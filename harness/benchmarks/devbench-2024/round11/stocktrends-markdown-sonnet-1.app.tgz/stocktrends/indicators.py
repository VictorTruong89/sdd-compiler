import numpy as np
import pandas as pd


class Instrument:
    """Base class holding an OHLC DataFrame."""

    def __init__(self, df):
        self.odf = df
        self.df = df.copy()
        self._validate_df()

    def _validate_df(self):
        if not isinstance(self.df, pd.DataFrame):
            raise ValueError("Input must be a pandas DataFrame")
        self.df.columns = [str(c).lower() for c in self.df.columns]
        required = {"open", "high", "low", "close"}
        if not required.issubset(self.df.columns):
            raise ValueError("DataFrame must have open, high, low and close columns")


class Renko(Instrument):
    PERIOD_CLOSE = 1
    PRICE_MOVEMENT = 2
    TREND_CHANGE_DIFF = 2

    def __init__(self, df):
        super().__init__(df)
        self.brick_size = 1
        self.chart_type = Renko.PERIOD_CLOSE
        self.rdf = None

    def get_ohlc_data(self):
        if self.chart_type == self.PERIOD_CLOSE:
            self.rdf = self.period_close_bricks()
        else:
            self.rdf = self.price_movement_bricks()
        return self.rdf

    def _dates(self):
        if "date" in self.df.columns:
            return list(self.df["date"])
        return list(self.df.index)

    def _build(self, series):
        """series: iterable of (date, high, low, close) used to extend bricks."""
        bs = self.brick_size
        rows = []
        level = None  # close of last brick
        up = True
        for date, hi, lo, cl in series:
            if level is None:
                level = np.floor(cl / bs) * bs
                rows.append((date, level - bs, level, level - bs, level, True))
                up = True
                continue
            yield_rows = self._extend(date, level, up, hi, lo, cl)
            for r in yield_rows:
                rows.append(r)
                level, up = r[4], r[5]
        return rows

    def _extend(self, date, level, up, hi, lo, cl):
        bs = self.brick_size
        out = []
        if self.chart_type == self.PERIOD_CLOSE:
            up_t = down_t = cl
        else:
            up_t, down_t = hi, lo
        up_move = np.floor(up_t / bs) * bs
        down_move = np.ceil(down_t / bs) * bs
        diff_up = round((up_move - level) / bs)
        diff_dn = round((level - down_move) / bs)
        if up:
            if diff_up >= 1:
                direction, n, start = True, diff_up, level
            elif diff_dn >= self.TREND_CHANGE_DIFF:
                direction, n, start = False, diff_dn - 1, level - bs
            else:
                return out
        else:
            if diff_dn >= 1:
                direction, n, start = False, diff_dn, level
            elif diff_up >= self.TREND_CHANGE_DIFF:
                direction, n, start = True, diff_up - 1, level + bs
            else:
                return out
        o = start
        for _ in range(int(n)):
            c = o + bs if direction else o - bs
            out.append((date, o, max(o, c), min(o, c), c, direction))
            o = c
        return out

    def _to_frame(self, rows):
        cols = ["date", "open", "high", "low", "close", "uptrend"]
        out = pd.DataFrame(
            [(r[0], r[1], r[2], r[3], r[4], r[5]) for r in rows], columns=cols
        )
        return out

    def period_close_bricks(self):
        rows = self._build(
            (d, c, c, c) for d, c in zip(self._dates(), self.df["close"])
        )
        return self._to_frame(rows)

    def price_movement_bricks(self):
        rows = self._build(
            zip(self._dates(), self.df["high"], self.df["low"], self.df["close"])
        )
        return self._to_frame(rows)

    def shift_bricks(self):
        """Shift the brick set so each row reflects the previous close."""
        if self.rdf is None:
            self.get_ohlc_data()
        self.rdf["close_s1"] = self.rdf["close"].shift(1)
        self.rdf["diff"] = self.rdf["close"] - self.rdf["close_s1"]


class LineBreak(Instrument):
    def __init__(self, df):
        super().__init__(df)
        self.line_number = 3
        self.cdf = None

    def uptrend_reversal(self, close):
        lines = self.cdf.tail(self.line_number)
        return close > lines["high"].max()

    def downtrend_reversal(self, close):
        lines = self.cdf.tail(self.line_number)
        return close < lines["low"].min()

    def get_ohlc_data(self):
        cols = ["date", "open", "high", "low", "close"]
        if "date" not in self.df.columns:
            self.df["date"] = self.df.index
        df = self.df[cols].reset_index(drop=True)
        df["index"] = range(len(df))
        df["uptrend"] = True
        out = df.head(self.line_number).copy()
        self.cdf = out
        uptrend = True
        rows = []
        for r in df.itertuples():
            close = r.close
            prev = self.cdf.iloc[-1]
            new = None
            if uptrend:
                if close > prev["close"]:
                    new = (r.date, prev["close"], close, prev["close"], close, True)
                elif self.downtrend_reversal(close):
                    new = (r.date, prev["open"], prev["open"], close, close, False)
                    uptrend = False
            else:
                if close < prev["close"]:
                    new = (r.date, prev["close"], prev["close"], close, close, False)
                elif self.uptrend_reversal(close):
                    new = (r.date, prev["open"], close, prev["open"], close, True)
                    uptrend = True
            if new is not None:
                row = pd.DataFrame(
                    [{"index": 0, "date": new[0], "open": new[1], "high": new[2],
                      "low": new[3], "close": new[4], "uptrend": new[5]}]
                )
                self.cdf = pd.concat([self.cdf, row], ignore_index=True)
        return self.cdf[["index"] + cols + ["uptrend"]]


class PnF(Instrument):
    def __init__(self, df):
        super().__init__(df)
        self.box_size = 1
        self.reversal_size = 3

    @property
    def brick_size(self):
        return self.box_size

    def get_state(self, uptrend_p1, bricks):
        """Return 'continue', 'reverse' or 'none' for the move of `bricks` boxes."""
        if uptrend_p1:
            if bricks >= 1:
                return "continue"
            if bricks <= -self.reversal_size:
                return "reverse"
        else:
            if bricks <= -1:
                return "continue"
            if bricks >= self.reversal_size:
                return "reverse"
        return "none"

    def roundit(self, x, base):
        return int(base * round(float(x) / base))

    def _series(self, source):
        if "date" in self.df.columns:
            dates = list(self.df["date"])
        else:
            dates = list(self.df.index)
        if source == "hl":
            return dates, list(self.df["high"]), list(self.df["low"])
        if source == "close":
            c = list(self.df["close"])
            return dates, c, c
        raise ValueError("source must be 'close' or 'hl'")

    def get_ohlc_data(self, source="close"):
        """One row per box in the chart (open/close are box edges)."""
        bar = self.get_bar_ohlc_data(source)
        rows = []
        for r in bar.itertuples():
            step = self.box_size if r.uptrend else -self.box_size
            n = int(round(abs(r.close - r.open) / self.box_size))
            o = r.open
            for _ in range(n):
                c = o + step
                rows.append((r.date, o, max(o, c), min(o, c), c, r.uptrend))
                o = c
        return pd.DataFrame(
            rows, columns=["date", "open", "high", "low", "close", "uptrend"]
        )

    def get_bar_ohlc_data(self, source="close"):
        """One row per PnF column (a run of X's or O's)."""
        bs = self.box_size
        dates, highs, lows = self._series(source)
        cols = ["date", "open", "high", "low", "close", "uptrend"]
        if not dates:
            return pd.DataFrame(columns=cols)
        top = np.floor(highs[0] / bs) * bs
        bottom = np.ceil(lows[0] / bs) * bs
        rows = []
        uptrend = None
        start = None
        cur_date = dates[0]
        for d, h, l in zip(dates, highs, lows):
            hb = np.floor(h / bs) * bs
            lb = np.ceil(l / bs) * bs
            if uptrend is None:
                if hb - bottom >= bs and hb - bottom >= lb * 0 + bs:
                    uptrend, start, top, cur_date = True, bottom, hb, d
                elif top - lb >= bs:
                    uptrend, start, bottom, cur_date = False, top, lb, d
                continue
            if uptrend:
                if hb > top:
                    top, cur_date = hb, d
                elif (top - lb) / bs >= self.reversal_size:
                    rows.append((cur_date, start, top, start, top, True))
                    uptrend, start, bottom, cur_date = False, top - bs, lb, d
            else:
                if lb < bottom:
                    bottom, cur_date = lb, d
                elif (hb - bottom) / bs >= self.reversal_size:
                    rows.append((cur_date, start, start, bottom, bottom, False))
                    uptrend, start, top, cur_date = True, bottom + bs, hb, d
        if uptrend is not None:
            if uptrend:
                rows.append((cur_date, start, top, start, top, True))
            else:
                rows.append((cur_date, start, start, bottom, bottom, False))
        return pd.DataFrame(rows, columns=cols)
