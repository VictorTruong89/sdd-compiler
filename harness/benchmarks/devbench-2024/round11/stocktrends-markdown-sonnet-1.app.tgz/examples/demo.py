import os
import sys

import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from stocktrends import Renko, LineBreak, PnF

here = os.path.dirname(os.path.abspath(__file__))
df = pd.read_csv(os.path.join(here, "HDFCLIFE.csv"))
df.columns = [c.lower() for c in df.columns]
df = df.sort_values("date").reset_index(drop=True)

renko = Renko(df)
renko.brick_size = 5
print("Renko:\n", renko.get_ohlc_data().tail())
print("Line Break:\n", LineBreak(df).get_ohlc_data().tail())
pnf = PnF(df)
pnf.box_size = 5
print("PnF:\n", pnf.get_ohlc_data("close").tail())
