import os

import pandas as pd

from stocktrends import PnF

HERE = os.path.dirname(os.path.abspath(__file__))


def test_pnf():
    p = PnF(pd.read_csv(os.path.join(HERE, "HOOLI.csv")))
    assert p.roundit(7.6, 2) == 8
    assert p.get_state(True, 1) == "continue"
    assert len(p.get_ohlc_data("close")) > 0
