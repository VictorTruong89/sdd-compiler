import os

import pandas as pd

from stocktrends import Renko

HERE = os.path.dirname(os.path.abspath(__file__))


def test_shape():
    r = Renko(pd.read_csv(os.path.join(HERE, "HOOLI.csv")))
    r.brick_size = 4
    assert r.get_ohlc_data().shape == (215, 6)
