import os

import pandas as pd
import pytest

from stocktrends import Instrument

HERE = os.path.dirname(os.path.abspath(__file__))


def test_lowercase_columns():
    df = pd.read_csv(os.path.join(HERE, "HDFCLIFE.csv"))
    assert "close" in Instrument(df).df.columns


def test_missing_columns():
    with pytest.raises(ValueError):
        Instrument(pd.DataFrame({"open": [1]}))
