import os

import pandas as pd

from stocktrends import Renko, LineBreak

HERE = os.path.dirname(os.path.abspath(__file__))


def _load(name):
    return pd.read_csv(os.path.join(HERE, name))


def test_renko():
    r = Renko(_load("HOOLI.csv"))
    r.brick_size = 4
    out = r.get_ohlc_data()
    exp = _load("hooli_renko_4.csv")
    assert out.shape[0] == exp.shape[0]
    assert ((out["close"].values - exp["close"].values).__abs__() <= 1e-12).all()


def test_linebreak():
    out = LineBreak(_load("HOOLI.csv")).get_ohlc_data()
    exp = _load("hooli_linebreak_3.csv")
    assert out.shape[0] == exp.shape[0]
    assert ((out["close"].values - exp["close"].values).__abs__() <= 1e-12).all()
