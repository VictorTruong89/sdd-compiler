#! /bin/bash
set -e

# source /path/to/your/venv/bin/activate
pip install lice

lice

lice mit

lice -y $(date +"%Y") -o "Your Organization Name"

lice -l py > LICENSE.txt

# Run tests
python -m unittest discover -s ./lice/tests -p 'test_*.py'
