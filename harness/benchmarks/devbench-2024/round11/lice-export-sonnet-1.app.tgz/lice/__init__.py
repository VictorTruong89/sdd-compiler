# spec: N-000046 N-000047
__version__ = "0.1.0"

from .core import main  # noqa: E402,F401
