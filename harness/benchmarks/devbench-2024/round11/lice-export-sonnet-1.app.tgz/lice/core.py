#!/usr/bin/env python
"""Lice: generate license files and source headers."""
# spec: N-000048
import argparse
import datetime
import os
import re
import subprocess
import sys
from io import StringIO

_HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_DIRS = [
    os.path.join(os.path.dirname(_HERE), "templates"),
    os.path.join(_HERE, "templates"),
]

LICENSES = [  # spec: N-000014 N-000015 N-000016 N-000017
    "afl3", "agpl3", "apache", "bsd2", "bsd3", "cc0", "cc_by", "cc_by_nc",
    "cc_by_nc_nd", "cc_by_nc_sa", "cc_by_nd", "cc_by_sa", "cddl", "epl",
    "gpl2", "gpl3", "isc", "lgpl", "mit", "mpl", "wtfpl", "zlib",
]
DEFAULT_LICENSE = "bsd3"

# language -> comment style [open, per-line prefix, close]
LANG_CMT = {
    "c": ["/*", " *", " */"],
    "css": ["/*", " *", " */"],
    "erb": ["<%#", "", "%>"],
    "hs": ["{-", "", "-}"],
    "html": ["<!--", "", "-->"],
    "lisp": [";;", ";;", ";;"],
    "lua": ["--[[", "", "--]]"],
    "ml": ["(*", "", "*)"],
    "pas": ["{", "", "}"],
    "php": ["/*", " *", " */"],
    "py": ["#", "#", "#"],
    "rb": ["#", "#", "#"],
    "sh": ["#", "#", "#"],
    "sql": ["--", "--", "--"],
    "tex": ["%", "%", "%"],
    "txt": ["", "", ""],
    "vim": ['"', '"', '"'],
    "xml": ["<!--", "", "-->"],
}

# file extension -> language key
LANGS = {
    "c": "c", "cc": "c", "cpp": "c", "cs": "c", "cxx": "c", "go": "c",
    "h": "c", "hpp": "c", "java": "c", "js": "c", "m": "c", "scala": "c",
    "swift": "c", "ts": "c", "rs": "c", "kt": "c",
    "css": "css", "erb": "erb", "hs": "hs", "html": "html", "htm": "html",
    "cl": "lisp", "clj": "lisp", "el": "lisp", "lisp": "lisp", "scm": "lisp",
    "lua": "lua", "ml": "ml", "pas": "pas", "php": "php",
    "py": "py", "pl": "py", "r": "py", "rb": "rb", "sh": "sh", "bash": "sh",
    "zsh": "sh", "yml": "py", "yaml": "py", "toml": "py", "mk": "py",
    "sql": "sql", "tex": "tex", "txt": "txt", "vim": "vim",
    "xml": "xml", "svg": "xml",
}


class Context(object):
    def __init__(self, year, organization, project):
        self.year = year
        self.organization = organization
        self.project = project


def clean_path(p):
    return os.path.abspath(os.path.expanduser(p))


def get_suffix(name):
    """Return the file extension (no dot) of name, or False."""
    if not name:
        return False
    ext = os.path.splitext(name)[1]
    if len(ext) > 1:
        return ext[1:]
    return False


def guess_organization():  # spec: N-000009 N-000050
    try:
        out = subprocess.run(
            ["git", "config", "--get", "user.name"],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            universal_newlines=True,
        ).stdout.strip()
        if out:
            return out
    except (OSError, ValueError):
        pass
    return os.getenv("USER") or os.getenv("USERNAME") or ""


def get_context(args):
    year = args.year or str(datetime.date.today().year)
    org = args.org or guess_organization()
    proj = args.proj or os.path.basename(os.getcwd())
    return Context(str(year), org, proj)


def load_file_template(path):
    with open(clean_path(path), "r") as f:
        return StringIO(f.read())


def load_template(license, header=False):
    name = "template-%s%s.txt" % (license, "-header" if header else "")
    for d in TEMPLATE_DIRS:
        p = os.path.join(d, name)
        if os.path.isfile(p):
            return load_file_template(p)
    raise IOError("Template not found: %s" % name)


_VAR_RE = re.compile(r"\{\{\s*(\w+)\s*\}\}")


def extract_vars(template):
    template.seek(0)
    seen = []
    for name in _VAR_RE.findall(template.read()):
        if name not in seen:
            seen.append(name)
    template.seek(0)
    return seen


def generate_license(template, context):  # spec: N-000051
    template.seek(0)
    values = {
        "year": context.year,
        "organization": context.organization,
        "project": context.project,
    }
    text = _VAR_RE.sub(lambda m: str(values.get(m.group(1), m.group(0))),
                       template.read())
    out = StringIO()
    out.write(text)
    out.seek(0)
    return out


def format_license(template, lang):  # spec: N-000052
    lang = lang if lang in LANG_CMT else LANGS.get(lang, "txt")
    start, mid, end = LANG_CMT[lang]
    template.seek(0)
    out = StringIO()
    if start:
        out.write(start + "\n")
    for line in template.readlines():
        line = line.rstrip("\n")
        out.write((mid + " " + line).rstrip() if (mid or line) else "")
        out.write("\n")
    if end:
        out.write(end + "\n")
    out.seek(0)
    return out


def get_parser():
    p = argparse.ArgumentParser(description="Generate a license")
    p.add_argument("license", metavar="license", nargs="?",
                   default=DEFAULT_LICENSE, help="the license to generate")
    p.add_argument("--header", dest="header", action="store_true",
                   help="generate source file header for the license")
    p.add_argument("-o", "--org", dest="org", help="organization")
    p.add_argument("-p", "--proj", dest="proj", help="project name")
    p.add_argument("-t", "--template", dest="template",
                   help="path to a custom license template")
    p.add_argument("-y", "--year", dest="year", help="copyright year")
    p.add_argument("-l", "--language", dest="language",
                   help="format for language")
    p.add_argument("-f", "--file", dest="ofile", help="output file")
    p.add_argument("--vars", dest="list_vars", action="store_true",
                   help="list template variables for specified license")
    return p


def main(argv=None):  # spec: N-000049
    args = get_parser().parse_args(argv)
    lic = args.license.lower()
    if not args.template and lic not in LICENSES:
        sys.stderr.write("Invalid license %r. Valid licenses: %s\n"
                         % (args.license, ", ".join(LICENSES)))
        sys.exit(1)

    try:
        if args.template:
            template = load_file_template(args.template)
        else:
            template = load_template(lic, args.header)
    except IOError as e:
        sys.stderr.write("%s\n" % e)
        sys.exit(1)

    if args.list_vars:
        print(extract_vars(template))
        return

    content = generate_license(template, get_context(args))
    lang = args.language or get_suffix(args.ofile)
    if lang:
        content = format_license(content, lang)

    text = content.getvalue()
    if args.ofile:
        with open(clean_path(args.ofile), "w") as f:
            f.write(text)
    else:
        sys.stdout.write(text)


if __name__ == "__main__":
    main()
