import unittest
from lice import core


class T(unittest.TestCase):
    def test_vars(self):
        self.assertEqual(core.extract_vars(core.load_template("bsd3")),
                         ["year", "organization", "project"])

    def test_generate_format(self):
        c = core.Context("2021", "Org", "P")
        out = core.generate_license(core.load_template("mit"), c)
        self.assertIn("2021 Org", out.getvalue())
        f = core.format_license(out, "py").getvalue()
        self.assertTrue(f.startswith("#\n# "))
