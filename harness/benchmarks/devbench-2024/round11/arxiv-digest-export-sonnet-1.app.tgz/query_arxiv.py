import argparse
import csv
import os
import re
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from typing import Dict, List

BASE_URL = "http://export.arxiv.org/api/query"
ALLOWED = re.compile(r"^[A-Za-z0-9+:.]+$")  # spec: N-000027
NAMESPACE = {"atom": "http://www.w3.org/2005/Atom"}
FIELDS = ["category", "title", "author", "abstract", "published", "link"]
ABSTRACT_LIMIT = 200


def _validate(category, title, author, abstract):
    values = [category, title, author, abstract]
    if all(v is None or v == "" for v in values):  # spec: N-000025
        raise ValueError("At least one of category, title, author, abstract must be provided")
    for v in values:
        if v and not ALLOWED.match(v):  # spec: N-000028
            raise ValueError(f"Invalid characters in argument: {v!r}")


def get_args(argv=None) -> argparse.Namespace:  # spec: N-000046
    parser = argparse.ArgumentParser(description="Query ArXiv for recent papers")
    parser.add_argument("--category", type=str, default=None)
    parser.add_argument("--title", type=str, default=None)
    parser.add_argument("--author", type=str, default=None)
    parser.add_argument("--abstract", type=str, default=None)
    parser.add_argument("--recent_days", type=int, required=True)  # spec: N-000030
    parser.add_argument("--max_results", type=int, default=10)  # spec: N-000005
    parser.add_argument("--to_file", type=str, default=None)
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args(argv)
    _validate(args.category, args.title, args.author, args.abstract)
    return args


def construct_query_url(category: str = None, title: str = None, author: str = None,
                        abstract: str = None, max_results: int = 10) -> str:  # spec: N-000048
    _validate(category, title, author, abstract)
    parts = []
    if category:
        parts.append(f"cat:{category}")
    if author:
        parts.append(f"au:{author}")
    if title:
        parts.append(f"ti:{title}")
    if abstract:
        parts.append(f"abs:{abstract}")
    query = "+AND+".join(parts)
    return (f"{BASE_URL}?search_query={query}&sortBy=submittedDate&sortOrder=descending"
            f"&start=0&max_results={max_results}")  # spec: N-000009


def fetch_data(query_url: str) -> bytes:  # spec: N-000049
    with urllib.request.urlopen(query_url) as response:
        return response.read()


def check_date(date_string: str, recent_days: int, current_date: datetime) -> bool:  # spec: N-000051
    published = datetime.strptime(date_string[:10], "%Y-%m-%d")
    if current_date.tzinfo is not None:
        published = published.replace(tzinfo=current_date.tzinfo)
    return current_date - published <= timedelta(days=recent_days + 1) \
        and published <= current_date


def _text(entry, tag):
    el = entry.find(f"atom:{tag}", NAMESPACE)
    return (el.text or "").strip() if el is not None and el.text else ""


def process_entries(entries: List[ET.Element], namespace: Dict[str, str],
                    current_date: datetime, recent_days: int) -> List[Dict[str, str]]:  # spec: N-000050
    papers = []
    for entry in entries:
        published = (entry.findtext("atom:published", default="", namespaces=namespace) or "").strip()
        if not published or not check_date(published, recent_days, current_date):
            continue
        authors = [(a.findtext("atom:name", default="", namespaces=namespace) or "").strip()
                   for a in entry.findall("atom:author", namespace)]
        cat = entry.find("atom:category", namespace)
        papers.append({
            "category": cat.get("term", "") if cat is not None else "",
            "title": " ".join((entry.findtext("atom:title", default="", namespaces=namespace) or "").split()),
            "author": ", ".join(authors),
            "abstract": " ".join((entry.findtext("atom:summary", default="", namespaces=namespace) or "").split()),
            "published": published,
            "link": (entry.findtext("atom:id", default="", namespaces=namespace) or "").strip(),
        })
    return papers


def save_to_csv(papers: List[Dict[str, str]], file_name: str) -> None:  # spec: N-000052
    folder = os.path.dirname(file_name)
    if folder:
        os.makedirs(folder, exist_ok=True)
    with open(file_name, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(papers)


def print_results(papers: List[Dict[str, str]]) -> None:  # spec: N-000053
    for p in papers:
        abstract = p.get("abstract", "")
        if len(abstract) > ABSTRACT_LIMIT:  # spec: N-000054
            abstract = abstract[:ABSTRACT_LIMIT] + "..."
        print(f"Title: {p.get('title', '')}")
        print(f"Category: {p.get('category', '')}")
        print(f"Author: {p.get('author', '')}")
        print(f"Published: {p.get('published', '')}")
        print(f"Link: {p.get('link', '')}")
        print(f"Abstract: {abstract}")
        print()


def main(argv=None):  # spec: N-000047
    args = get_args(argv)
    url = construct_query_url(args.category, args.title, args.author, args.abstract, args.max_results)
    data = fetch_data(url)
    root = ET.fromstring(data)
    entries = root.findall("atom:entry", NAMESPACE)
    papers = process_entries(entries, NAMESPACE, datetime.now(timezone.utc).replace(tzinfo=None), args.recent_days)
    # spec: N-000013 (CF-000003/CF-000006 resolved per PRD text: only --to_file => save only)
    if args.to_file:
        save_to_csv(papers, args.to_file)
    if args.verbose or not args.to_file:
        print_results(papers)


if __name__ == "__main__":
    main()
