import os
import sys

import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from stocktrends import LineBreak, PnF, Renko  # noqa: E402

here = os.path.dirname(os.path.abspath(__file__))
df = pd.read_csv(os.path.join(here, "HDFCLIFE.csv"))
df.columns = [c.lower() for c in df.columns]
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

# spec: N-000015 reporting
print("Renko bricks:", len(Renko(df, brick_size=10).get_ohlc_data()))
print("Line break lines:", len(LineBreak(df, line_number=3).get_ohlc_data()))
print("PnF columns:", len(PnF(df, box_size=10).get_ohlc_data()))
