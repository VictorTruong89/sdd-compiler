import os

import pandas as pd

from stocktrends import LineBreak, Renko

HERE = os.path.dirname(os.path.abspath(__file__))


def _load(name, **kw):
    return pd.read_csv(os.path.join(HERE, name), **kw)


def test_N_000042_renko_close_matches():
    expected = _load("hooli_renko_4.csv", index_col=0)
    got = Renko(_load("HOOLI.csv"), brick_size=4).get_ohlc_data()
    assert got.shape[0] == expected.shape[0]
    assert (got["close"].values - expected["close"].values).__abs__().max() <= 1e-12


def test_N_000044_linebreak_close_matches():
    expected = _load("hooli_linebreak_3.csv", index_col=0)
    got = LineBreak(_load("HOOLI.csv"), line_number=3).get_ohlc_data()
    assert got.shape[0] == expected.shape[0]
    assert (got["close"].values - expected["close"].values).__abs__().max() <= 1e-12
