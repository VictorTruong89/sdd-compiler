import os

import pandas as pd

from stocktrends import PnF

HERE = os.path.dirname(os.path.abspath(__file__))


def test_roundit_and_brick_size():
    pnf = PnF(pd.read_csv(os.path.join(HERE, "HOOLI.csv")), box_size=2)
    assert pnf.roundit(7.4, 2) == 8
    assert pnf.brick_size == 2


def test_pnf_runs():
    pnf = PnF(pd.read_csv(os.path.join(HERE, "HOOLI.csv")), box_size=2)
    out = pnf.get_ohlc_data()
    assert list(out.columns) == ["date", "open", "high", "low", "close", "uptrend"]
