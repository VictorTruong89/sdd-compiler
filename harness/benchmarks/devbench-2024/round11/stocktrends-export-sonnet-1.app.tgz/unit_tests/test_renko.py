import os

import pandas as pd

from stocktrends import Renko

HERE = os.path.dirname(os.path.abspath(__file__))


def test_renko_shape():
    df = pd.read_csv(os.path.join(HERE, "HOOLI.csv"))
    out = Renko(df, brick_size=4).get_ohlc_data()
    assert out.shape == (215, 6)
