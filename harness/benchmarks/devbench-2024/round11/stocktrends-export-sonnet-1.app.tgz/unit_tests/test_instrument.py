import pandas as pd
import pytest

from stocktrends import Instrument


def test_lowercases_columns():
    df = pd.DataFrame({"DATE": [1], "OPEN": [1], "HIGH": [1], "LOW": [1], "CLOSE": [1]})
    assert list(Instrument(df).df.columns) == ["date", "open", "high", "low", "close"]


def test_missing_columns():
    with pytest.raises(ValueError):
        Instrument(pd.DataFrame({"a": [1]}))
