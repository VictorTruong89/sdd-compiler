import math

import numpy as np
import pandas as pd


class Instrument:
    """Base class holding the OHLC data of a financial instrument."""

    # spec: N-000049
    def __init__(self, df):
        self.odf = df
        self.df = df
        self._validate_df()

    # spec: N-000050 N-000005
    def _validate_df(self):
        """Lowercase the column names and check the required OHLC columns."""
        self.df = self.df.copy()
        self.df.columns = [str(c).lower() for c in self.df.columns]
        self.odf = self.df
        required = {"date", "open", "high", "low", "close"}
        if not required.issubset(set(self.df.columns)):
            raise ValueError("DataFrame must have date, open, high, low, close columns")


class Renko(Instrument):
    PERIOD_CLOSE = 1
    PRICE_MOVEMENT = 2
    TREND_CHANGE_DIFF = 2

    # spec: N-000051 N-000006 N-000007
    def __init__(self, df, brick_size=4, chart_type=PERIOD_CLOSE):
        super().__init__(df)
        self.brick_size = brick_size
        self.chart_type = chart_type
        self.rdf = None

    # spec: N-000052 N-000008
    def get_ohlc_data(self):
        if self.chart_type == self.PERIOD_CLOSE:
            self.rdf = self.period_close_bricks()
        else:
            self.price_movement_bricks()
        return self.rdf

    def _build(self, dates, closes, use_high_low=False):
        size = self.brick_size
        rows = []
        last_close = None
        last_open = None
        up = True
        for k, (date, close) in enumerate(zip(dates, closes)):
            if last_close is None:
                base = math.floor(close / size) * size
                rows.append((date, base - size, base, base - size, base, True))
                last_close, last_open, up = base, base - size, True
                continue
            while True:
                if up:
                    if close >= last_close + size:
                        o, c = last_close, last_close + size
                        rows.append((date, o, c, o, c, True))
                        last_open, last_close = o, c
                    elif close <= last_open - size:
                        o, c = last_open, last_open - size
                        rows.append((date, o, o, c, c, False))
                        last_open, last_close, up = o, c, False
                    else:
                        break
                else:
                    if close <= last_close - size:
                        o, c = last_close, last_close - size
                        rows.append((date, o, o, c, c, False))
                        last_open, last_close = o, c
                    elif close >= last_open + size:
                        o, c = last_open, last_open + size
                        rows.append((date, o, c, o, c, True))
                        last_open, last_close, up = o, c, True
                    else:
                        break
        out = pd.DataFrame(rows, columns=["date", "open", "high", "low", "close", "uptrend"])
        return out

    # spec: N-000053
    def period_close_bricks(self):
        df = self.odf.reset_index(drop=True)
        return self._build(df["date"], df["close"].astype(float))

    def price_movement_bricks(self):
        df = self.odf.reset_index(drop=True)
        self.rdf = self._build(df["date"], df["close"].astype(float))
        return self.rdf

    # spec: N-000054
    def shift_bricks(self):
        """Shift brick counts: a trend change must cover TREND_CHANGE_DIFF bricks."""
        df = self.df
        size = self.brick_size
        floor = (df["close"] // size) * size
        bricks = (floor - floor.shift(1)) / size
        shift = df["close"] - df["close"].shift(1)
        bricks = bricks.where(shift.isna() | (np.sign(bricks) == np.sign(shift)),
                              bricks - np.sign(bricks))
        self.df = df.assign(bricks=bricks)
        return self.df


class LineBreak(Instrument):
    # spec: N-000055 N-000009
    def __init__(self, df, line_number=3):
        super().__init__(df)
        self.line_number = line_number
        self.cdf = None

    # spec: N-000056
    def uptrend_reversal(self, close):
        highs = self.cdf["high"].iloc[-self.line_number:]
        return close > highs.max()

    # spec: N-000057
    def downtrend_reversal(self, close):
        lows = self.cdf["low"].iloc[-self.line_number:]
        return close < lows.min()

    # spec: N-000058 N-000059 N-000010
    def get_ohlc_data(self):
        df = self.odf.reset_index(drop=True)
        cols = ["index", "date", "open", "high", "low", "close", "uptrend"]
        first = df.iloc[:self.line_number][["date", "open", "high", "low", "close"]].copy()
        first.insert(0, "index", range(len(first)))
        first["uptrend"] = True
        self.cdf = first.reset_index(drop=True)[cols]
        for _, row in df.iterrows():
            close = row["close"]
            last = self.cdf.iloc[-1]
            new = None
            if last["uptrend"]:
                if close > last["close"]:
                    new = (0, row["date"], last["close"], close, last["close"], close, True)
                elif self.downtrend_reversal(close):
                    new = (0, row["date"], last["open"], last["open"], close, close, False)
            else:
                if close < last["close"]:
                    new = (0, row["date"], last["close"], last["close"], close, close, False)
                elif self.uptrend_reversal(close):
                    new = (0, row["date"], last["open"], close, last["open"], close, True)
            if new is not None:
                self.cdf.loc[len(self.cdf)] = new
        self.cdf = self.cdf.reset_index(drop=True)
        return self.cdf


class PnF(Instrument):
    # spec: N-000060
    def __init__(self, df, box_size=1, reversal_size=3):
        super().__init__(df)
        self.box_size = box_size
        self.reversal_size = reversal_size

    # spec: N-000061
    @property
    def brick_size(self):
        return self.box_size

    # spec: N-000062
    def get_state(self, uptrend_p1, bricks):
        """Return 'continue', 'reverse' or 'none' for the move of `bricks` boxes."""
        if uptrend_p1:
            if bricks >= 1:
                return "continue"
            if bricks <= -self.reversal_size:
                return "reverse"
        else:
            if bricks <= -1:
                return "continue"
            if bricks >= self.reversal_size:
                return "reverse"
        return "none"

    # spec: N-000063 N-000064
    def roundit(self, x, base):
        return int(base * round(float(x) / base))

    # spec: N-000065
    def get_ohlc_data(self, source="close"):
        df = self.odf.reset_index(drop=True)
        size = self.box_size
        rows = []
        if len(df) == 0:
            return pd.DataFrame(columns=["date", "open", "high", "low", "close", "uptrend"])
        if source == "hl":
            prices = [(r["date"], r["high"], r["low"]) for _, r in df.iterrows()]
        else:
            prices = [(r["date"], r["close"], r["close"]) for _, r in df.iterrows()]
        level = math.floor(prices[0][1] / size) * size
        top = bottom = level
        up = None
        for date, hi, lo in prices[1:]:
            hi_f = math.floor(hi / size) * size
            lo_f = math.floor(lo / size) * size
            if up is None:
                if hi_f - top >= size:
                    up, top = True, hi_f
                    rows.append((date, bottom, top, bottom, top, True))
                elif bottom - lo_f >= size:
                    up, bottom = False, lo_f
                    rows.append((date, top, top, bottom, bottom, False))
                continue
            if up:
                state = self.get_state(True, (hi_f - top) // size)
                if state == "continue":
                    top = hi_f
                    rows[-1] = (date, rows[-1][1], top, rows[-1][3], top, True)
                elif self.get_state(True, (lo_f - top) // size) == "reverse":
                    bottom = lo_f
                    rows.append((date, top - size, top - size, bottom, bottom, False))
                    top -= size
            else:
                state = self.get_state(False, (lo_f - bottom) // size)
                if state == "continue":
                    bottom = lo_f
                    rows[-1] = (date, rows[-1][1], rows[-1][2], bottom, bottom, False)
                elif self.get_state(False, (hi_f - bottom) // size) == "reverse":
                    top = hi_f
                    rows.append((date, bottom + size, top, bottom + size, top, True))
                    bottom += size
        return pd.DataFrame(rows, columns=["date", "open", "high", "low", "close", "uptrend"])

    # spec: N-000066
    def get_bar_ohlc_data(self, source="close"):
        pnf = self.get_ohlc_data(source)
        return pnf.reset_index(drop=True)
