import argparse
import csv
import os
import sys
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from typing import Dict, List

ALLOWED_CHARS = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+:.")
BASE_URL = "http://export.arxiv.org/api/query"
NAMESPACE = {"atom": "http://www.w3.org/2005/Atom"}


def _validate(name, value):
    if value is None:
        return
    if not all(c in ALLOWED_CHARS for c in str(value)):
        raise ValueError(f"Invalid characters in argument '{name}': {value}")


def get_args(argv=None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Query the ArXiv API for recent papers.")
    parser.add_argument("--category", type=str, default=None, help="Category of the paper")
    parser.add_argument("--title", type=str, default=None, help="Keyword in the title")
    parser.add_argument("--author", type=str, default=None, help="Author keyword")
    parser.add_argument("--abstract", type=str, default=None, help="Keyword in the abstract")
    parser.add_argument("--recent_days", type=int, required=True, help="Only papers from the last k days")
    parser.add_argument("--to_file", type=str, default=None, help="Path to save results as CSV")
    parser.add_argument("--verbose", action="store_true", help="Print results to console")
    parser.add_argument("--max_results", type=int, default=10, help="Maximum number of results")
    args = parser.parse_args(argv)
    for name in ("category", "title", "author", "abstract"):
        _validate(name, getattr(args, name))
    if not any([args.category, args.title, args.author, args.abstract]):
        parser.error("At least one of category, title, author, abstract must be provided")
    return args


def construct_query_url(category: str = None, title: str = None, author: str = None,
                        abstract: str = None, max_results: int = 10) -> str:
    parts = []
    for prefix, name, value in (("cat", "category", category), ("au", "author", author),
                                ("ti", "title", title), ("abs", "abstract", abstract)):
        _validate(name, value)
        if value:
            parts.append(f"{prefix}:{value}")
    if not parts:
        raise ValueError("At least one of category, title, author, abstract must be provided")
    query = "+AND+".join(parts)
    return (f"{BASE_URL}?search_query={query}&sortBy=submittedDate&sortOrder=descending"
            f"&start=0&max_results={max_results}")


def fetch_data(query_url: str) -> bytes:
    with urllib.request.urlopen(query_url) as response:
        return response.read()


def check_date(date_string: str, recent_days: int, current_date: datetime) -> bool:
    published = datetime.strptime(date_string, "%Y-%m-%dT%H:%M:%SZ")
    if current_date.tzinfo is not None:
        current_date = current_date.astimezone(timezone.utc).replace(tzinfo=None)
    return current_date - published <= timedelta(days=recent_days)


def _text(entry, tag):
    el = entry.find(f"atom:{tag}", NAMESPACE)
    return (el.text or "").strip() if el is not None and el.text else ""


def process_entries(entries: List[ET.Element], namespace: Dict[str, str],
                    current_date: datetime, recent_days: int) -> List[Dict[str, str]]:
    papers = []
    for entry in entries:
        published = entry.find("atom:published", namespace)
        published = (published.text or "").strip() if published is not None else ""
        if not published or not check_date(published, recent_days, current_date):
            continue
        cat = entry.find("atom:category", namespace)
        category = cat.get("term", "") if cat is not None else ""
        authors = [(a.text or "").strip() for a in entry.findall("atom:author/atom:name", namespace)]
        link_el = entry.find("atom:id", namespace)
        link = (link_el.text or "").strip() if link_el is not None else ""
        title = entry.find("atom:title", namespace)
        summary = entry.find("atom:summary", namespace)
        papers.append({
            "category": category,
            "title": " ".join((title.text or "").split()) if title is not None else "",
            "author": ", ".join(authors),
            "abstract": " ".join((summary.text or "").split()) if summary is not None else "",
            "published": published,
            "link": link,
        })
    return papers


def save_to_csv(papers: List[Dict[str, str]], file_name: str) -> None:
    d = os.path.dirname(file_name)
    if d:
        os.makedirs(d, exist_ok=True)
    fields = ["category", "title", "author", "abstract", "published", "link"]
    with open(file_name, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for p in papers:
            writer.writerow({k: p.get(k, "") for k in fields})


def print_results(papers: List[Dict[str, str]]) -> None:
    for p in papers:
        abstract = p.get("abstract", "")
        if len(abstract) > 200:
            abstract = abstract[:200] + "..."
        print(f"Category: {p.get('category', '')}")
        print(f"Title: {p.get('title', '')}")
        print(f"Author: {p.get('author', '')}")
        print(f"Published: {p.get('published', '')}")
        print(f"Abstract: {abstract}")
        print(f"Link: {p.get('link', '')}")
        print("-" * 40)


def main(argv=None):
    args = get_args(argv)
    url = construct_query_url(args.category, args.title, args.author, args.abstract, args.max_results)
    data = fetch_data(url)
    root = ET.fromstring(data)
    entries = root.findall("atom:entry", NAMESPACE)
    papers = process_entries(entries, NAMESPACE, datetime.utcnow(), args.recent_days)
    if args.to_file:
        save_to_csv(papers, args.to_file)
    if args.verbose or not args.to_file:
        print_results(papers)


if __name__ == "__main__":
    main()
