#!/usr/bin/env python
"""Generate license files and source headers."""
import argparse
import os
import re
import subprocess
import sys
from datetime import date
from io import StringIO

LICENSES = ["afl3", "agpl3", "apache", "bsd2", "bsd3", "cc0", "cc_by",
            "cc_by_nc", "cc_by_nc_nd", "cc_by_nc_sa", "cc_by_nd", "cc_by_sa",
            "cddl", "epl", "gpl2", "gpl3", "isc", "lgpl", "mit", "mpl",
            "wtfpl", "zlib"]

DEFAULT_LICENSE = "bsd3"

_C = ["/*", " *", " */"]
_HASH = ["", "#", ""]
_SLASH = ["", "//", ""]
LANG_CMT = {
    "txt": ["", "", ""],
    "c": _C, "h": _C, "cpp": _SLASH, "cc": _SLASH, "hpp": _SLASH,
    "cs": _SLASH, "java": _C, "js": _C, "ts": _C, "go": _SLASH,
    "rs": _SLASH, "swift": _SLASH, "php": _C, "css": _C, "scala": _C,
    "kt": _C, "m": _C,
    "py": _HASH, "sh": _HASH, "rb": _HASH, "pl": _HASH, "r": _HASH,
    "yml": _HASH, "yaml": _HASH, "toml": _HASH, "mk": _HASH, "ps1": _HASH,
    "lua": ["--[[", "", "--]]"],
    "hs": ["", "--", ""], "sql": ["", "--", ""], "ada": ["", "--", ""],
    "html": ["<!--", "", "-->"], "xml": ["<!--", "", "-->"],
    "tex": ["", "%", ""], "erl": ["", "%", ""],
    "lisp": ["", ";", ""], "clj": ["", ";", ""], "el": ["", ";", ""],
    "vim": ["", '"', ""], "bat": ["", "REM", ""],
}

_VAR_RE = re.compile(r"\{\{\s*(\w+)\s*\}\}")


class Context(object):
    def __init__(self, year, organization, project):
        self.year = year
        self.organization = organization
        self.project = project

    def as_dict(self):
        return {"year": self.year, "organization": self.organization,
                "project": self.project}


def clean_path(p):
    return os.path.expanduser(p)


def guess_organization():
    """Guess the organization from git config, then $USER."""
    try:
        stdout = subprocess.check_output(
            ["git", "config", "--get", "user.name"],
            stderr=subprocess.DEVNULL)
        org = stdout.decode("utf-8", "replace").strip()
        if org:
            return org
    except (OSError, subprocess.CalledProcessError):
        pass
    return os.environ.get("USER") or os.environ.get("USERNAME") or ""


def get_context(args):
    year = getattr(args, "year", None) or str(date.today().year)
    org = getattr(args, "organization", None) or guess_organization()
    project = getattr(args, "project", None) or org
    return Context(str(year), org, project)


def load_file_template(path):
    template = StringIO()
    if not os.path.exists(path):
        raise ValueError("path does not exist: %s" % path)
    with open(clean_path(path), "rt") as f:
        template.write(f.read())
    template.seek(0)
    return template


def _template_dirs():
    here = os.path.dirname(os.path.abspath(__file__))
    return [os.path.join(here, "templates"),
            os.path.join(os.path.dirname(here), "templates")]


def load_template(license, header=False):
    if license not in LICENSES:
        raise ValueError("unknown license: %s" % license)
    name = "template-%s%s.txt" % (license, "-header" if header else "")
    for d in _template_dirs():
        path = os.path.join(d, name)
        if os.path.exists(path):
            with open(path, "rt") as f:
                template = StringIO(f.read())
            return template
    raise IOError("template not found: %s" % name)


def extract_vars(template):
    """Return the sorted unique variable names used in the template."""
    pos = template.tell() if hasattr(template, "tell") else 0
    template.seek(0)
    found = set()
    for line in template.readlines():
        found.update(_VAR_RE.findall(line))
    template.seek(pos)
    return sorted(found)


def generate_license(template, context):
    template.seek(0)
    values = context.as_dict()
    out = StringIO()
    for line in template.readlines():
        out.write(_VAR_RE.sub(
            lambda m: str(values.get(m.group(1), m.group(0))), line))
    out.seek(0)
    return out


def get_suffix(name):
    """Return the file extension (without dot) or False."""
    a = os.path.basename(name).split(".")
    if len(a) > 1 and a[-1]:
        return a[-1]
    return False


def format_license(template, lang):
    """Wrap the license in the comment syntax of lang."""
    lang = (lang or "txt").lower().lstrip(".")
    if lang not in LANG_CMT:
        raise ValueError("unknown language: %s" % lang)
    start, mid, end = LANG_CMT[lang]
    template.seek(0)
    out = StringIO()
    if start:
        out.write(start + "\n")
    for line in template.readlines():
        line = line.rstrip("\r\n")
        out.write((mid + " " + line).rstrip() if mid else line)
        out.write("\n")
    if end:
        out.write(end + "\n")
    out.seek(0)
    return out


def get_parser():
    parser = argparse.ArgumentParser(
        description="Generate a license file or source header")
    parser.add_argument("license", nargs="?", default=DEFAULT_LICENSE,
                        choices=LICENSES, metavar="license",
                        help="license to generate (%s)" % ", ".join(LICENSES))
    parser.add_argument("--header", action="store_true", dest="header",
                        help="generate a source file header")
    parser.add_argument("-o", "--org", dest="organization",
                        help="organization, defaults to git config or $USER")
    parser.add_argument("-p", "--proj", dest="project", help="project name")
    parser.add_argument("-t", "--template", dest="template_path",
                        help="path to a custom license template")
    parser.add_argument("-y", "--year", dest="year", help="copyright year")
    parser.add_argument("-l", "--language", dest="language",
                        help="format output for this language")
    parser.add_argument("-f", "--file", dest="ofile",
                        help="output file name")
    parser.add_argument("--vars", dest="list_vars", action="store_true",
                        help="list template variables for the license")
    return parser


def main(argv=None):
    args = get_parser().parse_args(argv)

    if args.template_path:
        template = load_file_template(args.template_path)
    else:
        template = load_template(args.license, args.header)

    if args.list_vars:
        print("The %s license template contains the following variables:"
              % args.license)
        for v in extract_vars(template):
            print("  " + v)
        return 0

    context = get_context(args)
    content = generate_license(template, context)

    lang = args.language
    if not lang and args.ofile:
        lang = get_suffix(args.ofile) or None
        if lang and lang.lower() not in LANG_CMT:
            lang = None
    if lang:
        content = format_license(content, lang)

    if args.ofile:
        with open(clean_path(args.ofile), "wt") as f:
            f.write(content.getvalue())
    else:
        sys.stdout.write(content.getvalue())
    return 0


if __name__ == "__main__":
    sys.exit(main())
