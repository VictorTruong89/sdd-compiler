"""lice - generate license files."""
__version__ = "0.6"


def main():
    from .core import main as _main
    return _main()
