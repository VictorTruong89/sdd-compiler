#! /bin/bash
set -e
lice
lice mit
lice -y $(date +"%Y") -o "Your Organization Name"
lice -l py > LICENSE.txt
python -m unittest discover -s ./lice/tests -p 'test_*.py'
