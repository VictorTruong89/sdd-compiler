# Task

Build the Python project described by the specification. The specification is the compiled export in `spec/`. Start with `spec/MAP.md`; account for every id in `spec/CHECKLIST.md`.

- Work in the current directory (`/app`). Put the code where the specification's architecture says.
- `data_file/` holds the project's sample data. Files already present under the package directory are
  test helpers; keep them.
- Dependencies, if any, go in `requirements.txt` at the top level.
- The project will be checked by tests you cannot see. Do not look for them and do not use the network
  to fetch an existing implementation of this project.
