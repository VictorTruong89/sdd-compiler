#!/bin/bash
cp -r /solution/reference/. /app/
echo "PROBE /tests during agent phase: $(ls /tests 2>&1 | tr '\n' ' ')"
echo "PROBE files under /app: $(cd /app && find . -maxdepth 3 -not -path './spec/*' -not -path './data_file/*' | sort | tr '\n' ' ')"
