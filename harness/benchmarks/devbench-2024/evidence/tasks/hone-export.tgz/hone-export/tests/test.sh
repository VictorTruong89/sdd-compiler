#!/bin/bash
# Copy the hidden tests beside the agent's code, run them, write named rewards.
cp -r /tests/unit_tests /tests/acceptance_tests /app/
cd /app
python -m venv /tmp/venv
/tmp/venv/bin/pip install -q pytest > /logs/verifier/pip.log 2>&1
[ -f requirements.txt ] && /tmp/venv/bin/pip install -q -r requirements.txt >> /logs/verifier/pip.log 2>&1
PYTHONPATH=/app /tmp/venv/bin/python -m pytest unit_tests acceptance_tests \
  -q -p no:cacheprovider --junitxml /logs/verifier/junit.xml > /logs/verifier/pytest.out 2>&1
/tmp/venv/bin/python - <<'PY'
import json, xml.etree.ElementTree as ET
TOTAL = 12
try:
    cases = list(ET.parse("/logs/verifier/junit.xml").getroot().iter("testcase"))
except Exception:
    cases = []
passed = sum(1 for c in cases if all(c.find(t) is None for t in ("failure", "error", "skipped")))
json.dump({"reward": passed / TOTAL, "tests_passed": passed, "tests_total": TOTAL,
           "tests_collected": len(cases)}, open("/logs/verifier/reward.json", "w"))
PY
