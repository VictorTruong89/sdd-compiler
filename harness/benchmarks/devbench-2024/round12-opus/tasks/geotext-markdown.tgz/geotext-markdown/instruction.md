# Task

Build the Python project described by the specification. The specification is the Markdown files in `spec/`. Start with `spec/PRD.md`.

- Work in the current directory (`/app`). Put the code where the specification's architecture says.
- Files already present outside `spec/` are the project's data files, its dependency list, or test
  helpers; keep them where they are. Present now: `geotext/`, `requirements.txt`.
- Dependencies, if any, go in `requirements.txt` at the top level.
- The project will be checked by tests you cannot see. Do not look for them and do not use the network
  to fetch an existing implementation of this project.
