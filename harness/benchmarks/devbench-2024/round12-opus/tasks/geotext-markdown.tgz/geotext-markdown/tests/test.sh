#!/bin/bash
# Keep what the agent wrote, copy the hidden tests beside it, run them, write named rewards.
mkdir -p /logs/verifier/agent_files
tar -czf /logs/verifier/agent_files/app.tgz -C /app --exclude=./spec --exclude='*.egg-info' \
  --exclude=__pycache__ --exclude=.venv --exclude=venv --exclude=.pytest_cache . 2>/dev/null
# Test folders the agent wrote are set aside (they are in app.tgz): only the hidden tests are scored.
rm -rf /app/unit_tests /app/acceptance_tests
cp -r /tests/unit_tests /tests/acceptance_tests /app/
cd /app
python -m venv /tmp/venv
/tmp/venv/bin/pip install -q pytest > /logs/verifier/pip.log 2>&1
# One requirement at a time: some DevEval lists name standard-library modules, which pip cannot install.
for req in /tests/project_requirements.txt requirements.txt; do
  [ -f "$req" ] && grep -vE '^[[:space:]]*(#|$)' "$req" | while read -r line; do
    /tmp/venv/bin/pip install -q "$line" >> /logs/verifier/pip.log 2>&1 || echo "NOT INSTALLED: $line" >> /logs/verifier/pip.log
  done
done
# Unit and acceptance tests in separate processes, as DevEval runs them.
for folder in unit_tests acceptance_tests; do
  PYTHONPATH=/app /tmp/venv/bin/python -m pytest $folder \
    -q -p no:cacheprovider --confcutdir=$folder --junitxml /logs/verifier/junit-$folder.xml >> /logs/verifier/pytest.out 2>&1
done
/tmp/venv/bin/python - <<'PY'
import json, xml.etree.ElementTree as ET
TOTAL = 9
cases = []
for folder in ("unit_tests", "acceptance_tests"):
    try:
        cases += list(ET.parse(f"/logs/verifier/junit-{folder}.xml").getroot().iter("testcase"))
    except Exception:
        pass
passed = sum(1 for c in cases if all(c.find(t) is None for t in ("failure", "error", "skipped")))
json.dump({"reward": passed / TOTAL, "tests_passed": passed, "tests_total": TOTAL,
           "tests_collected": len(cases)}, open("/logs/verifier/reward.json", "w"))
PY
