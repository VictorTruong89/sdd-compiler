import os
import sys

import cv2

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, 'src'))

from hybrid import create_hybrid_image  # noqa: E402


def main():
    left_img = cv2.imread(os.path.join(ROOT, 'resources', 'dog.jpg'))
    right_img = cv2.imread(os.path.join(ROOT, 'resources', 'cat.jpg'))
    hybrid_image = create_hybrid_image(left_img, right_img, 4.0, 17, 'low',
                                       3.0, 13, 'high', 0.65)
    out_path = os.path.join(ROOT, 'examples', 'hybrid.png')
    cv2.imwrite(out_path, hybrid_image)
    print('Hybrid image saved to', out_path)


if __name__ == '__main__':
    main()
