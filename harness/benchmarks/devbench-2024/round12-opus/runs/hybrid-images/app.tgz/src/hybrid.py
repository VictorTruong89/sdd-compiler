"""Hybrid image creation using cross-correlation, convolution and Gaussian filters."""
import numpy as np


def cross_correlation_2d(img, kernel):
    """Cross-correlate img with kernel (m x n, both odd), using zero padding.

    Works on grayscale (h x w) or color (h x w x c) images; the output has the
    same shape as the input image.
    """
    img = np.asarray(img)
    kernel = np.asarray(kernel, dtype=np.float64)
    m, n = kernel.shape
    pm, pn = m // 2, n // 2

    squeeze = img.ndim == 2
    data = img[:, :, np.newaxis] if squeeze else img
    data = data.astype(np.float64)
    h, w, c = data.shape

    padded = np.zeros((h + 2 * pm, w + 2 * pn, c), dtype=np.float64)
    padded[pm:pm + h, pn:pn + w] = data

    out = np.zeros((h, w, c), dtype=np.float64)
    for i in range(m):
        for j in range(n):
            k = kernel[i, j]
            if k != 0:
                out += k * padded[i:i + h, j:j + w]

    return out[:, :, 0] if squeeze else out


def convolve_2d(img, kernel):
    """Convolve img with kernel (cross-correlation with a flipped kernel)."""
    kernel = np.asarray(kernel)
    return cross_correlation_2d(img, kernel[::-1, ::-1])


def gaussian_blur_kernel_2d(sigma, width, height):
    """Return a normalized Gaussian kernel of shape (height, width)."""
    x = np.arange(width) - (width - 1) / 2.0
    y = np.arange(height) - (height - 1) / 2.0
    xx, yy = np.meshgrid(x, y)
    kernel = np.exp(-(xx ** 2 + yy ** 2) / (2.0 * sigma ** 2))
    return kernel / np.sum(kernel)


def low_pass(img, sigma, size):
    """Low-pass filter img with a size x size Gaussian kernel."""
    return convolve_2d(img, gaussian_blur_kernel_2d(sigma, size, size))


def high_pass(img, sigma, size):
    """High-pass filter img: the image minus its low-pass version."""
    return np.asarray(img, dtype=np.float64) - low_pass(img, sigma, size)


def create_hybrid_image(img1, img2, sigma1, size1, high_low1, sigma2, size2,
                        high_low2, mixin_ratio):
    """Combine two images into a hybrid image, returned as uint8."""
    high_low1 = high_low1.lower()
    high_low2 = high_low2.lower()

    img1 = np.asarray(img1)
    img2 = np.asarray(img2)
    if img1.dtype == np.uint8:
        img1 = img1.astype(np.float32) / 255.0
    if img2.dtype == np.uint8:
        img2 = img2.astype(np.float32) / 255.0

    if high_low1 == 'low':
        img1 = low_pass(img1, sigma1, size1)
    else:
        img1 = high_pass(img1, sigma1, size1)

    if high_low2 == 'low':
        img2 = low_pass(img2, sigma2, size2)
    else:
        img2 = high_pass(img2, sigma2, size2)

    img1 = img1 * (2 * (1 - mixin_ratio))
    img2 = img2 * (2 * mixin_ratio)
    hybrid_img = img1 + img2
    return (hybrid_img * 255).clip(0, 255).astype(np.uint8)
