from setuptools import setup, find_packages

setup(
    name='chakin',
    version='0.0.8',
    description='Simple downloader for pre-trained word vectors',
    packages=find_packages(),
    package_data={'chakin': ['datasets.csv']},
    include_package_data=True,
    install_requires=['progressbar2', 'pandas', 'six'],
)
