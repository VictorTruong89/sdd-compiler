# -*- coding: utf-8 -*-
import os

import pandas as pd
import progressbar

try:
    from six.moves.urllib.request import urlretrieve
except ImportError:  # pragma: no cover
    from urllib.request import urlretrieve

DATASETS_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                             'datasets.csv')
DISPLAY_COLUMNS = ['Name', 'Dimension', 'Corpus', 'VocabularySize',
                   'Method', 'Language', 'Author']


def load_datasets(path=DATASETS_PATH):
    """Load the list of available word vectors as a DataFrame."""
    return pd.read_csv(path)


def _find_row(datasets, number, name):
    if number is not None and number != -1:
        try:
            number = int(number)
        except (TypeError, ValueError):
            raise ValueError('number must be an integer: {!r}'.format(number))
        if number < 0 or number >= len(datasets):
            raise IndexError(
                'number must be between 0 and {}: {}'.format(
                    len(datasets) - 1, number))
        return datasets.iloc[number]
    if name:
        rows = datasets.loc[datasets['Name'] == name]
        if rows.empty:
            raise ValueError(
                'The word vector you specified was not found: {}'.format(name))
        return rows.iloc[0]
    raise ValueError('Please specify either number or name.')


def download(number=-1, name='', save_dir='./'):
    """Download a pre-trained word vector by its number or name.

    Returns the path of the downloaded file.
    """
    datasets = load_datasets()
    row = _find_row(datasets, number, name)
    url = str(row['URL'])

    file_name = os.path.basename(url.split('?')[0]) or 'word_vectors'
    if save_dir is None or save_dir == '':
        save_dir = './'
    save_dir = os.path.expanduser(str(save_dir))
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    save_path = os.path.join(save_dir, file_name)

    state = {'pbar': None}

    def report(count, block_size, total_size):
        if state['pbar'] is None:
            if total_size and total_size > 0:
                widgets = ['Downloading: ', progressbar.Percentage(), ' ',
                           progressbar.Bar(), ' ', progressbar.ETA(), ' ',
                           progressbar.FileTransferSpeed()]
                state['pbar'] = progressbar.ProgressBar(
                    widgets=widgets, max_value=total_size).start()
            else:
                state['pbar'] = progressbar.ProgressBar(
                    max_value=progressbar.UnknownLength).start()
        downloaded = count * block_size
        pbar = state['pbar']
        max_value = getattr(pbar, 'max_value', None)
        if isinstance(max_value, (int, float)) and downloaded > max_value:
            downloaded = max_value
        try:
            pbar.update(downloaded)
        except Exception:
            pass

    try:
        path, _ = urlretrieve(url, save_path, reporthook=report)
    except Exception:
        if os.path.exists(save_path):
            try:
                os.remove(save_path)
            except OSError:
                pass
        raise
    finally:
        if state['pbar'] is not None:
            try:
                state['pbar'].finish()
            except Exception:
                pass
    return path


def search(lang=''):
    """Search word vectors by language and print/return the matches."""
    datasets = load_datasets()
    if lang:
        rows = datasets.loc[datasets['Language'].str.lower() ==
                            str(lang).lower()]
    else:
        rows = datasets
    rows = rows[DISPLAY_COLUMNS]
    print(rows)
    return rows
