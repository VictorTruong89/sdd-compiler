import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))

import pandas as pd  # noqa: E402

from stocktrends import indicators  # noqa: E402

df = pd.read_csv(os.path.join(HERE, 'HDFCLIFE.csv'))
df.columns = [c.lower() for c in df.columns]
df = df.iloc[::-1].reset_index(drop=True)  # oldest first

rows = 5

renko = indicators.Renko(df)
print('\n\nRenko box calculation based on periodic close')
renko.brick_size = 2
renko.chart_type = indicators.Renko.PERIOD_CLOSE
data = renko.get_ohlc_data()
print(data.tail(rows))

lb = indicators.LineBreak(df)
print('\n\nLine break chart')
lb.line_number = 3
data = lb.get_ohlc_data()
print(data.tail(rows))

pnf = indicators.PnF(df)
pnf.box_size = 10
pnf.reversal_size = 3
print('\n\nPnF bricks')
data = pnf.get_ohlc_data(source='close')
print(data.tail(rows))

print('\n\nPnF bars')
data = pnf.get_bar_ohlc_data(source='close')
print(data.tail(rows))
