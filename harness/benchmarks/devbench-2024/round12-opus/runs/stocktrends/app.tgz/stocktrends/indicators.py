import numpy as np
import pandas as pd


class Instrument:
    """Base class holding an OHLC DataFrame."""

    ohlc = {'open', 'high', 'low', 'close'}

    UPTREND_CONTINUAL = 0
    UPTREND_REVERSAL = 1
    DOWNTREND_CONTINUAL = 2
    DOWNTREND_REVERSAL = 3

    def __init__(self, df):
        self.odf = df
        self.df = df.copy()
        self.df.columns = [str(c).strip().lower() for c in self.df.columns]
        self._validate_df()

    def _validate_df(self):
        if not self.ohlc.issubset(self.df.columns):
            raise ValueError('DataFrame should have OHLC {} columns'.format(sorted(self.ohlc)))


COLUMNS = ['date', 'open', 'high', 'low', 'close', 'uptrend']


def _up_brick(date, base, size, uptrend=True):
    return [date, base, base + size, base, base + size, uptrend]


def _down_brick(date, base, size, uptrend=False):
    return [date, base, base, base - size, base - size, uptrend]


class Renko(Instrument):
    PERIOD_CLOSE = 1
    PRICE_MOVEMENT = 2

    TREND_CHANGE_DIFF = 2

    brick_size = 1
    chart_type = PERIOD_CLOSE

    def get_ohlc_data(self):
        if self.chart_type == self.PERIOD_CLOSE:
            self.period_close_bricks()
        else:
            self.price_movement_bricks()
        return self.cdf

    def price_movement_bricks(self):
        """Bricks built from intra-period high/low movements."""
        brick_size = self.brick_size
        df = self.df.reset_index(drop=True)
        first = df.iloc[0]
        close = first['close'] // brick_size * brick_size
        data = [[first.get('date'), close - brick_size, close, close - brick_size, close, True]]

        for row in df.itertuples(index=False):
            date = getattr(row, 'date', None)
            uptrend = data[-1][5]
            close_p1 = data[-1][4]
            # Check continuation first, then reversal.
            if uptrend:
                prices = [row.high, row.low]
            else:
                prices = [row.low, row.high]
            for price in prices:
                bricks = int((price - close_p1) / brick_size)
                new = self._make_bricks(date, uptrend, close_p1, bricks)
                if new:
                    data.extend(new)
                    break

        self.cdf = pd.DataFrame(data=data, columns=COLUMNS)
        return self.cdf

    def _make_bricks(self, date, uptrend, close_p1, bricks):
        brick_size = self.brick_size
        data = []
        if uptrend and bricks >= 1:
            for _ in range(bricks):
                data.append(_up_brick(date, close_p1, brick_size, uptrend))
                close_p1 += brick_size
        elif uptrend and bricks <= -self.TREND_CHANGE_DIFF:
            uptrend = not uptrend
            bricks += 1
            close_p1 -= brick_size
            for _ in range(abs(bricks)):
                data.append(_down_brick(date, close_p1, brick_size, uptrend))
                close_p1 -= brick_size
        elif not uptrend and bricks <= -1:
            for _ in range(abs(bricks)):
                data.append(_down_brick(date, close_p1, brick_size, uptrend))
                close_p1 -= brick_size
        elif not uptrend and bricks >= self.TREND_CHANGE_DIFF:
            uptrend = not uptrend
            bricks -= 1
            close_p1 += brick_size
            for _ in range(abs(bricks)):
                data.append(_up_brick(date, close_p1, brick_size, uptrend))
                close_p1 += brick_size
        return data

    def period_close_bricks(self):
        brick_size = self.brick_size
        columns = [c for c in ['date', 'open', 'high', 'low', 'close'] if c in self.df.columns]
        self.df = self.df[columns].reset_index(drop=True)

        first = self.df.iloc[0]
        close = first['close'] // brick_size * brick_size
        data = [[first.get('date'), close - brick_size, close, close - brick_size, close, True]]

        for row in self.df.itertuples(index=False):
            date = getattr(row, 'date', None)
            uptrend = data[-1][5]
            close_p1 = data[-1][4]
            bricks = int((row.close - close_p1) / brick_size)
            data.extend(self._make_bricks(date, uptrend, close_p1, bricks))

        self.cdf = pd.DataFrame(data=data, columns=COLUMNS)
        return self.cdf

    def shift_bricks(self):
        shift = self.df['close'].iloc[-1] - self.cdf['close'].iloc[-1]
        if abs(shift) < self.brick_size:
            return
        step = shift // self.brick_size
        self.cdf[['open', 'high', 'low', 'close']] += step * self.brick_size


class LineBreak(Instrument):
    line_number = 3

    def uptrend_reversal(self, close):
        n = min(self.line_number, len(self.cdf))
        lows = [self.cdf.iloc[i]['low'] for i in range(-1, -n - 1, -1)]
        return close < min(lows)

    def downtrend_reversal(self, close):
        n = min(self.line_number, len(self.cdf))
        highs = [self.cdf.iloc[i]['high'] for i in range(-1, -n - 1, -1)]
        return close > max(highs)

    def get_ohlc_data(self):
        columns = [c for c in ['date', 'open', 'high', 'low', 'close'] if c in self.df.columns]
        self.df = self.df[columns].reset_index(drop=True)
        has_date = 'date' in columns

        rows = []
        index = []
        for i in range(min(self.line_number, len(self.df))):
            r = self.df.iloc[i]
            rows.append([r['date'] if has_date else None,
                         r['open'], r['high'], r['low'], r['close'], True])
            index.append(i)
        self.cdf = pd.DataFrame(rows, columns=COLUMNS)

        for row in self.df.itertuples(index=False):
            close = row.close
            row_p1 = self.cdf.iloc[-1]
            uptrend = bool(row_p1['uptrend'])
            open_p1 = row_p1['open']
            close_p1 = row_p1['close']

            if uptrend and close > close_p1:
                r = [close_p1, close, close_p1, close]
            elif uptrend and self.uptrend_reversal(close):
                uptrend = not uptrend
                r = [open_p1, open_p1, close, close]
            elif not uptrend and close < close_p1:
                r = [close_p1, close_p1, close, close]
            elif not uptrend and self.downtrend_reversal(close):
                uptrend = not uptrend
                r = [open_p1, close, open_p1, close]
            else:
                continue

            date = getattr(row, 'date', None)
            self.cdf.loc[len(self.cdf)] = [date] + r + [uptrend]
            index.append(0)

        self.cdf.insert(0, 'index', index)
        self.cdf['uptrend'] = self.cdf['uptrend'].astype(bool)
        return self.cdf


class PnF(Instrument):
    box_size = 2
    reversal_size = 3

    @property
    def brick_size(self):
        return self.box_size

    def get_state(self, uptrend_p1, bricks):
        state = None
        if uptrend_p1 and bricks > 0:
            state = self.UPTREND_CONTINUAL
        elif uptrend_p1 and bricks * -1 >= self.reversal_size:
            state = self.UPTREND_REVERSAL
        elif not uptrend_p1 and bricks < 0:
            state = self.DOWNTREND_CONTINUAL
        elif not uptrend_p1 and bricks >= self.reversal_size:
            state = self.DOWNTREND_REVERSAL
        return state

    def roundit(self, x, base=5):
        return int(base * round(float(x) / base))

    def get_ohlc_data(self, source='close'):
        source = source.lower()
        if source not in ('close', 'hl'):
            raise ValueError("source should be 'close' or 'hl'")
        box_size = self.box_size
        df = self.df.reset_index(drop=True)

        uptrend_p1 = True
        if source == 'close':
            open_ = self.roundit(df.iloc[0]['open'], base=box_size)
        else:
            open_ = self.roundit(df.iloc[0]['low'], base=box_size)
        pnf_data = [[None, open_, open_, open_, open_, True]]

        for row in df.itertuples(index=False):
            date = getattr(row, 'date', None)
            close_p1 = pnf_data[-1][4]

            if source == 'close':
                candidates = [row.close]
            elif uptrend_p1:
                candidates = [row.high, row.low]
            else:
                candidates = [row.low, row.high]

            state = None
            for price in candidates:
                bricks = int((price - close_p1) / box_size)
                state = self.get_state(uptrend_p1, bricks)
                if state is not None:
                    break
            if state is None:
                continue

            day_data = []
            if state == self.UPTREND_CONTINUAL:
                for _ in range(bricks):
                    day_data.append(_up_brick(date, close_p1, box_size, uptrend_p1))
                    close_p1 += box_size
            elif state == self.UPTREND_REVERSAL:
                uptrend_p1 = not uptrend_p1
                bricks += 1
                close_p1 -= box_size
                for _ in range(abs(bricks)):
                    day_data.append(_down_brick(date, close_p1, box_size, uptrend_p1))
                    close_p1 -= box_size
            elif state == self.DOWNTREND_CONTINUAL:
                for _ in range(abs(bricks)):
                    day_data.append(_down_brick(date, close_p1, box_size, uptrend_p1))
                    close_p1 -= box_size
            elif state == self.DOWNTREND_REVERSAL:
                uptrend_p1 = not uptrend_p1
                bricks -= 1
                close_p1 += box_size
                for _ in range(abs(bricks)):
                    day_data.append(_up_brick(date, close_p1, box_size, uptrend_p1))
                    close_p1 += box_size

            pnf_data.extend(day_data)

        return pd.DataFrame(pnf_data[1:], columns=COLUMNS)

    def get_bar_ohlc_data(self, source='close'):
        """Collapse consecutive same-trend boxes into one bar (a PnF column)."""
        df = self.get_ohlc_data(source=source)
        if df.empty:
            return pd.DataFrame(columns=COLUMNS)

        group = df['uptrend'].ne(df['uptrend'].shift()).cumsum()
        bars = []
        for _, g in df.groupby(group, sort=False):
            uptrend = bool(g['uptrend'].iloc[0])
            open_ = g['open'].iloc[0]
            close = g['close'].iloc[-1]
            bars.append([g['date'].iloc[-1], open_, max(open_, close), min(open_, close), close, uptrend])
        return pd.DataFrame(bars, columns=COLUMNS)
