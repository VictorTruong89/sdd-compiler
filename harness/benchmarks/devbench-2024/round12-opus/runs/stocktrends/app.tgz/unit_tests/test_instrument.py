import os

import pandas as pd
import pytest

from stocktrends import indicators

HERE = os.path.dirname(os.path.abspath(__file__))


def test_lowercases_columns():
    df = pd.read_csv(os.path.join(HERE, 'HDFCLIFE.csv'))
    inst = indicators.Instrument(df)
    assert {'date', 'open', 'high', 'low', 'close'}.issubset(inst.df.columns)
    assert inst.odf is df


def test_missing_columns():
    with pytest.raises(ValueError):
        indicators.Instrument(pd.DataFrame({'open': [1], 'close': [2]}))
