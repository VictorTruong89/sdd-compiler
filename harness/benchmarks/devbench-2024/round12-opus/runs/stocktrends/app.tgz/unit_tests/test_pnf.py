import os

import pandas as pd

from stocktrends import indicators

HERE = os.path.dirname(os.path.abspath(__file__))


def test_pnf():
    df = pd.read_csv(os.path.join(HERE, 'HOOLI.csv'))
    pnf = indicators.PnF(df)
    pnf.box_size = 2
    pnf.reversal_size = 3
    assert pnf.brick_size == 2
    data = pnf.get_ohlc_data(source='close')
    assert list(data.columns) == ['date', 'open', 'high', 'low', 'close', 'uptrend']
    assert len(data) > 0
    diffs = (data['close'] - data['open']).abs()
    assert (diffs == 2).all()
    bars = pnf.get_bar_ohlc_data(source='close')
    assert len(bars) <= len(data)
    assert pnf.get_ohlc_data(source='hl').shape[1] == 6


def test_roundit_and_state():
    pnf = indicators.PnF(pd.DataFrame({'open': [1], 'high': [1], 'low': [1], 'close': [1]}))
    assert pnf.roundit(12.4, base=5) == 10
    assert pnf.get_state(True, 1) == pnf.UPTREND_CONTINUAL
    assert pnf.get_state(True, -3) == pnf.UPTREND_REVERSAL
    assert pnf.get_state(False, -1) == pnf.DOWNTREND_CONTINUAL
    assert pnf.get_state(False, 3) == pnf.DOWNTREND_REVERSAL
    assert pnf.get_state(True, -1) is None
