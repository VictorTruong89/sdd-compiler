import os

import pandas as pd

from stocktrends import indicators

HERE = os.path.dirname(os.path.abspath(__file__))


def test_renko_shape():
    df = pd.read_csv(os.path.join(HERE, 'HOOLI.csv'))
    renko = indicators.Renko(df)
    renko.brick_size = 4
    renko.chart_type = indicators.Renko.PERIOD_CLOSE
    data = renko.get_ohlc_data()
    assert data.shape == (215, 6)
    assert list(data.columns) == ['date', 'open', 'high', 'low', 'close', 'uptrend']
