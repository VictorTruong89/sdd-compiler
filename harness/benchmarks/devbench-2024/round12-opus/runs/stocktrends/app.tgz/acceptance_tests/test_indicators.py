import os

import numpy as np
import pandas as pd

from stocktrends import indicators

HERE = os.path.dirname(os.path.abspath(__file__))


def _load(name):
    return pd.read_csv(os.path.join(HERE, name))


def test_renko():
    df = _load('HOOLI.csv')
    renko = indicators.Renko(df)
    renko.brick_size = 4
    renko.chart_type = indicators.Renko.PERIOD_CLOSE
    data = renko.get_ohlc_data()

    expected = _load('hooli_renko_4.csv')
    assert data.shape[0] == expected.shape[0]
    assert np.all(np.abs(data['close'].values - expected['close'].values) <= 1e-12)
    assert list(data['uptrend']) == list(expected['uptrend'])


def test_linebreak():
    df = _load('HOOLI.csv')
    lb = indicators.LineBreak(df)
    lb.line_number = 3
    data = lb.get_ohlc_data()

    expected = _load('hooli_linebreak_3.csv')
    assert data.shape[0] == expected.shape[0]
    assert np.all(np.abs(data['close'].values - expected['close'].values) <= 1e-12)
    assert list(data['uptrend']) == list(expected['uptrend'])
