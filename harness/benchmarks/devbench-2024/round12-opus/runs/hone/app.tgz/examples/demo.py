import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from hone import Hone
from hone.utils import json_utils

HERE = os.path.dirname(os.path.abspath(__file__))

if __name__ == "__main__":
    hone = Hone()
    for name in ("example_a", "example_b", "example_c"):
        csv_filepath = os.path.join(HERE, name + ".csv")
        json_filepath = os.path.join(HERE, name + ".json")
        json_struct = hone.convert(csv_filepath)
        json_utils.output_json(json_struct, json_filepath)
        print("Converted %s -> %s" % (csv_filepath, json_filepath))
    json_utils.output_json(hone.get_schema(os.path.join(HERE, "example_c.csv")))
