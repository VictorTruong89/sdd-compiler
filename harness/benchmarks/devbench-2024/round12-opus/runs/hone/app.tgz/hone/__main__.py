import argparse
import json

from hone.hone import Hone
from hone.utils import json_utils


def parse_args(argv=None):
    parser = argparse.ArgumentParser(
        prog="hone", description="Convert CSV files to nested JSON.")
    parser.add_argument("--delimiters", nargs="*", default=None,
                        help="list of string delimiters used to infer nesting")
    parser.add_argument("--schema", type=json.loads, default=None,
                        help="JSON schema structure for the output JSON")
    parser.add_argument("csv_filepath", help="path to the input CSV file")
    parser.add_argument("json_filepath", nargs="?", default=None,
                        help="path to the output JSON file (stdout if omitted)")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)
    if args.delimiters:
        hone = Hone(args.delimiters)
    else:
        hone = Hone()
    json_struct = hone.convert(args.csv_filepath, args.schema)
    json_utils.output_json(json_struct, args.json_filepath)


if __name__ == "__main__":
    main()
