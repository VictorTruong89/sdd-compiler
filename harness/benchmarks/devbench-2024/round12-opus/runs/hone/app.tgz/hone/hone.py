"""
Convert CSV files to nested JSON structures.
"""

import copy

from hone.utils import csv_utils


class Hone:
    DEFAULT_DELIMITERS = [",", "_", " "]

    def __init__(self, delimiters=None):
        if delimiters is None:
            delimiters = self.DEFAULT_DELIMITERS
        self.delimiters = list(delimiters)
        self.csv_filepath = None
        self.csv = None

    '''
    Convert a CSV file to a nested JSON structure (a list of objects).
    If no schema is given, one is generated from the column names.
    '''

    def convert(self, csv_filepath, schema=None):
        self.set_csv_filepath(csv_filepath)
        column_names = self.csv.get_column_names()
        data_rows = self.csv.get_data_rows()
        if not schema:
            schema = self.generate_full_structure(column_names)
        return self.populate_structure_with_data(schema, column_names, data_rows)

    '''
    Fill copies of the schema structure with values from each data row.
    '''

    def populate_structure_with_data(self, structure, column_names, data_rows):
        paths = {}
        self._get_leaf_paths(structure, [], paths)
        json_struct = []
        for row in data_rows:
            json_row = copy.deepcopy(structure)
            for i, column_name in enumerate(column_names):
                if column_name not in paths or i >= len(row):
                    continue
                for path in paths[column_name]:
                    node = json_row
                    for key in path[:-1]:
                        node = node[key]
                    node[path[-1]] = row[i]
            json_struct.append(json_row)
        return json_struct

    '''
    Generate the nested schema for a CSV file from its column names.
    '''

    def get_schema(self, csv_filepath):
        self.set_csv_filepath(csv_filepath)
        column_names = self.csv.get_column_names()
        return self.generate_full_structure(column_names)

    '''
    Build a nested structure mapping output keys to column names.
    '''

    def generate_full_structure(self, column_names):
        return self._build_structure({c: c for c in column_names})

    '''
    Recursively nest a flat {key: column_name} structure.
    '''

    def get_nested_structure(self, parent_structure):
        return self._build_structure(parent_structure)

    def _build_structure(self, mapping):
        keys = list(mapping.keys())[::-1]
        visited = set()
        structure = {}
        for k1 in keys:
            if k1 in visited:
                continue
            for split in self.get_valid_splits(k1):
                if split in mapping:
                    continue
                nodes = {}
                for k2 in keys:
                    if k2 not in visited and self.is_valid_prefix(split, k2):
                        nodes[self.get_split_suffix(split, k2)] = k2
                if len(nodes) > 1:
                    structure[split] = self._build_structure(
                        {suffix: mapping[k] for suffix, k in nodes.items()})
                    visited.update(nodes.values())
                    break
            if k1 not in visited:
                structure[k1] = mapping[k1]
                visited.add(k1)
        return structure

    '''
    Map each leaf (column name) to the path of keys that reaches it,
    expressed as a string of subscripts, e.g. '["birth"]["day"]'.
    '''

    def get_leaves(self, structure, path="", result=None):
        if result is None:
            result = {}
        for key, value in structure.items():
            key_path = '%s["%s"]' % (path, self.escape_quotes(key))
            if isinstance(value, dict):
                self.get_leaves(value, key_path, result)
            else:
                result[value] = key_path
        return result

    def _get_leaf_paths(self, structure, path, result):
        for key, value in structure.items():
            key_path = path + [key]
            if isinstance(value, dict):
                self._get_leaf_paths(value, key_path, result)
            else:
                result.setdefault(value, []).append(key_path)
        return result

    '''
    Return all candidate prefixes of a column name, split on delimiters,
    shortest first.
    '''

    def get_valid_splits(self, column_name):
        splits = set()
        for i, c in enumerate(column_name):
            if c in self.delimiters:
                split = self.clean_split(column_name[:i])
                if split:
                    splits.add(split)
        return sorted(splits, key=lambda s: (len(s), s))

    '''
    Return the part of the column name following the split prefix,
    without leading delimiters.
    '''

    def get_split_suffix(self, split, column_name=""):
        suffix = column_name[len(split):]
        i = 0
        while i < len(suffix) and suffix[i] in self.delimiters:
            i += 1
        return suffix[i:]

    '''
    Strip delimiters from both ends of a split.
    '''

    def clean_split(self, split):
        start, end = 0, len(split)
        while start < end and split[start] in self.delimiters:
            start += 1
        while end > start and split[end - 1] in self.delimiters:
            end -= 1
        return split[start:end]

    '''
    Whether prefix is a delimiter-bounded prefix of base.
    '''

    def is_valid_prefix(self, prefix, base):
        if not prefix or not base.startswith(prefix):
            return False
        if len(base) == len(prefix):
            return False
        return base[len(prefix)] in self.delimiters

    def set_csv_filepath(self, csv_filepath):
        self.csv_filepath = csv_filepath
        self.csv = csv_utils.CSVUtils(csv_filepath)

    def escape_quotes(self, string):
        return string.replace('\\', '\\\\').replace('"', '\\"')
