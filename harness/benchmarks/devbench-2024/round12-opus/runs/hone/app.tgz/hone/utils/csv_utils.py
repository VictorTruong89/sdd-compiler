"""
Methods for reading and processing CSV files.
"""

import csv
import contextlib


class CSVUtils:
    def __init__(self, csv_filepath):
        self.filepath = csv_filepath

    '''
    Return the column names (first row) of the CSV file.
    '''

    def get_column_names(self):
        with self.open_csv() as f:
            for row in csv.reader(f):
                return row
        return []

    '''
    Return all data rows (every row after the header) of the CSV file.
    '''

    def get_data_rows(self):
        with self.open_csv() as f:
            rows = list(csv.reader(f))
        return rows[1:]

    '''
    Context manager for opening the CSV file.
    '''

    @contextlib.contextmanager
    def open_csv(self, mode="r", newline=""):
        f = open(self.filepath, mode, newline=newline)
        try:
            yield f
        finally:
            f.close()
