"""
Methods for writing JSON structures to files or stdout.
"""

import sys
import json
import contextlib


@contextlib.contextmanager
def open_json(json_filepath=None, mode="w"):
    if json_filepath is None or json_filepath == "-":
        yield sys.stdout
    else:
        f = open(json_filepath, mode)
        try:
            yield f
        finally:
            f.close()


'''
Write a JSON structure to the given file, or to stdout if no file is given.
'''


def output_json(json_struct, json_filepath=None):
    with open_json(json_filepath) as f:
        json.dump(json_struct, f, indent=2, sort_keys=True)
        f.write("\n")
