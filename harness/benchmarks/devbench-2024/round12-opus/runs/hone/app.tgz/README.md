# Hone

Convert CSV files into nested JSON.

```python
from hone import Hone
Hone().convert("data.csv")          # schema inferred from column names
Hone([" "]).convert("data.csv", schema)  # custom delimiters / schema
```

Columns sharing a delimiter-separated prefix (e.g. `birth day`, `birth month`) are nested
under that prefix (`{"birth": {"day": ..., "month": ...}}`). Default delimiters: `,`, `_`, space.

CLI:

```bash
python -m hone [--delimiters , _ ' '] [--schema '{"a": "col"}'] input.csv [output.json]
```

If the output path is omitted, JSON is written to stdout.
