#! /bin/bash
set -e

# source /path/to/your/venv/bin/activate
python lice/core.py

python lice/core.py mit

python lice/core.py -y $(date +"%Y") -o "Your Organization Name"

python lice/core.py -l py > LICENSE.txt

# Run tests
python -m unittest discover -s ./lice/tests -p 'test_*.py'
