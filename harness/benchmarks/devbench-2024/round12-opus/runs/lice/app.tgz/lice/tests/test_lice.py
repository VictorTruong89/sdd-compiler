import os
import unittest

from lice.core import (
    LICENSES, LANGS, LANG_CMT, extract_vars, format_license,
    generate_license, get_suffix, load_file_template, load_template,
)

TEMPLATES_DIR = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "..", "..", "templates")
CONTEXT = {"year": "1981", "organization": "Awesome Co.", "project": "X"}


class TestLice(unittest.TestCase):

    def test_licenses_found(self):
        self.assertIn("mit", LICENSES)
        self.assertIn("bsd3", LICENSES)

    def test_file_template(self):
        for lic in LICENSES:
            path = os.path.join(TEMPLATES_DIR, "template-%s.txt" % lic)
            with open(path, encoding="utf-8") as infile:
                self.assertEqual(infile.read(),
                                 load_file_template(path).getvalue())

    def test_generate_license(self):
        for lic in LICENSES:
            out = generate_license(load_template(lic), CONTEXT).getvalue()
            self.assertNotIn("{{", out)

    def test_extract_vars(self):
        self.assertEqual(extract_vars(load_template("mit")),
                         ["organization", "year"])

    def test_format_license(self):
        for ext, cmt in LANGS.items():
            out = format_license(generate_license(load_template("mit"),
                                                  CONTEXT), ext).getvalue()
            lines = out.splitlines()
            self.assertEqual(lines[0], LANG_CMT[cmt][0])
            self.assertEqual(lines[-1], LANG_CMT[cmt][2])

    def test_get_suffix(self):
        self.assertEqual(get_suffix("a.py"), "py")
        self.assertFalse(get_suffix("LICENSE"))
        self.assertFalse(get_suffix("a.xyz"))


if __name__ == "__main__":
    unittest.main()
