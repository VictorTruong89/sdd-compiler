"""Core functionality of the lice license generator."""

from io import StringIO
import argparse
import datetime
import getpass
import os
import re
import subprocess
import sys

PACKAGE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_DIRS = [
    PACKAGE_DIR,
    os.path.join(PACKAGE_DIR, "templates"),
    os.path.join(os.path.dirname(PACKAGE_DIR), "templates"),
]


def _find_licenses():
    found = set()
    for directory in TEMPLATE_DIRS:
        if not os.path.isdir(directory):
            continue
        for name in os.listdir(directory):
            match = re.match(r"^template-([a-z0-9_]+)\.txt$", name)
            if match:
                found.add(match.group(1))
    return sorted(found)


LICENSES = _find_licenses()

DEFAULT_LICENSE = "bsd3"

# To extend language formatting support with a new language, add an item in
# LANGS dict:
#   "language_suffix": "comment_name"
# where "comment_name" is one of the comment types listed in LANG_CMT.
# A comment type is [opening string, line prefix, closing string].
LANGS = {
    "agda": "haskell",
    "c": "c",
    "cc": "c",
    "clj": "lisp",
    "cpp": "c",
    "css": "c",
    "el": "lisp",
    "erl": "erlang",
    "f": "fortran",
    "f90": "fortran90",
    "h": "c",
    "hpp": "c",
    "hs": "haskell",
    "html": "html",
    "idr": "haskell",
    "java": "java",
    "js": "c",
    "lisp": "lisp",
    "lua": "lua",
    "m": "c",
    "ml": "ml",
    "php": "c",
    "pl": "perl",
    "py": "unix",
    "ps": "powershell",
    "rb": "ruby",
    "scm": "lisp",
    "sh": "unix",
    "txt": "text",
    "rs": "rust",
}

LANG_CMT = {
    "c": [u'/*', u' *', u' */'],
    "erlang": [u'%%', u'%', u'%%'],
    "fortran": [u'C', u'C', u'C'],
    "fortran90": [u'!*', u'!*', u'!*'],
    "haskell": [u'{-', u'', u'-}'],
    "html": [u'<!--', u'', u'-->'],
    "java": [u'/**', u' *', u' */'],
    "lisp": [u'', u';;', u''],
    "lua": [u'--[[', u'', u'--]]'],
    "ml": [u'(*', u'', u'*)'],
    "perl": [u'=item', u'', u'=cut'],
    "powershell": [u'<#', u'#', u'#>'],
    "ruby": [u'=begin', u'', u'=end'],
    "text": [u'', u'', u''],
    "unix": [u'', u'#', u''],
    "rust": [u'', u'//', u''],
}


def clean_path(p):
    """Clean a path by expanding user and environment variables and
    ensuring an absolute path.
    """
    p = os.path.expanduser(p)
    p = os.path.expandvars(p)
    p = os.path.abspath(p)
    return p


def get_context(args):
    return {
        "year": args.year,
        "organization": args.organization,
        "project": args.project,
    }


def guess_organization():
    """Guess the organization from `git config`. If that can't be found,
    fall back to the $USER environment variable.
    """
    try:
        stdout = subprocess.check_output(
            'git config --get user.name'.split(), stderr=subprocess.DEVNULL)
        org = stdout.strip().decode("UTF-8")
        if not org:
            raise ValueError("empty git user.name")
    except Exception:
        try:
            org = getpass.getuser()
        except Exception:
            org = os.environ.get("USER", "")
    return org


def load_file_template(path):
    """Load template from the specified filesystem path."""
    template = StringIO()
    if not os.path.exists(path):
        raise ValueError("path does not exist: %s" % path)
    with open(clean_path(path), "rb") as infile:
        for line in infile:
            template.write(line.decode("utf-8"))
    return template


def _template_path(filename):
    for directory in TEMPLATE_DIRS:
        path = os.path.join(directory, filename)
        if os.path.isfile(path):
            return path
    raise IOError("template not found: %s" % filename)


def load_template(license, header=False):
    """Load license template distributed with the package."""
    content = StringIO()
    filename = 'template-%s-header.txt' if header else 'template-%s.txt'
    with open(_template_path(filename % license), "rb") as licfile:
        for line in licfile:
            content.write(line.decode("utf-8"))
    return content


load_package_template = load_template


def extract_vars(template):
    """Extract variables from template. Variables are enclosed in
    double curly braces.
    """
    keys = set()
    for match in re.finditer(r"\{\{ (?P<key>\w+) \}\}", template.getvalue()):
        keys.add(match.group("key"))
    return sorted(keys)


def generate_license(template, context):
    """Generate a license by replacing the template variables with the
    corresponding values in the given context.
    """
    out = StringIO()
    content = template.getvalue()
    for key in extract_vars(template):
        if key not in context:
            raise ValueError("%s is missing from the template context" % key)
        content = content.replace("{{ %s }}" % key, context[key])
    template.close()
    out.write(content)
    return out


def format_license(template, lang):
    """Format the StringIO template for the specified language and return
    a new formatted StringIO object.
    """
    if not lang:
        lang = 'txt'
    out = StringIO()
    template.seek(0)
    cmt = LANG_CMT[LANGS[lang]]
    out.write(cmt[0] + u'\n')
    for line in template.readlines():
        out.write(cmt[1] + u' ')
        out.write(line)
    out.write(cmt[2] + u'\n')
    template.close()
    return out


def get_suffix(name):
    """Return the file name suffix if it is a known language, else False."""
    if name.count("."):
        ext = name.split(".")[-1]
        if ext in LANGS:
            return ext
    return False


def main():
    def valid_year(string):
        if not re.match(r"^\d{4}$", string):
            raise argparse.ArgumentTypeError("Must be a four digit year")
        return string

    parser = argparse.ArgumentParser(description='Generate a license')

    parser.add_argument(
        'license', metavar='license', nargs="?", choices=LICENSES,
        help='the license to generate, one of: %s' % ", ".join(LICENSES))
    parser.add_argument(
        '--header', dest='header', action="store_true",
        help='generate source file header for specified license')
    parser.add_argument(
        '-o', '--org', dest='organization', default=None,
        help='organization, defaults to .gitconfig or os.environ["USER"]')
    parser.add_argument(
        '-p', '--proj', dest='project', default=os.getcwd().split(os.sep)[-1],
        help='name of project, defaults to name of current directory')
    parser.add_argument(
        '-t', '--template', dest='template_path',
        help='path to license template file')
    parser.add_argument(
        '-y', '--year', dest='year', type=valid_year,
        default="%i" % datetime.date.today().year, help='copyright year')
    parser.add_argument(
        '-l', '--language', dest='language',
        help='format output for language source file, one of: %s '
             '[default is not formatted (txt)]' % ", ".join(LANGS.keys()))
    parser.add_argument(
        '-f', '--file', dest='ofile', default='stdout',
        help='Name of the output source file (with -l, extension can be '
             'omitted)')
    parser.add_argument(
        '--vars', dest='list_vars', action="store_true",
        help='list template variables for specified license')
    parser.add_argument(
        '--licenses', dest='list_licenses', action="store_true",
        help='list available license templates and their parameters')
    parser.add_argument(
        '--languages', dest='list_languages', action="store_true",
        help='list available source code formatting languages')

    args = parser.parse_args()
    if args.organization is None:
        args.organization = guess_organization()

    license = args.license or DEFAULT_LICENSE

    lang = args.language
    if lang and lang not in LANGS:
        sys.stderr.write("I do not know about a language ending with "
                         "extension %s.\n"
                         "Please send a pull request adding this language to\n"
                         "https://github.com/licenses/lice. Thanks!\n" % lang)
        sys.exit(1)

    # generate header if requested
    if args.header:
        if args.template_path:
            template = load_file_template(args.template_path)
        else:
            try:
                template = load_template(license, header=True)
            except IOError:
                sys.stderr.write(
                    "Sorry, no source headers are available for %s.\n" %
                    license)
                sys.exit(1)

        content = generate_license(template, get_context(args))
        out = format_license(content, lang)
        sys.stdout.write(out.getvalue())
        out.close()
        sys.exit(0)

    # list template vars if requested
    if args.list_vars:
        context = get_context(args)
        if args.template_path:
            template = load_file_template(args.template_path)
        else:
            template = load_template(license)
        var_list = extract_vars(template)
        name = args.template_path or license
        if var_list:
            sys.stdout.write(
                "The %s license template contains the following variables "
                "and defaults:\n" % name)
            for v in var_list:
                if v in context:
                    sys.stdout.write("  %s = %s\n" % (v, context[v]))
                else:
                    sys.stdout.write("  %s\n" % v)
        else:
            sys.stdout.write(
                "The %s license template contains no variables.\n" % name)
        sys.exit(0)

    # list available licenses and their template variables
    if args.list_licenses:
        for lic in LICENSES:
            template = load_template(lic)
            var_list = extract_vars(template)
            sys.stdout.write("%s : %s\n" % (lic, ", ".join(var_list)))
        sys.exit(0)

    # list available source formatting languages
    if args.list_languages:
        for lng in sorted(LANGS.keys()):
            sys.stdout.write("%s\n" % lng)
        sys.exit(0)

    if args.template_path:
        template = load_file_template(args.template_path)
    else:
        template = load_template(license)

    content = generate_license(template, get_context(args))

    if args.ofile != "stdout":
        ext = get_suffix(args.ofile)
        if ext:
            output = args.ofile
            out = format_license(content, ext)
        else:
            if lang:
                output = "%s.%s" % (args.ofile, lang)
            else:
                output = args.ofile
            out = format_license(content, lang)

        with open(output, "w") as f:
            f.write(out.getvalue())
    else:
        out = format_license(content, lang)
        sys.stdout.write(out.getvalue())
    out.close()


if __name__ == "__main__":
    main()
