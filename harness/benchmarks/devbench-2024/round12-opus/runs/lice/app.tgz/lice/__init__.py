from lice.core import main

__version__ = "0.6"

__all__ = ["main", "__version__"]
