import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

from geotext import GeoText

places = GeoText("London is a great city")
print(places.cities)

print(GeoText('New York, Texas, and also China').country_mentions)
print(GeoText('I have been to Berlin and Paris, France', 'FR').cities)
