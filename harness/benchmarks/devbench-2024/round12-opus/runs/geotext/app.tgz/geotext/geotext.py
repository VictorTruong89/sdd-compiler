# -*- coding: utf-8 -*-

import io
import os
import re
from collections import namedtuple, Counter, OrderedDict

_ROOT = os.path.abspath(os.path.dirname(__file__))


def get_data_path(path):
    return os.path.join(_ROOT, 'data_file', path)


def read_table(filename, usecols=(0, 1), sep='\t', comment='#',
               encoding='utf-8', skip=0):
    """Parse data files from the data directory

    Parameters
    ----------
    filename: string
        Full path to file
    usecols: list, default [0, 1]
        A list of two elements representing the columns to be parsed into a
        dictionary. The first element will be used as keys and the second as
        values. Defaults to the first two columns of `filename`.
    sep : string, default '\\t'
        Field delimiter.
    comment : str, default '#'
        Indicates remainder of line should not be parsed. If found at the
        beginning of a line, the line will be ignored altogether.
    encoding : string, default 'utf-8'
        Encoding to use for UTF when reading/writing (ex. `utf-8`)
    skip: int, default 0
        Number of lines to skip at the beginning of the file

    Returns
    -------
    A dictionary with the same length as the number of lines in `filename`
    """
    with io.open(filename, 'r', encoding=encoding) as f:
        # skip initial lines
        for _ in range(skip):
            next(f)

        # filter comment lines
        lines = (line for line in f if not line.startswith(comment))

        d = dict()
        for line in lines:
            columns = line.split(sep)
            key = columns[usecols[0]].lower()
            value = columns[usecols[1]].rstrip('\n')
            d[key] = value
    return d


def build_index():
    """Load information from the data directory

    Returns
    -------
    A namedtuple with three fields: nationalities cities countries
    """
    nationalities = read_table(get_data_path('nationalities.txt'), sep=':')

    # parse http://download.geonames.org/export/dump/countryInfo.txt
    countries = read_table(
        get_data_path('countryInfo.txt'), usecols=[4, 0], skip=1)

    # parse http://download.geonames.org/export/dump/cities15000.zip
    cities = read_table(get_data_path('cities15000.txt'), usecols=[1, 8])

    # load and apply city patches
    city_patches = read_table(get_data_path('citypatches.txt'))
    cities.update(city_patches)

    Index = namedtuple('Index', 'nationalities cities countries')
    return Index(nationalities, cities, countries)


class GeoText(object):
    """Extract cities and countries from a text

    Examples
    --------
    >>> places = GeoText("London is a great city")
    >>> places.cities
    ['London']

    >>> GeoText('New York, Texas, and also China').country_mentions
    OrderedDict([('US', 2), ('CN', 1)])
    """

    index = build_index()

    def __init__(self, text, country=None):
        self.text = text
        self.country = country
        self.city_regex = (r"[A-ZÀ-Ú]+[a-zà-ú]+[ \-]?(?:d[a-u].)?"
                           r"(?:[A-ZÀ-Ú]+[a-zà-ú]+)*")
        candidates = self._find_candidates(text)
        self.countries = self._extract_countries(candidates)
        self.cities = self._extract_cities(candidates, country)
        self.nationalities = self._extract_nationalities(candidates)
        self.country_mentions = self._calculate_country_mentions()

    def _find_candidates(self, text):
        candidates = re.findall(self.city_regex, text)
        # remove surrounding white spaces from candidates
        return [candidate.strip() for candidate in candidates]

    def _extract_countries(self, candidates):
        return [each for each in candidates
                if each.lower() in self.index.countries]

    def _extract_cities(self, candidates, country=None):
        cities = [each for each in candidates
                  if each.lower() in self.index.cities
                  # country names are not considered cities
                  and each.lower() not in self.index.countries]
        if country is not None:
            cities = [city for city in cities
                      if self.index.cities[city.lower()] == country]
        return cities

    def _extract_nationalities(self, candidates):
        return [each for each in candidates
                if each.lower() in self.index.nationalities]

    def _calculate_country_mentions(self):
        mentions = [self.index.countries[c.lower()] for c in self.countries]
        mentions.extend(self.index.cities[c.lower()] for c in self.cities)
        mentions.extend(self.index.nationalities[n.lower()]
                        for n in self.nationalities)
        return OrderedDict(Counter(mentions).most_common())


if __name__ == '__main__':
    print(GeoText('In a filing with the Hong Kong bourse, the Chinese cement '
                  'producer said ...').countries)
