mkdir -p outputs
python query_arxiv.py \
--category cs.CL \
--title LLM \
--author Smith \
--abstract Deep+Learning \
--recent_days 10 \
--to_file outputs/query_all_results.csv \
--verbose \
>> outputs/query_all_results.txt
