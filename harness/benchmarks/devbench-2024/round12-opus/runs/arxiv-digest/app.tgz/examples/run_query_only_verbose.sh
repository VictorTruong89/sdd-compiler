mkdir -p outputs
python query_arxiv.py \
--category cs.CL \
--title LLM \
--author Smith \
--abstract Deep+Learning \
--recent_days 10 \
--verbose \
>> outputs/query_only_verbose_results.txt
