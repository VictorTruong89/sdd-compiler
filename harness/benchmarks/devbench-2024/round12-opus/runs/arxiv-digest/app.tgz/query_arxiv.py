"""Query the ArXiv API with advanced search options and recent-days filtering."""
import argparse
import csv
import os
import sys
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional

BASE_URL = "http://export.arxiv.org/api/query"
ALLOWED_CHARS = set(
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+:."
)
NAMESPACE = {
    "atom": "http://www.w3.org/2005/Atom",
    "arxiv": "http://arxiv.org/schemas/atom",
}
CSV_FIELDS = ["category", "title", "author", "abstract", "published", "link"]
ABSTRACT_PREVIEW_LEN = 300


def _validate(name: str, value) -> None:
    if value is None:
        return
    value = str(value)
    bad = [c for c in value if c not in ALLOWED_CHARS]
    if bad or value == "":
        raise ValueError(
            f"Invalid character(s) {''.join(sorted(set(bad)))!r} in argument "
            f"'{name}': only letters, digits and '+:.' are allowed."
        )


def get_args(argv=None) -> argparse.Namespace:
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Query ArXiv papers by category, title, author and abstract."
    )
    parser.add_argument("--category", type=str, default=None, help="Category of the paper (e.g. cs.CL).")
    parser.add_argument("--title", type=str, default=None, help="Keyword for the title.")
    parser.add_argument("--author", type=str, default=None, help="Keyword for the author.")
    parser.add_argument("--abstract", type=str, default=None, help="Keyword in the abstract.")
    parser.add_argument("--recent_days", type=int, required=True, help="Only keep papers from the most recent k days.")
    parser.add_argument("--max_results", type=int, default=10, help="Maximum number of results to fetch (default: 10).")
    parser.add_argument("--to_file", type=str, default=None, help="Path to save the results in CSV format.")
    parser.add_argument("--verbose", action="store_true", help="Print results to the console.")
    args = parser.parse_args(argv)

    if not any([args.category, args.title, args.author, args.abstract]):
        raise ValueError(
            "At least one of --category, --title, --author, --abstract must be specified."
        )
    for name in ("category", "title", "author", "abstract"):
        _validate(name, getattr(args, name))
    return args


def construct_query_url(
    category: str = None,
    title: str = None,
    author: str = None,
    abstract: str = None,
    max_results: int = 10,
) -> str:
    """Build the ArXiv API query URL sorted by submission date (descending)."""
    parts = []
    for prefix, name, value in (
        ("cat", "category", category),
        ("au", "author", author),
        ("ti", "title", title),
        ("abs", "abstract", abstract),
    ):
        if value is None or value == "":
            continue
        _validate(name, value)
        parts.append(f"{prefix}:{value}")
    if not parts:
        raise ValueError(
            "At least one of category, title, author, abstract must be specified."
        )
    search_query = "+AND+".join(parts)
    return (
        f"{BASE_URL}?search_query={search_query}"
        f"&sortBy=submittedDate&sortOrder=descending"
        f"&start=0&max_results={max_results}"
    )


def fetch_data(query_url: str) -> bytes:
    """Send a GET request to the ArXiv API and return the raw response body."""
    response = urllib.request.urlopen(query_url)
    data = response.read()
    if not isinstance(data, (bytes, str)) and hasattr(response, "__enter__"):
        with response as ctx:
            data = ctx.read()
    else:
        close = getattr(response, "close", None)
        if callable(close):
            close()
    return data


def _parse_date(date_string: str) -> datetime:
    s = date_string.strip()
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(s)
    except ValueError:
        dt = datetime.strptime(s[:10], "%Y-%m-%d")
    return dt


def check_date(date_string: str, recent_days: int, current_date: datetime) -> bool:
    """Return True if date_string is within recent_days days of current_date."""
    published = _parse_date(date_string)
    if published.tzinfo is not None and current_date.tzinfo is None:
        published = published.astimezone(timezone.utc).replace(tzinfo=None)
    elif published.tzinfo is None and current_date.tzinfo is not None:
        published = published.replace(tzinfo=timezone.utc)
    return current_date - published <= timedelta(days=recent_days)


def _q(namespace: Dict[str, str], tag: str) -> str:
    """Build a qualified tag name for the Atom namespace."""
    uri = (namespace or {}).get("atom", NAMESPACE["atom"])
    return f"{{{uri}}}{tag}"


def _text(element: Optional[ET.Element]) -> str:
    if element is None or element.text is None:
        return ""
    return " ".join(element.text.split())


def process_entries(
    entries: List[ET.Element],
    namespace: Dict[str, str],
    current_date: datetime,
    recent_days: int,
) -> List[Dict[str, str]]:
    """Convert ArXiv Atom entries to dicts, keeping only recent papers."""
    papers = []
    for entry in entries:
        published = _text(entry.find(_q(namespace, "published")))
        if not published or not check_date(published, recent_days, current_date):
            continue
        categories = [
            c.get("term") for c in entry.findall(_q(namespace, "category")) if c.get("term")
        ]
        if not categories:
            arxiv_uri = (namespace or {}).get("arxiv", NAMESPACE["arxiv"])
            primary = entry.find(f"{{{arxiv_uri}}}primary_category")
            if primary is not None and primary.get("term"):
                categories = [primary.get("term")]
        authors = [
            _text(a.find(_q(namespace, "name")))
            for a in entry.findall(_q(namespace, "author"))
        ]
        link = _text(entry.find(_q(namespace, "id")))
        if not link:
            for l in entry.findall(_q(namespace, "link")):
                if l.get("href") and l.get("rel", "alternate") == "alternate":
                    link = l.get("href")
                    break
        papers.append(
            {
                "category": ", ".join(categories),
                "title": _text(entry.find(_q(namespace, "title"))),
                "author": ", ".join(a for a in authors if a),
                "abstract": _text(entry.find(_q(namespace, "summary"))),
                "published": published,
                "link": link,
            }
        )
    return papers


def save_to_csv(papers: List[Dict[str, str]], file_name: str) -> None:
    """Save papers to a CSV file, creating parent directories if needed."""
    directory = os.path.dirname(file_name)
    if directory:
        os.makedirs(directory, exist_ok=True)
    with open(file_name, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_FIELDS, extrasaction="ignore")
        writer.writeheader()
        for paper in papers:
            writer.writerow({k: paper.get(k, "") for k in CSV_FIELDS})


def print_results(papers: List[Dict[str, str]]) -> None:
    """Print papers to the console with truncated abstracts."""
    if not papers:
        print("No papers found.")
        return
    for i, paper in enumerate(papers, 1):
        abstract = paper.get("abstract", "")
        if len(abstract) > ABSTRACT_PREVIEW_LEN:
            abstract = abstract[:ABSTRACT_PREVIEW_LEN].rstrip() + "..."
        print(f"[{i}] Title: {paper.get('title', '')}")
        print(f"    Category: {paper.get('category', '')}")
        print(f"    Author: {paper.get('author', '')}")
        print(f"    Published: {paper.get('published', '')}")
        print(f"    Link: {paper.get('link', '')}")
        print(f"    Abstract: {abstract}")
        print("-" * 80)


def main(argv=None) -> None:
    args = get_args(argv)
    query_url = construct_query_url(
        category=args.category,
        title=args.title,
        author=args.author,
        abstract=args.abstract,
        max_results=args.max_results,
    )
    data = fetch_data(query_url)
    root = ET.fromstring(data)
    entries = root.findall("atom:entry", NAMESPACE)
    current_date = datetime.now(timezone.utc)
    papers = process_entries(entries, NAMESPACE, current_date, args.recent_days)

    if args.to_file:
        save_to_csv(papers, args.to_file)
        if args.verbose:
            print_results(papers)
    else:
        print_results(papers)


if __name__ == "__main__":
    main()
