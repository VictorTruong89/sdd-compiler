import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

from pso import pso_simple
from pso.cost_functions import sphere

if __name__ == '__main__':
    initial = [5, 5]                # initial starting location [x1, x2...]
    bounds = [(-10, 10), (-10, 10)]  # input bounds [(x1_min, x1_max), ...]
    pso_simple.minimize(sphere, initial, bounds, num_particles=15, maxiter=30, verbose=True)
