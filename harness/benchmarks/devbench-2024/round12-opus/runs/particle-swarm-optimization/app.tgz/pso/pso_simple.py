"""A minimal Particle Swarm Optimization (PSO) implementation."""

from random import random, uniform

# number of dimensions of the current problem (set by minimize)
num_dimensions = None

# PSO coefficients
W = 0.5   # inertia weight
C1 = 1    # cognitive constant
C2 = 2    # social constant


class Particle:
    def __init__(self, x0):
        self.position_i = []    # particle position
        self.velocity_i = []    # particle velocity
        self.pos_best_i = []    # best position individual
        self.err_best_i = -1    # best error individual
        self.err_i = -1         # error individual

        for xi in x0:
            self.velocity_i.append(uniform(-1, 1))
            self.position_i.append(xi)

    def evaluate(self, costFunc):
        """Evaluate current fitness and update the individual best."""
        self.err_i = costFunc(self.position_i)
        if self.err_i < self.err_best_i or self.err_best_i == -1:
            self.pos_best_i = list(self.position_i)
            self.err_best_i = self.err_i

    def update_velocity(self, pos_best_g):
        """Update particle velocity using the global best position."""
        for i in range(len(self.position_i)):
            r1 = random()
            r2 = random()
            vel_cognitive = C1 * r1 * (self.pos_best_i[i] - self.position_i[i])
            vel_social = C2 * r2 * (pos_best_g[i] - self.position_i[i])
            self.velocity_i[i] = W * self.velocity_i[i] + vel_cognitive + vel_social

    def update_position(self, bounds):
        """Move the particle according to its velocity, clamped to bounds."""
        for i in range(len(self.position_i)):
            self.position_i[i] = self.position_i[i] + self.velocity_i[i]
            lo, hi = bounds[i][0], bounds[i][1]
            if self.position_i[i] > hi:
                self.position_i[i] = hi
            if self.position_i[i] < lo:
                self.position_i[i] = lo


def minimize(costFunc, x0, bounds, num_particles, maxiter, verbose=False):
    """Minimize costFunc with PSO. Returns (err_best_g, pos_best_g)."""
    global num_dimensions
    num_dimensions = len(x0)

    err_best_g = -1     # best error for group
    pos_best_g = []     # best position for group

    swarm = [Particle(x0) for _ in range(num_particles)]

    i = 0
    while i < maxiter:
        if verbose:
            print(f'iter: {i:>4d}, best solution: {err_best_g:10.6f}')

        # evaluate fitness of particles in swarm
        for j in range(num_particles):
            swarm[j].evaluate(costFunc)
            if swarm[j].err_i < err_best_g or err_best_g == -1:
                pos_best_g = list(swarm[j].position_i)
                err_best_g = float(swarm[j].err_i)

        # update velocities and positions
        for j in range(num_particles):
            swarm[j].update_velocity(pos_best_g)
            swarm[j].update_position(bounds)
        i += 1

    if verbose:
        print('\nFINAL SOLUTION:')
        print(f'   > {pos_best_g}')
        print(f'   > {err_best_g}\n')

    return err_best_g, pos_best_g
