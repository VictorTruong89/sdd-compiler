"""Example cost functions for PSO."""


def sphere(x):
    """Sphere function: sum of squares of the elements of x."""
    total = 0
    for xi in x:
        total += xi ** 2
    return total
