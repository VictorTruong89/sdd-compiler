"""Query the ArXiv API for recent papers and print or save the results.

Example:
    python query_arxiv.py --category cs.CL --title LLM --recent_days 10 --verbose
"""

import argparse
import csv
import os
import re
import sys
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from typing import Dict, List

ARXIV_API_URL = "http://export.arxiv.org/api/query?"
DEFAULT_MAX_RESULTS = 10
ABSTRACT_PREVIEW_CHARS = 300
PUBLISHED_FORMAT = "%Y-%m-%dT%H:%M:%SZ"
ALLOWED_QUERY_PATTERN = re.compile(r"^[A-Za-z0-9+:.]+$")
CSV_COLUMNS = ["category", "title", "author", "abstract", "published", "link"]
NAMESPACE = {
    "atom": "http://www.w3.org/2005/Atom",
    "arxiv": "http://arxiv.org/schemas/atom",
}


def get_args(argv=None) -> argparse.Namespace:
    """Parse and validate command line arguments."""
    parser = argparse.ArgumentParser(description="Query ArXiv for recent papers.")
    parser.add_argument("--category", type=str, default=None, help="Category, e.g. cs.CL")
    parser.add_argument("--title", type=str, default=None, help="Keyword in the title")
    parser.add_argument("--author", type=str, default=None, help="Keyword in the author")
    parser.add_argument("--abstract", type=str, default=None, help="Keyword in the abstract")
    parser.add_argument(
        "--recent_days",
        type=int,
        required=True,
        help="Only keep papers published within the last k days",
    )
    parser.add_argument(
        "--max_results",
        type=int,
        default=DEFAULT_MAX_RESULTS,
        help="Maximum number of results to request (default: %(default)s)",
    )
    parser.add_argument(
        "--to_file", type=str, default=None, help="Path of the CSV file to write"
    )
    parser.add_argument(
        "--verbose", action="store_true", help="Print results to the console"
    )
    args = parser.parse_args(argv)

    query_values = {
        "category": args.category,
        "title": args.title,
        "author": args.author,
        "abstract": args.abstract,
    }
    provided = {name: value for name, value in query_values.items() if value is not None}
    if not provided:
        raise ValueError("At least one of category, title, author, abstract must be provided")
    for name, value in provided.items():
        if not ALLOWED_QUERY_PATTERN.match(value):
            raise ValueError(
                f"Invalid characters in --{name} {value!r}; allowed: "
                "letters, digits, '+', ':', '.'"
            )
    if args.recent_days < 0:
        raise ValueError("--recent_days must be non-negative")
    if args.max_results <= 0:
        raise ValueError("--max_results must be positive")
    return args


def construct_query_url(
    category: str = None,
    title: str = None,
    author: str = None,
    abstract: str = None,
    max_results: int = DEFAULT_MAX_RESULTS,
) -> str:
    """Build the ArXiv API URL, sorted by submission date (newest first)."""
    clauses = []
    if category is not None:
        clauses.append(f"cat:{category}")
    if author is not None:
        clauses.append(f"au:{author}")
    if title is not None:
        clauses.append(f"ti:{title}")
    if abstract is not None:
        clauses.append(f"abs:{abstract}")
    if not clauses:
        raise ValueError("At least one search field must be provided")

    search_query = "+AND+".join(clauses)
    return (
        f"{ARXIV_API_URL}search_query={search_query}"
        f"&sortBy=submittedDate&sortOrder=descending&start=0&max_results={max_results}"
    )


def fetch_data(query_url: str) -> bytes:
    """Send a GET request to the ArXiv API and return the raw response body."""
    request = urllib.request.Request(
        query_url, headers={"User-Agent": "query_arxiv.py/1.0"}
    )
    with urllib.request.urlopen(request, timeout=30) as response:
        return response.read()


def _text(element: ET.Element, path: str) -> str:
    """Return the whitespace-normalized text of a child element, or ''."""
    child = element.find(path, NAMESPACE)
    if child is None or child.text is None:
        return ""
    return " ".join(child.text.split())


def check_date(date_string: str, recent_days: int, current_date: datetime) -> bool:
    """Return True if the paper date is within `recent_days` before `current_date`.

    `date_string` is an ArXiv timestamp such as "2024-01-15T18:59:59Z" (UTC).
    A naive `current_date` is interpreted as UTC.
    """
    try:
        published = datetime.strptime(date_string, PUBLISHED_FORMAT).replace(
            tzinfo=timezone.utc
        )
    except (TypeError, ValueError):
        return False

    if current_date.tzinfo is None:
        current_date = current_date.replace(tzinfo=timezone.utc)
    cutoff = current_date - timedelta(days=recent_days)
    return published >= cutoff


def process_entries(
    entries: List[ET.Element],
    namespace: Dict[str, str],
    current_date: datetime,
    recent_days: int,
) -> List[Dict[str, str]]:
    """Convert Atom entries to paper dictionaries, keeping only recent ones."""
    papers = []
    for entry in entries:
        published = _text(entry, "atom:published")
        if not check_date(published, recent_days, current_date):
            continue

        authors = [
            " ".join(name.text.split())
            for name in entry.findall("atom:author/atom:name", namespace)
            if name.text
        ]
        categories = [
            category.get("term", "")
            for category in entry.findall("atom:category", namespace)
            if category.get("term")
        ]
        papers.append(
            {
                "category": ", ".join(categories),
                "title": _text(entry, "atom:title"),
                "author": ", ".join(authors),
                "abstract": _text(entry, "atom:summary"),
                "published": published,
                "link": _text(entry, "atom:id"),
            }
        )
    return papers


def save_to_csv(papers: List[Dict[str, str]], file_name: str) -> None:
    """Write papers to a CSV file, creating the parent directory if needed."""
    directory = os.path.dirname(file_name)
    if directory:
        os.makedirs(directory, exist_ok=True)
    with open(file_name, "w", newline="", encoding="utf-8") as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        writer.writerows(papers)


def print_results(papers: List[Dict[str, str]]) -> None:
    """Print papers to stdout with abstracts truncated for readability."""
    if not papers:
        print("No papers found.")
        return

    for index, paper in enumerate(papers, start=1):
        abstract = paper["abstract"]
        if len(abstract) > ABSTRACT_PREVIEW_CHARS:
            abstract = abstract[:ABSTRACT_PREVIEW_CHARS].rstrip() + "..."
        print(f"[{index}] {paper['title']}")
        print(f"    Authors:    {paper['author']}")
        print(f"    Categories: {paper['category']}")
        print(f"    Published:  {paper['published']}")
        print(f"    Link:       {paper['link']}")
        print(f"    Abstract:   {abstract}")
        print()


def main(argv=None) -> None:
    """Run a query and route the results to the console and/or a CSV file.

    Output rules:
    - --verbose and --to_file: print to console and save to CSV.
    - only --to_file: save to CSV.
    - otherwise (only --verbose, or neither): print to console.
    """
    args = get_args(argv)

    query_url = construct_query_url(
        category=args.category,
        title=args.title,
        author=args.author,
        abstract=args.abstract,
        max_results=args.max_results,
    )
    data = fetch_data(query_url)
    root = ET.fromstring(data)
    entries = root.findall("atom:entry", NAMESPACE)

    papers = process_entries(
        entries, NAMESPACE, datetime.now(timezone.utc), args.recent_days
    )

    if args.to_file:
        save_to_csv(papers, args.to_file)
    if args.verbose or not args.to_file:
        print_results(papers)


if __name__ == "__main__":
    main(sys.argv[1:])
