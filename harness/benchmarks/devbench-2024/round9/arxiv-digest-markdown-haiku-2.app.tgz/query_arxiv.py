"""Query the ArXiv API for papers and filter them by publication date.

Results can be printed to the console (--verbose), saved to a CSV file
(--to_file), or both. With neither flag, results are printed to the console.
"""

import argparse
import csv
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional

ARXIV_API_URL = "http://export.arxiv.org/api/query"
USER_AGENT = "query_arxiv/1.0 (+https://info.arxiv.org/help/api/user-manual.html)"
REQUEST_TIMEOUT = 30  # seconds
DEFAULT_MAX_RESULTS = 10
ABSTRACT_PREVIEW_CHARS = 300
CSV_FIELDS = ["category", "title", "author", "abstract", "published", "link"]
NAMESPACE = {
    "atom": "http://www.w3.org/2005/Atom",
    "arxiv": "http://arxiv.org/schemas/atom",
}
QUERY_FIELDS = ("category", "author", "title", "abstract")
ALLOWED_CHARS = re.compile(r"[A-Za-z0-9+:.]+")


def get_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    """Parse and validate command-line arguments.

    Raises:
        ValueError: if no query parameter is given, or a query parameter
            contains characters outside the allowed set, or recent_days is negative.
    """
    parser = argparse.ArgumentParser(
        description="Query ArXiv for recent papers by category, title, author, or abstract."
    )
    parser.add_argument("--category", type=str, default=None, help="Category of the paper, e.g. cs.CL")
    parser.add_argument("--title", type=str, default=None, help="Keyword in the title")
    parser.add_argument("--author", type=str, default=None, help="Keyword for the author")
    parser.add_argument("--abstract", type=str, default=None, help="Keyword in the abstract")
    parser.add_argument(
        "--recent_days", type=int, required=True, help="Only keep papers published within the last k days"
    )
    parser.add_argument(
        "--max_results",
        type=int,
        default=DEFAULT_MAX_RESULTS,
        help="Maximum number of results to request from ArXiv (default: %(default)s)",
    )
    parser.add_argument("--to_file", type=str, default=None, help="Path to save the results as CSV")
    parser.add_argument("--verbose", action="store_true", help="Print results to the console")
    args = parser.parse_args(argv)

    provided = {name: getattr(args, name) for name in QUERY_FIELDS if getattr(args, name)}
    if not provided:
        raise ValueError("At least one of category, title, author, or abstract must be specified.")
    for name, value in provided.items():
        if not ALLOWED_CHARS.fullmatch(value):
            raise ValueError(
                f"Invalid characters in --{name} {value!r}; only letters, digits, '+', ':' and '.' are allowed."
            )
    if args.recent_days < 0:
        raise ValueError("--recent_days must be a non-negative integer.")
    return args


def construct_query_url(
    category: str = None,
    title: str = None,
    author: str = None,
    abstract: str = None,
    max_results: int = DEFAULT_MAX_RESULTS,
) -> str:
    """Build the ArXiv API URL, sorted by submission date (newest first)."""
    terms = []
    if category:
        terms.append(f"cat:{category}")
    if author:
        terms.append(f"au:{author}")
    if title:
        terms.append(f"ti:{title}")
    if abstract:
        terms.append(f"abs:{abstract}")
    if not terms:
        raise ValueError("At least one query parameter must be provided.")

    search_query = "+AND+".join(terms)
    return (
        f"{ARXIV_API_URL}?search_query={search_query}"
        f"&sortBy=submittedDate&sortOrder=descending&start=0&max_results={max_results}"
    )


def fetch_data(query_url: str) -> bytes:
    """Send a GET request to the ArXiv API and return the raw response body.

    A single request is made per run, which is well within ArXiv's rate limits.
    """
    request = urllib.request.Request(query_url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(request, timeout=REQUEST_TIMEOUT) as response:
        return response.read()


def _normalize(text: Optional[str]) -> str:
    """Collapse runs of whitespace (ArXiv titles and abstracts contain newlines)."""
    return " ".join((text or "").split())


def _child_text(entry: ET.Element, path: str, namespace: Dict[str, str]) -> str:
    return _normalize(entry.findtext(path, default="", namespaces=namespace))


def process_entries(
    entries: List[ET.Element],
    namespace: Dict[str, str],
    current_date: datetime,
    recent_days: int,
) -> List[Dict[str, str]]:
    """Convert Atom entries into paper dictionaries, keeping only recent papers."""
    papers = []
    for entry in entries:
        published = _child_text(entry, "atom:published", namespace)
        if not check_date(published, recent_days, current_date):
            continue

        authors = [
            _normalize(name.text)
            for name in entry.findall("atom:author/atom:name", namespace)
            if name.text
        ]

        primary = entry.find("arxiv:primary_category", namespace)
        if primary is not None and primary.get("term"):
            category = primary.get("term")
        else:
            first = entry.find("atom:category", namespace)
            category = first.get("term", "") if first is not None else ""

        link = ""
        for candidate in entry.findall("atom:link", namespace):
            if candidate.get("rel") == "alternate" and candidate.get("href"):
                link = candidate.get("href")
                break
        if not link:
            link = _child_text(entry, "atom:id", namespace)

        papers.append(
            {
                "category": category,
                "title": _child_text(entry, "atom:title", namespace),
                "author": ", ".join(authors),
                "abstract": _child_text(entry, "atom:summary", namespace),
                "published": published,
                "link": link,
            }
        )
    return papers


def _as_utc(value: datetime) -> datetime:
    """Treat naive datetimes as UTC so that they can be compared with aware ones."""
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def check_date(date_string: str, recent_days: int, current_date: datetime) -> bool:
    """Return True if date_string is within recent_days before current_date.

    ArXiv timestamps look like "2023-01-05T18:00:00Z".
    """
    if not date_string:
        return False
    try:
        published = datetime.strptime(date_string, "%Y-%m-%dT%H:%M:%SZ")
    except ValueError:
        try:
            published = datetime.fromisoformat(date_string.replace("Z", "+00:00"))
        except ValueError:
            return False

    published = _as_utc(published)
    current = _as_utc(current_date)
    cutoff = current - timedelta(days=recent_days)
    return cutoff <= published <= current


def save_to_csv(papers: List[Dict[str, str]], file_name: str) -> None:
    """Write papers to a CSV file, creating the parent directory if needed."""
    directory = os.path.dirname(file_name)
    if directory:
        os.makedirs(directory, exist_ok=True)
    with open(file_name, "w", newline="", encoding="utf-8") as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=CSV_FIELDS)
        writer.writeheader()
        writer.writerows(papers)


def _truncate(text: str, limit: int = ABSTRACT_PREVIEW_CHARS) -> str:
    if len(text) <= limit:
        return text
    return text[:limit].rstrip() + "..."


def print_results(papers: List[Dict[str, str]]) -> None:
    """Print papers to stdout, with the abstract truncated."""
    if not papers:
        print("No papers found.")
        return
    for index, paper in enumerate(papers, start=1):
        print(f"[{index}] {paper['title']}")
        print(f"    Authors:   {paper['author']}")
        print(f"    Category:  {paper['category']}")
        print(f"    Published: {paper['published']}")
        print(f"    Link:      {paper['link']}")
        print(f"    Abstract:  {_truncate(paper['abstract'])}")
        print()


def main(argv: Optional[List[str]] = None) -> None:
    try:
        args = get_args(argv)
    except ValueError as error:
        print(f"error: {error}", file=sys.stderr)
        raise SystemExit(2)

    query_url = construct_query_url(
        category=args.category,
        title=args.title,
        author=args.author,
        abstract=args.abstract,
        max_results=args.max_results,
    )
    try:
        data = fetch_data(query_url)
    except (urllib.error.URLError, OSError) as error:
        print(f"error: failed to query ArXiv: {error}", file=sys.stderr)
        raise SystemExit(1)

    root = ET.fromstring(data)
    entries = root.findall("atom:entry", NAMESPACE)
    papers = process_entries(entries, NAMESPACE, datetime.now(timezone.utc), args.recent_days)

    if args.to_file:
        save_to_csv(papers, args.to_file)
    if args.verbose or not args.to_file:
        print_results(papers)


if __name__ == "__main__":
    main()
