import csv
import os
import sys
import xml.etree.ElementTree as ET
from datetime import datetime, timezone

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import query_arxiv as qa  # noqa: E402

FEED = """<?xml version="1.0" encoding="UTF-8"?>
<feed xmlns="http://www.w3.org/2005/Atom" xmlns:arxiv="http://arxiv.org/schemas/atom">
  <entry>
    <id>http://arxiv.org/abs/2301.00001v1</id>
    <published>2023-01-09T10:00:00Z</published>
    <title>Neural
      Learning</title>
    <summary>  A short
      abstract. </summary>
    <author><name>Jane Smith</name></author>
    <author><name>John Doe</name></author>
    <link href="http://arxiv.org/abs/2301.00001v1" rel="alternate" type="text/html"/>
    <arxiv:primary_category term="cs.CL"/>
    <category term="cs.CL"/>
    <category term="cs.LG"/>
  </entry>
  <entry>
    <id>http://arxiv.org/abs/2001.00002v1</id>
    <published>2020-01-01T00:00:00Z</published>
    <title>Old paper</title>
    <summary>old</summary>
    <author><name>Old Author</name></author>
    <category term="cs.AI"/>
  </entry>
</feed>
"""

NOW = datetime(2023, 1, 10, 12, 0, 0, tzinfo=timezone.utc)


def _entries():
    root = ET.fromstring(FEED)
    return root.findall("atom:entry", qa.NAMESPACE)


def test_construct_query_url_matches_spec_example():
    url = qa.construct_query_url(category="cs.CL", author="Smith", title="neural", abstract="learning", max_results=10)
    assert url == (
        "http://export.arxiv.org/api/query?search_query=cat:cs.CL+AND+au:Smith+AND+ti:neural+AND+abs:learning"
        "&sortBy=submittedDate&sortOrder=descending&start=0&max_results=10"
    )


def test_construct_query_url_single_field():
    url = qa.construct_query_url(title="LLM", max_results=5)
    assert "search_query=ti:LLM&" in url
    assert url.endswith("max_results=5")


def test_get_args_requires_a_query_field():
    with pytest.raises(ValueError):
        qa.get_args(["--recent_days", "3"])


def test_get_args_rejects_invalid_characters():
    with pytest.raises(ValueError):
        qa.get_args(["--title", "neural networks", "--recent_days", "3"])


def test_get_args_accepts_allowed_characters_and_defaults():
    args = qa.get_args(["--abstract", "Deep+Learning", "--recent_days", "10"])
    assert args.abstract == "Deep+Learning"
    assert args.recent_days == 10
    assert args.max_results == 10
    assert args.verbose is False
    assert args.to_file is None


def test_check_date_window():
    assert qa.check_date("2023-01-09T10:00:00Z", 2, NOW)
    assert not qa.check_date("2023-01-01T00:00:00Z", 2, NOW)
    assert not qa.check_date("not a date", 2, NOW)


def test_process_entries_filters_and_extracts_fields():
    papers = qa.process_entries(_entries(), qa.NAMESPACE, NOW, recent_days=5)
    assert len(papers) == 1
    paper = papers[0]
    assert paper == {
        "category": "cs.CL",
        "title": "Neural Learning",
        "author": "Jane Smith, John Doe",
        "abstract": "A short abstract.",
        "published": "2023-01-09T10:00:00Z",
        "link": "http://arxiv.org/abs/2301.00001v1",
    }


def test_save_to_csv_round_trip(tmp_path):
    papers = qa.process_entries(_entries(), qa.NAMESPACE, NOW, recent_days=5)
    target = tmp_path / "nested" / "out.csv"
    qa.save_to_csv(papers, str(target))
    with open(target, newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    assert rows == papers


def test_print_results_truncates_abstract(capsys):
    long_abstract = "x" * 500
    qa.print_results([{"category": "c", "title": "t", "author": "a", "abstract": long_abstract,
                       "published": "p", "link": "l"}])
    out = capsys.readouterr().out
    assert "x" * qa.ABSTRACT_PREVIEW_CHARS + "..." in out
    assert "x" * (qa.ABSTRACT_PREVIEW_CHARS + 1) not in out


def test_print_results_empty(capsys):
    qa.print_results([])
    assert "No papers found." in capsys.readouterr().out


def test_main_to_file_only_does_not_print(monkeypatch, tmp_path, capsys):
    monkeypatch.setattr(qa, "fetch_data", lambda url: FEED.encode("utf-8"))
    target = tmp_path / "res.csv"
    qa.main(["--title", "Neural", "--recent_days", "100000", "--to_file", str(target)])
    assert capsys.readouterr().out == ""
    assert target.exists()


def test_main_default_prints(monkeypatch, capsys):
    monkeypatch.setattr(qa, "fetch_data", lambda url: FEED.encode("utf-8"))
    qa.main(["--title", "Neural", "--recent_days", "100000"])
    assert "Neural Learning" in capsys.readouterr().out
