import os
import sys

# Make query_arxiv.py (at the project root) importable from the tests.
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
