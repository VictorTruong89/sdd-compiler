import csv
import io
from contextlib import redirect_stdout
from datetime import datetime, timedelta, timezone
from unittest import mock

import pytest

import query_arxiv as qa

NOW = datetime(2026, 10, 14, 12, 0, 0, tzinfo=timezone.utc)


class FixedDatetime(datetime):
    @classmethod
    def now(cls, tz=None):
        return NOW

FEED = b"""<?xml version="1.0" encoding="UTF-8"?>
<feed xmlns="http://www.w3.org/2005/Atom" xmlns:arxiv="http://arxiv.org/schema/atom">
  <entry>
    <id>http://arxiv.org/abs/2610.00001v1</id>
    <published>2026-10-12T08:00:00Z</published>
    <title>Deep   Learning for LLM
      Evaluation</title>
    <summary>  We study things.
      Second line.  </summary>
    <author><name>Jane Smith</name></author>
    <author><name>John Doe</name></author>
    <link href="http://arxiv.org/pdf/2610.00001v1" rel="related"/>
    <link href="http://arxiv.org/abs/2610.00001v1" rel="alternate"/>
    <category term="cs.CL" scheme="http://arxiv.org/schema/atom"/>
    <category term="cs.LG" scheme="http://arxiv.org/schema/atom"/>
  </entry>
  <entry>
    <id>http://arxiv.org/abs/2601.00002v1</id>
    <published>2026-01-01T08:00:00Z</published>
    <title>Old paper</title>
    <summary>Too old to be included.</summary>
    <author><name>Old Author</name></author>
    <category term="cs.CL" scheme="http://arxiv.org/schema/atom"/>
  </entry>
</feed>
"""


def make_paper(**overrides):
    paper = {
        "category": "cs.CL",
        "title": "A title",
        "author": "Jane Smith",
        "abstract": "An abstract.",
        "published": "2026-10-12T08:00:00Z",
        "link": "http://arxiv.org/abs/2610.00001v1",
    }
    paper.update(overrides)
    return paper


def parsed_entries():
    root = qa.ET.fromstring(FEED)
    return root.findall("atom:entry", qa.ATOM_NAMESPACE)


# --- N-000033: successful execution of queries with various parameter combinations ---

@pytest.mark.parametrize(
    "argv, expected_clause",
    [
        (["--category", "cs.CL", "--recent_days", "3"], "search_query=cat:cs.CL&"),
        (["--title", "LLM", "--recent_days", "3"], "search_query=ti:LLM&"),
        (["--author", "Smith", "--recent_days", "3"], "search_query=au:Smith&"),
        (["--abstract", "Deep+Learning", "--recent_days", "3"], "search_query=abs:Deep+Learning&"),
        (
            ["--category", "cs.CL", "--title", "LLM", "--author", "Smith", "--abstract", "Deep+Learning", "--recent_days", "10"],
            "search_query=cat:cs.CL+AND+au:Smith+AND+ti:LLM+AND+abs:Deep+Learning&",
        ),
    ],
)
def test_N_000033_query_combinations_build_url(argv, expected_clause):
    args = qa.get_args(argv)
    url = qa.construct_query_url(args.category, args.title, args.author, args.abstract, args.max_results)
    assert url.startswith(qa.ARXIV_API_URL + "?")
    assert expected_clause in url
    assert url.endswith("&sortBy=submittedDate&sortOrder=descending&start=0&max_results=10")


def test_N_000033_url_matches_architecture_example():
    url = qa.construct_query_url(category="cs.CL", title="neural", author="Smith", abstract="learning")
    assert url == (
        "http://export.arxiv.org/api/query?search_query=cat:cs.CL+AND+au:Smith+AND+ti:neural+AND+abs:learning"
        "&sortBy=submittedDate&sortOrder=descending&start=0&max_results=10"
    )


def test_N_000033_end_to_end_console_run(capsys):
    with mock.patch.object(qa, "fetch_data", return_value=FEED) as fetch:
        with mock.patch.object(qa, "datetime", FixedDatetime):
            qa.main(["--title", "LLM", "--recent_days", "10", "--verbose"])
    assert "search_query=ti:LLM&" in fetch.call_args.args[0]
    out = capsys.readouterr().out
    assert "Deep Learning for LLM Evaluation" in out
    assert "Jane Smith, John Doe" in out
    assert "Old paper" not in out


# --- N-000034: accurate filtering based on recent_days ---

def test_N_000034_check_date_within_window():
    recent = (NOW - timedelta(days=9)).strftime("%Y-%m-%dT%H:%M:%SZ")
    assert qa.check_date(recent, 10, NOW) is True


def test_N_000034_check_date_outside_window():
    old = (NOW - timedelta(days=11)).strftime("%Y-%m-%dT%H:%M:%SZ")
    assert qa.check_date(old, 10, NOW) is False


def test_N_000034_check_date_boundary_is_inclusive():
    boundary = (NOW - timedelta(days=10)).strftime("%Y-%m-%dT%H:%M:%SZ")
    assert qa.check_date(boundary, 10, NOW) is True


def test_N_000034_check_date_accepts_naive_current_date():
    recent = "2026-10-12T08:00:00Z"
    assert qa.check_date(recent, 10, datetime(2026, 10, 14, 12, 0, 0)) is True


def test_N_000034_process_entries_filters_by_recent_days():
    papers = qa.process_entries(parsed_entries(), qa.ATOM_NAMESPACE, NOW, 10)
    assert [paper["title"] for paper in papers] == ["Deep Learning for LLM Evaluation"]


def test_N_000034_process_entries_keeps_old_papers_when_window_is_wide():
    papers = qa.process_entries(parsed_entries(), qa.ATOM_NAMESPACE, NOW, 365)
    assert len(papers) == 2


# --- N-000035: correct formatting and data integrity in console output and CSV ---

def test_N_000035_process_entries_extracts_fields():
    (paper,) = qa.process_entries(parsed_entries(), qa.ATOM_NAMESPACE, NOW, 10)
    assert paper == {
        "category": "cs.CL, cs.LG",
        "title": "Deep Learning for LLM Evaluation",
        "author": "Jane Smith, John Doe",
        "abstract": "We study things. Second line.",
        "published": "2026-10-12T08:00:00Z",
        "link": "http://arxiv.org/abs/2610.00001v1",
    }


def test_N_000035_save_to_csv_writes_header_and_full_rows(tmp_path):
    long_abstract = "word " * 200
    target = tmp_path / "nested" / "out.csv"
    qa.save_to_csv([make_paper(abstract=long_abstract, title="Comma, title")], str(target))
    with open(target, newline="", encoding="utf-8") as csv_file:
        rows = list(csv.DictReader(csv_file))
    assert list(rows[0].keys()) == qa.CSV_COLUMNS
    assert rows[0]["abstract"].strip() == long_abstract.strip()
    assert rows[0]["title"] == "Comma, title"


def test_N_000035_print_results_contains_fields_and_truncates_abstract():
    buffer = io.StringIO()
    with redirect_stdout(buffer):
        qa.print_results([make_paper(abstract="x" * 1000)])
    out = buffer.getvalue()
    for label in ("Category:", "Authors:", "Published:", "Link:"):
        assert label in out
    assert "A title" in out
    assert "x" * (qa.ABSTRACT_PREVIEW_LENGTH + 1) not in out
    assert "..." in out


def test_N_000035_print_results_handles_no_papers():
    buffer = io.StringIO()
    with redirect_stdout(buffer):
        qa.print_results([])
    assert buffer.getvalue().strip() == "No papers found."


# --- N-000036: efficient handling of API responses ---

def test_N_000036_fetch_data_uses_timeout_and_returns_bytes():
    response = mock.MagicMock()
    response.read.return_value = FEED
    context = mock.MagicMock()
    context.__enter__.return_value = response
    with mock.patch.object(qa.urllib.request, "urlopen", return_value=context) as urlopen:
        assert qa.fetch_data("http://example.test/q") == FEED
    assert urlopen.call_args.kwargs["timeout"] == qa.REQUEST_TIMEOUT_SECONDS


def test_N_000036_empty_feed_yields_no_papers():
    root = qa.ET.fromstring(b'<feed xmlns="http://www.w3.org/2005/Atom"></feed>')
    assert qa.process_entries(root.findall("atom:entry", qa.ATOM_NAMESPACE), qa.ATOM_NAMESPACE, NOW, 10) == []


# --- Output routing (N-000011, N-000012, N-000013) ---

@pytest.mark.parametrize(
    "argv, expect_console, expect_csv",
    [
        (["--title", "LLM", "--recent_days", "10", "--to_file", "{csv}", "--verbose"], True, True),
        (["--title", "LLM", "--recent_days", "10", "--to_file", "{csv}"], False, True),
        (["--title", "LLM", "--recent_days", "10", "--verbose"], True, False),
        (["--title", "LLM", "--recent_days", "10"], True, False),
    ],
)
def test_N_000013_output_routing(tmp_path, capsys, argv, expect_console, expect_csv):
    csv_path = tmp_path / "results.csv"
    argv = [arg.format(csv=csv_path) for arg in argv]
    with mock.patch.object(qa, "fetch_data", return_value=FEED):
        with mock.patch.object(qa, "datetime", FixedDatetime):
            qa.main(argv)
    out = capsys.readouterr().out
    assert ("Deep Learning for LLM Evaluation" in out) is expect_console
    assert csv_path.exists() is expect_csv


# --- Validation (N-000025, N-000027, N-000028, N-000026, N-000030) ---

def test_N_000028_invalid_characters_raise_value_error():
    with pytest.raises(ValueError):
        qa.construct_query_url(title="deep learning")


def test_N_000028_invalid_characters_rejected_by_get_args():
    with pytest.raises(ValueError):
        qa.get_args(["--title", "a-b", "--recent_days", "3"])


def test_N_000025_requires_at_least_one_query_term():
    with pytest.raises(ValueError):
        qa.get_args(["--recent_days", "3"])


def test_N_000026_recent_days_is_required():
    with pytest.raises(SystemExit):
        qa.get_args(["--title", "LLM"])
