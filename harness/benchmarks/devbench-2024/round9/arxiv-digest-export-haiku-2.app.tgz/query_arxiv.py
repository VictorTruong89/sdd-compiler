"""Query the ArXiv API for recent papers and print or save the results.

All functions are standalone module-level functions (spec: N-000055).
"""
import argparse
import csv
import os
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone

ARXIV_API_URL = "http://export.arxiv.org/api/query"
ALLOWED_CHARACTERS = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+:.")  # spec: N-000027
ATOM_NAMESPACE = {"atom": "http://www.w3.org/2005/Atom"}
CSV_COLUMNS = ["category", "title", "author", "abstract", "published", "link"]  # spec: N-000018
ABSTRACT_PREVIEW_LENGTH = 300  # spec: N-000054
REQUEST_TIMEOUT_SECONDS = 30
USER_AGENT = "query-arxiv/1.0"


def validate_query_terms(category=None, title=None, author=None, abstract=None):
    """Return the provided query terms, raising ValueError on bad input.  # spec: N-000025, N-000027, N-000028"""
    terms = {"category": category, "author": author, "title": title, "abstract": abstract}
    provided = {name: value for name, value in terms.items() if value}
    if not provided:
        raise ValueError("at least one of category, title, author or abstract must be provided")
    for name, value in provided.items():
        invalid = "".join(sorted(set(value) - ALLOWED_CHARACTERS))
        if invalid:
            raise ValueError(f"{name} contains characters that are not allowed: {invalid!r}")
    return provided


def get_args(argv=None):  # spec: N-000046, N-000014
    parser = argparse.ArgumentParser(description="Search ArXiv papers and filter them by publication date.")
    parser.add_argument("--category", type=str, help="Category of the paper, e.g. cs.CL")
    parser.add_argument("--title", type=str, help="Keyword for the title")
    parser.add_argument("--author", type=str, help="Keyword for the author")
    parser.add_argument("--abstract", type=str, help="Keyword in the abstract")
    parser.add_argument("--recent_days", type=int, required=True, help="Filter papers from the most recent k days")  # spec: N-000030
    parser.add_argument("--max_results", type=int, default=10, help="Number of results requested from ArXiv (default: 10)")  # spec: N-000005
    parser.add_argument("--to_file", type=str, help="Path to save the results in CSV format")  # spec: N-000031
    parser.add_argument("--verbose", action="store_true", help="Print results to the console")  # spec: N-000032
    args = parser.parse_args(argv)
    validate_query_terms(args.category, args.title, args.author, args.abstract)
    return args


def construct_query_url(category=None, title=None, author=None, abstract=None, max_results=10):  # spec: N-000048
    provided = validate_query_terms(category, title, author, abstract)
    values = {"category": category, "author": author, "title": title, "abstract": abstract}
    prefixes = {"category": "cat", "author": "au", "title": "ti", "abstract": "abs"}
    clauses = [f"{prefixes[name]}:{values[name]}" for name in prefixes if name in provided]
    search_query = "+AND+".join(clauses)
    return (
        f"{ARXIV_API_URL}?search_query={search_query}"
        f"&sortBy=submittedDate&sortOrder=descending&start=0&max_results={max_results}"
    )


def fetch_data(query_url):  # spec: N-000049, N-000036
    request = urllib.request.Request(query_url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(request, timeout=REQUEST_TIMEOUT_SECONDS) as response:
        return response.read()


def process_entries(entries, namespace, current_date, recent_days):  # spec: N-000050, N-000016
    papers = []
    for entry in entries:
        published = _find_text(entry, "atom:published", namespace)
        if not published or not check_date(published, recent_days, current_date):
            continue
        papers.append({
            "category": ", ".join(
                category.get("term") for category in entry.findall("atom:category", namespace) if category.get("term")
            ),
            "title": _normalize_whitespace(_find_text(entry, "atom:title", namespace)),
            "author": ", ".join(
                _find_text(author, "atom:name", namespace) for author in entry.findall("atom:author", namespace)
            ),
            "abstract": _normalize_whitespace(_find_text(entry, "atom:summary", namespace)),
            "published": published,
            "link": _find_link(entry, namespace),
        })
    return papers


def check_date(date_string, recent_days, current_date):  # spec: N-000051, N-000010, N-000021
    published = _as_utc(datetime.fromisoformat(date_string.replace("Z", "+00:00")))
    return _as_utc(current_date) - published <= timedelta(days=recent_days)


def save_to_csv(papers, file_name):  # spec: N-000052, N-000041
    directory = os.path.dirname(file_name)
    if directory:
        os.makedirs(directory, exist_ok=True)
    with open(file_name, "w", newline="", encoding="utf-8") as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        writer.writerows(papers)


def print_results(papers):  # spec: N-000053, N-000040, N-000054
    if not papers:
        print("No papers found.")
        return
    for index, paper in enumerate(papers, start=1):
        print(f"[{index}] {paper['title']}")
        print(f"    Category:  {paper['category']}")
        print(f"    Authors:   {paper['author']}")
        print(f"    Published: {paper['published']}")
        print(f"    Abstract:  {_truncate(paper['abstract'], ABSTRACT_PREVIEW_LENGTH)}")
        print(f"    Link:      {paper['link']}")
        print()


def main(argv=None):  # spec: N-000047, N-000013, N-000033
    args = get_args(argv)
    query_url = construct_query_url(args.category, args.title, args.author, args.abstract, args.max_results)
    root = ET.fromstring(fetch_data(query_url))
    entries = root.findall("atom:entry", ATOM_NAMESPACE)
    papers = process_entries(entries, ATOM_NAMESPACE, datetime.now(timezone.utc), args.recent_days)
    if args.to_file:
        save_to_csv(papers, args.to_file)
    # Console output is produced for --verbose, or when no CSV file was requested (so results are never silently lost).
    if args.verbose or not args.to_file:
        print_results(papers)


def _find_text(element, path, namespace):
    child = element.find(path, namespace)
    return (child.text or "").strip() if child is not None else ""


def _find_link(entry, namespace):
    for link in entry.findall("atom:link", namespace):
        if link.get("rel") == "alternate" and link.get("href"):
            return link.get("href")
    return _find_text(entry, "atom:id", namespace)


def _normalize_whitespace(text):
    return " ".join(text.split())


def _truncate(text, length):
    if len(text) <= length:
        return text
    return text[:length].rstrip() + "..."


def _as_utc(moment):
    if moment.tzinfo is None:
        return moment.replace(tzinfo=timezone.utc)
    return moment.astimezone(timezone.utc)


if __name__ == "__main__":
    try:
        main()
    except ValueError as error:
        raise SystemExit(f"error: {error}")
