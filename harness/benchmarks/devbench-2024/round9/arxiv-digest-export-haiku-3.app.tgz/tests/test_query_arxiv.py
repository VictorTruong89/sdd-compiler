import sys
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest import mock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import query_arxiv as qa  # noqa: E402

NOW = datetime(2026, 10, 14, 12, 0, 0, tzinfo=timezone.utc)


def _iso(days_ago: float) -> str:
    return (NOW - timedelta(days=days_ago)).strftime("%Y-%m-%dT%H:%M:%SZ")


def _feed(*entries: str) -> bytes:
    body = "".join(entries)
    return (
        '<?xml version="1.0" encoding="UTF-8"?>'
        f'<feed xmlns="{qa.ATOM_NS}" xmlns:arxiv="{qa.ARXIV_NS}">{body}</feed>'
    ).encode("utf-8")


def _entry(title: str, published: str, abstract: str = "An abstract.", authors=("Jane Smith",), arxiv_id="2610.00001") -> str:
    author_xml = "".join(f"<author><name>{name}</name></author>" for name in authors)
    return (
        "<entry>"
        f"<id>http://arxiv.org/abs/{arxiv_id}</id>"
        f"<published>{published}</published>"
        f"<title>{title}</title>"
        f"<summary>{abstract}</summary>"
        f"{author_xml}"
        '<arxiv:primary_category term="cs.CL"/>'
        '<category term="cs.CL"/><category term="cs.LG"/>'
        "</entry>"
    )


def _papers(feed: bytes, recent_days: int):
    root = ET.fromstring(feed)
    return qa.process_entries(root.findall("atom:entry", qa.NAMESPACE), qa.NAMESPACE, NOW, recent_days)


# spec: N-000033
def test_N_000033_queries_with_parameter_combinations():
    url = qa.construct_query_url(category="cs.CL", author="Smith", title="neural", abstract="learning")
    assert url == (
        "http://export.arxiv.org/api/query?search_query=cat:cs.CL+AND+au:Smith+AND+ti:neural+AND+abs:learning"
        "&sortBy=submittedDate&sortOrder=descending&start=0&max_results=10"
    )
    assert qa.construct_query_url(title="LLM").endswith("search_query=ti:LLM&sortBy=submittedDate&sortOrder=descending&start=0&max_results=10")
    assert "abs:Deep+Learning" in qa.construct_query_url(abstract="Deep+Learning")
    assert qa.construct_query_url(author="Smith", max_results=3).endswith("max_results=3")


# spec: N-000033
def test_N_000033_end_to_end_main_with_combinations(tmp_path, capsys):
    out_file = tmp_path / "nested" / "results.csv"
    published = (datetime.now(timezone.utc) - timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%SZ")
    feed = _feed(_entry("Deep Learning for LLM", published))
    argv = ["--category", "cs.CL", "--title", "LLM", "--author", "Smith", "--abstract", "Deep+Learning",
            "--recent_days", "10", "--to_file", str(out_file), "--verbose"]
    with mock.patch.object(qa, "fetch_data", return_value=feed) as fetch:
        qa.main(argv)
    assert "search_query=cat:cs.CL+AND+au:Smith+AND+ti:LLM+AND+abs:Deep+Learning" in fetch.call_args[0][0]
    assert out_file.exists()
    assert "Deep Learning for LLM" in capsys.readouterr().out


# spec: N-000034
def test_N_000034_accurate_filtering_by_recent_days():
    feed = _feed(
        _entry("Recent", _iso(2)),
        _entry("Old", _iso(30)),
        _entry("Boundary", _iso(10)),
        _entry("Broken date", "not-a-date"),
    )
    titles = [p["title"] for p in _papers(feed, recent_days=10)]
    assert titles == ["Recent", "Boundary"]


# spec: N-000034 N-000051 N-000021
def test_N_000034_check_date_uses_utc_and_window():
    assert qa.check_date(_iso(0), 1, NOW)
    assert not qa.check_date(_iso(5), 1, NOW)
    naive_now = NOW.replace(tzinfo=None)
    assert qa.check_date(_iso(3), 5, naive_now)
    assert not qa.check_date("", 5, NOW)


# spec: N-000035
def test_N_000035_csv_and_console_format_and_integrity(tmp_path, capsys):
    feed = _feed(_entry("A  title\n  split", _iso(1), abstract="Words   here", authors=("A One", "B Two")))
    papers = _papers(feed, recent_days=5)
    assert papers[0]["title"] == "A title split"
    assert papers[0]["author"] == "A One, B Two"
    assert papers[0]["category"] == "cs.CL"
    assert papers[0]["link"] == "http://arxiv.org/abs/2610.00001"

    csv_path = tmp_path / "out.csv"
    qa.save_to_csv(papers, str(csv_path))
    lines = csv_path.read_text(encoding="utf-8").splitlines()
    assert lines[0] == "category,title,author,abstract,published,link"
    assert lines[1].startswith("cs.CL,A title split,\"A One, B Two\",Words here,")

    qa.print_results(papers)
    console = capsys.readouterr().out
    assert "[1] A title split" in console
    assert "http://arxiv.org/abs/2610.00001" in console


# spec: N-000036 N-000054 N-000050
def test_N_000036_handles_empty_and_large_responses_and_truncates_abstract(capsys):
    assert _papers(_feed(), recent_days=5) == []
    qa.print_results([])
    assert "No papers found." in capsys.readouterr().out

    long_abstract = "x" * 1000
    feed = _feed(*[_entry(f"Paper {i}", _iso(0), abstract=long_abstract) for i in range(500)])
    papers = _papers(feed, recent_days=5)
    assert len(papers) == 500
    qa.print_results(papers[:1])
    abstract_line = [l for l in capsys.readouterr().out.splitlines() if "Abstract:" in l][0]
    assert abstract_line.endswith("...")
    assert len(abstract_line.split("Abstract:")[1].strip()) == qa.ABSTRACT_MAX_CHARS


# spec: N-000025 N-000027 N-000028
def test_argument_validation_raises_value_error():
    with pytest.raises(ValueError):
        qa.construct_query_url()
    with pytest.raises(ValueError):
        qa.construct_query_url(title="bad title")
    with pytest.raises(ValueError):
        qa.get_args(["--title", "x y", "--recent_days", "3"])
    with pytest.raises(ValueError):
        qa.get_args(["--recent_days", "3"])


# spec: N-000014 N-000024 N-000026 N-000029 N-000030 N-000031 N-000032 N-000006
def test_get_args_parses_all_options():
    args = qa.get_args(["--category", "cs.CL", "--recent_days", "7", "--to_file", "a.csv", "--verbose"])
    assert args.category == "cs.CL"
    assert args.recent_days == 7
    assert args.to_file == "a.csv"
    assert args.verbose is True
    assert args.max_results == 10


def test_recent_days_is_required():
    with pytest.raises(SystemExit):
        qa.get_args(["--title", "LLM"])


# spec: N-000013 N-000011 N-000012 N-000044 N-000045 N-000038
@pytest.mark.parametrize(
    "extra, expect_console, expect_file",
    [
        (["--verbose", "--to_file", "f.csv"], True, True),
        (["--to_file", "f.csv"], False, True),
        (["--verbose"], True, False),
        ([], True, False),
    ],
)
def test_output_selection(tmp_path, capsys, extra, expect_console, expect_file):
    feed = _feed(_entry("Paper", _iso(0)))
    argv = ["--title", "LLM", "--recent_days", "5"] + [
        str(tmp_path / a) if a == "f.csv" else a for a in extra
    ]
    with mock.patch.object(qa, "fetch_data", return_value=feed):
        qa.main(argv)
    assert ("[1] Paper" in capsys.readouterr().out) is expect_console
    assert (tmp_path / "f.csv").exists() is expect_file


# spec: N-000048 N-000049 N-000052 N-000053 N-000055 N-000046 N-000047
def test_functions_are_module_level():
    for name in ["get_args", "main", "construct_query_url", "fetch_data", "process_entries",
                 "check_date", "save_to_csv", "print_results"]:
        assert callable(getattr(qa, name))
