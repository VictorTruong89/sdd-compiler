"""Query the ArXiv API for recent papers and print or save the results.

The standalone functions of this tool all live in this file.
"""
import argparse
import csv
import os
import sys
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from typing import Dict, List

# spec: N-000039
ARXIV_API_URL = "http://export.arxiv.org/api/query"
ATOM_NS = "http://www.w3.org/2005/Atom"
ARXIV_NS = "http://arxiv.org/schemas/atom"
NAMESPACE = {"atom": ATOM_NS, "arxiv": ARXIV_NS}

# spec: N-000027
ALLOWED_CHARS = frozenset("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+:.")
DATE_FORMAT = "%Y-%m-%dT%H:%M:%SZ"
DEFAULT_MAX_RESULTS = 10
# spec: N-000054
ABSTRACT_MAX_CHARS = 300
# spec: N-000018
CSV_COLUMNS = ["category", "title", "author", "abstract", "published", "link"]


def _validate_search_terms(category, title, author, abstract) -> None:
    """Require at least one search term and only allowed characters in each."""
    # spec: N-000025 N-000028
    terms = {"category": category, "title": title, "author": author, "abstract": abstract}
    provided = {name: value for name, value in terms.items() if value}
    if not provided:
        raise ValueError("At least one of category, title, author, or abstract must be provided")
    for name, value in provided.items():
        # spec: N-000027 N-000028
        if not set(value) <= ALLOWED_CHARS:
            raise ValueError(
                f"Invalid characters in {name}: {value!r}. "
                "Only letters, digits, '+', ':' and '.' are allowed"
            )


# spec: N-000046 N-000014
def get_args(argv=None) -> argparse.Namespace:
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description="Query ArXiv papers by category, title, author, or abstract.")
    # spec: N-000024 N-000029 N-000030 N-000031 N-000032
    parser.add_argument("--category", type=str, default=None, help="Category of the paper, e.g. cs.CL")
    parser.add_argument("--title", type=str, default=None, help="Keyword for the title")
    parser.add_argument("--author", type=str, default=None, help="Keyword for the author")
    parser.add_argument("--abstract", type=str, default=None, help="Keyword in the abstract")
    # spec: N-000006 N-000026
    parser.add_argument(
        "--recent_days", type=int, required=True, help="Only keep papers submitted within the last k days"
    )
    # spec: N-000005
    parser.add_argument(
        "--max_results", type=int, default=DEFAULT_MAX_RESULTS, help="Maximum number of results to request"
    )
    parser.add_argument("--to_file", type=str, default=None, help="Path to save the results in CSV format")
    parser.add_argument("--verbose", action="store_true", help="Print results to the console")
    args = parser.parse_args(argv)
    if args.recent_days < 0:
        parser.error("--recent_days must be zero or a positive number of days")
    _validate_search_terms(args.category, args.title, args.author, args.abstract)
    return args


# spec: N-000048 N-000003 N-000004 N-000005 N-000009
def construct_query_url(category=None, title=None, author=None, abstract=None, max_results=DEFAULT_MAX_RESULTS) -> str:
    """Build the ArXiv API query URL, newest submissions first."""
    _validate_search_terms(category, title, author, abstract)
    clauses = []
    if category:
        clauses.append(f"cat:{category}")
    if author:
        clauses.append(f"au:{author}")
    if title:
        clauses.append(f"ti:{title}")
    if abstract:
        clauses.append(f"abs:{abstract}")
    search_query = "+AND+".join(clauses)
    return (
        f"{ARXIV_API_URL}?search_query={search_query}"
        f"&sortBy=submittedDate&sortOrder=descending&start=0&max_results={max_results}"
    )


# spec: N-000049 N-000020
def fetch_data(query_url: str) -> bytes:
    """Send one GET request to the ArXiv API and return the raw response.

    A single request is made per run, which keeps us within ArXiv's usage guidelines.
    """
    request = urllib.request.Request(query_url, headers={"User-Agent": "query_arxiv/1.0"})
    with urllib.request.urlopen(request, timeout=30) as response:
        return response.read()


# spec: N-000051 N-000021 N-000008 N-000010
def check_date(date_string: str, recent_days: int, current_date: datetime) -> bool:
    """Return True if the paper was published within `recent_days` before `current_date`."""
    try:
        published = datetime.strptime(date_string, DATE_FORMAT).replace(tzinfo=timezone.utc)
    except ValueError:
        return False
    if current_date.tzinfo is None:
        current_date = current_date.replace(tzinfo=timezone.utc)
    return published >= current_date - timedelta(days=recent_days)


# spec: N-000050 N-000015 N-000016
def process_entries(entries: List[ET.Element], namespace: Dict[str, str], current_date: datetime, recent_days: int) -> List[Dict[str, str]]:
    """Turn ArXiv feed entries into dictionaries, keeping only papers within the date window."""
    papers = []
    for entry in entries:
        published = entry.findtext("atom:published", default="", namespaces=namespace)
        if not check_date(published, recent_days, current_date):
            continue
        primary = entry.find("arxiv:primary_category", namespace)
        if primary is not None:
            category = primary.get("term", "")
        else:
            category = " ".join(c.get("term", "") for c in entry.findall("atom:category", namespace))
        authors = ", ".join(
            author.findtext("atom:name", default="", namespaces=namespace)
            for author in entry.findall("atom:author", namespace)
        )
        papers.append(
            {
                "category": category,
                "title": " ".join(entry.findtext("atom:title", default="", namespaces=namespace).split()),
                "author": authors,
                "abstract": " ".join(entry.findtext("atom:summary", default="", namespaces=namespace).split()),
                "published": published,
                "link": entry.findtext("atom:id", default="", namespaces=namespace).strip(),
            }
        )
    return papers


# spec: N-000052 N-000012 N-000041 N-000017 N-000018
def save_to_csv(papers: List[Dict[str, str]], file_name: str) -> None:
    """Write the full paper records to a CSV file, creating its folder if needed."""
    directory = os.path.dirname(file_name)
    if directory:
        os.makedirs(directory, exist_ok=True)
    with open(file_name, "w", newline="", encoding="utf-8") as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        writer.writerows(papers)


# spec: N-000053 N-000040 N-000054 N-000017 N-000011
def print_results(papers: List[Dict[str, str]]) -> None:
    """Print each paper to the console with its abstract truncated."""
    if not papers:
        print("No papers found.")
        return
    for index, paper in enumerate(papers, start=1):
        abstract = paper["abstract"]
        if len(abstract) > ABSTRACT_MAX_CHARS:
            abstract = abstract[: ABSTRACT_MAX_CHARS - 3].rstrip() + "..."
        print(f"[{index}] {paper['title']}")
        print(f"    Category:  {paper['category']}")
        print(f"    Authors:   {paper['author']}")
        print(f"    Published: {paper['published']}")
        print(f"    Link:      {paper['link']}")
        print(f"    Abstract:  {abstract}")
        print()


# spec: N-000047 N-000038 N-000013 N-000055
def main(argv=None) -> None:
    """Run a query: fetch, filter, save, and/or show the results."""
    args = get_args(argv)
    current_date = datetime.now(timezone.utc)
    query_url = construct_query_url(
        category=args.category,
        title=args.title,
        author=args.author,
        abstract=args.abstract,
        max_results=args.max_results,
    )
    root = ET.fromstring(fetch_data(query_url))
    papers = process_entries(root.findall("atom:entry", NAMESPACE), NAMESPACE, current_date, args.recent_days)
    if args.to_file:
        save_to_csv(papers, args.to_file)
    # Print when --verbose is given, or when no output file was requested (so a run never silently does nothing).
    # With --to_file alone, results are only saved.
    if args.verbose or not args.to_file:
        print_results(papers)


if __name__ == "__main__":
    try:
        main()
    except ValueError as error:
        print(f"error: {error}", file=sys.stderr)
        sys.exit(2)
