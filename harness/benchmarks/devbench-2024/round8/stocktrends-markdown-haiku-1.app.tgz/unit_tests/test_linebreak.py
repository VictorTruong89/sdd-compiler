import pandas as pd
import pytest

from stocktrends import LineBreak


def make_closes(closes):
    dates = pd.date_range("2020-01-01", periods=len(closes), freq="D").strftime("%Y-%m-%d")
    return pd.DataFrame({
        "date": dates, "open": closes, "high": closes, "low": closes, "close": closes,
    })


def test_seed_rows_are_first_line_number_bars():
    chart = LineBreak(make_closes([10, 11, 12, 13]), line_number=3).get_ohlc_data()
    assert chart["close"].iloc[:3].tolist() == [10, 11, 12]
    assert chart["uptrend"].iloc[:3].all()


def test_reversal_needs_break_of_last_lines_range():
    # Lines: up to 13, then 11 is below the last line's low (not a reversal yet
    # because 11 > min low of the last 3 lines) -> stays inside range.
    chart = LineBreak(make_closes([10, 11, 12, 13, 11, 14]), line_number=3).get_ohlc_data()
    assert chart["close"].tolist()[3:] == [13, 11, 14] or chart["close"].iloc[-1] == 14


def test_up_reversal_opens_at_previous_line_open():
    chart = LineBreak(make_closes([10, 11, 12, 13, 9, 15]), line_number=3).get_ohlc_data()
    lines = chart.iloc[3:]
    down = lines[lines["uptrend"] == False]  # noqa: E712
    up = lines[lines["uptrend"] == True]  # noqa: E712
    assert len(down) >= 1 and len(up) >= 1
    last_down = down.iloc[-1]
    reversal = lines.iloc[-1]
    assert reversal["open"] == last_down["open"]


def test_output_has_seed_rows_plus_lines():
    df = make_closes([10, 11, 12, 13])
    chart = LineBreak(df, line_number=3).get_ohlc_data()
    assert list(chart.columns) == ["date", "open", "high", "low", "close", "uptrend"]
    assert len(chart) >= 3


def test_too_few_rows_raises():
    with pytest.raises(ValueError):
        LineBreak(make_closes([1, 2]), line_number=3).get_ohlc_data()
