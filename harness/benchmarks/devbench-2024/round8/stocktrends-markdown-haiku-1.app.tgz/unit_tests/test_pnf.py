import pandas as pd
import pytest

from stocktrends import PnF


def make_closes(closes):
    dates = pd.date_range("2020-01-01", periods=len(closes), freq="D").strftime("%Y-%m-%d")
    return pd.DataFrame({
        "date": dates, "open": closes, "high": closes, "low": closes, "close": closes,
    })


@pytest.mark.parametrize("x, base, expected", [
    (143.95, 1, 144),
    (143.4, 1, 143),
    (147.6, 5, 150),
    (147.4, 5, 145),
    (-7.2, 5, -5),
])
def test_roundit_nearest_multiple_as_int(x, base, expected):
    result = PnF.roundit(x, base)
    assert isinstance(result, int)
    assert result == expected


def test_brick_size_is_box_size():
    assert PnF(make_closes([1.0]), box_size=7).brick_size == 7


def test_get_state_extend_reverse_hold():
    pnf = PnF(make_closes([1.0]), box_size=1, reversal_size=3)
    assert pnf.get_state(True, 1) == "extend"
    assert pnf.get_state(True, -3) == "reverse"
    assert pnf.get_state(True, -2) == "hold"
    assert pnf.get_state(False, -1) == "extend"
    assert pnf.get_state(False, 3) == "reverse"
    assert pnf.get_state(False, 2) == "hold"


def test_columns_alternate_and_reverse_after_reversal_size():
    closes = [10, 11, 12, 13, 12, 11, 10, 9, 8, 9, 10, 11, 12]
    chart = PnF(make_closes(closes), box_size=1, reversal_size=3).get_ohlc_data(source="close")
    ups = chart["uptrend"].tolist()
    assert ups[0] is True
    assert all(a != b for a, b in zip(ups, ups[1:]))
    assert chart["close"].iloc[0] == 13


def test_small_moves_do_not_form_column_under_reversal_size():
    closes = [10, 11, 10, 11, 10]
    chart = PnF(make_closes(closes), box_size=1, reversal_size=3).get_ohlc_data()
    assert len(chart) == 1
    assert bool(chart["uptrend"].iloc[0]) is True


def test_bar_ohlc_is_rounded_to_boxes():
    df = make_closes([143.95])
    bars = PnF(df, box_size=5).get_bar_ohlc_data(source="close")
    assert bars.iloc[0][["open", "high", "low", "close", "level"]].tolist() == [145, 145, 145, 145, 145]


def test_unknown_source_raises():
    with pytest.raises(ValueError):
        PnF(make_closes([1.0, 2.0]), box_size=1).get_ohlc_data(source="volume")
