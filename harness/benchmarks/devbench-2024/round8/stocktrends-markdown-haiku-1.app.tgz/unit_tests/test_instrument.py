import os

import pandas as pd
import pytest

from stocktrends import Instrument

SAMPLES = os.path.join(os.path.dirname(__file__), "..", "unit_samples")


def test_columns_are_lowercased_and_stripped():
    df = pd.DataFrame({" Date ": ["2020-01-01"], "OPEN": [1.0], "High": [2.0], "LOW": [0.5], "Close": [1.5]})
    inst = Instrument(df)
    assert list(inst.df.columns) == ["date", "open", "high", "low", "close"]


def test_rows_sorted_oldest_first():
    df = pd.DataFrame({
        "date": ["2021-06-08", "2021-06-07", "2021-06-04"],
        "open": [3.0, 2.0, 1.0], "high": [3.0, 2.0, 1.0],
        "low": [3.0, 2.0, 1.0], "close": [3.0, 2.0, 1.0],
    })
    inst = Instrument(df)
    assert inst.df["date"].tolist() == ["2021-06-04", "2021-06-07", "2021-06-08"]


def test_missing_ohlc_column_raises():
    df = pd.DataFrame({"open": [1.0], "high": [2.0], "low": [0.5]})
    with pytest.raises(ValueError, match="close"):
        Instrument(df)


def test_input_frame_not_modified():
    df = pd.DataFrame({"OPEN": [1], "HIGH": [2], "LOW": [0], "CLOSE": [1]})
    Instrument(df)
    assert list(df.columns) == ["OPEN", "HIGH", "LOW", "CLOSE"]


def test_unit_sample_loads():
    df = pd.read_csv(os.path.join(SAMPLES, "HDFCLIFE.csv"))
    inst = Instrument(df)
    assert {"open", "high", "low", "close"} <= set(inst.df.columns)
    dates = pd.to_datetime(inst.df["date"])
    assert dates.is_monotonic_increasing
