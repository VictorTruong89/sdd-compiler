import pandas as pd

from stocktrends import Renko


def make_closes(closes, start="2020-01-01"):
    dates = pd.date_range(start, periods=len(closes), freq="D").strftime("%Y-%m-%d")
    return pd.DataFrame({
        "date": dates, "open": closes, "high": closes, "low": closes, "close": closes,
    })


def test_first_brick_anchored_below_first_close():
    chart = Renko(make_closes([143.95]), brick_size=4).get_ohlc_data()
    assert chart.iloc[0][["open", "high", "low", "close"]].tolist() == [136, 140, 136, 140]
    assert bool(chart.iloc[0]["uptrend"]) is True


def test_up_then_down_continuation_bricks():
    chart = Renko(make_closes([100, 104, 108, 104, 96]), brick_size=4).get_ohlc_data()
    closes = chart["close"].tolist()
    assert closes[-2:] == [100, 96]
    assert chart["uptrend"].tolist()[-2:] == [False, False]


def test_reversal_needs_two_bricks_from_close():
    # Up to 104, then a fall to 100 is only one brick below 104 -> no reversal yet.
    chart = Renko(make_closes([100, 104, 100]), brick_size=4).get_ohlc_data()
    assert chart["uptrend"].tolist() == [True, True]
    assert chart["close"].tolist()[-1] == 104


def test_price_jump_creates_multiple_bricks_on_same_date():
    chart = Renko(make_closes([100, 120]), brick_size=4).get_ohlc_data()
    assert len(chart) > 2
    assert chart["date"].iloc[1:].nunique() == 1


def test_row_count_depends_on_brick_size():
    closes = [10, 20, 30, 40, 50]
    small = Renko(make_closes(closes), brick_size=2).get_ohlc_data()
    large = Renko(make_closes(closes), brick_size=5).get_ohlc_data()
    assert list(small.columns) == ["date", "open", "high", "low", "close", "uptrend"]
    assert len(small) > len(large)


def test_price_movement_uses_high_and_low():
    df = make_closes([100, 100, 100])
    df["high"] = [100, 112, 100]
    chart = Renko(df, brick_size=4, chart_type=Renko.PRICE_MOVEMENT).get_ohlc_data()
    assert chart["close"].max() == 112


def test_empty_frame_returns_empty_chart():
    df = pd.DataFrame(columns=["date", "open", "high", "low", "close"])
    chart = Renko(df, brick_size=4).get_ohlc_data()
    assert len(chart) == 0
