"""Compute Renko, Line Break and PnF indicators for the HDFCLIFE sample and print a report."""
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)

from stocktrends import LineBreak, PnF, Renko, load_csv  # noqa: E402

DATA = os.path.join(ROOT, "unit_samples", "HDFCLIFE.csv")


def report(title, chart):
    print(f"== {title}: {len(chart)} rows")
    print(chart.tail(5).to_string(index=False))
    print()


def main():
    df = load_csv(DATA)

    renko = Renko(df, brick_size=10, chart_type=Renko.PERIOD_CLOSE)
    report("Renko (brick 10, period close)", renko.get_ohlc_data())

    line_break = LineBreak(df, line_number=3)
    report("Line Break (3 lines)", line_break.get_ohlc_data())

    pnf = PnF(df, box_size=10, reversal_size=3)
    report("Point and Figure (box 10, reversal 3)", pnf.get_ohlc_data(source="close"))


if __name__ == "__main__":
    main()
