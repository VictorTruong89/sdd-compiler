import os

import numpy as np
import pandas as pd

from stocktrends import LineBreak, Renko

SAMPLES = os.path.join(os.path.dirname(__file__), "..", "acceptance_samples")
TOLERANCE = 1e-12


def load(name):
    return pd.read_csv(os.path.join(SAMPLES, name))


def test_renko_close_matches_expected():
    expected = load("hooli_renko_4.csv")
    chart = Renko(load("HOOLI.csv"), brick_size=4, chart_type=Renko.PERIOD_CLOSE).get_ohlc_data()
    assert chart.shape[0] == expected.shape[0]
    diff = np.abs(chart["close"].to_numpy() - expected["close"].to_numpy())
    assert diff.max() < TOLERANCE
    assert (chart["uptrend"].to_numpy() == expected["uptrend"].to_numpy()).all()


def test_line_break_close_matches_expected():
    expected = load("hooli_linebreak_3.csv")
    chart = LineBreak(load("HOOLI.csv"), line_number=3).get_ohlc_data()
    assert chart.shape[0] == expected.shape[0]
    diff = np.abs(chart["close"].to_numpy() - expected["close"].to_numpy())
    assert (diff <= TOLERANCE).all()
    assert (chart["uptrend"].to_numpy() == expected["uptrend"].to_numpy()).all()
