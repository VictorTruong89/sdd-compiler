"""Financial indicators: Renko, Line Break and Point and Figure (PnF) charts."""
import math

import pandas as pd

OHLC_COLUMNS = ["open", "high", "low", "close"]
CHART_COLUMNS = ["date", "open", "high", "low", "close", "uptrend"]


def load_csv(path):
    """Read a price CSV file into a DataFrame."""
    return pd.read_csv(path)


class Instrument:
    """Holds the price history of one instrument (stock, commodity, ...).

    Column names are lowercased and stripped, rows are sorted by ``date``
    (oldest first) when a date column is present, and OHLC columns are
    converted to float.
    """

    def __init__(self, df):
        self.odf = df
        self.df = self._normalize(df)
        self._validate_df()

    @staticmethod
    def _normalize(df):
        df = df.copy()
        df.columns = [str(col).strip().lower() for col in df.columns]
        if "date" in df.columns:
            order = pd.to_datetime(df["date"]).argsort(kind="stable")
            df = df.iloc[order]
        df = df.reset_index(drop=True)
        for col in OHLC_COLUMNS:
            if col in df.columns:
                df[col] = df[col].astype(float)
        return df

    def _dates(self):
        """Bar dates as a list; falls back to the row index without a date column."""
        if "date" in self.df.columns:
            return self.df["date"].tolist()
        return self.df.index.tolist()

    def _validate_df(self):
        """Raise ValueError when the DataFrame lacks any OHLC column."""
        missing = [col for col in OHLC_COLUMNS if col not in self.df.columns]
        if missing:
            raise ValueError(f"DataFrame is missing required columns: {missing}")


class Renko(Instrument):
    """Renko bricks of a fixed size.

    A brick is added when the price moves one brick beyond the last brick's
    close in the same direction. A reversal needs the price to move
    ``TREND_CHANGE_DIFF`` bricks beyond the last close; the reversal brick
    opens at the previous brick's open.
    """

    PERIOD_CLOSE = 0
    PRICE_MOVEMENT = 1
    TREND_CHANGE_DIFF = 2

    def __init__(self, df, brick_size=3, chart_type=PERIOD_CLOSE):
        super().__init__(df)
        self.brick_size = brick_size
        self.chart_type = chart_type

    def get_ohlc_data(self):
        """Return the Renko bricks as a DataFrame of OHLC rows.

        PERIOD_CLOSE uses one price per bar (the close). Any other chart type
        (PRICE_MOVEMENT) also checks each bar's high and low, in that order.
        """
        if self.chart_type == self.PERIOD_CLOSE:
            return self.period_close_bricks()
        return self.price_movement_bricks()

    def period_close_bricks(self):
        """Bricks built from each bar's closing price."""
        return self._bricks_from_ticks(self._ticks(self.df["close"]))

    def price_movement_bricks(self):
        """Bricks built from every bar's high and low prices."""
        ticks = self._ticks(self.df["high"]) + self._ticks(self.df["low"])
        ticks.sort(key=lambda tick: tick[2])
        return self._bricks_from_ticks([(date, price) for date, price, _ in ticks])

    def shift_bricks(self, bricks, date, price):
        """Append every brick that ``price`` completes to ``bricks`` (in place)."""
        size = float(self.brick_size)
        reversal = self.TREND_CHANGE_DIFF * size
        while True:
            last = bricks[-1]
            open_, close, up = last["open"], last["close"], last["uptrend"]
            if up and price >= close + size:
                bricks.append(self._brick(date, close, close + size))
            elif up and price <= close - reversal:
                bricks.append(self._brick(date, open_, open_ - size))
            elif not up and price <= close - size:
                bricks.append(self._brick(date, close, close - size))
            elif not up and price >= close + reversal:
                bricks.append(self._brick(date, open_, open_ + size))
            else:
                return

    def _ticks(self, prices):
        return [(date, float(price), i) for i, (date, price) in enumerate(zip(self._dates(), prices))]

    def _bricks_from_ticks(self, ticks):
        if not ticks:
            return pd.DataFrame(columns=CHART_COLUMNS)
        size = float(self.brick_size)
        first_date, first_price = ticks[0][0], ticks[0][1]
        anchor = math.floor(first_price / size) * size
        bricks = [self._brick(first_date, anchor - size, anchor)]
        for date, price, *_ in ticks:
            self.shift_bricks(bricks, date, price)
        return pd.DataFrame(bricks, columns=CHART_COLUMNS)

    @staticmethod
    def _brick(date, open_, close):
        return {
            "date": date,
            "open": open_,
            "high": max(open_, close),
            "low": min(open_, close),
            "close": close,
            "uptrend": close > open_,
        }


class LineBreak(Instrument):
    """Line Break chart with ``line_number`` lines of reversal look-back.

    The first ``line_number`` rows of the result are the raw input bars
    (uptrend True); the line-break lines follow them.
    """

    def __init__(self, df, line_number=3):
        super().__init__(df)
        self.line_number = line_number
        self._reset()

    def _reset(self):
        self._lines = []
        self._uptrend = True
        self._open = None
        self._close = None

    def uptrend_reversal(self, close):
        """True when ``close`` is above the highest high of the last lines."""
        recent = self._lines[-self.line_number:]
        return bool(recent) and close > max(line["high"] for line in recent)

    def downtrend_reversal(self, close):
        """True when ``close`` is below the lowest low of the last lines."""
        recent = self._lines[-self.line_number:]
        return bool(recent) and close < min(line["low"] for line in recent)

    def get_ohlc_data(self):
        """Return the seed bars followed by the Line Break lines."""
        n = self.line_number
        if len(self.df) < n:
            raise ValueError(f"need at least {n} rows for a {n}-line break chart")
        self._reset()
        closes = self.df["close"].tolist()
        self._open = self._close = closes[n - 1]

        for date, close in zip(self._dates(), closes):
            if self._uptrend:
                if close > self._close:
                    self._add_line(date, self._close, close, True)
                elif self.downtrend_reversal(close):
                    self._add_line(date, self._open, close, False)
            else:
                if close < self._close:
                    self._add_line(date, self._close, close, False)
                elif self.uptrend_reversal(close):
                    self._add_line(date, self._open, close, True)

        seeds = self.df.iloc[:n]
        seed_rows = [
            {"date": row["date"] if "date" in seeds.columns else index,
             "open": row["open"], "high": row["high"], "low": row["low"],
             "close": row["close"], "uptrend": True}
            for index, row in seeds.iterrows()
        ]
        return pd.DataFrame(seed_rows + self._lines, columns=CHART_COLUMNS)

    def _add_line(self, date, open_, close, uptrend):
        self._lines.append({
            "date": date,
            "open": open_,
            "high": max(open_, close),
            "low": min(open_, close),
            "close": close,
            "uptrend": uptrend,
        })
        self._open = open_
        self._close = close
        self._uptrend = uptrend


class PnF(Instrument):
    """Point and Figure chart with boxes of ``box_size``.

    Price levels are rounded to multiples of ``box_size``. A column reverses
    once price moves ``reversal_size`` boxes against it.
    """

    def __init__(self, df, box_size=1, reversal_size=3):
        super().__init__(df)
        self.box_size = box_size
        self.reversal_size = reversal_size

    @property
    def brick_size(self):
        """Brick size used for the indicator (the box size)."""
        return self.box_size

    def get_state(self, uptrend_p1, bricks):
        """Decide what a move of ``bricks`` boxes does to the current column.

        ``uptrend_p1`` is True when the current column is an X (rising) column.
        ``bricks`` is the signed box distance from the column's end to the new
        level (positive means higher). Returns 'extend', 'reverse' or 'hold'.
        """
        if uptrend_p1:
            if bricks >= 1:
                return "extend"
            if bricks <= -self.reversal_size:
                return "reverse"
        else:
            if bricks <= -1:
                return "extend"
            if bricks >= self.reversal_size:
                return "reverse"
        return "hold"

    @staticmethod
    def roundit(x, base):
        """Round ``x`` to the nearest multiple of ``base`` and return an int."""
        return int(math.floor(x / base + 0.5) * base)

    def get_ohlc_data(self, source="close"):
        """Return one OHLC row per PnF column, using the ``source`` column."""
        columns = self._columns(source)
        rows = [
            {"date": col["date"], "open": col["start"], "high": max(col["start"], col["end"]),
             "low": min(col["start"], col["end"]), "close": col["end"], "uptrend": col["up"]}
            for col in columns
        ]
        return pd.DataFrame(rows, columns=CHART_COLUMNS)

    def get_bar_ohlc_data(self, source="close"):
        """Return each bar's OHLC rounded to box levels, plus its PnF level.

        ``level`` is the box level of ``source`` for that bar.
        """
        b = self.box_size
        rows = []
        for date, row in zip(self._dates(), self.df.itertuples(index=False)):
            rows.append({
                "date": date,
                "open": self.roundit(row.open, b),
                "high": self.roundit(row.high, b),
                "low": self.roundit(row.low, b),
                "close": self.roundit(row.close, b),
                "level": self.roundit(getattr(row, source), b),
            })
        return pd.DataFrame(rows, columns=["date", "open", "high", "low", "close", "level"])

    def _columns(self, source):
        """Build the list of PnF columns from the ``source`` price series."""
        if source not in self.df.columns:
            raise ValueError(f"unknown price source: {source!r}")
        b = self.box_size
        columns = []
        current = None
        for date, price in zip(self._dates(), self.df[source].tolist()):
            level = self.roundit(price, b)
            if current is None:
                current = {"date": date, "up": None, "start": level, "end": level}
                continue
            if current["up"] is None:
                if level - current["start"] >= b:
                    current["up"], current["end"], current["date"] = True, level, date
                elif current["start"] - level >= b:
                    current["up"], current["end"], current["date"] = False, level, date
                continue
            bricks = (level - current["end"]) // b
            state = self.get_state(current["up"], bricks)
            if state == "extend":
                current["end"], current["date"] = level, date
            elif state == "reverse":
                columns.append(current)
                start = current["end"] - b if current["up"] else current["end"] + b
                current = {"date": date, "up": not current["up"], "start": start, "end": level}
        if current is not None and current["up"] is not None:
            columns.append(current)
        return columns
