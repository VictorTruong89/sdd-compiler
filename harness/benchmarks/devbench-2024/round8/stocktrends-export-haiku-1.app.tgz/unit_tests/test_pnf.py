# Unit tests for the indicator package.  # spec: N-000016, N-000017
import pandas as pd
import pytest

from stocktrends import PnF


def _bars(closes, highs=None, lows=None):
    dates = [f"d{i + 1}" for i in range(len(closes))]
    return pd.DataFrame({
        "date": dates,
        "open": closes,
        "high": highs or closes,
        "low": lows or closes,
        "close": closes,
    })


def test_brick_size_returns_box_size():  # spec: N-000061, N-000060
    assert PnF(_bars([1, 2]), box_size=5, reversal_size=3).brick_size() == 5


def test_roundit_rounds_to_nearest_multiple_as_int():  # spec: N-000063, N-000064
    pnf = PnF(_bars([1, 2]))
    assert pnf.roundit(143.95, 1) == 144
    assert pnf.roundit(14.26, 5) == 15
    assert pnf.roundit(12.4, 5) == 10
    assert pnf.roundit(2.5, 1) == 3
    assert isinstance(pnf.roundit(143.95, 1), int)


def test_get_state_continuation_and_reversal():  # spec: N-000062
    pnf = PnF(_bars([1, 2]), box_size=1, reversal_size=3)
    assert pnf.get_state(True, 2) == "up"
    assert pnf.get_state(False, -1) == "down"
    assert pnf.get_state(True, -2) == "none"
    assert pnf.get_state(True, -3) == "down_reversal"
    assert pnf.get_state(False, 3) == "up_reversal"
    assert pnf.get_state(True, 0) == "none"


def test_column_build_with_reversal():  # spec: N-000065, N-000011
    # 10 -> 13 is an X column; 13 -> 10 is a 3-box reversal starting one box below 13.
    pnf = PnF(_bars([10, 11, 12, 13, 12, 11, 10, 9]), box_size=1, reversal_size=3)
    out = pnf.get_ohlc_data("close")
    assert list(out.columns) == ["date", "open", "high", "low", "close", "uptrend"]
    assert list(out["open"]) == [10, 12]
    assert list(out["high"]) == [13, 12]
    assert list(out["low"]) == [10, 9]
    assert list(out["close"]) == [13, 9]
    assert list(out["uptrend"]) == [True, False]


def test_small_move_does_not_reverse():  # spec: N-000012
    pnf = PnF(_bars([10, 11, 12, 11, 12]), box_size=1, reversal_size=3)
    out = pnf.get_ohlc_data("close")
    assert len(out) == 1
    assert out["close"].iloc[0] == 12


def test_hl_source_uses_high_and_low_per_bar():  # spec: N-000065
    # Bar 2 goes up to 14 then down to 10: an X column to 14, then a 4-box reversal to 10.
    df = _bars([10, 10], highs=[10, 14], lows=[10, 10])
    out = PnF(df, box_size=1, reversal_size=3).get_ohlc_data("hl")
    assert list(out["close"]) == [14, 10]
    assert list(out["uptrend"]) == [True, False]


def test_unknown_source_raises():  # spec: N-000065
    with pytest.raises(ValueError):
        PnF(_bars([1, 2])).get_ohlc_data("open")


def test_bar_ohlc_rounds_prices_to_box_levels():  # spec: N-000066
    df = pd.DataFrame({"date": ["d1"], "open": [10.4], "high": [11.6], "low": [9.7], "close": [10.6]})
    out = PnF(df, box_size=1).get_bar_ohlc_data("hl")
    assert list(out.iloc[0][["open", "high", "low", "close"]]) == [10, 12, 10, 11]
    close_only = PnF(df, box_size=1).get_bar_ohlc_data("close")
    assert close_only.iloc[0]["close"] == close_only.iloc[0]["open"] == 11


def test_bar_ohlc_unknown_source_raises():  # spec: N-000066
    with pytest.raises(ValueError):
        PnF(_bars([1, 2])).get_bar_ohlc_data("volume")
