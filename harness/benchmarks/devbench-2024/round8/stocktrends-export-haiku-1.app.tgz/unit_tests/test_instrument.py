# Unit tests for the indicator package.  # spec: N-000016, N-000017
import os

import pandas as pd
import pytest

from stocktrends import Instrument, load_csv, summarize

HERE = os.path.dirname(os.path.abspath(__file__))
SAMPLES = os.path.join(os.path.dirname(HERE), "acceptance_samples")
UNIT_SAMPLES = os.path.join(os.path.dirname(HERE), "unit_samples")


def _frame(**cols):
    return pd.DataFrame(cols)


def test_normalizes_column_names_to_lowercase():  # spec: N-000005
    df = _frame(Date=["2020-01-01"], Open=[1.0], High=[2.0], Low=[0.5], Close=[1.5])
    inst = Instrument(df)
    assert list(inst.df.columns) == ["date", "open", "high", "low", "close"]


def test_keeps_original_frame_as_odf():  # spec: N-000045
    df = _frame(date=["2020-01-01"], open=[1.0], high=[2.0], low=[0.5], close=[1.5])
    inst = Instrument(df)
    assert inst.odf is df
    assert inst.df is not df


def test_missing_ohlc_column_raises():  # spec: N-000050
    df = _frame(date=["2020-01-01"], open=[1.0], high=[2.0], close=[1.5])
    with pytest.raises(ValueError, match="low"):
        Instrument(df)


def test_rows_sorted_chronologically():  # spec: N-000004
    df = _frame(date=["2021-06-08", "2021-06-07", "2021-06-04"], open=[3, 2, 1], high=[3, 2, 1], low=[3, 2, 1], close=[3, 2, 1])
    inst = Instrument(df)
    assert list(inst.df["date"]) == ["2021-06-04", "2021-06-07", "2021-06-08"]
    assert list(inst.df["close"]) == [1, 2, 3]


def test_load_csv_reads_sample_and_instrument_accepts_it():  # spec: N-000004, N-000013, N-000014
    df = load_csv(os.path.join(SAMPLES, "HOOLI.csv"))
    inst = Instrument(df)
    assert inst.df.shape == (248, 5)


def test_hdfclife_columns_normalized():  # spec: N-000014, N-000027, N-000028
    inst = Instrument(load_csv(os.path.join(UNIT_SAMPLES, "HDFCLIFE.csv")))
    assert {"open", "high", "low", "close", "date"}.issubset(inst.df.columns)
    assert inst.df.shape[0] == 879


def test_summarize_reports_counts_and_last_close():  # spec: N-000015
    chart = pd.DataFrame({
        "date": ["d1", "d2", "d3"],
        "open": [1, 2, 3], "high": [2, 3, 4], "low": [1, 2, 3], "close": [2, 3, 4],
        "uptrend": [True, True, False],
    })
    result = summarize(chart)
    assert result["rows"] == 3
    assert result["up"] == 2
    assert result["down"] == 1
    assert result["first_date"] == "d1"
    assert result["last_date"] == "d3"
    assert result["last_close"] == 4.0


def test_summarize_empty_chart():  # spec: N-000015
    assert summarize(pd.DataFrame(columns=["date", "close", "uptrend"]))["rows"] == 0


# Data contract checks for the sample folders (assumptions in the spec's data description).

def test_acceptance_samples_folder_has_expected_files():  # spec: N-000018, N-000019, N-000020, N-000029, N-000030
    for name in ["HOOLI.csv", "hooli_linebreak_3.csv", "hooli_renko_4.csv"]:
        assert os.path.isfile(os.path.join(SAMPLES, name))


def test_acceptance_file_columns():  # spec: N-000022, N-000023, N-000024
    hooli = pd.read_csv(os.path.join(SAMPLES, "HOOLI.csv"))
    assert list(hooli.columns) == ["date", "open", "high", "low", "close"]
    lb = pd.read_csv(os.path.join(SAMPLES, "hooli_linebreak_3.csv"), index_col=0)
    assert list(lb.columns) == ["index", "date", "open", "high", "low", "close", "uptrend"]
    renko = pd.read_csv(os.path.join(SAMPLES, "hooli_renko_4.csv"), index_col=0)
    assert list(renko.columns) == ["date", "open", "high", "low", "close", "uptrend"]


def test_unit_samples_folder_has_expected_files():  # spec: N-000025, N-000026, N-000032, N-000033
    assert os.path.isfile(os.path.join(UNIT_SAMPLES, "HDFCLIFE.csv"))
    assert os.path.isfile(os.path.join(UNIT_SAMPLES, "HOOLI.csv"))


def test_hdfclife_file_columns():  # spec: N-000027
    hdfc = pd.read_csv(os.path.join(UNIT_SAMPLES, "HDFCLIFE.csv"))
    assert list(hdfc.columns) == [
        "DATE", "SERIES", "OPEN", "HIGH", "LOW", "PREV. CLOSE", "LTP", "CLOSE", "VWAP",
        "52W H", "52W L", "VOLUME", "VALUE", "NO OF TRADES", "SYMBOL",
    ]
