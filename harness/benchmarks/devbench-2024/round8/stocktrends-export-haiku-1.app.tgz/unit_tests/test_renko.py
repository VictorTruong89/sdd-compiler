# Unit tests for the indicator package.  # spec: N-000016, N-000017
import pandas as pd

from stocktrends import Renko


def _bars(closes, start="2020-01-01"):
    dates = pd.date_range(start, periods=len(closes)).strftime("%Y-%m-%d")
    return pd.DataFrame({"date": dates, "open": closes, "high": closes, "low": closes, "close": closes})


def test_constructor_defaults_and_chart_type_constants():  # spec: N-000051, N-000007
    renko = Renko(_bars([10, 11]))
    assert renko.chart_type == Renko.PERIOD_CLOSE
    assert renko.brick_size == 3
    assert (Renko.PERIOD_CLOSE, Renko.PRICE_MOVEMENT, Renko.TREND_CHANGE_DIFF) == (0, 1, 2)


def test_brick_size_is_customizable():  # spec: N-000006
    out = Renko(_bars([100, 110]), brick_size=5).get_ohlc_data()
    # Initial brick 95-100, then 100-105 and 105-110.
    assert list(out["close"]) == [100, 105, 110]


def test_dispatch_by_chart_type():  # spec: N-000052, N-000046
    renko = Renko(_bars([10, 14, 6]), brick_size=2)
    renko.chart_type = Renko.PERIOD_CLOSE
    assert renko.get_ohlc_data().equals(renko.period_close_bricks())
    renko.chart_type = Renko.PRICE_MOVEMENT
    assert renko.get_ohlc_data().equals(renko.price_movement_bricks())


def test_period_close_brick_levels():  # spec: N-000053
    out = Renko(_bars([10, 14, 6]), brick_size=2).period_close_bricks()
    assert list(out["open"]) == [8, 10, 12, 12, 10, 8]
    assert list(out["close"]) == [10, 12, 14, 10, 8, 6]
    assert list(out["high"]) == [10, 12, 14, 12, 10, 8]
    assert list(out["low"]) == [8, 10, 12, 10, 8, 6]
    assert list(out["uptrend"]) == [True, True, True, False, False, False]


def test_bricks_formed_in_one_period_share_its_date():  # spec: N-000008
    out = Renko(_bars([10, 14]), brick_size=2).period_close_bricks()
    assert out["date"].iloc[1] == out["date"].iloc[2] == "2020-01-02"


def test_shift_bricks_counts_steps_between_closes():  # spec: N-000054
    steps = Renko(_bars([10, 14, 6, 6.5]), brick_size=2).shift_bricks()
    assert list(steps) == [0, 2, -4, 0]


def test_price_movement_uses_high_for_up_and_low_for_down():  # spec: N-000052
    df = pd.DataFrame({
        "date": ["d1", "d2"],
        "open": [10, 10], "high": [10, 15], "low": [10, 10], "close": [10, 10],
    })
    out = Renko(df, brick_size=2, chart_type=Renko.PRICE_MOVEMENT).get_ohlc_data()
    # Up bricks from the high (12, 14), then the low of the same bar reverses to 10.
    assert list(out["close"]) == [10, 12, 14, 10]
    assert list(out["date"]) == ["d1", "d2", "d2", "d2"]
