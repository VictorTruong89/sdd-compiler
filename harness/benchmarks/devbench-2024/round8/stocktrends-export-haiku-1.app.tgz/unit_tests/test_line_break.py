# Unit tests for the indicator package.  # spec: N-000016, N-000017
import pandas as pd

from stocktrends import LineBreak


def _bars(closes):
    dates = pd.date_range("2020-01-01", periods=len(closes)).strftime("%Y-%m-%d")
    return pd.DataFrame({"date": dates, "open": closes, "high": closes, "low": closes, "close": closes})


def test_line_number_is_stored():  # spec: N-000009, N-000055
    assert LineBreak(_bars([1, 2, 3, 4]), line_number=2).line_number == 2


def test_reversal_checks_use_window_of_last_lines():  # spec: N-000056, N-000057
    lb = LineBreak(_bars([10, 11, 12, 13]), line_number=2)
    lb.get_ohlc_data()
    # Window after the run is the last two lines: highs 12 and 13, lows 11 and 12.
    assert lb.uptrend_reversal(14)
    assert not lb.uptrend_reversal(13)
    assert lb.downtrend_reversal(10)
    assert not lb.downtrend_reversal(11)


def test_line_break_output_shape_and_columns():  # spec: N-000058, N-000059
    out = LineBreak(_bars([10, 11, 12, 13, 14, 15]), line_number=3).get_ohlc_data()
    assert list(out.columns) == ["date", "open", "high", "low", "close", "uptrend"]
    assert len(out) == 3 + 4  # leading bars, then the bar-0 line and three more lines
    assert out["uptrend"].iloc[-1]


def test_closes_follow_the_breakout_rule():  # spec: N-000010
    out = LineBreak(_bars([10, 12, 11, 9, 13]), line_number=2).get_ohlc_data()
    assert list(out["close"]) == [10, 12, 10, 9, 13]
    assert list(out["uptrend"]) == [True, True, False, False, True]
