"""Pytest entry point: puts the project root on sys.path so `stocktrends` imports in every test folder."""
