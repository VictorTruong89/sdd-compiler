# Acceptance tests: Renko and Line Break close prices compared with the expected sample charts.  # spec: N-000031
import os

import pandas as pd

from stocktrends import LineBreak, Renko, load_csv

HERE = os.path.dirname(os.path.abspath(__file__))
TOL = 1e-12


def _path(name):
    return os.path.join(HERE, name)


def test_AC_1_renko_close_matches_expected():  # spec: N-000041, N-000042, N-000021, N-000040
    renko = Renko(load_csv(_path("HOOLI.csv")), brick_size=4)
    got = renko.get_ohlc_data()
    expected = pd.read_csv(_path("hooli_renko_4.csv"), index_col=0)
    assert len(got) == len(expected)
    assert (got["close"] - expected["close"]).abs().max() <= TOL
    assert (got["date"] == expected["date"]).all()
    assert (got["uptrend"].astype(bool) == expected["uptrend"].astype(bool)).all()


def test_AC_2_line_break_close_matches_expected():  # spec: N-000043, N-000044, N-000021, N-000040, N-000010
    line_break = LineBreak(load_csv(_path("HOOLI.csv")), line_number=3)
    got = line_break.get_ohlc_data()
    expected = pd.read_csv(_path("hooli_linebreak_3.csv"), index_col=0)
    assert len(got) == len(expected)
    assert (got["close"] - expected["close"]).abs().max() <= TOL
    assert (got["date"] == expected["date"]).all()
    assert (got["uptrend"].astype(bool) == expected["uptrend"].astype(bool)).all()


def test_AC_1_renko_shape_matches_expected():  # spec: N-000008, N-000017
    got = Renko(load_csv(_path("HOOLI.csv")), brick_size=4).get_ohlc_data()
    assert list(got.columns) == ["date", "open", "high", "low", "close", "uptrend"]
    assert got.shape == (215, 6)


def test_AC_2_line_break_shape_matches_expected():  # spec: N-000017
    got = LineBreak(load_csv(_path("HOOLI.csv")), line_number=3).get_ohlc_data()
    assert list(got.columns) == ["date", "open", "high", "low", "close", "uptrend"]
    assert got.shape == (76, 6)
