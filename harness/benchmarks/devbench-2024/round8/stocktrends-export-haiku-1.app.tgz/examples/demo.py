"""Compute Renko, Line Break and PnF charts for the sample HDFCLIFE data."""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))

from stocktrends import LineBreak, PnF, Renko, load_csv, summarize  # noqa: E402


def main():
    data_path = os.path.join(HERE, "HDFCLIFE.csv")

    renko = Renko(load_csv(data_path), brick_size=4)
    renko_chart = renko.get_ohlc_data()
    print("Renko (brick size 4):", summarize(renko_chart))

    line_break = LineBreak(load_csv(data_path), line_number=3)
    line_chart = line_break.get_ohlc_data()
    print("Line Break (3 lines):", summarize(line_chart))

    pnf = PnF(load_csv(data_path), box_size=1, reversal_size=3)
    pnf_chart = pnf.get_ohlc_data("close")
    print("PnF (box 1, reversal 3):", summarize(pnf_chart))


if __name__ == "__main__":
    main()
