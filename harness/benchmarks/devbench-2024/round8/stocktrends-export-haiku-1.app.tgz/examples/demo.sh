#! /bin/bash

# Run the demo  # spec: N-000048
python examples/demo.py
