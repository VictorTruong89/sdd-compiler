"""Financial indicators: Renko, Line Break and Point & Figure (PnF) charts."""
import math

import pandas as pd


def load_csv(path):  # spec: N-000004
    """Load a CSV file of price data into a DataFrame."""
    return pd.read_csv(path)


def summarize(chart):  # spec: N-000015
    """Summarize an indicator chart: row counts, direction counts, date range and last close."""
    if chart.empty:
        return {"rows": 0, "up": 0, "down": 0, "first_date": None, "last_date": None, "last_close": None}
    up = int(chart["uptrend"].sum()) if "uptrend" in chart.columns else None
    return {
        "rows": len(chart),
        "up": up,
        "down": None if up is None else len(chart) - up,
        "first_date": chart["date"].iloc[0],
        "last_date": chart["date"].iloc[-1],
        "last_close": float(chart["close"].iloc[-1]),
    }


class Instrument:
    """Holds the price data for one financial instrument (stock, commodity, ...)."""

    REQUIRED_COLUMNS = ("open", "high", "low", "close")

    def __init__(self, df):  # spec: N-000049, N-000001, N-000013, N-000014
        self.odf = df  # spec: N-000045
        self.df = self._normalize(df)  # spec: N-000045
        self._validate_df()

    @classmethod
    def _normalize(cls, df):  # spec: N-000004, N-000005
        out = df.copy()
        out.columns = [str(c).strip().lower() for c in out.columns]
        if "date" not in out.columns:
            out.insert(0, "date", out.index)
        for col in cls.REQUIRED_COLUMNS:
            if col in out.columns:
                out[col] = pd.to_numeric(out[col])
        # Sort chronologically when dates can be parsed (some sample files are newest-first).
        parsed = pd.to_datetime(out["date"], errors="coerce", format="mixed")
        if parsed.notna().all():
            out = out.iloc[parsed.argsort(kind="stable").to_numpy()]
        return out.reset_index(drop=True)

    def _validate_df(self):  # spec: N-000050
        missing = [c for c in self.REQUIRED_COLUMNS if c not in self.df.columns]
        if missing:
            raise ValueError(f"DataFrame is missing required OHLC columns: {missing}")


class Renko(Instrument):
    """Renko chart built from closing prices (PERIOD_CLOSE) or intraperiod price moves."""

    PERIOD_CLOSE = 0
    PRICE_MOVEMENT = 1
    TREND_CHANGE_DIFF = 2

    def __init__(self, df, brick_size=3, chart_type=PERIOD_CLOSE):  # spec: N-000051, N-000006, N-000007
        super().__init__(df)
        self.brick_size = brick_size
        self.chart_type = chart_type

    def get_ohlc_data(self):  # spec: N-000052, N-000046
        if self.chart_type == self.PERIOD_CLOSE:
            return self.period_close_bricks()
        return self.price_movement_bricks()

    def period_close_bricks(self):  # spec: N-000053, N-000008
        """Bricks driven by each period's closing price."""
        df = self.df
        closes = df["close"].tolist()
        return self._build_bricks(df["date"].tolist(), closes, closes, closes)

    def price_movement_bricks(self):
        """Bricks driven by each period's high (up moves) and low (down moves)."""
        df = self.df
        return self._build_bricks(df["date"].tolist(), df["close"].tolist(), df["high"].tolist(), df["low"].tolist())

    def shift_bricks(self):  # spec: N-000054
        """Number of brick steps between consecutive closes, truncated toward zero."""
        diff = self.df["close"].diff().fillna(0)
        return (diff / self.brick_size).apply(math.trunc)

    def _build_bricks(self, dates, base_prices, up_prices, down_prices):
        b = self.brick_size
        level = math.floor(base_prices[0] / b) * b
        # Each brick is (date, open, close, uptrend); high/low are derived from open/close below.
        rows = [(dates[0], level - b, level, True)]
        o, c, up = level - b, level, True
        for d, up_p, down_p in zip(dates, up_prices, down_prices):
            if up:
                while up_p >= c + b:
                    o, c = c, c + b
                    rows.append((d, o, c, True))
                if down_p <= o - b:  # reversal: one brick below the last brick's open
                    o, c, up = o, o - b, False
                    rows.append((d, o, c, False))
                    while down_p <= c - b:
                        o, c = c, c - b
                        rows.append((d, o, c, False))
            else:
                while down_p <= c - b:
                    o, c = c, c - b
                    rows.append((d, o, c, False))
                if up_p >= o + b:  # reversal: one brick above the last brick's open
                    o, c, up = o, o + b, True
                    rows.append((d, o, c, True))
                    while up_p >= c + b:
                        o, c = c, c + b
                        rows.append((d, o, c, True))
        out = pd.DataFrame(rows, columns=["date", "open", "close", "uptrend"])
        out.insert(2, "high", out[["open", "close"]].max(axis=1))
        out.insert(3, "low", out[["open", "close"]].min(axis=1))
        return out[["date", "open", "high", "low", "close", "uptrend"]]


class LineBreak(Instrument):
    """Line Break chart: a new line is drawn when price breaks the extreme of the last N lines."""

    def __init__(self, df, line_number=3):  # spec: N-000055, N-000009
        super().__init__(df)
        self.line_number = line_number
        self._lines = []

    def uptrend_reversal(self, close):  # spec: N-000056
        window = self._lines[-self.line_number:]
        return close > max(line["high"] for line in window)

    def downtrend_reversal(self, close):  # spec: N-000057
        window = self._lines[-self.line_number:]
        return close < min(line["low"] for line in window)

    def get_ohlc_data(self):  # spec: N-000058, N-000059, N-000010, N-000043, N-000044, N-000046
        """Build Line Break lines.

        The first ``line_number`` rows are the leading bars as given. The first drawn line
        starts from the last of those bars, and processing then resumes at bar ``line_number``.
        """
        df = self.df
        n = self.line_number
        dates = df["date"].tolist()
        closes = df["close"].tolist()
        if len(df) < n:
            raise ValueError(f"need at least {n} rows for a line break chart, got {len(df)}")

        self._lines = []
        for i in range(n):
            self._lines.append(self._line(dates[i], df["open"].iloc[i], closes[i], df["high"].iloc[i], df["low"].iloc[i], True))
        seed_close = self._lines[-1]["close"]
        self._add_line(dates[0], seed_close, closes[0], closes[0] >= seed_close)

        for d, x in zip(dates[n:], closes[n:]):
            prev = self._lines[-1]
            if prev["uptrend"]:
                if self.downtrend_reversal(x):
                    self._add_line(d, prev["open"], x, False)
                elif self.uptrend_reversal(x):
                    self._add_line(d, prev["close"], x, True)
            else:
                if self.uptrend_reversal(x):
                    self._add_line(d, prev["open"], x, True)
                elif self.downtrend_reversal(x):
                    self._add_line(d, prev["close"], x, False)

        out = pd.DataFrame(self._lines)
        return out[["date", "open", "high", "low", "close", "uptrend"]]

    def _add_line(self, date, open_, close, up):
        if up:
            self._lines.append(self._line(date, open_, close, close, open_, True))
        else:
            self._lines.append(self._line(date, open_, close, open_, close, False))

    @staticmethod
    def _line(date, open_, close, high, low, up):
        return {"date": date, "open": open_, "high": high, "low": low, "close": close, "uptrend": up}


class PnF(Instrument):
    """Point and Figure chart with box size and reversal size measured in boxes."""

    def __init__(self, df, box_size=1, reversal_size=3):  # spec: N-000060, N-000011, N-000012
        super().__init__(df)
        self.box_size = box_size
        self.reversal_size = reversal_size

    def brick_size(self):  # spec: N-000061
        return self.box_size

    def get_state(self, uptrend_p1, bricks):  # spec: N-000062
        """State of the column after a move of ``bricks`` boxes (signed: + is up).

        ``uptrend_p1`` is whether the current column is an uptrend (X) column.
        Returns 'up' or 'down' for a continuing column, 'up_reversal' or 'down_reversal'
        when the move reverses the column, and 'none' otherwise.
        """
        if bricks == 0:
            return "none"
        if uptrend_p1:
            if bricks > 0:
                return "up"
            return "down_reversal" if -bricks >= self.reversal_size else "none"
        if bricks < 0:
            return "down"
        return "up_reversal" if bricks >= self.reversal_size else "none"

    def roundit(self, x, base):  # spec: N-000063, N-000064
        """Round ``x`` to the nearest multiple of ``base`` (halves round up) and return an int."""
        return int(math.floor(x / base + 0.5) * base)

    def get_ohlc_data(self, source):  # spec: N-000065, N-000012
        """PnF columns as an OHLC DataFrame. ``source`` is 'close' or 'hl' (high then low)."""
        columns = self._columns(self._box_steps(source))
        rows = []
        for date, up, start, extreme in columns:
            top, bottom = max(start, extreme) * self.box_size, min(start, extreme) * self.box_size
            if up:
                rows.append((date, bottom, top, bottom, top, True))
            else:
                rows.append((date, top, top, bottom, bottom, False))
        return pd.DataFrame(rows, columns=["date", "open", "high", "low", "close", "uptrend"])

    def get_bar_ohlc_data(self, source):  # spec: N-000066
        """Input bars with prices rounded to box levels. 'close' gives one value per bar."""
        df = self.df
        if source == "close":
            levels = [self.roundit(c, self.box_size) for c in df["close"]]
            return pd.DataFrame({"date": df["date"], "open": levels, "high": levels, "low": levels, "close": levels})
        if source == "hl":
            return pd.DataFrame({
                "date": df["date"],
                "open": [self.roundit(v, self.box_size) for v in df["open"]],
                "high": [self.roundit(v, self.box_size) for v in df["high"]],
                "low": [self.roundit(v, self.box_size) for v in df["low"]],
                "close": [self.roundit(v, self.box_size) for v in df["close"]],
            })
        raise ValueError(f"unknown source {source!r}; expected 'close' or 'hl'")

    def _box_steps(self, source):
        df = self.df
        if source == "close":
            return [(d, self._box_index(c)) for d, c in zip(df["date"], df["close"])]
        if source == "hl":
            steps = []
            for d, h, lo in zip(df["date"], df["high"], df["low"]):
                steps.append((d, self._box_index(h)))
                steps.append((d, self._box_index(lo)))
            return steps
        raise ValueError(f"unknown source {source!r}; expected 'close' or 'hl'")

    def _box_index(self, price):
        return int(math.floor(price / self.box_size + 0.5))

    def _columns(self, steps):
        """Walk box indices and return finished and in-progress columns as (date, up, start, extreme)."""
        columns = []
        up = None
        start = extreme = None
        col_date = None
        for date, k in steps:
            if extreme is None:
                start = extreme = k
                col_date = date
                continue
            move = k - extreme
            if up is None:
                if move == 0:
                    continue
                up = move > 0
                start = extreme
            state = self.get_state(up, move)
            if state in ("up", "down"):
                extreme = k
                col_date = date
            elif state.endswith("reversal"):
                columns.append((col_date, up, start, extreme))
                up = not up
                start = extreme + 1 if up else extreme - 1
                extreme = k
                col_date = date
        if up is not None:
            columns.append((col_date, up, start, extreme))
        return columns
