"""File opening with the dash-as-stdin/stdout rule, lazy and atomic modes."""

import io
import os
import sys
import tempfile
from contextlib import contextmanager


class _LazyFile:
    """Write-mode file that opens on first I/O."""

    def __init__(self, filename, mode, encoding, errors, atomic):
        self._filename = filename
        self._mode = mode
        self._encoding = encoding
        self._errors = errors
        self._atomic = atomic
        self._fh = None
        self._tmp = None
        self.name = filename
        self.closed = False

    def _open(self):
        if self._fh is not None:
            return self._fh
        if self._atomic:
            d = os.path.dirname(os.path.abspath(self._filename))
            fd, self._tmp = tempfile.mkstemp(dir=d, prefix=".optlyn-")
            os.close(fd)
            target = self._tmp
        else:
            target = self._filename
        kwargs = {}
        if "b" not in self._mode:
            kwargs = {"encoding": self._encoding, "errors": self._errors}
        self._fh = open(target, self._mode, **kwargs)
        return self._fh

    def write(self, data):
        return self._open().write(data)

    def flush(self):
        if self._fh is not None:
            self._fh.flush()

    def close(self):
        if self.closed:
            return
        self.closed = True
        if self._fh is not None:
            self._fh.close()
            if self._atomic and self._tmp is not None:
                os.replace(self._tmp, self._filename)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def __getattr__(self, item):
        return getattr(self._open(), item)


class _NoCloseWrapper(io.TextIOWrapper):
    pass


def _std_stream(mode):
    if "w" in mode or "a" in mode:
        stream = sys.stdout
    else:
        stream = sys.stdin
    if "b" in mode:
        return getattr(stream, "buffer", stream)
    return stream


class _Uncloseable:
    """Proxy that keeps standard streams open when the context block ends."""

    def __init__(self, stream):
        self._stream = stream

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def __getattr__(self, item):
        return getattr(self._stream, item)

    def __iter__(self):
        return iter(self._stream)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open ``filename``; ``-`` means standard input or output by mode."""
    if filename == "-":
        return _Uncloseable(_std_stream(mode))
    if lazy and ("w" in mode or "a" in mode):
        return _LazyFile(filename, mode, encoding, errors, atomic)
    if "w" in mode and atomic:
        d = os.path.dirname(os.path.abspath(filename))
        fd, tmp = tempfile.mkstemp(dir=d, prefix=".optlyn-")
        os.close(fd)
        kwargs = {} if "b" in mode else {"encoding": encoding, "errors": errors}
        fh = open(tmp, mode, **kwargs)
        return _AtomicFile(fh, tmp, filename)
    kwargs = {} if "b" in mode else {"encoding": encoding, "errors": errors}
    return open(filename, mode, **kwargs)


class _AtomicFile:
    def __init__(self, fh, tmp, target):
        self._fh = fh
        self._tmp = tmp
        self._target = target
        self.name = target
        self.closed = False

    def close(self):
        if self.closed:
            return
        self.closed = True
        self._fh.close()
        os.replace(self._tmp, self._target)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def __getattr__(self, item):
        return getattr(self._fh, item)


@contextmanager
def open_file_ctx(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    f = open_file(filename, mode, encoding, errors, lazy, atomic)
    try:
        yield f
    finally:
        f.close()
