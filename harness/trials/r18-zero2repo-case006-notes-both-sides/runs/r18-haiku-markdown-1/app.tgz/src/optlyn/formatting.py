"""Text wrapping and help-page formatting helpers."""

import re
import shutil
import textwrap

DEFAULT_MAX_CONTENT_WIDTH = 80
HELP_MAX_CONTENT_WIDTH = 100
_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")


def strip_ansi(text):
    return _ANSI_RE.sub("", text)


def detect_width(max_content_width=DEFAULT_MAX_CONTENT_WIDTH):
    cols = shutil.get_terminal_size((max_content_width + 2, 20)).columns
    return max(20, min(cols - 2, max_content_width))


def wrap_text(
    text,
    width=78,
    initial_indent="",
    subsequent_indent="",
    preserve_paragraphs=False,
):
    """Rewrap text to ``width``. Never fails on any string.

    Paragraphs are separated by blank lines. Single newlines are not kept as
    hard breaks. A paragraph whose first line is only a backspace character
    is kept verbatim (minus the backspace line).
    """
    if text is None:
        return ""
    text = str(text)
    out_paras = []
    for para in re.split(r"\n\s*\n", text.strip("\n")):
        lines = para.split("\n")
        if lines and lines[0].strip("\x08") == "" and lines[0] != "":
            # no-rewrap paragraph: drop the backspace line, keep line breaks
            kept = "\n".join(lines[1:])
            out_paras.append(kept)
            continue
        flat = " ".join(line.strip() for line in lines if line.strip())
        if not flat:
            continue
        out_paras.append(
            textwrap.fill(
                flat,
                width=max(10, width),
                initial_indent=initial_indent,
                subsequent_indent=subsequent_indent,
                break_long_words=False,
                break_on_hyphens=False,
            )
        )
    sep = "\n" if preserve_paragraphs else "\n\n"
    return sep.join(out_paras)


def ellipsize(text, limit):
    if len(text) <= limit:
        return text
    if limit <= 3:
        return "." * limit
    return text[: limit - 3].rstrip() + "..."


def first_sentence(text):
    text = (text or "").strip()
    if not text:
        return ""
    m = re.search(r"[.!?](\s|$)", text)
    return text[: m.end()].strip() if m else text


def first_paragraph(text):
    text = (text or "").strip()
    if not text:
        return ""
    para = re.split(r"\n\s*\n", text)[0]
    return " ".join(line.strip() for line in para.split("\n")).strip()
