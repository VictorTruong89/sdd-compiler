"""Command, Group and CommandCollection: parsing, dispatch, help, and main()."""

import os
import sys

from .context import Context, get_current_context
from .exceptions import (Abort, BadParameter, Exit, MissingParameter, OptlynError,
                         UsageError)
from .formatting import (DEFAULT_MAX_CONTENT_WIDTH, HELP_MAX_CONTENT_WIDTH, detect_width,
                         ellipsize, first_paragraph, first_sentence, wrap_text)
from .params import Argument, Option
from .parser import OptionParser, bind_arguments

CHAIN_MARKER = "*"
_SUFFIXES = ("_command", "_cmd", "_group", "_grp")


def _derive_name(func_name):
    name = func_name.lower().replace("_", "-")
    for suf in _SUFFIXES:
        s = suf.replace("_", "-")
        if name.endswith(s) and len(name) > len(s):
            return name[: -len(s)]
    return name


class NoArgsHelp(UsageError):
    """No arguments on a command configured to show help: help goes to stderr, exit 2."""

    def __init__(self, ctx):
        super().__init__("", ctx)

    def show(self, file=None):
        file = file or sys.stderr
        file.write(self.ctx.command.get_help(self.ctx) + "\n")


class Command:
    is_group = False

    def __init__(self, name=None, callback=None, params=None, help=None, epilog=None,
                 short_help=None, options_metavar="[OPTIONS]", context_settings=None,
                 add_help_option=True, no_args_is_help=False, deprecated=False,
                 hidden=False, allow_extra_args=False, ignore_unknown_options=False,
                 allow_interspersed_args=True, **extra):
        self.name = name
        self.callback = callback
        self.params = list(params or [])
        self.arguments = [p for p in self.params if isinstance(p, Argument)]
        if help is None and callback is not None and callback.__doc__:
            help = callback.__doc__
        self.help = self._clean_help(help)
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.context_settings = dict(context_settings or {})
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.deprecated = deprecated
        self.hidden = hidden
        self.allow_extra_args = allow_extra_args
        self.ignore_unknown_options = ignore_unknown_options
        self.allow_interspersed_args = allow_interspersed_args
        self._help_cache = {}
        self.deprecation_note = deprecated if isinstance(deprecated, str) else None

    @staticmethod
    def _clean_help(text):
        if text is None:
            return None
        if "\x0c" in text:
            text = text.split("\x0c", 1)[0]
        return text

    # --- parameters ---------------------------------------------------
    def get_params(self, ctx):
        params = list(self.params)
        if self.add_help_option:
            help_opt = self._help_option(ctx)
            if help_opt is not None:
                params.append(help_opt)
        return params

    def _help_option(self, ctx):
        names = list(ctx.help_option_names or [])
        used = set()
        for p in self.params:
            used.update(getattr(p, "opts", []))
        names = [n for n in names if n not in used]
        if not names:
            return None
        key = tuple(names)
        if key not in self._help_cache:
            self._help_cache[key] = Option(
                names, is_flag=True, is_eager=True, expose_value=False,
                help="Show this message and exit.", callback=_help_callback,
            )
        return self._help_cache[key]

    # --- context ------------------------------------------------------
    def make_context(self, info_name, args, parent=None, **extra):
        settings = dict(self.context_settings)
        settings.update(extra)
        dm = settings.pop("default_map", None)
        if dm is None and parent is not None and isinstance(parent.default_map, dict):
            dm = parent.default_map.get(info_name)
        ctx = Context(self, parent=parent, info_name=info_name, default_map=dm, **settings)
        if ctx.command_path == "" and info_name:
            ctx.info_name = info_name
        ctx.protected_args = []
        ctx.extra_args = []
        ctx.standalone_mode = settings.get("standalone_mode", True)
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsHelp(ctx)
        parser = OptionParser(self, ctx)
        res = parser.parse(list(args))
        bound = bind_arguments(self, res.positionals, ctx) if not self.is_group else \
            bind_arguments(self, res.positionals, ctx)
        if self.is_group:
            ctx.protected_args = res.rest
        self._process_params(ctx, res, bound)
        return ctx

    def _process_params(self, ctx, res, bound):
        params = self.get_params(ctx)
        # eager parameters: the one the user typed first wins
        eager = []
        for p in params:
            if p.is_eager and p in res.occurrences:
                eager.append((res.occurrences[p][0]["idx"], p))
        if eager:
            eager.sort(key=lambda t: t[0])
            p = eager[0][1]
            value, src = p.resolve(ctx, res.occurrences[p])
            if p.callback and value:
                ctx.set_source(p.name, src)
                p.callback(ctx, p, value)
        for p in params:
            if p.is_eager:
                continue
            if isinstance(p, Argument):
                occ = bound.get(p, [])
            else:
                occ = res.occurrences.get(p, [])
            value, src = p.resolve(ctx, occ)
            empty = value is None or (getattr(p, "multiple", False) or p.nargs == -1) and value == ()
            if p.required and empty:
                raise MissingParameter("missing required", ctx=ctx, param=p)
            if p.deprecated and occ:
                _warn(f"DeprecationWarning: The {('argument' if isinstance(p, Argument) else 'option')} "
                      f"{p.human_name!r} is deprecated." + (f" {p.deprecated}" if isinstance(p.deprecated, str) else ""))
            if p.callback is not None:
                value = p.callback(ctx, p, value)
            ctx.set_source(p.name, src)
            if p.expose_value:
                ctx.params[p.name] = value

    # --- invocation ---------------------------------------------------
    def _callback_kwargs(self, ctx):
        kwargs = {}
        for p in self.get_params(ctx):
            if p.expose_value and p.name in ctx.params:
                kwargs[p.name] = ctx.params[p.name]
        return kwargs

    def _run_callback(self, ctx):
        if self.callback is None:
            return None
        kwargs = self._callback_kwargs(ctx)
        with ctx:
            return self.callback(**kwargs)

    def invoke(self, ctx):
        with ctx:
            try:
                if self.deprecated:
                    note = f" {self.deprecation_note}" if self.deprecation_note else ""
                    _warn(f"DeprecationWarning: The command {ctx.command_path or self.name!r} is deprecated.{note}")
                return self._run_callback(ctx)
            finally:
                ctx.close()

    def get_help(self, ctx):
        width = _wrap_width(ctx)
        lines = []
        lines.append(self.format_usage(ctx))
        lines.append("")
        desc = self.help
        if desc:
            lines.append(wrap_text(desc, width=width))
            lines.append("")
        args = [a for a in self.arguments if a.help]
        if args:
            lines.append("Positional arguments:")
            for a in args:
                lines.append(f"  {self._arg_placeholder(a)}  {wrap_text(a.help, width=width - 30)}")
            lines.append("")
        opts = [p for p in self.get_params(ctx) if isinstance(p, Option) and not p.hidden]
        if opts:
            lines.append("Options:")
            for p in opts:
                lines.extend(self._format_option(ctx, p, width))
            lines.append("")
        if self.epilog:
            lines.append(wrap_text(self.epilog, width=width))
            lines.append("")
        return "\n".join(lines).rstrip("\n") + "\n"

    def _arg_placeholder(self, a):
        return a.metavar or a.name.upper()

    def _format_option(self, ctx, p, width):
        names = ", ".join(p.opts + p.secondary_opts)
        takes = not (p.is_flag or p.count)
        if takes:
            meta = p.metavar or (p.type.get_default_type_name() if p.type else "")
            if meta:
                names = f"{names} {meta}"
        extras = []
        if p.help:
            extras.append(p.help)
        show = p.show_default if p.show_default is not None else ctx.show_default
        if show and not (p.is_flag and p.default is False):
            if p.show_default is not None and isinstance(p.show_default, str):
                extras.append(f"[default: {p.show_default}]")
            elif p.default is not None:
                d = p.default() if callable(p.default) else p.default
                extras.append(f"[default: {d}]")
        if p.show_envvar and p.get_env_names():
            extras.append(f"[env var: {', '.join(p.get_env_names())}]")
        if p.deprecated:
            extras.append("[deprecated]")
        if p.required and not p.is_flag:
            extras.append("[required]")
        text = " ".join(extras)
        head = f"  {names}"
        if len(head) < 30 and text:
            lines = [head.ljust(30) + wrap_text(text, width=max(20, width - 32), subsequent_indent=" " * 32).replace("\n\n", "\n")]
        else:
            lines = [head]
            if text:
                lines.append(" " * 32 + wrap_text(text, width=max(20, width - 32)))
        return lines

    def format_usage(self, ctx):
        parts = [ctx.command_path or self.name or "command"]
        if self.params or self.add_help_option:
            if any(isinstance(p, Option) and not p.is_eager for p in self.params) or self.add_help_option:
                parts.append(self.options_metavar)
        for a in self.arguments:
            ph = self._arg_placeholder(a)
            if a.nargs == -1:
                ph = f"{ph}..."
            parts.append(ph if a.required else f"[{ph}]")
        return "Usage: " + " ".join(parts)

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True, **extra):
        if args is None:
            args = sys.argv[1:]
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else (self.name or "cli")
        handled = _maybe_complete(self, prog_name, complete_var, args)
        if handled is not None:
            # completion mode never runs the callback
            if standalone_mode:
                sys.exit(handled)
            return None
        try:
            ctx = self.make_context(prog_name, args, standalone_mode=standalone_mode,
                                    prog_name=prog_name, **extra)
            rv = self.invoke(ctx)
            if not standalone_mode:
                return rv
            sys.exit(0)
        except Exit as exc:
            if not standalone_mode:
                return None
            sys.exit(exc.exit_code)
        except OptlynError as exc:
            if not standalone_mode:
                raise
            exc.show()
            sys.exit(exc.exit_code)
        except (KeyboardInterrupt, EOFError):
            if not standalone_mode:
                raise Abort()
            Abort().show()
            sys.exit(1)

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"


class Group(Command):
    is_group = True

    def __init__(self, name=None, commands=None, invoke_without_command=False,
                 no_args_is_help=None, subcommand_metavar=None, chain=False,
                 result_callback=None, allow_group_option_mixing=False, **kwargs):
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        super().__init__(name=name, no_args_is_help=no_args_is_help, **kwargs)
        self.commands = {}
        self.invoke_without_command = invoke_without_command
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self.result_callback_fn = result_callback
        self.allow_group_option_mixing = allow_group_option_mixing
        for n, c in (commands or {}).items():
            self.add_command(c, n)

    def add_command(self, cmd, name=None):
        name = name or cmd.name
        if self.chain and cmd.is_group:
            raise TypeError("Groups cannot be nested under a chaining group.")
        if name is None:
            raise TypeError("command needs a name")
        self.commands[name] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as _command

        def decorator(f):
            cmd = _command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd
        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as _group

        def decorator(f):
            cmd = _group(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd
        return decorator

    def result_callback(self):
        def decorator(f):
            self.result_callback_fn = f
            return f
        return decorator

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        return self.commands.get(cmd_name)

    def _visible_children(self, ctx):
        out = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is not None and not cmd.hidden:
                out.append((name, cmd))
        return out

    def get_help(self, ctx):
        base = super().get_help(ctx)
        children = self._visible_children(ctx)
        if not children:
            return base
        width = _wrap_width(ctx)
        lines = ["Commands:"]
        for name, cmd in children:
            sh = cmd.short_help or ellipsize(first_sentence(cmd.help or ""), 45)
            lines.append(f"  {name}  {sh}".rstrip())
        section = "\n".join(lines) + "\n"
        # insert the command section before the epilog, if any
        if self.epilog:
            idx = base.rfind(self.epilog)
            return base[:idx] + section + "\n" + base[idx:]
        return base + "\n" + section

    def format_usage(self, ctx):
        base = super().format_usage(ctx)
        if self.chain:
            return base + " " + (self.subcommand_metavar or "COMMAND [ARGS]... [COMMAND [ARGS]...]...")
        if self.invoke_without_command:
            return base + " " + (self.subcommand_metavar or "[COMMAND] [ARGS]...")
        return base + " " + (self.subcommand_metavar or "COMMAND [ARGS]...")

    def invoke(self, ctx):
        with ctx:
            try:
                if self.deprecated:
                    _warn(f"DeprecationWarning: The command {self.name!r} is deprecated.")
                if self.chain:
                    return self._invoke_chain(ctx)
                return self._invoke_single(ctx)
            finally:
                ctx.close()

    def _invoke_single(self, ctx):
        tokens = ctx.protected_args
        if not tokens:
            ctx.invoked_subcommand = None
            if not self.invoke_without_command:
                raise UsageError("Missing command.", ctx)
            rv = self._run_callback(ctx)
            if self.result_callback_fn is not None:
                return self.result_callback_fn(rv, **ctx.params)
            return rv
        name, rest = tokens[0], tokens[1:]
        cmd = self.get_command(ctx, name)
        if cmd is None:
            raise UsageError(f"No such command {name!r}.", ctx)
        ctx.invoked_subcommand = name
        self._run_callback(ctx)
        sub = cmd.make_context(name, rest, parent=ctx, standalone_mode=ctx.standalone_mode)
        rv = cmd.invoke(sub)
        if self.result_callback_fn is not None:
            return self.result_callback_fn(rv, **ctx.params)
        return rv

    def _invoke_chain(self, ctx):
        tokens = ctx.protected_args
        segments = []
        i = 0
        while i < len(tokens):
            name = tokens[i]
            cmd = self.get_command(ctx, name)
            if cmd is None:
                raise UsageError(f"No such command {name!r}.", ctx)
            if cmd.is_group:
                raise UsageError("Groups cannot be chained.", ctx)
            j = i + 1
            while j < len(tokens) and self.get_command(ctx, tokens[j]) is None:
                j += 1
            segments.append((name, cmd, tokens[i + 1:j]))
            i = j
        ctx.invoked_subcommand = CHAIN_MARKER
        self._run_callback(ctx)
        results = []
        for name, cmd, args in segments:
            sub = cmd.make_context(name, args, parent=ctx, standalone_mode=ctx.standalone_mode)
            results.append(cmd.invoke(sub))
        if self.result_callback_fn is not None:
            self.result_callback_fn(results, **ctx.params)
        return results


class CommandCollection(Group):
    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name=name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = set(self.commands)
        for src in self.sources:
            names.update(src.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        for src in self.sources:
            cmd = src.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None


def _wrap_width(ctx):
    if ctx.terminal_width:
        return ctx.terminal_width
    return detect_width(ctx.max_content_width or DEFAULT_MAX_CONTENT_WIDTH)


def _warn(text):
    from .terminal import echo
    echo(text, err=True)


def _help_callback(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    from .terminal import echo
    echo(ctx.command.get_help(ctx), nl=False)
    raise Exit(0)


def _maybe_complete(cmd, prog_name, complete_var, args):
    from .completion import handle_completion
    var = complete_var or "_" + prog_name.upper().replace("-", "_") + "_COMPLETE"
    value = os.environ.get(var)
    if not value:
        return None
    return handle_completion(cmd, prog_name, value, args)
