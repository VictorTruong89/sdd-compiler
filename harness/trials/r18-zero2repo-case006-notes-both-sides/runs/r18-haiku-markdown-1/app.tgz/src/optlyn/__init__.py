"""Optlyn: a command line interface composition kit.

Importing this package performs no I/O and starts no processes.
"""

from .commands import Command, CommandCollection, Group
from .context import Context, get_current_context
from .decorators import (
    argument,
    command,
    confirmation_option,
    custom_version_option,
    group,
    help_option,
    make_pass_decorator,
    option,
    pass_context,
    pass_obj,
    password_option,
    version_option,
)
from .exceptions import Abort, BadParameter, Exit, OptlynError, UsageError
from .params import Argument, Option, Parameter
from .terminal import (
    clear,
    confirm,
    echo,
    echo_via_pager,
    edit,
    get_app_dir,
    get_pager_file,
    getchar,
    format_filename,
    launch,
    pause,
    progressbar,
    prompt,
    secho,
    style,
    unstyle,
)
from .fileio import open_file
from .types import (
    BOOL,
    DATETIME,
    FLOAT,
    INT,
    STRING,
    UNPROCESSED,
    UUID,
    Choice,
    DateTime,
    File,
    FloatRange,
    IntRange,
    ParamType,
    Path,
    Tuple,
)

__version__ = "0.1.0"

__all__ = [
    "command", "group", "option", "argument", "help_option", "version_option",
    "custom_version_option", "password_option", "confirmation_option", "pass_context",
    "pass_obj", "make_pass_decorator",
    "Command", "Group", "CommandCollection", "Context", "Option", "Parameter",
    "ParamType", "BadParameter", "Abort", "UsageError", "Exit", "OptlynError",
    "STRING", "INT", "FLOAT", "BOOL", "UUID", "UNPROCESSED",
    "Choice", "DateTime", "IntRange", "FloatRange", "Tuple", "File", "Path",
    "echo", "secho", "style", "unstyle", "echo_via_pager", "get_pager_file",
    "progressbar", "prompt", "confirm", "getchar", "pause", "edit", "launch", "clear",
    "get_app_dir", "get_current_context", "format_filename", "open_file",
]
