"""Terminal output and interaction helpers."""

import contextlib
import io
import os
import re
import subprocess
import sys
import time

from .context import get_current_context
from .exceptions import Abort, BadParameter
from .formatting import strip_ansi

_COLORS = {
    "black": 30, "red": 31, "green": 32, "yellow": 33,
    "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
    "reset": 39,
}
_STYLE_CODES = {
    "bold": (1, 22), "dim": (2, 22), "underline": (4, 24), "overline": (53, 55),
    "italic": (3, 23), "blink": (5, 25), "reverse": (7, 27), "strikethrough": (9, 29),
}


def _color_code(color, base):
    """base 38 for fg, 48 for bg."""
    if isinstance(color, str):
        if color not in _COLORS:
            raise TypeError(f"unknown color {color!r}")
        code = _COLORS[color]
        if color == "reset":
            return str(code + 10 if base == 48 else code)
        return str(code + (10 if base == 48 else 0))
    if isinstance(color, bool):
        raise TypeError("invalid color")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise TypeError("color index must be 0-255")
        return f"{base};5;{color}"
    if isinstance(color, (tuple, list)) and len(color) == 3 and all(
        isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
    ):
        return f"{base};2;{color[0]};{color[1]};{color[2]}"
    raise TypeError(f"invalid color {color!r}")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True):
    """Wrap ``text`` in ANSI SGR sequences. Invalid colors raise TypeError."""
    bits = []
    if fg is not None:
        bits.append(_color_code(fg, 38))
    if bg is not None:
        bits.append(_color_code(bg, 48))
    flags = dict(bold=bold, dim=dim, underline=underline, overline=overline,
                 italic=italic, blink=blink, reverse=reverse, strikethrough=strikethrough)
    for name, on in flags.items():
        if on is not None:
            on_code, _ = _STYLE_CODES[name]
            bits.append(str(on_code) if on else str(_STYLE_CODES[name][1]))
    if not bits:
        return text
    prefix = "\x1b[" + ";".join(bits) + "m"
    suffix = "\x1b[0m" if reset else ""
    return prefix + text + suffix


def unstyle(text):
    return strip_ansi(text)


def _ctx_color():
    ctx = get_current_context(silent=True)
    return ctx.color if ctx is not None else None


def _is_tty(stream):
    try:
        return bool(stream.isatty())
    except Exception:
        return False


def _should_strip(stream, color):
    if color is None:
        color = _ctx_color()
    if color is True:
        return False
    if color is False:
        return True
    return not _is_tty(stream)


def _write(stream, text):
    try:
        stream.write(text)
    except UnicodeEncodeError:
        enc = getattr(stream, "buffer", None)
        if enc is not None:
            stream.flush()
            enc.write(text.encode("utf-8", "replace"))
        else:
            stream.write(text.encode("ascii", "replace").decode("ascii"))
    stream.flush()


def echo(message=None, file=None, nl=True, err=False, color=None):
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        buf = getattr(file, "buffer", None)
        data = message + (b"\n" if nl else b"")
        if buf is not None:
            file.flush()
            buf.write(data)
            buf.flush()
        else:
            file.write(data.decode("utf-8", "replace"))
        return
    text = str(message)
    if _should_strip(file, color):
        text = strip_ansi(text)
    if nl:
        text += "\n"
    _write(file, text)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None:
        message = style(str(message), **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


def _interactive():
    return _is_tty(sys.stdin) or _is_tty(sys.stdout)


def echo_via_pager(text_or_generator, color=None):
    if callable(text_or_generator):
        source = text_or_generator()
    else:
        source = text_or_generator
    if isinstance(source, str):
        chunks = [source]
    else:
        chunks = source
    if not _interactive():
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    pager = os.environ.get("PAGER")
    if not pager:
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    proc = subprocess.Popen(pager, shell=True, stdin=subprocess.PIPE)
    try:
        strip = _should_strip(proc.stdin, color)
        for chunk in chunks:
            text = strip_ansi(chunk) if strip else chunk
            proc.stdin.write(text.encode("utf-8", "replace"))
            proc.stdin.flush()
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        proc.wait()


@contextlib.contextmanager
def get_pager_file(color=None):
    buf = io.StringIO()
    yield buf
    echo_via_pager(buf.getvalue(), color=color)


class ProgressBar:
    def __init__(self, iterable, length, label, hidden):
        self.iterable = iterable
        self.length = length if length is not None else (
            len(iterable) if iterable is not None and hasattr(iterable, "__len__") else None
        )
        self.label = label
        self.hidden = hidden or not _is_tty(sys.stdout)
        self.pos = 0
        self.start = time.time()
        if self.hidden and label and not hidden:
            echo(label)

    def __iter__(self):
        if self.iterable is None:
            return
        for item in self.iterable:
            yield item
            self.update(1)

    def update(self, n_steps):
        self.pos += n_steps
        if self.hidden or not self.length:
            return
        frac = min(1.0, self.pos / self.length)
        elapsed = time.time() - self.start
        eta = (elapsed / frac - elapsed) if frac > 0 else 0
        width = 30
        filled = int(width * frac)
        bar = "#" * filled + "-" * (width - filled)
        sys.stdout.write(f"\r{self.label or ''} [{bar}] {self.pos}/{self.length} eta {int(eta)}s")
        sys.stdout.flush()


@contextlib.contextmanager
def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    bar = ProgressBar(iterable, length, label, hidden)
    try:
        yield bar
    finally:
        if not bar.hidden and bar.length:
            sys.stdout.write("\n")
            sys.stdout.flush()


def _read_line(prompt_text, hide_input):
    if hide_input:
        import getpass
        try:
            return getpass.getpass(prompt_text)
        except (EOFError, KeyboardInterrupt):
            raise Abort()
    echo(prompt_text, nl=False)
    try:
        line = sys.stdin.readline()
    except KeyboardInterrupt:
        raise Abort()
    if line == "":
        raise Abort()
    return line.rstrip("\r\n")


def prompt(text, default=None, hide_input=False, confirmation_prompt=False,
           type=None, value_proc=None, prompt_suffix=": ", show_default=True,
           err=False):
    from .types import to_type, STRING

    ptype = to_type(type) if type is not None else (
        to_type(default.__class__) if default is not None and not callable(default) else STRING
    )
    while True:
        shown_default = default
        if callable(shown_default):
            shown_default = shown_default()
        suffix = ""
        if show_default and shown_default is not None:
            suffix = f" [{shown_default}]"
        raw = _read_line(f"{text}{suffix}{prompt_suffix}", hide_input)
        if raw == "" and shown_default is not None:
            value = shown_default
        else:
            value = raw
        try:
            value = ptype.convert(value, None, None)
        except BadParameter as exc:
            echo(f"Error: {exc.message}", err=True)
            continue
        if confirmation_prompt:
            again = _read_line(f"Repeat for confirmation{prompt_suffix}", hide_input)
            if again != raw:
                echo("Error: the two entered values do not match", err=True)
                continue
        return value


def confirm(text, default=False, abort=False, prompt_suffix=": ",
            show_default=True, err=False):
    hint = " [Y/n]" if default else " [y/N]"
    if not show_default:
        hint = ""
    while True:
        raw = _read_line(f"{text}{hint}{prompt_suffix}", False).strip().lower()
        if raw == "":
            answer = default
        elif raw in ("y", "yes"):
            answer = True
        elif raw in ("n", "no"):
            answer = False
        else:
            echo("Error: invalid input", err=True)
            continue
        if not answer and abort:
            raise Abort()
        return answer


def getchar(echo_char=False):
    try:
        import termios
        import tty
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
        text = ch.decode("utf-8", "replace")
    except (ImportError, OSError, ValueError, io.UnsupportedOperation):
        text = sys.stdin.read(1)
    if text == "\x03":
        raise KeyboardInterrupt()
    if text == "\x04" or text == "":
        raise EOFError()
    if echo_char:
        echo(text, nl=False)
    return text


def pause(info=None, err=False):
    if info is None:
        info = "Press any key to continue..."
    if not _interactive():
        return
    echo(info, nl=False, err=err)
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass
    echo(err=err)


def clear():
    if not _is_tty(sys.stdout):
        return
    sys.stdout.write("\x1b[2J\x1b[H")
    sys.stdout.flush()


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt",
         filename=None):
    import tempfile

    editor = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR") or "vi"
    if filename is not None:
        cmd = f"{editor} {_quote(filename)}"
        subprocess.call(cmd, shell=True, env={**os.environ, **(env or {})})
        return None
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(text or "")
        before = os.path.getmtime(path)
        subprocess.call(f"{editor} {_quote(path)}", shell=True,
                        env={**os.environ, **(env or {})})
        with open(path, encoding="utf-8") as fh:
            result = fh.read()
        if require_save and os.path.getmtime(path) == before and result == (text or ""):
            return None
        return result
    finally:
        os.unlink(path)


def _quote(s):
    return "'" + s.replace("'", "'\"'\"'") + "'"


def launch(url, wait=False, locate=False):
    if sys.platform == "darwin":
        args = ["open"] + (["-R"] if locate else []) + [url]
    elif sys.platform == "win32":
        os.startfile(url)  # type: ignore[attr-defined]
        return 0
    else:
        args = ["xdg-open", url]
    proc = subprocess.Popen(args)
    if wait:
        return proc.wait()
    return 0


def get_app_dir(app_name, roaming=True, force_posix=False):
    if force_posix or sys.platform not in ("darwin", "win32"):
        if force_posix and sys.platform in ("darwin", "win32"):
            return os.path.join(os.path.expanduser("~"), "." + app_name.lower().replace(" ", "-"))
        folder = re.sub(r"\s+", "-", app_name.lower())
        if force_posix:
            return os.path.join(os.path.expanduser("~"), "." + folder)
        base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
        return os.path.join(base, folder)
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~"), "Library", "Application Support", app_name)
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    return os.path.join(base, app_name)


def format_filename(filename, shorten=False):
    if isinstance(filename, bytes):
        text = os.fsdecode(filename)
    else:
        text = os.fspath(filename) if not isinstance(filename, str) else filename
    if shorten:
        text = os.path.basename(text)
    return text.encode("utf-8", "surrogateescape").decode("utf-8", "replace")


def open_file_helper(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    from .fileio import open_file
    return open_file(filename, mode, encoding, errors, lazy, atomic)
