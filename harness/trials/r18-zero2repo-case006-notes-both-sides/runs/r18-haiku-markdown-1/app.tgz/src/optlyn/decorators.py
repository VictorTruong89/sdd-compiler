"""Declaration decorators: command, group, option, argument, and ready-made options."""

import functools
import importlib
import sys

from .commands import Command, CommandCollection, Group, _derive_name
from .context import get_current_context
from .exceptions import Abort, BadParameter, Exit
from .params import Argument, Option
from .terminal import confirm, echo

_ATTR = "__optlyn_params__"


def _take_params(f):
    params = getattr(f, _ATTR, None)
    if params is None:
        return []
    delattr(f, _ATTR)
    params.reverse()
    return params


def _memo(f, param):
    if not hasattr(f, _ATTR):
        setattr(f, _ATTR, [])
    getattr(f, _ATTR).append(param)


def command(name=None, cls=None, **attrs):
    """Turn a function into a Command. ``@command()`` or ``@command``."""
    if callable(name) and not isinstance(name, str):
        return command()(name)

    def decorator(f):
        params = _take_params(f)
        cmd_name = name if name is not None else _derive_name(f.__name__)
        cls_ = cls or Command
        attrs.setdefault("help", f.__doc__)
        return cls_(name=cmd_name, callback=f, params=params, **attrs)

    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a Group. ``@group()`` or ``@group``."""
    if callable(name) and not isinstance(name, str):
        return group()(name)
    if cls is None:
        cls = Group

    def decorator(f):
        params = _take_params(f)
        grp_name = name if name is not None else _derive_name(f.__name__)
        attrs.setdefault("help", f.__doc__)
        return cls(name=grp_name, callback=f, params=params, **attrs)

    return decorator


def option(*param_decls, cls=None, **attrs):
    option_cls = cls or Option

    def decorator(f):
        _memo(f, option_cls(list(param_decls), **attrs))
        return f

    return decorator


def argument(*param_decls, cls=None, **attrs):
    arg_cls = cls or Argument

    def decorator(f):
        _memo(f, arg_cls(list(param_decls), **attrs))
        return f

    return decorator


def _attach(f, param):
    _memo(f, param)
    return f


# --- pass-through decorators -------------------------------------------

def pass_context(f):
    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(f):
    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type, ensure=False):
    def decorator(f):
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            obj = None
            node = ctx
            while node is not None:
                if isinstance(node.obj, object_type):
                    obj = node.obj
                    break
                node = node.parent
            if obj is None:
                if ensure:
                    obj = ctx.ensure_object(object_type) if hasattr(ctx, "ensure_object") else object_type()
                else:
                    raise RuntimeError(f"Managed to invoke callback without a context object of type {object_type.__name__!r} existing.")
            return f(obj, *args, **kwargs)

        return new_func

    return decorator


# --- ready-made options -------------------------------------------------

def _show_help_flag(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.command.get_help(ctx), nl=False)
    raise Exit(0)


def help_option(*param_decls, **kwargs):
    decls = list(param_decls) or ["--help"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _show_help_flag)
    return _DecoratorOption(decls, kwargs)


class _DecoratorOption:
    """Behaves as a decorator when applied to a function, or as an Option when used directly."""

    def __init__(self, decls, attrs):
        self.opt = Option(decls, **attrs)

    def __call__(self, f):
        _memo(f, self.opt)
        return f


def _version_identity(ctx, package_name, prog_name, message, version):
    if version is None:
        version = _detect_version(package_name)
    prog = prog_name or ctx.command.name or ctx.info_name or "cli"
    text = message or "%(prog)s, version %(version)s"
    return text % {"prog": prog, "version": version}


def _detect_version(package_name):
    from importlib import metadata

    if package_name:
        try:
            return metadata.version(package_name)
        except metadata.PackageNotFoundError:
            try:
                mod = importlib.import_module(package_name)
            except ImportError:
                raise RuntimeError(f"{package_name!r} is not installed.")
            pkg = (mod.__spec__.parent or package_name).split(".")[0] if mod.__spec__ else package_name
            return metadata.version(pkg)
    return "unknown"


def version_option(version=None, *param_decls, package_name=None, prog_name=None,
                   message=None, **kwargs):
    decls = list(param_decls) or ["--version"]

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(_version_identity(ctx, package_name, prog_name, message, version))
        raise Exit(0)

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return _DecoratorOption(decls, kwargs)


def custom_version_option(callback_fn, *param_decls, **kwargs):
    decls = list(param_decls) or ["--version"]

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(callback_fn(ctx), nl=True)
        raise Exit(0)

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return _DecoratorOption(decls, kwargs)


def password_option(*param_decls, **kwargs):
    decls = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    return _DecoratorOption(decls, kwargs)


def confirmation_option(*param_decls, **kwargs):
    decls = list(param_decls) or ["--yes"]
    question = kwargs.pop("prompt", "Do you want to continue?")

    def callback(ctx, param, value):
        if value:
            return value
        if ctx.resilient_parsing:
            return value
        confirm(question, abort=True)
        return True

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Confirm the action without prompting.")
    kwargs["callback"] = callback
    return _DecoratorOption(decls, kwargs)
