"""Parameters (options and arguments): declaration, value sources, conversion."""

import os
import re

from . import context as _ctx_mod
from .exceptions import BadParameter, MissingParameter, UsageError
from .types import BOOL, INT, STRING, Tuple, to_type, ParamType

_TRUE_ENV = {"true", "1", "yes", "on", "t", "y"}
_FALSE_ENV = {"false", "0", "no", "off", "f", "n"}
_PREFIX_CHARS = "-/+"


def _is_decl_flag(decl):
    return bool(decl) and decl[0] in _PREFIX_CHARS


def _split_on_off(decl):
    if "/" in decl[1:] and decl[0] in _PREFIX_CHARS:
        on, off = decl.split("/", 1)
        return on, off
    return decl, None


class Parameter:
    kind = "parameter"

    def __init__(self, decls, kind, **attrs):
        self.kind = kind
        self.opts = []
        self.secondary_opts = []
        self.prefixes = set()
        names = []
        for decl in decls:
            on, off = _split_on_off(decl) if _is_decl_flag(decl) else (decl, None)
            if _is_decl_flag(on):
                self.opts.append(on)
                self.prefixes.add(on[0])
                if off:
                    self.secondary_opts.append(off)
                    self.prefixes.add(off[0])
            else:
                names.append(on)
        if len(names) > 1:
            raise TypeError("only one destination name is allowed")
        # destination: explicit identifier, else first long flag, else first short flag
        self.name = self._infer_dest(names + self.opts)
        self.type_arg = attrs.pop("type", None)
        self.default = attrs.pop("default", None)
        self.callback = attrs.pop("callback", None)
        self.nargs = attrs.pop("nargs", 1)
        self.multiple = bool(attrs.pop("multiple", False))
        self.metavar = attrs.pop("metavar", None)
        self.expose_value = attrs.pop("expose_value", True)
        self.is_eager = bool(attrs.pop("is_eager", False))
        self.envvar = attrs.pop("envvar", None)
        self.shell_complete_func = attrs.pop("shell_complete", None)
        self.deprecated = attrs.pop("deprecated", False)
        self.hidden = bool(attrs.pop("hidden", False))
        self.help = attrs.pop("help", None)
        self.show_default = attrs.pop("show_default", None)
        self.show_envvar = bool(attrs.pop("show_envvar", False))
        self._attrs = attrs

    # --- declaration helpers -----------------------------------------
    @staticmethod
    def _infer_dest(names):
        for n in names:
            if n.isidentifier():
                return n
        for n in names:
            if n.startswith("--"):
                return n.lstrip("-").replace("-", "_")
        if names:
            return names[0].lstrip("-").replace("-", "_")
        return None

    @property
    def all_flag_names(self):
        return self.opts + self.secondary_opts

    def _finish_type(self, is_flag=False, count=False):
        if self.type_arg is not None:
            self.type = to_type(self.type_arg)
            return
        if is_flag:
            self.type = BOOL
            return
        if count:
            self.type = INT
            return
        d = self.default
        if isinstance(d, (list, tuple)) and self.multiple and d:
            self.type = to_type(type(d[0]))
        elif d is not None and not callable(d):
            self.type = to_type(type(d))
        else:
            self.type = STRING

    @property
    def is_composite(self):
        return isinstance(self.type, Tuple)

    @property
    def value_arity(self):
        if isinstance(self.type, Tuple):
            return len(self.type.types)
        return self.nargs

    @property
    def human_name(self):
        if self.opts:
            return "/".join(self.opts)
        return self.name

    def get_metavar(self):
        if self.metavar is not None:
            return self.metavar
        return None

    def get_env_names(self):
        if self.envvar is None:
            return []
        if isinstance(self.envvar, str):
            return [self.envvar]
        return list(self.envvar)

    def auto_env_name(self, ctx):
        prefix = ctx.auto_envvar_prefix
        if not prefix or not self.allow_from_autoenv:
            return None
        parts = []
        c = ctx
        path = []
        while c is not None and c.parent is not None:
            path.append(c.info_name)
            c = c.parent
        path.reverse()
        parts = [prefix] + path[:] + [self.name]
        return "_".join(p.replace("-", "_") for p in parts if p).upper()

    # --- conversion ---------------------------------------------------
    def convert(self, ctx, raw):
        return self.type.convert(raw, self, ctx)

    def _convert_tokens(self, ctx, tokens):
        if isinstance(self.type, Tuple):
            return self.type.convert(list(tokens), self, ctx)
        if self.nargs == 1:
            return self.convert(ctx, tokens[0])
        return tuple(self.convert(ctx, t) for t in tokens)

    def _split_env(self, raw):
        if self.is_flag_like:
            return raw
        if self.multiple or self.value_arity != 1:
            if self.type is not None and hasattr(self.type, "split_envvar_value"):
                return self.type.split_envvar_value(raw)
            return raw.split()
        return raw

    def _fail(self, msg, ctx):
        raise BadParameter(msg, ctx=ctx, param=self)

    # --- source lookup ------------------------------------------------
    def env_names_all(self, ctx):
        """Explicit names first, then the automatic prefix name if enabled."""
        names = self.get_env_names()
        auto = self.auto_env_name(ctx)
        if auto and auto not in names:
            names.append(auto)
        return names

    def default_map_value(self, ctx):
        dm = ctx.default_map
        if not dm or not isinstance(dm, dict):
            return None
        if self.name in dm:
            return dm[self.name]
        return None

    def declared_default(self):
        d = self.default
        if callable(d):
            return d()
        return d

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"


class Option(Parameter):
    def __init__(self, param_decls=None, **attrs):
        decls = list(param_decls or [])
        self.is_flag_arg = attrs.pop("is_flag", None)
        self.flag_value_arg = attrs.pop("flag_value", None)
        self.count = bool(attrs.pop("count", False))
        self.required = bool(attrs.pop("required", False))
        self.allow_from_autoenv = attrs.pop("allow_from_autoenv", True)
        self.prompt = attrs.pop("prompt", None)
        self.prompt_required = attrs.pop("prompt_required", True)
        self.hide_input = bool(attrs.pop("hide_input", False))
        self.confirmation_prompt = bool(attrs.pop("confirmation_prompt", False))
        super().__init__(decls, "option", **attrs)
        if not self.opts:
            raise TypeError("an option needs at least one flag name")

        if self.name is None:
            raise TypeError("an option needs a destination name")
        if self.is_flag_arg is None:
            # on/off pairs and explicit is_flag=True are flags; so is a bool-typed option
            # with no value (handled by the decorator); otherwise a value option.
            self.is_flag = bool(self.secondary_opts)
        else:
            self.is_flag = bool(self.is_flag_arg)
        if self.count:
            self.is_flag = False
        if self.is_flag and self.flag_value_arg is None:
            self.flag_value = True
        else:
            self.flag_value = self.flag_value_arg
        if self.count:
            self.default = 0 if self.default is None else self.default
        if self.is_flag and self.default is None:
            self.default = False
        if self.is_flag and self.default is not None:
            self.default = bool(self.default) if not callable(self.default) else self.default
        self._finish_type(is_flag=self.is_flag, count=self.count)
        if self.is_flag:
            self.nargs = 0
        if self.deprecated and self.required:
            raise TypeError("a deprecated option cannot be required")
        if self.deprecated and self.prompt:
            raise TypeError("a deprecated option cannot use a prompt")
        if self.multiple and self.default is not None and not callable(self.default):
            if isinstance(self.default, (str, bytes)) or not isinstance(self.default, (list, tuple)):
                self._bad_default = True

    @property
    def is_flag_like(self):
        return self.is_flag or self.count

    def takes_value(self):
        return not self.is_flag and not self.count and self.nargs > 0

    def resolve(self, ctx, occurrences):
        """Resolve value for this option given ``occurrences``.

        Each occurrence is a dict: {"tokens": [...], "flag": bool|None, "idx": int}.
        Returns (value, source).
        """
        from .context import (PARAM_SOURCE_COMMANDLINE, PARAM_SOURCE_DEFAULT,
                              PARAM_SOURCE_DEFAULT_MAP, PARAM_SOURCE_ENVIRONMENT,
                              PARAM_SOURCE_PROMPT)

        if occurrences:
            if self.count:
                return len(occurrences), PARAM_SOURCE_COMMANDLINE
            if self.is_flag:
                last = occurrences[-1]
                return last["flag"], PARAM_SOURCE_COMMANDLINE
            if self.multiple:
                vals = []
                for occ in occurrences:
                    vals.append(self._convert_tokens(ctx, occ["tokens"]))
                return tuple(vals), PARAM_SOURCE_COMMANDLINE
            last = occurrences[-1]
            if last.get("prompt"):
                return self._run_prompt(ctx), PARAM_SOURCE_PROMPT
            return self._convert_tokens(ctx, last["tokens"]), PARAM_SOURCE_COMMANDLINE

        # Not on the command line.
        if self.prompt is not None and self.prompt_required and not self.deprecated:
            env = self._env_raw(ctx)
            if env is None:
                return self._run_prompt(ctx), PARAM_SOURCE_PROMPT

        env = self._env_raw(ctx)
        if env is not None:
            return self._from_env(ctx, env), PARAM_SOURCE_ENVIRONMENT

        dm = self.default_map_value(ctx)
        if dm is not None:
            return self._from_default_map(ctx, dm), PARAM_SOURCE_DEFAULT_MAP

        if self.count:
            d = self.declared_default()
            return (0 if d is None else d), PARAM_SOURCE_DEFAULT
        if self.is_flag:
            return bool(self.declared_default()) if self.default is not None else False, PARAM_SOURCE_DEFAULT
        if self.multiple:
            d = self.declared_default()
            if d is None:
                return (), PARAM_SOURCE_DEFAULT
            if not isinstance(d, (list, tuple)):
                self._fail("needs an iterable (sequence) default", ctx)
            return tuple(self._convert_default_item(ctx, v) for v in d), PARAM_SOURCE_DEFAULT
        d = self.declared_default()
        if d is None:
            return None, PARAM_SOURCE_DEFAULT
        return self._convert_default_item(ctx, d), PARAM_SOURCE_DEFAULT

    def _convert_default_item(self, ctx, v):
        if isinstance(v, self.type.__class__) and False:
            return v
        if isinstance(self.type, Tuple):
            return self.type.convert(list(v), self, ctx) if not isinstance(v, tuple) else self.type.convert(v, self, ctx)
        try:
            return self.type.convert(v, self, ctx)
        except BadParameter:
            raise

    def _env_raw(self, ctx):
        for name in self.env_names_all(ctx):
            val = os.environ.get(name)
            if val is None:
                continue
            if val.strip() == "":
                continue
            if self.is_flag:
                low = val.strip().lower()
                if low in _TRUE_ENV or low in _FALSE_ENV:
                    return val
                fv = self.flag_value
                if isinstance(fv, str) and val == fv:
                    return val
                continue
            return val
        return None

    def _from_env(self, ctx, raw):
        if self.is_flag:
            low = raw.strip().lower()
            if low in _TRUE_ENV:
                return True if self.flag_value is True else self.flag_value
            if low in _FALSE_ENV:
                return False
            if isinstance(self.flag_value, str) and raw == self.flag_value:
                return self.flag_value
            self._fail(f"{raw!r} is not a valid boolean.", ctx)
        if self.multiple or self.value_arity != 1:
            parts = self._split_env(raw)
            if self.multiple:
                return tuple(self._convert_tokens(ctx, [p]) if self.value_arity == 1 else self._convert_tokens(ctx, p) for p in parts)
            return self._convert_tokens(ctx, parts)
        return self.convert(ctx, raw)

    def _from_default_map(self, ctx, dm):
        if self.is_flag:
            return bool(dm) if not isinstance(dm, str) else dm.strip().lower() in _TRUE_ENV
        if self.multiple:
            if isinstance(dm, str):
                if self.value_arity != 1:
                    dm = dm.split()
                else:
                    self._fail("needs an iterable (sequence) default", ctx)
            return tuple(self.convert(ctx, v) for v in dm)
        if isinstance(dm, str) and self.value_arity != 1:
            return self._convert_tokens(ctx, dm.split())
        if isinstance(dm, (list, tuple)) and self.value_arity != 1:
            return self._convert_tokens(ctx, list(dm))
        return self._convert_default_item(ctx, dm)

    def _run_prompt(self, ctx):
        from .terminal import prompt as _prompt
        text = self.prompt if isinstance(self.prompt, str) else f"{self.name.replace('_', ' ').title()}"
        default = self.declared_default()
        dm = self.default_map_value(ctx)
        if dm is not None:
            default = dm
        if self.is_flag:
            from .terminal import confirm
            return confirm(text, default=bool(default))
        return _prompt(text, default=default, hide_input=self.hide_input,
                       confirmation_prompt=self.confirmation_prompt,
                       type=self.type)


class Argument(Parameter):
    def __init__(self, param_decls=None, **attrs):
        decls = list(param_decls or [])
        self.required_arg = attrs.pop("required", None)
        self.allow_from_autoenv = False
        super().__init__(decls, "argument", **attrs)
        if self.name is None:
            raise TypeError("an argument needs a destination name")
        if self.deprecated and self.required_arg is True:
            raise TypeError("a deprecated argument cannot be required")
        if self.nargs not in (-1,) and not (isinstance(self.nargs, int) and self.nargs >= 1):
            raise TypeError("argument nargs must be a positive int or -1")
        if self.required_arg is None:
            self.required = self.default is None and self.nargs != -1
        else:
            self.required = bool(self.required_arg)
        if self.deprecated and self.required:
            raise TypeError("a deprecated argument cannot be required")
        self.count = False
        self.is_flag = False
        self.flag_value = None
        self.prompt = None
        self.hide_input = False
        self.confirmation_prompt = False
        self._finish_type()
        self.opts = []
        self.is_flag_like = False

    @property
    def variadic(self):
        return self.nargs == -1

    def resolve(self, ctx, occurrences):
        from .context import (PARAM_SOURCE_COMMANDLINE, PARAM_SOURCE_DEFAULT,
                              PARAM_SOURCE_DEFAULT_MAP, PARAM_SOURCE_ENVIRONMENT)
        if occurrences:
            tokens = occurrences[0]["tokens"]
            if self.variadic or self.nargs != 1:
                return self._conv_seq(ctx, tokens), PARAM_SOURCE_COMMANDLINE
            return self.convert(ctx, tokens[0]), PARAM_SOURCE_COMMANDLINE
        for name in self.get_env_names():
            val = os.environ.get(name)
            if val:
                if self.variadic or self.nargs != 1:
                    return self._conv_seq(ctx, self._split_env(val)), PARAM_SOURCE_ENVIRONMENT
                return self.convert(ctx, val), PARAM_SOURCE_ENVIRONMENT
        dm = self.default_map_value(ctx)
        if dm is not None:
            if isinstance(dm, str) and (self.variadic or self.nargs != 1):
                return self._conv_seq(ctx, dm.split()), PARAM_SOURCE_DEFAULT_MAP
            if isinstance(dm, (list, tuple)):
                return self._conv_seq(ctx, list(dm)), PARAM_SOURCE_DEFAULT_MAP
            return self.convert(ctx, dm), PARAM_SOURCE_DEFAULT_MAP
        d = self.declared_default()
        if d is None:
            if self.variadic:
                return (), PARAM_SOURCE_DEFAULT
            return None, PARAM_SOURCE_DEFAULT
        if self.variadic or self.nargs != 1:
            return self._conv_seq(ctx, list(d)), PARAM_SOURCE_DEFAULT
        return self.convert(ctx, d), PARAM_SOURCE_DEFAULT

    def _conv_seq(self, ctx, tokens):
        if isinstance(self.type, Tuple):
            return self.type.convert(list(tokens), self, ctx)
        return tuple(self.convert(ctx, t) for t in tokens)
