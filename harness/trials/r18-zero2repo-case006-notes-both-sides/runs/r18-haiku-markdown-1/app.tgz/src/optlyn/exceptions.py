"""Exception classes and exit-status handling for Optlyn."""

import sys


class OptlynError(Exception):
    """Base class for Optlyn-signalled errors (general error, exit 1)."""

    exit_code = 1

    def __init__(self, message=None):
        super().__init__(message or "")
        self.message = message or ""

    def show(self, file=None):
        file = file or sys.stderr
        file.write(f"Error: {self.message}\n")


class UsageError(OptlynError):
    """Usage failure (exit 2)."""

    exit_code = 2

    def __init__(self, message=None, ctx=None):
        super().__init__(message)
        self.ctx = ctx

    def show(self, file=None):
        file = file or sys.stderr
        file.write(f"Usage error: {self.message}\n")


class BadParameter(UsageError):
    """A value was refused. Carries the offending parameter identity."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def param_name(self):
        if self.param_hint:
            return str(self.param_hint)
        p = self.param
        if p is None:
            return None
        flags = getattr(p, "opts", None)
        if flags:
            return "/".join(flags)
        return getattr(p, "name", None)

    def show(self, file=None):
        file = file or sys.stderr
        name = self.param_name()
        if name:
            file.write(f"Usage error: invalid value for {name}: {self.message}\n")
        else:
            file.write(f"Usage error: invalid value: {self.message}\n")


class MissingParameter(BadParameter):
    """A required parameter was not supplied."""

    def show(self, file=None):
        file = file or sys.stderr
        name = self.param_name() or "parameter"
        file.write(f"Usage error: missing required parameter {name}\n")


class NoSuchOption(UsageError):
    """An unknown option was given."""

    def __init__(self, option_name, message=None, ctx=None):
        super().__init__(message or f"no such option: {option_name}", ctx)
        self.option_name = option_name


class UsageNoCommand(UsageError):
    """A group was invoked without a required subcommand."""


class Abort(OptlynError):
    """Abort (exit 1), e.g. declined confirmation or EOF on prompt."""

    exit_code = 1

    def show(self, file=None):
        file = file or sys.stderr
        file.write("Aborted!\n")


class Exit(Exception):
    """Author clean stop with a status code."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code


class FileError(OptlynError):
    """A file could not be opened at first I/O (general error, exit 1)."""

    exit_code = 1
