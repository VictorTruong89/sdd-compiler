"""Parameter types and conversion."""

import datetime as _dt
import enum
import os
import pathlib
import sys
import uuid

from .exceptions import BadParameter


class ParamType:
    """Base class for parameter types."""

    name = "text"
    is_composite = False
    envvar_list_splitter = None  # None means whitespace

    def convert(self, value, param=None, ctx=None):
        return value

    def get_metavar(self, param=None):
        return None

    def get_default_type_name(self):
        return self.name.upper()

    def split_envvar_value(self, value):
        return value.split()

    def shell_complete(self, ctx, param, incomplete):
        return []

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def __repr__(self):
        return f"<{type(self).__name__}>"


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            try:
                return value.decode("utf-8")
            except UnicodeError:
                return value.decode("utf-8", "replace")
        return str(value)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            return int(str(value).strip(), 10)
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        if isinstance(value, int) and not isinstance(value, bool):
            return float(value)
        try:
            return float(str(value).strip())
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


class Choice(ParamType):
    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        self.case_sensitive = case_sensitive
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self._enum = choices
            self.choices = list(choices)
            self._tokens = [m.name for m in choices]
        else:
            self._enum = None
            self.choices = list(choices)
            self._tokens = [str(c) for c in self.choices]

    def get_metavar(self, param=None):
        return "[" + "|".join(self._tokens) + "]"

    def get_default_type_name(self):
        return self.get_metavar()

    def _norm(self, s):
        return s if self.case_sensitive else s.casefold()

    def convert(self, value, param=None, ctx=None):
        if self._enum is not None and isinstance(value, self._enum):
            return value
        if not self.case_sensitive and not isinstance(value, str):
            pass
        for choice, token in zip(self.choices, self._tokens):
            if value == choice:
                return choice
        text = str(value)
        normed = self._norm(text)
        for choice, token in zip(self.choices, self._tokens):
            if self._norm(token) == normed:
                return choice
        options = ", ".join(repr(t) for t in self._tokens)
        self.fail(f"{value!r} is not {options}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        return [t for t in self._tokens if t.startswith(incomplete)]


class DateTime(ParamType):
    name = "datetime"
    DEFAULT_FORMATS = (
        "%Y-%m-%d",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
    )

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(self.DEFAULT_FORMATS)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        text = str(value).strip()
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(text, fmt)
            except ValueError:
                continue
        fmts = ", ".join(repr(f) for f in self.formats)
        self.fail(f"{value!r} does not match the formats {fmts}.", param, ctx)


class IntRange(IntParamType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        v = super().convert(value, param, ctx)
        lo, hi = self.min, self.max
        if lo is not None:
            if self.min_open:
                if v <= lo:
                    if self.clamp:
                        return lo + 1
                    self.fail(f"{v} is not in the range {self._desc()}.", param, ctx)
            elif v < lo:
                if self.clamp:
                    return lo
                self.fail(f"{v} is not in the range {self._desc()}.", param, ctx)
        if hi is not None:
            if self.max_open:
                if v >= hi:
                    if self.clamp:
                        return hi - 1
                    self.fail(f"{v} is not in the range {self._desc()}.", param, ctx)
            elif v > hi:
                if self.clamp:
                    return hi
                self.fail(f"{v} is not in the range {self._desc()}.", param, ctx)
        return v

    def _desc(self):
        lo = "" if self.min is None else (">" if self.min_open else ">=") + str(self.min)
        hi = "" if self.max is None else ("<" if self.max_open else "<=") + str(self.max)
        return " and ".join(x for x in (lo, hi) if x) or "any"


class FloatRange(FloatParamType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and ((min is not None and min_open) or (max is not None and max_open)):
            raise ValueError("clamp is only allowed when both bounds are closed.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        v = super().convert(value, param, ctx)
        if self.min is not None:
            if v < self.min or (self.min_open and v == self.min):
                if self.clamp:
                    return float(self.min)
                self.fail(f"{v} is not within the range.", param, ctx)
        if self.max is not None:
            if v > self.max or (self.max_open and v == self.max):
                if self.clamp:
                    return float(self.max)
                self.fail(f"{v} is not within the range.", param, ctx)
        return v


class Tuple(ParamType):
    name = "tuple"
    is_composite = True

    def __init__(self, types):
        self.types = [to_type(t) for t in types]

    @property
    def arity(self):
        return len(self.types)

    def get_metavar(self, param=None):
        return " ".join(t.get_default_type_name() for t in self.types)

    def convert(self, value, param=None, ctx=None):
        if not isinstance(value, (list, tuple)) or len(value) != len(self.types):
            self.fail(f"{value!r} must have {len(self.types)} items.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))


class File(ParamType):
    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"unsupported mode {mode!r}")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def get_metavar(self, param=None):
        return "FILENAME"

    def _is_lazy(self):
        if self.lazy is not None:
            return self.lazy
        return self.mode.startswith("w")

    def convert(self, value, param=None, ctx=None):
        from .fileio import open_file

        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        try:
            return open_file(
                str(value),
                self.mode,
                self.encoding,
                self.errors,
                lazy=self._is_lazy(),
                atomic=self.atomic,
            )
        except OSError as exc:
            self.fail(f"'{value}': {exc.strerror or exc}", param, ctx)


class Path(ParamType):
    name = "path"

    def __init__(
        self,
        exists=False,
        file_okay=True,
        dir_okay=True,
        writable=False,
        readable=True,
        resolve_path=False,
        allow_dash=False,
        path_type=None,
        executable=False,
    ):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def get_metavar(self, param=None):
        return "PATH"

    def convert(self, value, param=None, ctx=None):
        text = os.fspath(value) if not isinstance(value, str) else value
        if isinstance(text, bytes):
            text = os.fsdecode(text)
        if self.allow_dash and text == "-":
            return self._out("-")
        if self.resolve_path:
            text = os.path.realpath(text)
        exists = os.path.exists(text)
        if not exists:
            if self.exists:
                self.fail(f"{text!r} does not exist.", param, ctx)
        else:
            if not self.file_okay and os.path.isfile(text):
                self.fail(f"{text!r} is a file.", param, ctx)
            if not self.dir_okay and os.path.isdir(text):
                self.fail(f"{text!r} is a directory.", param, ctx)
            if self.readable and not os.access(text, os.R_OK):
                self.fail(f"{text!r} is not readable.", param, ctx)
            if self.writable and not os.access(text, os.W_OK):
                self.fail(f"{text!r} is not writable.", param, ctx)
            if self.executable and not os.access(text, os.X_OK):
                self.fail(f"{text!r} is not executable.", param, ctx)
        return self._out(text)

    def _out(self, text):
        if self.path_type is pathlib.Path:
            return pathlib.Path(text)
        return text


class UnsetType:
    pass


def to_type(value):
    """Turn a type declaration into a ParamType instance."""
    if isinstance(value, ParamType):
        return value
    if isinstance(value, type) and issubclass(value, ParamType):
        return value()
    if value is None:
        return STRING
    if value is str:
        return STRING
    if value is int:
        return INT
    if value is float:
        return FLOAT
    if value is bool:
        return BOOL
    if value is uuid.UUID:
        return UUID
    if isinstance(value, (list, tuple)) and value and all(
        isinstance(v, (ParamType, type)) for v in value
    ):
        return Tuple(value)
    if callable(value):
        return FuncParamType(value)
    raise TypeError(f"unknown parameter type {value!r}")


class FuncParamType(ParamType):
    """Wraps a conversion function that refuses by raising ValueError."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text").upper()

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except BadParameter:
            raise
        except ValueError as exc:
            self.fail(str(exc) or f"{value!r} is not valid.", param, ctx)


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()
DATETIME = DateTime()
