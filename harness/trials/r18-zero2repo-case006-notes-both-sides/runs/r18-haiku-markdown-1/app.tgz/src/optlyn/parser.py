"""Command-line token parser for options and positional arguments."""

from .exceptions import BadParameter, MissingParameter, NoSuchOption, UsageError
from .params import Option, Argument

_PREFIXES = "-/+"


class ParseResult:
    def __init__(self):
        self.occurrences = {}  # Parameter -> [occurrence dict]
        self.positionals = []  # raw positional tokens for this command
        self.rest = []         # for groups: tokens from the subcommand name on
        self.help_index = None


class OptionParser:
    def __init__(self, command, ctx, help_params=()):
        self.command = command
        self.ctx = ctx
        self.is_group = bool(getattr(command, "is_group", False))
        self.interspersed = ctx.allow_interspersed_args
        if self.is_group:
            self.interspersed = False if not command.allow_group_option_mixing else True
        self.ignore_unknown = ctx.ignore_unknown_options
        self.normalize = ctx.token_normalize_func
        self.map = {}
        self.prefixes = set(_PREFIXES)
        for p in list(command.get_params(ctx)):
            if isinstance(p, Option):
                for o in p.opts:
                    self.map[self._norm(o)] = (p, "on")
                for o in p.secondary_opts:
                    self.map[self._norm(o)] = (p, "off")
                self.prefixes.update(p.prefixes)

    def _norm(self, name):
        if self.normalize is None:
            return name
        return self.normalize(name)

    def _optlike(self, tok):
        return len(tok) > 1 and tok[0] in self.prefixes

    def _lookup(self, name):
        return self.map.get(self._norm(name))

    def _add(self, res, param, occ):
        res.occurrences.setdefault(param, []).append(occ)

    def parse(self, args):
        res = ParseResult()
        i = 0
        idx = 0
        end_of_opts = False
        no_more_opts = False
        n = len(args)
        while i < n:
            tok = args[i]
            if end_of_opts:
                res.positionals.append(tok)
                i += 1
                continue
            if tok == "--":
                end_of_opts = True
                i += 1
                continue
            if no_more_opts or not self._optlike(tok):
                if self.is_group:
                    if self._group_wants_positional(res):
                        res.positionals.append(tok)
                        i += 1
                        continue
                    res.rest = list(args[i:])
                    return res
                res.positionals.append(tok)
                if not self.interspersed:
                    no_more_opts = True
                i += 1
                continue
            i = self._handle_option(tok, args, i, res, idx)
            idx += 1
        return res

    def _group_wants_positional(self, res):
        args = getattr(self.command, "arguments", [])
        if not args:
            return False
        needed = 0
        for a in args:
            if a.nargs == -1:
                return True
            needed += a.nargs
        return len(res.positionals) < needed

    def _handle_option(self, tok, args, i, res, idx):
        if tok.startswith("--") or (tok[0] in self.prefixes and len(tok) > 2 and self._lookup(tok.split("=", 1)[0]) is not None):
            name, eq, val = tok.partition("=")
            found = self._lookup(name)
            if found is None:
                if self.ignore_unknown:
                    res.positionals.append(tok)
                    return i + 1
                raise NoSuchOption(name, ctx=self.ctx)
            return self._apply(found, eq and val, bool(eq), args, i, res, idx)
        # short stack
        prefix = tok[0]
        chars = tok[1:]
        j = 0
        while j < len(chars):
            name = prefix + chars[j]
            found = self._lookup(name)
            if found is None:
                if self.ignore_unknown:
                    res.positionals.append(prefix + chars[j:])
                    return i + 1
                raise NoSuchOption(name, ctx=self.ctx)
            param, _kind = found
            if self._takes_value(param):
                rest = chars[j + 1:]
                if rest:
                    return self._apply(found, rest, True, args, i, res, idx)
                return self._apply(found, None, False, args, i, res, idx)
            self._apply(found, None, False, args, i, res, idx)
            j += 1
        return i + 1

    @staticmethod
    def _takes_value(param):
        return not (param.is_flag or param.count) and param.nargs > 0

    def _apply(self, found, value, has_eq, args, i, res, idx):
        param, kind = found
        if param.is_flag:
            flag = param.flag_value if kind == "on" else False
            if kind == "on" and flag is None:
                flag = True
            self._add(res, param, {"tokens": [], "flag": flag, "idx": idx})
            return i + 1
        if param.count:
            self._add(res, param, {"tokens": [], "flag": True, "idx": idx})
            return i + 1
        nargs = param.value_arity if param.is_composite else param.nargs
        if has_eq and value is not None and nargs == 1:
            self._add(res, param, {"tokens": [value], "flag": None, "idx": idx})
            return i + 1
        tokens = []
        j = i + 1
        if has_eq and value is not None:
            tokens.append(value)
            j = i + 1
        while len(tokens) < nargs and j < len(args):
            nxt = args[j]
            if nxt == "--" or self._optlike(nxt):
                break
            tokens.append(nxt)
            j += 1
        if len(tokens) < nargs:
            if param.prompt is not None:
                self._add(res, param, {"tokens": [], "flag": None, "idx": idx, "prompt": True})
                return j
            raise BadParameter(
                f"option requires an argument ({nargs} expected, {len(tokens)} given).",
                ctx=self.ctx, param=param)
        self._add(res, param, {"tokens": tokens, "flag": None, "idx": idx})
        return j


def bind_arguments(command, positionals, ctx):
    """Bind positional tokens to declared arguments. Returns dict Argument -> occurrences."""
    result = {}
    args = list(getattr(command, "arguments", []))
    tokens = list(positionals)
    for k, arg in enumerate(args):
        later_fixed = 0
        for later in args[k + 1:]:
            later_fixed += later.nargs if later.nargs != -1 else 0
        if arg.nargs == -1:
            take = max(0, len(tokens) - later_fixed)
            chunk, tokens = tokens[:take], tokens[take:]
            result[arg] = [{"tokens": chunk}] if chunk else []
            continue
        if len(tokens) >= arg.nargs:
            chunk, tokens = tokens[:arg.nargs], tokens[arg.nargs:]
            result[arg] = [{"tokens": chunk}]
            continue
        if arg.required:
            if tokens or arg.nargs > 1:
                raise BadParameter(
                    f"argument {arg.name} needs {arg.nargs} value(s), {len(tokens)} given.",
                    ctx=ctx, param=arg)
            raise MissingParameter("missing argument", ctx=ctx, param=arg)
        result[arg] = []
    if tokens:
        if getattr(command, "allow_extra_args", False) or getattr(ctx, "allow_extra_args", False):
            ctx.extra_args = tokens
        else:
            raise UsageError(f"Got unexpected extra argument(s) ({' '.join(tokens)}).", ctx=ctx)
    return result
