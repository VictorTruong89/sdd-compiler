"""In-process runner for invoking commands and capturing their output."""

import contextlib
import io
import os
import shutil
import sys
import tempfile

from .exceptions import Abort, Exit


class _EchoingStdin(io.TextIOBase):
    def __init__(self, data, echo_to):
        self._buf = io.StringIO(data)
        self._echo_to = echo_to

    def readline(self, size=-1):
        line = self._buf.readline(size)
        if line:
            self._echo_to.write(line)
        return line

    def read(self, size=-1):
        data = self._buf.read(size)
        if data:
            self._echo_to.write(data)
        return data

    def isatty(self):
        return False

    def readable(self):
        return True


class _Input(io.TextIOBase):
    """Input stream; unreadable echo is off unless requested."""

    def __init__(self, data):
        self._buf = io.StringIO(data)

    def readline(self, size=-1):
        return self._buf.readline(size)

    def read(self, size=-1):
        return self._buf.read(size)

    def isatty(self):
        return False

    def readable(self):
        return True


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, exit_code, exception, exc_info):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    @property
    def output(self):
        return self.output_bytes.decode(self.runner.charset, "replace")

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False,
                 catch_exceptions=True, capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        if isinstance(input, bytes):
            input = input.decode(self.charset)
        input = input or ""
        merged = dict(self.env)
        merged.update(env or {})
        old_env = {}
        for k, v in merged.items():
            old_env[k] = os.environ.get(k)
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = str(v)

        out_buf = io.BytesIO()
        err_buf = io.BytesIO()
        out = io.TextIOWrapper(out_buf, encoding=self.charset, errors="replace",
                               write_through=True)
        err = io.TextIOWrapper(err_buf, encoding=self.charset, errors="replace",
                               write_through=True)
        # The combined output keeps write order across both streams.
        combined = _Combined(out, err)
        stdin = _Input(input)
        if self.echo_stdin:
            stdin = _EchoingStdin(input, combined)
        old = (sys.stdin, sys.stdout, sys.stderr)
        sys.stdin = stdin
        fd_mode = self.capture == "fd"
        sys.stdout = _Tee(out, combined, fd=1 if fd_mode else None)
        sys.stderr = _Tee(err, combined, fd=2 if fd_mode else None)
        try:
            yield (out_buf, err_buf, combined)
        finally:
            out.flush()
            err.flush()
            # detach so the byte buffers stay open for reading after teardown
            out.detach()
            err.detach()
            sys.stdin, sys.stdout, sys.stderr = old
            for k, v in old_env.items():
                if v is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = v

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None,
               color=False, **extra):
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if isinstance(args, str):
            import shlex
            args = shlex.split(args)
        args = list(args or [])
        exit_code = 0
        exception = None
        exc_info = None
        standalone = extra.pop("standalone_mode", True)
        prog = extra.pop("prog_name", "cli")
        extra.setdefault("color", color)
        with self.isolation(input=input, env=env, color=color) as (out_buf, err_buf, combined):
            try:
                if self.capture == "fd":
                    fd_out, fd_err = self._run_fd(cli, args, prog, standalone, extra)
                    out_buf.write(fd_out)
                    err_buf.write(fd_err)
                    combined.write(fd_out.decode(self.charset, "replace"))
                    combined.write(fd_err.decode(self.charset, "replace"))
                else:
                    self._run(cli, args, prog, standalone, extra)
            except SystemExit as e:
                code = e.code
                if code is None:
                    exit_code = 0
                elif isinstance(code, int):
                    exit_code = code
                else:
                    sys.stderr.write(str(code) + "\n")
                    exit_code = 1
            except Abort as e:
                exit_code = 1
                exception = e
                exc_info = sys.exc_info()
            except Exit as e:
                exit_code = e.exit_code
            except Exception as e:  # noqa: BLE001
                if not catch_exceptions:
                    raise
                exit_code = 1
                exception = e
                exc_info = sys.exc_info()
        return Result(self, out_buf.getvalue(), err_buf.getvalue(),
                      combined.getvalue().encode(self.charset, "replace"),
                      exit_code, exception, exc_info)

    def _run(self, cli, args, prog, standalone, extra):
        return cli.main(args=args, prog_name=prog, standalone_mode=standalone, **extra)

    def _run_fd(self, cli, args, prog, standalone, extra):
        """Run with OS-level descriptor 1/2 redirected; return the captured bytes."""
        tmp = tempfile.TemporaryFile()
        err_tmp = tempfile.TemporaryFile()
        saved_out = os.dup(1)
        saved_err = os.dup(2)
        try:
            sys.stdout.flush()
            sys.stderr.flush()
            os.dup2(tmp.fileno(), 1)
            os.dup2(err_tmp.fileno(), 2)
            try:
                self._run(cli, args, prog, standalone, extra)
            finally:
                sys.stdout.flush()
                sys.stderr.flush()
                os.dup2(saved_out, 1)
                os.dup2(saved_err, 2)
            tmp.seek(0)
            err_tmp.seek(0)
            return tmp.read(), err_tmp.read()
        finally:
            os.close(saved_out)
            os.close(saved_err)
            tmp.close()
            err_tmp.close()

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        if temp_dir is not None:
            path = tempfile.mkdtemp(dir=temp_dir)
        else:
            path = tempfile.mkdtemp()
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            # The directory is left in place so its files can be inspected.


class _Combined(io.TextIOBase):
    """Records writes from both streams in write order."""

    def __init__(self, out, err):
        self._parts = []

    def write(self, s):
        self._parts.append(s)
        return len(s)

    def getvalue(self):
        return "".join(self._parts)

    def flush(self):
        pass


class _Tee:
    def __init__(self, target, combined, fd=None):
        self._target = target
        self._combined = combined
        self._fd = fd

    def write(self, s):
        self._combined.write(s)
        return self._target.write(s)

    def flush(self):
        self._target.flush()

    def isatty(self):
        return False

    def fileno(self):
        if self._fd is None:
            raise io.UnsupportedOperation("fileno")
        return self._fd

    def __getattr__(self, item):
        return getattr(self._target, item)
