"""Shell completion: registration scripts (``*_source``) and suggestions (``*_complete``)."""

import os
import sys

from .params import Argument, Option
from .types import File, Path, Choice

SHELLS = ("bash", "zsh", "fish", "powershell")
PATH_FILE = "__OPTLYN_PATH_FILE__"
PATH_DIR = "__OPTLYN_PATH_DIR__"


def _var_name(prog):
    return "_" + prog.upper().replace("-", "_") + "_COMPLETE"


def _func_name(prog):
    return "_" + prog.replace("-", "_") + "_completion"


def handle_completion(cmd, prog_name, value, args):
    """Handle the completion variable. Returns an exit code (0 for a handled run)."""
    if "_" not in value:
        return _unknown(value)
    shell, _, mode = value.partition("_")
    if shell not in SHELLS or mode not in ("source", "complete"):
        return _unknown(value)
    if mode == "source":
        sys.stdout.write(source_script(shell, prog_name))
        sys.stdout.flush()
        return 0
    words = os.environ.get("COMP_WORDS", "").split()
    if shell == "fish":
        incomplete = os.environ.get("COMP_CWORD", "")
        cword = len(words)
        if incomplete:
            words = words + [incomplete]
            cword = len(words) - 1
        else:
            cword = len(words)
    else:
        try:
            cword = int(os.environ.get("COMP_CWORD", str(len(words))))
        except ValueError:
            cword = len(words)
    items = suggest(cmd, words, cword)
    out = []
    for it in items:
        if isinstance(it, tuple):
            value_text, help_text = it
        else:
            value_text, help_text = it, None
        if value_text in (PATH_FILE, PATH_DIR):
            out.append(("__PATH__:dir" if value_text == PATH_DIR else "__PATH__:file") + ":" + help_text)
        elif help_text and shell in ("zsh", "fish"):
            out.append(f"{value_text}\t{help_text}")
        else:
            out.append(value_text)
    sys.stdout.write("\n".join(out) + ("\n" if out else ""))
    sys.stdout.flush()
    return 0


def _unknown(value):
    return 1


def suggest(cmd, words, cword):
    """Return suggestions for the word at index ``cword`` (words[0] is the program)."""
    incomplete = words[cword] if cword < len(words) else ""
    prev = words[cword - 1] if 0 < cword <= len(words) else ""
    node = cmd
    ctx_stub = _Stub(cmd)
    for w in words[1:cword]:
        if w.startswith("-"):
            continue
        if node.is_group:
            nxt = node.get_command(ctx_stub, w)
            if nxt is not None:
                node = nxt
                ctx_stub = _Stub(nxt)
    opts = [p for p in node.get_params(ctx_stub) if isinstance(p, Option) and not p.hidden]

    # value of the previous option, when it takes a value
    if prev.startswith("-") and not incomplete.startswith("-"):
        for p in opts:
            if prev in p.opts + p.secondary_opts and not (p.is_flag or p.count):
                return _value_suggestions(p, ctx_stub, incomplete, node)

    if incomplete.startswith("-"):
        out = []
        for p in opts:
            for name in p.opts + p.secondary_opts:
                if name.startswith(incomplete) and not p.hidden:
                    out.append((name, p.help))
        return out

    out = []
    if node.is_group:
        for name in node.list_commands(ctx_stub):
            child = node.get_command(ctx_stub, name)
            if child is not None and not child.hidden and name.startswith(incomplete):
                out.append((name, child.short_help or (child.help or "").split(".")[0] or None))
    else:
        for a in node.arguments:
            if isinstance(a.type, (File, Path)):
                kind = PATH_DIR if isinstance(a.type, Path) and not a.type.file_okay else PATH_FILE
                out.append((kind, incomplete))
                break
    return out


def _value_suggestions(p, ctx, incomplete, node):
    if isinstance(p.type, Choice):
        return [t for t in p.type._tokens if t.startswith(incomplete)]
    if p.shell_complete_func is not None:
        res = p.shell_complete_func(ctx, p, incomplete)
        out = []
        for r in res:
            if isinstance(r, str):
                out.append(r)
            else:
                out.append((r.value, r.help))
        return out
    if isinstance(p.type, (File, Path)):
        kind = PATH_DIR if isinstance(p.type, Path) and not p.type.file_okay else PATH_FILE
        return [(kind, incomplete)]
    return []


class _Stub:
    """Minimal context stand-in for completion lookups."""

    def __init__(self, command):
        self.command = command
        self.params = {}
        self.help_option_names = ["--help"]
        self.parent = None
        self.obj = None
        self.resilient_parsing = True
        self.ignore_unknown_options = False
        self.allow_extra_args = False
        self.max_content_width = 80
        self.default_map = None
        self.show_default = None
        self.terminal_width = None
        self.color = None
        self.token_normalize_func = None
        self.auto_envvar_prefix = None
        self.command_path = ""
        self.info_name = None


def source_script(shell, prog):
    var = _var_name(prog)
    func = _func_name(prog)
    if shell == "bash":
        return f"""{func}() {{
    local words="${{COMP_WORDS[*]}}"
    local IFS=$'\\n'
    local response
    response=$(env COMP_WORDS="$words" COMP_CWORD=$COMP_CWORD {var}=bash_complete {prog} 2>/dev/null)
    COMPREPLY=()
    for completion in $response; do
        case "$completion" in
            __PATH__:*) ;;
            *) COMPREPLY+=("$completion") ;;
        esac
    done
    if [ ${{#COMPREPLY[@]}} -eq 0 ]; then
        COMPREPLY=($(compgen -f -- "${{COMP_WORDS[COMP_CWORD]}}"))
    fi
}}
complete -o default -F {func} {prog}
"""
    if shell == "zsh":
        return f"""#compdef {prog}
{func}() {{
    local -a completions
    local words="${{words[*]}}"
    completions=("${{(@f)$(env COMP_WORDS="$words" COMP_CWORD=$((CURRENT-1)) {var}=zsh_complete {prog} 2>/dev/null)}}")
    _describe 'values' completions
}}
compdef {func} {prog}
"""
    if shell == "fish":
        return f"""function {func}
    set -l words (commandline -opc)
    set -l cur (commandline -ct)
    env COMP_WORDS="$words" COMP_CWORD="$cur" {var}=fish_complete {prog} 2>/dev/null
end
complete -c {prog} -f -a "({func})"
"""
    return f"""Register-ArgumentCompleter -Native -CommandName {prog} -ScriptBlock {{
    param($wordToComplete, $commandAst, $cursorPosition)
    $words = $commandAst.ToString()
    $env:COMP_WORDS = $words
    $env:COMP_CWORD = $commandAst.CommandElements.Count
    $env:{var} = 'powershell_complete'
    & {prog} | ForEach-Object {{
        [System.Management.Automation.CompletionResult]::new($_, $_, 'ParameterValue', $_)
    }}
    Remove-Item Env:{var}
}}
"""
