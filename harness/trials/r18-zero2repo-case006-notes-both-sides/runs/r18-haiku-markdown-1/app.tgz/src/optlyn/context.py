"""Invocation context and thread-local current-context stack."""

import threading

from .exceptions import Abort, Exit

_local = threading.local()

_SOURCE_PROMPT = "prompt"
_SOURCE_CMDLINE = "commandline"
_SOURCE_ENV = "environment"
_SOURCE_DEFAULT_MAP = "default_map"
_SOURCE_DEFAULT = "default"


class ParameterSource:
    """Distinct source marker; equal sources compare equal."""

    __slots__ = ("value",)

    def __init__(self, value):
        self.value = value

    def __eq__(self, other):
        return isinstance(other, ParameterSource) and other.value == self.value

    def __hash__(self):
        return hash(self.value)

    def __repr__(self):
        return f"ParameterSource.{self.value.upper()}"


PARAM_SOURCE_PROMPT = ParameterSource(_SOURCE_PROMPT)
PARAM_SOURCE_COMMANDLINE = ParameterSource(_SOURCE_CMDLINE)
PARAM_SOURCE_ENVIRONMENT = ParameterSource(_SOURCE_ENV)
PARAM_SOURCE_DEFAULT_MAP = ParameterSource(_SOURCE_DEFAULT_MAP)
PARAM_SOURCE_DEFAULT = ParameterSource(_SOURCE_DEFAULT)


class Context:
    def __init__(
        self,
        command,
        parent=None,
        info_name=None,
        obj=None,
        auto_envvar_prefix=None,
        default_map=None,
        terminal_width=None,
        max_content_width=None,
        help_option_names=None,
        token_normalize_func=None,
        color=None,
        show_default=None,
        allow_extra_args=None,
        ignore_unknown_options=None,
        allow_interspersed_args=None,
        standalone_mode=True,
        catch_exceptions=True,
        prog_name=None,
        resilient_parsing=False,
    ):
        self.command = command
        self.parent = parent
        self.info_name = info_name
        self.obj = obj if obj is not None else (parent.obj if parent else None)
        self.params = {}
        self._sources = {}
        self._exit_stack = []
        self.invoked_subcommand = None
        self.auto_envvar_prefix = auto_envvar_prefix
        if auto_envvar_prefix is None and parent is not None:
            self.auto_envvar_prefix = parent.auto_envvar_prefix
        self.default_map = default_map
        self.terminal_width = terminal_width
        self.max_content_width = max_content_width or (
            parent.max_content_width if parent else 80
        )
        self.help_option_names = (
            list(help_option_names)
            if help_option_names is not None
            else (list(parent.help_option_names) if parent else ["--help"])
        )
        self.token_normalize_func = token_normalize_func or (
            parent.token_normalize_func if parent else None
        )
        self.color = color if color is not None else (parent.color if parent else None)
        self.show_default = show_default if show_default is not None else (
            parent.show_default if parent else None
        )
        self.allow_extra_args = bool(allow_extra_args) if allow_extra_args is not None else (
            bool(command.allow_extra_args) if command is not None else False
        )
        self.ignore_unknown_options = bool(ignore_unknown_options) if ignore_unknown_options is not None else (
            bool(command.ignore_unknown_options) if command is not None else False
        )
        self.allow_interspersed_args = (
            allow_interspersed_args
            if allow_interspersed_args is not None
            else getattr(command, "allow_interspersed_args", True)
        )
        self.standalone_mode = standalone_mode
        self.catch_exceptions = catch_exceptions
        self.prog_name = prog_name or (parent.prog_name if parent else None)
        self.resilient_parsing = resilient_parsing
        self._entered = 0

    # --- naming -------------------------------------------------------
    @property
    def command_path(self):
        parts = []
        ctx = self
        while ctx is not None:
            if ctx.info_name:
                parts.append(ctx.info_name)
            ctx = ctx.parent
        return " ".join(reversed(parts))

    # --- sources ------------------------------------------------------
    def set_source(self, name, source):
        self._sources[name] = source

    def get_parameter_source(self, name):
        if self.command is None:
            return None
        if name not in {p.name for p in self.command.params}:
            return None
        return self._sources.get(name)

    # --- resources ----------------------------------------------------
    def with_resource(self, cm):
        value = cm.__enter__()
        root = self
        self._exit_stack.append(cm)
        return value

    def call_on_close(self, fn):
        self._exit_stack.append(_CloseCallback(fn))

    def close(self):
        errors = []
        while self._exit_stack:
            cm = self._exit_stack.pop()
            try:
                cm.__exit__(None, None, None)
            except Exception as exc:  # pragma: no cover
                errors.append(exc)
        if errors:
            raise errors[0]

    # --- control ------------------------------------------------------
    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def invoke(self, other, /, *args, **kwargs):
        return _invoke_command(self, other, kwargs, forward=False)

    def forward(self, other, /, **kwargs):
        merged = dict(self.params)
        merged.update(kwargs)
        return _invoke_command(self, other, merged, forward=True)

    # --- thread current -----------------------------------------------
    def __enter__(self):
        stack = _stack()
        stack.append(self)
        self._entered += 1
        return self

    def __exit__(self, exc_type, exc, tb):
        self._entered -= 1
        stack = _stack()
        if stack and stack[-1] is self:
            stack.pop()
        return False


class _CloseCallback:
    def __init__(self, fn):
        self.fn = fn

    def __exit__(self, *exc):
        self.fn()


def _stack():
    if not hasattr(_local, "stack"):
        _local.stack = []
    return _local.stack


def get_current_context(silent=False):
    stack = _stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")


def _invoke_command(ctx, other, values, forward):
    """Run ``other`` (a Command) from inside a callback."""
    from .core import Command

    if not isinstance(other, Command):
        raise TypeError("invoke/forward target must be a command")
    sub = other.make_context(other.name, [], parent=ctx, standalone_mode=False)
    # Both invoke and forward deliver the given values to the target; forward
    # passes this command's own values, invoke passes exactly the caller's.
    sub.params.update(values)
    with sub:
        return other.invoke(sub)
