"""Options, arguments, types, value sources (spec: section 4-5, FP-03..FP-05, FP-07..FP-09)."""

import enum
import os
import uuid

import pytest

from optlyn import (
    BOOL,
    Choice,
    DateTime,
    File,
    FloatRange,
    IntRange,
    ParamType,
    Path,
    Tuple,
    UUID,
    argument,
    command,
    confirmation_option,
    echo,
    group,
    option,
    password_option,
    pass_context,
)
from optlyn.exceptions import BadParameter, OptlynDeclarationError
from optlyn.testing import CliRunner


@pytest.fixture
def runner():
    return CliRunner()


def run(runner, cmd, args, **kw):
    return runner.invoke(cmd, args, **kw)


# -- option basics -----------------------------------------------------------

def test_FP03_destination_inferred_from_long_name(runner):
    @command()
    @option("--dry-run", is_flag=True)
    def c(dry_run):
        echo(str(dry_run))

    assert run(runner, c, ["--dry-run"]).stdout == "True\n"


def test_FP03_destination_prefers_identifier_name():
    from optlyn.core import Option

    assert Option(["count", "-c"]).name == "count"
    assert Option(["-c", "--cnt-x"]).name == "cnt_x"
    assert Option(["--dry-run"]).name == "dry_run"
    assert Option(["-q", "--quiet"]).name == "quiet"


def test_FP03_long_equals_and_separate_value(runner):
    @command()
    @option("--name")
    def c(name):
        echo(name)

    assert run(runner, c, ["--name=bob"]).stdout == "bob\n"
    assert run(runner, c, ["--name", "amy"]).stdout == "amy\n"


def test_FP03_short_stacking_flags_and_value(runner):
    @command()
    @option("-a", is_flag=True)
    @option("-b", is_flag=True)
    @option("-n", type=int)
    def c(a, b, n):
        echo(f"{a} {b} {n}")

    assert run(runner, c, ["-ab", "-n5"]).stdout == "True True 5\n"
    assert run(runner, c, ["-abn", "7"]).stdout == "True True 7\n"


def test_FP03_double_dash_ends_options(runner):
    @command()
    @option("--flag", is_flag=True)
    @argument("rest", nargs=-1)
    def c(flag, rest):
        echo(f"{flag} {rest}")

    res = run(runner, c, ["--", "--flag", "x"])
    assert res.stdout == "False ('--flag', 'x')\n"


def test_FP03_leaf_mixes_options_and_arguments(runner):
    @command()
    @option("--v", is_flag=True)
    @argument("a")
    def c(v, a):
        echo(f"{v} {a}")

    assert run(runner, c, ["x", "--v"]).stdout == "True x\n"


def test_FP03_unknown_option_is_usage_error(runner):
    @command()
    def c():
        pass

    res = run(runner, c, ["--zzz"])
    assert res.exit_code == 2 and "--zzz" in res.stderr


def test_FP03_missing_value_is_usage_error(runner):
    @command()
    @option("--name")
    def c(name):
        pass

    assert run(runner, c, ["--name"]).exit_code == 2


def test_FP03_required_option_missing_is_usage_error(runner):
    ran = []

    @command()
    @option("--name", required=True)
    def c(name):
        ran.append(1)

    res = run(runner, c, [])
    assert res.exit_code == 2 and ran == []


def test_FP03_boolean_flag_default_false_and_true_on_presence(runner):
    @command()
    @option("--x", is_flag=True)
    def c(x):
        echo(repr(x))

    assert run(runner, c, []).stdout == "False\n"
    assert run(runner, c, ["--x"]).stdout == "True\n"


def test_FP03_on_off_pair(runner):
    @command()
    @option("--shout/--no-shout", default=False)
    def c(shout):
        echo(repr(shout))

    assert run(runner, c, ["--shout"]).stdout == "True\n"
    assert run(runner, c, ["--no-shout"]).stdout == "False\n"
    assert run(runner, c, []).stdout == "False\n"


def test_FP03_flag_after_double_dash_is_argument(runner):
    @command()
    @option("--x", is_flag=True)
    @argument("rest", nargs=-1)
    def c(x, rest):
        echo(f"{x}|{rest}")

    assert run(runner, c, ["--", "--x"]).stdout == "False|('--x',)\n"


def test_FP03_counting_option_zero_when_omitted(runner):
    @command()
    @option("-v", count=True)
    def c(v):
        echo(repr(v))

    assert run(runner, c, []).stdout == "0\n"
    assert run(runner, c, ["-vvv"]).stdout == "3\n"


def test_FP03_repeatable_option_tuple_in_order(runner):
    @command()
    @option("--tag", multiple=True)
    def c(tag):
        echo(repr(tag))

    assert run(runner, c, []).stdout == "()\n"
    assert run(runner, c, ["--tag", "a", "--tag", "b"]).stdout == "('a', 'b')\n"


def test_FP03_repeatable_default_must_be_sequence(runner):
    @command()
    @option("--tag", multiple=True, default="abc")
    def c(tag):
        pass

    res = run(runner, c, [])
    assert res.exit_code == 2
    assert "iterable" in res.stderr


def test_FP03_repeatable_list_default(runner):
    @command()
    @option("--tag", multiple=True, default=["x", "y"])
    def c(tag):
        echo(repr(tag))

    assert run(runner, c, []).stdout == "('x', 'y')\n"


def test_FP03_multi_value_option_fixed_arity(runner):
    @command()
    @option("--pair", nargs=2, type=int)
    @argument("rest", nargs=-1)
    def c(pair, rest):
        echo(f"{pair} {rest}")

    assert run(runner, c, ["--pair", "1", "2", "x"]).stdout == "(1, 2) ('x',)\n"
    assert run(runner, c, ["--pair", "1"]).exit_code == 2


def test_FP03_tuple_type_option(runner):
    @command()
    @option("--point", type=Tuple([str, int]))
    def c(point):
        echo(repr(point))

    assert run(runner, c, ["--point", "a", "3"]).stdout == "('a', 3)\n"


def test_FP03_optional_value_option(runner):
    @command()
    @option("--opt", is_flag=False, flag_value="FLAG", default="DEF")
    def c(opt):
        echo(opt)

    assert run(runner, c, []).stdout == "DEF\n"
    assert run(runner, c, ["--opt"]).stdout == "FLAG\n"
    assert run(runner, c, ["--opt", "VAL"]).stdout == "VAL\n"


def test_FP03_prefix_slash_option(runner):
    @command()
    @option("/x", is_flag=True)
    def c(x):
        echo(repr(x))

    assert run(runner, c, ["/x"]).stdout == "True\n"


def test_FP03_deprecated_option_cannot_be_required():
    with pytest.raises((OptlynDeclarationError, TypeError, ValueError)):
        option("--x", deprecated=True, required=True)(lambda x: None)


def test_FP03_deprecated_option_warns_only_when_supplied(runner):
    @command()
    @option("--old", deprecated=True, default="d")
    def c(old):
        echo(old)

    assert run(runner, c, []).stderr == ""
    res = run(runner, c, ["--old", "v"])
    assert "deprecated" in res.stderr.lower() and res.stdout == "v\n"


def test_FP03_feature_switch_group_last_declared_wins(runner):
    @command()
    @option("--red", "color", flag_value="red", default=None)
    @option("--blue", "color", flag_value="blue")
    def c(color):
        echo(str(color))

    assert run(runner, c, ["--red"]).stdout == "red\n"
    assert run(runner, c, ["--blue"]).stdout == "blue\n"


def test_FP03_callback_refusal_is_usage_error_and_callback_not_run(runner):
    ran = []

    def check(ctx, param, value):
        if value < 0:
            raise BadParameter("must be positive", ctx, param)
        return value

    @command()
    @option("--n", type=int, callback=check)
    def c(n):
        ran.append(n)

    res = run(runner, c, ["--n", "-1"])
    assert res.exit_code == 2 and ran == []
    assert "must be positive" in res.stderr


def test_FP03_callback_runs_for_missing_and_can_default_from_earlier(runner):
    @command()
    @option("--a", default="x")
    @option("--b", default=None)
    def c(a, b):
        echo(str(b))

    assert run(runner, c, []).stdout == "None\n"


def test_FP03_missing_param_still_runs_callback(runner):
    seen = []

    def cb(ctx, param, value):
        seen.append(value)
        return value

    @command()
    @option("--a", callback=cb)
    def c(a):
        pass

    run(runner, c, [])
    assert seen == [None]


def test_FP03_callable_default_invoked(runner):
    calls = []

    def make():
        calls.append(1)
        return "made"

    @command()
    @option("--v", default=make)
    def c(v):
        echo(v)

    assert run(runner, c, []).stdout == "made\n"
    assert calls == [1]


def test_FP03_env_var_fills_option_and_skips_when_empty(runner, monkeypatch):
    @command()
    @option("--token", envvar=["TOK_A", "TOK_B"])
    def c(token):
        echo(token)

    monkeypatch.setenv("TOK_B", "bee")
    monkeypatch.setenv("TOK_A", "")
    assert run(runner, c, []).stdout == "bee\n"
    monkeypatch.setenv("TOK_A", "ay")
    assert run(runner, c, []).stdout == "ay\n"
    assert run(runner, c, ["--token", "cli"]).stdout == "cli\n"


def test_FP03_env_value_converted_and_satisfies_required(runner, monkeypatch):
    @command()
    @option("--n", type=int, envvar="N_VAR", required=True)
    def c(n):
        echo(str(n + 1))

    monkeypatch.setenv("N_VAR", "41")
    assert run(runner, c, []).stdout == "42\n"


def test_FP03_env_bool_flag_values(runner, monkeypatch):
    @command()
    @option("--on", is_flag=True, envvar="ON_VAR")
    def c(on):
        echo(repr(on))

    for value, expected in [("yes", "True"), (" TRUE ", "True"), ("0", "False"), ("off", "False"), ("   ", "False")]:
        monkeypatch.setenv("ON_VAR", value)
        assert run(runner, c, []).stdout == expected + "\n", value
    monkeypatch.setenv("ON_VAR", "maybe")
    res = run(runner, c, [])
    assert res.exit_code == 2


def test_FP03_env_list_split_for_multiple(runner, monkeypatch):
    @command()
    @option("--item", multiple=True, envvar="ITEMS")
    def c(item):
        echo(repr(item))

    monkeypatch.setenv("ITEMS", "a  b c")
    assert run(runner, c, []).stdout == "('a', 'b', 'c')\n"


def test_FP03_auto_envvar_prefix(runner, monkeypatch):
    @group(context_settings={"auto_envvar_prefix": "MYAPP"})
    def cli():
        pass

    @cli.command()
    @option("--host")
    def serve(host):
        echo(host)

    monkeypatch.setenv("MYAPP_SERVE_HOST", "example.org")
    assert runner.invoke(cli, ["serve"]).stdout == "example.org\n"


def test_FP03_auto_prefix_opt_out(runner, monkeypatch):
    @command(context_settings={"auto_envvar_prefix": "APP"})
    @option("--host", allow_from_autoenv=False)
    def c(host):
        echo(str(host))

    monkeypatch.setenv("APP_HOST", "zzz")
    assert run(runner, c, []).stdout == "None\n"


def test_FP07_default_map_fills_and_cli_wins(runner):
    @command()
    @option("--port", type=int, default=1)
    def c(port):
        echo(str(port))

    assert run(runner, c, [], default_map={"port": 9}).stdout == "9\n"
    assert run(runner, c, ["--port", "3"], default_map={"port": 9}).stdout == "3\n"


def test_FP07_default_map_nests_by_subcommand(runner):
    @group()
    def cli():
        pass

    @cli.command()
    @option("--port", type=int)
    def serve(port):
        echo(str(port))

    dm = {"serve": {"port": 80}, "other": {"port": 1}}
    assert runner.invoke(cli, ["serve"], default_map=dm).stdout == "80\n"


def test_FP07_default_map_string_split_for_multi_value(runner):
    @command()
    @option("--pt", nargs=2, type=int)
    def c(pt):
        echo(repr(pt))

    assert run(runner, c, [], default_map={"pt": "3 4"}).stdout == "(3, 4)\n"


def test_FP07_default_map_string_refused_for_repeatable(runner):
    @command()
    @option("--t", multiple=True)
    def c(t):
        pass

    res = run(runner, c, [], default_map={"t": "abc"})
    assert res.exit_code == 2 and "iterable" in res.stderr


def test_FP07_get_parameter_source(runner, monkeypatch):
    from optlyn.core import ParameterSource

    seen = {}

    @command()
    @option("--a")
    @option("--b", default="d")
    @option("--c", envvar="CVAR")
    @option("--d", default="from-map")
    @option("--p", prompt=True)
    @pass_context
    def c(ctx, a, b, c, d, p):
        for name in ("a", "b", "c", "d", "p", "nope"):
            seen[name] = ctx.get_parameter_source(name)

    monkeypatch.setenv("CVAR", "x")
    res = run(runner, c, ["--a", "1", "--p", "pp"], default_map={"d": 9})
    assert res.exit_code == 0, res.output
    assert seen["a"] is ParameterSource.COMMANDLINE
    assert seen["b"] is ParameterSource.DEFAULT
    assert seen["c"] is ParameterSource.ENVIRONMENT
    assert seen["d"] is ParameterSource.DEFAULT_MAP
    assert seen["p"] is ParameterSource.COMMANDLINE
    assert seen["nope"] is None
    assert len({seen[k] for k in ("a", "b", "c", "d")}) == 4


# -- types -------------------------------------------------------------------

def test_FP05_int_and_float_conversion(runner):
    @command()
    @option("--i", type=int)
    @option("--f", type=float)
    def c(i, f):
        echo(f"{i!r} {f!r}")

    assert run(runner, c, ["--i", "3", "--f", "2.5"]).stdout == "3 2.5\n"
    res = run(runner, c, ["--i", "1.5"])
    assert res.exit_code == 2 and "--i" in res.stderr or "'--i'" in res.stderr


def test_FP05_default_type_inferred_from_default(runner):
    @command()
    @option("--n", default=5)
    def c(n):
        echo(repr(n))

    assert run(runner, c, ["--n", "9"]).stdout == "9\n"


def test_FP05_bool_text_conversion(runner):
    @command()
    @option("--b", type=BOOL)
    def c(b):
        echo(repr(b))

    assert run(runner, c, ["--b", "YES"]).stdout == "True\n"
    assert run(runner, c, ["--b", "off"]).stdout == "False\n"
    assert run(runner, c, ["--b", "maybe"]).exit_code == 2


def test_FP05_uuid(runner):
    @command()
    @option("--u", type=UUID)
    def c(u):
        echo(type(u).__name__)

    assert run(runner, c, ["--u", str(uuid.uuid4())]).stdout == "UUID\n"


def test_FP05_choice_case_sensitive_by_default(runner):
    @command()
    @option("--c", type=Choice(["alpha", "beta"]))
    def c(c):
        echo(c)

    assert run(runner, c, ["--c", "alpha"]).stdout == "alpha\n"
    res = run(runner, c, ["--c", "ALPHA"])
    assert res.exit_code == 2 and "one of" in res.stderr


def test_FP05_choice_case_insensitive_returns_original(runner):
    @command()
    @option("--c", type=Choice(["Alpha", "Beta"], case_sensitive=False))
    def c(c):
        echo(c)

    assert run(runner, c, ["--c", "alpha"]).stdout == "Alpha\n"


def test_FP05_choice_enum_member_delivered(runner):
    class Color(enum.Enum):
        RED = 1
        GREEN = 2

    @command()
    @option("--c", type=Choice(Color, case_sensitive=False))
    def c(c):
        echo(repr(c))

    assert run(runner, c, ["--c", "red"]).stdout == "<Color.RED: 1>\n"


def test_FP05_choice_repeatable(runner):
    @command()
    @option("--c", type=Choice(["a", "b"]), multiple=True)
    def c(c):
        echo(repr(c))

    assert run(runner, c, ["--c", "a", "--c", "b"]).stdout == "('a', 'b')\n"


def test_FP05_choice_completion_metavar_in_help(runner):
    @command()
    @option("--c", type=Choice(["one", "two"]))
    def c(c):
        pass

    assert "[one|two]" in run(runner, c, ["--help"]).stdout


def test_FP05_datetime_formats(runner):
    @command()
    @option("--when", type=DateTime())
    def c(when):
        echo(when.isoformat())

    assert run(runner, c, ["--when", "2024-01-02"]).stdout == "2024-01-02T00:00:00\n"
    assert run(runner, c, ["--when", "2024-01-02T03:04:05"]).stdout == "2024-01-02T03:04:05\n"
    assert run(runner, c, ["--when", "2024-01-02 03:04:05"]).stdout == "2024-01-02T03:04:05\n"
    assert run(runner, c, ["--when", "02/01/2024"]).exit_code == 2


def test_FP05_datetime_custom_formats_replace_defaults(runner):
    @command()
    @option("--when", type=DateTime(["%d.%m.%Y"]))
    def c(when):
        echo(when.isoformat())

    assert run(runner, c, ["--when", "02.01.2024"]).stdout == "2024-01-02T00:00:00\n"
    assert run(runner, c, ["--when", "2024-01-02"]).exit_code == 2


def test_FP05_int_range_closed_and_clamp(runner):
    @command()
    @option("--r", type=IntRange(1, 5))
    @option("--c", type=IntRange(1, 5, clamp=True))
    def c(r, c):
        echo(f"{r} {c}")

    assert run(runner, c, ["--r", "3", "--c", "9"]).stdout == "3 5\n"
    res = run(runner, c, ["--r", "9", "--c", "1"])
    assert res.exit_code == 2 and "--r" in res.stderr


def test_FP05_int_range_clamp_open_bound_adjacent(runner):
    rng = IntRange(0, 10, min_open=True, max_open=True, clamp=True)
    assert rng.convert("0", None, None) == 1
    assert rng.convert("10", None, None) == 9
    assert rng.convert("-5", None, None) == 1
    closed = IntRange(0, 10, clamp=True)
    assert closed.convert("-5", None, None) == 0
    assert closed.convert("99", None, None) == 10


def test_FP05_float_range_rules():
    with pytest.raises((OptlynDeclarationError, TypeError, ValueError)):
        FloatRange(0.0, 1.0, min_open=True, clamp=True)
    r = FloatRange(0.0, 1.0, clamp=True)
    assert r.convert("2.5", None, None) == 1.0
    assert r.convert("-1", None, None) == 0.0
    with pytest.raises(BadParameter):
        FloatRange(0.0, 1.0).convert("2", None, None)


def test_FP05_custom_type_and_pass_through(runner):
    class Upper(ParamType):
        name = "upper"

        def convert(self, value, param, ctx):
            if isinstance(value, str) and value.islower():
                return value.upper()
            self.fail("bad", param, ctx)

    @command()
    @option("--u", type=Upper())
    def c(u):
        echo(u)

    assert run(runner, c, ["--u", "abc"]).stdout == "ABC\n"
    assert run(runner, c, ["--u", "ABC"]).exit_code == 2


def test_FP05_conversion_function_refusal(runner):
    def parse_even(text):
        value = int(text)
        if value % 2:
            raise ValueError("not even")
        return value

    @command()
    @option("--e", type=parse_even)
    def c(e):
        echo(str(e))

    assert run(runner, c, ["--e", "4"]).stdout == "4\n"
    res = run(runner, c, ["--e", "3"])
    assert res.exit_code == 2 and "--e" in res.stderr


def test_FP05_string_type_keeps_numeric_looking_token(runner):
    @command()
    @option("--s", type=str)
    def c(s):
        echo(repr(s))

    assert run(runner, c, ["--s", "007"]).stdout == "'007'\n"


# -- arguments ---------------------------------------------------------------

def test_FP04_argument_binding_in_order(runner):
    @command()
    @argument("a")
    @argument("b", type=int)
    def c(a, b):
        echo(f"{a} {b + 1}")

    assert run(runner, c, ["x", "1"]).stdout == "x 2\n"


def test_FP04_missing_required_argument_usage_error(runner):
    @command()
    @argument("a")
    def c(a):
        pass

    res = run(runner, c, [])
    assert res.exit_code == 2 and "A" in res.stderr.upper()


def test_FP04_optional_argument_default_and_absent(runner):
    @command()
    @argument("a", required=False)
    @argument("b", default="dflt")
    def c(a, b):
        echo(f"{a!r} {b}")

    assert run(runner, c, []).stdout == "None dflt\n"
    assert run(runner, c, ["x", "y"]).stdout == "'x' y\n"


def test_FP04_variadic_argument(runner):
    @command()
    @argument("files", nargs=-1)
    def c(files):
        echo(repr(files))

    assert run(runner, c, []).stdout == "()\n"
    assert run(runner, c, ["a", "b"]).stdout == "('a', 'b')\n"


def test_FP04_required_variadic_missing_is_error(runner):
    @command()
    @argument("files", nargs=-1, required=True)
    def c(files):
        pass

    assert run(runner, c, []).exit_code == 2


def test_FP04_fixed_arity_argument_delivered_as_tuple(runner):
    @command()
    @argument("pair", nargs=2)
    def c(pair):
        echo(repr(pair))

    assert run(runner, c, ["1", "2"]).stdout == "('1', '2')\n"


def test_FP04_argument_env_explicit_only(runner, monkeypatch):
    @command()
    @argument("a", envvar="A_ENV", required=False)
    @argument("dest_named_b", required=False)
    def c(a, dest_named_b):
        echo(repr(a))

    monkeypatch.setenv("A_ENV", "from-env")
    assert run(runner, c, []).stdout == "'from-env'\n"
    assert run(runner, c, ["cli"]).stdout == "'cli'\n"


def test_FP04_argument_declared_with_dash_in_name_uses_upper_metavar(runner):
    @command()
    @argument("src")
    def c(src):
        pass

    assert "SRC" in run(runner, c, ["--help"]).stdout


def test_FP04_deprecated_argument_cannot_be_required():
    from optlyn import Argument

    with pytest.raises((OptlynDeclarationError, TypeError, ValueError)):
        Argument(["x"], deprecated=True, required=True)


# -- files and paths ---------------------------------------------------------

def test_FP09_file_read_existing(runner, tmp_path):
    target = tmp_path / "in.txt"
    target.write_text("hello file")

    @command()
    @argument("f", type=File("r"))
    def c(f):
        echo(f.read())

    assert run(runner, c, [str(target)]).stdout == "hello file\n"


def test_FP09_file_missing_read_is_usage_error_naming_path(runner, tmp_path):
    missing = str(tmp_path / "nope.txt")

    @command()
    @argument("f", type=File("r"))
    def c(f):
        pass

    res = run(runner, c, [missing])
    assert res.exit_code == 2 and missing in res.stderr


def test_FP09_file_write_lazy_not_truncated_until_used(runner, tmp_path):
    target = tmp_path / "out.txt"
    target.write_text("keep")

    @command()
    @option("--out", type=File("w"))
    def c(out):
        pass

    assert run(runner, c, ["--out", str(target)]).exit_code == 0
    assert target.read_text() == "keep"


def test_FP09_file_write_nonlazy_truncates_before_callback(runner, tmp_path):
    target = tmp_path / "out.txt"
    target.write_text("keep")

    @command()
    @option("--out", type=File("w", lazy=False))
    def c(out):
        pass

    run(runner, c, ["--out", str(target)])
    assert target.read_text() == ""


def test_FP09_file_dash_is_stdout(runner):
    @command()
    @argument("f", type=File("w"))
    def c(f):
        echo("data", file=f)
        echo("after")

    res = run(runner, c, ["-"])
    assert res.stdout == "data\nafter\n"


def test_FP09_file_dash_read_is_stdin(runner):
    @command()
    @argument("f", type=File("r"))
    def c(f):
        echo(f.read().upper())

    res = runner.invoke(c, ["-"], input="piped text")
    assert "PIPED TEXT" in res.stdout


def test_FP09_binary_file_round_trip(runner, tmp_path):
    target = tmp_path / "b.bin"

    @command()
    @argument("f", type=File("wb"))
    def c(f):
        f.write(b"\x00\x01bytes")

    run(runner, c, [str(target)])
    assert target.read_bytes() == b"\x00\x01bytes"


def test_FP09_path_exists_and_type_checks(runner, tmp_path):
    f = tmp_path / "file.txt"
    f.write_text("x")
    d = tmp_path / "sub"
    d.mkdir()

    @command()
    @argument("p", type=Path(exists=True, dir_okay=False))
    def c(p):
        echo(str(p))

    assert run(runner, c, [str(f)]).stdout == f"{f}\n"
    res = run(runner, c, [str(d)])
    assert res.exit_code == 2 and str(d) in res.stderr
    res = run(runner, c, [str(tmp_path / "gone")])
    assert res.exit_code == 2


def test_FP09_path_allow_dash_without_opening(runner):
    @command()
    @argument("p", type=Path(allow_dash=True))
    def c(p):
        echo(p)

    assert run(runner, c, ["-"]).stdout == "-\n"


def test_FP09_path_type_pathlib(runner, tmp_path):
    import pathlib

    @command()
    @argument("p", type=Path(path_type=pathlib.Path))
    def c(p):
        echo(type(p).__name__)

    assert run(runner, c, [str(tmp_path)]).stdout == "PosixPath\n"


def test_FP09_path_resolve_path_does_not_expand_tilde(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    result = Path(resolve_path=True).convert("~nothere", None, None)
    assert result == os.path.join(os.path.realpath(tmp_path), "~nothere")


def test_FP09_format_filename_round_trips_bytes():
    from optlyn import format_filename

    assert format_filename("plain.txt") == "plain.txt"
    text = format_filename(b"\xff\xfe")
    assert text.encode("utf-8")
    assert format_filename("a/b.txt", shorten=True) == "b.txt"


# -- prompts, password and confirmation ---------------------------------------

def test_FP08_prompt_reads_value_when_omitted(runner):
    @command()
    @option("--name", prompt=True)
    def c(name):
        echo(f"hi {name}")

    res = runner.invoke(c, [], input="ann\n")
    assert res.exit_code == 0
    assert "Name: ann" in res.stdout
    assert res.stdout.rstrip().endswith("hi ann")


def test_FP08_prompt_not_read_when_supplied(runner):
    @command()
    @option("--name", prompt=True)
    def c(name):
        echo(name)

    res = runner.invoke(c, ["--name", "cli"], input="typed\n")
    assert res.stdout == "cli\n"


def test_FP08_prompt_custom_text_and_default(runner):
    @command()
    @option("--name", prompt="Who", default="zed")
    def c(name):
        echo(name)

    res = runner.invoke(c, [], input="\n")
    assert "Who [zed]" in res.stdout and res.stdout.rstrip().endswith("zed")


def test_FP08_prompt_reasks_on_conversion_failure(runner):
    @command()
    @option("--n", prompt=True, type=int)
    def c(n):
        echo(str(n))

    res = runner.invoke(c, [], input="abc\n12\n")
    assert res.stdout.rstrip().endswith("12")
    assert "not a valid integer" in res.stdout + res.stderr


def test_FP08_prompt_eof_is_abort(runner):
    @command()
    @option("--name", prompt=True)
    def c(name):
        echo(name)

    res = runner.invoke(c, [], input="")
    assert res.exit_code == 1


def test_FP08_prompt_hidden_input_not_echoed(runner):
    @command()
    @option("--pw", prompt=True, hide_input=True)
    def c(pw):
        echo("got it")

    res = runner.invoke(c, [], input="s3cret\n")
    assert "s3cret" not in res.output and "got it" in res.stdout


def test_FP08_password_option_confirmation_pair(runner):
    @command()
    @password_option()
    def c(password):
        echo(f"len={len(password)}")

    res = runner.invoke(c, [], input="abc\nabc\n")
    assert res.exit_code == 0 and "len=3" in res.stdout


def test_FP08_password_option_mismatch_asks_again(runner):
    @command()
    @password_option()
    def c(password):
        echo(password)

    res = runner.invoke(c, [], input="one\ntwo\nsecret\nsecret\n")
    assert res.exit_code == 0 and res.stdout.rstrip().endswith("secret")
    assert "do not match" in res.stdout + res.stderr


def test_FP08_confirmation_option_flag_skips_question(runner):
    @command()
    @confirmation_option()
    def c():
        echo("ran")

    res = runner.invoke(c, ["--yes"], input="")
    assert res.stdout == "ran\n"


def test_FP08_confirmation_option_declined_aborts(runner):
    @command()
    @confirmation_option(prompt="Proceed?")
    def c():
        echo("ran")

    res = runner.invoke(c, [], input="n\n")
    assert res.exit_code == 1 and "ran" not in res.stdout and "Aborted" in res.stderr


def test_FP08_confirmation_option_accepted_runs(runner):
    @command()
    @confirmation_option()
    def c():
        echo("ran")

    res = runner.invoke(c, [], input="y\n")
    assert res.exit_code == 0 and "ran" in res.stdout


def test_FP08_standalone_prompt_and_confirm_helpers(runner):
    from optlyn import confirm, prompt

    @command()
    def c():
        n = prompt("Number", type=int)
        ok = confirm("Sure?")
        echo(f"{n} {ok}")

    res = runner.invoke(c, [], input="5\nyes\n")
    assert res.stdout.rstrip().endswith("5 True")


def test_FP08_confirm_empty_takes_default(runner):
    from optlyn import confirm

    @command()
    def c():
        echo(str(confirm("Go?", default=True)))

    res = runner.invoke(c, [], input="\n")
    assert res.stdout.rstrip().endswith("True")


def test_FP04_second_variadic_argument_refused_at_declaration():
    from optlyn import Argument, Command

    with pytest.raises((OptlynDeclarationError, TypeError, ValueError)):
        Command(name="x", params=[Argument(["a"], nargs=-1), Argument(["b"], nargs=-1)])


def test_FP08_prompt_text_unstyled_when_not_terminal(runner):
    from optlyn import style

    @command()
    @option("--name", prompt=style("Name", fg="red"))
    def c(name):
        echo(name)

    res = runner.invoke(c, [], input="x\n")
    assert "\x1b" not in res.stdout and "Name: x" in res.stdout


def test_FP09_atomic_write_replaces_on_close(tmp_path):
    from optlyn.utils import open_file

    target = tmp_path / "data.txt"
    target.write_text("original")
    handle = open_file(str(target), "w", atomic=True, encoding="utf-8")
    handle.write("new content")
    assert target.read_text() == "original"  # readers still see the original
    handle.close()
    assert target.read_text() == "new content"
    assert not [p for p in tmp_path.iterdir() if p.name.endswith(".tmp")]


def test_FP09_lazy_write_fails_when_io_starts_with_general_error(runner, tmp_path):
    bad = tmp_path / "no-such-dir" / "out.txt"

    @command()
    @argument("f", type=File("w"))
    def c(f):
        f.write("x")
        echo("after write")

    res = runner.invoke(c, [str(bad)])
    assert res.exit_code == 1
    assert "after write" not in res.stdout
    assert str(bad) in res.stderr


def test_FP09_lazy_write_never_used_does_not_fail(runner, tmp_path):
    bad = tmp_path / "no-such-dir" / "out.txt"

    @command()
    @argument("f", type=File("w"))
    def c(f):
        echo("unused")

    res = runner.invoke(c, [str(bad)])
    assert res.exit_code == 0 and res.stdout == "unused\n"


def test_FP09_dash_write_does_not_close_stdout(runner):
    @command()
    @argument("f", type=File("w"))
    def c(f):
        echo("first", file=f)
        f.close()
        echo("second")

    res = runner.invoke(c, ["-"])
    assert res.stdout == "first\nsecond\n"


def test_FP09_open_file_helper_immediate_and_closes(tmp_path):
    from optlyn import open_file

    with open_file(str(tmp_path / "r.txt"), "w") as handle:
        handle.write("abc")
    assert (tmp_path / "r.txt").read_text() == "abc"
    with pytest.raises(Exception) as info:
        open_file(str(tmp_path / "missing.txt"), "r")
    assert "missing.txt" in str(info.value)


def test_FP05_uuid_never_inferred_from_default(runner):
    import uuid as uuid_mod

    @command()
    @option("--u", default=uuid_mod.UUID(int=1))
    def c(u):
        echo(type(u).__name__)

    # the type is text, not UUID: neither the default nor typed text becomes a UUID
    assert runner.invoke(c, []).stdout == "str\n"
    assert runner.invoke(c, ["--u", "abc"]).stdout == "str\n"
