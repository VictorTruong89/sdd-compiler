"""Shell completion and standalone program behaviour (spec: section 3 main, section 8; FP-12, FP-13)."""

import os
import subprocess
import sys

import pytest

from optlyn import Choice, argument, command, echo, group, option, File, Path
from optlyn.paramtypes import CompletionItem
from optlyn.testing import CliRunner
from optlyn.core import complete_var_name


@pytest.fixture
def runner():
    return CliRunner()


def complete(cli, prog, comp_words, cword, shell="bash", monkeypatch=None):
    var = complete_var_name(prog)
    os.environ[var] = f"{shell}_complete"
    os.environ["COMP_WORDS"] = comp_words
    os.environ["COMP_CWORD"] = str(cword)
    try:
        return CliRunner().invoke(cli, [], prog_name=prog)
    finally:
        for key in (var, "COMP_WORDS", "COMP_CWORD"):
            os.environ.pop(key, None)


def test_FP12_variable_name_derivation():
    assert complete_var_name("my-tool") == "_MY_TOOL_COMPLETE"
    assert complete_var_name("tool") == "_TOOL_COMPLETE"


def test_FP12_source_prints_script_and_skips_callback(runner, monkeypatch):
    ran = []

    @command()
    def tool():
        ran.append(1)

    monkeypatch.setenv("_MY_TOOL_COMPLETE", "bash_source")
    res = CliRunner().invoke(tool, [], prog_name="my-tool")
    assert res.exit_code == 0
    assert "complete -o default -F" in res.stdout
    assert "my-tool" in res.stdout
    assert ran == []


def test_FP12_complete_subcommands_and_options(monkeypatch):
    @group()
    def cli():
        pass

    @cli.command()
    def alpha():
        """Alpha command."""

    @cli.command()
    def beta():
        pass

    @cli.command(hidden=True)
    def hidden_one():
        pass

    res = complete(cli, "tool", "tool a", 1)
    assert res.stdout.splitlines() == ["plain,alpha"]
    res = complete(cli, "tool", "tool ", 1)
    assert set(res.stdout.splitlines()) == {"plain,alpha", "plain,beta"}
    assert "hidden" not in res.stdout


def test_FP12_options_listed_only_after_dash(monkeypatch):
    @command()
    @option("--verbose", is_flag=True)
    def c(verbose):
        pass

    res = complete(c, "tool", "tool --v", 1)
    assert "plain,--verbose" in res.stdout
    res = complete(c, "tool", "tool ", 1)
    assert "--verbose" not in res.stdout


def test_FP12_choice_values_filtered_by_prefix(monkeypatch):
    @command()
    @option("--mode", type=Choice(["fast", "full", "slow"]))
    def c(mode):
        pass

    res = complete(c, "tool", "tool --mode f", 2)
    assert set(res.stdout.splitlines()) == {"plain,fast", "plain,full"}


def test_FP12_path_request_kinds(monkeypatch):
    @command()
    @argument("src", type=Path(file_okay=True, dir_okay=False))
    @argument("dst", type=File("w"))
    def c(src, dst):
        pass

    res = complete(c, "tool", "tool x ", 2)
    assert res.stdout.strip() == "file,"

    @command()
    @argument("d", type=Path(file_okay=False))
    def dirs(d):
        pass

    res = complete(dirs, "tool", "tool ", 1)
    assert res.stdout.strip() == "dir,"


def test_FP12_custom_completion_function_with_help(monkeypatch):
    def suggest(ctx, param, incomplete):
        return [CompletionItem("alpha", help="the first"), "beta"]

    @command()
    @option("--x", shell_complete=suggest)
    def c(x):
        pass

    res = complete(c, "tool", "tool --x ", 2, shell="zsh")
    assert "plain,alpha\tthe first" in res.stdout
    assert "plain,beta" in res.stdout


def test_FP12_unknown_instruction_runs_nothing(monkeypatch, runner):
    ran = []

    @command()
    def tool():
        ran.append(1)

    monkeypatch.setenv("_TOOL_COMPLETE", "tcsh_complete")
    res = CliRunner().invoke(tool, [], prog_name="tool")
    assert ran == []
    assert res.stdout == ""


def test_FP12_incomplete_token_matching_nothing_is_empty(monkeypatch):
    @group()
    def cli():
        pass

    @cli.command()
    def alpha():
        pass

    res = complete(cli, "tool", "tool zzz", 1)
    assert res.exit_code == 0 and res.stdout == ""


def test_FP12_fish_uses_incomplete_token_directly(monkeypatch):
    @group()
    def cli():
        pass

    @cli.command()
    def alpha():
        """Help for alpha."""

    @cli.command()
    def alps():
        pass

    os.environ["_TOOL_COMPLETE"] = "fish_complete"
    os.environ["COMP_WORDS"] = "tool"
    os.environ["COMP_CWORD"] = "al"
    try:
        res = CliRunner().invoke(cli, [], prog_name="tool")
    finally:
        for key in ("_TOOL_COMPLETE", "COMP_WORDS", "COMP_CWORD"):
            os.environ.pop(key, None)
    assert "plain,alpha" in res.stdout and "plain,alps" in res.stdout


# -- standalone program --------------------------------------------------------

def test_FP13_standalone_success_exits_zero():
    @command()
    def c():
        echo("ok")

    with pytest.raises(SystemExit) as info:
        c.main([])
    assert info.value.code == 0


def test_FP13_usage_error_exit_two_standalone(capsys):
    @command()
    @option("--need", required=True)
    def c(need):
        pass

    with pytest.raises(SystemExit) as info:
        c.main([], prog_name="tool")
    assert info.value.code == 2
    assert "Error" in capsys.readouterr().err


def test_FP13_abort_exit_one_standalone(capsys):
    @command()
    def c():
        raise_abort()

    def raise_abort():
        from optlyn.exceptions import Abort

        raise Abort()

    with pytest.raises(SystemExit) as info:
        c.main([])
    assert info.value.code == 1
    assert "Aborted!" in capsys.readouterr().err


def test_FP13_general_error_exit_one_standalone(capsys, tmp_path):
    missing = tmp_path / "missing.txt"

    @command()
    @argument("f", type=File("r", lazy=True))
    def c(f):
        f.read()

    with pytest.raises(SystemExit) as info:
        c.main([str(missing)], prog_name="tool")
    assert info.value.code == 1
    assert str(missing) in capsys.readouterr().err


def test_FP13_intentional_help_zero_versus_missing_command_two(runner):
    @group()
    def cli():
        pass

    @cli.command()
    def sub():
        pass

    assert runner.invoke(cli, ["--help"]).exit_code == 0
    assert runner.invoke(cli, []).exit_code == 2


def test_FP13_keyboard_interrupt_is_abort(capsys):
    @command()
    def c():
        raise KeyboardInterrupt()

    with pytest.raises(SystemExit) as info:
        c.main([])
    assert info.value.code == 1


def test_FP13_eof_is_abort_standalone(capsys):
    @command()
    def c():
        raise EOFError()

    with pytest.raises(SystemExit) as info:
        c.main([])
    assert info.value.code == 1


def test_N_000854_main_default_args_from_sys_argv(monkeypatch):
    @command()
    @argument("word")
    def c(word):
        return word

    monkeypatch.setattr(sys, "argv", ["prog", "hello"])
    assert c.main(standalone_mode=False) == "hello"


def test_FP01_runs_as_script_subprocess(tmp_path):
    script = tmp_path / "tool.py"
    script.write_text(
        "from optlyn import command, option, echo\n"
        "@command()\n"
        "@option('--who', default='world')\n"
        "def main(who):\n"
        "    echo(f'hello {who}')\n"
        "if __name__ == '__main__':\n"
        "    main()\n"
    )
    src = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src")
    env = dict(os.environ, PYTHONPATH=src)
    out = subprocess.run([sys.executable, str(script), "--who", "you"], capture_output=True, text=True, env=env)
    assert out.returncode == 0 and out.stdout == "hello you\n"
    bad = subprocess.run([sys.executable, str(script), "--nope"], capture_output=True, text=True, env=env)
    assert bad.returncode == 2 and "No such option" in bad.stderr


@pytest.mark.skipif(not __import__("shutil").which("bash"), reason="bash is not installed")
def test_FP12_bash_registration_script_completes_real_tool(tmp_path):
    """End to end: the sourced bash function calls the tool and fills COMPREPLY."""
    tool = tmp_path / "mytool"
    src = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src")
    tool.write_text(
        "#!/usr/bin/env python3\n"
        f"import sys; sys.path.insert(0, {src!r})\n"
        "from optlyn import group, command, option, argument, Choice, echo\n"
        "@group()\n"
        "def cli():\n"
        "    pass\n"
        "@cli.command()\n"
        "@option('--mode', type=Choice(['fast', 'full']))\n"
        "@argument('path')\n"
        "def build(mode, path):\n"
        "    echo(f'build {mode} {path}')\n"
        "@cli.command()\n"
        "def deploy():\n"
        "    echo('deploy')\n"
        "if __name__ == '__main__':\n"
        "    cli()\n"
    )
    tool.chmod(0o755)
    script = tmp_path / "check.sh"
    script.write_text(
        f"set -e\nexport PATH={tmp_path}:$PATH\n"
        "eval \"$(_MYTOOL_COMPLETE=bash_source mytool)\"\n"
        "COMP_WORDS=(mytool \"\")\nCOMP_CWORD=1\n_mytool_completion\n"
        "echo \"SUB:${COMPREPLY[*]}\"\n"
        "COMP_WORDS=(mytool build --mode \"\")\nCOMP_CWORD=3\n_mytool_completion\n"
        "echo \"VAL:${COMPREPLY[*]}\"\n"
    )
    out = subprocess.run(["bash", str(script)], capture_output=True, text=True)
    assert out.returncode == 0, out.stderr
    assert "SUB:build deploy" in out.stdout
    assert "VAL:fast full" in out.stdout
