"""Terminal helpers, invocation context, in-process runner, completion (spec: sections 6-9; FP-11, FP-12, FP-14)."""

import io
import os
import sys

import pytest

from optlyn import (
    argument,
    clear,
    command,
    echo,
    get_app_dir,
    get_current_context,
    group,
    option,
    pass_context,
    pause,
    secho,
    style,
    unstyle,
)
from optlyn.formatting import wrap_text
from optlyn.testing import CliRunner
from optlyn.termui import echo_via_pager, get_pager_file, progressbar


@pytest.fixture
def runner():
    return CliRunner()


# -- echo and styling -------------------------------------------------------

def test_FP11_echo_strips_styles_off_terminal(runner):
    @command()
    def c():
        echo(style("plain", fg="red", bold=True))

    assert runner.invoke(c, []).stdout == "plain\n"


def test_FP11_color_flag_forces_styles(runner):
    @command()
    def c():
        echo(style("hi", fg="red"))

    res = runner.invoke(c, [], color=True)
    assert "\x1b[31m" in res.stdout and "hi" in res.stdout


def test_FP11_color_off_strips_even_when_forced(runner):
    @command()
    def c():
        echo(style("hi", fg="green"))

    assert "\x1b" not in runner.invoke(c, [], color=False).stdout


def test_FP11_echo_nl_and_err(runner):
    @command()
    def c():
        echo("out", nl=False)
        echo("err", err=True)

    res = runner.invoke(c, [])
    assert res.stdout == "out" and res.stderr == "err\n"
    assert res.output == "outerr\n"


def test_FP11_echo_bytes(runner):
    @command()
    def c():
        echo(b"raw\x01")

    assert runner.invoke(c, []).stdout_bytes == b"raw\x01\n"


def test_FP11_style_variants_distinct():
    colors = ["black", "red", "bright_white", "reset"]
    outputs = {style("x", fg=c) for c in colors}
    assert len(outputs) == len(colors)
    assert style("x", fg="red") != style("x", bg="red")
    assert style("x", bold=True) != style("x", underline=True)
    assert style("x", fg=200) != style("x", fg=(1, 2, 3))
    assert style("x", bold=True, underline=True) not in (style("x", bold=True), style("x", underline=True))


def test_FP11_style_invalid_color_raises():
    with pytest.raises((TypeError, ValueError)):
        style("x", fg="not-a-color")
    with pytest.raises((TypeError, ValueError)):
        style("x", fg=300)
    with pytest.raises((TypeError, ValueError)):
        style("x", fg=(1, 2))


def test_FP11_unstyle_removes_ansi_only():
    assert unstyle(style("a", fg="red", bold=True) + " b") == "a b"


def test_FP11_secho_styles_and_strips(runner):
    @command()
    def c():
        secho("warn", fg="yellow", err=True)

    res = runner.invoke(c, [], color=True)
    assert "\x1b[33m" in res.stderr


def test_FP11_echo_ascii_stream_writes_utf8(monkeypatch):
    class AsciiStream(io.TextIOWrapper):
        pass

    raw = io.BytesIO()
    stream = io.TextIOWrapper(raw, encoding="ascii", errors="strict")
    echo("héllo", file=stream)
    stream.flush()
    assert "héllo".encode("utf-8") in raw.getvalue()


def test_FP11_wrap_text_accepts_any_string():
    assert wrap_text("") == ""
    assert wrap_text("a" * 200, width=20).count("\n") >= 9
    assert wrap_text("\x00\x7f weird é text") != ""


def test_FP11_wrap_text_preserve_paragraphs():
    out = wrap_text("para one\n\npara two", width=40, preserve_paragraphs=True)
    assert out == "para one\n\npara two"


def test_FP11_progressbar_visits_every_item_without_tty(capsys):
    items = list(range(5))
    seen = []
    with progressbar(items, label="work") as bar:
        for item in bar:
            seen.append(item)
    assert seen == items
    assert "work" in capsys.readouterr().out


def test_FP11_hidden_progressbar_prints_nothing(capsys):
    with progressbar(range(3), label="hidden", hidden=True) as bar:
        assert list(bar) == [0, 1, 2]
    assert capsys.readouterr().out == ""


def test_FP11_progressbar_explicit_length_and_update():
    with progressbar(length=10, hidden=True) as bar:
        bar.update(4)
        bar.update(6)
        assert bar.pos == 10


def test_FP11_pause_does_not_block_when_not_interactive(runner):
    @command()
    def c():
        pause("press it")

    res = runner.invoke(c, [], input="")
    assert res.exit_code == 0 and "press it" in res.stdout


def test_FP11_clear_does_nothing_without_terminal(runner):
    @command()
    def c():
        clear()

    assert runner.invoke(c, []).stdout == ""


def test_FP11_get_app_dir_unix_name_and_xdg(monkeypatch):
    if sys.platform in ("darwin", "win32"):
        pytest.skip("unix only")
    monkeypatch.setenv("XDG_CONFIG_HOME", "/tmp/xdgcfg")
    assert get_app_dir("My  App") == "/tmp/xdgcfg/my-app"
    monkeypatch.delenv("XDG_CONFIG_HOME")
    assert get_app_dir("My App").endswith(os.path.join(".config", "my-app"))
    assert get_app_dir("My App", force_posix=True).endswith(os.path.join(os.path.expanduser("~"), ".my-app"))


def test_FP11_pager_plain_when_not_interactive(capsys):
    echo_via_pager(["a\n", "b\n"])
    assert capsys.readouterr().out == "a\nb\n"
    echo_via_pager(lambda: "whole")
    assert capsys.readouterr().out == "whole"


def test_FP11_pager_file_context_manager_does_not_close_stdout(capsys):
    with get_pager_file() as f:
        f.write("pager text")
    assert "pager text" in capsys.readouterr().out
    print("still open")
    assert "still open" in capsys.readouterr().out


# -- context --------------------------------------------------------------

def test_N_000950_context_obj_inherited_and_shared(runner):
    class Store:
        def __init__(self):
            self.items = []

    @group()
    @pass_context
    def cli(ctx):
        ctx.obj = Store()

    @cli.command()
    @pass_context
    def add(ctx):
        ctx.obj.items.append("x")
        echo(str(len(ctx.obj.items)))

    @cli.command()
    @pass_context
    def read(ctx):
        echo(str(ctx.obj.items))

    assert runner.invoke(cli, ["add"]).stdout == "1\n"


def test_N_000965_context_params_visible_to_callbacks(runner):
    seen = {}

    def grab(ctx, param, value):
        seen["so_far"] = dict(ctx.params)
        return value

    @command()
    @option("--a", default="A")
    @option("--b", callback=grab, default="B")
    def c(a, b):
        pass

    runner.invoke(c, [])
    assert seen["so_far"] == {"a": "A"}


def test_N_000972_ctx_invoke_runs_another_command(runner):
    @command()
    @option("--n", default=1, type=int)
    def inner(n):
        echo(f"inner {n}")

    @command()
    @pass_context
    def outer(ctx):
        ctx.invoke(inner, n=7)
        ctx.forward(inner)

    assert runner.invoke(outer, []).stdout == "inner 7\ninner 1\n"


def test_FP07_forward_uses_current_values(runner):
    @command()
    @option("--n", default=1, type=int)
    def inner(n):
        echo(f"inner {n}")

    @command()
    @option("--n", default=5, type=int)
    @pass_context
    def outer(ctx, n):
        ctx.forward(inner)

    assert runner.invoke(outer, []).stdout == "inner 5\n"


def test_FP07_with_resource_closed_at_end(runner):
    closed = []

    class Res:
        def __enter__(self):
            return "value"

        def __exit__(self, *a):
            closed.append(True)

    @command()
    @pass_context
    def c(ctx):
        echo(ctx.with_resource(Res()))

    res = runner.invoke(c, [])
    assert res.stdout == "value\n"
    assert closed == [True]


def test_FP07_resources_closed_even_after_usage_failure(runner):
    closed = []

    class Res:
        def __enter__(self):
            return 1

        def __exit__(self, *a):
            closed.append(1)

    @group()
    @pass_context
    def cli(ctx):
        ctx.with_resource(Res())

    @cli.command()
    @option("--need", required=True)
    def sub(need):
        pass

    runner.invoke(cli, ["sub"])
    assert closed == [1]


def test_N_000974_with_ctx_makes_context_current_on_other_thread():
    import threading

    from optlyn import Context
    from optlyn.core import Command

    cmd = Command(name="x")
    ctx = Context(cmd, info_name="x")
    result = {}

    def worker():
        result["before"] = get_current_context(silent=True)
        with ctx:
            result["inside"] = get_current_context()

    with ctx:
        t = threading.Thread(target=worker)
        t.start()
        t.join()
        assert get_current_context() is ctx
    assert result["before"] is None
    assert result["inside"] is ctx


def test_N_000977_get_current_context_raises_without_context():
    with pytest.raises(RuntimeError):
        get_current_context()
    assert get_current_context(silent=True) is None


def test_N_000955_context_settings_max_content_width(runner):
    @command(help="w " * 200)
    def c():
        pass

    out = runner.invoke(c, ["--help"], max_content_width=40, terminal_width=40).stdout
    assert all(len(line) <= 40 for line in out.splitlines())


def test_N_000968_invoked_subcommand_for_chain_is_not_a_name(runner):
    from optlyn.core import CHAIN_SUBCOMMAND

    @group(chain=True)
    @pass_context
    def cli(ctx):
        echo(repr(ctx.invoked_subcommand is CHAIN_SUBCOMMAND))

    @cli.command()
    def a():
        pass

    assert runner.invoke(cli, ["a"]).stdout.startswith("True")


def test_N_000979_exit_status_from_callback(runner):
    @command()
    @pass_context
    def c(ctx):
        echo("before")
        ctx.exit(3)
        echo("after")

    res = runner.invoke(c, [])
    assert res.exit_code == 3 and res.stdout == "before\n"


def test_N_000980_abort_from_callback(runner):
    @command()
    @pass_context
    def c(ctx):
        ctx.abort()

    res = runner.invoke(c, [])
    assert res.exit_code == 1 and "Aborted" in res.stderr


def test_FP13_ctx_exit_zero_without_status(runner):
    @command()
    @pass_context
    def c(ctx):
        ctx.exit()

    assert runner.invoke(c, []).exit_code == 0


# -- runner ---------------------------------------------------------------

def test_N_001039_runner_captures_stdout_and_stderr_separately(runner):
    @command()
    def c():
        echo("out")
        echo("err", err=True)

    res = runner.invoke(c, [])
    assert res.stdout == "out\n" and res.stderr == "err\n"
    assert res.stdout_bytes == b"out\n" and res.stderr_bytes == b"err\n"


def test_N_001040_runner_env_none_unsets(runner, monkeypatch):
    monkeypatch.setenv("RUNNER_T", "set")

    @command()
    def c():
        echo(str(os.environ.get("RUNNER_T")))

    assert runner.invoke(c, [], env={"RUNNER_T": None}).stdout == "None\n"
    assert os.environ.get("RUNNER_T") == "set"
    assert runner.invoke(c, [], env={"RUNNER_T": "x"}).stdout == "x\n"


def test_N_001041_runner_input_feeds_prompts_and_echoes_visible(runner):
    @command()
    @option("--name", prompt=True)
    @option("--pw", prompt=True, hide_input=True)
    def c(name, pw):
        echo(f"{name}:{pw}")

    res = runner.invoke(c, [], input="ann\nsecret\n")
    assert "Name: ann" in res.stdout
    assert "Pw: \n" in res.stdout  # hidden input is not echoed back on the prompt line
    assert "Pw: secret" not in res.stdout
    assert res.stdout.rstrip().endswith("ann:secret")


def test_N_001041_echo_stdin_mode_echoes_reads(runner):
    runner2 = CliRunner(echo_stdin=True)

    @command()
    def c():
        line = sys.stdin.readline()
        echo(f"got {line.strip()}")

    res = runner2.invoke(c, [], input="hello\nignored\n")
    assert res.stdout == "hello\ngot hello\n"


def test_N_001042_runner_catch_exceptions_false_propagates(runner):
    @command()
    def c():
        raise ValueError("boom")

    with pytest.raises(ValueError):
        CliRunner().invoke(c, [], catch_exceptions=False)


def test_N_001043_result_exception_recorded(runner):
    @command()
    def c():
        raise KeyError("missing")

    res = runner.invoke(c, [])
    assert res.exit_code == 1 and isinstance(res.exception, KeyError)


def test_FP14_standalone_false_exception_inspectable(runner):
    @command()
    def c():
        raise ValueError("inspect me")

    res = runner.invoke(c, [], standalone_mode=False)
    assert isinstance(res.exception, ValueError)


def test_FP14_isolated_filesystem_removed_without_parent(runner):
    seen = {}

    @command()
    @argument("name")
    def c(name):
        with open(name, "w") as handle:
            handle.write("data")
        seen["cwd"] = os.getcwd()

    cwd = os.getcwd()
    with runner.isolated_filesystem() as path:
        assert os.getcwd() == path
        runner.invoke(c, ["out.txt"])
        assert os.path.exists(os.path.join(path, "out.txt"))
    assert os.getcwd() == cwd
    assert not os.path.exists(path)


def test_FP14_isolated_filesystem_left_in_place_with_parent(runner, tmp_path):
    with runner.isolated_filesystem(temp_dir=str(tmp_path)) as path:
        open(os.path.join(path, "keep.txt"), "w").close()
    assert os.path.exists(os.path.join(path, "keep.txt"))


def test_FP14_fd_capture_mode_captures_os_writes():
    fd_runner = CliRunner(capture="fd")

    @command()
    def c():
        os.write(1, b"raw-fd-out\n")
        echo("interp-out")

    res = fd_runner.invoke(c, [])
    assert "raw-fd-out" in res.stdout and "interp-out" in res.stdout


def test_FP14_default_capture_does_not_expose_fileno():
    @command()
    def c():
        try:
            sys.stdout.fileno()
            echo("has fd")
        except (io.UnsupportedOperation, OSError, ValueError, AttributeError):
            echo("no fd")

    assert CliRunner().invoke(c, []).stdout == "no fd\n"


def test_FP14_runner_subcommand_by_token_list(runner):
    @group()
    def cli():
        pass

    @cli.command()
    def sub():
        echo("sub")

    assert runner.invoke(cli, ["sub"]).stdout == "sub\n"


def test_N_000757_extra_keys_go_to_context(runner):
    @command()
    @pass_context
    def c(ctx):
        echo(str(ctx.terminal_width))

    assert runner.invoke(c, [], terminal_width=55).stdout == "55\n"


def test_FP14_runner_standalone_mode_off_returns_value(runner):
    @command()
    def c():
        return "value"

    res = runner.invoke(c, [], standalone_mode=False)
    assert res.return_value == "value" and res.exit_code == 0


def test_FP08_input_consumed_only_as_read(runner):
    @command()
    @option("--a", prompt=True)
    def c(a):
        echo(f"a={a} rest={sys.stdin.read()!r}")

    res = runner.invoke(c, [], input="one\ntwo\nthree")
    assert "a=one rest='two\\nthree'" in res.stdout
