"""Edge behaviour: token normalization, unknown-option handling, prefixes, chained files (FP-03, FP-04, FP-07, FP-10, FP-12)."""

import pytest

from optlyn import Choice, argument, command, echo, group, option, File
from optlyn.testing import CliRunner


@pytest.fixture
def runner():
    return CliRunner()


def test_FP07_token_normalization_applies_to_options_choices_and_commands(runner):
    norm = lambda s: s.lower().replace("_", "-")

    @group()
    def cli():
        pass

    @cli.command()
    @option("--dry-run", is_flag=True)
    @option("--mode", type=Choice(["Fast"]))
    def run_it(dry_run, mode):
        echo(f"{dry_run} {mode}")

    res = runner.invoke(cli, ["RUN-IT", "--DRY_RUN", "--mode", "fast"], token_normalize_func=norm)
    assert res.exit_code == 0, res.output
    assert res.stdout == "True Fast\n"
    assert runner.invoke(cli, ["RUN-IT"]).exit_code == 2


def test_FP04_ignore_unknown_options_consumed_as_arguments(runner):
    @command(context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
    @option("--known", is_flag=True)
    @argument("rest", nargs=-1)
    def c(known, rest):
        echo(f"{known} {rest}")

    res = runner.invoke(c, ["--known", "--mystery", "x"])
    assert res.exit_code == 0 and res.stdout == "True ('--mystery', 'x')\n"


def test_FP03_unknown_short_stack_leftover_kept(runner):
    @command(context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
    @option("-a", is_flag=True)
    @argument("rest", nargs=-1)
    def c(a, rest):
        echo(f"{a} {rest}")

    res = runner.invoke(c, ["-axq"])
    assert res.exit_code == 0 and res.stdout == "True ('-xq',)\n"


def test_FP04_option_shaped_leftover_is_error_with_only_allow_extra(runner):
    @command(context_settings={"allow_extra_args": True})
    @argument("a")
    def c(a):
        pass

    res = runner.invoke(c, ["x", "--weird"])
    assert res.exit_code == 2


def test_FP03_plus_prefix_option(runner):
    @command()
    @option("+x", is_flag=True)
    def c(x):
        echo(str(x))

    assert runner.invoke(c, ["+x"]).stdout == "True\n"


def test_FP03_long_option_with_short_alias_and_extra_alias(runner):
    @command()
    @option("-n", "--number", "--count", type=int, default=1)
    def c(number):
        echo(str(number))

    assert runner.invoke(c, ["--count", "4"]).stdout == "4\n"
    assert runner.invoke(c, ["-n", "2"]).stdout == "2\n"


def test_FP10_chained_subcommand_files_closed_after_its_callback(runner, tmp_path):
    seen = {}

    @group(chain=True)
    def cli():
        pass

    @cli.command()
    @argument("f", type=File("w"))
    def writer(f):
        seen["handle"] = f
        echo("written", file=f)

    target = tmp_path / "out.txt"
    res = runner.invoke(cli, ["writer", str(target)])
    assert res.exit_code == 0, res.output
    assert seen["handle"].closed
    assert target.read_text() == "written\n"


def test_FP10_chain_child_consumes_only_its_arguments(runner):
    @group(chain=True)
    def cli():
        pass

    @cli.command()
    @argument("a")
    def first(a):
        echo(f"first {a}")

    @cli.command()
    @argument("b")
    def second(b):
        echo(f"second {b}")

    res = runner.invoke(cli, ["first", "x", "second", "y"])
    assert res.stdout == "first x\nsecond y\n"


def test_FP12_zsh_suggestions_include_help(runner, monkeypatch):
    @group()
    def cli():
        pass

    @cli.command()
    def build():
        """Build the project."""

    monkeypatch.setenv("_TOOL_COMPLETE", "zsh_complete")
    monkeypatch.setenv("COMP_WORDS", "tool ")
    monkeypatch.setenv("COMP_CWORD", "1")
    res = CliRunner().invoke(cli, [], prog_name="tool")
    assert "plain,build\tBuild the project." in res.stdout


def test_FP12_source_scripts_exist_for_all_shells(runner, monkeypatch):
    from optlyn.shell_completion import SHELLS

    @command()
    def tool():
        pass

    for shell in SHELLS:
        monkeypatch.setenv("_TOOL_COMPLETE", f"{shell}_source")
        res = CliRunner().invoke(tool, [], prog_name="tool")
        assert res.exit_code == 0 and res.stdout.strip(), shell
        monkeypatch.delenv("_TOOL_COMPLETE")


def test_FP02_required_option_satisfied_by_declared_default(runner):
    @command()
    @option("--level", required=True, default="info")
    def c(level):
        echo(level)

    assert runner.invoke(c, []).stdout == "info\n"


def test_FP03_required_option_satisfied_by_envvar(runner, monkeypatch):
    @command()
    @option("--key", required=True, envvar="KEY_X")
    def c(key):
        echo(key)

    monkeypatch.setenv("KEY_X", "v")
    assert runner.invoke(c, []).stdout == "v\n"
