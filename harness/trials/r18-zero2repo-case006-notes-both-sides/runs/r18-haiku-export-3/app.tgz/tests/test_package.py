"""Package surface, layout and project metadata (spec: sections 1-2, 17, 1 Hardware)."""

import os

import pytest

import optlyn
from optlyn import formatting, testing
from optlyn.utils import expand_windows_args

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

SECTION_1 = """command group option argument help_option version_option custom_version_option
password_option confirmation_option pass_context pass_obj make_pass_decorator
Command Group CommandCollection Context Option Parameter ParamType BadParameter Abort
STRING INT FLOAT BOOL UUID UNPROCESSED Choice DateTime IntRange FloatRange Tuple File Path
echo secho style unstyle echo_via_pager get_pager_file progressbar prompt confirm getchar pause
edit launch clear get_app_dir get_current_context format_filename open_file""".split()


def test_N_000791_package_importable_from_src_layout():
    assert os.path.normpath(optlyn.__file__).startswith(os.path.join(ROOT, "src", "optlyn"))


def test_N_000799_section_1_names_exported_from_root():
    missing = [name for name in SECTION_1 if not hasattr(optlyn, name)]
    assert missing == []


def test_N_000800_testing_exports_cli_runner():
    assert testing.CliRunner is not None


def test_N_000801_formatting_exports_wrap_text():
    assert formatting.wrap_text("one two three", 7) == "one two\nthree"


def test_N_000794_zero_runtime_dependencies_declared():
    tomllib = pytest.importorskip("tomllib")
    with open(os.path.join(ROOT, "pyproject.toml"), "rb") as handle:
        data = tomllib.load(handle)
    assert data["project"]["dependencies"] == []
    assert data["project"]["requires-python"] == ">=3.10"
    assert data["tool"]["setuptools"]["packages"]["find"]["where"] == ["src"]


def test_N_000051_windows_argument_expansion_helper(tmp_path, monkeypatch):
    (tmp_path / "a.txt").write_text("")
    (tmp_path / "b.txt").write_text("")
    monkeypatch.chdir(tmp_path)
    assert expand_windows_args(["*.txt", "plain"]) == ["a.txt", "b.txt", "plain"]
    assert expand_windows_args(["nomatch*.zz"]) == ["nomatch*.zz"]
