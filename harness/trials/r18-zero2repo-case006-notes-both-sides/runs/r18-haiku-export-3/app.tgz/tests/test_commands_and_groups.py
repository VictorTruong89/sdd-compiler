"""Commands, groups, dispatch, and the help page (spec: section 3, FP-01, FP-02, FP-06, FP-10)."""

import pytest

from optlyn import (
    Command,
    CommandCollection,
    Group,
    argument,
    command,
    echo,
    group,
    option,
    pass_context,
    pass_obj,
    make_pass_decorator,
)
from optlyn.testing import CliRunner


@pytest.fixture
def runner():
    return CliRunner()


def test_N_000850_name_derived_from_function(runner):
    @command()
    def init_cmd():
        echo("ran")

    assert isinstance(init_cmd, Command)
    assert init_cmd.name == "init"
    res = runner.invoke(init_cmd, [])
    assert res.exit_code == 0 and res.output == "ran\n"


@pytest.mark.parametrize("func_name, expected", [
    ("my_group_name", "my-group-name"),
    ("sync_grp", "sync"),
    ("build_group", "build"),
    ("run_command", "run"),
    ("Mixed_Case", "mixed-case"),
])
def test_N_000851_name_suffix_rules(func_name, expected):
    def body():
        pass
    body.__name__ = func_name
    assert command()(body).name == expected


def test_N_000852_explicit_name_only_accepts_that_name(runner):
    @command("custom")
    def foo():
        echo("x")

    assert foo.name == "custom"
    assert runner.invoke(foo, []).exit_code == 0


def test_N_000850_function_runs_once(runner):
    calls = []

    @command()
    def once():
        calls.append(1)

    runner.invoke(once, [])
    assert calls == [1]


def test_N_000853_deprecated_command_still_runs_with_warning(runner):
    @command(deprecated=True)
    def old():
        echo("still runs")

    res = runner.invoke(old, [])
    assert res.exit_code == 0
    assert "still runs" in res.stdout
    assert "deprecated" in res.stderr.lower()


def test_N_000853_deprecated_custom_note_appears(runner):
    @command(deprecated="use new instead")
    def old():
        pass

    res = runner.invoke(old, [])
    assert "use new instead" in res.stderr


def test_N_000853_unknown_option_on_deprecated_command_is_usage_error(runner):
    @command(deprecated=True)
    def old():
        pass

    res = runner.invoke(old, ["--bogus"])
    assert res.exit_code == 2


def test_N_000853_hidden_command_still_invocable_and_not_in_help(runner):
    @group()
    def cli():
        pass

    @cli.command(hidden=True)
    def secret():
        echo("secret!")

    @cli.command()
    def public():
        pass

    assert runner.invoke(cli, ["secret"]).output == "secret!\n"
    assert "secret" not in runner.invoke(cli, ["--help"]).output


def test_N_000850_no_params_runs_with_empty_args(runner):
    @command()
    def noop():
        echo("noop")

    assert runner.invoke(noop, []).output == "noop\n"


def test_N_000850_extra_arguments_rejected(runner):
    @command()
    def noop():
        pass

    res = runner.invoke(noop, ["stray"])
    assert res.exit_code == 2
    assert "unexpected extra argument" in res.stderr


def test_FP01_allow_extra_args_tolerates_positionals(runner):
    @command(context_settings={"allow_extra_args": True})
    def noop():
        echo("ok")

    res = runner.invoke(noop, ["a", "b"])
    assert res.exit_code == 0 and res.stdout == "ok\n"


def test_FP01_callback_refused_on_bad_option_is_not_run(runner):
    ran = []

    @command()
    @option("--n", type=int)
    def c(n):
        ran.append(n)

    res = runner.invoke(c, ["--n", "abc"])
    assert res.exit_code == 2
    assert ran == []


def test_N_000854_main_standalone_false_returns_value():
    @command()
    def c():
        return 42

    assert c.main([], standalone_mode=False) == 42


def test_N_000854_main_standalone_false_propagates_usage_error():
    from optlyn.exceptions import UsageError

    @command()
    @option("--x", required=True)
    def c(x):
        pass

    with pytest.raises(UsageError):
        c.main([], standalone_mode=False)


def test_N_000861_calling_command_is_main(runner):
    @command()
    def c():
        return "rv"

    assert c([], standalone_mode=False) == "rv"


# -- help page ---------------------------------------------------------------

def test_FP02_help_does_not_run_callback_and_exits_zero(runner):
    ran = []

    @command()
    def c():
        """Describe me."""
        ran.append(1)

    res = runner.invoke(c, ["--help"])
    assert res.exit_code == 0
    assert ran == []
    assert "Describe me." in res.output
    assert res.output.startswith("Usage: ")


def test_FP02_docstring_formfeed_truncates(runner):
    @command()
    def c():
        """Visible.

        \f
        Hidden part.
        """

    out = runner.invoke(c, ["--help"]).output
    assert "Visible." in out
    assert "Hidden part" not in out


def test_N_000853_explicit_help_keeps_text_after_formfeed(runner):
    @command(help="Kept\fafter")
    def c():
        pass

    out = runner.invoke(c, ["--help"]).output
    assert "Keptafter" in out


def test_FP02_epilog_at_end(runner):
    @command(epilog="THE EPILOG")
    @option("--a")
    def c(a):
        """Doc."""

    out = runner.invoke(c, ["--help"]).output
    assert out.rstrip().endswith("THE EPILOG")


def test_FP02_option_metavar_and_help(runner):
    @command()
    @option("--count", type=int, help="How many times.")
    def c(count):
        pass

    out = runner.invoke(c, ["--help"]).output
    assert "--count" in out and "How many times." in out
    assert "INTEGER" in out


def test_FP02_positional_arguments_section_only_with_help(runner):
    @command()
    @argument("src", help="Source file.")
    @argument("dst")
    def c(src, dst):
        pass

    out = runner.invoke(c, ["--help"]).output
    assert "Positional arguments" in out
    assert "Source file." in out
    assert "DST" in out.split("Usage:")[1].splitlines()[0]


def test_FP02_usage_line_brackets_optional_and_variadic(runner):
    @command()
    @argument("req")
    @argument("files", nargs=-1)
    def c(req, files):
        pass

    usage = runner.invoke(c, ["--help"]).output.splitlines()[0]
    assert usage == "Usage: c [OPTIONS] REQ [FILES]..."


def test_FP02_help_option_names_replaced_via_context(runner):
    @command()
    def c():
        pass

    res = runner.invoke(c, ["-h"], help_option_names=["-h"])
    assert res.exit_code == 0 and "Usage:" in res.stdout
    res = runner.invoke(c, ["--help"], help_option_names=["-h"])
    assert res.exit_code == 2  # --help is no longer a help name: unknown option


def test_FP02_author_option_reusing_help_name_wins(runner):
    @command()
    @option("--help", is_flag=True)
    def c(help):
        echo(f"author help={help}")

    res = runner.invoke(c, ["--help"])
    assert "author help=True" in res.stdout


def test_FP02_parameter_named_help_does_not_disable_help(runner):
    @command()
    @argument("help")
    def c(help):
        echo(help)

    assert runner.invoke(c, ["--help"]).exit_code == 0
    assert runner.invoke(c, ["x"]).stdout == "x\n"


def test_FP02_version_option_prints_and_exits(runner):
    from optlyn import version_option

    @command()
    @version_option("1.2.3", prog_name="tool")
    def c():
        echo("body")

    res = runner.invoke(c, ["--version"])
    assert res.exit_code == 0
    assert "1.2.3" in res.stdout and "body" not in res.stdout


def test_FP02_custom_version_option_is_exact_text(runner):
    from optlyn import custom_version_option

    @command()
    @custom_version_option(lambda ctx: "build-42")
    def c():
        pass

    res = runner.invoke(c, ["--version"])
    assert res.stdout == "build-42\n"


def test_FP02_eager_first_typed_wins(runner):
    from optlyn import custom_version_option

    @command()
    @custom_version_option(lambda ctx: "VERSION")
    def c():
        pass

    res = runner.invoke(c, ["--help", "--version"])
    assert "VERSION" not in res.stdout and "Usage:" in res.stdout
    res = runner.invoke(c, ["--version", "--help"])
    assert res.stdout == "VERSION\n"


def test_FP02_version_option_detects_installed_distribution(runner):
    from optlyn import version_option

    @command()
    @version_option(package_name="pytest")
    def c():
        pass

    res = runner.invoke(c, ["--version"])
    import pytest as pt
    assert pt.__version__ in res.stdout


def test_FP02_hidden_option_absent_from_help(runner):
    @command()
    @option("--secret", hidden=True)
    @option("--shown")
    def c(secret, shown):
        pass

    out = runner.invoke(c, ["--help"]).output
    assert "--secret" not in out and "--shown" in out


def test_FP02_show_default_flag_false_hidden_true_shown(runner):
    @command()
    @option("--off", is_flag=True, default=False, show_default=True)
    @option("--on", is_flag=True, default=True, show_default=True)
    @option("--num", type=int, default=7, show_default=True)
    def c(off, on, num):
        pass

    out = runner.invoke(c, ["--help"]).output
    assert "[default: True]" in out
    assert "[default: 7]" in out
    assert "[default: False]" not in out


def test_FP02_show_envvar(runner):
    @command()
    @option("--token", envvar="TOKEN_VAR", show_envvar=True)
    def c(token):
        pass

    assert "TOKEN_VAR" in runner.invoke(c, ["--help"]).output


def test_FP02_no_args_is_help_leaf_usage_error(runner):
    @command(no_args_is_help=True)
    def c():
        echo("body")

    res = runner.invoke(c, [])
    assert res.exit_code == 2
    assert "Usage:" in res.stderr


def test_FP02_help_text_wraps_at_max_content_width(runner):
    long_text = " ".join(["word"] * 80)

    @command(help=long_text)
    def c():
        pass

    out = runner.invoke(c, ["--help"]).output
    for line in out.splitlines():
        assert len(line) <= 80


def test_FP02_help_text_single_newlines_not_hard_breaks(runner):
    @command(help="alpha\nbeta gamma")
    def c():
        pass

    out = runner.invoke(c, ["--help"]).output
    assert "alpha beta gamma" in out


def test_FP02_backspace_paragraph_keeps_line_breaks(runner):
    @command(help="\b\nline one\nline two\n\nafter")
    def c():
        pass

    out = runner.invoke(c, ["--help"]).output
    assert "line one\nline two" in out
    assert "\b" not in out


def test_FP02_short_help_first_sentence_in_group_listing(runner):
    @group()
    def cli():
        pass

    @cli.command()
    def short():
        """First sentence here. Second sentence."""

    @cli.command()
    def long_one():
        """This is a very long first sentence that absolutely cannot fit on one line of help."""

    out = runner.invoke(cli, ["--help"]).output
    assert "First sentence here." in out
    assert "Second sentence" not in out
    assert "..." in out


# -- groups ---------------------------------------------------------------------

def test_FP06_group_without_subcommand_is_usage_error_with_help(runner):
    @group()
    def cli():
        """Top."""
        echo("group body")

    @cli.command()
    def sub():
        echo("sub")

    res = runner.invoke(cli, [])
    assert res.exit_code == 2
    assert "group body" not in res.output
    assert "Usage:" in res.stderr


def test_FP06_group_callback_runs_before_child(runner):
    @group()
    def cli():
        echo("group")

    @cli.command()
    def sub():
        echo("child")

    res = runner.invoke(cli, ["sub"])
    assert res.stdout == "group\nchild\n"


def test_FP06_group_help_skips_callback(runner):
    @group()
    def cli():
        echo("group")

    @cli.command()
    def sub():
        pass

    res = runner.invoke(cli, ["--help"])
    assert res.exit_code == 0 and "group" not in res.stdout.replace("Usage", "")


def test_FP06_child_help_after_group_callback_runs(runner):
    @group()
    def cli():
        echo("group runs")

    @cli.command()
    def sub():
        pass

    res = runner.invoke(cli, ["sub", "--help"])
    assert res.exit_code == 0
    assert "group runs" in res.stdout
    assert "Usage: cli sub" in res.stdout


def test_FP06_group_options_before_subcommand(runner):
    @group()
    @option("--verbose", is_flag=True)
    def cli(verbose):
        echo(f"verbose={verbose}")

    @cli.command()
    @option("--x")
    def sub(x):
        echo(f"x={x}")

    assert runner.invoke(cli, ["--verbose", "sub", "--x", "1"]).stdout == "verbose=True\nx=1\n"


def test_FP06_group_option_after_subcommand_not_for_group(runner):
    @group()
    @option("--verbose", is_flag=True)
    def cli(verbose):
        echo(f"verbose={verbose}")

    @cli.command()
    def sub():
        pass

    res = runner.invoke(cli, ["sub", "--verbose"])
    assert res.exit_code == 2


def test_FP06_group_mixing_enabled_delivers_group_option_after_name(runner):
    @group(context_settings={"allow_interspersed_args": True})
    @option("--verbose", is_flag=True)
    def cli(verbose):
        echo(f"verbose={verbose}")

    @cli.command()
    def sub():
        echo("sub ran")

    res = runner.invoke(cli, ["sub", "--verbose"])
    assert res.stdout == "verbose=True\nsub ran\n"


def test_FP06_nested_groups_outside_in(runner):
    @group()
    def outer():
        echo("outer")

    @outer.group()
    def inner():
        echo("inner")

    @inner.command()
    def leaf():
        echo("leaf")

    assert runner.invoke(outer, ["inner", "leaf"]).stdout == "outer\ninner\nleaf\n"


def test_FP06_nested_group_with_nothing_after_shows_its_help(runner):
    @group()
    def outer():
        echo("outer runs")

    @outer.group()
    def inner():
        """Inner help text."""
        echo("inner must not run")

    @inner.command()
    def leaf():
        pass

    res = runner.invoke(outer, ["inner"])
    assert res.exit_code == 2
    assert "outer runs" in res.stdout
    assert "inner must not run" not in res.output
    assert "Inner help text." in res.stderr


def test_FP06_unknown_subcommand_does_not_run_callback(runner):
    ran = []

    @group()
    def cli():
        ran.append(1)

    @cli.command()
    def sub():
        pass

    res = runner.invoke(cli, ["nope"])
    assert res.exit_code == 2
    assert ran == []


def test_FP06_invoke_without_command_runs_callback(runner):
    @group(invoke_without_command=True)
    @pass_context
    def cli(ctx):
        echo(f"sub={ctx.invoked_subcommand}")

    res = runner.invoke(cli, [])
    assert res.exit_code == 0 and res.stdout == "sub=None\n"


def test_FP06_invoked_subcommand_name(runner):
    @group()
    @pass_context
    def cli(ctx):
        echo(f"sub={ctx.invoked_subcommand}")

    @cli.command()
    def a():
        pass

    assert runner.invoke(cli, ["a"]).stdout == "sub=a\n"


def test_FP06_add_command_explicit_name_and_later_registration(runner):
    @group()
    def cli():
        pass

    @command()
    def late():
        echo("late")

    cli.add_command(late, "other")
    assert runner.invoke(cli, ["other"]).stdout == "late\n"


def test_FP06_list_commands_and_get_command_override(runner):
    class Lazy(Group):
        def list_commands(self, ctx):
            return ["alpha", "beta"]

        def get_command(self, ctx, name):
            if name in ("alpha", "beta"):
                @command()
                def c():
                    echo(name)
                return c
            return None

    cli = Lazy(name="lazy", no_args_is_help=False)
    assert runner.invoke(cli, ["alpha"]).stdout == "alpha\n"
    assert runner.invoke(cli, ["gamma"]).exit_code == 2
    assert "alpha" in runner.invoke(cli, ["--help"]).stdout


def test_FP06_command_collection_union(runner):
    g1 = Group(name="g1", commands={"one": Command(name="one", callback=lambda: echo("1"))})
    g2 = Group(name="g2", commands={"two": Command(name="two", callback=lambda: echo("2"))})
    collection = CommandCollection(name="all", sources=[g1, g2])
    assert runner.invoke(collection, ["one"]).stdout == "1\n"
    assert runner.invoke(collection, ["two"]).stdout == "2\n"
    assert "one" in runner.invoke(collection, ["--help"]).stdout
    assert "two" in runner.invoke(collection, ["--help"]).stdout


def test_FP06_command_collection_via_decorator(runner):
    @group()
    def a():
        pass

    @a.command()
    def x():
        echo("x")

    @group(cls=CommandCollection, sources=[a])
    def merged():
        pass

    assert runner.invoke(merged, ["x"]).stdout == "x\n"


def test_FP10_chain_runs_children_in_order(runner):
    @group(chain=True)
    def cli():
        pass

    @cli.command()
    @argument("n", type=int)
    def add(n):
        echo(f"add {n}")
        return n

    @cli.command()
    @argument("n", type=int)
    def mul(n):
        echo(f"mul {n}")
        return n * 10

    @cli.result_callback()
    def done(results):
        echo(f"results={results}")

    res = runner.invoke(cli, ["add", "1", "mul", "5"])
    assert res.exit_code == 0
    assert res.stdout == "add 1\nmul 5\nresults=[1, 50]\n"


def test_FP10_chain_result_callback_empty_when_invoke_without_command(runner):
    @group(chain=True, invoke_without_command=True)
    def cli():
        pass

    @cli.result_callback()
    def done(results):
        echo(f"empty={results}")

    assert runner.invoke(cli, []).stdout == "empty=[]\n"


def test_FP10_chain_non_standalone_returns_list():
    @group(chain=True)
    def cli():
        pass

    @cli.command()
    def a():
        return "A"

    @cli.command()
    def b():
        return "B"

    assert cli.main(["a", "b"], standalone_mode=False) == ["A", "B"]


def test_FP10_chain_refuses_nested_group():
    from optlyn.exceptions import OptlynDeclarationError

    @group(chain=True)
    def cli():
        pass

    with pytest.raises((OptlynDeclarationError, TypeError, ValueError)):
        @cli.group()
        def nested():
            pass


def test_FP10_result_callback_gets_single_value_non_chain(runner):
    @group()
    def cli():
        pass

    @cli.command()
    def a():
        return 5

    @cli.result_callback()
    def done(value):
        echo(f"value={value}")

    assert runner.invoke(cli, ["a"]).stdout == "value=5\n"


def test_FP07_pass_obj_and_find_object(runner):
    class Config:
        pass

    @group()
    @pass_obj
    def cli(obj):
        obj.touched = True

    @cli.command()
    @make_pass_decorator(Config)
    def sub(cfg):
        echo(f"cfg={type(cfg).__name__}")

    res = runner.invoke(cli, ["sub"], obj=Config())
    assert res.stdout == "cfg=Config\n"


def test_FP07_make_pass_decorator_ensure_creates_object(runner):
    class Store:
        pass

    @command()
    @make_pass_decorator(Store, ensure=True)
    def cmd(store):
        echo(type(store).__name__)

    assert runner.invoke(cmd, []).stdout == "Store\n"


def test_FP07_pass_context_gives_current_context(runner):
    @command()
    @pass_context
    def cmd(ctx):
        echo(ctx.info_name)

    assert runner.invoke(cmd, [], prog_name="tool").stdout == "tool\n"
