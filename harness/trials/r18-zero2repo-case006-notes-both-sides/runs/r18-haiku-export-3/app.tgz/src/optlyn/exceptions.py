"""Exceptions raised and handled by Optlyn."""

import sys


class OptlynDeclarationError(TypeError, ValueError):
    """A command, group or parameter was declared with an invalid combination."""


class OptlynException(Exception):
    """Base for failures that standalone mode reports as errors (exit status 1)."""

    exit_code = 1

    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def format_message(self):
        return self.message

    def show(self, file=None):
        stream = file if file is not None else sys.stderr
        stream.write(f"Error: {self.format_message()}\n")
        stream.flush()


# spec: N-000804 (usage error, status 2)
class UsageError(OptlynException):
    """Incorrect command line usage (exit status 2)."""

    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.ctx = ctx

    def show(self, file=None):
        stream = file if file is not None else sys.stderr
        if self.ctx is not None:
            stream.write(self.ctx.get_usage() + "\n")
            if self.ctx.help_option_names and self.ctx.command.add_help_option:
                stream.write(
                    f"Try '{self.ctx.command_path} {self.ctx.help_option_names[0]}' for help.\n"
                )
            stream.write("\n")
        stream.write(f"Error: {self.format_message()}\n")
        stream.flush()


class NoArgsIsHelpError(UsageError):
    """No arguments were given and the command shows its help page instead (usage class, exit 2)."""

    def show(self, file=None):
        return None


# spec: N-000933, N-000934, N-000935
class BadParameter(UsageError):
    """A value was refused (conversion failure or parameter callback refusal)."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint()
        if hint:
            return f"Invalid value for {hint}: {self.message}"
        return f"Invalid value: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter was not supplied from any source."""

    def __init__(self, message=None, ctx=None, param=None, param_hint=None):
        super().__init__(message or "", ctx=ctx, param=param, param_hint=param_hint)

    def format_message(self):
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint()
        kind = self.param.param_kind if self.param is not None else "parameter"
        if hint:
            return f"Missing {kind} {hint}."
        return self.message or "Missing parameter."


class NoSuchOption(UsageError):
    def __init__(self, option_name, ctx=None):
        super().__init__(f"No such option: {option_name}", ctx)
        self.option_name = option_name


class BadOptionUsage(UsageError):
    """An option was used incorrectly (for example, a value is missing)."""


class BadArgumentUsage(UsageError):
    """An argument was used incorrectly."""


class NoSuchCommand(UsageError):
    def __init__(self, name, ctx=None):
        super().__init__(f"No such command '{name}'.", ctx)
        self.command_name = name


class FileError(OptlynException):
    """A file could not be opened when I/O started (general error, exit status 1)."""

    def __init__(self, filename, hint):
        super().__init__(f"Could not open file '{filename}': {hint}")
        self.ui_filename = filename
        self.hint = hint


# spec: N-000805 (abort, status 1)
class Abort(RuntimeError):
    """The user or the author aborted the invocation (exit status 1)."""


# spec: N-000806 (author clean stop with a status)
class Exit(RuntimeError):
    """An author clean stop, or an intentional help/version exit."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code
