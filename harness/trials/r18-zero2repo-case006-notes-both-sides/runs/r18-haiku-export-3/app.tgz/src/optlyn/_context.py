"""Thread-local stack of the invocation contexts that are current on each thread."""

import threading

_local = threading.local()


def _stack():
    stack = getattr(_local, "stack", None)
    if stack is None:
        stack = _local.stack = []
    return stack


def push_context(ctx):
    _stack().append(ctx)


def pop_context(ctx):
    stack = _stack()
    for index in range(len(stack) - 1, -1, -1):
        if stack[index] is ctx:
            del stack[index]
            return


def get_current_context(silent=False):
    """Return the context current on this thread (spec: FP-07, section 6)."""
    stack = _stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context on this thread.")
