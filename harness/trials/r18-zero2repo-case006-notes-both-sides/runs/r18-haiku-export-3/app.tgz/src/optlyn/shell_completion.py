"""Shell completion: registration scripts and suggestion output (spec: section 8, FP-12)."""

import os
import sys

from .core import Context, Group, Option
from .exceptions import NoSuchCommand
from .paramtypes import CompletionItem

# spec: N-001015 (shells: bash, zsh, fish, powershell)
SHELLS = ("bash", "zsh", "fish", "powershell")
_MODES = ("source", "complete")


def _function_name(prog_name):
    return "_" + "".join(ch if ch.isalnum() else "_" for ch in prog_name) + "_completion"


def _script(shell, prog_name, var):
    fn = _function_name(prog_name)
    if shell == "bash":
        return f"""{fn}() {{
    local words response line kind value
    words="$(IFS=' '; printf '%s' "${{COMP_WORDS[*]}}")"
    response=$(env COMP_WORDS="$words" COMP_CWORD=$COMP_CWORD {var}=bash_complete {prog_name} 2>/dev/null)
    local IFS=$'\\n'
    COMPREPLY=()
    for line in $response; do
        kind="${{line%%,*}}"
        value="${{line#*,}}"
        if [[ "$kind" == "file" ]]; then
            COMPREPLY+=($(compgen -f -- "$value"))
        elif [[ "$kind" == "dir" ]]; then
            COMPREPLY+=($(compgen -d -- "$value"))
        else
            COMPREPLY+=("$value")
        fi
    done
    return 0
}}

complete -o default -F {fn} {prog_name}
"""
    if shell == "zsh":
        return f"""#compdef {prog_name}

{fn}() {{
    local -a response
    local line kind value
    response=("${{(@f)$(env COMP_WORDS="${{words[*]}}" COMP_CWORD=$((CURRENT-1)) {var}=zsh_complete {prog_name} 2>/dev/null)}}")
    local -a plain
    for line in "${{response[@]}}"; do
        kind="${{line%%,*}}"
        value="${{${{line#*,}}%%$'\\t'*}}"
        if [[ "$kind" == "file" ]]; then
            _files
        elif [[ "$kind" == "dir" ]]; then
            _files -/
        else
            plain+=("$value")
        fi
    done
    compadd -- "${{plain[@]}}"
}}

compdef {fn} {prog_name}
"""
    if shell == "fish":
        return f"""complete --command {prog_name} --no-files --arguments "(env COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -ct) {var}=fish_complete {prog_name} 2>/dev/null)"
"""
    return f"""Register-ArgumentCompleter -Native -CommandName {prog_name} -ScriptBlock {{
    param($wordToComplete, $commandAst, $cursorPosition)
    $env:COMP_WORDS = $commandAst.ToString()
    $env:COMP_CWORD = $wordToComplete
    $env:{var} = 'powershell_complete'
    & {prog_name} 2>$null | ForEach-Object {{
        $kind, $value = $_ -split ',', 2
        [System.Management.Automation.CompletionResult]::new($value, $value, 'ParameterValue', $value)
    }}
    Remove-Item Env:\\{var} -ErrorAction SilentlyContinue
}}
"""


def _param_suggestions(ctx, param, incomplete):
    if param.shell_complete is not None:
        raw = param.shell_complete(ctx, param, incomplete)
    else:
        raw = param.type.shell_complete(ctx, param, incomplete)
    return [item if isinstance(item, CompletionItem) else CompletionItem(item) for item in raw or []]


def get_suggestions(cmd, prog_name, words, incomplete, shell):
    """Items (kind, value, help) to offer for ``incomplete`` after the complete ``words``."""
    current = cmd
    ctx = Context(cmd, info_name=prog_name)
    pending = None
    positional_seen = 0
    index = 0
    while index < len(words):
        tok = words[index]
        index += 1
        if pending is not None:
            pending = None
            continue
        if tok.startswith("-") and len(tok) > 1:
            for param in current.get_params(ctx):
                if isinstance(param, Option) and tok in param.opts:
                    if not param.is_flag and not param.count and not param.optional_value:
                        pending = param
                    break
            continue
        if isinstance(current, Group):
            sub = current.get_command(ctx, tok)
            if sub is not None:
                current = sub
                ctx = Context(sub, info_name=tok, parent=ctx)
                continue
        positional_seen += 1

    if pending is not None:
        return [(item.type, item.value, item.help) for item in _param_suggestions(ctx, pending, incomplete)]

    items = []
    if incomplete.startswith("-"):
        for param in current.get_params(ctx):
            if not isinstance(param, Option) or param.hidden:
                continue
            for name in param.opts + param.secondary_opts:
                if name.startswith(incomplete):
                    items.append(("plain", name, param.help))
        return items

    if isinstance(current, Group):
        if incomplete or positional_seen == 0:
            for name in current.list_commands(ctx):
                sub = current.get_command(ctx, name)
                if sub is None or sub.hidden or not name.startswith(incomplete):
                    continue
                items.append(("plain", name, sub.short_help_text() or None))
        if incomplete == "" and items:
            return items

    arguments = [a for a in current.arguments]
    if arguments and not isinstance(current, Group):
        arg = arguments[min(positional_seen, len(arguments) - 1)]
        for item in _param_suggestions(ctx, arg, incomplete):
            if item.value.startswith(incomplete) or item.type in ("file", "dir"):
                items.append((item.type, item.value, item.help))
    return items


def _render(items, shell):
    lines = []
    for kind, value, help_text in items:
        line = f"{kind},{value}"
        if shell in ("zsh", "fish") and help_text and kind == "plain":
            line += "\t" + help_text
        lines.append(line)
    return "\n".join(lines) + ("\n" if lines else "")


# spec: N-001013, N-001015, N-001021, N-001022, N-001023
def handle_instruction(cmd, prog_name, instruction, args, standalone_mode):
    """Handle a ``_PROG_COMPLETE`` instruction; the command callback never runs (FP-12)."""
    shell, _, mode = instruction.rpartition("_")
    if shell not in SHELLS or mode not in _MODES:
        if standalone_mode:
            sys.exit(1)
        return None
    var = "_" + prog_name.upper().replace("-", "_") + "_COMPLETE"
    if mode == "source":
        sys.stdout.write(_script(shell, prog_name, var))
        sys.stdout.flush()
        if standalone_mode:
            sys.exit(0)
        return None
    words_env = os.environ.get("COMP_WORDS", "")
    words = words_env.split(" ")[1:] if words_env else []
    if shell == "fish":
        incomplete = os.environ.get("COMP_CWORD", "")
        complete_words = words
    else:
        try:
            cword = int(os.environ.get("COMP_CWORD", "0"))
        except ValueError:
            cword = 0
        full = words_env.split(" ")
        incomplete = full[cword] if 0 <= cword < len(full) else ""
        complete_words = full[1:cword] if cword >= 1 else []
    try:
        items = get_suggestions(cmd, prog_name, complete_words, incomplete, shell)
    except NoSuchCommand:
        items = []
    sys.stdout.write(_render(items, shell))
    sys.stdout.flush()
    if standalone_mode:
        sys.exit(0)
    return None
