"""Public declaration decorators (spec: sections 3, 4, 6; FP-01, FP-02, FP-08)."""

import functools
import importlib.metadata
import inspect

from . import _context
from .core import Argument, Command, Group, Option
from .termui import confirm, echo


def _derive_name(func):
    """Command name from a function: lowercase, suffix stripped, underscores to dashes (FP-01)."""
    name = func.__name__.lower()
    for suffix in ("_command", "_cmd", "_group", "_grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def _param_memo(func, param):
    if isinstance(func, Command):
        func.params.append(param)
        return
    if not hasattr(func, "__optlyn_params__"):
        func.__optlyn_params__ = []
    func.__optlyn_params__.append(param)


def _take_params(func):
    """Declarations attached to a function, top-down; they move to the new command (FP-03)."""
    if isinstance(func, Command):
        return list(func.params)
    params = list(reversed(getattr(func, "__optlyn_params__", [])))
    func.__optlyn_params__ = []
    return params


def _docstring(func):
    doc = func.__doc__
    if not doc:
        return None
    if "\f" in doc:
        doc = doc.split("\f", 1)[0]
    return inspect.cleandoc(doc)


# spec: N-000852 (explicit name), N-000853 (help and attribute keywords)
def _build(factory, name, attrs, func):
    params = _take_params(func)
    attrs = dict(attrs)
    if attrs.get("help") is not None:
        attrs["help"] = _keep_after_formfeed(attrs["help"])
    elif "help" not in attrs or attrs["help"] is None:
        attrs["help"] = _docstring(func)
    cmd_name = name if name is not None else _derive_name(func)
    return factory(name=cmd_name, callback=func, params=params, **attrs)


def _keep_after_formfeed(text):
    """A form feed in an explicit ``help`` string is dropped; the text after it is kept (section 3)."""
    return text.replace("\f", "")


def _as_decorator(name_or_func, cls, attrs, default_cls):
    """Accept ``@command``, ``@command()`` and ``@command(name)``."""
    chosen = cls or default_cls

    def decorator(func):
        return _build(chosen, name_or_func if isinstance(name_or_func, str) else None, attrs, func)

    if callable(name_or_func) and not isinstance(name_or_func, str):
        return decorator(name_or_func)
    return decorator


def command(name=None, cls=None, **attrs):
    """Declare a leaf command from a function (spec: section 3, FP-01)."""
    if callable(name) and not isinstance(name, str):
        return _as_decorator(None, cls, attrs, Command)(name)
    return _as_decorator(name, cls, attrs, Command)


def group(name=None, cls=None, **attrs):
    """Declare a group from a function (spec: section 3, FP-06)."""
    if callable(name) and not isinstance(name, str):
        return _as_decorator(None, cls, attrs, Group)(name)
    chosen = cls or Group

    def decorator(func):
        return _build(chosen, name, attrs, func)

    return decorator


# spec: N-000881, N-000882, N-000883
def option(*param_decls, cls=None, **attrs):
    """Attach an option to a command or group (spec: section 4, FP-03)."""
    chosen = cls or Option

    def decorator(func):
        param = chosen(param_decls, **attrs)
        _param_memo(func, param)
        return func

    return decorator


# spec: N-000910, N-000911, N-000912
def argument(*param_decls, cls=None, **attrs):
    """Attach a positional argument (spec: section 4, FP-04)."""
    chosen = cls or Argument

    def decorator(func):
        param = chosen(param_decls, **attrs)
        _param_memo(func, param)
        return func

    return decorator


# ---------------------------------------------------------------------------
# Callback decorators (section 6)
# ---------------------------------------------------------------------------


def pass_context(func):
    """Pass the current Context as the first argument."""

    @functools.wraps(func)
    def new_func(*args, **kwargs):
        return func(_context.get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(func):
    """Pass the current context's ``obj`` as the first argument."""

    @functools.wraps(func)
    def new_func(*args, **kwargs):
        return func(_context.get_current_context().obj, *args, **kwargs)

    return new_func


# spec: N-000977 (ensure creates an empty object)
def make_pass_decorator(object_type, ensure=False):
    """Pass the nearest object of ``object_type`` up the context chain (FP-07)."""

    def decorator(func):
        @functools.wraps(func)
        def new_func(*args, **kwargs):
            ctx = _context.get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(f"Managed to invoke callback without a context object of type "
                                   f"{object_type.__name__!r} existing.")
            return func(obj, *args, **kwargs)

        return new_func

    return decorator


# ---------------------------------------------------------------------------
# Ready-made options (section 4, FP-02, FP-08)
# ---------------------------------------------------------------------------


def _help_option_param(param_decls, kwargs):
    decls = list(param_decls) or ["--help"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    from .core import _help_callback

    kwargs.setdefault("callback", _help_callback)
    return Option(decls, **kwargs)


# spec: N-000924, N-000929
def help_option(*param_decls, **kwargs):
    """An extra eager help flag that prints the help page and exits (FP-02)."""

    def decorator(func):
        _param_memo(func, _help_option_param(param_decls, kwargs))
        return func

    return decorator


def _detect_version(package_name):
    if not package_name:
        return "unknown"
    try:
        return importlib.metadata.version(package_name)
    except importlib.metadata.PackageNotFoundError:
        pass
    try:
        providers = importlib.metadata.packages_distributions().get(package_name) or []
    except Exception:  # pragma: no cover - defensive
        providers = []
    for dist in providers:
        try:
            return importlib.metadata.version(dist)
        except importlib.metadata.PackageNotFoundError:
            continue
    return "unknown"


# spec: N-000925, N-000930, N-000931
def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None,
                   **kwargs):
    """Eager ``--version`` flag printing a version identity (FP-02)."""
    if version is None and package_name is None:
        frame = inspect.currentframe().f_back
        module = frame.f_globals.get("__name__", "") if frame is not None else ""
        package_name = module.partition(".")[0] or None
    decls = list(param_decls) or ["--version"]

    def callback(ctx, param, value):
        if not value:
            return
        prog = prog_name or ctx.find_root().info_name or ""
        ver = version if version is not None else _detect_version(package_name)
        text = message if message is not None else "%(prog)s, version %(version)s"
        echo(text % {"prog": prog, "package": package_name, "version": ver}, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback

    def decorator(func):
        _param_memo(func, Option(decls, **kwargs))
        return func

    return decorator


# spec: N-000926, N-000932
def custom_version_option(callback_fn, *param_decls, **kwargs):
    """Eager version flag whose entire identity is the string ``callback_fn(ctx)`` returns."""
    decls = list(param_decls) or ["--version"]

    def callback(ctx, param, value):
        if not value:
            return
        echo(callback_fn(ctx), color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback

    def decorator(func):
        _param_memo(func, Option(decls, **kwargs))
        return func

    return decorator


# spec: N-000927
def password_option(*param_decls, **kwargs):
    """A prompting, hidden, confirmed option (FP-08)."""
    decls = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("help", "The password to use.")

    def decorator(func):
        _param_memo(func, Option(decls, **kwargs))
        return func

    return decorator


# spec: N-000928
def confirmation_option(*param_decls, **kwargs):
    """A yes-flag that asks when omitted and aborts when declined (FP-08)."""
    decls = list(param_decls) or ["--yes"]
    question = kwargs.pop("prompt", "Do you want to continue?")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Confirm the action without prompting.")

    def callback(ctx, param, value):
        if not value:
            confirm(question, default=False, abort=True)
            return True
        return value

    kwargs["callback"] = callback

    def decorator(func):
        _param_memo(func, Option(decls, **kwargs))
        return func

    return decorator
