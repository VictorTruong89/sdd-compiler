"""In-process runner: ``optlyn.testing.CliRunner`` (spec: section 9, FP-14)."""

import contextlib
import io
import os
import shutil
import sys
import tempfile


class _Sink:
    """Captures bytes for one stream and, optionally, a shared interleaved log."""

    def __init__(self, shared):
        self.own = io.BytesIO()
        self.shared = shared

    def write(self, data):
        self.own.write(data)
        self.shared.write(data)


class _BinaryView:
    def __init__(self, stream):
        self._stream = stream

    def write(self, data):
        return self._stream._write_bytes(data)

    def flush(self):
        pass

    def getvalue(self):
        return self._stream._sink.own.getvalue()


class _CaptureStream(io.TextIOBase):
    def __init__(self, sink, charset, echo_target=None, fileno=None):
        self._sink = sink
        self._charset = charset
        self._fileno = fileno
        self.echo_target = echo_target

    @property
    def encoding(self):
        return self._charset

    @property
    def errors(self):
        return "backslashreplace"

    @property
    def buffer(self):
        return _BinaryView(self)

    def _write_bytes(self, data):
        self._sink.write(bytes(data))
        return len(data)

    def write(self, text):
        if isinstance(text, bytes):
            self._sink.write(text)
            return len(text)
        self._sink.write(text.encode(self._charset, "backslashreplace"))
        return len(text)

    def flush(self):
        pass

    def isatty(self):
        return False

    def writable(self):
        return True

    def readable(self):
        return False

    def fileno(self):
        if self._fileno is None:
            raise io.UnsupportedOperation("fileno")
        return self._fileno


class _CaptureInput(io.TextIOBase):
    """Standard input for an invocation. Reads may be echoed into the captured output."""

    echoes_reads = False

    def __init__(self, data, charset, echo_stdin, stdout_stream):
        self._buffer = io.StringIO(data.decode(charset, "replace") if isinstance(data, bytes) else data)
        self._echo = echo_stdin
        self._stdout = stdout_stream
        self._charset = charset

    @property
    def encoding(self):
        return self._charset

    def _echo_text(self, text):
        if self._echo and text:
            self._stdout.write(text)

    def readline(self, size=-1):
        line = self._buffer.readline()
        self._echo_text(line)
        return line

    def read(self, size=-1):
        data = self._buffer.read(size)
        self._echo_text(data)
        return data

    def readlines(self, hint=-1):
        lines = self._buffer.readlines()
        for line in lines:
            self._echo_text(line)
        return lines

    def prompt_readline(self, prompt_text, hide_input, err):
        """Prompt reads: the prompt and visible typed input are written to the captured output."""
        target = self._stdout
        line = self._buffer.readline()
        if line == "":
            target.write(prompt_text)
            target.write("\n")
            return None
        target.write(prompt_text)
        if hide_input:
            target.write("\n")
        else:
            target.write(line.rstrip("\r\n") + "\n")
        return line.rstrip("\r\n")

    def isatty(self):
        return False

    def readable(self):
        return True


class Result:
    """Outcome of an invocation (spec: section 9)."""

    def __init__(self, exit_code, output_bytes, stdout_bytes, stderr_bytes, exception, return_value=None):
        self.exit_code = exit_code
        self.output_bytes = output_bytes
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.exception = exception
        self.return_value = return_value
        self._charset = "utf-8"

    @property
    def output(self):
        return self.output_bytes.decode(self._charset, "replace")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self._charset, "replace")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self._charset, "replace")

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


# spec: N-001038, N-001039, N-001040, N-001041, N-001042, N-001043
class CliRunner:
    """Runs a command in-process with captured streams (spec: section 9, FP-14)."""

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        """Context manager that swaps the process streams for captured ones."""
        shared = io.BytesIO()
        out_sink = _Sink(shared)
        err_sink = _Sink(shared)
        stdout = _CaptureStream(out_sink, self.charset)
        stderr = _CaptureStream(err_sink, self.charset)
        stdin_data = input.encode(self.charset) if isinstance(input, str) else (input or b"")
        stdin = _CaptureInput(stdin_data, self.charset, self.echo_stdin, stdout)
        env_changes = dict(self.env)
        env_changes.update(env or {})
        saved_env = {}
        for key, value in env_changes.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)
        old = (sys.stdin, sys.stdout, sys.stderr)
        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
        try:
            yield out_sink, err_sink, shared
        finally:
            sys.stdin, sys.stdout, sys.stderr = old
            for key, value in saved_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False,
               **extra):
        """Invoke ``cli`` with the given argument tokens and return a Result."""
        catch = self.catch_exceptions if catch_exceptions is None else catch_exceptions
        standalone = extra.pop("standalone_mode", True)
        prog_name = extra.pop("prog_name", None) or cli.name or "root"
        extra.setdefault("color", color)
        if args is None:
            args = []
        elif isinstance(args, str):
            import shlex

            args = shlex.split(args)
        exit_code = 0
        exception = None
        return_value = None
        if self.capture == "fd":
            return self._invoke_fd(cli, list(args), input, env, catch, standalone, prog_name, extra)
        with self.isolation(input, env, color) as (out_sink, err_sink, shared):
            try:
                return_value = cli.main(args=list(args), prog_name=prog_name,
                                        standalone_mode=standalone, **extra)
            except SystemExit as exc:
                code = exc.code
                if code is None:
                    exit_code = 0
                elif isinstance(code, int):
                    exit_code = code
                else:
                    sys.stderr.write(str(code) + "\n")
                    exit_code = 1
            except Exception as exc:
                if not catch:
                    raise
                exit_code = 1
                exception = exc
        return Result(exit_code, shared.getvalue(), out_sink.own.getvalue(),
                      err_sink.own.getvalue(), exception, return_value)

    def _invoke_fd(self, cli, args, input, env, catch, standalone, prog_name, extra):
        import tempfile as _tf

        exit_code = 0
        exception = None
        return_value = None
        out_file = _tf.TemporaryFile()
        err_file = _tf.TemporaryFile()
        saved_out, saved_err = os.dup(1), os.dup(2)
        sys_stdin_data = input.encode(self.charset) if isinstance(input, str) else (input or b"")
        stdin = _CaptureInput(sys_stdin_data, self.charset, self.echo_stdin, None)
        old = (sys.stdin, sys.stdout, sys.stderr)
        env_changes = dict(self.env)
        env_changes.update(env or {})
        saved_env = {k: os.environ.get(k) for k in env_changes}
        for key, value in env_changes.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)
        try:
            os.dup2(out_file.fileno(), 1)
            os.dup2(err_file.fileno(), 2)
            stdout_io = io.TextIOWrapper(os.fdopen(os.dup(1), "wb"), encoding=self.charset,
                                         line_buffering=True)
            stderr_io = io.TextIOWrapper(os.fdopen(os.dup(2), "wb"), encoding=self.charset,
                                         line_buffering=True)
            stdin._stdout = stdout_io
            sys.stdin, sys.stdout, sys.stderr = stdin, stdout_io, stderr_io
            try:
                return_value = cli.main(args=args, prog_name=prog_name, standalone_mode=standalone,
                                        **extra)
            except SystemExit as exc:
                code = exc.code
                exit_code = 0 if code is None else (code if isinstance(code, int) else 1)
            except Exception as exc:
                if not catch:
                    raise
                exit_code = 1
                exception = exc
            finally:
                stdout_io.flush()
                stderr_io.flush()
                stdout_io.close()
                stderr_io.close()
        finally:
            sys.stdin, sys.stdout, sys.stderr = old
            os.dup2(saved_out, 1)
            os.dup2(saved_err, 2)
            os.close(saved_out)
            os.close(saved_err)
            for key, value in saved_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
        out_file.seek(0)
        err_file.seek(0)
        stdout_bytes = out_file.read()
        stderr_bytes = err_file.read()
        out_file.close()
        err_file.close()
        return Result(exit_code, stdout_bytes + stderr_bytes, stdout_bytes, stderr_bytes,
                      exception, return_value)

    @contextlib.contextmanager
    # spec: N-001044
    def isolated_filesystem(self, temp_dir=None):
        """Run inside a new empty directory (FP-14). Without a parent it is removed on exit."""
        cwd = os.getcwd()
        path = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                shutil.rmtree(path, ignore_errors=True)
