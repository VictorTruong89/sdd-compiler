"""Commands, groups, parameters, invocation context, parsing and dispatch.

Spec anchors: section 3 (commands/groups), section 4 (parameters), section 6
(invocation context), FP-01 .. FP-10, FP-13.
"""

import enum
import os
import sys

from . import _context
from .exceptions import (
    Abort,
    BadArgumentUsage,
    BadOptionUsage,
    BadParameter,
    Exit,
    MissingParameter,
    NoArgsIsHelpError,
    NoSuchCommand,
    NoSuchOption,
    OptlynDeclarationError,
    OptlynException,
    UsageError,
)
from .formatting import DEFAULT_MAX_CONTENT_WIDTH, format_dl, make_default_short_help, rewrap_help
from .paramtypes import Tuple, make_param_type
from .termui import echo
from .termui import prompt as _prompt
from .utils import terminal_size_columns


# spec: N-000245 (CF-000072: env ranks above default map); N-000243
class ParameterSource(enum.Enum):
    """Where a parameter's value came from (spec: section 6, FP-07)."""

    PROMPT = "prompt"
    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"


_SOURCE_RANK = {
    ParameterSource.PROMPT: 0,
    ParameterSource.COMMANDLINE: 1,
    ParameterSource.ENVIRONMENT: 2,
    ParameterSource.DEFAULT_MAP: 3,
    ParameterSource.DEFAULT: 4,
}


class _Marker:
    def __init__(self, label):
        self._label = label

    def __repr__(self):
        return self._label


_BARE = _Marker("<bare>")  # flag/option present with no value token
_UNSET = _Marker("<unset>")  # an environment value that does not supply anything
CHAIN_SUBCOMMAND = _Marker("<chain>")  # invoked_subcommand on a chaining group with children

_ENV_TRUE = {"true", "1", "yes", "on", "t", "y"}
_ENV_FALSE = {"false", "0", "no", "off", "f", "n", ""}

_PREFIX_CHARS = set("-/+")


# spec: N-001013 (completion variable name)
def complete_var_name(prog_name):
    """Completion environment variable name (spec: section 8, FP-12)."""
    return "_" + prog_name.upper().replace("-", "_") + "_COMPLETE"


def _is_option_name(text):
    return bool(text) and not (text[0].isalnum() or text[0] == "_")


def _parse_decls(decls):
    """Split declarations into (primary flags, secondary flags, destination name)."""
    opts, secondary, name = [], [], None
    for decl in decls:
        if not isinstance(decl, str):
            raise OptlynDeclarationError(f"parameter declarations must be strings, got {decl!r}")
        if _is_option_name(decl):
            if "/" in decl[1:]:
                on, _, off = decl.partition("/")
                # on-flag/off-flag pair: "--shout/--no-shout"
                if on and off:
                    opts.append(on)
                    secondary.append(off)
                    continue
            opts.append(decl)
        else:
            if name is not None:
                raise OptlynDeclarationError("only one destination name may be declared")
            name = decl.replace("-", "_")
    return opts, secondary, name


def _infer_name(opts, secondary, name):
    if name is not None:
        return name
    everything = opts + secondary
    if not everything:
        raise OptlynDeclarationError("a parameter needs a flag name or a destination name")
    for decl in everything:
        if decl.isidentifier():
            return decl
    longs = [d for d in everything if len(d) > 1 and d[0] in _PREFIX_CHARS and d[1] in _PREFIX_CHARS]
    pick = longs[0] if longs else everything[0]
    stripped = pick.lstrip("".join(_PREFIX_CHARS))
    return stripped.replace("-", "_")


# spec: N-000022 (CF-000155: callbacks run for missing parameters, see N-000260)
class Parameter:
    """Common behaviour of options and arguments."""

    param_kind = "parameter"
    is_flag = False
    count = False
    is_eager = False
    hidden = False
    prompt = None

    def get_error_hint(self):
        return f"'{self.name}'"

    def display_name(self):
        return self.name

    def _is_repeating(self):
        return self.multiple or self.nargs == -1

    def _occ_size(self):
        """Tokens per occurrence (spec: FP-03 multi-value)."""
        if isinstance(self.type, Tuple):
            return len(self.type.types)
        if self.nargs == -1:
            return 1
        return self.nargs

    def _occ_min(self):
        return 0 if self.nargs == -1 else self._occ_size()

    def _with_param(self, exc, ctx):
        if isinstance(exc, BadParameter):
            if exc.param is None:
                exc.param = self
            if exc.ctx is None:
                exc.ctx = ctx
        raise exc

    def _convert_one(self, ptype, ctx, token):
        try:
            return ptype.convert(token, self, ctx)
        except BadParameter as exc:
            self._with_param(exc, ctx)

    def _convert_tokens(self, ctx, tokens):
        """Convert the tokens of one occurrence (unary -> scalar, otherwise a tuple)."""
        size = self._occ_size()
        if isinstance(self.type, Tuple):
            if len(tokens) != size:
                raise BadParameter(f"takes {size} values but {len(tokens)} were given.", ctx, self)
            return tuple(self._convert_one(t, ctx, v) for t, v in zip(self.type.types, tokens))
        if self.nargs == -1:
            return tuple(self._convert_one(self.type, ctx, v) for v in tokens)
        if size == 1 and self.nargs == 1:
            if len(tokens) != 1:
                raise BadParameter("expects one value.", ctx, self)
            return self._convert_one(self.type, ctx, tokens[0])
        if len(tokens) != size:
            raise BadParameter(f"takes {size} values but {len(tokens)} were given.", ctx, self)
        return tuple(self._convert_one(self.type, ctx, v) for v in tokens)

    def _tokens_to_value(self, ctx, tokens):
        if self._is_repeating():
            size = self._occ_size()
            if size == 1 and not isinstance(self.type, Tuple):
                return tuple(self._convert_one(self.type, ctx, t) for t in tokens)
            if len(tokens) % size:
                raise BadParameter(f"takes {size} values per occurrence.", ctx, self)
            groups = [tokens[i:i + size] for i in range(0, len(tokens), size)]
            return tuple(self._convert_tokens(ctx, g) for g in groups)
        return self._convert_tokens(ctx, tokens)

    def _items_to_value(self, ctx, items):
        if self._is_repeating():
            size = self._occ_size()
            out = []
            for item in items:
                if size == 1 and not isinstance(self.type, Tuple):
                    out.append(self._convert_one(self.type, ctx, item))
                else:
                    out.append(self._convert_tokens(ctx, list(item)))
            return tuple(out)
        return self._convert_tokens(ctx, list(items))

    def _fail_iterable(self, ctx):
        raise BadParameter("needs an iterable (sequence) default.", ctx, self)

    def _python_value(self, ctx, raw):
        """Convert a value from a default or the default map (not from the command line)."""
        if self.is_flag:
            return self._convert_one(self.type, ctx, raw)
        if self._is_repeating():
            if isinstance(raw, str):
                if self.multiple and self._occ_size() == 1 and not isinstance(self.type, Tuple):
                    self._fail_iterable(ctx)
                return self._tokens_to_value(ctx, self.type.split_env(raw))
            try:
                items = list(raw)
            except TypeError:
                self._fail_iterable(ctx)
            return self._items_to_value(ctx, items)
        if self.nargs != 1 or isinstance(self.type, Tuple):
            if isinstance(raw, str):
                return self._tokens_to_value(ctx, self.type.split_env(raw))
            return self._convert_tokens(ctx, list(raw))
        return self._convert_one(self.type, ctx, raw)

    def _env_value(self, ctx, raw):
        if self.is_flag:
            return self._flag_env_value(ctx, raw)
        if self._is_repeating() or self.nargs != 1 or isinstance(self.type, Tuple):
            return self._tokens_to_value(ctx, self.type.split_env(raw))
        return self._convert_one(self.type, ctx, raw)

    def _flag_env_value(self, ctx, raw):
        return _UNSET

    def _lookup_default_map(self, ctx):
        dmap = ctx.default_map
        if isinstance(dmap, dict) and self.name in dmap:
            return True, dmap[self.name]
        return False, None

    def _declared_raw_default(self):
        raw = self.default
        if callable(raw):
            raw = raw()
        return raw

    def _env_names(self, ctx):
        return list(self.envvar)

    def _env_lookup(self, ctx):
        for name in self._env_names(ctx):
            raw = os.environ.get(name)
            if raw is None or raw == "":
                continue
            value = self._env_value(ctx, raw)
            if value is _UNSET:
                continue
            return True, value
        return False, None

    def run_callback(self, ctx, value):
        if self.callback is not None:
            value = self.callback(ctx, self, value)
        return value


# spec: N-000881, N-000883, N-000884, N-000909
class Option(Parameter):
    """A named parameter (spec: section 4 option, FP-03)."""

    param_kind = "option"

    def __init__(self, param_decls=None, *, type=None, default=None, required=False, is_flag=None,
                 flag_value=None, count=False, multiple=False, nargs=None, envvar=None,
                 allow_from_autoenv=True, prompt=None, prompt_required=True, hide_input=False,
                 confirmation_prompt=False, callback=None, is_eager=False, expose_value=True,
                 hidden=False, deprecated=False, help=None, metavar=None, show_default=None,
                 show_envvar=False, shell_complete=None):
        opts, secondary, name = _parse_decls(list(param_decls or []))
        self.name = _infer_name(opts, secondary, name)
        self.opts = opts
        self.secondary_opts = secondary
        self.count = bool(count)
        if self.count:
            is_flag = True if is_flag is None else is_flag
            if multiple:
                raise OptlynDeclarationError("count and multiple cannot be combined")
        if is_flag is None:
            if flag_value is not None:
                is_flag = False
            elif secondary or isinstance(default, bool):
                is_flag = True
            else:
                is_flag = False
        self.is_flag = bool(is_flag)
        if self.is_flag:
            flag_value = True if flag_value is None else flag_value
            if multiple:
                raise OptlynDeclarationError("a flag cannot be repeatable")
        self.flag_value = flag_value
        if prompt is False:
            prompt = None
        if prompt is not None and self.is_flag:
            raise OptlynDeclarationError("a flag cannot prompt")
        if deprecated and required:
            raise OptlynDeclarationError("a deprecated option cannot be required")
        if deprecated and prompt is not None:
            raise OptlynDeclarationError("a deprecated option cannot use a prompt")
        if nargs is None:
            nargs = 1
        if isinstance(type, Tuple):
            if nargs not in (1, len(type.types)):
                raise OptlynDeclarationError("nargs does not match the tuple type length")
            nargs = len(type.types)
        if nargs == -1 or nargs < 1:
            raise OptlynDeclarationError("an option takes a positive number of values")
        if self.is_flag and nargs != 1:
            raise OptlynDeclarationError("a flag takes no values")
        self.nargs = nargs
        self.multiple = bool(multiple)
        self.required = bool(required)
        self.default = default
        self.default_is_set = default is not None
        self.type = make_param_type(type, default, self.is_flag, flag_value)
        self.callback = callback
        self.expose_value = expose_value
        self.is_eager = bool(is_eager)
        self.hidden = bool(hidden)
        self.deprecated = deprecated
        self.help = help
        self.metavar = metavar
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.shell_complete = shell_complete
        self.allow_from_autoenv = allow_from_autoenv
        if envvar is None:
            self.envvar = []
        elif isinstance(envvar, str):
            self.envvar = [envvar]
        else:
            self.envvar = list(envvar)
        self.prompt = (
            (prompt if isinstance(prompt, str) else True) if prompt is not None else None
        )
        self.prompt_required = bool(prompt_required)
        self.hide_input = bool(hide_input)
        self.confirmation_prompt = bool(confirmation_prompt)
        if self.is_flag:
            self.optional_value = False
        else:
            self.optional_value = flag_value is not None and not self.count
        self.kind = (
            "count" if self.count else "flag" if self.is_flag else
            "optval" if self.optional_value else "value"
        )

    def get_error_hint(self):
        return " / ".join(f"'{o}'" for o in self.opts + self.secondary_opts) or f"'{self.name}'"

    def display_name(self):
        return (self.opts or [self.name])[0]

    def get_metavar(self, ctx=None):
        if self.is_flag or self.count:
            return None
        if self.metavar:
            return self.metavar
        return self.type.get_metavar(self) or self.type.name.upper()

    def _from_occurrences(self, ctx, occ):
        if self.count:
            return len(occ)
        if self.is_flag:
            return occ[-1]
        if self.multiple:
            return tuple(self._entry_value(ctx, entry) for entry in occ)
        return self._entry_value(ctx, occ[-1])

    def _entry_value(self, ctx, entry):
        if entry is _BARE:
            return self.flag_value
        return self._convert_tokens(ctx, list(entry))

    def _prompt_value(self, ctx):
        text = self.prompt if isinstance(self.prompt, str) else self.name.replace("_", " ").capitalize()
        found, raw_default = self._lookup_default_map(ctx)
        if not found:
            raw_default = self._declared_raw_default()
        value = _prompt(
            text,
            default=raw_default,
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            type=self.type,
        )
        if self.multiple:
            return (value,)
        return value

    def _declared_default(self, ctx):
        raw = self._declared_raw_default()
        if self.count:
            return 0 if raw is None else int(raw)
        if raw is None:
            if self.is_flag:
                return False if isinstance(self.flag_value, bool) else None
            if self.multiple:
                return ()
            return None
        return self._python_value(ctx, raw)

    def _flag_env_value(self, ctx, raw):
        """Boolean reading of an environment value for a flag (spec: FP-03)."""
        text = raw.strip().lower()
        if not isinstance(self.flag_value, bool):
            # a non-boolean flag value: its own text activates; unrecognized values are unset
            if text == str(self.flag_value).lower():
                return self.flag_value
            if text in _ENV_TRUE:
                return True
            if text in _ENV_FALSE:
                return False
            return _UNSET
        if text in _ENV_TRUE:
            return True
        if text in _ENV_FALSE:
            return False
        raise BadParameter(f"{raw.strip()!r} is not a valid boolean.", ctx, self)

    def _resolve_env(self, ctx):
        names = list(self.envvar)
        if self.allow_from_autoenv and ctx.auto_envvar_prefix:
            auto = "_".join(
                [ctx.auto_envvar_prefix_text(), self.name]
            ).upper().replace("-", "_")
            names.append(auto)
        return names

    def _env_names(self, ctx):
        return self._resolve_env(ctx)

    def resolve(self, ctx):
        """Return (value, source) for this option (spec: FP-03 value sources, FP-08)."""
        occ = ctx._raw.get(self, [])
        if self.prompt is not None:
            bare = any(entry is _BARE for entry in occ)
            if bare or (not occ and self.prompt_required):
                if not bare:
                    found, env_value = self._env_lookup(ctx)
                    if found:
                        return env_value, ParameterSource.ENVIRONMENT
                return self._prompt_value(ctx), ParameterSource.PROMPT
        if occ:
            return self._from_occurrences(ctx, occ), ParameterSource.COMMANDLINE
        found, value = self._env_lookup(ctx)
        if found:
            return value, ParameterSource.ENVIRONMENT
        found, value = self._lookup_default_map(ctx)
        if found:
            return self._python_value(ctx, value), ParameterSource.DEFAULT_MAP
        return self._declared_default(ctx), ParameterSource.DEFAULT

    def usage_names(self):
        return self.opts

    def help_record(self, ctx):
        term = ", ".join(self.opts) if not self.secondary_opts else (
            "/".join(self.opts) + "/" + "/".join(self.secondary_opts)
        )
        metavar = self.get_metavar(ctx)
        if metavar:
            term = f"{term} {metavar}"
        extras = []
        if self.help:
            extras.append(self.help)
        default_text = self._default_text(ctx)
        if default_text is not None:
            extras.append(f"[default: {default_text}]")
        if self.show_envvar or getattr(ctx, "show_envvar", False):
            names = self._resolve_env(ctx)
            if names:
                extras.append(f"[env var: {', '.join(names)}]")
        return term, " ".join(extras)

    def _default_text(self, ctx):
        show = self.show_default if self.show_default is not None else ctx.show_default
        if isinstance(show, str):
            return show
        if not show:
            return None
        if self.is_flag and self.default in (None, False):
            return None
        raw = self.default
        if callable(raw):
            return "(dynamic)"
        if raw is None:
            return None
        if isinstance(raw, (list, tuple)):
            return ", ".join(str(item) for item in raw)
        return str(raw)


# spec: N-000910, N-000911, N-000912
class Argument(Parameter):
    """A positional parameter (spec: section 4 argument, FP-04)."""

    param_kind = "argument"

    def __init__(self, param_decls=None, *, type=None, default=None, required=None, nargs=1,
                 envvar=None, deprecated=False, help=None, metavar=None, callback=None,
                 expose_value=True, hidden=False, is_eager=False, shell_complete=None):
        decls = list(param_decls or [])
        if len(decls) != 1 or _is_option_name(decls[0]):
            raise OptlynDeclarationError("an argument takes exactly one destination name")
        self.name = decls[0].replace("-", "_")
        self.opts = []
        self.secondary_opts = []
        if isinstance(type, Tuple):
            if nargs not in (1, len(type.types)):
                raise OptlynDeclarationError("nargs does not match the tuple type length")
            nargs = len(type.types)
        if nargs != -1 and nargs < 1:
            raise OptlynDeclarationError("nargs must be a positive number or -1")
        self.nargs = nargs
        self.multiple = False
        self.is_flag = False
        self.count = False
        self.default = default
        self.default_is_set = default is not None
        if required is None:
            required = default is None and nargs != -1
        if deprecated and required:
            raise OptlynDeclarationError("a deprecated argument cannot be required")
        self.required = bool(required)
        self.type = make_param_type(type, default)
        self.deprecated = deprecated
        self.help = help
        self.metavar = metavar
        self.callback = callback
        self.expose_value = expose_value
        self.hidden = bool(hidden)
        self.is_eager = bool(is_eager)
        self.shell_complete = shell_complete
        self.allow_from_autoenv = False
        self.envvar = [envvar] if isinstance(envvar, str) else list(envvar or [])
        self.show_default = None
        self.show_envvar = False
        self.prompt = None

    def get_error_hint(self):
        return f"'{self.name.upper()}'"

    def display_name(self):
        return self.name

    def get_metavar(self, ctx=None):
        return self.metavar or self.name.upper()

    def usage_placeholder(self):
        meta = self.get_metavar()
        if self.nargs == -1:
            return f"{meta}..." if self.required else f"[{meta}]..."
        if self.required:
            return " ".join([meta] * self.nargs)
        return f"[{' '.join([meta] * self.nargs)}]"

    def resolve(self, ctx):
        occ = ctx._raw.get(self, [])
        if occ:
            return self._tokens_to_value(ctx, occ[-1]), ParameterSource.COMMANDLINE
        if self.envvar:
            for name in self.envvar:
                raw = os.environ.get(name)
                if raw is None or raw == "":
                    continue
                return self._env_value(ctx, raw), ParameterSource.ENVIRONMENT
        found, value = self._lookup_default_map(ctx)
        if found:
            return self._python_value(ctx, value), ParameterSource.DEFAULT_MAP
        raw = self._declared_raw_default()
        if raw is None:
            return (() if self.nargs == -1 else None), ParameterSource.DEFAULT
        return self._python_value(ctx, raw), ParameterSource.DEFAULT

    def help_record(self, ctx):
        return self.get_metavar(ctx), self.help or ""


# spec: N-000950, N-000951, N-000953, N-000955, N-000978
class Context:
    """Per-invocation state (spec: section 6, FP-07)."""

    def __init__(self, command, parent=None, info_name=None, obj=None, default_map=None,
                 terminal_width=None, max_content_width=None, help_option_names=None,
                 token_normalize_func=None, color=None, show_default=None, allow_extra_args=None,
                 allow_interspersed_args=None, ignore_unknown_options=None,
                 auto_envvar_prefix=None, **extra):
        self.command = command
        self.parent = parent
        self.info_name = info_name
        self.extra = extra
        if parent is not None:
            obj = parent.obj if obj is None else obj
            terminal_width = parent.terminal_width if terminal_width is None else terminal_width
            max_content_width = (
                parent.max_content_width if max_content_width is None else max_content_width
            )
            help_option_names = (
                parent.help_option_names if help_option_names is None else help_option_names
            )
            token_normalize_func = (
                parent.token_normalize_func if token_normalize_func is None else token_normalize_func
            )
            color = parent.color if color is None else color
            show_default = parent.show_default if show_default is None else show_default
            ignore_unknown_options = (
                parent.ignore_unknown_options if ignore_unknown_options is None
                else ignore_unknown_options
            )
            if auto_envvar_prefix is None and parent.auto_envvar_prefix:
                auto_envvar_prefix = parent.auto_envvar_prefix
                if info_name:
                    auto_envvar_prefix = f"{auto_envvar_prefix}_{info_name}"
            if default_map is None and isinstance(parent.default_map, dict):
                child_map = parent.default_map.get(info_name)
                default_map = child_map if isinstance(child_map, dict) else None
        self.obj = obj
        self.default_map = default_map
        self.terminal_width = terminal_width
        self.max_content_width = (
            DEFAULT_MAX_CONTENT_WIDTH if max_content_width is None else max_content_width
        )
        self.help_option_names = list(help_option_names) if help_option_names else ["--help"]
        self.token_normalize_func = token_normalize_func
        self.color = color
        self.show_default = bool(show_default)
        self.ignore_unknown_options = bool(ignore_unknown_options)
        self.allow_extra_args = (
            command.allow_extra_args if allow_extra_args is None else bool(allow_extra_args)
        )
        self.allow_interspersed_args = (
            command.allow_interspersed_args if allow_interspersed_args is None
            else bool(allow_interspersed_args)
        )
        self.auto_envvar_prefix = auto_envvar_prefix
        self.params = {}
        self.args = []
        self._raw = {}
        self._immediate = {}
        self._sources = {}
        self._given_args = []
        self._invoked_subcommand = None
        self._children = []
        self._close_callbacks = []
        self._command_params = None

    # -- identity and linkage -------------------------------------------------
    @property
    def command_path(self):
        if self.parent is not None:
            return f"{self.parent.command_path} {self.info_name}"
        return self.info_name or self.command.name or ""

    def auto_envvar_prefix_text(self):
        return (self.auto_envvar_prefix or "").upper().replace("-", "_")

    @property
    def command_params(self):
        if self._command_params is None:
            self._command_params = self.command.get_params(self)
        return self._command_params

    @property
    def invoked_subcommand(self):
        return self._invoked_subcommand

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type):
        node = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

    def get_parameter_source(self, name):
        declared = {p.name for p in self.command_params}
        if name not in declared:
            return None
        return self._sources.get(name)

    def lookup_default(self, name):
        if isinstance(self.default_map, dict) and name in self.default_map:
            return self.default_map[name]
        return None

    # -- output helpers -------------------------------------------------------
    def help_width(self):
        if self.terminal_width is not None:
            return self.terminal_width
        return min(terminal_size_columns(), self.max_content_width)

    def get_usage(self):
        return self.command.get_usage(self)

    def get_help(self):
        return self.command.get_help(self)

    # -- control flow ----------------------------------------------------------
    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def invoke(self, callback, *args, **kwargs):
        """Run a callback function, or another command with the given values."""
        if isinstance(callback, Command):
            values = dict(kwargs)
            child = Context(callback, info_name=callback.name, parent=self)
            with child:
                for param in child.command_params:
                    if param.expose_value and param.name not in values:
                        values[param.name] = param.resolve(child)[0]
                if callback.callback is None:
                    return None
                return callback.callback(**{
                    p.name: values[p.name] for p in child.command_params
                    if p.expose_value and p.name in values
                })
        with self:
            return callback(*args, **kwargs)

    def forward(self, cmd, **kwargs):
        values = dict(self.params)
        values.update(kwargs)
        return self.invoke(cmd, **values)

    def call_on_close(self, func):
        self._close_callbacks.append(func)

    def with_resource(self, context_manager):
        value = context_manager.__enter__()
        self.call_on_close(lambda: context_manager.__exit__(None, None, None))
        return value

    def close(self):
        for child in reversed(self._children):
            if child is not None:
                child.close()
        while self._close_callbacks:
            func = self._close_callbacks.pop()
            try:
                func()
            except OSError:
                pass

    def __enter__(self):
        _context.push_context(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        _context.pop_context(self)
        return False


# ---------------------------------------------------------------------------
# Commands and groups
# ---------------------------------------------------------------------------


def _help_callback(ctx, param, value):
    if not value:
        return value
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


def _record(ctx, param, entry):
    """Store one occurrence and run eager flags immediately (FP-02: first typed wins)."""
    ctx._raw.setdefault(param, []).append(entry)
    if param.is_eager and param.is_flag and param not in ctx._immediate:
        ctx._immediate[param] = entry
        if param.callback is not None:
            param.callback(ctx, param, entry)


def _lookup(table, ctx, name):
    if name in table:
        return table[name]
    normalize = ctx.token_normalize_func
    if normalize is not None:
        wanted = normalize(name)
        for key, value in table.items():
            if normalize(key) == wanted:
                return value
    return None


# spec: N-000850, N-000853, N-000854, N-000861
class Command:
    """A leaf command (spec: section 3 command, FP-01)."""

    allow_extra_args = False
    allow_interspersed_args = True

    def __init__(self, name=None, context_settings=None, callback=None, params=None, help=None,
                 epilog=None, short_help=None, options_metavar="[OPTIONS]", add_help_option=True,
                 no_args_is_help=False, hidden=False, deprecated=False, **kwargs):
        self.name = name
        self.context_settings = dict(context_settings or {})
        self.callback = callback
        self.params = list(params or [])
        self.help = help
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = bool(no_args_is_help)
        self.hidden = bool(hidden)
        self.deprecated = deprecated
        self.extra = kwargs
        if sum(1 for p in self.params if isinstance(p, Argument) and p.nargs == -1) > 1:
            raise OptlynDeclarationError("only one variadic argument may be declared on a command")

    @property
    def arguments(self):
        return [p for p in self.params if isinstance(p, Argument)]

    @property
    def options(self):
        return [p for p in self.params if isinstance(p, Option)]

    def get_params(self, ctx):
        params = list(self.params)
        if self.add_help_option:
            taken = set()
            for param in params:
                taken.update(param.opts)
                taken.update(param.secondary_opts)
            remaining = [n for n in ctx.help_option_names if n not in taken]
            if remaining:
                params.append(Option(
                    remaining, is_flag=True, is_eager=True, expose_value=False,
                    callback=_help_callback, help="Show this message and exit.",
                ))
        return params

    # -- invocation -----------------------------------------------------------
    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True, **extra):
        """Run this command as a program (spec: section 3, FP-01, FP-13)."""
        expand_args = extra.pop("windows_expand_args", True)
        if args is None:
            args = list(sys.argv[1:])
            if os.name == "nt" and expand_args:
                from .utils import expand_windows_args

                args = expand_windows_args(args)
        else:
            args = list(args)
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else (self.name or "root")
        var = complete_var or complete_var_name(prog_name)
        instruction = os.environ.get(var)
        if instruction:
            from .shell_completion import handle_instruction

            return handle_instruction(self, prog_name, instruction, args, standalone_mode)

        ctx = None
        try:
            try:
                ctx = self.make_context(prog_name, args, **extra)
                with ctx:
                    rv = self.invoke(ctx)
                if not standalone_mode:
                    return rv
                sys.exit(0)
            except Exit as exc:
                if standalone_mode:
                    sys.exit(exc.exit_code)
                return exc.exit_code
            except OptlynException as exc:
                if standalone_mode:
                    exc.show()
                    sys.exit(exc.exit_code)
                raise
            except (EOFError, KeyboardInterrupt):
                if standalone_mode:
                    echo("Aborted!", err=True)
                    sys.exit(1)
                raise Abort()
            except Abort:
                if standalone_mode:
                    echo("Aborted!", err=True)
                    sys.exit(1)
                raise
        finally:
            if ctx is not None:
                ctx.close()

    def make_context(self, info_name, args, parent=None, **extra):
        settings = dict(self.context_settings)
        settings.update(extra)
        ctx = Context(self, info_name=info_name, parent=parent, **settings)
        if parent is not None:
            parent._children.append(ctx)
        ctx._given_args = list(args)
        with ctx:
            self.parse_args(ctx, list(args))
        return ctx

    def invoke(self, ctx):
        with ctx:
            if self.deprecated:
                _warn_deprecated(self.name, "command", self.deprecated)
            if self.no_args_is_help and not ctx._given_args:
                echo(self.get_help(ctx), err=True)
                raise NoArgsIsHelpError("No arguments given.", ctx)
            return self._run_callback(ctx)

    def _run_callback(self, ctx):
        _process_params(ctx)
        if self.callback is None:
            return None
        kwargs = {p.name: ctx.params[p.name] for p in ctx.command_params
                  if p.expose_value and p.name in ctx.params}
        return self.callback(**kwargs)

    # -- parsing ----------------------------------------------------------------
    def parse_args(self, ctx, args):
        table = _option_table(ctx)
        positionals = _scan_leaf(self, ctx, table, args)
        leftover = _assign_arguments(self, ctx, positionals)
        if leftover:
            if any(not dd and _looks_like_option(table, ctx, tok) for tok, dd in leftover):
                if not ctx.ignore_unknown_options:
                    bad = next(tok for tok, dd in leftover if not dd and _looks_like_option(table, ctx, tok))
                    raise NoSuchOption(bad, ctx)
            if not ctx.allow_extra_args:
                names = " ".join(tok for tok, _ in leftover)
                raise UsageError(f"Got unexpected extra argument(s) ({names}).", ctx)
            ctx.args = [tok for tok, _ in leftover]
        else:
            ctx.args = []

    # -- help -------------------------------------------------------------------
    def get_usage(self, ctx):
        pieces = [ctx.command_path]
        if self.options_metavar:
            pieces.append(self.options_metavar)
        for arg in self.arguments:
            pieces.append(arg.usage_placeholder())
        placeholder = self._subcommand_placeholder()
        if placeholder:
            pieces.append(placeholder)
        return "Usage: " + " ".join(piece for piece in pieces if piece)

    def _subcommand_placeholder(self):
        return None

    def get_help(self, ctx):
        width = ctx.help_width()
        lines = [self.get_usage(ctx), ""]
        if self.deprecated:
            lines.extend(["(DEPRECATED)", ""])
        if self.help:
            lines.extend(rewrap_help(self.help, width))
            lines.append("")
        arg_rows = [arg.help_record(ctx) for arg in self.arguments if arg.help and not arg.hidden]
        if arg_rows:
            lines.append("Positional arguments:")
            lines.extend(format_dl(arg_rows, width))
            lines.append("")
        option_rows = []
        for param in ctx.command_params:
            if isinstance(param, Option) and not param.hidden and param.opts:
                option_rows.append(param.help_record(ctx))
        if option_rows:
            lines.append("Options:")
            lines.extend(format_dl(option_rows, width))
            lines.append("")
        lines.extend(self._extra_help_sections(ctx, width))
        if self.epilog:
            lines.extend(rewrap_help(self.epilog, width))
            lines.append("")
        text = "\n".join(lines)
        return text.rstrip("\n") + "\n"

    def _extra_help_sections(self, ctx, width):
        return []

    def short_help_text(self):
        if self.short_help:
            return self.short_help
        return make_default_short_help(self.help or "", 45)


def _warn_deprecated(name, kind, note):
    text = f"DeprecationWarning: The {kind} '{name}' is deprecated."
    if isinstance(note, str):
        text = f"{text} {note}"
    echo(text, err=True)


def _option_table(ctx):
    table = {}
    for param in ctx.command_params:
        if not isinstance(param, Option):
            continue
        for name in param.opts:
            table[name] = (param, param.kind)
        for name in param.secondary_opts:
            table[name] = (param, "off")
    return table


def _looks_like_option(table, ctx, tok):
    if len(tok) < 2:
        return False
    if tok.startswith("-"):
        return True
    if tok in table:
        return True
    return any(tok.startswith(name + "=") for name in table)


def _record_entry(ctx, param, entry):
    _record(ctx, param, entry)


def _apply_option(ctx, table, param, kind, key, tokens, nxt, attached):
    """Consume an option's value tokens; returns (next index, leftover positionals)."""
    if kind == "flag":
        _record_entry(ctx, param, param.flag_value)
        return nxt, []
    if kind == "off":
        _record_entry(ctx, param, False)
        return nxt, []
    if kind == "count":
        _record_entry(ctx, param, 1)
        return nxt, []
    if kind == "value":
        need = param.nargs
        values = [] if attached is None else [attached]
        index = nxt
        while len(values) < need and index < len(tokens):
            values.append(tokens[index])
            index += 1
        if len(values) < need:
            if param.prompt is not None and not values:
                _record_entry(ctx, param, _BARE)
                return nxt, []
            if need == 1:
                raise BadOptionUsage(f"Option '{key}' requires an argument.", ctx)
            raise BadOptionUsage(f"Option '{key}' requires {need} arguments.", ctx)
        _record_entry(ctx, param, tuple(values))
        return index, []
    # optional value
    if attached is not None:
        _record_entry(ctx, param, (attached,))
        return nxt, []
    if nxt < len(tokens) and not _looks_like_option(table, ctx, tokens[nxt]):
        _record_entry(ctx, param, (tokens[nxt],))
        return nxt + 1, []
    _record_entry(ctx, param, _BARE)
    return nxt, []


def _handle_option(ctx, table, tokens, index):
    tok = tokens[index]
    hit = _lookup(table, ctx, tok)
    key, attached = tok, None
    if hit is None and "=" in tok:
        name, _, value = tok.partition("=")
        candidate = _lookup(table, ctx, name)
        if candidate is not None:
            hit, key, attached = candidate, name, value
    if hit is not None:
        param, kind = hit
        return _apply_option(ctx, table, param, kind, key, tokens, index + 1, attached)
    if tok.startswith("--") or not tok.startswith("-"):
        if ctx.ignore_unknown_options:
            return index + 1, [(tok, False)]
        raise NoSuchOption(tok, ctx)
    # a stack of single-character short flags, e.g. -abc
    position = 1
    while position < len(tok):
        short = "-" + tok[position]
        hit = _lookup(table, ctx, short)
        if hit is None:
            if ctx.ignore_unknown_options:
                return index + 1, [("-" + tok[position:], False)]
            raise NoSuchOption(short, ctx)
        param, kind = hit
        if kind in ("value", "optval"):
            rest = tok[position + 1:]
            return _apply_option(ctx, table, param, kind, short, tokens, index + 1, rest or None)
        _apply_option(ctx, table, param, kind, short, tokens, index + 1, None)
        position += 1
    return index + 1, []


# spec: N-000196 (leaf options and arguments may be mixed)
def _scan_leaf(cmd, ctx, table, tokens):
    positionals = []
    index = 0
    after_dashes = False
    while index < len(tokens):
        tok = tokens[index]
        if after_dashes:
            positionals.append((tok, True))
            index += 1
            continue
        if tok == "--":
            after_dashes = True
            index += 1
            continue
        if _looks_like_option(table, ctx, tok):
            index, extra = _handle_option(ctx, table, tokens, index)
            positionals.extend(extra)
            continue
        positionals.append((tok, False))
        index += 1
        if not ctx.allow_interspersed_args:
            positionals.extend((rest, False) for rest in tokens[index:])
            break
    return positionals


def _group_capacity(cmd):
    total = 0
    for arg in cmd.arguments:
        if arg.nargs == -1:
            return float("inf")
        total += arg._occ_size()
    return total


# spec: N-000197 (group option parsing stops at the subcommand name)
def _scan_group(cmd, ctx, table, tokens):
    """Parse a group's own options; returns (positionals, tokens starting at the subcommand name)."""
    capacity = _group_capacity(cmd)
    positionals = []
    index = 0
    after_dashes = False
    while index < len(tokens):
        tok = tokens[index]
        if not after_dashes and tok == "--":
            after_dashes = True
            index += 1
            continue
        if not after_dashes and _looks_like_option(table, ctx, tok):
            index, extra = _handle_option(ctx, table, tokens, index)
            positionals.extend(extra)
            continue
        if len(positionals) < capacity:
            positionals.append((tok, after_dashes))
            index += 1
            continue
        # the first token that is not a group argument names the subcommand
        rest = [tok]
        index += 1
        if not ctx.allow_interspersed_args:
            rest.extend(tokens[index:])
            return positionals, rest
        while index < len(tokens):
            item = tokens[index]
            if item != "--" and _lookup(table, ctx, item) is not None and _looks_like_option(table, ctx, item):
                index, _ = _handle_option(ctx, table, tokens, index)
                continue
            rest.append(item)
            index += 1
        return positionals, rest
    return positionals, []


def _assign_arguments(cmd, ctx, positionals):
    """Give positional tokens to arguments in declaration order; returns leftovers."""
    arguments = cmd.arguments
    values = list(positionals)
    for position, arg in enumerate(arguments):
        later = sum(a._occ_min() for a in arguments[position + 1:] if a.required)
        if arg.nargs == -1:
            take = max(0, len(values) - later)
            chosen = values[:take]
            values = values[take:]
            if chosen:
                ctx._raw.setdefault(arg, []).append([tok for tok, _ in chosen])
            continue
        need = arg._occ_size()
        if len(values) >= need:
            chosen = values[:need]
            values = values[need:]
            ctx._raw.setdefault(arg, []).append([tok for tok, _ in chosen])
        elif values and arg.required:
            raise BadArgumentUsage(f"Argument '{arg.name.upper()}' takes {need} values.", ctx)
    return values


# spec: N-000862, N-000864, N-000865, N-000869, N-000871, N-000874, N-000876
class Group(Command):
    """A command that dispatches to named subcommands (spec: section 3 Group, FP-06, FP-10)."""

    allow_extra_args = True
    allow_interspersed_args = False

    def __init__(self, name=None, commands=None, invoke_without_command=False, no_args_is_help=None,
                 subcommand_metavar=None, chain=False, result_callback=None, **kwargs):
        super().__init__(name=name, **kwargs)
        self.commands = dict(commands or {})
        self.invoke_without_command = bool(invoke_without_command)
        if no_args_is_help is None:
            no_args_is_help = not self.invoke_without_command
        self.no_args_is_help = bool(no_args_is_help)
        self.subcommand_metavar = subcommand_metavar
        self.chain = bool(chain)
        self._result_callback_fn = result_callback

    # -- registration -----------------------------------------------------------
    def add_command(self, cmd, name=None):
        if self.chain and isinstance(cmd, Group):
            raise OptlynDeclarationError("groups cannot be nested beneath a chaining group")
        key = name if name is not None else cmd.name
        self.commands[key] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as command_decorator

        if args and callable(args[0]) and not isinstance(args[0], str):
            return self.command()(args[0])

        def decorator(func):
            cmd = command_decorator(*args, **kwargs)(func)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as group_decorator

        if args and callable(args[0]) and not isinstance(args[0], str):
            return self.group()(args[0])

        def decorator(func):
            cmd = group_decorator(*args, **kwargs)(func)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self):
        def decorator(func):
            self._result_callback_fn = func
            return func

        return decorator

    # -- lookup -----------------------------------------------------------------
    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        cmd = self.commands.get(cmd_name)
        if cmd is None and ctx is not None and ctx.token_normalize_func is not None:
            wanted = ctx.token_normalize_func(cmd_name)
            for key, value in self.commands.items():
                if ctx.token_normalize_func(key) == wanted:
                    return value
        return cmd

    def _subcommand_placeholder(self):
        meta = self.subcommand_metavar or "COMMAND"
        if self.chain:
            return f"{meta} [ARGS]... [{meta} [ARGS]...]..."
        if self.invoke_without_command:
            return f"[{meta}] [ARGS]..."
        return f"{meta} [ARGS]..."

    def _extra_help_sections(self, ctx, width):
        rows = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            rows.append((name, cmd.short_help_text()))
        if not rows:
            return []
        return ["Commands:"] + format_dl(rows, width) + [""]

    # -- parsing ----------------------------------------------------------------
    def parse_args(self, ctx, args):
        table = _option_table(ctx)
        positionals, rest = _scan_group(self, ctx, table, args)
        leftover = _assign_arguments(self, ctx, positionals)
        if leftover:
            raise UsageError(f"Got unexpected extra argument(s) ({' '.join(t for t, _ in leftover)}).", ctx)
        ctx.args = rest

    # -- invocation -------------------------------------------------------------
    def invoke(self, ctx):
        with ctx:
            if self.deprecated:
                _warn_deprecated(self.name, "command", self.deprecated)
            tokens = list(ctx.args)
            if not tokens:
                if self.invoke_without_command:
                    if self.chain:
                        return self._invoke_chain(ctx)
                    return self._run_group(ctx, None, None)
                if self.no_args_is_help and not ctx._given_args:
                    echo(self.get_help(ctx), err=True)
                    raise UsageError("Missing command.", ctx)
                raise UsageError("Missing command.", ctx)
            if self.chain:
                return self._invoke_chain(ctx)
            name, rest = tokens[0], tokens[1:]
            cmd = self.get_command(ctx, name)
            if cmd is None:
                raise NoSuchCommand(name, ctx)
            return self._run_group(ctx, name, (cmd, rest))

    def _run_group(self, ctx, name, dispatch):
        if dispatch is None or name is None:
            _process_params(ctx)
            ctx._invoked_subcommand = None
            value = self.callback(**_exposed(ctx)) if self.callback else None
            if self._result_callback_fn is not None:
                return self._finish_result(ctx, value)
            return value
        cmd, rest = dispatch
        ctx._invoked_subcommand = name
        _process_params(ctx)
        if self.callback is not None:
            self.callback(**_exposed(ctx))
        child = cmd.make_context(name, rest, parent=ctx)
        with child:
            value = cmd.invoke(child)
        child.close()
        if self._result_callback_fn is not None:
            return self._finish_result(ctx, value)
        return value

    def _finish_result(self, ctx, value):
        return ctx.invoke(self._result_callback_fn, value, **ctx.params)

    def _invoke_chain(self, ctx):
        tokens = list(ctx.args)
        ctx._invoked_subcommand = CHAIN_SUBCOMMAND
        _process_params(ctx)
        if self.callback is not None:
            self.callback(**_exposed(ctx))
        children = []
        while tokens:
            name, rest = tokens[0], tokens[1:]
            cmd = self.get_command(ctx, name)
            if cmd is None:
                raise NoSuchCommand(name, ctx)
            child = cmd.make_context(name, rest, parent=ctx, allow_extra_args=True,
                                     allow_interspersed_args=False)
            children.append((cmd, child))
            tokens = list(child.args)
        results = []
        for cmd, child in children:
            with child:
                results.append(cmd.invoke(child))
            child.close()
        if self._result_callback_fn is not None:
            ctx.invoke(self._result_callback_fn, results, **ctx.params)
        return results


# spec: N-000878, N-000879, N-000880
class CommandCollection(Group):
    """Presents the subcommands of several source groups under one dispatch surface."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name=name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = set()
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None


def _exposed(ctx):
    return {p.name: ctx.params[p.name] for p in ctx.command_params
            if p.expose_value and p.name in ctx.params}


# spec: N-000913, N-000914, N-000915, N-000916, N-000917, N-000918, N-000920 (delivered values)
def _process_params(ctx):
    """Resolve, convert and call back every parameter in order; eager ones first (FP-03)."""
    ctx.params = {}
    params = ctx.command_params
    ordered = [p for p in params if p.is_eager] + [p for p in params if not p.is_eager]
    shared = {}
    for param in ordered:
        shared.setdefault(param.name, []).append(param)
    winners = {}
    for index, param in enumerate(ordered):
        if param in ctx._immediate:
            value = ctx._immediate[param]
            winners[param.name] = (param, value, ParameterSource.COMMANDLINE, index, (0,))
            continue
        value, source = param.resolve(ctx)
        if param.required and source is ParameterSource.DEFAULT and param.default is None:
            raise MissingParameter(param=param, ctx=ctx)
        if param.deprecated and source is ParameterSource.COMMANDLINE:
            _warn_deprecated(param.display_name(), param.param_kind, param.deprecated)
        value = param.run_callback(ctx, value)
        if len(shared[param.name]) == 1:
            if param.expose_value:
                ctx.params[param.name] = value
            ctx._sources[param.name] = source
        else:
            best = winners.get(param.name)
            key = (_SOURCE_RANK[source], 0 if (source is ParameterSource.DEFAULT and param.default_is_set) else 1, -index)
            if best is None or key < best[4]:
                winners[param.name] = (param, value, source, index, key)
    for name, winner in winners.items():
        param, value, source = winner[0], winner[1], winner[2]
        if param.expose_value:
            ctx.params[name] = value
        ctx._sources[name] = source


# ---------------------------------------------------------------------------
# Helpers for the public decorators
# ---------------------------------------------------------------------------

