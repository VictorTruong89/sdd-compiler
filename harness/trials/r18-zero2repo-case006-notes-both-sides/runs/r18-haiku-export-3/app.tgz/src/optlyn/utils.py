"""File, path and application helpers (FP-09, FP-11)."""

import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile

from .exceptions import FileError


class _NonClosing:
    """Wraps a process standard stream: closing the wrapper never closes the stream."""

    def __init__(self, stream):
        object.__setattr__(self, "_stream", stream)

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __iter__(self):
        return iter(self._stream)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def close(self):
        try:
            self._stream.flush()
        except (OSError, ValueError):
            pass


def _std_stream(mode):
    binary = "b" in mode
    base = sys.stdin if "r" in mode else sys.stdout
    if binary:
        base = getattr(base, "buffer", base)
    return _NonClosing(base)


class _AtomicFile:
    """Writes to a sibling temporary file; the target is replaced on close."""

    def __init__(self, handle, tmp_path, target):
        self._handle = handle
        self._tmp_path = tmp_path
        self._target = target
        self.name = target

    def __getattr__(self, name):
        return getattr(self._handle, name)

    def __iter__(self):
        return iter(self._handle)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def close(self):
        if self._handle.closed:
            return
        self._handle.close()
        os.replace(self._tmp_path, self._target)


def _open_real(filename, mode, encoding=None, errors="strict", atomic=False):
    """Open a real file; raises OSError on failure."""
    binary = "b" in mode
    kwargs = {} if binary else {"encoding": encoding, "errors": errors}
    if atomic and "w" in mode:
        directory = os.path.dirname(os.path.abspath(filename))
        fd, tmp_path = tempfile.mkstemp(dir=directory, prefix=".optlyn-", suffix=".tmp")
        handle = os.fdopen(fd, mode, **kwargs)
        return _AtomicFile(handle, tmp_path, filename)
    return open(filename, mode, **kwargs)


class LazyFile:
    """A file that is opened on first I/O (spec: FP-09 lazy write)."""

    def __init__(self, filename, mode, encoding=None, errors="strict", atomic=False):
        self.name = filename
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._file = None

    def _ensure(self):
        if self._file is None:
            try:
                self._file = _open_real(self.name, self.mode, self.encoding, self.errors, self.atomic)
            except OSError as exc:
                raise FileError(self.name, exc.strerror or str(exc)) from exc
        return self._file

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        return getattr(self._ensure(), name)

    def __iter__(self):
        return iter(self._ensure())

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    @property
    def closed(self):
        return self._file is not None and self._file.closed

    def close(self):
        if self._file is not None:
            self._file.close()


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file, or a standard stream for ``-`` (spec: section 7, FP-09)."""
    filename = os.fspath(filename) if hasattr(filename, "__fspath__") else filename
    if filename == "-":
        return _std_stream(mode)
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    try:
        return _open_real(filename, mode, encoding, errors, atomic)
    except OSError as exc:
        raise FileError(filename, exc.strerror or str(exc)) from exc


def format_filename(filename, shorten=False):
    """Text that can be printed and encoded as UTF-8 without failing (FP-09)."""
    if hasattr(filename, "__fspath__"):
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        text = filename.decode("utf-8", "backslashreplace")
    else:
        text = str(filename)
    if shorten:
        text = os.path.basename(text)
    return text.encode("utf-8", "backslashreplace").decode("utf-8")


_UNIX_FOLDER_RE = re.compile(r"\s+")


def get_app_dir(app_name, roaming=True, force_posix=False):
    """Per-user config directory for an application (spec: FP-11)."""
    home = os.path.expanduser("~")
    if not force_posix:
        if sys.platform == "darwin":
            return os.path.join(home, "Library", "Application Support", app_name)
        if sys.platform == "win32":
            base = os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming")
            return os.path.join(base, app_name)
    folder = _UNIX_FOLDER_RE.sub("-", app_name.lower())
    if force_posix:
        return os.path.join(home, "." + folder)
    config_home = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(config_home, folder)


def launch(url, wait=False, locate=False):
    """Open a URL or file with the default application; returns a status (spec: FP-11)."""
    if sys.platform == "win32":
        try:
            os.startfile(url)  # type: ignore[attr-defined]
        except OSError:
            return 1
        return 0
    if sys.platform == "darwin":
        command = ["open", "-R", url] if locate else ["open", url]
    else:
        command = ["xdg-open", url]
    try:
        proc = subprocess.Popen(command)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0


def clear_screen():
    """Clear the visible terminal; does nothing when stdout is not a terminal."""
    try:
        is_tty = sys.stdout.isatty()
    except (AttributeError, ValueError):
        is_tty = False
    if not is_tty:
        return
    if os.name == "nt":
        os.system("cls")
        return
    sys.stdout.write("\033[2J\033[H")
    sys.stdout.flush()


def edit_text(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Run an editor on text or on a file (spec: section 7 edit)."""
    if editor is None:
        editor = (
            os.environ.get("VISUAL")
            or os.environ.get("EDITOR")
            or ("notepad" if os.name == "nt" else "vi")
        )
    command = shlex.split(editor, posix=os.name != "nt") if os.name != "nt" else [editor]
    run_env = dict(os.environ)
    if env:
        run_env.update(env)

    if filename is not None:
        subprocess.call(command + [os.fspath(filename)], env=run_env)
        return None

    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(text or "")
        with open(path, "r", encoding="utf-8", newline="") as handle:
            before = handle.read()
        subprocess.call(command + [path], env=run_env)
        with open(path, "r", encoding="utf-8", newline="") as handle:
            after = handle.read()
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
    if require_save and after == before:
        return None
    return after


def terminal_size_columns(default=80):
    return shutil.get_terminal_size((default, 24)).columns


# spec: N-000051 (Windows argument expansion)
def expand_windows_args(args):
    """Expand ``~``, environment variables and glob patterns in program arguments (spec: section 17).

    Only applied when running as a program on Windows; a Unix shell expands these earlier.
    """
    import glob

    out = []
    for arg in args:
        text = os.path.expandvars(os.path.expanduser(arg))
        if any(ch in text for ch in "*?["):
            matches = sorted(glob.glob(text))
            out.extend(matches if matches else [text])
        else:
            out.append(text)
    return out
