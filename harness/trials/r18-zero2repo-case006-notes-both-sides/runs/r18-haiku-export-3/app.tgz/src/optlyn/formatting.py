"""Text wrapping and two-column layout used by help pages (FP-02, FP-11)."""

import re
import textwrap

DEFAULT_MAX_CONTENT_WIDTH = 80  # spec: FP-02 / FP-11 (see NOTES.md, CF-000087)


def _fill(text, width, initial_indent="", subsequent_indent=""):
    width = max(int(width), len(initial_indent) + 1, len(subsequent_indent) + 1, 1)
    words = " ".join(text.split())
    if not words:
        return ""
    wrapper = textwrap.TextWrapper(
        width=width,
        initial_indent=initial_indent,
        subsequent_indent=subsequent_indent,
        break_long_words=True,
        break_on_hyphens=False,
    )
    return wrapper.fill(words)


def wrap_text(text, width=DEFAULT_MAX_CONTENT_WIDTH, initial_indent="", subsequent_indent="",
              preserve_paragraphs=False):
    """Wrap any string; returns the wrapped text (spec: optlyn.formatting.wrap_text)."""
    text = "" if text is None else str(text)
    if not preserve_paragraphs:
        return _fill(text, width, initial_indent, subsequent_indent)
    parts = []
    for paragraph in re.split(r"\n[ \t]*\n", text):
        lines = paragraph.split("\n")
        if lines and lines[0].strip() == "\b":
            kept = [line.rstrip() for line in lines[1:]]
            parts.append("\n".join(initial_indent + line for line in kept))
        else:
            wrapped = _fill(paragraph, width, initial_indent, subsequent_indent)
            if wrapped:
                parts.append(wrapped)
    return "\n\n".join(parts)


def rewrap_help(text, width):
    """Rewrap help text: single newlines are not hard breaks; a paragraph whose first
    line is only a backspace keeps its line breaks (spec: FP-02)."""
    lines_out = []
    paragraphs = [p for p in re.split(r"\n[ \t]*\n", text.strip("\n"))]
    for index, paragraph in enumerate(paragraphs):
        if index:
            lines_out.append("")
        lines = paragraph.split("\n")
        if lines and lines[0].strip() == "\b":
            lines_out.extend(line.rstrip() for line in lines[1:])
        else:
            filled = _fill(paragraph, width)
            if filled:
                lines_out.extend(filled.split("\n"))
    return lines_out


def make_default_short_help(help_text, max_length=45):
    """Short help for a subcommand listing: the first sentence, cut with '...' (spec: FP-02, section 2)."""
    if not help_text:
        return ""
    first_paragraph = re.split(r"\n[ \t]*\n", help_text.strip())[0]
    text = " ".join(first_paragraph.split())
    match = re.search(r"[.!?](\s|$)", text)
    if match:
        text = text[: match.start() + 1]
    if len(text) <= max_length:
        return text
    words = text.split()
    out = ""
    for word in words:
        candidate = word if not out else out + " " + word
        if len(candidate) + 3 > max_length:
            break
        out = candidate
    if not out:
        out = text[: max_length - 3]
    return out + "..."


def format_dl(rows, width, indent=2, col_max=30, col_spacing=2):
    """Lay out (term, description) rows in two columns; returns lines."""
    if not rows:
        return []
    term_width = max(len(term) for term, _ in rows) + indent
    first_col = min(term_width, col_max)
    help_width = max(width - first_col - col_spacing, 10)
    lines = []
    for term, desc in rows:
        left = " " * indent + term
        desc_lines = textwrap.wrap(" ".join(desc.split()), help_width) if desc else []
        if not desc_lines:
            lines.append(left)
            continue
        if len(left) <= first_col:
            lines.append(left.ljust(first_col + col_spacing) + desc_lines[0])
        else:
            lines.append(left)
            lines.append(" " * (first_col + col_spacing) + desc_lines[0])
        pad = " " * (first_col + col_spacing)
        lines.extend(pad + line for line in desc_lines[1:])
    return lines
