"""Optlyn: a composable command line interface toolkit.

Public names follow spec section 1 (Interface Contract, Package and modules).
"""

from .core import (
    Argument,
    Command,
    CommandCollection,
    Context,
    Group,
    Option,
    Parameter,
)
from .decorators import (
    argument,
    command,
    confirmation_option,
    custom_version_option,
    group,
    help_option,
    make_pass_decorator,
    option,
    pass_context,
    pass_obj,
    password_option,
    version_option,
)
from .exceptions import Abort, BadParameter, Exit, FileError, MissingParameter, UsageError
from .paramtypes import (
    BOOL,
    FLOAT,
    INT,
    STRING,
    UNPROCESSED,
    UUID,
    Choice,
    DateTime,
    File,
    FloatRange,
    IntRange,
    ParamType,
    Path,
    Tuple,
)
from .termui import (
    clear,
    confirm,
    echo,
    echo_via_pager,
    edit,
    get_app_dir,
    get_current_context,
    get_pager_file,
    getchar,
    launch,
    pause,
    progressbar,
    prompt,
    secho,
    style,
    unstyle,
)
from .utils import format_filename, open_file

__all__ = [
    "Abort", "Argument", "BadParameter", "BOOL", "Choice", "Command", "CommandCollection",
    "Context", "DateTime", "Exit", "File", "FileError", "FLOAT", "FloatRange", "Group", "INT",
    "IntRange", "MissingParameter", "Option", "Parameter", "ParamType", "Path", "STRING",
    "Tuple", "UNPROCESSED", "UsageError", "UUID", "argument", "clear", "command",
    "confirm", "confirmation_option", "custom_version_option", "echo", "echo_via_pager", "edit",
    "format_filename", "get_app_dir", "get_current_context", "get_pager_file", "getchar",
    "group", "help_option", "launch", "make_pass_decorator", "open_file", "option", "pass_context",
    "pass_obj", "password_option", "pause", "progressbar", "prompt", "secho", "style", "unstyle",
    "version_option",
]

__version__ = "0.1.0"
