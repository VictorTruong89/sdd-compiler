"""Terminal helpers: echo, styling, prompts, pager, progress bars (spec: section 7, FP-08, FP-11)."""

import contextlib
import getpass
import os
import re
import subprocess
import sys
import time

from . import _context
from .exceptions import Abort
from .utils import clear_screen, edit_text
from .utils import get_app_dir as _get_app_dir
from .utils import launch as _launch

_ANSI_RE = re.compile(r"\033\[[0-?]*[ -/]*[@-~]")


class InvalidColorError(TypeError, ValueError):
    """A style color is not a name, a 0-255 integer, or an RGB triple."""


def unstyle(text):
    """Remove ANSI escape sequences, leaving all other text (spec: section 7)."""
    return _ANSI_RE.sub("", text)


_NAMED = {
    "black": 0, "red": 1, "green": 2, "yellow": 3,
    "blue": 4, "magenta": 5, "cyan": 6, "white": 7,
}


def _color_code(color, background):
    if isinstance(color, str):
        if color == "reset":
            return "49" if background else "39"
        bright = color.startswith("bright_")
        base = color[len("bright_"):] if bright else color
        if base not in _NAMED:
            raise InvalidColorError(f"unknown color {color!r}")
        if bright:
            return str((100 if background else 90) + _NAMED[base])
        return str((40 if background else 30) + _NAMED[base])
    if isinstance(color, bool):
        raise InvalidColorError(f"invalid color {color!r}")
    if isinstance(color, int):
        if 0 <= color <= 255:
            return f"{48 if background else 38};5;{color}"
        raise InvalidColorError(f"color index {color} is out of range 0-255")
    if isinstance(color, (tuple, list)) and len(color) == 3:
        if all(isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color):
            r, g, b = color
            return f"{48 if background else 38};2;{r};{g};{b}"
    raise InvalidColorError(f"invalid color {color!r}")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True):
    """Wrap text in ANSI SGR sequences (spec: section 7, FP-11)."""
    bits = []
    if fg is not None:
        bits.append(_color_code(fg, background=False))
    if bg is not None:
        bits.append(_color_code(bg, background=True))
    for flag, code in ((bold, 1), (dim, 2), (italic, 3), (underline, 4), (blink, 5),
                       (reverse, 7), (strikethrough, 9), (overline, 53)):
        if flag:
            bits.append(str(code))
    if not bits:
        return text
    prefix = "\033[" + ";".join(bits) + "m"
    return prefix + text + ("\033[0m" if reset else "")


def _is_tty(stream):
    try:
        return bool(stream.isatty())
    except (AttributeError, ValueError):
        return False


# spec: N-001012 (interactivity from terminal state of standard streams)
def _interactive():
    return _is_tty(sys.stdin) and _is_tty(sys.stdout)


def _current_color():
    ctx = _context.get_current_context(silent=True)
    return ctx.color if ctx is not None else None


def _keep_styles(stream, color):
    if color is None:
        color = _current_color()
    if color is None:
        return _is_tty(stream)
    return bool(color)


def _write_text(stream, text):
    encoding = (getattr(stream, "encoding", None) or "").lower()
    buffer = getattr(stream, "buffer", None)
    if encoding in ("ascii", "us-ascii") and buffer is not None:
        stream.flush()
        buffer.write(text.encode("utf-8", "backslashreplace"))
        buffer.flush()
        return
    try:
        stream.write(text)
    except UnicodeEncodeError:
        stream.flush()
        if buffer is not None:
            buffer.write(text.encode("utf-8", "backslashreplace"))
            buffer.flush()
        else:
            stream.write(text.encode("utf-8", "backslashreplace").decode("ascii"))


# spec: N-000981 (helpers write through sys.stdout / sys.stderr)
def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write text or bytes to stdout (or stderr with err=True); strips styles off-terminal."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        buffer = getattr(file, "buffer", None)
        if buffer is not None:
            file.flush()
            buffer.write(message + (b"\n" if nl else b""))
            buffer.flush()
        else:
            file.write(message.decode("utf-8", "replace") + ("\n" if nl else ""))
        file.flush()
        return
    text = str(message)
    if not _keep_styles(file, color):
        text = unstyle(text)
    if nl:
        text += "\n"
    _write_text(file, text)
    file.flush()


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    """Styled echo: ``echo(style(message, **styles))``."""
    if message is not None and not isinstance(message, bytes):
        message = style(str(message), **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


class _PagerStream:
    def __init__(self, handle, keep):
        self._handle = handle
        self._keep = keep
        self.encoding = "utf-8"

    def write(self, text):
        if not self._keep:
            text = unstyle(text)
        self._handle.write(text.encode("utf-8", "replace"))
        self._handle.flush()
        return len(text)

    def flush(self):
        self._handle.flush()


def _pager_command():
    return os.environ.get("PAGER")


@contextlib.contextmanager
def get_pager_file(color=None):
    """Context manager yielding a writable text stream for pager output (FP-11)."""
    keep = bool(color) if color is not None else False
    pager = _pager_command()
    if _interactive() and pager:
        proc = subprocess.Popen(pager, shell=True, stdin=subprocess.PIPE)
        try:
            yield _PagerStream(proc.stdin, keep)
        finally:
            try:
                proc.stdin.close()
            except OSError:
                pass
            proc.wait()
    else:
        stream = sys.stdout
        try:
            yield _NoCloseText(stream, keep)
        finally:
            stream.flush()


class _NoCloseText:
    def __init__(self, stream, keep):
        self._stream = stream
        self._keep = keep

    def write(self, text):
        if not self._keep:
            text = unstyle(text)
        return self._stream.write(text)

    def flush(self):
        self._stream.flush()


def echo_via_pager(text_or_generator, color=None):
    """Write long text through the pager when interactive (FP-11)."""
    value = text_or_generator() if callable(text_or_generator) else text_or_generator
    chunks = [value] if isinstance(value, str) else value
    with get_pager_file(color=color) as stream:
        for chunk in chunks:
            stream.write(chunk if isinstance(chunk, str) else str(chunk))
            stream.flush()


class ProgressBar:
    """Yields items and tracks progress; draws only on a terminal (FP-11)."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.pos = 0
        self.finished = False
        self._start = time.monotonic()
        self._show = (not hidden) and _is_tty(sys.stdout)
        if label and not hidden and not self._show:
            sys.stdout.write(f"{label}\n")
            sys.stdout.flush()

    def __iter__(self):
        if self.iterable is None:
            return
        for item in self.iterable:
            yield item
            self.update(1)

    def update(self, n_steps):
        self.pos += n_steps
        if self._show:
            self._render()

    def _eta(self):
        if not self.length or self.pos <= 0:
            return ""
        elapsed = time.monotonic() - self._start
        remaining = elapsed / self.pos * max(self.length - self.pos, 0)
        return f" eta {int(remaining) // 60:02d}:{int(remaining) % 60:02d}"

    def _render(self):
        if self.length:
            fraction = min(self.pos / self.length, 1.0)
            filled = int(fraction * 30)
            bar = "#" * filled + "-" * (30 - filled)
            line = f"\r{self.label} [{bar}] {self.pos}/{self.length}{self._eta()}"
        else:
            line = f"\r{self.label} {self.pos}"
        sys.stdout.write(line)
        sys.stdout.flush()

    def finish(self):
        if self.finished:
            return
        self.finished = True
        if self._show:
            sys.stdout.write("\n")
            sys.stdout.flush()


@contextlib.contextmanager
def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    bar = ProgressBar(iterable, length, label, hidden)
    try:
        yield bar
    finally:
        bar.finish()


def _read_line(prompt_text, hide_input, err):
    """Read one line for a prompt; EOF becomes an abort (FP-08, FP-13)."""
    out = sys.stderr if err else sys.stdout
    if not _keep_styles(out, None):
        prompt_text = unstyle(prompt_text)
    reader = getattr(sys.stdin, "prompt_readline", None)
    if reader is not None:
        line = reader(prompt_text, hide_input, err)
        if line is None:
            raise Abort()
        return line
    if hide_input and _is_tty(sys.stdin):
        try:
            return getpass.getpass(prompt_text, stream=out)
        except EOFError:
            raise Abort()
    out.write(prompt_text)
    out.flush()
    line = sys.stdin.readline()
    if line == "":
        out.write("\n")
        out.flush()
        raise Abort()
    if not _is_tty(sys.stdin):
        out.write(("" if hide_input else line.rstrip("\r\n")) + "\n")
    out.flush()
    return line.rstrip("\r\n")


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False, show_choices=True):
    """Ask for a value and return it converted; re-asks on conversion failure (FP-08)."""
    from .paramtypes import make_param_type

    ptype = make_param_type(type, default)
    ctx = _context.get_current_context(silent=True)
    while True:
        shown = text
        if default is not None and show_default and not hide_input:
            shown = f"{text} [{default}]"
        value = _read_line(shown + prompt_suffix, hide_input, err)
        if value == "":
            if default is None:
                continue
            value = default
        try:
            result = ptype.convert(value, None, ctx)
        except Exception as exc:  # BadParameter from conversion
            message = getattr(exc, "format_message", None)
            detail = message() if message else str(exc)
            echo(f"Error: {detail}", err=True)
            continue
        if confirmation_prompt:
            second = _read_line(f"Repeat for confirmation{prompt_suffix}", hide_input, err)
            if second != value:
                echo("Error: The two entered values do not match.", err=True)
                continue
        return result


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    """Ask a yes/no question; returns a bool (FP-08)."""
    hint = "[Y/n]" if default else "[y/N]"
    while True:
        answer = _read_line(f"{text} {hint}{prompt_suffix}", False, err).strip().lower()
        if answer == "":
            result = default
            break
        if answer in ("y", "yes"):
            result = True
            break
        if answer in ("n", "no"):
            result = False
            break
        echo("Error: invalid input", err=True)
    if not result and abort:
        raise Abort()
    return result


def getchar(echo=False):
    """Read one character from the terminal, even when stdin is a pipe (FP-11)."""
    if os.name == "nt":
        import msvcrt  # pragma: no cover

        char = msvcrt.getwch()  # pragma: no cover
    else:
        char = None
        try:
            fd = os.open("/dev/tty", os.O_RDONLY)
        except OSError:
            fd = None
        if fd is None:
            char = sys.stdin.read(1)
        else:
            try:
                import termios
                import tty

                old = termios.tcgetattr(fd)
                try:
                    tty.setraw(fd)
                    char = os.read(fd, 1).decode("utf-8", "replace")
                finally:
                    termios.tcsetattr(fd, termios.TCSADRAIN, old)
            except ImportError:
                char = os.read(fd, 1).decode("utf-8", "replace")
            finally:
                os.close(fd)
    if char == "":
        raise EOFError()
    if char == "\x03":
        raise KeyboardInterrupt()
    if char == "\x04":
        raise EOFError()
    if echo:
        sys.stdout.write(char)
        sys.stdout.flush()
    return char


def pause(info=None, err=False):
    """Print a message and wait for a key when interactive; never blocks otherwise."""
    if info is None:
        info = "Press any key to continue..."
    stream = sys.stderr if err else sys.stdout
    if _interactive():
        stream.write(info)
        stream.flush()
        getchar()
        stream.write("\n")
        stream.flush()
    else:
        stream.write(info + "\n")
        stream.flush()


# spec: N-000997 (editor launch)
def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Launch an editor on text or a file (FP-11)."""
    return edit_text(text, editor, env, require_save, extension, filename)


def launch(url, wait=False, locate=False):
    """Open a URL or path with the default application (FP-11)."""
    return _launch(url, wait=wait, locate=locate)


def clear():
    """Clear the screen when attached to a terminal (FP-11)."""
    clear_screen()


def get_app_dir(app_name, roaming=True, force_posix=False):
    """Per-user config directory path for an application (FP-11)."""
    return _get_app_dir(app_name, roaming=roaming, force_posix=force_posix)


# spec: N-000978, N-000979, N-000980
def get_current_context(silent=False):
    """The context current on this thread (spec: section 6)."""
    return _context.get_current_context(silent=silent)
