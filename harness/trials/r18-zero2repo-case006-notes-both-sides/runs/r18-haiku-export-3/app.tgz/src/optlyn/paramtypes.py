"""Parameter types and conversion (spec: section 5, FP-05, FP-09)."""

import datetime as _dt
import enum
import os
import pathlib
import uuid

from .exceptions import BadParameter, OptlynDeclarationError
from .utils import open_file


class ParamType:
    """Base class for parameter types. Subclasses set ``name`` and implement ``convert``."""

    name = "text"
    is_composite = False
    envvar_splitter = None  # None means whitespace

    def __call__(self, value, param=None, ctx=None):
        return self.convert(value, param, ctx)

    def convert(self, value, param, ctx):  # spec: section 5 ParamType
        return value

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def get_metavar(self, param):
        return None

    def split_env(self, raw):
        if self.envvar_splitter is None:
            return raw.split()
        return [part for part in raw.split(self.envvar_splitter) if part != ""]

    def shell_complete(self, ctx, param, incomplete):
        return []

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"


class CompletionItem:
    """A suggestion with help text and kind (spec: section 8)."""

    def __init__(self, value, help=None, type="plain"):
        self.value = str(value)
        self.help = help
        self.type = type

    def __repr__(self):
        return f"CompletionItem({self.value!r}, {self.help!r}, {self.type!r})"


def _text_of(value):
    if isinstance(value, bytes):
        return value.decode("utf-8", "replace")
    return str(value)


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        return _text_of(value)


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            return int(_text_of(value).strip())
        except ValueError:
            self.fail(f"{_text_of(value)!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param, ctx):
        if isinstance(value, float):
            return value
        if isinstance(value, int) and not isinstance(value, bool):
            return float(value)
        try:
            return float(_text_of(value).strip())
        except ValueError:
            self.fail(f"{_text_of(value)!r} is not a valid float.", param, ctx)


_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return value
        text = _text_of(value).strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        self.fail(f"{_text_of(value)!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param, ctx):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(_text_of(value).strip())
        except ValueError:
            self.fail(f"{_text_of(value)!r} is not a valid UUID value.", param, ctx)


class UnprocessedParamType(ParamType):
    """Pass-through: the raw token is delivered unchanged."""

    name = "text"

    def convert(self, value, param, ctx):
        return value


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()

_PY_TYPE_MAP = {str: STRING, int: INT, float: FLOAT, bool: BOOL, uuid.UUID: UUID}


class FuncParamType(ParamType):
    """A conversion function ``f(token) -> value`` that refuses by raising ValueError."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text") or "text"

    def convert(self, value, param, ctx):
        try:
            return self.func(value)
        except ValueError as exc:
            self.fail(str(exc) or f"{_text_of(value)!r} is not a valid value.", param, ctx)


# spec: N-000348, N-000937 (CF-000163: case-sensitive by default)
class Choice(ParamType):
    """A closed list of values, or the member names of an enumeration (spec: section 5, FP-05)."""

    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        self.case_sensitive = case_sensitive
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.enum_type = choices
            self.choices = [member.name for member in choices]
            self._originals = list(choices)
        else:
            self.enum_type = None
            self.choices = list(choices)
            self._originals = list(choices)

    def _key(self, text):
        return text if self.case_sensitive else text.casefold()

    def convert(self, value, param, ctx):
        if self.enum_type is not None and isinstance(value, self.enum_type):
            return value
        if not self.enum_type and not isinstance(value, str) and value in self._originals:
            return value
        token = _text_of(value)
        normalize = getattr(ctx, "token_normalize_func", None) if ctx is not None else None
        wanted = normalize(token) if normalize is not None else token
        for index, text in enumerate(self.choices):
            candidate = str(text)
            if normalize is not None:
                candidate = normalize(candidate)
            if self._key(candidate) == self._key(wanted):
                return self._originals[index]
        self.fail(
            f"{token!r} is not one of " + ", ".join(repr(str(c)) for c in self.choices) + ".",
            param,
            ctx,
        )

    def get_metavar(self, param):
        return "[" + "|".join(str(c) for c in self.choices) + "]"

    def shell_complete(self, ctx, param, incomplete):
        out = []
        for text in self.choices:
            if self._key(str(text)).startswith(self._key(incomplete)):
                out.append(CompletionItem(str(text)))
        return out


_DEFAULT_DATETIME_FORMATS = ["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]


# spec: N-000354, N-000938, N-000939 (CF-000158, CF-000136)
class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(_DEFAULT_DATETIME_FORMATS)

    def convert(self, value, param, ctx):
        if isinstance(value, _dt.datetime):
            return value
        text = _text_of(value).strip()
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(text, fmt)
            except ValueError:
                continue
        self.fail(f"{text!r} does not match the formats {', '.join(repr(f) for f in self.formats)}.",
                  param, ctx)


class _RangeMixin:
    def _check_bounds(self, min_v, max_v, min_open, max_open, clamp):
        if min_v is not None and max_v is not None and min_v > max_v:
            raise OptlynDeclarationError("min must not be greater than max")
        if clamp and (min_open or max_open) and self.kind == "float":
            raise OptlynDeclarationError("clamp is not allowed with an open bound on a float range")

    def _range_text(self):
        lo = "" if self.min is None else (f"{'>' if self.min_open else '>='}{self.min}")
        hi = "" if self.max is None else (f"{'<' if self.max_open else '<='}{self.max}")
        return " and ".join(part for part in (lo, hi) if part) or "any value"

    def _apply(self, number, param, ctx, original):
        if self.min is not None:
            below = number <= self.min if self.min_open else number < self.min
            if below:
                if self.clamp:
                    return (self.min + 1) if (self.min_open and self.kind == "int") else self.min
                self.fail(f"{original} is not in the valid range of {self._range_text()}.", param, ctx)
        if self.max is not None:
            above = number >= self.max if self.max_open else number > self.max
            if above:
                if self.clamp:
                    return (self.max - 1) if (self.max_open and self.kind == "int") else self.max
                self.fail(f"{original} is not in the valid range of {self._range_text()}.", param, ctx)
        return number


# spec: N-000361, N-000362, N-000364, N-000941 (CF-000016, CF-000092)
class IntRange(_RangeMixin, IntParamType):
    name = "integer range"
    kind = "int"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min, self.max = min, max
        self.min_open, self.max_open = min_open, max_open
        self.clamp = clamp
        self._check_bounds(min, max, min_open, max_open, clamp)

    def convert(self, value, param, ctx):
        number = IntParamType.convert(self, value, param, ctx)
        return self._apply(number, param, ctx, _text_of(value))


# spec: N-000381, N-000943 (CF-000100, CF-000107)
class FloatRange(_RangeMixin, FloatParamType):
    name = "float range"
    kind = "float"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min, self.max = min, max
        self.min_open, self.max_open = min_open, max_open
        self.clamp = clamp
        self._check_bounds(min, max, min_open, max_open, clamp)

    def convert(self, value, param, ctx):
        number = FloatParamType.convert(self, value, param, ctx)
        return self._apply(number, param, ctx, _text_of(value))


def _as_type(item):
    if isinstance(item, ParamType):
        return item
    if isinstance(item, type) and item in _PY_TYPE_MAP:
        return _PY_TYPE_MAP[item]
    if isinstance(item, type) and issubclass(item, ParamType):
        return item()
    return make_param_type(item)


# spec: N-000944
class Tuple(ParamType):
    """A fixed-length product of inner types (spec: section 5)."""

    name = "tuple"
    is_composite = True

    def __init__(self, types):
        self.types = [_as_type(t) for t in types]
        if not self.types:
            raise OptlynDeclarationError("Tuple needs at least one type")

    def convert(self, value, param, ctx):
        if isinstance(value, (str, bytes)) or not hasattr(value, "__len__"):
            self.fail("needs a sequence of values.", param, ctx)
        if len(value) != len(self.types):
            self.fail(f"takes {len(self.types)} values but {len(value)} were given.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))

    def get_metavar(self, param):
        return " ".join((t.name or "text").upper() for t in self.types)


class _SplitPathMixin:
    envvar_splitter = os.pathsep


class File(_SplitPathMixin, ParamType):
    """Opens a file; the value is an open file object (spec: FP-09)."""

    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise OptlynDeclarationError(f"unsupported file mode {mode!r}")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def convert(self, value, param, ctx):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        filename = _text_of(value)
        lazy = self.lazy
        if lazy is None:
            lazy = "w" in self.mode and filename != "-"
        try:
            handle = open_file(filename, self.mode, self.encoding, self.errors, lazy, self.atomic)
        except OSError as exc:
            self.fail(f"Could not open file '{filename}': {exc.strerror or exc}", param, ctx)
        except Exception as exc:  # FileError from open_file
            hint = getattr(exc, "hint", str(exc))
            self.fail(f"Could not open file '{filename}': {hint}", param, ctx)
        if ctx is not None:
            ctx.call_on_close(handle.close)
        return handle

    def shell_complete(self, ctx, param, incomplete):
        return [CompletionItem(incomplete, type="file")]


# spec: N-000558, N-000947 (CF-000160: no tilde expansion)
class Path(_SplitPathMixin, ParamType):
    """Validates a filesystem path and returns it (spec: FP-09)."""

    name = "path"

    def __init__(self, exists=False, file_okay=True, dir_okay=True, writable=False, readable=True,
                 resolve_path=False, allow_dash=False, path_type=None, executable=False):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def _deliver(self, text):
        if self.path_type is None or self.path_type is str:
            return text
        if self.path_type is pathlib.Path:
            return pathlib.Path(text)
        return self.path_type(text)

    def convert(self, value, param, ctx):
        text = _text_of(value)
        if self.allow_dash and text == "-":
            return self._deliver("-")
        rv = text
        if self.resolve_path:
            rv = os.path.realpath(rv)
        if not os.path.exists(rv):
            if self.exists:
                self.fail(f"{text!r} does not exist.", param, ctx)
            return self._deliver(rv)
        if os.path.isdir(rv):
            if not self.dir_okay:
                self.fail(f"{text!r} is a directory.", param, ctx)
        elif not self.file_okay:
            self.fail(f"{text!r} is a file.", param, ctx)
        if self.readable and not os.access(rv, os.R_OK):
            self.fail(f"{text!r} is not readable.", param, ctx)
        if self.writable and not os.access(rv, os.W_OK):
            self.fail(f"{text!r} is not writable.", param, ctx)
        if self.executable and not os.access(rv, os.X_OK):
            self.fail(f"{text!r} is not executable.", param, ctx)
        return self._deliver(rv)

    def shell_complete(self, ctx, param, incomplete):
        kind = "dir" if (self.dir_okay and not self.file_okay) else "file"
        return [CompletionItem(incomplete, type=kind)]


def make_param_type(ty, default=None, is_flag=False, flag_value=True):
    """Resolve a ``type=`` argument (or infer one) into a ParamType instance."""
    if ty is None:
        if is_flag:
            return BOOL if isinstance(flag_value, bool) else STRING
        sample = default
        if callable(sample) and not isinstance(sample, (list, tuple)):
            return STRING
        if isinstance(sample, (list, tuple)):
            sample = sample[0] if sample else None
        if isinstance(sample, bool):
            return BOOL
        if isinstance(sample, int):
            return INT
        if isinstance(sample, float):
            return FLOAT
        return STRING  # UUID is never inferred from a default (FP-05)
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, type):
        if ty in _PY_TYPE_MAP:
            return _PY_TYPE_MAP[ty]
        if issubclass(ty, ParamType):
            return ty()
    if callable(ty):
        return FuncParamType(ty)
    raise OptlynDeclarationError(f"unsupported parameter type {ty!r}")
