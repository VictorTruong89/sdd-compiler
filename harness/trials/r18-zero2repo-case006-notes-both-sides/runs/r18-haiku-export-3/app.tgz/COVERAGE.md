# Spec coverage

Every id in `spec/CHECKLIST.md` (1044 ids), with its state. Ids are grouped by pack; each
pack entry names where the behaviour lives and which tests exercise it. Statuses:
`tested` (implemented and exercised by the suite), `implemented` (implemented; not fully
exercised by the suite), `not done` (with the reason). Conflicts and the chosen reading are in `NOTES.md`.

## Pack 01 — 01-hardware-requirements--hardware-requirements.md

No checklist ids (context only).

## Pack 02 — 02-hardware-requirements--summary.md
ids: N-000775–N-000779 (5)
- status: implemented
- where: pyproject.toml (zero dependencies, requires-python >=3.10, src layout)
- tests: tests/test_package.py::test_N_000794_zero_runtime_dependencies_declared

## Pack 03 — 03-hardware-requirements--execution-profiles.md
ids: N-000780–N-000789 (10)
- status: implemented
- where: pyproject.toml; pager and styling use only the standard library (termui.py)
- tests: tests/test_package.py

## Pack 04 — 04-interface-contract--interface-contract.md
ids: N-000790–N-000790 (1)
- status: implemented
- where: form choices recorded in NOTES.md
- tests: -

## Pack 05 — 05-interface-contract--1-package-and-modules.md
ids: N-000791–N-000802 (12)
- status: tested
- where: __init__.py (names), testing.py, formatting.py
- tests: tests/test_package.py

## Pack 06 — 06-interface-contract--2-global-output-forms.md
ids: N-000803–N-000849 (47)
- status: tested
- where: exceptions.py (statuses 0/1/2), core.py (Command.main, Command.get_help), termui.py (channels), decorators.py (version/help)
- tests: tests/test_commands_and_groups.py (help, version); tests/test_completion_and_main.py (exit statuses, channels)

## Pack 07 — 07-interface-contract--3-declaring-commands-and-groups.md
ids: N-000850–N-000880 (31)
- status: tested
- where: core.py (Command, Group, CommandCollection), decorators.py (command, group)
- tests: tests/test_commands_and_groups.py

## Pack 08 — 08-interface-contract--4-parameters.md
ids: N-000881–N-000935 (55)
- status: tested
- where: core.py (Parameter, Option, Argument, delivered values), decorators.py (option, argument, ready-made options)
- tests: tests/test_parameters.py

## Pack 09 — 09-interface-contract--5-parameter-types.md
ids: N-000936–N-000949 (14)
- status: tested
- where: paramtypes.py (built-in and custom types, Choice, DateTime, ranges, Tuple, File, Path)
- tests: tests/test_parameters.py (types)

## Pack 10 — 10-interface-contract--6-invocation-context.md
ids: N-000950–N-000980 (31)
- status: tested
- where: core.py (Context, get_parameter_source, invoke/forward, resources), decorators.py (pass_context, pass_obj, make_pass_decorator), _context.py
- tests: tests/test_terminal_and_runner.py (context); tests/test_parameters.py (sources)

## Pack 11 — 11-interface-contract--7-terminal-helpers.md
ids: N-000981–N-001012 (32)
- status: implemented
- where: termui.py, utils.py (echo, styles, prompts, pager, progress bar, pause, clear, edit, launch, app dir, filenames)
- tests: tests/test_terminal_and_runner.py; getchar, edit and launch are implemented but need a real terminal or desktop, so they are not exercised by the suite

## Pack 12 — 12-interface-contract--8-shell-completion.md
ids: N-001013–N-001037 (25)
- status: implemented
- where: shell_completion.py (bash, zsh, fish, powershell scripts and suggestion protocol)
- tests: tests/test_completion_and_main.py; bash checked end to end with a real shell; zsh, fish and powershell scripts are generated and checked for protocol output only

## Pack 13 — 13-interface-contract--9-in-process-runner-optlyn-testing-cliru.md
ids: N-001038–N-001044 (7)
- status: tested
- where: testing.py (CliRunner, Result, isolated_filesystem)
- tests: tests/test_terminal_and_runner.py

## Pack 14 — 14-full-prd--product-overview.md
ids: N-000001–N-000014 (14)
- status: implemented
- where: core.py (nesting, help, lazy subcommand lookup through list_commands/get_command)
- tests: tests/test_commands_and_groups.py

## Pack 15 — 15-full-prd--terminology.md
ids: N-000015–N-000024 (10)
- status: implemented
- where: terminology is realised by the classes in core.py; interactive-session reading is recorded in NOTES.md
- tests: -

## Pack 16 — 16-full-prd--public-surface-inventory.md
ids: N-000025–N-000044 (20)
- status: tested
- where: public surface in __init__.py, testing.py, formatting.py
- tests: tests/test_package.py

## Pack 17 — 17-full-prd--non-functional-constraints.md
ids: N-000045–N-000069 (25)
- status: implemented
- where: pure Python; threading via _context.py (thread-local); Windows argument expansion in utils.expand_windows_args (applied only on Windows, not run on Windows here)
- tests: tests/test_package.py::test_N_000051_windows_argument_expansion_helper; tests/test_terminal_and_runner.py (threads)

## Pack 18 — 18-full-prd--non-goals.md
ids: N-000070–N-000078 (9)
- status: implemented
- where: non-goals are not built; the one related requirement (custom groups resolve names) is implemented
- tests: tests/test_commands_and_groups.py::test_FP06_list_commands_and_get_command_override
- N-000070: not done: non-goal (general-purpose argument parser unrelated to dispatch)
- N-000071: not done: non-goal (help-page layout redesign; wording is customisable, layout is not)
- N-000072: not done: non-goal (remote server, GUI or web framework)
- N-000073: implemented by absence: no built-in aliases or plugin discovery ships; custom groups resolve names through list_commands/get_command (tests/test_commands_and_groups.py::test_FP06_list_commands_and_get_command_override)
- N-000074: implemented by absence: same as N-000073
- N-000075: implemented by absence: no configuration syntax; default_map accepts any mapping the author loads
- N-000076: implemented by absence: same as N-000075
- N-000077: not done: non-goal (thread-safe mutation of an invocation context)
- N-000078: not done: non-goal (guaranteed colour on every Windows console)

## Pack 19 — 19-full-prd--fp-01-command-declaration-naming-and-inv.md
ids: N-000079–N-000109 (31)
- status: tested
- where: core.py (Command naming, invocation, deprecation, extra arguments), decorators.py (command)
- tests: tests/test_commands_and_groups.py; tests/test_completion_and_main.py

## Pack 20 — 20-full-prd--fp-02-automatic-help-pages-and-eager-doc.md
ids: N-000110–N-000177 (68)
- status: tested
- where: core.py (Command.get_help, Option.help_record, Group.get_help), formatting.py (wrapping, short help)
- tests: tests/test_commands_and_groups.py (help)

## Pack 21 — 21-full-prd--fp-03-options.md
ids: N-000178–N-000284 (107)
- status: tested
- where: core.py (Option, _scan_leaf, _apply_option, _process_params, Option.resolve, env and default-map lookup)
- tests: tests/test_parameters.py; tests/test_edge_behaviour.py

## Pack 22 — 22-full-prd--fp-04-positional-arguments.md
ids: N-000285–N-000329 (45)
- status: tested
- where: core.py (Argument, _assign_arguments, Argument.resolve)
- tests: tests/test_parameters.py (arguments)

## Pack 23 — 23-full-prd--fp-05-parameter-types-and-conversion.md
ids: N-000330–N-000383 (54)
- status: tested
- where: paramtypes.py
- tests: tests/test_parameters.py (types)

## Pack 24 — 24-full-prd--fp-06-groups-nesting-and-deferred-subcom.md
ids: N-000384–N-000433 (50)
- status: tested
- where: core.py (Group dispatch, nesting, lazy lookup, CommandCollection)
- tests: tests/test_commands_and_groups.py (groups)

## Pack 25 — 25-full-prd--fp-07-invocation-context-defaults-enviro.md
ids: N-000434–N-000483 (50)
- status: tested
- where: core.py (Context, default map, env prefix, sources), _context.py
- tests: tests/test_parameters.py (FP-07 tests); tests/test_terminal_and_runner.py

## Pack 26 — 26-full-prd--fp-08-prompts-confirmation-and-hidden-in.md
ids: N-000484–N-000527 (44)
- status: tested
- where: termui.py (prompt, confirm, password, confirmation), decorators.py (password_option, confirmation_option), core.py (prompt resolution)
- tests: tests/test_parameters.py (prompts)

## Pack 27 — 27-full-prd--fp-09-file-and-path-parameters.md
ids: N-000528–N-000590 (63)
- status: tested
- where: utils.py (open_file, LazyFile, atomic writes, format_filename), paramtypes.py (File, Path)
- tests: tests/test_parameters.py (files and paths)

## Pack 28 — 28-full-prd--fp-10-command-chaining-and-pipelines.md
ids: N-000591–N-000617 (27)
- status: tested
- where: core.py (Group chain mode, result callback, child file closing)
- tests: tests/test_commands_and_groups.py (chain); tests/test_edge_behaviour.py

## Pack 29 — 29-full-prd--fp-11-terminal-output-and-interaction-he.md
ids: N-000618–N-000688 (71)
- status: implemented
- where: termui.py, utils.py, formatting.py
- tests: tests/test_terminal_and_runner.py

## Pack 30 — 30-full-prd--fp-12-shell-completion.md
ids: N-000689–N-000715 (27)
- status: implemented
- where: shell_completion.py
- tests: tests/test_completion_and_main.py; tests/test_edge_behaviour.py

## Pack 31 — 31-full-prd--fp-13-usage-failures-abort-and-exit-stat.md
ids: N-000716–N-000735 (20)
- status: tested
- where: exceptions.py, core.py (main: exit statuses, abort, usage errors)
- tests: tests/test_completion_and_main.py (FP-13); tests/test_commands_and_groups.py

## Pack 32 — 32-full-prd--fp-14-in-process-runner.md
ids: N-000736–N-000763 (28)
- status: tested
- where: testing.py (CliRunner, capture modes, isolated filesystem)
- tests: tests/test_terminal_and_runner.py

## Pack 33 — 33-full-prd--cross-cutting-refinements.md
ids: N-000764–N-000774 (11)
- status: tested
- where: cross-cutting behaviours in core.py and termui.py
- tests: tests/test_commands_and_groups.py (help vs usage exit codes); tests/test_parameters.py (hidden names, prompts vs defaults); tests/test_completion_and_main.py

## Totals

- implemented: 224
- tested: 815
- not done: 5
- total checklist ids: 1044
