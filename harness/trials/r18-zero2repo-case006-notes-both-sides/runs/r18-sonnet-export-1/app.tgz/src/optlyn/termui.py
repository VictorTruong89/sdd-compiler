import contextlib
import inspect
import itertools
import math
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
import time

from . import _compat
from .exceptions import Abort, UsageError
from .globals import resolve_color_default
from .types import Choice, convert_type
from .utils import echo, get_app_dir  # noqa: F401  (re-exported)

visible_prompt_func = input
hidden_prompt_func = None
_getchar = None


def _hidden(prompt):
    import getpass
    return getpass.getpass(prompt)


class _ColorError(TypeError, ValueError):
    pass


_ansi_colors = {
    "black": 30, "red": 31, "green": 32, "yellow": 33, "blue": 34, "magenta": 35, "cyan": 36,
    "white": 37, "reset": 39, "bright_black": 90, "bright_red": 91, "bright_green": 92,
    "bright_yellow": 93, "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96,
    "bright_white": 97,
}
_ansi_reset_all = "\033[0m"


def _interpret_color(color, offset=0):
    if isinstance(color, bool):
        raise _ColorError(f"Unknown color {color!r}")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise _ColorError(f"Color {color!r} out of range 0-255")
        return f"{38 + offset};5;{color:d}"
    if isinstance(color, (tuple, list)):
        if len(color) != 3 or not all(isinstance(c, int) and not isinstance(c, bool)
                                      and 0 <= c <= 255 for c in color):
            raise _ColorError(f"Invalid RGB color {color!r}")
        r, g, b = color
        return f"{38 + offset};2;{r:d};{g:d};{b:d}"
    if isinstance(color, str) and color in _ansi_colors:
        return str(_ansi_colors[color] + offset)
    raise _ColorError(f"Unknown color {color!r}")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None, italic=None,
          blink=None, reverse=None, strikethrough=None, reset=True):
    if not isinstance(text, str):
        text = str(text)
    bits = []
    if fg is not None:
        bits.append(f"\033[{_interpret_color(fg)}m")
    if bg is not None:
        bits.append(f"\033[{_interpret_color(bg, 10)}m")
    for flag, on, off in ((bold, 1, 22), (dim, 2, 22), (underline, 4, 24), (overline, 53, 55),
                          (italic, 3, 23), (blink, 5, 25), (reverse, 7, 27),
                          (strikethrough, 9, 29)):
        if flag is not None:
            bits.append(f"\033[{on if flag else off}m")
    bits.append(text)
    if reset:
        bits.append(_ansi_reset_all)
    return "".join(bits)


def unstyle(text):
    return _compat.strip_ansi(text)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None and not isinstance(message, (bytes, bytearray)):
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def is_interactive():
    return _compat.isatty(sys.stdin) or _compat.isatty(sys.stdout)


# ---------------------------------------------------------------- prompts

def _build_prompt(text, suffix, show_default=False, default=None, show_choices=True, type=None):
    prompt = text
    if type is not None and show_choices and isinstance(type, Choice):
        prompt += f" ({', '.join(map(str, type.choices))})"
    if default is not None and show_default:
        if hasattr(default, "name") and hasattr(default, "read"):
            default = default.name
        prompt = f"{prompt} [{default}]"
    return f"{prompt}{suffix}"


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False, show_choices=True):
    def prompt_func(text):
        f = (hidden_prompt_func or _hidden) if hide_input else visible_prompt_func
        try:
            echo(text.rstrip(" "), nl=False, err=err)
            return f(" ")
        except (KeyboardInterrupt, EOFError):
            if hide_input:
                echo(None, err=err)
            raise Abort() from None

    if value_proc is None:
        value_proc = convert_type(type, default)

    pr = _build_prompt(text, prompt_suffix, show_default, default, show_choices, type)
    if confirmation_prompt:
        if confirmation_prompt is True:
            confirmation_prompt = "Repeat for confirmation"
        confirmation_prompt = _build_prompt(confirmation_prompt, prompt_suffix)

    while True:
        while True:
            value = prompt_func(pr)
            if value:
                break
            elif default is not None:
                value = default
                break
        try:
            result = value_proc(value)
        except UsageError as e:
            if hide_input:
                echo("Error: The value you entered was invalid.", err=err)
            else:
                echo(f"Error: {e.message}", err=err)
            continue
        if not confirmation_prompt:
            return result
        while True:
            value2 = prompt_func(confirmation_prompt)
            is_empty = not value and not value2
            if value2 or is_empty:
                break
        if value == value2:
            return result
        echo("Error: The two entered values do not match.", err=err)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    pr = _build_prompt(text, prompt_suffix, show_default,
                       "y/n" if default is None else ("Y/n" if default else "y/N"))
    while True:
        try:
            echo(pr.rstrip(" "), nl=False, err=err)
            value = visible_prompt_func(" ").lower().strip()
        except (KeyboardInterrupt, EOFError):
            raise Abort() from None
        if value in ("y", "yes"):
            rv = True
        elif value in ("n", "no"):
            rv = False
        elif default is not None and value == "":
            rv = default
        else:
            echo("Error: invalid input", err=err)
            continue
        break
    if abort and not rv:
        raise Abort()
    return rv


# ---------------------------------------------------------------- pager

class _PagerFile:
    def __init__(self, write, flush=None):
        self._write = write
        self._flush = flush

    def write(self, s):
        if isinstance(s, bytes):
            s = s.decode("utf-8", "replace")
        self._write(s)
        return len(s)

    def writelines(self, lines):
        for ln in lines:
            self.write(ln)

    def flush(self):
        if self._flush:
            self._flush()

    def isatty(self):
        return False


@contextlib.contextmanager
def get_pager_file(color=None):
    color = resolve_color_default(color)
    pager_cmd = os.environ.get("PAGER", "").strip()
    if not is_interactive() or not pager_cmd:
        out = sys.stdout

        def w(s):
            echo(s, file=out, nl=False, color=color)

        yield _PagerFile(w, lambda: out.flush())
        return
    proc = subprocess.Popen(pager_cmd, shell=True, stdin=subprocess.PIPE)
    enc = getattr(sys.stdout, "encoding", None) or "utf-8"

    def w(s):
        if not color:
            s = _compat.strip_ansi(s)
        try:
            proc.stdin.write(s.encode(enc, "replace"))
            proc.stdin.flush()
        except (OSError, ValueError):
            pass

    try:
        yield _PagerFile(w, lambda: proc.stdin.flush())
    finally:
        try:
            proc.stdin.close()
        except OSError:
            pass
        while True:
            try:
                proc.wait()
                break
            except KeyboardInterrupt:
                pass


def echo_via_pager(text_or_generator, color=None):
    if inspect.isgeneratorfunction(text_or_generator) or (
            callable(text_or_generator) and not isinstance(text_or_generator, str)):
        i = text_or_generator()
    elif isinstance(text_or_generator, str):
        i = [text_or_generator]
    else:
        i = iter(text_or_generator)
    if isinstance(i, str):
        i = [i]
    with get_pager_file(color) as f:
        for el in itertools.chain((el if isinstance(el, str) else str(el) for el in i), "\n"):
            f.write(el)
            f.flush()


# ---------------------------------------------------------------- progress

class ProgressBar:
    def __init__(self, iterable=None, length=None, label=None, hidden=False, show_eta=True,
                 show_percent=None, show_pos=False, item_show_func=None, fill_char="#",
                 empty_char="-", bar_template="%(label)s  [%(bar)s]  %(info)s", info_sep="  ",
                 width=36, file=None, color=None, update_min_steps=1):
        if iterable is None:
            if length is None:
                raise TypeError("iterable or length is required")
            iterable = range(length)
        self.iter = iter(iterable)
        if length is None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.show_eta = show_eta
        self.show_percent = show_percent if show_percent is not None else length is not None
        self.show_pos = show_pos
        self.item_show_func = item_show_func
        self.fill_char = fill_char
        self.empty_char = empty_char
        self.bar_template = bar_template
        self.info_sep = info_sep
        self.width = width
        self.file = file
        self.color = color
        self.pos = 0
        self.finished = False
        self.current_item = None
        self.start = self.last_eta = time.time()
        self._last_line = None
        self._printed = False
        self._rendered = False

    def _stream(self):
        return self.file if self.file is not None else sys.stdout

    def __enter__(self):
        self.start = self.last_eta = time.time()
        self.render_progress()
        return self

    def __exit__(self, *a):
        self.render_finish()

    def __iter__(self):
        return self._iter()

    def _iter(self):
        self.render_progress()
        for rv in self.iter:
            self.current_item = rv
            yield rv
            self.update(1)
        self.finish()
        self.render_progress()

    def __next__(self):
        raise TypeError("use iter()")

    @property
    def pct(self):
        if self.finished:
            return 1.0
        if not self.length:
            return 0.0
        return min(self.pos / self.length, 1.0)

    @property
    def time_per_iteration(self):
        elapsed = time.time() - self.start
        return elapsed / self.pos if self.pos else 0.0

    @property
    def eta(self):
        if self.length is not None and not self.finished:
            return self.time_per_iteration * (self.length - self.pos)
        return 0.0

    def format_eta(self):
        if self.length is None or self.finished:
            return ""
        t = int(self.eta)
        seconds = t % 60
        t //= 60
        minutes = t % 60
        t //= 60
        hours = t % 24
        t //= 24
        if t > 0:
            return f"{t}d {hours:02}:{minutes:02}:{seconds:02}"
        return f"{hours:02}:{minutes:02}:{seconds:02}"

    def format_pct(self):
        return f"{int(self.pct * 100): 4}%"[1:]

    def format_progress_line(self):
        parts = []
        if self.show_pos:
            parts.append(f"{self.pos}/{self.length}" if self.length is not None else str(self.pos))
        if self.show_percent:
            parts.append(self.format_pct())
        if self.show_eta and self.pos:
            eta = self.format_eta()
            if eta:
                parts.append(eta)
        if self.item_show_func is not None:
            item = self.item_show_func(self.current_item)
            if item:
                parts.append(item)
        info = self.info_sep.join(p for p in parts if p)
        if self.length is not None:
            bar_len = int(self.pct * self.width)
            bar = self.fill_char * bar_len + self.empty_char * (self.width - bar_len)
        else:
            bar = self.empty_char * self.width
        return (self.bar_template % {"label": self.label, "bar": bar, "info": info}).rstrip()

    def render_progress(self):
        if self.hidden:
            return
        stream = self._stream()
        if not _compat.isatty(stream):
            if self.label and self._last_line != self.label:
                self._last_line = self.label
                echo(self.label, file=stream, color=self.color)
            return
        line = self.format_progress_line()
        if line != self._last_line:
            self._last_line = line
            echo("\r" + line, file=stream, nl=False, color=self.color)
            self._rendered = True

    def render_finish(self):
        if self.hidden or not _compat.isatty(self._stream()):
            return
        if self._rendered:
            echo(file=self._stream())

    def update(self, n_steps=1, current_item=None):
        self.pos += n_steps
        if self.length is not None and self.pos >= self.length:
            self.finished = True
        if current_item is not None:
            self.current_item = current_item
        self.render_progress()

    def finish(self):
        self.pos = self.length if self.length is not None else self.pos
        self.finished = True


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)


# ---------------------------------------------------------------- misc

def _unix_getchar(echo_):
    fd = None
    f = None
    try:
        import termios
        import tty
        if _compat.isatty(sys.stdin):
            f = None
            fd = sys.stdin.fileno()
        else:
            f = open("/dev/tty")
            fd = f.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 32).decode(getattr(sys.stdin, "encoding", None) or "utf-8", "replace")
            if echo_ and _compat.isatty(sys.stdout):
                sys.stdout.write(ch)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
            sys.stdout.flush()
            if f is not None:
                f.close()
    except ImportError:
        ch = sys.stdin.read(1)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    return ch


def getchar(echo=False):  # noqa: F811 - parameter shadows helper by design
    global _getchar
    if _getchar is None:
        _getchar = _unix_getchar
    return _getchar(echo)


def pause(info=None, err=False):
    if info is None:
        info = "Press any key to continue..."
    if not (_compat.isatty(sys.stdin) and _compat.isatty(sys.stdout)):
        if info:
            echo(info, err=err)
        return
    try:
        if info:
            echo(info, nl=False, err=err)
        try:
            getchar()
        except (KeyboardInterrupt, EOFError):
            pass
    finally:
        if info:
            echo(err=err)


def clear():
    if not _compat.isatty(sys.stdout):
        return
    echo("\033[2J\033[1;1H", nl=False)


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    if editor is None:
        editor = os.environ.get("VISUAL") or os.environ.get("EDITOR")
        if not editor:
            editor = "vi"
    environ = None
    if env:
        environ = os.environ.copy()
        environ.update(env)

    def run(path):
        try:
            c = subprocess.Popen(f"{editor} {shlex.quote(path)}", env=environ, shell=True)
            exit_code = c.wait()
        except OSError as e:
            raise RuntimeError(f"{editor}: Editing failed: {e}") from e
        if exit_code != 0:
            raise RuntimeError(f"{editor}: Editing failed")

    if filename is not None:
        run(filename)
        return None
    if text is None:
        text = ""
    data = text.encode("utf-8") if isinstance(text, str) else text
    fd, name = tempfile.mkstemp(prefix="editor-", suffix=extension)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        before = os.stat(name)
        run(name)
        after = os.stat(name)
        with open(name, "rb") as f:
            rv = f.read()
        if require_save and before.st_mtime_ns == after.st_mtime_ns and rv == data:
            return None
        return rv.decode("utf-8").replace("\r\n", "\n")
    finally:
        try:
            os.unlink(name)
        except OSError:
            pass


def launch(url, wait=False, locate=False):
    if locate:
        p = str(url)
        if p.startswith("file://"):
            p = p[7:]
        url = os.path.dirname(p) or "."
    opener = shutil.which("xdg-open") or "xdg-open"
    try:
        c = subprocess.Popen([opener, str(url)])
        return c.wait() if True else 0
    except OSError:
        return 127
