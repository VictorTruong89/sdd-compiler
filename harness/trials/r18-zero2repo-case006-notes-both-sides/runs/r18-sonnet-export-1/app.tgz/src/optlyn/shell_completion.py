import os
import re
import shlex
import sys

from .core import Argument, Command, Group, Option, Parameter


class CompletionItem:
    __slots__ = ("value", "type", "help", "_info")

    def __init__(self, value, type="plain", help=None, **kwargs):
        self.value = value
        self.type = type
        self.help = help
        self._info = kwargs

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        return self._info.get(name)


_SOURCE_BASH = r"""
%(complete_func)s() {
    local IFS=$'\n'
    local response
    response=$(env COMP_WORDS="${COMP_WORDS[*]}" COMP_CWORD=$COMP_CWORD %(complete_var)s=bash_complete $1)
    for completion in $response; do
        IFS=',' read type value <<< "$completion"
        if [[ $type == 'dir' ]]; then
            COMPREPLY=()
            compopt -o dirnames
        elif [[ $type == 'file' ]]; then
            COMPREPLY=()
            compopt -o default
        elif [[ $type == 'plain' ]]; then
            COMPREPLY+=($value)
        fi
    done
    return 0
}

%(complete_func)s_setup() {
    complete -o nosort -F %(complete_func)s %(prog_name)s
}

%(complete_func)s_setup;
"""

_SOURCE_ZSH = r"""#compdef %(prog_name)s

%(complete_func)s() {
    local -a completions
    local -a completions_with_descriptions
    local -a response
    (( ! $+commands[%(prog_name)s] )) && return 1

    response=("${(@f)$(env COMP_WORDS="${words[*]}" COMP_CWORD=$((CURRENT-1)) %(complete_var)s=zsh_complete %(prog_name)s)}")

    for type key descr in ${response}; do
        if [[ "$type" == "plain" ]]; then
            if [[ "$descr" == "_" ]]; then
                completions+=("$key")
            else
                completions_with_descriptions+=("$key":"$descr")
            fi
        elif [[ "$type" == "dir" ]]; then
            _path_files -/
        elif [[ "$type" == "file" ]]; then
            _path_files -f
        fi
    done

    if [ -n "$completions_with_descriptions" ]; then
        _describe -V unsorted completions_with_descriptions -U
    fi

    if [ -n "$completions" ]; then
        compadd -U -V unsorted -a completions
    fi
}

if [[ $zsh_eval_context[-1] == loadautofunc ]]; then
    %(complete_func)s "$@"
else
    compdef %(complete_func)s %(prog_name)s
fi
"""

_SOURCE_FISH = r"""
function %(complete_func)s;
    set -l response (env %(complete_var)s=fish_complete COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -t) %(prog_name)s);

    for completion in $response;
        set -l metadata (string split "," $completion);

        if test $metadata[1] = "dir";
            __fish_complete_directories $metadata[2];
        else if test $metadata[1] = "file";
            __fish_complete_path $metadata[2];
        else if test $metadata[1] = "plain";
            echo $metadata[2];
        end;
    end;
end;

complete --no-files --command %(prog_name)s --arguments "(%(complete_func)s)";
"""

_SOURCE_POWERSHELL = r"""
Register-ArgumentCompleter -Native -CommandName %(prog_name)s -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)
    $env:COMP_WORDS = $commandAst.ToString()
    $env:COMP_CWORD = ($commandAst.CommandElements.Count - $(if ($wordToComplete -eq '') { 0 } else { 1 }))
    $env:%(complete_var)s = "powershell_complete"
    & %(prog_name)s | ForEach-Object {
        $type, $value = $_ -split ',', 2
        if ($type -eq 'plain') {
            [System.Management.Automation.CompletionResult]::new($value, $value, 'ParameterValue', $value)
        }
    }
    Remove-Item Env:%(complete_var)s
}
"""

_SOURCES = {"bash": _SOURCE_BASH, "zsh": _SOURCE_ZSH, "fish": _SOURCE_FISH,
            "powershell": _SOURCE_POWERSHELL}


def _func_name(prog_name):
    safe = re.sub(r"\W*", "", prog_name.replace("-", "_"), flags=re.ASCII)
    return f"_{safe}_completion"


def get_source(shell, prog_name, complete_var):
    return _SOURCES[shell] % {"complete_func": _func_name(prog_name), "prog_name": prog_name,
                              "complete_var": complete_var}


def split_arg_string(string):
    lex = shlex.shlex(string, posix=True)
    lex.whitespace_split = True
    lex.commenters = ""
    out = []
    try:
        for token in lex:
            out.append(token)
    except ValueError:
        out.extend(lex.instream.read().split() if False else [lex.token] if lex.token else [])
    return out


def format_item(shell, item):
    h = item.help
    if shell == "zsh":
        return f"{item.type}\n{item.value}\n{h if h else '_'}"
    if shell == "fish":
        return f"{item.type},{item.value}\t{h}" if h else f"{item.type},{item.value}"
    return f"{item.type},{item.value}"


def _is_incomplete_argument(ctx, param):
    if not isinstance(param, Argument):
        return False
    value = ctx.params.get(param.name)
    return param.nargs == -1 or ctx.get_parameter_source(param.name) is None or (
        param.nargs > 1 and isinstance(value, (tuple, list)) and len(value) < param.nargs)


def _start_of_option(ctx, value):
    if not value:
        return False
    c = value[0]
    return c in ctx._opt_prefixes


def _is_incomplete_option(ctx, args, param):
    if not isinstance(param, Option):
        return False
    if param.is_flag or param.count:
        return False
    last_option = None
    for index, arg in enumerate(reversed(args)):
        if index + 1 > param.nargs:
            break
        if _start_of_option(ctx, arg):
            last_option = arg
            break
    return last_option is not None and last_option in {*param.opts, *param.secondary_opts}


def _resolve_context(cli, ctx_args, prog_name, args):
    ctx_args = dict(ctx_args)
    ctx_args["resilient_parsing"] = True
    ctx = cli.make_context(prog_name, list(args), **ctx_args)
    args = ctx.protected_args + ctx.args
    while args:
        command = ctx.command
        if isinstance(command, Group):
            if not command.chain:
                name, cmd, args = command.resolve_command(ctx, args)
                if cmd is None:
                    return ctx
                ctx = cmd.make_context(name, args, parent=ctx, resilient_parsing=True)
                args = ctx.protected_args + ctx.args
            else:
                sub_ctx = ctx
                while args:
                    name, cmd, args = command.resolve_command(ctx, args)
                    if cmd is None:
                        return ctx
                    sub_ctx = cmd.make_context(name, args, parent=ctx, allow_extra_args=True,
                                               allow_interspersed_args=False,
                                               resilient_parsing=True)
                    args = sub_ctx.args
                ctx = sub_ctx
                args = [*sub_ctx.protected_args, *sub_ctx.args]
        else:
            break
    return ctx


def _resolve_incomplete(ctx, args, incomplete):
    if "=" in incomplete:
        name, _, incomplete = incomplete.partition("=")
        args.append(name)
    if "--" in args:
        return ctx.command, incomplete
    params = ctx.command.get_params(ctx)
    for param in params:
        if _is_incomplete_option(ctx, args, param):
            return param, incomplete
    for param in params:
        if _is_incomplete_argument(ctx, param):
            return param, incomplete
    return ctx.command, incomplete


def get_completions(cli, ctx_args, prog_name, args, incomplete):
    try:
        ctx = _resolve_context(cli, ctx_args, prog_name, args)
    except Exception:
        return []
    obj, incomplete = _resolve_incomplete(ctx, list(args), incomplete)
    try:
        if isinstance(obj, Parameter):
            return obj.shell_complete(ctx, incomplete)
        return obj.shell_complete(ctx, incomplete)
    except Exception:
        return []


def shell_complete(cli, ctx_args, prog_name, complete_var, instruction):
    shell, _, instr = instruction.partition("_")
    if shell not in _SOURCES or instr not in ("source", "complete"):
        print(f"Completion instruction {instruction!r} is not supported.", file=sys.stderr)
        return 1
    if instr == "source":
        sys.stdout.write(get_source(shell, prog_name, complete_var))
        sys.stdout.flush()
        return 0
    words = split_arg_string(os.environ.get("COMP_WORDS", ""))
    cword_raw = os.environ.get("COMP_CWORD", "")
    if shell == "fish":
        args = words[1:]
        incomplete = cword_raw
        if args and incomplete and args[-1] == incomplete:
            args = args[:-1]
    else:
        try:
            cword = int(cword_raw)
        except ValueError:
            cword = len(words)
        args = words[1:cword]
        try:
            incomplete = words[cword]
        except IndexError:
            incomplete = ""
    items = get_completions(cli, ctx_args, prog_name, args, incomplete)
    out = "\n".join(format_item(shell, i) for i in items)
    sys.stdout.write(out)
    sys.stdout.flush()
    return 0
