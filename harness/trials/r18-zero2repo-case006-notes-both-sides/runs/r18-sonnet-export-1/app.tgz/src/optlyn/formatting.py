import textwrap
from contextlib import contextmanager

FORCED_WIDTH = None


def measure_table(rows):
    widths = {}
    for row in rows:
        for idx, col in enumerate(row):
            widths[idx] = max(widths.get(idx, 0), term_len(col))
    return tuple(y for x, y in sorted(widths.items()))


def iter_rows(rows, col_count):
    for row in rows:
        yield tuple(row) + ("",) * (col_count - len(row))


def term_len(x):
    from ._compat import strip_ansi
    return len(strip_ansi(x))


class TextWrapper(textwrap.TextWrapper):
    def _handle_long_word(self, reversed_chunks, cur_line, cur_len, width):
        space_left = max(width - cur_len, 1)
        if self.break_long_words:
            last = reversed_chunks[-1]
            cut = last[:space_left]
            res = last[space_left:]
            cur_line.append(cut)
            reversed_chunks[-1] = res
        elif not cur_line:
            cur_line.append(reversed_chunks.pop())

    @contextmanager
    def extra_indent(self, indent):
        old_initial = self.initial_indent
        old_subsequent = self.subsequent_indent
        self.initial_indent += indent
        self.subsequent_indent += indent
        try:
            yield
        finally:
            self.initial_indent = old_initial
            self.subsequent_indent = old_subsequent

    def indent_only(self, text):
        rv = []
        for idx, line in enumerate(text.splitlines()):
            indent = self.initial_indent
            if idx > 0:
                indent = self.subsequent_indent
            rv.append(f"{indent}{line}")
        return "\n".join(rv)


def wrap_text(text, width=78, initial_indent="", subsequent_indent="", preserve_paragraphs=False):
    text = str(text).expandtabs()
    wrapper = TextWrapper(width, initial_indent=initial_indent, subsequent_indent=subsequent_indent,
                          replace_whitespace=False)
    if not preserve_paragraphs:
        return wrapper.fill(text)
    p = []
    buf = []
    indent = None

    def _flush_par():
        if not buf:
            return
        if buf[0].strip() == "\b":
            p.append((indent or 0, True, "\n".join(buf[1:])))
        else:
            p.append((indent or 0, False, " ".join(buf)))
        del buf[:]

    for line in text.splitlines():
        if not line:
            _flush_par()
            indent = None
        else:
            if indent is None:
                orig_len = term_len(line)
                line = line.lstrip()
                indent = orig_len - term_len(line)
            buf.append(line)
    _flush_par()
    rv = []
    for indent, raw, t in p:
        with wrapper.extra_indent(" " * indent):
            if raw:
                rv.append(wrapper.indent_only(t))
            else:
                rv.append(wrapper.fill(t))
    return "\n\n".join(rv)


class HelpFormatter:
    def __init__(self, indent_increment=2, width=None, max_width=None):
        import shutil
        self.indent_increment = indent_increment
        if max_width is None:
            max_width = 80
        if width is None:
            width = FORCED_WIDTH
            if width is None:
                width = max(min(shutil.get_terminal_size().columns, max_width) - 2, 50)
        self.width = width
        self.current_indent = 0
        self.buffer = []

    def write(self, string):
        self.buffer.append(string)

    def indent(self):
        self.current_indent += self.indent_increment

    def dedent(self):
        self.current_indent -= self.indent_increment

    def write_usage(self, prog, args="", prefix="Usage: "):
        usage_prefix = f"{prefix:>{self.current_indent}}{prog} "
        text_width = self.width - self.current_indent
        if text_width >= (term_len(usage_prefix) + 20):
            indent = " " * term_len(usage_prefix)
            self.write(wrap_text(args, text_width, initial_indent=usage_prefix,
                                 subsequent_indent=indent))
        else:
            self.write(usage_prefix)
            self.write("\n")
            indent = " " * (max(self.current_indent, term_len(prefix)) + 4)
            self.write(wrap_text(args, text_width, initial_indent=indent, subsequent_indent=indent))
        self.write("\n")

    def write_heading(self, heading):
        self.write(f"{'':>{self.current_indent}}{heading}:\n")

    def write_paragraph(self):
        if self.buffer:
            self.write("\n")

    def write_text(self, text):
        indent = " " * self.current_indent
        self.write(wrap_text(text, self.width, initial_indent=indent, subsequent_indent=indent,
                             preserve_paragraphs=True))
        self.write("\n")

    def write_dl(self, rows, col_max=30, col_spacing=2):
        rows = list(rows)
        widths = measure_table(rows)
        if len(widths) != 2:
            raise TypeError("Expected two columns for definition list")
        first_col = min(widths[0], col_max) + col_spacing
        for first, second in iter_rows(rows, len(widths)):
            self.write(f"{'':>{self.current_indent}}{first}")
            if not second:
                self.write("\n")
                continue
            if term_len(first) <= first_col - col_spacing:
                self.write(" " * (first_col - term_len(first)))
            else:
                self.write("\n")
                self.write(" " * (first_col + self.current_indent))
            text_width = max(self.width - first_col - 2, 10)
            wrapped = wrap_text(second, text_width, preserve_paragraphs=True)
            lines = wrapped.splitlines()
            if lines:
                self.write(f"{lines[0]}\n")
                for line in lines[1:]:
                    self.write(f"{'':>{first_col + self.current_indent}}{line}\n")
            else:
                self.write("\n")

    @contextmanager
    def section(self, name):
        self.write_paragraph()
        self.write_heading(name)
        self.indent()
        try:
            yield
        finally:
            self.dedent()

    @contextmanager
    def indentation(self):
        self.indent()
        try:
            yield
        finally:
            self.dedent()

    def getvalue(self):
        return "".join(self.buffer)


def join_options(options):
    rv = []
    any_prefix_is_slash = False
    for opt in options:
        prefix = split_opt(opt)[0]
        if prefix == "/":
            any_prefix_is_slash = True
        rv.append((len(prefix), opt))
    rv.sort(key=lambda x: x[0])
    return ", ".join(x[1] for x in rv), any_prefix_is_slash


def split_opt(opt):
    first = opt[:1]
    if first.isalnum():
        return "", opt
    if opt[1:2] == first:
        return opt[:2], opt[2:]
    return first, opt[1:]


def make_default_short_help(help, max_length=45):
    paragraph_end = help.find("\n\n")
    if paragraph_end != -1:
        help = help[:paragraph_end]
    words = help.split()
    if not words:
        return ""
    if words[0] == "\b":
        words = words[1:]
        if not words:
            return ""
    total_length = 0
    last_index = len(words) - 1
    i = 0
    for i, word in enumerate(words):
        total_length += len(word) + (i > 0)
        if total_length > max_length:
            break
        if word[-1] == ".":
            return " ".join(words[: i + 1])
        if total_length == max_length and i != last_index:
            break
    else:
        return " ".join(words)
    total_length += len("...")
    while i > 0:
        total_length -= len(words[i]) + (i > 0)
        if total_length <= max_length:
            break
        i -= 1
    return " ".join(words[:i]) + "..."
