import io
import re
import sys

_ansi_re = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")


def strip_ansi(value):
    return _ansi_re.sub("", value)


def isatty(stream):
    try:
        return bool(stream.isatty())
    except Exception:
        return False


def is_ascii_encoding(enc):
    if not enc:
        return False
    try:
        import codecs
        return codecs.lookup(enc).name == "ascii"
    except LookupError:
        return False


def should_strip_ansi(stream=None, color=None):
    if color is None:
        if stream is None:
            stream = sys.stdin
        return not isatty(stream)
    return not color


class NonClosingTextIOWrapper(io.TextIOWrapper):
    """Text wrapper that never closes the wrapped buffer."""

    def close(self):
        try:
            self.flush()
        except Exception:
            pass

    def __del__(self):
        pass


def _wrap_binary(buf, encoding, errors, write):
    if write:
        try:
            sys.stdout.flush()
        except Exception:
            pass
    return NonClosingTextIOWrapper(buf, encoding=encoding or "utf-8", errors=errors or "strict",
                                   write_through=True)


def get_binary_stream(name):
    stream = getattr(sys, name, None)
    if stream is None:
        raise RuntimeError(f"The standard stream {name!r} is not available.")
    return getattr(stream, "buffer", stream)


def get_text_stream(name, encoding=None, errors="strict"):
    stream = getattr(sys, name, None)
    if stream is None:
        raise RuntimeError(f"The standard stream {name!r} is not available.")
    if encoding is None:
        return stream
    buf = getattr(stream, "buffer", None)
    if buf is None:
        return stream
    return _wrap_binary(buf, encoding, errors, name != "stdin")
