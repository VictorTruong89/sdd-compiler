import os
import re
import sys
import tempfile

from . import _compat
from .exceptions import FileError
from .globals import resolve_color_default


def safecall(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception:
            pass
    return wrapper


def make_str(value):
    if isinstance(value, bytes):
        try:
            return value.decode(sys.getfilesystemencoding())
        except UnicodeError:
            return value.decode("utf-8", "replace")
    return str(value)


def echo(message=None, file=None, nl=True, err=False, color=None):
    if file is None:
        file = sys.stderr if err else sys.stdout
    if file is None:
        return
    if message is not None and not isinstance(message, (str, bytes, bytearray)):
        out = str(message)
    else:
        out = message
    if nl:
        out = out or ""
        if isinstance(out, str):
            out += "\n"
        else:
            out += b"\n"
    if not out:
        try:
            file.flush()
        except Exception:
            pass
        return
    if isinstance(out, (bytes, bytearray)):
        binary = getattr(file, "buffer", None)
        try:
            file.flush()
        except Exception:
            pass
        target = binary if binary is not None else file
        try:
            target.write(bytes(out))
        except TypeError:
            file.write(bytes(out).decode("utf-8", "replace"))
        try:
            target.flush()
        except Exception:
            pass
        return
    color = resolve_color_default(color)
    if _compat.should_strip_ansi(file, color):
        out = _compat.strip_ansi(out)
    enc = getattr(file, "encoding", None)
    buf = getattr(file, "buffer", None)
    if buf is not None and _compat.is_ascii_encoding(enc):
        try:
            file.flush()
        except Exception:
            pass
        buf.write(out.encode("utf-8"))
        try:
            buf.flush()
        except Exception:
            pass
        return
    try:
        file.write(out)
    except UnicodeEncodeError:
        if buf is None:
            file.write(out.encode("ascii", "replace").decode("ascii"))
        else:
            file.flush()
            buf.write(out.encode("utf-8"))
            buf.flush()
    try:
        file.flush()
    except Exception:
        pass


def get_binary_stream(name):
    return _compat.get_binary_stream(name)


def get_text_stream(name, encoding=None, errors="strict"):
    return _compat.get_text_stream(name, encoding, errors)


def format_filename(filename, shorten=False):
    if shorten:
        filename = os.path.basename(filename)
    else:
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        filename = filename.decode(sys.getfilesystemencoding(), "replace")
    else:
        filename = filename.encode("utf-8", "surrogateescape").decode("utf-8", "replace")
    return filename


def _posixify(name):
    return "-".join(name.split()).lower()


def get_app_dir(app_name, roaming=True, force_posix=False):
    if sys.platform.startswith("win") and not force_posix:
        key = "APPDATA" if roaming else "LOCALAPPDATA"
        folder = os.environ.get(key) or os.path.expanduser("~")
        return os.path.join(folder, app_name)
    if force_posix:
        return os.path.join(os.path.expanduser(f"~/.{_posixify(app_name)}"))
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~/Library/Application Support"), app_name)
    return os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config"),
                        _posixify(app_name))


class KeepOpenFile:
    def __init__(self, file):
        self._file = file

    def __getattr__(self, name):
        return getattr(self._file, name)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        pass

    def __repr__(self):
        return repr(self._file)

    def __iter__(self):
        return iter(self._file)


class _AtomicFile:
    def __init__(self, f, tmp_filename, real_filename):
        self._f = f
        self._tmp_filename = tmp_filename
        self._real_filename = real_filename
        self.closed = False

    @property
    def name(self):
        return self._real_filename

    def close(self, delete=False):
        if self.closed:
            return
        self._f.close()
        os.replace(self._tmp_filename, self._real_filename)
        self.closed = True

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, *a):
        self.close(delete=exc_type is not None)

    def __repr__(self):
        return repr(self._f)

    def __iter__(self):
        return iter(self._f)


def open_stream(filename, mode="r", encoding=None, errors="strict", atomic=False):
    binary = "b" in mode
    filename = os.fspath(filename)
    if filename in ("-", b"-"):
        if any(m in mode for m in ("w", "a", "x")):
            if binary:
                return _compat.get_binary_stream("stdout"), False
            return _compat.get_text_stream("stdout", encoding, errors), False
        if binary:
            return _compat.get_binary_stream("stdin"), False
        return _compat.get_text_stream("stdin", encoding, errors), False
    if not atomic:
        kw = {} if binary else {"encoding": encoding, "errors": errors}
        return open(filename, mode, **kw), True
    if "r" in mode or "x" in mode or "a" in mode:
        raise ValueError("Atomic writes only make sense with 'w' mode.")
    flags = os.O_RDWR | os.O_CREAT | os.O_EXCL
    if binary:
        flags |= getattr(os, "O_BINARY", 0)
    dirn = os.path.dirname(os.path.abspath(filename))
    fd, tmp = tempfile.mkstemp(dir=dirn, prefix=".__atomic-write")
    kw = {} if binary else {"encoding": encoding, "errors": errors}
    f = open(fd, mode, **kw)
    return _AtomicFile(f, tmp, os.path.abspath(filename)), True


class LazyFile:
    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False):
        self.name = os.fspath(filename)
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self.should_close = True
        if self.name == "-":
            self._f, self.should_close = open_stream(filename, mode, encoding, errors)
        elif "r" in mode:
            # Open and close the file in case we're opening it for reading so that we can catch at least some errors in some cases early.
            open(filename, mode).close()

    def __getattr__(self, name):
        return getattr(self.open(), name)

    def __repr__(self):
        if self._f is not None:
            return repr(self._f)
        return f"<unopened file '{format_filename(self.name)}' {self.mode}>"

    def open(self):
        if self._f is not None:
            return self._f
        try:
            rv, self.should_close = open_stream(self.name, self.mode, self.encoding, self.errors,
                                                atomic=self.atomic)
        except OSError as e:
            raise FileError(self.name, hint=e.strerror) from e
        self._f = rv
        return rv

    def close(self):
        if self._f is not None:
            self._f.close()

    def close_intelligently(self):
        if self.should_close:
            self.close()

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close_intelligently()

    def __iter__(self):
        self.open()
        return iter(self._f)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    f, should_close = open_stream(filename, mode, encoding, errors, atomic=atomic)
    if not should_close:
        f = KeepOpenFile(f)
    return f
