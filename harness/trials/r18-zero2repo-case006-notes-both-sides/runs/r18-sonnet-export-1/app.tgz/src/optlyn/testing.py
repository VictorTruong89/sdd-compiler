import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile

from . import _compat, formatting, termui
from .utils import echo  # noqa: F401


class EchoingStdin:
    def __init__(self, input, output):
        self._input = input
        self._output = output
        self._paused = False

    def __getattr__(self, x):
        return getattr(self._input, x)

    def _echo(self, rv):
        if not self._paused:
            self._output.write(rv)
        return rv

    def read(self, n=-1):
        return self._echo(self._input.read(n))

    def read1(self, n=-1):
        return self._echo(self._input.read1(n))

    def readline(self, n=-1):
        return self._echo(self._input.readline(n))

    def readlines(self):
        return [self._echo(x) for x in self._input.readlines()]

    def __iter__(self):
        return iter(self._echo(x) for x in self._input)

    def __repr__(self):
        return repr(self._input)


@contextlib.contextmanager
def _pause_echo(stream):
    if stream is None:
        yield
    else:
        stream._paused = True
        try:
            yield
        finally:
            stream._paused = False


class BytesIOCopy(io.BytesIO):
    def __init__(self, copy_to):
        super().__init__()
        self.copy_to = copy_to

    def flush(self):
        super().flush()
        self.copy_to.flush()

    def write(self, b):
        self.copy_to.write(b)
        return super().write(b)


class _NamedTextIOWrapper(io.TextIOWrapper):
    def __init__(self, buffer, name=None, mode=None, **kwargs):
        super().__init__(buffer, **kwargs)
        self._name = name
        self._mode = mode

    @property
    def name(self):
        return self._name

    @property
    def mode(self):
        return self._mode


def make_input_stream(input, charset):
    if hasattr(input, "read"):
        rv = input
        if isinstance(rv.read(0), str):
            raise TypeError("input stream must be binary")
    elif input is None:
        rv = io.BytesIO(b"")
    else:
        if isinstance(input, str):
            input = input.encode(charset)
        rv = io.BytesIO(input)
    return rv


class _FdRaw(io.RawIOBase):
    def __init__(self, fd, copy_to):
        self._fd = fd
        self._copy = copy_to
        self.total = 0

    def fileno(self):
        return self._fd

    def writable(self):
        return True

    def write(self, b):
        b = bytes(b)
        os.write(self._fd, b)
        self._copy.write(b)
        self.total += len(b)
        return len(b)


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value, exit_code,
                 exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    def _dec(self, b):
        return b.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def output(self):
        return self._dec(self.output_bytes)

    @property
    def stdout(self):
        return self._dec(self.stdout_bytes)

    @property
    def stderr(self):
        return self._dec(self.stderr_bytes)

    def __repr__(self):
        exc = repr(self.exception) if self.exception else "okay"
        return f"<Result {exc}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def make_env(self, overrides=None):
        rv = dict(self.env)
        if overrides:
            rv.update(overrides)
        return rv

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        bytes_input = make_input_stream(input, self.charset)
        echo_input = None
        old_stdin, old_stdout, old_stderr = sys.stdin, sys.stdout, sys.stderr
        old_forced_width = formatting.FORCED_WIDTH
        formatting.FORCED_WIDTH = 80
        env = self.make_env(env)

        bytes_output = io.BytesIO()
        fd_state = None
        if self.capture == "fd":
            out_file = tempfile.TemporaryFile()
            err_file = tempfile.TemporaryFile()
            old_fds = (os.dup(1), os.dup(2))
            try:
                old_stdout.flush()
                old_stderr.flush()
            except Exception:
                pass
            os.dup2(out_file.fileno(), 1)
            os.dup2(err_file.fileno(), 2)
            raw_out = _FdRaw(1, bytes_output)
            raw_err = _FdRaw(2, bytes_output)
            stdout = _NamedTextIOWrapper(io.BufferedWriter(raw_out), name="<stdout>", mode="w",
                                         encoding=self.charset, write_through=True)
            stderr = _NamedTextIOWrapper(io.BufferedWriter(raw_err), name="<stderr>", mode="w",
                                         encoding=self.charset, errors="backslashreplace",
                                         write_through=True)
            fd_state = (out_file, err_file, old_fds, raw_out, raw_err)
            stdout_bytes_getter = None
        else:
            stdout_buf = BytesIOCopy(copy_to=bytes_output)
            stderr_buf = BytesIOCopy(copy_to=bytes_output)
            stdout = _NamedTextIOWrapper(stdout_buf, encoding=self.charset, name="<stdout>",
                                         mode="w")
            stderr = _NamedTextIOWrapper(stderr_buf, encoding=self.charset, name="<stderr>",
                                         mode="w", errors="backslashreplace")
        if self.echo_stdin:
            bytes_input = echo_input = EchoingStdin(bytes_input, stdout.buffer if fd_state is None
                                                    else stdout.buffer)
        sys.stdin = text_input = _NamedTextIOWrapper(bytes_input, encoding=self.charset,
                                                     name="<stdin>", mode="r")
        if self.echo_stdin:
            text_input._CHUNK_SIZE = 1
        sys.stdout = stdout
        sys.stderr = stderr

        def visible_input(prompt=None):
            with _pause_echo(echo_input):
                sys.stdout.write(prompt or "")
                try:
                    val = next(text_input).rstrip("\r\n")
                except StopIteration as e:
                    raise EOFError() from e
                sys.stdout.write(f"{val}\n")
                sys.stdout.flush()
            return val

        def hidden_input(prompt=None):
            with _pause_echo(echo_input):
                sys.stdout.write(f"{prompt or ''}\n")
                sys.stdout.flush()
                try:
                    return next(text_input).rstrip("\r\n")
                except StopIteration as e:
                    raise EOFError() from e

        def _getchar(echo_):
            char = sys.stdin.read(1)
            if echo_:
                sys.stdout.write(char)
            sys.stdout.flush()
            return char

        default_color = color

        def should_strip_ansi(stream=None, color=None):
            if color is None:
                return not default_color
            return not color

        old = (termui.visible_prompt_func, termui.hidden_prompt_func, termui._getchar,
               _compat.should_strip_ansi)
        termui.visible_prompt_func = visible_input
        termui.hidden_prompt_func = hidden_input
        termui._getchar = _getchar
        _compat.should_strip_ansi = should_strip_ansi

        old_env = {}
        try:
            for key, value in env.items():
                old_env[key] = os.environ.get(key)
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            if fd_state is None:
                yield (stdout_buf, stderr_buf, bytes_output)
            else:
                yield fd_state
        finally:
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            (termui.visible_prompt_func, termui.hidden_prompt_func, termui._getchar,
             _compat.should_strip_ansi) = old
            try:
                stdout.flush()
                stderr.flush()
            except Exception:
                pass
            if fd_state is not None:
                out_file, err_file, old_fds, raw_out, raw_err = fd_state
                os.dup2(old_fds[0], 1)
                os.dup2(old_fds[1], 2)
                os.close(old_fds[0])
                os.close(old_fds[1])
            sys.stdout, sys.stderr, sys.stdin = old_stdout, old_stderr, old_stdin
            formatting.FORCED_WIDTH = old_forced_width

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False,
               **extra):
        exc_info = None
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        with self.isolation(input=input, env=env, color=color) as outstreams:
            return_value = None
            exception = None
            exit_code = 0
            if isinstance(args, str):
                args = shlex.split(args)
            try:
                prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
                return_value = cli.main(args=args or (), prog_name=prog_name, **extra)
            except SystemExit as e:
                exc_info = sys.exc_info()
                e_code = e.code
                if e_code is None:
                    e_code = 0
                if e_code != 0:
                    exception = e
                if not isinstance(e_code, int):
                    sys.stdout.write(str(e_code))
                    sys.stdout.write("\n")
                    e_code = 1
                exit_code = e_code
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                sys.stdout.flush()
                sys.stderr.flush()
                if self.capture == "fd":
                    out_file, err_file, _old, raw_out, raw_err = outstreams
                    out_file.seek(0)
                    err_file.seek(0)
                    stdout = out_file.read()
                    stderr = err_file.read()
                    output = bytes(outstreams_output(raw_out, raw_err, stdout, stderr))
                else:
                    stdout = outstreams[0].getvalue()
                    stderr = outstreams[1].getvalue()
                    output = outstreams[2].getvalue()
        return Result(runner=self, stdout_bytes=stdout, stderr_bytes=stderr, output_bytes=output,
                      return_value=return_value, exit_code=exit_code, exception=exception,
                      exc_info=exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass


def outstreams_output(raw_out, raw_err, stdout, stderr):
    """Combined output for fd capture: interpreter writes first, then other OS-level writes."""
    copy = raw_out._copy.getvalue()
    extra_out = stdout[raw_out.total:] if len(stdout) > raw_out.total else b""
    extra_err = stderr[raw_err.total:] if len(stderr) > raw_err.total else b""
    return copy + extra_out + extra_err
