from optlyn import command, option, echo, Choice
from optlyn.testing import CliRunner


def test_basic_option_and_choice():
    @command()
    @option("--ch", type=Choice(["a", "b"]))
    @option("--count", type=int, default=1)
    def cli(ch, count):
        echo(f"{ch} {count}")

    r = CliRunner()
    assert r.invoke(cli, ["--ch", "a", "--count", "3"]).output == "a 3\n"
    assert r.invoke(cli, ["--ch", "z"]).exit_code == 2
