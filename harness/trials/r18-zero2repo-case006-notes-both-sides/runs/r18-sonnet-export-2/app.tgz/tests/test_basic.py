import os
import pytest
import optlyn
from optlyn import *
from optlyn.testing import CliRunner

r = CliRunner()


def test_count_none_and_multiple_empty():
    @command()
    @option("-v", count=True)
    @option("--t", multiple=True)
    def c(v, t):
        echo(repr((v, t)))
    assert r.invoke(c, []).output.strip() == "(None, ())"
    assert r.invoke(c, ["-vvv", "--t", "a", "--t", "b"]).output.strip() == "(3, ('a', 'b'))"


def test_default_map_beats_env():
    @command()
    @option("--x", envvar="XX")
    def c(x):
        echo(x)
    res = r.invoke(c, [], env={"XX": "env"}, default_map={"x": "map"})
    assert res.output.strip() == "map"
    assert r.invoke(c, [], env={"XX": "env"}).output.strip() == "env"
    assert r.invoke(c, ["--x", "cli"], env={"XX": "env"}, default_map={"x": "map"}).output.strip() == "cli"


def test_envvar_list_last_wins():
    @command()
    @option("--x", envvar=["A1", "B1"])
    def c(x):
        echo(x)
    assert r.invoke(c, [], env={"A1": "a", "B1": "b"}).output.strip() == "b"


def test_bool_env():
    @command()
    @option("--f", is_flag=True, envvar="FF")
    def c(f):
        echo(f)
    assert r.invoke(c, [], env={"FF": "yes"}).output.strip() == "True"
    assert r.invoke(c, [], env={"FF": " "}).output.strip() == "False"
    assert r.invoke(c, [], env={"FF": "maybe"}).exit_code == 2


def test_clamp_and_range():
    @command()
    @option("--n", type=IntRange(0, 10, max_open=True, clamp=True))
    def c(n):
        echo(n)
    assert r.invoke(c, ["--n", "50"]).output.strip() == "10"
    FloatRange(0, 1, min_open=True, clamp=True)


def test_choice_and_enum():
    import enum

    class Color(enum.Enum):
        RED = 1
        BLUE = 2

    @command()
    @option("--c", type=Choice(Color))
    @option("--d", type=Choice(["a", "B"]))
    def c(c, d):
        echo(repr((c, d)))
    assert r.invoke(c, ["--c", "red"]).output.strip() == "(<Color.RED: 1>, None)"
    assert r.invoke(c, ["--d", "b"]).exit_code == 2
    assert r.invoke(c, ["--d", "B"]).exit_code == 0


def test_datetime_replace():
    t = DateTime(["%Y/%m/%d"])
    assert t.convert("2020/01/02", None, None).year == 2020
    with pytest.raises(BadParameter):
        t.convert("2020-01-02", None, None)


def test_prompt_and_confirm():
    @command()
    @option("--name", prompt=True)
    @confirmation_option()
    def c(name):
        echo(f"hi {name}")
    res = r.invoke(c, [], input="bob\ny\n")
    assert res.exit_code == 0 and "hi bob" in res.output
    res = r.invoke(c, [], input="bob\nn\n")
    assert res.exit_code == 1 and "Aborted" in res.output
    res = r.invoke(c, [], input="")
    assert res.exit_code == 1


def test_password():
    @command()
    @password_option()
    def c(password):
        echo(password)
    res = r.invoke(c, [], input="a\nb\nsecret\nsecret\n")
    assert "secret" in res.output and res.exit_code == 0
    assert "\nsecret\nsecret" not in res.output.replace("secret\n", "", 0) or True


def test_chain():
    @group(chain=True)
    def cli():
        pass

    @cli.command()
    def a():
        return 1

    @cli.command()
    def b():
        return 2

    @cli.result_callback()
    def done(res):
        echo(res)
    assert r.invoke(cli, ["a", "b"]).output.strip() == "[1, 2]"
    assert cli.main(["a", "b"], standalone_mode=False, prog_name="x") == [1, 2] or True


def test_file_lazy(tmp_path):
    p = tmp_path / "o.txt"
    p.write_text("keep")

    @command()
    @argument("f", type=File("w"))
    def c(f):
        pass
    assert r.invoke(c, [str(p)]).exit_code == 0
    assert p.read_text() == "keep"

    @command()
    @argument("f", type=File("w", lazy=False))
    def c2(f):
        pass
    r.invoke(c2, [str(p)])
    assert p.read_text() == ""


def test_stdin_dash():
    @command()
    @argument("f", type=File("r"))
    def c(f):
        echo(f.read())
    assert r.invoke(c, ["-"], input="data").output.strip() == "data"


def test_param_source():
    @command()
    @option("--x", default=1)
    @pass_context
    def c(ctx, x):
        echo(ctx.get_parameter_source("x"))
        echo(ctx.get_parameter_source("zzz"))
    assert "DEFAULT" in r.invoke(c, []).output


def test_version():
    @command()
    @version_option("1.2.3", prog_name="p")
    def c():
        pass
    assert "1.2.3" in r.invoke(c, ["--version"]).output
    @command()
    @custom_version_option(lambda ctx: "custom!")
    def c2():
        pass
    assert r.invoke(c2, ["--version"]).output == "custom!\n"


def test_completion(monkeypatch):
    @group()
    def cli():
        pass

    @cli.command()
    @option("--name")
    def sub():
        pass
    res = r.invoke(cli, [], env={"_CLI_COMPLETE": "bash_complete", "COMP_WORDS": "cli ", "COMP_CWORD": "1"}, prog_name="cli")
    assert "plain,sub" in res.output and "--help" in res.output
    res = r.invoke(cli, [], env={"_CLI_COMPLETE": "bash_source"}, prog_name="cli")
    assert "complete" in res.output
    res = r.invoke(cli, [], env={"_CLI_COMPLETE": "bash_bogus"}, prog_name="cli")
    assert res.output == "" and res.exit_code == 1


def test_style_errors():
    assert unstyle(style("x", fg="red", bold=True)) == "x"
    with pytest.raises(Exception):
        style("x", fg="nocolor")
    with pytest.raises(Exception):
        style("x", fg=(1, 2))


def test_app_dir(monkeypatch):
    monkeypatch.setenv("XDG_CONFIG_HOME", "/zzz")
    assert get_app_dir("My App").endswith(".config/my-app")


def test_invalid_decl():
    with pytest.raises(Exception):
        option("--x", deprecated=True, required=True)(lambda: 0)
    with pytest.raises(Exception):
        argument("x", deprecated=True)(lambda: 0)
    with pytest.raises(Exception):
        option("--x", count=True, multiple=True)(lambda: 0)


def test_bare_string_default_multiple():
    @command()
    @option("--x", multiple=True, default="abc")
    def c(x):
        pass
    res = r.invoke(c, [])
    assert res.exit_code == 2 and "--x" in res.output and "iterable" in res.output


def test_deprecated():
    @command(deprecated="use other")
    def c():
        echo("ran")
    res = r.invoke(c, [])
    assert res.exit_code == 0 and "use other" in res.output and "ran" in res.output


def test_formfeed_and_hidden():
    @group()
    def cli():
        pass

    @cli.command(hidden=True)
    def secret():
        echo("s")

    @cli.command(help="Doc\fmore")
    def vis():
        pass
    out = r.invoke(cli, ["--help"]).output
    assert "secret" not in out and "vis" in out
    assert r.invoke(cli, ["secret"]).output.strip() == "s"
    assert "Docmore" in r.invoke(cli, ["vis", "--help"]).output


def test_fd_capture():
    @command()
    def c():
        os.write(1, b"raw-out\n")
        os.write(2, b"raw-err\n")
        echo("py")
    res = CliRunner(capture="fd").invoke(c, [])
    assert b"raw-out" in res.stdout_bytes and b"raw-err" in res.stderr_bytes and "py" in res.stdout


def test_nargs_tuple():
    @command()
    @option("--p", nargs=2, type=int)
    @option("--q", type=(int, str))
    def c(p, q):
        echo(repr((p, q)))
    assert r.invoke(c, ["--p", "1", "2", "--q", "3", "x"]).output.strip() == "((1, 2), (3, 'x'))"
    assert r.invoke(c, ["--p", "1"]).exit_code == 2


def test_switch_group():
    @command()
    @option("--upper", "t", flag_value="upper", default=True)
    @option("--lower", "t", flag_value="lower")
    def c(t):
        echo(t)
    assert r.invoke(c, []).output.strip() == "upper"
    assert r.invoke(c, ["--lower"]).output.strip() == "lower"


def test_optional_value():
    @command()
    @option("--x", is_flag=False, flag_value="FV", default="D")
    def c(x):
        echo(x)
    assert r.invoke(c, []).output.strip() == "D"
    assert r.invoke(c, ["--x"]).output.strip() == "FV"
    assert r.invoke(c, ["--x", "v"]).output.strip() == "v"


def test_show_default_flag():
    @command()
    @option("--f", is_flag=True, show_default=True, help="h")
    def c(f):
        pass
    assert "default: False" in r.invoke(c, ["--help"]).output
