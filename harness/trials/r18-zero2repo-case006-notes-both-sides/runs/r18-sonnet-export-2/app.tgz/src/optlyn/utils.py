"""Utilities: echo, style, file helpers."""
import os
import sys
import types as _pytypes

from . import _compat
from ._compat import (get_binary_stderr, get_binary_stdin, get_binary_stdout,
                      get_text_stderr, get_text_stdin, get_text_stdout, isatty,
                      strip_ansi)
from .exceptions import DeclarationError, FileError
from .globals import resolve_color_default


def safecall(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception:
            pass
    return wrapper


def make_str(value):
    if isinstance(value, bytes):
        try:
            return value.decode(sys.getfilesystemencoding())
        except UnicodeError:
            return value.decode("utf-8", "replace")
    return str(value)


def _find_binary_writer(stream):
    buf = getattr(stream, "buffer", None)
    if buf is not None:
        return buf
    import io
    if isinstance(stream, (io.RawIOBase, io.BufferedIOBase)):
        return stream
    return None


def echo(message=None, file=None, nl=True, err=False, color=None):
    if file is None:
        file = get_text_stderr() if err else get_text_stdout()
        if file is None:
            return
    if message is not None and not isinstance(message, (str, bytes, bytearray)):
        out = str(message)
    else:
        out = message
    if nl:
        out = out or ""
        if isinstance(out, str):
            out += "\n"
        else:
            out += b"\n"
    if not out:
        file.flush()
        return
    if isinstance(out, (bytes, bytearray)):
        binary_file = _find_binary_writer(file)
        if binary_file is not None:
            file.flush()
            binary_file.write(out)
            binary_file.flush()
            return
        out = bytes(out).decode("utf-8", "replace")
    color = resolve_color_default(color)
    if _compat.should_strip_ansi(file, color):
        out = strip_ansi(out)
    file.write(out)
    file.flush()


_ansi_colors = {
    "black": 30, "red": 31, "green": 32, "yellow": 33, "blue": 34, "magenta": 35,
    "cyan": 36, "white": 37, "reset": 39,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
}
_ansi_reset_all = "\033[0m"


def _interpret_color(color, offset=0):
    if isinstance(color, bool):
        raise DeclarationError(f"Unknown color {color!r}")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise DeclarationError(f"Unknown color {color!r}")
        return f"{38 + offset};5;{color:d}"
    if isinstance(color, str):
        if color not in _ansi_colors:
            raise DeclarationError(f"Unknown color {color!r}")
        return str(_ansi_colors[color] + offset)
    try:
        r, g, b = color
        vals = (r, g, b)
        if len(tuple(color)) != 3:
            raise ValueError
    except (TypeError, ValueError):
        raise DeclarationError(f"Unknown color {color!r}") from None
    for v in vals:
        if isinstance(v, bool) or not isinstance(v, int) or not 0 <= v <= 255:
            raise DeclarationError(f"Unknown color {color!r}")
    return f"{38 + offset};2;{r:d};{g:d};{b:d}"


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True):
    if not isinstance(text, str):
        text = str(text)
    bits = []
    if fg is not None:
        bits.append(f"\033[{_interpret_color(fg)}m")
    if bg is not None:
        bits.append(f"\033[{_interpret_color(bg, 10)}m")
    if bold is not None:
        bits.append(f"\033[{1 if bold else 22}m")
    if dim is not None:
        bits.append(f"\033[{2 if dim else 22}m")
    if underline is not None:
        bits.append(f"\033[{4 if underline else 24}m")
    if overline is not None:
        bits.append(f"\033[{53 if overline else 55}m")
    if italic is not None:
        bits.append(f"\033[{3 if italic else 23}m")
    if blink is not None:
        bits.append(f"\033[{5 if blink else 25}m")
    if reverse is not None:
        bits.append(f"\033[{7 if reverse else 27}m")
    if strikethrough is not None:
        bits.append(f"\033[{9 if strikethrough else 29}m")
    bits.append(text)
    if reset:
        bits.append(_ansi_reset_all)
    return "".join(bits)


def unstyle(text):
    return strip_ansi(text)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None and not isinstance(message, (bytes, bytearray)):
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def format_filename(filename, shorten=False):
    if shorten:
        filename = os.path.basename(filename)
    else:
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        filename = filename.decode(sys.getfilesystemencoding(), "backslashreplace")
    else:
        filename = filename.encode("utf-8", "surrogateescape").decode("utf-8", "backslashreplace")
    return filename


def _posixify(name):
    return "-".join(name.split()).lower()


def get_app_dir(app_name, roaming=True, force_posix=False):
    if sys.platform.startswith("win"):
        key = "APPDATA" if roaming else "LOCALAPPDATA"
        folder = os.environ.get(key)
        if folder is None:
            folder = os.path.expanduser("~")
        return os.path.join(folder, app_name)
    if force_posix:
        return os.path.join(os.path.expanduser(f"~/.{_posixify(app_name)}"))
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~/Library/Application Support"), app_name)
    return os.path.join(os.path.expanduser("~/.config"), _posixify(app_name))


class _AtomicFile:
    def __init__(self, f, tmp_filename, real_filename):
        self._f = f
        self._tmp_filename = tmp_filename
        self._real_filename = real_filename
        self.closed = False

    @property
    def name(self):
        return self._real_filename

    def close(self, delete=False):
        if self.closed:
            return
        self._f.close()
        os.replace(self._tmp_filename, self._real_filename)
        self.closed = True

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.close(delete=exc_type is not None)

    def __repr__(self):
        return repr(self._f)


def open_stream(filename, mode="r", encoding=None, errors="strict", atomic=False):
    binary = "b" in mode
    filename = os.fspath(filename)
    if filename == "-":
        if any(m in mode for m in ["w", "a", "x"]):
            if binary:
                return get_binary_stdout(), False
            return get_text_stdout(encoding=encoding, errors=errors), False
        if binary:
            return get_binary_stdin(), False
        return get_text_stdin(encoding=encoding, errors=errors), False
    if not atomic:
        return open(filename, mode, encoding=encoding, errors=errors), True
    if "a" in mode:
        raise ValueError("Appending to an existing file is not supported, because that would involve an expensive `copy`-operation to a temporary file. Open the file in normal `w`-mode and copy explicitly if that's what you're after.")
    if "x" in mode:
        raise ValueError("Use the `overwrite`-parameter instead.")
    if "w" not in mode:
        raise ValueError("Atomic writes only make sense with `w`-mode.")
    import errno
    import random
    try:
        perm = os.stat(filename).st_mode
    except OSError:
        perm = None
    flags = os.O_RDWR | os.O_CREAT | os.O_EXCL
    if binary:
        flags |= getattr(os, "O_BINARY", 0)
    while True:
        tmp_filename = os.path.join(os.path.dirname(filename),
                                    f".__atomic-write{random.randrange(1 << 32):08x}")
        try:
            fd = os.open(tmp_filename, flags, 0o666 if perm is None else perm)
            break
        except OSError as e:
            if e.errno == errno.EEXIST:
                continue
            raise
    if perm is not None:
        os.chmod(tmp_filename, perm)
    f = open(fd, mode, encoding=encoding, errors=errors)
    return _AtomicFile(f, tmp_filename, os.path.realpath(filename)), True


class LazyFile:
    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False):
        self.name = os.fspath(filename)
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self.should_close = True
        if self.name == "-":
            self._f, self.should_close = open_stream(filename, mode, encoding, errors)
        elif "r" in mode:
            open(filename, mode).close()

    def __getattr__(self, name):
        return getattr(self.open(), name)

    def __repr__(self):
        if self._f is not None:
            return repr(self._f)
        return f"<unopened file '{format_filename(self.name)}' {self.mode}>"

    def open(self):
        if self._f is not None:
            return self._f
        try:
            rv, self.should_close = open_stream(self.name, self.mode, self.encoding,
                                                self.errors, atomic=self.atomic)
        except OSError as e:
            raise FileError(self.name, hint=e.strerror) from e
        self._f = rv
        return rv

    def close(self):
        if self._f is not None:
            self._f.close()

    def close_intelligently(self):
        if self.should_close:
            self.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.close_intelligently()

    def __iter__(self):
        self.open()
        return iter(self._f)


class KeepOpenFile:
    def __init__(self, file):
        self._file = file

    def __getattr__(self, name):
        return getattr(self._file, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        pass

    def __repr__(self):
        return repr(self._file)

    def __iter__(self):
        return iter(self._file)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    f, should_close = open_stream(filename, mode, encoding, errors, atomic=atomic)
    if not should_close:
        f = KeepOpenFile(f)
    return f


def get_binary_stream(name):
    opener = {"stdin": get_binary_stdin, "stdout": get_binary_stdout,
              "stderr": get_binary_stderr}.get(name)
    if opener is None:
        raise TypeError(f"Unknown standard stream '{name}'")
    return opener()


def get_text_stream(name, encoding=None, errors="strict"):
    opener = {"stdin": get_text_stdin, "stdout": get_text_stdout,
              "stderr": get_text_stderr}.get(name)
    if opener is None:
        raise TypeError(f"Unknown standard stream '{name}'")
    return opener(encoding, errors)
