"""Stream helpers."""
import codecs
import io
import re
import sys

_ansi_re = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")


def strip_ansi(value):
    return _ansi_re.sub("", value)


def term_len(x):
    return len(strip_ansi(x))


def isatty(stream):
    try:
        return stream.isatty()
    except Exception:
        return False


def should_strip_ansi(stream=None, color=None):
    if color is None:
        if stream is None:
            stream = sys.stdin
        return not isatty(stream)
    return not color


def _is_ascii_encoding(encoding):
    if not encoding:
        return False
    try:
        return codecs.lookup(encoding).name == "ascii"
    except LookupError:
        return False


class NonClosingTextIOWrapper(io.TextIOWrapper):
    def __del__(self):
        try:
            self.flush()
            self.detach()
        except Exception:
            pass

    def close(self):
        try:
            self.flush()
        except Exception:
            pass


def _wrap(stream, encoding, errors):
    buf = getattr(stream, "buffer", None)
    if buf is None:
        return stream
    try:
        stream.flush()
    except Exception:
        pass
    return NonClosingTextIOWrapper(buf, encoding=encoding, errors=errors,
                                   line_buffering=True)


def _text_stream(name, encoding=None, errors=None):
    stream = getattr(sys, name)
    if encoding is None:
        if _is_ascii_encoding(getattr(stream, "encoding", None)):
            return _wrap(stream, "utf-8", errors or "replace")
        if errors is None or errors == getattr(stream, "errors", None):
            return stream
        return _wrap(stream, getattr(stream, "encoding", None) or "utf-8", errors)
    return _wrap(stream, encoding, errors or "strict")


def get_text_stdin(encoding=None, errors=None):
    return _text_stream("stdin", encoding, errors)


def get_text_stdout(encoding=None, errors=None):
    return _text_stream("stdout", encoding, errors)


def get_text_stderr(encoding=None, errors=None):
    return _text_stream("stderr", encoding, errors)


def _binary(name):
    stream = getattr(sys, name)
    buf = getattr(stream, "buffer", None)
    if buf is None:
        raise RuntimeError(f"sys.{name} has no binary buffer")
    return buf


def get_binary_stdin():
    return _binary("stdin")


def get_binary_stdout():
    return _binary("stdout")


def get_binary_stderr():
    return _binary("stderr")


def get_best_encoding(stream):
    rv = getattr(stream, "encoding", None) or sys.getdefaultencoding()
    if _is_ascii_encoding(rv):
        return "utf-8"
    return rv
