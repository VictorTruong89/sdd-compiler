"""In-process runner."""
import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile

from . import _compat, formatting, termui, utils
from ._compat import strip_ansi


class EchoingStdin:
    def __init__(self, input, output):
        self._input = input
        self._output = output
        self._paused = False

    def __getattr__(self, x):
        return getattr(self._input, x)

    def _echo(self, rv):
        if not self._paused:
            self._output.write(rv)
        return rv

    def read(self, n=-1):
        return self._echo(self._input.read(n))

    def read1(self, n=-1):
        return self._echo(self._input.read1(n))

    def readline(self, n=-1):
        return self._echo(self._input.readline(n))

    def readlines(self):
        return [self._echo(x) for x in self._input.readlines()]

    def __iter__(self):
        return iter(self._echo(x) for x in self._input)

    def __repr__(self):
        return repr(self._input)


@contextlib.contextmanager
def _pause_echo(stream):
    if stream is None:
        yield
    else:
        stream._paused = True
        yield
        stream._paused = False


class _NamedTextIOWrapper(io.TextIOWrapper):
    def __init__(self, buffer, name=None, mode=None, **kwargs):
        super().__init__(buffer, **kwargs)
        self._name = name
        self._mode = mode

    @property
    def name(self):
        return self._name

    @property
    def mode(self):
        return self._mode


def make_input_stream(input, charset):
    if hasattr(input, "read"):
        rv = input.read()
        if isinstance(rv, str):
            rv = rv.encode(charset)
        return io.BytesIO(rv)
    if input is None:
        input = b""
    elif isinstance(input, str):
        input = input.encode(charset)
    return io.BytesIO(input)


class _BytesIOCopy(io.BytesIO):
    def __init__(self, copy_to):
        super().__init__()
        self.copy_to = copy_to

    def flush(self):
        super().flush()
        self.copy_to.flush()

    def write(self, b):
        self.copy_to.write(b)
        return super().write(b)


class _FdStream:
    def __init__(self, *files):
        self.files = files

    def getvalue(self):
        out = b""
        for f in self.files:
            f.flush()
            fd = f.fileno()
            size = os.fstat(fd).st_size
            out += os.pread(fd, size, 0) if size else b""
        return out


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value,
                 exit_code, exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    def _dec(self, b):
        return b.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def output(self):
        return self._dec(self.output_bytes)

    @property
    def stdout(self):
        return self._dec(self.stdout_bytes)

    @property
    def stderr(self):
        return self._dec(self.stderr_bytes)

    def __repr__(self):
        exc_str = repr(self.exception) if self.exception else "okay"
        return f"<{type(self).__name__} {exc_str}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        self.charset = charset
        self.env = env or {}
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def make_env(self, overrides=None):
        rv = dict(self.env)
        if overrides:
            rv.update(overrides)
        return rv

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        bytes_input = make_input_stream(input, self.charset)
        echo_input = None
        old_stdin, old_stdout, old_stderr = sys.stdin, sys.stdout, sys.stderr
        old_forced_width = formatting.FORCED_WIDTH
        formatting.FORCED_WIDTH = 80
        env = self.make_env(env)

        sys.stdin = text_input = _NamedTextIOWrapper(bytes_input, encoding=self.charset,
                                                     name="<stdin>", mode="r")
        if self.echo_stdin:
            bytes_output_for_echo = None
        fd_state = None
        if self.capture == "fd":
            fd_state = self._fd_setup()
            out_f, err_f = fd_state["out"], fd_state["err"]
            sys.stdout = _NamedTextIOWrapper(io.FileIO(1, "w", closefd=False),
                                             encoding=self.charset, name="<stdout>", mode="w",
                                             write_through=True)
            sys.stderr = _NamedTextIOWrapper(io.FileIO(2, "w", closefd=False),
                                             encoding=self.charset, name="<stderr>", mode="w",
                                             errors="backslashreplace", write_through=True)
            outstreams = (_FdStream(out_f), _FdStream(err_f), _FdStream(out_f, err_f))
        else:
            bytes_output = io.BytesIO()
            bytes_stdout = _BytesIOCopy(bytes_output)
            bytes_stderr = _BytesIOCopy(bytes_output)
            sys.stdout = _NamedTextIOWrapper(bytes_stdout, encoding=self.charset,
                                             name="<stdout>", mode="w", write_through=True)
            sys.stderr = _NamedTextIOWrapper(bytes_stderr, encoding=self.charset,
                                             name="<stderr>", mode="w",
                                             errors="backslashreplace", write_through=True)
            outstreams = (bytes_stdout, bytes_stderr, bytes_output)
        if self.echo_stdin:
            sys.stdin = text_input = EchoingStdin(text_input, sys.stdout)
            echo_input = text_input

        @_echo_pause(echo_input)
        def visible_input(prompt=None):
            sys.stdout.write(prompt or "")
            line = text_input.readline()
            if line == "":
                raise EOFError()
            val = line.rstrip("\r\n")
            sys.stdout.write(f"{val}\n")
            sys.stdout.flush()
            return val

        @_echo_pause(echo_input)
        def hidden_input(prompt=None):
            sys.stdout.write(f"{prompt or ''}\n")
            sys.stdout.flush()
            line = text_input.readline()
            if line == "":
                raise EOFError()
            return line.rstrip("\r\n")

        def _getchar(echo):
            char = sys.stdin.read(1)
            if echo:
                sys.stdout.write(char)
            return char

        default_color = color

        def should_strip_ansi(stream=None, color=None):
            if color is None:
                return not default_color
            return not color

        old_visible = termui.visible_prompt_func
        old_hidden = termui.hidden_prompt_func
        old_getchar = termui._getchar
        old_strip = _compat.should_strip_ansi
        termui.visible_prompt_func = visible_input
        termui.hidden_prompt_func = hidden_input
        termui._getchar = _getchar
        _compat.should_strip_ansi = should_strip_ansi

        old_env = {}
        try:
            for key, value in env.items():
                old_env[key] = os.environ.get(key)
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            yield outstreams
        finally:
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            if fd_state is not None:
                try:
                    sys.stdout.flush()
                    sys.stderr.flush()
                except Exception:
                    pass
                self._fd_teardown(fd_state)
            sys.stdout, sys.stderr, sys.stdin = old_stdout, old_stderr, old_stdin
            termui.visible_prompt_func = old_visible
            termui.hidden_prompt_func = old_hidden
            termui._getchar = old_getchar
            _compat.should_strip_ansi = old_strip
            formatting.FORCED_WIDTH = old_forced_width

    def _fd_setup(self):
        try:
            sys.__stdout__.flush()
            sys.__stderr__.flush()
        except Exception:
            pass
        state = {}
        state["saved1"] = os.dup(1)
        state["saved2"] = os.dup(2)
        state["out"] = tempfile.TemporaryFile()
        state["err"] = tempfile.TemporaryFile()
        os.dup2(state["out"].fileno(), 1)
        os.dup2(state["err"].fileno(), 2)
        return state

    def _fd_teardown(self, state):
        os.dup2(state["saved1"], 1)
        os.dup2(state["saved2"], 2)
        os.close(state["saved1"])
        os.close(state["saved2"])

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False,
               **extra):
        exc_info = None
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        with self.isolation(input=input, env=env, color=color) as outstreams:
            return_value = None
            exception = None
            exit_code = 0
            if isinstance(args, str):
                args = shlex.split(args)
            try:
                prog_name = extra.pop("prog_name")
            except KeyError:
                prog_name = self.get_default_prog_name(cli)
            try:
                return_value = cli.main(args=args or (), prog_name=prog_name, **extra)
            except SystemExit as e:
                exc_info = sys.exc_info()
                e_code = e.code
                if e_code is None:
                    e_code = 0
                if e_code != 0:
                    exception = e
                if not isinstance(e_code, int):
                    sys.stdout.write(str(e_code))
                    sys.stdout.write("\n")
                    e_code = 1
                exit_code = e_code
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                try:
                    sys.stdout.flush()
                    sys.stderr.flush()
                except Exception:
                    pass
                stdout = outstreams[0].getvalue()
                stderr = outstreams[1].getvalue()
                output = outstreams[2].getvalue()
        return Result(runner=self, stdout_bytes=stdout, stderr_bytes=stderr,
                      output_bytes=output, return_value=return_value, exit_code=exit_code,
                      exception=exception, exc_info=exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass


def _echo_pause(stream):
    def deco(func):
        def wrapper(*a, **kw):
            with _pause_echo(stream):
                return func(*a, **kw)
        return wrapper
    return deco
