"""Terminal UI helpers: prompts, progress bars, pager, editor..."""
import contextlib
import getpass
import inspect
import io
import math
import os
import shutil
import subprocess
import sys
import tempfile
import time

from . import _compat
from ._compat import isatty, strip_ansi
from .exceptions import Abort, OptlynException, UsageError
from .globals import resolve_color_default
from .types import Choice, convert_type
from .utils import echo, format_filename  # noqa: F401

visible_prompt_func = input
hidden_prompt_func = getpass.getpass


def _build_prompt(text, suffix, show_default=False, default=None, show_choices=True, type=None):
    prompt = text
    if type is not None and show_choices and isinstance(type, Choice):
        prompt += f" ({', '.join(map(str, type.choices))})"
    if default is not None and show_default:
        prompt = f"{prompt} [{_format_default(default)}]"
    return f"{prompt}{suffix}"


def _format_default(default):
    if isinstance(default, (io.IOBase, io.BufferedIOBase)) and hasattr(default, "name"):
        return default.name
    return default


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False,
           show_choices=True):
    def prompt_func(text):
        f = hidden_prompt_func if hide_input else visible_prompt_func
        try:
            echo(text.rstrip(" "), nl=False, err=err)
            return f(" ")
        except (KeyboardInterrupt, EOFError):
            if hide_input:
                echo(None, err=err)
            raise Abort() from None

    if value_proc is None:
        value_proc = convert_type(type, default)

    prompt_text = _build_prompt(text, prompt_suffix, show_default, default, show_choices, type)
    if confirmation_prompt:
        if confirmation_prompt is True:
            confirmation_prompt = "Repeat for confirmation"
        confirmation_prompt = _build_prompt(confirmation_prompt, prompt_suffix)

    while True:
        while True:
            value = prompt_func(prompt_text)
            if value:
                break
            elif default is not None:
                value = default
                break
        try:
            result = value_proc(value)
        except UsageError as e:
            if hide_input:
                echo("Error: The value you entered was invalid.", err=err)
            else:
                echo(f"Error: {e.message}", err=err)
            continue
        if not confirmation_prompt:
            return result
        while True:
            value2 = prompt_func(confirmation_prompt)
            is_empty = not value and not value2
            if value2 or is_empty:
                break
        if value == value2:
            return result
        echo("Error: The two entered values do not match.", err=err)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    prompt_text = _build_prompt(text, prompt_suffix, show_default,
                                "y/n" if default is None else ("Y/n" if default else "y/N"))
    while True:
        try:
            echo(prompt_text.rstrip(" "), nl=False, err=err)
            value = visible_prompt_func(" ").lower().strip()
        except (KeyboardInterrupt, EOFError):
            raise Abort() from None
        if value in ("y", "yes"):
            rv = True
        elif value in ("n", "no"):
            rv = False
        elif default is not None and value == "":
            rv = default
        else:
            echo("Error: invalid input", err=err)
            continue
        break
    if abort and not rv:
        raise Abort()
    return rv


def _interactive():
    return isatty(sys.stdin) or isatty(sys.stdout)


# ---------------------------------------------------------------- pager

class _PagerWriter:
    """Writable text stream that sends text to the pager (or stdout)."""

    def __init__(self, write_bytes, color, stream):
        self._write_bytes = write_bytes
        self._color = color
        self._stream = stream
        self.encoding = "utf-8"

    def write(self, text):
        if isinstance(text, bytes):
            text = text.decode("utf-8", "replace")
        if not isinstance(text, str):
            text = str(text)
        if _compat.should_strip_ansi(self._stream, self._color):
            text = strip_ansi(text)
        self._write_bytes(text)
        return len(text)

    def writelines(self, lines):
        for line in lines:
            self.write(line)

    def flush(self):
        pass

    def isatty(self):
        return False


@contextlib.contextmanager
def get_pager_file(color=None):
    stdout = _compat.get_text_stdout()
    color = resolve_color_default(color)
    pager_cmd = (os.environ.get("PAGER", None) or "").strip()
    if not _interactive() or not pager_cmd:
        def wb(text):
            stdout.write(text)
            stdout.flush()
        yield _PagerWriter(wb, color, stdout)
        return
    encoding = _compat.get_best_encoding(stdout)
    env = dict(os.environ)
    proc = subprocess.Popen(pager_cmd, shell=True, stdin=subprocess.PIPE, env=env)
    broken = []

    def wb(text):
        if broken:
            return
        try:
            proc.stdin.write(text.encode(encoding, "replace"))
            proc.stdin.flush()
        except (OSError, ValueError):
            broken.append(True)

    try:
        yield _PagerWriter(wb, color, _PipeTty())
    finally:
        try:
            proc.stdin.close()
        except (OSError, ValueError):
            pass
        while True:
            try:
                proc.wait()
                break
            except KeyboardInterrupt:
                pass


class _PipeTty:
    """Stand-in stream used to decide whether styles are kept for a pager."""

    def isatty(self):
        return True


def echo_via_pager(text_or_generator, color=None):
    if inspect.isgeneratorfunction(text_or_generator):
        i = text_or_generator()
    elif isinstance(text_or_generator, str):
        i = [text_or_generator]
    elif callable(text_or_generator):
        i = text_or_generator()
        if isinstance(i, str):
            i = [i]
    else:
        i = iter(text_or_generator)
    chunks = (c if isinstance(c, str) else str(c) for c in i)
    with get_pager_file(color=color) as f:
        for chunk in chunks:
            f.write(chunk)


# ------------------------------------------------------------- progress

class ProgressBar:
    def __init__(self, iterable=None, length=None, fill_char="#", empty_char="-",
                 bar_template="%(label)s  [%(bar)s]  %(info)s", info_sep="  ",
                 show_eta=True, show_percent=None, show_pos=False, item_show_func=None,
                 label=None, file=None, color=None, update_min_steps=1, width=36,
                 hidden=False):
        self.fill_char = fill_char
        self.empty_char = empty_char
        self.bar_template = bar_template
        self.info_sep = info_sep
        self.show_eta = show_eta
        self.show_percent = show_percent
        self.show_pos = show_pos
        self.item_show_func = item_show_func
        self.label = label or ""
        self.file = file if file is not None else _compat.get_text_stdout()
        self.color = color
        self.update_min_steps = update_min_steps
        self._completed_intervals = 0
        self.width = width
        self.hidden = hidden
        self._last_line = None
        self.iterable = iterable
        if length is None:
            try:
                length = len(iterable)
            except (TypeError, AttributeError):
                length = None
        if iterable is None:
            if length is None:
                raise TypeError("iterable or length is required")
            iterable = range(length)
            self.iterable = iterable
        self.length = length
        self.pos = 0
        self.avg = []
        self.last_eta = time.time()
        self.start = self.last_eta
        self.eta_known = False
        self.finished = False
        self.max_width = None
        self.entered = False
        self.current_item = None
        self._is_atty = isatty(self.file)
        self._started = False

    @property
    def is_hidden(self):
        return self.hidden or not self._is_atty

    def __enter__(self):
        self.entered = True
        self.render_progress()
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.render_finish()

    def __iter__(self):
        if not self.entered:
            raise RuntimeError("You need to use progress bars in a with block.")
        return self.generator()

    def __next__(self):
        return next(iter(self))

    def render_finish(self):
        if self.hidden or not self._is_atty:
            return
        self.file.write("\n")
        self.file.flush()

    @property
    def pct(self):
        if self.finished:
            return 1.0
        if not self.length:
            return 0.0
        return min(self.pos / self.length, 1.0)

    @property
    def time_per_iteration(self):
        if not self.pos:
            return 0.0
        return (time.time() - self.start) / self.pos

    @property
    def eta(self):
        if self.length is not None and not self.finished:
            return self.time_per_iteration * (self.length - self.pos)
        return 0.0

    def format_eta(self):
        if self.length is not None:
            t = int(self.eta)
            seconds = t % 60
            t //= 60
            minutes = t % 60
            t //= 60
            hours = t % 24
            t //= 24
            if t > 0:
                return f"{t}d {hours:02}:{minutes:02}:{seconds:02}"
            return f"{hours:02}:{minutes:02}:{seconds:02}"
        return ""

    def format_pos(self):
        pos = str(self.pos)
        if self.length is not None:
            pos += f"/{self.length}"
        return pos

    def format_pct(self):
        return f"{int(self.pct * 100): 4}%"[1:]

    def format_bar(self):
        if self.length is not None:
            bar_length = int(self.pct * self.width)
            bar = self.fill_char * bar_length
            bar += self.empty_char * (self.width - bar_length)
        elif self.finished:
            bar = self.fill_char * self.width
        else:
            chars = list(self.empty_char * (self.width or 1))
            if self.time_per_iteration != 0:
                chars[int((math.cos(self.pos * self.time_per_iteration) / 2.0 + 0.5)
                          * self.width)] = self.fill_char
            bar = "".join(chars)
        return bar

    def format_progress_line(self):
        show_percent = self.show_percent
        info_bits = []
        if self.length is not None and show_percent is None:
            show_percent = not self.show_pos
        if self.show_pos:
            info_bits.append(self.format_pos())
        if show_percent:
            info_bits.append(self.format_pct())
        if self.show_eta and self.length is not None and not self.finished:
            info_bits.append(self.format_eta())
        if self.item_show_func is not None:
            item_info = self.item_show_func(self.current_item)
            if item_info is not None:
                info_bits.append(item_info)
        return (self.bar_template % {
            "label": self.label, "bar": self.format_bar(),
            "info": self.info_sep.join(info_bits)}).rstrip()

    def render_progress(self):
        if self.hidden:
            return
        if not self._is_atty:
            if self._last_line != self.label:
                self._last_line = self.label
                echo(self.label, file=self.file, color=self.color)
            return
        line = self.format_progress_line()
        if line == self._last_line and not self.finished:
            return
        self._last_line = line
        self.file.write("\r" + line)
        self.file.flush()

    def make_step(self, n_steps):
        self.pos += n_steps
        if self.length is not None and self.pos >= self.length:
            self.finished = True

    def update(self, n_steps=1, current_item=None):
        if current_item is not None:
            self.current_item = current_item
        self.make_step(n_steps)
        self.render_progress()

    def finish(self):
        self.finished = True
        self.pos = self.length if self.length is not None else self.pos

    def generator(self):
        if not self.entered:
            raise RuntimeError("You need to use progress bars in a with block.")
        for rv in self.iterable:
            self.current_item = rv
            yield rv
            self.update(1)
        self.finish()
        self.render_progress()


def progressbar(iterable=None, length=None, label=None, hidden=False, show_eta=True,
                show_percent=None, show_pos=False, item_show_func=None, fill_char="#",
                empty_char="-", bar_template="%(label)s  [%(bar)s]  %(info)s",
                info_sep="  ", width=36, file=None, color=None, update_min_steps=1):
    color = resolve_color_default(color)
    return ProgressBar(iterable=iterable, length=length, show_eta=show_eta,
                       show_percent=show_percent, show_pos=show_pos,
                       item_show_func=item_show_func, fill_char=fill_char,
                       empty_char=empty_char, bar_template=bar_template,
                       info_sep=info_sep, file=file, label=label, width=width,
                       color=color, update_min_steps=update_min_steps, hidden=hidden)


# ---------------------------------------------------------- misc helpers

def clear():
    if not isatty(sys.stdout):
        return
    echo("\033[2J\033[1;1H", nl=False)


def _getchar_unix(echo_):
    import termios
    import tty
    f = None
    if isatty(sys.stdin):
        fd = sys.stdin.fileno()
    else:
        f = open("/dev/tty")
        fd = f.fileno()
    try:
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 32).decode(_compat.get_best_encoding(sys.stdin), "replace")
            if echo_ and isatty(sys.stdout):
                sys.stdout.write(ch)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
            sys.stdout.flush()
    finally:
        if f is not None:
            f.close()
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    return ch


_getchar = None


def getchar(echo=False):
    func = _getchar if _getchar is not None else _getchar_unix
    return func(echo)


def pause(info=None, err=False):
    if info is None:
        info = "Press any key to continue..."
    interactive = isatty(sys.stdin) and isatty(sys.stdout)
    try:
        if info:
            echo(info, nl=False, err=err)
        if interactive:
            try:
                getchar()
            except (KeyboardInterrupt, EOFError):
                pass
    finally:
        if info:
            echo(err=err)


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    def get_editor():
        if editor is not None:
            return editor
        for key in "VISUAL", "EDITOR":
            rv = os.environ.get(key)
            if rv:
                return rv
        for ed in "sensible-editor", "vim", "nano":
            if shutil.which(ed):
                return ed
        return "vi"

    def run(path):
        ed = get_editor()
        environ = None
        if env:
            environ = os.environ.copy()
            environ.update(env)
        try:
            c = subprocess.Popen(f'{ed} "{path}"', env=environ, shell=True)
            exit_code = c.wait()
            if exit_code != 0:
                raise OptlynException(f"{ed}: Editing failed")
        except OSError as e:
            raise OptlynException(f"{ed}: Editing failed: {e}") from e

    if filename is not None:
        run(filename)
        return None
    binary = isinstance(text, (bytes, bytearray))
    if text is None:
        text = ""
    if not binary and text and not text.endswith("\n"):
        text += "\n"
    fd, name = tempfile.mkstemp(prefix="editor-", suffix=extension)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(bytes(text) if binary else text.encode("utf-8"))
        timestamp = os.path.getmtime(name)
        run(name)
        if require_save and os.path.getmtime(name) == timestamp:
            return None
        with open(name, "rb") as f:
            rv = f.read()
        if binary:
            return rv
        return rv.decode("utf-8-sig").replace("\r\n", "\n")
    finally:
        try:
            os.unlink(name)
        except OSError:
            pass


def launch(url, wait=False, locate=False):
    def _unquote_file(url):
        from urllib.parse import unquote
        if url.startswith("file://"):
            url = unquote(url[7:])
        return url

    try:
        url = os.fspath(url) if not isinstance(url, str) else url
        if locate:
            url = os.path.dirname(_unquote_file(url)) or "."
        else:
            url = _unquote_file(url)
        c = subprocess.Popen(["xdg-open", url])
        if wait:
            return c.wait()
        try:
            c.wait(timeout=1)
        except subprocess.TimeoutExpired:
            pass
        return 0
    except OSError:
        if url.startswith(("http://", "https://")) and not locate and not wait:
            import webbrowser
            webbrowser.open(url)
            return 0
        return 1
