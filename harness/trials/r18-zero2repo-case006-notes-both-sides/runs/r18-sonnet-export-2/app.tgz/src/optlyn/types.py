"""Parameter types."""
import datetime
import enum
import os
import stat
import uuid

from ._compat import get_best_encoding
from .exceptions import BadParameter, DeclarationError
from .shell_completion import CompletionItem


class ParamType:
    is_composite = False
    arity = 1
    name = ""
    envvar_list_splitter = None

    def get_metavar(self, param, ctx=None):
        return None

    def get_missing_message(self, param):
        return None

    def convert(self, value, param, ctx):
        return value

    def split_envvar_value(self, rv):
        return (rv or "").split(self.envvar_list_splitter)

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def shell_complete(self, ctx, param, incomplete):
        return []

    def __call__(self, value, param=None, ctx=None):
        if value is not None:
            return self.convert(value, param, ctx)


class CompositeParamType(ParamType):
    is_composite = True

    @property
    def arity(self):
        raise NotImplementedError()


class FuncParamType(ParamType):
    def __init__(self, func):
        self.name = getattr(func, "__name__", "func")
        self.func = func

    def convert(self, value, param, ctx):
        try:
            return self.func(value)
        except ValueError:
            try:
                value = str(value)
            except UnicodeError:
                value = value.decode("utf-8", "replace")
            self.fail(value, param, ctx)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        return value

    def __repr__(self):
        return "UNPROCESSED"


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        if isinstance(value, bytes):
            enc = get_best_encoding(__import__("sys").stdin)
            try:
                value = value.decode(enc)
            except UnicodeError:
                value = value.decode("utf-8", "replace")
            return value
        return str(value)

    def __repr__(self):
        return "STRING"


class Choice(ParamType):
    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        self._enum = None
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self._enum = choices
            self._items = [(m.name, m) for m in choices]
            case_sensitive = False
        else:
            self._items = [(c if isinstance(c, str) else str(c), c) for c in choices]
        self.choices = [k for k, _ in self._items]
        self.case_sensitive = case_sensitive

    def get_metavar(self, param, ctx=None):
        return "[" + "|".join(self.choices) + "]"

    def get_missing_message(self, param):
        return "Choose from:\n\t" + ",\n\t".join(self.choices)

    def _norm(self, s, ctx):
        if ctx is not None and ctx.token_normalize_func is not None:
            s = ctx.token_normalize_func(s)
        if not self.case_sensitive:
            s = s.casefold()
        return s

    def convert(self, value, param, ctx):
        if self._enum is not None and isinstance(value, self._enum):
            return value
        if not isinstance(value, str):
            for k, orig in self._items:
                if orig is value or (self._enum is None and orig == value):
                    return orig
            value = str(value)
        normed_choices = {}
        for k, orig in self._items:
            normed_choices.setdefault(self._norm(k, ctx), orig)
        nv = self._norm(value, ctx)
        if nv in normed_choices:
            return normed_choices[nv]
        choices_str = ", ".join(map(repr, self.choices))
        self.fail(f"{value!r} is not one of {choices_str}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        str_choices = map(str, self.choices)
        if self.case_sensitive:
            matched = (c for c in str_choices if c.startswith(incomplete))
        else:
            incomplete = incomplete.lower()
            matched = (c for c in str_choices if c.lower().startswith(incomplete))
        return [CompletionItem(c) for c in matched]

    def __repr__(self):
        return f"Choice({list(self.choices)})"


class DateTime(ParamType):
    name = "datetime"
    DEFAULT_FORMATS = ["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(self.DEFAULT_FORMATS)

    def get_metavar(self, param, ctx=None):
        return f"[{'|'.join(self.formats)}]"

    def convert(self, value, param, ctx):
        if isinstance(value, datetime.datetime):
            return value
        result = None
        for fmt in self.formats:
            try:
                result = datetime.datetime.strptime(value, fmt)
            except (ValueError, TypeError):
                pass
        if result is not None:
            return result
        if len(self.formats) == 1:
            self.fail(f"{value!r} does not match the format {self.formats[0]!r}.", param, ctx)
        formats_str = ", ".join(map(repr, self.formats))
        self.fail(f"{value!r} does not match the formats {formats_str}.", param, ctx)

    def __repr__(self):
        return "DateTime"


class _NumberParamTypeBase(ParamType):
    _number_class = None

    def convert(self, value, param, ctx):
        try:
            return self._number_class(value)
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid {self.name}.", param, ctx)


class _NumberRangeBase(_NumberParamTypeBase):
    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param, ctx):
        import operator
        rv = super().convert(value, param, ctx)
        lt_min = self.min is not None and (operator.le if self.min_open else operator.lt)(rv, self.min)
        gt_max = self.max is not None and (operator.ge if self.max_open else operator.gt)(rv, self.max)
        if self.clamp:
            if lt_min:
                return self._number_class(self.min)
            if gt_max:
                return self._number_class(self.max)
        if lt_min or gt_max:
            self.fail(f"{rv} is not in the range {self._describe_range()}.", param, ctx)
        return rv

    def _describe_range(self):
        if self.min is None:
            op = "<" if self.max_open else "<="
            return f"x{op}{self.max}"
        if self.max is None:
            op = ">" if self.min_open else ">="
            return f"x{op}{self.min}"
        lop = "<" if self.min_open else "<="
        rop = "<" if self.max_open else "<="
        return f"{self.min}{lop}x{rop}{self.max}"

    def __repr__(self):
        clamp = " clamped" if self.clamp else ""
        return f"<{type(self).__name__} {self._describe_range()}{clamp}>"


class IntParamType(_NumberParamTypeBase):
    name = "integer"
    _number_class = int

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return int(value)
        return super().convert(value, param, ctx)

    def __repr__(self):
        return "INT"


class IntRange(_NumberRangeBase):
    name = "integer range"
    _number_class = int


class FloatParamType(_NumberParamTypeBase):
    name = "float"
    _number_class = float

    def __repr__(self):
        return "FLOAT"


class FloatRange(_NumberRangeBase):
    name = "float range"
    _number_class = float

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        super().__init__(min=min, max=max, min_open=min_open, max_open=max_open, clamp=clamp)
        if min is not None and max is not None and min > max:
            raise DeclarationError("'min' must not be greater than 'max'.")


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param, ctx):
        if value in {False, True}:
            return bool(value)
        norm = str(value).strip().lower()
        if norm in {"1", "true", "t", "yes", "y", "on"}:
            return True
        if norm in {"0", "false", "f", "no", "n", "off"}:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)

    def __repr__(self):
        return "BOOL"


class UUIDParameterType(ParamType):
    name = "uuid"

    def convert(self, value, param, ctx):
        if isinstance(value, uuid.UUID):
            return value
        value = str(value).strip()
        try:
            return uuid.UUID(value)
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)

    def __repr__(self):
        return "UUID"


class File(ParamType):
    name = "filename"
    envvar_list_splitter = os.path.pathsep

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def resolve_lazy_flag(self, value):
        if self.lazy is not None:
            return self.lazy
        if os.fspath(value) == "-":
            return False
        if "w" in self.mode:
            return True
        return False

    def convert(self, value, param, ctx):
        from .utils import LazyFile, open_stream, safecall, format_filename
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        try:
            lazy = self.resolve_lazy_flag(value)
            if lazy:
                lf = LazyFile(value, self.mode, self.encoding, self.errors, atomic=self.atomic)
                if ctx is not None:
                    ctx.call_on_close(lf.close_intelligently)
                return lf
            f, should_close = open_stream(value, self.mode, self.encoding, self.errors,
                                          atomic=self.atomic)
            if ctx is not None:
                if should_close:
                    ctx.call_on_close(safecall(f.close))
                else:
                    ctx.call_on_close(safecall(f.flush))
            return f
        except OSError as e:
            self.fail(f"'{format_filename(value)}': {e.strerror}", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        return [CompletionItem(incomplete, type="file")]


class Path(ParamType):
    envvar_list_splitter = os.path.pathsep

    def __init__(self, exists=False, file_okay=True, dir_okay=True, writable=False,
                 readable=True, resolve_path=False, allow_dash=False, path_type=None,
                 executable=False):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.readable = readable
        self.writable = writable
        self.executable = executable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.type = path_type
        if self.file_okay and not self.dir_okay:
            self.name = "file"
        elif self.dir_okay and not self.file_okay:
            self.name = "directory"
        else:
            self.name = "path"

    def coerce_path_result(self, rv):
        if self.type is not None and not isinstance(rv, self.type):
            if self.type is str:
                rv = os.fsdecode(rv)
            elif self.type is bytes:
                rv = os.fsencode(rv)
            else:
                rv = self.type(rv)
        return rv

    def convert(self, value, param, ctx):
        from .utils import format_filename
        rv = value
        is_dash = self.allow_dash and rv in (b"-", "-")
        if not is_dash:
            if self.resolve_path:
                import pathlib
                rv = os.fsdecode(pathlib.Path(os.path.expanduser(os.fsdecode(rv))).resolve())
            try:
                st = os.stat(rv)
            except OSError:
                if not self.exists:
                    return self.coerce_path_result(rv)
                self.fail(f"{self.name.title()} {format_filename(value)!r} does not exist.",
                          param, ctx)
            if not self.file_okay and stat.S_ISREG(st.st_mode):
                self.fail(f"{self.name.title()} {format_filename(value)!r} is a file.", param, ctx)
            if not self.dir_okay and stat.S_ISDIR(st.st_mode):
                self.fail(f"{self.name.title()} {format_filename(value)!r} is a directory.",
                          param, ctx)
            if self.readable and not os.access(rv, os.R_OK):
                self.fail(f"{self.name.title()} {format_filename(value)!r} is not readable.",
                          param, ctx)
            if self.writable and not os.access(rv, os.W_OK):
                self.fail(f"{self.name.title()} {format_filename(value)!r} is not writable.",
                          param, ctx)
            if self.executable and not os.access(rv, os.X_OK):
                self.fail(f"{self.name.title()} {format_filename(value)!r} is not executable.",
                          param, ctx)
        return self.coerce_path_result(rv)

    def shell_complete(self, ctx, param, incomplete):
        type = "dir" if self.dir_okay and not self.file_okay else "file"
        return [CompletionItem(incomplete, type=type)]


class Tuple(CompositeParamType):
    def __init__(self, types):
        self.types = [convert_type(ty) for ty in types]

    @property
    def name(self):
        return f"<{' '.join(ty.name for ty in self.types)}>"

    @property
    def arity(self):
        return len(self.types)

    def convert(self, value, param, ctx):
        len_type = len(self.types)
        len_value = len(value)
        if len_value != len_type:
            self.fail(f"{len_type} values are required, but {len_value} were given.", param, ctx)
        return tuple(ty(x, param, ctx) for ty, x in zip(self.types, value))


def convert_type(ty, default=None):
    guessed_type = False
    if ty is None and default is not None:
        if isinstance(default, (tuple, list)):
            if default:
                item = default[0]
                if isinstance(item, (tuple, list)):
                    ty = tuple(map(type, item))
                else:
                    ty = type(item)
        else:
            ty = type(default)
        guessed_type = True
    if isinstance(ty, tuple):
        return Tuple(ty)
    if isinstance(ty, ParamType):
        return ty
    if ty is str or ty is None:
        return STRING
    if ty is int:
        return INT
    if ty is float:
        return FLOAT
    if ty is bool:
        return BOOL
    if guessed_type:
        return STRING
    try:
        if issubclass(ty, ParamType):
            raise DeclarationError(
                f"Attempted to use an uninstantiated parameter type ({ty}).")
    except TypeError:
        pass
    return FuncParamType(ty)


UNPROCESSED = UnprocessedParamType()
STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParameterType()
