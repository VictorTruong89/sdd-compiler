"""Terminal interaction helpers."""
import getpass
import inspect
import io
import itertools
import os
import shutil
import subprocess
import sys
import tempfile
import time
from contextlib import contextmanager

from .exceptions import Abort, FileError, UsageError, OptlynException
from . import utils
from .utils import echo, isatty, strip_ansi, term_len, format_filename

visible_prompt_func = input


def hidden_prompt_func(prompt):
    return getpass.getpass(prompt)


def _build_prompt(text, suffix, show_default=False, default=None, show_choices=True, type=None):
    from .types import Choice
    prompt = text
    if type is not None and show_choices and isinstance(type, Choice):
        prompt += f" ({', '.join(map(str, type._names))})"
    if default is not None and show_default:
        prompt = f"{prompt} [{_format_default(default)}]"
    return f"{prompt}{suffix}"


def _format_default(default):
    if isinstance(default, (io.IOBase, utils.LazyFile)) and hasattr(default, "name"):
        return default.name
    return default


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False,
           show_choices=True):
    from .types import convert_type

    def prompt_func(t):
        f = hidden_prompt_func if hide_input else visible_prompt_func
        try:
            echo(t.rstrip(" "), nl=False, err=err)
            return f(" ")
        except (KeyboardInterrupt, EOFError):
            if hide_input:
                echo(None, err=err)
            raise Abort() from None

    if value_proc is None:
        value_proc = convert_type(type, default)
    full = _build_prompt(text, prompt_suffix, show_default, default, show_choices, type)
    if confirmation_prompt:
        if confirmation_prompt is True:
            confirmation_prompt = "Repeat for confirmation"
        confirmation_prompt = _build_prompt(confirmation_prompt, prompt_suffix)
    while True:
        while True:
            value = prompt_func(full)
            if value:
                break
            elif default is not None:
                value = default
                break
        try:
            result = value_proc(value)
        except UsageError as e:
            if hide_input:
                echo("Error: The value you entered was invalid.", err=err)
            else:
                echo(f"Error: {e.message}", err=err)
            continue
        if not confirmation_prompt:
            return result
        while True:
            value2 = prompt_func(confirmation_prompt)
            is_empty = not value and not value2
            if value2 or is_empty:
                break
        if value == value2:
            return result
        echo("Error: The two entered values do not match.", err=err)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    full = _build_prompt(text, prompt_suffix, show_default,
                         "y/n" if default is None else ("Y/n" if default else "y/N"))
    while True:
        try:
            echo(full.rstrip(" "), nl=False, err=err)
            value = visible_prompt_func(" ").lower().strip()
        except (KeyboardInterrupt, EOFError):
            raise Abort() from None
        if value in ("y", "yes"):
            rv = True
        elif value in ("n", "no"):
            rv = False
        elif default is not None and value == "":
            rv = default
        else:
            echo("Error: invalid input", err=err)
            continue
        break
    if abort and not rv:
        raise Abort()
    return rv


# ------------------------------------------------------------------ pager

def _interactive():
    return isatty(sys.stdin) or isatty(sys.stdout)


def _nullpager(stream, generator, color):
    for text in generator:
        if not color:
            text = strip_ansi(text) if utils.should_strip_ansi(stream, color) else text
        stream.write(text)
    stream.flush()


def _pipepager(generator, cmd, color):
    env = dict(os.environ)
    if color is None or color:
        env.setdefault("LESS", "-R")
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, env=env)
    pipe = proc.stdin
    try:
        for text in generator:
            if not color:
                text = strip_ansi(text)
            pipe.write(text.encode("utf-8", "replace"))
            pipe.flush()
    except (OSError, KeyboardInterrupt):
        pass
    finally:
        try:
            pipe.close()
        except OSError:
            pass
        while True:
            try:
                proc.wait()
                break
            except KeyboardInterrupt:
                pass


def _pager_command():
    cmd = (os.environ.get("PAGER") or "").strip()
    if cmd:
        return cmd
    for c in ("less", "more"):
        if shutil.which(c):
            return c
    return None


def _run_pager(generator, color):
    stdout = sys.stdout
    if color is None:
        color = utils.resolve_color_default(None)
    if not _interactive():
        return _nullpager(stdout, generator, color)
    cmd = _pager_command()
    if not cmd:
        return _nullpager(stdout, generator, color)
    if color is None:
        color = False
    return _pipepager(generator, cmd, color)


def echo_via_pager(text_or_generator, color=None):
    if inspect.isgeneratorfunction(text_or_generator) or (
            callable(text_or_generator) and not isinstance(text_or_generator, str)):
        i = text_or_generator()
    elif isinstance(text_or_generator, str):
        i = [text_or_generator]
    else:
        i = iter(text_or_generator)
    text = (el if isinstance(el, str) else str(el) for el in i)
    if isinstance(i, list):
        gen = itertools.chain(text, "\n")
    else:
        gen = itertools.chain(text, ["\n"])
    return _run_pager(gen, color)


@contextmanager
def get_pager_file(color=None):
    stdout = sys.stdout
    cmd = _pager_command() if _interactive() else None
    if cmd is None:
        class _Out:
            def write(self, s):
                c = color if color is not None else utils.resolve_color_default(None)
                if utils.should_strip_ansi(stdout, c):
                    s = strip_ansi(s)
                stdout.write(s)

            def flush(self):
                stdout.flush()

            def writelines(self, lines):
                for ln in lines:
                    self.write(ln)
        out = _Out()
        try:
            yield out
        finally:
            stdout.flush()
        return
    env = dict(os.environ)
    env.setdefault("LESS", "-R")
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, env=env)
    strip = not color if color is not None else False

    class _Pipe:
        def write(self, s):
            if strip:
                s = strip_ansi(s)
            proc.stdin.write(s.encode("utf-8", "replace"))
            proc.stdin.flush()

        def flush(self):
            proc.stdin.flush()

        def writelines(self, lines):
            for ln in lines:
                self.write(ln)
    try:
        yield _Pipe()
    finally:
        try:
            proc.stdin.close()
        except OSError:
            pass
        proc.wait()


# ------------------------------------------------------------ progress bar

class ProgressBar:
    def __init__(self, iterable=None, length=None, fill_char="#", empty_char="-",
                 bar_template="%(label)s  [%(bar)s]  %(info)s", info_sep="  ",
                 show_eta=True, show_percent=None, show_pos=False, item_show_func=None,
                 label=None, file=None, color=None, update_min_steps=1, width=36,
                 hidden=False):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.fill_char = fill_char
        self.empty_char = empty_char
        self.bar_template = bar_template
        self.info_sep = info_sep
        self.show_eta = show_eta
        self.show_percent = show_percent
        self.show_pos = show_pos
        self.item_show_func = item_show_func
        self.label = label or ""
        self.file = file if file is not None else sys.stdout
        self.color = color
        self.update_min_steps = update_min_steps
        self.width = width
        self.explicit_hidden = hidden
        self.hidden = hidden or not isatty(self.file)
        self.pos = 0
        self.finished = False
        self.start = self.last_eta = time.time()
        self.current_item = None
        self._last_line = None
        self._completed_intervals = 0
        self._started = False
        if self.show_percent is None:
            self.show_percent = length is not None and not show_pos

    def __enter__(self):
        self._started = True
        self.render_progress()
        return self

    def __exit__(self, *a):
        self.render_finish()

    def __iter__(self):
        if not self._started:
            self._started = True
            self.render_progress()
        return self._iter()

    def _iter(self):
        for item in self.iterable:
            self.current_item = item
            yield item
            self.update(1)
        self.finish()
        self.render_progress()

    def __next__(self):
        return next(self._it)

    @property
    def eta(self):
        if self.length is None or self.pos == 0:
            return None
        elapsed = time.time() - self.start
        avg = elapsed / self.pos
        return max(self.length - self.pos, 0) * avg

    def format_eta(self):
        if not self.show_eta or self.finished:
            return ""
        eta = self.eta
        if eta is None:
            return ""
        t = int(eta)
        d, r = divmod(t, 86400)
        h, r = divmod(r, 3600)
        m, s = divmod(r, 60)
        if d:
            return f"{d}d {h:02}:{m:02}:{s:02}"
        return f"{h:02}:{m:02}:{s:02}"

    def format_pos(self):
        pos = str(self.pos)
        if self.length is not None:
            pos += f"/{self.length}"
        return pos

    def format_pct(self):
        if not self.length:
            return "  0%"
        return f"{int(self.pos * 100 / self.length): 4}%"

    def format_bar(self):
        if self.length:
            n = int(self.width * min(self.pos, self.length) / self.length)
            return self.fill_char * n + self.empty_char * (self.width - n)
        return self.fill_char * 1 + self.empty_char * (self.width - 1)

    def format_progress_line(self):
        info = []
        if self.show_percent:
            info.append(self.format_pct())
        if self.show_pos:
            info.append(self.format_pos())
        eta = self.format_eta()
        if eta:
            info.append(eta)
        if self.item_show_func is not None:
            item = self.item_show_func(self.current_item)
            if item is not None:
                info.append(item)
        return (self.bar_template % {
            "label": self.label, "bar": self.format_bar(),
            "info": self.info_sep.join(i for i in info if i)}).rstrip()

    def render_progress(self):
        if self.explicit_hidden:
            return
        if self.hidden:
            if self.label and self.label != self._last_line:
                echo(self.label, file=self.file, color=self.color)
                self._last_line = self.label
            return
        line = self.format_progress_line()
        clear = " " * max(term_len(self._last_line or "") - term_len(line), 0)
        echo(f"\r{line}{clear}", file=self.file, nl=False, color=self.color)
        self._last_line = line

    def render_finish(self):
        if self.hidden or self.explicit_hidden:
            return
        self.file.write("\n")
        self.file.flush()

    def make_step(self, n_steps):
        self.pos += n_steps
        if self.length is not None and self.pos >= self.length:
            self.finished = True

    def update(self, n_steps=1, current_item=None):
        self.make_step(n_steps)
        if current_item is not None:
            self.current_item = current_item
        self.render_progress()

    def finish(self):
        self.pos = self.length if self.length is not None else self.pos
        self.finished = True


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    if iterable is None and length is None:
        raise TypeError("Either iterable or length is required.")
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)


# ------------------------------------------------------------------ misc

def _getchar(echo_=False):
    import termios
    import tty
    f = None
    if not isatty(sys.stdin):
        f = open("/dev/tty")
        fd = f.fileno()
    else:
        fd = sys.stdin.fileno()
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 32)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
            sys.stdout.flush()
    finally:
        if f is not None:
            f.close()
    ch = ch.decode(getattr(sys.stdin, "encoding", None) or "utf-8", "replace")
    if echo_ and isatty(sys.stdout):
        sys.stdout.write(ch)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    return ch


def getchar(echo=False):
    return _getchar(echo)


def pause(info=None, err=False):
    if info is None:
        info = "Press any key to continue..."
    interactive = isatty(sys.stdin) and isatty(sys.stdout)
    try:
        echo(info, nl=False, err=err)
        if interactive:
            try:
                getchar()
            except (KeyboardInterrupt, EOFError):
                pass
    finally:
        echo(err=err)


def clear():
    if not isatty(sys.stdout):
        return
    echo("\033[2J\033[1;1H", nl=False)


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    if editor is None:
        editor = os.environ.get("VISUAL") or os.environ.get("EDITOR") or \
            ("vi" if shutil.which("vi") else "nano")
    environ = None
    if env:
        environ = dict(os.environ)
        environ.update(env)

    def run(path):
        import shlex
        try:
            c = subprocess.Popen(f'{editor} {shlex.quote(path)}', env=environ, shell=True)
            exit_code = c.wait()
        except OSError as e:
            raise OptlynException(f"{editor}: Editing failed: {e}") from e
        if exit_code != 0:
            raise OptlynException(f"{editor}: Editing failed")

    if filename is not None:
        run(filename)
        return None
    fd, name = tempfile.mkstemp(prefix="optlyn-edit-", suffix=extension)
    try:
        data = (text or "").replace("\r\n", "\n")
        with os.fdopen(fd, "wb") as f:
            f.write(data.encode("utf-8"))
        os.utime(name, (0, 0))
        before = os.stat(name).st_mtime_ns
        run(name)
        after = os.stat(name).st_mtime_ns
        if require_save and before == after:
            return None
        with open(name, "rb") as f:
            rv = f.read()
        return rv.decode("utf-8-sig").replace("\r\n", "\n")
    finally:
        try:
            os.unlink(name)
        except OSError:
            pass


def launch(url, wait=False, locate=False):
    if sys.platform == "darwin":
        opener = "open"
    elif sys.platform.startswith("win"):
        opener = "start"
    else:
        opener = "xdg-open"
    url = os.fspath(url)
    if locate:
        url = os.path.dirname(url) or "."
    try:
        return subprocess.Popen([opener, url]).wait() if wait or True else 0
    except OSError:
        return 127
