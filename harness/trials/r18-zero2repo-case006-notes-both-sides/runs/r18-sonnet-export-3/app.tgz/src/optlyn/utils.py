"""Output, styling, file helpers."""
import codecs
import io
import os
import re
import sys
import tempfile
from .globals import resolve_color_default

_ansi_re = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")

_ansi_colors = {
    "black": 30, "red": 31, "green": 32, "yellow": 33, "blue": 34,
    "magenta": 35, "cyan": 36, "white": 37, "reset": 39,
    "bright_black": 90, "bright_red": 91, "bright_green": 92,
    "bright_yellow": 93, "bright_blue": 94, "bright_magenta": 95,
    "bright_cyan": 96, "bright_white": 97,
}
_ansi_reset_all = "\033[0m"


class StyleError(TypeError, ValueError):
    pass


def strip_ansi(value):
    return _ansi_re.sub("", value)


def unstyle(text):
    return strip_ansi(text)


def term_len(x):
    return len(strip_ansi(x))


def isatty(stream):
    try:
        return stream.isatty()
    except Exception:
        return False


def _color_code(color, offset):
    if isinstance(color, str):
        if color not in _ansi_colors:
            raise StyleError(f"Unknown color {color!r}")
        return str(_ansi_colors[color] + offset)
    if isinstance(color, bool):
        raise StyleError(f"Unknown color {color!r}")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise StyleError(f"Color {color!r} out of range 0-255")
        return f"{38 + offset};5;{color}"
    if isinstance(color, (tuple, list)):
        if (len(color) != 3 or not all(isinstance(c, int) and not isinstance(c, bool)
                                       and 0 <= c <= 255 for c in color)):
            raise StyleError(f"Unknown color {color!r}")
        r, g, b = color
        return f"{38 + offset};2;{r};{g};{b}"
    raise StyleError(f"Unknown color {color!r}")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None,
          overline=None, italic=None, blink=None, reverse=None,
          strikethrough=None, reset=True):
    if not isinstance(text, str):
        text = str(text)
    bits = []
    if fg is not None:
        bits.append(f"\033[{_color_code(fg, 0)}m")
    if bg is not None:
        bits.append(f"\033[{_color_code(bg, 10)}m")
    for val, on, off in ((bold, 1, 22), (dim, 2, 22), (underline, 4, 24),
                         (overline, 53, 55), (italic, 3, 23), (blink, 5, 25),
                         (reverse, 7, 27), (strikethrough, 9, 29)):
        if val is not None:
            bits.append(f"\033[{on if val else off}m")
    bits.append(text)
    if reset:
        bits.append(_ansi_reset_all)
    return "".join(bits)


def should_strip_ansi(stream=None, color=None):
    if color is None:
        if stream is None:
            stream = sys.stdin
        return not isatty(stream)
    return not color


def _is_ascii_stream(stream):
    enc = getattr(stream, "encoding", None)
    if not enc:
        return False
    try:
        return codecs.lookup(enc).name in ("ascii", "us-ascii")
    except LookupError:
        return False


def _find_binary_writer(stream):
    if isinstance(stream, (io.RawIOBase, io.BufferedIOBase)):
        return stream
    buf = getattr(stream, "buffer", None)
    if buf is not None and not isinstance(stream, io.StringIO):
        return buf
    return None


def echo(message=None, file=None, nl=True, err=False, color=None):
    if file is None:
        file = sys.stderr if err else sys.stdout
        if file is None:
            return
    if message is not None and not isinstance(message, (str, bytes, bytearray)):
        out = str(message)
    else:
        out = message
    if nl:
        out = out or ""
        out = out + ("\n" if isinstance(out, str) else b"\n")
    if not out:
        try:
            file.flush()
        except Exception:
            pass
        return
    if isinstance(out, (bytes, bytearray)):
        binary = _find_binary_writer(file)
        if binary is not None:
            file.flush()
            binary.write(out)
            binary.flush()
            return
        out = out.decode("utf-8", "replace")
    if message and not isinstance(message, (bytes, bytearray)):
        color = resolve_color_default(color)
        if should_strip_ansi(file, color):
            out = strip_ansi(out)
    if _is_ascii_stream(file):
        binary = _find_binary_writer(file)
        if binary is not None:
            file.flush()
            binary.write(out.encode("utf-8"))
            binary.flush()
            return
    file.write(out)
    file.flush()


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None and not isinstance(message, (bytes, bytearray)):
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def format_filename(filename, shorten=False):
    if shorten:
        filename = os.path.basename(filename)
    filename = os.fspath(filename)
    if isinstance(filename, bytes):
        return filename.decode(sys.getfilesystemencoding() or "utf-8", "backslashreplace")
    return filename.encode("utf-8", "surrogateescape").decode("utf-8", "backslashreplace")


def get_app_dir(app_name, roaming=True, force_posix=False):
    def posixify(name):
        return "-".join(name.split()).lower()
    if sys.platform.startswith("win"):
        key = "APPDATA" if roaming else "LOCALAPPDATA"
        folder = os.environ.get(key) or os.path.expanduser("~")
        return os.path.join(folder, app_name)
    if force_posix:
        return os.path.join(os.path.expanduser(f"~/.{posixify(app_name)}"))
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~/Library/Application Support"), app_name)
    return os.path.join(os.path.expanduser("~/.config"), posixify(app_name))


# ---------------------------------------------------------------- files

class _KeepOpenFile:
    def __init__(self, file):
        self._file = file

    def __getattr__(self, name):
        return getattr(self._file, name)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        pass

    def __repr__(self):
        return repr(self._file)

    def __iter__(self):
        return iter(self._file)


KeepOpenFile = _KeepOpenFile


class _NonClosingText(io.TextIOWrapper):
    def close(self):
        try:
            self.flush()
        except Exception:
            pass

    def __del__(self):
        try:
            self.flush()
            self.detach()
        except Exception:
            pass


class _AtomicFile:
    def __init__(self, f, tmp_filename, real_filename):
        self._f = f
        self.name = real_filename
        self._tmp = tmp_filename
        self._closed = False

    def __getattr__(self, name):
        return getattr(self._f, name)

    def close(self, delete=False):
        if self._closed:
            return
        self._closed = True
        self._f.close()
        if delete:
            try:
                os.unlink(self._tmp)
            except OSError:
                pass
        else:
            os.replace(self._tmp, self.name)

    @property
    def closed(self):
        return self._closed

    def __enter__(self):
        return self

    def __exit__(self, exc_type, *a):
        self.close(delete=exc_type is not None)

    def __iter__(self):
        return iter(self._f)

    def __del__(self):
        try:
            self.close(delete=False)
        except Exception:
            pass


def _open_atomic(filename, mode, encoding, errors):
    filename = os.fspath(filename)
    if "r" in mode or "x" in mode or "a" in mode or "w" not in mode:
        raise ValueError("Atomic writes only make sense with 'w' mode.")
    d = os.path.dirname(os.path.abspath(filename))
    base = os.path.basename(filename)
    fd, tmp = tempfile.mkstemp(dir=d, prefix=f".__atomic-write-{base}-")
    try:
        if os.path.exists(filename):
            try:
                os.chmod(tmp, os.stat(filename).st_mode & 0o7777)
            except OSError:
                pass
        else:
            um = os.umask(0)
            os.umask(um)
            os.chmod(tmp, 0o666 & ~um)
    except OSError:
        pass
    f = open(fd, mode, encoding=encoding, errors=errors)
    return _AtomicFile(f, tmp, filename)


def open_stream(filename, mode="r", encoding=None, errors="strict", atomic=False):
    binary = "b" in mode
    if os.fspath(filename) == "-" or filename == b"-":
        if any(m in mode for m in ("w", "a", "x")):
            stream = sys.stdout
        else:
            stream = sys.stdin
        if binary:
            return getattr(stream, "buffer", stream), False
        if encoding is not None:
            buf = getattr(stream, "buffer", None)
            if buf is not None:
                return _NonClosingText(buf, encoding=encoding, errors=errors,
                                       write_through=True), False
        return stream, False
    if atomic:
        return _open_atomic(filename, mode, encoding, errors), True
    if binary:
        return open(filename, mode), True
    return open(filename, mode, encoding=encoding, errors=errors), True


class LazyFile:
    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False):
        self.name = os.fspath(filename)
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self.should_close = True
        if self.name == "-":
            self._f, self.should_close = open_stream(filename, mode, encoding, errors)

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return getattr(self.open(), name)

    def __repr__(self):
        if self._f is not None:
            return repr(self._f)
        return f"<unopened file '{format_filename(self.name)}' {self.mode}>"

    def open(self):
        if self._f is not None:
            return self._f
        try:
            rv, self.should_close = open_stream(self.name, self.mode, self.encoding,
                                                self.errors, atomic=self.atomic)
        except OSError as e:
            from .exceptions import FileError
            raise FileError(self.name, hint=e.strerror) from e
        self._f = rv
        return rv

    def close(self):
        if self._f is not None:
            self._f.close()

    def close_intelligently(self):
        if self.should_close:
            self.close()

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close_intelligently()

    def __iter__(self):
        self.open()
        return iter(self._f)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    f, should_close = open_stream(filename, mode, encoding, errors, atomic=atomic)
    if not should_close:
        f = KeepOpenFile(f)
    return f


def make_str(value):
    if isinstance(value, bytes):
        try:
            return value.decode(sys.getfilesystemencoding())
        except UnicodeError:
            return value.decode("utf-8", "replace")
    return str(value)


def safecall(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception:
            pass
    return wrapper


def split_arg_string(string):
    import shlex
    lex = shlex.shlex(string, posix=True)
    lex.whitespace_split = True
    lex.commenters = ""
    out = []
    try:
        for token in lex:
            out.append(token)
    except ValueError:
        out.extend(lex.token and [lex.token] or [])
    return out
