"""Parameter types."""
import enum
import os
import stat
import sys
import uuid as _uuid
from datetime import datetime
from .exceptions import BadParameter, DeclarationError
from .utils import (format_filename, make_str, LazyFile, open_stream, safecall)


class ParamType:
    is_composite = False
    arity = 1
    name = ""
    envvar_list_splitter = None

    def __call__(self, value, param=None, ctx=None):
        if value is not None:
            return self.convert(value, param, ctx)

    def get_metavar(self, param):
        return None

    def get_missing_message(self, param):
        return None

    def convert(self, value, param=None, ctx=None):
        return value

    def split_envvar_value(self, rv):
        return (rv or "").split(self.envvar_list_splitter)

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def shell_complete(self, ctx, param, incomplete):
        return []


class FuncParamType(ParamType):
    def __init__(self, func):
        self.name = getattr(func, "__name__", "value")
        self.func = func

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except ValueError:
            try:
                value = str(value)
            except UnicodeError:
                value = value.decode("utf-8", "replace")
            self.fail(value, param, ctx)


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            enc = sys.getfilesystemencoding() or "utf-8"
            try:
                return value.decode(enc)
            except UnicodeError:
                return value.decode("utf-8", "replace")
        return str(value)

    def __repr__(self):
        return "STRING"


class _NumberBase(ParamType):
    _number_class = None

    def convert(self, value, param=None, ctx=None):
        try:
            return self._number_class(value)
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid {self.name}.", param, ctx)


class IntParamType(_NumberBase):
    name = "integer"
    _number_class = int

    def __repr__(self):
        return "INT"


class FloatParamType(_NumberBase):
    name = "float"
    _number_class = float

    def __repr__(self):
        return "FLOAT"


class _RangeBase(_NumberBase):
    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp
        if min is not None and max is not None and min > max:
            raise DeclarationError("'min' must not be greater than 'max'.")

    def convert(self, value, param=None, ctx=None):
        import operator
        rv = super().convert(value, param, ctx)
        lt_min = self.min is not None and (
            operator.le if self.min_open else operator.lt)(rv, self.min)
        gt_max = self.max is not None and (
            operator.ge if self.max_open else operator.gt)(rv, self.max)
        if self.clamp:
            if lt_min:
                return self._number_class(self.min)
            if gt_max:
                return self._number_class(self.max)
        if lt_min or gt_max:
            self.fail(f"{rv} is not in the range {self._describe_range()}.", param, ctx)
        return rv

    def _describe_range(self):
        if self.min is None:
            op = "<" if self.max_open else "<="
            return f"x{op}{self.max}"
        if self.max is None:
            op = ">" if self.min_open else ">="
            return f"x{op}{self.min}"
        lop = "<" if self.min_open else "<="
        rop = "<" if self.max_open else "<="
        return f"{self.min}{lop}x{rop}{self.max}"


class IntRange(_RangeBase):
    name = "integer range"
    _number_class = int


class FloatRange(_RangeBase):
    name = "float range"
    _number_class = float


class BoolParamType(ParamType):
    name = "boolean"
    TRUE = ("1", "true", "t", "yes", "y", "on")
    FALSE = ("0", "false", "f", "no", "n", "off")

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        norm = str(value).strip().lower()
        if norm in self.TRUE:
            return True
        if norm in self.FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)

    def __repr__(self):
        return "BOOL"


class UUIDParameterType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)

    def __repr__(self):
        return "UUID"


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value

    def __repr__(self):
        return "UNPROCESSED"


class Choice(ParamType):
    name = "choice"

    def __init__(self, choices, case_sensitive=None):
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self._enum = choices
            self.choices = list(choices)
            self._names = [m.name for m in choices]
            if case_sensitive is None:
                case_sensitive = False
        else:
            self._enum = None
            self.choices = list(choices)
            self._names = [c if isinstance(c, str) else str(c) for c in self.choices]
            if case_sensitive is None:
                case_sensitive = True
        self.case_sensitive = case_sensitive

    def get_metavar(self, param):
        s = "|".join(self._names)
        if getattr(param, "param_type_name", "") == "argument" and param.required:
            return f"{{{s}}}"
        return f"[{s}]"

    def get_missing_message(self, param):
        return "Choose from:\n\t" + ",\n\t".join(self._names)

    def convert(self, value, param=None, ctx=None):
        if self._enum is not None and isinstance(value, self._enum):
            return value
        if self._enum is None:
            for c in self.choices:
                if value is c or (type(value) is type(c) and value == c
                                  and not isinstance(c, str)):
                    return c
        norm = ctx.token_normalize_func if ctx is not None else None
        nv = value if isinstance(value, str) else str(value)
        mapping = {}
        for name, orig in zip(self._names, self.choices):
            key = norm(name) if norm else name
            if not self.case_sensitive:
                key = key.casefold()
            mapping.setdefault(key, orig)
        if norm:
            nv = norm(nv)
        if not self.case_sensitive:
            nv = nv.casefold()
        if nv in mapping:
            return mapping[nv]
        self.fail(f"{value!r} is not one of " + ", ".join(repr(n) for n in self._names) + ".",
                  param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem
        if not self.case_sensitive:
            inc = incomplete.casefold()
            return [CompletionItem(n) for n in self._names if n.casefold().startswith(inc)]
        return [CompletionItem(n) for n in self._names if n.startswith(incomplete)]

    def __repr__(self):
        return f"Choice({self.choices!r})"


class DateTime(ParamType):
    name = "datetime"
    DEFAULT_FORMATS = ["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(self.DEFAULT_FORMATS)

    def get_metavar(self, param):
        return f"[{'|'.join(self.formats)}]"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, datetime):
            return value
        result = None
        for fmt in self.formats:
            try:
                result = datetime.strptime(value, fmt)
            except (ValueError, TypeError):
                continue
        if result is not None:
            return result
        self.fail(f"{value!r} does not match the format(s) "
                  + ", ".join(repr(f) for f in self.formats) + ".", param, ctx)


class Tuple(ParamType):
    is_composite = True

    def __init__(self, types):
        self.types = [convert_type(ty) for ty in types]

    @property
    def name(self):
        return "<" + " ".join(ty.name for ty in self.types) + ">"

    @property
    def arity(self):
        return len(self.types)

    def convert(self, value, param=None, ctx=None):
        if len(value) != len(self.types):
            self.fail(f"{value!r} is not a tuple of length {len(self.types)}.", param, ctx)
        return tuple(ty(x, param, ctx) for ty, x in zip(self.types, value))


def _is_file_like(value):
    return hasattr(value, "read") or hasattr(value, "write")


class File(ParamType):
    name = "filename"
    envvar_list_splitter = os.path.pathsep

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def resolve_lazy_flag(self, value):
        if self.lazy is not None:
            return self.lazy
        if os.fspath(value) == "-":
            return False
        if "w" in self.mode:
            return True
        return False

    def convert(self, value, param=None, ctx=None):
        if _is_file_like(value):
            return value
        try:
            lazy = self.resolve_lazy_flag(value)
            if lazy:
                lf = LazyFile(value, self.mode, self.encoding, self.errors, atomic=self.atomic)
                if ctx is not None:
                    ctx.call_on_close(lf.close_intelligently)
                return lf
            f, should_close = open_stream(value, self.mode, self.encoding, self.errors,
                                          atomic=self.atomic)
            if ctx is not None:
                if should_close:
                    ctx.call_on_close(safecall(f.close))
                else:
                    ctx.call_on_close(safecall(f.flush))
            return f
        except OSError as e:
            self.fail(f"'{format_filename(value)}': {e.strerror}", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem
        return [CompletionItem(incomplete, type="file")]


class Path(ParamType):
    envvar_list_splitter = os.path.pathsep

    def __init__(self, exists=False, file_okay=True, dir_okay=True, writable=False,
                 readable=True, resolve_path=False, allow_dash=False, path_type=None,
                 executable=False):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.readable = readable
        self.writable = writable
        self.executable = executable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.type = path_type
        if self.file_okay and not self.dir_okay:
            self.name = "file"
        elif self.dir_okay and not self.file_okay:
            self.name = "directory"
        else:
            self.name = "path"

    def coerce_path_result(self, rv):
        if self.type is not None and not isinstance(rv, self.type):
            if self.type is str:
                rv = os.fsdecode(rv)
            elif self.type is bytes:
                rv = os.fsencode(rv)
            else:
                rv = self.type(rv)
        return rv

    def convert(self, value, param=None, ctx=None):
        rv = value
        is_dash = self.file_okay and self.allow_dash and rv in (b"-", "-")
        if not is_dash:
            if self.resolve_path:
                rv = os.path.realpath(os.path.expanduser(rv))
            try:
                st = os.stat(rv)
            except OSError:
                if not self.exists:
                    return self.coerce_path_result(rv)
                self.fail(f"{self.name.title()} {format_filename(value)!r} does not exist.",
                          param, ctx)
            nm = self.name.title()
            fn = format_filename(value)
            if not self.file_okay and stat.S_ISREG(st.st_mode):
                self.fail(f"{nm} {fn!r} is a file.", param, ctx)
            if not self.dir_okay and stat.S_ISDIR(st.st_mode):
                self.fail(f"{nm} {fn!r} is a directory.", param, ctx)
            if self.readable and not os.access(rv, os.R_OK):
                self.fail(f"{nm} {fn!r} is not readable.", param, ctx)
            if self.writable and not os.access(rv, os.W_OK):
                self.fail(f"{nm} {fn!r} is not writable.", param, ctx)
            if self.executable and not os.access(rv, os.X_OK):
                self.fail(f"{nm} {fn!r} is not executable.", param, ctx)
        return self.coerce_path_result(rv)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem
        t = "dir" if self.dir_okay and not self.file_okay else "file"
        return [CompletionItem(incomplete, type=t)]


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParameterType()
UNPROCESSED = UnprocessedParamType()


def convert_type(ty, default=None):
    guessed = False
    if ty is None and default is not None:
        if isinstance(default, (tuple, list)):
            if default:
                item = default[0]
                if isinstance(item, (tuple, list)):
                    ty = tuple(type(x) for x in item) if item else str
                else:
                    ty = type(item)
            else:
                ty = str
        else:
            ty = type(default)
        guessed = True
    if isinstance(ty, tuple):
        return Tuple(ty)
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    if ty is str or ty is None:
        return STRING
    if ty is int:
        return INT
    if ty is float:
        return FLOAT
    if ty is bool:
        return BOOL
    if guessed:
        return STRING
    return FuncParamType(ty)
