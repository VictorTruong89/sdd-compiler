"""Shell completion support."""
import os
import re

from .core import Argument, Command, Group, Option, ParameterSource
from .utils import split_arg_string


class CompletionItem:
    def __init__(self, value, type="plain", help=None, **kwargs):
        self.value = value
        self.type = type
        self.help = help
        self._info = kwargs

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return self._info.get(name)


_BASH = r'''
%(func)s() {
    local IFS=$'\n'
    local response
    response=$(env COMP_WORDS="${COMP_WORDS[*]}" COMP_CWORD=$COMP_CWORD %(var)s=bash_complete $1)
    for completion in $response; do
        IFS=',' read type value <<< "$completion"
        if [[ $type == 'dir' ]]; then
            COMPREPLY=()
            compopt -o dirnames
        elif [[ $type == 'file' ]]; then
            COMPREPLY=()
            compopt -o default
        elif [[ $type == 'plain' ]]; then
            COMPREPLY+=($value)
        fi
    done
    return 0
}

%(func)s_setup() {
    complete -o nosort -F %(func)s %(prog)s
}

%(func)s_setup;
'''

_ZSH = r'''
#compdef %(prog)s

%(func)s() {
    local -a completions
    local -a completions_with_descriptions
    local -a response
    (( ! $+commands[%(prog)s] )) && return 1

    response=("${(@f)$(env COMP_WORDS="${words[*]}" COMP_CWORD=$((CURRENT-1)) %(var)s=zsh_complete %(prog)s)}")

    for type key descr in ${response}; do
        if [[ "$type" == "plain" ]]; then
            if [[ "$descr" == "_" ]]; then
                completions+=("$key")
            else
                completions_with_descriptions+=("$key":"$descr")
            fi
        elif [[ "$type" == "dir" ]]; then
            _path_files -/
        elif [[ "$type" == "file" ]]; then
            _path_files -f
        fi
    done

    if [ -n "$completions_with_descriptions" ]; then
        _describe -V unsorted completions_with_descriptions -U
    fi

    if [ -n "$completions" ]; then
        compadd -U -V unsorted -a completions
    fi
}

if [[ $zsh_eval_context[-1] == loadautofunc ]]; then
    %(func)s "$@"
else
    compdef %(func)s %(prog)s
fi
'''

_FISH = r'''
function %(func)s;
    set -l response (env %(var)s=fish_complete COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -t) %(prog)s);

    for completion in $response;
        set -l metadata (string split "," $completion);

        if test $metadata[1] = "dir";
            __fish_complete_directories $metadata[2];
        else if test $metadata[1] = "file";
            __fish_complete_path $metadata[2];
        else if test $metadata[1] = "plain";
            echo $metadata[2];
        end;
    end;
end;

complete --no-files --command %(prog)s --arguments "(%(func)s)";
'''

_POWERSHELL = r'''
Register-ArgumentCompleter -Native -CommandName %(prog)s -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)

    $env:COMP_WORDS = $commandAst
    $env:COMP_WORDS = $env:COMP_WORDS.replace('\\', '/')
    $incompleteCommand = $commandAst.ToString()

    $myCursorPosition = $cursorPosition
    if ($myCursorPosition -gt $incompleteCommand.Length) {
        $myCursorPosition = $incompleteCommand.Length
    }
    $env:COMP_CWORD = @($incompleteCommand.substring(0, $myCursorPosition).Split(" ") | Where-Object { $_ -ne "" }).Length
    if ($wordToComplete -eq "") { $env:COMP_CWORD = [int]$env:COMP_CWORD }
    $env:%(var)s = "powershell_complete"

    %(prog)s | ForEach-Object {
        $type, $value, $help = $_.Split(",", 3)
        if ( ($type -eq "plain") -and ("" -ne $value) ) {
            [System.Management.Automation.CompletionResult]::new($value, $value, "ParameterValue", $value)
        } elseif ( ($type -eq "file") -or ($type -eq "dir") ) {
            [System.Management.Automation.CompletionResult]::new($wordToComplete, $wordToComplete, "ParameterValue", $wordToComplete)
        }
    }
    $env:%(var)s = ""
}
'''


class ShellComplete:
    name = ""
    source_template = ""

    def __init__(self, cli, ctx_args, prog_name, complete_var):
        self.cli = cli
        self.ctx_args = ctx_args
        self.prog_name = prog_name
        self.complete_var = complete_var

    @property
    def func_name(self):
        safe = re.sub(r"\W*", "", self.prog_name.replace("-", "_"), flags=re.ASCII)
        return f"_{safe}_completion"

    def source(self):
        return self.source_template % {"func": self.func_name, "var": self.complete_var,
                                       "prog": self.prog_name}

    def get_completion_args(self):
        raise NotImplementedError

    def get_completions(self, args, incomplete):
        ctx = _resolve_context(self.cli, dict(self.ctx_args), self.prog_name, args)
        obj, incomplete = _resolve_incomplete(ctx, args, incomplete)
        return obj.shell_complete(ctx, incomplete)

    def format_completion(self, item):
        raise NotImplementedError

    def complete(self):
        args, incomplete = self.get_completion_args()
        completions = self.get_completions(args, incomplete)
        return "\n".join(self.format_completion(item) for item in completions)


class _BashLike(ShellComplete):
    def get_completion_args(self):
        cwords = split_arg_string(os.environ.get("COMP_WORDS", ""))
        try:
            cword = int(os.environ.get("COMP_CWORD", ""))
        except ValueError:
            cword = len(cwords)
        args = cwords[1:cword]
        try:
            incomplete = cwords[cword]
        except IndexError:
            incomplete = ""
        return args, incomplete


class BashComplete(_BashLike):
    name = "bash"
    source_template = _BASH

    def format_completion(self, item):
        return f"{item.type},{item.value}"


class ZshComplete(_BashLike):
    name = "zsh"
    source_template = _ZSH

    def format_completion(self, item):
        return f"{item.type}\n{item.value}\n{item.help if item.help else '_'}"


class PowerShellComplete(_BashLike):
    name = "powershell"
    source_template = _POWERSHELL

    def format_completion(self, item):
        return f"{item.type},{item.value}"


class FishComplete(ShellComplete):
    name = "fish"
    source_template = _FISH

    def get_completion_args(self):
        cwords = split_arg_string(os.environ.get("COMP_WORDS", ""))
        incomplete = os.environ.get("COMP_CWORD", "")
        args = cwords[1:]
        if incomplete and args and args[-1] == incomplete:
            args.pop()
        return args, incomplete

    def format_completion(self, item):
        if item.help:
            return f"{item.type},{item.value}\t{item.help}"
        return f"{item.type},{item.value}"


_REGISTRY = {"bash": BashComplete, "zsh": ZshComplete, "fish": FishComplete,
             "powershell": PowerShellComplete}


def shell_complete(cli, ctx_args, prog_name, complete_var, instruction):
    import sys
    shell, _, instr = instruction.partition("_")
    cls = _REGISTRY.get(shell)
    if cls is None or instr not in ("source", "complete"):
        return 1
    comp = cls(cli, ctx_args, prog_name, complete_var)
    if instr == "source":
        out = comp.source()
    else:
        out = comp.complete()
    sys.stdout.write(out)
    sys.stdout.flush()
    return 0


def _resolve_context(cli, ctx_args, prog_name, args):
    ctx_args["resilient_parsing"] = True
    ctx = cli.make_context(prog_name, list(args), **ctx_args)
    args = ctx.protected_args + ctx.args
    while args:
        command = ctx.command
        if isinstance(command, Group):
            if not command.chain:
                name, cmd, args = command.resolve_command(ctx, args)
                if cmd is None:
                    return ctx
                ctx = cmd.make_context(name, args, parent=ctx, resilient_parsing=True)
                args = ctx.protected_args + ctx.args
            else:
                sub_ctx = ctx
                while args:
                    name, cmd, args = command.resolve_command(ctx, args)
                    if cmd is None:
                        return ctx
                    sub_ctx = cmd.make_context(name, args, parent=ctx, allow_extra_args=True,
                                               allow_interspersed_args=False,
                                               resilient_parsing=True)
                    args = sub_ctx.args
                ctx = sub_ctx
                args = [*sub_ctx.protected_args, *sub_ctx.args]
        else:
            break
    return ctx


def _start_of_option(ctx, value):
    if not value:
        return False
    return value[0] in ctx._opt_prefixes or not value[0].isalnum() and value[0] in "-+/"


def _is_incomplete_option(ctx, args, param):
    if not isinstance(param, Option):
        return False
    if param.is_flag or param.count:
        return False
    last = None
    for index, arg in enumerate(reversed(args)):
        if index + 1 > param.nargs:
            break
        if _start_of_option(ctx, arg):
            last = arg
    return last is not None and last in param.opts


def _is_incomplete_argument(ctx, param):
    if not isinstance(param, Argument):
        return False
    value = ctx.params.get(param.name)
    return (param.nargs == -1
            or ctx.get_parameter_source(param.name) is not ParameterSource.COMMANDLINE
            or (param.nargs > 1 and isinstance(value, (tuple, list))
                and len(value) < param.nargs))


def _resolve_incomplete(ctx, args, incomplete):
    if "=" in incomplete:
        name, _, incomplete = incomplete.partition("=")
        args = list(args) + [name]
    if "--" in args:
        return ctx.command, incomplete
    params = ctx.command.get_params(ctx)
    for param in params:
        if _is_incomplete_option(ctx, args, param):
            return param, incomplete
    for param in params:
        if _is_incomplete_argument(ctx, param):
            return param, incomplete
    return ctx.command, incomplete
