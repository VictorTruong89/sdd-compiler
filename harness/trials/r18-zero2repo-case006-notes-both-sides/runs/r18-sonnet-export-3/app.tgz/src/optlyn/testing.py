"""In-process runner."""
import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile

from . import termui, utils


class _Tee(io.RawIOBase):
    def __init__(self, own, mix):
        self.own = own
        self.mix = mix

    def writable(self):
        return True

    def write(self, b):
        b = bytes(b)
        self.own.write(b)
        self.mix.write(b)
        return len(b)

    def flush(self):
        pass


class _OutStream(io.TextIOWrapper):
    def __init__(self, tee, charset, name, fake_fd=None):
        super().__init__(tee, encoding=charset, errors="backslashreplace",
                         write_through=True)
        self._name = name
        self._fake_fd = fake_fd

    @property
    def name(self):
        return self._name

    def fileno(self):
        if self._fake_fd is not None:
            return self._fake_fd
        raise io.UnsupportedOperation("fileno")

    def close(self):
        pass


class _EchoingStdin:
    def __init__(self, input, output):
        self._input = input
        self._output = output
        self._paused = False

    def __getattr__(self, x):
        return getattr(self._input, x)

    def _echo(self, rv):
        if not self._paused:
            self._output.write(rv)
        return rv

    def read(self, n=-1):
        return self._echo(self._input.read(n))

    def read1(self, n=-1):
        return self._echo(self._input.read1(n))

    def readline(self, n=-1):
        return self._echo(self._input.readline(n))

    def readlines(self):
        return [self._echo(x) for x in self._input.readlines()]

    def __iter__(self):
        return iter(self._echo(x) for x in self._input)


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value,
                 exit_code, exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self):
        return self.output_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    def __repr__(self):
        exc = repr(self.exception) if self.exception else "okay"
        return f"<Result {exc}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        self.charset = charset
        self.env = dict(env) if env else {}
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def make_env(self, overrides=None):
        rv = dict(self.env)
        if overrides:
            rv.update(overrides)
        return rv

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        else:
            data = bytes(input)
        env = self.make_env(env)
        old_stdin, old_stdout, old_stderr = sys.stdin, sys.stdout, sys.stderr
        old_funcs = (termui.visible_prompt_func, termui.hidden_prompt_func,
                     termui._getchar, utils.should_strip_ansi)
        bytes_in = io.BytesIO(data)
        mix = io.BytesIO()
        out_own = io.BytesIO()
        err_own = io.BytesIO()
        if self.echo_stdin:
            bytes_input = _EchoingStdin(bytes_in, mix)
        else:
            bytes_input = bytes_in
        text_in = io.TextIOWrapper(bytes_input, encoding=self.charset)
        fd_mode = self.capture == "fd"
        stdout = _OutStream(_Tee(out_own, mix), self.charset, "<stdout>", 1 if fd_mode else None)
        stderr = _OutStream(_Tee(err_own, mix), self.charset, "<stderr>", 2 if fd_mode else None)
        saved_fds = None
        fd_files = None
        if fd_mode:
            try:
                sys.__stdout__.flush()
                sys.__stderr__.flush()
            except Exception:
                pass
            fd_files = (tempfile.TemporaryFile(), tempfile.TemporaryFile())
            saved_fds = (os.dup(1), os.dup(2))
            os.dup2(fd_files[0].fileno(), 1)
            os.dup2(fd_files[1].fileno(), 2)

        def visible_input(prompt=None):
            sys.stdout.write(prompt or "")
            if isinstance(bytes_input, _EchoingStdin):
                bytes_input._paused = True
            try:
                line = text_in.readline()
            finally:
                if isinstance(bytes_input, _EchoingStdin):
                    bytes_input._paused = False
            if line == "":
                raise EOFError()
            val = line.rstrip("\r\n")
            sys.stdout.write(f"{val}\n")
            sys.stdout.flush()
            return val

        def hidden_input(prompt=None):
            sys.stdout.write(f"{prompt or ''}\n")
            sys.stdout.flush()
            if isinstance(bytes_input, _EchoingStdin):
                bytes_input._paused = True
            try:
                line = text_in.readline()
            finally:
                if isinstance(bytes_input, _EchoingStdin):
                    bytes_input._paused = False
            if line == "":
                raise EOFError()
            return line.rstrip("\r\n")

        def _getchar(echo=False):
            ch = text_in.read(1)
            if ch == "":
                raise EOFError()
            if echo:
                sys.stdout.write(ch)
                sys.stdout.flush()
            if ch == "\x03":
                raise KeyboardInterrupt()
            if ch == "\x04":
                raise EOFError()
            return ch

        def should_strip_ansi(stream=None, color_=None):
            if color_ is None:
                return not color
            return not color_

        sys.stdin = text_in
        sys.stdout = stdout
        sys.stderr = stderr
        termui.visible_prompt_func = visible_input
        termui.hidden_prompt_func = hidden_input
        termui._getchar = _getchar
        utils.should_strip_ansi = should_strip_ansi
        old_env = {}
        try:
            for key, value in env.items():
                old_env[key] = os.environ.get(key)
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            yield (out_own, err_own, mix)
        finally:
            try:
                stdout.flush()
                stderr.flush()
            except Exception:
                pass
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            if fd_mode:
                os.dup2(saved_fds[0], 1)
                os.dup2(saved_fds[1], 2)
                os.close(saved_fds[0])
                os.close(saved_fds[1])
                for f, own in zip(fd_files, (out_own, err_own)):
                    f.seek(0)
                    data = f.read()
                    f.close()
                    own.write(data)
                    mix.write(data)
            sys.stdin, sys.stdout, sys.stderr = old_stdin, old_stdout, old_stderr
            (termui.visible_prompt_func, termui.hidden_prompt_func,
             termui._getchar, utils.should_strip_ansi) = old_funcs

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None,
               color=False, **extra):
        exc_info = None
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        return_value = None
        exception = None
        exit_code = 0
        with self.isolation(input=input, env=env, color=color) as (out_own, err_own, mix):
            if isinstance(args, str):
                args = shlex.split(args)
            prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
            try:
                return_value = cli.main(args=args or [], prog_name=prog_name, **extra)
            except SystemExit as e:
                exc_info = sys.exc_info()
                code = e.code
                if code is None:
                    code = 0
                if code != 0:
                    exception = e
                if not isinstance(code, int):
                    sys.stdout.write(str(code))
                    sys.stdout.write("\n")
                    code = 1
                exit_code = code
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                try:
                    sys.stdout.flush()
                    sys.stderr.flush()
                except Exception:
                    pass
        # fd data is appended in isolation's finally; read after
        return Result(self, out_own.getvalue(), err_own.getvalue(), mix.getvalue(),
                      return_value, exit_code, exception, exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass
