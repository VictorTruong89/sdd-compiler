"""Core: Context, parameters, commands, groups."""
import errno
import inspect
import os
import sys
from contextlib import ExitStack, contextmanager
from enum import Enum
from functools import update_wrapper

from . import types
from .exceptions import (Abort, BadParameter, DeclarationError, Exit, MissingParameter,
                         NoArgsIsHelpError, OptlynException, UsageError)
from .formatting import HelpFormatter, join_options, make_default_short_help, split_opt
from .globals import get_current_context, pop_context, push_context
from .parser import FLAG_NEEDS_VALUE, OptionParser
from .utils import echo, make_str, style

_UNSET = object()


class ParameterSource(Enum):
    COMMANDLINE = 1
    ENVIRONMENT = 2
    DEFAULT = 3
    DEFAULT_MAP = 4
    PROMPT = 5


_SOURCE_RANK = {
    ParameterSource.DEFAULT: 1,
    ParameterSource.ENVIRONMENT: 2,
    ParameterSource.DEFAULT_MAP: 3,
    ParameterSource.COMMANDLINE: 4,
    ParameterSource.PROMPT: 5,
}


@contextmanager
def augment_usage_errors(ctx, param=None):
    try:
        yield
    except BadParameter as e:
        if e.ctx is None:
            e.ctx = ctx
        if param is not None and e.param is None:
            e.param = param
        raise
    except UsageError as e:
        if e.ctx is None:
            e.ctx = ctx
        raise


def iter_params_for_processing(invocation_order, declaration_order):
    def sort_key(item):
        try:
            idx = invocation_order.index(item)
        except ValueError:
            idx = float("inf")
        return (not item.is_eager, idx)
    return sorted(declaration_order, key=sort_key)


def _check_chain(base, cmd_name, cmd):
    if not getattr(base, "chain", False) or not isinstance(cmd, Group):
        return
    raise RuntimeError(
        f"{base.__class__.__name__} is set to chain and {cmd_name!r} was added "
        f"as a subcommand but it in itself is a group. Chained groups cannot "
        f"nest other groups.")


class Context:
    formatter_class = HelpFormatter

    def __init__(self, command, parent=None, info_name=None, obj=None,
                 auto_envvar_prefix=None, default_map=None, terminal_width=None,
                 max_content_width=None, resilient_parsing=False,
                 allow_extra_args=None, allow_interspersed_args=None,
                 ignore_unknown_options=None, help_option_names=None,
                 token_normalize_func=None, color=None, show_default=None):
        self.parent = parent
        self.command = command
        self.info_name = info_name
        self.params = {}
        self.args = []
        self.protected_args = []
        self._opt_prefixes = set(parent._opt_prefixes) if parent else set()
        if obj is None and parent is not None:
            obj = parent.obj
        self.obj = obj
        self._meta = getattr(parent, "meta", {}) if parent is not None else {}
        if default_map is None and info_name is not None and parent is not None \
                and parent.default_map is not None:
            default_map = parent.default_map.get(info_name)
        self.default_map = default_map
        self.invoked_subcommand = None
        if terminal_width is None and parent is not None:
            terminal_width = parent.terminal_width
        self.terminal_width = terminal_width
        if max_content_width is None and parent is not None:
            max_content_width = parent.max_content_width
        self.max_content_width = max_content_width
        if allow_extra_args is None:
            allow_extra_args = command.allow_extra_args
        self.allow_extra_args = allow_extra_args
        if allow_interspersed_args is None:
            allow_interspersed_args = command.allow_interspersed_args
        self.allow_interspersed_args = allow_interspersed_args
        if ignore_unknown_options is None:
            ignore_unknown_options = command.ignore_unknown_options
        self.ignore_unknown_options = ignore_unknown_options
        if help_option_names is None:
            help_option_names = parent.help_option_names if parent is not None else ["--help"]
        self.help_option_names = list(help_option_names)
        if token_normalize_func is None and parent is not None:
            token_normalize_func = parent.token_normalize_func
        self.token_normalize_func = token_normalize_func
        self.resilient_parsing = resilient_parsing
        if auto_envvar_prefix is None:
            if (parent is not None and parent.auto_envvar_prefix is not None
                    and self.info_name is not None):
                auto_envvar_prefix = f"{parent.auto_envvar_prefix}_{self.info_name.upper()}"
        else:
            auto_envvar_prefix = auto_envvar_prefix.upper()
        if auto_envvar_prefix is not None:
            auto_envvar_prefix = auto_envvar_prefix.replace("-", "_")
        self.auto_envvar_prefix = auto_envvar_prefix
        if color is None and parent is not None:
            color = parent.color
        self.color = color
        if show_default is None and parent is not None:
            show_default = parent.show_default
        self.show_default = show_default
        self._close_callbacks = []
        self._depth = 0
        self._parameter_source = {}
        self._param_rank = {}
        self._exit_stack = ExitStack()

    @property
    def meta(self):
        return self._meta

    def __enter__(self):
        self._depth += 1
        push_context(self)
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self._depth -= 1
        if self._depth == 0:
            self.close()
        pop_context()

    @contextmanager
    def scope(self, cleanup=True):
        if not cleanup:
            self._depth += 1
        try:
            with self as rv:
                yield rv
        finally:
            if not cleanup:
                self._depth -= 1

    def with_resource(self, context_manager):
        return self._exit_stack.enter_context(context_manager)

    def call_on_close(self, f):
        return self._exit_stack.callback(f)

    def close(self):
        self._exit_stack.close()
        self._exit_stack = ExitStack()

    @property
    def command_path(self):
        rv = ""
        if self.info_name is not None:
            rv = self.info_name
        if self.parent is not None:
            parts = [self.parent.command_path]
            if isinstance(self.parent.command, Command):
                for param in self.parent.command.get_params(self):
                    parts.extend(param.get_usage_pieces(self))
            rv = f"{' '.join(parts)} {rv}"
        return rv.lstrip()

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type):
        node = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        rv = self.find_object(object_type)
        if rv is None:
            self.obj = rv = object_type()
        return rv

    def lookup_default(self, name, call=True):
        if self.default_map is not None:
            value = self.default_map.get(name)
            if call and callable(value):
                return value()
            return value
        return None

    def fail(self, message):
        raise UsageError(message, self)

    def abort(self):
        raise Abort()

    def exit(self, code=0):
        raise Exit(code)

    def make_formatter(self):
        return self.formatter_class(width=self.terminal_width, max_width=self.max_content_width)

    def get_usage(self):
        return self.command.get_usage(self)

    def get_help(self):
        return self.command.get_help(self)

    def set_parameter_source(self, name, source):
        self._parameter_source[name] = source

    def get_parameter_source(self, name):
        return self._parameter_source.get(name)

    def _make_sub_context(self, command):
        return type(self)(command, info_name=command.name, parent=self)

    def invoke(self, callback, *args, **kwargs):
        if isinstance(callback, Command):
            other = callback
            if other.callback is None:
                raise TypeError("The given command has no callback to invoke.")
            callback = other.callback
            ctx = self._make_sub_context(other)
            for param in other.params:
                if param.name not in kwargs and param.expose_value:
                    kwargs[param.name] = param.type_cast_value(ctx, param.get_default(ctx))
            ctx.params.update(kwargs)
        else:
            ctx = self
        with augment_usage_errors(self):
            with ctx:
                return callback(*args, **kwargs)

    def forward(self, cmd, *args, **kwargs):
        if not isinstance(cmd, Command):
            raise TypeError("Callback is not a command.")
        for key, value in self.params.items():
            if key not in kwargs:
                kwargs[key] = value
        return self.invoke(cmd, *args, **kwargs)


# ------------------------------------------------------------ parameters

class Parameter:
    param_type_name = "parameter"

    def __init__(self, param_decls=None, type=None, required=False, default=None,
                 callback=None, nargs=None, multiple=False, metavar=None, expose_value=True,
                 is_eager=False, envvar=None, shell_complete=None, deprecated=False,
                 help=None, hidden=False):
        self.name, self.opts, self.secondary_opts = self._parse_decls(
            param_decls or (), expose_value)
        self.type = types.convert_type(type, default)
        if nargs is None:
            nargs = self.type.arity if self.type.is_composite else 1
        self.required = required
        self.callback = callback
        self.nargs = nargs
        self.multiple = multiple
        self.expose_value = expose_value
        self.default = default
        self.is_eager = is_eager
        self.metavar = metavar
        self.envvar = envvar
        self._custom_shell_complete = shell_complete
        self.deprecated = deprecated
        self.help = help
        self.hidden = hidden
        if self.type.is_composite and nargs != self.type.arity:
            raise DeclarationError(
                f"'nargs' must be {self.type.arity} (or None) for type {self.type!r}, "
                f"but it was {nargs}.")

    @property
    def human_readable_name(self):
        return self.name

    def make_metavar(self):
        if self.metavar is not None:
            return self.metavar
        metavar = self.type.get_metavar(self)
        if metavar is None:
            metavar = self.type.name.upper()
        if self.nargs != 1:
            metavar += "..."
        return metavar

    def get_default(self, ctx, call=True):
        value = ctx.lookup_default(self.name, call=False)
        if value is None:
            value = self.default
        if call and callable(value):
            value = value()
        return value

    def add_to_parser(self, parser, ctx):
        raise NotImplementedError

    def get_usage_pieces(self, ctx):
        return []

    def get_error_hint(self, ctx):
        hint_list = self.opts or [self.human_readable_name]
        return " / ".join(repr(x) for x in hint_list)

    def resolve_envvar_value(self, ctx):
        if self.envvar is None:
            return None
        if isinstance(self.envvar, str):
            rv = os.environ.get(self.envvar)
            return rv if rv else None
        result = None
        for name in self.envvar:
            rv = os.environ.get(name)
            if rv:
                result = rv
        return result

    def value_from_envvar(self, ctx):
        rv = self.resolve_envvar_value(ctx)
        if rv is not None and self.nargs != 1:
            rv = self.type.split_envvar_value(rv)
        return rv

    def _lookup_map(self, ctx):
        value = ctx.lookup_default(self.name)
        if isinstance(value, str) and (self.nargs != 1 or self.type.is_composite):
            value = self.type.split_envvar_value(value)
        return value

    def consume_value(self, ctx, opts):
        value = opts.get(self.name)
        source = ParameterSource.COMMANDLINE
        if value is None:
            value = self._lookup_map(ctx)
            source = ParameterSource.DEFAULT_MAP
        if value is None:
            value = self.value_from_envvar(ctx)
            source = ParameterSource.ENVIRONMENT
        if value is None:
            value = self.get_default(ctx)
            source = ParameterSource.DEFAULT
        return value, source

    def type_cast_value(self, ctx, value):
        if value is None:
            return () if (self.multiple or self.nargs == -1) else None

        def check_iter(v):
            if isinstance(v, (str, bytes)):
                raise BadParameter(
                    "Value must be an iterable sequence (list or tuple), "
                    "not a plain string.", ctx=ctx, param=self)
            try:
                return iter(v)
            except TypeError:
                raise BadParameter("Value must be an iterable sequence.",
                                   ctx=ctx, param=self) from None

        if self.nargs == 1 or self.type.is_composite:
            def convert(v):
                return self.type(v, param=self, ctx=ctx)
        elif self.nargs == -1:
            def convert(v):
                return tuple(self.type(x, self, ctx) for x in check_iter(v))
        else:
            def convert(v):
                items = tuple(check_iter(v))
                if len(items) != self.nargs:
                    raise BadParameter(
                        f"Takes {self.nargs} values but {len(items)} given.",
                        ctx=ctx, param=self)
                return tuple(self.type(x, self, ctx) for x in items)

        if self.multiple:
            return tuple(convert(x) for x in check_iter(value))
        return convert(value)

    def value_is_missing(self, value):
        if value is None:
            return True
        if (self.nargs != 1 or self.multiple) and value == ():
            return True
        return False

    def process_value(self, ctx, value):
        value = self.type_cast_value(ctx, value)
        if self.required and self.value_is_missing(value):
            raise MissingParameter(ctx=ctx, param=self)
        if self.callback is not None:
            value = self.callback(ctx, self, value)
        return value

    def _warn_deprecated(self, ctx):
        msg = f"DeprecationWarning: The {self.param_type_name} {self._dep_name()!r} is deprecated."
        if isinstance(self.deprecated, str):
            msg += f" {self.deprecated}"
        echo(style(msg, fg="red"), err=True)

    def _dep_name(self):
        return self.opts[0] if self.opts else self.name

    def handle_parse_result(self, ctx, opts, args):
        with augment_usage_errors(ctx, param=self):
            value, source = self.consume_value(ctx, opts)
            prev = ctx._parameter_source.get(self.name)
            ctx.set_parameter_source(self.name, source)
            if self.deprecated and source in (ParameterSource.COMMANDLINE,
                                              ParameterSource.ENVIRONMENT,
                                              ParameterSource.PROMPT):
                self._warn_deprecated(ctx)
            try:
                value = self.process_value(ctx, value)
            except Exception:
                if not ctx.resilient_parsing:
                    raise
                value = None
        explicit = 1 if getattr(self, "_default_explicit", True) else 0
        key = (_SOURCE_RANK[source], explicit if source is ParameterSource.DEFAULT else 0)
        old = ctx._param_rank.get(self.name)
        if old is not None and key < old:
            ctx._parameter_source[self.name] = prev
            return value, args
        ctx._param_rank[self.name] = key
        if self.expose_value:
            ctx.params[self.name] = value
        return value, args

    def shell_complete(self, ctx, incomplete):
        from .shell_completion import CompletionItem
        if self._custom_shell_complete is not None:
            results = self._custom_shell_complete(ctx, self, incomplete)
            if results and isinstance(results[0], str):
                results = [CompletionItem(c) for c in results]
            return list(results or [])
        return self.type.shell_complete(ctx, self, incomplete)


class Option(Parameter):
    param_type_name = "option"

    def __init__(self, param_decls=None, show_default=None, prompt=False,
                 confirmation_prompt=False, prompt_required=True, hide_input=False,
                 is_flag=None, flag_value=_UNSET, multiple=False, count=False,
                 allow_from_autoenv=True, type=None, help=None, hidden=False,
                 show_choices=True, show_envvar=False, deprecated=False, default=_UNSET,
                 nargs=None, required=False, **attrs):
        if prompt is True:
            if attrs.get("expose_value", True) is False and not param_decls:
                raise DeclarationError("Prompt needs a name")
            prompt_text = True
        elif prompt is False or prompt is None:
            prompt_text = None
        else:
            prompt_text = str(prompt)
        self._default_explicit = default is not _UNSET
        flag_given = flag_value is not _UNSET
        default_v = None if default is _UNSET else default
        # decls (needed early for secondary opts)
        name, opts, secondary = self._parse_decls(param_decls or (), attrs.get("expose_value", True))
        if deprecated and required:
            raise DeclarationError("A deprecated option cannot be required.")
        if deprecated and prompt_text is not None:
            raise DeclarationError("A deprecated option cannot use a prompt.")
        flag_needs_value = False
        if is_flag is None:
            if flag_given:
                is_flag = True
            else:
                is_flag = bool(secondary)
        elif is_flag is False and flag_given:
            flag_needs_value = True
        if prompt_text is not None and not prompt_required and not is_flag:
            flag_needs_value = True
        if is_flag and secondary and not flag_given:
            flag_value = True
        if is_flag and not flag_given:
            flag_value = True
        if not flag_given and not is_flag and not flag_needs_value:
            flag_value = None
        if is_flag and default_v is True and flag_given and not isinstance(flag_value, bool):
            default_v = flag_value
        if is_flag and not self._default_explicit and not required:
            default_v = () if multiple else False
        if count:
            if type is None:
                type = types.IntRange(min=0)
        if type is None and is_flag:
            type = types.BOOL if isinstance(flag_value, bool) else types.UNPROCESSED
        infer = default_v
        if callable(default_v):
            infer = None
        elif multiple and isinstance(default_v, (list, tuple)):
            infer = default_v[0] if default_v else None
        super().__init__(param_decls, type=type if type is not None else
                         types.convert_type(None, infer),
                         required=required, default=default_v, nargs=nargs,
                         multiple=multiple, deprecated=deprecated, help=help,
                         hidden=hidden, **attrs)
        self.prompt = prompt_text
        if self.prompt is True:
            self.prompt = (self.name or "").replace("_", " ").capitalize()
        self.confirmation_prompt = confirmation_prompt
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.hidden = hidden
        self.is_flag = is_flag
        self.is_bool_flag = bool(is_flag and isinstance(self.type, types.BoolParamType))
        self.flag_value = flag_value if flag_value is not _UNSET else None
        self._flag_needs_value = flag_needs_value
        self.count = count
        self.allow_from_autoenv = allow_from_autoenv
        self.show_default = show_default
        self.show_choices = show_choices
        self.show_envvar = show_envvar
        if self.nargs == -1 or (self.nargs is not None and self.nargs < 1):
            raise DeclarationError("'nargs' must be a positive integer for options.")
        if self.count:
            if self.multiple:
                raise DeclarationError("'count' is not valid with 'multiple'.")
            if self.is_flag:
                raise DeclarationError("'count' is not valid with 'is_flag'.")
        if self.multiple and self.is_flag:
            raise DeclarationError("'multiple' is not valid with 'is_flag', use 'count'.")
        if self.is_flag and self.nargs != 1:
            raise DeclarationError("'nargs' must be 1 for flags.")

    def _parse_decls(self, decls, expose_value):
        opts = []
        secondary_opts = []
        name = None
        possible = []
        for decl in decls:
            if decl.isidentifier():
                if name is not None:
                    raise DeclarationError(f"Name {name!r} defined twice")
                name = decl
            else:
                split_char = ";" if decl[:1] == "/" else "/"
                if split_char in decl:
                    first, second = decl.split(split_char, 1)
                    first = first.rstrip()
                    if first:
                        possible.append(split_opt(first))
                        opts.append(first)
                    second = second.lstrip()
                    if second:
                        secondary_opts.append(second)
                    if first == second:
                        raise DeclarationError(
                            f"Boolean option {decl!r} cannot use the same flag for true/false.")
                else:
                    possible.append(split_opt(decl))
                    opts.append(decl)
        if name is None and possible:
            possible.sort(key=lambda x: -len(x[0]))
            name = possible[0][1].replace("-", "_").lower()
            if not name.isidentifier():
                name = None
        if name is None:
            if not expose_value:
                return None, opts, secondary_opts
            raise DeclarationError("Could not determine name for option")
        if not opts and not secondary_opts:
            raise DeclarationError(
                f"No options defined but a name was passed ({name}).")
        return name, opts, secondary_opts

    def add_to_parser(self, parser, ctx):
        if self.multiple:
            action = "append"
        elif self.count:
            action = "count"
        else:
            action = "store"
        if self.is_flag:
            action = f"{action}_const"
            if self.is_bool_flag and self.secondary_opts:
                parser.add_option(obj=self, opts=self.opts, dest=self.name,
                                  action=action, const=True)
                parser.add_option(obj=self, opts=self.secondary_opts, dest=self.name,
                                  action=action, const=False)
            else:
                parser.add_option(obj=self, opts=self.opts, dest=self.name,
                                  action=action, const=self.flag_value)
        else:
            parser.add_option(obj=self, opts=self.opts, dest=self.name,
                              action=action, nargs=self.nargs)

    def _dep_name(self):
        return self.opts[0] if self.opts else self.name

    def get_error_hint(self, ctx):
        hints = list(self.opts) + list(self.secondary_opts)
        return " / ".join(repr(x) for x in hints)

    def make_metavar(self):
        return super().make_metavar()

    def get_help_record(self, ctx):
        if self.hidden:
            return None
        any_slash = False

        def write_opts(opts):
            nonlocal any_slash
            rv, slash = join_options(opts)
            if slash:
                any_slash = True
            if not self.is_flag and not self.count:
                rv += f" {self.make_metavar()}"
            return rv

        rv = [write_opts(self.opts)]
        if self.secondary_opts:
            rv.append(write_opts(self.secondary_opts))
        help = self.help or ""
        extra = []
        if self.show_envvar:
            envvar = self.envvar
            if envvar is None and self.allow_from_autoenv and \
                    ctx.auto_envvar_prefix is not None and self.name is not None:
                envvar = f"{ctx.auto_envvar_prefix}_{self.name.upper()}"
            if envvar is not None:
                names = envvar if isinstance(envvar, str) else ", ".join(envvar)
                extra.append(f"env var: {names}")
        default_value = self.get_default(ctx, call=False)
        show_default = False
        is_str = False
        if self.show_default is not None:
            if isinstance(self.show_default, str):
                is_str = show_default = True
            else:
                show_default = self.show_default
        elif ctx.show_default is not None:
            show_default = ctx.show_default
        if is_str or (show_default and (default_value is not None or self.is_flag)):
            if is_str:
                ds = f"({self.show_default})"
            elif isinstance(default_value, (list, tuple)):
                ds = ", ".join(str(d) for d in default_value)
            elif inspect.isfunction(default_value):
                ds = "(dynamic)"
            elif self.is_bool_flag and self.secondary_opts:
                ds = split_opt((self.opts if default_value else self.secondary_opts)[0])[1]
            else:
                ds = str(default_value)
            if ds != "" or is_str:
                extra.append(f"default: {ds}")
        rng = getattr(self.type, "_describe_range", None)
        if rng is not None:
            r = rng()
            if r:
                extra.append(r)
        if self.required:
            extra.append("required")
        if self.deprecated:
            note = f": {self.deprecated}" if isinstance(self.deprecated, str) else ""
            help = f"(DEPRECATED{note}) {help}".rstrip()
        if extra:
            es = "; ".join(extra)
            help = f"{help}  [{es}]" if help else f"[{es}]"
        return ("; " if any_slash else " / ").join(rv), help

    def _flag_env(self, rv):
        from .types import BoolParamType
        s = rv.strip().lower()
        is_bool = isinstance(self.flag_value, bool)
        on = self.flag_value
        off = (not self.flag_value) if is_bool else False
        if is_bool:
            if s == "":
                return off
            if s in BoolParamType.TRUE:
                return on
            if s in BoolParamType.FALSE:
                return off
            raise BadParameter(f"{rv!r} is not a valid boolean.", param=self)
        if rv == str(self.flag_value):
            return on
        if s in BoolParamType.TRUE:
            return on
        if s in BoolParamType.FALSE:
            return off
        return None

    def resolve_envvar_value(self, ctx):
        rv = super().resolve_envvar_value(ctx)
        if rv is not None:
            return rv
        if self.allow_from_autoenv and ctx.auto_envvar_prefix is not None \
                and self.name is not None:
            envvar = f"{ctx.auto_envvar_prefix}_{self.name.upper()}"
            rv = os.environ.get(envvar)
            if rv:
                return rv
        return None

    def value_from_envvar(self, ctx):
        rv = self.resolve_envvar_value(ctx)
        if rv is None:
            return None
        if self.is_flag:
            return self._flag_env(rv)
        depth = (self.nargs != 1) + bool(self.multiple)
        if depth > 0:
            rv = self.type.split_envvar_value(rv)
            if self.multiple and self.nargs != 1:
                rv = [tuple(rv[i:i + self.nargs]) for i in range(0, len(rv), self.nargs)]
        return rv

    def get_default(self, ctx, call=True):
        return super().get_default(ctx, call=call)

    def prompt_for_value(self, ctx):
        from .termui import confirm, prompt
        default = self.get_default(ctx)
        if self.is_bool_flag:
            return confirm(self.prompt, bool(default))
        return prompt(self.prompt, default=default, type=self.type,
                      hide_input=self.hide_input, show_choices=self.show_choices,
                      confirmation_prompt=self.confirmation_prompt,
                      value_proc=lambda x: self.type_cast_value(ctx, x))

    def consume_value(self, ctx, opts):
        value, source = super().consume_value(ctx, opts)
        if value is FLAG_NEEDS_VALUE:
            if self.prompt is not None and not ctx.resilient_parsing:
                value = self.prompt_for_value(ctx)
                source = ParameterSource.PROMPT
            else:
                value = self.flag_value
                source = ParameterSource.COMMANDLINE
        elif self.multiple and isinstance(value, (list, tuple)) and \
                any(v is FLAG_NEEDS_VALUE for v in value):
            value = [self.flag_value if v is FLAG_NEEDS_VALUE else v for v in value]
            source = ParameterSource.COMMANDLINE
        elif source in (ParameterSource.DEFAULT, ParameterSource.DEFAULT_MAP) \
                and self.prompt is not None and (self.required or self.prompt_required) \
                and not ctx.resilient_parsing:
            value = self.prompt_for_value(ctx)
            source = ParameterSource.PROMPT
        return value, source


class Argument(Parameter):
    param_type_name = "argument"

    def __init__(self, param_decls, required=None, default=_UNSET, nargs=None,
                 deprecated=False, **attrs):
        d = None if default is _UNSET else default
        if nargs is not None and (not isinstance(nargs, int) or nargs == 0 or nargs < -1):
            raise DeclarationError("'nargs' must be a positive integer or -1 for arguments.")
        if required is None:
            if d is not None:
                required = False
            else:
                required = nargs is None or nargs > 0
        self._default_explicit = default is not _UNSET
        if deprecated and required:
            raise DeclarationError("A deprecated argument cannot be required.")
        attrs.pop("multiple", None)
        super().__init__(param_decls, required=required, default=d, nargs=nargs,
                         deprecated=deprecated, **attrs)
        if self.default is not None and self.nargs < 0:
            raise DeclarationError("'default' is not supported for nargs=-1.")

    @property
    def human_readable_name(self):
        return self.name.upper()

    def make_metavar(self):
        if self.metavar is not None:
            return self.metavar
        var = self.type.get_metavar(self)
        if not var:
            var = self.name.upper()
        if not self.required:
            var = f"[{var}]"
        if self.nargs != 1:
            var += "..."
        return var

    def _parse_decls(self, decls, expose_value):
        if not decls:
            if not expose_value:
                return None, [], []
            raise DeclarationError("Could not determine name for argument")
        if len(decls) == 1:
            name = arg = decls[0]
            name = name.replace("-", "_").lower()
        else:
            raise DeclarationError(
                f"Arguments take exactly one parameter declaration, got {len(decls)}.")
        return name, [arg], []

    def get_usage_pieces(self, ctx):
        return [self.make_metavar()]

    def get_error_hint(self, ctx):
        return repr(self.human_readable_name)

    def _dep_name(self):
        return self.name

    def get_help_record(self, ctx):
        if self.hidden or not self.help:
            return None
        h = self.help
        if self.deprecated:
            h = f"(DEPRECATED) {h}"
        return (self.metavar if self.metavar is not None else self.name.upper(), h)

    def add_to_parser(self, parser, ctx):
        parser.add_argument(dest=self.name, nargs=self.nargs, obj=self)

    def consume_value(self, ctx, opts):
        if opts.get(self.name) == ():
            opts = dict(opts)
            opts[self.name] = None
        return super().consume_value(ctx, opts)


# -------------------------------------------------------------- commands

def _show_help(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


class Command:
    context_class = Context
    allow_extra_args = False
    allow_interspersed_args = True
    ignore_unknown_options = False

    def __init__(self, name=None, context_settings=None, callback=None, params=None,
                 help=None, epilog=None, short_help=None, options_metavar="[OPTIONS]",
                 add_help_option=True, no_args_is_help=False, hidden=False,
                 deprecated=False):
        self.name = name
        self.context_settings = dict(context_settings) if context_settings else {}
        self.callback = callback
        self.params = list(params or [])
        self.help = help
        self.epilog = epilog
        self.options_metavar = options_metavar
        self.short_help = short_help
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = deprecated

    def __repr__(self):
        return f"<{self.__class__.__name__} {self.name}>"

    def get_usage(self, ctx):
        formatter = ctx.make_formatter()
        self.format_usage(ctx, formatter)
        return formatter.getvalue().rstrip("\n")

    def get_params(self, ctx):
        rv = list(self.params)
        help_option = self.get_help_option(ctx)
        if help_option is not None:
            rv.append(help_option)
        return rv

    def format_usage(self, ctx, formatter):
        pieces = self.collect_usage_pieces(ctx)
        formatter.write_usage(ctx.command_path, " ".join(pieces))

    def collect_usage_pieces(self, ctx):
        rv = [self.options_metavar] if self.options_metavar else []
        for param in self.get_params(ctx):
            rv.extend(param.get_usage_pieces(ctx))
        return rv

    def get_help_option_names(self, ctx):
        names = list(ctx.help_option_names)
        for param in self.params:
            for o in list(param.opts) + list(param.secondary_opts):
                if o in names:
                    names.remove(o)
        return names

    def get_help_option(self, ctx):
        names = self.get_help_option_names(ctx)
        if not self.add_help_option or not names:
            return None
        return Option(names, is_flag=True, is_eager=True, expose_value=False,
                      callback=_show_help, help="Show this message and exit.")

    def make_parser(self, ctx):
        parser = OptionParser(ctx)
        for param in self.get_params(ctx):
            param.add_to_parser(parser, ctx)
        return parser

    def get_help(self, ctx):
        formatter = ctx.make_formatter()
        self.format_help(ctx, formatter)
        return formatter.getvalue().rstrip("\n")

    def get_short_help_str(self, limit=45):
        if self.short_help:
            text = " ".join(self.short_help.split())
        elif self.help:
            text = make_default_short_help(self.help.replace("\f", ""), limit)
        else:
            text = ""
        if self.deprecated:
            text = f"(Deprecated) {text}"
        return text.strip()

    def format_help(self, ctx, formatter):
        self.format_usage(ctx, formatter)
        self.format_help_text(ctx, formatter)
        self.format_arguments(ctx, formatter)
        self.format_options(ctx, formatter)
        self.format_epilog(ctx, formatter)

    def format_help_text(self, ctx, formatter):
        text = self.help if self.help is not None else ""
        if self.deprecated:
            text = f"(Deprecated) {text}"
        text = inspect.cleandoc(text).replace("\f", "") if text else text
        if text:
            formatter.write_paragraph()
            with formatter.indentation():
                formatter.write_text(text)

    def format_arguments(self, ctx, formatter):
        rows = []
        for param in self.get_params(ctx):
            if isinstance(param, Argument):
                rec = param.get_help_record(ctx)
                if rec is not None:
                    rows.append(rec)
        if rows:
            with formatter.section("Positional arguments"):
                formatter.write_dl(rows)

    def format_options(self, ctx, formatter):
        opts = []
        for param in self.get_params(ctx):
            if isinstance(param, Option):
                rv = param.get_help_record(ctx)
                if rv is not None:
                    opts.append(rv)
        if opts:
            with formatter.section("Options"):
                formatter.write_dl(opts)

    def format_epilog(self, ctx, formatter):
        if self.epilog:
            epilog = inspect.cleandoc(self.epilog)
            formatter.write_paragraph()
            with formatter.indentation():
                formatter.write_text(epilog)

    def make_context(self, info_name, args, parent=None, **extra):
        for key, value in self.context_settings.items():
            if key not in extra:
                extra[key] = value
        ctx = self.context_class(self, info_name=info_name, parent=parent, **extra)
        with ctx.scope(cleanup=False):
            self.parse_args(ctx, args)
        return ctx

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsIsHelpError(ctx)
        parser = self.make_parser(ctx)
        opts, args, param_order = parser.parse_args(args=args)
        for param in iter_params_for_processing(param_order, self.get_params(ctx)):
            value, args = param.handle_parse_result(ctx, opts, args)
        if args and not ctx.allow_extra_args and not ctx.resilient_parsing:
            ctx.fail(f"Got unexpected extra argument{'s' if len(args) != 1 else ''} "
                     f"({' '.join(map(make_str, args))})")
        ctx.args = args
        ctx._opt_prefixes.update(parser._opt_prefixes)
        return args

    def invoke(self, ctx):
        if self.deprecated:
            msg = f"DeprecationWarning: The command {self.name!r} is deprecated."
            if isinstance(self.deprecated, str):
                msg += f" {self.deprecated}"
            echo(style(msg, fg="red"), err=True)
        if self.callback is not None:
            return ctx.invoke(self.callback, **ctx.params)

    def shell_complete(self, ctx, incomplete):
        from .shell_completion import CompletionItem
        results = []
        if incomplete == "" or not incomplete[0].isalnum():
            for param in self.get_params(ctx):
                if (not isinstance(param, Option) or param.hidden
                        or (not param.multiple and ctx.get_parameter_source(param.name)
                            is ParameterSource.COMMANDLINE and not param.count)):
                    continue
                results.extend(CompletionItem(name, help=param.help)
                               for name in [*param.opts, *param.secondary_opts]
                               if name.startswith(incomplete))
        return results

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True,
             **extra):
        if args is None:
            args = sys.argv[1:]
        else:
            args = list(args)
        if prog_name is None:
            prog_name = _detect_program_name()
        self._main_shell_completion(extra, prog_name, complete_var)
        try:
            try:
                with self.make_context(prog_name, args, **extra) as ctx:
                    rv = self.invoke(ctx)
                    if not standalone_mode:
                        return rv
                    ctx.exit()
            except (EOFError, KeyboardInterrupt) as e:
                echo(file=sys.stderr)
                raise Abort() from e
            except OptlynException as e:
                if not standalone_mode:
                    raise
                e.show()
                sys.exit(e.exit_code)
            except OSError as e:
                if e.errno == errno.EPIPE:
                    sys.stdout = open(os.devnull, "w")
                    sys.stderr = open(os.devnull, "w")
                    sys.exit(1)
                raise
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return e.exit_code
        except Abort:
            if not standalone_mode:
                raise
            echo("Aborted!", file=sys.stderr)
            sys.exit(1)

    def _main_shell_completion(self, ctx_args, prog_name, complete_var=None):
        if complete_var is None:
            name = prog_name.replace("-", "_").replace(".", "_")
            complete_var = f"_{name}_COMPLETE".upper()
        instruction = os.environ.get(complete_var)
        if not instruction:
            return
        from .shell_completion import shell_complete
        rv = shell_complete(self, ctx_args, prog_name, complete_var, instruction)
        sys.exit(rv)

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)


def _detect_program_name():
    path = sys.argv[0] if sys.argv and sys.argv[0] else "python"
    name = os.path.basename(path)
    if name == "__main__.py":
        parent = os.path.basename(os.path.dirname(os.path.abspath(path)))
        main_mod = sys.modules.get("__main__")
        pkg = getattr(main_mod, "__package__", None)
        if pkg:
            return f"python -m {pkg}"
        return parent or name
    return name


def _visible_commands(group, ctx):
    rv = []
    for sub in group.list_commands(ctx):
        cmd = group.get_command(ctx, sub)
        if cmd is None or cmd.hidden:
            continue
        rv.append((sub, cmd))
    return rv


class Group(Command):
    allow_extra_args = True
    allow_interspersed_args = False

    def __init__(self, name=None, commands=None, invoke_without_command=False,
                 no_args_is_help=None, subcommand_metavar=None, chain=False,
                 result_callback=None, **kwargs):
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        super().__init__(name, no_args_is_help=no_args_is_help, **kwargs)
        self.invoke_without_command = invoke_without_command
        if subcommand_metavar is None:
            if chain:
                subcommand_metavar = "COMMAND1 [ARGS]... [COMMAND2 [ARGS]...]..."
                if invoke_without_command:
                    subcommand_metavar = "[COMMAND1 [ARGS]...] [COMMAND2 [ARGS]...]..."
            else:
                subcommand_metavar = "COMMAND [ARGS]..."
                if invoke_without_command:
                    subcommand_metavar = "[COMMAND] [ARGS]..."
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback
        if commands is None:
            commands = {}
        elif not isinstance(commands, dict):
            commands = {c.name: c for c in commands if c.name is not None}
        self.commands = commands
        if self.chain:
            for n, c in self.commands.items():
                _check_chain(self, n, c)

    def add_command(self, cmd, name=None):
        name = name or cmd.name
        if name is None:
            raise TypeError("Command has no name.")
        _check_chain(self, name, cmd)
        self.commands[name] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as _command
        func = None
        if args and callable(args[0]):
            func = args[0]
            args = args[1:]

        def decorator(f):
            cmd = _command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd
        if func is not None:
            return decorator(func)
        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as _group
        func = None
        if args and callable(args[0]):
            func = args[0]
            args = args[1:]

        def decorator(f):
            cmd = _group(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd
        if func is not None:
            return decorator(func)
        return decorator

    def result_callback(self, replace=False):
        def decorator(f):
            old = self._result_callback
            if old is None or replace:
                self._result_callback = f
                return f

            def function(value, *args, **kwargs):
                inner = old(value, *args, **kwargs)
                return f(inner, *args, **kwargs)
            self._result_callback = rv = update_wrapper(function, f)
            return rv
        return decorator

    def collect_usage_pieces(self, ctx):
        rv = super().collect_usage_pieces(ctx)
        rv.append(self.subcommand_metavar)
        return rv

    def format_options(self, ctx, formatter):
        super().format_options(ctx, formatter)
        self.format_commands(ctx, formatter)

    def format_commands(self, ctx, formatter):
        rows = []
        for sub, cmd in _visible_commands(self, ctx):
            rows.append((sub, cmd.get_short_help_str(45)))
        if rows:
            with formatter.section("Commands"):
                formatter.write_dl(rows)

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsIsHelpError(ctx)
        rest = super().parse_args(ctx, args)
        if self.chain:
            ctx.protected_args = rest
            ctx.args = []
        elif rest:
            ctx.protected_args, ctx.args = rest[:1], rest[1:]
        return ctx.args

    def invoke(self, ctx):
        def process_result(value):
            if self._result_callback is not None:
                value = ctx.invoke(self._result_callback, value, **ctx.params)
            return value

        if not ctx.protected_args:
            if self.invoke_without_command:
                with ctx:
                    rv = super().invoke(ctx)
                    return process_result([] if self.chain else rv)
            ctx.fail("Missing command.")
        args = [*ctx.protected_args, *ctx.args]
        ctx.args = []
        ctx.protected_args = []
        if not self.chain:
            with ctx:
                cmd_name, cmd, args = self.resolve_command(ctx, args)
                ctx.invoked_subcommand = cmd_name
                super().invoke(ctx)
                sub_ctx = cmd.make_context(cmd_name, args, parent=ctx)
                with sub_ctx:
                    return process_result(sub_ctx.command.invoke(sub_ctx))
        with ctx:
            ctx.invoked_subcommand = "*" if args else None
            super().invoke(ctx)
            contexts = []
            while args:
                cmd_name, cmd, args = self.resolve_command(ctx, args)
                sub_ctx = cmd.make_context(cmd_name, args, parent=ctx,
                                           allow_extra_args=True,
                                           allow_interspersed_args=False)
                contexts.append(sub_ctx)
                args, sub_ctx.args = sub_ctx.args, []
            rv = []
            for sub_ctx in contexts:
                with sub_ctx:
                    rv.append(sub_ctx.command.invoke(sub_ctx))
            return process_result(rv)

    def resolve_command(self, ctx, args):
        cmd_name = make_str(args[0])
        original = cmd_name
        cmd = self.get_command(ctx, cmd_name)
        if cmd is None and ctx.token_normalize_func is not None:
            cmd_name = ctx.token_normalize_func(cmd_name)
            cmd = self.get_command(ctx, cmd_name)
        if cmd is None and not ctx.resilient_parsing:
            if split_opt(cmd_name)[0]:
                self.parse_args(ctx, ctx.args)
            ctx.fail(f"No such command {original!r}.")
        return (cmd_name if cmd else None), cmd, args[1:]

    def get_command(self, ctx, cmd_name):
        return self.commands.get(cmd_name)

    def list_commands(self, ctx):
        return sorted(self.commands)

    def shell_complete(self, ctx, incomplete):
        from .shell_completion import CompletionItem
        results = [CompletionItem(name, help=cmd.get_short_help_str())
                   for name, cmd in _visible_commands(self, ctx)
                   if name.startswith(incomplete)]
        results.extend(super().shell_complete(ctx, incomplete))
        return results


MultiCommand = Group


class CommandCollection(Group):
    def __init__(self, name=None, sources=None, **attrs):
        super().__init__(name, **attrs)
        self.sources = list(sources) if sources else []

    def add_source(self, group):
        self.sources.append(group)

    def get_command(self, ctx, cmd_name):
        rv = super().get_command(ctx, cmd_name)
        if rv is not None:
            return rv
        for source in self.sources:
            rv = source.get_command(ctx, cmd_name)
            if rv is not None:
                if self.chain:
                    _check_chain(self, cmd_name, rv)
                return rv
        return None

    def list_commands(self, ctx):
        rv = set(super().list_commands(ctx))
        for source in self.sources:
            rv.update(source.list_commands(ctx))
        return sorted(rv)
