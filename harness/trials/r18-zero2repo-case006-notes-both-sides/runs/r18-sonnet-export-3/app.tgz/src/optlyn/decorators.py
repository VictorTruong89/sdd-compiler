"""Declaration decorators."""
import inspect
import re
from functools import update_wrapper

from .core import Argument, Command, Group, Option, _UNSET
from .exceptions import DeclarationError
from .globals import get_current_context

_ATTR = "__optlyn_params__"
_SUFFIX = re.compile(r"_(command|cmd|group|grp)$")


def pass_context(f):
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)
    return update_wrapper(new_func, f)


def pass_obj(f):
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)
    return update_wrapper(new_func, f)


def make_pass_decorator(object_type, ensure=False):
    def decorator(f):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(
                    f"Managed to invoke callback without a context object of type "
                    f"{object_type.__name__!r} existing.")
            return ctx.invoke(f, obj, *args, **kwargs)
        return update_wrapper(new_func, f)
    return decorator


def _make_command(f, name, attrs, cls):
    if isinstance(f, Command):
        raise TypeError("Attempted to convert a callback into a command twice.")
    params = getattr(f, _ATTR, None)
    if params is not None:
        params = list(reversed(params))
        try:
            delattr(f, _ATTR)
        except AttributeError:
            pass
    else:
        params = []
    help_ = attrs.get("help")
    if help_ is None:
        help_ = inspect.getdoc(f)
    else:
        help_ = inspect.cleandoc(help_)
    attrs["help"] = help_
    if name is None:
        name = _SUFFIX.sub("", f.__name__.lower(), count=1).replace("_", "-")
    return cls(name=name, callback=f, params=params, **attrs)


def command(name=None, cls=None, **attrs):
    if cls is None:
        cls = Command

    def decorator(f):
        cmd = _make_command(f, name_holder[0], dict(attrs), cls)
        cmd.__doc__ = f.__doc__
        return cmd

    name_holder = [name]
    if name is not None and callable(name):
        func = name
        name_holder[0] = None
        return decorator(func)
    return decorator


def group(name=None, cls=None, **attrs):
    if cls is None:
        cls = Group
    if name is not None and callable(name):
        return command(None, cls, **attrs)(name)
    return command(name, cls, **attrs)


def _param_memo(f, param):
    if isinstance(f, Command):
        f.params.append(param)
    else:
        if not hasattr(f, _ATTR):
            setattr(f, _ATTR, [])
        getattr(f, _ATTR).append(param)


def argument(*param_decls, cls=None, **attrs):
    if cls is None:
        cls = Argument

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f
    # validate eagerly so invalid combinations raise at declaration
    cls(param_decls, **attrs)
    return decorator


def option(*param_decls, cls=None, **attrs):
    if cls is None:
        cls = Option

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f
    cls(param_decls, **attrs)
    return decorator


def help_option(*param_decls, **kwargs):
    if not param_decls:
        param_decls = ("--help",)
    from .core import _show_help
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs["callback"] = _show_help
    return option(*param_decls, **kwargs)


def version_option(version=None, *param_decls, package_name=None, prog_name=None,
                   message=None, **kwargs):
    from .utils import echo
    if message is None:
        message = "%(prog)s, version %(version)s"
    if version is None and package_name is None:
        frame = inspect.currentframe()
        f_back = frame.f_back if frame is not None else None
        f_globals = f_back.f_globals if f_back is not None else {}
        del frame
        package_name = f_globals.get("__name__")
        if package_name == "__main__":
            package_name = f_globals.get("__package__")
        if package_name:
            package_name = package_name.partition(".")[0]

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        nonlocal prog_name, version
        pn = prog_name
        if pn is None:
            pn = ctx.find_root().info_name
        ver = version
        if ver is None and package_name is not None:
            import importlib.metadata as md
            try:
                ver = md.version(package_name)
            except md.PackageNotFoundError:
                try:
                    dists = md.packages_distributions().get(package_name.partition(".")[0])
                    if dists:
                        ver = md.version(dists[0])
                except Exception:
                    ver = None
                if ver is None:
                    raise RuntimeError(
                        f"{package_name!r} is not installed. Try passing 'package_name' "
                        f"instead.") from None
        if ver is None:
            raise RuntimeError("Could not determine the version.")
        echo(message % {"prog": pn, "package": package_name, "version": ver}, color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*param_decls, **kwargs)


def custom_version_option(callback, *param_decls, **kwargs):
    from .utils import echo

    def cb(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(callback(ctx), color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = cb
    return option(*param_decls, **kwargs)


def password_option(*param_decls, **kwargs):
    if not param_decls:
        param_decls = ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("hide_input", True)
    return option(*param_decls, **kwargs)


def confirmation_option(*param_decls, **kwargs):
    def callback(ctx, param, value):
        if not value:
            ctx.abort()

    if not param_decls:
        param_decls = ("--yes",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("callback", callback)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")
    return option(*param_decls, **kwargs)
