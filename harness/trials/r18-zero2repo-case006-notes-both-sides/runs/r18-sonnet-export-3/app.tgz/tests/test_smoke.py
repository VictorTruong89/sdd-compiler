import os
import pytest
import optlyn as o
from optlyn.testing import CliRunner


def test_basic_and_help():
    @o.command()
    @o.option("--count", "-c", type=int, default=1, help="how many")
    @o.argument("name")
    def hello_cmd(count, name):
        """Say hello."""
        for _ in range(count):
            o.echo(f"hi {name}")
    r = CliRunner().invoke(hello_cmd, ["-c", "2", "bob"])
    assert r.exit_code == 0 and r.output == "hi bob\nhi bob\n"
    assert hello_cmd.name == "hello"
    r = CliRunner().invoke(hello_cmd, ["--help"])
    assert r.exit_code == 0 and "--count" in r.output and "Say hello." in r.output
    r = CliRunner().invoke(hello_cmd, [])
    assert r.exit_code == 2 and "NAME" in r.stderr.upper()


def test_group_chain_env():
    @o.group()
    @o.option("--debug/--no-debug", default=False)
    @o.pass_context
    def cli(ctx, debug):
        ctx.obj = debug

    @cli.command()
    @o.option("--n", envvar="N_VAR", type=int, default=0)
    @o.pass_obj
    def sub(obj, n):
        o.echo(f"{obj} {n}")
    r = CliRunner().invoke(cli, ["--debug", "sub"], env={"N_VAR": "5"})
    assert r.output == "True 5\n"
    r = CliRunner().invoke(cli, [])
    assert r.exit_code == 2 and "Usage" in r.stderr
    r = CliRunner().invoke(cli, ["nope"])
    assert r.exit_code == 2

    @o.group(chain=True)
    def ch():
        pass

    @ch.command()
    def a():
        return 1

    @ch.command()
    def b():
        return 2
    assert ch.main(["a", "b"], standalone_mode=False) == [1, 2]
    with pytest.raises(RuntimeError):
        ch.add_command(cli)


def test_types():
    @o.command()
    @o.option("--c", type=o.Choice(["a", "b"]))
    @o.option("--r", type=o.IntRange(1, 5, clamp=True))
    @o.option("--m", multiple=True)
    @o.option("-v", count=True)
    def f(c, r, m, v):
        o.echo(repr((c, r, m, v)))
    r = CliRunner().invoke(f, ["--c", "a", "--r", "9", "--m", "x", "--m", "y", "-vv"])
    assert r.output == "('a', 5, ('x', 'y'), 2)\n"
    r = CliRunner().invoke(f, [])
    assert r.output == "(None, None, (), None)\n"
    assert CliRunner().invoke(f, ["--c", "z"]).exit_code == 2


def test_prompt_confirm():
    @o.command()
    @o.option("--name", prompt=True)
    @o.confirmation_option()
    def f(name):
        o.echo(name)
    r = CliRunner().invoke(f, input="bob\ny\n")
    assert r.output.endswith("bob\n") and r.exit_code == 0
    r = CliRunner().invoke(f, input="bob\nn\n")
    assert r.exit_code == 1 and "Aborted" in r.stderr


def test_files(tmp_path):
    @o.command()
    @o.argument("f", type=o.File("w"))
    def w(f):
        f.write("x")
    r = CliRunner()
    with r.isolated_filesystem():
        assert r.invoke(w, ["out.txt"]).exit_code == 0
        assert open("out.txt").read() == "x"


def test_completion(monkeypatch):
    @o.group()
    def cli():
        pass

    @cli.command()
    def foo():
        pass
    monkeypatch.setenv("_CLI_COMPLETE", "bash_complete")
    monkeypatch.setenv("COMP_WORDS", "cli ")
    monkeypatch.setenv("COMP_CWORD", "1")
    r = CliRunner().invoke(cli, [], prog_name="cli")
    assert "plain,foo" in r.output


def test_style():
    assert o.unstyle(o.style("x", fg="red", bold=True)) == "x"
    with pytest.raises(Exception):
        o.style("x", fg="nope")
