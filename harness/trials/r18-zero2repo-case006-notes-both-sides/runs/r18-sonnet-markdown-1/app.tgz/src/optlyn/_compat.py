"""Stream helpers and patchable hooks (the test runner replaces some of these)."""
from __future__ import annotations

import codecs
import io
import os
import re
import sys

_ansi_re = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")

FORCED_WIDTH = None


def strip_ansi(value):
    return _ansi_re.sub("", value)


def term_len(x):
    return len(strip_ansi(x))


def isatty(stream):
    try:
        return stream.isatty()
    except Exception:
        return False


def should_strip_ansi(stream=None, color=None):
    if color is None:
        if stream is None:
            stream = sys.stdin
        return not isatty(stream)
    return not color


def terminal_columns():
    """Auto-detected terminal width (patched by the test runner)."""
    import shutil
    return shutil.get_terminal_size().columns


def visible_prompt_func(prompt=""):
    return input(prompt)


def hidden_prompt_func(prompt=""):
    import getpass
    return getpass.getpass(prompt)


def _getchar(echo):
    return _posix_getchar(echo)


def _posix_getchar(echo):
    import termios
    import tty
    if isatty(sys.stdin):
        f = None
        fd = sys.stdin.fileno()
    else:
        f = open("/dev/tty")
        fd = f.fileno()
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 32)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
            sys.stdout.flush()
    finally:
        if f is not None:
            f.close()
    text = ch.decode(getattr(sys.stdin, "encoding", None) or "utf-8", "replace")
    if echo and isatty(sys.stdout):
        sys.stdout.write(text)
        sys.stdout.flush()
    if text == "\x03":
        raise KeyboardInterrupt()
    if text == "\x04":
        raise EOFError()
    return text


def _is_ascii_encoding(stream):
    enc = getattr(stream, "encoding", None)
    if enc is None:
        return False
    try:
        return codecs.lookup(enc).name == "ascii"
    except LookupError:
        return False


class _TextAdapter:
    """Binary writer on top of a text-only stream."""

    def __init__(self, stream):
        self.stream = stream

    def write(self, b):
        self.stream.write(bytes(b).decode("utf-8", "replace"))
        return len(b)

    def flush(self):
        self.stream.flush()


def _find_binary_writer(stream):
    try:
        stream.flush()
    except Exception:
        pass
    if isinstance(stream, (io.RawIOBase, io.BufferedIOBase)):
        return stream
    buf = getattr(stream, "buffer", None)
    if buf is not None:
        return buf
    return None


def get_binary_stdout():
    w = _find_binary_writer(sys.stdout)
    return w if w is not None else _TextAdapter(sys.stdout)


def get_binary_stderr():
    w = _find_binary_writer(sys.stderr)
    return w if w is not None else _TextAdapter(sys.stderr)


def get_binary_stdin():
    return getattr(sys.stdin, "buffer", None) or io.BytesIO(sys.stdin.read().encode())


class _NonClosingTextIOWrapper(io.TextIOWrapper):
    def __del__(self):
        pass

    def close(self):
        try:
            self.flush()
        except Exception:
            pass


def get_text_stdout(encoding=None, errors=None):
    if encoding is None:
        return sys.stdout
    return _NonClosingTextIOWrapper(get_binary_stdout(), encoding=encoding,
                                    errors=errors or "strict", write_through=True)


def get_text_stderr(encoding=None, errors=None):
    if encoding is None:
        return sys.stderr
    return _NonClosingTextIOWrapper(get_binary_stderr(), encoding=encoding,
                                    errors=errors or "strict", write_through=True)


def get_text_stdin(encoding=None, errors=None):
    if encoding is None:
        return sys.stdin
    return _NonClosingTextIOWrapper(get_binary_stdin(), encoding=encoding,
                                    errors=errors or "strict")
