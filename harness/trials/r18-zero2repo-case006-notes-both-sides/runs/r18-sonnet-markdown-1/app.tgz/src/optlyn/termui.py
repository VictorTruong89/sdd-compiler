from __future__ import annotations

import contextlib
import inspect
import io
import itertools
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time

from . import _compat
from ._compat import isatty, strip_ansi
from .exceptions import Abort, OptlynException, UsageError
from .globals import resolve_color_default
from .types import Choice, convert_type
from .utils import echo, format_filename

_ansi_colors = {
    "black": 30, "red": 31, "green": 32, "yellow": 33, "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "reset": 39, "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
}
_ansi_reset_all = "\033[0m"


class InvalidColor(TypeError, ValueError):
    pass


def _interpret_color(color, offset=0):
    if isinstance(color, bool):
        raise InvalidColor(f"Unknown color {color!r}")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise InvalidColor(f"Color {color!r} out of range")
        return f"{38 + offset};5;{color:d}"
    if isinstance(color, str):
        if color not in _ansi_colors:
            raise InvalidColor(f"Unknown color {color!r}")
        return str(_ansi_colors[color] + offset)
    try:
        r, g, b = color
    except (TypeError, ValueError):
        raise InvalidColor(f"Unknown color {color!r}") from None
    for c in (r, g, b):
        if isinstance(c, bool) or not isinstance(c, int) or not 0 <= c <= 255:
            raise InvalidColor(f"Unknown color {color!r}")
    return f"{38 + offset};2;{r:d};{g:d};{b:d}"


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None, italic=None,
          blink=None, reverse=None, strikethrough=None, reset=True):
    if not isinstance(text, str):
        text = str(text)
    bits = []
    if fg is not None:
        bits.append(f"\033[{_interpret_color(fg)}m")
    if bg is not None:
        bits.append(f"\033[{_interpret_color(bg, 10)}m")
    for val, on, off in ((bold, 1, 22), (dim, 2, 22), (underline, 4, 24), (overline, 53, 55),
                         (italic, 3, 23), (blink, 5, 25), (reverse, 7, 27), (strikethrough, 9, 29)):
        if val is not None:
            bits.append(f"\033[{on if val else off}m")
    bits.append(text)
    if reset:
        bits.append(_ansi_reset_all)
    return "".join(bits)


def unstyle(text):
    return strip_ansi(text)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None and not isinstance(message, (bytes, bytearray)):
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


# ---------------------------------------------------------------- prompts

def _build_prompt(text, suffix, show_default=False, default=None, show_choices=True, type=None):
    prompt = text
    if type is not None and show_choices and isinstance(type, Choice):
        prompt += f" ({', '.join(map(str, type.choices_as_str))})"
    if default is not None and show_default:
        if hasattr(default, "name") and hasattr(default, "mode"):
            default = default.name
        prompt = f"{prompt} [{default}]"
    return f"{prompt}{suffix}"


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None, value_proc=None,
           prompt_suffix=": ", show_default=True, err=False, show_choices=True):
    def prompt_func(text):
        f = _compat.hidden_prompt_func if hide_input else _compat.visible_prompt_func
        try:
            echo(text.rstrip(" "), nl=False, err=err)
            return f(" ")
        except (KeyboardInterrupt, EOFError):
            if hide_input:
                echo(None, err=err)
            raise Abort() from None

    if value_proc is None:
        value_proc = convert_type(type, default)
    prompt_text = _build_prompt(text, prompt_suffix, show_default, default, show_choices, type)
    if confirmation_prompt:
        if confirmation_prompt is True:
            confirmation_prompt = "Repeat for confirmation"
        confirmation_prompt = _build_prompt(confirmation_prompt, prompt_suffix)
    while True:
        while True:
            value = prompt_func(prompt_text)
            if value:
                break
            elif default is not None:
                value = default
                break
        try:
            result = value_proc(value)
        except UsageError as e:
            if hide_input:
                echo("Error: The value you entered was invalid.", err=err)
            else:
                echo(f"Error: {e.message}", err=err)
            continue
        if not confirmation_prompt:
            return result
        while True:
            value2 = prompt_func(confirmation_prompt)
            is_empty = not value and not value2
            if value2 or is_empty:
                break
        if value == value2:
            return result
        echo("Error: The two entered values do not match.", err=err)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    prompt_text = _build_prompt(text, prompt_suffix, show_default,
                                "y/n" if default is None else ("Y/n" if default else "y/N"))
    while True:
        try:
            echo(prompt_text.rstrip(" "), nl=False, err=err)
            value = _compat.visible_prompt_func(" ").lower().strip()
        except (KeyboardInterrupt, EOFError):
            raise Abort() from None
        if value in ("y", "yes"):
            rv = True
        elif value in ("n", "no"):
            rv = False
        elif default is not None and value == "":
            rv = default
        else:
            echo("Error: invalid input", err=err)
            continue
        break
    if abort and not rv:
        raise Abort()
    return rv


def getchar(echo=False):
    sys.stdout.flush()
    return _compat._getchar(echo)


def _interactive():
    return isatty(sys.stdin) or isatty(sys.stdout)


def pause(info=None, err=False):
    if info is None:
        info = "Press any key to continue..."
    if not _interactive():
        echo(info, err=err)
        return
    try:
        if info:
            echo(info, nl=False, err=err)
        try:
            getchar()
        except (KeyboardInterrupt, EOFError):
            pass
    finally:
        if info:
            echo(err=err)


def clear():
    if not isatty(sys.stdout):
        return
    echo("\033[2J\033[1;1H", nl=False)


# ---------------------------------------------------------------- pager

class _EchoWriter:
    def __init__(self, file, color):
        self.file = file
        self.color = color

    def write(self, text):
        echo(text, file=self.file, nl=False, color=self.color)
        return len(text)

    def flush(self):
        try:
            self.file.flush()
        except Exception:
            pass

    def writable(self):
        return True


@contextlib.contextmanager
def get_pager_file(color=None):
    stdout = sys.stdout
    color = resolve_color_default(color)
    pager_cmd = (os.environ.get("PAGER", None) or "").strip()
    if not (isatty(sys.stdin) or isatty(stdout)) or not pager_cmd:
        yield _EchoWriter(stdout, color)
        return
    env = dict(os.environ)
    proc = subprocess.Popen(pager_cmd, shell=True, stdin=subprocess.PIPE, env=env)
    enc = getattr(stdout, "encoding", None) or "utf-8"
    stream = io.TextIOWrapper(proc.stdin, encoding=enc, errors="replace", write_through=True)

    class _W:
        def write(self, text):
            if not color:
                text = strip_ansi(text)
            try:
                stream.write(text)
                stream.flush()
            except (OSError, ValueError):
                pass
            return len(text)

        def flush(self):
            try:
                stream.flush()
            except (OSError, ValueError):
                pass

        def writable(self):
            return True

    try:
        yield _W()
    finally:
        try:
            stream.close()
        except (OSError, ValueError):
            pass
        while True:
            try:
                proc.wait()
            except KeyboardInterrupt:
                pass
            else:
                break


def echo_via_pager(text_or_generator, color=None):
    if callable(text_or_generator):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        i = [text_or_generator]
    else:
        i = iter(text_or_generator)
    gen = (el if isinstance(el, str) else str(el) for el in i)
    with get_pager_file(color) as f:
        for chunk in itertools.chain(gen, "\n"):
            f.write(chunk)
            f.flush()


# ---------------------------------------------------------------- editor / launch

def _get_editor():
    for key in ("VISUAL", "EDITOR"):
        rv = os.environ.get(key)
        if rv:
            return rv
    for ed in ("sensible-editor", "vim", "nano", "vi"):
        if shutil.which(ed):
            return ed
    return "vi"


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    editor = editor or _get_editor()
    environ = None
    if env:
        environ = os.environ.copy()
        environ.update(env)
    tmp = None
    path = filename
    try:
        if filename is None:
            fd, path = tempfile.mkstemp(prefix="editor-", suffix=extension)
            tmp = path
            data = (text or "").replace("\r\n", "\n").encode("utf-8")
            with os.fdopen(fd, "wb") as f:
                f.write(data)
            old = time.time() - 5
            os.utime(path, (old, old))
        timestamp = os.path.getmtime(path) if os.path.exists(path) else None
        try:
            c = subprocess.Popen(f'{editor} "{path}"', env=environ, shell=True)
            code = c.wait()
        except OSError as e:
            raise OptlynException(f"{editor}: Editing failed: {e}") from e
        if code != 0:
            raise OptlynException(f"{editor}: Editing failed")
        if filename is not None:
            return None
        if require_save and os.path.getmtime(path) == timestamp:
            return None
        with open(path, "rb") as f:
            rv = f.read()
        return rv.decode("utf-8-sig").replace("\r\n", "\n")
    finally:
        if tmp is not None:
            try:
                os.unlink(tmp)
            except OSError:
                pass


def launch(url, wait=False, locate=False):
    args = ["xdg-open"]
    if locate:
        url = os.path.dirname(os.fspath(url)) or "."
    try:
        c = subprocess.Popen([*args, os.fspath(url)])
        return c.wait()
    except OSError:
        if str(url).startswith(("http://", "https://")) and not locate and not wait:
            import webbrowser
            webbrowser.open(url)
            return 0
        return 1


# ---------------------------------------------------------------- progress bar

class ProgressBar:
    def __init__(self, iterable=None, length=None, fill_char="#", empty_char="-",
                 bar_template="%(label)s  [%(bar)s]  %(info)s", info_sep="  ", show_eta=True,
                 show_percent=None, show_pos=False, item_show_func=None, label=None, file=None, color=None,
                 update_min_steps=1, width=36, hidden=False):
        if iterable is None:
            if length is None:
                raise TypeError("iterable or length is required")
            iterable = range(length)
        self.iterable = iterable
        self.length = length
        if length is None:
            try:
                self.length = len(iterable)
            except (TypeError, AttributeError):
                self.length = None
        self.length_known = self.length is not None
        self.fill_char, self.empty_char = fill_char, empty_char
        self.bar_template, self.info_sep = bar_template, info_sep
        self.show_eta = show_eta
        self.show_percent = show_percent if show_percent is not None else self.length_known
        self.show_pos = show_pos
        self.item_show_func = item_show_func
        self.label = label or ""
        self.file = file if file is not None else sys.stdout
        self.color = color
        self.width = width
        self.hidden = hidden
        self.pos = 0
        self.finished = False
        self.current_item = None
        self.start = self.last_eta = time.time()
        self._last_line = None
        self._rendered = False
        self._started = False
        self.update_min_steps = update_min_steps
        self._pending = 0

    @property
    def is_hidden(self):
        return self.hidden or not isatty(self.file)

    def __enter__(self):
        self.start = self.last_eta = time.time()
        self._started = True
        if not self.hidden and isatty(self.file):
            self.file.write("\033[?25l")
        self.render_progress()
        return self

    def __exit__(self, *a):
        self.render_finish()

    def __iter__(self):
        if not self._started:
            raise RuntimeError("You need to use progress bars in a with block.")
        return self.generator()

    def __next__(self):
        return next(iter(self))

    @property
    def pct(self):
        if self.finished:
            return 1.0
        if not self.length:
            return 0.0
        return min(self.pos / self.length, 1.0)

    @property
    def eta(self):
        if self.length_known and not self.finished and self.pos:
            elapsed = time.time() - self.start
            return elapsed / self.pos * (self.length - self.pos)
        return 0.0

    def format_eta(self):
        if self.length_known and not self.finished:
            t = int(self.eta)
            seconds = t % 60
            t //= 60
            minutes = t % 60
            t //= 60
            hours = t % 24
            t //= 24
            if t > 0:
                return f"{t}d {hours:02}:{minutes:02}:{seconds:02}"
            return f"{hours:02}:{minutes:02}:{seconds:02}"
        return ""

    def format_pos(self):
        pos = str(self.pos)
        if self.length_known:
            pos += f"/{self.length}"
        return pos

    def format_pct(self):
        return f"{int(self.pct * 100): 4}%"[1:]

    def format_bar(self):
        if self.length_known:
            bar_length = int(self.pct * self.width)
            bar = self.fill_char * bar_length + self.empty_char * (self.width - bar_length)
        elif self.finished:
            bar = self.fill_char * self.width
        else:
            chars = list(self.empty_char * (self.width or 1))
            if self.time_per_iteration() != 0:
                chars[int((math.cos(self.pos * self.time_per_iteration()) / 2.0 + 0.5) * self.width)] = self.fill_char
            bar = "".join(chars)
        return bar

    def time_per_iteration(self):
        return 0.0 if not self.pos else (time.time() - self.start) / self.pos

    def format_progress_line(self):
        info = []
        if self.length_known and self.show_percent:
            info.append(self.format_pct())
        if self.show_pos:
            info.append(self.format_pos())
        if self.show_eta and self.length_known and not self.finished:
            info.append(self.format_eta())
        if self.item_show_func is not None:
            item_info = self.item_show_func(self.current_item)
            if item_info is not None:
                info.append(item_info)
        return (self.bar_template % {"label": self.label, "bar": self.format_bar(),
                                     "info": self.info_sep.join(i for i in info if i)}).rstrip()

    def render_progress(self):
        if self.hidden:
            return
        if not isatty(self.file):
            if self._last_line != self.label and self.label:
                echo(self.label, file=self.file, color=self.color)
                self._last_line = self.label
            return
        line = self.format_progress_line()
        clear_width = max(len(strip_ansi(self._last_line or "")), len(strip_ansi(line)))
        self.file.write("\r" + line + " " * max(0, clear_width - len(strip_ansi(line))))
        self.file.flush()
        self._last_line = line

    def render_finish(self):
        if self.hidden or not isatty(self.file):
            return
        self.file.write("\033[?25h\n")
        self.file.flush()

    def make_step(self, n_steps):
        self.pos += n_steps
        if self.length is not None and self.pos >= self.length:
            self.finished = True

    def update(self, n_steps, current_item=None):
        self._pending += n_steps
        if current_item is not None:
            self.current_item = current_item
        if self._pending >= self.update_min_steps or (self.length is not None and
                                                      self.pos + self._pending >= self.length):
            self.make_step(self._pending)
            self._pending = 0
            self.render_progress()

    def finish(self):
        self.finished = True

    def generator(self):
        if not self._started:
            raise RuntimeError("You need to use progress bars in a with block.")
        if self.is_hidden:
            self.render_progress()
        for rv in self.iterable:
            self.current_item = rv
            yield rv
            self.update(1)
        self.finish()
        self.render_progress()


def progressbar(iterable=None, length=None, label=None, hidden=False, show_eta=True, show_percent=None,
                show_pos=False, item_show_func=None, fill_char="#", empty_char="-",
                bar_template="%(label)s  [%(bar)s]  %(info)s", info_sep="  ", width=36, file=None,
                color=None, update_min_steps=1):
    color = resolve_color_default(color)
    return ProgressBar(iterable=iterable, length=length, show_eta=show_eta, show_percent=show_percent,
                       show_pos=show_pos, item_show_func=item_show_func, fill_char=fill_char,
                       empty_char=empty_char, bar_template=bar_template, info_sep=info_sep, file=file,
                       label=label, width=width, color=color, update_min_steps=update_min_steps,
                       hidden=hidden)
