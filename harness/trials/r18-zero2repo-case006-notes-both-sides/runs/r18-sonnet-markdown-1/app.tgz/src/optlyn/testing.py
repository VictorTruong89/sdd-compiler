from __future__ import annotations

import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile

from . import _compat, termui, utils


class EchoingStdin:
    def __init__(self, input, output):
        self._input = input
        self._output = output
        self._paused = False

    def __getattr__(self, x):
        return getattr(self._input, x)

    def _echo(self, rv):
        if not self._paused:
            self._output.write(rv)
        return rv

    def read(self, n=-1):
        return self._echo(self._input.read(n))

    def readline(self, n=-1):
        return self._echo(self._input.readline(n))

    def readlines(self):
        return [self._echo(x) for x in self._input.readlines()]

    def __iter__(self):
        return iter(self._echo(x) for x in self._input)


class _Tee(io.BytesIO):
    def __init__(self, copy):
        super().__init__()
        self.copy = copy

    def write(self, b):
        self.copy.write(b)
        return super().write(b)


class _Stream(io.TextIOWrapper):
    def __init__(self, buf, charset, fd=None, name="<stream>"):
        super().__init__(buf, encoding=charset, write_through=True, newline="")
        self._fd = fd
        self._nm = name

    @property
    def name(self):
        return self._nm

    def fileno(self):
        if self._fd is None:
            raise io.UnsupportedOperation("fileno")
        return self._fd

    def isatty(self):
        return False

    def __del__(self):
        pass

    def close(self):
        pass


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value, exit_code, exception,
                 exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    def _dec(self, b):
        return b.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def output(self):
        return self._dec(self.output_bytes)

    @property
    def stdout(self):
        return self._dec(self.stdout_bytes)

    @property
    def stderr(self):
        return self._dec(self.stderr_bytes)

    def __repr__(self):
        exc = f" {self.exception!r}" if self.exception else ""
        return f"<{type(self).__name__}{exc}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        self.charset = charset
        self.env = env or {}
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def make_env(self, overrides=None):
        rv = dict(self.env)
        if overrides:
            rv.update(overrides)
        return rv

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        else:
            data = bytes(input)
        env = self.make_env(env)
        old = (sys.stdin, sys.stdout, sys.stderr, _compat.visible_prompt_func, _compat.hidden_prompt_func,
               _compat._getchar, _compat.should_strip_ansi, _compat.terminal_columns)
        fd_mode = self.capture == "fd"
        output = io.BytesIO()
        bytes_out = _Tee(output)
        bytes_err = _Tee(output)
        saved_fds = None
        tmp_out = tmp_err = None
        if fd_mode:
            sys.stdout.flush()
            sys.stderr.flush()
            tmp_out = tempfile.TemporaryFile()
            tmp_err = tempfile.TemporaryFile()
            saved_fds = (os.dup(1), os.dup(2))
            os.dup2(tmp_out.fileno(), 1)
            os.dup2(tmp_err.fileno(), 2)
        text_in = io.TextIOWrapper(io.BytesIO(data), encoding=self.charset)
        stdin_obj = text_in
        out_stream = _Stream(bytes_out, self.charset, fd=1 if fd_mode else None, name="<stdout>")
        err_stream = _Stream(bytes_err, self.charset, fd=2 if fd_mode else None, name="<stderr>")
        echo_in = self.echo_stdin
        if echo_in:
            stdin_obj = EchoingStdin(text_in, out_stream)

        def visible_input(prompt=None):
            sys.stdout.write(prompt or "")
            line = text_in.readline()
            if line == "":
                raise EOFError()
            val = line.rstrip("\r\n")
            sys.stdout.write(f"{val}\n")
            sys.stdout.flush()
            return val

        def hidden_input(prompt=None):
            sys.stdout.write((prompt or "") + "\n")
            sys.stdout.flush()
            line = text_in.readline()
            if line == "":
                raise EOFError()
            return line.rstrip("\r\n")

        def _getchar(echo):
            c = text_in.read(1)
            if c == "":
                raise EOFError()
            if echo:
                sys.stdout.write(c)
                sys.stdout.flush()
            return c

        def should_strip_ansi(stream=None, color_=None):
            if color_ is None:
                return not color
            return not color_

        def columns():
            try:
                return int(os.environ["COLUMNS"])
            except (KeyError, ValueError):
                return 80

        sys.stdin, sys.stdout, sys.stderr = stdin_obj, out_stream, err_stream
        _compat.visible_prompt_func = visible_input
        _compat.hidden_prompt_func = hidden_input
        _compat._getchar = _getchar
        _compat.should_strip_ansi = should_strip_ansi
        _compat.terminal_columns = columns
        old_env = {}
        try:
            for key, value in env.items():
                old_env[key] = os.environ.get(key)
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            result = {}
            yield (bytes_out, bytes_err, output, result)
        finally:
            try:
                out_stream.flush()
                err_stream.flush()
            except Exception:
                pass
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            if fd_mode:
                os.dup2(saved_fds[0], 1)
                os.dup2(saved_fds[1], 2)
                os.close(saved_fds[0])
                os.close(saved_fds[1])
                tmp_out.seek(0)
                tmp_err.seek(0)
                result["os_out"] = tmp_out.read()
                result["os_err"] = tmp_err.read()
                tmp_out.close()
                tmp_err.close()
            (sys.stdin, sys.stdout, sys.stderr, _compat.visible_prompt_func, _compat.hidden_prompt_func,
             _compat._getchar, _compat.should_strip_ansi, _compat.terminal_columns) = old

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        exc_info = None
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        with self.isolation(input=input, env=env, color=color) as streams:
            bytes_out, bytes_err, output, extra_out = streams
            return_value = None
            exception = None
            exit_code = 0
            if isinstance(args, str):
                args = shlex.split(args)
            try:
                prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
                try:
                    return_value = cli.main(args=args or (), prog_name=prog_name, **extra)
                except SystemExit as e:
                    exc_info = sys.exc_info()
                    code = e.code
                    if code is None:
                        code = 0
                    if code != 0:
                        exception = e
                    if not isinstance(code, int):
                        sys.stdout.write(str(code))
                        sys.stdout.write("\n")
                        code = 1
                    exit_code = code
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                sys.stdout.flush()
                sys.stderr.flush()
        so = bytes_out.getvalue()
        se = bytes_err.getvalue()
        oo = output.getvalue()
        if "os_out" in extra_out:
            so += extra_out["os_out"]
            se += extra_out["os_err"]
            oo += extra_out["os_out"] + extra_out["os_err"]
        return Result(self, so, se, oo, return_value, exit_code, exception, exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass
