from optlyn import command, option, echo
from optlyn.testing import CliRunner


def test_basic():
    @command()
    @option("--n", default=2)
    def hello(n):
        echo(f"n={n}")

    r = CliRunner().invoke(hello, ["--n", "5"])
    assert r.exit_code == 0 and r.output == "n=5\n"
