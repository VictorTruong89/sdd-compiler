import inspect
import sys
from functools import update_wrapper

from . import utils as _u
from .core import Argument, Command, Group, Option, _show_help
from .globals_ import get_current_context


def pass_context(f):
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)
    return update_wrapper(new_func, f)


def pass_obj(f):
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)
    return update_wrapper(new_func, f)


def make_pass_decorator(object_type, ensure=False):
    def decorator(f):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            obj = ctx.ensure_object(object_type) if ensure else ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(
                    f"Managed to invoke callback without a context object of type "
                    f"{object_type.__name__!r} existing.")
            return f(obj, *args, **kwargs)
        return update_wrapper(new_func, f)
    return decorator


def _make_name(f):
    name = f.__name__.lower()
    for suffix in ("_command", "_cmd", "_group", "_grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def command(name=None, cls=None, **attrs):
    if cls is None:
        cls = Command

    def decorator(f):
        if isinstance(f, Command):
            raise TypeError("Attempted to convert a callback into a command twice.")
        try:
            params = f.__optlyn_params__
            del f.__optlyn_params__
            params = list(reversed(params))
        except AttributeError:
            params = []
        a = dict(attrs)
        help = a.get("help")
        if help is None:
            help = inspect.getdoc(f)
        else:
            help = inspect.cleandoc(help)
        a["help"] = help
        cmd = cls(name=name or _make_name(f), callback=f, params=params, **a)
        cmd.__doc__ = f.__doc__
        return cmd

    if callable(name) and cls is Command and not attrs:
        f, name = name, None
        return decorator(f)
    if callable(name):
        f, name = name, None
        return decorator(f)
    return decorator


def group(name=None, cls=None, **attrs):
    if cls is None:
        cls = Group
    if callable(name):
        f, name = name, None
        return command(None, cls, **attrs)(f)
    return command(name, cls, **attrs)


def _param_memo(f, param):
    if isinstance(f, Command):
        f.params.append(param)
    else:
        if not hasattr(f, "__optlyn_params__"):
            f.__optlyn_params__ = []
        f.__optlyn_params__.append(param)


def argument(*param_decls, cls=None, **attrs):
    if cls is None:
        cls = Argument

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f
    return decorator


def option(*param_decls, cls=None, **attrs):
    if cls is None:
        cls = Option

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f
    return decorator


def help_option(*param_decls, **kwargs):
    if not param_decls:
        param_decls = ("--help",)
    if not any(d.isidentifier() for d in param_decls):
        param_decls = ("_optlyn_extra_help_flag", *param_decls)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _show_help)
    return option(*param_decls, **kwargs)


def _detect_version(package_name):
    import importlib.metadata as md
    try:
        return md.version(package_name)
    except md.PackageNotFoundError:
        pass
    try:
        dists = md.packages_distributions().get(package_name)
    except Exception:
        dists = None
    if dists:
        try:
            return md.version(dists[0])
        except md.PackageNotFoundError:
            pass
    return None


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None,
                   **kwargs):
    if message is None:
        message = "%(prog)s, version %(version)s"
    if version is None and package_name is None:
        frame = inspect.currentframe()
        f_back = frame.f_back if frame is not None else None
        f_globals = f_back.f_globals if f_back is not None else None
        del frame
        if f_globals is not None:
            package_name = f_globals.get("__name__")
            if package_name == "__main__":
                package_name = f_globals.get("__package__")
            if package_name:
                package_name = package_name.partition(".")[0]

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        nonlocal prog_name, version
        if prog_name is None:
            prog_name = ctx.find_root().info_name
        if version is None and package_name is not None:
            version = _detect_version(package_name)
            if version is None:
                raise RuntimeError(
                    f"{package_name!r} is not installed. Try passing 'package_name' instead.")
        if version is None:
            raise RuntimeError("Could not determine the version for "
                               f"{package_name!r} automatically.")
        _u.echo(message % {"prog": prog_name, "package": package_name, "version": version},
                color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*param_decls, **kwargs)


def custom_version_option(callback, *param_decls, **kwargs):
    def cb(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        _u.echo(callback(ctx), color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = cb
    return option(*param_decls, **kwargs)


def password_option(*param_decls, **kwargs):
    if not param_decls:
        param_decls = ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("hide_input", True)
    return option(*param_decls, **kwargs)


def confirmation_option(*param_decls, **kwargs):
    def callback(ctx, param, value):
        if not value:
            ctx.abort()

    if not param_decls:
        param_decls = ("--yes",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("callback", callback)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")
    return option(*param_decls, **kwargs)
