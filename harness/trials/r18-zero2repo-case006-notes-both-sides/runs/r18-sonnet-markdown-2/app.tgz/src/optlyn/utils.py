"""Echo, style, file helpers."""
import codecs
import io
import os
import re
import sys

from .globals_ import get_current_context

_ansi_re = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")

_ansi_colors = {
    "black": 30, "red": 31, "green": 32, "yellow": 33, "blue": 34, "magenta": 35,
    "cyan": 36, "white": 37, "reset": 39,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
}
_ansi_reset_all = "\033[0m"


def strip_ansi(value):
    return _ansi_re.sub("", value)


def unstyle(text):
    return strip_ansi(text)


def isatty(stream):
    try:
        return stream.isatty()
    except Exception:
        return False


def is_interactive():
    return isatty(sys.stdin) or isatty(sys.stdout)


def should_strip_ansi(stream=None, color=None):
    if color is None:
        if stream is None:
            stream = sys.stdin
        return not isatty(stream)
    return not color


def resolve_color_default(color=None):
    if color is not None:
        return color
    ctx = get_current_context(silent=True)
    if ctx is not None:
        return ctx.color
    return None


def _color_code(color, offset):
    if isinstance(color, bool):
        raise TypeError(f"Unknown color {color!r}")
    if isinstance(color, str):
        if color not in _ansi_colors:
            raise TypeError(f"Unknown color {color!r}")
        return str(_ansi_colors[color] + offset)
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise TypeError(f"Unknown color {color!r}")
        return f"{38 + offset};5;{color}"
    try:
        parts = tuple(color)
    except TypeError:
        raise TypeError(f"Unknown color {color!r}") from None
    if len(parts) != 3 or not all(
        isinstance(p, int) and not isinstance(p, bool) and 0 <= p <= 255 for p in parts
    ):
        raise TypeError(f"Unknown color {color!r}")
    return f"{38 + offset};2;{parts[0]};{parts[1]};{parts[2]}"


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True):
    if not isinstance(text, str):
        text = str(text)
    bits = []
    if fg is not None:
        bits.append(f"\033[{_color_code(fg, 0)}m")
    if bg is not None:
        bits.append(f"\033[{_color_code(bg, 10)}m")
    for val, on, off in ((bold, 1, 22), (dim, 2, 22), (underline, 4, 24), (overline, 53, 55),
                         (italic, 3, 23), (blink, 5, 25), (reverse, 7, 27),
                         (strikethrough, 9, 29)):
        if val is not None:
            bits.append(f"\033[{on if val else off}m")
    bits.append(text)
    if reset:
        bits.append(_ansi_reset_all)
    return "".join(bits)


def _find_binary_writer(stream):
    if isinstance(stream, (io.RawIOBase, io.BufferedIOBase)):
        return stream
    buf = getattr(stream, "buffer", None)
    if buf is not None and hasattr(buf, "write"):
        return buf
    return None


def echo(message=None, file=None, nl=True, err=False, color=None):
    if file is None:
        file = sys.stderr if err else sys.stdout
    if file is None:
        return
    if message is not None and not isinstance(message, (str, bytes, bytearray)):
        out = str(message)
    else:
        out = message
    if nl:
        out = out or ""
        if isinstance(out, str):
            out += "\n"
        else:
            out += b"\n"
    if not out:
        try:
            file.flush()
        except Exception:
            pass
        return
    if isinstance(out, (bytes, bytearray)):
        binary = _find_binary_writer(file)
        if binary is not None:
            file.flush()
            binary.write(out)
            binary.flush()
            return
        out = out.decode("utf-8", "replace")
    else:
        color = resolve_color_default(color)
        if should_strip_ansi(file, color):
            out = strip_ansi(out)
    enc = getattr(file, "encoding", None)
    if enc:
        try:
            is_ascii = codecs.lookup(enc).name == "ascii"
        except LookupError:
            is_ascii = False
        if is_ascii:
            buf = _find_binary_writer(file)
            if buf is not None and buf is not file:
                file.flush()
                buf.write(out.encode("utf-8"))
                buf.flush()
                return
    try:
        file.write(out)
    except UnicodeEncodeError:
        buf = _find_binary_writer(file)
        if buf is not None and buf is not file:
            file.flush()
            buf.write(out.encode("utf-8"))
            buf.flush()
            return
        file.write(out.encode("ascii", "replace").decode("ascii"))
    file.flush()


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None and not isinstance(message, (bytes, bytearray)):
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def format_filename(filename, shorten=False):
    if shorten:
        filename = os.path.basename(filename)
    else:
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        filename = filename.decode(sys.getfilesystemencoding(), "replace")
    else:
        filename = filename.encode("utf-8", "surrogateescape").decode("utf-8", "replace")
    return filename


def get_app_dir(app_name, roaming=True, force_posix=False):
    def _posixify(name):
        return "-".join(name.split()).lower()

    if sys.platform.startswith("win"):
        key = "APPDATA" if roaming else "LOCALAPPDATA"
        folder = os.environ.get(key)
        if folder is None:
            folder = os.path.expanduser("~")
        return os.path.join(folder, app_name)
    if force_posix:
        return os.path.join(os.path.expanduser("~"), f".{_posixify(app_name)}")
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~/Library/Application Support"), app_name)
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
    return os.path.join(base, _posixify(app_name))


def safecall(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception:
            pass
    return wrapper


class _NonClosingTextIOWrapper(io.TextIOWrapper):
    def __del__(self):
        pass

    def close(self):
        try:
            self.flush()
        except Exception:
            pass


def get_text_stream(name, encoding=None, errors="strict"):
    stream = getattr(sys, name)
    if encoding is None:
        return stream
    buf = _find_binary_writer(stream) if name != "stdin" else getattr(stream, "buffer", None)
    if buf is None:
        return stream
    try:
        stream.flush()
    except Exception:
        pass
    return _NonClosingTextIOWrapper(buf, encoding=encoding, errors=errors,
                                    line_buffering=(name != "stdin"))


def get_binary_stream(name):
    stream = getattr(sys, name)
    buf = getattr(stream, "buffer", None)
    return buf if buf is not None else stream


class KeepOpenFile:
    def __init__(self, file):
        self._file = file

    def __getattr__(self, name):
        return getattr(self._file, name)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        pass

    def __repr__(self):
        return repr(self._file)

    def __iter__(self):
        return iter(self._file)

    def close(self):
        pass


class _AtomicFile:
    def __init__(self, f, tmp_filename, real_filename):
        self._f = f
        self._tmp_filename = tmp_filename
        self._real_filename = real_filename
        self.closed = False

    @property
    def name(self):
        return self._real_filename

    def close(self, delete=False):
        if self.closed:
            return
        self._f.close()
        os.replace(self._tmp_filename, self._real_filename)
        self.closed = True
        if delete:
            pass

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.close(delete=exc_type is not None)

    def __iter__(self):
        return iter(self._f)


def open_stream(filename, mode="r", encoding=None, errors="strict", atomic=False):
    binary = "b" in mode
    filename = os.fspath(filename)
    if filename == "-":
        if any(m in mode for m in ["w", "a", "x"]):
            if binary:
                return get_binary_stream("stdout"), False
            return get_text_stream("stdout", encoding=encoding, errors=errors), False
        if binary:
            return get_binary_stream("stdin"), False
        return get_text_stream("stdin", encoding=encoding, errors=errors), False
    if not atomic:
        if binary:
            return open(filename, mode), True
        return open(filename, mode, encoding=encoding, errors=errors), True
    if "x" in mode:
        raise ValueError("Use the `overwrite`-parameter instead.")
    if "w" not in mode:
        raise ValueError("Atomic writes only make sense with `w`-mode.")
    import random
    try:
        perm = os.stat(filename).st_mode
    except OSError:
        perm = None
    flags = os.O_RDWR | os.O_CREAT | os.O_EXCL
    while True:
        tmp = os.path.join(os.path.dirname(filename),
                           f".__atomic-write{random.randrange(1 << 32):08x}")
        try:
            fd = os.open(tmp, flags, 0o666 if perm is None else perm)
            break
        except FileExistsError:
            continue
    if binary:
        f = open(fd, mode)
    else:
        f = open(fd, mode, encoding=encoding, errors=errors)
    return _AtomicFile(f, tmp, os.path.realpath(filename)), True


class LazyFile:
    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False):
        self.name = os.fspath(filename)
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self.should_close = True
        if self.name == "-":
            self._f, self.should_close = open_stream(filename, mode, encoding, errors)
        elif "r" in mode:
            open(filename, mode).close()

    def __getattr__(self, name):
        return getattr(self.open(), name)

    def __repr__(self):
        if self._f is not None:
            return repr(self._f)
        return f"<unopened file '{format_filename(self.name)}' {self.mode}>"

    def open(self):
        from .exceptions import FileError
        if self._f is not None:
            return self._f
        try:
            rv, self.should_close = open_stream(self.name, self.mode, self.encoding,
                                                self.errors, atomic=self.atomic)
        except OSError as e:
            raise FileError(self.name, hint=e.strerror) from e
        self._f = rv
        return rv

    def close(self):
        if self._f is not None:
            self._f.close()

    def close_intelligently(self):
        if self.should_close:
            self.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close_intelligently()

    def __iter__(self):
        self.open()
        return iter(self._f)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    f, should_close = open_stream(filename, mode, encoding, errors, atomic=atomic)
    if not should_close:
        f = KeepOpenFile(f)
    return f
