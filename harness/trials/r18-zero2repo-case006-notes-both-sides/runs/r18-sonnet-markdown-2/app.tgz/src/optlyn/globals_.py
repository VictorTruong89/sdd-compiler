"""Thread-local context stack."""
import threading
import typing as t

_local = threading.local()


def get_current_context(silent=False):
    try:
        return _local.stack[-1]
    except (AttributeError, IndexError):
        if not silent:
            raise RuntimeError("There is no active context.") from None
    return None


def push_context(ctx):
    _local.__dict__.setdefault("stack", []).append(ctx)


def pop_context():
    _local.stack.pop()
