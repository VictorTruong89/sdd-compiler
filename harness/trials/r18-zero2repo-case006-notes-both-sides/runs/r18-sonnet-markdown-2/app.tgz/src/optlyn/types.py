import datetime
import enum
import os
import stat
import uuid

from .exceptions import BadParameter
from .utils import LazyFile, format_filename, open_stream, safecall


class ParamType:
    name = None
    is_composite = False
    arity = 1
    envvar_list_splitter = None

    def get_metavar(self, param, ctx=None):
        return None

    def get_missing_message(self, param, ctx=None):
        return None

    def convert(self, value, param, ctx):
        return value

    def __call__(self, value, param=None, ctx=None):
        if value is not None:
            return self.convert(value, param, ctx)

    def split_envvar_value(self, rv):
        return (rv or "").split(self.envvar_list_splitter)

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def shell_complete(self, ctx, param, incomplete):
        return []


class FuncParamType(ParamType):
    def __init__(self, func):
        self.name = getattr(func, "__name__", "func")
        self.func = func

    def convert(self, value, param, ctx):
        try:
            return self.func(value)
        except ValueError:
            try:
                value = str(value)
            except UnicodeError:
                value = value.decode("utf-8", "replace")
            self.fail(value, param, ctx)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        return value

    def __repr__(self):
        return "UNPROCESSED"


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        if isinstance(value, bytes):
            enc = getattr(__import__("sys").stdin, "encoding", None) or "utf-8"
            try:
                value = value.decode(enc)
            except UnicodeError:
                value = value.decode("utf-8", "replace")
            return value
        return str(value)

    def __repr__(self):
        return "STRING"


class Choice(ParamType):
    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            choices = tuple(choices)
        self.choices = tuple(choices)
        self.case_sensitive = case_sensitive

    def _norm(self, c, ctx):
        s = c.name if isinstance(c, enum.Enum) else str(c)
        if ctx is not None and ctx.token_normalize_func is not None:
            s = ctx.token_normalize_func(s)
        if not self.case_sensitive:
            s = s.casefold()
        return s

    def _names(self):
        return [c.name if isinstance(c, enum.Enum) else str(c) for c in self.choices]

    def get_metavar(self, param, ctx=None):
        return f"[{'|'.join(self._names())}]"

    def get_missing_message(self, param, ctx=None):
        return "Choose from:\n\t" + ",\n\t".join(self._names())

    def convert(self, value, param, ctx):
        nv = self._norm(value, ctx)
        for orig in self.choices:
            if self._norm(orig, ctx) == nv:
                return orig
        opts = ", ".join(repr(n) for n in self._names())
        self.fail(f"{value!r} is not one of {opts}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem
        inc = self._norm(incomplete, None)
        return [CompletionItem(n) for n in self._names()
                if (n if self.case_sensitive else n.casefold()).startswith(inc)]

    def __repr__(self):
        return f"Choice({list(self.choices)})"


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else [
            "%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]

    def get_metavar(self, param, ctx=None):
        return f"[{'|'.join(self.formats)}]"

    def convert(self, value, param, ctx):
        if isinstance(value, datetime.datetime):
            return value
        for fmt in self.formats:
            try:
                return datetime.datetime.strptime(value, fmt)
            except (ValueError, TypeError):
                continue
        fm = ", ".join(repr(f) for f in self.formats)
        self.fail(f"{value!r} does not match the format{'s' if len(self.formats) > 1 else ''} {fm}.",
                  param, ctx)


class _NumberParamTypeBase(ParamType):
    _number_class = None

    def convert(self, value, param, ctx):
        try:
            return self._number_class(value)
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid {self.name}.", param, ctx)


class IntParamType(_NumberParamTypeBase):
    name = "integer"
    _number_class = int

    def convert(self, value, param, ctx):
        if isinstance(value, float) and not value.is_integer():
            self.fail(f"{value!r} is not a valid {self.name}.", param, ctx)
        return super().convert(value, param, ctx)

    def __repr__(self):
        return "INT"


class FloatParamType(_NumberParamTypeBase):
    name = "float"
    _number_class = float

    def __repr__(self):
        return "FLOAT"


class _NumberRangeBase(ParamType):
    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param, ctx):
        import operator
        rv = super().convert(value, param, ctx)
        lt_min = self.min is not None and (operator.le if self.min_open else operator.lt)(rv, self.min)
        gt_max = self.max is not None and (operator.ge if self.max_open else operator.gt)(rv, self.max)
        if self.clamp:
            if lt_min:
                return self._clamp(self.min, 1, self.min_open)
            if gt_max:
                return self._clamp(self.max, -1, self.max_open)
        if lt_min or gt_max:
            self.fail(f"{rv} is not in the range {self._describe()}.", param, ctx)
        return rv

    def _describe(self):
        lo = "" if self.min is None else f"{self.min}"
        hi = "" if self.max is None else f"{self.max}"
        if self.min is None:
            return f"x{'<' if self.max_open else '<='}{hi}"
        if self.max is None:
            return f"x{'>' if self.min_open else '>='}{lo}"
        return f"{lo}{'<' if self.min_open else '<='}x{'<' if self.max_open else '<='}{hi}"

    def get_metavar(self, param, ctx=None):
        return None


class IntRange(_NumberRangeBase, IntParamType):
    name = "integer range"

    def _clamp(self, bound, dir, open):
        if not open:
            return bound
        return bound + dir


class FloatRange(_NumberRangeBase, FloatParamType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        super().__init__(min, max, min_open, max_open, clamp)
        if (min_open or max_open) and clamp:
            raise TypeError("Clamping is not supported for open bounds.")
        if min is not None and max is not None and min > max:
            raise ValueError("'min' must not be greater than 'max'.")

    def _clamp(self, bound, dir, open):
        if not open:
            return bound
        raise RuntimeError("Clamping is not supported for open bounds.")


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param, ctx):
        if value in {False, True}:
            return bool(value)
        norm = str(value).strip().lower()
        if norm in {"1", "true", "t", "yes", "y", "on"}:
            return True
        if norm in {"0", "false", "f", "no", "n", "off"}:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)

    def __repr__(self):
        return "BOOL"


class UUIDParameterType(ParamType):
    name = "uuid"

    def convert(self, value, param, ctx):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)

    def __repr__(self):
        return "UUID"


class File(ParamType):
    name = "filename"
    envvar_list_splitter = os.path.pathsep

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def resolve_lazy_flag(self, value):
        if self.lazy is not None:
            return self.lazy
        if os.fspath(value) == "-":
            return False
        if "w" in self.mode:
            return True
        return False

    def convert(self, value, param, ctx):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        try:
            lazy = self.resolve_lazy_flag(value)
            if lazy:
                lf = LazyFile(value, self.mode, self.encoding, self.errors, atomic=self.atomic)
                if ctx is not None:
                    ctx.call_on_close(lf.close_intelligently)
                return lf
            f, should_close = open_stream(value, self.mode, self.encoding, self.errors,
                                          atomic=self.atomic)
            if ctx is not None:
                if should_close:
                    ctx.call_on_close(safecall(f.close))
                else:
                    ctx.call_on_close(safecall(f.flush))
            return f
        except OSError as e:
            self.fail(f"'{format_filename(value)}': {e.strerror}", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem
        return [CompletionItem(incomplete, type="file")]


class Path(ParamType):
    envvar_list_splitter = os.path.pathsep

    def __init__(self, exists=False, file_okay=True, dir_okay=True, writable=False,
                 readable=True, resolve_path=False, allow_dash=False, path_type=None,
                 executable=False):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.readable = readable
        self.writable = writable
        self.executable = executable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.type = path_type
        if self.file_okay and not self.dir_okay:
            self.name = "file"
        elif self.dir_okay and not self.file_okay:
            self.name = "directory"
        else:
            self.name = "path"

    def coerce_path_result(self, rv):
        if self.type is not None and not isinstance(rv, self.type):
            if self.type is str:
                rv = os.fsdecode(rv)
            elif self.type is bytes:
                rv = os.fsencode(rv)
            else:
                rv = self.type(rv)
        return rv

    def convert(self, value, param, ctx):
        rv = value
        is_dash = self.file_okay and self.allow_dash and rv in (b"-", "-")
        if not is_dash:
            if self.resolve_path:
                rv = os.path.realpath(rv)
            try:
                st = os.stat(rv)
            except OSError:
                if not self.exists:
                    return self.coerce_path_result(rv)
                self.fail(f"{self.name.title()} {format_filename(value)!r} does not exist.",
                          param, ctx)
            if not self.file_okay and stat.S_ISREG(st.st_mode):
                self.fail(f"{self.name.title()} {format_filename(value)!r} is a file.", param, ctx)
            if not self.dir_okay and stat.S_ISDIR(st.st_mode):
                self.fail(f"{self.name.title()} {format_filename(value)!r} is a directory.",
                          param, ctx)
            if self.readable and not os.access(rv, os.R_OK):
                self.fail(f"{self.name.title()} {format_filename(value)!r} is not readable.",
                          param, ctx)
            if self.writable and not os.access(rv, os.W_OK):
                self.fail(f"{self.name.title()} {format_filename(value)!r} is not writable.",
                          param, ctx)
            if self.executable and not os.access(rv, os.X_OK):
                self.fail(f"{self.name.title()} {format_filename(value)!r} is not executable.",
                          param, ctx)
        return self.coerce_path_result(rv)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem
        t = "dir" if self.dir_okay and not self.file_okay else "file"
        return [CompletionItem(incomplete, type=t)]


class Tuple(ParamType):
    is_composite = True

    def __init__(self, types):
        self.types = [convert_type(ty) for ty in types]

    @property
    def name(self):
        return f"<{' '.join(ty.name for ty in self.types)}>"

    @property
    def arity(self):
        return len(self.types)

    def convert(self, value, param, ctx):
        len_type = len(self.types)
        try:
            len_value = len(value)
        except TypeError:
            self.fail(f"{value!r} is not a valid tuple.", param, ctx)
        if len_value != len_type:
            self.fail(f"{len_type} values are required, but {len_value} were given.", param, ctx)
        return tuple(ty(x, param, ctx) for ty, x in zip(self.types, value))


def convert_type(ty, default=None):
    guessed = False
    if ty is None and default is not None:
        if isinstance(default, (tuple, list)):
            if default:
                item = default[0]
                if isinstance(item, (tuple, list)):
                    ty = Tuple([type(i) for i in item])
                else:
                    ty = type(item)
            else:
                ty = None
        else:
            ty = type(default)
        guessed = True
    if isinstance(ty, tuple):
        return Tuple(ty)
    if isinstance(ty, ParamType):
        return ty
    if ty is str or ty is None:
        return STRING
    if ty is int:
        return INT
    if ty is float:
        return FLOAT
    if ty is bool:
        return BOOL
    if ty is uuid.UUID:
        return UUID
    if guessed:
        return STRING
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    return FuncParamType(ty)


UNPROCESSED = UnprocessedParamType()
STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParameterType()
