import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile

from . import formatting, termui
from . import utils as _u


class _EchoingStdin:
    def __init__(self, input, output):
        self._input = input
        self._output = output
        self._paused = False

    def __getattr__(self, x):
        return getattr(self._input, x)

    def _echo(self, rv):
        if not self._paused:
            self._output.write(rv)
        return rv

    def read(self, n=-1):
        return self._echo(self._input.read(n))

    def read1(self, n=-1):
        return self._echo(self._input.read1(n))

    def readline(self, n=-1):
        return self._echo(self._input.readline(n))

    def readlines(self):
        return [self._echo(x) for x in self._input.readlines()]

    def __iter__(self):
        return iter(self._echo(x) for x in self._input)


def make_input_stream(input, charset):
    if hasattr(input, "read"):
        rv = getattr(input, "buffer", None)
        if rv is None:
            rv = input
            if isinstance(rv.read(0), str):
                rv = io.BytesIO(rv.read().encode(charset))
        return rv
    if input is None:
        input = b""
    elif isinstance(input, str):
        input = input.encode(charset)
    return io.BytesIO(input)


class _NamedTextIOWrapper(io.TextIOWrapper):
    def __init__(self, buffer, name=None, mode=None, **kwargs):
        super().__init__(buffer, **kwargs)
        self._name = name
        self._mode = mode

    @property
    def name(self):
        return self._name

    @property
    def mode(self):
        return self._mode


class _CopyBytes(io.BytesIO):
    """BytesIO that mirrors writes into a shared output buffer."""

    def __init__(self, copy_to):
        super().__init__()
        self.copy_to = copy_to

    def flush(self):
        super().flush()
        self.copy_to.flush()

    def write(self, b):
        self.copy_to.write(b)
        return super().write(b)


class _FdRaw(io.RawIOBase):
    def __init__(self, fd):
        self._fd = fd

    def fileno(self):
        return self._fd

    def writable(self):
        return True

    def write(self, b):
        return os.write(self._fd, bytes(b))


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value,
                 exit_code, exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self):
        return self.output_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    def __repr__(self):
        exc = repr(self.exception) if self.exception else "okay"
        return f"<Result {exc}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.charset = charset
        self.env = env or {}
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def make_env(self, overrides=None):
        rv = dict(self.env)
        if overrides:
            rv.update(overrides)
        return rv

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        bytes_input = make_input_stream(input, self.charset)
        old = (sys.stdin, sys.stdout, sys.stderr)
        old_funcs = (termui.visible_prompt_func, termui.hidden_prompt_func, termui._getchar,
                     _u.should_strip_ansi)
        old_width = formatting.FORCED_WIDTH
        formatting.FORCED_WIDTH = 80
        env = self.make_env(env)
        out_all = io.BytesIO()
        fd_state = None
        if self.capture == "fd":
            sys.stdout.flush()
            sys.stderr.flush()
            t1 = tempfile.TemporaryFile()
            t2 = tempfile.TemporaryFile()
            saved = (os.dup(1), os.dup(2))
            os.dup2(t1.fileno(), 1)
            os.dup2(t2.fileno(), 2)
            fd_state = (t1, t2, saved)
            raw1, raw2 = _FdRaw(1), _FdRaw(2)
            b_out = io.BufferedWriter(raw1, buffer_size=1)
            b_err = io.BufferedWriter(raw2, buffer_size=1)
            bytes_out, bytes_err = b_out, b_err
        else:
            bytes_out = _CopyBytes(out_all)
            bytes_err = _CopyBytes(out_all)
        echo_in = None
        if self.echo_stdin:
            bytes_input = echo_in = _EchoingStdin(bytes_input, bytes_out)
        sys.stdin = text_input = _NamedTextIOWrapper(bytes_input, encoding=self.charset,
                                                     name="<stdin>", mode="r")
        if self.echo_stdin:
            text_input._CHUNK_SIZE = 1
        sys.stdout = _NamedTextIOWrapper(bytes_out, encoding=self.charset, name="<stdout>",
                                         mode="w", write_through=True)
        sys.stderr = _NamedTextIOWrapper(bytes_err, encoding=self.charset, name="<stderr>",
                                         mode="w", errors="backslashreplace",
                                         write_through=True)

        def visible_input(prompt=None):
            sys.stdout.write(prompt or "")
            try:
                if echo_in:
                    echo_in._paused = True
                line = text_input.readline()
            finally:
                if echo_in:
                    echo_in._paused = False
            if not line:
                raise EOFError()
            val = line.rstrip("\r\n")
            sys.stdout.write(f"{val}\n")
            sys.stdout.flush()
            return val

        def hidden_input(prompt=None):
            sys.stdout.write(f"{prompt or ''}\n")
            sys.stdout.flush()
            line = text_input.readline()
            if not line:
                raise EOFError()
            return line.rstrip("\r\n")

        def _getchar(echo):
            ch = text_input.read(1)
            if not ch:
                raise EOFError()
            if echo:
                sys.stdout.write(ch)
                sys.stdout.flush()
            return ch

        default_color = color

        def should_strip_ansi(stream=None, color=None):
            if color is None:
                return not default_color
            return not color

        termui.visible_prompt_func = visible_input
        termui.hidden_prompt_func = hidden_input
        termui._getchar = _getchar
        _u.should_strip_ansi = should_strip_ansi
        old_env = {}
        try:
            for key, value in env.items():
                old_env[key] = os.environ.get(key)
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            if fd_state is not None:
                yield (fd_state, None, None)
            else:
                yield (bytes_out, bytes_err, out_all)
        finally:
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            try:
                sys.stdout.flush()
                sys.stderr.flush()
            except Exception:
                pass
            sys.stdin, sys.stdout, sys.stderr = old
            (termui.visible_prompt_func, termui.hidden_prompt_func, termui._getchar,
             _u.should_strip_ansi) = old_funcs
            formatting.FORCED_WIDTH = old_width
            if fd_state is not None:
                os.dup2(saved[0], 1)
                os.dup2(saved[1], 2)
                os.close(saved[0])
                os.close(saved[1])
                fd_state[0].close()
                fd_state[1].close()

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False,
               **extra):
        exc_info = None
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        return_value = None
        exception = None
        exit_code = 0
        with self.isolation(input=input, env=env, color=color) as outstreams:
            if isinstance(args, str):
                args = shlex.split(args)
            try:
                prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
                return_value = cli.main(args=args or (), prog_name=prog_name, **extra)
            except SystemExit as e:
                exc_info = sys.exc_info()
                e_code = e.code
                if e_code is None:
                    e_code = 0
                if e_code != 0:
                    exception = e
                if not isinstance(e_code, int):
                    sys.stdout.write(str(e_code))
                    sys.stdout.write("\n")
                    e_code = 1
                exit_code = e_code
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                try:
                    sys.stdout.flush()
                    sys.stderr.flush()
                except Exception:
                    pass
                if self.capture == "fd":
                    t1, t2, _ = outstreams[0]
                    t1.seek(0)
                    t2.seek(0)
                    stdout = t1.read()
                    stderr = t2.read()
                    output = stdout + stderr
                else:
                    stdout = outstreams[0].getvalue()
                    stderr = outstreams[1].getvalue()
                    output = outstreams[2].getvalue()
        return Result(self, stdout, stderr, output, return_value, exit_code, exception, exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass
