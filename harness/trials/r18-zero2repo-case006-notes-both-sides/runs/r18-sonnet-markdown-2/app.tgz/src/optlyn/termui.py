import contextlib
import getpass
import inspect
import itertools
import math
import os
import shutil
import subprocess
import sys
import tempfile
import time

from . import utils as _u
from .exceptions import Abort, OptlynException, UsageError
from .types import Choice, convert_type

visible_prompt_func = input
hidden_prompt_func = getpass.getpass


def _build_prompt(text, suffix, show_default=False, default=None, show_choices=True, type=None):
    prompt = text
    if type is not None and show_choices and isinstance(type, Choice):
        prompt += f" ({', '.join(map(str, type._names()))})"
    if default is not None and show_default:
        d = getattr(default, "name", default) if not isinstance(default, str) else default
        if hasattr(default, "read") or hasattr(default, "write"):
            d = getattr(default, "name", default)
        prompt = f"{prompt} [{d}]"
    return f"{prompt}{suffix}"


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False, show_choices=True):
    def prompt_func(text):
        f = hidden_prompt_func if hide_input else visible_prompt_func
        try:
            _u.echo(text.rstrip(" "), nl=False, err=err)
            return f(" ")
        except (KeyboardInterrupt, EOFError):
            if hide_input:
                _u.echo(None, err=err)
            raise Abort() from None

    if value_proc is None:
        value_proc = convert_type(type, default)
    text_ = _build_prompt(text, prompt_suffix, show_default, default, show_choices, type)
    if confirmation_prompt:
        if confirmation_prompt is True:
            confirmation_prompt = "Repeat for confirmation"
        confirmation_prompt = _build_prompt(confirmation_prompt, prompt_suffix)
    while True:
        while True:
            value = prompt_func(text_)
            if value:
                break
            elif default is not None:
                value = default
                break
        try:
            result = value_proc(value)
        except UsageError as e:
            if hide_input:
                _u.echo("Error: The value you entered was invalid.", err=err)
            else:
                _u.echo(f"Error: {e.message}", err=err)
            continue
        if not confirmation_prompt:
            return result
        while True:
            value2 = prompt_func(confirmation_prompt)
            is_empty = not value and not value2
            if value2 or is_empty:
                break
        if value == value2:
            return result
        _u.echo("Error: The two entered values do not match.", err=err)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    text_ = _build_prompt(text, prompt_suffix, show_default,
                          "y/n" if default is None else ("Y/n" if default else "y/N"))
    while True:
        try:
            _u.echo(text_.rstrip(" "), nl=False, err=err)
            value = visible_prompt_func(" ").lower().strip()
        except (KeyboardInterrupt, EOFError):
            raise Abort() from None
        if value in ("y", "yes"):
            rv = True
        elif value in ("n", "no"):
            rv = False
        elif default is not None and value == "":
            rv = default
        else:
            _u.echo("Error: invalid input", err=err)
            continue
        break
    if abort and not rv:
        raise Abort()
    return rv


# ------------------------------------------------------------------ pager

def _pager_command():
    return (os.environ.get("PAGER") or "").strip()


def _chunks(text_or_generator):
    if callable(text_or_generator):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        it = iter([text_or_generator])
    elif isinstance(text_or_generator, (bytes, bytearray)):
        it = iter([bytes(text_or_generator).decode("utf-8", "replace")])
    else:
        it = iter(text_or_generator)
    for el in it:
        yield el if isinstance(el, str) else str(el)


class _EchoStream:
    def __init__(self, color):
        self.color = color

    def write(self, text):
        _u.echo(text, nl=False, color=self.color)
        return len(text)

    def writelines(self, lines):
        for line in lines:
            self.write(line)

    def flush(self):
        try:
            sys.stdout.flush()
        except Exception:
            pass

    def isatty(self):
        return _u.isatty(sys.stdout)


class _PipeStream:
    def __init__(self, cmd, color):
        env = dict(os.environ)
        cmd_detail = cmd.rsplit("/", 1)[-1].split()
        if color is None and cmd_detail and cmd_detail[0] == "less":
            less_flags = f"{os.environ.get('LESS', '')}{' '.join(cmd_detail[1:])}"
            if not less_flags:
                env["LESS"] = "-R"
                color = True
            elif "r" in less_flags or "R" in less_flags:
                color = True
        self.color = color
        try:
            sys.stdout.flush()
        except Exception:
            pass
        self.proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, env=env,
                                     text=True, errors="replace", encoding="utf-8")
        self.stdin = self.proc.stdin

    def write(self, text):
        if not self.color:
            text = _u.strip_ansi(text)
        try:
            self.stdin.write(text)
            self.stdin.flush()
        except (OSError, KeyboardInterrupt):
            pass
        return len(text)

    def writelines(self, lines):
        for line in lines:
            self.write(line)

    def flush(self):
        try:
            self.stdin.flush()
        except OSError:
            pass

    def close(self):
        try:
            self.stdin.close()
        except OSError:
            pass
        while True:
            try:
                self.proc.wait()
            except KeyboardInterrupt:
                continue
            break


@contextlib.contextmanager
def get_pager_file(color=None):
    cmd = _pager_command()
    if not _u.is_interactive():
        yield _EchoStream(color)
        return
    if not cmd:
        cmd = "less" if shutil.which("less") else "more"
    ps = _PipeStream(cmd, color)
    try:
        yield ps
    finally:
        ps.close()


def echo_via_pager(text_or_generator, color=None):
    chunks = _chunks(text_or_generator)
    with get_pager_file(color=color) as f:
        for chunk in chunks:
            f.write(chunk)
        f.write("\n")


# ------------------------------------------------------------------ progress

class ProgressBar:
    def __init__(self, iterable, length=None, label=None, hidden=False, fill_char="#",
                 empty_char="-", bar_template="%(label)s  [%(bar)s]  %(info)s",
                 show_eta=True, show_percent=None, show_pos=False, item_show_func=None,
                 file=None, color=None, update_min_steps=1, width=36):
        if iterable is None:
            if length is None:
                raise TypeError("iterable or length is required")
            iterable = range(length)
        if length is None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.iter = iter(iterable)
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.fill_char = fill_char
        self.empty_char = empty_char
        self.bar_template = bar_template
        self.show_eta = show_eta
        self.show_percent = show_percent if show_percent is not None else length is not None
        self.show_pos = show_pos
        self.item_show_func = item_show_func
        self.file = file if file is not None else sys.stdout
        self.color = color
        self.width = width
        self.pos = 0
        self.finished = False
        self.entered = False
        self.start = time.time()
        self.current_item = None
        self._last_line = None
        self.is_hidden = hidden or not _u.isatty(self.file)

    def __enter__(self):
        self.entered = True
        self.start = time.time()
        self.render_progress()
        return self

    def __exit__(self, *exc):
        self.render_finish()

    def __iter__(self):
        if not self.entered:
            raise RuntimeError("You need to use progress bars in a with block.")
        return self.generator()

    def __next__(self):
        return next(iter(self))

    def update(self, n_steps=1, current_item=None):
        self.pos += n_steps
        if self.length is not None and self.pos >= self.length:
            self.finished = True
        if current_item is not None:
            self.current_item = current_item
        self.render_progress()

    def finish(self):
        self.finished = True
        if self.length is not None:
            self.pos = max(self.pos, self.length)

    @property
    def pct(self):
        if self.finished:
            return 1.0
        if not self.length:
            return 0.0
        return min(self.pos / self.length, 1.0)

    @property
    def eta(self):
        if self.length is not None and not self.finished and self.pos > 0:
            elapsed = time.time() - self.start
            return elapsed / self.pos * (self.length - self.pos)
        return 0.0

    def format_eta(self):
        if self.length is not None and not self.finished and self.pos > 0:
            t = int(self.eta)
            h, rem = divmod(t, 3600)
            m, s = divmod(rem, 60)
            return f"{h}:{m:02d}:{s:02d}"
        return ""

    def format_info(self):
        parts = []
        if self.show_pos:
            parts.append(f"{self.pos}/{self.length}" if self.length is not None else str(self.pos))
        if self.show_percent:
            parts.append(f"{int(self.pct * 100):>3}%")
        if self.show_eta and self.length is not None:
            e = self.format_eta()
            if e:
                parts.append(e)
        if self.item_show_func and self.current_item is not None:
            parts.append(str(self.item_show_func(self.current_item)))
        return "  ".join(parts)

    def format_bar(self):
        if self.length is not None:
            filled = int(self.pct * self.width)
            return self.fill_char * filled + self.empty_char * (self.width - filled)
        return self.empty_char * self.width

    def render_progress(self):
        if self.hidden:
            return
        if self.is_hidden:
            if self.label and self._last_line != self.label:
                self._last_line = self.label
                _u.echo(self.label, file=self.file, color=self.color)
            return
        line = (self.bar_template % {"label": self.label, "bar": self.format_bar(),
                                     "info": self.format_info()}).rstrip()
        if line != self._last_line:
            self._last_line = line
            _u.echo("\r" + line, file=self.file, nl=False, color=self.color)
            self.file.flush()

    def render_finish(self):
        if self.hidden or self.is_hidden:
            return
        self.file.write("\n")
        self.file.flush()

    def generator(self):
        if self.is_hidden:
            for rv in self.iter:
                self.current_item = rv
                yield rv
                self.pos += 1
            self.finished = True
            return
        for rv in self.iter:
            self.current_item = rv
            yield rv
            self.update(1)
        self.finish()
        self.render_progress()


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    return ProgressBar(iterable, length=length, label=label, hidden=hidden, **options)


# ------------------------------------------------------------------ keys

def _getchar_impl(echo):
    import termios
    import tty
    f = open("/dev/tty")
    fd = f.fileno()
    ch = ""
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 32).decode("utf-8", "replace")
            if echo and _u.isatty(sys.stdout):
                sys.stdout.write(ch)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
            sys.stdout.flush()
    finally:
        f.close()
    return ch


_getchar = _getchar_impl


def getchar(echo=False):
    ch = _getchar(echo)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    return ch


def pause(info=None, err=False):
    if not _u.is_interactive():
        return
    try:
        if info is None:
            info = "Press any key to continue..."
        if info:
            _u.echo(info, nl=False, err=err)
        try:
            getchar()
        except (KeyboardInterrupt, EOFError):
            pass
    finally:
        if info:
            _u.echo(err=err)


def clear():
    if not _u.isatty(sys.stdout):
        return
    sys.stdout.write("\033[2J\033[1;1H")
    sys.stdout.flush()


# ------------------------------------------------------------------ editor / launch

def _editor_cmd(editor):
    if editor is not None:
        return editor
    for key in ("VISUAL", "EDITOR"):
        rv = os.environ.get(key)
        if rv:
            return rv
    for e in ("sensible-editor", "vim", "nano"):
        if shutil.which(e):
            return e
    return "vi"


def _edit_file(editor, env, filename):
    editor = _editor_cmd(editor)
    environ = None
    if env:
        environ = os.environ.copy()
        environ.update(env)
    try:
        c = subprocess.Popen(f'{editor} "{filename}"', env=environ, shell=True)
        exit_code = c.wait()
        if exit_code != 0:
            raise OptlynException(f"{editor}: Editing failed")
    except OSError as e:
        raise OptlynException(f"{editor}: Editing failed: {e}") from e


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    if filename is not None:
        _edit_file(editor, env, filename)
        return None
    text = text or ""
    binary = isinstance(text, bytes)
    if not binary and text and not text.endswith("\n"):
        text += "\n"
    fd, name = tempfile.mkstemp(prefix="editor-", suffix=extension)
    try:
        data = text if binary else text.replace("\n", os.linesep).encode("utf-8-sig")
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        os.utime(name, ns=(0, 0))
        stamp = os.stat(name).st_mtime_ns
        _edit_file(editor, env, name)
        if require_save and os.stat(name).st_mtime_ns == stamp:
            return None
        with open(name, "rb") as f:
            rv = f.read()
        if binary:
            return rv
        return rv.decode("utf-8-sig").replace(os.linesep, "\n")
    finally:
        os.unlink(name)


def launch(url, wait=False, locate=False):
    def _unquote(u):
        return u[7:] if u.startswith("file://") else u

    try:
        if locate:
            target = os.path.dirname(_unquote(url)) or "."
        else:
            target = _unquote(url)
        c = subprocess.Popen(["xdg-open", target])
        if wait:
            return c.wait()
        return 0
    except OSError:
        if url.startswith(("http://", "https://")) and not locate and not wait:
            import webbrowser
            webbrowser.open(url)
            return 0
        return 1
