"""POSIX-style tokenizer and binder (PRD FP-01, FP-03, FP-04, FP-06).

The parser works on raw tokens. It produces raw occurrence values per
parameter; type conversion, environment, default map, prompts and
callbacks happen later in core.Command.

Attributes expected on parameter objects:
  name, opts, secondary_opts, prefixes, is_flag, count, flag_value,
  nargs, multiple, prompt, required, kind ("option" | "argument").
"""

from __future__ import annotations

import typing as t

from .exceptions import BadArgumentUsage, BadOptionUsage, NoSuchOption, UsageError

PROMPT = object()  # sentinel: option was given with no value; prompt needed
FLAG_OFF = False


class Occurrence:
    """One occurrence of an option, with raw value(s)."""

    __slots__ = ("value",)

    def __init__(self, value: t.Any) -> None:
        self.value = value


class ParseResult:
    def __init__(self) -> None:
        # param -> list of raw occurrence values (order of command line)
        self.opts: t.Dict[t.Any, t.List[t.Any]] = {}
        # argument name -> raw value (scalar, or list for variadic / nargs)
        self.args: t.Dict[t.Any, t.Any] = {}
        self.extra: t.List[str] = []  # leftover tokens
        self.rest: t.List[str] = []  # tokens after the stop point (groups)
        self.help_seen: bool = False
        self.seen: t.List[t.Any] = []

    def add_opt(self, param: t.Any, value: t.Any) -> None:
        if param not in self.opts:
            self.seen.append(param)  # first-occurrence order (eager flags)
        self.opts.setdefault(param, []).append(value)


def _norm(tok: str, normalize: t.Optional[t.Callable[[str], str]]) -> str:
    return normalize(tok) if normalize else tok


def is_option_like(tok: str, prefixes: t.Iterable[str]) -> bool:
    return len(tok) > 1 and tok[0] in set(prefixes)


class Parser:
    def __init__(
        self,
        options: t.Sequence[t.Any],
        arguments: t.Sequence[t.Any],
        *,
        interspersed: bool = True,
        ignore_unknown_options: bool = False,
        allow_extra_args: bool = False,
        stop_after: int = 0,
        normalize: t.Optional[t.Callable[[str], str]] = None,
        command_name: str = "",
    ) -> None:
        self.options = list(options)
        self.arguments = list(arguments)
        self.interspersed = interspersed
        self.ignore_unknown = ignore_unknown_options
        self.allow_extra = allow_extra_args
        # for groups: positional tokens to take before the subcommand name
        # (0 => stop at the first positional token)
        self.stop_after = stop_after
        self.normalize = normalize
        self.command_name = command_name
        self._lookup: t.Dict[str, t.Any] = {}
        for opt in self.options:
            for name in list(opt.opts) + list(getattr(opt, "secondary_opts", [])):
                self._lookup[_norm(name, normalize)] = (opt, name in getattr(opt, "secondary_opts", []))
        self._prefixes: t.Set[str] = set()
        for opt in self.options:
            for p in getattr(opt, "prefixes", {"-"}):
                self._prefixes.add(p)
        if not self._prefixes:
            self._prefixes = {"-"}

    # ------------------------------------------------------------------
    def parse(self, tokens: t.Sequence[str]) -> ParseResult:
        res = ParseResult()
        tokens = list(tokens)
        positional: t.List[str] = []
        seen_dd = False
        i = 0
        n = len(tokens)
        while i < n:
            tok = tokens[i]
            if not seen_dd and tok == "--":
                seen_dd = True
                i += 1
                continue
            if not seen_dd and is_option_like(tok, self._prefixes):
                i = self._handle_option(tok, tokens, i, res)
                continue
            # positional token
            if not self.interspersed and len(positional) >= self.stop_after:
                # group: this token is the subcommand name (or the stop point)
                res.rest = tokens[i:]
                break
            positional.append(tok)
            i += 1
        self._bind_arguments(positional, res, seen_dd)
        return res

    # ------------------------------------------------------------------
    def _handle_option(self, tok, tokens, i, res) -> int:
        """Consume an option token (and its values); return the next index."""
        if tok[:2] == tok[0] * 2:
            return self._handle_long(tok, tokens, i, res)
        return self._handle_short(tok, tokens, i, res)

    def _find(self, name: str):
        return self._lookup.get(_norm(name, self.normalize))

    def _handle_long(self, tok, tokens, i, res) -> int:
        if "=" in tok:
            name, value = tok.split("=", 1)
            has_eq = True
        else:
            name, value, has_eq = tok, None, False
        found = self._find(name)
        if found is None:
            if self.ignore_unknown or self.allow_extra:
                res.extra.append(tok)
                return i + 1
            raise NoSuchOption(name, ctx=None)
        opt, is_secondary = found
        return self._consume_option(opt, is_secondary, name, value, has_eq, tokens, i, res)

    def _handle_short(self, tok, tokens, i, res) -> int:
        prefix = tok[0]
        chars = tok[1:]
        j = 0
        while j < len(chars):
            flag = prefix + chars[j]
            found = self._find(flag)
            if found is None:
                if self.ignore_unknown or self.allow_extra:
                    # the unknown remainder of the stack stays leftover
                    res.extra.append(prefix + chars[j:])
                    return i + 1
                raise NoSuchOption(flag, ctx=None)
            opt, is_secondary = found
            takes_value = not (opt.is_flag or getattr(opt, "count", False))
            rest = chars[j + 1:]
            if takes_value:
                value = rest if rest else None
                return self._consume_option(opt, is_secondary, flag, value, bool(rest), tokens, i, res)
            self._consume_option(opt, is_secondary, flag, None, False, tokens, i, res)
            j += 1
        return i + 1

    def _consume_option(self, opt, is_secondary, name, value, has_eq, tokens, i, res) -> int:
        nxt = i + 1
        if opt.is_flag:
            if has_eq or value is not None:
                raise BadOptionUsage(f"Option {name} does not take a value.", ctx=None)
            res.add_opt(opt, FLAG_OFF if is_secondary else (opt.flag_value if opt.flag_value is not None else True))
            if getattr(opt, "name", None) == "help":
                res.help_seen = True
            return nxt
        if getattr(opt, "count", False):
            res.add_opt(opt, 1)
            return nxt
        nargs = max(int(getattr(opt, "nargs", 1) or 1), 1)
        if nargs == 1:
            if value is not None:
                res.add_opt(opt, value)
                return nxt
            # The next token is a value unless it is a known option or "--".
            has_next = nxt < len(tokens) and tokens[nxt] != "--"
            next_is_option = has_next and is_option_like(tokens[nxt], self._prefixes) \
                and self._find(tokens[nxt]) is not None
            value_follows = has_next and not next_is_option
            flag_value = getattr(opt, "flag_value", None)
            if getattr(opt, "prompt", None) and flag_value is None:
                # --opt with no value on a prompting option: prompt for it
                if value_follows:
                    res.add_opt(opt, tokens[nxt])
                    return nxt + 1
                res.add_opt(opt, PROMPT)
                return nxt
            if flag_value is not None:
                # optional value: flag alone yields flag_value
                if value_follows and not is_option_like(tokens[nxt], self._prefixes):
                    res.add_opt(opt, tokens[nxt])
                    return nxt + 1
                res.add_opt(opt, flag_value)
                return nxt
            if value_follows:
                res.add_opt(opt, tokens[nxt])
                return nxt + 1
            raise BadOptionUsage(f"Option {name} requires an argument.", ctx=None)
        # multi-value
        if value is not None:
            raise BadOptionUsage(f"Option {name} takes {nargs} values.", ctx=None)
        vals = tokens[nxt:nxt + nargs]
        if len(vals) < nargs:
            raise BadOptionUsage(f"Option {name} requires {nargs} arguments.", ctx=None)
        res.add_opt(opt, tuple(vals))
        return nxt + nargs

    # ------------------------------------------------------------------
    def _bind_arguments(self, positional: t.List[str], res: ParseResult, seen_dd: bool) -> None:
        pos = list(positional)
        args = self.arguments
        for idx, arg in enumerate(args):
            if arg.nargs == -1:  # variadic
                later_min = sum(
                    a.nargs for a in args[idx + 1:] if a.nargs != -1
                )
                take = max(len(pos) - later_min, 0)
                res.args[arg] = tuple(pos[:take])
                pos = pos[take:]
                continue
            need = arg.nargs
            if len(pos) >= need:
                chunk = pos[:need]
                pos = pos[need:]
                res.args[arg] = chunk[0] if need == 1 else tuple(chunk)
            else:
                if pos:
                    res.args[arg] = pos[0] if need == 1 else tuple(pos)
                    pos = pos[len(pos):]
                # missing arguments are checked later when the value is resolved
        if pos:
            if self.allow_extra or self.ignore_unknown:
                res.extra.extend(pos)
            else:
                # An option-shaped leftover is an unknown option (not after --)
                for tok in pos:
                    if not seen_dd and is_option_like(tok, self._prefixes):
                        raise NoSuchOption(tok, ctx=None)
                names = " ".join(repr(t_) for t_ in pos)
                raise UsageError(f"Got unexpected extra argument{'s' if len(pos) > 1 else ''} ({', '.join(pos)})", ctx=None)
