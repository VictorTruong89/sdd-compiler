"""Shell completion (PRD FP-12; Interface section 8).

Output framing (implementer's choice): one entry per line,
    kind<TAB>value<TAB>help
where kind is "plain", "file" (complete filesystem paths) or "dir"
(complete directories only). Help may be empty.
"""

from __future__ import annotations

import os
import sys
import typing as t

from .context import Context
from .exceptions import UsageError
from .params import Argument, Option

SHELLS = ("bash", "zsh", "fish", "powershell")


class CompletionItem:
    def __init__(self, value: str, help: t.Optional[str] = None, type: str = "plain") -> None:
        self.value = value
        self.help = help
        self.type = type


def _var_name(prog: str) -> str:
    return "_" + prog.upper().replace("-", "_") + "_COMPLETE"


def complete_or_source(cmd: t.Any, instruction: str, prog: str, args: t.Sequence[str]) -> bool:
    """Handle a completion instruction. Returns False for an unknown instruction."""
    shell, _, mode = instruction.partition("_")
    if shell not in SHELLS or mode not in ("source", "complete"):
        return False
    if mode == "source":
        sys.stdout.write(source_script(shell, prog, _var_name(prog)))
        sys.stdout.flush()
        return True
    words = os.environ.get("COMP_WORDS", "")
    cword_raw = os.environ.get("COMP_CWORD", "")
    if shell == "fish":
        words_list = words.split(" ") if words else []
        incomplete = cword_raw
        cword = len(words_list)
    else:
        words_list = words.split(" ") if words else []
        try:
            cword = int(cword_raw)
        except ValueError:
            cword = len(words_list)
        incomplete = words_list[cword] if cword < len(words_list) else ""
    entries = suggestions(cmd, words_list, cword, incomplete, prog)
    for item in entries:
        help_text = item.help or ""
        if shell not in ("zsh", "fish"):
            help_text = ""
        sys.stdout.write(f"{item.type}\t{item.value}\t{help_text}\n")
    sys.stdout.flush()
    return True


def suggestions(cmd: t.Any, words: t.List[str], cword: int, incomplete: str,
                prog: str) -> t.List[CompletionItem]:
    """Suggestions for the incomplete token at position cword."""
    current = cmd
    ctx = Context(cmd, info_name=prog)
    prev = words[cword - 1] if 0 < cword <= len(words) else None
    i = 1
    end = min(cword, len(words))
    while i < end:
        tok = words[i]
        if tok.startswith("-"):
            i += 1
            continue
        if getattr(current, "is_group", False):
            child = current.resolve_command(ctx, tok) if hasattr(current, "resolve_command") else None
            if child is not None:
                current = child
                ctx = Context(child, parent=ctx, info_name=tok)
                # the remaining words belong to the child
        i += 1

    # value completion for an option expecting a value
    if prev is not None and prev.startswith("-") and not incomplete.startswith("-"):
        for p in current.all_params(ctx) if hasattr(current, "all_params") else []:
            if isinstance(p, Option) and prev in (p.opts + p.secondary_opts) and not p.is_flag:
                return _as_items(p.shell_complete(ctx, incomplete), incomplete)

    if incomplete.startswith("-"):
        out: t.List[CompletionItem] = []
        if hasattr(current, "all_params"):
            for p in current.all_params(ctx):
                if isinstance(p, Option) and not p.hidden:
                    for name in p.opts + p.secondary_opts:
                        if name.startswith(incomplete):
                            out.append(CompletionItem(name, p.help))
        return out

    if getattr(current, "is_group", False):
        out = []
        for name in current.list_commands(ctx):
            child = current.get_command(ctx, name)
            if child is None or child.hidden:
                continue
            if name.startswith(incomplete):
                out.append(CompletionItem(name, child.short_help or child.help))
        return out

    for p in current.params if hasattr(current, "params") else []:
        if isinstance(p, Argument):
            return _as_items(p.shell_complete(ctx, incomplete), incomplete)
    return []


def _as_items(raw: t.Iterable, incomplete: str) -> t.List[CompletionItem]:
    out: t.List[CompletionItem] = []
    for item in raw:
        if isinstance(item, dict):
            kind = item.get("type", "file")
            out.append(CompletionItem(item.get("incomplete", incomplete), None,
                                      "dir" if kind == "dir" else "file"))
        elif isinstance(item, CompletionItem):
            if item.value.startswith(incomplete):
                out.append(item)
        else:
            text = str(item)
            if text.startswith(incomplete):
                out.append(CompletionItem(text))
    return out


def source_script(shell: str, prog: str, var: str) -> str:
    if shell == "bash":
        return (
            f"_{prog.replace('-', '_')}_completion() {{\n"
            f"  local IFS=$'\\n' line kind val\n"
            f"  COMPREPLY=()\n"
            f"  for line in $(env COMP_WORDS=\"${{COMP_WORDS[*]}}\" COMP_CWORD=$COMP_CWORD "
            f"{var}=bash_complete {prog}); do\n"
            f"    kind=${{line%%$'\\t'*}}; val=${{line#*$'\\t'}}; val=${{val%%$'\\t'*}}\n"
            f"    case $kind in\n"
            f"      file) COMPREPLY+=( $(compgen -f -- \"$val\") ) ;;\n"
            f"      dir) COMPREPLY+=( $(compgen -d -- \"$val\") ) ;;\n"
            f"      *) COMPREPLY+=( \"$val\" ) ;;\n"
            f"    esac\n"
            f"  done\n"
            f"  return 0\n"
            f"}}\n"
            f"complete -o default -F _{prog.replace('-', '_')}_completion {prog}\n"
        )
    if shell == "zsh":
        return (
            f"#compdef {prog}\n"
            f"_{prog.replace('-', '_')}_completion() {{\n"
            f"  local -a lines\n"
            f"  lines=(\"${{(@f)$(env COMP_WORDS=\"${{words[*]}}\" COMP_CWORD=$((CURRENT-1)) "
            f"{var}=zsh_complete {prog})}}\")\n"
            f"  local line kind val help\n"
            f"  for line in $lines; do\n"
            f"    kind=${{line%%$'\\t'*}}; rest=${{line#*$'\\t'}}; val=${{rest%%$'\\t'*}}; help=${{rest#*$'\\t'}}\n"
            f"    case $kind in\n"
            f"      file) _files ;;\n"
            f"      dir) _files -/ ;;\n"
            f"      *) compadd -d \"($help)\" -- \"$val\" ;;\n"
            f"    esac\n"
            f"  done\n"
            f"}}\n"
            f"compdef _{prog.replace('-', '_')}_completion {prog}\n"
        )
    if shell == "fish":
        return (
            f"function _{prog.replace('-', '_')}_completion\n"
            f"    set -l words (commandline -opc)\n"
            f"    set -l cur (commandline -ct)\n"
            f"    env COMP_WORDS=\"$words $cur\" COMP_CWORD=\"$cur\" {var}=fish_complete {prog} | "
            f"while read -l kind val help\n"
            f"        switch $kind\n"
            f"            case file\n"
            f"                __fish_complete_path $cur\n"
            f"            case dir\n"
            f"                __fish_complete_directories $cur\n"
            f"            case '*'\n"
            f"                printf '%s\\t%s\\n' $val \"$help\"\n"
            f"        end\n"
            f"    end\n"
            f"end\n"
            f"complete -c {prog} -f -a '(_{prog.replace('-', '_')}_completion)'\n"
        )
    # powershell
    return (
        f"Register-ArgumentCompleter -Native -CommandName '{prog}' -ScriptBlock {{\n"
        f"    param($wordToComplete, $commandAst, $cursorPosition)\n"
        f"    $env:COMP_WORDS = $commandAst.ToString()\n"
        f"    $env:COMP_CWORD = $wordToComplete\n"
        f"    $env:{var} = 'powershell_complete'\n"
        f"    & {prog} | ForEach-Object {{\n"
        f"        $parts = $_ -split \"`t\"\n"
        f"        [System.Management.Automation.CompletionResult]::new($parts[1], $parts[1], 'ParameterValue', $parts[1])\n"
        f"    }}\n"
        f"    Remove-Item Env:\\{var}\n"
        f"}}\n"
    )
