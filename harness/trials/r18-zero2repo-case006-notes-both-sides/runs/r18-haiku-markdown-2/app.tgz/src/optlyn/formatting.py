"""Text wrapping and help-page layout helpers (PRD FP-02, FP-11)."""

from __future__ import annotations

import re
import textwrap
import typing as t

FORM_FEED = "\f"
BACKSPACE = "\b"
DEFAULT_MAX_CONTENT_WIDTH = 80  # FP-02 default for auto-detected width
TEXT_WRAP_WIDTH = 100  # FP-11 wrap width for wrap_text when caller gives none
SHORT_HELP_LIMIT = 45


def _paragraphs(text: str) -> t.List[str]:
    """Split text into paragraphs separated by blank lines."""
    return [p for p in re.split(r"\n\s*\n", text) if p.strip()]


def wrap_text(
    text: str,
    width: int = TEXT_WRAP_WIDTH,
    initial_indent: str = "",
    subsequent_indent: str = "",
    preserve_paragraphs: bool = False,
) -> str:
    """Wrap text to width. Accepts any string and never fails.

    Single newlines inside a paragraph are not preserved. A paragraph whose
    first line is a lone backspace is not rewrapped; its line breaks are kept
    and the backspace line is removed.
    """
    if not isinstance(text, str):
        text = str(text)
    width = max(int(width), 1)
    out: t.List[str] = []
    for para in _paragraphs(text):
        lines = para.split("\n")
        if lines and lines[0].strip() == BACKSPACE:
            kept = [ln for ln in lines[1:]]
            for ln in kept:
                out.append(ln.rstrip())
            out.append("")
            continue
        flat = " ".join(ln.strip() for ln in lines if ln.strip())
        if not flat:
            continue
        wrapped = textwrap.fill(
            flat,
            width=width,
            initial_indent=initial_indent,
            subsequent_indent=subsequent_indent,
            break_long_words=False,
            break_on_hyphens=False,
        )
        out.append(wrapped)
        out.append("")
    if out and out[-1] == "":
        out.pop()
    if not out and text.strip() == "":
        return ""
    return "\n".join(out)


def cut_at_form_feed(text: t.Optional[str]) -> t.Optional[str]:
    """Drop everything from the first form feed onward (PRD FP-02)."""
    if text is None:
        return None
    if FORM_FEED in text:
        return text.split(FORM_FEED, 1)[0].rstrip()
    return text


def first_sentence(text: str) -> str:
    """Return the first sentence of a docstring-like text, on one line."""
    flat = " ".join(text.split())
    if not flat:
        return ""
    m = re.search(r"(?<=[.!?])\s", flat)
    if m:
        return flat[: m.start() + 1]
    return flat


def short_help_text(text: str, limit: int = SHORT_HELP_LIMIT) -> str:
    """Short help for a group listing: the first paragraph, cut at `limit`.

    Interface section 2 says "the start of the child's first paragraph, cut
    with ... at 45 characters". The PRD says "first sentence ... ellipsized
    if it cannot fit on one line at the wrap width". This implementation
    uses the first sentence, then cuts to `limit` with an ellipsis.
    """
    sent = first_sentence(text)
    if len(sent) <= limit:
        return sent
    return sent[: max(limit - 3, 0)].rstrip() + "..."


def join_columns(rows: t.Sequence[t.Tuple[str, str]], indent: int = 2,
                 width: int = DEFAULT_MAX_CONTENT_WIDTH, col_gap: int = 2) -> t.List[str]:
    """Lay out (first, second) rows as two columns, wrapping the second."""
    if not rows:
        return []
    first_w = max(len(a) for a, _ in rows)
    first_w = min(first_w, max(width // 3, 10))
    pad = " " * indent
    gap = " " * col_gap
    right_w = max(width - indent - first_w - col_gap, 20)
    out: t.List[str] = []
    for left, right in rows:
        right_lines = textwrap.wrap(right, right_w) or [""]
        if len(left) > first_w:
            out.append(f"{pad}{left}")
            for rl in right_lines:
                out.append(f"{pad}{' ' * first_w}{gap}{rl}".rstrip())
        else:
            out.append(f"{pad}{left.ljust(first_w)}{gap}{right_lines[0]}".rstrip())
            for rl in right_lines[1:]:
                out.append(f"{pad}{' ' * first_w}{gap}{rl}".rstrip())
    return out
