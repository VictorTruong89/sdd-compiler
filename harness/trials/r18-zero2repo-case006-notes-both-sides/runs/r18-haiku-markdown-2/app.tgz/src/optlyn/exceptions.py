"""Exception classes used by Optlyn.

Exit-status classes (standalone mode):
  * UsageError    -> status 2
  * Abort         -> status 1
  * ClickLikeExit / Exit -> author clean stop with status n
  * OptlynError (general) -> status 1
"""

from __future__ import annotations

import typing as t


class OptlynError(Exception):
    """Base class for all Optlyn errors. General error class (exit 1)."""

    exit_code = 1

    def __init__(self, message: str, ctx: t.Any = None) -> None:
        super().__init__(message)
        self.message = message
        self.ctx = ctx

    def show(self, file: t.Any = None) -> None:
        import sys

        if file is None:
            file = sys.stderr
        file.write(f"Error: {self.message}\n")


class UsageError(OptlynError):
    """Incorrect usage of the command line (exit 2)."""

    exit_code = 2

    def __init__(
        self,
        message: str,
        ctx: t.Any = None,
        show_usage: bool = True,
    ) -> None:
        super().__init__(message, ctx)
        self.show_usage = show_usage

    def show(self, file: t.Any = None) -> None:
        import sys

        if file is None:
            file = sys.stderr
        if self.ctx is not None and self.show_usage:
            usage = self.ctx.get_usage()
            file.write(usage + "\n")
        file.write(f"Error: {self.message}\n")


class NoSuchOption(UsageError):
    """An unknown option was given."""

    def __init__(self, option_name: str, message: t.Optional[str] = None, **kw: t.Any) -> None:
        self.option_name = option_name
        super().__init__(message or f"No such option: {option_name}", **kw)


class BadOptionUsage(UsageError):
    """Usage problem with an option (such as a missing value)."""


class BadArgumentUsage(UsageError):
    """Usage problem with an argument."""


class MissingParameter(UsageError):
    """A required parameter was not given."""

    def __init__(self, message: t.Optional[str] = None, ctx: t.Any = None,
                 param: t.Any = None, param_hint: t.Optional[str] = None,
                 show_usage: bool = True) -> None:
        self.param = param
        self.param_hint = param_hint
        super().__init__(message or "Missing parameter", ctx, show_usage)


class BadParameter(UsageError):
    """A value was refused (conversion or callback failure).

    Signature follows the interface contract:
    BadParameter(message, ctx=None, param=None, param_hint=None)
    """

    def __init__(
        self,
        message: str,
        ctx: t.Any = None,
        param: t.Any = None,
        param_hint: t.Optional[str] = None,
    ) -> None:
        self.param = param
        self.param_hint = param_hint
        super().__init__(message, ctx)

    def format_message(self) -> str:
        name = _param_identity(self.param, self.param_hint)
        if name:
            return f"Invalid value for {name}: {self.message}"
        return f"Invalid value: {self.message}"


class NoSuchCommand(UsageError):
    """An unknown subcommand name was given."""

    def __init__(self, cmd_name: str, message: t.Optional[str] = None, **kw: t.Any) -> None:
        self.cmd_name = cmd_name
        super().__init__(message or f"No such command '{cmd_name}'.", **kw)


class MissingCommand(UsageError):
    """A group was given no subcommand where one is required."""


class FileError(OptlynError):
    """A file could not be opened during I/O (general error, exit 1)."""

    def __init__(self, filename: str, hint: str = "") -> None:
        self.ui_filename = filename
        super().__init__(f"Could not open file '{filename}'{': ' + hint if hint else ''}.")


class Abort(OptlynError):
    """Abort: user declined, EOF, interrupt, or an author abort (exit 1)."""

    exit_code = 1

    def __init__(self, message: str = "Aborted!", ctx: t.Any = None) -> None:
        super().__init__(message, ctx)

    def show(self, file: t.Any = None) -> None:
        import sys

        if file is None:
            file = sys.stderr
        file.write(f"{self.message}\n")


class Exit(RuntimeError):
    """Author clean stop with a status code (exit n, default 0)."""

    def __init__(self, code: int = 0) -> None:
        super().__init__(code)
        self.exit_code = code


class DeprecationWarningFlag(Exception):
    """Internal marker, not raised publicly."""


def _param_identity(param: t.Any, hint: t.Optional[str]) -> t.Optional[str]:
    if hint:
        return hint
    if param is None:
        return None
    try:
        return param.get_error_hint(None)
    except Exception:
        return getattr(param, "name", None)
