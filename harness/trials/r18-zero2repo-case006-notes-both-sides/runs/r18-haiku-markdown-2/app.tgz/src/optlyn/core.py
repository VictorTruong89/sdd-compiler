"""Commands: parsing, value resolution, invocation, help and main() (FP-01, FP-02, FP-13)."""

from __future__ import annotations

import os
import sys
import typing as t

from . import utils as _utils
from .context import Context, get_current_context
from .exceptions import (
    Abort,
    BadArgumentUsage,
    Exit,
    MissingParameter,
    OptlynError,
    UsageError,
)
from .formatting import cut_at_form_feed, join_columns, wrap_text, DEFAULT_MAX_CONTENT_WIDTH
from .params import MISSING, Argument, Option, Parameter, SRC_CMDLINE
from .parser import Parser

_SOURCE_RANK = {"prompt": 0, "commandline": 1, "environment": 2, "default_map": 3, "default": 4}


class NoArgsHelp(UsageError):
    """Usage failure that shows the help page on standard error (exit 2)."""

    def __init__(self, ctx: Context) -> None:
        super().__init__("", ctx=ctx, show_usage=False)

    def show(self, file: t.Any = None) -> None:
        file = file or sys.stderr
        file.write(self.ctx.get_help() + "\n")


class Command:
    """A leaf command: parses its tokens and runs an author callback."""

    is_group = False
    allow_interspersed_default = True

    def __init__(
        self,
        name: t.Optional[str] = None,
        callback: t.Optional[t.Callable] = None,
        params: t.Optional[t.List[Parameter]] = None,
        *,
        help: t.Optional[str] = None,
        short_help: t.Optional[str] = None,
        epilog: t.Optional[str] = None,
        options_metavar: t.Optional[str] = "[OPTIONS]",
        context_settings: t.Optional[dict] = None,
        add_help_option: bool = True,
        no_args_is_help: bool = False,
        deprecated: t.Any = False,
        hidden: bool = False,
        **extra: t.Any,
    ) -> None:
        self.name = name
        self.callback = callback
        self.params: t.List[Parameter] = list(params or [])
        if help is None and callback is not None and callback.__doc__:
            help = callback.__doc__
        self.help = cut_at_form_feed(help)
        self.short_help = short_help
        self.epilog = epilog
        self.options_metavar = options_metavar
        self.context_settings = dict(context_settings or {})
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.deprecated = deprecated
        self.hidden = hidden
        self.extra = extra

    def __repr__(self) -> str:
        return f"<Command {self.name}>"

    def __call__(self, *args: t.Any, **kwargs: t.Any) -> t.Any:
        return self.main(*args, **kwargs)

    # ------------------------------------------------------------------
    def get_help_option_names(self, ctx: Context) -> t.List[str]:
        return list(ctx.help_option_names)

    def _author_option_names(self) -> t.Set[str]:
        names: t.Set[str] = set()
        for p in self.params:
            if isinstance(p, Option):
                names.update(p.opts)
                names.update(p.secondary_opts)
        return names

    def _help_param(self, ctx: Context) -> t.Optional[Option]:
        if not self.add_help_option:
            return None
        names = self.get_help_option_names(ctx)
        author = self._author_option_names()
        free = [n for n in names if n not in author]
        if not free:
            return None
        param = Option(
            free, is_flag=True, is_eager=True, expose_value=False, hidden=False,
            help="Show this message and exit.", callback=_help_callback,
        )
        param.name = "help"
        return param

    def all_params(self, ctx: Context) -> t.List[Parameter]:
        params = list(self.params)
        hp = self._help_param(ctx)
        if hp is not None:
            params.append(hp)
        return params

    # ------------------------------------------------------------------
    def _parser_for(self, ctx: Context, params: t.List[Parameter]) -> Parser:
        opts = [p for p in params if isinstance(p, Option)]
        args = [p for p in params if isinstance(p, Argument)]
        return Parser(
            opts, args,
            interspersed=bool(ctx.allow_interspersed_args) and not self.is_group,
            ignore_unknown_options=bool(ctx.ignore_unknown_options),
            allow_extra_args=bool(ctx.allow_extra_args),
            stop_after=self._stop_after(args),
            normalize=ctx.token_normalize_func,
            command_name=self.name or "",
        )

    def _stop_after(self, args: t.List[Argument]) -> int:
        return 0

    def parse_args(self, ctx: Context, args: t.List[str]) -> t.List[str]:
        """Parse tokens, resolve values into ctx.params, return group rest."""
        params = self.all_params(ctx)
        parser = self._parser_for(ctx, params)
        res = parser.parse(args)
        # eager flags: the one typed first takes effect
        eager_done: t.Dict[t.Any, t.Tuple[t.Any, t.Optional[str]]] = {}
        eager_seen = [p for p in res.seen if getattr(p, "is_eager", False)]
        if eager_seen:
            first = eager_seen[0]
            eager_done[first] = first.resolve_value(ctx, res.opts.get(first, []))
        for p in params:
            if p in eager_done:
                value, source = eager_done[p]
            else:
                if isinstance(p, Option):
                    supplied: t.Any = res.opts.get(p, [])
                else:
                    supplied = res.args.get(p, MISSING)
                    if isinstance(p, Argument) and supplied is not MISSING and p.nargs > 1 \
                            and not p.variadic and isinstance(supplied, tuple) and len(supplied) < p.nargs:
                        raise BadArgumentUsage(f"Argument {p.name!r} takes {p.nargs} values.", ctx=ctx)
                value, source = p.resolve_value(ctx, supplied)
            if not p.expose_value:
                continue
            self._store(ctx, p, value, source)
        ctx._extra = res.extra
        return res.rest

    @staticmethod
    def _store(ctx: Context, p: Parameter, value: t.Any, source: t.Optional[str]) -> None:
        if source is None:
            ctx.params[p.name] = value
            return
        prev = ctx._sources.get(p.name)
        if prev is not None and _SOURCE_RANK.get(source, 9) > _SOURCE_RANK.get(prev, 9):
            return  # feature-switch: the more explicit source wins
        ctx.params[p.name] = value
        ctx.set_source(p.name, source)

    # ------------------------------------------------------------------
    def make_context(
        self,
        info_name: t.Optional[str],
        args: t.Sequence[str],
        parent: t.Optional[Context] = None,
        **extra: t.Any,
    ) -> Context:
        settings = dict(self.context_settings)
        settings.update(extra)
        if parent is not None:
            # children inherit the default map for their name
            dm = settings.pop("default_map", None)
            if dm is None and isinstance(parent.default_map, dict) and info_name in parent.default_map:
                dm = parent.default_map[info_name]
            if isinstance(dm, dict) or dm is None:
                settings["default_map"] = dm
            else:
                settings["default_map"] = dm
        ctx = Context(self, parent=parent, info_name=info_name, **settings)
        ctx._raw_args = list(args)
        ctx._rest = []
        ctx._push()
        try:
            ctx._rest = self.parse_args(ctx, list(args))
        except UsageError as e:
            if e.ctx is None:
                e.ctx = ctx
            ctx._pop()
            ctx.close()
            raise
        except BaseException:
            ctx._pop()
            ctx.close()
            raise
        ctx._pop()
        return ctx

    def _warn_if_deprecated(self) -> None:
        if not self.deprecated:
            return
        note = self.deprecated if isinstance(self.deprecated, str) else None
        text = f"DeprecationWarning: {note}" if note else \
            f"DeprecationWarning: The command '{self.name}' is deprecated."
        _utils.echo(text, err=True)

    def invoke(self, ctx: Context) -> t.Any:
        """Run the callback with the parsed values."""
        self._warn_if_deprecated()
        if self.callback is None:
            return None
        ctx._push()
        try:
            return self.callback(**ctx.params)
        finally:
            ctx._pop()

    def invoke_with_values(self, ctx: Context, values: t.Dict[str, t.Any]) -> t.Any:
        """Used by Context.invoke / forward: values go through as given."""
        params = self.all_params(ctx)
        ctx._push()
        try:
            for p in self.params:
                if p.name in values:
                    ctx.params[p.name] = values[p.name]
                elif p.expose_value:
                    v, src = p.resolve_value(ctx, MISSING if isinstance(p, Argument) else [])
                    ctx.params[p.name] = v
                    if src:
                        ctx.set_source(p.name, src)
        finally:
            ctx._pop()
        return self.invoke(ctx)

    # ------------------------------------------------------------------
    def main(
        self,
        args: t.Optional[t.Sequence[str]] = None,
        prog_name: t.Optional[str] = None,
        complete_var: t.Optional[str] = None,
        standalone_mode: bool = True,
        **extra: t.Any,
    ) -> t.Any:
        if args is None:
            args = sys.argv[1:]
        args = list(args)
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else "cli"
            if prog_name.endswith(".py"):
                prog_name = prog_name[:-3]
        var = complete_var or "_" + prog_name.upper().replace("-", "_") + "_COMPLETE"
        instruction = os.environ.get(var)
        if instruction:
            from .shell_completion import complete_or_source

            ok = complete_or_source(self, instruction, prog_name, args)
            if not standalone_mode:
                return None
            sys.exit(0 if ok else 1)

        ctx = None
        try:
            try:
                ctx = self.make_context(prog_name, args, **extra)
                rv = self.invoke_root(ctx)
            finally:
                if ctx is not None:
                    ctx.close()
            if not standalone_mode:
                return rv
            sys.exit(0)
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return None
        except OptlynError as e:
            if not standalone_mode:
                raise
            e.show()
            sys.exit(e.exit_code)
        except (KeyboardInterrupt, EOFError):
            if not standalone_mode:
                raise
            Abort().show()
            sys.exit(1)

    def invoke_root(self, ctx: Context) -> t.Any:
        return self.invoke(ctx)

    # ------------------------------------------------------------------
    def command_path(self, ctx: Context) -> str:
        if ctx.parent is not None:
            return self.command_path(ctx.parent) + " " + (ctx.info_name or "")
        return ctx.info_name or (self.name or "cli")

    def _usage_pieces(self, ctx: Context) -> t.List[str]:
        pieces = [self.options_metavar] if self.options_metavar else []
        for p in self.params:
            if isinstance(p, Argument) and not p.hidden:
                meta = p.get_metavar(ctx)
                if p.nargs == -1 or p.variadic:
                    pieces.append(f"[{meta}]..." if not p.required else f"{meta}...")
                elif not p.required:
                    pieces.append(f"[{meta}]")
                else:
                    pieces.append(meta)
        return pieces

    def get_usage(self, ctx: Context) -> str:
        return "Usage: " + " ".join([self.command_path(ctx)] + self._usage_pieces(ctx)) + \
            f"\nTry '{self.command_path(ctx)} {self._help_names_text(ctx)}' for help."

    def _help_names_text(self, ctx: Context) -> str:
        return ctx.help_option_names[0] if ctx.help_option_names else "--help"

    def get_help(self, ctx: Context) -> str:
        return self.format_help(ctx)

    def format_help(self, ctx: Context) -> str:
        # An explicit terminal width is the wrap width as-is; otherwise the
        # detected width is capped by the maximum content width (FP-02).
        if ctx.terminal_width:
            width = ctx.terminal_width
        else:
            cap = ctx.max_content_width or DEFAULT_MAX_CONTENT_WIDTH
            width = min(max(_term_width() - 2, 10), cap)
        lines: t.List[str] = []
        lines.append("Usage: " + " ".join([self.command_path(ctx)] + self._usage_pieces(ctx)))
        lines.append("")
        if self.help:
            lines.append(wrap_text(self.help, width=width))
            lines.append("")
        arg_rows = []
        for p in self.params:
            if isinstance(p, Argument) and not p.hidden and p.help:
                arg_rows.append((p.get_metavar(ctx), p.help))
        if arg_rows:
            lines.append("Positional arguments:")
            lines.extend(join_columns(arg_rows, width=width))
            lines.append("")
        opt_rows = []
        for p in self.all_params(ctx):
            if isinstance(p, Option) and not p.hidden:
                opt_rows.append(self._option_record(p, ctx))
        if opt_rows:
            lines.append("Options:")
            lines.extend(join_columns(opt_rows, width=width))
            lines.append("")
        lines.extend(self._extra_help_sections(ctx, width))
        if self.epilog:
            lines.append(wrap_text(self.epilog, width=width))
            lines.append("")
        while lines and lines[-1] == "":
            lines.pop()
        return "\n".join(lines)

    def _extra_help_sections(self, ctx: Context, width: int) -> t.List[str]:
        return []

    def _option_record(self, p: Option, ctx: Context) -> t.Tuple[str, str]:
        names = ", ".join(p.opts + p.secondary_opts)
        if not p.is_flag and not p.count:
            meta = p.get_metavar(ctx)
            if meta:
                names += " " + meta
        extras = []
        if p.help:
            help_text = p.help
        else:
            help_text = ""
        if p.type is not None and not p.is_flag and not p.count and hasattr(p.type, "choices"):
            extras.append("choices: " + p.type.describe_choices())
        show = p.show_default if p.show_default is not False else (ctx.show_default or False)
        if show and p.default is not None and not (p.is_flag and p.default is False):
            if isinstance(show, str):
                extras.append(f"default: {show}")
            else:
                dv = p.get_default(ctx) if callable(p.default) else p.default
                if not (callable(p.default)):
                    extras.append(f"default: {dv}")
        if p.envvar and p.show_envvar:
            extras.append("env var: " + ", ".join(p.envvar))
        if p.is_deprecated:
            extras.append("deprecated")
        if extras:
            help_text = (help_text + " " if help_text else "") + "[" + "; ".join(extras) + "]"
        return names, help_text

    def shell_complete_options(self, ctx: Context) -> t.List[str]:
        out = []
        for p in self.all_params(ctx):
            if isinstance(p, Option) and not p.hidden:
                out.extend(p.opts + p.secondary_opts)
        return out


def _term_width() -> int:
    try:
        return os.get_terminal_size().columns
    except OSError:
        return 80


def _help_callback(ctx: Context, param: Parameter, value: t.Any) -> None:
    if not value or ctx is None:
        return None
    _utils.echo(ctx.get_help())
    raise Exit(0)
