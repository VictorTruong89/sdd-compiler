"""Parameter types and conversion (PRD FP-05, FP-09; Interface section 5)."""

from __future__ import annotations

import datetime as _dt
import enum
import io
import os
import pathlib
import sys
import tempfile
import typing as t
import uuid as _uuid

from .exceptions import BadParameter, FileError


class ParamType:
    """Base class for parameter types."""

    name: str = "text"
    is_composite: bool = False
    arity: int = 1

    def __call__(self, value: t.Any, param: t.Any = None, ctx: t.Any = None) -> t.Any:
        return self.convert(value, param, ctx)

    def convert(self, value: t.Any, param: t.Any = None, ctx: t.Any = None) -> t.Any:
        return value

    def get_metavar(self, param: t.Any = None) -> t.Optional[str]:
        """Default metavar: the type name upper-cased."""
        return self.name.upper() if self.name else None

    def shell_complete(self, ctx: t.Any, param: t.Any, incomplete: str) -> list:
        return []

    def split_envvar_value(self, rv: str) -> list:
        return rv.split()

    def fail(self, message: str, param: t.Any = None, ctx: t.Any = None) -> t.NoReturn:
        raise BadParameter(message, ctx=ctx, param=param)

    def describe_choices(self) -> t.Optional[str]:
        return None

    def __repr__(self) -> str:
        return self.name.upper()


class _StringType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        return str(value) if not isinstance(value, str) else value


class _UnprocessedType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


class _IntType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            text = str(value).strip()
            return int(text, 10)
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class _FloatType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        if isinstance(value, int) and not isinstance(value, bool):
            return float(value)
        try:
            return float(str(value).strip())
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class _BoolType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class _UUIDType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value).strip())
        except (ValueError, TypeError, AttributeError):
            self.fail(f"{value!r} is not a valid UUID value.", param, ctx)


STRING = _StringType()
INT = _IntType()
FLOAT = _FloatType()
BOOL = _BoolType()
UUID = _UUIDType()
UNPROCESSED = _UnprocessedType()

# Map Python types to built-in instances (used for inference from defaults).
BUILTIN_BY_PYTYPE: dict = {
    str: STRING,
    int: INT,
    float: FLOAT,
    bool: BOOL,
    _uuid.UUID: UUID,
}


def convert_type(ty: t.Any, default: t.Any = None) -> ParamType:
    """Turn a user-supplied type (instance, class, callable) into a ParamType."""
    if ty is None:
        if default is not None and not callable(default):
            if isinstance(default, (tuple, list)):
                if default:
                    return convert_type(None, default[0])
                return STRING
            guessed = BUILTIN_BY_PYTYPE.get(type(default))
            if guessed is not None:
                return guessed
        return STRING
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, type):
        if issubclass(ty, ParamType):
            return ty()
        guessed = BUILTIN_BY_PYTYPE.get(ty)
        if guessed is not None:
            return guessed
        if ty is tuple or ty is list:
            return STRING
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"Unknown type {ty!r}")


class FuncParamType(ParamType):
    """Wraps a conversion function f(token) -> value that raises ValueError."""

    def __init__(self, func: t.Callable) -> None:
        self.func = func
        self.name = getattr(func, "__name__", "text") or "text"

    def convert(self, value, param=None, ctx=None):
        from .exceptions import BadParameter as _BP

        try:
            return self.func(value)
        except _BP as e:
            if e.param is None:
                e.param = param
            if e.ctx is None:
                e.ctx = ctx
            raise
        except ValueError as e:
            self.fail(str(e) or f"{value!r} is not valid.", param, ctx)


class Choice(ParamType):
    name = "choice"

    def __init__(self, choices: t.Iterable, case_sensitive: bool = True) -> None:
        self.case_sensitive = case_sensitive
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self._enum = choices
            self._pairs = [(m.name, m) for m in choices]
        else:
            self._enum = None
            self._pairs = [(str(c), c) for c in choices]
        self.choices = [p[1] for p in self._pairs]

    def get_metavar(self, param=None):
        return "[" + "|".join(str(n) for n, _ in self._pairs) + "]"

    def describe_choices(self) -> str:
        return ", ".join(repr(n) for n, _ in self._pairs)

    def _norm(self, s: str) -> str:
        return s if self.case_sensitive else s.casefold()

    def convert(self, value, param=None, ctx=None):
        if self._enum is not None and isinstance(value, self._enum):
            return value
        if self._enum is None and value in self.choices:
            return value
        normalize = None
        if ctx is not None:
            normalize = getattr(ctx, "token_normalize_func", None)
        token = str(value)
        for name, original in self._pairs:
            cand = name
            if normalize:
                if self._norm(normalize(token)) == self._norm(normalize(cand)):
                    return original
            elif self._norm(token) == self._norm(cand):
                return original
        self.fail(
            f"{value!r} is not {self.describe_choice_phrase()}.", param, ctx
        )

    def describe_choice_phrase(self) -> str:
        return "one of " + ", ".join(repr(n) for n, _ in self._pairs)

    def shell_complete(self, ctx, param, incomplete):
        return [n for n, _ in self._pairs if n.startswith(incomplete)]


_DEFAULT_DT_FORMATS = [
    "%Y-%m-%d",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M:%S",
]


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats: t.Optional[t.Sequence[str]] = None) -> None:
        self.formats = list(formats) if formats is not None else list(_DEFAULT_DT_FORMATS)

    def get_metavar(self, param=None):
        return "[" + "|".join(self.formats) + "]"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        text = str(value).strip()
        result = None
        for fmt in self.formats:
            try:
                result = _dt.datetime.strptime(text, fmt)
            except ValueError:
                continue
        if result is None:
            self.fail(
                f"{value!r} does not match the formats "
                + ", ".join(repr(f) for f in self.formats) + ".",
                param, ctx,
            )
        return result


class _RangeMixin:
    def _check(self, value, param, ctx):
        mn, mx = self.min, self.max
        if mn is not None:
            if self.min_open:
                if value <= mn:
                    if self.clamp:
                        return self._clamp_low(mn)
                    self.fail(f"{value!r} is not in the range {self._range_text()}.", param, ctx)
            elif value < mn:
                if self.clamp:
                    return mn
                self.fail(f"{value!r} is not in the range {self._range_text()}.", param, ctx)
        if mx is not None:
            if self.max_open:
                if value >= mx:
                    if self.clamp:
                        return self._clamp_high(mx)
                    self.fail(f"{value!r} is not in the range {self._range_text()}.", param, ctx)
            elif value > mx:
                if self.clamp:
                    return mx
                self.fail(f"{value!r} is not in the range {self._range_text()}.", param, ctx)
        return value

    def _range_text(self) -> str:
        lo = "" if self.min is None else (("(" if self.min_open else "[") + str(self.min))
        hi = "" if self.max is None else (str(self.max) + (")" if self.max_open else "]"))
        if lo and hi:
            return f"{lo}, {hi}"
        return lo or hi or "(-inf, inf)"


class IntRange(_RangeMixin, _IntType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False) -> None:
        self.min, self.max = min, max
        self.min_open, self.max_open = min_open, max_open
        self.clamp = clamp

    def _clamp_low(self, mn):
        return mn + 1

    def _clamp_high(self, mx):
        return mx - 1

    def convert(self, value, param=None, ctx=None):
        value = _IntType.convert(self, value, param, ctx)
        return self._check(value, param, ctx)


class FloatRange(_RangeMixin, _FloatType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False) -> None:
        if clamp and (min_open or max_open):
            raise TypeError("Clamping is not supported for open bounds.")
        if min is not None and max is not None and min > max:
            raise TypeError("min must not be greater than max.")
        self.min, self.max = min, max
        self.min_open, self.max_open = min_open, max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        value = _FloatType.convert(self, value, param, ctx)
        return float(self._check(value, param, ctx))


class Tuple(ParamType):
    name = "tuple"
    is_composite = True

    def __init__(self, types: t.Sequence) -> None:
        self.types = [convert_type(x) for x in types]
        self.arity = len(self.types)

    def get_metavar(self, param=None):
        return " ".join(ty.get_metavar(param) or ty.name.upper() for ty in self.types)

    def convert(self, value, param=None, ctx=None):
        if not isinstance(value, (tuple, list)):
            self.fail(f"{value!r} is not a tuple.", param, ctx)
        if len(value) != len(self.types):
            self.fail(
                f"{len(value)} values given, but {len(self.types)} are required.",
                param, ctx,
            )
        return tuple(ty.convert(v, param, ctx) for ty, v in zip(self.types, value))


class _PassThrough(ParamType):
    name = "text"


def _split_path_env(value: str) -> list:
    return [p for p in value.split(os.pathsep)] if value else []


class LazyFile(io.IOBase):
    """Opens its target on first I/O. Used for write-mode files and lazy reads."""

    def __init__(self, filename, mode, encoding, errors, atomic=False):
        self._filename = filename
        self._mode = mode
        self._encoding = encoding
        self._errors = errors
        self._atomic = atomic
        self._fh = None
        self._tmp = None

    def _open(self):
        if self._fh is not None:
            return self._fh
        try:
            binary = "b" in self._mode
            if self._atomic and "w" in self._mode:
                d = os.path.dirname(os.path.abspath(self._filename))
                fd, tmp = tempfile.mkstemp(dir=d, prefix=".optlyn-")
                os.close(fd)
                self._tmp = tmp
                target = tmp
            else:
                target = self._filename
            if binary:
                self._fh = open(target, self._mode)
            else:
                self._fh = open(target, self._mode, encoding=self._encoding, errors=self._errors)
        except OSError as e:
            raise FileError(str(self._filename), e.strerror or "") from e
        return self._fh

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return getattr(self._open(), name)

    def write(self, data):
        return self._open().write(data)

    def read(self, *a):
        return self._open().read(*a)

    def readline(self, *a):
        return self._open().readline(*a)

    def __iter__(self):
        return iter(self._open())

    def close(self):
        if self._fh is not None:
            self._fh.close()
            self._fh = None
            if self._tmp is not None:
                os.replace(self._tmp, self._filename)
                self._tmp = None
        super().close()

    @property
    def name(self):
        return self._filename


class _StdStream:
    """Wraps a standard stream; closing it does not close the real stream."""

    def __init__(self, stream):
        self._s = stream

    def __getattr__(self, name):
        return getattr(self._s, name)

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def __iter__(self):
        return iter(self._s)


def open_file_helper(filename, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
    """Shared implementation of File.convert and utils.open_file."""
    if mode not in ("r", "w", "rb", "wb"):
        raise ValueError(f"Unsupported file mode {mode!r}")
    if lazy is None:
        lazy = "w" in mode
    if filename == "-":
        if "r" in mode:
            stream = sys.stdin.buffer if "b" in mode else sys.stdin
        else:
            stream = sys.stdout.buffer if "b" in mode else sys.stdout
        return _StdStream(stream)
    if "b" in mode:
        encoding = None
        errors = None
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    if atomic and "w" in mode:
        lf = LazyFile(filename, mode, encoding, errors, atomic=True)
        try:
            lf._open()
        except FileError:
            raise
        return lf
    try:
        if "b" in mode:
            return open(filename, mode)
        return open(filename, mode, encoding=encoding, errors=errors)
    except OSError as e:
        raise FileError(str(filename), e.strerror or "") from e


class File(ParamType):
    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False) -> None:
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"Unsupported file mode {mode!r}")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def get_metavar(self, param=None):
        return "FILENAME"

    def shell_complete(self, ctx, param, incomplete):
        return [{"type": "file", "incomplete": incomplete}]

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        try:
            if value == "-":
                return open_file_helper("-", self.mode, self.encoding, self.errors)
            lazy = self.lazy
            if lazy is None:
                lazy = "w" in self.mode
            if lazy:
                return open_file_helper(value, self.mode, self.encoding, self.errors, lazy=True, atomic=self.atomic)
            return open_file_helper(value, self.mode, self.encoding, self.errors, lazy=False, atomic=self.atomic)
        except FileError as e:
            self.fail(f"'{value}': {e.message}", param, ctx)
        except OSError as e:
            self.fail(f"'{value}': {e.strerror or e}", param, ctx)

    def split_envvar_value(self, rv: str) -> list:
        return _split_path_env(rv)


class Path(ParamType):
    name = "path"

    def __init__(
        self,
        exists=False,
        file_okay=True,
        dir_okay=True,
        writable=False,
        readable=True,
        resolve_path=False,
        allow_dash=False,
        path_type=None,
        executable=False,
    ) -> None:
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def get_metavar(self, param=None):
        return "PATH"

    def shell_complete(self, ctx, param, incomplete):
        if self.file_okay and not self.dir_okay:
            return [{"type": "file", "incomplete": incomplete}]
        if self.dir_okay and not self.file_okay:
            return [{"type": "dir", "incomplete": incomplete}]
        return [{"type": "file", "incomplete": incomplete}]

    def split_envvar_value(self, rv: str) -> list:
        return _split_path_env(rv)

    def convert(self, value, param=None, ctx=None):
        raw = value
        if isinstance(value, pathlib.PurePath):
            raw = str(value)
        if self.allow_dash and raw == "-":
            return self._out(raw)
        if self.resolve_path:
            raw = os.path.expanduser(raw) if raw.startswith("~") else raw
            raw = os.path.realpath(raw)
        exists = os.path.exists(raw)
        if self.exists and not exists:
            self.fail(f"{value!r} does not exist.", param, ctx)
        if exists:
            if not self.file_okay and os.path.isfile(raw):
                self.fail(f"{value!r} is a file.", param, ctx)
            if not self.dir_okay and os.path.isdir(raw):
                self.fail(f"{value!r} is a directory.", param, ctx)
            if self.readable and not os.access(raw, os.R_OK):
                self.fail(f"{value!r} is not readable.", param, ctx)
            if self.writable and not os.access(raw, os.W_OK):
                self.fail(f"{value!r} is not writable.", param, ctx)
            if self.executable and not os.access(raw, os.X_OK):
                self.fail(f"{value!r} is not executable.", param, ctx)
        return self._out(raw)

    def _out(self, raw):
        if self.path_type is None or self.path_type is str:
            return raw
        if self.path_type is pathlib.Path:
            return pathlib.Path(raw)
        return self.path_type(raw)
