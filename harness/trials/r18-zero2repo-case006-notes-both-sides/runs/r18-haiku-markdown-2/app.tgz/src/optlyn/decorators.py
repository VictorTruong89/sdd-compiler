"""Public declaration decorators (Interface sections 3, 4 and 2)."""

from __future__ import annotations

import re
import typing as t

from . import utils as _utils
from .context import Context
from .core import Command
from .exceptions import Exit
from .group import CommandCollection, Group
from .params import Argument, Option, Parameter

_SUFFIXES = ("_command", "_cmd", "_group", "_grp")


def _attach(f: t.Callable, param: Parameter) -> None:
    """Attach a declaration to a function; command() will move it."""
    store = f.__dict__.setdefault("__optlyn_params__", [])
    store.insert(0, param)  # top-most declaration first, as written


def _pop_params(f: t.Any) -> t.List[Parameter]:
    if isinstance(f, Command):
        return []
    params = f.__dict__.pop("__optlyn_params__", [])
    return list(params)


def _derive_name(func_name: str) -> str:
    name = func_name.lower().replace("_", "-")
    for suffix in _SUFFIXES:
        suf = suffix.replace("_", "-")
        if name.endswith(suf) and len(name) > len(suf):
            return name[: -len(suf)]
    return name


def command(name: t.Any = None, cls: t.Optional[type] = None, **attrs: t.Any) -> t.Any:
    """Declare a leaf command from a function (used as @command() or @command)."""
    if callable(name) and not isinstance(name, str):
        return command(None, cls, **attrs)(name)

    def decorator(f: t.Callable) -> Command:
        cmd_cls = cls or Command
        cmd_name = name if name is not None else _derive_name(f.__name__)
        params = _pop_params(f)
        return cmd_cls(name=cmd_name, callback=f, params=params, **attrs)

    return decorator


def group(name: t.Any = None, cls: t.Optional[type] = None, **attrs: t.Any) -> t.Any:
    """Declare a group from a function (used as @group() or @group)."""
    if callable(name) and not isinstance(name, str):
        return group(None, cls, **attrs)(name)

    def decorator(f: t.Callable) -> Group:
        grp_cls = cls or Group
        grp_name = name if name is not None else _derive_name(f.__name__)
        params = _pop_params(f)
        return grp_cls(name=grp_name, callback=f, params=params, **attrs)

    return decorator


def option(*param_decls: str, cls: t.Optional[type] = None, **attrs: t.Any) -> t.Callable:
    """Attach an option to the function that follows."""
    option_cls = cls or Option

    def decorator(f: t.Callable) -> t.Callable:
        _attach(f, option_cls(list(param_decls), **attrs))
        return f

    return decorator


def argument(*param_decls: str, cls: t.Optional[type] = None, **attrs: t.Any) -> t.Callable:
    """Attach a positional argument to the function that follows."""
    arg_cls = cls or Argument

    def decorator(f: t.Callable) -> t.Callable:
        _attach(f, arg_cls(list(param_decls), **attrs))
        return f

    return decorator


def _eager_flag(decls: t.Sequence[str], callback: t.Callable, default_decl: str,
                kwargs: dict) -> Option:
    names = list(decls) or [default_decl]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("hidden", False)
    kwargs.setdefault("callback", callback)
    return Option(names, **kwargs)


def _help_flag_callback(ctx: Context, param: Parameter, value: t.Any) -> None:
    if not value or ctx is None:
        return None
    _utils.echo(ctx.get_help())
    raise Exit(0)


def help_option(*param_decls: str, **kwargs: t.Any) -> t.Callable:
    """Attach an extra eager help flag (does not remove the automatic one)."""
    names = list(param_decls) or ["--help"]
    p = Option(names, is_flag=True, is_eager=True, expose_value=False,
               callback=_help_flag_callback, **kwargs)

    def decorator(f: t.Callable) -> t.Callable:
        _attach(f, p)
        return f

    return decorator


def _version_text(ctx: Context, version: t.Optional[str], package_name: t.Optional[str],
                  prog_name: t.Optional[str], message: t.Optional[str]) -> str:
    detected = version
    if detected is None and package_name:
        detected = _detect_version(package_name)
    root = ctx
    while root.parent is not None:
        root = root.parent
    prog = prog_name or root.info_name or "cli"
    msg = message or "%(prog)s, version %(version)s"
    return msg % {"prog": prog, "version": detected or "unknown"}


def _detect_version(name: str) -> t.Optional[str]:
    try:
        from importlib import metadata
    except ImportError:  # pragma: no cover
        return None
    try:
        return metadata.version(name)
    except metadata.PackageNotFoundError:
        pass
    # not a distribution name: treat it as an import name
    try:
        mapping = metadata.packages_distributions()
    except Exception:
        return None
    for dist in mapping.get(name, []):
        try:
            return metadata.version(dist)
        except metadata.PackageNotFoundError:
            continue
    return None


def version_option(version: t.Optional[str] = None, *param_decls: str,
                   package_name: t.Optional[str] = None, prog_name: t.Optional[str] = None,
                   message: t.Optional[str] = None, **kwargs: t.Any) -> t.Callable:
    """Attach an eager --version flag that prints the identity and exits."""

    def callback(ctx: Context, param: Parameter, value: t.Any) -> None:
        if not value or ctx is None:
            return None
        _utils.echo(_version_text(ctx, version, package_name, prog_name, message))
        raise Exit(0)

    p = _eager_flag(param_decls, callback, "--version", kwargs)

    def decorator(f: t.Callable) -> t.Callable:
        _attach(f, p)
        return f

    return decorator


def custom_version_option(callback_fn: t.Callable[[Context], str], *param_decls: str,
                          **kwargs: t.Any) -> t.Callable:
    """Attach an eager version flag whose identity is callback(ctx) verbatim."""

    def callback(ctx: Context, param: Parameter, value: t.Any) -> None:
        if not value or ctx is None:
            return None
        _utils.echo(callback_fn(ctx))
        raise Exit(0)

    p = _eager_flag(param_decls, callback, "--version", kwargs)

    def decorator(f: t.Callable) -> t.Callable:
        _attach(f, p)
        return f

    return decorator


def password_option(*param_decls: str, **kwargs: t.Any) -> t.Callable:
    """Hidden, prompting, confirmed option (default --password)."""
    names = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    p = Option(names, **kwargs)

    def decorator(f: t.Callable) -> t.Callable:
        _attach(f, p)
        return f

    return decorator


def confirmation_option(*param_decls: str, **kwargs: t.Any) -> t.Callable:
    """Yes-style flag: asks when omitted, aborts when declined; not passed on."""
    names = list(param_decls) or ["--yes"]
    question = kwargs.pop("prompt", None) or "Do you want to continue?"
    help_text = kwargs.pop("help", None) or "Confirm the action without prompting."

    def callback(ctx: Context, param: Parameter, value: t.Any) -> t.Any:
        if value:
            return value
        if ctx is None:
            return value
        _utils.confirm(question, default=False, abort=True)
        return True

    p = Option(names, is_flag=True, is_eager=False, expose_value=False,
               callback=callback, help=help_text, **kwargs)

    def decorator(f: t.Callable) -> t.Callable:
        _attach(f, p)
        return f

    return decorator
