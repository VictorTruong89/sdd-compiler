"""Optlyn: a command line interface composition kit (Interface Contract section 1)."""

from .exceptions import (
    Abort,
    BadParameter,
    Exit,
    OptlynError,
    UsageError,
)
from .params import Argument, Option, Parameter
from .types import (
    BOOL,
    FLOAT,
    INT,
    STRING,
    UNPROCESSED,
    UUID,
    Choice,
    DateTime,
    File,
    FloatRange,
    IntRange,
    ParamType,
    Path,
    Tuple,
)
from .context import (
    Context,
    get_current_context,
    make_pass_decorator,
    pass_context,
    pass_obj,
)
from .core import Command
from .group import CommandCollection, Group
from .decorators import (
    argument,
    command,
    confirmation_option,
    custom_version_option,
    group,
    help_option,
    option,
    password_option,
    version_option,
)
from .utils import (
    clear,
    confirm,
    echo,
    echo_via_pager,
    edit,
    format_filename,
    get_app_dir,
    get_pager_file,
    getchar,
    launch,
    open_file,
    pause,
    progressbar,
    prompt,
    secho,
    style,
    unstyle,
)

__version__ = "0.1.0"

__all__ = [
    # declaration
    "command", "group", "option", "argument", "help_option", "version_option",
    "custom_version_option", "password_option", "confirmation_option",
    "pass_context", "pass_obj", "make_pass_decorator",
    # classes
    "Command", "Group", "CommandCollection", "Context", "Option", "Parameter",
    "ParamType", "BadParameter", "Abort", "Argument", "UsageError", "Exit", "OptlynError",
    # types
    "STRING", "INT", "FLOAT", "BOOL", "UUID", "UNPROCESSED",
    "Choice", "DateTime", "IntRange", "FloatRange", "Tuple", "File", "Path",
    # terminal helpers
    "echo", "secho", "style", "unstyle", "echo_via_pager", "get_pager_file",
    "progressbar", "prompt", "confirm", "getchar", "pause", "edit", "launch", "clear",
    "get_app_dir", "get_current_context", "format_filename", "open_file",
]
