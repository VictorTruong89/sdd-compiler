"""Groups, chaining groups, and command collections (PRD FP-06, FP-10)."""

from __future__ import annotations

import typing as t

from .context import Context
from .core import Command, NoArgsHelp
from .exceptions import MissingCommand, NoSuchCommand, UsageError
from .formatting import short_help_text
from .params import Argument

CHAIN_MARK = object()  # value of ctx.invoked_subcommand on a chaining group


class Group(Command):
    """A command that dispatches to named subcommands."""

    is_group = True

    def __init__(
        self,
        name: t.Optional[str] = None,
        commands: t.Any = None,
        invoke_without_command: bool = False,
        no_args_is_help: t.Optional[bool] = None,
        subcommand_metavar: t.Optional[str] = None,
        chain: bool = False,
        result_callback: t.Optional[t.Callable] = None,
        **kwargs: t.Any,
    ) -> None:
        super().__init__(name, **kwargs)
        self.commands: t.Dict[str, Command] = {}
        self.invoke_without_command = invoke_without_command
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        self.no_args_is_help = no_args_is_help
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self.result_callback_func = result_callback
        if commands:
            if isinstance(commands, dict):
                for cname, cmd in commands.items():
                    self.add_command(cmd, cname)
            else:
                for cmd in commands:
                    self.add_command(cmd)

    # --- registration -------------------------------------------------------
    def add_command(self, cmd: Command, name: t.Optional[str] = None) -> None:
        if name is None:
            name = cmd.name
        if name is None:
            raise TypeError("A command needs a name to be registered.")
        if self.chain and isinstance(cmd, Group):
            raise TypeError("Groups cannot be nested under a chaining group.")
        self.commands[name] = cmd

    def command(self, *args: t.Any, **kwargs: t.Any) -> t.Callable:
        from .decorators import command as _command

        def decorator(f):
            cmd = _command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args: t.Any, **kwargs: t.Any) -> t.Callable:
        from .decorators import group as _group

        def decorator(f):
            cmd = _group(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self) -> t.Callable:
        def decorator(f):
            self.result_callback_func = f
            return f

        return decorator

    # --- lookup (override points for lazy loading) --------------------------
    def list_commands(self, ctx: Context) -> t.List[str]:
        return list(self.commands.keys())

    def get_command(self, ctx: Context, cmd_name: str) -> t.Optional[Command]:
        return self.commands.get(cmd_name)

    def resolve_command(self, ctx: Context, name: str) -> t.Optional[Command]:
        cmd = self.get_command(ctx, name)
        if cmd is None and ctx.token_normalize_func is not None:
            norm = ctx.token_normalize_func
            for other in self.list_commands(ctx):
                if norm(other) == norm(name):
                    return self.get_command(ctx, other)
        return cmd

    # --- parsing ------------------------------------------------------------
    def _stop_after(self, args: t.List[Argument]) -> int:
        return sum(a.nargs for a in args if a.nargs > 0)

    def _is_command_token(self, ctx: Context, tok: str) -> bool:
        if tok.startswith("-") and len(tok) > 1:
            return False
        return self.resolve_command(ctx, tok) is not None

    # --- invocation ---------------------------------------------------------
    def _run_callback(self, ctx: Context) -> t.Any:
        if self.callback is None:
            return None
        ctx._push()
        try:
            return self.callback(**ctx.params)
        finally:
            ctx._pop()

    def _run_result_callback(self, ctx: Context, value: t.Any) -> t.Any:
        if self.result_callback_func is None:
            return value
        ctx._push()
        try:
            return self.result_callback_func(value, **ctx.params)
        finally:
            ctx._pop()

    def invoke(self, ctx: Context) -> t.Any:
        self._warn_if_deprecated()
        rest: t.List[str] = list(ctx._rest or [])
        if not rest:
            if self.invoke_without_command:
                ctx.invoked_subcommand = None
                rv = self._run_callback(ctx)
                if self.chain:
                    self._run_result_callback(ctx, [])
                    return []
                return rv if self.result_callback_func is None else self._run_result_callback(ctx, rv)
            if self.no_args_is_help and not ctx._raw_args:
                raise NoArgsHelp(ctx)
            raise MissingCommand("Missing command.", ctx=ctx)
        if self.chain:
            return self._invoke_chain(ctx, rest)
        name, sub_args = rest[0], rest[1:]
        cmd = self.resolve_command(ctx, name)
        if cmd is None:
            raise NoSuchCommand(name, ctx=ctx)
        ctx.invoked_subcommand = name
        self._run_callback(ctx)  # the group callback runs before its child
        sub_ctx = cmd.make_context(name, sub_args, parent=ctx)
        try:
            child_rv = cmd.invoke(sub_ctx)
        finally:
            sub_ctx.close()
        return self._run_result_callback(ctx, child_rv)

    def _invoke_chain(self, ctx: Context, rest: t.List[str]) -> t.List[t.Any]:
        ctx.invoked_subcommand = CHAIN_MARK
        self._run_callback(ctx)
        results: t.List[t.Any] = []
        tokens = list(rest)
        while tokens:
            name = tokens[0]
            cmd = self.resolve_command(ctx, name)
            if cmd is None:
                raise NoSuchCommand(name, ctx=ctx)
            j = 1
            while j < len(tokens) and not self._is_command_token(ctx, tokens[j]):
                j += 1
            sub_args = tokens[1:j]
            tokens = tokens[j:]
            sub_ctx = cmd.make_context(name, sub_args, parent=ctx)
            try:
                results.append(cmd.invoke(sub_ctx))
            finally:
                sub_ctx.close()
        self._run_result_callback(ctx, results)
        return results

    # --- help ---------------------------------------------------------------
    def _usage_pieces(self, ctx: Context) -> t.List[str]:
        pieces = super()._usage_pieces(ctx)
        meta = self.subcommand_metavar or ("COMMAND1 [ARGS]... [COMMAND2 [ARGS]...]..." if self.chain else "COMMAND [ARGS]...")
        if self.chain:
            pieces.append(meta)
        elif self.invoke_without_command:
            pieces.append("[" + meta + "]")
        else:
            pieces.append(meta)
        return pieces

    def _extra_help_sections(self, ctx: Context, width: int) -> t.List[str]:
        rows = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            text = cmd.short_help or cmd.help or ""
            rows.append((name, short_help_text(text) if not cmd.short_help else cmd.short_help))
        if not rows:
            return []
        from .formatting import join_columns

        return ["Commands:"] + join_columns(rows, width=width) + [""]

    def shell_complete_commands(self, ctx: Context) -> t.List[str]:
        out = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is not None and not cmd.hidden:
                out.append(name)
        return out


class CommandCollection(Group):
    """Presents the union of subcommands from several source groups."""

    def __init__(self, name: t.Optional[str] = None, sources: t.Optional[t.List[Group]] = None,
                 **kwargs: t.Any) -> None:
        super().__init__(name, **kwargs)
        self.sources: t.List[Group] = list(sources or [])

    def list_commands(self, ctx: Context) -> t.List[str]:
        seen: t.List[str] = []
        for src in self.sources:
            for n in src.list_commands(ctx):
                if n not in seen:
                    seen.append(n)
        for n in super().list_commands(ctx):
            if n not in seen:
                seen.append(n)
        return seen

    def get_command(self, ctx: Context, cmd_name: str) -> t.Optional[Command]:
        for src in self.sources:
            cmd = src.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return super().get_command(ctx, cmd_name)
