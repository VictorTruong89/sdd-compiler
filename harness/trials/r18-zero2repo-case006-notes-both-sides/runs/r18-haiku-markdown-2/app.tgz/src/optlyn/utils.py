"""Terminal helpers (PRD FP-08, FP-11; Interface section 7)."""

from __future__ import annotations

import codecs
import contextlib
import os
import re
import shlex
import subprocess
import sys
import tempfile
import time
import typing as t

from .exceptions import Abort, BadParameter
from . import types as _types

_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")

_NAMED_FG = {
    "black": 30, "red": 31, "green": 32, "yellow": 33,
    "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
    "reset": 39,
}
_SWITCHES = {
    "bold": 1, "dim": 2, "italic": 3, "underline": 4, "blink": 5,
    "reverse": 7, "strikethrough": 9, "overline": 53,
}


def _color_codes(color: t.Any, background: bool) -> t.List[str]:
    base = 40 if background else 30
    if isinstance(color, str):
        if color not in _NAMED_FG:
            raise TypeError(f"Unknown color {color!r}.")
        code = _NAMED_FG[color]
        if background:
            if color == "reset":
                code = 49
            elif code >= 90:
                code += 10
            else:
                code += 10
        return [str(code)]
    if isinstance(color, bool):
        raise TypeError("Invalid color.")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise TypeError("Color index must be between 0 and 255.")
        return [("48" if background else "38"), "5", str(color)]
    if isinstance(color, (tuple, list)) and len(color) == 3 and all(
        isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
    ):
        return [("48" if background else "38"), "2"] + [str(c) for c in color]
    raise TypeError(f"Invalid color {color!r}.")


def style(text: t.Any, fg: t.Any = None, bg: t.Any = None, bold: t.Any = None,
          dim: t.Any = None, underline: t.Any = None, overline: t.Any = None,
          italic: t.Any = None, blink: t.Any = None, reverse: t.Any = None,
          strikethrough: t.Any = None, reset: bool = True) -> str:
    """Wrap text in ANSI SGR sequences. Invalid colors raise TypeError."""
    codes: t.List[str] = []
    if fg is not None:
        codes += _color_codes(fg, False)
    if bg is not None:
        codes += _color_codes(bg, True)
    switches = {
        "bold": bold, "dim": dim, "underline": underline, "overline": overline,
        "italic": italic, "blink": blink, "reverse": reverse, "strikethrough": strikethrough,
    }
    for name, value in switches.items():
        if value:
            codes.append(str(_SWITCHES[name]))
    text = str(text)
    if not codes:
        return text
    out = "\x1b[" + ";".join(codes) + "m" + text
    if reset:
        out += "\x1b[0m"
    return out


def unstyle(text: str) -> str:
    return _ANSI_RE.sub("", text)


def _is_tty(stream: t.Any) -> bool:
    try:
        return bool(stream is not None and stream.isatty())
    except Exception:
        return False


def is_interactive() -> bool:
    return _is_tty(sys.stdin) or _is_tty(sys.stdout)


def _current_color(color: t.Optional[bool]) -> t.Optional[bool]:
    if color is not None:
        return color
    from .context import get_current_context

    ctx = get_current_context(silent=True)
    return ctx.color if ctx is not None else None


def _write_text(stream: t.Any, text: str) -> None:
    enc = getattr(stream, "encoding", None) or ""
    ascii_only = False
    try:
        ascii_only = bool(enc) and codecs.lookup(enc).name == "ascii"
    except LookupError:
        ascii_only = False
    buf = getattr(stream, "buffer", None)
    if ascii_only and buf is not None:
        buf.write(text.encode("utf-8"))
        return
    try:
        stream.write(text)
    except UnicodeEncodeError:
        if buf is not None:
            buf.write(text.encode("utf-8"))
        else:
            raise


def echo(message: t.Any = None, file: t.Any = None, nl: bool = True,
         err: bool = False, color: t.Optional[bool] = None) -> None:
    """Write text or bytes to stdout (or stderr / file)."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        buf = getattr(file, "buffer", None)
        if buf is not None:
            buf.write(message + (b"\n" if nl else b""))
            buf.flush()
        else:
            file.write(message.decode("utf-8", "replace") + ("\n" if nl else ""))
        return
    text = str(message)
    keep = _current_color(color)
    if keep is None:
        keep = _is_tty(file)
    if not keep:
        text = unstyle(text)
    if nl:
        text += "\n"
    _write_text(file, text)
    try:
        file.flush()
    except Exception:
        pass


def secho(message: t.Any = None, file: t.Any = None, nl: bool = True,
          err: bool = False, color: t.Optional[bool] = None, **styles: t.Any) -> None:
    if message is not None:
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


# ----------------------------------------------------------------------
# Input / prompts
def _read_line(stream: t.Any) -> str:
    line = stream.readline()
    if line == "" or line is None:
        raise EOFError()
    return line.rstrip("\r\n")


def prompt(text: str, default: t.Any = None, hide_input: bool = False,
           confirmation_prompt: bool = False, type: t.Any = None,
           value_proc: t.Optional[t.Callable] = None, prompt_suffix: str = ": ",
           show_default: bool = True, err: bool = False, show_choices: bool = True,
           _param: t.Any = None, _ctx: t.Any = None) -> t.Any:
    """Ask for a value, converting it; re-asks on conversion failure."""
    ptype = _types.convert_type(type, default)
    suffix_default = ""
    if default is not None and show_default and not callable(default):
        shown = default
        if isinstance(default, (list, tuple)):
            shown = ", ".join(str(x) for x in default)
        suffix_default = f" [{shown}]"
    while True:
        try:
            value = _ask(text + suffix_default + prompt_suffix, hide_input, err)
            if value == "" and default is not None:
                value = default() if callable(default) else default
                if not isinstance(value, str):
                    return value
            elif value == "" and default is None:
                continue
            if confirmation_prompt:
                second = _ask(f"Repeat for confirmation{prompt_suffix}", hide_input, err)
                if second != value:
                    echo("Error: The two entered values do not match.", err=True)
                    continue
            return ptype.convert(value, _param, _ctx)
        except BadParameter as e:
            echo(f"Error: {e.message}", err=True)
        except EOFError:
            raise Abort()
        except KeyboardInterrupt:
            raise Abort()


def _ask(prefix: str, hide_input: bool, err: bool) -> str:
    out = sys.stderr if err else sys.stdout
    out.write(prefix)
    out.flush()
    stdin = sys.stdin
    value = _read_line(stdin)
    if not hide_input and not _is_tty(stdin):
        # echo the line we actually read into the captured output (visible prompts)
        out.write(value + "\n")
        out.flush()
    elif hide_input:
        out.write("\n")
        out.flush()
    return value


def confirm(text: str, default: bool = False, abort: bool = False,
            prompt_suffix: str = ": ", show_default: bool = True,
            err: bool = False) -> bool:
    """Ask a yes/no question. Empty answer takes the default."""
    shown = ""
    if show_default:
        shown = " [Y/n]" if default else " [y/N]"
    while True:
        try:
            value = _ask(text + shown + prompt_suffix, False, err).strip().lower()
        except EOFError:
            raise Abort()
        if value == "":
            result = default
            break
        if value in ("y", "yes"):
            result = True
            break
        if value in ("n", "no"):
            result = False
            break
    if abort and not result:
        raise Abort()
    return result


def getchar(echo: bool = False) -> str:
    """Read one character from the controlling terminal (or stdin)."""
    try:
        import termios
        import tty

        fd = os.open("/dev/tty", os.O_RDONLY)
        try:
            old = termios.tcgetattr(fd)
            try:
                tty.setraw(fd)
                ch = os.read(fd, 1).decode("utf-8", "replace")
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
        finally:
            os.close(fd)
    except (ImportError, OSError):
        ch = sys.stdin.read(1)
    if ch == "":
        raise EOFError()
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    if echo:
        echo(ch, nl=False)
    return ch


def pause(info: t.Optional[str] = None, err: bool = False) -> None:
    if not is_interactive():
        return
    echo(info if info is not None else "Press any key to continue...", err=err, nl=False)
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass
    echo("", err=err)


# ----------------------------------------------------------------------
# Pager
def _pager_cmd() -> t.Optional[str]:
    return os.environ.get("PAGER") or None


def echo_via_pager(text_or_generator: t.Any, color: t.Optional[bool] = None) -> None:
    if callable(text_or_generator):
        chunks = text_or_generator()
    elif isinstance(text_or_generator, str):
        chunks = [text_or_generator]
    else:
        chunks = text_or_generator
    if not is_interactive() or not _pager_cmd():
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    with get_pager_file(color=color) as f:
        for chunk in chunks:
            f.write(str(chunk))
            f.flush()


@contextlib.contextmanager
def get_pager_file(color: t.Optional[bool] = None):
    if not is_interactive() or not _pager_cmd():
        yield _NonClosing(sys.stdout)
        return
    proc = subprocess.Popen(_pager_cmd(), shell=True, stdin=subprocess.PIPE, text=True)
    try:
        yield proc.stdin
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        proc.wait()


class _NonClosing:
    def __init__(self, stream):
        self._s = stream

    def __getattr__(self, name):
        return getattr(self._s, name)

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


# ----------------------------------------------------------------------
# Progress bar
class ProgressBar:
    def __init__(self, iterable=None, length=None, label=None, hidden=False, **options):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.pos = 0
        self.start = time.time()
        self.tty = _is_tty(sys.stdout) and not hidden
        self._printed_label = False
        if not hidden and not self.tty and self.label:
            echo(self.label)
            self._printed_label = True

    def _render(self):
        if not self.tty:
            return
        if self.length:
            frac = min(self.pos / self.length, 1.0)
            filled = int(frac * 30)
            elapsed = time.time() - self.start
            eta = (elapsed / frac - elapsed) if frac > 0 else 0
            bar = "#" * filled + "-" * (30 - filled)
            line = f"\r{self.label} [{bar}] {self.pos}/{self.length} eta {int(eta)}s"
        else:
            line = f"\r{self.label} {self.pos}"
        sys.stdout.write(line)
        sys.stdout.flush()

    def update(self, n_steps: int, current_item: t.Any = None) -> None:
        self.pos += n_steps
        if not self.hidden:
            self._render()

    def __iter__(self):
        if self.iterable is None:
            return
        for item in self.iterable:
            yield item
            self.update(1)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        if self.tty:
            sys.stdout.write("\n")
            sys.stdout.flush()
        return False


@contextlib.contextmanager
def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    bar = ProgressBar(iterable, length=length, label=label, hidden=hidden, **options)
    try:
        yield bar
    finally:
        bar.__exit__(None, None, None)


# ----------------------------------------------------------------------
# Editor, launch, clear, dirs, filenames, open
def edit(text: t.Optional[str] = None, editor: t.Optional[str] = None,
         env: t.Optional[dict] = None, require_save: bool = True,
         extension: str = ".txt", filename: t.Optional[str] = None):
    editor_cmd = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR") or "vi"
    environ = dict(os.environ)
    environ.update(env or {})
    if filename is not None:
        cmd = shlex.split(editor_cmd) + [filename]
        subprocess.call(cmd, env=environ)
        return None
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            if text:
                f.write(text)
        before = open(path, encoding="utf-8").read() if text else None
        subprocess.call(shlex.split(editor_cmd) + [path], env=environ)
        with open(path, encoding="utf-8") as f:
            result = f.read()
        if require_save and before == result:
            return None
        return result
    finally:
        os.remove(path)


def launch(url: str, wait: bool = False, locate: bool = False) -> int:
    if sys.platform == "darwin":
        cmd = ["open"] + (["-R"] if locate else []) + [url]
    elif sys.platform == "win32":
        os.startfile(url)  # type: ignore[attr-defined]
        return 0
    else:
        cmd = ["xdg-open", url]
    try:
        proc = subprocess.Popen(cmd)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0


def clear() -> None:
    if not _is_tty(sys.stdout):
        return
    sys.stdout.write("\x1b[2J\x1b[H")
    sys.stdout.flush()


def get_app_dir(app_name: str, roaming: bool = True, force_posix: bool = False) -> str:
    if sys.platform.startswith("win"):
        base = os.environ.get("APPDATA") or os.path.expanduser("~")
        return os.path.join(base, app_name)
    if sys.platform == "darwin" and not force_posix:
        return os.path.join(os.path.expanduser("~"), "Library", "Application Support", app_name)
    if force_posix:
        return os.path.join(os.path.expanduser("~"), "." + app_name.lower().replace(" ", "-"))
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
    folder = re.sub(r"\s+", "-", app_name.lower())
    return os.path.join(base, folder)


def format_filename(filename: t.Any, shorten: bool = False) -> str:
    if hasattr(filename, "__fspath__"):
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        text = filename.decode(sys.getfilesystemencoding() or "utf-8", "replace")
    else:
        text = str(filename)
    if shorten:
        text = os.path.basename(text)
    return text.encode("utf-8", "surrogateescape").decode("utf-8", "replace")


def open_file(filename: str, mode: str = "r", encoding: t.Optional[str] = None,
              errors: str = "strict", lazy: bool = False, atomic: bool = False):
    return _types.open_file_helper(filename, mode, encoding, errors, lazy=lazy, atomic=atomic)


def get_text_stdin(encoding=None, errors=None):
    return sys.stdin


def get_text_stdout(encoding=None, errors=None):
    return sys.stdout


def get_text_stderr(encoding=None, errors=None):
    return sys.stderr
