"""In-process runner (PRD FP-14; Interface section 9)."""

from __future__ import annotations

import contextlib
import io
import os
import shutil
import sys
import tempfile
import typing as t


class _Capture(io.RawIOBase):
    """Raw sink that records writes to its own buffer and a shared combined buffer."""

    def __init__(self, combined: io.BytesIO) -> None:
        self.buf = io.BytesIO()
        self.combined = combined

    def writable(self) -> bool:
        return True

    def write(self, b) -> int:
        data = bytes(b)
        self.buf.write(data)
        self.combined.write(data)
        return len(data)

    def readable(self) -> bool:
        return False


class Result:
    """Outcome of CliRunner.invoke."""

    def __init__(self, runner, stdout_bytes: bytes, stderr_bytes: bytes, combined: bytes,
                 return_value: t.Any, exit_code: int, exception: t.Optional[BaseException],
                 exc_info: t.Any = None) -> None:
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self._combined = combined
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self) -> str:
        return self._combined.decode(self.runner.charset, "replace")

    @property
    def stdout(self) -> str:
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self) -> str:
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    def __repr__(self) -> str:
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    """Invoke a command in-process and capture its output."""

    def __init__(
        self,
        charset: str = "utf-8",
        env: t.Optional[t.Mapping[str, t.Optional[str]]] = None,
        echo_stdin: bool = False,
        catch_exceptions: bool = True,
        capture: str = "sys",
    ) -> None:
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input: t.Any = None, env: t.Optional[t.Mapping] = None):
        input_bytes: bytes
        if input is None:
            input_bytes = b""
        elif isinstance(input, str):
            input_bytes = input.encode(self.charset)
        else:
            input_bytes = bytes(input)
        merged_env = dict(self.env)
        merged_env.update(env or {})
        saved_env = {}
        for k, v in merged_env.items():
            saved_env[k] = os.environ.get(k)
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = str(v)

        combined = io.BytesIO()
        out_raw = _Capture(combined)
        err_raw = _Capture(combined)
        old_stdin, old_stdout, old_stderr = sys.stdin, sys.stdout, sys.stderr
        sys.stdin = io.TextIOWrapper(io.BytesIO(input_bytes), encoding=self.charset)
        sys.stdout = io.TextIOWrapper(out_raw, encoding=self.charset, write_through=True,
                                      errors="replace", newline="\n")
        sys.stderr = io.TextIOWrapper(err_raw, encoding=self.charset, write_through=True,
                                      errors="backslashreplace", newline="\n")
        try:
            yield (out_raw, err_raw, combined)
        finally:
            try:
                sys.stdout.flush()
                sys.stderr.flush()
            except Exception:
                pass
            sys.stdin, sys.stdout, sys.stderr = old_stdin, old_stdout, old_stderr
            for k, v in saved_env.items():
                if v is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = v

    def invoke(
        self,
        cli: t.Any,
        args: t.Any = None,
        input: t.Any = None,
        env: t.Optional[t.Mapping] = None,
        catch_exceptions: t.Optional[bool] = None,
        color: bool = False,
        **extra: t.Any,
    ) -> Result:
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if isinstance(args, str):
            import shlex

            args = shlex.split(args)
        args = list(args or [])
        extra.setdefault("standalone_mode", True)
        extra.setdefault("prog_name", "cli")
        extra.setdefault("color", color)
        standalone = extra.get("standalone_mode", True)
        exit_code = 0
        exception: t.Optional[BaseException] = None
        return_value: t.Any = None
        exc_info = None
        with self.isolation(input=input, env=env) as (out_raw, err_raw, combined):
            try:
                prog = extra.pop("prog_name")
                color_flag = extra.pop("color")
                return_value = cli.main(args=args, prog_name=prog, color=color_flag,
                                        **extra)
                if not standalone:
                    exit_code = 0
            except SystemExit as e:
                code = e.code
                if code is None:
                    exit_code = 0
                elif isinstance(code, int):
                    exit_code = code
                else:
                    sys.stdout.write(str(code) + "\n")
                    exit_code = 1
                if exit_code != 0:
                    exception = e
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                import traceback

                exc_info = sys.exc_info()
                _ = traceback
            finally:
                try:
                    sys.stdout.flush()
                    sys.stderr.flush()
                except Exception:
                    pass
            stdout_bytes = out_raw.buf.getvalue()
            stderr_bytes = err_raw.buf.getvalue()
            combined_bytes = combined.getvalue()
        return Result(self, stdout_bytes, stderr_bytes, combined_bytes,
                      return_value, exit_code, exception, exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir: t.Optional[str] = None) -> t.Iterator[str]:
        """Change into a new empty directory; remove it on exit when no parent is given."""
        cwd = os.getcwd()
        if temp_dir is None:
            path = tempfile.mkdtemp()
            remove = True
        else:
            path = tempfile.mkdtemp(dir=temp_dir)
            remove = False
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if remove:
                shutil.rmtree(path, ignore_errors=True)
