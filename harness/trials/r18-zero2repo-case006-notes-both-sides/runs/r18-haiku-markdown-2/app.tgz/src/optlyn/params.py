"""Parameters: options and arguments (PRD FP-03, FP-04, FP-07, FP-08)."""

from __future__ import annotations

import os
import re
import typing as t

from . import types as _types
from .exceptions import BadParameter, MissingParameter
from .parser import PROMPT

# Value sources, ranked from most to least explicit (FP-03, FP-07).
SRC_PROMPT = "prompt"
SRC_CMDLINE = "commandline"
SRC_ENV = "environment"
SRC_DEFAULT_MAP = "default_map"
SRC_DEFAULT = "default"

MISSING = object()  # no value supplied from any source
_TRUE_ENV = {"true", "1", "yes", "on", "t", "y"}
_FALSE_ENV = {"false", "0", "no", "off", "f", "n"}
_IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


class Parameter:
    """Base class for options and arguments."""

    kind = "parameter"

    def __init__(
        self,
        name: t.Optional[str],
        *,
        type: t.Any = None,
        default: t.Any = None,
        required: bool = False,
        nargs: int = 1,
        multiple: bool = False,
        envvar: t.Any = None,
        callback: t.Optional[t.Callable] = None,
        is_eager: bool = False,
        expose_value: bool = True,
        hidden: bool = False,
        deprecated: t.Any = False,
        help: t.Optional[str] = None,
        metavar: t.Optional[str] = None,
        shell_complete: t.Optional[t.Callable] = None,
    ) -> None:
        self.name = name
        self.default = default
        self.required = required
        self.multiple = multiple
        self.callback = callback
        self.is_eager = is_eager
        self.expose_value = expose_value
        self.hidden = hidden
        self.deprecated = deprecated
        self.help = help
        self.metavar = metavar
        self.shell_complete_func = shell_complete
        if isinstance(envvar, str):
            envvar = [envvar]
        self.envvar = list(envvar) if envvar else None
        if isinstance(type, (tuple, list)):
            self.type: _types.ParamType = _types.Tuple(type)
        else:
            self.type = _types.convert_type(type, default)
        self.nargs = self.type.arity if isinstance(self.type, _types.Tuple) else nargs

    # ------------------------------------------------------------------
    @property
    def deprecated_note(self) -> t.Optional[str]:
        return self.deprecated if isinstance(self.deprecated, str) else None

    @property
    def is_deprecated(self) -> bool:
        return bool(self.deprecated)

    def get_default(self, ctx: t.Any = None) -> t.Any:
        d = self.default
        return d() if callable(d) else d

    def get_metavar(self, ctx: t.Any = None) -> t.Optional[str]:
        if self.metavar is not None:
            return self.metavar
        return self.type.get_metavar(self)

    def label(self) -> str:
        return self.name or ""

    def get_error_hint(self, ctx: t.Any = None) -> str:
        return self.label()

    def is_prompting(self) -> bool:
        return False

    def is_composite(self) -> bool:
        """True when each occurrence carries several values (tuple result)."""
        return self.nargs != 1 or isinstance(self.type, _types.Tuple)

    # ------------------------------------------------------------------
    def env_value(self, ctx: t.Any) -> t.Tuple[bool, t.Optional[str]]:
        names = list(self.envvar or [])
        if (getattr(self, "allow_from_autoenv", True) and ctx is not None
                and getattr(ctx, "auto_envvar_prefix", None)):
            auto = ctx.auto_envvar_name(self.name)
            if auto and auto not in names:
                names.append(auto)
        for name in names:
            raw = os.environ.get(name)
            if raw is None or raw == "":
                continue
            return True, raw
        return False, None

    # conversion -----------------------------------------------------------
    def convert_one(self, value: t.Any, ctx: t.Any) -> t.Any:
        return self.type.convert(value, self, ctx)

    def convert_occurrence(self, value: t.Any, ctx: t.Any) -> t.Any:
        """Convert one occurrence: a scalar, or a tuple of nargs values."""
        if isinstance(self.type, _types.Tuple):
            vals = tuple(value) if isinstance(value, (tuple, list)) else (value,)
            return self.type.convert(vals, self, ctx)
        if self.nargs != 1:
            vals = value if isinstance(value, (tuple, list)) else (value,)
            return tuple(self.type.convert(v, self, ctx) for v in vals)
        return self.type.convert(value, self, ctx)

    def shape(self, occ: t.List[t.Any], ctx: t.Any) -> t.Any:
        if self.multiple:
            return tuple(self.convert_occurrence(o, ctx) for o in occ)
        return self.convert_occurrence(occ[-1], ctx)

    def convert_env(self, raw: str, ctx: t.Any) -> t.Any:
        if self.is_composite() or self.multiple:
            parts = self.type.split_envvar_value(raw)
            if self.multiple:
                return tuple(self.convert_one(p, ctx) for p in parts)
            return self.convert_occurrence(tuple(parts), ctx)
        return self.convert_one(raw, ctx)

    def convert_default_map(self, dm: t.Any, ctx: t.Any) -> t.Any:
        if dm is None:
            return None
        if isinstance(dm, str):
            if self.is_composite():
                return self.convert_env(dm, ctx)
            if self.multiple:
                raise BadParameter(
                    f"{self.label()} needs an iterable (sequence) default.", ctx=ctx, param=self)
            return self.convert_one(dm, ctx)
        if self.multiple:
            if not isinstance(dm, (list, tuple)):
                raise BadParameter(
                    f"{self.label()} needs an iterable (sequence) default.", ctx=ctx, param=self)
            return tuple(self.convert_occurrence(v, ctx) for v in dm)
        if self.is_composite():
            return self.convert_occurrence(dm, ctx)
        return self.convert_one(dm, ctx)

    def convert_declared_default(self, dflt: t.Any, ctx: t.Any) -> t.Any:
        if self.multiple:
            if isinstance(dflt, str) or not isinstance(dflt, (list, tuple)):
                raise BadParameter(
                    f"{self.label()} needs an iterable (sequence) default.", ctx=ctx, param=self)
            return tuple(self.convert_occurrence(v, ctx) for v in dflt)
        if self.is_composite():
            return self.convert_occurrence(dflt, ctx)
        return self.convert_one(dflt, ctx)

    def prompt_value(self, ctx: t.Any) -> t.Any:
        raise MissingParameter(f"Missing {self.kind} {self.label()}.", ctx=ctx, param=self)

    def run_callback(self, ctx: t.Any, value: t.Any) -> t.Any:
        if self.callback is not None:
            return self.callback(ctx, self, value)
        return value

    def shell_complete(self, ctx: t.Any, incomplete: str) -> t.List[t.Any]:
        if self.shell_complete_func is not None:
            return list(self.shell_complete_func(ctx, self, incomplete))
        return self.type.shell_complete(ctx, self, incomplete)

    # resolution -----------------------------------------------------------
    def resolve_value(self, ctx: t.Any, supplied: t.Any) -> t.Tuple[t.Any, t.Optional[str]]:
        """Resolve the final value from all sources.

        `supplied` is MISSING, a list of raw occurrences (options), or a raw
        value/tuple (arguments). Returns (value, source-or-None).
        """
        prompt_marker = False
        if isinstance(supplied, list):
            prompt_marker = any(o is PROMPT for o in supplied)
            occ = [o for o in supplied if o is not PROMPT]
            cmd_given = len(occ) > 0
        else:
            occ = None
            cmd_given = supplied is not MISSING

        value: t.Any = MISSING
        source: t.Optional[str] = None

        if cmd_given:
            source = SRC_CMDLINE
            value = self.shape(occ, ctx) if isinstance(supplied, list) else self._shape_arg(supplied, ctx)
        else:
            if not prompt_marker:
                found, raw = self.env_value(ctx)
                if found:
                    source, value = SRC_ENV, self.convert_env(raw, ctx)
                else:
                    dm_found, dm = ctx.lookup_default(self.name) if ctx is not None else (False, None)
                    if dm_found:
                        source, value = SRC_DEFAULT_MAP, self.convert_default_map(dm, ctx)
            if source is None and (prompt_marker or (self.required and self.is_prompting())):
                value = self.prompt_value(ctx)
                source = SRC_PROMPT
            if source is None and self.default is not None:
                dflt = self.get_default(ctx)
                if dflt is not None:
                    value = self.convert_declared_default(dflt, ctx)
                    source = SRC_DEFAULT
            if source is None and (self.multiple or self.nargs != 1):
                value, source = (), SRC_DEFAULT

        if source is None:
            if self.required:
                raise MissingParameter(f"Missing {self.kind} {self.display_name()}.",
                                       ctx=ctx, param=self)
            return self.run_callback(ctx, None), None

        if self.is_deprecated and source == SRC_CMDLINE:
            _warn_deprecated(self, ctx)
        return self.run_callback(ctx, value), source

    def _shape_arg(self, raw, ctx):
        raise NotImplementedError

    def display_name(self) -> str:
        return self.label()


class Option(Parameter):
    """A named parameter introduced by a prefix."""

    kind = "option"

    def __init__(
        self,
        param_decls: t.Sequence[str] = (),
        *,
        prefixes: t.Sequence[str] = ("-",),
        is_flag: t.Optional[bool] = None,
        flag_value: t.Any = None,
        count: bool = False,
        prompt: t.Any = False,
        prompt_required: bool = True,
        hide_input: bool = False,
        confirmation_prompt: bool = False,
        show_default: t.Any = False,
        show_envvar: bool = False,
        allow_from_autoenv: bool = True,
        **kwargs: t.Any,
    ) -> None:
        opts, secondary, name = _split_decls(param_decls, prefixes)
        if not opts and not secondary:
            raise TypeError("Option needs at least one flag name.")
        if name is None:
            name = _infer_name(opts + secondary)
        if not name:
            raise TypeError("Could not determine a destination name for the option.")
        self.opts = opts
        self.secondary_opts = secondary
        self.prefixes = tuple(prefixes)
        default = kwargs.get("default")
        if is_flag is None:
            is_flag = bool(secondary) or (isinstance(default, bool) and not count
                                          and not kwargs.get("multiple", False))
        if count:
            is_flag = False
        self.is_flag = bool(is_flag)
        self.count = bool(count)
        self.flag_value = flag_value
        self.prompt = prompt
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.allow_from_autoenv = allow_from_autoenv
        self.optional_value = flag_value is not None and not self.is_flag

        if self.is_flag:
            if self.flag_value is None:
                self.flag_value = True
            kwargs.setdefault("type", _types.BOOL)
            if kwargs.get("default") is None:
                kwargs["default"] = False
        if self.count:
            kwargs.setdefault("type", _types.INT)
        if kwargs.get("deprecated") and kwargs.get("required"):
            raise TypeError("A deprecated option cannot be required.")
        if kwargs.get("deprecated") and prompt:
            raise TypeError("A deprecated option cannot use a prompt.")
        if self.is_flag and prompt:
            raise TypeError("A flag cannot prompt.")
        if self.is_flag and kwargs.get("nargs", 1) not in (1, None):
            raise TypeError("A flag takes exactly one value.")

        nargs = kwargs.pop("nargs", 1) or 1
        if nargs < 1:
            raise TypeError("Option nargs must be a positive integer.")
        super().__init__(name, nargs=nargs, **_filter(kwargs))
        self.name = name
        if self.is_flag or self.count:
            self.nargs = 1

    # ------------------------------------------------------------------
    def label(self) -> str:
        return " / ".join(self.opts + self.secondary_opts)

    def display_name(self) -> str:
        return self.label()

    def get_error_hint(self, ctx: t.Any = None) -> str:
        return self.label()

    def is_prompting(self) -> bool:
        return bool(self.prompt)

    def takes_value(self) -> bool:
        return not (self.is_flag or self.count)

    def prompt_text(self) -> str:
        if isinstance(self.prompt, str):
            return self.prompt
        return self.name.replace("_", " ").capitalize()

    def prompt_value(self, ctx: t.Any) -> t.Any:
        from . import utils as _utils

        default = self.get_default(ctx) if self.default is not None else None
        return _utils.prompt(
            self.prompt_text(),
            default=default,
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            type=self.type,
        )

    def convert_env(self, raw: str, ctx: t.Any) -> t.Any:
        if self.is_flag:
            return self._env_flag(raw, ctx)
        return super().convert_env(raw, ctx)

    def _env_flag(self, raw: str, ctx: t.Any) -> t.Any:
        text = raw.strip().lower()
        fv = self.flag_value
        if isinstance(fv, str) and text == fv.lower():
            return fv
        if text in _TRUE_ENV:
            return True if fv is None or fv is True else fv
        if text in _FALSE_ENV or text == "":
            return False
        raise BadParameter(f"{raw!r} is not a valid boolean.", ctx=ctx, param=self)

    def resolve_value(self, ctx: t.Any, supplied: t.Any) -> t.Tuple[t.Any, t.Optional[str]]:
        if not (self.is_flag or self.count):
            return super().resolve_value(ctx, supplied)
        occ = [o for o in supplied if o is not PROMPT] if isinstance(supplied, list) else []
        if self.count:
            if occ:
                value, source = sum(int(v) for v in occ), SRC_CMDLINE
            else:
                value, source = self._count_fallback(ctx)
        else:
            if occ:
                value, source = occ[-1], SRC_CMDLINE
            else:
                value, source = self._flag_fallback(ctx)
        if source is None:
            if self.required:
                raise MissingParameter(f"Missing option {self.label()}.", ctx=ctx, param=self)
            return self.run_callback(ctx, None), None
        if self.is_deprecated and source == SRC_CMDLINE:
            _warn_deprecated(self, ctx)
        return self.run_callback(ctx, value), source

    def _count_fallback(self, ctx):
        dm_found, dm = ctx.lookup_default(self.name) if ctx is not None else (False, None)
        if dm_found:
            return dm, SRC_DEFAULT_MAP
        if self.default is not None:
            return self.get_default(ctx), SRC_DEFAULT
        return None, None

    def _flag_fallback(self, ctx):
        found, raw = self.env_value(ctx)
        if found:
            return self._env_flag(raw, ctx), SRC_ENV
        dm_found, dm = ctx.lookup_default(self.name) if ctx is not None else (False, None)
        if dm_found:
            return (self._env_flag(dm, ctx) if isinstance(dm, str) else dm), SRC_DEFAULT_MAP
        if self.default is not None:
            return self.get_default(ctx), SRC_DEFAULT
        return False, SRC_DEFAULT


def _warn_deprecated(param: Parameter, ctx: t.Any) -> None:
    from . import utils as _utils

    note = param.deprecated_note
    if note:
        _utils.echo(f"DeprecationWarning: {note}", err=True)
    else:
        _utils.echo(f"DeprecationWarning: The {param.kind} '{param.label()}' is deprecated.", err=True)


def _filter(kwargs: dict) -> dict:
    allowed = {
        "type", "default", "required", "nargs", "multiple", "envvar", "callback",
        "is_eager", "expose_value", "hidden", "deprecated", "help", "metavar",
        "shell_complete",
    }
    return {k: v for k, v in kwargs.items() if k in allowed}


def _split_decls(decls: t.Sequence[str], prefixes: t.Sequence[str]):
    """Split declarations into (flag names, off-flag names, destination)."""
    opts: t.List[str] = []
    secondary: t.List[str] = []
    name: t.Optional[str] = None
    pre = set(prefixes)
    for decl in decls:
        if not decl:
            continue
        if decl[0] in pre:
            # "<on>/<off>" pair; a leading "/" is a prefix, not a separator
            if "/" in decl[1:] and decl[1:].index("/") + 1 < len(decl) - 1:
                idx = decl.index("/", 1)
                on, off = decl[:idx], decl[idx + 1:]
                if on and off:
                    opts.append(on)
                    secondary.append(off)
                    continue
            opts.append(decl)
        else:
            if name is not None:
                raise TypeError("Only one destination name is allowed.")
            name = decl
    return opts, secondary, name


def _infer_name(names: t.List[str]) -> t.Optional[str]:
    """Destination from flag names: first long name, else first short name."""
    for n in names:
        if n.startswith("--") and len(n) > 2:
            cand = n[2:].replace("-", "_")
            if _IDENT.match(cand):
                return cand
    for n in names:
        cand = n.lstrip("-+/").replace("-", "_")
        if cand:
            return cand
    return None


class Argument(Parameter):
    """A positional parameter."""

    kind = "argument"

    def __init__(self, param_decls: t.Sequence[str] = (), *, required: t.Optional[bool] = None,
                 nargs: int = 1, default: t.Any = None, **kwargs: t.Any) -> None:
        names = [d for d in param_decls if d]
        if len(names) != 1:
            raise TypeError("An argument needs exactly one destination name.")
        name = names[0]
        if nargs == 0 or nargs < -1:
            raise TypeError("nargs must be a positive integer or -1.")
        deprecated = kwargs.get("deprecated", False)
        if required is None:
            required = default is None and nargs != -1
        if deprecated and required:
            raise TypeError("A deprecated argument cannot be required.")
        if deprecated and default is None and required is not False:
            raise TypeError("A deprecated argument needs a default or must be optional.")
        self.variadic = nargs == -1
        self.opts: t.List[str] = []
        self.secondary_opts: t.List[str] = []
        self.prefixes = ("-",)
        self.is_flag = False
        self.count = False
        self.flag_value = None
        self.prompt = False
        self.optional_value = False
        super().__init__(name, default=default, required=bool(required),
                         nargs=nargs, **_filter(kwargs))
        self.name = name
        if self.variadic:
            self.multiple = True
            self.nargs = -1
        self.allow_from_autoenv = False

    def label(self) -> str:
        return self.name

    def display_name(self) -> str:
        return self.name

    def get_error_hint(self, ctx: t.Any = None) -> str:
        return self.name

    def get_metavar(self, ctx: t.Any = None) -> str:
        if self.metavar is not None:
            return self.metavar
        return self.name.upper()

    def env_value(self, ctx: t.Any) -> t.Tuple[bool, t.Optional[str]]:
        # arguments never use the automatic prefix (FP-07)
        for name in self.envvar or []:
            raw = os.environ.get(name)
            if raw:
                return True, raw
        return False, None

    def _shape_arg(self, raw: t.Any, ctx: t.Any) -> t.Any:
        if self.variadic:
            vals = raw if isinstance(raw, tuple) else (raw,)
            return tuple(self.type.convert(v, self, ctx) for v in vals)
        if self.nargs != 1 or isinstance(self.type, _types.Tuple):
            return self.convert_occurrence(raw, ctx)
        return self.convert_one(raw, ctx)

    def convert_declared_default(self, dflt: t.Any, ctx: t.Any) -> t.Any:
        if self.variadic or self.nargs != 1:
            if isinstance(dflt, str):
                raise BadParameter(f"{self.label()} needs an iterable default.", ctx=ctx, param=self)
            return tuple(self.convert_one(v, ctx) for v in dflt)
        return self.convert_one(dflt, ctx)

    def convert_env(self, raw: str, ctx: t.Any) -> t.Any:
        if self.variadic or self.nargs != 1:
            return tuple(self.convert_one(p, ctx) for p in self.type.split_envvar_value(raw))
        return self.convert_one(raw, ctx)

    def resolve_value(self, ctx: t.Any, supplied: t.Any) -> t.Tuple[t.Any, t.Optional[str]]:
        if self.variadic and supplied is not MISSING and supplied == ():
            supplied = MISSING
        if supplied is MISSING and self.variadic and not self.required:
            return self.run_callback(ctx, ()), SRC_DEFAULT
        return super().resolve_value(ctx, supplied)
