"""Invocation context (PRD FP-07; Interface section 6)."""

from __future__ import annotations

import contextlib
import threading
import typing as t

from .exceptions import Abort, Exit

_local = threading.local()

# Keys accepted in context settings (Interface section 6).
CONTEXT_SETTING_KEYS = {
    "auto_envvar_prefix", "default_map", "terminal_width", "max_content_width",
    "help_option_names", "token_normalize_func", "color", "show_default",
    "allow_extra_args", "ignore_unknown_options", "allow_interspersed_args",
}


def _stack() -> t.List["Context"]:
    st = getattr(_local, "stack", None)
    if st is None:
        st = []
        _local.stack = st
    return st


class Context:
    """Per-invocation state, linked to its parent context."""

    def __init__(
        self,
        command: t.Any,
        parent: t.Optional["Context"] = None,
        info_name: t.Optional[str] = None,
        obj: t.Any = None,
        auto_envvar_prefix: t.Optional[str] = None,
        default_map: t.Optional[dict] = None,
        terminal_width: t.Optional[int] = None,
        max_content_width: t.Optional[int] = None,
        help_option_names: t.Optional[t.Sequence[str]] = None,
        token_normalize_func: t.Optional[t.Callable[[str], str]] = None,
        color: t.Optional[bool] = None,
        show_default: t.Optional[bool] = None,
        allow_extra_args: t.Optional[bool] = None,
        ignore_unknown_options: t.Optional[bool] = None,
        allow_interspersed_args: t.Optional[bool] = None,
        **extra: t.Any,
    ) -> None:
        self.command = command
        self.parent = parent
        self.info_name = info_name
        self.obj = obj if obj is not None else (parent.obj if parent is not None else None)
        self.params: t.Dict[str, t.Any] = {}
        self._sources: t.Dict[str, str] = {}
        self.extra = extra
        self.default_map = default_map

        def inherit(value, attr, fallback):
            if value is not None:
                return value
            if parent is not None:
                return getattr(parent, attr)
            return fallback

        self.auto_envvar_prefix = inherit(auto_envvar_prefix, "auto_envvar_prefix", None)
        self.terminal_width = inherit(terminal_width, "terminal_width", None)
        self.max_content_width = inherit(max_content_width, "max_content_width", None)
        self.help_option_names = list(inherit(help_option_names, "help_option_names", ["--help"]))
        self.token_normalize_func = inherit(token_normalize_func, "token_normalize_func", None)
        self.color = inherit(color, "color", None)
        self.show_default = inherit(show_default, "show_default", None)
        self.allow_extra_args = inherit(allow_extra_args, "allow_extra_args", False)
        self.ignore_unknown_options = inherit(ignore_unknown_options, "ignore_unknown_options", False)
        self.allow_interspersed_args = inherit(allow_interspersed_args, "allow_interspersed_args", True)

        if parent is not None:
            self._path_parts = list(parent._path_parts) + ([info_name] if info_name else [])
        else:
            self._path_parts = []
        self.invoked_subcommand: t.Any = None
        self._exit_stack = contextlib.ExitStack()
        self._closed = False
        self._entered = 0

    # --- defaults and env --------------------------------------------------
    def lookup_default(self, name: t.Optional[str]) -> t.Tuple[bool, t.Any]:
        """Return (found, value) from this context's default map."""
        if name is None or not isinstance(self.default_map, dict):
            return False, None
        if name in self.default_map:
            return True, self.default_map[name]
        return False, None

    def auto_envvar_name(self, dest: str) -> t.Optional[str]:
        if not self.auto_envvar_prefix or not dest:
            return None
        parts = [self.auto_envvar_prefix] + list(self._path_parts) + [dest]
        return "_".join(p.upper().replace("-", "_") for p in parts if p)

    # --- sources -----------------------------------------------------------
    def set_source(self, name: str, source: str) -> None:
        self._sources[name] = source

    def get_parameter_source(self, name: str) -> t.Optional[str]:
        declared = {p.name for p in getattr(self.command, "params", [])}
        if name not in declared:
            return None
        return self._sources.get(name)

    # --- resources and control --------------------------------------------
    def with_resource(self, cm: t.ContextManager) -> t.Any:
        return self._exit_stack.enter_context(cm)

    def call_on_close(self, f: t.Callable[[], t.Any]) -> None:
        self._exit_stack.callback(f)

    def close(self) -> None:
        if not self._closed:
            self._closed = True
            self._exit_stack.close()

    def exit(self, code: int = 0) -> t.NoReturn:
        raise Exit(code)

    def abort(self) -> t.NoReturn:
        raise Abort()

    def get_usage(self) -> str:
        return self.command.get_usage(self)

    def get_help(self) -> str:
        return self.command.get_help(self)

    def invoke(self, other: t.Any, **kwargs: t.Any) -> t.Any:
        """Run another command with exactly the given values."""
        return _run_child(self, other, kwargs, forward=False)

    def forward(self, other: t.Any, **kwargs: t.Any) -> t.Any:
        """Run another command, filling in this command's current params."""
        merged = dict(self.params)
        merged.update(kwargs)
        return _run_child(self, other, merged, forward=True)

    # --- current-context protocol ------------------------------------------
    def __enter__(self) -> "Context":
        _stack().append(self)
        self._entered += 1
        return self

    def _push(self) -> None:
        """Make this context current without closing it (internal use)."""
        _stack().append(self)

    def _pop(self) -> None:
        st = _stack()
        for i in range(len(st) - 1, -1, -1):
            if st[i] is self:
                del st[i]
                break

    def __exit__(self, exc_type, exc, tb) -> None:
        self._entered -= 1
        st = _stack()
        if st and st[-1] is self:
            st.pop()
        else:
            # remove the most recent entry for this context
            for i in range(len(st) - 1, -1, -1):
                if st[i] is self:
                    del st[i]
                    break
        if self._entered == 0:
            self.close()


def _run_child(ctx: Context, other: t.Any, values: dict, forward: bool) -> t.Any:
    from .core import Command

    if not isinstance(other, Command):
        raise TypeError("invoke/forward expects a Command")
    sub = Context(other, parent=ctx, info_name=other.name, obj=ctx.obj)
    with sub:
        # values are keyword arguments to the callback
        for p in other.params:
            if p.name in values:
                sub.params[p.name] = values[p.name]
        return other.invoke_with_values(sub, values)


def get_current_context(silent: bool = False) -> t.Optional[Context]:
    st = _stack()
    if st:
        return st[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")


def _make_pass(kind: str):
    def decorator(f):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if kind == "context":
                return f(ctx, *args, **kwargs)
            return f(ctx.obj, *args, **kwargs)

        new_func.__name__ = getattr(f, "__name__", "pass")
        new_func.__doc__ = getattr(f, "__doc__", None)
        new_func.__optlyn_pass__ = kind
        return new_func

    return decorator


def pass_context(f):
    """Pass the current Context as the first argument."""
    return _make_pass("context")(f)


def pass_obj(f):
    """Pass the current context's obj as the first argument."""
    return _make_pass("obj")(f)


def make_pass_decorator(object_type: type, ensure: bool = False):
    """Decorator that passes the nearest object of object_type."""

    def decorator(f):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            node = ctx
            obj = None
            while node is not None:
                if isinstance(node.obj, object_type):
                    obj = node.obj
                    break
                node = node.parent
            if obj is None:
                if ensure:
                    obj = object_type()
                    ctx.obj = obj
                else:
                    raise RuntimeError(
                        f"Managed to invoke callback without a context object of type "
                        f"{object_type.__name__!r} existing."
                    )
            return f(obj, *args, **kwargs)

        new_func.__name__ = getattr(f, "__name__", "pass")
        new_func.__doc__ = getattr(f, "__doc__", None)
        return new_func

    return decorator
