# Optlyn

Optlyn is a pure-Python library for building command line interfaces: nested
commands and groups, automatic help, typed options and arguments, prompts,
terminal helpers, shell completion, and an in-process test runner.

Import it from `src/optlyn`:

```python
from optlyn import command, group, option, argument, echo

@command()
@option("--count", type=int, default=1)
@argument("name")
def greet(count, name):
    """Say hello."""
    for _ in range(count):
        echo(f"hello {name}")

if __name__ == "__main__":
    greet()
```

See `NOTES.md` for how spec conflicts were resolved.
