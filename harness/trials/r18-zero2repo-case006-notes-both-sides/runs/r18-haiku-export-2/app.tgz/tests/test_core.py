"""Behaviour tests for commands, groups, options and arguments (FP-01..FP-06)."""

import optlyn
from optlyn import (
    BadParameter,
    Choice,
    CommandCollection,
    Abort,
    IntRange,
    FloatRange,
    ParamType,
    argument,
    command,
    echo,
    group,
    option,
    pass_context,
    pass_obj,
)
from optlyn.testing import CliRunner

runner = CliRunner()


def test_derived_command_name_strips_suffix():
    @command()
    def hello_world_cmd():
        pass

    assert hello_world_cmd.name == "hello-world"


def test_explicit_name_replaces_derived_name():
    @command("greet")
    def hello():
        pass

    assert hello.name == "greet"


def test_leaf_command_runs_once_and_returns_zero():
    calls = []

    @command()
    @option("--count", type=int, default=1)
    @argument("name")
    def hi(count, name):
        calls.append((count, name))
        echo(f"hi {name}")

    r = runner.invoke(hi, ["--count", "2", "bob"])
    assert r.exit_code == 0
    assert calls == [(2, "bob")]
    assert r.output == "hi bob\n"


def test_options_after_argument_on_leaf():
    @command()
    @option("--flag", is_flag=True)
    @argument("x")
    def leaf(flag, x):
        echo(f"{flag} {x}")

    assert runner.invoke(leaf, ["a", "--flag"]).output == "True a\n"


def test_unknown_option_is_usage_error_and_callback_not_run():
    ran = []

    @command()
    def leaf():
        ran.append(1)

    r = runner.invoke(leaf, ["--nope"])
    assert r.exit_code == 2
    assert ran == []
    assert "No such option" in r.output


def test_missing_required_option_is_usage_error():
    @command()
    @option("--name", required=True)
    def leaf(name):
        echo(name)

    r = runner.invoke(leaf, [])
    assert r.exit_code == 2
    assert "--name" in r.output


def test_short_flag_stacking_and_attached_value():
    @command()
    @option("-a", is_flag=True)
    @option("-b", is_flag=True)
    @option("-n", type=int)
    def leaf(a, b, n):
        echo(f"{a} {b} {n}")

    assert runner.invoke(leaf, ["-abn7"]).output == "True True 7\n"


def test_pair_flag_on_and_off():
    @command()
    @option("--shout/--no-shout", default=False)
    def leaf(shout):
        echo(str(shout))

    assert runner.invoke(leaf, ["--shout"]).output == "True\n"
    assert runner.invoke(leaf, ["--no-shout"]).output == "False\n"
    assert runner.invoke(leaf, []).output == "False\n"


def test_counting_option_zero_when_omitted():
    @command()
    @option("-v", count=True)
    def leaf(v):
        echo(str(v))

    assert runner.invoke(leaf, []).output == "0\n"
    assert runner.invoke(leaf, ["-vvv"]).output == "3\n"


def test_repeatable_option_gets_tuple_and_empty_when_omitted():
    @command()
    @option("--item", multiple=True)
    def leaf(item):
        echo(repr(item))

    assert runner.invoke(leaf, []).output == "()\n"
    assert runner.invoke(leaf, ["--item", "a", "--item", "b"]).output == "('a', 'b')\n"


def test_bare_string_default_on_repeatable_is_usage_error():
    @command()
    @option("--item", multiple=True, default="x")
    def leaf(item):
        echo(repr(item))

    r = runner.invoke(leaf, [])
    assert r.exit_code == 2
    assert "iterable" in r.output


def test_double_dash_ends_options():
    @command()
    @argument("rest", nargs=-1)
    def leaf(rest):
        echo(repr(rest))

    assert runner.invoke(leaf, ["--", "--x", "y"]).output == "('--x', 'y')\n"


def test_no_args_is_help_for_group_is_usage_failure():
    @group()
    def cli():
        pass

    @cli.command()
    def sub():
        pass

    r = runner.invoke(cli, [])
    assert r.exit_code == 2
    assert "Usage:" in r.stderr


def test_help_is_success_and_skips_callback():
    ran = []

    @command()
    def leaf():
        """Does a thing.

        Details here."""
        ran.append(1)

    r = runner.invoke(leaf, ["--help"])
    assert r.exit_code == 0
    assert "Does a thing." in r.stdout
    assert ran == []


def test_group_callback_runs_before_child_and_nested_groups_nest():
    order = []

    @group()
    def outer():
        order.append("outer")

    @outer.group()
    def mid():
        order.append("mid")

    @mid.command()
    def leaf():
        order.append("leaf")

    r = runner.invoke(outer, ["mid", "leaf"])
    assert r.exit_code == 0
    assert order == ["outer", "mid", "leaf"]


def test_unknown_subcommand_does_not_run_group_callback():
    ran = []

    @group()
    def cli():
        ran.append(1)

    r = runner.invoke(cli, ["nope"])
    assert r.exit_code == 2
    assert ran == []


def test_group_options_must_precede_subcommand_name():
    @group()
    @option("--verbose", is_flag=True)
    @pass_context
    def cli(ctx, verbose):
        ctx.obj = verbose

    @cli.command()
    @option("--x", default="d")
    def sub(x):
        echo(x)

    assert runner.invoke(cli, ["--verbose", "sub", "--x", "y"]).output == "y\n"


def test_context_obj_inherited_by_children():
    @group()
    @pass_context
    def cli(ctx):
        ctx.obj = {"k": 1}

    @cli.command()
    @pass_obj
    def sub(obj):
        echo(str(obj["k"]))

    assert runner.invoke(cli, ["sub"]).output == "1\n"


def test_invoke_without_command_runs_callback():
    @group(invoke_without_command=True)
    @pass_context
    def cli(ctx):
        echo(f"sub={ctx.invoked_subcommand}")

    @cli.command()
    def go():
        echo("go")

    assert runner.invoke(cli, []).output == "sub=None\n"
    assert runner.invoke(cli, ["go"]).output == "sub=go\ngo\n"


def test_chain_group_runs_children_and_result_callback():
    @group(chain=True)
    def pipe():
        pass

    @pipe.result_callback()
    def done(results):
        echo(f"results={results}")

    @pipe.command()
    @argument("v", type=int)
    def dbl(v):
        return v * 2

    @pipe.command()
    @argument("v", type=int)
    def inc(v):
        return v + 1

    r = runner.invoke(pipe, ["dbl", "3", "inc", "4"])
    assert r.exit_code == 0
    assert r.output == "results=[6, 5]\n"


def test_chain_group_cannot_nest_groups():
    import pytest

    @group(chain=True)
    def pipe():
        pass

    @group()
    def inner():
        pass

    with pytest.raises(TypeError):
        pipe.add_command(inner)


def test_command_collection_union():
    @group()
    def a():
        pass

    @a.command()
    def one():
        echo("one")

    @group()
    def b():
        pass

    @b.command()
    def two():
        echo("two")

    coll = CommandCollection(name="all", sources=[a, b])
    assert coll.list_commands(None) == ["one", "two"]
    assert runner.invoke(coll, ["two"]).output == "two\n"


def test_hidden_command_dispatchable_but_not_listed():
    @group()
    def cli():
        pass

    @cli.command(hidden=True)
    def secret():
        echo("s")

    assert runner.invoke(cli, ["secret"]).output == "s\n"
    assert "secret" not in runner.invoke(cli, ["--help"]).output


def test_deprecated_command_still_runs_with_warning():
    @command(deprecated=True)
    def old():
        echo("ran")

    r = runner.invoke(old, [])
    assert r.exit_code == 0
    assert "DeprecationWarning" in r.stderr
    assert "ran" in r.stdout


def test_choice_delivers_original_object_and_refuses_unknown():
    @command()
    @option("--mode", type=Choice(["alpha", "beta"]))
    def leaf(mode):
        echo(mode)

    assert runner.invoke(leaf, ["--mode", "beta"]).output == "beta\n"
    assert runner.invoke(leaf, ["--mode", "gamma"]).exit_code == 2


def test_int_range_clamp_and_refusal():
    @command()
    @option("--r", type=IntRange(0, 10, clamp=True))
    @option("--f", type=FloatRange(0.0, 1.0))
    def leaf(r, f):
        echo(f"{r} {f}")

    assert runner.invoke(leaf, ["--r", "99", "--f", "0.5"]).output == "10 0.5\n"
    assert runner.invoke(leaf, ["--f", "2"]).exit_code == 2


def test_float_range_clamp_with_open_bound_refused_at_declaration():
    import pytest

    with pytest.raises(ValueError):
        FloatRange(0.0, 1.0, min_open=True, clamp=True)


def test_custom_param_type_and_callback_refusal():
    class Upper(ParamType):
        name = "upper"

        def convert(self, value, param=None, ctx=None):
            if isinstance(value, str) and value.isupper():
                return value
            self.fail(f"{value!r} is not upper", param, ctx)

    @command()
    @argument("w", type=Upper())
    def leaf(w):
        echo(w)

    assert runner.invoke(leaf, ["ABC"]).output == "ABC\n"
    assert runner.invoke(leaf, ["abc"]).exit_code == 2


def test_callback_refusal_is_usage_error():
    def check(ctx, param, value):
        if value < 0:
            raise BadParameter("must be >= 0", ctx=ctx, param=param)
        return value

    @command()
    @option("--n", type=int, callback=check)
    def leaf(n):
        echo(n)

    r = runner.invoke(leaf, ["--n", "-1"])
    assert r.exit_code == 2
    assert "must be >= 0" in r.output


def test_abort_exit_status_one():
    @command()
    def leaf():
        raise Abort()

    r = runner.invoke(leaf, [])
    assert r.exit_code == 1
    assert "Aborted!" in r.stderr


def test_author_exit_status():
    @command()
    @pass_context
    def leaf(ctx):
        echo("before")
        ctx.exit(3)
        echo("after")

    r = runner.invoke(leaf, [])
    assert r.exit_code == 3
    assert r.output == "before\n"


def test_default_map_nests_by_subcommand():
    @group()
    def cli():
        pass

    @cli.command()
    @option("--k", default="x")
    def sub(k):
        echo(k)

    r = runner.invoke(cli, ["sub"], default_map={"sub": {"k": "fromdm"}})
    assert r.output == "fromdm\n"


def test_env_var_first_set_wins_and_empty_is_unset():
    @command()
    @option("--v", envvar=["NOPE_A", "NOPE_B"])
    def leaf(v):
        echo(v)

    assert runner.invoke(leaf, [], env={"NOPE_A": "", "NOPE_B": "b"}).output == "b\n"


def test_auto_envvar_prefix_with_subcommand_path():
    @group()
    def cli():
        pass

    @cli.command()
    @option("--port", type=int, default=80)
    def serve(port):
        echo(str(port))

    r = runner.invoke(cli, ["serve"], env={"APP_SERVE_PORT": "8080"}, auto_envvar_prefix="APP")
    assert r.output == "8080\n"


def test_parameter_source_reporting():
    @command()
    @option("--port", type=int, default=80)
    @option("--host", default="h")
    @pass_context
    def leaf(ctx, port, host):
        echo(f"{ctx.get_parameter_source('port')} {ctx.get_parameter_source('host')} {ctx.get_parameter_source('nope')}")

    r = runner.invoke(leaf, ["--port", "1"])
    assert r.output == "ParameterSource.COMMANDLINE ParameterSource.DEFAULT None\n"


def test_variadic_and_fixed_arguments():
    @command()
    @argument("first")
    @argument("rest", nargs=-1)
    def leaf(first, rest):
        echo(repr((first, rest)))

    assert runner.invoke(leaf, ["a", "b", "c"]).output == "('a', ('b', 'c'))\n"


def test_extra_arguments_are_usage_error_unless_allowed():
    @command()
    def leaf():
        pass

    assert runner.invoke(leaf, ["x"]).exit_code == 2


def test_version_option_prints_identity_and_exits():
    @command()
    @optlyn.version_option("1.2.3", prog_name="tool")
    def leaf():
        echo("ran")

    r = runner.invoke(leaf, ["--version"])
    assert r.exit_code == 0
    assert r.output == "tool, version 1.2.3\n"


def test_custom_version_option_exact_string():
    @command()
    @optlyn.custom_version_option(lambda ctx: "CUSTOM 9")
    def leaf():
        pass

    assert runner.invoke(leaf, ["--version"]).output == "CUSTOM 9\n"


def test_confirmation_option_flow():
    @command()
    @optlyn.confirmation_option(prompt="Sure?")
    def go():
        echo("done")

    assert runner.invoke(go, [], input="n\n").exit_code == 1
    assert runner.invoke(go, [], input="y\n").output.endswith("done\n")
    assert runner.invoke(go, ["--yes"]).output == "done\n"


def test_password_option_confirms_and_mismatch_aborts():
    @command()
    @optlyn.password_option()
    def leaf(password):
        echo(f"pw={password}")

    assert "pw=abc" in runner.invoke(leaf, ["--password"], input="abc\nabc\n").output
    assert runner.invoke(leaf, ["--password"], input="abc\nxyz\n").exit_code == 1


def test_prompt_on_bare_flag_and_required_prompt():
    @command()
    @option("--name", prompt=True)
    def leaf(name):
        echo(name)

    assert runner.invoke(leaf, ["--name"], input="zed\n").output == "Name: zed\nzed\n"

    @command()
    @option("--name", prompt=True, required=True)
    def req(name):
        echo(name)

    assert runner.invoke(req, [], input="zed\n").output == "Name: zed\nzed\n"


def test_eof_on_prompt_is_abort():
    @command()
    @option("--name", prompt=True, required=True)
    def req(name):
        echo(name)

    r = runner.invoke(req, [], input="")
    assert r.exit_code == 1


def test_feature_switch_group_last_declared_default():
    @command()
    @option("--fast", "mode", flag_value="fast", default=False)
    @option("--slow", "mode", flag_value="slow")
    def leaf(mode):
        echo(str(mode))

    assert runner.invoke(leaf, ["--fast"]).output == "fast\n"
