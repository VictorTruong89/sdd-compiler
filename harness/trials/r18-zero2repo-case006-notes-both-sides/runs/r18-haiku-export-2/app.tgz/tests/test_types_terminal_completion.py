"""Tests for parameter types, files, terminal helpers, completion and the runner."""

import datetime as dt
import os

import pytest

from optlyn import (
    BOOL,
    FLOAT,
    INT,
    STRING,
    UUID,
    Choice,
    DateTime,
    File,
    Path,
    Tuple,
    argument,
    command,
    echo,
    group,
    option,
)
from optlyn.formatting import wrap_text
from optlyn.termui import format_filename, get_app_dir, style, unstyle
from optlyn.shell_completion import get_completions
from optlyn.testing import CliRunner

runner = CliRunner()


def test_builtin_conversions():
    assert INT.convert("42") == 42
    with pytest.raises(Exception):
        INT.convert("1.5")
    assert FLOAT.convert("1.5") == 1.5
    assert BOOL.convert("Yes") is True
    assert BOOL.convert("off") is False
    assert str(UUID.convert("12345678123456781234567812345678")) == "12345678-1234-5678-1234-567812345678"
    assert isinstance(STRING.convert("007"), str)


def test_datetime_default_and_custom_formats_replace():
    assert DateTime().convert("2024-01-02") == dt.datetime(2024, 1, 2)
    assert DateTime().convert("2024-01-02T03:04:05") == dt.datetime(2024, 1, 2, 3, 4, 5)
    with pytest.raises(Exception):
        DateTime(["%d.%m.%Y"]).convert("2024-01-02")


def test_tuple_type_arity():
    t = Tuple([str, int])
    assert t.convert(("a", "3")) == ("a", 3)
    with pytest.raises(Exception):
        t.convert(("a",))


def test_file_write_and_read_roundtrip(tmp_path):
    @command()
    @argument("f", type=File("w", encoding="utf-8"))
    def wr(f):
        f.write("héllo\n")

    @command()
    @argument("f", type=File("r", encoding="utf-8"))
    def rd(f):
        echo(f.read().strip())

    target = tmp_path / "out.txt"
    assert runner.invoke(wr, [str(target)]).exit_code == 0
    assert target.read_text(encoding="utf-8") == "héllo\n"
    assert runner.invoke(rd, [str(target)]).output == "héllo\n"


def test_missing_read_file_is_usage_error(tmp_path):
    @command()
    @argument("f", type=File("r"))
    def rd(f):
        pass

    r = runner.invoke(rd, [str(tmp_path / "missing.txt")])
    assert r.exit_code == 2
    assert "missing.txt" in r.output


def test_lazy_write_never_used_does_not_create_file(tmp_path):
    @command()
    @argument("f", type=File("w"))
    def nw(f):
        pass

    target = tmp_path / "never.txt"
    assert runner.invoke(nw, [str(target)]).exit_code == 0
    assert not target.exists()


def test_dash_is_stdin_for_read_and_stdout_survives(tmp_path):
    @command()
    @argument("f", type=File("r"))
    def rd(f):
        echo(f.read().strip())

    assert runner.invoke(rd, ["-"], input="from stdin\n").output == "from stdin\n"


def test_path_checks(tmp_path):
    @command()
    @argument("p", type=Path(exists=True, dir_okay=False))
    def pth(p):
        echo(p)

    f = tmp_path / "a.txt"
    f.write_text("x")
    assert runner.invoke(pth, [str(f)]).output == f"{f}\n"
    assert runner.invoke(pth, [str(tmp_path)]).exit_code == 2
    assert runner.invoke(pth, [str(tmp_path / "nope")]).exit_code == 2


def test_style_and_unstyle():
    s = style("hi", fg="red", bold=True)
    assert s.startswith("\x1b[")
    assert unstyle(s) == "hi"
    with pytest.raises(ValueError):
        style("x", fg="notacolor")
    with pytest.raises(ValueError):
        style("x", fg=300)


def test_echo_strips_styles_when_not_terminal_and_keeps_when_forced():
    @command()
    def plain():
        echo(style("x", fg="green"))

    assert runner.invoke(plain, []).output == "x\n"
    assert "\x1b[" in runner.invoke(plain, [], color=True).output


def test_wrap_text_and_backspace_paragraph():
    out = wrap_text("alpha beta gamma delta epsilon", width=12)
    assert all(len(line) <= 12 for line in out.splitlines())
    kept = wrap_text("\b\nline one\nline two")
    assert kept == "line one\nline two"


def test_format_filename_and_app_dir(monkeypatch, tmp_path):
    assert format_filename("/tmp/x.txt", shorten=True) == "x.txt"
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    assert get_app_dir("My App") == os.path.join(str(tmp_path), "my-app")


def test_choice_completion_and_hidden_names():
    @group()
    def cli():
        pass

    @cli.command()
    @option("--color", type=Choice(["red", "green"]))
    @option("--secret", hidden=True)
    def build(color, secret):
        pass

    @cli.command(hidden=True)
    def hid():
        pass

    assert [i.value for i in get_completions(cli, ["cli", ""], 1)] == ["build"]
    assert [i.value for i in get_completions(cli, ["cli", "build", "--col"], 2)] == ["--color"]
    assert [i.value for i in get_completions(cli, ["cli", "build", "--color", "g"], 3)] == ["green"]
    names = [i.value for i in get_completions(cli, ["cli", "build", "--"], 2)]
    assert "--secret" not in names


def test_completion_source_script_and_unknown_instruction():
    @group()
    def cli():
        pass

    r = runner.invoke(cli, [], env={"_CLI_COMPLETE": "bash_source"})
    assert r.exit_code == 0
    assert "complete" in r.output
    r = runner.invoke(cli, [], env={"_CLI_COMPLETE": "bogus"})
    assert r.exit_code == 1
    assert r.output == ""


def test_completion_only_for_matching_program_name():
    @command()
    def other():
        echo("ran")

    r = runner.invoke(other, [], env={"_NOT_OTHER_COMPLETE": "bash_source"})
    assert r.output == "ran\n"


def test_runner_isolated_filesystem_leaves_directory(tmp_path):
    with runner.isolated_filesystem(temp_dir=str(tmp_path)) as d:
        assert os.path.isdir(d)
        open("x.txt", "w").close()
    assert os.path.isdir(d)
    assert os.path.exists(os.path.join(d, "x.txt"))


def test_runner_fd_capture_records_os_level_writes():
    @command()
    def fd():
        os.write(1, b"raw-out\n")
        os.write(2, b"raw-err\n")

    r = CliRunner(capture="fd").invoke(fd, [])
    assert r.stdout == "raw-out\n"
    assert r.stderr == "raw-err\n"


def test_runner_default_capture_has_no_real_fileno():
    import sys

    @command()
    def probe():
        try:
            sys.stdout.fileno()
            echo("has-fileno")
        except Exception:
            echo("no-fileno")

    assert runner.invoke(probe, []).output == "no-fileno\n"


def test_runner_env_none_unsets_variable():
    @command()
    def envcheck():
        echo(str(os.environ.get("SOME_VAR_FOR_TEST")))

    os.environ["SOME_VAR_FOR_TEST"] = "set"
    try:
        assert runner.invoke(envcheck, [], env={"SOME_VAR_FOR_TEST": None}).output == "None\n"
    finally:
        os.environ.pop("SOME_VAR_FOR_TEST", None)


def test_runner_exception_is_inspectable():
    @command()
    def boom():
        raise RuntimeError("kaput")

    r = runner.invoke(boom, [])
    assert r.exit_code == 1
    assert isinstance(r.exception, RuntimeError)
    with pytest.raises(RuntimeError):
        CliRunner(catch_exceptions=False).invoke(boom, [])
