"""Thread-local storage of the current invocation context (PRD: Threading)."""

import threading

_local = threading.local()


def _stack():
    stack = getattr(_local, "stack", None)
    if stack is None:
        stack = _local.stack = []
    return stack


def push_context(ctx):
    _stack().append(ctx)


def pop_context(ctx):
    stack = _stack()
    for i in range(len(stack) - 1, -1, -1):
        if stack[i] is ctx:
            del stack[i]
            return


def get_current_context(silent=False):
    """Return the context current on this thread.

    Raises ``RuntimeError`` when there is none and ``silent`` is false; returns
    ``None`` when there is none and ``silent`` is true.
    """
    stack = _stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")
