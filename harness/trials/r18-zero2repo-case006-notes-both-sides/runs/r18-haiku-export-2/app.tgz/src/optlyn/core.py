"""Core of Optlyn: contexts, parameters, the argument parser, commands and groups.

Spec anchors are given as ``# spec: N-xxxxxx`` comments beside the code that
satisfies them (ids from ``spec/CHECKLIST.md``).
"""

import functools
import importlib.metadata as _md
import inspect
import os
import sys
from enum import Enum

from . import _state
from .exceptions import (
    Abort,
    BadArgumentUsage,
    BadOptionUsage,
    BadParameter,
    Exit,
    MissingParameter,
    NoArgsIsHelp,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .formatting import clean_help_text, make_default_short_help, wrap_text
from .termui import echo, get_terminal_width
from .param_types import (
    BOOL,
    INT,
    STRING,
    Tuple,
    infer_type_from_default,
    to_param_type,
)

_state_get = _state.get_current_context
get_current_context = _state_get

# spec: N-000850..N-000880 (command/group declaration); N-000881..N-000935 (parameters)

INF = float("inf")
_PREFIX_CHARS = frozenset("-/+")
_MISSING = object()
CHAIN_MARKER = type("ChainMarker", (), {"__repr__": lambda self: "<chain>"})()


class ParameterSource(Enum):
    """Where a parameter's value came from (FP-07 get_parameter_source)."""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


class CompletionItem:
    """A shell-completion suggestion (Interface Contract §8)."""

    def __init__(self, value, help=None, type="plain"):
        self.value = str(value)
        self.help = help
        self.type = type

    def __repr__(self):
        return f"CompletionItem({self.value!r}, help={self.help!r}, type={self.type!r})"


# ---------------------------------------------------------------------------
# Context
# ---------------------------------------------------------------------------

_SETTING_DEFAULTS = {
    "auto_envvar_prefix": None,
    "terminal_width": None,
    "max_content_width": 80,
    "help_option_names": ["--help"],
    "token_normalize_func": None,
    "color": None,
    "show_default": False,
    "allow_extra_args": False,
    "ignore_unknown_options": False,
    "allow_interspersed_args": None,
}


class Context:
    """Invocation context, created by Optlyn for each command run (Interface Contract §6)."""

    def __init__(
        self,
        command,
        parent=None,
        info_name=None,
        obj=None,
        default_map=None,
        terminal_width=None,
        max_content_width=None,
        help_option_names=None,
        token_normalize_func=None,
        color=None,
        show_default=None,
        allow_extra_args=None,
        allow_interspersed_args=None,
        ignore_unknown_options=None,
        auto_envvar_prefix=None,
        resilient_parsing=False,
        chained=False,
        **extra,
    ):
        self.command = command
        self.parent = parent
        self.info_name = info_name if info_name is not None else command.name
        self.extra = extra
        self.params = {}
        self.args = []
        self.protected_args = []
        self.invoked_subcommand = None
        self.resilient_parsing = resilient_parsing
        self.chained = chained
        self._sources = {}
        self._closers = []
        self._children = []
        cmd_settings = dict(getattr(command, "context_settings", None) or {})
        explicit = {
            "auto_envvar_prefix": auto_envvar_prefix,
            "terminal_width": terminal_width,
            "max_content_width": max_content_width,
            "help_option_names": help_option_names,
            "token_normalize_func": token_normalize_func,
            "color": color,
            "show_default": show_default,
            "allow_extra_args": allow_extra_args,
            "ignore_unknown_options": ignore_unknown_options,
            "allow_interspersed_args": allow_interspersed_args,
        }
        for key, default in _SETTING_DEFAULTS.items():
            value = explicit[key]
            if value is None:
                if key in cmd_settings and cmd_settings[key] is not None:
                    value = cmd_settings[key]
                elif parent is not None:
                    value = getattr(parent, key)
                else:
                    value = default
            setattr(self, key, value)
        if parent is not None:
            parent._children.append(self)
            if obj is None:
                obj = parent.obj
        if obj is None:
            obj = cmd_settings.get("obj")
        self.obj = obj
        # default map nests by subcommand name (FP-07)
        dm = default_map
        if dm is None and parent is not None and isinstance(parent.default_map, dict):
            dm = parent.default_map.get(self.info_name)
        if dm is None:
            dm = cmd_settings.get("default_map")
        self.default_map = dm

    # --- context protocol -------------------------------------------------
    def __enter__(self):
        _state.push_context(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        _state.pop_context(self)
        return False

    # --- navigation -------------------------------------------------------
    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    @property
    def command_path(self):
        rv = self.info_name or ""
        if self.parent is not None:
            parent_path = self.parent.command_path
            rv = f"{parent_path} {rv}" if parent_path else rv
        return rv

    def find_object(self, object_type):
        node = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

    # --- resources --------------------------------------------------------
    def call_on_close(self, func):
        self._closers.append(func)
        return func

    def with_resource(self, cm):
        """Enter ``cm`` and return its value; it is exited when the invocation closes."""
        value = cm.__enter__()
        self._closers.append(lambda: cm.__exit__(None, None, None))
        return value

    def close(self):
        for child in list(self._children):
            child.close()
        while self._closers:
            func = self._closers.pop()
            try:
                func()
            except Exception:  # pragma: no cover - best effort cleanup
                pass

    # --- sources ----------------------------------------------------------
    def get_parameter_source(self, name):
        declared = {p.name for p in self.command.params}
        if name not in declared:
            return None
        return self._sources.get(name, ParameterSource.DEFAULT)

    # --- invocation -------------------------------------------------------
    def invoke(self, __callback, /, *args, **kwargs):
        """Run a callback or another command from inside a callback (FP-07)."""
        if isinstance(__callback, Command):
            other = __callback
            if other.callback is None:
                raise TypeError("The given command does not have a callback that can be invoked.")
            sub = Context(other, parent=self, info_name=other.name)
            for p in other.params:
                if p.expose_value and p.name not in kwargs:
                    kwargs[p.name] = p.get_default_value(sub)
            sub.params.update(kwargs)
            return other.invoke(sub)
        with self:
            return __callback(*args, **kwargs)

    def forward(self, __cmd, /, **kwargs):
        merged = dict(self.params)
        merged.update(kwargs)
        return self.invoke(__cmd, **merged)

    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def fail(self, message):
        raise UsageError(message, self)

    def get_help(self):
        return self.command.get_help(self)

    def get_usage(self):
        return self.command.get_usage(self)

    def auto_envvar_name(self, dest):
        """Environment name built from the automatic prefix (FP-07)."""
        parts = []
        node = self
        while node.parent is not None:
            parts.append(node.info_name)
            node = node.parent
        pieces = [self.auto_envvar_prefix] + list(reversed(parts)) + [dest]
        return "_".join(str(p).replace("-", "_").upper() for p in pieces if p)


# ---------------------------------------------------------------------------
# Parameters
# ---------------------------------------------------------------------------


def _split_pair(decl):
    if len(decl) >= 3 and decl[0] in _PREFIX_CHARS:
        for i in range(1, len(decl) - 1):
            if decl[i] == "/" and decl[i + 1] in _PREFIX_CHARS:
                return decl[:i], decl[i + 1 :]
    return decl, None


def _is_long(name):
    return len(name) >= 3 and name[0] in _PREFIX_CHARS and name[1] == name[0]


def _infer_dest(names):
    stripped = [n.lstrip("".join(_PREFIX_CHARS)) for n in names]
    for s in stripped:
        if s.isidentifier():
            return s
    for n, s in zip(names, stripped):
        if _is_long(n):
            return s.replace("-", "_")
    return stripped[0].replace("-", "_")


class Parameter:
    """Base class of options and arguments."""

    is_argument = False
    param_type_name = "parameter"

    def __init__(self):
        self.is_eager = False
        self.expose_value = True
        self.callback = None
        self.deprecated = False
        self.deprecation_note = None
        self.hidden = False

    def get_error_hint(self, ctx=None):
        return f"'{self.name}'"

    def get_default(self, ctx=None):
        default = self.default
        if callable(default):
            return default()
        return default

    def get_default_value(self, ctx=None):
        d = self.get_default(ctx)
        if d is None:
            return self.missing_value()
        return self._coerce_default(d, ctx)

    def missing_value(self):
        return None

    # --- conversion ------------------------------------------------------
    def _is_tuple_type(self):
        return isinstance(self.type, Tuple)

    def _arity_is_one(self):
        return self.nargs == 1 and not self._is_tuple_type() and not self.multiple

    def convert_value(self, ctx, tokens):
        """Convert one occurrence (a list of raw tokens)."""
        if self._is_tuple_type():
            return self.type.convert(tuple(tokens), self, ctx)
        if self.nargs != 1:
            return tuple(self.type.convert(t, self, ctx) for t in tokens)
        return self.type.convert(tokens[0], self, ctx)

    def _coerce_one(self, value, ctx):
        """Coerce a default-like value (already a Python object) for one occurrence."""
        if isinstance(value, str):
            return self.type.convert(value, self, ctx)
        if self._is_tuple_type():
            return self.type.convert(value, self, ctx)
        if self.nargs != 1 and isinstance(value, (list, tuple)):
            return tuple(self.type.convert(v, self, ctx) for v in value)
        return self.type.convert(value, self, ctx)

    def _coerce_default(self, value, ctx):
        if self.multiple:
            if isinstance(value, str) or not hasattr(value, "__iter__"):
                raise BadParameter(
                    "needs an iterable (sequence) default.", ctx=ctx, param=self
                )
            return tuple(self._coerce_one(v, ctx) for v in value)
        if self.nargs != 1 and not self._is_tuple_type():
            if isinstance(value, str) or not hasattr(value, "__iter__"):
                raise BadParameter("needs an iterable (sequence) default.", ctx=ctx, param=self)
            return tuple(self._coerce_one(v, ctx) for v in value)
        return self._coerce_one(value, ctx)

    def _split_env(self, text):
        if self.multiple or self.nargs != 1:
            return self.type.split_envvar_value(text)
        return [text]

    # --- processing ------------------------------------------------------
    def handle_parse_result(self, ctx, occs, order_idx=None):
        """Resolve this parameter's value from all sources and store it on ``ctx``."""
        if occs and self.deprecated:
            msg = f"DeprecationWarning: The {self._deprecation_label()} is deprecated."
            if isinstance(self.deprecated, str):
                msg += " " + self.deprecated
            elif self.deprecation_note:
                msg += " " + self.deprecation_note
            echo(msg, err=True)
        value, source = self.resolve_value(ctx, occs)
        if value is _MISSING:
            if self.required:
                raise MissingParameter(ctx=ctx, param=self)
            value = self.missing_value()
            source = ParameterSource.DEFAULT
        if self.callback is not None:
            value = self.callback(ctx, self, value)
        if self.expose_value:
            ctx.params[self.name] = value
        ctx._sources[self.name] = source or ParameterSource.DEFAULT

    def _deprecation_label(self):
        return f"'{self.name}' {'argument' if self.is_argument else 'option'}"

    def _env_value(self, ctx):
        """Return (value, True) when an environment variable supplies a value."""
        return _MISSING, None

    def _default_map_value(self, ctx):
        # spec: FP-07 default map; a string is split only when the per-occurrence arity is not one
        dm = ctx.default_map
        if not isinstance(dm, dict) or self.name not in dm:
            return _MISSING
        raw = dm[self.name]
        one_per_occurrence = self.nargs == 1 and not self._is_tuple_type()
        if isinstance(raw, str):
            if one_per_occurrence:
                if self.multiple:
                    raise BadParameter("needs an iterable (sequence) default.", ctx=ctx, param=self)
                return self.type.convert(raw, self, ctx)
            tokens = self.type.split_envvar_value(raw)
            value = self.convert_value(ctx, tokens)
            return (value,) if self.multiple else value
        if isinstance(raw, (list, tuple)):
            return self._coerce_default(raw, ctx)
        return raw

    def _declared_default(self, ctx):
        if self.default is None:
            return _MISSING
        return self._coerce_default(self.get_default(ctx), ctx)

    def _default_for_prompt(self, ctx):
        val = self._default_map_value(ctx)
        if val is _MISSING:
            val = self._declared_default(ctx)
        return None if val is _MISSING else val

    def resolve_value(self, ctx, occs):
        raise NotImplementedError


class Option(Parameter):
    """A named parameter (FP-03). Declared with flag names such as ``--name`` or ``-n``."""

    param_type_name = "option"

    def __init__(self, param_decls=None, **attrs):
        super().__init__()
        decls = list(param_decls or [])
        opts, secondary, dest = [], [], None
        for decl in decls:
            if not decl:
                raise TypeError("Empty parameter declaration.")
            if decl[0] in _PREFIX_CHARS:
                on, off = _split_pair(decl)
                if off is not None:
                    opts.append(on)
                    secondary.append(off)
                else:
                    opts.append(decl)
            else:
                if not decl.isidentifier():
                    raise TypeError(f"Invalid destination name {decl!r}.")
                dest = decl
        if not opts and dest is None:
            raise TypeError("Option declarations need at least one flag name or a destination.")
        if dest is None:
            dest = _infer_dest(opts)
        self.opts = opts
        self.secondary_opts = secondary
        self.name = dest
        self.dest = dest
        self._parse_attrs(attrs)

    def _parse_attrs(self, attrs):
        attrs = dict(attrs)
        allowed = {
            "type", "default", "required", "is_flag", "flag_value", "count", "multiple",
            "nargs", "envvar", "allow_from_autoenv", "prompt", "prompt_required", "hide_input",
            "confirmation_prompt", "callback", "is_eager", "expose_value", "hidden", "deprecated",
            "help", "metavar", "show_default", "show_envvar", "shell_complete", "cls",
            "_is_help",
        }
        unknown = set(attrs) - allowed
        if unknown:
            raise TypeError(f"Unknown option keyword(s): {', '.join(sorted(unknown))}")
        attrs.pop("cls", None)
        self._is_help = attrs.pop("_is_help", False)
        self._explicit_default = "default" in attrs
        default = attrs.pop("default", None)
        self.default = default
        self.required = bool(attrs.pop("required", False))
        is_flag = attrs.pop("is_flag", None)
        self.is_count = bool(attrs.pop("count", False))
        self.multiple = bool(attrs.pop("multiple", False))
        flag_value = attrs.pop("flag_value", None)
        if is_flag is None:
            is_flag = bool(self.secondary_opts) or isinstance(default, bool)
        if self.is_count:
            is_flag = False
        self.is_flag = bool(is_flag)
        if self.is_flag:
            if flag_value is None:
                flag_value = (not default) if isinstance(default, bool) else True
            self.flag_value = flag_value
        else:
            self.flag_value = flag_value
        self.optional_value = (flag_value is not None) and not self.is_flag and not self.is_count
        nargs = attrs.pop("nargs", None)
        type_ = attrs.pop("type", None)
        if isinstance(type_, Tuple):
            nargs = len(type_.types)
        if nargs is None:
            nargs = 1
        if not isinstance(nargs, int) or nargs < 1:
            raise TypeError("nargs for an option must be a positive integer.")
        self.nargs = nargs
        if self.is_flag or self.is_count:
            if type_ is None:
                type_ = BOOL if self.is_flag else INT
        if type_ is None:
            if default is not None and not callable(default):
                type_ = infer_type_from_default(default)
            else:
                type_ = STRING
        self.type = to_param_type(type_)
        self.envvar = attrs.pop("envvar", None)
        if isinstance(self.envvar, str):
            self.envvar = [self.envvar]
        elif self.envvar is not None:
            self.envvar = list(self.envvar)
        self.allow_from_autoenv = bool(attrs.pop("allow_from_autoenv", True))
        prompt = attrs.pop("prompt", None)
        self.prompt = prompt if prompt not in (None, False) else None
        self.prompt_required = bool(attrs.pop("prompt_required", True))
        self.hide_input = bool(attrs.pop("hide_input", False))
        self.confirmation_prompt = bool(attrs.pop("confirmation_prompt", False))
        self.callback = attrs.pop("callback", None)
        self.is_eager = bool(attrs.pop("is_eager", False))
        self.expose_value = bool(attrs.pop("expose_value", True))
        self.hidden = bool(attrs.pop("hidden", False))
        dep = attrs.pop("deprecated", False)
        self.deprecated = bool(dep)
        self.deprecation_note = dep if isinstance(dep, str) else None
        self.help = attrs.pop("help", None)
        self.metavar = attrs.pop("metavar", None)
        self.show_default = attrs.pop("show_default", None)
        self.show_envvar = bool(attrs.pop("show_envvar", False))
        self.shell_complete = attrs.pop("shell_complete", None)
        if self.deprecated and self.required:
            raise TypeError("A deprecated option cannot also be required.")
        if self.deprecated and self.prompt:
            raise TypeError("A deprecated option cannot use a prompt.")
        if self.prompt and self.is_flag:
            self.prompt = None

    @property
    def all_names(self):
        return self.opts + self.secondary_opts

    def get_error_hint(self, ctx=None):
        return " / ".join(f"'{n}'" for n in self.all_names)

    def missing_value(self):
        if self.is_flag:
            return False
        if self.is_count:
            return 0
        if self.multiple:
            return ()
        return None

    def get_help_metavar(self):
        if self.is_flag or self.is_count or self.secondary_opts:
            return None
        if self.metavar:
            return self.metavar
        if self.nargs != 1 or self._is_tuple_type():
            if self._is_tuple_type():
                return " ".join(t.get_metavar(self) for t in self.type.types)
            return " ".join([self.type.get_metavar(self)] * self.nargs)
        return self.type.get_metavar(self)

    def _env_names(self, ctx):
        names = list(self.envvar or [])
        if ctx.auto_envvar_prefix and self.allow_from_autoenv:
            names.append(ctx.auto_envvar_name(self.name))
        return names

    def _env_value(self, ctx):
        # spec: N-000231..N-000240 (environment variables for options)
        for name in self._env_names(ctx):
            raw = os.environ.get(name)
            if raw is None or raw == "":
                continue
            if self.is_flag:
                flag = self._bool_from_env(raw, ctx)
                if flag is None:
                    continue
                return flag, ParameterSource.ENVIRONMENT
            if self.is_count:
                return INT.convert(raw, self, ctx), ParameterSource.ENVIRONMENT
            tokens = self._split_env(raw)
            if self.multiple or self.nargs != 1 or self._is_tuple_type():
                if self.multiple and self.nargs == 1:
                    return tuple(self.type.convert(t, self, ctx) for t in tokens), ParameterSource.ENVIRONMENT
                return self.convert_value(ctx, tokens), ParameterSource.ENVIRONMENT
            return self.type.convert(raw, self, ctx), ParameterSource.ENVIRONMENT
        return _MISSING, None

    def _bool_from_env(self, raw, ctx):
        text = raw.strip().lower()
        if isinstance(self.flag_value, bool) or self.flag_value is None:
            if text == "":
                return False
            if text in ("true", "1", "yes", "on", "t", "y"):
                return True
            if text in ("false", "0", "no", "off", "f", "n"):
                return False
            raise BadParameter(f"{raw!r} is not a valid boolean.", ctx=ctx, param=self)
        if raw == str(self.flag_value):
            return self.flag_value
        if text in ("true", "1", "yes", "on", "t", "y"):
            return True
        if text in ("false", "0", "no", "off", "f", "n"):
            return False
        return None

    def _from_cmdline(self, ctx, occs):
        if self.is_count:
            return len(occs), ParameterSource.COMMANDLINE
        if self.is_flag:
            last = occs[-1]
            return (self.flag_value if last else False), ParameterSource.COMMANDLINE
        values = []
        source = ParameterSource.COMMANDLINE
        for toks in occs:
            if not toks:
                if self.prompt is not None:
                    values.append(self._prompt(ctx))
                    source = ParameterSource.PROMPT
                else:
                    fv = self.flag_value
                    if isinstance(fv, str):
                        fv = self.type.convert(fv, self, ctx)
                    values.append(fv)
            else:
                values.append(self.convert_value(ctx, toks))
        if self.multiple:
            return tuple(values), source
        return values[-1], source

    def _prompt(self, ctx):
        from .termui import prompt as _prompt_fn

        text = self.prompt if isinstance(self.prompt, str) else self.name.replace("_", " ").capitalize()
        default = self._default_for_prompt(ctx)

        def proc(v):
            return self.type.convert(v, self, ctx)

        value = _prompt_fn(
            text,
            default=default,
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            value_proc=proc,
        )
        if self.multiple:
            return (value,)
        return value

    def resolve_value(self, ctx, occs):
        # spec: N-000243..N-000250 (value precedence)
        if occs:
            return self._from_cmdline(ctx, occs)
        val, src = self._env_value(ctx)
        if val is not _MISSING:
            return val, src
        if self.prompt is not None and self.required and not self.is_flag:
            return self._prompt(ctx), ParameterSource.PROMPT
        dm = self._default_map_value(ctx)
        if dm is not _MISSING:
            return dm, ParameterSource.DEFAULT_MAP
        dv = self._declared_default(ctx)
        if dv is not _MISSING:
            return dv, ParameterSource.DEFAULT
        if self.is_flag and self.default is None:
            return False, ParameterSource.DEFAULT
        return _MISSING, None


class Argument(Parameter):
    """A positional parameter (FP-04)."""

    param_type_name = "argument"
    is_argument = True

    def __init__(self, param_decls=None, **attrs):
        super().__init__()
        decls = list(param_decls or [])
        if len(decls) != 1 or not decls[0] or decls[0][0] in _PREFIX_CHARS:
            raise TypeError("An argument takes a single destination name.")
        self.name = decls[0]
        self.dest = self.name
        self.opts = []
        self.secondary_opts = []
        self.is_flag = False
        self.is_count = False
        self.multiple = False
        allowed = {
            "type", "default", "required", "nargs", "envvar", "deprecated", "help", "metavar",
            "callback", "expose_value", "is_eager", "hidden", "shell_complete", "cls",
        }
        unknown = set(attrs) - allowed
        if unknown:
            raise TypeError(f"Unknown argument keyword(s): {', '.join(sorted(unknown))}")
        attrs.pop("cls", None)
        self.default = attrs.pop("default", None)
        nargs = attrs.pop("nargs", 1)
        type_ = attrs.pop("type", None)
        if isinstance(type_, Tuple):
            nargs = len(type_.types)
        if nargs != -1 and (not isinstance(nargs, int) or nargs < 1):
            raise TypeError("nargs for an argument must be a positive integer or -1.")
        self.nargs = nargs
        if type_ is None:
            type_ = infer_type_from_default(self.default) if self.default is not None and not callable(self.default) else STRING
        self.type = to_param_type(type_)
        if "required" in attrs:
            self.required = bool(attrs.pop("required"))
        else:
            self.required = (self.default is None) and nargs != -1
        envvar = attrs.pop("envvar", None)
        if isinstance(envvar, str):
            envvar = [envvar]
        self.envvar = list(envvar) if envvar is not None else None
        self.allow_from_autoenv = False
        dep = attrs.pop("deprecated", False)
        self.deprecated = bool(dep)
        self.deprecation_note = dep if isinstance(dep, str) else None
        self.help = attrs.pop("help", None)
        self.metavar = attrs.pop("metavar", None)
        self.callback = attrs.pop("callback", None)
        self.expose_value = bool(attrs.pop("expose_value", True))
        self.is_eager = bool(attrs.pop("is_eager", False))
        self.hidden = bool(attrs.pop("hidden", False))
        self.shell_complete = attrs.pop("shell_complete", None)
        self.show_default = None
        self.show_envvar = False
        self.prompt = None
        if self.deprecated and self.required:
            raise TypeError("A deprecated argument cannot be required.")

    @property
    def is_variadic(self):
        return self.nargs == -1

    def get_error_hint(self, ctx=None):
        return f"'{self.metavar or self.name.upper()}'"

    def get_placeholder(self):
        base = self.metavar or self.name.upper()
        if self.is_variadic:
            base += "..."
        if not self.required:
            base = f"[{base}]"
        return base

    def missing_value(self):
        if self.is_variadic:
            return ()
        return None

    def _env_value(self, ctx):
        if not self.envvar:
            return _MISSING, None
        for name in self.envvar:
            raw = os.environ.get(name)
            if raw is None or raw == "":
                continue
            if self.nargs != 1 or self.is_variadic:
                return self.convert_value(ctx, self.type.split_envvar_value(raw)), ParameterSource.ENVIRONMENT
            return self.type.convert(raw, self, ctx), ParameterSource.ENVIRONMENT
        return _MISSING, None

    def convert_arg_tokens(self, ctx, tokens):
        if self._is_tuple_type():
            return self.type.convert(tuple(tokens), self, ctx)
        if self.nargs == 1 and not self.is_variadic:
            return self.type.convert(tokens[0], self, ctx)
        return tuple(self.type.convert(t, self, ctx) for t in tokens)

    def resolve_value(self, ctx, occs):
        if occs:
            return self.convert_arg_tokens(ctx, occs[0]), ParameterSource.COMMANDLINE
        val, src = self._env_value(ctx)
        if val is not _MISSING:
            return val, src
        dm = self._default_map_value(ctx)
        if dm is not _MISSING:
            return dm, ParameterSource.DEFAULT_MAP
        dv = self._declared_default(ctx)
        if dv is not _MISSING:
            return dv, ParameterSource.DEFAULT
        return _MISSING, None

    def get_help_metavar(self):
        return self.metavar or self.name.upper()


# ---------------------------------------------------------------------------
# Argument parsing
# ---------------------------------------------------------------------------


def _is_optlike(tok, prefixes):
    return len(tok) > 1 and tok[0] in prefixes


def _parse_tokens(ctx, params, args, interspersed, cap, ignore_unknown):
    """Scan ``args`` for options.

    Returns ``(occs, order, pos)``: occurrences per option, the first-seen index of
    each option, and the positional tokens as ``(token, after_double_dash)`` pairs.
    """
    prefixes = {"-"}
    table = {}
    normalize = ctx.token_normalize_func

    def key(name):
        return normalize(name) if normalize else name

    for p in params:
        if isinstance(p, Option):
            for n in p.opts:
                prefixes.add(n[0])
                table.setdefault(key(n), (p, True))
            for n in p.secondary_opts:
                prefixes.add(n[0])
                table.setdefault(key(n), (p, False))

    occs, order, pos = {}, {}, []
    counter = [0]

    def record(p, occ):
        order.setdefault(p, counter[0])
        counter[0] += 1
        occs.setdefault(p, []).append(occ)

    def lookup(name):
        return table.get(key(name))

    def consume(p, on, inline, i):
        """Return (occurrence, next_index) for an option matched with an optional inline value."""
        if p.is_count:
            if inline is not None:
                raise BadOptionUsage(f"Option '{p.all_names[0]}' takes no value.", ctx)
            return None, i
        if p.is_flag:
            if inline is not None:
                raise BadOptionUsage(f"Option '{p.all_names[0]}' does not take a value.", ctx)
            return on, i
        if inline is None and (p.optional_value or (p.prompt is not None and p.nargs == 1)):
            if i < n and not _is_optlike(args[i], prefixes):
                return [args[i]], i + 1
            return [], i
        if p.optional_value or (p.prompt is not None and p.nargs == 1):
            return [inline], i
        toks = [] if inline is None else [inline]
        need = p.nargs - len(toks)
        if i + need > n:
            label = " / ".join(f"'{x}'" for x in p.all_names)
            if p.nargs == 1:
                raise BadOptionUsage(f"Option {label} requires an argument.", ctx)
            raise BadOptionUsage(f"Option {label} requires {p.nargs} arguments.", ctx)
        toks += args[i : i + need]
        return toks, i + need

    i = 0
    n = len(args)
    stop = False
    while i < n:
        tok = args[i]
        i += 1
        if stop:
            pos.append((tok, False))
            continue
        if tok == "--":
            pos.extend((t, True) for t in args[i:])
            break
        if not _is_optlike(tok, prefixes):
            if not interspersed and len(pos) >= cap:
                stop = True
                pos.append((tok, False))
                continue
            pos.append((tok, False))
            if not interspersed and len(pos) >= cap and not _is_group_mode(ctx, params):
                stop = True
            continue
        # option-shaped token
        found = lookup(tok)
        inline = None
        if found is None and "=" in tok:
            base, _, inline = tok.partition("=")
            found = lookup(base)
            if found is None:
                inline = None
        if found is not None:
            p, on = found
            occ, i = consume(p, on, inline, i)
            record(p, occ)
            continue
        if len(tok) > 2 and tok[0] in prefixes and not _is_long(tok) and tok[1] not in prefixes:
            body = tok[1:]
            j = 0
            while j < len(body):
                name = tok[0] + body[j]
                hit = lookup(name)
                if hit is None:
                    if ignore_unknown:
                        pos.append((tok[0] + body[j:], False))
                        break
                    raise NoSuchOption(name, ctx=ctx)
                p, on = hit
                rest = body[j + 1 :]
                if p.is_flag or p.is_count:
                    occ, _ = consume(p, on, None, i)
                    record(p, occ)
                    j += 1
                    continue
                occ, i = consume(p, on, rest if rest else None, i)
                record(p, occ)
                break
            continue
        if ignore_unknown:
            pos.append((tok, False))
            continue
        raise NoSuchOption(tok.partition("=")[0], ctx=ctx)
    return occs, order, pos


def _is_group_mode(ctx, params):
    return ctx.command.is_group


def _assign_arguments(ctx, arg_params, pos):
    """Assign positional tokens to declared arguments (FP-04)."""
    occs = {}
    idx = 0
    for k, a in enumerate(arg_params):
        if a.nargs == -1:
            after = sum(b.nargs for b in arg_params[k + 1 :] if b.nargs != -1)
            take = max(0, len(pos) - idx - after)
            if take:
                occs[a] = [[t for t, _ in pos[idx : idx + take]]]
                idx += take
            continue
        avail = len(pos) - idx
        if avail <= 0:
            continue
        take = min(a.nargs, avail)
        if take < a.nargs:
            raise BadArgumentUsage(
                f"Argument {a.get_error_hint()} takes {a.nargs} values.", ctx
            )
        occs[a] = [[t for t, _ in pos[idx : idx + take]]]
        idx += take
    return occs, pos[idx:]


def _check_extras(ctx, extras, allow, ignore_unknown):
    optlike = [t for t, dd in extras if not dd and not ignore_unknown and len(t) > 1 and t[0] in "-/+"]
    if optlike:
        raise NoSuchOption(optlike[0].partition("=")[0], ctx=ctx)
    if extras and not allow:
        names = ", ".join(repr(t) for t, _ in extras)
        word = "argument" if len(extras) == 1 else "arguments"
        raise UsageError(f"Got unexpected extra {word} ({names})", ctx)


def _rebuild_tokens(extras):
    out = []
    added = False
    for tok, dd in extras:
        if dd and not added:
            out.append("--")
            added = True
        out.append(tok)
    return out


def _processing_order(params, order):
    eager = [p for p in params if p.is_eager]
    eager.sort(key=lambda p: order.get(p, INF))
    return eager + [p for p in params if not p.is_eager]


def _skipped_winners(params, occs, order):
    groups = {}
    for p in params:
        if p.expose_value:
            groups.setdefault(p.name, []).append(p)
    skip = set()
    for group in groups.values():
        if len(group) < 2:
            continue
        present = [p for p in group if occs.get(p)]
        if present:
            win = max(present, key=lambda p: order.get(p, -1))
        else:
            explicit = [p for p in group if getattr(p, "_explicit_default", False)]
            win = explicit[-1] if explicit else group[-1]
        skip.update(p for p in group if p is not win)
    return skip


# ---------------------------------------------------------------------------
# Help rendering
# ---------------------------------------------------------------------------


def _wrap_width(ctx):
    if ctx is None:
        return 80
    if ctx.terminal_width:
        return int(ctx.terminal_width)
    return min(get_terminal_width(80), int(ctx.max_content_width or 80))


def _definition_rows(rows, width):
    """Lay out (first column, help) rows as an indented two-column list."""
    if not rows:
        return []
    col = min(max(len(first) for first, _ in rows), 30)
    indent = 2
    help_width = max(width - (col + indent + 2), 20)
    out = []
    for first, text in rows:
        if not text:
            out.append(" " * indent + first)
            continue
        wrapped = wrap_text(text, help_width).split("\n")
        if len(first) > col:
            out.append(" " * indent + first)
            out.extend(" " * (col + indent + 2) + line for line in wrapped)
        else:
            out.append(" " * indent + first.ljust(col) + "  " + wrapped[0])
            out.extend(" " * (col + indent + 2) + line for line in wrapped[1:])
    return out


def _option_row(p, ctx):
    first = ", ".join(p.opts)
    if p.secondary_opts:
        first += " / " + ", ".join(p.secondary_opts)
    meta = p.get_help_metavar()
    if meta:
        first += " " + meta
    parts = []
    if p.help:
        parts.append(str(p.help))
    extras = []
    if p.required:
        extras.append("[required]")
    show = p.show_default if p.show_default is not None else ctx.show_default
    if show and p.default is not None and not (p.is_flag and p.default is False):
        if isinstance(show, str):
            extras.append(f"[default: {show}]")
        elif callable(p.default):
            extras.append("[default: (dynamic)]")
        else:
            extras.append(f"[default: {_format_default(p.default)}]")
    if p.show_envvar and p.envvar:
        extras.append(f"[env var: {p.envvar[0]}]")
    if p.deprecated:
        extras.append("(deprecated)")
    text = " ".join(parts + extras)
    return first, text


def _format_default(value):
    if isinstance(value, (list, tuple)):
        return ", ".join(str(v) for v in value)
    return str(value)


def _usage_line(cmd, ctx):
    pieces = [ctx.command_path, cmd.options_metavar]
    for a in cmd.params:
        if a.is_argument:
            pieces.append(a.get_placeholder())
    if cmd.is_group:
        pieces.append(cmd._subcommand_usage())
    return "Usage: " + " ".join(p for p in pieces if p)


def _format_help(cmd, ctx):
    width = _wrap_width(ctx)
    lines = [_usage_line(cmd, ctx), ""]
    if cmd.deprecated:
        note = f" {cmd.deprecation_note}" if cmd.deprecation_note else ""
        lines += ["(DEPRECATED)" + note, ""]
    desc = clean_help_text(cmd.help) if cmd.help else ""
    if desc:
        lines += [wrap_text(desc, width), ""]
    arg_rows = [(a.get_placeholder().strip("[]."), a.help) for a in cmd.params if a.is_argument and a.help and not a.hidden]
    if arg_rows:
        lines.append("Positional arguments:")
        lines += _definition_rows(arg_rows, width) + [""]
    opt_rows = [
        _option_row(p, ctx)
        for p in cmd.get_params(ctx)
        if isinstance(p, Option) and not p.hidden
    ]
    if opt_rows:
        lines.append("Options:")
        lines += _definition_rows(opt_rows, width) + [""]
    if cmd.is_group:
        rows = []
        for name in cmd.list_commands(ctx):
            sub = cmd.get_command(ctx, name)
            if sub is None or sub.hidden:
                continue
            rows.append((name, sub.get_short_help_str()))
        if rows:
            lines.append("Commands:")
            lines += _definition_rows(rows, width) + [""]
    if cmd.epilog:
        lines += [wrap_text(cmd.epilog, width), ""]
    return "\n".join(lines).rstrip() + "\n"


def _show_help(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


# ---------------------------------------------------------------------------
# Commands and groups
# ---------------------------------------------------------------------------


class Command:
    """A leaf command (FP-01). Created by :func:`command`, or directly."""

    is_group = False

    def __init__(
        self,
        name,
        context_settings=None,
        callback=None,
        params=None,
        help=None,
        epilog=None,
        short_help=None,
        options_metavar="[OPTIONS]",
        add_help_option=True,
        no_args_is_help=False,
        hidden=False,
        deprecated=False,
        **extra,
    ):
        self.name = name
        self.context_settings = dict(context_settings or {})
        self.callback = callback
        self.params = list(params or [])
        self.help = help if help is not None else (getattr(callback, "__doc__", None) if callback else None)
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = bool(deprecated)
        self.deprecation_note = deprecated if isinstance(deprecated, str) else None
        self.extra = extra
        variadic = [p for p in self.params if p.is_argument and p.nargs == -1]
        if len(variadic) > 1:
            raise TypeError("Only one variadic argument may be declared per command.")

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    # --- help -------------------------------------------------------------
    def get_short_help_str(self, limit=45):
        if self.short_help:
            return self.short_help
        return make_default_short_help(clean_help_text(self.help or ""), limit)

    def get_help(self, ctx):
        return _format_help(self, ctx)

    def get_usage(self, ctx):
        return _usage_line(self, ctx)

    @property
    def options_placeholder(self):
        return self.options_metavar

    def get_help_option(self, ctx):
        if not self.add_help_option:
            return None
        used = set()
        for p in self.params:
            if isinstance(p, Option) and not p._is_help:
                used.update(p.all_names)
        names = [n for n in ctx.help_option_names if n not in used]
        if not names:
            return None
        opt = Option(
            names,
            is_flag=True,
            is_eager=True,
            expose_value=False,
            help="Show this message and exit.",
            callback=_show_help,
        )
        opt._is_help = True
        return opt

    def get_params(self, ctx):
        params = list(self.params)
        help_opt = self.get_help_option(ctx)
        if help_opt is not None:
            params.append(help_opt)
        return params

    # --- invocation -------------------------------------------------------
    def make_context(self, info_name, args, parent=None, chained=False, **extra):
        ctx = Context(self, parent=parent, info_name=info_name, chained=chained, **extra)
        try:
            with ctx:
                self.parse_args(ctx, list(args))
        except BaseException:
            ctx.close()
            raise
        return ctx

    def _interspersed(self, ctx):
        if ctx.chained:
            return False
        if ctx.allow_interspersed_args is not None:
            return bool(ctx.allow_interspersed_args)
        return not self.is_group

    def _no_args_is_help(self, ctx):
        return bool(self.no_args_is_help)

    def parse_args(self, ctx, args):
        """Parse ``args`` into ``ctx.params``; leftover tokens go to ``ctx.args``."""
        if not args and self._no_args_is_help(ctx) and not ctx.resilient_parsing:
            raise NoArgsIsHelp("", ctx=ctx)
        extras = self._parse_and_process(ctx, args)
        if self.is_group:
            return extras
        allow = ctx.allow_extra_args or ctx.chained
        _check_extras(ctx, extras, allow, ctx.ignore_unknown_options)
        if extras:
            ctx.args = [t for t, _ in extras]
        return None

    def _parse_and_process(self, ctx, args):
        params = self.get_params(ctx)
        interspersed = self._interspersed(ctx)
        arg_params = [p for p in params if p.is_argument]
        cap = INF if any(a.nargs == -1 for a in arg_params) else sum(a.nargs for a in arg_params)
        ignore_unknown = bool(ctx.ignore_unknown_options) or (self.is_group and interspersed)
        occs, order, pos = _parse_tokens(ctx, params, args, interspersed, cap, ignore_unknown)
        arg_occs, extras = _assign_arguments(ctx, arg_params, pos)
        occs.update(arg_occs)
        skip = _skipped_winners(params, occs, order)
        for p in _processing_order(params, order):
            if p in skip:
                continue
            p.handle_parse_result(ctx, occs.get(p))
        return extras

    def invoke(self, ctx):
        """Run the callback with the values bound on ``ctx``."""
        if self.deprecated:
            msg = f"DeprecationWarning: The command {self.name!r} is deprecated."
            if self.deprecation_note:
                msg += " " + self.deprecation_note
            echo(msg, err=True)
        if self.callback is None:
            return None
        with ctx:
            return ctx.invoke(self.callback, **ctx.params)

    def main(
        self,
        args=None,
        prog_name=None,
        complete_var=None,
        standalone_mode=True,
        windows_expand_args=True,
        **extra,
    ):
        """Run this command as a program (FP-01 / FP-13)."""
        import re as _re

        args = list(sys.argv[1:]) if args is None else list(args)
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else (self.name or "cli")
        if complete_var is None:
            complete_var = "_" + _re.sub(r"[^A-Za-z0-9_]", "_", prog_name).upper() + "_COMPLETE"

        instruction = os.environ.get(complete_var)
        if instruction:
            from .shell_completion import run_instruction

            handled = run_instruction(self, instruction, prog_name)
            if standalone_mode:
                sys.exit(0 if handled else 1)
            return None

        try:
            try:
                ctx = self.make_context(prog_name, args, **extra)
                try:
                    rv = self.invoke(ctx)
                    if not standalone_mode:
                        return rv
                    ctx.exit()
                finally:
                    ctx.close()
            except (EOFError, KeyboardInterrupt) as exc:
                raise Abort() from exc
            except OptlynError as exc:
                if not standalone_mode:
                    raise
                exc.show()
                sys.exit(exc.exit_code)
        except Exit as exc:
            if standalone_mode:
                sys.exit(exc.exit_code)
            return exc.exit_code
        except Abort:
            if not standalone_mode:
                raise
            echo("Aborted!", file=sys.stderr, err=True)
            sys.exit(1)
        return None


class Group(Command):
    """A command that dispatches to named subcommands (FP-06)."""

    is_group = True

    def __init__(
        self,
        name=None,
        commands=None,
        invoke_without_command=False,
        no_args_is_help=None,
        subcommand_metavar=None,
        chain=False,
        result_callback=None,
        **kwargs,
    ):
        super().__init__(name, **kwargs)
        self.invoke_without_command = bool(invoke_without_command)
        self._no_args_is_help_setting = no_args_is_help
        self.subcommand_metavar = subcommand_metavar or "COMMAND"
        self.chain = bool(chain)
        self._result_callback = result_callback
        self.commands = {}
        if commands:
            items = commands.items() if isinstance(commands, dict) else [(c.name, c) for c in commands]
            for cname, cmd in items:
                self.add_command(cmd, cname)

    def _no_args_is_help(self, ctx):
        if self._no_args_is_help_setting is None:
            return not self.invoke_without_command
        return bool(self._no_args_is_help_setting)

    def _subcommand_usage(self):
        meta = self.subcommand_metavar
        if self.chain:
            return f"{meta} [ARGS]... [{meta} [ARGS]...]..."
        if self.invoke_without_command:
            return f"[{meta}] [ARGS]..."
        return f"{meta} [ARGS]..."

    # --- registration -----------------------------------------------------
    def add_command(self, cmd, name=None):
        # spec: N-000869..N-000871
        if self.chain and isinstance(cmd, Group):
            raise TypeError("A chaining group cannot have a group nested beneath it.")
        name = name or cmd.name
        if name is None:
            raise TypeError("A command needs a name to be added to a group.")
        self.commands[name] = cmd

    def command(self, *args, **kwargs):
        # spec: N-000872
        def decorator(f):
            cmd = command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        if len(args) == 1 and callable(args[0]) and not kwargs:
            f = args[0]
            args = ()
            return decorator(f)
        return decorator

    def group(self, *args, **kwargs):
        # spec: N-000873
        def decorator(f):
            grp = group(*args, **kwargs)(f)
            self.add_command(grp)
            return grp

        if len(args) == 1 and callable(args[0]) and not kwargs:
            return decorator(args[0])
        return decorator

    def result_callback(self):
        # spec: N-000874..N-000875
        def decorator(f):
            self._result_callback = f
            return f

        return decorator

    # --- lookup -----------------------------------------------------------
    def list_commands(self, ctx):
        # spec: N-000876
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        # spec: N-000877
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        norm = ctx.token_normalize_func
        if norm:
            target = norm(cmd_name)
            for name, cmd in self.commands.items():
                if norm(name) == target:
                    return cmd
        return None

    def resolve_command(self, ctx, args):
        cmd_name = args[0]
        cmd = self.get_command(ctx, cmd_name)
        if cmd is None:
            raise UsageError(f"No such command {cmd_name!r}.", ctx)
        return cmd_name, cmd, args[1:]

    # --- parsing / invocation --------------------------------------------
    def parse_args(self, ctx, args):
        if not args and self._no_args_is_help(ctx) and not ctx.resilient_parsing:
            raise NoArgsIsHelp("", ctx=ctx)
        extras = self._parse_and_process(ctx, args)
        if not extras:
            if not self.invoke_without_command:
                raise UsageError("Missing command.", ctx)
            ctx.protected_args = []
            ctx.args = []
            return None
        name = extras[0][0]
        ctx.protected_args = [name]
        ctx.args = _rebuild_tokens(extras[1:])
        return None

    def invoke(self, ctx):
        if self.deprecated:
            msg = f"DeprecationWarning: The command {self.name!r} is deprecated."
            if self.deprecation_note:
                msg += " " + self.deprecation_note
            echo(msg, err=True)
        args = [*ctx.protected_args, *ctx.args]
        ctx.protected_args = []
        ctx.args = []
        if not args:
            # only reachable when invoke_without_command is set
            ctx.invoked_subcommand = None
            rv = Command.invoke(self, ctx)
            if self.chain:
                return self._process_result(ctx, [])
            return self._process_result(ctx, rv)

        if not self.chain:
            cmd_name, cmd, sub_args = self.resolve_command(ctx, args)
            ctx.invoked_subcommand = cmd_name
            Command.invoke(self, ctx)
            sub_ctx = cmd.make_context(cmd_name, sub_args, parent=ctx)
            try:
                with sub_ctx:
                    rv = cmd.invoke(sub_ctx)
            finally:
                sub_ctx.close()
            return self._process_result(ctx, rv)

        ctx.invoked_subcommand = CHAIN_MARKER
        Command.invoke(self, ctx)
        values = []
        while args:
            cmd_name, cmd, sub_args = self.resolve_command(ctx, args)
            sub_ctx = cmd.make_context(cmd_name, sub_args, parent=ctx, chained=True)
            try:
                with sub_ctx:
                    values.append(cmd.invoke(sub_ctx))
                args = list(sub_ctx.args)
            finally:
                sub_ctx.close()
        if self._result_callback is not None:
            self._process_result(ctx, values)
        return values

    def _process_result(self, ctx, value):
        if self._result_callback is None:
            return value
        with ctx:
            return ctx.invoke(self._result_callback, value, **ctx.params)


class CommandCollection(Group):
    """Presents the union of subcommands of several source groups (FP-06)."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources) if sources is not None else []

    def list_commands(self, ctx):
        seen = []
        for src in self.sources:
            for name in src.list_commands(ctx):
                if name not in seen:
                    seen.append(name)
        return sorted(seen)

    def get_command(self, ctx, cmd_name):
        for src in self.sources:
            cmd = src.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None


# ---------------------------------------------------------------------------
# Declaration decorators
# ---------------------------------------------------------------------------


def _param_memo(f, param):
    if not hasattr(f, "__optlyn_params__"):
        f.__optlyn_params__ = []
    f.__optlyn_params__.append(param)


def _take_params(f):
    params = getattr(f, "__optlyn_params__", None)
    if params is None:
        return []
    try:
        del f.__optlyn_params__
    except AttributeError:
        pass
    params = list(params)
    params.reverse()
    return params


def _derive_name(f):
    name = f.__name__.lower()
    for suffix in ("_command", "_cmd", "_group", "_grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def command(name=None, cls=None, **attrs):
    """Declare a leaf command from a function (``@command()`` or ``@command``)."""
    # spec: N-000850..N-000861
    if callable(name) and not isinstance(name, str):
        return command()(name)
    cls = cls or Command

    def decorator(f):
        params = _take_params(f)
        cmd_name = name if name is not None else _derive_name(f)
        return cls(name=cmd_name, callback=f, params=params, **attrs)

    return decorator


def group(name=None, cls=None, **attrs):
    """Declare a group from a function (``@group()`` or ``@group``)."""
    # spec: N-000862..N-000864
    if callable(name) and not isinstance(name, str):
        return group()(name)
    cls = cls or Group

    def decorator(f):
        params = _take_params(f)
        grp_name = name if name is not None else _derive_name(f)
        return cls(name=grp_name, callback=f, params=params, **attrs)

    return decorator


def option(*param_decls, cls=None, **attrs):
    """Attach an option to a function (returns a decorator)."""
    # spec: N-000881..N-000909
    cls = cls or Option

    def decorator(f):
        _param_memo(f, cls(list(param_decls), **attrs))
        return f

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach a positional argument to a function (returns a decorator)."""
    # spec: N-000910..N-000912
    cls = cls or Argument

    def decorator(f):
        _param_memo(f, cls(list(param_decls), **attrs))
        return f

    return decorator


def help_option(*param_decls, **kwargs):
    """Attach an extra eager help flag that prints help and exits (FP-02)."""
    # spec: N-000924, N-000929
    decls = list(param_decls) or ["--help"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _show_help)

    def decorator(f):
        opt = Option(decls, **kwargs)
        opt._is_help = True
        _param_memo(f, opt)
        return f

    return decorator


def _detect_version(package_name):
    try:
        return _md.version(package_name)
    except _md.PackageNotFoundError:
        pass
    try:
        mapping = _md.packages_distributions().get(package_name) or []
    except Exception:  # pragma: no cover
        mapping = []
    for dist in mapping:
        try:
            return _md.version(dist)
        except _md.PackageNotFoundError:
            continue
    return "unknown"


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    """Eager ``--version`` flag printing a version identity (FP-02)."""
    # spec: N-000925, N-000930..N-000931, N-000846..N-000849
    decls = list(param_decls) or ["--version"]
    if version is None and package_name is None:
        frame = inspect.currentframe().f_back
        mod = frame.f_globals.get("__name__", "") if frame else ""
        package_name = mod.partition(".")[0] or None
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        ident = version
        if ident is None:
            ident = _detect_version(package_name) if package_name else "unknown"
        pname = prog_name or ctx.find_root().info_name
        template = message or "%(prog)s, version %(version)s"
        echo(template % {"prog": pname, "package": package_name, "version": ident}, color=ctx.color)
        ctx.exit()

    kwargs["callback"] = callback

    def decorator(f):
        _param_memo(f, Option(decls, **kwargs))
        return f

    return decorator


def custom_version_option(callback, *param_decls, **kwargs):
    """Eager version flag whose identity is the string ``callback(ctx)`` returns."""
    # spec: N-000932, N-000847
    decls = list(param_decls) or ["--version"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")

    def cb(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(callback(ctx), color=ctx.color)
        ctx.exit()

    kwargs["callback"] = cb

    def decorator(f):
        _param_memo(f, Option(decls, **kwargs))
        return f

    return decorator


def password_option(*param_decls, **kwargs):
    """Prompting, hidden, confirmed option (FP-08)."""
    # spec: N-000926
    decls = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)

    def decorator(f):
        _param_memo(f, Option(decls, **kwargs))
        return f

    return decorator


def confirmation_option(*param_decls, **kwargs):
    """Yes-flag that asks for confirmation when omitted and aborts when declined (FP-08)."""
    # spec: N-000927
    decls = list(param_decls) or ["--yes"]
    prompt_text = kwargs.pop("prompt", "Do you want to continue?")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Confirm the action without prompting.")

    def cb(ctx, param, value):
        if not value and not ctx.resilient_parsing:
            from .termui import confirm

            confirm(prompt_text, default=False, abort=True)
        return value

    kwargs["callback"] = cb

    def decorator(f):
        _param_memo(f, Option(decls, **kwargs))
        return f

    return decorator


# ---------------------------------------------------------------------------
# Callback decorators (Interface Contract §6)
# ---------------------------------------------------------------------------


def pass_context(f):
    """Pass the current :class:`Context` as the first argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(f):
    """Pass the current context's ``obj`` as the first argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type, ensure=False):
    """Build a decorator passing the nearest object of ``object_type`` (FP-07)."""

    def decorator(f):
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(
                    f"Managed to invoke callback without a context object of type "
                    f"{object_type.__name__!r} existing."
                )
            return f(obj, *args, **kwargs)

        return new_func

    return decorator


__all__ = [
    "Context",
    "Command",
    "Group",
    "CommandCollection",
    "Option",
    "Argument",
    "Parameter",
    "ParameterSource",
    "CompletionItem",
    "command",
    "group",
    "option",
    "argument",
    "help_option",
    "version_option",
    "custom_version_option",
    "password_option",
    "confirmation_option",
    "pass_context",
    "pass_obj",
    "make_pass_decorator",
    "get_current_context",
]
