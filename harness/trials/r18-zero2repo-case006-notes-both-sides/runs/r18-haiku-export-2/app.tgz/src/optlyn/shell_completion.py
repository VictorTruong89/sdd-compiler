"""Shell completion (Interface Contract §8, PRD FP-12).

Instruction values are ``<shell>_source`` (print the registration script) and
``<shell>_complete`` (print suggestions for the words in ``COMP_WORDS`` /
``COMP_CWORD``). Each suggestion line is ``<kind>\\t<value>\\t<help>`` where kind
is ``plain`` for an ordinary value, ``file`` for a file-path request, or ``dir``
for a directories-only request.
"""

import os
import sys

from .core import CompletionItem, Context, Option

SHELLS = ("bash", "zsh", "fish", "powershell")
# spec: N-001013..N-001037

_SCRIPT_BASH = """\
_{func}_completion() {{
    local IFS=$'\\n'
    local line kind value help
    COMPREPLY=()
    for line in $(env COMP_WORDS="${{COMP_WORDS[*]}}" COMP_CWORD=$COMP_CWORD {var}=bash_complete "$1"); do
        IFS=$'\\t' read -r kind value help <<< "$line"
        case "$kind" in
            plain) COMPREPLY+=("$value") ;;
            file) COMPREPLY+=($(compgen -f -- "$value")) ;;
            dir) COMPREPLY+=($(compgen -d -- "$value")) ;;
        esac
    done
    return 0
}}
complete -o default -F _{func}_completion {prog}
"""

_SCRIPT_ZSH = """\
#compdef {prog}
_{func}_completion() {{
    local -a lines
    local line kind value help
    lines=("${{(@f)$(env COMP_WORDS="${{words[*]}}" COMP_CWORD=$((CURRENT-1)) {var}=zsh_complete {prog})}}")
    for line in $lines; do
        kind=${{line%%$'\\t'*}}
        value=${{${{line#*$'\\t'}}%%$'\\t'*}}
        help=${{line##*$'\\t'}}
        case "$kind" in
            plain) compadd -d "$help" -- "$value" ;;
            file) _files -- ;;
            dir) _files -/ ;;
        esac
    done
}}
compdef _{func}_completion {prog}
"""

_SCRIPT_FISH = """\
function _{func}_completion
    set -l response (env COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -ct) {var}=fish_complete {prog})
    for line in $response
        set -l parts (string split \\t -- $line)
        if test "$parts[1]" = "plain"
            printf "%s\\t%s\\n" $parts[2] $parts[3]
        end
    end
end
complete -c {prog} -f -a '(_{func}_completion)'
"""

_SCRIPT_POWERSHELL = """\
Register-ArgumentCompleter -Native -CommandName {prog} -ScriptBlock {{
    param($wordToComplete, $commandAst, $cursorPosition)
    $words = $commandAst.ToString()
    $env:COMP_WORDS = $words
    $env:COMP_CWORD = $commandAst.CommandElements.Count
    $env:{var} = "powershell_complete"
    & {prog} | ForEach-Object {{
        $parts = $_ -split "`t"
        if ($parts[0] -eq "plain" -and $parts[1] -like "$wordToComplete*") {{
            [System.Management.Automation.CompletionResult]::new($parts[1], $parts[1], 'ParameterValue', $parts[2])
        }}
    }}
    Remove-Item Env:{var}
}}
"""


def _names(prog_name):
    func = "".join(c if c.isalnum() else "_" for c in prog_name)
    var = "_" + "".join(c if c.isalnum() else "_" for c in prog_name).upper() + "_COMPLETE"
    return func, var


def registration_script(shell, prog_name):
    func, var = _names(prog_name)
    template = {
        "bash": _SCRIPT_BASH,
        "zsh": _SCRIPT_ZSH,
        "fish": _SCRIPT_FISH,
        "powershell": _SCRIPT_POWERSHELL,
    }[shell]
    return template.format(func=func, var=var, prog=prog_name)


def _as_items(result):
    items = []
    for entry in result or []:
        if isinstance(entry, CompletionItem):
            items.append(entry)
        elif isinstance(entry, str):
            items.append(CompletionItem(entry))
        else:
            value = getattr(entry, "value", None)
            if value is None:
                continue
            items.append(
                CompletionItem(
                    value,
                    help=getattr(entry, "help", None),
                    type=getattr(entry, "type", "plain") or "plain",
                )
            )
    return items


def _find_option(node, ctx, token):
    base = token.partition("=")[0]
    for p in node.get_params(ctx):
        if isinstance(p, Option) and base in p.all_names:
            return p
    return None


def _positional_tokens(node, ctx, args):
    """Return the args that are not option tokens (or option values)."""
    out = []
    skip = False
    for tok in args:
        if skip:
            skip = False
            continue
        if len(tok) > 1 and tok[0] in "-/+" and tok != "--":
            opt = _find_option(node, ctx, tok)
            if opt is not None and opt.nargs >= 1 and not opt.is_flag and not opt.is_count and "=" not in tok:
                skip = True
            continue
        out.append(tok)
    return out


def _complete_at(node, ctx, args, incomplete):
    prefix_chars = "-/+"
    # a value expected by the preceding option
    if args:
        prev = args[-1]
        if len(prev) > 1 and prev[0] in prefix_chars and "=" not in prev:
            opt = _find_option(node, ctx, prev)
            if opt is not None and not opt.is_flag and not opt.is_count:
                return _param_items(opt, ctx, incomplete)
    if incomplete[:1] and incomplete[0] in prefix_chars:
        items = []
        for p in node.get_params(ctx):
            if not isinstance(p, Option) or p.hidden:
                continue
            for name in p.all_names:
                if name.startswith(incomplete):
                    items.append(CompletionItem(name, help=p.help))
        return items
    if node.is_group:
        items = []
        for name in node.list_commands(ctx):
            sub = node.get_command(ctx, name)
            if sub is None or sub.hidden:
                continue
            if name.startswith(incomplete):
                items.append(CompletionItem(name, help=sub.get_short_help_str()))
        return items
    positional = _positional_tokens(node, ctx, args)
    arguments = [p for p in node.params if p.is_argument]
    index = len(positional)
    if index < len(arguments):
        return _param_items(arguments[index], ctx, incomplete)
    return []


def _param_items(param, ctx, incomplete):
    func = getattr(param, "shell_complete", None)
    if func is not None:
        return _as_items(func(ctx, param, incomplete))
    if param.type is not None:
        return _as_items(param.type.shell_complete(ctx, param, incomplete))
    return []


def get_completions(root, words, cword):
    """Return completion items for ``words`` with the word at ``cword`` incomplete."""
    if cword < len(words):
        incomplete = words[cword]
    else:
        incomplete = ""
    args = words[1:cword] if cword >= 1 else []
    ctx = Context(root, info_name=root.name or "cli")
    node = root
    while node.is_group:
        found = None
        i = 0
        while i < len(args):
            tok = args[i]
            if len(tok) > 1 and tok[0] in "-/+" and tok != "--":
                opt = _find_option(node, ctx, tok)
                if opt is not None and not opt.is_flag and not opt.is_count and "=" not in tok:
                    i += 2
                    continue
                i += 1
                continue
            sub = node.get_command(ctx, tok)
            if sub is not None:
                found = (i, sub)
                break
            i += 1
        if found is None:
            break
        idx, sub = found
        args = args[idx + 1 :]
        node = sub
        ctx = Context(node, info_name=node.name, parent=ctx)
    return _complete_at(node, ctx, args, incomplete)


def _format_items(items):
    lines = []
    for item in items:
        if item.type in ("file", "dir"):
            lines.append(f"{item.type}\t{item.value}\t")
        else:
            lines.append(f"plain\t{item.value}\t{item.help or ''}".replace("\n", " "))
    return lines


def run_instruction(root, instruction, prog_name):
    """Handle a ``_<PROG>_COMPLETE`` instruction. Returns False for unknown instructions."""
    shell, sep, action = instruction.rpartition("_")
    if not sep or shell not in SHELLS or action not in ("source", "complete"):
        return False
    if action == "source":
        sys.stdout.write(registration_script(shell, prog_name) + "\n")
        sys.stdout.flush()
        return True
    words = os.environ.get("COMP_WORDS", "").split(" ")
    try:
        cword = int(os.environ.get("COMP_CWORD", str(len(words))))
    except ValueError:
        cword = len(words)
    if shell == "fish":
        incomplete = os.environ.get("COMP_CWORD", "")
        if words and incomplete and words[-1] == incomplete:
            words = words[:-1]
        cword = len(words)
        words = words + [incomplete]
    items = get_completions(root, words, cword)
    for line in _format_items(items):
        sys.stdout.write(line + "\n")
    sys.stdout.flush()
    return True
