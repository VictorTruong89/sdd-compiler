"""Terminal helpers (Interface Contract §7, PRD FP-08 / FP-11)."""

import contextlib
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import time

from ._state import get_current_context
from .exceptions import Abort, BadParameter
from .param_types import STRING, open_file as _open_file, to_param_type, infer_type_from_default

# spec: N-000981..N-001012

_ANSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")

_COLORS = {
    "black": 30,
    "red": 31,
    "green": 32,
    "yellow": 33,
    "blue": 34,
    "magenta": 35,
    "cyan": 36,
    "white": 37,
    "reset": 39,
    "bright_black": 90,
    "bright_red": 91,
    "bright_green": 92,
    "bright_yellow": 93,
    "bright_blue": 94,
    "bright_magenta": 95,
    "bright_cyan": 96,
    "bright_white": 97,
}

_SWITCHES = [
    ("bold", 1, 22),
    ("dim", 2, 22),
    ("italic", 3, 23),
    ("underline", 4, 24),
    ("blink", 5, 25),
    ("reverse", 7, 27),
    ("strikethrough", 9, 29),
    ("overline", 53, 55),
]


def _interactive():
    """A session is interactive when stdin or stdout is a terminal (PRD glossary)."""
    try:
        return bool(sys.stdin and sys.stdin.isatty()) or bool(sys.stdout and sys.stdout.isatty())
    except (ValueError, AttributeError):
        return False


def _is_tty(stream):
    try:
        return bool(stream is not None and stream.isatty())
    except (ValueError, AttributeError):
        return False


def _current_color_flag():
    ctx = get_current_context(silent=True)
    return ctx.color if ctx is not None else None


def unstyle(text):
    """Remove ANSI escape sequences from ``text``."""
    return _ANSI_RE.sub("", text)


def _color_code(value, background=False):
    if isinstance(value, bool):
        raise TypeError(f"Invalid color {value!r}")
    if isinstance(value, int):
        if not 0 <= value <= 255:
            raise ValueError(f"Invalid color {value!r}: integer must be 0-255")
        return f"{48 if background else 38};5;{value}"
    if isinstance(value, str):
        key = value.lower()
        if key not in _COLORS:
            raise ValueError(f"Unknown color {value!r}")
        code = _COLORS[key]
        if key == "reset":
            return "0"
        if background:
            code = code - 30 + 40 if code < 90 else code - 90 + 100
        return str(code)
    if isinstance(value, (list, tuple)) and len(value) == 3:
        if not all(isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in value):
            raise ValueError(f"Invalid RGB color {value!r}")
        return f"{48 if background else 38};2;{value[0]};{value[1]};{value[2]}"
    raise ValueError(f"Invalid color {value!r}")


def style(
    text,
    fg=None,
    bg=None,
    bold=None,
    dim=None,
    underline=None,
    overline=None,
    italic=None,
    blink=None,
    reverse=None,
    strikethrough=None,
    reset=True,
):
    """Wrap ``text`` in ANSI SGR sequences."""
    bits = []
    if fg is not None:
        bits.append(_color_code(fg, background=False))
    if bg is not None:
        bits.append(_color_code(bg, background=True))
    values = {
        "bold": bold,
        "dim": dim,
        "underline": underline,
        "overline": overline,
        "italic": italic,
        "blink": blink,
        "reverse": reverse,
        "strikethrough": strikethrough,
    }
    for name, on_code, off_code in _SWITCHES:
        flag = values[name]
        if flag is not None:
            bits.append(str(on_code if flag else off_code))
    if not bits:
        return text if not reset else text
    prefix = "\x1b[" + ";".join(bits) + "m"
    suffix = "\x1b[0m" if reset else ""
    return f"{prefix}{text}{suffix}"


def _write_text(stream, text):
    try:
        stream.write(text)
    except UnicodeEncodeError:
        buffer = getattr(stream, "buffer", None)
        if buffer is None:
            stream.write(text.encode("utf-8", "replace").decode("ascii", "replace"))
        else:
            stream.flush()
            buffer.write(text.encode("utf-8", "replace"))
            buffer.flush()


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write ``message`` to stdout, stderr or ``file`` (FP-11)."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    keep = color if color is not None else _current_color_flag()
    if isinstance(message, bytes):
        buffer = getattr(file, "buffer", None)
        if buffer is not None:
            file.flush()
            buffer.write(message)
            if nl:
                buffer.write(b"\n")
            buffer.flush()
        else:
            file.write(message.decode("utf-8", "replace") + ("\n" if nl else ""))
        return
    text = str(message)
    if keep is None:
        keep = _is_tty(file)
    if not keep:
        text = unstyle(text)
    if nl:
        text += "\n"
    _write_text(file, text)
    try:
        file.flush()
    except (ValueError, OSError):
        pass


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None:
        message = style(str(message), **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


def _strip_if_needed(text, color):
    keep = color if color is not None else _current_color_flag()
    return text if keep else unstyle(text)


@contextlib.contextmanager
def get_pager_file(color=None):
    """Context manager yielding a writable text stream fed to the pager (FP-11)."""
    if _interactive() and os.environ.get("PAGER"):
        proc = subprocess.Popen(shlex.split(os.environ["PAGER"]), stdin=subprocess.PIPE, text=True)
        stream = proc.stdin

        class _Filtered:
            def write(self, s):
                stream.write(_strip_if_needed(s, color))
                stream.flush()

            def flush(self):
                stream.flush()

        try:
            yield _Filtered()
        finally:
            try:
                stream.close()
            except (BrokenPipeError, OSError):
                pass
            proc.wait()
    else:
        stdout = sys.stdout

        class _Plain:
            def write(self, s):
                _write_text(stdout, _strip_if_needed(s, color))

            def flush(self):
                try:
                    stdout.flush()
                except (ValueError, OSError):
                    pass

        yield _Plain()


def echo_via_pager(text_or_generator, color=None):
    """Write text through the pager when interactive, else to stdout (FP-11)."""
    if callable(text_or_generator):
        content = text_or_generator()
    else:
        content = text_or_generator
    if isinstance(content, str):
        chunks = [content]
    else:
        chunks = content
    with get_pager_file(color=color) as out:
        for chunk in chunks:
            out.write(str(chunk))
            out.flush()


class ProgressBar:
    """Progress bar object yielded by :func:`progressbar`."""

    def __init__(self, iterable, length, label, hidden):
        self._iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.pos = 0
        self.start = time.time()
        self._tty = (not hidden) and _is_tty(sys.stdout)
        if not hidden and not self._tty and self.label:
            sys.stdout.write(self.label + "\n")
            sys.stdout.flush()

    def _render(self):
        if not self._tty:
            return
        if self.length:
            frac = min(self.pos / self.length, 1.0)
            width = 30
            filled = int(width * frac)
            bar = "#" * filled + "-" * (width - filled)
            elapsed = time.time() - self.start
            eta = (elapsed / self.pos * (self.length - self.pos)) if self.pos else 0
            line = f"{self.label} [{bar}] {self.pos}/{self.length}  eta {int(eta)}s"
        else:
            line = f"{self.label} {self.pos}"
        sys.stdout.write("\r" + line)
        sys.stdout.flush()

    def update(self, n_steps):
        self.pos += n_steps
        self._render()

    def __iter__(self):
        if self._iterable is None:
            return
        for item in self._iterable:
            yield item
            self.update(1)

    def finish(self):
        if self._tty:
            sys.stdout.write("\n")
            sys.stdout.flush()


@contextlib.contextmanager
def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    """Context manager yielding a :class:`ProgressBar` (FP-11)."""
    bar = ProgressBar(iterable, length, label, hidden)
    try:
        yield bar
    finally:
        bar.finish()


_reading_prompt = {"active": False}


def _read_line(hide_input=False):
    stream = sys.stdin
    _reading_prompt["active"] = True
    try:
        line = stream.readline()
    finally:
        _reading_prompt["active"] = False
    if line == "" or line is None:
        raise EOFError()
    return line.rstrip("\r\n")


def _prompt_once(text, hide_input, err):
    out = sys.stderr if err else sys.stdout
    echo(text, nl=False, file=out, err=err, color=None)
    try:
        out.flush()
    except (ValueError, OSError):
        pass
    value = _read_line(hide_input)
    if not hide_input and not _is_tty(sys.stdin):
        # Piped / captured input is not echoed by the terminal; echo it so the transcript shows it.
        echo(value, file=out, err=err)
    elif hide_input:
        echo("", file=out, err=err)
    return value


def prompt(
    text,
    default=None,
    hide_input=False,
    confirmation_prompt=False,
    type=None,
    value_proc=None,
    prompt_suffix=": ",
    show_default=True,
    err=False,
    show_choices=True,
):
    """Ask for a value, converting it; re-asks on conversion failure (FP-08)."""
    if type is None:
        ptype = STRING if default is None else infer_type_from_default(default)
    else:
        ptype = to_param_type(type)
    if value_proc is None:
        def value_proc(v, _p=ptype):
            return _p.convert(v)

    suffix = prompt_suffix
    if default is not None and show_default:
        shown = default if not callable(default) else default()
        suffix = f" [{shown}]{prompt_suffix}"
    while True:
        value = _prompt_once(text + suffix, hide_input, err)
        if confirmation_prompt:
            second = _prompt_once("Repeat for confirmation" + prompt_suffix, hide_input, err)
            if second != value:
                echo("Error: The two entered values do not match.", err=True)
                continue
        if value == "" and default is not None:
            value = default() if callable(default) else default
            return value
        try:
            return value_proc(value)
        except BadParameter as exc:
            echo(f"Error: {exc.message}", err=True)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    """Yes/no question; returns a bool, or aborts when declined and ``abort`` is set (FP-08)."""
    if default is None:
        suffix = " [y/n]"
    elif default:
        suffix = " [Y/n]" if show_default else ""
    else:
        suffix = " [y/N]" if show_default else ""
    while True:
        answer = _prompt_once(text + suffix + prompt_suffix, False, err).strip().lower()
        if answer in ("y", "yes"):
            result = True
            break
        if answer in ("n", "no"):
            result = False
            break
        if answer == "" and default is not None:
            result = bool(default)
            break
    if not result and abort:
        raise Abort()
    return result


def getchar(echo=False):
    """Read one character from the terminal (FP-11)."""
    tty_fd = None
    try:
        import termios
        import tty

        try:
            tty_fd = os.open("/dev/tty", os.O_RDONLY)
        except OSError:
            tty_fd = None
        if tty_fd is not None:
            old = termios.tcgetattr(tty_fd)
            try:
                tty.setraw(tty_fd)
                ch = os.read(tty_fd, 1).decode("utf-8", "replace")
            finally:
                termios.tcsetattr(tty_fd, termios.TCSADRAIN, old)
                os.close(tty_fd)
        else:
            ch = sys.stdin.read(1)
    except ImportError:
        ch = sys.stdin.read(1)
    if ch == "":
        raise EOFError()
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    if echo:
        echo(ch, nl=False)
    return ch


def pause(info=None, err=False):
    """Print a message and wait for a key when interactive (FP-11)."""
    if info is None:
        info = "Press any key to continue..."
    echo(info, nl=False, err=err)
    if _interactive():
        try:
            getchar()
        except (EOFError, KeyboardInterrupt):
            pass
    echo("", err=err)


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Open an editor on text or on a file (FP-11)."""
    editor_cmd = editor or (env or {}).get("EDITOR") or os.environ.get("VISUAL") or os.environ.get("EDITOR")
    if not editor_cmd:
        editor_cmd = "notepad" if sys.platform == "win32" else "vi"
    if filename is not None:
        path = os.fspath(filename)
        existed_text = None
    else:
        fd, path = tempfile.mkstemp(suffix=extension)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            if text:
                f.write(text)
        existed_text = text or ""
    try:
        before = None
        if os.path.exists(path):
            with open(path, "rb") as f:
                before = f.read()
        argv = shlex.split(editor_cmd) + [path]
        subprocess.call(argv, env={**os.environ, **(env or {})})
        with open(path, "rb") as f:
            after = f.read()
        if filename is not None:
            return None
        if require_save and before is not None and after == before:
            return None
        if require_save and existed_text is not None and after.decode("utf-8", "replace") == existed_text and not text:
            return None
        return after.decode("utf-8", "replace")
    finally:
        if filename is None:
            try:
                os.remove(path)
            except OSError:
                pass


def launch(url, wait=False, locate=False):
    """Open ``url`` or a path with the default application (FP-11)."""
    if sys.platform == "darwin":
        argv = ["open"]
    elif sys.platform == "win32":
        try:
            os.startfile(url)  # type: ignore[attr-defined]
            return 0
        except OSError:
            return 1
    else:
        argv = ["xdg-open"]
    if locate and sys.platform == "darwin":
        argv.append("-R")
    argv.append(url)
    try:
        proc = subprocess.Popen(argv)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0


def clear():
    """Clear the screen when connected to a terminal (FP-11)."""
    if _is_tty(sys.stdout):
        sys.stdout.write("\033[2J\033[H")
        sys.stdout.flush()


def get_app_dir(app_name, roaming=True, force_posix=False):
    """Return the per-user config directory for ``app_name`` (FP-11)."""
    unix_name = "-".join(app_name.lower().split())
    home = os.path.expanduser("~")
    if force_posix and sys.platform != "win32":
        return os.path.join(home, "." + unix_name)
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    if sys.platform == "win32":
        base = os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming")
        return os.path.join(base, app_name)
    xdg = os.environ.get("XDG_CONFIG_HOME")
    base = xdg if xdg else os.path.join(home, ".config")
    return os.path.join(base, unix_name)


def format_filename(filename, shorten=False):
    """Return a printable, strictly UTF-8-encodable text form of a filename (FP-09)."""
    if hasattr(filename, "__fspath__"):
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        text = os.fsdecode(filename)
    else:
        text = str(filename)
    if shorten:
        text = os.path.basename(text.rstrip("/\\")) or text
    return text.encode("utf-8", "backslashreplace").decode("utf-8")


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file or standard stream (FP-09 / FP-11); ``-`` means standard stream."""
    return _open_file(filename, mode, encoding, errors, lazy=lazy, atomic=atomic)


def get_terminal_width(default=80):
    try:
        return shutil.get_terminal_size((default, 24)).columns
    except OSError:
        return default
