"""Exception classes used by Optlyn.

Exit statuses (spec: Interface Contract §2):
  * ``UsageError`` and subclasses -> 2
  * ``Abort`` and other ``OptlynError`` -> 1
  * ``Exit(n)`` -> n (author clean stop)
"""

import sys


class OptlynError(Exception):
    """Base class for errors Optlyn reports to the user (general error, exit 1)."""

    exit_code = 1

    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def format_message(self):
        return self.message

    def show(self, file=None):
        from .termui import echo

        echo(f"Error: {self.format_message()}", file=file or sys.stderr, err=True)


class FileError(OptlynError):
    """A file could not be opened at first I/O (general error, exit 1)."""

    def __init__(self, filename, hint=""):
        self.filename = filename
        self.hint = hint
        message = f"Could not open file {filename!r}"
        if hint:
            message += f": {hint}"
        super().__init__(message + ".")


class UsageError(OptlynError):
    """Incorrect command-line usage (exit 2)."""

    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.ctx = ctx

    def show(self, file=None):
        from .termui import echo

        file = file or sys.stderr
        if self.ctx is not None:
            prog = self.ctx.command_path
            hint_name = (self.ctx.help_option_names or ["--help"])[0]
            echo(self.ctx.get_usage(), file=file, err=True)
            echo(f"Try '{prog} {hint_name}' for help.", file=file, err=True)
            echo("", file=file, err=True)
        echo(f"Error: {self.format_message()}", file=file, err=True)


class NoArgsIsHelp(UsageError):
    """Help page shown because no arguments were given (usage failure, exit 2)."""

    def show(self, file=None):
        from .termui import echo

        file = file or sys.stderr
        if self.ctx is not None:
            echo(self.ctx.get_help(), file=file, err=True)


class BadParameter(UsageError):
    """A parameter value was refused (conversion failure or callback refusal)."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        if hint:
            return f"Invalid value for {hint}: {self.message}"
        return self.message


class MissingParameter(BadParameter):
    """A required parameter was not supplied from any source."""

    def __init__(self, message=None, ctx=None, param=None, param_hint=None):
        super().__init__(message or "", ctx=ctx, param=param, param_hint=param_hint)

    def format_message(self):
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        kind = "parameter"
        if self.param is not None:
            kind = "argument" if self.param.is_argument else "option"
        return f"Missing {kind} {hint}." if hint else "Missing parameter."


class NoSuchOption(UsageError):
    """An unknown option was given."""

    def __init__(self, option_name, message=None, ctx=None):
        self.option_name = option_name
        super().__init__(message or f"No such option: {option_name}", ctx)


class BadOptionUsage(UsageError):
    """An option was used incorrectly (for example a missing value)."""


class BadArgumentUsage(UsageError):
    """An argument was used incorrectly."""


class Abort(RuntimeError):
    """Abort the program (exit 1), e.g. declined confirmation or EOF on a prompt."""

    exit_code = 1


class Exit(RuntimeError):
    """Author clean stop with an exit status."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code
