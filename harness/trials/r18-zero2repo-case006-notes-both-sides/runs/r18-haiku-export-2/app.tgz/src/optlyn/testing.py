"""In-process runner: ``optlyn.testing.CliRunner`` (Interface Contract §9, PRD FP-14)."""

import contextlib
import io
import os
import sys
import tempfile


class _Tap(io.BytesIO):
    """BytesIO that also records every write into a shared combined log (write order)."""

    def __init__(self, combined):
        super().__init__()
        self._combined = combined

    def write(self, data):
        self._combined.append(bytes(data))
        return super().write(data)


class _EchoingStdin(io.TextIOWrapper):
    """Stdin that echoes every line read when the runner asks for it (echo_stdin)."""

    def __init__(self, data, encoding, echo_target):
        super().__init__(io.BytesIO(data), encoding=encoding, newline="")
        self._echo_target = echo_target

    def readline(self, *args):
        from . import termui

        line = super().readline(*args)
        if line and self._echo_target is not None and not termui._reading_prompt["active"]:
            self._echo_target.write(line)
        return line


class Result:
    """Outcome of :meth:`CliRunner.invoke`."""

    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value, exit_code, exception, exc_info):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self):
        return self.output_bytes.decode(self.runner.charset, "replace")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    """Invoke a command in-process with argument tokens and capture its output."""

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        # spec: N-001038..N-001043
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        else:
            data = bytes(input)
        combined = []
        stdout_buf = _Tap(combined)
        stderr_buf = _Tap(combined)

        merged_env = dict(self.env)
        merged_env.update(env or {})
        saved_env = {}
        for key, value in merged_env.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)
        try:
            if self.capture == "fd":
                yield from self._fd_streams(data, stdout_buf, stderr_buf, combined)
            else:
                stdout_text = io.TextIOWrapper(stdout_buf, encoding=self.charset, errors="replace", write_through=True)
                stderr_text = io.TextIOWrapper(stderr_buf, encoding=self.charset, errors="replace", write_through=True)
                stdin_text = _EchoingStdin(data, self.charset, stdout_text if self.echo_stdin else None)
                saved = (sys.stdin, sys.stdout, sys.stderr)
                sys.stdin, sys.stdout, sys.stderr = stdin_text, stdout_text, stderr_text
                try:
                    yield stdout_buf, stderr_buf, combined
                finally:
                    stdout_text.flush()
                    stderr_text.flush()
                    sys.stdin, sys.stdout, sys.stderr = saved
                    stdout_text.detach()
                    stderr_text.detach()
        finally:
            for key, old in saved_env.items():
                if old is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = old

    def _fd_streams(self, data, stdout_buf, stderr_buf, combined):
        """File-descriptor capture: descriptors 1 and 2 are redirected to temporary files."""
        out_file = tempfile.TemporaryFile()
        err_file = tempfile.TemporaryFile()
        sys.stdout.flush()
        sys.stderr.flush()
        saved_out, saved_err = os.dup(1), os.dup(2)
        os.dup2(out_file.fileno(), 1)
        os.dup2(err_file.fileno(), 2)
        stdout_text = io.TextIOWrapper(io.FileIO(1, "w", closefd=False), encoding=self.charset, errors="replace", write_through=True)
        stderr_text = io.TextIOWrapper(io.FileIO(2, "w", closefd=False), encoding=self.charset, errors="replace", write_through=True)
        stdin_text = _EchoingStdin(data, self.charset, stdout_text if self.echo_stdin else None)
        saved = (sys.stdin, sys.stdout, sys.stderr)
        sys.stdin, sys.stdout, sys.stderr = stdin_text, stdout_text, stderr_text
        try:
            yield stdout_buf, stderr_buf, combined
        finally:
            stdout_text.flush()
            stderr_text.flush()
            sys.stdin, sys.stdout, sys.stderr = saved
            stdout_text.detach()
            stderr_text.detach()
            os.dup2(saved_out, 1)
            os.dup2(saved_err, 2)
            os.close(saved_out)
            os.close(saved_err)
            out_file.seek(0)
            err_file.seek(0)
            out_data, err_data = out_file.read(), err_file.read()
            out_file.close()
            err_file.close()
            stdout_buf.write(out_data)
            stderr_buf.write(err_data)

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        """Invoke ``cli`` with the argument token list ``args``."""
        # spec: N-001038..N-001043
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if args is None:
            args = []
        elif isinstance(args, str):
            import shlex

            args = shlex.split(args)
        standalone = extra.pop("standalone_mode", True)
        extra.setdefault("prog_name", cli.name or "cli")
        extra.setdefault("color", color)
        exit_code = 0
        exception = None
        exc_info = None
        return_value = None
        with self.isolation(input=input, env=env, color=color) as (stdout_buf, stderr_buf, combined):
            try:
                return_value = cli.main(args=list(args), standalone_mode=standalone, **extra)
            except SystemExit as exc:
                code = exc.code
                if code is None:
                    exit_code = 0
                elif isinstance(code, int):
                    exit_code = code
                else:
                    print(code, file=sys.stderr)
                    exit_code = 1
                if exit_code != 0:
                    exception = exc
                exc_info = sys.exc_info()
            except Exception as exc:
                if not catch_exceptions:
                    raise
                exception = exc
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                sys.stdout.flush()
                sys.stderr.flush()
        stdout_bytes = stdout_buf.getvalue()
        stderr_bytes = stderr_buf.getvalue()
        output_bytes = b"".join(combined)
        return Result(
            self,
            stdout_bytes=stdout_bytes,
            stderr_bytes=stderr_bytes,
            output_bytes=output_bytes,
            return_value=return_value,
            exit_code=exit_code,
            exception=exception,
            exc_info=exc_info,
        )

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Change into a new empty directory; the directory is left in place (FP-14)."""
        # spec: N-001044 and FP-14 isolated filesystem
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
