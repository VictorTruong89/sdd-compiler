"""Parameter types and conversion (Interface Contract §5, PRD FP-05, FP-09)."""

import datetime as _dt
import enum
import io
import os
import pathlib
import sys
import tempfile
import uuid as _uuid

from .exceptions import BadParameter, FileError

# spec: N-000936..N-000949 (Interface Contract §5, parameter types)


class ParamType:
    """Base class for parameter types. Subclasses set ``name`` and implement ``convert``."""

    name = None
    is_path = False

    def get_metavar(self, param=None):
        return (self.name or "text").upper()

    def arity(self):
        return 1

    def convert(self, value, param=None, ctx=None):
        return value

    def __call__(self, value, param=None, ctx=None):
        return self.convert(value, param, ctx)

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def split_envvar_value(self, value):
        return value.split()

    def shell_complete(self, ctx, param, incomplete):
        return []


def _ctx_normalize(ctx, text):
    func = getattr(ctx, "token_normalize_func", None) if ctx is not None else None
    return func(text) if func else text


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            return value.decode("utf-8", "surrogateescape")
        return value if isinstance(value, str) else str(value)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, int) and not isinstance(value, bool):
            return value
        try:
            return int(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        try:
            return float(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()

_PY_TYPE_MAP = {
    str: STRING,
    int: INT,
    float: FLOAT,
    bool: BOOL,
    _uuid.UUID: UUID,
}


class FuncParamType(ParamType):
    """Wraps a conversion function ``f(token) -> value`` that refuses with ``ValueError``."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text")

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except ValueError as exc:
            self.fail(str(exc) or f"{value!r} is not valid.", param, ctx)


def to_param_type(obj):
    """Coerce a ``type=`` argument into a ``ParamType`` instance."""
    if obj is None:
        return None
    if isinstance(obj, ParamType):
        return obj
    if isinstance(obj, Tuple):
        return obj
    if isinstance(obj, type):
        if issubclass(obj, ParamType):
            return obj()
        if obj in _PY_TYPE_MAP:
            return _PY_TYPE_MAP[obj]
        return FuncParamType(obj)
    if callable(obj):
        return FuncParamType(obj)
    raise TypeError(f"Unsupported parameter type: {obj!r}")


def infer_type_from_default(default):
    """Infer a built-in type from a default value (FP-05)."""
    if isinstance(default, bool):
        return BOOL
    if isinstance(default, int):
        return INT
    if isinstance(default, float):
        return FLOAT
    if isinstance(default, _uuid.UUID):
        return UUID
    if isinstance(default, (list, tuple)) and default:
        return infer_type_from_default(default[0])
    return STRING


class Choice(ParamType):
    """A closed list of allowed values, or the members of an enumeration."""

    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self._enum = choices
            self.choices = list(choices)
        else:
            self._enum = None
            self.choices = list(choices)
        self.case_sensitive = case_sensitive

    def _name_of(self, choice):
        if isinstance(choice, enum.Enum):
            return choice.name
        return str(choice)

    def get_metavar(self, param=None):
        return "[" + "|".join(self._name_of(c) for c in self.choices) + "]"

    def convert(self, value, param=None, ctx=None):
        for choice in self.choices:
            if value is choice:
                return choice
        if self._enum is not None and isinstance(value, self._enum):
            return value
        text = value if isinstance(value, str) else str(value)
        text = _ctx_normalize(ctx, text)
        for choice in self.choices:
            name = _ctx_normalize(ctx, self._name_of(choice))
            if text == name or (not self.case_sensitive and text.casefold() == name.casefold()):
                return choice
        choices_str = ", ".join(repr(self._name_of(c)) for c in self.choices)
        self.fail(f"{text!r} is not {choices_str}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        from .core import CompletionItem  # local import to avoid cycle

        out = []
        for choice in self.choices:
            name = self._name_of(choice)
            if name.startswith(incomplete):
                out.append(CompletionItem(name))
        return out


DEFAULT_DATETIME_FORMATS = [
    "%Y-%m-%d",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M:%S",
]


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(DEFAULT_DATETIME_FORMATS)

    def get_metavar(self, param=None):
        return "DATETIME"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        text = str(value).strip()
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(text, fmt)
            except ValueError:
                continue
        self.fail(
            f"{value!r} does not match the formats {', '.join(repr(f) for f in self.formats)}.",
            param,
            ctx,
        )


class IntRange(IntParamType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if min_open and min is None:
            raise ValueError("min_open requires min")
        if max_open and max is None:
            raise ValueError("max_open requires max")
        self.min, self.max = min, max
        self.min_open, self.max_open = min_open, max_open
        self.clamp = clamp

    def get_metavar(self, param=None):
        return "INTEGER RANGE"

    def _range_text(self):
        lo = "" if self.min is None else str(self.min)
        hi = "" if self.max is None else str(self.max)
        lb = "(" if self.min_open else "["
        rb = ")" if self.max_open else "]"
        return f"{lb}{lo}, {hi}{rb}"

    def convert(self, value, param=None, ctx=None):
        v = super().convert(value, param, ctx)
        if self.clamp:
            if self.min is not None and (v < self.min or (self.min_open and v == self.min)):
                v = self.min + 1 if self.min_open else self.min
            if self.max is not None and (v > self.max or (self.max_open and v == self.max)):
                v = self.max - 1 if self.max_open else self.max
            return v
        if self.min is not None and (v < self.min or (self.min_open and v == self.min)):
            self.fail(f"{v} is not in the valid range of {self._range_text()}.", param, ctx)
        if self.max is not None and (v > self.max or (self.max_open and v == self.max)):
            self.fail(f"{v} is not in the valid range of {self._range_text()}.", param, ctx)
        return v


class FloatRange(FloatParamType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if min_open and min is None:
            raise ValueError("min_open requires min")
        if max_open and max is None:
            raise ValueError("max_open requires max")
        if clamp and (min_open or max_open):
            raise ValueError("clamp is not allowed when a bound is open")
        self.min, self.max = min, max
        self.min_open, self.max_open = min_open, max_open
        self.clamp = clamp

    def get_metavar(self, param=None):
        return "FLOAT RANGE"

    def _range_text(self):
        lo = "" if self.min is None else str(self.min)
        hi = "" if self.max is None else str(self.max)
        lb = "(" if self.min_open else "["
        rb = ")" if self.max_open else "]"
        return f"{lb}{lo}, {hi}{rb}"

    def convert(self, value, param=None, ctx=None):
        v = super().convert(value, param, ctx)
        if self.clamp:
            if self.min is not None and v < self.min:
                v = self.min
            if self.max is not None and v > self.max:
                v = self.max
            return v
        if self.min is not None and (v < self.min or (self.min_open and v == self.min)):
            self.fail(f"{v} is not in the valid range of {self._range_text()}.", param, ctx)
        if self.max is not None and (v > self.max or (self.max_open and v == self.max)):
            self.fail(f"{v} is not in the valid range of {self._range_text()}.", param, ctx)
        return v


class Tuple(ParamType):
    """A fixed-length product of inner types."""

    name = "tuple"

    def __init__(self, types):
        self.types = [to_param_type(t) for t in types]

    def arity(self):
        return len(self.types)

    def get_metavar(self, param=None):
        return " ".join(t.get_metavar(param) for t in self.types)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, str) or not hasattr(value, "__len__"):
            self.fail(f"{value!r} is not a sequence of {len(self.types)} values.", param, ctx)
        if len(value) != len(self.types):
            self.fail(f"Expected {len(self.types)} values, got {len(value)}.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))


# ---------------------------------------------------------------------------
# File handling (FP-09)
# ---------------------------------------------------------------------------


class _NonClosingStream:
    """Proxy around a standard stream whose ``close`` only flushes it (FP-09)."""

    def __init__(self, stream):
        self._stream = stream

    def close(self):
        try:
            self._stream.flush()
        except (OSError, ValueError):
            pass

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __iter__(self):
        return iter(self._stream)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()


class LazyFile:
    """Opens its target on first I/O (FP-09 lazy write mode)."""

    def __init__(self, filename, mode, encoding=None, errors="strict", atomic=False):
        self.filename = filename
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None

    def _open(self):
        if self._f is None:
            self._f = _open_real(self.filename, self.mode, self.encoding, self.errors, self.atomic)
        return self._f

    def __getattr__(self, name):
        if name.startswith("_") and name not in ("_f",):
            raise AttributeError(name)
        return getattr(self._open(), name)

    def write(self, data):
        return self._open().write(data)

    def read(self, *args):
        return self._open().read(*args)

    def readline(self, *args):
        return self._open().readline(*args)

    def __iter__(self):
        return iter(self._open())

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def close(self):
        if self._f is not None:
            self._f.close()
            self._f = None


class _AtomicWriter:
    """Writes to a sibling temporary file and replaces the target on close."""

    def __init__(self, filename, mode, encoding, errors):
        self._target = os.path.abspath(filename)
        directory = os.path.dirname(self._target)
        fd, self._tmp = tempfile.mkstemp(dir=directory, prefix=".optlyn-", suffix=".tmp")
        binary = "b" in mode
        raw = os.fdopen(fd, "wb")
        self._f = raw if binary else io.TextIOWrapper(raw, encoding=encoding or "utf-8", errors=errors)
        self._closed = False

    def __getattr__(self, name):
        return getattr(self._f, name)

    def close(self):
        if self._closed:
            return
        self._closed = True
        self._f.close()
        os.replace(self._tmp, self._target)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()


def _open_real(filename, mode, encoding, errors, atomic):
    try:
        if atomic:
            return _AtomicWriter(filename, mode, encoding, errors)
        if "b" in mode:
            return open(filename, mode)
        return open(filename, mode, encoding=encoding, errors=errors)
    except OSError as exc:
        raise FileError(filename, exc.strerror or str(exc)) from exc


def _std_stream(mode, encoding, errors):
    writing = "w" in mode or "a" in mode
    base = sys.stdout if writing else sys.stdin
    if "b" in mode:
        stream = getattr(base, "buffer", base)
    elif encoding:
        buffer = getattr(base, "buffer", None)
        if buffer is None:
            stream = base
        else:
            stream = io.TextIOWrapper(buffer, encoding=encoding, errors=errors, line_buffering=True)
    else:
        stream = base
    return _NonClosingStream(stream)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=None, atomic=False, ctx=None):
    """Open ``filename`` (``-`` means standard input or output) per FP-09.

    Read-mode files and standard streams open immediately. Write-mode files
    open on first I/O unless ``lazy`` is false.
    """
    if hasattr(filename, "read") or hasattr(filename, "write"):
        return filename
    filename = os.fspath(filename) if not isinstance(filename, str) else filename
    writing = "w" in mode or "a" in mode or "x" in mode
    if filename == "-":
        return _std_stream(mode, encoding, errors)
    if lazy is None:
        lazy = writing
    if lazy and writing:
        f = LazyFile(filename, mode, encoding, errors, atomic)
    else:
        f = _open_real(filename, mode, encoding, errors, atomic)
    if ctx is not None and hasattr(f, "close"):
        ctx.call_on_close(f.close)
    return f


class File(ParamType):
    """Opens a file; the value delivered is an open file object."""

    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"Unsupported file mode {mode!r}")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def get_metavar(self, param=None):
        return "FILENAME"

    def split_envvar_value(self, value):
        return value.split(os.pathsep)

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        try:
            return open_file(
                value,
                self.mode,
                self.encoding,
                self.errors,
                lazy=self.lazy,
                atomic=self.atomic,
                ctx=ctx,
            )
        except FileError as exc:
            self.fail(f"'{value}': {exc.hint or 'could not be opened'}", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        from .core import CompletionItem

        return [CompletionItem(incomplete, type="file")]


class Path(ParamType):
    """Validates a filesystem path and delivers the path (not an open file)."""

    name = "path"
    is_path = True

    def __init__(
        self,
        exists=False,
        file_okay=True,
        dir_okay=True,
        writable=False,
        readable=True,
        resolve_path=False,
        allow_dash=False,
        path_type=None,
        executable=False,
    ):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def get_metavar(self, param=None):
        return "PATH"

    def split_envvar_value(self, value):
        return value.split(os.pathsep)

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        text = os.fspath(value)
        if self.allow_dash and text == "-":
            return "-"
        if self.resolve_path:
            text = os.path.realpath(text)
        exists = os.path.exists(text)
        if not exists:
            if self.exists:
                self.fail(f"{text!r} does not exist.", param, ctx)
        else:
            if not self.file_okay and os.path.isfile(text):
                self.fail(f"{text!r} is a file.", param, ctx)
            if not self.dir_okay and os.path.isdir(text):
                self.fail(f"{text!r} is a directory.", param, ctx)
            if self.readable and not os.access(text, os.R_OK):
                self.fail(f"{text!r} is not readable.", param, ctx)
            if self.writable and not os.access(text, os.W_OK):
                self.fail(f"{text!r} is not writable.", param, ctx)
            if self.executable and not os.access(text, os.X_OK):
                self.fail(f"{text!r} is not executable.", param, ctx)
        if self.path_type is not None and issubclass(self.path_type, pathlib.PurePath):
            return self.path_type(text)
        return text

    def shell_complete(self, ctx, param, incomplete):
        from .core import CompletionItem

        kind = "dir" if (not self.file_okay and self.dir_okay) else "file"
        return [CompletionItem(incomplete, type=kind)]


# Public short names for the built-in parameter types.
__all__ = [
    "ParamType",
    "STRING",
    "INT",
    "FLOAT",
    "BOOL",
    "UUID",
    "UNPROCESSED",
    "Choice",
    "DateTime",
    "IntRange",
    "FloatRange",
    "Tuple",
    "File",
    "Path",
    "open_file",
    "to_param_type",
    "infer_type_from_default",
]
