"""Text wrapping and short-help helpers (Interface Contract §1, PRD FP-02, FP-11)."""

import re
import textwrap

# spec: N-001044-era helper; FP-11 "Text wrapping accepts any string without failing."
DEFAULT_CONTENT_WIDTH = 80
MAX_CONTENT_WIDTH_LIMIT = 100


def wrap_text(
    text,
    width=78,
    initial_indent="",
    subsequent_indent="",
    preserve_paragraphs=False,
):
    """Rewrap ``text`` to ``width`` columns.

    Single newlines inside a paragraph are not preserved. A paragraph whose
    first line is only a backspace character keeps its line breaks, and the
    backspace line itself is removed.
    """
    text = "" if text is None else str(text)
    if not text.strip():
        return ""
    width = max(int(width), 1)
    out = []
    for para in re.split(r"\n[ \t]*\n", text.strip("\n")):
        lines = para.split("\n")
        if lines and lines[0].strip() == "\b":
            body = lines[1:]
            out.append("\n".join(subsequent_indent + line.rstrip() for line in body).rstrip())
            continue
        joined = " ".join(line.strip() for line in lines if line.strip())
        if not joined:
            continue
        wrapper = textwrap.TextWrapper(
            width=width,
            initial_indent=initial_indent,
            subsequent_indent=subsequent_indent,
            break_long_words=False,
            break_on_hyphens=False,
        )
        out.append(wrapper.fill(joined))
    return "\n\n".join(out)


def make_default_short_help(text, max_length=45):
    """Return the first sentence of ``text``, cut to ``max_length`` with ``...``."""
    if not text:
        return ""
    flat = " ".join(str(text).split())
    match = re.match(r"(.*?[.!?])(\s|$)", flat)
    sentence = match.group(1) if match else flat
    if len(sentence) > max_length:
        sentence = sentence[: max(max_length - 3, 0)].rstrip() + "..."
    return sentence


def clean_help_text(text):
    """Apply the form-feed rule: text from the first form feed onward is omitted."""
    if not text:
        return ""
    import inspect

    text = text.split("\f", 1)[0]
    return inspect.cleandoc(text)
