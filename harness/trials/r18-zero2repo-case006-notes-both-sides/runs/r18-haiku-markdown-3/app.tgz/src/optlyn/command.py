"""Commands, groups, the argument parser, and standalone program handling."""

from __future__ import annotations

import os
import sys
import typing as t

from .context import Context, ParameterSource
from .exceptions import (
    Abort,
    BadParameter,
    Exit,
    MissingCommand,
    MissingParameter,
    NoSuchCommand,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .formatting import HelpFormatter, clean_help, short_help_text
from .params import MISSING, NOVALUE, Argument, Option, Parameter
from .termui import echo

_CHAIN = object()


class _NoArgsHelp(UsageError):
    """No-arguments help: usage-class failure whose help page is the report."""

    def __init__(self, ctx: Context) -> None:
        super().__init__("no arguments given", ctx)

    def show(self, file=None) -> None:
        file = file or sys.stderr
        file.write(HelpFormatter().format_help(self.ctx))


class BadOptionUsage(UsageError):
    pass


class BadArgumentUsage(UsageError):
    pass


def _print_help(ctx: Context, file) -> None:
    width = ctx.terminal_width
    max_w = ctx.max_content_width or 80
    file.write(HelpFormatter(width=width, max_width=max_w).format_help(ctx))


def _complete_var_name(prog_name: str) -> str:
    base = os.path.basename(prog_name)
    return "_" + base.upper().replace("-", "_") + "_COMPLETE"


def _help_pseudo_param(names: t.Sequence[str]) -> Option:
    return Option(
        list(names),
        is_flag=True,
        is_eager=True,
        expose_value=False,
        help="Show this message and exit.",
    )


class Command:
    """A leaf command: parameters and a callback."""

    allow_extra_args = False
    ignore_unknown_options = False
    allow_interspersed_args = True

    def __init__(
        self,
        name: t.Optional[str] = None,
        callback=None,
        params: t.Optional[t.List[Parameter]] = None,
        context_settings: t.Optional[dict] = None,
        help: t.Optional[str] = None,
        short_help: t.Optional[str] = None,
        epilog: t.Optional[str] = None,
        options_metavar: t.Optional[str] = "[OPTIONS]",
        add_help_option: bool = True,
        no_args_is_help: bool = False,
        deprecated=False,
        hidden: bool = False,
        **extra: t.Any,
    ) -> None:
        self.name = name
        self.callback = callback
        self.params: t.List[Parameter] = list(params or [])
        self.context_settings = dict(context_settings or {})
        self.help = help
        self.short_help = short_help
        self.epilog = epilog
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.deprecated = deprecated
        self.hidden = hidden
        self.extra = extra
        for key in ("allow_extra_args", "ignore_unknown_options", "allow_interspersed_args"):
            if key in extra:
                setattr(self, key, extra.pop(key))

    # --- help text -----------------------------------------------------------

    def get_help_text(self) -> str:
        if self.help is not None:
            return self.help.replace("\f", "").strip("\n")
        doc = getattr(self.callback, "__doc__", None) if self.callback else None
        return clean_help(doc)

    def get_short_help_str(self) -> str:
        if self.short_help is not None:
            return self.short_help
        return short_help_text(self.get_help_text())

    def get_arguments(self) -> t.List[Argument]:
        return [p for p in self.params if isinstance(p, Argument) and not p.hidden]

    def get_params(self, ctx: Context) -> t.List[Parameter]:
        params = list(self.params)
        names = self._auto_help_names(ctx)
        if names:
            params.append(_help_pseudo_param(names))
        return params

    def _auto_help_names(self, ctx: Context) -> t.List[str]:
        if not self.add_help_option:
            return []
        declared = {n for p in self.params if isinstance(p, Option) for n in p.all_flag_names}
        return [n for n in ctx.help_option_names if n not in declared]

    # --- parsing ---------------------------------------------------------------

    def _norm(self, ctx: Context, token: str) -> str:
        func = ctx.token_normalize_func
        return func(token) if func is not None else token

    def _flag_map(self, ctx: Context) -> dict:
        m = {}
        for p in self.params:
            if isinstance(p, Option):
                for n in p.opts:
                    m[n] = (p, False)
                for n in p.secondary_opts:
                    m[n] = (p, True)
        return m

    def _parse(self, ctx: Context, args: t.Sequence[str]):
        """Return (occurrences, eager_order, leftover) where leftover is a list of (token, literal)."""
        occs: t.Dict[Parameter, list] = {}
        eager: list = []
        leftover: t.List[t.Tuple[str, bool]] = []
        flagmap = self._flag_map(ctx)
        help_names = set(self._auto_help_names(ctx))
        help_names_norm = {self._norm(ctx, n) for n in help_names}
        prefixes = {"-"} | {n[0] for n in flagmap if n}
        interspersed = ctx.allow_interspersed_args
        ignore_unknown = ctx.ignore_unknown_options
        n_args = len(args)
        i = 0

        def add(param, raw):
            occs.setdefault(param, []).append(raw)
            if param.is_eager and param not in eager:
                eager.append(param)

        def take_value(param, inline, tok):
            nonlocal i
            need = param.nargs
            vals = [] if inline is None else [inline]
            while len(vals) < need and i < n_args:
                vals.append(args[i])
                i += 1
            if not vals:
                if param.prompt is not None:
                    return NOVALUE
                raise BadOptionUsage(f"option {tok!r} requires an argument.", ctx)
            if len(vals) < need:
                raise BadOptionUsage(f"option {tok!r} requires {need} values.", ctx)
            if need == 1:
                return vals[0]
            return tuple(vals)

        while i < n_args:
            tok = args[i]
            i += 1
            if tok == "--":
                leftover.extend((a, True) for a in args[i:])
                break
            is_opt = len(tok) > 1 and tok[0] in prefixes
            if not is_opt:
                if not interspersed:
                    leftover.append((tok, False))
                    leftover.extend((a, False) for a in args[i:])
                    break
                leftover.append((tok, False))
                continue

            key = self._norm(ctx, tok)
            hit = None
            name = tok
            inline = None
            for candidate in (tok, key):
                if candidate in flagmap:
                    hit = flagmap[candidate]
                    name = candidate
                    break
            if hit is None and "=" in tok:
                head, _, rest = tok.partition("=")
                for candidate in (head, self._norm(ctx, head)):
                    if candidate in flagmap:
                        hit = flagmap[candidate]
                        name = candidate
                        inline = rest
                        break
            if hit is None and (key in help_names_norm or tok in help_names):
                if "help" not in eager:
                    eager.append("help")
                continue
            if hit is not None:
                param, secondary = hit
                if param.is_flag:
                    if inline is not None:
                        raise BadOptionUsage(f"option {name!r} does not take a value.", ctx)
                    add(param, False if secondary else param.flag_value)
                elif param.is_count:
                    add(param, 1)
                else:
                    add(param, take_value(param, inline, name))
                continue
            if len(tok) > 2 and tok[1] in prefixes:
                # Unknown long option.
                if ignore_unknown:
                    leftover.append((tok, False))
                    continue
                raise NoSuchOption(tok.partition("=")[0], ctx)
            # Short option stack: each character is a flag.
            p0 = tok[0]
            j = 1
            while j < len(tok):
                sname = p0 + tok[j]
                skey = self._norm(ctx, sname)
                if sname in flagmap or skey in flagmap:
                    param, secondary = flagmap.get(sname) or flagmap[skey]
                    if param.is_flag:
                        add(param, False if secondary else param.flag_value)
                        j += 1
                        continue
                    if param.is_count:
                        add(param, 1)
                        j += 1
                        continue
                    rest = tok[j + 1:]
                    add(param, take_value(param, rest if rest else None, sname))
                    break
                if sname in help_names or skey in help_names_norm:
                    if "help" not in eager:
                        eager.append("help")
                    j += 1
                    continue
                if ignore_unknown:
                    leftover.append((tok, False))
                    break
                raise NoSuchOption(sname, ctx)
        return occs, eager, leftover

    def _bind_arguments(self, ctx: Context, leftover, occs):
        """Bind positional tokens to arguments in order; return the unbound tokens."""
        args = [p for p in self.params if isinstance(p, Argument)]
        tokens = list(leftover)
        pos = 0
        for idx, a in enumerate(args):
            after = sum(x.nargs for x in args[idx + 1:] if x.nargs > 0)
            if a.nargs == -1:
                take = max(0, len(tokens) - pos - after)
                chunk = tokens[pos:pos + take]
                pos += take
                if chunk:
                    occs[a] = [tuple(tok for tok, _ in chunk)]
                continue
            avail = len(tokens) - pos
            if avail <= 0:
                continue
            if avail < a.nargs:
                if a.nargs == 1:
                    continue
                raise BadArgumentUsage(
                    f"argument {a.name!r} takes {a.nargs} values but only {avail} were given.",
                    ctx,
                )
            chunk = tokens[pos:pos + a.nargs]
            pos += a.nargs
            if a.nargs == 1:
                occs[a] = [chunk[0][0]]
            else:
                occs[a] = [tuple(tok for tok, _ in chunk)]
        return tokens[pos:]

    # --- context creation --------------------------------------------------------

    def make_context(self, info_name, args, parent: t.Optional[Context] = None, **extra):
        settings = dict(self.context_settings)
        settings.update(extra)
        default_map = settings.pop("default_map", None)
        if parent is not None:
            pm = parent.default_map
            default_map = pm.get(info_name) if isinstance(pm, dict) else None
            if default_map is None and "default_map" in self.context_settings:
                default_map = self.context_settings["default_map"]
        ctx = Context(self, parent=parent, info_name=info_name, default_map=default_map, **settings)
        ctx._had_args = bool(args)
        with ctx:
            occs, eager, leftover = self._parse(ctx, list(args))
            leftover = self._bind_arguments(ctx, leftover, occs)
            self._run_eager(ctx, occs, eager)
            self._process(ctx, occs, leftover)
        return ctx

    def _run_eager(self, ctx, occs, eager):
        for item in eager:
            if item == "help":
                _print_help(ctx, sys.stdout)
                raise Exit(0)
            value, _src = item.resolve(ctx, occs.get(item, []))
            if value is MISSING:
                value = None
            value = item.process(ctx, value)
            if item.expose_value:
                ctx.params[item.name] = value
        return None

    def _process(self, ctx, occs, leftover):
        """Resolve every non-eager parameter, convert it, and run its callback."""
        done = set()
        for p in self.params:
            if p.is_eager:
                if p in occs:
                    done.add(p)
        leftover_extra = [tok for tok, lit in leftover]
        if isinstance(self, Group):
            ctx._remaining = leftover_extra
        else:
            self._check_extra(ctx, leftover)
        for p in self.params:
            if p in done:
                continue
            supplied = occs.get(p, [])
            if p.deprecated and supplied:
                note = p.deprecated if isinstance(p.deprecated, str) else ""
                echo(f"DeprecationWarning: {p.get_error_hint()} is deprecated. {note}".rstrip(), err=True)
            value, source = p.resolve(ctx, supplied)
            if value is MISSING:
                if p.required:
                    raise MissingParameter(
                        "missing required parameter", ctx=ctx, param=p
                    )
                value = None
                source = ParameterSource.DEFAULT
            value = p.process(ctx, value)
            if p.expose_value:
                ctx.params[p.name] = value
            ctx._sources[p.name] = source or ParameterSource.DEFAULT

    def _check_extra(self, ctx, leftover):
        if not leftover:
            return
        if ctx.allow_extra_args:
            ctx.args = [tok for tok, lit in leftover]
            for tok, lit in leftover:
                if not lit and len(tok) > 1 and tok[0] in "-" and not ctx.ignore_unknown_options:
                    raise NoSuchOption(tok, ctx)
            return
        for tok, lit in leftover:
            if not lit and len(tok) > 1 and tok[0] == "-":
                raise NoSuchOption(tok, ctx)
        names = " ".join(tok for tok, _ in leftover)
        raise UsageError(f"got unexpected extra argument(s) ({names})", ctx)

    # --- invocation -----------------------------------------------------------

    def invoke(self, ctx: Context):
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else ""
            echo(f"DeprecationWarning: The command {ctx.command_path!r} is deprecated. {note}".rstrip(), err=True)
        kwargs = {p.name: ctx.params.get(p.name) for p in self.params if p.expose_value}
        if self.callback is None:
            return None
        with ctx:
            return self.callback(**kwargs)

    def main(
        self,
        args=None,
        prog_name=None,
        complete_var=None,
        standalone_mode: bool = True,
        **extra,
    ):
        if args is None:
            args = sys.argv[1:]
            if prog_name is None:
                prog_name = os.path.basename(sys.argv[0]) if sys.argv else (self.name or "cli")
        else:
            args = list(args)
        if prog_name is None:
            prog_name = self.name or "cli"

        var = complete_var or _complete_var_name(prog_name)
        instruction = os.environ.get(var)
        if instruction:
            from .shell_completion import run_completion

            status = run_completion(self, args, prog_name, instruction)
            if standalone_mode:
                sys.exit(status)
            return status

        try:
            try:
                ctx = self.make_context(prog_name, args, **extra)
                try:
                    with ctx:
                        rv = self.invoke(ctx)
                finally:
                    ctx.close()
                if not standalone_mode:
                    return rv
                sys.exit(0)
            except Exit as e:
                if standalone_mode:
                    sys.exit(e.exit_code)
                if e.exit_code == 0:
                    return None
                raise
            except OptlynError as e:
                if not standalone_mode:
                    raise
                e.show()
                sys.exit(e.exit_code)
        except (KeyboardInterrupt, EOFError):
            if not standalone_mode:
                raise
            echo("Aborted!", err=True)
            sys.exit(1)

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    def __repr__(self) -> str:
        return f"<{type(self).__name__} {self.name}>"


class Group(Command):
    """A command that dispatches to named subcommands."""

    allow_interspersed_args = False

    def __init__(
        self,
        name: t.Optional[str] = None,
        commands=None,
        invoke_without_command: bool = False,
        no_args_is_help: t.Optional[bool] = None,
        subcommand_metavar: t.Optional[str] = None,
        chain: bool = False,
        result_callback=None,
        **kwargs: t.Any,
    ) -> None:
        super().__init__(name, **kwargs)
        self.commands: t.Dict[str, Command] = dict(commands or {})
        self.invoke_without_command = invoke_without_command
        self.no_args_is_help = (not invoke_without_command) if no_args_is_help is None else no_args_is_help
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self.result_callback_fn = result_callback

    def add_command(self, cmd: Command, name: t.Optional[str] = None) -> None:
        if self.chain and isinstance(cmd, Group):
            raise TypeError("groups cannot be nested under a chaining group.")
        key = name or cmd.name
        if key is None:
            raise TypeError("command has no name")
        self.commands[key] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as _command

        def decorator(f):
            cmd = _command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as _group

        def decorator(f):
            cmd = _group(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self):
        def decorator(f):
            self.result_callback_fn = f
            return f

        return decorator

    def list_commands(self, ctx: Context) -> t.List[str]:
        return sorted(self.commands)

    def get_command(self, ctx: Context, cmd_name: str):
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        norm = self._norm(ctx, cmd_name)
        for key, cmd in self.commands.items():
            if self._norm(ctx, key) == norm:
                return cmd
        return None

    def _finish(self, ctx: Context, value):
        if self.result_callback_fn is None:
            return value
        kwargs = {p.name: ctx.params.get(p.name) for p in self.params if p.expose_value}
        with ctx:
            return self.result_callback_fn(value, **kwargs)

    def invoke(self, ctx: Context):
        rest = ctx._remaining
        if not rest:
            if self.invoke_without_command:
                ctx.invoked_subcommand = None
                rv = Command.invoke(self, ctx)
                return self._finish(ctx, [] if self.chain else rv)
            if self.no_args_is_help and not ctx._had_args:
                raise _NoArgsHelp(ctx)
            raise MissingCommand(ctx)

        if self.chain:
            return self._invoke_chain(ctx, rest)

        name = rest[0]
        cmd = self.get_command(ctx, name)
        if cmd is None:
            raise NoSuchCommand(name, ctx)
        ctx.invoked_subcommand = cmd.name
        rv = Command.invoke(self, ctx)
        sub = cmd.make_context(name, rest[1:], parent=ctx)
        rv = cmd.invoke(sub)
        return self._finish(ctx, rv)

    def _invoke_chain(self, ctx: Context, tokens: t.List[str]):
        segments = []
        i = 0
        while i < len(tokens):
            name = tokens[i]
            cmd = self.get_command(ctx, name)
            if cmd is None:
                raise NoSuchCommand(name, ctx)
            j = i + 1
            while j < len(tokens) and self.get_command(ctx, tokens[j]) is None:
                j += 1
            segments.append((name, cmd, tokens[i + 1:j]))
            i = j
        ctx.invoked_subcommand = _CHAIN
        Command.invoke(self, ctx)
        results = []
        for name, cmd, seg_args in segments:
            sub = cmd.make_context(name, seg_args, parent=ctx)
            results.append(cmd.invoke(sub))
        return self._finish(ctx, results)

    def get_help_text(self) -> str:
        return super().get_help_text()


class CommandCollection(Group):
    """A group whose subcommands are the union of several source groups."""

    def __init__(self, name=None, sources=None, **kwargs) -> None:
        super().__init__(name, **kwargs)
        self.sources: t.List[Group] = list(sources or [])

    def list_commands(self, ctx: Context) -> t.List[str]:
        names = set(self.commands)
        for src in self.sources:
            names.update(src.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx: Context, cmd_name: str):
        cmd = super().get_command(ctx, cmd_name)
        if cmd is not None:
            return cmd
        for src in self.sources:
            cmd = src.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None


def _fill_context_values(cmd: Command, parent: Context, values: dict) -> Context:
    """Create a child context carrying exactly the supplied values (for invoke/forward)."""
    ctx = Context(cmd, parent=parent, info_name=cmd.name)
    ctx._had_args = False
    ctx._remaining = []
    with ctx:
        for p in cmd.params:
            if p.name in values:
                ctx.params[p.name] = values[p.name]
                ctx._sources[p.name] = ParameterSource.COMMANDLINE
            else:
                default = p._declared_default(ctx)
                ctx.params[p.name] = None if default is MISSING else default
                ctx._sources[p.name] = ParameterSource.DEFAULT
    return ctx
