"""Thread-local storage for the current invocation context."""

from __future__ import annotations

import threading
import typing as t

_local = threading.local()


def _stack() -> t.List[t.Any]:
    st = getattr(_local, "stack", None)
    if st is None:
        st = []
        _local.stack = st
    return st


def push_context(ctx: t.Any) -> None:
    _stack().append(ctx)


def pop_context(ctx: t.Any) -> None:
    st = _stack()
    if st and st[-1] is ctx:
        st.pop()
    elif ctx in st:
        # Remove the most recent occurrence to keep nesting consistent.
        for i in range(len(st) - 1, -1, -1):
            if st[i] is ctx:
                del st[i]
                break


def current_context(silent: bool = False):
    st = _stack()
    if st:
        return st[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")
