"""Parameter types and conversion."""

from __future__ import annotations

import enum
import os
import sys
import typing as t
import uuid
from datetime import datetime
from pathlib import Path as _PathLib

from .exceptions import BadParameter, FileError


class ParamType:
    """Base class for parameter types."""

    name = "text"
    is_composite = False

    def __call__(self, value: t.Any, param=None, ctx=None) -> t.Any:
        if value is None:
            return None
        return self.convert(value, param, ctx)

    def convert(self, value: t.Any, param=None, ctx=None) -> t.Any:
        return value

    def get_metavar(self, param) -> t.Optional[str]:
        return None

    def get_missing_message(self, param) -> t.Optional[str]:
        return None

    def split_envvar_value(self, rv: str) -> t.Sequence[str]:
        return rv.split()

    def shell_complete(self, ctx, param, incomplete: str):
        return []

    def fail(self, message: str, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def __repr__(self) -> str:
        return self.name.upper()


class _StringType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            try:
                return value.decode("utf-8")
            except UnicodeError:
                return value.decode("utf-8", "replace")
        return str(value)


class _UnprocessedType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


class _IntType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            text = str(value).strip()
            if text.lower().startswith(("0x", "-0x", "+0x")):
                return int(text, 16)
            return int(text, 10)
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid integer", param, ctx)


class _FloatType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        try:
            return float(str(value).strip())
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid floating point value", param, ctx)


_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class _BoolType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean", param, ctx)


class _UUIDType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid UUID", param, ctx)


STRING = _StringType()
INT = _IntType()
FLOAT = _FloatType()
BOOL = _BoolType()
UUID = _UUIDType()
UNPROCESSED = _UnprocessedType()


def convert_type(ty, default=None) -> ParamType:
    """Turn a type spec (ParamType, python type, callable, or None) into a ParamType."""
    if isinstance(ty, ParamType):
        return ty
    if ty is None and default is not None:
        if isinstance(default, (tuple, list)):
            # Guessed per-position types are handled by the caller.
            return STRING
        if isinstance(default, bool):
            return BOOL
        if isinstance(default, int):
            return INT
        if isinstance(default, float):
            return FLOAT
        if isinstance(default, uuid.UUID):
            return UUID
        return STRING
    if ty is None or ty is str:
        return STRING
    if ty is int:
        return INT
    if ty is float:
        return FLOAT
    if ty is bool:
        return BOOL
    if ty is uuid.UUID:
        return UUID
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"unsupported parameter type {ty!r}")


class FuncParamType(ParamType):
    """Wraps a conversion function f(token) -> value that refuses by raising ValueError."""

    def __init__(self, func: t.Callable) -> None:
        self.func = func
        self.name = getattr(func, "__name__", "text").upper()

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except BadParameter:
            raise
        except ValueError as e:
            self.fail(str(e) or f"{value!r} is not valid", param, ctx)


class Choice(ParamType):
    name = "choice"

    def __init__(self, choices, case_sensitive: bool = True) -> None:
        self.case_sensitive = case_sensitive
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self._enum = choices
            self.choices = list(choices.__members__.items())  # (name, member)
            self._originals = {name: member for name, member in self.choices}
        else:
            self._enum = None
            self.choices = list(choices)
            self._originals = None

    def _tokens(self):
        if self._enum is not None:
            return [name for name, _ in self.choices]
        return [str(c) for c in self.choices]

    def get_metavar(self, param):
        return "[" + "|".join(self._tokens()) + "]"

    def get_missing_message(self, param):
        return "Choose from:\n\t" + ",\n\t".join(self._tokens())

    def _normalize(self, s: str) -> str:
        return s if self.case_sensitive else s.casefold()

    def convert(self, value, param=None, ctx=None):
        if self._enum is not None and isinstance(value, self._enum):
            return value
        if self._enum is None and value in self.choices:
            return value
        text = str(value)
        norm = self._normalize(text)
        norm_map = {}
        if self._enum is not None:
            items = [(name, member) for name, member in self.choices]
        else:
            items = [(str(c), c) for c in self.choices]
        for tok, original in items:
            key = self._normalize(tok)
            norm_map.setdefault(key, original)
        if norm in norm_map:
            return norm_map[norm]
        allowed = ", ".join(repr(tok) for tok, _ in items)
        self.fail(f"{text!r} is not {allowed}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        out = []
        for tok in self._tokens():
            if self._normalize(tok).startswith(self._normalize(incomplete)):
                out.append(tok)
        return out


DEFAULT_DATETIME_FORMATS = (
    "%Y-%m-%d",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M:%S",
)


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None) -> None:
        self.formats = list(formats) if formats is not None else list(DEFAULT_DATETIME_FORMATS)

    def get_metavar(self, param):
        return "[" + "|".join(self.formats) + "]"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, datetime):
            return value
        text = str(value).strip()
        for fmt in self.formats:
            try:
                return datetime.strptime(text, fmt)
            except ValueError:
                continue
        self.fail(f"{value!r} does not match the formats {', '.join(self.formats)}.", param, ctx)


class IntRange(_IntType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False) -> None:
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def get_metavar(self, param):
        lo = "" if self.min is None else str(self.min)
        hi = "" if self.max is None else str(self.max)
        return f"integer{'>' if self.min_open else '>='}{lo}..{'<' if self.max_open else '<='}{hi}"

    def convert(self, value, param=None, ctx=None):
        rv = super().convert(value, param, ctx)
        if self.min is not None:
            if self.min_open and rv <= self.min:
                if self.clamp:
                    return self.min + 1
                self.fail(f"{rv} is not greater than {self.min}.", param, ctx)
            if not self.min_open and rv < self.min:
                if self.clamp:
                    return self.min
                self.fail(f"{rv} is not in the range {self.min}..{self.max}.", param, ctx)
        if self.max is not None:
            if self.max_open and rv >= self.max:
                if self.clamp:
                    return self.max - 1
                self.fail(f"{rv} is not less than {self.max}.", param, ctx)
            if not self.max_open and rv > self.max:
                if self.clamp:
                    return self.max
                self.fail(f"{rv} is not in the range {self.min}..{self.max}.", param, ctx)
        return rv


class FloatRange(_FloatType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False) -> None:
        if clamp and ((min is not None and min_open) or (max is not None and max_open)):
            raise ValueError("clamp is only allowed when both bounds are closed")
        if clamp and (min is None or max is None):
            raise ValueError("clamp requires both bounds")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        rv = super().convert(value, param, ctx)
        if self.clamp:
            if rv < self.min:
                return float(self.min)
            if rv > self.max:
                return float(self.max)
            return rv
        if self.min is not None:
            if (self.min_open and rv <= self.min) or (not self.min_open and rv < self.min):
                self.fail(f"{rv} is not in the range {self.min}..{self.max}.", param, ctx)
        if self.max is not None:
            if (self.max_open and rv >= self.max) or (not self.max_open and rv > self.max):
                self.fail(f"{rv} is not in the range {self.min}..{self.max}.", param, ctx)
        return rv


class Tuple(ParamType):
    name = "tuple"
    is_composite = True

    def __init__(self, types) -> None:
        self.types = [convert_type(t_) for t_ in types]

    @property
    def arity(self) -> int:
        return len(self.types)

    def convert(self, value, param=None, ctx=None):
        if not isinstance(value, (tuple, list)) or len(value) != len(self.types):
            self.fail(f"expected {len(self.types)} values", param, ctx)
        return tuple(ty(v, param, ctx) for ty, v in zip(self.types, value))


class File(ParamType):
    name = "filename"

    def __init__(
        self,
        mode: str = "r",
        encoding=None,
        errors: str = "strict",
        lazy=None,
        atomic: bool = False,
    ) -> None:
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"unsupported file mode {mode!r}")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def _is_lazy(self) -> bool:
        if self.lazy is not None:
            return bool(self.lazy)
        return self.mode in ("w", "wb")

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        name = str(value)
        if name == "-":
            from .utils import open_file as _open

            return _open(
                "-",
                self.mode,
                self.encoding,
                self.errors,
                lazy=False,
                atomic=False,
            )
        try:
            from .utils import open_file as _open

            return _open(
                name,
                self.mode,
                self.encoding,
                self.errors,
                lazy=self._is_lazy(),
                atomic=self.atomic,
            )
        except OSError as e:
            self.fail(f"'{name}': {e.strerror or e}", param, ctx)

    def get_metavar(self, param):
        return "FILENAME"


class Path(ParamType):
    name = "path"

    def __init__(
        self,
        exists: bool = False,
        file_okay: bool = True,
        dir_okay: bool = True,
        writable: bool = False,
        readable: bool = True,
        resolve_path: bool = False,
        allow_dash: bool = False,
        path_type=None,
        executable: bool = False,
    ) -> None:
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def get_metavar(self, param):
        return "PATH"

    def convert(self, value, param=None, ctx=None):
        rv = value
        is_dash = self.allow_dash and rv in (b"-", "-")
        if not is_dash:
            if isinstance(rv, bytes):
                rv = os.fsdecode(rv)
            if self.resolve_path:
                rv = os.path.realpath(os.path.expanduser(rv))
            exists = os.path.exists(rv)
            if not exists:
                if self.exists:
                    self.fail(f"{value!r} does not exist.", param, ctx)
            else:
                if not self.file_okay and os.path.isfile(rv):
                    self.fail(f"{value!r} is a file.", param, ctx)
                if not self.dir_okay and os.path.isdir(rv):
                    self.fail(f"{value!r} is a directory.", param, ctx)
                if self.readable and not os.access(rv, os.R_OK):
                    self.fail(f"{value!r} is not readable.", param, ctx)
                if self.writable and not os.access(rv, os.W_OK):
                    self.fail(f"{value!r} is not writable.", param, ctx)
                if self.executable and not os.access(rv, os.X_OK):
                    self.fail(f"{value!r} is not executable.", param, ctx)
        if self.path_type is not None and self.path_type is _PathLib:
            return _PathLib(rv)
        return rv


