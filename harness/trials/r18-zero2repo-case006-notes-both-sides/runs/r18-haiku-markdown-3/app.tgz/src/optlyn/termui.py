"""Terminal helpers: echo, styling, prompts, pager, progress bars, editor, and friends."""

from __future__ import annotations

import contextlib
import getpass
import io
import os
import re
import subprocess
import sys
import tempfile
import time
import typing as t

from ._state import current_context
from .exceptions import Abort, BadParameter

_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]")

_COLOR_CODES = {
    "black": 30, "red": 31, "green": 32, "yellow": 33,
    "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
}
_BG_OFFSET = 10


def _strip_ansi(text: str) -> str:
    return _ANSI_RE.sub("", text)


def unstyle(text: str) -> str:
    """Remove ANSI escape sequences, leaving other text as is."""
    return _strip_ansi(text)


def _color_code(color, bg: bool) -> str:
    if isinstance(color, bool):
        raise TypeError("invalid color")
    if isinstance(color, str):
        if color == "reset":
            return "49" if bg else "39"
        if color not in _COLOR_CODES:
            raise TypeError(f"unknown color {color!r}")
        code = _COLOR_CODES[color] + (_BG_OFFSET if bg else 0)
        return str(code)
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise ValueError("256-color value out of range")
        return f"{48 if bg else 38};5;{color}"
    if isinstance(color, (tuple, list)) and len(color) == 3 and all(
        isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
    ):
        return f"{48 if bg else 38};2;{color[0]};{color[1]};{color[2]}"
    raise TypeError(f"invalid color {color!r}")


def style(
    text: t.Any,
    fg=None,
    bg=None,
    bold=None,
    dim=None,
    underline=None,
    overline=None,
    italic=None,
    blink=None,
    reverse=None,
    strikethrough=None,
    reset: bool = True,
) -> str:
    """Wrap ``text`` in ANSI SGR sequences. Invalid colors raise ``TypeError``/``ValueError``."""
    codes: t.List[str] = []
    if fg is not None:
        codes.append(_color_code(fg, False))
    if bg is not None:
        codes.append(_color_code(bg, True))
    switches = [
        (bold, "1"), (dim, "2"), (underline, "4"), (overline, "53"),
        (italic, "3"), (blink, "5"), (reverse, "7"), (strikethrough, "9"),
    ]
    for flag, code in switches:
        if flag is True:
            codes.append(code)
        elif flag is False:
            codes.append({"1": "22", "2": "22", "4": "24", "53": "55",
                          "3": "23", "5": "25", "7": "27", "9": "29"}[code])
    body = str(text)
    if not codes:
        return body
    prefix = "\x1b[" + ";".join(codes) + "m"
    suffix = "\x1b[0m" if reset else ""
    return prefix + body + suffix


def _current_color():
    ctx = current_context(silent=True)
    return getattr(ctx, "color", None) if ctx is not None else None


def _is_tty(stream) -> bool:
    try:
        return bool(stream.isatty())
    except Exception:
        return False


def _write_text(stream, text: str) -> None:
    """Write text; on an encoding that cannot represent it, fall back to UTF-8 bytes."""
    try:
        stream.write(text)
    except UnicodeEncodeError:
        buf = getattr(stream, "buffer", None)
        if buf is None:
            stream.write(text.encode("ascii", "backslashreplace").decode("ascii"))
        else:
            stream.flush()
            buf.write(text.encode("utf-8"))
            buf.flush()


def echo(
    message=None,
    file=None,
    nl: bool = True,
    err: bool = False,
    color=None,
) -> None:
    """Write text or bytes; styles are stripped when the stream is not a terminal."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        buf = getattr(file, "buffer", file)
        buf.write(message + (b"\n" if nl else b""))
        buf.flush()
        return
    text = str(message)
    if color is None:
        color = _current_color()
    keep = color is True or (color is None and _is_tty(file))
    if color is False or not keep:
        text = _strip_ansi(text)
    if nl:
        text += "\n"
    _write_text(file, text)
    try:
        file.flush()
    except Exception:
        pass


def secho(message=None, file=None, nl: bool = True, err: bool = False, color=None, **styles) -> None:
    if message is not None:
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


def is_interactive() -> bool:
    try:
        return sys.stdin.isatty() or sys.stdout.isatty()
    except Exception:
        return False


def echo_via_pager(text_or_generator, color=None) -> None:
    """Send text through $PAGER when interactive; otherwise write it to standard output."""
    if callable(text_or_generator) and not isinstance(text_or_generator, str):
        chunks = text_or_generator()
    elif isinstance(text_or_generator, str):
        chunks = [text_or_generator]
    else:
        chunks = text_or_generator
    if not is_interactive():
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    pager = os.environ.get("PAGER") or "less"
    import shlex

    proc = subprocess.Popen(shlex.split(pager), stdin=subprocess.PIPE, text=True)
    try:
        for chunk in chunks:
            proc.stdin.write(str(chunk))
            proc.stdin.flush()
    except BrokenPipeError:
        pass
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        proc.wait()


class _NonClosingWriter(io.TextIOBase):
    def __init__(self, target, color=None):
        self._t = target
        self._color = color

    def writable(self):
        return True

    def write(self, s):
        echo(s, file=self._t, nl=False, color=self._color)
        return len(s)

    def flush(self):
        try:
            self._t.flush()
        except Exception:
            pass

    def close(self):  # never closes the real stream
        pass


@contextlib.contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream routed through the pager (or stdout)."""
    if not is_interactive():
        yield _NonClosingWriter(sys.stdout, color)
        return
    pager = os.environ.get("PAGER") or "less"
    import shlex

    proc = subprocess.Popen(shlex.split(pager), stdin=subprocess.PIPE, text=True)
    try:
        yield _NonClosingWriter(proc.stdin, color)
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        proc.wait()


class ProgressBar:
    """Iterates a sequence and optionally draws progress on a terminal."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, **options):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label
        self.hidden = hidden
        self.pos = 0
        self.start = time.time()
        self._stream = sys.stdout
        self.visible = (not hidden) and _is_tty(self._stream)
        self._printed_label = False
        self.options = options

    def _render(self) -> None:
        if not self.visible:
            return
        if self.length:
            frac = min(self.pos / self.length, 1.0)
            width = 30
            filled = int(width * frac)
            elapsed = time.time() - self.start
            remaining = (elapsed / frac - elapsed) if frac > 0 else 0
            bar = "#" * filled + "-" * (width - filled)
            line = f"\r{self.label + ' ' if self.label else ''}[{bar}] {self.pos}/{self.length} ETA {int(remaining)}s"
        else:
            line = f"\r{self.label + ' ' if self.label else ''}{self.pos}"
        self._stream.write(line)
        self._stream.flush()

    def update(self, n_steps: int = 1) -> None:
        self.pos += n_steps
        self._render()

    def __iter__(self):
        if self.iterable is None:
            return
        if not self.visible and self.label and not self.hidden and not self._printed_label:
            self._stream.write(f"{self.label}\n")
            self._printed_label = True
        for item in self.iterable:
            yield item
            self.update(1)
        if self.visible:
            self._stream.write("\n")
            self._stream.flush()


@contextlib.contextmanager
def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    bar = ProgressBar(iterable, length, label, hidden, **options)
    if label and not bar.visible and not hidden:
        echo(label)
        bar._printed_label = True
    try:
        yield bar
    finally:
        if bar.visible:
            bar._stream.write("\n")
            bar._stream.flush()


def _read_line(prompt_text: str, hide: bool, err: bool = False) -> str:
    stream = sys.stderr if err else sys.stdout
    if hide:
        if _is_tty(sys.stdin):
            return getpass.getpass(prompt_text)
        stream.write(prompt_text)
        stream.flush()
        line = sys.stdin.readline()
        stream.write("\n")
        stream.flush()
    else:
        stream.write(prompt_text)
        stream.flush()
        line = sys.stdin.readline()
        if not _is_tty(sys.stdin):
            # Visible prompts echo the typed line into the captured output.
            stream.write(line if line.endswith("\n") else line + "\n")
            stream.flush()
    if line == "":
        raise EOFError()
    return line.rstrip("\r\n")


def _default_type_for(default, type_):
    from .types import convert_type

    if type_ is not None:
        return convert_type(type_)
    if default is not None:
        return convert_type(None, default)
    return convert_type(None)


def prompt(
    text: str,
    default=None,
    hide_input: bool = False,
    confirmation_prompt=False,
    type=None,
    value_proc=None,
    prompt_suffix: str = ": ",
    show_default: bool = True,
    err: bool = False,
):
    """Ask for a value, re-asking until conversion succeeds or input ends."""
    ty = _default_type_for(default, type)
    shown_default = ""
    if default is not None and show_default and not callable(default):
        shown_default = f" [{default}]"
    while True:
        try:
            raw = _read_line(f"{text}{shown_default}{prompt_suffix}", hide_input, err)
        except (EOFError, KeyboardInterrupt) as e:
            raise Abort() from e
        if raw == "" and default is not None:
            value = default() if callable(default) else default
        else:
            try:
                value = ty.convert(raw, None, None)
            except BadParameter as e:
                (sys.stderr).write(f"Error: {e.message}\n")
                continue
        if confirmation_prompt:
            try:
                again = _read_line("Repeat for confirmation" + prompt_suffix, hide_input, err)
            except (EOFError, KeyboardInterrupt) as e:
                raise Abort() from e
            if again != raw:
                (sys.stderr).write("Error: the two entered values do not match\n")
                continue
        return value


_YES = {"y", "yes"}
_NO = {"n", "no"}


def confirm(
    text: str,
    default: bool = False,
    abort: bool = False,
    prompt_suffix: str = ": ",
    show_default: bool = True,
    err: bool = False,
) -> bool:
    """Ask a yes/no question. An empty answer takes the default."""
    suffix = " [y/N]" if not default and show_default else (" [Y/n]" if show_default else "")
    while True:
        try:
            raw = _read_line(f"{text}{suffix}{prompt_suffix}", False, err).strip().lower()
        except (EOFError, KeyboardInterrupt) as e:
            raise Abort() from e
        if raw == "":
            answer = default
            break
        if raw in _YES:
            answer = True
            break
        if raw in _NO:
            answer = False
            break
    if abort and not answer:
        raise Abort()
    return answer


def getchar(echo: bool = False) -> str:
    """Read one character from the terminal (not from a piped stdin)."""
    try:
        import termios
        import tty
    except ImportError:  # pragma: no cover - Windows
        import msvcrt

        ch = msvcrt.getwch()
        if ch == "\x03":
            raise KeyboardInterrupt()
        if ch == "\x04" or ch == "\x1a":
            raise EOFError()
        return ch
    opened_here = False
    try:
        fd = os.open("/dev/tty", os.O_RDONLY)
        opened_here = True
    except OSError:
        if not _is_tty(sys.stdin):
            raise EOFError()
        fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        ch = os.read(fd, 1).decode("utf-8", "replace")
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)
        if opened_here:
            os.close(fd)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    if echo:
        echo(ch, nl=False)
    return ch


def pause(info: t.Optional[str] = None, err: bool = False) -> None:
    """Wait for a key press when interactive; do nothing otherwise."""
    if info is None:
        info = "Press any key to continue..."
    stream = sys.stderr if err else sys.stdout
    if not is_interactive():
        if info:
            stream.write(info + "\n")
        return
    stream.write(info + "\n")
    stream.flush()
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass


def edit(
    text=None,
    editor=None,
    env=None,
    require_save: bool = True,
    extension: str = ".txt",
    filename=None,
):
    """Open a file in an editor. Returns the saved text, or None."""
    import shlex

    editor_cmd = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR") or "vi"
    argv = shlex.split(editor_cmd) if isinstance(editor_cmd, str) else list(editor_cmd)
    run_env = dict(os.environ)
    if env:
        run_env.update(env)
    if filename is not None:
        subprocess.call(argv + [os.fspath(filename)], env=run_env)
        return None
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            if text:
                f.write(text.replace("\r\n", "\n"))
        before = os.path.getmtime(path)
        rc = subprocess.call(argv + [path], env=run_env)
        if rc != 0:
            return None
        with open(path, "r", encoding="utf-8") as f:
            result = f.read()
        if require_save and os.path.getmtime(path) == before and text is not None:
            return None
        return result
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


def clear() -> None:
    """Clear the terminal when connected to one; otherwise do nothing."""
    if _is_tty(sys.stdout):
        sys.stdout.write("\033[2J\033[H")
        sys.stdout.flush()
