"""Shell completion: registration scripts and suggestion output."""

from __future__ import annotations

import os
import sys
import typing as t

from .params import Argument, Option
from .types import Choice, File, Path

SHELLS = ("bash", "zsh", "fish", "powershell")
PATH_FILES = "__optlyn_path__file"
PATH_DIRS = "__optlyn_path__dir"


def _script(shell: str, prog_name: str, var: str) -> str:
    exe = os.path.basename(prog_name)
    if shell == "bash":
        return (
            f"_{exe.replace('-', '_')}_completion() {{\n"
            f"  local IFS=$'\\n'\n"
            f"  COMPREPLY=( $(env COMP_WORDS=\"${{COMP_WORDS[*]}}\" COMP_CWORD=$COMP_CWORD "
            f"{var}=bash_complete {exe}) )\n"
            f"  return 0\n}}\n"
            f"complete -o default -F _{exe.replace('-', '_')}_completion {exe}\n"
        )
    if shell == "zsh":
        return (
            f"#compdef {exe}\n"
            f"_{exe.replace('-', '_')}_completion() {{\n"
            f"  local -a completions\n"
            f"  completions=(\"${{(@f)$(env COMP_WORDS=\"${{words[*]}}\" COMP_CWORD=$((CURRENT-1)) "
            f"{var}=zsh_complete {exe})}}\")\n"
            f"  compadd -a completions\n}}\n"
            f"compdef _{exe.replace('-', '_')}_completion {exe}\n"
        )
    if shell == "fish":
        return (
            f"function _{exe.replace('-', '_')}_completion\n"
            f"    set -l cmd (commandline -cp)\n"
            f"    env COMP_WORDS=\"$cmd\" COMP_CWORD=(commandline -ct) {var}=fish_complete {exe}\n"
            f"end\n"
            f"complete -c {exe} -f -a '(_{exe.replace('-', '_')}_completion)'\n"
        )
    return (
        f"Register-ArgumentCompleter -Native -CommandName {exe} -ScriptBlock {{\n"
        f"    param($wordToComplete, $commandAst, $cursorPosition)\n"
        f"    $env:COMP_WORDS = $commandAst.ToString(); $env:COMP_CWORD = $wordToComplete\n"
        f"    $env:{var} = 'powershell_complete'\n"
        f"    & {exe} | ForEach-Object {{ [System.Management.Automation.CompletionResult]::new($_) }}\n"
        f"}}\n"
    )


def _normalize_item(item) -> str:
    """Completion functions may return strings or objects exposing ``value``."""
    if isinstance(item, str):
        return item
    return str(getattr(item, "value", item))


def _suggestions(cmd, words: t.List[str], incomplete: str):
    """Return the list of suggestion strings for the given already-typed words."""
    from .context import Context

    ctx = Context(cmd, info_name=cmd.name)
    cur = cmd
    flag_names = {}
    prev_param = None
    typed = words[1:]
    for idx, w in enumerate(typed):
        if prev_param is not None:
            prev_param = None
            continue
        if w.startswith("-") and hasattr(cur, "params"):
            for p in cur.params:
                if isinstance(p, Option) and w in p.all_flag_names and not (p.is_flag or p.is_count):
                    prev_param = p
                    break
            continue
        if hasattr(cur, "get_command"):
            nxt = cur.get_command(ctx, w)
            if nxt is not None:
                cur = nxt
    results: t.List[t.Any] = []
    if prev_param is not None:
        if callable(prev_param.shell_complete):
            return [_normalize_item(x) for x in prev_param.shell_complete(ctx, prev_param, incomplete)]
        ty = prev_param.type
        if isinstance(ty, Choice):
            return [c for c in ty.shell_complete(ctx, prev_param, incomplete)]
        if isinstance(ty, (File, Path)):
            return [PATH_FILES]
        return []
    if incomplete.startswith("-") or incomplete == "":
        if incomplete.startswith("-"):
            pass
        for p in getattr(cur, "params", []):
            if isinstance(p, Option) and not p.hidden:
                for name in p.all_flag_names:
                    if name.startswith(incomplete):
                        results.append(name)
    if not incomplete.startswith("-") and hasattr(cur, "list_commands"):
        for name in cur.list_commands(ctx):
            sub = cur.get_command(ctx, name)
            if sub is None or sub.hidden:
                continue
            if name.startswith(incomplete):
                results.insert(0, name)
    for p in getattr(cur, "params", []):
        if isinstance(p, Argument):
            if isinstance(p.type, (File, Path)):
                results.append(PATH_FILES)
                break
    seen = []
    for r in results:
        if r not in seen:
            seen.append(r)
    return seen


def run_completion(cmd, args, prog_name: str, instruction: str) -> int:
    """Handle ``_PROG_COMPLETE=<shell>_source|<shell>_complete``. Returns an exit status."""
    var = None
    for shell in SHELLS:
        if instruction == f"{shell}_source":
            var = (shell, "source")
            break
        if instruction == f"{shell}_complete":
            var = (shell, "complete")
            break
    if var is None:
        return 1
    shell, mode = var
    if mode == "source":
        sys.stdout.write(_script(shell, prog_name, _var_name(prog_name)))
        return 0
    raw = os.environ.get("COMP_WORDS", "")
    words = raw.split(" ") if raw else []
    if shell == "fish":
        incomplete = os.environ.get("COMP_CWORD", "")
        if words and words[-1] == incomplete:
            words = words[:-1]
    else:
        try:
            cword = int(os.environ.get("COMP_CWORD", str(len(words))))
        except ValueError:
            cword = len(words)
        incomplete = words[cword] if 0 <= cword < len(words) else ""
        words = words[:cword]
    for item in _suggestions(cmd, words or [prog_name], incomplete):
        sys.stdout.write(f"{item}\n")
    return 0


def _var_name(prog_name: str) -> str:
    return "_" + os.path.basename(prog_name).upper().replace("-", "_") + "_COMPLETE"
