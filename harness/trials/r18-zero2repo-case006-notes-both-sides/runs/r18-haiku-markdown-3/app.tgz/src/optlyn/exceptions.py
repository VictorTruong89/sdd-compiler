"""Exception classes for Optlyn.

Exit-status classes (standalone mode):
  * ``ClickException``-style usage errors exit with status 2.
  * ``Abort`` and other general errors exit with status 1.
"""

from __future__ import annotations

import typing as t


class OptlynError(Exception):
    """Base class for errors signalled by Optlyn."""

    exit_code = 1

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message = message

    def show(self, file: t.Optional[t.TextIO] = None) -> None:
        import sys

        if file is None:
            file = sys.stderr
        file.write(f"Error: {self.message}\n")


class UsageError(OptlynError):
    """A usage failure: exit status 2, help may be shown."""

    exit_code = 2

    def __init__(
        self,
        message: str,
        ctx: t.Optional["Context"] = None,  # noqa: F821
    ) -> None:
        super().__init__(message)
        self.ctx = ctx
        self.cmd = ctx.command if ctx is not None else None

    def show(self, file: t.Optional[t.TextIO] = None) -> None:
        import sys

        if file is None:
            file = sys.stderr
        hint = ""
        if self.ctx is not None and self.ctx.command is not None:
            help_names = self.ctx.help_option_names
            if help_names:
                hint = f"Try '{self.ctx.command_path} {help_names[0]}' for help.\n"
        file.write(f"Usage error: {self.message}\n")
        if hint:
            file.write(hint)


class BadParameter(UsageError):
    """Raised to refuse a parameter value. Usage-class error that names the parameter."""

    def __init__(
        self,
        message: str,
        ctx: t.Optional["Context"] = None,  # noqa: F821
        param: t.Optional["Parameter"] = None,  # noqa: F821
        param_hint: t.Optional[str] = None,
    ) -> None:
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self) -> str:
        if self.param_hint is not None:
            hint = self.param_hint
        elif self.param is not None:
            hint = self.param.get_error_hint()
        else:
            hint = None
        if hint:
            return f"Invalid value for {hint}: {self.message}"
        return f"Invalid value: {self.message}"

    def show(self, file: t.Optional[t.TextIO] = None) -> None:
        import sys

        if file is None:
            file = sys.stderr
        file.write(f"Usage error: {self.format_message()}\n")


class MissingParameter(BadParameter):
    """A required parameter was not supplied."""

    def __init__(
        self,
        message: t.Optional[str] = None,
        ctx: t.Optional["Context"] = None,  # noqa: F821
        param: t.Optional["Parameter"] = None,  # noqa: F821
        param_hint: t.Optional[str] = None,
    ) -> None:
        super().__init__(message or "missing required parameter", ctx, param, param_hint)

    def format_message(self) -> str:
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint()
        if hint:
            return f"Missing parameter {hint}: {self.message}"
        return f"Missing parameter: {self.message}"


class NoSuchOption(UsageError):
    """An option name that is not declared on the command."""

    def __init__(self, option_name: str, ctx: t.Optional["Context"] = None) -> None:  # noqa: F821
        super().__init__(f"no such option: {option_name}", ctx)
        self.option_name = option_name


class NoSuchCommand(UsageError):
    """A subcommand name that is not known to a group."""

    def __init__(self, name: str, ctx: t.Optional["Context"] = None) -> None:  # noqa: F821
        super().__init__(f"no such command: {name}", ctx)
        self.command_name = name


class MissingCommand(UsageError):
    """A group was invoked without a subcommand where one is required."""

    def __init__(self, ctx: t.Optional["Context"] = None) -> None:  # noqa: F821
        super().__init__("missing command", ctx)


class BadOptionUsage(UsageError):
    """Usage problem with an option (for example a missing value)."""


class BadArgumentUsage(UsageError):
    """Usage problem with an argument."""


class Abort(OptlynError):
    """User aborted (confirmation declined, EOF on prompt, Ctrl-C)."""

    exit_code = 1

    def __init__(self, message: str = "Aborted!") -> None:
        super().__init__(message)

    def show(self, file: t.Optional[t.TextIO] = None) -> None:
        import sys

        if file is None:
            file = sys.stderr
        file.write(f"{self.message}\n")


class Exit(Exception):
    """Author clean stop with a status code."""

    def __init__(self, code: int = 0) -> None:
        super().__init__(code)
        self.exit_code = code


class FileError(OptlynError):
    """A file could not be opened at first I/O (general error class)."""

    exit_code = 1

    def __init__(self, filename: str, message: str) -> None:
        super().__init__(f"Could not open file {filename!r}: {message}")
        self.filename = filename


class DeprecatedError(OptlynError):
    """Declaration-time refusal of an invalid combination."""

    exit_code = 1
