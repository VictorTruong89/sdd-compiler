"""Parameters: options and positional arguments, with value-source resolution."""

from __future__ import annotations

import os
import typing as t

from . import types as _types
from .context import ParameterSource
from .exceptions import BadParameter, MissingParameter

MISSING = object()  # no value from any source
NOVALUE = object()  # flag/value option present with no value (prompt trigger)

_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}
PREFIX_CHARS = "-"


def _resolve_type(ty, default, multiple: bool, nargs: int):
    if isinstance(ty, tuple) and not isinstance(ty, _types.ParamType):
        return _types.Tuple(ty)
    if isinstance(ty, _types.ParamType):
        return ty
    if ty is None and default is not None:
        sample = default
        if isinstance(default, (list, tuple)):
            sample = default[0] if len(default) else None
        if sample is None:
            return _types.STRING
        return _types.convert_type(None, sample)
    return _types.convert_type(ty)


class Parameter:
    """Base class for options and arguments."""

    is_option_like = False
    expose_help = True

    def __init__(
        self,
        param_decls: t.Sequence[str] = (),
        type=None,
        default=None,
        required: t.Optional[bool] = None,
        callback=None,
        nargs: t.Optional[int] = None,
        multiple: bool = False,
        metavar: t.Optional[str] = None,
        expose_value: bool = True,
        is_eager: bool = False,
        envvar=None,
        shell_complete=None,
        deprecated=False,
        hidden: bool = False,
        help: t.Optional[str] = None,
        allow_from_autoenv: bool = True,
        prompt=None,
        prompt_required: bool = True,
        hide_input: bool = False,
        confirmation_prompt: bool = False,
        show_default=None,
        show_envvar: bool = False,
        **extra: t.Any,
    ) -> None:
        self.name: str = self._infer_name(param_decls)
        self.default = default
        self.callback = callback
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        self.hidden = hidden
        self.deprecated = deprecated
        self.help = help
        self.allow_from_autoenv = allow_from_autoenv
        self.shell_complete = shell_complete
        self.prompt = prompt if prompt is not False else None
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.multiple = multiple
        if envvar is None:
            self.envvars: t.List[str] = []
        elif isinstance(envvar, str):
            self.envvars = [envvar]
        else:
            self.envvars = list(envvar)
        self._nargs_declared = nargs
        self.nargs = nargs if nargs is not None else 1
        self.required = bool(required) if required is not None else False
        self.type = _resolve_type(type, default, multiple, self.nargs)
        if isinstance(self.type, _types.Tuple) and nargs is None:
            self.nargs = self.type.arity
        self.extra = extra

    # --- naming -------------------------------------------------------------

    @staticmethod
    def _infer_name(decls: t.Sequence[str]) -> str:
        return ""

    def get_error_hint(self) -> str:
        return self.name

    def get_metavar(self) -> t.Optional[str]:
        if self.metavar is not None:
            return self.metavar
        return None

    # --- value pipeline -------------------------------------------------

    def _split(self, text: str) -> t.List[str]:
        if isinstance(self.type, (_types.File, _types.Path)):
            return [x for x in text.split(os.pathsep) if x != ""]
        return self.type.split_envvar_value(text)

    def _convert_occ(self, ctx, raw):
        if raw is NOVALUE or raw is MISSING:
            return raw
        if self.is_count or self.is_flag:
            return raw
        ty = self.type
        if isinstance(ty, _types.Tuple):
            return ty(raw, self, ctx)
        if self.nargs == 1 and not isinstance(raw, tuple):
            return ty(raw, self, ctx)
        return tuple(ty(x, self, ctx) for x in raw)

    def _convert_sequence(self, ctx, items) -> tuple:
        return tuple(self._convert_occ(ctx, x) for x in items)

    def _normalize_default(self, value, ctx, from_map: bool):
        if self.multiple or self.nargs != 1 or isinstance(self.type, _types.Tuple):
            if isinstance(value, str):
                if from_map and (self.nargs != 1 or isinstance(self.type, _types.Tuple)):
                    parts = self._split(value)
                    return self._convert_sequence(ctx, parts)
                raise BadParameter(
                    f"{self.name!r} needs an iterable (sequence) default, not a string.",
                    ctx=ctx,
                    param=self,
                )
            if self.multiple:
                if not isinstance(value, (list, tuple)):
                    raise BadParameter(
                        f"{self.name!r} needs an iterable (sequence) default.",
                        ctx=ctx,
                        param=self,
                    )
                return self._convert_sequence(ctx, value)
            if isinstance(value, (list, tuple)):
                return self._convert_occ(ctx, tuple(value))
            return self._convert_occ(ctx, value)
        if isinstance(value, str) and from_map and self.nargs == 1:
            return self._convert_occ(ctx, value)
        return self._convert_occ(ctx, value)

    def _declared_default(self, ctx, from_map: bool = False):
        """Default value (declared or from the default map), converted; MISSING when none."""
        value = self.default
        if callable(value):
            value = value()
        if value is None:
            if self.is_flag:
                return False
            if self.is_count:
                return 0
            if self.multiple or self.nargs == -1:
                return ()
            return MISSING
        return self._normalize_default(value, ctx, from_map)

    def _env_value(self, ctx):
        names = list(self.envvars)
        if (
            isinstance(self, Option)
            and self.allow_from_autoenv
            and ctx.root.auto_envvar_prefix
        ):
            names.append(ctx.env_name_for(self.name))
        for name in names:
            raw = os.environ.get(name)
            if raw is None or raw == "":
                continue
            if self.is_flag:
                text = raw.strip().lower()
                flag_value = self.flag_value
                if isinstance(flag_value, bool) or flag_value is None:
                    if text in _TRUE:
                        return True
                    if text in _FALSE or text == "":
                        return False
                    raise BadParameter(f"{raw!r} is not a valid boolean.", ctx=ctx, param=self)
                if text == str(flag_value).lower():
                    return flag_value
                if text in _TRUE:
                    return True
                if text in _FALSE:
                    return False
                continue
            if self.multiple:
                return self._convert_sequence(ctx, self._split(raw))
            if self.nargs != 1 or isinstance(self.type, _types.Tuple):
                parts = self._split(raw)
                return self._convert_occ(ctx, tuple(parts))
            return self._convert_occ(ctx, raw)
        return MISSING

    def _prompt_value(self, ctx, default):
        from .termui import prompt as _prompt

        text = self.prompt if isinstance(self.prompt, str) else self._prompt_text()
        if default is MISSING:
            default = None
        if self.multiple or self.nargs != 1:
            # Prompting for sequences is not offered; take a single token.
            pass
        return _prompt(
            text,
            default=default,
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            type=self.type,
        )

    def _prompt_text(self) -> str:
        return self.name.replace("_", " ").capitalize()

    def resolve(self, ctx, occs: t.List[t.Any]):
        """Return (value, source). ``value`` is MISSING when no source produced one."""
        given = [o for o in occs if o is not MISSING]
        if given:
            if any(o is NOVALUE for o in given) and self.prompt is not None:
                return self._prompt_value(ctx, MISSING), ParameterSource.PROMPT
            real = [o for o in given]
            if self.multiple:
                return self._convert_sequence(ctx, real), ParameterSource.COMMANDLINE
            if self.is_count:
                return sum(real), ParameterSource.COMMANDLINE
            return self._convert_occ(ctx, real[-1]), ParameterSource.COMMANDLINE

        env = self._env_value(ctx)
        if env is not MISSING:
            return env, ParameterSource.ENVIRONMENT

        fallback = MISSING
        source = ParameterSource.DEFAULT
        dm = ctx.default_map
        if isinstance(dm, dict) and self.name in dm:
            fallback = self._normalize_default(dm[self.name], ctx, from_map=True)
            source = ParameterSource.DEFAULT_MAP
        if fallback is MISSING:
            fallback = self._declared_default(ctx)
        if self.prompt is not None and self.prompt_required:
            return self._prompt_value(ctx, fallback), ParameterSource.PROMPT
        return fallback, source if fallback is not MISSING else None

    def process(self, ctx, value):
        """Run the parameter callback; it may replace or refuse the value."""
        if self.callback is not None:
            value = self.callback(ctx, self, value)
        return value


class Option(Parameter):
    is_option_like = True

    def __init__(
        self,
        param_decls: t.Sequence[str] = (),
        is_flag: t.Optional[bool] = None,
        flag_value: t.Any = None,
        count: bool = False,
        **attrs: t.Any,
    ) -> None:
        decls = list(param_decls)
        self.opts: t.List[str] = []
        self.secondary_opts: t.List[str] = []
        self.dest_hint: t.Optional[str] = None
        for decl in decls:
            if decl and decl[0] in PREFIX_CHARS or (decl and decl[0] in "/+" and len(decl) > 1):
                if "/" in decl[1:] and decl[0] in "-/+":
                    first, _, second = decl.partition("/")
                    if first:
                        self.opts.append(first)
                    if second:
                        self.secondary_opts.append(second)
                    continue
                self.opts.append(decl)
            else:
                self.dest_hint = decl
        if not self.opts and not self.secondary_opts and self.dest_hint is None:
            raise TypeError("an option needs at least one flag name or destination")
        super().__init__(decls, **attrs)
        if self.dest_hint is not None:
            self.name = self.dest_hint
        elif not self.name:
            self.name = self._infer_from_names()
        else:
            self.name = self.name

        if count and (is_flag or self.secondary_opts):
            raise TypeError("a counting option cannot be a flag")

        flag_like = bool(self.secondary_opts) or isinstance(self.default, bool)
        if is_flag is None:
            is_flag = flag_like
        self.is_flag: bool = bool(is_flag) and not count
        self.is_count: bool = bool(count)
        if self.is_flag:
            self.flag_value = True if flag_value is None else flag_value
            if attrs.get("type") is None:
                self.type = _types.BOOL
            self.nargs = 0
            if self.required and self.deprecated:
                raise TypeError("a deprecated option cannot be required")
        else:
            self.flag_value = flag_value
            if self.is_count:
                self.type = _types.INT
                self.nargs = 0
        if self.deprecated and self.required:
            raise TypeError("a deprecated option cannot be required")
        if self.deprecated and self.prompt is not None:
            raise TypeError("a deprecated option cannot use a prompt")

    def _infer_from_names(self) -> str:
        """Destination from the first long name, else the first short name (prefix stripped)."""
        names = self.opts + self.secondary_opts
        longs = [o for o in names if o.startswith("--") or (len(o) > 2 and o[1] in "-/+")]
        pick = (longs or names)[0]
        return pick.lstrip("-/+").replace("-", "_")

    @property
    def all_flag_names(self) -> t.List[str]:
        return self.opts + self.secondary_opts

    def get_error_hint(self) -> str:
        return " / ".join(repr(o) for o in self.opts) or repr(self.name)

    def get_metavar(self) -> t.Optional[str]:
        if self.metavar is not None:
            return self.metavar
        if self.is_flag or self.is_count:
            return None
        # A closed choice supplies its own placeholder; otherwise the destination
        # name in uppercase (PRD example: `--count COUNT`).
        if isinstance(self.type, _types.Choice):
            return self.type.get_metavar(self)
        return self.name.upper()

    def get_default_text(self, ctx) -> t.Optional[str]:
        if isinstance(self.show_default, str):
            return self.show_default
        show = self.show_default if self.show_default is not None else (ctx.show_default if ctx else False)
        if not show:
            return None
        value = self.default
        if callable(value):
            return "(dynamic)"
        if value is None:
            return None
        return str(value)

    def get_help_row(self, ctx) -> t.Tuple[str, str]:
        names = ", ".join(self.all_flag_names)
        metavar = None if self.is_flag else self.get_metavar()
        first = f"{names} {metavar}" if metavar else names
        parts = []
        if self.help:
            parts.append(self.help)
        default_text = self.get_default_text(ctx)
        if default_text is not None:
            parts.append(f"[default: {default_text}]")
        if self.show_envvar and self.envvars:
            parts.append(f"[env var: {', '.join(self.envvars)}]")
        if self.deprecated:
            parts.append("(DEPRECATED)")
        return first, " ".join(parts)


class Argument(Parameter):
    def __init__(
        self,
        param_decls: t.Sequence[str] = (),
        **attrs: t.Any,
    ) -> None:
        decls = list(param_decls)
        if len(decls) != 1:
            raise TypeError("an argument takes exactly one destination name")
        self._decl_name = decls[0]
        if self._decl_name.startswith("-"):
            raise TypeError("an argument cannot have an option prefix")
        super().__init__(decls, **attrs)
        self.name = self._decl_name
        nargs = attrs.get("nargs")
        if nargs is not None and nargs != -1 and nargs < 1:
            raise TypeError("nargs must be a positive integer or -1")
        self.is_variadic = self.nargs == -1
        self.is_flag = False
        self.is_count = False
        self.flag_value = None
        self.envvars = list(self.envvars)
        # An argument with neither a default nor an explicit optional marking is required.
        if attrs.get("required") is None:
            self.required = self.default is None and not self.is_variadic
        if self.deprecated and self.required:
            raise TypeError("a deprecated argument cannot be required")
        if self.deprecated and self.prompt is not None:
            raise TypeError("a deprecated argument cannot use a prompt")

    def get_error_hint(self) -> str:
        return self.name

    def get_argument_placeholder(self) -> str:
        if self.metavar is not None:
            return self.metavar
        return self.name.upper()

    def get_usage_piece(self) -> str:
        ph = self.get_argument_placeholder()
        if self.nargs == -1:
            body = ph + "..."
        elif self.nargs > 1:
            body = " ".join([ph] * self.nargs)
        else:
            body = ph
        return body if self.required else f"[{body}]"

    def get_help_row(self, ctx):
        return self.get_argument_placeholder(), self.help or ""

    @property
    def hidden_arg(self) -> bool:
        return self.hidden
