"""Declaration decorators: command, group, option, argument, and ready-made flags."""

from __future__ import annotations

import functools
import sys
import typing as t

from ._state import current_context
from .command import Command, CommandCollection, Group
from .context import Context
from .exceptions import Exit
from .params import Argument, Option
from .termui import confirm, echo

_PARAM_ATTR = "__optlyn_params__"
_SUFFIXES = ("_command", "_cmd", "_group", "_grp")


def _attach(f, param) -> None:
    params = getattr(f, _PARAM_ATTR, None)
    if params is None:
        params = []
        setattr(f, _PARAM_ATTR, params)
    params.append(param)


def _take_params(f) -> t.List:
    params = getattr(f, _PARAM_ATTR, None)
    if params is None:
        return []
    try:
        delattr(f, _PARAM_ATTR)
    except AttributeError:  # pragma: no cover
        pass
    params = list(params)
    params.reverse()
    return params


def _derive_name(func_name: str) -> str:
    name = func_name.lower()
    for suffix in _SUFFIXES:
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def command(name=None, cls=None, **attrs):
    """Turn a function into a Command. Usable as ``@command()`` or ``@command``."""
    if callable(name) and not isinstance(name, str):
        return command()(name)
    cls = cls or Command

    def decorator(f):
        cmd_name = name if name is not None else _derive_name(f.__name__)
        params = _take_params(f)
        cmd = cls(name=cmd_name, callback=f, params=params, **attrs)
        return cmd

    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a Group. Usable as ``@group()`` or ``@group``."""
    if callable(name) and not isinstance(name, str):
        return group()(name)
    cls = cls or Group

    def decorator(f):
        grp_name = name if name is not None else _derive_name(f.__name__)
        params = _take_params(f)
        return cls(name=grp_name, callback=f, params=params, **attrs)

    return decorator


def option(*param_decls, cls=None, **attrs):
    cls = cls or Option

    def decorator(f):
        _attach(f, cls(list(param_decls), **attrs))
        return f

    return decorator


def argument(*param_decls, cls=None, **attrs):
    cls = cls or Argument

    def decorator(f):
        _attach(f, cls(list(param_decls), **attrs))
        return f

    return decorator


def _print_and_exit_help(ctx: Context, param, value) -> None:
    if not value:
        return
    from .command import _print_help

    _print_help(ctx, sys.stdout)
    raise Exit(0)


def help_option(*param_decls, **kwargs):
    decls = list(param_decls) or ["--help"]
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("callback", _print_and_exit_help)
    return option(*decls, **kwargs)


def _detect_version(package_name: str) -> str:
    from importlib import metadata

    try:
        return metadata.version(package_name)
    except metadata.PackageNotFoundError:
        pass
    try:
        mapping = metadata.packages_distributions()
        for dist in mapping.get(package_name, []):
            return metadata.version(dist)
    except Exception:
        pass
    return "unknown"


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    decls = list(param_decls) or ["--version"]

    def callback(ctx: Context, param, value):
        if not value:
            return
        ver = version if version is not None else _detect_version(package_name or ctx.root.info_name or "")
        prog = prog_name or ctx.root.info_name or ""
        template = message or "%(prog)s, version %(version)s"
        echo(template % {"prog": prog, "package": package_name or prog, "version": ver})
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    return option(*decls, callback=callback, **kwargs)


def custom_version_option(callback_fn, *param_decls, **kwargs):
    decls = list(param_decls) or ["--version"]

    def callback(ctx: Context, param, value):
        if not value:
            return
        echo(callback_fn(ctx))
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    return option(*decls, callback=callback, **kwargs)


def password_option(*param_decls, **kwargs):
    decls = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    return option(*decls, **kwargs)


def confirmation_option(*param_decls, **kwargs):
    decls = list(param_decls) or ["--yes"]
    question = kwargs.pop("prompt", "Do you want to continue?")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("default", False)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Confirm the action without prompting.")

    def callback(ctx: Context, param, value):
        if value:
            return value
        confirm(question, abort=True)
        return True

    return option(*decls, callback=callback, **kwargs)


def pass_context(f):
    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(f):
    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return new_func


def _find_object(ctx: Context, object_type):
    node = ctx
    while node is not None:
        if isinstance(node.obj, object_type):
            return node.obj
        node = node.parent
    return None


def make_pass_decorator(object_type, ensure: bool = False):
    def decorator(f):
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            obj = _find_object(ctx, object_type)
            if obj is None and ensure:
                obj = object_type()
                ctx.obj = obj
            return f(obj, *args, **kwargs)

        return new_func

    return decorator


def get_current_context(silent: bool = False):
    return current_context(silent=silent)


__all__ = [
    "command",
    "group",
    "option",
    "argument",
    "help_option",
    "version_option",
    "custom_version_option",
    "password_option",
    "confirmation_option",
    "pass_context",
    "pass_obj",
    "make_pass_decorator",
    "get_current_context",
    "CommandCollection",
]
