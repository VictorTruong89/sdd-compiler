"""Text wrapping and help-page layout."""

from __future__ import annotations

import shutil
import textwrap
import typing as t

from .termui import _strip_ansi

FORM_FEED = "\f"
BACKSPACE = "\b"
MAX_HELP_WIDTH = 80
MAX_WRAP_WIDTH = 100
SHORT_HELP_LIMIT = 45


def _detect_width(max_width: int) -> int:
    try:
        cols = shutil.get_terminal_size((max_width, 24)).columns
    except OSError:  # pragma: no cover
        cols = max_width
    return max(20, min(cols, max_width))


def wrap_text(
    text: str,
    width: t.Optional[int] = None,
    indent: str = "",
    preserve_paragraphs: bool = False,
    max_width: int = MAX_WRAP_WIDTH,
) -> str:
    """Rewrap text to ``width`` (auto-detected, capped at ``max_width``).

    A paragraph whose first line is only a backspace is not rewrapped and its
    line breaks are kept; the backspace line itself is removed.
    """
    if text is None:
        return ""
    text = str(text)
    if width is None:
        width = _detect_width(max_width)
    out_paragraphs = []
    for para in _split_paragraphs(text):
        lines = para.split("\n")
        if lines and lines[0].strip() == BACKSPACE:
            kept = [ln for ln in lines[1:]]
            out_paragraphs.append("\n".join(indent + ln for ln in kept))
            continue
        joined = " ".join(ln.strip() for ln in lines if ln.strip())
        if not joined:
            continue
        out_paragraphs.append(
            textwrap.fill(
                joined,
                width=max(width, len(indent) + 1),
                initial_indent=indent,
                subsequent_indent=indent,
                break_long_words=False,
                break_on_hyphens=False,
            )
        )
    return "\n\n".join(out_paragraphs)


def _split_paragraphs(text: str) -> t.List[str]:
    paras: t.List[str] = []
    cur: t.List[str] = []
    for line in text.split("\n"):
        if line.strip() == "":
            if cur:
                paras.append("\n".join(cur))
                cur = []
        else:
            cur.append(line)
    if cur:
        paras.append("\n".join(cur))
    return paras


def clean_help(text: t.Optional[str]) -> str:
    """Drop everything after a form feed and dedent a docstring."""
    if not text:
        return ""
    text = text.split(FORM_FEED, 1)[0]
    return textwrap.dedent(text).strip("\n")


def short_help_text(text: str) -> str:
    """Start of the first paragraph, cut with '...' at SHORT_HELP_LIMIT characters."""
    first = clean_help(text).strip().split("\n\n", 1)[0]
    flat = " ".join(line.strip() for line in first.split("\n")).strip()
    if len(flat) > SHORT_HELP_LIMIT:
        flat = flat[: SHORT_HELP_LIMIT - 3].rstrip() + "..."
    return flat


def _column(rows: t.List[t.Tuple[str, str]], indent: str = "  ", max_col: int = 30) -> t.List[str]:
    if not rows:
        return []
    first_w = min(max(len(a) for a, _ in rows), max_col)
    out = []
    for first, second in rows:
        if second:
            if len(first) <= first_w:
                out.append(f"{indent}{first.ljust(first_w)}  {second}")
            else:
                out.append(f"{indent}{first}")
                out.append(f"{indent}{' ' * first_w}  {second}")
        else:
            out.append(f"{indent}{first}")
    return out


class HelpFormatter:
    """Builds the help page text for a command, group or context."""

    def __init__(self, width: int = None, max_width: int = MAX_HELP_WIDTH) -> None:
        self.width = width if width is not None else _detect_width(max_width)

    def format_help(self, ctx) -> str:
        cmd = ctx.command
        parts: t.List[str] = []
        parts.append(self.usage_line(ctx))
        desc = cmd.get_help_text()
        if cmd.deprecated:
            note = cmd.deprecated if isinstance(cmd.deprecated, str) else "This command is deprecated."
            desc = (desc + "\n\n" if desc else "") + f"DEPRECATED: {note}"
        if desc:
            parts.append("")
            parts.append(wrap_text(desc, width=self.width, indent=""))
        arg_rows = [
            (a.get_argument_placeholder(), a.help)
            for a in cmd.get_arguments()
            if a.help and not a.hidden
        ]
        if arg_rows:
            parts.append("")
            parts.append("Positional arguments:")
            parts.extend(_column(arg_rows))
        opt_rows = []
        for p in cmd.get_params(ctx):
            if getattr(p, "hidden", False) or not p.is_option_like or not p.expose_help:
                continue
            opt_rows.append(p.get_help_row(ctx))
        if opt_rows:
            parts.append("")
            parts.append("Options:")
            parts.extend(_column(opt_rows))
        if hasattr(cmd, "list_commands"):
            subrows = []
            for name in cmd.list_commands(ctx):
                sub = cmd.get_command(ctx, name)
                if sub is None or sub.hidden:
                    continue
                subrows.append((name, sub.get_short_help_str()))
            if subrows:
                parts.append("")
                parts.append("Commands:")
                parts.extend(_column(subrows))
        if cmd.epilog:
            parts.append("")
            parts.append(wrap_text(cmd.epilog, width=self.width))
        return "\n".join(parts) + "\n"

    def usage_line(self, ctx) -> str:
        cmd = ctx.command
        pieces = [ctx.command_path]
        opt_placeholder = cmd.options_metavar or "[OPTIONS]"
        if cmd.options_metavar is None:
            pieces.append("[OPTIONS]")
        else:
            pieces.append(opt_placeholder)
        if hasattr(cmd, "list_commands"):
            if cmd.invoke_without_command:
                pieces.append("[COMMAND [ARGS]...]")
            elif cmd.chain:
                pieces.append("COMMAND [ARGS]... [COMMAND [ARGS]...]...")
            else:
                pieces.append("COMMAND [ARGS]...")
        for a in cmd.get_arguments():
            pieces.append(a.get_usage_piece())
        return "Usage: " + " ".join(pieces)
