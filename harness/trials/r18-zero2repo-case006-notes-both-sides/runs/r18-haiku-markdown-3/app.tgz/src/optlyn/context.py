"""Invocation context."""

from __future__ import annotations

import contextlib
import enum
import typing as t

from . import _state
from .exceptions import Abort, Exit

DEFAULT_HELP_NAMES = ["--help"]
DEFAULT_MAX_CONTENT_WIDTH = 80


class ParameterSource(enum.Enum):
    """Where a parameter's value came from."""

    PROMPT = "prompt"
    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"


class Context:
    """Per-invocation state. Children link to their parents."""

    def __init__(
        self,
        command,
        parent: t.Optional["Context"] = None,
        info_name: t.Optional[str] = None,
        obj: t.Any = None,
        default_map: t.Optional[dict] = None,
        terminal_width: t.Optional[int] = None,
        max_content_width: t.Optional[int] = None,
        help_option_names: t.Optional[t.Sequence[str]] = None,
        token_normalize_func: t.Optional[t.Callable[[str], str]] = None,
        color: t.Optional[bool] = None,
        show_default: t.Optional[bool] = None,
        allow_extra_args: t.Optional[bool] = None,
        ignore_unknown_options: t.Optional[bool] = None,
        allow_interspersed_args: t.Optional[bool] = None,
        auto_envvar_prefix: t.Optional[str] = None,
        **extra: t.Any,
    ) -> None:
        self.command = command
        self.parent = parent
        self.info_name = info_name if info_name is not None else (command.name if command else None)

        def inherit(value, attr):
            if value is not None:
                return value
            return getattr(parent, attr) if parent is not None else None

        self.obj = obj if obj is not None else (parent.obj if parent is not None else None)
        self.default_map = default_map
        self.terminal_width = inherit(terminal_width, "terminal_width")
        self.max_content_width = inherit(max_content_width, "max_content_width")
        self.help_option_names = list(
            help_option_names
            if help_option_names is not None
            else (parent.help_option_names if parent is not None else DEFAULT_HELP_NAMES)
        )
        self.token_normalize_func = inherit(token_normalize_func, "token_normalize_func")
        self.color = inherit(color, "color")
        self.show_default = inherit(show_default, "show_default")
        self.auto_envvar_prefix = (
            auto_envvar_prefix if auto_envvar_prefix is not None
            else (parent.auto_envvar_prefix if parent is not None else None)
        )

        def pick(value, attr, default):
            if value is not None:
                return value
            return getattr(command, attr, default) if command is not None else default

        self.allow_extra_args = pick(allow_extra_args, "allow_extra_args", False)
        self.ignore_unknown_options = pick(ignore_unknown_options, "ignore_unknown_options", False)
        self.allow_interspersed_args = pick(allow_interspersed_args, "allow_interspersed_args", True)
        self.extra = extra

        self.params: t.Dict[str, t.Any] = {}
        self._sources: t.Dict[str, ParameterSource] = {}
        self.invoked_subcommand: t.Any = None
        self.args: t.List[str] = []
        self._remaining: t.List[str] = []
        self._had_args: bool = False
        self._path_names: t.List[str] = (
            parent._path_names + [self.info_name]
            if parent is not None and self.info_name is not None
            else []
        )
        self._exit_stack: t.Optional[contextlib.ExitStack] = (
            None if parent is not None else contextlib.ExitStack()
        )

    # --- structure -----------------------------------------------------

    @property
    def root(self) -> "Context":
        ctx = self
        while ctx.parent is not None:
            ctx = ctx.parent
        return ctx

    @property
    def command_path(self) -> str:
        names = [self.root.info_name or ""] + self._path_names
        return " ".join(n for n in names if n)

    def env_name_for(self, dest: str) -> str:
        """Environment name built from the automatic prefix, path names, and destination."""
        prefix = self.root.auto_envvar_prefix
        parts = ([prefix] if prefix else []) + self._path_names + [dest]
        return "_".join(p.replace("-", "_").upper() for p in parts)

    # --- sources ---------------------------------------------------------

    def get_parameter_source(self, name: str) -> t.Optional[ParameterSource]:
        if name not in self.command_param_names():
            return None
        return self._sources.get(name)

    def command_param_names(self) -> t.Set[str]:
        return {p.name for p in self.command.params} if self.command is not None else set()

    def _set_source(self, name: str, source: ParameterSource) -> None:
        self._sources[name] = source

    # --- resources and control --------------------------------------------

    def with_resource(self, cm):
        root = self.root
        if root._exit_stack is None:  # pragma: no cover
            root._exit_stack = contextlib.ExitStack()
        return root._exit_stack.enter_context(cm)

    def close(self) -> None:
        root = self.root
        if root._exit_stack is not None:
            stack = root._exit_stack
            root._exit_stack = contextlib.ExitStack()
            stack.close()

    def exit(self, code: int = 0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    # --- nested invocation --------------------------------------------------

    def invoke(self, cmd, **values):
        """Run ``cmd`` with exactly the values supplied (no conversion)."""
        from .command import _fill_context_values

        sub = _fill_context_values(cmd, self, values)
        return cmd.invoke(sub)

    def forward(self, cmd, **values):
        """Run ``cmd`` with this context's values, overridden by ``values``."""
        merged = {k: v for k, v in self.params.items() if k in {p.name for p in cmd.params}}
        merged.update(values)
        return self.invoke(cmd, **merged)

    # --- context manager ----------------------------------------------------

    def __enter__(self):
        _state.push_context(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        _state.pop_context(self)
        return False

    def __repr__(self) -> str:
        return f"<Context {self.command_path!r}>"
