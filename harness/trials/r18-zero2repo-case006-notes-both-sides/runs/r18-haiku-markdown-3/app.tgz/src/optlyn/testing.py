"""In-process runner for invoking commands with argument tokens."""

from __future__ import annotations

import contextlib
import io
import os
import shutil
import sys
import tempfile
import typing as t


class Result:
    def __init__(self, runner, exit_code, output_chunks, exception, exc_info=None):
        self.runner = runner
        self.exit_code = exit_code
        self._chunks = output_chunks  # list of (channel, bytes)
        self.exception = exception
        self.exc_info = exc_info

    @property
    def stdout_bytes(self) -> bytes:
        return b"".join(b for ch, b in self._chunks if ch == "out")

    @property
    def stderr_bytes(self) -> bytes:
        return b"".join(b for ch, b in self._chunks if ch == "err")

    @property
    def output_bytes(self) -> bytes:
        return b"".join(b for _, b in self._chunks)

    @property
    def stdout(self) -> str:
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self) -> str:
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    @property
    def output(self) -> str:
        return self.output_bytes.decode(self.runner.charset, "replace")

    def __repr__(self) -> str:
        return f"<Result exit_code={self.exit_code}>"


class _ChannelStream(io.TextIOBase):
    def __init__(self, channel: str, sink: list, charset: str, fileno=None):
        self._channel = channel
        self._sink = sink
        self._charset = charset
        self._fileno = fileno
        self.buffer = _BytesChannel(channel, sink)

    def writable(self):
        return True

    def write(self, s):
        data = s.encode(self._charset, "replace")
        self._sink.append((self._channel, data))
        return len(s)

    def flush(self):
        pass

    @property
    def encoding(self):
        return self._charset

    def isatty(self):
        return False

    def fileno(self):
        if self._fileno is None:
            raise io.UnsupportedOperation("fileno")
        return self._fileno


class _BytesChannel(io.RawIOBase):
    def __init__(self, channel, sink):
        self._channel = channel
        self._sink = sink

    def writable(self):
        return True

    def write(self, b):
        self._sink.append((self._channel, bytes(b)))
        return len(b)

    def flush(self):
        pass


class CliRunner:
    """Invoke a command in process, capturing standard streams and the exit status."""

    def __init__(
        self,
        charset: str = "utf-8",
        env: t.Optional[dict] = None,
        echo_stdin: bool = False,
        catch_exceptions: bool = True,
        capture: str = "sys",
    ) -> None:
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        chunks: list = []
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        else:
            data = input
        stdin = io.TextIOWrapper(io.BytesIO(data), encoding=self.charset)
        saved_env = {}
        merged = dict(self.env)
        merged.update(env or {})
        for k, v in merged.items():
            saved_env[k] = os.environ.get(k)
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = str(v)
        old_in, old_out, old_err = sys.stdin, sys.stdout, sys.stderr
        fd_files = []
        try:
            if self.capture == "fd":
                tmp_out = tempfile.TemporaryFile()
                tmp_err = tempfile.TemporaryFile()
                fd_files = [tmp_out, tmp_err]
                saved_fds = (os.dup(1), os.dup(2))
                try:
                    old_out.flush()
                    old_err.flush()
                except Exception:
                    pass
                os.dup2(tmp_out.fileno(), 1)
                os.dup2(tmp_err.fileno(), 2)
                out_stream = io.TextIOWrapper(os.fdopen(os.dup(1), "wb", buffering=0), encoding=self.charset, write_through=True)
                err_stream = io.TextIOWrapper(os.fdopen(os.dup(2), "wb", buffering=0), encoding=self.charset, write_through=True)
                sys.stdout, sys.stderr = out_stream, err_stream
                sys.stdin = stdin
                try:
                    yield chunks
                finally:
                    out_stream.flush()
                    err_stream.flush()
                    out_stream.close()
                    err_stream.close()
                    os.dup2(saved_fds[0], 1)
                    os.dup2(saved_fds[1], 2)
                    os.close(saved_fds[0])
                    os.close(saved_fds[1])
                    tmp_out.seek(0)
                    tmp_err.seek(0)
                    chunks.append(("out", tmp_out.read()))
                    chunks.append(("err", tmp_err.read()))
            else:
                out_stream = _ChannelStream("out", chunks, self.charset)
                err_stream = _ChannelStream("err", chunks, self.charset)
                sys.stdin = stdin
                sys.stdout = out_stream
                sys.stderr = err_stream
                yield chunks
        finally:
            sys.stdin, sys.stdout, sys.stderr = old_in, old_out, old_err
            for f in fd_files:
                try:
                    f.close()
                except Exception:
                    pass
            for k, v in saved_env.items():
                if v is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = v

    def invoke(
        self,
        cli,
        args=None,
        input=None,
        env=None,
        catch_exceptions: t.Optional[bool] = None,
        color: bool = False,
        **extra,
    ) -> Result:
        exc_info = None
        exit_code = 0
        exception = None
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        prog_name = extra.pop("prog_name", "cli")
        standalone = extra.pop("standalone_mode", True)
        if isinstance(args, str):
            import shlex

            args = shlex.split(args)
        args = list(args or [])
        if color is not None:
            extra.setdefault("color", color)
        with self.isolation(input=input, env=env, color=color) as chunks:
            try:
                rv = cli.main(
                    args=args,
                    prog_name=prog_name,
                    standalone_mode=standalone,
                    **extra,
                )
                if not standalone:
                    exit_code = 0
                    _ = rv
            except SystemExit as e:
                code = e.code
                if code is None:
                    exit_code = 0
                elif isinstance(code, int):
                    exit_code = code
                else:
                    sys.stderr.write(str(code) + "\n")
                    exit_code = 1
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
        return Result(self, exit_code, chunks, exception, exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        if temp_dir is None:
            path = tempfile.mkdtemp()
            remove = True
        else:
            path = tempfile.mkdtemp(dir=os.fspath(temp_dir))
            remove = False
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if remove:
                shutil.rmtree(path, ignore_errors=True)


@contextlib.contextmanager
def isolated_filesystem(temp_dir=None):
    """Module-level helper with the same behaviour as ``CliRunner.isolated_filesystem``."""
    with CliRunner().isolated_filesystem(temp_dir) as path:
        yield path
