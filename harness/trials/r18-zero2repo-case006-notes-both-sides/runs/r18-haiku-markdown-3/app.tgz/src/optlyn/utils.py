"""File opening, filename formatting, app directories, and launching."""

from __future__ import annotations

import contextlib
import io
import os
import subprocess
import sys
import tempfile
import typing as t


class _NonClosing(io.TextIOWrapper):
    pass


@contextlib.contextmanager
def _nonclosing(stream):
    """Yield a stream that is not closed when the block ends."""
    yield stream


class LazyFile:
    """A file that opens on first I/O (used for lazy write mode)."""

    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False):
        self.name = filename
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self._tmp = None
        self.closed = False

    def _open(self):
        if self._f is not None:
            return self._f
        try:
            if self.atomic:
                d = os.path.dirname(os.path.abspath(self.name))
                fd, tmp = tempfile.mkstemp(dir=d, prefix=".optlyn-", suffix=".tmp")
                os.close(fd)
                self._tmp = tmp
                target = tmp
            else:
                target = self.name
            if "b" in self.mode:
                self._f = open(target, self.mode)
            else:
                self._f = open(target, self.mode, encoding=self.encoding, errors=self.errors)
        except OSError as e:
            from .exceptions import FileError

            raise FileError(self.name, e.strerror or str(e)) from e
        return self._f

    def __getattr__(self, item):
        return getattr(self._open(), item)

    def write(self, data):
        return self._open().write(data)

    def read(self, *args):
        return self._open().read(*args)

    def __iter__(self):
        return iter(self._open())

    def close(self):
        if self.closed:
            return
        self.closed = True
        if self._f is not None:
            self._f.close()
            if self._tmp is not None:
                os.replace(self._tmp, self.name)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()


def _std_stream(name: str, mode: str, encoding=None, errors="strict"):
    stream = sys.stdin if "r" in mode else sys.stdout
    if "b" in mode:
        return getattr(stream, "buffer", stream)
    return stream


class _StdWrapper:
    """Wraps a standard stream so that closing it does not close the process stream."""

    def __init__(self, stream):
        self._s = stream

    def __getattr__(self, item):
        return getattr(self._s, item)

    def __iter__(self):
        return iter(self._s)

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        pass


def open_file(
    filename,
    mode: str = "r",
    encoding=None,
    errors: str = "strict",
    lazy: bool = False,
    atomic: bool = False,
):
    """Open a file, or the standard stream for ``-``.

    Read-mode files open immediately. Write-mode files open on first I/O when lazy.
    """
    if isinstance(filename, bytes):
        filename = os.fsdecode(filename)
    if filename == "-":
        if "r" in mode:
            return _StdWrapper(_std_stream("stdin", mode, encoding, errors))
        if "b" in mode:
            return _StdWrapper(getattr(sys.stdout, "buffer", sys.stdout))
        return _StdWrapper(sys.stdout)
    if lazy and ("w" in mode):
        return LazyFile(filename, mode, encoding, errors, atomic)
    if atomic and "w" in mode:
        d = os.path.dirname(os.path.abspath(filename))
        fd, tmp = tempfile.mkstemp(dir=d, prefix=".optlyn-", suffix=".tmp")
        os.close(fd)
        if "b" in mode:
            f = open(tmp, mode)
        else:
            f = open(tmp, mode, encoding=encoding, errors=errors)
        orig_close = f.close

        def _close_and_replace():
            orig_close()
            os.replace(tmp, filename)

        f.close = _close_and_replace  # type: ignore[method-assign]
        return f
    try:
        if "b" in mode:
            return open(filename, mode)
        return open(filename, mode, encoding=encoding, errors=errors)
    except OSError as e:
        from .exceptions import FileError

        raise FileError(filename, e.strerror or str(e)) from e


def format_filename(filename, shorten: bool = False) -> str:
    """Return printable text for a filename, never failing on undecodable names."""
    if hasattr(filename, "__fspath__"):
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        text = os.fsdecode(filename)
    else:
        text = str(filename)
    if shorten:
        text = os.path.basename(text)
    # Escape anything the process encoding cannot print, keep ordinary text intact.
    return text.encode("utf-8", "surrogateescape").decode("utf-8", "backslashreplace")


def get_app_dir(app_name: str, roaming: bool = True, force_posix: bool = False) -> str:
    """Return the per-user config directory for ``app_name``."""
    home = os.path.expanduser("~")
    unix_folder = "-".join(app_name.lower().split())
    if force_posix:
        return os.path.join(home, "." + unix_folder)
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    if sys.platform.startswith("win"):
        base = os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming")
        return os.path.join(base, app_name)
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(base, unix_folder)


def launch(url: str, wait: bool = False, locate: bool = False) -> int:
    """Open ``url`` with the default desktop application (Linux: xdg-open)."""
    if sys.platform == "darwin":
        args = ["open"]
    elif sys.platform.startswith("win"):
        args = ["cmd", "/c", "start", ""]
    else:
        args = ["xdg-open"]
    if locate and sys.platform == "darwin":
        args.append("-R")
    args.append(url)
    try:
        proc = subprocess.Popen(args)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0
