import sys


def _echo(msg, file):
    from .utils import echo
    echo(msg, file=file)


class OptlynException(Exception):
    exit_code = 1

    def __init__(self, message=""):
        super().__init__(message)
        self.message = message

    def format_message(self):
        return self.message

    def __str__(self):
        return self.message

    def show(self, file=None):
        if file is None:
            file = sys.stderr
        _echo(f"Error: {self.format_message()}", file)


class UsageError(OptlynException):
    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.ctx = ctx
        self.cmd = self.ctx.command if self.ctx else None

    def show(self, file=None):
        if file is None:
            file = sys.stderr
        hint = ""
        if (self.ctx is not None and self.ctx.command.get_help_option(self.ctx) is not None):
            names = self.ctx.help_option_names
            if names:
                hint = f"Try '{self.ctx.command_path} {names[0]}' for help.\n"
        if self.ctx is not None:
            _echo(f"{self.ctx.get_usage()}\n{hint}", file)
        _echo(f"Error: {self.format_message()}", file)


class NoArgsIsHelpError(UsageError):
    def __init__(self, ctx):
        self.ctx_help = ctx.get_help()
        super().__init__(self.ctx_help, ctx)

    def show(self, file=None):
        if file is None:
            file = sys.stderr
        _echo(self.ctx_help, file)


def _join_param_hints(param_hint):
    if param_hint is not None and not isinstance(param_hint, str):
        return " / ".join(repr(x) for x in param_hint)
    return param_hint


class BadParameter(UsageError):
    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        if self.param_hint is not None:
            hint = self.param_hint
        elif self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        else:
            return f"Invalid value: {self.message}"
        return f"Invalid value for {_join_param_hints(hint)}: {self.message}"


class MissingParameter(BadParameter):
    def __init__(self, message=None, ctx=None, param=None, param_hint=None, param_type=None):
        super().__init__(message or "", ctx, param, param_hint)
        self.param_type = param_type

    def format_message(self):
        if self.param_hint is not None:
            hint = self.param_hint
        elif self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        else:
            hint = None
        hint = _join_param_hints(hint)
        hint = f" {hint}" if hint else ""
        ptype = self.param_type
        if ptype is None and self.param is not None:
            ptype = self.param.param_type_name
        msg = self.message
        if self.param is not None:
            extra = self.param.type.get_missing_message(self.param)
            if extra:
                msg = f"{msg}. {extra}" if msg else extra
        msg = f" {msg}" if msg else ""
        return f"Missing {ptype}{hint}.{msg}"

    __str__ = format_message


class NoSuchOption(UsageError):
    def __init__(self, option_name, message=None, possibilities=None, ctx=None):
        if message is None:
            message = f"No such option: {option_name}"
        super().__init__(message, ctx)
        self.option_name = option_name
        self.possibilities = possibilities

    def format_message(self):
        if not self.possibilities:
            return self.message
        possibilities = sorted(self.possibilities)
        if len(possibilities) == 1:
            return f"{self.message} Did you mean {possibilities[0]}?"
        return f"{self.message} (Possible options: {', '.join(possibilities)})"


class BadOptionUsage(UsageError):
    def __init__(self, option_name, message, ctx=None):
        super().__init__(message, ctx)
        self.option_name = option_name


class BadArgumentUsage(UsageError):
    pass


class FileError(OptlynException):
    def __init__(self, filename, hint=None):
        if hint is None:
            hint = "unknown error"
        super().__init__(hint)
        from .utils import format_filename
        self.ui_filename = format_filename(filename)
        self.filename = filename

    def format_message(self):
        return f"Could not open file {self.ui_filename!r}: {self.message}"


class Abort(RuntimeError):
    """Signals an abort."""


class Exit(RuntimeError):
    __slots__ = ("exit_code",)

    def __init__(self, code=0):
        self.exit_code = code
