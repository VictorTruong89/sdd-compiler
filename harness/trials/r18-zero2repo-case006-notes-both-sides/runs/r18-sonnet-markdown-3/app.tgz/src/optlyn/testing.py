import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile
import threading

from . import formatting, termui, utils


class EchoingStdin:
    def __init__(self, input, output):
        self._input = input
        self._output = output
        self._paused = False

    def __getattr__(self, x):
        return getattr(self._input, x)

    def _echo(self, rv):
        if not self._paused:
            self._output.write(rv)
        return rv

    def read(self, n=-1):
        return self._echo(self._input.read(n))

    def read1(self, n=-1):
        return self._echo(self._input.read1(n))

    def readline(self, n=-1):
        return self._echo(self._input.readline(n))

    def readlines(self):
        return [self._echo(x) for x in self._input.readlines()]

    def __iter__(self):
        return iter(self._echo(x) for x in self._input)


class _Tee(io.BytesIO):
    def __init__(self, also=None):
        super().__init__()
        self.also = also

    def write(self, b):
        n = super().write(b)
        if self.also is not None:
            self.also.write(b)
        return n


class _NamedTextIOWrapper(io.TextIOWrapper):
    def __init__(self, buffer, name=None, mode=None, **kwargs):
        super().__init__(buffer, **kwargs)
        self._name = name
        self._mode = mode

    @property
    def name(self):
        return self._name

    @property
    def mode(self):
        return self._mode


def make_input_stream(input, charset):
    if hasattr(input, "read"):
        rv = input.read()
        if isinstance(rv, str):
            rv = rv.encode(charset)
        return io.BytesIO(rv)
    if input is None:
        input = b""
    elif isinstance(input, str):
        input = input.encode(charset)
    return io.BytesIO(input)


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value, exit_code,
                 exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self):
        return self.output_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    def __repr__(self):
        name = type(self.exception).__name__ if self.exception else "okay"
        return f"<Result {name}>"


class _FdCapture:
    """Capture OS-level writes to descriptors 1 and 2 through pipes."""

    def __init__(self, out, err, mixed):
        self.out, self.err, self.mixed = out, err, mixed
        self.lock = threading.Lock()
        self.saved = {}
        self.threads = []
        self.wfds = {}

    def _reader(self, rfd, sink):
        while True:
            try:
                data = os.read(rfd, 65536)
            except OSError:
                break
            if not data:
                break
            with self.lock:
                sink.write(data)
                self.mixed.write(data)
        os.close(rfd)

    def start(self):
        for fd, sink in ((1, self.out), (2, self.err)):
            self.saved[fd] = os.dup(fd)
            r, w = os.pipe()
            os.dup2(w, fd)
            os.close(w)
            t = threading.Thread(target=self._reader, args=(r, sink), daemon=True)
            t.start()
            self.threads.append(t)

    def stop(self):
        for fd in (1, 2):
            os.dup2(self.saved[fd], fd)
            os.close(self.saved[fd])
        for t in self.threads:
            t.join(timeout=5)


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        self.charset = charset
        self.env = env or {}
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def make_env(self, overrides=None):
        rv = dict(self.env)
        if overrides:
            rv.update(overrides)
        return rv

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        bytes_input = make_input_stream(input, self.charset)
        echo_input = None
        old = (sys.stdin, sys.stdout, sys.stderr, formatting.FORCED_WIDTH)
        formatting.FORCED_WIDTH = 80
        env = self.make_env(env)
        bytes_output = _Tee()
        fd_mode = self.capture == "fd"
        bytes_stdout = _Tee(None if fd_mode else bytes_output)
        bytes_stderr = _Tee(None if fd_mode else bytes_output)
        capture = None
        if self.echo_stdin:
            bytes_input = echo_input = EchoingStdin(bytes_input, bytes_stdout)
        sys.stdin = text_input = _NamedTextIOWrapper(bytes_input, encoding=self.charset,
                                                     name="<stdin>", mode="r")
        if self.echo_stdin:
            text_input._CHUNK_SIZE = 1
        if self.capture == "fd":
            capture = _FdCapture(bytes_stdout, bytes_stderr, bytes_output)
            sys.stdout.flush()
            sys.stderr.flush()
            capture.start()
            sys.stdout = _NamedTextIOWrapper(io.FileIO(1, "w", closefd=False), encoding=self.charset,
                                             name="<stdout>", mode="w", write_through=True)
            sys.stderr = _NamedTextIOWrapper(io.FileIO(2, "w", closefd=False), encoding=self.charset,
                                             name="<stderr>", mode="w", errors="backslashreplace",
                                             write_through=True)
        else:
            sys.stdout = _NamedTextIOWrapper(bytes_stdout, encoding=self.charset, name="<stdout>",
                                             mode="w", write_through=True)
            sys.stderr = _NamedTextIOWrapper(bytes_stderr, encoding=self.charset, name="<stderr>",
                                             mode="w", errors="backslashreplace", write_through=True)

        def visible_input(prompt=None):
            if echo_input is not None:
                echo_input._paused = True
            try:
                sys.stdout.write(prompt or "")
                line = text_input.readline()
                if line == "":
                    raise EOFError()
                val = line.rstrip("\r\n")
            finally:
                if echo_input is not None:
                    echo_input._paused = False
            sys.stdout.write(f"{val}\n")
            sys.stdout.flush()
            return val

        def hidden_input(prompt=None):
            sys.stdout.write(f"{prompt or ''}\n")
            sys.stdout.flush()
            if echo_input is not None:
                echo_input._paused = True
            try:
                line = text_input.readline()
            finally:
                if echo_input is not None:
                    echo_input._paused = False
            if line == "":
                raise EOFError()
            return line.rstrip("\r\n")

        def _getchar(echo):
            char = sys.stdin.read(1)
            if echo:
                sys.stdout.write(char)
            return char

        default_color = color

        def should_strip_ansi(stream=None, color=None):
            if color is None:
                return not default_color
            return not color

        olds = (termui.visible_prompt_func, termui.hidden_prompt_func, termui._getchar,
                utils.should_strip_ansi)
        termui.visible_prompt_func = visible_input
        termui.hidden_prompt_func = hidden_input
        termui._getchar = _getchar
        utils.should_strip_ansi = should_strip_ansi
        old_env = {}
        try:
            for key, value in env.items():
                old_env[key] = os.environ.get(key)
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            yield (bytes_stdout, bytes_stderr, bytes_output)
        finally:
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            try:
                sys.stdout.flush()
                sys.stderr.flush()
            except Exception:
                pass
            if capture is not None:
                capture.stop()
                self._fd_result = (bytes_stdout.getvalue(), bytes_stderr.getvalue(), bytes_output.getvalue())
            else:
                self._sys_result = (bytes_stdout.getvalue(), bytes_stderr.getvalue(), bytes_output.getvalue())
            (termui.visible_prompt_func, termui.hidden_prompt_func, termui._getchar,
             utils.should_strip_ansi) = olds
            sys.stdin, sys.stdout, sys.stderr, formatting.FORCED_WIDTH = old

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False,
               **extra):
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        exc_info = None
        with self.isolation(input=input, env=env, color=color) as outstreams:
            return_value = None
            exception = None
            exit_code = 0
            if isinstance(args, str):
                args = shlex.split(args)
            prog_name = extra.pop("prog_name", None)
            if prog_name is None:
                prog_name = self.get_default_prog_name(cli)
            try:
                return_value = cli.main(args=args or (), prog_name=prog_name, **extra)
            except SystemExit as e:
                exc_info = sys.exc_info()
                code = e.code
                if code is None:
                    code = 0
                if code != 0:
                    exception = e
                if not isinstance(code, int):
                    sys.stdout.write(str(code))
                    sys.stdout.write("\n")
                    code = 1
                exit_code = code
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                sys.stdout.flush()
                sys.stderr.flush()
                if self.capture == "fd":
                    outstreams = outstreams + (None,)
        if self.capture == "fd":
            out_b, err_b, all_b = self._fd_result
        else:
            out_b, err_b, all_b = self._sys_result
        return Result(self, out_b, err_b, all_b, return_value, exit_code, exception, exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass
