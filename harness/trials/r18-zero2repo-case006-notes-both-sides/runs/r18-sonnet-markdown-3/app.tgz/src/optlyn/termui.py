import inspect
import io
import itertools
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
import time
import contextlib

from .exceptions import Abort, UsageError, OptlynException
from .formatting import strip_ansi
from .globals import resolve_color_default
from . import utils
from .utils import echo, isatty
from .types import convert_type, Choice

visible_prompt_func = input


def _hidden(prompt):
    import getpass
    return getpass.getpass(prompt)


hidden_prompt_func = _hidden


def _build_prompt(text, suffix, show_default=False, default=None, show_choices=True, type=None):
    prompt = text
    if type is not None and show_choices and isinstance(type, Choice):
        prompt += f" ({', '.join(map(str, type.choices))})"
    if default is not None and show_default:
        d = getattr(default, "name", default) if hasattr(default, "read") or hasattr(default, "write") else default
        prompt = f"{prompt} [{d}]"
    return f"{prompt}{suffix}"


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False, show_choices=True):
    def prompt_func(text):
        f = hidden_prompt_func if hide_input else visible_prompt_func
        try:
            echo(text.rstrip(" "), nl=False, err=err)
            return f(" ")
        except (KeyboardInterrupt, EOFError):
            if hide_input:
                echo(None, err=err)
            raise Abort() from None

    if value_proc is None:
        value_proc = convert_type(type, default)
    p = _build_prompt(text, prompt_suffix, show_default, default, show_choices, type)
    if confirmation_prompt:
        if confirmation_prompt is True:
            confirmation_prompt = "Repeat for confirmation"
        confirmation_prompt = _build_prompt(confirmation_prompt, prompt_suffix)
    while True:
        while True:
            value = prompt_func(p)
            if value:
                break
            elif default is not None:
                value = default
                break
        try:
            result = value_proc(value)
        except UsageError as e:
            if hide_input:
                echo("Error: The value you entered was invalid.", err=err)
            else:
                echo(f"Error: {e.message}", err=err)
            continue
        if not confirmation_prompt:
            return result
        while True:
            value2 = prompt_func(confirmation_prompt)
            is_empty = not value and not value2
            if value2 or is_empty:
                break
        if value == value2:
            return result
        echo("Error: The two entered values do not match.", err=err)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    p = _build_prompt(text, prompt_suffix, show_default, "y/n" if default is None else ("Y/n" if default else "y/N"))
    while True:
        try:
            echo(p.rstrip(" "), nl=False, err=err)
            value = visible_prompt_func(" ").lower().strip()
        except (KeyboardInterrupt, EOFError):
            raise Abort() from None
        if value in ("y", "yes"):
            rv = True
        elif value in ("n", "no"):
            rv = False
        elif default is not None and value == "":
            rv = default
        else:
            echo("Error: invalid input", err=err)
            continue
        break
    if abort and not rv:
        raise Abort()
    return rv


# ---- pager -------------------------------------------------------------

def _interactive():
    return isatty(sys.stdin) or isatty(sys.stdout)


class _PagerStream:
    """Writable text stream that forwards to a pager process (flushing each write)."""

    def __init__(self, proc, color):
        self._proc = proc
        self._color = color
        self.closed = False

    def write(self, text):
        if not isinstance(text, str):
            text = str(text)
        if not self._color:
            text = strip_ansi(text)
        try:
            self._proc.stdin.write(text)
            self._proc.stdin.flush()
        except BrokenPipeError:
            pass
        return len(text)

    def writelines(self, lines):
        for l in lines:
            self.write(l)

    def flush(self):
        try:
            self._proc.stdin.flush()
        except Exception:
            pass

    def isatty(self):
        return False

    def writable(self):
        return True


class _PlainStream:
    def __init__(self, color):
        self._color = color

    def write(self, text):
        if not isinstance(text, str):
            text = str(text)
        out = sys.stdout
        if utils.should_strip_ansi(out, self._color):
            text = strip_ansi(text)
        out.write(text)
        out.flush()
        return len(text)

    def writelines(self, lines):
        for l in lines:
            self.write(l)

    def flush(self):
        sys.stdout.flush()

    def isatty(self):
        return isatty(sys.stdout)

    def writable(self):
        return True


@contextlib.contextmanager
def get_pager_file(color=None):
    color = resolve_color_default(color)
    cmd = (os.environ.get("PAGER") or "").strip()
    if not cmd and _interactive():
        for c in ("less", "more"):
            if shutil.which(c):
                cmd = c
                break
    if not _interactive() or not cmd:
        yield _PlainStream(color)
        sys.stdout.flush()
        return
    env = dict(os.environ)
    detail = cmd.rsplit("/", 1)[-1].split()
    if color is None and detail and detail[0] == "less":
        flags = f"{os.environ.get('LESS', '')}{' '.join(detail[1:])}"
        if not flags:
            env["LESS"] = "-R"
            color = True
        elif "r" in flags or "R" in flags:
            color = True
    try:
        sys.stdout.flush()
    except Exception:
        pass
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, env=env, errors="replace", text=True)
    stream = _PagerStream(proc, color)
    try:
        yield stream
    except BaseException:
        try:
            proc.terminate()
        except Exception:
            pass
        raise
    else:
        try:
            proc.stdin.close()
        except BrokenPipeError:
            pass
    finally:
        stream.closed = True
        while True:
            try:
                proc.wait()
            except KeyboardInterrupt:
                continue
            break


def echo_via_pager(text_or_generator, color=None):
    color = resolve_color_default(color)
    if inspect.isgeneratorfunction(text_or_generator) or (
            callable(text_or_generator) and not isinstance(text_or_generator, str)):
        i = text_or_generator()
    else:
        i = text_or_generator
    if isinstance(i, str):
        i = [i]
    elif isinstance(i, (bytes, bytearray)):
        i = [bytes(i).decode("utf-8", "replace")]
    else:
        i = iter(i)
    with get_pager_file(color=color) as f:
        for el in i:
            f.write(el if isinstance(el, str) else str(el))
        f.write("\n")


# ---- progress bar ------------------------------------------------------

def _fmt_eta(seconds):
    seconds = int(seconds)
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    d, h = divmod(h, 24)
    t = f"{h:02}:{m:02}:{s:02}"
    return f"{d}d {t}" if d else t


class ProgressBar:
    def __init__(self, iterable=None, length=None, fill_char="#", empty_char="-",
                 bar_template="%(label)s  [%(bar)s]  %(info)s", info_sep="  ", show_eta=True,
                 show_percent=None, show_pos=False, item_show_func=None, label=None,
                 file=None, color=None, update_min_steps=1, width=36, hidden=False):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        if iterable is None:
            if length is None:
                raise TypeError("iterable or length is required")
            iterable = range(length)
        self.iter = iter(iterable)
        self.length = length
        self.fill_char, self.empty_char = fill_char, empty_char
        self.bar_template, self.info_sep = bar_template, info_sep
        self.show_eta, self.show_pos = show_eta, show_pos
        self.show_percent = show_percent
        self.item_show_func = item_show_func
        self.label = label or ""
        self.file = file if file is not None else sys.stdout
        self.color = color
        self.update_min_steps = update_min_steps
        self.width = width
        self.hidden = hidden
        self.pos = 0
        self.finished = False
        self.current_item = None
        self.start = self.last_eta = time.time()
        self._last_line = None
        self._completed_intervals = 0
        self.is_hidden = hidden or not isatty(self.file)
        self.avg = []
        self._label_printed = False

    def __enter__(self):
        self.render_progress()
        return self

    def __exit__(self, *a):
        self.render_finish()

    def __iter__(self):
        self.render_progress()
        return self.generator()

    def __next__(self):
        return next(iter(self))

    @property
    def pct(self):
        if self.finished:
            return 1.0
        if not self.length:
            return 0.0
        return min(self.pos / self.length, 1.0)

    @property
    def eta(self):
        if self.length is not None and not self.finished and self.pos > 0:
            elapsed = time.time() - self.start
            return elapsed / self.pos * (self.length - self.pos)
        return 0.0

    def format_eta(self):
        if self.show_eta and self.length is not None and not self.finished and self.pos > 0:
            return _fmt_eta(self.eta)
        return ""

    def format_pos(self):
        pos = str(self.pos)
        if self.length is not None:
            pos += f"/{self.length}"
        return pos

    def format_pct(self):
        return f"{int(self.pct * 100): 4}%"[1:]

    def format_bar(self):
        if self.length is not None:
            n = int(self.pct * self.width)
            return self.fill_char * n + self.empty_char * (self.width - n)
        return self.empty_char * self.width

    def format_progress_line(self):
        show_percent = self.show_percent
        info = []
        if self.length is not None and show_percent is None:
            show_percent = not self.show_pos
        if self.show_pos:
            info.append(self.format_pos())
        if show_percent:
            info.append(self.format_pct())
        if self.show_eta and self.length is not None:
            e = self.format_eta()
            if e:
                info.append(e)
        if self.item_show_func is not None and self.current_item is not None:
            item = self.item_show_func(self.current_item)
            if item is not None:
                info.append(item)
        return (self.bar_template % {"label": self.label, "bar": self.format_bar(),
                                     "info": self.info_sep.join(info)}).rstrip()

    def render_progress(self):
        if self.hidden:
            return
        if not isatty(self.file):
            if self.label and not self._label_printed:
                self._label_printed = True
                echo(self.label, file=self.file, color=self.color)
            return
        line = self.format_progress_line()
        clear = " " * max(0, len(self._last_line or "") - len(line))
        self._last_line = line
        echo("\r" + line + clear, file=self.file, nl=False, color=self.color)
        self.file.flush()

    def render_finish(self):
        if self.hidden or not isatty(self.file):
            return
        self.file.write("\n")
        self.file.flush()

    def make_step(self, n_steps):
        self.pos += n_steps
        if self.length is not None and self.pos >= self.length:
            self.finished = True

    def update(self, n_steps, current_item=None):
        if current_item is not None:
            self.current_item = current_item
        self.make_step(n_steps)
        self.render_progress()

    def finish(self):
        self.finished = True

    def generator(self):
        if self.is_hidden and self.hidden:
            for rv in self.iter:
                yield rv
            return
        for rv in self.iter:
            self.current_item = rv
            yield rv
            self.update(1)
        self.finish()
        self.render_progress()


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)


# ---- single char, pause, editor, launch, clear -------------------------

def _getchar(echo_):
    import termios
    import tty
    if isatty(sys.stdin):
        fd = sys.stdin.fileno()
        close = None
    else:
        fd = os.open("/dev/tty", os.O_RDONLY)
        close = fd
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 32)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
    finally:
        if close is not None:
            os.close(close)
    ch = ch.decode(getattr(sys.stdin, "encoding", None) or "utf-8", "replace")
    if echo_ and isatty(sys.stdout):
        sys.stdout.write(ch)
        sys.stdout.flush()
    return ch


def getchar(echo=False):
    ch = _getchar(echo)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    return ch


def pause(info=None, err=False):
    if info is None:
        info = "Press any key to continue..."
    if not _interactive():
        if info:
            echo(info, err=err)
        return
    try:
        if info:
            echo(info, nl=False, err=err)
        try:
            getchar()
        except (KeyboardInterrupt, EOFError):
            pass
    finally:
        if info:
            echo(err=err)


def clear():
    if not isatty(sys.stdout):
        return
    echo("\033[2J\033[1;1H", nl=False)


def _get_editor(editor):
    if editor is not None:
        return editor
    for key in ("VISUAL", "EDITOR"):
        rv = os.environ.get(key)
        if rv:
            return rv
    for e in ("sensible-editor", "vim", "nano"):
        if shutil.which(e):
            return e
    return "vi"


def _edit_file(editor, env, filename):
    ed = _get_editor(editor)
    environ = None
    if env:
        environ = os.environ.copy()
        environ.update(env)
    try:
        c = subprocess.Popen(f"{ed} {shlex.quote(os.fspath(filename))}", env=environ, shell=True)
        code = c.wait()
        if code != 0:
            raise OptlynException(f"{ed}: Editing failed")
    except OSError as e:
        raise OptlynException(f"{ed}: Editing failed: {e}") from e


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    if filename is not None:
        _edit_file(editor, env, filename)
        return None
    text = text or ""
    binary = isinstance(text, bytes)
    data = text if binary else text.encode("utf-8")
    fd, name = tempfile.mkstemp(prefix="editor-", suffix=extension)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        st = os.stat(name)
        before = (st.st_mtime_ns, st.st_size)
        os.utime(name, ns=(st.st_atime_ns, st.st_mtime_ns - 2_000_000_000))
        before = (os.stat(name).st_mtime_ns, st.st_size)
        _edit_file(editor, env, name)
        st = os.stat(name)
        if require_save and (st.st_mtime_ns, st.st_size) == before:
            return None
        with open(name, "rb") as f:
            rv = f.read()
        if binary:
            return rv
        return rv.decode("utf-8-sig").replace("\r\n", "\n")
    finally:
        try:
            os.unlink(name)
        except OSError:
            pass


def launch(url, wait=False, locate=False):
    from urllib.parse import unquote
    u = os.fspath(url)
    if u.startswith("file://"):
        u = unquote(u[7:])
    try:
        if locate:
            u = os.path.dirname(u) or "."
        c = subprocess.Popen(["xdg-open", u])
        if wait:
            return c.wait()
        try:
            return c.wait(timeout=3)
        except subprocess.TimeoutExpired:
            return 0
    except OSError:
        if str(url).startswith(("http://", "https://")) and not locate and not wait:
            import webbrowser
            webbrowser.open(url)
            return 0
        return 1
