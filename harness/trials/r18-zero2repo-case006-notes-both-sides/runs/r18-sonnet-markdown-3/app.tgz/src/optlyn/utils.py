import codecs
import io
import os
import sys
from functools import update_wrapper

from . import formatting
from .formatting import strip_ansi
from .globals import resolve_color_default


def isatty(stream):
    try:
        return stream.isatty()
    except Exception:
        return False


def _find_binary_writer(stream):
    if isinstance(stream, (io.RawIOBase, io.BufferedIOBase)):
        return stream
    buf = getattr(stream, "buffer", None)
    if buf is not None and hasattr(buf, "write"):
        return buf
    return None


def _is_ascii_encoding(enc):
    if not enc:
        return False
    try:
        return codecs.lookup(enc).name == "ascii"
    except LookupError:
        return False


def should_strip_ansi(stream=None, color=None):
    if color is None:
        if stream is None:
            stream = sys.stdin
        return not isatty(stream)
    return not color


def echo(message=None, file=None, nl=True, err=False, color=None):
    if file is None:
        file = sys.stderr if err else sys.stdout
        if file is None:
            return
    if message is not None and not isinstance(message, (str, bytes, bytearray)):
        out = str(message)
    else:
        out = message
    if nl:
        out = out or ""
        out = out + ("\n" if isinstance(out, str) else b"\n")
    if not out:
        file.flush()
        return
    if isinstance(out, (bytes, bytearray)):
        binary = _find_binary_writer(file)
        if binary is not None:
            file.flush()
            binary.write(bytes(out))
            binary.flush()
            return
        out = bytes(out).decode("utf-8", "replace")
    else:
        color = resolve_color_default(color)
        if should_strip_ansi(file, color):
            out = strip_ansi(out)
    if _is_ascii_encoding(getattr(file, "encoding", None)):
        binary = _find_binary_writer(file)
        if binary is not None:
            file.flush()
            binary.write(out.encode("utf-8"))
            binary.flush()
            return
    try:
        file.write(out)
    except UnicodeEncodeError:
        binary = _find_binary_writer(file)
        if binary is None:
            raise
        file.flush()
        binary.write(out.encode("utf-8"))
        binary.flush()
        return
    file.flush()


class ColorError(TypeError, ValueError):
    pass


_ansi_colors = {
    "black": 30, "red": 31, "green": 32, "yellow": 33, "blue": 34, "magenta": 35,
    "cyan": 36, "white": 37, "reset": 39, "bright_black": 90, "bright_red": 91,
    "bright_green": 92, "bright_yellow": 93, "bright_blue": 94, "bright_magenta": 95,
    "bright_cyan": 96, "bright_white": 97,
}


def _interpret_color(color, offset=0):
    if isinstance(color, bool):
        raise ColorError(f"Unknown color {color!r}")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise ColorError(f"Color out of range: {color!r}")
        return f"{38 + offset};5;{color:d}"
    if isinstance(color, (tuple, list)):
        if len(color) != 3 or any(isinstance(c, bool) or not isinstance(c, int) or not 0 <= c <= 255 for c in color):
            raise ColorError(f"Invalid RGB color {color!r}")
        r, g, b = color
        return f"{38 + offset};2;{r:d};{g:d};{b:d}"
    if isinstance(color, str) and color in _ansi_colors:
        return str(_ansi_colors[color] + offset)
    raise ColorError(f"Unknown color {color!r}")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True):
    if not isinstance(text, str):
        text = str(text)
    bits = []
    if fg is not None:
        bits.append(f"\033[{_interpret_color(fg)}m")
    if bg is not None:
        bits.append(f"\033[{_interpret_color(bg, 10)}m")
    for val, on, off in ((bold, 1, 22), (dim, 2, 22), (underline, 4, 24), (overline, 53, 55),
                         (italic, 3, 23), (blink, 5, 25), (reverse, 7, 27), (strikethrough, 9, 29)):
        if val is not None:
            bits.append(f"\033[{on if val else off}m")
    bits.append(text)
    if reset:
        bits.append("\033[0m")
    return "".join(bits)


def unstyle(text):
    return strip_ansi(text)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None and not isinstance(message, (bytes, bytearray)):
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def format_filename(filename, shorten=False):
    if shorten:
        filename = os.path.basename(filename)
    filename = os.fspath(filename)
    if isinstance(filename, bytes):
        filename = filename.decode(sys.getfilesystemencoding() or "utf-8", "surrogateescape")
    return filename.encode("utf-8", "surrogateescape").decode("utf-8", "backslashreplace")


def get_app_dir(app_name, roaming=True, force_posix=False):
    def posixify(name):
        return "-".join(name.split()).lower()

    if sys.platform.startswith("win"):
        key = "APPDATA" if roaming else "LOCALAPPDATA"
        folder = os.environ.get(key) or os.path.expanduser("~")
        return os.path.join(folder, app_name)
    if force_posix:
        return os.path.join(os.path.expanduser(f"~/.{posixify(app_name)}"))
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~/Library/Application Support"), app_name)
    return os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config"),
                        posixify(app_name))


def safecall(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception:
            pass
    return wrapper


def make_str(value):
    if isinstance(value, bytes):
        try:
            return value.decode(sys.getfilesystemencoding())
        except UnicodeError:
            return value.decode("utf-8", "replace")
    return str(value)


# ---- files -------------------------------------------------------------

class KeepOpenFile:
    def __init__(self, file):
        self._file = file

    def __getattr__(self, name):
        return getattr(self._file, name)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        pass

    def __repr__(self):
        return repr(self._file)

    def __iter__(self):
        return iter(self._file)


class _AtomicFile:
    def __init__(self, f, tmp_filename, real_filename):
        self._f = f
        self._tmp_filename = tmp_filename
        self._real_filename = real_filename
        self.closed = False

    @property
    def name(self):
        return self._real_filename

    def close(self, delete=False):
        if self.closed:
            return
        self._f.close()
        if delete:
            try:
                os.remove(self._tmp_filename)
            except OSError:
                pass
        else:
            os.replace(self._tmp_filename, self._real_filename)
        self.closed = True

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, *a):
        self.close(delete=exc_type is not None)

    def __repr__(self):
        return repr(self._f)

    def __iter__(self):
        return iter(self._f)


class _NonClosingTextIOWrapper(io.TextIOWrapper):
    def __del__(self):
        try:
            self.flush()
            self.detach()
        except Exception:
            pass

    def close(self):
        try:
            self.flush()
        except Exception:
            pass


def _std_stream(name, binary, encoding, errors, writing):
    stream = getattr(sys, name)
    if binary:
        return getattr(stream, "buffer", stream)
    if encoding is None or (getattr(stream, "encoding", None) or "").lower() == encoding.lower():
        return stream
    buf = getattr(stream, "buffer", None)
    if buf is None:
        return stream
    if writing:
        try:
            stream.flush()
        except Exception:
            pass
    return _NonClosingTextIOWrapper(buf, encoding, errors or "strict", write_through=True) if writing \
        else _NonClosingTextIOWrapper(buf, encoding, errors or "strict")


def open_stream(filename, mode="r", encoding=None, errors="strict", atomic=False):
    binary = "b" in mode
    filename = os.fspath(filename)
    if isinstance(filename, bytes):
        filename = os.fsdecode(filename)
    if filename == "-":
        if any(m in mode for m in "wax"):
            return _std_stream("stdout", binary, encoding, errors, True), False
        return _std_stream("stdin", binary, encoding, errors, False), False
    if not atomic:
        return open(filename, mode, encoding=encoding, errors=errors) if not binary \
            else open(filename, mode), True
    if "r" in mode or "x" in mode or "a" in mode:
        raise ValueError("Atomic writes only make sense with 'w' mode.")
    import random
    import errno
    perm = None
    try:
        perm = os.stat(filename).st_mode
    except OSError:
        pass
    flags = os.O_RDWR | os.O_CREAT | os.O_EXCL
    while True:
        tmp = os.path.join(os.path.dirname(filename) or ".", f".__atomic-write{random.randrange(1 << 32):08x}")
        try:
            fd = os.open(tmp, flags, 0o666 if perm is None else perm)
            break
        except OSError as e:
            if e.errno == errno.EEXIST:
                continue
            raise
    f = open(fd, mode, encoding=None if binary else encoding, errors=None if binary else errors)
    return _AtomicFile(f, tmp, os.path.realpath(filename)), True


class LazyFile:
    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False):
        self.name = os.fspath(filename)
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self.should_close = True
        if self.name == "-":
            self._f, self.should_close = open_stream(filename, mode, encoding, errors)
        elif "r" in mode:
            open(filename, mode).close()

    def __getattr__(self, name):
        if name.startswith("__") and name.endswith("__"):
            raise AttributeError(name)
        return getattr(self.open(), name)

    def __repr__(self):
        if self._f is not None:
            return repr(self._f)
        return f"<unopened file '{format_filename(self.name)}' {self.mode}>"

    def open(self):
        if self._f is not None:
            return self._f
        try:
            rv, self.should_close = open_stream(self.name, self.mode, self.encoding, self.errors, atomic=self.atomic)
        except OSError as e:
            from .exceptions import FileError
            raise FileError(self.name, hint=e.strerror) from e
        self._f = rv
        return rv

    def close(self):
        if self._f is not None:
            self._f.close()

    def close_intelligently(self):
        if self.should_close:
            self.close()

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close_intelligently()

    def __iter__(self):
        self.open()
        return iter(self._f)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    f, should_close = open_stream(filename, mode, encoding, errors, atomic=atomic)
    if not should_close:
        f = KeepOpenFile(f)
    return f


def _is_file_like(obj):
    return hasattr(obj, "read") or hasattr(obj, "write")


def get_text_stdout():
    return sys.stdout


def get_binary_stdout():
    return getattr(sys.stdout, "buffer", sys.stdout)


def get_text_stderr():
    return sys.stderr


def get_text_stdin():
    return sys.stdin


def get_binary_stdin():
    return getattr(sys.stdin, "buffer", sys.stdin)


def _detect_program_name(path=None, _main=None):
    if _main is None:
        _main = sys.modules.get("__main__")
    if not path:
        path = sys.argv[0] if sys.argv else ""
    if getattr(_main, "__package__", None) in {None, ""}:
        return os.path.basename(path)
    py_module = _main.__package__
    name = os.path.splitext(os.path.basename(path))[0]
    if name != "__main__":
        py_module = f"{py_module}.{name}"
    return f"python -m {py_module.lstrip('.')}"
