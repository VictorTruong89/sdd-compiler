import inspect
import sys
from functools import update_wrapper

from .core import Argument, Command, Group, Option, Parameter
from .globals import get_current_context
from .utils import echo

_PARAMS = "__optlyn_params__"


def pass_context(f):
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)
    return update_wrapper(new_func, f)


def pass_obj(f):
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)
    return update_wrapper(new_func, f)


def make_pass_decorator(object_type, ensure=False):
    def decorator(f):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            obj = ctx.ensure_object(object_type) if ensure else ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(
                    f"Managed to invoke callback without a context object of type "
                    f"{object_type.__name__!r} existing.")
            return ctx.invoke(f, obj, *args, **kwargs)
        return update_wrapper(new_func, f)
    return decorator


def _param_memo(f, param):
    if isinstance(f, Command):
        f.params.append(param)
    else:
        if not hasattr(f, _PARAMS):
            setattr(f, _PARAMS, [])
        getattr(f, _PARAMS).append(param)


def _make_command(f, name, attrs, cls):
    if isinstance(f, Command):
        raise TypeError("Attempted to convert a callback into a command twice.")
    params = list(getattr(f, _PARAMS, []))
    params.reverse()
    try:
        delattr(f, _PARAMS)
    except AttributeError:
        pass
    help = attrs.get("help")
    if help is None:
        help = inspect.getdoc(f)
        if isinstance(help, bytes):
            help = help.decode("utf-8")
    else:
        help = inspect.cleandoc(help).replace("\f", "")
    attrs["help"] = help
    if name is None:
        name = f.__name__.lower().replace("_", "-")
        for suffix in ("-command", "-cmd", "-group", "-grp"):
            if name.endswith(suffix):
                name = name[: -len(suffix)]
                break
    return cls(name=name, callback=f, params=params, **attrs)


def command(name=None, cls=None, **attrs):
    func = None
    if callable(name):
        func = name
        name = None
    if cls is None:
        cls = Command

    def decorator(f):
        cmd = _make_command(f, name, dict(attrs), cls)
        cmd.__doc__ = f.__doc__
        return cmd

    if func is not None:
        return decorator(func)
    return decorator


def group(name=None, cls=None, **attrs):
    if cls is None:
        cls = Group
    if callable(name):
        return command(None, cls, **attrs)(name)
    return command(name, cls, **attrs)


def argument(*param_decls, cls=None, **attrs):
    if cls is None:
        cls = Argument

    def decorator(f):
        _param_memo(f, cls(param_decls, **dict(attrs)))
        return f
    return decorator


def option(*param_decls, cls=None, **attrs):
    if cls is None:
        cls = Option

    def decorator(f):
        _param_memo(f, cls(param_decls, **dict(attrs)))
        return f
    return decorator


def confirmation_option(*param_decls, **kwargs):
    def callback(ctx, param, value):
        if not value:
            ctx.abort()

    if not param_decls:
        param_decls = ("--yes",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("callback", callback)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")
    return option(*param_decls, **kwargs)


def password_option(*param_decls, **kwargs):
    if not param_decls:
        param_decls = ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("hide_input", True)
    return option(*param_decls, **kwargs)


def _detect_package(depth=2):
    f = sys._getframe(depth)
    name = f.f_globals.get("__name__")
    if not name or name == "__main__":
        return None
    return name.partition(".")[0]


def _lookup_version(package_name):
    from importlib import metadata
    try:
        return metadata.version(package_name)
    except metadata.PackageNotFoundError:
        pass
    try:
        dists = metadata.packages_distributions().get(package_name) or []
    except Exception:
        dists = []
    for d in dists:
        try:
            return metadata.version(d)
        except metadata.PackageNotFoundError:
            continue
    return None


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    if message is None:
        message = "%(prog)s, version %(version)s"
    if version is None and package_name is None:
        package_name = _detect_package(2)

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        nonlocal prog_name, version
        pn = prog_name
        if pn is None:
            pn = ctx.find_root().info_name
        ver = version
        if ver is None:
            if package_name is None:
                raise RuntimeError("Could not determine the version: no package name.")
            ver = _lookup_version(package_name)
            if ver is None:
                raise RuntimeError(f"{package_name!r} is not installed. Try passing 'package_name' instead.")
        echo(message % {"prog": pn, "package": package_name, "version": ver}, color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*param_decls, **kwargs)


def custom_version_option(callback, *param_decls, **kwargs):
    def cb(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(callback(ctx), color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = cb
    return option(*param_decls, **kwargs)


def help_option(*param_decls, **kwargs):
    def show_help(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(ctx.get_help(), color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs["callback"] = show_help
    return option(*param_decls, **kwargs)
