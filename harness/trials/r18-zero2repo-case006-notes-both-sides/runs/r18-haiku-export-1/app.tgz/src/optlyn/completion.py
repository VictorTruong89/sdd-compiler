"""Shell completion: registration scripts and suggestion emission.

# spec: N-001013..N-001037 (interface contract section 8)
# spec: N-000689..N-000715 (FP-12 shell completion)
"""

from __future__ import annotations

import os
import sys

from .params import Argument, Option

SHELLS = ("bash", "zsh", "fish", "powershell")


def complete_var_name(prog_name):
    return "_" + prog_name.upper().replace("-", "_") + "_COMPLETE"


def maybe_complete(cmd, prog_name, args, complete_var=None):
    """If the completion variable is set for this program, handle it and return True."""
    var = complete_var or complete_var_name(prog_name)
    value = os.environ.get(var)
    if not value:
        return False
    if "_" not in value:
        return True
    shell, _, mode = value.partition("_")
    if shell not in SHELLS or mode not in ("source", "complete"):
        # unknown instruction: neither a script nor suggestions are printed
        return True
    if mode == "source":
        sys.stdout.write(_script(shell, prog_name, var))
        return True
    for line in _suggestions(cmd, prog_name, shell):
        sys.stdout.write(line + "\n")
    return True


def _script(shell, prog, var):
    p = os.path.basename(prog)
    if shell == "bash":
        fn = "_" + p.replace("-", "_") + "_completion"
        return (f"{fn}() {{\n"
                f"  local IFS=$'\\n'\n"
                f"  COMPREPLY=( $(env COMP_WORDS=\"${{COMP_WORDS[*]}}\" COMP_CWORD=$COMP_CWORD "
                f"{var}=bash_complete {p}) )\n"
                f"  return 0\n}}\n"
                f"complete -o default -F {fn} {p}\n")
    if shell == "zsh":
        return (f"#compdef {p}\n"
                f"_{p.replace('-', '_')}() {{\n"
                f"  local -a completions\n"
                f"  completions=(${{(f)\"$(env COMP_WORDS=\"${{words[*]}}\" COMP_CWORD=$((CURRENT-1)) "
                f"{var}=zsh_complete {p})\"}})\n"
                f"  _describe 'values' completions\n}}\n"
                f"compdef _{p.replace('-', '_')} {p}\n")
    if shell == "fish":
        return (f"complete --no-files --command {p} --arguments "
                f"\"(env COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -ct) {var}=fish_complete {p})\"\n")
    return (f"Register-ArgumentCompleter -Native -CommandName '{p}' -ScriptBlock {{\n"
            f"  param($wordToComplete, $commandAst, $cursorPosition)\n"
            f"  $env:COMP_WORDS = $commandAst.ToString(); $env:COMP_CWORD = $wordToComplete\n"
            f"  & {p} | Out-Null\n}}\n")


def _words_and_incomplete(shell):
    raw = os.environ.get("COMP_WORDS", "")
    words = raw.split()
    if shell == "fish":
        incomplete = os.environ.get("COMP_CWORD", "")
        args = words[1:]
        return args, incomplete
    try:
        idx = int(os.environ.get("COMP_CWORD", str(len(words))))
    except ValueError:
        idx = len(words)
    args = words[1:idx]
    incomplete = words[idx] if idx < len(words) else ""
    return args, incomplete


def _suggestions(cmd, prog, shell):
    from .context import Context
    from .core import Group

    args, incomplete = _words_and_incomplete(shell)
    current = cmd
    ctx = Context(cmd, info_name=prog, resilient_parsing=True)
    consumed = []
    i = 0
    while i < len(args):
        tok = args[i]
        if tok.startswith("-"):
            i += 1
            continue
        if isinstance(current, Group):
            child = current.get_command(ctx, tok)
            if child is not None:
                current = child
                ctx = Context(child, parent=ctx, info_name=tok, resilient_parsing=True)
                i += 1
                continue
        i += 1
    out = []
    params = [p for p in current.get_params(ctx) if not getattr(p, "hidden", False)]
    if incomplete.startswith("-"):
        for p in params:
            if isinstance(p, Option):
                for o in p.opts:
                    if o.startswith(incomplete):
                        out.append(o)
        return out
    if isinstance(current, Group) and not incomplete.startswith("-"):
        for name, child in current._visible_commands(ctx):
            if name.startswith(incomplete):
                help_text = child.get_short_help()
                out.append(_fmt(name, help_text, shell))
    for p in params:
        if not isinstance(p, Argument):
            continue
        kind = getattr(p.type, "name", "")
        if kind in ("filename", "path"):
            out.append("__optlyn_path__file " + incomplete)
            break
    return out


def _fmt(value, help_text, shell):
    if help_text and shell in ("zsh", "fish"):
        return f"{value}\t{help_text}"
    return value
