"""Help page and usage-line rendering.

# spec: N-000827..N-000849 (interface contract section 2: help page order, version identity)
# spec: N-000103..N-000177 (FP-02 automatic help pages, usage line, metavars)
# spec: N-000680 (max content width 100 for wrapped text; help auto width defaults to 80)
"""

from __future__ import annotations

import shutil

from .formatting import first_sentence, short_help, wrap_text
from .params import Argument, Option


def _help_width(ctx):
    if ctx.terminal_width is not None:
        return max(int(ctx.terminal_width) - 2, 10)
    try:
        size = shutil.get_terminal_size((80, 24)).columns
    except Exception:
        size = 80
    cap = ctx.max_content_width or 80
    return max(min(size, cap) - 2, 10)


def _visible_params(ctx, command):
    return [p for p in command.get_params(ctx) if not getattr(p, "hidden", False)]


def format_usage(ctx):
    cmd = ctx.command
    pieces = [ctx.command_path or "cli"]
    options = [p for p in _visible_params(ctx, cmd) if isinstance(p, Option)]
    if options or cmd.options_metavar:
        pieces.append(cmd.options_metavar)
    for a in cmd.params:
        if not isinstance(a, Argument):
            continue
        if getattr(a, "hidden", False):
            continue
        name = a.get_metavar()
        if a.variadic:
            token = f"{name}..."
        else:
            token = name
        if not a.required:
            token = f"[{token}]"
        pieces.append(token)
    from .core import Group

    if isinstance(cmd, Group):
        meta = cmd.subcommand_metavar or "COMMAND [ARGS]..."
        if cmd.chain:
            meta = "COMMAND [ARGS]... [COMMAND [ARGS]...]..."
        if cmd.invoke_without_command:
            meta = f"[{meta}]" if not cmd.chain else meta
        pieces.append(meta)
    return "Usage: " + " ".join(pieces)


def _option_entry(ctx, p):
    names = []
    for o in p.opts:
        names.append(o)
    if p.secondary_opts:
        names = [f"{a}/{b}" for a, b in zip(p.opts, p.secondary_opts)] or names
    head = ", ".join(names)
    if not p.is_flag and not p.count:
        meta = p.get_metavar()
        if meta:
            head += f" {meta}"
    extras = []
    show_default = p.show_default if p.show_default is not None else ctx.show_default
    if show_default and p.has_default:
        d = p.default
        if isinstance(p.show_default, str):
            extras.append(f"default: {p.show_default}")
        elif p.is_flag and d is False:
            pass  # spec contradiction CF-000162: hidden for a False flag default
        elif d is not None:
            extras.append(f"default: {d}")
    if p.show_envvar and p.env_names(ctx):
        extras.append(f"env var: {', '.join(p.env_names(ctx))}")
    if p.deprecated:
        extras.append("deprecated")
    text = p.help or ""
    if extras:
        text = (text + " " if text else "") + "[" + "; ".join(extras) + "]"
    return head, text


def format_help(ctx):
    cmd = ctx.command
    width = _help_width(ctx)
    lines = [format_usage(ctx), ""]
    if cmd.deprecated:
        lines.insert(0, "(deprecated)")
        lines.insert(1, "")
    desc = cmd.help or ""
    if desc:
        lines.append(wrap_text(desc, width=width))
        lines.append("")
    if cmd.epilog and False:
        pass

    args = [p for p in cmd.params if isinstance(p, Argument) and p.help and not p.hidden]
    if args:
        lines.append("Positional arguments:")
        for a in args:
            lines.append(f"  {a.get_metavar()}  {a.help}")
        lines.append("")

    opts = [p for p in _visible_params(ctx, cmd) if isinstance(p, Option)]
    if opts:
        lines.append("Options:")
        rows = [_option_entry(ctx, p) for p in opts]
        w = max(len(h) for h, _ in rows) if rows else 0
        for head, text in rows:
            if text:
                lines.append(f"  {head.ljust(w)}  {text}")
            else:
                lines.append(f"  {head}")
        lines.append("")

    from .core import Group

    if isinstance(cmd, Group):
        visible = cmd._visible_commands(ctx)
        if visible:
            lines.append("Commands:")
            w = max(len(n) for n, _ in visible)
            for name, child in visible:
                sh = child.get_short_help()
                if len(sh) > 45:
                    sh = sh[:42] + "..."
                lines.append(f"  {name.ljust(w)}  {sh}".rstrip())
            lines.append("")

    if cmd.epilog:
        lines.append(wrap_text(cmd.epilog, width=width))
        lines.append("")
    text = "\n".join(lines)
    while text.endswith("\n\n"):
        text = text[:-1]
    return text if text.endswith("\n") else text + "\n"
