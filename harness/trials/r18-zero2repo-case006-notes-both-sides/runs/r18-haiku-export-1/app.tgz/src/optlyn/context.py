"""Invocation context.

# spec: N-000950..N-000980 (interface contract section 6: Context members)
# spec: N-000434..N-000483 (FP-07 invocation context, defaults, env prefix, sources)
# spec: N-000243..N-000245 (value precedence)
"""

from __future__ import annotations

from contextlib import contextmanager

from . import _context_stack
from .exceptions import Abort, Exit
from .params import ParameterSource, UNSET

_SETTING_KEYS = {
    "auto_envvar_prefix", "default_map", "terminal_width", "max_content_width",
    "help_option_names", "token_normalize_func", "color", "show_default",
    "allow_extra_args", "ignore_unknown_options", "allow_interspersed_args",
    "obj", "resilient_parsing",
}


class Context:
    def __init__(self, command, parent=None, info_name=None, obj=None, default_map=None,
                 auto_envvar_prefix=None, terminal_width=None, max_content_width=None,
                 help_option_names=None, token_normalize_func=None, color=None,
                 show_default=None, allow_extra_args=None, ignore_unknown_options=None,
                 allow_interspersed_args=None, resilient_parsing=False, **extra):
        self.command = command
        self.parent = parent
        self.info_name = info_name
        self.params = {}
        self._sources = {}
        self._close_callbacks = []
        self.invoked_subcommand = None
        self.args = []
        self.resilient_parsing = resilient_parsing
        self.extra = extra

        if parent is not None:
            self.obj = parent.obj if obj is None else obj
            self.default_map = default_map
            self.auto_envvar_prefix = parent.auto_envvar_prefix
            self.terminal_width = parent.terminal_width if terminal_width is None else terminal_width
            self.max_content_width = parent.max_content_width if max_content_width is None else max_content_width
            self.help_option_names = parent.help_option_names if help_option_names is None else help_option_names
            self.token_normalize_func = parent.token_normalize_func if token_normalize_func is None else token_normalize_func
            self.color = parent.color if color is None else color
            self.show_default = parent.show_default if show_default is None else show_default
            self.allow_extra_args = parent.allow_extra_args if allow_extra_args is None else allow_extra_args
            self.ignore_unknown_options = parent.ignore_unknown_options if ignore_unknown_options is None else ignore_unknown_options
            self.allow_interspersed_args = parent.allow_interspersed_args if allow_interspersed_args is None else allow_interspersed_args
            self._env_prefix = None
            if parent._env_prefix and info_name:
                self._env_prefix = f"{parent._env_prefix}_{info_name}"
        else:
            self.obj = obj
            self.default_map = default_map
            self.auto_envvar_prefix = auto_envvar_prefix
            self.terminal_width = terminal_width
            self.max_content_width = 80 if max_content_width is None else max_content_width
            self.help_option_names = list(help_option_names) if help_option_names is not None else ["--help"]
            self.token_normalize_func = token_normalize_func
            self.color = color
            self.show_default = bool(show_default)
            self.allow_extra_args = bool(allow_extra_args)
            self.ignore_unknown_options = bool(ignore_unknown_options)
            self.allow_interspersed_args = True if allow_interspersed_args is None else allow_interspersed_args
            self._env_prefix = auto_envvar_prefix
        if self.auto_envvar_prefix and parent is None:
            self._env_prefix = self.auto_envvar_prefix

    # ---- tree -----------------------------------------------------------
    @property
    def root(self):
        ctx = self
        while ctx.parent is not None:
            ctx = ctx.parent
        return ctx

    @property
    def command_path(self):
        parts = []
        ctx = self
        while ctx is not None:
            if ctx.info_name:
                parts.append(ctx.info_name)
            ctx = ctx.parent
        return " ".join(reversed(parts))

    def get_usage(self):
        from .help import format_usage

        return format_usage(self)

    def get_help(self):
        from .help import format_help

        return format_help(self)

    # ---- sources --------------------------------------------------------
    def get_parameter_source(self, name):
        """None for an undeclared name; otherwise a ParameterSource."""
        return self._sources.get(name)

    def _set_value(self, name, value, source):
        self.params[name] = value
        self._sources[name] = source

    # ---- resources ------------------------------------------------------
    def call_on_close(self, f):
        self._close_callbacks.append(f)
        return f

    def close(self):
        errors = []
        while self._close_callbacks:
            cb = self._close_callbacks.pop()
            try:
                cb()
            except Exception as e:  # keep closing the rest
                errors.append(e)
        if errors:
            raise errors[0]

    def with_resource(self, cm):
        value = cm.__enter__()
        self.call_on_close(lambda: cm.__exit__(None, None, None))
        return value

    # ---- control --------------------------------------------------------
    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def __enter__(self):
        _context_stack.push(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        _context_stack.pop(self)
        return False

    def invoke(self, __cmd, **kwargs):
        """Invoke ``__cmd`` with exactly the given values (a Command or a callable)."""
        from .core import Command

        if isinstance(__cmd, Command):
            other = __cmd
            sub = Context(other, parent=self, info_name=other.name, obj=None)
            for p in other.params:
                if p.name in kwargs:
                    sub._set_value(p.name, p.convert(kwargs[p.name], sub), ParameterSource.COMMANDLINE)
                else:
                    sub._set_value(p.name, p.get_default(sub) if p.has_default else None, ParameterSource.DEFAULT)
            with sub:
                return other.invoke(sub)
        with self:
            return __cmd(*(), **kwargs)

    def forward(self, cmd, **kwargs):
        merged = dict(self.params)
        merged.update(kwargs)
        return self.invoke(cmd, **merged)

    def find_root(self):
        return self.root

    def find_object(self, object_type):
        ctx = self
        while ctx is not None:
            if isinstance(ctx.obj, object_type):
                return ctx.obj
            ctx = ctx.parent
        return None

    def ensure_object(self, object_type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found
