"""Commands, groups, parsing, invocation and the standalone entry point.

# spec: N-000850..N-000880 (command / group / CommandCollection)
# spec: N-000079..N-000109 (FP-01 command declaration, naming, invocation)
# spec: N-000384..N-000433 (FP-06 groups, nesting, deferred loading)
# spec: N-000591..N-000617 (FP-10 chaining)
# spec: N-000716..N-000735 (FP-13 exit statuses)
"""

from __future__ import annotations

import os
import re
import sys

from . import _context_stack
from .context import Context
from .exceptions import (Abort, BadParameter, Exit, MissingCommand, MissingParameter,
                         NoSuchCommand, NoSuchOption, OptlynError, UsageError)
from .params import (Argument, Option, Parameter, ParameterSource, PREFIX_CHARS, UNSET,
                     take_declared_params, help_option)
from .types import Tuple

_CMD_SUFFIX_RE = re.compile(r"_(command|cmd|group|grp)$")


class _ChainMarker:
    """Value of ``ctx.invoked_subcommand`` on a chaining group about to run children."""

    def __repr__(self):
        return "<chain>"


CHAIN = _ChainMarker()

_NOVAL = object()


def _name_from_function(f):
    name = f.__name__.lower().replace("_", "-")
    return _CMD_SUFFIX_RE.sub("", name)


def _docstring(f):
    doc = getattr(f, "__doc__", None)
    if not doc:
        return None
    from .formatting import clean_docstring

    return clean_docstring(doc)


class Command:
    """A leaf command: options, arguments and a callback."""

    def __init__(self, name=None, callback=None, params=None, help=None, short_help=None,
                 epilog=None, options_metavar="[OPTIONS]", context_settings=None,
                 add_help_option=True, no_args_is_help=False, deprecated=False, hidden=False,
                 deprecation_note=None, **attrs):
        if isinstance(deprecated, str):
            deprecation_note = deprecated
            deprecated = True
        self.name = name
        self.callback = callback
        self.params = list(params or [])
        self.help = help
        self.short_help = short_help
        self.epilog = epilog
        self.options_metavar = options_metavar
        self.context_settings = dict(context_settings or {})
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.deprecated = bool(deprecated)
        self.deprecation_note = deprecation_note
        self.hidden = hidden
        self.attrs = attrs
        if help is not None and "\f" in help:
            self.help = help.split("\f", 1)[0]

    # --- description helpers ------------------------------------------
    def get_short_help(self):
        if self.short_help is not None:
            return self.short_help
        from .formatting import first_sentence, short_help as _sh

        text = self.help or ""
        if not text:
            return ""
        return _sh(first_sentence(text), 45)

    def get_help_text(self):
        return self.help or ""

    def get_params(self, ctx):
        params = list(self.params)
        if self.add_help_option:
            author_flags = set()
            for p in params:
                if isinstance(p, Option):
                    author_flags.update(p.opts)
                    author_flags.update(p.secondary_opts)
            names = [n for n in ctx.help_option_names if n not in author_flags]
            if names:
                params.insert(0, _make_help_param(names))
        return params

    def get_param_by_name(self, name):
        for p in self.params:
            if p.name == name:
                return p
        return None

    # --- context -----------------------------------------------------
    def make_context(self, info_name, args, parent=None, **extra):
        settings = dict(self.context_settings)
        settings.update(extra)
        if parent is None:
            ctx = Context(self, info_name=info_name, **settings)
        else:
            dm = None
            if parent.default_map:
                dm = parent.default_map.get(info_name)
            settings.pop("default_map", None)
            ctx = Context(self, parent=parent, info_name=info_name, default_map=dm, **settings)
        if ctx.default_map is None and parent is None:
            ctx.default_map = settings.get("default_map")
        ctx.args = list(args)
        self.parse_args(ctx, args)
        return ctx

    def parse_args(self, ctx, args):
        """Parse the tokens for this command into raw values on ``ctx``."""
        ctx._raw = {}
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            from .help import format_help

            sys.stderr.write(format_help(ctx))
            raise UsageError("Missing argument.")
        rest = self._parse_tokens(ctx, list(args))
        ctx.args = rest
        return rest

    # --- token parsing -----------------------------------------------
    def _norm(self, ctx, tok):
        f = ctx.token_normalize_func
        return f(tok) if f else tok

    def _parse_tokens(self, ctx, args):
        params = self.get_params(ctx)
        lookup = {}
        for p in params:
            if isinstance(p, Option):
                for o in p.opts:
                    lookup[self._norm(ctx, o)] = (p, True)
                for o in p.secondary_opts:
                    lookup[self._norm(ctx, o)] = (p, False)
        prefixes = set(PREFIX_CHARS)
        for k in lookup:
            prefixes.add(k[0])
        arguments = [p for p in params if isinstance(p, Argument)]
        is_group = isinstance(self, Group)

        positional = []
        i = 0
        stop = False
        ctx._subcommand_rest = None
        while i < len(args):
            tok = args[i]
            if not stop and tok == "--":
                stop = True
                i += 1
                continue
            if not stop and len(tok) > 1 and tok[0] in prefixes:
                consumed = self._take_option(ctx, tok, args, i, lookup, positional, prefixes)
                i += consumed
                continue
            # non-option token
            if is_group:
                needed = sum(1 for a in arguments if a.required and a.nargs != -1)
                if len(positional) >= needed or not arguments:
                    ctx._subcommand_rest = args[i:]
                    break
                positional.append(tok)
                i += 1
                continue
            positional.append(tok)
            if not ctx.allow_interspersed_args:
                stop = True
            i += 1

        if is_group:
            self._bind_arguments(ctx, arguments, positional, leftover_ok=True)
            return ctx._subcommand_rest or []

        leftover = self._bind_arguments(ctx, arguments, positional)
        if leftover and not ctx.allow_extra_args:
            raise UsageError(f"Got unexpected extra argument{'s' if len(leftover) > 1 else ''} "
                             f"({' '.join(leftover)})", ctx)
        return leftover

    def _take_option(self, ctx, tok, args, i, lookup, positional, prefixes):
        """Consume one option token (possibly a stack). Returns tokens consumed."""
        ntok = self._norm(ctx, tok)
        if "=" in tok:
            head, val = tok.split("=", 1)
            if self._norm(ctx, head) in lookup:
                p, on = lookup[self._norm(ctx, head)]
                return self._apply(ctx, p, on, val, args, i, positional)
        if ntok in lookup:
            p, on = lookup[ntok]
            return self._apply(ctx, p, on, None, args, i, positional)
        long_style = tok[:2] == "--" or (len(tok) > 1 and tok[0] in prefixes and tok[1] in prefixes)
        if long_style:
            if ctx.ignore_unknown_options:
                positional.append(tok)
                return 1
            raise NoSuchOption(tok, ctx)
        # short stack: each char is a flag; a value-taking flag takes the rest or the next token
        first = tok[0]
        j = 1
        unknown = ""
        while j < len(tok):
            flag = self._norm(ctx, first + tok[j])
            if flag in lookup:
                p, on = lookup[flag]
                if p.is_flag or p.count:
                    self._apply(ctx, p, on, None, args, i, [])
                    j += 1
                    continue
                rest_inline = tok[j + 1:] or None
                return self._apply(ctx, p, on, rest_inline, args, i, [])
            if ctx.ignore_unknown_options:
                unknown += tok[j]
                j += 1
                continue
            raise NoSuchOption(first + tok[j], ctx)
        if unknown:
            positional.append(first + unknown)
        return 1

    def _apply(self, ctx, p, on, inline, args, i, positional):
        """Record one occurrence of option ``p``. Returns tokens consumed (1 + value tokens)."""
        if p.is_eager:
            # Eager flags act immediately, in the order typed.
            value = on if p.is_flag else None
            if p.is_flag:
                if not on and p.secondary_opts:
                    value = False
                p.run_callback(ctx, value)
                if p.callback is None:
                    pass
                return 1
        if p.is_flag or p.count:
            if inline is not None and not p.count:
                raise BadParameter(f"Option '{p.opts[0]}' does not take a value.", ctx, p)
            if p.count:
                ctx._raw.setdefault(id(p), []).append(("flag", 1))
                return 1
            if on:
                value = p.flag_value
            else:
                value = False if p.secondary_opts else (not p.flag_value)
            if p.deprecated:
                self._warn_deprecated(ctx, p)
            ctx._raw.setdefault(id(p), []).append(("flag", value))
            return 1
        # value-taking option
        if inline is not None:
            tokens = [inline]
            used = 1
            if p.nargs > 1:
                tokens = [inline] + list(args[i + 1:i + p.nargs])
                if len(tokens) < p.nargs:
                    raise UsageError(f"Option '{p.opts[0]}' requires {p.nargs} values.", ctx, p)
                used = p.nargs
            if p.deprecated:
                self._warn_deprecated(ctx, p)
            ctx._raw.setdefault(id(p), []).append(("tokens", tokens))
            return used
        need = p.nargs
        tokens = list(args[i + 1:i + 1 + need])
        if len(tokens) < need:
            if p.prompt:
                ctx._raw.setdefault(id(p), []).append(("noval", None))
                return 1
            raise UsageError(f"Option '{p.opts[0]}' requires {need} argument{'s' if need > 1 else ''}.", ctx, p)
        if p.deprecated:
            self._warn_deprecated(ctx, p)
        ctx._raw.setdefault(id(p), []).append(("tokens", tokens))
        return 1 + need

    def _warn_deprecated(self, ctx, p):
        note = p.attrs.get("deprecation_note") if isinstance(getattr(p, "attrs", None), dict) else None
        msg = f"DeprecationWarning: The {'option' if isinstance(p, Option) else 'argument'} '{p.get_error_hint()}' is deprecated."
        if isinstance(note, str):
            msg += " " + note
        sys.stderr.write(msg + "\n")

    def _bind_arguments(self, ctx, arguments, positional, leftover_ok=False):
        remaining = list(positional)
        for idx, a in enumerate(arguments):
            if a.nargs == -1:
                later_min = sum(b.nargs for b in arguments[idx + 1:] if b.required and b.nargs != -1)
                take = max(0, len(remaining) - later_min)
                tokens = remaining[:take]
                remaining = remaining[take:]
                if tokens:
                    ctx._raw.setdefault(id(a), []).append(("tokens", tokens))
                continue
            n = a.nargs
            if len(remaining) >= n:
                tokens = remaining[:n]
                remaining = remaining[n:]
                ctx._raw.setdefault(id(a), []).append(("tokens", tokens))
            elif remaining and not a.required:
                tokens = remaining[:n]
                remaining = remaining[n:]
                ctx._raw.setdefault(id(a), []).append(("tokens", tokens))
        return remaining

    # --- value resolution -------------------------------------------
    def _convert_tokens(self, ctx, p, tokens):
        if isinstance(p.type, Tuple):
            return p.type.convert(tuple(tokens), p, ctx)
        if p.nargs == 1:
            return p.type.convert(tokens[0], p, ctx)
        return tuple(p.type.convert(t, p, ctx) for t in tokens)

    def _cl_value(self, ctx, p, entries):
        if p.count:
            return len(entries)
        if p.is_flag:
            return entries[-1][1]
        occs = [self._convert_tokens(ctx, p, toks) for _, toks in entries]
        if p.multiple:
            return tuple(occs)
        return occs[-1]

    def _env_value(self, ctx, p):
        if p.is_flag or p.count:
            names = p.env_names(ctx)
            for n in names:
                raw = os.environ.get(n)
                if raw is None or raw == "":
                    continue
                txt = raw.strip().lower()
                if txt in ("true", "1", "yes", "on", "t", "y"):
                    return True
                if txt in ("false", "0", "no", "off", "f", "n", ""):
                    return False
                fv = p.flag_value
                if isinstance(fv, str) and txt == fv.lower():
                    return True
                # unrecognized: treated as unset, next source wins (FP-03)
            return UNSET
        raw, _name = p.read_envvar(ctx)
        if raw is None:
            return UNSET
        if p.multiple or p.nargs != 1 or isinstance(p.type, Tuple):
            toks = p.split_env(raw)
            if p.multiple and p.nargs == 1:
                return tuple(p.type.convert(t, p, ctx) for t in toks)
            return self._convert_tokens(ctx, p, toks)
        return p.type.convert(raw, p, ctx)

    def _default_value(self, ctx, p, d):
        if callable(d):
            d = d()
        if d is None:
            return None
        if p.is_flag:
            return bool(d)
        if p.multiple or p.nargs != 1 or isinstance(p.type, Tuple):
            if isinstance(d, str) or not isinstance(d, (list, tuple)):
                raise BadParameter(f"needs an iterable (sequence) default, got {d!r}.", ctx, p)
            if p.multiple and p.nargs == 1:
                return tuple(p.type.convert(x, p, ctx) for x in d)
            return self._convert_tokens(ctx, p, list(d))
        return p.type.convert(d, p, ctx)

    def _default_map_value(self, ctx, p):
        dm = ctx.default_map
        if not dm or p.name not in dm:
            return UNSET
        v = dm[p.name]
        if isinstance(v, str) and (p.nargs != 1 or isinstance(p.type, Tuple)):
            toks = p.type.split_env_value(v) if hasattr(p.type, "split_env_value") else v.split()
            return self._convert_tokens(ctx, p, toks)
        if isinstance(v, str) and p.multiple:
            raise BadParameter(f"needs an iterable (sequence) default, got {v!r}.", ctx, p)
        if p.is_flag:
            return bool(v) if not isinstance(v, str) else p.type.convert(v, p, ctx)
        if p.multiple and p.nargs == 1 and isinstance(v, (list, tuple)):
            return tuple(p.type.convert(x, p, ctx) for x in v)
        if isinstance(v, (list, tuple)) and p.nargs == 1 and not p.multiple:
            return v
        return v if v is None else p.type.convert(v, p, ctx)

    def _resolve(self, ctx, p):
        """Return (value, source). Raises MissingParameter for a required param with no value."""
        entries = ctx._raw.get(id(p), [])
        kinds = {k for k, _ in entries}
        if entries and "noval" not in kinds:
            return self._cl_value(ctx, p, entries), ParameterSource.COMMANDLINE

        env = self._env_value(ctx, p)
        dm = self._default_map_value(ctx, p)
        if env is not UNSET:
            return env, ParameterSource.ENVIRONMENT

        needs_prompt = bool(p.prompt) and ("noval" in kinds or (not entries and p.required))
        if needs_prompt:
            from .termui import prompt as _prompt

            if dm is not UNSET:
                dflt = dm
            elif p.has_default:
                dflt = p.default
            else:
                dflt = None
            text = p.prompt if isinstance(p.prompt, str) else p.name.replace("_", " ").capitalize()
            value = _prompt(text, default=dflt, hide_input=p.hide_input,
                            confirmation_prompt=p.confirmation_prompt, type=p.type)
            return value, ParameterSource.PROMPT

        if dm is not UNSET:
            return dm, ParameterSource.DEFAULT_MAP

        if p.required:
            raise MissingParameter(ctx=ctx, param=p)
        if p.has_default:
            return self._default_value(ctx, p, p.default), ParameterSource.DEFAULT
        if p.count:
            return 0, ParameterSource.DEFAULT
        if p.multiple or (isinstance(p, Argument) and p.variadic):
            return (), ParameterSource.DEFAULT
        return None, ParameterSource.DEFAULT

    def _process_values(self, ctx):
        for p in self.get_params(ctx):
            if p.is_eager and isinstance(p, Option):
                continue
            value, source = self._resolve(ctx, p)
            if source is ParameterSource.COMMANDLINE and p.deprecated:
                pass
            value = p.run_callback(ctx, value)
            if p.expose_value:
                ctx._set_value(p.name, value, source)
            else:
                ctx._sources[p.name] = source

    # --- invocation -----------------------------------------------------
    def invoke(self, ctx):
        """Run this command in ``ctx`` (already parsed). Returns the callback result."""
        if self.deprecated:
            note = f" {self.deprecation_note}" if self.deprecation_note else ""
            sys.stderr.write(f"DeprecationWarning: The command '{ctx.command_path}' is deprecated.{note}\n")
        try:
            with ctx:
                self._process_values(ctx)
                kwargs = {p.name: ctx.params.get(p.name) for p in self.get_params(ctx)
                          if p.expose_value and not p.is_eager}
                if self.callback is None:
                    return None
                return self.callback(**kwargs)
        finally:
            ctx.close()

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True, **extra):
        if args is None:
            args = sys.argv[1:]
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else "cli"
        from . import completion

        if completion.maybe_complete(self, prog_name, args, complete_var):
            raise SystemExit(0) if standalone_mode else None
        ctx = None
        try:
            try:
                ctx = self.make_context(prog_name, args, **extra)
                rv = self.invoke(ctx)
                if not standalone_mode:
                    return rv
                sys.stdout.flush()
                raise SystemExit(0)
            except Exit as e:
                if standalone_mode:
                    raise SystemExit(e.exit_code)
                return e.exit_code
            except OptlynError as e:
                if not standalone_mode:
                    raise
                e.show()
                raise SystemExit(e.exit_code)
            except (KeyboardInterrupt, EOFError):
                if not standalone_mode:
                    raise
                sys.stderr.write("\nAborted!\n")
                raise SystemExit(1)
        finally:
            if ctx is not None:
                try:
                    ctx.close()
                except Exception:
                    pass


def _make_help_param(names):
    def cb(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        from .help import format_help
        from .termui import echo

        echo(format_help(ctx))
        ctx.exit()

    return Option(list(names), is_flag=True, expose_value=False, is_eager=True,
                  callback=cb, help="Show this message and exit.")


class Group(Command):
    """A command that dispatches to named subcommands."""

    def __init__(self, name=None, callback=None, params=None, commands=None,
                 invoke_without_command=False, no_args_is_help=None, subcommand_metavar=None,
                 chain=False, result_callback=None, **kwargs):
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        super().__init__(name=name, callback=callback, params=params,
                         no_args_is_help=no_args_is_help, **kwargs)
        self.commands = dict(commands or {})
        self.invoke_without_command = invoke_without_command
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self.result_callback_func = result_callback

    # --- children -------------------------------------------------------
    def add_command(self, cmd, name=None):
        if self.chain and isinstance(cmd, Group):
            raise TypeError("Groups cannot be nested under a chaining group.")
        key = name or cmd.name
        if not key:
            raise ValueError("A command needs a name to be registered.")
        self.commands[key] = cmd

    def command(self, *args, **kwargs):
        return command_decorator(self, *args, **kwargs)

    def group(self, *args, **kwargs):
        return group_decorator(self, *args, **kwargs)

    def result_callback(self):
        def decorator(f):
            self.result_callback_func = f
            return f

        return decorator

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        norm = self._norm(ctx, cmd_name)
        for k, v in self.commands.items():
            if self._norm(ctx, k) == norm:
                return v
        return None

    def _visible_commands(self, ctx):
        out = []
        for n in self.list_commands(ctx):
            c = self.get_command(ctx, n)
            if c is None or getattr(c, "hidden", False):
                continue
            out.append((n, c))
        return out

    def _is_command_name(self, ctx, tok):
        return self.get_command(ctx, tok) is not None

    # --- parsing ----------------------------------------------------------
    def parse_args(self, ctx, args):
        ctx._raw = {}
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            from .help import format_help

            sys.stderr.write(format_help(ctx))
            raise UsageError("Missing command.")
        rest = self._parse_tokens(ctx, list(args))
        if rest:
            name = rest[0]
            if self.get_command(ctx, name) is None:
                raise NoSuchCommand(name, ctx)
        elif not self.invoke_without_command:
            raise MissingCommand(ctx)
        ctx.args = rest
        return rest

    # --- invocation -----------------------------------------------------
    def invoke(self, ctx):
        rest = list(ctx.args)
        if not rest:
            ctx.invoked_subcommand = None
            return self._run_group_only(ctx)
        if self.chain:
            ctx.invoked_subcommand = CHAIN
            return self._run_chain(ctx, rest)
        name = rest[0]
        cmd = self.get_command(ctx, name)
        ctx.invoked_subcommand = name
        try:
            with ctx:
                self._process_values(ctx)
                if self.deprecated:
                    sys.stderr.write(f"DeprecationWarning: The command '{ctx.command_path}' is deprecated.\n")
                if self.callback is not None:
                    self.callback(**self._kwargs(ctx))
            sub_ctx = cmd.make_context(name, rest[1:], parent=ctx)
            rv = cmd.invoke(sub_ctx)
            if self.result_callback_func is not None:
                with ctx:
                    return self.result_callback_func(rv, **self._kwargs(ctx))
            return rv
        finally:
            ctx.close()

    def _kwargs(self, ctx):
        return {p.name: ctx.params.get(p.name) for p in self.get_params(ctx)
                if p.expose_value and not p.is_eager}

    def _run_group_only(self, ctx):
        try:
            with ctx:
                self._process_values(ctx)
                rv = None
                if self.callback is not None:
                    rv = self.callback(**self._kwargs(ctx))
                if self.result_callback_func is not None:
                    return self.result_callback_func(rv, **self._kwargs(ctx))
                return rv
        finally:
            ctx.close()

    def _run_chain(self, ctx, rest):
        # Split the remaining tokens into one segment per subcommand.
        segments = []
        tokens = list(rest)
        while tokens:
            name = tokens[0]
            cmd = self.get_command(ctx, name)
            if cmd is None:
                raise NoSuchCommand(name, ctx)
            j = 1
            while j < len(tokens) and not self._is_command_name(ctx, tokens[j]):
                j += 1
            segments.append((name, cmd, tokens[1:j]))
            tokens = tokens[j:]
        try:
            with ctx:
                self._process_values(ctx)
                if self.callback is not None:
                    self.callback(**self._kwargs(ctx))
        finally:
            pass
        results = []
        for name, cmd, seg_args in segments:
            sub = cmd.make_context(name, seg_args, parent=ctx)
            results.append(cmd.invoke(sub))
        try:
            if self.result_callback_func is not None:
                with ctx:
                    return self.result_callback_func(results, **self._kwargs(ctx))
            return results
        finally:
            ctx.close()


class CommandCollection(Group):
    """Union of subcommands from several source groups."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name=name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = set()
        for src in self.sources:
            names.update(src.list_commands(ctx))
        names.update(self.commands)
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        for src in self.sources:
            c = src.get_command(ctx, cmd_name)
            if c is not None:
                return c
        return None


# --- decorators --------------------------------------------------------

def command_decorator(parent=None, name=None, cls=None, **attrs):
    """Build a Command from a function (``@command`` / ``@command()``)."""
    def decorator(f):
        return _make(f, name, cls or Command, attrs, parent)

    if callable(name) and not isinstance(name, str):
        f, name = name, None
        return _make(f, None, cls or Command, attrs, parent)
    return decorator


def group_decorator(parent=None, name=None, cls=None, **attrs):
    def decorator(f):
        return _make(f, name, cls or Group, attrs, parent)

    if callable(name) and not isinstance(name, str):
        f, name = name, None
        return _make(f, None, cls or Group, attrs, parent)
    return decorator


def _make(f, name, klass, attrs, parent):
    params = take_declared_params(f)
    cmd_name = name or _name_from_function(f)
    help_text = attrs.pop("help", None)
    if help_text is None:
        help_text = _docstring(f)
    if help_text is not None and "\f" in help_text:
        help_text = help_text.split("\f", 1)[0]
    if klass is CommandCollection and "sources" not in attrs:
        attrs["sources"] = []
    cmd = klass(name=cmd_name, callback=f, params=params, help=help_text, **attrs)
    if parent is not None:
        parent.add_command(cmd, cmd_name)
    return cmd


def command(name=None, cls=None, **attrs):
    if callable(name) and not isinstance(name, str):
        return command_decorator(None, None, cls, **attrs)(name)
    return command_decorator(None, name, cls, **attrs)


def group(name=None, cls=None, **attrs):
    if callable(name) and not isinstance(name, str):
        return group_decorator(None, None, cls, **attrs)(name)
    return group_decorator(None, name, cls, **attrs)


# Re-export for ``from optlyn import help_option`` convenience.
__all__ = ["Command", "Group", "CommandCollection", "command", "group", "CHAIN"]
