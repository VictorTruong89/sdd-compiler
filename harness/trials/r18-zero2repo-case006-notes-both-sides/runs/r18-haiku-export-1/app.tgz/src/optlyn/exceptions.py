"""Exception classes used by Optlyn.

# spec: N-000796 (Abort, BadParameter exported classes)
# spec: N-000735 (exit-status classes: usage 2, abort/general 1)
"""

from __future__ import annotations


class OptlynError(Exception):
    """Base class for Optlyn-signalled errors (general error class, exit 1)."""

    exit_code = 1

    def __init__(self, message: str = "", ctx=None, param=None, param_hint=None):
        super().__init__(message)
        self.message = message
        self.ctx = ctx
        self.param = param
        self.param_hint = param_hint

    def show(self, file=None) -> None:
        import sys

        print(self.format_message(), file=file or sys.stderr)

    def format_message(self) -> str:
        return f"Error: {self.message}"


class UsageError(OptlynError):
    """A usage failure: exit status 2, help hint on stderr."""

    exit_code = 2

    def __init__(self, message: str, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx, param, param_hint)
        self.usage = None

    def format_message(self) -> str:
        if self.ctx is not None and getattr(self.ctx, "command", None) is not None:
            prog = self.ctx.command_path
            usage = self.ctx.get_usage()
            return f"{usage}\nTry '{prog} --help' for help.\n\nError: {self.message}"
        return f"Error: {self.message}"


class BadParameter(UsageError):
    """Raised by callbacks or types to refuse a value (usage error)."""

    def format_message(self) -> str:
        param_name = None
        if self.param is not None:
            param_name = self.param.get_error_hint()
        elif self.param_hint:
            param_name = self.param_hint
        if param_name:
            return f"Invalid value for {param_name}: {self.message}"
        return f"Invalid value: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter was omitted."""

    def __init__(self, message: str = "", ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx, param, param_hint)

    def format_message(self) -> str:
        hint = self.param.get_error_hint() if self.param is not None else self.param_hint
        return f"Missing parameter: {hint or 'value'}"


class NoSuchOption(UsageError):
    """An unknown option token."""

    def __init__(self, option_name: str, ctx=None):
        super().__init__(f"No such option: {option_name}", ctx)
        self.option_name = option_name


class NoSuchCommand(UsageError):
    """An unknown subcommand name."""

    def __init__(self, cmd_name: str, ctx=None):
        super().__init__(f"No such command '{cmd_name}'.", ctx)
        self.cmd_name = cmd_name


class MissingCommand(UsageError):
    """A group was invoked without a subcommand name where one is required."""

    def __init__(self, ctx=None):
        super().__init__("Missing command.", ctx)


class BadArgumentUsage(UsageError):
    """Extra or malformed positional tokens."""


class Abort(OptlynError):
    """Abort indication: exit status 1, distinct abort message on stderr."""

    exit_code = 1

    def __init__(self, message: str = "Aborted!"):
        super().__init__(message)

    def format_message(self) -> str:
        return self.message


class Exit(Exception):
    """Author clean stop with a status; not an error."""

    def __init__(self, code: int = 0):
        super().__init__(code)
        self.exit_code = code


class FileError(OptlynError):
    """A general file-open failure (exit 1) that names the path."""

    def __init__(self, filename: str, hint: str = "unknown error"):
        super().__init__(f"Could not open file '{filename}': {hint}")
        self.filename = filename


class Deprecated(Exception):
    """Internal marker, unused for control flow."""
