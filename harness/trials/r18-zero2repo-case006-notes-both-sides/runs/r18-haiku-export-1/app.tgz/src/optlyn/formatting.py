"""Text wrapping and help-page formatting helpers.

# spec: N-000801 (optlyn.formatting.wrap_text)
# spec: N-000680 (max content width 100 unless caller sets another)
# spec: N-000834..N-000845 (help page sections, wrap rules)
"""

from __future__ import annotations

import re
import textwrap

DEFAULT_MAX_CONTENT_WIDTH = 100
DEFAULT_AUTO_WIDTH = 80  # auto-detected width cap (see NOTES.md: CF-000087)


def wrap_text(text, width=DEFAULT_MAX_CONTENT_WIDTH, initial_indent="", subsequent_indent="",
              preserve_paragraphs=False):
    """Wrap ``text`` to ``width``. Accepts any string; never fails.

    Single newlines inside a paragraph are not preserved. A paragraph whose
    first line is only a backspace character is kept with its line breaks and
    the backspace line is stripped.
    """
    text = "" if text is None else str(text)
    width = max(int(width), 1)
    paragraphs = re.split(r"\n\s*\n", text)
    out = []
    for para in paragraphs:
        lines = para.split("\n")
        if lines and lines[0].strip("\b") == "" and lines[0] != "":
            # backspace-marked paragraph: keep line breaks
            kept = [ln for ln in lines[1:]]
            out.append("\n".join(subsequent_indent + ln for ln in kept))
            continue
        flat = " ".join(ln.strip() for ln in lines if ln.strip())
        if not flat:
            continue
        out.append(
            textwrap.fill(
                flat,
                width=width,
                initial_indent=initial_indent,
                subsequent_indent=subsequent_indent,
                break_on_hyphens=False,
                break_long_words=True,
            )
        )
    return "\n\n".join(out)


def short_help(text, limit=45):
    """First paragraph of ``text``, cut with '...' at ``limit`` characters."""
    if not text:
        return ""
    first = text.strip().split("\n\n", 1)[0]
    first = " ".join(first.split())
    if len(first) <= limit:
        return first
    return first[: limit - 3] + "..."


def first_sentence(text):
    if not text:
        return ""
    flat = " ".join(text.strip().split())
    m = re.match(r"(.+?[.!?])(\s|$)", flat)
    return m.group(1) if m else flat


def clean_docstring(doc):
    """Dedent a docstring; a form feed truncates it (the feed is removed)."""
    if not doc:
        return None
    if "\f" in doc:
        doc = doc.split("\f", 1)[0]
    return textwrap.dedent(doc).strip("\n")
