"""Terminal helpers: echo, styling, prompts, pager, progress, editor, launch.

# spec: N-000799 (exported terminal helpers)
# spec: N-000981..N-001012 (interface contract section 7)
# spec: N-000618..N-000688 (FP-11 terminal output and interaction helpers)
# spec: N-000484..N-000527 (FP-08 prompts, confirmation, hidden input)
"""

from __future__ import annotations

import getpass
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import time

from ._context_stack import get_current_context as _gcc
from .exceptions import Abort
from .fileio import open_file as _open_file
from .types import STRING, BOOL, ParamType, resolve_type

_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")

_COLORS = {
    "black": 30, "red": 31, "green": 32, "yellow": 33,
    "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
    "reset": 39,
}

_STYLE_CODES = {
    "bold": 1, "dim": 2, "italic": 3, "underline": 4, "blink": 5,
    "reverse": 7, "strikethrough": 9, "overline": 53,
}


def unstyle(text) -> str:
    return _ANSI_RE.sub("", str(text))


def _color_code(color, background=False):
    if color is None:
        return None
    base = 40 if background else 30
    if isinstance(color, str):
        if color not in _COLORS:
            raise TypeError(f"Unknown color {color!r}.")
        code = _COLORS[color]
        if background:
            if code == 39:
                return "49"
            code += 10  # 40-47 / 100-107
        return str(code)
    if isinstance(color, bool):
        raise TypeError("Invalid color value.")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise TypeError("Color index out of range 0-255.")
        return f"{48 if background else 38};5;{color}"
    if isinstance(color, (list, tuple)) and len(color) == 3:
        if not all(isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color):
            raise TypeError("RGB color components must be integers 0-255.")
        return f"{48 if background else 38};2;{color[0]};{color[1]};{color[2]}"
    raise TypeError(f"Invalid color {color!r}.")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True) -> str:
    """Wrap ``text`` in ANSI SGR sequences. Invalid colors raise TypeError."""
    codes = []
    fgc = _color_code(fg, False)
    bgc = _color_code(bg, True)
    if fgc is not None:
        codes.append(fgc)
    if bgc is not None:
        codes.append(bgc)
    for name, flag in (("bold", bold), ("dim", dim), ("underline", underline),
                       ("overline", overline), ("italic", italic), ("blink", blink),
                       ("reverse", reverse), ("strikethrough", strikethrough)):
        if flag:
            codes.append(str(_STYLE_CODES[name]))
    if not codes:
        return str(text)
    prefix = "\x1b[" + ";".join(codes) + "m"
    suffix = "\x1b[0m" if reset else ""
    return f"{prefix}{text}{suffix}"


def _stream_is_tty(stream) -> bool:
    try:
        return bool(stream.isatty())
    except Exception:
        return False


def _should_keep_styles(stream, color=None):
    if color is None:
        try:
            ctx = _gcc(silent=True)
        except Exception:
            ctx = None
        color = getattr(ctx, "color", None) if ctx is not None else None
    if color is not None:
        return bool(color)
    return _stream_is_tty(stream)


def _write(stream, text: str):
    try:
        stream.write(text)
    except UnicodeEncodeError:
        enc = getattr(stream, "encoding", None) or "ascii"
        data = text.encode("utf-8")
        buf = getattr(stream, "buffer", None)
        if buf is not None:
            stream.flush()
            buf.write(data)
        else:
            stream.write(data.decode(enc, "replace"))
    stream.flush()


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write text or bytes. Styles are stripped unless the stream is a TTY or color is forced on."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        buf = getattr(file, "buffer", None)
        if buf is not None:
            file.flush()
            buf.write(message + (b"\n" if nl else b""))
            buf.flush()
        else:
            file.write(message.decode("utf-8", "replace") + ("\n" if nl else ""))
        return
    text = str(message)
    if not _should_keep_styles(file, color):
        text = unstyle(text)
    if nl:
        text += "\n"
    _write(file, text)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is None:
        message = ""
    echo(style(message, **styles), file=file, nl=nl, err=err, color=color)


def _is_interactive():
    return _stream_is_tty(sys.stdin) or _stream_is_tty(sys.stdout)


class _PagerStream:
    def __init__(self, buffer):
        self._buf = buffer

    def write(self, text):
        self._buf.append(str(text))

    def flush(self):
        pass


def echo_via_pager(text_or_generator, color=None):
    """Send text to the pager ($PAGER) when interactive; otherwise to stdout."""
    if callable(text_or_generator) and not isinstance(text_or_generator, (str, bytes)):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        chunks = [text_or_generator]
    else:
        chunks = [str(c) for c in text_or_generator]
    keep = bool(color) if color is not None else _is_interactive()
    chunks = [c if keep else unstyle(c) for c in chunks]
    pager = os.environ.get("PAGER")
    if not _is_interactive() or not pager:
        for c in chunks:
            _write(sys.stdout, c)
        return
    proc = subprocess.Popen(shlex.split(pager), stdin=subprocess.PIPE, text=True)
    try:
        for c in chunks:
            proc.stdin.write(c)
            proc.stdin.flush()
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        proc.wait()


class _PagerFile:
    """Context manager yielding a writable text stream routed through the pager."""

    def __init__(self, color=None):
        self.color = color
        self._chunks = []

    def __enter__(self):
        self._stream = _PagerStream(self._chunks)
        return self._stream

    def __exit__(self, *exc):
        echo_via_pager(self._chunks, color=self.color)
        return False


def get_pager_file(color=None):
    return _PagerFile(color)


class ProgressBar:
    def __init__(self, iterable=None, length=None, label=None, hidden=False, **options):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label
        self.hidden = hidden or not _stream_is_tty(sys.stdout)
        self.pos = 0
        self.start = time.time()
        self._printed_label = False
        if label and not hidden and not _stream_is_tty(sys.stdout):
            echo(label)
            self._printed_label = True

    def _render(self):
        if self.hidden or self.length in (None, 0):
            return
        frac = min(self.pos / self.length, 1.0)
        width = 30
        filled = int(width * frac)
        elapsed = time.time() - self.start
        remaining = (elapsed / self.pos * (self.length - self.pos)) if self.pos else 0
        bar = "#" * filled + "-" * (width - filled)
        line = f"\r{self.label or ''} [{bar}] {self.pos}/{self.length} eta {int(remaining)}s"
        sys.stdout.write(line)
        sys.stdout.flush()

    def update(self, n_steps, current_item=None):
        self.pos += n_steps
        self._render()

    def __iter__(self):
        if self.iterable is None:
            return
        for item in self.iterable:
            yield item
            self.update(1)

    def finish(self):
        if not self.hidden and self.length:
            sys.stdout.write("\n")
            sys.stdout.flush()


class _Progress:
    def __init__(self, bar):
        self.bar = bar

    def __enter__(self):
        return self.bar

    def __exit__(self, *exc):
        self.bar.finish()
        return False


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    return _Progress(ProgressBar(iterable, length, label, hidden, **options))


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False, show_choices=True):
    """Ask for a value until it converts or input ends. Returns the converted value."""
    ptype = resolve_type(type, default)
    while True:
        suffix = ""
        if default is not None and show_default and not callable(default):
            suffix = f" [{default}]"
        elif callable(default):
            suffix = ""
        stream = sys.stderr if err else sys.stdout
        full = f"{text}{suffix}{prompt_suffix}"
        value = _read_line(full, hide_input, stream)
        if value == "" and default is not None:
            value = default() if callable(default) else default
            if isinstance(value, str) or not isinstance(value, (list, tuple)):
                pass
            return ptype.convert(value) if isinstance(value, str) else value
        if confirmation_prompt:
            again = _read_line(f"Repeat for confirmation{prompt_suffix}", hide_input, stream)
            if again != value:
                echo("Error: the two entered values do not match", err=True)
                continue
        try:
            return ptype.convert(value)
        except Exception as e:  # BadParameter from conversion: re-ask
            echo(f"Error: {getattr(e, 'message', e)}", err=True)
            continue


def _read_line(prompt_text, hide_input, stream):
    """Read one line of input for a prompt.

    Hidden input is read with getpass on a real terminal; otherwise (piped or
    in-process input) the line is read from sys.stdin without echo. Visible
    input typed into an in-process runner is echoed into captured output.
    """
    if hide_input and _stream_is_tty(sys.stdin):
        try:
            return getpass.getpass(prompt_text, stream=stream)
        except EOFError:
            raise Abort()
    _write(stream, prompt_text)
    line = sys.stdin.readline()
    if line == "":
        raise Abort()
    text = line.rstrip("\r\n")
    if not hide_input and getattr(sys.stdin, "_optlyn_runner", False):
        _write(stream, text + "\n")
    elif hide_input:
        _write(stream, "\n")
    return text


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True,
            err=False):
    """Yes/no question. Empty answer takes the default; other answers re-ask."""
    suffix = " [y/N]" if default is False else " [Y/n]"
    stream = sys.stderr if err else sys.stdout
    while True:
        answer = _read_line(f"{text}{suffix}{prompt_suffix}", False, stream).strip().lower()
        if answer == "":
            result = default
            break
        if answer in ("y", "yes"):
            result = True
            break
        if answer in ("n", "no"):
            result = False
            break
    if not result and abort:
        raise Abort()
    return result


def getchar(echo=False):
    """Read one character from the terminal (not the piped stdin where possible)."""
    try:
        import termios
        import tty

        fd = os.open("/dev/tty", os.O_RDONLY)
        try:
            old = termios.tcgetattr(fd)
            try:
                tty.setraw(fd)
                ch = os.read(fd, 1).decode("utf-8", "replace")
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
        finally:
            os.close(fd)
    except (ImportError, OSError):
        ch = sys.stdin.read(1)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch in ("\x04", "\x1a") or ch == "":
        raise EOFError()
    if echo:
        _write(sys.stdout, ch)
    return ch


def pause(info=None, err=False):
    """Print a message and wait for a key when interactive; no-op otherwise."""
    stream = sys.stderr if err else sys.stdout
    if info is None:
        info = "Press any key to continue..."
    if not _is_interactive():
        return
    _write(stream, info)
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass
    _write(stream, "\n")


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Open an editor. Returns saved text, or None when quitting without saving or when filename is given."""
    editor = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR") or (
        "notepad" if os.name == "nt" else "vi")
    if filename is not None:
        subprocess.call(shlex.split(editor) + [str(filename)], env=_merge_env(env))
        return None
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text or "")
        before = os.path.getmtime(path)
        subprocess.call(shlex.split(editor) + [path], env=_merge_env(env))
        after = os.path.getmtime(path)
        with open(path, encoding="utf-8") as f:
            saved = f.read()
        if require_save and after == before:
            # Quit without saving: no change was written.
            return None
        return saved
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


def _merge_env(env):
    if not env:
        return None
    merged = dict(os.environ)
    merged.update(env)
    return merged


def launch(url, wait=False, locate=False) -> int:
    """Open a URL or path with the default application; returns the opener's status."""
    if sys.platform == "darwin":
        cmd = ["open"]
    elif os.name == "nt":
        cmd = ["cmd", "/c", "start", ""]
    else:
        cmd = ["xdg-open"]
    if locate and sys.platform == "darwin":
        cmd.append("-R")
    cmd.append(str(url))
    proc = subprocess.Popen(cmd)
    if wait:
        return proc.wait()
    return 0


def clear():
    """Clear the screen when attached to a terminal; otherwise nothing."""
    if _stream_is_tty(sys.stdout):
        _write(sys.stdout, "\033[2J\033[H")


def get_app_dir(app_name, roaming=True, force_posix=False) -> str:
    """Per-user config directory for ``app_name`` (FP-11 rules)."""
    home = os.path.expanduser("~")
    if force_posix or (os.name != "nt" and sys.platform != "darwin"):
        folder = "-".join(app_name.lower().split())
        if force_posix:
            return os.path.join(home, "." + folder)
        xdg = os.environ.get("XDG_CONFIG_HOME")
        base = xdg if xdg else os.path.join(home, ".config")
        return os.path.join(base, folder)
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    base = os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming")
    return os.path.join(base, app_name)


def format_filename(filename, shorten=False) -> str:
    """Printable, UTF-8-safe text for a file name (str, bytes or path-like)."""
    if hasattr(filename, "__fspath__"):
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        filename = os.fsdecode(filename)
    text = str(filename)
    if shorten:
        text = os.path.basename(text) or text
    return text.encode("utf-8", "backslashreplace").decode("utf-8")


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    return _open_file(filename, mode, encoding, errors, lazy=lazy, atomic=atomic)
