"""Parameters (options and arguments), declaration decorators, ready-made options.

# spec: N-000178..N-000284 (FP-03 options), N-000285..N-000329 (FP-04 arguments)
# spec: N-000881..N-000935 (interface contract section 4)
# spec: N-000850..N-000880 (declaration helpers; decorator-attached declarations)
"""

from __future__ import annotations

import enum
import os
import re
import sys

from .exceptions import BadParameter
from .types import BOOL, STRING, INT, ParamType, infer_type, resolve_type, _resolve_type, Tuple


class ParameterSource(enum.Enum):
    """The five distinguishable value sources (FP-07)."""

    PROMPT = "prompt"
    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"


_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

PREFIX_CHARS = ("-", "/", "+")
UNSET = object()


def _strip_prefix(name: str) -> str:
    i = 0
    while i < len(name) and name[i] in PREFIX_CHARS:
        i += 1
    return name[i:]


def _is_flag_name(s: str) -> bool:
    return len(s) > 1 and s[0] in PREFIX_CHARS


class Parameter:
    """Base class for options and arguments."""

    param_type_name = "parameter"
    # Defaults for attributes that only options set; shared code reads them on both kinds.
    is_flag = False
    count = False
    opts = ()
    secondary_opts = ()
    is_eager = False
    deprecated = False
    variadic = False
    flag_value = None
    show_default = None
    show_envvar = False
    prompt = None
    hide_input = False
    confirmation_prompt = False
    prompt_required = True
    attrs = {}

    def __init__(self, param_decls=None, type=None, required=False, default=UNSET,
                 callback=None, nargs=None, multiple=False, metavar=None, expose_value=True,
                 is_eager=False, envvar=None, shell_complete=None, deprecated=False,
                 hidden=False, help=None, allow_from_autoenv=True, **attrs):
        self.name = None
        self.default = None if default is UNSET else default
        self.has_default = default is not UNSET
        self.required = required
        self.callback = callback
        self.nargs = 1 if nargs is None else nargs
        self.multiple = multiple
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        self.envvar = envvar
        self.shell_complete_func = shell_complete
        self.deprecated = deprecated
        self.hidden = hidden
        self.help = help
        self.allow_from_autoenv = allow_from_autoenv
        self._raw_type = type
        self.type = resolve_type(type, None if default is UNSET else default)
        self.attrs = attrs

    def get_error_hint(self):
        return self.name

    @property
    def human_readable_name(self):
        return self.name

    def get_metavar(self):
        if self.metavar is not None:
            return self.metavar
        return self.type.get_metavar(self)

    def get_default(self, ctx):
        d = self.default
        if callable(d):
            d = d()
        return d

    def convert(self, value, ctx):
        if value is None:
            return None
        if self.multiple or self.nargs != 1:
            if isinstance(value, (list, tuple)):
                return tuple(self._conv_one(v, ctx) for v in value) if not isinstance(self.type, Tuple) else tuple(self.type.convert(v, self, ctx) for v in value)
            self.fail_default_sequence(value)
        return self._conv_one(value, ctx)

    def _conv_one(self, value, ctx):
        return self.type.convert(value, self, ctx)

    def fail_default_sequence(self, value):
        raise BadParameter(f"needs an iterable (sequence) default, got {value!r}.", param=self)

    def run_callback(self, ctx, value):
        if self.callback is not None:
            return self.callback(ctx, self, value)
        return value

    def shell_complete(self, ctx, incomplete):
        if self.shell_complete_func is not None:
            return self.shell_complete_func(ctx, self, incomplete)
        return self.type.shell_complete(ctx, self, incomplete)

    def env_names(self, ctx=None):
        if self.envvar is None:
            return []
        if isinstance(self.envvar, str):
            return [self.envvar]
        return list(self.envvar)

    def auto_env_name(self, ctx):
        prefix = getattr(ctx, "_env_prefix", None) if ctx is not None else None
        if not prefix or not self.allow_from_autoenv:
            return None
        return f"{prefix}_{self.name}".upper().replace("-", "_")

    def read_envvar(self, ctx):
        """Return (raw_value, name) for the first set environment variable, or (None, None)."""
        names = self.env_names(ctx)
        for n in names:
            v = os.environ.get(n)
            if v is not None and v != "":
                return v, n
        auto = self.auto_env_name(ctx)
        if auto and not names:
            v = os.environ.get(auto)
            if v:
                return v, auto
        return None, None

    def split_env(self, raw):
        if self.multiple or self.nargs != 1 or isinstance(self.type, Tuple):
            return self.type.split_env_value(raw) if hasattr(self.type, "split_env_value") else raw.split()
        return raw

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"


class Option(Parameter):
    """A named parameter introduced by a prefix (``--name``, ``-n``, ``/n``)."""

    def __init__(self, param_decls=None, is_flag=None, flag_value=None, count=False,
                 secondary_opts=None, show_default=None, show_envvar=False, prompt=None,
                 prompt_required=True, hide_input=False, confirmation_prompt=False,
                 is_eager=False, deprecated=False, **attrs):
        decls = list(param_decls or [])
        dest = None
        opts, secondary = [], []
        for d in decls:
            if _is_flag_name(d):
                if "/" in d and d[0] in PREFIX_CHARS and "/" in d[1:]:
                    on, off = d.split("/", 1)
                    opts.append(on)
                    secondary.append(off)
                else:
                    opts.append(d)
            else:
                dest = d
        if not opts:
            raise TypeError("Option needs at least one flag name.")
        if secondary_opts:
            secondary.extend(secondary_opts)
        self.opts = opts
        self.secondary_opts = secondary
        self.count = count
        self.show_envvar = show_envvar
        self.show_default = show_default
        self.prompt = prompt
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.deprecated = deprecated
        self.is_eager = is_eager

        default = attrs.get("default", UNSET)
        has_on_off = bool(secondary)
        if is_flag is None:
            is_flag = (has_on_off or count or isinstance(default, bool)
                       or flag_value is not None)
        if count:
            is_flag = False
        self.is_flag = bool(is_flag) or has_on_off
        if self.is_flag and flag_value is None:
            flag_value = not (default is True or default == True)  # noqa: E712
            if has_on_off:
                flag_value = True
        self.flag_value = flag_value
        attrs.pop("default", None)
        type_arg = attrs.pop("type", None)
        if self.is_flag:
            type_arg = type_arg or BOOL
            if has_on_off or count:
                pass
        super().__init__(param_decls=decls, type=type_arg,
                         default=default if default is not UNSET else (False if self.is_flag and not count and not has_on_off else UNSET) if False else default,
                         **attrs)
        if count:
            self.type = INT
            if not self.has_default:
                self.default = None
        if self.is_flag and not self.has_default:
            self.default = False
            self.has_default = True
        if self.is_flag and self.has_default and isinstance(self.default, bool) and self.flag_value is None:
            self.flag_value = not self.default
        # Parameter.__init__ resets these; restore the values given to Option.
        self.is_eager = is_eager
        self.deprecated = deprecated
        self.dest = dest or self._infer_dest()
        self.name = self.dest
        self.help_text = self.help

    def _infer_dest(self):
        # FP-03: first long name, otherwise first short name; prefix stripped, dashes -> underscores.
        for o in self.opts:
            if o[:2] == "--" or (len(o) > 2 and o[0] in PREFIX_CHARS and o[1] in PREFIX_CHARS):
                return _strip_prefix(o).replace("-", "_")
        return _strip_prefix(self.opts[0]).replace("-", "_")

    def get_error_hint(self):
        return " / ".join(self.opts)

    def get_metavar(self):
        if self.is_flag or self.count:
            return None if self.metavar is None else self.metavar
        return super().get_metavar()

    def env_names(self, ctx=None):
        return super().env_names(ctx)

    def auto_env_name(self, ctx):
        return super().auto_env_name(ctx)

    def convert(self, value, ctx):
        if self.is_flag:
            return bool(value) if not isinstance(value, bool) else value
        return super().convert(value, ctx)


class Argument(Parameter):
    """A positional parameter bound in declaration order."""

    def __init__(self, param_decls=None, **attrs):
        decls = list(param_decls or [])
        if len(decls) != 1:
            raise TypeError("Argument takes exactly one destination name.")
        dest = decls[0]
        nargs = attrs.pop("nargs", None)
        required = attrs.pop("required", None)
        default = attrs.get("default", UNSET)
        if required is None:
            # A variadic argument is optional unless marked required (empty tuple when omitted).
            required = default is UNSET and nargs != -1
        if nargs is None:
            nargs = 1
        if nargs == 0 or (nargs != -1 and nargs < 1):
            raise TypeError("nargs must be a positive integer or -1 (variadic).")
        if nargs == -1 and required is False and default is UNSET:
            pass
        if attrs.get("deprecated") and required:
            raise TypeError("A deprecated argument cannot be required.")
        if attrs.get("deprecated") and default is UNSET and not attrs.get("default") is None and False:
            pass
        super().__init__(param_decls=decls, nargs=nargs, required=required, **attrs)
        self.name = dest
        self.dest = dest
        if default is UNSET and nargs == -1:
            self.default = ()
        # A variadic argument is delivered as one tuple (not via ``multiple``).
        self.variadic = nargs == -1

    def get_error_hint(self):
        return self.name.upper()

    def get_metavar(self):
        if self.metavar is not None:
            return self.metavar
        return self.name.upper()


# ---- decorators -----------------------------------------------------------

_PARAMS_ATTR = "__optlyn_params__"


def _attach(f, param):
    if not hasattr(f, _PARAMS_ATTR):
        setattr(f, _PARAMS_ATTR, [])
    getattr(f, _PARAMS_ATTR).append(param)
    return f


def option(*param_decls, cls=None, **attrs):
    """Attach an option to a function (returns a decorator)."""
    klass = cls or Option

    def decorator(f):
        _attach(f, klass(list(param_decls), **attrs))
        return f

    return decorator


def argument(*param_decls, cls=None, **attrs):
    klass = cls or Argument

    def decorator(f):
        _attach(f, klass(list(param_decls), **attrs))
        return f

    return decorator


def _eager_flag(f_or_none, decls, **attrs):
    def decorator(f):
        _attach(f, Option(list(decls), is_flag=True, expose_value=False, is_eager=True, **attrs))
        return f

    return decorator


def help_option(*param_decls, **kwargs):
    """Extra eager help flag; the declared names print help."""
    decls = list(param_decls) or ["--help"]
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("expose_value", False)
    kwargs["is_eager"] = True
    kwargs["is_flag"] = True
    kwargs["_help_flag"] = True

    def decorator(f):
        _attach(f, Option(decls, **kwargs))
        return f

    return decorator


def version_option(version=None, *param_decls, package_name=None, prog_name=None,
                   message=None, **kwargs):
    """Eager --version flag. ``version`` None means detect via ``package_name``."""
    decls = list(param_decls) or ["--version"]

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        ver = version
        if ver is None:
            ver = detect_version(package_name or prog_name or ctx.info_name)
        name = prog_name or ctx.info_name or package_name or ""
        text = (message or "%(prog)s, version %(version)s") % {"prog": name, "version": ver, "package": package_name}
        from .termui import echo

        echo(text, color=False)
        ctx.exit()

    kwargs.setdefault("help", "Show the version and exit.")
    kwargs.update(is_flag=True, expose_value=False, is_eager=True, callback=callback,
                   is_version=True)

    def decorator(f):
        _attach(f, Option(decls, **kwargs))
        return f

    return decorator


def custom_version_option(callback, *param_decls, **kwargs):
    """Eager --version flag whose whole identity is ``callback(ctx)``."""
    decls = list(param_decls) or ["--version"]

    def cb(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        from .termui import echo

        echo(str(callback(ctx)), color=False)
        ctx.exit()

    kwargs.setdefault("help", "Show the version and exit.")
    kwargs.update(is_flag=True, expose_value=False, is_eager=True, callback=cb)

    def decorator(f):
        _attach(f, Option(decls, **kwargs))
        return f

    return decorator


def password_option(*param_decls, **kwargs):
    decls = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("required", True)  # an omitted password prompts (FP-08)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)

    def decorator(f):
        _attach(f, Option(decls, **kwargs))
        return f

    return decorator


def confirmation_option(*param_decls, **kwargs):
    decls = list(param_decls) or ["--yes"]
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("help", "Confirm the action without prompting.")
    prompt_text = kwargs.pop("prompt", "Do you want to continue?")

    def cb(ctx, param, value):
        if not value:
            from .termui import confirm

            if not confirm(prompt_text, default=False):
                from .exceptions import Abort

                raise Abort()
        return value

    kwargs.setdefault("callback", cb)
    kwargs.setdefault("expose_value", False)

    def decorator(f):
        _attach(f, Option(decls, **kwargs))
        return f

    return decorator


def take_declared_params(f):
    """Return the parameter list attached to ``f`` and clear it from the function."""
    params = getattr(f, _PARAMS_ATTR, None)
    if params is None:
        return []
    params = list(reversed(params))
    try:
        delattr(f, _PARAMS_ATTR)
    except AttributeError:
        pass
    return params


def detect_version(name):
    try:
        from importlib import metadata

        return metadata.version(name)
    except Exception:
        pass
    try:
        from importlib import metadata

        dists = metadata.packages_distributions().get(name)
        if dists:
            return metadata.version(dists[0])
    except Exception:
        pass
    mod = sys.modules.get(name)
    if mod is not None and getattr(mod, "__version__", None) and False:
        return mod.__version__
    return "unknown"
