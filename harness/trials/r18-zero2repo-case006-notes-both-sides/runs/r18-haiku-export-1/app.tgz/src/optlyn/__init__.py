"""Optlyn: composable command line interfaces.

Public names are re-exported here so that ``from optlyn import <name>`` works.

# spec: N-000791..N-000802 (interface contract section 1: package and exports)
"""

from __future__ import annotations

import functools

from . import _context_stack
from ._context_stack import get_current_context
from .context import Context
from .core import CHAIN, Command, CommandCollection, Group, command, group
from .exceptions import Abort, BadParameter, Exit, MissingParameter, NoSuchCommand, NoSuchOption, OptlynError, UsageError
from .params import (Argument, Option, Parameter, ParameterSource, confirmation_option,
                     custom_version_option, help_option, password_option, version_option)
from .params import argument, option
from .params import ParameterSource as _PS  # noqa: F401
from .termui import (clear, confirm, echo, echo_via_pager, edit, format_filename, get_app_dir,
                     get_pager_file, getchar, launch, open_file, pause, progressbar, prompt,
                     secho, style, unstyle)
from .types import (BOOL, FLOAT, INT, STRING, UNPROCESSED, UUID, Choice, DateTime, File,
                    FloatRange, IntRange, ParamType, Path, Tuple)

__version__ = "0.1.0"


def pass_context(f):
    """Pass the current Context as the first positional argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(f):
    """Pass the current context's ``obj`` as the first positional argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type, ensure=False):
    """Pass the nearest object of ``object_type`` found walking up the context chain."""

    def decorator(f):
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            return f(obj, *args, **kwargs)

        return new_func

    return decorator


__all__ = [
    "command", "group", "option", "argument", "help_option", "version_option",
    "custom_version_option", "password_option", "confirmation_option", "pass_context",
    "pass_obj", "make_pass_decorator",
    "Command", "Group", "CommandCollection", "Context", "Option", "Parameter", "ParamType",
    "BadParameter", "Abort", "UsageError", "MissingParameter", "NoSuchOption", "NoSuchCommand",
    "OptlynError", "Exit", "CHAIN", "ParameterSource",
    "STRING", "INT", "FLOAT", "BOOL", "UUID", "UNPROCESSED",
    "Choice", "DateTime", "IntRange", "FloatRange", "Tuple", "File", "Path",
    "echo", "secho", "style", "unstyle", "echo_via_pager", "get_pager_file", "progressbar",
    "prompt", "confirm", "getchar", "pause", "edit", "launch", "clear", "get_app_dir",
    "get_current_context", "format_filename", "open_file",
]
