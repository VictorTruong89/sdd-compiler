"""In-process runner: ``optlyn.testing.CliRunner``.

# spec: N-001038..N-001044 (interface contract section 9)
# spec: N-000736..N-000763 (FP-14 in-process runner)
"""

from __future__ import annotations

import contextlib
import io
import os
import shutil
import sys
import tempfile


class Result:
    def __init__(self, runner_output, stdout_bytes, stderr_bytes, exit_code, exception, exc_info=None):
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_text = runner_output
        self.stdout = stdout_bytes.decode("utf-8", "replace")
        self.stderr = stderr_bytes.decode("utf-8", "replace")

    @property
    def output(self):
        return self.output_text

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class _Recorder:
    """Shared record of writes in order, per stream name."""

    def __init__(self):
        self.order = []  # list of (name, bytes)
        self.bufs = {"stdout": bytearray(), "stderr": bytearray()}


class _CapStream:
    def __init__(self, rec, name, charset):
        self._rec = rec
        self._name = name
        self.encoding = charset
        self.errors = "strict"

    def write(self, b):
        data = bytes(b)
        self._rec.bufs[self._name].extend(data)
        self._rec.order.append((self._name, data))
        return len(data)

    def isatty(self):
        return False

    def fileno(self):
        raise io.UnsupportedOperation("no real file descriptor")


class _TextCap:
    def __init__(self, rec, name, charset):
        self._raw = _CapStream(rec, name, charset)
        self.buffer = self._raw
        self.encoding = charset
        self.errors = "strict"
        self.name = "<" + name + ">"

    def write(self, s):
        if isinstance(s, str):
            data = s.encode(self.encoding or "utf-8", "replace")
        else:
            data = bytes(s)
        self._raw.write(data)
        return len(s)

    def flush(self):
        pass

    def isatty(self):
        return False

    def fileno(self):
        raise io.UnsupportedOperation("no real file descriptor")


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        rec = _Recorder()
        out = _TextCap(rec, "stdout", self.charset)
        err = _TextCap(rec, "stderr", self.charset)
        if isinstance(input, str):
            input = input.encode(self.charset)
        stdin_bytes = input or b""
        stdin = io.TextIOWrapper(io.BytesIO(stdin_bytes), encoding=self.charset)
        stdin.isatty = lambda: False  # type: ignore[assignment]
        stdin._optlyn_runner = True  # prompts echo typed lines into captured output

        merged = dict(self.env)
        if env:
            merged.update(env)
        saved_env = {}
        for k, v in merged.items():
            saved_env[k] = os.environ.get(k)
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = str(v)
        saved = (sys.stdin, sys.stdout, sys.stderr)
        sys.stdin, sys.stdout, sys.stderr = stdin, out, err
        try:
            yield rec
        finally:
            sys.stdin, sys.stdout, sys.stderr = saved
            for k, v in saved_env.items():
                if v is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = v

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False,
               **extra):
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if args is None:
            args = []
        elif isinstance(args, str):
            import shlex

            args = shlex.split(args)
        prog = extra.pop("prog_name", None) or getattr(cli, "name", None) or "root"
        exit_code = 0
        exception = None
        exc_info = None
        with self.isolation(input=input, env=env, color=color) as rec:
            try:
                cli.main(args=list(args), prog_name=prog, standalone_mode=extra.pop("standalone_mode", True),
                         **extra)
            except SystemExit as e:
                code = e.code
                if code is None:
                    exit_code = 0
                elif isinstance(code, int):
                    exit_code = code
                else:
                    sys.stderr.write(str(code) + "\n")
                    exit_code = 1
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
        text = _merged_text(rec, self.charset)
        return Result(text, bytes(rec.bufs["stdout"]), bytes(rec.bufs["stderr"]), exit_code,
                      exception, exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        if temp_dir is None:
            path = tempfile.mkdtemp()
            cleanup = True
        else:
            path = tempfile.mkdtemp(dir=temp_dir)
            cleanup = False
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if cleanup:
                shutil.rmtree(path, ignore_errors=True)


def _merged_text(rec, charset):
    chunks = []
    for name, data in rec.order:
        chunks.append(data)
    return b"".join(chunks).decode(charset or "utf-8", "replace")
