"""File opening helper shared by the File type and ``open_file``.

# spec: N-000816..N-000820 (file dash rule, lazy and atomic writes)
# spec: N-000926..N-000935 (FP-09 file parameters)
"""

from __future__ import annotations

import io
import os
import sys
import tempfile


class _LazyFile:
    """A write-mode file that opens on first I/O."""

    def __init__(self, filename, mode, encoding, errors, atomic):
        self._filename = filename
        self._mode = mode
        self._encoding = encoding
        self._errors = errors
        self._atomic = atomic
        self._f = None
        self._tmp = None
        self.name = filename
        self.closed = False

    def _ensure(self):
        if self._f is None:
            if self._atomic:
                d = os.path.dirname(os.path.abspath(self._filename))
                fd, self._tmp = tempfile.mkstemp(dir=d, prefix=".optlyn-", suffix=".tmp")
                os.close(fd)
                target = self._tmp
            else:
                target = self._filename
            if "b" in self._mode:
                self._f = open(target, self._mode)
            else:
                self._f = open(target, self._mode, encoding=self._encoding or "utf-8", errors=self._errors)
        return self._f

    def __getattr__(self, item):
        return getattr(self._ensure(), item)

    def write(self, data):
        return self._ensure().write(data)

    def close(self):
        if self.closed:
            return
        if self._f is not None:
            self._f.close()
            if self._atomic and self._tmp is not None:
                os.replace(self._tmp, self._filename)
                self._tmp = None
        self.closed = True


class _StdStream:
    """Wrapper for standard streams that are not closed when the block ends."""

    def __init__(self, stream):
        self._stream = stream
        self.name = getattr(stream, "name", "<std>")
        self.closed = False

    def __getattr__(self, item):
        return getattr(self._stream, item)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def close(self):
        # Standard streams stay open.
        pass

    def __iter__(self):
        return iter(self._stream)


def _std(mode, encoding, errors):
    binary = "b" in mode
    if "r" in mode:
        stream = sys.stdin.buffer if binary else sys.stdin
    else:
        stream = sys.stdout.buffer if binary else sys.stdout
    if not binary and encoding:
        stream = io.TextIOWrapper(stream.buffer if hasattr(stream, "buffer") else stream,
                                  encoding=encoding, errors=errors)
    return _StdStream(stream)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open ``filename``; ``-`` means standard input (read) or output (write)."""
    if hasattr(filename, "read") or hasattr(filename, "write"):
        return filename
    if filename == "-":
        return _std(mode, encoding, errors)
    if "r" in mode:
        if lazy:
            return _LazyFile(filename, mode, encoding, errors, atomic)
        if "b" in mode:
            return open(filename, mode)
        return open(filename, mode, encoding=encoding or "utf-8", errors=errors)
    # write modes
    if lazy:
        return _LazyFile(filename, mode, encoding, errors, atomic)
    f = _LazyFile(filename, mode, encoding, errors, atomic)
    f._ensure()
    return f
