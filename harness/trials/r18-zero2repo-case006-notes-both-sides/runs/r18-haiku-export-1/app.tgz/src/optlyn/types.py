"""Parameter types and conversion.

# spec: N-000797 N-000798 (ready-made and constructible types)
# spec: N-000330..N-000383 (FP-05 parameter types and conversion)
# spec: N-000936..N-000949 (interface contract section 5)
"""

from __future__ import annotations

import datetime as _dt
import enum
import math
import os
import pathlib
import uuid as _uuid

from .exceptions import BadParameter

TRUE_WORDS = ("1", "true", "t", "yes", "y", "on")
FALSE_WORDS = ("0", "false", "f", "no", "n", "off")

DEFAULT_DATETIME_FORMATS = (
    "%Y-%m-%d",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M:%S",
)


class ParamType:
    """Base class for parameter types. Subclasses set ``name`` and implement ``convert``."""

    name = "text"
    is_composite = False
    arity = 1

    def convert(self, value, param=None, ctx=None):
        return value

    def __call__(self, value, param=None, ctx=None):
        return self.convert(value, param, ctx)

    def get_metavar(self, param=None):
        return self.name.upper()

    def split_env_value(self, value: str) -> list[str]:
        return value.split()

    def shell_complete(self, ctx, param, incomplete):
        return []

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"


class _StringType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        return str(value)


class _IntType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            return int(str(value).strip(), 10)
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class _FloatType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        try:
            return float(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


class _BoolType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in TRUE_WORDS:
            return True
        if text in FALSE_WORDS:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class _UUIDType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value).strip())
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid UUID value.", param, ctx)


class _UnprocessedType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


STRING = _StringType()
INT = _IntType()
FLOAT = _FloatType()
BOOL = _BoolType()
UUID = _UUIDType()
UNPROCESSED = _UnprocessedType()


class Choice(ParamType):
    """A closed list of allowed values, or an Enum class.

    Matching is case-insensitive by default (the spec has a contradiction here,
    see NOTES.md); the original choice object is delivered.
    """

    name = "choice"

    def __init__(self, choices, case_sensitive: bool = False):
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.choices = list(choices)
            self._names = {m.name: m for m in choices}
        else:
            self.choices = list(choices)
            self._names = None
        self.case_sensitive = case_sensitive

    def _tokens(self):
        if self._names is not None:
            return [(m.name, m) for m in self.choices]
        return [(str(c), c) for c in self.choices]

    def get_metavar(self, param=None):
        return "[" + "|".join(t for t, _ in self._tokens()) + "]"

    def convert(self, value, param=None, ctx=None):
        if not isinstance(value, str):
            for c in self.choices:
                if c == value:
                    return c
        norm = value
        for token, original in self._tokens():
            if token == norm:
                return original
        if not self.case_sensitive:
            folded = str(norm).casefold()
            first = None
            for token, original in self._tokens():
                if token.casefold() == folded:
                    if first is None:
                        first = original
            if first is not None:
                return first
        choices = ", ".join(repr(t) for t, _ in self._tokens())
        self.fail(f"{value!r} is not one of {choices}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        return [t for t, _ in self._tokens() if t.startswith(incomplete)]


class DateTime(ParamType):
    """Parses into a datetime. Author formats replace the defaults."""

    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(DEFAULT_DATETIME_FORMATS)

    def get_metavar(self, param=None):
        return "[" + "|".join(self.formats) + "]"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(str(value).strip(), fmt)
            except ValueError:
                continue
        self.fail(f"{value!r} does not match the formats {', '.join(self.formats)}.", param, ctx)


class IntRange(_IntType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        v = super().convert(value, param, ctx)
        lo, hi = self.min, self.max
        if lo is not None:
            if v < lo or (self.min_open and v == lo):
                if self.clamp:
                    return (lo + 1) if self.min_open else lo
                self._range_fail(v, param, ctx)
        if hi is not None:
            if v > hi or (self.max_open and v == hi):
                if self.clamp:
                    return (hi - 1) if self.max_open else hi
                self._range_fail(v, param, ctx)
        return v

    def _range_fail(self, v, param, ctx):
        self.fail(f"{v} is not in the valid range {self._desc()}.", param, ctx)

    def _desc(self):
        lo = "-inf" if self.min is None else (("(" if self.min_open else "[") + str(self.min))
        hi = "inf" if self.max is None else (str(self.max) + (")" if self.max_open else "]"))
        return f"{lo}, {hi}"


class FloatRange(_FloatType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min_open or max_open):
            # Spec contradiction CF-000100/CF-000107/CF-000016: this build
            # refuses clamp with an open bound at declaration time.
            raise ValueError("FloatRange: clamp is not allowed when a bound is open.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        v = super().convert(value, param, ctx)
        if self.min is not None and (v < self.min or (self.min_open and v == self.min)):
            if self.clamp:
                return float(self.min)
            self.fail(f"{v} is not in the valid range {self._desc()}.", param, ctx)
        if self.max is not None and (v > self.max or (self.max_open and v == self.max)):
            if self.clamp:
                return float(self.max)
            self.fail(f"{v} is not in the valid range {self._desc()}.", param, ctx)
        return v

    def _desc(self):
        lo = "-inf" if self.min is None else (("(" if self.min_open else "[") + str(self.min))
        hi = "inf" if self.max is None else (str(self.max) + (")" if self.max_open else "]"))
        return f"{lo}, {hi}"


class Tuple(ParamType):
    """Fixed-length product of inner types."""

    name = "tuple"
    is_composite = True

    def __init__(self, types):
        self.types = [_resolve_type(t) for t in types]
        self.arity = len(self.types)

    def get_metavar(self, param=None):
        return " ".join(t.get_metavar(param) for t in self.types)

    def convert(self, value, param=None, ctx=None):
        if not isinstance(value, (list, tuple)):
            self.fail(f"{value!r} is not a sequence of {self.arity} values.", param, ctx)
        if len(value) != self.arity:
            self.fail(f"Takes {self.arity} values but {len(value)} were given.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))


class File(ParamType):
    """Opens a file; ``-`` means stdin for reading and stdout for writing."""

    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"Unsupported File mode {mode!r}")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def split_env_value(self, value):
        return value.split(os.pathsep)

    def convert(self, value, param=None, ctx=None):
        from .fileio import open_file

        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        lazy = self.lazy
        if lazy is None:
            lazy = self.mode in ("w", "wb")
        try:
            f = open_file(value, self.mode, self.encoding, self.errors, lazy=lazy, atomic=self.atomic)
        except OSError as e:
            from .exceptions import BadParameter as _BP

            raise _BP(f"'{value}': {e.strerror or e}", ctx=ctx, param=param)
        if ctx is not None:
            ctx.call_on_close(f.close)
        return f


class Path(ParamType):
    """Validates a filesystem path and returns it (not an open file)."""

    name = "path"

    def __init__(self, exists=False, file_okay=True, dir_okay=True, writable=False,
                 readable=True, resolve_path=False, allow_dash=False, path_type=None,
                 executable=False):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def split_env_value(self, value):
        return value.split(os.pathsep)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, pathlib.PurePath):
            value = str(value)
        if self.allow_dash and value == "-":
            return self._out("-")
        p = value
        if self.resolve_path:
            p = os.path.realpath(os.path.expanduser(p))
            # Spec contradiction CF-000160: this build expands a leading "~" when resolving.
        if not os.path.exists(p):
            if self.exists:
                self.fail(f"{value!r} does not exist.", param, ctx)
            return self._out(p)
        if not self.file_okay and not os.path.isdir(p):
            self.fail(f"{value!r} is a file.", param, ctx)
        if not self.dir_okay and os.path.isdir(p):
            self.fail(f"{value!r} is a directory.", param, ctx)
        if self.readable and not os.access(p, os.R_OK):
            self.fail(f"{value!r} is not readable.", param, ctx)
        if self.writable and not os.access(p, os.W_OK):
            self.fail(f"{value!r} is not writable.", param, ctx)
        if self.executable and not os.access(p, os.X_OK):
            self.fail(f"{value!r} is not executable.", param, ctx)
        return self._out(p)

    def _out(self, p):
        if self.path_type is pathlib.Path:
            return pathlib.Path(p)
        return p


def _resolve_type(t):
    if t is None:
        return STRING
    if isinstance(t, ParamType):
        return t
    if isinstance(t, type) and issubclass(t, ParamType):
        return t()
    if t is str:
        return STRING
    if t is int:
        return INT
    if t is float:
        return FLOAT
    if t is bool:
        return BOOL
    if callable(t):
        return FuncType(t)
    raise TypeError(f"Unsupported type {t!r}")


class FuncType(ParamType):
    """Wraps a conversion function f(token) -> value that refuses with ValueError."""

    name = "text"

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text")

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except ValueError as e:
            self.fail(str(e) or f"{value!r} is not valid.", param, ctx)


def infer_type(default):
    """Infer a parameter type from a default value (FP-05)."""
    if default is None or callable(default):
        return None
    if isinstance(default, bool):
        return BOOL
    if isinstance(default, int):
        return INT
    if isinstance(default, float):
        return FLOAT
    if isinstance(default, (list, tuple)) and default:
        inner = infer_type(default[0])
        return inner or STRING
    return None


def resolve_type(t, default=None):
    """Return a ParamType for a declared type, falling back to the default's type."""
    if t is None:
        return infer_type(default) or STRING
    return _resolve_type(t)
