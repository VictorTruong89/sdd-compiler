"""Thread-local stack of current invocation contexts.

# spec: N-000954..N-000960 (get_current_context, with ctx: makes it current)
# spec: N-000972 (context is per-thread; not a thread-safe store)
"""

from __future__ import annotations

import threading

_local = threading.local()


def _stack():
    s = getattr(_local, "stack", None)
    if s is None:
        s = []
        _local.stack = s
    return s


def push(ctx):
    _stack().append(ctx)


def pop(ctx):
    s = _stack()
    if s and s[-1] is ctx:
        s.pop()
    elif ctx in s:
        s.remove(ctx)


def current():
    s = _stack()
    return s[-1] if s else None


def get_current_context(silent: bool = False):
    ctx = current()
    if ctx is None and not silent:
        raise RuntimeError("There is no active Optlyn context.")
    return ctx
