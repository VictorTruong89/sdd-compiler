"""Regression tests for the Optlyn package (run with PYTHONPATH=src).

Each test names the spec area it exercises in its docstring; see NOTES.md for
the id-level accounting.
"""

import optlyn
from optlyn import Choice, argument, command, confirmation_option, group, option, password_option
from optlyn.testing import CliRunner


def _runner():
    return CliRunner()


def test_option_parsing_short_stack_and_long_value():
    """FP-03: short-option stacking, --name value, --name=value."""

    @command()
    @option("-v", "--verbose", is_flag=True)
    @option("-c", "--count", type=int, default=1)
    def cmd(verbose, count):
        optlyn.echo(f"{verbose} {count}")

    r = _runner().invoke(cmd, ["-v", "--count=4"])
    assert r.exit_code == 0 and r.output == "True 4\n"
    r = _runner().invoke(cmd, ["-vc", "2"])
    assert r.exit_code == 0 and r.output == "True 2\n"


def test_unknown_option_is_usage_error():
    """FP-13: unknown option exits with status 2 and runs no callback."""
    ran = []

    @command()
    @option("--a")
    def cmd(a):
        ran.append(a)

    r = _runner().invoke(cmd, ["--nope"])
    assert r.exit_code == 2
    assert ran == []
    assert "No such option" in r.stderr


def test_bad_conversion_names_parameter():
    """FP-05: conversion failure is a usage error naming the parameter."""

    @command()
    @option("--n", type=int)
    def cmd(n):
        pass

    r = _runner().invoke(cmd, ["--n", "x"])
    assert r.exit_code == 2
    assert "--n" in r.stderr


def test_help_exits_zero_and_skips_callback():
    """FP-02: intentional help exits 0 and does not run the callback."""
    ran = []

    @command()
    @option("--a")
    def cmd(a):
        """Do a thing."""
        ran.append(1)

    r = _runner().invoke(cmd, ["--help"])
    assert r.exit_code == 0
    assert ran == []
    assert "Do a thing." in r.output and "Usage:" in r.output


def test_group_missing_command_is_usage_error_with_help():
    """FP-06/FP-02: a group with no subcommand shows help and exits 2."""

    @group()
    def cli():
        pass

    @cli.command()
    def sub():
        pass

    r = _runner().invoke(cli, [])
    assert r.exit_code == 2
    assert "Usage:" in r.stderr


def test_nested_groups_run_outside_in():
    """FP-06: nested groups run from the outside in, then the leaf."""
    order = []

    @group()
    def outer():
        order.append("outer")

    @outer.group()
    def mid():
        order.append("mid")

    @mid.command()
    def leaf():
        order.append("leaf")

    r = _runner().invoke(outer, ["mid", "leaf"])
    assert r.exit_code == 0
    assert order == ["outer", "mid", "leaf"]


def test_chain_group_result_callback():
    """FP-10: chaining runs children in order and passes results to the result callback."""

    @group(chain=True)
    def pipe():
        pass

    @pipe.command()
    @argument("n", type=int)
    def dbl(n):
        return n * 2

    @pipe.command()
    @argument("n", type=int)
    def inc(n):
        return n + 1

    @pipe.result_callback()
    def done(results):
        optlyn.echo(f"results={results}")

    r = _runner().invoke(pipe, ["dbl", "3", "inc", "4"])
    assert r.exit_code == 0
    assert r.output == "results=[6, 5]\n"


def test_choice_case_insensitive_returns_original():
    """FP-05: Choice matches case-insensitively and delivers the original choice."""

    @command()
    @option("--level", type=Choice(["low", "high"]), default="low")
    def cmd(level):
        optlyn.echo(level)

    r = _runner().invoke(cmd, ["--level", "HIGH"])
    assert r.exit_code == 0 and r.output == "high\n"


def test_env_prefix_and_command_line_precedence():
    """FP-07/FP-03: auto env prefix fills options; command line beats environment."""

    @group(context_settings={"auto_envvar_prefix": "APP"})
    def cli():
        pass

    @cli.command()
    @option("--port", type=int, default=80)
    def serve(port):
        optlyn.echo(port)

    r = _runner().invoke(cli, ["serve"], env={"APP_SERVE_PORT": "9000"})
    assert r.output == "9000\n"
    r = _runner().invoke(cli, ["serve", "--port", "1"], env={"APP_SERVE_PORT": "9000"})
    assert r.output == "1\n"


def test_default_map_and_value_source():
    """FP-07: default map applies; get_parameter_source reports the source."""

    @command()
    @option("--x")
    def cmd(x):
        ctx = optlyn.get_current_context()
        optlyn.echo(f"{x} {ctx.get_parameter_source('x').value}")

    r = _runner().invoke(cmd, [], default_map={"x": "dmv"})
    assert r.output == "dmv default_map\n"


def test_confirmation_option_declines_and_aborts():
    """FP-08: a declined confirmation aborts with status 1 and runs no callback."""
    ran = []

    @command()
    @confirmation_option(prompt="Sure?")
    def cmd():
        ran.append(1)

    r = _runner().invoke(cmd, [], input="n\n")
    assert r.exit_code == 1
    assert ran == []
    r = _runner().invoke(cmd, ["--yes"])
    assert r.exit_code == 0 and ran == [1]


def test_password_option_confirms_and_delivers():
    """FP-08: the password option prompts twice and delivers the value."""

    @command()
    @password_option()
    def cmd(password):
        optlyn.echo("pw=" + password)

    r = _runner().invoke(cmd, [], input="secret\nsecret\n")
    assert r.exit_code == 0
    assert r.output.endswith("pw=secret\n")


def test_version_option_is_eager():
    """FP-02: version prints identity and exits without the callback."""
    ran = []

    @command()
    @optlyn.version_option("1.2.3", prog_name="x")
    @option("--req", required=True)
    def cmd(req):
        ran.append(1)

    r = _runner().invoke(cmd, ["--version"])
    assert r.exit_code == 0
    assert "1.2.3" in r.output
    assert ran == []


def test_deprecated_command_warns_and_runs():
    """FP-01: a deprecated command still runs and warns on stderr."""

    @command(deprecated="use other")
    def cmd():
        optlyn.echo("ran")

    r = _runner().invoke(cmd, [])
    assert r.exit_code == 0
    assert "ran" in r.output
    assert "deprecated" in r.stderr and "use other" in r.stderr


def test_file_write_dash_and_lazy(tmp_path):
    """FP-09: file parameters open writes inside the sandbox; '-' is stdout."""
    from optlyn import File

    @command()
    @argument("out", type=File("w"))
    def cmd(out):
        out.write("hello")

    runner = _runner()
    with runner.isolated_filesystem() as d:
        r = runner.invoke(cmd, ["result.txt"])
        assert r.exit_code == 0
        import os

        with open(os.path.join(d, "result.txt")) as f:
            assert f.read() == "hello"


def test_echo_strips_styles_when_not_tty():
    """FP-11: echo strips ANSI styles when the stream is not a terminal."""

    @command()
    def cmd():
        optlyn.echo(optlyn.style("plain", fg="red"))

    r = _runner().invoke(cmd, [])
    assert r.output == "plain\n"
    assert optlyn.unstyle(optlyn.style("x", bold=True)) == "x"


def test_pass_context_and_obj():
    """FP-07: pass_context and pass_obj deliver context and the author object."""

    @group()
    @option("--n", type=int, default=1)
    @optlyn.pass_context
    def top(ctx, n):
        ctx.obj = {"n": n}

    @top.command()
    @optlyn.pass_obj
    def show(obj):
        optlyn.echo(obj["n"])

    r = _runner().invoke(top, ["--n", "7", "show"])
    assert r.output == "7\n"


def test_runner_catches_exception():
    """FP-14: an exception raised by the callback is inspectable on the result."""

    @command()
    def cmd():
        raise RuntimeError("boom")

    r = _runner().invoke(cmd, [])
    assert r.exit_code == 1
    assert isinstance(r.exception, RuntimeError)


def test_completion_bash_suggests_subcommands(monkeypatch):
    """FP-12: complete mode lists subcommand names for a group."""
    from optlyn import completion

    @group()
    def cli():
        pass

    @cli.command()
    def alpha():
        """Alpha."""

    @cli.command()
    def beta():
        pass

    monkeypatch.setenv("COMP_WORDS", "cli ")
    monkeypatch.setenv("COMP_CWORD", "1")
    out = completion._suggestions(cli, "cli", "bash")
    assert "alpha" in out and "beta" in out
