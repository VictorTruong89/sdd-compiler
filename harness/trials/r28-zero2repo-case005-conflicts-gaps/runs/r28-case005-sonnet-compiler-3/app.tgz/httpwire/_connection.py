import re

from ._errors import LocalProtocolError, RemoteProtocolError
from ._events import (Request, InformationalResponse, Response, Data,
                      EndOfMessage, ConnectionClosed, Headers,
                      normalize_and_validate, _token)
from ._states import *  # noqa
from ._states import _Sentinel

DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 16 * 1024  # see NOTES.md (CF-000048)
MAX_CHUNK_DIGITS = 32

_SWITCH_UPGRADE = _Sentinel("_SWITCH_UPGRADE")
_SWITCH_CONNECT = _Sentinel("_SWITCH_CONNECT")

_request_line_re = re.compile(
    rb"(" + _token + rb") ([\x21-\x7e]+) HTTP/(1\.[01])\Z")
_status_line_re = re.compile(rb"HTTP/(1\.[01]) ([0-9]{3}) ([^\r\n]*)\Z")
_header_line_re = re.compile(rb"(" + _token + rb"):[ \t]*(.*?)[ \t]*\Z", re.S)
_chunk_re = re.compile(
    rb"([0-9a-fA-F]{1,%d})[ \t]*(?:;[^\r\n]*)?\Z" % MAX_CHUNK_DIGITS)


def _comma_header(headers, name):
    out = []
    for n, v in headers:
        if n == name:
            for p in v.split(b","):
                p = p.strip(b" \t").lower()
                if p:
                    out.append(p)
    return out


def _keep_alive(event):
    if b"close" in _comma_header(event.headers, b"connection"):
        return False
    if event.http_version < b"1.1":
        return False
    return True


# ---- state machine -------------------------------------------------------

_TRANSITIONS = {
    CLIENT: {
        IDLE: {Request: SEND_BODY, ConnectionClosed: CLOSED},
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
        CLOSED: {ConnectionClosed: CLOSED},
        MIGHT_SWITCH_PROTOCOL: {},
        SWITCHED_PROTOCOL: {},
        ERROR: {},
    },
    SERVER: {
        IDLE: {ConnectionClosed: CLOSED, Response: SEND_BODY,
               (Request, CLIENT): SEND_RESPONSE},
        SEND_RESPONSE: {InformationalResponse: SEND_RESPONSE,
                        Response: SEND_BODY,
                        (Response, _SWITCH_CONNECT): SWITCHED_PROTOCOL,
                        (InformationalResponse, _SWITCH_UPGRADE):
                            SWITCHED_PROTOCOL},
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
        CLOSED: {ConnectionClosed: CLOSED},
        MIGHT_SWITCH_PROTOCOL: {},
        SWITCHED_PROTOCOL: {},
        ERROR: {},
    },
}


class _ConnectionState(object):
    def __init__(self):
        self.states = {CLIENT: IDLE, SERVER: IDLE}
        self.keep_alive = True
        self.pending = set()

    def process_event(self, role, etype, server_switch_event=None):
        key = etype
        if server_switch_event is not None:
            if server_switch_event not in self.pending:
                raise LocalProtocolError(
                    "Received server %s event without a pending proposal"
                    % server_switch_event)
            key = (etype, server_switch_event)
        if server_switch_event is None and etype is Response:
            self.pending.clear()
        self._fire(role, key)
        if etype is Request:
            self._fire(SERVER, (Request, CLIENT))
        self._fire_state_triggered()

    def _fire(self, role, key):
        st = self.states[role]
        try:
            new = _TRANSITIONS[role][st][key]
        except KeyError:
            name = key[0].__name__ if isinstance(key, tuple) else key.__name__
            raise LocalProtocolError(
                "can't handle event type %s when role=%r and state=%r"
                % (name, role, st))
        self.states[role] = new

    def _fire_state_triggered(self):
        s = self.states
        while True:
            start = dict(s)
            if self.pending and s[CLIENT] is DONE:
                s[CLIENT] = MIGHT_SWITCH_PROTOCOL
            if not self.pending and s[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                s[CLIENT] = DONE
            if not self.keep_alive:
                for r in (CLIENT, SERVER):
                    if s[r] is DONE:
                        s[r] = MUST_CLOSE
            if (s[CLIENT] is MIGHT_SWITCH_PROTOCOL
                    and s[SERVER] is SWITCHED_PROTOCOL):
                s[CLIENT] = SWITCHED_PROTOCOL
            for r, o in ((CLIENT, SERVER), (SERVER, CLIENT)):
                if s[r] is CLOSED and s[o] in (DONE, IDLE):
                    s[o] = MUST_CLOSE
                if s[r] is ERROR and s[o] is DONE:
                    s[o] = MUST_CLOSE
            if s == start:
                break

    def process_error(self, role):
        self.states[role] = ERROR
        self._fire_state_triggered()

    def disable_keep_alive(self):
        self.keep_alive = False
        self._fire_state_triggered()

    def start_next_cycle(self):
        if self.states != {CLIENT: DONE, SERVER: DONE}:
            raise LocalProtocolError(
                "not in a reusable state: %r" % (self.states,))
        assert not self.pending
        self.states = {CLIENT: IDLE, SERVER: IDLE}


# ---- framing -------------------------------------------------------------

def _body_framing(request_method, event):
    if type(event) is Response:
        if (event.status_code in (204, 304) or request_method == b"HEAD"
                or (request_method == b"CONNECT"
                    and 200 <= event.status_code < 300)):
            return ("content-length", 0)
    # TE wins over Content-Length (see NOTES.md)
    if _comma_header(event.headers, b"transfer-encoding"):
        return ("chunked", None)
    cl = _comma_header(event.headers, b"content-length")
    if cl:
        return ("content-length", int(cl[0]))
    if type(event) is Request:
        return ("content-length", 0)
    return ("http/1.0", None)


def _extract_lines(buf):
    """Return list of lines of a complete header block, or None."""
    if buf[:2] == b"\r\n":
        del buf[:2]
        return []
    if buf[:1] == b"\n":
        del buf[:1]
        return []
    m = re.search(rb"\n\r?\n", bytes(buf))
    if m is None:
        return None
    block = bytes(buf[:m.start()])
    del buf[:m.end()]
    return [l[:-1] if l.endswith(b"\r") else l for l in block.split(b"\n")]


def _parse_headers(lines):
    out = []
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            if not out:
                raise LocalProtocolError("continuation line at start of headers")
            n, v = out[-1]
            out[-1] = (n, v + b" " + line.lstrip(b" \t"))
            continue
        m = _header_line_re.match(line)
        if not m:
            raise LocalProtocolError("illegal header line %r" % line)
        out.append((m.group(1), m.group(2)))
    return out


class _CLReader(object):
    def __init__(self, n):
        self.remaining = n

    def __call__(self, buf):
        if self.remaining == 0:
            return EndOfMessage()
        if not buf:
            return None
        take = min(self.remaining, len(buf))
        data = bytes(buf[:take])
        del buf[:take]
        self.remaining -= take
        return Data(data)

    def eof(self):
        raise LocalProtocolError(
            "peer closed connection without sending complete message body "
            "(%d bytes missing)" % self.remaining)


class _ChunkedReader(object):
    def __init__(self):
        self.in_chunk = 0
        self.discard = 0
        self.trailer = False
        self.start_pending = False

    def __call__(self, buf):
        if self.trailer:
            lines = _extract_lines(buf)
            if lines is None:
                return None
            return EndOfMessage(headers=_parse_headers(lines))
        if self.discard:
            n = min(len(buf), 2)
            if bytes(buf[:n]) != b"\r\n"[:n]:
                raise LocalProtocolError("chunk not terminated by CRLF")
            if len(buf) < 2:
                return None
            del buf[:2]
            self.discard = 0
        if self.in_chunk == 0:
            idx = bytes(buf).find(b"\r\n")
            if idx < 0:
                return None
            m = _chunk_re.match(bytes(buf[:idx]))
            if not m:
                raise LocalProtocolError("illegal chunk header")
            del buf[:idx + 2]
            size = int(m.group(1), 16)
            if size == 0:
                self.trailer = True
                return self(buf)
            self.in_chunk = size
            self.start_pending = True
        if not buf:
            return None
        take = min(self.in_chunk, len(buf))
        data = bytes(buf[:take])
        del buf[:take]
        self.in_chunk -= take
        start = self.start_pending
        self.start_pending = False
        end = self.in_chunk == 0
        if end:
            self.discard = 2
        return Data(data, chunk_start=start, chunk_end=end)

    def eof(self):
        raise LocalProtocolError(
            "peer closed connection without sending complete message body "
            "(incomplete chunked read)")


class _H10Reader(object):
    def __call__(self, buf):
        if not buf:
            return None
        data = bytes(buf)
        del buf[:]
        return Data(data)

    def eof(self):
        return EndOfMessage()


def _hdrs_bytes(headers, skip_host_first=False):
    items = headers.raw_items()
    out = []
    if skip_host_first:
        hosts = [i for i in items if i[0].lower() == b"host"]
        items = hosts + [i for i in items if i[0].lower() != b"host"]
    for n, v in items:
        out.append(n + b": " + v + b"\r\n")
    return b"".join(out)


class _CLWriter(object):
    def __init__(self, n):
        self.remaining = n

    def data(self, d, w):
        self.remaining -= len(d)
        if self.remaining < 0:
            raise LocalProtocolError("Too much data for declared Content-Length")
        w(d)

    def eom(self, headers, w):
        if self.remaining:
            raise LocalProtocolError(
                "Too little data for declared Content-Length")
        if len(headers):
            raise LocalProtocolError("Content-Length framing forbids trailers")


class _ChunkedWriter(object):
    def data(self, d, w):
        n = len(d)
        if n == 0:
            return
        w(b"%x\r\n" % n)
        w(d)
        w(b"\r\n")

    def eom(self, headers, w):
        w(b"0\r\n" + _hdrs_bytes(headers) + b"\r\n")


class _H10Writer(object):
    def data(self, d, w):
        w(d)

    def eom(self, headers, w):
        if len(headers):
            raise LocalProtocolError("HTTP/1.0 framing forbids trailers")


def _make_reader(request_method, event):
    kind, n = _body_framing(request_method, event)
    if kind == "content-length":
        return _CLReader(n)
    if kind == "chunked":
        return _ChunkedReader()
    return _H10Reader()


def _make_writer(request_method, event):
    kind, n = _body_framing(request_method, event)
    if kind == "content-length":
        return _CLWriter(n)
    if kind == "chunked":
        return _ChunkedWriter()
    return _H10Writer()


class Connection(object):
    def __init__(self, role, max_incomplete_event_size=
                 DEFAULT_MAX_INCOMPLETE_EVENT_SIZE):
        if role is not CLIENT and role is not SERVER:
            raise ValueError("role must be CLIENT or SERVER")
        self.our_role = role
        self.their_role = SERVER if role is CLIENT else CLIENT
        self._cstate = _ConnectionState()
        self._max = max_incomplete_event_size
        self._buf = bytearray()
        self._closed = False
        self._request_method = None
        self.their_http_version = None
        self.client_is_waiting_for_100_continue = False
        self._reader = None   # body reader for their side
        self._writer = None   # body writer for our side

    # -- queries --
    @property
    def states(self):
        return dict(self._cstate.states)

    @property
    def our_state(self):
        return self._cstate.states[self.our_role]

    @property
    def their_state(self):
        return self._cstate.states[self.their_role]

    @property
    def they_are_waiting_for_100_continue(self):
        return (self.their_role is CLIENT
                and self.client_is_waiting_for_100_continue)

    @property
    def trailing_data(self):
        return (bytes(self._buf), self._closed)

    # -- core --
    def _process_event(self, role, event):
        old = dict(self._cstate.states)
        et = type(event)
        if role is CLIENT and et is Request:
            if event.method == b"CONNECT":
                self._cstate.pending.add(_SWITCH_CONNECT)
            if _comma_header(event.headers, b"upgrade"):
                self._cstate.pending.add(_SWITCH_UPGRADE)
        sw = None
        if role is SERVER:
            if et is InformationalResponse and event.status_code == 101:
                sw = _SWITCH_UPGRADE
            elif (et is Response and _SWITCH_CONNECT in self._cstate.pending
                  and 200 <= event.status_code < 300):
                sw = _SWITCH_CONNECT
        try:
            self._cstate.process_event(role, et, sw)
        except LocalProtocolError:
            if role is CLIENT and et is Request:
                pass
            raise
        if et is Request:
            self._request_method = event.method
        if role is self.their_role and et in (Request, Response,
                                              InformationalResponse):
            self.their_http_version = event.http_version
        if et in (Request, Response) and not _keep_alive(event):
            self._cstate.disable_keep_alive()
        if et is Request:
            if (event.http_version == b"1.1"
                    and b"100-continue" in _comma_header(event.headers,
                                                         b"expect")):
                self.client_is_waiting_for_100_continue = True
        if et in (InformationalResponse, Response):
            self.client_is_waiting_for_100_continue = False
        if role is CLIENT and et in (Data, EndOfMessage):
            self.client_is_waiting_for_100_continue = False
        new = self._cstate.states
        for r in (CLIENT, SERVER):
            if new[r] != old[r] and new[r] is SEND_BODY:
                if r is self.our_role:
                    self._writer = _make_writer(self._request_method, event)
                else:
                    self._reader = _make_reader(self._request_method, event)

    def _process_error(self, role):
        self._cstate.process_error(role)

    # -- send --
    def _clean_response(self, response):
        framing, _ = _body_framing(self._request_method, response)
        items = response.headers.raw_items()
        need_close = False
        if framing in ("chunked", "http/1.0"):
            items = [(n, v) for n, v in items
                     if n.lower() not in (b"content-length",
                                          b"transfer-encoding")]
            if (self.their_http_version is None
                    or self.their_http_version < b"1.1"):
                need_close = True
            else:
                items.append((b"transfer-encoding", b"chunked"))
        if (not self._cstate.keep_alive
                or self.their_state is ERROR):
            need_close = True
        if need_close:
            conn = set(_comma_header(Headers(
                [(n, n.lower(), v) for n, v in items]), b"connection"))
            conn.discard(b"keep-alive")
            conn.add(b"close")
            items = [(n, v) for n, v in items if n.lower() != b"connection"]
            items.append((b"connection", b",".join(sorted(conn))))
        return Response(status_code=response.status_code, headers=items,
                        http_version=response.http_version,
                        reason=response.reason)

    def send(self, event):
        parts = self.send_with_data_passthrough(event)
        if parts is None:
            return None
        return b"".join(parts)

    def send_with_data_passthrough(self, event):
        if self.our_state is ERROR:
            raise LocalProtocolError("Can't send data when our state is ERROR")
        try:
            if type(event) is Response:
                event = self._clean_response(event)
            pieces = []
            w = pieces.append
            et = type(event)
            if et not in (Request, InformationalResponse, Response, Data,
                          EndOfMessage, ConnectionClosed):
                raise LocalProtocolError("not an event: %r" % (event,))
            writer = self._writer
            self._process_event(self.our_role, event)
            if et is ConnectionClosed:
                return None
            if et is Request:
                if event.http_version != b"1.1":
                    raise LocalProtocolError("I only send HTTP/1.1")
                w(b"%s %s HTTP/1.1\r\n" % (event.method, event.target))
                w(_hdrs_bytes(event.headers, True) + b"\r\n")
            elif et in (InformationalResponse, Response):
                if event.http_version != b"1.1":
                    raise LocalProtocolError("I only send HTTP/1.1")
                w(b"HTTP/1.1 %d %s\r\n" % (event.status_code, event.reason))
                w(_hdrs_bytes(event.headers) + b"\r\n")
            else:
                writer = self._writer
                if et is Data:
                    writer.data(event.data, w)
                else:
                    writer.eom(event.headers, w)
            return pieces
        except BaseException:
            self._process_error(self.our_role)
            raise

    def send_failed(self):
        self._process_error(self.our_role)

    def start_next_cycle(self):
        self._cstate.start_next_cycle()
        self._request_method = None
        self.their_http_version = None
        self.client_is_waiting_for_100_continue = False
        self._reader = None
        self._writer = None

    # -- receive --
    def receive_data(self, data):
        if data:
            if self._closed:
                raise RuntimeError("received close, then received more data?")
            self._buf += data
        else:
            self._closed = True

    def _read_request(self):
        buf = self._buf
        if buf and buf[0] < 0x21:
            raise LocalProtocolError("illegal request line")
        lines = _extract_lines(buf)
        if lines is None:
            return None
        if not lines:
            raise LocalProtocolError("empty request")
        m = _request_line_re.match(lines[0])
        if not m:
            raise LocalProtocolError("illegal request line")
        return Request(method=m.group(1), target=m.group(2),
                       headers=_parse_headers(lines[1:]),
                       http_version=m.group(3))

    def _read_response(self):
        buf = self._buf
        if buf and buf[0] < 0x21:
            raise LocalProtocolError("illegal status line")
        lines = _extract_lines(buf)
        if lines is None:
            return None
        if not lines:
            raise LocalProtocolError("empty response")
        m = _status_line_re.match(lines[0])
        if not m:
            raise LocalProtocolError("illegal status line")
        code = int(m.group(2))
        cls = InformationalResponse if code < 200 else Response
        return cls(status_code=code, headers=_parse_headers(lines[1:]),
                   http_version=m.group(1), reason=m.group(3))

    def _extract(self):
        st = self.their_state
        if st is DONE and self._buf:
            return PAUSED
        if st is MIGHT_SWITCH_PROTOCOL or st is SWITCHED_PROTOCOL:
            return PAUSED
        reader_eof = None
        if st is SEND_BODY:
            ev = self._reader(self._buf)
            reader_eof = self._reader.eof
        elif st in (DONE, MUST_CLOSE, CLOSED):
            if self._buf:
                raise LocalProtocolError("Got data when expecting EOF")
            ev = None
        elif self.their_role is CLIENT:  # IDLE
            ev = self._read_request()
        else:  # SERVER IDLE / SEND_RESPONSE
            ev = self._read_response()
        if ev is None:
            if not self._buf and self._closed:
                ev = reader_eof() if reader_eof else ConnectionClosed()
            if ev is None:
                ev = NEED_DATA
        return ev

    def next_event(self):
        if self.their_state is ERROR:
            raise RemoteProtocolError(
                "Can't receive data when peer state is ERROR")
        try:
            ev = self._extract()
            if ev is not NEED_DATA and ev is not PAUSED:
                self._process_event(self.their_role, ev)
            if ev is NEED_DATA:
                if len(self._buf) > self._max:
                    raise RemoteProtocolError("Receive buffer too long", 431)
                if self._closed:
                    raise RemoteProtocolError(
                        "peer unexpectedly closed connection")
            return ev
        except BaseException as exc:
            self._process_error(self.their_role)
            if isinstance(exc, LocalProtocolError):
                raise RemoteProtocolError(str(exc), exc.error_status_hint)
            raise
