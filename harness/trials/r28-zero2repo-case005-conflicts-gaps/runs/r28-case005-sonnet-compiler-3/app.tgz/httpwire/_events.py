import re

from ._errors import LocalProtocolError

MAX_CL_DIGITS = 18  # spec: implementer's choice 18..32

_token = rb"[-!#$%&'*+.^_`|~0-9A-Za-z]+"
_token_re = re.compile(_token + rb"\Z")
_target_re = re.compile(rb"[\x21-\x7e]+\Z")
_value_re = re.compile(
    rb"(?:[^\x00\r\n\x0b\x0c \t](?:[^\x00\r\n\x0b\x0c]*[^\x00\r\n\x0b\x0c \t])?)?\Z")
_digits_re = re.compile(rb"[0-9]+\Z")
_version_re = re.compile(rb"[0-9]\.[0-9]\Z")


def _bytesify(x, what="value"):
    if type(x) is bytes:
        return x
    if isinstance(x, str):
        try:
            return x.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("non-ASCII text in %s" % what)
    if isinstance(x, (bytes, bytearray, memoryview)):
        return bytes(x)
    try:
        return bytes(memoryview(x))
    except TypeError:
        raise LocalProtocolError("%s must be str or bytes-like" % what)


class Headers(object):
    """Sequence of (lowercase name, value); raw_items() keeps caller spelling."""

    __slots__ = ("_full",)

    def __init__(self, full):
        self._full = list(full)  # (raw_name, lower_name, value)

    def __iter__(self):
        for _raw, low, val in self._full:
            yield (low, val)

    def __len__(self):
        return len(self._full)

    def __getitem__(self, i):
        if isinstance(i, slice):
            return [(l, v) for _r, l, v in self._full[i]]
        _r, l, v = self._full[i]
        return (l, v)

    def __eq__(self, other):
        if isinstance(other, Headers):
            return list(self) == list(other)
        try:
            return list(self) == [tuple(x) for x in other]
        except TypeError:
            return NotImplemented

    __hash__ = None

    def __repr__(self):
        return repr(list(self))

    def raw_items(self):
        return [(r, v) for r, _l, v in self._full]


def normalize_and_validate(headers):
    if headers is None:
        headers = []
    if hasattr(headers, "items") and not isinstance(headers, Headers):
        headers = headers.items()
    if isinstance(headers, Headers):
        pairs = headers.raw_items()
    else:
        pairs = headers
    full = []
    try:
        pairs = list(pairs)
    except TypeError:
        raise LocalProtocolError("headers must be a sequence of pairs")
    for item in pairs:
        try:
            name, value = item
        except (TypeError, ValueError):
            raise LocalProtocolError("header must be a (name, value) pair")
        name = _bytesify(name, "header name")
        value = _bytesify(value, "header value")
        if not _token_re.match(name):
            raise LocalProtocolError("illegal header name %r" % name)
        if not _value_re.match(value):
            raise LocalProtocolError("illegal header value %r" % value)
        low = name.lower()
        full.append([name, low, value])

    # Content-Length
    out = []
    seen_cl = None
    seen_te = 0
    for raw, low, value in full:
        if low == b"content-length":
            vals = [p.strip(b" \t") for p in value.split(b",")]
            for p in vals:
                if not _digits_re.match(p) or len(p) > MAX_CL_DIGITS:
                    raise LocalProtocolError("bad Content-Length")
            if len(set(vals)) != 1:
                raise LocalProtocolError("conflicting Content-Length")
            if seen_cl is not None:
                if seen_cl != vals[0]:
                    raise LocalProtocolError("conflicting Content-Length")
                continue
            seen_cl = vals[0]
            out.append((raw, low, vals[0]))
        elif low == b"transfer-encoding":
            seen_te += 1
            if seen_te > 1:
                raise LocalProtocolError("multiple Transfer-Encoding", 501)
            if value.lower() != b"chunked":
                raise LocalProtocolError("unsupported Transfer-Encoding", 501)
            out.append((raw, low, b"chunked"))
        else:
            out.append((raw, low, value))
    return Headers(out)


def _status(code, lo, hi):
    if isinstance(code, bool) or not isinstance(code, int):
        raise LocalProtocolError("status_code must be an integer")
    code = int(code)
    if not (lo <= code < hi):
        raise LocalProtocolError("status_code %d out of range" % code)
    return code


class _Event(object):
    _fields = ()

    def __eq__(self, other):
        return type(other) is type(self) and all(
            getattr(self, f) == getattr(other, f) for f in self._fields)

    __hash__ = None

    def __repr__(self):
        return "%s(%s)" % (type(self).__name__, ", ".join(
            "%s=%r" % (f, getattr(self, f)) for f in self._fields))


class Request(_Event):
    _fields = ("method", "target", "headers", "http_version")

    def __init__(self, method, target, headers, http_version=b"1.1"):
        self.method = _bytesify(method, "method")
        self.target = _bytesify(target, "target")
        self.http_version = _bytesify(http_version, "http_version")
        if not _token_re.match(self.method):
            raise LocalProtocolError("illegal method")
        if not _target_re.match(self.target):
            raise LocalProtocolError("illegal request target")
        if not _version_re.match(self.http_version):
            raise LocalProtocolError("illegal http_version")
        self.headers = normalize_and_validate(headers)
        hosts = sum(1 for _n, v in self.headers if _n == b"host")
        if hosts > 1:
            raise LocalProtocolError("Found multiple Host headers")
        if self.http_version == b"1.1" and hosts == 0:
            raise LocalProtocolError("Missing mandatory Host: header")


class _Resp(_Event):
    _fields = ("status_code", "headers", "http_version", "reason")
    _lo = 0
    _hi = 0

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        self.status_code = _status(status_code, self._lo, self._hi)
        self.http_version = _bytesify(http_version, "http_version")
        self.reason = _bytesify(reason, "reason")
        if not _version_re.match(self.http_version):
            raise LocalProtocolError("illegal http_version")
        self.headers = normalize_and_validate(headers)


class InformationalResponse(_Resp):
    _lo, _hi = 100, 200


class Response(_Resp):
    _lo, _hi = 200, 1000


class Data(_Event):
    _fields = ("data", "chunk_start", "chunk_end")

    def __init__(self, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)


class EndOfMessage(_Event):
    _fields = ("headers",)

    def __init__(self, headers=None):
        self.headers = normalize_and_validate(headers)


class ConnectionClosed(_Event):
    _fields = ()

    def __init__(self):
        pass
