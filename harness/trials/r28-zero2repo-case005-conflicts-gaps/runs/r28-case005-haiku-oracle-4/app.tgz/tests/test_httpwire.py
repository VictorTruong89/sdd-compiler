"""Tests for httpwire. Each test name carries the spec node id(s) it checks (see NOTES.md)."""

import pytest

from httpwire import (
    CLIENT,
    SERVER,
    NEED_DATA,
    PAUSED,
    IDLE,
    SEND_RESPONSE,
    SEND_BODY,
    DONE,
    MUST_CLOSE,
    CLOSED,
    MIGHT_SWITCH_PROTOCOL,
    SWITCHED_PROTOCOL,
    ERROR,
    Connection,
    Request,
    InformationalResponse,
    Response,
    Data,
    EndOfMessage,
    ConnectionClosed,
    LocalProtocolError,
    RemoteProtocolError,
)
from httpwire._errors import ReceiveClosedError


def pair():
    return Connection(CLIENT), Connection(SERVER)


def get(host=b"example.com"):
    return Request(method=b"GET", target=b"/", headers=[(b"Host", host)])


# ---------------------------------------------------------------- FP-01 events

def test_N_000070_six_distinct_event_kinds():
    kinds = {Request, InformationalResponse, Response, Data, EndOfMessage, ConnectionClosed}
    assert len(kinds) == 6


def test_N_000072_request_fields_and_defaults():
    r = Request(method="GET", target="/x", headers=[("Host", "a")])
    assert r.method == b"GET" and r.target == b"/x"
    assert r.http_version == b"1.1"
    assert type(r.method) is bytes


def test_N_000077_http10_request_needs_no_host():
    r = Request(method=b"GET", target=b"/", headers=[], http_version=b"1.0")
    assert r.http_version == b"1.0"


def test_N_000104_http11_request_without_host_refused():
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/", headers=[])


def test_N_000105_duplicate_host_refused_whatever_version():
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/", headers=[(b"HOST", b"a"), (b"host", b"b")], http_version=b"1.0")


def test_N_000079_status_ranges():
    assert InformationalResponse(status_code=100, headers=[]).status_code == 100
    with pytest.raises(LocalProtocolError):
        InformationalResponse(status_code=200, headers=[])
    assert Response(status_code=999, headers=[]).status_code == 999
    with pytest.raises(LocalProtocolError):
        Response(status_code=199, headers=[])
    with pytest.raises(LocalProtocolError):
        Response(status_code="200", headers=[])


def test_N_000082_default_reason_empty_and_version_1_1():
    r = Response(status_code=200, headers=[])
    assert r.reason == b"" and r.http_version == b"1.1"


def test_N_000087_headers_lowercase_view_and_raw_items():
    r = Request(method=b"GET", target=b"/", headers=[(b"Host", b"a"), (b"X-Foo", b"1")])
    assert list(r.headers) == [(b"host", b"a"), (b"x-foo", b"1")]
    assert r.headers[1] == (b"x-foo", b"1")
    assert r.headers.raw_items() == [(b"Host", b"a"), (b"X-Foo", b"1")]


def test_N_000092_content_length_repeats_collapse():
    r = Request(method=b"POST", target=b"/", headers=[(b"Host", b"a"), (b"Content-Length", b"5"),
                                                    (b"content-length", b"5, 5")])
    assert [h for h in r.headers if h[0] == b"content-length"] == [(b"content-length", b"5")]


def test_N_000114_content_length_must_be_decimal():
    with pytest.raises(LocalProtocolError):
        Request(method=b"POST", target=b"/", headers=[(b"Host", b"a"), (b"Content-Length", b"+5")])


def test_N_000116_content_length_of_18_digits_accepted_19_refused():
    ok = Request(method=b"POST", target=b"/", headers=[(b"Host", b"a"), (b"Content-Length", b"9" * 18)])
    assert ok.headers[1] == (b"content-length", b"9" * 18)
    with pytest.raises(LocalProtocolError):
        Request(method=b"POST", target=b"/", headers=[(b"Host", b"a"), (b"Content-Length", b"9" * 19)])


def test_N_000115_conflicting_content_length_refused():
    with pytest.raises(LocalProtocolError):
        Request(method=b"POST", target=b"/", headers=[(b"Host", b"a"), (b"Content-Length", b"5"),
                                                    (b"Content-Length", b"6")])


def test_N_000120_transfer_encoding_other_than_chunked_refused_501():
    with pytest.raises(LocalProtocolError) as info:
        Request(method=b"POST", target=b"/", headers=[(b"Host", b"a"), (b"Transfer-Encoding", b"gzip, chunked")])
    assert info.value.error_status_hint == 501


def test_N_000093_single_chunked_stored_lowercase():
    r = Request(method=b"POST", target=b"/", headers=[(b"Host", b"a"), (b"Transfer-Encoding", b"ChUnKeD")])
    assert r.headers[1] == (b"transfer-encoding", b"chunked")


def test_N_000121_second_transfer_encoding_refused_501_even_both_chunked():
    with pytest.raises(LocalProtocolError) as info:
        Request(method=b"POST", target=b"/", headers=[(b"Host", b"a"), (b"Transfer-Encoding", b"chunked"),
                                                    (b"Transfer-Encoding", b"chunked")])
    assert info.value.error_status_hint == 501


def test_N_000097_value_control_bytes_refused_and_space_edges_refused():
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/", headers=[(b"Host", b"a"), (b"X", b"a\x01b")])
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/", headers=[(b"Host", b"a"), (b"X", b" lead")])
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/", headers=[(b"Host", b"a"), (b"X", b"trail\t")])


def test_N_000100_non_ascii_value_bytes_accepted():
    r = Request(method=b"GET", target=b"/", headers=[(b"Host", b"a"), (b"X", b"caf\xe9")])
    assert r.headers[1] == (b"x", b"caf\xe9")


def test_N_000106_header_name_must_be_token():
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/", headers=[(b"Host", b"a"), (b"bad name", b"x")])


def test_N_000110_target_must_be_visible_ascii_and_method_token():
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/a b", headers=[(b"Host", b"a")])
    with pytest.raises(LocalProtocolError):
        Request(method=b"G T", target=b"/", headers=[(b"Host", b"a")])


def test_N_000466_invalid_construction_returns_no_event_and_no_state_change():
    c = Connection(CLIENT)
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/", headers=[])
    assert c.our_state is IDLE
    c.send(get())  # a later valid construction still works
    assert c.our_state is SEND_BODY


def test_N_000085_end_of_message_default_empty_trailers():
    assert list(EndOfMessage().headers) == []


def test_N_000463_data_marks_are_exact_bools():
    d = Data(data=b"x", chunk_start=1, chunk_end=0)
    assert d.chunk_start is True and d.chunk_end is False


# ------------------------------------------------------------- FP-02 connection

def test_N_000123_roles_and_initial_states():
    c, s = pair()
    assert c.our_role is CLIENT and c.their_role is SERVER
    assert s.our_role is SERVER and s.their_role is CLIENT
    assert c.our_state is IDLE and c.their_state is IDLE
    assert c.states == {CLIENT: IDLE, SERVER: IDLE}


def test_N_000172_unknown_role_refused():
    with pytest.raises(LocalProtocolError):
        Connection("client")


def test_N_000127_pull_with_nothing_stored_is_need_data():
    c, _ = pair()
    assert c.next_event() is NEED_DATA


def test_N_000128_client_send_request_bytes_and_states():
    c, s = pair()
    data = c.send(get())
    assert data == b"GET / HTTP/1.1\r\nHost: example.com\r\n\r\n"
    assert c.our_state is SEND_BODY
    assert c.their_state is SEND_RESPONSE
    assert c.their_http_version is None  # the client does not record its own version
    s.receive_data(data)
    assert isinstance(s.next_event(), Request)
    assert s.their_http_version == b"1.1"
    assert s.their_state is SEND_BODY and s.our_state is SEND_RESPONSE


def test_N_000161_host_written_first():
    c, _ = pair()
    data = c.send(Request(method=b"GET", target=b"/", headers=[(b"X-A", b"1"), (b"Host", b"h")]))
    assert data == b"GET / HTTP/1.1\r\nHost: h\r\nX-A: 1\r\n\r\n"


def test_N_000163_original_name_casing_on_wire():
    c, _ = pair()
    data = c.send(Request(method=b"GET", target=b"/", headers=[(b"HOST", b"h"), (b"X-Mixed-Case", b"v")]))
    assert b"X-Mixed-Case: v\r\n" in data


def test_N_000144_feed_only_stores_and_changes_no_state():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
    assert s.our_state is IDLE and s.their_state is IDLE
    assert s.their_http_version is None
    assert s.trailing_data == (b"GET / HTTP/1.1\r\nHost: h\r\n\r\n", False)


def test_N_000153_incomplete_event_is_need_data_and_retained():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHo")
    assert s.next_event() is NEED_DATA
    s.receive_data(b"st: h\r\n\r\n")
    assert isinstance(s.next_event(), Request)


def test_N_000180_feed_after_empty_feed_is_runtime_error_not_protocol_error():
    s = Connection(SERVER)
    s.receive_data(b"")
    with pytest.raises(ReceiveClosedError) as info:
        s.receive_data(b"x")
    assert not isinstance(info.value, (LocalProtocolError, RemoteProtocolError))


def test_N_000165_lone_lf_line_endings_accepted_when_reading():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\nHost: h\n\n")
    ev = s.next_event()
    assert isinstance(ev, Request) and ev.headers[0] == (b"host", b"h")


def test_N_000166_status_line_without_reason_accepted():
    c = Connection(CLIENT)
    c.send(get())
    c.send(EndOfMessage())
    c.receive_data(b"HTTP/1.1 204\r\n\r\n")
    ev = c.next_event()
    assert isinstance(ev, Response) and ev.status_code == 204 and ev.reason == b""


def test_N_000167_obsolete_line_folding_joined_with_single_space():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\nX-Long: one\r\n   two\t\r\n\r\n")
    ev = s.next_event()
    assert ev.headers[1] == (b"x-long", b"one two")


def test_N_000176_continuation_as_first_header_refused():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\n Host: h\r\n\r\n")
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_N_000177_space_first_byte_fails_at_once_without_line_ending():
    s = Connection(SERVER)
    s.receive_data(b" ")
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_N_000179_control_first_byte_fails_at_once():
    s = Connection(SERVER)
    s.receive_data(b"\x01")
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_N_000174_bad_header_is_remote_protocol_error():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\nBad Name: x\r\n\r\n")
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_N_000302_remote_error_sets_their_error_and_is_sticky():
    s = Connection(SERVER)
    s.receive_data(b"NOPE\r\n\r\n")
    with pytest.raises(RemoteProtocolError):
        s.next_event()
    assert s.their_state is ERROR and s.our_state is IDLE
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_N_000304_server_can_still_send_error_response_with_close():
    s = Connection(SERVER)
    s.receive_data(b"NOPE\r\n\r\n")
    with pytest.raises(RemoteProtocolError):
        s.next_event()
    data = s.send(Response(status_code=400, headers=[(b"Content-Length", b"0")]))
    assert data.startswith(b"HTTP/1.1 400 ")
    assert b"Connection: close\r\n" in data


def test_N_000307_refused_send_makes_our_side_error_and_sticks():
    c, _ = pair()
    c.send(get())
    with pytest.raises(LocalProtocolError):
        c.send(get())  # a second request before the cycle is started
    assert c.our_state is ERROR
    with pytest.raises(LocalProtocolError):
        c.send(EndOfMessage())


def test_N_000312_send_failed_puts_our_side_in_error_and_leaves_peer_alone():
    c, _ = pair()
    c.send(get())
    c.send(EndOfMessage())
    assert c.our_state is DONE
    assert c.send_failed() is None
    assert c.our_state is ERROR
    assert c.their_state is SEND_RESPONSE
    with pytest.raises(LocalProtocolError):
        c.send(EndOfMessage())


def test_N_000311_done_side_becomes_must_close_when_peer_errors():
    c, _ = pair()
    c.send(get())
    c.send(EndOfMessage())
    assert c.our_state is DONE
    c.receive_data(b"junk\r\n\r\n")
    with pytest.raises(RemoteProtocolError):
        c.next_event()
    assert c.their_state is ERROR
    assert c.our_state is MUST_CLOSE


def test_N_000316_incomplete_head_over_limit_is_431():
    s = Connection(SERVER, max_incomplete_event_size=32)
    s.receive_data(b"GET /" + b"a" * 40)
    with pytest.raises(RemoteProtocolError) as info:
        s.next_event()
    assert info.value.error_status_hint == 431
    assert s.their_state is ERROR


def test_N_000317_default_limit_boundary_is_16_kib():
    s = Connection(SERVER)
    s.receive_data(b"GET /" + b"a" * (16 * 1024 - 5))  # exactly the limit: still incomplete
    assert s.next_event() is NEED_DATA
    s.receive_data(b"a")  # one byte over the limit
    with pytest.raises(RemoteProtocolError) as info:
        s.next_event()
    assert info.value.error_status_hint == 431


def test_N_000292_default_suggested_status_is_400_and_is_int():
    s = Connection(SERVER)
    s.receive_data(b"junk\r\n\r\n")
    with pytest.raises(RemoteProtocolError) as info:
        s.next_event()
    assert info.value.error_status_hint == 400
    assert type(info.value.error_status_hint) is int


def test_N_000474_bytes_after_close_not_protocol_error():
    s = Connection(SERVER)
    s.receive_data(b"")
    with pytest.raises(ReceiveClosedError):
        s.receive_data(b"x")


# -------------------------------------------------------------- FP-03 framing

def test_N_000188_content_length_request_body_and_eom():
    c, s = pair()
    head = c.send(Request(method=b"POST", target=b"/", headers=[(b"Host", b"h"), (b"Content-Length", b"5")]))
    body = c.send(Data(data=b"hello"))
    assert body == b"hello"
    assert c.send(EndOfMessage()) is None
    s.receive_data(head + body)
    req = s.next_event()
    d = s.next_event()
    eom = s.next_event()
    assert isinstance(req, Request)
    assert isinstance(d, Data) and d.data == b"hello"
    assert isinstance(eom, EndOfMessage)


def test_N_000189_content_length_overflow_refused_and_makes_error():
    c, _ = pair()
    c.send(Request(method=b"POST", target=b"/", headers=[(b"Host", b"h"), (b"Content-Length", b"2")]))
    with pytest.raises(LocalProtocolError):
        c.send(Data(data=b"abc"))
    assert c.our_state is ERROR


def test_N_000190_eom_before_content_length_sent_refused():
    c, _ = pair()
    c.send(Request(method=b"POST", target=b"/", headers=[(b"Host", b"h"), (b"Content-Length", b"2")]))
    with pytest.raises(LocalProtocolError):
        c.send(EndOfMessage())


def test_N_000192_chunked_send_encoding_and_trailers():
    c, _ = pair()
    c.send(Request(method=b"POST", target=b"/", headers=[(b"Host", b"h"), (b"Transfer-Encoding", b"chunked")]))
    assert c.send(Data(data=b"hello")) == b"5\r\nhello\r\n"
    assert c.send(Data(data=b"")) is None
    assert c.send(EndOfMessage(headers=[(b"X-T", b"1")])) == b"0\r\nX-T: 1\r\n\r\n"


def test_N_000195_chunked_request_pull_and_chunk_marks():
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n4\r\nwiki\r\n")
    assert isinstance(s.next_event(), Request)
    d = s.next_event()
    assert isinstance(d, Data) and d.data == b"wiki" and d.chunk_start and d.chunk_end


def test_N_000221_chunk_split_across_pieces_marks_start_then_end():
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n6\r\nab")
    s.next_event()
    first = s.next_event()
    assert first.data == b"ab" and first.chunk_start and not first.chunk_end
    assert s.next_event() is NEED_DATA
    s.receive_data(b"cdef\r\n0\r\n\r\n")
    second = s.next_event()
    assert second.data == b"cdef" and not second.chunk_start and second.chunk_end
    assert isinstance(s.next_event(), EndOfMessage)


def test_N_000228_chunk_size_hex_and_extensions_discarded():
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n"
                   b"A;name=val \r\n0123456789\r\n0\r\n\r\n")
    s.next_event()
    assert s.next_event().data == b"0123456789"


def test_N_000244_chunk_size_with_too_many_digits_refused():
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n" + b"1" * 40 + b"\r\n")
    s.next_event()
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_N_000243_chunk_data_must_be_followed_by_exact_crlf():
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n2\r\nabXY")
    s.next_event()
    s.next_event()
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_N_000208_close_delimited_response_read_until_close():
    c = Connection(CLIENT)
    c.send(get())
    c.send(EndOfMessage())
    c.receive_data(b"HTTP/1.1 200 OK\r\n\r\nbody")
    assert isinstance(c.next_event(), Response)
    d = c.next_event()
    assert isinstance(d, Data) and d.data == b"body"
    assert c.next_event() is NEED_DATA
    c.receive_data(b"")
    eom = c.next_event()
    cc = c.next_event()
    assert isinstance(eom, EndOfMessage) and isinstance(cc, ConnectionClosed)
    assert c.our_state is MUST_CLOSE


def test_N_000202_response_neither_framing_from_http11_peer_is_chunked():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
    s.next_event()
    head = s.send(Response(status_code=200, headers=[]))
    assert b"Transfer-Encoding: chunked\r\n" in head
    assert s.send(Data(data=b"ab")) == b"2\r\nab\r\n"
    assert s.send(EndOfMessage()) == b"0\r\n\r\n"


def test_N_000203_http10_peer_response_is_close_delimited_with_connection_close():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.0\r\n\r\n")
    s.next_event()
    head = s.send(Response(status_code=200, headers=[]))
    assert head == b"HTTP/1.1 200 \r\nConnection: close\r\n\r\n"
    assert s.send(Data(data=b"raw")) == b"raw"
    assert s.send(EndOfMessage()) is None
    assert s.our_state is MUST_CLOSE


def test_N_000207_response_with_both_framing_headers_transfer_encoding_wins():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
    s.next_event()
    head = s.send(Response(status_code=200, headers=[(b"Content-Length", b"3"), (b"Transfer-Encoding", b"chunked")]))
    assert b"Content-Length" not in head
    assert b"Transfer-Encoding: chunked" in head


def test_N_000215_204_is_always_empty_with_no_framing_headers():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
    s.next_event()
    head = s.send(Response(status_code=204, headers=[(b"Content-Length", b"0")]))
    assert head == b"HTTP/1.1 204 \r\n\r\n"
    assert s.send(EndOfMessage()) is None


def test_N_000199_content_length_zero_kept_on_wire_for_ordinary_response():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
    s.next_event()
    assert b"Content-Length: 0\r\n" in s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))


def test_N_000219_head_response_gets_get_framing_headers_but_empty_body():
    s = Connection(SERVER)
    s.receive_data(b"HEAD / HTTP/1.1\r\nHost: h\r\n\r\n")
    s.next_event()
    head = s.send(Response(status_code=200, headers=[(b"Content-Length", b"100")]))
    assert b"Content-Length: 100\r\n" in head
    assert s.send(EndOfMessage()) is None


def test_N_000234_passthrough_keeps_placeholder_identity_under_content_length():
    class Placeholder:
        def __len__(self):
            return 7

    c = Connection(CLIENT)
    c.send(Request(method=b"POST", target=b"/", headers=[(b"Host", b"h"), (b"Content-Length", b"7")]))
    p = Placeholder()
    pieces = c.send_with_data_passthrough(Data(data=p))
    assert isinstance(pieces, list)
    assert pieces[0] is p
    assert c.send(EndOfMessage()) is None


def test_N_000236_passthrough_chunked_adds_size_and_crlf_pieces():
    class Placeholder:
        def __len__(self):
            return 3

    c = Connection(CLIENT)
    c.send(Request(method=b"POST", target=b"/", headers=[(b"Host", b"h"), (b"Transfer-Encoding", b"chunked")]))
    p = Placeholder()
    pieces = c.send_with_data_passthrough(Data(data=p))
    assert pieces[0] == b"3\r\n" and pieces[1] is p and pieces[2] == b"\r\n"


def test_N_000240_trailers_need_chunked_framing():
    c, _ = pair()
    c.send(Request(method=b"POST", target=b"/", headers=[(b"Host", b"h"), (b"Content-Length", b"0")]))
    with pytest.raises(LocalProtocolError):
        c.send(EndOfMessage(headers=[(b"X-A", b"1")]))


def test_N_000241_trailers_to_http10_peer_refused_even_when_chunked():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.0\r\n\r\n")
    s.next_event()
    s.send(Response(status_code=200, headers=[(b"Transfer-Encoding", b"chunked")]))
    with pytest.raises(LocalProtocolError):
        s.send(EndOfMessage(headers=[(b"X-A", b"1")]))


def test_N_000246_non_chunked_transfer_encoding_refused():
    with pytest.raises(LocalProtocolError):
        Response(status_code=200, headers=[(b"Transfer-Encoding", b"gzip")])


# ------------------------------------------------------------ FP-04 lifecycle

def _one_exchange(c, s):
    """Run a complete GET/200 exchange on a keep-alive pair; both end DONE."""
    c.send(get())
    c.send(EndOfMessage())
    s.receive_data(b"GET / HTTP/1.1\r\nHost: example.com\r\n\r\n")
    s.next_event()
    s.next_event()
    s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    c.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
    c.next_event()
    c.next_event()


def test_N_000270_keep_alive_cycle_restarts_both_idle():
    c, s = pair()
    _one_exchange(c, s)
    assert c.states == {CLIENT: DONE, SERVER: DONE}
    c.start_next_cycle()
    s.start_next_cycle()
    assert c.states == {CLIENT: IDLE, SERVER: IDLE}
    _one_exchange(c, s)
    assert c.states == {CLIENT: DONE, SERVER: DONE}


def test_N_000280_start_next_cycle_refused_until_both_done_and_changes_nothing():
    c, _ = pair()
    c.send(get())
    before = c.states
    with pytest.raises(LocalProtocolError):
        c.start_next_cycle()
    assert c.states == before and c.our_state is SEND_BODY


def test_N_000274_client_pipelining_refused():
    c, _ = pair()
    c.send(get())
    c.send(EndOfMessage())
    with pytest.raises(LocalProtocolError):
        c.send(get())


def test_N_000275_server_pauses_pipelined_requests_until_next_cycle():
    c, s = pair()
    c.send(get())
    c.send(EndOfMessage())
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\nGET /2 HTTP/1.1\r\nHost: h\r\n\r\n")
    assert isinstance(s.next_event(), Request)
    assert isinstance(s.next_event(), EndOfMessage)  # the client's body ends
    assert s.next_event() is PAUSED                  # client is DONE, bytes remain
    s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    assert s.next_event() is PAUSED                  # still paused until the next cycle
    c.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
    c.next_event()
    c.next_event()
    c.start_next_cycle()
    s.start_next_cycle()
    assert isinstance(s.next_event(), Request)       # the pipelined request is now parsed


def test_N_000286_http10_peer_cannot_be_kept_alive():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.0\r\nHost: h\r\n\r\n")
    s.next_event()
    s.next_event()
    s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    assert s.states == {CLIENT: MUST_CLOSE, SERVER: MUST_CLOSE}
    with pytest.raises(LocalProtocolError):
        s.start_next_cycle()
    assert s.states == {CLIENT: MUST_CLOSE, SERVER: MUST_CLOSE}


def test_N_000265_keep_alive_off_adds_connection_close_and_drops_keep_alive():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\nConnection: close\r\n\r\n")
    s.next_event()
    s.next_event()
    head = s.send(Response(status_code=200, headers=[(b"Content-Length", b"0"), (b"Connection", b"keep-alive")]))
    assert b"Connection: close\r\n" in head and b"keep-alive" not in head


def test_N_000262_close_token_matched_as_whole_element_only():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\nConnection: closed-later\r\n\r\n")
    s.next_event()
    s.next_event()
    s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    assert s.our_state is DONE


def test_N_000281_start_next_cycle_refusal_is_not_error():
    c, _ = pair()
    c.send(get())
    with pytest.raises(LocalProtocolError):
        c.start_next_cycle()
    assert c.our_state is SEND_BODY


# ---------------------------------------------------------- FP-05 error paths

def test_N_000305_send_after_remote_error_still_works():
    s = Connection(SERVER)
    s.receive_data(b"??\r\n\r\n")
    with pytest.raises(RemoteProtocolError):
        s.next_event()
    assert s.our_state is IDLE
    assert s.send(Response(status_code=400, headers=[])).startswith(b"HTTP/1.1 400 ")


def test_N_000324_truncated_content_length_body_is_remote_error():
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nContent-Length: 5\r\n\r\nab")
    assert isinstance(s.next_event(), Request)
    d = s.next_event()
    assert isinstance(d, Data) and d.data == b"ab"
    assert s.next_event() is NEED_DATA
    s.receive_data(b"")
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_N_000326_local_and_remote_errors_are_distinct_types():
    assert not issubclass(LocalProtocolError, RemoteProtocolError)
    assert not issubclass(RemoteProtocolError, LocalProtocolError)


def test_N_000328_error_state_cannot_be_left_by_cycle_start():
    c, _ = pair()
    c.send_failed()
    with pytest.raises(LocalProtocolError):
        c.start_next_cycle()
    assert c.our_state is ERROR


# ------------------------------------------------------------ FP-06 shutdown

def test_N_000334_connection_closed_from_idle_closes_our_side():
    c, s = pair()
    assert c.send(ConnectionClosed()) is None
    assert c.our_state is CLOSED
    s.receive_data(b"")
    assert isinstance(s.next_event(), ConnectionClosed)
    assert s.their_state is CLOSED
    assert s.our_state is MUST_CLOSE


def test_N_000339_empty_feed_pulls_connection_closed_and_keeps_yielding_it():
    s = Connection(SERVER)
    s.receive_data(b"")
    assert isinstance(s.next_event(), ConnectionClosed)
    assert isinstance(s.next_event(), ConnectionClosed)


def test_N_000345_connection_closed_not_allowed_mid_message():
    c, _ = pair()
    c.send(get())
    with pytest.raises(LocalProtocolError):
        c.send(ConnectionClosed())


def test_N_000347_pulled_close_from_peer_in_wrong_state_is_remote_error():
    c, _ = pair()
    c.send(get())  # the server is in SEND_RESPONSE, which may not close
    c.receive_data(b"")
    with pytest.raises(RemoteProtocolError):
        c.next_event()


# ----------------------------------------------------------- FP-07 informational

def test_N_000349_informational_responses_then_final():
    c, s = pair()
    c.send(get())
    c.send(EndOfMessage())
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
    s.next_event()
    s.next_event()
    assert s.send(InformationalResponse(status_code=103, headers=[(b"Link", b"x")])).startswith(b"HTTP/1.1 103 ")
    assert s.our_state is SEND_RESPONSE
    s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    assert s.our_state is SEND_BODY
    c.receive_data(b"HTTP/1.1 103 \r\nLink: x\r\n\r\n")
    assert isinstance(c.next_event(), InformationalResponse)
    assert c.their_state is SEND_RESPONSE


def test_N_000354_expect_100_continue_sets_flags_on_client_and_server():
    c, s = pair()
    c.send(Request(method=b"POST", target=b"/", headers=[(b"Host", b"h"), (b"Expect", b"100-Continue"),
                                                         (b"Content-Length", b"0")]))
    assert c.client_is_waiting_for_100_continue is True
    assert c.they_are_waiting_for_100_continue is False
    s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nExpect: 100-continue\r\nContent-Length: 0\r\n\r\n")
    s.next_event()
    assert s.they_are_waiting_for_100_continue is True
    s.send(InformationalResponse(status_code=100, headers=[]))
    assert s.they_are_waiting_for_100_continue is False


def test_N_000357_expect_on_http10_sets_no_flag():
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.0\r\nHost: h\r\nExpect: 100-continue\r\n\r\n")
    s.next_event()
    assert s.client_is_waiting_for_100_continue is False


def test_N_000364_connect_accepted_by_2xx_switches_both_sides():
    c, s = pair()
    c.send(Request(method=b"CONNECT", target=b"example.com:443", headers=[(b"Host", b"example.com:443")]))
    c.send(EndOfMessage())
    assert c.our_state is MIGHT_SWITCH_PROTOCOL
    s.receive_data(b"CONNECT example.com:443 HTTP/1.1\r\nHost: example.com:443\r\n\r\n")
    assert isinstance(s.next_event(), Request)
    assert isinstance(s.next_event(), EndOfMessage)
    assert s.their_state is MIGHT_SWITCH_PROTOCOL
    assert s.next_event() is PAUSED
    out = s.send(Response(status_code=200, headers=[]))
    assert out == b"HTTP/1.1 200 \r\n\r\n"
    assert s.our_state is SWITCHED_PROTOCOL and s.their_state is SWITCHED_PROTOCOL
    with pytest.raises(LocalProtocolError):
        s.send(Response(status_code=200, headers=[]))
    c.receive_data(out + b"tunnel-bytes")
    assert isinstance(c.next_event(), Response)
    assert c.next_event() is PAUSED
    assert c.trailing_data == (b"tunnel-bytes", False)


def test_N_000378_denied_switch_returns_to_http_after_next_cycle():
    c, s = pair()
    c.send(Request(method=b"CONNECT", target=b"example.com:443", headers=[(b"Host", b"example.com:443")]))
    c.send(EndOfMessage())
    s.receive_data(b"CONNECT example.com:443 HTTP/1.1\r\nHost: example.com:443\r\n\r\n")
    s.next_event()
    s.next_event()
    s.send(Response(status_code=407, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    c.receive_data(b"HTTP/1.1 407 \r\nContent-Length: 0\r\n\r\n")
    c.next_event()
    c.next_event()
    assert c.our_state is DONE and s.our_state is DONE
    c.start_next_cycle()
    s.start_next_cycle()
    assert c.states == {CLIENT: IDLE, SERVER: IDLE}


def test_N_000366_upgrade_accepted_by_101_informational_response():
    c, s = pair()
    c.send(Request(method=b"GET", target=b"/ws", headers=[(b"Host", b"h"), (b"Upgrade", b"websocket"),
                                                         (b"Connection", b"Upgrade")]))
    c.send(EndOfMessage())
    s.receive_data(b"GET /ws HTTP/1.1\r\nHost: h\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n\r\n")
    s.next_event()
    s.next_event()
    out = s.send(InformationalResponse(status_code=101, headers=[(b"Upgrade", b"websocket"),
                                                                 (b"Connection", b"Upgrade")]))
    assert out.startswith(b"HTTP/1.1 101 ")
    assert s.our_state is SWITCHED_PROTOCOL


def test_N_000367_other_informational_neither_accepts_nor_denies_upgrade():
    c, s = pair()
    c.send(Request(method=b"GET", target=b"/ws", headers=[(b"Host", b"h"), (b"Upgrade", b"websocket")]))
    c.send(EndOfMessage())
    s.receive_data(b"GET /ws HTTP/1.1\r\nHost: h\r\nUpgrade: websocket\r\n\r\n")
    s.next_event()
    s.next_event()
    s.send(InformationalResponse(status_code=102, headers=[]))
    assert s.our_state is SEND_RESPONSE


def test_N_000388_trailing_data_after_accept_is_stored_and_close_stays_paused():
    s = Connection(SERVER)
    s.receive_data(b"CONNECT h:1 HTTP/1.1\r\nHost: h:1\r\n\r\n")
    s.next_event()
    s.send(Response(status_code=200, headers=[]))
    s.receive_data(b"abc")
    s.receive_data(b"")
    assert s.next_event() is PAUSED
    assert s.trailing_data == (b"abc", True)


def test_N_000392_client_cannot_send_request_while_might_switch():
    c, _ = pair()
    c.send(Request(method=b"CONNECT", target=b"h:1", headers=[(b"Host", b"h:1")]))
    c.send(EndOfMessage())
    with pytest.raises(LocalProtocolError):
        c.send(get())


def test_N_000394_101_is_informational_not_a_final_response():
    with pytest.raises(LocalProtocolError):
        Response(status_code=101, headers=[])
    assert InformationalResponse(status_code=101, headers=[]).status_code == 101


# ------------------------------------------------------- round trips

def test_N_000134_round_trip_preserves_method_target_and_headers():
    c, s = pair()
    wire = c.send(Request(method=b"PUT", target=b"/p?q=1", headers=[(b"Host", b"h"), (b"X-Q", b"v")]))
    c.send(EndOfMessage())
    s.receive_data(wire)
    ev = s.next_event()
    assert ev.method == b"PUT" and ev.target == b"/p?q=1"
    assert list(ev.headers) == [(b"host", b"h"), (b"x-q", b"v")]


def test_N_000135_response_status_and_reason_survive_round_trip():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
    s.next_event()
    wire = s.send(Response(status_code=418, headers=[(b"Content-Length", b"0")], reason=b"Teapot"))
    c = Connection(CLIENT)
    c.send(get())
    c.send(EndOfMessage())
    c.receive_data(wire)
    r = c.next_event()
    assert r.status_code == 418 and r.reason == b"Teapot"


def test_N_000145_feed_then_pull_is_two_step():
    c, s = pair()
    wire = c.send(get())
    s.receive_data(wire[:5])
    assert s.next_event() is NEED_DATA
    s.receive_data(wire[5:])
    assert isinstance(s.next_event(), Request)


# ------------------------------------------------- additional coverage points

def test_N_000170_peer_version_retained_across_later_sends():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
    s.next_event()
    assert s.their_http_version == b"1.1"
    s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    assert s.their_http_version == b"1.1"


def test_N_000186_request_without_framing_headers_has_empty_body():
    c, s = pair()
    wire = c.send(get())
    assert c.send(EndOfMessage()) is None
    with pytest.raises(LocalProtocolError):
        c.send(Data(data=b"x"))
    s.receive_data(wire)
    assert isinstance(s.next_event(), Request)
    assert isinstance(s.next_event(), EndOfMessage)


def test_N_000257_server_idle_may_send_final_response_without_a_request():
    s = Connection(SERVER)
    head = s.send(Response(status_code=408, headers=[]))
    assert s.our_state is SEND_BODY
    assert head == b"HTTP/1.1 408 \r\nConnection: close\r\n\r\n"
    assert s.send(EndOfMessage()) is None
    assert s.our_state is MUST_CLOSE


def test_N_000173_bad_role_produces_no_connection_object():
    with pytest.raises(LocalProtocolError):
        Connection(None)
