"""Root conftest: its presence puts /app on sys.path so `import httpwire` works under plain `pytest`."""
