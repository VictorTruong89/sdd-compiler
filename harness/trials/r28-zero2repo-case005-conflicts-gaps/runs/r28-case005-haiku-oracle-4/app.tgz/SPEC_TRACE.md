# Spec traceability

Every id in `spec/CHECKLIST.md` ends in one of three states. Ids with an inline
`# spec: N-…` or `N-…` marker in `httpwire/` or `tests/` are traced there. The
rows below cover the rest, grouped by behaviour. "Tests" names are functions in
`tests/test_httpwire.py`. Status is `implemented`, `tested` (a test checks it),
or `not done` (with reason).

| Ids | Behaviour | Where implemented | Tests | Status |
|---|---|---|---|---|
| N-000001–N-000069 | Product overview, library-only surface, non-functional constraints, non-goals | Package layout (`httpwire/`), no socket or process code anywhere, no CLI or `__main__`, HTTP/2 not implemented, `gzip`/`deflate` transfer codings refused (`_events._normalize_headers`), chunk extensions parsed and discarded (`_wire.CHUNK_SIZE_LINE`), HTTP/1.0 never kept alive (`Connection._apply`, `_encode_response`) | test_N_000145_feed_then_pull_is_two_step, test_N_000246_non_chunked_transfer_encoding_refused | implemented (by design; I/O and CLI absence cannot be tested directly) |
| N-000102–N-000103 | Refused construction produces no event and no state change | `_events` constructors raise before building anything | test_N_000466_invalid_construction_returns_no_event_and_no_state_change | tested |
| N-000122 | Connection may be built in client or server role | `Connection.__init__` | test_N_000123_roles_and_initial_states | tested |
| N-000127 | Pull with nothing stored returns need-data | `Connection._next_event` | test_N_000127_pull_with_nothing_stored_is_need_data | tested |
| N-000132–N-000135 | Request bytes, states after send/pull, round trip of method/target/headers/payload | `Connection._encode_request`, `_pull_head`, `_apply` | test_N_000128_client_send_request_bytes_and_states, test_N_000134_round_trip_preserves_method_target_and_headers, test_N_000135_response_status_and_reason_survive_round_trip | tested |
| N-000138–N-000139 | Server SEND_RESPONSE to SEND_BODY on final response; client records same | `_SENDER_TRANSITIONS`, `_apply` | test_N_000349_informational_responses_then_final | tested |
| N-000140–N-000143 | Content-Length end-of-message encodes empty; next pull yields EOM without input; both DONE | `_encode_end`, `_pull_body` | test_N_000188_content_length_request_body_and_eom, test_N_000270_keep_alive_cycle_restarts_both_idle | tested |
| N-000144–N-000152 | Feed only stores; pull yields at most one event; bytes for later events stay stored | `receive_data`, `_pull_body`, `_pull_head` | test_N_000144_feed_only_stores_and_changes_no_state | tested |
| N-000153–N-000155 | Incomplete event gives need-data and keeps bytes | `_pull_head`, `_pull_chunked` | test_N_000153_incomplete_event_is_need_data_and_retained | tested |
| N-000156–N-000160 | HTTP/1.1 only on send; peer HTTP/1.0 pulled and reported as `1.0`; no framing means empty body | `_encode_request`, `_encode_response`, `_received_framing` | test_N_000203_http10_peer_response_is_close_delimited_with_connection_close, test_N_000186_request_without_framing_headers_has_empty_body | tested |
| N-000165 | Lone LF accepted in received header blocks | `_wire.split_head` (CF-000074 decision) | test_N_000165_lone_lf_line_endings_accepted_when_reading | tested |
| N-000168 | Obsolete folding joins to previous value | `_wire.parse_header_lines` | test_N_000167_obsolete_line_folding_joined_with_single_space | tested |
| N-000170–N-000171 | Peer version retained after pull; later sends do not change it | `Connection._apply` (records version only for the peer's events) | test_N_000170_peer_version_retained_across_later_sends | tested |
| N-000173 | Bad role yields no connection object | `Connection.__init__` | test_N_000173_bad_role_produces_no_connection_object | tested |
| N-000174–N-000176 | Illegal peer bytes raise RemoteProtocolError; continuation as first header refused | `_wire`, `Connection._next_event` | test_N_000174_bad_header_is_remote_protocol_error, test_N_000176_continuation_as_first_header_refused | tested |
| N-000183–N-000184, N-000186 | Framing chosen from headers (and method and peer version for responses) | `_encode_request`, `_encode_response`, `_received_framing` | test_N_000188…, test_N_000202…, test_N_000219… | tested |
| N-000190–N-000191 | Content-Length: exact bytes; matching EOM encodes empty | `_encode_data`, `_encode_end` | test_N_000189_content_length_overflow_refused_and_makes_error, test_N_000190_eom_before_content_length_sent_refused | tested |
| N-000195–N-000196 | Chunked: one chunk per non-empty data event; trailers after zero chunk | `_encode_data`, `_encode_end`, `_pull_chunked` | test_N_000192_chunked_send_encoding_and_trailers, test_N_000195_chunked_request_pull_and_chunk_marks | tested |
| N-000199 | Content-Length: 0 kept on the wire for ordinary responses | `_encode_response` (CF-000102 decision) | test_N_000199_content_length_zero_kept_on_wire_for_ordinary_response | tested |
| N-000201 | Response wire form chosen from peer's HTTP version | `_encode_response` | test_N_000202_…, test_N_000203_… | tested |
| N-000209 | HTTP/1.0 peer: raw payloads, empty EOM, connection must close | `_encode_response`, `_encode_data`, `_fire` | test_N_000203_http10_peer_response_is_close_delimited_with_connection_close | tested |
| N-000212–N-000213 | Body delivered as data; chunk-size and body states | `_pull_body`, `_pull_chunked` | test_N_000208_close_delimited_response_read_until_close, test_N_000195… | tested |
| N-000221–N-000227 | Chunk marks: start on first piece, end on completing piece, both if one piece; non-chunked carry neither | `_pull_chunked` | test_N_000221_chunk_split_across_pieces_marks_start_then_end, test_N_000195_chunked_request_pull_and_chunk_marks | tested |
| N-000231 | Chunk extensions parsed and discarded | `_wire.CHUNK_SIZE_LINE` | test_N_000228_chunk_size_hex_and_extensions_discarded | tested |
| N-000234–N-000236 | Passthrough keeps payload identity; chunked adds size and CRLF pieces | `_encode_data` | test_N_000234_…, test_N_000236_… | tested |
| N-000239–N-000240 | Content-Length or close-delimited with trailers refused | `_encode_end` | test_N_000240_trailers_need_chunked_framing | tested |
| N-000243–N-000244 | Whitespace/CRLF rules and chunk-size digit limit | `_pull_chunked`, `_wire.parse_chunk_size` | test_N_000243_chunk_data_must_be_followed_by_exact_crlf, test_N_000244_chunk_size_with_too_many_digits_refused | tested |
| N-000246–N-000249 | Non-chunked TE refused; FP-04 public entry and queryable states | `_events._normalize_headers`, `Connection` | test_N_000246_…, test_N_000123_roles_and_initial_states (states) | tested |
| N-000251–N-000254 | Normal cycle transitions (client SEND_BODY, server SEND_RESPONSE, both sides' transitions) | `_SENDER_TRANSITIONS`, `_apply` | test_N_000270_keep_alive_cycle_restarts_both_idle | tested |
| N-000257–N-000258 | Server in IDLE may send a final response without a request (framing for unknown peer) | `_SENDER_TRANSITIONS` (SERVER IDLE), `_encode_response` | test_N_000257_server_idle_may_send_final_response_without_a_request | tested |
| N-000264 | Keep-alive enabled only for HTTP/1.1 with no `close` token | `_apply`, `_fire` | test_N_000262_close_token_matched_as_whole_element_only | tested |
| N-000271–N-000274 | Next cycle starts when both DONE; client may not pipeline | `start_next_cycle`, `_plan` | test_N_000270…, test_N_000274_client_pipelining_refused | tested |
| N-000276–N-000278 | Server handles pipelined requests one cycle at a time; PAUSED while peer DONE | `_next_event` | test_N_000275_server_pauses_pipelined_requests_until_next_cycle | tested |
| N-000280–N-000281 | Refused start-next-cycle changes nothing and is recoverable | `start_next_cycle` | test_N_000280…, test_N_000281… | tested |
| N-000286–N-000289 | HTTP/1.0 cannot be kept alive; paused is not need-data | `_apply`, `_next_event` | test_N_000286_http10_peer_cannot_be_kept_alive, test_N_000275… | tested |
| N-000293–N-000295 | Protocol error classes; default 400; 501 and 431 exceptions | `_errors.py`, `_events`, `_wire` | test_N_000292_…, test_N_000120_…, test_N_000121_… | tested |
| N-000297–N-000301 | Construction and start-next-cycle refusals are recoverable local errors | `_events`, `start_next_cycle` | test_N_000466_…, test_N_000281_… | tested |
| N-000314 | send_failed produces no bytes and puts our side in ERROR | `Connection.send_failed` | test_N_000312_send_failed_puts_our_side_in_error_and_leaves_peer_alone | tested |
| N-000317–N-000322 | Incomplete-event size limit, 431, whole line plus headers counted, body exempt | `_pull_head`, `_pull_chunked` (trailers), default 16 KiB (CF-000048) | test_N_000316_…, test_N_000317_default_limit_boundary_is_16_kib | tested |
| N-000324–N-000325 | Close mid-message is remote error; close-delimited body ends on empty feed | `_pull_body`, `_pull_head` | test_N_000324_truncated_content_length_body_is_remote_error, test_N_000208_… | tested |
| N-000327–N-000335 | ERROR cannot be left; send after remote error still works; DONE beside ERROR becomes MUST_CLOSE; close rules | `_fire`, `_next_event`, `next_event` error path | test_N_000305_…, test_N_000311_…, test_N_000328_… | tested |
| N-000337, N-000340 | CLOSED makes other IDLE/DONE side MUST_CLOSE; empty feed yields connection-closed | `_fire`, `_pull_close` | test_N_000334_…, test_N_000339_… | tested |
| N-000342–N-000347 | Pipelined requests before half-close; close states; close not allowed mid-message is error | `_next_event`, `_plan` | test_N_000345_…, test_N_000347_… | tested |
| N-000349–N-000353 | Informational responses before final; client still sends body | `_SENDER_TRANSITIONS`, `_apply` | test_N_000349_informational_responses_then_final | tested |
| N-000355–N-000356 | 100-continue flags on both roles; not set for HTTP/1.0 | `_apply` | test_N_000354_…, test_N_000357_… | tested |
| N-000361–N-000363 | Switch proposal pattern: accept or deny; accept gives SWITCHED | `_apply`, `_encode_response` | test_N_000364_…, test_N_000378_… | tested |
| N-000365–N-000371 | CONNECT accepted by 2xx; Upgrade by 101; other informational neither | `_accepts_switch`, `_apply` | test_N_000364_…, test_N_000366_…, test_N_000367_… | tested |
| N-000374–N-000376 | Client in MIGHT_SWITCH after proposing request; server pulls PAUSED | `_apply`, `_next_event` | test_N_000364_connect_accepted_by_2xx_switches_both_sides | tested |
| N-000379 | Bytes after a denied proposal parse as the next cycle's request | `_apply`, `start_next_cycle` | test_N_000378_denied_switch_returns_to_http_after_next_cycle | tested |
| N-000383 | After acceptance pulls stay PAUSED forever | `_next_event` | test_N_000388_trailing_data_after_accept_is_stored_and_close_stays_paused | tested |
| N-000388–N-000412 | Trailing data pair; client cannot send while MIGHT; 101 vs 2xx; accept permanence; cycle start refusal during proposal; distinguishable paused states | `Connection.trailing_data`, `_plan`, `_apply`, `_next_event`, `start_next_cycle` | test_N_000388…, test_N_000392_…, test_N_000394_… | tested |
| N-000413–N-000432 | Hardware: pure Python, no compiled code, zero runtime deps, Python 3.8+, flat layout; interface overview: importable library, no CLI, no config file, no exit codes | `pyproject.toml` (`dependencies = []`, `requires-python >=3.8`, `packages = ["httpwire"]`), `httpwire/__init__.py` | syntax checked with ast feature_version=(3,8) | implemented (by design; platforms other than Linux not run here) |
| N-000434–N-000437 | Six event classes, constructible by calling them; `Connection` class | `httpwire/__init__.py`, `_events.py` | test_N_000070_six_distinct_event_kinds | tested |
| N-000446–N-000448 | LocalProtocolError and RemoteProtocolError, siblings, not subclasses of each other | `_errors.py` | test_N_000326_local_and_remote_errors_are_distinct_types | tested |
| N-000450–N-000456 | Keyword constructors, field readability, field types, byte-valued arguments accept ASCII str or bytes-like | `_events.py` | test_N_000072_…, test_N_000085_…, test_N_000463_… | tested |
| N-000460–N-000462 | status_code accepts integer-valued int subclass; headers as pairs; Content-Length digit cap | `_events.py` (`_check_status`, `_normalize_headers`) | test_N_000079_…, test_N_000116_… | tested |
| N-000466 | Invalid construction raises LocalProtocolError and returns no event | `_events.py` | test_N_000466_… | tested |
| N-000486–N-000501 | Connection attributes and send/receive/next-event methods and their return forms | `_connection.py` (`Connection` properties and methods) | test_N_000123_…, test_N_000128_…, test_N_000145_… | tested |
| N-000517–N-000522 | start_next_cycle returns None on success, refuses with LocalProtocolError; send_failed returns None | `_connection.py` | test_N_000270_…, test_N_000280_…, test_N_000312_… | tested |
