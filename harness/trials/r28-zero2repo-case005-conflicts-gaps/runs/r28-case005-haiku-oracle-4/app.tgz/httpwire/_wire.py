"""Line-level parsing of received HTTP/1.1 bytes.

Lines may end with CRLF or a lone LF (a leniency the PRD states for received
header blocks; see NOTES.md, CF-000074). A malformed line raises
RemoteProtocolError; the caller turns that into the receive-side ERROR state.
"""

import re

from ._errors import RemoteProtocolError

# spec: N-000110 N-000111 N-000112 N-000113 — request/status grammar pieces.
_TOKEN = re.compile(rb"[!#$%&'*+\-.^_`|~0-9A-Za-z]+")
_TARGET = re.compile(rb"[\x21-\x7e]+")
_STATUS_CODE = re.compile(rb"[0-9]{3}")
# spec: N-000228 N-000229 N-000230 — chunk-size: 1..32 hex digits, optional ";ext",
# optional trailing spaces/tabs (see NOTES.md, CF-000099 and CF-000101).
CHUNK_SIZE_LINE = re.compile(rb"([0-9A-Fa-f]{1,32})(?:;[\x20-\x7e\x80-\xff\t]*)?[ \t]*")
MAX_CHUNK_SIZE_DIGITS = 32


def _fail(message, hint=400):
    raise RemoteProtocolError(message, hint)


def split_head(buf):
    """Return (lines, consumed) when `buf` holds a complete head, else None.

    `lines` excludes the terminating blank line. Works for request/status
    lines plus header blocks, and for chunked trailers.
    """
    lines = []
    pos = 0
    while True:
        idx = buf.find(b"\n", pos)
        if idx < 0:
            return None
        line = bytes(buf[pos:idx])
        if line.endswith(b"\r"):
            line = line[:-1]
        pos = idx + 1
        if not line:
            return lines, pos
        lines.append(line)


def parse_request_line(line):
    """Return (method, target, version_without_prefix)."""
    parts = line.split(b" ")
    if len(parts) != 3:
        _fail("malformed request line")
    method, target, version = parts
    if not _TOKEN.fullmatch(method):
        _fail("request method is not a token")
    if not _TARGET.fullmatch(target):
        _fail("request target must be visible ASCII")
    if version not in (b"HTTP/1.1", b"HTTP/1.0"):
        _fail("unsupported HTTP version in request line")
    return method, target, version[5:]


def parse_status_line(line):
    """Return (status, version_without_prefix, reason).

    A status line with no reason phrase is accepted and the reason is empty
    (N-000166; see NOTES.md, CF-000005).
    """
    parts = line.split(b" ", 2)
    if len(parts) < 2:
        _fail("malformed status line")
    version, code = parts[0], parts[1]
    reason = parts[2] if len(parts) == 3 else b""
    if version not in (b"HTTP/1.1", b"HTTP/1.0"):
        _fail("unsupported HTTP version in status line")
    if not _STATUS_CODE.fullmatch(code):
        _fail("status code must be three digits")
    status = int(code)
    if status < 100:
        _fail("status code out of range")
    for c in reason:
        if (c < 0x20 and c != 0x09) or c == 0x7F:
            _fail("reason phrase contains a control byte")
    return status, version[5:], reason


def parse_header_lines(lines):
    """Return a list of (name, value) pairs from header lines.

    Obsolete line folding is joined to the previous value with a single space
    (N-000167..N-000169; see NOTES.md, CF-000075/76/100). Values have
    surrounding spaces and tabs stripped (the RFC 7230 OWS grammar).
    """
    out = []
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            if not out:
                _fail("obsolete line folding with no preceding header")
            cont = line.strip(b" \t")
            if cont:
                name, prev = out[-1]
                prev = prev.rstrip(b" \t")
                out[-1] = (name, prev + b" " + cont if prev else cont)
            continue
        name, sep, value = line.partition(b":")
        if not sep:
            _fail("header line has no colon")
        if not _TOKEN.fullmatch(name):
            _fail("header name is not a token")
        out.append((name, value.strip(b" \t")))
    return out


def parse_chunk_size(line):
    """Return the chunk size for one chunk-size line (without its line ending)."""
    m = CHUNK_SIZE_LINE.fullmatch(line)
    if m is None:
        _fail("malformed chunk-size line")
    return int(m.group(1), 16)


def hex_run_length(buf):
    """Count leading hex digits in a bytes-like buffer."""
    n = 0
    for c in buf:
        if chr(c) in "0123456789abcdefABCDEF":
            n += 1
        else:
            break
    return n
