"""Exception classes for httpwire.

# spec: N-000290 N-000291 N-000326 N-000472 N-000473 N-000474 N-000475
"""


class ProtocolError(Exception):
    """Common base for the two protocol-error kinds (not itself raised)."""

    def __init__(self, message="", error_status_hint=400):
        super().__init__(message)
        # spec: N-000292 N-000296 N-000472 — suggested status, always an int.
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(ProtocolError):
    """The integrator's own event or send violated HTTP/1.1.

    # spec: N-000290 N-000326 — distinct from RemoteProtocolError.
    """


class RemoteProtocolError(ProtocolError):
    """The peer's bytes violated HTTP/1.1.

    # spec: N-000291 N-000326 — distinct from LocalProtocolError.
    """


class ReceiveClosedError(RuntimeError):
    """Non-empty bytes were fed after the receive side was closed.

    # spec: N-000474 N-000348 N-000291 — a runtime error, neither protocol kind.
    """
