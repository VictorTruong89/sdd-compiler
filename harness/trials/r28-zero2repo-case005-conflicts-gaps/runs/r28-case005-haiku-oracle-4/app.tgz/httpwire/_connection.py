"""The sans-IO Connection object: encodes events to bytes, parses bytes to events.

Each Connection tracks both sides' states. A side moves only on its own sends,
on events pulled from the peer, and on the state-triggered rules (keep-alive,
CLOSED, ERROR). Nothing here touches a socket.
"""

from ._constants import (
    CLIENT,
    SERVER,
    ROLES,
    NEED_DATA,
    PAUSED,
    IDLE,
    SEND_RESPONSE,
    SEND_BODY,
    DONE,
    MUST_CLOSE,
    CLOSED,
    MIGHT_SWITCH_PROTOCOL,
    SWITCHED_PROTOCOL,
    ERROR,
    DEFAULT_MAX_INCOMPLETE_EVENT_SIZE,
)
from ._errors import LocalProtocolError, RemoteProtocolError, ReceiveClosedError
from ._events import (
    Request,
    InformationalResponse,
    Response,
    Data,
    EndOfMessage,
    ConnectionClosed,
    EVENT_TYPES,
)
from . import _wire

# spec: N-000259 N-000260 N-000261 N-000262 N-000263 — keep-alive enablement.


class _Illegal(Exception):
    """An event is not allowed in the sender's current state."""


# Body framing kinds.
_NONE, _LENGTH, _CHUNKED, _CLOSE = range(4)
# Chunked-body sub-states.
_CH_SIZE, _CH_DATA, _CH_CRLF, _CH_TRAILERS = range(4)


class _Framing:
    """How the body of the current message is delimited, on one side."""

    __slots__ = ("kind", "remaining", "chunk", "chunk_remaining", "chunk_first")

    def __init__(self, kind, remaining=0):
        self.kind = kind
        self.remaining = remaining
        self.chunk = _CH_SIZE
        self.chunk_remaining = 0
        self.chunk_first = True


# spec: N-000483 N-000484 N-000485 — sender-side transition table (role -> state -> event).
# spec: N-000283 N-000284 N-000285 — event kinds a role may send in each state.
_SENDER_TRANSITIONS = {
    CLIENT: {
        IDLE: {Request: SEND_BODY, ConnectionClosed: CLOSED},
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
    },
    SERVER: {
        # spec: N-000255 N-000256 — a server in IDLE may send a final response.
        IDLE: {Response: SEND_BODY, ConnectionClosed: CLOSED},
        SEND_RESPONSE: {InformationalResponse: SEND_RESPONSE, Response: SEND_BODY},
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
    },
}

_ROLE_NAMES = {CLIENT: "client", SERVER: "server"}


def _other(role):
    return SERVER if role is CLIENT else CLIENT


def _find(items, lower):
    for item in items:
        if item[1] == lower:
            return item
    return None


def _has_token(items, name, token):
    """True when a header named `name` has `token` as a whole comma-separated element."""
    # spec: N-000262 — whole-element, case-insensitive match.
    for _, lower, value in items:
        if lower == name:
            for piece in value.split(b","):
                if piece.strip(b" \t").lower() == token:
                    return True
    return False


def _strip(items, names):
    return [it for it in items if it[1] not in names]


def _format_headers(items):
    return [raw + b": " + value + b"\r\n" for raw, _, value in items]


def _with_connection_close(items):
    """Drop keep-alive tokens and make sure `close` is present in Connection."""
    # spec: N-000265 N-000266 N-000267 N-000268 — add Connection: close, drop keep-alive.
    kept = []
    tokens = []
    for item in items:
        if item[1] == b"connection":
            for piece in item[2].split(b","):
                tok = piece.strip(b" \t")
                if not tok or tok.lower() in (b"keep-alive", b"close"):
                    continue
                tokens.append(tok)
        else:
            kept.append(item)
    tokens.append(b"close")
    kept.append((b"Connection", b"connection", b", ".join(tokens)))
    return kept


def _build(factory, *args):
    """Construct a received event; construction refusals become remote errors."""
    try:
        return factory(*args)
    except LocalProtocolError as exc:
        raise RemoteProtocolError(str(exc), exc.error_status_hint) from None


class Connection:
    """One HTTP/1.1 connection in the CLIENT or SERVER role.

    # spec: N-000476 N-000477 N-000478 N-000479 N-000480 N-000481 N-000482
    """

    def __init__(self, our_role, max_incomplete_event_size=None):
        if our_role is CLIENT:
            self._our_role = CLIENT
        elif our_role is SERVER:
            self._our_role = SERVER
        else:
            raise LocalProtocolError("role must be CLIENT or SERVER", 400)
        self._their_role = _other(self._our_role)

        if max_incomplete_event_size is None:
            max_incomplete_event_size = DEFAULT_MAX_INCOMPLETE_EVENT_SIZE
        if isinstance(max_incomplete_event_size, bool) or not isinstance(
            max_incomplete_event_size, int
        ):
            raise LocalProtocolError("max_incomplete_event_size must be an int", 400)
        if max_incomplete_event_size < 0:
            raise LocalProtocolError("max_incomplete_event_size must not be negative", 400)
        self._max_size = int(max_incomplete_event_size)

        # spec: N-000123 — both sides start in IDLE.
        self._state = {CLIENT: IDLE, SERVER: IDLE}
        self._keep_alive = True
        self._proposals = set()  # pending switch proposals: "connect", "upgrade"
        self._method = None  # request method of the current cycle
        self._their_version = None  # peer HTTP version as bytes, once recorded
        self._client_waiting = False
        self._they_waiting = False
        self._buf = bytearray()  # fed but unparsed bytes
        self._closed = False  # receive side closed (an empty chunk was fed)
        self._our_body = _Framing(_NONE)
        self._their_body = _Framing(_NONE)

    # ----- queryable attributes -------------------------------------------

    @property
    def our_role(self):
        return self._our_role

    @property
    def their_role(self):
        return self._their_role

    @property
    def our_state(self):
        return self._state[self._our_role]

    @property
    def their_state(self):
        return self._state[self._their_role]

    @property
    def states(self):
        # spec: N-000126 — our state, their state and the pair always agree.
        return {CLIENT: self._state[CLIENT], SERVER: self._state[SERVER]}

    @property
    def their_http_version(self):
        return self._their_version

    @property
    def client_is_waiting_for_100_continue(self):
        return self._client_waiting

    @property
    def they_are_waiting_for_100_continue(self):
        return self._they_waiting

    @property
    def trailing_data(self):
        return (bytes(self._buf), self._closed)

    # ----- sending ----------------------------------------------------------

    def send(self, event):
        """Encode one event to bytes. Returns bytes, or None when no bytes result."""
        pieces = self._send(event, passthrough=False)
        if not pieces:
            return None
        return b"".join(pieces)

    def send_with_data_passthrough(self, event):
        """Like send(), but returns a list of pieces; a non-bytes Data payload is kept by identity."""
        # spec: N-000502 N-000503 N-000504 N-000505 N-000506
        return list(self._send(event, passthrough=True))

    def _send(self, event, passthrough):
        if not isinstance(event, EVENT_TYPES):
            raise LocalProtocolError("send() takes an httpwire event", 400)
        our = self._our_role
        try:
            self._plan(our, event)
            pieces = self._encode(event, passthrough)
            self._apply(our, event)
        except _Illegal as exc:
            self._fail_our_side()
            raise LocalProtocolError(str(exc), 400) from None
        except LocalProtocolError:
            # spec: N-000307 N-000308 N-000309 N-000310 — a refused send is unrecoverable for sending.
            self._fail_our_side()
            raise
        return pieces

    def _fail_our_side(self):
        self._state[self._our_role] = ERROR
        self._fire()

    def _encode(self, event, passthrough):
        t = type(event)
        if t is Request:
            return self._encode_request(event)
        if t is InformationalResponse:
            return self._encode_informational(event)
        if t is Response:
            return self._encode_response(event)
        if t is Data:
            return self._encode_data(event, passthrough)
        if t is EndOfMessage:
            return self._encode_end(event)
        return []  # connection-closed produces no bytes

    def _encode_request(self, ev):
        # spec: N-000128 N-000129 N-000130 N-000131 N-000161 N-000162 N-000163 N-000164
        if ev.http_version != b"1.1":
            raise LocalProtocolError("only HTTP/1.1 requests can be sent", 400)
        items = list(ev.headers._items)
        host = [it for it in items if it[1] == b"host"]
        items = host + [it for it in items if it[1] != b"host"]
        cl = _find(items, b"content-length")
        if cl is not None:
            # spec: N-000188 N-000189 — Content-Length decides when both framing headers are present.
            items = _strip(items, (b"transfer-encoding",))
            self._our_body = _Framing(_LENGTH, int(cl[2]))
        elif _find(items, b"transfer-encoding") is not None:
            self._our_body = _Framing(_CHUNKED)
        else:
            self._our_body = _Framing(_NONE)
        lines = [b"%s %s HTTP/1.1\r\n" % (ev.method, ev.target)]
        lines += _format_headers(items)
        lines.append(b"\r\n")
        return lines

    def _encode_informational(self, ev):
        # spec: N-000136 N-000137 — informational response line, headers, blank line.
        if ev.http_version != b"1.1":
            raise LocalProtocolError("only HTTP/1.1 responses can be sent", 400)
        self._our_body = _Framing(_NONE)
        lines = [b"HTTP/1.1 %03d %s\r\n" % (ev.status_code, ev.reason)]
        lines += _format_headers(ev.headers._items)
        lines.append(b"\r\n")
        return lines

    def _accepts_switch(self, ev):
        # spec: N-000364..N-000372 — which response accepts which proposal.
        if type(ev) is InformationalResponse:
            return ev.status_code == 101 and "upgrade" in self._proposals
        if type(ev) is Response:
            return 200 <= ev.status_code < 300 and "connect" in self._proposals
        return False

    def _encode_response(self, ev):
        # spec: N-000136 N-000137 N-000198..N-000219 — response framing from headers, method, peer version.
        if ev.http_version != b"1.1":
            raise LocalProtocolError("only HTTP/1.1 responses can be sent", 400)
        status = ev.status_code
        items = list(ev.headers._items)
        if self._accepts_switch(ev):
            # spec: N-000381 N-000382 — the accepting response has no body and no framing.
            self._our_body = _Framing(_NONE)
            lines = [b"HTTP/1.1 %03d %s\r\n" % (status, ev.reason)]
            lines += _format_headers(items)
            lines.append(b"\r\n")
            return lines

        peer_11 = self._their_version == b"1.1"
        close = False
        remaining = 0
        if status in (204, 304):
            # spec: N-000215 N-000216 N-000217 N-000218 — always an empty body, no framing headers.
            items = _strip(items, (b"content-length", b"transfer-encoding"))
            kind = _NONE
        else:
            if _find(items, b"transfer-encoding") is not None:
                # spec: N-000207 — transfer-encoding wins over Content-Length on responses.
                if peer_11:
                    items = _strip(items, (b"content-length",))
                    kind = _CHUNKED
                else:
                    items = _strip(items, (b"content-length", b"transfer-encoding"))
                    kind = _CLOSE
                    close = True
            elif _find(items, b"content-length") is not None:
                kind = _LENGTH
                remaining = int(_find(items, b"content-length")[2])
            elif peer_11:
                # spec: N-000202 — HTTP/1.1 peer: chunked.
                items.append((b"Transfer-Encoding", b"transfer-encoding", b"chunked"))
                kind = _CHUNKED
            else:
                # spec: N-000203 N-000204 N-000205 N-000206 — HTTP/1.0 or unknown peer: close-delimited.
                kind = _CLOSE
                close = True
            if self._method == b"HEAD":
                # spec: N-000215 N-000219 — HEAD gets GET's framing headers but an empty body.
                kind = _NONE
        if close:
            # spec: N-000269 — close-delimited responses disable keep-alive.
            self._keep_alive = False
        if close or not self._keep_alive:
            # spec: N-000265 N-000266 — keep-alive off means Connection: close on the response.
            items = _with_connection_close(items)
            self._keep_alive = False
        self._our_body = _Framing(kind, remaining)
        lines = [b"HTTP/1.1 %03d %s\r\n" % (status, ev.reason)]
        lines += _format_headers(items)
        lines.append(b"\r\n")
        return lines

    def _encode_data(self, ev, passthrough):
        # spec: N-000233..N-000237 — passthrough keeps non-bytes payloads by identity.
        obj = ev.data
        if isinstance(obj, str):
            raise LocalProtocolError("Data payload must be bytes-like", 400)
        bytes_like = isinstance(obj, (bytes, bytearray, memoryview))
        if not bytes_like and not passthrough:
            raise LocalProtocolError("send() needs bytes-like Data; use send_with_data_passthrough", 400)
        if bytes_like:
            n = memoryview(obj).nbytes
            piece = obj if isinstance(obj, bytes) else bytes(obj)
        else:
            try:
                n = len(obj)
            except TypeError:
                raise LocalProtocolError("Data payload has no length", 400) from None
            piece = obj
        mode = self._our_body
        if mode.kind == _LENGTH:
            # spec: N-000238 — data may not exceed the remaining Content-Length.
            if n > mode.remaining:
                raise LocalProtocolError("Data exceeds the declared Content-Length", 400)
            mode.remaining -= n
        elif mode.kind == _NONE:
            if n:
                raise LocalProtocolError("this message has an empty body", 400)
        elif mode.kind == _CHUNKED:
            # spec: N-000192 N-000193 — one chunk per non-empty data event; marks ignored.
            if n == 0:
                return []
            return [b"%x\r\n" % n, piece, b"\r\n"]
        if n == 0:
            return []
        return [piece]

    def _encode_end(self, ev):
        # spec: N-000194..N-000197 N-000238..N-000241 — end-of-message encoding and trailer rules.
        mode = self._our_body
        trailers = ev.headers._items
        if mode.kind == _LENGTH and mode.remaining:
            raise LocalProtocolError("end-of-message before the Content-Length was sent", 400)
        if trailers:
            if mode.kind != _CHUNKED:
                raise LocalProtocolError("trailing headers need chunked framing", 400)
            if self._their_version == b"1.0":
                raise LocalProtocolError("trailing headers cannot go to an HTTP/1.0 peer", 400)
            return [b"0\r\n"] + _format_headers(trailers) + [b"\r\n"]
        if mode.kind == _CHUNKED:
            return [b"0\r\n\r\n"]
        return []

    # ----- receiving --------------------------------------------------------

    def receive_data(self, data):
        """Store bytes from the peer. An empty chunk means the peer closed its sending side."""
        # spec: N-000507 N-000508 N-000509 N-000510 N-000511 — only stores bytes.
        if not isinstance(data, (bytes, bytearray, memoryview)):
            raise TypeError("receive_data() needs a bytes-like object")
        data = bytes(data)
        if not data:
            self._closed = True
            return None
        if self._closed:
            # spec: N-000180 N-000181 N-000182 — a runtime error, not a protocol error.
            raise ReceiveClosedError("bytes fed after the receive side was closed")
        self._buf += data
        return None

    def next_event(self):
        """Parse one event from stored bytes, or return NEED_DATA / PAUSED."""
        # spec: N-000512 N-000513 N-000514 N-000515 N-000516
        try:
            return self._next_event()
        except RemoteProtocolError:
            if self._state[self._their_role] is not ERROR:
                # spec: N-000302 N-000303 N-000304 N-000305 N-000306 — peer side goes to ERROR.
                self._state[self._their_role] = ERROR
                self._keep_alive = False
                self._fire()
            raise

    def _next_event(self):
        their = self._their_role
        st = self._state[their]
        if st is ERROR:
            raise RemoteProtocolError("the peer is in ERROR after a protocol violation", 400)
        if st is CLOSED:
            return ConnectionClosed()
        if st is SWITCHED_PROTOCOL or st is MIGHT_SWITCH_PROTOCOL:
            # spec: N-000384 N-000385 N-000386 — paused while a switch is pending or accepted.
            return PAUSED
        if st is DONE or st is MUST_CLOSE:
            # spec: N-000275..N-000279 — pipelined bytes wait for the next cycle.
            if self._buf:
                return PAUSED
            if self._closed:
                return self._pull_close()
            return NEED_DATA
        if st is SEND_BODY:
            return self._pull_body()
        return self._pull_head()

    def _apply_received(self, ev):
        try:
            self._apply(self._their_role, ev)
        except _Illegal as exc:
            raise RemoteProtocolError(str(exc), 400) from None

    def _pull_close(self):
        # spec: N-000339..N-000341 — pulling a connection-closed event.
        ev = ConnectionClosed()
        self._apply_received(ev)
        return ev

    def _pull_head(self):
        their = self._their_role
        st = self._state[their]
        buf = self._buf
        if not buf:
            if self._closed:
                if st is IDLE:
                    return self._pull_close()
                raise RemoteProtocolError("connection closed before the message was complete", 400)
            return NEED_DATA
        # spec: N-000177 N-000178 N-000179 — a space or control byte fails at once.
        if buf[0] == 0x20 or buf[0] < 0x21:
            raise RemoteProtocolError("malformed start line", 400)
        parsed = _wire.split_head(buf)
        if parsed is None:
            if self._closed:
                raise RemoteProtocolError("connection closed in the middle of a head", 400)
            # spec: N-000316..N-000323 — incomplete-event size limit, status 431.
            if len(buf) > self._max_size:
                raise RemoteProtocolError("incomplete event exceeds the size limit", 431)
            return NEED_DATA
        lines, consumed = parsed
        if their is CLIENT:
            ev = self._build_request(lines)
        else:
            ev = self._build_response(lines)
        framing = self._received_framing(ev)
        if self._accepts_switch(ev):
            # spec: N-000381 — an accepting response has no body and no end-of-message.
            framing = _Framing(_NONE)
        if framing.kind == _CLOSE:
            # spec: N-000208..N-000214 — close-delimited responses end the connection.
            self._keep_alive = False
        self._apply_received(ev)
        self._their_body = framing
        del buf[:consumed]
        return ev

    def _build_request(self, lines):
        method, target, version = _wire.parse_request_line(lines[0])
        headers = _wire.parse_header_lines(lines[1:])
        return _build(Request, method, target, headers, version)

    def _build_response(self, lines):
        status, version, reason = _wire.parse_status_line(lines[0])
        headers = _wire.parse_header_lines(lines[1:])
        if status < 200:
            return _build(InformationalResponse, status, headers, version, reason)
        return _build(Response, status, headers, version, reason)

    def _received_framing(self, ev):
        # spec: N-000185..N-000187 N-000198 N-000200..N-000214 — framing for a received message.
        items = ev.headers._items if type(ev) in (Request, Response) else ()
        if type(ev) is Request:
            if _find(items, b"content-length") is not None:
                return _Framing(_LENGTH, int(_find(items, b"content-length")[2]))
            if _find(items, b"transfer-encoding") is not None:
                return _Framing(_CHUNKED)
            return _Framing(_NONE)
        if type(ev) is Response:
            if self._method == b"HEAD" or ev.status_code in (204, 304):
                return _Framing(_NONE)
            if _find(items, b"transfer-encoding") is not None:
                return _Framing(_CHUNKED)
            if _find(items, b"content-length") is not None:
                return _Framing(_LENGTH, int(_find(items, b"content-length")[2]))
            return _Framing(_CLOSE)
        return _Framing(_NONE)

    def _pull_body(self):
        their = self._their_role
        fr = self._their_body
        buf = self._buf
        if fr.kind == _NONE:
            ev = EndOfMessage()
        elif fr.kind == _LENGTH:
            if fr.remaining == 0:
                ev = EndOfMessage()
            elif buf:
                n = min(fr.remaining, len(buf))
                ev = Data(bytes(buf[:n]))
                del buf[:n]
                fr.remaining -= n
            elif self._closed:
                raise RemoteProtocolError("connection closed in the middle of a Content-Length body", 400)
            else:
                return NEED_DATA
        elif fr.kind == _CLOSE:
            # spec: N-000208 N-000210 N-000211 — the empty feed ends a close-delimited body.
            if buf:
                ev = Data(bytes(buf))
                buf.clear()
            elif self._closed:
                ev = EndOfMessage()
            else:
                return NEED_DATA
        else:
            ev = self._pull_chunked(fr)
            if ev is None:
                return NEED_DATA
        self._apply_received(ev)
        if type(ev) is EndOfMessage:
            self._their_body = _Framing(_NONE)
        return ev

    def _pull_chunked(self, fr):
        """Return the next Data or EndOfMessage event of a chunked body, or None (need data)."""
        # spec: N-000220..N-000232 N-000242..N-000245 — chunk marks, size lines, CRLF.
        buf = self._buf
        while True:
            if fr.chunk == _CH_SIZE:
                idx = buf.find(b"\n")
                if idx < 0:
                    if _wire.hex_run_length(buf) > _wire.MAX_CHUNK_SIZE_DIGITS:
                        raise RemoteProtocolError("chunk-size line has too many digits", 400)
                    if self._closed:
                        raise RemoteProtocolError("connection closed in the middle of a chunked body", 400)
                    return None
                line = bytes(buf[:idx])
                if line.endswith(b"\r"):
                    line = line[:-1]
                size = _wire.parse_chunk_size(line)
                del buf[: idx + 1]
                if size == 0:
                    fr.chunk = _CH_TRAILERS
                else:
                    fr.chunk = _CH_DATA
                    fr.chunk_remaining = size
                    fr.chunk_first = True
            elif fr.chunk == _CH_DATA:
                if not buf:
                    if self._closed:
                        raise RemoteProtocolError("connection closed in the middle of a chunk", 400)
                    return None
                n = min(fr.chunk_remaining, len(buf))
                data = bytes(buf[:n])
                del buf[:n]
                fr.chunk_remaining -= n
                start = fr.chunk_first
                fr.chunk_first = False
                end = fr.chunk_remaining == 0
                if end:
                    fr.chunk = _CH_CRLF
                return Data(data, chunk_start=start, chunk_end=end)
            elif fr.chunk == _CH_CRLF:
                if len(buf) >= 2:
                    if bytes(buf[:2]) != b"\r\n":
                        raise RemoteProtocolError("chunk data is not followed by CRLF", 400)
                    del buf[:2]
                    fr.chunk = _CH_SIZE
                    continue
                if buf and buf[0] != 0x0D:
                    raise RemoteProtocolError("chunk data is not followed by CRLF", 400)
                if self._closed:
                    raise RemoteProtocolError("connection closed in the middle of a chunked body", 400)
                return None
            else:  # _CH_TRAILERS
                parsed = _wire.split_head(buf)
                if parsed is None:
                    if self._closed:
                        raise RemoteProtocolError("connection closed in the middle of trailers", 400)
                    if len(buf) > self._max_size:
                        raise RemoteProtocolError("incomplete event exceeds the size limit", 431)
                    return None
                lines, consumed = parsed
                trailers = _wire.parse_header_lines(lines)
                del buf[:consumed]
                return _build(EndOfMessage, trailers)

    # ----- cycles and failure -----------------------------------------------

    def start_next_cycle(self):
        """Return both sides to IDLE for another request/response. Refused unless both are DONE."""
        # spec: N-000270..N-000282 — refusal is recoverable and changes nothing.
        if self._state[CLIENT] is not DONE or self._state[SERVER] is not DONE:
            raise LocalProtocolError("the next cycle can start only when both sides are DONE", 400)
        self._state[CLIENT] = IDLE
        self._state[SERVER] = IDLE
        self._keep_alive = True
        self._proposals.clear()
        self._method = None
        self._client_waiting = False
        self._they_waiting = False
        self._our_body = _Framing(_NONE)
        self._their_body = _Framing(_NONE)
        return None

    def send_failed(self):
        """Record that the bytes of the last send were not transmitted. Produces no bytes."""
        # spec: N-000312..N-000315 — our side goes to ERROR.
        self._fail_our_side()
        return None

    # ----- internal state machinery -----------------------------------------

    def _plan(self, sender, ev):
        st = self._state[sender]
        row = _SENDER_TRANSITIONS[sender].get(st)
        nxt = row.get(type(ev)) if row is not None else None
        if nxt is None:
            raise _Illegal(
                "%s event is not allowed while the %s side is %s"
                % (type(ev).__name__, _ROLE_NAMES[sender], st)
            )
        return nxt

    def _apply(self, sender, ev):
        """Commit an event that has been encoded (send) or parsed (receive)."""
        t = type(ev)
        new = self._plan(sender, ev)
        st = self._state
        if t is EndOfMessage and sender is CLIENT and self._proposals:
            # spec: N-000373..N-000377 — the proposing request is finished; wait for the answer.
            new = MIGHT_SWITCH_PROTOCOL

        if self._accepts_switch(ev):
            # spec: N-000381..N-000387 — acceptance: both sides switch, permanently.
            self._proposals.clear()
            st[CLIENT] = SWITCHED_PROTOCOL
            st[SERVER] = SWITCHED_PROTOCOL
        else:
            if t is Response and self._proposals:
                # spec: N-000378..N-000380 — a final response that does not accept is a denial.
                self._proposals.clear()
                if st[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                    st[CLIENT] = DONE
            st[sender] = new

        if t is Request:
            if st[SERVER] is IDLE:
                st[SERVER] = SEND_RESPONSE  # spec: N-000250 — the server sees the request.
            self._method = ev.method
            # spec: N-000360..N-000372 — which switch proposals the request carries.
            if ev.method == b"CONNECT":
                self._proposals.add("connect")
            if _find(ev.headers._items, b"upgrade") is not None:
                self._proposals.add("upgrade")
            # spec: N-000354..N-000357 — Expect: 100-continue on HTTP/1.1 requests.
            if ev.http_version == b"1.1" and _has_token(ev.headers._items, b"expect", b"100-continue"):
                self._client_waiting = True
                if self._our_role is SERVER:
                    self._they_waiting = True

        if t in (Request, Response, InformationalResponse) and sender is self._their_role:
            self._their_version = ev.http_version

        if t in (Request, Response):
            # spec: N-000259 N-000260 N-000261 — keep-alive off for HTTP/1.0 or Connection: close.
            if ev.http_version != b"1.1" or _has_token(ev.headers._items, b"connection", b"close"):
                self._keep_alive = False

        if t in (InformationalResponse, Response):
            # spec: N-000358 — an informational or final response turns the wait off.
            self._client_waiting = False
            self._they_waiting = False
        if t in (Data, EndOfMessage) and sender is CLIENT:
            # spec: N-000359 — the client's body data or end-of-message turns the wait off.
            self._client_waiting = False
            self._they_waiting = False

        self._fire()

    def _fire(self):
        """State-triggered transitions, applied until nothing changes."""
        st = self._state
        changed = True
        while changed:
            changed = False
            for role in ROLES:
                if st[role] is DONE and not self._keep_alive:
                    # spec: N-000263 — with keep-alive off, DONE becomes MUST_CLOSE.
                    st[role] = MUST_CLOSE
                    changed = True
            for role in ROLES:
                other = _other(role)
                if st[role] is CLOSED and st[other] in (IDLE, DONE):
                    # spec: N-000336..N-000338 — the other side must close too.
                    st[other] = MUST_CLOSE
                    changed = True
                if st[role] is ERROR and st[other] is DONE:
                    # spec: N-000311 N-000313 — DONE beside ERROR becomes MUST_CLOSE.
                    st[other] = MUST_CLOSE
                    changed = True
