"""Role values, state values, and the two non-event pull results.

# spec: N-000123 N-000124 N-000125 N-000438 N-000439 N-000440 N-000441 N-000442
# spec: N-000443 N-000444 N-000445
"""


class _Sentinel:
    """A named, unique, non-string singleton. Instances never compare equal to others."""

    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return self._name

    __str__ = __repr__


# spec: N-000438 N-000439 — two distinct role objects.
CLIENT = _Sentinel("CLIENT")
SERVER = _Sentinel("SERVER")

# spec: N-000440 N-000441 N-000442 — non-event pull results, not event instances.
NEED_DATA = _Sentinel("NEED_DATA")
PAUSED = _Sentinel("PAUSED")

# spec: N-000443 N-000444 N-000445 — the nine state values.
IDLE = _Sentinel("IDLE")
SEND_RESPONSE = _Sentinel("SEND_RESPONSE")
SEND_BODY = _Sentinel("SEND_BODY")
DONE = _Sentinel("DONE")
MUST_CLOSE = _Sentinel("MUST_CLOSE")
CLOSED = _Sentinel("CLOSED")
MIGHT_SWITCH_PROTOCOL = _Sentinel("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = _Sentinel("SWITCHED_PROTOCOL")
ERROR = _Sentinel("ERROR")

# spec: N-000172 — the only roles a connection accepts.
ROLES = (CLIENT, SERVER)

# spec: N-000478 N-000479 N-000480 — default incomplete-event size limit (bytes).
# Decision: 16 KiB; see NOTES.md (CF-000048).
DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 16 * 1024
