"""The six event types, the header list, and construction-time checks (FP-01).

Every refusal here raises LocalProtocolError and produces no event.
"""

import re

from ._errors import LocalProtocolError

# spec: N-000070 N-000071 — exactly six event kinds, each a distinct class.

_TOKEN = re.compile(rb"[!#$%&'*+\-.^_`|~0-9A-Za-z]+")  # RFC 7230 tchar+
_TARGET = re.compile(rb"[\x21-\x7e]+")  # visible ASCII (33..126)
_VERSION = re.compile(rb"[0-9]\.[0-9]")
_DIGITS = re.compile(rb"[0-9]+")

# spec: N-000113 N-000116 N-000117 — Content-Length digit cap. Chosen: 18
# (the PRD lets the implementer pick 18..32 and says values of at most 18
# digits are accepted). See NOTES.md (CF-000098).
MAX_CONTENT_LENGTH_DIGITS = 18


def _to_bytes(value, what):
    """Accept ASCII str or a bytes-like object; return a bytes object.

    # spec: N-000458 N-000459 — stored value is exactly `bytes`.
    """
    if isinstance(value, str):
        try:
            return value.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("%s must be ASCII text or bytes" % what, 400)
    if isinstance(value, (bytes, bytearray, memoryview)):
        return bytes(value)
    raise LocalProtocolError("%s must be ASCII text or a bytes-like object" % what, 400)


def _check_value(value):
    """Header value rule.

    # spec: N-000097 N-000098 N-000099 N-000100 N-000108 N-000109
    Decision (CF-000026): control bytes other than tab are refused, so NUL, CR,
    LF, FF, VT and DEL are refused too. Space/tab may only appear between
    other bytes, so a leading or trailing space or tab is refused, not stripped.
    """
    for c in value:
        if (c < 0x20 and c != 0x09) or c == 0x7F:
            raise LocalProtocolError("header value contains a control byte", 400)
    if value[:1] in (b" ", b"\t") or value[-1:] in (b" ", b"\t"):
        raise LocalProtocolError("header value begins or ends with space or tab", 400)


def _check_reason(reason):
    """Reason phrase: no control bytes other than tab (NUL, CR, LF included)."""
    for c in reason:
        if (c < 0x20 and c != 0x09) or c == 0x7F:
            raise LocalProtocolError("reason phrase contains a control byte", 400)


def _check_status(status, low, high):
    # spec: N-000112 N-000113 — range per kind; non-integers refused.
    if isinstance(status, bool) or not isinstance(status, int):
        raise LocalProtocolError("status must be an integer", 400)
    status = int(status)
    if not (low <= status < high):
        raise LocalProtocolError("status %d out of range" % status, 400)
    return status


def _check_version(version):
    # spec: N-000075 N-000076 — version is two digits separated by a dot.
    if not _VERSION.fullmatch(version):
        raise LocalProtocolError("HTTP version must look like 1.1", 400)
    return version


def _normalize_headers(pairs):
    """Build the stored header list: a tuple of (raw_name, lower_name, value).

    # spec: N-000087 N-000088 N-000089 N-000090 N-000091 N-000092 N-000093
    # spec: N-000094 N-000095 N-000096 N-000101 N-000104 N-000105 N-000106
    # spec: N-000107 N-000109 N-000114 N-000115 N-000116 N-000118 N-000119
    # spec: N-000120 N-000121
    """
    items = []
    if isinstance(pairs, Headers):
        pairs = pairs.raw_items()
    try:
        iterator = iter(pairs)
    except TypeError:
        raise LocalProtocolError("headers must be a sequence of (name, value) pairs", 400)
    for pair in iterator:
        try:
            name, value = pair
        except (TypeError, ValueError):
            raise LocalProtocolError("each header must be a (name, value) pair", 400)
        raw = _to_bytes(name, "header name")
        val = _to_bytes(value, "header value")
        if not _TOKEN.fullmatch(raw):
            raise LocalProtocolError("header name is not an RFC 7230 token", 400)
        _check_value(val)
        items.append((raw, raw.lower(), val))

    # Content-Length: all values (across headers and comma pieces) must agree.
    cl_positions = [i for i, it in enumerate(items) if it[1] == b"content-length"]
    if cl_positions:
        numbers = []
        for i in cl_positions:
            for piece in items[i][2].split(b","):
                digits = piece.strip(b" \t")
                if not _DIGITS.fullmatch(digits):
                    raise LocalProtocolError("Content-Length must be a decimal integer", 400)
                if len(digits) > MAX_CONTENT_LENGTH_DIGITS:
                    raise LocalProtocolError("Content-Length value is too long", 400)
                numbers.append(int(digits))
        if len(set(numbers)) != 1:
            raise LocalProtocolError("conflicting Content-Length values", 400)
        first = items[cl_positions[0]]
        collapsed = (first[0], b"content-length", str(numbers[0]).encode("ascii"))
        new_items = []
        for i, it in enumerate(items):
            if it[1] == b"content-length":
                if i == cl_positions[0]:
                    new_items.append(collapsed)
            else:
                new_items.append(it)
        items = new_items

    # Transfer-Encoding: only a single header whose value is exactly "chunked".
    te_positions = [i for i, it in enumerate(items) if it[1] == b"transfer-encoding"]
    if te_positions:
        if len(te_positions) > 1:
            raise LocalProtocolError("more than one Transfer-Encoding header", 501)
        i = te_positions[0]
        raw, _, val = items[i]
        if val.lower() != b"chunked":
            raise LocalProtocolError("only Transfer-Encoding: chunked is supported", 501)
        items[i] = (raw, b"transfer-encoding", b"chunked")

    return tuple(items)


def _check_host(items, version):
    # spec: N-000077 N-000078 N-000104 N-000105 — Host rules for requests.
    count = sum(1 for it in items if it[1] == b"host")
    if count > 1:
        raise LocalProtocolError("more than one Host header", 400)
    if version == b"1.1" and count != 1:
        raise LocalProtocolError("an HTTP/1.1 request needs exactly one Host header", 400)


class Headers:
    """Ordered header list.

    Iterating or indexing yields the ordinary view: (lowercase name, value) pairs.
    raw_items() yields (name as the caller spelled it, value) pairs.

    # spec: N-000467 N-000468 N-000469 N-000470 N-000471
    """

    __slots__ = ("_items",)

    def __init__(self, items=()):
        self._items = tuple(items)

    def __iter__(self):
        return iter([(lower, value) for _, lower, value in self._items])

    def __len__(self):
        return len(self._items)

    def __getitem__(self, index):
        view = [(lower, value) for _, lower, value in self._items]
        return view[index]

    def raw_items(self):
        # spec: N-000469 N-000470 N-000471 — caller spelling, same order, bytes pairs.
        return [(raw, value) for raw, _, value in self._items]

    def __eq__(self, other):
        try:
            return list(self) == [tuple(pair) for pair in other]
        except TypeError:
            return NotImplemented

    __hash__ = None

    def __repr__(self):
        return "Headers(%r)" % (self.raw_items(),)


class _Event:
    __slots__ = ()

    def __repr__(self):
        parts = ", ".join("%s=%r" % (name, getattr(self, name)) for name in self.__slots__)
        return "%s(%s)" % (type(self).__name__, parts)


class Request(_Event):
    """Start of an HTTP request. # spec: N-000072 N-000073 N-000074 N-000110 N-000111

    Fields: method (bytes), target (bytes), headers (Headers), http_version (bytes).
    """

    __slots__ = ("method", "target", "headers", "http_version")

    def __init__(self, method, target, headers=(), http_version=b"1.1"):
        method = _to_bytes(method, "method")
        if not _TOKEN.fullmatch(method):
            raise LocalProtocolError("method must be a single RFC 7230 token", 400)
        target = _to_bytes(target, "target")
        if not _TARGET.fullmatch(target):
            raise LocalProtocolError("target must be visible ASCII", 400)
        version = _check_version(_to_bytes(http_version, "http_version"))
        items = _normalize_headers(headers)
        _check_host(items, version)
        self.method = method
        self.target = target
        self.headers = Headers(items)
        self.http_version = version


class InformationalResponse(_Event):
    """1xx response. # spec: N-000079 N-000080 N-000081 N-000082 N-000083

    Fields: status_code (int), headers, http_version (bytes), reason (bytes).
    """

    __slots__ = ("status_code", "headers", "http_version", "reason")

    def __init__(self, status_code, headers=(), http_version=b"1.1", reason=b""):
        status = _check_status(status_code, 100, 200)
        version = _check_version(_to_bytes(http_version, "http_version"))
        reason = _to_bytes(reason, "reason")
        _check_reason(reason)
        self.status_code = status
        self.headers = Headers(_normalize_headers(headers))
        self.http_version = version
        self.reason = reason


class Response(_Event):
    """Final response. # spec: N-000079 N-000080 N-000081 N-000082 N-000083

    Fields: status_code (int), headers, http_version (bytes), reason (bytes).
    """

    __slots__ = ("status_code", "headers", "http_version", "reason")

    def __init__(self, status_code, headers=(), http_version=b"1.1", reason=b""):
        status = _check_status(status_code, 200, 1000)
        version = _check_version(_to_bytes(http_version, "http_version"))
        reason = _to_bytes(reason, "reason")
        _check_reason(reason)
        self.status_code = status
        self.headers = Headers(_normalize_headers(headers))
        self.http_version = version
        self.reason = reason


class Data(_Event):
    """A piece of a message body. # spec: N-000084 N-000463 N-000464 N-000465

    `data` is stored exactly as given. chunk_start / chunk_end are exact bools.
    """

    __slots__ = ("data", "chunk_start", "chunk_end")

    def __init__(self, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)


class EndOfMessage(_Event):
    """End of a request or response, with optional trailing headers.

    # spec: N-000085 N-000086
    """

    __slots__ = ("headers",)

    def __init__(self, headers=()):
        self.headers = Headers(_normalize_headers(headers))


class ConnectionClosed(_Event):
    """This party will send no more HTTP data. # spec: N-000086 N-000457 — no fields."""

    __slots__ = ()

    def __init__(self):
        pass


EVENT_TYPES = (Request, InformationalResponse, Response, Data, EndOfMessage, ConnectionClosed)
