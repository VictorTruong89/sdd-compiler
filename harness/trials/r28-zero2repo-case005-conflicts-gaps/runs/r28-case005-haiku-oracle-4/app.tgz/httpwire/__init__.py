"""httpwire: a pure-Python, bring-your-own-I/O HTTP/1.1 wire protocol library.

The package never opens sockets. Feed it bytes, pull events out; send events,
write the bytes it returns.

# spec: N-000433 N-000449 — every published entry is importable from the root.
"""

from ._constants import (
    CLIENT,
    SERVER,
    NEED_DATA,
    PAUSED,
    IDLE,
    SEND_RESPONSE,
    SEND_BODY,
    DONE,
    MUST_CLOSE,
    CLOSED,
    MIGHT_SWITCH_PROTOCOL,
    SWITCHED_PROTOCOL,
    ERROR,
)
from ._errors import LocalProtocolError, RemoteProtocolError
from ._events import (
    Request,
    InformationalResponse,
    Response,
    Data,
    EndOfMessage,
    ConnectionClosed,
)
from ._connection import Connection

__all__ = [
    "CLIENT",
    "CLOSED",
    "Connection",
    "ConnectionClosed",
    "Data",
    "DONE",
    "EndOfMessage",
    "ERROR",
    "IDLE",
    "InformationalResponse",
    "LocalProtocolError",
    "MIGHT_SWITCH_PROTOCOL",
    "MUST_CLOSE",
    "NEED_DATA",
    "PAUSED",
    "RemoteProtocolError",
    "Request",
    "Response",
    "SEND_BODY",
    "SEND_RESPONSE",
    "SERVER",
    "SWITCHED_PROTOCOL",
]
