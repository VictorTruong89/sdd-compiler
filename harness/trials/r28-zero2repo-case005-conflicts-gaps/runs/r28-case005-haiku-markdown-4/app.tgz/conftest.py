# Empty on purpose: its presence makes pytest put the repository root on
# sys.path, so `import httpwire` works from /app without an install step.
