"""Behavioural tests for httpwire, written from the PRD and Interface Contract."""

import pytest

import httpwire
from httpwire import (
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
    Connection,
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    LocalProtocolError,
    RemoteProtocolError,
    Request,
    Response,
)


def get_request(**kw):
    headers = kw.pop("headers", [("Host", "example.com")])
    return Request(method=kw.pop("method", "GET"), target=kw.pop("target", "/"), headers=headers, **kw)


def pair_client_server():
    return Connection(CLIENT), Connection(SERVER)


def deliver(conn, data):
    conn.receive_data(data)


# ----------------------------------------------------------------------
# Package surface
# ----------------------------------------------------------------------

def test_package_root_names_exist():
    for name in httpwire.__all__:
        assert hasattr(httpwire, name)


def test_roles_and_states_are_distinct():
    states = [IDLE, SEND_RESPONSE, SEND_BODY, DONE, MUST_CLOSE, CLOSED,
              MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL, ERROR]
    assert len({id(s) for s in states}) == 9
    assert CLIENT is not SERVER
    assert NEED_DATA is not PAUSED


def test_protocol_errors_are_siblings():
    assert not issubclass(LocalProtocolError, RemoteProtocolError)
    assert not issubclass(RemoteProtocolError, LocalProtocolError)
    assert LocalProtocolError("x").error_status_hint == 400


def test_bad_role_refused():
    with pytest.raises(Exception):
        Connection("client")


# ----------------------------------------------------------------------
# FP-01 events
# ----------------------------------------------------------------------

def test_request_defaults_and_bytes_storage():
    req = get_request()
    assert req.method == b"GET"
    assert req.target == b"/"
    assert req.http_version == b"1.1"
    assert list(req.headers) == [(b"host", b"example.com")]
    assert req.headers.raw_items() == [(b"Host", b"example.com")]


def test_http11_request_needs_exactly_one_host():
    with pytest.raises(LocalProtocolError):
        Request(method="GET", target="/", headers=[])
    with pytest.raises(LocalProtocolError):
        Request(method="GET", target="/", headers=[("Host", "a"), ("host", "b")])
    with pytest.raises(LocalProtocolError):
        Request(method="GET", target="/", headers=[("HOST", "a"), ("Host", "b")], http_version="1.0")
    Request(method="GET", target="/", headers=[], http_version="1.0")


def test_header_rules_refused():
    host = ("Host", "x")
    for bad in [("Bad Name", "v"), ("X", " lead"), ("X", "trail "), ("X", "a\x01b"),
                ("X", "a\x7fb"), ("X", "a\rb"), ("X", "a\nb"), ("X\x00", "v")]:
        with pytest.raises(LocalProtocolError):
            Request(method="GET", target="/", headers=[host, bad])


def test_nonascii_header_value_allowed():
    req = get_request(headers=[("Host", "x"), ("X-Raw", b"\xe9\xff")])
    assert (b"x-raw", b"\xe9\xff") in list(req.headers)


def test_target_and_method_validation():
    with pytest.raises(LocalProtocolError):
        Request(method="GE T", target="/", headers=[("Host", "x")])
    with pytest.raises(LocalProtocolError):
        Request(method="GET", target="/a b", headers=[("Host", "x")])


def test_status_ranges():
    InformationalResponse(status_code=100, headers=[])
    InformationalResponse(status_code=199, headers=[])
    with pytest.raises(LocalProtocolError):
        InformationalResponse(status_code=200, headers=[])
    Response(status_code=200, headers=[])
    Response(status_code=999, headers=[])
    with pytest.raises(LocalProtocolError):
        Response(status_code=1000, headers=[])
    with pytest.raises(LocalProtocolError):
        Response(status_code="200", headers=[])


def test_reason_defaults_empty_and_is_bytes():
    r = Response(status_code=200, headers=[], reason="OK")
    assert r.reason == b"OK" and r.http_version == b"1.1"
    assert Response(status_code=200, headers=[]).reason == b""


def test_content_length_collapses_and_conflicts():
    e = EndOfMessage(headers=[("Content-Length", "5"), ("content-length", "5")])
    assert list(e.headers) == [(b"content-length", b"5")]
    e = EndOfMessage(headers=[("Content-Length", "5, 5")])
    assert list(e.headers) == [(b"content-length", b"5")]
    with pytest.raises(LocalProtocolError):
        EndOfMessage(headers=[("Content-Length", "5"), ("Content-Length", "6")])
    with pytest.raises(LocalProtocolError):
        EndOfMessage(headers=[("Content-Length", "+5")])
    with pytest.raises(LocalProtocolError):
        EndOfMessage(headers=[("Content-Length", "1" * 19)])
    EndOfMessage(headers=[("Content-Length", "1" * 18)])


def test_transfer_encoding_rules():
    e = EndOfMessage(headers=[("Transfer-Encoding", "ChUnKeD")])
    assert list(e.headers) == [(b"transfer-encoding", b"chunked")]
    for bad in ([("Transfer-Encoding", "gzip")], [("Transfer-Encoding", "chunked, gzip")],
                [("Transfer-Encoding", "chunked"), ("Transfer-Encoding", "chunked")]):
        with pytest.raises(LocalProtocolError) as info:
            EndOfMessage(headers=bad)
        assert info.value.error_status_hint == 501


def test_data_and_connection_closed_fields():
    d = Data(b"abc")
    assert d.data == b"abc" and d.chunk_start is False and d.chunk_end is False
    assert EndOfMessage().headers == []
    assert ConnectionClosed() is not None


def test_raw_names_preserved_for_wire():
    req = get_request(headers=[("Host", "x"), ("X-Mixed-Case", "1")])
    wire = Connection(CLIENT).send(req)
    assert b"X-Mixed-Case: 1\r\n" in wire


# ----------------------------------------------------------------------
# FP-02 basic exchange
# ----------------------------------------------------------------------

def test_request_bytes_host_first():
    c = Connection(CLIENT)
    wire = c.send(get_request(headers=[("X-A", "1"), ("Host", "h")]))
    assert wire == b"GET / HTTP/1.1\r\nHost: h\r\nX-A: 1\r\n\r\n"
    assert c.our_state is SEND_BODY


def test_request_round_trip_and_states():
    c, s = pair_client_server()
    deliver(s, c.send(get_request()))
    assert s.next_event() is not NEED_DATA
    assert s.our_state is SEND_RESPONSE and s.their_state is SEND_BODY
    assert s.their_http_version == b"1.1"
    assert c.their_http_version is None
    deliver(s, c.send(EndOfMessage()))
    assert s.next_event() == EndOfMessage()
    assert s.their_state is DONE


def test_pull_on_empty_is_need_data():
    assert Connection(SERVER).next_event() is NEED_DATA


def test_send_one_event_per_pull_and_partial_feed():
    c, s = pair_client_server()
    deliver(s, c.send(get_request(method="POST", headers=[("Host", "h"), ("Content-Length", "3")])))
    deliver(s, b"ab")
    assert s.next_event() == get_request(method="POST", headers=[("Host", "h"), ("Content-Length", "3")])
    assert s.next_event() == Data(b"ab")
    assert s.next_event() is NEED_DATA
    deliver(s, b"c")
    assert s.next_event() == Data(b"c")
    assert s.next_event() == EndOfMessage()


def test_response_bytes_and_default_reason():
    c, s = pair_client_server()
    deliver(s, c.send(get_request()))
    s.next_event()
    assert s.send(Response(status_code=204, headers=[])) == b"HTTP/1.1 204 \r\n\r\n"


def test_receive_side_accepts_lone_lf_and_obs_fold():
    s = Connection(SERVER)
    deliver(s, b"GET / HTTP/1.1\nHost: a\nX-Fold: one\n   two\n\n")
    req = s.next_event()
    assert list(req.headers)[1] == (b"x-fold", b"one two")


def test_response_without_reason_accepted():
    c = Connection(CLIENT)
    c.send(get_request())
    c.send(EndOfMessage())
    deliver(c, b"HTTP/1.1 200\r\nContent-Length: 0\r\n\r\n")
    r = c.next_event()
    assert isinstance(r, Response) and r.reason == b""


# ----------------------------------------------------------------------
# FP-03 framing
# ----------------------------------------------------------------------

def test_chunked_request_round_trip_with_marks_and_trailers():
    c, s = pair_client_server()
    deliver(s, c.send(get_request(method="POST", headers=[("Host", "h"), ("Transfer-Encoding", "chunked")])))
    wire = c.send(Data(b"hello")) + c.send(EndOfMessage(headers=[("X-T", "9")]))
    assert wire == b"5\r\nhello\r\n0\r\nX-T: 9\r\n\r\n"
    deliver(s, wire)
    s.next_event()
    d = s.next_event()
    assert d == Data(b"hello", chunk_start=True, chunk_end=True)
    assert d.chunk_start is True and d.chunk_end is True
    e = s.next_event()
    assert e == EndOfMessage(headers=[("X-T", "9")])


def test_chunk_split_across_feeds_marks_start_and_end():
    s = Connection(SERVER)
    deliver(s, b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n4\r\nab")
    s.next_event()
    first = s.next_event()
    assert first == Data(b"ab", chunk_start=True, chunk_end=False)
    assert s.next_event() is NEED_DATA
    deliver(s, b"cd\r\n0\r\n\r\n")
    second = s.next_event()
    assert second == Data(b"cd", chunk_start=False, chunk_end=True)
    assert s.next_event() == EndOfMessage()


def test_chunk_size_64_digits_and_extension_accepted():
    s = Connection(SERVER)
    size_line = b"0" * 63 + b"1" + b";name=val ; x\r\n"
    deliver(s, b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n"
               + size_line + b"x\r\n0\r\n\r\n")
    s.next_event()
    assert s.next_event() == Data(b"x", chunk_start=True, chunk_end=True)
    assert s.next_event() == EndOfMessage()


def test_chunk_size_too_many_digits_refused():
    s = Connection(SERVER)
    deliver(s, b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n" + b"1" * 65 + b"\r\n")
    s.next_event()
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_whitespace_after_chunk_size_refused():
    s = Connection(SERVER)
    deliver(s, b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n5 \r\nhello\r\n")
    s.next_event()
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_chunk_missing_crlf_refused():
    s = Connection(SERVER)
    deliver(s, b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n2\r\nabXX")
    s.next_event()
    s.next_event()
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_content_length_too_much_body_refused_locally():
    c = Connection(CLIENT)
    c.send(get_request(method="POST", headers=[("Host", "h"), ("Content-Length", "2")]))
    with pytest.raises(LocalProtocolError):
        c.send(Data(b"abc"))
    assert c.our_state is ERROR


def test_end_of_message_short_of_content_length_refused():
    c = Connection(CLIENT)
    c.send(get_request(method="POST", headers=[("Host", "h"), ("Content-Length", "2")]))
    with pytest.raises(LocalProtocolError):
        c.send(EndOfMessage())


def test_trailers_refused_with_content_length():
    c = Connection(CLIENT)
    c.send(get_request(method="POST", headers=[("Host", "h"), ("Content-Length", "0")]))
    with pytest.raises(LocalProtocolError):
        c.send(EndOfMessage(headers=[("X", "1")]))


def test_passthrough_keeps_object_identity():
    class Blob(object):
        def __init__(self, n):
            self.n = n

        def __len__(self):
            return self.n

    c = Connection(CLIENT)
    c.send(get_request(method="POST", headers=[("Host", "h"), ("Transfer-Encoding", "chunked")]))
    blob = Blob(4)
    pieces = c.send_with_data_passthrough(Data(blob))
    assert pieces[0] == b"4\r\n"
    assert pieces[1] is blob
    assert pieces[2] == b"\r\n"


def test_passthrough_content_length_adds_no_pieces():
    class Blob(object):
        def __len__(self):
            return 3

    c = Connection(CLIENT)
    c.send(get_request(method="POST", headers=[("Host", "h"), ("Content-Length", "3")]))
    blob = Blob()
    pieces = c.send_with_data_passthrough(Data(blob))
    assert pieces == [blob]


def test_server_response_chunked_for_http11_peer():
    c, s = pair_client_server()
    deliver(s, c.send(get_request()))
    s.next_event()
    wire = s.send(Response(status_code=200, headers=[("X-A", "1")])) + s.send(Data(b"hey")) + s.send(EndOfMessage())
    assert b"Transfer-Encoding: chunked\r\n" in wire
    assert wire.endswith(b"3\r\nhey\r\n0\r\n\r\n")


def test_response_content_length_zero_kept():
    c, s = pair_client_server()
    deliver(s, c.send(get_request()))
    s.next_event()
    wire = s.send(Response(status_code=200, headers=[("Content-Length", "0")]))
    assert wire == b"HTTP/1.1 200 \r\nContent-Length: 0\r\n\r\n"


def test_response_both_framing_headers_transfer_encoding_wins():
    c, s = pair_client_server()
    deliver(s, c.send(get_request()))
    s.next_event()
    wire = s.send(Response(status_code=200, headers=[("Content-Length", "5"), ("Transfer-Encoding", "chunked")]))
    assert b"Content-Length" not in wire and b"chunked" in wire


def test_head_response_has_no_body_and_204_too():
    c, s = pair_client_server()
    deliver(s, c.send(get_request(method="HEAD")))
    s.next_event()
    wire = s.send(Response(status_code=200, headers=[("Content-Length", "10")]))
    assert wire == b"HTTP/1.1 200 \r\nContent-Length: 10\r\n\r\n"
    assert s.send(EndOfMessage()) == b""
    assert s.our_state is DONE


def test_204_response_has_no_body():
    c, s = pair_client_server()
    deliver(s, c.send(get_request()))
    s.next_event()
    s.send(Response(status_code=204, headers=[]))
    assert s.send(EndOfMessage()) == b""


def test_head_client_receives_empty_body_regardless_of_length():
    c = Connection(CLIENT)
    c.send(get_request(method="HEAD"))
    c.send(EndOfMessage())
    deliver(c, b"HTTP/1.1 200 OK\r\nContent-Length: 10\r\n\r\n")
    assert isinstance(c.next_event(), Response)
    assert c.next_event() == EndOfMessage()


def test_http10_close_delimited_response_and_connection_close():
    s = Connection(SERVER)
    deliver(s, b"GET / HTTP/1.0\r\nHost: h\r\n\r\n")  # httpwire never sends 1.0
    s.next_event()
    assert s.our_state is SEND_RESPONSE
    wire = s.send(Response(status_code=200, headers=[]))
    assert wire == b"HTTP/1.1 200 \r\nConnection: close\r\n\r\n"
    assert s.send(Data(b"raw")) == b"raw"
    assert s.send(EndOfMessage()) == b""
    assert s.our_state is MUST_CLOSE


def test_http10_request_peer_close_ends_body_with_eom_then_close():
    c = Connection(CLIENT)
    c.send(get_request())
    c.send(EndOfMessage())
    deliver(c, b"HTTP/1.0 200 OK\r\n\r\nbody")
    assert c.next_event() == Response(status_code=200, headers=[], http_version="1.0", reason="OK")
    assert c.next_event() == Data(b"body")
    assert c.next_event() is NEED_DATA
    c.receive_data(b"")
    assert c.next_event() == EndOfMessage()
    assert c.next_event() == ConnectionClosed()
    assert c.our_state is MUST_CLOSE


def test_send_response_with_http10_version_refused_and_error_state():
    s = Connection(SERVER)
    with pytest.raises(LocalProtocolError):
        s.send(Response(status_code=200, headers=[], http_version="1.0"))
    assert s.our_state is ERROR


# ----------------------------------------------------------------------
# FP-04 lifecycle
# ----------------------------------------------------------------------

def test_full_keep_alive_cycle_then_next_request():
    c, s = pair_client_server()
    for _ in range(2):
        deliver(s, c.send(get_request()))
        c.send(EndOfMessage())
        s.next_event()
        s.next_event()
        s.send(Response(status_code=200, headers=[("Content-Length", "0")]))
        s.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
        c.next_event()
        c.next_event()
        c.start_next_cycle()
        s.start_next_cycle()
        assert c.our_state is IDLE and s.their_state is IDLE


def test_start_next_cycle_refused_until_both_done_and_no_state_change():
    c, s = pair_client_server()
    c.send(get_request())
    with pytest.raises(LocalProtocolError):
        c.start_next_cycle()
    assert c.our_state is SEND_BODY


def test_second_request_refused_as_local_error():
    c = Connection(CLIENT)
    c.send(get_request())
    c.send(EndOfMessage())
    with pytest.raises(LocalProtocolError):
        c.send(get_request())


def test_connection_close_header_makes_must_close():
    c, s = pair_client_server()
    deliver(s, c.send(get_request(headers=[("Host", "h"), ("Connection", "Keep-Alive, Close")])))
    c.send(EndOfMessage())
    s.next_event()
    s.next_event()
    wire = s.send(Response(status_code=200, headers=[("Content-Length", "0"), ("Connection", "keep-alive")]))
    assert b"Connection: keep-alive" not in wire and b"close" in wire
    s.send(EndOfMessage())
    assert s.our_state is MUST_CLOSE


def test_server_pipelined_request_paused_until_cycle_done():
    c, s = pair_client_server()
    first = c.send(get_request(headers=[("Host", "h")]))
    c.send(EndOfMessage())
    second = b"GET /2 HTTP/1.1\r\nHost: h\r\n\r\n"
    deliver(s, first + second)
    assert isinstance(s.next_event(), Request)
    assert s.next_event() == EndOfMessage()
    assert s.next_event() is PAUSED
    s.send(Response(status_code=200, headers=[("Content-Length", "0")]))
    s.send(EndOfMessage())
    assert s.next_event() is PAUSED
    c.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
    c.next_event(); c.next_event()
    c.start_next_cycle()
    s.start_next_cycle()
    assert s.next_event().target == b"/2"


def test_server_can_send_final_response_without_request():
    s = Connection(SERVER)
    wire = s.send(Response(status_code=400, headers=[("Content-Length", "0")]))
    assert b"Connection: close" in wire
    assert s.our_state is SEND_BODY


# ----------------------------------------------------------------------
# FP-05 errors
# ----------------------------------------------------------------------

def test_remote_error_marks_their_state_and_persists():
    s = Connection(SERVER)
    deliver(s, b"GET / HTTP/1.1\r\nBad Header\r\n\r\n")
    with pytest.raises(RemoteProtocolError):
        s.next_event()
    assert s.their_state is ERROR and s.our_state is IDLE
    deliver(s, b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
    with pytest.raises(RemoteProtocolError):
        s.next_event()
    wire = s.send(Response(status_code=400, headers=[("Content-Length", "0")]))
    assert b"Connection: close" in wire


def test_leading_space_or_control_fails_immediately():
    s = Connection(SERVER)
    deliver(s, b" GET")
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_incomplete_header_block_over_limit_is_431():
    s = Connection(SERVER, 100)
    deliver(s, b"GET / HTTP/1.1\r\nX: " + b"a" * 200)
    with pytest.raises(RemoteProtocolError) as info:
        s.next_event()
    assert info.value.error_status_hint == 431


def test_body_bytes_never_count_against_limit():
    s = Connection(SERVER, 100)
    deliver(s, b"POST / HTTP/1.1\r\nHost: h\r\nContent-Length: 500\r\n\r\n")
    s.next_event()
    deliver(s, b"x" * 300)
    assert s.next_event() == Data(b"x" * 300)


def test_default_limit_between_14_and_18_kib():
    s = Connection(SERVER)
    deliver(s, b"GET / HTTP/1.1\r\nHost: h\r\nX: " + b"a" * (15 * 1024))
    assert s.next_event() is NEED_DATA
    deliver(s, b"a" * (5 * 1024))
    with pytest.raises(RemoteProtocolError) as info:
        s.next_event()
    assert info.value.error_status_hint == 431


def test_local_send_error_makes_our_state_error_and_sends_fail():
    c = Connection(CLIENT)
    with pytest.raises(LocalProtocolError):
        c.send(Response(status_code=200, headers=[]))
    assert c.our_state is ERROR
    with pytest.raises(LocalProtocolError):
        c.send(get_request())


def test_invalid_construction_recoverable():
    c = Connection(CLIENT)
    with pytest.raises(LocalProtocolError):
        Request(method="GET", target="/", headers=[])
    assert c.our_state is IDLE
    c.send(get_request())


def test_send_failed_marks_error_and_no_bytes():
    c = Connection(CLIENT)
    c.send(get_request(method="POST", headers=[("Host", "h"), ("Content-Length", "5")]))
    assert c.send_failed() is None
    assert c.our_state is ERROR
    with pytest.raises(LocalProtocolError):
        c.send(Data(b"x"))


def test_receive_after_close_is_runtime_error():
    s = Connection(SERVER)
    s.receive_data(b"")
    with pytest.raises(RuntimeError) as info:
        s.receive_data(b"GET")
    assert not isinstance(info.value, (LocalProtocolError, RemoteProtocolError))


# ----------------------------------------------------------------------
# FP-06 shutdown
# ----------------------------------------------------------------------

def test_connection_closed_from_idle_and_repeat_pulls():
    c, s = pair_client_server()
    c.send(ConnectionClosed())
    assert c.our_state is CLOSED
    assert s.their_state is IDLE
    s.receive_data(b"")
    assert isinstance(s.next_event(), ConnectionClosed)
    assert isinstance(s.next_event(), ConnectionClosed)
    assert s.their_state is CLOSED
    assert s.our_state is MUST_CLOSE


def test_close_mid_body_is_remote_error():
    s = Connection(SERVER)
    deliver(s, b"POST / HTTP/1.1\r\nHost: h\r\nContent-Length: 5\r\n\r\nab")
    s.next_event()
    assert s.next_event() == Data(b"ab")
    s.receive_data(b"")
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_send_connection_closed_in_send_body_refused():
    c = Connection(CLIENT)
    c.send(get_request())
    with pytest.raises(LocalProtocolError):
        c.send(ConnectionClosed())


def test_trailing_data_reports_leftover_and_closed():
    s = Connection(SERVER)
    deliver(s, b"junk")
    s.receive_data(b"")
    assert s.trailing_data == (b"junk", True)


# ----------------------------------------------------------------------
# FP-07 informational, 100-continue, protocol switches
# ----------------------------------------------------------------------

def test_expect_100_continue_flags_and_clearing():
    c, s = pair_client_server()
    req = get_request(method="POST", headers=[("Host", "h"), ("Content-Length", "2"), ("Expect", "100-continue")])
    deliver(s, c.send(req))
    assert c.client_is_waiting_for_100_continue is True
    assert c.they_are_waiting_for_100_continue is False
    s.next_event()
    assert s.they_are_waiting_for_100_continue is True
    assert s.client_is_waiting_for_100_continue is True
    s.send(InformationalResponse(status_code=100, headers=[]))
    assert s.client_is_waiting_for_100_continue is False


def test_expect_on_http10_does_not_set_flag():
    c = Connection(CLIENT)
    c.send(get_request(headers=[("Host", "h"), ("Expect", "100-continue")], http_version="1.1"))
    assert c.client_is_waiting_for_100_continue is True
    s = Connection(SERVER)
    deliver(s, b"POST / HTTP/1.0\r\nContent-Length: 0\r\nExpect: 100-continue\r\n\r\n")
    s.next_event()
    assert s.they_are_waiting_for_100_continue is False


def test_client_pulls_informational_then_final():
    c = Connection(CLIENT)
    c.send(get_request(method="POST", headers=[("Host", "h"), ("Content-Length", "1"), ("Expect", "100-continue")]))
    deliver(c, b"HTTP/1.1 100 Continue\r\n\r\nHTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
    info = c.next_event()
    assert isinstance(info, InformationalResponse) and info.status_code == 100
    assert c.our_state is SEND_BODY
    c.send(Data(b"x"))
    c.send(EndOfMessage())
    assert isinstance(c.next_event(), Response)
    assert c.next_event() == EndOfMessage()


def test_connect_accepted_switches_protocol_with_trailing_data():
    c, s = pair_client_server()
    deliver(s, c.send(get_request(method="CONNECT", target="h:443")))
    c.send(EndOfMessage())
    assert c.our_state is MIGHT_SWITCH_PROTOCOL
    with pytest.raises(LocalProtocolError):
        c.send(get_request())
    deliver(s, b"\x16\x03")
    assert isinstance(s.next_event(), Request)
    assert s.next_event() == EndOfMessage()
    assert s.next_event() is PAUSED
    wire = s.send(Response(status_code=200, headers=[]))
    assert wire.startswith(b"HTTP/1.1 200 ")
    assert s.our_state is SWITCHED_PROTOCOL and s.their_state is SWITCHED_PROTOCOL
    assert s.next_event() is PAUSED
    assert s.trailing_data == (b"\x16\x03", False)
    with pytest.raises(LocalProtocolError):
        s.send(Data(b"x"))


def test_connect_denied_then_normal_cycle_continues():
    c, s = pair_client_server()
    deliver(s, c.send(get_request(method="CONNECT", target="h:443")))
    c.send(EndOfMessage())
    s.next_event(); s.next_event()
    s.send(Response(status_code=403, headers=[("Content-Length", "0")]))
    s.send(EndOfMessage())
    assert s.our_state is DONE
    c.receive_data(b"HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\n\r\n")
    c.next_event(); c.next_event()
    assert c.our_state is DONE
    c.start_next_cycle()
    s.start_next_cycle()


def test_upgrade_accepted_with_101():
    c, s = pair_client_server()
    deliver(s, c.send(get_request(headers=[("Host", "h"), ("Upgrade", "websocket"), ("Connection", "Upgrade")])))
    c.send(EndOfMessage())
    s.next_event(); s.next_event()
    wire = s.send(InformationalResponse(status_code=101, headers=[("Upgrade", "websocket")], reason="Switching Protocols"))
    assert s.our_state is SWITCHED_PROTOCOL and s.their_state is SWITCHED_PROTOCOL
    deliver(c, wire)
    info = c.next_event()
    assert isinstance(info, InformationalResponse) and info.status_code == 101
    assert c.our_state is SWITCHED_PROTOCOL and c.their_state is SWITCHED_PROTOCOL
    assert c.next_event() is PAUSED


def test_upgrade_denied_by_final_response():
    c, s = pair_client_server()
    deliver(s, c.send(get_request(headers=[("Host", "h"), ("Upgrade", "websocket")])))
    c.send(EndOfMessage())
    s.next_event(); s.next_event()
    s.send(Response(status_code=426, headers=[("Content-Length", "0")]))
    assert s.our_state is SEND_BODY
    s.send(EndOfMessage())
    assert s.our_state is DONE


def test_informational_not_switch_leaves_response_pending():
    c, s = pair_client_server()
    deliver(s, c.send(get_request(headers=[("Host", "h"), ("Upgrade", "x")])))
    c.send(EndOfMessage())
    s.next_event(); s.next_event()
    s.send(InformationalResponse(status_code=102, headers=[]))
    assert s.our_state is SEND_RESPONSE
