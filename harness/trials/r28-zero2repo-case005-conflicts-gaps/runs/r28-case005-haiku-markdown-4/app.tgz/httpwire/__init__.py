"""httpwire: a pure-Python HTTP/1.1 wire protocol library (RFC 7230 framing).

httpwire performs no I/O. Feed it bytes, pull events out; send events, get bytes.
"""

from ._connection import Connection
from ._errors import LocalProtocolError, RemoteProtocolError
from ._events import (
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    Request,
    Response,
)
from ._states import (
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
)

__version__ = "1.0.0"

__all__ = [
    "CLIENT",
    "CLOSED",
    "Connection",
    "ConnectionClosed",
    "Data",
    "DONE",
    "EndOfMessage",
    "ERROR",
    "IDLE",
    "InformationalResponse",
    "LocalProtocolError",
    "MIGHT_SWITCH_PROTOCOL",
    "MUST_CLOSE",
    "NEED_DATA",
    "PAUSED",
    "RemoteProtocolError",
    "Request",
    "Response",
    "SEND_BODY",
    "SEND_RESPONSE",
    "SERVER",
    "SWITCHED_PROTOCOL",
]
