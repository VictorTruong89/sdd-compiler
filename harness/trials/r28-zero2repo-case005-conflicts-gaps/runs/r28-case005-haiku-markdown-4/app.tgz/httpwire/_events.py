"""HTTP event types and header-list normalization (PRD FP-01).

Construction validates everything and raises LocalProtocolError on refusal;
no event object is produced in that case.
"""

import re
from collections.abc import Sequence

from ._errors import LocalProtocolError

MAX_CONTENT_LENGTH_DIGITS = 18

_TOKEN_RE = re.compile(rb"[!#$%&'*+\-.^_`|~0-9A-Za-z]+")
_TARGET_RE = re.compile(rb"[\x21-\x7e]+")
# A value: empty, or non-blank bytes with SP/HTAB allowed only between them.
# Controls other than HTAB, DEL, and CR/LF/NUL/FF/VT are all refused.
_VALUE_RE = re.compile(
    rb"(?:[\x21-\x7e\x80-\xff](?:[\t \x21-\x7e\x80-\xff]*[\x21-\x7e\x80-\xff])?)?"
)
_VERSION_RE = re.compile(rb"[0-9]\.[0-9]")
_REASON_RE = re.compile(rb"[\t \x21-\x7e\x80-\xff]*")


def as_bytes(value, what):
    """Return ``value`` as an immutable bytes object (ASCII str or bytes-like)."""
    if isinstance(value, bytes):
        return value
    if isinstance(value, str):
        try:
            return value.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("%s must be ASCII text" % what) from None
    try:
        return bytes(memoryview(value))
    except TypeError:
        raise LocalProtocolError("%s must be text or bytes" % what) from None


class Headers(Sequence):
    """Ordered header list.

    Iterating or indexing yields ``(lowercase_name, value)`` byte pairs.
    ``raw_items()`` yields ``(name_as_given, value)`` byte pairs.
    """

    def __init__(self, triples=()):
        # Internal storage: tuple of (raw_name, lower_name, value).
        self._items = tuple(triples)

    def __len__(self):
        return len(self._items)

    def __getitem__(self, index):
        if isinstance(index, slice):
            return [(n, v) for _, n, v in self._items[index]]
        _, n, v = self._items[index]
        return (n, v)

    def raw_items(self):
        return [(r, v) for r, _, v in self._items]

    def _triples(self):
        return self._items

    def __eq__(self, other):
        if isinstance(other, Headers):
            other = list(other)
        elif not isinstance(other, (list, tuple)):
            return NotImplemented
        try:
            return list(self) == [tuple(p) for p in other]
        except TypeError:
            return False

    __hash__ = None

    def __repr__(self):
        return "Headers(%r)" % (list(self),)


def build_headers(headers):
    """Validate and normalize a caller-supplied header list into Headers."""
    if isinstance(headers, Headers):
        pairs = headers.raw_items()
    elif isinstance(headers, (bytes, str, bytearray)):
        raise LocalProtocolError("headers must be a sequence of (name, value) pairs")
    else:
        try:
            pairs = list(headers)
        except TypeError:
            raise LocalProtocolError(
                "headers must be a sequence of (name, value) pairs"
            ) from None

    items = []
    for pair in pairs:
        try:
            name, value = pair
        except (TypeError, ValueError):
            raise LocalProtocolError("each header must be a (name, value) pair") from None
        name = as_bytes(name, "header name")
        value = as_bytes(value, "header value")
        if not _TOKEN_RE.fullmatch(name):
            raise LocalProtocolError("invalid header name %r" % (name,))
        if not _VALUE_RE.fullmatch(value):
            raise LocalProtocolError("invalid header value for %r" % (name,))
        items.append((name, name.lower(), value))
    return Headers(_apply_framing_rules(items))


def _apply_framing_rules(items):
    """Collapse Content-Length, and check Transfer-Encoding (PRD FP-01)."""
    cl_indexes = [i for i, it in enumerate(items) if it[1] == b"content-length"]
    te_indexes = [i for i, it in enumerate(items) if it[1] == b"transfer-encoding"]

    if len(te_indexes) > 1:
        raise LocalProtocolError("more than one Transfer-Encoding header", 501)
    if te_indexes and items[te_indexes[0]][2].strip(b" \t").lower() != b"chunked":
        raise LocalProtocolError("only the chunked transfer coding is supported", 501)

    cl_value = None
    if cl_indexes:
        first = None
        for i in cl_indexes:
            for piece in items[i][2].split(b","):
                piece = piece.strip(b" \t")
                if not piece.isdigit():
                    raise LocalProtocolError("Content-Length must be a decimal integer")
                if len(piece) > MAX_CONTENT_LENGTH_DIGITS:
                    raise LocalProtocolError("Content-Length has too many digits")
                if first is None:
                    first = piece
                elif int(piece) != int(first):
                    raise LocalProtocolError("conflicting Content-Length values")
        cl_value = first

    out = []
    for i, (raw, lname, value) in enumerate(items):
        if lname == b"content-length":
            if i == cl_indexes[0]:
                out.append((raw, lname, cl_value))
        elif lname == b"transfer-encoding":
            out.append((raw, lname, b"chunked"))
        else:
            out.append((raw, lname, value))
    return out


def check_status(status, low, high):
    if isinstance(status, bool) or not isinstance(status, int):
        raise LocalProtocolError("status code must be an integer")
    code = int(status)
    if not low <= code < high:
        raise LocalProtocolError("status code %d is out of range" % code)
    return code


def check_reason(reason):
    reason = as_bytes(reason, "reason")
    if not _REASON_RE.fullmatch(reason):
        raise LocalProtocolError("reason phrase contains a forbidden byte")
    return reason


def check_version(version):
    version = as_bytes(version, "http_version")
    if not _VERSION_RE.fullmatch(version):
        raise LocalProtocolError("http_version must look like 1.1")
    return version


def check_token(value, what):
    value = as_bytes(value, what)
    if not _TOKEN_RE.fullmatch(value):
        raise LocalProtocolError("%s must be an RFC 7230 token" % what)
    return value


def check_target(target):
    target = as_bytes(target, "request target")
    if not _TARGET_RE.fullmatch(target):
        raise LocalProtocolError("request target must be visible ASCII")
    return target


def _host_count(headers):
    return sum(1 for it in headers._triples() if it[1] == b"host")


class _Event(object):
    _fields = ()

    def __eq__(self, other):
        if type(other) is not type(self):
            return NotImplemented
        return all(getattr(self, f) == getattr(other, f) for f in self._fields)

    __hash__ = None

    def __repr__(self):
        return "%s(%s)" % (
            type(self).__name__,
            ", ".join("%s=%r" % (f, getattr(self, f)) for f in self._fields),
        )


class Request(_Event):
    _fields = ("method", "target", "headers", "http_version")

    def __init__(self, method, target, headers, http_version=b"1.1"):
        self.method = check_token(method, "method")
        self.target = check_target(target)
        self.headers = build_headers(headers)
        self.http_version = check_version(http_version)
        hosts = _host_count(self.headers)
        if hosts > 1:
            raise LocalProtocolError("more than one Host header")
        if self.http_version == b"1.1" and hosts == 0:
            raise LocalProtocolError("an HTTP/1.1 request needs a Host header")


class _ResponseBase(_Event):
    _fields = ("status_code", "headers", "http_version", "reason")
    _LOW = 0
    _HIGH = 0

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        self.status_code = check_status(status_code, self._LOW, self._HIGH)
        self.headers = build_headers(headers)
        self.http_version = check_version(http_version)
        self.reason = check_reason(reason)


class InformationalResponse(_ResponseBase):
    _LOW = 100
    _HIGH = 200


class Response(_ResponseBase):
    _LOW = 200
    _HIGH = 1000


class Data(_Event):
    _fields = ("data", "chunk_start", "chunk_end")

    def __init__(self, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)

    def __eq__(self, other):
        if type(other) is not type(self):
            return NotImplemented
        try:
            same = bytes(memoryview(self.data)) == bytes(memoryview(other.data))
        except TypeError:
            same = self.data == other.data
        return same and (self.chunk_start, self.chunk_end) == (
            other.chunk_start,
            other.chunk_end,
        )

    __hash__ = None


class EndOfMessage(_Event):
    _fields = ("headers",)

    def __init__(self, headers=None):
        self.headers = build_headers(() if headers is None else headers)


class ConnectionClosed(_Event):
    _fields = ()

    def __init__(self):
        pass


EVENT_TYPES = (Request, InformationalResponse, Response, Data, EndOfMessage, ConnectionClosed)
