"""The bring-your-own-I/O connection object (PRD FP-02 to FP-07).

The connection never touches a socket. ``send`` turns an event into bytes,
``receive_data`` stores bytes, and ``next_event`` parses one event out of the
stored bytes. Both directions share one pair of states; an event that either
side produces moves the pair through the same transitions.
"""

import re

from . import _events as ev
from ._errors import LocalProtocolError, RemoteProtocolError
from ._states import (
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
)

DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 16 * 1024
MAX_CHUNK_SIZE_DIGITS = 64

_CRLF = b"\r\n"
_CHUNK_SIZE_RE = re.compile(rb"([0-9A-Fa-f]+)(?:;[\t\x20-\x7e\x80-\xff]*)?")
_STATUS_CODE_RE = re.compile(rb"[0-9]{3}")
_SUPPORTED_VERSIONS = (b"HTTP/1.0", b"HTTP/1.1")

# Body framing kinds
_LENGTH = "length"
_CHUNKED = "chunked"
_CLOSE = "close"
_EMPTY = "empty"

# Switch proposals still waiting for an answer
_PROPOSE_CONNECT = "connect"
_PROPOSE_UPGRADE = "upgrade"

_CL = b"content-length"
_TE = b"transfer-encoding"
_CONNECTION = b"connection"


def _other(role):
    return SERVER if role is CLIENT else CLIENT


class _Framing(object):
    __slots__ = ("kind", "remaining", "cstate", "chunk_remaining", "first")

    def __init__(self, kind, remaining=0):
        self.kind = kind
        self.remaining = remaining
        self.cstate = "size"  # chunked sub-state: size, data, crlf, trailers
        self.chunk_remaining = 0
        self.first = False


def _find(items, name):
    for item in items:
        if item[1] == name:
            return item[2]
    return None


def _tokens(items, name):
    out = []
    for item in items:
        if item[1] == name:
            for token in item[2].split(b","):
                token = token.strip(b" \t").lower()
                if token:
                    out.append(token)
    return out


def _request_framing(items):
    """Body framing of a request (PRD FP-03); Content-Length wins over TE."""
    cl = _find(items, _CL)
    if cl is not None:
        return _Framing(_LENGTH, int(cl))
    if _find(items, _TE) is not None:
        return _Framing(_CHUNKED)
    return _Framing(_LENGTH, 0)


def _header_block(items):
    return b"".join(raw + b": " + value + _CRLF for raw, _, value in items)


def _force_connection_close(items):
    """Rewrite Connection so it carries close and no keep-alive token."""
    tokens = []
    out = []
    first = None
    for item in items:
        if item[1] == _CONNECTION:
            if first is None:
                first = len(out)
                out.append(None)
            for token in item[2].split(b","):
                token = token.strip(b" \t")
                if token and token.lower() != b"keep-alive":
                    tokens.append(token)
        else:
            out.append(item)
    if not any(token.lower() == b"close" for token in tokens):
        tokens.append(b"close")
    merged = (b"Connection", _CONNECTION, b", ".join(tokens))
    if first is None:
        out.append(merged)
    else:
        out[first] = merged
    return out


def _find_head_end(buf):
    """Index just past the blank line that ends a header block, or -1."""
    pos = 0
    while True:
        nl = buf.find(b"\n", pos)
        if nl < 0:
            return -1
        line = bytes(buf[pos:nl])
        if line == b"" or line == b"\r":
            return nl + 1
        pos = nl + 1


def _split_head(raw):
    """Lines of a header block, without line endings and without the blank line."""
    parts = raw.split(b"\n")
    return [p[:-1] if p.endswith(b"\r") else p for p in parts[:-2]]


def _parse_header_lines(lines):
    """Header (name, value) pairs; obsolete line folding is joined (RFC 7230 3.2.4)."""
    pairs = []
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            if not pairs:
                raise LocalProtocolError("continuation line with no header to continue")
            name, value = pairs[-1]
            cont = line.strip(b" \t")
            if cont:
                value = (value + b" " + cont) if value else cont
            pairs[-1] = (name, value)
            continue
        colon = line.find(b":")
        if colon < 0:
            raise LocalProtocolError("header line has no colon")
        pairs.append((line[:colon], line[colon + 1:].strip(b" \t")))
    return pairs


def _build_request(lines):
    parts = lines[0].split(b" ")
    if len(parts) != 3:
        raise LocalProtocolError("malformed request line")
    method, target, version = parts
    if version not in _SUPPORTED_VERSIONS:
        raise LocalProtocolError("unsupported HTTP version")
    return ev.Request(
        method=method,
        target=target,
        headers=_parse_header_lines(lines[1:]),
        http_version=version[5:],
    )


def _build_response(lines):
    parts = lines[0].split(b" ", 2)
    if len(parts) < 2:
        raise LocalProtocolError("malformed status line")
    version, code = parts[0], parts[1]
    if version not in _SUPPORTED_VERSIONS:
        raise LocalProtocolError("unsupported HTTP version")
    if not _STATUS_CODE_RE.fullmatch(code):
        raise LocalProtocolError("status code must be three digits")
    status = int(code)
    if status < 100:
        raise LocalProtocolError("status code out of range")
    reason = parts[2] if len(parts) == 3 else b""
    headers = _parse_header_lines(lines[1:])
    if status < 200:
        return ev.InformationalResponse(
            status_code=status, headers=headers, http_version=version[5:], reason=reason
        )
    return ev.Response(
        status_code=status, headers=headers, http_version=version[5:], reason=reason
    )


class Connection(object):
    """One HTTP/1.1 connection in the client or server role."""

    def __init__(self, role, max_incomplete_event_size=DEFAULT_MAX_INCOMPLETE_EVENT_SIZE):
        if role is not CLIENT and role is not SERVER:
            raise ValueError("role must be CLIENT or SERVER")
        self._our_role = role
        self._their_role = _other(role)
        self._states = {CLIENT: IDLE, SERVER: IDLE}
        self._max_size = int(max_incomplete_event_size)
        self._buf = bytearray()
        self._closed = False  # the peer's sending side has closed
        self._their_http_version = None
        self._request_method = None
        self._blocked = False  # keep-alive is disabled for this cycle
        self._pending = set()  # unanswered switch proposals
        self._client_waiting = False  # client is waiting for 100-continue
        self._send_framing = None
        self._recv_framing = None

    # ------------------------------------------------------------------
    # Attributes
    # ------------------------------------------------------------------

    @property
    def our_role(self):
        return self._our_role

    @property
    def their_role(self):
        return self._their_role

    @property
    def our_state(self):
        return self._states[self._our_role]

    @property
    def their_state(self):
        return self._states[self._their_role]

    @property
    def states(self):
        return dict(self._states)

    @property
    def their_http_version(self):
        return self._their_http_version

    @property
    def client_is_waiting_for_100_continue(self):
        return bool(self._client_waiting)

    @property
    def they_are_waiting_for_100_continue(self):
        return bool(self._client_waiting and self._our_role is SERVER)

    @property
    def trailing_data(self):
        return (bytes(self._buf), bool(self._closed))

    # ------------------------------------------------------------------
    # Sending
    # ------------------------------------------------------------------

    def send(self, event):
        """Encode one event; returns the bytes to transmit (possibly empty)."""
        return b"".join(self._send_pieces(event, passthrough=False))

    def send_with_data_passthrough(self, event):
        """Like send(), but returns a list of pieces; caller payloads stay as-is."""
        return self._send_pieces(event, passthrough=True)

    def send_failed(self):
        """The integrator did not transmit the bytes of the last send."""
        self._states[self._our_role] = ERROR
        self._normalize()
        return None

    def _send_pieces(self, event, passthrough):
        if not isinstance(event, ev.EVENT_TYPES):
            raise TypeError("expected an HTTP event, got %r" % (event,))
        try:
            return self._prepare_send(event, passthrough)
        except LocalProtocolError:
            self._states[self._our_role] = ERROR
            self._normalize()
            raise

    def _prepare_send(self, event, passthrough):
        role = self._our_role
        st = self._states[role]
        t = type(event)
        if t is ev.ConnectionClosed:
            if st is not IDLE and st is not DONE and st is not MUST_CLOSE:
                raise LocalProtocolError("cannot send connection-closed in state %r" % (st,))
            self._fire(role, event, pulled=False)
            return []
        if t is ev.Request:
            if role is not CLIENT or st is not IDLE:
                raise LocalProtocolError("a request can only be sent by an idle client")
            return self._send_request(event)
        if t is ev.InformationalResponse:
            if role is not SERVER or st is not SEND_RESPONSE:
                raise LocalProtocolError("informational response not allowed now")
            return self._send_informational(event)
        if t is ev.Response:
            if role is not SERVER or (st is not SEND_RESPONSE and st is not IDLE):
                raise LocalProtocolError("final response not allowed now")
            return self._send_response(event)
        if t is ev.Data:
            if st is not SEND_BODY:
                raise LocalProtocolError("body data not allowed in state %r" % (st,))
            return self._send_data(event, passthrough)
        if t is ev.EndOfMessage:
            if st is not SEND_BODY:
                raise LocalProtocolError("end-of-message not allowed in state %r" % (st,))
            return self._send_eom(event)
        raise LocalProtocolError("unknown event")  # pragma: no cover

    @staticmethod
    def _require_11(event):
        if event.http_version != b"1.1":
            raise LocalProtocolError("httpwire only sends HTTP/1.1")

    def _send_request(self, event):
        self._require_11(event)
        items = list(event.headers._triples())
        if _find(items, _CL) is not None:
            items = [it for it in items if it[1] != _TE]
        hosts = [it for it in items if it[1] == b"host"]
        others = [it for it in items if it[1] != b"host"]
        head = b"%s %s HTTP/1.1\r\n" % (event.method, event.target)
        head += _header_block(hosts + others) + _CRLF
        self._send_framing = _request_framing(items)
        self._fire(CLIENT, event, pulled=False)
        return [head]

    def _send_informational(self, event):
        self._require_11(event)
        items = list(event.headers._triples())
        head = b"HTTP/1.1 %d %s\r\n" % (event.status_code, event.reason)
        head += _header_block(items) + _CRLF
        self._fire(SERVER, event, pulled=False)
        return [head]

    def _send_response(self, event):
        self._require_11(event)
        items = list(event.headers._triples())
        status = event.status_code
        accept = status == 200 and _PROPOSE_CONNECT in self._pending
        if accept:
            wire = items
            framing = None
            blocked_now = self._blocked
        else:
            wire, framing, close_now = self._plan_response(items, status)
            blocked_now = self._blocked or close_now
            if blocked_now:
                wire = _force_connection_close(wire)
        head = b"HTTP/1.1 %d %s\r\n" % (status, event.reason)
        head += _header_block(wire) + _CRLF
        self._send_framing = framing
        if blocked_now:
            self._blocked = True
        self._fire(SERVER, event, pulled=False)
        return [head]

    def _plan_response(self, items, status):
        """Wire headers, body framing, and whether keep-alive ends (PRD FP-03/FP-04)."""
        peer_11 = self._their_http_version == b"1.1"
        head_request = self._request_method == b"HEAD"
        no_body_status = status in (204, 304)
        empty_body = head_request or no_body_status
        has_te = _find(items, _TE) is not None
        cl = _find(items, _CL)
        wire = list(items)

        if has_te:
            if peer_11:
                kind = _Framing(_CHUNKED)
                wire = [it for it in wire if it[1] != _CL]
            else:
                kind = _Framing(_CLOSE)
                wire = [it for it in wire if it[1] not in (_CL, _TE)]
        elif cl is not None:
            kind = _Framing(_LENGTH, int(cl))
        elif peer_11:
            kind = _Framing(_CHUNKED)
            if not no_body_status:
                wire.append((b"Transfer-Encoding", _TE, b"chunked"))
        else:
            kind = _Framing(_CLOSE)

        close_now = (
            (not peer_11)
            or kind.kind == _CLOSE
            or b"close" in _tokens(items, _CONNECTION)
        )
        if empty_body:
            kind = _Framing(_EMPTY)
            wire = [it for it in wire if not (it[1] == _CL and it[2] == b"0")]
            if no_body_status:
                wire = [it for it in wire if it[1] != _TE]
        return wire, kind, close_now

    def _send_data(self, event, passthrough):
        framing = self._send_framing
        data = event.data
        try:
            n = memoryview(data).nbytes
            bytes_like = True
        except TypeError:
            bytes_like = False
        if bytes_like:
            payload = data if passthrough else bytes(data)
        else:
            if not passthrough:
                raise LocalProtocolError("Data payload must be bytes-like")
            try:
                n = len(data)
            except TypeError:
                raise LocalProtocolError("passthrough payload needs a length") from None
            payload = data
        if framing is None:
            raise LocalProtocolError("no body framing is active")

        if framing.kind == _EMPTY:
            pieces = []  # empty-body response: no data is sent
        elif framing.kind == _LENGTH:
            if n > framing.remaining:
                raise LocalProtocolError("body exceeds the declared Content-Length")
            framing.remaining -= n
            pieces = [payload] if n else []
        elif framing.kind == _CHUNKED:
            pieces = [b"%x\r\n" % n, payload, _CRLF] if n else []
        else:  # close-delimited
            pieces = [payload] if n else []
        self._fire(self._our_role, event, pulled=False)
        return pieces

    def _send_eom(self, event):
        framing = self._send_framing
        items = list(event.headers._triples())
        if framing is None:
            raise LocalProtocolError("no body framing is active")
        if framing.kind == _LENGTH:
            if framing.remaining != 0:
                raise LocalProtocolError("body is shorter than the declared Content-Length")
            if items:
                raise LocalProtocolError("trailers are not allowed with Content-Length")
            pieces = []
        elif framing.kind == _CHUNKED:
            pieces = [b"0\r\n" + _header_block(items) + _CRLF]
        else:  # close-delimited or empty
            if items:
                raise LocalProtocolError("trailers are not allowed with this framing")
            pieces = []
        self._send_framing = None
        self._fire(self._our_role, event, pulled=False)
        return pieces

    # ------------------------------------------------------------------
    # Receiving
    # ------------------------------------------------------------------

    def receive_data(self, data):
        """Store bytes from the peer; an empty chunk means the peer closed its sending side."""
        chunk = bytes(memoryview(data))
        if not chunk:
            self._closed = True
            return None
        if self._closed:
            raise RuntimeError("cannot receive more data after the peer closed its side")
        self._buf += chunk
        return None

    def next_event(self):
        """Parse one event from stored bytes, or return NEED_DATA or PAUSED."""
        their = self._their_role
        st = self._states[their]
        if st is ERROR:
            raise RemoteProtocolError("peer previously violated the protocol", 400)
        if st is CLOSED:
            return ev.ConnectionClosed()
        if st is SWITCHED_PROTOCOL or st is MIGHT_SWITCH_PROTOCOL:
            return PAUSED
        if st is DONE or st is MUST_CLOSE:
            if self._buf:
                return PAUSED
            if self._closed:
                return self._pull_close()
            return NEED_DATA
        if st is SEND_BODY:
            return self._pull_body()
        return self._pull_head()

    def _pull_close(self):
        event = ev.ConnectionClosed()
        self._fire(self._their_role, event, pulled=True)
        return event

    def _remote(self, message, hint=400):
        self._states[self._their_role] = ERROR
        self._blocked = True
        self._normalize()
        return RemoteProtocolError(message, hint)

    def _pull_head(self):
        their = self._their_role
        st = self._states[their]
        buf = self._buf
        if their is SERVER and st is IDLE:
            if buf:
                raise self._remote("unexpected data from a server that has not responded")
            return self._pull_close() if self._closed else NEED_DATA
        if not buf:
            if self._closed:
                if st is IDLE:
                    return self._pull_close()
                raise self._remote("connection closed in the middle of a message")
            return NEED_DATA
        if buf[0] <= 32:
            raise self._remote("invalid first byte of a start line")

        end = _find_head_end(buf)
        if end < 0:
            if len(buf) > self._max_size:
                raise self._remote("header block exceeds the incomplete-event size limit", 431)
            if self._closed:
                raise self._remote("connection closed in the middle of a header block")
            return NEED_DATA

        try:
            lines = _split_head(bytes(buf[:end]))
            if their is CLIENT:
                event = _build_request(lines)
            else:
                event = _build_response(lines)
        except LocalProtocolError as exc:
            raise self._remote(str(exc), exc.error_status_hint)
        del buf[:end]

        if their is CLIENT:
            self._fire(CLIENT, event, pulled=True)
            self._recv_framing = _request_framing(event.headers._triples())
        elif isinstance(event, ev.InformationalResponse):
            self._fire(SERVER, event, pulled=True)
        else:
            self._fire(SERVER, event, pulled=True)
            if self._states[SERVER] is SEND_BODY:
                self._recv_framing = self._response_recv_framing(event)
        return event

    def _response_recv_framing(self, event):
        items = list(event.headers._triples())
        status = event.status_code
        if self._request_method == b"HEAD" or status in (204, 304):
            return _Framing(_EMPTY)
        if _find(items, _TE) is not None:
            return _Framing(_CHUNKED)
        cl = _find(items, _CL)
        if cl is not None:
            return _Framing(_LENGTH, int(cl))
        self._blocked = True  # close-delimited bodies end keep-alive
        return _Framing(_CLOSE)

    def _pull_body(self):
        framing = self._recv_framing
        buf = self._buf
        if framing is None:
            raise self._remote("no body framing is active")
        if framing.kind == _LENGTH:
            if framing.remaining == 0:
                return self._finish_body()
            if buf:
                n = min(len(buf), framing.remaining)
                data = bytes(buf[:n])
                del buf[:n]
                framing.remaining -= n
                return ev.Data(data)
            if self._closed:
                raise self._remote("connection closed in the middle of a Content-Length body")
            return NEED_DATA
        if framing.kind == _EMPTY:
            return self._finish_body()
        if framing.kind == _CLOSE:
            if buf:
                data = bytes(buf)
                del buf[:]
                return ev.Data(data)
            if self._closed:
                return self._finish_body()
            return NEED_DATA
        return self._pull_chunked(framing)

    def _finish_body(self, pairs=None):
        try:
            event = ev.EndOfMessage(headers=pairs)
        except LocalProtocolError as exc:
            raise self._remote(str(exc), exc.error_status_hint)
        self._recv_framing = None
        self._fire(self._their_role, event, pulled=True)
        return event

    def _pull_chunked(self, framing):
        buf = self._buf
        while True:
            if framing.cstate == "size":
                nl = buf.find(b"\n")
                if nl < 0:
                    if self._closed:
                        raise self._remote("connection closed in the middle of a chunk-size line")
                    return NEED_DATA
                line = bytes(buf[:nl])
                if line.endswith(b"\r"):
                    line = line[:-1]
                match = _CHUNK_SIZE_RE.fullmatch(line)
                if match is None or len(match.group(1)) > MAX_CHUNK_SIZE_DIGITS:
                    raise self._remote("invalid chunk-size line")
                del buf[:nl + 1]
                size = int(match.group(1), 16)
                if size == 0:
                    framing.cstate = "trailers"
                else:
                    framing.cstate = "data"
                    framing.chunk_remaining = size
                    framing.first = True
            elif framing.cstate == "data":
                if not buf:
                    if self._closed:
                        raise self._remote("connection closed in the middle of a chunk")
                    return NEED_DATA
                n = min(len(buf), framing.chunk_remaining)
                data = bytes(buf[:n])
                del buf[:n]
                framing.chunk_remaining -= n
                start = framing.first
                framing.first = False
                end = framing.chunk_remaining == 0
                if end:
                    framing.cstate = "crlf"
                return ev.Data(data, chunk_start=start, chunk_end=end)
            elif framing.cstate == "crlf":
                if len(buf) < 2:
                    if self._closed:
                        raise self._remote("connection closed in the middle of a chunk")
                    return NEED_DATA
                if bytes(buf[:2]) != _CRLF:
                    raise self._remote("chunk data is not followed by CRLF")
                del buf[:2]
                framing.cstate = "size"
            else:  # trailers
                end = _find_head_end(buf)
                if end < 0:
                    if len(buf) > self._max_size:
                        raise self._remote(
                            "trailer block exceeds the incomplete-event size limit", 431
                        )
                    if self._closed:
                        raise self._remote("connection closed in the middle of trailers")
                    return NEED_DATA
                try:
                    pairs = _parse_header_lines(_split_head(bytes(buf[:end])))
                except LocalProtocolError as exc:
                    raise self._remote(str(exc), exc.error_status_hint)
                del buf[:end]
                return self._finish_body(pairs)

    # ------------------------------------------------------------------
    # Cycle control
    # ------------------------------------------------------------------

    def start_next_cycle(self):
        if self._states[CLIENT] is not DONE or self._states[SERVER] is not DONE:
            raise LocalProtocolError("cannot start the next cycle: both sides must be DONE", 400)
        self._states = {CLIENT: IDLE, SERVER: IDLE}
        self._their_http_version = None
        self._request_method = None
        self._blocked = False
        self._pending = set()
        self._client_waiting = False
        self._send_framing = None
        self._recv_framing = None
        return None

    # ------------------------------------------------------------------
    # State machine
    # ------------------------------------------------------------------

    def _fire(self, producer, event, pulled):
        """Apply the state transition for an event produced by ``producer``."""
        states = self._states
        t = type(event)
        if t is ev.Request:
            items = list(event.headers._triples())
            self._request_method = event.method
            if pulled:
                self._their_http_version = event.http_version
            if event.method == b"CONNECT":
                self._pending.add(_PROPOSE_CONNECT)
            if _find(items, b"upgrade") is not None:
                self._pending.add(_PROPOSE_UPGRADE)
            if event.http_version == b"1.1" and b"100-continue" in _tokens(items, b"expect"):
                self._client_waiting = True
            if event.http_version != b"1.1" or b"close" in _tokens(items, _CONNECTION):
                self._blocked = True
            states[CLIENT] = SEND_BODY
            states[SERVER] = SEND_RESPONSE
        elif t is ev.InformationalResponse:
            self._client_waiting = False
            if event.status_code == 101 and _PROPOSE_UPGRADE in self._pending:
                self._accept_switch()
        elif t is ev.Response:
            items = list(event.headers._triples())
            if pulled:
                self._their_http_version = event.http_version
            if event.http_version != b"1.1" or b"close" in _tokens(items, _CONNECTION):
                self._blocked = True
            self._client_waiting = False
            if event.status_code == 200 and _PROPOSE_CONNECT in self._pending:
                self._accept_switch()
            else:
                # A final response that does not accept is a denial.
                self._pending = set()
                if states[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                    states[CLIENT] = DONE
                states[SERVER] = SEND_BODY
        elif t is ev.Data:
            if producer is CLIENT:
                self._client_waiting = False
        elif t is ev.EndOfMessage:
            if producer is CLIENT:
                self._client_waiting = False
                states[CLIENT] = MIGHT_SWITCH_PROTOCOL if self._pending else DONE
            else:
                states[SERVER] = DONE
        elif t is ev.ConnectionClosed:
            states[producer] = CLOSED
        self._normalize()

    def _accept_switch(self):
        self._pending = set()
        self._states[CLIENT] = SWITCHED_PROTOCOL
        self._states[SERVER] = SWITCHED_PROTOCOL

    def _normalize(self):
        """Apply the rules that couple the two sides' states."""
        states = self._states
        changed = True
        while changed:
            changed = False
            for side in (CLIENT, SERVER):
                other = _other(side)
                if states[side] is CLOSED and states[other] in (IDLE, DONE):
                    states[other] = MUST_CLOSE
                    changed = True
                if states[side] is ERROR and states[other] is DONE:
                    states[other] = MUST_CLOSE
                    changed = True
                if self._blocked and states[side] is DONE:
                    states[side] = MUST_CLOSE
                    changed = True
