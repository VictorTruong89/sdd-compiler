"""Protocol error classes (PRD FP-05).

``LocalProtocolError`` and ``RemoteProtocolError`` are siblings: neither is a
subclass of the other. Both carry ``error_status_hint``, the suggested HTTP
status for the violation (default 400).
"""


class _ProtocolErrorBase(Exception):
    def __init__(self, message="", error_status_hint=400):
        Exception.__init__(self, message)
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(_ProtocolErrorBase):
    """The integrator's own event or send violated HTTP/1.1."""


class RemoteProtocolError(_ProtocolErrorBase):
    """The peer's bytes violated HTTP/1.1."""
