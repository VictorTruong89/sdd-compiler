"""Role values, state values, and the two non-event pull results.

Every object here is a unique sentinel: two different sentinels never compare
equal, and none of them is a string or an event.
"""


class _Marker(object):
    """A named, identity-compared sentinel."""

    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return "<httpwire.%s>" % self._name

    def __reduce__(self):
        return self._name


# Roles
CLIENT = _Marker("CLIENT")
SERVER = _Marker("SERVER")

# States (PRD FP-02)
IDLE = _Marker("IDLE")
SEND_RESPONSE = _Marker("SEND_RESPONSE")
SEND_BODY = _Marker("SEND_BODY")
DONE = _Marker("DONE")
MUST_CLOSE = _Marker("MUST_CLOSE")
CLOSED = _Marker("CLOSED")
MIGHT_SWITCH_PROTOCOL = _Marker("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = _Marker("SWITCHED_PROTOCOL")
ERROR = _Marker("ERROR")

# Non-event results of Connection.next_event()
NEED_DATA = _Marker("NEED_DATA")
PAUSED = _Marker("PAUSED")
