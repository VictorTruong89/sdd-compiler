"""Behavioral tests for httpwire, written against the PRD and Interface Contract."""

import unittest

import httpwire
from httpwire import (
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
    ConnectionClosed,
    Connection,
    Data,
    EndOfMessage,
    InformationalResponse,
    LocalProtocolError,
    RemoteProtocolError,
    Request,
    Response,
)


def pull_all(conn):
    events = []
    while True:
        event = conn.next_event()
        if event is NEED_DATA or event is PAUSED:
            return events, event
        events.append(event)
        if isinstance(event, ConnectionClosed):
            return events, event


class PackageSurfaceTests(unittest.TestCase):
    def test_root_names_exist(self):
        for name in httpwire.__all__:
            self.assertTrue(hasattr(httpwire, name), name)

    def test_roles_and_states_are_distinct(self):
        states = [IDLE, SEND_RESPONSE, SEND_BODY, DONE, MUST_CLOSE, CLOSED,
                  MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL, ERROR]
        self.assertEqual(len(set(id(s) for s in states)), 9)
        self.assertIsNot(CLIENT, SERVER)
        self.assertNotEqual(CLIENT, SERVER)
        self.assertIsNot(NEED_DATA, PAUSED)

    def test_protocol_errors_are_siblings(self):
        self.assertFalse(issubclass(LocalProtocolError, RemoteProtocolError))
        self.assertFalse(issubclass(RemoteProtocolError, LocalProtocolError))

    def test_bad_role_refused(self):
        with self.assertRaises(Exception):
            Connection("client")


class EventTests(unittest.TestCase):
    def test_request_defaults_and_bytes(self):
        r = Request(method="GET", target="/", headers=[("Host", "a")])
        self.assertEqual(r.method, b"GET")
        self.assertEqual(r.target, b"/")
        self.assertEqual(r.http_version, b"1.1")
        self.assertIsInstance(r.method, bytes)

    def test_header_normalization(self):
        r = Request(method="GET", target="/", headers=[("HOST", "a"), ("X-Thing", "V")])
        self.assertEqual(list(r.headers), [(b"host", b"a"), (b"x-thing", b"V")])
        self.assertEqual(r.headers.raw_items(), [(b"HOST", b"a"), (b"X-Thing", b"V")])

    def test_host_rules(self):
        with self.assertRaises(LocalProtocolError):
            Request(method="GET", target="/", headers=[])
        with self.assertRaises(LocalProtocolError):
            Request(method="GET", target="/", headers=[("Host", "a"), ("host", "b")])
        Request(method="GET", target="/", headers=[], http_version=b"1.0")
        with self.assertRaises(LocalProtocolError):
            Request(method="GET", target="/", headers=[("Host", "a"), ("Host", "b")], http_version=b"1.0")

    def test_content_length_collapse_and_conflict(self):
        r = Request(method="POST", target="/", headers=[
            ("Host", "a"), ("Content-Length", "5"), ("content-length", "5"), ("Content-Length", "5, 5")])
        self.assertEqual(list(r.headers), [(b"host", b"a"), (b"content-length", b"5")])
        with self.assertRaises(LocalProtocolError):
            Request(method="POST", target="/", headers=[("Host", "a"), ("Content-Length", "5"), ("Content-Length", "6")])
        with self.assertRaises(LocalProtocolError):
            Request(method="POST", target="/", headers=[("Host", "a"), ("Content-Length", "5x")])
        with self.assertRaises(LocalProtocolError):
            Request(method="POST", target="/", headers=[("Host", "a"), ("Content-Length", "1" * 19)])

    def test_transfer_encoding_rules(self):
        r = Request(method="POST", target="/", headers=[("Host", "a"), ("Transfer-Encoding", "CHUNKED")])
        self.assertEqual(list(r.headers)[1], (b"transfer-encoding", b"chunked"))
        with self.assertRaises(LocalProtocolError) as ctx:
            Request(method="POST", target="/", headers=[("Host", "a"), ("Transfer-Encoding", "gzip, chunked")])
        self.assertEqual(ctx.exception.error_status_hint, 501)
        with self.assertRaises(LocalProtocolError) as ctx:
            Request(method="POST", target="/", headers=[("Host", "a"),
                                                       ("Transfer-Encoding", "chunked"),
                                                       ("Transfer-Encoding", "chunked")])
        self.assertEqual(ctx.exception.error_status_hint, 501)

    def test_header_value_rules(self):
        with self.assertRaises(LocalProtocolError):
            Request(method="GET", target="/", headers=[("Host", " a")])
        with self.assertRaises(LocalProtocolError):
            Request(method="GET", target="/", headers=[("Host", "a\x01")])
        with self.assertRaises(LocalProtocolError):
            Request(method="GET", target="/", headers=[("Host", "a"), ("Bad Name", "x")])
        Request(method="GET", target="/", headers=[("Host", "a"), ("X", "\xff".encode("latin-1"))])

    def test_target_and_method_rules(self):
        with self.assertRaises(LocalProtocolError):
            Request(method="GET", target="/a b", headers=[("Host", "a")])
        with self.assertRaises(LocalProtocolError):
            Request(method="G E", target="/", headers=[("Host", "a")])

    def test_status_ranges(self):
        with self.assertRaises(LocalProtocolError):
            InformationalResponse(200)
        with self.assertRaises(LocalProtocolError):
            Response(199)
        with self.assertRaises(LocalProtocolError):
            Response(1000)
        with self.assertRaises(LocalProtocolError):
            Response("200")
        r = Response(200)
        self.assertEqual(r.http_version, b"1.1")
        self.assertEqual(r.reason, b"")

    def test_data_and_eom_and_closed(self):
        self.assertEqual(Data(b"x").data, b"x")
        self.assertEqual(EndOfMessage().headers, [])
        self.assertIsInstance(ConnectionClosed(), ConnectionClosed)


class SendTests(unittest.TestCase):
    def test_request_bytes_host_first(self):
        c = Connection(CLIENT)
        out = c.send(Request(method="GET", target="/x", headers=[("X-A", "1"), ("Host", "h")]))
        self.assertEqual(out, b"GET /x HTTP/1.1\r\nHost: h\r\nX-A: 1\r\n\r\n")
        self.assertEqual(c.our_state, SEND_BODY)
        self.assertEqual(c.their_state, SEND_RESPONSE)
        self.assertIsNone(c.their_http_version)

    def test_server_cannot_send_request(self):
        s = Connection(SERVER)
        with self.assertRaises(LocalProtocolError):
            s.send(Request(method="GET", target="/", headers=[("Host", "h")]))
        self.assertEqual(s.our_state, ERROR)

    def test_second_request_refused_and_error(self):
        c = Connection(CLIENT)
        c.send(Request(method="GET", target="/", headers=[("Host", "h")]))
        c.send(EndOfMessage())
        with self.assertRaises(LocalProtocolError):
            c.send(Request(method="GET", target="/", headers=[("Host", "h")]))
        self.assertEqual(c.our_state, ERROR)
        with self.assertRaises(LocalProtocolError):
            c.send(EndOfMessage())

    def test_content_length_enforced(self):
        c = Connection(CLIENT)
        c.send(Request(method="POST", target="/", headers=[("Host", "h"), ("Content-Length", "3")]))
        c.send(Data(b"ab"))
        with self.assertRaises(LocalProtocolError):
            c.send(EndOfMessage())
        self.assertEqual(c.our_state, ERROR)

    def test_content_length_exceeded(self):
        c = Connection(CLIENT)
        c.send(Request(method="POST", target="/", headers=[("Host", "h"), ("Content-Length", "1")]))
        with self.assertRaises(LocalProtocolError):
            c.send(Data(b"ab"))

    def test_chunked_encoding(self):
        c = Connection(CLIENT)
        out = c.send(Request(method="POST", target="/", headers=[("Host", "h"), ("Transfer-Encoding", "chunked")]))
        self.assertIn(b"Transfer-Encoding: chunked", out)
        self.assertEqual(c.send(Data(b"hello")), b"5\r\nhello\r\n")
        self.assertEqual(c.send(Data(b"")), b"")
        self.assertEqual(c.send(EndOfMessage(headers=[("X-T", "1")])), b"0\r\nX-T: 1\r\n\r\n")

    def test_passthrough_keeps_object_identity(self):
        class Blob(object):
            def __init__(self, n):
                self.n = n

            def __len__(self):
                return self.n

        blob = Blob(4)
        c = Connection(CLIENT)
        c.send(Request(method="POST", target="/", headers=[("Host", "h"), ("Transfer-Encoding", "chunked")]))
        pieces = c.send_with_data_passthrough(Data(blob))
        self.assertIs(pieces[1], blob)
        self.assertEqual(pieces[0], b"4\r\n")
        self.assertEqual(pieces[2], b"\r\n")

    def test_send_connection_closed_produces_no_bytes(self):
        c = Connection(CLIENT)
        self.assertEqual(c.send(ConnectionClosed()), b"")
        self.assertEqual(c.our_state, CLOSED)
        self.assertEqual(c.their_state, MUST_CLOSE)

    def test_response_bytes_and_framing_headers(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
        self.assertIsInstance(s.next_event(), Request)
        self.assertIsInstance(s.next_event(), EndOfMessage)
        out = s.send(Response(200, headers=[("Content-Type", "text/plain")], reason=b"OK"))
        self.assertEqual(out, b"HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nTransfer-Encoding: chunked\r\n\r\n")
        self.assertEqual(s.send(Data(b"hi")), b"2\r\nhi\r\n")
        self.assertEqual(s.send(EndOfMessage()), b"0\r\n\r\n")
        self.assertEqual(s.our_state, DONE)

    def test_response_content_length_zero_kept(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
        s.next_event()
        s.next_event()
        out = s.send(Response(200, headers=[("Content-Length", "0")], reason=b"OK"))
        self.assertIn(b"Content-Length: 0", out)

    def test_head_response_has_no_body(self):
        s = Connection(SERVER)
        s.receive_data(b"HEAD / HTTP/1.1\r\nHost: h\r\n\r\n")
        s.next_event()
        s.next_event()
        out = s.send(Response(200, headers=[("Content-Length", "10")], reason=b"OK"))
        self.assertIn(b"Content-Length: 10", out)
        self.assertEqual(s.send(EndOfMessage()), b"")

    def test_http10_peer_gets_close_delimited_response(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.0\r\n\r\n")
        self.assertIsInstance(s.next_event(), Request)
        self.assertEqual(s.next_event(), EndOfMessage())
        out = s.send(Response(200, reason=b"OK"))
        self.assertEqual(out, b"HTTP/1.1 200 OK\r\nConnection: close\r\n\r\n")
        self.assertEqual(s.send(Data(b"raw")), b"raw")
        self.assertEqual(s.send(EndOfMessage()), b"")
        self.assertEqual(s.our_state, MUST_CLOSE)

    def test_server_in_idle_can_send_final_response(self):
        s = Connection(SERVER)
        out = s.send(Response(400, reason=b"Bad Request"))
        self.assertEqual(out, b"HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n")
        self.assertEqual(s.our_state, SEND_BODY)

    def test_send_failed_puts_side_in_error(self):
        c = Connection(CLIENT)
        c.send(Request(method="GET", target="/", headers=[("Host", "h")]))
        c.send(EndOfMessage())
        self.assertEqual(c.send_failed(), None)
        self.assertEqual(c.our_state, ERROR)
        with self.assertRaises(LocalProtocolError):
            c.send(EndOfMessage())


class ReceiveTests(unittest.TestCase):
    def test_need_data_and_two_step_receive(self):
        s = Connection(SERVER)
        self.assertIs(s.next_event(), NEED_DATA)
        s.receive_data(b"GET / HTTP/1.1\r\nHo")
        self.assertIs(s.next_event(), NEED_DATA)
        self.assertEqual(s.their_state, IDLE)
        s.receive_data(b"st: h\r\n\r\n")
        self.assertIsInstance(s.next_event(), Request)
        self.assertEqual(s.their_http_version, b"1.1")

    def test_lone_lf_accepted(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\nHost: h\n\n")
        self.assertIsInstance(s.next_event(), Request)

    def test_obsolete_folding_joined(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\nX-A: one\r\n   two\r\n\r\n")
        req = s.next_event()
        self.assertEqual(dict(req.headers)[b"x-a"], b"one two")

    def test_leading_space_is_remote_error_immediately(self):
        s = Connection(SERVER)
        s.receive_data(b" GET")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()
        self.assertEqual(s.their_state, ERROR)
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    def test_size_limit_gives_431(self):
        s = Connection(SERVER, 100)
        s.receive_data(b"GET / HTTP/1.1\r\n" + b"X: " + b"a" * 200)
        with self.assertRaises(RemoteProtocolError) as ctx:
            s.next_event()
        self.assertEqual(ctx.exception.error_status_hint, 431)

    def test_default_limit_is_between_14_and_18_kib(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\n" + b"X: " + b"a" * (15 * 1024))
        self.assertIs(s.next_event(), NEED_DATA)

    def test_content_length_body_pulled_as_data(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nContent-Length: 5\r\n\r\nhe")
        self.assertIsInstance(s.next_event(), Request)
        self.assertEqual(s.next_event().data, b"he")
        self.assertIs(s.next_event(), NEED_DATA)
        s.receive_data(b"llo")
        self.assertEqual(s.next_event().data, b"llo")
        self.assertIsInstance(s.next_event(), EndOfMessage)
        self.assertEqual(s.their_state, DONE)

    def test_chunked_body_marks_and_trailers(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n")
        s.next_event()
        s.receive_data(b"3;ext=1\r\nab")
        d = s.next_event()
        self.assertEqual(d.data, b"ab")
        self.assertTrue(d.chunk_start)
        self.assertFalse(d.chunk_end)
        self.assertIs(s.next_event(), NEED_DATA)
        s.receive_data(b"c\r\n3\r\nxyz\r\n0\r\nT: v\r\n\r\n")
        d = s.next_event()
        self.assertEqual(d.data, b"c")
        self.assertIs(d.chunk_start, False)
        self.assertIs(d.chunk_end, True)
        d = s.next_event()
        self.assertEqual(d.data, b"xyz")
        self.assertTrue(d.chunk_start and d.chunk_end)
        eom = s.next_event()
        self.assertIsInstance(eom, EndOfMessage)
        self.assertEqual(eom.headers.raw_items(), [(b"T", b"v")])

    def test_chunk_size_line_rules(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n1x\r\n")
        s.next_event()
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    def test_chunk_crlf_required(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n2\r\nabXX")
        s.next_event()
        s.next_event()
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    def test_close_mid_body_is_remote_error(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nContent-Length: 5\r\n\r\nab")
        s.next_event()
        s.next_event()
        s.receive_data(b"")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    def test_feed_after_close_is_runtime_error(self):
        s = Connection(SERVER)
        s.receive_data(b"")
        with self.assertRaises(Exception) as ctx:
            s.receive_data(b"x")
        self.assertNotIsInstance(ctx.exception, (LocalProtocolError, RemoteProtocolError))

    def test_remote_error_then_error_response_closes(self):
        s = Connection(SERVER)
        s.receive_data(b"BAD\x01 / HTTP/1.1\r\nHost: h\r\n\r\n")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()
        self.assertEqual(s.their_state, ERROR)
        out = s.send(Response(400, headers=[("Content-Length", "0")]))
        self.assertIn(b"Connection: close", out)
        self.assertEqual(s.our_state, SEND_BODY)


class CycleTests(unittest.TestCase):
    def test_keep_alive_full_cycles(self):
        c, s = Connection(CLIENT), Connection(SERVER)
        for _ in range(2):
            s.receive_data(c.send(Request(method="GET", target="/", headers=[("Host", "h")])))
            c.send(EndOfMessage())
            self.assertIsInstance(s.next_event(), Request)
            self.assertIsInstance(s.next_event(), EndOfMessage)
            c.receive_data(s.send(Response(200, headers=[("Content-Length", "2")])) + s.send(Data(b"ok")) + s.send(EndOfMessage()))
            self.assertIsInstance(c.next_event(), Response)
            self.assertIsInstance(c.next_event(), Data)
            self.assertIsInstance(c.next_event(), EndOfMessage)
            self.assertEqual((c.our_state, c.their_state), (DONE, DONE))
            self.assertEqual((s.our_state, s.their_state), (DONE, DONE))
            c.start_next_cycle()
            s.start_next_cycle()
            self.assertEqual((c.our_state, s.our_state), (IDLE, IDLE))

    def test_start_next_cycle_refused_before_done(self):
        c = Connection(CLIENT)
        c.send(Request(method="GET", target="/", headers=[("Host", "h")]))
        with self.assertRaises(LocalProtocolError):
            c.start_next_cycle()
        self.assertEqual(c.our_state, SEND_BODY)

    def test_connection_close_disables_keepalive(self):
        c, s = Connection(CLIENT), Connection(SERVER)
        s.receive_data(c.send(Request(method="GET", target="/", headers=[("Host", "h"), ("Connection", "close")])))
        c.send(EndOfMessage())
        s.next_event()
        s.next_event()
        out = s.send(Response(200, headers=[("Content-Length", "0")]))
        self.assertIn(b"Connection: close", out)
        s.send(EndOfMessage())
        self.assertEqual(s.our_state, MUST_CLOSE)
        self.assertEqual(c.our_state, MUST_CLOSE)

    def test_pipelined_requests_are_paused_until_next_cycle(self):
        c, s = Connection(CLIENT), Connection(SERVER)
        raw = (b"GET /a HTTP/1.1\r\nHost: h\r\n\r\n" b"GET /b HTTP/1.1\r\nHost: h\r\n\r\n")
        s.receive_data(raw)
        self.assertIsInstance(s.next_event(), Request)
        self.assertIsInstance(s.next_event(), EndOfMessage)
        s.send(Response(200, headers=[("Content-Length", "0")]))
        s.send(EndOfMessage())
        self.assertEqual(s.their_state, DONE)
        self.assertIs(s.next_event(), PAUSED)
        s.receive_data(b"")
        self.assertIs(s.next_event(), PAUSED)
        self.assertEqual(s.trailing_data, (b"GET /b HTTP/1.1\r\nHost: h\r\n\r\n", True))

    def test_client_half_close_yields_connection_closed(self):
        s = Connection(SERVER)
        s.receive_data(b"")
        self.assertIsInstance(s.next_event(), ConnectionClosed)
        self.assertIsInstance(s.next_event(), ConnectionClosed)
        self.assertEqual(s.their_state, CLOSED)
        self.assertEqual(s.our_state, MUST_CLOSE)

    def test_http10_response_close_delimited_body(self):
        c, s = Connection(CLIENT), Connection(SERVER)
        s.receive_data(c.send(Request(method="GET", target="/", headers=[("Host", "h")])))
        c.send(EndOfMessage())
        s.next_event()
        s.next_event()
        c.receive_data(b"HTTP/1.0 200 OK\r\n\r\nbody-bytes")
        self.assertIsInstance(c.next_event(), Response)
        self.assertEqual(c.next_event().data, b"body-bytes")
        self.assertIs(c.next_event(), NEED_DATA)
        c.receive_data(b"")
        self.assertIsInstance(c.next_event(), EndOfMessage)
        self.assertIsInstance(c.next_event(), ConnectionClosed)
        self.assertEqual(c.our_state, MUST_CLOSE)


class InformationalAndSwitchTests(unittest.TestCase):
    def test_expect_continue_flags(self):
        c, s = Connection(CLIENT), Connection(SERVER)
        c.send(Request(method="PUT", target="/", headers=[("Host", "h"), ("Expect", "100-Continue"),
                                                          ("Content-Length", "1")]))
        self.assertTrue(c.client_is_waiting_for_100_continue)
        self.assertFalse(c.they_are_waiting_for_100_continue)
        s2 = Connection(SERVER)
        s2.receive_data(b"PUT / HTTP/1.1\r\nHost: h\r\nExpect: 100-continue\r\nContent-Length: 1\r\n\r\n")
        s2.next_event()
        self.assertTrue(s2.they_are_waiting_for_100_continue)
        s2.send(InformationalResponse(100))
        self.assertFalse(s2.they_are_waiting_for_100_continue)

    def test_expect_on_http10_does_not_set_flag(self):
        # httpwire only sends HTTP/1.1, so an HTTP/1.0 Expect request arrives from the peer.
        s = Connection(SERVER)
        s.receive_data(b"PUT / HTTP/1.0\r\nExpect: 100-continue\r\nContent-Length: 0\r\n\r\n")
        self.assertIsInstance(s.next_event(), Request)
        self.assertFalse(s.client_is_waiting_for_100_continue)
        self.assertFalse(s.they_are_waiting_for_100_continue)
        c = Connection(CLIENT)
        with self.assertRaises(LocalProtocolError):
            c.send(Request(method="PUT", target="/", headers=[("Host", "h")], http_version=b"1.0"))

    def test_informational_then_final(self):
        c, s = Connection(CLIENT), Connection(SERVER)
        s.receive_data(c.send(Request(method="GET", target="/", headers=[("Host", "h")])))
        c.send(EndOfMessage())
        s.next_event()
        s.next_event()
        c.receive_data(s.send(InformationalResponse(102)) + s.send(Response(200, headers=[("Content-Length", "0")])))
        self.assertIsInstance(c.next_event(), InformationalResponse)
        self.assertIsInstance(c.next_event(), Response)

    def test_connect_accepted_switches(self):
        c, s = Connection(CLIENT), Connection(SERVER)
        s.receive_data(c.send(Request(method="CONNECT", target="example:443", headers=[("Host", "example:443")])))
        c.send(EndOfMessage())
        self.assertEqual(c.their_state, SEND_RESPONSE)
        self.assertEqual(c.our_state, MIGHT_SWITCH_PROTOCOL)
        self.assertIsInstance(s.next_event(), Request)
        self.assertIsInstance(s.next_event(), EndOfMessage)
        out = s.send(Response(200))
        self.assertEqual(out, b"HTTP/1.1 200 \r\n\r\n")
        self.assertEqual(s.our_state, SWITCHED_PROTOCOL)
        c.receive_data(out + b"raw-tunnel")
        self.assertIsInstance(c.next_event(), Response)
        self.assertEqual((s.our_state, c.our_state), (SWITCHED_PROTOCOL, SWITCHED_PROTOCOL))
        self.assertIs(c.next_event(), PAUSED)
        self.assertEqual(c.trailing_data, (b"raw-tunnel", False))
        with self.assertRaises(LocalProtocolError):
            s.send(Data(b"x"))

    def test_connect_denied_continues_http(self):
        c, s = Connection(CLIENT), Connection(SERVER)
        s.receive_data(c.send(Request(method="CONNECT", target="x:1", headers=[("Host", "x:1")])))
        c.send(EndOfMessage())
        self.assertEqual(c.our_state, MIGHT_SWITCH_PROTOCOL)
        self.assertIsInstance(s.next_event(), Request)
        self.assertIsInstance(s.next_event(), EndOfMessage)
        self.assertIs(s.next_event(), PAUSED)
        c.receive_data(s.send(Response(403, headers=[("Content-Length", "0")])) + s.send(EndOfMessage()))
        self.assertIsInstance(c.next_event(), Response)
        self.assertEqual(c.our_state, DONE)
        self.assertIsInstance(c.next_event(), EndOfMessage)
        self.assertEqual((c.our_state, c.their_state), (DONE, DONE))

    def test_upgrade_101_accepted(self):
        c, s = Connection(CLIENT), Connection(SERVER)
        s.receive_data(c.send(Request(method="GET", target="/ws", headers=[("Host", "h"), ("Upgrade", "websocket"), ("Connection", "upgrade")])))
        c.send(EndOfMessage())
        s.next_event()
        s.next_event()
        wire = s.send(InformationalResponse(101, headers=[("Upgrade", "websocket"), ("Connection", "Upgrade")]))
        self.assertEqual(s.our_state, SWITCHED_PROTOCOL)
        c.receive_data(wire + b"ws-frames")
        self.assertIsInstance(c.next_event(), InformationalResponse)
        self.assertEqual((c.our_state, c.their_state), (SWITCHED_PROTOCOL, SWITCHED_PROTOCOL))
        self.assertIs(c.next_event(), PAUSED)
        self.assertEqual(c.trailing_data, (b"ws-frames", False))

    def test_switch_not_resumed_by_next_cycle(self):
        s = Connection(SERVER)
        s.receive_data(b"CONNECT x:1 HTTP/1.1\r\nHost: x:1\r\n\r\n")
        s.next_event()
        s.next_event()
        s.send(Response(200))
        with self.assertRaises(LocalProtocolError):
            s.start_next_cycle()


def _normalize(events):
    """Merge consecutive data events so splits made by feed sizes do not matter."""
    out = []
    for event in events:
        if isinstance(event, Data):
            if out and out[-1][0] == "Data":
                out[-1] = ("Data", out[-1][1] + event.data)
            else:
                out.append(("Data", event.data))
        else:
            out.append((type(event).__name__, list(getattr(event, "headers", []))))
    return out


class IncrementalParsingTests(unittest.TestCase):
    def _run(self, step):
        c, s = Connection(CLIENT), Connection(SERVER)
        req = c.send(Request("POST", "/up", [("Host", "h"), ("Transfer-Encoding", "chunked")]))
        req += c.send(Data(b"hello world")) + c.send(Data(b"!!"))
        req += c.send(EndOfMessage(headers=[("X-Sum", "1")]))

        def feed(conn, data):
            got = []
            for i in range(0, len(data), step):
                conn.receive_data(data[i:i + step])
                while True:
                    event = conn.next_event()
                    if event is NEED_DATA or event is PAUSED:
                        break
                    got.append(event)
            return got

        got_req = feed(s, req)
        resp = s.send(Response(200, [("Content-Type", "x")]))
        resp += s.send(Data(b"0123456789abcdef")) + s.send(Data(b"end")) + s.send(EndOfMessage())
        got_resp = feed(c, resp)
        return _normalize(got_req), _normalize(got_resp), (c.their_state, s.their_state)

    def test_same_events_regardless_of_feed_size(self):
        reference = self._run(10 ** 9)
        self.assertEqual(reference[2], (DONE, DONE))
        self.assertEqual(reference[0][1], ("Data", b"hello world!!"))
        self.assertEqual(reference[1][1], ("Data", b"0123456789abcdefend"))
        for step in (1, 2, 3, 7):
            self.assertEqual(self._run(step), reference, "feed size %d" % step)


if __name__ == "__main__":
    unittest.main()
