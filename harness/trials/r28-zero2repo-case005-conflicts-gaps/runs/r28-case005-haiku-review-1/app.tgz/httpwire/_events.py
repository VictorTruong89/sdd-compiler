"""HTTP events (FP-01): construction checks and header normalization."""

import re

from ._util import CONTROL_RE, TOKEN_RE, VISIBLE_RE, VERSION_RE, LocalProtocolError, to_bytes

# Content-Length piece: decimal digits, at most 18 (NOTES.md, conflict 1).
_CONTENT_LENGTH_PIECE_RE = re.compile(rb"[0-9]{1,18}")


def _check_name(name):
    if not TOKEN_RE.fullmatch(name):
        raise LocalProtocolError("invalid header name %r" % (name,))


def _check_value(value):
    if value[:1] in (b" ", b"\t") or value[-1:] in (b" ", b"\t"):
        raise LocalProtocolError("header value may not begin or end with space or tab")
    if CONTROL_RE.search(value):
        raise LocalProtocolError("header value contains a control byte")


def _normalize_headers(items):
    """Validate and normalize (name, value) pairs.

    Returns a list of [raw_name, lowercase_name, value] entries.
    """
    try:
        items = list(items)
    except TypeError:
        raise LocalProtocolError("headers must be a sequence of (name, value) pairs")

    entries = []
    content_length_index = None
    content_lengths = []
    transfer_encoding_seen = False
    for item in items:
        try:
            raw_name, raw_value = item
        except (TypeError, ValueError):
            raise LocalProtocolError("headers must be (name, value) pairs")
        name = to_bytes(raw_name, "header name")
        value = to_bytes(raw_value, "header value")
        _check_name(name)
        _check_value(value)
        lname = name.lower()
        if lname == b"content-length":
            for piece in value.split(b","):
                piece = piece.strip(b" \t")
                if not _CONTENT_LENGTH_PIECE_RE.fullmatch(piece):
                    raise LocalProtocolError("invalid Content-Length value")
                content_lengths.append(int(piece))
            if content_length_index is None:
                content_length_index = len(entries)
                entries.append([name, lname, None])
        elif lname == b"transfer-encoding":
            if transfer_encoding_seen:
                raise LocalProtocolError("second Transfer-Encoding header", 501)
            transfer_encoding_seen = True
            if value.strip(b" \t").lower() != b"chunked":
                raise LocalProtocolError("only the chunked transfer coding is supported", 501)
            entries.append([name, lname, b"chunked"])
        else:
            entries.append([name, lname, value])

    if content_lengths:
        if any(length != content_lengths[0] for length in content_lengths):
            raise LocalProtocolError("conflicting Content-Length values")
        entries[content_length_index][2] = str(content_lengths[0]).encode("ascii")
    return entries


class Headers(list):
    """Ordinary header view: a list of (lowercase_name, value) bytes pairs.

    raw_items() returns the same pairs with each name exactly as the caller spelled it.
    """

    def __init__(self, items=()):
        entries = _normalize_headers(items)
        list.__init__(self, [(entry[1], entry[2]) for entry in entries])
        self._raw = [(entry[0], entry[2]) for entry in entries]

    def raw_items(self):
        return list(self._raw)

    def __repr__(self):
        return "Headers(%r)" % (list(self),)


def _token(value, what):
    value = to_bytes(value, what)
    if not TOKEN_RE.fullmatch(value):
        raise LocalProtocolError("%s must be an RFC 7230 token" % what)
    return value


def _visible(value, what):
    value = to_bytes(value, what)
    if not VISIBLE_RE.fullmatch(value):
        raise LocalProtocolError("%s must be visible ASCII" % what)
    return value


def _version(value):
    value = to_bytes(value, "http_version")
    if not VERSION_RE.fullmatch(value):
        raise LocalProtocolError("http_version must look like 1.1")
    return value


def _status(value, low, high):
    if isinstance(value, bool) or not isinstance(value, int):
        raise LocalProtocolError("status code must be an integer")
    value = int(value)
    if not low <= value < high:
        raise LocalProtocolError("status code %d is out of range" % value)
    return value


def _reason(value):
    value = to_bytes(value, "reason")
    if CONTROL_RE.search(value):
        raise LocalProtocolError("reason phrase contains a control byte")
    return value


class _Event(object):
    _FIELDS = ()

    def _field_values(self):
        return tuple(getattr(self, name) for name in self._FIELDS)

    def __eq__(self, other):
        return type(other) is type(self) and other._field_values() == self._field_values()

    def __ne__(self, other):
        return not self.__eq__(other)

    __hash__ = None

    def __repr__(self):
        parts = ", ".join("%s=%r" % (name, getattr(self, name)) for name in self._FIELDS)
        return "%s(%s)" % (type(self).__name__, parts)


class Request(_Event):
    _FIELDS = ("method", "target", "headers", "http_version")

    def __init__(self, method, target, headers=(), http_version=b"1.1"):
        self.method = _token(method, "method")
        self.target = _visible(target, "target")
        self.http_version = _version(http_version)
        self.headers = Headers(headers)
        hosts = sum(1 for name, _ in self.headers if name == b"host")
        if hosts > 1:
            raise LocalProtocolError("request has more than one Host header")
        if hosts == 0 and self.http_version == b"1.1":
            raise LocalProtocolError("HTTP/1.1 request needs exactly one Host header")


class _ResponseBase(_Event):
    _FIELDS = ("status_code", "headers", "http_version", "reason")
    _LOW = 0
    _HIGH = 0

    def __init__(self, status_code, headers=(), http_version=b"1.1", reason=b""):
        self.status_code = _status(status_code, self._LOW, self._HIGH)
        self.headers = Headers(headers)
        self.http_version = _version(http_version)
        self.reason = _reason(reason)


class InformationalResponse(_ResponseBase):
    _LOW = 100
    _HIGH = 200


class Response(_ResponseBase):
    _LOW = 200
    _HIGH = 1000


class Data(_Event):
    _FIELDS = ("data", "chunk_start", "chunk_end")

    def __init__(self, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)


class EndOfMessage(_Event):
    _FIELDS = ("headers",)

    def __init__(self, headers=()):
        self.headers = Headers(headers)


class ConnectionClosed(_Event):
    _FIELDS = ()

    def __init__(self):
        pass
