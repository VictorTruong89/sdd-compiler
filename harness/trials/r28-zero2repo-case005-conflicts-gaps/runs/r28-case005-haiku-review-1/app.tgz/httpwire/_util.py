"""Sentinels, protocol-error classes and byte-level helpers shared by httpwire."""

import re


class _Sentinel(object):
    """A named singleton. Instances compare by identity only."""

    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return "httpwire.%s" % self._name


# Roles.
CLIENT = _Sentinel("CLIENT")
SERVER = _Sentinel("SERVER")

# Connection states.
IDLE = _Sentinel("IDLE")
SEND_RESPONSE = _Sentinel("SEND_RESPONSE")
SEND_BODY = _Sentinel("SEND_BODY")
DONE = _Sentinel("DONE")
MUST_CLOSE = _Sentinel("MUST_CLOSE")
CLOSED = _Sentinel("CLOSED")
MIGHT_SWITCH_PROTOCOL = _Sentinel("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = _Sentinel("SWITCHED_PROTOCOL")
ERROR = _Sentinel("ERROR")

# Non-event results of Connection.next_event().
NEED_DATA = _Sentinel("NEED_DATA")
PAUSED = _Sentinel("PAUSED")

# Body framing modes (internal).
EMPTY = "empty"
LENGTH = "length"
CHUNKED = "chunked"
CLOSE = "close"


class _ProtocolError(Exception):
    """Common base for the two protocol-error classes (they are siblings, not nested)."""

    def __init__(self, message, error_status_hint=400):
        Exception.__init__(self, message)
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(_ProtocolError):
    """The integrator's own event, send, or start-next-cycle violated HTTP/1.1."""


class RemoteProtocolError(_ProtocolError):
    """The peer's bytes violated HTTP/1.1."""


TOKEN_RE = re.compile(rb"[!#$%&'*+\-.^_`|~0-9A-Za-z]+")
VISIBLE_RE = re.compile(rb"[\x21-\x7e]+")
VERSION_RE = re.compile(rb"[0-9]\.[0-9]")
# NUL, CR, LF, FF, VT and every other control byte except HTAB, plus DEL.
CONTROL_RE = re.compile(rb"[\x00-\x08\x0a-\x1f\x7f]")


def to_bytes(value, what):
    """Accept ASCII str, bytes or any bytes-like object; return an exact bytes object."""
    if isinstance(value, bytes):
        return value
    if isinstance(value, str):
        try:
            return value.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("%s must be ASCII text" % what)
    if isinstance(value, (bytearray, memoryview)):
        return bytes(value)
    raise LocalProtocolError("%s must be str or bytes-like" % what)
