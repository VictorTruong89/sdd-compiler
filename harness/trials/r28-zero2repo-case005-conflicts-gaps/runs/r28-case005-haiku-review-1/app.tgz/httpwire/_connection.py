"""The bring-your-own-I/O HTTP/1.1 connection state machine (FP-02 .. FP-07)."""

import re

from ._util import (
    CHUNKED,
    CLIENT,
    CLOSE,
    CLOSED,
    DONE,
    EMPTY,
    ERROR,
    IDLE,
    LENGTH,
    LocalProtocolError,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    RemoteProtocolError,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
    TOKEN_RE,
)
from ._events import (
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    Request,
    Response,
)

# Default incomplete-event size limit (NOTES.md, conflict 2).
DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 16 * 1024

# Chunk-size line: 1 to 32 hex digits, optional extension, optional spaces/tabs (NOTES.md, conflicts 3-4).
_CHUNK_SIZE_RE = re.compile(rb"([0-9A-Fa-f]{1,32})(?:;[^\x00-\x08\x0a-\x1f\x7f]*)?[ \t]*")
_STATUS_LINE_RE = re.compile(rb"HTTP/([0-9]\.[0-9]) ([0-9]{3})(?: (.*))?")


class _Framing(object):
    """Body framing for one direction of one message."""

    def __init__(self, mode, remaining=0):
        self.mode = mode
        # For chunked bodies, None means "expecting a chunk-size line".
        self.remaining = None if mode == CHUNKED else remaining
        # Chunked receive state only.
        self.pending_crlf = False
        self.in_trailers = False
        self.fresh = False


# ---------------------------------------------------------------- helpers

def _find(pairs, lname):
    for index, (name, _value) in enumerate(pairs):
        if name.lower() == lname:
            return index
    return None


def _find_value(pairs, lname):
    index = _find(pairs, lname)
    return None if index is None else pairs[index][1]


def _has_token(pairs, lname, token):
    for name, value in pairs:
        if name.lower() == lname:
            for piece in value.split(b","):
                if piece.strip(b" \t").lower() == token:
                    return True
    return False


def _render_pairs(pairs):
    return b"".join(name + b": " + value + b"\r\n" for name, value in pairs)


def _connection_close(pairs):
    """Drop keep-alive tokens from Connection headers and make sure `close` is present."""
    out = []
    tokens = []
    slot = None
    for name, value in pairs:
        if name.lower() == b"connection":
            if slot is None:
                slot = len(out)
                out.append((name, None))
            tokens.extend(piece.strip(b" \t") for piece in value.split(b","))
        else:
            out.append((name, value))
    tokens = [token for token in tokens if token and token.lower() != b"keep-alive"]
    if not any(token.lower() == b"close" for token in tokens):
        tokens.append(b"close")
    value = b", ".join(tokens)
    if slot is None:
        out.append((b"Connection", value))
    else:
        out[slot] = (out[slot][0], value)
    return out


def _payload_info(payload, passthrough):
    """Return (piece, nbytes) for a Data payload."""
    if isinstance(payload, str):
        raise LocalProtocolError("data payload must be bytes-like, not str")
    try:
        view = memoryview(payload)
    except TypeError:
        view = None
    if view is not None:
        return payload, view.nbytes
    if passthrough and hasattr(payload, "__len__"):
        return payload, len(payload)
    raise LocalProtocolError("data payload must be bytes-like")


def _find_block_end(buf):
    """Find the blank line ending a block of lines. Returns (lines, consumed) or None."""
    pos = 0
    lines = []
    while True:
        index = buf.find(b"\n", pos)
        if index < 0:
            return None
        line = bytes(buf[pos:index])
        if line.endswith(b"\r"):
            line = line[:-1]
        pos = index + 1
        if not line:
            return lines, pos
        lines.append(line)


def _parse_fields(lines):
    """Parse header field lines, applying obsolete line folding. Returns (name, value) pairs."""
    items = []
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            if not items:
                raise RemoteProtocolError("obsolete line folding without a header to continue")
            raw_name, value = items[-1]
            items[-1] = (raw_name, (value + b" " + line.lstrip(b" \t")).strip(b" \t"))
        else:
            index = line.find(b":")
            if index <= 0:
                raise RemoteProtocolError("malformed header line")
            name = line[:index]
            if not TOKEN_RE.fullmatch(name):
                raise RemoteProtocolError("invalid header name")
            items.append((name, line[index + 1:].strip(b" \t")))
    return items


def _parse_request(lines):
    parts = lines[0].split(b" ")
    if len(parts) != 3:
        raise RemoteProtocolError("malformed request line")
    method, target, version = parts
    if version[:5] != b"HTTP/" or version[5:] not in (b"1.0", b"1.1"):
        raise RemoteProtocolError("unsupported HTTP version in request line")
    return Request(method, target, headers=_parse_fields(lines[1:]), http_version=version[5:])


def _parse_response(lines):
    match = _STATUS_LINE_RE.fullmatch(lines[0])
    if match is None:
        raise RemoteProtocolError("malformed status line")
    version = match.group(1)
    if version not in (b"1.0", b"1.1"):
        raise RemoteProtocolError("unsupported HTTP version in status line")
    status = int(match.group(2))
    reason = match.group(3) or b""
    headers = _parse_fields(lines[1:])
    if status < 200:
        return InformationalResponse(status, headers=headers, http_version=version, reason=reason)
    return Response(status, headers=headers, http_version=version, reason=reason)


def _request_framing(event):
    length = _find_value(event.headers, b"content-length")
    if length is not None:
        return _Framing(LENGTH, int(length))
    if _find_value(event.headers, b"transfer-encoding") is not None:
        return _Framing(CHUNKED)
    return _Framing(EMPTY)


def _expects_continue(headers):
    return _has_token(headers, b"expect", b"100-continue")


# ---------------------------------------------------------------- connection

class Connection(object):
    """One HTTP/1.1 connection in the client or server role. It performs no I/O."""

    def __init__(self, role, max_incomplete_event_size=None):
        if role is not CLIENT and role is not SERVER:
            raise ValueError("role must be CLIENT or SERVER")
        if max_incomplete_event_size is None:
            max_incomplete_event_size = DEFAULT_MAX_INCOMPLETE_EVENT_SIZE
        if (isinstance(max_incomplete_event_size, bool)
                or not isinstance(max_incomplete_event_size, int)
                or max_incomplete_event_size < 1):
            raise ValueError("max_incomplete_event_size must be a positive integer")
        self._our_role = role
        self._their_role = SERVER if role is CLIENT else CLIENT
        self._states = {CLIENT: IDLE, SERVER: IDLE}
        self._max_incomplete = int(max_incomplete_event_size)
        self._buf = bytearray()
        self._recv_closed = False
        self._switched = False
        self._their_http_version = None
        self._client_waiting = False
        self._keep_alive = True
        self._request_method = None
        self._proposal_connect = False
        self._proposal_upgrade = False
        self._send_framing = None
        self._recv_framing = None
        self._their_error_hint = 400

    # ------------------------------------------------------------ properties

    @property
    def our_role(self):
        return self._our_role

    @property
    def their_role(self):
        return self._their_role

    @property
    def our_state(self):
        return self._states[self._our_role]

    @property
    def their_state(self):
        return self._states[self._their_role]

    @property
    def states(self):
        return dict(self._states)

    @property
    def their_http_version(self):
        return self._their_http_version

    @property
    def client_is_waiting_for_100_continue(self):
        return bool(self._client_waiting)

    @property
    def they_are_waiting_for_100_continue(self):
        return bool(self._client_waiting) if self._our_role is SERVER else False

    @property
    def trailing_data(self):
        return (bytes(self._buf), bool(self._recv_closed))

    # ------------------------------------------------------------ sending

    def send(self, event):
        """Encode one event to bytes. A refused send raises LocalProtocolError."""
        return b"".join(self._send(event, False))

    def send_with_data_passthrough(self, event):
        """Like send(), but return a list of pieces; object payloads are passed through by identity."""
        return list(self._send(event, True))

    def send_failed(self):
        """Record that the bytes of the last send were not transmitted."""
        self._mark_our_error()
        return None

    def _send(self, event, passthrough):
        try:
            return self._encode(event, passthrough)
        except LocalProtocolError:
            self._mark_our_error()
            raise

    def _encode(self, event, passthrough):
        our = self._our_role
        state = self._states[our]
        if state is ERROR:
            raise LocalProtocolError("connection is in the ERROR state; cannot send")

        if isinstance(event, ConnectionClosed):
            if state not in (IDLE, DONE, MUST_CLOSE):
                raise LocalProtocolError("cannot send connection-closed in state %r" % (state,))
            self._apply_event(our, event)
            return []

        if isinstance(event, Request):
            if our is not CLIENT:
                raise LocalProtocolError("a server cannot send a request")
            if state is not IDLE:
                raise LocalProtocolError("client cannot send a request in state %r" % (state,))
            if event.http_version != b"1.1":
                raise LocalProtocolError("only HTTP/1.1 requests can be sent")
            pairs = event.headers.raw_items()
            length = _find_value(pairs, b"content-length")
            if length is not None:
                framing = _Framing(LENGTH, int(length))
                pairs = [pair for pair in pairs if pair[0].lower() != b"transfer-encoding"]
            elif _find(pairs, b"transfer-encoding") is not None:
                framing = _Framing(CHUNKED)
            else:
                framing = _Framing(EMPTY)
            host = [pair for pair in pairs if pair[0].lower() == b"host"]
            rest = [pair for pair in pairs if pair[0].lower() != b"host"]
            head = (event.method + b" " + event.target + b" HTTP/1.1\r\n"
                    + _render_pairs(host + rest) + b"\r\n")
            self._send_framing = framing
            self._apply_event(CLIENT, event)
            return [head]

        if isinstance(event, InformationalResponse):
            if our is not SERVER:
                raise LocalProtocolError("a client cannot send an informational response")
            if state is not SEND_RESPONSE:
                raise LocalProtocolError("cannot send informational response in state %r" % (state,))
            head = self._status_line(event) + _render_pairs(event.headers.raw_items()) + b"\r\n"
            self._apply_event(SERVER, event)
            return [head]

        if isinstance(event, Response):
            if our is not SERVER:
                raise LocalProtocolError("a client cannot send a response")
            if state is not SEND_RESPONSE and state is not IDLE:
                raise LocalProtocolError("cannot send response in state %r" % (state,))
            if self._accepts_connect(event):
                pairs = event.headers.raw_items()
                framing = _Framing(EMPTY)
                keep_alive = False
            else:
                pairs, framing, close_delimited = self._response_framing(event)
                keep_alive = (self._keep_alive and not close_delimited
                              and not _has_token(pairs, b"connection", b"close"))
                if not keep_alive:
                    pairs = _connection_close(pairs)
            head = self._status_line(event) + _render_pairs(pairs) + b"\r\n"
            self._keep_alive = keep_alive
            self._send_framing = framing
            self._apply_event(SERVER, event)
            return [head]

        if isinstance(event, Data):
            if state is not SEND_BODY:
                raise LocalProtocolError("cannot send data in state %r" % (state,))
            framing = self._send_framing
            payload, count = _payload_info(event.data, passthrough)
            if framing.mode == EMPTY:
                if count:
                    raise LocalProtocolError("this message has no body")
                pieces = []
            elif framing.mode == LENGTH:
                if count > framing.remaining:
                    raise LocalProtocolError("data exceeds the declared Content-Length")
                framing.remaining -= count
                pieces = [payload] if count else []
            elif framing.mode == CHUNKED:
                pieces = [b"%x\r\n" % count, payload, b"\r\n"] if count else []
            else:
                pieces = [payload] if count else []
            self._apply_event(our, event)
            return pieces

        if isinstance(event, EndOfMessage):
            if state is not SEND_BODY:
                raise LocalProtocolError("cannot send end-of-message in state %r" % (state,))
            framing = self._send_framing
            trailers = event.headers.raw_items()
            if framing.mode == LENGTH and framing.remaining != 0:
                raise LocalProtocolError("end-of-message before the declared Content-Length was sent")
            if framing.mode == CHUNKED:
                if trailers and self._their_http_version == b"1.0":
                    raise LocalProtocolError("trailers cannot be sent to an HTTP/1.0 peer")
                pieces = [b"0\r\n" + _render_pairs(trailers) + b"\r\n"]
            else:
                if trailers:
                    raise LocalProtocolError("trailers require chunked framing")
                pieces = []
            self._send_framing = None
            self._apply_event(our, event)
            return pieces

        raise LocalProtocolError("not an HTTP event: %r" % (event,))

    def _status_line(self, event):
        return b"HTTP/1.1 " + str(event.status_code).encode("ascii") + b" " + event.reason + b"\r\n"

    def _response_framing(self, event):
        """Framing for a final response that does not accept a switch.

        Returns (wire_pairs, framing, close_delimited).
        """
        status = event.status_code
        peer_is_11 = self._their_http_version == b"1.1"
        pairs = list(event.headers.raw_items())
        if _find(pairs, b"transfer-encoding") is not None:
            # Transfer-Encoding wins over Content-Length on responses (NOTES.md, conflict 11).
            pairs = [pair for pair in pairs if pair[0].lower() != b"content-length"]
        close_delimited = False
        if status in (204, 304):
            framing = _Framing(EMPTY)
        elif _find(pairs, b"transfer-encoding") is not None:
            if peer_is_11:
                framing = _Framing(CHUNKED)
            else:
                pairs = [pair for pair in pairs if pair[0].lower() != b"transfer-encoding"]
                framing = _Framing(CLOSE)
                close_delimited = True
        elif _find(pairs, b"content-length") is not None:
            framing = _Framing(LENGTH, int(_find_value(pairs, b"content-length")))
        elif peer_is_11:
            pairs.append((b"Transfer-Encoding", b"chunked"))
            framing = _Framing(CHUNKED)
        else:
            framing = _Framing(CLOSE)
            close_delimited = True
        if self._request_method == b"HEAD":
            framing = _Framing(EMPTY)
        return pairs, framing, close_delimited

    def _accepts_connect(self, event):
        return (self._proposal_connect and type(event) is Response
                and event.status_code == 200)

    # ------------------------------------------------------------ receiving

    def receive_data(self, data):
        """Store bytes received from the peer. An empty chunk means the peer closed its sending side."""
        try:
            chunk = memoryview(data).tobytes()
        except TypeError:
            raise TypeError("data must be bytes-like")
        if self._recv_closed:
            if not chunk:
                return None
            if not self._switched:
                raise RuntimeError("cannot receive data after the peer closed its sending side")
        if chunk:
            self._buf += chunk
        else:
            self._recv_closed = True
        return None

    def next_event(self):
        """Parse one event from stored bytes, or return NEED_DATA or PAUSED."""
        try:
            return self._next_event_impl()
        except LocalProtocolError as exc:
            error = RemoteProtocolError(str(exc), exc.error_status_hint)
        except RemoteProtocolError as exc:
            error = exc
        self._mark_their_error(error.error_status_hint)
        raise error

    def _next_event_impl(self):
        their = self._states[self._their_role]
        if their is ERROR:
            raise RemoteProtocolError("peer previously violated the protocol", self._their_error_hint)
        if their is CLOSED:
            return ConnectionClosed()
        if their is SWITCHED_PROTOCOL or their is MIGHT_SWITCH_PROTOCOL:
            return PAUSED

        if their is SEND_BODY:
            result = self._pull_body()
        elif their is SEND_RESPONSE and self._our_role is CLIENT:
            result = self._pull_head()
        elif their is IDLE and self._our_role is SERVER:
            result = self._pull_head()
        elif their is IDLE:
            result = PAUSED if self._buf else NEED_DATA
        else:
            # DONE or MUST_CLOSE: stored bytes are a pipelined request that must wait for the next cycle.
            result = PAUSED if self._buf else NEED_DATA

        if result is NEED_DATA and self._recv_closed:
            if their is IDLE or their is DONE or their is MUST_CLOSE:
                return self._pull_close()
            raise RemoteProtocolError("peer closed the connection in the middle of a message")
        return result

    def _mark_their_error(self, hint):
        self._states[self._their_role] = ERROR
        self._their_error_hint = hint
        self._recv_framing = None
        self._keep_alive = False
        self._fixup()

    def _mark_our_error(self):
        self._states[self._our_role] = ERROR
        self._keep_alive = False
        self._fixup()

    def _pull_head(self):
        buf = self._buf
        if not buf:
            return NEED_DATA
        if buf[0] <= 32:
            raise RemoteProtocolError("message starts with a space or control byte")
        block = _find_block_end(buf)
        if block is None:
            if self._recv_closed:
                raise RemoteProtocolError("connection closed in the middle of a message header")
            if len(buf) > self._max_incomplete:
                raise RemoteProtocolError("incomplete message exceeds the size limit", 431)
            return NEED_DATA
        lines, consumed = block
        del buf[:consumed]
        if self._our_role is SERVER:
            event = _parse_request(lines)
            self._their_http_version = event.http_version
            self._apply_event(CLIENT, event)
            self._recv_framing = _request_framing(event)
            return event
        event = _parse_response(lines)
        self._their_http_version = event.http_version
        self._apply_event(SERVER, event)
        if isinstance(event, Response):
            self._recv_framing = self._response_recv_framing(event)
        return event

    def _response_recv_framing(self, event):
        if self._switched:
            return _Framing(EMPTY)
        if self._request_method == b"HEAD" or event.status_code in (204, 304):
            return _Framing(EMPTY)
        if _find(event.headers, b"transfer-encoding") is not None:
            return _Framing(CHUNKED)
        length = _find_value(event.headers, b"content-length")
        if length is not None:
            return _Framing(LENGTH, int(length))
        # Close-delimited body (FP-03): the connection cannot be reused.
        self._keep_alive = False
        return _Framing(CLOSE)

    def _pull_body(self):
        framing = self._recv_framing
        buf = self._buf
        if framing.mode == EMPTY:
            return self._finish_recv_body()
        if framing.mode == LENGTH:
            if framing.remaining == 0:
                return self._finish_recv_body()
            if not buf:
                return NEED_DATA
            count = min(framing.remaining, len(buf))
            data = bytes(buf[:count])
            del buf[:count]
            framing.remaining -= count
            return self._data_event(data, False, False)
        if framing.mode == CHUNKED:
            return self._pull_chunked(framing)
        # Close-delimited.
        if buf:
            data = bytes(buf)
            del buf[:]
            return self._data_event(data, False, False)
        if self._recv_closed:
            return self._finish_recv_body()
        return NEED_DATA

    def _pull_chunked(self, framing):
        buf = self._buf
        if framing.pending_crlf:
            if buf[:1] and buf[:1] != b"\r":
                raise RemoteProtocolError("chunk data not followed by CRLF")
            if len(buf) < 2:
                return NEED_DATA
            if buf[1:2] != b"\n":
                raise RemoteProtocolError("chunk data not followed by CRLF")
            del buf[:2]
            framing.pending_crlf = False

        if framing.remaining is None and not framing.in_trailers:
            index = buf.find(b"\n")
            if index < 0:
                if len(buf) > self._max_incomplete:
                    raise RemoteProtocolError("chunk-size line exceeds the size limit")
                return NEED_DATA
            line = bytes(buf[:index])
            if line.endswith(b"\r"):
                line = line[:-1]
            match = _CHUNK_SIZE_RE.fullmatch(line)
            if match is None:
                raise RemoteProtocolError("invalid chunk-size line")
            del buf[:index + 1]
            size = int(match.group(1), 16)
            if size == 0:
                framing.in_trailers = True
            else:
                framing.remaining = size
                framing.fresh = True

        if framing.in_trailers:
            block = _find_block_end(buf)
            if block is None:
                if self._recv_closed:
                    raise RemoteProtocolError("connection closed in the middle of trailers")
                if len(buf) > self._max_incomplete:
                    raise RemoteProtocolError("trailers exceed the size limit", 431)
                return NEED_DATA
            lines, consumed = block
            del buf[:consumed]
            return self._finish_recv_body(_parse_fields(lines))

        if not buf:
            return NEED_DATA
        count = min(framing.remaining, len(buf))
        data = bytes(buf[:count])
        del buf[:count]
        starts_chunk = framing.fresh
        framing.fresh = False
        framing.remaining -= count
        ends_chunk = framing.remaining == 0
        if ends_chunk:
            framing.remaining = None
            framing.pending_crlf = True
        return self._data_event(data, starts_chunk, ends_chunk)

    def _data_event(self, data, chunk_start, chunk_end):
        event = Data(data, chunk_start=chunk_start, chunk_end=chunk_end)
        self._apply_event(self._their_role, event)
        return event

    def _finish_recv_body(self, trailers=()):
        event = EndOfMessage(headers=trailers)
        self._apply_event(self._their_role, event)
        self._recv_framing = None
        return event

    def _pull_close(self):
        event = ConnectionClosed()
        self._apply_event(self._their_role, event)
        return event

    # ------------------------------------------------------------ cycles

    def start_next_cycle(self):
        """Reset a finished exchange (both sides DONE) so another request/response can run."""
        if self._states[CLIENT] is not DONE or self._states[SERVER] is not DONE:
            raise LocalProtocolError("cannot start the next cycle: both sides must be DONE")
        self._states[CLIENT] = IDLE
        self._states[SERVER] = IDLE
        self._keep_alive = True
        self._request_method = None
        self._proposal_connect = False
        self._proposal_upgrade = False
        self._send_framing = None
        self._recv_framing = None
        self._client_waiting = False
        return None

    # ------------------------------------------------------------ state machine

    def _apply_event(self, role, event):
        """Apply the state change caused by an event sent (or pulled) by `role`."""
        states = self._states
        kind = type(event)
        if kind is Request:
            states[role] = SEND_BODY
            if states[SERVER if role is CLIENT else CLIENT] is IDLE:
                states[SERVER if role is CLIENT else CLIENT] = SEND_RESPONSE
            self._request_method = event.method
            self._proposal_connect = event.method == b"CONNECT"
            self._proposal_upgrade = _find(event.headers, b"upgrade") is not None
            if event.http_version != b"1.1" or _has_token(event.headers, b"connection", b"close"):
                self._keep_alive = False
            if event.http_version == b"1.1" and _expects_continue(event.headers):
                self._client_waiting = True
        elif kind is InformationalResponse:
            if self._proposal_upgrade and event.status_code == 101:
                self._switch()
            self._client_waiting = False
        elif kind is Response:
            self._client_waiting = False
            if self._accepts_connect(event):
                self._switch()
            else:
                states[role] = SEND_BODY
                if states[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                    # Denied proposal: the client's request was already finished.
                    self._finish_side(CLIENT)
                self._proposal_connect = False
                self._proposal_upgrade = False
                if event.http_version != b"1.1" or _has_token(event.headers, b"connection", b"close"):
                    self._keep_alive = False
        elif kind is Data:
            if role is CLIENT:
                self._client_waiting = False
        elif kind is EndOfMessage:
            if role is CLIENT:
                self._client_waiting = False
            if role is CLIENT and (self._proposal_connect or self._proposal_upgrade):
                states[CLIENT] = MIGHT_SWITCH_PROTOCOL
            else:
                self._finish_side(role)
        elif kind is ConnectionClosed:
            states[role] = CLOSED
        self._fixup()

    def _finish_side(self, side):
        self._states[side] = DONE if self._keep_alive else MUST_CLOSE

    def _switch(self):
        self._switched = True
        self._states[CLIENT] = SWITCHED_PROTOCOL
        self._states[SERVER] = SWITCHED_PROTOCOL
        self._proposal_connect = False
        self._proposal_upgrade = False
        self._keep_alive = False

    def _fixup(self):
        states = self._states
        for side, other in ((CLIENT, SERVER), (SERVER, CLIENT)):
            if states[side] is ERROR and states[other] is DONE:
                states[other] = MUST_CLOSE
            if states[side] is CLOSED and states[other] in (IDLE, DONE):
                states[other] = MUST_CLOSE
