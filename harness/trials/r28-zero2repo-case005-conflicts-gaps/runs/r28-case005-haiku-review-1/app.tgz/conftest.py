# Marks the repository root as the rootdir so pytest puts it on sys.path and `import httpwire` works.
