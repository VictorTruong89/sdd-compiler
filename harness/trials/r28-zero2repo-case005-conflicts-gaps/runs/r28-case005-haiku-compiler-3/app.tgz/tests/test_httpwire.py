"""Behavioral tests for httpwire, written from the specification in spec/.

Test names carry the spec id(s) they exercise where that is practical.
Run with:  python -m unittest discover -s tests -t .   (or pytest tests)
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import httpwire as hw  # noqa: E402
from httpwire import (  # noqa: E402
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
    Connection,
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    LocalProtocolError,
    RemoteProtocolError,
    Request,
    Response,
)
from httpwire._errors import ReceiveAfterCloseError  # noqa: E402


def pair(client=None, server=None):
    return (client or Connection(CLIENT)), (server or Connection(SERVER))


def pump(src, dst, data):
    """Send raw bytes from src to dst and return the events dst pulls."""
    dst.receive_data(data)
    out = []
    for _ in range(1000):
        ev = dst.next_event()
        if ev is NEED_DATA or ev is PAUSED:
            break
        out.append(ev)
        if isinstance(ev, ConnectionClosed):
            break  # a closed receive side keeps returning ConnectionClosed
    else:
        raise AssertionError("pump did not settle")
    return out


def get_request(**kw):
    kw.setdefault("headers", [("Host", "example.com")])
    return Request(method=b"GET", target=b"/", **kw)


class TestSurface(unittest.TestCase):
    # spec: pack 05 N-000433..N-000449
    def test_package_names(self):
        for name in ["CLIENT", "CLOSED", "Connection", "ConnectionClosed", "Data",
                     "DONE", "EndOfMessage", "ERROR", "IDLE", "InformationalResponse",
                     "LocalProtocolError", "MIGHT_SWITCH_PROTOCOL", "MUST_CLOSE",
                     "NEED_DATA", "PAUSED", "RemoteProtocolError", "Request",
                     "Response", "SEND_BODY", "SEND_RESPONSE", "SERVER",
                     "SWITCHED_PROTOCOL"]:
            self.assertTrue(hasattr(hw, name), name)

    def test_states_and_roles_distinct(self):
        states = [IDLE, SEND_RESPONSE, SEND_BODY, DONE, MUST_CLOSE, CLOSED,
                  MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL, ERROR]
        self.assertEqual(len(set(map(id, states))), 9)
        self.assertIsNot(CLIENT, SERVER)
        self.assertIsNot(NEED_DATA, PAUSED)
        self.assertFalse(issubclass(LocalProtocolError, RemoteProtocolError))
        self.assertFalse(issubclass(RemoteProtocolError, LocalProtocolError))

    def test_bad_role_refused(self):
        with self.assertRaises(Exception):
            Connection("client")

    # spec: pack 08 N-000478..N-000480
    def test_max_size_bad_value_refused(self):
        with self.assertRaises(Exception):
            Connection(CLIENT, 0)


class TestEventConstruction(unittest.TestCase):
    # spec: pack 14 N-000072..N-000076, N-000090
    def test_bytes_normalization(self):
        r = Request(method="GET", target=bytearray(b"/x"), headers=[("Host", "h")])
        self.assertIs(type(r.method), bytes)
        self.assertIs(type(r.target), bytes)
        self.assertEqual(r.http_version, b"1.1")
        self.assertEqual(r.headers[0], (b"host", b"h"))

    def test_raw_items_keep_case(self):
        r = Request(method=b"GET", target=b"/", headers=[("X-Mixed", "v"), ("Host", "h")])
        self.assertEqual(r.headers.raw_items()[0], (b"X-Mixed", b"v"))
        self.assertEqual(list(r.headers)[0], (b"x-mixed", b"v"))

    # spec: pack 14 N-000104, N-000105, N-000077, N-000078
    def test_host_rules(self):
        with self.assertRaises(LocalProtocolError):
            Request(method=b"GET", target=b"/", headers=[])
        with self.assertRaises(LocalProtocolError):
            Request(method=b"GET", target=b"/", headers=[("host", "a"), ("Host", "b")])
        with self.assertRaises(LocalProtocolError):
            Request(method=b"GET", target=b"/", headers=[("host", "a"), ("HOST", "b")],
                    http_version=b"1.0")
        Request(method=b"GET", target=b"/", headers=[], http_version=b"1.0")

    # spec: pack 14 N-000097..N-000100, N-000108
    def test_header_value_rules(self):
        for bad in [" x", "x ", "\tx", "a\x00b", "a\rb", "a\x01b", "a\x7fb"]:
            with self.assertRaises(LocalProtocolError, msg=repr(bad)):
                Request(method=b"GET", target=b"/", headers=[("Host", "h"), ("X", bad)])
        Request(method=b"GET", target=b"/", headers=[("Host", "h"), ("X", b"a\tb\xff")])

    # spec: pack 14 N-000106, N-000110, N-000111
    def test_name_target_method_rules(self):
        with self.assertRaises(LocalProtocolError):
            Request(method=b"GET", target=b"/", headers=[("Host", "h"), ("bad name", "x")])
        with self.assertRaises(LocalProtocolError):
            Request(method=b"GET", target=b"a b", headers=[("Host", "h")])
        with self.assertRaises(LocalProtocolError):
            Request(method=b"G E", target=b"/", headers=[("Host", "h")])

    # spec: pack 14 N-000079..N-000083, N-000112, N-000113
    def test_status_rules(self):
        r = hw.Response(status_code=200, headers=[])
        self.assertEqual(r.http_version, b"1.1")
        self.assertEqual(r.reason, b"")
        with self.assertRaises(LocalProtocolError):
            hw.Response(status_code=199, headers=[])
        with self.assertRaises(LocalProtocolError):
            hw.Response(status_code=1000, headers=[])
        with self.assertRaises(LocalProtocolError):
            hw.Response(status_code="200", headers=[])
        with self.assertRaises(LocalProtocolError):
            InformationalResponse(status_code=200, headers=[])
        self.assertEqual(InformationalResponse(status_code=101, headers=[]).status_code, 101)

    # spec: pack 14 N-000114..N-000121
    def test_framing_header_rules(self):
        with self.assertRaises(LocalProtocolError):
            Request(method=b"POST", target=b"/", headers=[("Host", "h"), ("Content-Length", "1x")])
        with self.assertRaises(LocalProtocolError):
            Request(method=b"POST", target=b"/", headers=[("Host", "h"), ("Content-Length", "1"),
                                                           ("Content-Length", "2")])
        r = Request(method=b"POST", target=b"/", headers=[("Host", "h"),
                                                           ("Content-Length", "5, 5")])
        self.assertEqual(list(r.headers)[1], (b"content-length", b"5"))
        with self.assertRaises(LocalProtocolError) as cm:
            Request(method=b"POST", target=b"/", headers=[("Host", "h"),
                                                           ("Transfer-Encoding", "gzip, chunked")])
        self.assertEqual(cm.exception.error_status_hint, 501)
        with self.assertRaises(LocalProtocolError) as cm:
            Request(method=b"POST", target=b"/", headers=[("Host", "h"),
                                                           ("Transfer-Encoding", "chunked"),
                                                           ("Transfer-Encoding", "chunked")])
        self.assertEqual(cm.exception.error_status_hint, 501)
        r = Request(method=b"POST", target=b"/", headers=[("Host", "h"),
                                                           ("Transfer-Encoding", "CHUNKED")])
        self.assertEqual(list(r.headers)[1], (b"transfer-encoding", b"chunked"))

    def test_content_length_16_digit_limit(self):
        with self.assertRaises(LocalProtocolError):
            Request(method=b"POST", target=b"/", headers=[("Host", "h"),
                                                           ("Content-Length", "1" * 17)])

    def test_default_hint_is_400(self):
        try:
            Request(method=b"G E", target=b"/", headers=[])
        except LocalProtocolError as e:
            self.assertIs(type(e.error_status_hint), int)
            self.assertEqual(e.error_status_hint, 400)

    def test_data_and_eom_defaults(self):
        d = Data(data=b"x")
        self.assertIs(d.chunk_start, False)
        self.assertIs(d.chunk_end, False)
        self.assertEqual(EndOfMessage().headers, [])


class TestBasicCycle(unittest.TestCase):
    # spec: pack 15 N-000128..N-000143, pack 17 N-000250..N-000254
    def test_get_no_body_and_keepalive_cycle(self):
        c, s = pair()
        data = c.send(get_request())
        self.assertEqual(data, b"GET / HTTP/1.1\r\nHost: example.com\r\n\r\n")
        self.assertIs(c.our_state, SEND_BODY)
        self.assertEqual(c.send(EndOfMessage()), b"")
        self.assertIs(c.our_state, DONE)

        evs = pump(c, s, data)
        self.assertIsInstance(evs[0], Request)
        self.assertIsInstance(evs[1], EndOfMessage)
        self.assertIs(s.their_state, DONE)
        self.assertEqual(s.their_http_version, b"1.1")

        out = s.send(Response(status_code=200, headers=[("Content-Length", "2")],
                              reason=b"OK"))
        self.assertEqual(out, b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\n")
        self.assertEqual(s.send(Data(data=b"ok")), b"ok")
        self.assertEqual(s.send(EndOfMessage()), b"")
        self.assertIs(s.our_state, DONE)
        self.assertIs(s.their_state, DONE)

        evs = pump(s, c, out)
        self.assertIsInstance(evs[0], Response)
        self.assertEqual(evs[0].status_code, 200)
        self.assertEqual(c.their_http_version, b"1.1")
        self.assertIs(c.next_event(), NEED_DATA)
        c.receive_data(b"ok")
        self.assertEqual(c.next_event(), Data(data=b"ok"))
        self.assertEqual(c.next_event(), EndOfMessage())
        self.assertIs(c.our_state, DONE)
        self.assertIs(c.their_state, DONE)

        self.assertIsNone(c.start_next_cycle())
        self.assertIsNone(s.start_next_cycle())
        self.assertIs(c.our_state, IDLE)
        self.assertIs(s.their_state, IDLE)

    # spec: pack 15 N-000136..N-000139, N-000153..N-000155
    def test_need_data_retains_partial(self):
        c, s = pair()
        data = c.send(get_request()) + c.send(EndOfMessage())
        s.receive_data(data[:10])
        self.assertIs(s.next_event(), NEED_DATA)
        s.receive_data(data[10:])
        self.assertIsInstance(s.next_event(), Request)

    # spec: pack 15 N-000127
    def test_pull_with_nothing_is_need_data(self):
        self.assertIs(Connection(SERVER).next_event(), NEED_DATA)


class TestBodies(unittest.TestCase):
    # spec: pack 16 N-000188..N-000191
    def test_content_length_body(self):
        c, s = pair()
        head = c.send(Request(method=b"POST", target=b"/", headers=[
            ("Host", "h"), ("Content-Length", "6")]))
        self.assertEqual(c.send(Data(data=b"abc")), b"abc")
        with self.assertRaises(LocalProtocolError):
            c.send(Data(data=b"toolong"))
        # the refused send put the client into ERROR (spec pack 18)
        self.assertIs(c.our_state, ERROR)

        c, s = pair()
        head = c.send(Request(method=b"POST", target=b"/", headers=[
            ("Host", "h"), ("Content-Length", "6")]))
        c.send(Data(data=b"abc"))
        with self.assertRaises(LocalProtocolError):
            c.send(EndOfMessage())
        self.assertIs(c.our_state, ERROR)

        c, s = pair()
        head = c.send(Request(method=b"POST", target=b"/", headers=[
            ("Host", "h"), ("Content-Length", "6")]))
        body = c.send(Data(data=b"abcdef")) + c.send(EndOfMessage())
        evs = pump(c, s, head + body[:3])
        self.assertIsInstance(evs[0], Request)
        self.assertEqual(evs[1], Data(data=b"abc"))
        self.assertIs(s.next_event(), NEED_DATA)
        s.receive_data(body[3:])
        self.assertEqual(s.next_event(), Data(data=b"def"))
        self.assertIsInstance(s.next_event(), EndOfMessage)

    # spec: pack 16 N-000192..N-000197, N-000220..N-000227
    def test_chunked_request_with_trailers_and_marks(self):
        c, s = pair()
        head = c.send(Request(method=b"POST", target=b"/", headers=[
            ("Host", "h"), ("Transfer-Encoding", "chunked")]))
        self.assertEqual(head.lower().count(b"transfer-encoding: chunked"), 1)
        wire = c.send(Data(data=b"hello"))
        self.assertEqual(wire, b"5\r\nhello\r\n")
        self.assertEqual(c.send(Data(data=b"")), b"")
        wire += c.send(EndOfMessage(headers=[("X-T", "1")]))
        self.assertEqual(wire, b"5\r\nhello\r\n0\r\nX-T: 1\r\n\r\n")

        evs = pump(c, s, head + b"5;ext=1\r\nhel")
        self.assertIsInstance(evs[0], Request)
        self.assertEqual(evs[1], Data(data=b"hel", chunk_start=True, chunk_end=False))
        self.assertIs(s.next_event(), NEED_DATA)
        s.receive_data(b"lo\r\n0\r\nX-T: 1\r\n\r\n")
        d = s.next_event()
        self.assertEqual(d, Data(data=b"lo", chunk_start=False, chunk_end=True))
        e = s.next_event()
        self.assertIsInstance(e, EndOfMessage)
        self.assertEqual(e.headers[0], (b"x-t", b"1"))

    # spec: pack 16 N-000220..N-000227 (single-piece chunk is both)
    def test_chunk_marks_single_piece(self):
        c, s = pair()
        head = c.send(Request(method=b"POST", target=b"/", headers=[
            ("Host", "h"), ("Transfer-Encoding", "chunked")]))
        evs = pump(c, s, head + b"3\r\nabc\r\n")
        self.assertEqual(evs[1], Data(data=b"abc", chunk_start=True, chunk_end=True))

    # spec: pack 16 N-000228..N-000232, N-000242..N-000245
    def test_chunk_size_line_rules(self):
        c, s = pair()
        head = c.send(Request(method=b"POST", target=b"/", headers=[
            ("Host", "h"), ("Transfer-Encoding", "chunked")]))
        s.receive_data(head + b"3 \r\nabc\r\n")
        s.next_event()
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

        c, s = pair()
        head = c.send(Request(method=b"POST", target=b"/", headers=[
            ("Host", "h"), ("Transfer-Encoding", "chunked")]))
        s.receive_data(head + b"3\r\nabcX\r\n")
        self.assertIsInstance(s.next_event(), Request)
        self.assertEqual(s.next_event(), Data(data=b"abc", chunk_start=True, chunk_end=True))
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    # spec: pack 16 N-000233..N-000237
    def test_passthrough_keeps_object(self):
        c, s = pair()
        c.send(Request(method=b"POST", target=b"/", headers=[
            ("Host", "h"), ("Content-Length", "3")]))
        payload = memoryview(b"abc")
        pieces = c.send_with_data_passthrough(Data(data=payload))
        self.assertIs(pieces[0], payload)
        self.assertEqual(b"".join(bytes(p) for p in pieces), b"abc")

        c, s = pair()
        c.send(Request(method=b"POST", target=b"/", headers=[
            ("Host", "h"), ("Transfer-Encoding", "chunked")]))
        pieces = c.send_with_data_passthrough(Data(data=payload))
        self.assertEqual(pieces[0], b"3\r\n")
        self.assertIs(pieces[1], payload)
        self.assertEqual(pieces[2], b"\r\n")

    # spec: pack 16 N-000238..N-000241
    def test_trailers_refused_for_length_framing(self):
        c, s = pair()
        c.send(Request(method=b"POST", target=b"/", headers=[
            ("Host", "h"), ("Content-Length", "0")]))
        with self.assertRaises(LocalProtocolError):
            c.send(EndOfMessage(headers=[("X", "1")]))


class TestResponseFraming(unittest.TestCase):
    def _req(self, version=b"1.1", extra=(), method=b"GET"):
        if version == b"1.0":
            # httpwire cannot send HTTP/1.0 requests; feed raw bytes instead.
            s = Connection(SERVER)
            s.receive_data(method + b" / HTTP/1.0\r\n\r\n")
            self.assertIsInstance(s.next_event(), Request)
            self.assertIsInstance(s.next_event(), EndOfMessage)
            return None, s
        c, s = pair()
        headers = [("Host", "h")] + list(extra)
        data = c.send(Request(method=method, target=b"/", headers=headers,
                              http_version=version))
        c.send(EndOfMessage())
        pump(c, s, data)
        return c, s

    # spec: pack 16 N-000200..N-000206
    def test_response_to_11_is_chunked(self):
        c, s = self._req()
        out = s.send(Response(status_code=200, headers=[], reason=b"OK"))
        self.assertIn(b"Transfer-Encoding: chunked", out)
        self.assertEqual(s.send(Data(data=b"xy")), b"2\r\nxy\r\n")
        self.assertEqual(s.send(EndOfMessage()), b"0\r\n\r\n")

    # spec: pack 16 N-000203..N-000206, N-000265..N-000269
    def test_response_to_10_is_close_delimited(self):
        c, s = self._req(version=b"1.0")
        out = s.send(Response(status_code=200, headers=[], reason=b"OK"))
        self.assertEqual(out, b"HTTP/1.1 200 OK\r\nConnection: close\r\n\r\n")
        # an explicit Content-Length is a definite length and is kept
        s2 = self._req(version=b"1.0")[1]
        out2 = s2.send(Response(status_code=200, headers=[("Content-Length", "0")],
                                reason=b"OK"))
        self.assertEqual(out2, b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\nConnection: close\r\n\r\n")
        self.assertEqual(s.send(Data(data=b"raw")), b"raw")
        self.assertEqual(s.send(EndOfMessage()), b"")
        self.assertIs(s.our_state, MUST_CLOSE)

    # spec: pack 16 N-000218, N-000215, N-000219
    def test_head_response_has_no_body(self):
        c, s = self._req(method=b"HEAD")
        out = s.send(Response(status_code=200, headers=[("Content-Length", "10")]))
        self.assertIn(b"Content-Length: 10", out)
        self.assertEqual(s.send(EndOfMessage()), b"")
        with self.assertRaises(LocalProtocolError):
            s.send(Data(data=b"x"))

    def test_204_strips_framing(self):
        c, s = self._req()
        out = s.send(Response(status_code=204, headers=[("Content-Length", "4")]))
        self.assertEqual(out, b"HTTP/1.1 204 \r\n\r\n")
        self.assertEqual(s.send(EndOfMessage()), b"")

    # spec: pack 16 N-000198, N-000199
    def test_content_length_zero_kept(self):
        c, s = self._req()
        out = s.send(Response(status_code=200, headers=[("Content-Length", "0")]))
        self.assertIn(b"Content-Length: 0", out)

    # spec: pack 16 N-000207 (TE wins over CL)
    def test_transfer_encoding_wins_on_response(self):
        c, s = self._req()
        out = s.send(Response(status_code=200, headers=[("Content-Length", "5"),
                                                        ("Transfer-Encoding", "chunked")]))
        self.assertNotIn(b"Content-Length", out)
        self.assertIn(b"Transfer-Encoding: chunked", out)

    # spec: pack 16 N-000208..N-000214 (close-delimited on the receive side)
    def test_close_delimited_response_pull(self):
        c, s = pair()
        c.send(get_request())
        c.send(EndOfMessage())
        c.receive_data(b"HTTP/1.0 200 OK\r\n\r\nbody")
        self.assertIsInstance(c.next_event(), Response)
        self.assertEqual(c.next_event(), Data(data=b"body"))
        self.assertIs(c.next_event(), NEED_DATA)
        c.receive_data(b"")
        self.assertIsInstance(c.next_event(), EndOfMessage)
        self.assertIsInstance(c.next_event(), ConnectionClosed)
        self.assertIs(c.our_state, MUST_CLOSE)

    # spec: pack 15 N-000165 (lone LF), pack 15 N-000167..N-000169 (folding)
    def test_lenient_line_endings_and_folding(self):
        c, s = pair()
        c.send(get_request())
        c.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 200\nX-A: one\n  two\t three\nContent-Length: 0\n\n")
        r = c.next_event()
        self.assertIsInstance(r, Response)
        self.assertEqual(r.reason, b"")
        # only the leading run of spaces/tabs is replaced by one space
        self.assertEqual(r.headers[0], (b"x-a", b"one two\t three"))


class TestErrors(unittest.TestCase):
    # spec: pack 18 N-000302..N-000306
    def test_remote_error_is_sticky(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nBad Header: x\r\n\r\n")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()
        self.assertIs(s.their_state, ERROR)
        self.assertIs(s.our_state, IDLE)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()
        # a server can still send an error response, which carries close
        out = s.send(Response(status_code=400, headers=[("Content-Length", "0")]))
        self.assertIn(b"Connection: close", out)

    # spec: pack 15 N-000177..N-000179
    def test_leading_space_fails_immediately(self):
        s = Connection(SERVER)
        s.receive_data(b" GET / HTTP/1.1")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()
        s = Connection(SERVER)
        s.receive_data(b"\r\n")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    # spec: pack 18 N-000316..N-000323
    def test_incomplete_event_size_limit_431(self):
        s = Connection(SERVER, 100)
        s.receive_data(b"GET / HTTP/1.1\r\nX: " + b"a" * 200)
        with self.assertRaises(RemoteProtocolError) as cm:
            s.next_event()
        self.assertEqual(cm.exception.error_status_hint, 431)
        self.assertIs(s.their_state, ERROR)

    def test_default_limit_is_8k(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nX: " + b"a" * (8 * 1024 + 10))
        with self.assertRaises(RemoteProtocolError) as cm:
            s.next_event()
        self.assertEqual(cm.exception.error_status_hint, 431)

    # spec: pack 18 N-000324, N-000325
    def test_close_mid_body_is_remote_error(self):
        c, s = pair()
        s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nContent-Length: 9\r\n\r\nab")
        s.next_event()
        self.assertEqual(s.next_event(), Data(data=b"ab"))
        s.receive_data(b"")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    # spec: pack 19 N-000339..N-000341
    def test_clean_close_yields_connection_closed(self):
        c, s = pair()
        s.receive_data(b"")
        self.assertIsInstance(s.next_event(), ConnectionClosed)
        self.assertIsInstance(s.next_event(), ConnectionClosed)
        self.assertIs(s.their_state, CLOSED)

    # spec: pack 07 N-000474, pack 15 N-000180..N-000182
    def test_bytes_after_close_is_runtime_error(self):
        s = Connection(SERVER)
        s.receive_data(b"")
        with self.assertRaises(ReceiveAfterCloseError) as cm:
            s.receive_data(b"x")
        self.assertFalse(isinstance(cm.exception, (LocalProtocolError, RemoteProtocolError)))

    # spec: pack 18 N-000307..N-000310
    def test_local_send_error_is_unrecoverable_for_sending(self):
        c, s = pair()
        c.send(get_request())
        c.send(EndOfMessage())
        with self.assertRaises(LocalProtocolError):
            c.send(get_request())
        self.assertIs(c.our_state, ERROR)
        with self.assertRaises(LocalProtocolError):
            c.send(EndOfMessage())

    # spec: pack 18 N-000312..N-000315
    def test_send_failed(self):
        c, s = pair()
        c.send(get_request())
        c.send(EndOfMessage())
        self.assertIsNone(c.send_failed())
        self.assertIs(c.our_state, ERROR)
        with self.assertRaises(LocalProtocolError):
            c.send(EndOfMessage())

    # spec: pack 17 N-000280..N-000282
    def test_start_next_cycle_refusal_is_recoverable(self):
        c, s = pair()
        c.send(get_request())
        with self.assertRaises(LocalProtocolError):
            c.start_next_cycle()
        self.assertIs(c.our_state, SEND_BODY)
        c.send(EndOfMessage())
        self.assertIs(c.our_state, DONE)

    # spec: pack 14 N-000101..N-000103
    def test_invalid_construction_leaves_connection_usable(self):
        c, s = pair()
        with self.assertRaises(LocalProtocolError):
            Request(method=b"GET", target=b"/", headers=[])
        self.assertIs(c.our_state, IDLE)
        c.send(get_request())
        self.assertIs(c.our_state, SEND_BODY)

    # spec: pack 17 N-000283..N-000285
    def test_client_cannot_send_response(self):
        c, s = pair()
        with self.assertRaises(LocalProtocolError):
            c.send(Response(status_code=200, headers=[]))
        self.assertIs(c.our_state, ERROR)


class TestPipelining(unittest.TestCase):
    # spec: pack 17 N-000275..N-000279, N-000288
    def test_server_pauses_on_pipelined_bytes(self):
        c, s = pair()
        first = c.send(get_request()) + c.send(EndOfMessage())
        c2_bytes = b"GET /2 HTTP/1.1\r\nHost: h\r\n\r\n"
        s.receive_data(first + c2_bytes)
        self.assertIsInstance(s.next_event(), Request)
        self.assertIsInstance(s.next_event(), EndOfMessage)
        self.assertIs(s.next_event(), PAUSED)
        s.send(Response(status_code=200, headers=[("Content-Length", "0")]))
        s.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 200 \r\nContent-Length: 0\r\n\r\n")
        self.assertIsInstance(c.next_event(), Response)
        self.assertIsInstance(c.next_event(), EndOfMessage)
        self.assertIs(s.next_event(), PAUSED)
        self.assertIsNone(s.start_next_cycle())
        c.start_next_cycle()
        self.assertEqual(s.next_event().target, b"/2")

    # spec: pack 17 N-000272..N-000274
    def test_client_no_pipelining(self):
        c, _s = pair()
        c.send(get_request())
        c.send(EndOfMessage())
        with self.assertRaises(LocalProtocolError):
            c.send(get_request())


class TestKeepAliveAndClose(unittest.TestCase):
    # spec: pack 17 N-000259..N-000264
    def test_connection_close_request_forces_must_close(self):
        c, s = pair()
        data = c.send(Request(method=b"GET", target=b"/", headers=[
            ("Host", "h"), ("Connection", "keep-alive, Close")]))
        c.send(EndOfMessage())
        self.assertIs(c.our_state, MUST_CLOSE)
        pump(c, s, data)
        s.send(Response(status_code=200, headers=[("Content-Length", "0")]))
        s.send(EndOfMessage())
        self.assertIs(s.our_state, MUST_CLOSE)

    # spec: pack 19 N-000332..N-000344
    def test_client_close_then_server_close(self):
        c, s = pair()
        self.assertEqual(c.send(ConnectionClosed()), b"")
        self.assertIs(c.our_state, CLOSED)
        evs = pump(c, s, b"")
        self.assertIsInstance(evs[0], ConnectionClosed)
        self.assertIs(s.our_state, MUST_CLOSE)
        self.assertIs(s.send(ConnectionClosed()), b"")
        self.assertIs(s.our_state, CLOSED)

    # spec: pack 19 N-000345, N-000346
    def test_connection_closed_refused_mid_message(self):
        c, s = pair()
        c.send(get_request())
        with self.assertRaises(LocalProtocolError):
            c.send(ConnectionClosed())


class TestExpectAndSwitch(unittest.TestCase):
    # spec: pack 20 N-000354..N-000359
    def test_100_continue_flags(self):
        c, s = pair()
        data = c.send(Request(method=b"POST", target=b"/", headers=[
            ("Host", "h"), ("Expect", "100-continue"), ("Content-Length", "1")]))
        self.assertTrue(c.client_is_waiting_for_100_continue)
        self.assertFalse(c.they_are_waiting_for_100_continue)
        pump(c, s, data)
        self.assertTrue(s.they_are_waiting_for_100_continue)
        s.send(InformationalResponse(status_code=100, headers=[]))
        self.assertFalse(s.client_is_waiting_for_100_continue)
        self.assertFalse(s.they_are_waiting_for_100_continue)

    # spec: pack 20 N-000364..N-000365, N-000394..N-000398
    def test_connect_accepted_with_200(self):
        c, s = pair()
        data = c.send(Request(method=b"CONNECT", target=b"example.com:443",
                              headers=[("Host", "example.com:443")]))
        c.send(EndOfMessage())
        self.assertIs(c.our_state, MIGHT_SWITCH_PROTOCOL)
        evs = pump(c, s, data)
        self.assertIsInstance(evs[0], Request)
        self.assertIs(s.their_state, MIGHT_SWITCH_PROTOCOL)
        self.assertIs(s.next_event(), PAUSED)
        out = s.send(Response(status_code=200, headers=[]))
        self.assertEqual(out, b"HTTP/1.1 200 \r\n\r\n")
        self.assertIs(s.our_state, SWITCHED_PROTOCOL)
        s.receive_data(b"raw-tunnel")
        self.assertIs(s.next_event(), PAUSED)
        self.assertEqual(s.trailing_data, (b"raw-tunnel", False))
        with self.assertRaises(LocalProtocolError):
            s.send(EndOfMessage())

    # spec: pack 20 N-000394..N-000398 (only 200 accepts CONNECT)
    def test_connect_denied_by_other_2xx(self):
        c, s = pair()
        data = c.send(Request(method=b"CONNECT", target=b"h:1",
                              headers=[("Host", "h:1")]))
        c.send(EndOfMessage())
        pump(c, s, data)
        s.send(Response(status_code=204, headers=[]))
        self.assertIs(s.our_state, SEND_BODY)

    # spec: pack 20 N-000366..N-000372
    def test_upgrade_accepted_with_101(self):
        c, s = pair()
        data = c.send(Request(method=b"GET", target=b"/", headers=[
            ("Host", "h"), ("Upgrade", "websocket"), ("Connection", "Upgrade")]))
        c.send(EndOfMessage())
        pump(c, s, data)
        out = s.send(InformationalResponse(status_code=101, headers=[
            ("Upgrade", "websocket")], reason=b"Switching Protocols"))
        self.assertTrue(out.startswith(b"HTTP/1.1 101 Switching Protocols\r\n"))
        self.assertIs(s.our_state, SWITCHED_PROTOCOL)
        c.receive_data(out)
        self.assertIsInstance(c.next_event(), InformationalResponse)
        self.assertIs(c.their_state, SWITCHED_PROTOCOL)

    # spec: pack 20 N-000378..N-000380
    def test_switch_denied_then_next_cycle(self):
        c, s = pair()
        data = c.send(Request(method=b"GET", target=b"/", headers=[
            ("Host", "h"), ("Upgrade", "x")]))
        c.send(EndOfMessage())
        pump(c, s, data)
        s.send(Response(status_code=200, headers=[("Content-Length", "0")]))
        s.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
        self.assertIsInstance(c.next_event(), Response)
        self.assertIsInstance(c.next_event(), EndOfMessage)
        self.assertIs(c.our_state, DONE)
        self.assertIs(s.our_state, DONE)
        self.assertIsNone(c.start_next_cycle())
        self.assertIsNone(s.start_next_cycle())


class TestInformationalAndHeaders(unittest.TestCase):
    # spec: pack 20 N-000349..N-000353
    def test_informational_before_final(self):
        c, s = pair()
        data = c.send(get_request())
        c.send(EndOfMessage())
        pump(c, s, data)
        s.send(InformationalResponse(status_code=103, headers=[("Link", "x")]))
        self.assertIs(s.our_state, SEND_RESPONSE)
        s.send(Response(status_code=200, headers=[("Content-Length", "0")]))
        self.assertIs(s.our_state, SEND_BODY)

    # spec: pack 15 N-000161
    def test_host_written_first(self):
        c, _s = pair()
        out = c.send(Request(method=b"GET", target=b"/", headers=[
            ("X-A", "1"), ("Host", "h"), ("X-B", "2")]))
        self.assertEqual(out, b"GET / HTTP/1.1\r\nHost: h\r\nX-A: 1\r\nX-B: 2\r\n\r\n")

    # spec: pack 15 N-000163, N-000164
    def test_original_name_casing_on_wire(self):
        c, _s = pair()
        out = c.send(Request(method=b"GET", target=b"/", headers=[("hOsT", "h"), ("X-Caf", "1")]))
        self.assertIn(b"hOsT: h", out)
        self.assertIn(b"X-Caf: 1", out)

    # spec: pack 15 N-000156..N-000160 (HTTP/1.0 request has empty body)
    def test_http10_request_has_empty_body(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.0\r\n\r\n")
        self.assertIsInstance(s.next_event(), Request)
        self.assertIsInstance(s.next_event(), EndOfMessage)
        self.assertEqual(s.their_http_version, b"1.0")

    # spec: pack 15 N-000156 (only 1.1 can be sent)
    def test_non_11_cannot_be_sent(self):
        c, _s = pair()
        with self.assertRaises(LocalProtocolError):
            c.send(Request(method=b"GET", target=b"/", headers=[("Host", "h")],
                           http_version=b"1.0"))

    # spec: pack 15 N-000165 (status line w/o reason) and N-000166
    def test_status_line_without_reason_accepted(self):
        c, _s = pair()
        c.send(get_request())
        c.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 204\r\n\r\n")
        r = c.next_event()
        self.assertEqual(r.reason, b"")
        self.assertEqual(r.status_code, 204)


if __name__ == "__main__":
    unittest.main()
