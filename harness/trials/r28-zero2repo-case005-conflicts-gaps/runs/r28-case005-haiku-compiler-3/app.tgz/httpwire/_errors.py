"""Exception classes.

spec: pack 07 (Errors), pack 18 (FP-05).

LocalProtocolError and RemoteProtocolError are sibling classes; neither is a
subclass of the other. Both carry ``error_status_hint`` (an exact ``int``,
default 400).
"""


class ProtocolError(Exception):
    """Common base for the two protocol-error kinds (not exported at root)."""

    def __init__(self, msg="", error_status_hint=400):
        Exception.__init__(self, msg)
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(ProtocolError):
    """The integrator's own event or send violated the protocol."""


class RemoteProtocolError(ProtocolError):
    """The peer's bytes violated the protocol."""


class _InvalidArgument(LocalProtocolError, ValueError):
    """Bad constructor argument (e.g. an unknown role). Also a ValueError."""


class ReceiveAfterCloseError(RuntimeError):
    """Non-empty bytes fed after the receive side was closed.

    spec: pack 15 (FP-02), pack 18 (FP-05), pack 19 (FP-06). Deliberately not a
    protocol error.
    """
