"""The sans-I/O connection object.

spec: pack 05 (surface), pack 08 (Connection), pack 15 (FP-02), pack 16 (FP-03),
pack 17 (FP-04), pack 18 (FP-05), pack 19 (FP-06), pack 20 (FP-07).

State is kept per role in ``self._states``. Sending and pulling an event both
run ``_transition`` for the emitting role, then ``_post`` for the cross-role
rules. Both ends of a conversation therefore apply the same transitions.
"""

from ._errors import (
    LocalProtocolError,
    RemoteProtocolError,
    ReceiveAfterCloseError,
    _InvalidArgument,
)
from ._events import (
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    Request,
    Response,
)
from ._headers import has_token
from ._sentinels import (
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
)
from ._wire import next_line, parse_chunk_size, parse_status_code, scan_head

# spec: pack 08 N-000478..N-000480 (default 8 KiB; conflicts with pack 15/18
# "14 to 18 KiB"; see NOTES.md).
DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 8 * 1024

_OTHER = {CLIENT: SERVER, SERVER: CLIENT}
_VERSIONS = {b"HTTP/1.1": b"1.1", b"HTTP/1.0": b"1.0"}
_FRAMING_HEADERS = (b"content-length", b"transfer-encoding")


class _Framing(object):
    """How one side's message body is framed.

    kind: "length" (remaining bytes), "chunked", "close" (close-delimited),
    or "none" (no body bytes at all: HEAD, 204, 304, switch acceptance).
    """

    __slots__ = ("kind", "remaining", "sub", "chunk_remaining", "started")

    def __init__(self, kind, remaining=0):
        self.kind = kind
        self.remaining = remaining
        self.sub = "size"
        self.chunk_remaining = 0
        self.started = False


def _byte_len(obj):
    try:
        return memoryview(obj).nbytes
    except TypeError:
        return len(obj)


def _is_bytes_like(obj):
    return isinstance(obj, (bytes, bytearray, memoryview))


def _first(items, name):
    for it in items:
        if it[1] == name:
            return it
    return None


def _field_bytes(items):
    """Wire form of stored (raw, lower, value) items, each line CRLF-ended."""
    return b"".join(it[0] + b": " + it[2] + b"\r\n" for it in items)


def _without_keep_alive(items):
    """Drop keep-alive tokens and add ``Connection: close``.

    spec: pack 17 N-000265..N-000269.
    """
    tokens = []
    out = []
    for it in items:
        if it[1] == b"connection":
            for piece in it[2].split(b","):
                tok = piece.strip(b" \t")
                if tok and tok.lower() not in (b"keep-alive", b"close"):
                    tokens.append(tok)
        else:
            out.append(it)
    tokens.append(b"close")
    out.append((b"Connection", b"connection", b", ".join(tokens)))
    return out


def _proposals_for(request):
    """Switch proposals made by a request. spec: pack 20 N-000360..N-000372."""
    found = set()
    stored = request.headers._stored()
    if _first(stored, b"upgrade") is not None:
        found.add("upgrade")
    if request.method == b"CONNECT":
        found.add("connect")
    return found


def _join(pieces):
    parts = []
    for p in pieces:
        parts.append(p if isinstance(p, bytes) else bytes(memoryview(p)))
    return b"".join(parts)


class Connection(object):
    """One HTTP/1.1 connection in the CLIENT or SERVER role.

    spec: pack 08. Performs no I/O: bytes go in through ``receive_data`` and
    come out of ``send``.
    """

    def __init__(self, role, max_incomplete_event_size=None):
        # spec: pack 15 N-000172, N-000173; pack 08 N-000476, N-000477.
        if role is not CLIENT and role is not SERVER:
            raise _InvalidArgument("role must be CLIENT or SERVER")
        if max_incomplete_event_size is None:
            max_incomplete_event_size = DEFAULT_MAX_INCOMPLETE_EVENT_SIZE
        elif (isinstance(max_incomplete_event_size, bool)
              or not isinstance(max_incomplete_event_size, int)
              or max_incomplete_event_size <= 0):
            raise _InvalidArgument("max_incomplete_event_size must be a positive int")

        self._our_role = role
        self._their_role = _OTHER[role]
        self._states = {CLIENT: IDLE, SERVER: IDLE}
        self._max_incomplete = int(max_incomplete_event_size)

        self._recv = bytearray()
        self._recv_closed = False

        self._ours = None      # framing of our current body (writer)
        self._theirs = None    # framing of the peer's current body (reader)
        self._their_version = None
        self._request_method = None
        self._proposals = set()
        self._client_waiting = False
        self._disable_keep_alive = False

    # ----- queryable attributes (spec: pack 08 attribute table) -------------

    @property
    def our_role(self):
        return self._our_role

    @property
    def their_role(self):
        return self._their_role

    @property
    def our_state(self):
        return self._states[self._our_role]

    @property
    def their_state(self):
        return self._states[self._their_role]

    @property
    def states(self):
        return {CLIENT: self._states[CLIENT], SERVER: self._states[SERVER]}

    @property
    def their_http_version(self):
        return self._their_version

    @property
    def client_is_waiting_for_100_continue(self):
        return bool(self._client_waiting)

    @property
    def they_are_waiting_for_100_continue(self):
        return self._their_role is CLIENT and bool(self._client_waiting)

    @property
    def trailing_data(self):
        return (bytes(self._recv), bool(self._recv_closed))

    # ----- send side ---------------------------------------------------------

    def send(self, event):
        """Encode an event to bytes (b"" when it produces none)."""
        return _join(self._send(event, passthrough=False))

    def send_with_data_passthrough(self, event):
        """Like send, but returns a list of pieces; a non-bytes payload object
        is kept as the same object. spec: pack 16 N-000233..N-000237."""
        return self._send(event, passthrough=True)

    def _send(self, event, passthrough):
        our = self._our_role
        try:
            new_states = self._transition(our, event)
            t = type(event)
            if t is Request:
                pieces, ctx = self._request_pieces(event)
            elif t is InformationalResponse:
                pieces, ctx = self._informational_pieces(event)
            elif t is Response:
                pieces, ctx = self._response_pieces(event)
            elif t is Data:
                pieces, ctx = self._data_pieces(event, passthrough)
            elif t is EndOfMessage:
                pieces, ctx = self._eom_pieces(event)
            else:
                pieces, ctx = [], {}
        except LocalProtocolError:
            # spec: pack 18 N-000307..N-000310. A refused send is unrecoverable
            # for sending.
            self._fail_side(our)
            raise
        self._commit(our, event, new_states, ctx, sending=True)
        return pieces

    def _request_pieces(self, event):
        if event.http_version != b"1.1":
            raise LocalProtocolError("httpwire sends only HTTP/1.1")
        stored = event.headers._stored()
        cl = _first(stored, b"content-length")
        te = _first(stored, b"transfer-encoding")
        # spec: pack 14 N-000096: Content-Length decides framing for a request.
        if cl is not None:
            framing = _Framing("length", int(cl[2]))
            items = [it for it in stored if it is not te]
        elif te is not None:
            framing = _Framing("chunked")
            items = stored
        else:
            framing = _Framing("length", 0)
            items = stored
        # spec: pack 15 N-000161: Host is written first.
        hosts = [it for it in items if it[1] == b"host"]
        rest = [it for it in items if it[1] != b"host"]
        line = event.method + b" " + event.target + b" HTTP/1.1\r\n"
        wire = line + _field_bytes(hosts + rest) + b"\r\n"
        return [wire], {"framing": framing}

    def _informational_pieces(self, event):
        if event.http_version != b"1.1":
            raise LocalProtocolError("httpwire sends only HTTP/1.1")
        wire = _status_line(event) + _field_bytes(event.headers._stored()) + b"\r\n"
        return [wire], {}

    def _response_pieces(self, event):
        # spec: pack 16 N-000200..N-000218; pack 17 N-000265..N-000269;
        # pack 20 N-000381 (accepted CONNECT carries no framing).
        if event.http_version != b"1.1":
            raise LocalProtocolError("httpwire sends only HTTP/1.1")
        stored = event.headers._stored()
        status = event.status_code
        peer_11 = self._their_version == b"1.1"
        is_head = self._request_method == b"HEAD"

        if status == 200 and "connect" in self._proposals:
            items = stored
            framing = _Framing("none")
            disable = False
        else:
            has_te = _first(stored, b"transfer-encoding") is not None
            cl = _first(stored, b"content-length")
            if status in (204, 304):
                mode = "strip"
            elif cl is not None and not has_te:
                mode = "length"
            elif peer_11:
                mode = "chunked"
            else:
                mode = "close"

            items = []
            for it in stored:
                if mode == "strip" and it[1] in _FRAMING_HEADERS:
                    continue
                if mode == "chunked" and it[1] == b"content-length":
                    continue
                if mode == "close" and it[1] in _FRAMING_HEADERS:
                    continue
                items.append(it)
            if mode == "chunked" and _first(items, b"transfer-encoding") is None:
                items.append((b"Transfer-Encoding", b"transfer-encoding", b"chunked"))

            if mode == "strip" or is_head:
                framing = _Framing("none")
            elif mode == "length":
                framing = _Framing("length", int(cl[2]))
            elif mode == "chunked":
                framing = _Framing("chunked")
            else:
                framing = _Framing("close")

            disable = (mode == "close" or not peer_11 or self._keep_alive_disabled())
            if disable:
                items = _without_keep_alive(items)

        wire = _status_line(event) + _field_bytes(items) + b"\r\n"
        return [wire], {"framing": framing, "disable": disable}

    def _data_pieces(self, event, passthrough):
        f = self._ours
        if f is None:
            raise LocalProtocolError("no body is open for data")
        payload = event.data
        if _is_bytes_like(payload):
            n = _byte_len(payload)
            if passthrough:
                piece = payload
            else:
                piece = payload if isinstance(payload, bytes) else bytes(memoryview(payload))
        elif passthrough and hasattr(payload, "__len__"):
            n = len(payload)
            piece = payload
        else:
            raise LocalProtocolError("Data payload must be bytes-like")

        if f.kind == "none":
            if n:
                raise LocalProtocolError("this message has no body")
            return [], {"consume": 0}
        if f.kind == "length":
            if n > f.remaining:
                raise LocalProtocolError("data exceeds the declared Content-Length")
            return ([piece] if n else []), {"consume": n}
        if f.kind == "chunked":
            if n == 0:
                return [], {"consume": 0}
            size_line = format(n, "x").encode("ascii") + b"\r\n"
            return [size_line, piece, b"\r\n"], {"consume": n}
        # close-delimited
        return ([piece] if n else []), {"consume": n}

    def _eom_pieces(self, event):
        f = self._ours
        if f is None:
            raise LocalProtocolError("no body is open to end")
        trailers = event.headers._stored()
        if f.kind == "chunked":
            return [b"0\r\n" + _field_bytes(trailers) + b"\r\n"], {}
        if trailers:
            raise LocalProtocolError("trailing headers are not allowed with this framing")
        if f.kind == "length" and f.remaining != 0:
            raise LocalProtocolError("end-of-message before the declared Content-Length was sent")
        return [], {}

    def send_failed(self):
        """Mark the last send as not transmitted. spec: pack 18 N-000312..N-000315."""
        self._fail_side(self._our_role)
        return None

    # ----- receive side -----------------------------------------------------

    def receive_data(self, data):
        """Store bytes from the peer. Empty bytes means the peer closed its
        sending side. spec: pack 15 N-000144..N-000152, N-000180..N-000182."""
        if _byte_len(data) == 0:
            self._recv_closed = True
            return None
        if self._recv_closed:
            raise ReceiveAfterCloseError("bytes fed after the receive side was closed")
        self._recv += bytes(memoryview(data))
        return None

    def next_event(self):
        """Pull one event, NEED_DATA, or PAUSED.

        spec: pack 08 N-000512..N-000516; pack 18 N-000302..N-000306.
        """
        their = self._their_role
        if self._states[their] is ERROR:
            raise RemoteProtocolError("peer is in the ERROR state; cannot receive")
        try:
            return self._next_event_unchecked()
        except LocalProtocolError as exc:
            self._fail_side(their)
            raise RemoteProtocolError(str(exc), error_status_hint=exc.error_status_hint)
        except RemoteProtocolError:
            self._fail_side(their)
            raise

    def _next_event_unchecked(self):
        their = self._their_role
        st = self._states[their]
        buf = self._recv

        if st is SWITCHED_PROTOCOL or st is MIGHT_SWITCH_PROTOCOL:
            # spec: pack 20 N-000373..N-000377, N-000381..N-000391.
            return PAUSED
        if st is CLOSED:
            return ConnectionClosed()
        if st is SEND_BODY:
            return self._read_body()
        if st is DONE or st is MUST_CLOSE:
            # spec: pack 17 N-000275..N-000279 (pipelining pause).
            if buf:
                return PAUSED
            if self._recv_closed:
                return self._emit_pulled(ConnectionClosed())
            return NEED_DATA
        # IDLE or SEND_RESPONSE: a message head is next.
        if not buf:
            if self._recv_closed:
                if st is IDLE:
                    return self._emit_pulled(ConnectionClosed())
                raise RemoteProtocolError("peer closed the connection in the middle of a message")
            return NEED_DATA
        return self._read_head()

    def _read_head(self):
        buf = self._recv
        if buf[0] < 0x21:
            # spec: pack 15 N-000177..N-000179: fail at once.
            raise RemoteProtocolError("invalid first byte where a start line is expected")
        scanned = scan_head(buf, True)
        if scanned is None:
            if len(buf) > self._max_incomplete:
                raise RemoteProtocolError("incomplete event exceeds the size limit",
                                          error_status_hint=431)
            if self._recv_closed:
                raise RemoteProtocolError("peer closed the connection in the middle of a message")
            return NEED_DATA
        start, pairs, consumed = scanned
        if self._their_role is CLIENT:
            event, ctx = self._build_request(start, pairs)
        else:
            event, ctx = self._build_response(start, pairs)
        del buf[:consumed]
        return self._emit_pulled(event, ctx)

    def _build_request(self, start, pairs):
        parts = start.split(b" ")
        if len(parts) != 3:
            raise RemoteProtocolError("malformed request line")
        method, target, ver = parts
        version = _VERSIONS.get(ver)
        if version is None:
            raise RemoteProtocolError("unsupported HTTP version")
        event = Request(method=method, target=target, headers=pairs, http_version=version)
        stored = event.headers._stored()
        cl = _first(stored, b"content-length")
        if cl is not None:
            framing = _Framing("length", int(cl[2]))
        elif _first(stored, b"transfer-encoding") is not None:
            framing = _Framing("chunked")
        else:
            framing = _Framing("length", 0)
        return event, {"framing": framing}

    def _build_response(self, start, pairs):
        ver, sp, rest = start.partition(b" ")
        version = _VERSIONS.get(ver)
        if not sp or version is None:
            raise RemoteProtocolError("malformed status line")
        code_raw, _sp2, reason = rest.partition(b" ")
        status = parse_status_code(code_raw)
        if 100 <= status < 200:
            event = InformationalResponse(status_code=status, headers=pairs,
                                          http_version=version, reason=reason)
            return event, {}
        if 200 <= status < 1000:
            event = Response(status_code=status, headers=pairs,
                             http_version=version, reason=reason)
            # spec: pack 16 N-000208..N-000218.
            if self._request_method == b"HEAD" or status in (204, 304):
                framing = _Framing("none")
            else:
                stored = event.headers._stored()
                cl = _first(stored, b"content-length")
                if _first(stored, b"transfer-encoding") is not None:
                    framing = _Framing("chunked")
                elif cl is not None:
                    framing = _Framing("length", int(cl[2]))
                else:
                    framing = _Framing("close")
            return event, {"framing": framing}
        raise RemoteProtocolError("status code out of range")

    def _read_body(self):
        f = self._theirs
        buf = self._recv
        if f is None:
            return NEED_DATA
        if f.kind == "chunked":
            return self._read_chunked(f)
        if f.kind == "none":
            return self._emit_pulled(EndOfMessage())
        if f.kind == "length":
            if f.remaining == 0:
                return self._emit_pulled(EndOfMessage())
            if buf:
                k = min(len(buf), f.remaining)
                data = bytes(buf[:k])
                del buf[:k]
                f.remaining -= k
                return self._emit_pulled(Data(data))
            if self._recv_closed:
                raise RemoteProtocolError("peer closed the connection in the middle of a body")
            return NEED_DATA
        # close-delimited: every byte until the receive side closes.
        # spec: pack 16 N-000208..N-000214.
        if buf:
            data = bytes(buf)
            del buf[:]
            return self._emit_pulled(Data(data))
        if self._recv_closed:
            return self._emit_pulled(EndOfMessage())
        return NEED_DATA

    def _read_chunked(self, f):
        buf = self._recv
        while True:
            if f.sub == "size":
                r = next_line(buf, 0)
                if r is None:
                    if self._recv_closed:
                        raise RemoteProtocolError("peer closed the connection in the middle of a chunk")
                    return NEED_DATA
                line, consumed = r
                del buf[:consumed]
                size = parse_chunk_size(line)
                if size == 0:
                    f.sub = "trailers"
                else:
                    f.sub = "data"
                    f.chunk_remaining = size
                    f.started = False
            elif f.sub == "data":
                if not buf:
                    if self._recv_closed:
                        raise RemoteProtocolError("peer closed the connection in the middle of a chunk")
                    return NEED_DATA
                k = min(len(buf), f.chunk_remaining)
                data = bytes(buf[:k])
                del buf[:k]
                is_start = not f.started
                f.started = True
                f.chunk_remaining -= k
                chunk_end = f.chunk_remaining == 0
                if chunk_end:
                    f.sub = "crlf"
                return self._emit_pulled(
                    Data(data, chunk_start=is_start, chunk_end=chunk_end))
            elif f.sub == "crlf":
                head = bytes(buf[:2])
                if head == b"\r\n":
                    del buf[:2]
                    f.sub = "size"
                    continue
                if len(head) < 2 and b"\r\n".startswith(head):
                    if self._recv_closed:
                        raise RemoteProtocolError("peer closed the connection in the middle of a chunk")
                    return NEED_DATA
                raise RemoteProtocolError("chunk data not followed by CRLF")
            else:  # trailers
                scanned = scan_head(buf, False)
                if scanned is None:
                    if len(buf) > self._max_incomplete:
                        raise RemoteProtocolError("trailer block exceeds the size limit",
                                                  error_status_hint=431)
                    if self._recv_closed:
                        raise RemoteProtocolError("peer closed the connection in the middle of trailers")
                    return NEED_DATA
                _start, pairs, consumed = scanned
                del buf[:consumed]
                return self._emit_pulled(EndOfMessage(headers=pairs))

    def _emit_pulled(self, event, ctx=None):
        their = self._their_role
        new_states = self._transition(their, event)
        self._commit(their, event, new_states, ctx or {}, sending=False)
        return event

    # ----- cycle control ----------------------------------------------------

    def start_next_cycle(self):
        """Reset both sides to IDLE. spec: pack 17 N-000270..N-000282."""
        if self._states[CLIENT] is not DONE or self._states[SERVER] is not DONE:
            raise LocalProtocolError("cannot start the next cycle: both sides must be DONE")
        self._states = {CLIENT: IDLE, SERVER: IDLE}
        self._ours = None
        self._theirs = None
        self._their_version = None
        self._request_method = None
        self._proposals = set()
        self._client_waiting = False
        self._disable_keep_alive = False
        return None

    # ----- internals: state machine ----------------------------------------

    def _transition(self, role, event):
        """Return the new states if ``role`` may emit ``event``; else raise."""
        s = dict(self._states)
        t = type(event)
        if t is Request:
            if role is not CLIENT or s[CLIENT] is not IDLE:
                raise LocalProtocolError("a request is only allowed from a client in IDLE")
            s[CLIENT] = SEND_BODY
            if s[SERVER] is IDLE:
                s[SERVER] = SEND_RESPONSE
        elif t is InformationalResponse:
            if role is not SERVER or s[SERVER] is not SEND_RESPONSE:
                raise LocalProtocolError("informational response not allowed now")
            if event.status_code == 101 and "upgrade" in self._proposals:
                # spec: pack 20 N-000366..N-000372, N-000381.
                s[SERVER] = SWITCHED_PROTOCOL
                s[CLIENT] = SWITCHED_PROTOCOL
        elif t is Response:
            if role is not SERVER or (s[SERVER] is not IDLE and s[SERVER] is not SEND_RESPONSE):
                raise LocalProtocolError("final response not allowed now")
            # spec: pack 20 N-000394..N-000398: only 200 accepts CONNECT.
            if event.status_code == 200 and "connect" in self._proposals:
                s[SERVER] = SWITCHED_PROTOCOL
                s[CLIENT] = SWITCHED_PROTOCOL
            else:
                s[SERVER] = SEND_BODY
                if s[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                    s[CLIENT] = DONE  # denial. spec: pack 20 N-000378..N-000380
        elif t is Data:
            if s[role] is not SEND_BODY:
                raise LocalProtocolError("data is only allowed while sending a body")
        elif t is EndOfMessage:
            if s[role] is not SEND_BODY:
                raise LocalProtocolError("end-of-message is only allowed while sending a body")
            if role is CLIENT and self._proposals:
                s[CLIENT] = MIGHT_SWITCH_PROTOCOL  # spec: pack 20 N-000373..N-000377
            else:
                s[role] = DONE
        elif t is ConnectionClosed:
            if s[role] not in (IDLE, DONE, MUST_CLOSE):
                raise LocalProtocolError("connection-closed is not allowed in this state")
            s[role] = CLOSED
        else:
            raise LocalProtocolError("not an event")
        return s

    def _keep_alive_disabled(self):
        # spec: pack 17 N-000259..N-000264, N-000286.
        if self._disable_keep_alive:
            return True
        if self._states[self._their_role] is ERROR:
            return True
        if self._their_version is not None and self._their_version != b"1.1":
            return True
        return False

    def _post(self):
        """Cross-role rules that run after every state change."""
        s = self._states
        for r in (CLIENT, SERVER):
            o = _OTHER[r]
            # spec: pack 18 N-000311
            if s[r] is ERROR and s[o] is DONE:
                s[o] = MUST_CLOSE
            # spec: pack 19 N-000336..N-000338
            if s[r] is CLOSED and (s[o] is IDLE or s[o] is DONE):
                s[o] = MUST_CLOSE
        # spec: pack 17 N-000264: when keep-alive is off, DONE becomes MUST_CLOSE.
        if self._keep_alive_disabled():
            for r in (CLIENT, SERVER):
                if s[r] is DONE:
                    s[r] = MUST_CLOSE

    def _fail_side(self, role):
        self._states[role] = ERROR
        self._post()

    def _commit(self, role, event, new_states, ctx, sending):
        """Apply a transition that has already been validated."""
        t = type(event)
        self._states = new_states
        framing = ctx.get("framing")

        if t is Request or t is InformationalResponse or t is Response:
            stored = event.headers._stored()
            if has_token(stored, b"connection", b"close"):
                self._disable_keep_alive = True
            if not sending and self._their_version is None:
                self._their_version = event.http_version

        if t is Request:
            self._request_method = event.method
            self._proposals = _proposals_for(event)
            stored = event.headers._stored()
            if event.http_version == b"1.1" and has_token(stored, b"expect", b"100-continue"):
                self._client_waiting = True  # spec: pack 20 N-000354..N-000357
            if sending:
                self._ours = framing
            else:
                self._theirs = framing

        elif t is InformationalResponse:
            if new_states[SERVER] is SWITCHED_PROTOCOL:
                self._proposals = set()
            if role is SERVER:
                self._client_waiting = False  # spec: pack 20 N-000358

        elif t is Response:
            self._proposals = set()
            if role is SERVER:
                self._client_waiting = False
            if new_states[SERVER] is SWITCHED_PROTOCOL:
                framing = _Framing("none")
            if ctx.get("disable"):
                self._disable_keep_alive = True
            if sending:
                self._ours = framing
            else:
                self._theirs = framing
                if framing is not None and framing.kind == "close":
                    self._disable_keep_alive = True

        elif t is Data:
            if role is CLIENT:
                self._client_waiting = False  # spec: pack 20 N-000359
            if sending and self._ours is not None and self._ours.kind == "length":
                self._ours.remaining -= ctx.get("consume", 0)

        elif t is EndOfMessage:
            if role is CLIENT:
                self._client_waiting = False
            if sending:
                self._ours = None
            else:
                self._theirs = None

        self._post()


def _status_line(event):
    return (b"HTTP/1.1 " + str(event.status_code).encode("ascii") + b" "
            + event.reason + b"\r\n")
