"""The six event types.

spec: pack 14 (FP-01), pack 06 (Events), pack 05 (surface).

Every constructor refuses invalid input with LocalProtocolError and produces
no event (N-000466, N-000101).
"""

from ._errors import LocalProtocolError
from ._headers import (
    Headers,
    check_reason,
    check_target,
    check_token,
    check_version,
    to_bytes,
)


def _status(value, low, high):
    # spec: pack 14 N-000112, N-000113. Non-int statuses are refused.
    if isinstance(value, bool) or not isinstance(value, int):
        raise LocalProtocolError("status code must be an integer")
    v = int(value)
    if not (low <= v <= high):
        raise LocalProtocolError("status code %d out of range" % v)
    return v


def _bytes_default(value, default, what):
    if value is None:
        return default
    return to_bytes(value, what)


class _Event(object):
    _fields = ()

    def __eq__(self, other):
        if type(self) is not type(other):
            return NotImplemented
        return all(getattr(self, f) == getattr(other, f) for f in self._fields)

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    __hash__ = None

    def __repr__(self):
        inner = ", ".join("%s=%r" % (f, getattr(self, f)) for f in self._fields)
        return "%s(%s)" % (type(self).__name__, inner)


class Request(_Event):
    """Start of a request. spec: pack 14 N-000072..N-000078, N-000104."""

    _fields = ("method", "target", "headers", "http_version")

    def __init__(self, method, target, headers, http_version=b"1.1"):
        self.method = check_token(to_bytes(method, "method"), "method")
        self.target = check_target(to_bytes(target, "target"))
        self.headers = Headers(headers)
        self.http_version = check_version(
            _bytes_default(http_version, b"1.1", "http_version"))
        hosts = sum(1 for name, _v in self.headers if name == b"host")
        if hosts > 1:
            raise LocalProtocolError("more than one Host header")
        if self.http_version == b"1.1" and hosts == 0:
            raise LocalProtocolError("HTTP/1.1 request needs a Host header")


class InformationalResponse(_Event):
    """1xx response. spec: pack 14 N-000079..N-000083."""

    _fields = ("status_code", "headers", "http_version", "reason")

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        self.status_code = _status(status_code, 100, 199)
        self.headers = Headers(headers)
        self.http_version = check_version(
            _bytes_default(http_version, b"1.1", "http_version"))
        self.reason = check_reason(_bytes_default(reason, b"", "reason"))


class Response(_Event):
    """Final response (200..999). spec: pack 14 N-000079..N-000083."""

    _fields = ("status_code", "headers", "http_version", "reason")

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        self.status_code = _status(status_code, 200, 999)
        self.headers = Headers(headers)
        self.http_version = check_version(
            _bytes_default(http_version, b"1.1", "http_version"))
        self.reason = check_reason(_bytes_default(reason, b"", "reason"))


class Data(_Event):
    """A piece of a message body. spec: pack 14 N-000084; pack 06 N-000463..N-000465."""

    _fields = ("data", "chunk_start", "chunk_end")

    def __init__(self, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)


class EndOfMessage(_Event):
    """End of a message, with optional trailing headers. spec: pack 14 N-000085."""

    _fields = ("headers",)

    def __init__(self, headers=()):
        self.headers = Headers(headers)


class ConnectionClosed(_Event):
    """This party will send no more HTTP data. spec: pack 14 N-000086."""

    _fields = ()

    def __init__(self):
        pass
