"""Byte-level scanners for the receive side.

spec: pack 14 (FP-01 header rules), pack 15 (FP-02 line endings, folding,
first-byte rule), pack 16 (FP-03 chunk-size lines).
"""

import re

from ._errors import RemoteProtocolError

# spec: pack 16 N-000228..N-000232. Between 16 and 32 digits is allowed; we
# use 32 (pack 16 N-000192 says "up to 64", which conflicts; see NOTES.md).
_CHUNK_SIZE_RE = re.compile(rb"([0-9a-fA-F]{1,32})(;[\t\x20-\x7e\x80-\xff]*)?\Z")
_STATUS_CODE_RE = re.compile(rb"[0-9]{3}\Z")


def next_line(buf, pos):
    """Return (line, next_pos) for the line starting at ``pos``, or None.

    A line ends at LF; one CR immediately before the LF is removed. Lone LF is
    accepted (spec: pack 15 N-000165, which conflicts with pack 08 N-000510;
    see NOTES.md).
    """
    i = buf.find(b"\n", pos)
    if i < 0:
        return None
    line = bytes(buf[pos:i])
    if line.endswith(b"\r"):
        line = line[:-1]
    return line, i + 1


def scan_head(buf, with_start):
    """Scan a message head (optional start line, then field lines, blank line).

    Returns (start_line_or_None, pairs, consumed_bytes), or None when the head
    is not yet complete. Raises RemoteProtocolError for malformed lines.

    Obsolete line folding is accepted: a continuation line is joined to the
    previous value with one space (spec: pack 15 N-000167..N-000169; conflicts
    with N-000176, see NOTES.md).
    """
    pos = 0
    start = None
    if with_start:
        r = next_line(buf, pos)
        if r is None:
            return None
        start, pos = r
    pairs = []
    while True:
        r = next_line(buf, pos)
        if r is None:
            return None
        line, pos = r
        if not line:
            return start, pairs, pos
        if line[0] in (0x20, 0x09):
            if not pairs:
                raise RemoteProtocolError("continuation line with no header to fold into")
            name, value = pairs[-1]
            extra = line.strip(b" \t")
            if extra:
                value = value + b" " + extra
            pairs[-1] = (name, value)
        else:
            colon = line.find(b":")
            if colon <= 0:
                raise RemoteProtocolError("malformed header line")
            pairs.append((line[:colon], line[colon + 1:].strip(b" \t")))


def parse_chunk_size(line):
    """Return the chunk size (int) from a chunk-size line, or raise.

    spec: pack 16 N-000228..N-000232, N-000242..N-000245. Extensions are
    accepted and discarded; whitespace directly after the size is refused.
    """
    m = _CHUNK_SIZE_RE.match(line)
    if m is None:
        raise RemoteProtocolError("malformed chunk-size line")
    return int(m.group(1), 16)


def parse_status_code(raw):
    if not _STATUS_CODE_RE.match(raw):
        raise RemoteProtocolError("status code must be three digits")
    return int(raw)
