"""Package-root sentinel objects: roles, states, and pull results.

Each sentinel is a distinct object compared by identity. None of them is a
string, and none is an event instance.
"""


class _Sentinel(object):
    __slots__ = ("name",)

    def __init__(self, name):
        self.name = name

    def __repr__(self):
        return self.name


# Roles (spec: pack 05, FP-02)
CLIENT = _Sentinel("CLIENT")
SERVER = _Sentinel("SERVER")

# Non-event results of Connection.next_event (spec: pack 05)
NEED_DATA = _Sentinel("NEED_DATA")
PAUSED = _Sentinel("PAUSED")

# The nine connection states (spec: pack 05, pack 15 FP-02)
IDLE = _Sentinel("IDLE")
SEND_RESPONSE = _Sentinel("SEND_RESPONSE")
SEND_BODY = _Sentinel("SEND_BODY")
DONE = _Sentinel("DONE")
MUST_CLOSE = _Sentinel("MUST_CLOSE")
CLOSED = _Sentinel("CLOSED")
MIGHT_SWITCH_PROTOCOL = _Sentinel("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = _Sentinel("SWITCHED_PROTOCOL")
ERROR = _Sentinel("ERROR")
