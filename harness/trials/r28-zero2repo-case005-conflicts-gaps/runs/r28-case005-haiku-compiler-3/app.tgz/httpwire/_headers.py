"""Header list: validation and normalization.

spec: pack 06 (Header list), pack 14 (FP-01 header normalization).

Stored form of each header is (raw_name, lower_name, value), all ``bytes``.
Ordinary view: (lower_name, value). Raw view: (raw_name, value).
"""

import re

from ._errors import LocalProtocolError

# RFC 7230 token (spec: pack 14, "header name must be an RFC 7230 token").
_TOKEN_RE = re.compile(rb"[!#$%&'*+\-.^_`|~0-9A-Za-z]+\Z")
_DIGITS_RE = re.compile(rb"[0-9]+\Z")
_TARGET_RE = re.compile(rb"[\x21-\x7e]+\Z")
_VERSION_RE = re.compile(rb"[0-9]\.[0-9]\Z")

# spec: pack 14 says a Content-Length longer than 16 digits is refused
# (pack 06 N-000462); pack 14 also says values of at most 18 digits are
# accepted (N-000114..N-000119). Those two cannot both hold. We use 16 digits.
MAX_CONTENT_LENGTH_DIGITS = 16


def to_bytes(value, what):
    """Byte-valued argument: ASCII str, bytes, or any bytes-like object.

    spec: pack 06 (N-000458, N-000459).
    """
    if isinstance(value, bytes):
        return value
    if isinstance(value, str):
        try:
            return value.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("%s must be ASCII" % what)
    if isinstance(value, (bytearray, memoryview)):
        return bytes(value)
    raise LocalProtocolError("%s must be bytes or ASCII str" % what)


def check_token(raw, what):
    if not _TOKEN_RE.match(raw):
        raise LocalProtocolError("%s must be an RFC 7230 token" % what)
    return raw


def check_target(raw):
    if not _TARGET_RE.match(raw):
        raise LocalProtocolError("request target must be visible ASCII")
    return raw


def check_version(raw):
    if not _VERSION_RE.match(raw):
        raise LocalProtocolError("HTTP version must look like 1.1")
    return raw


def check_reason(raw):
    if b"\r" in raw or b"\n" in raw or b"\x00" in raw:
        raise LocalProtocolError("reason phrase contains a forbidden byte")
    return raw


def check_value(val):
    """Header value rule (spec: pack 14 N-000097..N-000100, N-000108).

    Refused: NUL, CR, LF, VT, FF, and other control bytes (tab is the only
    allowed control byte), plus DEL. Space or tab may not begin or end a
    value. Non-ASCII bytes are allowed.
    """
    for c in bytearray(val):
        if c == 0x09:
            continue
        if c < 0x20 or c == 0x7F:
            raise LocalProtocolError("header value contains a control byte")
    if val[:1] in (b" ", b"\t") or val[-1:] in (b" ", b"\t"):
        raise LocalProtocolError("header value begins or ends with space/tab")
    return val


def normalize(pairs):
    """Turn caller pairs into the stored list of (raw, lower, value) items."""
    items = []
    for pair in pairs:
        try:
            name, value = pair
        except (TypeError, ValueError):
            raise LocalProtocolError("header must be a (name, value) pair")
        raw = check_token(to_bytes(name, "header name"), "header name")
        val = check_value(to_bytes(value, "header value"))
        items.append([raw, raw.lower(), val])

    # Content-Length: equal values collapse to one; disagreement is refused.
    # spec: pack 14 N-000092..N-000094, N-000114..N-000119.
    cl_idx = [i for i, it in enumerate(items) if it[1] == b"content-length"]
    if cl_idx:
        nums = []
        for i in cl_idx:
            for piece in items[i][2].split(b","):
                p = piece.strip(b" \t")
                if not _DIGITS_RE.match(p) or len(p) > MAX_CONTENT_LENGTH_DIGITS:
                    raise LocalProtocolError("invalid Content-Length")
                nums.append(int(p))
        if len(set(nums)) != 1:
            raise LocalProtocolError("conflicting Content-Length values")
        first = cl_idx[0]
        new_items = []
        for i, it in enumerate(items):
            if i == first:
                new_items.append([it[0], b"content-length", str(nums[0]).encode("ascii")])
            elif i in cl_idx:
                continue
            else:
                new_items.append(it)
        items = new_items

    # Transfer-Encoding: exactly one header, value exactly "chunked" (any case).
    # Duplicates are refused even when both are chunked (N-000121), which
    # overrides the "collapse" wording of N-000094.
    te_idx = [i for i, it in enumerate(items) if it[1] == b"transfer-encoding"]
    if len(te_idx) > 1:
        raise LocalProtocolError("second Transfer-Encoding header", error_status_hint=501)
    if te_idx:
        it = items[te_idx[0]]
        if it[2].lower() != b"chunked":
            raise LocalProtocolError("unsupported transfer coding", error_status_hint=501)
        it[2] = b"chunked"

    return [tuple(it) for it in items]


def has_token(items, name, token):
    """True if a header named ``name`` (lowercase) lists ``token`` as an element.

    Matching is case-insensitive and whole-element (comma-separated).
    """
    for it in items:
        if it[1] == name:
            for piece in it[2].split(b","):
                if piece.strip(b" \t").lower() == token:
                    return True
    return False


class Headers(object):
    """Sequence container for an event's header list.

    Iteration and indexing yield ordinary (lowercase name, value) pairs.
    ``raw_items()`` yields (name exactly as supplied, value) pairs.
    spec: pack 06 (N-000467..N-000471).
    """

    __slots__ = ("_items",)

    def __init__(self, pairs=()):
        if isinstance(pairs, Headers):
            self._items = list(pairs._items)
        else:
            self._items = normalize(pairs)

    def _ordinary(self):
        return [(lname, value) for (_raw, lname, value) in self._items]

    def __iter__(self):
        return iter(self._ordinary())

    def __len__(self):
        return len(self._items)

    def __getitem__(self, index):
        return self._ordinary()[index]

    def raw_items(self):
        """List of (raw name, value) pairs in order."""
        return [(raw, value) for (raw, _lname, value) in self._items]

    def _stored(self):
        return list(self._items)

    def __eq__(self, other):
        if isinstance(other, Headers):
            return self._ordinary() == other._ordinary()
        try:
            return self._ordinary() == Headers(other)._ordinary()
        except (LocalProtocolError, TypeError):
            return False

    __hash__ = None

    def __repr__(self):
        return "Headers(%r)" % (self._ordinary(),)
