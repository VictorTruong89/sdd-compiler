"""Role, state and result sentinels.

Every value here is a distinct singleton. They compare by identity, are not
strings, and are not instances of any event type.
"""


class _Marker(object):
    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return self._name


class Role(_Marker):
    __slots__ = ()


class State(_Marker):
    __slots__ = ()


class Signal(_Marker):
    __slots__ = ()


CLIENT = Role("CLIENT")
SERVER = Role("SERVER")

IDLE = State("IDLE")
SEND_RESPONSE = State("SEND_RESPONSE")
SEND_BODY = State("SEND_BODY")
DONE = State("DONE")
MUST_CLOSE = State("MUST_CLOSE")
CLOSED = State("CLOSED")
MIGHT_SWITCH_PROTOCOL = State("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = State("SWITCHED_PROTOCOL")
ERROR = State("ERROR")

NEED_DATA = Signal("NEED_DATA")
PAUSED = Signal("PAUSED")
