"""Exception classes."""


class ProtocolError(Exception):
    """Common base of the two protocol-error kinds.

    ``error_status_hint`` is the suggested HTTP status (an ``int``).
    """

    def __init__(self, message, error_status_hint=400):
        Exception.__init__(self, message)
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(ProtocolError):
    """The integrator's own event or send violated the protocol."""


class RemoteProtocolError(ProtocolError):
    """The peer's bytes violated the protocol."""


class ReceiveClosedError(RuntimeError):
    """Non-empty bytes were fed after the receive side had been closed.

    This is deliberately neither a local nor a remote protocol error.
    """
