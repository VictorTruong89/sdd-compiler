"""Header-list normalization and byte-level validation shared by the events."""

import re
from collections.abc import Mapping, Sequence

from ._errors import LocalProtocolError

TOKEN_RE = re.compile(rb"[!#$%&'*+\-.^_`|~0-9A-Za-z]+")
TARGET_RE = re.compile(rb"[\x21-\x7e]+")
VERSION_RE = re.compile(rb"[0-9]\.[0-9]")
DIGITS_RE = re.compile(rb"[0-9]+")
# Control bytes other than horizontal tab. NUL, CR, LF, FF and VT are all
# inside this class, so they are refused too.
BAD_VALUE_RE = re.compile(rb"[\x00-\x08\x0a-\x1f\x7f]")

# Maximum number of decimal digits accepted in a Content-Length value.
MAX_CONTENT_LENGTH_DIGITS = 18


def to_bytes(value, what):
    """Coerce ASCII text or a bytes-like object to ``bytes``."""
    if isinstance(value, str):
        try:
            return value.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("%s must be ASCII text" % what)
    try:
        return bytes(memoryview(value))
    except TypeError:
        raise LocalProtocolError("%s must be text or a bytes-like object" % what)


def check_value(value):
    """Refuse header values that break the FP-01 value rule."""
    if value[:1] in (b" ", b"\t") or value[-1:] in (b" ", b"\t"):
        raise LocalProtocolError("header value must not begin or end with space or tab")
    if BAD_VALUE_RE.search(value):
        raise LocalProtocolError("header value contains a forbidden control byte")


def validate_method(method):
    if not TOKEN_RE.fullmatch(method):
        raise LocalProtocolError("method must be a single RFC 7230 token")
    return method


def validate_target(target):
    if not TARGET_RE.fullmatch(target):
        raise LocalProtocolError("request target must be visible ASCII characters")
    return target


def validate_version(version):
    if not VERSION_RE.fullmatch(version):
        raise LocalProtocolError("HTTP version must look like <digit>.<digit>")
    return version


def check_reason(reason):
    if BAD_VALUE_RE.search(reason):
        raise LocalProtocolError("reason phrase contains a forbidden control byte")
    return reason


def check_status(code, low, high):
    if isinstance(code, bool) or not isinstance(code, int):
        raise LocalProtocolError("status code must be an integer")
    value = int(code)
    if not low <= value <= high:
        raise LocalProtocolError("status code %d is outside %d..%d" % (value, low, high))
    return value


def find_value(pairs, lname):
    """Return the first value whose lowercase name is ``lname``, else None."""
    for name, value in pairs:
        if name == lname:
            return value
    return None


def has_token(pairs, lname, token):
    """True if any header named ``lname`` lists ``token`` (case-insensitive)."""
    for name, value in pairs:
        if name == lname:
            for piece in value.split(b","):
                if piece.strip(b" \t").lower() == token:
                    return True
    return False


class Headers(Sequence):
    """Ordered header list.

    Iterating or indexing yields ``(lowercase_name, value)`` byte pairs.
    ``raw_items()`` yields ``(name_as_spelled_by_caller, value)`` pairs.
    """

    __slots__ = ("_items", "_raw")

    def __init__(self, items, raw):
        self._items = tuple(items)
        self._raw = tuple(raw)

    def __getitem__(self, index):
        return self._items[index]

    def __len__(self):
        return len(self._items)

    def __iter__(self):
        return iter(self._items)

    def raw_items(self):
        return list(self._raw)

    def __eq__(self, other):
        if isinstance(other, Headers):
            return self._items == other._items
        if isinstance(other, (list, tuple)):
            try:
                return list(self._items) == [tuple(pair) for pair in other]
            except TypeError:
                return False
        return NotImplemented

    __hash__ = None

    def __repr__(self):
        return "Headers(%r)" % (list(self._items),)


def normalize_headers(pairs):
    """Validate and normalize a caller's header list into a :class:`Headers`."""
    if isinstance(pairs, Mapping):
        pairs = list(pairs.items())
    try:
        items = list(pairs)
    except TypeError:
        raise LocalProtocolError("headers must be a sequence of (name, value) pairs")

    entries = []  # each: [lowercase_name, value, raw_name]
    for item in items:
        try:
            name, value = item
        except (TypeError, ValueError):
            raise LocalProtocolError("each header must be a (name, value) pair")
        raw = to_bytes(name, "header name")
        if not TOKEN_RE.fullmatch(raw):
            raise LocalProtocolError("header name %r is not an RFC 7230 token" % (raw,))
        val = to_bytes(value, "header value")
        check_value(val)
        entries.append([raw.lower(), val, raw])

    # Content-Length: every piece must be decimal; all pieces must agree;
    # the surviving header is a single entry at the first occurrence.
    cl_idx = [i for i, e in enumerate(entries) if e[0] == b"content-length"]
    if cl_idx:
        digits = []
        for i in cl_idx:
            for piece in entries[i][1].split(b","):
                p = piece.strip(b" \t")
                if not DIGITS_RE.fullmatch(p):
                    raise LocalProtocolError("Content-Length must be a decimal integer")
                if len(p) > MAX_CONTENT_LENGTH_DIGITS:
                    raise LocalProtocolError("Content-Length has too many digits")
                digits.append(p)
        if len(set(int(p) for p in digits)) != 1:
            raise LocalProtocolError("conflicting Content-Length values")
        merged = [b"content-length", digits[0], entries[cl_idx[0]][2]]
        new_entries = []
        for i, e in enumerate(entries):
            if i == cl_idx[0]:
                new_entries.append(merged)
            elif i not in cl_idx:
                new_entries.append(e)
        entries = new_entries

    # Transfer-Encoding: only a single header whose value is chunked.
    te_idx = [i for i, e in enumerate(entries) if e[0] == b"transfer-encoding"]
    if len(te_idx) > 1:
        raise LocalProtocolError("duplicate Transfer-Encoding header", 501)
    if te_idx:
        e = entries[te_idx[0]]
        if e[1].lower() != b"chunked":
            raise LocalProtocolError("only Transfer-Encoding: chunked is supported", 501)
        entries[te_idx[0]] = [b"transfer-encoding", b"chunked", e[2]]

    return Headers(
        [(e[0], e[1]) for e in entries],
        [(e[2], e[1]) for e in entries],
    )
