"""The bring-your-own-I/O HTTP/1.1 connection state machine.

Both sides' states are kept as one pair. Every event, whether sent by us or
pulled from the peer, advances the pair according to its sender's role.
"""

import re

from ._errors import LocalProtocolError, ReceiveClosedError, RemoteProtocolError
from ._events import (
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    Request,
    Response,
)
from ._headers import TOKEN_RE, find_value, has_token
from ._sentinels import (
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
)

DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 8 * 1024

_REQUEST_LINE_RE = re.compile(
    rb"([!#$%&'*+\-.^_`|~0-9A-Za-z]+) ([\x21-\x7e]+) HTTP/([0-9])\.([0-9])"
)
_STATUS_LINE_RE = re.compile(rb"HTTP/([0-9])\.([0-9]) ([0-9]{3})(?: (.*))?", re.DOTALL)
# Hex digits, then either nothing or a ';' extension. Whitespace directly
# after the size is therefore refused; whitespace after an extension is kept
# by the extension class.
_CHUNK_SIZE_RE = re.compile(rb"([0-9A-Fa-f]{1,32})(;[^\x00-\x08\x0a-\x1f\x7f]*)?")


def _other(role):
    return SERVER if role is CLIENT else CLIENT


def _has_expect_continue(headers):
    for name, value in headers:
        if name == b"expect":
            for piece in value.split(b","):
                if piece.strip(b" \t").lower() == b"100-continue":
                    return True
    return False


def _content_length(headers):
    value = find_value(headers, b"content-length")
    if value is None:
        return None
    return int(value.decode("ascii"))


def _request_framing(headers):
    if find_value(headers, b"content-length") is not None:
        return ("length", _content_length(headers))
    if find_value(headers, b"transfer-encoding") is not None:
        return ("chunked",)
    return ("length", 0)


def _response_framing_received(event, method):
    if method == b"HEAD" or event.status_code in (204, 304):
        return ("empty",)
    if find_value(event.headers, b"content-length") is not None:
        return ("length", _content_length(event.headers))
    if find_value(event.headers, b"transfer-encoding") is not None:
        return ("chunked",)
    return ("close",)


def _plan_final_headers(event, peer11, method):
    """Decide the wire headers and body framing for a final response we send.

    Returns (raw_items, framing, close_delimited).
    """
    items = list(event.headers.raw_items())
    status = event.status_code
    if status == 204:
        return items, ("empty",), False

    has_cl = find_value(event.headers, b"content-length") is not None
    has_te = find_value(event.headers, b"transfer-encoding") is not None
    close_delimited = False
    if has_cl and not has_te:
        framing = ("length", _content_length(event.headers))
    elif peer11:
        # Transfer-Encoding wins over Content-Length; the body is chunked.
        items = [it for it in items if it[0].lower() != b"content-length"]
        if not has_te:
            items.append((b"Transfer-Encoding", b"chunked"))
        framing = ("chunked",)
    else:
        items = [
            it for it in items
            if it[0].lower() not in (b"content-length", b"transfer-encoding")
        ]
        framing = ("close",)
        close_delimited = True

    if status == 304 or method == b"HEAD":
        framing = ("empty",)
    return items, framing, close_delimited


def _adjust_connection_header(items):
    """Make the Connection header say close, dropping keep-alive tokens."""
    new = []
    slot = None
    tokens = []
    for name, value in items:
        if name.lower() == b"connection":
            if slot is None:
                slot = len(new)
                new.append(None)
            for piece in value.split(b","):
                t = piece.strip(b" \t")
                if t and t.lower() != b"keep-alive" and t.lower() not in [x.lower() for x in tokens]:
                    tokens.append(t)
            continue
        new.append((name, value))
    if b"close" not in [x.lower() for x in tokens]:
        tokens.append(b"close")
    header = (b"Connection", b", ".join(tokens))
    if slot is None:
        new.append(header)
    else:
        new[slot] = header
    return [x for x in new if x is not None]


def _format_header(name, value):
    return name + b": " + value + b"\r\n"


def _serialize_request(event):
    raw = event.headers.raw_items()
    hosts = [it for it in raw if it[0].lower() == b"host"]
    others = [it for it in raw if it[0].lower() != b"host"]
    head = event.method + b" " + event.target + b" HTTP/1.1\r\n"
    return head + b"".join(_format_header(n, v) for n, v in hosts + others) + b"\r\n"


def _serialize_status(code, reason, items):
    line = b"HTTP/1.1 " + ("%d" % code).encode("ascii") + b" " + reason + b"\r\n"
    return line + b"".join(_format_header(n, v) for n, v in items) + b"\r\n"


def _payload_piece(payload, passthrough):
    """Return (length, piece) for a Data payload, or None if it is unusable."""
    if isinstance(payload, str):
        return None
    try:
        view = memoryview(payload)
    except TypeError:
        view = None
    if view is not None:
        return view.nbytes, (payload if passthrough else bytes(view))
    if passthrough:
        try:
            return len(payload), payload
        except TypeError:
            return None
    return None


class Connection(object):
    """One HTTP/1.1 connection in the client or server role.

    The integrator does all I/O: ``send`` returns bytes to write, and
    ``receive_data`` plus ``next_event`` consume bytes that were read.
    """

    def __init__(self, role, max_incomplete_event_size=None):
        if role is not CLIENT and role is not SERVER:
            raise ValueError("role must be CLIENT or SERVER")
        if max_incomplete_event_size is None:
            max_incomplete_event_size = DEFAULT_MAX_INCOMPLETE_EVENT_SIZE
        if (isinstance(max_incomplete_event_size, bool)
                or not isinstance(max_incomplete_event_size, int)
                or max_incomplete_event_size < 1):
            raise ValueError("max_incomplete_event_size must be a positive int")

        self.our_role = role
        self.their_role = _other(role)
        self._states = {CLIENT: IDLE, SERVER: IDLE}
        self._max_incomplete = int(max_incomplete_event_size)
        self._buf = bytearray()
        self._receive_closed = False
        self._remote_hint = 400
        self.their_http_version = None
        self._reset_cycle()

    # ----------------------------------------------------------------- state

    def _reset_cycle(self):
        self._request_method = None
        self._cycle_peer_version = None
        self._proposals = frozenset()  # subset of {b"connect", b"upgrade"}
        self._proposal_answered = False
        self._no_keepalive = False
        self._client_waiting = False
        self._our_body = None
        self._their_body = None
        self._chunk_state = None
        self._chunk_remaining = 0
        self._chunk_open = False

    @property
    def our_state(self):
        return self._states[self.our_role]

    @property
    def their_state(self):
        return self._states[self.their_role]

    @property
    def states(self):
        return {CLIENT: self._states[CLIENT], SERVER: self._states[SERVER]}

    @property
    def client_is_waiting_for_100_continue(self):
        return bool(self._client_waiting)

    @property
    def they_are_waiting_for_100_continue(self):
        return bool(self._client_waiting) and self.our_role is SERVER

    @property
    def trailing_data(self):
        return (bytes(self._buf), self._receive_closed)

    def _normalize(self):
        s = self._states
        for role in (CLIENT, SERVER):
            other = _other(role)
            if s[role] is CLOSED and s[other] in (IDLE, DONE):
                s[other] = MUST_CLOSE
            if s[role] is ERROR and s[other] is DONE:
                s[other] = MUST_CLOSE
        if self._no_keepalive:
            for role in (CLIENT, SERVER):
                if s[role] is DONE:
                    s[role] = MUST_CLOSE

    def _local_error(self, message, hint=400):
        self._states[self.our_role] = ERROR
        self._normalize()
        raise LocalProtocolError(message, hint)

    def _remote_error(self, message, hint=400):
        self._remote_hint = hint
        self._states[self.their_role] = ERROR
        self._normalize()
        raise RemoteProtocolError(message, hint)

    def _end_side(self, role):
        if role is CLIENT and self._proposals and not self._proposal_answered:
            self._states[CLIENT] = MIGHT_SWITCH_PROTOCOL
        else:
            self._states[role] = DONE
        self._normalize()

    def _switch(self):
        self._states[CLIENT] = SWITCHED_PROTOCOL
        self._states[SERVER] = SWITCHED_PROTOCOL
        self._proposal_answered = True
        self._client_waiting = False

    def _deny(self):
        self._proposal_answered = True
        if self._states[CLIENT] is MIGHT_SWITCH_PROTOCOL:
            self._states[CLIENT] = DONE

    def _accepts(self, event):
        if self._proposal_answered or not self._proposals:
            return False
        if isinstance(event, InformationalResponse):
            return event.status_code == 101 and b"upgrade" in self._proposals
        return event.status_code == 200 and b"connect" in self._proposals

    def _begin_request(self, event):
        self._request_method = event.method
        props = set()
        if event.method == b"CONNECT":
            props.add(b"connect")
        if find_value(event.headers, b"upgrade") is not None:
            props.add(b"upgrade")
        self._proposals = frozenset(props)
        if event.http_version == b"1.1" and _has_expect_continue(event.headers):
            self._client_waiting = True
        if (event.http_version != b"1.1"
                or has_token(event.headers, b"connection", b"close")):
            self._no_keepalive = True

    def _set_their_body(self, framing):
        self._their_body = framing
        self._chunk_state = "size" if framing[0] == "chunked" else None

    # ----------------------------------------------------------------- send

    def send(self, event):
        """Encode one event into bytes for the integrator to write."""
        return b"".join(self._send(event, passthrough=False))

    def send_with_data_passthrough(self, event):
        """Like ``send`` but returns a list of pieces; payload objects pass through."""
        return list(self._send(event, passthrough=True))

    def send_failed(self):
        """Record that bytes from the last send never reached the peer."""
        self._states[self.our_role] = ERROR
        self._normalize()
        return None

    def _send(self, event, passthrough):
        if self._states[self.our_role] is ERROR:
            raise LocalProtocolError("connection is in the ERROR state; send refused", 400)
        if isinstance(event, Request):
            return self._send_request(event)
        if isinstance(event, InformationalResponse):
            return self._send_informational(event)
        if isinstance(event, Response):
            return self._send_final(event)
        if isinstance(event, Data):
            return self._send_data(event, passthrough)
        if isinstance(event, EndOfMessage):
            return self._send_end(event)
        if isinstance(event, ConnectionClosed):
            return self._send_closed()
        self._local_error("send() needs an HTTP event instance, not %r" % (event,))

    def _send_request(self, event):
        if self.our_role is not CLIENT:
            self._local_error("only the client role may send a request")
        if self._states[CLIENT] is not IDLE:
            self._local_error("a request can only be sent from IDLE; start the next cycle first")
        if event.http_version != b"1.1":
            self._local_error("only HTTP/1.1 requests can be sent")
        framing = _request_framing(event.headers)
        head = _serialize_request(event)
        self._states[CLIENT] = SEND_BODY
        if self._states[SERVER] is IDLE:
            self._states[SERVER] = SEND_RESPONSE
        self._begin_request(event)
        self._our_body = framing
        self._normalize()
        return [head]

    def _send_informational(self, event):
        if self.our_role is not SERVER:
            self._local_error("only the server role may send an informational response")
        if self._states[SERVER] is not SEND_RESPONSE:
            self._local_error("informational responses are only sent in SEND_RESPONSE")
        if event.http_version != b"1.1":
            self._local_error("only HTTP/1.1 responses can be sent")
        head = _serialize_status(event.status_code, event.reason, event.headers.raw_items())
        self._client_waiting = False
        if self._accepts(event):
            self._switch()
        self._normalize()
        return [head]

    def _send_final(self, event):
        if self.our_role is not SERVER:
            self._local_error("only the server role may send a response")
        if self._states[SERVER] is not SEND_RESPONSE and self._states[SERVER] is not IDLE:
            self._local_error("a final response is only sent in SEND_RESPONSE (or IDLE)")
        if event.http_version != b"1.1":
            self._local_error("only HTTP/1.1 responses can be sent")

        if self._accepts(event):
            items = event.headers.raw_items()
            head = _serialize_status(event.status_code, event.reason, items)
            self._switch()
            self._normalize()
            return [head]

        peer11 = self._cycle_peer_version == b"1.1"
        items, framing, close_delimited = _plan_final_headers(
            event, peer11, self._request_method)
        own_close = has_token(event.headers, b"connection", b"close")
        if not peer11 or own_close or close_delimited:
            self._no_keepalive = True
        if self._no_keepalive:
            items = _adjust_connection_header(items)
        head = _serialize_status(event.status_code, event.reason, items)

        self._states[SERVER] = SEND_BODY
        self._our_body = framing
        self._client_waiting = False
        if self._proposals:
            self._deny()
        self._normalize()
        return [head]

    def _send_data(self, event, passthrough):
        if self._states[self.our_role] is not SEND_BODY:
            self._local_error("data can only be sent in SEND_BODY")
        located = _payload_piece(event.data, passthrough)
        if located is None:
            self._local_error("data payload must be bytes-like")
        n, piece = located
        kind = self._our_body
        if kind[0] == "empty":
            if n:
                self._local_error("this response has no body; data refused")
            return []
        if kind[0] == "length":
            if n > kind[1]:
                self._local_error("data exceeds the declared Content-Length")
            self._our_body = ("length", kind[1] - n)
            pieces = [piece] if n else []
        elif kind[0] == "close":
            pieces = [piece] if n else []
        else:
            if n == 0:
                pieces = []
            else:
                pieces = [b"%x\r\n" % n, piece, b"\r\n"]
        self._client_waiting = False
        return pieces

    def _send_end(self, event):
        if self._states[self.our_role] is not SEND_BODY:
            self._local_error("end-of-message can only be sent in SEND_BODY")
        kind = self._our_body
        trailers = event.headers.raw_items()
        if kind[0] == "chunked":
            block = b"".join(_format_header(n, v) for n, v in trailers) + b"\r\n"
            pieces = [b"0\r\n" + block]
        else:
            if kind[0] == "length" and kind[1] != 0:
                self._local_error("end-of-message before the Content-Length was sent in full")
            if trailers:
                self._local_error("trailing headers need chunked framing")
            pieces = []
        self._our_body = None
        self._client_waiting = False
        self._end_side(self.our_role)
        return pieces

    def _send_closed(self):
        if self._states[self.our_role] not in (IDLE, DONE, MUST_CLOSE):
            self._local_error("connection-closed cannot be sent in the current state")
        self._states[self.our_role] = CLOSED
        self._normalize()
        return []

    # ----------------------------------------------------------- receive

    def receive_data(self, data):
        """Store bytes that arrived from the peer. An empty chunk means it closed."""
        try:
            chunk = bytes(memoryview(data))
        except TypeError:
            raise TypeError("receive_data needs a bytes-like object")
        if self._receive_closed:
            if chunk:
                raise ReceiveClosedError("bytes fed after the receive side was closed")
            return None
        if not chunk:
            self._receive_closed = True
            return None
        self._buf += chunk
        return None

    def next_event(self):
        """Parse and return one event, or NEED_DATA / PAUSED."""
        their = self._states[self.their_role]
        ours = self._states[self.our_role]
        if their is ERROR:
            raise RemoteProtocolError("the peer's side is in the ERROR state", self._remote_hint)
        if (ours is SWITCHED_PROTOCOL or their is SWITCHED_PROTOCOL
                or their is MIGHT_SWITCH_PROTOCOL):
            return PAUSED
        if their is CLOSED:
            return ConnectionClosed()
        if their is DONE or their is MUST_CLOSE:
            if self._buf:
                return PAUSED
            return self._no_more_input()
        if their is IDLE:
            if self.our_role is SERVER:
                return self._pull_request()
            if self._buf:
                self._remote_error("unexpected data from the server before any response")
            return self._no_more_input()
        if their is SEND_RESPONSE:
            return self._pull_response()
        if their is SEND_BODY:
            return self._pull_body()
        raise RuntimeError("unexpected peer state %r" % (their,))

    def _no_more_input(self):
        """Nothing is stored and the peer is in a state that may close."""
        if self._receive_closed:
            self._states[self.their_role] = CLOSED
            self._normalize()
            return ConnectionClosed()
        return NEED_DATA

    def _need_more(self, message, limited_hint=None):
        """Called when the current element is incomplete and no event is ready."""
        if limited_hint is not None and len(self._buf) > self._max_incomplete:
            self._remote_error("incomplete event exceeds the size limit", limited_hint)
        if self._receive_closed:
            self._remote_error(message)
        return NEED_DATA

    def _read_block(self):
        """Read lines up to the blank line. Returns (lines, consumed) or None."""
        buf = self._buf
        lines = []
        pos = 0
        while True:
            idx = buf.find(b"\n", pos)
            if idx < 0:
                return None
            line = bytes(buf[pos:idx])
            if line.endswith(b"\r"):
                line = line[:-1]
            pos = idx + 1
            if not line:
                return lines, pos
            lines.append(line)

    def _parse_fields(self, lines):
        fields = []
        for line in lines:
            if line[:1] in (b" ", b"\t"):
                # Obsolete line folding: join onto the previous field value.
                if not fields:
                    self._remote_error("continuation line with no header to continue")
                cont = line.strip(b" \t")
                if cont:
                    name, prev = fields[-1]
                    fields[-1] = (name, (prev + b" " + cont) if prev else cont)
                continue
            name, sep, value = line.partition(b":")
            if not sep or not TOKEN_RE.fullmatch(name):
                self._remote_error("malformed header line")
            fields.append((name, value.strip(b" \t")))
        return fields

    def _pull_request(self):
        if not self._buf:
            return self._no_more_input()
        if self._states[self.our_role] is not IDLE:
            self._remote_error("a request arrived while this side is not idle")
        if self._buf[0] <= 32:
            self._remote_error("request line must not begin with a space or control byte")
        block = self._read_block()
        if block is None:
            return self._need_more("connection closed in the middle of a request head", 431)
        lines, consumed = block

        match = _REQUEST_LINE_RE.fullmatch(lines[0])
        if match is None:
            self._remote_error("malformed request line")
        method, target, major, minor = match.groups()
        version = major + b"." + minor
        if version not in (b"1.0", b"1.1"):
            self._remote_error("unsupported HTTP version")
        fields = self._parse_fields(lines[1:])
        try:
            event = Request(method=method, target=target, headers=fields, http_version=version)
        except LocalProtocolError as exc:
            self._remote_error(str(exc), exc.error_status_hint)

        del self._buf[:consumed]
        self.their_http_version = version
        self._cycle_peer_version = version
        self._states[CLIENT] = SEND_BODY
        self._states[SERVER] = SEND_RESPONSE
        self._begin_request(event)
        self._set_their_body(_request_framing(event.headers))
        self._normalize()
        return event

    def _pull_response(self):
        if not self._buf:
            if self._receive_closed:
                self._remote_error("connection closed before a response was received")
            return NEED_DATA
        if self._buf[0] <= 32:
            self._remote_error("status line must not begin with a space or control byte")
        block = self._read_block()
        if block is None:
            return self._need_more("connection closed in the middle of a response head", 431)
        lines, consumed = block

        match = _STATUS_LINE_RE.fullmatch(lines[0])
        if match is None:
            self._remote_error("malformed status line")
        major, minor, code, reason = match.groups()
        version = major + b"." + minor
        if version not in (b"1.0", b"1.1"):
            self._remote_error("unsupported HTTP version")
        status = int(code.decode("ascii"))
        if status < 100:
            self._remote_error("status code below 100")
        fields = self._parse_fields(lines[1:])
        try:
            if status < 200:
                event = InformationalResponse(status, fields, version, reason or b"")
            else:
                event = Response(status, fields, version, reason or b"")
        except LocalProtocolError as exc:
            self._remote_error(str(exc), exc.error_status_hint)

        del self._buf[:consumed]
        self.their_http_version = version
        self._cycle_peer_version = version
        if isinstance(event, InformationalResponse):
            self._client_waiting = False
            if self._accepts(event):
                self._switch()
        else:
            self._pull_final_response(event)
        self._normalize()
        return event

    def _pull_final_response(self, event):
        self._client_waiting = False
        if self._accepts(event):
            self._switch()
            return
        framing = _response_framing_received(event, self._request_method)
        if (event.http_version != b"1.1"
                or has_token(event.headers, b"connection", b"close")
                or framing[0] == "close"):
            self._no_keepalive = True
        self._states[SERVER] = SEND_BODY
        self._set_their_body(framing)
        if self._proposals:
            self._deny()

    def _end_their_message(self, event):
        self._their_body = None
        self._chunk_state = None
        self._end_side(self.their_role)
        return event

    def _pull_body(self):
        kind = self._their_body
        buf = self._buf
        if kind[0] == "empty":
            return self._end_their_message(EndOfMessage())
        if kind[0] == "length":
            remaining = kind[1]
            if remaining == 0:
                return self._end_their_message(EndOfMessage())
            if not buf:
                return self._need_more("connection closed in the middle of a Content-Length body")
            n = min(remaining, len(buf))
            payload = bytes(buf[:n])
            del buf[:n]
            self._their_body = ("length", remaining - n)
            return Data(payload)
        if kind[0] == "close":
            if buf:
                payload = bytes(buf)
                del buf[:]
                return Data(payload)
            if self._receive_closed:
                return self._end_their_message(EndOfMessage())
            return NEED_DATA
        return self._pull_chunked()

    def _pull_chunked(self):
        buf = self._buf
        while True:
            state = self._chunk_state
            if state == "size":
                idx = buf.find(b"\n")
                if idx < 0:
                    return self._need_more("connection closed in the middle of a chunk-size line", 400)
                line = bytes(buf[:idx])
                if line.endswith(b"\r"):
                    line = line[:-1]
                match = _CHUNK_SIZE_RE.fullmatch(line)
                if match is None:
                    self._remote_error("malformed chunk-size line")
                del buf[:idx + 1]
                size = int(match.group(1), 16)
                if size == 0:
                    self._chunk_state = "trailer"
                    continue
                self._chunk_state = "data"
                self._chunk_remaining = size
                self._chunk_open = False
                continue

            if state == "data":
                if not buf:
                    return self._need_more("connection closed in the middle of a chunk")
                n = min(self._chunk_remaining, len(buf))
                payload = bytes(buf[:n])
                del buf[:n]
                start = not self._chunk_open
                self._chunk_open = True
                self._chunk_remaining -= n
                end = self._chunk_remaining == 0
                if end:
                    self._chunk_state = "crlf"
                return Data(payload, chunk_start=start, chunk_end=end)

            if state == "crlf":
                if len(buf) >= 2:
                    if buf[0] != 13 or buf[1] != 10:
                        self._remote_error("chunk data not followed by CRLF")
                    del buf[:2]
                    self._chunk_state = "size"
                    continue
                if len(buf) == 1 and buf[0] != 13:
                    self._remote_error("chunk data not followed by CRLF")
                return self._need_more("connection closed in the middle of a chunk")

            # state == "trailer": the zero-size chunk has been read.
            block = self._read_block()
            if block is None:
                return self._need_more("connection closed in the middle of the trailer", 431)
            lines, consumed = block
            fields = self._parse_fields(lines)
            try:
                event = EndOfMessage(headers=fields)
            except LocalProtocolError as exc:
                self._remote_error(str(exc), exc.error_status_hint)
            del buf[:consumed]
            return self._end_their_message(event)

    # ------------------------------------------------------------ cycles

    def start_next_cycle(self):
        """Reset both sides to IDLE for another request/response on this connection."""
        if self._states[CLIENT] is not DONE or self._states[SERVER] is not DONE:
            raise LocalProtocolError("the next cycle can start only when both sides are DONE", 400)
        self._states[CLIENT] = IDLE
        self._states[SERVER] = IDLE
        self._reset_cycle()
        return None
