"""The six HTTP event types."""

from ._errors import LocalProtocolError
from ._headers import (
    check_reason,
    check_status,
    normalize_headers,
    to_bytes,
    validate_method,
    validate_target,
    validate_version,
)


class _Event(object):
    __slots__ = ()
    _fields = ()

    def __repr__(self):
        parts = ", ".join("%s=%r" % (f, getattr(self, f)) for f in self._fields)
        return "%s(%s)" % (type(self).__name__, parts)


class Request(_Event):
    __slots__ = ("method", "target", "headers", "http_version")
    _fields = __slots__

    def __init__(self, method, target, headers, http_version=b"1.1"):
        self.method = validate_method(to_bytes(method, "method"))
        self.target = validate_target(to_bytes(target, "request target"))
        self.http_version = validate_version(to_bytes(http_version, "HTTP version"))
        self.headers = normalize_headers(headers)
        hosts = sum(1 for name, _ in self.headers if name == b"host")
        if hosts > 1:
            raise LocalProtocolError("a request may carry only one Host header")
        if self.http_version == b"1.1" and hosts != 1:
            raise LocalProtocolError("an HTTP/1.1 request needs exactly one Host header")


class InformationalResponse(_Event):
    __slots__ = ("status_code", "headers", "http_version", "reason")
    _fields = __slots__

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        self.status_code = check_status(status_code, 100, 199)
        self.headers = normalize_headers(headers)
        self.http_version = validate_version(to_bytes(http_version, "HTTP version"))
        self.reason = check_reason(to_bytes(reason, "reason phrase"))


class Response(_Event):
    __slots__ = ("status_code", "headers", "http_version", "reason")
    _fields = __slots__

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        self.status_code = check_status(status_code, 200, 999)
        self.headers = normalize_headers(headers)
        self.http_version = validate_version(to_bytes(http_version, "HTTP version"))
        self.reason = check_reason(to_bytes(reason, "reason phrase"))


class Data(_Event):
    __slots__ = ("data", "chunk_start", "chunk_end")
    _fields = __slots__

    def __init__(self, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)


class EndOfMessage(_Event):
    __slots__ = ("headers",)
    _fields = __slots__

    def __init__(self, headers=()):
        self.headers = normalize_headers(headers)


class ConnectionClosed(_Event):
    __slots__ = ()
    _fields = ()

    def __init__(self):
        pass
