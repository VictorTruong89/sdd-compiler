import unittest

from httpwire import (
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
    Connection,
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    LocalProtocolError,
    Request,
    Response,
    RemoteProtocolError,
)
from httpwire._errors import ReceiveClosedError


def pair():
    return Connection(CLIENT), Connection(SERVER)


def exchange(client, server, data):
    """Deliver bytes from client to server and return the events pulled."""
    server.receive_data(data)
    out = []
    while True:
        ev = server.next_event()
        if ev is NEED_DATA or ev is PAUSED:
            out.append(ev)
            break
        out.append(ev)
    return out


class EventTests(unittest.TestCase):
    def test_default_version_and_bytes(self):
        r = Request(method="GET", target="/", headers=[("Host", "x")])
        self.assertEqual(r.http_version, b"1.1")
        self.assertIsInstance(r.method, bytes)
        self.assertEqual(r.method, b"GET")

    def test_header_normalization(self):
        r = Request(method="GET", target="/", headers=[("Host", "x"), ("X-Ab", "1")])
        self.assertEqual(list(r.headers), [(b"host", b"x"), (b"x-ab", b"1")])
        self.assertEqual(r.headers.raw_items(), [(b"Host", b"x"), (b"X-Ab", b"1")])

    def test_host_required_for_11(self):
        with self.assertRaises(LocalProtocolError):
            Request(method="GET", target="/", headers=[])
        Request(method="GET", target="/", headers=[], http_version=b"1.0")

    def test_duplicate_host_refused(self):
        with self.assertRaises(LocalProtocolError):
            Request(method="GET", target="/", headers=[("host", "a"), ("Host", "b")], http_version=b"1.0")

    def test_repeated_equal_content_length_collapses(self):
        r = Request(method="POST", target="/", headers=[("Host", "x"), ("Content-Length", "5"), ("content-length", "5, 5")])
        self.assertEqual([h for h in r.headers if h[0] == b"content-length"], [(b"content-length", b"5")])

    def test_conflicting_content_length_refused(self):
        with self.assertRaises(LocalProtocolError):
            Request(method="POST", target="/", headers=[("Host", "x"), ("Content-Length", "5"), ("Content-Length", "6")])

    def test_bad_content_length(self):
        for bad in ["-1", "5x", "", "0x10", "1" * 19]:
            with self.assertRaises(LocalProtocolError):
                Request(method="POST", target="/", headers=[("Host", "x"), ("Content-Length", bad)])

    def test_transfer_encoding(self):
        r = Request(method="POST", target="/", headers=[("Host", "x"), ("Transfer-Encoding", "CHUNKED")])
        self.assertIn((b"transfer-encoding", b"chunked"), list(r.headers))
        with self.assertRaises(LocalProtocolError) as cm:
            Request(method="POST", target="/", headers=[("Host", "x"), ("Transfer-Encoding", "gzip")])
        self.assertEqual(cm.exception.error_status_hint, 501)
        with self.assertRaises(LocalProtocolError) as cm:
            Request(method="POST", target="/", headers=[("Host", "x"), ("Transfer-Encoding", "chunked"), ("Transfer-Encoding", "chunked")])
        self.assertEqual(cm.exception.error_status_hint, 501)

    def test_value_rules(self):
        with self.assertRaises(LocalProtocolError):
            Request(method="GET", target="/", headers=[("Host", "x"), ("X-A", " lead")])
        with self.assertRaises(LocalProtocolError):
            Request(method="GET", target="/", headers=[("Host", "x"), ("X-A", "a\x01b")])
        with self.assertRaises(LocalProtocolError):
            Request(method="GET", target="/", headers=[("Host", "x"), ("X-A", "a\rb")])
        Request(method="GET", target="/", headers=[("Host", "x"), ("X-A", b"a\tb\xff")])

    def test_bad_names_targets_methods(self):
        with self.assertRaises(LocalProtocolError):
            Request(method="GET", target="/", headers=[("Host", "x"), ("Bad Name", "v")])
        with self.assertRaises(LocalProtocolError):
            Request(method="GET", target="/a b", headers=[("Host", "x")])
        with self.assertRaises(LocalProtocolError):
            Request(method="G E", target="/", headers=[("Host", "x")])

    def test_status_ranges(self):
        InformationalResponse(100, [])
        with self.assertRaises(LocalProtocolError):
            InformationalResponse(200, [])
        Response(999, [])
        with self.assertRaises(LocalProtocolError):
            Response(1000, [])
        with self.assertRaises(LocalProtocolError):
            Response("200", [])

    def test_default_reason_is_empty(self):
        self.assertEqual(Response(200, []).reason, b"")

    def test_eom_and_closed(self):
        self.assertEqual(list(EndOfMessage().headers), [])
        ConnectionClosed()


class ErrorTests(unittest.TestCase):
    def test_errors_are_distinct(self):
        self.assertFalse(issubclass(LocalProtocolError, RemoteProtocolError))
        self.assertFalse(issubclass(RemoteProtocolError, LocalProtocolError))
        self.assertIsInstance(LocalProtocolError("x").error_status_hint, int)
        self.assertEqual(RemoteProtocolError("x", 431).error_status_hint, 431)

    def test_bad_role(self):
        with self.assertRaises(Exception):
            Connection("client")

    def test_receive_after_close(self):
        c = Connection(SERVER)
        c.receive_data(b"")
        with self.assertRaises(ReceiveClosedError):
            c.receive_data(b"x")


class BasicCycleTests(unittest.TestCase):
    def test_request_and_response_cycle(self):
        c, s = pair()
        self.assertIs(c.our_state, IDLE)
        self.assertIs(s.their_state, IDLE)
        wire = c.send(Request(method="POST", target="/p", headers=[("Host", "h"), ("Content-Length", "3")]))
        self.assertEqual(wire, b"POST /p HTTP/1.1\r\nHost: h\r\nContent-Length: 3\r\n\r\n")
        self.assertIs(c.our_state, SEND_BODY)
        self.assertIs(c.their_state, SEND_RESPONSE)
        self.assertEqual(c.send(Data(b"abc")), b"abc")
        self.assertEqual(c.send(EndOfMessage()), b"")
        self.assertIs(c.our_state, DONE)

        s.receive_data(wire + b"abc")
        req = s.next_event()
        self.assertIsInstance(req, Request)
        self.assertEqual(s.their_http_version, b"1.1")
        self.assertIsInstance(s.next_event(), Data)
        self.assertIsInstance(s.next_event(), EndOfMessage)
        self.assertIs(s.next_event(), NEED_DATA)
        self.assertIs(s.our_state, SEND_RESPONSE)
        self.assertIs(s.their_state, DONE)

        resp = s.send(Response(200, [("Content-Length", "2")], reason=b"OK"))
        self.assertEqual(resp, b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\n")
        s.send(Data(b"hi"))
        s.send(EndOfMessage())
        self.assertIs(s.our_state, DONE)

        c.receive_data(resp + b"hi")
        self.assertIsInstance(c.next_event(), Response)
        self.assertIsInstance(c.next_event(), Data)
        self.assertIsInstance(c.next_event(), EndOfMessage)
        self.assertIs(c.our_state, DONE)
        self.assertIs(c.their_state, DONE)

        c.start_next_cycle()
        s.start_next_cycle()
        self.assertIs(c.our_state, IDLE)
        self.assertIs(s.our_state, IDLE)

    def test_need_data_and_incremental_parse(self):
        s = Connection(SERVER)
        self.assertIs(s.next_event(), NEED_DATA)
        s.receive_data(b"GET / HTTP/1.1\r\nHo")
        self.assertIs(s.next_event(), NEED_DATA)
        s.receive_data(b"st: h\r\n\r\n")
        self.assertIsInstance(s.next_event(), Request)

    def test_lone_lf_accepted(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\nHost: h\r\n\n")
        ev = s.next_event()
        self.assertEqual(ev.headers, [(b"host", b"h")])

    def test_folding_accepted(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\nX-A: one\r\n\t two\r\n\r\n")
        ev = s.next_event()
        self.assertEqual(list(ev.headers)[-1], (b"x-a", b"one two"))

    def test_leading_continuation_refused(self):
        s = Connection(SERVER)
        s.receive_data(b" GET / HTTP/1.1\r\n\r\n")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    def test_status_line_without_reason(self):
        c = Connection(CLIENT)
        c.send(Request(method="GET", target="/", headers=[("Host", "h")]))
        c.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 204\r\n\r\n")
        ev = c.next_event()
        self.assertIsInstance(ev, Response)
        self.assertEqual(ev.reason, b"")

    def test_early_bad_first_byte(self):
        s = Connection(SERVER)
        s.receive_data(b" ")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()
        self.assertIs(s.their_state, ERROR)
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    def test_remote_error_allows_error_response(self):
        s = Connection(SERVER)
        s.receive_data(b"BAD\r\n\r\n")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()
        resp = s.send(Response(400, [("Content-Length", "0")]))
        self.assertIn(b"Connection: close", resp)
        self.assertIs(s.our_state, SEND_BODY)

    def test_unknown_header_size_limit(self):
        s = Connection(SERVER, 100)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\nX-Big: " + b"a" * 200)
        with self.assertRaises(RemoteProtocolError) as cm:
            s.next_event()
        self.assertEqual(cm.exception.error_status_hint, 431)

    def test_default_limit_is_8k(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\nX-Big: " + b"a" * (9 * 1024))
        with self.assertRaises(RemoteProtocolError):
            s.next_event()


class FramingTests(unittest.TestCase):
    def test_chunked_request_round_trip(self):
        c, s = pair()
        wire = c.send(Request(method="POST", target="/", headers=[("Host", "h"), ("Transfer-Encoding", "chunked")]))
        wire += c.send(Data(b"hello"))
        wire += c.send(Data(b""))
        wire += c.send(EndOfMessage(headers=[("X-T", "1")]))
        self.assertTrue(wire.endswith(b"5\r\nhello\r\n0\r\nX-T: 1\r\n\r\n"))
        s.receive_data(wire)
        self.assertIsInstance(s.next_event(), Request)
        d = s.next_event()
        self.assertIsInstance(d, Data)
        self.assertEqual(d.data, b"hello")
        self.assertTrue(d.chunk_start and d.chunk_end)
        e = s.next_event()
        self.assertIsInstance(e, EndOfMessage)
        self.assertEqual(list(e.headers), [(b"x-t", b"1")])

    def test_chunk_in_pieces_marks(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n")
        s.next_event()
        s.receive_data(b"A;ext=1\r\n01234")
        d1 = s.next_event()
        self.assertEqual((d1.data, d1.chunk_start, d1.chunk_end), (b"01234", True, False))
        s.receive_data(b"56789\r\n")
        d2 = s.next_event()
        self.assertEqual((d2.data, d2.chunk_start, d2.chunk_end), (b"56789", False, True))
        self.assertIs(s.next_event(), NEED_DATA)
        s.receive_data(b"0\r\n\r\n")
        self.assertIsInstance(s.next_event(), EndOfMessage)

    def test_bad_chunk_size_refused(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n")
        s.next_event()
        s.receive_data(b"5 \r\nhello\r\n")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    def test_chunk_not_followed_by_crlf(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n2\r\nabXX")
        s.next_event()
        s.next_event()
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    def test_content_length_exact(self):
        c, s = pair()
        c.send(Request(method="POST", target="/", headers=[("Host", "h"), ("Content-Length", "2")]))
        with self.assertRaises(LocalProtocolError):
            c.send(Data(b"abc"))
        self.assertIs(c.our_state, ERROR)
        self.assertIs(c.send.__self__.our_state, ERROR)

    def test_eom_before_content_length_refused(self):
        c, _ = pair()
        c.send(Request(method="POST", target="/", headers=[("Host", "h"), ("Content-Length", "2")]))
        with self.assertRaises(LocalProtocolError):
            c.send(EndOfMessage())

    def test_passthrough_keeps_object(self):
        class Blob(object):
            def __init__(self, n):
                self.n = n

            def __len__(self):
                return self.n

        c, _ = pair()
        c.send(Request(method="POST", target="/", headers=[("Host", "h"), ("Transfer-Encoding", "chunked")]))
        blob = Blob(7)
        pieces = c.send_with_data_passthrough(Data(blob))
        self.assertIs(pieces[1], blob)
        self.assertEqual(pieces[0], b"7\r\n")
        self.assertEqual(pieces[2], b"\r\n")

    def test_head_response_no_body(self):
        c, s = pair()
        c.send(Request(method="HEAD", target="/", headers=[("Host", "h")]))
        c.send(EndOfMessage())
        s.receive_data(b"HEAD / HTTP/1.1\r\nHost: h\r\n\r\n")
        s.next_event()
        s.next_event()
        resp = s.send(Response(200, [("Content-Length", "10")]))
        self.assertIn(b"Content-Length: 10", resp)
        self.assertEqual(s.send(EndOfMessage()), b"")
        self.assertIs(s.our_state, DONE)

    def test_close_delimited_response(self):
        c = Connection(CLIENT)
        c.send(Request(method="GET", target="/", headers=[("Host", "h")]))
        c.send(EndOfMessage())
        c.receive_data(b"HTTP/1.0 200 OK\r\n\r\nbody")
        self.assertIsInstance(c.next_event(), Response)
        d = c.next_event()
        self.assertEqual(d.data, b"body")
        self.assertIs(c.next_event(), NEED_DATA)
        c.receive_data(b"")
        self.assertIsInstance(c.next_event(), EndOfMessage)
        self.assertIsInstance(c.next_event(), ConnectionClosed)
        self.assertIs(c.their_state, CLOSED)

    def test_response_chunked_for_http11_peer(self):
        c, s = pair()
        c.send(Request(method="GET", target="/", headers=[("Host", "h")]))
        c.send(EndOfMessage())
        s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
        s.next_event()
        wire = s.send(Response(200, []))
        self.assertIn(b"Transfer-Encoding: chunked", wire)
        wire += s.send(Data(b"xy")) + s.send(EndOfMessage())
        self.assertTrue(wire.endswith(b"2\r\nxy\r\n0\r\n\r\n"))

    def test_response_for_http10_peer_closes(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.0\r\nHost: h\r\n\r\n")
        s.next_event()
        wire = s.send(Response(200, []))
        self.assertNotIn(b"Transfer-Encoding", wire)
        self.assertIn(b"Connection: close", wire)
        s.send(Data(b"raw"))
        s.send(EndOfMessage())
        self.assertIs(s.our_state, MUST_CLOSE)

    def test_no_request_response_is_close_delimited(self):
        s = Connection(SERVER)
        wire = s.send(Response(408, [], reason=b"Request Timeout"))
        self.assertIn(b"Connection: close", wire)
        self.assertIs(s.our_state, SEND_BODY)

    def test_zero_content_length_kept(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
        s.next_event()
        wire = s.send(Response(200, [("Content-Length", "0")]))
        self.assertIn(b"Content-Length: 0", wire)


class KeepAliveTests(unittest.TestCase):
    def test_connection_close_prevents_reuse(self):
        c, s = pair()
        c.send(Request(method="GET", target="/", headers=[("Host", "h"), ("Connection", "close")]))
        c.send(EndOfMessage())
        self.assertIs(c.our_state, MUST_CLOSE)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\nConnection: Close\r\n\r\n")
        s.next_event()
        s.next_event()
        wire = s.send(Response(200, [("Content-Length", "0")]))
        self.assertIn(b"Connection: close", wire)
        s.send(EndOfMessage())
        self.assertIs(s.our_state, MUST_CLOSE)
        with self.assertRaises(LocalProtocolError):
            c.start_next_cycle()
        self.assertIs(c.our_state, MUST_CLOSE)

    def test_pipelining_paused_then_served(self):
        c, s = pair()
        s.receive_data(b"GET /a HTTP/1.1\r\nHost: h\r\n\r\nGET /b HTTP/1.1\r\nHost: h\r\n\r\n")
        self.assertIsInstance(s.next_event(), Request)
        self.assertIsInstance(s.next_event(), EndOfMessage)  # no body for request A
        self.assertIs(s.next_event(), PAUSED)  # request B is stored and paused
        s.send(Response(200, [("Content-Length", "0")]))
        s.send(EndOfMessage())
        self.assertIs(s.next_event(), PAUSED)  # still paused until the next cycle
        s.start_next_cycle()
        self.assertIsInstance(s.next_event(), Request)

    def test_client_cannot_pipeline(self):
        c, _ = pair()
        c.send(Request(method="GET", target="/", headers=[("Host", "h")]))
        c.send(EndOfMessage())
        with self.assertRaises(LocalProtocolError):
            c.send(Request(method="GET", target="/", headers=[("Host", "h")]))
        self.assertIs(c.our_state, ERROR)

    def test_start_next_cycle_refused_changes_nothing(self):
        c, _ = pair()
        c.send(Request(method="GET", target="/", headers=[("Host", "h")]))
        with self.assertRaises(LocalProtocolError):
            c.start_next_cycle()
        self.assertIs(c.our_state, SEND_BODY)


class ExpectAndSwitchTests(unittest.TestCase):
    def test_expect_100_continue(self):
        c, s = pair()
        c.send(Request(method="POST", target="/", headers=[("Host", "h"), ("Content-Length", "1"), ("Expect", "100-continue")]))
        self.assertTrue(c.client_is_waiting_for_100_continue)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nContent-Length: 1\r\nExpect: 100-continue\r\n\r\n")
        s.next_event()
        self.assertTrue(s.they_are_waiting_for_100_continue)
        wire = s.send(InformationalResponse(100, []))
        self.assertEqual(wire, b"HTTP/1.1 100 \r\n\r\n")
        self.assertFalse(s.they_are_waiting_for_100_continue)
        c.receive_data(wire)
        self.assertIsInstance(c.next_event(), InformationalResponse)
        self.assertIs(c.their_state, SEND_RESPONSE)

    def test_connect_accepted(self):
        c, s = pair()
        c.send(Request(method="CONNECT", target="example:443", headers=[("Host", "example:443")]))
        c.send(EndOfMessage())
        self.assertIs(c.our_state, MIGHT_SWITCH_PROTOCOL)
        with self.assertRaises(LocalProtocolError):
            c.send(Request(method="GET", target="/", headers=[("Host", "h")]))
        s.receive_data(b"CONNECT example:443 HTTP/1.1\r\nHost: example:443\r\n\r\nTUNNEL")
        s.next_event()
        s.next_event()  # EOM of the proposing request
        self.assertIs(s.next_event(), PAUSED)
        s.send(Response(200, []))
        self.assertIs(s.our_state, SWITCHED_PROTOCOL)
        self.assertIs(s.next_event(), PAUSED)
        self.assertEqual(s.trailing_data[0], b"TUNNEL")
        c.receive_data(b"HTTP/1.1 200 OK\r\n\r\nafter")
        self.assertIsInstance(c.next_event(), Response)
        self.assertIs(c.our_state, SWITCHED_PROTOCOL)
        self.assertIs(c.next_event(), PAUSED)
        self.assertEqual(c.trailing_data[0], b"after")

    def test_connect_denied_then_next_request(self):
        c, s = pair()
        c.send(Request(method="CONNECT", target="x:1", headers=[("Host", "x:1")]))
        c.send(EndOfMessage())
        s.receive_data(b"CONNECT x:1 HTTP/1.1\r\nHost: x:1\r\n\r\n")
        s.next_event()
        s.next_event()
        s.send(Response(403, [("Content-Length", "0")]))
        s.send(EndOfMessage())
        self.assertIs(s.their_state, DONE)
        c.receive_data(b"HTTP/1.1 403 No\r\nContent-Length: 0\r\n\r\n")
        c.next_event()
        c.next_event()
        self.assertIs(c.our_state, DONE)
        c.start_next_cycle()
        self.assertIs(c.our_state, IDLE)

    def test_upgrade_accepted_with_101(self):
        c, s = pair()
        c.send(Request(method="GET", target="/ws", headers=[("Host", "h"), ("Upgrade", "websocket"), ("Connection", "Upgrade")]))
        c.send(EndOfMessage())
        self.assertIs(c.our_state, MIGHT_SWITCH_PROTOCOL)
        s.receive_data(b"GET /ws HTTP/1.1\r\nHost: h\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n\r\n")
        s.next_event()
        s.next_event()
        wire = s.send(InformationalResponse(101, [("Upgrade", "websocket"), ("Connection", "Upgrade")], reason=b"Switching Protocols"))
        self.assertIs(s.our_state, SWITCHED_PROTOCOL)
        c.receive_data(wire)
        self.assertIsInstance(c.next_event(), InformationalResponse)
        self.assertIs(c.our_state, SWITCHED_PROTOCOL)
        self.assertIs(c.their_state, SWITCHED_PROTOCOL)

    def test_close_while_paused_for_switch_is_not_pulled_after_accept(self):
        c, s = pair()
        c.send(Request(method="CONNECT", target="x:1", headers=[("Host", "x:1")]))
        c.send(EndOfMessage())
        s.receive_data(b"CONNECT x:1 HTTP/1.1\r\nHost: x:1\r\n\r\n")
        s.next_event()
        s.next_event()
        s.send(Response(200, []))
        s.receive_data(b"")
        self.assertIs(s.next_event(), PAUSED)
        self.assertEqual(s.trailing_data, (b"", True))


class CloseTests(unittest.TestCase):
    def test_close_then_peer_must_close(self):
        c, s = pair()
        self.assertIsInstance(c.send(ConnectionClosed()), bytes)
        self.assertIs(c.our_state, CLOSED)
        self.assertIs(c.their_state, MUST_CLOSE)  # IDLE peer must close after our close
        self.assertIs(s.our_state, IDLE)

    def test_receive_empty_yields_closed_when_idle(self):
        s = Connection(SERVER)
        s.receive_data(b"")
        self.assertIsInstance(s.next_event(), ConnectionClosed)
        self.assertIsInstance(s.next_event(), ConnectionClosed)

    def test_close_mid_request_is_remote_error(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nHo")
        s.receive_data(b"")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    def test_close_mid_body_is_remote_error(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nContent-Length: 5\r\n\r\nab")
        s.next_event()
        s.next_event()
        s.receive_data(b"")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    def test_send_close_in_send_body_refused(self):
        c, _ = pair()
        c.send(Request(method="GET", target="/", headers=[("Host", "h")]))
        with self.assertRaises(LocalProtocolError):
            c.send(ConnectionClosed())


class ErrorStateTests(unittest.TestCase):
    def test_send_failed(self):
        c, s = pair()
        c.send(Request(method="GET", target="/", headers=[("Host", "h")]))
        c.send(EndOfMessage())
        self.assertIsNone(c.send_failed())
        self.assertIs(c.our_state, ERROR)
        with self.assertRaises(LocalProtocolError):
            c.send(EndOfMessage())

    def test_local_error_moves_done_peer_to_must_close(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
        s.next_event()
        s.next_event()  # EOM -> their DONE
        self.assertIs(s.their_state, DONE)
        s.send_failed()
        self.assertIs(s.their_state, MUST_CLOSE)

    def test_invalid_version_send_refused(self):
        c = Connection(CLIENT)
        with self.assertRaises(LocalProtocolError):
            c.send(Request(method="GET", target="/", headers=[("Host", "h")], http_version=b"2.0"))
        self.assertIs(c.our_state, ERROR)


if __name__ == "__main__":
    unittest.main()
