"""Behavioural tests for httpwire. Run with: python -m unittest discover -s tests -t ."""

import os
import sys
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import httpwire as hw  # noqa: E402
from httpwire import (  # noqa: E402
    CLIENT, SERVER, NEED_DATA, PAUSED, IDLE, SEND_RESPONSE, SEND_BODY, DONE,
    MUST_CLOSE, CLOSED, MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL, ERROR,
    Connection, ConnectionClosed, Data, EndOfMessage, InformationalResponse,
    LocalProtocolError, RemoteProtocolError, Request, Response,
)


def pump(sender, receiver, wire):
    """Feed wire bytes to receiver and return all events it can pull."""
    receiver.receive_data(wire)
    out = []
    while True:
        ev = receiver.next_event()
        if ev is NEED_DATA or ev is PAUSED:
            out.append(ev)
            break
        out.append(ev)
    return out


class EventTests(unittest.TestCase):
    def test_request_defaults_and_bytes(self):
        r = Request(method="GET", target="/", headers=[("Host", "x"), ("X-A", "b")])
        self.assertEqual(r.method, b"GET")
        self.assertEqual(r.http_version, b"1.1")
        self.assertEqual(list(r.headers), [(b"host", b"x"), (b"x-a", b"b")])
        self.assertEqual(r.headers.raw_items(), [(b"Host", b"x"), (b"X-A", b"b")])

    def test_http11_requires_single_host(self):
        with self.assertRaises(LocalProtocolError):
            Request(method="GET", target="/", headers=[])
        with self.assertRaises(LocalProtocolError):
            Request(method="GET", target="/", headers=[("host", "a"), ("Host", "b")])
        Request(method="GET", target="/", headers=[], http_version=b"1.0")

    def test_transfer_encoding_rules(self):
        r = Request("POST", "/", [("Host", "h"), ("Transfer-Encoding", "CHUNKED")])
        self.assertEqual(list(r.headers)[-1], (b"transfer-encoding", b"chunked"))
        with self.assertRaises(LocalProtocolError) as cm:
            Request("POST", "/", [("Host", "h"), ("Transfer-Encoding", "gzip")])
        self.assertEqual(cm.exception.error_status_hint, 501)
        with self.assertRaises(LocalProtocolError):
            Request("POST", "/", [("Host", "h"), ("Transfer-Encoding", "chunked"),
                                  ("Transfer-Encoding", "chunked")])

    def test_content_length_collapse_and_conflict(self):
        r = Response(200, [("Content-Length", "5, 5"), ("content-length", "5")])
        self.assertEqual(list(r.headers), [(b"content-length", b"5")])
        with self.assertRaises(LocalProtocolError):
            Response(200, [("Content-Length", "5"), ("Content-Length", "6")])
        with self.assertRaises(LocalProtocolError):
            Response(200, [("Content-Length", "x")])

    def test_value_rules(self):
        with self.assertRaises(LocalProtocolError):
            Response(200, [("X", " lead")])
        with self.assertRaises(LocalProtocolError):
            Response(200, [("X", "a\x01b")])
        Response(200, [("X", "tab\there")])

    def test_status_range(self):
        with self.assertRaises(LocalProtocolError):
            InformationalResponse(200)
        with self.assertRaises(LocalProtocolError):
            Response(99)
        with self.assertRaises(LocalProtocolError):
            Response("200")
        self.assertEqual(Response(200).reason, b"")

    def test_construction_error_is_not_connection_error(self):
        self.assertFalse(issubclass(LocalProtocolError, RemoteProtocolError))
        self.assertFalse(issubclass(RemoteProtocolError, LocalProtocolError))


class RoundTripTests(unittest.TestCase):
    def test_simple_get_and_response(self):
        cli = Connection(CLIENT)
        srv = Connection(SERVER)
        wire = cli.send(Request("GET", "/a", [("Host", "example")]))
        self.assertEqual(wire, b"GET /a HTTP/1.1\r\nHost: example\r\n\r\n")
        self.assertEqual(cli.send(EndOfMessage()), b"")
        evs = pump(cli, srv, wire)
        self.assertIsInstance(evs[0], Request)
        self.assertEqual(evs[0].target, b"/a")
        self.assertIsInstance(evs[1], EndOfMessage)
        self.assertEqual(srv.their_http_version, b"1.1")
        self.assertIs(srv.our_state, SEND_RESPONSE)

        wire = srv.send(Response(200, [("Content-Length", "2")], reason=b"OK"))
        self.assertEqual(wire, b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\n")
        wire += srv.send(Data(b"hi"))
        self.assertEqual(wire[-2:], b"hi")
        self.assertEqual(srv.send(EndOfMessage()), b"")
        self.assertIs(srv.our_state, DONE)
        evs = pump(srv, cli, wire)
        self.assertIsInstance(evs[0], Response)
        self.assertEqual(evs[0].status_code, 200)
        self.assertEqual(evs[1].data, b"hi")
        self.assertIsInstance(evs[2], EndOfMessage)
        self.assertIs(cli.our_state, DONE)
        self.assertIs(cli.their_state, DONE)

        cli.start_next_cycle()
        srv.start_next_cycle()
        self.assertIs(cli.our_state, IDLE)

    def test_host_written_first_and_raw_case(self):
        cli = Connection(CLIENT)
        wire = cli.send(Request("GET", "/", [("X-One", "1"), ("Host", "h")]))
        self.assertEqual(wire, b"GET / HTTP/1.1\r\nHost: h\r\nX-One: 1\r\n\r\n")

    def test_chunked_request_round_trip(self):
        cli = Connection(CLIENT)
        srv = Connection(SERVER)
        head = cli.send(Request("POST", "/", [("Host", "h"), ("Transfer-Encoding", "chunked")]))
        body = cli.send(Data(b"hello")) + cli.send(Data(b"")) + cli.send(
            EndOfMessage(headers=[("X-T", "v")]))
        self.assertEqual(body, b"5\r\nhello\r\n0\r\nX-T: v\r\n\r\n")
        evs = pump(cli, srv, head + body)
        self.assertIsInstance(evs[0], Request)
        self.assertIsInstance(evs[1], Data)
        self.assertEqual(evs[1].data, b"hello")
        self.assertTrue(evs[1].chunk_start and evs[1].chunk_end)
        self.assertIsInstance(evs[2], EndOfMessage)
        self.assertEqual(list(evs[2].headers), [(b"x-t", b"v")])

    def test_chunk_split_across_feeds(self):
        srv = Connection(SERVER)
        srv.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n4\r\nab")
        self.assertIsInstance(srv.next_event(), Request)
        d1 = srv.next_event()
        self.assertEqual((d1.data, d1.chunk_start, d1.chunk_end), (b"ab", True, False))
        self.assertIs(srv.next_event(), NEED_DATA)
        srv.receive_data(b"cd\r\n0\r\n\r\n")
        d2 = srv.next_event()
        self.assertEqual((d2.data, d2.chunk_start, d2.chunk_end), (b"cd", False, True))
        self.assertIsInstance(srv.next_event(), EndOfMessage)

    def test_passthrough_keeps_object(self):
        class Blob(object):
            def __init__(self, n):
                self.n = n

            def __len__(self):
                return self.n
        cli = Connection(CLIENT)
        cli.send(Request("PUT", "/", [("Host", "h"), ("Content-Length", "3")]))
        blob = Blob(3)
        pieces = cli.send_with_data_passthrough(Data(blob))
        self.assertIs(pieces[0], blob)
        self.assertEqual(cli.send(EndOfMessage()), b"")

    def test_passthrough_chunked_pieces(self):
        cli = Connection(CLIENT)
        cli.send(Request("PUT", "/", [("Host", "h"), ("Transfer-Encoding", "chunked")]))
        pieces = cli.send_with_data_passthrough(Data(b"abc"))
        self.assertEqual(b"".join(pieces), b"3\r\nabc\r\n")

    def test_content_length_overflow_refused(self):
        cli = Connection(CLIENT)
        cli.send(Request("PUT", "/", [("Host", "h"), ("Content-Length", "2")]))
        with self.assertRaises(LocalProtocolError):
            cli.send(Data(b"abc"))
        # the failed send makes our side ERROR
        self.assertIs(cli.our_state, ERROR)
        with self.assertRaises(LocalProtocolError):
            cli.send(EndOfMessage())


class StateTests(unittest.TestCase):
    def test_client_cannot_send_second_request(self):
        cli = Connection(CLIENT)
        cli.send(Request("GET", "/", [("Host", "h")]))
        cli.send(EndOfMessage())
        with self.assertRaises(LocalProtocolError):
            cli.send(Request("GET", "/", [("Host", "h")]))
        self.assertIs(cli.our_state, ERROR)

    def test_start_next_cycle_refused_before_done_is_recoverable(self):
        cli = Connection(CLIENT)
        cli.send(Request("GET", "/", [("Host", "h")]))
        with self.assertRaises(LocalProtocolError):
            cli.start_next_cycle()
        self.assertIs(cli.our_state, SEND_BODY)

    def test_server_pipelined_request_is_paused(self):
        srv = Connection(SERVER)
        srv.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\nGET /2 HTTP/1.1\r\nHost: h\r\n\r\n")
        self.assertIsInstance(srv.next_event(), Request)
        self.assertIsInstance(srv.next_event(), EndOfMessage)
        self.assertIs(srv.their_state, DONE)
        self.assertIs(srv.next_event(), PAUSED)
        srv.send(Response(200, [("Content-Length", "0")]))
        srv.send(EndOfMessage())
        self.assertIs(srv.our_state, DONE)
        self.assertIs(srv.next_event(), PAUSED)  # pipelined bytes still held
        srv.start_next_cycle()
        ev = srv.next_event()
        self.assertIsInstance(ev, Request)
        self.assertEqual(ev.target, b"/2")

    def test_http10_disables_keepalive(self):
        srv = Connection(SERVER)
        srv.receive_data(b"GET / HTTP/1.0\r\n\r\n")
        srv.next_event()
        srv.next_event()
        # keep-alive is off, so the side that would be DONE is MUST_CLOSE
        self.assertIs(srv.their_state, MUST_CLOSE)
        wire = srv.send(Response(200, [("Content-Length", "0")]))
        self.assertIn(b"Connection: close", wire)
        srv.send(EndOfMessage())
        self.assertIs(srv.our_state, MUST_CLOSE)
        with self.assertRaises(LocalProtocolError):
            srv.start_next_cycle()

    def test_connection_close_request_forces_must_close(self):
        cli = Connection(CLIENT)
        cli.send(Request("GET", "/", [("Host", "h"), ("Connection", "Close")]))
        cli.send(EndOfMessage())
        self.assertIs(cli.our_state, MUST_CLOSE)

    def test_close_delimited_response(self):
        cli = Connection(CLIENT)
        cli.send(Request("GET", "/", [("Host", "h")]))
        cli.send(EndOfMessage())
        cli.receive_data(b"HTTP/1.0 200 OK\r\n\r\nbody bytes")
        self.assertIsInstance(cli.next_event(), Response)
        d = cli.next_event()
        self.assertIsInstance(d, Data)
        self.assertEqual(d.data, b"body bytes")
        self.assertIs(cli.next_event(), NEED_DATA)
        cli.receive_data(b"")
        self.assertIsInstance(cli.next_event(), EndOfMessage)
        self.assertIsInstance(cli.next_event(), ConnectionClosed)
        self.assertIs(cli.their_state, CLOSED)
        self.assertIs(cli.our_state, MUST_CLOSE)

    def test_head_response_has_no_body(self):
        cli = Connection(CLIENT)
        cli.send(Request("HEAD", "/", [("Host", "h")]))
        cli.send(EndOfMessage())
        cli.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 500\r\n\r\n")
        self.assertIsInstance(cli.next_event(), Response)
        self.assertIsInstance(cli.next_event(), EndOfMessage)
        self.assertIs(cli.our_state, DONE)

    def test_server_response_chunked_for_http11_peer(self):
        srv = Connection(SERVER)
        srv.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
        srv.next_event()
        srv.next_event()
        wire = srv.send(Response(200, reason=b"OK"))
        self.assertEqual(wire, b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n")
        self.assertEqual(srv.send(Data(b"x")), b"1\r\nx\r\n")
        self.assertEqual(srv.send(EndOfMessage()), b"0\r\n\r\n")

    def test_server_response_close_delimited_for_http10_peer(self):
        srv = Connection(SERVER)
        srv.receive_data(b"GET / HTTP/1.0\r\n\r\n")
        srv.next_event()
        srv.next_event()
        wire = srv.send(Response(200, reason=b"OK"))
        self.assertNotIn(b"Transfer-Encoding", wire)
        self.assertNotIn(b"Content-Length", wire)
        self.assertIn(b"Connection: close", wire)
        self.assertEqual(srv.send(Data(b"raw")), b"raw")


class ProtocolErrorTests(unittest.TestCase):
    def test_remote_error_sets_their_error_and_server_can_answer(self):
        srv = Connection(SERVER)
        srv.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\nbad header\r\n\r\n")
        with self.assertRaises(RemoteProtocolError):
            srv.next_event()
        self.assertIs(srv.their_state, ERROR)
        with self.assertRaises(RemoteProtocolError):
            srv.next_event()
        wire = srv.send(Response(400, [("Content-Length", "0")]))
        self.assertIn(b"Connection: close", wire)
        self.assertIs(srv.our_state, SEND_BODY)

    def test_leading_space_fails_immediately(self):
        srv = Connection(SERVER)
        srv.receive_data(b" GET")
        with self.assertRaises(RemoteProtocolError):
            srv.next_event()

    def test_size_limit_gives_431(self):
        srv = Connection(SERVER, 100)
        srv.receive_data(b"GET / HTTP/1.1\r\nX: " + b"a" * 200)
        with self.assertRaises(RemoteProtocolError) as cm:
            srv.next_event()
        self.assertEqual(cm.exception.error_status_hint, 431)

    def test_receive_after_close_raises_runtime_error(self):
        srv = Connection(SERVER)
        srv.receive_data(b"")
        with self.assertRaises(RuntimeError) as cm:
            srv.receive_data(b"x")
        self.assertNotIsInstance(cm.exception, (LocalProtocolError, RemoteProtocolError))

    def test_close_mid_message_is_remote_error(self):
        srv = Connection(SERVER)
        srv.receive_data(b"GET / HTT")
        srv.receive_data(b"")
        with self.assertRaises(RemoteProtocolError):
            srv.next_event()

    def test_send_failed_marks_error(self):
        cli = Connection(CLIENT)
        cli.send(Request("PUT", "/", [("Host", "h"), ("Content-Length", "1")]))
        cli.send_failed()
        self.assertIs(cli.our_state, ERROR)
        with self.assertRaises(LocalProtocolError):
            cli.send(EndOfMessage())

    def test_bad_role(self):
        with self.assertRaises(Exception):
            Connection("client")


class SwitchAndExpectTests(unittest.TestCase):
    def test_expect_100_continue_flags(self):
        cli = Connection(CLIENT)
        srv = Connection(SERVER)
        wire = cli.send(Request("PUT", "/", [("Host", "h"), ("Content-Length", "1"),
                                             ("Expect", "100-Continue")]))
        self.assertTrue(cli.client_is_waiting_for_100_continue)
        self.assertFalse(cli.they_are_waiting_for_100_continue)
        pump(cli, srv, wire)
        self.assertTrue(srv.they_are_waiting_for_100_continue)
        info = srv.send(InformationalResponse(100))
        self.assertEqual(info, b"HTTP/1.1 100 \r\n\r\n")
        pump(srv, cli, info)
        self.assertFalse(cli.client_is_waiting_for_100_continue)
        self.assertFalse(srv.client_is_waiting_for_100_continue)

    def test_connect_accept(self):
        cli = Connection(CLIENT)
        srv = Connection(SERVER)
        wire = cli.send(Request("CONNECT", "example:443", [("Host", "example:443")]))
        cli.send(EndOfMessage())
        self.assertIs(cli.our_state, MIGHT_SWITCH_PROTOCOL)
        evs = pump(cli, srv, wire)
        self.assertIsInstance(evs[0], Request)
        self.assertIs(srv.their_state, MIGHT_SWITCH_PROTOCOL)
        self.assertIs(srv.next_event(), PAUSED)
        resp = srv.send(Response(200))
        self.assertEqual(resp, b"HTTP/1.1 200 \r\n\r\n")
        self.assertIs(srv.our_state, SWITCHED_PROTOCOL)
        pump(srv, cli, resp)
        self.assertIs(cli.our_state, SWITCHED_PROTOCOL)
        srv.receive_data(b"raw tunnel bytes")
        self.assertIs(srv.next_event(), PAUSED)
        self.assertEqual(srv.trailing_data, (b"raw tunnel bytes", False))
        with self.assertRaises(LocalProtocolError):
            srv.send(Data(b"x"))

    def test_upgrade_101_accept(self):
        cli = Connection(CLIENT)
        srv = Connection(SERVER)
        wire = cli.send(Request("GET", "/ws", [("Host", "h"), ("Upgrade", "websocket"),
                                               ("Connection", "Upgrade")]))
        cli.send(EndOfMessage())
        pump(cli, srv, wire)
        out = srv.send(InformationalResponse(101, [("Upgrade", "websocket")]))
        self.assertTrue(out.startswith(b"HTTP/1.1 101 "))
        self.assertIs(srv.our_state, SWITCHED_PROTOCOL)
        pump(srv, cli, out)
        self.assertIs(cli.their_state, SWITCHED_PROTOCOL)
        self.assertIs(cli.our_state, SWITCHED_PROTOCOL)

    def test_denied_connect_resumes_http(self):
        cli = Connection(CLIENT)
        srv = Connection(SERVER)
        wire = cli.send(Request("CONNECT", "example:443", [("Host", "example:443")]))
        cli.send(EndOfMessage())
        pump(cli, srv, wire)
        denial = srv.send(Response(403, [("Content-Length", "0")]))
        srv.send(EndOfMessage())
        self.assertIs(srv.our_state, DONE)
        pump(srv, cli, denial)
        self.assertIs(cli.our_state, DONE)
        self.assertIs(srv.their_state, DONE)


if __name__ == "__main__":
    unittest.main()
