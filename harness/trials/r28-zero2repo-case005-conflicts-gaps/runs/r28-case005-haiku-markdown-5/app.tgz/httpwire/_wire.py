"""Byte-level helpers: block boundaries, line splitting, and field parsing."""

import re

from ._errors import RemoteProtocolError
from ._headers import TOKEN_RE

# Implementer's choice, within the PRD range 16..32.
MAX_CHUNK_SIZE_DIGITS = 32

REQUEST_LINE_RE = re.compile(
    rb"([!#$%&'*+\-.^_`|~0-9A-Za-z]+) ([\x21-\x7e]+) HTTP/([0-9])\.([0-9])\Z"
)
STATUS_LINE_RE = re.compile(rb"HTTP/([0-9])\.([0-9]) ([0-9]{3})(?: (.*))?\Z", re.DOTALL)
CHUNK_SIZE_RE = re.compile(
    rb"([0-9A-Fa-f]{1,%d})(?:;[^\r\n]*)?\r\n\Z" % MAX_CHUNK_SIZE_DIGITS
)


def find_block_end(buf):
    """Return the index just past the first blank line, or None if incomplete.

    Lines may end with LF or CRLF.
    """
    pos = 0
    while True:
        idx = buf.find(b"\n", pos)
        if idx < 0:
            return None
        if idx == pos or (idx == pos + 1 and buf[pos] == 0x0D):
            return idx + 1
        pos = idx + 1


def split_block(block):
    """Split a block that ends in a blank line into its non-blank lines."""
    lines = []
    pos = 0
    while True:
        idx = block.index(b"\n", pos)
        line = block[pos:idx]
        if line.endswith(b"\r"):
            line = line[:-1]
        pos = idx + 1
        if not line:
            return lines
        lines.append(line)


def parse_fields(lines):
    """Parse header or trailer lines into (name, value) pairs.

    Obsolete line folding is joined to the previous value.
    """
    pairs = []
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            if not pairs:
                raise RemoteProtocolError("line folding with no preceding header", 400)
            name, value = pairs[-1]
            joined = (value + b" " + line.strip(b" \t")).strip(b" \t")
            pairs[-1] = (name, joined)
            continue
        idx = line.find(b":")
        if idx <= 0:
            raise RemoteProtocolError("malformed header line", 400)
        name = line[:idx]
        if not TOKEN_RE.fullmatch(name):
            raise RemoteProtocolError("malformed header name", 400)
        pairs.append((name, line[idx + 1:].strip(b" \t")))
    return pairs
