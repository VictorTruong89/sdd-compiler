"""Role, state, and non-event sentinel objects.

Every value here is a distinct object compared by identity. None of them are
strings, and none compare equal to another sentinel.
"""


class _Sentinel(object):
    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return self._name


# Roles
CLIENT = _Sentinel("CLIENT")
SERVER = _Sentinel("SERVER")

# Connection states
IDLE = _Sentinel("IDLE")
SEND_RESPONSE = _Sentinel("SEND_RESPONSE")
SEND_BODY = _Sentinel("SEND_BODY")
DONE = _Sentinel("DONE")
MUST_CLOSE = _Sentinel("MUST_CLOSE")
CLOSED = _Sentinel("CLOSED")
MIGHT_SWITCH_PROTOCOL = _Sentinel("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = _Sentinel("SWITCHED_PROTOCOL")
ERROR = _Sentinel("ERROR")

# Non-event results of Connection.next_event()
NEED_DATA = _Sentinel("NEED_DATA")
PAUSED = _Sentinel("PAUSED")
