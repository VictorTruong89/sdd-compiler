"""The six HTTP event types (FP-01)."""

import re

from ._errors import LocalProtocolError
from ._headers import (
    TOKEN_RE,
    check_reason,
    normalize_headers,
    to_bytes,
)

_TARGET_RE = re.compile(rb"[\x21-\x7e]+")
_VERSION_RE = re.compile(rb"[0-9]\.[0-9]")


def _check_version(version):
    if not _VERSION_RE.fullmatch(version):
        raise LocalProtocolError("HTTP version must be two digits separated by a dot")
    return version


def _check_host(headers, version):
    hosts = headers.get_values(b"host")
    if len(hosts) > 1:
        raise LocalProtocolError("more than one Host header")
    if version == b"1.1" and not hosts:
        raise LocalProtocolError("an HTTP/1.1 request needs exactly one Host header")


class Request(object):
    """Start of an HTTP request."""

    def __init__(self, method, target, headers=(), http_version=b"1.1"):
        method = to_bytes(method, "method")
        if not TOKEN_RE.fullmatch(method):
            raise LocalProtocolError("method must be a single RFC 7230 token")
        target = to_bytes(target, "request target")
        if not _TARGET_RE.fullmatch(target):
            raise LocalProtocolError("request target must be visible ASCII")
        http_version = _check_version(to_bytes(http_version, "http_version"))
        headers = normalize_headers(headers)
        _check_host(headers, http_version)
        self.method = method
        self.target = target
        self.headers = headers
        self.http_version = http_version

    def __repr__(self):
        return "Request(method=%r, target=%r, headers=%r, http_version=%r)" % (
            self.method, self.target, self.headers, self.http_version)


class _StatusEvent(object):
    _low = 0
    _high = 0

    def __init__(self, status_code, headers=(), http_version=b"1.1", reason=b""):
        if not isinstance(status_code, int):
            raise LocalProtocolError("status code must be an integer")
        status = int(status_code)
        if not (self._low <= status < self._high):
            raise LocalProtocolError("status code %d is out of range" % status)
        http_version = _check_version(to_bytes(http_version, "http_version"))
        reason = to_bytes(reason, "reason")
        check_reason(reason)
        self.status_code = status
        self.headers = normalize_headers(headers)
        self.http_version = http_version
        self.reason = reason

    def __repr__(self):
        return "%s(status_code=%r, headers=%r, http_version=%r, reason=%r)" % (
            type(self).__name__, self.status_code, self.headers,
            self.http_version, self.reason)


class InformationalResponse(_StatusEvent):
    """An HTTP 1xx response (status 100 <= s < 200)."""
    _low = 100
    _high = 200


class Response(_StatusEvent):
    """The start of a final HTTP response (status 200 <= s < 1000)."""
    _low = 200
    _high = 1000


class Data(object):
    """A piece of a message body."""

    def __init__(self, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)

    def __repr__(self):
        return "Data(data=%r, chunk_start=%r, chunk_end=%r)" % (
            self.data, self.chunk_start, self.chunk_end)


class EndOfMessage(object):
    """The end of a request or response, with optional trailing headers."""

    def __init__(self, headers=()):
        self.headers = normalize_headers(headers)

    def __repr__(self):
        return "EndOfMessage(headers=%r)" % (self.headers,)


class ConnectionClosed(object):
    """The sending side of this conversation will send no more data."""

    def __repr__(self):
        return "ConnectionClosed()"
