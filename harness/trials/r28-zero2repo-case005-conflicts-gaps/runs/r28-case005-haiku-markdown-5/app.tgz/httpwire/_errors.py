"""Exception classes used by httpwire."""


class _ProtocolErrorBase(Exception):
    """Common base for the two protocol-error kinds.

    Neither concrete kind is a subclass of the other.
    """

    def __init__(self, message="", error_status_hint=400):
        Exception.__init__(self, message)
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(_ProtocolErrorBase):
    """The integrator's own event or send violated HTTP/1.1."""


class RemoteProtocolError(_ProtocolErrorBase):
    """The peer's bytes violated HTTP/1.1."""


class ReceiveAfterCloseError(RuntimeError):
    """Non-empty bytes were fed after the receive side was closed.

    This is deliberately neither a LocalProtocolError nor a RemoteProtocolError.
    """


class _IllegalTransition(Exception):
    """Internal: an event is not allowed in the current states."""
