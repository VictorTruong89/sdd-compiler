"""The HTTP/1.1 connection state machine (FP-02 .. FP-07).

Both roles' states live in one pair, and every event (sent or received) is
run through the same transition table, so our view and the peer's view stay
consistent.
"""

from . import _wire
from ._errors import LocalProtocolError, RemoteProtocolError, ReceiveAfterCloseError, _IllegalTransition
from ._events import (
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    Request,
    Response,
)
from ._sentinels import (
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
)

_OTHER = {CLIENT: SERVER, SERVER: CLIENT}

# Implementer's choice, within the PRD range 14..18 KiB.
DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 16 * 1024

# Framing kinds
_EMPTY = "empty"
_LENGTH = "length"
_CHUNKED = "chunked"
_EOF = "eof"  # close-delimited

# Chunk decoding phases
_PH_SIZE = "size"
_PH_DATA = "data"
_PH_CRLF = "crlf"
_PH_TRAILERS = "trailers"

_FRAMING_NAMES = (b"content-length", b"transfer-encoding")


class _Frame(object):
    __slots__ = ("kind", "remaining", "phase", "started")

    def __init__(self, kind, remaining=0):
        self.kind = kind
        self.remaining = remaining
        self.phase = _PH_SIZE
        self.started = False


def _nbytes(data):
    try:
        return memoryview(data).nbytes
    except TypeError:
        return len(data)


def _as_buffer(data):
    try:
        return memoryview(data)
    except TypeError:
        return None


def _request_frame(headers):
    cl = headers.first(b"content-length")
    if cl is not None:
        return _Frame(_LENGTH, int(cl))
    if headers.has(b"transfer-encoding"):
        return _Frame(_CHUNKED)
    return _Frame(_LENGTH, 0)


def _response_frame(headers, method, status):
    if method == b"HEAD" or status in (204, 304) or status < 200:
        return _Frame(_EMPTY)
    if headers.has(b"transfer-encoding"):
        return _Frame(_CHUNKED)
    cl = headers.first(b"content-length")
    if cl is not None:
        return _Frame(_LENGTH, int(cl))
    return _Frame(_EOF)


def _drop(raw, names):
    return [(n, v) for n, v in raw if n.lower() not in names]


def _rewrite_connection(raw):
    """Remove keep-alive tokens and make the Connection header say close."""
    out = []
    placed = False
    tokens = []
    for name, value in raw:
        if name.lower() == b"connection":
            if not placed:
                out.append(None)
                placed = True
            for part in value.split(b","):
                token = part.strip(b" \t")
                if token and token.lower() not in (b"keep-alive", b"close"):
                    tokens.append(token)
        else:
            out.append((name, value))
    tokens.append(b"close")
    value = b", ".join(tokens)
    if placed:
        out[out.index(None)] = (b"Connection", value)
    else:
        out.append((b"Connection", value))
    return out


def _header_lines(raw):
    return [n + b": " + v + b"\r\n" for n, v in raw]


class Connection(object):
    """One HTTP/1.1 connection in the client or server role. Performs no I/O."""

    def __init__(self, role, max_incomplete_event_size=DEFAULT_MAX_INCOMPLETE_EVENT_SIZE):
        if role is not CLIENT and role is not SERVER:
            raise ValueError("role must be CLIENT or SERVER")
        self.our_role = role
        self.their_role = _OTHER[role]
        self._states = {CLIENT: IDLE, SERVER: IDLE}
        self._max_incomplete = int(max_incomplete_event_size)
        self._buf = bytearray()
        self._closed = False
        self._peer_version = None
        self._reset_cycle()

    # ----- queryable state -------------------------------------------------

    @property
    def our_state(self):
        return self._states[self.our_role]

    @property
    def their_state(self):
        return self._states[self.their_role]

    @property
    def states(self):
        return {CLIENT: self._states[CLIENT], SERVER: self._states[SERVER]}

    @property
    def their_http_version(self):
        return self._peer_version

    @property
    def client_is_waiting_for_100_continue(self):
        return bool(self._waiting_100)

    @property
    def they_are_waiting_for_100_continue(self):
        return bool(self._waiting_100) and self.our_role is SERVER

    @property
    def trailing_data(self):
        return (bytes(self._buf), bool(self._closed))

    # ----- public operations -----------------------------------------------

    def send(self, event):
        return b"".join(self._send(event, passthrough=False))

    def send_with_data_passthrough(self, event):
        return list(self._send(event, passthrough=True))

    def receive_data(self, data):
        chunk = memoryview(data).tobytes()
        if not chunk:
            self._closed = True
            return None
        if self._closed:
            raise ReceiveAfterCloseError("bytes received after the peer closed its side")
        self._buf.extend(chunk)
        return None

    def next_event(self):
        try:
            return self._next_event()
        except RemoteProtocolError:
            self._states[self.their_role] = ERROR
            self._keep_alive_off = True
            self._trigger()
            raise

    def start_next_cycle(self):
        if self._states[CLIENT] is not DONE or self._states[SERVER] is not DONE:
            raise LocalProtocolError("cannot start the next cycle: both sides must be DONE")
        self._states[CLIENT] = IDLE
        self._states[SERVER] = IDLE
        self._reset_cycle()

    def send_failed(self):
        self._fail_send()

    # ----- internal: cycle bookkeeping ------------------------------------

    def _reset_cycle(self):
        self._request_method = None
        self._keep_alive_off = False
        self._connect_pending = False
        self._upgrade_pending = False
        self._waiting_100 = False
        self._in_frame = None
        self._out_frame = None

    def _set_frame(self, sender, frame):
        if sender is self.our_role:
            self._out_frame = frame
        else:
            self._in_frame = frame

    def _get_frame(self, sender):
        return self._out_frame if sender is self.our_role else self._in_frame

    def _fail_send(self):
        self._states[self.our_role] = ERROR
        self._trigger()

    # ----- internal: transition table -------------------------------------

    def _check(self, sender, event):
        s = self._states[sender]
        o = self._states[_OTHER[sender]]
        t = type(event)
        if s is ERROR:
            raise _IllegalTransition("connection is in the ERROR state")
        if t is Request:
            if sender is not CLIENT:
                raise _IllegalTransition("only the client role sends requests")
            if s is not IDLE or o is not IDLE:
                raise _IllegalTransition("a request cannot start in the current state")
        elif t is InformationalResponse:
            if sender is not SERVER or s is not SEND_RESPONSE:
                raise _IllegalTransition("informational response not allowed now")
            if event.status_code == 101 and not self._upgrade_pending:
                raise _IllegalTransition("101 without a pending Upgrade proposal")
        elif t is Response:
            if sender is not SERVER:
                raise _IllegalTransition("only the server role sends responses")
            if s is SEND_RESPONSE:
                pass
            elif s is IDLE and (o is IDLE or o is ERROR):
                pass  # unsolicited final response
            else:
                raise _IllegalTransition("response not allowed in the current state")
        elif t is Data or t is EndOfMessage:
            if s is not SEND_BODY:
                raise _IllegalTransition("body event not allowed in the current state")
        elif t is ConnectionClosed:
            if s is not IDLE and s is not DONE and s is not MUST_CLOSE:
                raise _IllegalTransition("connection-closed not allowed in the current state")
        else:
            raise _IllegalTransition("not an HTTP event")

    def _apply(self, sender, event, frame):
        st = self._states
        peer = sender is not self.our_role
        t = type(event)
        if t is Request:
            hdrs = event.headers
            self._request_method = event.method
            self._connect_pending = event.method == b"CONNECT"
            self._upgrade_pending = hdrs.has(b"upgrade")
            if event.http_version != b"1.1" or hdrs.has_token(b"connection", b"close"):
                self._keep_alive_off = True
            if event.http_version == b"1.1" and hdrs.has_token(b"expect", b"100-continue"):
                self._waiting_100 = True
            if peer:
                self._peer_version = event.http_version
            st[CLIENT] = SEND_BODY
            st[SERVER] = SEND_RESPONSE
            self._set_frame(sender, frame)
        elif t is InformationalResponse:
            self._waiting_100 = False
            if event.status_code == 101:
                self._connect_pending = False
                self._upgrade_pending = False
                st[CLIENT] = SWITCHED_PROTOCOL
                st[SERVER] = SWITCHED_PROTOCOL
        elif t is Response:
            self._waiting_100 = False
            if peer:
                self._peer_version = event.http_version
            if (event.http_version != b"1.1" or self._peer_version != b"1.1"
                    or frame.kind == _EOF
                    or event.headers.has_token(b"connection", b"close")):
                self._keep_alive_off = True
            pending = self._connect_pending or self._upgrade_pending
            if sender is SERVER and pending:
                accepted = self._connect_pending and event.status_code == 200
                self._connect_pending = False
                self._upgrade_pending = False
                if accepted:
                    st[CLIENT] = SWITCHED_PROTOCOL
                    st[SERVER] = SWITCHED_PROTOCOL
                else:
                    if st[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                        st[CLIENT] = DONE
                    st[SERVER] = SEND_BODY
            else:
                st[SERVER] = SEND_BODY
            self._set_frame(sender, frame)
        elif t is Data:
            if sender is CLIENT:
                self._waiting_100 = False
            fr = self._get_frame(sender)
            if fr is not None and fr.kind == _LENGTH:
                fr.remaining -= _nbytes(event.data)
        elif t is EndOfMessage:
            if sender is CLIENT:
                self._waiting_100 = False
            if (sender is CLIENT and (self._connect_pending or self._upgrade_pending)
                    and st[SERVER] is SEND_RESPONSE):
                st[CLIENT] = MIGHT_SWITCH_PROTOCOL
            else:
                st[sender] = DONE
            self._set_frame(sender, None)
        elif t is ConnectionClosed:
            st[sender] = CLOSED

    def _trigger(self):
        st = self._states
        for a, b in ((CLIENT, SERVER), (SERVER, CLIENT)):
            if st[a] is CLOSED and (st[b] is IDLE or st[b] is DONE):
                st[b] = MUST_CLOSE
            if st[a] is ERROR and st[b] is DONE:
                st[b] = MUST_CLOSE
        if self._keep_alive_off:
            for role in (CLIENT, SERVER):
                if st[role] is DONE:
                    st[role] = MUST_CLOSE

    # ----- internal: sending -----------------------------------------------

    def _send(self, event, passthrough):
        sender = self.our_role
        try:
            self._check(sender, event)
            pieces, frame = self._encode(event, passthrough)
        except _IllegalTransition as exc:
            self._fail_send()
            raise LocalProtocolError(str(exc))
        except LocalProtocolError:
            self._fail_send()
            raise
        except TypeError as exc:
            self._fail_send()
            raise LocalProtocolError("event payload is not bytes-like: %s" % exc)
        self._apply(sender, event, frame)
        self._trigger()
        return pieces

    def _encode(self, event, passthrough):
        t = type(event)
        if t is Request:
            return self._encode_request(event)
        if t is InformationalResponse:
            return self._encode_informational(event)
        if t is Response:
            return self._encode_response(event)
        if t is Data:
            return self._encode_data(event, passthrough), None
        if t is EndOfMessage:
            return self._encode_eom(event), None
        if t is ConnectionClosed:
            return [], None
        raise _IllegalTransition("not an HTTP event")

    def _encode_request(self, event):
        if event.http_version != b"1.1":
            raise LocalProtocolError("only HTTP/1.1 requests can be sent")
        raw = event.headers.raw_items()
        host = [(n, v) for n, v in raw if n.lower() == b"host"]
        rest = [(n, v) for n, v in raw if n.lower() != b"host"]
        head = b"%s %s HTTP/1.1\r\n" % (event.method, event.target)
        block = head + b"".join(_header_lines(host + rest)) + b"\r\n"
        return [block], _request_frame(event.headers)

    def _encode_informational(self, event):
        if event.http_version != b"1.1":
            raise LocalProtocolError("only HTTP/1.1 responses can be sent")
        status = b"HTTP/1.1 %03d %s\r\n" % (event.status_code, event.reason)
        block = status + b"".join(_header_lines(event.headers.raw_items())) + b"\r\n"
        return [block], None

    def _encode_response(self, event):
        if event.http_version != b"1.1":
            raise LocalProtocolError("only HTTP/1.1 responses can be sent")
        status = event.status_code
        raw = list(event.headers.raw_items())

        if self._connect_pending and status == 200:
            # Accepted CONNECT: no body, no framing headers, then switched.
            raw = _drop(raw, _FRAMING_NAMES)
            frame = _Frame(_EMPTY)
        else:
            method = self._request_method
            peer_11 = self._peer_version == b"1.1"
            cl = event.headers.first(b"content-length")
            if event.headers.has(b"transfer-encoding") or cl is None:
                wire = _CHUNKED if peer_11 else _EOF
                length = 0
            else:
                wire = _LENGTH
                length = int(cl)

            if status in (204, 304):
                raw = _drop(raw, _FRAMING_NAMES)
                body = _EMPTY
            else:
                body = _EMPTY if method == b"HEAD" else wire
                if wire == _CHUNKED:
                    raw = _drop(raw, (b"content-length",))
                    if not any(n.lower() == b"transfer-encoding" for n, _ in raw):
                        raw.append((b"Transfer-Encoding", b"chunked"))
                elif wire == _LENGTH:
                    raw = _drop(raw, (b"transfer-encoding",))
                    if body == _EMPTY and length == 0:
                        raw = _drop(raw, (b"content-length",))
                else:
                    raw = _drop(raw, _FRAMING_NAMES)

            frame = _Frame(body, length if body == _LENGTH else 0)

            if (self._keep_alive_off or not peer_11 or wire == _EOF
                    or event.headers.has_token(b"connection", b"close")):
                self._keep_alive_off = True
                raw = _rewrite_connection(raw)

        block = (b"HTTP/1.1 %03d %s\r\n" % (status, event.reason)
                 + b"".join(_header_lines(raw)) + b"\r\n")
        return [block], frame

    def _encode_data(self, event, passthrough):
        frame = self._out_frame
        data = event.data
        n = _nbytes(data)
        if _as_buffer(data) is None and not passthrough:
            raise LocalProtocolError(
                "payload is not bytes-like; use send_with_data_passthrough")
        if frame.kind == _LENGTH:
            if n > frame.remaining:
                raise LocalProtocolError("body exceeds the declared Content-Length")
            return [data]
        if frame.kind == _EOF:
            return [data] if n else []
        if frame.kind == _CHUNKED:
            if n == 0:
                return []
            return [b"%x\r\n" % n, data, b"\r\n"]
        # _EMPTY: this response has no body
        if n:
            raise LocalProtocolError("this response has no body")
        return []

    def _encode_eom(self, event):
        frame = self._out_frame
        trailers = event.headers
        if frame.kind == _CHUNKED:
            lines = [b"0\r\n"] + _header_lines(trailers.raw_items()) + [b"\r\n"]
            return [b"".join(lines)]
        if len(trailers):
            raise LocalProtocolError("trailing headers are not allowed with this framing")
        if frame.kind == _LENGTH and frame.remaining != 0:
            raise LocalProtocolError("body is shorter than the declared Content-Length")
        return []

    # ----- internal: receiving ---------------------------------------------

    def _consume(self, event, frame=None):
        their = self.their_role
        try:
            self._check(their, event)
        except _IllegalTransition as exc:
            raise RemoteProtocolError(str(exc), 400)
        self._apply(their, event, frame)
        self._trigger()
        return event

    def _next_event(self):
        their = self.their_role
        st = self._states[their]
        if st is ERROR:
            raise RemoteProtocolError("peer already violated the protocol", 400)
        if st is SWITCHED_PROTOCOL or st is MIGHT_SWITCH_PROTOCOL:
            return PAUSED
        if st is CLOSED:
            return ConnectionClosed()
        if st is DONE or st is MUST_CLOSE:
            if self._buf:
                return PAUSED
            if self._closed:
                return self._consume(ConnectionClosed())
            return NEED_DATA
        if st is SEND_BODY:
            return self._pull_body()
        # IDLE (request or unsolicited response) or SEND_RESPONSE
        if self._closed and not self._buf:
            if st is IDLE:
                return self._consume(ConnectionClosed())
            raise RemoteProtocolError("connection closed in the middle of a response", 400)
        return self._pull_head()

    def _pull_head(self):
        buf = self._buf
        if not buf:
            return NEED_DATA
        if buf[0] < 33:
            raise RemoteProtocolError("line starts with a space or control byte", 400)
        end = _wire.find_block_end(buf)
        if end is None:
            if len(buf) > self._max_incomplete:
                raise RemoteProtocolError("incomplete event exceeds the size limit", 431)
            if self._closed:
                raise RemoteProtocolError("connection closed in the middle of a header block", 400)
            return NEED_DATA
        block = bytes(buf[:end])
        del buf[:end]
        lines = _wire.split_block(block)
        if not lines:
            raise RemoteProtocolError("empty head", 400)
        if self.their_role is CLIENT:
            event = self._build_request(lines)
            frame = _request_frame(event.headers)
        else:
            event = self._build_response(lines)
            frame = _response_frame(event.headers, self._request_method, event.status_code)
        return self._consume(event, frame)

    def _build_request(self, lines):
        m = _wire.REQUEST_LINE_RE.match(lines[0])
        if m is None:
            raise RemoteProtocolError("malformed request line", 400)
        version = m.group(3) + b"." + m.group(4)
        if version not in (b"1.0", b"1.1"):
            raise RemoteProtocolError("unsupported HTTP version", 400)
        pairs = _wire.parse_fields(lines[1:])
        try:
            return Request(method=m.group(1), target=m.group(2),
                           headers=pairs, http_version=version)
        except LocalProtocolError as exc:
            raise RemoteProtocolError(str(exc), exc.error_status_hint)

    def _build_response(self, lines):
        m = _wire.STATUS_LINE_RE.match(lines[0])
        if m is None:
            raise RemoteProtocolError("malformed status line", 400)
        version = m.group(1) + b"." + m.group(2)
        if version not in (b"1.0", b"1.1"):
            raise RemoteProtocolError("unsupported HTTP version", 400)
        code = int(m.group(3))
        reason = m.group(4) or b""
        pairs = _wire.parse_fields(lines[1:])
        try:
            if code < 200:
                return InformationalResponse(code, headers=pairs,
                                             http_version=version, reason=reason)
            return Response(code, headers=pairs, http_version=version, reason=reason)
        except LocalProtocolError as exc:
            raise RemoteProtocolError(str(exc), exc.error_status_hint)

    def _pull_body(self):
        frame = self._in_frame
        if frame is None:
            raise RemoteProtocolError("internal: no framing for the incoming body", 400)
        buf = self._buf
        if frame.kind == _EMPTY or (frame.kind == _LENGTH and frame.remaining == 0):
            return self._consume(EndOfMessage())
        if frame.kind == _LENGTH:
            if buf:
                n = min(len(buf), frame.remaining)
                data = bytes(buf[:n])
                del buf[:n]
                return self._consume(Data(data))
            if self._closed:
                raise RemoteProtocolError("connection closed in the middle of a Content-Length body", 400)
            return NEED_DATA
        if frame.kind == _EOF:
            if buf:
                data = bytes(buf)
                del buf[:]
                return self._consume(Data(data))
            if self._closed:
                return self._consume(EndOfMessage())
            return NEED_DATA
        return self._pull_chunked(frame)

    def _pull_chunked(self, frame):
        buf = self._buf
        while True:
            if frame.phase == _PH_SIZE:
                idx = buf.find(b"\n")
                if idx < 0:
                    if self._closed:
                        raise RemoteProtocolError("connection closed in the middle of a chunk-size line", 400)
                    return NEED_DATA
                line = bytes(buf[:idx + 1])
                m = _wire.CHUNK_SIZE_RE.match(line)
                if m is None:
                    raise RemoteProtocolError("malformed chunk-size line", 400)
                del buf[:idx + 1]
                size = int(m.group(1), 16)
                if size == 0:
                    frame.phase = _PH_TRAILERS
                else:
                    frame.remaining = size
                    frame.started = False
                    frame.phase = _PH_DATA
                continue
            if frame.phase == _PH_DATA:
                if buf:
                    n = min(len(buf), frame.remaining)
                    data = bytes(buf[:n])
                    del buf[:n]
                    frame.remaining -= n
                    start = not frame.started
                    frame.started = True
                    end = frame.remaining == 0
                    if end:
                        frame.phase = _PH_CRLF
                    return self._consume(Data(data, chunk_start=start, chunk_end=end))
                if self._closed:
                    raise RemoteProtocolError("connection closed in the middle of a chunk", 400)
                return NEED_DATA
            if frame.phase == _PH_CRLF:
                if len(buf) >= 2:
                    if bytes(buf[:2]) != b"\r\n":
                        raise RemoteProtocolError("chunk data not followed by CRLF", 400)
                    del buf[:2]
                    frame.phase = _PH_SIZE
                    continue
                if buf and buf[0] != 0x0D:
                    raise RemoteProtocolError("chunk data not followed by CRLF", 400)
                if self._closed:
                    raise RemoteProtocolError("connection closed in the middle of a chunk", 400)
                return NEED_DATA
            # _PH_TRAILERS
            end = _wire.find_block_end(buf)
            if end is None:
                if len(buf) > self._max_incomplete:
                    raise RemoteProtocolError("incomplete trailer block exceeds the size limit", 431)
                if self._closed:
                    raise RemoteProtocolError("connection closed in the middle of trailers", 400)
                return NEED_DATA
            block = bytes(buf[:end])
            del buf[:end]
            pairs = _wire.parse_fields(_wire.split_block(block))
            try:
                event = EndOfMessage(headers=pairs)
            except LocalProtocolError as exc:
                raise RemoteProtocolError(str(exc), exc.error_status_hint)
            return self._consume(event)
