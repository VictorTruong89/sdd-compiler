"""Header-name/value rules, the header container, and normalization."""

import re

from ._errors import LocalProtocolError

# RFC 7230 token
TOKEN_RE = re.compile(rb"[!#$%&'*+\-.^_`|~0-9A-Za-z]+")
DIGITS_RE = re.compile(rb"[0-9]+")

# Implementer's choice, within the PRD range 18..32.
MAX_CONTENT_LENGTH_DIGITS = 18

# NUL, other C0 controls except HTAB, and DEL.
_BAD_VALUE_RE = re.compile(rb"[\x00-\x08\x0a-\x1f\x7f]")

_FRAMING_NAMES = (b"content-length", b"transfer-encoding")


def to_bytes(value, what):
    """Accept ASCII text or a bytes-like object and return ``bytes``."""
    if isinstance(value, bytes):
        return value
    if isinstance(value, str):
        try:
            return value.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("%s must be ASCII text" % what)
    if isinstance(value, (bytearray, memoryview)):
        return bytes(value)
    raise LocalProtocolError("%s must be text or bytes" % what)


def check_field_value(value):
    """Enforce the FP-01 header value rule."""
    if _BAD_VALUE_RE.search(value):
        raise LocalProtocolError("header value contains a forbidden control byte")
    if value[:1] in (b" ", b"\t") or value[-1:] in (b" ", b"\t"):
        raise LocalProtocolError("header value may not begin or end with space or tab")


def check_reason(reason):
    """Reason phrases may hold any bytes except controls other than tab."""
    if _BAD_VALUE_RE.search(reason):
        raise LocalProtocolError("reason phrase contains a forbidden control byte")


def _has_token(values, token):
    for value in values:
        for part in value.split(b","):
            if part.strip(b" \t").lower() == token:
                return True
    return False


class Headers(object):
    """Ordered header list with an ordinary (lowercase) view and a raw view."""

    __slots__ = ("_items", "_raw")

    def __init__(self, items, raw):
        self._items = tuple(items)
        self._raw = tuple(raw)

    def __iter__(self):
        return iter(self._items)

    def __len__(self):
        return len(self._items)

    def __getitem__(self, index):
        return self._items[index]

    def __eq__(self, other):
        if isinstance(other, Headers):
            other = other._items
        try:
            other = [tuple(pair) for pair in other]
        except TypeError:
            return NotImplemented
        return list(self._items) == other

    __hash__ = None

    def __repr__(self):
        return "Headers(%r)" % (list(self._items),)

    def raw_items(self):
        """(name, value) pairs with names exactly as the caller spelled them."""
        return list(self._raw)

    def get_values(self, lname):
        return [value for name, value in self._items if name == lname]

    def has(self, lname):
        return any(name == lname for name, _ in self._items)

    def first(self, lname):
        for name, value in self._items:
            if name == lname:
                return value
        return None

    def has_token(self, lname, token):
        return _has_token(self.get_values(lname), token.lower())


def normalize_headers(pairs):
    """Validate and normalize a header list (FP-01)."""
    if pairs is None:
        pairs = ()
    if isinstance(pairs, Headers):
        pairs = pairs.raw_items()

    raw = []
    for item in pairs:
        try:
            name, value = item
        except (TypeError, ValueError):
            raise LocalProtocolError("each header must be a (name, value) pair")
        name = to_bytes(name, "header name")
        value = to_bytes(value, "header value")
        if not TOKEN_RE.fullmatch(name):
            raise LocalProtocolError("header name is not an RFC 7230 token")
        check_field_value(value)
        raw.append((name, value))

    result = []  # (raw name, lowercase name, value)
    cl_int = None
    seen_te = 0
    for name, value in raw:
        lname = name.lower()
        if lname == b"content-length":
            pieces = []
            for piece in value.split(b","):
                piece = piece.strip(b" \t")
                if not DIGITS_RE.fullmatch(piece):
                    raise LocalProtocolError("Content-Length must be a decimal integer")
                if len(piece) > MAX_CONTENT_LENGTH_DIGITS:
                    raise LocalProtocolError("Content-Length has too many digits")
                pieces.append(piece)
            if len(set(int(p) for p in pieces)) != 1:
                raise LocalProtocolError("conflicting Content-Length values")
            if cl_int is not None:
                if int(pieces[0]) != cl_int:
                    raise LocalProtocolError("conflicting Content-Length values")
                continue  # equal repeat collapses into the first header
            cl_int = int(pieces[0])
            result.append((name, lname, pieces[0]))
        elif lname == b"transfer-encoding":
            seen_te += 1
            if seen_te > 1:
                raise LocalProtocolError("more than one Transfer-Encoding header", 501)
            if value.lower() != b"chunked":
                raise LocalProtocolError("only the chunked transfer coding is supported", 501)
            result.append((name, lname, b"chunked"))
        else:
            result.append((name, lname, value))

    items = tuple((lname, value) for _, lname, value in result)
    raw_out = tuple((name, value) for name, _, value in result)
    return Headers(items, raw_out)
