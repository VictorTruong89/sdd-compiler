"""Role and state sentinels, plus the non-event pull results."""


class _Sentinel:
    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return self._name


CLIENT = _Sentinel("CLIENT")
SERVER = _Sentinel("SERVER")

IDLE = _Sentinel("IDLE")
SEND_RESPONSE = _Sentinel("SEND_RESPONSE")
SEND_BODY = _Sentinel("SEND_BODY")
DONE = _Sentinel("DONE")
MUST_CLOSE = _Sentinel("MUST_CLOSE")
CLOSED = _Sentinel("CLOSED")
MIGHT_SWITCH_PROTOCOL = _Sentinel("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = _Sentinel("SWITCHED_PROTOCOL")
ERROR = _Sentinel("ERROR")

NEED_DATA = _Sentinel("NEED_DATA")
PAUSED = _Sentinel("PAUSED")


def other_role(role):
    return SERVER if role is CLIENT else CLIENT


class StatePair(tuple):
    """``(client_state, server_state)`` that also indexes by role object."""

    def __getitem__(self, key):
        if key is CLIENT:
            return tuple.__getitem__(self, 0)
        if key is SERVER:
            return tuple.__getitem__(self, 1)
        return tuple.__getitem__(self, key)
