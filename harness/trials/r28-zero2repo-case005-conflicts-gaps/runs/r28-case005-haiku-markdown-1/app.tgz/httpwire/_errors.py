"""Exception classes for httpwire."""


class ProtocolError(Exception):
    """Common base for the two protocol-error kinds.

    ``error_status_hint`` is the suggested HTTP status (default 400).
    """

    def __init__(self, message="", error_status_hint=400):
        super().__init__(message)
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(ProtocolError):
    """The integrator's own event or send violated the protocol."""


class RemoteProtocolError(ProtocolError):
    """The peer's bytes violated the protocol."""


class ReceiveClosedError(RuntimeError):
    """Non-empty bytes were fed after the receive side was already closed.

    Deliberately neither a local nor a remote protocol error.
    """
