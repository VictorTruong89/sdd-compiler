"""HTTP event types and header-list normalization (PRD FP-01)."""

import re
from collections.abc import Mapping

from ._errors import LocalProtocolError

# RFC 7230 tchar
_TOKEN_RE = re.compile(rb"[!#$%&'*+\-.^_`|~0-9A-Za-z]+")
_VERSION_RE = re.compile(rb"[0-9]\.[0-9]")
_TARGET_RE = re.compile(rb"[\x21-\x7e]+")
_DIGITS_RE = re.compile(rb"[0-9]+")
# NUL, CR, LF, VT, FF are never allowed in header values.
_BAD_VALUE_RE = re.compile(rb"[\x00\r\n\x0b\x0c]")
_BAD_REASON_RE = re.compile(rb"[\x00\r\n]")

# Maximum digits accepted in a Content-Length value (interface contract).
MAX_CONTENT_LENGTH_DIGITS = 16


def _to_bytes(value, what):
    if isinstance(value, bytes):
        return value
    if isinstance(value, str):
        try:
            return value.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("%s must be ASCII text" % what) from None
    try:
        return memoryview(value).tobytes()
    except TypeError:
        raise LocalProtocolError("%s must be bytes or ASCII text" % what) from None


def _check_value(value):
    if _BAD_VALUE_RE.search(value):
        raise LocalProtocolError("header value contains a forbidden byte")
    if value[:1] in (b" ", b"\t") or value[-1:] in (b" ", b"\t"):
        raise LocalProtocolError("header value begins or ends with space or tab")


def _check_version(value):
    value = _to_bytes(value, "HTTP version")
    if not _VERSION_RE.fullmatch(value):
        raise LocalProtocolError("HTTP version must be two digits separated by a dot")
    return value


def _check_status(code, low, high):
    if isinstance(code, bool) or not isinstance(code, int):
        raise LocalProtocolError("status code must be an integer")
    code = int(code)
    if not low <= code <= high:
        raise LocalProtocolError("status code %d is out of range" % code)
    return code


def _check_reason(reason):
    reason = _to_bytes(reason, "reason phrase")
    if _BAD_REASON_RE.search(reason):
        raise LocalProtocolError("reason phrase contains a forbidden byte")
    return reason


class Headers:
    """Ordered header list.

    Iterating or indexing yields ``(lowercase_name, value)`` byte pairs.
    ``raw_items()`` yields ``(name_as_given, value)`` byte pairs.
    """

    __slots__ = ("_items",)

    def __init__(self, items=()):
        self._items = tuple(items)

    def __len__(self):
        return len(self._items)

    def __iter__(self):
        for raw, value in self._items:
            yield (raw.lower(), value)

    def __getitem__(self, index):
        if isinstance(index, slice):
            return [(raw.lower(), value) for raw, value in self._items[index]]
        raw, value = self._items[index]
        return (raw.lower(), value)

    def raw_items(self):
        return [(raw, value) for raw, value in self._items]

    def __eq__(self, other):
        if isinstance(other, Headers):
            return self._items == other._items
        try:
            return list(self) == [tuple(pair) for pair in other]
        except TypeError:
            return NotImplemented

    __hash__ = None

    def __repr__(self):
        return "Headers(%r)" % (list(self),)


def _digits_value(piece):
    if (not piece or len(piece) > MAX_CONTENT_LENGTH_DIGITS
            or not _DIGITS_RE.fullmatch(piece)):
        raise LocalProtocolError("Content-Length must be a decimal integer of at most %d digits"
                                 % MAX_CONTENT_LENGTH_DIGITS)
    return int(piece)


def _normalize_headers(pairs):
    """Turn caller-supplied pairs into a validated, normalized ``Headers``."""
    if pairs is None:
        pairs = ()
    if isinstance(pairs, Headers):
        items = list(pairs._items)
    else:
        if isinstance(pairs, Mapping):
            pairs = pairs.items()
        items = []
        for pair in pairs:
            try:
                name, value = pair
            except (TypeError, ValueError):
                raise LocalProtocolError("each header must be a (name, value) pair") from None
            raw = _to_bytes(name, "header name")
            val = _to_bytes(value, "header value")
            if not _TOKEN_RE.fullmatch(raw):
                raise LocalProtocolError("invalid header name %r" % (raw,))
            _check_value(val)
            items.append((raw, val))

    # Transfer-Encoding: exactly one header, exactly "chunked" (any case).
    te_idx = [i for i, (raw, _) in enumerate(items) if raw.lower() == b"transfer-encoding"]
    if len(te_idx) > 1:
        raise LocalProtocolError("more than one Transfer-Encoding header", 501)
    if te_idx:
        i = te_idx[0]
        raw, val = items[i]
        if val.lower() != b"chunked":
            raise LocalProtocolError("unsupported Transfer-Encoding", 501)
        items[i] = (raw, b"chunked")

    # Content-Length: all pieces must be equal decimal integers; collapse to one.
    cl_idx = [i for i, (raw, _) in enumerate(items) if raw.lower() == b"content-length"]
    if cl_idx:
        values = []
        for i in cl_idx:
            for piece in items[i][1].split(b","):
                values.append(_digits_value(piece.strip(b" \t")))
        if len(set(values)) > 1:
            raise LocalProtocolError("conflicting Content-Length values")
        first = cl_idx[0]
        new_items = []
        for i, (raw, val) in enumerate(items):
            if i == first:
                new_items.append((raw, str(values[0]).encode("ascii")))
            elif i in cl_idx:
                continue
            else:
                new_items.append((raw, val))
        items = new_items

    return Headers(items)


def _check_host(headers, version):
    hosts = [1 for raw, _ in headers._items if raw.lower() == b"host"]
    if len(hosts) > 1:
        raise LocalProtocolError("more than one Host header")
    if version == b"1.1" and not hosts:
        raise LocalProtocolError("HTTP/1.1 request requires a Host header")


class _Event:
    __slots__ = ()
    _fields = ()

    def __eq__(self, other):
        if type(other) is not type(self):
            return NotImplemented
        return all(getattr(self, f) == getattr(other, f) for f in self._fields)

    __hash__ = None

    def __repr__(self):
        inner = ", ".join("%s=%r" % (f, getattr(self, f)) for f in self._fields)
        return "%s(%s)" % (type(self).__name__, inner)


class Request(_Event):
    __slots__ = ("method", "target", "headers", "http_version")
    _fields = ("method", "target", "headers", "http_version")

    def __init__(self, method, target, headers=(), http_version=b"1.1"):
        method = _to_bytes(method, "method")
        if not _TOKEN_RE.fullmatch(method):
            raise LocalProtocolError("method must be a single token")
        target = _to_bytes(target, "request target")
        if not _TARGET_RE.fullmatch(target):
            raise LocalProtocolError("request target must be visible ASCII")
        version = _check_version(http_version)
        hdrs = _normalize_headers(headers)
        _check_host(hdrs, version)
        self.method = method
        self.target = target
        self.headers = hdrs
        self.http_version = version


class InformationalResponse(_Event):
    __slots__ = ("status_code", "headers", "http_version", "reason")
    _fields = ("status_code", "headers", "http_version", "reason")

    def __init__(self, status_code, headers=(), http_version=b"1.1", reason=b""):
        self.status_code = _check_status(status_code, 100, 199)
        self.headers = _normalize_headers(headers)
        self.http_version = _check_version(http_version)
        self.reason = _check_reason(reason)


class Response(_Event):
    __slots__ = ("status_code", "headers", "http_version", "reason")
    _fields = ("status_code", "headers", "http_version", "reason")

    def __init__(self, status_code, headers=(), http_version=b"1.1", reason=b""):
        self.status_code = _check_status(status_code, 200, 999)
        self.headers = _normalize_headers(headers)
        self.http_version = _check_version(http_version)
        self.reason = _check_reason(reason)


class Data(_Event):
    __slots__ = ("data", "chunk_start", "chunk_end")
    _fields = ("data", "chunk_start", "chunk_end")

    def __init__(self, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)


class EndOfMessage(_Event):
    __slots__ = ("headers",)
    _fields = ("headers",)

    def __init__(self, headers=()):
        self.headers = _normalize_headers(headers)


class ConnectionClosed(_Event):
    __slots__ = ()
    _fields = ()

    def __init__(self):
        pass


EVENT_TYPES = (Request, InformationalResponse, Response, Data, EndOfMessage, ConnectionClosed)
