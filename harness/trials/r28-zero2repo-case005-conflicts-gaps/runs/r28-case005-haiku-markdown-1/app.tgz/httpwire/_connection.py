"""The bring-your-own-I/O connection object (PRD FP-02 through FP-07)."""

import re

from ._errors import LocalProtocolError, RemoteProtocolError, ReceiveClosedError
from ._events import (
    EVENT_TYPES,
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    Request,
    Response,
)
from ._state import (
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
    StatePair,
    other_role,
)

DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 8 * 1024
# Chunk-size lines may carry at most this many hexadecimal digits.
MAX_CHUNK_SIZE_DIGITS = 32

_HEX_RE = re.compile(rb"[0-9A-Fa-f]{1,32}")
_STATUS_CODE_RE = re.compile(rb"[0-9]{3}")
_TOKEN_RE = re.compile(rb"[!#$%&'*+\-.^_`|~0-9A-Za-z]+")
_TARGET_RE = re.compile(rb"[\x21-\x7e]+")
_BAD_REASON_RE = re.compile(rb"[\x00\r\n]")

# Event-triggered transitions, keyed by the sender's role and state.
_TRANSITIONS = {
    CLIENT: {
        IDLE: {Request: SEND_BODY, ConnectionClosed: CLOSED},
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
    },
    SERVER: {
        IDLE: {Response: SEND_BODY, ConnectionClosed: CLOSED},
        SEND_RESPONSE: {InformationalResponse: SEND_RESPONSE, Response: SEND_BODY},
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
    },
}


# ---------------------------------------------------------------- helpers

def _payload_len(data):
    try:
        return memoryview(data).nbytes
    except TypeError:
        pass
    try:
        return len(data)
    except TypeError:
        raise LocalProtocolError("Data payload has no length") from None


def _payload_piece(data, passthrough):
    try:
        return memoryview(data).tobytes()
    except TypeError:
        if passthrough:
            return data
        raise LocalProtocolError(
            "Data payload is not bytes-like; use send_with_data_passthrough") from None


def _header_tokens(headers, name):
    out = []
    for raw, value in headers._items:
        if raw.lower() == name:
            out.extend(piece.strip(b" \t") for piece in value.split(b","))
    return out


def _has_token(headers, name, token):
    """Case-insensitive, whole-element token match inside a list header."""
    return any(piece.lower() == token for piece in _header_tokens(headers, name))


def _has_token_exact(headers, name, token):
    return any(piece == token for piece in _header_tokens(headers, name))


def _has_header(headers, name):
    return any(raw.lower() == name for raw, _ in headers._items)


def _content_length(headers):
    for raw, value in headers._items:
        if raw.lower() == b"content-length":
            return int(value)
    return None


def _is_chunked(headers):
    return any(raw.lower() == b"transfer-encoding" and value == b"chunked"
               for raw, value in headers._items)


def _serialize(items):
    return b"".join(name + b": " + value + b"\r\n" for name, value in items)


def _status_line(code, reason):
    return b"HTTP/1.1 %d %s\r\n" % (code, reason)


def _drop(items, *names):
    return [(raw, value) for raw, value in items if raw.lower() not in names]


def _rewrite_connection(items):
    """Replace Connection headers with one that ends in ``close``, dropping keep-alive."""
    out = []
    tokens = []
    insert_at = None
    for raw, value in items:
        if raw.lower() == b"connection":
            if insert_at is None:
                insert_at = len(out)
            tokens.extend(p.strip(b" \t") for p in value.split(b","))
        else:
            out.append((raw, value))
    tokens = [t for t in tokens if t and t.lower() != b"keep-alive"]
    if not any(t.lower() == b"close" for t in tokens):
        tokens.append(b"close")
    conn = (b"Connection", b", ".join(tokens))
    if insert_at is None:
        out.append(conn)
    else:
        out.insert(insert_at, conn)
    return out


def _split_head(buf):
    """Split a stored head block into ``(lines, consumed)``, or None if unfinished.

    Lines end in LF; a preceding CR is removed. The block ends at the first empty line.
    """
    lines = []
    pos = 0
    while True:
        idx = buf.find(b"\n", pos)
        if idx < 0:
            return None
        line = bytes(buf[pos:idx])
        if line.endswith(b"\r"):
            line = line[:-1]
        pos = idx + 1
        if not line:
            return lines, pos
        lines.append(line)


def _parse_header_lines(lines):
    pairs = []
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            # Obsolete line folding: join to previous value with one space.
            if not pairs:
                raise RemoteProtocolError("header continuation line without a header")
            name, value = pairs[-1]
            pairs[-1] = (name, value + b" " + line.lstrip(b" \t"))
            continue
        idx = line.find(b":")
        if idx <= 0:
            raise RemoteProtocolError("malformed header line")
        name = line[:idx]
        if not _TOKEN_RE.fullmatch(name):
            raise RemoteProtocolError("invalid header name")
        pairs.append((name, line[idx + 1:].strip(b" \t")))
    return pairs


class _Body:
    """Framing of one message body, used for both writing and reading."""

    __slots__ = ("kind", "remaining", "chunk_state", "chunk_remaining", "chunk_start")

    def __init__(self, kind, length=0):
        # kind: "length" (exact byte count), "chunked", or "eof" (close-delimited).
        self.kind = kind
        self.remaining = length if kind == "length" else 0
        self.chunk_state = "size"
        self.chunk_remaining = 0
        self.chunk_start = False


def _request_body(ev):
    cl = _content_length(ev.headers)
    if cl is not None:
        return _Body("length", cl)
    if _is_chunked(ev.headers):
        return _Body("chunked")
    return _Body("length", 0)


def _request_ka_off(ev):
    return ev.http_version != b"1.1" or _has_token(ev.headers, b"connection", b"close")


# ------------------------------------------------------------- Connection

class Connection:
    """One HTTP/1.1 connection in the client or server role. Performs no I/O."""

    def __init__(self, role, max_incomplete_event_size=DEFAULT_MAX_INCOMPLETE_EVENT_SIZE):
        if role is not CLIENT and role is not SERVER:
            raise ValueError("role must be CLIENT or SERVER")
        self._our_role = role
        self._their_role = other_role(role)
        self._states = {CLIENT: IDLE, SERVER: IDLE}
        self._buffer = bytearray()
        self._recv_closed = False
        self._max_incomplete = int(max_incomplete_event_size)

        self._their_http_version = None
        self._request_method = None
        self._ka_disabled = False
        self._client_waiting = False
        self._they_waiting = False
        self._switch_kinds = frozenset()
        self._switch_resolved = False
        self._bodies = {CLIENT: None, SERVER: None}

    # ------------------------------------------------------- properties

    @property
    def our_role(self):
        return self._our_role

    @property
    def their_role(self):
        return self._their_role

    @property
    def our_state(self):
        return self._states[self._our_role]

    @property
    def their_state(self):
        return self._states[self._their_role]

    @property
    def states(self):
        return StatePair((self._states[CLIENT], self._states[SERVER]))

    @property
    def their_http_version(self):
        return self._their_http_version

    @property
    def client_is_waiting_for_100_continue(self):
        return bool(self._client_waiting)

    @property
    def they_are_waiting_for_100_continue(self):
        return bool(self._they_waiting)

    @property
    def trailing_data(self):
        return (bytes(self._buffer), bool(self._recv_closed))

    # ----------------------------------------------------------- sending

    def send(self, event):
        pieces = self._send_event(event, passthrough=False)
        return b"".join(pieces)

    def send_with_data_passthrough(self, event):
        return self._send_event(event, passthrough=True)

    def _send_event(self, event, passthrough):
        if not isinstance(event, EVENT_TYPES):
            raise TypeError("send() expects an httpwire event")
        role = self._our_role
        if self._states[role] is ERROR:
            raise LocalProtocolError("cannot send: our side is in the ERROR state")
        try:
            new_states = self._next_states(role, event, LocalProtocolError)
            pieces, body, ka_off = self._encode(event, passthrough)
        except LocalProtocolError:
            self._states[role] = ERROR
            self._fire()
            raise
        self._commit(role, event, new_states, pulled=False, body=body, ka_off=ka_off)
        self._fire()
        return pieces

    def send_failed(self):
        self._states[self._our_role] = ERROR
        self._fire()

    def start_next_cycle(self):
        if self._states[CLIENT] is not DONE or self._states[SERVER] is not DONE:
            raise LocalProtocolError("cannot start next cycle: both sides must be DONE")
        self._states = {CLIENT: IDLE, SERVER: IDLE}
        self._request_method = None
        self._ka_disabled = False
        self._client_waiting = False
        self._they_waiting = False
        self._switch_kinds = frozenset()
        self._switch_resolved = False
        self._bodies = {CLIENT: None, SERVER: None}

    # ---------------------------------------------------------- receiving

    def receive_data(self, data):
        chunk = memoryview(data).tobytes()
        if not chunk:
            self._recv_closed = True
            return None
        if self._recv_closed:
            raise ReceiveClosedError("data received after the peer closed its sending side")
        self._buffer += chunk
        return None

    def next_event(self):
        their = self._their_role
        if self._states[their] is ERROR:
            raise RemoteProtocolError("peer side is in the ERROR state")
        try:
            return self._next_event_unchecked()
        except RemoteProtocolError:
            self._states[their] = ERROR
            self._fire()
            raise

    def _next_event_unchecked(self):
        their = self._their_role
        ts = self._states[their]
        buf = self._buffer
        if ts is SWITCHED_PROTOCOL or ts is MIGHT_SWITCH_PROTOCOL:
            return PAUSED
        if ts is CLOSED:
            return ConnectionClosed()
        if ts is DONE or ts is MUST_CLOSE:
            if buf:
                return PAUSED
            if self._recv_closed:
                return self._pull_connection_closed()
            return NEED_DATA
        if ts is SEND_BODY:
            return self._pull_body_event()
        # IDLE or SEND_RESPONSE: a start line is expected.
        if not buf:
            if self._recv_closed:
                if ts is IDLE:
                    return self._pull_connection_closed()
                raise RemoteProtocolError("connection closed while a response was expected")
            return NEED_DATA
        return self._pull_start_event()

    def _pull_connection_closed(self):
        ev = ConnectionClosed()
        new_states = self._next_states(self._their_role, ev, RemoteProtocolError)
        self._commit(self._their_role, ev, new_states, pulled=True)
        self._fire()
        return ev

    def _pull_start_event(self):
        buf = self._buffer
        if buf[0] < 33:
            raise RemoteProtocolError("message must not begin with a space or control byte")
        head = _split_head(buf)
        if head is None:
            if len(buf) > self._max_incomplete:
                raise RemoteProtocolError("incomplete message head exceeds size limit", 431)
            if self._recv_closed:
                raise RemoteProtocolError("connection closed in the middle of a message head")
            return NEED_DATA
        lines, consumed = head
        ev = self._parse_start_line(lines)
        body, ka_off = self._pulled_start_framing(ev)
        new_states = self._next_states(self._their_role, ev, RemoteProtocolError)
        del buf[:consumed]
        self._commit(self._their_role, ev, new_states, pulled=True, body=body, ka_off=ka_off)
        self._fire()
        return ev

    def _pull_body_event(self):
        their = self._their_role
        body = self._bodies[their]
        if body is None:
            raise RemoteProtocolError("no message body is open")
        ev = self._read_body(body)
        if ev is NEED_DATA:
            return NEED_DATA
        new_states = self._next_states(their, ev, RemoteProtocolError)
        self._commit(their, ev, new_states, pulled=True)
        self._fire()
        return ev

    def _parse_start_line(self, lines):
        try:
            if self._their_role is CLIENT:
                return self._build_request(lines)
            return self._build_response(lines)
        except LocalProtocolError as exc:
            raise RemoteProtocolError(str(exc), exc.error_status_hint) from None

    def _build_request(self, lines):
        parts = lines[0].split(b" ")
        if len(parts) != 3:
            raise RemoteProtocolError("malformed request line")
        method, target, version = parts
        if not _TOKEN_RE.fullmatch(method):
            raise RemoteProtocolError("invalid request method")
        if not _TARGET_RE.fullmatch(target):
            raise RemoteProtocolError("invalid request target")
        if version not in (b"HTTP/1.0", b"HTTP/1.1"):
            raise RemoteProtocolError("unsupported HTTP version")
        headers = _parse_header_lines(lines[1:])
        return Request(method=method, target=target, headers=headers,
                       http_version=version[5:])

    def _build_response(self, lines):
        parts = lines[0].split(b" ", 2)
        if len(parts) < 2:
            raise RemoteProtocolError("malformed status line")
        version, code = parts[0], parts[1]
        if version not in (b"HTTP/1.0", b"HTTP/1.1"):
            raise RemoteProtocolError("unsupported HTTP version")
        if not _STATUS_CODE_RE.fullmatch(code):
            raise RemoteProtocolError("status code must be three digits")
        status = int(code)
        if status < 100:
            raise RemoteProtocolError("status code out of range")
        reason = parts[2] if len(parts) == 3 else b""
        if _BAD_REASON_RE.search(reason):
            raise RemoteProtocolError("reason phrase contains a forbidden byte")
        headers = _parse_header_lines(lines[1:])
        cls = InformationalResponse if status < 200 else Response
        return cls(status_code=status, headers=headers, http_version=version[5:], reason=reason)

    def _pulled_start_framing(self, ev):
        """Return ``(body, ka_off)`` for a start event the peer just sent."""
        et = type(ev)
        if et is Request:
            return _request_body(ev), _request_ka_off(ev)
        if et is InformationalResponse:
            return None, False
        if self._accepts(ev):
            return None, False
        if self._request_method == b"HEAD" or ev.status_code in (204, 304):
            body = _Body("length", 0)
        else:
            cl = _content_length(ev.headers)
            if cl is not None:
                body = _Body("length", cl)
            elif _is_chunked(ev.headers):
                body = _Body("chunked")
            else:
                body = _Body("eof")
        ka_off = (ev.http_version != b"1.1"
                  or _has_token(ev.headers, b"connection", b"close")
                  or body.kind == "eof")
        return body, ka_off

    def _read_body(self, body):
        """Return the next Data/EndOfMessage for the peer's body, or NEED_DATA."""
        buf = self._buffer
        closed = self._recv_closed
        if body.kind == "length":
            if body.remaining == 0:
                return EndOfMessage()
            if not buf:
                if closed:
                    raise RemoteProtocolError("connection closed in the middle of a body")
                return NEED_DATA
            n = min(body.remaining, len(buf))
            data = bytes(buf[:n])
            del buf[:n]
            body.remaining -= n
            return Data(data=data)
        if body.kind == "eof":
            if buf:
                data = bytes(buf)
                buf.clear()
                return Data(data=data)
            if closed:
                return EndOfMessage()
            return NEED_DATA
        # chunked
        while True:
            if body.chunk_state == "size":
                idx = buf.find(b"\n")
                if idx < 0:
                    if len(buf) > self._max_incomplete:
                        raise RemoteProtocolError("chunk-size line exceeds size limit", 400)
                    if closed:
                        raise RemoteProtocolError("connection closed in the middle of a chunk")
                    return NEED_DATA
                line = bytes(buf[:idx])
                if line.endswith(b"\r"):
                    line = line[:-1]
                del buf[:idx + 1]
                size_part = line.split(b";", 1)[0]
                if not _HEX_RE.fullmatch(size_part):
                    raise RemoteProtocolError("invalid chunk-size line")
                size = int(size_part.decode("ascii"), 16)
                if size == 0:
                    body.chunk_state = "trailer"
                else:
                    body.chunk_state = "data"
                    body.chunk_remaining = size
                    body.chunk_start = True
                continue
            if body.chunk_state == "data":
                if not buf:
                    if closed:
                        raise RemoteProtocolError("connection closed in the middle of a chunk")
                    return NEED_DATA
                n = min(body.chunk_remaining, len(buf))
                data = bytes(buf[:n])
                del buf[:n]
                body.chunk_remaining -= n
                start = body.chunk_start
                body.chunk_start = False
                end = body.chunk_remaining == 0
                if end:
                    body.chunk_state = "crlf"
                return Data(data=data, chunk_start=start, chunk_end=end)
            if body.chunk_state == "crlf":
                if len(buf) >= 2:
                    if bytes(buf[:2]) != b"\r\n":
                        raise RemoteProtocolError("chunk data not followed by CRLF")
                    del buf[:2]
                    body.chunk_state = "size"
                    continue
                if buf and buf[0] != 13:
                    raise RemoteProtocolError("chunk data not followed by CRLF")
                if closed:
                    raise RemoteProtocolError("connection closed in the middle of a chunk")
                return NEED_DATA
            # trailer section after the zero-size chunk
            head = _split_head(buf)
            if head is None:
                if len(buf) > self._max_incomplete:
                    raise RemoteProtocolError("trailer block exceeds size limit", 431)
                if closed:
                    raise RemoteProtocolError("connection closed in the middle of trailers")
                return NEED_DATA
            lines, consumed = head
            try:
                trailers = EndOfMessage(headers=_parse_header_lines(lines))
            except LocalProtocolError as exc:
                raise RemoteProtocolError(str(exc), exc.error_status_hint) from None
            del buf[:consumed]
            return trailers

    # --------------------------------------------------------- encoding

    def _encode(self, ev, passthrough):
        """Return ``(pieces, new_body_or_None, ka_off)`` for an event we are sending."""
        et = type(ev)
        if et is Request:
            return self._encode_request(ev)
        if et is InformationalResponse:
            return self._encode_informational(ev)
        if et is Response:
            return self._encode_response(ev)
        if et is Data:
            return self._encode_data(ev, passthrough), None, False
        if et is EndOfMessage:
            return self._encode_eom(ev), None, False
        return [], None, False

    def _encode_request(self, ev):
        if ev.http_version != b"1.1":
            raise LocalProtocolError("only HTTP/1.1 requests can be sent")
        items = ev.headers.raw_items()
        host = [i for i in items if i[0].lower() == b"host"]
        rest = [i for i in items if i[0].lower() != b"host"]
        wire = ev.method + b" " + ev.target + b" HTTP/1.1\r\n" + _serialize(host + rest) + b"\r\n"
        return [wire], _request_body(ev), _request_ka_off(ev)

    def _encode_informational(self, ev):
        if ev.http_version != b"1.1":
            raise LocalProtocolError("only HTTP/1.1 responses can be sent")
        wire = _status_line(ev.status_code, ev.reason) + _serialize(ev.headers.raw_items()) + b"\r\n"
        return [wire], None, False

    def _encode_response(self, ev):
        if ev.http_version != b"1.1":
            raise LocalProtocolError("only HTTP/1.1 responses can be sent")
        if self._accepts(ev):
            # Accepted protocol switch: no framing, no body, no connection changes.
            wire = _status_line(ev.status_code, ev.reason) + _serialize(ev.headers.raw_items()) + b"\r\n"
            return [wire], None, False

        empty = self._request_method == b"HEAD" or ev.status_code in (204, 304)
        peer11 = self._their_http_version == b"1.1"
        items = list(ev.headers.raw_items())
        has_te = _is_chunked(ev.headers)
        cl = _content_length(ev.headers)

        if has_te:  # Transfer-Encoding wins over Content-Length for responses
            if peer11:
                kind = "chunked"
                items = _drop(items, b"content-length")
            else:
                kind = "eof"
                items = _drop(items, b"transfer-encoding", b"content-length")
        elif cl is not None:
            kind = "length"
        else:
            if peer11:
                kind = "chunked"
                items.append((b"Transfer-Encoding", b"chunked"))
            else:
                kind = "eof"

        if empty:
            body = _Body("length", 0)
            if cl == 0:
                items = _drop(items, b"content-length")
        elif kind == "length":
            body = _Body("length", cl)
        elif kind == "chunked":
            body = _Body("chunked")
        else:
            body = _Body("eof")

        ka_off = (self._ka_disabled or not peer11
                  or _has_token(ev.headers, b"connection", b"close") or kind == "eof")
        if ka_off:
            items = _rewrite_connection(items)
        wire = _status_line(ev.status_code, ev.reason) + _serialize(items) + b"\r\n"
        return [wire], body, ka_off

    def _encode_data(self, ev, passthrough):
        body = self._bodies[self._our_role]
        if body is None:
            raise LocalProtocolError("no message body is open")
        n = _payload_len(ev.data)
        if body.kind == "length":
            if n > body.remaining:
                raise LocalProtocolError("data exceeds the declared Content-Length")
            piece = _payload_piece(ev.data, passthrough) if n else None
            body.remaining -= n
            return [] if piece is None else [piece]
        if body.kind == "chunked":
            if n == 0:
                return []
            piece = _payload_piece(ev.data, passthrough)
            return [b"%x\r\n" % n, piece, b"\r\n"]
        if n == 0:
            return []
        return [_payload_piece(ev.data, passthrough)]

    def _encode_eom(self, ev):
        body = self._bodies[self._our_role]
        if body is None:
            raise LocalProtocolError("no message body is open")
        if len(ev.headers) and (body.kind != "chunked" or self._their_http_version == b"1.0"):
            raise LocalProtocolError("trailing headers need chunked framing to a non-HTTP/1.0 peer")
        if body.kind == "length":
            if body.remaining:
                raise LocalProtocolError("message ended before its Content-Length was sent")
            return []
        if body.kind == "eof":
            return []
        return [b"0\r\n" + _serialize(ev.headers.raw_items()) + b"\r\n"]

    # ------------------------------------------------------- state logic

    def _accepts(self, ev):
        """Whether ``ev`` (a server event) accepts the pending protocol switch."""
        kinds = self._switch_kinds
        if not kinds or self._switch_resolved:
            return False
        et = type(ev)
        if et is Response:
            return ev.status_code == 200 and b"connect" in kinds
        if et is InformationalResponse:
            return ev.status_code == 101 and b"upgrade" in kinds
        return False

    def _next_states(self, role, ev, exc_cls):
        """Return the state dict after ``role`` sends or pulls ``ev``; raise if illegal."""
        cur_states = self._states
        cur = cur_states[role]
        et = type(ev)
        if cur is ERROR:
            raise exc_cls("connection is in the ERROR state")
        target = _TRANSITIONS[role].get(cur, {}).get(et)
        accepted = (role is SERVER and et in (Response, InformationalResponse)
                    and self._accepts(ev))
        if accepted:
            target = SWITCHED_PROTOCOL
        elif (role is CLIENT and et is EndOfMessage and cur is SEND_BODY
              and self._switch_kinds and not self._switch_resolved):
            target = MIGHT_SWITCH_PROTOCOL  # proposing request finished; await answer
        if target is None:
            raise exc_cls("%s event is not allowed while %s side is %s"
                          % (et.__name__, role, cur))
        new = dict(cur_states)
        new[role] = target
        if accepted:
            new[other_role(role)] = SWITCHED_PROTOCOL
        else:
            if et is Request and role is CLIENT and new[SERVER] is IDLE:
                new[SERVER] = SEND_RESPONSE
            if (role is SERVER and et is Response
                    and cur_states[CLIENT] is MIGHT_SWITCH_PROTOCOL):
                new[CLIENT] = DONE  # denial: client's proposal is answered
        return new

    def _commit(self, role, ev, new_states, pulled, body=None, ka_off=False):
        et = type(ev)
        old_states = self._states
        accepted = et in (Response, InformationalResponse) and self._accepts(ev)
        denial = (et is Response and not accepted
                  and old_states[CLIENT] is MIGHT_SWITCH_PROTOCOL)
        self._states = new_states

        if et is Request:
            self._request_method = ev.method
            self._bodies[CLIENT] = body
            if ka_off:
                self._ka_disabled = True
            if ev.http_version == b"1.1" and _has_token(ev.headers, b"expect", b"100-continue"):
                self._client_waiting = True
                if self._our_role is SERVER and pulled and \
                        _has_token_exact(ev.headers, b"expect", b"100-continue"):
                    self._they_waiting = True
            kinds = set()
            if ev.method == b"CONNECT":
                kinds.add(b"connect")
            if _has_header(ev.headers, b"upgrade"):
                kinds.add(b"upgrade")
            self._switch_kinds = frozenset(kinds)
            self._switch_resolved = False
            if pulled:
                self._their_http_version = ev.http_version
        elif et is Response or et is InformationalResponse:
            self._client_waiting = False
            self._they_waiting = False
            if accepted or denial:
                self._switch_resolved = True
            if et is Response:
                self._bodies[SERVER] = body
                if ka_off:
                    self._ka_disabled = True
            if pulled:
                self._their_http_version = ev.http_version
        elif et is EndOfMessage:
            self._bodies[role] = None

        if role is CLIENT and self._our_role is SERVER and et in (Data, EndOfMessage):
            self._they_waiting = False

    def _fire(self):
        """Apply state-triggered transitions until nothing changes."""
        s = self._states
        while True:
            changed = False
            for r, o in ((CLIENT, SERVER), (SERVER, CLIENT)):
                if s[r] is DONE and (self._ka_disabled or s[o] is ERROR or s[o] is CLOSED):
                    s[r] = MUST_CLOSE
                    changed = True
                elif s[r] is IDLE and s[o] is CLOSED:
                    s[r] = MUST_CLOSE
                    changed = True
            if not changed:
                break
