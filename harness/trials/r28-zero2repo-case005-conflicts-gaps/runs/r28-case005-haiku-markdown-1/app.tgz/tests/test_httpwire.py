import unittest

import httpwire
from httpwire import (
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
    Connection,
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    LocalProtocolError,
    RemoteProtocolError,
    Request,
    Response,
)
from httpwire._errors import ReceiveClosedError


def get(target=b"/", extra=(), version=b"1.1"):
    headers = list(extra)
    if version == b"1.1" and not any(h[0].lower() == b"host" for h in headers):
        headers.insert(0, (b"Host", b"h"))
    return Request(method=b"GET", target=target, headers=headers, http_version=version)


def serve_one(client, server, request, response, body=b""):
    """Run one request/response with no body; return the server connection's pulled events."""
    server.receive_data(client.send(request))
    client.send(EndOfMessage())
    pulled = [server.next_event(), server.next_event()]
    server.send(response)
    if body:
        server.send(Data(data=body))
    server.send(EndOfMessage())
    return pulled


class EventTests(unittest.TestCase):
    def test_defaults_and_bytes(self):
        r = Request(method="GET", target="/", headers=[("Host", "x")])
        self.assertEqual(r.http_version, b"1.1")
        self.assertEqual(r.method, b"GET")
        self.assertIsInstance(r.target, bytes)
        self.assertEqual(list(r.headers), [(b"host", b"x")])
        self.assertEqual(r.headers.raw_items(), [(b"Host", b"x")])

    def test_http11_request_needs_host(self):
        with self.assertRaises(LocalProtocolError):
            Request(method=b"GET", target=b"/", headers=[])
        Request(method=b"GET", target=b"/", headers=[], http_version=b"1.0")

    def test_duplicate_host_refused_any_version(self):
        with self.assertRaises(LocalProtocolError):
            Request(method=b"GET", target=b"/", headers=[(b"Host", b"a"), (b"host", b"b")],
                    http_version=b"1.0")

    def test_status_ranges(self):
        InformationalResponse(status_code=100)
        with self.assertRaises(LocalProtocolError):
            InformationalResponse(status_code=200)
        Response(status_code=200)
        with self.assertRaises(LocalProtocolError):
            Response(status_code=1000)
        with self.assertRaises(LocalProtocolError):
            Response(status_code="200")
        self.assertEqual(Response(status_code=200).reason, b"")

    def test_content_length_collapse_and_conflict(self):
        r = EndOfMessage(headers=[("Content-Length", "5"), ("content-length", "5, 5")])
        self.assertEqual(list(r.headers), [(b"content-length", b"5")])
        with self.assertRaises(LocalProtocolError):
            EndOfMessage(headers=[("Content-Length", "5"), ("Content-Length", "6")])
        with self.assertRaises(LocalProtocolError):
            EndOfMessage(headers=[("Content-Length", "+5")])
        with self.assertRaises(LocalProtocolError):
            EndOfMessage(headers=[("Content-Length", "1" * 17)])

    def test_transfer_encoding_rules(self):
        r = EndOfMessage(headers=[("Transfer-Encoding", "ChUnKeD")])
        self.assertEqual(list(r.headers), [(b"transfer-encoding", b"chunked")])
        with self.assertRaises(LocalProtocolError) as cm:
            EndOfMessage(headers=[("Transfer-Encoding", "gzip, chunked")])
        self.assertEqual(cm.exception.error_status_hint, 501)
        with self.assertRaises(LocalProtocolError) as cm:
            EndOfMessage(headers=[("Transfer-Encoding", "chunked"), ("Transfer-Encoding", "chunked")])
        self.assertEqual(cm.exception.error_status_hint, 501)

    def test_header_value_rules(self):
        EndOfMessage(headers=[("X-A", "a\tb")])
        with self.assertRaises(LocalProtocolError):
            EndOfMessage(headers=[("X-A", " a")])
        with self.assertRaises(LocalProtocolError):
            EndOfMessage(headers=[("X-A", "a\x0c")])
        with self.assertRaises(LocalProtocolError):
            EndOfMessage(headers=[("bad name", "a")])

    def test_target_and_method(self):
        with self.assertRaises(LocalProtocolError):
            Request(method=b"G E", target=b"/", headers=[(b"Host", b"x")])
        with self.assertRaises(LocalProtocolError):
            Request(method=b"GET", target=b"/a b", headers=[(b"Host", b"x")])

    def test_data_and_close_fields(self):
        d = Data(data=b"abc", chunk_start=1, chunk_end=0)
        self.assertIs(d.chunk_start, True)
        self.assertIs(d.chunk_end, False)
        self.assertIsInstance(ConnectionClosed(), ConnectionClosed)


class ConnectionBasics(unittest.TestCase):
    def test_roles_and_initial_states(self):
        c = Connection(CLIENT)
        self.assertIs(c.our_role, CLIENT)
        self.assertIs(c.their_role, SERVER)
        self.assertIs(c.our_state, IDLE)
        self.assertIs(c.states[CLIENT], IDLE)
        self.assertIs(c.states[SERVER], IDLE)
        self.assertIsNone(c.their_http_version)
        with self.assertRaises(Exception):
            Connection("client")

    def test_request_wire_and_server_pull(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        wire = c.send(Request(method=b"POST", target=b"/x",
                              headers=[(b"Content-Length", b"3"), (b"Host", b"h")]))
        self.assertEqual(wire, b"POST /x HTTP/1.1\r\nHost: h\r\nContent-Length: 3\r\n\r\n")
        self.assertIs(c.our_state, SEND_BODY)
        self.assertIsNone(c.their_http_version)
        s.receive_data(wire)
        self.assertIsInstance(s.next_event(), Request)
        self.assertEqual(s.their_http_version, b"1.1")
        self.assertIs(s.our_state, SEND_RESPONSE)
        self.assertIs(s.their_state, SEND_BODY)
        c.send(Data(data=b"abc"))
        c.send(EndOfMessage())
        s.receive_data(b"abc")
        self.assertEqual(s.next_event(), Data(data=b"abc"))
        self.assertIsInstance(s.next_event(), EndOfMessage)
        self.assertIs(s.their_state, DONE)

    def test_feed_does_not_change_state(self):
        s = Connection(SERVER)
        raw = b"GET / HTTP/1.1\r\nHost: x\r\n\r\n"
        s.receive_data(raw)
        self.assertIs(s.their_state, IDLE)
        self.assertIsNone(s.their_http_version)
        self.assertEqual(s.trailing_data, (raw, False))

    def test_start_line_with_space_fails_immediately(self):
        s = Connection(SERVER)
        s.receive_data(b" GET")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()
        self.assertIs(s.their_state, ERROR)

    def test_lone_lf_and_obs_fold_accepted(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\nHost: x\nX-Long: a\n   b\n\n")
        ev = s.next_event()
        self.assertEqual(list(ev.headers)[1], (b"x-long", b"a b"))

    def test_status_line_without_reason(self):
        c = Connection(CLIENT)
        c.send(get())
        c.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 204\r\n\r\n")
        ev = c.next_event()
        self.assertIsInstance(ev, Response)
        self.assertEqual(ev.reason, b"")

    def test_bytes_after_receive_close_refused(self):
        s = Connection(SERVER)
        s.receive_data(b"")
        with self.assertRaises(ReceiveClosedError):
            s.receive_data(b"x")
        self.assertIs(s.trailing_data[1], True)

    def test_header_casing_preserved_on_wire(self):
        c = Connection(CLIENT)
        wire = c.send(Request(method=b"GET", target=b"/", headers=[(b"X-Foo", b"1"), (b"Host", b"h")]))
        self.assertEqual(wire, b"GET / HTTP/1.1\r\nHost: h\r\nX-Foo: 1\r\n\r\n")


class FramingTests(unittest.TestCase):
    def test_chunked_response_roundtrip(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        serve_one_head = [None]
        s.receive_data(c.send(get()))
        c.send(EndOfMessage())
        s.next_event()
        s.next_event()
        out = s.send(Response(status_code=200, headers=[(b"Transfer-Encoding", b"chunked")]))
        self.assertEqual(out, b"HTTP/1.1 200 \r\nTransfer-Encoding: chunked\r\n\r\n")
        out += s.send(Data(data=b"hello"))
        out += s.send(Data(data=b""))
        out += s.send(EndOfMessage(headers=[(b"X-T", b"1")]))
        self.assertTrue(out.endswith(b"5\r\nhello\r\n0\r\nX-T: 1\r\n\r\n"), out)
        c.receive_data(out)
        evs = [c.next_event() for _ in range(3)]
        self.assertIsInstance(evs[0], Response)
        self.assertEqual(evs[1], Data(data=b"hello", chunk_start=True, chunk_end=True))
        self.assertIsInstance(evs[2], EndOfMessage)
        self.assertEqual(list(evs[2].headers), [(b"x-t", b"1")])
        self.assertIs(serve_one_head[0], None)

    def test_chunked_data_in_pieces(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n")
        s.next_event()
        s.receive_data(b"4\r\nab")
        self.assertEqual(s.next_event(), Data(data=b"ab", chunk_start=True, chunk_end=False))
        self.assertIs(s.next_event(), NEED_DATA)
        s.receive_data(b"cd\r\n0;ext=1\r\n\r\n")
        self.assertEqual(s.next_event(), Data(data=b"cd", chunk_start=False, chunk_end=True))
        self.assertIsInstance(s.next_event(), EndOfMessage)

    def test_chunk_size_whitespace_refused(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n1 \r\n")
        s.next_event()
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    def test_chunk_missing_crlf_refused(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n1\r\nabX")
        s.next_event()
        self.assertIsInstance(s.next_event(), Data)
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    def test_content_length_body_and_eom(self):
        s = Connection(SERVER)
        c = Connection(CLIENT)
        s.receive_data(c.send(Request(method=b"PUT", target=b"/",
                                      headers=[(b"Host", b"h"), (b"Content-Length", b"4")])))
        self.assertEqual(c.send(Data(data=b"ab")), b"ab")
        self.assertEqual(c.send(Data(data=b"cd")), b"cd")
        with self.assertRaises(LocalProtocolError):
            c.send(Data(data=b"e"))
        self.assertIs(c.our_state, ERROR)

    def test_send_eom_before_length_refused(self):
        c = Connection(CLIENT)
        c.send(Request(method=b"PUT", target=b"/", headers=[(b"Host", b"h"), (b"Content-Length", b"4")]))
        with self.assertRaises(LocalProtocolError):
            c.send(EndOfMessage())
        self.assertIs(c.our_state, ERROR)

    def test_pulled_content_length_eom_after_last_byte(self):
        s = Connection(SERVER)
        s.receive_data(b"PUT / HTTP/1.1\r\nHost: h\r\nContent-Length: 4\r\n\r\nabcd")
        s.next_event()
        self.assertEqual(s.next_event(), Data(data=b"abcd"))
        self.assertIsInstance(s.next_event(), EndOfMessage)

    def test_passthrough_piece_identity(self):
        class Blob:
            def __len__(self):
                return 3

        blob = Blob()
        c = Connection(CLIENT)
        c.send(Request(method=b"PUT", target=b"/", headers=[(b"Host", b"h"), (b"Content-Length", b"3")]))
        pieces = c.send_with_data_passthrough(Data(data=blob))
        self.assertIs(pieces[0], blob)
        c2 = Connection(CLIENT)
        c2.send(Request(method=b"PUT", target=b"/", headers=[(b"Host", b"h"), (b"Content-Length", b"3")]))
        with self.assertRaises(LocalProtocolError):
            c2.send(Data(data=blob))  # plain send cannot encode a non-bytes payload

    def test_passthrough_chunked_pieces(self):
        class Blob:
            def __len__(self):
                return 2

        blob = Blob()
        c = Connection(CLIENT)
        c.send(Request(method=b"PUT", target=b"/", headers=[(b"Host", b"h"), (b"Transfer-Encoding", b"chunked")]))
        pieces = c.send_with_data_passthrough(Data(data=blob))
        self.assertEqual(pieces[0], b"2\r\n")
        self.assertIs(pieces[1], blob)
        self.assertEqual(pieces[2], b"\r\n")

    def test_http10_request_gets_close_delimited_response(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.0\r\n\r\n")
        s.next_event()
        s.next_event()
        wire = s.send(Response(status_code=200))
        self.assertEqual(wire, b"HTTP/1.1 200 \r\nConnection: close\r\n\r\n")
        self.assertEqual(s.send(Data(data=b"body")), b"body")
        self.assertEqual(s.send(EndOfMessage()), b"")
        self.assertIs(s.our_state, MUST_CLOSE)
        self.assertIs(s.their_state, MUST_CLOSE)

    def test_unknown_peer_response_is_close_delimited(self):
        s = Connection(SERVER)
        wire = s.send(Response(status_code=408, headers=[(b"Content-Length", b"0")]))
        self.assertEqual(wire, b"HTTP/1.1 408 \r\nContent-Length: 0\r\nConnection: close\r\n\r\n")
        self.assertIs(s.our_state, SEND_BODY)

    def test_unknown_peer_response_without_framing(self):
        s = Connection(SERVER)
        wire = s.send(Response(status_code=503))
        self.assertEqual(wire, b"HTTP/1.1 503 \r\nConnection: close\r\n\r\n")

    def test_head_response_has_no_body(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        s.receive_data(c.send(Request(method=b"HEAD", target=b"/", headers=[(b"Host", b"h")])))
        c.send(EndOfMessage())
        s.next_event()
        s.next_event()
        wire = s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
        self.assertEqual(wire, b"HTTP/1.1 200 \r\n\r\n")
        self.assertEqual(s.send(EndOfMessage()), b"")
        self.assertIs(s.our_state, DONE)

    def test_head_response_pulled_is_empty(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        req = Request(method=b"HEAD", target=b"/", headers=[(b"Host", b"h")])
        s.receive_data(c.send(req))
        c.send(EndOfMessage())
        s.next_event()
        s.next_event()
        s.send(Response(status_code=200, headers=[(b"Content-Length", b"100")]))
        s.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 200 \r\nContent-Length: 100\r\n\r\n")
        self.assertIsInstance(c.next_event(), Response)
        self.assertIsInstance(c.next_event(), EndOfMessage)
        self.assertIs(c.their_state, DONE)

    def test_empty_status_responses_drop_body(self):
        s = Connection(SERVER)
        c = Connection(CLIENT)
        s.receive_data(c.send(get()))
        c.send(EndOfMessage())
        s.next_event()
        s.next_event()
        self.assertEqual(s.send(Response(status_code=204, headers=[(b"Content-Length", b"0")])),
                         b"HTTP/1.1 204 \r\n\r\n")
        with self.assertRaises(LocalProtocolError):
            s.send(Data(data=b"x"))


class KeepAliveTests(unittest.TestCase):
    def _cycle(self, c, s):
        s.receive_data(c.send(get()))
        c.send(EndOfMessage())
        s.next_event()
        s.next_event()
        s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
        s.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 200 \r\nContent-Length: 0\r\n\r\n")
        c.next_event()
        c.next_event()

    def test_reuse(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        self._cycle(c, s)
        self.assertIs(c.states[CLIENT], DONE)
        self.assertIs(s.states[SERVER], DONE)
        c.start_next_cycle()
        s.start_next_cycle()
        self.assertIs(c.states[CLIENT], IDLE)
        self.assertIs(s.states[SERVER], IDLE)
        self._cycle(c, s)

    def test_pipelined_request_paused_until_next_cycle(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        s.receive_data(c.send(get()))
        c.send(EndOfMessage())
        s.next_event()
        s.next_event()
        s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
        s.send(EndOfMessage())
        pipelined = b"GET /2 HTTP/1.1\r\nHost: h\r\n\r\n"
        s.receive_data(pipelined)
        self.assertIs(s.next_event(), PAUSED)
        self.assertIs(s.next_event(), PAUSED)
        self.assertEqual(s.trailing_data[0], pipelined)
        c.receive_data(b"HTTP/1.1 200 \r\nContent-Length: 0\r\n\r\n")
        c.next_event()
        c.next_event()
        c.start_next_cycle()
        s.start_next_cycle()
        self.assertIsInstance(s.next_event(), Request)

    def test_bytes_after_pipelined_need_data_then_paused(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        s.receive_data(c.send(get()))
        c.send(EndOfMessage())
        s.next_event()
        s.next_event()
        s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
        s.send(EndOfMessage())
        self.assertIs(s.next_event(), NEED_DATA)
        s.receive_data(b"GET /2")
        self.assertIs(s.next_event(), PAUSED)

    def test_connection_close_request_forces_must_close(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        s.receive_data(c.send(get(extra=[(b"Connection", b"Close")])))
        c.send(EndOfMessage())
        self.assertIs(c.our_state, MUST_CLOSE)
        s.next_event()
        s.next_event()
        wire = s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
        self.assertIn(b"Connection: close", wire)
        s.send(EndOfMessage())
        self.assertIs(s.our_state, MUST_CLOSE)

    def test_http10_cannot_restart(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.0\r\n\r\n")
        s.next_event()
        s.next_event()
        s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
        s.send(EndOfMessage())
        self.assertIs(s.our_state, MUST_CLOSE)
        with self.assertRaises(LocalProtocolError):
            s.start_next_cycle()
        self.assertIs(s.our_state, MUST_CLOSE)

    def test_second_request_refused_and_errors(self):
        c = Connection(CLIENT)
        c.send(get())
        with self.assertRaises(LocalProtocolError):
            c.send(get())
        self.assertIs(c.our_state, ERROR)
        with self.assertRaises(LocalProtocolError):
            c.send(EndOfMessage())

    def test_start_next_cycle_refused_is_harmless(self):
        c = Connection(CLIENT)
        c.send(get())
        with self.assertRaises(LocalProtocolError):
            c.start_next_cycle()
        self.assertIs(c.our_state, SEND_BODY)


class ErrorTests(unittest.TestCase):
    def test_remote_error_is_unrecoverable_but_send_still_works(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\n Bad: x\r\nHost: h\r\n\r\n")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()
        self.assertIs(s.their_state, ERROR)
        with self.assertRaises(RemoteProtocolError):
            s.next_event()
        wire = s.send(Response(status_code=400, headers=[(b"Content-Length", b"0")]))
        self.assertIn(b"Connection: close", wire)

    def test_incomplete_head_limit_431(self):
        s = Connection(SERVER, 100)
        s.receive_data(b"GET / HTTP/1.1\r\nX-A: " + b"a" * 200)
        with self.assertRaises(RemoteProtocolError) as cm:
            s.next_event()
        self.assertEqual(cm.exception.error_status_hint, 431)

    def test_default_limit_is_8k(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nX: " + b"a" * (9 * 1024))
        with self.assertRaises(RemoteProtocolError) as cm:
            s.next_event()
        self.assertEqual(cm.exception.error_status_hint, 431)

    def test_local_error_sets_our_error_and_refuses_later_sends(self):
        c = Connection(CLIENT)
        with self.assertRaises(LocalProtocolError):
            c.send(Response(status_code=200))
        self.assertIs(c.our_state, ERROR)
        with self.assertRaises(LocalProtocolError):
            c.send(get())

    def test_send_failed_marks_error(self):
        c = Connection(CLIENT)
        c.send(get())
        c.send(EndOfMessage())
        c.send_failed()
        self.assertIs(c.our_state, ERROR)

    def test_connection_closed_flow(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        s.receive_data(b"")
        self.assertIsInstance(s.next_event(), ConnectionClosed)
        self.assertIs(s.their_state, CLOSED)
        self.assertIsInstance(s.next_event(), ConnectionClosed)
        self.assertEqual(c.send(ConnectionClosed()), b"")
        self.assertIs(c.our_state, CLOSED)

    def test_mid_message_close_is_remote_error(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nHost")
        self.assertIs(s.next_event(), NEED_DATA)
        s.receive_data(b"")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    def test_close_delimited_body_ends_with_eom_then_close(self):
        c = Connection(CLIENT)
        c.send(get())
        c.send(EndOfMessage())
        c.receive_data(b"HTTP/1.0 200 OK\r\n\r\nhello")
        self.assertIsInstance(c.next_event(), Response)
        self.assertEqual(c.next_event(), Data(data=b"hello"))
        self.assertIs(c.next_event(), NEED_DATA)
        c.receive_data(b"")
        self.assertIsInstance(c.next_event(), EndOfMessage)
        self.assertIsInstance(c.next_event(), ConnectionClosed)
        self.assertIs(c.our_state, MUST_CLOSE)

    def test_send_connection_closed_in_wrong_state(self):
        c = Connection(CLIENT)
        c.send(get())
        with self.assertRaises(LocalProtocolError):
            c.send(ConnectionClosed())


class SwitchAndContinueTests(unittest.TestCase):
    def test_100_continue_flags(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        s.receive_data(c.send(Request(method=b"PUT", target=b"/",
                                      headers=[(b"Host", b"h"), (b"Content-Length", b"1"),
                                               (b"Expect", b"100-continue")])))
        self.assertTrue(c.client_is_waiting_for_100_continue)
        self.assertFalse(c.they_are_waiting_for_100_continue)
        s.next_event()
        self.assertTrue(s.client_is_waiting_for_100_continue)
        self.assertTrue(s.they_are_waiting_for_100_continue)
        s.send(InformationalResponse(status_code=100))
        self.assertFalse(s.they_are_waiting_for_100_continue)
        c.receive_data(b"HTTP/1.1 100 \r\n\r\n")
        self.assertIsInstance(c.next_event(), InformationalResponse)
        self.assertFalse(c.client_is_waiting_for_100_continue)
        self.assertIs(c.our_state, SEND_BODY)

    def test_connect_accepted(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        s.receive_data(c.send(Request(method=b"CONNECT", target=b"example:443",
                                      headers=[(b"Host", b"example:443")])))
        c.send(EndOfMessage())
        self.assertIs(c.our_state, MIGHT_SWITCH_PROTOCOL)
        s.next_event()
        self.assertIsInstance(s.next_event(), EndOfMessage)
        self.assertIs(s.their_state, MIGHT_SWITCH_PROTOCOL)
        s.receive_data(b"tunnel-bytes")
        self.assertIs(s.next_event(), PAUSED)
        wire = s.send(Response(status_code=200))
        self.assertEqual(wire, b"HTTP/1.1 200 \r\n\r\n")
        self.assertIs(s.our_state, SWITCHED_PROTOCOL)
        c.receive_data(wire)
        self.assertIsInstance(c.next_event(), Response)
        self.assertIs(c.our_state, SWITCHED_PROTOCOL)
        self.assertIs(c.their_state, SWITCHED_PROTOCOL)
        self.assertEqual(s.trailing_data, (b"tunnel-bytes", False))
        with self.assertRaises(LocalProtocolError):
            s.send(Response(status_code=200))
        with self.assertRaises(LocalProtocolError):
            c.send(EndOfMessage())

    def test_connect_non_200_2xx_is_denial(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        s.receive_data(c.send(Request(method=b"CONNECT", target=b"a:1", headers=[(b"Host", b"a:1")])))
        c.send(EndOfMessage())
        s.next_event()
        s.next_event()
        s.send(Response(status_code=204, headers=[(b"Content-Length", b"0")]))
        self.assertIs(s.our_state, SEND_BODY)
        s.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 204 \r\nContent-Length: 0\r\n\r\n")
        self.assertIsInstance(c.next_event(), Response)
        self.assertIs(c.our_state, DONE)
        self.assertIs(s.our_state, DONE)

    def test_connect_denied_keeps_http(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        s.receive_data(c.send(Request(method=b"CONNECT", target=b"a:1", headers=[(b"Host", b"a:1")])))
        c.send(EndOfMessage())
        s.next_event()
        s.next_event()
        s.send(Response(status_code=403, headers=[(b"Content-Length", b"0")]))
        s.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 403 \r\nContent-Length: 0\r\n\r\n")
        self.assertIsInstance(c.next_event(), Response)
        self.assertIsInstance(c.next_event(), EndOfMessage)
        self.assertIs(c.our_state, DONE)
        self.assertIs(s.our_state, DONE)

    def test_upgrade_101_accepted(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        s.receive_data(c.send(get(target=b"/ws", extra=[(b"Upgrade", b"websocket"),
                                                         (b"Connection", b"Upgrade")])))
        c.send(EndOfMessage())
        s.next_event()
        s.next_event()
        wire = s.send(InformationalResponse(status_code=101, headers=[(b"Upgrade", b"websocket")]))
        self.assertIs(s.our_state, SWITCHED_PROTOCOL)
        c.receive_data(wire)
        self.assertIsInstance(c.next_event(), InformationalResponse)
        self.assertIs(c.our_state, SWITCHED_PROTOCOL)

    def test_pending_switch_blocks_restart(self):
        c = Connection(CLIENT)
        c.send(get(extra=[(b"Upgrade", b"x")]))
        c.send(EndOfMessage())
        with self.assertRaises(LocalProtocolError):
            c.start_next_cycle()
        self.assertIs(c.our_state, MIGHT_SWITCH_PROTOCOL)


class PublicSurfaceTests(unittest.TestCase):
    def test_root_names(self):
        for name in ["CLIENT", "CLOSED", "Connection", "ConnectionClosed", "Data", "DONE",
                     "EndOfMessage", "ERROR", "IDLE", "InformationalResponse",
                     "LocalProtocolError", "MIGHT_SWITCH_PROTOCOL", "MUST_CLOSE", "NEED_DATA",
                     "PAUSED", "RemoteProtocolError", "Request", "Response", "SEND_BODY",
                     "SEND_RESPONSE", "SERVER", "SWITCHED_PROTOCOL"]:
            self.assertTrue(hasattr(httpwire, name), name)
        self.assertNotEqual(CLIENT, SERVER)
        self.assertFalse(issubclass(LocalProtocolError, RemoteProtocolError))
        self.assertFalse(issubclass(RemoteProtocolError, LocalProtocolError))
        self.assertIsNot(NEED_DATA, PAUSED)


if __name__ == "__main__":
    unittest.main()
