"""Exception classes for httpwire (FP-05, Interface Contract "Errors")."""

# spec: N-000290 N-000291 N-000326 N-000472 N-000473 N-000292 N-000293 N-000294 N-000295 N-000296


# spec: N-000020 N-000031 N-000058
class ProtocolError(Exception):
    """Common base of the two protocol-error kinds.

    ``LocalProtocolError`` and ``RemoteProtocolError`` both derive from this
    class, but neither derives from the other (spec N-000290, N-000291).
    """

    def __init__(self, message="", error_status_hint=400):
        super().__init__(message)
        # spec: N-000472 -- exactly of type int
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(ProtocolError):
    """The integrator's own event or send violated the protocol."""


class RemoteProtocolError(ProtocolError):
    """The peer's bytes violated the protocol."""
