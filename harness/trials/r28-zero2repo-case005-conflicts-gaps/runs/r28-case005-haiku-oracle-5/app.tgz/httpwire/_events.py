"""The six HTTP event types (FP-01, Interface Contract "Events")."""

from ._errors import LocalProtocolError
from ._util import (Headers, check_reason, check_target, check_token,
                    check_version, normalize_headers, to_bytes)

# spec: N-000070 N-000071 -- six distinct event kinds


# spec: N-000087 N-000089 N-000094 N-000096
def _items_of(headers):
    """Normalized (raw, lname, value) triples for a headers argument."""
    if headers is None:
        headers = ()
    return normalize_headers(headers)


# spec: N-000079 N-000080 N-000112 N-000113 N-000398
def _status(status_code, low, high):
    # spec: N-000112 N-000113 -- status must be an integer in range
    if not isinstance(status_code, int):
        raise LocalProtocolError("status code must be an integer")
    status = int(status_code)
    if not (low <= status < high):
        raise LocalProtocolError("status code %d out of range" % status)
    return status


# spec: N-000450 N-000451 N-000466 N-000070 N-000071
# spec: N-000101 N-000102 N-000103 N-000297 N-000298 N-000299 N-000020
class _Event(object):
    __slots__ = ()
    _fields = ()

    def __eq__(self, other):
        if type(other) is not type(self):
            return NotImplemented
        return all(_same(getattr(self, f), getattr(other, f)) for f in self._fields)

    def __ne__(self, other):
        result = self.__eq__(other)
        return result if result is NotImplemented else not result

    __hash__ = None

    def __repr__(self):
        parts = ", ".join("%s=%r" % (f, getattr(self, f)) for f in self._fields)
        return "%s(%s)" % (type(self).__name__, parts)


def _same(a, b):
    if isinstance(a, Headers) and isinstance(b, Headers):
        return list(a) == list(b)
    return a == b


# spec: N-000072 N-000073 N-000074 N-000076 N-000077 N-000078 N-000104 N-000105 N-000452
class Request(_Event):
    """Start of an HTTP request. spec: N-000072..N-000078, N-000104..N-000111."""

    __slots__ = ("method", "target", "headers", "http_version")
    _fields = ("method", "target", "headers", "http_version")

    def __init__(self, method, target, headers, http_version=b"1.1"):
        method = to_bytes(method, "method")
        check_token(method, "method")
        target = to_bytes(target, "target")
        check_target(target)
        http_version = to_bytes(http_version, "http_version")
        check_version(http_version)
        items = _items_of(headers)
        host_count = sum(1 for item in items if item[1] == b"host")
        # spec: N-000077 N-000078 N-000104 N-000105
        if host_count > 1:
            raise LocalProtocolError("more than one Host header")
        if host_count == 0 and http_version == b"1.1":
            raise LocalProtocolError("HTTP/1.1 request needs a Host header")
        self.method = method
        self.target = target
        self.headers = Headers(items)
        self.http_version = http_version


# spec: N-000081 N-000082 N-000083 N-000460 N-000461 N-000453 N-000454
class _Response(_Event):
    __slots__ = ("status_code", "headers", "http_version", "reason")
    _fields = ("status_code", "headers", "http_version", "reason")
    _low = 0
    _high = 0

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        status = _status(status_code, self._low, self._high)
        http_version = to_bytes(http_version, "http_version")
        check_version(http_version)
        reason = to_bytes(reason, "reason")
        check_reason(reason)
        self.status_code = status
        self.headers = Headers(_items_of(headers))
        self.http_version = http_version
        self.reason = reason


# spec: N-000079 N-000081 N-000082 N-000453
class InformationalResponse(_Response):
    """HTTP 1xx response. spec: N-000079..N-000083."""

    __slots__ = ()
    _low = 100
    _high = 200


# spec: N-000080 N-000081 N-000082 N-000454
class Response(_Response):
    """Final response (200..999). spec: N-000079..N-000083."""

    __slots__ = ()
    _low = 200
    _high = 1000


def _length_of(payload):
    if isinstance(payload, (bytes, bytearray, memoryview)):
        return memoryview(payload).nbytes
    return len(payload)


# spec: N-000084 N-000455 N-000463 N-000464 N-000465
class Data(_Event):
    """A piece of a message body. spec: N-000084, N-000450..N-000465."""

    __slots__ = ("data", "chunk_start", "chunk_end")
    _fields = ("data", "chunk_start", "chunk_end")

    def __init__(self, data, chunk_start=False, chunk_end=False):
        if isinstance(data, str):
            data = to_bytes(data, "data")
        elif not isinstance(data, (bytes, bytearray, memoryview)):
            if not hasattr(data, "__len__"):
                raise LocalProtocolError("data must be bytes-like or an object with a length")
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)


# spec: N-000085 N-000456 N-000467
class EndOfMessage(_Event):
    """End of a message with optional trailing headers. spec: N-000084..N-000085."""

    __slots__ = ("headers",)
    _fields = ("headers",)

    def __init__(self, headers=None):
        self.headers = Headers(_items_of(headers))


# spec: N-000086 N-000457
class ConnectionClosed(_Event):
    """This party will send no more HTTP data. spec: N-000086."""

    __slots__ = ()
    _fields = ()

    def __init__(self):
        pass


# spec: N-000070 N-000071 N-000434 N-000435 N-000436
EVENT_TYPES = (Request, InformationalResponse, Response, Data, EndOfMessage, ConnectionClosed)
