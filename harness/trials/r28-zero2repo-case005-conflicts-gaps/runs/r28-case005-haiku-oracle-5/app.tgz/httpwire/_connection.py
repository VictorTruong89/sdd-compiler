"""The bring-your-own-I/O connection object (FP-02..FP-07).

Design: one object tracks both roles' states (``CLIENT`` and ``SERVER``).
Every event, whether this side sends it or pulls it from the peer, is run
through the same transition function ``_process``. Sends and pulls differ
only in which exception class a refusal raises and in how bytes are
produced or consumed. Nothing in this module touches a socket.
"""

import re

from ._errors import LocalProtocolError, RemoteProtocolError
from ._events import (ConnectionClosed, Data, EndOfMessage, EVENT_TYPES,
                      InformationalResponse, Request, Response)
from ._sentinels import (CLIENT, CLOSED, DONE, ERROR, IDLE, MIGHT_SWITCH_PROTOCOL,
                         MUST_CLOSE, NEED_DATA, PAUSED, SEND_BODY, SEND_RESPONSE,
                         SERVER, SWITCHED_PROTOCOL)
from ._util import (MAX_CHUNK_SIZE_DIGITS, has_token, pairs_from_lines)

# spec: N-000478..N-000480 -- default incomplete-event size limit (Interface
# Contract, Connection signature). Conflicts with the PRD's 14..18 KiB range;
# see NOTES.md.
DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 8 * 1024

# Body framing kinds
_NONE = "none"
_LENGTH = "length"
_CHUNKED = "chunked"
_CLOSE = "close"

# spec: N-000228 N-000229 N-000230 N-000231 N-000232 N-000067 N-000066
_CHUNK_SIZE_RE = re.compile(rb"([0-9A-Fa-f]+)(?:[ \t]*;[^\r\n]*)?[ \t]*")
_STATUS_CODE_RE = re.compile(rb"[0-9]{3}")
# spec: N-000052 N-000053 N-000054 -- speak only HTTP/1.1; read HTTP/1.0 peers; no HTTP/2
_HTTP_VERSIONS = (b"HTTP/1.1", b"HTTP/1.0")


class _Body(object):
    """Framing of one side's current message body."""

    __slots__ = ("kind", "remaining", "cstate", "chunk_remaining", "chunk_first")

    def __init__(self, kind, remaining=0):
        self.kind = kind
        self.remaining = remaining      # Content-Length bytes left
        self.cstate = "size"            # chunked receive sub-state
        self.chunk_remaining = 0
        self.chunk_first = False


class _Cycle(object):
    """Facts about the current request/response cycle, shared by both roles."""

    __slots__ = ("request_method", "request_version", "response_version",
                 "close_seen", "closedelim", "client_waiting", "proposals")

    def __init__(self):
        self.request_method = None
        self.request_version = None
        self.response_version = None
        self.close_seen = False         # a Connection: close token was sent
        self.closedelim = False         # a close-delimited body is in use
        self.client_waiting = False     # client is waiting for 100-continue
        self.proposals = set()          # pending switch proposals: b"connect", b"upgrade"

    def copy(self):
        dup = _Cycle()
        for name in _Cycle.__slots__:
            setattr(dup, name, getattr(self, name))
        dup.proposals = set(self.proposals)
        return dup


def _other(role):
    return SERVER if role is CLIENT else CLIENT


def _has(items, lname):
    return any(item[1] == lname for item in items)


def _get(items, lname):
    for _raw, name, value in items:
        if name == lname:
            return value
    return None


def _drop(items, lname):
    return [item for item in items if item[1] != lname]


# spec: N-000364 N-000365 N-000366 N-000367 N-000368 N-000369 N-000370 N-000371 N-000372 N-000395 N-000381
def _accepts(proposals, status):
    """Does a response with this status accept a pending switch proposal? (FP-07)"""
    if status == 101:
        return b"upgrade" in proposals
    if 200 <= status < 300:
        return b"connect" in proposals
    return False


# spec: N-000183 N-000184 N-000028
def _request_body(items):
    cl = _get(items, b"content-length")
    if cl is not None:
        return _Body(_LENGTH, int(cl))
    if _has(items, b"transfer-encoding"):
        return _Body(_CHUNKED)
    return _Body(_NONE)


# spec: N-000183 N-000184 N-000028 N-000215 N-000216 N-000217 N-000218
def _response_body(items, status, request_method):
    if status < 200 or status in (204, 304) or request_method == b"HEAD":
        return _Body(_NONE)
    if _has(items, b"transfer-encoding"):
        return _Body(_CHUNKED)
    cl = _get(items, b"content-length")
    if cl is not None:
        return _Body(_LENGTH, int(cl))
    return _Body(_CLOSE)


# spec: N-000262 N-000264 N-000266 N-000267 N-000268 N-000265
def _rewrite_connection(items):
    """Replace Connection tokens: drop keep-alive, ensure close (FP-04)."""
    tokens = []
    raw_name = b"Connection"
    out = []
    first = None
    for item in items:
        raw, lname, value = item
        if lname == b"connection":
            if first is None:
                first = len(out)
                raw_name = raw
                out.append(None)
            for piece in value.split(b","):
                tok = piece.strip(b" \t")
                if tok and tok.lower() != b"keep-alive":
                    tokens.append(tok)
        else:
            out.append(item)
    if not any(tok.lower() == b"close" for tok in tokens):
        tokens.append(b"close")
    new_item = (raw_name, b"connection", b", ".join(tokens))
    if first is None:
        out.append(new_item)
    else:
        out[first] = new_item
    return out


# spec: N-000165 N-000166 N-000167 N-000168 N-000169
def _find_block(buf):
    """Split complete lines up to a blank line. Returns (lines, consumed) or None.

    Lone LF line endings are accepted (spec N-000165).
    """
    lines = []
    pos = 0
    while True:
        idx = buf.find(b"\n", pos)
        if idx < 0:
            return None
        line = bytes(buf[pos:idx])
        if line.endswith(b"\r"):
            line = line[:-1]
        pos = idx + 1
        if not line:
            return lines, pos
        lines.append(line)


def _parse_request_line(line):
    parts = line.split(b" ")
    if len(parts) != 3:
        raise RemoteProtocolError("malformed request line")
    method, target, version = parts
    if version not in _HTTP_VERSIONS:
        raise RemoteProtocolError("unsupported HTTP version in request line")
    return method, target, version[5:]


def _parse_status_line(line):
    parts = line.split(b" ", 2)
    if len(parts) < 2:
        raise RemoteProtocolError("malformed status line")
    version, code = parts[0], parts[1]
    if version not in _HTTP_VERSIONS:
        raise RemoteProtocolError("unsupported HTTP version in status line")
    if not _STATUS_CODE_RE.fullmatch(code):
        raise RemoteProtocolError("malformed status code")
    # spec: N-000166 (see NOTES.md, CF-000005): a missing reason phrase is accepted
    reason = parts[2] if len(parts) == 3 else b""
    return version[5:], int(code), reason


# spec: N-000002 N-000003 N-000005 N-000022 N-000024 N-000047 N-000048 N-000049 N-000052 N-000126 N-000145 N-000146 N-000012
# spec: N-000010 N-000011 N-000122 N-000025 N-000437 N-000050 N-000051 N-000059 N-000060 N-000068
class Connection(object):
    """One HTTP/1.1 connection in the client or server role (FP-02)."""

    # spec: N-000476 N-000477 N-000478 N-000479 N-000480 N-000123 N-000124 N-000125 N-000172 N-000173 N-000033
    def __init__(self, role, max_incomplete_event_size=DEFAULT_MAX_INCOMPLETE_EVENT_SIZE):
        # spec: N-000476 N-000477 -- unknown role is refused, no connection made
        if role is not CLIENT and role is not SERVER:
            raise ValueError("role must be CLIENT or SERVER")
        # spec: N-000478 -- optional int
        if (isinstance(max_incomplete_event_size, bool)
                or not isinstance(max_incomplete_event_size, int)
                or max_incomplete_event_size < 0):
            raise ValueError("max_incomplete_event_size must be a non-negative int")
        self._our_role = role
        self._their_role = _other(role)
        # spec: N-000123..N-000125 -- both sides start in IDLE
        self._states = {CLIENT: IDLE, SERVER: IDLE}
        self._max = max_incomplete_event_size
        self._buf = bytearray()
        self._closed = False
        self._cycle = _Cycle()
        self._our_body = _Body(_NONE)
        self._their_body = _Body(_NONE)
        self._their_http_version = None

    # ------------------------------------------------------------------ attributes

    @property
    def our_role(self):
        return self._our_role

    @property
    # spec: N-000482
    def their_role(self):
        return self._their_role

    @property
    # spec: N-000481 N-000483 N-000126 N-000018
    def our_state(self):
        return self._states[self._our_role]

    @property
    # spec: N-000484
    def their_state(self):
        return self._states[self._their_role]

    @property
    # spec: N-000485 N-000126
    def states(self):
        return {CLIENT: self._states[CLIENT], SERVER: self._states[SERVER]}

    @property
    # spec: N-000486 N-000488 N-000489 N-000487 N-000170 N-000171
    def their_http_version(self):
        return self._their_http_version

    @property
    # spec: N-000490 N-000352 N-000353 N-000354 N-000355 N-000356 N-000357 N-000358
    def client_is_waiting_for_100_continue(self):
        return bool(self._cycle.client_waiting)

    @property
    # spec: N-000492 N-000354 N-000355 N-000356
    def they_are_waiting_for_100_continue(self):
        return self._our_role is SERVER and bool(self._cycle.client_waiting)

    @property
    # spec: N-000494 N-000495 N-000496 N-000388 N-000389 N-000390 N-000391
    def trailing_data(self):
        return (bytes(self._buf), bool(self._closed))

    # ------------------------------------------------------------------ receive

    # spec: N-000507 N-000508 N-000509 N-000511 N-000144 N-000145 N-000146 N-000147 N-000148 N-000150 N-000180 N-000181 N-000182
    # spec: N-000015 N-000016 N-000291 N-000348 N-000474 N-000475
    def receive_data(self, data):
        """Store bytes from the peer. Empty means the peer closed its sending side."""
        view = memoryview(data)          # TypeError for non bytes-like input
        if view.nbytes == 0:
            self._closed = True
            return None
        if self._closed:
            # spec: N-000180..N-000182 -- a runtime error, not a protocol error
            raise RuntimeError("bytes received after the receive side was closed")
        self._buf += view.tobytes()
        return None

    # spec: N-000512 N-000513 N-000514 N-000515 N-000302 N-000303 N-000304 N-000305 N-000306 N-000127 N-000153 N-000154 N-000155 N-000275 N-000276 N-000277 N-000278 N-000279 N-000289 N-000339 N-000340 N-000341 N-000343 N-000347
    # spec: N-000017 N-000026 N-000027 N-000149 N-000031 N-000032
    def next_event(self):
        """Pull one event, NEED_DATA, or PAUSED."""
        try:
            return self._next_event()
        except RemoteProtocolError:
            # spec: N-000302..N-000306 -- their side goes to ERROR, ours does not
            self._states[self._their_role] = ERROR
            self._fire()
            raise

    # spec: N-000027 N-000342 N-000343 N-000401 N-000405 N-000406 N-000407 N-000408 N-000409 N-000410 N-000411 N-000412 N-000402 N-000403 N-000404
    def _next_event(self):
        their = self._their_role
        st = self._states[their]
        buf = self._buf
        if st is ERROR:
            raise RemoteProtocolError("peer already violated the protocol")
        if st is SWITCHED_PROTOCOL or st is MIGHT_SWITCH_PROTOCOL:
            # spec: N-000381..N-000387, N-000373..N-000377 -- HTTP parsing stops
            return PAUSED
        if st is CLOSED:
            return ConnectionClosed()
        if st is DONE or st is MUST_CLOSE:
            # spec: N-000275..N-000279 -- pipelined bytes wait for the next cycle
            if buf:
                return PAUSED
            if self._closed:
                event = ConnectionClosed()
                self._process(their, event, local=False)
                return event
            return NEED_DATA
        if st is SEND_BODY:
            return self._pull_body()
        # IDLE or SEND_RESPONSE: a message head is expected next
        if not buf:
            if self._closed:
                if st is IDLE:
                    event = ConnectionClosed()
                    self._process(their, event, local=False)
                    return event
                raise RemoteProtocolError("connection closed in the middle of a message")
            return NEED_DATA
        return self._pull_head()

    # spec: N-000165 N-000166 N-000167 N-000168 N-000169 N-000174 N-000175 N-000177 N-000178 N-000179 N-000316 N-000318 N-000319 N-000320 N-000321 N-000322 N-000323 N-000296 N-000133 N-000134 N-000135 N-000129 N-000130 N-000170 N-000171 N-000158 N-000159 N-000053 N-000054
    def _pull_head(self):
        buf = self._buf
        # spec: N-000177..N-000179 -- a space or control byte fails at once
        if buf[0] < 33:
            raise RemoteProtocolError("unexpected byte where a message start line belongs")
        found = _find_block(buf)
        if found is None:
            # spec: N-000316..N-000323 -- incomplete head larger than the limit
            if len(buf) > self._max:
                raise RemoteProtocolError("incomplete event exceeds size limit", 431)
            if self._closed:
                raise RemoteProtocolError("connection closed in the middle of a header block")
            return NEED_DATA
        lines, consumed = found
        start = lines[0]
        try:
            if self._their_role is CLIENT:
                method, target, version = _parse_request_line(start)
                event = Request(method, target, pairs_from_lines(lines[1:]), version)
                body = _request_body(event.headers._items)
            else:
                version, code, reason = _parse_status_line(start)
                pairs = pairs_from_lines(lines[1:])
                if 100 <= code < 200:
                    event = InformationalResponse(code, pairs, version, reason)
                else:
                    event = Response(code, pairs, version, reason)
                body = _response_body(event.headers._items, code, self._cycle.request_method)
        except LocalProtocolError as exc:
            # spec: N-000174 N-000175 -- illegal peer bytes are remote errors
            raise RemoteProtocolError(str(exc), exc.error_status_hint)
        self._process(self._their_role, event, local=False, body_kind=body.kind)
        del buf[:consumed]
        self._their_http_version = event.http_version
        if self._states[self._their_role] is SWITCHED_PROTOCOL:
            body = _Body(_NONE)
        self._their_body = body
        return event

    # spec: N-000140 N-000141 N-000142 N-000143 N-000150 N-000151 N-000152 N-000185 N-000186 N-000187 N-000188 N-000189 N-000190 N-000191 N-000208 N-000209 N-000210 N-000211 N-000212 N-000213 N-000214 N-000324 N-000325
    # spec: N-000028
    def _pull_body(self):
        their = self._their_role
        body = self._their_body
        buf = self._buf
        if body.kind == _NONE or (body.kind == _LENGTH and body.remaining == 0):
            event = EndOfMessage()
            self._process(their, event, local=False)
            return event
        if body.kind == _LENGTH:
            # spec: N-000188..N-000191 -- payloads concatenate to the declared length
            if buf:
                n = min(len(buf), body.remaining)
                event = Data(bytes(buf[:n]))
                self._process(their, event, local=False)
                del buf[:n]
                body.remaining -= n
                return event
            if self._closed:
                raise RemoteProtocolError("connection closed in the middle of a Content-Length body")
            return NEED_DATA
        if body.kind == _CLOSE:
            # spec: N-000208..N-000214 -- close-delimited body ends at the empty feed
            if buf:
                event = Data(bytes(buf))
                self._process(their, event, local=False)
                del buf[:]
                return event
            if self._closed:
                event = EndOfMessage()
                self._process(their, event, local=False)
                return event
            return NEED_DATA
        return self._pull_chunked(body)

    # spec: N-000193 N-000195 N-000196 N-000197 N-000220 N-000221 N-000222 N-000223 N-000224 N-000225 N-000226 N-000227 N-000228 N-000229 N-000230 N-000231 N-000232 N-000242 N-000244 N-000245
    def _pull_chunked(self, body):
        their = self._their_role
        buf = self._buf
        if body.cstate == "size":
            idx = buf.find(b"\n")
            if idx < 0:
                if self._closed:
                    raise RemoteProtocolError("connection closed in the middle of a chunk-size line")
                return NEED_DATA
            line = bytes(buf[:idx])
            if line.endswith(b"\r"):
                line = line[:-1]
            match = _CHUNK_SIZE_RE.fullmatch(line)
            if match is None or len(match.group(1)) > MAX_CHUNK_SIZE_DIGITS:
                raise RemoteProtocolError("malformed chunk-size line")
            size = int(match.group(1), 16)
            del buf[:idx + 1]
            body.chunk_first = True
            if size == 0:
                body.cstate = "trailers"
            else:
                body.cstate = "data"
                body.chunk_remaining = size
            return self._pull_chunked(body)
        if body.cstate == "data":
            if not buf:
                if self._closed:
                    raise RemoteProtocolError("connection closed in the middle of a chunk")
                return NEED_DATA
            n = min(len(buf), body.chunk_remaining)
            # spec: N-000220..N-000227 -- start/end marks on data events
            event = Data(bytes(buf[:n]),
                         chunk_start=body.chunk_first,
                         chunk_end=(body.chunk_remaining == n))
            self._process(their, event, local=False)
            del buf[:n]
            body.chunk_remaining -= n
            body.chunk_first = False
            if body.chunk_remaining == 0:
                body.cstate = "crlf"
            return event
        if body.cstate == "crlf":
            # spec: N-000242..N-000245 -- the bytes after chunk data must be exactly CRLF
            if buf[:2] == b"\r\n":
                del buf[:2]
                body.cstate = "size"
                return self._pull_chunked(body)
            if len(buf) < 2 and b"\r\n".startswith(bytes(buf)):
                if self._closed:
                    raise RemoteProtocolError("connection closed in the middle of a chunk")
                return NEED_DATA
            raise RemoteProtocolError("chunk data is not followed by CRLF")
        # trailers after the zero-size chunk
        found = _find_block(buf)
        if found is None:
            if len(buf) > self._max:
                raise RemoteProtocolError("incomplete event exceeds size limit", 431)
            if self._closed:
                raise RemoteProtocolError("connection closed in the middle of trailing headers")
            return NEED_DATA
        lines, consumed = found
        try:
            event = EndOfMessage(pairs_from_lines(lines))
        except LocalProtocolError as exc:
            raise RemoteProtocolError(str(exc), exc.error_status_hint)
        self._process(their, event, local=False)
        del buf[:consumed]
        return event

    # ------------------------------------------------------------------ send

    # spec: N-000497 N-000498 N-000499 N-000501 N-000012 N-000013
    def send(self, event):
        """Encode an event to bytes (empty bytes when the event produces none)."""
        return b"".join(bytes(piece) for piece in self._send(event))

    # spec: N-000502 N-000503 N-000504 N-000505 N-000506 N-000014 N-000233 N-000234 N-000235 N-000236 N-000237
    # spec: N-000029 N-000028
    def send_with_data_passthrough(self, event):
        """Like send(), but returns a list of pieces; caller payload objects stay intact."""
        return list(self._send(event))

    # spec: N-000500 N-000501 N-000307 N-000308 N-000309 N-000310 N-000312 N-000313 N-000334 N-000335 N-000344 N-000345 N-000346 N-000381 N-000386 N-000387 N-000399 N-000400
    # spec: N-000329 N-000330 N-000331 N-000332 N-000333 N-000032
    def _send(self, event):
        if not isinstance(event, EVENT_TYPES):
            raise TypeError("send() takes an event instance")
        our = self._our_role
        wire = None
        body = None
        n = 0
        try:
            if type(event) is Request:
                pieces, body = self._plan_request(event)
            elif type(event) in (InformationalResponse, Response):
                pieces, body, wire = self._plan_response(event)
            elif type(event) is Data:
                pieces, n = self._plan_data(event)
            elif type(event) is EndOfMessage:
                pieces = self._plan_eom(event)
            else:
                pieces = []
            self._process(our, event, local=True,
                          body_kind=(body.kind if body is not None else None),
                          wire=wire)
        except LocalProtocolError:
            # spec: N-000307..N-000310 -- a refused send makes our side ERROR
            self._states[our] = ERROR
            self._fire()
            raise
        if body is not None:
            self._our_body = body
        elif type(event) is Data and self._our_body.kind == _LENGTH:
            self._our_body.remaining -= n
        return pieces

    # spec: N-000517 N-000518 N-000519 N-000270 N-000271 N-000280 N-000281 N-000282 N-000018 N-000286 N-000287 N-000399
    # spec: N-000300 N-000301 N-000401 N-000405 N-000406
    def start_next_cycle(self):
        """Return both sides to IDLE after a finished cycle (FP-04)."""
        # spec: N-000280..N-000282 -- refusal is recoverable and changes nothing
        if self._states[CLIENT] is not DONE or self._states[SERVER] is not DONE:
            raise LocalProtocolError("next cycle can start only when both sides are DONE")
        self._states = {CLIENT: IDLE, SERVER: IDLE}
        self._cycle = _Cycle()
        self._our_body = _Body(_NONE)
        self._their_body = _Body(_NONE)
        return None

    # spec: N-000520 N-000521 N-000522 N-000019 N-000312 N-000313 N-000314 N-000315
    # spec: N-000034
    def send_failed(self):
        """Tell the connection our last send never went out (FP-05)."""
        self._states[self._our_role] = ERROR
        self._fire()
        return None

    # ------------------------------------------------------------------ planning sends

    # spec: N-000128 N-000131 N-000132 N-000160 N-000161 N-000162 N-000163 N-000164 N-000156 N-000157
    def _plan_request(self, event):
        if event.http_version != b"1.1":
            raise LocalProtocolError("only HTTP/1.1 requests can be sent")
        items = list(event.headers._items)
        cl = _get(items, b"content-length")
        if cl is not None:
            body = _Body(_LENGTH, int(cl))
            items = _drop(items, b"transfer-encoding")
        elif _has(items, b"transfer-encoding"):
            body = _Body(_CHUNKED)
        else:
            body = _Body(_NONE)
        # spec: N-000161 N-000162 -- Host is written first; others keep caller order
        hosts = [item for item in items if item[1] == b"host"]
        others = [item for item in items if item[1] != b"host"]
        lines = [event.method + b" " + event.target + b" HTTP/1.1\r\n"]
        for raw, _lname, value in hosts + others:
            lines.append(raw + b": " + value + b"\r\n")
        lines.append(b"\r\n")
        return [b"".join(lines)], body

    # spec: N-000136 N-000138 N-000139 N-000198 N-000199 N-000200 N-000201 N-000202 N-000203 N-000204 N-000205 N-000206 N-000207 N-000215 N-000216 N-000217 N-000218 N-000219 N-000265 N-000266 N-000267 N-000268 N-000269 N-000363 N-000381 N-000382 N-000383 N-000384 N-000385 N-000386 N-000387 N-000157
    # spec: N-000028
    def _plan_response(self, event):
        if event.http_version != b"1.1":
            raise LocalProtocolError("only HTTP/1.1 responses can be sent")
        status = event.status_code
        items = list(event.headers._items)
        accepted = _accepts(self._cycle.proposals, status)
        if status < 200 or accepted:
            body = _Body(_NONE)
        else:
            peer_11 = self._cycle.request_version == b"1.1"
            head = self._cycle.request_method == b"HEAD"
            close_needed = False
            cl = _get(items, b"content-length")
            if status in (204, 304) or head:
                # spec: N-000215..N-000219 -- empty-body responses
                body = _Body(_NONE)
                if cl is not None and int(cl) == 0:
                    items = _drop(items, b"content-length")
                if head:
                    if not peer_11:
                        items = _drop(items, b"transfer-encoding")
                        close_needed = True
                    elif not _has(items, b"transfer-encoding") and not _has(items, b"content-length"):
                        items.append((b"Transfer-Encoding", b"transfer-encoding", b"chunked"))
            elif _has(items, b"transfer-encoding"):
                # spec: N-000207 -- transfer-encoding wins; Content-Length is not sent
                items = _drop(items, b"content-length")
                if peer_11:
                    body = _Body(_CHUNKED)
                else:
                    # spec: N-000203..N-000206 -- HTTP/1.0 peer gets close framing
                    body = _Body(_CLOSE)
                    items = _drop(items, b"transfer-encoding")
                    close_needed = True
            elif cl is not None:
                # spec: N-000198 N-000199 -- Content-Length kept, including 0
                body = _Body(_LENGTH, int(cl))
            elif peer_11:
                # spec: N-000200..N-000202 -- unknown length, HTTP/1.1 peer: chunked
                body = _Body(_CHUNKED)
                items.append((b"Transfer-Encoding", b"transfer-encoding", b"chunked"))
            else:
                body = _Body(_CLOSE)
                close_needed = True
            if status >= 200 and (close_needed or body.kind == _CLOSE
                                  or has_token(items, b"connection", b"close")
                                  or self._keep_alive_disabled()):
                # spec: N-000265..N-000269 -- keep-alive off means Connection: close
                items = _rewrite_connection(items)
        lines = [b"HTTP/1.1 " + str(status).encode("ascii") + b" " + event.reason + b"\r\n"]
        for raw, _lname, value in items:
            lines.append(raw + b": " + value + b"\r\n")
        lines.append(b"\r\n")
        return [b"".join(lines)], body, items

    # spec: N-000188 N-000189 N-000190 N-000191 N-000192 N-000197 N-000233 N-000234 N-000235 N-000236 N-000237 N-000238 N-000239
    # spec: N-000028
    def _plan_data(self, event):
        body = self._our_body
        payload = event.data
        n = _length_of(payload)
        if body.kind == _LENGTH:
            # spec: N-000238 -- more than the declared Content-Length is refused
            if n > body.remaining:
                raise LocalProtocolError("data exceeds the remaining Content-Length")
            return ([payload] if n else []), n
        if body.kind == _CHUNKED:
            # spec: N-000192..N-000197 -- one chunk per non-empty data event
            return ([b"%x\r\n" % n, payload, b"\r\n"] if n else []), n
        if body.kind == _CLOSE:
            return ([payload] if n else []), n
        if n:
            raise LocalProtocolError("this message has no body")
        return [], 0

    # spec: N-000193 N-000238 N-000240 N-000241 N-000244
    def _plan_eom(self, event):
        body = self._our_body
        trailers = list(event.headers._items)
        if body.kind == _LENGTH:
            # spec: N-000238 -- end-of-message before the declared length is refused
            if body.remaining != 0:
                raise LocalProtocolError("end-of-message before the Content-Length was sent in full")
            if trailers:
                raise LocalProtocolError("trailing headers need chunked framing")
            return []
        if body.kind == _CHUNKED:
            block = b"".join(raw + b": " + value + b"\r\n" for raw, _l, value in trailers)
            return [b"0\r\n" + block + b"\r\n"]
        # spec: N-000240 N-000241 -- trailers refused without chunked framing
        if trailers:
            raise LocalProtocolError("trailing headers need chunked framing")
        return []

    # ------------------------------------------------------------------ state machine

    # spec: N-000259 N-000260 N-000261 N-000262 N-000263 N-000264 N-000286 N-000287 N-000288
    # spec: N-000062 N-000063
    def _keep_alive_disabled(self, extra=False):
        """FP-04: keep-alive needs HTTP/1.1 both ways and no close token."""
        cyc = self._cycle
        if extra or cyc.close_seen or cyc.closedelim:
            return True
        if cyc.request_version != b"1.1":
            return True
        if cyc.response_version is not None and cyc.response_version != b"1.1":
            return True
        for state in self._states.values():
            if state is ERROR:
                return True
        return False

    # spec: N-000006 N-000031 N-000032
    def _fail(self, local, message):
        if local:
            return LocalProtocolError(message)
        return RemoteProtocolError(message)

    # spec: N-000247 N-000248 N-000249 N-000250 N-000251 N-000252 N-000253 N-000254 N-000255 N-000256 N-000257 N-000258 N-000280 N-000283 N-000284 N-000285 N-000272 N-000273 N-000274 N-000275 N-000360 N-000361 N-000362 N-000364 N-000365 N-000366 N-000367 N-000368 N-000369 N-000370 N-000371 N-000372 N-000373 N-000374 N-000375 N-000376 N-000377 N-000378 N-000379 N-000380 N-000392 N-000393 N-000394 N-000395 N-000397 N-000334 N-000335 N-000344 N-000345 N-000346
    # spec: N-000030 N-000035 N-000036 N-000350 N-000351 N-000352 N-000353
    def _process(self, sender, event, local, body_kind=None, wire=None):
        """Run one event through the joint transition table.

        Checks everything first; mutates state only after all checks pass, so a
        refused event leaves the connection unchanged (except for the caller's
        own ERROR marking on sends).
        """
        states = self._states
        cur = self._cycle
        st_sender = states[sender]
        new = {CLIENT: states[CLIENT], SERVER: states[SERVER]}
        cyc = cur.copy()
        et = type(event)

        if et is Request:
            if sender is not CLIENT or st_sender is not IDLE:
                raise self._fail(local, "request not allowed in state %r" % (st_sender,))
            new[CLIENT] = SEND_BODY
            if states[SERVER] is IDLE:
                new[SERVER] = SEND_RESPONSE
            items = event.headers._items
            cyc.request_method = event.method
            cyc.request_version = event.http_version
            cyc.close_seen = has_token(items, b"connection", b"close")
            # spec: N-000354 N-000357 -- Expect: 100-continue on HTTP/1.1 only
            cyc.client_waiting = (event.http_version == b"1.1"
                                  and has_token(items, b"expect", b"100-continue"))
            cyc.proposals = set()
            # spec: N-000364 N-000366 -- CONNECT and Upgrade proposals
            if event.method == b"CONNECT":
                cyc.proposals.add(b"connect")
            if _has(items, b"upgrade"):
                cyc.proposals.add(b"upgrade")

        elif et is InformationalResponse or et is Response:
            if sender is not SERVER:
                raise self._fail(local, "only the server role sends responses")
            cyc.client_waiting = False
            if et is InformationalResponse:
                if st_sender is not SEND_RESPONSE:
                    raise self._fail(local, "informational response not allowed in state %r" % (st_sender,))
                if event.status_code == 101 and b"upgrade" in cur.proposals:
                    # spec: N-000366 N-000381 -- 101 accepts Upgrade
                    new[SERVER] = SWITCHED_PROTOCOL
                    new[CLIENT] = SWITCHED_PROTOCOL
                    cyc.proposals = set()
                else:
                    new[SERVER] = SEND_RESPONSE
            else:
                if st_sender is not IDLE and st_sender is not SEND_RESPONSE:
                    raise self._fail(local, "response not allowed in state %r" % (st_sender,))
                cyc.response_version = event.http_version
                items = wire if wire is not None else event.headers._items
                cyc.close_seen = cur.close_seen or has_token(items, b"connection", b"close")
                if body_kind == _CLOSE:
                    cyc.closedelim = True
                if _accepts(cur.proposals, event.status_code):
                    # spec: N-000369..N-000372 -- 2xx accepts CONNECT (permanent switch)
                    new[SERVER] = SWITCHED_PROTOCOL
                    new[CLIENT] = SWITCHED_PROTOCOL
                    cyc.proposals = set()
                else:
                    if cur.proposals:
                        # spec: N-000378..N-000380 -- denial: client goes to DONE
                        cyc.proposals = set()
                        if states[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                            new[CLIENT] = DONE
                    new[SERVER] = SEND_BODY

        elif et is Data:
            if st_sender is not SEND_BODY:
                raise self._fail(local, "data not allowed in state %r" % (st_sender,))

        elif et is EndOfMessage:
            if st_sender is not SEND_BODY:
                raise self._fail(local, "end-of-message not allowed in state %r" % (st_sender,))
            # spec: N-000373..N-000377 -- client waits in MIGHT_SWITCH after proposing
            if sender is CLIENT and cur.proposals:
                new[CLIENT] = MIGHT_SWITCH_PROTOCOL
            else:
                new[sender] = DONE

        elif et is ConnectionClosed:
            # spec: N-000334 N-000335 N-000344 N-000345 -- close allowed only from IDLE/DONE/MUST_CLOSE
            if st_sender not in (IDLE, DONE, MUST_CLOSE):
                raise self._fail(local, "connection-closed not allowed in state %r" % (st_sender,))
            new[sender] = CLOSED

        else:
            raise TypeError("unknown event")

        self._states = new
        self._cycle = cyc
        self._fire()

    # spec: N-000264 N-000265 N-000311 N-000336 N-000337 N-000338 N-000259
    # spec: N-000327 N-000328 N-000032
    def _fire(self):
        """State-triggered transitions (FP-04, FP-06, FP-05)."""
        st = self._states
        changed = True
        while changed:
            changed = False
            for a, b in ((CLIENT, SERVER), (SERVER, CLIENT)):
                # spec: N-000336..N-000338 -- one side CLOSED: other IDLE/DONE -> MUST_CLOSE
                if st[a] is CLOSED and (st[b] is IDLE or st[b] is DONE):
                    st[b] = MUST_CLOSE
                    changed = True
                # spec: N-000311 -- one side ERROR: other DONE -> MUST_CLOSE
                if st[a] is ERROR and st[b] is DONE:
                    st[b] = MUST_CLOSE
                    changed = True
            if self._keep_alive_disabled():
                # spec: N-000259..N-000264 -- keep-alive off: DONE becomes MUST_CLOSE
                for role in (CLIENT, SERVER):
                    if st[role] is DONE:
                        st[role] = MUST_CLOSE
                        changed = True


def _length_of(payload):
    if isinstance(payload, (bytes, bytearray, memoryview)):
        return memoryview(payload).nbytes
    return len(payload)
