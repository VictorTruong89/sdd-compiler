"""Byte handling, token/value rules, and header-list normalization.

Rules come from FP-01 (header list, value rule, Content-Length and
Transfer-Encoding normalization) and FP-01 "Interface Contract > Header list".
"""

import re

from ._errors import LocalProtocolError

# spec: N-000106 -- header names must be RFC 7230 tokens
_TOKEN_RE = re.compile(rb"[!#$%&'*+\-.^_`|~0-9A-Za-z]+")
# spec: N-000097 N-000108 -- value bytes: tab, visible ASCII, obs-text (no other control bytes)
_VALUE_BYTES_RE = re.compile(rb"[\t\x20-\x7e\x80-\xff]*")
# spec: N-000110 -- request target: visible ASCII only
_TARGET_RE = re.compile(rb"[\x21-\x7e]+")
# HTTP version as two digits separated by a dot (FP-01)
_VERSION_RE = re.compile(rb"[0-9]\.[0-9]")
_DIGITS_RE = re.compile(rb"[0-9]+")

# spec: N-000114 N-000116 -- max Content-Length digits: fixed in 18..32; we pick 18
# spec: N-000116 N-000117 N-000118
MAX_CONTENT_LENGTH_DIGITS = 18

# Chunk-size digit limit: fixed in 16..32 (spec N-000228); we pick 32.
# spec: N-000228
MAX_CHUNK_SIZE_DIGITS = 32


# spec: N-000074 N-000089 N-000458 N-000459 N-000460
def to_bytes(value, what="value"):
    """Accept bytes, bytes-like objects, or ASCII str; return exact bytes."""
    if isinstance(value, bytes):
        return value
    if isinstance(value, (bytearray, memoryview)):
        return bytes(value)
    if isinstance(value, str):
        try:
            return value.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("%s must be ASCII text or bytes" % what)
    raise LocalProtocolError("%s must be bytes or ASCII str, not %s"
                             % (what, type(value).__name__))


# spec: N-000106 N-000111
def check_token(name, what):
    if not _TOKEN_RE.fullmatch(name):
        raise LocalProtocolError("%s is not a valid token: %r" % (what, name))


# spec: N-000097 N-000098 N-000099 N-000100 N-000107 N-000108 N-000109
def check_value(value):
    """Header value rule (FP-01): no leading/trailing SP or HTAB, no control bytes."""
    if value[:1] in (b" ", b"\t") or value[-1:] in (b" ", b"\t"):
        raise LocalProtocolError("header value may not begin or end with space or tab")
    if not _VALUE_BYTES_RE.fullmatch(value):
        raise LocalProtocolError("header value contains a forbidden control byte")


# spec: N-000110
def check_target(target):
    if not _TARGET_RE.fullmatch(target):
        raise LocalProtocolError("request target must be visible ASCII")


# spec: N-000075
def check_version(version):
    if not _VERSION_RE.fullmatch(version):
        raise LocalProtocolError("HTTP version must look like 1.1")


# spec: N-000082 N-000083
def check_reason(reason):
    # Reason phrase is not specified beyond "stored as a byte string"; we refuse
    # bytes that cannot be represented on a status line (see NOTES.md).
    if not _VALUE_BYTES_RE.fullmatch(reason):
        raise LocalProtocolError("reason phrase contains a forbidden control byte")


def has_token(items, lname, token):
    """True if a header named ``lname`` lists ``token`` as a whole comma element."""
    for _raw, name, value in items:
        if name == lname:
            for piece in value.split(b","):
                if piece.strip(b" \t").lower() == token:
                    return True
    return False


# spec: N-000087 N-000088 N-000090 N-000091 N-000467 N-000468 N-000469 N-000470 N-000471
class Headers(object):
    """Ordered header list: ordinary view (lowercase names) plus raw_items()."""

    __slots__ = ("_items",)

    def __init__(self, items):
        # items: tuple of (raw_name, lname, value) triples, all bytes
        self._items = tuple(items)

    def __iter__(self):
        return iter([(lname, value) for (_raw, lname, value) in self._items])

    def __len__(self):
        return len(self._items)

    def __getitem__(self, index):
        if isinstance(index, slice):
            return [(lname, value) for (_raw, lname, value) in self._items[index]]
        _raw, lname, value = self._items[index]
        return (lname, value)

    def raw_items(self):
        """(name, value) pairs in order, with each name spelled as the caller gave it."""
        return [(raw, value) for (raw, _lname, value) in self._items]

    def __eq__(self, other):
        if isinstance(other, Headers):
            return self._items == other._items
        try:
            return list(self) == list(other)
        except TypeError:
            return NotImplemented

    __hash__ = None

    def __repr__(self):
        return "Headers(%r)" % (list(self),)


# spec: N-000092 N-000094 N-000095 N-000096 N-000246 N-000114 N-000115 N-000116 N-000117 N-000118 N-000119 N-000120 N-000121 N-000064 N-000065 N-000109
def normalize_headers(pairs):
    """Turn caller/peer pairs into a list of (raw, lname, value) triples.

    Applies the FP-01 normalization: Content-Length collapse and checks,
    Transfer-Encoding checks, name/value rules.
    """
    if isinstance(pairs, Headers):
        pairs = pairs.raw_items()
    out = []
    cl_index = None
    cl_value = None
    te_count = 0
    for pair in pairs:
        try:
            name, value = pair
        except (TypeError, ValueError):
            raise LocalProtocolError("header must be a (name, value) pair")
        name = to_bytes(name, "header name")
        value = to_bytes(value, "header value")
        check_token(name, "header name")
        check_value(value)
        lname = name.lower()
        if lname == b"content-length":
            # spec: N-000114 N-000115 N-000116 N-000117 N-000118 N-000119
            for piece in value.split(b","):
                digits = piece.strip(b" \t")
                if not _DIGITS_RE.fullmatch(digits):
                    raise LocalProtocolError("Content-Length must be a decimal integer")
                if len(digits) > MAX_CONTENT_LENGTH_DIGITS:
                    raise LocalProtocolError("Content-Length has too many digits")
                number = int(digits)
                if cl_value is None:
                    cl_value = number
                elif cl_value != number:
                    raise LocalProtocolError("conflicting Content-Length values")
            if cl_index is None:
                cl_index = len(out)
                out.append([b"content-length", b"content-length", b""])
            continue
        if lname == b"transfer-encoding":
            # spec: N-000120 N-000121 -- exactly "chunked", and only one header
            te_count += 1
            if te_count > 1:
                raise LocalProtocolError("second Transfer-Encoding header refused", 501)
            if value.lower() != b"chunked":
                raise LocalProtocolError("only Transfer-Encoding: chunked is supported", 501)
            out.append([b"transfer-encoding", b"transfer-encoding", b"chunked"])
            continue
        out.append([name, lname, value])
    if cl_index is not None:
        out[cl_index][2] = str(cl_value).encode("ascii")
    return [tuple(item) for item in out]


# spec: N-000167 N-000168 N-000169 N-000174
def pairs_from_lines(lines):
    """Parse raw header lines (already split, no line endings) with obs-fold.

    Raises ValueError-like LocalProtocolError on malformed lines; callers that
    parse peer bytes convert it to RemoteProtocolError.
    """
    out = []
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            # spec: N-000167 N-000168 N-000169 -- obsolete line folding
            if not out:
                raise LocalProtocolError("continuation line with no header to join")
            name, value = out[-1]
            out[-1] = (name, value + b" " + line.strip(b" \t"))
            continue
        idx = line.find(b":")
        if idx <= 0:
            raise LocalProtocolError("header line has no colon")
        out.append((line[:idx], line[idx + 1:].strip(b" \t")))
    return out
