"""httpwire: a pure-Python HTTP/1.1 wire protocol library with no I/O.

The public surface is the names listed in spec/packs (Interface Contract,
"Shape of the public surface"). Everything is importable from the package root.
"""

from ._connection import Connection
from ._errors import LocalProtocolError, ProtocolError, RemoteProtocolError
from ._events import (ConnectionClosed, Data, EndOfMessage, InformationalResponse,
                      Request, Response)
from ._sentinels import (CLIENT, CLOSED, DONE, ERROR, IDLE, MIGHT_SWITCH_PROTOCOL,
                         MUST_CLOSE, NEED_DATA, PAUSED, SEND_BODY, SEND_RESPONSE,
                         SERVER, SWITCHED_PROTOCOL)

# spec: N-000001 N-000002 N-000004 N-000005 N-000007 N-000022 N-000023 N-000069 N-000429 N-000430 N-000431 N-000432 N-000433 N-000446 N-000447 N-000448 N-000449
# spec: N-000008 N-000055 N-000056 N-000057 N-000059 N-000060 N-000061 N-000068
__version__ = "0.1.0"

__all__ = [
    "CLIENT", "SERVER",
    "NEED_DATA", "PAUSED",
    "IDLE", "SEND_RESPONSE", "SEND_BODY", "DONE", "MUST_CLOSE", "CLOSED",
    "MIGHT_SWITCH_PROTOCOL", "SWITCHED_PROTOCOL", "ERROR",
    "Request", "InformationalResponse", "Response", "Data", "EndOfMessage",
    "ConnectionClosed",
    "Connection",
    "LocalProtocolError", "RemoteProtocolError", "ProtocolError",
]
