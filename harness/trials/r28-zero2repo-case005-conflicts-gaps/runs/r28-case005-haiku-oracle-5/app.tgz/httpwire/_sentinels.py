"""Package-root sentinel objects: roles, states, and pull results.

They are plain distinct objects (not strings), so no two compare equal
(spec N-000440..N-000445).
"""


class _Sentinel(object):
    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return "httpwire." + self._name


# spec: N-000438 N-000439 -- roles
CLIENT = _Sentinel("CLIENT")
SERVER = _Sentinel("SERVER")

# spec: N-000440 N-000441 N-000442 -- non-event results of next_event
NEED_DATA = _Sentinel("NEED_DATA")
PAUSED = _Sentinel("PAUSED")

# spec: N-000443 N-000444 N-000445 -- the nine state values
IDLE = _Sentinel("IDLE")
SEND_RESPONSE = _Sentinel("SEND_RESPONSE")
SEND_BODY = _Sentinel("SEND_BODY")
DONE = _Sentinel("DONE")
MUST_CLOSE = _Sentinel("MUST_CLOSE")
CLOSED = _Sentinel("CLOSED")
MIGHT_SWITCH_PROTOCOL = _Sentinel("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = _Sentinel("SWITCHED_PROTOCOL")
ERROR = _Sentinel("ERROR")
