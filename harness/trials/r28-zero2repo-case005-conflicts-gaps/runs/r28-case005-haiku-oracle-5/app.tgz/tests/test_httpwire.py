"""Behavioral tests for httpwire, organised by feature point (see NOTES.md)."""

import pytest

import httpwire as hw
from httpwire import (CLIENT, SERVER, NEED_DATA, PAUSED, IDLE, SEND_RESPONSE,
                      SEND_BODY, DONE, MUST_CLOSE, CLOSED, MIGHT_SWITCH_PROTOCOL,
                      SWITCHED_PROTOCOL, ERROR, Request, InformationalResponse,
                      Response, Data, EndOfMessage, ConnectionClosed, Connection,
                      LocalProtocolError, RemoteProtocolError)


def pull_all(conn):
    out = []
    while True:
        ev = conn.next_event()
        if ev is NEED_DATA or ev is PAUSED:
            out.append(ev)
            return out
        out.append(ev)


def get_request(headers=None, version=b"1.1"):
    if headers is None:
        headers = [(b"Host", b"example.com")]
    return Request(method=b"GET", target=b"/", headers=headers, http_version=version)


# ---------------------------------------------------------------- public surface

def test_package_root_names():  # spec: N-000433..N-000449
    for name in ["CLIENT", "SERVER", "NEED_DATA", "PAUSED", "IDLE", "SEND_RESPONSE",
                 "SEND_BODY", "DONE", "MUST_CLOSE", "CLOSED", "MIGHT_SWITCH_PROTOCOL",
                 "SWITCHED_PROTOCOL", "ERROR", "Request", "InformationalResponse",
                 "Response", "Data", "EndOfMessage", "ConnectionClosed", "Connection",
                 "LocalProtocolError", "RemoteProtocolError"]:
        assert hasattr(hw, name)
    states = [IDLE, SEND_RESPONSE, SEND_BODY, DONE, MUST_CLOSE, CLOSED,
              MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL, ERROR]
    assert len({id(s) for s in states}) == 9
    assert CLIENT is not SERVER
    assert NEED_DATA is not PAUSED
    assert not issubclass(LocalProtocolError, RemoteProtocolError)
    assert not issubclass(RemoteProtocolError, LocalProtocolError)
    assert not isinstance(NEED_DATA, Request)


# ---------------------------------------------------------------- FP-01 events

def test_request_defaults_and_byte_storage():  # spec: N-000072..N-000076
    req = Request(method="GET", target="/x", headers=[("Host", "h")])
    assert req.http_version == b"1.1"
    assert type(req.method) is bytes and type(req.target) is bytes
    assert req.method == b"GET" and req.target == b"/x"


def test_host_rules():  # spec: N-000077 N-000078 N-000104 N-000105
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/", headers=[])
    Request(method=b"GET", target=b"/", headers=[], http_version=b"1.0")
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/", headers=[(b"HOST", b"a"), (b"host", b"b")],
                http_version=b"1.0")


def test_header_list_views():  # spec: N-000467..N-000471
    req = get_request([(b"Host", b"a"), (b"X-Case", b"v")])
    assert list(req.headers) == [(b"host", b"a"), (b"x-case", b"v")]
    assert req.headers[1] == (b"x-case", b"v")
    assert req.headers.raw_items() == [(b"Host", b"a"), (b"X-Case", b"v")]


def test_content_length_collapse_and_conflict():  # spec: N-000092 N-000093 N-000114..N-000119
    req = get_request([(b"Host", b"a"), (b"Content-Length", b"5"), (b"content-length", b"5, 5")])
    assert [h for h in req.headers if h[0] == b"content-length"] == [(b"content-length", b"5")]
    with pytest.raises(LocalProtocolError):
        get_request([(b"Host", b"a"), (b"Content-Length", b"5"), (b"Content-Length", b"6")])
    with pytest.raises(LocalProtocolError):
        get_request([(b"Host", b"a"), (b"Content-Length", b"5x")])


def test_content_length_digit_limit():  # spec: N-000116 (18-digit ceiling chosen, see NOTES)
    get_request([(b"Host", b"a"), (b"Content-Length", b"9" * 18)])
    with pytest.raises(LocalProtocolError):
        get_request([(b"Host", b"a"), (b"Content-Length", b"9" * 19)])


def test_transfer_encoding_rules():  # spec: N-000092 N-000120 N-000121
    req = get_request([(b"Host", b"a"), (b"Transfer-Encoding", b"CHUNKED")])
    assert list(req.headers)[1] == (b"transfer-encoding", b"chunked")
    with pytest.raises(LocalProtocolError) as exc:
        get_request([(b"Host", b"a"), (b"Transfer-Encoding", b"gzip, chunked")])
    assert exc.value.error_status_hint == 501
    with pytest.raises(LocalProtocolError) as exc:
        get_request([(b"Host", b"a"), (b"Transfer-Encoding", b"chunked"),
                     (b"Transfer-Encoding", b"chunked")])
    assert exc.value.error_status_hint == 501


def test_value_and_name_rules():  # spec: N-000097..N-000109
    get_request([(b"Host", b"a"), (b"X-A", b"tab\tinside \xff ok")])
    for bad in [b" lead", b"trail ", b"nul\x00", b"ctl\x01", b"cr\r", b"\x7f"]:
        with pytest.raises(LocalProtocolError):
            get_request([(b"Host", b"a"), (b"X-A", bad)])
    with pytest.raises(LocalProtocolError):
        get_request([(b"Host", b"a"), (b"Bad Name", b"x")])


def test_target_and_method_rules():  # spec: N-000110 N-000111
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/a b", headers=[(b"Host", b"a")])
    with pytest.raises(LocalProtocolError):
        Request(method=b"G E", target=b"/", headers=[(b"Host", b"a")])


def test_status_ranges():  # spec: N-000079..N-000083, N-000112, N-000113
    InformationalResponse(status_code=100, headers=[])
    InformationalResponse(status_code=199, headers=[])
    with pytest.raises(LocalProtocolError):
        InformationalResponse(status_code=200, headers=[])
    Response(status_code=200, headers=[])
    Response(status_code=999, headers=[])
    with pytest.raises(LocalProtocolError):
        Response(status_code=1000, headers=[])
    with pytest.raises(LocalProtocolError):
        Response(status_code="200", headers=[])
    assert Response(status_code=200, headers=[]).reason == b""


def test_data_and_eom_fields():  # spec: N-000084..N-000086, N-000463..N-000465
    d = Data(b"abc")
    assert d.chunk_start is False and d.chunk_end is False
    assert EndOfMessage().headers == []
    assert ConnectionClosed() == ConnectionClosed()


def test_construction_error_is_local_and_no_event():  # spec: N-000466
    with pytest.raises(LocalProtocolError):
        get_request([])  # no Host on HTTP/1.1


# ---------------------------------------------------------------- FP-02 connection

def test_bad_role_refused():  # spec: N-000476 N-000477
    with pytest.raises(ValueError):
        Connection("client")


def test_initial_states_and_states_mapping():  # spec: N-000123..N-000126
    c = Connection(CLIENT)
    assert c.our_role is CLIENT and c.their_role is SERVER
    assert c.states == {CLIENT: IDLE, SERVER: IDLE}
    assert c.our_state is IDLE and c.their_state is IDLE
    assert c.their_http_version is None
    assert c.trailing_data == (b"", False)
    assert c.next_event() is NEED_DATA


def test_send_request_sets_states_and_bytes():  # spec: N-000128..N-000133, N-000161
    c = Connection(CLIENT)
    data = c.send(get_request([(b"X-A", b"1"), (b"Host", b"h")]))
    assert data == b"GET / HTTP/1.1\r\nHost: h\r\nX-A: 1\r\n\r\n"
    assert c.our_state is SEND_BODY and c.their_state is SEND_RESPONSE
    assert c.their_http_version is None


def test_round_trip_of_data_and_headers():  # spec: N-000134, N-000135, N-000163
    c = Connection(CLIENT)
    s = Connection(SERVER)
    wire = c.send(get_request([(b"Host", b"h"), (b"X-Case", b"v")]))
    c.send(EndOfMessage())
    s.receive_data(wire)
    req = s.next_event()
    assert isinstance(req, Request)
    assert req.headers.raw_items()[1] == (b"X-Case", b"v")
    assert s.their_http_version == b"1.1"
    assert s.next_event() == EndOfMessage()
    assert s.states == {CLIENT: DONE, SERVER: SEND_RESPONSE}


def test_pull_is_one_event_and_need_data_retains_bytes():  # spec: N-000144..N-000155
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHo")
    assert s.next_event() is NEED_DATA
    assert s.trailing_data[0] == b"GET / HTTP/1.1\r\nHo"
    s.receive_data(b"st: h\r\n\r\n")
    assert isinstance(s.next_event(), Request)


def test_feed_after_close_is_runtime_error():  # spec: N-000180..N-000182
    s = Connection(SERVER)
    s.receive_data(b"")
    with pytest.raises(RuntimeError):
        s.receive_data(b"x")
    assert not isinstance(RuntimeError(), (LocalProtocolError, RemoteProtocolError))


def test_response_status_line_and_no_reason():  # spec: N-000136..N-000139, N-000166
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    s.next_event()
    out = s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")], reason=b"OK"))
    assert out == b"HTTP/1.1 200 OK\r\ncontent-length: 0\r\n\r\n"
    assert s.our_state is SEND_BODY


def test_lone_lf_and_obs_fold_accepted_when_reading():  # spec: N-000165 N-000167..N-000169
    c = Connection(CLIENT)
    c.send(get_request())
    c.send(EndOfMessage())
    c.receive_data(b"HTTP/1.1 200 OK\nX-Fold: a\n   b\tc\nContent-Length: 0\n\n")
    resp = c.next_event()
    assert isinstance(resp, Response)
    # spec N-000169: leading run of the continuation replaced by one space; rest kept
    assert resp.headers[0] == (b"x-fold", b"a b\tc")
    assert c.next_event() == EndOfMessage()


def test_status_line_without_reason_accepted():  # spec: N-000166 (CF-000005)
    c = Connection(CLIENT)
    c.send(get_request())
    c.send(EndOfMessage())
    c.receive_data(b"HTTP/1.1 204\r\n\r\n")
    resp = c.next_event()
    assert isinstance(resp, Response) and resp.reason == b""


def test_leading_space_or_control_byte_fails_at_once():  # spec: N-000177..N-000179
    s = Connection(SERVER)
    s.receive_data(b" GET / HTTP/1.1")
    with pytest.raises(RemoteProtocolError):
        s.next_event()
    assert s.their_state is ERROR


def test_continuation_line_at_start_refused():  # spec: N-000176
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\n Host: a\r\n\r\n")
    with pytest.raises(RemoteProtocolError):
        s.next_event()


# ---------------------------------------------------------------- FP-03 framing

def test_request_content_length_body():  # spec: N-000188..N-000191
    c = Connection(CLIENT)
    s = Connection(SERVER)
    wire = c.send(get_request([(b"Host", b"a"), (b"Content-Length", b"5")]))
    assert wire.endswith(b"\r\n\r\n")
    assert c.send(Data(b"abc")) == b"abc"
    assert c.send(Data(b"de")) == b"de"
    assert c.send(EndOfMessage()) == b""
    with pytest.raises(LocalProtocolError):
        c.send(Data(b"x"))  # DONE: no more body allowed, and our side goes to ERROR
    assert c.our_state is ERROR
    s.receive_data(wire + b"abc" + b"de")
    s.next_event()
    # both payloads are already stored, so one pull yields them together
    assert s.next_event() == Data(b"abcde")
    assert s.next_event() == EndOfMessage()


def test_content_length_overrun_is_local_and_error_state():  # spec: N-000238, N-000307..N-000310
    c = Connection(CLIENT)
    c.send(get_request([(b"Host", b"a"), (b"Content-Length", b"2")]))
    with pytest.raises(LocalProtocolError):
        c.send(Data(b"abc"))
    assert c.our_state is ERROR
    with pytest.raises(LocalProtocolError):
        c.send(EndOfMessage())


def test_chunked_send_encoding_and_passthrough_identity():  # spec: N-000192..N-000197, N-000233..N-000237
    c = Connection(CLIENT)
    c.send(get_request([(b"Host", b"a"), (b"Transfer-Encoding", b"chunked")]))
    assert c.send(Data(b"hello")) == b"5\r\nhello\r\n"
    assert c.send(Data(b"")) == b""
    assert c.send(EndOfMessage(headers=[(b"X-T", b"1")])) == b"0\r\nX-T: 1\r\n\r\n"

    c2 = Connection(CLIENT)
    c2.send(get_request([(b"Host", b"a"), (b"Transfer-Encoding", b"chunked")]))

    class Placeholder(object):
        def __len__(self):
            return 4

    ph = Placeholder()
    pieces = c2.send_with_data_passthrough(Data(ph))
    assert pieces[0] == b"4\r\n"
    assert pieces[1] is ph
    assert pieces[2] == b"\r\n"


def test_chunked_receive_marks_and_split_pieces():  # spec: N-000220..N-000232
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\n"
                   b"4\r\nab")
    s.next_event()
    first = s.next_event()
    assert first == Data(b"ab", chunk_start=True, chunk_end=False)
    assert s.next_event() is NEED_DATA
    s.receive_data(b"cd\r\n3;ext=1\r\nxyz\r\n0\r\nT: v\r\n\r\n")
    second = s.next_event()
    assert second == Data(b"cd", chunk_start=False, chunk_end=True)
    third = s.next_event()
    assert third == Data(b"xyz", chunk_start=True, chunk_end=True)
    end = s.next_event()
    assert end == EndOfMessage(headers=[(b"T", b"v")])


def test_bad_chunk_terminator_and_size_digits():  # spec: N-000242..N-000245, N-000228
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\n2\r\nabXX")
    s.next_event()
    s.next_event()
    with pytest.raises(RemoteProtocolError):
        s.next_event()

    s2 = Connection(SERVER)
    s2.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\n"
                    + b"1" * 33 + b"\r\n")
    s2.next_event()
    with pytest.raises(RemoteProtocolError):
        s2.next_event()


def test_no_framing_request_has_empty_body():  # spec: N-000185..N-000187
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    assert s.next_event() == EndOfMessage()


def test_head_response_and_empty_body_statuses():  # spec: N-000215..N-000219
    s = Connection(SERVER)
    s.receive_data(b"HEAD / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    s.next_event()
    out = s.send(Response(status_code=200, headers=[]))
    # framing headers as for GET: chunked for an HTTP/1.1 peer (N-000219)
    assert out == b"HTTP/1.1 200 \r\nTransfer-Encoding: chunked\r\n\r\n"
    assert s.send(EndOfMessage()) == b""
    assert s.our_state is DONE

    s2 = Connection(SERVER)
    s2.receive_data(b"HEAD / HTTP/1.1\r\nHost: a\r\n\r\n")
    s2.next_event()
    s2.next_event()
    with pytest.raises(LocalProtocolError):
        s2.send(Data(b"x"))  # body is never sent for HEAD
    assert s2.our_state is ERROR

    c = Connection(CLIENT)
    c.send(Request(method=b"HEAD", target=b"/", headers=[(b"Host", b"a")]))
    c.send(EndOfMessage())
    c.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 10\r\n\r\n")
    assert isinstance(c.next_event(), Response)
    assert c.next_event() == EndOfMessage()  # no body although Content-Length says 10


def test_response_framing_for_unknown_and_http10_peer():  # spec: N-000200..N-000206
    s = Connection(SERVER)
    out = s.send(Response(status_code=200, headers=[]))
    assert out == b"HTTP/1.1 200 \r\nConnection: close\r\n\r\n"
    s2 = Connection(SERVER)
    s2.receive_data(b"GET / HTTP/1.0\r\n\r\n")
    s2.next_event()
    s2.next_event()
    out2 = s2.send(Response(status_code=200, headers=[(b"Transfer-Encoding", b"chunked")]))
    assert b"Transfer-Encoding" not in out2 and b"Connection: close" in out2


def test_response_with_chunked_and_content_length_prefers_chunked():  # spec: N-000207
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    s.next_event()
    out = s.send(Response(status_code=200, headers=[(b"Content-Length", b"3"),
                                                    (b"Transfer-Encoding", b"chunked")]))
    assert b"content-length" not in out.lower()
    assert b"chunked" in out


def test_zero_content_length_response_keeps_header():  # spec: N-000199 (CF-000102)
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    s.next_event()
    out = s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    assert b"content-length: 0" in out


def test_close_delimited_response_body_ends_at_close():  # spec: N-000208..N-000214
    c = Connection(CLIENT)
    c.send(get_request())
    c.send(EndOfMessage())
    c.receive_data(b"HTTP/1.0 200 OK\r\n\r\nhello")
    assert isinstance(c.next_event(), Response)
    assert c.next_event() == Data(b"hello")
    assert c.next_event() is NEED_DATA
    c.receive_data(b"")
    assert c.next_event() == EndOfMessage()
    assert c.next_event() == ConnectionClosed()
    assert c.their_state is CLOSED


def test_close_mid_content_length_body_is_remote_error():  # spec: N-000324
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nContent-Length: 5\r\n\r\nab")
    s.next_event()
    assert s.next_event() == Data(b"ab")
    s.receive_data(b"")
    with pytest.raises(RemoteProtocolError):
        s.next_event()


# ---------------------------------------------------------------- FP-04 lifecycle

def test_keep_alive_cycle_and_restart():  # spec: N-000270, N-000271, N-000259
    c = Connection(CLIENT)
    s = Connection(SERVER)
    s.receive_data(c.send(get_request()) + c.send(EndOfMessage()))
    s.next_event()
    s.next_event()
    s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    c.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
    c.next_event()
    c.next_event()
    assert c.states == {CLIENT: DONE, SERVER: DONE}
    assert s.states == {CLIENT: DONE, SERVER: DONE}
    assert c.start_next_cycle() is None
    assert s.start_next_cycle() is None
    assert c.states == {CLIENT: IDLE, SERVER: IDLE}


def test_start_next_cycle_refused_is_recoverable():  # spec: N-000280..N-000282
    c = Connection(CLIENT)
    c.send(get_request())
    with pytest.raises(LocalProtocolError):
        c.start_next_cycle()
    assert c.our_state is SEND_BODY  # nothing moved, not ERROR


def test_client_second_request_refused():  # spec: N-000283..N-000285, N-000272
    c = Connection(CLIENT)
    c.send(get_request())
    c.send(EndOfMessage())
    with pytest.raises(LocalProtocolError):
        c.send(get_request())
    assert c.our_state is ERROR


def test_server_cannot_send_request_and_client_cannot_send_response():  # spec: N-000283, N-000284
    s = Connection(SERVER)
    with pytest.raises(LocalProtocolError):
        s.send(get_request())
    c = Connection(CLIENT)
    with pytest.raises(LocalProtocolError):
        c.send(Response(status_code=200, headers=[]))


def test_http10_request_forces_close():  # spec: N-000286, N-000287
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.0\r\n\r\n")
    s.next_event()
    s.next_event()
    s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    assert s.states[SERVER] is MUST_CLOSE
    assert s.states[CLIENT] is MUST_CLOSE
    with pytest.raises(LocalProtocolError):
        s.start_next_cycle()
    s.send(ConnectionClosed())
    assert s.our_state is CLOSED


def test_connection_close_token_disables_keep_alive():  # spec: N-000259..N-000262 (CF-000103)
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\nConnection: keep-alive, Close\r\n\r\n")
    s.next_event()
    s.next_event()
    out = s.send(Response(status_code=200, headers=[(b"Connection", b"keep-alive"),
                                                    (b"Content-Length", b"0")]))
    assert b"keep-alive" not in out.lower()
    assert b"connection: close" in out.lower()


def test_closed_word_does_not_disable_keep_alive():  # spec: N-000262 (CF-000103)
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\nConnection: closed-later\r\n\r\n")
    s.next_event()
    s.next_event()
    s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    assert s.our_state is DONE


def test_pipelining_is_paused_until_next_cycle():  # spec: N-000275..N-000279
    s = Connection(SERVER)
    s.receive_data(b"GET /1 HTTP/1.1\r\nHost: a\r\n\r\nGET /2 HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    s.next_event()
    assert s.next_event() is PAUSED
    s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    assert s.next_event() is PAUSED  # peer still DONE, bytes stored


def test_pipelined_request_after_cycle():  # spec: N-000275..N-000279
    c = Connection(CLIENT)
    s = Connection(SERVER)
    s.receive_data(b"GET /1 HTTP/1.1\r\nHost: a\r\n\r\nGET /2 HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    s.next_event()
    assert s.next_event() is PAUSED
    s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    # the client side still needs to be DONE for a cycle; emulate with a client
    c.send(get_request())
    c.send(EndOfMessage())
    c.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
    c.next_event()
    c.next_event()
    assert c.start_next_cycle() is None
    assert s.start_next_cycle() is None
    req = s.next_event()
    assert isinstance(req, Request) and req.target == b"/2"


# ---------------------------------------------------------------- FP-05 errors

def test_remote_error_is_sticky_and_send_still_works():  # spec: N-000302..N-000306
    s = Connection(SERVER)
    s.receive_data(b"GARBAGE\r\n\r\n")
    with pytest.raises(RemoteProtocolError):
        s.next_event()
    assert s.their_state is ERROR and s.our_state is IDLE
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    with pytest.raises(RemoteProtocolError):
        s.next_event()
    out = s.send(Response(status_code=400, headers=[(b"Content-Length", b"0")]))
    assert b"Connection: close" in out
    s.send(EndOfMessage())
    assert s.our_state is MUST_CLOSE


def test_size_limit_431():  # spec: N-000316..N-000323
    s = Connection(SERVER, 100)
    s.receive_data(b"GET / HTTP/1.1\r\nX: " + b"a" * 200)
    with pytest.raises(RemoteProtocolError) as exc:
        s.next_event()
    assert exc.value.error_status_hint == 431
    assert s.their_state is ERROR


def test_size_limit_does_not_count_body_bytes():  # spec: N-000323
    s = Connection(SERVER, 50)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nContent-Length: 500\r\n\r\n")
    s.next_event()
    s.receive_data(b"b" * 200)
    assert isinstance(s.next_event(), Data)


def test_default_size_limit_is_8k():  # spec: N-000478..N-000480 (CF-000048)
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nX: " + b"a" * (8 * 1024 + 10))
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_local_error_send_marks_our_side_error():  # spec: N-000307..N-000310
    s = Connection(SERVER)
    with pytest.raises(LocalProtocolError):
        s.send(EndOfMessage())
    assert s.our_state is ERROR
    with pytest.raises(LocalProtocolError):
        s.send(Response(status_code=200, headers=[]))


def test_send_failed_marks_error_and_done_peer_must_close():  # spec: N-000312..N-000315
    c = Connection(CLIENT)
    c.send(get_request())
    c.send(EndOfMessage())
    c.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
    c.next_event()
    c.next_event()
    assert c.our_state is DONE
    c.send_failed()
    assert c.our_state is ERROR
    assert c.their_state is MUST_CLOSE  # spec N-000311: their DONE becomes MUST_CLOSE
    with pytest.raises(LocalProtocolError):
        c.send(EndOfMessage())


def test_error_types_are_distinct():  # spec: N-000290 N-000291
    assert isinstance(LocalProtocolError("x"), hw.ProtocolError)
    assert not isinstance(LocalProtocolError("x"), RemoteProtocolError)
    assert LocalProtocolError("x", 418).error_status_hint == 418
    assert type(RemoteProtocolError("x").error_status_hint) is int
    assert str(RemoteProtocolError("message")) == "message"


# ---------------------------------------------------------------- FP-06 shutdown

def test_connection_closed_sent_from_idle_and_peer_must_close():  # spec: N-000334..N-000338
    c = Connection(CLIENT)
    s = Connection(SERVER)
    out = c.send(ConnectionClosed())
    assert out == b""
    assert c.our_state is CLOSED
    assert c.their_state is MUST_CLOSE


def test_pulled_close_after_empty_feed():  # spec: N-000339..N-000341
    s = Connection(SERVER)
    s.receive_data(b"")
    assert s.next_event() == ConnectionClosed()
    assert s.next_event() == ConnectionClosed()
    assert s.their_state is CLOSED
    assert s.our_state is MUST_CLOSE


def test_send_in_sendresponse_cannot_close():  # spec: N-000345, N-000346
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    s.next_event()
    with pytest.raises(LocalProtocolError):
        s.send(ConnectionClosed())


# ---------------------------------------------------------------- FP-07 informational / switch

def test_informational_then_final_response():  # spec: N-000349..N-000353
    c = Connection(CLIENT)
    s = Connection(SERVER)
    c.send(get_request([(b"Host", b"a"), (b"Expect", b"100-continue"),
                        (b"Content-Length", b"1")]))
    assert c.client_is_waiting_for_100_continue is True
    assert c.they_are_waiting_for_100_continue is False
    wire = b"GET / HTTP/1.1\r\nHost: a\r\nExpect: 100-continue\r\nContent-Length: 1\r\n\r\n"
    s2 = Connection(SERVER)
    s2.receive_data(wire)
    s2.next_event()
    assert s2.client_is_waiting_for_100_continue is True
    assert s2.they_are_waiting_for_100_continue is True
    s2.send(InformationalResponse(status_code=100, headers=[]))
    assert s2.client_is_waiting_for_100_continue is False


def test_expect_on_http10_sets_no_flag():  # spec: N-000357 (CF-000083)
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.0\r\nExpect: 100-continue\r\n\r\n")
    s.next_event()
    assert s.they_are_waiting_for_100_continue is False
    assert s.client_is_waiting_for_100_continue is False


def test_connect_denied_then_next_cycle():  # spec: N-000378..N-000380
    c = Connection(CLIENT)
    s = Connection(SERVER)
    wire = c.send(Request(method=b"CONNECT", target=b"example.com:443", headers=[(b"Host", b"e")]))
    c.send(EndOfMessage())
    assert c.our_state is MIGHT_SWITCH_PROTOCOL
    s.receive_data(wire)
    assert isinstance(s.next_event(), Request)
    assert s.next_event() == EndOfMessage()
    assert s.next_event() is PAUSED
    out = s.send(Response(status_code=403, headers=[(b"Content-Length", b"0")]))
    assert out.startswith(b"HTTP/1.1 403 ")
    s.send(EndOfMessage())
    # denial: client goes to DONE, server to DONE after its end-of-message
    assert s.states == {CLIENT: DONE, SERVER: DONE}
    assert c.states == {CLIENT: MIGHT_SWITCH_PROTOCOL, SERVER: SEND_RESPONSE}
    c.receive_data(b"HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\n\r\n")
    c.next_event()
    c.next_event()
    assert c.states == {CLIENT: DONE, SERVER: DONE}
    assert c.start_next_cycle() is None
    assert s.start_next_cycle() is None


def test_connect_accepted_switches_permanently():  # spec: N-000381..N-000387, N-000364
    c = Connection(CLIENT)
    s = Connection(SERVER)
    c.send(Request(method=b"CONNECT", target=b"h:1", headers=[(b"Host", b"h")]))
    c.send(EndOfMessage())
    wire_in = b"CONNECT h:1 HTTP/1.1\r\nHost: h\r\n\r\n"
    s.receive_data(wire_in)
    assert isinstance(s.next_event(), Request)
    assert s.next_event() == EndOfMessage()
    assert s.their_state is MIGHT_SWITCH_PROTOCOL
    assert s.next_event() is PAUSED  # server-role pulls wait for the answer (N-000373..N-000377)
    out = s.send(Response(status_code=200, headers=[]))
    assert out.startswith(b"HTTP/1.1 200 ")
    assert s.our_state is SWITCHED_PROTOCOL and s.their_state is SWITCHED_PROTOCOL
    with pytest.raises(LocalProtocolError):
        s.send(EndOfMessage())
    s.receive_data(b"raw protocol bytes")
    assert s.next_event() is PAUSED
    assert s.trailing_data == (b"raw protocol bytes", False)


def test_upgrade_101_accepts_and_client_side_follows():  # spec: N-000366..N-000368, N-000381
    c = Connection(CLIENT)
    c.send(Request(method=b"GET", target=b"/ws", headers=[(b"Host", b"h"), (b"Upgrade", b"websocket"),
                                                          (b"Connection", b"Upgrade")]))
    c.send(EndOfMessage())
    c.receive_data(b"HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n\r\nextra")
    resp = c.next_event()
    assert isinstance(resp, InformationalResponse) and resp.status_code == 101
    assert c.our_state is SWITCHED_PROTOCOL
    assert c.next_event() is PAUSED
    assert c.trailing_data == (b"extra", False)


def test_client_in_might_switch_cannot_send_request():  # spec: N-000392, N-000393
    c = Connection(CLIENT)
    c.send(Request(method=b"CONNECT", target=b"h:1", headers=[(b"Host", b"h")]))
    c.send(EndOfMessage())
    with pytest.raises(LocalProtocolError):
        c.send(get_request())


def test_status_codes_for_switch_kinds_are_kind_checked():  # spec: N-000394..N-000398
    with pytest.raises(LocalProtocolError):
        Response(status_code=101, headers=[])
    with pytest.raises(LocalProtocolError):
        InformationalResponse(status_code=200, headers=[])


def test_server_pipelined_request_after_denial_is_next_cycle_request():  # spec: N-000378..N-000380
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\nUpgrade: x\r\n\r\n")
    s.next_event()
    s.next_event()
    assert s.our_state is SEND_RESPONSE
    s.send(Response(status_code=426, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    assert s.our_state is DONE


# ---------------------------------------------------------------- additional coverage

def test_100_continue_client_keeps_sending_body():  # spec: N-000349..N-000353
    c = Connection(CLIENT)
    s = Connection(SERVER)
    head = c.send(get_request([(b"Host", b"a"), (b"Expect", b"100-continue"),
                               (b"Content-Length", b"3")]))
    s.receive_data(head)
    assert isinstance(s.next_event(), Request)
    assert s.they_are_waiting_for_100_continue is True
    # the client keeps waiting; its body events do not end the wait (N-000353, CF-000105)
    assert c.send(Data(b"abc")) == b"abc"
    assert c.send(EndOfMessage()) == b""
    s.receive_data(b"abc")
    assert s.next_event() == Data(b"abc")
    assert s.next_event() == EndOfMessage()
    cont = s.send(InformationalResponse(status_code=100, headers=[]))
    assert cont == b"HTTP/1.1 100 \r\n\r\n"
    s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    c.receive_data(cont + b"HTTP/1.1 200 \r\ncontent-length: 0\r\n\r\n")
    assert isinstance(c.next_event(), InformationalResponse)
    assert c.client_is_waiting_for_100_continue is False
    assert isinstance(c.next_event(), Response)
    assert c.next_event() == EndOfMessage()
    assert c.states == {CLIENT: DONE, SERVER: DONE}


def test_chunked_trailers_round_trip():  # spec: N-000193 N-000195 N-000197
    c = Connection(CLIENT)
    s = Connection(SERVER)
    wire = c.send(get_request([(b"Host", b"a"), (b"Transfer-Encoding", b"chunked")]))
    wire += c.send(Data(b"hi"))
    wire += c.send(EndOfMessage(headers=[(b"X-Digest", b"abc")]))
    s.receive_data(wire)
    s.next_event()
    assert s.next_event() == Data(b"hi", chunk_start=True, chunk_end=True)
    assert s.next_event() == EndOfMessage(headers=[(b"X-Digest", b"abc")])
    assert s.their_state is DONE


def test_passthrough_bytes_payload_pieces():  # spec: N-000233 N-000234
    c = Connection(CLIENT)
    c.send(get_request([(b"Host", b"a"), (b"Content-Length", b"3")]))
    pieces = c.send_with_data_passthrough(Data(b"abc"))
    assert pieces == [b"abc"]
    assert isinstance(pieces, list)


def test_request_with_both_framing_headers_uses_content_length():  # spec: N-000096 (CF-000003)
    c = Connection(CLIENT)
    wire = c.send(get_request([(b"Host", b"a"), (b"Content-Length", b"2"),
                               (b"Transfer-Encoding", b"chunked")]))
    assert b"transfer-encoding" not in wire.lower()
    assert b"content-length: 2" in wire
    c.send(Data(b"ok"))
    assert c.send(EndOfMessage()) == b""


def test_connect_2xx_other_than_200_accepts():  # spec: N-000364 (CF-000106)
    s = Connection(SERVER)
    s.receive_data(b"CONNECT h:1 HTTP/1.1\r\nHost: h\r\n\r\n")
    s.next_event()
    s.next_event()
    s.send(Response(status_code=201, headers=[]))
    assert s.our_state is SWITCHED_PROTOCOL


def test_client_keep_alive_off_after_its_own_close_token():  # spec: N-000259 N-000264
    c = Connection(CLIENT)
    c.send(get_request([(b"Host", b"a"), (b"Connection", b"close")]))
    c.send(EndOfMessage())
    assert c.our_state is MUST_CLOSE  # DONE with keep-alive off goes to MUST_CLOSE (N-000264)
    c.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
    c.next_event()
    c.next_event()
    assert c.our_state is MUST_CLOSE
    with pytest.raises(LocalProtocolError):
        c.start_next_cycle()


def test_refused_send_does_not_stop_pulls():  # spec: N-000329 N-000331
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    with pytest.raises(LocalProtocolError):
        s.send(EndOfMessage())  # refused: nothing has been sent yet
    assert s.our_state is ERROR
    assert isinstance(s.next_event(), Request)
    assert s.next_event() == EndOfMessage()


def test_http11_response_without_framing_is_chunked():  # spec: N-000202
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    s.next_event()
    out = s.send(Response(status_code=200, headers=[]))
    assert out == b"HTTP/1.1 200 \r\nTransfer-Encoding: chunked\r\n\r\n"
    assert s.send(Data(b"hello")) == b"5\r\nhello\r\n"
    assert s.send(EndOfMessage()) == b"0\r\n\r\n"


def test_incomplete_chunk_terminator_wait():  # spec: N-000242 N-000245
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\n1\r\nx")
    s.next_event()
    assert s.next_event() == Data(b"x", chunk_start=True, chunk_end=True)
    assert s.next_event() is NEED_DATA  # waiting for the CRLF after chunk data
    s.receive_data(b"\r\n0\r\n\r\n")
    assert s.next_event() == EndOfMessage()
