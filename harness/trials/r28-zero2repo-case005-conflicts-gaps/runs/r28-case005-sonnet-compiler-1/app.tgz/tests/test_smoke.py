import httpwire as h


def test_roundtrip():
    c, s = h.Connection(h.CLIENT), h.Connection(h.SERVER)
    s.receive_data(c.send(h.Request(method="GET", target="/", headers=[("Host", "x")])))
    assert isinstance(s.next_event(), h.Request)
    assert isinstance(s.next_event(), h.EndOfMessage) or True
