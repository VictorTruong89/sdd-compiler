class _ProtocolError(Exception):
    def __init__(self, msg="", error_status_hint=400):
        if type(self) is _ProtocolError:
            raise TypeError("tried to directly instantiate _ProtocolError")
        Exception.__init__(self, msg)
        self.error_status_hint = int(error_status_hint)

    def _reraise_as_remote_protocol_error(self):
        if type(self) is RemoteProtocolError:
            raise self
        new = RemoteProtocolError(str(self), self.error_status_hint)
        raise new from self


class LocalProtocolError(_ProtocolError):
    pass


class RemoteProtocolError(_ProtocolError):
    pass
