class _Sentinel:
    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return self._name

    def __reduce__(self):
        return self._name


def _mk(name):
    return _Sentinel(name)


CLIENT = _mk("CLIENT")
SERVER = _mk("SERVER")
NEED_DATA = _mk("NEED_DATA")
PAUSED = _mk("PAUSED")
IDLE = _mk("IDLE")
SEND_RESPONSE = _mk("SEND_RESPONSE")
SEND_BODY = _mk("SEND_BODY")
DONE = _mk("DONE")
MUST_CLOSE = _mk("MUST_CLOSE")
CLOSED = _mk("CLOSED")
MIGHT_SWITCH_PROTOCOL = _mk("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = _mk("SWITCHED_PROTOCOL")
ERROR = _mk("ERROR")
