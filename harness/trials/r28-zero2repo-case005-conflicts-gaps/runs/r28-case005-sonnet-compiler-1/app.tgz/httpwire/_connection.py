import re

from ._errors import LocalProtocolError, RemoteProtocolError
from ._events import (ConnectionClosed, Data, EndOfMessage, Headers,
                      InformationalResponse, Request, Response)
from ._states import (CLIENT, CLOSED, DONE, ERROR, IDLE, MIGHT_SWITCH_PROTOCOL,
                      MUST_CLOSE, NEED_DATA, PAUSED, SEND_BODY, SEND_RESPONSE,
                      SERVER, SWITCHED_PROTOCOL)

DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 16 * 1024
MAX_CHUNK_SIZE_DIGITS = 32

_SWITCH_UPGRADE = "_SWITCH_UPGRADE"
_SWITCH_CONNECT = "_SWITCH_CONNECT"

_TOKEN = rb"[-!#$%&'*+.^_`|~0-9a-zA-Z]+"
_request_line_re = re.compile(
    rb"(?P<method>" + _TOKEN + rb") (?P<target>[\x21-\x7e]+) HTTP/(?P<http_version>[0-9]\.[0-9])")
_status_line_re = re.compile(
    rb"HTTP/(?P<http_version>[0-9]\.[0-9]) (?P<status_code>[0-9]{3})(?: (?P<reason>[^\x00-\x08\x0a-\x1f\x7f]*))?")
_header_re = re.compile(rb"(?P<name>" + _TOKEN + rb"):[ \t]*(?P<value>.*?)[ \t]*", re.S)
_chunk_re = re.compile(
    rb"(?P<size>[0-9a-fA-F]{1,%d})(?:;[^\r\n]*)?[ \t]*" % MAX_CHUNK_SIZE_DIGITS)

EVENT_TRANSITIONS = {
    CLIENT: {
        IDLE: {Request: SEND_BODY, ConnectionClosed: CLOSED},
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
        CLOSED: {ConnectionClosed: CLOSED},
        MIGHT_SWITCH_PROTOCOL: {},
        SWITCHED_PROTOCOL: {},
        ERROR: {},
    },
    SERVER: {
        IDLE: {ConnectionClosed: CLOSED, Response: SEND_BODY,
               (Request, CLIENT): SEND_RESPONSE},
        SEND_RESPONSE: {InformationalResponse: SEND_RESPONSE,
                        Response: SEND_BODY,
                        (InformationalResponse, _SWITCH_UPGRADE): SWITCHED_PROTOCOL,
                        (Response, _SWITCH_CONNECT): SWITCHED_PROTOCOL},
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
        CLOSED: {ConnectionClosed: CLOSED},
        SWITCHED_PROTOCOL: {},
        ERROR: {},
    },
}

STATE_TRANSITIONS = {
    (MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL): {CLIENT: SWITCHED_PROTOCOL},
    (CLOSED, DONE): {SERVER: MUST_CLOSE},
    (CLOSED, IDLE): {SERVER: MUST_CLOSE},
    (ERROR, DONE): {SERVER: MUST_CLOSE},
    (DONE, CLOSED): {CLIENT: MUST_CLOSE},
    (IDLE, CLOSED): {CLIENT: MUST_CLOSE},
    (DONE, ERROR): {CLIENT: MUST_CLOSE},
}


class _StateMachine:
    def __init__(self):
        self.reset()

    def reset(self):
        self.states = {CLIENT: IDLE, SERVER: IDLE}
        self.keep_alive = True
        self.pending = set()

    def _fire_state(self):
        while True:
            start = dict(self.states)
            if self.pending and self.states[CLIENT] is DONE:
                self.states[CLIENT] = MIGHT_SWITCH_PROTOCOL
            if not self.pending and self.states[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                self.states[CLIENT] = DONE
            if not self.keep_alive:
                for r in (CLIENT, SERVER):
                    if self.states[r] is DONE:
                        self.states[r] = MUST_CLOSE
            joint = (self.states[CLIENT], self.states[SERVER])
            self.states.update(STATE_TRANSITIONS.get(joint, {}))
            if self.states == start:
                break

    def _fire_event(self, role, key):
        try:
            new = EVENT_TRANSITIONS[role][self.states[role]][key]
        except (KeyError, TypeError):
            raise LocalProtocolError("can't handle event type %s when role=%r and state=%r"
                                     % (getattr(key, "__name__", key), role,
                                        self.states[role]))
        self.states[role] = new

    def process_event(self, role, event_type, server_switch=None):
        key = event_type
        if server_switch is not None:
            if server_switch not in self.pending:
                raise LocalProtocolError(
                    "Received server %s event without a pending proposal" % server_switch)
            key = (event_type, server_switch)
        if server_switch is None and event_type is Response:
            self.pending.clear()
        self._fire_event(role, key)
        if event_type is Request:
            self._fire_event(SERVER, (Request, CLIENT))
        self._fire_state()

    def add_proposal(self, p):
        self.pending.add(p)
        self._fire_state()

    def keep_alive_disabled(self):
        self.keep_alive = False
        self._fire_state()

    def process_error(self, role):
        self.states[role] = ERROR
        self._fire_state()

    def start_next_cycle(self):
        if self.states != {CLIENT: DONE, SERVER: DONE}:
            raise LocalProtocolError("not in a reusable state")
        self.reset()


# ---------- header helpers ----------

def _comma_header(headers, name):
    out = []
    for n, v in headers:
        if n == name:
            for piece in v.split(b","):
                piece = piece.strip(b" \t")
                if piece:
                    out.append(piece.lower())
    return out


def _set_comma_header(headers, name, values):
    full = [(r, n, v) for r, n, v in headers._full if n != name]
    for v in values:
        full.append((name.title(), name, v))
    return Headers(full)


def _delete_header(headers, name):
    return Headers([(r, n, v) for r, n, v in headers._full if n != name])


def _keep_alive(event):
    if b"close" in _comma_header(event.headers, b"connection"):
        return False
    if event.http_version < b"1.1":
        return False
    return True


def _body_framing(method, event):
    if type(event) is Response:
        if (event.status_code in (204, 304) or method == b"HEAD"
                or (method == b"CONNECT" and 200 <= event.status_code < 300)):
            return ("content-length", 0)
    if _comma_header(event.headers, b"transfer-encoding"):
        return ("chunked", None)
    cl = _comma_header(event.headers, b"content-length")
    if cl:
        return ("content-length", int(cl[0]))
    if type(event) is Request:
        return ("content-length", 0)
    return ("http/1.0", None)


# ---------- receive buffer ----------

_multi_re = re.compile(rb"\n\r?\n")
_split_re = re.compile(rb"\r?\n")


class _Buf:
    def __init__(self):
        self.data = bytearray()

    def __len__(self):
        return len(self.data)

    def take(self, n):
        out = bytes(self.data[:n])
        del self.data[:n]
        return out

    def extract_lines(self):
        d = self.data
        if d[:1] == b"\n":
            del d[:1]
            return []
        if d[:2] == b"\r\n":
            del d[:2]
            return []
        m = _multi_re.search(d)
        if m is None:
            return None
        block = self.take(m.end())
        return _split_re.split(block)[:-2]

    def extract_line(self):
        i = self.data.find(b"\r\n")
        if i < 0:
            return None
        line = self.take(i)
        del self.data[:2]
        return line

    def at_most(self, n):
        if not self.data:
            return None
        return self.take(n)

    def obviously_invalid_line(self):
        return bool(self.data) and self.data[0] < 0x21


def _fold(lines):
    last = None
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            if last is None:
                raise LocalProtocolError("continuation line at start of headers")
            last = last + b" " + line.lstrip(b" \t")
        else:
            if last is not None:
                yield last
            last = line
    if last is not None:
        yield last


def _decode_headers(lines):
    out = []
    for line in _fold(lines):
        m = _header_re.fullmatch(line)
        if m is None:
            raise LocalProtocolError("illegal header line: %r" % line)
        out.append((m.group("name"), m.group("value")))
    return out


# ---------- readers ----------

def _read_request(buf):
    lines = buf.extract_lines()
    if lines is None:
        if buf.obviously_invalid_line():
            raise LocalProtocolError("illegal request line")
        return None
    if not lines:
        raise LocalProtocolError("no request line received")
    m = _request_line_re.fullmatch(lines[0])
    if m is None:
        raise LocalProtocolError("illegal request line: %r" % lines[0])
    return Request(headers=_decode_headers(lines[1:]), **m.groupdict())


def _read_response(buf):
    lines = buf.extract_lines()
    if lines is None:
        if buf.obviously_invalid_line():
            raise LocalProtocolError("illegal status line")
        return None
    if not lines:
        raise LocalProtocolError("no response line received")
    m = _status_line_re.fullmatch(lines[0])
    if m is None:
        raise LocalProtocolError("illegal status line: %r" % lines[0])
    code = int(m.group("status_code"))
    cls = InformationalResponse if code < 200 else Response
    return cls(headers=_decode_headers(lines[1:]), status_code=code,
               http_version=m.group("http_version"),
               reason=m.group("reason") or b"")


def _expect_nothing(buf):
    if buf.data:
        raise LocalProtocolError("Got data when expecting EOF")
    return None


class _CLReader:
    def __init__(self, n):
        self.remaining = n
        self.expected = n

    def __call__(self, buf):
        if self.remaining == 0:
            return EndOfMessage()
        data = buf.at_most(self.remaining)
        if data is None:
            return None
        self.remaining -= len(data)
        return Data(data=data)

    def read_eof(self):
        raise RemoteProtocolError(
            "peer closed connection without sending complete message body "
            "(received %d bytes, expected %d)" % (self.expected - self.remaining, self.expected))


class _ChunkedReader:
    def __init__(self):
        self.in_chunk = 0
        self.discard = 0  # CRLF bytes still to verify
        self.trailer = False

    def __call__(self, buf):
        if self.trailer:
            lines = buf.extract_lines()
            if lines is None:
                return None
            return EndOfMessage(headers=_decode_headers(lines))
        if self.discard > 0:
            avail = bytes(buf.data[:self.discard])
            want = b"\r\n"[2 - self.discard:2 - self.discard + len(avail)]
            if avail != want:
                raise LocalProtocolError("chunk not terminated by CRLF")
            buf.take(len(avail))
            self.discard -= len(avail)
            if self.discard > 0:
                return None
        if self.in_chunk == 0:
            header = buf.extract_line()
            if header is None:
                return None
            m = _chunk_re.fullmatch(header)
            if m is None:
                raise LocalProtocolError("illegal chunk header: %r" % header)
            self.in_chunk = int(m.group("size"), 16)
            if self.in_chunk == 0:
                self.trailer = True
                return self(buf)
            start = True
        else:
            start = False
        data = buf.at_most(self.in_chunk)
        if data is None:
            return None
        self.in_chunk -= len(data)
        end = self.in_chunk == 0
        if end:
            self.discard = 2
        return Data(data=data, chunk_start=start, chunk_end=end)

    def read_eof(self):
        raise RemoteProtocolError("peer closed connection without sending complete message body (incomplete chunked read)")


class _Http10Reader:
    def __call__(self, buf):
        return None if not buf.data else Data(data=buf.take(len(buf.data)))

    def read_eof(self):
        return EndOfMessage()


# ---------- writers ----------

def _write_headers(headers, write):
    raw = headers._full
    for r, n, v in raw:
        if n == b"host":
            write(b"%s: %s\r\n" % (r, v))
    for r, n, v in raw:
        if n != b"host":
            write(b"%s: %s\r\n" % (r, v))
    write(b"\r\n")


def _write_request(ev, write):
    if ev.http_version != b"1.1":
        raise LocalProtocolError("I only send HTTP/1.1")
    write(b"%s %s HTTP/1.1\r\n" % (ev.method, ev.target))
    _write_headers(ev.headers, write)


def _write_response(ev, write):
    if ev.http_version != b"1.1":
        raise LocalProtocolError("I only send HTTP/1.1")
    write(b"HTTP/1.1 %d %s\r\n" % (ev.status_code, ev.reason))
    _write_headers(ev.headers, write)


class _CLWriter:
    def __init__(self, n):
        self.remaining = n

    def __call__(self, ev, write):
        if type(ev) is Data:
            self.remaining -= len(ev.data)
            if self.remaining < 0:
                raise LocalProtocolError("Too much data for declared Content-Length")
            write(ev.data)
        else:
            if self.remaining != 0:
                raise LocalProtocolError("Too little data for declared Content-Length")
            if len(ev.headers):
                raise LocalProtocolError("Content-Length and trailers don't mix")


class _ChunkedWriter:
    def __call__(self, ev, write):
        if type(ev) is Data:
            n = len(ev.data)
            if n:
                write(b"%x\r\n" % n)
                write(ev.data)
                write(b"\r\n")
        else:
            write(b"0\r\n")
            _write_headers(ev.headers, write)


class _Http10Writer:
    def __call__(self, ev, write):
        if type(ev) is Data:
            write(ev.data)
        elif len(ev.headers):
            raise LocalProtocolError("can't send trailers to HTTP/1.0 client")


def _make_reader(framing):
    kind, n = framing
    if kind == "content-length":
        return _CLReader(n)
    if kind == "chunked":
        return _ChunkedReader()
    return _Http10Reader()


def _make_writer(framing):
    kind, n = framing
    if kind == "content-length":
        return _CLWriter(n)
    if kind == "chunked":
        return _ChunkedWriter()
    return _Http10Writer()


class Connection:
    def __init__(self, role, max_incomplete_event_size=DEFAULT_MAX_INCOMPLETE_EVENT_SIZE):
        if role is not CLIENT and role is not SERVER:
            raise ValueError("expected CLIENT or SERVER, not %r" % (role,))
        self.our_role = role
        self.their_role = SERVER if role is CLIENT else CLIENT
        self._cstate = _StateMachine()
        self._max = max_incomplete_event_size
        self._buf = _Buf()
        self._closed = False
        self._reader = None
        self._writer = None
        self._request_method = None
        self.their_http_version = None
        self.client_is_waiting_for_100_continue = False

    # ----- attributes -----
    @property
    def states(self):
        return dict(self._cstate.states)

    @property
    def our_state(self):
        return self._cstate.states[self.our_role]

    @property
    def their_state(self):
        return self._cstate.states[self.their_role]

    @property
    def they_are_waiting_for_100_continue(self):
        return self.their_role is CLIENT and self.client_is_waiting_for_100_continue

    @property
    def trailing_data(self):
        return (bytes(self._buf.data), self._closed)

    # ----- internals -----
    def _process_error(self, role):
        self._cstate.process_error(role)

    def _server_switch_event(self, event):
        if type(event) is InformationalResponse and event.status_code == 101:
            return _SWITCH_UPGRADE
        if type(event) is Response:
            if _SWITCH_CONNECT in self._cstate.pending and event.status_code == 200:
                return _SWITCH_CONNECT
        return None

    def _process_event(self, role, event):
        old = dict(self._cstate.states)
        cs = self._cstate
        if role is CLIENT and type(event) is Request:
            if event.method == b"CONNECT":
                cs.add_proposal(_SWITCH_CONNECT)
            if _comma_header(event.headers, b"upgrade"):
                cs.add_proposal(_SWITCH_UPGRADE)
        sw = self._server_switch_event(event) if role is SERVER else None
        cs.process_event(role, type(event), sw)
        t = type(event)
        if t is Request:
            self._request_method = event.method
        if role is self.their_role and t in (Request, Response, InformationalResponse):
            self.their_http_version = event.http_version
        if t in (Request, Response):
            if not _keep_alive(event):
                cs.keep_alive_disabled()
            elif t is Response and _body_framing(self._request_method, event)[0] == "http/1.0":
                cs.keep_alive_disabled()
        if t is Request and event.http_version == b"1.1" and \
                b"100-continue" in _comma_header(event.headers, b"expect"):
            self.client_is_waiting_for_100_continue = True
        if t in (InformationalResponse, Response):
            self.client_is_waiting_for_100_continue = False
        if role is CLIENT and t in (Data, EndOfMessage):
            self.client_is_waiting_for_100_continue = False
        if cs.states != old:
            new_state = cs.states
            if new_state[self.our_role] != old[self.our_role] and \
                    new_state[self.our_role] is SEND_BODY:
                self._writer = _make_writer(_body_framing(self._request_method, event))
            if new_state[self.their_role] != old[self.their_role] and \
                    new_state[self.their_role] is SEND_BODY:
                self._reader = _make_reader(_body_framing(self._request_method, event))

    def _clean_response(self, response):
        headers = response.headers
        need_close = False
        method = self._request_method
        if method == b"HEAD":
            method = b"GET"
        framing = _body_framing(method, response)[0]
        if framing in ("chunked", "http/1.0"):
            headers = _delete_header(headers, b"content-length")
            if self.their_http_version is None or self.their_http_version < b"1.1":
                headers = _delete_header(headers, b"transfer-encoding")
                if self._request_method != b"HEAD":
                    need_close = True
            else:
                headers = _set_comma_header(headers, b"transfer-encoding", [b"chunked"])
        if (not self._cstate.keep_alive or need_close
                or self.their_state is ERROR):
            conn = set(_comma_header(headers, b"connection"))
            conn.discard(b"keep-alive")
            conn.add(b"close")
            headers = _set_comma_header(headers, b"connection", sorted(conn))
        return Response(status_code=response.status_code, headers=headers,
                        http_version=response.http_version, reason=response.reason)

    # ----- public API -----
    def send(self, event):
        parts = self.send_with_data_passthrough(event)
        if parts is None:
            return None
        return b"".join(parts)

    def send_with_data_passthrough(self, event):
        if self.our_state is ERROR:
            raise LocalProtocolError("Can't send data when our state is ERROR")
        try:
            if type(event) is Response:
                event = self._clean_response(event)
            self._process_event(self.our_role, event)
            t = type(event)
            if t is ConnectionClosed:
                return None
            out = []
            if t is Request:
                _write_request(event, out.append)
            elif t in (Response, InformationalResponse):
                _write_response(event, out.append)
            else:
                self._writer(event, out.append)
            return out
        except BaseException:
            self._process_error(self.our_role)
            raise

    def receive_data(self, data):
        if data:
            if self._closed:
                raise RuntimeError("received close, then received more data?")
            self._buf.data += data
        else:
            self._closed = True

    def _extract(self):
        state = self.their_state
        if state is DONE and self._buf.data:
            return PAUSED
        if state is MIGHT_SWITCH_PROTOCOL or state is SWITCHED_PROTOCOL:
            return PAUSED
        if state is SEND_BODY:
            reader = self._reader
        elif state is IDLE and self.their_role is CLIENT:
            reader = _read_request
        elif state in (IDLE, SEND_RESPONSE) and self.their_role is SERVER:
            reader = _read_response
        else:
            reader = _expect_nothing
        event = reader(self._buf)
        if event is None:
            if not self._buf.data and self._closed:
                if hasattr(reader, "read_eof"):
                    event = reader.read_eof()
                else:
                    event = ConnectionClosed()
        if event is None:
            event = NEED_DATA
        return event

    def next_event(self):
        if self.their_state is ERROR:
            raise RemoteProtocolError("Can't receive data when peer state is ERROR")
        try:
            event = self._extract()
            if event is not NEED_DATA and event is not PAUSED:
                self._process_event(self.their_role, event)
            if event is NEED_DATA:
                if len(self._buf) > self._max:
                    raise RemoteProtocolError("Receive buffer too long",
                                              error_status_hint=431)
                if self._closed:
                    raise RemoteProtocolError("peer unexpectedly closed connection")
            return event
        except BaseException as exc:
            self._process_error(self.their_role)
            if isinstance(exc, LocalProtocolError):
                exc._reraise_as_remote_protocol_error()
            raise

    def start_next_cycle(self):
        self._cstate.start_next_cycle()
        self._request_method = None
        self.their_http_version = None
        self.client_is_waiting_for_100_continue = False
        self._reader = None
        self._writer = None

    def send_failed(self):
        self._process_error(self.our_role)
