import re

from ._errors import LocalProtocolError

_TOKEN = rb"[-!#$%&'*+.^_`|~0-9a-zA-Z]+"
_token_re = re.compile(_TOKEN)
_target_re = re.compile(rb"[\x21-\x7e]+")
_value_re = re.compile(
    rb"(?:[^\x00\r\n\x0b\x0c \t](?:[^\x00\r\n\x0b\x0c]*[^\x00\r\n\x0b\x0c \t])?)?")
_cl_re = re.compile(rb"[0-9]+")
_version_re = re.compile(rb"[0-9]\.[0-9]")
_reason_re = re.compile(rb"[^\x00\r\n]*")

CONTENT_LENGTH_MAX_DIGITS = 18


def _bytesify(x, what="value"):
    if type(x) is bytes:
        return x
    if isinstance(x, str):
        try:
            return x.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("%s must be ASCII" % what)
    if isinstance(x, bool) or isinstance(x, int):
        raise LocalProtocolError("%s must be bytes-like or ASCII str" % what)
    try:
        return bytes(memoryview(x))
    except TypeError:
        raise LocalProtocolError("%s must be bytes-like or ASCII str" % what)


class Headers:
    """Ordered header list. Iterating yields (lowercase name, value)."""

    __slots__ = ("_full",)

    def __init__(self, full):
        self._full = list(full)  # (raw_name, lower_name, value)

    def __iter__(self):
        for _, n, v in self._full:
            yield (n, v)

    def __len__(self):
        return len(self._full)

    def __getitem__(self, i):
        if isinstance(i, slice):
            return [(n, v) for _, n, v in self._full[i]]
        _, n, v = self._full[i]
        return (n, v)

    def __bool__(self):
        return bool(self._full)

    def __contains__(self, item):
        return item in list(self)

    def __eq__(self, other):
        if isinstance(other, Headers):
            return self._full == other._full
        try:
            return list(self) == [tuple(p) for p in other]
        except TypeError:
            return NotImplemented

    __hash__ = None

    def __repr__(self):
        return repr(list(self))

    def raw_items(self):
        return [(r, v) for r, _, v in self._full]


def normalize_headers(headers):
    if isinstance(headers, Headers):
        return headers
    if isinstance(headers, (str, bytes, bytearray)) or headers is None:
        raise LocalProtocolError("headers must be a sequence of (name, value) pairs")
    try:
        items = list(headers.items()) if hasattr(headers, "items") else list(headers)
    except TypeError:
        raise LocalProtocolError("headers must be a sequence of (name, value) pairs")
    out = []
    seen_cl = None
    saw_te = False
    for item in items:
        try:
            name, value = item
        except (TypeError, ValueError):
            raise LocalProtocolError("each header must be a (name, value) pair")
        raw = _bytesify(name, "header name")
        value = _bytesify(value, "header value")
        if not _token_re.fullmatch(raw):
            raise LocalProtocolError("illegal header name %r" % raw)
        if not _value_re.fullmatch(value):
            raise LocalProtocolError("illegal header value %r" % value)
        lname = raw.lower()
        if lname == b"content-length":
            lengths = {p.strip(b" \t") for p in value.split(b",")}
            if len(lengths) != 1:
                raise LocalProtocolError("conflicting Content-Length headers")
            value = lengths.pop()
            if not _cl_re.fullmatch(value) or len(value) > CONTENT_LENGTH_MAX_DIGITS:
                raise LocalProtocolError("bad Content-Length")
            if seen_cl is None:
                seen_cl = value
                out.append((raw, lname, value))
            elif seen_cl != value:
                raise LocalProtocolError("conflicting Content-Length headers")
        elif lname == b"transfer-encoding":
            if saw_te:
                raise LocalProtocolError("multiple Transfer-Encoding headers",
                                         error_status_hint=501)
            saw_te = True
            value = value.lower()
            if value != b"chunked":
                raise LocalProtocolError(
                    "Only Transfer-Encoding: chunked is supported",
                    error_status_hint=501)
            out.append((raw, lname, value))
        else:
            out.append((raw, lname, value))
    return Headers(out)


class _Event:
    def __eq__(self, other):
        return type(self) is type(other) and self.__dict__ == other.__dict__

    __hash__ = None

    def __repr__(self):
        return "<%s %s>" % (type(self).__name__, " ".join(
            "%s=%r" % kv for kv in self.__dict__.items()))


def _version(v):
    v = _bytesify(v, "http_version")
    if not _version_re.fullmatch(v):
        raise LocalProtocolError("illegal http_version %r" % v)
    return v


def _status(code, lo, hi):
    if isinstance(code, bool) or not isinstance(code, int):
        raise LocalProtocolError("status_code must be an integer")
    code = int(code)
    if not (lo <= code < hi):
        raise LocalProtocolError("status code %d out of range [%d, %d)" % (code, lo, hi))
    return code


class Request(_Event):
    def __init__(self, method, target, headers, http_version=b"1.1"):
        method = _bytesify(method, "method")
        target = _bytesify(target, "target")
        if not _token_re.fullmatch(method):
            raise LocalProtocolError("illegal method %r" % method)
        if not _target_re.fullmatch(target):
            raise LocalProtocolError("illegal request target %r" % target)
        self.method = method
        self.target = target
        self.http_version = _version(http_version)
        self.headers = normalize_headers(headers)
        hosts = sum(1 for n, _ in self.headers if n == b"host")
        if self.http_version == b"1.1" and hosts == 0:
            raise LocalProtocolError("Missing mandatory Host: header")
        if hosts > 1:
            raise LocalProtocolError("Found multiple Host: headers")


class _ResponseBase(_Event):
    _lo = _hi = 0

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        self.status_code = _status(status_code, self._lo, self._hi)
        self.http_version = _version(http_version)
        reason = _bytesify(reason, "reason")
        if not _reason_re.fullmatch(reason):
            raise LocalProtocolError("illegal reason phrase")
        self.reason = reason
        self.headers = normalize_headers(headers)


class InformationalResponse(_ResponseBase):
    _lo, _hi = 100, 200


class Response(_ResponseBase):
    _lo, _hi = 200, 1000


class Data(_Event):
    def __init__(self, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)


class EndOfMessage(_Event):
    def __init__(self, headers=None):
        self.headers = normalize_headers([] if headers is None else headers)


class ConnectionClosed(_Event):
    def __init__(self):
        pass
