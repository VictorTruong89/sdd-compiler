"""httpwire: a pure-Python, sans-I/O HTTP/1.1 wire protocol library."""
from ._util import LocalProtocolError, RemoteProtocolError
from ._events import (ConnectionClosed, Data, EndOfMessage,
                      InformationalResponse, Request, Response)
from ._connection import (CLIENT, CLOSED, Connection, DONE, ERROR, IDLE,
                          MIGHT_SWITCH_PROTOCOL, MUST_CLOSE, NEED_DATA, PAUSED,
                          SEND_BODY, SEND_RESPONSE, SERVER, SWITCHED_PROTOCOL)

__all__ = """CLIENT CLOSED Connection ConnectionClosed Data DONE EndOfMessage ERROR
IDLE InformationalResponse LocalProtocolError MIGHT_SWITCH_PROTOCOL MUST_CLOSE
NEED_DATA PAUSED RemoteProtocolError Request Response SEND_BODY SEND_RESPONSE
SERVER SWITCHED_PROTOCOL""".split()
