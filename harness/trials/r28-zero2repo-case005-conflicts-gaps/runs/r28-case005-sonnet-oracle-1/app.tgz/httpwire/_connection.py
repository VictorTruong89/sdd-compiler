import re

from ._events import (ConnectionClosed, Data, EndOfMessage, Headers,
                      InformationalResponse, Request, Response,
                      normalize_and_validate, TOKEN)
from ._util import (LocalProtocolError, RemoteProtocolError, _RoleError,
                    _Sentinel, validate)

CLIENT = _Sentinel("CLIENT")
SERVER = _Sentinel("SERVER")
NEED_DATA = _Sentinel("NEED_DATA")
PAUSED = _Sentinel("PAUSED")
IDLE = _Sentinel("IDLE")
SEND_RESPONSE = _Sentinel("SEND_RESPONSE")
SEND_BODY = _Sentinel("SEND_BODY")
DONE = _Sentinel("DONE")
MUST_CLOSE = _Sentinel("MUST_CLOSE")
CLOSED = _Sentinel("CLOSED")
MIGHT_SWITCH_PROTOCOL = _Sentinel("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = _Sentinel("SWITCHED_PROTOCOL")
ERROR = _Sentinel("ERROR")

_SWITCH_UPGRADE = _Sentinel("_SWITCH_UPGRADE")
_SWITCH_CONNECT = _Sentinel("_SWITCH_CONNECT")

DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 16 * 1024  # see NOTES.md CF-000048
MAX_CHUNK_DIGITS = 20  # see NOTES.md CF-000099

_EVENT_TRANSITIONS = {
    CLIENT: {
        IDLE: {Request: SEND_BODY, ConnectionClosed: CLOSED},
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
        CLOSED: {ConnectionClosed: CLOSED},
        MIGHT_SWITCH_PROTOCOL: {},
        SWITCHED_PROTOCOL: {},
        ERROR: {},
    },
    SERVER: {
        IDLE: {ConnectionClosed: CLOSED, Response: SEND_BODY,
               (Request, CLIENT): SEND_RESPONSE},
        SEND_RESPONSE: {InformationalResponse: SEND_RESPONSE,
                        Response: SEND_BODY,
                        (InformationalResponse, _SWITCH_UPGRADE): SWITCHED_PROTOCOL,
                        (Response, _SWITCH_CONNECT): SWITCHED_PROTOCOL},
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
        CLOSED: {ConnectionClosed: CLOSED},
        SWITCHED_PROTOCOL: {},
        ERROR: {},
    },
}

_STATE_TRANSITIONS = {
    (MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL): {CLIENT: SWITCHED_PROTOCOL},
    (CLOSED, DONE): {SERVER: MUST_CLOSE},
    (CLOSED, IDLE): {SERVER: MUST_CLOSE},
    (ERROR, DONE): {SERVER: MUST_CLOSE},
    (DONE, CLOSED): {CLIENT: MUST_CLOSE},
    (IDLE, CLOSED): {CLIENT: MUST_CLOSE},
    (DONE, ERROR): {CLIENT: MUST_CLOSE},
}


class _ConnectionState:
    def __init__(self):
        self.states = {CLIENT: IDLE, SERVER: IDLE}
        self.pending = set()
        self.keep_alive = True

    def process_event(self, role, event_type, server_switch_event=None):
        et = event_type
        if server_switch_event is not None:
            if server_switch_event not in self.pending:
                raise LocalProtocolError("server switch event without proposal")
            et = (event_type, server_switch_event)
        if server_switch_event is None and event_type is Response:
            self.pending = set()
        self._fire(role, et)
        if et is Request:
            self._fire(SERVER, (Request, CLIENT))
        self._fire_state()

    def _fire(self, role, et):
        state = self.states[role]
        try:
            self.states[role] = _EVENT_TRANSITIONS[role][state][et]
        except KeyError:
            raise LocalProtocolError(
                "can't handle event type %s when role=%r and state=%r"
                % (getattr(et, "__name__", et), role, state))

    def _fire_state(self):
        while True:
            start = dict(self.states)
            if self.pending and self.states[CLIENT] is DONE:
                self.states[CLIENT] = MIGHT_SWITCH_PROTOCOL
            if not self.pending and self.states[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                self.states[CLIENT] = DONE
            if not self.keep_alive:
                for r in (CLIENT, SERVER):
                    if self.states[r] is DONE:
                        self.states[r] = MUST_CLOSE
            joint = (self.states[CLIENT], self.states[SERVER])
            self.states.update(_STATE_TRANSITIONS.get(joint, {}))
            if self.states == start:
                break

    def process_error(self, role):
        self.states[role] = ERROR
        self._fire_state()

    def disable_keep_alive(self):
        self.keep_alive = False
        self._fire_state()

    def start_next_cycle(self):
        if self.states != {CLIENT: DONE, SERVER: DONE}:
            raise LocalProtocolError(
                "not in a reusable state: %r" % (self.states,))
        self.states = {CLIENT: IDLE, SERVER: IDLE}


# ---- header helpers -------------------------------------------------------

def _comma_header(headers, name):
    out = []
    for _, n, v in headers._full:
        if n == name:
            for piece in v.split(b","):
                piece = piece.strip(b" \t").lower()
                if piece:
                    out.append(piece)
    return out


def _set_comma_header(pairs, name, values):
    new = [(r, v) for r, v in pairs if r.lower() != name]
    for v in values:
        new.append((name, v))
    return new


def _keep_alive(event):
    if b"close" in _comma_header(event.headers, b"connection"):
        return False
    if event.http_version < b"1.1":
        return False
    return True


def _expect_100(event):
    return event.http_version == b"1.1" and \
        b"100-continue" in _comma_header(event.headers, b"expect")


def _body_framing(method, event):
    if type(event) is Response:
        if (event.status_code in (204, 304) or method == b"HEAD"
                or (method == b"CONNECT" and 200 <= event.status_code < 300)):
            return ("content-length", (0,))
    if _comma_header(event.headers, b"transfer-encoding"):
        return ("chunked", ())
    cl = _comma_header(event.headers, b"content-length")
    if cl:
        return ("content-length", (int(cl[0]),))
    if type(event) is Request:
        return ("content-length", (0,))
    return ("http/1.0", ())


# ---- writers --------------------------------------------------------------

def _write_headers(headers, write, request=False):
    items = headers.raw_items()
    if request:
        hosts = [i for i in items if i[0].lower() == b"host"]
        rest = [i for i in items if i[0].lower() != b"host"]
        items = hosts + rest
    for n, v in items:
        write(n + b": " + v + b"\r\n")
    write(b"\r\n")


def _write_request(ev, write):
    if ev.http_version != b"1.1":
        raise LocalProtocolError("I only send HTTP/1.1")
    write(ev.method + b" " + ev.target + b" HTTP/1.1\r\n")
    _write_headers(ev.headers, write, request=True)


def _write_response(ev, write):
    if ev.http_version != b"1.1":
        raise LocalProtocolError("I only send HTTP/1.1")
    write(b"HTTP/1.1 " + str(ev.status_code).encode("ascii") + b" " + ev.reason + b"\r\n")
    _write_headers(ev.headers, write)


class _CLWriter:
    def __init__(self, length):
        self.left = length

    def __call__(self, ev, write):
        if type(ev) is Data:
            self.left -= len(ev.data)
            if self.left < 0:
                raise LocalProtocolError("Too much data for declared Content-Length")
            write(ev.data)
        elif type(ev) is EndOfMessage:
            if self.left != 0:
                raise LocalProtocolError("Too little data for declared Content-Length")
            if len(ev.headers):
                raise LocalProtocolError("Content-Length and trailers don't mix")


class _ChunkedWriter:
    def __call__(self, ev, write):
        if type(ev) is Data:
            n = len(ev.data)
            if n == 0:
                return
            write(b"%x\r\n" % n)
            write(ev.data)
            write(b"\r\n")
        elif type(ev) is EndOfMessage:
            write(b"0\r\n")
            _write_headers(ev.headers, write)


class _HTTP10Writer:
    def __call__(self, ev, write):
        if type(ev) is Data:
            write(ev.data)
        elif type(ev) is EndOfMessage:
            if len(ev.headers):
                raise LocalProtocolError("can't send trailers to HTTP/1.0 client")


def _no_more_data_writer(ev, write):
    raise LocalProtocolError("no more data can be sent in this state")


# ---- readers --------------------------------------------------------------

_request_line_re = re.compile(
    rb"(?P<method>" + TOKEN.encode() + rb") (?P<target>[\x21-\x7e]+) HTTP/(?P<ver>[0-9]\.[0-9])")
_status_line_re = re.compile(
    rb"HTTP/(?P<ver>[0-9]\.[0-9]) (?P<code>[0-9]{3}) (?P<reason>[^\r\n]*)")
_header_line_re = re.compile(
    rb"(?P<name>" + TOKEN.encode() + rb"):[ \t]*(?P<value>.*?)[ \t]*", re.S)
_chunk_re = re.compile(
    rb"(?P<size>[0-9a-fA-F]{1,%d})[ \t]*(;[^\r\n]*)?[ \t]*" % MAX_CHUNK_DIGITS)
_block_end_re = re.compile(rb"\r?\n\r?\n")
_eol_re = re.compile(rb"\r?\n")


class _Buffer:
    def __init__(self):
        self.data = bytearray()

    def __len__(self):
        return len(self.data)

    def __bool__(self):
        return bool(self.data)

    def extract_at_most(self, n):
        if not self.data:
            return None
        out = bytes(self.data[:n])
        del self.data[:n]
        return out

    def extract_line(self):
        m = _eol_re.search(self.data)
        if m is None:
            return None
        line = bytes(self.data[:m.start()])
        del self.data[:m.end()]
        return line

    def extract_lines(self):
        d = self.data
        if d[:1] == b"\n":
            del d[:1]
            return []
        if d[:2] == b"\r\n":
            del d[:2]
            return []
        m = _block_end_re.search(d)
        if m is None:
            return None
        block = bytes(d[:m.start()])
        del d[:m.end()]
        return _eol_re.split(block)

    def obviously_invalid_line(self):
        return bool(self.data) and self.data[0] < 0x21


def _decode_headers(lines):
    joined = []
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            if not joined:
                raise LocalProtocolError("continuation line at start of headers")
            joined[-1] = joined[-1] + b" " + line.lstrip(b" \t")
        else:
            joined.append(line)
    out = []
    for line in joined:
        m = validate(_header_line_re, line, "illegal header line: {!r}", line)
        out.append((m.group("name"), m.group("value")))
    return out


def _read_request(buf):
    lines = buf.extract_lines()
    if lines is None:
        if buf.obviously_invalid_line():
            raise LocalProtocolError("illegal request line")
        return None
    if not lines:
        raise LocalProtocolError("no request line received")
    m = validate(_request_line_re, lines[0], "illegal request line: {!r}", lines[0])
    return Request(method=m.group("method"), target=m.group("target"),
                   headers=_decode_headers(lines[1:]), http_version=m.group("ver"))


def _read_response(buf):
    lines = buf.extract_lines()
    if lines is None:
        if buf.obviously_invalid_line():
            raise LocalProtocolError("illegal status line")
        return None
    if not lines:
        raise LocalProtocolError("no response line received")
    m = validate(_status_line_re, lines[0], "illegal status line: {!r}", lines[0])
    code = int(m.group("code"))
    cls = InformationalResponse if code < 200 else Response
    return cls(status_code=code, headers=_decode_headers(lines[1:]),
               http_version=m.group("ver"), reason=m.group("reason"))


class _ExpectNothing:
    def __call__(self, buf):
        if buf:
            raise LocalProtocolError("Got data when expecting EOF")
        return None


class _CLReader:
    def __init__(self, length):
        self.left = length

    def __call__(self, buf):
        if self.left == 0:
            return EndOfMessage()
        data = buf.extract_at_most(self.left)
        if data is None:
            return None
        self.left -= len(data)
        return Data(data=data)

    def read_eof(self):
        raise RemoteProtocolError(
            "peer closed connection without sending complete message: "
            "%d more bytes expected" % self.left)


class _ChunkedReader:
    def __init__(self):
        self.in_chunk = 0
        self.discard = 0
        self.trailer = False
        self.start_pending = False

    def __call__(self, buf):
        if self.trailer:
            lines = buf.extract_lines()
            if lines is None:
                return None
            return EndOfMessage(headers=_decode_headers(lines))
        if self.discard > 0:
            if len(buf) < self.discard:
                # verify what we have is a CRLF prefix
                if bytes(buf.data) != b"\r\n"[:len(buf)]:
                    raise LocalProtocolError("chunk not terminated by CRLF")
                return None
            if bytes(buf.data[:2]) != b"\r\n":
                raise LocalProtocolError("chunk not terminated by CRLF")
            del buf.data[:2]
            self.discard = 0
        if self.in_chunk == 0:
            line = buf.extract_line()
            if line is None:
                if len(buf) > 0 and len(buf) > 8192 and False:
                    pass
                return None
            m = validate(_chunk_re, line, "illegal chunk header: {!r}", line)
            self.in_chunk = int(m.group("size"), 16)
            if self.in_chunk == 0:
                self.trailer = True
                return self(buf)
            self.start_pending = True
        data = buf.extract_at_most(self.in_chunk)
        if data is None:
            return None
        self.in_chunk -= len(data)
        start = self.start_pending
        self.start_pending = False
        end = self.in_chunk == 0
        if end:
            self.discard = 2
        return Data(data=data, chunk_start=start, chunk_end=end)

    def read_eof(self):
        raise RemoteProtocolError("peer closed connection without sending complete message (chunked)")


class _HTTP10Reader:
    def __call__(self, buf):
        data = buf.extract_at_most(1 << 30)
        if data is None:
            return None
        return Data(data=data)

    def read_eof(self):
        return EndOfMessage()


def _make_reader(framing, args):
    if framing == "content-length":
        return _CLReader(*args)
    if framing == "chunked":
        return _ChunkedReader()
    return _HTTP10Reader()


def _make_writer(framing, args):
    if framing == "content-length":
        return _CLWriter(*args)
    if framing == "chunked":
        return _ChunkedWriter()
    return _HTTP10Writer()


_EXPECT_NOTHING = _ExpectNothing()


class Connection:
    def __init__(self, role, max_incomplete_event_size=DEFAULT_MAX_INCOMPLETE_EVENT_SIZE):
        if role is not CLIENT and role is not SERVER:
            raise _RoleError("role must be CLIENT or SERVER")
        self.our_role = role
        self.their_role = SERVER if role is CLIENT else CLIENT
        self._cstate = _ConnectionState()
        self._max = max_incomplete_event_size
        self._buf = _Buffer()
        self._closed = False
        self.their_http_version = None
        self._request_method = None
        self.client_is_waiting_for_100_continue = False
        self._writer = self._io(self.our_role, None, True)
        self._reader = self._io(self.their_role, None, False)

    # -- properties
    @property
    def states(self):
        return dict(self._cstate.states)

    @property
    def our_state(self):
        return self._cstate.states[self.our_role]

    @property
    def their_state(self):
        return self._cstate.states[self.their_role]

    @property
    def they_are_waiting_for_100_continue(self):
        return self.their_role is CLIENT and self.client_is_waiting_for_100_continue

    @property
    def trailing_data(self):
        return (bytes(self._buf.data), self._closed)

    # -- io selection
    def _io(self, role, event, writer):
        state = self._cstate.states[role]
        if state is SEND_BODY:
            f, a = _body_framing(self._request_method, event)
            return _make_writer(f, a) if writer else _make_reader(f, a)
        if writer:
            if (role, state) in ((CLIENT, IDLE),):
                return _write_request
            if role is SERVER and state in (IDLE, SEND_RESPONSE):
                return _write_response
            if state in (DONE, MUST_CLOSE, CLOSED):
                return _no_more_data_writer
            return None
        if (role, state) == (CLIENT, IDLE):
            return _read_request
        if role is SERVER and state in (IDLE, SEND_RESPONSE):
            return _read_response
        if state in (DONE, MUST_CLOSE, CLOSED):
            return _EXPECT_NOTHING
        return None

    def _respond_to_state_changes(self, old, event=None):
        if self.our_state is not old[self.our_role]:
            self._writer = self._io(self.our_role, event, True)
        if self.their_state is not old[self.their_role]:
            self._reader = self._io(self.their_role, event, False)

    def _process_event(self, role, event):
        old = dict(self._cstate.states)
        cs = self._cstate
        t = type(event)
        if role is CLIENT and t is Request:
            if event.method == b"CONNECT":
                cs.pending.add(_SWITCH_CONNECT)
            if _comma_header(event.headers, b"upgrade"):
                cs.pending.add(_SWITCH_UPGRADE)
        sw = None
        if role is SERVER:
            if t is InformationalResponse and event.status_code == 101:
                sw = _SWITCH_UPGRADE
            elif (t is Response and _SWITCH_CONNECT in cs.pending
                  and 200 <= event.status_code < 300):
                sw = _SWITCH_CONNECT
        if t is Request:
            self._request_method = event.method
        cs.process_event(role, t, sw)
        if t in (Request, Response):
            if not _keep_alive(event):
                cs.disable_keep_alive()
            elif t is Response and \
                    _body_framing(self._request_method, event)[0] == "http/1.0":
                cs.disable_keep_alive()
        if t is Request and _expect_100(event):
            self.client_is_waiting_for_100_continue = True
        if t in (InformationalResponse, Response):
            self.client_is_waiting_for_100_continue = False
        if role is CLIENT and t in (Data, EndOfMessage):
            self.client_is_waiting_for_100_continue = False
        if cs.states != old:
            self._respond_to_state_changes(old, event)

    def _process_error(self, role):
        self._cstate.process_error(role)

    # -- send
    def _clean_response(self, resp):
        method = self._request_method
        if method == b"HEAD":
            method = b"GET"
        framing, _ = _body_framing(method, resp)
        pairs = resp.headers.raw_items()
        if framing in ("chunked", "http/1.0"):
            pairs = [(r, v) for r, v in pairs
                     if r.lower() not in (b"content-length", b"transfer-encoding")]
            if self.their_http_version is None or self.their_http_version < b"1.1":
                self._cstate.disable_keep_alive()
            else:
                pairs.append((b"transfer-encoding", b"chunked"))
        if not self._cstate.keep_alive or self.their_state is ERROR:
            tmp = normalize_and_validate(pairs)
            conn = set(_comma_header(tmp, b"connection"))
            conn.discard(b"keep-alive")
            conn.add(b"close")
            pairs = _set_comma_header(pairs, b"connection", sorted(conn))
        return Response(status_code=resp.status_code, headers=pairs,
                        http_version=resp.http_version, reason=resp.reason)

    def send_with_data_passthrough(self, event):
        if self.our_state is ERROR:
            raise LocalProtocolError("Can't send data when our state is ERROR")
        try:
            if type(event) not in (Request, InformationalResponse, Response,
                                   Data, EndOfMessage, ConnectionClosed):
                raise LocalProtocolError("not an event: %r" % (event,))
            if type(event) is Response:
                event = self._clean_response(event)
            writer = self._writer
            self._process_event(self.our_role, event)
            if type(event) is ConnectionClosed:
                return []
            pieces = []
            writer(event, pieces.append)
            return pieces
        except BaseException:
            self._process_error(self.our_role)
            raise

    def send(self, event):
        pieces = self.send_with_data_passthrough(event)
        return b"".join(bytes(p) if not isinstance(p, bytes) else p for p in pieces)

    def send_failed(self):
        self._process_error(self.our_role)

    def start_next_cycle(self):
        old = dict(self._cstate.states)
        self._cstate.start_next_cycle()
        self._request_method = None
        self.client_is_waiting_for_100_continue = False
        self._respond_to_state_changes(old)

    # -- receive
    def receive_data(self, data):
        if data:
            if self._closed:
                raise RuntimeError("received close, then received more data?")
            self._buf.data += data
        else:
            self._closed = True

    def _extract(self):
        state = self.their_state
        if state is DONE and self._buf:
            return PAUSED
        if state in (MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL):
            return PAUSED
        reader = self._reader
        if reader is None:
            raise LocalProtocolError("can't receive in state %r" % (state,))
        event = reader(self._buf)
        if event is None:
            if not self._buf and self._closed:
                if hasattr(reader, "read_eof"):
                    event = reader.read_eof()
                else:
                    event = ConnectionClosed()
        if event is None:
            event = NEED_DATA
        return event

    def next_event(self):
        if self.their_state is ERROR:
            raise RemoteProtocolError("Can't receive data when peer state is ERROR")
        try:
            event = self._extract()
            if event is not NEED_DATA and event is not PAUSED:
                self._process_event(self.their_role, event)
                if type(event) in (Request, Response, InformationalResponse):
                    pass
                if type(event) in (Request, Response):
                    self.their_http_version = event.http_version
            if event is NEED_DATA:
                if len(self._buf) > self._max:
                    raise RemoteProtocolError("Receive buffer too long", 431)
                if self._closed:
                    raise RemoteProtocolError("peer unexpectedly closed connection")
            return event
        except BaseException as exc:
            self._process_error(self.their_role)
            if isinstance(exc, LocalProtocolError):
                exc._reraise_as_remote_protocol_error()
            raise
