import re
from collections.abc import Sequence

from ._util import LocalProtocolError, bytesify, validate

# spec: N-000106 N-000107 N-000097
TOKEN = r"[-!#$%&'*+.^_`|~0-9a-zA-Z]+"
_name_re = re.compile(TOKEN.encode())
_value_re = re.compile(rb"([^\x00\s]+([ \t]+[^\x00\s]+)*)?")
_cl_re = re.compile(rb"[0-9]+")
_target_re = re.compile(rb"[\x21-\x7e]+")
_version_re = re.compile(rb"[0-9]\.[0-9]")
MAX_CL_DIGITS = 18  # spec: N-000116 (see NOTES.md CF-000098)


class Headers(Sequence):
    """Header list: iterates as (lowercase name, value); raw_items() keeps case."""

    def __init__(self, full):
        self._full = list(full)  # (raw_name, lower_name, value)

    def __len__(self):
        return len(self._full)

    def __getitem__(self, i):
        if isinstance(i, slice):
            return [(l, v) for _, l, v in self._full[i]]
        _, l, v = self._full[i]
        return (l, v)

    def __iter__(self):
        for _, l, v in self._full:
            yield (l, v)

    def raw_items(self):
        return [(r, v) for r, _, v in self._full]

    def __eq__(self, other):
        if isinstance(other, Headers):
            return self._full == other._full
        try:
            return list(self) == [(bytesify(a).lower(), bytesify(b)) for a, b in other]
        except Exception:
            return False

    __hash__ = None

    def __repr__(self):
        return repr(list(self))


def normalize_and_validate(headers):
    full = []
    seen_cl = None
    saw_te = False
    if headers is None:
        headers = []
    try:
        pairs = list(headers)
    except TypeError:
        raise LocalProtocolError("headers must be a sequence of pairs")
    for item in pairs:
        try:
            name, value = item
        except (TypeError, ValueError):
            raise LocalProtocolError("header must be a (name, value) pair")
        name = bytesify(name)
        value = bytesify(value)
        validate(_name_re, name, "Illegal header name {!r}", name)
        validate(_value_re, value, "Illegal header value {!r}", value)
        raw = name
        name = name.lower()
        if name == b"content-length":
            lengths = {p.strip(b" \t") for p in value.split(b",")}
            if len(lengths) != 1:
                raise LocalProtocolError("conflicting Content-Length headers")
            value = lengths.pop()
            validate(_cl_re, value, "bad Content-Length")
            if len(value) > MAX_CL_DIGITS:
                raise LocalProtocolError("bad Content-Length")
            if seen_cl is None:
                seen_cl = value
                full.append((raw, name, value))
            elif seen_cl != value:
                raise LocalProtocolError("conflicting Content-Length headers")
        elif name == b"transfer-encoding":
            if saw_te:
                raise LocalProtocolError("multiple Transfer-Encoding headers", 501)
            value = value.lower()
            if value != b"chunked":
                raise LocalProtocolError(
                    "Only Transfer-Encoding: chunked is supported", 501)
            saw_te = True
            full.append((raw, name, value))
        else:
            full.append((raw, name, value))
    return Headers(full)


class _Event:
    _fields = ()

    def __repr__(self):
        return "%s(%s)" % (type(self).__name__, ", ".join(
            "%s=%r" % (f, getattr(self, f)) for f in self._fields))

    def __eq__(self, other):
        return type(other) is type(self) and all(
            getattr(self, f) == getattr(other, f) for f in self._fields)

    __hash__ = None


def _version(v):
    v = bytesify(v)
    validate(_version_re, v, "bad HTTP version {!r}", v)
    return v


class Request(_Event):
    _fields = ("method", "target", "headers", "http_version")

    def __init__(self, method, target, headers=None, http_version=b"1.1"):
        self.method = bytesify(method)
        validate(_name_re, self.method, "Illegal method {!r}", self.method)
        self.target = bytesify(target)
        validate(_target_re, self.target, "Illegal target {!r}", self.target)
        self.http_version = _version(http_version)
        self.headers = normalize_and_validate(headers)
        hosts = sum(1 for _, n, _v in self.headers._full if n == b"host")
        if self.http_version == b"1.1" and hosts == 0:
            raise LocalProtocolError("Missing mandatory Host: header")
        if hosts > 1:
            raise LocalProtocolError("Found multiple Host: headers")


class _ResponseBase(_Event):
    _fields = ("status_code", "headers", "http_version", "reason")
    _lo = 0
    _hi = 0

    def __init__(self, status_code, headers=None, http_version=b"1.1", reason=b""):
        if isinstance(status_code, bool) or not isinstance(status_code, int):
            raise LocalProtocolError("status code must be integer")
        self.status_code = int(status_code)
        if not (self._lo <= self.status_code < self._hi):
            raise LocalProtocolError(
                "Illegal status code %d for %s" % (self.status_code, type(self).__name__))
        self.http_version = _version(http_version)
        self.reason = bytesify(reason)
        if re.search(rb"[\r\n]", self.reason):
            raise LocalProtocolError("Illegal reason phrase")
        self.headers = normalize_and_validate(headers)


class InformationalResponse(_ResponseBase):
    _lo, _hi = 100, 200


class Response(_ResponseBase):
    _lo, _hi = 200, 1000


class Data(_Event):
    _fields = ("data", "chunk_start", "chunk_end")

    def __init__(self, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)


class EndOfMessage(_Event):
    _fields = ("headers",)

    def __init__(self, headers=None):
        self.headers = normalize_and_validate(headers)


class ConnectionClosed(_Event):
    _fields = ()

    def __init__(self):
        pass
