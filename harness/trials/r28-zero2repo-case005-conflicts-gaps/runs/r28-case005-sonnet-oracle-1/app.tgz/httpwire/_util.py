# spec: N-000446 N-000447 N-000448 N-000472 N-000474
import re


class ProtocolError(Exception):
    """Common base (private); Local and Remote are siblings."""

    def __init__(self, msg="protocol error", error_status_hint=400):
        super().__init__(msg)
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(ProtocolError):
    def _reraise_as_remote_protocol_error(self):
        new = RemoteProtocolError(str(self), self.error_status_hint)
        raise new.with_traceback(self.__traceback__)


class RemoteProtocolError(ProtocolError):
    pass


class _RoleError(LocalProtocolError, ValueError):
    pass


class _Sentinel:
    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return self._name

    def __copy__(self):
        return self

    def __deepcopy__(self, memo):
        return self


def validate(regex, data, msg, *fmt, status=400):
    m = regex.fullmatch(data)
    if m is None:
        raise LocalProtocolError(msg.format(*fmt) if fmt else msg, status)
    return m


def bytesify(s):
    if isinstance(s, bytes):
        return s
    if isinstance(s, str):
        try:
            return s.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("expected ASCII text, got %r" % (s,))
    if isinstance(s, (bytearray, memoryview)):
        return bytes(s)
    if isinstance(s, int):
        raise LocalProtocolError("expected bytes-like, got int")
    try:
        return bytes(memoryview(s))
    except TypeError:
        raise LocalProtocolError("expected bytes-like, got %r" % type(s))
