"""HTTP event types and header normalization (PRD FP-01)."""

from ._util import (
    BAD_REASON_RE,
    BAD_VALUE_RE,
    DIGITS_RE,
    TARGET_RE,
    TOKEN_RE,
    VERSION_RE,
    LocalProtocolError,
    to_bytes,
)

# Decided in NOTES.md (conflict 1): PRD allows 18 digits; contract says 16.
MAX_CONTENT_LENGTH_DIGITS = 18


def _check_version(value):
    version = to_bytes(value, "HTTP version")
    if not VERSION_RE.fullmatch(version):
        raise LocalProtocolError("invalid HTTP version %r" % (version,))
    return version


def _check_status(code, low, high):
    if not isinstance(code, int):
        raise LocalProtocolError("status code must be an integer")
    code = int(code)
    if not (low <= code < high):
        raise LocalProtocolError("status code %d is out of range" % code)
    return code


def _check_reason(reason):
    reason = to_bytes(reason, "reason phrase")
    if BAD_REASON_RE.search(reason):
        raise LocalProtocolError("reason phrase contains a forbidden byte")
    return reason


def normalize_headers(pairs):
    """Validate and normalize a header list.

    Returns a list of ``(raw_name, value)`` byte pairs. ``raw_name`` keeps the
    caller's spelling; ``Transfer-Encoding`` values are normalized and repeated
    ``Content-Length`` values are collapsed.
    """
    try:
        given = list(pairs)
    except TypeError:
        raise LocalProtocolError("headers must be a sequence of (name, value) pairs")

    items = []
    for pair in given:
        try:
            name, value = pair
        except (TypeError, ValueError):
            raise LocalProtocolError("each header must be a (name, value) pair")
        name = to_bytes(name, "header name")
        value = to_bytes(value, "header value")
        if not TOKEN_RE.fullmatch(name):
            raise LocalProtocolError("invalid header name %r" % (name,))
        if BAD_VALUE_RE.search(value):
            raise LocalProtocolError("forbidden byte in value of header %r" % (name,))
        if value[:1] in (b" ", b"\t") or value[-1:] in (b" ", b"\t"):
            raise LocalProtocolError(
                "value of header %r begins or ends with space or tab" % (name,)
            )
        items.append((name, value))

    # Transfer-Encoding: exactly one header, exactly "chunked" (any case).
    te = [i for i, (n, _) in enumerate(items) if n.lower() == b"transfer-encoding"]
    if len(te) > 1:
        raise LocalProtocolError("multiple Transfer-Encoding headers", 501)
    if te:
        name, value = items[te[0]]
        if value.lower() != b"chunked":
            raise LocalProtocolError("unsupported Transfer-Encoding %r" % (value,), 501)
        items[te[0]] = (name, b"chunked")

    # Content-Length: decimal digits only; all values must agree; collapse to one.
    cl = [i for i, (n, _) in enumerate(items) if n.lower() == b"content-length"]
    if cl:
        pieces = []
        for i in cl:
            for piece in items[i][1].split(b","):
                piece = piece.strip(b" \t")
                if not DIGITS_RE.fullmatch(piece) or len(piece) > MAX_CONTENT_LENGTH_DIGITS:
                    raise LocalProtocolError("invalid Content-Length value")
                pieces.append(piece)
        first = pieces[0]
        if any(int(p) != int(first) for p in pieces):
            raise LocalProtocolError("conflicting Content-Length values")
        collapsed = []
        for i, (n, v) in enumerate(items):
            if i == cl[0]:
                collapsed.append((n, first))
            elif i not in cl:
                collapsed.append((n, v))
        items = collapsed

    return items


class Headers(object):
    """Header list: ordinary (lowercased) view plus ``raw_items()``."""

    __slots__ = ("_raw",)

    def __init__(self, raw_items):
        self._raw = tuple(raw_items)

    def _ordinary(self):
        return [(n.lower(), v) for n, v in self._raw]

    def raw_items(self):
        return list(self._raw)

    def __iter__(self):
        return iter(self._ordinary())

    def __len__(self):
        return len(self._raw)

    def __getitem__(self, index):
        return self._ordinary()[index]

    def __eq__(self, other):
        if isinstance(other, Headers):
            return self._ordinary() == other._ordinary()
        if isinstance(other, (list, tuple)):
            return self._ordinary() == [tuple(p) for p in other]
        return NotImplemented

    __hash__ = None

    def __repr__(self):
        return "Headers(%r)" % (self._ordinary(),)


class Request(object):
    __slots__ = ("method", "target", "headers", "http_version")

    def __init__(self, method, target, headers, http_version=b"1.1"):
        method = to_bytes(method, "method")
        if not TOKEN_RE.fullmatch(method):
            raise LocalProtocolError("invalid request method %r" % (method,))
        target = to_bytes(target, "request target")
        if not TARGET_RE.fullmatch(target):
            raise LocalProtocolError("invalid request target %r" % (target,))
        version = _check_version(http_version)
        items = normalize_headers(headers)
        hosts = [v for n, v in items if n.lower() == b"host"]
        if len(hosts) > 1:
            raise LocalProtocolError("request has more than one Host header")
        if version == b"1.1" and not hosts:
            raise LocalProtocolError("HTTP/1.1 request needs exactly one Host header")
        self.method = method
        self.target = target
        self.headers = Headers(items)
        self.http_version = version

    def __repr__(self):
        return "Request(method=%r, target=%r, headers=%r, http_version=%r)" % (
            self.method, self.target, self.headers, self.http_version)


class InformationalResponse(object):
    __slots__ = ("status_code", "headers", "http_version", "reason")

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        self.status_code = _check_status(status_code, 100, 200)
        self.headers = Headers(normalize_headers(headers))
        self.http_version = _check_version(http_version)
        self.reason = _check_reason(reason)

    def __repr__(self):
        return "InformationalResponse(status_code=%r, headers=%r)" % (
            self.status_code, self.headers)


class Response(object):
    __slots__ = ("status_code", "headers", "http_version", "reason")

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        self.status_code = _check_status(status_code, 200, 1000)
        self.headers = Headers(normalize_headers(headers))
        self.http_version = _check_version(http_version)
        self.reason = _check_reason(reason)

    def __repr__(self):
        return "Response(status_code=%r, headers=%r)" % (self.status_code, self.headers)


class Data(object):
    __slots__ = ("data", "chunk_start", "chunk_end")

    def __init__(self, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)

    def __repr__(self):
        return "Data(data=%r, chunk_start=%r, chunk_end=%r)" % (
            self.data, self.chunk_start, self.chunk_end)


class EndOfMessage(object):
    __slots__ = ("headers",)

    def __init__(self, headers=()):
        self.headers = Headers(normalize_headers(headers))

    def __repr__(self):
        return "EndOfMessage(headers=%r)" % (self.headers,)


class ConnectionClosed(object):
    __slots__ = ()

    def __repr__(self):
        return "ConnectionClosed()"
