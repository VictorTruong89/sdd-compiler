"""The bring-your-own-I/O connection object (PRD FP-02..FP-07)."""

import re

from ._events import (
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    Request,
    Response,
)
from ._util import (
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
    TOKEN_RE,
    LocalProtocolError,
    RemoteProtocolError,
)

# Decided in NOTES.md (conflict 2): PRD requires 14..18 KiB; contract says 8 KiB.
DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 16 * 1024

# Decided in NOTES.md (conflict 3): 16..32 digits allowed; 32 chosen.
MAX_CHUNK_SIZE_DIGITS = 32

_CHUNK_SIZE_RE = re.compile(rb"([0-9A-Fa-f]+)[ \t]*(?:;[^\r\n]*)?")
_REQUEST_LINE_RE = re.compile(
    rb"([!#$%&'*+\-.^_`|~0-9A-Za-z]+) ([\x21-\x7e]+) HTTP/([0-9]\.[0-9])"
)
_STATUS_LINE_RE = re.compile(rb"HTTP/([0-9]\.[0-9]) ([0-9]{3})(?: ([^\x00\r\n]*))?")


# ---------------------------------------------------------------------------
# Raw header helpers. ``raw`` is a list of (raw_name, value) byte pairs.
# ---------------------------------------------------------------------------

def _has_header(raw, name):
    return any(n.lower() == name for n, _ in raw)


def _drop_header(raw, name):
    return [(n, v) for n, v in raw if n.lower() != name]


def _header_tokens(raw, name):
    out = []
    for n, v in raw:
        if n.lower() == name:
            for piece in v.split(b","):
                piece = piece.strip(b" \t").lower()
                if piece:
                    out.append(piece)
    return out


def _content_length(raw):
    for n, v in raw:
        if n.lower() == b"content-length":
            return int(v)
    return None


def _render(raw):
    return [n + b": " + v + b"\r\n" for n, v in raw]


def _rewrite_connection(raw):
    """Drop keep-alive tokens from Connection and make sure ``close`` is present."""
    out = []
    has_close = False
    for n, v in raw:
        if n.lower() == b"connection":
            keep = []
            for piece in v.split(b","):
                piece = piece.strip(b" \t")
                if piece and piece.lower() != b"keep-alive":
                    keep.append(piece)
            if any(p.lower() == b"close" for p in keep):
                has_close = True
            if keep:
                out.append((n, b", ".join(keep)))
        else:
            out.append((n, v))
    if not has_close:
        out.append((b"Connection", b"close"))
    return out


def _request_framing(raw):
    if _has_header(raw, b"transfer-encoding"):
        return _Framing("chunked")
    cl = _content_length(raw)
    return _Framing("cl", 0 if cl is None else cl)


def _response_framing(raw, status, request_method):
    if status < 200 or status in (204, 304) or request_method == b"HEAD":
        return _Framing("empty")
    if _has_header(raw, b"transfer-encoding"):
        return _Framing("chunked")
    cl = _content_length(raw)
    if cl is not None:
        return _Framing("cl", cl)
    return _Framing("close")


class _Framing(object):
    """Body framing for one message. kind: empty | cl | close | chunked."""

    __slots__ = ("kind", "remaining", "stage", "chunk_remaining", "chunk_started")

    def __init__(self, kind, remaining=0):
        self.kind = kind
        self.remaining = remaining
        self.stage = "size"
        self.chunk_remaining = 0
        self.chunk_started = False


def _find_block(buf):
    """Return (lines, consumed) for a header block ending in a blank line, else None.

    Accepts CRLF and lone-LF line endings. The blank line is not included.
    """
    pos = 0
    lines = []
    while True:
        idx = buf.find(b"\n", pos)
        if idx < 0:
            return None
        line = bytes(buf[pos:idx])
        if line.endswith(b"\r"):
            line = line[:-1]
        pos = idx + 1
        if not line:
            return lines, pos
        lines.append(line)


def _remote_construct(cls, *args, **kwargs):
    try:
        return cls(*args, **kwargs)
    except LocalProtocolError as exc:
        raise RemoteProtocolError(str(exc), exc.error_status_hint)


def _parse_fields(lines):
    """Parse header lines from the wire, joining obsolete line folds."""
    items = []
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            if not items:
                raise RemoteProtocolError("header line continues nothing")
            name, value = items[-1]
            cont = line.lstrip(b" \t")
            value = (value + b" " + cont) if value else cont
            items[-1] = (name, value)
            continue
        name, sep, value = line.partition(b":")
        if not sep or not TOKEN_RE.fullmatch(name):
            raise RemoteProtocolError("malformed header line")
        items.append((name, value.strip(b" \t")))
    return [(n, v.strip(b" \t")) for n, v in items]


class Connection(object):
    """One HTTP/1.1 connection in the client or server role. Performs no I/O."""

    def __init__(self, role, max_incomplete_event_size=DEFAULT_MAX_INCOMPLETE_EVENT_SIZE):
        if role is not CLIENT and role is not SERVER:
            raise ValueError("role must be CLIENT or SERVER, not %r" % (role,))
        self._our_role = role
        self._their_role = SERVER if role is CLIENT else CLIENT
        self._states = {CLIENT: IDLE, SERVER: IDLE}
        self._max_size = int(max_incomplete_event_size)
        self._buf = bytearray()
        self._closed_in = False
        self._recv_error = None
        self._their_http_version = None
        self._keep_alive = True
        self._cycle_method = None
        self._proposal_kinds = frozenset()
        self._proposal_status = None  # None | pending | accepted | denied
        self._client_waiting = False
        self._send_framing = None
        self._recv_framing = None

    # -- read-only attributes -------------------------------------------------

    @property
    def our_role(self):
        return self._our_role

    @property
    def their_role(self):
        return self._their_role

    @property
    def our_state(self):
        return self._states[self._our_role]

    @property
    def their_state(self):
        return self._states[self._their_role]

    @property
    def states(self):
        return {CLIENT: self._states[CLIENT], SERVER: self._states[SERVER]}

    @property
    def their_http_version(self):
        return self._their_http_version

    @property
    def client_is_waiting_for_100_continue(self):
        return bool(self._client_waiting)

    @property
    def they_are_waiting_for_100_continue(self):
        return self._our_role is SERVER and bool(self._client_waiting)

    @property
    def trailing_data(self):
        return (bytes(self._buf), bool(self._closed_in))

    # -- public operations ----------------------------------------------------

    def send(self, event):
        return b"".join(self._send_event(event, passthrough=False))

    def send_with_data_passthrough(self, event):
        return self._send_event(event, passthrough=True)

    def receive_data(self, data):
        if memoryview(data).nbytes == 0:
            self._closed_in = True
            return None
        if self._closed_in:
            raise RuntimeError("received data after the peer closed its side")
        self._buf.extend(data)
        return None

    def next_event(self):
        if self._recv_error is not None:
            raise RemoteProtocolError(
                str(self._recv_error), self._recv_error.error_status_hint)
        S = self._states
        if S[self._our_role] is SWITCHED_PROTOCOL or S[self._their_role] is SWITCHED_PROTOCOL:
            return PAUSED
        st = S[self._their_role]
        if st is CLOSED:
            return ConnectionClosed()
        if st is MIGHT_SWITCH_PROTOCOL:
            return PAUSED
        if st is DONE or st is MUST_CLOSE:
            if self._buf:
                return PAUSED
            if self._closed_in:
                return self._pull_close()
            return NEED_DATA
        if st is SEND_BODY:
            return self._pull_body()
        return self._pull_head()

    def start_next_cycle(self):
        S = self._states
        if S[CLIENT] is not DONE or S[SERVER] is not DONE:
            raise LocalProtocolError(
                "cannot start next cycle: client is %r, server is %r"
                % (S[CLIENT], S[SERVER]))
        S[CLIENT] = IDLE
        S[SERVER] = IDLE
        self._keep_alive = True
        self._cycle_method = None
        self._proposal_kinds = frozenset()
        self._proposal_status = None
        self._client_waiting = False
        self._send_framing = None
        self._recv_framing = None

    def send_failed(self):
        self._states[self._our_role] = ERROR
        self._normalize()
        return None

    # -- state machine helpers ------------------------------------------------

    def _other(self, role):
        return SERVER if role is CLIENT else CLIENT

    def _normalize(self):
        S = self._states
        if not self._keep_alive:
            for role in (CLIENT, SERVER):
                if S[role] is DONE:
                    S[role] = MUST_CLOSE
        for role in (CLIENT, SERVER):
            other = self._other(role)
            if S[other] is ERROR and S[role] is DONE:
                S[role] = MUST_CLOSE
            if S[other] is CLOSED and (S[role] is IDLE or S[role] is DONE):
                S[role] = MUST_CLOSE

    def _decide(self, event):
        """For a pending switch proposal, return 'accept', 'deny', or None."""
        kinds = self._proposal_kinds
        if not kinds or self._proposal_status != "pending":
            return None
        t = type(event)
        if t is InformationalResponse:
            if event.status_code == 101 and "upgrade" in kinds:
                return "accept"
            return None
        if t is Response:
            if "connect" in kinds and 200 <= event.status_code < 300:
                return "accept"
            return "deny"
        return None

    def _apply_decision(self, decision):
        if decision == "accept":
            self._proposal_status = "accepted"
        elif decision == "deny":
            self._proposal_status = "denied"

    def _on_request(self, event):
        raw = event.headers.raw_items()
        self._cycle_method = event.method
        kinds = set()
        if event.method == b"CONNECT":
            kinds.add("connect")
        if _has_header(raw, b"upgrade"):
            kinds.add("upgrade")
        self._proposal_kinds = frozenset(kinds)
        self._proposal_status = "pending" if kinds else None
        if event.http_version == b"1.1" and b"100-continue" in _header_tokens(raw, b"expect"):
            self._client_waiting = True

    def _keep_alive_check(self, event):
        if event.http_version != b"1.1":
            self._keep_alive = False
        elif b"close" in _header_tokens(event.headers.raw_items(), b"connection"):
            self._keep_alive = False

    def _transition(self, sender, event, decision):
        """Apply the state change for one event, sent or pulled, from ``sender``."""
        S = self._states
        recv = self._other(sender)
        t = type(event)
        if t is Request:
            if S[sender] is IDLE:
                S[sender] = SEND_BODY
            if S[recv] is IDLE:
                S[recv] = SEND_RESPONSE
            self._keep_alive_check(event)
        elif t is InformationalResponse:
            if sender is SERVER:
                self._client_waiting = False
            if decision == "accept":
                S[sender] = SWITCHED_PROTOCOL
                if S[recv] is MIGHT_SWITCH_PROTOCOL:
                    S[recv] = SWITCHED_PROTOCOL
        elif t is Response:
            self._client_waiting = False
            self._keep_alive_check(event)
            if decision == "accept":
                S[sender] = SWITCHED_PROTOCOL
                if S[recv] is MIGHT_SWITCH_PROTOCOL:
                    S[recv] = SWITCHED_PROTOCOL
            else:
                S[sender] = SEND_BODY
                if decision == "deny" and S[recv] is MIGHT_SWITCH_PROTOCOL:
                    S[recv] = DONE
        elif t is Data:
            if sender is CLIENT:
                self._client_waiting = False
        elif t is EndOfMessage:
            if sender is CLIENT:
                self._client_waiting = False
            if S[sender] is SEND_BODY:
                if sender is CLIENT and self._proposal_kinds:
                    if self._proposal_status == "accepted":
                        S[sender] = SWITCHED_PROTOCOL
                    elif self._proposal_status == "denied":
                        S[sender] = DONE
                    else:
                        S[sender] = MIGHT_SWITCH_PROTOCOL
                else:
                    S[sender] = DONE
        elif t is ConnectionClosed:
            S[sender] = CLOSED
        self._normalize()

    # -- sending --------------------------------------------------------------

    def _send_event(self, event, passthrough):
        try:
            return self._send_checked(event, passthrough)
        except LocalProtocolError:
            self._states[self._our_role] = ERROR
            self._normalize()
            raise

    def _send_checked(self, event, passthrough):
        S = self._states
        our = self._our_role
        t = type(event)
        if S[our] is ERROR:
            raise LocalProtocolError("connection is in the ERROR state")
        if t is Request:
            return self._send_request(event)
        if t is InformationalResponse or t is Response:
            return self._send_response(event)
        if t is Data:
            return self._send_data(event, passthrough)
        if t is EndOfMessage:
            return self._send_eom(event)
        if t is ConnectionClosed:
            if S[our] is not IDLE and S[our] is not DONE and S[our] is not MUST_CLOSE:
                raise LocalProtocolError("cannot send connection-closed in state %r" % (S[our],))
            self._transition(our, event, None)
            return []
        raise LocalProtocolError("not an HTTP event: %r" % (event,))

    def _send_request(self, event):
        S = self._states
        if self._our_role is not CLIENT:
            raise LocalProtocolError("a server cannot send a request")
        if S[CLIENT] is not IDLE:
            raise LocalProtocolError("cannot send a request in state %r" % (S[CLIENT],))
        if event.http_version != b"1.1":
            raise LocalProtocolError("only HTTP/1.1 requests can be sent")
        raw = event.headers.raw_items()
        if _has_header(raw, b"transfer-encoding"):
            framing = _Framing("chunked")
            raw = _drop_header(raw, b"content-length")
        else:
            cl = _content_length(raw)
            framing = _Framing("cl", 0 if cl is None else cl)
        hosts = [h for h in raw if h[0].lower() == b"host"]
        others = [h for h in raw if h[0].lower() != b"host"]
        start = event.method + b" " + event.target + b" HTTP/1.1"
        pieces = [start + b"\r\n"] + _render(hosts + others) + [b"\r\n"]
        self._send_framing = framing
        self._on_request(event)
        self._transition(CLIENT, event, None)
        return pieces

    def _final_response_framing(self, event, raw):
        """Return (wire_headers, framing, keep_alive_ok) for a final response."""
        peer = self._their_http_version
        ka_ok = peer == b"1.1" and b"close" not in _header_tokens(raw, b"connection")
        status = event.status_code
        if status in (204, 304):
            return raw, _Framing("empty"), ka_ok
        if _has_header(raw, b"transfer-encoding"):
            if peer == b"1.1":
                wire = _drop_header(raw, b"content-length")
                framing = _Framing("chunked")
            else:
                wire = _drop_header(_drop_header(raw, b"transfer-encoding"), b"content-length")
                framing = _Framing("close")
                ka_ok = False
        else:
            cl = _content_length(raw)
            if cl is not None:
                wire = raw
                framing = _Framing("cl", cl)
            elif peer == b"1.1":
                wire = raw + [(b"Transfer-Encoding", b"chunked")]
                framing = _Framing("chunked")
            else:
                wire = raw
                framing = _Framing("close")
                ka_ok = False
        if self._cycle_method == b"HEAD":
            framing = _Framing("empty")
        return wire, framing, ka_ok

    def _send_response(self, event):
        S = self._states
        our = self._our_role
        if our is not SERVER:
            raise LocalProtocolError("a client cannot send a response")
        info = type(event) is InformationalResponse
        if info:
            if S[our] is not SEND_RESPONSE:
                raise LocalProtocolError("cannot send an informational response in state %r"
                                         % (S[our],))
        elif S[our] is not IDLE and S[our] is not SEND_RESPONSE:
            raise LocalProtocolError("cannot send a response in state %r" % (S[our],))
        if event.http_version != b"1.1":
            raise LocalProtocolError("only HTTP/1.1 responses can be sent")
        raw = event.headers.raw_items()
        decision = self._decide(event)
        new_keep = self._keep_alive
        if info or decision == "accept":
            wire = raw
            framing = None
        else:
            wire, framing, ka_ok = self._final_response_framing(event, raw)
            new_keep = self._keep_alive and ka_ok
            if not new_keep:
                wire = _rewrite_connection(wire)
        start = b"HTTP/1.1 %03d %s" % (event.status_code, event.reason)
        pieces = [start + b"\r\n"] + _render(wire) + [b"\r\n"]
        self._send_framing = framing
        self._keep_alive = new_keep
        self._apply_decision(decision)
        self._transition(SERVER, event, decision)
        return pieces

    def _send_data(self, event, passthrough):
        S = self._states
        our = self._our_role
        if S[our] is not SEND_BODY:
            raise LocalProtocolError("cannot send body data in state %r" % (S[our],))
        payload = event.data
        if isinstance(payload, str):
            raise LocalProtocolError("body payload must be bytes-like")
        try:
            n = memoryview(payload).nbytes
        except TypeError:
            if not passthrough:
                raise LocalProtocolError("body payload must be bytes-like")
            try:
                n = len(payload)
            except TypeError:
                raise LocalProtocolError("body payload has no length")
        framing = self._send_framing
        if framing.kind == "cl" and n > framing.remaining:
            raise LocalProtocolError("body data exceeds the declared Content-Length")
        if framing.kind == "empty" and n:
            raise LocalProtocolError("this message has no body")
        if n == 0:
            pieces = []
        elif framing.kind == "chunked":
            pieces = [b"%x\r\n" % n, payload, b"\r\n"]
        else:
            pieces = [payload]
        if framing.kind == "cl":
            framing.remaining -= n
        self._transition(our, event, None)
        return pieces

    def _send_eom(self, event):
        S = self._states
        our = self._our_role
        if S[our] is not SEND_BODY:
            raise LocalProtocolError("cannot end a message in state %r" % (S[our],))
        raw = event.headers.raw_items()
        framing = self._send_framing
        if framing.kind == "chunked":
            pieces = [b"0\r\n"] + _render(raw) + [b"\r\n"]
        else:
            if framing.kind == "cl" and framing.remaining != 0:
                raise LocalProtocolError("message ended before its Content-Length was sent")
            if raw:
                raise LocalProtocolError("trailers are only allowed with chunked framing")
            pieces = []
        self._send_framing = None
        self._transition(our, event, None)
        return pieces

    # -- receiving ------------------------------------------------------------

    def _fail_recv(self, exc):
        if not isinstance(exc, RemoteProtocolError):
            exc = RemoteProtocolError(str(exc), 400)
        self._recv_error = exc
        self._states[self._their_role] = ERROR
        self._normalize()
        raise exc

    def _pull_close(self):
        self._states[self._their_role] = CLOSED
        self._normalize()
        return ConnectionClosed()

    def _finish_recv(self, event):
        self._recv_framing = None
        self._transition(self._their_role, event, None)
        return event

    def _pull_head(self):
        buf = self._buf
        their = self._their_role
        if not buf:
            if self._closed_in:
                if self._states[their] is IDLE:
                    return self._pull_close()
                self._fail_recv(RemoteProtocolError(
                    "connection closed in the middle of a message"))
            return NEED_DATA
        if buf[0] <= 32:
            self._fail_recv(RemoteProtocolError(
                "message starts with a space or control byte"))
        block = _find_block(buf)
        if block is None:
            if self._closed_in:
                self._fail_recv(RemoteProtocolError(
                    "connection closed in the middle of a header block"))
            if len(buf) > self._max_size:
                self._fail_recv(RemoteProtocolError(
                    "incomplete event exceeds the size limit", 431))
            return NEED_DATA
        lines, consumed = block
        try:
            if their is CLIENT:
                event = self._parse_request(lines)
            else:
                event = self._parse_response(lines)
        except RemoteProtocolError as exc:
            self._fail_recv(exc)
        del buf[:consumed]
        return self._commit_recv_head(event)

    def _parse_request(self, lines):
        match = _REQUEST_LINE_RE.fullmatch(lines[0])
        if not match:
            raise RemoteProtocolError("malformed request line")
        method, target, version = match.group(1), match.group(2), match.group(3)
        if version not in (b"1.0", b"1.1"):
            raise RemoteProtocolError("unsupported HTTP version")
        headers = _parse_fields(lines[1:])
        return _remote_construct(Request, method=method, target=target,
                                 headers=headers, http_version=version)

    def _parse_response(self, lines):
        match = _STATUS_LINE_RE.fullmatch(lines[0])
        if not match:
            raise RemoteProtocolError("malformed status line")
        version = match.group(1)
        code = int(match.group(2))
        reason = match.group(3) or b""
        if version not in (b"1.0", b"1.1"):
            raise RemoteProtocolError("unsupported HTTP version")
        headers = _parse_fields(lines[1:])
        if 100 <= code < 200:
            return _remote_construct(InformationalResponse, status_code=code,
                                     headers=headers, http_version=version, reason=reason)
        return _remote_construct(Response, status_code=code, headers=headers,
                                 http_version=version, reason=reason)

    def _commit_recv_head(self, event):
        t = type(event)
        if t is Request:
            self._their_http_version = event.http_version
            self._recv_framing = _request_framing(event.headers.raw_items())
            self._on_request(event)
            self._transition(CLIENT, event, None)
            return event
        self._their_http_version = event.http_version
        decision = self._decide(event)
        if t is InformationalResponse:
            self._apply_decision(decision)
            self._transition(SERVER, event, decision)
            return event
        self._apply_decision(decision)
        if decision == "accept":
            self._recv_framing = None
        else:
            raw = event.headers.raw_items()
            self._recv_framing = _response_framing(raw, event.status_code, self._cycle_method)
            if self._recv_framing.kind == "close":
                self._keep_alive = False
        self._transition(SERVER, event, decision)
        return event

    def _pull_body(self):
        fr = self._recv_framing
        buf = self._buf
        if fr.kind == "empty":
            return self._finish_recv(EndOfMessage())
        if fr.kind == "cl":
            if fr.remaining == 0:
                return self._finish_recv(EndOfMessage())
            if buf:
                n = min(fr.remaining, len(buf))
                data = bytes(buf[:n])
                del buf[:n]
                fr.remaining -= n
                return Data(data)
            if self._closed_in:
                self._fail_recv(RemoteProtocolError(
                    "connection closed in the middle of a Content-Length body"))
            return NEED_DATA
        if fr.kind == "close":
            if buf:
                data = bytes(buf)
                buf.clear()
                return Data(data)
            if self._closed_in:
                return self._finish_recv(EndOfMessage())
            return NEED_DATA
        return self._pull_chunked(fr)

    def _pull_chunked(self, fr):
        buf = self._buf
        while True:
            if fr.stage == "size":
                idx = buf.find(b"\n")
                if idx < 0:
                    if self._closed_in:
                        self._fail_recv(RemoteProtocolError(
                            "connection closed in the middle of a chunk-size line"))
                    if len(buf) > self._max_size:
                        self._fail_recv(RemoteProtocolError("chunk-size line too long"))
                    return NEED_DATA
                line = bytes(buf[:idx])
                if line.endswith(b"\r"):
                    line = line[:-1]
                match = _CHUNK_SIZE_RE.fullmatch(line)
                if not match or len(match.group(1)) > MAX_CHUNK_SIZE_DIGITS:
                    self._fail_recv(RemoteProtocolError("malformed chunk-size line"))
                del buf[:idx + 1]
                size = int(match.group(1), 16)
                if size == 0:
                    fr.stage = "trailers"
                else:
                    fr.stage = "data"
                    fr.chunk_remaining = size
                    fr.chunk_started = False
            elif fr.stage == "data":
                if not buf:
                    if self._closed_in:
                        self._fail_recv(RemoteProtocolError(
                            "connection closed in the middle of a chunk"))
                    return NEED_DATA
                n = min(fr.chunk_remaining, len(buf))
                data = bytes(buf[:n])
                del buf[:n]
                start = not fr.chunk_started
                fr.chunk_started = True
                fr.chunk_remaining -= n
                end = fr.chunk_remaining == 0
                if end:
                    fr.stage = "crlf"
                return Data(data, chunk_start=start, chunk_end=end)
            elif fr.stage == "crlf":
                if len(buf) >= 2:
                    if bytes(buf[:2]) != b"\r\n":
                        self._fail_recv(RemoteProtocolError("chunk not followed by CRLF"))
                    del buf[:2]
                    fr.stage = "size"
                    continue
                if len(buf) == 1 and buf[0] != 13:
                    self._fail_recv(RemoteProtocolError("chunk not followed by CRLF"))
                if self._closed_in:
                    self._fail_recv(RemoteProtocolError(
                        "connection closed in the middle of a chunk"))
                return NEED_DATA
            else:  # trailers
                block = _find_block(buf)
                if block is None:
                    if self._closed_in:
                        self._fail_recv(RemoteProtocolError(
                            "connection closed in the middle of trailers"))
                    if len(buf) > self._max_size:
                        self._fail_recv(RemoteProtocolError(
                            "incomplete event exceeds the size limit", 431))
                    return NEED_DATA
                lines, consumed = block
                del buf[:consumed]
                try:
                    trailers = _parse_fields(lines)
                    event = _remote_construct(EndOfMessage, headers=trailers)
                except RemoteProtocolError as exc:
                    self._fail_recv(exc)
                return self._finish_recv(event)
