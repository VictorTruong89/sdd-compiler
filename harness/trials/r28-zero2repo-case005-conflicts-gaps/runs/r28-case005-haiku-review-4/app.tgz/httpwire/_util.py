"""Shared sentinels, protocol-error classes, and low-level validators."""

import re


class _Sentinel(object):
    """A unique, identity-compared marker object."""

    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return "httpwire.%s" % self._name


# Roles
CLIENT = _Sentinel("CLIENT")
SERVER = _Sentinel("SERVER")

# Non-event pull results
NEED_DATA = _Sentinel("NEED_DATA")
PAUSED = _Sentinel("PAUSED")

# Connection states
IDLE = _Sentinel("IDLE")
SEND_RESPONSE = _Sentinel("SEND_RESPONSE")
SEND_BODY = _Sentinel("SEND_BODY")
DONE = _Sentinel("DONE")
MUST_CLOSE = _Sentinel("MUST_CLOSE")
CLOSED = _Sentinel("CLOSED")
MIGHT_SWITCH_PROTOCOL = _Sentinel("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = _Sentinel("SWITCHED_PROTOCOL")
ERROR = _Sentinel("ERROR")


class _ProtocolError(Exception):
    """Common base for the two protocol-error kinds (not a public name)."""

    def __init__(self, message="", error_status_hint=400):
        Exception.__init__(self, message)
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(_ProtocolError):
    """The integrator's own event or send violated HTTP/1.1."""


class RemoteProtocolError(_ProtocolError):
    """The peer's bytes violated HTTP/1.1."""


TOKEN_RE = re.compile(rb"[!#$%&'*+\-.^_`|~0-9A-Za-z]+")
TARGET_RE = re.compile(rb"[\x21-\x7e]+")
VERSION_RE = re.compile(rb"[0-9]\.[0-9]")
DIGITS_RE = re.compile(rb"[0-9]+")
# NUL, CR, LF, form feed and vertical tab are never allowed in a header value.
BAD_VALUE_RE = re.compile(rb"[\x00\r\n\x0b\x0c]")
BAD_REASON_RE = re.compile(rb"[\x00\r\n]")


def to_bytes(value, what):
    """Coerce ASCII text or a bytes-like object to ``bytes``; refuse anything else."""
    if isinstance(value, bytes):
        return value
    if isinstance(value, str):
        try:
            return value.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("%s must be ASCII text" % what)
    try:
        return bytes(memoryview(value))
    except TypeError:
        raise LocalProtocolError("%s must be text or a bytes-like object" % what)
