"""Behavioral tests for httpwire. Run from the repository root:

    python3 -m unittest discover -s tests -v
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from httpwire import (  # noqa: E402
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
    ConnectionClosed,
    Connection,
    Data,
    EndOfMessage,
    InformationalResponse,
    LocalProtocolError,
    RemoteProtocolError,
    Request,
    Response,
)


def drain(conn):
    """Pull events until NEED_DATA/PAUSED or a connection-closed event."""
    events = []
    while True:
        event = conn.next_event()
        if event is NEED_DATA or event is PAUSED:
            return events, event
        events.append(event)
        if isinstance(event, ConnectionClosed):
            return events, None


class ConstructionTests(unittest.TestCase):
    def test_request_needs_host_on_11(self):
        with self.assertRaises(LocalProtocolError):
            Request(method=b"GET", target=b"/", headers=[])
        Request(method=b"GET", target=b"/", headers=[], http_version=b"1.0")

    def test_two_hosts_refused_any_version(self):
        with self.assertRaises(LocalProtocolError):
            Request(method=b"GET", target=b"/", headers=[(b"Host", b"a"), (b"HOST", b"b")],
                    http_version=b"1.0")

    def test_transfer_encoding_rules(self):
        with self.assertRaises(LocalProtocolError) as ctx:
            Request(method=b"GET", target=b"/", headers=[(b"Host", b"a"), (b"Transfer-Encoding", b"gzip")])
        self.assertEqual(ctx.exception.error_status_hint, 501)
        with self.assertRaises(LocalProtocolError) as ctx:
            Request(method=b"GET", target=b"/", headers=[
                (b"Host", b"a"), (b"Transfer-Encoding", b"chunked"), (b"Transfer-Encoding", b"chunked")])
        self.assertEqual(ctx.exception.error_status_hint, 501)
        req = Request(method=b"POST", target=b"/", headers=[(b"Host", b"a"), (b"Transfer-Encoding", b"ChUnKeD")])
        self.assertEqual(req.headers.raw_items()[1], (b"Transfer-Encoding", b"chunked"))

    def test_content_length_collapse_and_conflict(self):
        req = Request(method=b"POST", target=b"/", headers=[
            (b"Host", b"a"), (b"Content-Length", b"3, 3"), (b"content-length", b"3")])
        self.assertEqual(req.headers.raw_items(), [(b"Host", b"a"), (b"Content-Length", b"3")])
        with self.assertRaises(LocalProtocolError):
            Request(method=b"POST", target=b"/", headers=[
                (b"Host", b"a"), (b"Content-Length", b"1"), (b"Content-Length", b"2")])
        with self.assertRaises(LocalProtocolError):
            Request(method=b"POST", target=b"/", headers=[(b"Host", b"a"), (b"Content-Length", b"1" * 19)])

    def test_status_ranges(self):
        with self.assertRaises(LocalProtocolError):
            InformationalResponse(status_code=200, headers=[])
        with self.assertRaises(LocalProtocolError):
            Response(status_code=199, headers=[])
        with self.assertRaises(LocalProtocolError):
            Response(status_code="200", headers=[])

    def test_raw_items_keep_caller_case(self):
        req = Request(method=b"GET", target=b"/", headers=[(b"Host", b"a"), (b"X-Foo", b"1")])
        self.assertEqual(list(req.headers), [(b"host", b"a"), (b"x-foo", b"1")])
        self.assertEqual(req.headers.raw_items(), [(b"Host", b"a"), (b"X-Foo", b"1")])

    def test_value_with_edge_space_refused(self):
        with self.assertRaises(LocalProtocolError):
            Request(method=b"GET", target=b"/", headers=[(b"Host", b"a"), (b"X", b" pad")])


class RoundTripTests(unittest.TestCase):
    def test_get_keep_alive_cycle(self):
        cl, sv = Connection(CLIENT), Connection(SERVER)
        wire = cl.send(Request(method=b"GET", target=b"/", headers=[(b"Host", b"h")]))
        self.assertEqual(wire, b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
        cl.send(EndOfMessage())
        sv.receive_data(wire)
        events, _ = drain(sv)
        self.assertIsInstance(events[0], Request)
        self.assertIsInstance(events[1], EndOfMessage)
        self.assertEqual(sv.their_http_version, b"1.1")
        resp = sv.send(Response(status_code=200, headers=[(b"Content-Length", b"5")], reason=b"OK"))
        self.assertEqual(resp, b"HTTP/1.1 200 OK\r\nContent-Length: 5\r\n\r\n")
        sv.send(Data(data=b"hello"))
        sv.send(EndOfMessage())
        self.assertEqual((sv.our_state, cl.our_state), (DONE, DONE))
        cl.receive_data(resp + b"hello")
        events, _ = drain(cl)
        self.assertIsInstance(events[0], Response)
        self.assertEqual(events[1].data, b"hello")
        self.assertIsInstance(events[2], EndOfMessage)
        self.assertEqual(cl.start_next_cycle(), None)
        sv.start_next_cycle()
        self.assertEqual((cl.our_state, sv.our_state), (IDLE, IDLE))

    def test_chunked_request_body_and_trailers(self):
        cl, sv = Connection(CLIENT), Connection(SERVER)
        wire = cl.send(Request(method=b"POST", target=b"/", headers=[
            (b"Host", b"h"), (b"Transfer-Encoding", b"chunked")]))
        wire += cl.send(Data(data=b"abc")) + cl.send(EndOfMessage(headers=[(b"X-T", b"1")]))
        self.assertEqual(wire.split(b"\r\n\r\n", 1)[1], b"3\r\nabc\r\n0\r\nX-T: 1\r\n\r\n")
        sv.receive_data(wire)
        events, _ = drain(sv)
        self.assertEqual(events[1].data, b"abc")
        self.assertTrue(events[1].chunk_start and events[1].chunk_end)
        self.assertEqual(list(events[2].headers), [(b"x-t", b"1")])

    def test_chunk_marks_across_pieces(self):
        sv = Connection(SERVER)
        msg = b"POST / HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\n5;ext=1\r\nhel"
        sv.receive_data(msg)
        events, need = drain(sv)
        self.assertEqual(events[1].data, b"hel")
        self.assertEqual((events[1].chunk_start, events[1].chunk_end), (True, False))
        sv.receive_data(b"lo\r\n0\r\n\r\n")
        events, _ = drain(sv)
        self.assertEqual((events[0].data, events[0].chunk_start, events[0].chunk_end), (b"lo", False, True))

    def test_passthrough_keeps_object_identity(self):
        class Blob(object):
            def __len__(self):
                return 7
        blob = Blob()
        cl = Connection(CLIENT)
        cl.send(Request(method=b"PUT", target=b"/", headers=[
            (b"Host", b"a"), (b"Transfer-Encoding", b"chunked")]))
        pieces = cl.send_with_data_passthrough(Data(data=blob))
        self.assertEqual(pieces[0], b"7\r\n")
        self.assertIs(pieces[1], blob)
        self.assertEqual(pieces[2], b"\r\n")

    def test_head_response_has_no_body_bytes(self):
        sv = Connection(SERVER)
        sv.receive_data(b"HEAD / HTTP/1.1\r\nHost: a\r\n\r\n")
        drain(sv)
        head = sv.send(Response(status_code=200, headers=[]))
        self.assertEqual(head, b"HTTP/1.1 200 \r\nTransfer-Encoding: chunked\r\n\r\n")
        self.assertEqual(sv.send(EndOfMessage()), b"")


class LifecycleTests(unittest.TestCase):
    def test_http10_request_forces_close(self):
        sv = Connection(SERVER)
        sv.receive_data(b"GET / HTTP/1.0\r\nHost: x\r\n\r\n")
        drain(sv)
        resp = sv.send(Response(status_code=200, headers=[]))
        self.assertIn(b"Connection: close", resp)
        sv.send(Data(data=b"body"))
        sv.send(EndOfMessage())
        self.assertEqual(sv.our_state, MUST_CLOSE)
        sv.send(ConnectionClosed())
        self.assertEqual(sv.our_state, CLOSED)

    def test_connection_close_request_gets_close_header(self):
        sv = Connection(SERVER)
        sv.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\nConnection: close\r\n\r\n")
        drain(sv)
        resp = sv.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
        self.assertIn(b"Connection: close", resp)
        sv.send(EndOfMessage())
        self.assertEqual(sv.our_state, MUST_CLOSE)

    def test_close_delimited_response_read_by_client(self):
        cl = Connection(CLIENT)
        cl.send(Request(method=b"GET", target=b"/", headers=[(b"Host", b"x")]))
        cl.send(EndOfMessage())
        cl.receive_data(b"HTTP/1.0 200 OK\r\n\r\nhello world")
        events, _ = drain(cl)
        self.assertEqual(events[1].data, b"hello world")
        cl.receive_data(b"")
        events, _ = drain(cl)
        self.assertIsInstance(events[0], EndOfMessage)
        self.assertIsInstance(events[1], ConnectionClosed)
        self.assertEqual(cl.their_state, CLOSED)
        self.assertEqual(cl.our_state, MUST_CLOSE)

    def test_pipelined_request_is_paused_until_next_cycle(self):
        sv = Connection(SERVER)
        sv.receive_data(b"GET /1 HTTP/1.1\r\nHost: a\r\n\r\nGET /2 HTTP/1.1\r\nHost: a\r\n\r\n")
        events, need = drain(sv)
        self.assertEqual(need, PAUSED)
        sv.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
        sv.send(EndOfMessage())
        sv.start_next_cycle()
        events, _ = drain(sv)
        self.assertEqual(events[0].target, b"/2")

    def test_second_request_refused_and_errors(self):
        cl = Connection(CLIENT)
        cl.send(Request(method=b"GET", target=b"/", headers=[(b"Host", b"a")]))
        cl.send(EndOfMessage())
        with self.assertRaises(LocalProtocolError):
            cl.send(Request(method=b"GET", target=b"/", headers=[(b"Host", b"a")]))
        self.assertEqual(cl.our_state, ERROR)
        with self.assertRaises(LocalProtocolError):
            cl.send(EndOfMessage())

    def test_start_next_cycle_refused_changes_nothing(self):
        cl = Connection(CLIENT)
        cl.send(Request(method=b"GET", target=b"/", headers=[(b"Host", b"a")]))
        with self.assertRaises(LocalProtocolError):
            cl.start_next_cycle()
        self.assertEqual(cl.our_state, SEND_BODY)

    def test_send_overflow_is_local_error(self):
        cl = Connection(CLIENT)
        cl.send(Request(method=b"PUT", target=b"/", headers=[(b"Host", b"a"), (b"Content-Length", b"2")]))
        with self.assertRaises(LocalProtocolError):
            cl.send(Data(data=b"abc"))
        self.assertEqual(cl.our_state, ERROR)


class ErrorTests(unittest.TestCase):
    def test_leading_space_fails_immediately_and_sticks(self):
        sv = Connection(SERVER)
        sv.receive_data(b" GET / HTTP/1.1\r\n")
        with self.assertRaises(RemoteProtocolError):
            sv.next_event()
        with self.assertRaises(RemoteProtocolError):
            sv.next_event()
        self.assertEqual(sv.their_state, ERROR)
        resp = sv.send(Response(status_code=400, headers=[]))
        self.assertIn(b"Connection: close", resp)

    def test_oversized_head_is_431(self):
        sv = Connection(SERVER)
        sv.receive_data(b"GET / HTTP/1.1\r\nX: " + b"a" * 20000)
        with self.assertRaises(RemoteProtocolError) as ctx:
            sv.next_event()
        self.assertEqual(ctx.exception.error_status_hint, 431)

    def test_chunk_size_digit_limit(self):
        sv = Connection(SERVER)
        sv.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\n"
                        + b"1" * 33 + b"\r\n")
        with self.assertRaises(RemoteProtocolError):
            drain(sv)

    def test_feed_after_empty_feed_is_runtime_error(self):
        sv = Connection(SERVER)
        sv.receive_data(b"")
        with self.assertRaises(RuntimeError):
            sv.receive_data(b"x")
        self.assertIsInstance(sv.next_event(), ConnectionClosed)

    def test_close_mid_message_is_remote_error(self):
        sv = Connection(SERVER)
        sv.receive_data(b"GET / HTTP/1.1\r\nHo")
        sv.receive_data(b"")
        with self.assertRaises(RemoteProtocolError):
            sv.next_event()

    def test_bad_role(self):
        with self.assertRaises(ValueError):
            Connection("client")


class SwitchTests(unittest.TestCase):
    def test_connect_accept(self):
        cl, sv = Connection(CLIENT), Connection(SERVER)
        wire = cl.send(Request(method=b"CONNECT", target=b"x:443", headers=[(b"Host", b"x:443")]))
        cl.send(EndOfMessage())
        sv.receive_data(wire + b"TLS")
        events, need = drain(sv)
        self.assertEqual(need, PAUSED)
        sv.send(Response(status_code=200, headers=[]))
        self.assertEqual(sv.our_state, SWITCHED_PROTOCOL)
        sv.receive_data(b"")
        self.assertEqual(sv.trailing_data, (b"TLS", True))
        self.assertEqual(sv.next_event(), PAUSED)
        cl.receive_data(b"HTTP/1.1 200 \r\n\r\nTLS")
        events, need = drain(cl)
        self.assertEqual(cl.our_state, SWITCHED_PROTOCOL)
        self.assertEqual(cl.trailing_data, (b"TLS", False))
        with self.assertRaises(LocalProtocolError):
            cl.send(Request(method=b"GET", target=b"/", headers=[(b"Host", b"a")]))

    def test_upgrade_denied_returns_to_http(self):
        cl, sv = Connection(CLIENT), Connection(SERVER)
        wire = cl.send(Request(method=b"GET", target=b"/", headers=[
            (b"Host", b"a"), (b"Upgrade", b"h2c"), (b"Connection", b"Upgrade")]))
        cl.send(EndOfMessage())
        sv.receive_data(wire)
        _, need = drain(sv)
        self.assertEqual(need, PAUSED)
        sv.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
        self.assertEqual(sv.their_state, DONE)

    def test_100_continue_flags(self):
        cl, sv = Connection(CLIENT), Connection(SERVER)
        wire = cl.send(Request(method=b"PUT", target=b"/", headers=[
            (b"Host", b"a"), (b"Expect", b"100-Continue"), (b"Content-Length", b"3")]))
        self.assertTrue(cl.client_is_waiting_for_100_continue)
        self.assertFalse(cl.they_are_waiting_for_100_continue)
        sv.receive_data(wire)
        drain(sv)
        self.assertTrue(sv.they_are_waiting_for_100_continue)
        sv.send(InformationalResponse(status_code=100, headers=[]))
        self.assertFalse(sv.client_is_waiting_for_100_continue)


if __name__ == "__main__":
    unittest.main()
