"""Behavioural tests for httpwire, organised by feature point (spec/packs, FP-01..FP-07)."""

import pytest

import httpwire as h
from httpwire import (
    CLIENT,
    SERVER,
    IDLE,
    SEND_RESPONSE,
    SEND_BODY,
    DONE,
    MUST_CLOSE,
    CLOSED,
    MIGHT_SWITCH_PROTOCOL,
    SWITCHED_PROTOCOL,
    ERROR,
    NEED_DATA,
    PAUSED,
    Connection,
    Request,
    InformationalResponse,
    Response,
    Data,
    EndOfMessage,
    ConnectionClosed,
    LocalProtocolError,
    RemoteProtocolError,
)


def pump(conn, data):
    """Feed bytes and pull every event currently available."""
    conn.receive_data(data)
    out = []
    while True:
        ev = conn.next_event()
        if ev is NEED_DATA or ev is PAUSED:
            out.append(ev)
            break
        out.append(ev)
    return out


def exchange_request_response(client, server, request, response_bytes_events):
    """Client sends request; server pulls it; server sends response events; client pulls them."""
    wire = client.send(request)
    server.receive_data(wire)
    assert isinstance(server.next_event(), Request)
    return wire


# ---------------------------------------------------------------- FP-01 events and headers

def test_package_root_names_and_identity():
    names = ["CLIENT", "SERVER", "IDLE", "SEND_RESPONSE", "SEND_BODY", "DONE", "MUST_CLOSE", "CLOSED",
             "MIGHT_SWITCH_PROTOCOL", "SWITCHED_PROTOCOL", "ERROR", "NEED_DATA", "PAUSED"]
    objs = [getattr(h, n) for n in names]
    assert len({id(o) for o in objs}) == len(objs)
    assert CLIENT != SERVER
    assert NEED_DATA is not PAUSED
    assert not isinstance(NEED_DATA, str)
    assert issubclass(LocalProtocolError, Exception)
    assert not issubclass(LocalProtocolError, RemoteProtocolError)
    assert not issubclass(RemoteProtocolError, LocalProtocolError)


def test_request_defaults_and_bytes_types():
    r = Request(method="GET", target="/x", headers=[("Host", "a")])
    assert r.http_version == b"1.1"
    assert type(r.method) is bytes and type(r.target) is bytes
    assert type(r.http_version) is bytes
    r2 = Request(method=bytearray(b"GET"), target=memoryview(b"/"), headers=[(b"Host", bytearray(b"a"))])
    assert type(r2.headers[0][1]) is bytes


def test_request_host_rules():
    with pytest.raises(LocalProtocolError):
        Request(method="GET", target="/", headers=[])  # HTTP/1.1 needs Host
    Request(method="GET", target="/", headers=[], http_version="1.0")  # 1.0 needs none
    with pytest.raises(LocalProtocolError):
        Request(method="GET", target="/", headers=[("Host", "a"), ("HOST", "b")], http_version="1.0")


def test_header_names_lowercased_raw_preserved_order():
    r = Request(method="GET", target="/", headers=[("Host", "a"), ("X-Foo", "1"), ("x-bar", "2")])
    assert list(r.headers) == [(b"host", b"a"), (b"x-foo", b"1"), (b"x-bar", b"2")]
    assert r.headers.raw_items() == [(b"Host", b"a"), (b"X-Foo", b"1"), (b"x-bar", b"2")]


@pytest.mark.parametrize("bad", [b"Bad Name", b"", b"Na:me"])
def test_invalid_header_name_refused(bad):
    with pytest.raises(LocalProtocolError):
        Request(method="GET", target="/", headers=[("Host", "a"), (bad, b"x")])


@pytest.mark.parametrize("bad", [b" lead", b"trail ", b"\tlead", b"nul\x00", b"cr\r", b"lf\n", b"ff\x0c", b"vt\x0b", b"del\x7f", b"ctl\x01"])
def test_invalid_header_value_refused(bad):
    with pytest.raises(LocalProtocolError):
        Request(method="GET", target="/", headers=[("Host", "a"), ("X", bad)])


def test_header_value_non_ascii_and_inner_tab_allowed():
    r = Request(method="GET", target="/", headers=[("Host", "a"), ("X", b"a\tb\xff")])
    assert r.headers[1] == (b"x", b"a\tb\xff")


def test_target_and_method_validation():
    with pytest.raises(LocalProtocolError):
        Request(method="GE T", target="/", headers=[("Host", "a")])
    with pytest.raises(LocalProtocolError):
        Request(method="GET", target="/a b", headers=[("Host", "a")])
    with pytest.raises(LocalProtocolError):
        Request(method="GET", target="", headers=[("Host", "a")])


def test_status_ranges_and_types():
    InformationalResponse(status_code=100, headers=[])
    InformationalResponse(status_code=199, headers=[])
    with pytest.raises(LocalProtocolError):
        InformationalResponse(status_code=200, headers=[])
    Response(status_code=200, headers=[])
    Response(status_code=999, headers=[])
    with pytest.raises(LocalProtocolError):
        Response(status_code=1000, headers=[])
    with pytest.raises(LocalProtocolError):
        Response(status_code="200", headers=[])
    with pytest.raises(LocalProtocolError):
        Response(status_code=200.0, headers=[])
    r = Response(status_code=200, headers=[])
    assert r.http_version == b"1.1" and r.reason == b""


def test_content_length_collapse_and_conflict():
    r = Request(method="POST", target="/", headers=[("Host", "a"), ("Content-Length", "3"), ("content-length", "3")])
    assert list(r.headers).count((b"content-length", b"3")) == 1
    r = Request(method="POST", target="/", headers=[("Host", "a"), ("Content-Length", "3, 3")])
    assert r.headers[1] == (b"content-length", b"3")
    with pytest.raises(LocalProtocolError):
        Request(method="POST", target="/", headers=[("Host", "a"), ("Content-Length", "3"), ("Content-Length", "4")])
    with pytest.raises(LocalProtocolError):
        Request(method="POST", target="/", headers=[("Host", "a"), ("Content-Length", "3x")])
    with pytest.raises(LocalProtocolError):
        Request(method="POST", target="/", headers=[("Host", "a"), ("Content-Length", "1" * 19)])
    Request(method="POST", target="/", headers=[("Host", "a"), ("Content-Length", "1" * 18)])


def test_transfer_encoding_rules():
    r = Request(method="POST", target="/", headers=[("Host", "a"), ("Transfer-Encoding", "CHUNKED")])
    assert r.headers[1] == (b"transfer-encoding", b"chunked")
    for bad in ([("Transfer-Encoding", "gzip")], [("Transfer-Encoding", "gzip, chunked")]):
        with pytest.raises(LocalProtocolError) as info:
            Request(method="POST", target="/", headers=[("Host", "a")] + bad)
        assert info.value.error_status_hint == 501
    with pytest.raises(LocalProtocolError) as info:
        Request(method="POST", target="/", headers=[("Host", "a"), ("Transfer-Encoding", "chunked"),
                                                    ("Transfer-Encoding", "chunked")])
    assert info.value.error_status_hint == 501


def test_event_construction_failure_is_recoverable():
    c = Connection(CLIENT)
    with pytest.raises(LocalProtocolError):
        Request(method="GET", target="/", headers=[])
    assert c.states == {CLIENT: IDLE, SERVER: IDLE}
    c.send(Request(method="GET", target="/", headers=[("Host", "a")]))  # still usable


def test_data_and_eom_and_closed_fields():
    d = Data(data=b"abc", chunk_start=1, chunk_end=0)
    assert d.data == b"abc" and d.chunk_start is True and d.chunk_end is False
    assert EndOfMessage().headers == []
    ConnectionClosed()


# ---------------------------------------------------------------- FP-02 connection basics

def test_new_connection_states_and_roles():
    c = Connection(CLIENT)
    assert c.our_role is CLIENT and c.their_role is SERVER
    assert c.our_state is IDLE and c.their_state is IDLE
    assert c.states == {CLIENT: IDLE, SERVER: IDLE}
    assert c.their_http_version is None
    s = Connection(SERVER)
    assert s.our_role is SERVER and s.their_role is CLIENT


def test_bad_role_refused():
    with pytest.raises(LocalProtocolError):
        Connection("client")


def test_request_bytes_and_states_on_client_and_server():
    c = Connection(CLIENT)
    wire = c.send(Request(method="GET", target="/", headers=[("Host", "a"), ("X-A", "1")]))
    assert wire == b"GET / HTTP/1.1\r\nHost: a\r\nX-A: 1\r\n\r\n"
    assert c.states == {CLIENT: SEND_BODY, SERVER: SEND_RESPONSE}
    assert c.their_http_version is None  # client does not record its own send
    s = Connection(SERVER)
    assert s.next_event() is NEED_DATA
    s.receive_data(wire)
    assert s.states == {CLIENT: IDLE, SERVER: IDLE}  # feeding stores only
    req = s.next_event()
    assert isinstance(req, Request) and req.headers[0] == (b"host", b"a")
    assert s.states == {CLIENT: SEND_BODY, SERVER: SEND_RESPONSE}
    assert s.their_http_version == b"1.1"


def test_host_written_first_and_original_casing():
    c = Connection(CLIENT)
    wire = c.send(Request(method="GET", target="/", headers=[("X-A", "1"), ("Host", "a")]))
    assert wire == b"GET / HTTP/1.1\r\nHost: a\r\nX-A: 1\r\n\r\n"


def test_response_wire_format_and_passthrough():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    wire = s.send(Response(status_code=200, headers=[("Content-Length", "5")], reason=b"OK"))
    assert wire == b"HTTP/1.1 200 OK\r\nContent-Length: 5\r\n\r\n"
    payload = bytearray(b"hello")
    s2 = Connection(SERVER)
    s2.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s2.next_event()
    pieces = s2.send_with_data_passthrough(Response(status_code=200, headers=[("Content-Length", "5")], reason=b"OK"))
    assert isinstance(pieces, list)
    pieces = s2.send_with_data_passthrough(Data(data=payload))
    assert any(p is payload for p in pieces)


def test_passthrough_object_with_length_counts_as_body():
    class Blob:
        def __init__(self, n):
            self.n = n

        def __len__(self):
            return self.n

    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    assert s.next_event() == EndOfMessage()
    s.send(Response(status_code=200, headers=[("Content-Length", "4")]))
    blob = Blob(4)
    pieces = s.send_with_data_passthrough(Data(data=blob))
    assert pieces == [blob] and pieces[0] is blob
    s.send(EndOfMessage())
    assert s.states == {CLIENT: DONE, SERVER: DONE}


def test_pull_nothing_returns_need_data_not_error():
    c = Connection(SERVER)
    assert c.next_event() is NEED_DATA


def test_two_step_receive_and_partial_event():
    s = Connection(SERVER)
    s.receive_data(b"GET / HT")
    assert s.next_event() is NEED_DATA
    s.receive_data(b"TP/1.1\r\nHost: a\r\n\r\n")
    assert isinstance(s.next_event(), Request)


def test_round_trip_request_and_response_content_length():
    c = Connection(CLIENT)
    s = Connection(SERVER)
    s.receive_data(c.send(Request(method="POST", target="/p", headers=[("Host", "a"), ("Content-Length", "5")])))
    s.receive_data(c.send(Data(data=b"he")) + c.send(Data(data=b"llo")))
    assert isinstance(s.next_event(), Request)
    assert s.next_event() == Data(data=b"hello")  # both pieces were buffered before the pull
    assert s.next_event() == EndOfMessage()
    c.send(EndOfMessage())
    wire = s.send(Response(status_code=201, headers=[("Content-Length", "2")], reason=b"Created"))
    s.send(Data(data=b"ok"))
    s.send(EndOfMessage())
    c.receive_data(wire + b"ok")
    r = c.next_event()
    assert isinstance(r, Response) and r.status_code == 201 and r.reason == b"Created"
    assert c.next_event() == Data(data=b"ok")
    assert c.next_event() == EndOfMessage()
    assert c.states == {CLIENT: DONE, SERVER: DONE}


def test_reason_absent_in_status_line_is_accepted():
    c = Connection(CLIENT)
    c.send(Request(method="GET", target="/", headers=[("Host", "a")]))
    c.receive_data(b"HTTP/1.1 204\r\n\r\n")
    r = c.next_event()
    assert isinstance(r, Response) and r.reason == b""


def test_lone_lf_line_endings_accepted_in_header_block():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\nHost: a\n\n")
    assert isinstance(s.next_event(), Request)


def test_obsolete_line_folding_accepted_on_read():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\nX-Long: one\r\n   two\r\n\tthree\r\n\r\n")
    req = s.next_event()
    assert req.headers[1] == (b"x-long", b"one two three")


def test_remote_error_for_bad_bytes_and_leading_space():
    s = Connection(SERVER)
    s.receive_data(b" GET / HTTP/1.1\r\n")
    with pytest.raises(RemoteProtocolError):
        s.next_event()
    assert s.their_state is ERROR


def test_remote_error_for_control_byte_before_line_ending():
    s = Connection(SERVER)
    s.receive_data(b"\x01")
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_remote_error_then_further_pulls_fail_even_with_good_bytes():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nBad Header\r\n\r\n")
    with pytest.raises(RemoteProtocolError):
        s.next_event()
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    with pytest.raises(RemoteProtocolError):
        s.next_event()
    # send still works: error response carries Connection: close
    wire = s.send(Response(status_code=400, headers=[("Content-Length", "0")]))
    assert b"Connection: close" in wire
    assert s.our_state is SEND_BODY


def test_feeding_after_close_is_runtime_error_not_protocol_error():
    c = Connection(SERVER)
    c.receive_data(b"")
    with pytest.raises(RuntimeError) as info:
        c.receive_data(b"x")
    assert not isinstance(info.value, (LocalProtocolError, RemoteProtocolError))


def test_send_refused_is_local_error_and_unrecoverable_for_sending():
    c = Connection(CLIENT)
    c.send(Request(method="GET", target="/", headers=[("Host", "a")]))
    with pytest.raises(LocalProtocolError):
        c.send(Request(method="GET", target="/", headers=[("Host", "a")]))  # second request
    assert c.our_state is ERROR
    with pytest.raises(LocalProtocolError):
        c.send(EndOfMessage())


def test_send_failed_marks_error_and_done_peer_must_close():
    c = Connection(CLIENT)
    c.send(Request(method="GET", target="/", headers=[("Host", "a")]))
    c.send(EndOfMessage())
    assert c.send_failed() is None
    assert c.our_state is ERROR
    assert c.states[SERVER] is SEND_RESPONSE


def test_http10_request_cannot_be_sent():
    c = Connection(CLIENT)
    with pytest.raises(LocalProtocolError):
        c.send(Request(method="GET", target="/", headers=[], http_version="1.0"))
    assert c.our_state is ERROR


# ---------------------------------------------------------------- FP-03 framing

def test_request_without_framing_is_empty_and_eom_immediate():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    assert s.next_event() == EndOfMessage()
    assert s.states[CLIENT] is DONE


def test_chunked_request_round_trip_with_marks_and_trailers():
    c = Connection(CLIENT)
    wire = c.send(Request(method="POST", target="/", headers=[("Host", "a"), ("Transfer-Encoding", "chunked")]))
    wire += c.send(Data(data=b"hello"))
    wire += c.send(Data(data=b"!!"))
    wire += c.send(EndOfMessage(headers=[("X-T", "v")]))
    assert wire.endswith(b"5\r\nhello\r\n2\r\n!!\r\n0\r\nX-T: v\r\n\r\n")
    s = Connection(SERVER)
    s.receive_data(wire)
    assert isinstance(s.next_event(), Request)
    assert s.next_event() == Data(data=b"hello", chunk_start=True, chunk_end=True)
    assert s.next_event() == Data(data=b"!!", chunk_start=True, chunk_end=True)
    eom = s.next_event()
    assert isinstance(eom, EndOfMessage) and eom.headers == [(b"x-t", b"v")]
    assert eom.headers.raw_items() == [(b"X-T", b"v")]


def test_chunk_pieces_marks():
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\n")
    s.next_event()
    s.receive_data(b"6\r\nab")
    assert s.next_event() == Data(data=b"ab", chunk_start=True, chunk_end=False)
    assert s.next_event() is NEED_DATA
    s.receive_data(b"cdef\r\n0\r\n\r\n")
    assert s.next_event() == Data(data=b"cdef", chunk_start=False, chunk_end=True)
    assert s.next_event() == EndOfMessage()


def test_chunk_extensions_discarded_and_hex_upper():
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\n")
    s.next_event()
    s.receive_data(b"A;name=val \t\r\n0123456789\r\n0\r\n\r\n")
    assert s.next_event() == Data(data=b"0123456789", chunk_start=True, chunk_end=True)


@pytest.mark.parametrize("size_line", [b"1 \r\nx\r\n", b"zz\r\n", b"1" * 33 + b"\r\n"])
def test_bad_chunk_size_line_refused(size_line):
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\n")
    s.next_event()
    s.receive_data(size_line)
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_chunk_data_must_end_with_crlf():
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\n")
    s.next_event()
    s.receive_data(b"2\r\nabXY")
    assert s.next_event() == Data(data=b"ab", chunk_start=True, chunk_end=True)
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_content_length_body_pull_and_close_mid_body_is_error():
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nContent-Length: 4\r\n\r\nab")
    s.next_event()
    assert s.next_event() == Data(data=b"ab")
    assert s.next_event() is NEED_DATA
    s.receive_data(b"")
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_content_length_send_rules():
    c = Connection(CLIENT)
    c.send(Request(method="POST", target="/", headers=[("Host", "a"), ("Content-Length", "3")]))
    with pytest.raises(LocalProtocolError):
        c.send(EndOfMessage())  # before the declared length is sent
    assert c.our_state is ERROR


def test_content_length_send_too_much_is_refused():
    c = Connection(CLIENT)
    c.send(Request(method="POST", target="/", headers=[("Host", "a"), ("Content-Length", "2")]))
    with pytest.raises(LocalProtocolError):
        c.send(Data(data=b"abc"))


def test_content_length_zero_response_keeps_header():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    wire = s.send(Response(status_code=200, headers=[("Content-Length", "0")]))
    assert wire == b"HTTP/1.1 200 \r\nContent-Length: 0\r\n\r\n"


def test_response_to_http11_peer_is_chunked_when_no_framing_given():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    wire = s.send(Response(status_code=200, headers=[]))
    assert b"Transfer-Encoding: chunked" in wire
    assert s.send(Data(data=b"abc")) == b"3\r\nabc\r\n"
    assert s.send(EndOfMessage()) == b"0\r\n\r\n"


def test_response_to_http10_peer_is_close_delimited_with_connection_close():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.0\r\n\r\n")
    s.next_event()
    s.next_event()
    wire = s.send(Response(status_code=200, headers=[]))
    assert b"Transfer-Encoding" not in wire and b"Content-Length" not in wire
    assert b"Connection: close" in wire
    assert s.send(Data(data=b"raw")) == b"raw"
    assert s.send(EndOfMessage()) == b""
    assert s.states == {CLIENT: MUST_CLOSE, SERVER: MUST_CLOSE}


def test_te_wins_over_cl_in_constructed_response():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    wire = s.send(Response(status_code=200, headers=[("Transfer-Encoding", "chunked"), ("Content-Length", "9")]))
    assert b"Content-Length" not in wire and b"Transfer-Encoding: chunked" in wire


def test_head_response_has_no_body_but_framing_headers_as_for_get():
    s = Connection(SERVER)
    s.receive_data(b"HEAD / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    wire = s.send(Response(status_code=200, headers=[]))
    assert b"Transfer-Encoding: chunked" in wire
    assert s.send(EndOfMessage()) == b""


@pytest.mark.parametrize("status", [204, 304])
def test_204_304_have_empty_body(status):
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    wire = s.send(Response(status_code=status, headers=[]))
    assert b"Transfer-Encoding" not in wire
    assert s.send(EndOfMessage()) == b""


def test_received_close_delimited_response_body_and_close():
    c = Connection(CLIENT)
    c.send(Request(method="GET", target="/", headers=[("Host", "a")]))
    c.send(EndOfMessage())
    c.receive_data(b"HTTP/1.0 200 OK\r\n\r\nbody-bytes")
    r = c.next_event()
    assert isinstance(r, Response) and r.http_version == b"1.0"
    assert c.next_event() == Data(data=b"body-bytes")
    assert c.next_event() is NEED_DATA
    c.receive_data(b"")
    assert c.next_event() == EndOfMessage()
    assert c.next_event() == ConnectionClosed()
    assert c.their_state is CLOSED
    assert c.our_state is MUST_CLOSE


def test_received_close_delimited_in_chunk_is_not_error_and_no_leftover_marks():
    c = Connection(CLIENT)
    c.send(Request(method="GET", target="/", headers=[("Host", "a")]))
    c.send(EndOfMessage())
    c.receive_data(b"HTTP/1.1 200 OK\r\n\r\nxy")
    c.next_event()
    assert c.next_event() == Data(data=b"xy")
    assert c.next_event() is NEED_DATA


def test_head_response_received_is_empty():
    c = Connection(CLIENT)
    c.send(Request(method="HEAD", target="/", headers=[("Host", "a")]))
    c.send(EndOfMessage())
    c.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 500\r\n\r\n")
    assert isinstance(c.next_event(), Response)
    assert c.next_event() == EndOfMessage()


# ---------------------------------------------------------------- FP-04 keep-alive, reuse, pipelining

def test_keep_alive_cycle_reuse_and_start_next_cycle_refusal():
    c = Connection(CLIENT)
    s = Connection(SERVER)
    for _ in range(2):
        s.receive_data(c.send(Request(method="GET", target="/", headers=[("Host", "a")])))
        c.send(EndOfMessage())
        s.next_event()
        s.next_event()
        s.send(Response(status_code=200, headers=[("Content-Length", "0")]))
        s.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
        c.next_event()
        c.next_event()
        assert c.states == {CLIENT: DONE, SERVER: DONE}
        c.start_next_cycle()
        s.start_next_cycle()
        assert c.states == {CLIENT: IDLE, SERVER: IDLE}


def test_start_next_cycle_refused_and_recoverable():
    c = Connection(CLIENT)
    c.send(Request(method="GET", target="/", headers=[("Host", "a")]))
    with pytest.raises(LocalProtocolError):
        c.start_next_cycle()
    assert c.our_state is SEND_BODY  # nothing moved
    c.send(EndOfMessage())
    assert c.our_state is DONE


def test_connection_close_disables_keep_alive_and_forces_must_close():
    c = Connection(CLIENT)
    s = Connection(SERVER)
    s.receive_data(c.send(Request(method="GET", target="/", headers=[("Host", "a"), ("Connection", "Close")])))
    c.send(EndOfMessage())
    s.next_event()
    s.next_event()
    wire = s.send(Response(status_code=200, headers=[("Content-Length", "0"), ("Connection", "keep-alive")]))
    assert b"keep-alive" not in wire.lower() and b"Connection: close" in wire
    s.send(EndOfMessage())
    assert s.states == {CLIENT: MUST_CLOSE, SERVER: MUST_CLOSE}


def test_http10_request_disables_keep_alive_even_with_keep_alive_token():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.0\r\nConnection: keep-alive\r\n\r\n")
    s.next_event()
    s.next_event()
    s.send(Response(status_code=200, headers=[("Content-Length", "0")]))
    s.send(EndOfMessage())
    assert s.states == {CLIENT: MUST_CLOSE, SERVER: MUST_CLOSE}


def test_client_second_request_refused():
    c = Connection(CLIENT)
    c.send(Request(method="GET", target="/", headers=[("Host", "a")]))
    c.send(EndOfMessage())
    with pytest.raises(LocalProtocolError):
        c.send(Request(method="GET", target="/", headers=[("Host", "a")]))


def test_client_cannot_send_response_and_server_cannot_send_request():
    c = Connection(CLIENT)
    with pytest.raises(LocalProtocolError):
        c.send(Response(status_code=200, headers=[("Content-Length", "0")]))
    s = Connection(SERVER)
    with pytest.raises(LocalProtocolError):
        s.send(Request(method="GET", target="/", headers=[("Host", "a")]))


def test_pipelined_requests_are_paused_one_cycle_at_a_time():
    s = Connection(SERVER)
    s.receive_data(b"GET /1 HTTP/1.1\r\nHost: a\r\n\r\nGET /2 HTTP/1.1\r\nHost: a\r\n\r\n")
    assert isinstance(s.next_event(), Request)
    assert s.next_event() == EndOfMessage()
    assert s.next_event() is PAUSED  # DONE on the peer side with bytes left
    s.send(Response(status_code=200, headers=[("Content-Length", "0")]))
    s.send(EndOfMessage())
    assert s.next_event() is PAUSED  # still not started


def test_pipelined_request_parsed_after_next_cycle():
    s = Connection(SERVER)
    s.receive_data(b"GET /1 HTTP/1.1\r\nHost: a\r\n\r\nGET /2 HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    s.next_event()
    assert s.next_event() is PAUSED
    s.send(Response(status_code=200, headers=[("Content-Length", "0")]))
    s.send(EndOfMessage())
    assert s.states == {CLIENT: DONE, SERVER: DONE}
    s.start_next_cycle()
    req = s.next_event()
    assert isinstance(req, Request) and req.target == b"/2"


# ---------------------------------------------------------------- FP-05 errors and limit

def test_incomplete_event_size_limit_431():
    s = Connection(SERVER, 100)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\nX: " + b"a" * 200)
    with pytest.raises(RemoteProtocolError) as info:
        s.next_event()
    assert info.value.error_status_hint == 431
    assert s.their_state is ERROR


def test_default_limit_accepts_moderate_header_block():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\nX: " + b"a" * 4000 + b"\r\n\r\n")
    assert isinstance(s.next_event(), Request)


def test_body_bytes_do_not_count_against_limit():
    s = Connection(SERVER, 100)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nContent-Length: 1000\r\n\r\n")
    s.next_event()
    s.receive_data(b"x" * 500)
    assert s.next_event() == Data(data=b"x" * 500)


def test_protocol_error_default_status_400():
    e = LocalProtocolError("x")
    assert e.error_status_hint == 400 and str(e) == "x"
    assert isinstance(e.error_status_hint, int)


def test_send_failed_on_done_server_makes_done_peer_must_close():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    assert s.next_event() == EndOfMessage()
    s.send(Response(status_code=200, headers=[("Content-Length", "0")]))
    s.send(EndOfMessage())
    assert s.states == {CLIENT: DONE, SERVER: DONE}
    assert s.send_failed() is None
    assert s.states == {CLIENT: MUST_CLOSE, SERVER: ERROR}


# ---------------------------------------------------------------- FP-06 shutdown

def test_client_closes_idle_and_server_sees_close():
    c = Connection(CLIENT)
    assert c.send(ConnectionClosed()) == b""
    assert c.our_state is CLOSED
    assert c.their_state is MUST_CLOSE
    s = Connection(SERVER)
    s.receive_data(b"")
    assert s.next_event() == ConnectionClosed()
    assert s.their_state is CLOSED


def test_close_in_middle_of_request_is_remote_error():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTT")
    s.receive_data(b"")
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_send_close_during_send_response_is_local_error():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    with pytest.raises(LocalProtocolError):
        s.send(ConnectionClosed())


def test_pulled_close_when_peer_not_allowed_is_remote_error():
    c = Connection(CLIENT)
    c.send(Request(method="GET", target="/", headers=[("Host", "a")]))
    c.receive_data(b"")
    with pytest.raises(RemoteProtocolError):
        c.next_event()


# ---------------------------------------------------------------- FP-07 informational, 100-continue, switch

def test_informational_then_final_response():
    c = Connection(CLIENT)
    s = Connection(SERVER)
    s.receive_data(c.send(Request(method="GET", target="/", headers=[("Host", "a")])))
    s.next_event()
    s.next_event()
    s.send(InformationalResponse(status_code=102, headers=[]))
    s.send(Response(status_code=200, headers=[("Content-Length", "0")]))
    c.receive_data(b"HTTP/1.1 102 Processing\r\n\r\nHTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
    assert isinstance(c.next_event(), InformationalResponse)
    assert isinstance(c.next_event(), Response)


def test_expect_100_continue_flags():
    c = Connection(CLIENT)
    s = Connection(SERVER)
    wire = c.send(Request(method="POST", target="/", headers=[("Host", "a"), ("Content-Length", "3"),
                                                              ("Expect", "100-continue")]))
    assert c.client_is_waiting_for_100_continue is True
    assert c.they_are_waiting_for_100_continue is False
    s.receive_data(wire)
    s.next_event()
    assert s.client_is_waiting_for_100_continue is True
    assert s.they_are_waiting_for_100_continue is True
    s.send(InformationalResponse(status_code=100, headers=[]))
    assert s.client_is_waiting_for_100_continue is False
    assert s.they_are_waiting_for_100_continue is False


def test_expect_on_http10_does_not_set_flag_for_nonconforming_case():
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.0\r\nExpect: 100-continue\r\nContent-Length: 0\r\n\r\n")
    s.next_event()
    assert s.client_is_waiting_for_100_continue is False


def test_connect_accepted_switches_protocol_and_trailing_data():
    c = Connection(CLIENT)
    s = Connection(SERVER)
    wire = c.send(Request(method="CONNECT", target="x:443", headers=[("Host", "x:443")]))
    wire += c.send(EndOfMessage())
    assert c.our_state is MIGHT_SWITCH_PROTOCOL
    s.receive_data(wire + b"\x16\x03 tls-bytes")
    assert isinstance(s.next_event(), Request)
    assert isinstance(s.next_event(), EndOfMessage)  # client is now MIGHT_SWITCH_PROTOCOL
    assert s.next_event() is PAUSED  # pulls paused until the server answers
    s.send(Response(status_code=200, headers=[]))
    assert s.our_state is SWITCHED_PROTOCOL and s.their_state is SWITCHED_PROTOCOL
    assert s.trailing_data == (b"\x16\x03 tls-bytes", False)
    assert s.next_event() is PAUSED
    with pytest.raises(LocalProtocolError):
        s.send(EndOfMessage())
    with pytest.raises(LocalProtocolError):
        s.start_next_cycle()


def test_connect_denied_then_next_cycle():
    c = Connection(CLIENT)
    s = Connection(SERVER)
    s.receive_data(c.send(Request(method="CONNECT", target="x:443", headers=[("Host", "x:443")])))
    c.send(EndOfMessage())
    s.next_event()
    s.next_event()
    s.send(Response(status_code=407, headers=[("Content-Length", "0")]))
    assert c.their_state is SEND_RESPONSE  # client has not pulled the 407 yet
    c.receive_data(b"HTTP/1.1 407 X\r\nContent-Length: 0\r\n\r\n")
    c.next_event()
    assert c.next_event() == EndOfMessage()
    s.send(EndOfMessage())
    assert c.our_state is DONE and s.our_state is DONE
    assert c.states[SERVER] is DONE and s.states[CLIENT] is DONE


def test_upgrade_101_accepts_switch():
    c = Connection(CLIENT)
    s = Connection(SERVER)
    wire = c.send(Request(method="GET", target="/ws", headers=[("Host", "a"), ("Upgrade", "websocket"),
                                                              ("Connection", "Upgrade")]))
    wire += c.send(EndOfMessage())
    s.receive_data(wire)
    s.next_event()
    s.next_event()
    s.send(InformationalResponse(status_code=101, headers=[("Upgrade", "websocket")], reason=b"Switching"))
    assert s.our_state is SWITCHED_PROTOCOL
    assert s.their_state is SWITCHED_PROTOCOL


def test_informational_non_101_neither_accepts_nor_denies_upgrade():
    s = Connection(SERVER)
    s.receive_data(b"GET /ws HTTP/1.1\r\nHost: a\r\nUpgrade: websocket\r\n\r\n")
    s.next_event()
    s.next_event()
    s.send(InformationalResponse(status_code=103, headers=[]))
    assert s.our_state is SEND_RESPONSE


def test_client_cannot_send_request_while_might_switch():
    c = Connection(CLIENT)
    c.send(Request(method="CONNECT", target="x:443", headers=[("Host", "x:443")]))
    c.send(EndOfMessage())
    with pytest.raises(LocalProtocolError):
        c.send(Request(method="GET", target="/", headers=[("Host", "a")]))


# ---------------------------------------------------------------- NOTES.md-documented choices

def test_send_data_chunked_hex_and_empty_data_noop():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    s.send(Response(status_code=200, headers=[]))
    assert s.send(Data(data=b"")) == b""
    assert s.send(Data(data=b"x" * 255)).startswith(b"ff\r\n")
