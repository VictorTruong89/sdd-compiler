"""Role and state markers (spec: Interface Contract 'Shape of the public surface', FP-02)."""


class _Marker(object):
    """A named, identity-compared singleton. Not a string, not equal to anything else."""

    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return self._name

    def __reduce__(self):
        # Pickle by global name so identity survives a round trip.
        return self._name


# spec: N-000438, N-000439 (roles)
CLIENT = _Marker("CLIENT")
SERVER = _Marker("SERVER")

# spec: N-000440..N-000442 (non-event results of next_event)
NEED_DATA = _Marker("NEED_DATA")
PAUSED = _Marker("PAUSED")

# spec: N-000443..N-000445 (the nine states, FP-02 N-000123..N-000126)
IDLE = _Marker("IDLE")
SEND_RESPONSE = _Marker("SEND_RESPONSE")
SEND_BODY = _Marker("SEND_BODY")
DONE = _Marker("DONE")
MUST_CLOSE = _Marker("MUST_CLOSE")
CLOSED = _Marker("CLOSED")
MIGHT_SWITCH_PROTOCOL = _Marker("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = _Marker("SWITCHED_PROTOCOL")
ERROR = _Marker("ERROR")


def other_role(role):
    """Return the peer role of `role`."""
    return SERVER if role is CLIENT else CLIENT
