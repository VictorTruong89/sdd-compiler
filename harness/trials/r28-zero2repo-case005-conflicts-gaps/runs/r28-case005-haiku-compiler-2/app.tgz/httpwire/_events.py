"""Event types and header-list normalization (spec: FP-01, Interface Contract 'Events' and 'Errors')."""

import re
from collections.abc import Sequence

from ._errors import LocalProtocolError

_TOKEN_RE = re.compile(rb"[!#$%&'*+\-.^_`|~0-9A-Za-z]+")  # spec: N-000106, N-000110, N-000111
_TARGET_RE = re.compile(rb"[\x21-\x7e]+")  # spec: N-000110 (visible ASCII, bytes 33..126)
_VERSION_RE = re.compile(rb"[0-9]\.[0-9]")  # spec: N-000075 (two digits separated by a dot)
_REASON_RE = re.compile(rb"[\t\x20-\x7e\x80-\xff]*")  # no CR, LF, NUL or other control bytes
_LENGTH_PIECE_RE = re.compile(rb"[0-9]{1,18}")  # spec: N-000114..N-000116 (at most 18 digits)

# spec: N-000117..N-000119 (Content-Length digit limit, implementer's choice 18..32)
MAX_CONTENT_LENGTH_DIGITS = 18


def as_bytes(value, what):
    """Accept ASCII str or any bytes-like object; return exact `bytes`.

    spec: N-000072..N-000076, N-000458, N-000459.
    """
    if isinstance(value, str):
        try:
            return value.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("%s must be ASCII text or bytes" % what)
    if isinstance(value, (bytes, bytearray, memoryview)):
        return bytes(value)
    raise LocalProtocolError("%s must be str or bytes-like, not %s" % (what, type(value).__name__))


def _token(value, what):
    value = as_bytes(value, what)
    if not _TOKEN_RE.fullmatch(value):
        raise LocalProtocolError("%s must be a single RFC 7230 token" % what)
    return value


def _version(value):
    value = as_bytes(value, "HTTP version")
    if not _VERSION_RE.fullmatch(value):
        raise LocalProtocolError("HTTP version must be two digits separated by a dot")
    return value


def _check_value(value):
    """spec: N-000097..N-000100, N-000108 (value rule; tab allowed between bytes only)."""
    if value[:1] in (b" ", b"\t") or value[-1:] in (b" ", b"\t"):
        raise LocalProtocolError("header value may not begin or end with space or tab")
    for byte in value:
        if byte == 9:
            continue
        if byte < 32 or byte == 127:
            raise LocalProtocolError("header value contains a control byte")


class Headers(Sequence):
    """Ordered header list.

    Iterating or indexing yields the ordinary view: (lowercase name, value) pairs.
    `raw_items()` yields (name as the caller spelled it, value) pairs.
    spec: N-000467..N-000471.
    """

    def __init__(self, pairs):
        self._raw = tuple((bytes(name), bytes(value)) for name, value in pairs)
        self._view = tuple((name.lower(), value) for name, value in self._raw)

    def __len__(self):
        return len(self._view)

    def __getitem__(self, index):
        return self._view[index]

    def raw_items(self):
        return list(self._raw)

    def __eq__(self, other):
        if isinstance(other, Headers):
            return self._view == other._view
        try:
            return list(self._view) == [tuple(pair) for pair in other]
        except TypeError:
            return NotImplemented

    __hash__ = None

    def __repr__(self):
        return "Headers(%r)" % (list(self._view),)


def normalize_headers(headers):
    """Validate and normalize a header list (spec: FP-01 header rules).

    Returns a Headers. Raises LocalProtocolError on any refusal.
    """
    if isinstance(headers, Headers):
        pairs = headers.raw_items()
    else:
        try:
            iterator = iter(headers)
        except TypeError:
            raise LocalProtocolError("headers must be a sequence of (name, value) pairs")
        pairs = []
        for pair in iterator:
            if not isinstance(pair, (tuple, list)) or len(pair) != 2:
                raise LocalProtocolError("each header must be a (name, value) pair")
            pairs.append((pair[0], pair[1]))

    items = []
    for name, value in pairs:
        name = as_bytes(name, "header name")
        value = as_bytes(value, "header value")
        if not _TOKEN_RE.fullmatch(name):  # spec: N-000106
            raise LocalProtocolError("header name %r is not an RFC 7230 token" % (name,))
        _check_value(value)
        items.append([name, value])

    items = _merge_content_length(items)  # spec: N-000092..N-000096, N-000114..N-000119
    items = _merge_transfer_encoding(items)  # spec: N-000092..N-000096, N-000120, N-000121
    return Headers((name, value) for name, value in items)


def _merge_content_length(items):
    indexes = [i for i, (name, _) in enumerate(items) if name.lower() == b"content-length"]
    if not indexes:
        return items
    values = set()
    for i in indexes:
        for piece in items[i][1].split(b","):
            digits = piece.strip(b" \t")
            if not _LENGTH_PIECE_RE.fullmatch(digits):
                raise LocalProtocolError("Content-Length must be a decimal integer")
            values.add(int(digits))
    if len(values) != 1:
        raise LocalProtocolError("conflicting Content-Length values")
    collapsed = [items[indexes[0]][0], str(values.pop()).encode("ascii")]
    out = []
    for i, item in enumerate(items):
        if i == indexes[0]:
            out.append(collapsed)
        elif i not in indexes:
            out.append(item)
    return out


def _merge_transfer_encoding(items):
    indexes = [i for i, (name, _) in enumerate(items) if name.lower() == b"transfer-encoding"]
    if not indexes:
        return items
    if len(indexes) > 1:
        raise LocalProtocolError("a second Transfer-Encoding header is refused", 501)
    i = indexes[0]
    if items[i][1].lower() != b"chunked":
        raise LocalProtocolError("only the chunked transfer coding is supported", 501)
    items[i][1] = b"chunked"
    return items


class _Event(object):
    _fields = ()

    def __eq__(self, other):
        if type(other) is not type(self):
            return NotImplemented
        return all(getattr(self, f) == getattr(other, f) for f in self._fields)

    __hash__ = None

    def __repr__(self):
        return "%s(%s)" % (
            type(self).__name__,
            ", ".join("%s=%r" % (f, getattr(self, f)) for f in self._fields),
        )


class Request(_Event):
    """Start of a request (spec: FP-01 N-000072..N-000078, N-000104, N-000105, N-000110, N-000111)."""

    _fields = ("method", "target", "headers", "http_version")

    def __init__(self, method, target, headers, http_version=b"1.1"):
        self.method = _token(method, "method")
        target = as_bytes(target, "request target")
        if not _TARGET_RE.fullmatch(target):
            raise LocalProtocolError("request target must be one or more visible ASCII bytes")
        self.target = target
        self.http_version = _version(http_version)
        self.headers = normalize_headers(headers)
        hosts = sum(1 for name, _ in self.headers if name == b"host")
        if hosts > 1:  # spec: N-000105 (any version)
            raise LocalProtocolError("more than one Host header")
        if self.http_version == b"1.1" and hosts == 0:  # spec: N-000104
            raise LocalProtocolError("an HTTP/1.1 request needs a Host header")


class _ResponseBase(_Event):
    _fields = ("status_code", "headers", "http_version", "reason")
    _low = 0
    _high = 0

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        if not isinstance(status_code, int):  # spec: N-000113
            raise LocalProtocolError("status code must be an integer")
        status = int(status_code)
        if not (self._low <= status < self._high):  # spec: N-000112
            raise LocalProtocolError("status %d is outside the range for %s" % (status, type(self).__name__))
        self.status_code = status
        self.headers = normalize_headers(headers)
        self.http_version = _version(http_version)
        reason = as_bytes(reason, "reason")
        if not _REASON_RE.fullmatch(reason):
            raise LocalProtocolError("reason phrase contains a forbidden byte")
        self.reason = reason


class InformationalResponse(_ResponseBase):
    """1xx status: 100 inclusive to 200 exclusive (spec: N-000079..N-000083)."""

    _low = 100
    _high = 200


class Response(_ResponseBase):
    """Final status: 200 inclusive to 1000 exclusive (spec: N-000079..N-000083)."""

    _low = 200
    _high = 1000


class Data(_Event):
    """A piece of a message body (spec: N-000084, N-000463..N-000465)."""

    _fields = ("data", "chunk_start", "chunk_end")

    def __init__(self, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)

    def __eq__(self, other):
        if type(other) is not Data:
            return NotImplemented
        return (
            self.data == other.data
            and self.chunk_start == other.chunk_start
            and self.chunk_end == other.chunk_end
        )

    __hash__ = None


class EndOfMessage(_Event):
    """End of a message, optionally with trailing headers (spec: N-000085)."""

    _fields = ("headers",)

    def __init__(self, headers=()):
        self.headers = normalize_headers(headers)


class ConnectionClosed(_Event):
    """This side will send no more HTTP data (spec: N-000086, N-000457)."""

    _fields = ()

    def __init__(self):
        pass
