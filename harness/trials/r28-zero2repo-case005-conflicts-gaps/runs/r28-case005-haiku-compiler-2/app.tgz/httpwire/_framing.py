"""Body framing, header-block parsing and body readers/writers (spec: FP-03, FP-05, FP-07)."""

import re

from ._errors import LocalProtocolError, RemoteProtocolError
from ._events import Data, EndOfMessage, normalize_headers

# Framing kinds.
LENGTH = "length"  # Content-Length: N
CHUNKED = "chunked"  # Transfer-Encoding: chunked
CLOSE = "close"  # neither header; body ends when the connection closes (HTTP/1.0 style)
EMPTY = "empty"  # no body at all (HEAD, 204, 304, informational)

# spec: N-000228..N-000232 (chunk-size digits, implementer's choice 16..32), N-000192 (MAY 64)
CHUNK_SIZE_MAX_DIGITS = 32
_CHUNK_SIZE_RE = re.compile(rb"([0-9A-Fa-f]{1,32})(?:;[^\r\n]*)?")
_HEX_PREFIX_RE = re.compile(rb"[0-9A-Fa-f]*")


# ---------------------------------------------------------------- header lookups

def content_length(headers):
    for name, value in headers.raw_items():
        if name.lower() == b"content-length":
            return int(value)
    return None


def has_header(headers, name):
    return any(n.lower() == name for n, _ in headers.raw_items())


def connection_tokens(headers):
    tokens = []
    for name, value in headers.raw_items():
        if name.lower() == b"connection":
            tokens.extend(t.strip(b" \t").lower() for t in value.split(b","))
    return [t for t in tokens if t]


def has_token(headers, name, token):
    """True if some header `name` lists `token` as a comma-separated element (case-insensitive)."""
    for n, value in headers.raw_items():
        if n.lower() == name:
            if token in [t.strip(b" \t").lower() for t in value.split(b",")]:
                return True
    return False


def is_chunked(headers):
    return has_header(headers, b"transfer-encoding")


# ---------------------------------------------------------------- framing decisions

def request_kind(headers):
    """spec: N-000185..N-000197 (request framing; CL decides when both are present)."""
    if content_length(headers) is not None:
        return LENGTH
    if is_chunked(headers):
        return CHUNKED
    return LENGTH  # no framing headers: empty body


def response_kind(headers, status, method):
    """Receive-side response framing. spec: N-000198..N-000218 (HEAD/204/304 empty; CL; TE; close)."""
    if status < 200 or method == b"HEAD" or status in (204, 304):
        return EMPTY
    if content_length(headers) is not None:
        return LENGTH
    if is_chunked(headers):
        return CHUNKED
    return CLOSE


def make_reader(kind, headers, max_size):
    if kind == LENGTH:
        return LengthReader(content_length(headers) or 0)
    if kind == CHUNKED:
        return ChunkedReader(max_size)
    if kind == CLOSE:
        return ClosedDelimitedReader()
    return EmptyReader()


def make_writer(kind, headers):
    if kind == LENGTH:
        return LengthWriter(content_length(headers) or 0)
    if kind == CHUNKED:
        return ChunkedWriter()
    if kind == CLOSE:
        return CloseWriter()
    return EmptyWriter()


# ---------------------------------------------------------------- wire helpers

def take_block(buf, limit):
    """Pop complete lines up to and including the blank line that ends a head or trailer block.

    Returns the list of lines (without line endings), or None if the block is still incomplete.
    Lone LF line endings are accepted (spec: N-000165, N-000166).
    Raises RemoteProtocolError 431 when an unfinished block exceeds `limit` (spec: N-000316..N-000323).
    """
    pos = 0
    lines = []
    while True:
        idx = buf.find(b"\n", pos)
        if idx < 0:
            if len(buf) > limit:
                raise RemoteProtocolError("incomplete message exceeds the incomplete-event size limit", 431)
            return None
        line = bytes(buf[pos:idx])
        pos = idx + 1
        if line.endswith(b"\r"):
            line = line[:-1]
        if not line:
            break
        lines.append(line)
    del buf[:pos]
    return lines


def parse_fields(lines):
    """Turn raw header lines into (name, value) pairs, joining obsolete line folds (spec: N-000167..N-000169)."""
    pairs = []
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            if not pairs:
                raise RemoteProtocolError("continuation line without a preceding header")
            name, value = pairs[-1]
            pairs[-1] = (name, value + b" " + line.lstrip(b" \t"))
            continue
        name, sep, value = line.partition(b":")
        if not sep:
            raise RemoteProtocolError("header line has no colon")
        pairs.append((name, value))
    return [(name, value.strip(b" \t")) for name, value in pairs]


def format_fields(items):
    """Serialize (name, value) pairs as header lines plus the terminating blank line."""
    return b"".join(name + b": " + value + b"\r\n" for name, value in items) + b"\r\n"


def payload_length(payload):
    if isinstance(payload, str):
        raise LocalProtocolError("data payload must be bytes-like")
    if isinstance(payload, (bytes, bytearray, memoryview)):
        return memoryview(payload).nbytes
    try:
        return len(payload)
    except TypeError:
        raise LocalProtocolError("data payload must be bytes-like or an object with a length")


# ---------------------------------------------------------------- readers (receive side)

class LengthReader(object):
    """spec: N-000188..N-000191, N-000140..N-000143."""

    def __init__(self, length):
        self._remaining = length

    def read(self, buf, closed):
        if self._remaining == 0:
            return EndOfMessage()
        if not buf:
            return None
        n = min(len(buf), self._remaining)
        payload = bytes(buf[:n])
        del buf[:n]
        self._remaining -= n
        return Data(data=payload)


class ChunkedReader(object):
    """spec: N-000192..N-000197, N-000220..N-000232, N-000242..N-000245."""

    def __init__(self, max_size):
        self._max_size = max_size
        self._state = "size"
        self._remaining = 0
        self._at_chunk_start = False

    def read(self, buf, closed):
        while True:
            if self._state == "size":
                idx = buf.find(b"\n")
                if idx < 0:
                    self._check_partial_size(buf)
                    return None
                raw = bytes(buf[:idx])
                del buf[: idx + 1]
                if raw.endswith(b"\r"):
                    raw = raw[:-1]
                match = _CHUNK_SIZE_RE.fullmatch(raw)
                if match is None:
                    raise RemoteProtocolError("invalid chunk-size line")
                size = int(match.group(1), 16)
                if size == 0:
                    self._state = "trailers"
                    continue
                self._remaining = size
                self._at_chunk_start = True
                self._state = "data"
                continue
            if self._state == "data":
                if not buf:
                    return None
                n = min(len(buf), self._remaining)
                payload = bytes(buf[:n])
                del buf[:n]
                start = self._at_chunk_start
                self._at_chunk_start = False
                self._remaining -= n
                end = self._remaining == 0
                if end:
                    self._state = "data_end"
                return Data(data=payload, chunk_start=start, chunk_end=end)
            if self._state == "data_end":
                if buf[:2] == b"\r\n":
                    del buf[:2]
                    self._state = "size"
                    continue
                if len(buf) < 2 and b"\r\n".startswith(bytes(buf)):
                    if closed:
                        raise RemoteProtocolError("connection closed in the middle of a chunk")
                    return None
                raise RemoteProtocolError("chunk data is not followed by CRLF")
            if self._state == "trailers":
                lines = take_block(buf, self._max_size)
                if lines is None:
                    if closed:
                        raise RemoteProtocolError("connection closed in the middle of trailing headers")
                    return None
                self._state = "done"
                return EndOfMessage(headers=normalize_headers(parse_fields(lines)))
            return None

    @staticmethod
    def _check_partial_size(buf):
        """Refuse a size line that is already known to be bad, before its line ending arrives."""
        digits = _HEX_PREFIX_RE.match(bytes(buf)).group(0)
        if len(digits) > CHUNK_SIZE_MAX_DIGITS:
            raise RemoteProtocolError("chunk size has too many hexadecimal digits")
        if len(digits) < len(buf) and bytes(buf[len(digits):len(digits) + 1]) not in (b";", b"\r"):
            raise RemoteProtocolError("invalid byte in chunk-size line")


class ClosedDelimitedReader(object):
    """HTTP/1.0-style body: every byte until the receive side closes (spec: N-000208..N-000214)."""

    def read(self, buf, closed):
        if buf:
            payload = bytes(buf)
            del buf[:]
            return Data(data=payload)
        if closed:
            return EndOfMessage()
        return None


class EmptyReader(object):
    """Bodies that are always empty (spec: N-000215..N-000218)."""

    def read(self, buf, closed):
        return EndOfMessage()


# ---------------------------------------------------------------- writers (send side)

class LengthWriter(object):
    """spec: N-000188..N-000191, N-000238, N-000240."""

    def __init__(self, length):
        self._remaining = length

    def write_data(self, payload, size):
        if size > self._remaining:
            raise LocalProtocolError("data would exceed the remaining Content-Length")
        self._remaining -= size
        return [payload] if size else []

    def write_end(self, trailers):
        if self._remaining:
            raise LocalProtocolError("end-of-message sent before the Content-Length was satisfied")
        if len(trailers):
            raise LocalProtocolError("trailing headers are not allowed with Content-Length framing")
        return []


class ChunkedWriter(object):
    """spec: N-000192..N-000197, N-000233..N-000237."""

    def write_data(self, payload, size):
        if not size:
            return []
        return [b"%x\r\n" % size, payload, b"\r\n"]

    def write_end(self, trailers):
        return [b"0\r\n" + format_fields(trailers.raw_items())]


class CloseWriter(object):
    """Close-delimited body: payload is written raw; nothing follows it (spec: N-000203..N-000206)."""

    def write_data(self, payload, size):
        return [payload] if size else []

    def write_end(self, trailers):
        if len(trailers):
            raise LocalProtocolError("trailing headers cannot be sent without chunked framing")
        return []


class EmptyWriter(object):
    """Body that must be empty (HEAD, 204, 304) (spec: N-000215..N-000218)."""

    def write_data(self, payload, size):
        if size:
            raise LocalProtocolError("this response has no body")
        return []

    def write_end(self, trailers):
        if len(trailers):
            raise LocalProtocolError("this response has no body, so it cannot carry trailers")
        return []
