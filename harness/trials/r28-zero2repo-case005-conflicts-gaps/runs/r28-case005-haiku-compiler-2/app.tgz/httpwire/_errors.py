"""Exception types (spec: FP-05, Interface Contract 'Errors')."""


class ProtocolError(Exception):
    """Common base of the two protocol-error kinds. Carries a suggested status.

    spec: N-000290..N-000296 (distinct kinds), N-000472 (error_status_hint is an int).
    """

    def __init__(self, message="", error_status_hint=400):
        Exception.__init__(self, message)
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(ProtocolError):
    """The integrator's own event or send violated HTTP/1.1 (spec: FP-05)."""


class RemoteProtocolError(ProtocolError):
    """The peer's bytes violated HTTP/1.1 (spec: FP-05)."""


class ReceiveClosedError(RuntimeError):
    """Non-empty bytes were fed after the receive side was closed.

    Deliberately neither a LocalProtocolError nor a RemoteProtocolError
    (spec: N-000180..N-000182, N-000291, N-000474).
    """
