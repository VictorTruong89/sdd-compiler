"""The Connection state machine (spec: FP-02, FP-03, FP-04, FP-05, FP-06, FP-07;
Interface Contract 'Connection').

Bytes in and bytes out only; this module never touches a socket (spec: N-000047..N-000049).
"""

import re

from ._errors import LocalProtocolError, RemoteProtocolError, ReceiveClosedError
from ._events import (
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    Request,
    Response,
    normalize_headers,
)
from ._framing import (
    CHUNKED,
    CLOSE,
    LENGTH,
    connection_tokens,
    content_length,
    format_fields,
    has_header,
    has_token,
    is_chunked,
    make_reader,
    make_writer,
    parse_fields,
    payload_length,
    request_kind,
    response_kind,
    take_block,
    EmptyWriter,
    LengthWriter,
    ChunkedWriter,
    CloseWriter,
)
from ._state import (
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
    other_role,
)

# spec: N-000317..N-000323 (default limit must be 14..18 KiB) vs N-000479 (8 KiB) -- see NOTES.md.
DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 16 * 1024

_REQUEST_LINE_RE = re.compile(rb"([!#$%&'*+\-.^_`|~0-9A-Za-z]+) ([\x21-\x7e]+) HTTP/([01]\.[01])")
_STATUS_LINE_RE = re.compile(rb"HTTP/([01]\.[01]) ([0-9]{3})(?: (.*))?")

_TE = b"transfer-encoding"
_CL = b"content-length"


def _status_line(event):
    return b"HTTP/1.1 " + str(event.status_code).encode("ascii") + b" " + event.reason + b"\r\n"


def _with_connection_close(items):
    """Drop `keep-alive` tokens and make sure `Connection: close` is present (spec: N-000265..N-000268)."""
    out = []
    for name, value in items:
        if name.lower() == b"connection":
            kept = [t.strip(b" \t") for t in value.split(b",")]
            kept = [t for t in kept if t and t.lower() != b"keep-alive"]
            if kept:
                out.append((name, b", ".join(kept)))
            continue
        out.append((name, value))
    if b"close" not in [t.lower() for t in _tokens_of(out)]:
        out.append((b"Connection", b"close"))
    return out


def _tokens_of(items):
    tokens = []
    for name, value in items:
        if name.lower() == b"connection":
            tokens.extend(t.strip(b" \t") for t in value.split(b","))
    return [t for t in tokens if t]


def _host_first(items):
    """spec: N-000161, N-000162 (Host is written before every other header)."""
    hosts = [item for item in items if item[0].lower() == b"host"]
    others = [item for item in items if item[0].lower() != b"host"]
    return hosts + others


def _wire_bytes(piece):
    if isinstance(piece, (bytes, bytearray, memoryview)):
        return bytes(piece)
    raise LocalProtocolError("data payload cannot be joined into a single buffer; use passthrough send")


class Connection(object):
    """One HTTP/1.1 connection in the client or server role (spec: FP-02)."""

    def __init__(self, role, max_incomplete_event_size=DEFAULT_MAX_INCOMPLETE_EVENT_SIZE):
        if role is not CLIENT and role is not SERVER:
            raise LocalProtocolError("role must be CLIENT or SERVER, not %r" % (role,))  # spec: N-000172, N-000173
        if max_incomplete_event_size is None:
            max_incomplete_event_size = DEFAULT_MAX_INCOMPLETE_EVENT_SIZE
        if isinstance(max_incomplete_event_size, bool) or not isinstance(max_incomplete_event_size, int):
            raise LocalProtocolError("max_incomplete_event_size must be an int")  # spec: N-000478..N-000480
        self.our_role = role
        self.their_role = other_role(role)
        self._cstate = {CLIENT: IDLE, SERVER: IDLE}  # spec: N-000123..N-000125
        self._max_size = int(max_incomplete_event_size)
        self._buffer = bytearray()
        self._receive_closed = False
        self._their_version = None
        self._reader = None
        self._writer = None
        self._cycle_method = None
        self._proposal_connect = False  # a CONNECT request is awaiting an answer (FP-07)
        self._proposal_upgrade = False  # a request with Upgrade is awaiting an answer (FP-07)
        self._our_close = False
        self._their_close = False
        self._client_waiting = False  # spec: N-000354..N-000359

    # ------------------------------------------------------------ queryable state

    @property
    def our_state(self):
        return self._cstate[self.our_role]

    @property
    def their_state(self):
        return self._cstate[self.their_role]

    @property
    def states(self):
        return dict(self._cstate)

    @property
    def their_http_version(self):
        return self._their_version

    @property
    def client_is_waiting_for_100_continue(self):
        return bool(self._client_waiting)

    @property
    def they_are_waiting_for_100_continue(self):
        return bool(self._client_waiting and self.our_role is SERVER)

    @property
    def trailing_data(self):
        return (bytes(self._buffer), bool(self._receive_closed))

    # ------------------------------------------------------------ receive side

    def receive_data(self, data):
        """Store bytes from the peer; an empty chunk means the peer closed its sending side."""
        chunk = bytes(data)
        if not chunk:
            self._receive_closed = True
            return None
        if self._receive_closed:
            raise ReceiveClosedError("bytes were fed after the receive side was closed")
        self._buffer += chunk
        return None

    def next_event(self):
        """Pull one event, NEED_DATA, or PAUSED. spec: FP-02, FP-04, FP-05, FP-06, FP-07."""
        try:
            return self._next_event()
        except RemoteProtocolError:
            self._fail_peer()
            raise
        except LocalProtocolError as exc:
            self._fail_peer()
            raise RemoteProtocolError(str(exc), exc.error_status_hint)

    def _next_event(self):
        peer = self.their_role
        state = self._cstate[peer]
        if state is ERROR:  # spec: N-000302..N-000306
            raise RemoteProtocolError("the peer already violated HTTP/1.1; no further events can be read", 400)
        if state is MIGHT_SWITCH_PROTOCOL or state is SWITCHED_PROTOCOL:  # spec: N-000373..N-000387
            return PAUSED
        if state is CLOSED:
            return ConnectionClosed()
        if state is DONE or state is MUST_CLOSE:  # spec: N-000275..N-000279, N-000339..N-000341
            if self._buffer:
                return PAUSED
            if self._receive_closed:
                return self._pull_close()
            return NEED_DATA
        if state is SEND_BODY:
            event = self._reader.read(self._buffer, self._receive_closed)
            if event is None:
                if self._receive_closed:
                    raise RemoteProtocolError("connection closed in the middle of a message body")  # spec: N-000324
                return NEED_DATA
            self._apply(peer, event)
            if isinstance(event, EndOfMessage):
                self._reader = None
            return event

        # IDLE (a request, or an unsolicited response) or SEND_RESPONSE (a response is expected).
        if not self._buffer:
            if self._receive_closed:
                if state is IDLE:
                    return self._pull_close()  # spec: N-000339
                raise RemoteProtocolError("connection closed while a response was still expected")  # spec: N-000324
            return NEED_DATA
        if self._buffer[0] < 33:  # spec: N-000177..N-000179
            raise RemoteProtocolError("message starts with a space or a control byte")
        lines = take_block(self._buffer, self._max_size)  # spec: N-000316..N-000323
        if lines is None:
            if self._receive_closed:
                raise RemoteProtocolError("connection closed in the middle of a header block")
            return NEED_DATA

        event = self._parse_head(lines)
        if isinstance(event, Request):
            self._apply(peer, event)
            self._reader = make_reader(request_kind(event.headers), event.headers, self._max_size)
        elif isinstance(event, Response):
            kind = response_kind(event.headers, event.status_code, self._cycle_method)
            action = self._apply(peer, event, close_framing=(kind == CLOSE))
            if action != "accept":
                self._reader = make_reader(kind, event.headers, self._max_size)
        else:
            self._apply(peer, event)
        return event

    def _parse_head(self, lines):
        start = lines[0]
        pairs = parse_fields(lines[1:])
        if self.their_role is CLIENT:
            match = _REQUEST_LINE_RE.fullmatch(start)
            if match is None:
                raise RemoteProtocolError("malformed request line")
            return Request(
                method=match.group(1),
                target=match.group(2),
                headers=normalize_headers(pairs),
                http_version=match.group(3),
            )
        match = _STATUS_LINE_RE.fullmatch(start)
        if match is None:
            raise RemoteProtocolError("malformed status line")
        version = match.group(1)
        status = int(match.group(2))
        reason = match.group(3) or b""
        headers = normalize_headers(pairs)
        if 100 <= status < 200:
            return InformationalResponse(status_code=status, headers=headers, http_version=version, reason=reason)
        if 200 <= status < 1000:
            return Response(status_code=status, headers=headers, http_version=version, reason=reason)
        raise RemoteProtocolError("status code %d is out of range" % status)

    def _pull_close(self):
        event = ConnectionClosed()
        self._apply(self.their_role, event)
        return event

    def _fail_peer(self):
        states = dict(self._cstate)
        states[self.their_role] = ERROR
        self._install(states)

    # ------------------------------------------------------------ send side

    def send(self, event):
        """Encode one event into bytes (possibly b""). spec: N-000497..N-000501."""
        return self._guarded(event, join=True)

    def send_with_data_passthrough(self, event):
        """Encode one event into a list of pieces; data objects are kept by identity. spec: N-000502..N-000506."""
        return self._guarded(event, join=False)

    def _guarded(self, event, join):
        if self._cstate[self.our_role] is ERROR:  # spec: N-000307..N-000310
            raise LocalProtocolError("this side is in ERROR; sends are refused")
        try:
            pieces = self._send(event)
            if join:
                return b"".join(_wire_bytes(piece) for piece in pieces)
            return pieces
        except LocalProtocolError:
            self._fail_ours()
            raise

    def send_failed(self):
        """Tell the connection the last send's bytes never went out. spec: N-000520..N-000522, N-000312."""
        self._fail_ours()
        return None

    def _fail_ours(self):
        states = dict(self._cstate)
        states[self.our_role] = ERROR
        self._install(states)

    def _send(self, event):
        if isinstance(event, Request):
            return self._send_request(event)
        if isinstance(event, (InformationalResponse, Response)):
            return self._send_response(event)
        if isinstance(event, Data):
            self._plan(self.our_role, event)
            pieces = self._writer.write_data(event.data, payload_length(event.data))
            self._apply(self.our_role, event)
            return pieces
        if isinstance(event, EndOfMessage):
            self._plan(self.our_role, event)
            pieces = self._writer.write_end(event.headers)
            self._apply(self.our_role, event)
            self._writer = None
            return pieces
        if isinstance(event, ConnectionClosed):
            self._apply(self.our_role, event)
            return []
        raise LocalProtocolError("send() takes an HTTP event; got %r" % (event,))

    def _send_request(self, event):
        if event.http_version != b"1.1":  # spec: N-000156, FP-05
            raise LocalProtocolError("only HTTP/1.1 requests can be sent")
        self._plan(self.our_role, event)
        kind = request_kind(event.headers)
        items = list(event.headers.raw_items())
        if kind == LENGTH:
            items = [item for item in items if item[0].lower() != _TE]
        items = _host_first(items)
        head = event.method + b" " + event.target + b" HTTP/1.1\r\n" + format_fields(items)
        writer = make_writer(kind, event.headers)
        self._apply(self.our_role, event)
        self._writer = writer
        return [head]

    def _send_response(self, event):
        if event.http_version != b"1.1":  # spec: N-000156, FP-05
            raise LocalProtocolError("only HTTP/1.1 responses can be sent")
        _, action = self._plan(self.our_role, event)
        items = list(event.headers.raw_items())

        if isinstance(event, InformationalResponse):
            head = _status_line(event) + format_fields(items)
            self._apply(self.our_role, event)
            return [head]

        if action == "accept":  # CONNECT 2xx or 101 accepted: no body, no end-of-message
            head = _status_line(event) + format_fields(items)
            self._apply(self.our_role, event)
            self._writer = None
            return [head]

        peer_is_11 = self._their_version == b"1.1"
        has_te = is_chunked(event.headers)
        cl = content_length(event.headers)
        # spec: FP-03 N-000200..N-000207 (TE wins; otherwise peer version decides), N-000219 (HEAD).
        if has_te:
            kind = CHUNKED if peer_is_11 else CLOSE
        elif cl is not None:
            kind = LENGTH
        else:
            kind = CHUNKED if peer_is_11 else CLOSE
        status = event.status_code
        no_body = self._cycle_method == b"HEAD" or status in (204, 304)  # spec: N-000215..N-000218
        add_framing = status not in (204, 304)

        if kind == CHUNKED:
            items = [item for item in items if item[0].lower() != _CL]
            if not has_te and add_framing:
                items.append((b"Transfer-Encoding", b"chunked"))
        elif kind == CLOSE:
            items = [item for item in items if item[0].lower() not in (_TE, _CL)]

        if no_body:
            writer = EmptyWriter()
        elif kind == LENGTH:
            writer = LengthWriter(cl)
        elif kind == CHUNKED:
            writer = ChunkedWriter()
        else:
            writer = CloseWriter()

        close_framing = kind == CLOSE
        if close_framing or self._keep_alive_disabled(self._cstate):  # spec: N-000265..N-000269
            items = _with_connection_close(items)
        head = _status_line(event) + format_fields(items)
        self._apply(self.our_role, event, close_framing=close_framing)
        self._writer = writer
        return [head]

    # ------------------------------------------------------------ state machine

    def start_next_cycle(self):
        """Reset both sides to IDLE after a completed cycle. spec: N-000270..N-000282."""
        if self._cstate[CLIENT] is not DONE or self._cstate[SERVER] is not DONE:
            raise LocalProtocolError("the next cycle can start only when both sides are DONE")
        self._cstate = {CLIENT: IDLE, SERVER: IDLE}
        self._cycle_method = None
        self._proposal_connect = False
        self._proposal_upgrade = False
        self._our_close = False
        self._their_close = False
        self._client_waiting = False
        self._reader = None
        self._writer = None
        return None

    def _note_close(self, sender):
        if sender is self.our_role:
            self._our_close = True
        else:
            self._their_close = True

    def _keep_alive_disabled(self, states):
        """spec: N-000259..N-000264, N-000286, N-000287 (keep-alive needs HTTP/1.1 on both sides, no close)."""
        if self._our_close or self._their_close:
            return True
        if self._their_version is not None and self._their_version != b"1.1":
            return True
        return states[self.their_role] is ERROR  # spec: N-000305, N-000306

    def _plan(self, sender, event):
        """Compute the next states for `event` sent (or pulled) by `sender`, without changing anything.

        Returns (states, action). action is None, "accept" (switch accepted) or "deny".
        Raises LocalProtocolError when the event is illegal in the current states.
        """
        st = dict(self._cstate)
        action = None
        if isinstance(event, Request):
            if sender is not CLIENT:
                raise LocalProtocolError("only the client role sends requests")  # spec: N-000284
            if st[CLIENT] is not IDLE:
                raise LocalProtocolError("a second request needs the next cycle to be started first")  # spec: N-000285
            st[CLIENT] = SEND_BODY
            if st[SERVER] is IDLE:  # spec: N-000250, N-000251
                st[SERVER] = SEND_RESPONSE
        elif isinstance(event, InformationalResponse):
            if sender is not SERVER:
                raise LocalProtocolError("only the server role sends informational responses")  # spec: N-000283
            if st[SERVER] is not SEND_RESPONSE:
                raise LocalProtocolError("informational response outside SEND_RESPONSE")
            if self._proposal_upgrade and event.status_code == 101 and st[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                st[CLIENT] = SWITCHED_PROTOCOL  # spec: N-000369..N-000372
                st[SERVER] = SWITCHED_PROTOCOL
                action = "accept"
        elif isinstance(event, Response):
            if sender is not SERVER:
                raise LocalProtocolError("only the server role sends responses")  # spec: N-000283
            if st[SERVER] is not IDLE and st[SERVER] is not SEND_RESPONSE:
                raise LocalProtocolError("a final response is not allowed in the server's current state")
            if (
                self._proposal_connect
                and 200 <= event.status_code < 300
                and st[CLIENT] is MIGHT_SWITCH_PROTOCOL
            ):
                st[CLIENT] = SWITCHED_PROTOCOL  # spec: N-000364, N-000381
                st[SERVER] = SWITCHED_PROTOCOL
                action = "accept"
            else:
                st[SERVER] = SEND_BODY  # spec: N-000255..N-000258, N-000136..N-000139
                if st[CLIENT] is MIGHT_SWITCH_PROTOCOL:  # spec: N-000378..N-000380 (denial)
                    st[CLIENT] = DONE
                    action = "deny"
        elif isinstance(event, Data):
            if st[sender] is not SEND_BODY:
                raise LocalProtocolError("data outside of a message body")  # spec: N-000140..N-000152
        elif isinstance(event, EndOfMessage):
            if st[sender] is not SEND_BODY:
                raise LocalProtocolError("end-of-message outside of a message body")
            if sender is CLIENT and (self._proposal_connect or self._proposal_upgrade):  # spec: N-000373..N-000377
                st[CLIENT] = MIGHT_SWITCH_PROTOCOL
            else:
                st[sender] = DONE  # spec: N-000143, N-000270
        elif isinstance(event, ConnectionClosed):
            if st[sender] not in (IDLE, DONE, MUST_CLOSE):  # spec: N-000334, N-000345, N-000346
                raise LocalProtocolError("connection-closed is not allowed in state %r" % (st[sender],))
            st[sender] = CLOSED
        else:
            raise LocalProtocolError("not an HTTP event: %r" % (event,))
        return st, action

    def _apply(self, sender, event, close_framing=False):
        """Commit an event: update flags and states. Returns the switch action, if any."""
        new_states, action = self._plan(sender, event)  # validates before anything changes
        if sender is self.their_role and isinstance(event, (Request, InformationalResponse, Response)):
            self._their_version = event.http_version  # spec: N-000128, N-000156..N-000160
        if isinstance(event, Request):
            self._cycle_method = event.method
            self._proposal_connect = event.method == b"CONNECT"  # spec: N-000364
            self._proposal_upgrade = has_header(event.headers, b"upgrade")  # spec: N-000366
            # spec: N-000354, N-000357 (HTTP/1.1 only), N-000083 conflict -- see NOTES.md
            self._client_waiting = event.http_version == b"1.1" and has_token(
                event.headers, b"expect", b"100-continue"
            )
            if b"close" in connection_tokens(event.headers):
                self._note_close(sender)
        elif isinstance(event, (InformationalResponse, Response)):
            if sender is SERVER:
                self._client_waiting = False  # spec: N-000358
            if isinstance(event, Response):
                self._proposal_connect = False
                self._proposal_upgrade = False
                if b"close" in connection_tokens(event.headers):
                    self._note_close(sender)
                if close_framing and action != "accept":
                    self._note_close(sender)  # spec: N-000265..N-000269
        elif isinstance(event, (Data, EndOfMessage)):
            if sender is CLIENT:
                self._client_waiting = False  # spec: N-000359
        self._install(new_states)
        return action

    def _install(self, states):
        """Store states and apply the pairing rules. spec: N-000311, N-000336..N-000338, N-000259..N-000264."""
        for role in (CLIENT, SERVER):
            other = other_role(role)
            if states[role] is CLOSED and states[other] in (IDLE, DONE):
                states[other] = MUST_CLOSE
            if states[role] is ERROR and states[other] is DONE:
                states[other] = MUST_CLOSE
        if self._keep_alive_disabled(states):
            for role in (CLIENT, SERVER):
                if states[role] is DONE:
                    states[role] = MUST_CLOSE
        self._cstate = states
