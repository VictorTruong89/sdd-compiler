"""httpwire: a pure-Python HTTP/1.1 wire protocol library with no I/O of its own.

Turn high-level events into bytes with ``Connection.send`` and bytes back into events
with ``Connection.receive_data`` followed by ``Connection.next_event``.
"""

from ._connection import Connection
from ._errors import LocalProtocolError, RemoteProtocolError
from ._events import ConnectionClosed, Data, EndOfMessage, InformationalResponse, Request, Response
from ._state import (
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
)

__version__ = "0.1.0"

__all__ = [
    "CLIENT",
    "SERVER",
    "NEED_DATA",
    "PAUSED",
    "IDLE",
    "SEND_RESPONSE",
    "SEND_BODY",
    "DONE",
    "MUST_CLOSE",
    "CLOSED",
    "MIGHT_SWITCH_PROTOCOL",
    "SWITCHED_PROTOCOL",
    "ERROR",
    "Request",
    "InformationalResponse",
    "Response",
    "Data",
    "EndOfMessage",
    "ConnectionClosed",
    "Connection",
    "LocalProtocolError",
    "RemoteProtocolError",
]
