import re


class _Sentinel:
    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return self._name


CLIENT = _Sentinel("CLIENT")
SERVER = _Sentinel("SERVER")
NEED_DATA = _Sentinel("NEED_DATA")
PAUSED = _Sentinel("PAUSED")
IDLE = _Sentinel("IDLE")
SEND_RESPONSE = _Sentinel("SEND_RESPONSE")
SEND_BODY = _Sentinel("SEND_BODY")
DONE = _Sentinel("DONE")
MUST_CLOSE = _Sentinel("MUST_CLOSE")
CLOSED = _Sentinel("CLOSED")
MIGHT_SWITCH_PROTOCOL = _Sentinel("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = _Sentinel("SWITCHED_PROTOCOL")
ERROR = _Sentinel("ERROR")
_SWITCH_UPGRADE = _Sentinel("_SWITCH_UPGRADE")
_SWITCH_CONNECT = _Sentinel("_SWITCH_CONNECT")

MAX_CONTENT_LENGTH_DIGITS = 18
MAX_CHUNK_SIZE_DIGITS = 32
DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 16 * 1024


# ---------------------------------------------------------------- errors
class ProtocolError(Exception):
    def __init__(self, msg, error_status_hint=400):
        super().__init__(msg)
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(ProtocolError):
    pass


class RemoteProtocolError(ProtocolError):
    pass


# ------------------------------------------------------------ validation
_TOKEN = rb"[-!#$%&'*+.^_`|~0-9a-zA-Z]+"
_TOKEN_RE = re.compile(_TOKEN)
_TARGET_RE = re.compile(rb"[\x21-\x7e]+")
_VALUE_RE = re.compile(
    rb"(?:[^\x00\r\n\x0b\x0c \t](?:[^\x00\r\n\x0b\x0c]*[^\x00\r\n\x0b\x0c \t])?)?")
_VERSION_RE = re.compile(rb"[0-9]\.[0-9]")
_REASON_RE = re.compile(rb"[^\x00-\x08\x0a-\x1f\x7f]*")
_REQUEST_LINE_RE = re.compile(rb"(" + _TOKEN + rb") ([\x21-\x7e]+) HTTP/([0-9]\.[0-9])")
_STATUS_LINE_RE = re.compile(
    rb"HTTP/([0-9]\.[0-9]) ([0-9]{3})(?: ([^\x00-\x08\x0a-\x1f\x7f]*))?")
_CHUNK_RE = re.compile(
    rb"([0-9a-fA-F]+)(?:;[^\r\n]*)?[ \t]*")


def _to_bytes(x, what="value"):
    if isinstance(x, bytes):
        return x
    if isinstance(x, str):
        try:
            return x.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("non-ASCII text in %s" % what)
    try:
        return bytes(memoryview(x))
    except TypeError:
        raise LocalProtocolError("bad type for %s" % what)


class Headers:
    def __init__(self, full):
        self._full = full

    def __len__(self):
        return len(self._full)

    def __iter__(self):
        for _raw, name, value in self._full:
            yield (name, value)

    def __getitem__(self, i):
        if isinstance(i, slice):
            return [(n, v) for _r, n, v in self._full[i]]
        _r, n, v = self._full[i]
        return (n, v)

    def raw_items(self):
        return [(r, v) for r, _n, v in self._full]

    def __eq__(self, other):
        if isinstance(other, Headers):
            return list(self) == list(other)
        try:
            return list(self) == [tuple(x) for x in other]
        except TypeError:
            return NotImplemented

    __hash__ = None

    def __repr__(self):
        return "Headers(%r)" % (self.raw_items(),)


def _normalize_headers(headers):
    if isinstance(headers, Headers):
        headers = headers.raw_items()
    out = []
    saw_cl = None
    saw_te = False
    try:
        items = list(headers)
    except TypeError:
        raise LocalProtocolError("headers must be a sequence")
    for item in items:
        try:
            name, value = item
        except (TypeError, ValueError):
            raise LocalProtocolError("header must be a (name, value) pair")
        raw = _to_bytes(name, "header name")
        value = _to_bytes(value, "header value")
        if not _TOKEN_RE.fullmatch(raw):
            raise LocalProtocolError("illegal header name %r" % raw)
        if not _VALUE_RE.fullmatch(value):
            raise LocalProtocolError("illegal header value %r" % value)
        lname = raw.lower()
        if lname == b"content-length":
            parts = [p.strip(b" \t") for p in value.split(b",")]
            for p in parts:
                if not p or not p.isdigit():
                    raise LocalProtocolError("bad Content-Length")
                if len(p) > MAX_CONTENT_LENGTH_DIGITS:
                    raise LocalProtocolError("Content-Length too long")
            if len(set(int(p) for p in parts)) > 1:
                raise LocalProtocolError("conflicting Content-Length")
            if saw_cl is not None:
                if int(parts[0]) != saw_cl:
                    raise LocalProtocolError("conflicting Content-Length")
                continue
            saw_cl = int(parts[0])
            value = parts[0]
        elif lname == b"transfer-encoding":
            if saw_te:
                raise LocalProtocolError("multiple Transfer-Encoding", 501)
            saw_te = True
            if value.lower() != b"chunked":
                raise LocalProtocolError("unsupported Transfer-Encoding", 501)
            value = b"chunked"
        out.append((raw, lname, value))
    return Headers(out)


def _comma(headers, name):
    res = []
    for _r, n, v in headers._full:
        if n == name:
            for piece in v.split(b","):
                piece = piece.strip(b" \t").lower()
                if piece:
                    res.append(piece)
    return res


# ---------------------------------------------------------------- events
class _Event:
    _fields = ()

    def __eq__(self, other):
        return type(self) is type(other) and all(
            getattr(self, f) == getattr(other, f) for f in self._fields)

    __hash__ = None

    def __repr__(self):
        return "%s(%s)" % (type(self).__name__, ", ".join(
            "%s=%r" % (f, getattr(self, f)) for f in self._fields))


class Request(_Event):
    _fields = ("method", "target", "headers", "http_version")

    def __init__(self, *, method, target, headers, http_version=b"1.1"):
        self.method = _to_bytes(method, "method")
        self.target = _to_bytes(target, "target")
        self.http_version = _to_bytes(http_version, "http_version")
        self.headers = _normalize_headers(headers)
        if not _TOKEN_RE.fullmatch(self.method):
            raise LocalProtocolError("illegal method")
        if not _TARGET_RE.fullmatch(self.target):
            raise LocalProtocolError("illegal target")
        if not _VERSION_RE.fullmatch(self.http_version):
            raise LocalProtocolError("illegal http version")
        hosts = [1 for _r, n, _v in self.headers._full if n == b"host"]
        if self.http_version >= b"1.1" and not hosts:
            raise LocalProtocolError("Missing mandatory Host: header")
        if len(hosts) > 1:
            raise LocalProtocolError("Found multiple Host: headers")


class _ResponseBase(_Event):
    _fields = ("status_code", "headers", "http_version", "reason")
    _lo = 0
    _hi = 0

    def __init__(self, *, status_code, headers, http_version=b"1.1", reason=b""):
        if not isinstance(status_code, int) or isinstance(status_code, bool):
            raise LocalProtocolError("status code must be an integer")
        status_code = int(status_code)
        if not (self._lo <= status_code < self._hi):
            raise LocalProtocolError("illegal status code %d" % status_code)
        self.status_code = status_code
        self.http_version = _to_bytes(http_version, "http_version")
        self.reason = _to_bytes(reason, "reason")
        self.headers = _normalize_headers(headers)
        if not _VERSION_RE.fullmatch(self.http_version):
            raise LocalProtocolError("illegal http version")
        if not _REASON_RE.fullmatch(self.reason):
            raise LocalProtocolError("illegal reason phrase")


class InformationalResponse(_ResponseBase):
    _lo, _hi = 100, 200


class Response(_ResponseBase):
    _lo, _hi = 200, 1000


class Data(_Event):
    _fields = ("data", "chunk_start", "chunk_end")

    def __init__(self, *, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)


class EndOfMessage(_Event):
    _fields = ("headers",)

    def __init__(self, *, headers=None):
        self.headers = _normalize_headers(headers if headers is not None else [])


class ConnectionClosed(_Event):
    _fields = ()

    def __init__(self):
        pass


# ----------------------------------------------------------------- writers
def _write_headers(headers, write):
    for raw, n, v in headers._full:
        if n == b"host":
            write(raw + b": " + v + b"\r\n")
    for raw, n, v in headers._full:
        if n != b"host":
            write(raw + b": " + v + b"\r\n")
    write(b"\r\n")


def _write_any_headers_nohostfirst(headers, write):
    for raw, _n, v in headers._full:
        write(raw + b": " + v + b"\r\n")
    write(b"\r\n")


def _nbytes(data):
    if isinstance(data, memoryview):
        return data.nbytes
    return len(data)


def _write_request(event, write):
    if type(event) is not Request:
        raise LocalProtocolError("expected a Request")
    if event.http_version != b"1.1":
        raise LocalProtocolError("I only send HTTP/1.1")
    write(b"%s %s HTTP/1.1\r\n" % (event.method, event.target))
    _write_headers(event.headers, write)


def _write_any_response(event, write):
    if type(event) not in (Response, InformationalResponse):
        raise LocalProtocolError("expected a response")
    if event.http_version != b"1.1":
        raise LocalProtocolError("I only send HTTP/1.1")
    write(b"HTTP/1.1 %d %s\r\n" % (event.status_code, event.reason))
    _write_any_headers_nohostfirst(event.headers, write)


class _BodyWriter:
    def __call__(self, event, write):
        if type(event) is Data:
            self.send_data(event.data, write)
        elif type(event) is EndOfMessage:
            self.send_eom(event.headers, write)
        else:
            raise LocalProtocolError("unexpected event in body")


class _ContentLengthWriter(_BodyWriter):
    def __init__(self, length):
        self._length = length

    def send_data(self, data, write):
        self._length -= _nbytes(data)
        if self._length < 0:
            raise LocalProtocolError("Too much data for declared Content-Length")
        write(data)

    def send_eom(self, headers, write):
        if self._length != 0:
            raise LocalProtocolError("Too little data for declared Content-Length")
        if len(headers):
            raise LocalProtocolError("Content-Length and trailers don't mix")


class _ChunkedWriter(_BodyWriter):
    def send_data(self, data, write):
        n = _nbytes(data)
        if not n:
            return
        write(b"%x\r\n" % n)
        write(data)
        write(b"\r\n")

    def send_eom(self, headers, write):
        write(b"0\r\n")
        _write_any_headers_nohostfirst(headers, write)


class _Http10Writer(_BodyWriter):
    def send_data(self, data, write):
        write(data)

    def send_eom(self, headers, write):
        if len(headers):
            raise LocalProtocolError("can't send trailers to HTTP/1.0 client")


def _no_writer(event, write):
    raise LocalProtocolError("can't send in this state")


# ----------------------------------------------------------------- readers
def _extract_lines(buf):
    if buf[:2] == b"\r\n":
        del buf[:2]
        return []
    if buf[:1] == b"\n":
        del buf[:1]
        return []
    m = re.search(rb"\n\r?\n", buf)
    if m is None:
        return None
    end = m.end()
    out = bytes(buf[:end])
    del buf[:end]
    lines = out.split(b"\n")
    lines = [l[:-1] if l.endswith(b"\r") else l for l in lines]
    return lines[:-2]


def _extract_line(buf):
    i = buf.find(b"\n")
    if i < 0:
        return None
    line = bytes(buf[:i + 1])
    del buf[:i + 1]
    line = line[:-1]
    if line.endswith(b"\r"):
        line = line[:-1]
    return line


def _decode_headers(lines):
    new = []
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            if not new:
                raise LocalProtocolError("continuation line at start of headers")
            new[-1] = new[-1] + b" " + line.lstrip(b" \t")
        else:
            new.append(line)
    headers = []
    for line in new:
        i = line.find(b":")
        if i < 0:
            raise LocalProtocolError("illegal header line")
        name = line[:i]
        if not _TOKEN_RE.fullmatch(name):
            raise LocalProtocolError("illegal header name")
        headers.append((name, line[i + 1:].strip(b" \t")))
    return headers


class _Reader:
    def read_eof(self):
        raise RemoteProtocolError("peer closed connection without sending complete message")


class _ReadRequest(_Reader):
    def __call__(self, buf):
        if buf and buf[0] < 33:
            raise LocalProtocolError("illegal request line")
        lines = _extract_lines(buf)
        if lines is None:
            return None
        m = _REQUEST_LINE_RE.fullmatch(lines[0]) if lines else None
        if not m:
            raise LocalProtocolError("illegal request line")
        return Request(method=m.group(1), target=m.group(2),
                       headers=_decode_headers(lines[1:]), http_version=m.group(3))

    def read_eof(self):
        return ConnectionClosed()


class _ReadResponse(_Reader):
    def __call__(self, buf):
        if buf and buf[0] < 33:
            raise LocalProtocolError("illegal status line")
        lines = _extract_lines(buf)
        if lines is None:
            return None
        m = _STATUS_LINE_RE.fullmatch(lines[0]) if lines else None
        if not m:
            raise LocalProtocolError("illegal status line")
        status = int(m.group(2))
        cls = InformationalResponse if status < 200 else Response
        return cls(status_code=status, headers=_decode_headers(lines[1:]),
                   http_version=m.group(1), reason=m.group(3) or b"")

    def read_eof(self):
        if self._idle:
            return ConnectionClosed()
        raise RemoteProtocolError("peer closed connection without sending complete message")

    _idle = False


class _ReadResponseIdle(_ReadResponse):
    _idle = True


class _ExpectNothing(_Reader):
    def __call__(self, buf):
        if buf:
            raise LocalProtocolError("Got data when expecting EOF")
        return None

    def read_eof(self):
        return ConnectionClosed()


class _ContentLengthReader(_Reader):
    def __init__(self, length):
        self._remaining = length

    def __call__(self, buf):
        if self._remaining == 0:
            return EndOfMessage()
        if not buf:
            return None
        data = bytes(buf[:self._remaining])
        del buf[:len(data)]
        self._remaining -= len(data)
        return Data(data=data)


class _ChunkedReader(_Reader):
    def __init__(self):
        self._in_chunk = 0
        self._discard = 2
        self._need_crlf = False
        self._trailer = False
        self._started = False

    def __call__(self, buf):
        if self._trailer:
            lines = _extract_lines(buf)
            if lines is None:
                return None
            return EndOfMessage(headers=_decode_headers(lines))
        if self._need_crlf:
            want = b"\r\n"[2 - self._discard:]
            got = bytes(buf[:self._discard])
            if not got:
                return None
            if want[:len(got)] != got:
                raise LocalProtocolError("bad chunk terminator")
            del buf[:len(got)]
            self._discard -= len(got)
            if self._discard > 0:
                return None
            self._need_crlf = False
        if self._in_chunk == 0:
            line = _extract_line(buf)
            if line is None:
                return None
            m = _CHUNK_RE.fullmatch(line)
            if not m or len(m.group(1)) > MAX_CHUNK_SIZE_DIGITS:
                raise LocalProtocolError("illegal chunk header")
            self._in_chunk = int(m.group(1), 16)
            if self._in_chunk == 0:
                self._trailer = True
                return self(buf)
            self._started = False
        if not buf:
            return None
        data = bytes(buf[:self._in_chunk])
        del buf[:len(data)]
        self._in_chunk -= len(data)
        start = not self._started
        self._started = True
        end = self._in_chunk == 0
        if end:
            self._need_crlf = True
            self._discard = 2
        return Data(data=data, chunk_start=start, chunk_end=end)


class _Http10Reader(_Reader):
    def __call__(self, buf):
        if not buf:
            return None
        data = bytes(buf)
        del buf[:]
        return Data(data=data)

    def read_eof(self):
        return EndOfMessage()


def _body_framing(request_method, event):
    if type(event) is Response:
        if (event.status_code in (204, 304) or request_method == b"HEAD"
                or (request_method == b"CONNECT" and 200 <= event.status_code < 300)):
            return ("content-length", 0)
    te = _comma(event.headers, b"transfer-encoding")
    cl = _comma(event.headers, b"content-length")
    if type(event) is Request:
        if cl:
            return ("content-length", int(cl[0]))
        if te:
            return ("chunked", None)
        return ("content-length", 0)
    if te:
        return ("chunked", None)
    if cl:
        return ("content-length", int(cl[0]))
    return ("http/1.0", None)


def _make_body(kind, arg, writer):
    if kind == "content-length":
        return _ContentLengthWriter(arg) if writer else _ContentLengthReader(arg)
    if kind == "chunked":
        return _ChunkedWriter() if writer else _ChunkedReader()
    return _Http10Writer() if writer else _Http10Reader()


# ----------------------------------------------------------- state machine
_EVENT_TRANSITIONS = {
    CLIENT: {
        IDLE: {Request: SEND_BODY, ConnectionClosed: CLOSED},
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
        CLOSED: {ConnectionClosed: CLOSED},
        MIGHT_SWITCH_PROTOCOL: {},
        SWITCHED_PROTOCOL: {},
        ERROR: {},
    },
    SERVER: {
        IDLE: {ConnectionClosed: CLOSED, (Request, CLIENT): SEND_RESPONSE,
               Response: SEND_BODY},
        SEND_RESPONSE: {
            InformationalResponse: SEND_RESPONSE,
            Response: SEND_BODY,
            (InformationalResponse, _SWITCH_UPGRADE): SWITCHED_PROTOCOL,
            (Response, _SWITCH_CONNECT): SWITCHED_PROTOCOL,
        },
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
        CLOSED: {ConnectionClosed: CLOSED},
        SWITCHED_PROTOCOL: {},
        ERROR: {},
    },
}

_STATE_TRANSITIONS = {
    (MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL): {CLIENT: SWITCHED_PROTOCOL},
    (CLOSED, DONE): {SERVER: MUST_CLOSE},
    (CLOSED, IDLE): {SERVER: MUST_CLOSE},
    (ERROR, DONE): {SERVER: MUST_CLOSE},
    (DONE, CLOSED): {CLIENT: MUST_CLOSE},
    (IDLE, CLOSED): {CLIENT: MUST_CLOSE},
    (DONE, ERROR): {CLIENT: MUST_CLOSE},
}


class _ConnectionState:
    def __init__(self):
        self.states = {CLIENT: IDLE, SERVER: IDLE}
        self.keep_alive = True
        self.pending = set()

    def process_event(self, role, typ, switch=None):
        if switch is not None:
            if switch not in self.pending:
                raise LocalProtocolError(
                    "Received server switch event without a pending proposal")
            typ = (typ, switch)
        if switch is None and typ is Response:
            self.pending.clear()
        self._fire_event(role, typ)
        if typ is Request:
            self._fire_event(SERVER, (Request, CLIENT))
        self._fire_state()

    def _fire_event(self, role, typ):
        try:
            new = _EVENT_TRANSITIONS[role][self.states[role]][typ]
        except KeyError:
            name = typ[0] if isinstance(typ, tuple) else typ
            raise LocalProtocolError(
                "can't handle event type %s when role=%r and state=%r"
                % (getattr(name, "__name__", name), role, self.states[role]))
        self.states[role] = new

    def _fire_state(self):
        while True:
            start = dict(self.states)
            if self.pending and self.states[CLIENT] is DONE:
                self.states[CLIENT] = MIGHT_SWITCH_PROTOCOL
            if not self.pending and self.states[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                self.states[CLIENT] = DONE
            if not self.keep_alive:
                for r in (CLIENT, SERVER):
                    if self.states[r] is DONE:
                        self.states[r] = MUST_CLOSE
            self.states.update(
                _STATE_TRANSITIONS.get((self.states[CLIENT], self.states[SERVER]), {}))
            if self.states == start:
                return

    def process_error(self, role):
        self.states[role] = ERROR
        self._fire_state()

    def disable_keep_alive(self):
        self.keep_alive = False
        self._fire_state()

    def start_next_cycle(self):
        if self.states != {CLIENT: DONE, SERVER: DONE}:
            raise LocalProtocolError(
                "not in a reusable state: %r" % (self.states,))
        self.states = {CLIENT: IDLE, SERVER: IDLE}


def _keep_alive(event):
    if b"close" in _comma(event.headers, b"connection"):
        return False
    if event.http_version < b"1.1":
        return False
    return True


class Connection:
    def __init__(self, role, max_incomplete_event_size=DEFAULT_MAX_INCOMPLETE_EVENT_SIZE):
        if role is not CLIENT and role is not SERVER:
            raise ValueError("role must be CLIENT or SERVER")
        self.our_role = role
        self.their_role = SERVER if role is CLIENT else CLIENT
        self._max = max_incomplete_event_size
        self._cstate = _ConnectionState()
        self._buf = bytearray()
        self._closed = False
        self._request_method = None
        self.their_http_version = None
        self.client_is_waiting_for_100_continue = False
        self._writer = self._io(self.our_role, None, True)
        self._reader = self._io(self.their_role, None, False)

    # ---- properties
    @property
    def states(self):
        return dict(self._cstate.states)

    @property
    def our_state(self):
        return self._cstate.states[self.our_role]

    @property
    def their_state(self):
        return self._cstate.states[self.their_role]

    @property
    def they_are_waiting_for_100_continue(self):
        return self.their_role is CLIENT and self.client_is_waiting_for_100_continue

    @property
    def trailing_data(self):
        return (bytes(self._buf), self._closed)

    # ---- io object selection
    def _io(self, role, event, writer):
        state = self._cstate.states[role]
        if state is SEND_BODY:
            kind, arg = _body_framing(self._request_method, event)
            return _make_body(kind, arg, writer)
        if writer:
            if role is CLIENT and state is IDLE:
                return _write_request
            if role is SERVER and state in (IDLE, SEND_RESPONSE):
                return _write_any_response
            return _no_writer
        if role is CLIENT:
            if state is IDLE:
                return _ReadRequest()
            if state in (DONE, MUST_CLOSE, CLOSED):
                return _ExpectNothing()
            return None
        if state is IDLE:
            return _ReadResponseIdle()
        if state is SEND_RESPONSE:
            return _ReadResponse()
        if state in (DONE, MUST_CLOSE, CLOSED):
            return _ExpectNothing()
        return None

    def _respond(self, old, event):
        if self.our_state is not old[self.our_role]:
            self._writer = self._io(self.our_role, event, True)
        if self.their_state is not old[self.their_role]:
            self._reader = self._io(self.their_role, event, False)

    def _process_event(self, role, event):
        old = dict(self._cstate.states)
        typ = type(event)
        cs = self._cstate
        if role is CLIENT and typ is Request:
            if event.method == b"CONNECT":
                cs.pending.add(_SWITCH_CONNECT)
            if _comma(event.headers, b"upgrade"):
                cs.pending.add(_SWITCH_UPGRADE)
        switch = None
        if role is SERVER:
            if typ is InformationalResponse and event.status_code == 101:
                switch = _SWITCH_UPGRADE
            if (typ is Response and _SWITCH_CONNECT in cs.pending
                    and 200 <= event.status_code < 300):
                switch = _SWITCH_CONNECT
        if typ in (Request, Response) and not _keep_alive(event):
            cs.disable_keep_alive()
        if typ is Request and role is CLIENT:
            if (event.http_version >= b"1.1"
                    and b"100-continue" in _comma(event.headers, b"expect")):
                self.client_is_waiting_for_100_continue = True
        if role is CLIENT and typ in (Data, EndOfMessage):
            self.client_is_waiting_for_100_continue = False
        if role is SERVER and typ in (InformationalResponse, Response):
            self.client_is_waiting_for_100_continue = False
        cs.process_event(role, typ, switch)
        if typ is Request:
            self._request_method = event.method
        if role is self.their_role and typ in (Request, Response, InformationalResponse):
            self.their_http_version = event.http_version
        self._respond(old, event)

    def _process_error(self, role):
        old = dict(self._cstate.states)
        self._cstate.process_error(role)
        self._respond(old, None)

    # ---- sending
    def _clean_response(self, response):
        method = self._request_method
        if method == b"HEAD":
            method = b"GET"
        kind, _ = _body_framing(method, response)
        full = list(response.headers._full)
        if kind in ("chunked", "http/1.0"):
            full = [h for h in full if h[1] not in (b"content-length", b"transfer-encoding")]
            if self.their_http_version is None or self.their_http_version < b"1.1":
                self._cstate.disable_keep_alive()
            else:
                full.append((b"transfer-encoding", b"transfer-encoding", b"chunked"))
        if (not self._cstate.keep_alive) or self.their_state is ERROR:
            vals = set(_comma(response.headers, b"connection"))
            vals.discard(b"keep-alive")
            vals.add(b"close")
            full = [h for h in full if h[1] != b"connection"]
            full.append((b"connection", b"connection", b", ".join(sorted(vals))))
        return Response(status_code=response.status_code,
                        headers=[(r, v) for r, _n, v in full],
                        http_version=response.http_version, reason=response.reason)

    def send_with_data_passthrough(self, event):
        if self.our_state is ERROR:
            raise LocalProtocolError("Can't send data when our state is ERROR")
        try:
            if type(event) is Response:
                event = self._clean_response(event)
            writer = self._writer
            self._process_event(self.our_role, event)
            if type(event) is ConnectionClosed:
                return []
            pieces = []
            writer(event, pieces.append)
            return pieces
        except BaseException:
            self._process_error(self.our_role)
            raise

    def send(self, event):
        pieces = self.send_with_data_passthrough(event)
        if not pieces:
            return None
        return b"".join(bytes(memoryview(p)) if not isinstance(p, bytes) else p
                        for p in pieces)

    def send_failed(self):
        self._process_error(self.our_role)

    # ---- receiving
    def receive_data(self, data):
        if len(data):
            if self._closed:
                raise RuntimeError("received close, then received more data?")
            self._buf += data
        else:
            self._closed = True

    def _extract(self):
        state = self.their_state
        if state is DONE and self._buf:
            return PAUSED
        if state in (MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL):
            return PAUSED
        reader = self._reader
        if reader is None:
            raise LocalProtocolError("no reader for state %r" % (state,))
        event = reader(self._buf)
        if event is None:
            if not self._buf and self._closed:
                event = reader.read_eof()
            else:
                event = NEED_DATA
        return event

    def next_event(self):
        if self.their_state is ERROR:
            raise RemoteProtocolError("Can't receive data when peer state is ERROR")
        try:
            event = self._extract()
            if event is not NEED_DATA and event is not PAUSED:
                self._process_event(self.their_role, event)
            if event is NEED_DATA:
                if len(self._buf) > self._max:
                    raise RemoteProtocolError("Receive buffer too long", 431)
                if self._closed:
                    raise RemoteProtocolError("peer unexpectedly closed connection")
            return event
        except BaseException as exc:
            self._process_error(self.their_role)
            if isinstance(exc, LocalProtocolError):
                raise RemoteProtocolError(str(exc), exc.error_status_hint) from None
            raise

    def start_next_cycle(self):
        old = dict(self._cstate.states)
        self._cstate.start_next_cycle()
        self._request_method = None
        self.client_is_waiting_for_100_continue = False
        self._respond(old, None)
