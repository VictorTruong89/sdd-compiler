from ._util import (LocalProtocolError, bytesify, normalize_headers, Headers,
                    token_re, target_re, version_re)


class _Event:
    _fields = ()

    def __repr__(self):
        return "%s(%s)" % (type(self).__name__, ", ".join(
            "%s=%r" % (f, getattr(self, f)) for f in self._fields))

    def __eq__(self, other):
        return type(self) is type(other) and all(
            getattr(self, f) == getattr(other, f) for f in self._fields)

    __hash__ = None


def _version(v):
    v = bytesify(v)
    if not version_re.fullmatch(v):
        raise LocalProtocolError("illegal HTTP version %r" % v)
    return v


class Request(_Event):
    _fields = ("method", "target", "headers", "http_version")

    def __init__(self, *, method, target, headers, http_version=b"1.1"):
        method = bytesify(method)
        target = bytesify(target)
        if not token_re.fullmatch(method):
            raise LocalProtocolError("illegal method")
        if not target_re.fullmatch(target):
            raise LocalProtocolError("illegal request target")
        http_version = _version(http_version)
        headers = normalize_headers(headers)
        hosts = sum(1 for _, n, _v in headers._items if n == b"host")
        if hosts > 1:
            raise LocalProtocolError("multiple Host headers")
        if http_version == b"1.1" and hosts == 0:
            raise LocalProtocolError("missing Host header")
        self.method = method
        self.target = target
        self.headers = headers
        self.http_version = http_version


class _ResponseBase(_Event):
    _fields = ("status_code", "headers", "http_version", "reason")
    _lo = 0
    _hi = 0

    def __init__(self, *, status_code, headers, http_version=b"1.1", reason=b""):
        if isinstance(status_code, bool) or not isinstance(status_code, int):
            raise LocalProtocolError("status code must be an integer")
        status_code = int(status_code)
        if not (self._lo <= status_code < self._hi):
            raise LocalProtocolError("status code %d out of range" % status_code)
        self.status_code = status_code
        self.headers = normalize_headers(headers)
        self.http_version = _version(http_version)
        self.reason = bytesify(reason)


class InformationalResponse(_ResponseBase):
    _lo, _hi = 100, 200


class Response(_ResponseBase):
    _lo, _hi = 200, 1000


class Data(_Event):
    _fields = ("data", "chunk_start", "chunk_end")

    def __init__(self, *, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)


class EndOfMessage(_Event):
    _fields = ("headers",)

    def __init__(self, *, headers=None):
        self.headers = normalize_headers(headers if headers is not None else [])


class ConnectionClosed(_Event):
    pass
