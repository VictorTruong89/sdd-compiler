import re


class _ProtocolError(Exception):
    def __init__(self, msg, error_status_hint=400):
        Exception.__init__(self, msg)
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(_ProtocolError):
    def _reraise_as_remote(self):
        raise RemoteProtocolError(str(self), self.error_status_hint) from self


class RemoteProtocolError(_ProtocolError):
    pass


class _Sentinel:
    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return self._name


MAX_CONTENT_LENGTH_DIGITS = 18
MAX_CHUNK_SIZE_DIGITS = 32

TOKEN = rb"[-!#$%&'*+.^_`|~0-9A-Za-z]+"
token_re = re.compile(TOKEN)
target_re = re.compile(rb"[\x21-\x7e]+")
version_re = re.compile(rb"[0-9]\.[0-9]")
value_re = re.compile(
    rb"(?:[^\x00\n\r\x0b\x0c \t](?:[^\x00\n\r\x0b\x0c]*[^\x00\n\r\x0b\x0c \t])?)?",
    re.DOTALL)
digits_re = re.compile(rb"[0-9]+")


def bytesify(s):
    if type(s) is bytes:
        return s
    if isinstance(s, (bytes, bytearray, memoryview)):
        return bytes(s)
    if isinstance(s, str):
        try:
            return s.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("expected ASCII text")
    raise LocalProtocolError("expected bytes or ASCII text, got %r" % type(s))


class Headers:
    """Sequence of (lowercase name, value) pairs that remembers raw names."""

    def __init__(self, items):
        self._items = items  # (raw_name, name, value)

    def __len__(self):
        return len(self._items)

    def __iter__(self):
        return ((n, v) for _, n, v in self._items)

    def __getitem__(self, i):
        if isinstance(i, slice):
            return [(n, v) for _, n, v in self._items[i]]
        _, n, v = self._items[i]
        return (n, v)

    def __eq__(self, other):
        try:
            return list(self) == [tuple(x) for x in other]
        except TypeError:
            return NotImplemented

    __hash__ = None

    def __repr__(self):
        return repr(list(self))

    def raw_items(self):
        return [(r, v) for r, _, v in self._items]


def normalize_headers(headers):
    if isinstance(headers, Headers):
        return headers
    items = []
    seen_cl = None
    saw_te = False
    try:
        pairs = list(headers)
    except TypeError:
        raise LocalProtocolError("headers must be a sequence of pairs")
    for pair in pairs:
        try:
            name, value = pair
        except (TypeError, ValueError):
            raise LocalProtocolError("header must be a (name, value) pair")
        raw = bytesify(name)
        value = bytesify(value)
        if not token_re.fullmatch(raw):
            raise LocalProtocolError("illegal header name %r" % raw)
        if not value_re.fullmatch(value):
            raise LocalProtocolError("illegal header value %r" % value)
        lname = raw.lower()
        if lname == b"content-length":
            lengths = {p.strip(b" \t") for p in value.split(b",")}
            if len(lengths) != 1:
                raise LocalProtocolError("conflicting Content-Length headers")
            value = lengths.pop()
            if not digits_re.fullmatch(value):
                raise LocalProtocolError("bad Content-Length")
            if len(value) > MAX_CONTENT_LENGTH_DIGITS:
                raise LocalProtocolError("Content-Length too long")
            if seen_cl is None:
                seen_cl = value
                items.append((raw, lname, value))
            elif seen_cl != value:
                raise LocalProtocolError("conflicting Content-Length headers")
        elif lname == b"transfer-encoding":
            if saw_te:
                raise LocalProtocolError("multiple Transfer-Encoding headers", 501)
            saw_te = True
            value = value.lower()
            if value != b"chunked":
                raise LocalProtocolError(
                    "only Transfer-Encoding: chunked is supported", 501)
            items.append((raw, lname, value))
        else:
            items.append((raw, lname, value))
    return Headers(items)


def get_comma_header(headers, name):
    out = []
    for _, n, v in headers._items:
        if n == name:
            for piece in v.split(b","):
                piece = piece.strip(b" \t").lower()
                if piece:
                    out.append(piece)
    return out


def set_comma_header(headers, name, new_values):
    items = [t for t in headers._items if t[1] != name]
    for v in new_values:
        items.append((name, name, v))
    return Headers(items)
