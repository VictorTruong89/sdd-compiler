import re

from ._util import (LocalProtocolError, RemoteProtocolError, _Sentinel, Headers,
                    normalize_headers, get_comma_header, set_comma_header,
                    token_re, target_re, MAX_CHUNK_SIZE_DIGITS)
from ._events import (Request, InformationalResponse, Response, Data,
                      EndOfMessage, ConnectionClosed)

CLIENT = _Sentinel("CLIENT")
SERVER = _Sentinel("SERVER")
NEED_DATA = _Sentinel("NEED_DATA")
PAUSED = _Sentinel("PAUSED")
(IDLE, SEND_RESPONSE, SEND_BODY, DONE, MUST_CLOSE, CLOSED,
 MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL, ERROR) = [
    _Sentinel(n) for n in (
        "IDLE", "SEND_RESPONSE", "SEND_BODY", "DONE", "MUST_CLOSE", "CLOSED",
        "MIGHT_SWITCH_PROTOCOL", "SWITCHED_PROTOCOL", "ERROR")]

_SWITCH_UPGRADE = _Sentinel("_SWITCH_UPGRADE")
_SWITCH_CONNECT = _Sentinel("_SWITCH_CONNECT")

_CC = {ConnectionClosed: CLOSED}
EVENT_TRANSITIONS = {
    CLIENT: {
        IDLE: {Request: SEND_BODY, ConnectionClosed: CLOSED},
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: dict(_CC), MUST_CLOSE: dict(_CC), CLOSED: dict(_CC),
    },
    SERVER: {
        IDLE: {ConnectionClosed: CLOSED, Response: SEND_BODY,
               "request": SEND_RESPONSE,
               (Response, _SWITCH_CONNECT): SWITCHED_PROTOCOL},
        SEND_RESPONSE: {InformationalResponse: SEND_RESPONSE,
                        Response: SEND_BODY,
                        (InformationalResponse, _SWITCH_UPGRADE): SWITCHED_PROTOCOL,
                        (Response, _SWITCH_CONNECT): SWITCHED_PROTOCOL},
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: dict(_CC), MUST_CLOSE: dict(_CC), CLOSED: dict(_CC),
    },
}
STATE_TRANSITIONS = {
    (MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL): {CLIENT: SWITCHED_PROTOCOL},
    (CLOSED, DONE): {SERVER: MUST_CLOSE},
    (CLOSED, IDLE): {SERVER: MUST_CLOSE},
    (ERROR, DONE): {SERVER: MUST_CLOSE},
    (DONE, CLOSED): {CLIENT: MUST_CLOSE},
    (IDLE, CLOSED): {CLIENT: MUST_CLOSE},
    (DONE, ERROR): {CLIENT: MUST_CLOSE},
}


class _ConnectionState:
    def __init__(self):
        self.states = {CLIENT: IDLE, SERVER: IDLE}
        self.keep_alive = True
        self.pending = set()

    def process_error(self, role):
        self.states[role] = ERROR
        self._fire()

    def process_event(self, role, event_type, switch_event=None):
        if switch_event is not None:
            if switch_event not in self.pending:
                raise LocalProtocolError(
                    "server switch event without a pending proposal")
            event_type = (event_type, switch_event)
        if switch_event is None and event_type is Response:
            self.pending = set()
        state = self.states[role]
        try:
            new = EVENT_TRANSITIONS[role][state][event_type]
        except KeyError:
            name = getattr(event_type, "__name__", event_type)
            raise LocalProtocolError(
                "can't handle event type %s when role=%r and state=%r"
                % (name, role, state))
        self.states[role] = new
        if event_type is Request and self.states[SERVER] is IDLE:
            self.states[SERVER] = SEND_RESPONSE
        self._fire()

    def _fire(self):
        while True:
            start = dict(self.states)
            if self.pending and self.states[CLIENT] is DONE:
                self.states[CLIENT] = MIGHT_SWITCH_PROTOCOL
            if not self.pending and self.states[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                self.states[CLIENT] = DONE
            if not self.keep_alive:
                for r in (CLIENT, SERVER):
                    if self.states[r] is DONE:
                        self.states[r] = MUST_CLOSE
            self.states.update(STATE_TRANSITIONS.get(
                (self.states[CLIENT], self.states[SERVER]), {}))
            if self.states == start:
                return

    def start_next_cycle(self):
        if self.states != {CLIENT: DONE, SERVER: DONE}:
            raise LocalProtocolError(
                "not in a reusable state: %r" % (self.states,))
        self.states = {CLIENT: IDLE, SERVER: IDLE}


# ---------------------------------------------------------------- buffer
class _Buffer:
    def __init__(self):
        self.data = bytearray()

    def __len__(self):
        return len(self.data)

    def extract_at_most(self, n):
        out = bytes(self.data[:n])
        if not out:
            return None
        del self.data[:n]
        return out

    def extract_lines(self):
        d = self.data
        if d[:2] == b"\r\n":
            del d[:2]
            return []
        if d[:1] == b"\n":
            del d[:1]
            return []
        m = re.search(rb"\n\r?\n", d)
        if m is None:
            return None
        block = bytes(d[:m.start()])
        del d[:m.end()]
        lines = block.split(b"\n")
        return [l[:-1] if l.endswith(b"\r") else l for l in lines]

    def extract_line(self):
        i = self.data.find(b"\r\n")
        if i < 0:
            return None
        line = bytes(self.data[:i])
        del self.data[:i + 2]
        return line

    def invalid_start(self):
        return len(self.data) > 0 and self.data[0] < 0x21


def _decode_headers(lines):
    out = []
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            if not out:
                raise LocalProtocolError("continuation line at start of headers")
            n, v = out[-1]
            out[-1] = (n, v + b" " + line.lstrip(b" \t"))
        else:
            n, colon, v = line.partition(b":")
            if not colon:
                raise LocalProtocolError("malformed header line")
            out.append((n, v))
    return [(n, v.strip(b" \t")) for n, v in out]


request_line_re = re.compile(
    rb"(" + rb"[-!#$%&'*+.^_`|~0-9A-Za-z]+" + rb") ([\x21-\x7e]+) HTTP/([0-9]\.[0-9])")
status_line_re = re.compile(
    rb"HTTP/([0-9]\.[0-9]) ([0-9]{3})(?: ([ \t\x21-\x7e\x80-\xff]*))?")
chunk_header_re = re.compile(
    rb"([0-9A-Fa-f]+)(;[^\r\n]*)?[ \t]*")


def _read_request(buf):
    lines = buf.extract_lines()
    if lines is None:
        if buf.invalid_start():
            raise RemoteProtocolError("illegal request line")
        return None
    if not lines:
        raise RemoteProtocolError("no request line received")
    m = request_line_re.fullmatch(lines[0])
    if not m:
        raise RemoteProtocolError("illegal request line")
    headers = _decode_headers(lines[1:])
    return Request(method=m.group(1), target=m.group(2), headers=headers,
                   http_version=m.group(3))


def _read_response(buf):
    lines = buf.extract_lines()
    if lines is None:
        if buf.invalid_start():
            raise RemoteProtocolError("illegal status line")
        return None
    if not lines:
        raise RemoteProtocolError("no response line received")
    m = status_line_re.fullmatch(lines[0])
    if not m:
        raise RemoteProtocolError("illegal status line")
    headers = _decode_headers(lines[1:])
    code = int(m.group(2))
    cls = InformationalResponse if code < 200 else Response
    return cls(status_code=code, headers=headers, http_version=m.group(1),
               reason=m.group(3) or b"")


def _expect_nothing(buf):
    return None


class _CLReader:
    def __init__(self, length):
        self.remaining = length

    def __call__(self, buf):
        if self.remaining == 0:
            return EndOfMessage()
        data = buf.extract_at_most(self.remaining)
        if data is None:
            return None
        self.remaining -= len(data)
        return Data(data=data)

    def read_eof(self):
        raise RemoteProtocolError(
            "peer closed connection without sending complete message body")


class _Http10Reader:
    def __call__(self, buf):
        data = buf.extract_at_most(1 << 30)
        if data is None:
            return None
        return Data(data=data)

    def read_eof(self):
        return EndOfMessage()


class _ChunkedReader:
    def __init__(self):
        self.in_chunk = 0
        self.discard = 0  # CRLF bytes still to consume
        self.trailer = False

    def __call__(self, buf):
        if self.trailer:
            lines = buf.extract_lines()
            if lines is None:
                return None
            return EndOfMessage(headers=_decode_headers(lines))
        while self.discard > 0:
            expected = b"\r\n"[2 - self.discard:]
            avail = bytes(buf.data[:self.discard])
            if not avail:
                return None
            if avail != expected[:len(avail)]:
                raise RemoteProtocolError("garbage after chunk data")
            del buf.data[:len(avail)]
            self.discard -= len(avail)
        start = False
        if self.in_chunk == 0:
            line = buf.extract_line()
            if line is None:
                return None
            m = chunk_header_re.fullmatch(line)
            if not m or len(m.group(1)) > MAX_CHUNK_SIZE_DIGITS:
                raise RemoteProtocolError("illegal chunk header")
            size = int(m.group(1), 16)
            if size == 0:
                self.trailer = True
                return self(buf)
            self.in_chunk = size
            start = True
        data = buf.extract_at_most(self.in_chunk)
        if data is None:
            # chunk header consumed but no data yet; remember start mark
            self._pending_start = True
            return None
        if getattr(self, "_pending_start", False):
            start = True
            self._pending_start = False
        self.in_chunk -= len(data)
        end = self.in_chunk == 0
        if end:
            self.discard = 2
        return Data(data=data, chunk_start=start, chunk_end=end)

    def read_eof(self):
        raise RemoteProtocolError(
            "peer closed connection without sending complete message body "
            "(incomplete chunked read)")


def _body_framing(method, event):
    if type(event) is Response:
        if (method == b"HEAD" or event.status_code in (204, 304)
                or (method == b"CONNECT" and 200 <= event.status_code < 300)):
            return ("content-length", (0,))
    if get_comma_header(event.headers, b"transfer-encoding") == [b"chunked"]:
        return ("chunked", ())
    cl = get_comma_header(event.headers, b"content-length")
    if cl:
        return ("content-length", (int(cl[0]),))
    if type(event) is Request:
        return ("content-length", (0,))
    return ("http/1.0", ())


# ---------------------------------------------------------------- writers
def _write_headers(headers, write):
    items = headers._items
    parts = []
    for raw, n, v in items:
        if n == b"host":
            parts.append(raw + b": " + v + b"\r\n")
    for raw, n, v in items:
        if n != b"host":
            parts.append(raw + b": " + v + b"\r\n")
    parts.append(b"\r\n")
    write(b"".join(parts))


def _write_request(event, write):
    if event.http_version != b"1.1":
        raise LocalProtocolError("I only send HTTP/1.1")
    write(event.method + b" " + event.target + b" HTTP/1.1\r\n")
    _write_headers(event.headers, write)


def _write_response(event, write):
    if event.http_version != b"1.1":
        raise LocalProtocolError("I only send HTTP/1.1")
    write(b"HTTP/1.1 %d %s\r\n" % (event.status_code, event.reason))
    _write_headers(event.headers, write)


class _BodyWriter:
    def __call__(self, event, write):
        if type(event) is Data:
            self.send_data(event.data, write)
        elif type(event) is EndOfMessage:
            self.send_eom(event.headers, write)
        else:
            raise LocalProtocolError("unexpected event in body")


class _CLWriter(_BodyWriter):
    def __init__(self, length):
        self.length = length

    def send_data(self, data, write):
        self.length -= len(data)
        if self.length < 0:
            raise LocalProtocolError("Too much data for declared Content-Length")
        write(data)

    def send_eom(self, headers, write):
        if self.length != 0:
            raise LocalProtocolError("Too little data for declared Content-Length")
        if len(headers):
            raise LocalProtocolError("Content-Length and trailers don't mix")


class _ChunkedWriter(_BodyWriter):
    def send_data(self, data, write):
        if not len(data):
            return
        write(b"%x\r\n" % len(data))
        write(data)
        write(b"\r\n")

    def send_eom(self, headers, write):
        write(b"0\r\n")
        _write_headers(headers, write)


class _Http10Writer(_BodyWriter):
    def send_data(self, data, write):
        write(data)

    def send_eom(self, headers, write):
        if len(headers):
            raise LocalProtocolError("can't send trailers to HTTP/1.0 client")


READERS = {
    (CLIENT, IDLE): _read_request,
    (SERVER, IDLE): _read_response,
    (SERVER, SEND_RESPONSE): _read_response,
    (CLIENT, DONE): _expect_nothing, (CLIENT, MUST_CLOSE): _expect_nothing,
    (CLIENT, CLOSED): _expect_nothing,
    (SERVER, DONE): _expect_nothing, (SERVER, MUST_CLOSE): _expect_nothing,
    (SERVER, CLOSED): _expect_nothing,
}
WRITERS = {
    (CLIENT, IDLE): _write_request,
    (SERVER, IDLE): _write_response,
    (SERVER, SEND_RESPONSE): _write_response,
}
_BODY_READERS = {"content-length": _CLReader, "chunked": _ChunkedReader,
                 "http/1.0": _Http10Reader}
_BODY_WRITERS = {"content-length": _CLWriter, "chunked": _ChunkedWriter,
                 "http/1.0": _Http10Writer}


def _keep_alive(event):
    if b"close" in get_comma_header(event.headers, b"connection"):
        return False
    if event.http_version < b"1.1":
        return False
    return True


class Connection:
    def __init__(self, role, max_incomplete_event_size=16 * 1024):
        if role is not CLIENT and role is not SERVER:
            raise ValueError("expected CLIENT or SERVER, got %r" % (role,))
        self.our_role = role
        self.their_role = SERVER if role is CLIENT else CLIENT
        self._cstate = _ConnectionState()
        self._max = max_incomplete_event_size
        self._buf = _Buffer()
        self._closed = False
        self.their_http_version = None
        self._request_method = None
        self.client_is_waiting_for_100_continue = False
        self._writer = WRITERS.get((role, IDLE))
        self._reader = READERS.get((self.their_role, IDLE))

    # ---- queries
    @property
    def states(self):
        return dict(self._cstate.states)

    @property
    def our_state(self):
        return self._cstate.states[self.our_role]

    @property
    def their_state(self):
        return self._cstate.states[self.their_role]

    @property
    def they_are_waiting_for_100_continue(self):
        return self.their_role is CLIENT and self.client_is_waiting_for_100_continue

    @property
    def trailing_data(self):
        return (bytes(self._buf.data), self._closed)

    # ---- internals
    def _io(self, role, event, table, body_table):
        state = self._cstate.states[role]
        if state is SEND_BODY:
            ft, args = _body_framing(self._request_method, event)
            return body_table[ft](*args)
        return table.get((role, state))

    def _respond(self, old, event):
        if self._cstate.states[self.our_role] != old[self.our_role]:
            self._writer = self._io(self.our_role, event, WRITERS, _BODY_WRITERS)
        if self._cstate.states[self.their_role] != old[self.their_role]:
            self._reader = self._io(self.their_role, event, READERS, _BODY_READERS)

    def _server_switch_event(self, event):
        if type(event) is InformationalResponse and event.status_code == 101:
            return _SWITCH_UPGRADE
        if (type(event) is Response and _SWITCH_CONNECT in self._cstate.pending
                and 200 <= event.status_code < 300):
            return _SWITCH_CONNECT
        return None

    def _process_event(self, role, event):
        old = dict(self._cstate.states)
        if role is CLIENT and type(event) is Request:
            if event.method == b"CONNECT":
                self._cstate.pending.add(_SWITCH_CONNECT)
            if get_comma_header(event.headers, b"upgrade"):
                self._cstate.pending.add(_SWITCH_UPGRADE)
        sw = self._server_switch_event(event) if role is SERVER else None
        self._cstate.process_event(role, type(event), sw)
        if type(event) is Request:
            self._request_method = event.method
        if role is self.their_role and type(event) in (
                Request, Response, InformationalResponse):
            self.their_http_version = event.http_version
        if type(event) in (Request, Response):
            off = not _keep_alive(event)
            if type(event) is Response and sw is None:
                if _body_framing(self._request_method, event)[0] == "http/1.0":
                    off = True
            if off:
                self._cstate.keep_alive = False
                self._cstate._fire()
        if type(event) is Request:
            if (event.http_version == b"1.1" and
                    b"100-continue" in get_comma_header(event.headers, b"expect")):
                self.client_is_waiting_for_100_continue = True
        if type(event) in (InformationalResponse, Response):
            self.client_is_waiting_for_100_continue = False
        if role is CLIENT and type(event) in (Data, EndOfMessage):
            self.client_is_waiting_for_100_continue = False
        self._respond(old, event)

    def _process_error(self, role):
        self._cstate.process_error(role)

    def _clean_response(self, response):
        method = self._request_method
        if method not in (b"HEAD", b"GET"):
            method = b"GET"
        headers = response.headers
        ft, _ = _body_framing(method, response)
        need_close = False
        if ft in ("chunked", "http/1.0"):
            items = [t for t in headers._items
                     if t[1] not in (b"content-length", b"transfer-encoding")]
            headers = Headers(items)
            if (self.their_http_version is None
                    or self.their_http_version < b"1.1"):
                need_close = True
            else:
                headers = set_comma_header(headers, b"transfer-encoding", [b"chunked"])
        if (not self._cstate.keep_alive or need_close
                or self.their_state is ERROR):
            conn = set(get_comma_header(headers, b"connection"))
            conn.discard(b"keep-alive")
            conn.add(b"close")
            headers = set_comma_header(headers, b"connection", sorted(conn))
        return Response(status_code=response.status_code, headers=headers,
                        http_version=response.http_version, reason=response.reason)

    # ---- public API
    def send(self, event):
        parts = self.send_with_data_passthrough(event)
        if parts is None:
            return None
        return b"".join(p if isinstance(p, (bytes, bytearray, memoryview))
                        else bytes(p) for p in parts)

    def send_with_data_passthrough(self, event):
        if self.our_state is ERROR:
            raise LocalProtocolError("Can't send data when our state is ERROR")
        try:
            if type(event) not in (Request, InformationalResponse, Response,
                                   Data, EndOfMessage, ConnectionClosed):
                raise LocalProtocolError("not an event: %r" % (event,))
            if type(event) is Response:
                event = self._clean_response(event)
            writer = self._writer
            self._process_event(self.our_role, event)
            if type(event) is ConnectionClosed:
                return None
            out = []
            writer(event, out.append)
            return out
        except BaseException:
            self._process_error(self.our_role)
            raise

    def receive_data(self, data):
        if data:
            if self._closed:
                raise RuntimeError("received close, then received more data?")
            self._buf.data += data
        else:
            self._closed = True

    def _extract(self):
        state = self.their_state
        if state is DONE and len(self._buf):
            return PAUSED
        if state is MIGHT_SWITCH_PROTOCOL or state is SWITCHED_PROTOCOL:
            return PAUSED
        reader = self._reader
        event = reader(self._buf) if reader is not None else None
        if event is None:
            if not len(self._buf) and self._closed:
                if hasattr(reader, "read_eof"):
                    event = reader.read_eof()
                else:
                    event = ConnectionClosed()
        if event is None:
            event = NEED_DATA
        return event

    def next_event(self):
        if self.their_state is ERROR:
            raise RemoteProtocolError("Can't receive data when peer state is ERROR")
        try:
            event = self._extract()
            if event is not NEED_DATA and event is not PAUSED:
                self._process_event(self.their_role, event)
            if event is NEED_DATA:
                if len(self._buf) > self._max:
                    raise RemoteProtocolError("Receive buffer too long", 431)
                if self._closed:
                    raise RemoteProtocolError("peer unexpectedly closed connection")
            return event
        except BaseException as exc:
            self._process_error(self.their_role)
            if isinstance(exc, LocalProtocolError):
                exc._reraise_as_remote()
            raise

    def start_next_cycle(self):
        old = dict(self._cstate.states)
        self._cstate.start_next_cycle()
        self._request_method = None
        self.client_is_waiting_for_100_continue = False
        self._respond(old, None)

    def send_failed(self):
        self._process_error(self.our_role)
