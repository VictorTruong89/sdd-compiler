"""httpwire: a pure-Python, I/O-free HTTP/1.1 wire protocol library."""
from ._util import LocalProtocolError, RemoteProtocolError
from ._events import (Request, InformationalResponse, Response, Data,
                      EndOfMessage, ConnectionClosed)
from ._connection import (Connection, CLIENT, SERVER, NEED_DATA, PAUSED, IDLE,
                          SEND_RESPONSE, SEND_BODY, DONE, MUST_CLOSE, CLOSED,
                          MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL, ERROR)

__all__ = ["CLIENT", "CLOSED", "Connection", "ConnectionClosed", "Data", "DONE",
           "EndOfMessage", "ERROR", "IDLE", "InformationalResponse",
           "LocalProtocolError", "MIGHT_SWITCH_PROTOCOL", "MUST_CLOSE",
           "NEED_DATA", "PAUSED", "RemoteProtocolError", "Request", "Response",
           "SEND_BODY", "SEND_RESPONSE", "SERVER", "SWITCHED_PROTOCOL"]
