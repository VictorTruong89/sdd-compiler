"""Every checklist id must be referenced by a `# spec:` annotation in httpwire/ or tests/."""

import pathlib
import re

import pytest

ROOT = pathlib.Path(__file__).resolve().parent.parent
CHECKLIST = ROOT / "spec" / "CHECKLIST.md"
_ID = r"N-(\d{6})"
_RANGE = re.compile(_ID + r"(?:\s*[–-]\s*N-(\d{6}))?")


def _covered_ids():
    covered = set()
    files = list((ROOT / "httpwire").glob("*.py")) + list((ROOT / "tests").glob("*.py"))
    for path in files:
        for match in _RANGE.finditer(path.read_text(encoding="utf-8")):
            low = int(match.group(1))
            high = int(match.group(2) or low)
            covered.update("N-%06d" % i for i in range(low, high + 1))
    return covered


@pytest.mark.skipif(not CHECKLIST.exists(), reason="spec export not present")
def test_every_checklist_id_is_annotated():
    wanted = set(re.findall(r"N-\d{6}", CHECKLIST.read_text(encoding="utf-8")))
    assert len(wanted) == 522
    missing = sorted(wanted - _covered_ids())
    assert not missing, missing
