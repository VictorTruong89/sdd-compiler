"""Behavioural tests for httpwire, written from the specification in spec/.

Test names carry the spec ids they exercise (e.g. N-000128).
"""

import pytest

import httpwire
from httpwire import (
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
    Connection,
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    LocalProtocolError,
    RemoteProtocolError,
    Request,
    Response,
)
from httpwire._errors import ReceiveClosedError


def get_request(extra=(), host=b"example.com", version=b"1.1"):
    headers = [(b"Host", host)] + list(extra)
    return Request(method=b"GET", target=b"/", headers=headers, http_version=version)


def post_request(body_headers, host=b"example.com"):
    return Request(
        method=b"POST", target=b"/x", headers=[(b"Host", host)] + list(body_headers)
    )


def pull_all(conn):
    out = []
    while True:
        ev = conn.next_event()
        if ev is NEED_DATA or ev is PAUSED:
            out.append(ev)
            break
        out.append(ev)
    return out


# ---------------------------------------------------------------- package surface


def test_N_000433_root_names_importable():
    for name in [
        "CLIENT", "CLOSED", "Connection", "ConnectionClosed", "Data", "DONE",
        "EndOfMessage", "ERROR", "IDLE", "InformationalResponse", "LocalProtocolError",
        "MIGHT_SWITCH_PROTOCOL", "MUST_CLOSE", "NEED_DATA", "PAUSED",
        "RemoteProtocolError", "Request", "Response", "SEND_BODY", "SEND_RESPONSE",
        "SERVER", "SWITCHED_PROTOCOL",
    ]:
        assert hasattr(httpwire, name), name


def test_N_000438_N_000441_sentinels_distinct():
    values = [CLIENT, SERVER, NEED_DATA, PAUSED, IDLE, SEND_RESPONSE, SEND_BODY, DONE,
              MUST_CLOSE, CLOSED, MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL, ERROR]
    for i, a in enumerate(values):
        for j, b in enumerate(values):
            assert (a == b) == (i == j)
        assert not isinstance(a, (str, bytes))


def test_N_000446_N_000448_error_classes_unrelated():
    assert not issubclass(LocalProtocolError, RemoteProtocolError)
    assert not issubclass(RemoteProtocolError, LocalProtocolError)


# ---------------------------------------------------------------- events (FP-01)


def test_N_000072_request_defaults_and_bytes():
    r = Request(method="GET", target=bytearray(b"/a"), headers=[("Host", "h")])
    assert r.method == b"GET" and type(r.method) is bytes
    assert r.target == b"/a" and type(r.target) is bytes
    assert r.http_version == b"1.1"


def test_N_000078_http11_needs_host_and_only_one():
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/", headers=[])
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/", headers=[(b"host", b"a"), (b"HOST", b"b")])
    # HTTP/1.0 needs no Host, but two Host headers are refused whatever the version
    Request(method=b"GET", target=b"/", headers=[], http_version=b"1.0")
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/", headers=[(b"Host", b"a"), (b"host", b"b")],
                http_version=b"1.0")


def test_N_000079_N_000083_status_ranges_and_defaults():
    r = Response(status_code=200, headers=[])
    assert r.http_version == b"1.1" and r.reason == b""
    info = InformationalResponse(status_code=100, headers=[])
    assert info.status_code == 100
    with pytest.raises(LocalProtocolError):
        InformationalResponse(status_code=200, headers=[])
    with pytest.raises(LocalProtocolError):
        Response(status_code=199, headers=[])
    with pytest.raises(LocalProtocolError):
        Response(status_code=1000, headers=[])
    with pytest.raises(LocalProtocolError):
        Response(status_code="200", headers=[])


def test_N_000460_int_subclass_status():
    import enum

    class S(enum.IntEnum):
        OK = 200

    assert Response(status_code=S.OK, headers=[]).status_code == 200
    assert type(Response(status_code=S.OK, headers=[]).status_code) is int


def test_N_000084_N_000086_data_eom_close():
    assert Data(data=b"x").chunk_start is False
    assert EndOfMessage().headers == []
    assert ConnectionClosed() == ConnectionClosed()


def test_N_000087_N_000091_header_views():
    r = Request(method=b"GET", target=b"/", headers=[("Host", "a"), ("X-Thing", "V")])
    assert list(r.headers) == [(b"host", b"a"), (b"x-thing", b"V")]
    assert r.headers.raw_items() == [(b"Host", b"a"), (b"X-Thing", b"V")]


def test_N_000092_N_000096_content_length_collapse():
    r = Request(method=b"POST", target=b"/", headers=[
        (b"Host", b"a"), (b"Content-Length", b"5"), (b"content-length", b"5, 5")])
    assert list(r.headers) == [(b"host", b"a"), (b"content-length", b"5")]
    with pytest.raises(LocalProtocolError):
        Request(method=b"POST", target=b"/", headers=[
            (b"Host", b"a"), (b"Content-Length", b"5"), (b"Content-Length", b"6")])


def test_N_000092_N_000096_transfer_encoding_normalized():
    r = Request(method=b"POST", target=b"/", headers=[(b"Host", b"a"), (b"Transfer-Encoding", b"CHUNKED")])
    assert r.headers[-1] == (b"transfer-encoding", b"chunked")


def test_N_000121_second_transfer_encoding_refused_501():
    with pytest.raises(LocalProtocolError) as info:
        Request(method=b"POST", target=b"/", headers=[
            (b"Host", b"a"), (b"Transfer-Encoding", b"chunked"), (b"Transfer-Encoding", b"chunked")])
    assert info.value.error_status_hint == 501


def test_N_000120_other_codings_refused_501():
    with pytest.raises(LocalProtocolError) as info:
        Request(method=b"POST", target=b"/", headers=[(b"Host", b"a"), (b"Transfer-Encoding", b"gzip, chunked")])
    assert info.value.error_status_hint == 501


def test_N_000097_N_000100_value_rule():
    Request(method=b"GET", target=b"/", headers=[(b"Host", b"a"), (b"X-A", b"a\tb\xff")])
    for bad in [b" lead", b"trail ", b"\tx", b"x\t", b"nul\x00", b"cr\r", b"ctl\x01"]:
        with pytest.raises(LocalProtocolError):
            Request(method=b"GET", target=b"/", headers=[(b"Host", b"a"), (b"X-A", bad)])


def test_N_000106_header_name_token():
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/", headers=[(b"Host", b"a"), (b"Bad Name", b"x")])


def test_N_000110_N_000111_target_and_method():
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/a b", headers=[(b"Host", b"a")])
    with pytest.raises(LocalProtocolError):
        Request(method=b"G ET", target=b"/", headers=[(b"Host", b"a")])


def test_N_000114_N_000119_content_length_digits():
    with pytest.raises(LocalProtocolError):
        Response(status_code=200, headers=[(b"Content-Length", b"1x")])
    Response(status_code=200, headers=[(b"Content-Length", b"1" * 18)])
    with pytest.raises(LocalProtocolError):
        Response(status_code=200, headers=[(b"Content-Length", b"1" * 19)])


def test_N_000450_N_000466_invalid_construction_raises_local_error():
    with pytest.raises(LocalProtocolError):
        Response(status_code=200, headers=[(b"X", b"a\n")])


def test_N_000469_headers_bad_pair_refused():
    with pytest.raises(LocalProtocolError):
        Response(status_code=200, headers=[(b"X",)])


# ---------------------------------------------------------------- connection basics


def test_N_000476_N_000477_role_checks():
    with pytest.raises(LocalProtocolError):
        Connection("client")
    with pytest.raises(ValueError):
        Connection(None)


def test_N_000123_initial_states_and_roles():
    c = Connection(CLIENT)
    assert c.our_role is CLIENT and c.their_role is SERVER
    assert c.our_state is IDLE and c.their_state is IDLE
    assert c.states == {CLIENT: IDLE, SERVER: IDLE}
    assert c.trailing_data == (b"", False)
    assert c.their_http_version is None


def test_N_000127_pull_on_empty_is_need_data():
    assert Connection(SERVER).next_event() is NEED_DATA


def test_N_000128_N_000133_request_bytes_and_states():
    c = Connection(CLIENT)
    data = c.send(get_request(extra=[(b"X-Y", b"1")]))
    assert data == b"GET / HTTP/1.1\r\nHost: example.com\r\nX-Y: 1\r\n\r\n"
    assert c.our_state is SEND_BODY and c.their_state is SEND_RESPONSE
    assert c.their_http_version is None  # client does not record its own version


def test_N_000161_host_written_first():
    c = Connection(CLIENT)
    data = c.send(Request(method=b"GET", target=b"/", headers=[(b"X-A", b"1"), (b"Host", b"h")]))
    assert data == b"GET / HTTP/1.1\r\nHost: h\r\nX-A: 1\r\n\r\n"


def test_N_000163_original_casing_on_wire():
    c = Connection(CLIENT)
    data = c.send(Request(method=b"GET", target=b"/", headers=[(b"HoSt", b"h"), (b"X-Case", b"1")]))
    assert b"HoSt: h\r\n" in data and b"X-Case: 1\r\n" in data


def test_N_000144_N_000152_feed_then_pull_and_round_trip():
    c = Connection(CLIENT)
    s = Connection(SERVER)
    c.send(post_request([(b"Content-Length", b"5")]))
    c.send(Data(data=b"hel"))
    c.send(Data(data=b"lo"))
    c.send(EndOfMessage())
    wire = b"POST /x HTTP/1.1\r\nHost: example.com\r\nContent-Length: 5\r\n\r\nhello"
    s.receive_data(wire)
    ev = s.next_event()
    assert type(ev) is Request and ev.method == b"POST"
    assert s.their_http_version == b"1.1"
    assert s.their_state is SEND_BODY and s.our_state is SEND_RESPONSE
    body = b""
    while True:
        e = s.next_event()
        if type(e) is Data:
            body += e.data
        else:
            assert type(e) is EndOfMessage
            break
    assert body == b"hello"
    assert s.their_state is DONE


def test_N_000153_N_000155_need_data_retains_bytes():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r")
    assert s.next_event() is NEED_DATA
    s.receive_data(b"\n\r\n")
    assert type(s.next_event()) is Request


def test_N_000165_lone_lf_accepted_in_head():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\nHost: a\n\n")
    assert type(s.next_event()) is Request


def test_N_000167_N_000169_obsolete_folding_joined():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\nX-Long: one\r\n   two\r\n\r\n")
    ev = s.next_event()
    assert ev.headers[-1] == (b"x-long", b"one two")


def test_N_000166_status_without_reason_accepted():
    c = Connection(CLIENT)
    c.send(get_request())
    c.send(EndOfMessage())
    c.receive_data(b"HTTP/1.1 200\r\nContent-Length: 0\r\n\r\n")
    ev = c.next_event()
    assert type(ev) is Response and ev.reason == b""


def test_N_000172_N_000173_role_error_no_connection():
    with pytest.raises(LocalProtocolError):
        Connection("x")


def test_N_000177_N_000179_space_at_start_fails_at_once():
    s = Connection(SERVER)
    s.receive_data(b" GET")
    with pytest.raises(RemoteProtocolError):
        s.next_event()
    assert s.their_state is ERROR


def test_N_000180_N_000182_feed_after_close_is_runtime_error():
    s = Connection(SERVER)
    s.receive_data(b"")
    with pytest.raises(ReceiveClosedError) as info:
        s.receive_data(b"x")
    assert not isinstance(info.value, (LocalProtocolError, RemoteProtocolError))
    assert isinstance(info.value, RuntimeError)


# ---------------------------------------------------------------- framing (FP-03)


def test_N_000185_no_framing_request_empty_body():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    assert type(s.next_event()) is Request
    assert type(s.next_event()) is EndOfMessage


def test_N_000202_chunked_send_and_passthrough():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    s.next_event()
    head = s.send(Response(status_code=200, headers=[]))
    assert head == b"HTTP/1.1 200 \r\ntransfer-encoding: chunked\r\n\r\n"
    assert s.send(Data(data=b"hello")) == b"5\r\nhello\r\n"
    assert s.send(Data(data=b"")) == b""
    assert s.send(EndOfMessage()) == b"0\r\n\r\n"
    assert s.our_state is DONE


def test_N_000233_N_000237_passthrough_identity():
    class Placeholder(object):
        def __len__(self):
            return 7

    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\nConnection: keep-alive\r\n\r\n")
    s.next_event()
    s.next_event()
    s.send_with_data_passthrough(Response(status_code=200, headers=[(b"Content-Length", b"7")]))
    obj = Placeholder()
    pieces = s.send_with_data_passthrough(Data(data=obj))
    assert any(p is obj for p in pieces)
    assert s.send_with_data_passthrough(EndOfMessage()) == []


def test_N_000188_N_000191_content_length_send_limits():
    c = Connection(CLIENT)
    c.send(post_request([(b"Content-Length", b"3")]))
    with pytest.raises(LocalProtocolError):
        c.send(Data(data=b"toolong"))
    assert c.our_state is ERROR


def test_N_000238_eom_before_length_refused():
    c = Connection(CLIENT)
    c.send(post_request([(b"Content-Length", b"3")]))
    c.send(Data(data=b"ab"))
    with pytest.raises(LocalProtocolError):
        c.send(EndOfMessage())


def test_N_000198_N_000199_content_length_zero_response_kept():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    s.next_event()
    assert s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")])) == \
        b"HTTP/1.1 200 \r\ncontent-length: 0\r\n\r\n"


def test_N_000207_transfer_encoding_wins_for_response():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    s.next_event()
    head = s.send(Response(status_code=200, headers=[(b"Content-Length", b"3"), (b"Transfer-Encoding", b"chunked")]))
    assert b"content-length" not in head and b"transfer-encoding: chunked" in head


def test_N_000203_N_000208_close_delimited_response_for_http10():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.0\r\n\r\n")
    s.next_event()
    s.next_event()
    head = s.send(Response(status_code=200, headers=[]))
    assert head == b"HTTP/1.1 200 \r\nConnection: close\r\n\r\n"
    assert s.send(Data(data=b"raw")) == b"raw"
    assert s.send(EndOfMessage()) == b""
    assert s.our_state is MUST_CLOSE


def test_N_000208_N_000214_close_delimited_receive():
    c = Connection(CLIENT)
    c.send(get_request())
    c.send(EndOfMessage())
    c.receive_data(b"HTTP/1.0 200 OK\r\n\r\nbody bytes")
    assert type(c.next_event()) is Response
    d = c.next_event()
    assert type(d) is Data and d.data == b"body bytes"
    assert c.next_event() is NEED_DATA
    c.receive_data(b"")
    assert type(c.next_event()) is EndOfMessage
    assert type(c.next_event()) is ConnectionClosed
    assert c.our_state is MUST_CLOSE


def test_N_000215_N_000219_head_response_empty_and_framing():
    s = Connection(SERVER)
    s.receive_data(b"HEAD / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    s.next_event()
    head = s.send(Response(status_code=200, headers=[(b"Content-Length", b"10")]))
    assert head == b"HTTP/1.1 200 \r\ncontent-length: 10\r\n\r\n"
    assert s.send(EndOfMessage()) == b""
    assert s.our_state is DONE


def test_N_000215_204_has_no_body_and_no_framing():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    s.next_event()
    assert s.send(Response(status_code=204, headers=[])) == b"HTTP/1.1 204 \r\n\r\n"
    assert s.send(EndOfMessage()) == b""


def test_N_000220_N_000227_chunk_marks_on_receive():
    c = Connection(CLIENT)
    c.send(get_request())
    c.send(EndOfMessage())
    c.receive_data(b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n")
    assert type(c.next_event()) is Response
    c.receive_data(b"5\r\nhe")
    d1 = c.next_event()
    assert (d1.data, d1.chunk_start, d1.chunk_end) == (b"he", True, False)
    c.receive_data(b"llo\r\n3;ext=1\r\nabc\r\n0\r\nX-T: 1\r\n\r\n")
    d2 = c.next_event()
    assert (d2.data, d2.chunk_start, d2.chunk_end) == (b"llo", False, True)
    d3 = c.next_event()
    assert (d3.data, d3.chunk_start, d3.chunk_end) == (b"abc", True, True)
    eom = c.next_event()
    assert type(eom) is EndOfMessage and eom.headers == [(b"x-t", b"1")]


def test_N_000242_N_000245_bad_chunk_framing_refused():
    for wire in [b"zz\r\n", b"5\r\nhelloXX"]:
        c = Connection(CLIENT)
        c.send(get_request())
        c.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n" + wire)
        c.next_event()
        with pytest.raises(RemoteProtocolError):
            while True:
                ev = c.next_event()
                if ev is NEED_DATA:
                    break
        assert c.their_state is ERROR


def test_N_000228_chunk_size_digit_limit():
    c = Connection(CLIENT)
    c.send(get_request())
    c.send(EndOfMessage())
    c.receive_data(b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n" + b"1" * 33 + b"\r\n")
    c.next_event()
    with pytest.raises(RemoteProtocolError):
        c.next_event()


def test_N_000246_other_transfer_encoding_refused():
    with pytest.raises(LocalProtocolError):
        Response(status_code=200, headers=[(b"Transfer-Encoding", b"gzip")])


# ---------------------------------------------------------------- lifecycle (FP-04)


def test_N_000270_N_000271_keep_alive_second_cycle():
    c = Connection(CLIENT)
    s = Connection(SERVER)
    wire_req = c.send(get_request())
    c.send(EndOfMessage())
    s.receive_data(wire_req)
    s.next_event()
    s.next_event()
    resp = s.send(Response(status_code=200, headers=[(b"Content-Length", b"2")]))
    resp += s.send(Data(data=b"ok"))
    resp += s.send(EndOfMessage())
    c.receive_data(resp)
    assert type(c.next_event()) is Response
    assert type(c.next_event()) is Data
    assert type(c.next_event()) is EndOfMessage
    assert c.states == {CLIENT: DONE, SERVER: DONE}
    assert s.states == {CLIENT: DONE, SERVER: DONE}
    c.start_next_cycle()
    s.start_next_cycle()
    assert c.states == {CLIENT: IDLE, SERVER: IDLE}
    # second cycle
    wire_req2 = c.send(get_request())
    c.send(EndOfMessage())
    s.receive_data(wire_req2)
    assert type(s.next_event()) is Request


def test_N_000272_N_000274_client_cannot_pipeline_and_refusal_is_error():
    c = Connection(CLIENT)
    c.send(get_request())
    c.send(EndOfMessage())
    with pytest.raises(LocalProtocolError):
        c.send(get_request())
    assert c.our_state is ERROR


def test_N_000280_N_000282_start_next_cycle_refusal_recoverable():
    c = Connection(CLIENT)
    c.send(get_request())
    with pytest.raises(LocalProtocolError):
        c.start_next_cycle()
    assert c.our_state is SEND_BODY  # nothing changed, not ERROR


def test_N_000275_N_000279_server_pipelining_paused_then_handled():
    s = Connection(SERVER)
    s.receive_data(
        b"GET /1 HTTP/1.1\r\nHost: a\r\n\r\nGET /2 HTTP/1.1\r\nHost: a\r\n\r\n"
    )
    assert type(s.next_event()) is Request
    assert type(s.next_event()) is EndOfMessage
    assert s.next_event() is PAUSED  # client DONE, bytes remain
    s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    assert s.next_event() is PAUSED
    s.start_next_cycle()
    ev = s.next_event()
    assert type(ev) is Request and ev.target == b"/2"


def test_N_000286_N_000287_http10_cannot_be_kept_alive():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.0\r\nConnection: keep-alive\r\n\r\n")
    s.next_event()
    s.next_event()
    s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    # keep-alive is disabled by the HTTP/1.0 peer, so both sides must close
    assert s.states == {CLIENT: MUST_CLOSE, SERVER: MUST_CLOSE}
    with pytest.raises(LocalProtocolError):
        s.start_next_cycle()


def test_N_000259_N_000262_connection_close_token_whole_element():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\nConnection: Keep-Alive, Close\r\n\r\n")
    s.next_event()
    s.next_event()
    s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    assert s.our_state is MUST_CLOSE
    # "closed-later" is not the close token
    s2 = Connection(SERVER)
    s2.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\nConnection: closed-later\r\n\r\n")
    s2.next_event()
    s2.next_event()
    head = s2.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    assert b"Connection" not in head
    s2.send(EndOfMessage())
    assert s2.our_state is DONE


def test_N_000265_N_000268_response_adds_close_and_drops_keep_alive():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\nConnection: close\r\n\r\n")
    s.next_event()
    s.next_event()
    head = s.send(Response(status_code=200, headers=[(b"Content-Length", b"0"), (b"Connection", b"keep-alive")]))
    assert b"keep-alive" not in head.lower()
    assert b"Connection: close" in head


def test_N_000283_N_000285_server_cannot_send_request_and_client_cannot_send_response():
    s = Connection(SERVER)
    with pytest.raises(LocalProtocolError):
        s.send(get_request())
    c = Connection(CLIENT)
    with pytest.raises(LocalProtocolError):
        c.send(Response(status_code=200, headers=[]))


# ---------------------------------------------------------------- errors (FP-05)


def test_N_000302_N_000306_remote_error_is_sticky_and_send_still_works():
    s = Connection(SERVER)
    s.receive_data(b"BAD\x00 request\r\n\r\n")
    with pytest.raises(RemoteProtocolError):
        s.next_event()
    assert s.their_state is ERROR and s.our_state is IDLE
    with pytest.raises(RemoteProtocolError):
        s.next_event()
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    with pytest.raises(RemoteProtocolError):
        s.next_event()
    resp = s.send(Response(status_code=400, headers=[(b"Content-Length", b"0")]))
    assert b"Connection: close" in resp


def test_N_000307_N_000310_local_send_error_is_sticky():
    c = Connection(CLIENT)
    with pytest.raises(LocalProtocolError):
        c.send(Request(method=b"GET", target=b"/", headers=[(b"Host", b"a")], http_version=b"1.0"))
    assert c.our_state is ERROR
    with pytest.raises(LocalProtocolError):
        c.send(get_request())


def test_N_000312_N_000315_send_failed():
    c = Connection(CLIENT)
    c.send(get_request())
    c.send(EndOfMessage())
    assert c.send_failed() is None
    assert c.our_state is ERROR
    with pytest.raises(LocalProtocolError):
        c.send(EndOfMessage())


def test_N_000316_N_000323_incomplete_size_limit_431():
    s = Connection(SERVER, 100)
    s.receive_data(b"GET / HTTP/1.1\r\nX: " + b"a" * 200)
    with pytest.raises(RemoteProtocolError) as info:
        s.next_event()
    assert info.value.error_status_hint == 431
    assert s.their_state is ERROR


def test_N_000316_default_limit_accepts_large_complete_head_within_range():
    s = Connection(SERVER)
    val = b"a" * 15000
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\nX: " + val + b"\r\n\r\n")
    assert type(s.next_event()) is Request


def test_N_000324_N_000325_eof_mid_body_is_remote_error():
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nContent-Length: 5\r\n\r\nab")
    s.next_event()
    assert type(s.next_event()) is Data
    s.receive_data(b"")
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_N_000290_N_000291_bytes_after_close_are_not_protocol_errors():
    s = Connection(SERVER)
    s.receive_data(b"")
    with pytest.raises(ReceiveClosedError):
        s.receive_data(b"GET")


def test_N_000472_hint_default_400_and_int():
    s = Connection(SERVER)
    s.receive_data(b"\x01GET / HTTP/1.1\r\n\r\n")
    with pytest.raises(RemoteProtocolError) as info:
        s.next_event()
    assert info.value.error_status_hint == 400
    assert type(info.value.error_status_hint) is int


# ---------------------------------------------------------------- shutdown (FP-06)


def test_N_000332_N_000336_close_states():
    c = Connection(CLIENT)
    s = Connection(SERVER)
    data = c.send(ConnectionClosed())
    assert data == b""
    assert c.our_state is CLOSED
    assert c.their_state is MUST_CLOSE  # CLOSED on one side, IDLE on the other
    s.receive_data(b"")
    ev = s.next_event()
    assert type(ev) is ConnectionClosed
    assert s.their_state is CLOSED
    assert s.our_state is MUST_CLOSE
    assert s.next_event() is not None and type(s.next_event()) is ConnectionClosed


def test_N_000345_N_000346_cc_refused_mid_message():
    c = Connection(CLIENT)
    c.send(get_request())
    with pytest.raises(LocalProtocolError):
        c.send(ConnectionClosed())


def test_N_000342_N_000343_pipelined_requests_before_half_close():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.receive_data(b"")
    assert type(s.next_event()) is Request
    assert type(s.next_event()) is EndOfMessage
    s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    # keep-alive, client has closed: client IDLE-or-DONE, pulls ConnectionClosed after
    ev = s.next_event()
    assert type(ev) is ConnectionClosed


# ---------------------------------------------------------------- informational / 100-continue / switch (FP-07)


def test_N_000354_N_000356_100_continue_flags():
    c = Connection(CLIENT)
    s = Connection(SERVER)
    req = Request(method=b"POST", target=b"/", headers=[(b"Host", b"a"), (b"Content-Length", b"1"), (b"Expect", b"100-continue")])
    wire = c.send(req)
    assert c.client_is_waiting_for_100_continue is True
    assert c.they_are_waiting_for_100_continue is False
    s.receive_data(wire)
    s.next_event()
    assert s.client_is_waiting_for_100_continue is True
    assert s.they_are_waiting_for_100_continue is True
    s.send(InformationalResponse(status_code=100, headers=[]))
    assert s.client_is_waiting_for_100_continue is False


def test_N_000357_http10_expect_sets_no_flag():
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.0\r\nExpect: 100-continue\r\nContent-Length: 0\r\n\r\n")
    s.next_event()
    assert s.client_is_waiting_for_100_continue is False


def test_N_000349_N_000353_informational_then_final():
    c = Connection(CLIENT)
    s = Connection(SERVER)
    c.send(get_request())
    c.send(EndOfMessage())
    s.receive_data(get_request_wire())
    s.next_event()
    s.next_event()
    s.send(InformationalResponse(status_code=100, headers=[]))
    assert s.our_state is SEND_RESPONSE
    s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    c.receive_data(b"HTTP/1.1 100 \r\n\r\nHTTP/1.1 200 \r\ncontent-length: 0\r\n\r\n")
    assert type(c.next_event()) is InformationalResponse
    assert type(c.next_event()) is Response


def get_request_wire():
    return b"GET / HTTP/1.1\r\nHost: example.com\r\n\r\n"


def test_N_000364_N_000368_connect_accept_and_switch():
    c = Connection(CLIENT)
    s = Connection(SERVER)
    wire = c.send(Request(method=b"CONNECT", target=b"example.com:443", headers=[(b"Host", b"example.com")]))
    c.send(EndOfMessage())
    assert c.our_state is MIGHT_SWITCH_PROTOCOL
    s.receive_data(wire + b"client-hello-bytes")
    s.next_event()
    s.next_event()
    assert s.next_event() is PAUSED
    s.send(Response(status_code=200, headers=[]))
    assert s.our_state is SWITCHED_PROTOCOL and s.their_state is SWITCHED_PROTOCOL
    assert s.trailing_data == (b"client-hello-bytes", False)
    with pytest.raises(LocalProtocolError):
        s.send(EndOfMessage())
    assert s.our_state is ERROR


def test_N_000378_N_000380_connect_denied_then_next_cycle():
    c = Connection(CLIENT)
    s = Connection(SERVER)
    c.send(Request(method=b"CONNECT", target=b"h:1", headers=[(b"Host", b"h")]))
    c.send(EndOfMessage())
    s.receive_data(b"CONNECT h:1 HTTP/1.1\r\nHost: h\r\n\r\n")
    s.next_event()
    s.next_event()
    s.send(Response(status_code=403, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    c.receive_data(b"HTTP/1.1 403 \r\ncontent-length: 0\r\n\r\n")
    assert type(c.next_event()) is Response
    assert type(c.next_event()) is EndOfMessage
    assert c.states == {CLIENT: DONE, SERVER: DONE}
    assert s.states == {CLIENT: DONE, SERVER: DONE}


def test_N_000394_N_000398_status_101_and_wrong_kind():
    c = Connection(CLIENT)
    s = Connection(SERVER)
    wire = c.send(Request(method=b"GET", target=b"/ws", headers=[(b"Host", b"h"), (b"Upgrade", b"websocket"), (b"Connection", b"Upgrade")]))
    c.send(EndOfMessage())
    s.receive_data(wire + b"frames")
    s.next_event()
    s.next_event()
    with pytest.raises(LocalProtocolError):
        s.send(Response(status_code=101, headers=[]))
    # the refusal above put our server side into ERROR; use a fresh pair
    c2 = Connection(CLIENT)
    s2 = Connection(SERVER)
    wire2 = c2.send(Request(method=b"GET", target=b"/ws", headers=[(b"Host", b"h"), (b"Upgrade", b"websocket")]))
    c2.send(EndOfMessage())
    s2.receive_data(wire2 + b"frames")
    s2.next_event()
    s2.next_event()
    s2.send(InformationalResponse(status_code=101, headers=[(b"Upgrade", b"websocket"), (b"Connection", b"Upgrade")]))
    assert s2.our_state is SWITCHED_PROTOCOL and s2.their_state is SWITCHED_PROTOCOL
    assert s2.next_event() is PAUSED


def test_N_000388_N_000391_switch_pause_then_close_after_denial_is_pulled():
    s = Connection(SERVER)
    s.receive_data(b"CONNECT h:1 HTTP/1.1\r\nHost: h\r\n\r\n")
    s.next_event()
    s.next_event()
    s.receive_data(b"")
    assert s.next_event() is PAUSED  # paused for the proposal
    s.send(Response(status_code=403, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    assert type(s.next_event()) is ConnectionClosed


def test_N_000392_N_000393_client_cannot_send_second_request_while_might_switch():
    c = Connection(CLIENT)
    c.send(Request(method=b"CONNECT", target=b"h:1", headers=[(b"Host", b"h")]))
    c.send(EndOfMessage())
    with pytest.raises(LocalProtocolError):
        c.send(get_request())


def test_N_000406_N_000407_start_next_cycle_during_unanswered_switch_is_refused():
    c = Connection(CLIENT)
    c.send(Request(method=b"CONNECT", target=b"h:1", headers=[(b"Host", b"h")]))
    c.send(EndOfMessage())
    with pytest.raises(LocalProtocolError):
        c.start_next_cycle()
    assert c.our_state is MIGHT_SWITCH_PROTOCOL


def test_N_000222_chunk_start_marker_only_on_first_piece():
    c = Connection(CLIENT)
    c.send(get_request())
    c.send(EndOfMessage())
    c.receive_data(b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n4\r\nab")
    c.next_event()
    first = c.next_event()
    assert first.chunk_start is True and first.chunk_end is False
    assert c.next_event() is NEED_DATA
    c.receive_data(b"cd\r\n0\r\n\r\n")
    last = c.next_event()
    assert last.data == b"cd" and last.chunk_start is False and last.chunk_end is True
