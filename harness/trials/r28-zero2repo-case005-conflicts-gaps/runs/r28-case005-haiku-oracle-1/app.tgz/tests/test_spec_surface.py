"""Tests for the package-level constraints: no I/O, zero dependencies, 3.8 floor, no CLI."""

import ast
import pathlib
import socket

import httpwire

PKG = pathlib.Path(httpwire.__file__).parent
ROOT = PKG.parent


def test_N_000047_N_000049_no_sockets_or_processes(monkeypatch):
    # Importing and driving a connection must not touch the network layer.
    def boom(*args, **kwargs):
        raise AssertionError("network or process use is forbidden")

    monkeypatch.setattr(socket, "socket", boom)
    monkeypatch.setattr(socket, "create_connection", boom)
    c = httpwire.Connection(httpwire.CLIENT)
    c.send(httpwire.Request(method=b"GET", target=b"/", headers=[(b"Host", b"a")]))
    c.send(httpwire.EndOfMessage())


def test_N_000037_N_000039_only_stdlib_imports_inside_package():
    allowed = {"re", "__future__"}
    for path in PKG.glob("*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    top = alias.name.split(".")[0]
                    assert top in allowed or top == "httpwire", (path.name, top)
            elif isinstance(node, ast.ImportFrom):
                if node.level == 0:
                    top = (node.module or "").split(".")[0]
                    assert top in allowed, (path.name, top)


def test_N_000040_python_38_syntax():
    for path in PKG.glob("*.py"):
        ast.parse(path.read_text(encoding="utf-8"), feature_version=(3, 8))


def test_N_000429_N_000431_no_cli_entry_points():
    assert not (PKG / "__main__.py").exists()
    assert not (ROOT / "setup.cfg").exists() or "console_scripts" not in (ROOT / "setup.cfg").read_text()
