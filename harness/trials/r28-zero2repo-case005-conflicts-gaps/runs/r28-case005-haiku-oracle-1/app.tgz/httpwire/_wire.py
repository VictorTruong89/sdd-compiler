"""Wire-level parsing and encoding helpers.

Parsing functions raise RemoteProtocolError; they never touch connection state.

# spec: N-000122–N-000182, N-000183–N-000246
"""

import re

from ._errors import RemoteProtocolError

_REQUEST_LINE_RE = re.compile(
    rb"([!#$%&'*+\-.^_`|~0-9A-Za-z]+) ([\x21-\x7e]+) HTTP/([0-9])\.([0-9])\Z"
)
_STATUS_LINE_RE = re.compile(rb"HTTP/([0-9])\.([0-9]) ([0-9]{3})(?: (.*))?\Z")
_TOKEN_RE = re.compile(rb"[!#$%&'*+\-.^_`|~0-9A-Za-z]+\Z")
# spec: N-000228–N-000232 (16–32 hex digits max, extension after ';' discarded)
# and N-000230 (optional trailing spaces/tabs). CF-000099 resolved to 32.
_CHUNK_SIZE_RE = re.compile(rb"([0-9A-Fa-f]{1,32})(?:;[^\r\n]*)?[ \t]*\Z")

MAX_CHUNK_SIZE_DIGITS = 32
_OWS = b" \t"


def find_head_end(buf):
    """Index just past the blank line ending a header block, or -1.

    Lines may end in CRLF or a lone LF.

    # spec: N-000165
    """
    pos = 0
    while True:
        nl = buf.find(b"\n", pos)
        if nl < 0:
            return -1
        line = bytes(buf[pos:nl])
        if line.endswith(b"\r"):
            line = line[:-1]
        pos = nl + 1
        if line == b"":
            return pos


def split_head(block):
    """Split a complete header block into lines (no terminators), blank line excluded."""
    lines = []
    for raw in bytes(block).split(b"\n"):
        if raw.endswith(b"\r"):
            raw = raw[:-1]
        if raw == b"":
            break
        lines.append(raw)
    return lines


def parse_request_line(line):
    # spec: N-000110, N-000111, N-000156
    match = _REQUEST_LINE_RE.match(line)
    if not match:
        raise RemoteProtocolError("malformed request line")
    method, target, major, minor = match.group(1, 2, 3, 4)
    version = major + b"." + minor
    if version not in (b"1.0", b"1.1"):
        raise RemoteProtocolError("unsupported HTTP version")
    return method, target, version


def parse_status_line(line):
    # spec: N-000166 (reason may be omitted), N-000156
    match = _STATUS_LINE_RE.match(line)
    if not match:
        raise RemoteProtocolError("malformed status line")
    major, minor, code, reason = match.group(1, 2, 3, 4)
    version = major + b"." + minor
    if version not in (b"1.0", b"1.1"):
        raise RemoteProtocolError("unsupported HTTP version")
    status = int(code)
    if status < 100:
        raise RemoteProtocolError("status code out of range")
    if reason is None:
        reason = b""
    reason = reason.rstrip(_OWS)
    return version, status, reason


def parse_header_lines(lines):
    """Parse header lines into (name, value) byte pairs.

    Obsolete line folding is joined to the previous value with a single space.

    # spec: N-000165, N-000167–N-000169, N-000106–N-000109
    """
    pairs = []
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            if not pairs:
                raise RemoteProtocolError("header continuation without a header")
            cont = line.strip(_OWS)
            if not cont:
                continue
            name, value = pairs[-1]
            value = (value + b" " + cont) if value else cont
            pairs[-1] = (name, value)
            continue
        colon = line.find(b":")
        if colon < 0:
            raise RemoteProtocolError("header line without a colon")
        name = line[:colon]
        if not _TOKEN_RE.match(name):
            raise RemoteProtocolError("invalid header name")
        pairs.append((name, line[colon + 1:].strip(_OWS)))
    return pairs


def encode_header_lines(pairs):
    out = []
    for name, value in pairs:
        out.append(name + b": " + value + b"\r\n")
    return b"".join(out)


def parse_chunk_size(line):
    # spec: N-000228–N-000232, N-000242–N-000245
    match = _CHUNK_SIZE_RE.match(line)
    if not match:
        raise RemoteProtocolError("malformed chunk-size line")
    return int(match.group(1), 16)
