"""The bring-your-own-I/O connection object.

The connection never touches a socket. ``send`` turns events into bytes,
``receive_data`` stores bytes, and ``next_event`` parses one event out of the
stored bytes.

# spec: N-000122–N-000182 (FP-02), N-000183–N-000246 (FP-03),
#       N-000247–N-000289 (FP-04), N-000290–N-000331 (FP-05),
#       N-000332–N-000348 (FP-06), N-000349–N-000412 (FP-07),
#       N-000476–N-000522 (Connection interface)
# Terminology and public-surface inventory (feature-point level):
# spec: N-000010–N-000021 (connection object, send, feed, pull, need-data,
#       paused, start next cycle, mark send failed, keep-alive, trailing data),
#       N-000024–N-000027 (connection object, FP-02), N-000028–N-000029 (framing,
#       FP-03), N-000030 (state machine, FP-04), N-000031–N-000034 (errors,
#       FP-05), N-000035 (shutdown, FP-06), N-000036 (informational, FP-07)
"""

from ._errors import (
    LocalProtocolError,
    ReceiveClosedError,
    RemoteProtocolError,
    _InvalidRoleError,
)
from ._events import (
    EVENT_TYPES,
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    Request,
    Response,
    connection_tokens,
    has_expect_100_continue,
)
from ._state import (
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
    other_role,
)
from ._wire import (
    encode_header_lines,
    find_head_end,
    parse_chunk_size,
    parse_header_lines,
    parse_request_line,
    parse_status_line,
    split_head,
)

# spec: N-000317 (default limit: at least 14 KiB, below 18 KiB) — resolves
# CF-000048 in favour of the FP-05 range; see NOTES.md.
DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 16 * 1024

# Owner-side transitions: state of the role that performs the event.
# spec: N-000250–N-000254, N-000283, N-000443–N-000445, N-000344–N-000346
_OWN = {
    CLIENT: {
        IDLE: {Request: SEND_BODY, ConnectionClosed: CLOSED},
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
    },
    SERVER: {
        IDLE: {Response: SEND_BODY, ConnectionClosed: CLOSED},
        SEND_RESPONSE: {InformationalResponse: SEND_RESPONSE, Response: SEND_BODY},
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
    },
}

# Reaction of the other role's state when the peer performs an event.
_PEER = {
    CLIENT: {
        # Denied switch proposal: the client becomes DONE on the final response.
        # spec: N-000378–N-000380
        MIGHT_SWITCH_PROTOCOL: {Response: DONE},
    },
    SERVER: {
        # spec: N-000250
        IDLE: {Request: SEND_RESPONSE},
    },
}

_CONNECT = b"CONNECT"
_HEAD = b"HEAD"
_CHUNKED = b"chunked"
_KEEP_ALIVE = b"keep-alive"
_CLOSE = b"close"
_HTTP11 = b"1.1"
_FRAMING = (b"content-length", b"transfer-encoding")


class _Body(object):
    """Framing state for one message body.

    kind is one of: "length", "chunked", "close", "none".
    """

    __slots__ = ("kind", "remaining", "chunk_state", "chunk_remaining", "chunk_started")

    def __init__(self, kind, remaining=0):
        self.kind = kind
        self.remaining = remaining
        self.chunk_state = "size"
        self.chunk_remaining = 0
        self.chunk_started = False


def _data_length(data):
    if isinstance(data, (bytes, bytearray, memoryview)):
        return memoryview(data).nbytes
    return len(data)


def _content_length_of(headers):
    values = headers.get_all(b"content-length")
    return int(values[0]) if values else None


def _request_body(headers):
    # spec: N-000185–N-000197 (request framing)
    length = _content_length_of(headers)
    if length is not None:
        return _Body("length", length)
    if headers.has(b"transfer-encoding"):
        return _Body("chunked")
    return _Body("length", 0)


def _is_bytes_like(obj):
    return isinstance(obj, (bytes, bytearray, memoryview))


class Connection(object):
    """One HTTP/1.1 connection, tracked from our role and the peer's role.

    # spec: N-000476–N-000481, N-000172
    """

    def __init__(self, role, max_incomplete_event_size=DEFAULT_MAX_INCOMPLETE_EVENT_SIZE):
        # spec: N-000476, N-000477
        if role is not CLIENT and role is not SERVER:
            raise _InvalidRoleError("role must be CLIENT or SERVER, got %r" % (role,))
        # spec: N-000478–N-000480
        if isinstance(max_incomplete_event_size, bool) or not isinstance(
            max_incomplete_event_size, int
        ):
            raise LocalProtocolError("max_incomplete_event_size must be an int")
        if max_incomplete_event_size <= 0:
            raise LocalProtocolError("max_incomplete_event_size must be positive")

        self._our_role = role
        self._their_role = other_role(role)
        self._state = {CLIENT: IDLE, SERVER: IDLE}
        self._max_incomplete = max_incomplete_event_size
        self._buf = bytearray()
        self._closed = False  # receive side closed (an empty chunk was fed)
        self._versions = {CLIENT: None, SERVER: None}
        self._has_close = {CLIENT: False, SERVER: False}
        self._request_method = None
        self._proposals = frozenset()
        self._client_waiting = False
        self._writer = None  # _Body for our outgoing message
        self._reader = None  # _Body for the peer's incoming message

    # ------------------------------------------------------------------
    # Queryable properties
    # ------------------------------------------------------------------

    @property
    def our_role(self):
        return self._our_role

    @property
    def their_role(self):
        return self._their_role

    @property
    def our_state(self):
        return self._state[self._our_role]

    @property
    def their_state(self):
        return self._state[self._their_role]

    @property
    def states(self):
        # spec: N-000125, N-000126
        return {CLIENT: self._state[CLIENT], SERVER: self._state[SERVER]}

    @property
    def their_http_version(self):
        # spec: N-000170, N-000171
        return self._versions[self._their_role]

    @property
    def client_is_waiting_for_100_continue(self):
        # spec: N-000354–N-000357, N-000358, N-000359
        return self._client_waiting

    @property
    def they_are_waiting_for_100_continue(self):
        # spec: N-000354, N-000356 — only a server-role connection reports this
        return self._client_waiting and self._their_role is CLIENT

    @property
    def trailing_data(self):
        # spec: N-000388–N-000391
        return (bytes(self._buf), self._closed)

    # ------------------------------------------------------------------
    # Receive side
    # ------------------------------------------------------------------

    def receive_data(self, data):
        """Store bytes from the peer. An empty chunk means the peer closed.

        # spec: N-000144–N-000152, N-000180–N-000182, N-000507–N-000511
        """
        if data is None:
            raise LocalProtocolError("receive_data needs bytes-like data")
        view = memoryview(data)
        if view.nbytes == 0:
            self._closed = True
            return None
        if self._closed:
            raise ReceiveClosedError("bytes fed after the receive side was closed")
        self._buf += view.tobytes()
        return None

    def next_event(self):
        """Return one event, NEED_DATA, or PAUSED.

        # spec: N-000127, N-000512–N-000516, N-000153–N-000155, N-000275–N-000279
        """
        their = self._their_role
        try:
            return self._next_event()
        except RemoteProtocolError:
            # spec: N-000302–N-000306 — remote error puts their side in ERROR
            self._state[their] = ERROR
            self._respond_to_state_changes()
            raise

    def _next_event(self):
        their = self._their_role
        ts = self._state[their]
        buf = self._buf

        if ts is ERROR:
            raise RemoteProtocolError("peer already violated the protocol")
        if ts is CLOSED:
            # spec: N-000348 / further pulls after a close yield connection-closed
            return ConnectionClosed()
        if ts is SWITCHED_PROTOCOL or ts is MIGHT_SWITCH_PROTOCOL:
            # spec: N-000381–N-000387, N-000373–N-000377, N-000388–N-000391
            return PAUSED
        if ts is DONE or ts is MUST_CLOSE:
            if not buf:
                if self._closed:
                    return self._perform_pull(ConnectionClosed(), None, False)
                return NEED_DATA
            # spec: N-000275–N-000279 — pipelined bytes wait for the next cycle
            return PAUSED
        if ts is IDLE:
            if not buf:
                if self._closed:
                    return self._perform_pull(ConnectionClosed(), None, False)
                return NEED_DATA
            if their is SERVER:
                raise RemoteProtocolError("unexpected data before a request was sent")
            return self._pull_head()
        if ts is SEND_RESPONSE:
            if not buf:
                if self._closed:
                    raise RemoteProtocolError("connection closed before a response")
                return NEED_DATA
            return self._pull_head()
        if ts is SEND_BODY:
            return self._pull_body()
        raise RemoteProtocolError("no receive transition for this state")

    def _pull_head(self):
        buf = self._buf
        # spec: N-000177–N-000179 — a space or control byte where a start line
        # is expected fails at once.
        if buf[0] < 33:
            raise RemoteProtocolError("unexpected byte where a start line is expected")
        end = find_head_end(buf)
        if end < 0:
            # spec: N-000316–N-000323 — incomplete-event size limit
            if len(buf) > self._max_incomplete:
                raise RemoteProtocolError(
                    "incomplete event exceeds the size limit", error_status_hint=431
                )
            if self._closed:
                raise RemoteProtocolError("connection closed in the middle of a head")
            return NEED_DATA

        block = bytes(buf[:end])
        del buf[:end]
        lines = split_head(block)
        if not lines:
            raise RemoteProtocolError("empty start line")
        pairs = parse_header_lines(lines[1:])

        if self._their_role is CLIENT:
            method, target, version = parse_request_line(lines[0])
            event = self._build(Request, method, target, pairs, version)
            body = _request_body(event.headers)
        else:
            version, status, reason = parse_status_line(lines[0])
            if status < 200:
                event = self._build(InformationalResponse, status, pairs, version, reason)
            else:
                event = self._build(Response, status, pairs, version, reason)
            body = self._response_body_for_receive(event)
        accept = self._is_accept(self._their_role, event)
        return self._perform_pull(event, None if accept else body, accept)

    @staticmethod
    def _build(cls, *args):
        try:
            return cls(*args)
        except LocalProtocolError as exc:
            raise RemoteProtocolError(str(exc), error_status_hint=exc.error_status_hint)

    def _response_body_for_receive(self, event):
        # spec: N-000200–N-000218, N-000208–N-000214, N-000215–N-000218
        if isinstance(event, InformationalResponse):
            return None
        if self._request_method == _HEAD or event.status_code in (204, 304):
            return _Body("none")
        length = _content_length_of(event.headers)
        if length is not None:
            return _Body("length", length)
        if event.headers.has(b"transfer-encoding"):
            return _Body("chunked")
        # spec: N-000208 — close-delimited body
        return _Body("close")

    def _pull_body(self):
        body = self._reader
        buf = self._buf

        if body.kind == "none":
            return self._perform_pull(EndOfMessage(), None, False)

        if body.kind == "length":
            if body.remaining == 0:
                return self._perform_pull(EndOfMessage(), None, False)
            if not buf:
                if self._closed:
                    raise RemoteProtocolError("connection closed in the middle of a body")
                return NEED_DATA
            k = min(body.remaining, len(buf))
            data = bytes(buf[:k])
            del buf[:k]
            return self._perform_pull(Data(data), None, False)

        if body.kind == "close":
            # spec: N-000208–N-000214 — the empty feed ends a close-delimited body
            if buf:
                data = bytes(buf)
                del buf[:]
                return self._perform_pull(Data(data), None, False)
            if self._closed:
                return self._perform_pull(EndOfMessage(), None, False)
            return NEED_DATA

        return self._pull_chunked()

    def _pull_chunked(self):
        body = self._reader
        buf = self._buf
        while True:
            if body.chunk_state == "size":
                nl = buf.find(b"\n")
                if nl < 0:
                    if len(buf) > self._max_incomplete:
                        raise RemoteProtocolError(
                            "chunk-size line exceeds the size limit", error_status_hint=431
                        )
                    if self._closed:
                        raise RemoteProtocolError("connection closed in the middle of a chunk")
                    return NEED_DATA
                line = bytes(buf[:nl])
                del buf[: nl + 1]
                if line.endswith(b"\r"):
                    line = line[:-1]
                size = parse_chunk_size(line)
                if size == 0:
                    body.chunk_state = "trailers"
                    continue
                body.chunk_state = "data"
                body.chunk_remaining = size
                body.chunk_started = True
                continue

            if body.chunk_state == "data":
                if not buf:
                    if self._closed:
                        raise RemoteProtocolError("connection closed in the middle of a chunk")
                    return NEED_DATA
                k = min(body.chunk_remaining, len(buf))
                data = bytes(buf[:k])
                del buf[:k]
                body.chunk_remaining -= k
                start = body.chunk_started
                body.chunk_started = False
                end = body.chunk_remaining == 0
                if end:
                    body.chunk_state = "crlf"
                # spec: N-000220–N-000227
                return self._perform_pull(Data(data, chunk_start=start, chunk_end=end), None, False)

            if body.chunk_state == "crlf":
                if len(buf) >= 2:
                    # spec: N-000244 — bytes after chunk data must be exactly CRLF
                    if buf[0:2] != b"\r\n":
                        raise RemoteProtocolError("chunk data not followed by CRLF")
                    del buf[:2]
                    body.chunk_state = "size"
                    continue
                if buf and buf[0:1] != b"\r":
                    raise RemoteProtocolError("chunk data not followed by CRLF")
                if self._closed:
                    raise RemoteProtocolError("connection closed in the middle of a chunk")
                return NEED_DATA

            # trailers
            end = find_head_end(buf)
            if end < 0:
                if len(buf) > self._max_incomplete:
                    raise RemoteProtocolError(
                        "trailer block exceeds the size limit", error_status_hint=431
                    )
                if self._closed:
                    raise RemoteProtocolError("connection closed in the middle of trailers")
                return NEED_DATA
            block = bytes(buf[:end])
            del buf[:end]
            pairs = parse_header_lines(split_head(block))
            event = self._build(EndOfMessage, pairs)
            return self._perform_pull(event, None, False)

    def _perform_pull(self, event, body, accept):
        self._perform(self._their_role, event, body, accept, False)
        return event

    # ------------------------------------------------------------------
    # Send side
    # ------------------------------------------------------------------

    def send(self, event):
        """Encode one event to bytes.

        # spec: N-000497–N-000501, N-000507, N-000510
        """
        return b"".join(self._send(event, passthrough=False))

    def send_with_data_passthrough(self, event):
        """Like send, but returns a list of pieces; object payloads are kept by identity.

        # spec: N-000502–N-000506, N-000233–N-000237
        """
        return self._send(event, passthrough=True)

    def start_next_cycle(self):
        """Reset both sides to IDLE once both are DONE.

        # spec: N-000270, N-000271, N-000280–N-000282, N-000517–N-000519
        """
        if self._state[CLIENT] is not DONE or self._state[SERVER] is not DONE:
            raise LocalProtocolError("cannot start the next cycle: both sides must be DONE")
        self._state[CLIENT] = IDLE
        self._state[SERVER] = IDLE
        self._versions = {CLIENT: None, SERVER: None}
        self._has_close = {CLIENT: False, SERVER: False}
        self._request_method = None
        self._proposals = frozenset()
        self._client_waiting = False
        self._writer = None
        self._reader = None
        return None

    def send_failed(self):
        """Record that the bytes from the last send were not transmitted.

        # spec: N-000312–N-000315, N-000520–N-000522
        """
        self._state[self._our_role] = ERROR
        self._respond_to_state_changes()
        return None

    def _send(self, event, passthrough):
        our = self._our_role
        if self._state[our] is ERROR:
            raise LocalProtocolError("connection is in ERROR; sends fail")
        try:
            pieces, body, accept, force_close = self._prepare_send(event, passthrough)
        except LocalProtocolError:
            # spec: N-000307–N-000310 — a refused send makes our side ERROR
            self._state[our] = ERROR
            self._respond_to_state_changes()
            raise
        self._perform(our, event, body, accept, force_close)
        return pieces

    def _prepare_send(self, event, passthrough):
        our = self._our_role
        if type(event) not in EVENT_TYPES:
            raise LocalProtocolError("send expects an event instance")
        allowed = _OWN[our].get(self._state[our], {})
        if type(event) not in allowed:
            raise LocalProtocolError(
                "%s is not allowed while our state is %r"
                % (type(event).__name__, self._state[our])
            )

        if type(event) is Request:
            return self._prepare_request(event)
        if type(event) is InformationalResponse:
            return self._prepare_informational(event)
        if type(event) is Response:
            return self._prepare_response(event)
        if type(event) is Data:
            return self._prepare_data(event, passthrough)
        if type(event) is EndOfMessage:
            return self._prepare_eom(event)
        return [], None, False, False  # ConnectionClosed produces no bytes

    def _prepare_request(self, event):
        # spec: N-000128–N-000133, N-000161–N-000162, N-000163–N-000164
        if event.http_version != _HTTP11:
            raise LocalProtocolError("only HTTP/1.1 requests can be sent")
        pairs = event.headers.raw_items()
        host = [p for p in pairs if p[0].lower() == b"host"]
        rest = [p for p in pairs if p[0].lower() != b"host"]
        body = _request_body(event.headers)
        if body.kind == "length" and event.headers.has(b"content-length"):
            rest = [p for p in rest if p[0].lower() != b"transfer-encoding"]
        line = event.method + b" " + event.target + b" HTTP/1.1\r\n"
        data = line + encode_header_lines(host + rest) + b"\r\n"
        return [data], body, False, False

    def _prepare_informational(self, event):
        # spec: N-000136–N-000139
        if event.http_version != _HTTP11:
            raise LocalProtocolError("only HTTP/1.1 responses can be sent")
        accept = self._is_accept(self._our_role, event)
        pairs = event.headers.raw_items()
        if accept:
            pairs = [p for p in pairs if p[0].lower() not in _FRAMING]
        data = self._status_line(event) + encode_header_lines(pairs) + b"\r\n"
        return [data], None, accept, False

    def _prepare_response(self, event):
        # spec: N-000136–N-000139, N-000198–N-000207, N-000215–N-000219, N-000265–N-000269
        if event.http_version != _HTTP11:
            raise LocalProtocolError("only HTTP/1.1 responses can be sent")
        accept = self._is_accept(self._our_role, event)
        pairs = event.headers.raw_items()
        if accept:
            # spec: N-000381–N-000387 — accepting response has no framing
            pairs = [p for p in pairs if p[0].lower() not in _FRAMING]
            data = self._status_line(event) + encode_header_lines(pairs) + b"\r\n"
            return [data], None, True, False

        peer_11 = self._versions[self._their_role] == _HTTP11
        status = event.status_code
        has_cl = event.headers.has(b"content-length")
        has_te = event.headers.has(b"transfer-encoding")
        framing_pair = None
        close_needed = not peer_11  # no request seen, or HTTP/1.0 peer

        if self._request_method == _HEAD or status in (204, 304):
            body = _Body("none")
            if self._request_method == _HEAD:
                # spec: N-000219 — HEAD gets the framing headers GET would
                if has_cl:
                    framing_pair = (b"content-length", str(_content_length_of(event.headers)).encode("ascii"))
                elif peer_11:
                    framing_pair = (b"transfer-encoding", _CHUNKED)
                else:
                    close_needed = True
            # spec: N-000215–N-000218 — 204/304 carry no framing
        elif has_te:
            # spec: N-000207 — transfer-encoding wins over Content-Length
            if peer_11:
                body = _Body("chunked")
                framing_pair = (b"transfer-encoding", _CHUNKED)
            else:
                body = _Body("close")
                close_needed = True
        elif has_cl:
            length = _content_length_of(event.headers)
            body = _Body("length", length)
            framing_pair = (b"content-length", str(length).encode("ascii"))
        else:
            if peer_11:
                body = _Body("chunked")
                framing_pair = (b"transfer-encoding", _CHUNKED)
            else:
                body = _Body("close")
                close_needed = True

        out = []
        placed = False
        for name, value in pairs:
            if name.lower() in _FRAMING:
                if framing_pair is not None and not placed:
                    out.append(framing_pair)
                    placed = True
                continue
            out.append((name, value))
        if framing_pair is not None and not placed:
            out.append(framing_pair)

        response_close = _CLOSE in connection_tokens(event.headers)
        if close_needed or response_close or self._keep_alive_disabled():
            out = self._rewrite_connection_for_close(out)
            close_needed = True

        data = self._status_line(event) + encode_header_lines(out) + b"\r\n"
        return [data], body, False, close_needed

    @staticmethod
    def _rewrite_connection_for_close(pairs):
        # spec: N-000265–N-000269 — drop keep-alive, ensure close
        tokens = []
        for name, value in pairs:
            if name.lower() == b"connection":
                for piece in value.split(b","):
                    token = piece.strip(b" \t")
                    if token:
                        tokens.append(token)
        kept = []
        seen_close = False
        for token in tokens:
            lower = token.lower()
            if lower == _KEEP_ALIVE:
                continue
            if lower == _CLOSE:
                if seen_close:
                    continue
                seen_close = True
            kept.append(token)
        if not seen_close:
            kept.append(b"close")
        out = []
        placed = False
        for name, value in pairs:
            if name.lower() == b"connection":
                if not placed:
                    out.append((b"Connection", b", ".join(kept)))
                    placed = True
                continue
            out.append((name, value))
        if not placed:
            out.append((b"Connection", b", ".join(kept)))
        return out

    @staticmethod
    def _status_line(event):
        reason = event.reason
        return b"HTTP/1.1 %03d %s\r\n" % (event.status_code, reason)

    def _prepare_data(self, event, passthrough):
        # spec: N-000233–N-000237, N-000238–N-000240, N-000220–N-000227
        body = self._writer
        data = event.data
        if _is_bytes_like(data):
            payload = bytes(data)
        elif passthrough and hasattr(data, "__len__"):
            payload = data  # kept by identity
        else:
            try:
                payload = memoryview(data).tobytes()
            except TypeError:
                raise LocalProtocolError("Data payload must be bytes-like")
        n = _data_length(payload)

        if body.kind == "none":
            return [], body, False, False
        if body.kind == "length":
            if n > body.remaining:
                raise LocalProtocolError("data exceeds the declared Content-Length")
            return ([payload] if n else []), body, False, False
        if body.kind == "close":
            return ([payload] if n else []), body, False, False
        # chunked: marks are ignored on send
        if n == 0:
            return [], body, False, False
        return [b"%x\r\n" % n, payload, b"\r\n"], body, False, False

    def _prepare_eom(self, event):
        # spec: N-000238–N-000241
        body = self._writer
        if body.kind == "length":
            if body.remaining != 0:
                raise LocalProtocolError("end-of-message before Content-Length was sent")
            if len(event.headers):
                raise LocalProtocolError("trailers are not allowed with Content-Length framing")
            return [], body, False, False
        if body.kind == "chunked":
            trailers = encode_header_lines(event.headers.raw_items())
            return [b"0\r\n" + trailers + b"\r\n"], body, False, False
        if len(event.headers):
            raise LocalProtocolError("trailers are not allowed with close-delimited framing")
        return [], body, False, False

    # ------------------------------------------------------------------
    # Shared transition logic
    # ------------------------------------------------------------------

    def _is_accept(self, performer, event):
        # spec: N-000364–N-000372, N-000394–N-000398, CF-000106 resolved to 2xx
        if performer is not SERVER:
            return False
        if self._state[CLIENT] is not MIGHT_SWITCH_PROTOCOL:
            return False
        if type(event) is Response:
            return 200 <= event.status_code < 300 and "connect" in self._proposals
        if type(event) is InformationalResponse:
            return event.status_code == 101 and "upgrade" in self._proposals
        return False

    def _body_of(self, performer):
        return self._writer if performer is self._our_role else self._reader

    def _perform(self, performer, event, body, accept, force_close):
        """Apply one event (sent by us or pulled from the peer) to all state."""
        recv = other_role(performer)
        st = self._state
        ev_type = type(event)

        if accept:
            st[CLIENT] = SWITCHED_PROTOCOL
            st[SERVER] = SWITCHED_PROTOCOL
        else:
            own_next = _OWN[performer][st[performer]][ev_type]
            if performer is CLIENT and ev_type is EndOfMessage and self._proposals:
                # spec: N-000373–N-000377 — client waits for the server's answer
                own_next = MIGHT_SWITCH_PROTOCOL
            peer_next = _PEER[recv].get(st[recv], {}).get(ev_type)
            st[performer] = own_next
            if peer_next is not None:
                st[recv] = peer_next

        if ev_type is Request:
            # spec: N-000161, N-000354, N-000364–N-000365
            self._request_method = event.method
            self._proposals = self._proposals_of(event)
            self._versions[performer] = event.http_version
            self._has_close[performer] = _CLOSE in connection_tokens(event.headers)
            if (
                performer is CLIENT
                and event.http_version == _HTTP11
                and has_expect_100_continue(event.headers)
            ):
                self._client_waiting = True
            self._set_body(performer, body)
        elif ev_type is InformationalResponse or ev_type is Response:
            self._versions[performer] = event.http_version
            if ev_type is Response:
                self._has_close[performer] = force_close or (
                    _CLOSE in connection_tokens(event.headers)
                )
                if not accept:
                    self._set_body(performer, body)
            if performer is SERVER:
                # spec: N-000358 — server's informational or final response
                self._client_waiting = False
        elif ev_type is Data:
            current = self._body_of(performer)
            if current.kind == "length":
                current.remaining -= _data_length(event.data)
        if performer is CLIENT and ev_type in (Data, EndOfMessage):
            # spec: N-000359 — client's data or end-of-message
            self._client_waiting = False

        self._respond_to_state_changes()

    def _set_body(self, performer, body):
        if performer is self._our_role:
            self._writer = body
        else:
            self._reader = body

    @staticmethod
    def _proposals_of(event):
        proposals = set()
        if event.method == _CONNECT:
            proposals.add("connect")  # spec: N-000364
        if event.headers.has(b"upgrade"):
            proposals.add("upgrade")  # spec: N-000366
        return frozenset(proposals)

    def _keep_alive_disabled(self):
        # spec: N-000259–N-000264, N-000286–N-000287, N-000302–N-000306
        if self._state[CLIENT] is ERROR or self._state[SERVER] is ERROR:
            return True
        for role in (CLIENT, SERVER):
            version = self._versions[role]
            if version is not None and version != _HTTP11:
                return True
        return self._has_close[CLIENT] or self._has_close[SERVER]

    def _respond_to_state_changes(self):
        st = self._state
        for _ in range(4):
            changed = False
            if self._keep_alive_disabled():
                # spec: N-000264 — a side that would be DONE becomes MUST_CLOSE
                for role in (CLIENT, SERVER):
                    if st[role] is DONE:
                        st[role] = MUST_CLOSE
                        changed = True
            # spec: N-000311–N-000313 — ERROR on one side, DONE on the other
            for role in (CLIENT, SERVER):
                if st[role] is ERROR and st[other_role(role)] is DONE:
                    st[other_role(role)] = MUST_CLOSE
                    changed = True
            # spec: N-000336–N-000338 — CLOSED on one side, IDLE/DONE on the other
            for role in (CLIENT, SERVER):
                if st[role] is CLOSED and st[other_role(role)] in (IDLE, DONE):
                    st[other_role(role)] = MUST_CLOSE
                    changed = True
            if not changed:
                break
