"""Exception classes for httpwire.

# spec: N-000290–N-000291, N-000326
"""


class ProtocolError(Exception):
    """Common base for the two protocol-error kinds.

    Neither concrete kind is a subclass of the other; this base is internal.
    """

    def __init__(self, message="", error_status_hint=400):
        super().__init__(message)
        # spec: N-000472 — exactly of type int
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(ProtocolError):
    """The integrator's own event or send violated the protocol.

    # spec: N-000466, N-000472, N-000473
    """


class RemoteProtocolError(ProtocolError):
    """The peer's bytes violated the protocol.

    # spec: N-000472, N-000473
    """


class ReceiveClosedError(RuntimeError):
    """Bytes were fed after the receive side was closed.

    This is a runtime error, deliberately neither a local nor a remote
    protocol error.

    # spec: N-000474, N-000475, N-000180–N-000182
    """


class _InvalidRoleError(LocalProtocolError, ValueError):
    """Connection constructed with a role that is neither CLIENT nor SERVER.

    # spec: N-000172, N-000173, N-000476, N-000477
    """
