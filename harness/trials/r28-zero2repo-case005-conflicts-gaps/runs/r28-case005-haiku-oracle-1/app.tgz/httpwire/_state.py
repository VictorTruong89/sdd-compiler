"""Roles, states, and the two non-event pull results.

Every value here is a distinct sentinel object. None of them compares equal
to any other, and none of them is a string.

# spec: N-000438, N-000439, N-000440–N-000445
"""


class _Sentinel(object):
    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return self._name

    def __reduce__(self):  # keep identity stable under pickling
        return self._name


# Roles
# spec: N-000438, N-000439
CLIENT = _Sentinel("CLIENT")
SERVER = _Sentinel("SERVER")

# Non-event pull results
# spec: N-000440, N-000441, N-000442
NEED_DATA = _Sentinel("NEED_DATA")
PAUSED = _Sentinel("PAUSED")

# The nine states
# spec: N-000443, N-000444, N-000445, N-000123–N-000126
IDLE = _Sentinel("IDLE")
SEND_RESPONSE = _Sentinel("SEND_RESPONSE")
SEND_BODY = _Sentinel("SEND_BODY")
DONE = _Sentinel("DONE")
MUST_CLOSE = _Sentinel("MUST_CLOSE")
CLOSED = _Sentinel("CLOSED")
MIGHT_SWITCH_PROTOCOL = _Sentinel("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = _Sentinel("SWITCHED_PROTOCOL")
ERROR = _Sentinel("ERROR")

ALL_STATES = (
    IDLE,
    SEND_RESPONSE,
    SEND_BODY,
    DONE,
    MUST_CLOSE,
    CLOSED,
    MIGHT_SWITCH_PROTOCOL,
    SWITCHED_PROTOCOL,
    ERROR,
)

_OTHER = {CLIENT: SERVER, SERVER: CLIENT}


def other_role(role):
    return _OTHER[role]
