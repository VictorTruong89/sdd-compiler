"""The six HTTP event types.

Each event is constructed from keyword (or positional) arguments named after
its fields. Invalid construction raises LocalProtocolError and produces no
event.

# spec: N-000070–N-000071, N-000072–N-000086, N-000450–N-000466
# A refused construction raises and produces no event; no connection is involved,
# so nothing else changes and a later valid construction succeeds.
# spec: N-000101–N-000103, N-000297–N-000299
"""

from ._errors import LocalProtocolError
from ._headers import (
    Headers,
    check_method,
    check_reason,
    check_target,
    check_version,
    to_bytes,
)

_CLOSE_TOKEN = b"close"


def _check_status(status_code, low, high):
    # spec: N-000112, N-000113, N-000460
    if isinstance(status_code, bool) or not isinstance(status_code, int):
        raise LocalProtocolError("status code must be an integer")
    status = int(status_code)
    if not (low <= status < high):
        raise LocalProtocolError("status code %d is out of range" % status)
    return status


def _check_host(headers, version):
    # spec: N-000077, N-000078, N-000104, N-000105
    count = len(headers.get_all(b"host"))
    if count > 1:
        raise LocalProtocolError("more than one Host header")
    if version == b"1.1" and count == 0:
        raise LocalProtocolError("HTTP/1.1 request needs a Host header")


class _Event(object):
    __slots__ = ()
    _fields = ()

    def __eq__(self, other):
        if type(other) is not type(self):
            return NotImplemented
        return all(getattr(self, f) == getattr(other, f) for f in self._fields)

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    __hash__ = None

    def __repr__(self):
        parts = ", ".join("%s=%r" % (f, getattr(self, f)) for f in self._fields)
        return "%s(%s)" % (type(self).__name__, parts)


class Request(_Event):
    """Start of an HTTP request.

    # spec: N-000072–N-000078, N-000104, N-000105, N-000110, N-000111
    """

    __slots__ = ("method", "target", "headers", "http_version")
    _fields = ("method", "target", "headers", "http_version")

    def __init__(self, method, target, headers, http_version=b"1.1"):
        method = check_method(to_bytes(method, "method"))
        target = check_target(to_bytes(target, "target"))
        version = check_version(to_bytes(http_version, "http_version"))
        headers = Headers(headers)
        _check_host(headers, version)
        self.method = method
        self.target = target
        self.headers = headers
        self.http_version = version

    # spec: N-000172, N-000173 — (role checks live in Connection)


class InformationalResponse(_Event):
    """An HTTP 1xx response.

    # spec: N-000079–N-000083, N-000112, N-000113
    """

    __slots__ = ("status_code", "headers", "http_version", "reason")
    _fields = ("status_code", "headers", "http_version", "reason")

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        status = _check_status(status_code, 100, 200)
        version = check_version(to_bytes(http_version, "http_version"))
        reason = check_reason(to_bytes(reason, "reason"))
        self.status_code = status
        self.headers = Headers(headers)
        self.http_version = version
        self.reason = reason


class Response(_Event):
    """Start of a final HTTP response.

    # spec: N-000079–N-000083, N-000112, N-000113
    """

    __slots__ = ("status_code", "headers", "http_version", "reason")
    _fields = ("status_code", "headers", "http_version", "reason")

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        status = _check_status(status_code, 200, 1000)
        version = check_version(to_bytes(http_version, "http_version"))
        reason = check_reason(to_bytes(reason, "reason"))
        self.status_code = status
        self.headers = Headers(headers)
        self.http_version = version
        self.reason = reason


class Data(_Event):
    """A piece of a message body.

    # spec: N-000084, N-000220–N-000227, N-000463–N-000465
    """

    __slots__ = ("data", "chunk_start", "chunk_end")
    _fields = ("data", "chunk_start", "chunk_end")

    def __init__(self, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)


class EndOfMessage(_Event):
    """End of a request or response, optionally with trailing headers.

    # spec: N-000084, N-000085, N-000467–N-000468
    """

    __slots__ = ("headers",)
    _fields = ("headers",)

    def __init__(self, headers=()):
        self.headers = Headers(headers)


class ConnectionClosed(_Event):
    """This party will not send more HTTP data.

    # spec: N-000086, N-000332–N-000333
    """

    __slots__ = ()
    _fields = ()

    def __init__(self):
        pass


def connection_tokens(headers):
    """Lowercase, whole-element tokens of all Connection headers.

    # spec: N-000259–N-000262 (whole comma-separated element, case-insensitive)
    """
    tokens = []
    for value in headers.get_all(b"connection"):
        for piece in value.split(b","):
            token = piece.strip(b" \t").lower()
            if token:
                tokens.append(token)
    return tokens


def has_expect_100_continue(headers):
    # spec: N-000354 (token matched case-insensitively)
    for value in headers.get_all(b"expect"):
        for piece in value.split(b","):
            if piece.strip(b" \t").lower() == b"100-continue":
                return True
    return False


EVENT_TYPES = (Request, InformationalResponse, Response, Data, EndOfMessage, ConnectionClosed)
