"""Byte conversion, validation rules, and the header list container.

# spec: N-000087–N-000100, N-000104–N-000121, N-000458–N-000471
"""

import re

from ._errors import LocalProtocolError

# RFC 7230 tchar: "!" / "#" / "$" / "%" / "&" / "'" / "*" / "+" / "-" / "." /
# "^" / "_" / "`" / "|" / "~" / DIGIT / ALPHA
_TOKEN_RE = re.compile(rb"[!#$%&'*+\-.^_`|~0-9A-Za-z]+\Z")
_TARGET_RE = re.compile(rb"[\x21-\x7e]+\Z")
_VERSION_RE = re.compile(rb"[0-9]\.[0-9]\Z")
_DIGITS_RE = re.compile(rb"[0-9]+\Z")

# spec: N-000114–N-000119 — "the maximum digit count is a fixed number ...
# from 18 to 32 inclusive" (implementer's choice: 18).
MAX_CONTENT_LENGTH_DIGITS = 18

_OWS = b" \t"

# Bytes permitted inside a header value: tab, printable ASCII, and any
# non-ASCII byte. Everything else (NUL, other C0 controls, CR, LF, FF, VT,
# DEL) is refused. spec: N-000097, N-000098, N-000108
_BAD_VALUE_BYTES = re.compile(rb"[\x00-\x08\x0a-\x1f\x7f]")


def to_bytes(value, what="value"):
    """Accept ASCII str or any bytes-like object; return exact bytes.

    # spec: N-000458, N-000459
    """
    if isinstance(value, bytes):
        return value
    if isinstance(value, str):
        try:
            return value.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("%s must be ASCII text or bytes" % what)
    if isinstance(value, (bytearray, memoryview)):
        return bytes(value)
    raise LocalProtocolError("%s must be ASCII text or bytes-like" % what)


def check_token(name, what="name"):
    # spec: N-000106, N-000110
    if not name or not _TOKEN_RE.match(name):
        raise LocalProtocolError("%s %r is not a valid token" % (what, name))
    return name


def check_method(method):
    # spec: N-000111
    return check_token(method, "method")


def check_target(target):
    # spec: N-000110
    if not target or not _TARGET_RE.match(target):
        raise LocalProtocolError("request target %r is not visible ASCII" % (target,))
    return target


def check_version(version):
    # spec: N-000486–N-000489 (version format: two digits separated by a dot)
    if not _VERSION_RE.match(version):
        raise LocalProtocolError("HTTP version %r is malformed" % (version,))
    return version


def check_value(value):
    """Validate a header value under the FP-01 value rule.

    Space and tab may appear only between other bytes; a value that begins or
    ends with either is refused rather than stripped.

    # spec: N-000097–N-000100, N-000108, N-000109
    """
    if _BAD_VALUE_BYTES.search(value):
        raise LocalProtocolError("header value contains a forbidden byte")
    if value[:1] in (b" ", b"\t") or value[-1:] in (b" ", b"\t"):
        raise LocalProtocolError("header value begins or ends with space or tab")
    return value


def check_reason(reason):
    # Reason phrases follow the same byte rule; no CR/LF/NUL/controls.
    # spec: N-000082, N-000083 (reason stored as a byte string)
    if _BAD_VALUE_BYTES.search(reason):
        raise LocalProtocolError("reason phrase contains a forbidden byte")
    return reason


def normalize_header_pairs(items):
    """Turn caller-supplied (name, value) pairs into validated byte pairs.

    Returns a list of [raw_name, value] lists, with raw names exactly as
    supplied (except that the framing headers are normalized to lowercase).

    # spec: N-000087–N-000090, N-000092–N-000096, N-000104, N-000105
    """
    pairs = []
    try:
        iterator = iter(items)
    except TypeError:
        raise LocalProtocolError("headers must be a sequence of (name, value) pairs")
    for item in iterator:
        try:
            name, value = item
        except (TypeError, ValueError):
            raise LocalProtocolError("each header must be a (name, value) pair")
        name = check_token(to_bytes(name, "header name"), "header name")
        value = check_value(to_bytes(value, "header value"))
        pairs.append([name, value])
    return _normalize_framing(pairs)


def _normalize_framing(pairs):
    # spec: N-000092–N-000096 (Content-Length and Transfer-Encoding normalization)
    cl_positions = [i for i, (n, _) in enumerate(pairs) if n.lower() == b"content-length"]
    te_positions = [i for i, (n, _) in enumerate(pairs) if n.lower() == b"transfer-encoding"]

    if cl_positions:
        values = set()
        for i in cl_positions:
            for piece in pairs[i][1].split(b","):
                piece = piece.strip(_OWS)
                # spec: N-000114–N-000117
                if not _DIGITS_RE.match(piece):
                    raise LocalProtocolError("Content-Length must be a decimal integer")
                if len(piece) > MAX_CONTENT_LENGTH_DIGITS:
                    raise LocalProtocolError("Content-Length has too many digits")
                values.add(int(piece))
        if len(values) != 1:
            raise LocalProtocolError("conflicting Content-Length values")
        canonical = str(values.pop()).encode("ascii")
        first = cl_positions[0]
        keep = []
        for i, pair in enumerate(pairs):
            if i in cl_positions:
                if i == first:
                    keep.append([b"content-length", canonical])
            else:
                keep.append(pair)
        pairs = keep

    if te_positions:
        # spec: N-000120, N-000121, CF-000107 resolved: second header refused
        if len(te_positions) > 1:
            raise LocalProtocolError(
                "a second Transfer-Encoding header is refused", error_status_hint=501
            )
        value = pairs[te_positions[0]][1]
        if value.lower() != b"chunked":
            raise LocalProtocolError(
                "only the chunked transfer coding is supported", error_status_hint=501
            )
        for i, pair in enumerate(pairs):
            if i == te_positions[0]:
                pair[0] = b"transfer-encoding"
                pair[1] = b"chunked"
    return pairs


class Headers(object):
    """Ordered header list.

    Iteration and indexing yield lowercase-name ``(name, value)`` bytes pairs.
    ``raw_items()`` yields the same pairs with names as the caller spelled them.

    # spec: N-000467–N-000471
    """

    __slots__ = ("_raw",)

    def __init__(self, items=()):
        if isinstance(items, Headers):
            self._raw = [tuple(p) for p in items._raw]
        else:
            self._raw = [tuple(p) for p in normalize_header_pairs(items)]

    @classmethod
    def _from_normalized(cls, raw_pairs):
        obj = cls.__new__(cls)
        obj._raw = [tuple(p) for p in raw_pairs]
        return obj

    def __iter__(self):
        for name, value in self._raw:
            yield (name.lower(), value)

    def __getitem__(self, index):
        if isinstance(index, slice):
            return [(n.lower(), v) for n, v in self._raw[index]]
        name, value = self._raw[index]
        return (name.lower(), value)

    def __len__(self):
        return len(self._raw)

    def raw_items(self):
        # spec: N-000469–N-000471
        return list(self._raw)

    def get_all(self, lower_name):
        """All values for a lowercase name, in order (internal helper)."""
        return [v for n, v in self._raw if n.lower() == lower_name]

    def has(self, lower_name):
        return any(n.lower() == lower_name for n, _ in self._raw)

    def __eq__(self, other):
        if isinstance(other, Headers):
            return self._raw == other._raw
        if isinstance(other, (list, tuple)):
            try:
                return list(self) == [tuple(p) for p in other]
            except TypeError:
                return NotImplemented
        return NotImplemented

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    __hash__ = None

    def __repr__(self):
        return "Headers(%r)" % (self._raw,)
