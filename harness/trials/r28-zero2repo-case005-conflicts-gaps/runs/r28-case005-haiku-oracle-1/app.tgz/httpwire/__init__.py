"""httpwire: a pure-Python HTTP/1.1 wire protocol library with no I/O.

Public names are importable from the package root, e.g.
``from httpwire import Connection, Request``.

# spec: N-000433–N-000449 (package-root names)
# Product overview, scope, and packaging constraints (satisfied by design):
# spec: N-000001–N-000009 (library, no network I/O, bytes in and out),
#       N-000022, N-000023 (library surface only, no CLI or config),
#       N-000037–N-000069 (pure Python, zero deps, no I/O, HTTP/1.1 only,
#       non-goals), N-000413–N-000432 (hardware floor, importable library,
#       no exit codes or entry points)
"""

from ._connection import Connection
from ._errors import LocalProtocolError, RemoteProtocolError
from ._events import (
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    Request,
    Response,
)
from ._state import (
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
)

__all__ = [
    "CLIENT",
    "CLOSED",
    "Connection",
    "ConnectionClosed",
    "Data",
    "DONE",
    "EndOfMessage",
    "ERROR",
    "IDLE",
    "InformationalResponse",
    "LocalProtocolError",
    "MIGHT_SWITCH_PROTOCOL",
    "MUST_CLOSE",
    "NEED_DATA",
    "PAUSED",
    "RemoteProtocolError",
    "Request",
    "Response",
    "SEND_BODY",
    "SEND_RESPONSE",
    "SERVER",
    "SWITCHED_PROTOCOL",
]

__version__ = "0.1.0"
