# spec: N-000433 N-000037 (pure python, no I/O, own parser)
import re


# ---------------------------------------------------------------- sentinels
class _Sentinel:
    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return self._name


CLIENT = _Sentinel("CLIENT")
SERVER = _Sentinel("SERVER")
NEED_DATA = _Sentinel("NEED_DATA")
PAUSED = _Sentinel("PAUSED")
IDLE = _Sentinel("IDLE")
SEND_RESPONSE = _Sentinel("SEND_RESPONSE")
SEND_BODY = _Sentinel("SEND_BODY")
DONE = _Sentinel("DONE")
MUST_CLOSE = _Sentinel("MUST_CLOSE")
CLOSED = _Sentinel("CLOSED")
MIGHT_SWITCH_PROTOCOL = _Sentinel("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = _Sentinel("SWITCHED_PROTOCOL")
ERROR = _Sentinel("ERROR")

_SWITCH_UPGRADE = _Sentinel("_SWITCH_UPGRADE")
_SWITCH_CONNECT = _Sentinel("_SWITCH_CONNECT")


# ------------------------------------------------------------------ errors
class ProtocolError(Exception):
    def __init__(self, msg="", error_status_hint=400):
        super().__init__(msg)
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(ProtocolError):
    pass


class RemoteProtocolError(ProtocolError):
    pass


# Limits chosen by the implementer (see NOTES.md)
MAX_CONTENT_LENGTH_DIGITS = 18
MAX_CHUNK_SIZE_DIGITS = 32
DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 16 * 1024

_TOKEN = rb"[-!#$%&'*+.^_`|~0-9A-Za-z]+"
_token_re = re.compile(_TOKEN)
_target_re = re.compile(rb"[\x21-\x7e]+")
_value_re = re.compile(rb"[^\x00\r\n\f\v \t](?:[^\x00\r\n\f\v]*[^\x00\r\n\f\v \t])?")
_version_re = re.compile(rb"[0-9]\.[0-9]")
_request_line_re = re.compile(
    rb"(?P<method>" + _TOKEN + rb") (?P<target>[\x21-\x7e]+) HTTP/(?P<version>[0-9]\.[0-9])")
_status_line_re = re.compile(
    rb"HTTP/(?P<version>[0-9]\.[0-9]) (?P<status>[0-9]{3})(?: (?P<reason>[ \t\x21-\x7e\x80-\xff]*))?")
_header_line_re = re.compile(rb"(?P<name>" + _TOKEN + rb"):[ \t]*(?P<value>.*)", re.S)
_chunk_header_re = re.compile(
    rb"(?P<size>[0-9a-fA-F]{1,%d})(?:[ \t]*;[^\r\n]*)?[ \t]*" % MAX_CHUNK_SIZE_DIGITS)


def _bytesify(x, what="value"):
    if type(x) is bytes:
        return x
    if isinstance(x, (bytearray, memoryview)):
        return bytes(x)
    if isinstance(x, bytes):
        return bytes(x)
    if isinstance(x, str):
        try:
            return x.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("%s must be ASCII" % what)
    try:
        return bytes(memoryview(x))
    except TypeError:
        raise LocalProtocolError("%s must be bytes-like or ASCII str" % what)


# ------------------------------------------------------------------ headers
class Headers(list):
    """Header list: iterates as (lowercase name, value); raw_items() keeps case."""

    def __init__(self, pairs=(), raw=None):
        super().__init__(pairs)
        self._raw = list(raw) if raw is not None else list(self)

    def raw_items(self):
        return list(self._raw)

    def __repr__(self):
        return "Headers(%r)" % (self.raw_items(),)

    def __eq__(self, other):
        if isinstance(other, Headers):
            return list.__eq__(self, other)
        return list.__eq__(self, other)

    __hash__ = None


def _normalize_headers(headers):
    # spec: N-000461 N-000467 N-000468 N-000469 N-000093 N-000094 N-000097
    if headers is None:
        headers = []
    if isinstance(headers, (str, bytes)):
        raise LocalProtocolError("headers must be a sequence of pairs")
    out = []
    raw = []
    saw_cl = None
    saw_te = False
    try:
        items = list(headers.raw_items() if isinstance(headers, Headers) else headers)
    except TypeError:
        raise LocalProtocolError("headers must be a sequence of pairs")
    for item in items:
        try:
            name, value = item
        except (TypeError, ValueError):
            raise LocalProtocolError("header must be a (name, value) pair")
        raw_name = _bytesify(name, "header name")
        value = _bytesify(value, "header value")
        if not _token_re.fullmatch(raw_name):
            raise LocalProtocolError("illegal header name %r" % (raw_name,))
        if value != b"" and not _value_re.fullmatch(value):
            raise LocalProtocolError("illegal header value %r" % (value,))
        lname = raw_name.lower()
        if lname == b"content-length":
            lengths = set()
            for piece in value.split(b","):
                piece = piece.strip(b" \t")
                if not piece or not piece.isdigit():
                    raise LocalProtocolError("bad Content-Length")
                if len(piece) > MAX_CONTENT_LENGTH_DIGITS:
                    raise LocalProtocolError("Content-Length too long")
                lengths.add(int(piece))
            if len(lengths) != 1:
                raise LocalProtocolError("conflicting Content-Length values")
            (length,) = lengths
            if saw_cl is not None:
                if saw_cl != length:
                    raise LocalProtocolError("conflicting Content-Length headers")
                continue
            saw_cl = length
            value = b"%d" % length
        elif lname == b"transfer-encoding":
            if saw_te:
                raise LocalProtocolError("multiple Transfer-Encoding headers", 501)
            saw_te = True
            if value.lower() != b"chunked":
                raise LocalProtocolError("unsupported transfer coding", 501)
            value = b"chunked"
        out.append((lname, value))
        raw.append((raw_name, value))
    return Headers(out, raw)


def _comma_header(headers, name):
    vals = []
    for n, v in headers:
        if n == name:
            for piece in v.split(b","):
                piece = piece.strip().lower()
                if piece:
                    vals.append(piece)
    return vals


class _Event:
    _fields = ()

    def __eq__(self, other):
        return type(self) is type(other) and all(
            getattr(self, f) == getattr(other, f) for f in self._fields)

    __hash__ = None

    def __repr__(self):
        return "%s(%s)" % (type(self).__name__, ", ".join(
            "%s=%r" % (f, getattr(self, f)) for f in self._fields))


def _check_version(v):
    v = _bytesify(v, "http_version")
    if not _version_re.fullmatch(v):
        raise LocalProtocolError("illegal http_version")
    return v


class Request(_Event):
    _fields = ("method", "target", "headers", "http_version")

    def __init__(self, *, method, target, headers, http_version=b"1.1"):
        method = _bytesify(method, "method")
        target = _bytesify(target, "target")
        http_version = _check_version(http_version)
        if not _token_re.fullmatch(method):
            raise LocalProtocolError("illegal method")
        if not _target_re.fullmatch(target):
            raise LocalProtocolError("illegal target")
        headers = _normalize_headers(headers)
        hosts = sum(1 for n, _ in headers if n == b"host")
        if hosts > 1:
            raise LocalProtocolError("multiple Host headers")
        if http_version == b"1.1" and hosts == 0:
            raise LocalProtocolError("missing Host header")
        self.method, self.target = method, target
        self.headers, self.http_version = headers, http_version


class _ResponseBase(_Event):
    _fields = ("status_code", "headers", "http_version", "reason")
    _lo, _hi = 0, 0

    def __init__(self, *, status_code, headers, http_version=b"1.1", reason=b""):
        http_version = _check_version(http_version)
        reason = _bytesify(reason, "reason")
        if isinstance(status_code, bool) or not isinstance(status_code, int):
            raise LocalProtocolError("status_code must be an int")
        status_code = int(status_code)
        if not (self._lo <= status_code < self._hi):
            raise LocalProtocolError("status_code out of range")
        self.status_code = status_code
        self.headers = _normalize_headers(headers)
        self.http_version = http_version
        self.reason = reason


class InformationalResponse(_ResponseBase):
    _lo, _hi = 100, 200


class Response(_ResponseBase):
    _lo, _hi = 200, 1000


class Data(_Event):
    _fields = ("data", "chunk_start", "chunk_end")

    def __init__(self, *, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)


class EndOfMessage(_Event):
    _fields = ("headers",)

    def __init__(self, *, headers=None):
        self.headers = _normalize_headers(headers)


class ConnectionClosed(_Event):
    _fields = ()

    def __init__(self):
        pass


# ----------------------------------------------------------- body framing
def _body_framing(request_method, event):
    if type(event) is Response:
        if (event.status_code in (204, 304) or request_method == b"HEAD"
                or (request_method == b"CONNECT" and 200 <= event.status_code < 300)):
            return ("content-length", 0)
    te = _comma_header(event.headers, b"transfer-encoding")
    if te:
        return ("chunked", None)
    for n, v in event.headers:
        if n == b"content-length":
            return ("content-length", int(v))
    if type(event) is Request:
        return ("content-length", 0)
    return ("http/1.0", None)


def _nbytes(data):
    try:
        return memoryview(data).nbytes
    except TypeError:
        return len(data)


class _CLWriter:
    def __init__(self, n):
        self.left = n

    def data(self, ev, out):
        n = _nbytes(ev.data)
        self.left -= n
        if self.left < 0:
            raise LocalProtocolError("Too much data for declared Content-Length")
        out.append(ev.data)

    def eom(self, ev, out):
        if self.left != 0:
            raise LocalProtocolError("Too little data for declared Content-Length")
        if len(ev.headers):
            raise LocalProtocolError("Content-Length framing cannot carry trailers")


class _ChunkedWriter:
    def data(self, ev, out):
        n = _nbytes(ev.data)
        if n == 0:
            return
        out.append(b"%x\r\n" % n)
        out.append(ev.data)
        out.append(b"\r\n")

    def eom(self, ev, out):
        out.append(b"0\r\n")
        _write_headers(ev.headers, out)
        out.append(b"\r\n")


class _Http10Writer:
    def data(self, ev, out):
        out.append(ev.data)

    def eom(self, ev, out):
        if len(ev.headers):
            raise LocalProtocolError("HTTP/1.0 framing cannot carry trailers")


def _write_headers(headers, out, host_first=False):
    items = headers.raw_items()
    if host_first:
        for i, (n, v) in enumerate(items):
            if n.lower() == b"host":
                items.insert(0, items.pop(i))
                break
    for n, v in items:
        out.append(n + b": " + v + b"\r\n")


def _make_writer(framing):
    kind, n = framing
    if kind == "content-length":
        return _CLWriter(n)
    if kind == "chunked":
        return _ChunkedWriter()
    return _Http10Writer()


# --------------------------------------------------------------- readers
def _extract_lines(buf):
    if buf[:2] == b"\r\n":
        del buf[:2]
        return []
    if buf[:1] == b"\n":
        del buf[:1]
        return []
    m = re.search(rb"\n\r?\n", bytes(buf))
    if not m:
        return None
    block = bytes(buf[:m.start()])
    del buf[:m.end()]
    if block.endswith(b"\r"):
        block = block[:-1]
    return re.split(rb"\r?\n", block)


def _decode_header_lines(lines):
    out = []
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            if not out:
                raise LocalProtocolError("continuation line at start of headers")
            out[-1][1] = out[-1][1] + b" " + line.lstrip(b" \t").rstrip(b" \t")
            continue
        m = _header_line_re.fullmatch(line)
        if not m:
            raise LocalProtocolError("illegal header line %r" % (line,))
        out.append([m.group("name"), m.group("value").strip(b" \t")])
    return [(n, v) for n, v in out]


def _read_request(buf):
    if buf and buf[0] < 0x21:
        raise LocalProtocolError("illegal request line")
    lines = _extract_lines(buf)
    if lines is None:
        return None
    if not lines:
        raise LocalProtocolError("illegal request line")
    m = _request_line_re.fullmatch(lines[0])
    if not m:
        raise LocalProtocolError("illegal request line")
    return Request(method=m.group("method"), target=m.group("target"),
                   headers=_decode_header_lines(lines[1:]),
                   http_version=m.group("version"))


def _read_response(buf):
    if buf and buf[0] < 0x21:
        raise LocalProtocolError("illegal status line")
    lines = _extract_lines(buf)
    if lines is None:
        return None
    if not lines:
        raise LocalProtocolError("illegal status line")
    m = _status_line_re.fullmatch(lines[0])
    if not m:
        raise LocalProtocolError("illegal status line")
    status = int(m.group("status"))
    cls = InformationalResponse if status < 200 else Response
    return cls(status_code=status, headers=_decode_header_lines(lines[1:]),
               http_version=m.group("version"), reason=m.group("reason") or b"")


class _CLReader:
    def __init__(self, n):
        self.total = n
        self.left = n

    def __call__(self, buf):
        if self.left == 0:
            return EndOfMessage()
        if not buf:
            return None
        data = bytes(buf[:self.left])
        del buf[:len(data)]
        self.left -= len(data)
        return Data(data=data)

    def read_eof(self):
        raise RemoteProtocolError(
            "peer closed connection without sending complete message: "
            "received %d bytes, expected %d" % (self.total - self.left, self.total))


class _Http10Reader:
    def __call__(self, buf):
        if not buf:
            return None
        data = bytes(buf)
        del buf[:]
        return Data(data=data)

    def read_eof(self):
        return EndOfMessage()


class _ChunkedReader:
    def __init__(self):
        self.in_chunk = 0
        self.start = True
        self.need_crlf = False
        self.trailer = False

    def __call__(self, buf):
        if self.trailer:
            lines = _extract_lines(buf)
            if lines is None:
                return None
            return EndOfMessage(headers=_decode_header_lines(lines))
        if self.need_crlf:
            if len(buf) < 2:
                if buf and bytes(buf) != b"\r"[:len(buf)]:
                    raise LocalProtocolError("bad chunk terminator")
                return None
            if bytes(buf[:2]) != b"\r\n":
                raise LocalProtocolError("bad chunk terminator")
            del buf[:2]
            self.need_crlf = False
        if self.in_chunk == 0:
            i = bytes(buf).find(b"\r\n")
            if i < 0:
                return None
            line = bytes(buf[:i])
            m = _chunk_header_re.fullmatch(line)
            if not m:
                raise LocalProtocolError("illegal chunk header %r" % (line,))
            del buf[:i + 2]
            size = int(m.group("size"), 16)
            if size == 0:
                self.trailer = True
                return self(buf)
            self.in_chunk = size
            self.start = True
        if not buf:
            return None
        data = bytes(buf[:self.in_chunk])
        del buf[:len(data)]
        self.in_chunk -= len(data)
        ev = Data(data=data, chunk_start=self.start, chunk_end=self.in_chunk == 0)
        self.start = False
        if self.in_chunk == 0:
            self.need_crlf = True
        return ev

    def read_eof(self):
        raise RemoteProtocolError("peer closed connection in the middle of a chunked body")


def _expect_nothing(buf):
    if buf:
        raise LocalProtocolError("Got data when expecting EOF")
    return None


def _make_reader(framing):
    kind, n = framing
    if kind == "content-length":
        return _CLReader(n)
    if kind == "chunked":
        return _ChunkedReader()
    return _Http10Reader()


# ------------------------------------------------------------ connection
def _other(role):
    return SERVER if role is CLIENT else CLIENT


class Connection:
    def __init__(self, role, max_incomplete_event_size=DEFAULT_MAX_INCOMPLETE_EVENT_SIZE):
        # spec: N-000476 N-000477 N-000479 N-000480
        if role is not CLIENT and role is not SERVER:
            raise ValueError("role must be CLIENT or SERVER")
        self.our_role = role
        self.their_role = _other(role)
        self._max_size = max_incomplete_event_size
        self._states = {CLIENT: IDLE, SERVER: IDLE}
        self._keep_alive = True
        self._pending = set()
        self._buf = bytearray()
        self._closed = False
        self._request_method = None
        self.their_http_version = None
        self.client_is_waiting_for_100_continue = False
        self._body_reader = None
        self._body_writer = None

    # --- attributes
    @property
    def states(self):
        return dict(self._states)

    @property
    def our_state(self):
        return self._states[self.our_role]

    @property
    def their_state(self):
        return self._states[self.their_role]

    @property
    def they_are_waiting_for_100_continue(self):
        return bool(self.their_role is CLIENT and self.client_is_waiting_for_100_continue)

    @property
    def trailing_data(self):
        return (bytes(self._buf), self._closed)

    # --- state machine
    def _settle(self):
        st = self._states
        while True:
            before = dict(st)
            if self._pending and st[CLIENT] is DONE:
                st[CLIENT] = MIGHT_SWITCH_PROTOCOL
            if not self._pending and st[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                st[CLIENT] = DONE
            if not self._keep_alive:
                for r in (CLIENT, SERVER):
                    if st[r] is DONE:
                        st[r] = MUST_CLOSE
            for r in (CLIENT, SERVER):
                o = _other(r)
                if st[r] is CLOSED and st[o] in (IDLE, DONE):
                    st[o] = MUST_CLOSE
                if st[r] is ERROR and st[o] is DONE:
                    st[o] = MUST_CLOSE
            if st == before:
                return

    def _process_error(self, role):
        self._states[role] = ERROR
        self._keep_alive = False
        self._settle()

    def _process_event(self, role, event):
        # spec: FP-04 FP-06 FP-07 state machine
        et = type(event)
        st = self._states
        cur = st[role]
        switch = None
        if role is SERVER:
            if et is InformationalResponse and event.status_code == 101 \
                    and _SWITCH_UPGRADE in self._pending:
                switch = _SWITCH_UPGRADE
            elif et is Response and 200 <= event.status_code < 300 \
                    and _SWITCH_CONNECT in self._pending:
                switch = _SWITCH_CONNECT
        new = None
        if et is ConnectionClosed:
            if cur in (IDLE, DONE, MUST_CLOSE, CLOSED):
                new = CLOSED
        elif cur is SEND_BODY and et in (Data, EndOfMessage):
            new = SEND_BODY if et is Data else DONE
        elif role is CLIENT and cur is IDLE and et is Request:
            new = SEND_BODY
        elif role is SERVER and cur is IDLE and et is Response:
            new = SEND_BODY
        elif role is SERVER and cur is SEND_RESPONSE and et in (InformationalResponse, Response):
            new = SEND_BODY if et is Response else SEND_RESPONSE
            if switch is not None:
                new = SWITCHED_PROTOCOL
        if new is None:
            raise LocalProtocolError("can't handle event type %s when role=%r and state=%r"
                                     % (et.__name__, role, cur))
        st[role] = new

        # bookkeeping
        if et is Request:
            self._request_method = event.method
            if role is CLIENT:
                if event.method == b"CONNECT":
                    self._pending.add(_SWITCH_CONNECT)
                if _comma_header(event.headers, b"upgrade"):
                    self._pending.add(_SWITCH_UPGRADE)
            if event.http_version == b"1.1" and \
                    b"100-continue" in _comma_header(event.headers, b"expect"):
                self.client_is_waiting_for_100_continue = True
            if st[SERVER] is IDLE:
                st[SERVER] = SEND_RESPONSE
        if role is self.their_role and et in (Request, Response, InformationalResponse):
            self.their_http_version = event.http_version
        if et in (Request, Response):
            if event.http_version < b"1.1" or b"close" in _comma_header(event.headers, b"connection"):
                self._keep_alive = False
        if role is SERVER and et in (InformationalResponse, Response):
            self.client_is_waiting_for_100_continue = False
        if role is CLIENT and et in (Data, EndOfMessage):
            self.client_is_waiting_for_100_continue = False
        if role is SERVER and et is Response:
            if switch is None:
                self._pending.clear()
        if switch is not None:
            self._pending.clear()
            st[CLIENT] = SWITCHED_PROTOCOL
            st[SERVER] = SWITCHED_PROTOCOL

        # framing
        if et in (Request, Response):
            framing = _body_framing(self._request_method if et is Response else None, event)
            if et is Response and framing[0] == "http/1.0":
                self._keep_alive = False
            if role is self.our_role:
                self._body_writer = _make_writer(framing)
            else:
                self._body_reader = _make_reader(framing)
        self._settle()

    # --- sending
    def _clean_up_response(self, response):
        method = self._request_method
        if method == b"HEAD":
            method = b"GET"
        framing = _body_framing(method, response)[0]
        raw = response.headers.raw_items()
        need_close = False
        if framing in ("chunked", "http/1.0"):
            raw = [(n, v) for n, v in raw
                   if n.lower() not in (b"content-length", b"transfer-encoding")]
            if self.their_http_version is None or self.their_http_version < b"1.1":
                need_close = True
            else:
                raw.append((b"transfer-encoding", b"chunked"))
        if need_close:
            self._keep_alive = False
        if not self._keep_alive:
            toks = set()
            for n, v in raw:
                if n.lower() == b"connection":
                    toks.update(p.strip().lower() for p in v.split(b",") if p.strip())
            toks.discard(b"keep-alive")
            toks.add(b"close")
            raw = [(n, v) for n, v in raw if n.lower() != b"connection"]
            raw.append((b"connection", b", ".join(sorted(toks))))
        return Response(status_code=response.status_code, headers=raw,
                        http_version=response.http_version, reason=response.reason)

    def send(self, event):
        pieces = self.send_with_data_passthrough(event)
        return b"".join(bytes(p) for p in pieces)

    def send_with_data_passthrough(self, event):
        if self.our_state is ERROR:
            raise LocalProtocolError("Can't send data when our state is ERROR")
        try:
            et = type(event)
            if et is Response:
                event = self._clean_up_response(event)
            if et not in (Request, InformationalResponse, Response, Data,
                          EndOfMessage, ConnectionClosed):
                raise LocalProtocolError("not an event: %r" % (event,))
            self._process_event(self.our_role, event)
            out = []
            if et is Request:
                if event.http_version != b"1.1":
                    raise LocalProtocolError("I only send HTTP/1.1")
                out.append(event.method + b" " + event.target + b" HTTP/1.1\r\n")
                _write_headers(event.headers, out, host_first=True)
                out.append(b"\r\n")
            elif et in (InformationalResponse, Response):
                if event.http_version != b"1.1":
                    raise LocalProtocolError("I only send HTTP/1.1")
                out.append(b"HTTP/1.1 %d %s\r\n" % (event.status_code, event.reason))
                _write_headers(event.headers, out)
                out.append(b"\r\n")
            elif et is Data:
                self._body_writer.data(event, out)
            elif et is EndOfMessage:
                self._body_writer.eom(event, out)
            return [p if isinstance(p, (bytes, bytearray, memoryview)) or et is Data
                    else bytes(p) for p in out]
        except BaseException as exc:
            self._process_error(self.our_role)
            if isinstance(exc, ProtocolError):
                raise
            raise

    def send_failed(self):
        self._process_error(self.our_role)

    # --- receiving
    def receive_data(self, data):
        if data:
            if self._closed:
                raise RuntimeError("received close, then received more data?")
            self._buf += data
        else:
            self._closed = True

    def _reader(self):
        s = self.their_state
        if s is IDLE and self.their_role is CLIENT:
            return _read_request
        if self.their_role is SERVER and s in (IDLE, SEND_RESPONSE):
            return _read_response
        if s is SEND_BODY:
            return self._body_reader
        return _expect_nothing

    def _extract(self):
        s = self.their_state
        if s is DONE and len(self._buf) > 0:
            return PAUSED
        if s is MIGHT_SWITCH_PROTOCOL or s is SWITCHED_PROTOCOL:
            return PAUSED
        reader = self._reader()
        ev = reader(self._buf)
        if ev is None:
            if not self._buf and self._closed:
                if hasattr(reader, "read_eof"):
                    ev = reader.read_eof()
                else:
                    ev = ConnectionClosed()
        if ev is None:
            ev = NEED_DATA
        return ev

    def next_event(self):
        if self.their_state is ERROR:
            raise RemoteProtocolError("Can't receive data when peer state is ERROR")
        try:
            ev = self._extract()
            if ev is not NEED_DATA and ev is not PAUSED:
                self._process_event(self.their_role, ev)
            if ev is NEED_DATA:
                if len(self._buf) > self._max_size:
                    raise RemoteProtocolError("Receive buffer too long", 431)
                if self._closed:
                    raise RemoteProtocolError("peer unexpectedly closed connection")
            return ev
        except BaseException as exc:
            self._process_error(self.their_role)
            if isinstance(exc, LocalProtocolError):
                raise RemoteProtocolError(str(exc), exc.error_status_hint) from exc
            raise

    def start_next_cycle(self):
        if self._states[CLIENT] is not DONE or self._states[SERVER] is not DONE:
            raise LocalProtocolError(
                "not in a reusable state: states=%r" % (self._states,))
        self._states = {CLIENT: IDLE, SERVER: IDLE}
        self._pending.clear()
        self._request_method = None
        self.their_http_version = None
        self.client_is_waiting_for_100_continue = False
        self._body_reader = None
        self._body_writer = None
        self._settle()
