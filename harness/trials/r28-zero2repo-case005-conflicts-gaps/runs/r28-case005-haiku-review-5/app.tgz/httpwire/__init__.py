"""httpwire: a pure-Python HTTP/1.1 wire protocol library (RFC 7230 + Expect).

The library performs no I/O. Integrators move bytes themselves and use
``Connection`` to turn events into bytes and bytes into events.
"""

from ._sentinels import (
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
)
from ._errors import LocalProtocolError, RemoteProtocolError
from ._events import (
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    Request,
    Response,
)
from ._connection import Connection

__version__ = "0.1.0"

__all__ = [
    "CLIENT",
    "CLOSED",
    "Connection",
    "ConnectionClosed",
    "Data",
    "DONE",
    "EndOfMessage",
    "ERROR",
    "IDLE",
    "InformationalResponse",
    "LocalProtocolError",
    "MIGHT_SWITCH_PROTOCOL",
    "MUST_CLOSE",
    "NEED_DATA",
    "PAUSED",
    "RemoteProtocolError",
    "Request",
    "Response",
    "SEND_BODY",
    "SEND_RESPONSE",
    "SERVER",
    "SWITCHED_PROTOCOL",
]
