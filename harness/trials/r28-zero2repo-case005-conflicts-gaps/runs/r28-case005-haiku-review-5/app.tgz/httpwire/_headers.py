"""Header list normalization and shared byte-level validation."""

import re

from ._errors import LocalProtocolError

# Decided in NOTES.md (conflict 1): 18 digits is the PRD's minimum allowed maximum.
MAX_CONTENT_LENGTH_DIGITS = 18

_TOKEN_RE = re.compile(rb"[!#$%&'*+\-.^_`|~0-9A-Za-z]+")
_TARGET_RE = re.compile(rb"[\x21-\x7e]+")
_VERSION_RE = re.compile(rb"[0-9]\.[0-9]")
# Control bytes other than horizontal tab, plus DEL.
_BAD_VALUE_BYTE_RE = re.compile(rb"[\x00-\x08\x0a-\x1f\x7f]")
_BAD_REASON_BYTE_RE = re.compile(rb"[\x00-\x08\x0a-\x1f\x7f]")


def is_token(value):
    return _TOKEN_RE.fullmatch(value) is not None


def is_target(value):
    return _TARGET_RE.fullmatch(value) is not None


def is_version(value):
    return _VERSION_RE.fullmatch(value) is not None


def to_bytes(value, what, err_cls):
    """Convert ASCII text or a bytes-like object to ``bytes``."""
    if isinstance(value, bytes):
        return value
    if isinstance(value, str):
        try:
            return value.encode("ascii")
        except UnicodeEncodeError:
            raise err_cls("%s must be ASCII text" % what)
    if isinstance(value, (bytearray, memoryview)):
        return bytes(value)
    raise err_cls("%s must be text or a bytes-like object" % what)


def check_field_value(value, err_cls):
    if _BAD_VALUE_BYTE_RE.search(value):
        raise err_cls("header value contains a forbidden control byte")
    if value[:1] in (b" ", b"\t") or value[-1:] in (b" ", b"\t"):
        raise err_cls("header value begins or ends with space or tab")


def check_reason(value, err_cls):
    if _BAD_REASON_BYTE_RE.search(value):
        raise err_cls("reason phrase contains a forbidden control byte")


class Headers:
    """An ordered header list.

    Iteration and indexing give the ordinary view: ``(lowercase name, value)``.
    ``raw_items()`` gives ``(name as spelled by the caller, value)``.
    """

    __slots__ = ("_raw",)

    def __init__(self, raw_pairs=()):
        self._raw = tuple((name, value) for name, value in raw_pairs)

    def _ordinary(self):
        return [(name.lower(), value) for name, value in self._raw]

    def raw_items(self):
        return list(self._raw)

    def __iter__(self):
        return iter(self._ordinary())

    def __len__(self):
        return len(self._raw)

    def __getitem__(self, index):
        return self._ordinary()[index]

    def __eq__(self, other):
        if isinstance(other, Headers):
            other = other._ordinary()
        try:
            other_list = [tuple(pair) for pair in other]
        except TypeError:
            return NotImplemented
        return self._ordinary() == other_list

    __hash__ = None

    def __repr__(self):
        return "Headers(%r)" % (self._ordinary(),)


def build_headers(pairs, err_cls):
    """Validate and normalize a header list, returning a ``Headers``."""
    if isinstance(pairs, Headers):
        pairs = pairs.raw_items()
    try:
        pairs = list(pairs)
    except TypeError:
        raise err_cls("headers must be a sequence of (name, value) pairs")

    items = []
    te_count = 0
    for pair in pairs:
        try:
            name, value = pair
        except (TypeError, ValueError):
            raise err_cls("each header must be a (name, value) pair")
        raw_name = to_bytes(name, "header name", err_cls)
        value_b = to_bytes(value, "header value", err_cls)
        if not is_token(raw_name):
            raise err_cls("invalid header name %r" % (raw_name,))
        if raw_name.lower() == b"transfer-encoding":
            te_count += 1
            if te_count > 1:
                raise err_cls("multiple Transfer-Encoding headers", 501)
            if value_b.lower() != b"chunked":
                raise err_cls("unsupported Transfer-Encoding", 501)
            value_b = b"chunked"
        check_field_value(value_b, err_cls)
        items.append([raw_name, value_b])

    out = []
    cl_index = None
    cl_values = []
    for raw_name, value in items:
        if raw_name.lower() == b"content-length":
            pieces = [p.strip(b" \t") for p in value.split(b",")]
            pieces = [p for p in pieces if p]
            if not pieces:
                raise err_cls("invalid Content-Length")
            for piece in pieces:
                if not piece.isdigit() or len(piece) > MAX_CONTENT_LENGTH_DIGITS:
                    raise err_cls("invalid Content-Length")
                cl_values.append(piece)
            if cl_index is None:
                cl_index = len(out)
                out.append([raw_name, None])
            continue
        out.append([raw_name, value])

    if cl_index is not None:
        if len(set(int(p) for p in cl_values)) != 1:
            raise err_cls("conflicting Content-Length values")
        out[cl_index][1] = cl_values[0]

    return Headers(tuple((name, value) for name, value in out))


def find_header(pairs, lname):
    """Return the first value whose name (lowercased) equals ``lname``, or None."""
    for name, value in pairs:
        if name.lower() == lname:
            return value
    return None


def has_token(pairs, lname, token):
    """True if any header named ``lname`` lists ``token`` as a list element."""
    for name, value in pairs:
        if name.lower() == lname:
            for part in value.split(b","):
                if part.strip(b" \t").lower() == token:
                    return True
    return False
