"""The bring-your-own-I/O HTTP/1.1 connection state machine (FP-02..FP-07)."""

import re

from ._errors import LocalProtocolError, RemoteProtocolError
from ._events import (
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    Request,
    Response,
)
from ._headers import find_header, has_token
from ._sentinels import (
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
)

# Decided in NOTES.md (conflict 2): the PRD's default lies in [14 KiB, 18 KiB).
DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 16 * 1024
# Decided in NOTES.md (conflict 3): the PRD's accepted range is 16..32 digits.
MAX_CHUNK_SIZE_DIGITS = 32

_REQUEST_LINE_RE = re.compile(
    rb"([!#$%&'*+\-.^_`|~0-9A-Za-z]+) ([\x21-\x7e]+) HTTP/([0-9])\.([0-9])"
)
_STATUS_LINE_RE = re.compile(rb"HTTP/([0-9])\.([0-9]) ([0-9]{3})(?: (.*))?", re.DOTALL)
_CHUNK_SIZE_RE = re.compile(
    rb"([0-9A-Fa-f]{1,%d})[ \t]*(?:;.*)?" % MAX_CHUNK_SIZE_DIGITS, re.DOTALL
)

_EVENT_TYPES = (
    Request,
    InformationalResponse,
    Response,
    Data,
    EndOfMessage,
    ConnectionClosed,
)

# Outcomes of a switch proposal.
_ACCEPT = "accept"
_DENY = "deny"


class _Body:
    """Framing state for one message body.

    Reader modes: "length", "chunked", "close".
    Writer modes: "length", "chunked", "close", "none" (no body bytes allowed).
    """

    __slots__ = ("mode", "remaining", "phase", "fresh")

    def __init__(self, mode, remaining=0):
        self.mode = mode
        self.remaining = remaining
        self.phase = "size"
        self.fresh = True


class _StateMap(dict):
    """Mapping keyed by CLIENT/SERVER; also compares equal to a 2-item sequence."""

    def __getitem__(self, key):
        if isinstance(key, int) and not isinstance(key, bool):
            return (dict.__getitem__(self, CLIENT), dict.__getitem__(self, SERVER))[key]
        return dict.__getitem__(self, key)

    def __eq__(self, other):
        if isinstance(other, (tuple, list)):
            return (
                len(other) == 2
                and other[0] == dict.__getitem__(self, CLIENT)
                and other[1] == dict.__getitem__(self, SERVER)
            )
        return dict.__eq__(self, other)

    __hash__ = None


def _request_body(pairs):
    cl = find_header(pairs, b"content-length")
    if cl is not None:
        return _Body("length", int(cl.decode("ascii")))
    if find_header(pairs, b"transfer-encoding") is not None:
        return _Body("chunked")
    return _Body("length", 0)


def _response_body(method, status, pairs):
    if method == b"HEAD" or status in (204, 304):
        return _Body("length", 0)
    cl = find_header(pairs, b"content-length")
    if cl is not None:
        return _Body("length", int(cl.decode("ascii")))
    if find_header(pairs, b"transfer-encoding") is not None:
        return _Body("chunked")
    return _Body("close")


def _encode_fields(pairs):
    return b"".join(name + b": " + value + b"\r\n" for name, value in pairs)


def _rewrite_connection(pairs):
    """Make the Connection header say ``close`` and drop ``keep-alive``."""
    tokens = []
    out = []
    slot = None
    for name, value in pairs:
        if name.lower() == b"connection":
            if slot is None:
                slot = len(out)
                out.append(None)
            for part in value.split(b","):
                tok = part.strip(b" \t")
                if tok and tok.lower() != b"keep-alive":
                    if tok.lower() not in [t.lower() for t in tokens]:
                        tokens.append(tok)
        else:
            out.append((name, value))
    if not any(t.lower() == b"close" for t in tokens):
        tokens.append(b"close")
    connection = (b"Connection", b", ".join(tokens))
    if slot is None:
        out.append(connection)
    else:
        out[slot] = connection
    return out


def _split_head(buf):
    """Return (header lines, bytes consumed) once a blank line is buffered, else None."""
    lines = []
    pos = 0
    while True:
        nl = buf.find(b"\n", pos)
        if nl < 0:
            return None
        line = bytes(buf[pos:nl])
        if line.endswith(b"\r"):
            line = line[:-1]
        pos = nl + 1
        if not line:
            return lines, pos
        lines.append(line)


def _parse_field_lines(lines):
    """Parse header lines, joining obsolete line folds. Raises LocalProtocolError."""
    pairs = []
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            if not pairs:
                raise LocalProtocolError("continuation line without a header")
            name, value = pairs[-1]
            cont = line.strip(b" \t")
            joined = b" ".join(part for part in (value, cont) if part)
            pairs[-1] = (name, joined)
            continue
        colon = line.find(b":")
        if colon <= 0:
            raise LocalProtocolError("malformed header line")
        pairs.append((line[:colon], line[colon + 1:].strip(b" \t")))
    return pairs


class Connection:
    """One HTTP/1.1 connection in the CLIENT or SERVER role. Performs no I/O."""

    def __init__(self, role, max_incomplete_event_size=DEFAULT_MAX_INCOMPLETE_EVENT_SIZE):
        if role is not CLIENT and role is not SERVER:
            raise ValueError("role must be CLIENT or SERVER")
        if max_incomplete_event_size is None:
            max_incomplete_event_size = DEFAULT_MAX_INCOMPLETE_EVENT_SIZE
        self.our_role = role
        self.their_role = SERVER if role is CLIENT else CLIENT
        self._max_incomplete = int(max_incomplete_event_size)
        self._states = {CLIENT: IDLE, SERVER: IDLE}
        self._buffer = bytearray()
        self._peer_closed = False
        self._their_version = None
        self._their_error = None
        self._reader = None
        self._writer = None
        self._reset_cycle()

    def _reset_cycle(self):
        self._cycle_method = None
        self._request_version = None
        self._request_close = False
        self._response_version = None
        self._response_close = False
        self._proposal_connect = False
        self._proposal_upgrade = False
        self._client_waiting = False
        self._reader = None
        self._writer = None

    # ----------------------------------------------------------------- queries

    @property
    def our_state(self):
        return self._states[self.our_role]

    @property
    def their_state(self):
        return self._states[self.their_role]

    @property
    def states(self):
        return _StateMap(self._states)

    @property
    def their_http_version(self):
        return self._their_version

    @property
    def client_is_waiting_for_100_continue(self):
        return bool(self._client_waiting)

    @property
    def they_are_waiting_for_100_continue(self):
        return bool(self._client_waiting) and self.our_role is SERVER

    @property
    def trailing_data(self):
        return (bytes(self._buffer), bool(self._peer_closed))

    # ------------------------------------------------------------------- send

    def send(self, event):
        pieces = self._send(event, passthrough=False)
        return b"".join(pieces)

    def send_with_data_passthrough(self, event):
        return self._send(event, passthrough=True)

    def _send(self, event, passthrough):
        try:
            pieces, commit = self._prepare_send(event, passthrough)
        except LocalProtocolError:
            self._states[self.our_role] = ERROR
            self._fire_triggered()
            raise
        commit()
        return pieces

    def _prepare_send(self, event, passthrough):
        role = self.our_role

        if not isinstance(event, _EVENT_TYPES):
            raise TypeError("send() expects an HTTP event, got %r" % (event,))

        if isinstance(event, Request):
            if role is not CLIENT:
                raise LocalProtocolError("a server cannot send a request")
            if event.http_version != b"1.1":
                raise LocalProtocolError("only HTTP/1.1 requests can be sent")
            new = self._legal_next(role, event)
            if new is None:
                raise LocalProtocolError(
                    "cannot send a request in state %r" % (self._states[role],)
                )
            pieces = [self._request_head(event)]
            writer = _request_body(event.headers)

            def commit():
                self._writer = writer
                self._commit(role, event, new, is_their=False)

            return pieces, commit

        if isinstance(event, (InformationalResponse, Response)):
            if role is not SERVER:
                raise LocalProtocolError("a client cannot send a response")
            if event.http_version != b"1.1":
                raise LocalProtocolError("only HTTP/1.1 responses can be sent")
            new = self._legal_next(role, event)
            if new is None:
                raise LocalProtocolError(
                    "cannot send a response in state %r" % (self._states[role],)
                )
            outcome = self._switch_outcome(event)
            final = isinstance(event, Response)
            writer = None
            if final and new is not SWITCHED_PROTOCOL:
                pairs, writer, close = self._final_response_wire(event)
            elif final:
                pairs = event.headers.raw_items()
                writer = _Body("none")
                close = has_token(pairs, b"connection", b"close")
            else:
                pairs = event.headers.raw_items()
                close = False
            head = self._status_line(event) + _encode_fields(pairs) + b"\r\n"

            def commit():
                if writer is not None:
                    self._writer = writer
                self._commit(role, event, new, is_their=False, outcome=outcome, close=close)

            return [head], commit

        if isinstance(event, Data):
            if self._states[role] is not SEND_BODY:
                raise LocalProtocolError("cannot send data in state %r" % (self._states[role],))
            pieces, consumed = self._encode_data(event, passthrough)
            writer = self._writer

            def commit():
                if writer.mode == "length":
                    writer.remaining -= consumed
                self._commit(role, event, SEND_BODY, is_their=False)

            return pieces, commit

        if isinstance(event, EndOfMessage):
            new = self._legal_next(role, event)
            if new is None:
                raise LocalProtocolError("cannot end a message in state %r" % (self._states[role],))
            writer = self._writer
            trailers = event.headers.raw_items()
            body = b""
            if writer.mode == "chunked":
                if trailers and self._their_version == b"1.0":
                    raise LocalProtocolError("trailers cannot be sent to an HTTP/1.0 peer")
                body = b"0\r\n" + _encode_fields(trailers) + b"\r\n"
            elif writer.mode == "length":
                if writer.remaining != 0:
                    raise LocalProtocolError("body is shorter than Content-Length")
                if trailers:
                    raise LocalProtocolError("trailers are not allowed with Content-Length")
            else:
                if trailers:
                    raise LocalProtocolError("trailers are not allowed without chunked framing")

            def commit():
                self._commit(role, event, new, is_their=False)

            return ([body] if body else []), commit

        # ConnectionClosed
        new = self._legal_next(role, event)
        if new is None:
            raise LocalProtocolError("cannot send connection-closed in state %r" % (self._states[role],))

        def commit():
            self._commit(role, event, new, is_their=False)

        return [], commit

    def _encode_data(self, event, passthrough):
        payload = event.data
        writer = self._writer
        if isinstance(payload, str):
            raise LocalProtocolError("data must be bytes-like")
        try:
            n = memoryview(payload).nbytes
            piece = payload
        except TypeError:
            if not hasattr(payload, "__len__"):
                raise LocalProtocolError("data must be bytes-like")
            if not passthrough:
                raise TypeError("send() needs bytes-like data; use send_with_data_passthrough()")
            n = len(payload)
            piece = payload

        if writer.mode == "none":
            if n:
                raise LocalProtocolError("this message has no body")
            return [], 0
        if writer.mode == "length":
            if n > writer.remaining:
                raise LocalProtocolError("body exceeds Content-Length")
            return ([piece] if n else []), n
        if writer.mode == "chunked":
            if n == 0:
                return [], 0
            return [b"%x\r\n" % n, piece, b"\r\n"], n
        # close-delimited
        return ([piece] if n else []), n

    def _request_head(self, event):
        pairs = event.headers.raw_items()
        hosts = [p for p in pairs if p[0].lower() == b"host"]
        others = [p for p in pairs if p[0].lower() != b"host"]
        line = event.method + b" " + event.target + b" HTTP/1.1\r\n"
        return line + _encode_fields(hosts + others) + b"\r\n"

    def _status_line(self, event):
        return b"HTTP/1.1 " + str(event.status_code).encode("ascii") + b" " + event.reason + b"\r\n"

    def _final_response_wire(self, event):
        """Decide framing, header adjustments, and close for a final response we send."""
        pairs = event.headers.raw_items()
        method = self._cycle_method
        code = event.status_code
        peer = self._their_version
        is_head = method == b"HEAD"
        cl = find_header(pairs, b"content-length")
        has_te = find_header(pairs, b"transfer-encoding") is not None
        forced_close = False

        if cl is not None and not has_te:
            # Content-Length framing, header kept on the wire.
            if is_head or code in (204, 304):
                writer = _Body("none")
            else:
                writer = _Body("length", int(cl.decode("ascii")))
        elif code in (204, 304):
            writer = _Body("none")
        else:
            # Unknown body length: chunked for an HTTP/1.1 peer, else close-delimited.
            pairs = [p for p in pairs if p[0].lower() not in (b"content-length", b"transfer-encoding")]
            if peer == b"1.1":
                pairs = pairs + [(b"Transfer-Encoding", b"chunked")]
                writer = _Body("none") if is_head else _Body("chunked")
            else:
                forced_close = True
                writer = _Body("none") if is_head else _Body("close")

        disabled = (
            forced_close
            or self._request_version != b"1.1"
            or self._request_close
            or has_token(pairs, b"connection", b"close")
        )
        if disabled:
            pairs = _rewrite_connection(pairs)
        return pairs, writer, disabled

    # ------------------------------------------------------------ transitions

    def _proposal_any(self):
        return self._proposal_connect or self._proposal_upgrade

    def _switch_outcome(self, event):
        if isinstance(event, InformationalResponse):
            if event.status_code == 101 and self._proposal_upgrade:
                return _ACCEPT
            return None
        if self._proposal_connect and event.status_code == 200:
            return _ACCEPT
        if self._proposal_connect or self._proposal_upgrade:
            return _DENY
        return None

    def _legal_next(self, role, event):
        """New state for ``role`` after ``event`` (sent or pulled), or None if illegal."""
        cur = self._states[role]
        if isinstance(event, Request):
            return SEND_BODY if (role is CLIENT and cur is IDLE) else None
        if isinstance(event, InformationalResponse):
            if role is not SERVER or cur is not SEND_RESPONSE:
                return None
            if self._switch_outcome(event) == _ACCEPT:
                return SWITCHED_PROTOCOL
            return SEND_RESPONSE
        if isinstance(event, Response):
            if role is not SERVER or (cur is not IDLE and cur is not SEND_RESPONSE):
                return None
            if self._switch_outcome(event) == _ACCEPT:
                return SWITCHED_PROTOCOL
            return SEND_BODY
        if isinstance(event, Data):
            return SEND_BODY if cur is SEND_BODY else None
        if isinstance(event, EndOfMessage):
            if cur is not SEND_BODY:
                return None
            if role is CLIENT and self._proposal_any():
                return MIGHT_SWITCH_PROTOCOL
            return DONE
        if isinstance(event, ConnectionClosed):
            if cur is IDLE or cur is DONE or cur is MUST_CLOSE:
                return CLOSED
            return None
        return None

    def _commit(self, role, event, new, is_their, outcome=None, close=False):
        if isinstance(event, Request):
            self._record_request(event, is_their)
        elif isinstance(event, (InformationalResponse, Response)):
            self._record_response(event, is_their, outcome, close)
        if new is SWITCHED_PROTOCOL:
            self._states[CLIENT] = SWITCHED_PROTOCOL
            self._states[SERVER] = SWITCHED_PROTOCOL
        else:
            self._states[role] = new
        if isinstance(event, Request) and self._states[SERVER] is IDLE:
            self._states[SERVER] = SEND_RESPONSE
        self._fire_triggered()

    def _record_request(self, event, is_their):
        self._cycle_method = event.method
        self._request_version = event.http_version
        self._request_close = has_token(event.headers, b"connection", b"close")
        if event.method == b"CONNECT":
            self._proposal_connect = True
        if find_header(event.headers, b"upgrade") is not None:
            self._proposal_upgrade = True
        if event.http_version == b"1.1" and has_token(event.headers, b"expect", b"100-continue"):
            self._client_waiting = True
        if is_their:
            self._their_version = event.http_version

    def _record_response(self, event, is_their, outcome, close):
        self._client_waiting = False
        if isinstance(event, Response):
            self._response_version = event.http_version
            self._response_close = close
            if is_their:
                self._their_version = event.http_version
        if outcome == _DENY:
            self._proposal_connect = False
            self._proposal_upgrade = False
            if self._states[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                self._states[CLIENT] = DONE

    def _keep_alive(self):
        if self._request_version != b"1.1":
            return False
        if self._response_version is not None and self._response_version != b"1.1":
            return False
        if self._request_close or self._response_close:
            return False
        return True

    def _switched(self):
        return self._states[CLIENT] is SWITCHED_PROTOCOL or self._states[SERVER] is SWITCHED_PROTOCOL

    def _fire_triggered(self):
        changed = True
        while changed:
            changed = False
            for me, other in ((CLIENT, SERVER), (SERVER, CLIENT)):
                if self._states[me] is CLOSED and self._states[other] in (IDLE, DONE):
                    self._states[other] = MUST_CLOSE
                    changed = True
                if self._states[me] is ERROR and self._states[other] is DONE:
                    self._states[other] = MUST_CLOSE
                    changed = True
            if not self._keep_alive():
                for role in (CLIENT, SERVER):
                    if self._states[role] is DONE:
                        self._states[role] = MUST_CLOSE
                        changed = True

    # ----------------------------------------------------------------- receive

    def receive_data(self, data):
        chunk = bytes(memoryview(data))
        if not chunk:
            self._peer_closed = True
            return None
        if self._peer_closed and not self._switched():
            raise RuntimeError("cannot receive data after the peer closed its side")
        self._buffer += chunk
        return None

    def next_event(self):
        if self._their_error is not None:
            raise RemoteProtocolError(str(self._their_error), self._their_error.error_status_hint)
        if self._switched():
            return PAUSED
        their = self._states[self.their_role]
        if their is MIGHT_SWITCH_PROTOCOL:
            return PAUSED
        if their is CLOSED:
            return ConnectionClosed()
        if their is DONE or their is MUST_CLOSE:
            if self._buffer:
                return PAUSED
            if self._peer_closed:
                return self._deliver(ConnectionClosed())
            return NEED_DATA

        if self._reader is not None:
            event = self._read_body()
            if event is None:
                if self._peer_closed:
                    raise self._remote("connection closed in the middle of a message body")
                return NEED_DATA
            return self._deliver(event)

        if not self._buffer:
            if self._peer_closed:
                if their is IDLE:
                    return self._deliver(ConnectionClosed())
                raise self._remote("connection closed in the middle of a message")
            return NEED_DATA

        event = self._read_head()
        if event is None:
            if self._peer_closed:
                raise self._remote("connection closed in the middle of a message head")
            return NEED_DATA
        return self._deliver(event)

    def _remote(self, message, hint=400):
        exc = RemoteProtocolError(message, hint)
        self._their_error = exc
        self._states[self.their_role] = ERROR
        self._fire_triggered()
        return exc

    def _deliver(self, event):
        role = self.their_role
        new = self._legal_next(role, event)
        if new is None:
            raise self._remote(
                "peer sent %s in state %r" % (type(event).__name__, self._states[role])
            )
        outcome = None
        close = False
        if isinstance(event, (InformationalResponse, Response)):
            outcome = self._switch_outcome(event)
            close = has_token(event.headers, b"connection", b"close")
        self._commit(role, event, new, is_their=True, outcome=outcome, close=close)
        if isinstance(event, Request):
            self._reader = _request_body(event.headers)
        elif isinstance(event, Response) and new is not SWITCHED_PROTOCOL:
            self._reader = _response_body(self._cycle_method, event.status_code, event.headers)
        return event

    def _read_body(self):
        r = self._reader
        if r.mode == "length":
            if r.remaining == 0:
                self._reader = None
                return EndOfMessage()
            if not self._buffer:
                return None
            n = min(r.remaining, len(self._buffer))
            data = bytes(self._buffer[:n])
            del self._buffer[:n]
            r.remaining -= n
            return Data(data=data)
        if r.mode == "close":
            if self._buffer:
                data = bytes(self._buffer)
                self._buffer.clear()
                return Data(data=data)
            if self._peer_closed:
                self._reader = None
                return EndOfMessage()
            return None
        return self._read_chunked(r)

    def _read_chunked(self, r):
        while True:
            if r.phase == "size":
                nl = self._buffer.find(b"\n")
                if nl < 0:
                    if len(self._buffer) > self._max_incomplete:
                        raise self._remote("chunk size line is too long")
                    return None
                line = bytes(self._buffer[:nl])
                if line.endswith(b"\r"):
                    line = line[:-1]
                m = _CHUNK_SIZE_RE.fullmatch(line)
                if m is None:
                    raise self._remote("invalid chunk size line")
                del self._buffer[:nl + 1]
                size = int(m.group(1), 16)
                if size == 0:
                    r.phase = "trailers"
                else:
                    r.phase = "data"
                    r.remaining = size
                    r.fresh = True
                continue

            if r.phase == "data":
                if not self._buffer:
                    return None
                n = min(r.remaining, len(self._buffer))
                data = bytes(self._buffer[:n])
                del self._buffer[:n]
                r.remaining -= n
                start = r.fresh
                r.fresh = False
                end = r.remaining == 0
                if end:
                    r.phase = "crlf"
                return Data(data=data, chunk_start=start, chunk_end=end)

            if r.phase == "crlf":
                if self._buffer and self._buffer[0] != 0x0D:
                    raise self._remote("chunk data is not followed by CRLF")
                if len(self._buffer) < 2:
                    return None
                if self._buffer[1] != 0x0A:
                    raise self._remote("chunk data is not followed by CRLF")
                del self._buffer[:2]
                r.phase = "size"
                continue

            # trailers
            split = _split_head(self._buffer)
            if split is None:
                if len(self._buffer) > self._max_incomplete:
                    raise self._remote("trailer block exceeds the size limit", 431)
                return None
            lines, consumed = split
            del self._buffer[:consumed]
            try:
                trailers = _parse_field_lines(lines)
                event = EndOfMessage(headers=trailers)
            except LocalProtocolError as exc:
                raise self._remote(str(exc), exc.error_status_hint)
            self._reader = None
            return event

    def _read_head(self):
        if self._buffer[0] < 33:
            raise self._remote("message starts with a space or control byte")
        split = _split_head(self._buffer)
        if split is None:
            if len(self._buffer) > self._max_incomplete:
                raise self._remote("incomplete event exceeds the size limit", 431)
            return None
        lines, consumed = split
        del self._buffer[:consumed]
        try:
            if self.their_role is CLIENT:
                return self._parse_request(lines)
            return self._parse_response(lines)
        except LocalProtocolError as exc:
            raise self._remote(str(exc), exc.error_status_hint)

    def _parse_request(self, lines):
        m = _REQUEST_LINE_RE.fullmatch(lines[0])
        if m is None:
            raise LocalProtocolError("malformed request line")
        version = m.group(3) + b"." + m.group(4)
        if version not in (b"1.0", b"1.1"):
            raise LocalProtocolError("unsupported HTTP version")
        headers = _parse_field_lines(lines[1:])
        return Request(
            method=m.group(1), target=m.group(2), headers=headers, http_version=version
        )

    def _parse_response(self, lines):
        m = _STATUS_LINE_RE.fullmatch(lines[0])
        if m is None:
            raise LocalProtocolError("malformed status line")
        version = m.group(1) + b"." + m.group(2)
        if version not in (b"1.0", b"1.1"):
            raise LocalProtocolError("unsupported HTTP version")
        code = int(m.group(3))
        reason = m.group(4) or b""
        headers = _parse_field_lines(lines[1:])
        if 100 <= code < 200:
            return InformationalResponse(
                status_code=code, headers=headers, http_version=version, reason=reason
            )
        return Response(status_code=code, headers=headers, http_version=version, reason=reason)

    # ----------------------------------------------------------- cycle control

    def start_next_cycle(self):
        if self._states[CLIENT] is not DONE or self._states[SERVER] is not DONE:
            raise LocalProtocolError(
                "cannot start the next cycle: client is %r, server is %r"
                % (self._states[CLIENT], self._states[SERVER])
            )
        self._states[CLIENT] = IDLE
        self._states[SERVER] = IDLE
        self._reset_cycle()
        return None

    def send_failed(self):
        self._states[self.our_role] = ERROR
        self._fire_triggered()
        return None
