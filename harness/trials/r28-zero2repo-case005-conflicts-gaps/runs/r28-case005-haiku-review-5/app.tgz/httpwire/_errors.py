"""Protocol error classes.

``LocalProtocolError`` is raised when the integrator's own event or send breaks
the protocol. ``RemoteProtocolError`` is raised when bytes received from the
peer break it. Neither class is a subclass of the other.
"""


class _ProtocolErrorBase(Exception):
    def __init__(self, message="", error_status_hint=400):
        super().__init__(message)
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(_ProtocolErrorBase):
    """The integrator's event or send violated HTTP/1.1."""


class RemoteProtocolError(_ProtocolErrorBase):
    """Bytes received from the peer violated HTTP/1.1."""
