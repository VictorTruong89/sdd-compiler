"""Role, state, and non-event result sentinels.

Every value here is a distinct object; none of them compare equal to another
and none of them is a string.
"""


class _Sentinel:
    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return self._name


CLIENT = _Sentinel("CLIENT")
SERVER = _Sentinel("SERVER")

NEED_DATA = _Sentinel("NEED_DATA")
PAUSED = _Sentinel("PAUSED")

IDLE = _Sentinel("IDLE")
SEND_RESPONSE = _Sentinel("SEND_RESPONSE")
SEND_BODY = _Sentinel("SEND_BODY")
DONE = _Sentinel("DONE")
MUST_CLOSE = _Sentinel("MUST_CLOSE")
CLOSED = _Sentinel("CLOSED")
MIGHT_SWITCH_PROTOCOL = _Sentinel("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = _Sentinel("SWITCHED_PROTOCOL")
ERROR = _Sentinel("ERROR")
