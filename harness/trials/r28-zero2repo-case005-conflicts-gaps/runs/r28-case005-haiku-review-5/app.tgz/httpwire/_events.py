"""The six HTTP event kinds (FP-01)."""

from ._errors import LocalProtocolError
from ._headers import (
    Headers,
    build_headers,
    check_reason,
    is_target,
    is_token,
    is_version,
    to_bytes,
)


def _check_version(value):
    version = to_bytes(value, "HTTP version", LocalProtocolError)
    if not is_version(version):
        raise LocalProtocolError("invalid HTTP version %r" % (version,))
    return version


def _comparable(value):
    if isinstance(value, Headers):
        return tuple(value.raw_items())
    if isinstance(value, (bytearray, memoryview)):
        return bytes(value)
    return value


class _Event:
    __slots__ = ()
    _fields = ()

    def _key(self):
        return tuple(_comparable(getattr(self, f)) for f in self._fields)

    def __eq__(self, other):
        if type(other) is not type(self):
            return NotImplemented
        return self._key() == other._key()

    __hash__ = None

    def __repr__(self):
        parts = ", ".join("%s=%r" % (f, getattr(self, f)) for f in self._fields)
        return "%s(%s)" % (type(self).__name__, parts)


class Request(_Event):
    __slots__ = ("method", "target", "headers", "http_version")
    _fields = ("method", "target", "headers", "http_version")

    def __init__(self, method, target, headers=(), http_version=b"1.1"):
        method = to_bytes(method, "method", LocalProtocolError)
        if not is_token(method):
            raise LocalProtocolError("invalid request method %r" % (method,))
        target = to_bytes(target, "request target", LocalProtocolError)
        if not is_target(target):
            raise LocalProtocolError("invalid request target %r" % (target,))
        version = _check_version(http_version)
        hdrs = build_headers(headers, LocalProtocolError)
        hosts = sum(1 for name, _ in hdrs if name == b"host")
        if hosts > 1:
            raise LocalProtocolError("more than one Host header")
        if version == b"1.1" and hosts != 1:
            raise LocalProtocolError("an HTTP/1.1 request needs exactly one Host header")
        self.method = method
        self.target = target
        self.headers = hdrs
        self.http_version = version


class _StatusEvent(_Event):
    __slots__ = ("status_code", "headers", "http_version", "reason")
    _fields = ("status_code", "headers", "http_version", "reason")
    _LOW = 0
    _HIGH = 0

    def __init__(self, status_code, headers=(), http_version=b"1.1", reason=b""):
        if isinstance(status_code, bool) or not isinstance(status_code, int):
            raise LocalProtocolError("status code must be an integer")
        code = int(status_code)
        if not (self._LOW <= code < self._HIGH):
            raise LocalProtocolError("status code %d out of range" % code)
        version = _check_version(http_version)
        reason_b = to_bytes(reason, "reason phrase", LocalProtocolError)
        check_reason(reason_b, LocalProtocolError)
        hdrs = build_headers(headers, LocalProtocolError)
        self.status_code = code
        self.headers = hdrs
        self.http_version = version
        self.reason = reason_b


class InformationalResponse(_StatusEvent):
    __slots__ = ()
    _LOW = 100
    _HIGH = 200


class Response(_StatusEvent):
    __slots__ = ()
    _LOW = 200
    _HIGH = 1000


class Data(_Event):
    __slots__ = ("data", "chunk_start", "chunk_end")
    _fields = ("data", "chunk_start", "chunk_end")

    def __init__(self, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)


class EndOfMessage(_Event):
    __slots__ = ("headers",)
    _fields = ("headers",)

    def __init__(self, headers=()):
        self.headers = build_headers(headers, LocalProtocolError)


class ConnectionClosed(_Event):
    __slots__ = ()
    _fields = ()

    def __init__(self):
        pass
