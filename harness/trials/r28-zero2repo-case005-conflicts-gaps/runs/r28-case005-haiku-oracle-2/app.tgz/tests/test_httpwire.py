"""Behavioural tests for httpwire. Test names carry the spec id they check (see NOTES.md)."""

import pytest

import httpwire as hw
from httpwire import (
    CLIENT, SERVER, NEED_DATA, PAUSED, IDLE, SEND_RESPONSE, SEND_BODY, DONE,
    MUST_CLOSE, CLOSED, MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL, ERROR,
    Connection, Request, InformationalResponse, Response, Data, EndOfMessage,
    ConnectionClosed, LocalProtocolError, RemoteProtocolError,
)
from httpwire._errors import ReceiveClosedError


def pump(conn):
    """Pull events from conn until it reports NEED_DATA or PAUSED."""
    events = []
    while True:
        ev = conn.next_event()
        if ev is NEED_DATA or ev is PAUSED:
            return events, ev
        events.append(ev)


def exchange(client, server, data):
    """Feed client-sent bytes to the server and pull what the server can now see."""
    server.receive_data(data)
    return pump(server)


def get_request(**kw):
    headers = kw.pop("headers", [(b"Host", b"example.com")])
    return Request(method=kw.pop("method", b"GET"), target=kw.pop("target", b"/"), headers=headers, **kw)


# ---- FP-01 event construction ------------------------------------------------------------

def test_N_000072_request_fields_are_bytes_and_default_version():
    r = Request(method="GET", target="/a", headers=[("Host", "x")])
    assert r.method == b"GET" and r.target == b"/a" and r.http_version == b"1.1"
    assert type(r.method) is bytes


def test_N_000092_content_length_duplicates_collapse():
    r = Request(method=b"POST", target=b"/", headers=[(b"Host", b"x"), (b"Content-Length", b"5"),
                                                     (b"content-length", b"5, 5")])
    assert [p for p in r.headers if p[0] == b"content-length"] == [(b"content-length", b"5")]


def test_N_000092_content_length_conflict_refused():
    with pytest.raises(LocalProtocolError):
        Request(method=b"POST", target=b"/", headers=[(b"Host", b"x"), (b"Content-Length", b"5"),
                                                     (b"Content-Length", b"6")])


def test_N_000096_transfer_encoding_chunked_is_lowercased():
    r = Request(method=b"POST", target=b"/", headers=[(b"Host", b"x"), (b"Transfer-Encoding", b"CHUNKED")])
    assert (b"transfer-encoding", b"chunked") in list(r.headers)


def test_N_000121_second_transfer_encoding_refused_with_501():
    with pytest.raises(LocalProtocolError) as info:
        Request(method=b"POST", target=b"/", headers=[(b"Host", b"x"), (b"Transfer-Encoding", b"chunked"),
                                                     (b"Transfer-Encoding", b"chunked")])
    assert info.value.error_status_hint == 501


def test_N_000120_unknown_transfer_coding_refused_with_501():
    with pytest.raises(LocalProtocolError) as info:
        Request(method=b"POST", target=b"/", headers=[(b"Host", b"x"), (b"Transfer-Encoding", b"gzip, chunked")])
    assert info.value.error_status_hint == 501


def test_N_000104_http11_request_needs_host():
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/", headers=[])
    Request(method=b"GET", target=b"/", headers=[], http_version=b"1.0")


def test_N_000105_two_host_headers_refused_in_any_version():
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/", headers=[(b"host", b"a"), (b"HOST", b"b")], http_version=b"1.0")


def test_N_000106_bad_header_name_refused():
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/", headers=[(b"Host", b"x"), (b"Bad Name", b"v")])


def test_N_000097_value_rule_leading_space_refused_not_stripped():
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/", headers=[(b"Host", b" x")])


def test_N_000110_target_must_be_visible_ascii():
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/a b", headers=[(b"Host", b"x")])


def test_N_000112_status_out_of_range_refused():
    with pytest.raises(LocalProtocolError):
        InformationalResponse(status_code=200, headers=[])
    with pytest.raises(LocalProtocolError):
        Response(status_code=1000, headers=[])
    with pytest.raises(LocalProtocolError):
        Response(status_code="200", headers=[])


def test_N_000460_intenum_status_accepted_as_int():
    import enum

    class S(enum.IntEnum):
        OK = 200

    r = Response(status_code=S.OK, headers=[])
    assert type(r.status_code) is int and r.status_code == 200


def test_N_000466_invalid_construction_returns_no_event_and_later_succeeds():
    with pytest.raises(LocalProtocolError):
        Response(status_code=99, headers=[])
    assert Response(status_code=200, headers=[]).status_code == 200


def test_N_000469_raw_items_keep_caller_spelling():
    r = get_request(headers=[(b"Host", b"x"), (b"X-Case", b"v")])
    assert r.headers.raw_items() == [(b"Host", b"x"), (b"X-Case", b"v")]
    assert list(r.headers) == [(b"host", b"x"), (b"x-case", b"v")]


def test_N_000226_data_marks_are_bool_and_payload_kept():
    d = Data(data=bytearray(b"ab"), chunk_start=1, chunk_end=0)
    assert d.chunk_start is True and d.chunk_end is False


# ---- FP-02 connection basics -------------------------------------------------------------

def test_N_000123_connection_roles_and_initial_states():
    c = Connection(CLIENT)
    assert c.our_role is CLIENT and c.their_role is SERVER
    assert c.our_state is IDLE and c.their_state is IDLE
    assert c.states[CLIENT] is IDLE and c.states[SERVER] is IDLE
    assert c.states[0] is IDLE


def test_N_000172_bad_role_refused():
    with pytest.raises(Exception):
        Connection("CLIENT")


def test_N_000127_pull_on_empty_returns_need_data():
    assert Connection(SERVER).next_event() is NEED_DATA


def test_N_000128_request_round_trip_and_states():
    c, s = Connection(CLIENT), Connection(SERVER)
    wire = c.send(get_request(headers=[(b"Host", b"h"), (b"X-One", b"1")]))
    assert wire == b"GET / HTTP/1.1\r\nHost: h\r\nX-One: 1\r\n\r\n"
    assert c.our_state is SEND_BODY and c.their_state is SEND_RESPONSE
    s.receive_data(wire)
    ev = s.next_event()
    assert isinstance(ev, Request) and ev.target == b"/"
    assert s.our_state is SEND_RESPONSE and s.their_state is SEND_BODY
    assert s.their_http_version == b"1.1"
    assert c.their_http_version is None


def test_N_000161_host_written_first():
    c = Connection(CLIENT)
    wire = c.send(get_request(headers=[(b"X-A", b"1"), (b"Host", b"h")]))
    assert wire.startswith(b"GET / HTTP/1.1\r\nHost: h\r\nX-A: 1")


def test_N_000163_original_name_casing_on_wire():
    c = Connection(CLIENT)
    assert b"X-Mixed-Case: v" in c.send(get_request(headers=[(b"Host", b"h"), (b"X-Mixed-Case", b"v")]))


def test_N_000165_lone_lf_and_folding_accepted_when_reading():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\nHost: h\nX-Fold: a\n   b\n\n")
    ev = s.next_event()
    assert ev.headers[1] == (b"x-fold", b"a b")


def test_N_000166_status_line_without_reason_accepted():
    c = Connection(CLIENT)
    c.send(get_request())
    c.receive_data(b"HTTP/1.1 200\r\nContent-Length: 0\r\n\r\n")
    ev = c.next_event()
    assert isinstance(ev, Response) and ev.reason == b""


def test_N_000177_space_at_start_of_request_fails_at_once():
    s = Connection(SERVER)
    s.receive_data(b" GET")
    with pytest.raises(RemoteProtocolError):
        s.next_event()
    assert s.their_state is ERROR
    assert s.our_state is IDLE


def test_N_000302_remote_error_is_sticky_but_send_still_works():
    s = Connection(SERVER)
    s.receive_data(b"BAD\x01 / HTTP/1.1\r\n\r\n")
    with pytest.raises(RemoteProtocolError):
        s.next_event()
    with pytest.raises(RemoteProtocolError):
        s.next_event()
    wire = s.send(Response(status_code=400, headers=[(b"Content-Length", b"0")]))
    assert wire.startswith(b"HTTP/1.1 400 ")
    assert b"Connection: close" in wire


def test_N_000307_send_error_is_unrecoverable_for_sending():
    c = Connection(CLIENT)
    c.send(get_request())
    with pytest.raises(LocalProtocolError):
        c.send(get_request())
    assert c.our_state is ERROR
    with pytest.raises(LocalProtocolError):
        c.send(ConnectionClosed())


def test_N_000312_send_failed_marks_error_and_done_peer_must_close():
    c = Connection(CLIENT)
    c.send(get_request())
    c.send(EndOfMessage())
    c.send_failed()
    assert c.our_state is ERROR
    with pytest.raises(LocalProtocolError):
        c.send(ConnectionClosed())


def test_N_000174_invalid_header_line_from_peer_is_remote_error():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\nnocolon\r\n\r\n")
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_N_000316_incomplete_header_block_over_limit_is_431():
    s = Connection(SERVER, max_incomplete_event_size=100)
    s.receive_data(b"GET / HTTP/1.1\r\nX-Big: " + b"a" * 200)
    with pytest.raises(RemoteProtocolError) as info:
        s.next_event()
    assert info.value.error_status_hint == 431


def test_N_000316_default_limit_is_applied():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nX-Big: " + b"a" * (17 * 1024))
    with pytest.raises(RemoteProtocolError) as info:
        s.next_event()
    assert info.value.error_status_hint == 431


def test_N_000153_incomplete_event_needs_data_then_continues():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h")
    assert s.next_event() is NEED_DATA
    s.receive_data(b"\r\n\r\n")
    assert isinstance(s.next_event(), Request)


def test_N_000180_feed_after_close_is_runtime_error_not_protocol_error():
    s = Connection(SERVER)
    s.receive_data(b"")
    with pytest.raises(ReceiveClosedError) as info:
        s.receive_data(b"x")
    assert isinstance(info.value, RuntimeError)
    assert not isinstance(info.value, (LocalProtocolError, RemoteProtocolError))


def test_N_000144_feed_only_stores_bytes():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\nGET")
    assert s.their_state is IDLE and s.their_http_version is None
    assert s.trailing_data == (b"GET / HTTP/1.1\r\nHost: h\r\n\r\nGET", False)


# ---- FP-03 framing -----------------------------------------------------------------------

def test_N_000188_content_length_body_round_trip():
    c, s = Connection(CLIENT), Connection(SERVER)
    wire = c.send(get_request(method=b"POST", headers=[(b"Host", b"h"), (b"Content-Length", b"5")]))
    wire += c.send(Data(data=b"hel"))
    wire += c.send(Data(data=b"lo"))
    assert c.send(EndOfMessage()) == b""
    events, _ = exchange(c, s, wire)
    assert isinstance(events[0], Request)
    datas = [e.data for e in events if isinstance(e, Data)]
    assert b"".join(datas) == b"hello"
    assert isinstance(events[-1], EndOfMessage)


def test_N_000238_data_beyond_content_length_refused():
    c = Connection(CLIENT)
    c.send(get_request(method=b"POST", headers=[(b"Host", b"h"), (b"Content-Length", b"2")]))
    with pytest.raises(LocalProtocolError):
        c.send(Data(data=b"abc"))


def test_N_000239_eom_before_content_length_refused():
    c = Connection(CLIENT)
    c.send(get_request(method=b"POST", headers=[(b"Host", b"h"), (b"Content-Length", b"2")]))
    with pytest.raises(LocalProtocolError):
        c.send(EndOfMessage())


def test_N_000192_chunked_round_trip_with_trailers_and_marks():
    c, s = Connection(CLIENT), Connection(SERVER)
    wire = c.send(get_request(method=b"POST", headers=[(b"Host", b"h"), (b"Transfer-Encoding", b"chunked")]))
    wire += c.send(Data(data=b"abc"))
    wire += c.send(Data(data=b"de"))
    wire += c.send(EndOfMessage(headers=[(b"X-Trailer", b"t")]))
    assert wire.endswith(b"0\r\nX-Trailer: t\r\n\r\n")
    events, _ = exchange(c, s, wire)
    datas = [e for e in events if isinstance(e, Data)]
    assert b"".join(d.data for d in datas) == b"abcde"
    assert datas[0].chunk_start and datas[0].chunk_end
    assert events[-1].headers[0] == (b"x-trailer", b"t")


def test_N_000228_chunk_split_over_pieces_is_marked_start_and_end():
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n5\r\nab")
    assert isinstance(s.next_event(), Request)
    d1 = s.next_event()
    assert d1.data == b"ab" and d1.chunk_start and not d1.chunk_end
    s.receive_data(b"cde\r\n0\r\n\r\n")
    d2 = s.next_event()
    assert d2.data == b"cde" and not d2.chunk_start and d2.chunk_end
    assert isinstance(s.next_event(), EndOfMessage)


def test_N_000242_chunk_size_with_more_than_32_digits_refused():
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n" + b"f" * 40 + b"\r\n")
    assert isinstance(s.next_event(), Request)
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_N_000245_chunk_data_not_followed_by_crlf_refused():
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n2\r\nabXY")
    s.next_event()
    assert s.next_event().data == b"ab"
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_N_000228_chunk_extension_discarded():
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n3;name=val\r\nabc\r\n0\r\n\r\n")
    s.next_event()
    assert s.next_event().data == b"abc"


def test_N_000233_passthrough_keeps_object_identity():
    class Placeholder(object):
        def __len__(self):
            return 7

    c = Connection(CLIENT)
    c.send(get_request(method=b"PUT", headers=[(b"Host", b"h"), (b"Content-Length", b"7")]))
    p = Placeholder()
    pieces = c.send_with_data_passthrough(Data(data=p))
    assert any(piece is p for piece in pieces)
    assert c.send_with_data_passthrough(EndOfMessage()) == []


def test_N_000233_passthrough_chunked_adds_framing_pieces():
    class Placeholder(object):
        def __len__(self):
            return 4

    c = Connection(CLIENT)
    c.send(get_request(method=b"PUT", headers=[(b"Host", b"h"), (b"Transfer-Encoding", b"chunked")]))
    p = Placeholder()
    pieces = c.send_with_data_passthrough(Data(data=p))
    assert pieces[0] == b"4\r\n" and pieces[1] is p and pieces[2] == b"\r\n"


def test_N_000198_response_content_length_zero_kept_on_wire():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
    s.next_event()
    assert s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")])).endswith(
        b"Content-Length: 0\r\n\r\n")


def test_N_000200_response_without_framing_is_chunked_for_http11_peer():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
    s.next_event()
    wire = s.send(Response(status_code=200, headers=[]))
    assert b"Transfer-Encoding: chunked\r\n" in wire
    wire += s.send(Data(data=b"hi")) + s.send(EndOfMessage())
    assert wire.endswith(b"2\r\nhi\r\n0\r\n\r\n")


def test_N_000203_response_to_http10_peer_is_close_delimited_and_closes():
    s, c = Connection(SERVER), Connection(CLIENT)
    s.receive_data(b"GET / HTTP/1.0\r\nHost: h\r\n\r\n")
    s.next_event()
    wire = s.send(Response(status_code=200, headers=[]))
    assert b"Transfer-Encoding" not in wire and b"Content-Length" not in wire
    assert b"Connection: close" in wire
    wire += s.send(Data(data=b"body")) + s.send(EndOfMessage())
    assert s.our_state is MUST_CLOSE
    c2 = Connection(CLIENT)
    c2.send(get_request(headers=[(b"Host", b"h")]))
    c2.send(EndOfMessage())
    c2.receive_data(wire)
    got = []
    while True:
        ev = c2.next_event()
        if ev is NEED_DATA:
            break
        got.append(ev)
    assert isinstance(got[0], Response)
    assert b"".join(e.data for e in got if isinstance(e, Data)) == b"body"
    c2.receive_data(b"")
    tail = []
    while True:
        ev = c2.next_event()
        tail.append(ev)
        if isinstance(ev, ConnectionClosed):
            break
    assert isinstance(tail[-1], ConnectionClosed)
    assert c2.their_state is CLOSED
    assert c2.our_state is MUST_CLOSE


def test_N_000208_close_delimited_response_ends_at_receive_close():
    c = Connection(CLIENT)
    c.send(get_request())
    c.receive_data(b"HTTP/1.1 200 OK\r\n\r\nstuff")
    assert c.next_event().__class__ is Response
    assert c.next_event().data == b"stuff"
    assert c.next_event() is NEED_DATA
    c.receive_data(b"")
    assert isinstance(c.next_event(), EndOfMessage)
    assert isinstance(c.next_event(), ConnectionClosed)


def test_N_000215_head_response_has_empty_body():
    c = Connection(CLIENT)
    c.send(get_request(method=b"HEAD"))
    c.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 1000\r\n\r\n")
    assert isinstance(c.next_event(), Response)
    assert isinstance(c.next_event(), EndOfMessage)


def test_N_000219_server_head_answer_uses_get_framing():
    s = Connection(SERVER)
    s.receive_data(b"HEAD / HTTP/1.1\r\nHost: h\r\n\r\n")
    s.next_event()
    wire = s.send(Response(status_code=200, headers=[]))
    assert b"Transfer-Encoding: chunked" in wire
    assert s.send(EndOfMessage()) == b""


def test_N_000207_transfer_encoding_wins_over_content_length_on_response():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
    s.next_event()
    wire = s.send(Response(status_code=200, headers=[(b"Content-Length", b"3"),
                                                     (b"Transfer-Encoding", b"chunked")]))
    assert b"Content-Length" not in wire and b"Transfer-Encoding: chunked" in wire


def test_N_000096_request_with_both_headers_is_framed_by_content_length():
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nContent-Length: 2\r\nTransfer-Encoding: chunked\r\n\r\nhi")
    assert isinstance(s.next_event(), Request)
    assert s.next_event().data == b"hi"
    assert isinstance(s.next_event(), EndOfMessage)


def test_N_000220_no_framing_request_has_empty_body():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
    s.next_event()
    assert isinstance(s.next_event(), EndOfMessage)


# ---- FP-04 lifecycle --------------------------------------------------------------------

def run_cycle(c, s, method=b"GET", status=200, body=b"ok"):
    wire = c.send(get_request(method=method))
    wire += c.send(EndOfMessage())
    events, _ = exchange(c, s, wire)
    assert isinstance(events[0], Request)
    resp = s.send(Response(status_code=status, headers=[(b"Content-Length", str(len(body)).encode())]))
    resp += s.send(Data(data=body)) + s.send(EndOfMessage())
    c.receive_data(resp)
    got = []
    while True:
        ev = c.next_event()
        if ev is NEED_DATA:
            break
        got.append(ev)
    return got


def test_N_000270_keep_alive_two_cycles_on_one_connection():
    c, s = Connection(CLIENT), Connection(SERVER)
    got = run_cycle(c, s)
    assert isinstance(got[0], Response) and isinstance(got[-1], EndOfMessage)
    assert c.our_state is DONE and c.their_state is DONE
    assert s.our_state is DONE and s.their_state is DONE
    c.start_next_cycle()
    s.start_next_cycle()
    assert c.our_state is IDLE and s.our_state is IDLE
    got2 = run_cycle(c, s, body=b"again")
    assert isinstance(got2[0], Response)


def test_N_000280_start_next_cycle_refused_before_done():
    c = Connection(CLIENT)
    c.send(get_request())
    with pytest.raises(LocalProtocolError):
        c.start_next_cycle()
    assert c.our_state is SEND_BODY  # refusal changes nothing


def test_N_000272_client_second_request_refused():
    c = Connection(CLIENT)
    c.send(get_request())
    c.send(EndOfMessage())
    with pytest.raises(LocalProtocolError):
        c.send(get_request())


def test_N_000283_client_cannot_send_response_and_server_cannot_send_request():
    c = Connection(CLIENT)
    with pytest.raises(LocalProtocolError):
        c.send(Response(status_code=200, headers=[]))
    s = Connection(SERVER)
    with pytest.raises(LocalProtocolError):
        s.send(get_request())


def test_N_000275_pipelined_request_is_paused_until_next_cycle():
    c, s = Connection(CLIENT), Connection(SERVER)
    wire = c.send(get_request()) + c.send(EndOfMessage())
    wire += b"GET /second HTTP/1.1\r\nHost: h\r\n\r\n"
    events, last = exchange(c, s, wire)
    assert isinstance(events[0], Request) and events[0].target == b"/"
    assert last is NEED_DATA or last is PAUSED
    s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    assert s.next_event() is PAUSED
    assert s.trailing_data[0].startswith(b"GET /second")


def test_N_000259_http10_request_disables_keep_alive():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.0\r\nHost: h\r\nConnection: keep-alive\r\n\r\n")
    s.next_event()
    s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    assert s.our_state is MUST_CLOSE


def test_N_000262_connection_close_token_matched_as_whole_element():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\nConnection: closed-later\r\n\r\n")
    s.next_event()
    s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    assert s.our_state is DONE


def test_N_000262_connection_close_element_in_list_disables_keep_alive():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\nConnection: Keep-Alive, Close\r\n\r\n")
    s.next_event()
    s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    assert s.our_state is MUST_CLOSE


def test_N_000265_server_response_gets_connection_close_when_disabled():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\nConnection: close\r\n\r\n")
    s.next_event()
    wire = s.send(Response(status_code=200, headers=[(b"Content-Length", b"0"), (b"Connection", b"keep-alive")]))
    assert b"Connection: close" in wire and b"keep-alive" not in wire


def test_N_000276_client_must_not_send_second_request_while_waiting():
    c = Connection(CLIENT)
    c.send(get_request())
    c.send(EndOfMessage())
    assert c.our_state is DONE


def test_N_000286_http10_cycle_cannot_restart():
    c, s = Connection(CLIENT), Connection(SERVER)
    bad = Connection(CLIENT)
    with pytest.raises(LocalProtocolError):
        bad.send(get_request(http_version=b"1.0"))  # only HTTP/1.1 is sent
    assert bad.our_state is ERROR
    c.send(get_request())
    c.send(EndOfMessage())
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\nConnection: close\r\n\r\n")
    s.next_event()
    s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    assert s.our_state is MUST_CLOSE and c.our_state is DONE
    with pytest.raises(LocalProtocolError):
        s.start_next_cycle()


# ---- FP-05 errors -------------------------------------------------------------------------

def test_N_000296_transfer_encoding_refusal_status_on_wire():
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: gzip\r\n\r\n")
    with pytest.raises(RemoteProtocolError) as info:
        s.next_event()
    assert info.value.error_status_hint == 501


def test_N_000292_protocol_errors_carry_default_400():
    assert LocalProtocolError("x").error_status_hint == 400
    assert RemoteProtocolError("x").error_status_hint == 400
    assert not issubclass(LocalProtocolError, RemoteProtocolError)
    assert not issubclass(RemoteProtocolError, LocalProtocolError)


def test_N_000324_close_in_middle_of_content_length_body_is_remote_error():
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nContent-Length: 10\r\n\r\nabc")
    s.next_event()
    assert s.next_event().data == b"abc"
    s.receive_data(b"")
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_N_000339_close_when_idle_yields_connection_closed():
    s = Connection(SERVER)
    s.receive_data(b"")
    assert isinstance(s.next_event(), ConnectionClosed)
    assert s.their_state is CLOSED
    assert isinstance(s.next_event(), ConnectionClosed)


def test_N_000345_connection_closed_send_from_send_state_refused():
    c = Connection(CLIENT)
    c.send(get_request())
    with pytest.raises(LocalProtocolError):
        c.send(ConnectionClosed())


def test_N_000334_client_closed_from_idle_makes_server_must_close():
    c = Connection(CLIENT)
    assert c.send(ConnectionClosed()) == b""
    assert c.our_state is CLOSED
    s = Connection(SERVER)
    s.receive_data(b"")
    assert isinstance(s.next_event(), ConnectionClosed)


# ---- FP-07 informational, 100-continue, switching ----------------------------------------

def test_N_000349_informational_then_final_response_order():
    c, s = Connection(CLIENT), Connection(SERVER)
    c.send(get_request(method=b"POST", headers=[(b"Host", b"h"), (b"Content-Length", b"0"),
                                                (b"Expect", b"100-continue")]))
    assert c.client_is_waiting_for_100_continue is True
    assert c.they_are_waiting_for_100_continue is False
    c.send(EndOfMessage())
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nContent-Length: 0\r\nExpect: 100-continue\r\n\r\n")
    s.next_event()
    assert s.they_are_waiting_for_100_continue is True
    s.send(InformationalResponse(status_code=100, headers=[]))
    assert s.they_are_waiting_for_100_continue is False
    wire = s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    c.receive_data(b"HTTP/1.1 100 Continue\r\n\r\nHTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
    assert isinstance(c.next_event(), InformationalResponse)
    assert isinstance(c.next_event(), Response)


def test_N_000357_expect_on_http10_sets_no_flag():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.0\r\nHost: h\r\nExpect: 100-continue\r\n\r\n")
    s.next_event()
    assert s.they_are_waiting_for_100_continue is False
    assert s.client_is_waiting_for_100_continue is False


def test_N_000364_connect_accepted_by_2xx_switches_both_sides():
    c, s = Connection(CLIENT), Connection(SERVER)
    wire = c.send(get_request(method=b"CONNECT", target=b"example.com:443", headers=[(b"Host", b"example.com:443")]))
    wire += c.send(EndOfMessage())
    s.receive_data(wire + b"TUNNEL-DATA")
    assert isinstance(s.next_event(), Request)
    assert isinstance(s.next_event(), EndOfMessage)
    assert s.next_event() is PAUSED
    s.send(Response(status_code=200, headers=[]))
    assert s.our_state is SWITCHED_PROTOCOL and s.their_state is SWITCHED_PROTOCOL
    with pytest.raises(LocalProtocolError):
        s.send(EndOfMessage())
    c.receive_data(b"HTTP/1.1 200 OK\r\n\r\n")
    assert isinstance(c.next_event(), Response)
    assert c.our_state is SWITCHED_PROTOCOL
    assert c.next_event() is PAUSED
    assert s.trailing_data == (b"TUNNEL-DATA", False)


def test_N_000360_connect_denied_then_http_continues():
    c, s = Connection(CLIENT), Connection(SERVER)
    wire = c.send(get_request(method=b"CONNECT", target=b"x:1", headers=[(b"Host", b"x:1")]))
    wire += c.send(EndOfMessage())
    s.receive_data(wire)
    s.next_event()
    assert isinstance(s.next_event(), EndOfMessage)
    s.send(Response(status_code=403, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    assert s.our_state is DONE and s.their_state is DONE
    c.receive_data(b"HTTP/1.1 403 No\r\nContent-Length: 0\r\n\r\n")
    assert isinstance(c.next_event(), Response)
    assert c.our_state is DONE


def test_N_000366_upgrade_accepted_by_101():
    c, s = Connection(CLIENT), Connection(SERVER)
    wire = c.send(get_request(headers=[(b"Host", b"h"), (b"Upgrade", b"websocket"), (b"Connection", b"Upgrade")]))
    wire += c.send(EndOfMessage())
    s.receive_data(wire)
    s.next_event()
    assert isinstance(s.next_event(), EndOfMessage)
    assert s.next_event() is PAUSED
    s.send(InformationalResponse(status_code=101, headers=[(b"Upgrade", b"websocket"), (b"Connection", b"Upgrade")]))
    assert s.our_state is SWITCHED_PROTOCOL
    c.receive_data(b"HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n\r\n")
    assert isinstance(c.next_event(), InformationalResponse)
    assert c.our_state is SWITCHED_PROTOCOL


def test_N_000373_client_in_might_switch_after_proposal_eom():
    c = Connection(CLIENT)
    c.send(get_request(method=b"CONNECT", target=b"x:1", headers=[(b"Host", b"x:1")]))
    c.send(EndOfMessage())
    assert c.our_state is MIGHT_SWITCH_PROTOCOL
    with pytest.raises(LocalProtocolError):
        c.send(get_request())


def test_N_000388_trailing_data_close_after_denial_is_connection_closed():
    c, s = Connection(CLIENT), Connection(SERVER)
    wire = c.send(get_request(method=b"CONNECT", target=b"x:1", headers=[(b"Host", b"x:1")]))
    wire += c.send(EndOfMessage())
    s.receive_data(wire)
    s.next_event()
    assert isinstance(s.next_event(), EndOfMessage)
    assert s.next_event() is PAUSED
    s.receive_data(b"")
    assert s.next_event() is PAUSED  # paused for a switch proposal: the close is held
    s.send(Response(status_code=401, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    assert isinstance(s.next_event(), ConnectionClosed)


def test_N_000408_paused_and_need_data_are_distinct():
    assert PAUSED is not NEED_DATA
    assert not isinstance(PAUSED, hw.Request)


# ---- package surface -----------------------------------------------------------------------

def test_N_000433_surface_names_exist_at_root():
    for name in ["CLIENT", "SERVER", "NEED_DATA", "PAUSED", "IDLE", "SEND_RESPONSE", "SEND_BODY",
                 "DONE", "MUST_CLOSE", "CLOSED", "MIGHT_SWITCH_PROTOCOL", "SWITCHED_PROTOCOL", "ERROR",
                 "LocalProtocolError", "RemoteProtocolError", "Request", "InformationalResponse",
                 "Response", "Data", "EndOfMessage", "ConnectionClosed", "Connection"]:
        assert hasattr(hw, name), name


def test_N_000439_roles_and_states_distinct():
    states = [IDLE, SEND_RESPONSE, SEND_BODY, DONE, MUST_CLOSE, CLOSED,
              MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL, ERROR]
    assert len(set(map(id, states))) == 9
    assert CLIENT is not SERVER and CLIENT != SERVER
    assert NEED_DATA is not PAUSED
