"""The six event kinds, header normalization and construction-time checks (FP-01).

Construction failures raise LocalProtocolError and produce no event.
"""

import re

from ._errors import LocalProtocolError, _Violation

_TOKEN_RE = re.compile(rb"[!#$%&'*+\-.^_`|~0-9A-Za-z]+")
_VERSION_RE = re.compile(rb"[0-9]\.[0-9]")
_DIGITS_RE = re.compile(rb"[0-9]+")
_TARGET_RE = re.compile(rb"[\x21-\x7e]+")

# spec: N-000461 N-000462 N-000114 N-000116 N-000118 N-000119 — Content-Length digit limit.
# Conflict CF-000098 (16 vs 18 digits): the PRD range is 18 to 32; 18 is chosen.
MAX_CONTENT_LENGTH_DIGITS = 18


def to_bytes(value, what):
    """ASCII str or any bytes-like object -> bytes (N-000458, N-000459)."""
    if isinstance(value, str):
        try:
            return value.encode("ascii")
        except UnicodeEncodeError:
            raise _Violation("%s must be ASCII text or bytes" % what)
    try:
        return memoryview(value).tobytes()
    except TypeError:
        raise _Violation("%s must be ASCII text or bytes-like" % what)


def check_token(name, what):
    if not _TOKEN_RE.fullmatch(name):
        raise _Violation("%s is not a valid RFC 7230 token" % what)
    return name


def check_value(value):
    """Header value rule (N-000097..N-000100, N-000106..N-000108).

    Conflict CF-000026 (control bytes): control bytes other than tab are refused.
    """
    for c in value:
        if (c < 0x20 and c != 0x09) or c == 0x7F:
            raise _Violation("header value contains a control byte")
    if value[:1] in (b" ", b"\t") or value[-1:] in (b" ", b"\t"):
        raise _Violation("header value begins or ends with a space or tab")


def check_reason(reason):
    for c in reason:
        if (c < 0x20 and c != 0x09) or c == 0x7F:
            raise _Violation("reason phrase contains a control byte")
    return reason


def check_version(version):
    v = to_bytes(version, "HTTP version")
    if not _VERSION_RE.fullmatch(v):
        raise _Violation("HTTP version must look like 1.1")
    return v


def check_target(target):
    if not _TARGET_RE.fullmatch(target):
        raise _Violation("request target must be visible ASCII")
    return target


def check_status(value, low, high):
    if not isinstance(value, int):
        raise _Violation("status must be an integer")
    v = int(value)
    if not (low <= v < high):
        raise _Violation("status %d is outside the range for this event kind" % v)
    return v


def normalize_headers(pairs):
    """Validate (name, value) pairs; return a list of [raw_name, lower_name, value]."""
    if isinstance(pairs, Headers):
        pairs = pairs.raw_items()
    if pairs is None:
        pairs = ()
    try:
        iterator = iter(pairs)
    except TypeError:
        raise _Violation("headers must be a sequence of (name, value) pairs")
    out = []
    for pair in iterator:
        try:
            name, value = pair
        except (TypeError, ValueError):
            raise _Violation("each header must be a (name, value) pair")
        raw = to_bytes(name, "header name")
        check_token(raw, "header name")
        val = to_bytes(value, "header value")
        check_value(val)
        out.append([raw, raw.lower(), val])
    return _framing(out)


def _framing(items):
    """Content-Length and Transfer-Encoding normalization (N-000092..N-000096, N-000120, N-000121)."""
    cl_index = [i for i, it in enumerate(items) if it[1] == b"content-length"]
    if cl_index:
        values = set()
        for i in cl_index:
            for piece in items[i][2].split(b","):
                piece = piece.strip(b" \t")
                if not _DIGITS_RE.fullmatch(piece) or len(piece) > MAX_CONTENT_LENGTH_DIGITS:
                    raise _Violation("invalid Content-Length value")
                values.add(int(piece))
        if len(values) != 1:
            raise _Violation("conflicting Content-Length values")
        merged = [items[cl_index[0]][0], b"content-length", str(values.pop()).encode("ascii")]
        out = []
        placed = False
        for it in items:
            if it[1] == b"content-length":
                if not placed:
                    out.append(merged)
                    placed = True
                continue
            out.append(it)
        items = out
    te_index = [i for i, it in enumerate(items) if it[1] == b"transfer-encoding"]
    if len(te_index) > 1:
        raise _Violation("a second Transfer-Encoding header is refused", 501)
    if te_index:
        i = te_index[0]
        if items[i][2].lower() != b"chunked":
            raise _Violation("only the chunked transfer coding is supported", 501)
        items[i] = [items[i][0], b"transfer-encoding", b"chunked"]
    return items


def _check_host(items, version):
    """Host rules (N-000077, N-000078, N-000104, N-000105)."""
    hosts = sum(1 for it in items if it[1] == b"host")
    if hosts > 1:
        raise _Violation("more than one Host header")
    if version == b"1.1" and hosts == 0:
        raise _Violation("an HTTP/1.1 request needs exactly one Host header")


def _triples(normalized):
    return tuple((it[0], it[1], it[2]) for it in normalized)


class Headers(object):
    """Ordered header list.

    Iterating or indexing yields (lowercase name, value) byte pairs.
    raw_items() yields (name as spelled by the caller, value) byte pairs.
    """

    __slots__ = ("_items",)

    def __init__(self, items=()):
        self._items = tuple(items)

    def __iter__(self):
        return iter([(it[1], it[2]) for it in self._items])

    def __len__(self):
        return len(self._items)

    def __getitem__(self, index):
        if isinstance(index, slice):
            return [(it[1], it[2]) for it in self._items[index]]
        it = self._items[index]
        return (it[1], it[2])

    def raw_items(self):
        return [(it[0], it[2]) for it in self._items]

    def __eq__(self, other):
        if isinstance(other, (Headers, list, tuple)):
            return list(self) == [tuple(p) for p in other]
        return NotImplemented

    __hash__ = None

    def __repr__(self):
        return "Headers(%r)" % (list(self),)


class Request(object):
    """Start of a request: method, target, headers, HTTP version."""

    def __init__(self, method, target, headers, http_version=b"1.1"):
        try:
            self.method = check_token(to_bytes(method, "method"), "method")
            self.target = check_target(to_bytes(target, "target"))
            self.http_version = check_version(http_version)
            normalized = normalize_headers(headers)
            _check_host(normalized, self.http_version)
            self.headers = Headers(_triples(normalized))
        except _Violation as exc:
            raise LocalProtocolError(str(exc), exc.status)

    def __repr__(self):
        return "Request(method=%r, target=%r, headers=%r, http_version=%r)" % (
            self.method, self.target, self.headers, self.http_version)


class InformationalResponse(object):
    """1xx status line: status code 100 <= n < 200."""

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        try:
            self.status_code = check_status(status_code, 100, 200)
            self.http_version = check_version(http_version)
            self.reason = check_reason(to_bytes(reason, "reason"))
            self.headers = Headers(_triples(normalize_headers(headers)))
        except _Violation as exc:
            raise LocalProtocolError(str(exc), exc.status)

    def __repr__(self):
        return "InformationalResponse(status_code=%r, headers=%r)" % (self.status_code, self.headers)


class Response(object):
    """Final status line: status code 200 <= n < 1000."""

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        try:
            self.status_code = check_status(status_code, 200, 1000)
            self.http_version = check_version(http_version)
            self.reason = check_reason(to_bytes(reason, "reason"))
            self.headers = Headers(_triples(normalize_headers(headers)))
        except _Violation as exc:
            raise LocalProtocolError(str(exc), exc.status)

    def __repr__(self):
        return "Response(status_code=%r, headers=%r)" % (self.status_code, self.headers)


class Data(object):
    """A piece of a message body. ``data`` is stored exactly as given."""

    def __init__(self, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)

    def __repr__(self):
        return "Data(data=%r, chunk_start=%r, chunk_end=%r)" % (
            self.data, self.chunk_start, self.chunk_end)


class EndOfMessage(object):
    """End of a message, optionally with trailing headers."""

    def __init__(self, headers=()):
        try:
            self.headers = Headers(_triples(normalize_headers(() if headers is None else headers)))
        except _Violation as exc:
            raise LocalProtocolError(str(exc), exc.status)

    def __repr__(self):
        return "EndOfMessage(headers=%r)" % (self.headers,)


class ConnectionClosed(object):
    """This party will not send more HTTP data."""

    def __repr__(self):
        return "ConnectionClosed()"


EVENT_TYPES = (Request, InformationalResponse, Response, Data, EndOfMessage, ConnectionClosed)
