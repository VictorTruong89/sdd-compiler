"""Role, state and sentinel objects exported at the package root.

# spec: N-000438 N-000439 N-000443 N-000444 N-000445 N-000440 N-000441 N-000442
"""


class _Role(object):
    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return "httpwire.%s" % self._name


class _State(object):
    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return "httpwire.%s" % self._name


class _Sentinel(object):
    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return "httpwire.%s" % self._name


# spec: N-000438 N-000439 — two distinct role values that do not compare equal.
CLIENT = _Role("CLIENT")
SERVER = _Role("SERVER")

# spec: N-000443 N-000444 N-000445 — nine distinct state objects.
IDLE = _State("IDLE")
SEND_RESPONSE = _State("SEND_RESPONSE")
SEND_BODY = _State("SEND_BODY")
DONE = _State("DONE")
MUST_CLOSE = _State("MUST_CLOSE")
CLOSED = _State("CLOSED")
MIGHT_SWITCH_PROTOCOL = _State("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = _State("SWITCHED_PROTOCOL")
ERROR = _State("ERROR")

# spec: N-000440 N-000441 N-000442 — non-event results of next_event.
NEED_DATA = _Sentinel("NEED_DATA")
PAUSED = _Sentinel("PAUSED")
