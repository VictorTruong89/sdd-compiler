"""Byte-level parsing and serialization helpers (the wire side of FP-02, FP-03, FP-05)."""

import re

from ._errors import _Violation
from ._events import check_token, check_reason

_CHUNK_SIZE_RE = re.compile(rb"([0-9A-Fa-f]{1,32})[ \t]*(?:;[^\r\n]*)?")
_HEX_PREFIX_RE = re.compile(rb"[0-9A-Fa-f]*")
_STATUS_CODE_RE = re.compile(rb"[0-9]{3}")

# spec: N-000228 N-000229 N-000230 N-000242 — chunk-size line: 1 to 32 hex digits, optional extension.
MAX_CHUNK_SIZE_DIGITS = 32


def read_lines(buf):
    """Split ``buf`` into lines up to the blank line that ends the block.

    Returns (lines, end_offset), or None when the block is not yet complete.
    Lone LF line endings are accepted (N-000165; conflict CF-000074 resolved in favour of acceptance).
    """
    lines = []
    pos = 0
    while True:
        nl = buf.find(b"\n", pos)
        if nl < 0:
            return None
        line = bytes(buf[pos:nl])
        if line.endswith(b"\r"):
            line = line[:-1]
        pos = nl + 1
        if not line:
            return lines, pos
        lines.append(line)


def parse_request_line(line):
    """``METHOD SP target SP HTTP/x.y`` -> (method, target, version digits). N-000110, N-000111."""
    parts = line.split(b" ")
    if len(parts) != 3:
        raise _Violation("malformed request line")
    method, target, version = parts
    check_token(method, "method")
    if not target or any(c < 0x21 or c > 0x7E for c in target):
        raise _Violation("request target must be visible ASCII")
    if version not in (b"HTTP/1.1", b"HTTP/1.0"):
        raise _Violation("unsupported HTTP version")
    return method, target, version[5:]


def parse_status_line(line):
    """``HTTP/x.y SP 3DIGIT [SP reason]`` -> (version digits, status int, reason bytes).

    A missing reason phrase is accepted and yields an empty reason (N-000166; CF-000005).
    """
    parts = line.split(b" ", 2)
    if len(parts) < 2:
        raise _Violation("malformed status line")
    version = parts[0]
    if version not in (b"HTTP/1.1", b"HTTP/1.0"):
        raise _Violation("unsupported HTTP version")
    code = parts[1]
    if not _STATUS_CODE_RE.fullmatch(code):
        raise _Violation("status code must be three digits")
    status = int(code)
    if status < 100:
        raise _Violation("status code out of range")
    reason = parts[2] if len(parts) == 3 else b""
    check_reason(reason)
    return version[5:], status, reason


def parse_header_lines(lines):
    """Header lines -> list of (name, value) pairs.

    Obsolete line folding is joined to the previous value with one space (N-000167..N-000169;
    CF-000075, CF-000076, CF-000100 resolved in favour of acceptance).
    """
    items = []
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            if not items:
                raise _Violation("continuation line without a preceding header")
            name, value = items[-1]
            value = (value + b" " + line.lstrip(b" \t")).strip(b" \t")
            items[-1] = (name, value)
            continue
        idx = line.find(b":")
        if idx < 0:
            raise _Violation("header line without a colon")
        items.append((line[:idx], line[idx + 1:].strip(b" \t")))
    return items


def parse_chunk_size(line):
    """Chunk-size line -> int. Whitespace before the line end and extensions are accepted (CF-000101)."""
    m = _CHUNK_SIZE_RE.fullmatch(line)
    if not m:
        raise _Violation("invalid chunk-size line")
    return int(m.group(1), 16)


def hex_prefix_length(buf):
    return len(_HEX_PREFIX_RE.match(buf).group(0))


def serialize_head(start_line, items):
    parts = [start_line]
    for raw, _lower, value in items:
        parts.append(raw + b": " + value + b"\r\n")
    parts.append(b"\r\n")
    return b"".join(parts)
