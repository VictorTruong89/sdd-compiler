"""httpwire: a pure-Python HTTP/1.1 wire protocol library with no I/O of its own.

Integrators encode events with ``Connection.send`` and recover events with
``Connection.receive_data`` followed by ``Connection.next_event``.
"""

from ._constants import (
    CLIENT,
    SERVER,
    NEED_DATA,
    PAUSED,
    IDLE,
    SEND_RESPONSE,
    SEND_BODY,
    DONE,
    MUST_CLOSE,
    CLOSED,
    MIGHT_SWITCH_PROTOCOL,
    SWITCHED_PROTOCOL,
    ERROR,
)
from ._errors import LocalProtocolError, RemoteProtocolError
from ._events import (
    Request,
    InformationalResponse,
    Response,
    Data,
    EndOfMessage,
    ConnectionClosed,
)
from ._connection import Connection

__version__ = "0.1.0"

__all__ = [
    "CLIENT",
    "SERVER",
    "NEED_DATA",
    "PAUSED",
    "IDLE",
    "SEND_RESPONSE",
    "SEND_BODY",
    "DONE",
    "MUST_CLOSE",
    "CLOSED",
    "MIGHT_SWITCH_PROTOCOL",
    "SWITCHED_PROTOCOL",
    "ERROR",
    "LocalProtocolError",
    "RemoteProtocolError",
    "Request",
    "InformationalResponse",
    "Response",
    "Data",
    "EndOfMessage",
    "ConnectionClosed",
    "Connection",
]
