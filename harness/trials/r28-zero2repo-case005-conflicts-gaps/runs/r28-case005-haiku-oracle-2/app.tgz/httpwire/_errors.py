"""Exception classes.

# spec: N-000446 N-000447 N-000448 N-000472 N-000474 N-000475 N-000290 N-000291 N-000326
"""


class _Violation(Exception):
    """Internal: a rule was broken. Converted to a public error by the caller."""

    def __init__(self, message, status=400):
        Exception.__init__(self, message)
        self.status = status


class _ProtocolError(Exception):
    """Common base; the two public protocol errors are siblings, not subclasses of each other."""

    def __init__(self, message="", error_status_hint=400):
        Exception.__init__(self, message)
        # spec: N-000472 — error_status_hint is exactly an int.
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(_ProtocolError):
    """The integrator's own event or send violated the protocol."""


class RemoteProtocolError(_ProtocolError):
    """The peer's bytes violated the protocol."""


class ReceiveClosedError(RuntimeError):
    """Non-empty bytes were fed after the receive side was closed.

    A runtime error, deliberately neither a local nor a remote protocol error.
    """


def status_of(exc):
    """Suggested status carried by an internal violation or a public protocol error."""
    if isinstance(exc, _Violation):
        return exc.status
    return exc.error_status_hint
