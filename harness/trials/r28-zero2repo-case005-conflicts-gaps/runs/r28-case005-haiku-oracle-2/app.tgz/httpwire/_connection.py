"""The Connection class: one HTTP/1.1 conversation, bring-your-own-I/O (FP-02..FP-07).

No sockets are used anywhere in this module (N-000047, N-000049). Bytes in and bytes out
are the whole interface.
"""

from . import _wire
from ._constants import (
    CLIENT, SERVER, IDLE, SEND_RESPONSE, SEND_BODY, DONE, MUST_CLOSE, CLOSED,
    MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL, ERROR, NEED_DATA, PAUSED,
)
from ._errors import LocalProtocolError, RemoteProtocolError, ReceiveClosedError, _Violation, status_of
from ._events import (
    EVENT_TYPES, Request, InformationalResponse, Response, Data,
    EndOfMessage, ConnectionClosed,
)

# spec: N-000317 N-000318 N-000319 N-000478 N-000479 N-000480 — incomplete-event size limit.
# Conflict CF-000048: the PRD says "14 to 18 KiB, implementer's choice"; 16 KiB is chosen,
# which also lies inside that range (the 8 KiB figure in the Interface Contract is rejected).
DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 16 * 1024

_STATES = (IDLE, SEND_RESPONSE, SEND_BODY, DONE, MUST_CLOSE, CLOSED,
           MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL, ERROR)


class _States(tuple):
    """(client-side state, server-side state). Also indexable by role, and by 0/1."""

    def __new__(cls, client_state, server_state):
        return tuple.__new__(cls, (client_state, server_state))

    def __getitem__(self, key):
        if key is CLIENT:
            return tuple.__getitem__(self, 0)
        if key is SERVER:
            return tuple.__getitem__(self, 1)
        return tuple.__getitem__(self, key)

    def keys(self):
        return [CLIENT, SERVER]

    def values(self):
        return [self[0], self[1]]

    def items(self):
        return [(CLIENT, self[0]), (SERVER, self[1])]

    def get(self, key, default=None):
        try:
            return self[key]
        except (IndexError, KeyError):
            return default

    def __eq__(self, other):
        if isinstance(other, dict):
            return other == {CLIENT: self[0], SERVER: self[1]}
        return tuple.__eq__(self, other)

    __hash__ = tuple.__hash__

    def __repr__(self):
        return "{CLIENT: %r, SERVER: %r}" % (self[0], self[1])


class _Frame(object):
    """Body framing of one message. kind: 'length', 'chunked' or 'close'."""

    __slots__ = ("kind", "remaining", "no_body")

    def __init__(self, kind, remaining, no_body):
        self.kind = kind
        self.remaining = remaining
        self.no_body = no_body


def _has_token(items, name, token):
    for it in items:
        if it[1] == name:
            for part in it[2].split(b","):
                if part.strip(b" \t").lower() == token:
                    return True
    return False


def _has_header(items, name):
    return any(it[1] == name for it in items)


def _content_length(items):
    for it in items:
        if it[1] == b"content-length":
            return int(it[2])
    return None


def _request_frame(items):
    """Framing of a request (FP-03): Content-Length, else chunked, else an empty body."""
    n = _content_length(items)
    if n is not None:
        return _Frame("length", n, False)
    if _has_header(items, b"transfer-encoding"):
        return _Frame("chunked", None, False)
    return _Frame("length", 0, False)


def _proposals(request):
    """Switch proposals a request makes (FP-07): CONNECT and/or Upgrade."""
    found = set()
    if request.method == b"CONNECT":
        found.add(b"CONNECT")
    if _has_header(request.headers._items, b"upgrade"):
        found.add(b"upgrade")
    return found


def _with_connection_close(items):
    """Make the Connection header say close and drop keep-alive (N-000265..N-000268)."""
    out = []
    found = False
    for it in items:
        if it[1] == b"connection":
            if found:
                continue
            tokens = [t.strip(b" \t") for t in it[2].split(b",")]
            tokens = [t for t in tokens if t and t.lower() not in (b"keep-alive", b"close")]
            out.append([it[0], b"connection", b", ".join(tokens + [b"close"])])
            found = True
        else:
            out.append(it)
    if not found:
        out.append([b"Connection", b"connection", b"close"])
    return out


def _payload(data, passthrough):
    """Return (piece, byte_length) for a Data payload (FP-03 passthrough rules)."""
    if isinstance(data, str):
        raise TypeError("Data payload must be bytes-like")
    try:
        view = memoryview(data)
    except TypeError:
        view = None
    if view is not None:
        piece = data if isinstance(data, bytes) else view.tobytes()
        return piece, view.nbytes
    if not passthrough:
        raise TypeError("Data payload is not bytes-like; use send_with_data_passthrough")
    return data, len(data)


class Connection(object):
    """One HTTP/1.1 connection in the CLIENT or SERVER role. No I/O is performed."""

    def __init__(self, our_role, max_incomplete_event_size=DEFAULT_MAX_INCOMPLETE_EVENT_SIZE):
        if our_role is CLIENT:
            their_role = SERVER
        elif our_role is SERVER:
            their_role = CLIENT
        else:
            raise LocalProtocolError("role must be CLIENT or SERVER", 400)
        if (isinstance(max_incomplete_event_size, bool)
                or not isinstance(max_incomplete_event_size, int)
                or max_incomplete_event_size < 1):
            raise ValueError("max_incomplete_event_size must be a positive int")
        self._our_role = our_role
        self._their_role = their_role
        self._st = {CLIENT: IDLE, SERVER: IDLE}           # spec: N-000123 N-000124 N-000125
        self._buf = bytearray()
        self._closed = False                               # receive side closed (empty feed)
        self._limit = int(max_incomplete_event_size)
        self._their_version = None                         # bytes such as b"1.1", or None
        self._request_method = None
        self._pending = set()                              # open switch proposals
        self._expect = False                               # 100-continue waiting flag
        self._our_close = False
        self._their_close = False
        self._send_frame = None
        self._recv_frame = None
        self._cs = "size"                                  # chunked receive sub-state
        self._cleft = 0
        self._cfirst = False

    # ----- attributes -------------------------------------------------------------------

    @property
    def our_role(self):
        return self._our_role

    @property
    def their_role(self):
        return self._their_role

    @property
    def our_state(self):
        return self._st[self._our_role]

    @property
    def their_state(self):
        return self._st[self._their_role]

    @property
    def states(self):
        return _States(self._st[CLIENT], self._st[SERVER])

    @property
    def their_http_version(self):
        return self._their_version

    @property
    def client_is_waiting_for_100_continue(self):
        return bool(self._expect)

    @property
    def they_are_waiting_for_100_continue(self):
        return bool(self._expect) and self._our_role is SERVER

    @property
    def trailing_data(self):
        return (bytes(self._buf), self._closed)

    # ----- public operations -------------------------------------------------------------

    def send(self, event):
        """Encode one event; return the bytes to transmit (bytes)."""
        return self._send(event, passthrough=False)

    def send_with_data_passthrough(self, event):
        """Like send, but returns a list of pieces; non-bytes Data payloads are kept by identity."""
        return self._send(event, passthrough=True)

    def receive_data(self, data):
        """Store bytes received from the peer. An empty chunk means the peer closed its sending side."""
        try:
            raw = memoryview(data).tobytes()
        except TypeError:
            raise TypeError("receive_data needs a bytes-like object")
        if not raw:
            self._closed = True
            return None
        if self._closed:
            raise ReceiveClosedError("bytes fed after the receive side was closed")
        self._buf += raw
        return None

    def next_event(self):
        """Parse and return one event, NEED_DATA, or PAUSED."""
        st = self._st
        us, them = self._our_role, self._their_role
        buf = self._buf
        if st[them] is ERROR:
            raise RemoteProtocolError("the peer side is in ERROR", 400)
        if st[us] is SWITCHED_PROTOCOL or st[them] in (SWITCHED_PROTOCOL, MIGHT_SWITCH_PROTOCOL):
            return PAUSED                                  # spec: N-000386 N-000389 N-000391
        cur = st[them]
        if cur in (DONE, MUST_CLOSE):
            if buf:
                return PAUSED                              # spec: N-000275..N-000279
            if self._closed:
                return self._pull_close()
            return NEED_DATA
        if cur is CLOSED:
            return ConnectionClosed()
        if cur is IDLE and not buf:
            if self._closed:
                return self._pull_close()
            return NEED_DATA
        if them is CLIENT:
            if cur is IDLE:
                return self._pull_request()
            if cur is SEND_BODY:
                return self._pull_body()
        else:
            if cur is SEND_RESPONSE:
                return self._pull_response()
            if cur is SEND_BODY:
                return self._pull_body()
        return self._fail("unexpected bytes from the peer", 400)

    def start_next_cycle(self):
        """Reset both sides to IDLE when both are DONE. Refusal changes nothing (N-000280..N-000282)."""
        if self._st[CLIENT] is not DONE or self._st[SERVER] is not DONE:
            raise LocalProtocolError("the next cycle can only start when both sides are DONE", 400)
        self._st[CLIENT] = IDLE
        self._st[SERVER] = IDLE
        self._request_method = None
        self._pending = set()
        self._expect = False
        self._our_close = False
        self._their_close = False
        self._send_frame = None
        self._recv_frame = None
        self._cs = "size"
        return None

    def send_failed(self):
        """Record that the last send's bytes never went out (N-000312..N-000315)."""
        self._st[self._our_role] = ERROR
        self._fire()
        return None

    # ----- sending -----------------------------------------------------------------------

    def _send(self, event, passthrough):
        us = self._our_role
        if not isinstance(event, EVENT_TYPES):
            raise TypeError("send() needs an event")
        if self._st[us] is ERROR:
            raise LocalProtocolError("this side is in ERROR; no further sends", 400)
        try:
            self._precheck_send(event)
            pieces, info = self._encode(event, passthrough)
            self._apply(us, event)
        except _Violation as exc:
            # spec: N-000307..N-000310 — an unrecoverable send failure.
            self._st[us] = ERROR
            self._fire()
            raise LocalProtocolError(str(exc), exc.status)
        if isinstance(event, Request):
            self._send_frame = info
        elif isinstance(event, Response):
            self._send_frame, want_close = info
            if want_close:
                self._our_close = True
        elif isinstance(event, Data):
            if self._send_frame is not None and self._send_frame.kind == "length":
                self._send_frame.remaining -= info
        elif isinstance(event, EndOfMessage):
            self._send_frame = None
        self._fire()
        if passthrough:
            return pieces
        return b"".join(pieces)

    def _precheck_send(self, ev):
        our = self._our_role
        cur = self._st[our]
        if isinstance(ev, Request):
            if our is not CLIENT or cur is not IDLE:
                raise _Violation("a request can only be sent by a client in IDLE")
            if ev.http_version != b"1.1":
                raise _Violation("only HTTP/1.1 requests can be sent")
        elif isinstance(ev, InformationalResponse):
            if our is not SERVER or cur is not SEND_RESPONSE:
                raise _Violation("an informational response needs SEND_RESPONSE on a server")
            if ev.http_version != b"1.1":
                raise _Violation("only HTTP/1.1 responses can be sent")
        elif isinstance(ev, Response):
            if our is not SERVER or cur not in (IDLE, SEND_RESPONSE):
                raise _Violation("a response can only be sent by a server")
            if ev.http_version != b"1.1":
                raise _Violation("only HTTP/1.1 responses can be sent")
        elif isinstance(ev, (Data, EndOfMessage)):
            if cur is not SEND_BODY:
                raise _Violation("body events need SEND_BODY")
        elif isinstance(ev, ConnectionClosed):
            if cur not in (IDLE, DONE, MUST_CLOSE):
                raise _Violation("connection-closed can only be sent from IDLE, DONE or MUST_CLOSE")

    def _encode(self, ev, passthrough):
        """Return (pieces, info). Raises _Violation for framing violations; mutates nothing."""
        if isinstance(ev, Request):
            items = list(ev.headers._items)
            # spec: N-000161 N-000162 — Host is written first; other headers keep their order.
            items = [it for it in items if it[1] == b"host"] + [it for it in items if it[1] != b"host"]
            head = b"%s %s HTTP/1.1\r\n" % (ev.method, ev.target)
            return [_wire.serialize_head(head, items)], _request_frame(items)
        if isinstance(ev, InformationalResponse):
            head = b"HTTP/1.1 %d %s\r\n" % (ev.status_code, ev.reason)
            return [_wire.serialize_head(head, list(ev.headers._items))], None
        if isinstance(ev, Response):
            return self._encode_response(ev)
        if isinstance(ev, Data):
            return self._encode_data(ev, passthrough)
        if isinstance(ev, EndOfMessage):
            return self._encode_eom(ev), None
        return [], None

    def _encode_response(self, ev):
        items = [list(it) for it in ev.headers._items]
        status = ev.status_code
        head_line = b"HTTP/1.1 %d %s\r\n" % (status, ev.reason)
        if self._accepts(ev):
            # Accepted switch: no framing, no body, no end-of-message (N-000381).
            return [_wire.serialize_head(head_line, items)], (None, False)
        empty = self._request_method == b"HEAD" or status in (204, 304)   # N-000215..N-000219
        peer = self._their_version
        want_close = ((peer is not None and peer != b"1.1") or self._their_close
                      or _has_token(items, b"connection", b"close"))
        if _content_length(items) is not None and not _has_header(items, b"transfer-encoding"):
            frame = _Frame("length", 0 if empty else _content_length(items), empty)
        else:
            # Unknown length (or both headers: transfer-encoding wins, N-000207).
            items = [it for it in items if it[1] not in (b"content-length", b"transfer-encoding")]
            if peer == b"1.1":
                items.append([b"Transfer-Encoding", b"transfer-encoding", b"chunked"])
                frame = _Frame("chunked", None, empty)
            else:
                frame = _Frame("close", None, empty)     # N-000203..N-000206, N-000208
                want_close = True
        if want_close:
            items = _with_connection_close(items)
        return [_wire.serialize_head(head_line, items)], (frame, want_close)

    def _encode_data(self, ev, passthrough):
        frame = self._send_frame
        piece, n = _payload(ev.data, passthrough)
        if frame.no_body and n:
            raise _Violation("this message has an empty body")  # N-000215..N-000218
        if frame.kind == "length" and n > frame.remaining:
            raise _Violation("Data exceeds the declared Content-Length")  # N-000238
        if n == 0:
            return [], 0
        if frame.kind == "chunked":
            return [b"%x\r\n" % n, piece, b"\r\n"], n     # N-000192..N-000197
        return [piece], n

    def _encode_eom(self, ev):
        frame = self._send_frame
        trailers = list(ev.headers._items)
        if frame.kind == "length":
            if frame.remaining != 0:
                raise _Violation("the declared Content-Length has not been sent in full")  # N-000239
            if trailers:
                raise _Violation("trailers are not allowed with Content-Length framing")   # N-000240
            return []
        if frame.kind == "close":
            if trailers:
                raise _Violation("trailers are not allowed with close-delimited framing")  # N-000240
            return []
        if trailers and self._their_version == b"1.0":
            raise _Violation("trailers are refused for an HTTP/1.0 peer")                   # N-000241
        if frame.no_body:
            return []
        out = [b"0\r\n"]
        for raw, _lower, value in trailers:
            out.append(raw + b": " + value + b"\r\n")
        out.append(b"\r\n")
        return out

    # ----- state machine ---------------------------------------------------------------

    def _accepts(self, ev):
        if isinstance(ev, InformationalResponse):
            return ev.status_code == 101 and b"upgrade" in self._pending      # N-000366..N-000368
        if isinstance(ev, Response):
            return 200 <= ev.status_code < 300 and b"CONNECT" in self._pending  # N-000364, N-000365
        return False

    def _accept(self):
        self._st[CLIENT] = SWITCHED_PROTOCOL
        self._st[SERVER] = SWITCHED_PROTOCOL
        self._pending = set()

    def _apply(self, sender, ev):
        """Advance the states for one event sent (sender == our role) or pulled (sender == peer).

        Raises _Violation, before changing anything, if the event is not legal here.
        """
        st = self._st
        us = self._our_role
        cur = st[sender]
        if isinstance(ev, Request):
            if sender is not CLIENT or cur is not IDLE:
                raise _Violation("a request is not allowed in this state")
            st[CLIENT] = SEND_BODY
            if st[SERVER] is IDLE:
                st[SERVER] = SEND_RESPONSE
            self._request_method = ev.method
            self._pending = _proposals(ev)
            self._expect = (ev.http_version == b"1.1"
                            and _has_token(ev.headers._items, b"expect", b"100-continue"))  # N-000354..N-000357
        elif isinstance(ev, InformationalResponse):
            if sender is not SERVER or cur is not SEND_RESPONSE:
                raise _Violation("an informational response is not allowed in this state")
            self._expect = False                                                # N-000358
            if self._accepts(ev):
                self._accept()
        elif isinstance(ev, Response):
            if sender is not SERVER or cur not in (IDLE, SEND_RESPONSE):
                raise _Violation("a response is not allowed in this state")
            self._expect = False                                                # N-000358
            if self._accepts(ev):
                self._accept()
            else:
                st[SERVER] = SEND_BODY
                if self._pending:
                    # Denial: the proposing side is DONE (N-000378..N-000380).
                    self._pending = set()
                    if st[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                        st[CLIENT] = DONE
        elif isinstance(ev, Data):
            if cur is not SEND_BODY:
                raise _Violation("body data is not allowed in this state")
            if sender is CLIENT:
                self._expect = False                                            # N-000359
        elif isinstance(ev, EndOfMessage):
            if cur is not SEND_BODY:
                raise _Violation("end-of-message is not allowed in this state")
            if sender is CLIENT:
                self._expect = False
                st[CLIENT] = MIGHT_SWITCH_PROTOCOL if self._pending else DONE  # N-000373..N-000377
            else:
                st[SERVER] = DONE
        elif isinstance(ev, ConnectionClosed):
            if cur not in (IDLE, DONE, MUST_CLOSE):
                raise _Violation("connection-closed is not allowed in this state")
            st[sender] = CLOSED
        if isinstance(ev, (Request, Response)) and _has_token(ev.headers._items, b"connection", b"close"):
            if sender is us:
                self._our_close = True
            else:
                self._their_close = True

    def _keep_alive_disabled(self):
        if self._our_close or self._their_close:
            return True
        return self._their_version is not None and self._their_version != b"1.1"  # N-000259..N-000264

    def _fire(self):
        """Triggered transitions, applied until nothing changes."""
        st = self._st
        changed = True
        while changed:
            changed = False
            for a, b in ((CLIENT, SERVER), (SERVER, CLIENT)):
                if st[a] is CLOSED and st[b] in (IDLE, DONE):
                    st[b] = MUST_CLOSE                                   # N-000336..N-000338
                    changed = True
                if st[a] is ERROR and st[b] is DONE:
                    st[b] = MUST_CLOSE                                   # N-000311
                    changed = True
            if self._keep_alive_disabled():
                for r in (CLIENT, SERVER):
                    if st[r] is DONE:
                        st[r] = MUST_CLOSE
                        changed = True

    # ----- pulling -------------------------------------------------------------------------

    def _fail(self, message, status=400):
        """Unrecoverable receive failure (N-000302..N-000306)."""
        self._st[self._their_role] = ERROR
        # The peer can no longer be kept alive, so our next response says Connection: close.
        self._their_close = True
        self._fire()
        raise RemoteProtocolError(message, status)

    def _pull_close(self):
        ev = ConnectionClosed()
        try:
            self._apply(self._their_role, ev)
        except _Violation as exc:
            self._fail(str(exc), exc.status)
        self._fire()
        return ev

    def _finish(self, sender, ev):
        try:
            self._apply(sender, ev)
        except _Violation as exc:
            self._fail(str(exc), exc.status)
        self._fire()
        return ev

    def _pull_request(self):
        buf = self._buf
        if buf[0] < 33:
            self._fail("request line starts with a space or control byte")   # N-000177..N-000179
        parsed = _wire.read_lines(buf)
        if parsed is None:
            if self._closed:
                self._fail("connection closed in the middle of a request")    # N-000324
            if len(buf) > self._limit:
                self._fail("incomplete request exceeds the size limit", 431)  # N-000316..N-000323
            return NEED_DATA
        lines, end = parsed
        try:
            method, target, version = _wire.parse_request_line(lines[0])
            pairs = _wire.parse_header_lines(lines[1:])
            ev = Request(method=method, target=target, headers=pairs, http_version=version)
        except (_Violation, LocalProtocolError) as exc:
            self._fail(str(exc), status_of(exc))
        del buf[:end]
        self._their_version = version
        self._finish(CLIENT, ev)
        self._recv_frame = _request_frame(ev.headers._items)
        return ev

    def _pull_response(self):
        buf = self._buf
        if buf and buf[0] < 33:
            self._fail("status line starts with a space or control byte")       # N-000177..N-000179
        parsed = _wire.read_lines(buf)
        if parsed is None:
            if self._closed:
                self._fail("connection closed in the middle of a response")     # N-000324
            if len(buf) > self._limit:
                self._fail("incomplete response exceeds the size limit", 431)   # N-000316..N-000323
            return NEED_DATA
        lines, end = parsed
        try:
            version, status, reason = _wire.parse_status_line(lines[0])
            pairs = _wire.parse_header_lines(lines[1:])
            if status < 200:
                ev = InformationalResponse(status_code=status, headers=pairs, http_version=version, reason=reason)
            else:
                ev = Response(status_code=status, headers=pairs, http_version=version, reason=reason)
        except (_Violation, LocalProtocolError) as exc:
            self._fail(str(exc), status_of(exc))
        del buf[:end]
        self._their_version = version
        if isinstance(ev, Response):
            self._recv_frame = self._response_frame(ev)
        self._finish(SERVER, ev)
        return ev

    def _response_frame(self, ev):
        items = ev.headers._items
        if self._request_method == b"HEAD" or ev.status_code in (204, 304):
            return _Frame("length", 0, True)                                     # N-000215..N-000218
        if _content_length(items) is not None:
            return _Frame("length", _content_length(items), False)
        if _has_header(items, b"transfer-encoding"):
            return _Frame("chunked", None, False)
        self._their_close = True                                                 # N-000208..N-000214
        return _Frame("close", None, False)

    def _pull_body(self):
        frame = self._recv_frame
        if frame.kind == "chunked":
            return self._pull_chunked()
        buf = self._buf
        if frame.kind == "length":
            if frame.remaining == 0:
                return self._body_done(EndOfMessage())                           # N-000190
            if not buf:
                if self._closed:
                    self._fail("connection closed in the middle of a Content-Length body")  # N-000324
                return NEED_DATA
            k = min(frame.remaining, len(buf))
            payload = bytes(buf[:k])
            del buf[:k]
            frame.remaining -= k
            return self._body_event(Data(payload))
        # close-delimited (N-000208..N-000214)
        if buf:
            payload = bytes(buf)
            del buf[:]
            return self._body_event(Data(payload))
        if self._closed:
            return self._body_done(EndOfMessage())
        return NEED_DATA

    def _body_event(self, ev):
        return self._finish(self._their_role, ev)

    def _body_done(self, ev):
        self._recv_frame = None
        return self._finish(self._their_role, ev)

    def _pull_chunked(self):
        buf = self._buf
        while True:
            cs = self._cs
            if cs == "size":
                nl = buf.find(b"\n")
                if nl < 0:
                    if _wire.hex_prefix_length(buf) > _wire.MAX_CHUNK_SIZE_DIGITS:
                        self._fail("chunk size has too many hexadecimal digits")  # N-000242
                    if self._closed:
                        self._fail("connection closed in the middle of a chunked body")  # N-000324
                    return NEED_DATA
                line = bytes(buf[:nl])
                if line.endswith(b"\r"):
                    line = line[:-1]
                del buf[:nl + 1]
                try:
                    size = _wire.parse_chunk_size(line)
                except _Violation as exc:
                    self._fail(str(exc), exc.status)
                if size == 0:
                    self._cs = "trailer"
                else:
                    self._cs = "data"
                    self._cleft = size
                    self._cfirst = True
                continue
            if cs == "data":
                if not buf:
                    if self._closed:
                        self._fail("connection closed in the middle of a chunk")  # N-000324
                    return NEED_DATA
                k = min(self._cleft, len(buf))
                payload = bytes(buf[:k])
                del buf[:k]
                self._cleft -= k
                start = self._cfirst
                self._cfirst = False
                end = self._cleft == 0
                if end:
                    self._cs = "crlf"
                # spec: N-000220..N-000227 — chunk marks on pulled data events.
                return self._body_event(Data(payload, chunk_start=start, chunk_end=end))
            if cs == "crlf":
                if len(buf) < 2:
                    if buf and buf[0] != 13:
                        self._fail("chunk data must be followed by CRLF")       # N-000244
                    if self._closed:
                        self._fail("connection closed in the middle of a chunked body")
                    return NEED_DATA
                if buf[0] != 13 or buf[1] != 10:
                    self._fail("chunk data must be followed by CRLF")           # N-000244
                del buf[:2]
                self._cs = "size"
                continue
            # trailer section after the zero-size chunk
            parsed = _wire.read_lines(buf)
            if parsed is None:
                if self._closed:
                    self._fail("connection closed in the middle of the trailer")
                if len(buf) > self._limit:
                    self._fail("trailer block exceeds the size limit", 431)
                return NEED_DATA
            lines, end = parsed
            try:
                ev = EndOfMessage(headers=_wire.parse_header_lines(lines))
            except (_Violation, LocalProtocolError) as exc:
                self._fail(str(exc), status_of(exc))
            del buf[:end]
            self._cs = "size"
            return self._body_done(ev)

