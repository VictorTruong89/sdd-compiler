import re
from collections.abc import Sequence

MAX_CONTENT_LENGTH_DIGITS = 18
MAX_CHUNK_SIZE_DIGITS = 32
DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 16 * 1024


class _Sentinel:
    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return self._name

    def __copy__(self):
        return self

    def __deepcopy__(self, memo):
        return self

    def __reduce__(self):
        return self._name


CLIENT = _Sentinel("CLIENT")
SERVER = _Sentinel("SERVER")
NEED_DATA = _Sentinel("NEED_DATA")
PAUSED = _Sentinel("PAUSED")
IDLE = _Sentinel("IDLE")
SEND_RESPONSE = _Sentinel("SEND_RESPONSE")
SEND_BODY = _Sentinel("SEND_BODY")
DONE = _Sentinel("DONE")
MUST_CLOSE = _Sentinel("MUST_CLOSE")
CLOSED = _Sentinel("CLOSED")
MIGHT_SWITCH_PROTOCOL = _Sentinel("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = _Sentinel("SWITCHED_PROTOCOL")
ERROR = _Sentinel("ERROR")
_SWITCH_UPGRADE = _Sentinel("_SWITCH_UPGRADE")
_SWITCH_CONNECT = _Sentinel("_SWITCH_CONNECT")


# ---------------------------------------------------------------- errors
class _ProtocolError(Exception):
    def __init__(self, msg, error_status_hint=400):
        if type(self) is _ProtocolError:
            raise TypeError("tried to directly instantiate _ProtocolError")
        Exception.__init__(self, msg)
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(_ProtocolError):
    def _reraise_as_remote_protocol_error(self):
        self.__class__ = RemoteProtocolError
        raise self


class RemoteProtocolError(_ProtocolError):
    pass


# ---------------------------------------------------------------- grammar
_token = r"[-!#$%&'*+.^_`|~0-9a-zA-Z]+"
_token_re = re.compile(_token.encode())
_target_re = re.compile(rb"[\x21-\x7e]+")
_value_re = re.compile(rb"(?:[^\x00\s](?:[^\x00\r\n\f\v]*[^\x00\s])?)?")
_cl_re = re.compile(rb"[0-9]+")
_request_line_re = re.compile(
    rb"(?P<method>" + _token.encode() + rb") (?P<target>[\x21-\x7e]+) HTTP/(?P<http_version>[0-9]\.[0-9])")
_status_line_re = re.compile(
    rb"HTTP/(?P<http_version>[0-9]\.[0-9]) (?P<status_code>[0-9]{3})(?: (?P<reason>[ \t\x21-\x7e\x80-\xff]*))?")
_header_field_re = re.compile(
    rb"(?P<name>" + _token.encode() + rb"):[ \t]*(?P<value>(?:[^\x00\s](?:[^\x00\r\n\f\v]*[^\x00\s])?)?)[ \t]*")
_chunk_header_re = re.compile(
    rb"(?P<size>[0-9a-fA-F]{1,%d})[ \t]*(?:;[^\r\n]*)?" % MAX_CHUNK_SIZE_DIGITS)


def _validate(regex, data, msg="malformed data"):
    m = regex.fullmatch(data)
    if not m:
        raise LocalProtocolError(msg)
    return m.groupdict()


def _bytesify(x, what="value"):
    if isinstance(x, bytes):
        return bytes(x)
    if isinstance(x, (bytearray, memoryview)):
        return bytes(x)
    if isinstance(x, str):
        try:
            return x.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("%s must be ASCII" % what)
    try:
        return bytes(memoryview(x))
    except TypeError:
        raise LocalProtocolError("expected bytes-like %s, got %r" % (what, type(x).__name__))


# ---------------------------------------------------------------- headers
class Headers(Sequence):
    __slots__ = ("_full_items",)

    def __init__(self, full_items):
        self._full_items = tuple(full_items)

    def __bool__(self):
        return bool(self._full_items)

    def __eq__(self, other):
        if isinstance(other, Headers):
            return self._full_items == other._full_items
        try:
            return list(self) == list(other)
        except TypeError:
            return NotImplemented

    __hash__ = None

    def __len__(self):
        return len(self._full_items)

    def __iter__(self):
        for _, name, value in self._full_items:
            yield (name, value)

    def __getitem__(self, idx):
        if isinstance(idx, slice):
            return [(n, v) for _, n, v in self._full_items[idx]]
        _, name, value = self._full_items[idx]
        return (name, value)

    def raw_items(self):
        return [(r, v) for r, _, v in self._full_items]

    def __repr__(self):
        return repr(list(self))


def normalize_and_validate(headers, _parsed=False):
    if isinstance(headers, Headers):
        headers = headers.raw_items()
    elif isinstance(headers, dict):
        headers = list(headers.items())
    elif isinstance(headers, (str, bytes, bytearray)):
        raise LocalProtocolError("headers must be a sequence of pairs")
    new = []
    seen_cl = None
    saw_te = False
    try:
        items = list(headers)
    except TypeError:
        raise LocalProtocolError("headers must be a sequence of pairs")
    for item in items:
        try:
            raw_name, value = item
        except (TypeError, ValueError):
            raise LocalProtocolError("each header must be a (name, value) pair")
        raw_name = _bytesify(raw_name, "header name")
        value = _bytesify(value, "header value")
        if not _token_re.fullmatch(raw_name):
            raise LocalProtocolError("illegal header name %r" % raw_name)
        if not _value_re.fullmatch(value):
            raise LocalProtocolError("illegal header value %r" % value)
        name = raw_name.lower()
        if name == b"content-length":
            lengths = {p.strip() for p in value.split(b",")}
            if len(lengths) != 1:
                raise LocalProtocolError("conflicting Content-Length headers")
            value = lengths.pop()
            if not _cl_re.fullmatch(value):
                raise LocalProtocolError("bad Content-Length")
            if len(value) > MAX_CONTENT_LENGTH_DIGITS:
                raise LocalProtocolError("Content-Length too long")
            if seen_cl is None:
                seen_cl = value
                new.append((raw_name, name, value))
            elif seen_cl != value:
                raise LocalProtocolError("conflicting Content-Length headers")
        elif name == b"transfer-encoding":
            if saw_te:
                raise LocalProtocolError("multiple Transfer-Encoding headers", error_status_hint=501)
            value = value.lower()
            if value != b"chunked":
                raise LocalProtocolError("only Transfer-Encoding: chunked is supported", error_status_hint=501)
            saw_te = True
            new.append((raw_name, name, value))
        else:
            new.append((raw_name, name, value))
    return Headers(new)


def get_comma_header(headers, name):
    out = []
    for _, found, value in headers._full_items:
        if found == name:
            for piece in value.lower().split(b","):
                piece = piece.strip()
                if piece:
                    out.append(piece)
    return out


def _title(name):
    return b"-".join(p.capitalize() for p in name.split(b"-"))


def set_comma_header(headers, name, new_values):
    new = [(r, v) for r, n, v in headers._full_items if n != name]
    for v in new_values:
        new.append((_title(name), v))
    return normalize_and_validate(new)


def delete_comma_header(headers, name):
    return Headers([(r, n, v) for r, n, v in headers._full_items if n != name])


# ---------------------------------------------------------------- events
class _Event:
    _fields = ()
    _required = ()

    def __init__(self, **kwargs):
        unknown = set(kwargs) - set(self._fields) - {"_parsed"}
        if unknown:
            raise LocalProtocolError("unexpected arguments: %s" % ", ".join(sorted(unknown)))
        for r in self._required:
            if r not in kwargs:
                raise LocalProtocolError("missing required argument %r" % r)
        self._build(**kwargs)

    def __repr__(self):
        return "%s(%s)" % (type(self).__name__, ", ".join(
            "%s=%r" % (f, getattr(self, f)) for f in self._fields))

    def __eq__(self, other):
        return type(other) is type(self) and all(
            getattr(self, f) == getattr(other, f) for f in self._fields)

    __hash__ = None


def _check_status(status_code, lo, hi):
    if not isinstance(status_code, int) or isinstance(status_code, bool):
        raise LocalProtocolError("status code must be an integer")
    status_code = int(status_code)
    if not (lo <= status_code < hi):
        raise LocalProtocolError("status code %d out of range" % status_code)
    return status_code


class Request(_Event):
    _fields = ("method", "target", "headers", "http_version")
    _required = ("method", "target", "headers")

    def _build(self, method, target, headers, http_version=b"1.1", _parsed=False):
        self.method = _bytesify(method, "method")
        self.target = _bytesify(target, "target")
        self.http_version = _bytesify(http_version, "http_version")
        self.headers = normalize_and_validate(headers, _parsed=_parsed)
        if not _token_re.fullmatch(self.method):
            raise LocalProtocolError("illegal method")
        if not _target_re.fullmatch(self.target):
            raise LocalProtocolError("illegal request target")
        hosts = [1 for _, n, _v in self.headers._full_items if n == b"host"]
        if len(hosts) > 1:
            raise LocalProtocolError("Found multiple Host headers")
        if self.http_version == b"1.1" and not hosts:
            raise LocalProtocolError("Missing mandatory Host: header")


class _ResponseBase(_Event):
    _fields = ("status_code", "headers", "http_version", "reason")
    _required = ("status_code", "headers")
    _lo = _hi = 0

    def _build(self, status_code, headers, http_version=b"1.1", reason=b"", _parsed=False):
        self.status_code = _check_status(status_code, self._lo, self._hi)
        self.http_version = _bytesify(http_version, "http_version")
        self.reason = _bytesify(reason, "reason")
        self.headers = normalize_and_validate(headers, _parsed=_parsed)


class InformationalResponse(_ResponseBase):
    _lo, _hi = 100, 200


class Response(_ResponseBase):
    _lo, _hi = 200, 1000


class Data(_Event):
    _fields = ("data", "chunk_start", "chunk_end")
    _required = ("data",)

    def _build(self, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)


class EndOfMessage(_Event):
    _fields = ("headers",)

    def _build(self, headers=None, _parsed=False):
        self.headers = normalize_and_validate([] if headers is None else headers, _parsed=_parsed)


class ConnectionClosed(_Event):
    pass


ConnectionClosed._build = lambda self: None


# ---------------------------------------------------------------- receive buffer
class _ReceiveBuffer:
    def __init__(self):
        self._data = bytearray()

    def __iadd__(self, data):
        self._data += data
        return self

    def __bool__(self):
        return bool(self._data)

    def __len__(self):
        return len(self._data)

    def __bytes__(self):
        return bytes(self._data)

    def _extract(self, n):
        out = bytes(self._data[:n])
        del self._data[:n]
        return out

    def at_most(self, count):
        if not self._data:
            return None
        return self._extract(count)

    def next_line(self):
        i = self._data.find(b"\r\n")
        if i < 0:
            return None
        return self._extract(i + 2)[:-2]

    def lines(self):
        d = self._data
        if d[:1] == b"\n":
            self._extract(1)
            return []
        if d[:2] == b"\r\n":
            self._extract(2)
            return []
        m = re.search(rb"\n\r?\n", d)
        if not m:
            return None
        block = self._extract(m.end())
        lines = block.split(b"\n")
        lines = [l[:-1] if l.endswith(b"\r") else l for l in lines]
        del lines[-2:]
        return lines

    def obviously_invalid_line(self):
        return bool(self._data) and self._data[0] < 0x21


# ---------------------------------------------------------------- readers
def _obs_fold(lines):
    last = None
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            if last is None:
                raise LocalProtocolError("continuation line at start of headers")
            last = bytes(last) + b" " + line.lstrip(b" \t")
        else:
            if last is not None:
                yield last
            last = line
    if last is not None:
        yield last


def _decode_header_lines(lines):
    for line in _obs_fold(lines):
        m = _validate(_header_field_re, bytes(line), "illegal header line")
        yield (m["name"], m["value"])


def _read_request(buf):
    lines = buf.lines()
    if lines is None:
        if buf.obviously_invalid_line():
            raise LocalProtocolError("illegal request line")
        return None
    if not lines:
        raise LocalProtocolError("no request line received")
    m = _validate(_request_line_re, lines[0], "illegal request line")
    return Request(headers=list(_decode_header_lines(lines[1:])), _parsed=True, **m)


def _read_response(buf):
    lines = buf.lines()
    if lines is None:
        if buf.obviously_invalid_line():
            raise LocalProtocolError("illegal status line")
        return None
    if not lines:
        raise LocalProtocolError("no response line received")
    m = _validate(_status_line_re, lines[0], "illegal status line")
    code = int(m["status_code"])
    cls = InformationalResponse if code < 200 else Response
    return cls(headers=list(_decode_header_lines(lines[1:])), _parsed=True,
               status_code=code, reason=m["reason"] or b"", http_version=m["http_version"])


def _expect_nothing(buf):
    if buf:
        raise LocalProtocolError("Got data when expecting EOF")
    return None


class _ContentLengthReader:
    def __init__(self, length):
        self._remaining = length

    def __call__(self, buf):
        if self._remaining == 0:
            return EndOfMessage()
        data = buf.at_most(self._remaining)
        if data is None:
            return None
        self._remaining -= len(data)
        return Data(data=data)

    def read_eof(self):
        raise RemoteProtocolError(
            "peer closed connection without sending complete message: %d bytes missing" % self._remaining)


class _ChunkedReader:
    def __init__(self):
        self._in_chunk = 0
        self._discard = 0
        self._trailer = False

    def __call__(self, buf):
        if self._trailer:
            lines = buf.lines()
            if lines is None:
                return None
            return EndOfMessage(headers=list(_decode_header_lines(lines)), _parsed=True)
        if self._discard > 0:
            n = min(len(buf), self._discard)
            if n == 0:
                return None
            expected = b"\r\n"[2 - self._discard:][:n]
            if bytes(buf._data[:n]) != expected:
                raise LocalProtocolError("chunk data not followed by CRLF")
            buf._extract(n)
            self._discard -= n
            if self._discard > 0:
                return None
        if self._in_chunk == 0:
            line = buf.next_line()
            if line is None:
                return None
            m = _validate(_chunk_header_re, line, "illegal chunk header")
            self._in_chunk = int(m["size"], 16)
            if self._in_chunk == 0:
                self._trailer = True
                return self(buf)
            start = True
        else:
            start = False
        data = buf.at_most(self._in_chunk)
        if data is None:
            return None
        self._in_chunk -= len(data)
        end = self._in_chunk == 0
        if end:
            self._discard = 2
        return Data(data=data, chunk_start=start, chunk_end=end)

    def read_eof(self):
        raise RemoteProtocolError("peer closed connection without sending complete message (chunked)")


class _Http10Reader:
    def __call__(self, buf):
        data = buf.at_most(999999999)
        if data is None:
            return None
        return Data(data=data)

    def read_eof(self):
        return EndOfMessage()


# ---------------------------------------------------------------- writers
def _write_headers(headers, write):
    items = headers._full_items
    for raw, name, value in items:
        if name == b"host":
            write(b"%s: %s\r\n" % (raw, value))
    for raw, name, value in items:
        if name != b"host":
            write(b"%s: %s\r\n" % (raw, value))
    write(b"\r\n")


def _write_request(request, write):
    if request.http_version != b"1.1":
        raise LocalProtocolError("I only send HTTP/1.1")
    write(b"%s %s HTTP/1.1\r\n" % (request.method, request.target))
    _write_headers(request.headers, write)


def _write_response(response, write):
    if response.http_version != b"1.1":
        raise LocalProtocolError("I only send HTTP/1.1")
    write(b"HTTP/1.1 %d %s\r\n" % (response.status_code, response.reason))
    _write_headers(response.headers, write)


class _BodyWriter:
    def __call__(self, event, write):
        if type(event) is Data:
            self.send_data(event.data, write)
        elif type(event) is EndOfMessage:
            self.send_eom(event.headers, write)
        else:
            raise LocalProtocolError("unexpected event in body")


class _ContentLengthWriter(_BodyWriter):
    def __init__(self, length):
        self._length = length

    def send_data(self, data, write):
        self._length -= len(data)
        if self._length < 0:
            raise LocalProtocolError("Too much data for declared Content-Length")
        write(data)

    def send_eom(self, headers, write):
        if self._length != 0:
            raise LocalProtocolError("Too little data for declared Content-Length")
        if headers:
            raise LocalProtocolError("Content-Length and trailers don't mix")


class _ChunkedWriter(_BodyWriter):
    def send_data(self, data, write):
        if not len(data):
            return
        write(b"%x\r\n" % len(data))
        write(data)
        write(b"\r\n")

    def send_eom(self, headers, write):
        write(b"0\r\n")
        _write_headers(headers, write)


class _Http10Writer(_BodyWriter):
    def send_data(self, data, write):
        write(data)

    def send_eom(self, headers, write):
        if headers:
            raise LocalProtocolError("can't send trailers to HTTP/1.0 client")


def _body_framing(request_method, event):
    if type(event) is Response:
        if (event.status_code in (204, 304) or request_method == b"HEAD"
                or (request_method == b"CONNECT" and 200 <= event.status_code < 300)):
            return ("content-length", (0,))
    if get_comma_header(event.headers, b"transfer-encoding"):
        return ("chunked", ())
    cls = get_comma_header(event.headers, b"content-length")
    if cls:
        return ("content-length", (int(cls[0]),))
    if type(event) is Request:
        return ("content-length", (0,))
    return ("http/1.0", ())


_WRITERS = {
    (CLIENT, IDLE): _write_request,
    (SERVER, IDLE): _write_response,
    (SERVER, SEND_RESPONSE): _write_response,
}
_READERS = {
    (CLIENT, IDLE): _read_request,
    (SERVER, IDLE): _read_response,
    (SERVER, SEND_RESPONSE): _read_response,
}
for _r in (CLIENT, SERVER):
    for _s in (DONE, MUST_CLOSE, CLOSED):
        _READERS[(_r, _s)] = _expect_nothing
_BODY_WRITERS = {"chunked": _ChunkedWriter, "content-length": _ContentLengthWriter, "http/1.0": _Http10Writer}
_BODY_READERS = {"chunked": _ChunkedReader, "content-length": _ContentLengthReader, "http/1.0": _Http10Reader}


# ---------------------------------------------------------------- state machine
_EVENT_TRANSITIONS = {
    CLIENT: {
        IDLE: {Request: SEND_BODY, ConnectionClosed: CLOSED},
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
        CLOSED: {ConnectionClosed: CLOSED},
        MIGHT_SWITCH_PROTOCOL: {},
        SWITCHED_PROTOCOL: {},
        ERROR: {},
    },
    SERVER: {
        IDLE: {ConnectionClosed: CLOSED, Response: SEND_BODY, (Request, CLIENT): SEND_RESPONSE},
        SEND_RESPONSE: {
            InformationalResponse: SEND_RESPONSE,
            Response: SEND_BODY,
            (InformationalResponse, _SWITCH_UPGRADE): SWITCHED_PROTOCOL,
            (Response, _SWITCH_CONNECT): SWITCHED_PROTOCOL,
        },
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
        CLOSED: {ConnectionClosed: CLOSED},
        SWITCHED_PROTOCOL: {},
        ERROR: {},
    },
}

_STATE_TRANSITIONS = {
    (MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL): {CLIENT: SWITCHED_PROTOCOL},
    (CLOSED, DONE): {SERVER: MUST_CLOSE},
    (CLOSED, IDLE): {SERVER: MUST_CLOSE},
    (ERROR, DONE): {SERVER: MUST_CLOSE},
    (DONE, CLOSED): {CLIENT: MUST_CLOSE},
    (IDLE, CLOSED): {CLIENT: MUST_CLOSE},
    (DONE, ERROR): {CLIENT: MUST_CLOSE},
}


class _ConnectionState:
    def __init__(self):
        self.keep_alive = True
        self.pending_switch_proposals = set()
        self.states = {CLIENT: IDLE, SERVER: IDLE}

    def process_error(self, role):
        self.states[role] = ERROR
        self._fire_state()

    def process_keep_alive_disabled(self):
        self.keep_alive = False
        self._fire_state()

    def process_client_switch_proposal(self, ev):
        self.pending_switch_proposals.add(ev)
        self._fire_state()

    def process_event(self, role, event_type, server_switch_event=None):
        _et = event_type
        if server_switch_event is not None:
            if server_switch_event not in self.pending_switch_proposals:
                raise LocalProtocolError("Received server switch event without a pending proposal")
            _et = (event_type, server_switch_event)
        if server_switch_event is None and _et is Response:
            self.pending_switch_proposals = set()
        self._fire_event(role, _et)
        if _et is Request:
            self._fire_event(SERVER, (Request, CLIENT))
        self._fire_state()

    def _fire_event(self, role, et):
        state = self.states[role]
        try:
            new = _EVENT_TRANSITIONS[role][state][et]
        except KeyError:
            name = et if isinstance(et, tuple) else getattr(et, "__name__", repr(et))
            raise LocalProtocolError("can't handle event type %s when role=%r and state=%r"
                                     % (name, role, state))
        self.states[role] = new

    def _fire_state(self):
        while True:
            start = dict(self.states)
            if self.pending_switch_proposals:
                if self.states[CLIENT] is DONE:
                    self.states[CLIENT] = MIGHT_SWITCH_PROTOCOL
            if not self.pending_switch_proposals:
                if self.states[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                    self.states[CLIENT] = DONE
            if not self.keep_alive:
                for r in (CLIENT, SERVER):
                    if self.states[r] is DONE:
                        self.states[r] = MUST_CLOSE
            joint = (self.states[CLIENT], self.states[SERVER])
            self.states.update(_STATE_TRANSITIONS.get(joint, {}))
            if self.states == start:
                return

    def start_next_cycle(self):
        if self.states != {CLIENT: DONE, SERVER: DONE}:
            raise LocalProtocolError("not in a reusable state")
        self.states = {CLIENT: IDLE, SERVER: IDLE}


# ---------------------------------------------------------------- connection
def _keep_alive(event):
    if b"close" in get_comma_header(event.headers, b"connection"):
        return False
    if getattr(event, "http_version", b"1.1") < b"1.1":
        return False
    return True


def _expects_100(request):
    if request.http_version < b"1.1":
        return False
    return b"100-continue" in get_comma_header(request.headers, b"expect")


class Connection:
    def __init__(self, our_role, max_incomplete_event_size=DEFAULT_MAX_INCOMPLETE_EVENT_SIZE):
        if our_role is not CLIENT and our_role is not SERVER:
            raise ValueError("expected CLIENT or SERVER, not %r" % (our_role,))
        self.our_role = our_role
        self.their_role = SERVER if our_role is CLIENT else CLIENT
        self._cstate = _ConnectionState()
        self._max = max_incomplete_event_size
        self._writer = self._get_io(self.our_role, None, True)
        self._reader = self._get_io(self.their_role, None, False)
        self._receive_buffer = _ReceiveBuffer()
        self._receive_buffer_closed = False
        self.their_http_version = None
        self._request_method = None
        self.client_is_waiting_for_100_continue = False

    @property
    def states(self):
        return dict(self._cstate.states)

    @property
    def our_state(self):
        return self._cstate.states[self.our_role]

    @property
    def their_state(self):
        return self._cstate.states[self.their_role]

    @property
    def they_are_waiting_for_100_continue(self):
        return self.their_role is CLIENT and self.client_is_waiting_for_100_continue

    @property
    def trailing_data(self):
        return (bytes(self._receive_buffer), self._receive_buffer_closed)

    def start_next_cycle(self):
        old = dict(self._cstate.states)
        self._cstate.start_next_cycle()
        self._request_method = None
        self.client_is_waiting_for_100_continue = False
        self._respond_to_state_changes(old)

    def send_failed(self):
        self._cstate.process_error(self.our_role)

    def receive_data(self, data):
        if data:
            if self._receive_buffer_closed:
                raise RuntimeError("received close, then received more data?")
            self._receive_buffer += data
        else:
            self._receive_buffer_closed = True

    def next_event(self):
        if self.their_state is ERROR:
            raise RemoteProtocolError("Can't receive data when peer state is ERROR")
        try:
            event = self._extract_next_receive_event()
            if event is not NEED_DATA and event is not PAUSED:
                self._process_event(self.their_role, event)
            if event is NEED_DATA:
                if len(self._receive_buffer) > self._max:
                    raise RemoteProtocolError("Receive buffer too long", error_status_hint=431)
                if self._receive_buffer_closed:
                    raise RemoteProtocolError("peer unexpectedly closed connection")
            return event
        except BaseException as exc:
            self._cstate.process_error(self.their_role)
            if isinstance(exc, LocalProtocolError):
                exc._reraise_as_remote_protocol_error()
            raise

    def send(self, event):
        parts = self.send_with_data_passthrough(event)
        if not parts:
            return b""
        return b"".join(parts)

    def send_with_data_passthrough(self, event):
        if self.our_state is ERROR:
            raise LocalProtocolError("Can't send data when our state is ERROR")
        try:
            if type(event) is Response:
                event = self._clean_up_response_headers_for_sending(event)
            writer = self._writer
            self._process_event(self.our_role, event)
            if type(event) is ConnectionClosed:
                return []
            out = []
            writer(event, out.append)
            return out
        except BaseException:
            self._cstate.process_error(self.our_role)
            raise

    # -- internals
    def _extract_next_receive_event(self):
        state = self.their_state
        if state is DONE and self._receive_buffer:
            return PAUSED
        if state is MIGHT_SWITCH_PROTOCOL or state is SWITCHED_PROTOCOL:
            return PAUSED
        event = self._reader(self._receive_buffer) if self._reader else None
        if event is None:
            if not self._receive_buffer and self._receive_buffer_closed:
                if hasattr(self._reader, "read_eof"):
                    event = self._reader.read_eof()
                else:
                    event = ConnectionClosed()
        if event is None:
            event = NEED_DATA
        return event

    def _get_io(self, role, event, writers):
        state = self._cstate.states[role]
        if state is SEND_BODY:
            framing, args = _body_framing(self._request_method, event)
            return (_BODY_WRITERS if writers else _BODY_READERS)[framing](*args)
        return (_WRITERS if writers else _READERS).get((role, state))

    def _server_switch_event(self, event):
        if type(event) is InformationalResponse and event.status_code == 101:
            return _SWITCH_UPGRADE
        if type(event) is Response:
            if _SWITCH_CONNECT in self._cstate.pending_switch_proposals and 200 <= event.status_code < 300:
                return _SWITCH_CONNECT
        return None

    def _process_event(self, role, event):
        old = dict(self._cstate.states)
        t = type(event)
        if role is CLIENT and t is Request:
            if event.method == b"CONNECT":
                self._cstate.process_client_switch_proposal(_SWITCH_CONNECT)
            if get_comma_header(event.headers, b"upgrade"):
                self._cstate.process_client_switch_proposal(_SWITCH_UPGRADE)
        sw = None
        if role is SERVER:
            sw = self._server_switch_event(event)
        self._cstate.process_event(role, t, sw)
        if t is Request:
            self._request_method = event.method
        if role is self.their_role and t in (Request, Response, InformationalResponse):
            self.their_http_version = event.http_version
        if t in (Request, Response) and not _keep_alive(event):
            self._cstate.process_keep_alive_disabled()
        if t is Request and _expects_100(event):
            self.client_is_waiting_for_100_continue = True
        if t in (InformationalResponse, Response):
            self.client_is_waiting_for_100_continue = False
        if role is CLIENT and t in (Data, EndOfMessage):
            self.client_is_waiting_for_100_continue = False
        self._respond_to_state_changes(old, event)

    def _respond_to_state_changes(self, old, event=None):
        new = self._cstate.states
        if new[self.our_role] != old[self.our_role]:
            self._writer = self._get_io(self.our_role, event, True)
        if new[self.their_role] != old[self.their_role]:
            self._reader = self._get_io(self.their_role, event, False)

    def _clean_up_response_headers_for_sending(self, response):
        headers = response.headers
        need_close = False
        method = self._request_method
        if method == b"HEAD":
            method = b"GET"
        framing, _ = _body_framing(method, response)
        if framing in ("chunked", "http/1.0"):
            headers = delete_comma_header(headers, b"content-length")
            if self.their_http_version is None or self.their_http_version < b"1.1":
                headers = delete_comma_header(headers, b"transfer-encoding")
                need_close = True
            else:
                headers = set_comma_header(headers, b"transfer-encoding", [b"chunked"])
        if not self._cstate.keep_alive or need_close or self.their_state is ERROR:
            conn = set(get_comma_header(headers, b"connection"))
            conn.discard(b"keep-alive")
            conn.add(b"close")
            headers = set_comma_header(headers, b"connection", sorted(conn))
        return Response(headers=headers, status_code=response.status_code,
                        http_version=response.http_version, reason=response.reason)
