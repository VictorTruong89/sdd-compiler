import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from httpwire import (  # noqa: E402
    CLIENT, SERVER, IDLE, SEND_BODY, SEND_RESPONSE, DONE, MUST_CLOSE, CLOSED,
    MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL, ERROR, NEED_DATA, PAUSED,
    Connection, ConnectionClosed, Data, EndOfMessage, InformationalResponse,
    LocalProtocolError, ReceiveAfterCloseError, RemoteProtocolError, Request, Response,
)


def pump(sender, receiver, event):
    """Send an event on sender and feed the bytes to receiver (no feed if nothing was sent)."""
    data = sender.send(event)
    if data:
        receiver.receive_data(data)
    return data


def pull_all(conn):
    out = []
    while True:
        ev = conn.next_event()
        if ev is NEED_DATA or ev is PAUSED:
            return out, ev
        out.append(ev)
        if isinstance(ev, ConnectionClosed):
            return out, None
        assert len(out) < 100, "pull loop did not terminate"


class ConstructionTests(unittest.TestCase):
    def test_request_defaults_and_bytes(self):
        r = Request(method="GET", target="/", headers=[("Host", "x")])
        self.assertEqual(r.method, b"GET")
        self.assertEqual(r.http_version, b"1.1")
        self.assertEqual(list(r.headers), [(b"host", b"x")])
        self.assertEqual(r.headers.raw_items(), [(b"Host", b"x")])

    def test_http11_requires_single_host(self):
        with self.assertRaises(LocalProtocolError):
            Request(method="GET", target="/", headers=[])
        with self.assertRaises(LocalProtocolError):
            Request(method="GET", target="/", headers=[("host", "a"), ("Host", "b")])
        Request(method="GET", target="/", headers=[], http_version="1.0")

    def test_bad_values_refused_with_status(self):
        with self.assertRaises(LocalProtocolError):
            Response(status_code=200, headers=[("x", " lead")])
        with self.assertRaises(LocalProtocolError):
            Response(status_code=200, headers=[("x", "a\x01b")])
        with self.assertRaises(LocalProtocolError):
            Response(status_code=99, headers=[])
        with self.assertRaises(LocalProtocolError):
            Response(status_code=200, headers=[("Transfer-Encoding", "gzip, chunked")])
        try:
            Response(status_code=200, headers=[("Transfer-Encoding", "gzip")])
        except LocalProtocolError as exc:
            self.assertEqual(exc.error_status_hint, 501)
        else:
            self.fail("gzip transfer coding should be refused")

    def test_transfer_encoding_and_content_length_normalization(self):
        r = Response(status_code=200, headers=[
            ("Transfer-Encoding", "CHUNKED"), ("Content-Length", "5"),
        ])
        self.assertEqual(list(r.headers), [(b"transfer-encoding", b"chunked"), (b"content-length", b"5")])
        r = Request(method="PUT", target="/", headers=[
            ("Host", "h"), ("Content-Length", "3, 3"), ("content-length", "3"),
        ])
        self.assertEqual(list(r.headers), [(b"host", b"h"), (b"content-length", b"3")])
        with self.assertRaises(LocalProtocolError):
            Request(method="PUT", target="/", headers=[("Host", "h"), ("Content-Length", "3, 4")])
        with self.assertRaises(LocalProtocolError):
            Request(method="PUT", target="/", headers=[("Host", "h"), ("Content-Length", "1" * 19)])
        with self.assertRaises(LocalProtocolError):
            Request(method="PUT", target="/", headers=[("Host", "h"), ("Transfer-Encoding", "chunked"),
                                                       ("Transfer-Encoding", "chunked")])

    def test_data_keeps_payload_identity(self):
        payload = bytearray(b"abc")
        d = Data(data=payload)
        self.assertIs(d.data, payload)
        self.assertIs(d.chunk_start, False)

    def test_connection_role_and_states(self):
        c = Connection(CLIENT)
        self.assertIs(c.our_role, CLIENT)
        self.assertIs(c.their_role, SERVER)
        self.assertIs(c.our_state, IDLE)
        self.assertIs(c.their_state, IDLE)
        with self.assertRaises(Exception):
            Connection("client")
        self.assertIsNone(c.their_http_version)
        self.assertIs(Connection(SERVER).next_event(), NEED_DATA)


class RoundTripTests(unittest.TestCase):
    def test_get_with_content_length_response(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        pump(c, s, Request(method="GET", target="/x", headers=[("Host", "h"), ("User-Agent", "t")]))
        self.assertIs(c.our_state, SEND_BODY)
        self.assertIs(s.our_state, IDLE)  # the server has not pulled the request yet
        pump(c, s, EndOfMessage())
        req = s.next_event()
        self.assertIsInstance(req, Request)
        self.assertIs(s.our_state, SEND_RESPONSE)
        self.assertEqual(req.target, b"/x")
        self.assertEqual(s.their_http_version, b"1.1")
        self.assertIsInstance(s.next_event(), EndOfMessage)
        self.assertIs(c.our_state, DONE)
        wire = pump(s, c, Response(status_code=200, headers=[("Content-Length", "2")], reason="OK"))
        self.assertTrue(wire.startswith(b"HTTP/1.1 200 OK\r\n"))
        self.assertIn(b"Content-Length: 2\r\n", wire)
        pump(s, c, Data(data=b"hi"))
        pump(s, c, EndOfMessage())
        events, last = pull_all(c)
        self.assertIsInstance(events[0], Response)
        self.assertEqual(events[0].status_code, 200)
        self.assertEqual(events[1], Data(data=b"hi"))
        self.assertIsInstance(events[2], EndOfMessage)
        self.assertIs(last, NEED_DATA)
        self.assertIs(c.their_state, DONE)
        self.assertIs(s.our_state, DONE)
        c.start_next_cycle()
        s.start_next_cycle()
        self.assertIs(c.our_state, IDLE)

    def test_host_first_and_raw_casing_on_wire(self):
        c = Connection(CLIENT)
        wire = c.send(Request(method="GET", target="/", headers=[("X-A", "1"), ("HOST", "h")]))
        self.assertEqual(wire, b"GET / HTTP/1.1\r\nHOST: h\r\nX-A: 1\r\n\r\n")

    def test_chunked_request_round_trip(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        pump(c, s, Request(method="POST", target="/", headers=[("Host", "h"), ("Transfer-Encoding", "chunked")]))
        s.next_event()
        pump(c, s, Data(data=b"hello"))
        pump(c, s, Data(data=b" world"))
        pump(c, s, EndOfMessage(headers=[("X-Trailer", "t")]))
        events, _ = pull_all(s)
        data = b"".join(e.data for e in events if isinstance(e, Data))
        self.assertEqual(data, b"hello world")
        self.assertIsInstance(events[-1], EndOfMessage)
        self.assertEqual(list(events[-1].headers), [(b"x-trailer", b"t")])
        self.assertIs(s.their_state, DONE)

    def test_chunk_marks_and_split_pieces(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n")
        s.next_event()
        s.receive_data(b"5\r\nhel")
        d1 = s.next_event()
        self.assertEqual((d1.data, d1.chunk_start, d1.chunk_end), (b"hel", True, False))
        self.assertIs(s.next_event(), NEED_DATA)
        s.receive_data(b"lo\r\n3;ext=1  \r\nabc\r\n0\r\n\r\n")
        d2 = s.next_event()
        self.assertEqual((d2.data, d2.chunk_start, d2.chunk_end), (b"lo", False, True))
        d3 = s.next_event()
        self.assertEqual((d3.data, d3.chunk_start, d3.chunk_end), (b"abc", True, True))
        self.assertIsInstance(s.next_event(), EndOfMessage)

    def test_passthrough_keeps_placeholder_object(self):
        c = Connection(CLIENT)
        c.send(Request(method="PUT", target="/", headers=[("Host", "h"), ("Content-Length", "4")]))
        blob = memoryview(b"abcd")
        pieces = c.send_with_data_passthrough(Data(data=blob))
        self.assertIs(pieces[-1], blob)
        self.assertEqual(c.send_with_data_passthrough(EndOfMessage()), [])

    def test_passthrough_chunked_framing_pieces(self):
        c = Connection(CLIENT)
        c.send(Request(method="PUT", target="/", headers=[("Host", "h"), ("Transfer-Encoding", "chunked")]))
        blob = memoryview(b"abcd")
        pieces = c.send_with_data_passthrough(Data(data=blob))
        self.assertIs(pieces[1], blob)
        self.assertEqual(b"".join(bytes(p) for p in pieces), b"4\r\nabcd\r\n")


class FramingAndLimitTests(unittest.TestCase):
    def test_content_length_mismatch_is_local_error_and_state_error(self):
        c = Connection(CLIENT)
        c.send(Request(method="PUT", target="/", headers=[("Host", "h"), ("Content-Length", "2")]))
        with self.assertRaises(LocalProtocolError):
            c.send(Data(data=b"abc"))
        self.assertIs(c.our_state, ERROR)
        with self.assertRaises(LocalProtocolError):
            c.send(EndOfMessage())

    def test_remote_bad_request_line_fails_at_once(self):
        s = Connection(SERVER)
        s.receive_data(b" GET / HTTP/1.1\r\n")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()
        self.assertIs(s.their_state, ERROR)
        self.assertIs(s.our_state, IDLE)
        with self.assertRaises(RemoteProtocolError):
            s.next_event()
        wire = s.send(Response(status_code=400, headers=[("Content-Length", "0")]))
        self.assertIn(b"Connection: close\r\n", wire)

    def test_size_limit_gives_431(self):
        s = Connection(SERVER, 100)
        s.receive_data(b"GET / HTTP/1.1\r\nX: " + b"a" * 200)
        with self.assertRaises(RemoteProtocolError) as ctx:
            s.next_event()
        self.assertEqual(ctx.exception.error_status_hint, 431)

    def test_default_size_limit_applies(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nX: " + b"a" * (20 * 1024))
        with self.assertRaises(RemoteProtocolError) as ctx:
            s.next_event()
        self.assertEqual(ctx.exception.error_status_hint, 431)

    def test_receive_after_close(self):
        s = Connection(SERVER)
        s.receive_data(b"")
        with self.assertRaises(ReceiveAfterCloseError):
            s.receive_data(b"GET")
        self.assertIsInstance(s.next_event(), ConnectionClosed)

    def test_close_mid_body_is_remote_error(self):
        s = Connection(SERVER)
        s.receive_data(b"PUT / HTTP/1.1\r\nHost: h\r\nContent-Length: 5\r\n\r\nab")
        s.next_event()
        s.next_event()
        s.receive_data(b"")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    def test_line_folding_and_lone_lf_accepted(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\nHost: h\nX-Long: a\n   b\n\n")
        req = s.next_event()
        self.assertEqual(dict(req.headers)[b"x-long"], b"a b")

    def test_bad_chunk_crlf_is_remote(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n1\r\nab\r\n0\r\n\r\n")
        s.next_event()
        self.assertEqual(s.next_event().data, b"a")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    def test_head_response_has_no_body(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        pump(c, s, Request(method="HEAD", target="/", headers=[("Host", "h")]))
        pump(c, s, EndOfMessage())
        s.next_event()
        s.next_event()
        wire = pump(s, c, Response(status_code=200, headers=[]))
        self.assertIn(b"Transfer-Encoding: chunked\r\n", wire)
        self.assertEqual(s.send(EndOfMessage()), b"")
        self.assertIs(s.our_state, DONE)


class KeepAliveAndCycleTests(unittest.TestCase):
    def test_http10_peer_closes_after_one_cycle(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.0\r\n\r\n")
        self.assertIsInstance(s.next_event(), Request)
        self.assertIsInstance(s.next_event(), EndOfMessage)
        self.assertEqual(s.their_http_version, b"1.0")
        wire = s.send(Response(status_code=200, headers=[("Content-Length", "2")]))
        self.assertIn(b"Connection: close\r\n", wire)
        s.send(Data(data=b"ok"))
        s.send(EndOfMessage())
        self.assertIs(s.our_state, MUST_CLOSE)
        self.assertIs(s.their_state, MUST_CLOSE)
        with self.assertRaises(LocalProtocolError):
            s.start_next_cycle()
        s.send(ConnectionClosed())
        self.assertIs(s.our_state, CLOSED)

    def test_http10_response_close_delimited(self):
        c = Connection(CLIENT)
        c.send(Request(method="GET", target="/", headers=[("Host", "h")]))
        c.send(EndOfMessage())
        c.receive_data(b"HTTP/1.0 200 OK\r\n\r\n")
        self.assertIsInstance(c.next_event(), Response)
        self.assertEqual(c.their_http_version, b"1.0")
        self.assertIs(c.next_event(), NEED_DATA)
        c.receive_data(b"raw body")
        self.assertEqual(c.next_event().data, b"raw body")
        c.receive_data(b"")
        self.assertIsInstance(c.next_event(), EndOfMessage)
        self.assertIs(c.their_state, MUST_CLOSE)
        self.assertIsInstance(c.next_event(), ConnectionClosed)
        self.assertIs(c.their_state, CLOSED)

    def test_connection_close_request_disables_reuse(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        pump(c, s, Request(method="GET", target="/", headers=[("Host", "h"), ("Connection", "Close")]))
        pump(c, s, EndOfMessage())
        s.next_event()
        s.next_event()
        pump(s, c, Response(status_code=200, headers=[("Content-Length", "0")]))
        pump(s, c, EndOfMessage())
        pull_all(c)
        self.assertIs(c.our_state, MUST_CLOSE)
        self.assertIs(s.our_state, MUST_CLOSE)
        with self.assertRaises(LocalProtocolError):
            c.start_next_cycle()

    def test_pipelined_request_is_paused_then_parsed(self):
        s = Connection(SERVER)
        c = Connection(CLIENT)
        pump(c, s, Request(method="GET", target="/1", headers=[("Host", "h")]))
        pump(c, s, EndOfMessage())
        s.receive_data(b"GET /2 HTTP/1.1\r\nHost: h\r\n\r\n")
        self.assertIsInstance(s.next_event(), Request)
        self.assertIsInstance(s.next_event(), EndOfMessage)
        self.assertIs(s.next_event(), PAUSED)
        pump(s, c, Response(status_code=200, headers=[("Content-Length", "0")]))
        pump(s, c, EndOfMessage())
        self.assertIs(s.next_event(), PAUSED)
        pull_all(c)
        s.start_next_cycle()
        self.assertIsInstance(s.next_event(), Request)

    def test_client_second_request_refused_and_errors(self):
        c = Connection(CLIENT)
        c.send(Request(method="GET", target="/", headers=[("Host", "h")]))
        with self.assertRaises(LocalProtocolError):
            c.send(Request(method="GET", target="/", headers=[("Host", "h")]))
        self.assertIs(c.our_state, ERROR)


class SwitchTests(unittest.TestCase):
    def test_expect_100_continue_flags(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        pump(c, s, Request(method="PUT", target="/", headers=[("Host", "h"), ("Content-Length", "1"),
                                                             ("Expect", "100-Continue")]))
        self.assertTrue(c.client_is_waiting_for_100_continue)
        self.assertFalse(c.they_are_waiting_for_100_continue)
        s.next_event()
        self.assertTrue(s.they_are_waiting_for_100_continue)
        pump(s, c, InformationalResponse(status_code=100))
        self.assertFalse(s.client_is_waiting_for_100_continue)
        self.assertFalse(s.they_are_waiting_for_100_continue)
        self.assertIsInstance(c.next_event(), InformationalResponse)
        self.assertFalse(c.client_is_waiting_for_100_continue)
        pump(c, s, Data(data=b"x"))
        pump(c, s, EndOfMessage())
        self.assertIsInstance(s.next_event(), Data)

    def test_expect_on_http10_sets_no_flag(self):
        s = Connection(SERVER)
        s.receive_data(b"PUT / HTTP/1.0\r\nContent-Length: 0\r\nExpect: 100-continue\r\n\r\n")
        self.assertIsInstance(s.next_event(), Request)
        self.assertFalse(s.they_are_waiting_for_100_continue)
        self.assertFalse(s.client_is_waiting_for_100_continue)

    def test_connect_accepted_switches_and_keeps_trailing_data(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        pump(c, s, Request(method="CONNECT", target="example:443", headers=[("Host", "example:443")]))
        pump(c, s, EndOfMessage())
        self.assertIs(c.our_state, MIGHT_SWITCH_PROTOCOL)
        s.next_event()
        s.next_event()
        self.assertIs(s.their_state, MIGHT_SWITCH_PROTOCOL)
        self.assertIs(s.next_event(), PAUSED)
        pump(s, c, Response(status_code=200, headers=[]))
        self.assertIs(s.our_state, SWITCHED_PROTOCOL)
        self.assertIs(s.their_state, SWITCHED_PROTOCOL)
        events, _ = pull_all(c)
        self.assertIsInstance(events[0], Response)
        self.assertIs(c.our_state, SWITCHED_PROTOCOL)
        c.receive_data(b"\x16\x03raw")
        self.assertIs(c.next_event(), PAUSED)
        self.assertEqual(c.trailing_data, (b"\x16\x03raw", False))
        with self.assertRaises(LocalProtocolError):
            s.send(EndOfMessage())

    def test_connect_denied_returns_to_http(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        pump(c, s, Request(method="CONNECT", target="example:443", headers=[("Host", "e")]))
        pump(c, s, EndOfMessage())
        s.next_event()
        s.next_event()
        pump(s, c, Response(status_code=407, headers=[("Content-Length", "0")]))
        pump(s, c, EndOfMessage())
        events, _ = pull_all(c)
        self.assertIsInstance(events[0], Response)
        self.assertIs(c.our_state, DONE)
        self.assertIs(c.their_state, DONE)
        c.start_next_cycle()
        s.start_next_cycle()

    def test_upgrade_101_accepts(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        pump(c, s, Request(method="GET", target="/ws", headers=[("Host", "h"), ("Upgrade", "websocket"),
                                                               ("Connection", "Upgrade")]))
        pump(c, s, EndOfMessage())
        s.next_event()
        s.next_event()
        pump(s, c, InformationalResponse(status_code=101, headers=[("Upgrade", "websocket")]))
        self.assertIs(s.our_state, SWITCHED_PROTOCOL)
        events, _ = pull_all(c)
        self.assertIsInstance(events[0], InformationalResponse)
        self.assertIs(c.our_state, SWITCHED_PROTOCOL)

    def test_send_connection_closed_in_send_body_is_local_error(self):
        c = Connection(CLIENT)
        c.send(Request(method="PUT", target="/", headers=[("Host", "h"), ("Content-Length", "1")]))
        with self.assertRaises(LocalProtocolError):
            c.send(ConnectionClosed())

    def test_client_closes_idle_and_server_sees_close(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        self.assertEqual(c.send(ConnectionClosed()), b"")
        self.assertIs(c.our_state, CLOSED)
        s.receive_data(b"")
        self.assertIsInstance(s.next_event(), ConnectionClosed)
        self.assertIs(s.their_state, CLOSED)


if __name__ == "__main__":
    unittest.main()
