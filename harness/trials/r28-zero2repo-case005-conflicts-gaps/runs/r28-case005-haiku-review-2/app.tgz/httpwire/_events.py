"""HTTP event types (PRD FP-01) and header-list normalization."""

import re

from ._common import LocalProtocolError, RemoteProtocolError

TOKEN_RE = re.compile(rb"[!#$%&'*+\-.^_`|~0-9A-Za-z]+\Z")
_TARGET_RE = re.compile(rb"[\x21-\x7e]+\Z")
_VERSION_RE = re.compile(rb"[0-9]\.[0-9]\Z")
_DIGITS_RE = re.compile(rb"[0-9]+\Z")
# Control bytes other than tab, plus DEL. CR, LF, FF, VT and NUL are included.
BAD_CONTROL_RE = re.compile(rb"[\x00-\x08\x0a-\x1f\x7f]")

# Resolves Full_PRD FP-01 ("every value of at most 18 digits is accepted")
# over the contract's 16-digit figure; see NOTES.md.
MAX_CONTENT_LENGTH_DIGITS = 18

CONTENT_LENGTH = b"content-length"
TRANSFER_ENCODING = b"transfer-encoding"
CONNECTION = b"connection"
HOST = b"host"
EXPECT = b"expect"
UPGRADE = b"upgrade"


def _to_bytes(value, what, err):
    if isinstance(value, bytes):
        return value
    if isinstance(value, str):
        try:
            return value.encode("ascii")
        except UnicodeEncodeError:
            raise err("%s must be ASCII text" % what)
    try:
        return bytes(memoryview(value))
    except TypeError:
        raise err("%s must be text or a bytes-like object" % what)


def _check_value(value, err):
    if BAD_CONTROL_RE.search(value):
        raise err("header value contains a forbidden control byte")
    if value[:1] in (b" ", b"\t") or value[-1:] in (b" ", b"\t"):
        raise err("header value begins or ends with a space or tab")


def _collapse(triples, err):
    """Normalize Content-Length and Transfer-Encoding on a list of (raw, lower, value)."""
    pieces = []
    te_count = 0
    for raw_name, lname, value in triples:
        if lname == CONTENT_LENGTH:
            for piece in value.split(b","):
                piece = piece.strip(b" \t")
                if _DIGITS_RE.match(piece) is None:
                    raise err("Content-Length must be a decimal integer")
                if len(piece) > MAX_CONTENT_LENGTH_DIGITS:
                    raise err("Content-Length has too many digits")
                pieces.append(piece)
        elif lname == TRANSFER_ENCODING:
            te_count += 1
            if te_count > 1:
                raise err("more than one Transfer-Encoding header", 501)
            if value.lower() != b"chunked":
                raise err("only the chunked transfer coding is supported", 501)
    if pieces and len(set(int(p) for p in pieces)) > 1:
        raise err("conflicting Content-Length values")

    out = []
    seen_length = False
    for raw_name, lname, value in triples:
        if lname == CONTENT_LENGTH:
            if not seen_length:
                out.append((raw_name, CONTENT_LENGTH, pieces[0]))
                seen_length = True
        elif lname == TRANSFER_ENCODING:
            out.append((raw_name, TRANSFER_ENCODING, b"chunked"))
        else:
            out.append((raw_name, lname, value))
    return out


def _normalize(pairs, err):
    """Turn (name, value) pairs into a list of (raw_name, lower_name, value) triples."""
    triples = []
    for pair in pairs:
        try:
            name, value = pair
        except (TypeError, ValueError):
            raise err("each header must be a (name, value) pair")
        raw_name = _to_bytes(name, "header name", err)
        value = _to_bytes(value, "header value", err)
        if TOKEN_RE.match(raw_name) is None:
            raise err("header name is not an RFC 7230 token")
        _check_value(value, err)
        triples.append((raw_name, raw_name.lower(), value))
    return _collapse(triples, err)


def _pairs_of(headers):
    if headers is None:
        return []
    if isinstance(headers, Headers):
        return headers.raw_items()
    return headers


def _check_status(value, low, high, err):
    if isinstance(value, bool) or not isinstance(value, int):
        raise err("status code must be an integer")
    value = int(value)
    if not low <= value < high:
        raise err("status code %d is out of range" % value)
    return value


class Headers(object):
    """Ordered header list. Iterates as lowercase (name, value); raw_items() keeps caller casing."""

    __slots__ = ("_triples",)

    def __init__(self, triples):
        self._triples = list(triples)

    def __iter__(self):
        return iter([(t[1], t[2]) for t in self._triples])

    def __len__(self):
        return len(self._triples)

    def __getitem__(self, index):
        return [(t[1], t[2]) for t in self._triples][index]

    def raw_items(self):
        return [(t[0], t[2]) for t in self._triples]

    def __eq__(self, other):
        try:
            other_items = [tuple(item) for item in other]
        except TypeError:
            return NotImplemented
        return list(self) == other_items

    def __ne__(self, other):
        result = self.__eq__(other)
        return result if result is NotImplemented else not result

    __hash__ = None

    def __repr__(self):
        return "Headers(%r)" % (list(self),)


class _Event(object):
    _fields = ()

    def __eq__(self, other):
        if type(other) is not type(self):
            return NotImplemented
        return all(getattr(self, f) == getattr(other, f) for f in self._fields)

    def __ne__(self, other):
        result = self.__eq__(other)
        return result if result is NotImplemented else not result

    __hash__ = None

    def __repr__(self):
        args = ", ".join("%s=%r" % (f, getattr(self, f)) for f in self._fields)
        return "%s(%s)" % (type(self).__name__, args)

    @classmethod
    def _from_wire(cls, *args):
        event = cls.__new__(cls)
        event._init(*(args + (RemoteProtocolError,)))
        return event


class Request(_Event):
    _fields = ("method", "target", "headers", "http_version")

    def __init__(self, method, target, headers=(), http_version=b"1.1"):
        self._init(method, target, headers, http_version, LocalProtocolError)

    def _init(self, method, target, headers, http_version, err):
        method = _to_bytes(method, "method", err)
        if TOKEN_RE.match(method) is None:
            raise err("method must be a single RFC 7230 token")
        target = _to_bytes(target, "request target", err)
        if _TARGET_RE.match(target) is None:
            raise err("request target must be visible ASCII")
        http_version = _to_bytes(http_version, "HTTP version", err)
        if _VERSION_RE.match(http_version) is None:
            raise err("HTTP version must look like 1.1")
        triples = _normalize(_pairs_of(headers), err)
        hosts = sum(1 for t in triples if t[1] == HOST)
        if hosts > 1:
            raise err("request has more than one Host header")
        if hosts == 0 and http_version == b"1.1":
            raise err("HTTP/1.1 request requires a Host header")
        self.method = method
        self.target = target
        self.http_version = http_version
        self.headers = Headers(triples)


class _Response(_Event):
    _fields = ("status_code", "headers", "http_version", "reason")
    _low = 0
    _high = 0

    def __init__(self, status_code, headers=(), http_version=b"1.1", reason=b""):
        self._init(status_code, headers, http_version, reason, LocalProtocolError)

    def _init(self, status_code, headers, http_version, reason, err):
        self.status_code = _check_status(status_code, self._low, self._high, err)
        http_version = _to_bytes(http_version, "HTTP version", err)
        if _VERSION_RE.match(http_version) is None:
            raise err("HTTP version must look like 1.1")
        reason = _to_bytes(reason, "reason phrase", err)
        if BAD_CONTROL_RE.search(reason):
            raise err("reason phrase contains a forbidden control byte")
        self.http_version = http_version
        self.reason = reason
        self.headers = Headers(_normalize(_pairs_of(headers), err))


class InformationalResponse(_Response):
    _low = 100
    _high = 200


class Response(_Response):
    _low = 200
    _high = 1000


class Data(_Event):
    _fields = ("data", "chunk_start", "chunk_end")

    def __init__(self, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)


class EndOfMessage(_Event):
    _fields = ("headers",)

    def __init__(self, headers=()):
        self._init(headers, LocalProtocolError)

    def _init(self, headers, err):
        self.headers = Headers(_normalize(_pairs_of(headers), err))


class ConnectionClosed(_Event):
    _fields = ()

    def __init__(self):
        pass
