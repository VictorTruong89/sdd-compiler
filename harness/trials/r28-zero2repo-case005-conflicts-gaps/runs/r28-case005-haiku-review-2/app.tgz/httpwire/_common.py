"""Shared sentinels, roles, states and protocol-error classes."""


class _Named(object):
    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return self._name


class _Role(_Named):
    __slots__ = ()


class _State(_Named):
    __slots__ = ()


class _Sentinel(_Named):
    __slots__ = ()


CLIENT = _Role("CLIENT")
SERVER = _Role("SERVER")

IDLE = _State("IDLE")
SEND_RESPONSE = _State("SEND_RESPONSE")
SEND_BODY = _State("SEND_BODY")
DONE = _State("DONE")
MUST_CLOSE = _State("MUST_CLOSE")
CLOSED = _State("CLOSED")
MIGHT_SWITCH_PROTOCOL = _State("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = _State("SWITCHED_PROTOCOL")
ERROR = _State("ERROR")

NEED_DATA = _Sentinel("NEED_DATA")
PAUSED = _Sentinel("PAUSED")

# PRD FP-05 requires a default in [14 KiB, 18 KiB); the contract's 8 KiB
# default contradicts that, so the PRD range is followed (see NOTES.md).
DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 16 * 1024


class ProtocolError(Exception):
    """Common base of the two protocol-error kinds. Carries a suggested status."""

    def __init__(self, message="", error_status_hint=400):
        Exception.__init__(self, message)
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(ProtocolError):
    """The integrator's own event or send violated HTTP/1.1."""


class RemoteProtocolError(ProtocolError):
    """The peer's bytes violated HTTP/1.1."""


class ReceiveAfterCloseError(RuntimeError):
    """Non-empty bytes were fed after the receive side had already been closed."""
