"""The HTTP/1.1 connection state machine (PRD FP-02..FP-07).

Each Connection keeps the state of both roles. Sending an event updates our
role; pulling an event updates the peer's role; some transitions (requests,
switch acceptance, post-processing rules) touch both.
"""

from ._common import (
    CLIENT, SERVER, IDLE, SEND_RESPONSE, SEND_BODY, DONE, MUST_CLOSE, CLOSED,
    MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL, ERROR, NEED_DATA, PAUSED,
    DEFAULT_MAX_INCOMPLETE_EVENT_SIZE, LocalProtocolError, RemoteProtocolError,
    ReceiveAfterCloseError,
)
from ._events import (
    Request, InformationalResponse, Response, Data, EndOfMessage, ConnectionClosed,
    CONTENT_LENGTH, TRANSFER_ENCODING, CONNECTION, HOST, EXPECT, UPGRADE,
)
from ._parse import (
    CHUNK_SIZE_RE, split_head, parse_request_line, parse_status_line, parse_header_lines,
)

_EVENT_TYPES = (Request, InformationalResponse, Response, Data, EndOfMessage, ConnectionClosed)
_ACCEPT = "accept"
_DENY = "deny"
_NORMAL = "normal"


class _Body(object):
    """Framing of one message body, plus chunked-decoding progress."""

    __slots__ = ("mode", "remaining", "chunk_state", "chunk_left", "piece_start")

    def __init__(self, mode, length=0):
        self.mode = mode  # "length", "chunked" or "eof"
        self.remaining = length
        self.chunk_state = "size"  # chunked decoding only: size, data, crlf, trailers
        self.chunk_left = 0
        self.piece_start = True


# ---------------------------------------------------------------- helpers

def _find(triples, lname):
    for t in triples:
        if t[1] == lname:
            return t[2]
    return None


def _has(triples, lname):
    return any(t[1] == lname for t in triples)


def _tokens(triples, lname):
    out = []
    for t in triples:
        if t[1] == lname:
            for part in t[2].split(b","):
                token = part.strip(b" \t").lower()
                if token:
                    out.append(token)
    return out


def _request_framing(triples):
    length = _find(triples, CONTENT_LENGTH)
    if length is not None:
        return _Body("length", int(length))
    if _has(triples, TRANSFER_ENCODING):
        return _Body("chunked")
    return _Body("length", 0)


def _response_framing(triples, request_method, status):
    if request_method == b"HEAD" or status in (204, 304):
        return _Body("length", 0)
    if _has(triples, TRANSFER_ENCODING):
        return _Body("chunked")
    length = _find(triples, CONTENT_LENGTH)
    if length is not None:
        return _Body("length", int(length))
    return _Body("eof")


def _ka_disables(event, framing):
    """Whether this request/response, by itself, rules out keep-alive for the cycle."""
    triples = event.headers._triples
    if event.http_version != b"1.1" or b"close" in _tokens(triples, CONNECTION):
        return True
    if type(event) is Response and framing is not None and framing.mode == "eof":
        return True
    return False


def _rewrite_connection(triples):
    """Replace Connection headers with one that ends in `close` and drops keep-alive."""
    kept = []
    rest = []
    for t in triples:
        if t[1] == CONNECTION:
            for part in t[2].split(b","):
                token = part.strip(b" \t")
                if token and token.lower() not in (b"keep-alive", b"close") and token not in kept:
                    kept.append(token)
        else:
            rest.append(t)
    kept.append(b"close")
    rest.append((b"Connection", CONNECTION, b", ".join(kept)))
    return rest


def _encode_head(first_line, triples):
    parts = [first_line]
    for raw_name, _lname, value in triples:
        parts.append(raw_name + b": " + value + b"\r\n")
    parts.append(b"\r\n")
    return b"".join(parts)


def _status_line(event):
    return (b"HTTP/1.1 " + str(event.status_code).encode("ascii") + b" "
            + event.reason + b"\r\n")


def _payload_length(payload):
    try:
        return memoryview(payload).nbytes
    except TypeError:
        return len(payload)


def _is_buffer(obj):
    try:
        memoryview(obj)
    except TypeError:
        return False
    return True


def _piece_bytes(piece):
    if isinstance(piece, bytes):
        return piece
    return bytes(memoryview(piece))


def _settle(states, ka_off):
    """Post-transition rules that apply to both sides (PRD FP-04, FP-05, FP-06)."""
    if ka_off:
        for role in (CLIENT, SERVER):
            if states[role] is DONE:
                states[role] = MUST_CLOSE
    for role in (CLIENT, SERVER):
        other = SERVER if role is CLIENT else CLIENT
        if states[role] is ERROR and states[other] is DONE:
            states[other] = MUST_CLOSE
        if states[role] is CLOSED and (states[other] is IDLE or states[other] is DONE):
            states[other] = MUST_CLOSE
    return states


# ------------------------------------------------------------- Connection

class Connection(object):
    """One HTTP/1.1 connection in the CLIENT or SERVER role. Performs no I/O."""

    def __init__(self, role, max_incomplete_event_size=DEFAULT_MAX_INCOMPLETE_EVENT_SIZE):
        if role is not CLIENT and role is not SERVER:
            raise ValueError("role must be CLIENT or SERVER")
        self.our_role = role
        self.their_role = SERVER if role is CLIENT else CLIENT
        self._max_incomplete = int(max_incomplete_event_size)
        self._states = {CLIENT: IDLE, SERVER: IDLE}
        self._buffer = bytearray()
        self._closed = False
        self._their_version = None
        self._reset_cycle()

    def _reset_cycle(self):
        self._ka_off = False
        self._pending_connect = False
        self._pending_upgrade = False
        self._request_method = None
        self._client_waiting = False
        self._they_waiting = False
        self._send_body = None
        self._recv_body = None

    # ---- queryable attributes

    @property
    def our_state(self):
        return self._states[self.our_role]

    @property
    def their_state(self):
        return self._states[self.their_role]

    @property
    def states(self):
        return dict(self._states)

    @property
    def their_http_version(self):
        return self._their_version

    @property
    def client_is_waiting_for_100_continue(self):
        return bool(self._client_waiting)

    @property
    def they_are_waiting_for_100_continue(self):
        return bool(self._they_waiting)

    @property
    def trailing_data(self):
        return (bytes(self._buffer), bool(self._closed))

    # ---- receive side

    def receive_data(self, data):
        chunk = bytes(memoryview(data))
        if not chunk:
            self._closed = True
            return None
        if self._closed and self._states[CLIENT] is not SWITCHED_PROTOCOL:
            raise ReceiveAfterCloseError("data received after the receive side was closed")
        self._buffer += chunk
        return None

    def next_event(self):
        try:
            return self._next_event()
        except RemoteProtocolError:
            self._fail_their()
            raise

    def _fail_their(self):
        states = dict(self._states)
        states[self.their_role] = ERROR
        self._states = _settle(states, self._ka_off)

    def _next_event(self):
        buf = self._buffer
        their = self._states[self.their_role]
        if their is ERROR:
            raise RemoteProtocolError("peer already sent invalid data; receiving has ended")
        if their is SWITCHED_PROTOCOL or their is MIGHT_SWITCH_PROTOCOL:
            return PAUSED
        if their is CLOSED:
            return ConnectionClosed() if self._closed else NEED_DATA
        if their is DONE or their is MUST_CLOSE:
            if buf:
                return PAUSED
            return self._pull_close() if self._closed else NEED_DATA
        if their is IDLE and not buf and self._closed:
            return self._pull_close()
        if their is SEND_BODY:
            return self._pull_body()
        return self._pull_head()

    def _pull_close(self):
        event = ConnectionClosed()
        new = self._transition(self.their_role, event)
        if new is None:
            raise RemoteProtocolError("peer closed the connection in a state where it may not")
        self._commit(self.their_role, event, new)
        return event

    def _pull_head(self):
        buf = self._buffer
        if not buf:
            if self._closed:
                raise RemoteProtocolError("peer closed the connection in the middle of a message")
            return NEED_DATA
        if buf[0] < 33:
            raise RemoteProtocolError("message starts with a space or control byte")
        split = split_head(buf)
        if split is None:
            if len(buf) > self._max_incomplete:
                raise RemoteProtocolError(
                    "header block exceeds the incomplete-event size limit", 431)
            if self._closed:
                raise RemoteProtocolError("peer closed the connection in the middle of a header block")
            return NEED_DATA
        lines, consumed = split
        if self.their_role is CLIENT:
            method, target, version = parse_request_line(lines[0])
            event = Request._from_wire(method, target, parse_header_lines(lines[1:]), version)
            framing = _request_framing(event.headers._triples)
        else:
            version, status, reason = parse_status_line(lines[0])
            pairs = parse_header_lines(lines[1:])
            if status < 200:
                event = InformationalResponse._from_wire(status, pairs, version, reason)
                framing = None
            else:
                event = Response._from_wire(status, pairs, version, reason)
                framing = _response_framing(event.headers._triples, self._request_method, status)
        new = self._transition(self.their_role, event)
        if new is None:
            raise RemoteProtocolError("unexpected message from peer in the current state")
        del buf[:consumed]
        ka_off = False
        if type(event) is not InformationalResponse:
            self._their_version = event.http_version
            ka_off = _ka_disables(event, framing)
        self._commit(self.their_role, event, new, framing=framing, ka_off=ka_off)
        return event

    def _pull_body(self):
        body = self._recv_body
        buf = self._buffer
        if body is None:
            raise RemoteProtocolError("no message body is open")
        if body.mode == "length":
            if body.remaining == 0:
                return self._finish_body(EndOfMessage())
            if not buf:
                if self._closed:
                    raise RemoteProtocolError("peer closed the connection in the middle of a body")
                return NEED_DATA
            n = min(body.remaining, len(buf))
            data = bytes(buf[:n])
            del buf[:n]
            body.remaining -= n
            return Data(data=data)
        if body.mode == "eof":
            if buf:
                data = bytes(buf)
                del buf[:]
                return Data(data=data)
            if self._closed:
                return self._finish_body(EndOfMessage())
            return NEED_DATA
        return self._pull_chunked(body)

    def _pull_chunked(self, body):
        buf = self._buffer
        while True:
            if body.chunk_state == "size":
                lf = buf.find(b"\n")
                if lf < 0:
                    if self._closed:
                        raise RemoteProtocolError("peer closed the connection in a chunk-size line")
                    return NEED_DATA
                line = bytes(buf[:lf])
                if line[-1:] == b"\r":
                    line = line[:-1]
                match = CHUNK_SIZE_RE.match(line)
                if match is None:
                    raise RemoteProtocolError("invalid chunk-size line")
                del buf[:lf + 1]
                size = int(match.group(1), 16)
                if size == 0:
                    body.chunk_state = "trailers"
                else:
                    body.chunk_left = size
                    body.chunk_state = "data"
                    body.piece_start = True
            elif body.chunk_state == "data":
                if not buf:
                    if self._closed:
                        raise RemoteProtocolError("peer closed the connection in the middle of a chunk")
                    return NEED_DATA
                n = min(body.chunk_left, len(buf))
                data = bytes(buf[:n])
                del buf[:n]
                body.chunk_left -= n
                start = body.piece_start
                body.piece_start = False
                end = body.chunk_left == 0
                if end:
                    body.chunk_state = "crlf"
                return Data(data=data, chunk_start=start, chunk_end=end)
            elif body.chunk_state == "crlf":
                if len(buf) >= 2:
                    if bytes(buf[:2]) != b"\r\n":
                        raise RemoteProtocolError("chunk data is not followed by CRLF")
                    del buf[:2]
                    body.chunk_state = "size"
                    continue
                if buf and bytes(buf[:1]) != b"\r":
                    raise RemoteProtocolError("chunk data is not followed by CRLF")
                if self._closed:
                    raise RemoteProtocolError("peer closed the connection in the middle of a chunk")
                return NEED_DATA
            else:
                return self._pull_trailers()

    def _pull_trailers(self):
        buf = self._buffer
        split = split_head(buf)
        if split is None:
            if len(buf) > self._max_incomplete:
                raise RemoteProtocolError(
                    "trailer block exceeds the incomplete-event size limit", 431)
            if self._closed:
                raise RemoteProtocolError("peer closed the connection in the trailer block")
            return NEED_DATA
        lines, consumed = split
        event = EndOfMessage._from_wire(parse_header_lines(lines))
        del buf[:consumed]
        return self._finish_body(event)

    def _finish_body(self, event):
        new = self._transition(self.their_role, event)
        if new is None:
            raise RemoteProtocolError("unexpected end of message from peer")
        self._commit(self.their_role, event, new)
        return event

    # ---- send side

    def send(self, event):
        return b"".join(_piece_bytes(p) for p in self._send_event(event, passthrough=False))

    def send_with_data_passthrough(self, event):
        return self._send_event(event, passthrough=True)

    def send_failed(self):
        self._fail_our()
        return None

    def start_next_cycle(self):
        if self._states[CLIENT] is not DONE or self._states[SERVER] is not DONE:
            raise LocalProtocolError("the next cycle cannot start until both sides are DONE")
        self._states = {CLIENT: IDLE, SERVER: IDLE}
        self._reset_cycle()
        return None

    def _fail_our(self):
        states = dict(self._states)
        states[self.our_role] = ERROR
        self._states = _settle(states, self._ka_off)

    def _send_event(self, event, passthrough):
        if not isinstance(event, _EVENT_TYPES):
            raise TypeError("send() takes one of the six HTTP event types")
        if not passthrough and type(event) is Data and not _is_buffer(event.data):
            raise TypeError("Data payload must be bytes-like for send()")
        try:
            return self._do_send(event, passthrough)
        except LocalProtocolError:
            self._fail_our()
            raise

    def _do_send(self, event, passthrough):
        if self._states[self.our_role] is ERROR:
            raise LocalProtocolError("connection is in ERROR; sends are refused")
        kind = type(event)
        if kind is Request:
            return self._send_request(event)
        if kind is InformationalResponse or kind is Response:
            return self._send_response(event)
        if kind is Data:
            return self._send_data(event)
        if kind is EndOfMessage:
            return self._send_end(event)
        new = self._transition(self.our_role, event)
        if new is None:
            raise LocalProtocolError("connection cannot be closed in the current state")
        self._commit(self.our_role, event, new)
        return []

    def _send_request(self, event):
        if self.our_role is not CLIENT:
            raise LocalProtocolError("a server cannot send a request")
        if event.http_version != b"1.1":
            raise LocalProtocolError("only HTTP/1.1 requests can be sent")
        new = self._transition(CLIENT, event)
        if new is None:
            raise LocalProtocolError("a request cannot be sent in the current state")
        triples = list(event.headers._triples)
        if _has(triples, CONTENT_LENGTH):
            # Content-Length decides the framing (PRD FP-01), so Transfer-Encoding is not sent.
            triples = [t for t in triples if t[1] != TRANSFER_ENCODING]
        triples = [t for t in triples if t[1] == HOST] + [t for t in triples if t[1] != HOST]
        framing = _request_framing(triples)
        head = _encode_head(event.method + b" " + event.target + b" HTTP/1.1\r\n", triples)
        self._commit(CLIENT, event, new, framing=framing, ka_off=_ka_disables(event, framing))
        return [head]

    def _send_response(self, event):
        if self.our_role is not SERVER:
            raise LocalProtocolError("a client cannot send a response")
        if event.http_version != b"1.1":
            raise LocalProtocolError("only HTTP/1.1 responses can be sent")
        new = self._transition(SERVER, event)
        if new is None:
            raise LocalProtocolError("a response cannot be sent in the current state")
        if type(event) is InformationalResponse:
            head = _encode_head(_status_line(event), event.headers._triples)
            self._commit(SERVER, event, new)
            return [head]
        accepted = self._switch_outcome(event) is _ACCEPT
        triples, framing, ka_off = self._plan_final_response(event, accepted)
        head = _encode_head(_status_line(event), triples)
        self._commit(SERVER, event, new, framing=framing, ka_off=ka_off)
        return [head]

    def _plan_final_response(self, event, accepted):
        """Wire headers, body framing and keep-alive effect of a final response (PRD FP-03, FP-04)."""
        triples = list(event.headers._triples)
        if accepted:
            return triples, None, False
        status = event.status_code
        peer_11 = self._their_version == b"1.1"
        their_error = self._states[self.their_role] is ERROR
        if status in (204, 304):
            triples = [t for t in triples if t[1] not in (CONTENT_LENGTH, TRANSFER_ENCODING)]
            framing = _Body("length", 0)
            eof = False
        elif _has(triples, TRANSFER_ENCODING):
            triples = [t for t in triples if t[1] != CONTENT_LENGTH]
            if peer_11:
                framing = _Body("chunked")
                eof = False
            else:
                triples = [t for t in triples if t[1] != TRANSFER_ENCODING]
                framing = _Body("eof")
                eof = True
        else:
            length = _find(triples, CONTENT_LENGTH)
            if length is not None:
                framing = _Body("length", int(length))
                eof = False
            elif peer_11:
                triples.append((b"Transfer-Encoding", TRANSFER_ENCODING, b"chunked"))
                framing = _Body("chunked")
                eof = False
            else:
                framing = _Body("eof")
                eof = True
        ka_off = (self._ka_off or eof or not peer_11 or their_error
                  or b"close" in _tokens(triples, CONNECTION))
        if ka_off:
            triples = _rewrite_connection(triples)
        if self._request_method == b"HEAD":
            # Headers follow the GET rules, but a HEAD response never carries a body.
            framing = _Body("length", 0)
        return triples, framing, ka_off

    def _send_data(self, event):
        new = self._transition(self.our_role, event)
        body = self._send_body
        if new is None or body is None:
            raise LocalProtocolError("data cannot be sent in the current state")
        payload = event.data
        size = _payload_length(payload)
        if body.mode == "length":
            if size > body.remaining:
                raise LocalProtocolError("data exceeds the declared Content-Length")
            body.remaining -= size
            pieces = [payload] if size else []
        elif body.mode == "eof":
            pieces = [payload] if size else []
        else:
            if size == 0:
                pieces = []
            else:
                pieces = [b"%x\r\n" % size, payload, b"\r\n"]
        self._commit(self.our_role, event, new)
        return pieces

    def _send_end(self, event):
        new = self._transition(self.our_role, event)
        body = self._send_body
        if new is None or body is None:
            raise LocalProtocolError("end-of-message cannot be sent in the current state")
        triples = list(event.headers._triples)
        if body.mode == "length":
            if body.remaining:
                raise LocalProtocolError("end-of-message sent before the Content-Length was complete")
            if triples:
                raise LocalProtocolError("trailers are not allowed with Content-Length framing")
            pieces = []
        elif body.mode == "eof":
            if triples:
                raise LocalProtocolError("trailers are not allowed with close-delimited framing")
            pieces = []
        else:
            if triples and self._their_version == b"1.0":
                raise LocalProtocolError("trailers cannot be sent to an HTTP/1.0 peer")
            parts = [b"0\r\n"]
            for raw_name, _lname, value in triples:
                parts.append(raw_name + b": " + value + b"\r\n")
            parts.append(b"\r\n")
            pieces = [b"".join(parts)]
        self._commit(self.our_role, event, new)
        return pieces

    # ---- state machine core

    def _proposal_pending(self):
        return self._pending_connect or self._pending_upgrade

    def _switch_outcome(self, event):
        """How a server response answers a pending CONNECT/Upgrade proposal (PRD FP-07)."""
        if type(event) is InformationalResponse:
            if event.status_code == 101 and self._pending_upgrade:
                return _ACCEPT
            return _NORMAL
        if not self._proposal_pending():
            return _NORMAL
        if self._pending_connect and 200 <= event.status_code < 300:
            return _ACCEPT
        return _DENY

    def _transition(self, sender, event):
        """Return the new pair of states if `sender` may send `event` now; else None. Pure."""
        states = dict(self._states)
        kind = type(event)
        if kind is Request:
            if sender is not CLIENT or states[CLIENT] is not IDLE or states[SERVER] is not IDLE:
                return None
            states[CLIENT] = SEND_BODY
            states[SERVER] = SEND_RESPONSE
            return states
        if kind is InformationalResponse:
            if sender is not SERVER or states[SERVER] is not SEND_RESPONSE:
                return None
            if self._switch_outcome(event) is _ACCEPT:
                states[CLIENT] = SWITCHED_PROTOCOL
                states[SERVER] = SWITCHED_PROTOCOL
            return states
        if kind is Response:
            if sender is not SERVER:
                return None
            if states[SERVER] is not IDLE and states[SERVER] is not SEND_RESPONSE:
                return None
            outcome = self._switch_outcome(event)
            if outcome is _ACCEPT:
                states[CLIENT] = SWITCHED_PROTOCOL
                states[SERVER] = SWITCHED_PROTOCOL
            else:
                states[SERVER] = SEND_BODY
                if outcome is _DENY and states[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                    states[CLIENT] = DONE
            return states
        if kind is Data:
            return states if states[sender] is SEND_BODY else None
        if kind is EndOfMessage:
            if states[sender] is not SEND_BODY:
                return None
            if sender is CLIENT and self._proposal_pending() and states[SERVER] is SEND_RESPONSE:
                states[CLIENT] = MIGHT_SWITCH_PROTOCOL
            else:
                states[sender] = DONE
            return states
        if kind is ConnectionClosed:
            if states[sender] in (IDLE, DONE, MUST_CLOSE):
                states[sender] = CLOSED
                return states
            return None
        return None

    def _commit(self, sender, event, states, framing=None, ka_off=False):
        """Apply a transition that _transition has approved, plus per-cycle bookkeeping."""
        kind = type(event)
        ours = sender is self.our_role
        if kind is Request:
            triples = event.headers._triples
            self._request_method = event.method
            self._pending_connect = event.method == b"CONNECT"
            self._pending_upgrade = _has(triples, UPGRADE)
            if event.http_version == b"1.1" and b"100-continue" in _tokens(triples, EXPECT):
                self._client_waiting = True
                if self.our_role is SERVER:
                    self._they_waiting = True
            if ours:
                self._send_body = framing
            else:
                self._recv_body = framing
        elif kind is InformationalResponse or kind is Response:
            outcome = self._switch_outcome(event)
            self._client_waiting = False
            self._they_waiting = False
            if kind is Response or outcome is _ACCEPT:
                self._pending_connect = False
                self._pending_upgrade = False
            if kind is Response:
                body = None if outcome is _ACCEPT else framing
                if ours:
                    self._send_body = body
                else:
                    self._recv_body = body
        elif kind is EndOfMessage:
            if ours:
                self._send_body = None
            else:
                self._recv_body = None
        if ka_off:
            self._ka_off = True
        self._states = _settle(dict(states), self._ka_off)
