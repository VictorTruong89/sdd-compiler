"""Byte-level parsing helpers for message heads and chunk-size lines."""

import re

from ._common import RemoteProtocolError
from ._events import TOKEN_RE

_REQUEST_LINE_RE = re.compile(
    rb"([!#$%&'*+\-.^_`|~0-9A-Za-z]+) ([\x21-\x7e]+) HTTP/([0-9]\.[0-9])\Z"
)
_STATUS_LINE_RE = re.compile(
    rb"HTTP/([0-9]\.[0-9]) ([0-9]{3})(?: ([\t\x20-\x7e\x80-\xff]*))?\Z"
)
# Up to 32 hex digits (the implementer's choice within PRD FP-03's 16..32 range),
# an optional extension that is parsed and discarded, then optional spaces/tabs.
CHUNK_SIZE_RE = re.compile(rb"([0-9A-Fa-f]{1,32})(?:;[^\r\n]*)?[ \t]*\Z")
_SUPPORTED_VERSIONS = (b"1.0", b"1.1")


def split_head(buf):
    """Return (lines, consumed) once buf holds a full header block ending in an empty line.

    Lines are returned without their terminators. A lone LF is accepted as a
    line ending. Returns None while the block is still incomplete.
    """
    pos = 0
    lines = []
    while True:
        lf = buf.find(b"\n", pos)
        if lf < 0:
            return None
        line = bytes(buf[pos:lf])
        if line[-1:] == b"\r":
            line = line[:-1]
        pos = lf + 1
        if not line:
            return lines, pos
        lines.append(line)


def parse_request_line(line):
    match = _REQUEST_LINE_RE.match(line)
    if match is None:
        raise RemoteProtocolError("malformed request line")
    version = match.group(3)
    if version not in _SUPPORTED_VERSIONS:
        raise RemoteProtocolError("unsupported HTTP version")
    return match.group(1), match.group(2), version


def parse_status_line(line):
    match = _STATUS_LINE_RE.match(line)
    if match is None:
        raise RemoteProtocolError("malformed status line")
    version = match.group(1)
    if version not in _SUPPORTED_VERSIONS:
        raise RemoteProtocolError("unsupported HTTP version")
    status = int(match.group(2))
    if status < 100:
        raise RemoteProtocolError("status code out of range")
    reason = match.group(3) or b""
    return version, status, reason


def parse_header_lines(lines):
    """Parse header lines into (name, value) pairs, applying obsolete line folding."""
    pairs = []
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            if not pairs:
                raise RemoteProtocolError("continuation line without a header")
            name, value = pairs[-1]
            extra = line.strip(b" \t")
            if extra:
                value = (value + b" " + extra) if value else extra
            pairs[-1] = (name, value)
            continue
        colon = line.find(b":")
        if colon <= 0:
            raise RemoteProtocolError("malformed header line")
        name = line[:colon]
        if TOKEN_RE.match(name) is None:
            raise RemoteProtocolError("invalid header name")
        pairs.append((name, line[colon + 1:].strip(b" \t")))
    return pairs
