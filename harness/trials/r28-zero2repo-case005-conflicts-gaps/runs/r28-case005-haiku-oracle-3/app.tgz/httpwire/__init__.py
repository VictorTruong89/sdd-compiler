"""httpwire: a pure-Python, bring-your-own-I/O HTTP/1.1 wire protocol library.

The public surface is the names listed in ``__all__``.  # spec: N-000433 N-000449 N-000023
httpwire is an importable library.  It implements the message-syntax and routing chapter of
HTTP/1.1 (RFC 7230) plus ``Expect: 100-continue`` (RFC 7231 Sec. 5.1.1), turns high-level events
into bytes and bytes into events, and does no I/O of its own.  Integrators supply the I/O.
# spec: N-000001 N-000002 N-000004 N-000005 N-000007 N-000008 N-000009 N-000429 N-000430
# spec: N-000431 N-000022 N-000069
"""

from ._connection import Connection
from ._errors import LocalProtocolError, RemoteProtocolError
from ._events import (
    ConnectionClosed, Data, EndOfMessage, InformationalResponse, Request, Response,
)
from ._state import (
    CLIENT, CLOSED, DONE, ERROR, IDLE, MIGHT_SWITCH_PROTOCOL, MUST_CLOSE, NEED_DATA,
    PAUSED, SEND_BODY, SEND_RESPONSE, SERVER, SWITCHED_PROTOCOL,
)

__version__ = "0.1.0"

__all__ = [
    "CLIENT", "SERVER",
    "NEED_DATA", "PAUSED",
    "IDLE", "SEND_RESPONSE", "SEND_BODY", "DONE", "MUST_CLOSE", "CLOSED",
    "MIGHT_SWITCH_PROTOCOL", "SWITCHED_PROTOCOL", "ERROR",
    "Request", "InformationalResponse", "Response", "Data", "EndOfMessage", "ConnectionClosed",
    "Connection",
    "LocalProtocolError", "RemoteProtocolError",
]
