"""The six event types (FP-01)."""

from ._errors import LocalProtocolError
from ._headers import (
    TARGET_RE, TOKEN_RE, VERSION_RE, check_reason, count_named,
    normalize_headers, to_bytes,
)


def _check_status(status_code, low, high_exclusive, kind):
    # spec: N-000112 N-000113 N-000460 N-000394 N-000398
    if isinstance(status_code, bool) or not isinstance(status_code, int):
        raise LocalProtocolError("status code must be an integer")
    code = int(status_code)
    if not (low <= code < high_exclusive):
        raise LocalProtocolError("status %d is outside the range for %s" % (code, kind))
    return code


def _check_version(version):
    version = to_bytes(version, "HTTP version")
    if not VERSION_RE.match(version):  # spec: N-000072 N-000073 N-000074 N-000075
        raise LocalProtocolError("HTTP version must be two digits separated by a dot")
    return version


class _Event:
    __slots__ = ()
    _field_names = ()

    def _values(self):
        return tuple(getattr(self, f) for f in self._field_names)

    def __eq__(self, other):
        if type(other) is not type(self):
            return NotImplemented
        return self._values() == other._values()

    __hash__ = None

    def __repr__(self):
        inner = ", ".join("%s=%r" % (f, getattr(self, f)) for f in self._field_names)
        return "%s(%s)" % (type(self).__name__, inner)


class Request(_Event):
    """Start of an HTTP request.  # spec: N-000070 N-000072 N-000076 N-000077 N-000078"""

    __slots__ = ("method", "target", "headers", "http_version")
    _field_names = ("method", "target", "headers", "http_version")

    def __init__(self, method, target, headers, http_version=b"1.1"):
        method = to_bytes(method, "method")
        if not TOKEN_RE.match(method):  # spec: N-000111
            raise LocalProtocolError("method must be a single RFC 7230 token")
        target = to_bytes(target, "target")
        if not TARGET_RE.match(target):  # spec: N-000110
            raise LocalProtocolError("request target must be visible ASCII")
        http_version = _check_version(http_version)
        headers = normalize_headers(headers)
        hosts = count_named(headers, b"host")
        if hosts > 1:  # spec: N-000105
            raise LocalProtocolError("more than one Host header")
        if http_version == b"1.1" and hosts != 1:  # spec: N-000077 N-000078 N-000104
            raise LocalProtocolError("HTTP/1.1 request needs exactly one Host header")
        self.method = method
        self.target = target
        self.headers = headers
        self.http_version = http_version


class InformationalResponse(_Event):
    """An HTTP 1xx response.  # spec: N-000079 N-000080 N-000081"""

    __slots__ = ("status_code", "headers", "http_version", "reason")
    _field_names = ("status_code", "headers", "http_version", "reason")

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        self.status_code = _check_status(status_code, 100, 200, "an informational response")
        self.headers = normalize_headers(headers)
        self.http_version = _check_version(http_version)
        reason = to_bytes(reason, "reason")
        check_reason(reason)
        self.reason = reason


class Response(_Event):
    """Start of a final HTTP response.  # spec: N-000079 N-000082 N-000083"""

    __slots__ = ("status_code", "headers", "http_version", "reason")
    _field_names = ("status_code", "headers", "http_version", "reason")

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        self.status_code = _check_status(status_code, 200, 1000, "a final response")
        self.headers = normalize_headers(headers)
        self.http_version = _check_version(http_version)
        reason = to_bytes(reason, "reason")
        check_reason(reason)
        self.reason = reason


class Data(_Event):
    """A piece of a message body.  # spec: N-000084 N-000463 N-000464 N-000465"""

    __slots__ = ("data", "chunk_start", "chunk_end")
    _field_names = ("data", "chunk_start", "chunk_end")

    def __init__(self, data, chunk_start=False, chunk_end=False):
        if isinstance(data, str):
            raise LocalProtocolError("data must be bytes-like")
        if not isinstance(data, (bytes, bytearray, memoryview)) and not hasattr(data, "__len__"):
            raise LocalProtocolError("data must be bytes-like or an object with a length")
        self.data = data  # stored as given  # spec: N-000085
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)


class EndOfMessage(_Event):
    """End of a request or response, optionally with trailing headers.  # spec: N-000086 N-000084"""

    __slots__ = ("headers",)
    _field_names = ("headers",)

    def __init__(self, headers=()):
        self.headers = normalize_headers(headers)


class ConnectionClosed(_Event):
    """This party will not send more HTTP data.  # spec: N-000086 N-000457"""

    __slots__ = ()
    _field_names = ()

    def __init__(self):
        pass
