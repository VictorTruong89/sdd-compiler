"""Header list container and header normalization (FP-01)."""

import re
from collections.abc import Sequence

from ._errors import LocalProtocolError

# RFC 7230 token: header names, methods.
TOKEN_RE = re.compile(rb"[!#$%&'*+\-.^_`|~0-9A-Za-z]+\Z")
# Visible ASCII only: request targets.  # spec: N-000110
TARGET_RE = re.compile(rb"[\x21-\x7e]+\Z")
VERSION_RE = re.compile(rb"[0-9]\.[0-9]\Z")
DIGITS_RE = re.compile(rb"[0-9]+\Z")
# Bytes that may never appear in a header value: everything except
# horizontal tab, printable ASCII and non-ASCII bytes.  # spec: N-000097 N-000108 N-000026
BAD_VALUE_BYTE_RE = re.compile(rb"[\x00-\x08\x0a-\x1f\x7f]")
# Maximum Content-Length digit count (fixed choice in 18..32).  # spec: N-000114 N-000115 N-000116 N-000117 N-000118 N-000119
MAX_CONTENT_LENGTH_DIGITS = 18


def to_bytes(value, what):
    """Accept ASCII str or any bytes-like object; return ``bytes``."""
    if isinstance(value, str):
        try:
            return value.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("%s must be ASCII text or bytes" % what)
    if isinstance(value, (bytes, bytearray, memoryview)):
        return bytes(value)
    raise LocalProtocolError("%s must be ASCII text or bytes" % what)  # spec: N-000458 N-000459


def check_value(value):
    """FP-01 header-value rule. Values may not start/end with SP or HT."""
    if BAD_VALUE_BYTE_RE.search(value):
        raise LocalProtocolError("header value contains a forbidden byte")  # spec: N-000098 N-000099 N-000108 N-000109
    if value[:1] in (b" ", b"\t") or value[-1:] in (b" ", b"\t"):
        raise LocalProtocolError("header value begins or ends with whitespace")  # spec: N-000099 N-000100


def check_reason(reason):
    if re.search(rb"[\x00-\x08\x0a-\x1f\x7f]", reason):
        raise LocalProtocolError("reason phrase contains a forbidden byte")


class Headers(Sequence):
    """Ordered header list.

    Headers on request, informational-response, response and end-of-message events are an
    ordered sequence of name/value pairs.  Iteration and indexing give the ordinary view:
    ``(lowercased name, value)``.  ``raw_items()`` gives the names exactly as the caller spelled
    them.  # spec: N-000087 N-000088 N-000089 N-000090 N-000091
    """

    __slots__ = ("_raw",)

    def __init__(self, raw_pairs):
        self._raw = tuple((bytes(n), bytes(v)) for n, v in raw_pairs)

    def __getitem__(self, index):
        if isinstance(index, slice):
            return [(n.lower(), v) for n, v in self._raw[index]]
        n, v = self._raw[index]
        return (n.lower(), v)  # spec: N-000468

    def __len__(self):
        return len(self._raw)

    def __iter__(self):
        for n, v in self._raw:
            yield (n.lower(), v)

    def raw_items(self):  # spec: N-000469 N-000470 N-000471
        return [(n, v) for n, v in self._raw]

    def __eq__(self, other):
        if isinstance(other, Headers):
            return self._raw == other._raw
        if isinstance(other, (list, tuple)):
            try:
                return list(self) == [tuple(p) for p in other]
            except TypeError:
                return NotImplemented
        return NotImplemented

    __hash__ = None

    def __repr__(self):
        return "Headers(%r)" % (list(self),)


def normalize_headers(pairs):
    """Validate and normalize a header list; return a :class:`Headers`.

    Raises LocalProtocolError on any refusal.  Refusals about
    ``Transfer-Encoding`` carry suggested status 501.
    """
    if isinstance(pairs, Headers):
        items = list(pairs.raw_items())
    else:
        items = []
        for pair in pairs:
            try:
                name, value = pair
            except (TypeError, ValueError):
                raise LocalProtocolError("header must be a (name, value) pair")  # spec: N-000461
            items.append((to_bytes(name, "header name"), to_bytes(value, "header value")))

    for name, value in items:
        if not TOKEN_RE.match(name):
            raise LocalProtocolError("header name is not an RFC 7230 token")  # spec: N-000106 N-000107
        check_value(value)

    # Content-Length: all values (across headers and comma pieces) must agree.  # spec: N-000092 N-000094 N-000095 N-000096 N-000114 N-000115 N-000116 N-000117 N-000118 N-000119
    cl_idx = [i for i, (n, _) in enumerate(items) if n.lower() == b"content-length"]
    if cl_idx:
        lengths = set()
        for i in cl_idx:
            for piece in items[i][1].split(b","):
                piece = piece.strip(b" \t")
                if not DIGITS_RE.match(piece) or len(piece) > MAX_CONTENT_LENGTH_DIGITS:
                    raise LocalProtocolError("invalid Content-Length value")  # spec: N-000114 N-000116
                lengths.add(int(piece))
        if len(lengths) > 1:
            raise LocalProtocolError("conflicting Content-Length values")  # spec: N-000119
        canonical = ("%d" % lengths.pop()).encode("ascii")
        first = cl_idx[0]
        new_items = []
        for i, (n, v) in enumerate(items):
            if i == first:
                new_items.append((n, canonical))
            elif i in cl_idx:
                continue
            else:
                new_items.append((n, v))
        items = new_items

    # Transfer-Encoding: only a single header whose value is exactly chunked.  # spec: N-000120 N-000121 N-000093 N-000094 N-000064 N-000065
    te_idx = [i for i, (n, _) in enumerate(items) if n.lower() == b"transfer-encoding"]
    if te_idx:
        if len(te_idx) > 1:
            raise LocalProtocolError("duplicate Transfer-Encoding header", 501)
        i = te_idx[0]
        n, v = items[i]
        if v.lower() != b"chunked":
            raise LocalProtocolError("unsupported Transfer-Encoding", 501)
        items[i] = (n, b"chunked")

    return Headers(items)


def has_token(headers, name, token):
    """True if some header ``name`` lists ``token`` (case-insensitive) as a list element."""
    token = token.lower()
    for n, v in headers:
        if n == name:
            for piece in v.split(b","):
                if piece.strip(b" \t").lower() == token:
                    return True
    return False


def count_named(headers, name):
    return sum(1 for n, _ in headers if n == name)
