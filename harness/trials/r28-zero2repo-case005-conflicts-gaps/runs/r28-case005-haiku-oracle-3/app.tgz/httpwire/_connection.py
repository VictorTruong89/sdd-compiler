"""The bring-your-own-I/O connection object (FP-02 .. FP-07).

Sending encodes events to bytes and updates state.  Receiving only stores
bytes (``receive_data``); ``next_event`` parses one event out of them.
Nothing here touches a socket.  # spec: N-000144 N-000145 N-000146 N-000147 N-000148 N-000149 N-000150 N-000047 N-000048 N-000049

Scope and dialect (RFC 7230 message syntax, plus Expect: 100-continue).  Our own parser and
serializer; no standard-library HTTP code is used.  Only HTTP/1.1 is written; HTTP/1.0 peers are
understood when reading.  No HTTP/2, no URL routing, no cookies, no content negotiation.
# spec: N-000050 N-000051 N-000052 N-000053 N-000054 N-000055 N-000056 N-000057 N-000058 N-000061
# spec: N-000003 N-000010 N-000011 N-000014 N-000016 N-000028 N-000029 N-000030 N-000183 N-000184
# spec: N-000024 N-000025 N-000036 N-000247 N-000248 N-000249 N-000012 N-000015 N-000017 N-000027
# spec: N-000006 N-000031 N-000032 N-000033 N-000034 N-000035 N-000018 N-000019 N-000020 N-000021
"""

import re

from ._errors import LocalProtocolError, ReceiveClosedError, RemoteProtocolError
from ._events import (
    ConnectionClosed, Data, EndOfMessage, InformationalResponse, Request, Response,
)
from ._headers import TOKEN_RE, has_token, normalize_headers
from ._state import (
    CLIENT, CLOSED, DONE, ERROR, IDLE, MIGHT_SWITCH_PROTOCOL, MUST_CLOSE, NEED_DATA,
    PAUSED, SEND_BODY, SEND_RESPONSE, SERVER, SWITCHED_PROTOCOL,
)

DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 8 * 1024  # spec: N-000478 N-000479 N-000480

_STATUS_LINE_RE = re.compile(rb"HTTP/([01]\.[01]) ([0-9]{3})(?: (.*))?\Z")
_REQUEST_VERSION_RE = re.compile(rb"HTTP/(1\.[01])\Z")
_CHUNK_SIZE_RE = re.compile(rb"[0-9A-Fa-f]{1,32}\Z")  # spec: N-000228 N-000229 N-000230 N-000242 N-000243 N-000194

_TRANSFER_ENCODING = b"transfer-encoding"
_CONTENT_LENGTH = b"content-length"
_CONNECTION = b"connection"
_EXPECT = b"expect"
_UPGRADE = b"upgrade"
_HOST = b"host"


def _other(role):
    return SERVER if role is CLIENT else CLIENT


def _request_framing(headers):
    """Framing for a request: Content-Length decides; else chunked; else empty.

    Body framing: Content-Length, Transfer-Encoding: chunked, or none (empty body).  # spec: N-000183 N-000184 N-000028
    """
    # spec: N-000185 N-000186 N-000187 N-000188 N-000192 N-000193 N-000096 N-000201
    for n, v in headers:
        if n == _CONTENT_LENGTH:
            return "length", int(v)
    for n, v in headers:
        if n == _TRANSFER_ENCODING:
            return "chunked", 0
    return "empty", 0


def _has_header(headers, name):
    return any(n == name for n, _ in headers)


def _status_line(event):
    return b"HTTP/1.1 %d " % event.status_code + event.reason + b"\r\n"


def _header_block(items):
    return b"".join(n + b": " + v + b"\r\n" for n, v in items) + b"\r\n"


def _payload_length(payload):
    if isinstance(payload, memoryview):
        return payload.nbytes
    return len(payload)


def _apply_connection_close(items):
    """Make the Connection header say ``close`` and drop ``keep-alive``.  # spec: N-000265 N-000266 N-000267 N-000268 N-000269"""
    idx = [i for i, (n, _) in enumerate(items) if n.lower() == _CONNECTION]
    if not idx:
        return items + [(b"Connection", b"close")]
    tokens = []
    for i in idx:
        tokens += [t.strip(b" \t") for t in items[i][1].split(b",")]
    kept = [t for t in tokens if t and t.lower() != b"keep-alive"]
    if not any(t.lower() == b"close" for t in kept):
        kept.append(b"close")
    value = b", ".join(kept)
    out = []
    placed = False
    for i, (n, v) in enumerate(items):
        if i in idx:
            if not placed:
                out.append((n, value))
                placed = True
        else:
            out.append((n, v))
    return out


class Connection:
    """One HTTP/1.1 connection in the CLIENT or SERVER role.  # spec: N-000476 N-000477 N-000122 N-000123 N-000172 N-000173"""

    def __init__(self, our_role, max_incomplete_event_size=DEFAULT_MAX_INCOMPLETE_EVENT_SIZE):
        if our_role is not CLIENT and our_role is not SERVER:
            raise LocalProtocolError("role must be CLIENT or SERVER")  # spec: N-000476 N-000477 N-000172 N-000173
        if isinstance(max_incomplete_event_size, bool) or not isinstance(max_incomplete_event_size, int):
            raise LocalProtocolError("max_incomplete_event_size must be an int")
        self._our_role = our_role
        self._their_role = _other(our_role)
        self._states = {CLIENT: IDLE, SERVER: IDLE}  # spec: N-000125 N-000124 N-000481
        self._max_incomplete = int(max_incomplete_event_size)  # spec: N-000479
        self._buf = bytearray()
        self._closed = False  # receive side closed (an empty feed was given)
        self._their_version = None  # spec: N-000486 N-000487 N-000488 N-000489
        self._error_hint = None
        self._waiting_for_100 = False  # spec: N-000354 N-000358 N-000359
        self._reset_cycle()

    # ------------------------------------------------------------------ state

    def _reset_cycle(self):
        self._cycle_request = None
        self._cycle_response = None
        self._cycle_close_delimited = False
        self._proposal = None  # set of "connect"/"upgrade" while a switch proposal is open
        self._send_mode = None
        self._send_remaining = 0
        self._recv_mode = None
        self._recv_remaining = 0
        self._recv_chunk_state = None
        self._recv_chunk_remaining = 0
        self._recv_chunk_started = False

    @property
    def our_role(self):
        return self._our_role  # spec: N-000481

    @property
    def their_role(self):
        return self._their_role  # spec: N-000482

    @property
    def our_state(self):
        return self._states[self._our_role]  # spec: N-000483

    @property
    def their_state(self):
        return self._states[self._their_role]  # spec: N-000484

    @property
    def states(self):
        return {CLIENT: self._states[CLIENT], SERVER: self._states[SERVER]}  # spec: N-000485 N-000126

    @property
    def their_http_version(self):
        return self._their_version  # spec: N-000486 N-000487 N-000488 N-000489

    @property
    def client_is_waiting_for_100_continue(self):
        return self._waiting_for_100  # spec: N-000490 N-000491 N-000492 N-000354 N-000355 N-000356 N-000357

    @property
    def they_are_waiting_for_100_continue(self):
        return self._waiting_for_100 and self._our_role is SERVER  # spec: N-000493 N-000494 N-000495 N-000496

    @property
    def trailing_data(self):
        return (bytes(self._buf), self._closed)  # spec: N-000496 N-000388 N-000389 N-000390 N-000391

    def _fixup(self):
        """Apply the cross-side state rules (ERROR/DONE, CLOSED, keep-alive)."""
        s = self._states
        c, sv = s[CLIENT], s[SERVER]
        if c is ERROR and sv is DONE:  # spec: N-000311
            s[SERVER] = MUST_CLOSE
        if sv is ERROR and c is DONE:
            s[CLIENT] = MUST_CLOSE
        if c is CLOSED and s[SERVER] in (IDLE, DONE):  # spec: N-000336 N-000337 N-000338
            s[SERVER] = MUST_CLOSE
        if sv is CLOSED and s[CLIENT] in (IDLE, DONE):
            s[CLIENT] = MUST_CLOSE
        if not self._keep_alive_ok():  # spec: N-000259 N-000260 N-000261 N-000262 N-000263 N-000264
            for r in (CLIENT, SERVER):
                if s[r] is DONE:
                    s[r] = MUST_CLOSE

    def _keep_alive_ok(self, resp=None, extra_close=False):
        """Keep-alive is on only if both speak 1.1 and nobody sent ``close``.

        Keep-alive is the reuse of one connection for another request/response
        cycle after both sides reach DONE.  An HTTP/1.0 peer is never kept alive.  # spec: N-000021 N-000062 N-000063 N-000286 N-000287
        """
        if resp is None:
            resp = self._cycle_response
        s = self._states
        if s[CLIENT] is ERROR or s[SERVER] is ERROR:  # spec: N-000306 N-000309
            return False
        if self._their_version is not None:
            if self._their_version != b"1.1":  # spec: N-000286 N-000287
                return False
        elif self._our_role is SERVER:
            return False  # no request seen yet: peer version unknown
        req = self._cycle_request
        if req is not None and (req.http_version != b"1.1" or has_token(req.headers, _CONNECTION, b"close")):
            return False
        if resp is not None and has_token(resp.headers, _CONNECTION, b"close"):
            return False
        if extra_close or self._cycle_close_delimited:
            return False
        return True

    def _local_error(self, message):
        """Our side violated the protocol: our state becomes ERROR (unrecoverable for sending).  # spec: N-000032 N-000034 N-000307 N-000308
        """
        self._states[self._our_role] = ERROR  # spec: N-000307 N-000308 N-000310
        self._fixup()
        return LocalProtocolError(message)

    def _remote_error(self, message, hint=400):
        """The peer violated the protocol: their state becomes ERROR (unrecoverable for receiving).  # spec: N-000031 N-000033 N-000302 N-000303
        """
        self._states[self._their_role] = ERROR  # spec: N-000302 N-000303 N-000304 N-000305
        self._error_hint = hint
        self._fixup()
        return RemoteProtocolError(message, error_status_hint=hint)

    def _accepts(self, event):
        """Would this server-sent (or received) event accept an open switch proposal?

        Informational responses, Expect: 100-continue, CONNECT and Upgrade protocol switches.  # spec: N-000036
        """
        # spec: N-000369 N-000370 N-000371 N-000372 N-000394 N-000395 N-000396 N-000397 N-000360 N-000361 N-000362 N-000363
        if not self._proposal or self._states[CLIENT] is not MIGHT_SWITCH_PROTOCOL:
            return False
        if type(event) is InformationalResponse:
            return event.status_code == 101 and "upgrade" in self._proposal
        if type(event) is Response:
            return 200 <= event.status_code < 300 and "connect" in self._proposal
        return False

    def _process_event(self, role, event, close_delimited=False):
        """Advance states for an event sent (role = us) or pulled (role = peer)."""
        s = self._states
        if type(event) is Request:
            if s[CLIENT] is IDLE:
                s[CLIENT] = SEND_BODY
            if s[SERVER] is IDLE:
                s[SERVER] = SEND_RESPONSE  # spec: N-000250 N-000251 N-000252
            self._cycle_request = event
            self._cycle_response = None
            self._cycle_close_delimited = False
            proposal = set()
            if event.method == b"CONNECT":  # spec: N-000364 N-000365
                proposal.add("connect")
            if _has_header(event.headers, _UPGRADE):  # spec: N-000366 N-000367 N-000368
                proposal.add("upgrade")
            self._proposal = proposal or None
            if event.http_version == b"1.1" and has_token(event.headers, _EXPECT, b"100-continue"):  # spec: N-000354 N-000355 N-000356
                self._waiting_for_100 = True
        elif type(event) is InformationalResponse:
            if self._accepts(event):  # spec: N-000371 N-000372
                self._accept()
            self._waiting_for_100 = False  # spec: N-000358
        elif type(event) is Response:
            self._cycle_response = event
            self._cycle_close_delimited = close_delimited
            if self._accepts(event):
                self._accept()
            else:
                if self._proposal:  # denial  # spec: N-000378 N-000379 N-000380
                    self._proposal = None
                    if s[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                        s[CLIENT] = DONE
                if s[SERVER] in (SEND_RESPONSE, IDLE):
                    s[SERVER] = SEND_BODY  # spec: N-000254 N-000139 N-000257
            self._waiting_for_100 = False  # spec: N-000358
        elif type(event) is EndOfMessage:
            if role is CLIENT and self._proposal:  # spec: N-000373 N-000374 N-000375 N-000376 N-000377
                s[CLIENT] = MIGHT_SWITCH_PROTOCOL
            else:
                s[role] = DONE  # spec: N-000253 N-000254
        elif type(event) is ConnectionClosed:
            s[role] = CLOSED  # spec: N-000334 N-000335 N-000344
        self._fixup()

    def _accept(self):
        self._states[CLIENT] = SWITCHED_PROTOCOL  # spec: N-000381 N-000382 N-000383 N-000384 N-000385 N-000386 N-000387
        self._states[SERVER] = SWITCHED_PROTOCOL
        self._proposal = None

    # ------------------------------------------------------------- sending

    def _check_recv_allowed(self, their, event):
        st = self._states[their]
        if type(event) is Request:
            return their is CLIENT and st is IDLE
        if type(event) is InformationalResponse:
            return their is SERVER and st is SEND_RESPONSE
        if type(event) is Response:
            return their is SERVER and st in (SEND_RESPONSE, IDLE)
        return False

    def _build_send(self, event):
        """Validate ``event`` for sending, commit state, and return wire pieces."""
        our = self._our_role
        st = self._states[our]
        if st is ERROR or st is SWITCHED_PROTOCOL:
            raise self._local_error("cannot send: connection is in state %r" % (st,))  # spec: N-000328 N-000402 N-000403 N-000404 N-000405 N-000399 N-000400
        if type(event) is ConnectionClosed:
            if st not in (IDLE, DONE, MUST_CLOSE):  # spec: N-000345 N-000346 N-000347
                raise self._local_error("cannot send connection-closed in state %r" % (st,))
            self._states[our] = CLOSED
            self._fixup()
            return []

        if type(event) is Request:
            if our is not CLIENT or st is not IDLE:  # spec: N-000283 N-000285 N-000272 N-000273 N-000274
                raise self._local_error("a request can only be sent by a client in IDLE")
            if event.http_version != b"1.1":  # spec: N-000156 N-000157 N-000158 N-000159 N-000160
                raise self._local_error("only HTTP/1.1 requests can be sent")
            mode, n = _request_framing(event.headers)
            items = list(event.headers.raw_items())
            if mode == "length":
                items = [(nm, v) for nm, v in items if nm.lower() != _TRANSFER_ENCODING]  # Content-Length decides  # spec: N-000096
            host = [it for it in items if it[0].lower() == _HOST]
            rest = [it for it in items if it[0].lower() != _HOST]
            head = event.method + b" " + event.target + b" HTTP/1.1\r\n" + _header_block(host + rest)  # spec: N-000161 N-000162 N-000163 N-000164 N-000128 N-000129 N-000130 N-000131
            self._send_mode = mode
            self._send_remaining = n
            self._process_event(CLIENT, event)
            return [head]

        if type(event) is InformationalResponse:
            if our is not SERVER or st is not SEND_RESPONSE:  # spec: N-000136 N-000137 N-000138
                raise self._local_error("informational response can only be sent in SEND_RESPONSE")
            if event.http_version != b"1.1":
                raise self._local_error("only HTTP/1.1 responses can be sent")
            head = _status_line(event) + _header_block(event.headers.raw_items())
            self._send_mode = None
            self._process_event(SERVER, event)
            return [head]

        if type(event) is Response:
            if our is not SERVER or st not in (SEND_RESPONSE, IDLE):  # spec: N-000255 N-000256 N-000257 N-000258
                raise self._local_error("a final response cannot be sent in state %r" % (st,))
            if event.http_version != b"1.1":
                raise self._local_error("only HTTP/1.1 responses can be sent")
            if self._accepts(event):  # spec: N-000381 N-000362
                head = _status_line(event) + _header_block(event.headers.raw_items())
                self._send_mode = None
                self._cycle_close_delimited = False
                self._process_event(SERVER, event)
                return [head]
            return self._build_final_response(event)

        if type(event) is Data:
            if st is not SEND_BODY:  # spec: N-000168 N-000169
                raise self._local_error("data can only be sent in SEND_BODY")
            payload = event.data
            if isinstance(payload, str):
                raise self._local_error("data must be bytes-like")
            n = _payload_length(payload)
            mode = self._send_mode
            if mode == "empty":  # spec: N-000215 N-000216 N-000217
                raise self._local_error("this message has no body")
            if isinstance(payload, (bytes, bytearray, memoryview)):
                payload = bytes(payload)
            if n == 0:
                return []
            if mode == "length":  # spec: N-000238
                if n > self._send_remaining:
                    raise self._local_error("data exceeds the declared Content-Length")
                self._send_remaining -= n
                return [payload]
            if mode == "chunked":  # spec: N-000220 N-000221 N-000233 N-000234 N-000235 N-000236 N-000237
                return [b"%x\r\n" % n, payload, b"\r\n"]
            return [payload]  # close-delimited: raw payload

        if type(event) is EndOfMessage:
            if st is not SEND_BODY:  # spec: N-000240 N-000241
                raise self._local_error("end-of-message can only be sent in SEND_BODY")
            mode = self._send_mode
            trailers = list(event.headers.raw_items())
            if mode == "length":
                if self._send_remaining != 0:  # spec: N-000239
                    raise self._local_error("end-of-message before the declared Content-Length was sent")
                if trailers:
                    raise self._local_error("trailing headers not allowed with Content-Length framing")
                pieces = []
            elif mode == "chunked":
                pieces = [b"0\r\n" + _header_block(trailers)]  # spec: N-000195 N-000196
            else:
                if trailers:  # spec: N-000240 N-000241
                    raise self._local_error("trailing headers not allowed without chunked framing")
                pieces = []
            self._process_event(our, event)
            return pieces

        raise self._local_error("not an event: %r" % (event,))

    def _build_final_response(self, event):
        """Frame and encode a non-switch final response (FP-03, FP-04)."""
        req = self._cycle_request
        method = req.method if req is not None else None
        code = event.status_code
        items = list(event.headers.raw_items())
        has_cl = _has_header(event.headers, _CONTENT_LENGTH)
        has_te = _has_header(event.headers, _TRANSFER_ENCODING)
        peer11 = self._their_version == b"1.1"
        add_te = False
        if code in (204, 304):  # spec: N-000215 N-000216
            items = [it for it in items if it[0].lower() not in (_CONTENT_LENGTH, _TRANSFER_ENCODING)]
            hdr_mode = "empty"
        elif has_te:  # Transfer-Encoding wins over Content-Length  # spec: N-000207 N-000201 N-000202 N-000203 N-000204 N-000205 N-000206
            if peer11:
                items = [it for it in items if it[0].lower() != _CONTENT_LENGTH]
                hdr_mode = "chunked"
            else:
                items = [it for it in items if it[0].lower() not in (_CONTENT_LENGTH, _TRANSFER_ENCODING)]
                hdr_mode = "close"
        elif has_cl:  # spec: N-000198 N-000199
            hdr_mode = "length"
        else:
            if peer11:
                add_te = True
                hdr_mode = "chunked"
            else:
                hdr_mode = "close"
        if add_te:
            items.append((b"Transfer-Encoding", b"chunked"))  # spec: N-000202
        body_mode = "empty" if method == b"HEAD" else hdr_mode  # spec: N-000215 N-000219
        close_delimited = hdr_mode == "close"
        keep_alive = self._keep_alive_ok(resp=event, extra_close=close_delimited)
        if not keep_alive:  # spec: N-000265 N-000266 N-000267 N-000268 N-000269
            items = _apply_connection_close(items)
        head = _status_line(event) + _header_block(items)
        self._send_mode = body_mode
        self._send_remaining = _cl_value(event.headers) if body_mode == "length" else 0
        self._process_event(SERVER, event, close_delimited=close_delimited)
        return [head]

    # ---------------------------------------------------------- public send

    def send(self, event):
        """Encode ``event`` to bytes (``b""`` or ``None`` if it produces none).

        Send operation: encode one event into bytes for the integrator to write and update
        state.  A connection-closed event produces no bytes.  # spec: N-000012 N-000013 N-000497 N-000498 N-000499 N-000500 N-000501
        """
        pieces = self._send_pieces(event)
        if not pieces:
            return None if type(event) is ConnectionClosed else b""
        return b"".join(p if isinstance(p, bytes) else bytes(p) for p in pieces)

    def send_with_data_passthrough(self, event):
        """Like send(), but returns a list of pieces; a non-bytes Data payload is passed through by identity.

        Passthrough send keeps a caller-supplied body placeholder intact for sendfile-style writes.  # spec: N-000029 N-000014 N-000502 N-000503 N-000504 N-000505 N-000506
        """
        return list(self._send_pieces(event))

    def _send_pieces(self, event):
        return self._build_send(event)

    def send_failed(self):  # spec: N-000312 N-000313 N-000314 N-000315 N-000520 N-000521 N-000522 N-000019
        """Mark the last send as failed: the integrator did not transmit those bytes."""
        self._states[self._our_role] = ERROR
        self._fixup()
        return None

    def start_next_cycle(self):  # spec: N-000270 N-000271 N-000280 N-000281 N-000282 N-000517 N-000518 N-000519 N-000018
        """Reset to IDLE for another request/response (both sides must be DONE)."""
        s = self._states
        if s[CLIENT] is not DONE or s[SERVER] is not DONE:
            raise LocalProtocolError("cannot start the next cycle: both sides must be DONE")
        s[CLIENT] = IDLE
        s[SERVER] = IDLE
        self._reset_cycle()
        self._waiting_for_100 = False
        return None

    # ---------------------------------------------------------- receiving

    def receive_data(self, data):  # spec: N-000507 N-000508 N-000509 N-000510 N-000511 N-000144 N-000145 N-000146
        """Store bytes from the peer.  An empty chunk means the peer closed its sending side.

        Feed received bytes: only stores them; changes no state and reads no socket.  # spec: N-000014 N-000016
        """
        data = bytes(data)
        if not data:
            self._closed = True  # spec: N-000339 N-000340
            return None
        if self._closed:
            raise ReceiveClosedError("cannot feed bytes after the receive side was closed")  # spec: N-000180 N-000181 N-000182
        self._buf += data
        return None

    def next_event(self):  # spec: N-000512 N-000513 N-000514 N-000515 N-000516 N-000127 N-000153 N-000154 N-000155 N-000175
        """Parse one event from stored bytes, or return NEED_DATA / PAUSED.

        Pull the next event: parse one event out of the stored bytes and update state.  Need-data
        means no further event is available until more bytes are fed; paused means the next cycle
        or a protocol switch must happen first.  # spec: N-000015 N-000017 N-000018 N-000027 N-000289
        """
        s = self._states
        their = self._their_role
        ts = s[their]
        if ts is ERROR:  # spec: N-000302 N-000303 N-000304 N-000305
            raise RemoteProtocolError("the connection failed earlier", error_status_hint=self._error_hint or 400)
        if ts is SWITCHED_PROTOCOL or s[self._our_role] is SWITCHED_PROTOCOL:  # spec: N-000381 N-000382 N-000383 N-000384
            return PAUSED
        if ts is MIGHT_SWITCH_PROTOCOL:  # spec: N-000373 N-000374 N-000375 N-000376 N-000377 N-000288 N-000289
            return PAUSED
        if ts is CLOSED:
            return ConnectionClosed()
        if ts is DONE or ts is MUST_CLOSE:  # spec: N-000275 N-000276 N-000277 N-000278 N-000279 N-000289 N-000339 N-000341 N-000342 N-000343
            if self._buf:
                return PAUSED
            if self._closed:
                return self._pull_close()
            return NEED_DATA
        if ts is SEND_BODY:
            return self._pull_body()
        return self._pull_head()

    def _pull_close(self):
        """Yield a connection-closed event (half-duplex shutdown).  # spec: N-000035
        """
        self._process_event(self._their_role, ConnectionClosed())  # spec: N-000340 N-000341
        return ConnectionClosed()

    def _pull_head(self):
        buf = self._buf
        their = self._their_role
        if not buf:
            if self._closed:
                if self._states[their] is IDLE:
                    return self._pull_close()
                raise self._remote_error("peer closed the connection in the middle of a message")  # spec: N-000324
            return NEED_DATA
        if buf[0] < 33:  # spec: N-000177 N-000178 N-000179
            raise self._remote_error("request or status line starts with a space or control byte")
        end = _head_end(buf)
        if end < 0:
            if len(buf) > self._max_incomplete:  # spec: N-000316 N-000317 N-000318 N-000319 N-000320 N-000321 N-000322 N-000323
                raise self._remote_error("incomplete event exceeds the size limit", 431)
            if self._closed:
                raise self._remote_error("peer closed the connection in the middle of a header block")  # spec: N-000324
            return NEED_DATA
        block = bytes(buf[:end])
        del buf[:end]
        try:
            event = _parse_head(their, block)
        except LocalProtocolError as exc:
            raise self._remote_error(str(exc), exc.error_status_hint)
        if not self._check_recv_allowed(their, event):
            raise self._remote_error("%s is not allowed in the current state" % type(event).__name__)
        if type(event) is Request:
            self._their_version = event.http_version  # spec: N-000170 N-000171 N-000486
            mode, n = _request_framing(event.headers)
            self._recv_mode = mode
            self._recv_remaining = n
            self._process_event(CLIENT, event)
        elif type(event) is InformationalResponse:
            self._their_version = event.http_version
            self._process_event(SERVER, event)
        else:
            self._their_version = event.http_version
            accepting = self._accepts(event)
            mode, n = _response_framing(event, self._cycle_request, accepting)
            self._recv_mode = mode
            self._recv_remaining = n
            self._process_event(SERVER, event, close_delimited=(mode == "close"))
        return event

    def _pull_body(self):
        mode = self._recv_mode
        buf = self._buf
        if mode == "empty":
            return self._finish_body()
        if mode == "length":
            if self._recv_remaining == 0:
                return self._finish_body()
            if buf:
                n = min(len(buf), self._recv_remaining)
                data = bytes(buf[:n])
                del buf[:n]
                self._recv_remaining -= n
                return Data(data)
            if self._closed:
                raise self._remote_error("peer closed the connection in the middle of a body")  # spec: N-000324
            return NEED_DATA
        if mode == "chunked":
            return self._pull_chunked()
        # close-delimited
        if buf:
            data = bytes(buf)
            del buf[:]
            return Data(data)  # spec: N-000208 N-000209 N-000210 N-000211
        if self._closed:
            return self._finish_body()
        return NEED_DATA

    def _finish_body(self):
        their = self._their_role
        ev = EndOfMessage()
        self._recv_mode = None
        self._process_event(their, ev)
        return ev

    def _pull_chunked(self):
        buf = self._buf
        while True:
            st = self._recv_chunk_state or "size"
            if st == "size":
                idx = buf.find(b"\n")
                if idx < 0:
                    if len(buf) > self._max_incomplete:
                        raise self._remote_error("chunk-size line is too long")
                    if self._closed:
                        raise self._remote_error("peer closed in the middle of a chunked body")
                    return NEED_DATA
                line = bytes(buf[:idx])
                del buf[:idx + 1]
                if line.endswith(b"\r"):
                    line = line[:-1]
                size_part = line.split(b";", 1)[0]  # chunk extensions are parsed and discarded  # spec: N-000066 N-000067 N-000231 N-000232
                if not _CHUNK_SIZE_RE.match(size_part):  # spec: N-000242 N-000243 N-000244 N-000245
                    raise self._remote_error("invalid chunk-size line")
                size = int(size_part, 16)
                if size == 0:
                    self._recv_chunk_state = "trailer"
                    continue
                self._recv_chunk_state = "data"
                self._recv_chunk_remaining = size
                self._recv_chunk_started = False
                continue
            if st == "data":
                if not buf:
                    if self._closed:
                        raise self._remote_error("peer closed in the middle of a chunk")
                    return NEED_DATA
                n = min(len(buf), self._recv_chunk_remaining)
                data = bytes(buf[:n])
                del buf[:n]
                self._recv_chunk_remaining -= n
                start = not self._recv_chunk_started  # spec: N-000220 N-000221 N-000222 N-000223 N-000224 N-000225 N-000226 N-000227
                self._recv_chunk_started = True
                end = self._recv_chunk_remaining == 0
                if end:
                    self._recv_chunk_state = "crlf"
                return Data(data, chunk_start=start, chunk_end=end)
            if st == "crlf":
                if len(buf) >= 2:
                    if bytes(buf[:2]) != b"\r\n":  # spec: N-000245 N-000197
                        raise self._remote_error("chunk data is not followed by CRLF")
                    del buf[:2]
                    self._recv_chunk_state = "size"
                    continue
                if len(buf) == 1 and buf[0] != 13:
                    raise self._remote_error("chunk data is not followed by CRLF")
                if self._closed:
                    raise self._remote_error("peer closed in the middle of a chunk")
                return NEED_DATA
            # trailer section
            end = _head_end(buf)
            if end < 0:
                if len(buf) > self._max_incomplete:
                    raise self._remote_error("trailer block is too long", 431)
                if self._closed:
                    raise self._remote_error("peer closed in the middle of trailers")
                return NEED_DATA
            block = bytes(buf[:end])
            del buf[:end]
            try:
                trailers = _parse_fields(_block_lines(block))
            except LocalProtocolError as exc:
                raise self._remote_error(str(exc), exc.error_status_hint)
            self._recv_chunk_state = None
            self._recv_mode = None
            ev = EndOfMessage(headers=trailers)
            self._process_event(self._their_role, ev)
            return ev


def _cl_value(headers):
    for n, v in headers.raw_items():
        if n.lower() == _CONTENT_LENGTH:
            return int(v)
    return 0


def _response_framing(resp, request, accepting):
    """Body framing for a received final or informational response."""
    # spec: N-000208 N-000209 N-000212 N-000213 N-000214 N-000215 N-000217 N-000218
    code = resp.status_code
    if code < 200 or code in (204, 304) or accepting:
        return "empty", 0
    if request is not None and request.method == b"HEAD":
        return "empty", 0
    if _has_header(resp.headers, _TRANSFER_ENCODING):
        return "chunked", 0
    if _has_header(resp.headers, _CONTENT_LENGTH):
        return "length", _cl_value(resp.headers)
    return "close", 0


def _head_end(buf):
    """Index just past the blank line ending a head/header block, or -1."""
    pos = 0
    while True:
        idx = buf.find(b"\n", pos)
        if idx < 0:
            return -1
        if idx == pos or (idx == pos + 1 and buf[pos] == 13):
            return idx + 1
        pos = idx + 1


def _block_lines(block):
    """Split a block into lines without their line endings, dropping the blank terminator."""
    parts = block.split(b"\n")
    out = []
    for p in parts[:-1]:
        if p.endswith(b"\r"):
            p = p[:-1]
        out.append(p)
    if out and out[-1] == b"":
        out.pop()
    return out


def _parse_fields(lines):
    pairs = []
    for line in lines:
        if line[:1] in (b" ", b"\t"):  # obsolete line folding is accepted when reading  # spec: N-000167 N-000168 N-000169
            if not pairs:
                raise LocalProtocolError("continuation line with no preceding header")  # spec: N-000176
            name, value = pairs[-1]
            cont = line.strip(b" \t")
            joined = value.rstrip(b" \t")
            if cont:
                joined = joined + b" " + cont
            pairs[-1] = (name, joined)
            continue
        idx = line.find(b":")
        if idx <= 0:
            raise LocalProtocolError("malformed header line")
        name = line[:idx]
        if not TOKEN_RE.match(name):
            raise LocalProtocolError("header name is not an RFC 7230 token")
        pairs.append((name, line[idx + 1:].strip(b" \t")))
    return normalize_headers(pairs)


def _parse_head(their, block):
    lines = _block_lines(block)
    start = lines[0]
    fields = lines[1:]
    if their is CLIENT:
        parts = start.split(b" ")
        if len(parts) != 3:
            raise LocalProtocolError("malformed request line")
        method, target, version = parts
        m = _REQUEST_VERSION_RE.match(version)
        if not m:
            raise LocalProtocolError("unsupported HTTP version")
        return Request(method, target, _parse_fields(fields), http_version=m.group(1))
    m = _STATUS_LINE_RE.match(start)
    if not m:
        raise LocalProtocolError("malformed status line")
    version = m.group(1)
    code = int(m.group(2))
    reason = m.group(3) or b""
    if code < 100:
        raise LocalProtocolError("status code below 100")
    headers = _parse_fields(fields)
    if code < 200:
        return InformationalResponse(code, headers, http_version=version, reason=reason)
    return Response(code, headers, http_version=version, reason=reason)
