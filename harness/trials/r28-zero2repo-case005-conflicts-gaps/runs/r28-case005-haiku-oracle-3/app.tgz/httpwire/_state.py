"""Role, state and non-event sentinel objects.

All of these are distinct, identity-compared objects (not strings).
"""


class _Named:
    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return "httpwire." + self._name


# Roles  # spec: N-000438 N-000439
CLIENT = _Named("CLIENT")
SERVER = _Named("SERVER")

# Non-event results of next_event()  # spec: N-000440 N-000441 N-000442
NEED_DATA = _Named("NEED_DATA")
PAUSED = _Named("PAUSED")

# The nine states  # spec: N-000443 N-000444 N-000445 N-000123 N-000124 N-000125
IDLE = _Named("IDLE")
SEND_RESPONSE = _Named("SEND_RESPONSE")
SEND_BODY = _Named("SEND_BODY")
DONE = _Named("DONE")
MUST_CLOSE = _Named("MUST_CLOSE")
CLOSED = _Named("CLOSED")
MIGHT_SWITCH_PROTOCOL = _Named("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = _Named("SWITCHED_PROTOCOL")
ERROR = _Named("ERROR")

ALL_STATES = (
    IDLE, SEND_RESPONSE, SEND_BODY, DONE, MUST_CLOSE,
    CLOSED, MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL, ERROR,
)
