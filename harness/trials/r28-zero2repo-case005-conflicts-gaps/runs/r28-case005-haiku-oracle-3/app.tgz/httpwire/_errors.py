"""Exception classes for httpwire.

Error wording is free (N-000058).  # spec: N-000058 N-000472 N-000473
"""


class _ProtocolErrorBase(Exception):
    """Common base for the two protocol-error kinds.

    Every protocol error carries ``error_status_hint``: the suggested HTTP
    status (default 400).  # spec: N-000292 N-000293 N-000294 N-000295 N-000296
    """

    def __init__(self, message="", error_status_hint=400):  # the default suggested status is 400  # spec: N-000020
        super().__init__(message)
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(_ProtocolErrorBase):
    """The integrator's own event or send violated the protocol."""  # spec: N-000290 N-000291 N-000326


class RemoteProtocolError(_ProtocolErrorBase):
    """The peer's bytes violated the protocol."""  # spec: N-000290 N-000291 N-000326


class ReceiveClosedError(RuntimeError):
    """Bytes were fed after the receive side was already closed.

    This is a runtime error, deliberately not a protocol error.  # spec: N-000474 N-000475 N-000348 N-000180 N-000181 N-000182
    """
