"""Connection behaviour: send/receive, framing, lifecycle, errors, switches."""

import unittest

import httpwire
from httpwire import (
    CLIENT, CLOSED, DONE, ERROR, IDLE, MIGHT_SWITCH_PROTOCOL, MUST_CLOSE, NEED_DATA,
    PAUSED, SEND_BODY, SEND_RESPONSE, SERVER, SWITCHED_PROTOCOL,
    ConnectionClosed, Connection, Data, EndOfMessage, InformationalResponse,
    LocalProtocolError, RemoteProtocolError, Request, Response,
)


def get(host=b"a", **extra):
    return Request(method=b"GET", target=b"/", headers=[(b"Host", host)], **extra)


def post(length=None, chunked=False, **extra):
    hdrs = [(b"Host", b"a")]
    if length is not None:
        hdrs.append((b"Content-Length", str(length).encode()))
    if chunked:
        hdrs.append((b"Transfer-Encoding", b"chunked"))
    return Request(method=b"POST", target=b"/", headers=hdrs, **extra)


class Pair:
    """Drive a client and server connection by hand (bytes are moved explicitly)."""

    def __init__(self):
        self.c = Connection(CLIENT)
        self.s = Connection(SERVER)

    def c_to_s(self, data):
        self.s.receive_data(data)

    def s_to_c(self, data):
        self.c.receive_data(data)

    def drain(self, conn):
        out = []
        while True:
            ev = conn.next_event()
            if ev is NEED_DATA or ev is PAUSED:
                out.append(ev)
                return out
            out.append(ev)


class TestRoles(unittest.TestCase):
    # spec: N-000476 N-000477 N-000172 N-000173
    def test_role_validation(self):
        with self.assertRaises(LocalProtocolError):
            Connection("client")
        with self.assertRaises(LocalProtocolError):
            Connection(None)

    # spec: N-000481 N-000482 N-000483 N-000484 N-000485 N-000126
    def test_state_attributes_agree(self):
        c = Connection(CLIENT)
        self.assertIs(c.our_role, CLIENT)
        self.assertIs(c.their_role, SERVER)
        self.assertEqual(c.states, {CLIENT: IDLE, SERVER: IDLE})
        self.assertIs(c.our_state, IDLE)
        self.assertIs(c.their_state, IDLE)
        self.assertIsNone(c.their_http_version)
        self.assertEqual(c.trailing_data, (b"", False))

    # spec: N-000123 N-000124 N-000125 N-000478 N-000479 N-000480
    def test_max_incomplete_size_argument(self):
        Connection(SERVER, 1000)
        with self.assertRaises(LocalProtocolError):
            Connection(SERVER, "1000")


class TestSendAndPull(unittest.TestCase):
    # spec: N-000127 N-000128 N-000129 N-000130 N-000131 N-000132 N-000133
    def test_pull_on_empty_returns_need_data(self):
        self.assertIs(Connection(SERVER).next_event(), NEED_DATA)

    # spec: N-000134 N-000135 N-000136 N-000137 N-000138 N-000139
    def test_request_round_trip(self):
        p = Pair()
        data = p.c.send(get())
        self.assertEqual(data, b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
        self.assertEqual(p.c.states, {CLIENT: SEND_BODY, SERVER: SEND_RESPONSE})
        p.c_to_s(data)
        ev = p.s.next_event()
        self.assertIsInstance(ev, Request)
        self.assertEqual(ev.method, b"GET")
        self.assertEqual(p.s.their_http_version, b"1.1")
        self.assertEqual(p.s.states, {CLIENT: SEND_BODY, SERVER: SEND_RESPONSE})
        # an empty request body is delivered as an end-of-message on the next pull
        self.assertIsInstance(p.s.next_event(), EndOfMessage)
        self.assertEqual(p.s.states, {CLIENT: DONE, SERVER: SEND_RESPONSE})

    # spec: N-000140 N-000141 N-000142 N-000143 N-000144 N-000145 N-000146 N-000147 N-000148 N-000149 N-000150
    def test_pull_yields_one_event_and_leftover_stays(self):
        p = Pair()
        p.c_to_s(b"GET / HTTP/1.1\r\nHost: a\r\n\r\nGET /2 HTTP/1.1\r\nHost: a\r\n\r\n")
        self.assertIsInstance(p.s.next_event(), Request)
        self.assertIsInstance(p.s.next_event(), EndOfMessage)
        self.assertIs(p.s.next_event(), PAUSED)  # client is DONE: pipelined bytes wait
        self.assertIn(b"GET /2", p.s.trailing_data[0])

    # spec: N-000151 N-000152 N-000153 N-000154 N-000155
    def test_partial_event_returns_need_data_and_retains_bytes(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nHost")
        self.assertIs(s.next_event(), NEED_DATA)
        self.assertEqual(s.trailing_data[0], b"GET / HTTP/1.1\r\nHost")
        s.receive_data(b": a\r\n\r\n")
        self.assertIsInstance(s.next_event(), Request)

    # spec: N-000156 N-000157 N-000158 N-000159 N-000160
    def test_http10_request_pulled_empty_body(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.0\r\n\r\n")
        req = s.next_event()
        self.assertEqual(req.http_version, b"1.0")
        self.assertIsInstance(s.next_event(), EndOfMessage)
        self.assertEqual(s.their_http_version, b"1.0")

    # spec: N-000161 N-000162
    def test_host_written_first(self):
        c = Connection(CLIENT)
        data = c.send(Request(method=b"GET", target=b"/", headers=[(b"X-A", b"1"), (b"Host", b"h")]))
        self.assertEqual(data, b"GET / HTTP/1.1\r\nHost: h\r\nX-A: 1\r\n\r\n")

    # spec: N-000163 N-000164 N-000165 N-000166
    def test_lone_lf_and_missing_reason_accepted(self):
        c = Connection(CLIENT)
        c.send(get())
        c.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 200\nContent-Length: 0\n\n")
        ev = c.next_event()
        self.assertIsInstance(ev, Response)
        self.assertEqual(ev.reason, b"")

    # spec: N-000167 N-000168 N-000169
    def test_obsolete_line_folding_joined(self):
        c = Connection(CLIENT)
        c.send(get())
        c.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 200 OK\r\nX-Long: a\r\n   b\r\n\tc\r\nContent-Length: 0\r\n\r\n")
        ev = c.next_event()
        self.assertEqual(ev.headers.raw_items()[0], (b"X-Long", b"a b c"))

    # spec: N-000172 N-000174 N-000175 N-000176
    def test_malformed_peer_bytes_are_remote_errors(self):
        s = Connection(SERVER)
        s.receive_data(b"GE T / HTTP/1.1\r\nHost: a\r\n\r\n")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()
        self.assertIs(s.their_state, ERROR)
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    # spec: N-000177 N-000178 N-000179
    def test_leading_space_or_control_fails_at_once(self):
        s = Connection(SERVER)
        s.receive_data(b"\r\n")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    # spec: N-000180 N-000181 N-000182
    def test_bytes_after_receive_close_is_runtime_error(self):
        s = Connection(SERVER)
        s.receive_data(b"")
        with self.assertRaises(RuntimeError) as cm:
            s.receive_data(b"x")
        self.assertNotIsInstance(cm.exception, (LocalProtocolError, RemoteProtocolError))

    # spec: N-000283 N-000284 N-000285
    def test_client_cannot_send_response(self):
        c = Connection(CLIENT)
        with self.assertRaises(LocalProtocolError):
            c.send(Response(200, []))
        self.assertIs(c.our_state, ERROR)

    # spec: N-000157 N-000158 N-000159 N-000283
    def test_server_cannot_send_request(self):
        s = Connection(SERVER)
        with self.assertRaises(LocalProtocolError):
            s.send(get())

    # spec: N-000156 N-000159
    def test_http10_request_cannot_be_sent(self):
        c = Connection(CLIENT)
        with self.assertRaises(LocalProtocolError):
            c.send(Request(method=b"GET", target=b"/", headers=[(b"Host", b"a")], http_version=b"1.0"))


class TestBodyFraming(unittest.TestCase):
    # spec: N-000185 N-000186 N-000187
    def test_no_framing_means_empty_body(self):
        p = Pair()
        p.c.send(get())
        self.assertEqual(p.c.send(EndOfMessage()), b"")
        p.c_to_s(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
        p.s.next_event()
        self.assertIsInstance(p.s.next_event(), EndOfMessage)

    # spec: N-000188 N-000189 N-000190 N-000191 N-000204
    def test_content_length_request(self):
        c = Connection(CLIENT)
        head = c.send(post(length=5))
        self.assertEqual(head, b"POST / HTTP/1.1\r\nHost: a\r\nContent-Length: 5\r\n\r\n")
        self.assertEqual(c.send(Data(b"hel")), b"hel")
        with self.assertRaises(LocalProtocolError):
            c.send(EndOfMessage())
        self.assertIs(c.our_state, ERROR)

    # spec: N-000238 N-000239
    def test_data_beyond_content_length_refused(self):
        c = Connection(CLIENT)
        c.send(post(length=2))
        with self.assertRaises(LocalProtocolError):
            c.send(Data(b"abc"))

    # spec: N-000192 N-000193 N-000194 N-000195 N-000196 N-000197
    def test_chunked_request_round_trip(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        head = c.send(post(chunked=True))
        body = c.send(Data(b"hello")) + c.send(Data(b"!!")) + c.send(EndOfMessage(headers=[(b"X-T", b"v")]))
        self.assertEqual(body, b"5\r\nhello\r\n2\r\n!!\r\n0\r\nX-T: v\r\n\r\n")
        s.receive_data(head + body)
        self.assertIsInstance(s.next_event(), Request)
        d1 = s.next_event()
        self.assertEqual((d1.data, d1.chunk_start, d1.chunk_end), (b"hello", True, True))
        d2 = s.next_event()
        self.assertEqual((d2.data, d2.chunk_start, d2.chunk_end), (b"!!", True, True))
        eom = s.next_event()
        self.assertEqual(list(eom.headers), [(b"x-t", b"v")])
        self.assertIs(s.their_state, DONE)

    # spec: N-000220 N-000221 N-000222 N-000223 N-000224 N-000225 N-000226 N-000227
    def test_chunk_marks_across_pieces(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\n")
        s.next_event()
        s.receive_data(b"6\r\nabc")
        d = s.next_event()
        self.assertEqual((d.data, d.chunk_start, d.chunk_end), (b"abc", True, False))
        s.receive_data(b"def\r\n")
        d = s.next_event()
        self.assertEqual((d.data, d.chunk_start, d.chunk_end), (b"def", False, True))
        self.assertIs(s.next_event(), NEED_DATA)

    # spec: N-000228 N-000229 N-000230 N-000231 N-000232 N-000233 N-000234 N-000235
    def test_chunk_extensions_discarded_and_size_limit(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\n"
                       b"3;name=val\r\nabc\r\n0\r\n\r\n")
        s.next_event()
        d = s.next_event()
        self.assertEqual(d.data, b"abc")
        self.assertIsInstance(s.next_event(), EndOfMessage)

    # spec: N-000242 N-000243 N-000244 N-000245
    def test_bad_chunk_size_lines_refused(self):
        for bad in [b"zz\r\nx\r\n", b"3 \r\nabc\r\n", b"3\r\nabcX\r\n"]:
            with self.subTest(bad=bad):
                s = Connection(SERVER)
                s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\n" + bad)
                s.next_event()
                with self.assertRaises(RemoteProtocolError):
                    while True:
                        ev = s.next_event()
                        if ev is NEED_DATA:
                            self.fail("expected a refusal")

    # spec: N-000236 N-000237
    def test_passthrough_keeps_payload_identity(self):
        c = Connection(CLIENT)
        c.send(post(chunked=True))
        payload = memoryview(b"0123456789")

        class Placeholder:
            def __len__(self):
                return 7

        ph = Placeholder()
        pieces = c.send_with_data_passthrough(Data(ph))
        self.assertIsInstance(pieces, list)
        self.assertIs(pieces[1], ph)
        self.assertEqual(pieces[0], b"7\r\n")
        self.assertEqual(pieces[2], b"\r\n")
        self.assertTrue(payload.nbytes == 10)

    # spec: N-000233 N-000234 N-000235
    def test_passthrough_length_mode_adds_no_pieces(self):
        c = Connection(CLIENT)
        c.send(post(length=4))

        class Placeholder:
            def __len__(self):
                return 4

        ph = Placeholder()
        self.assertEqual(c.send_with_data_passthrough(Data(ph)), [ph])

    # spec: N-000198 N-000199 N-000200 N-000201 N-000202 N-000203 N-000205 N-000206 N-000207
    def test_response_framing_by_peer_version(self):
        p = Pair()
        p.c.send(get())
        p.c.send(EndOfMessage())
        p.s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
        p.s.next_event()
        p.s.next_event()
        head = p.s.send(Response(200, []))
        self.assertEqual(head, b"HTTP/1.1 200 \r\nTransfer-Encoding: chunked\r\n\r\n")
        self.assertEqual(p.s.send(Data(b"ab")), b"2\r\nab\r\n")
        self.assertEqual(p.s.send(EndOfMessage()), b"0\r\n\r\n")
        self.assertIs(p.s.our_state, DONE)

    # spec: N-000198 N-000199 N-000200 N-000201 N-000207
    def test_response_with_both_headers_transfer_encoding_wins(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
        s.next_event()
        s.next_event()
        head = s.send(Response(200, [(b"Content-Length", b"3"), (b"Transfer-Encoding", b"chunked")]))
        self.assertNotIn(b"Content-Length", head)
        self.assertIn(b"Transfer-Encoding: chunked", head)

    # spec: N-000198 N-000199 N-000218
    def test_content_length_response_keeps_header_and_counts(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
        s.next_event()
        s.next_event()
        self.assertEqual(s.send(Response(200, [(b"Content-Length", b"2")])),
                         b"HTTP/1.1 200 \r\nContent-Length: 2\r\n\r\n")
        self.assertEqual(s.send(Data(b"hi")), b"hi")
        self.assertEqual(s.send(EndOfMessage()), b"")
        self.assertEqual(s.states[SERVER], DONE)

    # spec: N-000208 N-000209 N-000210 N-000211 N-000212 N-000213 N-000214
    def test_close_delimited_response_body_until_close(self):
        c = Connection(CLIENT)
        c.send(Request(method=b"GET", target=b"/", headers=[(b"Host", b"a")]))
        c.send(EndOfMessage())
        c.receive_data(b"HTTP/1.0 200 OK\r\n\r\nbody")
        self.assertIsInstance(c.next_event(), Response)
        self.assertEqual(c.next_event(), Data(b"body"))
        self.assertIs(c.next_event(), NEED_DATA)
        c.receive_data(b"")
        self.assertIsInstance(c.next_event(), EndOfMessage)
        self.assertIsInstance(c.next_event(), ConnectionClosed)
        self.assertIs(c.our_state, MUST_CLOSE)

    # spec: N-000215 N-000216 N-000217
    def test_head_response_has_empty_body(self):
        c = Connection(CLIENT)
        c.send(Request(method=b"HEAD", target=b"/", headers=[(b"Host", b"a")]))
        c.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 100\r\n\r\n")
        self.assertIsInstance(c.next_event(), Response)
        self.assertIsInstance(c.next_event(), EndOfMessage)

    # spec: N-000215 N-000216 N-000217 N-000218
    def test_204_and_304_always_empty(self):
        for code in (204, 304):
            with self.subTest(code=code):
                c = Connection(CLIENT)
                c.send(get())
                c.send(EndOfMessage())
                c.receive_data(b"HTTP/1.1 %d X\r\nContent-Length: 9\r\n\r\n" % code)
                self.assertIsInstance(c.next_event(), Response)
                self.assertIsInstance(c.next_event(), EndOfMessage)

    # spec: N-000219
    def test_head_response_from_server_uses_get_framing(self):
        s = Connection(SERVER)
        s.receive_data(b"HEAD / HTTP/1.1\r\nHost: a\r\n\r\n")
        s.next_event()
        s.next_event()
        head = s.send(Response(200, []))
        self.assertIn(b"Transfer-Encoding: chunked", head)
        self.assertEqual(s.send(EndOfMessage()), b"")

    # spec: N-000238 N-000240 N-000241
    def test_trailers_refused_without_chunking(self):
        c = Connection(CLIENT)
        c.send(post(length=0))
        with self.assertRaises(LocalProtocolError):
            c.send(EndOfMessage(headers=[(b"X", b"1")]))

    # spec: N-000240 N-000241
    def test_trailers_refused_for_http10_peer_even_if_chunked(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.0\r\n\r\n")
        s.next_event()
        s.next_event()
        s.send(Response(200, [(b"Transfer-Encoding", b"chunked")]))
        with self.assertRaises(LocalProtocolError):
            s.send(EndOfMessage(headers=[(b"X", b"1")]))

    # spec: N-000246
    def test_non_chunked_transfer_coding_refused_at_construction(self):
        with self.assertRaises(LocalProtocolError):
            Response(200, [(b"Transfer-Encoding", b"gzip")])


class TestKeepAliveAndCycles(unittest.TestCase):
    # spec: N-000259 N-000260 N-000261 N-000262 N-000263 N-000264
    def test_keep_alive_default_and_cycle_restart(self):
        p = Pair()
        p.c.send(get())
        p.c.send(EndOfMessage())
        p.c_to_s(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
        self.assertIsInstance(p.s.next_event(), Request)
        self.assertIsInstance(p.s.next_event(), EndOfMessage)
        p.s.send(Response(200, [(b"Content-Length", b"0")]))
        p.s.send(EndOfMessage())
        self.assertEqual(p.s.states, {CLIENT: DONE, SERVER: DONE})
        p.c.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
        self.assertIsInstance(p.c.next_event(), Response)
        self.assertIsInstance(p.c.next_event(), EndOfMessage)
        self.assertEqual(p.c.states, {CLIENT: DONE, SERVER: DONE})
        # cycle restart on both sides
        p.c.start_next_cycle()
        p.s.start_next_cycle()
        self.assertEqual(p.c.states, {CLIENT: IDLE, SERVER: IDLE})
        self.assertEqual(p.s.states, {CLIENT: IDLE, SERVER: IDLE})

    # spec: N-000265 N-000266 N-000267 N-000268 N-000269
    def test_http10_request_gets_connection_close(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.0\r\n\r\n")
        s.next_event()
        s.next_event()
        head = s.send(Response(200, [(b"Content-Length", b"0"), (b"Connection", b"keep-alive")]))
        self.assertIn(b"Connection: close", head)
        self.assertNotIn(b"keep-alive", head)
        s.send(EndOfMessage())
        self.assertIs(s.our_state, MUST_CLOSE)

    # spec: N-000248 N-000270 N-000271 N-000272 N-000273 N-000274
    def test_client_cannot_pipeline_requests(self):
        c = Connection(CLIENT)
        c.send(get())
        c.send(EndOfMessage())
        with self.assertRaises(LocalProtocolError):
            c.send(get())
        self.assertIs(c.our_state, ERROR)

    # spec: N-000275 N-000276 N-000277 N-000278 N-000279
    def test_server_serves_pipelined_requests_serially(self):
        s = Connection(SERVER)
        s.receive_data(b"GET /1 HTTP/1.1\r\nHost: a\r\n\r\nGET /2 HTTP/1.1\r\nHost: a\r\n\r\n")
        r1 = s.next_event()
        self.assertEqual(r1.target, b"/1")
        s.next_event()
        self.assertIs(s.next_event(), PAUSED)
        s.receive_data(b"GET /3 HTTP/1.1\r\nHost: a\r\n\r\n")
        self.assertIs(s.next_event(), PAUSED)
        s.send(Response(200, [(b"Content-Length", b"0")]))
        s.send(EndOfMessage())
        self.assertIs(s.next_event(), PAUSED)  # still DONE-side paused until cycle start

    # spec: N-000280 N-000281 N-000282
    def test_start_next_cycle_refused_is_recoverable(self):
        c = Connection(CLIENT)
        c.send(get())
        with self.assertRaises(LocalProtocolError):
            c.start_next_cycle()
        self.assertIs(c.our_state, SEND_BODY)
        c.send(EndOfMessage())
        self.assertIs(c.our_state, DONE)

    # spec: N-000286 N-000287 N-000288
    def test_http10_exchange_cannot_restart(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.0\r\n\r\n")
        s.next_event()
        s.next_event()
        s.send(Response(200, [(b"Content-Length", b"0")]))
        s.send(EndOfMessage())
        with self.assertRaises(LocalProtocolError):
            s.start_next_cycle()
        self.assertIs(s.our_state, MUST_CLOSE)

    # spec: N-000289
    def test_pause_distinct_from_need_data(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
        s.next_event()
        s.next_event()
        s.receive_data(b"GET /2 HTTP/1.1\r\nHost: a\r\n\r\n")
        s.send(Response(200, [(b"Content-Length", b"0")]))
        s.send(EndOfMessage())
        self.assertIs(s.next_event(), PAUSED)


class TestShutdown(unittest.TestCase):
    # spec: N-000035 N-000332 N-000333 N-000334 N-000335 N-000336 N-000337 N-000338 N-000344
    def test_send_connection_closed_from_idle_closes_and_marks_peer(self):
        c = Connection(CLIENT)
        self.assertIsNone(c.send(ConnectionClosed()))
        self.assertIs(c.our_state, CLOSED)
        self.assertIs(c.their_state, MUST_CLOSE)

    # spec: N-000339 N-000340 N-000341 N-000342 N-000343 N-000347 N-000348
    def test_pulled_close_from_idle_then_repeats(self):
        s = Connection(SERVER)
        s.receive_data(b"")
        self.assertIsInstance(s.next_event(), ConnectionClosed)
        self.assertIsInstance(s.next_event(), ConnectionClosed)
        self.assertIs(s.their_state, CLOSED)
        self.assertIs(s.our_state, MUST_CLOSE)

    # spec: N-000345 N-000346 N-000347
    def test_close_not_allowed_mid_message(self):
        c = Connection(CLIENT)
        c.send(get())
        with self.assertRaises(LocalProtocolError):
            c.send(ConnectionClosed())

    # spec: N-000324 N-000325
    def test_close_mid_content_length_body_is_remote_error(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nContent-Length: 9\r\n\r\nab")
        s.next_event()
        self.assertEqual(s.next_event(), Data(b"ab"))
        s.receive_data(b"")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    # spec: N-000324
    def test_close_mid_header_block_is_remote_error(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nHo")
        self.assertIs(s.next_event(), NEED_DATA)
        s.receive_data(b"")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()


class TestErrors(unittest.TestCase):
    # spec: N-000290 N-000291 N-000292 N-000293 N-000294 N-000295 N-000296
    def test_default_hint_400(self):
        s = Connection(SERVER)
        s.receive_data(b"NOT HTTP\r\n\r\n")
        with self.assertRaises(RemoteProtocolError) as cm:
            s.next_event()
        self.assertIs(type(cm.exception.error_status_hint), int)
        self.assertEqual(cm.exception.error_status_hint, 400)

    # spec: N-000033 N-000316 N-000317 N-000318 N-000319 N-000320 N-000321 N-000322 N-000323
    def test_incomplete_event_size_limit_431(self):
        s = Connection(SERVER, 50)
        s.receive_data(b"GET / HTTP/1.1\r\n" + b"X-Pad: " + b"a" * 60)
        with self.assertRaises(RemoteProtocolError) as cm:
            s.next_event()
        self.assertEqual(cm.exception.error_status_hint, 431)
        self.assertIs(s.their_state, ERROR)

    # spec: N-000316 N-000317 N-000318 N-000323
    def test_body_bytes_do_not_count_against_limit(self):
        s = Connection(SERVER, 50)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nContent-Length: 200\r\n\r\n")
        s.next_event()
        s.receive_data(b"x" * 150)
        self.assertEqual(s.next_event(), Data(b"x" * 150))

    # spec: N-000302 N-000303 N-000304 N-000305 N-000306
    def test_remote_error_then_error_response_closes(self):
        s = Connection(SERVER)
        s.receive_data(b"GET /\r\n\r\n")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()
        self.assertIs(s.their_state, ERROR)
        self.assertIs(s.our_state, IDLE)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()
        head = s.send(Response(400, [(b"Content-Length", b"0")]))
        self.assertIn(b"Connection: close", head)
        self.assertIs(s.our_state, SEND_BODY)
        s.send(EndOfMessage())
        self.assertIs(s.our_state, MUST_CLOSE)

    # spec: N-000032 N-000034 N-000307 N-000308 N-000309 N-000310 N-000311
    def test_local_send_error_is_sticky(self):
        c = Connection(CLIENT)
        c.send(get())
        c.send(EndOfMessage())
        with self.assertRaises(LocalProtocolError):
            c.send(Data(b"x"))
        self.assertIs(c.our_state, ERROR)
        with self.assertRaises(LocalProtocolError):
            c.send(EndOfMessage())
        self.assertIs(c.our_state, ERROR)

    # spec: N-000312 N-000313 N-000314 N-000315
    def test_send_failed_marks_error_and_done_peer_must_close(self):
        c = Connection(CLIENT)
        c.send(get())
        c.send(EndOfMessage())
        self.assertIs(c.our_state, DONE)
        c.send_failed()
        self.assertIs(c.our_state, ERROR)
        self.assertIs(c.their_state, SEND_RESPONSE)
        with self.assertRaises(LocalProtocolError):
            c.send(get())

    # spec: N-000326 N-000327 N-000328 N-000329 N-000330 N-000331
    def test_error_states_cannot_be_left_by_cycle_start(self):
        c = Connection(CLIENT)
        c.send(get())
        c.send_failed()
        with self.assertRaises(LocalProtocolError):
            c.start_next_cycle()
        self.assertIs(c.our_state, ERROR)

    # spec: N-000297 N-000298 N-000299 N-000300 N-000301
    def test_invalid_construction_leaves_connection_usable(self):
        c = Connection(CLIENT)
        with self.assertRaises(LocalProtocolError):
            Request(method=b"GET", target=b"/", headers=[])
        c.send(get())
        self.assertIs(c.our_state, SEND_BODY)


class TestSwitchAndContinue(unittest.TestCase):
    # spec: N-000349 N-000350 N-000351 N-000352 N-000353
    def test_informational_responses_before_final(self):
        p = Pair()
        p.c.send(Request(method=b"POST", target=b"/", headers=[
            (b"Host", b"a"), (b"Content-Length", b"3"), (b"Expect", b"100-continue")]))
        p.s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nContent-Length: 3\r\nExpect: 100-continue\r\n\r\n")
        p.s.next_event()
        self.assertEqual(p.s.send(InformationalResponse(100, [])), b"HTTP/1.1 100 \r\n\r\n")
        p.c.receive_data(b"HTTP/1.1 100 \r\n\r\n")
        self.assertIs(p.c.client_is_waiting_for_100_continue, True)
        self.assertIsInstance(p.c.next_event(), InformationalResponse)
        self.assertIs(p.c.our_state, SEND_BODY)
        # any informational response from the server ends the wait  # spec: N-000358
        self.assertIs(p.c.client_is_waiting_for_100_continue, False)

    # spec: N-000354 N-000355 N-000356 N-000357 N-000358 N-000359
    def test_expect_100_continue_flags(self):
        c = Connection(CLIENT)
        self.assertIs(c.client_is_waiting_for_100_continue, False)
        c.send(Request(method=b"POST", target=b"/", headers=[(b"Host", b"a"), (b"Expect", b"100-continue"), (b"Content-Length", b"0")]))
        self.assertIs(c.client_is_waiting_for_100_continue, True)
        self.assertIs(c.they_are_waiting_for_100_continue, False)
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nExpect: 100-Continue\r\nContent-Length: 0\r\n\r\n")
        s.next_event()
        self.assertIs(s.they_are_waiting_for_100_continue, True)
        s.send(InformationalResponse(100, []))
        self.assertIs(s.they_are_waiting_for_100_continue, False)

    # spec: N-000357
    def test_expect_on_http10_sets_no_flag(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.0\r\nExpect: 100-continue\r\nContent-Length: 0\r\n\r\n")
        s.next_event()
        self.assertIs(s.client_is_waiting_for_100_continue, False)

    # spec: N-000360 N-000361 N-000362 N-000363 N-000364 N-000365 N-000366 N-000367 N-000368
    def test_connect_denied_then_next_cycle(self):
        p = Pair()
        p.c.send(Request(method=b"CONNECT", target=b"a:1", headers=[(b"Host", b"a:1")]))
        p.c.send(EndOfMessage())
        self.assertIs(p.c.our_state, MIGHT_SWITCH_PROTOCOL)
        p.s.receive_data(b"CONNECT a:1 HTTP/1.1\r\nHost: a:1\r\n\r\n")
        p.s.next_event()
        p.s.next_event()
        self.assertIs(p.s.next_event(), PAUSED)
        p.s.send(Response(407, [(b"Content-Length", b"0")]))
        p.s.send(EndOfMessage())
        self.assertIs(p.s.our_state, DONE)
        self.assertIs(p.s.their_state, DONE)

    # spec: N-000369 N-000370 N-000371 N-000372 N-000373 N-000374 N-000375 N-000376 N-000377
    # spec: N-000381 N-000382 N-000383 N-000384 N-000385 N-000386 N-000387
    def test_connect_accepted_switches_and_trailing_data_kept(self):
        p = Pair()
        p.c.send(Request(method=b"CONNECT", target=b"a:1", headers=[(b"Host", b"a:1")]))
        p.c.send(EndOfMessage())
        p.s.receive_data(b"CONNECT a:1 HTTP/1.1\r\nHost: a:1\r\n\r\nTUNNEL")
        p.s.next_event()
        p.s.next_event()
        self.assertIs(p.s.next_event(), PAUSED)
        head = p.s.send(Response(200, []))
        self.assertEqual(head, b"HTTP/1.1 200 \r\n\r\n")
        self.assertIs(p.s.our_state, SWITCHED_PROTOCOL)
        self.assertIs(p.s.their_state, SWITCHED_PROTOCOL)
        p.c.receive_data(b"HTTP/1.1 200 \r\n\r\n")
        self.assertIsInstance(p.c.next_event(), Response)
        self.assertIs(p.c.our_state, SWITCHED_PROTOCOL)
        self.assertIs(p.s.next_event(), PAUSED)
        self.assertEqual(p.s.trailing_data, (b"TUNNEL", False))
        with self.assertRaises(LocalProtocolError):
            p.s.send(EndOfMessage())
        self.assertIs(p.s.our_state, ERROR)

    # spec: N-000378 N-000379 N-000380
    def test_upgrade_denied_then_new_request_parsed(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\nUpgrade: foo\r\n\r\n")
        s.next_event()
        s.next_event()
        s.send(Response(200, [(b"Content-Length", b"0")]))
        s.send(EndOfMessage())
        self.assertIs(s.their_state, DONE)
        self.assertIs(s.next_event(), NEED_DATA)

    # spec: N-000388 N-000389 N-000390 N-000391 N-000392 N-000393
    def test_client_in_might_switch_cannot_send_request(self):
        c = Connection(CLIENT)
        c.send(Request(method=b"CONNECT", target=b"a:1", headers=[(b"Host", b"a:1")]))
        c.send(EndOfMessage())
        with self.assertRaises(LocalProtocolError):
            c.send(get())

    # spec: N-000394 N-000395 N-000396 N-000397 N-000398
    def test_status_101_is_informational_and_2xx_is_final(self):
        with self.assertRaises(LocalProtocolError):
            Response(101, [])
        self.assertEqual(InformationalResponse(101, []).status_code, 101)

    # spec: N-000399 N-000400 N-000401 N-000402 N-000403 N-000404 N-000405
    def test_switched_connection_refuses_http(self):
        p = Pair()
        p.c.send(Request(method=b"GET", target=b"/", headers=[(b"Host", b"a"), (b"Upgrade", b"x")]))
        p.c.send(EndOfMessage())
        p.s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\nUpgrade: x\r\n\r\n")
        p.s.next_event()
        p.s.next_event()
        p.s.send(InformationalResponse(101, [(b"Upgrade", b"x")]))
        with self.assertRaises(LocalProtocolError):
            p.s.send(Response(200, []))
        with self.assertRaises(LocalProtocolError):
            p.s.start_next_cycle()

    # spec: N-000406 N-000407 N-000408 N-000409 N-000410 N-000411 N-000412
    def test_unanswered_proposal_cycle_restart_refused(self):
        c = Connection(CLIENT)
        c.send(Request(method=b"CONNECT", target=b"a:1", headers=[(b"Host", b"a:1")]))
        c.send(EndOfMessage())
        with self.assertRaises(LocalProtocolError):
            c.start_next_cycle()
        self.assertIs(c.our_state, MIGHT_SWITCH_PROTOCOL)


if __name__ == "__main__":
    unittest.main()
