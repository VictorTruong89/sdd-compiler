"""Tests for checklist ids whose behaviour is not otherwise exercised directly."""

import os
import unittest

from httpwire import (
    CLIENT, DONE, IDLE, NEED_DATA, PAUSED, SEND_BODY, SEND_RESPONSE, SERVER, Connection, ConnectionClosed,
    Data, EndOfMessage, InformationalResponse, LocalProtocolError, RemoteProtocolError, Request,
    Response,
)
from httpwire import _headers

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class TestProductOverviewAndTerms(unittest.TestCase):
    # spec: N-000001 N-000004 N-000005 N-000007 N-000008 N-000009
    def test_bytes_in_and_bytes_out_round_trip(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        wire = c.send(Request(method=b"GET", target=b"/p", headers=[(b"Host", b"h")]))
        wire += c.send(EndOfMessage())
        s.receive_data(wire)
        self.assertIsInstance(s.next_event(), Request)
        self.assertIsInstance(s.next_event(), EndOfMessage)

    # spec: N-000006 N-000031
    def test_malformed_peer_input_is_a_protocol_error(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nBad Name: x\r\nHost: a\r\n\r\n")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    # spec: N-000010 N-000011 N-000016
    def test_connections_are_independent_and_do_not_read(self):
        a = Connection(CLIENT)
        b = Connection(CLIENT)
        a.receive_data(b"partial")
        self.assertIs(b.next_event(), NEED_DATA)
        self.assertEqual(b.trailing_data, (b"", False))
        self.assertEqual(a.trailing_data, (b"partial", False))
        self.assertIsNone(a.receive_data(b""))

    # spec: N-000012 N-000013
    def test_send_of_connection_closed_produces_no_bytes(self):
        c = Connection(CLIENT)
        self.assertIsNone(c.send(ConnectionClosed()))
        self.assertIs(c.our_state, httpwire_state("CLOSED"))

    # spec: N-000014 N-000015
    def test_feed_stores_and_pull_yields_one_event(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
        self.assertIs(s.their_state, IDLE)  # feeding changed nothing
        self.assertIsInstance(s.next_event(), Request)

    # spec: N-000017 N-000018 N-000019 N-000020 N-000021
    def test_terms_pause_restart_failed_send_default_status_keep_alive(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
        s.next_event()
        s.next_event()
        s.receive_data(b"GET /2 HTTP/1.1\r\nHost: a\r\n\r\n")
        s.send(Response(200, [(b"Content-Length", b"0")]))
        s.send(EndOfMessage())
        self.assertIs(s.next_event(), PAUSED)  # paused: pipelined bytes wait for a restart
        s.start_next_cycle()  # restart is the cycle start
        self.assertIsInstance(s.next_event(), Request)  # keep-alive: bytes parse after restart
        self.assertEqual(RemoteProtocolError("x").error_status_hint, 400)  # default suggested status
        t = Connection(CLIENT)
        t.send(Request(method=b"GET", target=b"/", headers=[(b"Host", b"a")]))
        t.send_failed()  # the integrator did not transmit the bytes
        self.assertIs(t.our_state, httpwire_state("ERROR"))


class TestClientServerConnection(unittest.TestCase):
    # spec: N-000023 N-000024 N-000025 N-000026
    def test_public_surface_grouped_as_connection_and_events(self):
        import httpwire
        self.assertTrue(all(hasattr(httpwire, n) for n in ("Connection", "Request", "Data")))
        c = Connection(CLIENT)
        s = Connection(SERVER)
        self.assertEqual(c.states, {CLIENT: IDLE, SERVER: IDLE})
        self.assertEqual(s.states, {CLIENT: IDLE, SERVER: IDLE})

    # spec: N-000027 N-000028 N-000029
    def test_need_data_framing_and_passthrough(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nContent-Length: 4\r\n\r\nab")
        s.next_event()
        self.assertEqual(s.next_event(), Data(b"ab"))
        self.assertIs(s.next_event(), NEED_DATA)

    # spec: N-000030 N-000036
    def test_state_machine_and_informational_flow(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        s.receive_data(c.send(Request(method=b"GET", target=b"/", headers=[(b"Host", b"a")])))
        s.next_event()
        self.assertEqual(s.send(InformationalResponse(102, [])), b"HTTP/1.1 102 \r\n\r\n")
        self.assertIs(s.our_state, SEND_RESPONSE)
        self.assertEqual(c.states, {CLIENT: SEND_BODY, SERVER: SEND_RESPONSE})


class TestLifecycleTransitions(unittest.TestCase):
    # spec: N-000247 N-000249 N-000250 N-000251 N-000252 N-000253 N-000254
    def test_client_server_transitions_for_a_cycle(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        wire = c.send(Request(method=b"GET", target=b"/", headers=[(b"Host", b"a")]))
        self.assertEqual(c.states, {CLIENT: SEND_BODY, SERVER: SEND_RESPONSE})  # client IDLE -> SEND_BODY
        wire += c.send(EndOfMessage())
        self.assertEqual(c.states, {CLIENT: DONE, SERVER: SEND_RESPONSE})
        s.receive_data(wire)
        s.next_event()
        s.next_event()
        self.assertEqual(s.states, {CLIENT: DONE, SERVER: SEND_RESPONSE})  # pulled: same states
        s.send(InformationalResponse(100, []))
        self.assertIs(s.our_state, SEND_RESPONSE)  # informational keeps SEND_RESPONSE
        s.send(Response(200, [(b"Content-Length", b"1")]))
        self.assertIs(s.our_state, SEND_BODY)  # final response -> SEND_BODY
        s.send(Data(b"x"))
        self.assertIs(s.our_state, SEND_BODY)  # data keeps SEND_BODY
        s.send(EndOfMessage())
        self.assertIs(s.our_state, DONE)  # end of message -> DONE


class TestSyntaxAndDialect(unittest.TestCase):
    # spec: N-000039 N-000041 N-000042 N-000043
    def test_package_directory_and_declared_platforms(self):
        self.assertTrue(os.path.isdir(os.path.join(ROOT, "httpwire")))
        text = open(os.path.join(ROOT, "pyproject.toml")).read()
        for needle in ("Linux", "MacOS", "Windows", '"Programming Language :: Python :: 3"'):
            self.assertIn(needle, text)

    # spec: N-000044 N-000045 N-000046 N-000048
    def test_cpu_only_and_bytes_only_io(self):
        text = open(os.path.join(ROOT, "pyproject.toml")).read()
        self.assertNotIn("ext_modules", text)
        self.assertIn("dependencies = []", text)

    # spec: N-000052 N-000053 N-000054
    def test_http11_on_the_wire_and_http10_read(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.0\r\n\r\n")
        self.assertEqual(s.next_event().http_version, b"1.0")
        c = Connection(CLIENT)
        with self.assertRaises(LocalProtocolError):
            c.send(Request(method=b"GET", target=b"/", headers=[(b"Host", b"a")], http_version=b"2.0"))
        s2 = Connection(SERVER)
        s2.receive_data(b"GET / HTTP/2.0\r\nHost: a\r\n\r\n")
        with self.assertRaises(RemoteProtocolError):
            s2.next_event()

    # spec: N-000055 N-000056 N-000057 N-000058
    def test_scope_is_message_syntax_and_expect(self):
        c = Connection(CLIENT)
        c.send(Request(method=b"POST", target=b"/", headers=[
            (b"Host", b"a"), (b"Expect", b"100-continue"), (b"Content-Length", b"0")]))
        self.assertTrue(c.client_is_waiting_for_100_continue)
        self.assertEqual(str(RemoteProtocolError("any wording is fine")), "any wording is fine")

    # spec: N-000061 N-000062 N-000063
    def test_no_http2_and_http10_never_kept_alive(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.0\r\nConnection: keep-alive\r\n\r\n")
        s.next_event()
        s.next_event()
        s.send(Response(200, [(b"Content-Length", b"0")]))
        s.send(EndOfMessage())
        self.assertIs(s.their_state, httpwire_state("MUST_CLOSE"))

    # spec: N-000064 N-000065
    def test_gzip_and_deflate_transfer_codings_refused(self):
        for coding in (b"gzip", b"deflate"):
            with self.subTest(coding=coding):
                with self.assertRaises(LocalProtocolError):
                    Request(method=b"POST", target=b"/", headers=[
                        (b"Host", b"a"), (b"Transfer-Encoding", coding)])

    # spec: N-000066 N-000067
    def test_chunk_extensions_parsed_and_discarded(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\n"
                       b"2;ext=1\r\nhi\r\n0\r\n\r\n")
        s.next_event()
        d = s.next_event()
        self.assertEqual(d.data, b"hi")
        self.assertFalse(hasattr(d, "extension"))


class TestHeadersAndValues(unittest.TestCase):
    # spec: N-000087 N-000088 N-000089 N-000090 N-000091
    def test_headers_sequence_lowercase_bytes_and_raw(self):
        h = _headers.normalize_headers([("X-One", "1"), (bytearray(b"X-Two"), memoryview(b"2"))])
        self.assertEqual(list(h), [(b"x-one", b"1"), (b"x-two", b"2")])
        self.assertEqual(h.raw_items(), [(b"X-One", b"1"), (b"X-Two", b"2")])
        self.assertIs(type(list(h)[0][0]), bytes)

    # spec: N-000098 N-000108
    def test_nul_and_other_control_bytes_refused(self):
        for value in (b"a\x00b", b"a\x01b", b"a\x7fb", b"a\rb", b"a\nb", b"a\x0cb", b"a\x0bb"):
            with self.subTest(value=value):
                with self.assertRaises(LocalProtocolError):
                    _headers.normalize_headers([(b"X", value)])
        self.assertEqual(list(_headers.normalize_headers([(b"X", b"a\tb")])), [(b"x", b"a\tb")])

    # spec: N-000458
    def test_byte_arguments_accept_str_and_bytes_like(self):
        r = Request(method="GET", target=bytearray(b"/"), headers=[("Host", memoryview(b"h"))])
        self.assertEqual((r.method, r.target), (b"GET", b"/"))
        self.assertIs(type(r.target), bytes)
        with self.assertRaises(LocalProtocolError):
            Request(method="GÉT", target=b"/", headers=[(b"Host", b"h")])

    # spec: N-000183 N-000184
    def test_request_body_framing_chosen_from_headers(self):
        c = Connection(CLIENT)
        head = c.send(Request(method=b"PUT", target=b"/", headers=[
            (b"Host", b"a"), (b"Content-Length", b"2")]))
        self.assertIn(b"Content-Length: 2", head)
        self.assertEqual(c.send(Data(b"ok")), b"ok")


class TestPullAndSendDetails(unittest.TestCase):
    # spec: N-000486 N-000487 N-000488 N-000489
    def test_their_http_version_recorded_on_pull_only(self):
        c = Connection(CLIENT)
        c.send(Request(method=b"GET", target=b"/", headers=[(b"Host", b"a")]))
        c.send(EndOfMessage())
        self.assertIsNone(c.their_http_version)
        c.receive_data(b"HTTP/1.0 200 OK\r\nContent-Length: 0\r\n\r\n")
        c.next_event()
        self.assertEqual(c.their_http_version, b"1.0")

    # spec: N-000490 N-000491 N-000492 N-000493 N-000494 N-000495 N-000496
    def test_waiting_flags_and_trailing_data_shape(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nExpect: 100-continue\r\nContent-Length: 0\r\n\r\nxy")
        s.next_event()
        s.next_event()
        self.assertIs(s.client_is_waiting_for_100_continue, True)
        self.assertIs(s.they_are_waiting_for_100_continue, True)
        leftover, closed = s.trailing_data
        self.assertEqual(leftover, b"xy")
        self.assertIs(closed, False)
        self.assertIs(type(closed), bool)

    # spec: N-000507 N-000508 N-000509 N-000510 N-000511
    def test_receive_data_none_and_close_rule(self):
        s = Connection(SERVER)
        self.assertIsNone(s.receive_data(bytearray(b"GET / HTTP/1.1\r\n")))
        s.receive_data(b"")
        with self.assertRaises(RuntimeError):
            s.receive_data(b"more")

    # spec: N-000512 N-000513 N-000514 N-000515 N-000516
    def test_next_event_returns_sentinel_or_event(self):
        s = Connection(SERVER)
        self.assertIs(s.next_event(), NEED_DATA)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
        self.assertIsInstance(s.next_event(), Request)

    # spec: N-000517 N-000518 N-000519
    def test_start_next_cycle_none_or_refusal(self):
        c = Connection(CLIENT)
        with self.assertRaises(LocalProtocolError):
            c.start_next_cycle()
        c.send(Request(method=b"GET", target=b"/", headers=[(b"Host", b"a")]))
        c.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
        c.next_event()
        c.next_event()
        self.assertIsNone(c.start_next_cycle())
        self.assertIs(c.states[CLIENT], IDLE)
        self.assertIs(c.states[SERVER], IDLE)


def httpwire_state(name):
    import httpwire
    return getattr(httpwire, name)


if __name__ == "__main__":
    unittest.main()
