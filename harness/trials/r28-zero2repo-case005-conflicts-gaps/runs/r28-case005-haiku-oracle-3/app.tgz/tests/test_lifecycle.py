"""Further lifecycle, passthrough and corner-case behaviour."""

import unittest

from httpwire import (
    CLIENT, CLOSED, DONE, ERROR, IDLE, MIGHT_SWITCH_PROTOCOL, MUST_CLOSE, NEED_DATA,
    PAUSED, SEND_BODY, SEND_RESPONSE, SERVER, ConnectionClosed, Connection, Data,
    EndOfMessage, InformationalResponse, LocalProtocolError, RemoteProtocolError, Request,
    Response,
)


class TestServerInIdle(unittest.TestCase):
    # spec: N-000255 N-000256 N-000257 N-000258
    def test_server_may_answer_without_request(self):
        s = Connection(SERVER)
        head = s.send(Response(408, [(b"Content-Length", b"0")]))
        self.assertIn(b"Connection: close", head)
        self.assertIs(s.our_state, SEND_BODY)
        s.send(EndOfMessage())
        self.assertIs(s.our_state, MUST_CLOSE)

    # spec: N-000255 N-000257 N-000207
    def test_unknown_peer_uses_close_delimited_framing(self):
        s = Connection(SERVER)
        head = s.send(Response(503, []))
        self.assertNotIn(b"Transfer-Encoding", head)
        self.assertIn(b"Connection: close", head)
        self.assertEqual(s.send(Data(b"raw")), b"raw")
        s.send(EndOfMessage())
        self.assertIs(s.our_state, MUST_CLOSE)

    # spec: N-000255 N-000256
    def test_informational_not_allowed_in_idle(self):
        s = Connection(SERVER)
        with self.assertRaises(LocalProtocolError):
            s.send(InformationalResponse(100, []))


class TestCloseWithPipelining(unittest.TestCase):
    # spec: N-000342 N-000343 N-000275 N-000339 N-000341
    def test_close_after_pipelined_requests_waits_for_them(self):
        s = Connection(SERVER)
        s.receive_data(b"GET /1 HTTP/1.1\r\nHost: a\r\n\r\n")
        s.receive_data(b"")  # client half-closes right after a request
        self.assertIsInstance(s.next_event(), Request)
        self.assertIsInstance(s.next_event(), EndOfMessage)
        s.send(Response(200, [(b"Content-Length", b"0")]))
        s.send(EndOfMessage())
        self.assertIs(s.their_state, DONE)
        self.assertIsInstance(s.next_event(), ConnectionClosed)
        self.assertIs(s.their_state, CLOSED)
        self.assertIs(s.our_state, MUST_CLOSE)

    # spec: N-000279 N-000289
    def test_bytes_arriving_while_paused_go_to_trailing_data(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
        s.next_event()
        s.next_event()
        s.send(Response(200, [(b"Content-Length", b"0")]))
        s.send(EndOfMessage())
        s.receive_data(b"GET /x HTTP/1.1\r\nHost: a\r\n\r\n")
        self.assertIs(s.next_event(), PAUSED)
        self.assertEqual(s.trailing_data, (b"GET /x HTTP/1.1\r\nHost: a\r\n\r\n", False))

    # spec: N-000334 N-000335 N-000336
    def test_client_sends_close_from_done_then_server_must_close(self):
        c = Connection(CLIENT)
        c.send(Request(method=b"GET", target=b"/", headers=[(b"Host", b"a")]))
        c.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
        c.next_event()
        c.next_event()
        self.assertIs(c.our_state, DONE)
        c.send(ConnectionClosed())
        self.assertIs(c.our_state, CLOSED)
        self.assertIs(c.their_state, MUST_CLOSE)


class TestPassthrough(unittest.TestCase):
    # spec: N-000502 N-000503 N-000504 N-000505 N-000506
    def test_passthrough_returns_pieces_and_send_joins_them(self):
        c = Connection(CLIENT)
        c.send(Request(method=b"POST", target=b"/", headers=[
            (b"Host", b"a"), (b"Transfer-Encoding", b"chunked")]))
        pieces = c.send_with_data_passthrough(Data(b"abc"))
        self.assertIsInstance(pieces, list)
        self.assertEqual(b"".join(pieces), b"3\r\nabc\r\n")
        self.assertEqual(c.send(EndOfMessage()), b"0\r\n\r\n")

    # spec: N-000233 N-000237 N-000502
    def test_bytes_like_payload_is_a_bytes_piece(self):
        c = Connection(CLIENT)
        c.send(Request(method=b"POST", target=b"/", headers=[
            (b"Host", b"a"), (b"Content-Length", b"3")]))
        pieces = c.send_with_data_passthrough(Data(bytearray(b"abc")))
        self.assertEqual(b"".join(pieces), b"abc")
        self.assertTrue(all(isinstance(p, (bytes, bytearray, memoryview)) for p in pieces))

    # spec: N-000233 N-000237
    def test_zero_length_placeholder_sends_nothing(self):
        c = Connection(CLIENT)
        c.send(Request(method=b"POST", target=b"/", headers=[
            (b"Host", b"a"), (b"Transfer-Encoding", b"chunked")]))

        class Empty:
            def __len__(self):
                return 0

        self.assertEqual(c.send_with_data_passthrough(Data(Empty())), [])


class TestReceiveWithoutStateEffects(unittest.TestCase):
    # spec: N-000144 N-000145 N-000146 N-000147 N-000148 N-000149
    def test_feeding_records_nothing(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
        self.assertIs(s.their_state, IDLE)
        self.assertIsNone(s.their_http_version)
        self.assertEqual(s.states, {CLIENT: IDLE, SERVER: IDLE})

    # spec: N-000170 N-000171
    def test_peer_version_kept_across_our_send(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.0\r\n\r\n")
        s.next_event()
        s.next_event()
        s.send(Response(200, [(b"Content-Length", b"0")]))
        self.assertEqual(s.their_http_version, b"1.0")


class TestReceiveErrors(unittest.TestCase):
    # spec: N-000302 N-000305 N-000328
    def test_remote_errors_are_sticky_for_pulls_but_not_sends(self):
        s = Connection(SERVER)
        s.receive_data(b"BAD\r\n\r\n")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()
        with self.assertRaises(RemoteProtocolError):
            s.next_event()
        s.send(Response(400, [(b"Content-Length", b"0")]))  # sending still works
        self.assertIs(s.our_state, SEND_BODY)

    # spec: N-000299 N-000301
    def test_local_error_does_not_break_receiving_already_sent_bytes(self):
        c = Connection(CLIENT)
        c.send(Request(method=b"GET", target=b"/", headers=[(b"Host", b"a")]))
        c.send(EndOfMessage())
        with self.assertRaises(LocalProtocolError):
            c.send(Request(method=b"GET", target=b"/", headers=[(b"Host", b"a")]))
        self.assertIs(c.our_state, ERROR)

    # spec: N-000177 N-000178
    def test_unexpected_space_at_request_start(self):
        s = Connection(SERVER)
        s.receive_data(b" GET / HTTP/1.1\r\nHost: a\r\n\r\n")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    # spec: N-000172 N-000174
    def test_request_with_lf_only_and_bad_version(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/2.0\nHost: a\n\n")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    # spec: N-000166 N-000165
    def test_status_line_without_space_before_reason_is_refused(self):
        c = Connection(CLIENT)
        c.send(Request(method=b"GET", target=b"/", headers=[(b"Host", b"a")]))
        c.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 200OK\r\n\r\n")
        with self.assertRaises(RemoteProtocolError):
            c.next_event()

    # spec: N-000176
    def test_continuation_with_no_header_refused(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\n folded\r\nHost: a\r\n\r\n")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()


class TestHttp10Response(unittest.TestCase):
    # spec: N-000208 N-000213 N-000214 N-000325
    def test_client_side_becomes_must_close_after_close_delimited_body(self):
        c = Connection(CLIENT)
        c.send(Request(method=b"GET", target=b"/", headers=[(b"Host", b"a")]))
        c.send(EndOfMessage())
        c.receive_data(b"HTTP/1.0 200 OK\r\n\r\n")
        c.next_event()
        self.assertIs(c.our_state, MUST_CLOSE)

    # spec: N-000203 N-000206
    def test_unexpected_close_mid_chunked_body(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\n5\r\nab")
        s.next_event()
        s.next_event()
        s.receive_data(b"")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()


class TestTrailersAndBodies(unittest.TestCase):
    # spec: N-000194 N-000195 N-000196
    def test_long_chunk_size_digits_within_limit(self):
        s = Connection(SERVER)
        # 32 hex digits (the maximum this implementation accepts) with leading zeros
        s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\n"
                       + b"0" * 31 + b"3\r\nabc\r\n0\r\n\r\n")
        s.next_event()
        self.assertEqual(s.next_event().data, b"abc")

    # spec: N-000240
    def test_trailers_on_chunked_request_round_trip(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        head = c.send(Request(method=b"POST", target=b"/", headers=[
            (b"Host", b"a"), (b"Transfer-Encoding", b"chunked")]))
        body = c.send(EndOfMessage(headers=[(b"Digest", b"x")]))
        s.receive_data(head + body)
        s.next_event()
        eom = s.next_event()
        self.assertEqual(eom.headers.raw_items(), [(b"Digest", b"x")])


if __name__ == "__main__":
    unittest.main()
