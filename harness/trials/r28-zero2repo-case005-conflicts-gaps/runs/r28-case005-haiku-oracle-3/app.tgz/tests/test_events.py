"""Event construction and header normalization (FP-01, interface events)."""

import unittest

import httpwire
from httpwire import (
    CLIENT, SERVER, ConnectionClosed, Data, EndOfMessage, InformationalResponse,
    LocalProtocolError, Request, Response,
)


class TestEventTypes(unittest.TestCase):
    # spec: N-000070 N-000071 N-000433 N-000434 N-000435 N-000436
    def test_six_distinct_event_types(self):
        kinds = [Request, InformationalResponse, Response, Data, EndOfMessage, ConnectionClosed]
        self.assertEqual(len(set(kinds)), 6)
        for name in ["Request", "InformationalResponse", "Response", "Data", "EndOfMessage", "ConnectionClosed"]:
            self.assertIs(getattr(httpwire, name), globals()[name])

    # spec: N-000437 N-000438 N-000439 N-000440 N-000441 N-000442 N-000443 N-000444 N-000445
    def test_role_state_and_sentinel_objects_distinct(self):
        self.assertIsNot(CLIENT, SERVER)
        self.assertNotEqual(CLIENT, SERVER)
        self.assertNotEqual(httpwire.NEED_DATA, httpwire.PAUSED)
        states = [httpwire.IDLE, httpwire.SEND_RESPONSE, httpwire.SEND_BODY, httpwire.DONE,
                  httpwire.MUST_CLOSE, httpwire.CLOSED, httpwire.MIGHT_SWITCH_PROTOCOL,
                  httpwire.SWITCHED_PROTOCOL, httpwire.ERROR]
        self.assertEqual(len(set(map(id, states))), 9)
        for st in states:
            self.assertNotIsInstance(st, str)

    # spec: N-000446 N-000447 N-000448
    def test_protocol_error_classes_unrelated(self):
        self.assertFalse(issubclass(httpwire.LocalProtocolError, httpwire.RemoteProtocolError))
        self.assertFalse(issubclass(httpwire.RemoteProtocolError, httpwire.LocalProtocolError))

    # spec: N-000449
    def test_package_all_is_importable(self):
        for name in httpwire.__all__:
            self.assertTrue(hasattr(httpwire, name), name)


class TestRequest(unittest.TestCase):
    # spec: N-000072 N-000073 N-000074 N-000075 N-000076
    def test_bytes_storage_and_default_version(self):
        r = Request(method="GET", target=bytearray(b"/x"), headers=[("Host", "h")])
        self.assertEqual(r.method, b"GET")
        self.assertIs(type(r.method), bytes)
        self.assertEqual(r.target, b"/x")
        self.assertEqual(r.http_version, b"1.1")

    # spec: N-000077 N-000078 N-000104 N-000105
    def test_host_rules(self):
        Request(method=b"GET", target=b"/", headers=[(b"HOST", b"a")])
        with self.assertRaises(LocalProtocolError):
            Request(method=b"GET", target=b"/", headers=[])
        with self.assertRaises(LocalProtocolError):
            Request(method=b"GET", target=b"/", headers=[(b"Host", b"a"), (b"host", b"b")],
                    http_version=b"1.0")
        Request(method=b"GET", target=b"/", headers=[], http_version=b"1.0")

    # spec: N-000106 N-000107 N-000109 N-000110 N-000111
    def test_refusals(self):
        bad = [
            dict(method=b"G T", target=b"/", headers=[(b"Host", b"a")]),
            dict(method=b"GET", target=b"/ x", headers=[(b"Host", b"a")]),
            dict(method=b"GET", target=b"/", headers=[(b"Ho st", b"a")]),
            dict(method=b"GET", target=b"/", headers=[(b"Host", b"a\x01")]),
            dict(method=b"GET", target=b"/", headers=[(b"Host", b" a")]),
            dict(method=b"GET", target=b"/", headers=[(b"Host", b"a ")]),
        ]
        for kw in bad:
            with self.subTest(kw=kw):
                with self.assertRaises(LocalProtocolError):
                    Request(**kw)

    # spec: N-000122 N-000097 N-000099 N-000100
    def test_header_value_tab_and_high_bytes_allowed(self):
        r = Request(method=b"GET", target=b"/", headers=[(b"Host", b"a"), (b"X-A", b"a\tb\xff")])
        self.assertIn((b"x-a", b"a\tb\xff"), list(r.headers))

    # spec: N-000096 N-000092 N-000093 N-000094 N-000095
    def test_framing_header_normalization(self):
        r = Request(method=b"POST", target=b"/", headers=[
            (b"Host", b"a"), (b"Content-Length", b"5"), (b"content-length", b"5, 5"),
            (b"Transfer-Encoding", b"CHUNKED"),
        ])
        self.assertEqual(r.headers.raw_items()[1], (b"Content-Length", b"5"))
        self.assertIn((b"transfer-encoding", b"chunked"), list(r.headers))
        self.assertEqual(len([h for h in r.headers if h[0] == b"content-length"]), 1)

    # spec: N-000114 N-000115 N-000116 N-000117 N-000118 N-000119
    def test_content_length_refusals(self):
        for v in [b"-1", b"1x", b"", b"5, 6", b"1" * 19]:
            with self.subTest(v=v):
                with self.assertRaises(LocalProtocolError):
                    Request(method=b"POST", target=b"/", headers=[(b"Host", b"a"), (b"Content-Length", v)])
        Request(method=b"POST", target=b"/", headers=[(b"Host", b"a"), (b"Content-Length", b"1" * 18)])

    # spec: N-000120 N-000121
    def test_transfer_encoding_refusals_have_501(self):
        for hdrs in [[(b"Transfer-Encoding", b"gzip")],
                     [(b"Transfer-Encoding", b"gzip, chunked")],
                     [(b"Transfer-Encoding", b"chunked"), (b"Transfer-Encoding", b"chunked")]]:
            with self.subTest(hdrs=hdrs):
                with self.assertRaises(LocalProtocolError) as cm:
                    Request(method=b"POST", target=b"/", headers=[(b"Host", b"a")] + hdrs)
                self.assertEqual(cm.exception.error_status_hint, 501)

    # spec: N-000161 N-000162 N-000163 N-000164
    def test_raw_items_keep_caller_casing(self):
        r = Request(method=b"GET", target=b"/", headers=[(b"X-Mixed", b"1"), (b"Host", b"a")])
        self.assertEqual(r.headers.raw_items(), [(b"X-Mixed", b"1"), (b"Host", b"a")])
        self.assertEqual(list(r.headers)[0], (b"x-mixed", b"1"))
        self.assertEqual(r.headers[1], (b"host", b"a"))


class TestResponses(unittest.TestCase):
    # spec: N-000079 N-000080 N-000081 N-000082 N-000083 N-000112 N-000113 N-000394 N-000398
    def test_status_ranges(self):
        InformationalResponse(100, [])
        InformationalResponse(199, [])
        Response(200, [])
        Response(999, [])
        for code in (99, 200, 1000):
            with self.subTest(code=code):
                with self.assertRaises(LocalProtocolError):
                    InformationalResponse(code, [])
        for code in (199, 1000, 99):
            with self.subTest(code=code):
                with self.assertRaises(LocalProtocolError):
                    Response(code, [])
        with self.assertRaises(LocalProtocolError):
            Response("200", [])

    # spec: N-000460 N-000459
    def test_int_subclass_status_and_reason(self):
        import enum

        class S(enum.IntEnum):
            OK = 200

        r = Response(S.OK, [], reason="OK")
        self.assertEqual(r.status_code, 200)
        self.assertIs(type(r.status_code), int)
        self.assertEqual(r.reason, b"OK")
        self.assertEqual(r.http_version, b"1.1")
        self.assertEqual(Response(200, []).reason, b"")
        self.assertEqual(InformationalResponse(100, []).http_version, b"1.1")

    # spec: N-000466 N-000101 N-000102 N-000103
    def test_invalid_construction_raises_and_returns_nothing(self):
        with self.assertRaises(LocalProtocolError):
            Response(200, [(b"Bad Name", b"v")])
        self.assertEqual(Response(200, []).status_code, 200)


class TestDataAndEnd(unittest.TestCase):
    # spec: N-000084 N-000085 N-000086 N-000463 N-000464 N-000465
    def test_data_fields(self):
        d = Data(b"abc")
        self.assertEqual(d.data, b"abc")
        self.assertIs(d.chunk_start, False)
        self.assertIs(d.chunk_end, False)
        d2 = Data(b"x", chunk_start=True, chunk_end=1)
        self.assertIs(d2.chunk_start, True)
        self.assertIs(d2.chunk_end, True)

    # spec: N-000084 N-000467 N-000468
    def test_end_of_message_default_empty(self):
        self.assertEqual(list(EndOfMessage().headers), [])
        self.assertEqual(list(EndOfMessage(headers=[(b"X-T", b"1")]).headers), [(b"x-t", b"1")])

    # spec: N-000086 N-000457
    def test_connection_closed_no_fields(self):
        self.assertEqual(ConnectionClosed(), ConnectionClosed())

    # spec: N-000450 N-000451 N-000452 N-000453 N-000454 N-000455 N-000456 N-000460
    def test_event_fields_readable_by_keyword(self):
        r = Request(method=b"GET", target=b"/", headers=[(b"Host", b"a")])
        self.assertEqual(r.method, b"GET")
        self.assertEqual(Response(status_code=200, headers=[], reason=b"OK").reason, b"OK")

    # spec: N-000461 N-000462
    def test_headers_must_be_pairs(self):
        with self.assertRaises(LocalProtocolError):
            Response(200, [(b"a",)])


class TestHeadersView(unittest.TestCase):
    # spec: N-000467 N-000468 N-000469 N-000470 N-000471
    def test_ordinary_view_and_raw_view(self):
        from httpwire import _headers
        h = _headers.normalize_headers([(b"Foo", b"1"), (b"BAR", b"2")])
        self.assertEqual(list(h), [(b"foo", b"1"), (b"bar", b"2")])
        self.assertEqual(h.raw_items(), [(b"Foo", b"1"), (b"BAR", b"2")])
        self.assertEqual(h, [(b"foo", b"1"), (b"bar", b"2")])


if __name__ == "__main__":
    unittest.main()
