"""Product-surface, packaging and no-I/O checks."""

import ast
import importlib
import os
import subprocess
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PKG = os.path.join(ROOT, "httpwire")


def _package_sources():
    for name in sorted(os.listdir(PKG)):
        if name.endswith(".py"):
            yield os.path.join(PKG, name)


class TestSurface(unittest.TestCase):
    # spec: N-000002 N-000414 N-000417 N-000418 N-000419 N-000420 N-000421 N-000426
    def test_hardware_and_toolchain_statements(self):
        text = open(os.path.join(ROOT, "pyproject.toml")).read()
        self.assertIn("cpu_baseline", text)  # the one execution profile
        self.assertIn('build-backend = "setuptools.build_meta"', text)  # no native compile step
        self.assertNotIn("ext_modules", text)

    # spec: N-000022 N-000069 N-000431 N-000429 N-000430
    def test_library_has_no_cli_or_entry_points(self):
        self.assertFalse(os.path.exists(os.path.join(PKG, "__main__.py")))
        self.assertNotIn("[project.scripts]", open(os.path.join(ROOT, "pyproject.toml")).read())
        import httpwire
        self.assertFalse(hasattr(httpwire, "main"))

    # spec: N-000049 N-000047 N-000011 N-000003 N-000413 N-000059 N-000060 N-000068
    def test_no_socket_or_process_or_http_library_imports(self):
        banned = {"socket", "ssl", "subprocess", "http", "http.client", "http.server",
                  "urllib", "asyncio", "select", "multiprocessing", "os"}
        for path in _package_sources():
            with open(path) as fh:
                tree = ast.parse(fh.read())
            for node in ast.walk(tree):
                names = []
                if isinstance(node, ast.Import):
                    names = [a.name for a in node.names]
                elif isinstance(node, ast.ImportFrom) and node.module:
                    names = [node.module]
                for n in names:
                    self.assertNotIn(n.split(".")[0], banned, "%s imports %s" % (path, n))

    # spec: N-000050 N-000051
    def test_own_parser_no_stdlib_http_delegation(self):
        for path in _package_sources():
            with open(path) as fh:
                src = fh.read()
            self.assertNotIn("http.client", src)
            self.assertNotIn("http.server", src)

    # spec: N-000037 N-000038 N-000415 N-000424 N-000425
    def test_pure_python_no_compiled_or_runtime_deps(self):
        for path in _package_sources():
            self.assertTrue(path.endswith(".py"))
        with open(os.path.join(ROOT, "pyproject.toml")) as fh:
            text = fh.read()
        self.assertIn("dependencies = []", text)
        self.assertNotIn("ext_modules", text)

    # spec: N-000040 N-000416 N-000423
    def test_interpreter_floor_is_py38(self):
        self.assertIn('requires-python = ">=3.8"', open(os.path.join(ROOT, "pyproject.toml")).read())
        self.assertGreaterEqual(sys.version_info[:2], (3, 8))

    # spec: N-000428 N-000422 N-000427
    def test_importable_from_repo_root_in_fresh_process(self):
        out = subprocess.run(
            [sys.executable, "-c", "import httpwire, sys; print(httpwire.__file__)"],
            cwd=ROOT, capture_output=True, text=True, check=True,
        )
        self.assertTrue(out.stdout.strip().startswith(ROOT))

    # spec: N-000472 N-000473
    def test_protocol_error_hint_and_message(self):
        from httpwire import LocalProtocolError, RemoteProtocolError
        e = RemoteProtocolError("bad thing", error_status_hint=431)
        self.assertIs(type(e.error_status_hint), int)
        self.assertEqual(str(e), "bad thing")
        self.assertEqual(LocalProtocolError("x").error_status_hint, 400)

    # spec: N-000474 N-000475
    def test_bytes_after_receive_close_not_a_protocol_error(self):
        from httpwire import Connection, LocalProtocolError, RemoteProtocolError, SERVER
        s = Connection(SERVER)
        s.receive_data(b"")
        try:
            s.receive_data(b"x")
        except Exception as exc:  # noqa: BLE001 - we want the class, whatever it is
            self.assertNotIsInstance(exc, (LocalProtocolError, RemoteProtocolError))
        else:
            self.fail("expected an exception")

    # spec: N-000429 N-000432 N-000433 N-000449
    def test_public_names_importable_from_root(self):
        import httpwire
        for name in ["CLIENT", "SERVER", "Connection", "ConnectionClosed", "Data", "DONE",
                     "EndOfMessage", "ERROR", "IDLE", "InformationalResponse",
                     "LocalProtocolError", "MIGHT_SWITCH_PROTOCOL", "MUST_CLOSE",
                     "NEED_DATA", "PAUSED", "RemoteProtocolError", "Request", "Response",
                     "SEND_BODY", "SEND_RESPONSE", "SWITCHED_PROTOCOL", "CLOSED"]:
            with self.subTest(name=name):
                self.assertTrue(hasattr(httpwire, name))
                self.assertEqual(getattr(importlib.import_module("httpwire"), name), getattr(httpwire, name))

    # spec: N-000497 N-000498 N-000499 N-000500 N-000501 N-000013
    def test_send_returns_bytes_or_none_for_close(self):
        from httpwire import CLIENT, Connection, ConnectionClosed, Request
        c = Connection(CLIENT)
        out = c.send(Request(method=b"GET", target=b"/", headers=[(b"Host", b"a")]))
        self.assertIsInstance(out, bytes)
        c2 = Connection(CLIENT)
        self.assertIsNone(c2.send(ConnectionClosed()))

    # spec: N-000520 N-000521 N-000522
    def test_send_failed_returns_none_and_produces_no_bytes(self):
        from httpwire import CLIENT, Connection
        c = Connection(CLIENT)
        self.assertIsNone(c.send_failed())


if __name__ == "__main__":
    unittest.main()
