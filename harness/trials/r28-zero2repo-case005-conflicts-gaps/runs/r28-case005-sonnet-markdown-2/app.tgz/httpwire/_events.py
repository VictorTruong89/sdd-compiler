import re

from ._common import LocalProtocolError

MAX_CONTENT_LENGTH_DIGITS = 18

TOKEN = rb"[-!#$%&'*+.^_`|~0-9a-zA-Z]+"
token_re = re.compile(TOKEN)
value_re = re.compile(
    rb"(?:[^\x00\r\n\x0b\x0c \t](?:[^\x00\r\n\x0b\x0c]*[^\x00\r\n\x0b\x0c \t])?)?"
)
target_re = re.compile(rb"[\x21-\x7e]+")
digits_re = re.compile(rb"[0-9]+")


def to_bytes(value, what="value"):
    if type(value) is bytes:
        return value
    if isinstance(value, str):
        try:
            return value.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("non-ASCII text for %s" % what)
    try:
        return bytes(memoryview(value))
    except TypeError:
        raise LocalProtocolError("bad type for %s" % what)


class Headers(object):
    """Sequence of (lowercase name, value); raw_items() gives original names."""

    def __init__(self, full_items):
        self._full_items = full_items

    def __iter__(self):
        for _raw, name, value in self._full_items:
            yield (name, value)

    def __len__(self):
        return len(self._full_items)

    def __getitem__(self, idx):
        if isinstance(idx, slice):
            return [(n, v) for _r, n, v in self._full_items[idx]]
        _r, n, v = self._full_items[idx]
        return (n, v)

    def __bool__(self):
        return bool(self._full_items)

    def __eq__(self, other):
        try:
            return list(self) == list(other)
        except TypeError:
            return NotImplemented

    __hash__ = None

    def __repr__(self):
        return repr(list(self))

    def raw_items(self):
        return [(r, v) for r, _n, v in self._full_items]


def normalize_headers(headers):
    if headers is None:
        headers = []
    if isinstance(headers, Headers):
        pairs = headers.raw_items()
    elif hasattr(headers, "items") and not isinstance(headers, (list, tuple)):
        pairs = list(headers.items())
    else:
        pairs = list(headers)
    out = []
    saw_cl = None
    cl_index = None
    saw_te = False
    for pair in pairs:
        try:
            raw_name, value = pair
        except (TypeError, ValueError):
            raise LocalProtocolError("bad header item")
        raw_name = to_bytes(raw_name, "header name")
        value = to_bytes(value, "header value")
        if not token_re.fullmatch(raw_name):
            raise LocalProtocolError("illegal header name %r" % raw_name)
        if not value_re.fullmatch(value):
            raise LocalProtocolError("illegal header value %r" % value)
        name = raw_name.lower()
        if name == b"content-length":
            pieces = [p.strip(b" \t") for p in value.split(b",")]
            for p in pieces:
                if not digits_re.fullmatch(p):
                    raise LocalProtocolError("bad Content-Length")
                if len(p) > MAX_CONTENT_LENGTH_DIGITS:
                    raise LocalProtocolError("Content-Length too long")
            vals = set(int(p) for p in pieces)
            if saw_cl is not None:
                vals.add(saw_cl)
            if len(vals) > 1:
                raise LocalProtocolError("conflicting Content-Length headers")
            v = vals.pop()
            if saw_cl is None:
                saw_cl = v
                cl_index = len(out)
                out.append((raw_name, name, pieces[0]))
            continue
        if name == b"transfer-encoding":
            if saw_te:
                raise LocalProtocolError(
                    "multiple Transfer-Encoding headers", error_status_hint=501
                )
            saw_te = True
            if value.lower() != b"chunked":
                raise LocalProtocolError(
                    "only Transfer-Encoding: chunked is supported",
                    error_status_hint=501,
                )
            value = b"chunked"
        out.append((raw_name, name, value))
    return Headers(out)


def get_comma_header(headers, name):
    out = []
    for _r, n, v in headers._full_items:
        if n == name:
            for piece in v.split(b","):
                piece = piece.strip(b" \t").lower()
                if piece:
                    out.append(piece)
    return out


def set_comma_header(headers, name, values):
    items = [(r, n, v) for r, n, v in headers._full_items if n != name]
    for v in values:
        items.append((name, name, v))
    return Headers(items)


def delete_comma_header(headers, name):
    return Headers([(r, n, v) for r, n, v in headers._full_items if n != name])


class _Event(object):
    _fields = ()

    def __eq__(self, other):
        return type(self) is type(other) and all(
            getattr(self, f) == getattr(other, f) for f in self._fields
        )

    __hash__ = None

    def __repr__(self):
        return "%s(%s)" % (
            type(self).__name__,
            ", ".join("%s=%r" % (f, getattr(self, f)) for f in self._fields),
        )


class Request(_Event):
    _fields = ("method", "target", "headers", "http_version")

    def __init__(self, method, target, headers, http_version=b"1.1"):
        method = to_bytes(method, "method")
        target = to_bytes(target, "target")
        http_version = to_bytes(http_version, "http_version")
        headers = normalize_headers(headers)
        if not token_re.fullmatch(method):
            raise LocalProtocolError("illegal method")
        if not target_re.fullmatch(target):
            raise LocalProtocolError("illegal request target")
        hosts = sum(1 for _r, n, _v in headers._full_items if n == b"host")
        if hosts > 1:
            raise LocalProtocolError("Found multiple Host headers")
        if http_version == b"1.1" and hosts == 0:
            raise LocalProtocolError("Missing mandatory Host: header")
        self.method = method
        self.target = target
        self.headers = headers
        self.http_version = http_version


class _ResponseBase(_Event):
    _fields = ("status_code", "headers", "http_version", "reason")
    _lo = 0
    _hi = 0

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        if not isinstance(status_code, int) or isinstance(status_code, bool):
            raise LocalProtocolError("status code must be an integer")
        status_code = int(status_code)
        if not (self._lo <= status_code < self._hi):
            raise LocalProtocolError("illegal status code %r" % status_code)
        http_version = to_bytes(http_version, "http_version")
        reason = to_bytes(reason, "reason")
        if re.search(rb"[\x00\r\n]", reason):
            raise LocalProtocolError("illegal reason phrase")
        self.headers = normalize_headers(headers)
        self.status_code = status_code
        self.http_version = http_version
        self.reason = reason


class InformationalResponse(_ResponseBase):
    _lo, _hi = 100, 200


class Response(_ResponseBase):
    _lo, _hi = 200, 1000


class Data(_Event):
    _fields = ("data", "chunk_start", "chunk_end")

    def __init__(self, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)


class EndOfMessage(_Event):
    _fields = ("headers",)

    def __init__(self, headers=None):
        self.headers = normalize_headers(headers)


class ConnectionClosed(_Event):
    _fields = ()
