import re

from ._common import (
    CLIENT, SERVER, NEED_DATA, PAUSED, IDLE, SEND_RESPONSE, SEND_BODY, DONE,
    MUST_CLOSE, CLOSED, MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL, ERROR,
    LocalProtocolError, RemoteProtocolError, other_role,
)
from ._events import (
    Request, InformationalResponse, Response, Data, EndOfMessage,
    ConnectionClosed, Headers, normalize_headers, get_comma_header,
    set_comma_header, delete_comma_header, token_re, TOKEN,
)

MAX_CHUNK_HEX_DIGITS = 32
DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 16 * 1024

_SWITCH_UPGRADE = "_SWITCH_UPGRADE"
_SWITCH_CONNECT = "_SWITCH_CONNECT"

# ---------------------------------------------------------------- state machine

_EVENT_TRANSITIONS = {
    CLIENT: {
        IDLE: {Request: SEND_BODY, ConnectionClosed: CLOSED},
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
        CLOSED: {},
        MIGHT_SWITCH_PROTOCOL: {},
        SWITCHED_PROTOCOL: {},
        ERROR: {},
    },
    SERVER: {
        IDLE: {
            ConnectionClosed: CLOSED,
            Response: SEND_BODY,
            (Request, CLIENT): SEND_RESPONSE,
        },
        SEND_RESPONSE: {
            InformationalResponse: SEND_RESPONSE,
            Response: SEND_BODY,
            (Response, _SWITCH_CONNECT): SWITCHED_PROTOCOL,
            (InformationalResponse, _SWITCH_UPGRADE): SWITCHED_PROTOCOL,
        },
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
        CLOSED: {},
        SWITCHED_PROTOCOL: {},
        ERROR: {},
    },
}


class ConnectionState(object):
    def __init__(self):
        self.states = {CLIENT: IDLE, SERVER: IDLE}
        self.keep_alive = True
        self.pending = set()

    def process_error(self, role):
        self.states[role] = ERROR
        self._fire_state()

    def process_keep_alive_disabled(self):
        self.keep_alive = False
        self._fire_state()

    def process_client_switch_proposal(self, p):
        self.pending.add(p)
        self._fire_state()

    def process_event(self, role, event_type, switch=None):
        et = event_type
        if switch is not None:
            if switch not in self.pending:
                raise LocalProtocolError("server switch event without proposal")
            et = (event_type, switch)
        if switch is None and et is Response:
            self.pending.clear()
        self._fire_event(role, et)
        if et is Request:
            self._fire_event(SERVER, (Request, CLIENT))
        self._fire_state()

    def _fire_event(self, role, et):
        state = self.states[role]
        try:
            new = _EVENT_TRANSITIONS[role][state][et]
        except KeyError:
            name = getattr(et, "__name__", et)
            raise LocalProtocolError(
                "can't handle event type %s when role=%r and state=%r"
                % (name, role, state)
            )
        self.states[role] = new

    def _fire_state(self):
        st = self.states
        while True:
            start = dict(st)
            if self.pending:
                if st[CLIENT] is DONE:
                    st[CLIENT] = MIGHT_SWITCH_PROTOCOL
            else:
                if st[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                    st[CLIENT] = DONE
            if not self.keep_alive:
                for r in (CLIENT, SERVER):
                    if st[r] is DONE:
                        st[r] = MUST_CLOSE
            if st[CLIENT] is MIGHT_SWITCH_PROTOCOL and st[SERVER] is SWITCHED_PROTOCOL:
                st[CLIENT] = SWITCHED_PROTOCOL
            for r in (CLIENT, SERVER):
                o = other_role(r)
                if st[r] is CLOSED and st[o] in (IDLE, DONE):
                    st[o] = MUST_CLOSE
                if st[r] is ERROR and st[o] is DONE:
                    st[o] = MUST_CLOSE
            if st == start:
                return

    def start_next_cycle(self):
        if self.states != {CLIENT: DONE, SERVER: DONE}:
            raise LocalProtocolError(
                "not in a reusable state: %r" % (self.states,)
            )
        assert not self.pending
        self.states = {CLIENT: IDLE, SERVER: IDLE}


# ---------------------------------------------------------------- helpers

def _http_version_ge_11(v):
    return v is not None and v >= b"1.1"


def _keep_alive(event):
    if b"close" in get_comma_header(event.headers, b"connection"):
        return False
    if event.http_version < b"1.1":
        return False
    return True


def _body_framing(request_method, event):
    if type(event) is Response:
        if (
            event.status_code in (204, 304)
            or request_method == b"HEAD"
            or (request_method == b"CONNECT" and 200 <= event.status_code < 300)
        ):
            return ("content-length", (0,))
        if get_comma_header(event.headers, b"transfer-encoding"):
            return ("chunked", ())
    cls = get_comma_header(event.headers, b"content-length")
    if cls:
        return ("content-length", (int(cls[0]),))
    if get_comma_header(event.headers, b"transfer-encoding"):
        return ("chunked", ())
    if type(event) is Request:
        return ("content-length", (0,))
    return ("http/1.0", ())


# ---------------------------------------------------------------- writers

def _write_headers(headers, write, host_first=False):
    items = headers._full_items
    if host_first:
        for r, n, v in items:
            if n == b"host":
                write(b"%s: %s\r\n" % (r, v))
                break
        for r, n, v in items:
            if n != b"host":
                write(b"%s: %s\r\n" % (r, v))
    else:
        for r, n, v in items:
            write(b"%s: %s\r\n" % (r, v))
    write(b"\r\n")


def _write_request(event, write):
    if event.http_version != b"1.1":
        raise LocalProtocolError("I only send HTTP/1.1")
    write(b"%s %s HTTP/1.1\r\n" % (event.method, event.target))
    _write_headers(event.headers, write, host_first=True)


def _write_any_response(event, write):
    if event.http_version != b"1.1":
        raise LocalProtocolError("I only send HTTP/1.1")
    write(b"HTTP/1.1 %d %s\r\n" % (event.status_code, event.reason))
    _write_headers(event.headers, write)


class _ContentLengthWriter(object):
    def __init__(self, length):
        self._length = length

    def send_data(self, data, write):
        self._length -= len(data)
        if self._length < 0:
            raise LocalProtocolError("Too much data for declared Content-Length")
        write(data)

    def send_eom(self, headers, write):
        if self._length != 0:
            raise LocalProtocolError("Too little data for declared Content-Length")
        if headers:
            raise LocalProtocolError("Content-Length and trailers don't mix")


class _ChunkedWriter(object):
    def send_data(self, data, write):
        if not len(data):
            return
        write(b"%x\r\n" % len(data))
        write(data)
        write(b"\r\n")

    def send_eom(self, headers, write):
        write(b"0\r\n")
        _write_headers(headers, write)


class _Http10Writer(object):
    def send_data(self, data, write):
        write(data)

    def send_eom(self, headers, write):
        if headers:
            raise LocalProtocolError("can't send trailers to HTTP/1.0 client")


_BODY_WRITERS = {
    "content-length": _ContentLengthWriter,
    "chunked": _ChunkedWriter,
    "http/1.0": _Http10Writer,
}


def _head_writer(body_writer):
    return body_writer


# ---------------------------------------------------------------- readers

_head_end_re = re.compile(rb"\n\r?\n")
_request_line_re = re.compile(
    rb"(?P<method>" + TOKEN + rb") (?P<target>[\x21-\x7e]+) HTTP/(?P<ver>[0-9]\.[0-9])"
)
_status_line_re = re.compile(
    rb"HTTP/(?P<ver>[0-9]\.[0-9]) (?P<status>[0-9]{3})(?: (?P<reason>[^\x00\r\n]*))?"
)
_header_re = re.compile(
    rb"(?P<name>" + TOKEN + rb"):[ \t]*"
    rb"(?P<value>(?:[^\x00\r\n\x0b\x0c \t](?:[^\x00\r\n\x0b\x0c]*[^\x00\r\n\x0b\x0c \t])?)?)"
    rb"[ \t]*"
)
_chunk_header_re = re.compile(
    rb"(?P<size>[0-9a-fA-F]+)(?:;[^\r\n]*)?\r\n"
)


def _extract_block(buf):
    """Return list of lines (without line endings) or None if incomplete."""
    if buf[:2] == b"\r\n":
        del buf[:2]
        return []
    if buf[:1] == b"\n":
        del buf[:1]
        return []
    m = _head_end_re.search(buf)
    if m is None:
        return None
    block = bytes(buf[: m.start()])
    del buf[: m.end()]
    lines = []
    for ln in block.split(b"\n"):
        if ln.endswith(b"\r"):
            ln = ln[:-1]
        lines.append(ln)
    return lines


def _parse_headers(lines, has_start_line):
    out = []
    for i, ln in enumerate(lines):
        if ln[:1] in (b" ", b"\t"):
            if not out or (has_start_line and i == 0):
                raise RemoteProtocolError("illegal continuation line")
            out[-1] = out[-1] + b" " + ln.lstrip(b" \t")
        else:
            out.append(ln)
    result = []
    for ln in out:
        m = _header_re.fullmatch(ln)
        if m is None:
            raise RemoteProtocolError("illegal header line: %r" % ln)
        result.append((m.group("name"), m.group("value")))
    return result


def _remote(fn, *args):
    try:
        return fn(*args)
    except LocalProtocolError as e:
        raise RemoteProtocolError(str(e), e.error_status_hint)


def _split_head(buf):
    if buf and buf[0] < 33:
        raise RemoteProtocolError("illegal first byte of start line")
    lines = _extract_block(buf)
    if lines is None:
        return None
    return lines


def _read_request(buf):
    lines = _split_head(buf)
    if lines is None:
        return None
    if not lines:
        raise RemoteProtocolError("empty request")
    m = _request_line_re.fullmatch(lines[0])
    if m is None:
        raise RemoteProtocolError("illegal request line")
    headers = _parse_headers(lines[1:], True)
    return _remote(
        Request, m.group("method"), m.group("target"), headers, m.group("ver")
    )


def _read_response(buf):
    lines = _split_head(buf)
    if lines is None:
        return None
    if not lines:
        raise RemoteProtocolError("empty response")
    m = _status_line_re.fullmatch(lines[0])
    if m is None:
        raise RemoteProtocolError("illegal status line")
    headers = _parse_headers(lines[1:], True)
    status = int(m.group("status"))
    cls = InformationalResponse if status < 200 else Response
    return _remote(
        cls, status, headers, m.group("ver"), m.group("reason") or b""
    )


def _expect_nothing(buf):
    if buf:
        raise RemoteProtocolError("Got data when expecting EOF")
    return None


class _ContentLengthReader(object):
    def __init__(self, length):
        self._remaining = length

    def __call__(self, buf):
        if self._remaining == 0:
            return EndOfMessage()
        if not buf:
            return None
        data = bytes(buf[: self._remaining])
        del buf[: len(data)]
        self._remaining -= len(data)
        return Data(data=data)

    def read_eof(self):
        raise RemoteProtocolError("peer closed connection without sending complete message body")


class _ChunkedReader(object):
    def __init__(self):
        self._bytes_in_chunk = 0
        self._discard = False
        self._trailer = False
        self._chunk_started = False

    def __call__(self, buf):
        if self._trailer:
            lines = _extract_block(buf)
            if lines is None:
                return None
            return _remote(EndOfMessage, _parse_headers(lines, False))
        if self._discard:
            head = bytes(buf[:2])
            if head != b"\r\n"[: len(head)]:
                raise RemoteProtocolError("missing CRLF after chunk data")
            if len(head) < 2:
                return None
            del buf[:2]
            self._discard = False
        if self._bytes_in_chunk == 0:
            nl = buf.find(b"\n")
            if nl < 0:
                # fail early on obviously bad data
                m = re.match(rb"[0-9a-fA-F]*", bytes(buf))
                if m.end() > MAX_CHUNK_HEX_DIGITS:
                    raise RemoteProtocolError("chunk size too long")
                if m.end() < len(buf) and buf[m.end():m.end() + 1] != b";":
                    if buf[m.end():m.end() + 1] != b"\r" or len(buf) > m.end() + 1:
                        raise RemoteProtocolError("illegal chunk header")
                return None
            line = bytes(buf[: nl + 1])
            m = _chunk_header_re.fullmatch(line)
            if m is None or len(m.group("size")) > MAX_CHUNK_HEX_DIGITS:
                raise RemoteProtocolError("illegal chunk header: %r" % line)
            del buf[: nl + 1]
            size = int(m.group("size"), 16)
            if size == 0:
                self._trailer = True
                return self(buf)
            self._bytes_in_chunk = size
            self._chunk_started = True
        if not buf:
            return None
        data = bytes(buf[: self._bytes_in_chunk])
        del buf[: len(data)]
        self._bytes_in_chunk -= len(data)
        start = self._chunk_started
        self._chunk_started = False
        end = self._bytes_in_chunk == 0
        if end:
            self._discard = True
        return Data(data=data, chunk_start=start, chunk_end=end)

    def read_eof(self):
        raise RemoteProtocolError("peer closed connection without sending complete message body (incomplete chunked read)")


class _Http10Reader(object):
    def __call__(self, buf):
        if not buf:
            return None
        data = bytes(buf)
        del buf[:]
        return Data(data=data)

    def read_eof(self):
        return EndOfMessage()


# ---------------------------------------------------------------- Connection

class Connection(object):
    def __init__(self, our_role, max_incomplete_event_size=DEFAULT_MAX_INCOMPLETE_EVENT_SIZE):
        if our_role not in (CLIENT, SERVER):
            raise ValueError("expected CLIENT or SERVER, not %r" % (our_role,))
        self.our_role = our_role
        self.their_role = other_role(our_role)
        self._cstate = ConnectionState()
        self._max = max_incomplete_event_size
        self._buf = bytearray()
        self._closed = False
        self._writer = self._get_io(our_role, None, False)
        self._reader = self._get_io(self.their_role, None, True)
        self.their_http_version = None
        self._request_method = None
        self.client_is_waiting_for_100_continue = False

    # -- queries
    @property
    def states(self):
        return dict(self._cstate.states)

    @property
    def our_state(self):
        return self._cstate.states[self.our_role]

    @property
    def their_state(self):
        return self._cstate.states[self.their_role]

    @property
    def they_are_waiting_for_100_continue(self):
        return bool(self.their_role is CLIENT and self.client_is_waiting_for_100_continue)

    @property
    def trailing_data(self):
        return (bytes(self._buf), self._closed)

    # -- io object selection
    def _get_io(self, role, event, reading):
        state = self._cstate.states[role]
        if state is SEND_BODY:
            kind, args = _body_framing(self._request_method, event)
            if reading:
                if kind == "content-length":
                    return _ContentLengthReader(*args)
                if kind == "chunked":
                    return _ChunkedReader()
                return _Http10Reader()
            return _BODY_WRITERS[kind](*args)
        if reading:
            if role is CLIENT and state is IDLE:
                return _read_request
            if role is SERVER and state in (IDLE, SEND_RESPONSE):
                return _read_response
            if state in (DONE, MUST_CLOSE, CLOSED):
                return _expect_nothing
            return None
        if role is CLIENT and state is IDLE:
            return _write_request
        if role is SERVER and state in (IDLE, SEND_RESPONSE):
            return _write_any_response
        return None

    def _respond_to_state_changes(self, old, event=None):
        if self.our_state != old[self.our_role]:
            self._writer = self._get_io(self.our_role, event, False)
        if self.their_state != old[self.their_role]:
            self._reader = self._get_io(self.their_role, event, True)

    def _server_switch_event(self, event):
        if type(event) is InformationalResponse and event.status_code == 101:
            return _SWITCH_UPGRADE
        if type(event) is Response:
            if _SWITCH_CONNECT in self._cstate.pending and 200 <= event.status_code < 300:
                return _SWITCH_CONNECT
        return None

    def _process_event(self, role, event):
        old = dict(self._cstate.states)
        if role is CLIENT and type(event) is Request:
            if event.method == b"CONNECT":
                self._cstate.process_client_switch_proposal(_SWITCH_CONNECT)
            if get_comma_header(event.headers, b"upgrade"):
                self._cstate.process_client_switch_proposal(_SWITCH_UPGRADE)
        switch = None
        if role is SERVER:
            switch = self._server_switch_event(event)
        self._cstate.process_event(role, type(event), switch)
        if type(event) is Request:
            self._request_method = event.method
        if role is self.their_role and type(event) in (
            Request, Response, InformationalResponse
        ):
            self.their_http_version = event.http_version
        if type(event) in (Request, Response) and not _keep_alive(event):
            self._cstate.process_keep_alive_disabled()
        if type(event) is Request:
            if _http_version_ge_11(event.http_version) and b"100-continue" in get_comma_header(
                event.headers, b"expect"
            ):
                self.client_is_waiting_for_100_continue = True
        if type(event) in (InformationalResponse, Response):
            self.client_is_waiting_for_100_continue = False
        if role is CLIENT and type(event) in (Data, EndOfMessage):
            self.client_is_waiting_for_100_continue = False
        self._respond_to_state_changes(old, event)

    # -- receiving
    def receive_data(self, data):
        if data:
            if self._closed:
                raise RuntimeError("received close, then received more data?")
            self._buf += data
        else:
            self._closed = True

    def _extract_next_receive_event(self):
        state = self.their_state
        if state is DONE and self._buf:
            return PAUSED
        if state in (MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL):
            return PAUSED
        event = self._reader(self._buf)
        if event is None:
            if self._closed:
                if self._buf:
                    raise RemoteProtocolError("peer closed connection in the middle of an event")
                if hasattr(self._reader, "read_eof"):
                    event = self._reader.read_eof()
                else:
                    event = ConnectionClosed()
            else:
                event = NEED_DATA
        return event

    def next_event(self):
        if self.their_state is ERROR:
            raise RemoteProtocolError("Can't receive data when peer state is ERROR")
        try:
            event = self._extract_next_receive_event()
            if event is not NEED_DATA and event is not PAUSED:
                if not (type(event) is ConnectionClosed and self.their_state is CLOSED):
                    self._process_event(self.their_role, event)
            elif event is NEED_DATA and len(self._buf) > self._max:
                raise RemoteProtocolError(
                    "Receive buffer too long", error_status_hint=431
                )
            return event
        except BaseException as exc:
            self._cstate.process_error(self.their_role)
            if isinstance(exc, LocalProtocolError):
                raise RemoteProtocolError(str(exc), exc.error_status_hint)
            raise

    # -- sending
    def send(self, event):
        parts = self.send_with_data_passthrough(event)
        if not parts:
            return b""
        return b"".join(parts)

    def send_with_data_passthrough(self, event):
        if self.our_state is ERROR:
            raise LocalProtocolError("Can't send data when our state is ERROR")
        try:
            if not isinstance(
                event,
                (Request, InformationalResponse, Response, Data, EndOfMessage, ConnectionClosed),
            ):
                raise LocalProtocolError("not an event: %r" % (event,))
            if type(event) is Response:
                event = self._clean_up_response_headers(event)
            writer = self._writer
            self._process_event(self.our_role, event)
            if type(event) is ConnectionClosed:
                return []
            out = []
            if type(event) is Data:
                writer.send_data(event.data, out.append)
            elif type(event) is EndOfMessage:
                writer.send_eom(event.headers, out.append)
            else:
                writer(event, out.append)
            return out
        except BaseException:
            self._cstate.process_error(self.our_role)
            raise

    def send_failed(self):
        self._cstate.process_error(self.our_role)

    def start_next_cycle(self):
        self._cstate.start_next_cycle()
        old = {CLIENT: None, SERVER: None}
        self._request_method = None
        self.their_http_version = None
        self.client_is_waiting_for_100_continue = False
        self._respond_to_state_changes(old)

    def _clean_up_response_headers(self, response):
        headers = response.headers
        need_close = False
        method = self._request_method
        if method == b"HEAD":
            method = b"GET"
        framing, _ = _body_framing(method, response)
        if framing in ("chunked", "http/1.0"):
            headers = delete_comma_header(headers, b"content-length")
            tv = self.their_http_version
            if tv is None or tv < b"1.1":
                headers = delete_comma_header(headers, b"transfer-encoding")
                need_close = True
            else:
                headers = set_comma_header(headers, b"transfer-encoding", [b"chunked"])
        if not self._cstate.keep_alive or need_close:
            conn = set(get_comma_header(headers, b"connection"))
            conn.discard(b"keep-alive")
            conn.add(b"close")
            headers = set_comma_header(headers, b"connection", sorted(conn))
        return Response(
            status_code=response.status_code,
            headers=headers,
            http_version=response.http_version,
            reason=response.reason,
        )
