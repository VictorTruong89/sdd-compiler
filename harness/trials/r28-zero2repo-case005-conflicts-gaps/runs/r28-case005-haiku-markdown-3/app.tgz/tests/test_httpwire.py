"""Behavioral tests for httpwire, written from the spec. Run: python -m pytest tests/"""

import pytest

import httpwire as h
from httpwire import (
    CLIENT,
    SERVER,
    Connection,
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    LocalProtocolError,
    NEED_DATA,
    PAUSED,
    RemoteProtocolError,
    Request,
    Response,
)


def pair():
    return Connection(CLIENT), Connection(SERVER)


def get_request(**kw):
    headers = kw.pop("headers", [(b"Host", b"example.com")])
    return Request(method=kw.pop("method", b"GET"), target=kw.pop("target", b"/"),
                   headers=headers, http_version=kw.pop("http_version", b"1.1"))


def drain(conn):
    out = []
    while True:
        ev = conn.next_event()
        if ev is NEED_DATA or ev is PAUSED:
            out.append(ev)
            return out
        out.append(ev)


# ---------- FP-01 events ----------

def test_request_defaults_and_lowercase_view():
    r = Request(method="GET", target="/x", headers=[("Host", "a"), ("X-Thing", "V")])
    assert r.http_version == b"1.1"
    assert r.method == b"GET" and isinstance(r.method, bytes)
    assert list(r.headers) == [(b"host", b"a"), (b"x-thing", b"V")]
    assert r.headers.raw_items() == [(b"Host", b"a"), (b"X-Thing", b"V")]


def test_http11_request_requires_single_host():
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/", headers=[])
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/", headers=[(b"host", b"a"), (b"Host", b"b")])
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/", headers=[(b"HOST", b"a"), (b"host", b"b")],
                http_version=b"1.0")
    Request(method=b"GET", target=b"/", headers=[], http_version=b"1.0")


def test_status_ranges():
    with pytest.raises(LocalProtocolError):
        InformationalResponse(status_code=200, headers=[])
    with pytest.raises(LocalProtocolError):
        Response(status_code=199, headers=[])
    with pytest.raises(LocalProtocolError):
        Response(status_code=1000, headers=[])
    with pytest.raises(LocalProtocolError):
        Response(status_code="200", headers=[])
    assert Response(status_code=999, headers=[]).status_code == 999


def test_transfer_encoding_rules():
    r = Request(method=b"POST", target=b"/", headers=[(b"Host", b"a"), (b"Transfer-Encoding", b"CHUNKED")])
    assert list(r.headers)[1] == (b"transfer-encoding", b"chunked")
    with pytest.raises(LocalProtocolError) as ei:
        Request(method=b"POST", target=b"/", headers=[(b"Host", b"a"), (b"Transfer-Encoding", b"gzip")])
    assert ei.value.error_status_hint == 501
    with pytest.raises(LocalProtocolError) as ei:
        Request(method=b"POST", target=b"/", headers=[
            (b"Host", b"a"), (b"Transfer-Encoding", b"chunked"), (b"Transfer-Encoding", b"chunked")])
    assert ei.value.error_status_hint == 501


def test_content_length_collapse_and_conflict():
    r = Request(method=b"POST", target=b"/", headers=[
        (b"Host", b"a"), (b"Content-Length", b"5"), (b"content-length", b"5, 5")])
    assert [x for x in r.headers if x[0] == b"content-length"] == [(b"content-length", b"5")]
    with pytest.raises(LocalProtocolError):
        Request(method=b"POST", target=b"/", headers=[
            (b"Host", b"a"), (b"Content-Length", b"5"), (b"Content-Length", b"6")])
    with pytest.raises(LocalProtocolError):
        Request(method=b"POST", target=b"/", headers=[(b"Host", b"a"), (b"Content-Length", b"+5")])


def test_header_value_rules():
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/", headers=[(b"Host", b"a"), (b"X", b" lead")])
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/", headers=[(b"Host", b"a"), (b"X", b"bad\r\nx")])
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/", headers=[(b"Host", b"a"), (b"bad name", b"v")])
    Request(method=b"GET", target=b"/", headers=[(b"Host", b"a"), (b"X", b"caf\xe9\tok")])


def test_target_and_method_validation():
    with pytest.raises(LocalProtocolError):
        Request(method=b"GE T", target=b"/", headers=[(b"Host", b"a")])
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/a b", headers=[(b"Host", b"a")])


def test_data_and_eom_defaults():
    assert EndOfMessage().headers == []
    d = Data(b"x")
    assert d.chunk_start is False and d.chunk_end is False


# ---------- FP-02 connection basics ----------

def test_request_round_trip_and_host_first():
    c, s = pair()
    wire = c.send(get_request(headers=[(b"X-A", b"1"), (b"Host", b"example.com")]))
    assert wire == b"GET / HTTP/1.1\r\nHost: example.com\r\nX-A: 1\r\n\r\n"
    assert c.states == {CLIENT: h.SEND_BODY, SERVER: h.SEND_RESPONSE}
    assert s.their_http_version is None
    assert s.next_event() is NEED_DATA
    s.receive_data(wire)
    assert s.their_http_version is None  # feeding alone records nothing
    ev = s.next_event()
    assert isinstance(ev, Request)
    assert s.their_http_version == b"1.1"
    assert s.states == {CLIENT: h.SEND_BODY, SERVER: h.SEND_RESPONSE}


def test_feed_only_stores_and_pull_is_two_step():
    c, s = pair()
    wire = c.send(get_request())
    c.send(EndOfMessage())
    s.receive_data(wire)
    assert s.their_state is h.IDLE
    ev = s.next_event()
    assert isinstance(ev, Request)
    assert s.their_http_version == b"1.1"
    assert s.states == {CLIENT: h.SEND_BODY, SERVER: h.SEND_RESPONSE}
    assert isinstance(s.next_event(), EndOfMessage)
    assert s.states == {CLIENT: h.DONE, SERVER: h.SEND_RESPONSE}


def test_partial_event_need_data_then_completes():
    c, s = pair()
    wire = c.send(get_request())
    c.send(EndOfMessage())
    s.receive_data(wire[:10])
    assert s.next_event() is NEED_DATA
    s.receive_data(wire[10:])
    assert isinstance(s.next_event(), Request)


def test_lone_lf_and_obs_fold_accepted():
    c, s = pair()
    s.receive_data(b"GET / HTTP/1.1\nHost: a\nX-Long: one\n   two\n\n")
    ev = s.next_event()
    assert isinstance(ev, Request)
    assert dict(ev.headers)[b"x-long"] == b"one two"


def test_leading_space_or_control_byte_fails_at_once():
    c, s = pair()
    s.receive_data(b" GET")
    with pytest.raises(RemoteProtocolError):
        s.next_event()
    assert s.their_state is h.ERROR
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_bad_constructor_role():
    with pytest.raises(Exception):
        Connection("client")


def test_response_round_trip_reason_and_status_line():
    c, s = pair()
    c.send(get_request())
    c.send(EndOfMessage())
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    s.next_event()
    wire = s.send(Response(status_code=404, headers=[(b"Content-Length", b"0")], reason=b"Nope"))
    assert wire == b"HTTP/1.1 404 Nope\r\nContent-Length: 0\r\n\r\n"
    c.receive_data(wire)
    ev = c.next_event()
    assert isinstance(ev, Response) and ev.status_code == 404 and ev.reason == b"Nope"
    assert isinstance(c.next_event(), EndOfMessage)


def test_empty_reason_round_trips():
    c, s = pair()
    c.send(get_request())
    c.send(EndOfMessage())
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event(); s.next_event()
    wire = s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    assert wire.startswith(b"HTTP/1.1 200 \r\n")
    c.receive_data(wire)
    assert c.next_event().reason == b""


def test_status_line_without_reason_separator_is_remote_error():
    c, s = pair()
    c.send(get_request())
    c.send(EndOfMessage())
    c.receive_data(b"HTTP/1.1 200\r\n\r\n")
    with pytest.raises(RemoteProtocolError):
        c.next_event()


# ---------- FP-03 framing ----------

def test_chunked_request_round_trip_with_trailers_and_marks():
    c, s = pair()
    head = c.send(Request(method=b"POST", target=b"/", headers=[
        (b"Host", b"a"), (b"Transfer-Encoding", b"chunked")]))
    body = c.send(Data(b"hello")) + c.send(Data(b"")) + c.send(Data(b" world"))
    fin = c.send(EndOfMessage(headers=[(b"X-Tr", b"1")]))
    assert body == b"5\r\nhello\r\n6\r\n world\r\n"
    assert fin == b"0\r\nX-Tr: 1\r\n\r\n"
    s.receive_data(head + body + fin)
    assert isinstance(s.next_event(), Request)
    d1 = s.next_event()
    assert d1.data == b"hello" and d1.chunk_start and d1.chunk_end
    d2 = s.next_event()
    assert d2.data == b" world"
    eom = s.next_event()
    assert isinstance(eom, EndOfMessage) and list(eom.headers) == [(b"x-tr", b"1")]


def test_chunk_size_line_rules():
    c, s = pair()
    s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\n")
    s.next_event()
    s.receive_data(b"5 \r\nhello\r\n0\r\n\r\n")
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_chunk_extension_is_ignored():
    c, s = pair()
    s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\n\r\n"
                   b"3;name=val\r\nabc\r\n0\r\n\r\n")
    s.next_event()
    d = s.next_event()
    assert d.data == b"abc"
    assert isinstance(s.next_event(), EndOfMessage)


def test_content_length_request_body():
    c, s = pair()
    head = c.send(Request(method=b"POST", target=b"/", headers=[
        (b"Host", b"a"), (b"Content-Length", b"4")]))
    assert c.send(Data(b"ab")) == b"ab"
    assert c.send(Data(b"cd")) == b"cd"
    with pytest.raises(LocalProtocolError):
        c.send(Data(b"e"))
    assert c.our_state is h.ERROR
    assert head.endswith(b"\r\n\r\n")


def test_content_length_send_end_early_is_error():
    c, _ = pair()
    c.send(Request(method=b"POST", target=b"/", headers=[(b"Host", b"a"), (b"Content-Length", b"4")]))
    with pytest.raises(LocalProtocolError):
        c.send(EndOfMessage())


def test_passthrough_keeps_object_identity():
    c, _ = pair()
    c.send(Request(method=b"POST", target=b"/", headers=[(b"Host", b"a"), (b"Transfer-Encoding", b"chunked")]))
    payload = memoryview(b"0123456789")
    pieces = c.send_with_data_passthrough(Data(payload))
    assert pieces[0] == b"a\r\n"
    assert pieces[1] is payload
    assert pieces[2] == b"\r\n"


def test_response_with_content_length_zero_keeps_header():
    c, s = pair()
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    wire = s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    assert b"Content-Length: 0" in wire


def test_response_to_1_1_without_framing_uses_chunked():
    c, s = pair()
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event()
    wire = s.send(Response(status_code=200, headers=[]))
    assert b"Transfer-Encoding: chunked" in wire
    body = s.send(Data(b"hi")) + s.send(EndOfMessage())
    assert body == b"2\r\nhi\r\n0\r\n\r\n"


def test_head_response_has_no_body():
    c, s = pair()
    c.send(Request(method=b"HEAD", target=b"/", headers=[(b"Host", b"a")]))
    c.send(EndOfMessage())
    s.receive_data(b"HEAD / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event(); s.next_event()
    wire = s.send(Response(status_code=200, headers=[(b"Content-Length", b"10")]))
    assert s.send(EndOfMessage()) == b""
    with pytest.raises(LocalProtocolError):
        s.send(Data(b"x"))
    c.receive_data(wire)
    assert isinstance(c.next_event(), Response)
    assert isinstance(c.next_event(), EndOfMessage)


def test_204_has_no_body_and_eom_empty():
    c, s = pair()
    s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n\r\n")
    s.next_event(); s.next_event()
    s.send(Response(status_code=204, headers=[]))
    assert s.send(EndOfMessage()) == b""


def test_http10_close_delimited_response():
    c, s = pair()
    s.receive_data(b"GET / HTTP/1.0\r\n\r\n")
    s.next_event(); s.next_event()
    wire = s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    assert b"Connection: close" in wire
    assert s.our_state is h.SEND_BODY or s.our_state is h.DONE


def test_client_receives_close_delimited_body():
    c, s = pair()
    c.send(get_request())
    c.send(EndOfMessage())
    c.receive_data(b"HTTP/1.0 200 OK\r\n\r\nbody bytes")
    assert isinstance(c.next_event(), Response)
    assert c.next_event().data == b"body bytes"
    c.receive_data(b"")
    assert isinstance(c.next_event(), EndOfMessage)
    assert isinstance(c.next_event(), ConnectionClosed)
    assert c.their_state is h.CLOSED
    assert c.our_state is h.MUST_CLOSE


def test_remote_close_mid_body_is_remote_error():
    c, s = pair()
    c.send(get_request())
    c.send(EndOfMessage())
    c.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 10\r\n\r\nabc")
    c.next_event(); c.next_event()
    c.receive_data(b"")
    with pytest.raises(RemoteProtocolError):
        c.next_event()


# ---------- FP-04 lifecycle ----------

def test_keep_alive_second_cycle():
    c, s = pair()
    for _ in range(2):
        wire = c.send(get_request())
        c.send(EndOfMessage())
        s.receive_data(wire)
        assert isinstance(s.next_event(), Request)
        assert isinstance(s.next_event(), EndOfMessage)
        s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
        s.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
        assert isinstance(c.next_event(), Response)
        assert isinstance(c.next_event(), EndOfMessage)
        assert c.states == {CLIENT: h.DONE, SERVER: h.DONE}
        c.start_next_cycle(); s.start_next_cycle()
        assert c.states == {CLIENT: h.IDLE, SERVER: h.IDLE}


def test_connection_close_request_disables_keep_alive():
    c, s = pair()
    wire = c.send(get_request(headers=[(b"Host", b"a"), (b"Connection", b"Close")]))
    c.send(EndOfMessage())
    s.receive_data(wire)
    s.next_event(); s.next_event()
    assert s.their_state is h.MUST_CLOSE
    wire = s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    assert b"Connection: close" in wire


def test_client_second_request_refused_and_nonfatal():
    c, _ = pair()
    c.send(get_request())
    c.send(EndOfMessage())
    with pytest.raises(LocalProtocolError):
        c.send(get_request())
    assert c.our_state is h.ERROR


def test_start_next_cycle_refused_is_recoverable():
    c, s = pair()
    c.send(get_request())
    with pytest.raises(LocalProtocolError):
        c.start_next_cycle()
    assert c.our_state is h.SEND_BODY


def test_server_sends_request_is_refused():
    _, s = pair()
    with pytest.raises(LocalProtocolError):
        s.send(get_request())


def test_pipelining_is_paused_until_next_cycle():
    c, s = pair()
    wire = c.send(get_request())
    c.send(EndOfMessage())
    s.receive_data(wire + wire)  # second request is pipelined
    assert isinstance(s.next_event(), Request)
    assert isinstance(s.next_event(), EndOfMessage)
    assert s.next_event() is PAUSED
    s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    assert s.next_event() is PAUSED  # still DONE on the client side
    assert s.trailing_data[0] == wire
    c.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
    c.next_event(); c.next_event()
    s.start_next_cycle()
    c.start_next_cycle()
    assert isinstance(s.next_event(), Request)


def test_server_immediate_error_response_without_request():
    _, s = pair()
    wire = s.send(Response(status_code=400, headers=[]))
    assert b"Connection: close" in wire
    assert s.send(EndOfMessage()) == b""
    assert s.our_state is h.MUST_CLOSE


def test_remote_error_then_error_response_has_close():
    c, s = pair()
    s.receive_data(b"GARBAGE\r\n\r\n")
    with pytest.raises(RemoteProtocolError):
        s.next_event()
    assert s.their_state is h.ERROR
    wire = s.send(Response(status_code=400, headers=[(b"Content-Length", b"0")]))
    assert b"Connection: close" in wire


def test_incomplete_event_limit_431():
    s = Connection(SERVER, max_incomplete_event_size=100)
    s.receive_data(b"GET / HTTP/1.1\r\n" + b"X-A: " + b"a" * 200)
    with pytest.raises(RemoteProtocolError) as ei:
        s.next_event()
    assert ei.value.error_status_hint == 431


def test_default_limit_is_8k():
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nX-A: " + b"a" * (9 * 1024))
    with pytest.raises(RemoteProtocolError) as ei:
        s.next_event()
    assert ei.value.error_status_hint == 431


def test_local_send_error_is_unrecoverable_but_construction_is_not():
    c, _ = pair()
    with pytest.raises(LocalProtocolError):
        Request(method=b"GET", target=b"/", headers=[])  # construction only
    c.send(get_request())
    # Trailers are not allowed with Content-Length framing (a request with no framing is length 0).
    with pytest.raises(LocalProtocolError):
        c.send(EndOfMessage(headers=[(b"X", b"1")]))
    assert c.our_state is h.ERROR
    # Unrecoverable: a send that would be legal on a fresh connection now fails.
    with pytest.raises(LocalProtocolError):
        c.send(EndOfMessage())


def test_send_failed_marks_error():
    c, _ = pair()
    c.send(get_request())
    c.send_failed()
    assert c.our_state is h.ERROR


def test_http10_request_and_send_refusal():
    c, _ = pair()
    with pytest.raises(LocalProtocolError):
        c.send(Request(method=b"GET", target=b"/", headers=[], http_version=b"1.0"))


# ---------- FP-06 shutdown ----------

def test_client_closed_from_idle_and_server_must_close():
    c, s = pair()
    assert c.send(ConnectionClosed()) == b""
    assert c.our_state is h.CLOSED
    assert s.their_state is h.IDLE
    s.receive_data(b"")
    ev = s.next_event()
    assert isinstance(ev, ConnectionClosed)
    assert s.their_state is h.CLOSED
    assert s.our_state is h.MUST_CLOSE
    assert isinstance(s.next_event(), ConnectionClosed)


def test_close_in_send_body_is_refused():
    c, _ = pair()
    c.send(get_request())
    with pytest.raises(LocalProtocolError):
        c.send(ConnectionClosed())


def test_feed_after_close_is_runtime_error():
    s = Connection(SERVER)
    s.receive_data(b"")
    with pytest.raises(RuntimeError) as ei:
        s.receive_data(b"x")
    assert not isinstance(ei.value, (LocalProtocolError, RemoteProtocolError))


# ---------- FP-07 100-continue, CONNECT, Upgrade ----------

def test_expect_100_continue_flags_and_informational():
    c, s = pair()
    wire = c.send(Request(method=b"PUT", target=b"/", headers=[
        (b"Host", b"a"), (b"Expect", b"100-continue"), (b"Content-Length", b"3")]))
    assert c.client_is_waiting_for_100_continue is True
    assert c.they_are_waiting_for_100_continue is False
    s.receive_data(wire)
    s.next_event()
    assert s.they_are_waiting_for_100_continue is True
    # The server's informational response ends the wait on both connections.
    s.send(InformationalResponse(status_code=100, headers=[]))
    assert s.they_are_waiting_for_100_continue is False
    c.receive_data(b"HTTP/1.1 100 Continue\r\n\r\n")
    assert isinstance(c.next_event(), InformationalResponse)
    assert c.client_is_waiting_for_100_continue is False


def test_client_body_send_turns_off_waiting_flag():
    c, _ = pair()
    c.send(Request(method=b"PUT", target=b"/", headers=[
        (b"Host", b"a"), (b"Expect", b"100-continue"), (b"Content-Length", b"3")]))
    assert c.client_is_waiting_for_100_continue is True
    c.send(Data(b"abc"))
    assert c.client_is_waiting_for_100_continue is False


def test_connect_accepted_switches_protocol():
    c, s = pair()
    wire = c.send(Request(method=b"CONNECT", target=b"example.com:443", headers=[(b"Host", b"example.com:443")]))
    c.send(EndOfMessage())
    s.receive_data(wire + b"tls-bytes")
    assert isinstance(s.next_event(), Request)
    assert isinstance(s.next_event(), EndOfMessage)
    assert c.our_state is h.MIGHT_SWITCH_PROTOCOL
    assert s.next_event() is PAUSED  # server pulls pause while the client might switch
    s.send(Response(status_code=200, headers=[]))
    assert s.our_state is h.SWITCHED_PROTOCOL
    assert s.their_state is h.SWITCHED_PROTOCOL
    assert s.next_event() is PAUSED
    assert s.trailing_data == (b"tls-bytes", False)
    c.receive_data(b"HTTP/1.1 200 OK\r\n\r\n")
    assert isinstance(c.next_event(), Response)
    assert c.our_state is h.SWITCHED_PROTOCOL
    with pytest.raises(LocalProtocolError):
        s.send(EndOfMessage())


def test_upgrade_denied_returns_to_http():
    c, s = pair()
    wire = c.send(Request(method=b"GET", target=b"/ws", headers=[(b"Host", b"a"), (b"Upgrade", b"websocket")]))
    c.send(EndOfMessage())
    s.receive_data(wire)
    s.next_event(); s.next_event()
    s.send(Response(status_code=400, headers=[(b"Content-Length", b"0")]))
    s.send(EndOfMessage())
    c.receive_data(b"HTTP/1.1 400 Bad\r\nContent-Length: 0\r\n\r\n")
    c.next_event(); c.next_event()
    assert c.states == {CLIENT: h.DONE, SERVER: h.DONE}
    c.start_next_cycle(); s.start_next_cycle()


def test_upgrade_101_switches():
    c, s = pair()
    wire = c.send(Request(method=b"GET", target=b"/ws", headers=[(b"Host", b"a"), (b"Upgrade", b"websocket")]))
    c.send(EndOfMessage())
    s.receive_data(wire)
    s.next_event(); s.next_event()
    s.send(InformationalResponse(status_code=101, headers=[(b"Upgrade", b"websocket")]))
    assert s.our_state is h.SWITCHED_PROTOCOL
    c.receive_data(b"HTTP/1.1 101 Switching\r\nUpgrade: websocket\r\n\r\nframe")
    assert isinstance(c.next_event(), InformationalResponse)
    assert c.their_state is h.SWITCHED_PROTOCOL
    assert c.next_event() is PAUSED
    assert c.trailing_data[0] == b"frame"


def test_data_in_send_body_passthrough_does_not_need_bytes():
    c, _ = pair()
    c.send(Request(method=b"POST", target=b"/", headers=[(b"Host", b"a"), (b"Content-Length", b"0")]))
    with pytest.raises(LocalProtocolError):
        c.send(Data(b"x"))


def test_public_names_present():
    for name in ["CLIENT", "CLOSED", "Connection", "ConnectionClosed", "Data", "DONE", "EndOfMessage",
                 "ERROR", "IDLE", "InformationalResponse", "LocalProtocolError", "MIGHT_SWITCH_PROTOCOL",
                 "MUST_CLOSE", "NEED_DATA", "PAUSED", "RemoteProtocolError", "Request", "Response",
                 "SEND_BODY", "SEND_RESPONSE", "SERVER", "SWITCHED_PROTOCOL"]:
        assert hasattr(h, name), name
