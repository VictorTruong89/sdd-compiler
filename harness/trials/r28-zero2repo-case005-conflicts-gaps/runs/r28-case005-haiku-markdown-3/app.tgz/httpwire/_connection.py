"""The bring-your-own-I/O HTTP/1.1 connection (PRD FP-02 to FP-07)."""

import re

from ._errors import LocalProtocolError, RemoteProtocolError
from ._events import (
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    Request,
    Response,
)
from ._states import (
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
)

DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 8 * 1024
# Chunk-size lines may carry up to this many hex digits (PRD FP-03).
_MAX_CHUNK_HEX_DIGITS = 64

_HEX = re.compile(rb"[0-9A-Fa-f]{1,%d}" % _MAX_CHUNK_HEX_DIGITS)
_STATUS3 = re.compile(rb"[0-9]{3}")
_VERSION_LINE = re.compile(rb"HTTP/([0-9])\.([0-9])")
_OWS = b" \t"

# Pairs (role, state, event kind) that a role may send.
_LEGAL_SENDS = {
    (CLIENT, IDLE, "request"),
    (CLIENT, SEND_BODY, "data"),
    (CLIENT, SEND_BODY, "eom"),
    (SERVER, IDLE, "response"),
    (SERVER, SEND_RESPONSE, "info"),
    (SERVER, SEND_RESPONSE, "response"),
    (SERVER, SEND_BODY, "data"),
    (SERVER, SEND_BODY, "eom"),
}
# States from which a side may send connection-closed.
_CLOSABLE = (IDLE, DONE, MUST_CLOSE)


class ReceiveAfterCloseError(RuntimeError):
    """Non-empty bytes were fed after the receive side was closed."""


def _opposite(role):
    return SERVER if role is CLIENT else CLIENT


def _kind(event):
    if isinstance(event, Request):
        return "request"
    if isinstance(event, InformationalResponse):
        return "info"
    if isinstance(event, Response):
        return "response"
    if isinstance(event, Data):
        return "data"
    if isinstance(event, EndOfMessage):
        return "eom"
    if isinstance(event, ConnectionClosed):
        return "closed"
    raise LocalProtocolError("not an HTTP event: %r" % (event,))


def _has(headers, lower_name):
    return any(lower == lower_name for lower, _value in headers)


def _get(headers, lower_name):
    for lower, value in headers:
        if lower == lower_name:
            return value
    return None


def _has_token(headers, lower_name, token):
    for lower, value in headers:
        if lower == lower_name:
            for piece in value.split(b","):
                if piece.strip(_OWS).lower() == token:
                    return True
    return False


def _encode_head(start_line, items, host_first=False):
    if host_first:
        hosts = [it for it in items if it[0].lower() == b"host"]
        others = [it for it in items if it[0].lower() != b"host"]
        items = hosts + others
    lines = [start_line]
    for raw, value in items:
        lines.append(raw + b": " + value)
    return b"\r\n".join(lines) + b"\r\n\r\n"


def _with_connection_close(items):
    """Replace the Connection header(s) with one that ends in close, dropping keep-alive."""
    tokens = []
    out = []
    for raw, value in items:
        if raw.lower() == b"connection":
            for piece in value.split(b","):
                tok = piece.strip(_OWS)
                if tok and tok.lower() not in (b"keep-alive", b"close"):
                    tokens.append(tok)
        else:
            out.append((raw, value))
    tokens.append(b"close")
    out.append((b"Connection", b", ".join(tokens)))
    return out


def _payload_length(raw):
    if isinstance(raw, (bytes, bytearray, memoryview)):
        return memoryview(raw).nbytes
    try:
        return len(raw)
    except TypeError:
        raise LocalProtocolError("data payload has no length")


def _request_framing(headers):
    if _has(headers, b"content-length"):
        return ("length", int(_get(headers, b"content-length").decode("ascii")))
    if _has(headers, b"transfer-encoding"):
        return ("chunked",)
    return ("length", 0)


def _build(factory):
    try:
        return factory()
    except LocalProtocolError as exc:
        raise RemoteProtocolError(str(exc), exc.error_status_hint)


class Connection:
    """One HTTP/1.1 connection in the CLIENT or SERVER role. It does no I/O."""

    def __init__(self, role, max_incomplete_event_size=DEFAULT_MAX_INCOMPLETE_EVENT_SIZE):
        if role is not CLIENT and role is not SERVER:
            raise ValueError("role must be CLIENT or SERVER")
        self.our_role = role
        self.their_role = _opposite(role)
        self._max_incomplete = int(max_incomplete_event_size)
        self._state = {CLIENT: IDLE, SERVER: IDLE}
        self._buf = bytearray()
        self._recv_closed = False
        self._their_version = None
        self._body_framing = {CLIENT: None, SERVER: None}
        self._remaining = {CLIENT: 0, SERVER: 0}
        self._chunk_state = {CLIENT: "size", SERVER: "size"}
        self._chunk_left = {CLIENT: 0, SERVER: 0}
        self._chunk_fresh = {CLIENT: False, SERVER: False}
        self._request_method = None
        self._ka_disabled = False
        self._connect_proposal = False
        self._upgrade_proposal = False
        self._waiting_100 = False
        self._remote_error = None

    # ----- introspection -------------------------------------------------

    @property
    def our_state(self):
        return self._state[self.our_role]

    @property
    def their_state(self):
        return self._state[self.their_role]

    @property
    def states(self):
        return {CLIENT: self._state[CLIENT], SERVER: self._state[SERVER]}

    @property
    def their_http_version(self):
        return self._their_version

    @property
    def client_is_waiting_for_100_continue(self):
        return bool(self._waiting_100)

    @property
    def they_are_waiting_for_100_continue(self):
        return bool(self._waiting_100 and self.our_role is SERVER)

    @property
    def trailing_data(self):
        return (bytes(self._buf), self._recv_closed)

    # ----- send ----------------------------------------------------------

    def send(self, event):
        """Encode an event to bytes. Returns a bytes-like object (may be empty)."""
        return b"".join(self._send(event, passthrough=False))

    def send_with_data_passthrough(self, event):
        """Like send, but returns a list of pieces; Data payload objects are kept as-is."""
        return self._send(event, passthrough=True)

    def _send(self, event, passthrough):
        if self._state[self.our_role] is ERROR:
            raise LocalProtocolError("cannot send: this side is in ERROR")
        try:
            return self._send_checked(event, passthrough)
        except LocalProtocolError:
            self._state[self.our_role] = ERROR
            self._post()
            raise

    def _send_checked(self, event, passthrough):
        role = self.our_role
        kind = _kind(event)
        st = self._state[role]
        if kind == "closed":
            if st not in _CLOSABLE:
                raise LocalProtocolError("cannot send connection-closed in state %r" % (st,))
            self._process(role, event)
            return []
        if (role, st, kind) not in _LEGAL_SENDS:
            raise LocalProtocolError("cannot send %s while in state %r" % (kind, st))
        if kind == "request":
            return self._send_request(event)
        if kind in ("info", "response"):
            return self._send_response(event, kind == "info")
        if kind == "data":
            return self._send_data(event, passthrough)
        return self._send_eom(event)

    def _send_request(self, ev):
        if ev.http_version != b"1.1":
            raise LocalProtocolError("only HTTP/1.1 requests can be sent")
        items = ev.headers.raw_items()
        if _has(ev.headers, b"content-length"):
            framing = _request_framing(ev.headers)
            items = [(r, v) for r, v in items if r.lower() != b"transfer-encoding"]
        elif _has(ev.headers, b"transfer-encoding"):
            framing = ("chunked",)
        else:
            framing = ("length", 0)
        start = b" ".join([ev.method, ev.target, b"HTTP/1.1"])
        head = _encode_head(start, items, host_first=True)
        self._process(CLIENT, ev, framing)
        return [head]

    def _send_response(self, ev, is_info):
        if ev.http_version != b"1.1":
            raise LocalProtocolError("only HTTP/1.1 responses can be sent")
        start = b"HTTP/1.1 " + str(ev.status_code).encode("ascii") + b" " + ev.reason
        items = ev.headers.raw_items()
        if is_info:
            head = _encode_head(start, items)
            self._process(SERVER, ev)
            return [head]

        peer11 = self._their_version == b"1.1"
        has_cl = _has(ev.headers, b"content-length")
        has_te = _has(ev.headers, b"transfer-encoding")
        if ev.status_code in (204, 304):
            body = ("empty",)
        else:
            if has_te:
                # Transfer-Encoding wins over Content-Length (PRD FP-03).
                if peer11:
                    hdr = ("chunked",)
                    items = [(r, v) for r, v in items if r.lower() != b"content-length"]
                else:
                    hdr = ("close",)
                    items = [(r, v) for r, v in items
                             if r.lower() not in (b"content-length", b"transfer-encoding")]
            elif has_cl:
                hdr = ("length", int(_get(ev.headers, b"content-length").decode("ascii")))
            elif peer11:
                hdr = ("chunked",)
                items = items + [(b"Transfer-Encoding", b"chunked")]
            else:
                hdr = ("close",)
            # HEAD gets the framing headers GET would get, but no body.
            body = ("empty",) if self._request_method == b"HEAD" else hdr

        close_needed = (
            not peer11
            or self._ka_disabled
            or _has_token(ev.headers, b"connection", b"close")
            or self._state[self.their_role] is ERROR
            or body[0] == "close"
        )
        if close_needed:
            items = _with_connection_close(items)
        head = _encode_head(start, items)
        self._process(SERVER, ev, body, force_close=close_needed)
        return [head]

    def _send_data(self, ev, passthrough):
        role = self.our_role
        raw = ev.data
        if not isinstance(raw, (bytes, bytearray, memoryview)):
            if isinstance(raw, str):
                raise LocalProtocolError("data payload must be bytes-like")
            if not passthrough:
                try:
                    raw = bytes(raw)
                except TypeError:
                    raise LocalProtocolError("data payload must be bytes-like")
        n = _payload_length(raw)
        framing = self._body_framing[role]
        kind = framing[0]
        if kind == "length":
            if n > self._remaining[role]:
                raise LocalProtocolError("data exceeds the declared Content-Length")
            self._remaining[role] -= n
            pieces = [raw] if n else []
        elif kind == "chunked":
            pieces = [("%x\r\n" % n).encode("ascii"), raw, b"\r\n"] if n else []
        elif kind == "close":
            pieces = [raw] if n else []
        else:
            if n:
                raise LocalProtocolError("this response must not have a body")
            pieces = []
        self._process(role, ev)
        return pieces

    def _send_eom(self, ev):
        role = self.our_role
        kind = self._body_framing[role][0]
        if kind == "length":
            if self._remaining[role]:
                raise LocalProtocolError("body is shorter than the declared Content-Length")
            if len(ev.headers):
                raise LocalProtocolError("trailers are not allowed with Content-Length framing")
            pieces = []
        elif kind == "chunked":
            trailer = b"".join(r + b": " + v + b"\r\n" for r, v in ev.headers.raw_items())
            pieces = [b"0\r\n" + trailer + b"\r\n"]
        else:
            if len(ev.headers):
                raise LocalProtocolError("trailers are not allowed with this framing")
            pieces = []
        self._process(role, ev)
        return pieces

    # ----- receive -------------------------------------------------------

    def receive_data(self, data):
        """Store bytes from the peer. An empty chunk means the peer closed its sending side."""
        if len(data) == 0:
            self._recv_closed = True
            return None
        if self._recv_closed:
            raise ReceiveAfterCloseError("data received after the peer closed its side")
        self._buf += data
        return None

    def next_event(self):
        """Parse one event from stored bytes. Returns an event, NEED_DATA, or PAUSED."""
        try:
            return self._next_event()
        except RemoteProtocolError as exc:
            self._fail_remote(exc)
            raise

    def _fail_remote(self, exc):
        self._state[self.their_role] = ERROR
        if self._remote_error is None:
            self._remote_error = exc
        self._post()

    def _next_event(self):
        their = self.their_role
        st = self._state[their]
        if st is ERROR:
            err = self._remote_error
            raise RemoteProtocolError(
                str(err) if err else "peer is in error state",
                err.error_status_hint if err else 400)
        if st is SWITCHED_PROTOCOL or st is MIGHT_SWITCH_PROTOCOL:
            return PAUSED
        if st is CLOSED:
            return ConnectionClosed()
        if st is DONE or st is MUST_CLOSE:
            if self._buf:
                return PAUSED
            if self._recv_closed:
                return self._pull_closed(their)
            return NEED_DATA
        if st is IDLE:
            if their is CLIENT:
                return self._pull_request()
            if self._buf:
                raise RemoteProtocolError("unexpected data before a request was sent")
            if self._recv_closed:
                return self._pull_closed(their)
            return NEED_DATA
        if st is SEND_RESPONSE:
            return self._pull_response()
        if st is SEND_BODY:
            return self._pull_body(their)
        return NEED_DATA

    def _pull_closed(self, their):
        if self._state[their] not in (IDLE, DONE, MUST_CLOSE, CLOSED):
            raise RemoteProtocolError("peer closed while not allowed to close")
        ev = ConnectionClosed()
        self._process(their, ev)
        return ev

    def _incomplete(self, what):
        if self._recv_closed:
            raise RemoteProtocolError("connection closed in the middle of %s" % what)
        if len(self._buf) > self._max_incomplete:
            raise RemoteProtocolError("incomplete event exceeds the size limit", 431)
        return NEED_DATA

    def _read_block(self):
        """Return (lines, consumed) for a complete header block, or None."""
        buf = self._buf
        lines = []
        pos = 0
        while True:
            nl = buf.find(b"\n", pos)
            if nl < 0:
                return None
            line = bytes(buf[pos:nl])
            if line.endswith(b"\r"):
                line = line[:-1]
            pos = nl + 1
            if not line:
                return lines, pos
            lines.append(line)

    @staticmethod
    def _parse_fields(lines):
        pairs = []
        for line in lines:
            if line[:1] in (b" ", b"\t"):
                if not pairs:
                    raise RemoteProtocolError("obsolete line folding with no header to continue")
                name, value = pairs[-1]
                rest = line.strip(_OWS)
                pairs[-1] = (name, b" ".join(x for x in (value, rest) if x))
                continue
            colon = line.find(b":")
            if colon < 0:
                raise RemoteProtocolError("header line has no colon")
            name = line[:colon]
            value = line[colon + 1:].strip(_OWS)
            pairs.append((name, value))
        return pairs

    def _pull_request(self):
        buf = self._buf
        if not buf:
            if self._recv_closed:
                return self._pull_closed(self.their_role)
            return NEED_DATA
        if buf[0] < 33:
            raise RemoteProtocolError("request line starts with a space or control byte")
        block = self._read_block()
        if block is None:
            return self._incomplete("a request head")
        lines, consumed = block
        parts = lines[0].split(b" ")
        if len(parts) != 3:
            raise RemoteProtocolError("malformed request line")
        method, target, version_text = parts
        match = _VERSION_LINE.fullmatch(version_text)
        if not match:
            raise RemoteProtocolError("malformed HTTP version in request line")
        version = match.group(1) + b"." + match.group(2)
        if version not in (b"1.0", b"1.1"):
            raise RemoteProtocolError("unsupported HTTP version")
        pairs = self._parse_fields(lines[1:])
        ev = _build(lambda: Request(method=method, target=target,
                                    headers=pairs, http_version=version))
        del buf[:consumed]
        self._their_version = ev.http_version
        self._process(CLIENT, ev, _request_framing(ev.headers))
        return ev

    def _pull_response(self):
        buf = self._buf
        if not buf:
            if self._recv_closed:
                raise RemoteProtocolError("connection closed before a response")
            return NEED_DATA
        if buf[0] < 33:
            raise RemoteProtocolError("status line starts with a space or control byte")
        block = self._read_block()
        if block is None:
            return self._incomplete("a response head")
        lines, consumed = block
        line = lines[0]
        if not line.startswith(b"HTTP/"):
            raise RemoteProtocolError("malformed status line")
        parts = line.split(b" ", 2)
        if len(parts) < 3:
            raise RemoteProtocolError("status line has no reason phrase separator")
        version_text, code_text, reason = parts
        match = _VERSION_LINE.fullmatch(version_text)
        if not match:
            raise RemoteProtocolError("malformed HTTP version in status line")
        version = match.group(1) + b"." + match.group(2)
        if version not in (b"1.0", b"1.1"):
            raise RemoteProtocolError("unsupported HTTP version")
        if not _STATUS3.fullmatch(code_text):
            raise RemoteProtocolError("status code must be three digits")
        code = int(code_text.decode("ascii"))
        pairs = self._parse_fields(lines[1:])
        del buf[:consumed]
        if code < 200:
            ev = _build(lambda: InformationalResponse(
                status_code=code, headers=pairs, http_version=version, reason=reason))
            self._their_version = ev.http_version
            self._process(SERVER, ev)
            return ev
        ev = _build(lambda: Response(
            status_code=code, headers=pairs, http_version=version, reason=reason))
        self._their_version = ev.http_version
        self._process(SERVER, ev, self._response_framing(code, ev.headers))
        return ev

    def _response_framing(self, code, headers):
        if code < 200 or code in (204, 304) or self._request_method == b"HEAD":
            return ("empty",)
        if _has(headers, b"content-length"):
            return ("length", int(_get(headers, b"content-length").decode("ascii")))
        if _has(headers, b"transfer-encoding"):
            return ("chunked",)
        return ("close",)

    def _finish_body(self, their, headers=()):
        ev = EndOfMessage(headers=headers)
        self._process(their, ev)
        return ev

    def _pull_body(self, their):
        framing = self._body_framing[their]
        kind = framing[0]
        buf = self._buf
        if kind == "empty" or (kind == "length" and self._remaining[their] == 0):
            return self._finish_body(their)
        if kind == "length":
            if not buf:
                if self._recv_closed:
                    raise RemoteProtocolError("connection closed in the middle of a body")
                return NEED_DATA
            left = self._remaining[their]
            n = min(left, len(buf))
            data = bytes(buf[:n])
            del buf[:n]
            self._remaining[their] = left - n
            ev = Data(data)
            self._process(their, ev)
            return ev
        if kind == "close":
            if buf:
                data = bytes(buf)
                buf.clear()
                ev = Data(data)
                self._process(their, ev)
                return ev
            if self._recv_closed:
                return self._finish_body(their)
            return NEED_DATA
        return self._pull_chunked(their)

    def _pull_chunked(self, their):
        buf = self._buf
        while True:
            st = self._chunk_state[their]
            if st == "size":
                nl = buf.find(b"\n")
                if nl < 0:
                    if self._recv_closed:
                        raise RemoteProtocolError("connection closed in the middle of a chunk size line")
                    return NEED_DATA
                line = bytes(buf[:nl])
                del buf[:nl + 1]
                if line.endswith(b"\r"):
                    line = line[:-1]
                semi = line.find(b";")
                size_text = line if semi < 0 else line[:semi]
                if not _HEX.fullmatch(size_text):
                    raise RemoteProtocolError("invalid chunk size line")
                size = int(size_text.decode("ascii"), 16)
                if size == 0:
                    self._chunk_state[their] = "trailer"
                else:
                    self._chunk_state[their] = "data"
                    self._chunk_left[their] = size
                    self._chunk_fresh[their] = True
                continue
            if st == "data":
                if not buf:
                    if self._recv_closed:
                        raise RemoteProtocolError("connection closed in the middle of a chunk")
                    return NEED_DATA
                left = self._chunk_left[their]
                n = min(left, len(buf))
                data = bytes(buf[:n])
                del buf[:n]
                left -= n
                self._chunk_left[their] = left
                start = self._chunk_fresh[their]
                self._chunk_fresh[their] = False
                end = left == 0
                if end:
                    self._chunk_state[their] = "crlf"
                ev = Data(data, chunk_start=start, chunk_end=end)
                self._process(their, ev)
                return ev
            if st == "crlf":
                if len(buf) >= 2:
                    if bytes(buf[:2]) != b"\r\n":
                        raise RemoteProtocolError("chunk data is not followed by CRLF")
                    del buf[:2]
                    self._chunk_state[their] = "size"
                    continue
                if buf and buf[0] != 0x0D:
                    raise RemoteProtocolError("chunk data is not followed by CRLF")
                if self._recv_closed:
                    raise RemoteProtocolError("connection closed in the middle of a chunk")
                return NEED_DATA
            # st == "trailer": the zero-size chunk was read; trailers follow.
            block = self._read_block()
            if block is None:
                return self._incomplete("a chunked body trailer")
            lines, consumed = block
            pairs = self._parse_fields(lines)
            ev = _build(lambda: EndOfMessage(headers=pairs))
            del buf[:consumed]
            self._process(their, ev)
            return ev

    # ----- state machine -------------------------------------------------

    def _begin_body(self, role, framing):
        self._body_framing[role] = framing
        self._remaining[role] = framing[1] if framing and framing[0] == "length" else 0
        self._chunk_state[role] = "size"
        self._chunk_left[role] = 0
        self._chunk_fresh[role] = False

    def _accepts(self, ev):
        """Whether ev accepts the client's pending CONNECT or Upgrade proposal."""
        if self._state[CLIENT] is not MIGHT_SWITCH_PROTOCOL:
            return False
        if isinstance(ev, InformationalResponse):
            return ev.status_code == 101 and self._upgrade_proposal
        if isinstance(ev, Response):
            return ev.status_code == 200 and self._connect_proposal
        return False

    def _process(self, role, ev, framing=None, force_close=False):
        """Apply the effect of one event sent or pulled by `role`."""
        st = self._state
        kind = _kind(ev)
        if kind == "request":
            if st[CLIENT] is IDLE:
                st[CLIENT] = SEND_BODY
            if st[SERVER] is IDLE:
                st[SERVER] = SEND_RESPONSE
            self._begin_body(CLIENT, framing)
            self._request_method = ev.method
            self._connect_proposal = ev.method == b"CONNECT"
            self._upgrade_proposal = _has(ev.headers, b"upgrade")
            self._waiting_100 = _has_token(ev.headers, b"expect", b"100-continue")
            if (ev.http_version != b"1.1"
                    or _has_token(ev.headers, b"connection", b"close")):
                self._ka_disabled = True
        elif kind == "info":
            if self._accepts(ev):
                st[CLIENT] = SWITCHED_PROTOCOL
                st[SERVER] = SWITCHED_PROTOCOL
            self._waiting_100 = False
        elif kind == "response":
            if self._accepts(ev):
                st[CLIENT] = SWITCHED_PROTOCOL
                st[SERVER] = SWITCHED_PROTOCOL
            else:
                st[SERVER] = SEND_BODY
                self._begin_body(SERVER, framing)
                if st[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                    st[CLIENT] = DONE
            self._waiting_100 = False
            if (force_close
                    or ev.http_version != b"1.1"
                    or _has_token(ev.headers, b"connection", b"close")
                    or (framing is not None and framing[0] == "close")):
                self._ka_disabled = True
        elif kind == "data":
            if role is CLIENT:
                self._waiting_100 = False
        elif kind == "eom":
            if role is CLIENT:
                self._waiting_100 = False
                if self._connect_proposal or self._upgrade_proposal:
                    st[CLIENT] = MIGHT_SWITCH_PROTOCOL
                else:
                    st[CLIENT] = DONE
            else:
                st[SERVER] = DONE
        elif kind == "closed":
            st[role] = CLOSED
        self._post()

    def _post(self):
        """Apply the cross-side rules that follow from both states."""
        st = self._state
        for role in (CLIENT, SERVER):
            other = _opposite(role)
            if st[role] is CLOSED and st[other] in (IDLE, DONE):
                st[other] = MUST_CLOSE
            if st[role] is ERROR and st[other] is DONE:
                st[other] = MUST_CLOSE
        if self._ka_disabled:
            for role in (CLIENT, SERVER):
                if st[role] is DONE:
                    st[role] = MUST_CLOSE

    # ----- cycle control -------------------------------------------------

    def start_next_cycle(self):
        """Reset both sides to IDLE so another request/response can run."""
        st = self._state
        if st[CLIENT] is not DONE or st[SERVER] is not DONE:
            raise LocalProtocolError("cannot start the next cycle: both sides must be DONE")
        for role in (CLIENT, SERVER):
            st[role] = IDLE
            self._body_framing[role] = None
            self._remaining[role] = 0
            self._chunk_state[role] = "size"
            self._chunk_left[role] = 0
            self._chunk_fresh[role] = False
        self._request_method = None
        self._ka_disabled = False
        self._connect_proposal = False
        self._upgrade_proposal = False
        self._waiting_100 = False
        return None

    def send_failed(self):
        """Record that the bytes from the last send were never transmitted."""
        self._state[self.our_role] = ERROR
        self._post()
        return None
