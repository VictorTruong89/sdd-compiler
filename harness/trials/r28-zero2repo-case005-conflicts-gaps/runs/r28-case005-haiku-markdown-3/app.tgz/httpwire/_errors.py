"""Protocol error classes for httpwire.

``LocalProtocolError`` means the integrator's own event or send broke HTTP.
``RemoteProtocolError`` means the peer's bytes broke HTTP. Neither is a
subclass of the other.
"""


class LocalProtocolError(Exception):
    """The integrator's event or send violated the HTTP/1.1 protocol."""

    def __init__(self, msg="", error_status_hint=400):
        super().__init__(msg)
        self.error_status_hint = int(error_status_hint)


class RemoteProtocolError(Exception):
    """The peer's bytes violated the HTTP/1.1 protocol."""

    def __init__(self, msg="", error_status_hint=400):
        super().__init__(msg)
        self.error_status_hint = int(error_status_hint)
