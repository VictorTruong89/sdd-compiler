"""HTTP event types and header-list normalization (PRD FP-01)."""

import re

from ._errors import LocalProtocolError

# RFC 7230 token characters (a header name or request method must match this).
_TOKEN = re.compile(rb"[!#$%&'*+\-.^_`|~0-9A-Za-z]+")
# Visible ASCII (request target).
_VCHAR = re.compile(rb"[\x21-\x7e]+")
# Bytes never allowed in a header value or reason phrase: NUL, other C0
# controls except tab (covers CR, LF, VT, FF), and DEL.
_BAD_VALUE = re.compile(rb"[\x00-\x08\x0a-\x1f\x7f]")
# Version: two single digits separated by a dot.
_VERSION = re.compile(rb"[0-9]\.[0-9]")
# Content-Length piece: 1 to 16 decimal digits (contract limit).
_CL_DIGITS = re.compile(rb"[0-9]{1,16}")

_OWS = b" \t"


def _to_bytes(value, what):
    if isinstance(value, bytes):
        return value
    if isinstance(value, str):
        try:
            return value.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("%s must be ASCII text or bytes" % what)
    if isinstance(value, (bytearray, memoryview)):
        return bytes(value)
    raise LocalProtocolError("%s must be text or a bytes-like object" % what)


def _check_version(value):
    version = _to_bytes(value, "HTTP version")
    if not _VERSION.fullmatch(version):
        raise LocalProtocolError("HTTP version must look like 1.1")
    return version


def _check_status(value, low, high):
    if isinstance(value, bool) or not isinstance(value, int):
        raise LocalProtocolError("status code must be an integer")
    code = int(value)
    if not (low <= code < high):
        raise LocalProtocolError("status code %d out of range" % code)
    return code


def _check_reason(value):
    reason = _to_bytes(value, "reason phrase")
    if _BAD_VALUE.search(reason):
        raise LocalProtocolError("reason phrase contains a forbidden byte")
    return reason


class Headers:
    """Ordered header list.

    Iterating or indexing yields ``(lowercase_name, value)`` byte pairs.
    ``raw_items()`` yields ``(name_as_spelled, value)`` byte pairs.
    """

    __slots__ = ("_items",)

    def __init__(self, items):
        # items: tuples of (raw_name, lower_name, value), all bytes
        self._items = tuple(items)

    def __iter__(self):
        for _raw, lower, value in self._items:
            yield (lower, value)

    def __len__(self):
        return len(self._items)

    def __getitem__(self, index):
        if isinstance(index, slice):
            return [(lower, value) for _raw, lower, value in self._items[index]]
        _raw, lower, value = self._items[index]
        return (lower, value)

    def raw_items(self):
        return [(raw, value) for raw, _lower, value in self._items]

    def __eq__(self, other):
        try:
            return list(self) == list(other)
        except TypeError:
            return NotImplemented

    __hash__ = None

    def __repr__(self):
        return "Headers(%r)" % (list(self),)


def _normalize_headers(pairs):
    """Validate and normalize a sequence of (name, value) pairs.

    Raises LocalProtocolError on any refusal. Used for construction and for
    headers parsed from the peer (the caller converts the error).
    """
    items = []
    try:
        iterator = iter(pairs)
    except TypeError:
        raise LocalProtocolError("headers must be a sequence of (name, value) pairs")
    for pair in iterator:
        try:
            name, value = pair
        except (TypeError, ValueError):
            raise LocalProtocolError("each header must be a (name, value) pair")
        name = _to_bytes(name, "header name")
        value = _to_bytes(value, "header value")
        if not _TOKEN.fullmatch(name):
            raise LocalProtocolError("header name is not a token: %r" % (name,))
        if _BAD_VALUE.search(value):
            raise LocalProtocolError("header value contains a forbidden byte")
        if value[:1] in (b" ", b"\t") or value[-1:] in (b" ", b"\t"):
            raise LocalProtocolError("header value begins or ends with space or tab")
        items.append((name, name.lower(), value))

    # Content-Length: equal repeated values collapse; differing values refused.
    cl_positions = [i for i, item in enumerate(items) if item[1] == b"content-length"]
    if cl_positions:
        numbers = set()
        for i in cl_positions:
            for piece in items[i][2].split(b","):
                piece = piece.strip(_OWS)
                if not _CL_DIGITS.fullmatch(piece):
                    raise LocalProtocolError("Content-Length must be a decimal integer")
                numbers.add(int(piece.decode("ascii")))
        if len(numbers) > 1:
            raise LocalProtocolError("conflicting Content-Length values")
        length = str(numbers.pop()).encode("ascii")
        rebuilt = []
        placed = False
        for raw, lower, value in items:
            if lower == b"content-length":
                if not placed:
                    rebuilt.append((b"Content-Length", b"content-length", length))
                    placed = True
            else:
                rebuilt.append((raw, lower, value))
        items = rebuilt

    # Transfer-Encoding: exactly one header, whose value is exactly chunked.
    te_positions = [i for i, item in enumerate(items) if item[1] == b"transfer-encoding"]
    if len(te_positions) > 1:
        raise LocalProtocolError("multiple Transfer-Encoding headers", 501)
    if te_positions:
        i = te_positions[0]
        raw, lower, value = items[i]
        if value.strip(_OWS).lower() != b"chunked":
            raise LocalProtocolError("unsupported Transfer-Encoding", 501)
        items[i] = (raw, lower, b"chunked")

    return Headers(items)


def _check_host(headers, version):
    hosts = sum(1 for lower, _value in headers if lower == b"host")
    if hosts > 1:
        raise LocalProtocolError("more than one Host header")
    if version == b"1.1" and hosts == 0:
        raise LocalProtocolError("HTTP/1.1 request requires a Host header")


class Request:
    """An HTTP request start: method, target, headers, version."""

    def __init__(self, method, target, headers, http_version=b"1.1"):
        self.method = _to_bytes(method, "method")
        if not _TOKEN.fullmatch(self.method):
            raise LocalProtocolError("method must be a single token")
        self.target = _to_bytes(target, "target")
        if not _VCHAR.fullmatch(self.target):
            raise LocalProtocolError("target must be visible ASCII")
        self.http_version = _check_version(http_version)
        self.headers = _normalize_headers(headers)
        _check_host(self.headers, self.http_version)

    def __repr__(self):
        return "Request(method=%r, target=%r, headers=%r, http_version=%r)" % (
            self.method, self.target, list(self.headers), self.http_version)


class InformationalResponse:
    """A 1xx response start."""

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        self.status_code = _check_status(status_code, 100, 200)
        self.headers = _normalize_headers(headers)
        self.http_version = _check_version(http_version)
        self.reason = _check_reason(reason)

    def __repr__(self):
        return "InformationalResponse(status_code=%d, headers=%r)" % (
            self.status_code, list(self.headers))


class Response:
    """A final (2xx-9xx) response start."""

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        self.status_code = _check_status(status_code, 200, 1000)
        self.headers = _normalize_headers(headers)
        self.http_version = _check_version(http_version)
        self.reason = _check_reason(reason)

    def __repr__(self):
        return "Response(status_code=%d, headers=%r)" % (
            self.status_code, list(self.headers))


class Data:
    """A piece of a message body."""

    def __init__(self, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)

    def __repr__(self):
        return "Data(data=%r, chunk_start=%r, chunk_end=%r)" % (
            self.data, self.chunk_start, self.chunk_end)


class EndOfMessage:
    """The end of a message, with optional trailing headers."""

    def __init__(self, headers=None):
        self.headers = _normalize_headers(() if headers is None else headers)

    def __repr__(self):
        return "EndOfMessage(headers=%r)" % (list(self.headers),)


class ConnectionClosed:
    """The sending side of this conversation will send no more data."""

    def __repr__(self):
        return "ConnectionClosed()"
