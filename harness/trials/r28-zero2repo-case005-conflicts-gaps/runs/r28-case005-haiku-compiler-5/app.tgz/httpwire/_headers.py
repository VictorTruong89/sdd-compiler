"""Header list container and normalization (FP-01)."""

import re

from ._errors import LocalProtocolError

# RFC 7230 token characters
_TOKEN_RE = re.compile(rb"^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$")
_CL_DIGITS_RE = re.compile(rb"^[0-9]+$")
# spec: N-000114 - N-000119: maximum Content-Length digit count (implementer's choice, 18..32)
MAX_CONTENT_LENGTH_DIGITS = 18
_FORBIDDEN_VALUE_BYTES = frozenset(b"\x00\r\n\x0b\x0c")


def _to_bytes(value, what):
    if isinstance(value, bytes):
        return value
    if isinstance(value, str):
        try:
            return value.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("%s must be ASCII text" % what)
    if isinstance(value, (bytearray, memoryview)):
        return bytes(value)
    raise LocalProtocolError("%s must be bytes or ASCII str" % what)


class Headers:
    """Ordered header list. Iteration yields lowercased (name, value) bytes pairs;
    raw_items() yields names exactly as the caller spelled them."""

    __slots__ = ("_raw",)

    def __init__(self, raw):
        self._raw = tuple(raw)

    def __iter__(self):
        return iter(self.__getitem_all())

    def __getitem_all(self):
        return [(n.lower(), v) for (n, v) in self._raw]

    def __getitem__(self, idx):
        return self.__getitem_all()[idx]

    def __len__(self):
        return len(self._raw)

    def __eq__(self, other):
        if isinstance(other, Headers):
            return self.__getitem_all() == other.__getitem_all()
        try:
            return self.__getitem_all() == list(other)
        except TypeError:
            return NotImplemented

    def __repr__(self):
        return "Headers(%r)" % (self.__getitem_all(),)

    def raw_items(self):
        return list(self._raw)

    def get_all(self, lname):
        return [v for (n, v) in self.__getitem_all() if n == lname]


def normalize_headers(items):
    """Validate and normalize a sequence of (name, value) pairs.

    Returns a Headers object. Raises LocalProtocolError on invalid input.
    """
    out = []
    for item in items:
        try:
            name, value = item
        except (TypeError, ValueError):
            raise LocalProtocolError("header must be a (name, value) pair")
        name = _to_bytes(name, "header name")
        value = _to_bytes(value, "header value")
        if not _TOKEN_RE.match(name):
            raise LocalProtocolError("invalid header name %r" % (name,))
        _check_value(value)
        out.append((name, value))
    return normalize_framing(out)


def _check_value(value):
    if value[:1] in (b" ", b"\t") or value[-1:] in (b" ", b"\t"):
        raise LocalProtocolError("header value may not start or end with space/tab")
    for b in value:
        if b in _FORBIDDEN_VALUE_BYTES:
            raise LocalProtocolError("forbidden byte in header value")
        # spec: N-000108 - control bytes other than tab are refused (resolves CF-000026 toward refusal)
        if b < 0x20 and b != 0x09:
            raise LocalProtocolError("control byte in header value")
        if b == 0x7F:
            raise LocalProtocolError("DEL byte in header value")


def normalize_framing(pairs):
    """Collapse/validate Content-Length and Transfer-Encoding (FP-01, N-000092..N-000096, N-000114..N-000121).

    Returns Headers with at most one content-length and at most one transfer-encoding.
    """
    lengths = []
    te_count = 0
    other = []
    for name, value in pairs:
        lname = name.lower()
        if lname == b"content-length":
            for piece in value.split(b","):
                piece = piece.strip(b" \t")
                if not _CL_DIGITS_RE.match(piece):
                    raise LocalProtocolError("invalid Content-Length")
                if len(piece) > MAX_CONTENT_LENGTH_DIGITS:
                    raise LocalProtocolError("Content-Length too long")
                lengths.append(int(piece))
        elif lname == b"transfer-encoding":
            te_count += 1
            other.append((name, value))
        else:
            other.append((name, value))

    if lengths and len(set(lengths)) > 1:
        raise LocalProtocolError("conflicting Content-Length values")
    if te_count > 1:
        err = LocalProtocolError("multiple Transfer-Encoding headers")
        err.error_status_hint = 501
        raise err
    if te_count == 1:
        te_val = [v for (n, v) in other if n.lower() == b"transfer-encoding"][0]
        if te_val.strip(b" \t").lower() != b"chunked":
            err = LocalProtocolError("unsupported Transfer-Encoding")
            err.error_status_hint = 501
            raise err

    result = []
    cl_done = False
    te_done = False
    for name, value in other:
        lname = name.lower()
        if lname == b"transfer-encoding":
            if not te_done:
                result.append((b"transfer-encoding", b"chunked"))
                te_done = True
        else:
            result.append((name, value))
    if lengths:
        result.append((b"content-length", str(lengths[0]).encode("ascii")))
        cl_done = True
    return Headers(_keep_raw(pairs, result, cl_done, te_done))


def _keep_raw(orig_pairs, normalized, cl_done, te_done):
    """Build the raw-items list: original spelling for kept headers, and the
    normalized spelling for the collapsed framing headers."""
    raw = []
    for name, value in normalized:
        if name == b"transfer-encoding":
            raw.append((b"Transfer-Encoding", b"chunked"))
        elif name == b"content-length":
            raw.append((b"Content-Length", value))
        else:
            # keep original casing of the first occurrence of this name
            orig = next((n for (n, _v) in orig_pairs if n.lower() == name), name)
            raw.append((orig, value))
    return raw
