"""The six event types (FP-01, Interface Contract > Events)."""

import re

from ._errors import LocalProtocolError
from ._headers import _TOKEN_RE, _to_bytes, normalize_headers

_VERSION_RE = re.compile(rb"^[0-9]\.[0-9]$")
_TARGET_RE = re.compile(rb"^[\x21-\x7e]+$")


def _version(value):
    v = _to_bytes(value, "http_version")
    if not _VERSION_RE.match(v):
        raise LocalProtocolError("invalid HTTP version")
    return v


def _check_status(status_code, lo, hi):
    if isinstance(status_code, bool) or not isinstance(status_code, int):
        raise LocalProtocolError("status_code must be an integer")
    code = int(status_code)
    if not (lo <= code < hi):
        raise LocalProtocolError("status_code out of range for this event kind")
    return code


class Event:
    __slots__ = ()


class Request(Event):
    __slots__ = ("method", "target", "headers", "http_version")

    def __init__(self, *, method, target, headers, http_version=b"1.1"):
        method = _to_bytes(method, "method")
        if not _TOKEN_RE.match(method):
            raise LocalProtocolError("method must be a token")
        target = _to_bytes(target, "target")
        if not _TARGET_RE.match(target):
            raise LocalProtocolError("target must be visible ASCII")
        version = _version(http_version)
        headers = normalize_headers(headers)
        hosts = headers.get_all(b"host")
        if len(hosts) > 1:
            raise LocalProtocolError("more than one Host header")
        if version == b"1.1" and len(hosts) != 1:
            raise LocalProtocolError("HTTP/1.1 request requires exactly one Host header")
        self.method = method
        self.target = target
        self.headers = headers
        self.http_version = version

    def __repr__(self):
        return "Request(method=%r, target=%r, headers=%r, http_version=%r)" % (
            self.method, self.target, self.headers, self.http_version)


class _Response(Event):
    __slots__ = ("status_code", "headers", "http_version", "reason")
    _LO = 0
    _HI = 0

    def __init__(self, *, status_code, headers, http_version=b"1.1", reason=b""):
        self.status_code = _check_status(status_code, self._LO, self._HI)
        self.headers = normalize_headers(headers)
        self.http_version = _version(http_version)
        reason = _to_bytes(reason, "reason")
        if b"\r" in reason or b"\n" in reason:
            raise LocalProtocolError("reason may not contain CR or LF")
        self.reason = reason

    def __repr__(self):
        return "%s(status_code=%r, headers=%r, http_version=%r, reason=%r)" % (
            type(self).__name__, self.status_code, self.headers, self.http_version, self.reason)


class InformationalResponse(_Response):
    __slots__ = ()
    _LO = 100
    _HI = 200


class Response(_Response):
    __slots__ = ()
    _LO = 200
    _HI = 1000


class Data(Event):
    __slots__ = ("data", "chunk_start", "chunk_end")

    def __init__(self, *, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)

    def __repr__(self):
        return "Data(data=%r, chunk_start=%r, chunk_end=%r)" % (
            self.data, self.chunk_start, self.chunk_end)


class EndOfMessage(Event):
    __slots__ = ("headers",)

    def __init__(self, *, headers=()):
        self.headers = normalize_headers(headers)

    def __repr__(self):
        return "EndOfMessage(headers=%r)" % (self.headers,)


class ConnectionClosed(Event):
    __slots__ = ()

    def __init__(self):
        pass

    def __repr__(self):
        return "ConnectionClosed()"
