"""Protocol error classes (FP-05, Interface Contract > Errors)."""


class ProtocolError(Exception):
    """Base for local and remote protocol errors."""

    error_status_hint = 400

    def __init__(self, message="", error_status_hint=None):
        super().__init__(message)
        if error_status_hint is not None:
            self.error_status_hint = error_status_hint


class LocalProtocolError(ProtocolError):
    """Protocol violation caused by the integrator's own event or send."""


class RemoteProtocolError(ProtocolError):
    """Protocol violation caused by the peer's bytes."""


class BytesAfterEndOfReceive(RuntimeError):
    """Non-empty bytes fed after the receive side was closed.

    spec: N-000180..N-000182 - a runtime error, neither a local nor a remote protocol error.
    """
