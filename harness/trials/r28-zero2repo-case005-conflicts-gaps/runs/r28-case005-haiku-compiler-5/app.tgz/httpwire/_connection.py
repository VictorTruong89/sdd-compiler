"""The Connection class: send side, shared state machine, and public accessors.

The receive side (parsing peer bytes) lives in _receive.py and is mixed in here.
"""

from ._errors import LocalProtocolError, RemoteProtocolError
from ._events import (
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    Request,
    Response,
)
from ._receive import _ReceiveMixin
from ._state import (
    CAN_CLOSE_FROM,
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
)

DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 8 * 1024  # spec: N-000479 (resolves CF-000048 toward 8 KiB)

_BYTES_LIKE = (bytes, bytearray, memoryview)


def _other(role):
    return SERVER if role is CLIENT else CLIENT


def _tokens(value):
    return [t.strip(b" \t").lower() for t in value.split(b",") if t.strip(b" \t")]


def _has_token(headers, lname, token):
    for v in headers.get_all(lname):
        if token in _tokens(v):
            return True
    return False


def _payload_len(data):
    if isinstance(data, _BYTES_LIKE):
        return memoryview(data).nbytes
    return len(data)


def _serialize_head(first_line, items):
    parts = [first_line]
    for name, value in items:
        parts.append(name + b": " + value + b"\r\n")
    parts.append(b"\r\n")
    return b"".join(parts)


class Connection(_ReceiveMixin):
    def __init__(self, role, max_incomplete_event_size=None):
        if role is not CLIENT and role is not SERVER:
            raise LocalProtocolError("role must be CLIENT or SERVER")
        if max_incomplete_event_size is None:
            max_incomplete_event_size = DEFAULT_MAX_INCOMPLETE_EVENT_SIZE
        if isinstance(max_incomplete_event_size, bool) or not isinstance(max_incomplete_event_size, int):
            raise LocalProtocolError("max_incomplete_event_size must be an int")
        self.our_role = role
        self.their_role = _other(role)
        self._states = {CLIENT: IDLE, SERVER: IDLE}
        self._max_incomplete = max_incomplete_event_size
        self._their_http_version = None
        self._keep_alive = True
        self._expect_100 = False
        # switch proposal bookkeeping (FP-07)
        self._connect_pending = False
        self._upgrade_pending = False
        # per-side bookkeeping for framing
        self._writer_mode = None  # 'cl' | 'chunked' | 'close' | 'empty'
        self._writer_remaining = 0
        self._our_request_method = None
        self._their_request_method = None
        self._init_receive()

    # ----- public accessors -------------------------------------------------

    @property
    def our_state(self):
        return self._states[self.our_role]

    @property
    def their_state(self):
        return self._states[self.their_role]

    @property
    def states(self):
        return dict(self._states)

    @property
    def their_http_version(self):
        return self._their_http_version

    @property
    def client_is_waiting_for_100_continue(self):
        return bool(self._expect_100)

    @property
    def they_are_waiting_for_100_continue(self):
        return bool(self._expect_100) and self.our_role is SERVER

    @property
    def trailing_data(self):
        return (bytes(self._buf), bool(self._receive_closed))

    # ----- state machine ----------------------------------------------------

    def _note_keep_alive(self, event):
        if event.http_version != b"1.1":
            self._keep_alive = False
        if _has_token(event.headers, b"connection", b"close"):
            self._keep_alive = False

    def _transition(self, role, event):
        """Apply the effect of one event produced by `role` (ours on send, theirs on pull)."""
        st = self._states
        other = _other(role)
        if isinstance(event, Request):
            self._note_keep_alive(event)
            st[CLIENT] = SEND_BODY
            st[SERVER] = SEND_RESPONSE
            self._connect_pending = event.method == b"CONNECT"
            self._upgrade_pending = bool(event.headers.get_all(b"upgrade"))
            self._expect_100 = (
                event.http_version == b"1.1"
                and any(b"100-continue" in _tokens(v) for v in event.headers.get_all(b"expect"))
            )
        elif isinstance(event, InformationalResponse):
            if self._upgrade_pending and event.status_code == 101:
                st[CLIENT] = SWITCHED_PROTOCOL
                st[SERVER] = SWITCHED_PROTOCOL
            else:
                self._expect_100 = False
        elif isinstance(event, Response):
            self._note_keep_alive(event)
            self._expect_100 = False
            accepted = (self._connect_pending and event.status_code == 200)
            self._connect_pending = False
            self._upgrade_pending = False
            if accepted:
                st[CLIENT] = SWITCHED_PROTOCOL
                st[SERVER] = SWITCHED_PROTOCOL
            else:
                st[SERVER] = SEND_BODY
                if st[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                    st[CLIENT] = DONE  # denial: HTTP/1.1 continues
        elif isinstance(event, Data):
            if role is CLIENT:
                self._expect_100 = False
        elif isinstance(event, EndOfMessage):
            if role is CLIENT:
                self._expect_100 = False
                if self._connect_pending or self._upgrade_pending:
                    st[CLIENT] = MIGHT_SWITCH_PROTOCOL
                else:
                    st[CLIENT] = DONE
            else:
                st[SERVER] = DONE
        elif isinstance(event, ConnectionClosed):
            st[role] = CLOSED
            if st[other] in (IDLE, DONE):
                st[other] = MUST_CLOSE
        self._settle()

    def _settle(self):
        st = self._states
        for role in (CLIENT, SERVER):
            if st[role] is DONE and not self._keep_alive:
                st[role] = MUST_CLOSE
        for role in (CLIENT, SERVER):
            if st[role] is ERROR and st[_other(role)] is DONE:
                st[_other(role)] = MUST_CLOSE
        if st[CLIENT] is CLOSED and st[SERVER] in (IDLE, DONE):
            st[SERVER] = MUST_CLOSE
        if st[SERVER] is CLOSED and st[CLIENT] in (IDLE, DONE):
            st[CLIENT] = MUST_CLOSE

    def _fail_send(self, message):
        """A send refused as a local protocol error: our side goes to ERROR (FP-05)."""
        self._states[self.our_role] = ERROR
        self._settle()
        raise LocalProtocolError(message)

    def _check_send_allowed(self, event):
        s = self.our_state
        if s is ERROR:
            raise LocalProtocolError("connection is in ERROR; sending is refused")
        if isinstance(event, Request):
            if self.our_role is not CLIENT:
                self._fail_send("server cannot send a request")
            if s is not IDLE:
                self._fail_send("a request may only be sent from IDLE")
            if event.http_version != b"1.1":
                self._fail_send("only HTTP/1.1 requests can be sent")
        elif isinstance(event, (InformationalResponse, Response)):
            if self.our_role is not SERVER:
                self._fail_send("client cannot send a response")
            if isinstance(event, InformationalResponse):
                if s is not SEND_RESPONSE:
                    self._fail_send("informational response only in SEND_RESPONSE")
            else:
                if s not in (IDLE, SEND_RESPONSE):
                    self._fail_send("response not allowed in this state")
            if event.http_version != b"1.1":
                self._fail_send("only HTTP/1.1 responses can be sent")
        elif isinstance(event, Data):
            if s is not SEND_BODY:
                self._fail_send("data only allowed in SEND_BODY")
        elif isinstance(event, EndOfMessage):
            if s is not SEND_BODY:
                self._fail_send("end-of-message only allowed in SEND_BODY")
        elif isinstance(event, ConnectionClosed):
            if s not in CAN_CLOSE_FROM:
                self._fail_send("connection-closed not allowed in this state")
        else:
            raise LocalProtocolError("not an event")

    # ----- framing on the send side -----------------------------------------

    def _frame_request(self, event):
        # Content-Length decides the framing of a request that carries both (N-000096)
        cl = event.headers.get_all(b"content-length")
        if cl:
            self._writer_mode, self._writer_remaining = "cl", int(cl[0])
        elif event.headers.get_all(b"transfer-encoding"):
            self._writer_mode, self._writer_remaining = "chunked", 0
        else:
            self._writer_mode, self._writer_remaining = "cl", 0

    def _serialize_request(self, event):
        items = list(event.headers.raw_items())
        hosts = [it for it in items if it[0].lower() == b"host"]
        others = [it for it in items if it[0].lower() != b"host"]
        first = event.method + b" " + event.target + b" HTTP/1.1\r\n"
        return _serialize_head(first, hosts + others)

    def _serialize_response(self, event):
        """Build the response head with the framing this peer requires (FP-03, FP-04)."""
        head_request = self._their_request_method == b"HEAD"
        peer_is_11 = self._their_http_version == b"1.1"
        status = event.status_code
        items = list(event.headers.raw_items())
        has_cl = bool(event.headers.get_all(b"content-length"))
        has_te = bool(event.headers.get_all(b"transfer-encoding"))
        cl_value = int(event.headers.get_all(b"content-length")[0]) if has_cl else 0

        if status in (204, 304) or head_request:
            # Empty-body responses (FP-03): headers as for GET; for 204/304 framing headers
            # are dropped. A Content-Length: 0 is never sent for an empty body.
            if status in (204, 304):
                items = [it for it in items if it[0].lower() not in (b"content-length", b"transfer-encoding")]
            elif has_cl and cl_value == 0:
                items = [it for it in items if it[0].lower() != b"content-length"]
            self._writer_mode, self._writer_remaining = "empty", 0
            if status not in (204, 304):
                # HEAD keeps the framing headers GET would use (N-000219)
                if not has_cl and not has_te and peer_is_11:
                    items.append((b"Transfer-Encoding", b"chunked"))
                elif has_te and not peer_is_11:
                    items = [it for it in items if it[0].lower() != b"transfer-encoding"]
                # close framing for a 1.0 peer adds no header
            mode = "empty"
        else:
            if has_te:
                # Transfer-Encoding wins over Content-Length (FP-01/FP-03, resolves CF-000003 toward FP-03)
                items = [it for it in items if it[0].lower() != b"content-length"]
                if peer_is_11:
                    mode, self._writer_remaining = "chunked", 0
                else:
                    items = [it for it in items if it[0].lower() != b"transfer-encoding"]
                    mode, self._writer_remaining = "close", 0
            elif has_cl:
                mode, self._writer_remaining = "cl", cl_value
            elif peer_is_11:
                items.append((b"Transfer-Encoding", b"chunked"))
                mode, self._writer_remaining = "chunked", 0
            else:
                mode, self._writer_remaining = "close", 0
        self._writer_mode = mode

        keep = self._keep_alive and mode != "close" and not _has_token(event.headers, b"connection", b"close")
        if not keep:
            items = self._with_connection_close(items)
            self._keep_alive = False
        first = b"HTTP/1.1 %d " % status + event.reason + b"\r\n"
        return _serialize_head(first, items)

    @staticmethod
    def _with_connection_close(items):
        kept = []
        tokens = []
        for name, value in items:
            if name.lower() == b"connection":
                tokens.extend(t for t in _tokens(value) if t != b"keep-alive")
            else:
                kept.append((name, value))
        if b"close" not in tokens:
            tokens.append(b"close")
        return [(b"Connection", b", ".join(tokens))] + kept

    def _encode_data(self, event):
        """Return a list of pieces for a Data event; passthrough objects are kept by identity."""
        data = event.data
        n = _payload_len(data)
        mode = self._writer_mode
        if mode == "cl":
            if n > self._writer_remaining:
                self._fail_send("data exceeds the declared Content-Length")
            self._writer_remaining -= n
            return [data] if n else []
        if mode == "chunked":
            if not n:
                return []
            head = b"%x\r\n" % n
            if isinstance(data, _BYTES_LIKE):
                return [head, bytes(data), b"\r\n"]
            return [head, data, b"\r\n"]
        if mode == "close":
            return [data] if n else []
        # 'empty' bodies carry no data at all
        if n:
            self._fail_send("this response has an empty body")
        return []

    def _encode_end(self, event):
        mode = self._writer_mode
        trailers = event.headers
        if mode == "cl":
            if self._writer_remaining:
                self._fail_send("end-of-message before the declared Content-Length was sent")
            if len(trailers):
                self._fail_send("trailing headers are not allowed with Content-Length framing")
            return []
        if mode == "chunked":
            lines = [b"0\r\n"]
            for name, value in trailers.raw_items():
                lines.append(name + b": " + value + b"\r\n")
            lines.append(b"\r\n")
            return lines
        if len(trailers):
            self._fail_send("trailing headers are not allowed without chunked framing")
        return []

    def _encode(self, event):
        """Validate, encode, and apply the state change for one event. Returns a piece list."""
        self._check_send_allowed(event)
        pieces = []
        if isinstance(event, Request):
            self._frame_request(event)
            self._our_request_method = event.method
            pieces = [self._serialize_request(event)]
        elif isinstance(event, (InformationalResponse, Response)):
            if isinstance(event, InformationalResponse):
                self._writer_mode, self._writer_remaining = None, 0
                pieces = [self._serialize_informational(event)]
            else:
                pieces = [self._serialize_response(event)]
        elif isinstance(event, Data):
            pieces = self._encode_data(event)
        elif isinstance(event, EndOfMessage):
            pieces = self._encode_end(event)
        elif isinstance(event, ConnectionClosed):
            pieces = []
        self._transition(self.our_role, event)
        return pieces

    def _serialize_informational(self, event):
        if event.http_version != b"1.1":
            self._fail_send("only HTTP/1.1 responses can be sent")
        first = b"HTTP/1.1 %d " % event.status_code + event.reason + b"\r\n"
        return _serialize_head(first, list(event.headers.raw_items()))

    # ----- public send operations -------------------------------------------

    def send(self, event):
        pieces = self._encode(event)
        if not pieces:
            return b""
        if len(pieces) == 1 and isinstance(pieces[0], bytes):
            return pieces[0]
        return b"".join(pieces)

    def send_with_data_passthrough(self, event):
        # Passthrough: a caller-supplied non-bytes payload is kept by identity as one piece.
        return self._encode(event)

    def start_next_cycle(self):
        if self._states[CLIENT] is not DONE or self._states[SERVER] is not DONE:
            raise LocalProtocolError("next cycle can only start when both sides are DONE")
        self._states[CLIENT] = IDLE
        self._states[SERVER] = IDLE
        self._keep_alive = True
        self._expect_100 = False
        self._connect_pending = False
        self._upgrade_pending = False
        self._writer_mode = None
        self._writer_remaining = 0
        self._our_request_method = None
        self._their_request_method = None
        self._reset_reader()

    def send_failed(self):
        self._states[self.our_role] = ERROR
        self._settle()
        return None
