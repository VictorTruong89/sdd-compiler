"""Receive side: storing peer bytes and pulling events (FP-02..FP-07).

Mixed into Connection; relies on its state machine (_transition, _settle) and
on the attributes it sets up in Connection.__init__.
"""

import re

from ._errors import BytesAfterEndOfReceive, LocalProtocolError, RemoteProtocolError
from ._events import (
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    Request,
    Response,
)
from ._headers import _TOKEN_RE
from ._state import (
    CAN_CLOSE_FROM,
    CLIENT,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SWITCHED_PROTOCOL,
    CLOSED,
)

# spec: N-000228..N-000232 chunk-size digit limit (implementer's choice, 16..32).
# N-000192 says "up to 64"; that conflicts with the 16..32 rule, so 32 is used (see NOTES.md).
MAX_CHUNK_SIZE_DIGITS = 32
_CHUNK_SIZE_RE = re.compile(rb"^([0-9A-Fa-f]{1,32})(?:;[^\r\n]*?[ \t]*)?$")
_VERSION_RE = re.compile(rb"^HTTP/(1\.[01])$")
_STATUS_RE = re.compile(rb"^[0-9]{3}$")


class _ReceiveMixin:
    def _init_receive(self):
        self._buf = bytearray()
        self._receive_closed = False
        self._reset_reader()

    def _reset_reader(self):
        self._reader = None  # None | ('cl', remaining) | ('chunked', substate, remaining) | ('close',)
        self._chunk_started = False

    # ----- feeding ----------------------------------------------------------

    def receive_data(self, data):
        if data is None:
            data = b""
        chunk = bytes(data)
        if not chunk:
            self._receive_closed = True
            return None
        if self._receive_closed:
            raise BytesAfterEndOfReceive("bytes fed after the receive side was closed")
        self._buf += chunk
        return None

    # ----- errors -----------------------------------------------------------

    def _remote_error(self, message, hint=None):
        """Peer bytes violated the protocol: their side goes to ERROR, ours does not (FP-05)."""
        self._states[self.their_role] = ERROR
        # the peer can no longer be kept alive, so our next response carries Connection: close (FP-05)
        self._keep_alive = False
        self._settle()
        raise RemoteProtocolError(message, error_status_hint=hint)

    def _as_remote(self, exc):
        """Convert a local construction failure from parsed peer bytes into a remote error."""
        hint = getattr(exc, "error_status_hint", None)
        self._remote_error(str(exc), hint if hint is not None and hint != 400 else None)

    # ----- pulling ----------------------------------------------------------

    def next_event(self):
        st = self.their_state
        if st is ERROR:
            self._remote_error_no_state("connection is in ERROR; receiving is refused")
        if st is SWITCHED_PROTOCOL:
            return PAUSED
        if st is CLOSED:
            return ConnectionClosed()
        if st is MIGHT_SWITCH_PROTOCOL:
            return PAUSED
        if st in (DONE, MUST_CLOSE):
            if self._buf:
                return PAUSED
            if self._receive_closed:
                return self._emit_closed()
            return NEED_DATA
        if st is SEND_BODY:
            event = self._pull_body()
            if isinstance(event, Data):
                self._transition(self.their_role, event)
            return event
        if st in (IDLE, SEND_RESPONSE):
            return self._pull_head()
        return NEED_DATA

    def _remote_error_no_state(self, message):
        raise RemoteProtocolError(message)

    def _emit_closed(self):
        if self.their_state not in CAN_CLOSE_FROM:
            self._remote_error("peer closed while it is not allowed to close")
        event = ConnectionClosed()
        self._transition(self.their_role, event)
        return event

    # head (request line / status line + headers)

    def _split_head(self):
        """Return (lines, consumed) for a complete head block, or None.

        Lines may end in CRLF or a lone LF (N-000165, resolving CF-000074 toward acceptance).
        """
        pos = 0
        lines = []
        buf = self._buf
        while True:
            nl = buf.find(b"\n", pos)
            if nl < 0:
                return None
            line = bytes(buf[pos:nl])
            if line.endswith(b"\r"):
                line = line[:-1]
            pos = nl + 1
            if not line:
                return lines, pos
            lines.append(line)

    def _pull_head(self):
        buf = self._buf
        if not buf:
            if self._receive_closed:
                if self.their_state is IDLE:
                    return self._emit_closed()
                self._remote_error("peer closed while a response was expected")
            return NEED_DATA
        first = buf[0]
        if first == 0x20 or first < 33:
            self._remote_error("message starts with a space or control byte")
        split = self._split_head()
        if split is None:
            if self._receive_closed:
                self._remote_error("peer closed in the middle of a header block")
            if len(buf) > self._max_incomplete:
                self._remote_error("incomplete event exceeds the size limit", hint=431)
            return NEED_DATA
        lines, consumed = split
        del buf[:consumed]
        if not lines:
            self._remote_error("empty start line")
        start = lines[0]
        fields = self._parse_fields(lines[1:])

        if self.our_role is not CLIENT:
            # we are the server: their state IDLE, expecting a request
            method, target, version = self._parse_request_line(start)
            try:
                event = Request(method=method, target=target, headers=fields, http_version=version)
            except LocalProtocolError as exc:
                self._as_remote(exc)
            self._their_http_version = version
            self._their_request_method = method
            self._transition(self.their_role, event)
            self._set_request_reader(event)
            return event

        # we are the client: expecting a status line (possibly unsolicited)
        version, code, reason = self._parse_status_line(start)
        try:
            if code < 200:
                event = InformationalResponse(status_code=code, headers=fields, http_version=version, reason=reason)
            else:
                event = Response(status_code=code, headers=fields, http_version=version, reason=reason)
        except LocalProtocolError as exc:
            self._as_remote(exc)
        self._their_http_version = version
        self._transition(self.their_role, event)
        if isinstance(event, Response):
            self._set_response_reader(event)
        return event

    def _parse_fields(self, lines):
        fields = []
        for line in lines:
            if line[:1] in (b" ", b"\t"):
                self._remote_error("obsolete line folding is refused")
            name, sep, value = line.partition(b":")
            if not sep:
                self._remote_error("header line without a colon")
            if not _TOKEN_RE.match(name):
                self._remote_error("invalid header name")
            fields.append((name, value.strip(b" \t")))
        return fields

    def _parse_request_line(self, line):
        parts = line.split(b" ")
        if len(parts) != 3:
            self._remote_error("malformed request line")
        method, target, version = parts
        m = _VERSION_RE.match(version)
        if not m:
            self._remote_error("unsupported HTTP version")
        return method, target, m.group(1)

    def _parse_status_line(self, line):
        parts = line.split(b" ", 2)
        if len(parts) < 2:
            self._remote_error("malformed status line")
        m = _VERSION_RE.match(parts[0])
        if not m:
            self._remote_error("unsupported HTTP version")
        if not _STATUS_RE.match(parts[1]):
            self._remote_error("malformed status code")
        reason = parts[2] if len(parts) == 3 else b""  # N-000166, resolving CF-000005 toward acceptance
        return m.group(1), int(parts[1]), reason

    # body framing on the receive side

    def _set_request_reader(self, event):
        if event.headers.get_all(b"content-length"):
            self._reader = ("cl", int(event.headers.get_all(b"content-length")[0]))
        elif event.headers.get_all(b"transfer-encoding"):
            self._reader = ("chunked", "size", 0)
        else:
            self._reader = ("cl", 0)

    def _set_response_reader(self, event):
        status = event.status_code
        if status in (204, 304) or self._our_request_method == b"HEAD":
            self._reader = ("cl", 0)
        elif event.headers.get_all(b"transfer-encoding"):
            self._reader = ("chunked", "size", 0)
        elif event.headers.get_all(b"content-length"):
            self._reader = ("cl", int(event.headers.get_all(b"content-length")[0]))
        else:
            # close-delimited: the body runs until the receive side closes; the connection must close
            self._reader = ("close",)
            self._keep_alive = False
            self._settle()

    def _pull_body(self):
        reader = self._reader
        buf = self._buf
        if reader is None:
            self._remote_error("no body framing for this message")
        kind = reader[0]

        if kind == "cl":
            remaining = reader[1]
            if remaining == 0:
                return self._emit_end(EndOfMessage())
            if not buf:
                if self._receive_closed:
                    self._remote_error("peer closed in the middle of a Content-Length body")
                return NEED_DATA
            n = min(remaining, len(buf))
            piece = bytes(buf[:n])
            del buf[:n]
            self._reader = ("cl", remaining - n)
            return Data(data=piece)

        if kind == "close":
            if buf:
                piece = bytes(buf)
                del buf[:]
                return Data(data=piece)
            if self._receive_closed:
                return self._emit_end(EndOfMessage())
            return NEED_DATA

        # chunked
        substate, remaining = reader[1], reader[2]
        if substate == "size":
            nl = buf.find(b"\n")
            if nl < 0:
                if self._receive_closed:
                    self._remote_error("peer closed in the middle of a chunk-size line")
                if len(buf) > self._max_incomplete:
                    self._remote_error("chunk-size line exceeds the size limit", hint=431)
                return NEED_DATA
            line = bytes(buf[:nl])
            if line.endswith(b"\r"):
                line = line[:-1]
            m = _CHUNK_SIZE_RE.match(line)
            if not m:
                self._remote_error("malformed chunk-size line")
            del buf[:nl + 1]
            size = int(m.group(1), 16)
            if size == 0:
                self._reader = ("chunked", "trailers", 0)
                return self._pull_trailers()
            self._reader = ("chunked", "data", size)
            self._chunk_started = False
            return self._pull_body()

        if substate == "data":
            if not buf:
                if self._receive_closed:
                    self._remote_error("peer closed in the middle of a chunk")
                return NEED_DATA
            n = min(remaining, len(buf))
            piece = bytes(buf[:n])
            del buf[:n]
            remaining -= n
            start = not self._chunk_started
            self._chunk_started = True
            end = remaining == 0
            self._reader = ("chunked", "crlf", 0) if end else ("chunked", "data", remaining)
            return Data(data=piece, chunk_start=start, chunk_end=end)

        if substate == "crlf":
            if buf[:2] == b"\r\n":
                del buf[:2]
                self._reader = ("chunked", "size", 0)
                return self._pull_body()
            if len(buf) >= 2 or (buf and buf[:1] != b"\r"):
                self._remote_error("chunk data not followed by CRLF")
            if self._receive_closed:
                self._remote_error("peer closed in the middle of a chunk")
            return NEED_DATA

        # trailers
        return self._pull_trailers()

    def _pull_trailers(self):
        buf = self._buf
        split = self._split_head()
        if split is None:
            if self._receive_closed:
                self._remote_error("peer closed in the middle of trailing headers")
            if len(buf) > self._max_incomplete:
                self._remote_error("trailing header block exceeds the size limit", hint=431)
            return NEED_DATA
        lines, consumed = split
        del buf[:consumed]
        fields = self._parse_fields(lines)
        try:
            event = EndOfMessage(headers=fields)
        except LocalProtocolError as exc:
            self._as_remote(exc)
        return self._emit_end(event)

    def _emit_end(self, event):
        self._reader = None
        self._transition(self.their_role, event)
        return event
