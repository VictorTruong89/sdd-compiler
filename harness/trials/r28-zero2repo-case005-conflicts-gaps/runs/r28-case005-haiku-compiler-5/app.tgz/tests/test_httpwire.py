"""Tests for httpwire. Test names follow the spec's FP / claim areas (see spec/CHECKLIST.md)."""

import os
import sys

import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import httpwire as h  # noqa: E402


def _pair():
    return h.Connection(h.CLIENT), h.Connection(h.SERVER)


def _pull_all(conn):
    out = []
    while True:
        ev = conn.next_event()
        if ev is h.NEED_DATA or ev is h.PAUSED:
            return out, ev
        out.append(ev)


# ---- FP-01: events and header normalization (N-000070..N-000121) -----------

def test_request_default_version_and_bytes_storage():
    r = h.Request(method="GET", target="/x", headers=[("Host", "a")])
    assert r.http_version == b"1.1"
    assert r.method == b"GET" and isinstance(r.target, bytes)
    assert r.headers == [(b"host", b"a")]
    assert r.headers.raw_items() == [(b"Host", b"a")]


def test_http11_request_requires_single_host():
    with pytest.raises(h.LocalProtocolError):
        h.Request(method="GET", target="/", headers=[])
    with pytest.raises(h.LocalProtocolError):
        h.Request(method="GET", target="/", headers=[("host", "a"), ("Host", "b")])
    h.Request(method="GET", target="/", headers=[], http_version=b"1.0")


def test_status_ranges_and_defaults():
    r = h.InformationalResponse(status_code=101, headers=[])
    assert r.http_version == b"1.1" and r.reason == b""
    with pytest.raises(h.LocalProtocolError):
        h.InformationalResponse(status_code=200, headers=[])
    with pytest.raises(h.LocalProtocolError):
        h.Response(status_code=199, headers=[])
    with pytest.raises(h.LocalProtocolError):
        h.Response(status_code="200", headers=[])


def test_content_length_and_transfer_encoding_normalization():
    r = h.Response(status_code=200, headers=[("Content-Length", "5"), ("content-length", "5, 5")])
    assert r.headers.get_all(b"content-length") == [b"5"]
    with pytest.raises(h.LocalProtocolError):
        h.Response(status_code=200, headers=[("Content-Length", "5"), ("Content-Length", "6")])
    with pytest.raises(h.LocalProtocolError):
        h.Response(status_code=200, headers=[("Content-Length", "1" * 40)])
    r = h.Response(status_code=200, headers=[("Transfer-Encoding", "CHUNKED")])
    assert r.headers.get_all(b"transfer-encoding") == [b"chunked"]
    for bad in ("gzip", "gzip, chunked"):
        with pytest.raises(h.LocalProtocolError) as ei:
            h.Response(status_code=200, headers=[("Transfer-Encoding", bad)])
        assert ei.value.error_status_hint == 501
    with pytest.raises(h.LocalProtocolError) as ei:
        h.Response(status_code=200, headers=[("Transfer-Encoding", "chunked"), ("Transfer-Encoding", "chunked")])
    assert ei.value.error_status_hint == 501


def test_header_value_rules():
    with pytest.raises(h.LocalProtocolError):
        h.Response(status_code=200, headers=[("X", " lead")])
    with pytest.raises(h.LocalProtocolError):
        h.Response(status_code=200, headers=[("X", "a\x01b")])
    with pytest.raises(h.LocalProtocolError):
        h.Response(status_code=200, headers=[("bad name", "v")])


def test_data_chunk_marks_and_constructor_defaults():
    d = h.Data(data=b"x")
    assert d.chunk_start is False and d.chunk_end is False
    assert h.ConnectionClosed() is not None
    assert h.EndOfMessage().headers == []


def test_invalid_construction_is_recoverable():
    with pytest.raises(h.LocalProtocolError):
        h.Request(method="G E", target="/", headers=[("Host", "a")])
    c, _ = _pair()
    c.send(h.Request(method="GET", target="/", headers=[("Host", "a")]))
    assert c.our_state is h.SEND_BODY


# ---- FP-02: connection basics -------------------------------------------

def test_roles_and_initial_states():
    c, s = _pair()
    assert c.our_state is h.IDLE and s.their_state is h.IDLE
    assert c.their_role is h.SERVER and s.our_role is h.SERVER
    assert c.states[h.CLIENT] is h.IDLE and c.states[h.SERVER] is h.IDLE


def test_bad_role_refused():
    with pytest.raises(h.LocalProtocolError):
        h.Connection("client")


def test_pull_on_empty_returns_need_data():
    _, s = _pair()
    assert s.next_event() is h.NEED_DATA


def test_request_round_trip_and_host_first():
    c, s = _pair()
    raw = c.send(h.Request(method="POST", target="/p", headers=[("X-A", "1"), ("Host", "h"),
                                                                  ("Content-Length", "2")]))
    assert raw == b"POST /p HTTP/1.1\r\nHost: h\r\nX-A: 1\r\nContent-Length: 2\r\n\r\n"
    assert c.our_state is h.SEND_BODY and c.their_http_version is None
    s.receive_data(raw)
    req = s.next_event()
    assert isinstance(req, h.Request) and req.method == b"POST"
    assert s.their_http_version == b"1.1"
    assert s.our_state is h.SEND_RESPONSE and s.their_state is h.SEND_BODY


def test_feed_then_pull_with_partial_event():
    c, s = _pair()
    raw = c.send(h.Request(method="GET", target="/", headers=[("Host", "h")]))
    s.receive_data(raw[:5])
    assert s.next_event() is h.NEED_DATA
    s.receive_data(raw[5:])
    assert isinstance(s.next_event(), h.Request)


def test_lone_lf_accepted_on_receive():
    _, s = _pair()
    s.receive_data(b"GET / HTTP/1.1\nHost: h\n\n")
    assert isinstance(s.next_event(), h.Request)


def test_obsolete_folding_refused():
    _, s = _pair()
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n folded\r\n\r\n")
    with pytest.raises(h.RemoteProtocolError):
        s.next_event()
    assert s.their_state is h.ERROR
    assert s.our_state is h.IDLE


def test_space_first_byte_fails_immediately():
    _, s = _pair()
    s.receive_data(b" GET")
    with pytest.raises(h.RemoteProtocolError):
        s.next_event()


def test_feed_after_close_is_runtime_error_not_protocol():
    _, s = _pair()
    s.receive_data(b"")
    with pytest.raises(RuntimeError) as ei:
        s.receive_data(b"x")
    assert not isinstance(ei.value, (h.LocalProtocolError, h.RemoteProtocolError))


def test_response_status_line_without_reason_accepted():
    c, _ = _pair()
    c.send(h.Request(method="GET", target="/", headers=[("Host", "h")]))
    c.receive_data(b"HTTP/1.1 200\r\nContent-Length: 0\r\n\r\n")
    ev = c.next_event()
    assert isinstance(ev, h.Response) and ev.reason == b""


def test_trailing_data_reports_leftover():
    _, s = _pair()
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\nxyz")
    s.next_event()
    left, closed = s.trailing_data
    assert left == b"xyz" and closed is False


# ---- FP-03: framing ------------------------------------------------------

def test_content_length_body_round_trip():
    c, s = _pair()
    raw = c.send(h.Request(method="POST", target="/", headers=[("Host", "h"), ("Content-Length", "4")]))
    assert c.send(h.Data(data=b"ab")) == b"ab"
    assert c.send(h.Data(data=b"cd")) == b"cd"
    assert c.send(h.EndOfMessage()) == b""
    assert c.our_state is h.DONE
    s.receive_data(raw + b"abcd")
    assert isinstance(s.next_event(), h.Request)
    assert s.next_event().data == b"abcd"
    assert isinstance(s.next_event(), h.EndOfMessage)


def test_content_length_overrun_refused():
    c, _ = _pair()
    c.send(h.Request(method="POST", target="/", headers=[("Host", "h"), ("Content-Length", "1")]))
    with pytest.raises(h.LocalProtocolError):
        c.send(h.Data(data=b"ab"))
    assert c.our_state is h.ERROR


def test_chunked_request_and_marks():
    c, s = _pair()
    raw = c.send(h.Request(method="POST", target="/", headers=[("Host", "h"), ("Transfer-Encoding", "chunked")]))
    body = c.send(h.Data(data=b"hello")) + c.send(h.EndOfMessage(headers=[("X-T", "1")]))
    assert body == b"5\r\nhello\r\n0\r\nX-T: 1\r\n\r\n"
    s.receive_data(raw + b"3;ext=1\r\nab")
    assert isinstance(s.next_event(), h.Request)
    d = s.next_event()
    assert d.data == b"ab" and d.chunk_start and not d.chunk_end
    assert s.next_event() is h.NEED_DATA
    s.receive_data(b"c\r\n")
    d = s.next_event()
    assert d.data == b"c" and not d.chunk_start and d.chunk_end
    assert s.next_event() is h.NEED_DATA
    s.receive_data(b"0\r\n\r\n")
    eom = s.next_event()
    assert isinstance(eom, h.EndOfMessage) and len(eom.headers) == 0
    assert s.their_state is h.DONE


def test_chunk_marks_single_piece_both():
    _, s = _pair()
    s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n3\r\nabc\r\n0\r\n\r\n")
    s.next_event()
    d = s.next_event()
    assert d.chunk_start and d.chunk_end and d.data == b"abc"


def test_chunk_size_whitespace_refused_and_bad_crlf():
    _, s = _pair()
    s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n3 \r\nabc\r\n")
    s.next_event()
    with pytest.raises(h.RemoteProtocolError):
        s.next_event()


def test_close_mid_body_is_remote_error():
    _, s = _pair()
    s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nContent-Length: 9\r\n\r\nab")
    s.next_event()
    s.next_event()
    s.receive_data(b"")
    with pytest.raises(h.RemoteProtocolError):
        s.next_event()


def test_http10_close_delimited_response():
    c, s = _pair()
    # HTTP/1.0 requests cannot be sent by httpwire (FP-02); a peer's 1.0 request is fed raw
    s.receive_data(b"GET / HTTP/1.0\r\n\r\n")
    s.next_event()
    assert s.their_http_version == b"1.0"
    raw = s.send(h.Response(status_code=200, headers=[], http_version=b"1.1", reason=b"OK"))
    assert b"Content-Length" not in raw and b"Transfer-Encoding" not in raw
    assert b"Connection: close" in raw
    assert s.send(h.Data(data=b"body")) == b"body"
    assert s.send(h.EndOfMessage()) == b""
    assert s.our_state is h.MUST_CLOSE
    c.receive_data(raw + b"body")
    assert isinstance(c.next_event(), h.Response)
    assert c.next_event().data == b"body"
    assert c.next_event() is h.NEED_DATA
    c.receive_data(b"")
    assert isinstance(c.next_event(), h.EndOfMessage)
    assert isinstance(c.next_event(), h.ConnectionClosed)


def test_head_response_is_empty_body():
    c, s = _pair()
    raw = c.send(h.Request(method="HEAD", target="/", headers=[("Host", "h")]))
    c.send(h.EndOfMessage())
    s.receive_data(raw)
    s.next_event()
    out = s.send(h.Response(status_code=200, headers=[("Content-Length", "10")]))
    assert b"Content-Length: 10" in out
    assert s.send(h.EndOfMessage()) == b""
    assert s.our_state is h.DONE


def test_head_response_refuses_body_bytes():
    c, s = _pair()
    raw = c.send(h.Request(method="HEAD", target="/", headers=[("Host", "h")]))
    c.send(h.EndOfMessage())
    s.receive_data(raw)
    s.next_event()
    s.send(h.Response(status_code=200, headers=[("Content-Length", "10")]))
    with pytest.raises(h.LocalProtocolError):
        s.send(h.Data(data=b"x"))
    assert s.our_state is h.ERROR


def test_chunked_response_for_http11_peer():
    c, s = _pair()
    raw = c.send(h.Request(method="GET", target="/", headers=[("Host", "h")]))
    c.send(h.EndOfMessage())
    s.receive_data(raw)
    s.next_event()
    assert isinstance(s.next_event(), h.EndOfMessage)  # client's empty body, pulled
    head = s.send(h.Response(status_code=200, headers=[]))
    assert head == b"HTTP/1.1 200 \r\nTransfer-Encoding: chunked\r\n\r\n"
    assert s.send(h.Data(data=b"hi")) == b"2\r\nhi\r\n"
    assert s.send(h.EndOfMessage()) == b"0\r\n\r\n"
    assert s.our_state is h.DONE and s.their_state is h.DONE


def test_passthrough_keeps_object_identity():
    c, s = _pair()
    raw = c.send(h.Request(method="GET", target="/", headers=[("Host", "h")]))
    c.send(h.EndOfMessage())
    s.receive_data(raw)
    s.next_event()
    s.send(h.Response(status_code=200, headers=[("Content-Length", "3")]))

    class Blob:
        def __len__(self):
            return 3

    blob = Blob()
    pieces = s.send_with_data_passthrough(h.Data(data=blob))
    assert any(p is blob for p in pieces)


# ---- FP-04: lifecycle ----------------------------------------------------

def _cycle(c, s):
    raw = c.send(h.Request(method="GET", target="/", headers=[("Host", "h")]))
    c.send(h.EndOfMessage())
    s.receive_data(raw)
    s.next_event()
    s.next_event()
    s.send(h.Response(status_code=200, headers=[("Content-Length", "0")]))
    s.send(h.EndOfMessage())
    return raw


def test_keep_alive_two_cycles():
    c, s = _pair()
    _cycle(c, s)
    c.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
    assert isinstance(c.next_event(), h.Response)
    assert isinstance(c.next_event(), h.EndOfMessage)
    assert c.our_state is h.DONE and s.our_state is h.DONE
    c.start_next_cycle()
    s.start_next_cycle()
    assert c.our_state is h.IDLE and s.our_state is h.IDLE


def test_start_next_cycle_refused_when_not_done_is_recoverable():
    c, s = _pair()
    c.send(h.Request(method="GET", target="/", headers=[("Host", "h")]))
    with pytest.raises(h.LocalProtocolError):
        c.start_next_cycle()
    assert c.our_state is h.SEND_BODY


def test_connection_close_disables_keep_alive():
    c, s = _pair()
    raw = c.send(h.Request(method="GET", target="/", headers=[("Host", "h"), ("Connection", "close")]))
    c.send(h.EndOfMessage())
    s.receive_data(raw)
    s.next_event()
    s.next_event()
    out = s.send(h.Response(status_code=200, headers=[("Content-Length", "0")]))
    assert b"Connection: close" in out
    s.send(h.EndOfMessage())
    assert s.our_state is h.MUST_CLOSE


def test_pipelined_request_paused_until_next_cycle():
    c, s = _pair()
    raw = c.send(h.Request(method="GET", target="/", headers=[("Host", "h")]))
    c.send(h.EndOfMessage())
    s.receive_data(raw + raw)
    s.next_event()
    s.next_event()
    assert s.next_event() is h.PAUSED
    s.send(h.Response(status_code=200, headers=[("Content-Length", "0")]))
    s.send(h.EndOfMessage())
    assert s.next_event() is h.PAUSED


def test_send_refusal_moves_to_error_and_stays():
    c, _ = _pair()
    c.send(h.Request(method="GET", target="/", headers=[("Host", "h")]))
    with pytest.raises(h.LocalProtocolError):
        c.send(h.Request(method="GET", target="/", headers=[("Host", "h")]))
    assert c.our_state is h.ERROR
    with pytest.raises(h.LocalProtocolError):
        c.send(h.EndOfMessage())


def test_send_failed_marks_error():
    c, _ = _pair()
    c.send(h.Request(method="GET", target="/", headers=[("Host", "h")]))
    assert c.send_failed() is None
    assert c.our_state is h.ERROR


# ---- FP-05: protocol errors / size limit -----------------------------------

def test_default_suggested_status_and_431_on_huge_head():
    _, s = _pair()
    s.receive_data(b"GET / HTTP/1.1\r\n" + b"X: " + b"a" * (9 * 1024))
    with pytest.raises(h.RemoteProtocolError) as ei:
        s.next_event()
    assert ei.value.error_status_hint == 431
    assert s.their_state is h.ERROR


def test_default_error_status_is_400():
    _, s = _pair()
    s.receive_data(b"GET / HTTP/1.1\r\nbad line\r\n\r\n")
    with pytest.raises(h.RemoteProtocolError) as ei:
        s.next_event()
    assert ei.value.error_status_hint == 400


def test_remote_error_server_can_still_send_and_response_closes():
    _, s = _pair()
    s.receive_data(b"GARBAGE\r\n\r\n")
    with pytest.raises(h.RemoteProtocolError):
        s.next_event()
    out = s.send(h.Response(status_code=400, headers=[("Content-Length", "0")]))
    assert b"Connection: close" in out


# ---- FP-06: shutdown -------------------------------------------------------

def test_close_handshake():
    c, s = _pair()
    assert c.send(h.ConnectionClosed()) == b""
    assert c.our_state is h.CLOSED
    s.receive_data(b"")
    assert isinstance(s.next_event(), h.ConnectionClosed)
    assert s.their_state is h.CLOSED and s.our_state is h.MUST_CLOSE


def test_send_close_in_send_response_refused():
    c, s = _pair()
    c.send(h.Request(method="GET", target="/", headers=[("Host", "h")]))
    c.send(h.EndOfMessage())
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
    s.next_event()
    with pytest.raises(h.LocalProtocolError):
        s.send(h.ConnectionClosed())


# ---- FP-07: 100-continue and switching ------------------------------------

def test_expect_100_flags():
    c, s = _pair()
    c.send(h.Request(method="PUT", target="/", headers=[("Host", "h"), ("Expect", "100-continue"),
                                                         ("Content-Length", "1")]))
    assert c.client_is_waiting_for_100_continue is True
    assert c.they_are_waiting_for_100_continue is False
    s.receive_data(b"PUT / HTTP/1.1\r\nHost: h\r\nExpect: 100-continue\r\nContent-Length: 1\r\n\r\n")
    s.next_event()
    assert s.they_are_waiting_for_100_continue is True
    s.send(h.InformationalResponse(status_code=100, headers=[]))
    assert s.they_are_waiting_for_100_continue is False


def test_connect_accepted_with_200_switches():
    c, s = _pair()
    c.send(h.Request(method="CONNECT", target="x:1", headers=[("Host", "x:1")]))
    c.send(h.EndOfMessage())
    assert c.our_state is h.MIGHT_SWITCH_PROTOCOL
    s.receive_data(b"CONNECT x:1 HTTP/1.1\r\nHost: x:1\r\n\r\n")
    s.next_event()
    s.next_event()
    s.send(h.Response(status_code=200, headers=[]))
    assert s.our_state is h.SWITCHED_PROTOCOL
    c.receive_data(b"HTTP/1.1 200 OK\r\n\r\n")
    assert isinstance(c.next_event(), h.Response)
    assert c.our_state is h.SWITCHED_PROTOCOL
    with pytest.raises(h.LocalProtocolError):
        s.send(h.EndOfMessage())


def test_connect_denied_allows_next_cycle():
    c, s = _pair()
    c.send(h.Request(method="CONNECT", target="x:1", headers=[("Host", "x:1")]))
    c.send(h.EndOfMessage())
    s.receive_data(b"CONNECT x:1 HTTP/1.1\r\nHost: x:1\r\n\r\n")
    s.next_event()
    s.next_event()
    s.send(h.Response(status_code=403, headers=[("Content-Length", "0")]))
    s.send(h.EndOfMessage())
    assert s.our_state is h.DONE
    c.receive_data(b"HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\n\r\n")
    assert isinstance(c.next_event(), h.Response)
    assert isinstance(c.next_event(), h.EndOfMessage)
    assert c.our_state is h.DONE
    assert s.their_state is h.DONE


def test_upgrade_101_switches():
    c, s = _pair()
    c.send(h.Request(method="GET", target="/", headers=[("Host", "h"), ("Upgrade", "websocket")]))
    c.send(h.EndOfMessage())
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\nUpgrade: websocket\r\n\r\n")
    s.next_event()
    s.next_event()
    s.send(h.InformationalResponse(status_code=101, headers=[("Upgrade", "websocket")]))
    assert s.our_state is h.SWITCHED_PROTOCOL
    c.receive_data(b"HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\n\r\n")
    assert isinstance(c.next_event(), h.InformationalResponse)
    assert c.our_state is h.SWITCHED_PROTOCOL and c.their_state is h.SWITCHED_PROTOCOL
    assert c.next_event() is h.PAUSED
