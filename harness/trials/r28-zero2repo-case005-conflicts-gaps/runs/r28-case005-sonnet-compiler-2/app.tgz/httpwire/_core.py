"""Implementation of httpwire (events, state machine, framing, connection)."""
import re

# ---------------------------------------------------------------- sentinels


class _Sentinel(object):
    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return self._name

    def __reduce__(self):
        return self._name


CLIENT = _Sentinel("CLIENT")
SERVER = _Sentinel("SERVER")
NEED_DATA = _Sentinel("NEED_DATA")
PAUSED = _Sentinel("PAUSED")
IDLE = _Sentinel("IDLE")
SEND_RESPONSE = _Sentinel("SEND_RESPONSE")
SEND_BODY = _Sentinel("SEND_BODY")
DONE = _Sentinel("DONE")
MUST_CLOSE = _Sentinel("MUST_CLOSE")
CLOSED = _Sentinel("CLOSED")
MIGHT_SWITCH_PROTOCOL = _Sentinel("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = _Sentinel("SWITCHED_PROTOCOL")
ERROR = _Sentinel("ERROR")

_SWITCH_UPGRADE = _Sentinel("_SWITCH_UPGRADE")
_SWITCH_CONNECT = _Sentinel("_SWITCH_CONNECT")

# ------------------------------------------------------------------- errors


class ProtocolError(Exception):
    def __init__(self, msg="", error_status_hint=400):
        Exception.__init__(self, msg)
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(ProtocolError):
    pass


class RemoteProtocolError(ProtocolError):
    pass


# ------------------------------------------------------------------ grammar

MAX_CONTENT_LENGTH_DIGITS = 18
MAX_CHUNK_SIZE_DIGITS = 32
DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 16 * 1024

_token = rb"[-!#$%&'*+.^_`|~0-9a-zA-Z]+"
_name_re = re.compile(_token)
_target_re = re.compile(rb"[\x21-\x7e]+")
_value_re = re.compile(
    rb"(?:[^\x00\r\n\f\v \t](?:[^\x00\r\n\f\v]*[^\x00\r\n\f\v \t])?)?")
_digits_re = re.compile(rb"[0-9]+")

_request_line_re = re.compile(
    rb"(?P<method>" + _token + rb") (?P<target>[^\x00\s]+) "
    rb"HTTP/(?P<http_version>[0-9]\.[0-9])")
_status_line_re = re.compile(
    rb"HTTP/(?P<http_version>[0-9]\.[0-9]) (?P<status_code>[0-9]{3}) "
    rb"(?P<reason>[^\x00\r\n]*)")
_header_line_re = re.compile(
    rb"(?P<name>" + _token + rb"):[ \t]*(?P<value>[^\x00\r\n\f\v]*?)[ \t]*")
_chunk_header_re = re.compile(
    rb"(?P<size>[0-9a-fA-F]{1,%d})(?:;[^\r\n]*)?" % MAX_CHUNK_SIZE_DIGITS)
_blank_line_re = re.compile(rb"\n\r?\n")


def _bytesify(x, what="value"):
    if type(x) is bytes:
        return x
    if isinstance(x, str):
        try:
            return x.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("%s must be ASCII" % what)
    if isinstance(x, (bytes, bytearray, memoryview)):
        return bytes(x)
    raise LocalProtocolError("expected bytes-like or ASCII str for %s" % what)


# ------------------------------------------------------------------ headers


class Headers(object):
    """Sequence of (lowercase name, value) with raw_items() for raw names."""

    __slots__ = ("_full",)

    def __init__(self, full):
        self._full = full  # list of (raw_name, lower_name, value)

    def __len__(self):
        return len(self._full)

    def __iter__(self):
        for _, lower, value in self._full:
            yield (lower, value)

    def __getitem__(self, i):
        if isinstance(i, slice):
            return [(l, v) for _, l, v in self._full[i]]
        _, l, v = self._full[i]
        return (l, v)

    def __eq__(self, other):
        try:
            return list(self) == [tuple(x) for x in other]
        except TypeError:
            return NotImplemented

    def __ne__(self, other):
        r = self.__eq__(other)
        return r if r is NotImplemented else not r

    __hash__ = None

    def __repr__(self):
        return repr(list(self))

    def raw_items(self):
        return [(raw, v) for raw, _, v in self._full]


def _normalize_headers(headers, what="headers"):
    if headers is None:
        headers = []
    if isinstance(headers, Headers):
        headers = headers.raw_items()
    try:
        items = list(headers)
    except TypeError:
        raise LocalProtocolError("headers must be a sequence of pairs")
    out = []
    saw_cl = False
    saw_te = False
    cl_value = None
    for item in items:
        try:
            name, value = item
        except (TypeError, ValueError):
            raise LocalProtocolError("each header must be a (name, value) pair")
        raw = _bytesify(name, "header name")
        value = _bytesify(value, "header value")
        if not _name_re.fullmatch(raw):
            raise LocalProtocolError("illegal header name %r" % raw)
        if not _value_re.fullmatch(value):
            raise LocalProtocolError("illegal header value %r" % value)
        lower = raw.lower()
        if lower == b"content-length":
            pieces = [p.strip(b" \t") for p in value.split(b",")]
            nums = set()
            for p in pieces:
                if not _digits_re.fullmatch(p):
                    raise LocalProtocolError("bad Content-Length")
                if len(p) > MAX_CONTENT_LENGTH_DIGITS:
                    raise LocalProtocolError("Content-Length too long")
                nums.add(int(p))
            if cl_value is not None:
                nums.add(int(cl_value))
            if len(nums) != 1:
                raise LocalProtocolError("conflicting Content-Length")
            if saw_cl:
                continue
            saw_cl = True
            cl_value = pieces[0]
            value = pieces[0]
        elif lower == b"transfer-encoding":
            if saw_te:
                raise LocalProtocolError("multiple Transfer-Encoding headers",
                                         error_status_hint=501)
            saw_te = True
            value = value.lower()
            if value != b"chunked":
                raise LocalProtocolError(
                    "Only Transfer-Encoding: chunked is supported",
                    error_status_hint=501)
        out.append((raw, lower, value))
    return Headers(out)


def _get_comma_header(headers, name):
    out = []
    for _, lower, value in headers._full:
        if lower == name:
            for piece in value.split(b","):
                out.append(piece.strip().lower())
    return [x for x in out if x != b""] if False else out


def _delete_header(headers, name):
    return [(r, v) for r, l, v in headers._full if l != name]


def _set_comma_header(headers, name, values):
    items = _delete_header(headers, name)
    for v in values:
        items.append((name, v))
    return items


# ------------------------------------------------------------------- events


class _Event(object):
    _fields = ()

    def __repr__(self):
        return "<%s %s>" % (type(self).__name__, ", ".join(
            "%s=%r" % (f, getattr(self, f)) for f in self._fields))

    def __eq__(self, other):
        if type(other) is not type(self):
            return NotImplemented
        return all(getattr(self, f) == getattr(other, f) for f in self._fields)

    def __ne__(self, other):
        r = self.__eq__(other)
        return r if r is NotImplemented else not r

    __hash__ = None


def _check_host(headers, http_version):
    hosts = sum(1 for _, l, _v in headers._full if l == b"host")
    if hosts > 1:
        raise LocalProtocolError("Found multiple Host headers")
    if http_version == b"1.1" and hosts == 0:
        raise LocalProtocolError("Missing mandatory Host: header")


class Request(_Event):
    _fields = ("method", "target", "headers", "http_version")

    def __init__(self, method, target, headers, http_version=b"1.1"):
        self.method = _bytesify(method, "method")
        self.target = _bytesify(target, "target")
        self.http_version = _bytesify(http_version, "http_version")
        self.headers = _normalize_headers(headers)
        if not _name_re.fullmatch(self.method):
            raise LocalProtocolError("illegal method %r" % self.method)
        if not _target_re.fullmatch(self.target):
            raise LocalProtocolError("illegal target %r" % self.target)
        _check_host(self.headers, self.http_version)


class _ResponseBase(_Event):
    _fields = ("status_code", "headers", "http_version", "reason")
    _lo = _hi = 0

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        self.http_version = _bytesify(http_version, "http_version")
        self.reason = _bytesify(reason, "reason")
        self.headers = _normalize_headers(headers)
        if not isinstance(status_code, int) or isinstance(status_code, bool):
            raise LocalProtocolError("status code must be an integer")
        if not (self._lo <= status_code < self._hi):
            raise LocalProtocolError("illegal status code %r" % (status_code,))
        self.status_code = int(status_code)


class InformationalResponse(_ResponseBase):
    _lo, _hi = 100, 200


class Response(_ResponseBase):
    _lo, _hi = 200, 1000


class Data(_Event):
    _fields = ("data", "chunk_start", "chunk_end")

    def __init__(self, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)


class EndOfMessage(_Event):
    _fields = ("headers",)

    def __init__(self, headers=None):
        self.headers = _normalize_headers(headers)


class ConnectionClosed(_Event):
    _fields = ()

    def __init__(self):
        pass


# ------------------------------------------------------------ state machine

_BODY = {Data: SEND_BODY, EndOfMessage: DONE}
_TRANSITIONS = {
    CLIENT: {
        IDLE: {Request: SEND_BODY, ConnectionClosed: CLOSED},
        SEND_BODY: dict(_BODY),
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
        CLOSED: {ConnectionClosed: CLOSED},
        MIGHT_SWITCH_PROTOCOL: {},
        SWITCHED_PROTOCOL: {},
        ERROR: {},
    },
    SERVER: {
        IDLE: {
            ConnectionClosed: CLOSED,
            Response: SEND_BODY,
            (Request, CLIENT): SEND_RESPONSE,
        },
        SEND_RESPONSE: {
            InformationalResponse: SEND_RESPONSE,
            Response: SEND_BODY,
            (InformationalResponse, _SWITCH_UPGRADE): SWITCHED_PROTOCOL,
            (Response, _SWITCH_CONNECT): SWITCHED_PROTOCOL,
        },
        SEND_BODY: dict(_BODY),
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
        CLOSED: {ConnectionClosed: CLOSED},
        SWITCHED_PROTOCOL: {},
        MIGHT_SWITCH_PROTOCOL: {},
        ERROR: {},
    },
}


class _ConnectionState(object):
    def __init__(self):
        self.keep_alive = True
        self.pending = set()
        self.states = {CLIENT: IDLE, SERVER: IDLE}

    def _fire(self, role, event_type):
        state = self.states[role]
        try:
            new = _TRANSITIONS[role][state][event_type]
        except KeyError:
            name = event_type if isinstance(event_type, tuple) else \
                getattr(event_type, "__name__", repr(event_type))
            raise LocalProtocolError(
                "can't handle event type %s when role=%r and state=%r"
                % (name, role, state))
        self.states[role] = new

    def process_event(self, role, event_type, server_switch_event=None):
        et = event_type
        if server_switch_event is not None:
            if server_switch_event not in self.pending:
                raise LocalProtocolError(
                    "Received server event without a pending proposal")
            et = (event_type, server_switch_event)
        if server_switch_event is None and event_type is Response:
            self.pending = set()
        self._fire(role, et)
        if et is Request:
            self._fire(SERVER, (Request, CLIENT))
        self._state_triggered()

    def process_error(self, role):
        self.states[role] = ERROR
        self.keep_alive = False
        self._state_triggered()

    def disable_keep_alive(self):
        self.keep_alive = False
        self._state_triggered()

    def _state_triggered(self):
        while True:
            start = dict(self.states)
            s = self.states
            if self.pending and s[CLIENT] is DONE:
                s[CLIENT] = MIGHT_SWITCH_PROTOCOL
            if not self.pending and s[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                s[CLIENT] = DONE
            if s[SERVER] is SWITCHED_PROTOCOL and \
                    s[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                s[CLIENT] = SWITCHED_PROTOCOL
            if not self.keep_alive:
                for r in (CLIENT, SERVER):
                    if s[r] is DONE:
                        s[r] = MUST_CLOSE
            for r, o in ((CLIENT, SERVER), (SERVER, CLIENT)):
                if s[r] is CLOSED and s[o] in (IDLE, DONE):
                    s[o] = MUST_CLOSE
                if s[r] is ERROR and s[o] is DONE:
                    s[o] = MUST_CLOSE
            if s == start:
                break

    def start_next_cycle(self):
        if self.states != {CLIENT: DONE, SERVER: DONE}:
            raise LocalProtocolError(
                "not in a reusable state: client=%r server=%r"
                % (self.states[CLIENT], self.states[SERVER]))
        self.states = {CLIENT: IDLE, SERVER: IDLE}


# ------------------------------------------------------------ body framing


def _body_framing(request_method, event):
    if type(event) is Response:
        if (event.status_code in (204, 304) or request_method == b"HEAD"
                or (request_method == b"CONNECT"
                    and 200 <= event.status_code < 300)):
            return ("content-length", 0)
        te = _get_comma_header(event.headers, b"transfer-encoding")
        if te:
            return ("chunked", None)
        cl = _get_comma_header(event.headers, b"content-length")
        if cl:
            return ("content-length", int(cl[0]))
        return ("http/1.0", None)
    cl = _get_comma_header(event.headers, b"content-length")
    if cl:
        return ("content-length", int(cl[0]))
    te = _get_comma_header(event.headers, b"transfer-encoding")
    if te:
        return ("chunked", None)
    return ("content-length", 0)


# ------------------------------------------------------------------ writers


def _write_headers(headers, write):
    for raw, lower, value in headers._full:
        if lower == b"host":
            write(raw + b": " + value + b"\r\n")
    for raw, lower, value in headers._full:
        if lower != b"host":
            write(raw + b": " + value + b"\r\n")
    write(b"\r\n")


def _write_request(event, write):
    if event.http_version != b"1.1":
        raise LocalProtocolError("I only send HTTP/1.1")
    write(event.method + b" " + event.target + b" HTTP/1.1\r\n")
    _write_headers(event.headers, write)


def _write_any_response(event, write):
    if event.http_version != b"1.1":
        raise LocalProtocolError("I only send HTTP/1.1")
    write(b"HTTP/1.1 %d " % event.status_code + event.reason + b"\r\n")
    _write_headers(event.headers, write)


class _CLWriter(object):
    def __init__(self, length):
        self._length = length

    def send_data(self, data, write):
        self._length -= len(data)
        if self._length < 0:
            raise LocalProtocolError("Too much data for declared Content-Length")
        write(data)

    def send_eom(self, headers, write):
        if self._length != 0:
            raise LocalProtocolError("Too little data for declared Content-Length")
        if len(headers):
            raise LocalProtocolError("Content-Length framing cannot carry trailers")


class _ChunkedWriter(object):
    def send_data(self, data, write):
        if not len(data):
            return
        write(b"%x\r\n" % len(data))
        write(data)
        write(b"\r\n")

    def send_eom(self, headers, write):
        write(b"0\r\n")
        _write_headers(headers, write)


class _HTTP10Writer(object):
    def send_data(self, data, write):
        write(data)

    def send_eom(self, headers, write):
        if len(headers):
            raise LocalProtocolError("can't send trailers to HTTP/1.0 peer")


def _make_writer(framing):
    kind, arg = framing
    if kind == "content-length":
        return _CLWriter(arg)
    if kind == "chunked":
        return _ChunkedWriter()
    return _HTTP10Writer()


# ------------------------------------------------------------------ buffer


class _Buffer(object):
    def __init__(self):
        self.data = bytearray()

    def __len__(self):
        return len(self.data)

    def extract_at_most(self, n):
        if not self.data:
            return None
        out = bytes(self.data[:n])
        del self.data[:len(out)]
        return out

    def extract_line(self):
        i = self.data.find(b"\n")
        if i < 0:
            return None
        line = bytes(self.data[:i])
        del self.data[:i + 1]
        if line.endswith(b"\r"):
            line = line[:-1]
        return line

    def extract_lines(self):
        m = _blank_line_re.search(self.data)
        if m is None:
            return None
        text = bytes(self.data[:m.start()])
        del self.data[:m.end()]
        if text.endswith(b"\r"):
            text = text[:-1]
        lines = []
        for ln in text.split(b"\n"):
            if ln.endswith(b"\r"):
                ln = ln[:-1]
            lines.append(ln)
        return lines


def _decode_header_lines(lines):
    folded = []
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            if not folded:
                raise LocalProtocolError("continuation line at start of headers")
            folded[-1] = folded[-1] + b" " + line.lstrip(b" \t")
        else:
            folded.append(line)
    out = []
    for line in folded:
        m = _header_line_re.fullmatch(line)
        if m is None:
            raise LocalProtocolError("illegal header line: %r" % line)
        out.append((m.group("name"), m.group("value")))
    return out


def _check_obvious(buf):
    if len(buf.data) and buf.data[0] <= 32:
        raise LocalProtocolError("illegal start of message line")


def _read_request(buf):
    _check_obvious(buf)
    lines = buf.extract_lines()
    if lines is None:
        return None
    if not lines or not lines[0]:
        raise LocalProtocolError("no request line received")
    m = _request_line_re.fullmatch(lines[0])
    if m is None:
        raise LocalProtocolError("illegal request line: %r" % lines[0])
    return Request(method=m.group("method"), target=m.group("target"),
                   http_version=m.group("http_version"),
                   headers=_decode_header_lines(lines[1:]))


def _read_response(buf):
    _check_obvious(buf)
    lines = buf.extract_lines()
    if lines is None:
        return None
    if not lines or not lines[0]:
        raise LocalProtocolError("no response line received")
    m = _status_line_re.fullmatch(lines[0])
    if m is None:
        raise LocalProtocolError("illegal status line: %r" % lines[0])
    code = int(m.group("status_code"))
    cls = InformationalResponse if code < 200 else Response
    return cls(status_code=code, http_version=m.group("http_version"),
               reason=m.group("reason"),
               headers=_decode_header_lines(lines[1:]))


def _expect_nothing(buf):
    if len(buf):
        raise LocalProtocolError("Got data when expecting EOF")
    return None


class _CLReader(object):
    def __init__(self, length):
        self._total = length
        self._remaining = length

    def __call__(self, buf):
        if self._remaining == 0:
            return EndOfMessage()
        data = buf.extract_at_most(self._remaining)
        if data is None:
            return None
        self._remaining -= len(data)
        return Data(data=data)

    def read_eof(self):
        raise RemoteProtocolError(
            "peer closed connection without sending complete message: "
            "received %d bytes, expected %d"
            % (self._total - self._remaining, self._total))


class _ChunkedReader(object):
    def __init__(self):
        self._in_chunk = 0
        self._discard = 0
        self._trailer = False

    def __call__(self, buf):
        if self._trailer:
            lines = buf.extract_lines_trailer()
            if lines is None:
                return None
            return EndOfMessage(headers=_decode_header_lines(lines))
        if self._discard > 0:
            if len(buf) < self._discard:
                return None
            data = buf.extract_at_most(self._discard)
            if data != b"\r\n"[:len(data)] or len(data) != 2:
                raise LocalProtocolError("chunk not terminated by CRLF")
            self._discard = 0
        if self._in_chunk == 0:
            line = buf.extract_line()
            if line is None:
                return None
            m = _chunk_header_re.fullmatch(line)
            if m is None:
                raise LocalProtocolError("illegal chunk header: %r" % line)
            self._in_chunk = int(m.group("size"), 16)
            if self._in_chunk == 0:
                self._trailer = True
                return self(buf)
            start = True
        else:
            start = False
        data = buf.extract_at_most(self._in_chunk)
        if data is None:
            return None
        self._in_chunk -= len(data)
        end = self._in_chunk == 0
        if end:
            self._discard = 2
        return Data(data=data, chunk_start=start, chunk_end=end)


def _extract_lines_trailer(self):
    # trailer block: zero or more header lines followed by a blank line
    d = self.data
    if d[:2] == b"\r\n":
        del d[:2]
        return []
    if d[:1] == b"\n":
        del d[:1]
        return []
    return self.extract_lines()


_Buffer.extract_lines_trailer = _extract_lines_trailer


class _HTTP10Reader(object):
    def __call__(self, buf):
        data = buf.extract_at_most(999999999)
        if data is None:
            return None
        return Data(data=data)

    def read_eof(self):
        return EndOfMessage()


def _make_reader(framing):
    kind, arg = framing
    if kind == "content-length":
        return _CLReader(arg)
    if kind == "chunked":
        return _ChunkedReader()
    return _HTTP10Reader()


def _get_reader(role, state, event, request_method):
    if role is CLIENT:
        if state is IDLE:
            return _read_request
    else:
        if state in (IDLE, SEND_RESPONSE):
            return _read_response
    if state is SEND_BODY:
        return _make_reader(_body_framing(request_method, event))
    if state in (DONE, MUST_CLOSE, CLOSED):
        return _expect_nothing
    return None


def _get_writer(role, state, event, request_method):
    if state is SEND_BODY:
        return _make_writer(_body_framing(request_method, event))
    if state is IDLE:
        return _write_request if role is CLIENT else _write_any_response
    if state is SEND_RESPONSE and role is SERVER:
        return _write_any_response
    return None


# --------------------------------------------------------------- Connection


def _keep_alive(event):
    if b"close" in _get_comma_header(event.headers, b"connection"):
        return False
    if event.http_version < b"1.1":
        return False
    return True


class Connection(object):
    def __init__(self, our_role, max_incomplete_event_size=None):
        if our_role is not CLIENT and our_role is not SERVER:
            raise ValueError("expected CLIENT or SERVER, not %r" % (our_role,))
        self.our_role = our_role
        self.their_role = SERVER if our_role is CLIENT else CLIENT
        self._cstate = _ConnectionState()
        self._buf = _Buffer()
        self._closed = False
        self._max = (DEFAULT_MAX_INCOMPLETE_EVENT_SIZE
                     if max_incomplete_event_size is None
                     else max_incomplete_event_size)
        self.their_http_version = None
        self._request_method = None
        self.client_is_waiting_for_100_continue = False
        self._writer = _get_writer(our_role, IDLE, None, None)
        self._reader = _get_reader(self.their_role, IDLE, None, None)

    # -- properties
    @property
    def states(self):
        return dict(self._cstate.states)

    @property
    def our_state(self):
        return self._cstate.states[self.our_role]

    @property
    def their_state(self):
        return self._cstate.states[self.their_role]

    @property
    def they_are_waiting_for_100_continue(self):
        return bool(self.their_role is CLIENT
                    and self.client_is_waiting_for_100_continue)

    @property
    def trailing_data(self):
        return (bytes(self._buf.data), self._closed)

    # -- internals
    def _process_error(self, role):
        self._cstate.process_error(role)

    def _server_switch_event(self, event):
        if type(event) is InformationalResponse and event.status_code == 101:
            return _SWITCH_UPGRADE
        if type(event) is Response and 200 <= event.status_code < 300:
            return _SWITCH_CONNECT
        return None

    def _process_event(self, role, event):
        old = dict(self._cstate.states)
        t = type(event)
        if role is CLIENT and t is Request:
            if event.method == b"CONNECT":
                self._cstate.pending.add(_SWITCH_CONNECT)
            if _get_comma_header(event.headers, b"upgrade"):
                self._cstate.pending.add(_SWITCH_UPGRADE)
        sw = None
        if role is SERVER:
            sw = self._server_switch_event(event)
            if sw is not None and sw not in self._cstate.pending:
                sw = None
        self._cstate.process_event(role, t, sw)
        if t is Request:
            self._request_method = event.method
        if role is self.their_role and t in (Request, Response,
                                             InformationalResponse):
            self.their_http_version = event.http_version
        if t in (Request, Response) and not _keep_alive(event):
            self._cstate.disable_keep_alive()
        if t is Request and event.http_version == b"1.1" and \
                b"100-continue" in _get_comma_header(event.headers, b"expect"):
            self.client_is_waiting_for_100_continue = True
        if t in (InformationalResponse, Response):
            self.client_is_waiting_for_100_continue = False
        if role is CLIENT and t in (Data, EndOfMessage):
            self.client_is_waiting_for_100_continue = False
        self._respond_to_state_changes(old, event)

    def _respond_to_state_changes(self, old, event=None):
        if self.our_state != old[self.our_role]:
            self._writer = _get_writer(self.our_role, self.our_state, event,
                                       self._request_method)
        if self.their_state != old[self.their_role]:
            self._reader = _get_reader(self.their_role, self.their_state,
                                       event, self._request_method)

    def _clean_up_response(self, response):
        headers = response.headers
        need_close = False
        method = self._request_method
        if method != b"HEAD":
            pass
        choose = b"GET" if method in (None, b"HEAD") else method
        kind, _ = _body_framing(choose, response)
        items = None
        if kind in ("chunked", "http/1.0"):
            items = _delete_header(headers, b"content-length")
            hh = Headers([(r, r.lower(), v) for r, v in items])
            if self.their_http_version is None or \
                    self.their_http_version < b"1.1":
                items = _delete_header(hh, b"transfer-encoding")
                need_close = True
            else:
                items = _set_comma_header(hh, b"transfer-encoding",
                                          [b"chunked"])
        if not self._cstate.keep_alive or need_close:
            hh = Headers([(r, r.lower(), v) for r, v in
                          (items if items is not None else headers.raw_items())])
            conn = set(_get_comma_header(hh, b"connection"))
            conn.discard(b"keep-alive")
            conn.add(b"close")
            items = _set_comma_header(hh, b"connection", sorted(conn))
        if items is None:
            return response
        return Response(status_code=response.status_code, headers=items,
                        http_version=response.http_version,
                        reason=response.reason)

    # -- public API
    def send_with_data_passthrough(self, event):
        if self.our_state is ERROR:
            raise LocalProtocolError("Can't send data when our state is ERROR")
        try:
            if type(event) is Response:
                event = self._clean_up_response(event)
            writer = self._writer
            self._process_event(self.our_role, event)
            if type(event) is ConnectionClosed:
                return None
            pieces = []
            t = type(event)
            if t is Data:
                writer.send_data(event.data, pieces.append)
            elif t is EndOfMessage:
                writer.send_eom(event.headers, pieces.append)
            else:
                writer(event, pieces.append)
            return pieces
        except BaseException as exc:
            self._process_error(self.our_role)
            if isinstance(exc, (LocalProtocolError, RemoteProtocolError)) or \
                    not isinstance(exc, Exception):
                raise
            raise LocalProtocolError(str(exc))

    def send(self, event):
        pieces = self.send_with_data_passthrough(event)
        if pieces is None:
            return None
        return b"".join(pieces)

    def receive_data(self, data):
        if len(data):
            if self._closed:
                raise RuntimeError("received close, then received more data?")
            self._buf.data += data
        else:
            self._closed = True

    def _extract_next(self):
        state = self.their_state
        if state is DONE and len(self._buf):
            return PAUSED
        if state in (MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL):
            return PAUSED
        reader = self._reader
        event = reader(self._buf) if reader is not None else None
        if event is None:
            if not len(self._buf) and self._closed:
                if hasattr(reader, "read_eof"):
                    event = reader.read_eof()
                else:
                    event = ConnectionClosed()
        if event is None:
            event = NEED_DATA
        return event

    def next_event(self):
        if self.their_state is ERROR:
            raise RemoteProtocolError("Can't receive data when peer state is ERROR")
        try:
            event = self._extract_next()
            if event is not NEED_DATA and event is not PAUSED:
                self._process_event(self.their_role, event)
            if event is NEED_DATA:
                if len(self._buf) > self._max:
                    raise RemoteProtocolError("Receive buffer too long",
                                              error_status_hint=431)
                if self._closed:
                    raise RemoteProtocolError(
                        "peer unexpectedly closed connection")
            return event
        except BaseException as exc:
            self._process_error(self.their_role)
            if isinstance(exc, LocalProtocolError):
                raise RemoteProtocolError(str(exc), exc.error_status_hint)
            raise

    def start_next_cycle(self):
        old = dict(self._cstate.states)
        self._cstate.start_next_cycle()
        self._request_method = None
        self.their_http_version = None
        self.client_is_waiting_for_100_continue = False
        self._respond_to_state_changes(old)

    def send_failed(self):
        self._process_error(self.our_role)
