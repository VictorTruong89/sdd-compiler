"""The six event types (Interface Contract > Events; PRD FP-01)."""

import re

from ._errors import LocalProtocolError
from ._headers import Headers, check_reason, is_token, to_bytes

_TARGET = re.compile(rb"[\x21-\x7e]+")  # visible ASCII, bytes 33..126
_VERSION = re.compile(rb"[0-9]\.[0-9]")  # two digits separated by a dot


def _version(value):
    version = to_bytes(value, "HTTP version")
    if not _VERSION.fullmatch(version):
        raise LocalProtocolError("HTTP version must look like 1.1")
    return version


class Event(object):
    """Base class. Subclasses list their stored fields in _fields."""

    _fields = ()

    def __eq__(self, other):
        if type(other) is not type(self):
            return NotImplemented
        return all(getattr(self, n) == getattr(other, n) for n in self._fields)

    __hash__ = None

    def __repr__(self):
        return "%s(%s)" % (
            type(self).__name__,
            ", ".join("%s=%r" % (n, getattr(self, n)) for n in self._fields),
        )


class Request(Event):
    # spec: N-000070..N-000078, N-000104, N-000110, N-000111
    _fields = ("method", "target", "headers", "http_version")

    def __init__(self, method, target, headers, http_version=b"1.1"):
        method = to_bytes(method, "method")
        if not is_token(method):
            raise LocalProtocolError("method must be a single RFC 7230 token")
        target = to_bytes(target, "request target")
        if not _TARGET.fullmatch(target):
            raise LocalProtocolError("request target must be visible ASCII characters")
        version = _version(http_version)
        hdrs = Headers.from_pairs(headers)
        host_count = sum(1 for name, _value in hdrs if name == b"host")
        if host_count > 1:
            raise LocalProtocolError("more than one Host header")
        if version == b"1.1" and host_count == 0:
            raise LocalProtocolError("HTTP/1.1 request needs a Host header")
        self.method = method
        self.target = target
        self.headers = hdrs
        self.http_version = version


class _StatusEvent(Event):
    _low = 0
    _high = 0
    _fields = ("status_code", "headers", "http_version", "reason")

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        # spec: N-000079..N-000083, N-000112, N-000113
        if not isinstance(status_code, int):
            raise LocalProtocolError("status code must be an integer")
        status = int(status_code)
        if not (self._low <= status <= self._high):
            raise LocalProtocolError("status code %d is out of range" % status)
        version = _version(http_version)
        reason = to_bytes(reason, "reason")
        check_reason(reason)
        self.status_code = status
        self.headers = Headers.from_pairs(headers)
        self.http_version = version
        self.reason = reason


class InformationalResponse(_StatusEvent):
    """Status 100 inclusive to 200 exclusive."""

    _low = 100
    _high = 199


class Response(_StatusEvent):
    """Status 200 inclusive to 1000 exclusive."""

    _low = 200
    _high = 999


class Data(Event):
    # spec: N-000084, N-000450, N-000458, N-000463..N-000465
    _fields = ("data", "chunk_start", "chunk_end")

    def __init__(self, data, chunk_start=False, chunk_end=False):
        if isinstance(data, str):
            data = to_bytes(data, "data")
        self.data = data  # stored as given; may be a non-bytes object with a length
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)


class EndOfMessage(Event):
    # spec: N-000084..N-000086, N-000466
    _fields = ("headers",)

    def __init__(self, headers=()):
        self.headers = Headers.from_pairs(headers)


class ConnectionClosed(Event):
    # spec: N-000086, N-000457
    _fields = ()

    def __init__(self):
        pass
