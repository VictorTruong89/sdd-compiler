"""Wire parsing helpers: start lines, header lines, and the incomplete-event size limit."""

import re

from ._errors import LocalProtocolError, RemoteProtocolError
from ._headers import is_token

_REQUEST_TARGET = re.compile(rb"[\x21-\x7e]+")
_STATUS_LINE = re.compile(rb"HTTP/([0-9]\.[0-9]) ([0-9]{3})(?: (.*))?", re.DOTALL)


def remote(factory, *args, **kwargs):
    """Build an event from peer bytes; a refused construction becomes a RemoteProtocolError.

    # spec: N-000174, N-000175, N-000176 (refusals from pulled peer bytes are remote errors)
    """
    try:
        return factory(*args, **kwargs)
    except LocalProtocolError as exc:
        raise RemoteProtocolError(str(exc), exc.error_status_hint)


def split_block(buf, limit):
    """Split off one header block (start line and headers, or trailers) from a bytearray.

    Returns the lines (without line endings) and removes the block from buf, or returns None and
    leaves buf alone when the block is not complete yet. Lone LF line endings are accepted.
    # spec: N-000165 (lone LF accepted), N-000316..N-000323 (incomplete-event size limit, 431)
    """
    lines = []
    pos = 0
    while True:
        idx = buf.find(b"\n", pos)
        if idx < 0:
            if len(buf) > limit:
                raise RemoteProtocolError("incomplete message exceeds the size limit", 431)
            return None
        line = bytes(buf[pos:idx])
        if line.endswith(b"\r"):
            line = line[:-1]
        pos = idx + 1
        if not line:
            del buf[:pos]
            return lines
        lines.append(line)


def parse_header_lines(lines):
    """Turn header lines into (name, value) pairs, with obsolete line folding.

    # spec: N-000167, N-000168, N-000169 (folding joins the continuation; leading run -> one space)
    # spec: N-000106 (name must be a token); value whitespace is OWS and is stripped
    """
    pairs = []
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            if not pairs:
                raise RemoteProtocolError("continuation line with no header to continue")
            name, value = pairs[-1]
            pairs[-1] = (name, value + b" " + line.strip(b" \t"))
            continue
        colon = line.find(b":")
        if colon <= 0:
            raise RemoteProtocolError("header line has no name")
        name = line[:colon]
        if not is_token(name):
            raise RemoteProtocolError("invalid header name")
        pairs.append((name, line[colon + 1:].strip(b" \t")))
    return pairs


def parse_request_line(line):
    # spec: N-000110, N-000111, N-000174
    parts = line.split(b" ")
    if len(parts) != 3:
        raise RemoteProtocolError("malformed request line")
    method, target, version = parts
    if not is_token(method):
        raise RemoteProtocolError("invalid method")
    if not _REQUEST_TARGET.fullmatch(target):
        raise RemoteProtocolError("invalid request target")
    if version == b"HTTP/1.1":
        return method, target, b"1.1"
    if version == b"HTTP/1.0":
        return method, target, b"1.0"
    raise RemoteProtocolError("unsupported HTTP version")


def parse_status_line(line):
    """Return (status_code, version, reason). A missing reason phrase is accepted as b"".

    # spec: N-000166 (reason-less status line accepted; see NOTES.md)
    """
    match = _STATUS_LINE.fullmatch(line)
    if not match:
        raise RemoteProtocolError("malformed status line")
    version = match.group(1)
    if version not in (b"1.0", b"1.1"):
        raise RemoteProtocolError("unsupported HTTP version")
    code = int(match.group(2))
    if code < 100:
        raise RemoteProtocolError("status code out of range")
    return code, version, match.group(3) or b""
