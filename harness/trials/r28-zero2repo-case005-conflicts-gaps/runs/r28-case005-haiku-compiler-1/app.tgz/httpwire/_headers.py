"""Header lists: byte coercion, validation, and normalization (PRD FP-01)."""

from ._errors import LocalProtocolError

# Content-Length digit limit. The PRD allows any fixed value from 18 to 32 (implementer's choice);
# the Interface Contract says "longer than 16 digits is refused". 18 is the only value that keeps
# the PRD's "every value of at most 18 digits is accepted" MUST. See NOTES.md.
# spec: N-000114, N-000115, N-000116, N-000117, N-000118, N-000119
MAX_CONTENT_LENGTH_DIGITS = 18

_TOKEN_BYTES = frozenset(
    b"!#$%&'*+-.^_`|~0123456789"
    b"abcdefghijklmnopqrstuvwxyz"
    b"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
)


def is_token(value):
    """RFC 7230 token check on a bytes object (# spec: N-000106, N-000111)."""
    return len(value) > 0 and all(c in _TOKEN_BYTES for c in value)


def to_bytes(value, what):
    """Coerce a byte-valued argument: ASCII str or any bytes-like object (# spec: N-000458, N-000459)."""
    if isinstance(value, bytes):
        return value
    if isinstance(value, (bytearray, memoryview)):
        return bytes(value)
    if isinstance(value, str):
        try:
            return value.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("%s must be ASCII text or bytes" % what)
    raise LocalProtocolError("%s must be text or bytes, not %s" % (what, type(value).__name__))


def check_value(value):
    """Header value rule (# spec: N-000097..N-000100, N-000108, N-000109).

    Space and tab are allowed only between other bytes; NUL, CR, LF, FF, VT and every other
    control byte (except tab) are refused. Non-ASCII bytes are allowed.
    """
    if value[:1] in (b" ", b"\t") or value[-1:] in (b" ", b"\t"):
        raise LocalProtocolError("header value may not begin or end with a space or tab")
    for c in value:
        if c == 0x09:
            continue
        if c < 0x20 or c == 0x7F:
            raise LocalProtocolError("invalid byte 0x%02x in header value" % c)


def check_reason(value):
    """Reason phrase: no control bytes other than tab (# spec: N-000080..N-000083)."""
    for c in value:
        if c != 0x09 and (c < 0x20 or c == 0x7F):
            raise LocalProtocolError("invalid byte 0x%02x in reason phrase" % c)


def normalize(pairs):
    """Turn caller (name, value) pairs into a normalized list of (raw_name, lname, value).

    Applies the Content-Length and Transfer-Encoding rules (# spec: N-000092..N-000096,
    N-000114..N-000121). Raises LocalProtocolError; 501 for Transfer-Encoding refusals.
    """
    entries = []
    for pair in pairs:
        if isinstance(pair, (str, bytes)):
            raise LocalProtocolError("each header must be a (name, value) pair")
        try:
            name, value = pair
        except (TypeError, ValueError):
            raise LocalProtocolError("each header must be a (name, value) pair")
        name = to_bytes(name, "header name")
        value = to_bytes(value, "header value")
        if not is_token(name):
            raise LocalProtocolError("header name %r is not an RFC 7230 token" % (name,))
        check_value(value)
        entries.append([name, name.lower(), value])

    # Content-Length: comma-separated pieces, repeated headers; all equal -> one header.
    cl_idx = [i for i, e in enumerate(entries) if e[1] == b"content-length"]
    if cl_idx:
        lengths = set()
        for i in cl_idx:
            for piece in entries[i][2].split(b","):
                piece = piece.strip(b" \t")
                if not piece or not piece.isdigit():
                    raise LocalProtocolError("Content-Length must be a decimal integer")
                if len(piece) > MAX_CONTENT_LENGTH_DIGITS:
                    raise LocalProtocolError("Content-Length has too many digits")
                lengths.add(int(piece))
        if len(lengths) > 1:
            raise LocalProtocolError("conflicting Content-Length values")
        entries[cl_idx[0]][2] = str(lengths.pop()).encode("ascii")
        drop = set(cl_idx[1:])
        entries = [e for i, e in enumerate(entries) if i not in drop]

    # Transfer-Encoding: exactly one header whose value is "chunked" in any case (501 otherwise).
    te_idx = [i for i, e in enumerate(entries) if e[1] == b"transfer-encoding"]
    if len(te_idx) > 1:
        raise LocalProtocolError("more than one Transfer-Encoding header", 501)
    if te_idx:
        entry = entries[te_idx[0]]
        if entry[2].lower() != b"chunked":
            raise LocalProtocolError("unsupported Transfer-Encoding", 501)
        entry[2] = b"chunked"

    return [tuple(e) for e in entries]


class Headers(object):
    """Ordered header list (Interface Contract > Events > Header list; N-000467..N-000471).

    Iterating or indexing yields (lowercase_name, value) byte pairs.
    raw_items() yields (name_as_supplied, value) byte pairs.
    """

    __slots__ = ("_items",)

    def __init__(self, items):
        self._items = tuple(items)

    @classmethod
    def from_pairs(cls, pairs):
        if pairs is None:
            pairs = ()
        elif isinstance(pairs, Headers):
            pairs = pairs.raw_items()
        return cls(normalize(pairs))

    def __iter__(self):
        for _raw, lname, value in self._items:
            yield (lname, value)

    def __len__(self):
        return len(self._items)

    def __getitem__(self, index):
        if isinstance(index, slice):
            return [(lname, value) for _raw, lname, value in self._items[index]]
        _raw, lname, value = self._items[index]
        return (lname, value)

    def raw_items(self):
        """Pairs with each name exactly as the caller supplied it (# spec: N-000469..N-000471)."""
        return [(raw, value) for raw, _lname, value in self._items]

    def __eq__(self, other):
        if isinstance(other, Headers):
            return list(self) == list(other)
        if isinstance(other, (list, tuple)):
            return list(self) == [tuple(p) for p in other]
        return NotImplemented

    __hash__ = None

    def __repr__(self):
        return "Headers(%r)" % (list(self),)
