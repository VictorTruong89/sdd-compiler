"""Body readers (pull side) and body writers (send side) for the three framings (PRD FP-03)."""

import re

from ._errors import LocalProtocolError, RemoteProtocolError
from ._events import Data, EndOfMessage
from ._parse import parse_header_lines, remote, split_block

# Chunk-size line: 1..32 hex digits (implementer's choice in 16..32), then optional extension.
# Whitespace directly after the size is refused (N-000242..N-000245); extensions are discarded.
# spec: N-000228, N-000229, N-000230, N-000231, N-000232, N-000242, N-000243, N-000244, N-000245
_CHUNK_SIZE_LINE = re.compile(rb"([0-9a-fA-F]{1,32})(;[^\r\n]*)?")


def payload_length(payload):
    """Number of body bytes in a payload (bytes-like, or any object with a length)."""
    if isinstance(payload, (bytes, bytearray)):
        return len(payload)
    if isinstance(payload, memoryview):
        return payload.nbytes
    try:
        return len(payload)
    except TypeError:
        raise LocalProtocolError("data payload must be bytes-like or have a length")


# ---------------------------------------------------------------- readers
# Each reader's read(buf, closed) consumes from the bytearray buf and returns a Data or
# EndOfMessage event, or None when it needs more bytes. closed is True once the receive side
# has been closed.

class EmptyReader(object):
    """No body: end-of-message at once. # spec: N-000185, N-000215, N-000216"""

    def read(self, buf, closed):
        return EndOfMessage()


class LengthReader(object):
    """Content-Length body. # spec: N-000188, N-000189, N-000190"""

    def __init__(self, length):
        self._remaining = length

    def read(self, buf, closed):
        if self._remaining == 0:
            return EndOfMessage()
        if not buf:
            return None
        n = min(len(buf), self._remaining)
        payload = bytes(buf[:n])
        del buf[:n]
        self._remaining -= n
        return Data(payload)


class CloseDelimitedReader(object):
    """HTTP/1.0-style body: every byte until the receive side closes. # spec: N-000208..N-000214"""

    def read(self, buf, closed):
        if buf:
            payload = bytes(buf)
            del buf[:]
            return Data(payload)
        if closed:
            return EndOfMessage()
        return None


class ChunkedReader(object):
    """Transfer-Encoding: chunked body. # spec: N-000192..N-000197, N-000220..N-000232, N-000242..N-000245"""

    def __init__(self, limit):
        self._limit = limit
        self._state = "size"  # size | data | data_end | trailers
        self._remaining = 0
        self._first_piece = False

    def read(self, buf, closed):
        while True:
            if self._state == "size":
                idx = buf.find(b"\n")
                if idx < 0:
                    if len(buf) > self._limit:
                        raise RemoteProtocolError("chunk-size line is too long")
                    return None
                line = bytes(buf[:idx])
                del buf[:idx + 1]
                if line.endswith(b"\r"):
                    line = line[:-1]
                match = _CHUNK_SIZE_LINE.fullmatch(line)
                if not match:
                    raise RemoteProtocolError("invalid chunk-size line")
                size = int(match.group(1), 16)
                if size == 0:
                    self._state = "trailers"
                else:
                    self._remaining = size
                    self._first_piece = True
                    self._state = "data"
                continue

            if self._state == "data":
                if not buf:
                    return None
                n = min(len(buf), self._remaining)
                payload = bytes(buf[:n])
                del buf[:n]
                self._remaining -= n
                start = self._first_piece
                self._first_piece = False
                end = self._remaining == 0
                if end:
                    self._state = "data_end"
                return Data(payload, chunk_start=start, chunk_end=end)

            if self._state == "data_end":
                if not buf:
                    return None
                if buf[0:1] != b"\r":
                    raise RemoteProtocolError("chunk data must be followed by CRLF")
                if len(buf) < 2:
                    return None
                if buf[1:2] != b"\n":
                    raise RemoteProtocolError("chunk data must be followed by CRLF")
                del buf[:2]
                self._state = "size"
                continue

            # trailers
            lines = split_block(buf, self._limit)
            if lines is None:
                return None
            return remote(EndOfMessage, parse_header_lines(lines))


# ---------------------------------------------------------------- writers
# Each writer's data(payload) and end(trailers) return a list of pieces (bytes-like objects).
# Payload objects that are not bytes-like are passed through by identity.

class EmptyWriter(object):
    """No body bytes may be sent. # spec: N-000215..N-000218"""

    def data(self, payload):
        if payload_length(payload):
            raise LocalProtocolError("this message has an empty body")
        return []

    def end(self, trailers):
        if trailers:
            raise LocalProtocolError("trailing headers are not allowed without chunked framing")
        return []


class LengthWriter(object):
    """Content-Length body. # spec: N-000188..N-000191, N-000238, N-000239"""

    def __init__(self, length):
        self._length = length
        self._sent = 0

    def data(self, payload):
        n = payload_length(payload)
        if self._sent + n > self._length:
            raise LocalProtocolError("data would exceed the declared Content-Length")
        self._sent += n
        return [payload] if n else []

    def end(self, trailers):
        if trailers:
            raise LocalProtocolError("trailing headers are not allowed with Content-Length framing")
        if self._sent != self._length:
            raise LocalProtocolError("end-of-message before the declared Content-Length was sent")
        return []


class ChunkedWriter(object):
    """Transfer-Encoding: chunked body. # spec: N-000192..N-000197"""

    def data(self, payload):
        n = payload_length(payload)
        if n == 0:
            return []
        return [b"%x\r\n" % n, payload, b"\r\n"]

    def end(self, trailers):
        lines = b"".join(raw + b": " + value + b"\r\n" for raw, value in trailers)
        return [b"0\r\n" + lines + b"\r\n"]


class CloseWriter(object):
    """Close-delimited body (HTTP/1.0 peer). # spec: N-000203..N-000206, N-000241"""

    def data(self, payload):
        n = payload_length(payload)
        return [payload] if n else []

    def end(self, trailers):
        if trailers:
            raise LocalProtocolError("trailing headers are not allowed for a close-delimited body")
        return []
