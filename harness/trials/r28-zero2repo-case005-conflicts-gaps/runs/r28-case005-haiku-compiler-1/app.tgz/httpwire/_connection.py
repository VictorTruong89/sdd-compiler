"""The sans-I/O Connection object (Interface Contract > Connection; PRD FP-02, FP-04..FP-07).

Two states are tracked per connection: ours (our_role) and theirs (the peer's role). Every
send and every pull goes through _commit(), which moves the sender's state and the receiver's
state together.
"""

from ._errors import LocalProtocolError, ReceiveClosedError, RemoteProtocolError, _InvalidRoleError
from ._events import (
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    Request,
    Response,
)
from ._framing import (
    ChunkedReader,
    ChunkedWriter,
    CloseDelimitedReader,
    CloseWriter,
    EmptyReader,
    EmptyWriter,
    LengthReader,
    LengthWriter,
    payload_length,
)
from ._headers import Headers
from ._parse import parse_header_lines, parse_request_line, parse_status_line, remote, split_block
from ._sentinels import (
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
)

# spec: N-000478, N-000479, N-000480 (default incomplete-event limit); see NOTES.md for the 8 KiB choice
DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 8 * 1024

# Internal event kinds.
REQUEST, INFO, RESPONSE, DATA, EOM, CLOSE = "request", "info", "response", "data", "eom", "close"

_KINDS = (
    (Request, REQUEST),
    (InformationalResponse, INFO),
    (Response, RESPONSE),
    (Data, DATA),
    (EndOfMessage, EOM),
    (ConnectionClosed, CLOSE),
)


def _kind_of(event):
    for cls, kind in _KINDS:
        if isinstance(event, cls):
            return kind
    raise TypeError("expected an httpwire event instance, got %r" % (event,))


def _other(role):
    return SERVER if role is CLIENT else CLIENT


def _find(items, lname):
    for item in items:
        if item[1] == lname:
            return item
    return None


def _has_token(items, lname, token):
    """True if some header named lname has token as a comma-separated element (case-insensitive)."""
    for _raw, name, value in items:
        if name == lname:
            for piece in value.split(b","):
                if piece.strip(b" \t").lower() == token:
                    return True
    return False


def _host_first(items):
    # spec: N-000161, N-000162
    items = list(items)
    for idx, item in enumerate(items):
        if item[1] == b"host":
            return [item] + items[:idx] + items[idx + 1:]
    return items


def _format(items):
    return b"".join(raw + b": " + value + b"\r\n" for raw, _lname, value in items)


def _add_close(items):
    """Make the Connection header say close and drop keep-alive (# spec: N-000265..N-000268)."""
    out = []
    tokens = []
    position = None
    for raw, lname, value in items:
        if lname == b"connection":
            if position is None:
                position = len(out)
                out.append(None)
            tokens.extend(t.strip(b" \t") for t in value.split(b","))
            continue
        out.append((raw, lname, value))
    kept = [t for t in tokens if t and t.lower() not in (b"keep-alive", b"close")]
    header = (b"Connection", b"connection", b", ".join(kept + [b"close"]))
    if position is None:
        out.append(header)
    else:
        out[position] = header
    return out


def _request_reader(event, limit):
    items = event.headers._items
    cl = _find(items, b"content-length")
    if cl is not None:
        return LengthReader(int(cl[2]))
    if _find(items, b"transfer-encoding") is not None:
        return ChunkedReader(limit)
    return EmptyReader()


class _StateMap(dict):
    """Mapping keyed by CLIENT and SERVER; also indexable as (client_state, server_state)."""

    def __getitem__(self, key):
        if type(key) is int:
            key = (CLIENT, SERVER)[key]
        return dict.__getitem__(self, key)


class Connection(object):
    """One HTTP/1.1 connection in the client or server role. Performs no I/O."""

    def __init__(self, role, max_incomplete_event_size=DEFAULT_MAX_INCOMPLETE_EVENT_SIZE):
        if role is not CLIENT and role is not SERVER:
            raise _InvalidRoleError("role must be CLIENT or SERVER")
        # spec: N-000478, N-000479, N-000480
        limit = int(max_incomplete_event_size)
        if limit < 1:
            raise ValueError("max_incomplete_event_size must be positive")
        self._our_role = role
        self._their_role = _other(role)
        self._states = _StateMap({CLIENT: IDLE, SERVER: IDLE})  # spec: N-000126 (both start IDLE)
        self._max_incomplete = limit
        self._buffer = bytearray()
        self._receive_closed = False
        self._their_http_version = None
        self._reset_cycle()

    def _reset_cycle(self):
        self._keep_alive = True
        self._offers_connect = False
        self._offers_upgrade = False
        self._request_method = None
        self._writer = None
        self._reader = None
        self._client_waiting = False
        self._they_waiting = False

    # ------------------------------------------------------------ public properties

    @property
    def our_role(self):
        return self._our_role

    @property
    def their_role(self):
        return self._their_role

    @property
    def our_state(self):
        return self._states[self._our_role]

    @property
    def their_state(self):
        return self._states[self._their_role]

    @property
    def states(self):
        return self._states

    @property
    def their_http_version(self):
        return self._their_http_version

    @property
    def client_is_waiting_for_100_continue(self):
        return bool(self._client_waiting)

    @property
    def they_are_waiting_for_100_continue(self):
        return bool(self._they_waiting)

    @property
    def trailing_data(self):
        return (bytes(self._buffer), self._receive_closed)

    # ------------------------------------------------------------ send side

    def send(self, event):
        """Encode one event to bytes (b"" when it produces none). Raises LocalProtocolError."""
        if isinstance(event, Data) and not isinstance(event.data, (bytes, bytearray, memoryview)):
            try:
                payload = memoryview(event.data).tobytes()
            except TypeError:
                self._refuse("payload is not bytes-like; use send_with_data_passthrough")
            event = Data(payload, event.chunk_start, event.chunk_end)
        return b"".join(self._send_pieces(event))

    def send_with_data_passthrough(self, event):
        """Like send(), but returns a list of pieces; non-bytes payloads pass through by identity.

        # spec: N-000502..N-000506, N-000233..N-000237
        """
        return self._send_pieces(event)

    def _refuse(self, message):
        self._states[self._our_role] = ERROR  # a refused send is unrecoverable for sending
        self._post_transition()
        raise LocalProtocolError(message)

    def _send_pieces(self, event):
        kind = _kind_of(event)
        try:
            return self._do_send(kind, event)
        except LocalProtocolError:
            # spec: N-000307..N-000310 (refused send -> our state ERROR; their state unchanged)
            self._states[self._our_role] = ERROR
            self._post_transition()
            raise

    def _do_send(self, kind, event):
        our = self._our_role
        state = self._states[our]
        if state is ERROR:
            raise LocalProtocolError("connection is in ERROR; sends are refused")

        if kind == REQUEST:
            # spec: N-000128, N-000283, N-000156..N-000160
            if our is not CLIENT or state is not IDLE:
                raise LocalProtocolError("a request can be sent only from IDLE in the client role")
            if event.http_version != b"1.1":
                raise LocalProtocolError("only HTTP/1.1 requests can be sent")
            items = _host_first(event.headers._items)
            cl = _find(items, b"content-length")
            if cl is not None:
                items = [i for i in items if i[1] != b"transfer-encoding"]
                writer = LengthWriter(int(cl[2]))
            elif _find(items, b"transfer-encoding") is not None:
                writer = ChunkedWriter()
            else:
                writer = EmptyWriter()
            wire = b"%s %s HTTP/1.1\r\n" % (event.method, event.target) + _format(items) + b"\r\n"
            self._begin_request(event)
            self._writer = writer
            self._commit(CLIENT, REQUEST)
            return [wire]

        if kind == INFO:
            # spec: N-000136, N-000349, N-000351, N-000366, N-000372
            if our is not SERVER or state is not SEND_RESPONSE:
                raise LocalProtocolError("an informational response can be sent only from SEND_RESPONSE")
            if event.http_version != b"1.1":
                raise LocalProtocolError("only HTTP/1.1 responses can be sent")
            accept = self._offers_upgrade and event.status_code == 101
            wire = b"HTTP/1.1 %03d %s\r\n" % (event.status_code, event.reason)
            wire += _format(event.headers._items) + b"\r\n"
            self._commit(SERVER, INFO, accept=accept)
            return [wire]

        if kind == RESPONSE:
            # spec: N-000136..N-000139, N-000215..N-000219, N-000255, N-000394..N-000398
            if our is not SERVER or state not in (IDLE, SEND_RESPONSE):
                raise LocalProtocolError("a response can be sent only from SEND_RESPONSE (or IDLE)")
            if event.http_version != b"1.1":
                raise LocalProtocolError("only HTTP/1.1 responses can be sent")
            status_line = b"HTTP/1.1 %03d %s\r\n" % (event.status_code, event.reason)
            if self._offers_connect and event.status_code == 200:
                # Accepted CONNECT: no body, no end-of-message.
                self._commit(SERVER, RESPONSE, accept=True)
                return [status_line + _format(event.headers._items) + b"\r\n"]
            items, writer, close_delimited = self._plan_response(event)
            if (
                not self._keep_alive
                or close_delimited
                or _has_token(items, b"connection", b"close")
                or self._states[self._their_role] is ERROR  # spec: N-000305, N-000306 (close after remote error)
            ):
                items = _add_close(items)
                self._keep_alive = False
            self._writer = writer
            self._commit(SERVER, RESPONSE, accept=False)
            return [status_line + _format(items) + b"\r\n"]

        if kind == DATA:
            # spec: N-000140..N-000143, N-000238, N-000233..N-000237
            if state is not SEND_BODY or self._writer is None:
                raise LocalProtocolError("data can be sent only in SEND_BODY")
            pieces = self._writer.data(event.data)
            self._commit(our, DATA)
            return pieces

        if kind == EOM:
            # spec: N-000140..N-000143, N-000239..N-000241
            if state is not SEND_BODY or self._writer is None:
                raise LocalProtocolError("end-of-message can be sent only in SEND_BODY")
            pieces = self._writer.end(event.headers.raw_items())
            self._writer = None
            self._commit(our, EOM)
            return pieces

        # CLOSE: spec: N-000334, N-000345, N-000346
        if state not in (IDLE, DONE, MUST_CLOSE):
            raise LocalProtocolError("connection-closed can be sent only from IDLE, DONE, or MUST_CLOSE")
        self._commit(our, CLOSE)
        return []

    def _plan_response(self, event):
        """Choose the body framing and header set for a final response we send (FP-03)."""
        items = list(event.headers._items)
        status = event.status_code
        if status in (204, 304):
            # spec: N-000215, N-000216: empty body regardless of framing headers
            items = [i for i in items if i[1] not in (b"content-length", b"transfer-encoding")]
            return items, EmptyWriter(), False

        head = self._request_method == b"HEAD"  # spec: N-000215, N-000219
        peer_11 = self._their_http_version == b"1.1"
        cl = _find(items, b"content-length")
        te = _find(items, b"transfer-encoding")
        if te is not None:
            # spec: N-000207 transfer-encoding wins over Content-Length on constructed responses
            items = [i for i in items if i[1] != b"content-length"]
            cl = None
        if cl is not None:
            if head:
                if int(cl[2]) == 0:  # spec: N-000218 (Content-Length: 0 dropped for empty-body responses)
                    items = [i for i in items if i[1] != b"content-length"]
                return items, EmptyWriter(), False
            return items, LengthWriter(int(cl[2])), False  # spec: N-000198, N-000199

        # Neither framing header, or chunked: the wire form depends on the peer's version.
        if peer_11:
            if te is None:
                items.append((b"Transfer-Encoding", b"transfer-encoding", b"chunked"))  # spec: N-000202
            return items, (EmptyWriter() if head else ChunkedWriter()), False
        items = [i for i in items if i[1] != b"transfer-encoding"]
        # spec: N-000203..N-000206 (HTTP/1.0 or unknown peer: close-delimited, connection must close)
        return items, (EmptyWriter() if head else CloseWriter()), True

    # ------------------------------------------------------------ receive side

    def receive_data(self, data):
        """Store bytes received from the peer; empty means the peer closed its sending side.

        # spec: N-000144..N-000152, N-000507..N-000511, N-000180..N-000182
        """
        if self._receive_closed:
            if payload_length(data):
                raise ReceiveClosedError("bytes received after the receive side was closed")
            return None
        if not payload_length(data):
            self._receive_closed = True
            return None
        self._buffer += bytes(data)
        return None

    def next_event(self):
        """Pull one event, NEED_DATA, or PAUSED. Peer violations raise RemoteProtocolError.

        # spec: N-000512..N-000516, N-000127, N-000153..N-000155, N-000275..N-000279
        """
        try:
            return self._next_event()
        except RemoteProtocolError:
            their = self._their_role
            if self._states[their] is not ERROR:
                self._states[their] = ERROR  # spec: N-000302..N-000306
                self._post_transition()
            raise

    def _next_event(self):
        their = self._states[self._their_role]
        if their is ERROR:
            raise RemoteProtocolError("the peer already violated the protocol", 400)
        if their is SWITCHED_PROTOCOL or their is MIGHT_SWITCH_PROTOCOL:
            return PAUSED  # spec: N-000381..N-000391, N-000392
        if their is CLOSED:
            return ConnectionClosed()  # spec: N-000340
        if their is DONE:
            if self._buffer:
                return PAUSED  # spec: N-000275..N-000279 (pipelined bytes wait for the next cycle)
            if not self._receive_closed:
                return NEED_DATA
            return self._pull_close()
        if their is MUST_CLOSE:
            if self._buffer:
                raise RemoteProtocolError("the peer must close and sent more data")
            if not self._receive_closed:
                return NEED_DATA
            return self._pull_close()
        if their is SEND_BODY:
            return self._pull_body()

        # IDLE (expecting a request, or an unsolicited response) or SEND_RESPONSE (expecting a response)
        if not self._buffer:
            if self._receive_closed:
                if their is IDLE:
                    return self._pull_close()  # spec: N-000339..N-000341
                # spec: N-000324, N-000347: close while a response is still owed is a remote error
                raise RemoteProtocolError("connection closed before the response was complete")
            return NEED_DATA
        if self._buffer[0] < 33:
            # spec: N-000177..N-000179 — fail at once on a space or control byte
            raise RemoteProtocolError("message starts with a space or control byte")
        lines = split_block(self._buffer, self._max_incomplete)
        if lines is None:
            if self._receive_closed:
                raise RemoteProtocolError("connection closed in the middle of a message")  # spec: N-000324
            return NEED_DATA
        return self._make_start_event(lines)

    def _pull_close(self):
        self._commit(self._their_role, CLOSE)
        return ConnectionClosed()

    def _pull_body(self):
        event = self._reader.read(self._buffer, self._receive_closed)
        if event is None:
            if self._receive_closed:
                raise RemoteProtocolError("connection closed in the middle of a body")  # spec: N-000324
            return NEED_DATA
        if isinstance(event, EndOfMessage):
            self._reader = None
            self._commit(self._their_role, EOM)
        else:
            self._commit(self._their_role, DATA)
        return event

    def _make_start_event(self, lines):
        if self._their_role is CLIENT:
            # The peer sends requests (we are the server).
            method, target, version = parse_request_line(lines[0])
            event = remote(Request, method, target, parse_header_lines(lines[1:]), version)
            self._their_http_version = version  # spec: N-000170, N-000171
            self._begin_request(event)
            self._commit(CLIENT, REQUEST)
            self._reader = _request_reader(event, self._max_incomplete)
            return event

        # The peer sends responses (we are the client).
        code, version, reason = parse_status_line(lines[0])
        pairs = parse_header_lines(lines[1:])
        self._their_http_version = version
        if code < 200:
            if self._states[SERVER] is not SEND_RESPONSE:
                raise RemoteProtocolError("informational response with no request outstanding")
            event = remote(InformationalResponse, code, pairs, version, reason)
            self._commit(SERVER, INFO, accept=self._offers_upgrade and code == 101)
            return event

        event = remote(Response, code, pairs, version, reason)
        items = event.headers._items
        accept = self._offers_connect and code == 200
        if not accept:
            if version != b"1.1" or _has_token(items, b"connection", b"close"):
                self._keep_alive = False  # spec: N-000259..N-000264
            self._reader = self._response_reader(event)
            if isinstance(self._reader, CloseDelimitedReader):
                self._keep_alive = False  # spec: N-000265..N-000267
        self._commit(SERVER, RESPONSE, accept=accept)
        return event

    def _response_reader(self, event):
        # spec: N-000198..N-000218 (framing of a received response)
        if self._request_method == b"HEAD" or event.status_code in (204, 304):
            return EmptyReader()
        items = event.headers._items
        cl = _find(items, b"content-length")
        if cl is not None:
            return LengthReader(int(cl[2]))
        if _find(items, b"transfer-encoding") is not None:
            return ChunkedReader(self._max_incomplete)
        return CloseDelimitedReader()  # spec: N-000208..N-000214

    # ------------------------------------------------------------ cycles and failures

    def start_next_cycle(self):
        """Reset both sides to IDLE once both are DONE. # spec: N-000270..N-000271, N-000280..N-000282"""
        if self._states[CLIENT] is not DONE or self._states[SERVER] is not DONE:
            raise LocalProtocolError("the next cycle can start only when both sides are DONE")
        self._states = _StateMap({CLIENT: IDLE, SERVER: IDLE})
        self._reset_cycle()
        return None

    def send_failed(self):
        """Tell the connection that the last send's bytes never went out. # spec: N-000312..N-000315"""
        self._states[self._our_role] = ERROR
        self._post_transition()
        return None

    # ------------------------------------------------------------ state machinery

    def _begin_request(self, event):
        """Request-level bookkeeping shared by the send and pull paths."""
        items = event.headers._items
        self._request_method = event.method
        self._offers_connect = event.method == b"CONNECT"  # spec: N-000364, N-000365
        self._offers_upgrade = _find(items, b"upgrade") is not None  # spec: N-000366..N-000368
        if event.http_version != b"1.1" or _has_token(items, b"connection", b"close"):
            self._keep_alive = False  # spec: N-000259..N-000264, N-000286, N-000287
        if event.http_version == b"1.1" and _has_token(items, b"expect", b"100-continue"):
            # spec: N-000354..N-000357 (HTTP/1.1 only; matched case-insensitively)
            self._client_waiting = True
            if self._our_role is SERVER:
                self._they_waiting = True

    def _finish(self):
        """What a side enters when its message ends: DONE, or MUST_CLOSE without keep-alive."""
        return DONE if self._keep_alive else MUST_CLOSE  # spec: N-000259..N-000264

    def _done_state(self, sender):
        """State after an end-of-message from sender; a proposing client waits in MIGHT_SWITCH."""
        if sender is CLIENT and (self._offers_connect or self._offers_upgrade):
            other = self._states[SERVER]
            if other is SWITCHED_PROTOCOL:
                return SWITCHED_PROTOCOL
            if other is SEND_RESPONSE:
                return MIGHT_SWITCH_PROTOCOL  # spec: N-000373..N-000377
        return self._finish()

    def _commit(self, sender, kind, accept=False):
        """Apply one event (sent by us or pulled from the peer) to both sides' states."""
        recv = _other(sender)
        r_old = self._states[recv]

        if kind == REQUEST:
            s_new = SEND_BODY
        elif kind == INFO:
            s_new = SWITCHED_PROTOCOL if accept else SEND_RESPONSE
        elif kind == RESPONSE:
            s_new = SWITCHED_PROTOCOL if accept else SEND_BODY
        elif kind == DATA:
            s_new = SEND_BODY
        elif kind == EOM:
            s_new = self._done_state(sender)
        else:
            s_new = CLOSED

        r_new = r_old
        if kind == REQUEST and r_old is IDLE:
            r_new = SEND_RESPONSE  # spec: N-000250..N-000254
        elif kind in (INFO, RESPONSE) and r_old is MIGHT_SWITCH_PROTOCOL:
            if accept:
                r_new = SWITCHED_PROTOCOL  # spec: N-000381, N-000362
            elif kind == RESPONSE:
                r_new = self._finish()  # spec: N-000378..N-000380 (denial)

        if kind in (INFO, RESPONSE) or (kind in (DATA, EOM) and sender is CLIENT):
            # spec: N-000358, N-000359 (waiting flags turn off)
            self._client_waiting = False
            self._they_waiting = False

        self._states[sender] = s_new
        self._states[recv] = r_new
        self._post_transition()

    def _post_transition(self):
        s = self._states
        if not self._keep_alive:
            # spec: N-000259..N-000264 — with keep-alive off, a side that is DONE must close
            for role in (CLIENT, SERVER):
                if s[role] is DONE:
                    s[role] = MUST_CLOSE
        for a, b in ((CLIENT, SERVER), (SERVER, CLIENT)):
            # spec: N-000336..N-000338 (peer closed: IDLE/DONE become MUST_CLOSE)
            if s[a] is CLOSED and (s[b] is IDLE or s[b] is DONE):
                s[b] = MUST_CLOSE
            # spec: N-000311 (ERROR on one side: DONE on the other becomes MUST_CLOSE)
            if s[a] is ERROR and s[b] is DONE:
                s[b] = MUST_CLOSE
