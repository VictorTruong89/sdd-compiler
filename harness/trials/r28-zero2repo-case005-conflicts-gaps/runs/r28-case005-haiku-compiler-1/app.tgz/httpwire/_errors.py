"""Exception classes (Interface Contract > Errors; PRD FP-02, FP-05)."""


class _ProtocolErrorBase(Exception):
    """Common shape of the two protocol errors: a message and a suggested status.

    # spec: N-000472 (error_status_hint is an int), N-000473 (str() is the message),
    # spec: N-000292, N-000293 (every protocol error carries a suggested status, default 400)
    """

    def __init__(self, message="", error_status_hint=400):
        super().__init__(message)
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(_ProtocolErrorBase):
    """The integrator's own event or send violated the protocol.

    # spec: N-000290, N-000291, N-000326 (distinct from RemoteProtocolError and from ReceiveClosedError)
    """


class RemoteProtocolError(_ProtocolErrorBase):
    """The peer's bytes violated the protocol.

    # spec: N-000290, N-000291, N-000326
    """


class ReceiveClosedError(RuntimeError):
    """Non-empty bytes were fed after the receive side was closed.

    Deliberately neither a LocalProtocolError nor a RemoteProtocolError.
    # spec: N-000180, N-000181, N-000182, N-000348, N-000474, N-000475
    """


class _InvalidRoleError(LocalProtocolError, ValueError):
    """Raised by Connection() for a role that is neither CLIENT nor SERVER.

    # spec: N-000476, N-000477, N-000172, N-000173
    """
