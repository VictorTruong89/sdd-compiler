"""Package-root singletons: roles, pull results, and the nine state values.

Each object is distinct and compares equal only to itself
(Interface Contract > Shape of the public surface; N-000438..N-000445).
"""


class _Sentinel(object):
    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return "<httpwire.%s>" % self._name


# Roles (# spec: N-000438, N-000439)
CLIENT = _Sentinel("CLIENT")
SERVER = _Sentinel("SERVER")

# Non-event results of next_event (# spec: N-000440, N-000441, N-000442)
NEED_DATA = _Sentinel("NEED_DATA")
PAUSED = _Sentinel("PAUSED")

# The nine states (# spec: N-000443, N-000444, N-000445; PRD FP-02 N-000124)
IDLE = _Sentinel("IDLE")
SEND_RESPONSE = _Sentinel("SEND_RESPONSE")
SEND_BODY = _Sentinel("SEND_BODY")
DONE = _Sentinel("DONE")
MUST_CLOSE = _Sentinel("MUST_CLOSE")
CLOSED = _Sentinel("CLOSED")
MIGHT_SWITCH_PROTOCOL = _Sentinel("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = _Sentinel("SWITCHED_PROTOCOL")
ERROR = _Sentinel("ERROR")
