"""Behavioural tests for httpwire. Test names and docstrings cite the spec ids they check."""

import pytest

import httpwire
from httpwire import (
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
    Connection,
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    LocalProtocolError,
    RemoteProtocolError,
    Request,
    Response,
)
from httpwire._errors import ReceiveClosedError


def pull_all(conn):
    out = []
    while True:
        ev = conn.next_event()
        if ev is NEED_DATA or ev is PAUSED:
            out.append(ev)
            return out
        out.append(ev)


def get_request(**kw):
    kw.setdefault("headers", [("Host", "example.com")])
    return Request(method="GET", target="/", **kw)


# ---------------------------------------------------------------- surface and events

def test_package_root_names_present():
    """N-000433..N-000449: every listed name is importable from the root."""
    for name in (
        "CLIENT SERVER NEED_DATA PAUSED IDLE SEND_RESPONSE SEND_BODY DONE MUST_CLOSE CLOSED "
        "MIGHT_SWITCH_PROTOCOL SWITCHED_PROTOCOL ERROR Request InformationalResponse Response "
        "Data EndOfMessage ConnectionClosed Connection LocalProtocolError RemoteProtocolError"
    ).split():
        assert hasattr(httpwire, name), name


def test_role_and_state_values_are_distinct_and_unequal():
    """N-000438, N-000439, N-000440..N-000445."""
    assert CLIENT != SERVER
    assert NEED_DATA != PAUSED
    states = [IDLE, SEND_RESPONSE, SEND_BODY, DONE, MUST_CLOSE, CLOSED,
              MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL, ERROR]
    assert len(set(map(id, states))) == 9
    assert all(a != b for i, a in enumerate(states) for b in states[i + 1:])
    assert not isinstance(NEED_DATA, Request)


def test_error_classes_are_unrelated():
    """N-000446..N-000448."""
    assert not issubclass(LocalProtocolError, RemoteProtocolError)
    assert not issubclass(RemoteProtocolError, LocalProtocolError)
    assert RemoteProtocolError("x").error_status_hint == 400
    assert isinstance(LocalProtocolError("x").error_status_hint, int)


def test_request_defaults_and_bytes_storage():
    """N-000072..N-000076: method/target/version stored as bytes; default version 1.1."""
    r = Request(method="GET", target=bytearray(b"/a"), headers=[("Host", "h")])
    assert r.method == b"GET" and r.target == b"/a" and r.http_version == b"1.1"
    assert type(r.target) is bytes


def test_request_host_rules():
    """N-000077, N-000078, N-000104, N-000105."""
    Request(method="GET", target="/", headers=[], http_version="1.0")  # no Host needed
    with pytest.raises(LocalProtocolError):
        Request(method="GET", target="/", headers=[])  # 1.1 needs Host
    with pytest.raises(LocalProtocolError):
        Request(method="GET", target="/", headers=[("HOST", "a"), ("host", "b")], http_version="1.0")


def test_request_method_and_target_rules():
    """N-000110, N-000111."""
    with pytest.raises(LocalProtocolError):
        Request(method="GE T", target="/", headers=[("Host", "h")])
    with pytest.raises(LocalProtocolError):
        Request(method="GET", target="/a b", headers=[("Host", "h")])
    with pytest.raises(LocalProtocolError):
        Request(method="GET", target="", headers=[("Host", "h")])


def test_status_ranges_and_types():
    """N-000079..N-000083, N-000112, N-000113, N-000460."""
    assert InformationalResponse(101, []).status_code == 101
    with pytest.raises(LocalProtocolError):
        InformationalResponse(200, [])
    with pytest.raises(LocalProtocolError):
        Response(199, [])
    with pytest.raises(LocalProtocolError):
        Response(1000, [])
    with pytest.raises(LocalProtocolError):
        Response("200", [])
    assert Response(999, []).status_code == 999
    r = Response(200, [], reason="OK")
    assert r.reason == b"OK" and r.http_version == b"1.1"


def test_headers_normalized_view_and_raw_items():
    """N-000087..N-000091, N-000467..N-000471."""
    r = Request(method="GET", target="/", headers=[("Host", "h"), ("X-Thing", b"v")])
    assert list(r.headers) == [(b"host", b"h"), (b"x-thing", b"v")]
    assert r.headers[1] == (b"x-thing", b"v")
    assert r.headers.raw_items() == [(b"Host", b"h"), (b"X-Thing", b"v")]


def test_content_length_collapses_and_conflicts():
    """N-000092, N-000093, N-000114..N-000119."""
    r = Request(method="POST", target="/", headers=[
        ("Host", "h"), ("Content-Length", "5"), ("content-length", "5"), ("Content-Length", "5, 5")])
    assert list(r.headers) == [(b"host", b"h"), (b"content-length", b"5")]
    with pytest.raises(LocalProtocolError):
        Request(method="POST", target="/", headers=[("Host", "h"), ("Content-Length", "5, 6")])
    with pytest.raises(LocalProtocolError):
        Request(method="POST", target="/", headers=[("Host", "h"), ("Content-Length", "+5")])
    with pytest.raises(LocalProtocolError):
        Request(method="POST", target="/", headers=[("Host", "h"), ("Content-Length", "1" * 19)])
    Request(method="POST", target="/", headers=[("Host", "h"), ("Content-Length", "1" * 18)])


def test_transfer_encoding_rules():
    """N-000094, N-000096, N-000120, N-000121: chunked only, duplicates refused, status 501."""
    r = Request(method="POST", target="/", headers=[("Host", "h"), ("Transfer-Encoding", "CHUNKED")])
    assert list(r.headers)[1] == (b"transfer-encoding", b"chunked")
    with pytest.raises(LocalProtocolError) as exc:
        Request(method="POST", target="/", headers=[("Host", "h"), ("Transfer-Encoding", "gzip")])
    assert exc.value.error_status_hint == 501
    with pytest.raises(LocalProtocolError) as exc:
        Request(method="POST", target="/", headers=[
            ("Host", "h"), ("Transfer-Encoding", "chunked"), ("Transfer-Encoding", "chunked")])
    assert exc.value.error_status_hint == 501


def test_header_value_and_name_rules():
    """N-000097..N-000100, N-000106..N-000109."""
    for bad in (" lead", "trail ", "a\x00b", "a\rb", "a\nb", "a\x0bb", "a\x0cb", "a\x7fb", "a\x01b"):
        with pytest.raises(LocalProtocolError):
            Request(method="GET", target="/", headers=[("Host", "h"), ("X", bad)])
    Request(method="GET", target="/", headers=[("Host", "h"), ("X", b"a\tb \xff")])
    with pytest.raises(LocalProtocolError):
        Request(method="GET", target="/", headers=[("Host", "h"), ("bad name", "v")])


def test_invalid_construction_leaves_connection_usable():
    """N-000101..N-000103, N-000297..N-000299."""
    conn = Connection(CLIENT)
    with pytest.raises(LocalProtocolError):
        Request(method="GET", target="/", headers=[])
    conn.send(get_request())
    assert conn.our_state is SEND_BODY


def test_data_and_end_of_message_and_closed_fields():
    """N-000084..N-000086, N-000450..N-000466."""
    d = Data(bytearray(b"xy"))
    assert d.chunk_start is False and d.chunk_end is False
    assert EndOfMessage().headers == []
    assert ConnectionClosed() == ConnectionClosed()
    d2 = Data(b"z", chunk_start=1, chunk_end=0)
    assert d2.chunk_start is True and d2.chunk_end is False


# ---------------------------------------------------------------- roles and sending

def test_bad_role_refused():
    """N-000476, N-000477, N-000172, N-000173."""
    with pytest.raises(Exception):
        Connection("client")


def test_initial_states_and_need_data():
    """N-000123..N-000127."""
    c = Connection(SERVER)
    assert c.our_role is SERVER and c.their_role is CLIENT
    assert c.our_state is IDLE and c.their_state is IDLE
    assert c.states[CLIENT] is IDLE and c.states[SERVER] is IDLE
    assert c.next_event() is NEED_DATA
    assert c.their_http_version is None


def test_request_wire_format_host_first_and_raw_casing():
    """N-000128..N-000133, N-000161..N-000164."""
    c = Connection(CLIENT)
    wire = c.send(Request(method="GET", target="/x", headers=[
        ("X-First", "1"), ("Host", "h"), ("Accept", "*/*")]))
    assert wire == b"GET /x HTTP/1.1\r\nHost: h\r\nX-First: 1\r\nAccept: */*\r\n\r\n"
    assert c.our_state is SEND_BODY and c.their_state is SEND_RESPONSE


def test_send_refusals_set_error_and_later_sends_fail():
    """N-000307..N-000310, N-000283..N-000285."""
    c = Connection(CLIENT)
    c.send(get_request())
    with pytest.raises(LocalProtocolError):
        c.send(get_request())  # second request without next cycle
    assert c.our_state is ERROR
    with pytest.raises(LocalProtocolError):
        c.send(EndOfMessage())
    assert c.their_state is SEND_RESPONSE


def test_server_cannot_send_request_and_client_cannot_send_response():
    """N-000283, N-000284."""
    with pytest.raises(LocalProtocolError):
        Connection(SERVER).send(get_request())
    c = Connection(CLIENT)
    c.send(get_request())
    with pytest.raises(LocalProtocolError):
        c.send(Response(200, [("Content-Length", "0")]))


def test_http10_request_cannot_be_sent():
    """N-000156..N-000160."""
    with pytest.raises(LocalProtocolError):
        Connection(CLIENT).send(Request(method="GET", target="/", headers=[], http_version="1.0"))


def test_response_content_length_and_body():
    """N-000140..N-000143, N-000188..N-000199."""
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
    s.next_event()
    s.next_event()
    assert s.send(Response(200, [("Content-Length", "5")])) == b"HTTP/1.1 200 \r\nContent-Length: 5\r\n\r\n"
    assert s.send(Data(b"hello")) == b"hello"
    assert s.send(EndOfMessage()) == b""
    assert s.our_state is DONE and s.their_state is DONE


def test_content_length_short_body_refused_and_overflow_refused():
    """N-000238, N-000239."""
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
    s.next_event(); s.next_event()
    s.send(Response(200, [("Content-Length", "3")]))
    with pytest.raises(LocalProtocolError):
        s.send(EndOfMessage())
    assert s.our_state is ERROR


def test_chunked_response_for_http11_peer_and_trailers():
    """N-000192..N-000197, N-000202."""
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
    s.next_event(); s.next_event()
    head = s.send(Response(200, [("X-A", "1")]))
    assert head == b"HTTP/1.1 200 \r\nX-A: 1\r\nTransfer-Encoding: chunked\r\n\r\n"
    assert s.send(Data(b"abc")) == b"3\r\nabc\r\n"
    assert s.send(EndOfMessage(headers=[("X-T", "9")])) == b"0\r\nX-T: 9\r\n\r\n"


def test_http10_peer_gets_close_delimited_response():
    """N-000203..N-000206, N-000265..N-000269, N-000241."""
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.0\r\n\r\n")
    s.next_event(); s.next_event()
    head = s.send(Response(200, []))
    assert b"Connection: close" in head and b"chunked" not in head
    assert s.send(Data(b"raw")) == b"raw"
    with pytest.raises(LocalProtocolError):
        s.send(EndOfMessage(headers=[("X", "1")]))
    s2 = Connection(SERVER)
    s2.receive_data(b"GET / HTTP/1.0\r\n\r\n")
    s2.next_event(); s2.next_event()
    s2.send(Response(200, [])); s2.send(EndOfMessage())
    assert s2.our_state is MUST_CLOSE and s2.their_state is MUST_CLOSE


def test_head_response_has_framing_headers_but_no_body():
    """N-000215..N-000219 (HEAD gets GET's framing headers, empty body)."""
    s = Connection(SERVER)
    s.receive_data(b"HEAD / HTTP/1.1\r\nHost: h\r\n\r\n")
    s.next_event(); s.next_event()
    assert s.send(Response(200, [("Content-Length", "100")])) == b"HTTP/1.1 200 \r\nContent-Length: 100\r\n\r\n"
    assert s.send(EndOfMessage()) == b""
    s2 = Connection(SERVER)
    s2.receive_data(b"HEAD / HTTP/1.1\r\nHost: h\r\n\r\n")
    s2.next_event(); s2.next_event()
    s2.send(Response(200, [("Content-Length", "100")]))
    with pytest.raises(LocalProtocolError):
        s2.send(Data(b"x"))  # no body may be sent for HEAD


def test_204_has_no_framing_headers():
    """N-000215, N-000216 (204 and 304 always have an empty body)."""
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
    s.next_event(); s.next_event()
    assert s.send(Response(204, [("Content-Length", "0")])) == b"HTTP/1.1 204 \r\n\r\n"
    assert s.send(EndOfMessage()) == b""


def test_transfer_encoding_wins_over_content_length_on_response():
    """N-000207 (the response form of the CF-000003 resolution)."""
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
    s.next_event(); s.next_event()
    head = s.send(Response(200, [("Content-Length", "3"), ("Transfer-Encoding", "chunked")]))
    assert b"Content-Length" not in head and b"Transfer-Encoding: chunked" in head


def test_passthrough_keeps_object_identity_and_counts_length():
    """N-000233..N-000237, N-000502..N-000506."""

    class Blob(object):
        def __init__(self, n):
            self.n = n

        def __len__(self):
            return self.n

    blob = Blob(4)
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
    s.next_event(); s.next_event()
    s.send(Response(200, [("Content-Length", "4")]))
    pieces = s.send_with_data_passthrough(Data(blob))
    assert pieces[0] is blob
    s.send(EndOfMessage())
    # chunked: framing added as separate byte pieces around the same object
    s2 = Connection(SERVER)
    s2.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
    s2.next_event(); s2.next_event()
    s2.send(Response(200, []))
    pieces = s2.send_with_data_passthrough(Data(blob))
    assert pieces[1] is blob and pieces[0] == b"4\r\n" and pieces[2] == b"\r\n"


def test_send_of_non_bytes_payload_without_passthrough():
    """send() accepts a bytes-like payload; a non-bytes object with no buffer is refused."""
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
    s.next_event(); s.next_event()
    s.send(Response(200, [("Content-Length", "2")]))
    assert s.send(Data(bytearray(b"ab"))) == b"ab"


# ---------------------------------------------------------------- receiving

def test_pull_request_and_body_with_content_length():
    """N-000134..N-000155, N-000188..N-000191."""
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nContent-Length: 6\r\n\r\nab")
    req = s.next_event()
    assert isinstance(req, Request) and req.method == b"POST"
    assert s.their_state is SEND_BODY and s.our_state is SEND_RESPONSE
    assert s.next_event() == Data(b"ab")
    assert s.next_event() is NEED_DATA
    s.receive_data(b"cdef")
    assert s.next_event() == Data(b"cdef")
    assert isinstance(s.next_event(), EndOfMessage)
    assert s.their_state is DONE


def test_partial_header_block_is_need_data_then_continues():
    """N-000153..N-000155."""
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHo")
    assert s.next_event() is NEED_DATA
    s.receive_data(b"st: h\r\n\r\n")
    assert isinstance(s.next_event(), Request)


def test_chunked_request_pull_marks_and_trailers():
    """N-000192..N-000197, N-000220..N-000232."""
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n")
    s.next_event()
    s.receive_data(b"5;ext=1\r\nhel")
    d1 = s.next_event()
    assert d1 == Data(b"hel", chunk_start=True, chunk_end=False)
    s.receive_data(b"lo\r\n3\r\nabc\r\n0\r\nX-T: 1\r\n\r\n")
    d2 = s.next_event()
    assert d2 == Data(b"lo", chunk_start=False, chunk_end=True)
    d3 = s.next_event()
    assert d3 == Data(b"abc", chunk_start=True, chunk_end=True)
    eom = s.next_event()
    assert isinstance(eom, EndOfMessage) and eom.headers.raw_items() == [(b"X-T", b"1")]


def test_chunk_size_grammar_refusals():
    """N-000242..N-000245."""
    for bad in (b"5 \r\nhello\r\n", b"zz\r\n", b"5\r\nhelloXX", b"5\r\nhello\n"):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n")
        s.next_event()
        s.receive_data(bad)
        with pytest.raises(RemoteProtocolError):
            while True:
                ev = s.next_event()
                if ev is NEED_DATA:
                    raise AssertionError("expected refusal for %r" % (bad,))
        assert s.their_state is ERROR


def test_lone_lf_line_endings_accepted_and_obsolete_folding():
    """N-000165, N-000167..N-000169."""
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\nHost: h\nX-Long: one\n   two\t\tthree\n\n")
    req = s.next_event()
    # leading run of spaces/tabs on the continuation becomes one space; inner tabs are kept
    assert req.headers.raw_items() == [(b"Host", b"h"), (b"X-Long", b"one two\t\tthree")]


def test_continuation_without_header_refused():
    """N-000174..N-000176."""
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\n Host: h\r\n\r\n")
    with pytest.raises(RemoteProtocolError):
        s.next_event()
    assert s.their_state is ERROR


def test_leading_space_or_control_byte_fails_at_once():
    """N-000177..N-000179."""
    for lead in (b" GET", b"\r\nGET"):
        s = Connection(SERVER)
        s.receive_data(lead)
        with pytest.raises(RemoteProtocolError):
            s.next_event()


def test_error_state_is_sticky_and_send_still_works():
    """N-000302..N-000306, N-000329..N-000331."""
    s = Connection(SERVER)
    s.receive_data(b"GARBAGE\r\n\r\n")
    with pytest.raises(RemoteProtocolError):
        s.next_event()
    assert s.their_state is ERROR and s.our_state is IDLE
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
    with pytest.raises(RemoteProtocolError):
        s.next_event()
    resp = s.send(Response(400, [("Content-Length", "0")]))
    assert b"Connection: close" in resp


def test_incomplete_header_block_over_limit_is_431():
    """N-000316..N-000323."""
    s = Connection(SERVER, max_incomplete_event_size=16)
    s.receive_data(b"GET / HTTP/1.1\r\nX-Big: " + b"a" * 40)
    with pytest.raises(RemoteProtocolError) as exc:
        s.next_event()
    assert exc.value.error_status_hint == 431
    assert s.their_state is ERROR


def test_complete_block_larger_than_limit_is_still_parsed():
    """N-000316: the limit applies only while the event is incomplete."""
    s = Connection(SERVER, max_incomplete_event_size=16)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\nX-Big: " + b"a" * 40 + b"\r\n\r\n")
    assert isinstance(s.next_event(), Request)


def test_default_incomplete_limit_is_8kib():
    """CF-000048 resolution: default limit is 8 KiB."""
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\n" + b"X: " + b"a" * (8 * 1024 + 10))
    with pytest.raises(RemoteProtocolError) as exc:
        s.next_event()
    assert exc.value.error_status_hint == 431


# ---------------------------------------------------------------- close and shutdown

def test_feed_after_receive_closed_is_runtime_error():
    """N-000180..N-000182, N-000348."""
    s = Connection(SERVER)
    s.receive_data(b"")
    with pytest.raises(ReceiveClosedError) as exc:
        s.receive_data(b"x")
    assert not isinstance(exc.value, (LocalProtocolError, RemoteProtocolError))


def test_peer_close_from_idle_yields_connection_closed():
    """N-000339..N-000341, N-000336."""
    s = Connection(SERVER)
    s.receive_data(b"")
    assert isinstance(s.next_event(), ConnectionClosed)
    assert isinstance(s.next_event(), ConnectionClosed)
    assert s.their_state is CLOSED and s.our_state is MUST_CLOSE


def test_peer_close_mid_body_is_remote_error():
    """N-000324, N-000325."""
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nContent-Length: 9\r\n\r\nabc")
    s.next_event(); s.next_event()
    s.receive_data(b"")
    with pytest.raises(RemoteProtocolError):
        s.next_event()


def test_close_delimited_response_ends_on_receive_close():
    """N-000208..N-000214: HTTP/1.0 style body ends at the empty feed; then connection-closed."""
    c = Connection(CLIENT)
    c.send(get_request())
    c.send(EndOfMessage())
    c.receive_data(b"HTTP/1.0 200 OK\r\n\r\nbody")
    assert isinstance(c.next_event(), Response)
    assert c.next_event() == Data(b"body")
    c.receive_data(b"")
    assert isinstance(c.next_event(), EndOfMessage)
    assert isinstance(c.next_event(), ConnectionClosed)
    assert c.our_state is MUST_CLOSE


def test_connection_closed_send_rules():
    """N-000334, N-000335, N-000345, N-000346."""
    c = Connection(CLIENT)
    c.send(get_request())
    with pytest.raises(LocalProtocolError):
        c.send(ConnectionClosed())
    c2 = Connection(CLIENT)
    assert c2.send(ConnectionClosed()) == b""
    assert c2.our_state is CLOSED


# ---------------------------------------------------------------- keep-alive and cycles

def test_keep_alive_cycle_round_trip():
    """N-000250..N-000254, N-000270, N-000271, N-000259."""
    c = Connection(CLIENT)
    s = Connection(SERVER)
    for _ in range(2):
        s.receive_data(c.send(get_request()))
        c.send(EndOfMessage())
        assert isinstance(s.next_event(), Request)
        assert isinstance(s.next_event(), EndOfMessage)
        s.send(Response(200, [("Content-Length", "2")]))
        s.send(Data(b"ok"))
        s.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nok")
        assert isinstance(c.next_event(), Response)
        assert c.next_event() == Data(b"ok")
        assert isinstance(c.next_event(), EndOfMessage)
        assert c.our_state is DONE and s.our_state is DONE
        c.start_next_cycle()
        s.start_next_cycle()
        assert c.our_state is IDLE and s.our_state is IDLE


def test_connection_close_request_disables_keep_alive():
    """N-000259..N-000264, N-000265..N-000269."""
    c = Connection(CLIENT)
    s = Connection(SERVER)
    s.receive_data(c.send(get_request(headers=[("Host", "h"), ("Connection", "close")])))
    c.send(EndOfMessage())
    s.next_event(); s.next_event()
    head = s.send(Response(200, [("Content-Length", "0"), ("Connection", "keep-alive")]))
    assert b"keep-alive" not in head.lower()
    assert b"Connection: close" in head
    s.send(EndOfMessage())
    assert s.our_state is MUST_CLOSE


def test_client_pipelining_refused_and_start_next_cycle_is_recoverable():
    """N-000272..N-000274, N-000280..N-000282, N-000300."""
    c = Connection(CLIENT)
    c.send(get_request())
    c.send(EndOfMessage())
    with pytest.raises(LocalProtocolError):
        c.start_next_cycle()
    assert c.our_state is DONE  # refusal changed nothing
    c2 = Connection(CLIENT)
    c2.send(get_request())
    c2.send(EndOfMessage())
    c2.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
    c2.next_event(); c2.next_event()
    c2.start_next_cycle()
    assert c2.our_state is IDLE


def test_pipelined_bytes_wait_for_next_cycle():
    """N-000275..N-000279, N-000288: stored pipelined bytes are PAUSED until the next cycle."""
    s = Connection(SERVER)
    s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\nGET /2 HTTP/1.1\r\nHost: h\r\n\r\n")
    assert isinstance(s.next_event(), Request)
    assert isinstance(s.next_event(), EndOfMessage)
    assert s.their_state is DONE
    assert s.next_event() is PAUSED  # second request is stored but not parsed yet
    assert s.next_event() is PAUSED
    s.send(Response(200, [("Content-Length", "0")]))
    s.send(EndOfMessage())
    assert s.our_state is DONE and s.their_state is DONE
    s.start_next_cycle()
    second = s.next_event()
    assert isinstance(second, Request) and second.target == b"/2"


# ---------------------------------------------------------------- 100-continue and switching

def test_expect_100_continue_flags():
    """N-000354..N-000359."""
    c = Connection(CLIENT)
    c.send(get_request(headers=[("Host", "h"), ("Expect", "100-Continue")]))
    assert c.client_is_waiting_for_100_continue is True
    assert c.they_are_waiting_for_100_continue is False
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nExpect: 100-continue\r\nContent-Length: 1\r\n\r\n")
    s.next_event()
    assert s.they_are_waiting_for_100_continue is True
    assert s.send(InformationalResponse(100, [])) == b"HTTP/1.1 100 \r\n\r\n"
    assert s.they_are_waiting_for_100_continue is False
    assert s.our_state is SEND_RESPONSE
    s.send(Response(200, [("Content-Length", "0")]))


def test_expect_on_http10_request_sets_no_flags():
    """N-000357 (PRD) over N-000491 (interface) — see NOTES.md."""
    s = Connection(SERVER)
    s.receive_data(b"POST / HTTP/1.0\r\nExpect: 100-continue\r\nContent-Length: 0\r\n\r\n")
    s.next_event()
    assert s.client_is_waiting_for_100_continue is False
    assert s.they_are_waiting_for_100_continue is False


def test_connect_accept_switches_both_sides_and_trailing_data_preserved():
    """N-000364..N-000365, N-000381..N-000387, N-000399."""
    c = Connection(CLIENT)
    s = Connection(SERVER)
    s.receive_data(c.send(Request(method="CONNECT", target="example.com:443", headers=[("Host", "example.com:443")])))
    c.send(EndOfMessage())
    assert c.our_state is MIGHT_SWITCH_PROTOCOL
    assert isinstance(s.next_event(), Request)
    assert isinstance(s.next_event(), EndOfMessage)
    assert s.next_event() is PAUSED
    assert s.send(Response(200, [])) == b"HTTP/1.1 200 \r\n\r\n"
    assert s.our_state is SWITCHED_PROTOCOL
    c.receive_data(b"HTTP/1.1 200 OK\r\n\r\nTUNNEL")
    assert isinstance(c.next_event(), Response)
    assert c.our_state is SWITCHED_PROTOCOL and c.their_state is SWITCHED_PROTOCOL
    assert c.next_event() is PAUSED
    assert c.trailing_data == (b"TUNNEL", False)
    with pytest.raises(LocalProtocolError):
        s.send(EndOfMessage())
    assert s.our_state is ERROR and s.their_state is SWITCHED_PROTOCOL


def test_connect_non_200_2xx_is_denial_and_http_continues():
    """N-000394..N-000398 (only 200 accepts CONNECT), N-000378..N-000380."""
    c = Connection(CLIENT)
    s = Connection(SERVER)
    s.receive_data(c.send(Request(method="CONNECT", target="h:1", headers=[("Host", "h:1")])))
    c.send(EndOfMessage())
    s.next_event(); s.next_event()
    s.send(Response(204, []))
    s.send(EndOfMessage())
    assert c.our_state is MIGHT_SWITCH_PROTOCOL
    c.receive_data(b"HTTP/1.1 204 \r\n\r\n")
    assert isinstance(c.next_event(), Response)
    assert c.our_state is DONE
    assert isinstance(c.next_event(), EndOfMessage)
    assert c.start_next_cycle() is None


def test_upgrade_accepted_with_101_informational():
    """N-000366..N-000368, N-000372."""
    c = Connection(CLIENT)
    s = Connection(SERVER)
    s.receive_data(c.send(Request(method="GET", target="/ws", headers=[
        ("Host", "h"), ("Connection", "Upgrade"), ("Upgrade", "websocket")])))
    c.send(EndOfMessage())
    s.next_event(); s.next_event()
    s.send(InformationalResponse(101, [("Upgrade", "websocket"), ("Connection", "Upgrade")]))
    assert s.our_state is SWITCHED_PROTOCOL
    c.receive_data(b"HTTP/1.1 101 Switching\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n\r\n")
    assert isinstance(c.next_event(), InformationalResponse)
    assert c.our_state is SWITCHED_PROTOCOL


def test_switch_proposal_pause_then_close_after_denial():
    """N-000388..N-000391."""
    c = Connection(CLIENT)
    s = Connection(SERVER)
    s.receive_data(c.send(Request(method="GET", target="/x", headers=[
        ("Host", "h"), ("Upgrade", "foo")])))
    c.send(EndOfMessage())
    s.next_event(); s.next_event()
    s.receive_data(b"")
    assert s.next_event() is PAUSED  # switch proposal pending: the close is not pulled yet
    s.send(Response(200, [("Content-Length", "0")]))  # denial
    s.send(EndOfMessage())
    assert s.their_state is DONE
    assert isinstance(s.next_event(), ConnectionClosed)  # after denial the close is pulled


# ---------------------------------------------------------------- send failure

def test_send_failed_marks_error_and_peer_done_becomes_must_close():
    """N-000312..N-000315, N-000311."""
    c = Connection(CLIENT)
    s = Connection(SERVER)
    s.receive_data(c.send(get_request()))
    c.send(EndOfMessage())
    s.next_event(); s.next_event()
    s.send(Response(200, [("Content-Length", "0")]))
    s.send(EndOfMessage())
    assert s.their_state is SEND_BODY or s.their_state is DONE
    c.send_failed()
    assert c.our_state is ERROR
    with pytest.raises(LocalProtocolError):
        c.send(EndOfMessage())
    s2 = Connection(SERVER)
    s2.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
    s2.next_event(); s2.next_event()
    s2.send(Response(200, [("Content-Length", "0")])); s2.send(EndOfMessage())
    assert s2.their_state is DONE
    c2 = Connection(CLIENT)
    c2.send(get_request()); c2.send(EndOfMessage())
    c2.send_failed()
    assert c2.our_state is ERROR and c2.their_state is SEND_RESPONSE


def test_states_mapping_accessible_by_index_and_role():
    c = Connection(CLIENT)
    assert c.states[0] is IDLE and c.states[CLIENT] is IDLE
    assert c.states[1] is IDLE and c.states[SERVER] is IDLE


def test_keep_alive_off_turns_a_done_client_into_must_close():
    """N-000259..N-000264: the client was DONE when the server's Connection: close arrived."""
    c = Connection(CLIENT)
    c.send(get_request())
    c.send(EndOfMessage())
    assert c.our_state is DONE
    c.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\nConnection: close\r\n\r\n")
    c.next_event()
    c.next_event()
    assert c.their_state is MUST_CLOSE
    assert c.our_state is MUST_CLOSE
    with pytest.raises(LocalProtocolError):
        c.start_next_cycle()
