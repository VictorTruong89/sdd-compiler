"""The library performs no I/O: no sockets, no processes, no third-party imports.

# spec: N-000047, N-000048, N-000049 (no I/O; bytes are the whole network interface)
# spec: N-000037, N-000038, N-000050, N-000051 (zero runtime deps; own parser; no stdlib HTTP delegation)
"""

import ast
import pathlib

PKG = pathlib.Path(__file__).resolve().parent.parent / "httpwire"
FORBIDDEN = {"socket", "subprocess", "ssl", "select", "asyncio", "http", "urllib", "multiprocessing",
             "threading", "selectors"}


def _imported_roots():
    roots = set()
    for path in PKG.glob("*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                roots.update(alias.name.split(".")[0] for alias in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
                roots.add(node.module.split(".")[0])
    return roots


def test_package_imports_no_io_modules():
    assert not (_imported_roots() & FORBIDDEN)


def test_package_imports_only_stdlib_or_itself():
    import sys
    import pytest
    if not hasattr(sys, "stdlib_module_names"):  # Python 3.10+
        pytest.skip("sys.stdlib_module_names needs Python 3.10+")
    stdlib = set(sys.stdlib_module_names)
    for root in _imported_roots():
        assert root == "httpwire" or root in stdlib, root
