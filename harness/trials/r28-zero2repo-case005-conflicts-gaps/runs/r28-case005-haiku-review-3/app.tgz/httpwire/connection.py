"""The bring-your-own-I/O HTTP/1.1 connection object (PRD FP-02..FP-07)."""

import re

from ._sentinels import (
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
)
from .errors import LocalProtocolError, ReceiveAfterCloseError, RemoteProtocolError
from .events import (
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    Request,
    Response,
)
DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 16 * 1024

# Chunk-size line: 1..32 hex digits, optional ";extension", optional blanks.
_CHUNK_SIZE_RE = re.compile(rb"([0-9A-Fa-f]{1,32})(?:;[^\r\n]*)?[ \t]*")
_HTTP_VERSION_TEXT_RE = re.compile(rb"HTTP/([0-9])\.([0-9])")
_STATUS_CODE_RE = re.compile(rb"[0-9]{3}")

_LENGTH = "length"
_CHUNKED = "chunked"
_CLOSE = "close"


class _Body(object):
    """Framing of the body currently produced by one role."""

    __slots__ = ("kind", "remaining", "cstate", "chunk_remaining", "chunk_first")

    def __init__(self, kind, remaining=0):
        self.kind = kind
        self.remaining = remaining
        self.cstate = "size"
        self.chunk_remaining = 0
        self.chunk_first = False


# ---------------------------------------------------------------- helpers

def _is_bytes_like(obj):
    return isinstance(obj, (bytes, bytearray, memoryview))


def _payload_length(data):
    if _is_bytes_like(data):
        return memoryview(data).nbytes
    return len(data)


def _scan_lines(buf):
    """Split off complete lines up to the blank line that ends a block.

    Returns ``(lines, end_offset)`` or ``None`` when the block is unfinished.
    Lines may end in CRLF or a bare LF; the terminator is removed.
    """
    lines = []
    pos = 0
    while True:
        idx = buf.find(b"\n", pos)
        if idx < 0:
            return None
        line = bytes(buf[pos:idx])
        if line.endswith(b"\r"):
            line = line[:-1]
        pos = idx + 1
        if not line:
            return lines, pos
        lines.append(line)


def _parse_header_lines(lines):
    """Turn raw header lines into (name, value) pairs, applying obsolete line folding."""
    pairs = []
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            if not pairs:
                raise RemoteProtocolError("line folding without a preceding header", 400)
            name, value = pairs[-1]
            pairs[-1] = (name, (value + b" " + line.strip(b" \t")).rstrip(b" \t"))
            continue
        name, sep, value = line.partition(b":")
        if not sep:
            raise RemoteProtocolError("header line without a colon", 400)
        pairs.append((name, value.strip(b" \t")))
    return pairs


def _value(triples, name):
    for _raw, lname, value in triples:
        if lname == name:
            return value
    return None


def _tokens(triples, name):
    out = []
    for _raw, lname, value in triples:
        if lname == name:
            for token in value.split(b","):
                token = token.strip(b" \t").lower()
                if token:
                    out.append(token)
    return out


def _framing_for_request(triples):
    cl = _value(triples, b"content-length")
    if cl is not None:
        return _Body(_LENGTH, int(cl))
    if _value(triples, b"transfer-encoding") == b"chunked":
        return _Body(_CHUNKED)
    return _Body(_LENGTH, 0)


def _framing_for_response(triples, status, method):
    if method == b"HEAD" or status in (204, 304) or 100 <= status < 200:
        return _Body(_LENGTH, 0)
    if _value(triples, b"transfer-encoding") == b"chunked":
        return _Body(_CHUNKED)
    cl = _value(triples, b"content-length")
    if cl is not None:
        return _Body(_LENGTH, int(cl))
    return _Body(_CLOSE)


def _with_connection_close(items):
    """Rewrite Connection so it carries ``close`` and no ``keep-alive`` token."""
    tokens = []
    for _raw, lname, value in items:
        if lname == b"connection":
            for token in value.split(b","):
                token = token.strip(b" \t").lower()
                if token and token not in (b"keep-alive", b"close") and token not in tokens:
                    tokens.append(token)
    tokens.append(b"close")
    new_value = b", ".join(tokens)
    out = []
    placed = False
    for item in items:
        if item[1] == b"connection":
            if not placed:
                out.append((item[0], b"connection", new_value))
                placed = True
            continue
        out.append(item)
    if not placed:
        out.append((b"Connection", b"connection", new_value))
    return out


def _encode_request_head(event):
    items = event._headers_triples()
    host = [i for i in items if i[1] == b"host"]
    rest = [i for i in items if i[1] != b"host"]
    lines = [b"%s %s HTTP/1.1\r\n" % (event.method, event.target)]
    for raw, _lname, value in host + rest:
        lines.append(b"%s: %s\r\n" % (raw, value))
    lines.append(b"\r\n")
    return b"".join(lines)


def _encode_response_head(event, items):
    lines = [b"HTTP/1.1 %d %s\r\n" % (event.status_code, event.reason)]
    for raw, _lname, value in items:
        lines.append(b"%s: %s\r\n" % (raw, value))
    lines.append(b"\r\n")
    return b"".join(lines)


def _encode_data(body, data, n):
    """Return the pieces for one data payload of length ``n`` (no state change)."""
    if body.kind == _LENGTH:
        if n > body.remaining:
            raise LocalProtocolError("data exceeds the declared Content-Length")
        return ([data] if n else [])
    if body.kind == _CLOSE:
        return ([data] if n else [])
    if n == 0:
        return []
    return [b"%x\r\n" % n, data, b"\r\n"]


# ------------------------------------------------------------- connection

class Connection(object):
    """One HTTP/1.1 connection in the CLIENT or SERVER role. Performs no I/O."""

    def __init__(self, role, max_incomplete_event_size=DEFAULT_MAX_INCOMPLETE_EVENT_SIZE):
        if role is not CLIENT and role is not SERVER:
            raise ValueError("role must be CLIENT or SERVER")
        if (
            isinstance(max_incomplete_event_size, bool)
            or not isinstance(max_incomplete_event_size, int)
            or max_incomplete_event_size <= 0
        ):
            raise ValueError("max_incomplete_event_size must be a positive int")
        self._role = role
        self._their_role = SERVER if role is CLIENT else CLIENT
        self._states = {CLIENT: IDLE, SERVER: IDLE}
        self._buf = bytearray()
        self._closed = False
        self._max_incomplete = max_incomplete_event_size
        self._their_version = None
        self._reset_cycle()

    def _reset_cycle(self):
        self._request_method = None
        self._keep_alive = True
        self._proposed = False
        self._proposal_connect = False
        self._proposal_upgrade = False
        self._switch_outcome = None  # None, "accepted" or "denied"
        self._bodies = {CLIENT: None, SERVER: None}
        self._client_waiting = False

    # ------------------------------------------------------------ queries

    @property
    def our_role(self):
        return self._role

    @property
    def their_role(self):
        return self._their_role

    @property
    def our_state(self):
        return self._states[self._role]

    @property
    def their_state(self):
        return self._states[self._their_role]

    @property
    def states(self):
        return dict(self._states)

    @property
    def their_http_version(self):
        return self._their_version

    @property
    def client_is_waiting_for_100_continue(self):
        return bool(self._client_waiting)

    @property
    def they_are_waiting_for_100_continue(self):
        return bool(self._client_waiting) and self._role is SERVER

    @property
    def trailing_data(self):
        return (bytes(self._buf), bool(self._closed))

    # ------------------------------------------------------------ receive

    def receive_data(self, data):
        if not _is_bytes_like(data):
            raise TypeError("data must be a bytes-like object")
        chunk = bytes(data)
        if not chunk:
            self._closed = True
            return None
        if self._closed:
            raise ReceiveAfterCloseError("data received after the peer closed its sending side")
        self._buf += chunk
        return None

    def next_event(self):
        their = self._their_role
        st = self._states[their]
        if st is ERROR:
            raise RemoteProtocolError("peer previously violated the protocol", 400)
        if st is CLOSED:
            return ConnectionClosed()
        if st is MIGHT_SWITCH_PROTOCOL or st is SWITCHED_PROTOCOL:
            return PAUSED
        if st is DONE or st is MUST_CLOSE:
            if self._buf:
                return PAUSED
            if self._closed:
                return self._pull_close()
            return NEED_DATA

        try:
            if st is IDLE:
                event = self._pull_request() if self._role is SERVER else None
            elif st is SEND_RESPONSE:
                event = self._pull_response()
            elif st is SEND_BODY:
                event = self._pull_body()
            else:
                event = None
        except RemoteProtocolError:
            self._enter_error(their)
            raise

        if event is not None:
            return event
        if self._closed:
            if st is IDLE and (self._role is CLIENT or not self._buf):
                return self._pull_close()
            self._enter_error(their)
            raise RemoteProtocolError("connection closed in the middle of a message", 400)
        return NEED_DATA

    def _check_incomplete_size(self):
        if len(self._buf) > self._max_incomplete:
            raise RemoteProtocolError("incomplete event exceeds the size limit", 431)

    def _pull_head(self):
        buf = self._buf
        if not buf:
            return None
        first = buf[0]
        if first == 0x20 or first < 0x21:
            raise RemoteProtocolError("message starts with a space or control byte", 400)
        scanned = _scan_lines(buf)
        if scanned is None:
            self._check_incomplete_size()
            return None
        lines, end = scanned
        del buf[:end]
        if not lines:
            raise RemoteProtocolError("empty start line", 400)
        return lines[0], lines[1:]

    def _pull_request(self):
        head = self._pull_head()
        if head is None:
            return None
        line, header_lines = head
        parts = line.split(b" ")
        if len(parts) != 3:
            raise RemoteProtocolError("malformed request line", 400)
        method, target, version_text = parts
        m = _HTTP_VERSION_TEXT_RE.fullmatch(version_text)
        if m is None:
            raise RemoteProtocolError("malformed HTTP version", 400)
        version = m.group(1) + b"." + m.group(2)
        pairs = _parse_header_lines(header_lines)
        event = Request._make(RemoteProtocolError, method, target, pairs, version)
        triples = event._headers_triples()
        self._their_version = version
        self._commit_request(event, triples, _framing_for_request(triples))
        self._normalize()
        return event

    def _pull_response(self):
        head = self._pull_head()
        if head is None:
            return None
        line, header_lines = head
        parts = line.split(b" ", 2)
        if len(parts) < 2:
            raise RemoteProtocolError("malformed status line", 400)
        m = _HTTP_VERSION_TEXT_RE.fullmatch(parts[0])
        if m is None:
            raise RemoteProtocolError("malformed HTTP version", 400)
        version = m.group(1) + b"." + m.group(2)
        if _STATUS_CODE_RE.fullmatch(parts[1]) is None:
            raise RemoteProtocolError("malformed status code", 400)
        status = int(parts[1])
        reason = parts[2] if len(parts) == 3 else b""
        pairs = _parse_header_lines(header_lines)
        if 100 <= status < 200:
            event = InformationalResponse._make(RemoteProtocolError, status, pairs, version, reason)
        elif status >= 200:
            event = Response._make(RemoteProtocolError, status, pairs, version, reason)
        else:
            raise RemoteProtocolError("status code out of range", 400)

        outcome = self._switch_result(event)
        nxt = self._producer_next(SERVER, event)
        if nxt is None:
            raise RemoteProtocolError("response not allowed in the current state", 400)
        triples = event._headers_triples()
        self._states[SERVER] = nxt
        self._client_waiting = False
        if isinstance(event, Response):
            self._their_version = version
            body = _framing_for_response(triples, status, self._request_method)
            if nxt is SEND_BODY:
                self._bodies[SERVER] = body
            else:
                body = None
            if nxt is SWITCHED_PROTOCOL:
                self._keep_alive = False
            else:
                self._keep_alive = (
                    self._keep_alive
                    and version == b"1.1"
                    and b"close" not in _tokens(triples, b"connection")
                    and body is not None
                    and body.kind != _CLOSE
                )
        self._apply_outcome(outcome)
        self._normalize()
        return event

    def _pull_body(self):
        their = self._their_role
        body = self._bodies[their]
        buf = self._buf
        if body.kind == _LENGTH:
            if body.remaining == 0:
                return self._finish_body(EndOfMessage())
            if buf:
                n = min(len(buf), body.remaining)
                data = bytes(buf[:n])
                del buf[:n]
                body.remaining -= n
                return Data(data)
            if self._closed:
                raise RemoteProtocolError("connection closed in the middle of a Content-Length body", 400)
            return None
        if body.kind == _CLOSE:
            if buf:
                data = bytes(buf)
                buf.clear()
                return Data(data)
            if self._closed:
                return self._finish_body(EndOfMessage())
            return None

        # chunked
        while True:
            if body.cstate == "size":
                idx = buf.find(b"\n")
                if idx < 0:
                    self._check_incomplete_size()
                    if self._closed:
                        raise RemoteProtocolError("connection closed in the middle of a chunked body", 400)
                    return None
                line = bytes(buf[:idx])
                if line.endswith(b"\r"):
                    line = line[:-1]
                m = _CHUNK_SIZE_RE.fullmatch(line)
                if m is None:
                    raise RemoteProtocolError("invalid chunk-size line", 400)
                del buf[:idx + 1]
                size = int(m.group(1), 16)
                if size == 0:
                    body.cstate = "trailers"
                else:
                    body.cstate = "data"
                    body.chunk_remaining = size
                    body.chunk_first = True
                continue
            if body.cstate == "data":
                if buf:
                    n = min(len(buf), body.chunk_remaining)
                    data = bytes(buf[:n])
                    del buf[:n]
                    body.chunk_remaining -= n
                    start = body.chunk_first
                    body.chunk_first = False
                    end = body.chunk_remaining == 0
                    if end:
                        body.cstate = "data_end"
                    return Data(data, chunk_start=start, chunk_end=end)
                if self._closed:
                    raise RemoteProtocolError("connection closed in the middle of a chunk", 400)
                return None
            if body.cstate == "data_end":
                if len(buf) < 2:
                    if buf and buf[0] != 0x0D:
                        raise RemoteProtocolError("chunk data not followed by CRLF", 400)
                    if self._closed:
                        raise RemoteProtocolError("connection closed in the middle of a chunk", 400)
                    return None
                if bytes(buf[:2]) != b"\r\n":
                    raise RemoteProtocolError("chunk data not followed by CRLF", 400)
                del buf[:2]
                body.cstate = "size"
                continue
            # trailers after the zero-size chunk
            scanned = _scan_lines(buf)
            if scanned is None:
                self._check_incomplete_size()
                if self._closed:
                    raise RemoteProtocolError("connection closed in the middle of trailers", 400)
                return None
            lines, end = scanned
            del buf[:end]
            trailers = EndOfMessage._make(RemoteProtocolError, _parse_header_lines(lines))
            return self._finish_body(trailers)

    def _pull_close(self):
        self._states[self._their_role] = CLOSED
        self._normalize()
        return ConnectionClosed()

    def _finish_body(self, event):
        their = self._their_role
        nxt = self._producer_next(their, event)
        if nxt is None:
            raise RemoteProtocolError("end of message not allowed in the current state", 400)
        self._states[their] = nxt
        self._bodies[their] = None
        self._normalize()
        return event

    # --------------------------------------------------------------- send

    def send(self, event):
        """Encode ``event`` to bytes (b'' when it produces none)."""
        if isinstance(event, Data) and not _is_bytes_like(event.data):
            payload = bytes(memoryview(event.data))  # TypeError for non-buffer objects
            event = Data(payload, chunk_start=event.chunk_start, chunk_end=event.chunk_end)
        return b"".join(self._send_event(event))

    def send_with_data_passthrough(self, event):
        """Like send(), but returns a list of pieces; opaque payloads are passed through by identity."""
        if isinstance(event, Data) and isinstance(event.data, str):
            raise TypeError("data payload must be bytes-like or an object with a length")
        return self._send_event(event)

    def _send_event(self, event):
        if self._states[self._role] is ERROR:
            raise LocalProtocolError("connection is in the ERROR state; send refused", 400)
        try:
            return self._do_send(event)
        except LocalProtocolError:
            self._enter_error(self._role)
            raise

    def _do_send(self, event):
        role = self._role
        if isinstance(event, ConnectionClosed):
            nxt = self._producer_next(role, event)
            if nxt is None:
                raise LocalProtocolError("connection-closed not allowed in the current state", 400)
            self._states[role] = nxt
            self._normalize()
            return []

        if isinstance(event, Request):
            if role is not CLIENT:
                raise LocalProtocolError("a server cannot send a request", 400)
            if self._producer_next(CLIENT, event) is None:
                raise LocalProtocolError("request not allowed in the current state", 400)
            if event.http_version != b"1.1":
                raise LocalProtocolError("only HTTP/1.1 requests can be sent", 400)
            triples = event._headers_triples()
            pieces = [_encode_request_head(event)]
            self._commit_request(event, triples, _framing_for_request(triples))
            self._normalize()
            return pieces

        if isinstance(event, (InformationalResponse, Response)):
            if role is not SERVER:
                raise LocalProtocolError("a client cannot send a response", 400)
            if event.http_version != b"1.1":
                raise LocalProtocolError("only HTTP/1.1 responses can be sent", 400)
            nxt = self._producer_next(SERVER, event)
            if nxt is None:
                raise LocalProtocolError("response not allowed in the current state", 400)
            outcome = self._switch_result(event)
            items = event._headers_triples()
            if isinstance(event, InformationalResponse):
                pieces = [_encode_response_head(event, items)]
                self._states[SERVER] = nxt
                self._client_waiting = False
                self._apply_outcome(outcome)
                self._normalize()
                return pieces
            if nxt is SWITCHED_PROTOCOL:
                out, body, keep = items, None, False
            else:
                out, body, keep = self._plan_response(event, items)
            pieces = [_encode_response_head(event, out)]
            self._states[SERVER] = nxt
            self._client_waiting = False
            self._bodies[SERVER] = body if nxt is SEND_BODY else None
            self._keep_alive = keep
            self._apply_outcome(outcome)
            self._normalize()
            return pieces

        if isinstance(event, Data):
            if self._states[role] is not SEND_BODY:
                raise LocalProtocolError("data not allowed in the current state", 400)
            body = self._bodies[role]
            n = _payload_length(event.data)
            pieces = _encode_data(body, event.data, n)
            if body.kind == _LENGTH:
                body.remaining -= n
            return pieces

        if isinstance(event, EndOfMessage):
            if self._states[role] is not SEND_BODY:
                raise LocalProtocolError("end of message not allowed in the current state", 400)
            body = self._bodies[role]
            trailers = event._headers_triples()
            if body.kind == _LENGTH and body.remaining != 0:
                raise LocalProtocolError("end of message before the declared Content-Length was sent")
            if trailers and body.kind != _CHUNKED:
                raise LocalProtocolError("trailing headers need chunked framing")
            if trailers and self._their_version == b"1.0":
                raise LocalProtocolError("trailing headers cannot be sent to an HTTP/1.0 peer")
            nxt = self._producer_next(role, event)
            if nxt is None:
                raise LocalProtocolError("end of message not allowed in the current state", 400)
            pieces = []
            if body.kind == _CHUNKED:
                pieces.append(b"0\r\n")
                for raw, _lname, value in trailers:
                    pieces.append(b"%s: %s\r\n" % (raw, value))
                pieces.append(b"\r\n")
            self._states[role] = nxt
            self._bodies[role] = None
            self._normalize()
            return pieces

        raise LocalProtocolError("unknown event type", 400)

    def _plan_response(self, event, items):
        """Decide wire headers, body framing and keep-alive for a final response."""
        method = self._request_method
        status = event.status_code
        peer11 = self._their_version == b"1.1"
        response_close = b"close" in _tokens(items, b"connection")
        out = list(items)
        if status in (204, 304):
            body = _Body(_LENGTH, 0)
            close_framing = False
        else:
            has_te = _value(items, b"transfer-encoding") is not None
            cl = _value(items, b"content-length")
            if has_te:
                if peer11:
                    body = _Body(_CHUNKED)
                    close_framing = False
                    out = [i for i in out if i[1] != b"content-length"]
                else:
                    body = _Body(_CLOSE)
                    close_framing = True
                    out = [i for i in out if i[1] not in (b"content-length", b"transfer-encoding")]
            elif cl is not None:
                body = _Body(_LENGTH, int(cl))
                close_framing = False
            elif peer11:
                body = _Body(_CHUNKED)
                close_framing = False
                out.append((b"Transfer-Encoding", b"transfer-encoding", b"chunked"))
            else:
                body = _Body(_CLOSE)
                close_framing = True
            if method == b"HEAD":
                body = _Body(_LENGTH, 0)
        keep = self._keep_alive and peer11 and not response_close and not close_framing
        if not keep:
            out = _with_connection_close(out)
        return out, body, keep

    # ------------------------------------------------------ state machine

    def _producer_next(self, role, event):
        """Next state of ``role`` after it produces ``event``; None if illegal."""
        st = self._states[role]
        if isinstance(event, ConnectionClosed):
            if st is IDLE or st is DONE or st is MUST_CLOSE:
                return CLOSED
            return None
        if role is CLIENT:
            if isinstance(event, Request):
                return SEND_BODY if st is IDLE else None
            if isinstance(event, Data):
                return SEND_BODY if st is SEND_BODY else None
            if isinstance(event, EndOfMessage):
                return self._client_eom_next() if st is SEND_BODY else None
            return None
        # SERVER
        if isinstance(event, InformationalResponse):
            if st is not SEND_RESPONSE:
                return None
            return SWITCHED_PROTOCOL if self._is_accepting(event) else SEND_RESPONSE
        if isinstance(event, Response):
            if st is SEND_RESPONSE and self._is_accepting(event):
                return SWITCHED_PROTOCOL
            if st is IDLE or st is SEND_RESPONSE:
                return SEND_BODY
            return None
        if isinstance(event, Data):
            return SEND_BODY if st is SEND_BODY else None
        if isinstance(event, EndOfMessage):
            return DONE if st is SEND_BODY else None
        return None

    def _client_eom_next(self):
        if not self._proposed:
            return DONE
        if self._switch_outcome == "accepted":
            return SWITCHED_PROTOCOL
        if self._switch_outcome == "denied":
            return DONE
        return MIGHT_SWITCH_PROTOCOL

    def _is_accepting(self, event):
        if self._states[SERVER] is not SEND_RESPONSE:
            return False
        if isinstance(event, InformationalResponse):
            return event.status_code == 101 and self._proposal_upgrade
        if isinstance(event, Response):
            return event.status_code == 200 and self._proposal_connect
        return False

    def _switch_result(self, event):
        if not self._proposed:
            return None
        if self._is_accepting(event):
            return "accepted"
        if isinstance(event, Response):
            return "denied"
        return None

    def _apply_outcome(self, outcome):
        if outcome is None:
            return
        self._switch_outcome = outcome
        if self._states[CLIENT] is MIGHT_SWITCH_PROTOCOL:
            self._states[CLIENT] = SWITCHED_PROTOCOL if outcome == "accepted" else DONE

    def _commit_request(self, event, triples, body):
        """Record a request sent or pulled (the client is the producer)."""
        self._states[CLIENT] = SEND_BODY
        self._bodies[CLIENT] = body
        self._request_method = event.method
        connect = event.method == b"CONNECT"
        upgrade = _value(triples, b"upgrade") is not None
        self._proposal_connect = connect
        self._proposal_upgrade = upgrade
        self._proposed = connect or upgrade
        if event.http_version != b"1.1" or b"close" in _tokens(triples, b"connection"):
            self._keep_alive = False
        if event.http_version == b"1.1" and b"100-continue" in _tokens(triples, b"expect"):
            self._client_waiting = True
        if self._states[SERVER] is IDLE:
            self._states[SERVER] = SEND_RESPONSE

    def _enter_error(self, role):
        self._states[role] = ERROR
        self._keep_alive = False
        self._normalize()

    def _normalize(self):
        states = self._states
        changed = True
        while changed:
            changed = False
            for a, b in ((CLIENT, SERVER), (SERVER, CLIENT)):
                if states[a] is CLOSED and (states[b] is IDLE or states[b] is DONE):
                    states[b] = MUST_CLOSE
                    changed = True
                if states[a] is ERROR and states[b] is DONE:
                    states[b] = MUST_CLOSE
                    changed = True
            if not self._keep_alive:
                for r in (CLIENT, SERVER):
                    if states[r] is DONE:
                        states[r] = MUST_CLOSE
                        changed = True

    def start_next_cycle(self):
        if self._states[CLIENT] is not DONE or self._states[SERVER] is not DONE:
            raise LocalProtocolError("cannot start the next cycle: both sides must be DONE", 400)
        self._states[CLIENT] = IDLE
        self._states[SERVER] = IDLE
        self._reset_cycle()
        return None

    def send_failed(self):
        self._enter_error(self._role)
        return None
