"""Singleton marker objects: roles, the nine connection states, and pull results."""


class _Marker(object):
    """A named, identity-compared singleton. Never equal to any other marker."""

    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return self._name


CLIENT = _Marker("CLIENT")
SERVER = _Marker("SERVER")

IDLE = _Marker("IDLE")
SEND_RESPONSE = _Marker("SEND_RESPONSE")
SEND_BODY = _Marker("SEND_BODY")
DONE = _Marker("DONE")
MUST_CLOSE = _Marker("MUST_CLOSE")
CLOSED = _Marker("CLOSED")
MIGHT_SWITCH_PROTOCOL = _Marker("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = _Marker("SWITCHED_PROTOCOL")
ERROR = _Marker("ERROR")

NEED_DATA = _Marker("NEED_DATA")
PAUSED = _Marker("PAUSED")
