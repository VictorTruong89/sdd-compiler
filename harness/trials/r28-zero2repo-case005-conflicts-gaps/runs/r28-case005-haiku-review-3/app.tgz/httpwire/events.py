"""The six HTTP event types (PRD FP-01)."""

from .errors import LocalProtocolError
from .headers import Headers, TARGET_RE, TOKEN_RE, VERSION_RE, build_headers, to_bytes


def _check_version(value, err):
    value = to_bytes(value, err, "HTTP version")
    if VERSION_RE.fullmatch(value) is None:
        raise err("invalid HTTP version %r" % (value,))
    return value


def _check_status(status, low, high, err):
    if isinstance(status, bool) or not isinstance(status, int):
        raise err("status code must be an integer")
    status = int(status)
    if not low <= status <= high:
        raise err("status code %d is out of range %d-%d" % (status, low, high))
    return status


def _check_reason(reason, err):
    reason = to_bytes(reason, err, "reason phrase")
    if b"\r" in reason or b"\n" in reason or b"\0" in reason:
        raise err("reason phrase contains a forbidden byte")
    return reason


class _Event(object):
    _fields = ()

    @classmethod
    def _make(cls, err, *args, **kwargs):
        """Build an event, reporting invalid input with ``err`` (used by the parser)."""
        obj = cls.__new__(cls)
        obj._init(err, *args, **kwargs)
        return obj

    def _headers_triples(self):
        return self.headers._triples()

    def __eq__(self, other):
        if type(other) is not type(self):
            return NotImplemented
        return all(getattr(self, f) == getattr(other, f) for f in self._fields)

    __hash__ = None

    def __repr__(self):
        return "%s(%s)" % (
            type(self).__name__,
            ", ".join("%s=%r" % (f, getattr(self, f)) for f in self._fields),
        )


class Request(_Event):
    _fields = ("method", "target", "headers", "http_version")

    def __init__(self, method, target, headers, http_version=b"1.1"):
        self._init(LocalProtocolError, method, target, headers, http_version)

    def _init(self, err, method, target, headers, http_version=b"1.1"):
        method = to_bytes(method, err, "method")
        if TOKEN_RE.fullmatch(method) is None:
            raise err("invalid method %r" % (method,))
        target = to_bytes(target, err, "request target")
        if TARGET_RE.fullmatch(target) is None:
            raise err("invalid request target %r" % (target,))
        version = _check_version(http_version, err)
        self.method = method
        self.target = target
        self.headers = Headers(build_headers(headers, err, is_request=True, http_version=version))
        self.http_version = version


class InformationalResponse(_Event):
    _fields = ("status_code", "headers", "http_version", "reason")

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        self._init(LocalProtocolError, status_code, headers, http_version, reason)

    def _init(self, err, status_code, headers, http_version=b"1.1", reason=b""):
        self.status_code = _check_status(status_code, 100, 199, err)
        self.headers = Headers(build_headers(headers, err))
        self.http_version = _check_version(http_version, err)
        self.reason = _check_reason(reason, err)


class Response(_Event):
    _fields = ("status_code", "headers", "http_version", "reason")

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        self._init(LocalProtocolError, status_code, headers, http_version, reason)

    def _init(self, err, status_code, headers, http_version=b"1.1", reason=b""):
        self.status_code = _check_status(status_code, 200, 999, err)
        self.headers = Headers(build_headers(headers, err))
        self.http_version = _check_version(http_version, err)
        self.reason = _check_reason(reason, err)


class Data(_Event):
    _fields = ("data", "chunk_start", "chunk_end")

    def __init__(self, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)


class EndOfMessage(_Event):
    _fields = ("headers",)

    def __init__(self, headers=()):
        self._init(LocalProtocolError, headers)

    def _init(self, err, headers=()):
        self.headers = Headers(build_headers(headers, err))


class ConnectionClosed(_Event):
    _fields = ()

    def __init__(self):
        pass
