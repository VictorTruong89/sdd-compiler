"""Header-list validation and normalization shared by events and the parser."""

import re
from collections.abc import Sequence

TOKEN_RE = re.compile(rb"[!#$%&'*+\-.^_`|~0-9A-Za-z]+")
TARGET_RE = re.compile(rb"[\x21-\x7e]+")
# Empty, or starts and ends with a non-blank byte; blanks (space/tab) only between.
# Control bytes other than tab are refused; bytes 0x80-0xff are allowed.
VALUE_RE = re.compile(rb"(?:[\x21-\x7e\x80-\xff](?:[ \t]*[\x21-\x7e\x80-\xff])*)?")
VERSION_RE = re.compile(rb"([0-9])\.([0-9])")
DIGITS_RE = re.compile(rb"[0-9]+")

# Maximum Content-Length digit count (PRD FP-01 allows 18..32; see NOTES.md).
MAX_CONTENT_LENGTH_DIGITS = 18


def to_bytes(value, err, what):
    """Convert text (latin-1) or a bytes-like object to ``bytes``."""
    if isinstance(value, bytes):
        return value
    if isinstance(value, str):
        try:
            return value.encode("latin-1")
        except UnicodeEncodeError:
            raise err("%s is not representable as bytes" % what)
    if isinstance(value, (bytearray, memoryview)):
        return bytes(value)
    raise err("%s must be text or a bytes-like object" % what)


def build_headers(pairs, err, is_request=False, http_version=None):
    """Validate and normalize a header list.

    Returns a list of ``(raw_name, lower_name, value)`` triples. ``err`` is the
    exception class to raise (LocalProtocolError for constructed events,
    RemoteProtocolError for bytes read from the peer).
    """
    try:
        pair_list = list(pairs)
    except TypeError:
        raise err("headers must be a sequence of (name, value) pairs")

    items = []
    for pair in pair_list:
        if isinstance(pair, (str, bytes, bytearray)):
            raise err("each header must be a (name, value) pair")
        try:
            name, value = pair
        except (TypeError, ValueError):
            raise err("each header must be a (name, value) pair")
        name = to_bytes(name, err, "header name")
        value = to_bytes(value, err, "header value")
        if TOKEN_RE.fullmatch(name) is None:
            raise err("invalid header name %r" % (name,))
        if VALUE_RE.fullmatch(value) is None:
            raise err("invalid header value for %r" % (name,))
        items.append([name, name.lower(), value])

    # Content-Length: every decimal piece must agree; collapse to one header.
    cl_positions = [i for i, it in enumerate(items) if it[1] == b"content-length"]
    if cl_positions:
        numbers = set()
        first_value = None
        for i in cl_positions:
            for piece in items[i][2].split(b","):
                digits = piece.strip(b" \t")
                if DIGITS_RE.fullmatch(digits) is None:
                    raise err("invalid Content-Length value")
                if len(digits) > MAX_CONTENT_LENGTH_DIGITS:
                    raise err("Content-Length value has too many digits")
                numbers.add(int(digits))
                if first_value is None:
                    first_value = digits
        if len(numbers) > 1:
            raise err("conflicting Content-Length values")
        first = cl_positions[0]
        items = [
            ([it[0], b"content-length", first_value] if j == first else it)
            for j, it in enumerate(items)
            if j not in cl_positions or j == first
        ]

    # Transfer-Encoding: exactly one header, exactly "chunked" in any case.
    te_positions = [i for i, it in enumerate(items) if it[1] == b"transfer-encoding"]
    if len(te_positions) > 1:
        raise err("multiple Transfer-Encoding headers", 501)
    if te_positions:
        i = te_positions[0]
        if items[i][2].lower() != b"chunked":
            raise err("unsupported Transfer-Encoding", 501)
        items[i] = [items[i][0], b"transfer-encoding", b"chunked"]

    host_count = sum(1 for it in items if it[1] == b"host")
    if host_count > 1:
        raise err("multiple Host headers")
    if is_request and host_count == 0 and http_version == b"1.1":
        raise err("HTTP/1.1 request without a Host header")

    return [(it[0], it[1], it[2]) for it in items]


class Headers(Sequence):
    """Ordered header list: ordinary view is (lowercase name, value); raw_items() keeps caller spelling."""

    __slots__ = ("_items",)

    def __init__(self, items):
        self._items = tuple(items)

    def __len__(self):
        return len(self._items)

    def __getitem__(self, index):
        if isinstance(index, slice):
            return [(lname, value) for _raw, lname, value in self._items[index]]
        _raw, lname, value = self._items[index]
        return (lname, value)

    def __iter__(self):
        for _raw, lname, value in self._items:
            yield (lname, value)

    def raw_items(self):
        return [(raw, value) for raw, _lname, value in self._items]

    def _triples(self):
        return list(self._items)

    def __eq__(self, other):
        if isinstance(other, Headers):
            return self._items == other._items
        try:
            return list(self) == [tuple(p) for p in other]
        except TypeError:
            return NotImplemented

    __hash__ = None

    def __repr__(self):
        return "Headers(%r)" % (list(self),)
