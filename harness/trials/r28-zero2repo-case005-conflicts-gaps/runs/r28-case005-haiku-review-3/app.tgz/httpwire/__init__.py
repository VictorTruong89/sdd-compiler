"""httpwire: a pure-Python HTTP/1.1 wire protocol library (no I/O of its own)."""

from ._sentinels import (
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
)
from .connection import Connection
from .errors import LocalProtocolError, ReceiveAfterCloseError, RemoteProtocolError
from .events import (
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    Request,
    Response,
)

__all__ = [
    "CLIENT",
    "SERVER",
    "NEED_DATA",
    "PAUSED",
    "IDLE",
    "SEND_RESPONSE",
    "SEND_BODY",
    "DONE",
    "MUST_CLOSE",
    "CLOSED",
    "MIGHT_SWITCH_PROTOCOL",
    "SWITCHED_PROTOCOL",
    "ERROR",
    "Request",
    "InformationalResponse",
    "Response",
    "Data",
    "EndOfMessage",
    "ConnectionClosed",
    "Connection",
    "LocalProtocolError",
    "RemoteProtocolError",
    "ReceiveAfterCloseError",
]
