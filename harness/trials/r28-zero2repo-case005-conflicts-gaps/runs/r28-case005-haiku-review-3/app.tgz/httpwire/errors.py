"""Exception classes raised by httpwire."""


class ProtocolError(Exception):
    """Shared base of the two protocol-error kinds.

    ``error_status_hint`` is the suggested HTTP status (PRD FP-05); it
    defaults to 400.
    """

    def __init__(self, message="", error_status_hint=400):
        Exception.__init__(self, message)
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(ProtocolError):
    """The integrator's own event or send violated the protocol."""


class RemoteProtocolError(ProtocolError):
    """The peer's bytes violated the protocol."""


class ReceiveAfterCloseError(RuntimeError):
    """Non-empty bytes were fed after the receive side was already closed.

    Deliberately neither a LocalProtocolError nor a RemoteProtocolError (PRD FP-02).
    """
