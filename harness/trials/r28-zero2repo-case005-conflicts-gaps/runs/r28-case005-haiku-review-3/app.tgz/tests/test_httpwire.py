"""Behavioural tests for httpwire, written against the PRD and Interface Contract."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from httpwire import (  # noqa: E402
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
    ConnectionClosed,
    Connection,
    Data,
    EndOfMessage,
    InformationalResponse,
    LocalProtocolError,
    Request,
    Response,
    RemoteProtocolError,
)
from httpwire import ReceiveAfterCloseError  # noqa: E402


def exchange(client, server, data):
    """Feed bytes the client produced into the server."""
    server.receive_data(data)


class EventTests(unittest.TestCase):
    def test_defaults_and_bytes(self):
        r = Request(method="GET", target="/", headers=[("Host", "x")])
        self.assertEqual(r.http_version, b"1.1")
        self.assertEqual(r.method, b"GET")
        self.assertIsInstance(r.target, bytes)
        self.assertEqual(list(r.headers), [(b"host", b"x")])
        self.assertEqual(r.headers.raw_items(), [(b"Host", b"x")])

    def test_host_rules(self):
        with self.assertRaises(LocalProtocolError):
            Request(method=b"GET", target=b"/", headers=[])
        with self.assertRaises(LocalProtocolError):
            Request(method=b"GET", target=b"/", headers=[("HOST", "a"), ("host", "b")])
        Request(method=b"GET", target=b"/", headers=[], http_version=b"1.0")
        with self.assertRaises(LocalProtocolError):
            Request(method=b"GET", target=b"/", headers=[("Host", "a"), ("Host", "a")])

    def test_status_ranges(self):
        with self.assertRaises(LocalProtocolError):
            InformationalResponse(status_code=200, headers=[])
        with self.assertRaises(LocalProtocolError):
            Response(status_code=1000, headers=[])
        with self.assertRaises(LocalProtocolError):
            Response(status_code="200", headers=[])
        self.assertEqual(Response(status_code=999, headers=[]).status_code, 999)

    def test_header_value_rules(self):
        with self.assertRaises(LocalProtocolError):
            Response(status_code=200, headers=[("X", " lead")])
        with self.assertRaises(LocalProtocolError):
            Response(status_code=200, headers=[("X", "trail ")])
        with self.assertRaises(LocalProtocolError):
            Response(status_code=200, headers=[("X", "a\x01b")])
        Response(status_code=200, headers=[("X", "a\tb c")])
        with self.assertRaises(LocalProtocolError):
            Response(status_code=200, headers=[("bad name", "v")])

    def test_content_length_collapse_and_conflict(self):
        r = Response(status_code=200, headers=[("Content-Length", "5"), ("content-length", "5, 5")])
        self.assertEqual(list(r.headers), [(b"content-length", b"5")])
        with self.assertRaises(LocalProtocolError):
            Response(status_code=200, headers=[("Content-Length", "5"), ("Content-Length", "6")])
        with self.assertRaises(LocalProtocolError):
            Response(status_code=200, headers=[("Content-Length", "1" * 19)])
        with self.assertRaises(LocalProtocolError):
            Response(status_code=200, headers=[("Content-Length", "+5")])

    def test_transfer_encoding_rules(self):
        r = Response(status_code=200, headers=[("Transfer-Encoding", "ChUnKeD")])
        self.assertEqual(list(r.headers), [(b"transfer-encoding", b"chunked")])
        for hdrs in (
            [("Transfer-Encoding", "gzip")],
            [("Transfer-Encoding", "gzip, chunked")],
            [("Transfer-Encoding", "chunked"), ("Transfer-Encoding", "chunked")],
        ):
            with self.assertRaises(LocalProtocolError) as cm:
                Response(status_code=200, headers=hdrs)
            self.assertEqual(cm.exception.error_status_hint, 501)

    def test_data_and_eom(self):
        d = Data(b"x")
        self.assertIs(d.data, d.data)
        self.assertIs(d.chunk_start, False)
        self.assertEqual(EndOfMessage().headers, [])

    def test_error_classes_are_distinct(self):
        self.assertFalse(issubclass(LocalProtocolError, RemoteProtocolError))
        self.assertFalse(issubclass(RemoteProtocolError, LocalProtocolError))
        self.assertFalse(issubclass(ReceiveAfterCloseError, (LocalProtocolError, RemoteProtocolError)))

    def test_role_and_state_objects(self):
        self.assertIsNot(CLIENT, SERVER)
        self.assertNotEqual(CLIENT, SERVER)
        c = Connection(CLIENT)
        self.assertIs(c.our_role, CLIENT)
        self.assertIs(c.their_role, SERVER)
        self.assertEqual(c.states[CLIENT], IDLE)
        with self.assertRaises(Exception):
            Connection("client")


class ClientServerTests(unittest.TestCase):
    def test_simple_get_round_trip(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        wire = c.send(Request(method=b"GET", target=b"/a", headers=[("Host", "h")]))
        self.assertEqual(wire, b"GET /a HTTP/1.1\r\nHost: h\r\n\r\n")
        self.assertEqual(c.our_state, SEND_BODY)
        self.assertEqual(c.their_state, SEND_RESPONSE)
        self.assertEqual(c.send(EndOfMessage()), b"")
        self.assertEqual(c.our_state, DONE)
        s.receive_data(wire)
        req = s.next_event()
        self.assertIsInstance(req, Request)
        self.assertEqual(s.their_http_version, b"1.1")
        self.assertIsInstance(s.next_event(), EndOfMessage)
        self.assertIs(s.next_event(), NEED_DATA)
        self.assertEqual(s.our_state, SEND_RESPONSE)
        self.assertEqual(s.their_state, DONE)

    def test_host_written_first_and_original_casing(self):
        c = Connection(CLIENT)
        wire = c.send(Request(method=b"GET", target=b"/", headers=[("X-A", "1"), ("hOsT", "h")]))
        self.assertEqual(wire, b"GET / HTTP/1.1\r\nhOsT: h\r\nX-A: 1\r\n\r\n")

    def test_response_and_content_length(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        s.receive_data(c.send(Request(method=b"GET", target=b"/", headers=[("Host", "h")])))
        s.next_event()
        s.next_event()
        wire = s.send(Response(status_code=200, headers=[("Content-Length", "3")], reason=b"OK"))
        self.assertEqual(wire, b"HTTP/1.1 200 OK\r\nContent-Length: 3\r\n\r\n")
        self.assertEqual(s.send(Data(b"abc")), b"abc")
        self.assertEqual(s.send(EndOfMessage()), b"")
        self.assertEqual(s.our_state, DONE)

    def test_content_length_too_much_or_too_little(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nContent-Length: 2\r\n\r\n")
        s.next_event()
        c = Connection(CLIENT)
        c.send(Request(method=b"POST", target=b"/", headers=[("Host", "h"), ("Content-Length", "2")]))
        with self.assertRaises(LocalProtocolError):
            c.send(Data(b"abc"))
        self.assertEqual(c.our_state, ERROR)
        c2 = Connection(CLIENT)
        c2.send(Request(method=b"POST", target=b"/", headers=[("Host", "h"), ("Content-Length", "2")]))
        with self.assertRaises(LocalProtocolError):
            c2.send(EndOfMessage())
        with self.assertRaises(LocalProtocolError):
            c2.send(Data(b"x"))  # further sends fail once in ERROR

    def test_chunked_send_and_marks(self):
        c = Connection(CLIENT)
        wire = c.send(Request(method=b"PUT", target=b"/", headers=[("Host", "h"), ("Transfer-Encoding", "chunked")]))
        self.assertIn(b"Transfer-Encoding: chunked", wire)
        self.assertEqual(c.send(Data(b"hello")), b"5\r\nhello\r\n")
        self.assertEqual(c.send(Data(b"")), b"")
        self.assertEqual(c.send(EndOfMessage(headers=[("X-T", "v")])), b"0\r\nX-T: v\r\n\r\n")

        s = Connection(SERVER)
        s.receive_data(b"PUT / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n")
        s.next_event()
        s.receive_data(b"4\r\nab")
        d1 = s.next_event()
        self.assertEqual((d1.data, d1.chunk_start, d1.chunk_end), (b"ab", True, False))
        self.assertIs(s.next_event(), NEED_DATA)
        s.receive_data(b"cd\r\n0\r\n\r\n")
        d2 = s.next_event()
        self.assertEqual((d2.data, d2.chunk_start, d2.chunk_end), (b"cd", False, True))
        self.assertIsInstance(s.next_event(), EndOfMessage)

    def test_chunk_size_rules(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n2;ext=1\r\nhi\r\n0\r\n\r\n")
        s.next_event()
        self.assertEqual(s.next_event().data, b"hi")
        s2 = Connection(SERVER)
        s2.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n1 x\r\n")
        s2.next_event()
        with self.assertRaises(RemoteProtocolError):
            s2.next_event()
        self.assertEqual(s2.their_state, ERROR)

    def test_pipelining_paused_then_next_cycle(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        wire = b"GET /1 HTTP/1.1\r\nHost: h\r\n\r\nGET /2 HTTP/1.1\r\nHost: h\r\n\r\n"
        s.receive_data(wire)
        self.assertIsInstance(s.next_event(), Request)
        self.assertIsInstance(s.next_event(), EndOfMessage)
        s.send(Response(status_code=200, headers=[("Content-Length", "0")]))
        s.send(EndOfMessage())
        self.assertEqual(s.our_state, DONE)
        self.assertIs(s.next_event(), PAUSED)
        with self.assertRaises(LocalProtocolError):
            c.start_next_cycle()
        s.start_next_cycle()
        self.assertEqual(s.next_event().target, b"/2")

    def test_client_cannot_pipeline(self):
        c = Connection(CLIENT)
        c.send(Request(method=b"GET", target=b"/", headers=[("Host", "h")]))
        with self.assertRaises(LocalProtocolError):
            c.send(Request(method=b"GET", target=b"/", headers=[("Host", "h")]))
        self.assertEqual(c.our_state, ERROR)

    def test_keep_alive_disabled_by_http10_and_close(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.0\r\nHost: h\r\n\r\n")
        s.next_event()
        s.next_event()
        wire = s.send(Response(status_code=200, headers=[("Content-Length", "0")]))
        self.assertIn(b"Connection: close", wire)
        s.send(EndOfMessage())
        self.assertEqual(s.our_state, MUST_CLOSE)
        with self.assertRaises(LocalProtocolError):
            s.start_next_cycle()

    def test_connection_close_request(self):
        c = Connection(CLIENT)
        c.send(Request(method=b"GET", target=b"/", headers=[("Host", "h"), ("Connection", "Close")]))
        c.send(EndOfMessage())
        self.assertEqual(c.our_state, MUST_CLOSE)
        c.send(ConnectionClosed())
        self.assertEqual(c.our_state, CLOSED)

    def test_http10_response_is_close_delimited(self):
        c = Connection(CLIENT)
        c.send(Request(method=b"GET", target=b"/", headers=[("Host", "h")]))
        c.send(EndOfMessage())
        c.receive_data(b"HTTP/1.0 200 OK\r\n\r\nbody-")
        r = c.next_event()
        self.assertIsInstance(r, Response)
        self.assertEqual(c.their_http_version, b"1.0")
        self.assertEqual(c.next_event().data, b"body-")
        self.assertIs(c.next_event(), NEED_DATA)
        c.receive_data(b"")
        self.assertIsInstance(c.next_event(), EndOfMessage)
        self.assertIsInstance(c.next_event(), ConnectionClosed)
        self.assertEqual(c.our_state, MUST_CLOSE)

    def test_server_response_without_request_is_close_delimited(self):
        s = Connection(SERVER)
        wire = s.send(Response(status_code=400, headers=[], reason=b"Bad"))
        self.assertIn(b"Connection: close", wire)
        self.assertNotIn(b"Transfer-Encoding", wire)
        self.assertEqual(s.our_state, SEND_BODY)

    def test_response_to_head_has_empty_body(self):
        c = Connection(CLIENT)
        c.send(Request(method=b"HEAD", target=b"/", headers=[("Host", "h")]))
        c.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 100\r\n\r\n")
        self.assertIsInstance(c.next_event(), Response)
        self.assertIsInstance(c.next_event(), EndOfMessage)
        self.assertEqual(c.our_state, DONE)

    def test_status_line_without_reason_accepted(self):
        c = Connection(CLIENT)
        c.send(Request(method=b"GET", target=b"/", headers=[("Host", "h")]))
        c.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 204\n\n")
        r = c.next_event()
        self.assertEqual(r.status_code, 204)
        self.assertEqual(r.reason, b"")

    def test_lf_only_and_folding(self):
        c = Connection(CLIENT)
        c.send(Request(method=b"GET", target=b"/", headers=[("Host", "h")]))
        c.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 200 OK\nX-Long: a\n   b\t c\nContent-Length: 0\n\n")
        r = c.next_event()
        self.assertEqual(dict(r.headers)[b"x-long"], b"a b\t c")

    def test_leading_space_or_control_byte_fails_immediately(self):
        s = Connection(SERVER)
        s.receive_data(b" GET")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()
        s2 = Connection(SERVER)
        s2.receive_data(b"\x01")
        with self.assertRaises(RemoteProtocolError):
            s2.next_event()

    def test_size_limit_431(self):
        s = Connection(SERVER, 100)
        s.receive_data(b"GET / HTTP/1.1\r\nX: " + b"a" * 200)
        with self.assertRaises(RemoteProtocolError) as cm:
            s.next_event()
        self.assertEqual(cm.exception.error_status_hint, 431)

    def test_default_limit_is_in_prd_range(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nX: " + b"a" * (10 * 1024))
        self.assertIs(s.next_event(), NEED_DATA)

    def test_receive_close_mid_message_is_remote_error(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nHo")
        s.receive_data(b"")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    def test_clean_close_yields_connection_closed(self):
        s = Connection(SERVER)
        s.receive_data(b"")
        self.assertIsInstance(s.next_event(), ConnectionClosed)
        self.assertEqual(s.their_state, CLOSED)
        self.assertEqual(s.our_state, MUST_CLOSE)
        self.assertIsInstance(s.next_event(), ConnectionClosed)

    def test_feed_after_close_is_runtime_error(self):
        s = Connection(SERVER)
        s.receive_data(b"")
        with self.assertRaises(ReceiveAfterCloseError) as cm:
            s.receive_data(b"x")
        self.assertIsInstance(cm.exception, RuntimeError)
        self.assertNotIsInstance(cm.exception, (LocalProtocolError, RemoteProtocolError))

    def test_remote_error_then_error_response(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\nHost: b\r\n\r\n")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()
        self.assertEqual(s.their_state, ERROR)
        wire = s.send(Response(status_code=400, headers=[("Content-Length", "0")]))
        self.assertIn(b"Connection: close", wire)
        s.send(EndOfMessage())
        self.assertEqual(s.our_state, MUST_CLOSE)
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    def test_send_failed_marks_error(self):
        c = Connection(CLIENT)
        c.send(Request(method=b"POST", target=b"/", headers=[("Host", "h"), ("Content-Length", "4")]))
        c.send_failed()
        self.assertEqual(c.our_state, ERROR)
        with self.assertRaises(LocalProtocolError):
            c.send(Data(b"ab"))

    def test_http10_request_cannot_be_sent(self):
        c = Connection(CLIENT)
        with self.assertRaises(LocalProtocolError):
            c.send(Request(method=b"GET", target=b"/", headers=[], http_version=b"1.0"))
        self.assertEqual(c.our_state, ERROR)

    def test_passthrough_keeps_object(self):
        class Blob(object):
            def __len__(self):
                return 5

        c = Connection(CLIENT)
        c.send(Request(method=b"PUT", target=b"/", headers=[("Host", "h"), ("Transfer-Encoding", "chunked")]))
        blob = Blob()
        pieces = c.send_with_data_passthrough(Data(blob))
        self.assertIs(pieces[1], blob)
        self.assertEqual(pieces[0], b"5\r\n")
        self.assertEqual(pieces[2], b"\r\n")

    def test_informational_and_100_continue(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        wire = c.send(Request(method=b"POST", target=b"/", headers=[
            ("Host", "h"), ("Content-Length", "1"), ("Expect", "100-continue")]))
        self.assertTrue(c.client_is_waiting_for_100_continue)
        self.assertFalse(c.they_are_waiting_for_100_continue)
        s.receive_data(wire)
        s.next_event()
        self.assertTrue(s.they_are_waiting_for_100_continue)
        s.send(InformationalResponse(status_code=100, headers=[], reason=b"Continue"))
        self.assertFalse(s.they_are_waiting_for_100_continue)
        c.receive_data(b"HTTP/1.1 100 Continue\r\n\r\n")
        self.assertIsInstance(c.next_event(), InformationalResponse)
        self.assertFalse(c.client_is_waiting_for_100_continue)
        self.assertEqual(c.our_state, SEND_BODY)

    def test_expect_on_http10_sets_no_flag(self):
        c = Connection(CLIENT)
        c.send(Request(method=b"POST", target=b"/", headers=[("Host", "h"), ("Expect", "100-continue")],
                       http_version=b"1.1"))
        self.assertTrue(c.client_is_waiting_for_100_continue)

    def test_connect_accepted(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        wire = c.send(Request(method=b"CONNECT", target=b"example.com:443", headers=[("Host", "example.com")]))
        c.send(EndOfMessage())
        self.assertEqual(c.our_state, MIGHT_SWITCH_PROTOCOL)
        s.receive_data(wire)
        s.next_event()
        s.next_event()
        self.assertIs(s.next_event(), PAUSED)
        s.send(Response(status_code=200, headers=[]))
        self.assertEqual(s.our_state, SWITCHED_PROTOCOL)
        self.assertEqual(c.our_state, MIGHT_SWITCH_PROTOCOL)
        s.receive_data(b"\x16\x03leftover")
        self.assertIs(s.next_event(), PAUSED)
        self.assertEqual(s.trailing_data, (b"\x16\x03leftover", False))
        c.receive_data(b"HTTP/1.1 200 OK\r\n\r\n")
        self.assertIsInstance(c.next_event(), Response)
        self.assertEqual(c.our_state, SWITCHED_PROTOCOL)

    def test_connect_denied_then_next_cycle(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        wire = c.send(Request(method=b"CONNECT", target=b"x:1", headers=[("Host", "x")]))
        c.send(EndOfMessage())
        s.receive_data(wire)
        s.next_event()
        s.next_event()
        s.send(Response(status_code=403, headers=[("Content-Length", "0")]))
        s.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\n\r\n")
        self.assertIsInstance(c.next_event(), Response)
        self.assertIsInstance(c.next_event(), EndOfMessage)
        self.assertEqual(c.our_state, DONE)
        self.assertEqual(s.our_state, DONE)
        c.start_next_cycle()
        s.start_next_cycle()

    def test_upgrade_accepted_with_101(self):
        c = Connection(CLIENT)
        s = Connection(SERVER)
        wire = c.send(Request(method=b"GET", target=b"/", headers=[("Host", "h"), ("Upgrade", "websocket")]))
        c.send(EndOfMessage())
        s.receive_data(wire)
        s.next_event()
        s.next_event()
        s.send(InformationalResponse(status_code=101, headers=[("Upgrade", "websocket")], reason=b"Switching"))
        self.assertEqual(s.our_state, SWITCHED_PROTOCOL)
        c.receive_data(b"HTTP/1.1 101 Switching\r\nUpgrade: websocket\r\n\r\n")
        self.assertIsInstance(c.next_event(), InformationalResponse)
        self.assertEqual(c.our_state, SWITCHED_PROTOCOL)
        with self.assertRaises(LocalProtocolError):
            s.start_next_cycle()

    def test_states_mapping(self):
        c = Connection(CLIENT)
        self.assertEqual(c.states, {CLIENT: IDLE, SERVER: IDLE})
        self.assertIsNone(c.their_http_version)


if __name__ == "__main__":
    unittest.main()
