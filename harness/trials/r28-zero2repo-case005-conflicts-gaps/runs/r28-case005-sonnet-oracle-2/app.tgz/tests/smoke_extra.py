import sys; sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.dirname(__import__('os').path.abspath(__file__))))
from httpwire import *
s=Connection(SERVER); s.receive_data(b"GET / HTTP/1.1\r\nHost: a\r\n"+b"x"*20000)
try: s.next_event()
except RemoteProtocolError as e: print(e.error_status_hint, s.their_state)
# close handling
s=Connection(SERVER); s.receive_data(b""); print(s.next_event(), s.next_event(), s.states)
# mid-body close
s=Connection(SERVER); s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nContent-Length: 5\r\n\r\nab"); print(s.next_event(), s.next_event()); s.receive_data(b"")
try: s.next_event()
except RemoteProtocolError as e: print("mid-close", e)
# local error
c=Connection(CLIENT)
try: c.send(Response(status_code=200,headers=[]))
except LocalProtocolError as e: print(c.our_state, c.their_state)
# http10 response body
c=Connection(CLIENT); c.send(Request(method="GET",target="/",headers=[("Host","h")])); c.send(EndOfMessage())
c.receive_data(b"HTTP/1.0 200 OK\r\n\r\nabc"); print(c.next_event(), c.next_event()); c.receive_data(b"")
print(c.next_event(), c.next_event(), c.next_event(), c.states)
# pass-through
c=Connection(CLIENT); c.send(Request(method="POST",target="/",headers=[("Host","h"),("Transfer-Encoding","Chunked")]))
m=memoryview(b"abc"); print(c.send_with_data_passthrough(Data(data=m)))
# CL errors
for h in ([("content-length","5"),("content-length","6")],[("Transfer-Encoding","gzip")]):
    try: Request(method="GET",target="/",headers=[("Host","a")]+h)
    except LocalProtocolError as e: print(e.error_status_hint)
print(Request(method="GET",target="/",headers=[("Host","a"),("Content-Length","1, 1")]).headers.raw_items())
# folding / lf
s=Connection(SERVER); s.receive_data(b"GET / HTTP/1.1\nHost: a\n b\n\n"); print(s.next_event())
# 100-continue
s=Connection(SERVER); s.receive_data(b"POST / HTTP/1.1\r\nHost: a\r\nExpect: 100-continue\r\nContent-Length: 1\r\n\r\n"); s.next_event()
print(s.they_are_waiting_for_100_continue); s.send(InformationalResponse(status_code=100,headers=[])); print(s.they_are_waiting_for_100_continue)
print(s.trailing_data, s.next_event(), s.states)
