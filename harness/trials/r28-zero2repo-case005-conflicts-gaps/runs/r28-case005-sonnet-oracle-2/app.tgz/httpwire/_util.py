"""Shared helpers: errors, sentinels, validation regexes."""
import re


class ProtocolError(Exception):
    def __init__(self, msg="", error_status_hint=400):
        Exception.__init__(self, msg)
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(ProtocolError):
    def _reraise_as_remote(self):
        new = RemoteProtocolError(str(self), self.error_status_hint)
        raise new from self


class RemoteProtocolError(ProtocolError):
    pass


class _Sentinel(object):
    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return self._name

    def __copy__(self):
        return self

    def __deepcopy__(self, memo):
        return self

    def __reduce__(self):
        return self._name


CLIENT = _Sentinel("CLIENT")
SERVER = _Sentinel("SERVER")
NEED_DATA = _Sentinel("NEED_DATA")
PAUSED = _Sentinel("PAUSED")
IDLE = _Sentinel("IDLE")
SEND_RESPONSE = _Sentinel("SEND_RESPONSE")
SEND_BODY = _Sentinel("SEND_BODY")
DONE = _Sentinel("DONE")
MUST_CLOSE = _Sentinel("MUST_CLOSE")
CLOSED = _Sentinel("CLOSED")
MIGHT_SWITCH_PROTOCOL = _Sentinel("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = _Sentinel("SWITCHED_PROTOCOL")
ERROR = _Sentinel("ERROR")

TOKEN = rb"[-!#$%&'*+.^_`|~0-9a-zA-Z]+"
token_re = re.compile(rb"\A" + TOKEN + rb"\Z")
target_re = re.compile(rb"\A[\x21-\x7e]+\Z")
version_re = re.compile(rb"\A[0-9]\.[0-9]\Z")
digits_re = re.compile(rb"\A[0-9]+\Z")
_BAD_VALUE = re.compile(rb"[\x00\r\n\x0c\x0b]")

MAX_CONTENT_LENGTH_DIGITS = 18
MAX_CHUNK_SIZE_DIGITS = 32


def to_bytes(value, what):
    if isinstance(value, bytes):
        return value
    if isinstance(value, str):
        try:
            return value.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("%s must be ASCII" % what)
    try:
        return bytes(memoryview(value))
    except TypeError:
        raise LocalProtocolError("%s must be str or bytes-like" % what)


def check_value(value):
    if _BAD_VALUE.search(value):
        raise LocalProtocolError("illegal header value %r" % (value,))
    if value[:1] in (b" ", b"\t") or value[-1:] in (b" ", b"\t"):
        raise LocalProtocolError("header value has leading/trailing whitespace")
