import re

from ._util import *  # noqa
from ._util import (LocalProtocolError, RemoteProtocolError, token_re, target_re,
                    version_re, digits_re, check_value, _BAD_VALUE,
                    MAX_CHUNK_SIZE_DIGITS)
from ._events import (Request, InformationalResponse, Response, Data, EndOfMessage,
                      ConnectionClosed, Headers, get_comma_header)
from . import _util as U

CLIENT, SERVER = U.CLIENT, U.SERVER
IDLE, SEND_RESPONSE, SEND_BODY, DONE = U.IDLE, U.SEND_RESPONSE, U.SEND_BODY, U.DONE
MUST_CLOSE, CLOSED, ERROR = U.MUST_CLOSE, U.CLOSED, U.ERROR
MIGHT_SWITCH, SWITCHED = U.MIGHT_SWITCH_PROTOCOL, U.SWITCHED_PROTOCOL
NEED_DATA, PAUSED = U.NEED_DATA, U.PAUSED

_SWITCH_CONNECT = "connect"
_SWITCH_UPGRADE = "upgrade"

# (role, state) -> {event type -> new state}
_TRANS = {
    CLIENT: {
        IDLE: {Request: SEND_BODY, ConnectionClosed: CLOSED},
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
        CLOSED: {ConnectionClosed: CLOSED},
    },
    SERVER: {
        IDLE: {ConnectionClosed: CLOSED, Response: SEND_BODY},
        SEND_RESPONSE: {InformationalResponse: SEND_RESPONSE, Response: SEND_BODY},
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
        CLOSED: {ConnectionClosed: CLOSED},
    },
}

_line_split = re.compile(rb"\r?\n")
_block_end = re.compile(rb"\n\r?\n")
_request_line_re = re.compile(
    rb"\A(" + U.TOKEN + rb") ([\x21-\x7e]+) HTTP/([0-9]\.[0-9])\Z")
_status_line_re = re.compile(rb"\AHTTP/([0-9]\.[0-9]) ([0-9]{3})(?: ([^\x00\r\n]*))?\Z")
_header_line_re = re.compile(rb"\A(" + U.TOKEN + rb"):[ \t]*(.*?)[ \t]*\Z", re.S)
_chunk_re = re.compile(
    rb"\A([0-9a-fA-F]+)(?:;[^\r\n]*)?[ \t]*\Z")


def _extract_block(buf):
    """Return list of lines of a header block, or None if incomplete."""
    if buf[:2] == b"\r\n":
        del buf[:2]
        return []
    if buf[:1] == b"\n":
        del buf[:1]
        return []
    m = _block_end.search(buf)
    if not m:
        return None
    block = bytes(buf[:m.start()])
    if block.endswith(b"\r"):
        block = block[:-1]
    del buf[:m.end()]
    return _line_split.split(block)


def _parse_headers(lines):
    out = []
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            if not out:
                raise LocalProtocolError("illegal continuation line")
            name, value = out[-1]
            out[-1] = (name, value + b" " + line.lstrip(b" \t"))
            continue
        m = _header_line_re.match(line)
        if not m:
            raise LocalProtocolError("illegal header line %r" % (line,))
        out.append((m.group(1), m.group(2)))
    return [(n, v.strip(b" \t")) for n, v in out]


def _read_head(buf, is_request, max_size):
    if buf and buf[0] < 33:
        raise LocalProtocolError("illegal first byte of start line")
    lines = _extract_block(buf)
    if lines is None:
        return None
    first, rest = lines[0], lines[1:]
    if is_request:
        m = _request_line_re.match(first)
        if not m:
            raise LocalProtocolError("illegal request line %r" % (first,))
        headers = _parse_headers(rest)
        return Request(m.group(1), m.group(2), headers, m.group(3))
    m = _status_line_re.match(first)
    if not m:
        raise LocalProtocolError("illegal status line %r" % (first,))
    code = int(m.group(2))
    headers = _parse_headers(rest)
    cls = InformationalResponse if code < 200 else Response
    return cls(code, headers, m.group(1), m.group(3) or b"")


def _take(buf, n):
    if not buf:
        return None
    data = bytes(buf[:n])
    del buf[:len(data)]
    return data


class _CLReader(object):
    def __init__(self, n):
        self.remaining = n

    def __call__(self, buf):
        if self.remaining == 0:
            return EndOfMessage()
        data = _take(buf, self.remaining)
        if data is None:
            return None
        self.remaining -= len(data)
        return Data(data)


class _ChunkedReader(object):
    def __init__(self):
        self.in_chunk = 0
        self.discard = 0
        self.trailer = False
        self.start_pending = False

    def __call__(self, buf):
        if self.trailer:
            lines = _extract_block(buf)
            if lines is None:
                return None
            return EndOfMessage(headers=_parse_headers(lines))
        if self.discard > 0:
            if len(buf) < self.discard:
                if buf and bytes(buf) != b"\r\n"[:len(buf)]:
                    raise LocalProtocolError("bad chunk terminator")
                return None
            if bytes(buf[:2]) != b"\r\n":
                raise LocalProtocolError("bad chunk terminator")
            del buf[:2]
            self.discard = 0
        chunk_start = False
        if self.in_chunk == 0:
            i = buf.find(b"\n")
            if i < 0:
                if len(buf) > MAX_CHUNK_SIZE_DIGITS + 4096:
                    raise LocalProtocolError("chunk header too long")
                return None
            line = bytes(buf[:i])
            if line.endswith(b"\r"):
                line = line[:-1]
            m = _chunk_re.match(line)
            if not m or len(m.group(1)) > MAX_CHUNK_SIZE_DIGITS:
                raise LocalProtocolError("illegal chunk header %r" % (line,))
            del buf[:i + 1]
            size = int(m.group(1), 16)
            if size == 0:
                self.trailer = True
                return self(buf)
            self.in_chunk = size
            chunk_start = True
        data = _take(buf, self.in_chunk)
        if data is None:
            # chunk header consumed but no data yet: remember start mark
            self.start_pending = self.start_pending or chunk_start
            return None
        chunk_start = chunk_start or self.start_pending
        self.start_pending = False
        self.in_chunk -= len(data)
        chunk_end = self.in_chunk == 0
        if chunk_end:
            self.discard = 2
        return Data(data, chunk_start, chunk_end)


class _Http10Reader(object):
    def __call__(self, buf):
        data = _take(buf, len(buf))
        if data is None:
            return None
        return Data(data)

    def read_eof(self):
        return EndOfMessage()


def _body_framing(method, event):
    if type(event) is Response:
        if (method == b"HEAD" or event.status_code in (204, 304)
                or (method == b"CONNECT" and 200 <= event.status_code < 300)):
            return ("content-length", 0)
    if get_comma_header(event.headers, b"transfer-encoding"):
        return ("chunked", None)
    cl = get_comma_header(event.headers, b"content-length")
    if cl:
        return ("content-length", int(cl[0]))
    if type(event) is Request:
        return ("content-length", 0)
    return ("http/1.0", None)


def _write_headers(pieces, headers_raw):
    out = []
    for name, value in headers_raw:
        out.append(name + b": " + value + b"\r\n")
    pieces.append(b"".join(out))


class _Writer(object):
    def __init__(self, framing):
        self.kind, self.length = framing

    def data(self, event, out):
        d = event.data
        n = len(d)
        if self.kind == "content-length":
            self.length -= n
            if self.length < 0:
                raise LocalProtocolError("Too much data for declared Content-Length")
            if n:
                out.append(d)
        elif self.kind == "chunked":
            if n:
                out.append(b"%x\r\n" % n)
                out.append(d)
                out.append(b"\r\n")
        else:
            if n:
                out.append(d)

    def eom(self, event, out):
        trailers = event.headers.raw_items()
        if self.kind == "content-length":
            if self.length != 0:
                raise LocalProtocolError("Too little data for declared Content-Length")
            if trailers:
                raise LocalProtocolError("Content-Length framing cannot carry trailers")
        elif self.kind == "chunked":
            out.append(b"0\r\n")
            _write_headers(out, trailers)
            out.append(b"\r\n")
        else:
            if trailers:
                raise LocalProtocolError("close-delimited framing cannot carry trailers")


def _write_request(event, out):
    if event.http_version != b"1.1":
        raise LocalProtocolError("Illegal HTTP version for sending")
    out.append(b"%s %s HTTP/1.1\r\n" % (event.method, event.target))
    raw = event.headers.raw_items()
    host = [p for p in raw if p[0].lower() == b"host"]
    others = [p for p in raw if p[0].lower() != b"host"]
    _write_headers(out, host + others)
    out.append(b"\r\n")


def _write_response(event, out):
    if event.http_version != b"1.1":
        raise LocalProtocolError("Illegal HTTP version for sending")
    out.append(b"HTTP/1.1 %d %s\r\n" % (event.status_code, event.reason))
    _write_headers(out, event.headers.raw_items())
    out.append(b"\r\n")


class Connection(object):
    def __init__(self, role, max_incomplete_event_size=16 * 1024):
        if role is not CLIENT and role is not SERVER:
            raise ValueError("expected CLIENT or SERVER, got %r" % (role,))
        self.our_role = role
        self.their_role = SERVER if role is CLIENT else CLIENT
        self._states = {CLIENT: IDLE, SERVER: IDLE}
        self._keep_alive = True
        self._pending = set()
        self._max = max_incomplete_event_size
        self._buf = bytearray()
        self._closed = False
        self.their_http_version = None
        self._request_method = None
        self.client_is_waiting_for_100_continue = False
        self._framing = {}
        self._reader = None
        self._writer = None

    # ---- attributes
    @property
    def our_state(self):
        return self._states[self.our_role]

    @property
    def their_state(self):
        return self._states[self.their_role]

    @property
    def states(self):
        return dict(self._states)

    @property
    def they_are_waiting_for_100_continue(self):
        return bool(self.their_role is CLIENT and self.client_is_waiting_for_100_continue)

    @property
    def trailing_data(self):
        return (bytes(self._buf), self._closed)

    # ---- state machine
    def _fire(self):
        st = self._states
        while True:
            start = dict(st)
            if st[SERVER] is SWITCHED and st[CLIENT] in (MIGHT_SWITCH, DONE):
                st[CLIENT] = SWITCHED
                self._pending = set()
            if self._pending and st[CLIENT] is DONE:
                st[CLIENT] = MIGHT_SWITCH
            if not self._pending and st[CLIENT] is MIGHT_SWITCH:
                st[CLIENT] = DONE
            if st[SERVER] is SWITCHED and st[CLIENT] is MIGHT_SWITCH:
                st[CLIENT] = SWITCHED
            if not self._keep_alive:
                for r in (CLIENT, SERVER):
                    if st[r] is DONE:
                        st[r] = MUST_CLOSE
            for a, b in ((CLIENT, SERVER), (SERVER, CLIENT)):
                if st[a] is CLOSED and st[b] in (IDLE, DONE):
                    st[b] = MUST_CLOSE
                if st[a] is ERROR and st[b] is DONE:
                    st[b] = MUST_CLOSE
            if st == start:
                break

    def _process_error(self, role):
        self._states[role] = ERROR
        self._keep_alive = False
        self._fire()

    def _switch_event(self, event):
        t = type(event)
        if t is InformationalResponse and event.status_code == 101 \
                and _SWITCH_UPGRADE in self._pending:
            return _SWITCH_UPGRADE
        if t is Response and _SWITCH_CONNECT in self._pending \
                and 200 <= event.status_code < 300:
            return _SWITCH_CONNECT
        return None

    def _process_event(self, role, event):
        t = type(event)
        st = self._states
        if role is CLIENT and t is Request:
            if event.method == b"CONNECT":
                self._pending.add(_SWITCH_CONNECT)
            if get_comma_header(event.headers, b"upgrade"):
                self._pending.add(_SWITCH_UPGRADE)
        switch = self._switch_event(event) if role is SERVER else None
        table = _TRANS[role].get(st[role])
        if table is None or t not in table:
            raise LocalProtocolError(
                "can't handle event type %s when role=%r and state=%r"
                % (t.__name__, role, st[role]))
        if switch is None and t is Response:
            self._pending = set()
        if switch is not None:
            st[role] = SWITCHED
        else:
            st[role] = table[t]
        if t is Request:
            st[SERVER] = SEND_RESPONSE if st[SERVER] is IDLE else st[SERVER]
            self._request_method = event.method
        if role is self.their_role and t in (Request, Response, InformationalResponse):
            self.their_http_version = event.http_version
        if t in (Request, Response):
            conn = get_comma_header(event.headers, b"connection")
            if b"close" in conn or event.http_version < b"1.1":
                self._keep_alive = False
            self._framing[role] = _body_framing(self._request_method, event)
        if t is Request and b"100-continue" in get_comma_header(event.headers, b"expect"):
            self.client_is_waiting_for_100_continue = True
        if t in (InformationalResponse, Response):
            self.client_is_waiting_for_100_continue = False
        if role is CLIENT and t in (Data, EndOfMessage):
            self.client_is_waiting_for_100_continue = False
        self._fire()

    # ---- sending
    def _clean_response(self, response):
        method = self._request_method
        if method not in (b"GET", b"HEAD"):
            method = b"GET"
        framing = _body_framing(method, response)[0]
        items = list(response.headers._items)
        if framing in ("chunked", "http/1.0"):
            items = [i for i in items if i[1] not in (b"content-length", b"transfer-encoding")]
            if self.their_http_version is None or self.their_http_version < b"1.1":
                self._keep_alive = False
                self._fire()
            else:
                items.append((b"transfer-encoding", b"transfer-encoding", b"chunked"))
        raw = [(r, v) for r, _, v in items]
        if not self._keep_alive or self.their_state is ERROR:
            conn = set(get_comma_header(Headers(items), b"connection"))
            conn.discard(b"keep-alive")
            conn.add(b"close")
            raw = [(r, v) for r, l, v in items if l != b"connection"]
            raw.append((b"Connection", b",".join(sorted(conn))))
        return Response(response.status_code, raw, response.http_version, response.reason)

    def send(self, event):
        parts = self.send_with_data_passthrough(event)
        if parts is None:
            return None
        return b"".join(parts)

    def send_with_data_passthrough(self, event):
        if self.our_state is ERROR:
            raise LocalProtocolError("Can't send data when our state is ERROR")
        try:
            if type(event) is Response:
                event = self._clean_response(event)
            role, state = self.our_role, self.our_state
            t = type(event)
            if t not in (Request, InformationalResponse, Response, Data,
                         EndOfMessage, ConnectionClosed):
                raise LocalProtocolError("not an event: %r" % (event,))
            self._process_event(role, event)
            if t is ConnectionClosed:
                return None
            out = []
            if t is Request:
                _write_request(event, out)
            elif t in (InformationalResponse, Response):
                _write_response(event, out)
            else:
                if t is Data:
                    self._writer.data(event, out)
                else:
                    self._writer.eom(event, out)
            if t in (Request, Response):
                self._writer = _Writer(self._framing[role])
            return out
        except BaseException:
            self._process_error(self.our_role)
            raise

    # ---- receiving
    def receive_data(self, data):
        if data:
            if self._closed:
                raise RuntimeError("received close, then received more data?")
            self._buf += data
        else:
            self._closed = True

    def _extract(self):
        state = self.their_state
        role = self.their_role
        buf = self._buf
        if state is DONE and buf:
            return PAUSED
        if state is MIGHT_SWITCH or state is SWITCHED:
            return PAUSED
        event = None
        if state is IDLE and role is CLIENT:
            event = _read_head(buf, True, self._max)
        elif role is SERVER and state in (IDLE, SEND_RESPONSE):
            event = _read_head(buf, False, self._max)
        elif state is SEND_BODY:
            if self._reader is None:
                kind, n = self._framing[role]
                self._reader = (_CLReader(n) if kind == "content-length"
                                else _ChunkedReader() if kind == "chunked"
                                else _Http10Reader())
            event = self._reader(buf)
            if event is None and not buf and self._closed \
                    and hasattr(self._reader, "read_eof"):
                event = self._reader.read_eof()
            if type(event) is EndOfMessage:
                self._reader = None
        else:
            if buf:
                raise LocalProtocolError("Got data when expecting EOF")
        if event is None:
            if not buf and self._closed:
                event = ConnectionClosed()
        if event is None:
            event = NEED_DATA
        return event

    def next_event(self):
        if self.their_state is ERROR:
            raise RemoteProtocolError("Can't receive data when peer state is ERROR")
        try:
            event = self._extract()
            if event is not NEED_DATA and event is not PAUSED:
                self._process_event(self.their_role, event)
                if type(event) in (Request, Response, InformationalResponse):
                    pass
            if event is NEED_DATA:
                if len(self._buf) > self._max:
                    raise RemoteProtocolError("Receive buffer too long",
                                              error_status_hint=431)
                if self._closed:
                    raise RemoteProtocolError("peer unexpectedly closed connection")
            return event
        except BaseException as exc:
            self._process_error(self.their_role)
            if isinstance(exc, LocalProtocolError):
                exc._reraise_as_remote()
            raise

    def start_next_cycle(self):
        st = self._states
        if st[CLIENT] is not DONE or st[SERVER] is not DONE:
            raise LocalProtocolError("not in a reusable state")
        st[CLIENT] = IDLE
        st[SERVER] = IDLE
        self._request_method = None
        self.client_is_waiting_for_100_continue = False
        self._reader = None
        self._writer = None
        self._framing = {}

    def send_failed(self):
        self._process_error(self.our_role)
