from ._util import (LocalProtocolError, to_bytes, token_re, target_re, version_re,
                    digits_re, check_value, MAX_CONTENT_LENGTH_DIGITS)


class Headers(object):
    """Sequence of (lowercase name, value) pairs; raw_items() has original names."""

    def __init__(self, items):
        self._items = items  # list of (raw_name, lower_name, value)

    def __len__(self):
        return len(self._items)

    def __iter__(self):
        return iter([(l, v) for _, l, v in self._items])

    def __getitem__(self, i):
        pairs = [(l, v) for _, l, v in self._items]
        return pairs[i]

    def __contains__(self, x):
        return x in list(self)

    def __eq__(self, other):
        try:
            return list(self) == [tuple(p) for p in other]
        except TypeError:
            return NotImplemented

    def __ne__(self, other):
        r = self.__eq__(other)
        return r if r is NotImplemented else not r

    __hash__ = None

    def __repr__(self):
        return repr(list(self))

    def raw_items(self):
        return [(r, v) for r, _, v in self._items]


def get_comma_header(headers, name):
    out = []
    for _, lower, value in headers._items:
        if lower == name:
            for piece in value.split(b","):
                piece = piece.strip(b" \t")
                if piece:
                    out.append(piece.lower())
    return out


def normalize_headers(headers):
    if headers is None:
        headers = []
    try:
        pairs = list(headers)
    except TypeError:
        raise LocalProtocolError("headers must be a sequence of pairs")
    items = []
    saw_cl = None
    saw_te = False
    for pair in pairs:
        try:
            name, value = pair
        except (TypeError, ValueError):
            raise LocalProtocolError("each header must be a (name, value) pair")
        raw = to_bytes(name, "header name")
        value = to_bytes(value, "header value")
        if not token_re.match(raw):
            raise LocalProtocolError("illegal header name %r" % (raw,))
        check_value(value)
        lower = raw.lower()
        if lower == b"content-length":
            pieces = [p.strip(b" \t") for p in value.split(b",")]
            for p in pieces:
                if not digits_re.match(p):
                    raise LocalProtocolError("bad Content-Length %r" % (value,))
                if len(p) > MAX_CONTENT_LENGTH_DIGITS:
                    raise LocalProtocolError("Content-Length too long")
            nums = set(int(p) for p in pieces)
            if len(nums) > 1:
                raise LocalProtocolError("conflicting Content-Length values")
            num = nums.pop()
            if saw_cl is not None:
                if saw_cl != num:
                    raise LocalProtocolError("conflicting Content-Length headers")
                continue  # collapse duplicates
            saw_cl = num
            value = b"%d" % num
        elif lower == b"transfer-encoding":
            if saw_te:
                raise LocalProtocolError("multiple Transfer-Encoding headers",
                                         error_status_hint=501)
            saw_te = True
            if value.lower() != b"chunked":
                raise LocalProtocolError("unsupported Transfer-Encoding",
                                         error_status_hint=501)
            value = b"chunked"
        items.append((raw, lower, value))
    return Headers(items)


class _Event(object):
    _fields = ()

    def __eq__(self, other):
        if type(other) is not type(self):
            return NotImplemented
        return all(getattr(self, f) == getattr(other, f) for f in self._fields)

    def __ne__(self, other):
        r = self.__eq__(other)
        return r if r is NotImplemented else not r

    __hash__ = None

    def __repr__(self):
        return "%s(%s)" % (type(self).__name__, ", ".join(
            "%s=%r" % (f, getattr(self, f)) for f in self._fields))


def _status(status_code, lo, hi):
    if isinstance(status_code, bool) or not isinstance(status_code, int):
        raise LocalProtocolError("status_code must be an integer")
    code = int(status_code)
    if not (lo <= code < hi):
        raise LocalProtocolError("status_code %d out of range" % code)
    return code


def _version(v):
    v = to_bytes(v, "http_version")
    if not version_re.match(v):
        raise LocalProtocolError("bad http_version %r" % (v,))
    return v


class Request(_Event):
    _fields = ("method", "target", "headers", "http_version")

    def __init__(self, method, target, headers, http_version=b"1.1"):
        method = to_bytes(method, "method")
        target = to_bytes(target, "target")
        if not token_re.match(method):
            raise LocalProtocolError("illegal method %r" % (method,))
        if not target_re.match(target):
            raise LocalProtocolError("illegal request target %r" % (target,))
        version = _version(http_version)
        hdrs = normalize_headers(headers)
        hosts = [1 for _, l, _v in hdrs._items if l == b"host"]
        if len(hosts) > 1:
            raise LocalProtocolError("Found multiple Host headers")
        if version == b"1.1" and not hosts:
            raise LocalProtocolError("Missing mandatory Host header")
        self.method = method
        self.target = target
        self.headers = hdrs
        self.http_version = version


class _ResponseBase(_Event):
    _fields = ("status_code", "headers", "http_version", "reason")
    _lo = 0
    _hi = 0

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        self.status_code = _status(status_code, self._lo, self._hi)
        self.headers = normalize_headers(headers)
        self.http_version = _version(http_version)
        reason = to_bytes(reason, "reason")
        if b"\r" in reason or b"\n" in reason or b"\x00" in reason:
            raise LocalProtocolError("illegal reason phrase")
        self.reason = reason


class InformationalResponse(_ResponseBase):
    _lo, _hi = 100, 200


class Response(_ResponseBase):
    _lo, _hi = 200, 1000


class Data(_Event):
    _fields = ("data", "chunk_start", "chunk_end")

    def __init__(self, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)


class EndOfMessage(_Event):
    _fields = ("headers",)

    def __init__(self, headers=None):
        self.headers = normalize_headers(headers)


class ConnectionClosed(_Event):
    _fields = ()

    def __init__(self):
        pass
