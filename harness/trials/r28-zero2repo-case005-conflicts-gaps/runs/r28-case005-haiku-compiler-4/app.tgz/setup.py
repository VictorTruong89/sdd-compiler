"""Build script for httpwire (setuptools, flat layout, no native code)."""

# spec: N-000037, N-000038, N-000039, N-000040, N-000041, N-000042, N-000043, N-000044, N-000045, N-000046 — zero runtime deps, no compiled code, Python 3.8+ (CPython and PyPy), Linux/macOS/Windows, CPU only

from setuptools import find_packages, setup

# spec: N-000413, N-000414, N-000415, N-000416, N-000417, N-000418, N-000419, N-000420, N-000421, N-000422, N-000423, N-000424, N-000425, N-000426, N-000427, N-000428 — pure Python, zero runtime dependencies, Python 3.8+
setup(
    name="httpwire",
    version="0.1.0",
    description="Pure-Python HTTP/1.1 wire protocol library with no I/O",
    packages=find_packages(include=["httpwire", "httpwire.*"]),
    python_requires=">=3.8",
    install_requires=[],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)
