"""Tests for httpwire, named after the spec ids they exercise."""

import unittest

import httpwire
from httpwire import (
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
    ConnectionClosed,
    Connection,
    Data,
    EndOfMessage,
    InformationalResponse,
    LocalProtocolError,
    RemoteProtocolError,
    Request,
    Response,
)


def pair():
    return Connection(CLIENT), Connection(SERVER)


def get_request(extra=(), method=b"GET", target=b"/"):
    return Request(method=method, target=target,
                   headers=[(b"Host", b"example.com")] + list(extra))


class Pull(object):
    """Helpers that feed bytes to a connection and collect events."""

    @staticmethod
    def all(conn):
        out = []
        while True:
            ev = conn.next_event()
            if ev is NEED_DATA or ev is PAUSED:
                out.append(ev)
                return out
            out.append(ev)


class SurfaceTests(unittest.TestCase):
    # spec: N-000433, N-000437, N-000438, N-000440, N-000443, N-000446
    def test_package_root_names(self):
        for name in httpwire.__all__:
            self.assertTrue(hasattr(httpwire, name), name)
        # the spec's list of package-root names has 22 entries
        self.assertEqual(len(httpwire.__all__), 22)

    # spec: N-000438, N-000439
    def test_roles_distinct(self):
        self.assertIsNot(CLIENT, SERVER)
        self.assertFalse(CLIENT == SERVER)

    # spec: N-000440, N-000441, N-000442
    def test_non_event_results_distinct(self):
        self.assertIsNot(NEED_DATA, PAUSED)
        self.assertNotIsInstance(NEED_DATA, httpwire.Request)

    # spec: N-000443, N-000444, N-000445
    def test_nine_states_distinct(self):
        states = [IDLE, SEND_RESPONSE, SEND_BODY, DONE, MUST_CLOSE, CLOSED,
                  MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL, ERROR]
        self.assertEqual(len(set(id(s) for s in states)), 9)

    # spec: N-000446, N-000447, N-000448
    def test_protocol_errors_unrelated(self):
        self.assertFalse(issubclass(LocalProtocolError, RemoteProtocolError))
        self.assertFalse(issubclass(RemoteProtocolError, LocalProtocolError))

    # spec: N-000430, N-000431
    def test_no_cli_entry(self):
        self.assertFalse(hasattr(httpwire, "main"))


class EventTests(unittest.TestCase):
    # spec: N-000070, N-000071
    def test_six_event_types_are_distinct(self):
        kinds = (Request, InformationalResponse, Response, Data, EndOfMessage, ConnectionClosed)
        self.assertEqual(len(set(kinds)), 6)

    # spec: N-000072, N-000073, N-000074, N-000075, N-000076
    def test_request_defaults_and_bytes(self):
        r = Request(method="GET", target="/x", headers=[("Host", "h")])
        self.assertEqual(r.http_version, b"1.1")
        self.assertIs(type(r.method), bytes)
        self.assertIs(type(r.target), bytes)

    # spec: N-000077, N-000078
    def test_http11_needs_host(self):
        with self.assertRaises(LocalProtocolError):
            Request(method=b"GET", target=b"/", headers=[])
        Request(method=b"GET", target=b"/", headers=[], http_version=b"1.0")

    # spec: N-000104, N-000105
    def test_two_hosts_refused_any_version(self):
        with self.assertRaises(LocalProtocolError):
            Request(method=b"GET", target=b"/", headers=[(b"HOST", b"a"), (b"host", b"b")],
                    http_version=b"1.0")

    # spec: N-000079, N-000080, N-000081, N-000082, N-000083
    def test_status_ranges(self):
        InformationalResponse(100, [])
        InformationalResponse(199, [])
        with self.assertRaises(LocalProtocolError):
            InformationalResponse(200, [])
        Response(200, [])
        Response(999, [])
        with self.assertRaises(LocalProtocolError):
            Response(1000, [])
        with self.assertRaises(LocalProtocolError):
            Response("200", [])

    # spec: N-000460
    def test_status_int_subclass_accepted(self):
        import enum

        class S(enum.IntEnum):
            OK = 200

        self.assertEqual(Response(S.OK, []).status_code, 200)

    # spec: N-000084, N-000085
    def test_end_of_message_defaults(self):
        self.assertEqual(list(EndOfMessage().headers), [])

    # spec: N-000087, N-000088, N-000089, N-000090
    def test_header_names_lowercased(self):
        r = get_request([(b"X-Thing", b"Value")])
        self.assertIn((b"x-thing", b"Value"), list(r.headers))

    # spec: N-000091, N-000469, N-000470, N-000471
    def test_raw_items_keep_spelling(self):
        r = get_request([(b"X-Thing", b"Value")])
        self.assertIn((b"X-Thing", b"Value"), r.headers.raw_items())

    # spec: N-000092, N-000093
    def test_chunked_normalized_and_collapsed(self):
        r = Request(method=b"POST", target=b"/", headers=[
            (b"Host", b"h"), (b"Transfer-Encoding", b"CHUNKED")], http_version=b"1.1")
        self.assertIn((b"transfer-encoding", b"chunked"), list(r.headers))

    # spec: N-000094, N-000095
    def test_repeated_equal_content_length_collapses(self):
        r = Request(method=b"POST", target=b"/", headers=[
            (b"Host", b"h"), (b"Content-Length", b"5"), (b"content-length", b"5, 5")])
        cls = [v for k, v in r.headers if k == b"content-length"]
        self.assertEqual(cls, [b"5"])

    # spec: N-000114, N-000116, N-000118
    def test_disagreeing_content_length_refused(self):
        with self.assertRaises(LocalProtocolError):
            Request(method=b"POST", target=b"/", headers=[
                (b"Host", b"h"), (b"Content-Length", b"5"), (b"Content-Length", b"6")])

    # spec: N-000114
    def test_content_length_must_be_digits(self):
        with self.assertRaises(LocalProtocolError):
            Request(method=b"POST", target=b"/", headers=[
                (b"Host", b"h"), (b"Content-Length", b"5x")])

    # spec: N-000115, N-000117
    def test_content_length_digit_limit(self):
        Request(method=b"POST", target=b"/", headers=[
            (b"Host", b"h"), (b"Content-Length", b"9" * 18)])
        with self.assertRaises(LocalProtocolError):
            Request(method=b"POST", target=b"/", headers=[
                (b"Host", b"h"), (b"Content-Length", b"9" * 19)])

    # spec: N-000120, N-000121
    def test_transfer_encoding_refused_with_501(self):
        with self.assertRaises(LocalProtocolError) as cm:
            Request(method=b"POST", target=b"/", headers=[
                (b"Host", b"h"), (b"Transfer-Encoding", b"gzip, chunked")])
        self.assertEqual(cm.exception.error_status_hint, 501)
        with self.assertRaises(LocalProtocolError) as cm:
            Request(method=b"POST", target=b"/", headers=[
                (b"Host", b"h"), (b"Transfer-Encoding", b"chunked"),
                (b"Transfer-Encoding", b"chunked")])
        self.assertEqual(cm.exception.error_status_hint, 501)

    # spec: N-000106, N-000109
    def test_bad_header_name_refused(self):
        with self.assertRaises(LocalProtocolError):
            get_request([(b"Bad Name", b"v")])

    # spec: N-000097, N-000098, N-000099, N-000100
    def test_value_rules(self):
        get_request([(b"X", b"a\tb")])
        with self.assertRaises(LocalProtocolError):
            get_request([(b"X", b" lead")])
        with self.assertRaises(LocalProtocolError):
            get_request([(b"X", b"trail ")])
        with self.assertRaises(LocalProtocolError):
            get_request([(b"X", b"a\x01b")])
        with self.assertRaises(LocalProtocolError):
            get_request([(b"X", b"a\rb")])

    # spec: N-000110, N-000111
    def test_target_and_method_rules(self):
        with self.assertRaises(LocalProtocolError):
            Request(method=b"GE T", target=b"/", headers=[(b"Host", b"h")])
        with self.assertRaises(LocalProtocolError):
            Request(method=b"GET", target=b"/a b", headers=[(b"Host", b"h")])

    # spec: N-000459, N-000466, N-000298
    def test_invalid_construction_raises_and_connection_unaffected(self):
        c, s = pair()
        c.send(get_request())
        with self.assertRaises(LocalProtocolError):
            Request(method=b"GET", target=b"/", headers=[(b"bad name", b"v")])
        self.assertEqual(c.our_state, SEND_BODY)

    # spec: N-000459, N-000458
    def test_bytes_like_accepted(self):
        r = Request(method=bytearray(b"GET"), target=memoryview(b"/"), headers=[(b"Host", b"h")])
        self.assertIs(type(r.target), bytes)

    # spec: N-000456, N-000457
    def test_connection_closed_has_no_fields(self):
        self.assertEqual(ConnectionClosed(), ConnectionClosed())


class HeaderFramingNormalizationTests(unittest.TestCase):
    # spec: N-000096 (CL decides when both present on a request)
    def test_request_content_length_decides_framing(self):
        c, s = pair()
        c.send(Request(method=b"POST", target=b"/", headers=[
            (b"Host", b"h"), (b"Transfer-Encoding", b"chunked"), (b"Content-Length", b"3")]))
        self.assertEqual(c.send(Data(b"abc")), b"abc")
        self.assertIsNone(c.send(EndOfMessage()))


class FramingTests(unittest.TestCase):
    # spec: N-000185, N-000186, N-000187
    def test_request_without_framing_is_empty(self):
        c, s = pair()
        self.assertEqual(c.send(get_request()), b"GET / HTTP/1.1\r\nHost: example.com\r\n\r\n")
        self.assertIsNone(c.send(EndOfMessage()))
        # body bytes are refused when the framing gives no body
        c2, _ = pair()
        c2.send(get_request())
        with self.assertRaises(LocalProtocolError):
            c2.send(Data(b"x"))
        s.receive_data(b"GET / HTTP/1.1\r\nHost: example.com\r\n\r\n")
        self.assertIsInstance(s.next_event(), Request)
        self.assertIsInstance(s.next_event(), EndOfMessage)

    # spec: N-000188, N-000189, N-000190, N-000191
    def test_content_length_body(self):
        c, s = pair()
        c.send(Request(method=b"POST", target=b"/", headers=[
            (b"Host", b"h"), (b"Content-Length", b"5")]))
        self.assertEqual(c.send(Data(b"hel")), b"hel")
        self.assertEqual(c.send(Data(b"lo")), b"lo")
        self.assertIsNone(c.send(EndOfMessage()))
        self.assertEqual(c.our_state, DONE)

    # spec: N-000239 — EOM before the declared length is refused (and ERROR)
    def test_end_of_message_before_content_length_refused(self):
        c, s = pair()
        c.send(Request(method=b"POST", target=b"/", headers=[
            (b"Host", b"h"), (b"Content-Length", b"5")]))
        c.send(Data(b"hel"))
        with self.assertRaises(LocalProtocolError):
            c.send(EndOfMessage())
        self.assertIs(c.our_state, ERROR)

    # spec: N-000238
    def test_data_beyond_content_length_refused(self):
        c, s = pair()
        c.send(Request(method=b"POST", target=b"/", headers=[
            (b"Host", b"h"), (b"Content-Length", b"2")]))
        with self.assertRaises(LocalProtocolError):
            c.send(Data(b"abc"))
        self.assertEqual(c.our_state, ERROR)

    # spec: N-000192, N-000193, N-000194, N-000195, N-000196, N-000197
    def test_chunked_request_encoding(self):
        c, s = pair()
        out = c.send(Request(method=b"POST", target=b"/", headers=[
            (b"Host", b"h"), (b"Transfer-Encoding", b"chunked")]))
        self.assertTrue(out.endswith(b"\r\n\r\n"))
        self.assertEqual(c.send(Data(b"hello")), b"5\r\nhello\r\n")
        self.assertIsNone(c.send(Data(b"")))
        self.assertEqual(c.send(EndOfMessage(headers=[(b"X-T", b"1")])),
                         b"0\r\nX-T: 1\r\n\r\n")

    # spec: N-000220, N-000221, N-000222, N-000223, N-000224, N-000225, N-000226, N-000227
    def test_chunk_marks_when_pulled(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n"
                       b"5\r\nhello\r\n0\r\n\r\n")
        self.assertIsInstance(s.next_event(), Request)
        d = s.next_event()
        self.assertIsInstance(d, Data)
        self.assertEqual(d.data, b"hello")
        self.assertTrue(d.chunk_start)
        self.assertTrue(d.chunk_end)
        self.assertIsInstance(s.next_event(), EndOfMessage)

    # spec: N-000220, N-000221, N-000222, N-000223, N-000224, N-000225
    def test_chunk_split_across_pieces(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n"
                       b"5\r\nhe")
        self.assertIsInstance(s.next_event(), Request)
        d1 = s.next_event()
        self.assertEqual((d1.data, d1.chunk_start, d1.chunk_end), (b"he", True, False))
        self.assertIs(s.next_event(), NEED_DATA)
        s.receive_data(b"llo\r\n0\r\n\r\n")
        d2 = s.next_event()
        self.assertEqual((d2.data, d2.chunk_start, d2.chunk_end), (b"llo", False, True))
        self.assertIsInstance(s.next_event(), EndOfMessage)

    # spec: N-000228, N-000229, N-000230, N-000231, N-000232
    def test_chunk_extension_discarded(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n"
                       b"3;foo=bar\r\nabc\r\n0\r\n\r\n")
        s.next_event()
        d = s.next_event()
        self.assertEqual(d.data, b"abc")

    # spec: N-000242, N-000243, N-000244, N-000245
    def test_bad_chunk_size_refused(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n"
                       b"zz\r\n")
        s.next_event()
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    # spec: N-000244
    def test_chunk_data_needs_crlf(self):
        s = Connection(SERVER)
        s.receive_data(b"POST / HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n"
                       b"2\r\nabXX")
        s.next_event()
        s.next_event()
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    # spec: N-000233, N-000234, N-000235, N-000236, N-000237
    def test_passthrough_keeps_object_identity(self):
        class Blob(object):
            def __init__(self, n):
                self.n = n

            def __len__(self):
                return self.n

        c, s = pair()
        c.send(Request(method=b"POST", target=b"/", headers=[
            (b"Host", b"h"), (b"Transfer-Encoding", b"chunked")]))
        blob = Blob(4)
        pieces = c.send_with_data_passthrough(Data(blob))
        self.assertIsInstance(pieces, list)
        self.assertIs(pieces[1], blob)
        self.assertEqual(pieces[0], b"4\r\n")
        self.assertEqual(pieces[2], b"\r\n")

    # spec: N-000233, N-000237
    def test_passthrough_content_length_adds_no_pieces(self):
        class Blob(object):
            def __len__(self):
                return 3

        c, s = pair()
        c.send(Request(method=b"POST", target=b"/", headers=[
            (b"Host", b"h"), (b"Content-Length", b"3")]))
        blob = Blob()
        pieces = c.send_with_data_passthrough(Data(blob))
        self.assertEqual(len(pieces), 1)
        self.assertIs(pieces[0], blob)

    # spec: N-000198, N-000199
    def test_response_content_length_kept_even_zero(self):
        c, s = pair()
        s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
        s.next_event(); s.next_event()
        out = s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
        self.assertIn(b"Content-Length: 0\r\n", out)

    # spec: N-000202
    def test_response_to_http11_is_chunked(self):
        c, s = pair()
        s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
        s.next_event(); s.next_event()
        out = s.send(Response(status_code=200, headers=[]))
        self.assertIn(b"Transfer-Encoding: chunked\r\n", out)
        self.assertEqual(s.send(Data(b"ab")), b"2\r\nab\r\n")
        self.assertEqual(s.send(EndOfMessage()), b"0\r\n\r\n")

    # spec: N-000203, N-000204, N-000205, N-000206
    def test_response_to_http10_is_close_delimited(self):
        c, s = pair()
        s.receive_data(b"GET / HTTP/1.0\r\n\r\n")
        s.next_event(); s.next_event()
        out = s.send(Response(status_code=200, headers=[]))
        self.assertNotIn(b"Transfer-Encoding", out)
        self.assertNotIn(b"Content-Length", out)
        self.assertIn(b"Connection: close\r\n", out)
        self.assertEqual(s.send(Data(b"raw")), b"raw")
        self.assertIsNone(s.send(EndOfMessage()))

    # spec: N-000207
    def test_response_transfer_encoding_wins(self):
        c, s = pair()
        s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
        s.next_event(); s.next_event()
        out = s.send(Response(status_code=200, headers=[
            (b"Transfer-Encoding", b"chunked"), (b"Content-Length", b"9")]))
        self.assertNotIn(b"Content-Length", out)
        self.assertIn(b"Transfer-Encoding: chunked", out)

    # spec: N-000215, N-000216, N-000217, N-000218
    def test_204_and_304_have_no_body_or_framing(self):
        c, s = pair()
        s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
        s.next_event(); s.next_event()
        out = s.send(Response(status_code=204, headers=[(b"Content-Length", b"0")]))
        self.assertNotIn(b"Content-Length", out)
        self.assertIsNone(s.send(EndOfMessage()))

    # spec: N-000215, N-000219
    def test_head_gets_get_framing_headers_but_no_body(self):
        c, s = pair()
        s.receive_data(b"HEAD / HTTP/1.1\r\nHost: h\r\n\r\n")
        s.next_event(); s.next_event()
        out = s.send(Response(status_code=200, headers=[]))
        self.assertIn(b"Transfer-Encoding: chunked\r\n", out)
        self.assertIsNone(s.send(EndOfMessage()))
        # no body is sent for HEAD, so data is refused
        s2 = Connection(SERVER)
        s2.receive_data(b"HEAD / HTTP/1.1\r\nHost: h\r\n\r\n")
        s2.next_event(); s2.next_event()
        s2.send(Response(status_code=200, headers=[]))
        with self.assertRaises(LocalProtocolError):
            s2.send(Data(b"x"))

    # spec: N-000208, N-000209, N-000210, N-000211, N-000212, N-000213, N-000214
    def test_client_reads_close_delimited_body(self):
        c = Connection(CLIENT)
        c.send(get_request())
        c.send(EndOfMessage())
        c.receive_data(b"HTTP/1.0 200 OK\r\n\r\nbody bytes")
        ev = c.next_event()
        self.assertIsInstance(ev, Response)
        self.assertEqual(c.next_event().data, b"body bytes")
        self.assertIs(c.next_event(), NEED_DATA)
        c.receive_data(b"")
        self.assertIsInstance(c.next_event(), EndOfMessage)
        self.assertIsInstance(c.next_event(), ConnectionClosed)
        self.assertEqual(c.their_state, CLOSED)
        self.assertEqual(c.our_state, MUST_CLOSE)

    # spec: N-000324, N-000325
    def test_close_mid_content_length_body_is_remote_error(self):
        c = Connection(CLIENT)
        c.send(get_request())
        c.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 9\r\n\r\nabc")
        c.next_event()
        c.next_event()
        c.receive_data(b"")
        with self.assertRaises(RemoteProtocolError):
            c.next_event()

    # spec: N-000161, N-000162
    def test_host_written_first(self):
        c, s = pair()
        out = c.send(Request(method=b"GET", target=b"/", headers=[
            (b"X-A", b"1"), (b"Host", b"h"), (b"X-B", b"2")]))
        self.assertEqual(out, b"GET / HTTP/1.1\r\nHost: h\r\nX-A: 1\r\nX-B: 2\r\n\r\n")

    # spec: N-000163, N-000164
    def test_original_casing_on_wire(self):
        c, s = pair()
        out = c.send(Request(method=b"GET", target=b"/", headers=[
            (b"Host", b"h"), (b"X-Mixed-Case", b"v")]))
        self.assertIn(b"X-Mixed-Case: v", out)


class ParsingTests(unittest.TestCase):
    # spec: N-000165, N-000166
    def test_lone_lf_accepted_and_status_without_reason(self):
        c = Connection(CLIENT)
        c.send(get_request())
        c.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 204\nX-A: 1\n\n")
        ev = c.next_event()
        self.assertIsInstance(ev, Response)
        self.assertEqual(ev.reason, b"")

    # spec: N-000167, N-000168, N-000169
    def test_obs_fold_joined_to_previous_value(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\nX-Long: a\r\n    b\r\n\r\n")
        r = s.next_event()
        self.assertIn((b"x-long", b"a b"), list(r.headers))

    # spec: N-000170, N-000171
    def test_peer_version_recorded_on_pull_only(self):
        c, s = pair()
        c.send(get_request(method=b"GET"))
        self.assertIsNone(c.their_http_version)
        s.receive_data(b"GET / HTTP/1.0\r\nHost: h\r\n\r\n")
        s.next_event()
        self.assertEqual(s.their_http_version, b"1.0")

    # spec: N-000177, N-000178, N-000179
    def test_space_or_control_first_byte_fails_at_once(self):
        s = Connection(SERVER)
        s.receive_data(b" GET")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    # spec: N-000174, N-000175, N-000176
    def test_continuation_without_header_refused(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\n  x\r\nHost: h\r\n\r\n")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    # spec: N-000180, N-000181, N-000182
    def test_bytes_after_receive_close_is_runtime_error(self):
        s = Connection(SERVER)
        s.receive_data(b"")
        with self.assertRaises(RuntimeError) as cm:
            s.receive_data(b"x")
        self.assertNotIsInstance(cm.exception, (LocalProtocolError, RemoteProtocolError))

    # spec: N-000127
    def test_pull_on_empty_is_need_data(self):
        self.assertIs(Connection(SERVER).next_event(), NEED_DATA)

    # spec: N-000153, N-000154, N-000155
    def test_partial_event_retained(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: h")
        self.assertIs(s.next_event(), NEED_DATA)
        s.receive_data(b"\r\n\r\n")
        self.assertIsInstance(s.next_event(), Request)

    # spec: N-000144, N-000145, N-000146, N-000147, N-000148, N-000149, N-000150, N-000151, N-000152
    def test_feed_stores_pull_parses_one_event(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\nGET /2 HTTP/1.1\r\nHost: h\r\n\r\n")
        self.assertEqual(s.our_state, IDLE)
        self.assertIsInstance(s.next_event(), Request)
        self.assertIsInstance(s.trailing_data[0], bytes)

    # spec: N-000316, N-000317, N-000318, N-000319, N-000320, N-000321, N-000322, N-000323
    def test_incomplete_size_limit_431(self):
        s = Connection(SERVER, 100)
        s.receive_data(b"GET / HTTP/1.1\r\n" + b"X-Pad: " + b"a" * 200)
        with self.assertRaises(RemoteProtocolError) as cm:
            s.next_event()
        self.assertEqual(cm.exception.error_status_hint, 431)
        self.assertEqual(s.their_state, ERROR)

    # spec: N-000316, N-000317, N-000318
    def test_default_limit_is_8kib(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\n" + b"X: " + b"a" * (8 * 1024))
        with self.assertRaises(RemoteProtocolError):
            s.next_event()

    # spec: N-000321, N-000322
    def test_complete_head_larger_than_limit_is_fine(self):
        s = Connection(SERVER, 50)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\nX: " + b"a" * 30 + b"\r\n\r\n")
        self.assertIsInstance(s.next_event(), Request)

    # spec: N-000479, N-000476, N-000477
    def test_role_validation_and_max_argument(self):
        with self.assertRaises(LocalProtocolError):
            Connection("client")
        self.assertIsInstance(Connection(CLIENT, 1000), Connection)

    # spec: N-000481, N-000482
    def test_their_version_none_before_recorded(self):
        self.assertIsNone(Connection(SERVER).their_http_version)

    # spec: N-000483, N-000484
    def test_states_indexable_both_ways(self):
        c = Connection(CLIENT)
        self.assertIs(c.states[CLIENT], IDLE)
        self.assertIs(c.states[0], IDLE)
        self.assertIs(c.states[1], IDLE)


class LifecycleTests(unittest.TestCase):
    # spec: N-000247, N-000248, N-000249, N-000250, N-000251, N-000252, N-000253, N-000254
    def test_full_cycle_and_states(self):
        c, s = pair()
        c.send(get_request())
        self.assertIs(c.our_state, SEND_BODY)
        self.assertIs(c.their_state, SEND_RESPONSE)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: example.com\r\n\r\n")
        self.assertIsInstance(s.next_event(), Request)
        self.assertIs(s.our_state, SEND_RESPONSE)
        self.assertIs(s.their_state, SEND_BODY)
        s.send(Response(status_code=204, headers=[]))
        s.send(EndOfMessage())
        self.assertIs(s.our_state, DONE)

    # spec: N-000270, N-000271
    def test_next_cycle_after_both_done(self):
        c, s = pair()
        c.send(get_request())
        c.send(EndOfMessage())
        s.receive_data(b"GET / HTTP/1.1\r\nHost: example.com\r\n\r\n")
        s.next_event(); s.next_event()
        s.send(Response(status_code=204, headers=[]))
        s.send(EndOfMessage())
        c.receive_data(b"HTTP/1.1 204 No Content\r\n\r\n")
        c.next_event(); c.next_event()
        self.assertIs(c.our_state, DONE)
        self.assertIs(c.their_state, DONE)
        c.start_next_cycle()
        s.start_next_cycle()
        self.assertIs(c.our_state, IDLE)
        self.assertIs(s.our_state, IDLE)

    # spec: N-000280, N-000281, N-000282
    def test_next_cycle_refused_is_recoverable(self):
        c, s = pair()
        c.send(get_request())
        with self.assertRaises(LocalProtocolError):
            c.start_next_cycle()
        self.assertIs(c.our_state, SEND_BODY)

    # spec: N-000283, N-000284, N-000285, N-000307
    def test_second_request_refused_and_error(self):
        c, s = pair()
        c.send(get_request())
        c.send(EndOfMessage())
        with self.assertRaises(LocalProtocolError):
            c.send(get_request())
        self.assertIs(c.our_state, ERROR)
        with self.assertRaises(LocalProtocolError):
            c.send(EndOfMessage())

    # spec: N-000275, N-000276, N-000277, N-000278, N-000279
    def test_server_pipelining_paused_then_next_request(self):
        s = Connection(SERVER)
        s.receive_data(b"GET /1 HTTP/1.1\r\nHost: h\r\n\r\nGET /2 HTTP/1.1\r\nHost: h\r\n\r\n")
        s.next_event()
        s.next_event()
        s.send(Response(status_code=204, headers=[]))
        s.send(EndOfMessage())
        self.assertIs(s.next_event(), PAUSED)
        s.receive_data(b"GET /3 HTTP/1.1\r\nHost: h\r\n\r\n")
        self.assertIs(s.next_event(), PAUSED)

    # spec: N-000259, N-000260, N-000261, N-000262, N-000263, N-000264
    def test_connection_close_disables_keepalive(self):
        c, s = pair()
        c.send(get_request([(b"Connection", b"close")]))
        c.send(EndOfMessage())
        # keep-alive is off, so a side that would enter DONE enters MUST_CLOSE
        self.assertIs(c.our_state, MUST_CLOSE)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\nConnection: close\r\n\r\n")
        s.next_event(); s.next_event()
        out = s.send(Response(status_code=204, headers=[]))
        self.assertIn(b"Connection: close", out)
        s.send(EndOfMessage())
        self.assertIs(s.our_state, MUST_CLOSE)

    # spec: N-000259, N-000286, N-000063
    def test_http10_cannot_keepalive(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.0\r\nHost: h\r\nConnection: keep-alive\r\n\r\n")
        s.next_event(); s.next_event()
        s.send(Response(status_code=204, headers=[]))
        s.send(EndOfMessage())
        self.assertIs(s.our_state, MUST_CLOSE)
        with self.assertRaises(LocalProtocolError):
            s.start_next_cycle()

    # spec: N-000272, N-000273, N-000274
    def test_client_no_pipelining(self):
        c, s = pair()
        c.send(get_request())
        with self.assertRaises(LocalProtocolError):
            c.send(get_request())

    # spec: N-000283
    def test_client_cannot_send_response(self):
        c, s = pair()
        with self.assertRaises(LocalProtocolError):
            c.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))

    # spec: N-000255, N-000256, N-000257, N-000258
    def test_server_may_send_response_without_request(self):
        s = Connection(SERVER)
        out = s.send(Response(status_code=400, headers=[(b"Content-Length", b"0")]))
        self.assertIn(b"HTTP/1.1 400", out)
        self.assertIs(s.our_state, SEND_BODY)

    # spec: N-000255, N-000256, N-000257, N-000258 — unknown peer version means close-delimited
    def test_unknown_peer_version_close_delimited(self):
        s = Connection(SERVER)
        out = s.send(Response(status_code=400, headers=[]))
        self.assertIn(b"Connection: close", out)
        self.assertNotIn(b"Transfer-Encoding", out)

    # spec: N-000283, N-000285 — invalid event forwarding ERROR
    def test_send_after_error_fails(self):
        c = Connection(CLIENT)
        with self.assertRaises(LocalProtocolError):
            c.send(Response(status_code=200, headers=[]))
        with self.assertRaises(LocalProtocolError):
            c.send(get_request())

    # spec: N-000302, N-000303, N-000304, N-000305, N-000306
    def test_remote_error_then_server_can_send_error_response(self):
        s = Connection(SERVER)
        s.receive_data(b"GARBAGE\r\n\r\n")
        with self.assertRaises(RemoteProtocolError):
            s.next_event()
        self.assertIs(s.their_state, ERROR)
        with self.assertRaises(RemoteProtocolError):
            s.next_event()
        out = s.send(Response(status_code=400, headers=[(b"Content-Length", b"0")]))
        self.assertIn(b"Connection: close", out)

    # spec: N-000311
    def test_error_makes_done_side_must_close(self):
        c, s = pair()
        c.send(get_request())
        c.send(EndOfMessage())
        c.send_failed()
        self.assertIs(c.our_state, ERROR)
        self.assertIs(c.their_state, SEND_RESPONSE)

    # spec: N-000312, N-000313, N-000314, N-000315
    def test_send_failed_marks_error_and_keeps_peer(self):
        c, s = pair()
        c.send(get_request())
        c.send_failed()
        self.assertIs(c.our_state, ERROR)
        self.assertIs(c.their_state, SEND_RESPONSE)
        with self.assertRaises(LocalProtocolError):
            c.send(EndOfMessage())

    # spec: N-000332, N-000333, N-000334, N-000335
    def test_client_close_produces_no_bytes(self):
        c, s = pair()
        self.assertIsNone(c.send(ConnectionClosed()))
        self.assertIs(c.our_state, CLOSED)
        # the peer was IDLE, so it must close now
        self.assertIs(c.their_state, MUST_CLOSE)

    # spec: N-000345, N-000346
    def test_close_during_send_body_is_refused(self):
        c, s = pair()
        c.send(get_request())
        with self.assertRaises(LocalProtocolError):
            c.send(ConnectionClosed())

    # spec: N-000339, N-000340, N-000341
    def test_peer_close_pulled_as_connection_closed(self):
        s = Connection(SERVER)
        s.receive_data(b"")
        self.assertIsInstance(s.next_event(), ConnectionClosed)
        self.assertIsInstance(s.next_event(), ConnectionClosed)
        self.assertIs(s.their_state, CLOSED)

    # spec: N-000342, N-000343
    def test_pipelined_requests_before_close_handled_first(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\n\r\n")
        s.receive_data(b"")
        self.assertIsInstance(s.next_event(), Request)
        self.assertIsInstance(s.next_event(), EndOfMessage)
        s.send(Response(status_code=204, headers=[]))
        s.send(EndOfMessage())
        self.assertIsInstance(s.next_event(), ConnectionClosed)

    # spec: N-000336, N-000337, N-000338
    def test_closed_makes_idle_peer_must_close(self):
        c, s = pair()
        c.send(ConnectionClosed())
        self.assertIs(c.our_state, CLOSED)
        self.assertIs(c.their_state, MUST_CLOSE)
        # the server, once it pulls the close, is CLOSED and the client MUST_CLOSE
        s.receive_data(b"")
        self.assertIsInstance(s.next_event(), ConnectionClosed)
        self.assertIs(s.their_state, CLOSED)
        self.assertIs(s.our_state, MUST_CLOSE)

    # spec: N-000344
    def test_must_close_sends_close_to_enter_closed(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.0\r\nHost: h\r\n\r\n")
        s.next_event(); s.next_event()
        s.send(Response(status_code=204, headers=[]))
        s.send(EndOfMessage())
        self.assertIs(s.our_state, MUST_CLOSE)
        s.send(ConnectionClosed())
        self.assertIs(s.our_state, CLOSED)


class ExpectAndSwitchTests(unittest.TestCase):
    # spec: N-000354, N-000355, N-000352
    def test_100_continue_flags(self):
        c, s = pair()
        c.send(get_request([(b"Expect", b"100-continue")]))
        self.assertTrue(c.client_is_waiting_for_100_continue)
        self.assertFalse(c.they_are_waiting_for_100_continue)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\nExpect: 100-Continue\r\n\r\n")
        s.next_event()
        self.assertTrue(s.client_is_waiting_for_100_continue)
        self.assertTrue(s.they_are_waiting_for_100_continue)

    # spec: N-000357
    def test_http10_expect_sets_no_flag(self):
        s = Connection(SERVER)
        s.receive_data(b"GET / HTTP/1.0\r\nHost: h\r\nExpect: 100-continue\r\n\r\n")
        s.next_event()
        self.assertFalse(s.client_is_waiting_for_100_continue)
        self.assertFalse(s.they_are_waiting_for_100_continue)

    # spec: N-000349, N-000350, N-000351, N-000352, N-000353, N-000358
    def test_informational_then_final_clears_wait(self):
        c, s = pair()
        c.send(get_request([(b"Expect", b"100-continue")]))
        s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\nExpect: 100-continue\r\n\r\n")
        s.next_event()
        s.send(InformationalResponse(100, []))
        self.assertFalse(s.they_are_waiting_for_100_continue)
        out = s.send(InformationalResponse(100, []))
        self.assertIsNotNone(out)
        self.assertIs(s.our_state, SEND_RESPONSE)

    # spec: N-000364, N-000365, N-000381, N-000362
    def test_connect_accepted_by_200(self):
        c, s = pair()
        c.send(Request(method=b"CONNECT", target=b"x:1", headers=[(b"Host", b"x:1")]))
        c.send(EndOfMessage())
        self.assertIs(c.our_state, MIGHT_SWITCH_PROTOCOL)
        s.receive_data(b"CONNECT x:1 HTTP/1.1\r\nHost: x:1\r\n\r\n")
        s.next_event()
        s.next_event()
        self.assertIs(s.next_event(), PAUSED)
        s.send(Response(status_code=200, headers=[]))
        self.assertIs(s.our_state, SWITCHED_PROTOCOL)
        # the client pulls the accepting response and is SWITCHED too
        c.receive_data(b"HTTP/1.1 200 OK\r\n\r\nraw-tunnel")
        c.next_event()
        self.assertIs(c.our_state, SWITCHED_PROTOCOL)
        self.assertIs(c.their_state, SWITCHED_PROTOCOL)
        self.assertIs(c.next_event(), PAUSED)

    # spec: N-000394, N-000395
    def test_connect_non_200_2xx_is_denial(self):
        c, s = pair()
        c.send(Request(method=b"CONNECT", target=b"x:1", headers=[(b"Host", b"x:1")]))
        c.send(EndOfMessage())
        s.receive_data(b"CONNECT x:1 HTTP/1.1\r\nHost: x:1\r\n\r\n")
        s.next_event(); s.next_event()
        s.send(Response(status_code=201, headers=[(b"Content-Length", b"0")]))
        self.assertIs(s.our_state, SEND_BODY)
        # any other final response denies; the client is DONE once it pulls it
        c.receive_data(b"HTTP/1.1 201 Created\r\nContent-Length: 0\r\n\r\n")
        c.next_event()
        self.assertIs(c.our_state, DONE)

    # spec: N-000366, N-000367, N-000368, N-000378, N-000379, N-000380
    def test_upgrade_denied_by_final_response(self):
        c, s = pair()
        c.send(Request(method=b"GET", target=b"/", headers=[
            (b"Host", b"h"), (b"Upgrade", b"websocket"), (b"Connection", b"Upgrade")]))
        c.send(EndOfMessage())
        self.assertIs(c.our_state, MIGHT_SWITCH_PROTOCOL)
        s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\nUpgrade: websocket\r\n\r\n")
        s.next_event(); s.next_event()
        s.send(Response(status_code=200, headers=[(b"Content-Length", b"0")]))
        self.assertIs(s.our_state, SEND_BODY)
        c.receive_data(b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")
        c.next_event()
        self.assertIs(c.our_state, DONE)

    # spec: N-000369, N-000370, N-000371, N-000372
    def test_upgrade_accepted_by_101(self):
        c, s = pair()
        c.send(Request(method=b"GET", target=b"/", headers=[
            (b"Host", b"h"), (b"Upgrade", b"websocket")]))
        c.send(EndOfMessage())
        s.receive_data(b"GET / HTTP/1.1\r\nHost: h\r\nUpgrade: websocket\r\n\r\n")
        s.next_event(); s.next_event()
        s.send(InformationalResponse(101, [(b"Upgrade", b"websocket")]))
        self.assertIs(s.our_state, SWITCHED_PROTOCOL)
        with self.assertRaises(LocalProtocolError):
            s.send(EndOfMessage())
        with self.assertRaises(LocalProtocolError):
            s.start_next_cycle()
        self.assertIs(s.next_event(), PAUSED)

    # spec: N-000388, N-000389, N-000390, N-000391
    def test_trailing_data_after_accept(self):
        s = Connection(SERVER)
        s.receive_data(b"CONNECT x:1 HTTP/1.1\r\nHost: x:1\r\n\r\nRAW")
        self.assertIsInstance(s.next_event(), Request)
        self.assertIsInstance(s.next_event(), EndOfMessage)
        s.send(Response(status_code=200, headers=[]))
        s.receive_data(b"TUNNEL")
        self.assertIs(s.next_event(), PAUSED)
        # bytes after the accepting response are never parsed as HTTP
        self.assertEqual(s.trailing_data, (b"RAWTUNNEL", False))

    # spec: N-000392, N-000393
    def test_client_in_might_switch_cannot_send_request(self):
        c, s = pair()
        c.send(Request(method=b"CONNECT", target=b"x:1", headers=[(b"Host", b"x:1")]))
        c.send(EndOfMessage())
        with self.assertRaises(LocalProtocolError):
            c.send(get_request())

    # spec: N-000406, N-000407
    def test_start_next_cycle_while_proposal_unanswered_is_recoverable(self):
        c, s = pair()
        c.send(Request(method=b"CONNECT", target=b"x:1", headers=[(b"Host", b"x:1")]))
        c.send(EndOfMessage())
        with self.assertRaises(LocalProtocolError):
            c.start_next_cycle()
        self.assertIs(c.our_state, MIGHT_SWITCH_PROTOCOL)


class NoIOTests(unittest.TestCase):
    # spec: N-000047, N-000048, N-000049, N-000003 — the library never opens sockets
    # or starts processes
    def test_package_sources_do_no_io(self):
        import os
        pkg = os.path.join(os.path.dirname(httpwire.__file__))
        for name in os.listdir(pkg):
            if not name.endswith(".py"):
                continue
            with open(os.path.join(pkg, name)) as fh:
                source = fh.read()
            for banned in ("import socket", "import subprocess", "import http", "import ssl"):
                self.assertNotIn(banned, source, name)


if __name__ == "__main__":
    unittest.main()
