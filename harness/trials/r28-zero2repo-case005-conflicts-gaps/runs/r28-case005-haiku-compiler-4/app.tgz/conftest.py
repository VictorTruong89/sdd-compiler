# Empty on purpose: a rootdir conftest makes pytest put /app on sys.path,
# so `import httpwire` works from the repository root without an install.
