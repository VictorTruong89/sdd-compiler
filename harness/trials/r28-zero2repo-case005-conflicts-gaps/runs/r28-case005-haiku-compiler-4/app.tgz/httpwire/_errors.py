"""Protocol error classes.

Both concrete kinds carry ``error_status_hint``, an exact ``int``
(the suggested HTTP status; default 400).  ``str(error)`` is the message.
"""


# spec index: N-000292 (every protocol error has a suggested status), N-000293 (default 400),
#   N-000326 (local and remote errors are distinct), N-000472 (error_status_hint is an int),
#   N-000473 (str(error) is the message), N-000446, N-000447, N-000448 (separate classes)

class _ProtocolErrorBase(Exception):
    def __init__(self, message="", error_status_hint=400):
        Exception.__init__(self, message)
        # spec: N-000472 (error_status_hint is exactly an int)
        self.error_status_hint = int(error_status_hint)


# spec: N-000446, N-000447, N-000448 (distinct classes, neither subclasses
# the other); spec: N-000290, N-000291 (not the runtime error below)
class LocalProtocolError(_ProtocolErrorBase):
    """The integrator's own event or send violated the protocol."""


class RemoteProtocolError(_ProtocolErrorBase):
    """The peer's bytes violated the protocol."""
