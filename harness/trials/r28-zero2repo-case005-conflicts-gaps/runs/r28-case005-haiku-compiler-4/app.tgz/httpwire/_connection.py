"""The sans-I/O HTTP/1.1 connection state machine."""

# spec index (connection): N-000122 (connection object), N-000123, N-000124, N-000125, N-000126
#   (roles, IDLE start, states agree), N-000127 (empty pull is need-data), N-000128, N-000129, N-000130, N-000131, N-000132, N-000133, N-000134, N-000135, N-000136, N-000137, N-000138, N-000139
#   (request/response send and pull, server SEND_RESPONSE, client SEND_BODY, DONE), N-000140, N-000141, N-000142, N-000143
#   (Content-Length bodies), N-000144, N-000145, N-000146, N-000147, N-000148, N-000149, N-000150, N-000151, N-000152 (feed stores, pull parses one event), N-000183, N-000184
#   (framing choice), N-000200, N-000201 (response framing by peer version), N-000246 (only chunked),
#   N-000287 (HTTP/1.0 cannot keep alive), N-000297, N-000298, N-000299, N-000300, N-000301 (recoverable refusals), N-000326, N-000327, N-000328, N-000329, N-000330, N-000331
#   (distinct errors; ERROR is final; send after remote error works), N-000347, N-000348 (pulled close
#   and bytes after close), N-000350, N-000351, N-000360, N-000361, N-000363 (switch proposals),
#   N-000396, N-000397, N-000398, N-000399, N-000400, N-000401, N-000402, N-000403, N-000404, N-000405 (accepted switch is permanent), N-000408, N-000409, N-000410, N-000411, N-000412 (paused kinds),
#   N-000473, N-000474, N-000475 (runtime error on bytes after close, not a protocol error),
#   N-000157 (non-1.1 request or response is never sent), N-000158, N-000159 (HTTP/1.0 peer
#   requests and responses are read and report version 1.0), N-000160 (HTTP/1.0 request with no
#   framing headers has an empty body),
#   N-000296 (431 for an oversized incomplete event), N-000300, N-000301 (next-cycle refusal is
#   recoverable), N-000327, N-000328, N-000329, N-000330 (ERROR is final; receive after a local send error),
#   N-000396, N-000397 (only 200 accepts CONNECT), N-000399, N-000400, N-000401, N-000402, N-000403, N-000404 (permanence; refused send
#   after acceptance is ERROR), N-000409, N-000410, N-000411 (paused versus need-data),
#   N-000474 (bytes after close raise RuntimeError), N-000476, N-000477, N-000478, N-000479, N-000480, N-000481, N-000482, N-000483, N-000484, N-000485, N-000486, N-000487, N-000488, N-000489, N-000490, N-000491, N-000492, N-000493
#   (Connection surface: roles, states, versions, waiting flags, trailing data),
#   N-000494, N-000495, N-000496, N-000497, N-000498, N-000499, N-000500, N-000501, N-000502, N-000503, N-000504, N-000505, N-000506, N-000507, N-000508, N-000509, N-000510, N-000511, N-000512, N-000513, N-000514, N-000515, N-000516, N-000517, N-000518, N-000519, N-000520, N-000521, N-000522 (feed, pull, send, cycle and failure methods)

from ._errors import LocalProtocolError, RemoteProtocolError
from ._events import (
    EVENT_TYPES,
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    Request,
    Response,
)
from ._headers import content_length, has_header, has_token
from ._sentinels import (
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
)
from ._wire import (
    parse_chunk_size,
    parse_fields,
    parse_request_line,
    parse_status_line,
    split_head,
)

# spec: N-000478, N-000479, N-000480 — default incomplete-event limit is 8 KiB, per the
# Interface Contract's stated default (see NOTES.md for the PRD conflict).
DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 8 * 1024

_FRAMING_NAMES = (b"content-length", b"transfer-encoding")
_KEEP = object()

# spec: N-000497, N-000498, N-000499, N-000500, N-000501, N-000502, N-000503, N-000504, N-000505, N-000506, N-000507, N-000508, N-000509, N-000510, N-000511, N-000512, N-000513, N-000514, N-000515, N-000516, N-000517, N-000518, N-000519, N-000520, N-000521, N-000522 — per-role event-triggered transitions.
# Keys are the sender's current state; values map event type -> next state.
_TABLES = {
    CLIENT: {
        IDLE: {Request: SEND_BODY, ConnectionClosed: CLOSED},
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
    },
    SERVER: {
        IDLE: {Response: SEND_BODY, ConnectionClosed: CLOSED},
        SEND_RESPONSE: {InformationalResponse: SEND_RESPONSE, Response: SEND_BODY},
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
    },
}
_NO_EVENTS = {}


def _opposite(role):
    return SERVER if role is CLIENT else CLIENT


class _StateMap(dict):
    """Keyed by CLIENT/SERVER, and also indexable as (client, server)."""

    def __getitem__(self, key):
        if type(key) is int:
            key = (CLIENT, SERVER)[key]
        return dict.__getitem__(self, key)


class _Body(object):
    """Framing of one message body, in one direction."""

    __slots__ = ("kind", "remaining", "phase", "first")

    def __init__(self, kind, remaining=0):
        # kind: "empty", "length", "chunked", or "close"
        self.kind = kind
        self.remaining = remaining
        self.phase = "size"  # chunked reader: size, data, crlf, trailer
        self.first = False   # chunked reader: next data piece starts a chunk


def _request_body(items):
    # spec: N-000185, N-000186, N-000187, N-000188 — Content-Length decides when both are present
    cl = content_length(items)
    if cl is not None:
        return _Body("length", cl)
    if has_header(items, b"transfer-encoding"):
        return _Body("chunked")
    return _Body("length", 0)


def _drop(items, names):
    return [item for item in items if item[1] not in names]


def _rewrite_connection_close(items):
    """Replace Connection with a value that lacks keep-alive and has close."""
    # spec: N-000265, N-000266, N-000267, N-000268 — keep-alive off means Connection: close
    result = []
    tokens = []
    index = None
    for item in items:
        if item[1] == b"connection":
            if index is None:
                index = len(result)
                result.append(None)
            for token in item[2].split(b","):
                token = token.strip(b" \t")
                lowered = token.lower()
                if token and lowered != b"keep-alive" and lowered not in [t.lower() for t in tokens]:
                    tokens.append(token)
            continue
        result.append(item)
    if b"close" not in [t.lower() for t in tokens]:
        tokens.append(b"close")
    new_item = (b"Connection", b"connection", b", ".join(tokens))
    if index is None:
        result.append(new_item)
    else:
        result[index] = new_item
    return result


# spec: N-000010, N-000011, N-000012, N-000013, N-000014, N-000015, N-000016, N-000017, N-000018, N-000019, N-000020, N-000021 — PRD terminology realized by the methods and attributes below
# spec: N-000055, N-000056, N-000057, N-000058 — scope is RFC 7230 plus Expect: 100-continue; protocol error text is free

class Connection(object):
    """One HTTP/1.1 connection, in the CLIENT or SERVER role.

    No I/O: ``send`` encodes events to bytes; ``receive_data`` stores bytes;
    ``next_event`` parses one event out of the stored bytes.
    """

    def __init__(self, our_role, max_incomplete_event_size=DEFAULT_MAX_INCOMPLETE_EVENT_SIZE):
        # spec: N-000476, N-000477 — role must be CLIENT or SERVER
        if our_role is not CLIENT and our_role is not SERVER:
            raise LocalProtocolError("role must be CLIENT or SERVER")
        # spec: N-000478 — optional int limit in bytes
        if isinstance(max_incomplete_event_size, bool) or not isinstance(max_incomplete_event_size, int):
            raise LocalProtocolError("max_incomplete_event_size must be an int")
        self.our_role = our_role
        self.their_role = _opposite(our_role)
        self._max_incomplete = int(max_incomplete_event_size)
        self._buf = bytearray()
        self._closed = False
        # spec: N-000123, N-000124, N-000125 — both sides start in IDLE
        self._states = {CLIENT: IDLE, SERVER: IDLE}
        self._versions = {CLIENT: None, SERVER: None}
        self._conn_close = {CLIENT: False, SERVER: False}
        self._proposals = set()        # "connect" and/or "upgrade", unanswered
        self._switch_accepted = False
        self._request_method = None
        self._client_waiting = False
        self._close_delimited = False
        self._send_body = None
        self._recv_body = None

    # ----- queryable attributes -------------------------------------------

    @property
    def our_state(self):
        return self._states[self.our_role]

    @property
    def their_state(self):
        return self._states[self.their_role]

    @property
    def states(self):
        # spec: N-000483, N-000484 — both states, mapping or pair
        return _StateMap(self._states)

    @property
    def their_http_version(self):
        # spec: N-000481, N-000482, N-000170 — recorded only from pulled events
        return self._versions[self.their_role]

    @property
    def client_is_waiting_for_100_continue(self):
        return bool(self._client_waiting)

    @property
    def they_are_waiting_for_100_continue(self):
        # spec: N-000355, N-000356, N-000357 — only a server-role connection reports this
        return bool(self._client_waiting and self.our_role is SERVER)

    @property
    def trailing_data(self):
        # spec: N-000494, N-000495, N-000496 — (leftover bytes, receive side closed)
        return (bytes(self._buf), self._closed)

    # ----- sending --------------------------------------------------------

    def send(self, event):
        """Encode ``event``; returns bytes, or None when it produces none."""
        pieces = self._send(event, passthrough=False)
        if not pieces:
            return None
        return b"".join(pieces)

    def send_with_data_passthrough(self, event):
        """Like ``send`` but returns a list of pieces (see FP-03)."""
        # spec: N-000502, N-000503, N-000504, N-000505, N-000506
        return self._send(event, passthrough=True)

    def _send(self, event, passthrough):
        sender = self.our_role
        try:
            if not isinstance(event, EVENT_TYPES):
                raise LocalProtocolError("send() takes an event instance")
            if self._next_state(sender, event) is None:
                raise LocalProtocolError(
                    "%s is not allowed while our state is %r"
                    % (type(event).__name__, self._states[sender])
                )
            pieces, body, close_mode = self._frame_send(event, passthrough)
        except LocalProtocolError:
            # spec: N-000307, N-000308, N-000309, N-000310 — a refused send makes our side ERROR
            self._states[sender] = ERROR
            self._fire_state_triggered()
            raise
        self._apply(sender, event)
        if body is not _KEEP:
            self._send_body = body
        if close_mode:
            self._close_delimited = True
        return pieces

    def _frame_send(self, event, passthrough):
        if isinstance(event, Request):
            return self._frame_request(event)
        if isinstance(event, InformationalResponse):
            return self._frame_informational(event)
        if isinstance(event, Response):
            return self._frame_response(event)
        if isinstance(event, Data):
            return self._frame_data(event, passthrough)
        if isinstance(event, EndOfMessage):
            return self._frame_eom(event)
        # spec: N-000333 — ConnectionClosed produces no bytes
        return [], _KEEP, False

    def _frame_request(self, event):
        # spec: N-000128, N-000132 — request line with HTTP/1.1
        if event.http_version != b"1.1":
            raise LocalProtocolError("only HTTP/1.1 requests can be sent")
        items = list(event.headers._items)
        body = _request_body(items)
        drop = (b"transfer-encoding",) if (body.kind == "length" and content_length(items) is not None) else ()
        # spec: N-000161 — Host is written before every other header
        ordered = [i for i in items if i[1] == b"host"] + [i for i in items if i[1] != b"host"]
        lines = [b"%s %s HTTP/1.1\r\n" % (event.method, event.target)]
        for raw, lower, value in ordered:
            if lower in drop:
                continue
            # spec: N-000163, N-000164 — original name casing is written
            lines.append(raw + b": " + value + b"\r\n")
        lines.append(b"\r\n")
        return [b"".join(lines)], body, False

    def _frame_informational(self, event):
        # spec: N-000136, N-000137 — status line then headers then blank line
        if event.http_version != b"1.1":
            raise LocalProtocolError("only HTTP/1.1 responses can be sent")
        lines = [b"HTTP/1.1 %d %s\r\n" % (event.status_code, event.reason)]
        for raw, _lower, value in event.headers._items:
            lines.append(raw + b": " + value + b"\r\n")
        lines.append(b"\r\n")
        # spec: N-000139 — an informational response has no body
        return [b"".join(lines)], _Body("empty"), False

    def _frame_response(self, event):
        if event.http_version != b"1.1":
            raise LocalProtocolError("only HTTP/1.1 responses can be sent")
        items = list(event.headers._items)
        status = event.status_code
        method = self._request_method
        peer_11 = self._versions[CLIENT] == b"1.1"
        verdict = self._switch_verdict(event)
        close_mode = False
        if verdict == "accept":
            # spec: N-000381, N-000382 — accepting response: no body, no framing
            items = _drop(items, _FRAMING_NAMES)
            body = _Body("empty")
        elif status in (204, 304):
            # spec: N-000215, N-000216, N-000217, N-000218 — these always have an empty body
            items = _drop(items, _FRAMING_NAMES)
            body = _Body("empty")
        else:
            cl = content_length(items)
            if has_header(items, b"transfer-encoding"):
                # spec: N-000207 — transfer-encoding wins for responses
                if peer_11:
                    items = _drop(items, (b"content-length",))
                    body = _Body("chunked")
                else:
                    items = _drop(items, _FRAMING_NAMES)
                    body = _Body("close")
                    close_mode = True
            elif cl is not None:
                # spec: N-000198, N-000199 — Content-Length kept, even when 0
                body = _Body("length", cl)
            elif peer_11:
                # spec: N-000202 — chunked toward an HTTP/1.1 peer
                items.append((b"Transfer-Encoding", b"transfer-encoding", b"chunked"))
                body = _Body("chunked")
            else:
                # spec: N-000203, N-000204, N-000205, N-000206 — no framing, close-delimited
                body = _Body("close")
                close_mode = True
            if method == b"HEAD":
                # spec: N-000219 — HEAD gets the GET framing headers, no body
                # spec: N-000215 — no data for HEAD
                body = _Body("empty")
        if verdict != "accept":
            disabled = (
                close_mode
                or not peer_11
                or self._conn_close[CLIENT]
                or has_token(items, b"connection", b"close")
            )
            # spec: N-000265, N-000266, N-000267, N-000268, N-000269 — keep-alive off means Connection: close
            if disabled:
                items = _rewrite_connection_close(items)
        lines = [b"HTTP/1.1 %d %s\r\n" % (status, event.reason)]
        for raw, _lower, value in items:
            lines.append(raw + b": " + value + b"\r\n")
        lines.append(b"\r\n")
        return [b"".join(lines)], body, close_mode

    def _frame_data(self, event, passthrough):
        body = self._send_body
        data = event.data
        if isinstance(data, str):
            raise LocalProtocolError("Data payload must be bytes-like")
        try:
            view = memoryview(data)
        except TypeError:
            view = None
        if view is not None:
            n = view.nbytes
            piece = bytes(view)
        else:
            if not passthrough:
                raise LocalProtocolError("Data payload must be bytes-like to use send()")
            try:
                n = len(data)
            except TypeError:
                raise LocalProtocolError("Data payload needs a length to pass through")
            piece = data
        # spec: N-000238 — exceeding the declared Content-Length is refused
        if body.kind in ("empty", "length"):
            if n > body.remaining:
                raise LocalProtocolError("Data exceeds the remaining Content-Length")
            body.remaining -= n
            pieces = [piece] if n else []
        elif body.kind == "close":
            pieces = [piece] if n else []
        else:
            # spec: N-000192, N-000193, N-000194, N-000195, N-000196, N-000197 — one chunk per non-empty data event
            if n == 0:
                pieces = []
            else:
                pieces = [b"%x\r\n" % n, piece, b"\r\n"]
        # spec: N-000233, N-000234, N-000235, N-000236, N-000237 — payload object passes through unchanged
        return pieces, _KEEP, False

    def _frame_eom(self, event):
        body = self._send_body
        if body.kind == "chunked":
            # spec: N-000195, N-000197 — zero-size chunk, trailers, blank line
            lines = [b"0\r\n"]
            for raw, _lower, value in event.headers._items:
                lines.append(raw + b": " + value + b"\r\n")
            lines.append(b"\r\n")
            return [b"".join(lines)], None, False
        # spec: N-000239, N-000240, N-000241 — trailers only with chunked framing
        if len(event.headers):
            raise LocalProtocolError("trailing headers need chunked framing")
        if body.kind in ("empty", "length") and body.remaining != 0:
            # spec: N-000239 — end-of-message before the full Content-Length
            raise LocalProtocolError("end-of-message before Content-Length was sent")
        return [], None, False

    # ----- receiving ------------------------------------------------------

    def receive_data(self, data):
        """Store bytes from the peer; empty bytes mean the peer closed."""
        # spec: N-000507, N-000508, N-000509, N-000510, N-000511 — never raises for illegal peer bytes
        view = memoryview(data)
        if view.nbytes == 0:
            self._closed = True
            return None
        if self._closed:
            # spec: N-000180, N-000181, N-000182 — a runtime error, not a protocol error
            raise RuntimeError("received close, then received more data?")
        self._buf += bytes(view)
        return None

    def next_event(self):
        """Return one event, NEED_DATA, or PAUSED."""
        try:
            return self._next_event()
        except RemoteProtocolError:
            # spec: N-000302, N-000303, N-000304, N-000305, N-000306 — a remote error puts their side in ERROR
            self._states[self.their_role] = ERROR
            self._fire_state_triggered()
            raise

    def _next_event(self):
        st = self._states[self.their_role]
        # spec: N-000303, N-000304, N-000305, N-000306 — every further pull also fails
        if st is ERROR:
            raise RemoteProtocolError("an earlier message from the peer was invalid", 400)
        # spec: N-000288, N-000289, N-000381, N-000382, N-000383, N-000384, N-000385, N-000386, N-000387 — pause, not need-data
        if self._switch_accepted or st is MIGHT_SWITCH_PROTOCOL or st is SWITCHED_PROTOCOL:
            return PAUSED
        if st is CLOSED:
            return ConnectionClosed()
        if st is DONE or st is MUST_CLOSE:
            if self._buf:
                return PAUSED
            if self._closed:
                # spec: N-000339, N-000340, N-000341 — pulled close
                return self._emit(ConnectionClosed())
            return NEED_DATA
        if st is SEND_BODY:
            return self._read_body()
        return self._read_head()

    def _read_head(self):
        st = self._states[self.their_role]
        buf = self._buf
        if not buf:
            if self._closed:
                if st is IDLE:
                    return self._emit(ConnectionClosed())
                raise RemoteProtocolError("connection closed while a message was expected")
            return NEED_DATA
        # spec: N-000177, N-000178, N-000179 — a space or control byte fails at once
        if buf[0] < 33:
            raise RemoteProtocolError("message line starts with a space or control byte")
        split = split_head(buf)
        if split is None:
            # spec: N-000316, N-000317, N-000318, N-000319, N-000320, N-000321, N-000322, N-000323 — incomplete-event size limit
            if len(buf) > self._max_incomplete:
                raise RemoteProtocolError("incomplete event exceeds the size limit", 431)
            if self._closed:
                # spec: N-000324 — close in the middle of a header block
                raise RemoteProtocolError("connection closed in the middle of a header block")
            return NEED_DATA
        lines, consumed = split
        del buf[:consumed]
        return self._emit(self._parse_head(lines))

    def _parse_head(self, lines):
        try:
            if self.their_role is CLIENT:
                method, target, version = parse_request_line(lines[0])
                fields = parse_fields(lines[1:])
                return Request(method, target, fields, version)
            version, status, reason = parse_status_line(lines[0])
            fields = parse_fields(lines[1:])
            cls = InformationalResponse if status < 200 else Response
            return cls(status, fields, version, reason)
        except LocalProtocolError as exc:
            raise RemoteProtocolError(str(exc), exc.error_status_hint)

    def _read_body(self):
        rb = self._recv_body
        buf = self._buf
        if rb is None:
            return NEED_DATA
        if rb.kind == "empty" or (rb.kind == "length" and rb.remaining == 0):
            self._recv_body = None
            return self._emit(EndOfMessage())
        if rb.kind == "length":
            if not buf:
                if self._closed:
                    raise RemoteProtocolError("connection closed in the middle of a Content-Length body")
                return NEED_DATA
            n = min(rb.remaining, len(buf))
            data = bytes(buf[:n])
            del buf[:n]
            rb.remaining -= n
            return self._emit(Data(data))
        if rb.kind == "close":
            # spec: N-000208, N-000209, N-000210, N-000211, N-000212, N-000213, N-000214 — close-delimited body ends at the close
            if buf:
                data = bytes(buf)
                del buf[:]
                return self._emit(Data(data))
            if self._closed:
                self._recv_body = None
                return self._emit(EndOfMessage())
            return NEED_DATA
        return self._read_chunked(rb)

    def _read_chunked(self, rb):
        buf = self._buf
        while True:
            if rb.phase == "size":
                nl = buf.find(b"\n")
                if nl < 0:
                    if self._closed:
                        raise RemoteProtocolError("connection closed in the middle of a chunk-size line")
                    return NEED_DATA
                line = bytes(buf[:nl])
                if line.endswith(b"\r"):
                    line = line[:-1]
                size = parse_chunk_size(line)
                del buf[:nl + 1]
                if size == 0:
                    rb.phase = "trailer"
                else:
                    rb.phase = "data"
                    rb.remaining = size
                    rb.first = True
                continue
            if rb.phase == "data":
                if not buf:
                    if self._closed:
                        raise RemoteProtocolError("connection closed in the middle of a chunk")
                    return NEED_DATA
                n = min(rb.remaining, len(buf))
                data = bytes(buf[:n])
                del buf[:n]
                start = rb.first
                rb.first = False
                rb.remaining -= n
                end = rb.remaining == 0
                if end:
                    rb.phase = "crlf"
                # spec: N-000220, N-000221, N-000222, N-000223, N-000224, N-000225, N-000226, N-000227 — chunk marks on data events
                return self._emit(Data(data, chunk_start=start, chunk_end=end))
            if rb.phase == "crlf":
                if not buf:
                    if self._closed:
                        raise RemoteProtocolError("connection closed in the middle of a chunk")
                    return NEED_DATA
                # spec: N-000244 — chunk data must be followed by exactly CRLF
                if buf[0] != 13:
                    raise RemoteProtocolError("chunk data not followed by CRLF")
                if len(buf) < 2:
                    if self._closed:
                        raise RemoteProtocolError("connection closed in the middle of a chunk")
                    return NEED_DATA
                if buf[1] != 10:
                    raise RemoteProtocolError("chunk data not followed by CRLF")
                del buf[:2]
                rb.phase = "size"
                continue
            # trailer section after the zero-size chunk
            split = split_head(buf)
            if split is None:
                if len(buf) > self._max_incomplete:
                    raise RemoteProtocolError("incomplete event exceeds the size limit", 431)
                if self._closed:
                    raise RemoteProtocolError("connection closed in the middle of trailers")
                return NEED_DATA
            lines, consumed = split
            del buf[:consumed]
            self._recv_body = None
            try:
                trailers = EndOfMessage(parse_fields(lines))
            except LocalProtocolError as exc:
                raise RemoteProtocolError(str(exc), exc.error_status_hint)
            return self._emit(trailers)

    def _emit(self, event):
        self._pulled(event)
        return event

    def _pulled(self, event):
        their = self.their_role
        if self._next_state(their, event) is None:
            raise RemoteProtocolError(
                "%s is not allowed from the peer in its current state" % type(event).__name__
            )
        if isinstance(event, Request):
            self._recv_body = _request_body(list(event.headers._items))
        elif isinstance(event, Response) and self._switch_verdict(event) != "accept":
            self._recv_body = self._response_body_for_receive(event)
        self._apply(their, event)

    def _response_body_for_receive(self, event):
        items = list(event.headers._items)
        # spec: N-000215, N-000216, N-000217, N-000218 — HEAD, 204, 304 have empty bodies
        if self._request_method == b"HEAD" or event.status_code in (204, 304):
            return _Body("empty")
        cl = content_length(items)
        if cl is not None:
            return _Body("length", cl)
        if has_header(items, b"transfer-encoding"):
            return _Body("chunked")
        # spec: N-000208, N-000209, N-000210, N-000211, N-000212, N-000213, N-000214 — close-delimited response
        self._close_delimited = True
        return _Body("close")

    # ----- state machine --------------------------------------------------

    def _next_state(self, sender, event):
        """Return the state ``sender`` would move to, or None if illegal."""
        cur = self._states[sender]
        nxt = _TABLES[sender].get(cur, _NO_EVENTS).get(type(event))
        if nxt is None:
            return None
        if sender is CLIENT and isinstance(event, EndOfMessage):
            # spec: N-000373, N-000374, N-000375, N-000376, N-000377, N-000378, N-000379, N-000380 — switch states appear after the EOM
            if self._switch_accepted:
                return SWITCHED_PROTOCOL
            if self._proposals:
                return MIGHT_SWITCH_PROTOCOL
            return nxt
        if sender is SERVER and isinstance(event, (InformationalResponse, Response)):
            if self._switch_verdict(event) == "accept":
                return SWITCHED_PROTOCOL
        return nxt

    def _switch_verdict(self, event):
        """Classify a server response against unanswered switch proposals."""
        if not self._proposals:
            return None
        # spec: N-000366, N-000367, N-000368 — 101 accepts Upgrade; other 1xx neither
        if isinstance(event, InformationalResponse):
            if event.status_code == 101 and "upgrade" in self._proposals:
                return "accept"
            return None
        # spec: N-000364, N-000365, N-000394, N-000395 — only 200 accepts CONNECT
        if isinstance(event, Response):
            if event.status_code == 200 and "connect" in self._proposals:
                return "accept"
            return "deny"
        return None

    def _apply(self, sender, event):
        """Commit an event that has already been checked as legal."""
        nxt = self._next_state(sender, event)
        verdict = None
        if sender is SERVER and isinstance(event, (InformationalResponse, Response)):
            verdict = self._switch_verdict(event)
        self._states[sender] = nxt

        if isinstance(event, Request):
            self._on_request(event)
        elif isinstance(event, (InformationalResponse, Response)):
            self._versions[sender] = event.http_version
            # spec: N-000358 — the server answering ends the wait
            self._client_waiting = False
            if isinstance(event, Response):
                self._conn_close[sender] = has_token(list(event.headers._items), b"connection", b"close")

        # spec: N-000359 — the client sending data or end-of-message ends it
        if sender is CLIENT and isinstance(event, (Data, EndOfMessage)):
            self._client_waiting = False

        if verdict == "accept":
            self._switch_accepted = True
            self._proposals = set()
            if self._states[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                self._states[CLIENT] = SWITCHED_PROTOCOL
        elif verdict == "deny":
            # spec: N-000378, N-000379, N-000380 — denial follows the ordinary rules
            self._proposals = set()
            if self._states[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                self._states[CLIENT] = DONE
        self._fire_state_triggered()

    def _on_request(self, event):
        items = list(event.headers._items)
        # spec: N-000247, N-000248, N-000249, N-000250, N-000251, N-000252, N-000253, N-000254 — server goes IDLE -> SEND_RESPONSE
        if self._states[SERVER] is IDLE:
            self._states[SERVER] = SEND_RESPONSE
        self._request_method = event.method
        self._versions[CLIENT] = event.http_version
        self._conn_close[CLIENT] = has_token(items, b"connection", b"close")
        self._proposals = set()
        if event.method == b"CONNECT":
            self._proposals.add("connect")
        if has_header(items, b"upgrade"):
            self._proposals.add("upgrade")
        self._switch_accepted = False
        # spec: N-000354, N-000355, N-000356, N-000357 — Expect: 100-continue on HTTP/1.1 only
        if event.http_version == b"1.1" and has_token(items, b"expect", b"100-continue"):
            self._client_waiting = True

    # spec: N-000062 — no HTTP/1.0 Connection: keep-alive pseudo-standard: 1.0 never keeps alive
    def _keep_alive(self):
        # spec: N-000259, N-000260, N-000261, N-000262, N-000263, N-000264 — keep-alive needs 1.1 both ways and no close
        if any(self._conn_close.values()):
            return False
        if self._close_delimited:
            return False
        for version in self._versions.values():
            if version is not None and version != b"1.1":
                return False
        return True

    def _fire_state_triggered(self):
        # spec: N-000311, N-000312, N-000313, N-000314, N-000315 (ERROR vs DONE), N-000336, N-000337, N-000338 (CLOSED),
        # N-000264, N-000286 (keep-alive disabled turns DONE into MUST_CLOSE)
        while True:
            changed = False
            for role in (CLIENT, SERVER):
                other = _opposite(role)
                mine = self._states[role]
                theirs = self._states[other]
                if mine is CLOSED and (theirs is IDLE or theirs is DONE):
                    self._states[other] = MUST_CLOSE
                    changed = True
                elif mine is ERROR and theirs is DONE:
                    self._states[other] = MUST_CLOSE
                    changed = True
            if not self._keep_alive():
                for role in (CLIENT, SERVER):
                    if self._states[role] is DONE:
                        self._states[role] = MUST_CLOSE
                        changed = True
            if not changed:
                break

    # ----- cycle control and failure marks --------------------------------

    def start_next_cycle(self):
        # spec: N-000270, N-000271, N-000280, N-000281, N-000282 — refused unless both DONE
        if self._states[CLIENT] is not DONE or self._states[SERVER] is not DONE:
            raise LocalProtocolError("the next cycle can start only when both sides are DONE")
        self._states = {CLIENT: IDLE, SERVER: IDLE}
        self._conn_close = {CLIENT: False, SERVER: False}
        self._proposals = set()
        self._switch_accepted = False
        self._request_method = None
        self._client_waiting = False
        self._close_delimited = False
        self._send_body = None
        self._recv_body = None
        return None

    def send_failed(self):
        # spec: N-000312, N-000313, N-000314, N-000315 — mark the last send as failed
        self._states[self.our_role] = ERROR
        self._fire_state_triggered()
        return None
