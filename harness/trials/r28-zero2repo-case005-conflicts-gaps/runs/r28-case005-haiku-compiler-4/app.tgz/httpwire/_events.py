"""The six HTTP event types."""

# spec index: N-000070, N-000071 (six distinct kinds), N-000073, N-000074, N-000075 (method, target,
#   version as bytes), N-000080, N-000081, N-000082 (status ranges, default 1.1, empty reason),
#   N-000086 (ConnectionClosed has no fields), N-000088, N-000089 (lowercase names, bytes values),
#   N-000098, N-000099 (value rule), N-000101, N-000102, N-000103 (refused construction yields no
#   event and changes nothing), N-000107 (name and value rules for every kind), N-000297, N-000298,
#   N-000299 (invalid construction is recoverable), N-000434, N-000435, N-000436 (event classes),
#   N-000450, N-000451 (keyword construction, readable fields), N-000452, N-000453, N-000454, N-000455, N-000456, N-000457 (field table),
#   N-000463, N-000464, N-000465 (Data chunk marks), N-000466 (invalid construction raises)

import re

from ._errors import LocalProtocolError
from ._headers import Headers, to_bytes, is_token

_TARGET_RE = re.compile(rb"[\x21-\x7e]+")
_VERSION_RE = re.compile(rb"[0-9]\.[0-9]")
_REASON_BAD_RE = re.compile(rb"[\x00-\x08\x0a-\x1f\x7f]")


def _version(value):
    v = to_bytes(value, "HTTP version")
    # spec: N-000072, N-000073, N-000074, N-000075, N-000076 — two digits separated by a dot
    if not _VERSION_RE.fullmatch(v):
        raise LocalProtocolError("HTTP version must look like 1.1")
    return v


def _status(value, low, high):
    # spec: N-000112, N-000113 — status range by event kind; non-int refused
    if not isinstance(value, int):
        raise LocalProtocolError("status code must be an integer")
    status = int(value)
    if not low <= status < high:
        raise LocalProtocolError("status code %d out of range" % status)
    return status


def _reason(value):
    # spec: N-000079, N-000080, N-000081, N-000082, N-000083 — reason defaults to empty; stored as bytes
    reason = to_bytes(value, "reason")
    if _REASON_BAD_RE.search(reason):
        raise LocalProtocolError("reason phrase contains a forbidden byte")
    return reason


class _Event(object):
    _fields = ()

    def _key(self):
        return tuple(getattr(self, name) for name in self._fields)

    def __eq__(self, other):
        if type(other) is not type(self):
            return False
        return self._key() == other._key()

    def __ne__(self, other):
        return not self.__eq__(other)

    __hash__ = None

    def __repr__(self):
        parts = ", ".join("%s=%r" % (name, getattr(self, name)) for name in self._fields)
        return "%s(%s)" % (type(self).__name__, parts)


class Request(_Event):
    """Start of an HTTP request."""

    _fields = ("method", "target", "headers", "http_version")

    def __init__(self, method, target, headers, http_version=b"1.1"):
        # spec: N-000110, N-000111 — target and method rules
        method = to_bytes(method, "method")
        if not is_token(method):
            raise LocalProtocolError("method must be a single RFC 7230 token")
        target = to_bytes(target, "request target")
        if not _TARGET_RE.fullmatch(target):
            raise LocalProtocolError("request target must be visible ASCII")
        version = _version(http_version)
        hdrs = Headers(headers)
        hosts = sum(1 for name, _value in hdrs if name == b"host")
        # spec: N-000105 — more than one Host is refused in any version
        if hosts > 1:
            raise LocalProtocolError("more than one Host header")
        # spec: N-000104 — HTTP/1.1 requires exactly one Host header
        if version == b"1.1" and hosts == 0:
            raise LocalProtocolError("HTTP/1.1 request requires a Host header")
        self.method = method
        self.target = target
        self.headers = hdrs
        self.http_version = version


class InformationalResponse(_Event):
    """An HTTP 1xx response (status 100 <= code < 200)."""

    _fields = ("status_code", "headers", "http_version", "reason")

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        self.status_code = _status(status_code, 100, 200)
        self.headers = Headers(headers)
        self.http_version = _version(http_version)
        self.reason = _reason(reason)


class Response(_Event):
    """Start of a final HTTP response (status 200 <= code < 1000)."""

    _fields = ("status_code", "headers", "http_version", "reason")

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        self.status_code = _status(status_code, 200, 1000)
        self.headers = Headers(headers)
        self.http_version = _version(http_version)
        self.reason = _reason(reason)


class Data(_Event):
    """A piece of a message body."""

    _fields = ("data", "chunk_start", "chunk_end")

    def __init__(self, data, chunk_start=False, chunk_end=False):
        # data is stored as given; send checks it when encoding
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)


class EndOfMessage(_Event):
    """End of a request or response, with optional trailing headers."""

    _fields = ("headers",)

    def __init__(self, headers=()):
        self.headers = Headers(headers)


class ConnectionClosed(_Event):
    """This side will send no more HTTP data."""

    _fields = ()

    def __init__(self):
        pass


EVENT_TYPES = (Request, InformationalResponse, Response, Data, EndOfMessage, ConnectionClosed)
