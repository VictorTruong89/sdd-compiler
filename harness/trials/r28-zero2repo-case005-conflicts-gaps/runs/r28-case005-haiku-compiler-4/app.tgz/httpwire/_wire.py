"""Parsing helpers for bytes received from the peer."""

import re

from ._errors import RemoteProtocolError

_STATUS_RE = re.compile(rb"[0-9]{3}")
# chunk-size line: hex digits, then optionally a chunk extension (";...")
_CHUNK_SIZE_RE = re.compile(rb"([0-9A-Fa-f]+)(?:;[^\r\n]*)?")

# spec: N-000228 — chunk-size digit limit chosen from 16..32 (see NOTES.md)
MAX_CHUNK_SIZE_DIGITS = 32


def split_head(buf):
    """Split a header block off the front of ``buf``.

    Lines end in LF or CRLF (a lone LF is accepted).  Returns
    ``(lines, consumed)`` once the blank line is present, else ``None``.
    """
    # spec: N-000165 — lone line feed accepted as a line ending
    lines = []
    pos = 0
    while True:
        nl = buf.find(b"\n", pos)
        if nl < 0:
            return None
        line = bytes(buf[pos:nl])
        if line.endswith(b"\r"):
            line = line[:-1]
        pos = nl + 1
        if not line:
            return lines, pos
        lines.append(line)


def parse_fields(lines):
    """Parse ``name: value`` lines into (name, value) byte pairs.

    spec: N-000167, N-000168, N-000169 — obsolete line folding is joined to the previous
    value with its leading whitespace replaced by one space (see NOTES.md).
    """
    fields = []
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            if not fields:
                raise RemoteProtocolError("header continuation with no header before it")
            name, value = fields[-1]
            fields[-1] = (name, value + b" " + line.strip(b" \t"))
            continue
        colon = line.find(b":")
        if colon <= 0:
            raise RemoteProtocolError("malformed header line")
        name = line[:colon]
        value = line[colon + 1:].strip(b" \t")
        fields.append((name, value))
    return fields


# spec: N-000050, N-000051 (own parser, no http.client), N-000052, N-000053, N-000054 (speaks only HTTP/1.1)
def parse_http_version(token):
    if token[:5] != b"HTTP/":
        raise RemoteProtocolError("malformed HTTP version")
    version = token[5:]
    # spec: N-000156 — HTTP/1.0 is understood when reading, 1.1 is spoken
    if version not in (b"1.0", b"1.1"):
        raise RemoteProtocolError("unsupported HTTP version")
    return version


def parse_request_line(line):
    # spec: N-000172, N-000173 / N-000174 — malformed request lines are refused
    parts = line.split(b" ")
    if len(parts) != 3:
        raise RemoteProtocolError("malformed request line")
    method, target, version = parts
    return method, target, parse_http_version(version)


def parse_status_line(line):
    parts = line.split(b" ", 2)
    if len(parts) < 2:
        raise RemoteProtocolError("malformed status line")
    version = parse_http_version(parts[0])
    code = parts[1]
    if not _STATUS_RE.fullmatch(code):
        raise RemoteProtocolError("status code must be three digits")
    status = int(code)
    if status < 100:
        raise RemoteProtocolError("status code below 100")
    # spec: N-000166 — a status line without a reason phrase is accepted
    reason = parts[2] if len(parts) == 3 else b""
    return version, status, reason


# spec: N-000066, N-000067 (chunk extensions are parsed and discarded)
def parse_chunk_size(line):
    """Return the chunk size of a chunk-size line (CRLF already stripped)."""
    # spec: N-000228, N-000229, N-000230, N-000231, N-000232, N-000242, N-000243, N-000244, N-000245
    m = _CHUNK_SIZE_RE.fullmatch(line)
    if m is None or len(m.group(1)) > MAX_CHUNK_SIZE_DIGITS:
        raise RemoteProtocolError("malformed chunk-size line")
    return int(m.group(1), 16)
