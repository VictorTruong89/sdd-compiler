"""httpwire: a pure-Python HTTP/1.1 wire protocol library (no I/O).

Every published entry is importable from this package root.  The library
performs no network I/O: bytes in and bytes out are the entire interface.
"""

# spec: N-000001, N-000002, N-000004, N-000005, N-000006, N-000007, N-000008, N-000009 — overview: no I/O, protocol violations are protocol errors
# spec: N-000429, N-000430, N-000431, N-000432 — an importable library, not a CLI or service.
# spec: N-000022, N-000023, N-000024, N-000025, N-000026, N-000027, N-000028, N-000029, N-000030, N-000031, N-000032, N-000033, N-000034, N-000035, N-000036 — public surface inventory: six events, connection, framing, state machine, protocol errors, shutdown, informational responses
# spec: N-000059, N-000060, N-000061, N-000068, N-000069 — non-goals: no network I/O, no HTTP client or server, no HTTP/2 or HTTP/3, no URL routing, no CLI or benchmark
# spec: N-000433 — the public surface is the top-level package ``httpwire``.

from ._sentinels import (
    CLIENT,
    SERVER,
    NEED_DATA,
    PAUSED,
    IDLE,
    SEND_RESPONSE,
    SEND_BODY,
    DONE,
    MUST_CLOSE,
    CLOSED,
    MIGHT_SWITCH_PROTOCOL,
    SWITCHED_PROTOCOL,
    ERROR,
)
from ._events import (
    Request,
    InformationalResponse,
    Response,
    Data,
    EndOfMessage,
    ConnectionClosed,
)
from ._errors import LocalProtocolError, RemoteProtocolError
from ._connection import Connection

__version__ = "0.1.0"

# spec: N-000449 — other names the package defines are not part of the surface
__all__ = [
    "CLIENT",
    "CLOSED",
    "Connection",
    "ConnectionClosed",
    "Data",
    "DONE",
    "EndOfMessage",
    "ERROR",
    "IDLE",
    "InformationalResponse",
    "LocalProtocolError",
    "MIGHT_SWITCH_PROTOCOL",
    "MUST_CLOSE",
    "NEED_DATA",
    "PAUSED",
    "RemoteProtocolError",
    "Request",
    "Response",
    "SEND_BODY",
    "SEND_RESPONSE",
    "SERVER",
    "SWITCHED_PROTOCOL",
]
