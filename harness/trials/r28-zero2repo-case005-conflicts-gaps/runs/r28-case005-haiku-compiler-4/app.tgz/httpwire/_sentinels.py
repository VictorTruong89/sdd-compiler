"""Singleton role, state, and non-event result objects.

Every object here is distinct and compares equal only to itself.
"""


class _Sentinel(object):
    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return self._name


# spec: N-000438, N-000439 (CLIENT and SERVER are distinct objects)
CLIENT = _Sentinel("CLIENT")
SERVER = _Sentinel("SERVER")

# spec: N-000440, N-000441, N-000442 (NEED_DATA and PAUSED are distinct
# from each other and from every event type)
NEED_DATA = _Sentinel("NEED_DATA")
PAUSED = _Sentinel("PAUSED")

# spec: N-000443, N-000444, N-000445 (the nine state values, all distinct)
IDLE = _Sentinel("IDLE")
SEND_RESPONSE = _Sentinel("SEND_RESPONSE")
SEND_BODY = _Sentinel("SEND_BODY")
DONE = _Sentinel("DONE")
MUST_CLOSE = _Sentinel("MUST_CLOSE")
CLOSED = _Sentinel("CLOSED")
MIGHT_SWITCH_PROTOCOL = _Sentinel("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = _Sentinel("SWITCHED_PROTOCOL")
ERROR = _Sentinel("ERROR")
