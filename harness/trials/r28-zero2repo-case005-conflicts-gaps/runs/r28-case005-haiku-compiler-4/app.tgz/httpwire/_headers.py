"""Header list: validation, lowercase view, raw view, framing normalization."""

# spec index: N-000246 (other transfer codings refused at construction), N-000294 and N-000295
#   (Transfer-Encoding refusals suggest 501), N-000461 and N-000462 (Content-Length digit limit,
#   see NOTES.md), N-000467 (header list is a sequence), N-000468 (ordinary lowercase view),
#   N-000469, N-000470, N-000471 (raw_items keeps caller spelling and order)

import re

from ._errors import LocalProtocolError

# RFC 7230 token
_TOKEN_RE = re.compile(rb"[!#$%&'*+\-.^_`|~0-9A-Za-z]+")
_DIGITS_RE = re.compile(rb"[0-9]+")
# Control bytes other than tab are refused in values (NUL, CR, LF, FF, VT,
# and the other C0 controls, plus DEL).
_BAD_VALUE_RE = re.compile(rb"[\x00-\x08\x0a-\x1f\x7f]")

# spec: N-000114, N-000115, N-000116, N-000117, N-000118, N-000119 — maximum Content-Length digit count, chosen from
# the 18..32 range the PRD allows (see NOTES.md).
MAX_CONTENT_LENGTH_DIGITS = 18


def to_bytes(value, what):
    """Accept ASCII str or any bytes-like object; return exact ``bytes``."""
    # spec: N-000458, N-000459 (byte arguments accept ASCII str or bytes-like,
    # stored as exact bytes)
    if isinstance(value, str):
        try:
            return value.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("%s must be ASCII" % what)
    if isinstance(value, (bytes, bytearray, memoryview)):
        return bytes(value)
    raise LocalProtocolError("%s must be str or bytes-like" % what)


def is_token(value):
    return _TOKEN_RE.fullmatch(value) is not None


def check_value(value):
    # spec: N-000097, N-000098, N-000099, N-000100 — value rule; spec: N-000108 — control bytes
    # other than tab refused; space/tab only between other bytes.
    if _BAD_VALUE_RE.search(value):
        raise LocalProtocolError("header value contains a forbidden byte")
    if value and value[0] in (0x20, 0x09):
        raise LocalProtocolError("header value begins with space or tab")
    if value and value[-1] in (0x20, 0x09):
        raise LocalProtocolError("header value ends with space or tab")


def normalize(pairs):
    """Validate and normalize (name, value) pairs into (raw, lower, value)."""
    if isinstance(pairs, Headers):
        return list(pairs._items)
    try:
        pairs = list(pairs)
    except TypeError:
        raise LocalProtocolError("headers must be a sequence of (name, value) pairs")
    items = []
    for pair in pairs:
        if isinstance(pair, (str, bytes, bytearray)):
            raise LocalProtocolError("header must be a (name, value) pair")
        try:
            name, value = pair
        except (TypeError, ValueError):
            raise LocalProtocolError("header must be a (name, value) pair")
        raw = to_bytes(name, "header name")
        # spec: N-000106 — header name must be an RFC 7230 token
        if not is_token(raw):
            raise LocalProtocolError("header name must be an RFC 7230 token")
        val = to_bytes(value, "header value")
        check_value(val)
        items.append([raw, raw.lower(), val])
    normalize_framing(items)
    return [tuple(item) for item in items]


# spec: N-000064, N-000065 (transfer codings other than chunked, e.g. gzip and deflate, are refused)
def normalize_framing(items):
    """Normalize Transfer-Encoding and Content-Length in place (lists)."""
    # spec: N-000092, N-000093, N-000094, N-000095, N-000096 — framing header normalization
    te = [i for i, item in enumerate(items) if item[1] == b"transfer-encoding"]
    if len(te) > 1:
        # spec: N-000121 — a second Transfer-Encoding is refused, status 501
        raise LocalProtocolError("more than one Transfer-Encoding header", 501)
    if te:
        i = te[0]
        # spec: N-000120 — anything other than exactly chunked is refused, 501
        if items[i][2].lower() != b"chunked":
            raise LocalProtocolError("unsupported Transfer-Encoding", 501)
        items[i] = [items[i][0], b"transfer-encoding", b"chunked"]

    cl = [i for i, item in enumerate(items) if item[1] == b"content-length"]
    if cl:
        pieces = []
        for i in cl:
            for piece in items[i][2].split(b","):
                p = piece.strip(b" \t")
                # spec: N-000114 — must be a decimal integer
                if not _DIGITS_RE.fullmatch(p):
                    raise LocalProtocolError("Content-Length must be a decimal integer")
                # spec: N-000115, N-000116, N-000117 — digit-count limit
                if len(p) > MAX_CONTENT_LENGTH_DIGITS:
                    raise LocalProtocolError("Content-Length has too many digits")
                pieces.append(p)
        # spec: N-000118, N-000119 — disagreeing values are refused
        if len(set(int(p) for p in pieces)) != 1:
            raise LocalProtocolError("conflicting Content-Length values")
        first = cl[0]
        items[first] = [items[first][0], b"content-length", pieces[0]]
        for i in reversed(cl[1:]):
            del items[i]


def content_length(items):
    """Return the int Content-Length of normalized items, or None."""
    for item in items:
        if item[1] == b"content-length":
            return int(item[2])
    return None


def has_header(items, name):
    return any(item[1] == name for item in items)


def has_token(items, name, token):
    """True when a header ``name`` has ``token`` as a comma-separated element."""
    for item in items:
        if item[1] == name:
            for part in item[2].split(b","):
                if part.strip(b" \t").lower() == token:
                    return True
    return False


class Headers(object):
    """Ordered header list.

    Iterating or indexing yields ``(lowercase_name, value)`` byte pairs;
    ``raw_items()`` yields ``(name_as_spelled, value)`` byte pairs.
    """

    __slots__ = ("_items",)

    def __init__(self, pairs=()):
        self._items = normalize(pairs)

    def __iter__(self):
        for _raw, lower, value in self._items:
            yield (lower, value)

    def __len__(self):
        return len(self._items)

    def __getitem__(self, index):
        if isinstance(index, slice):
            return [(lower, value) for _raw, lower, value in self._items[index]]
        _raw, lower, value = self._items[index]
        return (lower, value)

    def raw_items(self):
        # spec: N-000469, N-000470, N-000471 — original-case names, in order
        return [(raw, value) for raw, _lower, value in self._items]

    def __eq__(self, other):
        if isinstance(other, (Headers, list, tuple)):
            return list(self) == list(other)
        return NotImplemented

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    __hash__ = None

    def __repr__(self):
        return "Headers(%r)" % (list(self),)
