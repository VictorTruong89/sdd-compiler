import re


class _Sentinel(object):
    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return self._name

    def __copy__(self):
        return self

    def __deepcopy__(self, memo):
        return self


CLIENT = _Sentinel("CLIENT")
SERVER = _Sentinel("SERVER")
NEED_DATA = _Sentinel("NEED_DATA")
PAUSED = _Sentinel("PAUSED")
IDLE = _Sentinel("IDLE")
SEND_RESPONSE = _Sentinel("SEND_RESPONSE")
SEND_BODY = _Sentinel("SEND_BODY")
DONE = _Sentinel("DONE")
MUST_CLOSE = _Sentinel("MUST_CLOSE")
CLOSED = _Sentinel("CLOSED")
MIGHT_SWITCH_PROTOCOL = _Sentinel("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = _Sentinel("SWITCHED_PROTOCOL")
ERROR = _Sentinel("ERROR")
_SWITCH_UPGRADE = _Sentinel("_SWITCH_UPGRADE")
_SWITCH_CONNECT = _Sentinel("_SWITCH_CONNECT")

MAX_CL_DIGITS = 18
MAX_CHUNK_HEX_DIGITS = 32
DEFAULT_MAX_INCOMPLETE = 16 * 1024


class _ProtocolError(Exception):
    def __init__(self, msg="", error_status_hint=400):
        Exception.__init__(self, msg)
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(_ProtocolError):
    def _reraise_as_remote(self):
        raise RemoteProtocolError(str(self), self.error_status_hint) from self


class RemoteProtocolError(_ProtocolError):
    pass


# ---------------------------------------------------------------- validation
_TOKEN = rb"[!#$%&'*+\-.^_`|~0-9A-Za-z]+"
_token_re = re.compile(rb"\A" + _TOKEN + rb"\Z")
_target_re = re.compile(rb"\A[\x21-\x7e]+\Z")
_value_bad_re = re.compile(rb"[\x00\r\n\x0b\x0c]")
_digits_re = re.compile(rb"\A[0-9]+\Z")


def _to_bytes(x, what):
    if type(x) is bytes:
        return x
    if isinstance(x, str):
        try:
            return x.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("non-ASCII %s" % what)
    try:
        return bytes(memoryview(x))
    except TypeError:
        raise LocalProtocolError("bad type for %s" % what)


class Headers(object):
    """Sequence of (lowercase name, value); raw_items() gives original names."""

    def __init__(self, items):
        self._items = items  # list of (raw_name, lower_name, value)

    def __len__(self):
        return len(self._items)

    def __getitem__(self, i):
        if isinstance(i, slice):
            return [(n, v) for _, n, v in self._items[i]]
        _, n, v = self._items[i]
        return (n, v)

    def __iter__(self):
        for _, n, v in self._items:
            yield (n, v)

    def raw_items(self):
        return [(r, v) for r, _, v in self._items]

    def __eq__(self, other):
        if isinstance(other, Headers):
            return list(self) == list(other)
        if isinstance(other, (list, tuple)):
            try:
                return list(self) == [tuple(p) for p in other]
            except TypeError:
                return False
        return NotImplemented

    def __ne__(self, other):
        r = self.__eq__(other)
        return r if r is NotImplemented else not r

    __hash__ = None

    def __repr__(self):
        return "Headers(%r)" % (self.raw_items(),)


def _normalize_headers(headers, parsed=False):
    if headers is None:
        headers = []
    if isinstance(headers, Headers):
        headers = headers.raw_items()
    elif isinstance(headers, dict):
        headers = list(headers.items())
    out = []
    seen_cl = None
    seen_te = False
    try:
        pairs = list(headers)
    except TypeError:
        raise LocalProtocolError("headers must be a sequence of pairs")
    for pair in pairs:
        try:
            name, value = pair
        except (TypeError, ValueError):
            raise LocalProtocolError("header must be a (name, value) pair")
        raw = _to_bytes(name, "header name")
        value = _to_bytes(value, "header value")
        if not _token_re.match(raw):
            raise LocalProtocolError("illegal header name %r" % raw)
        if _value_bad_re.search(value):
            raise LocalProtocolError("illegal header value %r" % value)
        if value[:1] in (b" ", b"\t") or value[-1:] in (b" ", b"\t"):
            raise LocalProtocolError("header value has leading/trailing whitespace")
        lname = raw.lower()
        if lname == b"content-length":
            pieces = [p.strip(b" \t") for p in value.split(b",")]
            for p in pieces:
                if not _digits_re.match(p):
                    raise LocalProtocolError("bad Content-Length")
                if len(p) > MAX_CL_DIGITS:
                    raise LocalProtocolError("Content-Length too long")
            vals = set(int(p) for p in pieces)
            if len(vals) > 1:
                raise LocalProtocolError("conflicting Content-Length")
            norm = pieces[0]
            if seen_cl is not None:
                if int(seen_cl) != int(norm):
                    raise LocalProtocolError("conflicting Content-Length")
                continue
            seen_cl = norm
            out.append((raw, lname, norm))
            continue
        if lname == b"transfer-encoding":
            if seen_te:
                raise LocalProtocolError("multiple Transfer-Encoding headers", 501)
            seen_te = True
            if value.lower() != b"chunked":
                raise LocalProtocolError("unsupported Transfer-Encoding", 501)
            out.append((raw, lname, b"chunked"))
            continue
        out.append((raw, lname, value))
    return Headers(out)


def _comma_values(headers, name):
    res = []
    for _, n, v in headers._items:
        if n == name:
            for piece in v.split(b","):
                piece = piece.strip(b" \t").lower()
                if piece:
                    res.append(piece)
    return res


# -------------------------------------------------------------------- events
class _Event(object):
    _fields = ()

    def __eq__(self, other):
        return type(self) is type(other) and all(
            getattr(self, f) == getattr(other, f) for f in self._fields)

    def __ne__(self, other):
        return not self.__eq__(other)

    __hash__ = None

    def __repr__(self):
        return "%s(%s)" % (type(self).__name__, ", ".join(
            "%s=%r" % (f, getattr(self, f)) for f in self._fields))


class Request(_Event):
    _fields = ("method", "target", "headers", "http_version")

    def __init__(self, *, method, target, headers, http_version=b"1.1", _parsed=False):
        self.method = _to_bytes(method, "method")
        self.target = _to_bytes(target, "target")
        self.http_version = _to_bytes(http_version, "http_version")
        self.headers = _normalize_headers(headers, _parsed)
        if not _token_re.match(self.method):
            raise LocalProtocolError("illegal method")
        if not _target_re.match(self.target):
            raise LocalProtocolError("illegal target")
        hosts = sum(1 for _, n, _v in self.headers._items if n == b"host")
        if hosts > 1:
            raise LocalProtocolError("Found multiple Host headers")
        if self.http_version == b"1.1" and hosts == 0:
            raise LocalProtocolError("Missing mandatory Host: header")


class _ResponseBase(_Event):
    _fields = ("status_code", "headers", "http_version", "reason")
    _lo = 0
    _hi = 0

    def __init__(self, *, status_code, headers, http_version=b"1.1", reason=b"", _parsed=False):
        self.http_version = _to_bytes(http_version, "http_version")
        self.reason = _to_bytes(reason, "reason")
        if not isinstance(status_code, int) or isinstance(status_code, bool):
            raise LocalProtocolError("status code must be an integer")
        status_code = int(status_code)
        if not (self._lo <= status_code < self._hi):
            raise LocalProtocolError("illegal status code %r" % status_code)
        self.status_code = status_code
        self.headers = _normalize_headers(headers, _parsed)


class InformationalResponse(_ResponseBase):
    _lo, _hi = 100, 200


class Response(_ResponseBase):
    _lo, _hi = 200, 1000


class Data(_Event):
    _fields = ("data", "chunk_start", "chunk_end")

    def __init__(self, *, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)


class EndOfMessage(_Event):
    _fields = ("headers",)

    def __init__(self, *, headers=None, _parsed=False):
        self.headers = _normalize_headers(headers, _parsed)


class ConnectionClosed(_Event):
    _fields = ()

    def __init__(self):
        pass


# --------------------------------------------------------------------- state
_EVT = {
    CLIENT: {
        IDLE: {Request: SEND_BODY, ConnectionClosed: CLOSED},
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
        CLOSED: {ConnectionClosed: CLOSED},
    },
    SERVER: {
        IDLE: {ConnectionClosed: CLOSED, Response: SEND_BODY,
               _SWITCH_UPGRADE: SWITCHED_PROTOCOL, _SWITCH_CONNECT: SWITCHED_PROTOCOL},
        SEND_RESPONSE: {InformationalResponse: SEND_RESPONSE, Response: SEND_BODY,
                        _SWITCH_UPGRADE: SWITCHED_PROTOCOL, _SWITCH_CONNECT: SWITCHED_PROTOCOL},
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
        CLOSED: {ConnectionClosed: CLOSED},
    },
}


class _StateMachine(object):
    def __init__(self):
        self.states = {CLIENT: IDLE, SERVER: IDLE}
        self.keep_alive = True
        self.pending = set()

    def process_event(self, role, evtype, switch_event=None):
        if switch_event is not None:
            if switch_event not in self.pending:
                raise LocalProtocolError("Received server switch without proposal")
            evtype = switch_event
        elif evtype is Response:
            self.pending = set()
        try:
            new = _EVT[role][self.states[role]][evtype]
        except KeyError:
            raise LocalProtocolError(
                "can't handle event type %s when role=%s and state=%s"
                % (getattr(evtype, "__name__", evtype), role, self.states[role]))
        self.states[role] = new
        if switch_event is not None:
            self.pending = set()
        self._fire()

    def add_proposal(self, p):
        self.pending.add(p)

    def disable_keep_alive(self):
        self.keep_alive = False
        self._fire()

    def process_error(self, role):
        self.states[role] = ERROR
        self.keep_alive = False
        self._fire()

    def start_next_cycle(self):
        if self.states != {CLIENT: DONE, SERVER: DONE}:
            raise LocalProtocolError(
                "not in a reusable state: %s" % (self.states,))
        assert self.keep_alive
        assert not self.pending
        self.states = {CLIENT: IDLE, SERVER: IDLE}

    def _fire(self):
        st = self.states
        while True:
            start = dict(st)
            if self.pending and st[CLIENT] is DONE:
                st[CLIENT] = MIGHT_SWITCH_PROTOCOL
            if not self.pending and st[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                st[CLIENT] = DONE
            if st[SERVER] is SWITCHED_PROTOCOL and st[CLIENT] in (DONE, MIGHT_SWITCH_PROTOCOL):
                st[CLIENT] = SWITCHED_PROTOCOL
            if not self.keep_alive:
                for r in (CLIENT, SERVER):
                    if st[r] is DONE:
                        st[r] = MUST_CLOSE
            c, s = st[CLIENT], st[SERVER]
            if c is SEND_BODY and s is IDLE:
                st[SERVER] = SEND_RESPONSE
            if c is CLOSED and s in (IDLE, DONE):
                st[SERVER] = MUST_CLOSE
            if s is CLOSED and c in (IDLE, DONE):
                st[CLIENT] = MUST_CLOSE
            if c is ERROR and s is DONE:
                st[SERVER] = MUST_CLOSE
            if s is ERROR and c is DONE:
                st[CLIENT] = MUST_CLOSE
            if st == start:
                return


# ------------------------------------------------------------------- framing
def _body_framing(request_method, event):
    if type(event) is Response:
        if (event.status_code in (204, 304) or request_method == b"HEAD"
                or (request_method == b"CONNECT" and 200 <= event.status_code < 300)):
            return ("content-length", (0,))
        if _comma_values(event.headers, b"transfer-encoding"):
            return ("chunked", ())
    else:
        if not _comma_values(event.headers, b"content-length") and \
                _comma_values(event.headers, b"transfer-encoding"):
            return ("chunked", ())
    cls = _comma_values(event.headers, b"content-length")
    if cls:
        return ("content-length", (int(cls[0]),))
    if type(event) is Response:
        return ("http/1.0", ())
    return ("content-length", (0,))


# ------------------------------------------------------------------- writers
def _write_headers(headers, out):
    items = headers._items
    parts = []
    for raw, n, v in items:
        if n == b"host":
            parts.append(raw + b": " + v + b"\r\n")
    for raw, n, v in items:
        if n != b"host":
            parts.append(raw + b": " + v + b"\r\n")
    parts.append(b"\r\n")
    out(b"".join(parts))


def _write_request(ev, out):
    if ev.http_version != b"1.1":
        raise LocalProtocolError("Only HTTP/1.1 is supported")
    out(ev.method + b" " + ev.target + b" HTTP/1.1\r\n")
    _write_headers(ev.headers, out)


def _write_response(ev, out):
    if ev.http_version != b"1.1":
        raise LocalProtocolError("Only HTTP/1.1 is supported")
    out(b"HTTP/1.1 " + str(ev.status_code).encode("ascii") + b" " + ev.reason + b"\r\n")
    _write_headers(ev.headers, out)


class _CLWriter(object):
    def __init__(self, length):
        self.remaining = length

    def __call__(self, ev, out):
        if type(ev) is Data:
            self.remaining -= len(ev.data)
            if self.remaining < 0:
                raise LocalProtocolError("Too much data for declared Content-Length")
            out(ev.data)
        elif type(ev) is EndOfMessage:
            if self.remaining != 0:
                raise LocalProtocolError("Too little data for declared Content-Length")
            if len(ev.headers):
                raise LocalProtocolError("Content-Length framing cannot carry trailers")


class _ChunkedWriter(object):
    def __call__(self, ev, out):
        if type(ev) is Data:
            if len(ev.data) == 0:
                return
            out(b"%x\r\n" % len(ev.data))
            out(ev.data)
            out(b"\r\n")
        elif type(ev) is EndOfMessage:
            out(b"0\r\n")
            _write_headers(ev.headers, out)


class _H10Writer(object):
    def __call__(self, ev, out):
        if type(ev) is Data:
            out(ev.data)
        elif type(ev) is EndOfMessage:
            if len(ev.headers):
                raise LocalProtocolError("HTTP/1.0 framing cannot carry trailers")


# ------------------------------------------------------------------- reading
_block_end_re = re.compile(rb"\r?\n\r?\n")
_line_split_re = re.compile(rb"\r?\n")
_request_line_re = re.compile(
    rb"\A(" + _TOKEN + rb") ([\x21-\x7e]+) HTTP/([0-9]\.[0-9])\Z")
_status_line_re = re.compile(
    rb"\AHTTP/([0-9]\.[0-9]) ([0-9]{3})(?: ([\t\x20-\x7e\x80-\xff]*))?\Z")
_chunk_re = re.compile(
    rb"\A([0-9a-fA-F]{1,%d})[ \t]*(?:;[^\r\n]*)?\Z" % MAX_CHUNK_HEX_DIGITS)


class _Buf(object):
    def __init__(self):
        self.data = bytearray()

    def __len__(self):
        return len(self.data)

    def __bool__(self):
        return bool(self.data)

    def extract_block(self):
        m = _block_end_re.search(self.data)
        if m is None:
            return None
        block = bytes(self.data[:m.start()])
        del self.data[:m.end()]
        return _line_split_re.split(block)

    def extract_at_most(self, n):
        if not self.data:
            return None
        out = bytes(self.data[:n])
        del self.data[:n]
        return out


def _parse_headers(lines):
    items = []
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            if not items:
                raise LocalProtocolError("continuation line at start of headers")
            name, value = items[-1]
            cont = line.strip(b" \t")
            items[-1] = (name, value + b" " + cont if cont else value)
            continue
        name, sep, value = line.partition(b":")
        if not sep:
            raise LocalProtocolError("malformed header line")
        items.append((name, value.strip(b" \t")))
    return items


def _obviously_invalid(buf):
    d = buf.data
    return bool(d) and d[0] < 33


def _read_request(buf):
    if _obviously_invalid(buf):
        raise LocalProtocolError("illegal request line")
    lines = buf.extract_block()
    if lines is None:
        return None
    m = _request_line_re.match(lines[0])
    if not m:
        raise LocalProtocolError("illegal request line")
    return Request(method=m.group(1), target=m.group(2), http_version=m.group(3),
                   headers=_parse_headers(lines[1:]), _parsed=True)


def _read_response(buf):
    if _obviously_invalid(buf):
        raise LocalProtocolError("illegal status line")
    lines = buf.extract_block()
    if lines is None:
        return None
    m = _status_line_re.match(lines[0])
    if not m:
        raise LocalProtocolError("illegal status line")
    status = int(m.group(2))
    cls = InformationalResponse if status < 200 else Response
    return cls(status_code=status, headers=_parse_headers(lines[1:]),
               http_version=m.group(1), reason=m.group(3) or b"", _parsed=True)


def _expect_nothing(buf):
    if buf:
        raise LocalProtocolError("Got data when expecting EOF")
    return None


class _CLReader(object):
    def __init__(self, length):
        self.remaining = length

    def __call__(self, buf):
        if self.remaining == 0:
            return EndOfMessage()
        data = buf.extract_at_most(self.remaining)
        if data is None:
            return None
        self.remaining -= len(data)
        return Data(data=data)

    def read_eof(self):
        raise LocalProtocolError("peer closed connection before Content-Length body completed")


class _H10Reader(object):
    def __call__(self, buf):
        data = buf.extract_at_most(1 << 30)
        if data is None:
            return None
        return Data(data=data)

    def read_eof(self):
        return EndOfMessage()


class _ChunkedReader(object):
    def __init__(self):
        self.in_chunk = 0
        self.to_discard = 0
        self.trailer = False

    def __call__(self, buf):
        if self.trailer:
            d = buf.data
            if d[:2] == b"\r\n":
                del d[:2]
                return EndOfMessage(headers=[], _parsed=True)
            if d[:1] == b"\n":
                del d[:1]
                return EndOfMessage(headers=[], _parsed=True)
            lines = buf.extract_block()
            if lines is None:
                return None
            return EndOfMessage(headers=_parse_headers(lines), _parsed=True)
        if self.to_discard > 0:
            d = buf.data
            if len(d) < self.to_discard:
                if bytes(d) != b"\r\n"[:len(d)]:
                    raise LocalProtocolError("bad chunk terminator")
                return None
            if bytes(d[:self.to_discard]) != b"\r\n"[2 - self.to_discard:]:
                raise LocalProtocolError("bad chunk terminator")
            del d[:self.to_discard]
            self.to_discard = 0
        start = False
        if self.in_chunk == 0:
            d = buf.data
            i = d.find(b"\r\n")
            if i < 0:
                m = re.match(rb"[0-9a-fA-F]*", bytes(d[:MAX_CHUNK_HEX_DIGITS + 2]))
                if len(m.group(0)) > MAX_CHUNK_HEX_DIGITS:
                    raise LocalProtocolError("chunk size too long")
                if d[:1] and not re.match(rb"[0-9a-fA-F]", bytes(d[:1])):
                    raise LocalProtocolError("illegal chunk header")
                return None
            line = bytes(d[:i])
            m = _chunk_re.match(line)
            if not m:
                raise LocalProtocolError("illegal chunk header")
            del d[:i + 2]
            self.in_chunk = int(m.group(1), 16)
            if self.in_chunk == 0:
                self.trailer = True
                return self(buf)
            start = True
        data = buf.extract_at_most(self.in_chunk)
        if data is None:
            return None
        self.in_chunk -= len(data)
        end = False
        if self.in_chunk == 0:
            self.to_discard = 2
            end = True
        return Data(data=data, chunk_start=start, chunk_end=end)

    def read_eof(self):
        raise LocalProtocolError("peer closed connection in the middle of a chunked body")


# ---------------------------------------------------------------- connection
def _keep_alive(ev):
    if b"close" in _comma_values(ev.headers, b"connection"):
        return False
    if ev.http_version < b"1.1":
        return False
    return True


def _expect_100(ev):
    return ev.http_version == b"1.1" and b"100-continue" in _comma_values(ev.headers, b"expect")


class Connection(object):
    def __init__(self, our_role, max_incomplete_event_size=DEFAULT_MAX_INCOMPLETE):
        if our_role is not CLIENT and our_role is not SERVER:
            raise ValueError("expected CLIENT or SERVER, not %r" % (our_role,))
        self.our_role = our_role
        self.their_role = SERVER if our_role is CLIENT else CLIENT
        self._cstate = _StateMachine()
        self._max = max_incomplete_event_size
        self._buf = _Buf()
        self._closed = False
        self.their_http_version = None
        self._request_method = None
        self.client_is_waiting_for_100_continue = False
        self._writer = self._get_io(self.our_role, None, True)
        self._reader = self._get_io(self.their_role, None, False)

    # -- queries
    @property
    def states(self):
        return dict(self._cstate.states)

    @property
    def our_state(self):
        return self._cstate.states[self.our_role]

    @property
    def their_state(self):
        return self._cstate.states[self.their_role]

    @property
    def they_are_waiting_for_100_continue(self):
        return self.their_role is CLIENT and self.client_is_waiting_for_100_continue

    @property
    def trailing_data(self):
        return (bytes(self._buf.data), self._closed)

    # -- io object selection
    def _get_io(self, role, event, writer):
        state = self._cstate.states[role]
        if state is SEND_BODY:
            kind, args = _body_framing(self._request_method, event)
            if writer:
                return {"content-length": _CLWriter, "chunked": _ChunkedWriter,
                        "http/1.0": _H10Writer}[kind](*args)
            return {"content-length": _CLReader, "chunked": _ChunkedReader,
                    "http/1.0": _H10Reader}[kind](*args)
        if writer:
            if role is CLIENT and state is IDLE:
                return _write_request
            if role is SERVER and state in (IDLE, SEND_RESPONSE):
                return _write_response
            return None
        if role is CLIENT and state is IDLE:
            return _read_request
        if role is SERVER and state in (IDLE, SEND_RESPONSE):
            return _read_response
        if state in (DONE, MUST_CLOSE, CLOSED):
            return _expect_nothing
        return None

    def _switch_event(self, event):
        p = self._cstate.pending
        if type(event) is InformationalResponse and event.status_code == 101 \
                and _SWITCH_UPGRADE in p:
            return _SWITCH_UPGRADE
        if type(event) is Response and 200 <= event.status_code < 300 \
                and _SWITCH_CONNECT in p:
            return _SWITCH_CONNECT
        return None

    def _process_event(self, role, event):
        old = dict(self._cstate.states)
        t = type(event)
        sw = None
        if role is CLIENT and t is Request:
            if event.method == b"CONNECT":
                self._cstate.add_proposal(_SWITCH_CONNECT)
            if _comma_values(event.headers, b"upgrade"):
                self._cstate.add_proposal(_SWITCH_UPGRADE)
        if role is SERVER:
            sw = self._switch_event(event)
        self._cstate.process_event(role, t, sw)
        if t is Request:
            self._request_method = event.method
        if role is self.their_role and t in (Request, Response, InformationalResponse):
            self.their_http_version = event.http_version
        if t in (Request, Response) and not _keep_alive(event):
            self._cstate.disable_keep_alive()
        if t is Request:
            if _expect_100(event):
                self.client_is_waiting_for_100_continue = True
        elif t in (InformationalResponse, Response, Data, EndOfMessage):
            self.client_is_waiting_for_100_continue = False
        if self.our_state is not old[self.our_role]:
            self._writer = self._get_io(self.our_role, event, True)
        if self.their_state is not old[self.their_role]:
            self._reader = self._get_io(self.their_role, event, False)

    def _process_error(self, role):
        old = dict(self._cstate.states)
        self._cstate.process_error(role)
        if self.our_state is not old[self.our_role]:
            self._writer = None
        if self.their_state is not old[self.their_role]:
            self._reader = None if self.their_state is ERROR else self._get_io(self.their_role, None, False)

    # -- public
    def receive_data(self, data):
        if data:
            if self._closed:
                raise RuntimeError("received close, then received more data?")
            self._buf.data += data
        else:
            self._closed = True

    def _extract(self):
        state = self.their_state
        if state is DONE and self._buf:
            return PAUSED
        if state in (MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL):
            return PAUSED
        reader = self._reader
        if reader is None:
            raise LocalProtocolError("no reader for state %s" % state)
        ev = reader(self._buf)
        if ev is None:
            if not self._buf and self._closed:
                if hasattr(reader, "read_eof"):
                    ev = reader.read_eof()
                else:
                    ev = ConnectionClosed()
        if ev is None:
            ev = NEED_DATA
        return ev

    def next_event(self):
        if self.their_state is ERROR:
            raise RemoteProtocolError("Can't receive data when peer state is ERROR")
        try:
            ev = self._extract()
            if ev is not NEED_DATA and ev is not PAUSED:
                self._process_event(self.their_role, ev)
            if ev is NEED_DATA:
                if len(self._buf) > self._max:
                    raise RemoteProtocolError("Receive buffer too long", 431)
                if self._closed:
                    raise RemoteProtocolError("peer unexpectedly closed connection")
            return ev
        except BaseException as exc:
            self._process_error(self.their_role)
            if isinstance(exc, LocalProtocolError):
                exc._reraise_as_remote()
            raise

    def send(self, event):
        pieces = self.send_with_data_passthrough(event)
        if not pieces:
            return None
        return b"".join(pieces)

    def send_with_data_passthrough(self, event):
        if self.our_state is ERROR:
            raise LocalProtocolError("Can't send data when our state is ERROR")
        try:
            if type(event) is Response:
                event = self._clean_response(event)
            writer = self._writer
            self._process_event(self.our_role, event)
            if type(event) is ConnectionClosed:
                return []
            if writer is None:
                raise LocalProtocolError("cannot send in current state")
            pieces = []
            writer(event, pieces.append)
            return pieces
        except BaseException:
            self._process_error(self.our_role)
            raise

    def _clean_response(self, response):
        method = self._request_method
        if method not in (b"HEAD", b"GET"):
            method = b"GET"
        framing, _ = _body_framing(method, response)
        items = response.headers.raw_items()
        need_close = False
        if framing in ("chunked", "http/1.0"):
            items = [(n, v) for n, v in items
                     if n.lower() not in (b"content-length", b"transfer-encoding")]
            if self.their_http_version is None or self.their_http_version < b"1.1":
                need_close = True
            else:
                items.append((b"transfer-encoding", b"chunked"))
        if not self._cstate.keep_alive or need_close:
            tokens = set(_comma_values(response.headers, b"connection"))
            tokens.discard(b"keep-alive")
            tokens.add(b"close")
            items = [(n, v) for n, v in items if n.lower() != b"connection"]
            for t in sorted(tokens):
                items.append((b"connection", t))
        return Response(status_code=response.status_code, headers=items,
                        http_version=response.http_version, reason=response.reason)

    def start_next_cycle(self):
        self._cstate.start_next_cycle()
        self._request_method = None
        self.client_is_waiting_for_100_continue = False
        self._writer = self._get_io(self.our_role, None, True)
        self._reader = self._get_io(self.their_role, None, False)

    def send_failed(self):
        self._process_error(self.our_role)
