import re

# ---------------------------------------------------------------- sentinels


class _Sentinel:
    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return self._name

    def __copy__(self):
        return self

    def __deepcopy__(self, memo):
        return self


CLIENT = _Sentinel("CLIENT")
SERVER = _Sentinel("SERVER")
NEED_DATA = _Sentinel("NEED_DATA")
PAUSED = _Sentinel("PAUSED")
(IDLE, SEND_RESPONSE, SEND_BODY, DONE, MUST_CLOSE, CLOSED,
 MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL, ERROR) = [
    _Sentinel(n) for n in (
        "IDLE", "SEND_RESPONSE", "SEND_BODY", "DONE", "MUST_CLOSE", "CLOSED",
        "MIGHT_SWITCH_PROTOCOL", "SWITCHED_PROTOCOL", "ERROR")]
_SWITCH_UPGRADE = _Sentinel("_SWITCH_UPGRADE")
_SWITCH_CONNECT = _Sentinel("_SWITCH_CONNECT")

# ------------------------------------------------------------------ errors


class ProtocolError(Exception):
    def __init__(self, msg="", error_status_hint=400):
        super().__init__(msg)
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(ProtocolError):
    pass


class RemoteProtocolError(ProtocolError):
    pass


def _as_remote(exc):
    return RemoteProtocolError(str(exc), exc.error_status_hint)


# ------------------------------------------------------------- validation

_TOKEN = rb"[!#$%&'*+\-.^_`|~0-9A-Za-z]+"
_token_re = re.compile(_TOKEN)
_value_re = re.compile(
    rb"(?:[^\x00\r\n\x0b\x0c \t](?:[^\x00\r\n\x0b\x0c]*[^\x00\r\n\x0b\x0c \t])?)?")
_target_re = re.compile(rb"[\x21-\x7e]+")
_version_re = re.compile(rb"[0-9]\.[0-9]")
_reason_re = re.compile(rb"[ \t\x21-\x7e\x80-\xff]*")
_digits_re = re.compile(rb"[0-9]+")
MAX_CONTENT_LENGTH_DIGITS = 18
MAX_CHUNK_DIGITS = 32
_chunk_re = re.compile(rb"([0-9a-fA-F]{1,%d})(?:;[^\r\n]*)?[ \t]*" % MAX_CHUNK_DIGITS)

_request_line_re = re.compile(
    rb"(" + _TOKEN + rb") ([\x21-\x7e]+) HTTP/([0-9]\.[0-9])")
_status_line_re = re.compile(
    rb"HTTP/([0-9]\.[0-9]) ([0-9]{3})(?: ([^\r\n]*))?")
_header_line_re = re.compile(rb"(" + _TOKEN + rb"):[ \t]*(.*)", re.S)


def _to_bytes(v, what="value"):
    if type(v) is bytes:
        return v
    if isinstance(v, str):
        try:
            return v.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("non-ASCII %s" % what)
    if isinstance(v, (bytes, bytearray, memoryview)):
        return bytes(v)
    raise LocalProtocolError("%s must be str or bytes-like" % what)


def _split_commas(value):
    return [p.strip(b" \t") for p in value.split(b",") if p.strip(b" \t")]


class Headers:
    def __init__(self, full_items):
        self._full_items = full_items  # (raw_name, lower_name, value)

    def __iter__(self):
        return ((n, v) for _, n, v in self._full_items)

    def __len__(self):
        return len(self._full_items)

    def __getitem__(self, i):
        if isinstance(i, slice):
            return [(n, v) for _, n, v in self._full_items[i]]
        _, n, v = self._full_items[i]
        return (n, v)

    def __bool__(self):
        return bool(self._full_items)

    def __eq__(self, other):
        if isinstance(other, Headers):
            return list(self) == list(other)
        try:
            return list(self) == [(_to_bytes(a), _to_bytes(b)) for a, b in other]
        except Exception:
            return False

    __hash__ = None

    def raw_items(self):
        return [(r, v) for r, _, v in self._full_items]

    def __repr__(self):
        return repr(list(self))


def _normalize_headers(headers):
    if headers is None:
        headers = []
    if hasattr(headers, "items") and callable(headers.items):
        headers = list(headers.items())
    out = []
    cl_seen = None
    cl_value = None
    te_seen = False
    host_count = 0
    for item in headers:
        try:
            raw_name, value = item
        except (TypeError, ValueError):
            raise LocalProtocolError("header must be a (name, value) pair")
        raw_name = _to_bytes(raw_name, "header name")
        value = _to_bytes(value, "header value")
        if not _token_re.fullmatch(raw_name):
            raise LocalProtocolError("illegal header name %r" % raw_name)
        if not _value_re.fullmatch(value):
            raise LocalProtocolError("illegal header value %r" % value)
        name = raw_name.lower()
        if name == b"content-length":
            pieces = [p.strip(b" \t") for p in value.split(b",")]
            for p in pieces:
                if not _digits_re.fullmatch(p) or len(p) > MAX_CONTENT_LENGTH_DIGITS:
                    raise LocalProtocolError("bad Content-Length")
            nums = set(int(p) for p in pieces)
            if len(nums) > 1 or (cl_value is not None and cl_value not in nums):
                raise LocalProtocolError("conflicting Content-Length")
            if cl_seen:
                continue
            cl_seen = True
            cl_value = nums.pop()
            value = pieces[0]
        elif name == b"transfer-encoding":
            if te_seen:
                raise LocalProtocolError("multiple Transfer-Encoding", 501)
            te_seen = True
            if value.lower() != b"chunked":
                raise LocalProtocolError("unsupported Transfer-Encoding", 501)
            value = b"chunked"
        elif name == b"host":
            host_count += 1
        out.append((raw_name, name, value))
    return Headers(out), host_count


def _comma_header(headers, name):
    out = []
    for _, n, v in headers._full_items:
        if n == name:
            out.extend(p.lower() for p in _split_commas(v))
    return out


def _set_comma_header(headers, name, values):
    items = [(r, n, v) for r, n, v in headers._full_items if n != name]
    items.extend((name, name, v) for v in values)
    return items


# ------------------------------------------------------------------ events


class _Event:
    _fields = ()

    def __eq__(self, other):
        return type(self) is type(other) and all(
            getattr(self, f) == getattr(other, f) for f in self._fields)

    __hash__ = None

    def __repr__(self):
        return "%s(%s)" % (type(self).__name__, ", ".join(
            "%s=%r" % (f, getattr(self, f)) for f in self._fields))


def _version(v):
    v = _to_bytes(v, "http_version")
    if not _version_re.fullmatch(v):
        raise LocalProtocolError("illegal http version")
    return v


def _status(code, lo, hi):
    if isinstance(code, bool) or not isinstance(code, int):
        raise LocalProtocolError("status_code must be an int")
    code = int(code)
    if not lo <= code < hi:
        raise LocalProtocolError("status_code out of range")
    return code


class Request(_Event):
    _fields = ("method", "headers", "target", "http_version")

    def __init__(self, *, method, headers, target, http_version=b"1.1"):
        method = _to_bytes(method, "method")
        target = _to_bytes(target, "target")
        http_version = _version(http_version)
        if not _token_re.fullmatch(method):
            raise LocalProtocolError("illegal method")
        if not _target_re.fullmatch(target):
            raise LocalProtocolError("illegal target")
        hdrs, hosts = _normalize_headers(headers)
        if hosts > 1:
            raise LocalProtocolError("multiple Host headers")
        if http_version == b"1.1" and hosts == 0:
            raise LocalProtocolError("Missing mandatory Host: header")
        self.method, self.target, self.http_version = method, target, http_version
        self.headers = hdrs


class _ResponseBase(_Event):
    _fields = ("status_code", "headers", "http_version", "reason")
    _lo = _hi = 0

    def __init__(self, *, status_code, headers, http_version=b"1.1", reason=b""):
        self.status_code = _status(status_code, self._lo, self._hi)
        self.http_version = _version(http_version)
        reason = _to_bytes(reason, "reason")
        if not _reason_re.fullmatch(reason):
            raise LocalProtocolError("illegal reason phrase")
        self.reason = reason
        self.headers, _ = _normalize_headers(headers)


class InformationalResponse(_ResponseBase):
    _lo, _hi = 100, 200


class Response(_ResponseBase):
    _lo, _hi = 200, 1000


class Data(_Event):
    _fields = ("data", "chunk_start", "chunk_end")

    def __init__(self, *, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)


class EndOfMessage(_Event):
    _fields = ("headers",)

    def __init__(self, *, headers=None):
        self.headers, _ = _normalize_headers(headers)


class ConnectionClosed(_Event):
    pass


# ------------------------------------------------------------ state machine

_EVENT_TRANSITIONS = {
    CLIENT: {
        IDLE: {Request: SEND_BODY, ConnectionClosed: CLOSED},
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
        CLOSED: {ConnectionClosed: CLOSED},
    },
    SERVER: {
        IDLE: {ConnectionClosed: CLOSED, Response: SEND_BODY,
               (Request, CLIENT): SEND_RESPONSE},
        SEND_RESPONSE: {InformationalResponse: SEND_RESPONSE,
                        Response: SEND_BODY,
                        (InformationalResponse, _SWITCH_UPGRADE): SWITCHED_PROTOCOL,
                        (Response, _SWITCH_CONNECT): SWITCHED_PROTOCOL},
        SEND_BODY: {Data: SEND_BODY, EndOfMessage: DONE},
        DONE: {ConnectionClosed: CLOSED},
        MUST_CLOSE: {ConnectionClosed: CLOSED},
        CLOSED: {ConnectionClosed: CLOSED},
    },
}

_STATE_TRANSITIONS = {
    (MIGHT_SWITCH_PROTOCOL, SWITCHED_PROTOCOL): {CLIENT: SWITCHED_PROTOCOL},
    (CLOSED, DONE): {SERVER: MUST_CLOSE},
    (CLOSED, IDLE): {SERVER: MUST_CLOSE},
    (ERROR, DONE): {SERVER: MUST_CLOSE},
    (DONE, CLOSED): {CLIENT: MUST_CLOSE},
    (IDLE, CLOSED): {CLIENT: MUST_CLOSE},
    (DONE, ERROR): {CLIENT: MUST_CLOSE},
}


class _ConnectionState:
    def __init__(self):
        self.states = {CLIENT: IDLE, SERVER: IDLE}
        self.keep_alive = True
        self.pending = set()

    def process_error(self, role):
        self.states[role] = ERROR
        self.keep_alive = False
        self._fire_state()

    def disable_keep_alive(self):
        self.keep_alive = False
        self._fire_state()

    def client_switch_proposal(self, ev):
        self.pending.add(ev)

    def process_event(self, role, event_type, server_switch_event=None):
        et = event_type
        if server_switch_event is not None:
            if server_switch_event not in self.pending:
                raise LocalProtocolError(
                    "Received server switch event without a pending proposal")
            et = (event_type, server_switch_event)
        if server_switch_event is None and event_type is Response:
            self.pending.clear()
        self._fire_event(role, et)
        if event_type is Request:
            self._fire_event(SERVER, (Request, CLIENT))
        self._fire_state()

    def _fire_event(self, role, et):
        state = self.states[role]
        try:
            new = _EVENT_TRANSITIONS[role][state][et]
        except KeyError:
            name = et.__name__ if isinstance(et, type) else str(et)
            raise LocalProtocolError(
                "can't handle event %s for %s in state %s" % (name, role, state))
        self.states[role] = new

    def _fire_state(self):
        while True:
            start = dict(self.states)
            if self.pending and self.states[CLIENT] is DONE:
                self.states[CLIENT] = MIGHT_SWITCH_PROTOCOL
            if not self.pending and self.states[CLIENT] is MIGHT_SWITCH_PROTOCOL:
                self.states[CLIENT] = DONE
            if not self.keep_alive:
                for r in (CLIENT, SERVER):
                    if self.states[r] is DONE:
                        self.states[r] = MUST_CLOSE
            joint = (self.states[CLIENT], self.states[SERVER])
            self.states.update(_STATE_TRANSITIONS.get(joint, {}))
            if self.states == start:
                return

    def start_next_cycle(self):
        if self.states != {CLIENT: DONE, SERVER: DONE}:
            raise LocalProtocolError(
                "not in a reusable state: %s" % (self.states,))
        self.keep_alive = True
        self.pending.clear()
        self.states = {CLIENT: IDLE, SERVER: IDLE}


# ----------------------------------------------------------------- helpers


def _keep_alive(event):
    if b"close" in _comma_header(event.headers, b"connection"):
        return False
    if event.http_version < b"1.1":
        return False
    return True


def _expect_100(event):
    return (event.http_version == b"1.1"
            and b"100-continue" in _comma_header(event.headers, b"expect"))


def _body_framing(request_method, event):
    if type(event) is Response:
        if (event.status_code in (204, 304) or request_method == b"HEAD"
                or (request_method == b"CONNECT" and 200 <= event.status_code < 300)):
            return ("content-length", (0,))
        if _comma_header(event.headers, b"transfer-encoding"):
            return ("chunked", ())
        cls = _comma_header(event.headers, b"content-length")
        if cls:
            return ("content-length", (int(cls[0]),))
        return ("http/1.0", ())
    cls = _comma_header(event.headers, b"content-length")
    if cls:
        return ("content-length", (int(cls[0]),))
    if _comma_header(event.headers, b"transfer-encoding"):
        return ("chunked", ())
    return ("content-length", (0,))


# ------------------------------------------------------------------ writers


def _write_headers(headers, write):
    for raw, name, value in headers._full_items:
        if name == b"host":
            write(raw + b": " + value + b"\r\n")
    for raw, name, value in headers._full_items:
        if name != b"host":
            write(raw + b": " + value + b"\r\n")
    write(b"\r\n")


def _write_request(event, write):
    if event.http_version != b"1.1":
        raise LocalProtocolError("I only send HTTP/1.1")
    write(b"%s %s HTTP/1.1\r\n" % (event.method, event.target))
    _write_headers(event.headers, write)


def _write_any_response(event, write):
    if event.http_version != b"1.1":
        raise LocalProtocolError("I only send HTTP/1.1")
    write(b"HTTP/1.1 %d %s\r\n" % (event.status_code, event.reason))
    _write_headers(event.headers, write)


class _CLWriter:
    def __init__(self, length):
        self._length = length

    def __call__(self, event, write):
        if type(event) is Data:
            self._length -= len(event.data)
            if self._length < 0:
                raise LocalProtocolError("Too much data for declared Content-Length")
            write(event.data)
        else:
            if self._length != 0:
                raise LocalProtocolError("Too little data for declared Content-Length")
            if event.headers:
                raise LocalProtocolError("Content-Length and trailers don't mix")


class _ChunkedWriter:
    def __call__(self, event, write):
        if type(event) is Data:
            n = len(event.data)
            if n:
                write(b"%x\r\n" % n)
                write(event.data)
                write(b"\r\n")
        else:
            write(b"0\r\n")
            _write_headers(event.headers, write)


class _Http10Writer:
    def __call__(self, event, write):
        if type(event) is Data:
            write(event.data)
        elif event.headers:
            raise LocalProtocolError("can't send trailers to HTTP/1.0 client")


# ------------------------------------------------------------------ readers


def _extract_block(buf):
    if buf[:2] == b"\r\n":
        del buf[:2]
        return []
    if buf[:1] == b"\n":
        del buf[:1]
        return []
    m = re.search(rb"\n\r?\n", buf)
    if m is None:
        return None
    block = bytes(buf[:m.start() + 1])
    del buf[:m.end()]
    lines = re.split(rb"\r?\n", block)
    lines.pop()
    return lines


def _parse_headers(lines):
    out = []
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            raise LocalProtocolError("obsolete line folding unsupported")
        m = _header_line_re.fullmatch(line)
        if m is None:
            raise LocalProtocolError("illegal header line")
        out.append((m.group(1), m.group(2).rstrip(b" \t")))
    return out


def _check_first_byte(buf):
    if buf[0] < 33:
        raise LocalProtocolError("illegal start of message line")


def _read_request(buf):
    if not buf:
        return None
    _check_first_byte(buf)
    lines = _extract_block(buf)
    if lines is None:
        return None
    m = _request_line_re.fullmatch(lines[0])
    if m is None:
        raise LocalProtocolError("illegal request line")
    return Request(method=m.group(1), target=m.group(2), http_version=m.group(3),
                   headers=_parse_headers(lines[1:]))


def _read_response(buf):
    if not buf:
        return None
    _check_first_byte(buf)
    lines = _extract_block(buf)
    if lines is None:
        return None
    m = _status_line_re.fullmatch(lines[0])
    if m is None:
        raise LocalProtocolError("illegal status line")
    code = int(m.group(2))
    cls = InformationalResponse if code < 200 else Response
    return cls(status_code=code, http_version=m.group(1),
               reason=m.group(3) or b"", headers=_parse_headers(lines[1:]))


def _take(buf, n):
    if not buf:
        return None
    data = bytes(buf[:n])
    del buf[:len(data)]
    return data


def _expect_nothing(buf):
    if buf:
        raise LocalProtocolError("Got data when expecting EOF")
    return None


class _CLReader:
    def __init__(self, length):
        self.remaining = length

    def __call__(self, buf):
        if self.remaining == 0:
            return EndOfMessage()
        data = _take(buf, self.remaining)
        if data is None:
            return None
        self.remaining -= len(data)
        return Data(data=data)

    def read_eof(self):
        raise RemoteProtocolError(
            "peer closed connection without sending complete message body")


class _Http10Reader:
    def __call__(self, buf):
        data = _take(buf, 1 << 62)
        return None if data is None else Data(data=data)

    def read_eof(self):
        return EndOfMessage()


class _ChunkedReader:
    def __init__(self):
        self.remaining = 0
        self.need_crlf = False
        self.in_trailers = False
        self.chunk_start = False

    def __call__(self, buf):
        if self.in_trailers:
            lines = _extract_block(buf)
            if lines is None:
                return None
            return EndOfMessage(headers=_parse_headers(lines))
        if self.need_crlf:
            if len(buf) < 2:
                if buf and buf[:1] != b"\r":
                    raise LocalProtocolError("bad chunk terminator")
                return None
            if bytes(buf[:2]) != b"\r\n":
                raise LocalProtocolError("bad chunk terminator")
            del buf[:2]
            self.need_crlf = False
        if self.remaining == 0:
            i = buf.find(b"\n")
            if i < 0:
                return None
            line = bytes(buf[:i])
            del buf[:i + 1]
            if line.endswith(b"\r"):
                line = line[:-1]
            m = _chunk_re.fullmatch(line)
            if m is None:
                raise LocalProtocolError("illegal chunk header")
            size = int(m.group(1), 16)
            if size == 0:
                self.in_trailers = True
                return self(buf)
            self.remaining = size
            self.chunk_start = True
        data = _take(buf, self.remaining)
        if data is None:
            return None
        self.remaining -= len(data)
        end = self.remaining == 0
        ev = Data(data=data, chunk_start=self.chunk_start, chunk_end=end)
        self.chunk_start = False
        if end:
            self.need_crlf = True
        return ev

    def read_eof(self):
        raise RemoteProtocolError(
            "peer closed connection without sending complete message body "
            "(incomplete chunked read)")


# --------------------------------------------------------------- Connection


class Connection:
    def __init__(self, role, max_incomplete_event_size=16 * 1024):
        if role is not CLIENT and role is not SERVER:
            raise ValueError("role must be CLIENT or SERVER")
        self.our_role = role
        self.their_role = SERVER if role is CLIENT else CLIENT
        self._cstate = _ConnectionState()
        self._max = max_incomplete_event_size
        self._buf = bytearray()
        self._closed = False
        self._request_method = None
        self.their_http_version = None
        self.client_is_waiting_for_100_continue = False
        self._writer = self._get_io(self.our_role, None, True)
        self._reader = self._get_io(self.their_role, None, False)

    # -- queries
    @property
    def states(self):
        return dict(self._cstate.states)

    @property
    def our_state(self):
        return self._cstate.states[self.our_role]

    @property
    def their_state(self):
        return self._cstate.states[self.their_role]

    @property
    def they_are_waiting_for_100_continue(self):
        return bool(self.their_role is CLIENT
                    and self.client_is_waiting_for_100_continue)

    @property
    def trailing_data(self):
        return (bytes(self._buf), self._closed)

    # -- io object selection
    def _get_io(self, role, event, writer):
        state = self._cstate.states[role]
        if state is SEND_BODY:
            kind, args = _body_framing(self._request_method, event)
            if writer:
                return {"content-length": _CLWriter, "chunked": _ChunkedWriter,
                        "http/1.0": _Http10Writer}[kind](*args)
            return {"content-length": _CLReader, "chunked": _ChunkedReader,
                    "http/1.0": _Http10Reader}[kind](*args)
        if writer:
            if role is CLIENT and state is IDLE:
                return _write_request
            if role is SERVER and state in (IDLE, SEND_RESPONSE):
                return _write_any_response
            return None
        if role is CLIENT and state is IDLE:
            return _read_request
        if role is SERVER and state in (IDLE, SEND_RESPONSE):
            return _read_response
        if state in (DONE, MUST_CLOSE, CLOSED):
            return _expect_nothing
        return None

    def _server_switch_event(self, event):
        if type(event) is InformationalResponse and event.status_code == 101:
            return _SWITCH_UPGRADE
        if type(event) is Response:
            if (_SWITCH_CONNECT in self._cstate.pending
                    and 200 <= event.status_code < 300):
                return _SWITCH_CONNECT
        return None

    def _process_event(self, role, event):
        old = dict(self._cstate.states)
        t = type(event)
        if role is CLIENT and t is Request:
            if event.method == b"CONNECT":
                self._cstate.client_switch_proposal(_SWITCH_CONNECT)
            if _comma_header(event.headers, b"upgrade"):
                self._cstate.client_switch_proposal(_SWITCH_UPGRADE)
        sse = None
        if role is SERVER:
            sse = self._server_switch_event(event)
        self._cstate.process_event(role, t, sse)
        if t is Request:
            self._request_method = event.method
        if role is self.their_role and t in (Request, Response, InformationalResponse):
            self.their_http_version = event.http_version
        if t in (Request, Response) and not _keep_alive(event):
            self._cstate.disable_keep_alive()
        if t is Request and _expect_100(event):
            self.client_is_waiting_for_100_continue = True
        if t in (InformationalResponse, Response):
            self.client_is_waiting_for_100_continue = False
        if role is CLIENT and t in (Data, EndOfMessage):
            self.client_is_waiting_for_100_continue = False
        self._respond_to_state_changes(old, event)

    def _respond_to_state_changes(self, old, event=None):
        if self.our_state != old[self.our_role]:
            self._writer = self._get_io(self.our_role, event, True)
        if self.their_state != old[self.their_role]:
            self._reader = self._get_io(self.their_role, event, False)

    def _process_error(self, role):
        old = dict(self._cstate.states)
        self._cstate.process_error(role)
        self._respond_to_state_changes(old)

    # -- receive
    def receive_data(self, data):
        if data:
            if self._closed:
                raise RuntimeError("received close, then received more data?")
            self._buf += data
        else:
            self._closed = True

    def _extract(self):
        state = self.their_state
        if state is DONE and self._buf:
            return PAUSED
        if state is MIGHT_SWITCH_PROTOCOL or state is SWITCHED_PROTOCOL:
            return PAUSED
        reader = self._reader
        if reader is None:
            raise LocalProtocolError("can't receive in state %s" % state)
        event = reader(self._buf)
        if event is None:
            if not self._buf and self._closed:
                if hasattr(reader, "read_eof"):
                    event = reader.read_eof()
                else:
                    event = ConnectionClosed()
        if event is None:
            event = NEED_DATA
        return event

    def next_event(self):
        if self.their_state is ERROR:
            raise RemoteProtocolError("Can't receive data when peer state is ERROR")
        try:
            event = self._extract()
            if event is not NEED_DATA and event is not PAUSED:
                self._process_event(self.their_role, event)
            if event is NEED_DATA:
                if len(self._buf) > self._max:
                    raise RemoteProtocolError("Receive buffer too long", 431)
                if self._closed:
                    raise RemoteProtocolError("peer unexpectedly closed connection")
            return event
        except BaseException as exc:
            self._process_error(self.their_role)
            if isinstance(exc, LocalProtocolError):
                raise _as_remote(exc) from None
            raise

    # -- send
    def send(self, event):
        parts = self.send_with_data_passthrough(event)
        if parts is None:
            return b""
        return b"".join(bytes(p) for p in parts)

    def send_with_data_passthrough(self, event):
        if self.our_state is ERROR:
            raise LocalProtocolError("Can't send data when our state is ERROR")
        try:
            if type(event) not in (Request, InformationalResponse, Response,
                                   Data, EndOfMessage, ConnectionClosed):
                raise LocalProtocolError("not an httpwire event")
            if type(event) is Response:
                event = self._clean_response(event)
            writer = self._writer
            self._process_event(self.our_role, event)
            if type(event) is ConnectionClosed:
                return None
            data = []
            if writer is None:
                raise LocalProtocolError("no writer for state")
            writer(event, data.append)
            return data
        except BaseException:
            self._process_error(self.our_role)
            raise

    def _clean_response(self, response):
        method = self._request_method
        if method == b"HEAD":
            method = b"GET"
        elif method not in (None, b"GET"):
            method = b"GET"
        kind, _ = _body_framing(method, response)
        items = list(response.headers._full_items)
        headers = response.headers
        need_close = False
        if kind in ("chunked", "http/1.0"):
            items = _set_comma_header(headers, b"content-length", [])
            headers = Headers(items)
            if self.their_http_version is None or self.their_http_version < b"1.1":
                items = _set_comma_header(headers, b"transfer-encoding", [])
                need_close = True
            else:
                items = _set_comma_header(headers, b"transfer-encoding", [b"chunked"])
            headers = Headers(items)
        if not self._cstate.keep_alive or need_close:
            conn = set(_comma_header(headers, b"connection"))
            conn.discard(b"keep-alive")
            conn.add(b"close")
            items = _set_comma_header(headers, b"connection", sorted(conn))
        return Response(status_code=response.status_code,
                        headers=[(r, v) for r, _, v in items],
                        http_version=response.http_version,
                        reason=response.reason)

    def start_next_cycle(self):
        old = dict(self._cstate.states)
        self._cstate.start_next_cycle()
        self._request_method = None
        self.their_http_version = None
        self.client_is_waiting_for_100_continue = False
        self._respond_to_state_changes(old)

    def send_failed(self):
        self._process_error(self.our_role)
