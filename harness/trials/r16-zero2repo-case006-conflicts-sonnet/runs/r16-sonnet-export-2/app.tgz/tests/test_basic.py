import os
import pytest
import optlyn
from optlyn import *
from optlyn.testing import CliRunner

R = CliRunner()


def run(cmd, args=(), **kw):
    return R.invoke(cmd, list(args), **kw)


def test_flags_env_bool():
    @command()
    @option('--flag', is_flag=True, envvar='FLG')
    @option('--shout/--no-shout', default=True, envvar='SH')
    @option('-v', '--verbose', count=True)
    def c(flag, shout, verbose):
        echo(f"{flag} {shout} {verbose}")
    assert run(c).output == "False True 0\n"
    assert run(c, ['--flag', '-vvv', '--no-shout']).output == "True False 3\n"
    assert run(c, env={'FLG': 'yes', 'SH': 'off'}).output == "True False 0\n"
    r = run(c, env={'FLG': 'bogus'})
    assert r.exit_code == 2 and 'FLG' not in r.output or '--flag' in r.output
    assert run(c, ['--', '--flag']).exit_code == 2


def test_multiple_nargs_tuple():
    @command()
    @option('--n', multiple=True, type=int)
    @option('--pair', nargs=2)
    @option('--t', type=(int, str))
    @argument('rest', nargs=-1)
    def c(n, pair, t, rest):
        echo(repr((n, pair, t, rest)))
    assert run(c).output == "((), None, None, ())\n"
    assert run(c, ['--n', '1', '--n', '2', '--pair', 'a', 'b', '--t', '3', 'x', 'r1', 'r2']).output == \
        "((1, 2), ('a', 'b'), (3, 'x'), ('r1', 'r2'))\n"
    assert run(c, ['--pair', 'a']).exit_code == 2


def test_bad_default_multiple():
    @command()
    @option('--n', multiple=True, default='abc')
    def c(n):
        pass
    r = run(c)
    assert r.exit_code == 2 and '--n' in r.output and 'iterable' in r.output


def test_choice_enum_range():
    import enum
    class Col(enum.Enum):
        RED = 1
        BLUE = 2
    @command()
    @option('--c', type=Choice(Col, case_sensitive=False))
    @option('--r', type=IntRange(1, 10, clamp=True))
    def c(c, r):
        echo(repr((c, r)))
    assert run(c, ['--c', 'red', '--r', '50']).output == "(<Col.RED: 1>, 10)\n"
    r = run(c, ['--c', 'x'])
    assert r.exit_code == 2 and '--c' in r.output
    assert 'RED' in run(c, ['--help']).output
    with pytest.raises(Exception):
        FloatRange(0, 1, min_open=True, clamp=True)


def test_default_map_env_prefix_source():
    @group()
    def g(): pass
    @g.command()
    @option('--name', default='d')
    @option('--other', default='o')
    @pass_context
    def sub(ctx, name, other):
        echo(f"{name} {other} {ctx.get_parameter_source('name').name} {ctx.get_parameter_source('nope')}")
    r = run(g, ['sub'], default_map={'sub': {'name': 'dm'}})
    assert r.output == "dm o DEFAULT_MAP None\n"
    r = run(g, ['sub'], auto_envvar_prefix='my-app', env={'MY_APP_SUB_NAME': 'envv'}, default_map={'sub': {'name': 'dm'}})
    assert r.output == "envv o ENVIRONMENT None\n"


def test_prompt_and_confirm():
    @command()
    @option('--name', prompt=True)
    @option('--pw', prompt=True, hide_input=True, confirmation_prompt=True)
    @confirmation_option()
    def c(name, pw):
        echo(f"{name} {pw}")
    r = run(c, input="bob\nsecret\nsecret\ny\n")
    assert r.exit_code == 0, r.output
    assert 'bob secret' in r.output and 'secret\nsecret' not in r.output.replace('bob secret', '')
    r = run(c, input="bob\nsecret\nsecret\nn\n")
    assert r.exit_code == 1 and 'Aborted' in r.output
    r = run(c, ['--name', 'x', '--pw', 'y', '--yes'])
    assert r.output == "x y\n"
    r = run(c, input="")
    assert r.exit_code == 1


def test_password_option():
    @command()
    @password_option()
    def c(password):
        echo(password)
    r = run(c, input="a\nb\na\na\n")
    assert 'do not match' in r.output and r.output.rstrip().endswith('a')


def test_files(tmp_path):
    @command()
    @argument('src', type=File('r'))
    @argument('dst', type=File('w'))
    def c(src, dst):
        dst.write(src.read().upper())
    with R.isolated_filesystem():
        open('in.txt', 'w').write('hi')
        r = run(c, ['in.txt', 'out.txt'])
        assert r.exit_code == 0 and open('out.txt').read() == 'HI'
        r = run(c, ['missing', 'o2'])
        assert r.exit_code == 2 and 'missing' in r.output
        assert not os.path.exists('o2')
        r = run(c, ['-', '-'], input='abc')
        assert r.output == 'ABC'


def test_path_type():
    @command()
    @argument('p', type=Path(exists=True, dir_okay=False, path_type=__import__('pathlib').Path))
    def c(p):
        echo(type(p).__name__)
    with R.isolated_filesystem():
        open('f', 'w').close()
        os.mkdir('d')
        assert run(c, ['f']).output == "PosixPath\n"
        assert run(c, ['d']).exit_code == 2
        assert run(c, ['zz']).exit_code == 2


def test_chain_and_result():
    @group(chain=True)
    def g(): pass
    @g.command()
    def a(): return 1
    @g.command()
    @argument('x')
    def b(x): return x
    @g.result_callback()
    def done(vals):
        echo(repr(vals))
    assert run(g, ['a', 'b', 'q']).output == "[1, 'q']\n"
    with pytest.raises(Exception):
        g.add_command(group()(lambda: None))
    assert g.main(['a', 'b', 'z'], standalone_mode=False) == [1, 'z']


def test_group_no_args_and_invoke_without():
    @group(invoke_without_command=True)
    @pass_context
    def g(ctx):
        echo(repr(ctx.invoked_subcommand))
    @g.command()
    def s(): echo('s')
    assert run(g).output == "None\n"
    assert run(g, ['s']).output == "s s\n".replace('s s', "'s'\ns")

    @group()
    def g2(): echo('g2')
    @g2.command()
    def x(): pass
    r = run(g2)
    assert r.exit_code == 2 and 'Usage' in r.stderr


def test_version_help_order():
    @command()
    @version_option('1.2.3', prog_name='p')
    @option('--req', required=True)
    def c(req): pass
    r = run(c, ['--version'])
    assert r.exit_code == 0 and '1.2.3' in r.stdout
    r = run(c, ['--help', '--version'])
    assert 'Usage' in r.stdout and '1.2.3' not in r.stdout
    r = run(c, ['--version', '--help'])
    assert '1.2.3' in r.stdout and 'Usage' not in r.stdout

    @command()
    @custom_version_option(lambda ctx: 'custom!')
    def d(): pass
    assert run(d, ['--version']).output == "custom!\n"


def test_deprecated():
    @command(deprecated='use other')
    @option('--old', deprecated=True)
    def c(old): echo('ran')
    r = run(c)
    assert r.exit_code == 0 and 'use other' in r.stderr and r.stdout == 'ran\n'
    assert 'old' not in r.stderr.replace('use other', '')
    r = run(c, ['--old', 'x'])
    assert '--old' in r.stderr
    with pytest.raises(Exception):
        option('--x', deprecated=True, required=True)(lambda: 0)
    with pytest.raises(Exception):
        argument('x', deprecated=True)(lambda: 0)


def test_exit_codes():
    @command()
    @argument('code', type=int)
    @pass_context
    def c(ctx, code):
        if code == 9:
            ctx.abort()
        ctx.exit(code)
        echo('no')
    assert run(c, ['0']).exit_code == 0
    assert run(c, ['5']).exit_code == 5
    assert run(c, ['9']).exit_code == 1
    assert c.main(['3'], standalone_mode=False) == 3
    with pytest.raises(UsageError):
        c.main(['zz'], standalone_mode=False)


def test_styles_echo():
    assert unstyle(style('x', fg='red', bold=True)) == 'x'
    assert style('x', fg='red') != style('x', bg='red')
    with pytest.raises(Exception):
        style('x', fg='nope')
    with pytest.raises(Exception):
        style('x', fg=(1, 2))
    assert style('x', fg=(1, 2, 3))
    @command()
    def c():
        secho('hi', fg='green')
    assert run(c).output == 'hi\n'
    assert '\x1b[' in run(c, color=True).output


def test_completion():
    @group()
    def g(): pass
    @g.command()
    @option('--name')
    @option('--hid', hidden=True)
    @argument('f', type=File())
    def sub(name, hid, f): pass
    @g.command(hidden=True)
    def secret(): pass
    r = run(g, [], env={'_G_COMPLETE': 'bash_complete', 'COMP_WORDS': 'g ', 'COMP_CWORD': '1'}, prog_name='g')
    assert r.exit_code == 0 and 'plain,sub' in r.output and 'secret' not in r.output
    r = run(g, [], env={'_G_COMPLETE': 'bash_complete', 'COMP_WORDS': 'g sub --', 'COMP_CWORD': '2'}, prog_name='g')
    assert '--name' in r.output and '--hid' not in r.output and '--help' in r.output
    r = run(g, [], env={'_G_COMPLETE': 'bash_complete', 'COMP_WORDS': 'g sub ', 'COMP_CWORD': '2'}, prog_name='g')
    assert 'file,' in r.output
    r = run(g, [], env={'_G_COMPLETE': 'zsh_source'}, prog_name='g')
    assert 'compdef' in r.output
    r = run(g, [], env={'_G_COMPLETE': 'bogus_x'}, prog_name='g')
    assert r.exit_code != 0 and r.output == ''
    r = run(g, ['--help'], env={'_OTHER_COMPLETE': 'bash_source'}, prog_name='g')
    assert 'Usage' in r.output


def test_context_obj_and_types():
    class Cfg: pass
    pass_cfg = make_pass_decorator(Cfg, ensure=True)
    @group()
    @pass_context
    def g(ctx):
        ctx.obj = Cfg()
        ctx.obj.v = 5
    @g.command()
    @pass_cfg
    def s(cfg): echo(cfg.v)
    assert run(g, ['s']).output == "5\n"
    with pytest.raises(RuntimeError):
        get_current_context()
    assert get_current_context(silent=True) is None


def test_names_and_help_misc():
    @command()
    def do_thing_command(): pass
    assert do_thing_command.name == 'do-thing'
    @command(name='Explicit', epilog='the end', options_metavar='<opts>', short_help='sh')
    @argument('x', help='the x', metavar='XX')
    @option('--num', type=int, default=3, show_default=True, envvar='NUM', show_envvar=True, help='n')
    def c(x, num):
        """Doc.\f hidden part"""
    out = run(c, ['--help']).output
    assert 'hidden part' not in out and 'Doc.' in out
    assert '<opts>' in out.split('\n')[0] and 'XX' in out and 'Positional arguments' in out
    assert 'default: 3' in out and 'NUM' in out and out.rstrip().endswith('the end')


def test_help_names_and_extra_args():
    @command(context_settings={'help_option_names': ['-h', '--hlp']})
    def c(): pass
    assert 'Usage' in run(c, ['-h']).output
    assert run(c, ['--help']).exit_code == 2

    @command(context_settings={'ignore_unknown_options': True})
    @argument('a', nargs=-1)
    def d(a): echo(repr(a))
    assert run(d, ['--foo', '-x', 'y']).output == "('--foo', '-x', 'y')\n"

    @command(context_settings={'allow_extra_args': True})
    def e(): echo('ok')
    assert run(e, ['junk']).output == 'ok\n'
    assert run(e, ['--junk']).exit_code == 2


def test_token_normalize_and_callback():
    @command(context_settings={'token_normalize_func': str.lower})
    @option('--Name', callback=lambda ctx, p, v: v.upper() if v else v)
    def c(name): echo(name)
    assert run(c, ['--NAME', 'x']).output == "X\n"

    def refuse(ctx, p, v): raise BadParameter('nope')
    @command()
    @option('--x', callback=refuse)
    def d(x): echo('ran')
    r = run(d, ['--x', '1'])
    assert r.exit_code == 2 and 'ran' not in r.output and '--x' in r.output


def test_get_app_dir(monkeypatch):
    monkeypatch.setenv('XDG_CONFIG_HOME', '/x')
    assert get_app_dir('My App') == '/x/my-app'
    monkeypatch.delenv('XDG_CONFIG_HOME')
    assert get_app_dir('My App', force_posix=True).endswith('/.my-app')


def test_wrap_and_filename():
    from optlyn.formatting import wrap_text
    assert wrap_text('a b c', 3).splitlines() == ['a b', 'c']
    assert wrap_text('') == ''
    assert format_filename(b'a\xffb') != format_filename(b'a\xfeb')
    assert format_filename('/x/y.txt', shorten=True) == 'y.txt'


def test_progress_and_pager():
    seen = []
    with progressbar(range(5), label='lbl') as bar:
        for i in bar:
            seen.append(i)
    assert seen == list(range(5))
    @command()
    def c():
        with progressbar(range(3), label='LL') as b:
            list(b)
        with progressbar(range(3), label='HH', hidden=True) as b:
            list(b)
        echo_via_pager(['a\n', 'b\n'])
    out = run(c).output
    assert out.count('LL') == 1 and 'HH' not in out and out.endswith('a\nb\n\n')


def test_lazy_group_and_collection():
    class Lazy(Group):
        loaded = []
        def list_commands(self, ctx): return ['a', 'b']
        def get_command(self, ctx, name):
            self.loaded.append(name)
            if name == 'a':
                return Command('a', callback=lambda: echo('A'), help='first. second')
    g = Lazy('lz')
    assert run(g, ['a']).output == 'A\n'
    assert Lazy.loaded == ['a']
    Lazy.loaded.clear()
    @group()
    def g1(): pass
    @g1.command()
    def x(): echo('x')
    @group()
    def g2(): pass
    @g2.command()
    def y(): echo('y')
    @group(cls=CommandCollection, sources=[g1, g2])
    def col(): pass
    assert run(col, ['y']).output == 'y\n'
    assert 'x' in run(col, ['--help']).output and 'y' in run(col, ['--help']).output
