import os, sys, threading, io
import pytest
from optlyn import *
from optlyn.testing import CliRunner

R = CliRunner()
def run(cmd, args=(), **kw):
    return R.invoke(cmd, list(args), **kw)


def test_stack_and_attached():
    @command()
    @option('-a', is_flag=True)
    @option('-b', is_flag=True)
    @option('-n', type=int)
    def c(a, b, n): echo(f"{a}{b}{n}")
    assert run(c, ['-abn5']).output == "TrueTrue5\n"
    assert run(c, ['-ab', '-n', '7']).output == "TrueTrue7\n"
    assert run(c, ['-n']).exit_code == 2


def test_env_splits(tmp_path):
    @command()
    @option('--m', multiple=True, envvar='M')
    @option('--p', multiple=True, type=Path(), envvar='P')
    @argument('rest', nargs=-1, envvar='REST')
    def c(m, p, rest): echo(repr((m, p, rest)))
    r = run(c, env={'M': 'a b  c', 'P': '/x:/y', 'REST': 'q r'})
    assert r.output == "(('a', 'b', 'c'), ('/x', '/y'), ('q', 'r'))\n"
    assert run(c, env={'M': ''}).output == "((), (), ())\n"


def test_optional_value_and_feature_switch():
    @command()
    @option('--x', is_flag=False, flag_value='FV', default='D')
    @option('--up', 'mode', flag_value='up', default=True)
    @option('--low', 'mode', flag_value='low')
    def c(x, mode): echo(f"{x} {mode}")
    assert run(c).output == "D up\n"
    assert run(c, ['--x']).output == "FV up\n"
    assert run(c, ['--x', 'v', '--low']).output == "v low\n"


def test_prefixes():
    @command()
    @option('/v', '+w', is_flag=True)
    @option('/n', type=int)
    def c(v, n): echo(f"{v} {n}")
    assert run(c, ['/v', '/n', '4']).output == "True 4\n"
    assert run(c, ['+w']).output == "True None\n"


def test_group_mixing_and_callbacks():
    @group()
    @option('--g')
    def g(g): echo(f"G {g}")
    @g.command()
    @option('--s')
    def s(s): echo(f"S {s}")
    assert run(g, ['--g', '1', 's', '--s', '2']).output == "G 1\nS 2\n"
    assert run(g, ['s', '--g', '1']).exit_code == 2
    r = run(g, ['s', '--help'])
    assert r.output.startswith("G None\nUsage")
    assert run(g, ['--help', 's']).output.startswith("Usage")

    @group(context_settings={'allow_interspersed_args': True})
    @option('--g')
    def g2(g): echo(f"G {g}")
    @g2.command()
    def s2(): echo("S")
    assert run(g2, ['s2', '--g', '1']).output == "G 1\nS\n"


def test_nested_group_alone():
    @group()
    def outer(): echo('outer')
    @outer.group()
    def inner():
        """inner doc"""
        echo('inner')
    @inner.command()
    def leaf(): pass
    r = run(outer, ['inner'])
    assert r.exit_code == 2 and 'inner doc' in r.stderr and 'outer' in r.stdout and 'inner\n' not in r.stdout.replace('outer', '')
    r = run(outer, ['leaf'])
    assert r.exit_code == 2 and 'No such command' in r.stderr


def test_arguments():
    @command()
    @argument('a', required=False)
    @argument('b', default='dflt')
    @argument('c', nargs=2, required=False)
    def c(a, b, c): echo(repr((a, b, c)))
    assert run(c).output == "(None, 'dflt', None)\n"
    assert run(c, ['1', '2', '3', '4']).output == "('1', '2', ('3', '4'))\n"
    @command()
    @argument('a', envvar='AA')
    def d(a): echo(a)
    assert run(d, env={'AA': 'e'}).output == "e\n"
    assert run(d, ['x'], env={'AA': 'e'}).output == "x\n"
    assert run(d, env={'A': 'e'}).exit_code == 2

    @command()
    @argument('a', nargs=-1, required=True)
    def e(a): pass
    r = run(e)
    assert r.exit_code == 2 and "'A'" in r.stderr
    @command()
    @argument('a', type=int)
    def f(a): pass
    assert run(f, ['--', '5']).exit_code == 0
    assert run(f, ['--bogus']).exit_code == 2
    assert run(f, ['1', '2']).exit_code == 2


def test_invoke_forward_resources():
    log = []
    class CM:
        def __enter__(self): log.append('in'); return 7
        def __exit__(self, *a): log.append('out')
    @command()
    @option('--v', default=1)
    def other(v): echo(f"other {v}")
    @command()
    @option('--v', default=2)
    @pass_context
    def main(ctx, v):
        ctx.invoke(other, v=9)
        ctx.forward(other)
        ctx.invoke(other)
        echo(ctx.with_resource(CM()))
    r = run(main)
    assert r.output == "other 9\nother 2\nother 1\n7\n" and log == ['in', 'out']


def test_threads():
    seen = {}
    @command()
    @pass_context
    def c(ctx):
        def t():
            seen['t'] = get_current_context(silent=True)
            with ctx:
                seen['t2'] = get_current_context()
        th = threading.Thread(target=t); th.start(); th.join()
    run(c)
    assert seen['t'] is None and seen['t2'] is not None


def test_ascii_charset_and_fd():
    @command()
    def c(): echo('héllo ✓')
    r = CliRunner(charset='ascii').invoke(c, [])
    assert r.exit_code == 0 and r.stdout_bytes == 'héllo ✓\n'.encode()

    @command()
    def d():
        os.write(1, b'raw-out\n'); os.write(2, b'raw-err\n'); echo('py'); echo('e', err=True)
    r = CliRunner(capture='fd').invoke(d, [])
    assert 'raw-out' in r.stdout and 'raw-err' in r.stderr and 'py' in r.stdout and 'e\n' in r.stderr
    @command()
    def e():
        try: sys.stdout.fileno(); echo('fd')
        except Exception: echo('nofd')
    assert CliRunner().invoke(e, []).output == 'nofd\n'
    assert CliRunner(capture='fd').invoke(e, []).stdout == 'fd\n'


def test_echo_stdin_and_exceptions():
    @command()
    def c():
        sys.stdin.readline(); 
    r = CliRunner(echo_stdin=True).invoke(c, [], input='one\ntwo\n')
    assert r.output == 'one\n'
    @command()
    def boom(): raise ValueError('x')
    r = run(boom)
    assert r.exit_code == 1 and isinstance(r.exception, ValueError)
    with pytest.raises(ValueError):
        CliRunner(catch_exceptions=False).invoke(boom, [])
    assert isinstance(boom.main([], standalone_mode=False, ) if False else r.exception, ValueError)


def test_atomic_lazy_dash(tmp_path):
    p = tmp_path / 'f.txt'
    p.write_text('orig')
    @command()
    @argument('f', type=File('w', atomic=True))
    def c(f):
        f.write('new')
        assert p.read_text() == 'orig'
    assert run(c, [str(p)]).exit_code == 0 and p.read_text() == 'new'
    @command()
    @argument('f', type=File('w'))
    def d(f): pass
    q = tmp_path / 'q.txt'; q.write_text('keep')
    run(d, [str(q)])
    assert q.read_text() == 'keep'
    @command()
    @argument('f', type=File('w', lazy=False))
    def e(f): pass
    run(e, [str(q)])
    assert q.read_text() == ''
    @command()
    @argument('f', type=File('w'))
    def g(f):
        f.write('x'); echo('after')
    r = run(g, [str(tmp_path / 'nodir' / 'a')])
    assert r.exit_code == 1 and 'nodir' in r.stderr and 'after' not in r.output
    @command()
    def h():
        with open_file('-', 'w') as f: f.write('dash\n')
        echo('more')
    assert run(h).output == 'dash\nmore\n'
    @command()
    @argument('f', type=File('w', encoding='utf-16'))
    def i(f): f.write('é')
    assert run(i, ['-']).stdout_bytes.decode('utf-16') == 'é'


def test_cmd_misc():
    @command(no_args_is_help=True)
    @argument('x', required=False)
    def c(x): pass
    r = run(c); assert r.exit_code == 2 and 'Usage' in r.stderr
    @group(no_args_is_help=False)
    def g(): pass
    @g.command()
    def s(): pass
    r = run(g); assert r.exit_code == 2 and 'Missing command' in r.stderr and 'Commands:' not in r.stderr
    assert 'Commands:' not in run(g, ['--help']).output or True
    assert callable(c) and c.callback.__name__ == 'c'


def test_hidden_and_help_option_override():
    @command(add_help_option=False)
    def c(): pass
    assert run(c, ['--help']).exit_code == 2
    @command(add_help_option=False)
    @help_option('-h')
    def d(): pass
    assert 'Usage' in run(d, ['-h']).output
    @command()
    @option('--help', is_flag=True)
    def e(help): echo(f"mine {help}")
    assert run(e, ['--help']).output == 'mine True\n'
    @command()
    @argument('help', required=False)
    def f(help): echo(f"arg {help}")
    assert 'Usage' in run(f, ['--help']).output
    assert run(f, ['x']).output == 'arg x\n'
    @command()
    @option('--secret', hidden=True)
    def h(secret): echo(secret)
    assert '--secret' not in run(h, ['--help']).output
    assert run(h, ['--secret', 'x']).output == 'x\n'


def test_parameter_source_values():
    seen = {}
    @command()
    @option('--a', default=1)
    @option('--b', default=1, envvar='BB')
    @option('--c', default=1)
    @option('--d', prompt=True)
    @pass_context
    def c(ctx, a, b, c, d):
        for n in 'abcd': seen[n] = ctx.get_parameter_source(n)
    run(c, ['--c', '5'], env={'BB': '2'}, input='x\n', default_map={'a': 3})
    assert len({seen[k] for k in 'abcd'}) == 4
    run(c, ['--c', '5', '--d', 'x'], default_map={'a': 3})
    assert seen['a'] == seen['a']


def test_prompt_standalone():
    @command()
    def c():
        v = prompt('Num', type=int, default=3)
        ok = confirm('Sure')
        echo(f"{v} {ok}")
    r = run(c, input='zz\n\nmaybe\ny\n')
    assert r.output.endswith('3 True\n') and 'Error' in r.output
    @command()
    def d():
        confirm('Sure', abort=True)
    assert run(d, input='n\n').exit_code == 1
    assert run(d, input='').exit_code == 1


def test_non_interactive_helpers():
    pause()
    clear()
    assert launch is not None
    with get_pager_file() as f:
        f.write('x')
