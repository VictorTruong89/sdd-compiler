"""Declaration decorators."""
import inspect
from functools import update_wrapper

from ._context_stack import get_current_context
from .core import Argument, Command, Group, Option, Parameter
from .exceptions import DeclarationError
from .utils import echo


def _named(param_decls, name):
    """Give eager built-in flags a private destination so they never collide
    with an author parameter that is merely called ``help`` or ``version``."""
    if any(d.isidentifier() for d in param_decls):
        return param_decls
    return (*param_decls, name)


def pass_context(f):
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)
    return update_wrapper(new_func, f)


def pass_obj(f):
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)
    return update_wrapper(new_func, f)


def make_pass_decorator(object_type, ensure=False):
    def decorator(f):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError("Managed to invoke callback without a context object of type "
                                   "{!r} existing.".format(object_type.__name__))
            return ctx.invoke(f, obj, *args, **kwargs)
        return update_wrapper(new_func, f)
    return decorator


def _make_name(f):
    name = f.__name__.lower().replace("_", "-")
    left, sep, suffix = name.rpartition("-")
    if sep and suffix in {"command", "cmd", "group", "grp"}:
        name = left
    return name


def command(name=None, cls=None, **attrs):
    """Turn a function into a command."""
    if cls is None:
        cls = Command
    if callable(name) and not isinstance(name, str):
        func, name = name, None
        return command(name, cls, **attrs)(func)

    def decorator(f):
        if isinstance(f, Command):
            raise TypeError("Attempted to convert a callback into a command twice.")
        try:
            params = f.__optlyn_params__
        except AttributeError:
            params = []
        else:
            del f.__optlyn_params__
        params.reverse()
        a = dict(attrs)
        if a.get("help") is None:
            a["help"] = inspect.getdoc(f)
        else:
            a["help"] = inspect.cleandoc(a["help"])
        cmd_name = name or _make_name(f)
        cmd = cls(name=cmd_name, callback=f, params=params, **a)
        cmd.__doc__ = f.__doc__
        return cmd
    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a group."""
    if cls is None:
        cls = Group
    if callable(name) and not isinstance(name, str):
        return command(None, cls, **attrs)(name)
    return command(name, cls, **attrs)


def _param_memo(f, param):
    if isinstance(f, Command):
        f.params.append(param)
    else:
        if not hasattr(f, "__optlyn_params__"):
            f.__optlyn_params__ = []
        f.__optlyn_params__.append(param)


def argument(*param_decls, cls=None, **attrs):
    if cls is None:
        cls = Argument

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f
    return decorator


def option(*param_decls, cls=None, **attrs):
    if cls is None:
        cls = Option

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f
    return decorator


def confirmation_option(*param_decls, **kwargs):
    def callback(ctx, param, value):
        if not value:
            ctx.abort()

    if not param_decls:
        param_decls = ("--yes",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("callback", callback)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")
    return option(*param_decls, **kwargs)


def password_option(*param_decls, **kwargs):
    if not param_decls:
        param_decls = ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("hide_input", True)
    return option(*param_decls, **kwargs)


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None,
                   **kwargs):
    if message is None:
        message = "%(prog)s, version %(version)s"
    if version is None and package_name is None:
        frame = inspect.currentframe()
        f_back = frame.f_back if frame else None
        f_globals = f_back.f_globals if f_back else None
        del frame
        if f_globals is not None:
            package_name = f_globals.get("__name__")
            if package_name == "__main__":
                package_name = f_globals.get("__package__")
            if package_name:
                package_name = package_name.partition(".")[0]

    def callback(ctx, param, value):
        nonlocal prog_name, version
        if not value or ctx.resilient_parsing:
            return
        if prog_name is None:
            prog_name = ctx.find_root().info_name
        if version is None and package_name is not None:
            import importlib.metadata as md
            try:
                version = md.version(package_name)
            except md.PackageNotFoundError:
                try:
                    dists = md.packages_distributions().get(package_name)
                    if dists:
                        version = md.version(dists[0])
                except Exception:
                    pass
                if version is None:
                    raise RuntimeError("{!r} is not installed. Try passing 'package_name' "
                                       "instead.".format(package_name)) from None
        if version is None:
            raise RuntimeError("Could not determine the version for {!r} automatically.".format(
                package_name))
        echo(message % {"prog": prog_name, "package": package_name, "version": version},
             color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*_named(param_decls, "__optlyn_version"), **kwargs)


def custom_version_option(callback, *param_decls, **kwargs):
    def cb(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(callback(ctx), color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = cb
    return option(*_named(param_decls, "__optlyn_version"), **kwargs)


def help_option(*param_decls, **kwargs):
    def show_help(ctx, param, value):
        if value and not ctx.resilient_parsing:
            echo(ctx.get_help(), color=ctx.color)
            ctx.exit()

    if not param_decls:
        param_decls = ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", show_help)
    return option(*_named(param_decls, "__optlyn_help"), **kwargs)
