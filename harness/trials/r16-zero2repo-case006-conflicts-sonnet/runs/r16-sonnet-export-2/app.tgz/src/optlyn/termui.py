"""Interactive terminal helpers."""
import contextlib
import getpass
import inspect
import io
import itertools
import math
import os
import shutil
import subprocess
import sys
import tempfile
import time

from . import utils as _utils
from ._context_stack import resolve_color_default
from .exceptions import Abort, UsageError, OptlynException
from .formatting import strip_ansi
from .utils import echo, isatty, style

visible_prompt_func = input
hidden_prompt_func = getpass.getpass
_getchar = None


def _format_default(default):
    if hasattr(default, "name") and isinstance(getattr(default, "name"), str) and hasattr(default, "read"):
        return default.name
    return default


def _build_prompt(text, suffix, show_default=False, default=None, show_choices=True, type=None):
    from .types import Choice
    prompt = text
    if type is not None and show_choices and isinstance(type, Choice):
        prompt += " ({})".format(", ".join(map(str, type.choices_as_str)))
    if default is not None and show_default:
        prompt = "{} [{}]".format(prompt, _format_default(default))
    return prompt + suffix


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False, show_choices=True):
    """Prompt for a value and return it converted."""
    from .types import convert_type

    def prompt_func(text):
        f = hidden_prompt_func if hide_input else visible_prompt_func
        try:
            echo(text.rstrip(" "), nl=False, err=err)
            return f(" ")
        except (KeyboardInterrupt, EOFError):
            if hide_input:
                echo(None, err=err)
            raise Abort() from None

    if value_proc is None:
        value_proc = convert_type(type, default)
    prompt_text = _build_prompt(text, prompt_suffix, show_default, default, show_choices, type)
    if confirmation_prompt:
        if confirmation_prompt is True:
            confirmation_prompt = "Repeat for confirmation"
        confirmation_prompt = _build_prompt(confirmation_prompt, prompt_suffix)
    while True:
        while True:
            value = prompt_func(prompt_text)
            if value:
                break
            elif default is not None:
                value = default
                break
        try:
            result = value_proc(value)
        except UsageError as e:
            if hide_input:
                echo("Error: The value you entered was invalid.", err=err)
            else:
                echo("Error: {}".format(e.message), err=err)
            continue
        if not confirmation_prompt:
            return result
        while True:
            value2 = prompt_func(confirmation_prompt)
            is_empty = not value and not value2
            if value2 or is_empty:
                break
        if value == value2:
            return result
        echo("Error: The two entered values do not match.", err=err)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    """Ask a yes/no question."""
    prompt_text = _build_prompt(text, prompt_suffix, show_default,
                                "y/n" if default is None else ("Y/n" if default else "y/N"))
    while True:
        try:
            echo(prompt_text.rstrip(" "), nl=False, err=err)
            value = visible_prompt_func(" ").lower().strip()
        except (KeyboardInterrupt, EOFError):
            raise Abort() from None
        if value in ("y", "yes"):
            rv = True
        elif value in ("n", "no"):
            rv = False
        elif default is not None and value == "":
            rv = default
        else:
            echo("Error: invalid input", err=err)
            continue
        break
    if abort and not rv:
        raise Abort()
    return rv


def is_interactive():
    return isatty(sys.stdin) or isatty(sys.stdout)


# ----------------------------------------------------------------- pager

class _PagerFile:
    def __init__(self, write, flush=None, close=None):
        self._write = write
        self._flush = flush
        self._close = close

    def write(self, text):
        if not isinstance(text, str):
            text = str(text)
        self._write(text)
        return len(text)

    def writelines(self, lines):
        for line in lines:
            self.write(line)

    def flush(self):
        if self._flush:
            self._flush()

    def isatty(self):
        return False

    def __enter__(self):
        return self

    def __exit__(self, *a):
        pass


@contextlib.contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream that feeds a pager when interactive."""
    stdout = sys.stdout
    color = resolve_color_default(color)
    cmd = (os.environ.get("PAGER") or "").strip()
    if not is_interactive() or not cmd:
        if cmd == "" and is_interactive():
            less = shutil.which("less")
            cmd = less or ""
        if not is_interactive() or not cmd:
            def w(text):
                echo(text, file=stdout, nl=False, color=color)
            yield _PagerFile(w, lambda: stdout.flush())
            return
    env = dict(os.environ)
    if color and "less" in os.path.basename(cmd.split()[0] if cmd.split() else ""):
        env.setdefault("LESS", "-R")
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, env=env)
    broken = []

    def w(text):
        if broken:
            return
        if not color:
            text = strip_ansi(text)
        try:
            proc.stdin.write(text.encode("utf-8", "replace"))
            proc.stdin.flush()
        except (OSError, ValueError):
            broken.append(True)

    try:
        stdout.flush()
    except Exception:
        pass
    try:
        yield _PagerFile(w, None)
    finally:
        try:
            proc.stdin.close()
        except OSError:
            pass
        while True:
            try:
                proc.wait()
                break
            except KeyboardInterrupt:
                pass


def echo_via_pager(text_or_generator, color=None):
    if callable(text_or_generator):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, (str, bytes)):
        it = [text_or_generator]
    else:
        it = iter(text_or_generator)
    chunks = (el if isinstance(el, str) else str(el) for el in it)
    with get_pager_file(color=color) as f:
        for chunk in itertools.chain(chunks, ["\n"]):
            f.write(chunk)
            f.flush()


# ----------------------------------------------------------- progress bar

class ProgressBar:
    def __init__(self, iterable, length=None, fill_char="#", empty_char="-",
                 bar_template="%(label)s  [%(bar)s]  %(info)s", info_sep="  ",
                 show_eta=True, show_percent=None, show_pos=False, item_show_func=None,
                 label=None, file=None, color=None, update_min_steps=1, width=36, hidden=False):
        self.fill_char = fill_char
        self.empty_char = empty_char
        self.bar_template = bar_template
        self.info_sep = info_sep
        self.show_eta = show_eta
        self.show_percent = show_percent
        self.show_pos = show_pos
        self.item_show_func = item_show_func
        self.label = label or ""
        self.file = file
        self.color = color
        self.update_min_steps = update_min_steps
        self._completed_intervals = 0
        self.width = width
        self.hidden = hidden
        if length is None:
            try:
                length = len(iterable)
            except (TypeError, AttributeError):
                try:
                    length = operator_length_hint(iterable)
                except Exception:
                    length = None
        if iterable is None:
            if length is None:
                raise TypeError("iterable or length is required")
            iterable = range(length)
        self.iter = iter(iterable)
        self.length = length
        self.pos = 0
        self.start = time.time()
        self.finished = False
        self.entered = False
        self.current_item = None
        self._last_line = None
        self._printed = False

    def _stream(self):
        return self.file if self.file is not None else sys.stdout

    @property
    def is_tty(self):
        return isatty(self._stream())

    def __enter__(self):
        self.entered = True
        self.render_progress()
        return self

    def __exit__(self, *a):
        self.render_finish()

    def __iter__(self):
        if not self.entered:
            raise RuntimeError("You need to use progress bars in a with block.")
        return self._generator()

    def __next__(self):
        return next(iter(self))

    def _generator(self):
        for rv in self.iter:
            self.current_item = rv
            yield rv
            self.update(1)
        self.finish()
        self.render_progress()

    @property
    def pct(self):
        if self.finished:
            return 1.0
        if not self.length:
            return 0.0
        return min(self.pos / self.length, 1.0)

    @property
    def eta(self):
        if self.length is not None and not self.finished and self.pos > 0:
            elapsed = time.time() - self.start
            return elapsed / self.pos * (self.length - self.pos)
        return 0.0

    def format_eta(self):
        if self.length is None or self.finished or self.pos <= 0:
            return ""
        t = int(self.eta)
        seconds = t % 60
        t //= 60
        minutes = t % 60
        t //= 60
        hours = t % 24
        t //= 24
        if t > 0:
            return "{}d {:02}:{:02}:{:02}".format(t, hours, minutes, seconds)
        return "{:02}:{:02}:{:02}".format(hours, minutes, seconds)

    def format_pos(self):
        pos = str(self.pos)
        if self.length is not None:
            pos += "/{}".format(self.length)
        return pos

    def format_pct(self):
        return "{:4}%".format(int(self.pct * 100))[1:]

    def format_bar(self):
        if self.length is not None:
            bar_length = int(self.pct * self.width)
            bar = self.fill_char * bar_length + self.empty_char * (self.width - bar_length)
        else:
            bar = self.empty_char * self.width
        return bar

    def format_progress_line(self):
        show_percent = self.show_percent
        info_bits = []
        if self.length is not None and show_percent is None:
            show_percent = not self.show_pos
        if self.show_pos:
            info_bits.append(self.format_pos())
        if show_percent:
            info_bits.append(self.format_pct())
        if self.show_eta and self.length is not None and not self.finished:
            eta = self.format_eta()
            if eta:
                info_bits.append(eta)
        if self.item_show_func is not None:
            item_info = self.item_show_func(self.current_item)
            if item_info is not None:
                info_bits.append(item_info)
        return (self.bar_template % {
            "label": self.label, "bar": self.format_bar(),
            "info": self.info_sep.join(info_bits)}).rstrip()

    def render_progress(self):
        if self.hidden:
            return
        stream = self._stream()
        if not self.is_tty:
            if self._last_line != self.label:
                self._last_line = self.label
                if self.label:
                    echo(self.label, file=stream, color=self.color)
            return
        line = self.format_progress_line()
        if line == self._last_line:
            return
        self._last_line = line
        echo("\r" + line, file=stream, nl=False, color=self.color)
        self._printed = True

    def update(self, n_steps=1, current_item=None):
        self.pos += n_steps
        if current_item is not None:
            self.current_item = current_item
        if self.length is not None and self.pos >= self.length:
            self.finished = True
        self.render_progress()

    def finish(self):
        self.pos = self.length if self.length is not None else self.pos
        self.finished = True

    def render_finish(self):
        if self.hidden or not self.is_tty:
            return
        if self._printed:
            echo(file=self._stream())


def operator_length_hint(obj):
    import operator
    return operator.length_hint(obj, None)


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    """Context manager yielding a progress bar."""
    return ProgressBar(iterable, length=length, label=label, hidden=hidden, **options)


# ------------------------------------------------------------ misc helpers

def getchar(echo=False):
    """Read one character from the controlling terminal."""
    global _getchar
    if _getchar is not None:
        return _getchar(echo)
    import termios
    import tty
    f = None
    if sys.stdin is not None and isatty(sys.stdin):
        try:
            fd = sys.stdin.fileno()
        except Exception:
            fd = None
        if fd is None:
            fd = os.open("/dev/tty", os.O_RDONLY)
            f = os.fdopen(fd, "rb", buffering=0)
    else:
        fd = os.open("/dev/tty", os.O_RDONLY)
        f = os.fdopen(fd, "rb", buffering=0)
    ch = ""
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 32).decode("utf-8", "replace")
            if echo and isatty(sys.stdout):
                sys.stdout.write(ch)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
            sys.stdout.flush()
    finally:
        if f is not None:
            f.close()
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04" or ch == "":
        raise EOFError()
    return ch


def pause(info=None, err=False):
    if not is_interactive():
        return
    if info is None:
        info = "Press any key to continue..."
    try:
        if info:
            echo(info, nl=False, err=err)
        try:
            getchar()
        except (KeyboardInterrupt, EOFError):
            pass
    finally:
        if info:
            echo(err=err)


def clear():
    if not isatty(sys.stdout):
        return
    echo("\033[2J\033[1;1H", nl=False)


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Launch an editor on text (returns saved text) or on a file."""
    def get_editor():
        if editor is not None:
            return editor
        for key in ("VISUAL", "EDITOR"):
            rv = os.environ.get(key)
            if rv:
                return rv
        for e in ("sensible-editor", "vim", "nano"):
            if shutil.which(e) is not None:
                return e
        return "vi"

    def edit_file(fn):
        ed = get_editor()
        environ = None
        if env:
            environ = os.environ.copy()
            environ.update(env)
        try:
            c = subprocess.Popen('{} "{}"'.format(ed, fn), env=environ, shell=True)
            code = c.wait()
            if code != 0:
                raise OptlynException("{}: Editing failed".format(ed))
        except OSError as e:
            raise OptlynException("{}: Editing failed: {}".format(ed, e))

    if filename is not None:
        edit_file(filename)
        return None
    if not text:
        data = b""
    elif isinstance(text, (bytes, bytearray)):
        data = bytes(text)
    else:
        if not text.endswith("\n"):
            text += "\n"
        data = text.encode("utf-8")
    fd, name = tempfile.mkstemp(prefix="editor-", suffix=extension)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        old = time.time() - 10
        os.utime(name, (old, old))
        timestamp = os.path.getmtime(name)
        edit_file(name)
        if require_save and os.path.getmtime(name) == timestamp:
            return None
        with open(name, "rb") as f:
            rv = f.read()
        if isinstance(text, (bytes, bytearray)):
            return rv
        return rv.decode("utf-8-sig").replace("\r\n", "\n")
    finally:
        os.unlink(name)


def launch(url, wait=False, locate=False):
    """Open url/path with the default application."""
    from urllib.parse import unquote

    def _unquote_file(u):
        if u.startswith("file://"):
            u = unquote(u[7:])
        return u

    url = os.fspath(url) if not isinstance(url, str) else url
    if locate:
        url = os.path.dirname(_unquote_file(url)) or "."
    else:
        url = _unquote_file(url)
    try:
        c = subprocess.Popen(["xdg-open", url])
        if wait:
            return c.wait()
        return 0
    except OSError:
        if url.startswith(("http://", "https://")) and not locate and not wait:
            import webbrowser
            return 0 if webbrowser.open(url) else 1
        return 1
