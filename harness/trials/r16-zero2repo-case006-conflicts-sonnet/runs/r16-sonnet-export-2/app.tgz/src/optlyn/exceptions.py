"""Exception classes. # spec: N-000792 N-000794 N-000795"""
import sys


class DeclarationError(TypeError, ValueError, RuntimeError):
    """Raised when a declaration (option, argument, type, group) is invalid."""


class OptlynException(Exception):
    exit_code = 1

    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def format_message(self):
        return self.message

    def __str__(self):
        return self.message

    def show(self, file=None):
        from .utils import echo, get_text_stderr
        if file is None:
            file = get_text_stderr()
        echo("Error: " + self.format_message(), file=file)


class UsageError(OptlynException):
    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.ctx = ctx
        self.cmd = self.ctx.command if self.ctx else None

    def show(self, file=None):
        from .utils import echo, get_text_stderr
        if file is None:
            file = get_text_stderr()
        color = None
        hint = ""
        if (self.ctx is not None and self.ctx.command.get_help_option(self.ctx) is not None):
            hint = "Try '{} {}' for help.\n".format(
                self.ctx.command_path, self.ctx.help_option_names[0])
        if self.ctx is not None:
            color = self.ctx.color
            echo(self.ctx.get_usage() + "\n" + hint, file=file, color=color)
        echo("Error: " + self.format_message(), file=file, color=color)


class NoArgsIsHelpError(UsageError):
    """Help shown because of incorrect usage (exit 2, standard error)."""

    def __init__(self, ctx):
        super().__init__(ctx.get_help(), ctx=ctx)

    def show(self, file=None):
        from .utils import echo, get_text_stderr
        if file is None:
            file = get_text_stderr()
        echo(self.format_message(), file=file, color=self.ctx.color if self.ctx else None)


def _join_param_hints(param_hint):
    if param_hint is not None and not isinstance(param_hint, str):
        return " / ".join(repr(x) for x in param_hint)
    return param_hint


class BadParameter(UsageError):
    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        if self.param_hint is not None:
            param_hint = self.param_hint
        elif self.param is not None:
            param_hint = self.param.get_error_hint(self.ctx)
        else:
            return "Invalid value: " + self.message
        return "Invalid value for {}: {}".format(_join_param_hints(param_hint), self.message)


class MissingParameter(BadParameter):
    def __init__(self, message=None, ctx=None, param=None, param_hint=None, param_type=None):
        super().__init__(message or "", ctx, param, param_hint)
        self.param_type = param_type

    def format_message(self):
        param_hint = None
        if self.param_hint is not None:
            param_hint = self.param_hint
        elif self.param is not None:
            param_hint = self.param.get_error_hint(self.ctx)
        param_hint = _join_param_hints(param_hint)
        param_type = self.param_type
        if param_type is None and self.param is not None:
            param_type = self.param.param_type_name
        msg = self.message
        if self.param is not None:
            extra = self.param.type.get_missing_message(self.param)
            if extra:
                msg = "{}. {}".format(msg, extra) if msg else extra
        hint_str = " " + param_hint if param_hint else ""
        return "Missing {}{}.{}{}".format(param_type, hint_str, " " if msg else "", msg or "")

    __str__ = format_message


class NoSuchOption(UsageError):
    def __init__(self, option_name, message=None, possibilities=None, ctx=None):
        if message is None:
            message = "No such option: {}".format(option_name)
        super().__init__(message, ctx)
        self.option_name = option_name
        self.possibilities = possibilities

    def format_message(self):
        if not self.possibilities:
            return self.message
        poss = sorted(self.possibilities)
        if len(poss) == 1:
            return "{} Did you mean {}?".format(self.message, poss[0])
        return "{} (Possible options: {})".format(self.message, ", ".join(poss))


class BadOptionUsage(UsageError):
    def __init__(self, option_name, message, ctx=None):
        super().__init__(message, ctx)
        self.option_name = option_name


class BadArgumentUsage(UsageError):
    pass


class FileError(OptlynException):
    def __init__(self, filename, hint=None):
        if hint is None:
            hint = "unknown error"
        super().__init__(hint)
        self.ui_filename = filename if isinstance(filename, str) else str(filename)
        self.filename = filename

    def format_message(self):
        return "Could not open file {!r}: {}".format(self.ui_filename, self.message)


class Abort(RuntimeError):
    """Abort the program (exit status 1)."""


class Exit(RuntimeError):
    """Clean stop carrying an exit status."""

    def __init__(self, code=0):
        self.exit_code = code
        super().__init__(code)
