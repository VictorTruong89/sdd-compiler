"""In-process runner."""
import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile

from . import formatting, termui, utils


class EchoingStdin:
    def __init__(self, input, output):
        self._input = input
        self._output = output
        self._paused = False

    def __getattr__(self, x):
        return getattr(self._input, x)

    def _echo(self, rv):
        if not self._paused:
            self._output.write(rv)
        return rv

    def read(self, n=-1):
        return self._echo(self._input.read(n))

    def read1(self, n=-1):
        return self._echo(self._input.read1(n))

    def readline(self, n=-1):
        return self._echo(self._input.readline(n))

    def readlines(self):
        return [self._echo(x) for x in self._input.readlines()]

    def __iter__(self):
        return iter(self._echo(x) for x in self._input)

    def __repr__(self):
        return repr(self._input)


@contextlib.contextmanager
def _pause_echo(stream):
    if stream is None:
        yield
    else:
        stream._paused = True
        yield
        stream._paused = False


class _NamedTextIOWrapper(io.TextIOWrapper):
    def __init__(self, buffer, name=None, mode=None, **kwargs):
        super().__init__(buffer, **kwargs)
        self._name = name
        self._mode = mode

    @property
    def name(self):
        return self._name

    @property
    def mode(self):
        return self._mode


class _BytesIOCopy(io.BytesIO):
    def __init__(self, copy_to, fd=None):
        super().__init__()
        self.copy_to = copy_to
        self._fd = fd

    def flush(self):
        super().flush()
        self.copy_to.flush()

    def write(self, b):
        self.copy_to.write(b)
        return super().write(b)

    def fileno(self):
        if self._fd is None:
            return super().fileno()
        return self._fd


def _make_input_stream(input, charset):
    if hasattr(input, "read"):
        rv = input
        if isinstance(rv.read(0), str):
            return io.BytesIO(rv.read().encode(charset))
        return rv
    if input is None:
        input = b""
    elif isinstance(input, str):
        input = input.encode(charset)
    return io.BytesIO(input)


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value, exit_code,
                 exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    def _dec(self, b):
        try:
            s = b.decode(self.runner.charset)
        except UnicodeDecodeError:
            s = b.decode("utf-8", "replace")
        return s.replace("\r\n", "\n")

    @property
    def output(self):
        return self._dec(self.output_bytes)

    @property
    def stdout(self):
        return self._dec(self.stdout_bytes)

    @property
    def stderr(self):
        return self._dec(self.stderr_bytes)

    def __repr__(self):
        exc = repr(self.exception) if self.exception else "okay"
        return "<Result {}>".format(exc)


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        self.charset = charset
        self.env = env or {}
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def make_env(self, overrides=None):
        rv = dict(self.env)
        if overrides:
            rv.update(overrides)
        return rv

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        bytes_input = _make_input_stream(input, self.charset)
        echo_input = None
        old_stdin, old_stdout, old_stderr = sys.stdin, sys.stdout, sys.stderr
        old_forced_width = formatting.FORCED_WIDTH
        formatting.FORCED_WIDTH = 80
        env = self.make_env(env)
        output = io.BytesIO()
        fd_mode = self.capture == "fd"
        bytes_output = _BytesIOCopy(output, fd=1 if fd_mode else None)
        bytes_error = _BytesIOCopy(output, fd=2 if fd_mode else None)
        if self.echo_stdin:
            bytes_input = echo_input = EchoingStdin(bytes_input, bytes_output)
        text_input = _NamedTextIOWrapper(bytes_input, encoding=self.charset, name="<stdin>", mode="r")
        if self.echo_stdin:
            text_input._CHUNK_SIZE = 1
        sys.stdin = text_input
        out_w = sys.stdout = _NamedTextIOWrapper(bytes_output, encoding=self.charset, name="<stdout>",
                                         mode="w", write_through=True)
        err_w = sys.stderr = _NamedTextIOWrapper(bytes_error, encoding=self.charset, name="<stderr>",
                                         mode="w", errors="backslashreplace", write_through=True)
        fd_files = []
        saved_fds = []
        if fd_mode:
            for fd in (1, 2):
                tf = tempfile.TemporaryFile()
                fd_files.append(tf)
                saved_fds.append(os.dup(fd))
                os.dup2(tf.fileno(), fd)

        @_pause_echo_wrap(echo_input)
        def visible_input(prompt=None):
            sys.stdout.write(prompt or "")
            val = text_input.readline()
            if not val:
                raise EOFError()
            val = val.rstrip("\r\n")
            sys.stdout.write(val + "\n")
            sys.stdout.flush()
            return val

        @_pause_echo_wrap(echo_input)
        def hidden_input(prompt=None):
            sys.stdout.write((prompt or "") + "\n")
            sys.stdout.flush()
            val = text_input.readline()
            if not val:
                raise EOFError()
            return val.rstrip("\r\n")

        @_pause_echo_wrap(echo_input)
        def _getchar(echo):
            char = sys.stdin.read(1)
            if not char:
                raise EOFError()
            if echo:
                sys.stdout.write(char)
            sys.stdout.flush()
            return char

        default_color = color

        def should_strip_ansi(stream=None, color=None):
            if color is None:
                return not default_color
            return not color

        old_env = {}
        saved = (termui.visible_prompt_func, termui.hidden_prompt_func, termui._getchar,
                 utils.should_strip_ansi)
        termui.visible_prompt_func = visible_input
        termui.hidden_prompt_func = hidden_input
        termui._getchar = _getchar
        utils.should_strip_ansi = should_strip_ansi
        try:
            for key, value in env.items():
                old_env[key] = os.environ.get(key)
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            self._fd_results = None
            try:
                yield (bytes_output, bytes_error, output)
            finally:
                try:
                    sys.stdout.flush()
                    sys.stderr.flush()
                except Exception:
                    pass
                if fd_mode:
                    extra = []
                    for fd, tf, saved_fd in zip((1, 2), fd_files, saved_fds):
                        os.dup2(saved_fd, fd)
                        os.close(saved_fd)
                        tf.seek(0)
                        extra.append(tf.read())
                        tf.close()
                    bytes_output.write(extra[0])
                    bytes_error.write(extra[1])
        finally:
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            (termui.visible_prompt_func, termui.hidden_prompt_func, termui._getchar,
             utils.should_strip_ansi) = saved
            formatting.FORCED_WIDTH = old_forced_width
            sys.stdin, sys.stdout, sys.stderr = old_stdin, old_stdout, old_stderr
            for w in (out_w, err_w, text_input):
                try:
                    w.detach()
                except Exception:
                    pass

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False,
               **extra):
        exc_info = None
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        with self.isolation(input=input, env=env, color=color) as outstreams:
            return_value = None
            exception = None
            exit_code = 0
            if isinstance(args, str):
                args = shlex.split(args)
            try:
                prog_name = extra.pop("prog_name")
            except KeyError:
                prog_name = self.get_default_prog_name(cli)
            if prog_name is None:
                prog_name = self.get_default_prog_name(cli)
            try:
                return_value = cli.main(args=args or (), prog_name=prog_name, **extra)
            except SystemExit as e:
                exc_info = sys.exc_info()
                e_code = e.code
                if e_code is None:
                    e_code = 0
                if e_code != 0:
                    exception = e
                if not isinstance(e_code, int):
                    sys.stdout.write(str(e_code))
                    sys.stdout.write("\n")
                    e_code = 1
                exit_code = e_code
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                try:
                    sys.stdout.flush()
                    sys.stderr.flush()
                except Exception:
                    pass
        # fd-captured data is appended in isolation's finally; read after exit
        bytes_output, bytes_error, output = outstreams
        return Result(runner=self, stdout_bytes=bytes_output.getvalue(),
                      stderr_bytes=bytes_error.getvalue(), output_bytes=output.getvalue(),
                      return_value=return_value, exit_code=exit_code, exception=exception,
                      exc_info=exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass


def _pause_echo_wrap(stream):
    def deco(f):
        def wrapper(*a, **k):
            with _pause_echo(stream):
                return f(*a, **k)
        return wrapper
    return deco
