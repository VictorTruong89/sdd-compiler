"""Output helpers, style, file helpers."""
import codecs
import io
import os
import re
import sys

from ._context_stack import get_current_context, resolve_color_default
from .exceptions import FileError, DeclarationError
from .formatting import strip_ansi

_ansi_colors = {
    "black": 30, "red": 31, "green": 32, "yellow": 33, "blue": 34, "magenta": 35,
    "cyan": 36, "white": 37, "reset": 39,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
}
_ansi_reset_all = "\033[0m"


def _is_int(x):
    return isinstance(x, int) and not isinstance(x, bool)


def _interpret_color(color, offset=0):
    if _is_int(color):
        if not 0 <= color <= 255:
            raise DeclarationError("Unknown color {!r}".format(color))
        return "{};5;{}".format(38 + offset, color)
    if isinstance(color, (tuple, list)):
        if len(color) != 3 or not all(_is_int(c) and 0 <= c <= 255 for c in color):
            raise DeclarationError("Unknown color {!r}".format(color))
        r, g, b = color
        return "{};2;{};{};{}".format(38 + offset, r, g, b)
    if isinstance(color, str) and color in _ansi_colors:
        return str(_ansi_colors[color] + offset)
    raise DeclarationError("Unknown color {!r}".format(color))


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True):
    """Wrap text in ANSI SGR sequences. Invalid colors raise."""
    if not isinstance(text, str):
        text = str(text)
    bits = []
    if fg is not None:
        bits.append("\033[{}m".format(_interpret_color(fg)))
    if bg is not None:
        bits.append("\033[{}m".format(_interpret_color(bg, 10)))
    for val, on, off in ((bold, 1, 22), (dim, 2, 22), (underline, 4, 24), (overline, 53, 55),
                         (italic, 3, 23), (blink, 5, 25), (reverse, 7, 27),
                         (strikethrough, 9, 29)):
        if val is not None:
            bits.append("\033[{}m".format(on if val else off))
    bits.append(text)
    if reset:
        bits.append(_ansi_reset_all)
    return "".join(bits)


def unstyle(text):
    return strip_ansi(text)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None and not isinstance(message, (bytes, bytearray)):
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def isatty(stream):
    try:
        return stream.isatty()
    except Exception:
        return False


def should_strip_ansi(stream=None, color=None):
    if color is None:
        if stream is None:
            stream = sys.stdin
        return not isatty(stream)
    return not color


def get_text_stdout(encoding=None, errors=None):
    return _get_text(sys.stdout, encoding, errors, True)


def get_text_stderr(encoding=None, errors=None):
    return _get_text(sys.stderr, encoding, errors, True)


class _NonClosingTextIOWrapper(io.TextIOWrapper):
    def __del__(self):
        pass

    def close(self):
        try:
            self.flush()
        except Exception:
            pass


def _get_text(stream, encoding, errors, writing):
    if stream is None:
        return None
    if encoding is None:
        return stream
    cur = getattr(stream, "encoding", None)
    try:
        same = cur is not None and codecs.lookup(cur) == codecs.lookup(encoding)
    except LookupError:
        same = False
    if same:
        return stream
    buf = getattr(stream, "buffer", None)
    if buf is None:
        return stream
    try:
        stream.flush()
    except Exception:
        pass
    return _NonClosingTextIOWrapper(buf, encoding=encoding, errors=errors or "strict",
                                    line_buffering=True)


def get_binary_stdout():
    return _binary(sys.stdout)


def get_binary_stderr():
    return _binary(sys.stderr)


def get_binary_stdin():
    return _binary(sys.stdin)


def _binary(stream):
    buf = getattr(stream, "buffer", None)
    if buf is not None:
        try:
            stream.flush()
        except Exception:
            pass
        return buf
    return stream


def get_text_stream(name, encoding=None, errors="strict"):
    if name == "stdin":
        return _get_text(sys.stdin, encoding, errors, False)
    if name == "stdout":
        return get_text_stdout(encoding, errors)
    if name == "stderr":
        return get_text_stderr(encoding, errors)
    raise TypeError("Unknown standard stream {!r}".format(name))


def get_binary_stream(name):
    if name == "stdin":
        return get_binary_stdin()
    if name == "stdout":
        return get_binary_stdout()
    if name == "stderr":
        return get_binary_stderr()
    raise TypeError("Unknown standard stream {!r}".format(name))


def _find_binary_writer(file):
    buf = getattr(file, "buffer", None)
    if buf is not None:
        return buf
    if isinstance(file, (io.RawIOBase, io.BufferedIOBase)):
        return file
    if not hasattr(file, "encoding") and not isinstance(file, io.TextIOBase):
        try:
            file.write(b"")
            return file
        except Exception:
            return None
    return None


def _is_ascii_stream(file):
    enc = getattr(file, "encoding", None)
    if not enc:
        return False
    try:
        return codecs.lookup(enc).name == "ascii"
    except LookupError:
        return False


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write text or bytes to stdout (or stderr, or file)."""
    if file is None:
        file = sys.stderr if err else sys.stdout
        if file is None:
            return
    if message is not None and not isinstance(message, (str, bytes, bytearray)):
        out = str(message)
    else:
        out = message
    if nl:
        out = out or ""
        if isinstance(out, str):
            out += "\n"
        else:
            out += b"\n"
    if not out:
        file.flush()
        return
    if isinstance(out, (bytes, bytearray)):
        binary_file = _find_binary_writer(file)
        if binary_file is not None:
            file.flush()
            binary_file.write(out)
            binary_file.flush()
            return
        out = bytes(out).decode("utf-8", "replace")
    if message and not isinstance(message, (bytes, bytearray)):
        color = resolve_color_default(color)
        if should_strip_ansi(file, color):
            out = strip_ansi(out)
    if _is_ascii_stream(file) and not out.isascii():
        binary_file = _find_binary_writer(file)
        if binary_file is not None:
            file.flush()
            binary_file.write(out.encode("utf-8"))
            binary_file.flush()
            return
    try:
        file.write(out)
    except UnicodeEncodeError:
        binary_file = _find_binary_writer(file)
        if binary_file is None:
            raise
        file.flush()
        binary_file.write(out.encode("utf-8"))
        binary_file.flush()
        return
    file.flush()


def format_filename(filename, shorten=False):
    if shorten:
        filename = os.path.basename(filename)
    else:
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        filename = filename.decode(sys.getfilesystemencoding(), "backslashreplace")
    else:
        filename = filename.encode("utf-8", "surrogateescape").decode("utf-8", "backslashreplace")
    return filename


def _posixify(name):
    return "-".join(name.split()).lower()


def get_app_dir(app_name, roaming=True, force_posix=False):
    if sys.platform.startswith("win"):
        key = "APPDATA" if roaming else "LOCALAPPDATA"
        folder = os.environ.get(key) or os.path.expanduser("~")
        return os.path.join(folder, app_name)
    if force_posix:
        return os.path.join(os.path.expanduser("~/." + _posixify(app_name)))
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~/Library/Application Support"), app_name)
    return os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config"),
                        _posixify(app_name))


class _AtomicFile:
    def __init__(self, f, tmp_filename, real_filename):
        self._f = f
        self._tmp_filename = tmp_filename
        self._real_filename = real_filename
        self.closed = False

    @property
    def name(self):
        return self._real_filename

    def close(self, delete=False):
        if self.closed:
            return
        self._f.close()
        if delete:
            try:
                os.unlink(self._tmp_filename)
            except OSError:
                pass
        else:
            os.replace(self._tmp_filename, self._real_filename)
        self.closed = True

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.close(delete=exc_type is not None)

    def __iter__(self):
        return iter(self._f)

    def __repr__(self):
        return repr(self._f)


def open_stream(filename, mode="r", encoding=None, errors="strict", atomic=False):
    binary = "b" in mode
    filename = os.fspath(filename)
    if filename == "-":
        if any(m in mode for m in "wax"):
            if binary:
                return get_binary_stdout(), False
            return get_text_stdout(encoding=encoding, errors=errors), False
        if binary:
            return get_binary_stdin(), False
        return _get_text(sys.stdin, encoding, errors, False), False
    if not atomic:
        return open(filename, mode, encoding=encoding, errors=errors), True
    if "a" in mode:
        raise ValueError("Appending is not supported in atomic mode.")
    if "x" in mode:
        raise ValueError("Exclusive creation is not supported in atomic mode.")
    if "w" not in mode:
        raise ValueError("Atomic writes only make sense with `w`-mode.")
    import errno
    import random
    try:
        perm = os.stat(filename).st_mode
    except OSError:
        perm = None
    flags = os.O_RDWR | os.O_CREAT | os.O_EXCL
    while True:
        tmp_filename = os.path.join(os.path.dirname(filename),
                                    ".__atomic-write{:08x}".format(random.randrange(1 << 32)))
        try:
            fd = os.open(tmp_filename, flags, 0o666 if perm is None else perm)
            break
        except OSError as e:
            if e.errno == errno.EEXIST:
                continue
            raise
    f = open(fd, mode, encoding=encoding, errors=errors)
    return _AtomicFile(f, tmp_filename, os.path.realpath(filename)), True


class LazyFile:
    """File opened on first I/O."""

    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False):
        self.name = os.fspath(filename)
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self.should_close = True

    def __getattr__(self, name):
        return getattr(self.open(), name)

    def __repr__(self):
        if self._f is not None:
            return repr(self._f)
        return "<unopened file '{}' {}>".format(format_filename(self.name), self.mode)

    def open(self):
        if self._f is not None:
            return self._f
        try:
            rv, self.should_close = open_stream(self.name, self.mode, self.encoding,
                                                self.errors, atomic=self.atomic)
        except OSError as e:
            raise FileError(self.name, hint=e.strerror) from e
        self._f = rv
        return rv

    def close(self):
        if self._f is not None:
            self._f.close()

    def close_intelligently(self):
        if self.should_close:
            self.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.close_intelligently()

    def __iter__(self):
        self.open()
        return iter(self._f)


class KeepOpenFile:
    def __init__(self, file):
        self._file = file

    def __getattr__(self, name):
        return getattr(self._file, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        pass

    def __repr__(self):
        return repr(self._file)

    def __iter__(self):
        return iter(self._file)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    f, should_close = open_stream(filename, mode, encoding, errors, atomic=atomic)
    if not should_close:
        f = KeepOpenFile(f)
    return f
