"""Parameter types."""
import enum
import os
import stat
import uuid
from datetime import datetime

from .exceptions import BadParameter, DeclarationError
from .utils import (LazyFile, format_filename, open_stream, _is_int)


class ParamType:
    is_composite = False
    arity = 1
    name = None
    envvar_list_splitter = None

    def get_metavar(self, param):
        return None

    def get_missing_message(self, param):
        return None

    def convert(self, value, param, ctx):
        return value

    def split_envvar_value(self, rv):
        return (rv or "").split(self.envvar_list_splitter)

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def shell_complete(self, ctx, param, incomplete):
        return []

    def __call__(self, value, param=None, ctx=None):
        if value is not None:
            return self.convert(value, param, ctx)


class FuncParamType(ParamType):
    def __init__(self, func):
        self.name = getattr(func, "__name__", type(func).__name__)
        self.func = func

    def convert(self, value, param, ctx):
        try:
            return self.func(value)
        except ValueError as e:
            msg = str(e)
            if not msg:
                msg = value if isinstance(value, str) else repr(value)
            self.fail(msg, param, ctx)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        return value

    def __repr__(self):
        return "UNPROCESSED"


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        if isinstance(value, bytes):
            enc = getattr(getattr(__import__("sys"), "stdin", None), "encoding", None) or "utf-8"
            try:
                value = value.decode(enc)
            except UnicodeError:
                value = value.decode("utf-8", "replace")
            return value
        return str(value)

    def __repr__(self):
        return "STRING"


class Choice(ParamType):
    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            choices = list(choices)
        self.choices = list(choices)
        self.case_sensitive = case_sensitive

    @staticmethod
    def _str(choice):
        if isinstance(choice, enum.Enum):
            return choice.name
        return str(choice)

    @property
    def choices_as_str(self):
        return [self._str(c) for c in self.choices]

    def _norm(self, s, ctx):
        if ctx is not None and ctx.token_normalize_func is not None:
            s = ctx.token_normalize_func(s)
        if not self.case_sensitive:
            s = s.casefold()
        return s

    def get_metavar(self, param):
        choices_str = "|".join(self.choices_as_str)
        if getattr(param, "required", False) and param.param_type_name == "argument":
            return "{" + choices_str + "}"
        return "[" + choices_str + "]"

    def get_missing_message(self, param):
        return "Choose from:\n\t" + ",\n\t".join(self.choices_as_str)

    def convert(self, value, param, ctx):
        normed = self._norm(self._str(value), ctx)
        table = {}
        for c in self.choices:
            table.setdefault(self._norm(self._str(c), ctx), c)
        if normed in table:
            return table[normed]
        choices_str = ", ".join(repr(c) for c in self.choices_as_str)
        self.fail("{!r} is not {} {}.".format(
            value, "one of" if len(self.choices) > 1 else "the only", choices_str), param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem
        inc = incomplete.casefold() if not self.case_sensitive else incomplete
        out = []
        for c in self.choices_as_str:
            cc = c.casefold() if not self.case_sensitive else c
            if cc.startswith(inc):
                out.append(CompletionItem(c))
        return out

    def __repr__(self):
        return "Choice({!r})".format(self.choices_as_str)


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else [
            "%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]

    def get_metavar(self, param):
        return "[{}]".format("|".join(self.formats))

    def convert(self, value, param, ctx):
        if isinstance(value, datetime):
            return value
        for fmt in self.formats:
            try:
                return datetime.strptime(value, fmt)
            except (ValueError, TypeError):
                continue
        formats_str = ", ".join(repr(f) for f in self.formats)
        self.fail("{!r} does not match the format{} {}.".format(
            value, "s" if len(self.formats) > 1 else "", formats_str), param, ctx)


class _NumberParamTypeBase(ParamType):
    _number_class = None

    def convert(self, value, param, ctx):
        try:
            return self._number_class(value)
        except (ValueError, TypeError):
            self.fail("{!r} is not a valid {}.".format(value, self.name), param, ctx)


class IntParamType(_NumberParamTypeBase):
    name = "integer"
    _number_class = int

    def __repr__(self):
        return "INT"


class FloatParamType(_NumberParamTypeBase):
    name = "float"
    _number_class = float

    def __repr__(self):
        return "FLOAT"


class _NumberRangeBase(_NumberParamTypeBase):
    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param, ctx):
        import operator
        rv = super().convert(value, param, ctx)
        lt_min = self.min is not None and (operator.le if self.min_open else operator.lt)(rv, self.min)
        gt_max = self.max is not None and (operator.ge if self.max_open else operator.gt)(rv, self.max)
        if self.clamp:
            if lt_min:
                return self._clamp(self.min, 1, self.min_open)
            if gt_max:
                return self._clamp(self.max, -1, self.max_open)
        if lt_min or gt_max:
            self.fail("{} is not in the range {}.".format(rv, self._describe_range()), param, ctx)
        return rv

    def _clamp(self, bound, dir, open):
        raise NotImplementedError

    def _describe_range(self):
        if self.min is None:
            op = "<" if self.max_open else "<="
            return "x{}{}".format(op, self.max)
        if self.max is None:
            op = ">" if self.min_open else ">="
            return "x{}{}".format(op, self.min)
        lop = "<" if self.min_open else "<="
        rop = "<" if self.max_open else "<="
        return "{}{}x{}{}".format(self.min, lop, rop, self.max)


class IntRange(_NumberRangeBase):
    name = "integer range"
    _number_class = int

    def _clamp(self, bound, dir, open):
        if not open:
            return bound
        return bound + dir


class FloatRange(_NumberRangeBase):
    name = "float range"
    _number_class = float

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        super().__init__(min, max, min_open, max_open, clamp)
        if (min_open or max_open) and clamp:
            raise DeclarationError("Clamping is not supported for open bounds.")

    def _clamp(self, bound, dir, open):
        if not open:
            return bound
        raise DeclarationError("Clamping is not supported for open bounds.")


class BoolParamType(ParamType):
    name = "boolean"
    TRUE = ("1", "true", "t", "yes", "y", "on")
    FALSE = ("0", "false", "f", "no", "n", "off")

    def convert(self, value, param, ctx):
        if value in {False, True} and not isinstance(value, str):
            return bool(value)
        norm = str(value).strip().lower()
        if norm in self.TRUE:
            return True
        if norm in self.FALSE:
            return False
        self.fail("{!r} is not a valid boolean.".format(value), param, ctx)

    def __repr__(self):
        return "BOOL"


class UUIDParameterType(ParamType):
    name = "uuid"

    def convert(self, value, param, ctx):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except ValueError:
            self.fail("{!r} is not a valid UUID.".format(value), param, ctx)

    def __repr__(self):
        return "UUID"


def _is_file_like(value):
    return hasattr(value, "read") or hasattr(value, "write")


class File(ParamType):
    name = "filename"
    envvar_list_splitter = os.path.pathsep

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def resolve_lazy_flag(self, value):
        if self.lazy is not None:
            return self.lazy
        if os.fspath(value) == "-":
            return False
        if "w" in self.mode:
            return True
        return False

    def convert(self, value, param, ctx):
        if _is_file_like(value):
            return value
        try:
            lazy = self.resolve_lazy_flag(value)
            if lazy:
                lf = LazyFile(value, self.mode, self.encoding, self.errors, atomic=self.atomic)
                if ctx is not None:
                    ctx.call_on_close(lf.close_intelligently)
                return lf
            f, should_close = open_stream(value, self.mode, self.encoding, self.errors,
                                          atomic=self.atomic)
            if ctx is not None:
                if should_close:
                    ctx.call_on_close(_safecall(f.close))
                else:
                    ctx.call_on_close(_safecall(f.flush))
            return f
        except OSError as e:
            self.fail("'{}': {}".format(format_filename(value), e.strerror), param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem
        return [CompletionItem(incomplete, type="file")]


def _safecall(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception:
            pass
    return wrapper


class Path(ParamType):
    envvar_list_splitter = os.path.pathsep

    def __init__(self, exists=False, file_okay=True, dir_okay=True, writable=False,
                 readable=True, resolve_path=False, allow_dash=False, path_type=None,
                 executable=False):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.readable = readable
        self.writable = writable
        self.executable = executable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.type = path_type
        if self.file_okay and not self.dir_okay:
            self.name = "file"
        elif self.dir_okay and not self.file_okay:
            self.name = "directory"
        else:
            self.name = "path"

    def coerce_path_result(self, rv):
        if self.type is not None and not isinstance(rv, self.type):
            if self.type is str:
                rv = os.fsdecode(rv)
            elif self.type is bytes:
                rv = os.fsencode(rv)
            else:
                rv = self.type(rv)
        return rv

    def convert(self, value, param, ctx):
        rv = value
        is_dash = self.file_okay and self.allow_dash and rv in (b"-", "-")
        if not is_dash:
            if self.resolve_path:
                rv = os.path.realpath(rv)
            try:
                st = os.stat(rv)
            except OSError:
                if not self.exists:
                    return self.coerce_path_result(rv)
                self.fail("{} {!r} does not exist.".format(
                    self.name.title(), format_filename(value)), param, ctx)
            if not self.file_okay and stat.S_ISREG(st.st_mode):
                self.fail("{} {!r} is a file.".format(self.name.title(), format_filename(value)),
                          param, ctx)
            if not self.dir_okay and stat.S_ISDIR(st.st_mode):
                self.fail("{} {!r} is a directory.".format(
                    self.name.title(), format_filename(value)), param, ctx)
            if self.readable and not os.access(rv, os.R_OK):
                self.fail("{} {!r} is not readable.".format(
                    self.name.title(), format_filename(value)), param, ctx)
            if self.writable and not os.access(rv, os.W_OK):
                self.fail("{} {!r} is not writable.".format(
                    self.name.title(), format_filename(value)), param, ctx)
            if self.executable and not os.access(rv, os.X_OK):
                self.fail("{} {!r} is not executable.".format(
                    self.name.title(), format_filename(value)), param, ctx)
        return self.coerce_path_result(rv)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem
        type = "dir" if self.dir_okay and not self.file_okay else "file"
        return [CompletionItem(incomplete, type=type)]


class Tuple(ParamType):
    is_composite = True

    def __init__(self, types):
        self.types = [convert_type(ty) for ty in types]

    @property
    def name(self):
        return "<{}>".format(" ".join(ty.name for ty in self.types))

    @property
    def arity(self):
        return len(self.types)

    def convert(self, value, param, ctx):
        len_type = len(self.types)
        try:
            len_value = len(value)
        except TypeError:
            self.fail("{} values are required.".format(len_type), param, ctx)
        if len_value != len_type:
            self.fail("{} values are required, but {} were given.".format(len_type, len_value),
                      param, ctx)
        return tuple(ty(x, param, ctx) for ty, x in zip(self.types, value))


def convert_type(ty, default=None):
    guessed_type = False
    if ty is None and default is not None:
        if isinstance(default, (tuple, list)):
            if default:
                item = default[0]
                if isinstance(item, (tuple, list)):
                    ty = tuple(map(type, item))
                else:
                    ty = type(item)
        else:
            ty = type(default)
        guessed_type = True
    if isinstance(ty, tuple):
        return Tuple(ty)
    if isinstance(ty, ParamType):
        return ty
    if ty is str or ty is None:
        return STRING
    if ty is int:
        return INT
    if ty is float:
        return FLOAT
    if ty is bool:
        return BOOL
    if guessed_type:
        return STRING
    if isinstance(ty, type) and issubclass(ty, ParamType):
        raise DeclarationError("Attempted to use an uninstantiated parameter type ({}).".format(ty.__name__))
    return FuncParamType(ty)


UNPROCESSED = UnprocessedParamType()
STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParameterType()
