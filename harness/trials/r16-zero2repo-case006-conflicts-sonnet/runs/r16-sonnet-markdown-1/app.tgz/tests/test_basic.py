import optlyn
from optlyn.testing import CliRunner


def test_group_and_command():
    @optlyn.group()
    def cli():
        pass

    @cli.command()
    @optlyn.option("--n", type=int, default=1)
    def hi(n):
        optlyn.echo(f"hi {n}")

    r = CliRunner().invoke(cli, ["hi", "--n", "3"])
    assert r.exit_code == 0 and r.output == "hi 3\n"
    assert CliRunner().invoke(cli, []).exit_code == 2
