"""Stream and platform helpers."""
import codecs
import io
import os
import re
import sys

_ansi_re = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")


def strip_ansi(value):
    return _ansi_re.sub("", value)


def term_len(x):
    return len(strip_ansi(x))


def isatty(stream):
    try:
        return stream.isatty()
    except Exception:
        return False


def should_strip_ansi(stream=None, color=None):
    if color is None:
        if stream is None:
            stream = sys.stdin
        return not isatty(stream)
    return not color


def is_interactive():
    return isatty(sys.stdin) or isatty(sys.stdout)


def is_ascii_encoding(encoding):
    try:
        return codecs.lookup(encoding).name == "ascii"
    except LookupError:
        return False


class _NonClosingTextIOWrapper(io.TextIOWrapper):
    def __del__(self):
        pass

    def close(self):
        try:
            self.flush()
        except Exception:
            pass


def _same_encoding(a, b):
    try:
        return codecs.lookup(a).name == codecs.lookup(b).name
    except LookupError:
        return False


def get_text_stream(name, encoding=None, errors="strict"):
    stream = getattr(sys, name)
    if stream is None or not hasattr(stream, "buffer"):
        return stream
    cur = getattr(stream, "encoding", None)
    if encoding is None:
        if cur and is_ascii_encoding(cur):
            return _NonClosingTextIOWrapper(stream.buffer, "utf-8", "replace", line_buffering=True)
        return stream
    if cur and _same_encoding(cur, encoding) and errors == getattr(stream, "errors", errors):
        return stream
    try:
        stream.flush()
    except Exception:
        pass
    return _NonClosingTextIOWrapper(stream.buffer, encoding, errors, line_buffering=True)


def get_binary_stream(name):
    stream = getattr(sys, name)
    if hasattr(stream, "buffer"):
        return stream.buffer
    return stream


class KeepOpenFile:
    def __init__(self, file):
        self._file = file

    def __getattr__(self, name):
        return getattr(self._file, name)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        try:
            self._file.flush()
        except Exception:
            pass

    def __repr__(self):
        return repr(self._file)

    def __iter__(self):
        return iter(self._file)


class _AtomicFile:
    def __init__(self, f, tmp_filename, real_filename):
        self._f = f
        self._tmp_filename = tmp_filename
        self._real_filename = real_filename
        self.closed = False

    @property
    def name(self):
        return self._real_filename

    def close(self, delete=False):
        if self.closed:
            return
        self._f.close()
        if delete:
            try:
                os.unlink(self._tmp_filename)
            except OSError:
                pass
        else:
            os.replace(self._tmp_filename, self._real_filename)
        self.closed = True

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, *a):
        self.close(delete=exc_type is not None)

    def __iter__(self):
        return iter(self._f)

    def __repr__(self):
        return repr(self._f)


def open_stream(filename, mode="r", encoding=None, errors="strict", atomic=False):
    binary = "b" in mode
    filename = os.fspath(filename)
    if filename == "-":
        if any(m in mode for m in ("w", "a", "x")):
            if binary:
                return get_binary_stream("stdout"), False
            return get_text_stream("stdout", encoding, errors), False
        if binary:
            return get_binary_stream("stdin"), False
        return get_text_stream("stdin", encoding, errors), False
    if not atomic:
        return open(filename, mode, encoding=encoding, errors=errors), True
    if "r" in mode or "a" in mode or "x" in mode or "+" in mode:
        raise ValueError("Atomic writes only make sense with 'w' mode.")
    import errno
    import random

    flags = os.O_RDWR | os.O_CREAT | os.O_EXCL
    if binary:
        flags |= getattr(os, "O_BINARY", 0)
    while True:
        tmp = os.path.join(os.path.dirname(filename), f".__atomic-write{random.randrange(1 << 32):08x}")
        try:
            fd = os.open(tmp, flags, 0o666)
            break
        except OSError as e:
            if e.errno == errno.EEXIST:
                continue
            raise
    f = open(fd, mode, encoding=encoding, errors=errors)
    return _AtomicFile(f, tmp, os.path.realpath(filename)), True


class LazyFile:
    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False):
        self.name = os.fspath(filename)
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self.should_close = True
        if self.name == "-":
            self._f, self.should_close = open_stream(filename, mode, encoding, errors)
        elif "r" in mode:
            open(filename, mode).close()

    def __getattr__(self, name):
        return getattr(self.open(), name)

    def __repr__(self):
        if self._f is not None:
            return repr(self._f)
        return f"<unopened file '{self.name}' {self.mode}>"

    def open(self):
        if self._f is not None:
            return self._f
        try:
            rv, self.should_close = open_stream(self.name, self.mode, self.encoding, self.errors, atomic=self.atomic)
        except OSError as e:
            from .exceptions import FileError

            raise FileError(self.name, hint=e.strerror) from e
        self._f = rv
        return rv

    def close(self):
        if self._f is not None:
            self._f.close()

    def close_intelligently(self):
        if self.should_close:
            self.close()

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close_intelligently()

    def __iter__(self):
        self.open()
        return iter(self._f)
