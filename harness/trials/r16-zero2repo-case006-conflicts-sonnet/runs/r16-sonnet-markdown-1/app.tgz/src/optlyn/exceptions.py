import sys

from ._compat import get_text_stream


def _echo_err(msg):
    from .utils import echo

    echo(msg, err=True)


class OptlynException(Exception):
    exit_code = 1

    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def format_message(self):
        return self.message

    def __str__(self):
        return self.message

    def show(self, file=None):
        from .utils import echo

        echo(f"Error: {self.format_message()}", file=file if file is not None else sys.stderr)


ClickException = OptlynException


class UsageError(OptlynException):
    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.ctx = ctx
        self.cmd = self.ctx.command if self.ctx else None

    def show(self, file=None):
        from .utils import echo

        if file is None:
            file = sys.stderr
        color = None
        hint = ""
        if self.ctx is not None:
            color = self.ctx.color
            names = self.ctx.command.get_help_option_names(self.ctx) if hasattr(self.ctx.command, "get_help_option_names") else []
            if names and self.ctx.command.add_help_option:
                hint = f"Try '{self.ctx.command_path} {names[0]}' for help.\n"
            echo(f"{self.ctx.get_usage()}\n{hint}", file=file, color=color)
        echo(f"Error: {self.format_message()}", file=file, color=color)


class NoArgsIsHelpError(UsageError):
    def __init__(self, ctx):
        super().__init__(ctx.get_help(), ctx=ctx)

    def show(self, file=None):
        from .utils import echo

        echo(self.format_message(), file=file if file is not None else sys.stderr, color=self.ctx.color)


def _join_param_hints(param_hint):
    if isinstance(param_hint, (tuple, list)):
        return " / ".join(repr(x) for x in param_hint)
    return param_hint


class BadParameter(UsageError):
    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        if self.param_hint is not None:
            param_hint = self.param_hint
        elif self.param is not None:
            param_hint = self.param.get_error_hint(self.ctx)
        else:
            return f"Invalid value: {self.message}"
        return f"Invalid value for {_join_param_hints(param_hint)}: {self.message}"


class MissingParameter(BadParameter):
    def __init__(self, message=None, ctx=None, param=None, param_hint=None, param_type=None):
        super().__init__(message or "", ctx, param, param_hint)
        self.param_type = param_type

    def format_message(self):
        if self.param_hint is not None:
            param_hint = self.param_hint
        elif self.param is not None:
            param_hint = self.param.get_error_hint(self.ctx)
        else:
            param_hint = None
        param_hint = _join_param_hints(param_hint)
        param_type = self.param_type
        if param_type is None and self.param is not None:
            param_type = self.param.param_type_name
        msg = self.message
        if self.param is not None:
            msg_extra = self.param.type.get_missing_message(self.param)
            if msg_extra:
                msg = f"{msg}. {msg_extra}" if msg else msg_extra
        hint_str = f" {param_hint}" if param_hint else ""
        return f"Missing {param_type or 'parameter'}{hint_str}." + (f" {msg}" if msg else "")


class NoSuchOption(UsageError):
    def __init__(self, option_name, message=None, possibilities=None, ctx=None):
        if message is None:
            message = f"No such option: {option_name}"
        super().__init__(message, ctx)
        self.option_name = option_name
        self.possibilities = possibilities

    def format_message(self):
        if not self.possibilities:
            return self.message
        poss = sorted(self.possibilities)
        if len(poss) == 1:
            return f"{self.message} Did you mean {poss[0]}?"
        return f"{self.message} (Possible options: {', '.join(poss)})"


class BadOptionUsage(UsageError):
    def __init__(self, option_name, message, ctx=None):
        super().__init__(message, ctx)
        self.option_name = option_name


class BadArgumentUsage(UsageError):
    pass


class FileError(OptlynException):
    def __init__(self, filename, hint=None):
        if hint is None:
            hint = "unknown error"
        super().__init__(hint)
        self.ui_filename = _fmt(filename)
        self.filename = filename

    def format_message(self):
        return f"Could not open file {self.ui_filename!r}: {self.message}"


def _fmt(filename):
    from .utils import format_filename

    return format_filename(filename)


class Abort(RuntimeError):
    pass


class Exit(RuntimeError):
    def __init__(self, code=0):
        self.exit_code = code
