import os
import re
import sys

from . import _compat
from ._compat import LazyFile, KeepOpenFile, open_stream
from .globals import resolve_color_default

_ansi_colors = {
    "black": 30, "red": 31, "green": 32, "yellow": 33, "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "reset": 39, "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
}
_ansi_reset_all = "\033[0m"


def make_str(value):
    if isinstance(value, bytes):
        try:
            return value.decode(sys.getfilesystemencoding())
        except UnicodeError:
            return value.decode("utf-8", "replace")
    return str(value)


def safecall(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception:
            pass

    return wrapper


def echo(message=None, file=None, nl=True, err=False, color=None):
    if file is None:
        file = sys.stderr if err else sys.stdout
        if file is None:
            return
    if message is not None and not isinstance(message, (str, bytes, bytearray)):
        out = str(message)
    else:
        out = message
    if nl:
        out = out or ""
        out = out + ("\n" if isinstance(out, str) else b"\n")
    if not out:
        file.flush()
        return
    if isinstance(out, (bytes, bytearray)):
        binary = getattr(file, "buffer", None)
        if binary is not None:
            file.flush()
            binary.write(out)
            binary.flush()
            return
        out = bytes(out).decode("utf-8", "replace")
    else:
        color = resolve_color_default(color)
        if _compat.should_strip_ansi(file, color):
            out = _compat.strip_ansi(out)
    enc = getattr(file, "encoding", None)
    if enc and _compat.is_ascii_encoding(enc) and not out.isascii():
        binary = getattr(file, "buffer", None)
        if binary is not None:
            file.flush()
            binary.write(out.encode("utf-8"))
            binary.flush()
            return
        out = out.encode("ascii", "replace").decode("ascii")
    file.write(out)
    file.flush()


def _interpret_color(color, offset=0):
    if isinstance(color, bool):
        raise TypeError(f"Unknown color {color!r}")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise ValueError(f"Color {color!r} out of range")
        return f"{38 + offset};5;{color:d}"
    if isinstance(color, (tuple, list)):
        if len(color) != 3 or not all(isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color):
            raise ValueError(f"Invalid RGB color {color!r}")
        r, g, b = color
        return f"{38 + offset};2;{r:d};{g:d};{b:d}"
    if isinstance(color, str) and color in _ansi_colors:
        return str(_ansi_colors[color] + offset)
    raise TypeError(f"Unknown color {color!r}")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None, italic=None,
          blink=None, reverse=None, strikethrough=None, reset=True):
    if not isinstance(text, str):
        text = str(text)
    bits = []
    if fg is not None:
        bits.append(f"\033[{_interpret_color(fg)}m")
    if bg is not None:
        bits.append(f"\033[{_interpret_color(bg, 10)}m")
    for val, on, off in ((bold, 1, 22), (dim, 2, 22), (underline, 4, 24), (overline, 53, 55), (italic, 3, 23),
                         (blink, 5, 25), (reverse, 7, 27), (strikethrough, 9, 29)):
        if val is not None:
            bits.append(f"\033[{on if val else off}m")
    bits.append(text)
    if reset:
        bits.append(_ansi_reset_all)
    return "".join(bits)


def unstyle(text):
    return _compat.strip_ansi(text)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None and not isinstance(message, (bytes, bytearray)):
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def format_filename(filename, shorten=False):
    if shorten:
        filename = os.path.basename(filename)
    else:
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        return filename.decode(sys.getfilesystemencoding(), "replace")
    return filename.encode("utf-8", "surrogateescape").decode("utf-8", "replace")


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    f, should_close = open_stream(filename, mode, encoding, errors, atomic=atomic)
    if not should_close:
        f = KeepOpenFile(f)
    return f


def get_binary_stream(name):
    if name not in ("stdin", "stdout", "stderr"):
        raise TypeError(f"Unknown standard stream '{name}'")
    return _compat.get_binary_stream(name)


def get_text_stream(name, encoding=None, errors="strict"):
    if name not in ("stdin", "stdout", "stderr"):
        raise TypeError(f"Unknown standard stream '{name}'")
    return _compat.get_text_stream(name, encoding, errors)


def get_app_dir(app_name, roaming=True, force_posix=False):
    def posixify(name):
        return "-".join(name.split()).lower()

    if sys.platform.startswith("win"):
        key = "APPDATA" if roaming else "LOCALAPPDATA"
        folder = os.environ.get(key)
        if folder is None:
            folder = os.path.expanduser("~")
        return os.path.join(folder, app_name)
    if force_posix:
        return os.path.join(os.path.expanduser(f"~/.{posixify(app_name)}"))
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~/Library/Application Support"), app_name)
    return os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config"), posixify(app_name))


def _detect_program_name(path=None):
    if path is None:
        path = sys.argv[0] if sys.argv else ""
    base = os.path.basename(path)
    if base == "__main__.py":
        base = os.path.basename(os.path.dirname(os.path.abspath(path)))
    return base or "main"
