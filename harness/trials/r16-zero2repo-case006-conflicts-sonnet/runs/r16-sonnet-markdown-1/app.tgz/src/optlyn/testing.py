import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile

from . import _compat, formatting, termui


class EchoingStdin:
    def __init__(self, input, output):
        self._input = input
        self._output = output
        self._paused = False

    def __getattr__(self, x):
        return getattr(self._input, x)

    def _echo(self, rv):
        if not self._paused:
            self._output.write(rv)
        return rv

    def read(self, n=-1):
        return self._echo(self._input.read(n))

    def read1(self, n=-1):
        return self._echo(self._input.read1(n))

    def readline(self, n=-1):
        return self._echo(self._input.readline(n))

    def readlines(self):
        return [self._echo(x) for x in self._input.readlines()]

    def __iter__(self):
        return iter(self._echo(x) for x in self._input)


@contextlib.contextmanager
def _pause_echo(stream):
    if stream is None:
        yield
    else:
        stream._paused = True
        try:
            yield
        finally:
            stream._paused = False


class _NamedTextIOWrapper(io.TextIOWrapper):
    def __init__(self, buffer, name=None, mode=None, **kwargs):
        super().__init__(buffer, **kwargs)
        self._name = name
        self._mode = mode

    @property
    def name(self):
        return self._name

    @property
    def mode(self):
        return self._mode


class _BytesIOCopy(io.BytesIO):
    def __init__(self, copy_to, fd=None, before=None):
        super().__init__()
        self.copy_to = copy_to
        self._fd = fd
        self._before = before

    def write(self, b):
        if self._before is not None:
            self._before()
        n = super().write(b)
        self.copy_to.write(b)
        return n

    def flush(self):
        super().flush()
        self.copy_to.flush()

    def fileno(self):
        if self._fd is None:
            return super().fileno()
        return self._fd


def make_input_stream(input, charset):
    if hasattr(input, "read"):
        rv = input
        if isinstance(rv.read(0), str):
            raise TypeError("input must be bytes-based")
        return rv
    if input is None:
        input = b""
    elif isinstance(input, str):
        input = input.encode(charset)
    return io.BytesIO(input)


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value, exit_code, exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    def _dec(self, b):
        return b.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def output(self):
        return self._dec(self.output_bytes)

    @property
    def stdout(self):
        return self._dec(self.stdout_bytes)

    @property
    def stderr(self):
        return self._dec(self.stderr_bytes)

    def __repr__(self):
        exc_str = repr(self.exception) if self.exception else "okay"
        return f"<{type(self).__name__} {exc_str}>"


class _FdCapture:
    """Captures OS-level writes to descriptors 1 and 2."""

    def __init__(self, combined):
        self.combined = combined
        self.extra_out = b""
        self.extra_err = b""
        self._saved = {}
        self._tmp = {}
        self._off = {1: 0, 2: 0}

    def start(self):
        for fd in (1, 2):
            try:
                (sys.__stdout__ if fd == 1 else sys.__stderr__).flush()
            except Exception:
                pass
            self._saved[fd] = os.dup(fd)
            tf = tempfile.TemporaryFile()
            self._tmp[fd] = tf
            os.dup2(tf.fileno(), fd)

    def drain(self):
        for fd in (1, 2):
            tf = self._tmp.get(fd)
            if tf is None:
                continue
            while True:
                data = os.pread(tf.fileno(), 65536, self._off[fd])
                if not data:
                    break
                self._off[fd] += len(data)
                self.combined.write(data)
                if fd == 1:
                    self.extra_out += data
                else:
                    self.extra_err += data

    def stop(self):
        self.drain()
        for fd in (1, 2):
            if fd in self._saved:
                os.dup2(self._saved[fd], fd)
                os.close(self._saved[fd])
                self._tmp[fd].close()
        self._saved.clear()
        self._tmp.clear()


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        self.charset = charset
        self.env = env or {}
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def make_env(self, overrides=None):
        rv = dict(self.env)
        if overrides:
            rv.update(overrides)
        return rv

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        bytes_input = make_input_stream(input, self.charset)
        echo_input = None
        old_stdin, old_stdout, old_stderr = sys.stdin, sys.stdout, sys.stderr
        old_forced_width = formatting.FORCED_WIDTH
        formatting.FORCED_WIDTH = 80
        env = self.make_env(env)
        bytes_output = io.BytesIO()
        fdcap = None
        if self.capture == "fd":
            fdcap = _FdCapture(bytes_output)
            fdcap.start()
            out_buf = _BytesIOCopy(bytes_output, fd=1, before=fdcap.drain)
            err_buf = _BytesIOCopy(bytes_output, fd=2, before=fdcap.drain)
        else:
            out_buf = _BytesIOCopy(bytes_output)
            err_buf = _BytesIOCopy(bytes_output)
        if self.echo_stdin:
            bytes_input = echo_input = EchoingStdin(bytes_input, bytes_output)
        sys.stdin = text_input = _NamedTextIOWrapper(bytes_input, encoding=self.charset, name="<stdin>", mode="r")
        if self.echo_stdin:
            text_input._CHUNK_SIZE = 1
        sys.stdout = _NamedTextIOWrapper(out_buf, encoding=self.charset, name="<stdout>", mode="w")
        sys.stderr = _NamedTextIOWrapper(err_buf, encoding=self.charset, name="<stderr>", mode="w", errors="backslashreplace")

        def visible_input(prompt=None):
            with _pause_echo(echo_input):
                sys.stdout.write(prompt or "")
                val = text_input.readline().rstrip("\r\n")
                sys.stdout.write(f"{val}\n")
                sys.stdout.flush()
            return val

        def hidden_input(prompt=None):
            with _pause_echo(echo_input):
                sys.stdout.write(f"{prompt or ''}\n")
                sys.stdout.flush()
                return text_input.readline().rstrip("\r\n")

        def _getchar(echo):
            with _pause_echo(echo_input):
                char = sys.stdin.read(1)
                if echo:
                    sys.stdout.write(char)
                sys.stdout.flush()
                return char

        default_color = color

        def should_strip_ansi(stream=None, color=None):
            if color is None:
                return not default_color
            return not color

        old_visible, old_hidden, old_getchar = termui.visible_prompt_func, termui.hidden_prompt_func, termui._getchar
        old_strip = _compat.should_strip_ansi
        termui.visible_prompt_func = visible_input
        termui.hidden_prompt_func = hidden_input
        termui._getchar = _getchar
        _compat.should_strip_ansi = should_strip_ansi
        old_env = {}
        try:
            for key, value in env.items():
                old_env[key] = os.environ.get(key)
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            yield (out_buf, err_buf, bytes_output, fdcap)
        finally:
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            if fdcap is not None:
                fdcap.stop()
            sys.stdout, sys.stderr, sys.stdin = old_stdout, old_stderr, old_stdin
            termui.visible_prompt_func, termui.hidden_prompt_func, termui._getchar = old_visible, old_hidden, old_getchar
            _compat.should_strip_ansi = old_strip
            formatting.FORCED_WIDTH = old_forced_width

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        exc_info = None
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        with self.isolation(input=input, env=env, color=color) as outstreams:
            return_value = None
            exception = None
            exit_code = 0
            if isinstance(args, str):
                args = shlex.split(args)
            prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
            try:
                return_value = cli.main(args=args or (), prog_name=prog_name, **extra)
            except SystemExit as e:
                exc_info = sys.exc_info()
                e_code = e.code
                if e_code is None:
                    e_code = 0
                if e_code != 0:
                    exception = e
                if not isinstance(e_code, int):
                    sys.stdout.write(str(e_code))
                    sys.stdout.write("\n")
                    e_code = 1
                exit_code = e_code
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                sys.stdout.flush()
                sys.stderr.flush()
                if outstreams[3] is not None:
                    outstreams[3].drain()
                stdout = outstreams[0].getvalue()
                stderr = outstreams[1].getvalue()
                output = outstreams[2].getvalue()
                if outstreams[3] is not None:
                    stdout += outstreams[3].extra_out
                    stderr += outstreams[3].extra_err
        return Result(self, stdout, stderr, output, return_value, exit_code, exception, exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass
