import optlyn as o
from optlyn.testing import CliRunner


def _cli():
    @o.group()
    def cli():
        """Root."""

    @cli.command()
    @o.option("-n", "--count", type=int, default=1)
    @o.argument("name")
    def hello(count, name):
        o.echo(f"{count} {name}")

    return cli


def test_dispatch():
    r = CliRunner().invoke(_cli(), ["hello", "-n", "3", "bob"])
    assert r.exit_code == 0 and r.output == "3 bob\n"


def test_group_no_args_is_usage_failure():
    r = CliRunner().invoke(_cli(), [])
    assert r.exit_code == 2 and "Commands" in r.stderr


def test_help_is_success():
    r = CliRunner().invoke(_cli(), ["--help"])
    assert r.exit_code == 0 and "Usage:" in r.stdout


def test_bad_value():
    r = CliRunner().invoke(_cli(), ["hello", "-n", "x", "b"])
    assert r.exit_code == 2 and "--count" in r.stderr
