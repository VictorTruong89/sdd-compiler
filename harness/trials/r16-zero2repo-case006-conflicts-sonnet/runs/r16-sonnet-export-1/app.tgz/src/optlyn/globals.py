import threading

_local = threading.local()


def get_current_context(silent=False):
    try:
        return _local.stack[-1]
    except (AttributeError, IndexError):
        if not silent:
            raise RuntimeError("There is no active optlyn context.") from None
    return None


def push_context(ctx):
    _local.__dict__.setdefault("stack", []).append(ctx)


def pop_context():
    _local.stack.pop()


def resolve_color_default(color=None):
    if color is not None:
        return color
    ctx = get_current_context(silent=True)
    if ctx is not None:
        return ctx.color
    return None
