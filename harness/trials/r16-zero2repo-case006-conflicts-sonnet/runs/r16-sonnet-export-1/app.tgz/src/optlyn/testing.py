import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile

from . import _compat, formatting, termui


class _BytesIOCopy(io.BytesIO):
    def __init__(self, copy_to):
        super().__init__()
        self.copy_to = copy_to

    def flush(self):
        super().flush()
        self.copy_to.flush()

    def write(self, b):
        self.copy_to.write(b)
        return super().write(b)


class _NamedTextIOWrapper(io.TextIOWrapper):
    def __init__(self, buffer, name=None, mode=None, **kwargs):
        super().__init__(buffer, **kwargs)
        self._name = name
        self._mode = mode

    @property
    def name(self):
        return self._name

    @property
    def mode(self):
        return self._mode


class _FdRaw(io.RawIOBase):
    """Raw stream that reports a real descriptor and records into a mixer buffer."""

    def __init__(self, fd, sink):
        self._fd = fd
        self._sink = sink

    def writable(self):
        return True

    def fileno(self):
        return self._fd

    def write(self, b):
        self._sink.write(bytes(b))
        return len(b)


class _EchoingStdin:
    """Text-level stdin wrapper echoing exactly what was read."""

    def __init__(self, input, write):
        self._input = input
        self._write = write
        self.paused = False

    def __getattr__(self, x):
        return getattr(self._input, x)

    def _echo(self, rv):
        if not self.paused and rv:
            self._write(rv)
        return rv

    def read(self, n=-1):
        return self._echo(self._input.read(n))

    def readline(self, n=-1):
        return self._echo(self._input.readline(n))

    def readlines(self):
        return [self._echo(x) for x in self._input.readlines()]

    def __iter__(self):
        return iter(self.readline, "")


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value, exit_code, exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self):
        return self.output_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    def __repr__(self):
        exc_str = repr(self.exception) if self.exception else "okay"
        return f"<{type(self).__name__} {exc_str}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        self.charset = charset
        self.env = env or {}
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def make_env(self, overrides=None):
        rv = dict(self.env)
        if overrides:
            rv.update(overrides)
        return rv

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        if input is None:
            input = b""
        elif isinstance(input, str):
            input = input.encode(self.charset)
        else:
            input = bytes(input)
        env = self.make_env(env)

        old_stdin, old_stdout, old_stderr = sys.stdin, sys.stdout, sys.stderr
        old_forced_width = formatting.FORCED_WIDTH
        formatting.FORCED_WIDTH = 80

        bytes_output = io.BytesIO()
        bytes_input = io.BytesIO(input)
        out_b = _BytesIOCopy(copy_to=bytes_output)
        err_b = _BytesIOCopy(copy_to=bytes_output)
        saved_fds = None
        tmp_out = tmp_err = None
        if self.capture == "fd":
            sys.stdout.flush() if sys.stdout else None
            sys.stderr.flush() if sys.stderr else None
            tmp_out = tempfile.TemporaryFile()
            tmp_err = tempfile.TemporaryFile()
            saved_fds = (os.dup(1), os.dup(2))
            os.dup2(tmp_out.fileno(), 1)
            os.dup2(tmp_err.fileno(), 2)
            out_stream = io.BufferedWriter(_FdRaw(1, out_b), buffer_size=1)
            err_stream = io.BufferedWriter(_FdRaw(2, err_b), buffer_size=1)
            sys.stdout = _NamedTextIOWrapper(out_stream, encoding=self.charset, name="<stdout>", mode="w", write_through=True)
            sys.stderr = _NamedTextIOWrapper(err_stream, encoding=self.charset, name="<stderr>", mode="w", write_through=True)
        else:
            sys.stdout = _NamedTextIOWrapper(out_b, encoding=self.charset, name="<stdout>", mode="w", write_through=True)
            sys.stderr = _NamedTextIOWrapper(err_b, encoding=self.charset, name="<stderr>", mode="w", write_through=True)
        text_input = _NamedTextIOWrapper(bytes_input, encoding=self.charset, name="<stdin>", mode="r")
        if self.echo_stdin:
            text_input = _EchoingStdin(text_input, lambda s: sys.stdout.write(s))
        sys.stdin = text_input
        raw_stdin = sys.stdin

        def _readline():
            line = raw_stdin.readline()
            if not line:
                raise EOFError()
            return line.rstrip("\r\n")

        def visible_input(prompt=None):
            sys.stdout.write(prompt or "")
            val = _readline()
            if not self.echo_stdin:
                sys.stdout.write(f"{val}\n")
            sys.stdout.flush()
            return val

        def hidden_input(prompt=None):
            sys.stdout.write(f"{prompt or ''}\n")
            sys.stdout.flush()
            if self.echo_stdin:
                raw_stdin.paused = True
            try:
                return _readline()
            finally:
                if self.echo_stdin:
                    raw_stdin.paused = False

        def _getchar(echo):
            char = sys.stdin.read(1)
            if echo:
                sys.stdout.write(char)
            return char

        default_color = color

        def should_strip_ansi(stream=None, color=None):
            if color is None:
                return not default_color
            return not color

        old_vis, old_hid = termui.visible_prompt_func, termui.hidden_prompt_func
        old_getchar = termui._getchar
        old_strip = _compat.should_strip_ansi
        termui.visible_prompt_func = visible_input
        termui.hidden_prompt_func = hidden_input
        termui._getchar = _getchar
        _compat.should_strip_ansi = should_strip_ansi

        old_env = {}
        try:
            for key, value in env.items():
                old_env[key] = os.environ.get(key)
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            yield (out_b, err_b, bytes_output, (tmp_out, tmp_err))
        finally:
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            try:
                sys.stdout.flush()
                sys.stderr.flush()
            except Exception:
                pass
            if saved_fds is not None:
                os.dup2(saved_fds[0], 1)
                os.dup2(saved_fds[1], 2)
                os.close(saved_fds[0])
                os.close(saved_fds[1])
            sys.stdin, sys.stdout, sys.stderr = old_stdin, old_stdout, old_stderr
            termui.visible_prompt_func = old_vis
            termui.hidden_prompt_func = old_hid
            termui._getchar = old_getchar
            _compat.should_strip_ansi = old_strip
            formatting.FORCED_WIDTH = old_forced_width

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        exc_info = None
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        with self.isolation(input=input, env=env, color=color) as streams:
            out_b, err_b, bytes_output, (tmp_out, tmp_err) = streams
            return_value = None
            exception = None
            exit_code = 0
            if isinstance(args, str):
                args = shlex.split(args)
            try:
                try:
                    prog_name = extra.pop("prog_name")
                except KeyError:
                    prog_name = self.get_default_prog_name(cli)
                try:
                    return_value = cli.main(args=args or (), prog_name=prog_name, **extra)
                except SystemExit as e:
                    exc_info = sys.exc_info()
                    e_code = e.code
                    if e_code is None:
                        e_code = 0
                    if e_code != 0:
                        exception = e
                    if not isinstance(e_code, int):
                        sys.stdout.write(str(e_code))
                        sys.stdout.write("\n")
                        e_code = 1
                    exit_code = e_code
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                try:
                    sys.stdout.flush()
                    sys.stderr.flush()
                except Exception:
                    pass
                stdout = out_b.getvalue()
                stderr = err_b.getvalue()
                output = bytes_output.getvalue()
                if tmp_out is not None:
                    tmp_out.seek(0)
                    tmp_err.seek(0)
                    os_out, os_err = tmp_out.read(), tmp_err.read()
                    stdout += os_out
                    stderr += os_err
                    output += os_out + os_err
                    tmp_out.close()
                    tmp_err.close()
        return Result(runner=self, stdout_bytes=stdout, stderr_bytes=stderr, output_bytes=output,
                      return_value=return_value, exit_code=exit_code, exception=exception, exc_info=exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass
