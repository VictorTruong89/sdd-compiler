import os
import sys

from . import _compat
from ._compat import (  # noqa: F401
    KeepOpenFile, LazyFile, format_filename, open_stream, strip_ansi,
)
from .globals import get_current_context, resolve_color_default


def unstyle(text):
    return strip_ansi(text)


def echo(message=None, file=None, nl=True, err=False, color=None):
    if file is None:
        file = sys.stderr if err else sys.stdout
    if file is None:
        return
    if message is not None and not isinstance(message, (str, bytes, bytearray)):
        out = str(message)
    else:
        out = message
    if nl:
        out = out or ""
        if isinstance(out, str):
            out += "\n"
        else:
            out += b"\n"
    if not out:
        try:
            file.flush()
        except Exception:
            pass
        return
    if isinstance(out, (bytes, bytearray)):
        binary_file = _compat._find_binary_writer(file)
        if binary_file is not None:
            file.flush()
            binary_file.write(out)
            binary_file.flush()
            return
        out = bytes(out).decode("utf-8", "replace")
    if message and not isinstance(message, (bytes, bytearray)):
        color = resolve_color_default(color)
        if _compat.should_strip_ansi(file, color):
            out = strip_ansi(out)
    if _compat._is_ascii_stream(file):
        binary_file = _compat._find_binary_writer(file)
        if binary_file is not None:
            file.flush()
            binary_file.write(out.encode("utf-8"))
            binary_file.flush()
            return
    try:
        file.write(out)
    except UnicodeEncodeError:
        binary_file = _compat._find_binary_writer(file)
        if binary_file is None:
            file.write(out.encode("ascii", "replace").decode("ascii"))
        else:
            file.flush()
            binary_file.write(out.encode("utf-8"))
            binary_file.flush()
            return
    file.flush()


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    f, should_close = open_stream(filename, mode, encoding, errors, atomic=atomic)
    if not should_close:
        f = KeepOpenFile(f)
    return f


def get_app_dir(app_name, roaming=True, force_posix=False):
    def _posixify(name):
        return "-".join(name.split()).lower()

    if force_posix:
        return os.path.join(os.path.expanduser(f"~/.{_posixify(app_name)}"))
    if sys.platform.startswith("win"):
        key = "APPDATA" if roaming else "LOCALAPPDATA"
        folder = os.environ.get(key) or os.path.expanduser("~")
        return os.path.join(folder, app_name)
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~/Library/Application Support"), app_name)
    return os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config"), _posixify(app_name))


def make_str(value):
    if isinstance(value, bytes):
        try:
            return value.decode(sys.getfilesystemencoding())
        except UnicodeError:
            return value.decode("utf-8", "replace")
    return str(value)


def safecall(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception:
            pass
    return wrapper
