import contextlib
import getpass
import inspect
import io
import itertools
import math
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
import time

from . import _compat
from ._compat import is_interactive, isatty, strip_ansi
from .exceptions import Abort, OptlynException, UsageError
from .globals import resolve_color_default
from .types import Choice, convert_type
from .utils import echo

visible_prompt_func = input
hidden_prompt_func = getpass.getpass

_ansi_colors = {
    "black": 30, "red": 31, "green": 32, "yellow": 33, "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "reset": 39, "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
}
_ansi_reset_all = "\033[0m"


class ColorError(TypeError, ValueError, KeyError):
    pass


def _interpret_color(color, offset=0):
    if isinstance(color, bool):
        raise ColorError(f"Unknown color {color!r}")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise ColorError(f"Unknown color {color!r}")
        return f"{38 + offset};5;{color:d}"
    if isinstance(color, (tuple, list)):
        if len(color) != 3 or not all(isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color):
            raise ColorError(f"Unknown color {color!r}")
        r, g, b = color
        return f"{38 + offset};2;{r:d};{g:d};{b:d}"
    if isinstance(color, str) and color in _ansi_colors:
        return str(_ansi_colors[color] + offset)
    raise ColorError(f"Unknown color {color!r}")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None, italic=None,
          blink=None, reverse=None, strikethrough=None, reset=True):
    if not isinstance(text, str):
        text = str(text)
    bits = []
    if fg is not None:
        bits.append(f"\033[{_interpret_color(fg)}m")
    if bg is not None:
        bits.append(f"\033[{_interpret_color(bg, 10)}m")
    for flag, on, off in (
        (bold, 1, 22), (dim, 2, 22), (underline, 4, 24), (overline, 53, 55), (italic, 3, 23),
        (blink, 5, 25), (reverse, 7, 27), (strikethrough, 9, 29),
    ):
        if flag is not None:
            bits.append(f"\033[{on if flag else off}m")
    bits.append(text)
    if reset:
        bits.append(_ansi_reset_all)
    return "".join(bits)


def unstyle(text):
    return strip_ansi(text)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None and not isinstance(message, (bytes, bytearray)):
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def _build_prompt(text, suffix, show_default=False, default=None, show_choices=True, type=None):
    prompt = text
    if type is not None and show_choices and isinstance(type, Choice):
        prompt += f" ({', '.join(map(str, type.choices))})"
    if default is not None and show_default:
        prompt = f"{prompt} [{_format_default(default)}]"
    return f"{prompt}{suffix}"


def _format_default(default):
    if hasattr(default, "name") and isinstance(getattr(default, "name", None), str) and hasattr(default, "read"):
        return default.name
    return default


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None, value_proc=None,
           prompt_suffix=": ", show_default=True, err=False, show_choices=True):
    def prompt_func(text):
        f = hidden_prompt_func if hide_input else visible_prompt_func
        try:
            echo(text.rstrip(" "), nl=False, err=err)
            return f(" ")
        except (KeyboardInterrupt, EOFError):
            if hide_input:
                echo(None, err=err)
            raise Abort() from None

    if value_proc is None:
        value_proc = convert_type(type, default)
    prompt = _build_prompt(text, prompt_suffix, show_default and not hide_input, default, show_choices, type)
    if confirmation_prompt:
        if confirmation_prompt is True:
            confirmation_prompt = "Repeat for confirmation"
        confirmation_prompt = _build_prompt(confirmation_prompt, prompt_suffix)
    while True:
        while True:
            value = prompt_func(prompt)
            if value:
                break
            elif default is not None:
                value = default
                break
        try:
            result = value_proc(value)
        except UsageError as e:
            if hide_input:
                echo("Error: The value you entered was invalid.", err=err)
            else:
                echo(f"Error: {e.message}", err=err)
            continue
        if not confirmation_prompt:
            return result
        while True:
            value2 = prompt_func(confirmation_prompt)
            is_empty = not value and not value2
            if value2 or is_empty:
                break
        if value == value2:
            return result
        echo("Error: The two entered values do not match.", err=err)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    prompt = _build_prompt(text, prompt_suffix, show_default, "y/n" if default is None else ("Y/n" if default else "y/N"))
    while True:
        try:
            echo(prompt.rstrip(" "), nl=False, err=err)
            value = visible_prompt_func(" ").lower().strip()
        except (KeyboardInterrupt, EOFError):
            raise Abort() from None
        if value in ("y", "yes"):
            rv = True
        elif value in ("n", "no"):
            rv = False
        elif default is not None and value == "":
            rv = default
        else:
            echo("Error: invalid input", err=err)
            continue
        break
    if abort and not rv:
        raise Abort()
    return rv


# ---------------------------------------------------------------- pager

class _PagerStream:
    def __init__(self, write, color, strip_default):
        self._write = write
        self._color = color
        self._strip_default = strip_default
        self.closed = False

    def write(self, text):
        if not isinstance(text, str):
            text = str(text)
        strip = (not self._color) if self._strip_default is None else self._strip_default
        if strip:
            text = strip_ansi(text)
        self._write(text)
        return len(text)

    def writelines(self, lines):
        for line in lines:
            self.write(line)

    def flush(self):
        pass

    def isatty(self):
        return False


def _pager_command():
    cmd = (os.environ.get("PAGER") or "").strip()
    if cmd:
        return cmd
    for name in ("less", "more"):
        if shutil.which(name):
            return name
    return None


@contextlib.contextmanager
def get_pager_file(color=None):
    color = resolve_color_default(color)
    if not is_interactive():
        def w(text):
            echo(text, nl=False, color=color)
        yield _PagerStream(w, color, strip_default=False)
        return
    cmd = _pager_command()
    if cmd is None:
        def w(text):
            echo(text, nl=False, color=color)
        yield _PagerStream(w, color, strip_default=False)
        return
    env = dict(os.environ)
    if color and "LESS" not in env:
        env["LESS"] = "-R"
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, env=env)
    broken = []

    def w(text):
        if broken:
            return
        try:
            proc.stdin.write(text.encode("utf-8", "replace"))
            proc.stdin.flush()
        except (BrokenPipeError, OSError):
            broken.append(1)

    try:
        yield _PagerStream(w, color, strip_default=None)
    finally:
        try:
            proc.stdin.close()
        except (BrokenPipeError, OSError):
            pass
        while True:
            try:
                proc.wait()
                break
            except KeyboardInterrupt:
                pass


def echo_via_pager(text_or_generator, color=None):
    if inspect.isgeneratorfunction(text_or_generator) or (callable(text_or_generator) and not isinstance(text_or_generator, str)):
        i = text_or_generator()
    elif isinstance(text_or_generator, str):
        i = [text_or_generator]
    else:
        i = iter(text_or_generator)
    chunks = (el if isinstance(el, str) else str(el) for el in i)
    with get_pager_file(color=color) as f:
        for chunk in itertools.chain(chunks, ["\n"]):
            f.write(chunk)


# ---------------------------------------------------------------- progress bar

class ProgressBar:
    def __init__(self, iterable, length=None, fill_char="#", empty_char="-", bar_template="%(label)s  [%(bar)s]  %(info)s",
                 info_sep="  ", show_eta=True, show_percent=None, show_pos=False, item_show_func=None,
                 label=None, file=None, color=None, update_min_steps=1, width=36, hidden=False):
        self.fill_char = fill_char
        self.empty_char = empty_char
        self.bar_template = bar_template
        self.info_sep = info_sep
        self.show_eta = show_eta
        self.show_percent = show_percent
        self.show_pos = show_pos
        self.item_show_func = item_show_func
        self.label = label or ""
        if file is None:
            file = sys.stdout
        self.file = file
        self.color = color
        self.update_min_steps = update_min_steps
        self._completed_intervals = 0
        self.width = width
        self.hidden = hidden
        self.autowidth = width == 0
        if length is None:
            try:
                length = len(iterable)
            except (TypeError, AttributeError):
                length = None
        if iterable is None:
            if length is None:
                raise TypeError("iterable or length is required")
            iterable = range(length)
        self.iter = iter(iterable)
        self.length = length
        self.pos = 0
        self.avg = []
        self.last_eta = 0.0
        self.start = self.last_eta = time.time()
        self.eta_known = False
        self.finished = False
        self.max_width = None
        self.entered = False
        self.current_item = None
        self.is_hidden = not isatty(self.file)
        self._last_line = None

    def __enter__(self):
        self.entered = True
        self.render_progress()
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.render_finish()

    def __iter__(self):
        if not self.entered:
            raise RuntimeError("You need to use progress bars in a with block.")
        self.render_progress()
        return self.generator()

    def __next__(self):
        return next(iter(self))

    def render_finish(self):
        if self.hidden or self.is_hidden:
            return
        self.file.write("\n")
        self.file.flush()

    @property
    def pct(self):
        if self.finished:
            return 1.0
        if not self.length:
            return 0.0
        return min(self.pos / self.length, 1.0)

    @property
    def time_per_iteration(self):
        if not self.avg:
            return 0.0
        return sum(self.avg) / float(len(self.avg))

    @property
    def eta(self):
        if self.length is not None and not self.finished:
            return self.time_per_iteration * (self.length - self.pos)
        return 0.0

    def format_eta(self):
        if self.eta_known:
            t = int(self.eta)
            seconds = t % 60
            t //= 60
            minutes = t % 60
            t //= 60
            hours = t % 24
            t //= 24
            if t > 0:
                return f"{t}d {hours:02}:{minutes:02}:{seconds:02}"
            return f"{hours:02}:{minutes:02}:{seconds:02}"
        return ""

    def format_pos(self):
        pos = str(self.pos)
        if self.length is not None:
            pos += f"/{self.length}"
        return pos

    def format_pct(self):
        return f"{int(self.pct * 100): 4}%"[1:]

    def format_bar(self):
        if self.length is not None:
            bar_length = int(self.pct * self.width)
            bar = self.fill_char * bar_length
            bar += self.empty_char * (self.width - bar_length)
        elif self.finished:
            bar = self.fill_char * self.width
        else:
            chars = list(self.empty_char * (self.width or 1))
            if self.time_per_iteration != 0:
                chars[int((math.cos(self.pos * self.time_per_iteration) / 2.0 + 0.5) * self.width)] = self.fill_char
            bar = "".join(chars)
        return bar

    def format_progress_line(self):
        show_percent = self.show_percent
        info_bits = []
        if self.length is not None and show_percent is None:
            show_percent = not self.show_pos
        if self.show_pos:
            info_bits.append(self.format_pos())
        if show_percent:
            info_bits.append(self.format_pct())
        if self.show_eta and self.eta_known and not self.finished:
            info_bits.append(self.format_eta())
        if self.item_show_func is not None:
            item_info = self.item_show_func(self.current_item)
            if item_info is not None:
                info_bits.append(item_info)
        return (self.bar_template % {
            "label": self.label, "bar": self.format_bar(), "info": self.info_sep.join(info_bits),
        }).rstrip()

    def render_progress(self):
        if self.hidden:
            return
        if self.is_hidden:
            if self._last_line != self.label:
                self._last_line = self.label
                if self.label:
                    echo(self.label, file=self.file, color=self.color)
            return
        line = self.format_progress_line()
        clear_width = len(strip_ansi(line))
        if self._last_line is not None and len(strip_ansi(self._last_line)) > clear_width:
            pass
        if line != self._last_line:
            self._last_line = line
            echo("\r" + line, file=self.file, nl=False, color=self.color)
            self.file.flush()

    def make_step(self, n_steps):
        self.pos += n_steps
        if self.length is not None and self.pos >= self.length:
            self.finished = True
        if (time.time() - self.last_eta) < 1.0:
            return
        self.last_eta = time.time()
        if self.pos:
            step = (time.time() - self.start) / self.pos
        else:
            step = time.time() - self.start
        self.avg = self.avg[-6:] + [step]
        self.eta_known = self.length is not None

    def update(self, n_steps, current_item=None):
        self.make_step(n_steps)
        if current_item is not None:
            self.current_item = current_item
        self.render_progress()

    def finish(self):
        self.eta_known = False
        self.current_item = None
        self.finished = True

    def generator(self):
        if not self.entered:
            raise RuntimeError("You need to use progress bars in a with block.")
        for rv in self.iter:
            self.current_item = rv
            yield rv
            self.update(1)
        self.finish()
        self.render_progress()


def progressbar(iterable=None, length=None, label=None, hidden=False, show_eta=True, show_percent=None,
                show_pos=False, item_show_func=None, fill_char="#", empty_char="-",
                bar_template="%(label)s  [%(bar)s]  %(info)s", info_sep="  ", width=36, file=None, color=None,
                update_min_steps=1):
    color = resolve_color_default(color)
    return ProgressBar(
        iterable=iterable, length=length, hidden=hidden, show_eta=show_eta, show_percent=show_percent,
        show_pos=show_pos, item_show_func=item_show_func, fill_char=fill_char, empty_char=empty_char,
        bar_template=bar_template, info_sep=info_sep, file=file, label=label, width=width, color=color,
        update_min_steps=update_min_steps,
    )


# ---------------------------------------------------------------- terminal

def _getchar_impl(echo_):
    import termios
    import tty
    if not isatty(sys.stdin):
        f = open("/dev/tty")
        fd = f.fileno()
    else:
        fd = sys.stdin.fileno()
        f = None
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 32).decode(getattr(sys.stdin, "encoding", None) or "utf-8", "replace")
            if echo_ and isatty(sys.stdout):
                sys.stdout.write(ch)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
            sys.stdout.flush()
    finally:
        if f is not None:
            f.close()
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    return ch


_getchar = None


def getchar(echo=False):
    f = _getchar if _getchar is not None else _getchar_impl
    return f(echo)


def pause(info=None, err=False):
    if not is_interactive():
        return
    if info is None:
        info = "Press any key to continue..."
    try:
        if info:
            echo(info, nl=False, err=err)
        try:
            getchar()
        except (KeyboardInterrupt, EOFError):
            pass
    finally:
        if info:
            echo(err=err)


def clear():
    if not isatty(sys.stdout):
        return
    echo("\033[2J\033[1;1H", nl=False)


class _EditError(OptlynException):
    pass


def _get_editor():
    for key in ("VISUAL", "EDITOR"):
        rv = os.environ.get(key)
        if rv:
            return rv
    for name in ("sensible-editor", "vim", "nano"):
        if shutil.which(name):
            return name
    return "vi"


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    editor = editor or _get_editor()
    environ = None
    if env:
        environ = os.environ.copy()
        environ.update(env)

    def run(path):
        try:
            c = subprocess.Popen(f'{editor} "{path}"', env=environ, shell=True)
            exit_code = c.wait()
            if exit_code != 0:
                raise _EditError(f"{editor}: Editing failed")
        except OSError as e:
            raise _EditError(f"{editor}: Editing failed: {e}") from e

    if filename is not None:
        run(filename)
        return None
    is_bytes = isinstance(text, (bytes, bytearray))
    if text is None:
        text = ""
    if not is_bytes:
        if text and not text.endswith("\n"):
            text += "\n"
        data = text.encode("utf-8")
    else:
        data = bytes(text)
    fd, name = tempfile.mkstemp(prefix="editor-", suffix=extension)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        old = os.path.getmtime(name) - 2
        os.utime(name, (old, old))
        timestamp = os.path.getmtime(name)
        run(name)
        if require_save and os.path.getmtime(name) == timestamp:
            return None
        with open(name, "rb") as f:
            rv = f.read()
        if is_bytes:
            return rv
        return rv.decode("utf-8-sig").replace("\r\n", "\n")
    finally:
        try:
            os.unlink(name)
        except OSError:
            pass


def launch(url, wait=False, locate=False):
    def _unquote(u):
        return u[7:] if u.startswith("file://") else u

    if locate:
        url = os.path.dirname(_unquote(url)) or "."
    opener = shutil.which("xdg-open") or "xdg-open"
    args = [opener, url]
    try:
        if wait:
            return subprocess.Popen(args).wait()
        subprocess.Popen(args)
        return 0
    except OSError:
        return 127
