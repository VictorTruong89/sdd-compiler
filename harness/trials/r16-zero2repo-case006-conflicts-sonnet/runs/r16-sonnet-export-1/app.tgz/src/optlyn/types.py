import enum
import os
import pathlib
import stat
import sys
import typing as t
import uuid
from datetime import datetime

from . import _compat
from .exceptions import BadParameter, DeclarationError
from .utils import make_str, safecall


class ParamType:
    is_composite = False
    arity = 1
    name = "param"
    envvar_list_splitter = None

    def get_metavar(self, param):
        return None

    def get_missing_message(self, param):
        return None

    def convert(self, value, param=None, ctx=None):
        return value

    def __call__(self, value, param=None, ctx=None):
        if value is not None:
            return self.convert(value, param, ctx)

    def split_envvar_value(self, rv):
        return (rv or "").split(self.envvar_list_splitter)

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def shell_complete(self, ctx, param, incomplete):
        return []


class FuncParamType(ParamType):
    def __init__(self, func):
        self.name = getattr(func, "__name__", type(func).__name__)
        self.func = func

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except ValueError:
            try:
                value = str(value)
            except UnicodeError:
                value = value.decode("utf-8", "replace")
            self.fail(value, param, ctx)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value

    def __repr__(self):
        return "UNPROCESSED"


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            enc = sys.getfilesystemencoding()
            try:
                return value.decode(enc)
            except UnicodeError:
                return value.decode("utf-8", "replace")
        return str(value)

    def __repr__(self):
        return "STRING"


class Choice(ParamType):
    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            choices = list(choices)
        self.choices = list(choices)
        self.case_sensitive = case_sensitive

    @staticmethod
    def _name(c):
        return c.name if isinstance(c, enum.Enum) else str(c)

    def get_metavar(self, param):
        return f"[{'|'.join(self._name(c) for c in self.choices)}]"

    def get_missing_message(self, param):
        return "Choose from:\n\t" + ",\n\t".join(self._name(c) for c in self.choices)

    def _norm(self, s, ctx):
        if ctx is not None and ctx.token_normalize_func is not None:
            s = ctx.token_normalize_func(s)
        if not self.case_sensitive:
            s = s.casefold()
        return s

    def convert(self, value, param=None, ctx=None):
        for c in self.choices:
            if isinstance(c, enum.Enum) and value is c:
                return c
        text = self._name(value) if isinstance(value, enum.Enum) else str(value)
        normed = self._norm(text, ctx)
        for c in self.choices:
            if self._norm(self._name(c), ctx) == normed:
                return c
        self.fail(
            f"{value!r} is not one of {', '.join(repr(self._name(c)) for c in self.choices)}.",
            param, ctx,
        )

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem
        inc = self._norm(incomplete, ctx)
        return [
            CompletionItem(self._name(c)) for c in self.choices
            if self._norm(self._name(c), ctx).startswith(inc)
        ]

    def __repr__(self):
        return f"Choice({[self._name(c) for c in self.choices]})"


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else ["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]

    def get_metavar(self, param):
        return f"[{'|'.join(self.formats)}]"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, datetime):
            return value
        for fmt in self.formats:
            try:
                return datetime.strptime(value, fmt)
            except (ValueError, TypeError):
                continue
        self.fail(f"{value!r} does not match the formats {', '.join(map(repr, self.formats))}.", param, ctx)


class _NumberParamTypeBase(ParamType):
    _number_class = int

    def convert(self, value, param=None, ctx=None):
        try:
            return self._number_class(value)
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid {self.name}.", param, ctx)


class IntParamType(_NumberParamTypeBase):
    name = "integer"
    _number_class = int

    def __repr__(self):
        return "INT"


class FloatParamType(_NumberParamTypeBase):
    name = "float"
    _number_class = float

    def __repr__(self):
        return "FLOAT"


class _NumberRangeBase(_NumberParamTypeBase):
    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        import operator
        rv = super().convert(value, param, ctx)
        lt_min = self.min is not None and (operator.le if self.min_open else operator.lt)(rv, self.min)
        gt_max = self.max is not None and (operator.ge if self.max_open else operator.gt)(rv, self.max)
        if self.clamp:
            if lt_min:
                return self._clamp(self.min, 1, self.min_open)
            if gt_max:
                return self._clamp(self.max, -1, self.max_open)
        if lt_min or gt_max:
            self.fail(f"{rv} is not in the range {self._describe_range()}.", param, ctx)
        return rv

    def _clamp(self, bound, dir, open):
        raise NotImplementedError

    def _describe_range(self):
        if self.min is None:
            op = "<" if self.max_open else "<="
            return f"x{op}{self.max}"
        if self.max is None:
            op = ">" if self.min_open else ">="
            return f"x{op}{self.min}"
        lop = "<" if self.min_open else "<="
        rop = "<" if self.max_open else "<="
        return f"{self.min}{lop}x{rop}{self.max}"


class IntRange(_NumberRangeBase):
    name = "integer range"
    _number_class = int

    def _clamp(self, bound, dir, open):
        if not open:
            return bound
        return bound + dir


class FloatRange(_NumberRangeBase):
    name = "float range"
    _number_class = float

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        super().__init__(min, max, min_open, max_open, clamp)
        if (min_open or max_open) and clamp:
            raise DeclarationError("Clamping is not supported for open bounds.")

    def _clamp(self, bound, dir, open):
        if not open:
            return bound
        raise RuntimeError("Clamping is not supported for open bounds.")


class BoolParamType(ParamType):
    name = "boolean"
    TRUE = {"1", "true", "t", "yes", "y", "on"}
    FALSE = {"0", "false", "f", "no", "n", "off"}

    def convert(self, value, param=None, ctx=None):
        if value in {False, True}:
            return bool(value)
        norm = str(value).strip().lower()
        if norm in self.TRUE:
            return True
        if norm in self.FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean. Recognized values: {', '.join(sorted(self.TRUE | self.FALSE))}", param, ctx)

    def __repr__(self):
        return "BOOL"


class UUIDParameterType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, uuid.UUID):
            return value
        value = value.strip()
        try:
            return uuid.UUID(value)
        except (ValueError, AttributeError):
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)

    def __repr__(self):
        return "UUID"


class File(ParamType):
    name = "filename"
    envvar_list_splitter = os.path.pathsep

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def resolve_lazy_flag(self, value):
        if self.lazy is not None:
            return self.lazy
        if os.fspath(value) == "-":
            return False
        if "w" in self.mode:
            return True
        return False

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        try:
            lazy = self.resolve_lazy_flag(value)
            if lazy:
                f = _compat.LazyFile(value, self.mode, self.encoding, self.errors, atomic=self.atomic)
                if ctx is not None:
                    ctx.call_on_close(f.close_intelligently)
                return f
            f, should_close = _compat.open_stream(value, self.mode, self.encoding, self.errors, atomic=self.atomic)
            if ctx is not None:
                if should_close:
                    ctx.call_on_close(safecall(f.close))
                else:
                    ctx.call_on_close(safecall(f.flush))
            if not should_close:
                f = _compat.KeepOpenFile(f)
            return f
        except OSError as e:
            self.fail(f"'{_compat.format_filename(value)}': {e.strerror}", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem
        return [CompletionItem(incomplete, type="file")]


def _is_file_like(v):
    return hasattr(v, "read") or hasattr(v, "write")


class Path(ParamType):
    envvar_list_splitter = os.path.pathsep

    def __init__(self, exists=False, file_okay=True, dir_okay=True, writable=False, readable=True,
                 resolve_path=False, allow_dash=False, path_type=None, executable=False):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.readable = readable
        self.writable = writable
        self.executable = executable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.type = path_type
        if self.file_okay and not self.dir_okay:
            self.name = "file"
        elif self.dir_okay and not self.file_okay:
            self.name = "directory"
        else:
            self.name = "path"

    def coerce_path_result(self, rv):
        if self.type is not None and not isinstance(rv, self.type):
            if self.type is str:
                rv = os.fsdecode(rv)
            elif self.type is bytes:
                rv = os.fsencode(rv)
            else:
                rv = self.type(rv)
        return rv

    def convert(self, value, param=None, ctx=None):
        rv = value
        is_dash = self.file_okay and self.allow_dash and rv in (b"-", "-")
        if not is_dash:
            if self.resolve_path:
                rv = os.path.realpath(rv)
            try:
                st = os.stat(rv)
            except OSError:
                if not self.exists:
                    return self.coerce_path_result(rv)
                self.fail(f"{self.name.capitalize()} {_compat.format_filename(value)!r} does not exist.", param, ctx)
            if not self.file_okay and stat.S_ISREG(st.st_mode):
                self.fail(f"{self.name.capitalize()} {_compat.format_filename(value)!r} is a file.", param, ctx)
            if not self.dir_okay and stat.S_ISDIR(st.st_mode):
                self.fail(f"{self.name.capitalize()} {_compat.format_filename(value)!r} is a directory.", param, ctx)
            if self.readable and not os.access(rv, os.R_OK):
                self.fail(f"{self.name.capitalize()} {_compat.format_filename(value)!r} is not readable.", param, ctx)
            if self.writable and not os.access(rv, os.W_OK):
                self.fail(f"{self.name.capitalize()} {_compat.format_filename(value)!r} is not writable.", param, ctx)
            if self.executable and not os.access(value, os.X_OK):
                self.fail(f"{self.name.capitalize()} {_compat.format_filename(value)!r} is not executable.", param, ctx)
        return self.coerce_path_result(rv)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem
        t_ = "dir" if self.dir_okay and not self.file_okay else "file"
        return [CompletionItem(incomplete, type=t_)]


class Tuple(ParamType):
    is_composite = True

    def __init__(self, types):
        self.types = [convert_type(ty) for ty in types]

    @property
    def name(self):
        return f"<{' '.join(ty.name for ty in self.types)}>"

    @property
    def arity(self):
        return len(self.types)

    def convert(self, value, param=None, ctx=None):
        len_type = len(self.types)
        len_value = len(value)
        if len_value != len_type:
            self.fail(f"{len_type} values are required, but {len_value} were given.", param=param, ctx=ctx)
        return tuple(ty(x, param, ctx) for ty, x in zip(self.types, value))


def convert_type(ty, default=None):
    guessed_type = False
    if ty is None and default is not None:
        if isinstance(default, (tuple, list)):
            if default:
                item = default[0]
                if isinstance(item, (tuple, list)):
                    ty = tuple(map(type, item))
                else:
                    ty = type(item)
        else:
            ty = type(default)
        guessed_type = True
    if isinstance(ty, tuple):
        return Tuple(ty)
    if isinstance(ty, ParamType):
        return ty
    if ty is str or ty is None:
        return STRING
    if ty is int:
        return INT
    if ty is float:
        return FLOAT
    if ty is bool:
        return BOOL
    if guessed_type:
        return UNPROCESSED if ty is not None else STRING
    if isinstance(ty, type) and issubclass(ty, ParamType):
        raise TypeError(f"Attempted to use an uninstantiated parameter type ({ty}).")
    return FuncParamType(ty)


UNPROCESSED = UnprocessedParamType()
STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParameterType()
