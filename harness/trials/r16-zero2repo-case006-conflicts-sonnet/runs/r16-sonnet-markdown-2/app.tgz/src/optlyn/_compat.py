"""Stream helpers shared by the rest of the package."""
import codecs
import io
import re
import sys

_ansi_re = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")


def strip_ansi(value):
    return _ansi_re.sub("", value)


def isatty(stream):
    try:
        return bool(stream.isatty())
    except Exception:
        return False


def should_strip_ansi(stream=None, color=None):
    if color is None:
        if stream is None:
            stream = sys.stdin
        return not isatty(stream)
    return not color


def is_ascii_encoding(encoding):
    if not encoding:
        return False
    try:
        return codecs.lookup(encoding).name == "ascii"
    except LookupError:
        return False


class NonClosingTextIOWrapper(io.TextIOWrapper):
    """A text wrapper that never closes the stream it wraps."""

    def __del__(self):
        pass

    def close(self):
        try:
            self.flush()
        except Exception:
            pass


def _wrap_std_text(stream, encoding, errors):
    buf = getattr(stream, "buffer", None)
    if buf is None:
        return stream
    cur = getattr(stream, "encoding", None)
    if encoding is None and not is_ascii_encoding(cur) and errors is None:
        return stream
    if encoding is None:
        encoding = "utf-8" if (is_ascii_encoding(cur) or not cur) else cur
    try:
        stream.flush()
    except Exception:
        pass
    return NonClosingTextIOWrapper(
        buf, encoding=encoding, errors=errors or "strict", write_through=True
    )


def get_text_stdout(encoding=None, errors=None):
    return _wrap_std_text(sys.stdout, encoding, errors)


def get_text_stderr(encoding=None, errors=None):
    return _wrap_std_text(sys.stderr, encoding, errors)


def get_text_stdin(encoding=None, errors=None):
    return _wrap_std_text(sys.stdin, encoding, errors)


def _binary(stream, name):
    buf = getattr(stream, "buffer", None)
    if buf is not None:
        return buf
    if isinstance(stream, (io.RawIOBase, io.BufferedIOBase)):
        return stream
    raise RuntimeError(f"sys.{name} has no binary stream")


def get_binary_stdout():
    return _binary(sys.stdout, "stdout")


def get_binary_stderr():
    return _binary(sys.stderr, "stderr")


def get_binary_stdin():
    return _binary(sys.stdin, "stdin")


def find_binary_writer(stream):
    if isinstance(stream, (io.RawIOBase, io.BufferedIOBase)):
        return stream
    buf = getattr(stream, "buffer", None)
    if buf is not None:
        return buf
    return None
