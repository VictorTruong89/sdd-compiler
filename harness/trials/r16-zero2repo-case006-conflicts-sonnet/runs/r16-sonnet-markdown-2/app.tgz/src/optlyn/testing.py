import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile

from . import _compat, termui, utils


class _Sink(io.RawIOBase):
    """Raw byte sink recording its own bytes and a shared interleaved stream."""

    def __init__(self, mixer, fd=None):
        super().__init__()
        self.data = io.BytesIO()
        self.mixer = mixer
        self._fd = fd

    def writable(self):
        return True

    def readable(self):
        return False

    def write(self, b):
        b = bytes(b)
        self.data.write(b)
        self.mixer.write(b)
        return len(b)

    def fileno(self):
        if self._fd is None:
            raise io.UnsupportedOperation("fileno")
        return self._fd

    def isatty(self):
        return False


class _NamedTextIOWrapper(io.TextIOWrapper):
    def __init__(self, buffer, name, mode, **kwargs):
        super().__init__(buffer, **kwargs)
        self._name = name
        self._mode = mode

    @property
    def name(self):
        return self._name

    @property
    def mode(self):
        return self._mode

    def __del__(self):
        pass


class _EchoingStdin:
    def __init__(self, input, output):
        self._input = input
        self._output = output
        self._paused = False

    def __getattr__(self, x):
        return getattr(self._input, x)

    def _echo(self, rv):
        if not self._paused:
            self._output.write(rv)
        return rv

    def read(self, n=-1):
        return self._echo(self._input.read(n))

    def read1(self, n=-1):
        return self._echo(self._input.read1(n))

    def readline(self, n=-1):
        return self._echo(self._input.readline(n))

    def readlines(self):
        return [self._echo(x) for x in self._input.readlines()]

    def __iter__(self):
        return iter(self._echo(x) for x in self._input)


def _make_input_stream(input, charset):
    if hasattr(input, "read"):
        data = input.read()
        if isinstance(data, str):
            data = data.encode(charset)
        return io.BytesIO(data)
    if input is None:
        input = b""
    elif isinstance(input, str):
        input = input.encode(charset)
    return io.BytesIO(input)


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value,
                 exit_code, exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self):
        return self.output_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    def __repr__(self):
        return f"<{type(self).__name__} {repr(self.exception) if self.exception else 'okay'}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        self.charset = charset
        self.env = env or {}
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def make_env(self, overrides=None):
        rv = dict(self.env)
        if overrides:
            rv.update(overrides)
        return rv

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        bytes_input = _make_input_stream(input, self.charset)
        old_stdin, old_stdout, old_stderr = sys.stdin, sys.stdout, sys.stderr
        old_visible, old_hidden, old_getchar = termui.visible_prompt_func, termui.hidden_prompt_func, termui._getchar
        old_strip = _compat.should_strip_ansi

        mixer = io.BytesIO()
        fd_state = None
        if self.capture == "fd":
            for s in (old_stdout, old_stderr):
                try:
                    s.flush()
                except Exception:
                    pass
            out_tmp = tempfile.TemporaryFile()
            err_tmp = tempfile.TemporaryFile()
            saved1, saved2 = os.dup(1), os.dup(2)
            os.dup2(out_tmp.fileno(), 1)
            os.dup2(err_tmp.fileno(), 2)
            fd_state = (out_tmp, err_tmp, saved1, saved2)
        out_sink = _Sink(mixer, 1 if fd_state else None)
        err_sink = _Sink(mixer, 2 if fd_state else None)

        sys.stdout = _NamedTextIOWrapper(out_sink, "<stdout>", "w", encoding=self.charset, write_through=True)
        sys.stderr = _NamedTextIOWrapper(err_sink, "<stderr>", "w", encoding=self.charset, errors="backslashreplace", write_through=True)
        if self.echo_stdin:
            echo_in = _EchoingStdin(bytes_input, sys.stdout.buffer)
        else:
            echo_in = bytes_input
        stdin = _NamedTextIOWrapper(echo_in if not self.echo_stdin else bytes_input, "<stdin>", "r", encoding=self.charset)
        sys.stdin = stdin
        text_input = stdin
        echoing = None
        if self.echo_stdin:
            # echo what is actually read, at the text level
            class _EchoText:
                def __init__(self, inner, out):
                    self.inner, self.out, self.paused = inner, out, False

                def __getattr__(self, n):
                    return getattr(self.inner, n)

                def _e(self, s):
                    if not self.paused and s:
                        sys.stdout.write(s)
                    return s

                def read(self, n=-1):
                    return self._e(self.inner.read(n))

                def readline(self, n=-1):
                    return self._e(self.inner.readline(n))

                def readlines(self, *a):
                    return [self._e(x) for x in self.inner.readlines(*a)]

                def __iter__(self):
                    return self

                def __next__(self):
                    line = self.inner.readline()
                    if not line:
                        raise StopIteration
                    return self._e(line)

            echoing = _EchoText(stdin, sys.stdout)
            sys.stdin = echoing
            text_input = echoing

        def pause(fn):
            def wrapper(*a, **k):
                if echoing is not None:
                    echoing.paused = True
                try:
                    return fn(*a, **k)
                finally:
                    if echoing is not None:
                        echoing.paused = False

            return wrapper

        @pause
        def visible_input(prompt=None):
            sys.stdout.write(prompt or "")
            try:
                line = next(iter_lines(text_input))
            except StopIteration as e:
                raise EOFError() from e
            val = line.rstrip("\r\n")
            sys.stdout.write(f"{val}\n")
            sys.stdout.flush()
            return val

        @pause
        def hidden_input(prompt=None):
            sys.stdout.write(f"{prompt or ''}\n")
            sys.stdout.flush()
            try:
                line = next(iter_lines(text_input))
            except StopIteration as e:
                raise EOFError() from e
            return line.rstrip("\r\n")

        @pause
        def _getchar(echo_):
            char = text_input.read(1)
            if echo_:
                sys.stdout.write(char)
            sys.stdout.flush()
            return char

        def iter_lines(src):
            def gen():
                line = src.readline()
                if line:
                    yield line

            return gen()

        default_color = color

        def should_strip_ansi(stream=None, color=None):
            if color is None:
                return not default_color
            return not color

        termui.visible_prompt_func = visible_input
        termui.hidden_prompt_func = hidden_input
        termui._getchar = _getchar
        _compat.should_strip_ansi = should_strip_ansi

        old_env = {}
        try:
            for key, value in self.make_env(env).items():
                old_env[key] = os.environ.get(key)
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            yield (out_sink, err_sink)
        finally:
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            try:
                sys.stdout.flush()
                sys.stderr.flush()
            except Exception:
                pass
            if fd_state is not None:
                out_tmp, err_tmp, saved1, saved2 = fd_state
                os.dup2(saved1, 1)
                os.dup2(saved2, 2)
                os.close(saved1)
                os.close(saved2)
                out_tmp.seek(0)
                err_tmp.seek(0)
                o, e = out_tmp.read(), err_tmp.read()
                out_tmp.close()
                err_tmp.close()
                out_sink.data.write(o)
                err_sink.data.write(e)
                mixer.write(o)
                mixer.write(e)
            self._mixer = mixer
            sys.stdin, sys.stdout, sys.stderr = old_stdin, old_stdout, old_stderr
            termui.visible_prompt_func = old_visible
            termui.hidden_prompt_func = old_hidden
            termui._getchar = old_getchar
            _compat.should_strip_ansi = old_strip

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        exc_info = None
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        with self.isolation(input=input, env=env, color=color) as streams:
            return_value = None
            exception = None
            exit_code = 0
            if isinstance(args, str):
                args = shlex.split(args)
            try:
                prog_name = extra.pop("prog_name", None)
                if prog_name is None:
                    prog_name = self.get_default_prog_name(cli)
                try:
                    return_value = cli.main(args=args or (), prog_name=prog_name, **extra)
                except SystemExit as e:
                    exc_info = sys.exc_info()
                    e_code = e.code
                    if e_code is None:
                        e_code = 0
                    if e_code != 0:
                        exception = e
                    if not isinstance(e_code, int):
                        sys.stdout.write(str(e_code))
                        sys.stdout.write("\n")
                        e_code = 1
                    exit_code = e_code
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                try:
                    sys.stdout.flush()
                    sys.stderr.flush()
                except Exception:
                    pass
        out_sink, err_sink = streams
        # fd-captured bytes are appended in the isolation teardown above
        return Result(
            runner=self,
            stdout_bytes=out_sink.data.getvalue(),
            stderr_bytes=err_sink.data.getvalue(),
            output_bytes=self._mixer.getvalue(),
            return_value=return_value,
            exit_code=exit_code,
            exception=exception,
            exc_info=exc_info,
        )

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass
