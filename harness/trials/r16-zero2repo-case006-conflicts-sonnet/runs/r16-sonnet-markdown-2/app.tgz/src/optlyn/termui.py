import contextlib
import inspect
import io
import itertools
import os
import shlex
import subprocess
import sys
import tempfile
import time
import math

from . import _compat
from ._compat import isatty, strip_ansi
from .exceptions import Abort, UsageError
from .globals import resolve_color_default
from .types import Choice, convert_type
from .utils import echo, format_filename

visible_prompt_func = input


def hidden_prompt_func(prompt):
    import getpass

    return getpass.getpass(prompt)


def _getchar_real(echo_):
    import termios
    import tty

    f = None
    if isatty(sys.stdin):
        fd = sys.stdin.fileno()
    else:
        f = open("/dev/tty")
        fd = f.fileno()
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            raw = os.read(fd, 1)
            if raw == b"\x1b":
                import select

                while select.select([fd], [], [], 0.02)[0]:
                    raw += os.read(fd, 1)
            else:
                # complete a multi-byte UTF-8 sequence
                b0 = raw[0]
                extra = 3 if b0 >= 0xF0 else 2 if b0 >= 0xE0 else 1 if b0 >= 0xC0 else 0
                for _ in range(extra):
                    raw += os.read(fd, 1)
            ch = raw.decode(getattr(sys.stdin, "encoding", None) or "utf-8", "replace")
            if echo_ and isatty(sys.stdout):
                sys.stdout.write(ch)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
            sys.stdout.flush()
    finally:
        if f is not None:
            f.close()
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    return ch


_getchar = None


def getchar(echo=False):
    f = _getchar if _getchar is not None else _getchar_real
    return f(echo)


def _build_prompt(text, suffix, show_default=False, default=None, show_choices=True, type=None):
    prompt = text
    if type is not None and show_choices and isinstance(type, Choice):
        prompt += f" ({', '.join(map(str, [c.name if hasattr(c, 'name') and not isinstance(c, str) else c for c in type.choices]))})"
    if default is not None and show_default:
        prompt = f"{prompt} [{_format_default(default)}]"
    return f"{prompt}{suffix}"


def _format_default(default):
    if hasattr(default, "name") and not isinstance(default, str):
        try:
            return default.name
        except Exception:
            pass
    return default


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False, show_choices=True):
    def prompt_func(text):
        f = hidden_prompt_func if hide_input else visible_prompt_func
        try:
            echo(text.rstrip(" "), nl=False, err=err)
            return f(" ")
        except (KeyboardInterrupt, EOFError):
            if hide_input:
                echo(None, err=err)
            raise Abort() from None

    if value_proc is None:
        value_proc = convert_type(type, default)

    prompt_ = _build_prompt(text, prompt_suffix, show_default, default, show_choices, type)
    if confirmation_prompt:
        if confirmation_prompt is True:
            confirmation_prompt = "Repeat for confirmation"
        confirmation_prompt = _build_prompt(confirmation_prompt, prompt_suffix)

    while True:
        while True:
            value = prompt_func(prompt_)
            if value:
                break
            elif default is not None:
                value = default
                break
        try:
            result = value_proc(value)
        except UsageError as e:
            if hide_input:
                echo("Error: The value you entered was invalid.", err=err)
            else:
                echo(f"Error: {e.message}", err=err)
            continue
        if not confirmation_prompt:
            return result
        while True:
            value2 = prompt_func(confirmation_prompt)
            is_empty = not value and not value2
            if value2 or is_empty:
                break
        if value == value2:
            return result
        echo("Error: The two entered values do not match.", err=err)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    prompt_ = _build_prompt(
        text, prompt_suffix, show_default, "y/n" if default is None else ("Y/n" if default else "y/N")
    )
    invalid_seen = False
    while True:
        try:
            echo(prompt_.rstrip(" "), nl=False, err=err)
            value = visible_prompt_func(" ").lower().strip()
        except (KeyboardInterrupt, EOFError):
            if invalid_seen:
                # an unrecognised answer counts as no once input runs out
                rv = False
                break
            raise Abort() from None
        if value in ("y", "yes"):
            rv = True
        elif value in ("n", "no"):
            rv = False
        elif value == "":
            rv = bool(default) if default is not None else None
            if rv is None:
                echo("Error: invalid input", err=err)
                invalid_seen = True
                continue
        else:
            echo("Error: invalid input", err=err)
            invalid_seen = True
            continue
        break
    if abort and not rv:
        raise Abort()
    return rv


def pause(info=None, err=False):
    if not (isatty(sys.stdin) or isatty(sys.stdout)):
        return
    if info is None:
        info = "Press any key to continue..."
    try:
        if info:
            echo(info, nl=False, err=err)
        try:
            getchar()
        except (KeyboardInterrupt, EOFError, OSError):
            pass
    finally:
        if info:
            echo(err=err)


def clear():
    if not isatty(sys.stdout):
        return
    echo("\033[2J\033[1;1H", nl=False)


# ---------------------------------------------------------------- pager

def _is_interactive():
    return isatty(sys.stdin) or isatty(sys.stdout)


class _PagerStream:
    def __init__(self, write, flush, close, strip):
        self._write = write
        self._flush = flush
        self._close = close
        self._strip = strip

    def write(self, text):
        if isinstance(text, (bytes, bytearray)):
            text = bytes(text).decode("utf-8", "replace")
        elif not isinstance(text, str):
            text = str(text)
        if self._strip:
            text = strip_ansi(text)
        self._write(text)
        return len(text)

    def writelines(self, lines):
        for line in lines:
            self.write(line)

    def flush(self):
        self._flush()

    def isatty(self):
        return False

    def writable(self):
        return True


@contextlib.contextmanager
def get_pager_file(color=None):
    stdout = sys.stdout
    if not _is_interactive():
        color = resolve_color_default(color)
        strip = _compat.should_strip_ansi(stdout, color)

        def w(t):
            echo(t, file=stdout, nl=False, color=True)

        yield _PagerStream(w, lambda: stdout.flush(), lambda: None, strip)
        stdout.flush()
        return

    cmd = os.environ.get("PAGER", "").strip()
    if not cmd:
        import shutil

        for cand in ("less", "more"):
            if shutil.which(cand):
                cmd = cand
                break
    if not cmd:
        color = resolve_color_default(color)
        strip = _compat.should_strip_ansi(stdout, color)
        yield _PagerStream(lambda t: echo(t, file=stdout, nl=False, color=True), stdout.flush, lambda: None, strip)
        stdout.flush()
        return

    env = dict(os.environ)
    base = os.path.basename(shlex.split(cmd)[0]) if cmd.split() else cmd
    if base == "less" and "LESS" not in env:
        env["LESS"] = "-R"
    color = resolve_color_default(color)
    if color is None:
        color = base == "less"
    stdout.flush()
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, env=env)
    enc = getattr(stdout, "encoding", None) or "utf-8"
    if _compat.is_ascii_encoding(enc):
        enc = "utf-8"

    def w(t):
        try:
            proc.stdin.write(t.encode(enc, "replace"))
        except (OSError, ValueError):
            pass

    def fl():
        try:
            proc.stdin.flush()
        except (OSError, ValueError):
            pass

    stream = _PagerStream(w, fl, lambda: None, not color)
    try:
        yield stream
    finally:
        try:
            proc.stdin.close()
        except (OSError, ValueError):
            pass
        while True:
            try:
                proc.wait()
                break
            except KeyboardInterrupt:
                pass


def echo_via_pager(text_or_generator, color=None):
    if inspect.isclass(text_or_generator):
        text_or_generator = text_or_generator()
    elif callable(text_or_generator):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, (str, bytes)):
        chunks = [text_or_generator]
    else:
        chunks = text_or_generator
    with get_pager_file(color=color) as pager:
        for chunk in chunks:
            pager.write(chunk if isinstance(chunk, (str, bytes)) else str(chunk))
            pager.flush()
        pager.write("\n")
        pager.flush()


# ---------------------------------------------------------------- progress

def _format_td(td):
    seconds = int(td)
    days, rem = divmod(seconds, 86400)
    hours, rem = divmod(rem, 3600)
    minutes, secs = divmod(rem, 60)
    s = f"{hours:d}:{minutes:02d}:{secs:02d}"
    if days:
        s = f"{days}d {s}"
    return s


class ProgressBar:
    def __init__(self, iterable, length=None, fill_char="#", empty_char="-",
                 bar_template="%(label)s  [%(bar)s]  %(info)s", info_sep="  ",
                 show_eta=True, show_percent=None, show_pos=False, item_show_func=None,
                 label=None, file=None, color=None, update_min_steps=1, width=36, hidden=False):
        self.fill_char = fill_char
        self.empty_char = empty_char
        self.bar_template = bar_template
        self.info_sep = info_sep
        self.show_eta = show_eta
        self.show_percent = show_percent
        self.show_pos = show_pos
        self.item_show_func = item_show_func
        self.label = label or ""
        if file is None:
            file = sys.stdout
        self.file = file
        self.color = color
        self.update_min_steps = update_min_steps
        self._completed_intervals = 0
        self.width = width
        self.autowidth = width == 0
        self.hidden = hidden
        if length is None:
            try:
                length = len(iterable)
            except (TypeError, AttributeError):
                length = None
        if iterable is None:
            if length is None:
                raise TypeError("iterable or length is required")
            iterable = range(length)
        self.iter = iter(iterable)
        self.length = length
        self.pos = 0
        self.avg = []
        self.last_eta = 0.0
        self.start = self.last_eta = time.time()
        self.eta_known = False
        self.finished = False
        self.max_width = None
        self._last_line = None
        self.current_item = None
        self.is_hidden = hidden or not isatty(self.file)

    def __enter__(self):
        self.entered = True
        self.render_progress()
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.render_finish()

    def __iter__(self):
        if not getattr(self, "entered", False):
            raise RuntimeError("You need to use progress bars in a with block.")
        self.render_progress()
        return self.generator()

    def __next__(self):
        return next(iter(self))

    def render_finish(self):
        if self.is_hidden:
            return
        self.file.write("\033[?25h\n")
        self.file.flush()

    @property
    def pct(self):
        if self.finished:
            return 1.0
        if not self.length:
            return 0.0
        return min(self.pos / self.length, 1.0)

    @property
    def time_per_iteration(self):
        if not self.avg:
            return 0.0
        return sum(self.avg) / float(len(self.avg))

    @property
    def eta(self):
        if self.length is not None and not self.finished and self.pos:
            return (time.time() - self.start) / self.pos * (self.length - self.pos)
        return 0.0

    def format_eta(self):
        if self.eta_known:
            return _format_td(self.eta)
        return ""

    def format_pos(self):
        pos = str(self.pos)
        if self.length is not None:
            pos += f"/{self.length}"
        return pos

    def format_pct(self):
        return f"{int(self.pct * 100): 4}%"[1:]

    def format_bar(self):
        if self.length is not None:
            bar_length = int(self.pct * self.width)
            bar = self.fill_char * bar_length
            bar += self.empty_char * (self.width - bar_length)
        elif self.finished:
            bar = self.fill_char * self.width
        else:
            chars = list(self.empty_char * (self.width or 1))
            if self.time_per_iteration != 0:
                chars[int((math.cos(self.pos * self.time_per_iteration) / 2.0 + 0.5) * self.width)] = self.fill_char
            bar = "".join(chars)
        return bar

    def format_progress_line(self):
        show_percent = self.show_percent
        info_bits = []
        if self.length is not None and show_percent is None:
            show_percent = not self.show_pos
        if self.show_pos:
            info_bits.append(self.format_pos())
        if show_percent:
            info_bits.append(self.format_pct())
        if self.show_eta and self.eta_known and not self.finished:
            info_bits.append(self.format_eta())
        if self.item_show_func is not None:
            item_info = self.item_show_func(self.current_item)
            if item_info is not None:
                info_bits.append(item_info)
        return (
            self.bar_template
            % {
                "label": self.label,
                "bar": self.format_bar(),
                "info": self.info_sep.join(info_bits),
            }
        ).rstrip()

    def render_progress(self):
        if self.hidden:
            return
        if not isatty(self.file):
            if self._last_line != self.label:
                self._last_line = self.label
                echo(self.label, file=self.file, color=self.color)
            return
        buf = []
        clear_width = self.width
        if self.max_width is not None:
            clear_width = self.max_width
        buf.append("\r\033[?25l")
        line = self.format_progress_line()
        line_len = len(strip_ansi(line))
        if self.max_width is None or self.max_width < line_len:
            self.max_width = line_len
        buf.append(line)
        buf.append(" " * (clear_width - line_len))
        line = "".join(buf)
        if line != self._last_line:
            self._last_line = line
            echo(line, file=self.file, color=self.color, nl=False)
            self.file.flush()

    def make_step(self, n_steps):
        self.pos += n_steps
        if self.length is not None and self.pos >= self.length:
            self.finished = True
        now = time.time()
        delta = max(now - self.last_eta, 0.0)
        self.last_eta = now
        if self.pos:
            self.avg = self.avg[-6:] + [delta / max(n_steps, 1)]
        self.eta_known = self.length is not None and self.pos > 0

    def update(self, n_steps, current_item=None):
        self._completed_intervals += n_steps
        if current_item is not None:
            self.current_item = current_item
        if self._completed_intervals >= self.update_min_steps:
            self.make_step(self._completed_intervals)
            self.render_progress()
            self._completed_intervals = 0

    def finish(self):
        self.eta_known = False
        self.current_item = None
        self.finished = True

    def generator(self):
        if self.is_hidden:
            yield from self.iter
        else:
            for rv in self.iter:
                self.current_item = rv
                yield rv
                self.update(1)
            self.finish()
            self.render_progress()


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)


# ---------------------------------------------------------------- editor / launch

def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    if editor is None:
        editor = os.environ.get("VISUAL") or os.environ.get("EDITOR")
        if not editor:
            import shutil

            for cand in ("vim", "nano", "vi"):
                if shutil.which(cand):
                    editor = cand
                    break
            else:
                editor = "vi"
    environ = None
    if env:
        environ = os.environ.copy()
        environ.update(env)

    def run(path):
        try:
            c = subprocess.Popen(f"{editor} {shlex.quote(path)}", env=environ, shell=True)
            exit_code = c.wait()
        except OSError as e:
            from .exceptions import OptlynException

            raise OptlynException(f"{editor}: Editing failed: {e}") from e
        if exit_code != 0:
            from .exceptions import OptlynException

            raise OptlynException(f"{editor}: Editing failed")

    if filename is not None:
        run(filename)
        return None

    if text is None:
        data = b""
    elif isinstance(text, (bytes, bytearray)):
        data = bytes(text)
    else:
        data = str(text).encode("utf-8")
    fd, name = tempfile.mkstemp(prefix="editor-", suffix=extension)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        past = time.time() - 5
        os.utime(name, (past, past))
        before = os.stat(name).st_mtime_ns
        run(name)
        after = os.stat(name).st_mtime_ns
        if require_save and before == after:
            return None
        with open(name, "rb") as f:
            rv = f.read()
        if isinstance(text, (bytes, bytearray)):
            return rv
        return rv.decode("utf-8-sig").replace("\r\n", "\n")
    finally:
        try:
            os.unlink(name)
        except OSError:
            pass


def launch(url, wait=False, locate=False):
    import shutil

    if locate:
        url = os.path.dirname(os.fspath(url)) or "."
    args = ["xdg-open", os.fspath(url) if not isinstance(url, str) else url]
    try:
        if wait:
            return subprocess.Popen(args).wait()
        subprocess.Popen(args)
        return 0
    except OSError:
        return 127
