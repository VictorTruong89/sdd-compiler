import os
import re
import sys

from . import _compat
from ._compat import (
    find_binary_writer,
    get_binary_stdin,
    get_binary_stdout,
    get_text_stdin,
    get_text_stdout,
    is_ascii_encoding,
    strip_ansi,
)
from .globals import resolve_color_default

_ansi_colors = {
    "black": 30,
    "red": 31,
    "green": 32,
    "yellow": 33,
    "blue": 34,
    "magenta": 35,
    "cyan": 36,
    "white": 37,
    "reset": 39,
    "bright_black": 90,
    "bright_red": 91,
    "bright_green": 92,
    "bright_yellow": 93,
    "bright_blue": 94,
    "bright_magenta": 95,
    "bright_cyan": 96,
    "bright_white": 97,
}
_ansi_reset_all = "\033[0m"


def _interpret_color(color, offset=0):
    if isinstance(color, bool):
        raise TypeError(f"Unknown color {color!r}")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise ValueError(f"Unknown color {color!r}")
        return f"{38 + offset};5;{color:d}"
    if isinstance(color, (tuple, list)):
        if len(color) != 3 or not all(
            isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
        ):
            raise ValueError(f"Unknown color {color!r}")
        r, g, b = color
        return f"{38 + offset};2;{r:d};{g:d};{b:d}"
    if isinstance(color, str) and color in _ansi_colors:
        return str(_ansi_colors[color] + offset)
    raise ValueError(f"Unknown color {color!r}")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True):
    if not isinstance(text, str):
        text = str(text)
    bits = []
    if fg is not None:
        bits.append(f"\033[{_interpret_color(fg)}m")
    if bg is not None:
        bits.append(f"\033[{_interpret_color(bg, 10)}m")
    for val, on, off in (
        (bold, 1, 22), (dim, 2, 22), (underline, 4, 24), (overline, 53, 55),
        (italic, 3, 23), (blink, 5, 25), (reverse, 7, 27), (strikethrough, 9, 29),
    ):
        if val is not None:
            bits.append(f"\033[{on if val else off}m")
    bits.append(text)
    if reset:
        bits.append(_ansi_reset_all)
    return "".join(bits)


def unstyle(text):
    return strip_ansi(text)


def echo(message=None, file=None, nl=True, err=False, color=None):
    if file is None:
        file = sys.stderr if err else sys.stdout
    if file is None:
        return
    if message is not None and not isinstance(message, (str, bytes, bytearray)):
        out = str(message)
    else:
        out = message
    if nl:
        out = out or ""
        out = out + ("\n" if isinstance(out, str) else b"\n")
    if not out:
        try:
            file.flush()
        except Exception:
            pass
        return
    if isinstance(out, (bytes, bytearray)):
        binary = find_binary_writer(file)
        if binary is not None:
            file.flush()
            binary.write(bytes(out))
            binary.flush()
            return
        out = bytes(out).decode("utf-8", "replace")
    else:
        color = resolve_color_default(color)
        if _compat.should_strip_ansi(file, color):
            out = strip_ansi(out)
    enc = getattr(file, "encoding", None)
    buf = getattr(file, "buffer", None)
    if buf is not None and is_ascii_encoding(enc) and not out.isascii():
        file.flush()
        buf.write(out.encode("utf-8"))
        buf.flush()
        return
    try:
        file.write(out)
    except UnicodeEncodeError:
        if buf is None:
            raise
        file.flush()
        buf.write(out.encode("utf-8"))
        buf.flush()
        return
    file.flush()


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None and not isinstance(message, (bytes, bytearray)):
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def make_str(value):
    if isinstance(value, bytes):
        try:
            return value.decode(sys.getfilesystemencoding())
        except UnicodeError:
            return value.decode("utf-8", "replace")
    return str(value)


def safecall(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception:
            pass

    return wrapper


def format_filename(filename, shorten=False):
    if shorten:
        filename = os.path.basename(filename)
    else:
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        return filename.decode(sys.getfilesystemencoding() or "utf-8", "backslashreplace")
    return filename.encode("utf-8", "surrogateescape").decode("utf-8", "backslashreplace")


def get_app_dir(app_name, roaming=True, force_posix=False):
    def posixify(name):
        return "-".join(name.split()).lower()

    if sys.platform.startswith("win") and not force_posix:
        key = "APPDATA" if roaming else "LOCALAPPDATA"
        folder = os.environ.get(key) or os.path.expanduser("~")
        return os.path.join(folder, app_name)
    if force_posix:
        return os.path.join(os.path.expanduser(f"~/.{posixify(app_name)}"))
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~/Library/Application Support"), app_name)
    return os.path.join(
        os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")),
        posixify(app_name),
    )


class _AtomicFile:
    def __init__(self, f, tmp_filename, real_filename):
        self._f = f
        self._tmp_filename = tmp_filename
        self._real_filename = real_filename
        self.closed = False

    @property
    def name(self):
        return self._real_filename

    def close(self, delete=False):
        if self.closed:
            return
        self._f.close()
        if delete:
            try:
                os.remove(self._tmp_filename)
            except OSError:
                pass
        else:
            os.replace(self._tmp_filename, self._real_filename)
        self.closed = True

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.close(delete=exc_type is not None)

    def __repr__(self):
        return repr(self._f)

    def __iter__(self):
        return iter(self._f)


def open_stream(filename, mode="r", encoding=None, errors="strict", atomic=False):
    binary = "b" in mode
    filename = os.fspath(filename)
    if filename == "-":
        if any(m in mode for m in ("w", "a", "x")):
            if binary:
                return get_binary_stdout(), False
            return get_text_stdout(encoding=encoding, errors=errors), False
        if binary:
            return get_binary_stdin(), False
        return get_text_stdin(encoding=encoding, errors=errors), False
    if not atomic:
        return open(filename, mode, encoding=encoding, errors=errors), True
    if "r" in mode or "x" in mode or "a" in mode:
        raise ValueError("Cannot open file in atomic mode with read, exclusive or append mode")
    import random

    try:
        perm = os.stat(filename).st_mode
    except OSError:
        perm = None
    flags = os.O_RDWR | os.O_CREAT | os.O_EXCL
    while True:
        tmp = os.path.join(os.path.dirname(filename), f".__atomic-write{random.randrange(1 << 32):08x}")
        try:
            fd = os.open(tmp, flags, 0o666 if perm is None else perm)
            break
        except FileExistsError:
            continue
    f = open(fd, "wb" if binary else "w", **({} if binary else {"encoding": encoding, "errors": errors}))
    return _AtomicFile(f, tmp, os.path.realpath(filename)), True


class LazyFile:
    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False):
        self.name = os.fspath(filename)
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self.should_close = True
        if self.name == "-":
            self._f, self.should_close = open_stream(filename, mode, encoding, errors)
        elif "r" in mode:
            open(filename, mode).close()

    def __getattr__(self, name):
        return getattr(self.open(), name)

    def __repr__(self):
        if self._f is not None:
            return repr(self._f)
        return f"<unopened file {format_filename(self.name)!r} {self.mode}>"

    def open(self):
        if self._f is not None:
            return self._f
        try:
            rv, self.should_close = open_stream(self.name, self.mode, self.encoding, self.errors, atomic=self.atomic)
        except OSError as e:
            from .exceptions import FileError

            raise FileError(self.name, hint=e.strerror) from e
        self._f = rv
        return rv

    def close(self):
        if self._f is not None:
            self._f.close()

    def close_intelligently(self):
        if self.should_close:
            self.close()

    def __enter__(self):
        return self.open()

    def __exit__(self, exc_type, exc_value, tb):
        self.close_intelligently()

    def __iter__(self):
        self.open()
        return iter(self._f)


class KeepOpenFile:
    def __init__(self, file):
        self._file = file

    def __getattr__(self, name):
        return getattr(self._file, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        pass

    def __repr__(self):
        return repr(self._file)

    def __iter__(self):
        return iter(self._file)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    f, should_close = open_stream(filename, mode, encoding, errors, atomic=atomic)
    if not should_close:
        f = KeepOpenFile(f)
    return f


def split_arg_string(string):
    import shlex

    lex = shlex.shlex(string, posix=True)
    lex.whitespace_split = True
    lex.commenters = ""
    out = []
    try:
        for token in lex:
            out.append(token)
    except ValueError:
        out.append(lex.token)
    return out
