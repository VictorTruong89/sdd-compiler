from collections import deque

from .exceptions import BadArgumentUsage, BadOptionUsage, NoSuchOption
from .formatting import split_opt

FLAG_NEEDS_VALUE = object()


def _unpack_args(args, nargs_spec):
    args = deque(args)
    nargs_spec = deque(nargs_spec)
    rv = []
    spos = None

    def fetch(c):
        try:
            if spos is None:
                return c.popleft()
            return c.pop()
        except IndexError:
            return None

    while nargs_spec:
        nargs = fetch(nargs_spec)
        if nargs is None:
            continue
        if nargs == 1:
            rv.append(fetch(args))
        elif nargs > 1:
            x = [fetch(args) for _ in range(nargs)]
            if spos is not None:
                x.reverse()
            rv.append(tuple(x))
        elif nargs < 0:
            if spos is not None:
                raise TypeError("Cannot have two nargs < 0")
            spos = len(rv)
            rv.append(None)
    if spos is not None:
        rv[spos] = tuple(args)
        args = []
        rv[spos + 1:] = reversed(rv[spos + 1:])
    return tuple(rv), list(args)


def _normalize_opt(opt, ctx):
    if ctx is None or ctx.token_normalize_func is None:
        return opt
    prefix, opt = split_opt(opt)
    return f"{prefix}{ctx.token_normalize_func(opt)}"


class _Option:
    def __init__(self, obj, opts, dest, action=None, nargs=1, const=None):
        self._short_opts = []
        self._long_opts = []
        self.prefixes = set()
        for opt in opts:
            prefix, value = split_opt(opt)
            if not prefix:
                raise ValueError(f"Invalid start character for option ({opt})")
            self.prefixes.add(prefix[0])
            if len(prefix) == 1 and len(value) == 1:
                self._short_opts.append(opt)
            else:
                self._long_opts.append(opt)
                self.prefixes.add(prefix)
        self.dest = dest
        self.action = action or "store"
        self.nargs = nargs
        self.const = const
        self.obj = obj

    @property
    def takes_value(self):
        return self.action in ("store", "append")

    def process(self, value, state):
        a = self.action
        if a == "store":
            state.opts[self.dest] = value
        elif a == "store_const":
            state.opts[self.dest] = self.const
        elif a == "append":
            state.opts.setdefault(self.dest, []).append(value)
        elif a == "append_const":
            state.opts.setdefault(self.dest, []).append(self.const)
        elif a == "count":
            state.opts[self.dest] = state.opts.get(self.dest, 0) + 1
        else:
            raise ValueError(f"unknown action {a!r}")
        state.order.append(self.obj)


class _Argument:
    def __init__(self, obj, dest, nargs=1):
        self.dest = dest
        self.nargs = nargs
        self.obj = obj

    def process(self, value, state):
        if self.nargs > 1:
            holes = sum(1 for x in value if x is None)
            if holes == len(value):
                value = None
            elif holes != 0:
                raise BadArgumentUsage(f"Argument {self.dest!r} takes {self.nargs} values.")
        if self.nargs == -1 and self.obj.envvar is not None and value == ():
            value = None
        state.opts[self.dest] = value
        state.order.append(self.obj)


class _ParsingState:
    def __init__(self, rargs):
        self.opts = {}
        self.largs = []
        self.rargs = rargs
        self.order = []


class OptionParser:
    def __init__(self, ctx=None):
        self.ctx = ctx
        self.allow_interspersed_args = True
        self.ignore_unknown_options = False
        if ctx is not None:
            self.allow_interspersed_args = ctx.allow_interspersed_args
            self.ignore_unknown_options = ctx.ignore_unknown_options
        self._short_opt = {}
        self._long_opt = {}
        self._opt_prefixes = {"-", "--"}
        self._args = []

    def add_option(self, obj, opts, dest, action=None, nargs=1, const=None):
        opts = [_normalize_opt(opt, self.ctx) for opt in opts]
        option = _Option(obj, opts, dest, action=action, nargs=nargs, const=const)
        self._opt_prefixes.update(option.prefixes)
        for opt in option._short_opts:
            self._short_opt[opt] = option
        for opt in option._long_opts:
            self._long_opt[opt] = option

    def add_argument(self, obj, dest, nargs=1):
        self._args.append(_Argument(obj, dest=dest, nargs=nargs))

    def parse_args(self, args):
        state = _ParsingState(args)
        try:
            self._process_args_for_options(state)
            self._process_args_for_args(state)
        except (NoSuchOption, BadOptionUsage, BadArgumentUsage) as e:
            if self.ctx is None or not self.ctx.resilient_parsing:
                if e.ctx is None:
                    e.ctx = self.ctx
                    e.cmd = self.ctx.command if self.ctx else None
                raise
        return state.opts, state.largs, state.order

    def _process_args_for_args(self, state):
        pargs, args = _unpack_args(state.largs + state.rargs, [x.nargs for x in self._args])
        for idx, arg in enumerate(self._args):
            arg.process(pargs[idx], state)
        state.largs = args
        state.rargs = []

    def _process_args_for_options(self, state):
        while state.rargs:
            arg = state.rargs.pop(0)
            arglen = len(arg)
            if arg == "--":
                return
            elif arg[:1] in self._opt_prefixes and arglen > 1:
                self._process_opts(arg, state)
            elif self.allow_interspersed_args:
                state.largs.append(arg)
            else:
                state.rargs.insert(0, arg)
                return

    def _match_long_opt(self, opt, explicit_value, state):
        if opt not in self._long_opt:
            from difflib import get_close_matches

            possibilities = get_close_matches(opt, self._long_opt)
            raise NoSuchOption(opt, possibilities=possibilities, ctx=self.ctx)
        option = self._long_opt[opt]
        if option.takes_value:
            if explicit_value is not None:
                state.rargs.insert(0, explicit_value)
            value = self._get_value_from_state(opt, option, state)
        elif explicit_value is not None:
            raise BadOptionUsage(opt, f"Option {opt!r} does not take a value.", ctx=self.ctx)
        else:
            value = None
        option.process(value, state)

    def _match_short_opt(self, arg, state):
        stop = False
        i = 1
        prefix = arg[0]
        unknown = []
        for ch in arg[1:]:
            opt = _normalize_opt(f"{prefix}{ch}", self.ctx)
            option = self._short_opt.get(opt)
            i += 1
            if not option:
                if self.ignore_unknown_options:
                    unknown.append(ch)
                    continue
                raise NoSuchOption(opt, ctx=self.ctx)
            if option.takes_value:
                if i < len(arg):
                    state.rargs.insert(0, arg[i:])
                    stop = True
                value = self._get_value_from_state(opt, option, state)
            else:
                value = None
            option.process(value, state)
            if stop:
                break
        if self.ignore_unknown_options and unknown:
            state.largs.append(f"{prefix}{''.join(unknown)}")

    def _get_value_from_state(self, option_name, option, state):
        nargs = option.nargs
        if len(state.rargs) < nargs:
            if option.obj._flag_needs_value:
                value = FLAG_NEEDS_VALUE
            else:
                raise BadOptionUsage(
                    option_name,
                    f"Option {option_name!r} requires an argument." if nargs == 1
                    else f"Option {option_name!r} requires {nargs} arguments.",
                    ctx=self.ctx,
                )
        elif nargs == 1:
            nxt = state.rargs[0]
            if (
                option.obj._flag_needs_value
                and isinstance(nxt, str)
                and nxt[:1] in self._opt_prefixes
                and len(nxt) > 1
            ):
                value = FLAG_NEEDS_VALUE
            else:
                value = state.rargs.pop(0)
        else:
            value = tuple(state.rargs[:nargs])
            del state.rargs[:nargs]
        return value

    def _process_opts(self, arg, state):
        explicit_value = None
        if "=" in arg:
            long_opt, explicit_value = arg.split("=", 1)
        else:
            long_opt = arg
        norm = _normalize_opt(long_opt, self.ctx)
        try:
            self._match_long_opt(norm, explicit_value, state)
        except NoSuchOption:
            if arg[:2] not in self._opt_prefixes:
                self._match_short_opt(arg, state)
                return
            if not self.ignore_unknown_options:
                raise
            state.largs.append(arg)
