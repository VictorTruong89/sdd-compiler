"""Optlyn: the Command Line Interface Composition Kit."""
from ._compat import isatty  # noqa: F401
from .core import (
    Argument,
    Command,
    CommandCollection,
    Context,
    Group,
    Option,
    Parameter,
    ParameterSource,
)
from .decorators import (
    argument,
    command,
    confirmation_option,
    custom_version_option,
    group,
    help_option,
    make_pass_decorator,
    option,
    pass_context,
    pass_obj,
    password_option,
    version_option,
)
from .exceptions import (
    Abort,
    BadArgumentUsage,
    BadOptionUsage,
    BadParameter,
    DeclarationError,
    Exit,
    FileError,
    MissingParameter,
    NoSuchOption,
    OptlynException,
    UsageError,
)
from .formatting import HelpFormatter, wrap_text
from .globals import get_current_context
from .shell_completion import CompletionItem
from .termui import (
    clear,
    confirm,
    echo_via_pager,
    edit,
    get_pager_file,
    getchar,
    launch,
    pause,
    progressbar,
    prompt,
)
from .types import (
    BOOL,
    FLOAT,
    INT,
    STRING,
    UNPROCESSED,
    UUID,
    Choice,
    DateTime,
    File,
    FloatRange,
    IntRange,
    ParamType,
    Path,
    Tuple,
)
from .utils import echo, format_filename, get_app_dir, open_file, secho, style, unstyle

__version__ = "1.0.0"
