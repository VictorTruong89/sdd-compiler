"""Tests for Optlyn. Each test names the spec area (node ids) it covers."""

import os

import pytest

import optlyn as o
from optlyn.testing import CliRunner


@pytest.fixture
def runner():
    return CliRunner()


def test_N_000834_command_name_derived_from_function(runner):
    # FP-01: function name lowercased, underscores to dashes, suffix stripped
    @o.command()
    def do_thing_cmd():
        o.echo("ran")

    assert do_thing_cmd.name == "do-thing"
    res = runner.invoke(do_thing_cmd, [])
    assert res.exit_code == 0 and res.output == "ran\n"


def test_N_000836_explicit_name_is_only_name():
    @o.command("sync")
    def whatever():
        pass

    assert whatever.name == "sync"


def test_N_000079_callback_runs_once_and_options_are_converted(runner):
    calls = []

    @o.command()
    @o.option("--count", type=int, default=1)
    @o.argument("name")
    def hello(count, name):
        calls.append(1)
        for _ in range(count):
            o.echo(f"hi {name}")

    res = runner.invoke(hello, ["--count", "2", "bob"])
    assert res.exit_code == 0
    assert res.output == "hi bob\nhi bob\n"
    assert len(calls) == 1


def test_N_000094_unknown_option_is_usage_error(runner):
    @o.command()
    def cmd():
        raise AssertionError("callback must not run")

    res = runner.invoke(cmd, ["--nope"])
    assert res.exit_code == 2
    assert "--nope" in res.stderr


def test_N_000309_missing_required_argument_names_it(runner):
    @o.command()
    @o.argument("path")
    def cmd(path):
        raise AssertionError("callback must not run")

    res = runner.invoke(cmd, [])
    assert res.exit_code == 2
    assert "PATH" in res.stderr


def test_N_000103_help_does_not_run_callback(runner):
    @o.command()
    @o.option("--flag", is_flag=True, help="A flag.")
    def cmd(flag):
        """Describe things."""
        raise AssertionError("callback must not run")

    res = runner.invoke(cmd, ["--help"])
    assert res.exit_code == 0
    assert res.stdout.startswith("Usage: cli [OPTIONS]")
    assert "Describe things." in res.stdout
    assert "--flag" in res.stdout and "A flag." in res.stdout


def test_N_000157_group_without_subcommand_is_usage_failure(runner):
    @o.group()
    def g():
        pass

    res = runner.invoke(g, [])
    assert res.exit_code == 2
    assert "Usage:" in res.stderr


def test_N_000396_group_callback_runs_before_child(runner):
    order = []

    @o.group()
    def g():
        order.append("group")

    @g.command()
    def child():
        order.append("child")

    runner.invoke(g, ["child"])
    assert order == ["group", "child"]


def test_N_000161_missing_subcommand_with_args_is_usage_error(runner):
    @o.group(invoke_without_command=False, no_args_is_help=False)
    @o.option("--x")
    def g(x):
        raise AssertionError("group callback must not run")

    res = runner.invoke(g, ["--x", "1"])
    assert res.exit_code == 2
    assert "Missing command" in res.stderr


def test_N_000185_group_options_before_subcommand(runner):
    @o.group()
    @o.option("--debug", is_flag=True)
    def g(debug):
        pass

    @g.command()
    @o.option("--v", type=int, default=0)
    def sub(v):
        o.echo(f"sub v={v}")

    assert runner.invoke(g, ["--debug", "sub", "--v", "3"]).output == "sub v=3\n"


def test_N_000220_env_var_then_default_and_required(runner):
    @o.command()
    @o.option("--port", type=int, envvar="OPTLYN_TEST_PORT", default=8000)
    @o.option("--token", required=True, envvar="OPTLYN_TEST_TOKEN")
    def serve(port, token):
        o.echo(f"{port} {token}")

    res = runner.invoke(serve, [], env={"OPTLYN_TEST_PORT": "9000", "OPTLYN_TEST_TOKEN": "t"})
    assert res.output == "9000 t\n"
    res = runner.invoke(serve, [], env={"OPTLYN_TEST_TOKEN": "t", "OPTLYN_TEST_PORT": None})
    assert res.output == "8000 t\n"


def test_N_000236_source_reported(runner):
    seen = {}

    @o.command()
    @o.option("--a", default="x")
    @o.option("--b", default="y")
    @o.pass_context
    def cmd(ctx, a, b):
        seen["a"] = ctx.get_parameter_source("a")
        seen["b"] = ctx.get_parameter_source("b")
        seen["none"] = ctx.get_parameter_source("zzz")

    runner.invoke(cmd, ["--a", "1"])
    assert seen["a"] != seen["b"]
    assert seen["none"] is None


def test_N_000330_choice_delivers_original_member(runner):
    import enum

    class Color(enum.Enum):
        RED = 1

    @o.command()
    @o.option("--c", type=o.Choice(Color))
    def cmd(c):
        o.echo(repr(c))

    assert runner.invoke(cmd, ["--c", "RED"]).output == repr(Color.RED) + "\n"
    assert runner.invoke(cmd, ["--c", "BLUE"]).exit_code == 2


def test_N_000349_int_range_clamp_and_refuse(runner):
    rng = o.IntRange(min=1, max=5, clamp=True)
    assert rng.convert("9") == 5
    assert rng.convert("-3") == 1
    strict = o.IntRange(min=1, max=5)
    with pytest.raises(o.BadParameter):
        strict.convert("9")


def test_N_000372_float_range_open_clamp_refused():
    with pytest.raises(ValueError):
        o.FloatRange(min=0, max=1, min_open=True, clamp=True)


def test_N_000344_datetime_formats(runner):
    dt = o.DateTime()
    assert dt.convert("2024-01-02 03:04:05").hour == 3
    with pytest.raises(o.BadParameter):
        dt.convert("nope")


def test_N_000518_file_dash_is_stdin_for_read(runner):
    @o.command()
    @o.argument("f", type=o.File("r"))
    def cmd(f):
        o.echo(f.read().upper())

    res = runner.invoke(cmd, ["-"], input="abc")
    assert res.output == "ABC\n"


def test_N_000569_missing_read_file_is_usage_error(runner):
    @o.command()
    @o.argument("f", type=o.File("r"))
    def cmd(f):
        raise AssertionError

    assert runner.invoke(cmd, ["/definitely/missing/file"]).exit_code == 2


def test_N_000725_path_checks(tmp_path):
    p = o.Path(exists=True, dir_okay=False)
    with pytest.raises(o.BadParameter):
        p.convert(str(tmp_path / "missing"))
    f = tmp_path / "a.txt"
    f.write_text("x")
    assert p.convert(str(f)) == str(f)


def test_N_000750_chain_result_callback(runner):
    @o.group(chain=True)
    def ch():
        pass

    @ch.command("a")
    def ca():
        return "a"

    @ch.command("b")
    def cb():
        return "b"

    @ch.result_callback()
    def done(results):
        o.echo("|".join(results))

    assert runner.invoke(ch, ["a", "b", "a"]).output == "a|b|a\n"


def test_N_000603_group_under_chain_refused():
    @o.group(chain=True)
    def ch():
        pass

    @o.group()
    def inner():
        pass

    with pytest.raises(TypeError):
        ch.add_command(inner)


def test_N_000506_confirmation_option(runner):
    @o.command()
    @o.confirmation_option(prompt="Sure?")
    def go():
        o.echo("went")

    assert runner.invoke(go, ["--yes"]).output == "went\n"
    res = runner.invoke(go, [], input="n\n")
    assert res.exit_code == 1 and "Aborted" in res.output
    assert runner.invoke(go, [], input="y\n").output.endswith("went\n")


def test_N_000149_custom_version_is_exact(runner):
    @o.command()
    @o.custom_version_option(lambda ctx: "3.1-custom")
    def cmd():
        pass

    res = runner.invoke(cmd, ["--version"])
    assert res.exit_code == 0 and res.output == "3.1-custom\n"


def test_N_000689_completion_source_script(capsys, monkeypatch):
    from optlyn.completion import run_completion

    @o.command()
    def tool():
        pass

    assert run_completion(tool, "tool", "bash_source", []) == 0
    assert "complete" in capsys.readouterr().out
    assert run_completion(tool, "tool", "bogus_source", []) == 1


def test_N_000726_style_and_unstyle():
    s = o.style("hi", fg="red", bold=True)
    assert s != "hi" and o.unstyle(s) == "hi"
    with pytest.raises(TypeError):
        o.style("x", fg="not-a-color")


def test_N_000668_app_dir_xdg(monkeypatch, tmp_path):
    import sys

    monkeypatch.setattr(sys, "platform", "linux")
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    assert o.get_app_dir("My  App") == os.path.join(str(tmp_path), "my-app")


def test_N_000731_isolated_filesystem_creates_directory(runner):
    cwd = os.getcwd()
    with runner.isolated_filesystem() as d:
        assert os.getcwd() == d
        assert os.path.isdir(d)
    assert os.getcwd() == cwd
    assert os.path.isdir(d)  # left in place


def test_N_000504_standalone_off_propagates_and_returns(runner):
    @o.command()
    def cmd():
        return 42

    assert cmd.main([], standalone_mode=False) == 42
    with pytest.raises(o.Abort):
        @o.command()
        def cmd2():
            raise o.Abort()
        cmd2.main([], standalone_mode=False)


def test_N_001012_wrap_text_never_fails():
    from optlyn.formatting import wrap_text

    assert isinstance(wrap_text("a " * 300, width=20), str)
    assert wrap_text(None) == ""
