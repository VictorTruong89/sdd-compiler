"""Parameter types and conversion.

# spec: N-000318..N-000374 (FP-05), N-000923..N-000931 (Interface Contract 5)
"""

import datetime as _dt
import enum
import os
import uuid as _uuid

from .exceptions import Abort, BadParameter  # noqa: F401 - Abort re-exported


class ParamType:
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value

    def get_metavar(self, param=None):
        return None

    def shell_complete(self, ctx, param, incomplete):
        return []

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def __repr__(self):
        return self.name.upper()


class _StringType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        return str(value)


class _IntType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            return int(str(value).strip(), 10)
        except ValueError:
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class _FloatType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        try:
            return float(value)
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid float.", param, ctx)


_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class _BoolType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class _UUIDType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value))
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


class _UnprocessedType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


STRING = _StringType()
INT = _IntType()
FLOAT = _FloatType()
BOOL = _BoolType()
UUID = _UUIDType()
UNPROCESSED = _UnprocessedType()


class Choice(ParamType):
    """A closed list of values, or an enum.Enum subclass (matched by member name)."""

    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        self.case_sensitive = case_sensitive
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.choices = list(choices.__members__.values())
            self._tokens = list(choices.__members__.keys())
        else:
            self.choices = list(choices)
            self._tokens = [str(c) for c in self.choices]

    def get_metavar(self, param=None):
        return "[" + "|".join(self._tokens) + "]"

    def convert(self, value, param=None, ctx=None):
        if value in self.choices:
            return value
        norm = str(value)
        for original, token in zip(self.choices, self._tokens):
            a, b = (token, norm) if self.case_sensitive else (token.casefold(), norm.casefold())
            if a == b:
                return original
        choice_list = ", ".join(repr(t) for t in self._tokens)
        self.fail(f"{value!r} is not one of {choice_list}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        return [t for t in self._tokens if t.startswith(incomplete)]


_DEFAULT_DT_FORMATS = ["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(_DEFAULT_DT_FORMATS)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(str(value), fmt)
            except ValueError:
                continue
        self.fail(f"{value!r} does not match the formats {', '.join(self.formats)}.", param, ctx)


class IntRange(_IntType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        v = super().convert(value, param, ctx)
        return _range_check(self, v, param, ctx, int_mode=True)


class FloatRange(_FloatType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min_open or max_open):
            raise ValueError("clamp is only allowed when both bounds are closed")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        v = super().convert(value, param, ctx)
        return _range_check(self, v, param, ctx, int_mode=False)


def _range_check(rng, v, param, ctx, int_mode):
    lo, hi = rng.min, rng.max
    below = lo is not None and (v < lo or (rng.min_open and v == lo))
    above = hi is not None and (v > hi or (rng.max_open and v == hi))
    if not below and not above:
        return v
    if rng.clamp:
        if below:
            if rng.min_open:
                return lo + 1 if int_mode else lo
            return lo
        if rng.max_open:
            return hi - 1 if int_mode else hi
        return hi
    rng_text = _range_text(rng)
    raise BadParameter(f"{v!r} is not in the range {rng_text}.", ctx=ctx, param=param)


def _range_text(rng):
    lo = "" if rng.min is None else str(rng.min)
    hi = "" if rng.max is None else str(rng.max)
    lb = "(" if rng.min_open else "["
    rb = ")" if rng.max_open else "]"
    return f"{lb}{lo}, {hi}{rb}"


class Tuple(ParamType):
    name = "tuple"

    def __init__(self, types):
        self.types = [_as_type(t) for t in types]

    def convert(self, value, param=None, ctx=None):
        items = list(value)
        if len(items) != len(self.types):
            self.fail(f"expected {len(self.types)} values, got {len(items)}.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, items))


class File(ParamType):
    """Opens a file. Delivers an open file object; '-' is stdin/stdout."""

    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"unsupported mode {mode!r}")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        from .fileio import open_file

        try:
            return open_file(str(value), self.mode, self.encoding, self.errors,
                             lazy=self.lazy, atomic=self.atomic)
        except OSError as exc:
            self.fail(f"Could not open file {value!r}: {exc.strerror or exc}.", param, ctx)


class Path(ParamType):
    name = "path"

    def __init__(self, exists=False, file_okay=True, dir_okay=True, writable=False,
                 readable=True, resolve_path=False, allow_dash=False, path_type=None,
                 executable=False):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def convert(self, value, param=None, ctx=None):
        import pathlib

        raw = str(value)
        if self.allow_dash and raw == "-":
            result = "-"
        else:
            result = raw
            if self.resolve_path:
                result = os.path.realpath(raw)
            if self.exists or os.path.exists(result):
                self._check(result, param, ctx)
            elif self.exists:
                self.fail(f"{raw!r} does not exist.", param, ctx)
        if self.path_type is pathlib.Path:
            return pathlib.Path(result)
        return result

    def _check(self, path, param, ctx):
        if not os.path.exists(path):
            self.fail(f"{path!r} does not exist.", param, ctx)
        if os.path.isdir(path) and not self.dir_okay:
            self.fail(f"{path!r} is a directory.", param, ctx)
        if not os.path.isdir(path) and not self.file_okay:
            self.fail(f"{path!r} is a file.", param, ctx)
        if self.readable and not os.access(path, os.R_OK):
            self.fail(f"{path!r} is not readable.", param, ctx)
        if self.writable and not os.access(path, os.W_OK):
            self.fail(f"{path!r} is not writable.", param, ctx)
        if self.executable and not os.access(path, os.X_OK):
            self.fail(f"{path!r} is not executable.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        kind = "dir" if (self.dir_okay and not self.file_okay) else "file"
        return [{"value": incomplete, "type": "path", "kind": kind}]


class _FuncType(ParamType):
    """Adapts a conversion function f(token) -> value that refuses by raising ValueError."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text")

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except BadParameter:
            raise
        except ValueError as exc:
            self.fail(str(exc) or f"{value!r} is not valid.", param, ctx)


def _as_type(obj):
    """Turn a declared type spec into a ParamType instance."""
    if obj is None:
        return None
    if isinstance(obj, ParamType):
        return obj
    if isinstance(obj, type) and issubclass(obj, ParamType):
        return obj()
    if obj is str:
        return STRING
    if obj is int:
        return INT
    if obj is float:
        return FLOAT
    if obj is bool:
        return BOOL
    if callable(obj):
        return _FuncType(obj)
    raise TypeError(f"not a parameter type: {obj!r}")


def infer_type(default):
    """Infer a type from a default value (FP-03/FP-05)."""
    if isinstance(default, bool):
        return BOOL
    if isinstance(default, int):
        return INT
    if isinstance(default, float):
        return FLOAT
    if isinstance(default, (tuple, list)) and default:
        return infer_type(default[0])
    return None
