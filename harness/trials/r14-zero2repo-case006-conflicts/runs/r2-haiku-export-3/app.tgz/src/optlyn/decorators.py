"""Declaration decorators, callback decorators, and ready-made options.

# spec: N-000868..N-000922 (Interface Contract 4), N-000957..N-000959 (pass decorators),
#       N-000103..N-000156 (FP-02 help/version), N-000474..N-000509 (FP-08)
"""

import functools
import importlib.metadata as _md

from .context import Exit, get_current_context
from .help import format_help
from .params import Argument, Option
from .terminal import confirm, echo
from .types import STRING


def _attach(f, param):
    if not hasattr(f, "__optlyn_params__"):
        f.__optlyn_params__ = []
    f.__optlyn_params__.append(param)
    return f


def take_params(f):
    """Move declarations off a function (used when a command or group is created)."""
    params = getattr(f, "__optlyn_params__", [])
    try:
        del f.__optlyn_params__
    except AttributeError:
        pass
    # decorators apply bottom-up, so reverse to get declaration order
    return list(reversed(params))


def option(*param_decls, cls=None, **attrs):
    cls = cls or Option

    def decorator(f):
        return _attach(f, cls(param_decls, **attrs))

    return decorator


def argument(*param_decls, cls=None, **attrs):
    cls = cls or Argument

    def decorator(f):
        return _attach(f, cls(param_decls, **attrs))

    return decorator


def pass_context(f):
    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(f):
    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type, ensure=False):
    def decorator(f):
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            obj = ctx.find_object(object_type)
            if obj is None and ensure:
                obj = object_type()
                ctx.obj = obj
            if obj is None:
                raise RuntimeError(f"Managed to invoke callback without a context object of "
                                   f"type {object_type.__name__!r} existing.")
            return f(obj, *args, **kwargs)

        return new_func

    return decorator


# --- ready-made options -------------------------------------------------------

def _show_help(ctx, param, value):
    if not value:
        return
    echo(format_help(ctx), nl=False)
    raise Exit(0)


def make_help_option(decls=("--help",), **kwargs):
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _show_help)
    return Option(tuple(decls), **kwargs)


def help_option(*param_decls, **kwargs):
    decls = param_decls or ("--help",)

    def decorator(f):
        return _attach(f, make_help_option(decls, **kwargs))

    return decorator


def _detect_version(package_name):
    if package_name is None:
        return "unknown"
    try:
        return _md.version(package_name)
    except _md.PackageNotFoundError:
        pass
    # treat as an import name: find the distribution that provides it
    dists = _md.packages_distributions().get(package_name, [])
    if dists:
        return _md.version(dists[0])
    return "unknown"


def version_option(version=None, *param_decls, package_name=None, prog_name=None,
                   message=None, **kwargs):
    decls = param_decls or ("--version",)

    def callback(ctx, param, value):
        if not value:
            return
        ver = version if version is not None else _detect_version(package_name)
        prog = prog_name or ctx.find_root().info_name or "program"
        text = (message or "%(prog)s, version %(version)s") % {"prog": prog, "version": ver}
        echo(text)
        raise Exit(0)

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs.setdefault("callback", callback)

    def decorator(f):
        return _attach(f, Option(tuple(decls), **kwargs))

    return decorator


def custom_version_option(callback, *param_decls, **kwargs):
    decls = param_decls or ("--version",)

    def cb(ctx, param, value):
        if not value:
            return
        echo(callback(ctx))
        raise Exit(0)

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = cb

    def decorator(f):
        return _attach(f, Option(tuple(decls), **kwargs))

    return decorator


def password_option(*param_decls, **kwargs):
    decls = param_decls or ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("prompt_required", True)
    kwargs.setdefault("type", STRING)

    def decorator(f):
        return _attach(f, Option(tuple(decls), **kwargs))

    return decorator


def confirmation_option(*param_decls, **kwargs):
    decls = param_decls or ("--yes",)
    question = kwargs.pop("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")

    def cb(ctx, param, value):
        if value:
            return value
        return confirm(question, abort=True)

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs["callback"] = cb

    def decorator(f):
        return _attach(f, Option(tuple(decls), **kwargs))

    return decorator
