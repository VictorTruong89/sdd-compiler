"""Invocation context.

# spec: N-000424..N-000473 (FP-07), N-000932..N-000962 (Interface Contract 6),
#       N-000061..N-000063 (threading)
"""

import contextlib
import enum
import threading

from .types import Abort

_local = threading.local()


class ParameterSource(enum.Enum):
    """Where a parameter value came from. Equal sources compare equal."""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


class Exit(Exception):
    """Author clean stop with a status."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code


def _stack():
    if not hasattr(_local, "stack"):
        _local.stack = []
    return _local.stack


def get_current_context(silent=False):
    st = _stack()
    if st:
        return st[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")


_SETTING_DEFAULTS = {
    "auto_envvar_prefix": None,
    "default_map": None,
    "terminal_width": None,
    "max_content_width": 80,
    "help_option_names": None,
    "token_normalize_func": None,
    "color": None,
    "show_default": None,
    "allow_extra_args": None,
    "ignore_unknown_options": None,
    "allow_interspersed_args": None,
}


class Context:
    def __init__(self, command, parent=None, info_name=None, obj=None, **settings):
        self.command = command
        self.parent = parent
        self.info_name = info_name
        self.params = {}
        self.args = []
        self.invoked_subcommand = None
        self._sources = {}
        self._close_callbacks = []
        self._exit_stack = contextlib.ExitStack()
        self.obj = obj if obj is not None else (parent.obj if parent is not None else None)
        self.meta = {}
        # Subcommand names below the top-level command (FP-07 env prefix).
        self.path_names = [] if parent is None else parent.path_names + [info_name]

        # Settings: explicit kwargs > context_settings on the command > parent
        merged = {}
        if command is not None:
            merged.update(getattr(command, "context_settings", None) or {})
        merged.update(settings)
        for key, default in _SETTING_DEFAULTS.items():
            if key in merged:
                setattr(self, key, merged[key])
            elif parent is not None and key not in ("default_map",):
                setattr(self, key, getattr(parent, key, default))
            else:
                setattr(self, key, default)
        if self.help_option_names is None:
            self.help_option_names = ["--help"]
        if self.allow_extra_args is None:
            self.allow_extra_args = False
        if self.ignore_unknown_options is None:
            self.ignore_unknown_options = False
        # allow_interspersed_args stays None unless set: leaves default to True,
        # groups default to False (FP-03).
        if self.show_default is None:
            self.show_default = False
        # default_map: a nested child map is selected by the parent; here we
        # just take what the caller supplied (or the command's own default).
        if "default_map" in merged:
            self.default_map = merged["default_map"]
        elif parent is not None and parent.default_map is not None and info_name is not None:
            self.default_map = parent.default_map.get(info_name)
        else:
            self.default_map = None
        if self.auto_envvar_prefix is None and parent is not None:
            self.auto_envvar_prefix = parent.auto_envvar_prefix

    # --- sources -----------------------------------------------------------
    def _set_source(self, name, source):
        self._sources[name] = source

    def get_parameter_source(self, name):
        """None for an undeclared name, otherwise a ParameterSource (or None if unknown)."""
        declared = {p.name for p in self.command.params} if self.command else set()
        if name not in declared:
            return None
        return self._sources.get(name)

    # --- resources ---------------------------------------------------------
    def with_resource(self, cm):
        return self._exit_stack.enter_context(cm)

    def call_on_close(self, f):
        self._exit_stack.callback(f)

    def close(self):
        self._exit_stack.close()

    # --- control -----------------------------------------------------------
    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def invoke(self, cmd, **values):
        """Run another command with exactly the values given (no parsing)."""
        from .commands import invoke_with_values

        sub = Context(cmd, parent=self, info_name=cmd.name, obj=self.obj)
        with sub:
            return invoke_with_values(sub, cmd, values)

    def forward(self, cmd, **values):
        """Run another command, filling its parameters from this context's params."""
        merged = dict(self.params)
        merged.update(values)
        return self.invoke(cmd, **merged)

    # --- thread-local current context --------------------------------------
    def __enter__(self):
        _stack().append(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        st = _stack()
        if st and st[-1] is self:
            st.pop()
        return False

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type):
        node = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None
