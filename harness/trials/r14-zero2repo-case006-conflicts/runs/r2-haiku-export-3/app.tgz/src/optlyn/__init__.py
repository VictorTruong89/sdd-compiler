"""Optlyn: composable command line interfaces.

Public surface per Interface Contract section 1.
"""

from .commands import Command, CommandCollection, Group, command, group
from .context import Context, get_current_context
from .decorators import (confirmation_option, custom_version_option, help_option,
                         make_pass_decorator, pass_context, pass_obj, password_option,
                         version_option)
from .decorators import argument as _argument_decorator
from .decorators import option as _option_decorator
from .exceptions import Abort, BadParameter
from .fileio import open_file
from .params import Argument, Option, Parameter
from .terminal import (clear, confirm, echo, echo_via_pager, edit, format_filename,
                       get_app_dir, get_pager_file, getchar, launch, pause, progressbar,
                       prompt, secho, style, unstyle)
from .types import (BOOL, FLOAT, INT, STRING, UNPROCESSED, UUID, Choice, DateTime, File,
                    FloatRange, IntRange, ParamType, Path, Tuple)

option = _option_decorator
argument = _argument_decorator

__version__ = "0.1.0"

__all__ = [
    # declaration
    "command", "group", "option", "argument", "help_option", "version_option",
    "custom_version_option", "password_option", "confirmation_option", "pass_context",
    "pass_obj", "make_pass_decorator",
    # classes
    "Command", "Group", "CommandCollection", "Context", "Option", "Parameter", "ParamType",
    "BadParameter", "Abort", "Argument",
    # types
    "STRING", "INT", "FLOAT", "BOOL", "UUID", "UNPROCESSED", "Choice", "DateTime",
    "IntRange", "FloatRange", "Tuple", "File", "Path",
    # terminal helpers
    "echo", "secho", "style", "unstyle", "echo_via_pager", "get_pager_file", "progressbar",
    "prompt", "confirm", "getchar", "pause", "edit", "launch", "clear", "get_app_dir",
    "get_current_context", "format_filename", "open_file",
]
