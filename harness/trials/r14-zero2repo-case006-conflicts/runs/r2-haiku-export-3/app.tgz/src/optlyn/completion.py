"""Shell completion: registration scripts and suggestion emission.

# spec: N-000677..N-000703 (FP-12), N-000983..N-001005 (Interface Contract 8)
"""

import os
import re

from .exceptions import UsageError
from .params import Option
from .types import Choice, Path

SHELLS = ("bash", "zsh", "fish", "powershell")
_PATH_LINE = "__optlyn_path__"


def _var_name(prog):
    return "_" + re.sub(r"[-.]", "_", prog).upper() + "_COMPLETE"


def _script(prog, shell):
    var = _var_name(prog)
    if shell == "bash":
        return (
            f"_{prog}_completion() {{\n"
            f"    local IFS=$'\\n'\n"
            f"    COMPREPLY=( $(env COMP_WORDS=\"${{COMP_WORDS[*]}}\" COMP_CWORD=$COMP_CWORD "
            f"{var}=bash_complete {prog}) )\n"
            f"    return 0\n}}\n"
            f"complete -o default -F _{prog}_completion {prog}\n"
        )
    if shell == "zsh":
        return (
            f"#compdef {prog}\n"
            f"_{prog}_completion() {{\n"
            f"    local -a completions\n"
            f"    completions=(${{(f)\"$(env COMP_WORDS=\"${{words[*]}}\" COMP_CWORD=$((CURRENT-1)) "
            f"{var}=zsh_complete {prog})\"}})\n"
            f"    _describe 'values' completions\n}}\n"
            f"compdef _{prog}_completion {prog}\n"
        )
    if shell == "fish":
        return (
            f"function _{prog}_completion\n"
            f"    set -l cmd (commandline -cp)\n"
            f"    env COMP_WORDS=\"$cmd\" COMP_CWORD=(commandline -ct) {var}=fish_complete {prog}\n"
            f"end\n"
            f"complete -program {prog} -f -a '(_{prog}_completion)'\n"
        )
    return (
        f"Register-ArgumentCompleter -Native -CommandName '{prog}' -ScriptBlock {{\n"
        f"    param($wordToComplete, $commandAst, $cursorPosition)\n"
        f"    $env:COMP_WORDS = $commandAst.ToString()\n"
        f"    $env:COMP_CWORD = $wordToComplete\n"
        f"    $env:{var} = 'powershell_complete'\n"
        f"    & '{prog}' | ForEach-Object {{ [System.Management.Automation.CompletionResult]::new($_) }}\n"
        f"    Remove-Item Env:{var}\n}}\n"
    )


def _walk(cmd, tokens):
    """Descend through groups by the tokens already typed; return (command, ctx)."""
    from .context import Context

    ctx = Context(cmd, info_name=None)
    current = cmd
    i = 0
    while current.is_group and i < len(tokens):
        tok = tokens[i]
        if tok.startswith("-"):
            i += 1
            continue
        child = current.get_command(ctx, tok)
        if child is None:
            break
        current = child
        ctx = Context(child, parent=ctx, info_name=tok)
        i += 1
    return current, ctx


def _items_for(cmd, ctx, incomplete, prev_option):
    out = []
    if prev_option is not None and isinstance(prev_option, Option) and not prev_option.is_flag:
        return _param_items(ctx, prev_option, incomplete)
    if incomplete.startswith("-"):
        for p in cmd.params:
            if isinstance(p, Option) and not p.hidden:
                for name in p.all_names():
                    if name.startswith(incomplete):
                        out.append((name, p.help or ""))
        return out
    if cmd.is_group:
        for name in cmd.list_commands(ctx):
            child = cmd.get_command(ctx, name)
            if child is None or child.hidden or not name.startswith(incomplete):
                continue
            out.append((name, child.short_help or ""))
    for arg in cmd.arguments:
        out.extend((v, "") for v, _ in _param_items(ctx, arg, incomplete))
    return out


def _param_items(ctx, param, incomplete):
    results = param.shell_complete(ctx, incomplete)
    items = []
    for r in results or []:
        if isinstance(r, dict) and r.get("type") == "path":
            kind = r.get("kind", "file")
            items.append((f"{_PATH_LINE}:{kind}:{incomplete}", ""))
        elif isinstance(r, dict):
            items.append((r.get("value", ""), r.get("help") or ""))
        elif hasattr(r, "value"):
            items.append((r.value, getattr(r, "help", "") or ""))
        else:
            items.append((str(r), ""))
    if isinstance(param.type, Path) and not results:
        kind = "dir" if (param.type.dir_okay and not param.type.file_okay) else "file"
        items.append((f"{_PATH_LINE}:{kind}:{incomplete}", ""))
    if isinstance(param.type, Choice) and not results:
        items.extend((t, "") for t in param.type._tokens if t.startswith(incomplete))
    return items


def run_completion(cmd, prog, value, args):
    """Handle a completion variable value. Returns an exit status (0 on success)."""
    if value.endswith("_source"):
        shell = value[: -len("_source")]
        if shell not in SHELLS:
            return 1
        print(_script(prog, shell), end="")
        return 0
    if value.endswith("_complete"):
        shell = value[: -len("_complete")]
        if shell not in SHELLS:
            return 1
        return _complete(cmd, shell, args)
    return 1


def _complete(cmd, shell, _args):
    raw = os.environ.get("COMP_WORDS", "")
    words = raw.split(" ")
    cword_raw = os.environ.get("COMP_CWORD", "")
    if shell == "fish":
        incomplete = cword_raw
        before = words[1:]
    else:
        try:
            idx = int(cword_raw)
        except ValueError:
            idx = len(words)
        incomplete = words[idx] if idx < len(words) else ""
        before = [w for j, w in enumerate(words[1:], start=1) if j < idx and w]
    target, ctx = _walk(cmd, before)
    prev_option = None
    if before:
        prev = before[-1]
        if prev.startswith("-"):
            for p in target.params:
                if isinstance(p, Option) and prev in p.all_names():
                    prev_option = p
    try:
        items = _items_for(target, ctx, incomplete, prev_option)
    except UsageError:
        items = []
    seen = set()
    for value, help_text in items:
        if value in seen:
            continue
        seen.add(value)
        if shell in ("zsh", "fish") and help_text:
            print(f"{value}\t{help_text}")
        else:
            print(value)
    return 0
