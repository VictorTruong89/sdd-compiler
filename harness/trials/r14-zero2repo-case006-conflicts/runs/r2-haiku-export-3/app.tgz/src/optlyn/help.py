"""Help page rendering.

# spec: N-000103..N-000164 (FP-02), N-000812..N-000829 (Interface Contract 2)
"""

import shutil

from .formatting import first_sentence, truncate_at_formfeed, wrap_text
from .params import Option
from .types import Choice

_INDENT = "  "
_COL_GAP = 2


def command_path(ctx):
    names = []
    node = ctx
    while node is not None:
        if node.info_name is not None:
            names.append(node.info_name)
        node = node.parent
    return " ".join(reversed(names))


def _width(ctx):
    if ctx.terminal_width is not None:
        return int(ctx.terminal_width)
    detected = shutil.get_terminal_size((80, 24)).columns
    return min(detected, int(ctx.max_content_width or 80))


def usage_line(ctx):
    cmd = ctx.command
    parts = [command_path(ctx)]
    opts_placeholder = getattr(cmd, "options_metavar", "[OPTIONS]")
    if opts_placeholder:
        parts.append(opts_placeholder)
    if hasattr(cmd, "list_commands") and cmd.is_group:
        if cmd.chain:
            if cmd.invoke_without_command:
                parts.append("[COMMAND [ARGS]...]...")
            else:
                parts.append("COMMAND [ARGS]... [COMMAND [ARGS]...]...")
        else:
            cmd_placeholder = cmd.subcommand_metavar or "COMMAND [ARGS]..."
            if cmd.invoke_without_command:
                cmd_placeholder = "[" + cmd_placeholder + "]"
            parts.append(cmd_placeholder)
    for arg in cmd.arguments:
        placeholder = arg.metavar()
        if arg.variadic:
            placeholder = placeholder + "..."
        if not arg.required:
            placeholder = "[" + placeholder + "]"
        parts.append(placeholder)
    return "Usage: " + " ".join(p for p in parts if p)


def _option_entry(ctx, opt):
    names = []
    for i, a in enumerate(opt.opts):
        names.append(f"{a}/{opt.secondary_opts[i]}" if i < len(opt.secondary_opts) else a)
    head = ", ".join(names)
    metavar = opt.metavar()
    if metavar:
        head = f"{head} {metavar}"
    extras = []
    if isinstance(opt.type, Choice):
        extras.append("choices: " + ", ".join(str(t) for t in opt.type._tokens))
    show_default = opt.show_default if opt.show_default is not None else ctx.show_default
    if show_default and opt.default is not None and not (opt.is_flag and opt.default is False):
        if isinstance(show_default, str):
            extras.append(f"default: {show_default}")
        else:
            d = opt.default() if callable(opt.default) else opt.default
            extras.append(f"default: {d}")
    if opt.show_envvar and opt.envvar:
        extras.append("env var: " + ", ".join(opt.envvar))
    if opt.deprecated:
        extras.append("deprecated")
    text = opt.help or ""
    if extras:
        text = (text + " " if text else "") + "[" + "; ".join(extras) + "]"
    return head, text


def _two_col(rows, width):
    if not rows:
        return []
    left_w = min(max(len(h) for h, _ in rows), width // 2)
    lines = []
    body_w = max(width - left_w - _COL_GAP - len(_INDENT), 10)
    for head, text in rows:
        body_lines = wrap_text(text, width=body_w).split("\n") if text else []
        if len(head) <= left_w:
            first = head.ljust(left_w) + " " * _COL_GAP + (body_lines[0] if body_lines else "")
            lines.append(_INDENT + first)
            rest = body_lines[1:]
        else:
            lines.append(_INDENT + head)
            rest = body_lines
        for bl in rest:
            lines.append(_INDENT + " " * (left_w + _COL_GAP) + bl)
    return lines


def format_help(ctx):
    """Return the full help page text for ctx.command (never runs the callback)."""
    cmd = ctx.command
    width = _width(ctx)
    out = [usage_line(ctx), ""]

    desc_src = cmd.help if cmd.help is not None else truncate_at_formfeed(cmd.callback_doc)
    if desc_src:
        out.append(wrap_text(truncate_at_formfeed(desc_src), width=width))
        out.append("")

    if cmd.deprecated:
        note = cmd.deprecated if isinstance(cmd.deprecated, str) else "This command is deprecated."
        out.append(f"DEPRECATED: {note}")
        out.append("")

    arg_rows = [(a.metavar(), a.help or "") for a in cmd.arguments if a.help and not a.hidden]
    if arg_rows:
        out.append("Positional arguments:")
        out.extend(_two_col(arg_rows, width))
        out.append("")

    opt_rows = [_option_entry(ctx, p) for p in cmd.params
                if isinstance(p, Option) and not p.hidden]
    if opt_rows:
        out.append("Options:")
        out.extend(_two_col(opt_rows, width))
        out.append("")

    if cmd.is_group:
        child_rows = []
        for name in cmd.list_commands(ctx):
            child = cmd.get_command(ctx, name)
            if child is None or child.hidden:
                continue
            short = child.short_help or first_sentence(truncate_at_formfeed(child.callback_doc), 45)
            child_rows.append((name, short or ""))
        if child_rows:
            out.append("Commands:")
            out.extend(_two_col(child_rows, width))
            out.append("")

    if cmd.epilog:
        out.append(wrap_text(cmd.epilog, width=width))
        out.append("")

    return "\n".join(out).rstrip("\n") + "\n"
