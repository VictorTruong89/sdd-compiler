"""File opening with the dash-as-stdin/stdout rule and atomic/lazy modes.

# spec: N-000518..N-000535 (FP-09), N-000579..N-000581
"""

import contextlib
import io
import os
import sys
import tempfile


class _LazyFile:
    """Opens its target on first I/O (write modes default to lazy)."""

    def __init__(self, filename, mode, encoding, errors, atomic):
        self._filename = filename
        self._mode = mode
        self._encoding = encoding
        self._errors = errors
        self._atomic = atomic
        self._fh = None
        self._tmp = None

    def _open(self):
        if self._fh is not None:
            return self._fh
        binary = "b" in self._mode
        kwargs = {} if binary else {"encoding": self._encoding, "errors": self._errors}
        if self._atomic:
            d = os.path.dirname(os.path.abspath(self._filename))
            fd, self._tmp = tempfile.mkstemp(dir=d, prefix=".optlyn-")
            os.close(fd)
            self._fh = open(self._tmp, self._mode, **kwargs)
        else:
            self._fh = open(self._filename, self._mode, **kwargs)
        return self._fh

    def __getattr__(self, name):
        return getattr(self._open(), name)

    def write(self, data):
        return self._open().write(data)

    def close(self):
        if self._fh is not None:
            self._fh.close()
            if self._atomic and self._tmp is not None:
                os.replace(self._tmp, self._filename)
                self._tmp = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False


class _StdStream:
    """Standard stream wrapper: closing it does not close the process stream."""

    def __init__(self, stream):
        self._stream = stream

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


def _std(filename, mode, encoding, errors):
    writing = "w" in mode
    if "b" in mode:
        base = sys.stdout.buffer if writing else sys.stdin.buffer
        return _StdStream(base)
    base = sys.stdout if writing else sys.stdin
    if encoding is not None:
        raw = base.buffer if hasattr(base, "buffer") else base
        return _StdStream(io.TextIOWrapper(raw, encoding=encoding, errors=errors))
    return _StdStream(base)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file, or '-' for the standard stream matching the mode.

    lazy=None/False opens reads immediately; write modes are opened on first I/O
    when lazy is true. The helper opens immediately unless lazy is turned on.
    """
    filename = os.fspath(filename) if not isinstance(filename, str) else filename
    if filename == "-":
        return _std(filename, mode, encoding, errors)
    if lazy:
        return _LazyFile(filename, mode, encoding, errors, atomic)
    if atomic:
        f = _LazyFile(filename, mode, encoding, errors, True)
        f._open()
        return f
    kwargs = {} if "b" in mode else {"encoding": encoding, "errors": errors}
    return open(filename, mode, **kwargs)


@contextlib.contextmanager
def open_file_cm(filename, mode="r", **kwargs):
    f = open_file(filename, mode, **kwargs)
    try:
        yield f
    finally:
        if hasattr(f, "close"):
            f.close()
