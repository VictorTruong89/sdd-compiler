"""Exception classes and their exit classes.

# spec: N-000704..N-000723 (FP-13), N-000788..N-000796 (Interface Contract 2)
"""


class OptlynError(Exception):
    """Base class. Non-usage library errors exit with status 1."""

    exit_code = 1

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.message = message
        self.ctx = ctx

    def format_message(self):
        return self.message


class FileError(OptlynError):
    """A file that cannot be opened at first I/O (general error class)."""

    def __init__(self, filename, message, ctx=None):
        super().__init__(message, ctx=ctx)
        self.filename = filename


class UsageError(OptlynError):
    """Usage failure: exit status 2."""

    exit_code = 2

    def __init__(self, message, ctx=None, show_help=False):
        super().__init__(message, ctx=ctx)
        self.show_help = show_help


class BadParameter(UsageError):
    """Refuses a value. Raised from callbacks, ParamType.convert, or conversion functions."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx=ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        hint = self.param_hint
        if hint is None and self.param is not None:
            # declared flag names for options, the name for arguments
            hint = self.param.spell() if hasattr(self.param, "spell") else self.param.name
        if hint:
            return f"Invalid value for {hint}: {self.message}"
        return f"Invalid value: {self.message}"


class MissingParameter(UsageError):
    """A required parameter has no value from any source."""

    def __init__(self, message, ctx=None, param=None):
        super().__init__(message, ctx=ctx)
        self.param = param


class NoSuchOption(UsageError):
    """An unknown option token."""


class NoSuchCommand(UsageError):
    """An unknown subcommand name."""


class NoArgsIsHelp(UsageError):
    """Group invoked with no arguments under the no-args-is-help policy."""

    def __init__(self, message="", ctx=None):
        super().__init__(message, ctx=ctx, show_help=True)


class Abort(OptlynError):
    """Abort indication: exit status 1, distinct from usage errors."""

    exit_code = 1

    def __init__(self, message="Aborted!", ctx=None):
        super().__init__(message, ctx=ctx)
