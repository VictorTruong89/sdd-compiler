"""Terminal helpers: echo, styling, prompts, pager, progress, editor, launch.

# spec: N-000963..N-000982 (Interface Contract 7), N-000608..N-000676 (FP-11),
#       N-000474..N-000517 (FP-08)
"""

import os
import re
import subprocess
import sys
import time

from .exceptions import Abort, BadParameter
from .types import _as_type

_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]")

_COLORS = {
    "black": 30, "red": 31, "green": 32, "yellow": 33,
    "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
    "reset": 39,
}
_BG_OFFSET = 10
_SWITCHES = {
    "bold": 1, "dim": 2, "italic": 3, "underline": 4, "blink": 5,
    "reverse": 7, "strikethrough": 9, "overline": 53,
}

# Forced color state set by the invocation context (None = autodetect).
_color_override = [None]


def _is_tty(stream):
    try:
        return stream.isatty()
    except Exception:
        return False


def _color_code(color, background=False):
    if isinstance(color, str):
        if color not in _COLORS:
            raise TypeError(f"unknown color {color!r}")
        code = _COLORS[color]
        if background:
            code += _BG_OFFSET
        return str(code)
    if isinstance(color, int) and not isinstance(color, bool):
        if not 0 <= color <= 255:
            raise TypeError("color index must be 0-255")
        return f"{'48' if background else '38'};5;{color}"
    if isinstance(color, (tuple, list)) and len(color) == 3 and all(
            isinstance(c, int) and 0 <= c <= 255 for c in color):
        return f"{'48' if background else '38'};2;{color[0]};{color[1]};{color[2]}"
    raise TypeError(f"invalid color {color!r}")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True):
    """Wrap text in ANSI SGR sequences. Invalid colors raise TypeError."""
    codes = []
    if fg is not None:
        codes.append(_color_code(fg))
    if bg is not None:
        codes.append(_color_code(bg, background=True))
    flags = {"bold": bold, "dim": dim, "underline": underline, "overline": overline,
             "italic": italic, "blink": blink, "reverse": reverse,
             "strikethrough": strikethrough}
    for name, on in flags.items():
        if on is not None:
            codes.append(str(_SWITCHES[name]) if on else str(_SWITCHES[name] + 20))
    if not codes:
        return str(text)
    prefix = "\x1b[" + ";".join(codes) + "m"
    suffix = "\x1b[0m" if reset else ""
    return prefix + str(text) + suffix


def unstyle(text):
    return _ANSI_RE.sub("", str(text))


def _resolve_color(color, stream):
    if color is not None:
        return bool(color)
    if _color_override[0] is not None:
        return _color_override[0]
    return _is_tty(stream)


def _write(stream, data):
    try:
        stream.write(data)
    except UnicodeEncodeError:
        enc = getattr(stream, "encoding", None) or "ascii"
        if hasattr(stream, "buffer"):
            stream.buffer.write(data.encode("utf-8"))
            stream.buffer.flush()
        else:
            stream.write(data.encode("utf-8").decode(enc, "replace"))
    if hasattr(stream, "flush"):
        stream.flush()


def echo(message=None, file=None, nl=True, err=False, color=None):
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        if hasattr(file, "buffer"):
            file.buffer.write(message + (b"\n" if nl else b""))
            file.flush()
        else:
            _write(file, message.decode("utf-8", "replace") + ("\n" if nl else ""))
        return
    text = str(message)
    if not _resolve_color(color, file):
        text = unstyle(text)
    if nl:
        text += "\n"
    _write(file, text)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None and styles:
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False):
    """Ask for a value; re-asks until it converts or input ends (EOF -> Abort)."""
    ptype = _as_type(type) if type is not None else (
        _infer_prompt_type(default))
    out = sys.stderr if err else sys.stdout
    if default is not None and show_default:
        shown = default() if callable(default) else default
        suffix = f" [{shown}]{prompt_suffix}"
    else:
        suffix = prompt_suffix
    while True:
        _write(out, text + suffix)
        try:
            value = _read_line(hide_input)
        except EOFError:
            raise Abort()
        # Visible prompts echo the typed line into runner-captured output (FP-14).
        if not hide_input and getattr(sys.stdin, "_optlyn_capture", False) \
                and not getattr(sys.stdin, "_echo_reads", False):
            _write(out, value + "\n")
        if value == "" and default is not None:
            value = default() if callable(default) else default
            if ptype is not None and isinstance(value, str):
                value = ptype.convert(value)
            return value
        if confirmation_prompt:
            _write(out, "Repeat for confirmation" + prompt_suffix)
            try:
                again = _read_line(hide_input)
            except EOFError:
                raise Abort()
            if again != value:
                _write(out, "Error: the two entered values do not match.\n")
                continue
        if ptype is None:
            return value
        try:
            return ptype.convert(value)
        except BadParameter as exc:
            _write(out, f"Error: {exc.message}\n")


def _infer_prompt_type(default):
    from .types import infer_type

    t = infer_type(default)
    return t


def _read_line(hide_input):
    if hide_input and _is_tty(sys.stdin):
        import getpass

        return getpass.getpass("")
    line = sys.stdin.readline()
    if line == "":
        raise EOFError
    return line.rstrip("\r\n")


_YES = {"y", "yes"}
_NO = {"n", "no"}


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True,
            err=False):
    """Yes/no question. Empty answer takes the default; other answers ask again."""
    out = sys.stderr if err else sys.stdout
    suffix = " [y/N]: " if default is False else " [Y/n]: "
    if not show_default:
        suffix = prompt_suffix
    text_out = text if _is_tty(out) else unstyle(text)
    while True:
        _write(out, text_out + suffix)
        try:
            line = _read_line(False)
        except EOFError:
            raise Abort()
        answer = line.strip().lower()
        if answer == "":
            value = bool(default)
            break
        if answer in _YES:
            value = True
            break
        if answer in _NO:
            value = False
            break
        _write(out, "Error: invalid input\n")
    if not value and abort:
        raise Abort()
    return value


def getchar(echo=False):
    """Read one character from the controlling terminal (not from a pipe)."""
    try:
        import termios
        import tty

        fd = os.open("/dev/tty", os.O_RDONLY)
        try:
            old = termios.tcgetattr(fd)
            try:
                tty.setraw(fd)
                ch = os.read(fd, 1).decode("utf-8", "replace")
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
        finally:
            os.close(fd)
    except (ImportError, OSError):
        ch = sys.stdin.read(1)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04" or ch == "":
        raise EOFError()
    if echo:
        echo(ch, nl=False)
    return ch


def pause(info=None, err=False):
    """Wait for a key only when the session is interactive; otherwise return."""
    if not (_is_tty(sys.stdin) and _is_tty(sys.stdout)):
        return
    out = sys.stderr if err else sys.stdout
    echo(info if info is not None else "Press any key to continue...", file=out, nl=False, err=err)
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        raise Abort()
    echo("", file=out, err=err)


def clear():
    if _is_tty(sys.stdout):
        sys.stdout.write("\x1b[2J\x1b[H")
        sys.stdout.flush()


def echo_via_pager(text_or_generator, color=None):
    if callable(text_or_generator):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        chunks = [text_or_generator]
    else:
        chunks = text_or_generator
    interactive = _is_tty(sys.stdin) and _is_tty(sys.stdout)
    pager = os.environ.get("PAGER")
    if not interactive or not pager:
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    proc = subprocess.Popen(pager, shell=True, stdin=subprocess.PIPE)
    try:
        for chunk in chunks:
            proc.stdin.write(str(chunk).encode("utf-8"))
            proc.stdin.flush()
    finally:
        try:
            proc.stdin.close()
        except OSError:
            pass
        proc.wait()


class _PagerStream:
    def __init__(self, stream):
        self._stream = stream

    def write(self, data):
        self._stream.write(data)
        self._stream.flush()
        return len(data)

    def flush(self):
        self._stream.flush()

    def close(self):
        pass


def get_pager_file(color=None):
    from contextlib import contextmanager

    @contextmanager
    def cm():
        yield _PagerStream(sys.stdout)

    return cm()


class ProgressBar:
    """Iterable progress bar; visits every item even when hidden or non-tty."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, **options):
        self.iterable = iterable
        if length is None and iterable is not None and hasattr(iterable, "__len__"):
            length = len(iterable)
        self.length = length
        self.label = label
        self.hidden = hidden
        self.pos = 0
        self.start = time.monotonic()
        self.show = (not hidden) and _is_tty(sys.stdout)
        if label and not hidden and not self.show:
            echo(label)

    def __iter__(self):
        if self.iterable is None:
            return
        for item in self.iterable:
            yield item
            self.update(1)

    def update(self, n_steps):
        self.pos += n_steps
        if self.show and self.length:
            elapsed = time.monotonic() - self.start
            remaining = (elapsed / self.pos * (self.length - self.pos)) if self.pos else 0
            pct = min(self.pos / self.length, 1.0)
            bar = "#" * int(pct * 30)
            sys.stdout.write(f"\r{self.label or ''} [{bar:<30}] {self.pos}/{self.length} "
                             f"eta {int(remaining)}s")
            sys.stdout.flush()


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    from contextlib import contextmanager

    @contextmanager
    def cm():
        bar = ProgressBar(iterable, length, label, hidden, **options)
        try:
            yield bar
        finally:
            if bar.show:
                sys.stdout.write("\n")
                sys.stdout.flush()

    return cm()


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt",
         filename=None):
    import tempfile

    editor = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR") or "vi"
    if filename is not None:
        subprocess.call(editor.split() + [filename])
        return None
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            if text:
                f.write(text)
        before = open(path, encoding="utf-8").read()
        subprocess.call(editor.split() + [path], env=env)
        with open(path, encoding="utf-8") as f:
            after = f.read()
        if require_save and after == before:
            return None
        return after
    finally:
        os.unlink(path)


def launch(url, wait=False, locate=False):
    if sys.platform.startswith("darwin"):
        opener = ["open"]
    elif os.name == "nt":
        os.startfile(url)  # noqa: S606 - Windows only
        return 0
    else:
        opener = ["xdg-open"]
    args = opener + (["-R"] if locate and sys.platform.startswith("darwin") else []) + [url]
    proc = subprocess.Popen(args)
    if wait:
        return proc.wait()
    return 0


def get_app_dir(app_name, roaming=True, force_posix=False):
    if sys.platform == "darwin" and not force_posix:
        return os.path.join(os.path.expanduser("~"), "Library", "Application Support", app_name)
    folder = "-".join(app_name.lower().split())
    if force_posix:
        return os.path.join(os.path.expanduser("~"), "." + folder)
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
    return os.path.join(base, folder)


def format_filename(filename, shorten=False):
    if isinstance(filename, (bytes, bytearray)):
        text = os.fsdecode(bytes(filename))
    else:
        text = os.fspath(filename)
    if shorten:
        text = os.path.basename(text)
    return text.encode("utf-8", "surrogateescape").decode("utf-8", "replace")
