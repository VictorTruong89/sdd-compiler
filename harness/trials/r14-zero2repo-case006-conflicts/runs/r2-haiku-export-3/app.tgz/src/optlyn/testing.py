"""In-process runner: optlyn.testing.CliRunner.

# spec: N-000724..N-001014 (FP-14), N-001006..N-001012 (Interface Contract 9)
"""

import contextlib
import io
import os
import sys
import tempfile

from . import terminal as _terminal


class _Capture:
    """Text+bytes capture for one standard stream. Also acts as its own .buffer."""

    def __init__(self, charset, name, log):
        self.encoding = charset
        self.errors = "strict"
        self.name = name
        self._log = log
        self._bytes = bytearray()
        self._text = []

    @property
    def buffer(self):
        return self

    def write(self, data):
        if isinstance(data, (bytes, bytearray)):
            raw = bytes(data)
            text = raw.decode(self.encoding, "replace")
        else:
            text = str(data)
            raw = text.encode(self.encoding, "replace")
        self._bytes.extend(raw)
        self._text.append(text)
        self._log.append((self.name, text))
        return len(data)

    def flush(self):
        pass

    def isatty(self):
        return False

    def fileno(self):
        raise io.UnsupportedOperation("fileno")

    def getvalue(self):
        return "".join(self._text)

    def getbytes(self):
        return bytes(self._bytes)


class _Input:
    """Standard input fed from the invoke input; marks itself as runner input."""

    _optlyn_capture = True

    def __init__(self, data, charset, echo_reads, out):
        self._stream = io.StringIO(data)
        self._echo_reads = echo_reads
        self._out = out
        self.encoding = charset

    def readline(self, *a):
        line = self._stream.readline()
        if line and self._echo_reads:
            self._out.write(line)
        return line

    def read(self, n=-1):
        return self._stream.read(n)

    def isatty(self):
        return False


class Result:
    def __init__(self, runner, stdout_cap, stderr_cap, log, exit_code, exception):
        self.runner = runner
        self._stdout = stdout_cap
        self._stderr = stderr_cap
        self.output_log = log
        self.exit_code = exit_code
        self.exception = exception

    @property
    def stdout(self):
        return self._stdout.getvalue()

    @property
    def stderr(self):
        return self._stderr.getvalue()

    @property
    def stdout_bytes(self):
        return self._stdout.getbytes()

    @property
    def stderr_bytes(self):
        return self._stderr.getbytes()

    @property
    def output(self):
        return "".join(text for _, text in self.output_log)

    @property
    def output_bytes(self):
        return self.stdout_bytes + self.stderr_bytes

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        log = []
        stdout = _Capture(self.charset, "stdout", log)
        stderr = _Capture(self.charset, "stderr", log)
        if isinstance(input, bytes):
            input = input.decode(self.charset, "replace")
        stdin = _Input(input or "", self.charset, self.echo_stdin, stdout)
        merged_env = dict(self.env)
        merged_env.update(env or {})
        saved_env = {}
        for k, v in merged_env.items():
            saved_env[k] = os.environ.get(k)
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = str(v)
        old = (sys.stdin, sys.stdout, sys.stderr)
        old_override = _terminal._color_override[0]
        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
        _terminal._color_override[0] = bool(color)
        try:
            yield stdout, stderr, log
        finally:
            sys.stdin, sys.stdout, sys.stderr = old
            _terminal._color_override[0] = old_override
            for k, v in saved_env.items():
                if v is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = v

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None,
               color=False, **extra):
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if isinstance(args, str):
            import shlex

            args = shlex.split(args)
        extra.setdefault("prog_name", "cli")
        exit_code = 0
        exception = None
        with self.isolation(input=input, env=env, color=color) as (out, err, log):
            try:
                rv = cli.main(args=list(args or []), standalone_mode=extra.pop(
                    "standalone_mode", True), **extra)
                if isinstance(rv, int) and not isinstance(rv, bool):
                    exit_code = rv
            except SystemExit as exc:
                code = exc.code
                if code is None:
                    exit_code = 0
                elif isinstance(code, int):
                    exit_code = code
                else:
                    print(code, file=sys.stderr)
                    exit_code = 1
            except Exception as exc:  # noqa: BLE001 - reported on the result
                if not catch_exceptions:
                    raise
                exception = exc
                exit_code = 1
        return Result(self, out, err, log, exit_code, exception)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        path = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
