"""Parameters (options and arguments), the token parser, and value resolution.

# spec: N-000165..N-000272 (FP-03), N-000273..N-000317 (FP-04),
#       N-000434..N-000456 (FP-07 sources), N-000868..N-000922 (Interface Contract 4)
"""

import os

from .context import ParameterSource
from .exceptions import BadParameter, MissingParameter, NoSuchOption, UsageError
from .types import BOOL, File, Path, Tuple, _as_type, infer_type

_TRUE_ENV = {"true", "1", "yes", "on", "t", "y"}
_FALSE_ENV = {"false", "0", "no", "off", "f", "n", ""}

UNSET = object()
_NO_VALUE = object()  # optional-value option present without a value


def _split_decls(decls):
    """Split raw declarations into (destination, flags, secondary flags)."""
    dest = None
    flags = []
    secondary = []
    for decl in decls:
        if not decl:
            continue
        if decl[0].isalnum() or decl[0] == "_":
            if dest is not None:
                raise TypeError(f"multiple destinations declared: {dest!r} and {decl!r}")
            dest = decl
            continue
        slash = decl.find("/", 1)
        if slash > 0 and len(decl) > slash + 1 and not decl[slash + 1].isalnum():
            flags.append(decl[:slash])
            secondary.append(decl[slash + 1:])
        else:
            flags.append(decl)
    return dest, flags, secondary


def _bare(flag):
    i = 0
    while i < len(flag) and not (flag[i].isalnum() or flag[i] == "_"):
        i += 1
    return flag[i:]


def _infer_dest(flags, dest):
    if dest:
        return dest
    bare = [_bare(f) for f in flags]
    for b in bare:
        if b.isidentifier():
            return b
    longs = [b for f, b in zip(flags, bare) if len(f) - len(b) > 1 or len(b) > 1]
    return (longs or bare)[0].replace("-", "_")


class Parameter:
    param_kind = "parameter"

    def __init__(self, name, type=None, default=None, required=False, callback=None,
                 nargs=1, multiple=False, metavar=None, expose_value=True,
                 is_eager=False, envvar=None, allow_from_autoenv=True, deprecated=False,
                 help=None, hidden=False, shell_complete=None, show_default=None,
                 show_envvar=False, prompt_required=False):
        self.name = name
        self.default = default
        self.required = required
        self.callback = callback
        self.nargs = nargs
        self.multiple = multiple
        self.metavar_text = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        self.envvar = [envvar] if isinstance(envvar, str) else list(envvar or [])
        self.allow_from_autoenv = allow_from_autoenv
        self.deprecated = deprecated
        self.help = help
        self.hidden = hidden
        self.shell_complete_fn = shell_complete
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.prompt_required = prompt_required
        self.type = _as_type(type) if type is not None else None
        if self.type is None and default is not None and not callable(default):
            self.type = infer_type(default)
        if self.deprecated and self.required:
            raise TypeError(f"{name}: a deprecated parameter cannot be required")
        if not (nargs == -1 or (isinstance(nargs, int) and nargs >= 1)):
            raise TypeError(f"{name}: nargs must be a positive int or -1")
        if multiple and nargs == -1:
            raise TypeError(f"{name}: multiple cannot combine with variadic nargs")

    @property
    def variadic(self):
        return self.nargs == -1

    @property
    def arity(self):
        """Tokens per occurrence; a Tuple type sets it to the tuple length."""
        if isinstance(self.type, Tuple):
            return len(self.type.types)
        return self.nargs

    def get_default(self):
        return self.default() if callable(self.default) else self.default

    def _run_callback(self, ctx, value):
        if self.callback is None:
            return value
        try:
            return self.callback(ctx, self, value)
        except BadParameter as exc:
            if exc.param is None:
                exc.param = self
            raise

    def shell_complete(self, ctx, incomplete):
        if self.shell_complete_fn is not None:
            return self.shell_complete_fn(ctx, self, incomplete)
        if self.type is not None:
            return self.type.shell_complete(ctx, self, incomplete)
        return []


class Option(Parameter):
    param_kind = "option"

    def __init__(self, param_decls=(), cls=None, is_flag=None, flag_value=None, count=False,
                 prompt=False, hide_input=False, confirmation_prompt=False,
                 prefixes=("-",), **kwargs):
        dest, flags, secondary = _split_decls(list(param_decls))
        if not flags:
            raise TypeError("an option needs at least one flag name")
        self.opts = flags
        self.secondary_opts = secondary
        self.prefixes = tuple(prefixes)
        if is_flag is None:
            is_flag = bool(secondary) or isinstance(kwargs.get("default"), bool) or count
        self.is_flag = bool(is_flag)
        self.count = bool(count)
        self.flag_value = flag_value
        if self.is_flag and flag_value is None:
            self.flag_value = True
        # A non-flag with a flag_value takes an optional value (see FP-03).
        self.optional_value = (not self.is_flag) and flag_value is not None
        self.prompt_text = prompt if isinstance(prompt, str) else None
        self.prompt_enabled = bool(prompt)
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        if self.is_flag and not self.count and "default" not in kwargs:
            kwargs["default"] = False
        if self.count and "default" not in kwargs:
            kwargs["default"] = 0
        name = _infer_dest(flags, dest)
        super().__init__(name, **kwargs)
        if self.is_flag and self.type is None:
            self.type = BOOL
        if self.count:
            self.type = None
        if self.prompt_enabled and self.deprecated:
            raise TypeError(f"{name}: a deprecated option cannot use a prompt")
        if self.is_flag and self.prompt_enabled:
            raise TypeError(f"{name}: a flag cannot prompt")
        if self.is_flag and self.multiple:
            raise TypeError(f"{name}: a flag cannot be repeatable")

    def all_names(self):
        return self.opts + self.secondary_opts

    def spell(self):
        if self.secondary_opts:
            return " / ".join(f"{a}/{b}" for a, b in zip(self.opts, self.secondary_opts))
        return " / ".join(self.opts)

    def metavar(self):
        if self.metavar_text is not None:
            return self.metavar_text
        if self.is_flag or self.count:
            return None
        if self.type is None:
            return "TEXT"
        return self.type.get_metavar(self) or self.type.name.upper()


class Argument(Parameter):
    param_kind = "argument"

    def __init__(self, param_decls=(), cls=None, **kwargs):
        dest, _flags, _ = _split_decls(list(param_decls))
        if dest is None:
            raise TypeError("an argument needs a destination name")
        if "required" not in kwargs:
            kwargs["required"] = kwargs.get("default") is None and kwargs.get("nargs", 1) != -1
        super().__init__(dest, **kwargs)

    def metavar(self):
        if self.metavar_text is not None:
            return self.metavar_text
        return self.name.upper()


# --- value resolution ---------------------------------------------------------

def _env_names(ctx, param):
    names = list(param.envvar)
    prefix = getattr(ctx, "auto_envvar_prefix", None)
    if prefix and param.allow_from_autoenv and param.param_kind == "option":
        parts = [prefix] + list(getattr(ctx, "path_names", [])) + [param.name]
        names.append("_".join(p.replace("-", "_").upper() for p in parts))
    return names


def _env_raw(ctx, param):
    for env_name in _env_names(ctx, param):
        raw = os.environ.get(env_name)
        if raw:
            return env_name, raw
    return None, None


def _split_env(param, raw):
    if isinstance(param.type, (File, Path)):
        return [p for p in raw.split(os.pathsep) if p != ""]
    if param.multiple or param.arity != 1:
        return raw.split()
    return [raw]


def _bool_from_env(param, raw):
    text = raw.strip().lower()
    if text in _TRUE_ENV:
        return True
    if text in _FALSE_ENV:
        return False
    if isinstance(param.flag_value, str) and text == param.flag_value.lower():
        return True
    raise BadParameter(f"{raw!r} is not a valid boolean.", param=param)


def _convert_occurrence(ctx, param, tup):
    """Convert one occurrence (a tuple of tokens)."""
    if isinstance(param.type, Tuple):
        return param.type.convert(list(tup), param, ctx)
    if param.arity != 1 and param.nargs != -1:
        return tuple(_convert_token(ctx, param, t) for t in tup)
    return _convert_token(ctx, param, tup[0])


def _convert_token(ctx, param, token):
    if param.type is None:
        return token
    return param.type.convert(token, param, ctx)


def _convert_default(ctx, param, value):
    if param.multiple or param.variadic:
        if isinstance(value, (str, bytes)) or not hasattr(value, "__iter__"):
            raise BadParameter(f"{param.name!r} needs an iterable (sequence) default.", param=param)
        return tuple(_convert_token(ctx, param, v) for v in value)
    if isinstance(param.type, Tuple):
        return param.type.convert(value, param, ctx)
    if param.arity != 1 and isinstance(value, (list, tuple)):
        return tuple(_convert_token(ctx, param, v) for v in value)
    return _convert_token(ctx, param, value)


def _from_commandline(ctx, param, raw):
    occurrences = [v for _, v in raw]
    if isinstance(param, Option) and param.is_flag:
        if param.multiple:
            value = tuple(occurrences)
        else:
            value = occurrences[-1]
        return param._run_callback(ctx, value), ParameterSource.COMMANDLINE
    if any(o is _NO_VALUE for o in occurrences):
        # optional-value option without value -> flag_value
        occurrences = [param.flag_value if o is _NO_VALUE else o for o in occurrences]
    if param.variadic:
        flat = [tup for occ in occurrences for tup in ((t,) for t in occ)]
        value = tuple(_convert_token(ctx, param, t[0]) for t in flat)
    elif param.multiple:
        value = tuple(_convert_occurrence(ctx, param, o) for o in occurrences)
    else:
        value = _convert_occurrence(ctx, param, occurrences[-1])
    return param._run_callback(ctx, value), ParameterSource.COMMANDLINE


def _maybe_prompt(ctx, param, raw):
    if not isinstance(param, Option) or not param.prompt_enabled:
        return UNSET
    flag_no_value = any(v is _NO_VALUE for _, v in raw)
    if raw and not flag_no_value:
        return UNSET
    if not raw and not (param.prompt_required or param.required):
        return UNSET
    from .terminal import prompt as _prompt

    text = param.prompt_text or param.name.replace("_", " ").title()
    dm = getattr(ctx, "default_map", None)
    if isinstance(dm, dict) and param.name in dm:
        default = dm[param.name]
    else:
        default = param.default
    return _prompt(text, default=default, hide_input=param.hide_input,
                   confirmation_prompt=param.confirmation_prompt, type=param.type)


def resolve_param(ctx, param, raw):
    """Final value and source for one parameter (FP-03 ranking, FP-07, FP-08).

    Ranking: prompt, command line, environment, default map, declared default.
    Callbacks run once, with the final value.
    """
    if isinstance(param, Option) and param.count:
        total = sum(v for _, v in raw)
        return param._run_callback(ctx, total), ParameterSource.COMMANDLINE if raw else ParameterSource.DEFAULT

    if raw:
        return _from_commandline(ctx, param, raw)

    if isinstance(param, Option) and param.is_flag:
        env_name, env_raw = _env_raw(ctx, param)
        if env_raw is not None:
            return param._run_callback(ctx, _bool_from_env(param, env_raw)), ParameterSource.ENVIRONMENT
        dm = getattr(ctx, "default_map", None)
        if isinstance(dm, dict) and param.name in dm:
            return param._run_callback(ctx, bool(dm[param.name])), ParameterSource.DEFAULT_MAP
        return param._run_callback(ctx, bool(param.get_default())), ParameterSource.DEFAULT

    env_name, env_raw = _env_raw(ctx, param)
    if env_raw is not None:
        tokens = _split_env(param, env_raw)
        if tokens:
            width = max(param.arity, 1)
            occ = [tuple(tokens[i:i + width]) for i in range(0, len(tokens), width)]
            if param.variadic:
                value = tuple(_convert_token(ctx, param, t) for t in tokens)
            elif param.multiple:
                value = tuple(_convert_occurrence(ctx, param, o) for o in occ)
            else:
                value = _convert_occurrence(ctx, param, occ[-1])
            return param._run_callback(ctx, value), ParameterSource.ENVIRONMENT

    prompted = _maybe_prompt(ctx, param, raw)
    if prompted is not UNSET:
        return param._run_callback(ctx, prompted), ParameterSource.PROMPT

    dm = getattr(ctx, "default_map", None)
    if isinstance(dm, dict) and param.name in dm:
        val = dm[param.name]
        if isinstance(val, str):
            if param.multiple or param.variadic:
                raise BadParameter(f"{param.name!r} needs an iterable (sequence) default.", param=param)
            if param.arity != 1:
                val = val.split()
        return param._run_callback(ctx, _convert_default(ctx, param, val)), ParameterSource.DEFAULT_MAP

    d = param.get_default()
    if d is not None:
        return param._run_callback(ctx, _convert_default(ctx, param, d)), ParameterSource.DEFAULT

    if param.required:
        if param.param_kind == "argument":
            raise MissingParameter(f"Missing argument '{param.name.upper()}'.", param=param)
        raise MissingParameter(f"Missing option '{param.spell()}'.", param=param)

    if param.multiple or param.variadic:
        return param._run_callback(ctx, ()), ParameterSource.DEFAULT
    return param._run_callback(ctx, None), ParameterSource.DEFAULT


# --- token parser -------------------------------------------------------------

class Parser:
    """Walks a token list and gathers raw occurrences keyed by destination.

    raw[dest] is a list of (position, value). Value is a token tuple for value
    options, True/False/flag_value for flags, an int for counting options, and
    _NO_VALUE for optional-value options given without a value.
    """

    def __init__(self, params, prefixes=("-",), ignore_unknown=False):
        self.ignore_unknown = ignore_unknown
        self.prefixes = set(prefixes)
        self.by_name = {}
        self.secondary = {}
        for p in params:
            if isinstance(p, Option):
                for n in p.opts:
                    self.by_name.setdefault(n, p)
                    self.prefixes.add(n[0])
                for n in p.secondary_opts:
                    self.secondary.setdefault(n, p)
                    self.prefixes.add(n[0])

    def _option_like(self, tok):
        return len(tok) > 1 and tok[0] in self.prefixes

    def parse(self, tokens, interspersed=True, stop_at_positional=False):
        """Returns (raw, positional, stop_index)."""
        raw = {}
        positional = []
        seen_dd = False
        i = 0
        n = len(tokens)
        while i < n:
            tok = tokens[i]
            if seen_dd:
                positional.append(tok)
                i += 1
                continue
            if tok == "--":
                seen_dd = True
                i += 1
                continue
            if not self._option_like(tok):
                if stop_at_positional:
                    positional.extend(tokens[i:])
                    return raw, positional, n
                positional.append(tok)
                i += 1
                if not interspersed:
                    positional.extend(tokens[i:])
                    return raw, positional, n
                continue
            i = self._option(tokens, i, tok, raw, positional)
        return raw, positional, n

    def _add(self, raw, p, pos, value):
        raw.setdefault(p.name, []).append((pos, value))

    def _option(self, tokens, i, tok, raw, positional):
        if tok in self.secondary and tok not in self.by_name:
            self._add(raw, self.secondary[tok], i, False)
            return i + 1
        if tok in self.by_name:
            return self._flag_or_value(tokens, i, self.by_name[tok], tok, None, raw, positional)
        name, eq, attached = tok.partition("=")
        if eq and name in self.by_name:
            return self._flag_or_value(tokens, i, self.by_name[name], name, attached, raw, positional)
        if tok.startswith("--") or (tok[:2] not in self.by_name and tok[:2] not in self.secondary):
            if self.ignore_unknown:
                positional.append(tok)
                return i + 1
            raise NoSuchOption(f"No such option: {name}")
        return self._stack(tokens, i, tok, raw, positional)

    def _flag_or_value(self, tokens, i, p, name, attached, raw, positional):
        if p.is_flag:
            if attached is not None:
                raise UsageError(f"Option {name} does not take a value.")
            if p.count:
                self._add(raw, p, i, 1)
            else:
                self._add(raw, p, i, p.flag_value)
            return i + 1
        if attached is not None:
            self._add(raw, p, i, (attached,))
            return i + 1
        return self._take_value(tokens, i, p, name, raw)

    def _take_value(self, tokens, i, p, name, raw):
        if p.optional_value:
            nxt = tokens[i + 1] if i + 1 < len(tokens) else None
            if nxt is None or self._option_like(nxt):
                self._add(raw, p, i, _NO_VALUE)
                return i + 1
            self._add(raw, p, i, (nxt,))
            return i + 2
        width = max(p.arity, 1)
        if len(tokens) - (i + 1) < width:
            raise UsageError(f"Option {name} requires {width} value(s).")
        self._add(raw, p, i, tuple(tokens[i + 1:i + 1 + width]))
        return i + 1 + width

    def _stack(self, tokens, i, tok, raw, positional):
        prefix = tok[0]
        body = tok[1:]
        for j, ch in enumerate(body):
            short = prefix + ch
            if short in self.secondary and short not in self.by_name:
                self._add(raw, self.secondary[short], i, False)
                continue
            if short not in self.by_name:
                if self.ignore_unknown:
                    positional.append(prefix + body[j:])
                    return i + 1
                raise NoSuchOption(f"No such option: {short}")
            p = self.by_name[short]
            if p.is_flag:
                if p.count:
                    self._add(raw, p, i, 1)
                else:
                    self._add(raw, p, i, p.flag_value)
                continue
            rest = body[j + 1:]
            if rest:
                self._add(raw, p, i, (rest,))
                return i + 1
            return self._take_value(tokens, i, p, short, raw)
        return i + 1


def bind_arguments(arguments, positional):
    """Assign positional tokens to Arguments in order.

    Returns (raw dict, leftovers). Missing required arguments are left out of raw
    so that resolution (after eager flags such as --help) reports them.
    """
    raw = {}
    rest = list(positional)
    for idx, arg in enumerate(arguments):
        later_min = sum(max(a.arity, 1) for a in arguments[idx + 1:] if not a.variadic)
        if arg.variadic:
            take = max(len(rest) - later_min, 0)
            toks = rest[:take]
            del rest[:take]
            if toks:
                raw[arg.name] = [(0, tuple([t])) for t in toks]
            continue
        width = max(arg.arity, 1)
        if len(rest) < width:
            continue
        toks = rest[:width]
        del rest[:width]
        raw[arg.name] = [(0, tuple(toks))]
    return raw, rest


def check_extra(ctx, leftover, allow_extra):
    if leftover and not allow_extra:
        raise UsageError("Got unexpected extra argument" + ("s" if len(leftover) > 1 else "")
                         + " (" + " ".join(leftover) + ")", ctx=ctx)
