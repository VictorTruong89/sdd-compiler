"""Text wrapping for help pages.

# spec: N-001013 (max content width 100), N-000669 (FP-11), N-000126..N-000131 (FP-02)
"""

import textwrap

MAX_CONTENT_WIDTH = 80
DEFAULT_MAX_CONTENT_WIDTH = MAX_CONTENT_WIDTH


def wrap_text(text, width=78, indent=0, preserve_paragraphs=False, max_width=None):
    """Rewrap text to width. Single newlines are not hard breaks.

    A paragraph whose first line is only a backspace is not rewrapped and the
    backspace line is dropped. Always returns a str; never raises on odd input.
    """
    if text is None:
        return ""
    text = str(text)
    if max_width is not None:
        width = min(width, max_width)
    width = max(width, 10)
    pad = " " * indent
    out = []
    for para in text.split("\n\n"):
        lines = para.split("\n")
        if lines and lines[0].strip() == "\b":
            body = [ln for ln in lines[1:]]
            out.append("\n".join(body))
            continue
        flowed = " ".join(ln.strip() for ln in lines if ln.strip())
        if not flowed:
            continue
        out.append(textwrap.fill(flowed, width=width, initial_indent=pad,
                                 subsequent_indent=pad, break_long_words=False,
                                 break_on_hyphens=False))
    sep = "\n\n"
    return sep.join(out)


def wrap_help_text(text, width=78):
    """Like wrap_text but for description paragraphs."""
    return wrap_text(text, width=width)


def truncate_at_formfeed(text):
    """A form feed truncates a docstring; the form feed itself is dropped."""
    if text is None:
        return None
    return text.split("\f", 1)[0]


def first_sentence(text, width=None):
    """First sentence of a docstring, ellipsized to width when it does not fit."""
    if not text:
        return ""
    flat = " ".join(text.split())
    end = flat.find(". ")
    sentence = flat if end == -1 else flat[: end + 1]
    if width is not None and len(sentence) > width:
        sentence = sentence[: max(width - 3, 0)].rstrip() + "..."
    return sentence
