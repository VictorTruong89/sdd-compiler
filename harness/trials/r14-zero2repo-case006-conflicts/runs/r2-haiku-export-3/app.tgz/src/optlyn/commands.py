"""Commands, groups, command collections, and standalone program dispatch.

# spec: N-000834..N-000867 (Interface Contract 3), N-000375..N-000423 (FP-06),
#       N-000584..N-000607 (FP-10), N-000704..N-000723 (FP-13), N-000079..N-000102 (FP-01)
"""

import os
import re
import sys

from .context import Context, Exit
from .decorators import make_help_option, take_params
from .exceptions import Abort, FileError, NoArgsIsHelp, NoSuchCommand, UsageError
from .help import command_path, format_help, usage_line
from .params import Argument, Option, Parser, bind_arguments, check_extra, resolve_param
from .terminal import echo

CHAIN_MARKER = "*"
_SUFFIXES = ("_command", "_cmd", "_group", "_grp")
_RANK = {"prompt": 0, "commandline": 1, "environment": 2, "default_map": 3, "default": 4}


def derive_name(func_name):
    name = func_name
    for suffix in _SUFFIXES:
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.lower().replace("_", "-")


class Command:
    is_group = False

    def __init__(self, name=None, callback=None, params=None, help=None, short_help=None,
                 epilog=None, options_metavar="[OPTIONS]", context_settings=None,
                 add_help_option=True, no_args_is_help=False, deprecated=False,
                 hidden=False, **extra):
        if name is None and callback is not None:
            name = derive_name(callback.__name__)
        self.name = name
        self.callback = callback
        self.callback_doc = callback.__doc__ if callback is not None else None
        self.params = list(params or [])
        self.help = help
        self.short_help = short_help
        self.epilog = epilog
        self.options_metavar = options_metavar
        self.context_settings = dict(context_settings or {})
        self.no_args_is_help = no_args_is_help
        self.deprecated = deprecated
        self.hidden = hidden
        self.extra = extra
        self._auto_help = None
        if add_help_option:
            self._auto_help = make_help_option(("--help",))
            self.params.append(self._auto_help)

    @property
    def arguments(self):
        return [p for p in self.params if isinstance(p, Argument)]

    @property
    def options(self):
        return [p for p in self.params if isinstance(p, Option)]

    def _effective_params(self, ctx):
        """Auto help follows the context's help-option names; an author option wins."""
        if self._auto_help is None:
            return self.params
        author_names = set()
        for p in self.params:
            if p is not self._auto_help and isinstance(p, Option):
                author_names.update(p.all_names())
        names = [n for n in ctx.help_option_names if n not in author_names]
        if not names:
            return [p for p in self.params if p is not self._auto_help]
        self._auto_help.opts = names
        return self.params

    def make_context(self, info_name, args, parent=None, **extra):
        ctx = Context(self, parent=parent, info_name=info_name, **extra)
        ctx.tokens = list(args or [])
        ctx.rest = []
        return ctx

    # --- invocation -----------------------------------------------------------
    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True,
             **extra):
        args = list(sys.argv[1:] if args is None else args)
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else (
                self.name or "program")
        var = complete_var or "_" + re.sub(r"[-.]", "_", prog_name).upper() + "_COMPLETE"
        if var in os.environ:
            from .completion import run_completion

            status = run_completion(self, prog_name, os.environ[var], args)
            if standalone_mode:
                sys.exit(status)
            return status

        ctx = None
        try:
            ctx = self.make_context(prog_name, args, **extra)
            with ctx:
                rv = self.invoke(ctx)
            if not standalone_mode:
                return rv
            sys.exit(0)
        except Exit as exc:
            if not standalone_mode:
                return exc.exit_code
            sys.exit(exc.exit_code)
        except UsageError as exc:
            if not standalone_mode:
                raise
            _report_usage(exc, exc.ctx or ctx)
            sys.exit(2)
        except (Abort, FileError) as exc:
            if not standalone_mode:
                raise
            if isinstance(exc, Abort):
                echo(exc.message, err=True)
            else:
                echo(f"Error: {exc.message}", err=True)
            sys.exit(exc.exit_code)
        except (KeyboardInterrupt, EOFError):
            if not standalone_mode:
                raise Abort()
            echo("Aborted!", err=True)
            sys.exit(1)

    __call__ = main

    def invoke(self, ctx):
        try:
            return self._invoke(ctx)
        except UsageError as exc:
            if exc.ctx is None:
                exc.ctx = ctx
            raise

    def _invoke(self, ctx):
        with ctx:
            if self.deprecated:
                note = self.deprecated if isinstance(self.deprecated, str) else (
                    f"The command {self.name!r} is deprecated.")
                echo(f"DeprecationWarning: {note}", err=True)
            if self.no_args_is_help and not ctx.tokens:
                raise NoArgsIsHelp(ctx=ctx)
            self._parse(ctx)
            return self._run_callback(ctx)

    def _parse(self, ctx):
        params = self._effective_params(ctx)
        parser = Parser(params, ignore_unknown=bool(ctx.ignore_unknown_options))
        interspersed = ctx.allow_interspersed_args is not False
        raw, positional, _ = parser.parse(ctx.tokens, interspersed=interspersed)
        arg_raw, leftover = bind_arguments(self.arguments, positional)
        raw.update(arg_raw)
        ctx.rest = leftover
        ctx.args = leftover
        _resolve_params(ctx, params, raw, leftover, bool(ctx.allow_extra_args))

    def _run_callback(self, ctx):
        if self.callback is None:
            return None
        return self.callback(**ctx.params)


def _resolve_params(ctx, params, raw, leftover, allow_extra):
    """Resolve every parameter. Eager flags run first (they may exit); then the
    extra-argument check; then the rest. Feature-switch candidates are collected."""
    eager = [p for p in params if p.is_eager and raw.get(p.name)]
    eager.sort(key=lambda p: min(pos for pos, _ in raw[p.name]))
    rest = [p for p in params if p not in eager]
    candidates = {}
    for p in eager:
        _resolve_one(ctx, p, raw, candidates)
    check_extra(ctx, leftover, allow_extra)
    for p in rest:
        _resolve_one(ctx, p, raw, candidates)
    for dest, cands in candidates.items():
        # Feature-switch group: most explicit source wins; ties go to the last declared.
        best = None
        for p, value, source in cands:
            rank = _RANK.get(source.value, 9)
            if best is None or rank <= best[0]:
                best = (rank, p, value, source)
        _, p, value, source = best
        ctx._set_source(dest, source)
        if p.expose_value:
            ctx.params[dest] = value


def _resolve_one(ctx, p, raw, candidates):
    if p.deprecated and raw.get(p.name):
        kind = "argument" if isinstance(p, Argument) else "option"
        echo(f"DeprecationWarning: {kind} {p.name!r} is deprecated.", err=True)
    value, source = resolve_param(ctx, p, raw.get(p.name, []))
    candidates.setdefault(p.name, []).append((p, value, source))


def invoke_with_values(ctx, cmd, values):
    """Run a command with exactly the given values (no parsing)."""
    for p in cmd.params:
        if p.name in values:
            value = values[p.name]
        else:
            value = p.get_default()
        if p.expose_value:
            ctx.params[p.name] = value
            ctx._set_source(p.name, None)
    return cmd._run_callback(ctx)


def _report_usage(exc, ctx):
    if exc.show_help and ctx is not None:
        echo(format_help(ctx), err=True, nl=False)
        if not str(exc.message):
            return
    if ctx is not None:
        echo(usage_line(ctx), err=True)
        echo(f"Try '{command_path(ctx)} {ctx.help_option_names[0]}' for help.", err=True)
    if exc.message:
        msg = exc.format_message() if hasattr(exc, "format_message") else exc.message
        echo("", err=True)
        echo(f"Error: {msg}", err=True)


class Group(Command):
    is_group = True

    def __init__(self, name=None, commands=None, invoke_without_command=False,
                 no_args_is_help=None, subcommand_metavar=None, chain=False,
                 result_callback=None, **kwargs):
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        super().__init__(name, no_args_is_help=no_args_is_help, **kwargs)
        self.commands = {}
        self.invoke_without_command = invoke_without_command
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self.result_callback_fn = result_callback
        for cmd in commands or []:
            self.add_command(cmd)

    def add_command(self, cmd, name=None):
        if self.chain and cmd.is_group:
            raise TypeError("a group cannot be attached beneath a chaining group")
        self.commands[name or cmd.name] = cmd

    def command(self, *args, **kwargs):
        def decorator(f):
            cmd = command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        def decorator(f):
            cmd = group(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self):
        def decorator(f):
            self.result_callback_fn = f
            return f

        return decorator

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        return self.commands.get(cmd_name)

    def _parse(self, ctx):
        params = self._effective_params(ctx)
        parser = Parser(params, ignore_unknown=bool(ctx.ignore_unknown_options))
        mixing = bool(ctx.allow_interspersed_args)
        raw, positional, _ = parser.parse(ctx.tokens, interspersed=mixing)
        arg_raw, leftover = bind_arguments(self.arguments, positional)
        raw.update(arg_raw)
        ctx.rest = leftover
        ctx.args = leftover
        # Groups hand the leftover (subcommand name and below) to dispatch.
        _resolve_params(ctx, params, raw, [], True)

    def _invoke(self, ctx):
        with ctx:
            if self.deprecated:
                note = self.deprecated if isinstance(self.deprecated, str) else (
                    f"The command {self.name!r} is deprecated.")
                echo(f"DeprecationWarning: {note}", err=True)
            if self.no_args_is_help and not ctx.tokens:
                raise NoArgsIsHelp(ctx=ctx)
            self._parse(ctx)
            rest = ctx.rest
            if self.chain:
                return self._invoke_chain(ctx, rest)
            if not rest:
                if self.invoke_without_command:
                    ctx.invoked_subcommand = None
                    rv = self._run_callback(ctx)
                    if self.result_callback_fn is not None:
                        return self.result_callback_fn(rv, **ctx.params)
                    return rv
                raise UsageError("Missing command.", ctx=ctx)
            name, child_tokens = rest[0], rest[1:]
            cmd = self.get_command(ctx, name)
            if cmd is None:
                raise NoSuchCommand(f"No such command '{name}'.", ctx=ctx)
            ctx.invoked_subcommand = name
            self._run_callback(ctx)
            child = cmd.make_context(name, child_tokens, parent=ctx)
            rv = cmd.invoke(child)
            if self.result_callback_fn is not None:
                return self.result_callback_fn(rv, **ctx.params)
            return rv

    def _invoke_chain(self, ctx, rest):
        results = []
        names = set(self.commands)
        ctx.invoked_subcommand = CHAIN_MARKER
        self._run_callback(ctx)
        while rest:
            name = rest[0]
            cmd = self.get_command(ctx, name)
            if cmd is None:
                raise NoSuchCommand(f"No such command '{name}'.", ctx=ctx)
            if any(isinstance(p, Argument) and p.variadic for p in cmd.params):
                child_tokens, rest = rest[1:], []
            else:
                k = 1
                while k < len(rest) and rest[k] not in names:
                    k += 1
                child_tokens, rest = rest[1:k], rest[k:]
            child = cmd.make_context(name, child_tokens, parent=ctx)
            results.append(cmd.invoke(child))
        if self.result_callback_fn is not None:
            return self.result_callback_fn(results, **ctx.params)
        return results


class CommandCollection(Group):
    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = set()
        for src in self.sources:
            names.update(src.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        for src in self.sources:
            found = src.get_command(ctx, cmd_name)
            if found is not None:
                return found
        return None


def _make(f, name, cls, attrs, default_cls):
    cls = cls or default_cls
    params = take_params(f)
    return cls(name=name, callback=f, params=params, **attrs)


def command(name=None, cls=None, **attrs):
    if callable(name) and not isinstance(name, str):
        return _make(name, None, cls, attrs, Command)

    def decorator(f):
        return _make(f, name, cls, attrs, Command)

    return decorator


def group(name=None, cls=None, **attrs):
    if callable(name) and not isinstance(name, str):
        return _make(name, None, cls, attrs, Group)

    def decorator(f):
        return _make(f, name, cls, attrs, Group)

    return decorator
