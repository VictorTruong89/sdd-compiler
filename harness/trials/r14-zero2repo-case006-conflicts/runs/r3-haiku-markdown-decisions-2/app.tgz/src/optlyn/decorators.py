"""Declaration decorators: commands, groups, options, arguments and ready-made flags."""

import inspect
from functools import update_wrapper

from .core import Argument, Command, Group, Option
from .globals import get_current_context
from .utils import echo


def _default_command_name(func_name):
    name = func_name.lower().replace("_", "-")
    left, sep, suffix = name.rpartition("-")
    if sep and suffix in ("command", "cmd", "group", "grp"):
        name = left
    return name


def _take_params(func):
    params = getattr(func, "__optlyn_params__", [])
    params.reverse()
    try:
        del func.__optlyn_params__
    except AttributeError:
        pass
    return params


def _attach_param(func, param):
    if isinstance(func, Command):
        func.params.append(param)
        return func
    if not hasattr(func, "__optlyn_params__"):
        func.__optlyn_params__ = []
    func.__optlyn_params__.append(param)
    return func


def command(name=None, cls=None, **attrs):
    """Turn a function into a :class:`Command`. Usable as ``@command`` or ``@command()``."""
    if cls is None:
        cls = Command

    def decorator(f):
        cmd_name = name if name is not None else _default_command_name(f.__name__)
        params = _take_params(f)
        return cls(name=cmd_name, callback=f, params=params, **attrs)

    if callable(name) and not isinstance(name, str):
        func, name = name, None
        return decorator(func)
    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a :class:`Group`. Usable as ``@group`` or ``@group()``."""
    if cls is None:
        cls = Group

    def decorator(f):
        cmd_name = name if name is not None else _default_command_name(f.__name__)
        params = _take_params(f)
        return cls(name=cmd_name, callback=f, params=params, **attrs)

    if callable(name) and not isinstance(name, str):
        func, name = name, None
        return decorator(func)
    return decorator


def option(*param_decls, cls=None, **attrs):
    """Attach an :class:`Option` to a command or group function."""
    if cls is None:
        cls = Option

    def decorator(f):
        return _attach_param(f, cls(param_decls, **attrs))

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach an :class:`Argument` to a command or group function."""
    if cls is None:
        cls = Argument

    def decorator(f):
        return _attach_param(f, cls(param_decls, **attrs))

    return decorator


def pass_context(f):
    """Pass the current :class:`Context` as the first argument."""

    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return update_wrapper(new_func, f)


def pass_obj(f):
    """Pass the current context's author object as the first argument."""

    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return update_wrapper(new_func, f)


def make_pass_decorator(object_type, ensure=False):
    """Build a decorator that passes the nearest object of ``object_type``."""

    def decorator(f):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            return f(obj, *args, **kwargs)

        return update_wrapper(new_func, f)

    return decorator


def help_option(*param_decls, **kwargs):
    """An extra eager help flag that prints the help page and exits."""

    def show_help(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(ctx.get_help(), color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", show_help)
    return option(*(param_decls or ("--help",)), **kwargs)


def _detect_version(package_name):
    from importlib import metadata

    try:
        return metadata.version(package_name)
    except metadata.PackageNotFoundError:
        pass
    dists = metadata.packages_distributions().get(package_name)
    if dists:
        return metadata.version(dists[0])
    raise RuntimeError(f"Could not determine the version of {package_name!r}.")


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    """An eager flag that prints a version identity and exits."""
    if version is None and package_name is None:
        frame = inspect.currentframe()
        caller = frame.f_back if frame is not None else None
        package_name = caller.f_globals.get("__name__") if caller is not None else None

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        prog = prog_name or ctx.find_root().info_name
        ver = version if version is not None else _detect_version(package_name)
        template = message or "%(prog)s, version %(version)s"
        echo(template % {"prog": prog, "package": package_name, "version": ver}, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*(param_decls or ("--version",)), **kwargs)


def custom_version_option(callback_fn, *param_decls, **kwargs):
    """An eager flag whose identity is exactly the string ``callback_fn(ctx)`` returns."""

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(callback_fn(ctx), color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*(param_decls or ("--version",)), **kwargs)


def password_option(*param_decls, **kwargs):
    """A prompting option that hides input and asks for confirmation."""
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    return option(*(param_decls or ("--password",)), **kwargs)


def confirmation_option(*param_decls, **kwargs):
    """A yes flag that prompts when omitted and aborts when the answer is no."""

    def callback(ctx, param, value):
        if not value:
            ctx.abort()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("callback", callback)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")
    return option(*(param_decls or ("--yes",)), **kwargs)


__all__ = [
    "argument",
    "command",
    "confirmation_option",
    "custom_version_option",
    "group",
    "help_option",
    "make_pass_decorator",
    "option",
    "pass_context",
    "pass_obj",
    "password_option",
    "version_option",
]
