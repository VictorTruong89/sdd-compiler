"""Parameter types: built-in conversions and the base class for custom types."""

import datetime as _dt
import enum
import os
import pathlib
import uuid

from .exceptions import BadParameter, FileError
from .utils import open_file


class ParamType:
    """Base class for parameter types. Subclasses implement :meth:`convert`."""

    name = "text"
    is_composite = False

    def convert(self, value, param=None, ctx=None):
        return value

    def __call__(self, value, param=None, ctx=None):
        if value is None:
            return None
        return self.convert(value, param, ctx)

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def get_metavar(self, param):
        return None

    def split_envvar_value(self, rv):
        return rv.split()

    def shell_complete(self, ctx, param, incomplete):
        return []

    def __repr__(self):
        return self.name.upper()


def _normalize(value, ctx):
    func = getattr(ctx, "token_normalize_func", None) if ctx is not None else None
    if func is not None and isinstance(value, str):
        return func(value)
    return value


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        return str(value)


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, int) and not isinstance(value, bool):
            return value
        if isinstance(value, bool):
            return int(value)
        try:
            return int(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        try:
            return float(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


_TRUE = ("1", "true", "t", "yes", "y", "on")
_FALSE = ("0", "false", "f", "no", "n", "off")


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID value.", param, ctx)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()


class Choice(ParamType):
    """A closed list of allowed values, or the members of an enumeration."""

    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.choices = list(choices)
            self._tokens = [member.name for member in self.choices]
        else:
            self.choices = list(choices)
            self._tokens = [str(choice) for choice in self.choices]
        self.case_sensitive = case_sensitive

    def _match_key(self, text):
        return text if self.case_sensitive else text.casefold()

    def convert(self, value, param=None, ctx=None):
        if any(value is choice for choice in self.choices):
            return value
        normed = self._match_key(_normalize(str(value), ctx))
        for token, choice in zip(self._tokens, self.choices):
            token_key = self._match_key(_normalize(token, ctx))
            if token_key == normed:
                return choice
        options = ", ".join(repr(token) for token in self._tokens)
        self.fail(f"{value!r} is not one of {options}.", param, ctx)

    def get_metavar(self, param):
        return "[" + "|".join(self._tokens) + "]"

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        return [CompletionItem(token) for token in self._tokens if token.startswith(incomplete)]


_DEFAULT_DATETIME_FORMATS = (
    "%Y-%m-%d",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M:%S",
)


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(_DEFAULT_DATETIME_FORMATS)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        text = str(value).strip()
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(text, fmt)
            except ValueError:
                continue
        formats = ", ".join(repr(fmt) for fmt in self.formats)
        self.fail(f"{value!r} does not match the format {formats}.", param, ctx)


def _range_text(lo, hi, lo_open, hi_open):
    left = "" if lo is None else f"{lo}{'<' if lo_open else '<='}"
    right = "" if hi is None else f"{'<' if hi_open else '<='}{hi}"
    if lo is None and hi is None:
        return "any value"
    return f"{left}x{right}"


class IntRange(ParamType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        rv = INT.convert(value, param, ctx)
        below = self.min is not None and (rv <= self.min if self.min_open else rv < self.min)
        above = self.max is not None and (rv >= self.max if self.max_open else rv > self.max)
        if not below and not above:
            return rv
        if self.clamp:
            if below:
                return self.min + 1 if self.min_open else self.min
            return self.max - 1 if self.max_open else self.max
        bounds = _range_text(self.min, self.max, self.min_open, self.max_open)
        self.fail(f"{rv} is not in the valid range of {bounds}.", param, ctx)


class FloatRange(ParamType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min_open or max_open):
            raise ValueError("Clamping is not supported for open bounds.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        rv = FLOAT.convert(value, param, ctx)
        below = self.min is not None and (rv <= self.min if self.min_open else rv < self.min)
        above = self.max is not None and (rv >= self.max if self.max_open else rv > self.max)
        if not below and not above:
            return rv
        if self.clamp:
            return float(self.min) if below else float(self.max)
        bounds = _range_text(self.min, self.max, self.min_open, self.max_open)
        self.fail(f"{rv} is not in the valid range of {bounds}.", param, ctx)


def convert_type(ty, default=None):
    """Return a :class:`ParamType` for ``ty``, inferring from ``default`` if needed."""
    if isinstance(ty, ParamType):
        return ty
    if ty is None:
        if default is None:
            return STRING
        if isinstance(default, tuple):
            return Tuple([convert_type(None, item) for item in default])
        if isinstance(default, list):
            return convert_type(None, default[0]) if default else STRING
        if isinstance(default, bool):
            return BOOL
        if isinstance(default, int):
            return INT
        if isinstance(default, float):
            return FLOAT
        return STRING
    if ty is str:
        return STRING
    if ty is bool:
        return BOOL
    if ty is int:
        return INT
    if ty is float:
        return FLOAT
    if ty is uuid.UUID:
        return UUID
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"Unsupported parameter type {ty!r}.")


class FuncParamType(ParamType):
    """Adapts a conversion function that raises ``ValueError`` to refuse a token."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text") or "text"

    def convert(self, value, param=None, ctx=None):
        if not isinstance(value, str):
            return value
        try:
            return self.func(value)
        except BadParameter:
            raise
        except ValueError as e:
            self.fail(str(e) or f"{value!r} is not valid.", param, ctx)


class Tuple(ParamType):
    """A fixed-length product of inner types."""

    name = "tuple"
    is_composite = True

    def __init__(self, types):
        self.types = [convert_type(t) for t in types]

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, tuple) and len(value) == len(self.types):
            return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))
        try:
            items = list(value)
        except TypeError:
            self.fail(f"{value!r} is not a sequence of {len(self.types)} values.", param, ctx)
        if len(items) != len(self.types):
            self.fail(f"Takes {len(self.types)} values but {len(items)} were given.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, items))


class File(ParamType):
    """Opens a file (``-`` is stdin or stdout). Delivers an open file object."""

    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        lazy = self.lazy if self.lazy is not None else ("w" in self.mode)
        try:
            stream = open_file(
                value,
                self.mode,
                self.encoding,
                self.errors,
                lazy=lazy,
                atomic=self.atomic,
            )
        except FileError as e:
            self.fail(f"'{value}': {e.hint}", param, ctx)
        if ctx is not None:
            ctx.call_on_close(stream.close)
        return stream

    def split_envvar_value(self, rv):
        return rv.split(os.pathsep)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        return [CompletionItem(incomplete, type="file")]


class Path(ParamType):
    """Validates a filesystem path. Delivers the path, not an open file."""

    name = "path"

    def __init__(
        self,
        exists=False,
        file_okay=True,
        dir_okay=True,
        writable=False,
        readable=True,
        resolve_path=False,
        allow_dash=False,
        path_type=None,
        executable=False,
    ):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def _deliver(self, rv):
        if self.path_type is None or self.path_type is str:
            return rv
        if self.path_type is pathlib.Path:
            return pathlib.Path(rv)
        return self.path_type(rv)

    def convert(self, value, param=None, ctx=None):
        if self.allow_dash and value == "-":
            return self._deliver(value)
        rv = os.path.realpath(value) if self.resolve_path else value
        if not os.path.exists(rv):
            if self.exists:
                self.fail(f"{rv!r} does not exist.", param, ctx)
            return self._deliver(rv)
        if not self.file_okay and os.path.isfile(rv):
            self.fail(f"{rv!r} is a file.", param, ctx)
        if not self.dir_okay and os.path.isdir(rv):
            self.fail(f"{rv!r} is a directory.", param, ctx)
        if self.readable and not os.access(rv, os.R_OK):
            self.fail(f"{rv!r} is not readable.", param, ctx)
        if self.writable and not os.access(rv, os.W_OK):
            self.fail(f"{rv!r} is not writable.", param, ctx)
        if self.executable and not os.access(rv, os.X_OK):
            self.fail(f"{rv!r} is not executable.", param, ctx)
        return self._deliver(rv)

    def split_envvar_value(self, rv):
        return rv.split(os.pathsep)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        kind = "dir" if self.dir_okay and not self.file_okay else "file"
        return [CompletionItem(incomplete, type=kind)]
