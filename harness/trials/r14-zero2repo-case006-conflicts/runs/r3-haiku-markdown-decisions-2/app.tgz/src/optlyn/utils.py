"""Output, styling, stream and file helpers shared by the rest of the package."""

import os
import re
import subprocess
import sys
import tempfile

from .exceptions import FileError
from .globals import get_current_context

_ansi_re = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")

_COLORS = {
    "black": 30,
    "red": 31,
    "green": 32,
    "yellow": 33,
    "blue": 34,
    "magenta": 35,
    "cyan": 36,
    "white": 37,
    "reset": 39,
}
for _name, _code in list(_COLORS.items()):
    if _name != "reset":
        _COLORS[f"bright_{_name}"] = _code + 60

_STYLE_SWITCHES = (
    ("bold", 1, 22),
    ("dim", 2, 22),
    ("italic", 3, 23),
    ("underline", 4, 24),
    ("blink", 5, 25),
    ("reverse", 7, 27),
    ("strikethrough", 9, 29),
    ("overline", 53, 55),
)


def _color_code(color, background):
    if isinstance(color, str):
        if color not in _COLORS:
            raise TypeError(f"Unknown color {color!r}.")
        code = _COLORS[color]
        if color == "reset":
            return "49" if background else "39"
        return str(code + 10 if background else code)
    if isinstance(color, bool):
        raise TypeError("Color must be a name, an integer, or an RGB triple.")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise ValueError(f"Color index {color} is outside 0-255.")
        return f"{48 if background else 38};5;{color}"
    if isinstance(color, (tuple, list)) and len(color) == 3 and all(
        isinstance(c, int) and not isinstance(c, bool) for c in color
    ):
        if not all(0 <= c <= 255 for c in color):
            raise ValueError("RGB components must be within 0-255.")
        r, g, b = color
        return f"{48 if background else 38};2;{r};{g};{b}"
    raise TypeError(f"Unsupported color value {color!r}.")


def style(
    text,
    fg=None,
    bg=None,
    bold=None,
    dim=None,
    underline=None,
    overline=None,
    italic=None,
    blink=None,
    reverse=None,
    strikethrough=None,
    reset=True,
):
    """Wrap ``text`` in ANSI SGR sequences for the given colors and switches."""
    bits = []
    if fg is not None:
        bits.append(_color_code(fg, False))
    if bg is not None:
        bits.append(_color_code(bg, True))
    flags = {
        "bold": bold,
        "dim": dim,
        "underline": underline,
        "overline": overline,
        "italic": italic,
        "blink": blink,
        "reverse": reverse,
        "strikethrough": strikethrough,
    }
    for name, on_code, off_code in _STYLE_SWITCHES:
        value = flags[name]
        if value is not None:
            bits.append(str(on_code if value else off_code))
    if not bits:
        return text
    text = f"\033[{';'.join(bits)}m{text}"
    if reset:
        text = f"{text}\033[0m"
    return text


def unstyle(text):
    """Remove ANSI escape sequences from ``text``."""
    return _ansi_re.sub("", text)


def _is_tty(stream):
    try:
        return bool(stream.isatty())
    except (AttributeError, ValueError):
        return False


def _is_ascii_stream(stream):
    encoding = (getattr(stream, "encoding", None) or "").lower().replace("-", "").replace("_", "")
    return encoding in ("ascii", "usascii")


def _write_text(file, text):
    """Write text to ``file``; ASCII-only streams get the UTF-8 bytes instead."""
    if _is_ascii_stream(file) and hasattr(file, "buffer"):
        file.flush()
        file.buffer.write(text.encode("utf-8"))
        file.buffer.flush()
        return
    try:
        file.write(text)
    except UnicodeEncodeError:
        file.flush()
        file.buffer.write(text.encode("utf-8"))
        file.buffer.flush()


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write text or bytes to standard output (or standard error).

    Styles are stripped unless the stream is a terminal, or color is forced
    on. ``color`` falls back to the color flag of the current context.
    """
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        file.flush()
        target = getattr(file, "buffer", None)
        if target is None:
            file.write(message.decode("utf-8", "replace"))
        else:
            target.write(message)
            if nl:
                target.write(b"\n")
            target.flush()
        return
    if color is None:
        ctx = get_current_context(silent=True)
        color = ctx.color if ctx is not None else None
    if color is None:
        color = _is_tty(file)
    if not color:
        message = unstyle(message)
    if nl:
        message += "\n"
    if message:
        _write_text(file, message)
    file.flush()


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    """Echo the text after styling it with the given keyword styles."""
    if message is not None and not isinstance(message, bytes):
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def get_text_stream(name, encoding=None, errors="strict"):
    """Return the named interpreter text stream (``stdin``, ``stdout`` or ``stderr``)."""
    streams = {"stdin": sys.stdin, "stdout": sys.stdout, "stderr": sys.stderr}
    return streams[name]


def _binary(name):
    stream = get_text_stream(name)
    return getattr(stream, "buffer", stream)


def get_binary_stdin():
    return _binary("stdin")


def get_binary_stdout():
    return _binary("stdout")


def get_binary_stderr():
    return _binary("stderr")


def get_text_stdin(encoding=None, errors=None):
    return get_text_stream("stdin", encoding, errors)


def get_text_stdout(encoding=None, errors=None):
    return get_text_stream("stdout", encoding, errors)


def get_text_stderr(encoding=None, errors=None):
    return get_text_stream("stderr", encoding, errors)


class _NoCloseStream:
    """Proxy for a standard stream whose ``close`` must not close the real stream."""

    def __init__(self, stream):
        self._stream = stream

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __iter__(self):
        return iter(self._stream)

    def close(self):
        self._stream.flush()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()


class _AtomicFile:
    """Writes to a sibling temporary file and replaces the target on close."""

    def __init__(self, filename, mode, encoding, errors):
        self._filename = filename
        directory = os.path.dirname(os.path.abspath(filename))
        fd, self._tmp_name = tempfile.mkstemp(dir=directory, prefix=".__optlyn-atomic-")
        self._f = os.fdopen(fd, mode, encoding=encoding, errors=errors)
        self._closed = False

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __iter__(self):
        return iter(self._f)

    def close(self):
        if self._closed:
            return
        self._closed = True
        self._f.close()
        os.replace(self._tmp_name, self._filename)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()


class LazyFile:
    """A file that opens on first I/O (or immediately, when not lazy)."""

    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False, lazy=True):
        self.name = filename
        self.mode = mode
        self._encoding = encoding
        self._errors = errors
        self._atomic = atomic
        self._f = None
        if not lazy:
            self._open()

    def _open(self):
        if self._f is None:
            try:
                if self._atomic:
                    self._f = _AtomicFile(self.name, self.mode, self._encoding, self._errors)
                else:
                    self._f = open(self.name, self.mode, encoding=self._encoding, errors=self._errors)
            except OSError as e:
                raise FileError(self.name, e.strerror) from e
        return self._f

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return getattr(self._open(), name)

    def __iter__(self):
        return iter(self._open())

    def close(self):
        if self._f is not None:
            self._f.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file, or return the standard stream for ``-``.

    Read-mode files open immediately. Write-mode files may be lazy.
    """
    filename = os.fspath(filename)
    if filename == "-":
        if "r" in mode:
            stream = get_text_stream("stdin")
        else:
            stream = get_text_stream("stdout")
        if "b" in mode:
            stream = getattr(stream, "buffer", stream)
        return _NoCloseStream(stream)
    if lazy is None:
        lazy = False
    if lazy and "r" in mode:
        lazy = False
    return LazyFile(filename, mode, encoding, errors, atomic=atomic, lazy=lazy)


def format_filename(filename, shorten=False):
    """Return a printable text form of a filename that may not be valid Unicode."""
    filename = os.fspath(filename)
    if isinstance(filename, bytes):
        filename = os.fsdecode(filename)
    if shorten:
        filename = os.path.basename(filename)
    out = []
    for ch in filename:
        code = ord(ch)
        if 0xDC80 <= code <= 0xDCFF:
            out.append(f"\\x{code - 0xDC00:02x}")
        else:
            out.append(ch)
    return "".join(out)


def get_app_dir(app_name, roaming=True, force_posix=False):
    """Return the per-user configuration directory for ``app_name``."""
    home = os.path.expanduser("~")
    if sys.platform == "win32" and not force_posix:
        base = os.environ.get("APPDATA" if roaming else "LOCALAPPDATA") or home
        return os.path.join(base, app_name)
    unix_name = re.sub(r"\s+", "-", app_name.lower())
    if force_posix:
        return os.path.join(home, "." + unix_name)
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    config_home = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(config_home, unix_name)


def launch(url, wait=False, locate=False):
    """Open a URL or file with the default application. Returns a status code."""
    if sys.platform == "win32":
        try:
            os.startfile(url)  # type: ignore[attr-defined]
        except OSError:
            return 127
        return 0
    if sys.platform == "darwin":
        args = ["open", "-R", url] if locate else ["open", url]
    else:
        opener = "xdg-open"
        target = os.path.dirname(os.path.abspath(url)) if locate else url
        args = [opener, target]
    try:
        proc = subprocess.Popen(args)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0
