"""Text wrapping and help-page layout."""

import re
import shutil
import textwrap
from contextlib import contextmanager

_BLANK_LINE = re.compile(r"\n\s*\n")


def wrap_text(text, width=100, initial_indent="", subsequent_indent="", preserve_paragraphs=False):
    """Wrap ``text`` to ``width`` columns.

    Single newlines inside a paragraph are not kept as breaks. A paragraph whose
    first line is only a backspace keeps its line breaks.
    """
    text = text or ""
    width = max(int(width), 10)
    if not preserve_paragraphs:
        return textwrap.fill(
            " ".join(text.split()),
            width=width,
            initial_indent=initial_indent,
            subsequent_indent=subsequent_indent,
            break_long_words=False,
            break_on_hyphens=False,
        )
    out = []
    first_line_of_block = True
    for paragraph in _BLANK_LINE.split(text.strip("\n")):
        lines = [line for line in paragraph.splitlines()]
        while lines and not lines[0].strip():
            lines.pop(0)
        while lines and not lines[-1].strip():
            lines.pop()
        if not lines:
            continue
        if lines[0].strip() == "\b":
            body = [line.rstrip() for line in lines[1:]]
            rendered = []
            for index, line in enumerate(body):
                prefix = initial_indent if index == 0 and first_line_of_block else subsequent_indent
                rendered.append(prefix + line.strip() if line.strip() else "")
            out.append("\n".join(rendered))
        else:
            joined = " ".join(line.strip() for line in lines)
            out.append(
                textwrap.fill(
                    joined,
                    width=width,
                    initial_indent=initial_indent if first_line_of_block else subsequent_indent,
                    subsequent_indent=subsequent_indent,
                    break_long_words=False,
                    break_on_hyphens=False,
                )
            )
        first_line_of_block = False
    return "\n\n".join(out)


class HelpFormatter:
    """Accumulates the lines of a help page."""

    def __init__(self, width=None, max_width=None, indent_increment=2):
        if width is None:
            columns = shutil.get_terminal_size().columns
            limit = 80 if max_width is None else max_width
            width = max(min(columns, limit) - 2, 50)
        self.width = width
        self.indent_increment = indent_increment
        self.current_indent = 0
        self.buffer = []

    def write(self, text):
        self.buffer.append(text)

    def getvalue(self):
        return "".join(self.buffer)

    @contextmanager
    def indentation(self):
        self.current_indent += self.indent_increment
        try:
            yield
        finally:
            self.current_indent -= self.indent_increment

    def write_usage(self, prog, args="", prefix="Usage: "):
        text = f"{prefix}{prog}"
        if args:
            text = f"{text} {args}"
            if len(text) > self.width:
                subsequent = " " * (len(prefix) + len(prog) + 1)
                text = textwrap.fill(
                    text,
                    width=max(self.width, 20),
                    subsequent_indent=subsequent,
                    break_long_words=False,
                    break_on_hyphens=False,
                )
        self.write(f"{text}\n")

    def write_heading(self, heading):
        self.write(f"{'':>{self.current_indent}}{heading}:\n")

    def write_paragraph(self):
        if self.buffer:
            self.write("\n")

    def write_text(self, text):
        indent = " " * self.current_indent
        body = wrap_text(
            text,
            width=max(self.width - self.current_indent, 11),
            initial_indent=indent,
            subsequent_indent=indent,
            preserve_paragraphs=True,
        )
        self.write(f"{body}\n")

    def write_dl(self, rows, col_max=30, col_spacing=2):
        rows = [(str(first), str(second or "")) for first, second in rows]
        if not rows:
            return
        first_width = min(max(len(first) for first, _ in rows), col_max)
        first_col = first_width + col_spacing
        pad = " " * self.current_indent
        value_pad = " " * (first_col + self.current_indent)
        text_width = max(self.width - first_col - self.current_indent, 10)
        for first, second in rows:
            if not second:
                self.write(f"{pad}{first}\n")
                continue
            if len(first) <= first_width:
                head = f"{pad}{first.ljust(first_width)}{' ' * col_spacing}"
            else:
                head = f"{pad}{first}\n{value_pad}"
            lines = wrap_text(second, width=text_width, preserve_paragraphs=True).split("\n")
            self.write(f"{head}{lines[0]}\n")
            for line in lines[1:]:
                self.write(f"{value_pad}{line}\n" if line else "\n")
