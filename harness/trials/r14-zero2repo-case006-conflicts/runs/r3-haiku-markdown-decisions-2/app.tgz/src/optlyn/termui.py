"""Interactive helpers: prompts, confirmation, progress, pager, editor and keys."""

import io
import os
import shlex
import subprocess
import sys
import tempfile
import time
from contextlib import contextmanager

from .exceptions import Abort, BadParameter
from .param_types import convert_type
from .utils import _is_tty, echo, unstyle


def is_interactive():
    """A session is interactive when stdin or stdout is a terminal."""
    return _is_tty(sys.stdin) or _is_tty(sys.stdout)


def _runner_flag(stream, name):
    return bool(getattr(stream, name, False))


def _read_line(text, hide_input=False, err=False):
    """Show ``text`` and read one line from standard input. EOF aborts."""
    stdin = sys.stdin
    if hide_input and _is_tty(stdin):
        import getpass

        return getpass.getpass(text)
    echo(text, nl=False, err=err)
    line = stdin.readline()
    if not line:
        raise EOFError
    line = line.rstrip("\r\n")
    if not hide_input and _runner_flag(stdin, "echo_prompts") and not _runner_flag(stdin, "echo_stdin"):
        echo(line)
    return line


def prompt(
    text,
    default=None,
    hide_input=False,
    confirmation_prompt=False,
    type=None,
    value_proc=None,
    prompt_suffix=": ",
    show_default=True,
    err=False,
    show_choices=True,
):
    """Ask for a value, convert it, and return it. Invalid input is asked again."""
    if callable(default):
        default = default()
    ptype = convert_type(type, default)
    prompt_text = text
    if show_default and default is not None and not hide_input:
        prompt_text = f"{prompt_text} [{default}]"
    prompt_text = f"{prompt_text}{prompt_suffix}"
    while True:
        try:
            value = _read_line(prompt_text, hide_input, err)
        except EOFError as e:
            raise Abort() from e
        if value:
            if confirmation_prompt:
                try:
                    second = _read_line("Repeat for confirmation" + prompt_suffix, hide_input, err)
                except EOFError as e:
                    raise Abort() from e
                if second != value:
                    echo("Error: the two entered values do not match", err=True)
                    continue
            try:
                if value_proc is not None:
                    return value_proc(value)
                return ptype.convert(value)
            except BadParameter as e:
                echo(f"Error: {e.message}", err=True)
                continue
        if default is not None:
            return ptype.convert(default) if value_proc is None else value_proc(default)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    """Ask a yes/no question. Empty input takes the default; anything else is no."""
    default = bool(default)
    if show_default:
        choices = "Y/n" if default else "y/N"
        prompt_text = f"{text} [{choices}]{prompt_suffix}"
    else:
        prompt_text = f"{text}{prompt_suffix}"
    try:
        answer = _read_line(prompt_text, False, err)
    except EOFError as e:
        raise Abort() from e
    text_answer = answer.strip().lower()
    if text_answer == "":
        rv = default
    elif text_answer in ("y", "yes"):
        rv = True
    else:
        rv = False
    if not rv and abort:
        raise Abort()
    return rv


def getchar(echo=False):
    """Read one character from the terminal, even when stdin is a pipe."""
    if sys.platform == "win32":
        import msvcrt

        ch = msvcrt.getwch()
    else:
        ch = _read_tty_char()
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch in ("\x04", "\x1a"):
        raise EOFError()
    if echo:
        sys.stdout.write(ch)
        sys.stdout.flush()
    return ch


def _read_tty_char():
    try:
        import termios
        import tty

        fd = os.open("/dev/tty", os.O_RDWR)
    except (ImportError, OSError):
        data = sys.stdin.read(1)
        if not data:
            raise EOFError()
        return data
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            data = os.read(fd, 1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
    finally:
        os.close(fd)
    if not data:
        raise EOFError()
    return data.decode("utf-8", "replace")


def pause(info=None, err=False):
    """Wait for a key press when the session is interactive; otherwise return."""
    if not is_interactive():
        return
    if info is None:
        info = "Press any key to continue..."
    echo(info, nl=False, err=err)
    getchar()
    echo("", err=err)


def clear():
    """Clear the terminal screen when standard output is a terminal."""
    if not _is_tty(sys.stdout):
        return
    echo("\033[2J\033[H", nl=False)


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Open an editor on text (returns the saved text) or on a file (returns None)."""
    if sys.platform == "win32":
        default_editor = "notepad"
    else:
        default_editor = "vi"
    editor_cmd = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR") or default_editor
    environ = dict(os.environ)
    environ.update(env or {})
    argv = shlex.split(editor_cmd)
    if filename is not None:
        subprocess.call([*argv, os.fspath(filename)], env=environ)
        return None
    original = text or ""
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(original)
        subprocess.call([*argv, path], env=environ)
        with open(path, encoding="utf-8", newline="") as handle:
            result = handle.read()
    finally:
        os.remove(path)
    if require_save and result == original:
        return None
    return result


class _EchoWriter:
    """Writes through :func:`echo` so styles follow the usual rules."""

    def __init__(self, color):
        self.color = color

    def write(self, text):
        echo(text, nl=False, color=self.color)

    def flush(self):
        sys.stdout.flush()


class _PagerWriter:
    def __init__(self, stream, color):
        self.stream = stream
        self.color = color

    def write(self, text):
        if self.color is not True:
            text = unstyle(text)
        self.stream.write(text)

    def flush(self):
        self.stream.flush()


@contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream that goes through the pager when interactive."""
    if not is_interactive():
        yield _EchoWriter(color)
        return
    pager = os.environ.get("PAGER") or "less"
    try:
        proc = subprocess.Popen(shlex.split(pager), stdin=subprocess.PIPE)
    except OSError:
        yield _EchoWriter(color)
        return
    stream = io.TextIOWrapper(proc.stdin, encoding="utf-8", errors="replace", write_through=True)
    try:
        yield _PagerWriter(stream, color)
    finally:
        try:
            stream.close()
        except (BrokenPipeError, OSError):
            pass
        proc.wait()


def echo_via_pager(text_or_generator, color=None):
    """Write a string, an iterable of strings, or a callable result through a pager."""
    text = text_or_generator() if callable(text_or_generator) else text_or_generator
    chunks = [text] if isinstance(text, str) else text
    with get_pager_file(color=color) as writer:
        for chunk in chunks:
            writer.write(chunk)
            writer.flush()


class ProgressBar:
    """Shows progress over an iterable, or advances by explicit steps."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, file=None, width=36, show_eta=True, **options):
        self.iter = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.file = file if file is not None else sys.stdout
        self.width = width
        self.show_eta = show_eta
        self.options = options
        self.pos = 0
        self.start = time.time()
        self.is_tty = (not hidden) and _is_tty(self.file)
        self._label_printed = False
        self._finished = False

    def __enter__(self):
        self._start_output()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.render_finish()

    def __iter__(self):
        if self.iter is None:
            raise TypeError("This progress bar has no iterable.")
        self._start_output()
        self.render_progress()
        for item in self.iter:
            yield item
            self.update(1)
        self.render_finish()

    def _start_output(self):
        if not self.hidden and not self.is_tty and self.label and not self._label_printed:
            echo(self.label, file=self.file)
            self._label_printed = True

    def update(self, n_steps):
        self.pos += n_steps
        self.render_progress()

    def _eta_text(self):
        if not self.show_eta or not self.length or self.pos <= 0:
            return ""
        elapsed = time.time() - self.start
        remaining = (self.length - self.pos) * elapsed / self.pos
        return f"  eta {int(remaining)}s"

    def render_progress(self):
        if self.hidden or not self.is_tty:
            return
        label = f"{self.label}  " if self.label else ""
        if self.length:
            fraction = min(max(self.pos / self.length, 0.0), 1.0)
            filled = int(self.width * fraction)
            bar = "#" * filled + "-" * (self.width - filled)
            line = f"\r{label}[{bar}] {self.pos}/{self.length} {int(fraction * 100):3d}%{self._eta_text()}"
        else:
            line = f"\r{label}{self.pos}"
        self.file.write(line)
        self.file.flush()

    def render_finish(self):
        if self._finished:
            return
        self._finished = True
        if self.hidden or not self.is_tty:
            return
        self.file.write("\n")
        self.file.flush()


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    """Return a progress bar, usable as a context manager or as an iterator wrapper."""
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)
