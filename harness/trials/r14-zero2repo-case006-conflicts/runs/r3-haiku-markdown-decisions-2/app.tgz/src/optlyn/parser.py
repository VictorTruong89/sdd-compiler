"""POSIX-style command line parser used by commands and groups.

The parser only sorts tokens. It records raw values per option and per
argument; conversion, defaults and callbacks happen in :mod:`optlyn.core`.
"""

from .exceptions import BadOptionUsage, NoSuchOption, OptlynError


class _Sentinel:
    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return self._name


#: No value from any source (an omitted parameter).
UNSET = _Sentinel("UNSET")
#: An option with a prompt was given without a value; the prompt decides.
NO_VALUE = _Sentinel("NO_VALUE")
#: An optional-value option was given with no value; its flag value applies.
FLAG_VALUE = _Sentinel("FLAG_VALUE")


class _Literal(str):
    """A token that followed the ``--`` separator; it is never an option."""

    __slots__ = ()


def _unpack_args(tokens, specs):
    """Split ``tokens`` among argument arities. ``-1`` means variadic."""
    result = []
    idx = 0
    total = len(tokens)
    for i, nargs in enumerate(specs):
        if nargs == -1:
            later_fixed = sum(s for s in specs[i + 1 :] if s > 0)
            take = max(0, total - idx - later_fixed)
        else:
            take = min(nargs, total - idx)
        result.append(list(tokens[idx : idx + take]))
        idx += take
    return result, list(tokens[idx:])


class OptionParser:
    """Parses one command's tokens against its options and arguments."""

    def __init__(self, ctx):
        self.ctx = ctx
        self.allow_interspersed_args = ctx.allow_interspersed_args
        self.ignore_unknown_options = ctx.ignore_unknown_options
        self.resilient = ctx.resilient_parsing
        self._normalize = ctx.token_normalize_func or (lambda token: token)
        self.prefixes = {"-"}
        self._names = {}
        self._args = []
        self.opts = {}
        self.order = []
        self.arg_values = {}

    def add_option(self, option):
        for name in option.opts:
            self._register(name, option, False)
        for name in option.secondary_opts:
            self._register(name, option, True)

    def add_argument(self, argument):
        self._args.append(argument)

    def _register(self, name, option, secondary):
        self.prefixes.add(name[0])
        self._names[self._normalize(name)] = (option, secondary)

    def is_option_like(self, token):
        return not isinstance(token, _Literal) and len(token) > 1 and token[0] in self.prefixes

    def parse_args(self, args):
        """Return ``(opts, arg_values, leftover, order)``.

        ``opts`` maps each option to its list of raw occurrences; ``arg_values``
        maps each argument to the tokens it received; ``order`` lists options and
        arguments in invocation order.
        """
        rargs = list(args)
        largs = []
        try:
            self._process_args_for_options(rargs, largs)
        except OptlynError:
            if not self.resilient:
                raise
        leftover = self._process_args_for_args(largs + rargs)
        return self.opts, self.arg_values, leftover, self.order

    def _process_args_for_options(self, rargs, largs):
        while rargs:
            arg = rargs.pop(0)
            if arg == "--":
                rargs[:] = [_Literal(token) for token in rargs]
                return
            if self.is_option_like(arg):
                self._process_opts(arg, rargs, largs)
            elif self.allow_interspersed_args:
                largs.append(arg)
            else:
                rargs.insert(0, arg)
                return

    def _process_opts(self, arg, rargs, largs):
        if "=" in arg:
            name, explicit = arg.split("=", 1)
        else:
            name, explicit = arg, None
        key = self._normalize(name)
        if key in self._names:
            option, secondary = self._names[key]
            self._match_option(option, secondary, name, explicit, rargs)
            return
        if len(arg) > 2 and arg[1] in self.prefixes:
            if self.ignore_unknown_options or self.resilient:
                largs.append(arg)
                return
            raise NoSuchOption(name)
        prefix = arg[0]
        chars = arg[1:]
        for i, ch in enumerate(chars):
            short = prefix + ch
            key = self._normalize(short)
            if key not in self._names:
                if self.ignore_unknown_options or self.resilient:
                    largs.append(prefix + chars[i:])
                    return
                raise NoSuchOption(short)
            option, secondary = self._names[key]
            if not option.takes_value:
                self._record(option, option.cmdline_value(secondary), secondary)
                continue
            rest = chars[i + 1 :]
            if rest:
                value = self._value_with_rest(option, rest, rargs, short)
            else:
                value = self._take_value(option, rargs, short)
            self._record(option, value, secondary)
            return

    def _match_option(self, option, secondary, name, explicit, rargs):
        if not option.takes_value:
            if explicit is not None:
                raise BadOptionUsage(f"Option {name!r} does not take a value.")
            self._record(option, option.cmdline_value(secondary), secondary)
            return
        if explicit is not None:
            value = self._value_with_rest(option, explicit, rargs, name)
        else:
            value = self._take_value(option, rargs, name)
        self._record(option, value, secondary)

    def _value_with_rest(self, option, first, rargs, name):
        if option.nargs == 1:
            return first
        values = [first]
        for _ in range(option.nargs - 1):
            values.append(self._pop_required(rargs, option, name))
        return tuple(values)

    def _pop_required(self, rargs, option, name):
        if not rargs:
            raise BadOptionUsage(f"Option {name!r} requires an argument.")
        return rargs.pop(0)

    def _take_value(self, option, rargs, name):
        if option.is_optional_value:
            if rargs and not self.is_option_like(rargs[0]):
                return rargs.pop(0)
            return FLAG_VALUE
        if option.nargs == 1:
            if not rargs:
                if option.prompt:
                    return NO_VALUE
                raise BadOptionUsage(f"Option {name!r} requires an argument.")
            return rargs.pop(0)
        values = [self._pop_required(rargs, option, name) for _ in range(option.nargs)]
        return tuple(values)

    def _record(self, option, value, secondary):
        self.opts.setdefault(option, []).append(value)
        if option not in self.order:
            self.order.append(option)

    def _process_args_for_args(self, tokens):
        specs = [arg.nargs for arg in self._args]
        pargs, leftover = _unpack_args(tokens, specs)
        for arg, values in zip(self._args, pargs):
            self.arg_values[arg] = values
            self.order.append(arg)
        return leftover


__all__ = [
    "UNSET",
    "NO_VALUE",
    "FLAG_VALUE",
    "OptionParser",
    "_Literal",
]
