"""In-process command runner for tests (``optlyn.testing.CliRunner``)."""

import io
import os
import sys
import tempfile
from contextlib import contextmanager

from .exceptions import Abort


class _Recorder:
    """Shared record of writes, so stdout and stderr keep their write order."""

    def __init__(self):
        self.combined = io.BytesIO()


class _CaptureBuffer(io.BufferedIOBase):
    def __init__(self, owner):
        self._owner = owner

    def write(self, data):
        self._owner.write_bytes(bytes(data))
        return len(data)

    def flush(self):
        pass

    def writable(self):
        return True


class _CaptureText(io.TextIOBase):
    """An interpreter-level output stream that records what is written to it."""

    def __init__(self, recorder, name, charset):
        self._recorder = recorder
        self._name = name
        self._charset = charset
        self._buffer = io.BytesIO()
        self.buffer = _CaptureBuffer(self)

    def isatty(self):
        return False

    def fileno(self):
        raise io.UnsupportedOperation("fileno")

    @property
    def encoding(self):
        return self._charset

    @property
    def errors(self):
        return "replace"

    @property
    def name(self):
        return f"<{self._name}>"

    def writable(self):
        return True

    def write_bytes(self, data):
        self._buffer.write(data)
        self._recorder.combined.write(data)

    def write(self, text):
        self.write_bytes(text.encode(self._charset, "replace"))
        return len(text)

    def flush(self):
        pass

    def getvalue_bytes(self):
        return self._buffer.getvalue()


class _CaptureInput(io.TextIOBase):
    """Standard input fed from the ``input`` argument of :meth:`CliRunner.invoke`."""

    def __init__(self, data, charset, echo_stdin, recorder):
        if isinstance(data, bytes):
            text = data.decode(charset, "replace")
        else:
            text = data or ""
        self._lines = io.StringIO(text)
        self._charset = charset
        self._echo_stdin = echo_stdin
        self._recorder = recorder
        # Read by the prompt helpers: visible prompts echo the line they read.
        self.echo_prompts = True
        self.echo_stdin = echo_stdin

    def isatty(self):
        return False

    def readable(self):
        return True

    def _record(self, text):
        if self._echo_stdin and text:
            self._recorder.combined.write(text.encode(self._charset, "replace"))

    def read(self, size=-1):
        data = self._lines.read(size)
        self._record(data)
        return data

    def readline(self, size=-1):
        line = self._lines.readline(size)
        self._record(line)
        return line

    def __iter__(self):
        return self

    def __next__(self):
        line = self.readline()
        if not line:
            raise StopIteration
        return line

    def fileno(self):
        raise io.UnsupportedOperation("fileno")


class _Capture:
    """Holds the captured streams for one invocation."""

    def __init__(self, charset):
        self.charset = charset
        self.recorder = _Recorder()
        self.stdout = None
        self.stderr = None
        self.stdin = None
        self._fd_files = None

    def collect(self):
        """Return ``(stdout_bytes, stderr_bytes, output_bytes)``."""
        if self._fd_files is None:
            return (
                self.stdout.getvalue_bytes(),
                self.stderr.getvalue_bytes(),
                self.recorder.combined.getvalue(),
            )
        out_file, err_file = self._fd_files
        out_file.seek(0)
        err_file.seek(0)
        stdout_bytes = out_file.read()
        stderr_bytes = err_file.read()
        return stdout_bytes, stderr_bytes, stdout_bytes + stderr_bytes


class Result:
    """The outcome of :meth:`CliRunner.invoke`."""

    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value, exit_code, exception, exc_info):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self):
        return self.output_bytes.decode(self.runner.charset, "replace")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    """Invokes a command with argument tokens and captures its output and status."""

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextmanager
    def isolation(self, input=None, env=None):
        capture = _Capture(self.charset)
        capture.stdin = _CaptureInput(input, self.charset, self.echo_stdin, capture.recorder)
        merged = dict(self.env)
        merged.update(env or {})
        saved_env = {key: os.environ.get(key) for key in merged}
        old_streams = (sys.stdin, sys.stdout, sys.stderr)
        saved_fds = None
        try:
            for key, value in merged.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = str(value)
            if self.capture == "fd":
                saved_fds = self._redirect_fds(capture)
            else:
                capture.stdout = _CaptureText(capture.recorder, "stdout", self.charset)
                capture.stderr = _CaptureText(capture.recorder, "stderr", self.charset)
                sys.stdout, sys.stderr = capture.stdout, capture.stderr
            sys.stdin = capture.stdin
            yield capture
        finally:
            if self.capture == "fd":
                self._restore_fds(saved_fds)
            sys.stdin, sys.stdout, sys.stderr = old_streams
            for key, value in saved_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def _redirect_fds(self, capture):
        """Point descriptors 1 and 2 at temporary files, with real-fd streams on top."""
        sys.stdout.flush()
        sys.stderr.flush()
        out_file = tempfile.TemporaryFile()
        err_file = tempfile.TemporaryFile()
        saved = (os.dup(1), os.dup(2))
        os.dup2(out_file.fileno(), 1)
        os.dup2(err_file.fileno(), 2)
        sys.stdout = io.TextIOWrapper(
            io.open(1, "wb", closefd=False), encoding=self.charset, errors="replace", write_through=True
        )
        sys.stderr = io.TextIOWrapper(
            io.open(2, "wb", closefd=False), encoding=self.charset, errors="replace", write_through=True
        )
        capture._fd_files = (out_file, err_file)
        return saved, out_file, err_file

    def _restore_fds(self, saved_fds):
        if saved_fds is None:
            return
        (saved_out, saved_err), out_file, err_file = saved_fds
        for stream in (sys.stdout, sys.stderr):
            try:
                stream.flush()
            except (OSError, ValueError):
                pass
        os.dup2(saved_out, 1)
        os.dup2(saved_err, 2)
        os.close(saved_out)
        os.close(saved_err)

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        """Run ``cli`` with the tokens ``args`` and return a :class:`Result`."""
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if args is None:
            args = []
        elif isinstance(args, str):
            args = args.split()
        extra.setdefault("prog_name", "cli")
        standalone = extra.pop("standalone_mode", True)
        extra.setdefault("color", color)
        exit_code = 0
        exception = None
        exc_info = None
        return_value = None
        with self.isolation(input=input, env=env) as capture:
            try:
                return_value = cli.main(args=list(args), standalone_mode=standalone, **extra)
            except SystemExit as e:
                if e.code is None:
                    exit_code = 0
                elif isinstance(e.code, int):
                    exit_code = e.code
                else:
                    print(e.code, file=sys.stderr)
                    exit_code = 1
            except Abort as e:
                exit_code = 1
                exception = e
                exc_info = sys.exc_info()
            except Exception as e:
                if not catch_exceptions:
                    raise
                exit_code = 1
                exception = e
                exc_info = sys.exc_info()
            for stream in (sys.stdout, sys.stderr):
                try:
                    stream.flush()
                except (OSError, ValueError):
                    pass
            stdout_bytes, stderr_bytes, output_bytes = capture.collect()
        return Result(self, stdout_bytes, stderr_bytes, output_bytes, return_value, exit_code, exception, exc_info)

    @contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Run inside a new empty directory. The directory is left in place afterwards."""
        cwd = os.getcwd()
        path = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)


__all__ = ["CliRunner", "Result"]
