"""Exception classes raised by Optlyn and their standalone-mode presentation."""


class OptlynError(Exception):
    """Base class for errors that the standalone runner reports and exits on."""

    exit_code = 1

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.message = message
        self.ctx = ctx

    def format_message(self):
        return self.message

    def show(self, file=None):
        from .utils import echo

        echo(f"Error: {self.format_message()}", file=file, err=True)


class UsageError(OptlynError):
    """Incorrect command line usage. Exit status 2."""

    exit_code = 2

    def show(self, file=None):
        from .utils import echo

        if self.ctx is not None:
            echo(self.ctx.get_usage() + "\n", file=file, err=True)
            hint = self.ctx.help_hint()
            if hint:
                echo(hint + "\n", file=file, err=True)
        echo(f"Error: {self.format_message()}", file=file, err=True)


class BadParameter(UsageError):
    """A value that cannot be converted or was refused by a callback."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        if self.param_hint is not None:
            hint = self.param_hint
        elif self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        else:
            return f"Invalid value: {self.message}"
        return f"Invalid value for {hint}: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter received no value from any source."""

    def __init__(self, message=None, ctx=None, param=None, param_hint=None):
        super().__init__(message or "", ctx, param, param_hint)

    def format_message(self):
        if self.param_hint is not None:
            hint = self.param_hint
        elif self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        else:
            hint = None
        kind = "argument" if self.param is not None and self.param.is_argument else "option"
        if hint is None:
            return self.message or "Missing parameter."
        return f"Missing {kind} {hint}." if not self.message else self.message


class NoSuchOption(UsageError):
    """An option name that the command does not declare."""

    def __init__(self, option_name, message=None, ctx=None):
        if message is None:
            message = f"No such option: {option_name}"
        super().__init__(message, ctx)
        self.option_name = option_name


class BadOptionUsage(UsageError):
    """An option was used incorrectly, for example without its value."""


class BadArgumentUsage(UsageError):
    """A positional argument was used incorrectly."""


class NoArgsIsHelpError(UsageError):
    """Help shown because a command was run with no arguments. Exit status 2."""

    def show(self, file=None):
        from .utils import echo

        if self.ctx is not None:
            echo(self.ctx.get_help(), file=file, err=True)


class FileError(OptlynError):
    """A file could not be opened at first I/O. General error, exit status 1."""

    def __init__(self, filename, hint=None):
        self.ui_filename = filename
        self.hint = hint or "unknown error"
        super().__init__(f"Could not open file '{filename}': {self.hint}")


class Abort(RuntimeError):
    """The user declined, input ended, or the author aborted. Exit status 1."""


class Exit(RuntimeError):
    """Author clean stop with an optional status code."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code
