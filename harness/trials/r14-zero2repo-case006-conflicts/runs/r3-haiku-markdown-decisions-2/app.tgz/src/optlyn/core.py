"""Commands, groups, parameters and invocation contexts."""

import enum
import inspect
import os
import sys
from contextlib import ExitStack, contextmanager

from . import param_types as pt
from .exceptions import (
    Abort,
    BadArgumentUsage,
    BadOptionUsage,
    BadParameter,
    Exit,
    MissingParameter,
    NoArgsIsHelpError,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .formatting import HelpFormatter
from .globals import pop_context, push_context
from .param_types import BOOL, INT, convert_type
from .parser import FLAG_VALUE, NO_VALUE, UNSET, OptionParser
from .termui import confirm, prompt
from .utils import echo

_PREFIX_CHARS = set("-+/")
_DEFAULT_HELP_NAMES = ["--help"]


class ParameterSource(enum.Enum):
    """Where a parameter's value came from."""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


# Lower rank is more explicit; used when several parameters share a destination.
_SOURCE_RANK = {
    ParameterSource.PROMPT: 0,
    ParameterSource.COMMANDLINE: 1,
    ParameterSource.ENVIRONMENT: 2,
    ParameterSource.DEFAULT_MAP: 3,
    ParameterSource.DEFAULT: 4,
    None: 5,
}


def _is_missing(value):
    return value is UNSET or value is None or (isinstance(value, tuple) and value == ())


def _warn_deprecated(kind, name):
    echo(f"DeprecationWarning: The {kind} {name!r} is deprecated.", err=True)


def _show_help(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


class Context:
    """The state of one command invocation."""

    def __init__(
        self,
        command,
        parent=None,
        info_name=None,
        obj=None,
        auto_envvar_prefix=None,
        default_map=None,
        terminal_width=None,
        max_content_width=None,
        resilient_parsing=False,
        allow_extra_args=None,
        allow_interspersed_args=None,
        ignore_unknown_options=None,
        help_option_names=None,
        token_normalize_func=None,
        color=None,
        show_default=None,
    ):
        self.parent = parent
        self.command = command
        self.info_name = info_name
        if obj is None and parent is not None:
            obj = parent.obj
        self.obj = obj
        if auto_envvar_prefix is None and parent is not None and parent.auto_envvar_prefix and info_name:
            auto_envvar_prefix = f"{parent.auto_envvar_prefix}_{info_name.upper().replace('-', '_')}"
        self.auto_envvar_prefix = auto_envvar_prefix
        self.default_map = default_map if isinstance(default_map, dict) else None

        def inherited(value, attr, fallback):
            if value is not None:
                return value
            if parent is not None:
                return getattr(parent, attr)
            return fallback

        self.terminal_width = inherited(terminal_width, "terminal_width", None)
        self.max_content_width = inherited(max_content_width, "max_content_width", 80)
        self.help_option_names = list(inherited(help_option_names, "help_option_names", _DEFAULT_HELP_NAMES))
        self.token_normalize_func = inherited(token_normalize_func, "token_normalize_func", None)
        self.color = inherited(color, "color", None)
        self.show_default = bool(inherited(show_default, "show_default", False))
        self.ignore_unknown_options = bool(inherited(ignore_unknown_options, "ignore_unknown_options", False))
        self.resilient_parsing = resilient_parsing or (parent.resilient_parsing if parent else False)
        self.allow_extra_args = (
            command.allow_extra_args if allow_extra_args is None else allow_extra_args
        )
        self.allow_interspersed_args = (
            command.allow_interspersed_args if allow_interspersed_args is None else allow_interspersed_args
        )
        self.params = {}
        self.args = []
        self.protected_args = []
        self.invoked_subcommand = None
        self._parameter_source = {}
        self._dest_rank = {}
        self._exit_stack = ExitStack()
        self._depth = 0

    @property
    def command_path(self):
        rv = self.info_name or ""
        if self.parent is not None and self.parent.command_path:
            rv = f"{self.parent.command_path} {rv}"
        return rv.lstrip()

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type):
        node = self
        while node is not None:
            if type(node.obj) is object_type:
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        rv = self.find_object(object_type)
        if rv is None:
            self.obj = rv = object_type()
        return rv

    def lookup_default(self, name):
        if self.default_map is None:
            return UNSET
        value = self.default_map.get(name, UNSET)
        return UNSET if value is None else value

    def get_parameter_source(self, name):
        return self._parameter_source.get(name)

    def fail(self, message):
        raise UsageError(message, ctx=self)

    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def call_on_close(self, f):
        self._exit_stack.callback(f)

    def with_resource(self, cm):
        return self._exit_stack.enter_context(cm)

    def close(self):
        self._exit_stack.close()

    def invoke(self, callback, *args, **kwargs):
        """Call a command (filling defaults for missing parameters) or a function."""
        if isinstance(callback, Command):
            other = callback
            sub = Context(other, parent=self, info_name=other.name)
            for param in other.params:
                if param.name not in kwargs and param.expose_value:
                    default = param.get_default(sub)
                    kwargs[param.name] = None if default is UNSET else param.type_cast_value(sub, default)
            sub.params.update({k: v for k, v in kwargs.items()})
            with sub:
                if other.callback is None:
                    return None
                return other.callback(*args, **kwargs)
        return callback(*args, **kwargs)

    def forward(self, cmd, *args, **kwargs):
        values = dict(self.params)
        values.update(kwargs)
        return self.invoke(cmd, *args, **values)

    def get_usage(self):
        return self.command.get_usage(self)

    def get_help(self):
        return self.command.get_help(self)

    def help_hint(self):
        if not self.help_option_names:
            return None
        return f"Try '{self.command_path} {self.help_option_names[0]}' for help."

    def _enter(self):
        self._depth += 1
        push_context(self)

    def _leave(self, cleanup):
        pop_context()
        self._depth -= 1
        if cleanup and self._depth == 0:
            self.close()

    @contextmanager
    def scope(self, cleanup=False):
        self._enter()
        try:
            yield self
        finally:
            self._leave(cleanup)

    def __enter__(self):
        self._enter()
        return self

    def __exit__(self, exc_type, exc, tb):
        self._leave(cleanup=True)


class Parameter:
    """Shared behavior of options and arguments."""

    is_argument = False
    skip_conversion = False
    #: True when the default is derived implicitly (a bare boolean flag's ``False``).
    auto_default = False

    def __init__(
        self,
        name,
        type_=None,
        required=False,
        default=UNSET,
        callback=None,
        nargs=1,
        multiple=False,
        metavar=None,
        expose_value=True,
        is_eager=False,
        envvar=None,
        shell_complete=None,
        deprecated=False,
        help=None,
        hidden=False,
    ):
        self.name = name
        self.default = default
        self.callback = callback
        self.multiple = multiple
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        self.shell_complete_func = shell_complete
        self.deprecated = deprecated
        self.help = help
        self.hidden = hidden
        self.required = required
        self.type = convert_type(type_, None if default is UNSET or callable(default) else default)
        if isinstance(self.type, pt.Tuple):
            nargs = len(self.type.types)
        self.nargs = nargs
        if envvar is None:
            self.envvar = None
        elif isinstance(envvar, str):
            self.envvar = [envvar]
        else:
            self.envvar = list(envvar)

    # -- declaration-time helpers ------------------------------------------------

    def add_to_parser(self, parser, ctx):
        raise NotImplementedError

    def get_error_hint(self, ctx):
        raise NotImplementedError

    def make_metavar(self, ctx=None):
        if self.metavar is not None:
            return self.metavar
        return self.type.get_metavar(self) or self.type.name.upper()

    def shell_complete(self, ctx, incomplete):
        if self.shell_complete_func is not None:
            return self.shell_complete_func(ctx, self, incomplete)
        return self.type.shell_complete(ctx, self, incomplete)

    # -- value resolution ----------------------------------------------------------

    def get_default(self, ctx):
        """The declared default, or UNSET. Callable defaults are invoked here."""
        default = self.default
        if default is UNSET:
            return UNSET
        if callable(default):
            default = default()
        if default is None:
            return UNSET if (self.multiple or self.nargs == -1) else None
        if self.multiple or self.nargs != 1:
            if isinstance(default, str):
                if self.multiple and self.nargs == 1:
                    raise BadOptionUsage(
                        f"{self.get_error_hint(ctx)} needs an iterable (sequence) default.", ctx=ctx
                    )
                return tuple(self.type.split_envvar_value(default))
            return tuple(default)
        return default

    def default_map_value(self, ctx):
        value = ctx.lookup_default(self.name)
        if value is UNSET:
            return UNSET
        if self.multiple or self.nargs != 1:
            if isinstance(value, str):
                if self.multiple and self.nargs == 1:
                    raise BadOptionUsage(
                        f"{self.get_error_hint(ctx)} needs an iterable (sequence) default.", ctx=ctx
                    )
                return tuple(self.type.split_envvar_value(value))
            return tuple(value)
        return value

    def _cast_item(self, ctx, value):
        if isinstance(self.type, pt.Tuple):
            return self.type.convert(value, self, ctx)
        if self.nargs > 1:
            return tuple(self.type.convert(item, self, ctx) for item in value)
        return self.type.convert(value, self, ctx)

    def type_cast_value(self, ctx, value):
        if value is UNSET or value is None or self.skip_conversion:
            return value
        if self.multiple or self.nargs == -1:
            return tuple(self._cast_item(ctx, item) for item in value)
        return self._cast_item(ctx, value)

    def value_from_envvar(self, ctx):
        names = self.envvar_names(ctx)
        raw = None
        for name in names:
            candidate = os.environ.get(name)
            if candidate:
                raw = candidate
                break
        if raw is None:
            return UNSET
        if self.nargs == -1 or self.multiple or self.nargs != 1:
            return tuple(self.type.split_envvar_value(raw))
        return raw

    def envvar_names(self, ctx):
        return list(self.envvar or [])

    def process_parse(self, ctx, opts, arg_values):
        """Resolve this parameter's value, convert it, run its callback and store it."""
        raw = self.raw_value(opts, arg_values)
        if self.deprecated and raw is not None:
            _warn_deprecated("argument" if self.is_argument else "option", self.name)
        try:
            value, source = self.resolve(ctx, raw)
            if _is_missing(value) and self.required and not ctx.resilient_parsing:
                raise MissingParameter(ctx=ctx, param=self)
            if value is UNSET:
                out = () if self.multiple or self.nargs == -1 else None
            else:
                value = self.type_cast_value(ctx, value)
                if self.callback is not None:
                    value = self.callback(ctx, self, value)
                out = value
        except BadParameter as e:
            if e.param is None:
                e.param = self
            if e.ctx is None:
                e.ctx = ctx
            raise
        ctx._parameter_source[self.name] = source
        if self.expose_value:
            auto = source is ParameterSource.DEFAULT and self.auto_default
            key = (_SOURCE_RANK[source], 1 if auto else 0)
            if key <= ctx._dest_rank.get(self.name, (_SOURCE_RANK[None], 0)):
                ctx.params[self.name] = out
                ctx._dest_rank[self.name] = key


class Option(Parameter):
    """A named parameter, given on the command line as a flag or a value."""

    def __init__(
        self,
        param_decls=None,
        show_default=None,
        prompt=False,
        confirmation_prompt=False,
        prompt_required=True,
        hide_input=False,
        is_flag=None,
        flag_value=UNSET,
        count=False,
        allow_from_autoenv=True,
        type=None,
        help=None,
        hidden=False,
        show_choices=True,
        show_envvar=False,
        deprecated=False,
        metavar=None,
        default=UNSET,
        required=False,
        multiple=False,
        nargs=1,
        envvar=None,
        callback=None,
        is_eager=False,
        expose_value=True,
        shell_complete=None,
    ):
        opts, secondary, dest = _parse_option_decls(param_decls or ())
        if not opts and dest is None:
            raise TypeError("An option needs at least one name.")
        if dest is None:
            dest = _derive_dest(opts)
        if count:
            is_flag = False
        if is_flag is None:
            if flag_value is not UNSET:
                is_flag = True
            else:
                is_flag = bool(secondary) or isinstance(default, bool) or type is BOOL or isinstance(type, pt.BoolParamType)
        if is_flag and flag_value is UNSET:
            flag_value = True
        if is_flag and type is None and not count:
            type = BOOL
        if count:
            type = INT if type is None else type
            if default is UNSET:
                default = 0
        if deprecated and required:
            raise TypeError("A deprecated option cannot be required.")
        if deprecated and prompt:
            raise TypeError("A deprecated option cannot use a prompt.")
        super().__init__(
            dest,
            type_=type,
            required=required,
            default=default,
            callback=callback,
            nargs=nargs,
            multiple=multiple,
            metavar=metavar,
            expose_value=expose_value,
            is_eager=is_eager,
            envvar=envvar,
            shell_complete=shell_complete,
            deprecated=deprecated,
            help=help,
            hidden=hidden,
        )
        self.opts = opts
        self.secondary_opts = secondary
        self.is_flag = bool(is_flag)
        self.count = bool(count)
        self.flag_value = flag_value
        self.is_optional_value = (not self.is_flag) and (not self.count) and flag_value is not UNSET
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.show_choices = show_choices
        self.allow_from_autoenv = allow_from_autoenv
        self.prompt = prompt
        self.prompt_text = prompt if isinstance(prompt, str) else dest.replace("_", " ").capitalize()
        self.prompt_required = prompt_required
        self.confirmation_prompt = confirmation_prompt
        self.hide_input = hide_input
        self.auto_default = self.is_flag and (default is UNSET or default is None)
        if self.is_flag:
            self.type = BOOL
        if self.prompt and self.nargs != 1:
            raise TypeError("A prompting option must take a single value.")

    @property
    def takes_value(self):
        return not (self.is_flag or self.count)

    @property
    def is_bool_flag(self):
        return self.is_flag and isinstance(self.flag_value, bool)

    @property
    def skip_conversion(self):
        return self.is_flag or self.count

    def cmdline_value(self, secondary):
        if self.count:
            return None
        if secondary:
            return False
        return self.flag_value

    def add_to_parser(self, parser, ctx):
        parser.add_option(self)

    def get_error_hint(self, ctx):
        return " / ".join(f"'{name}'" for name in self.opts + self.secondary_opts)

    def make_metavar(self, ctx=None):
        if self.metavar is not None:
            return self.metavar
        if self.is_flag or self.count:
            return None
        return self.type.get_metavar(self) or self.type.name.upper()

    def envvar_names(self, ctx):
        if self.envvar is not None:
            return list(self.envvar)
        if self.allow_from_autoenv and ctx.auto_envvar_prefix:
            prefix = ctx.auto_envvar_prefix.replace("-", "_").upper()
            return [f"{prefix}_{self.name.upper()}"]
        return []

    def value_from_envvar(self, ctx):
        names = self.envvar_names(ctx)
        raw = None
        for name in names:
            candidate = os.environ.get(name)
            if candidate:
                raw = candidate
                break
        if raw is None:
            return UNSET
        if self.is_flag:
            return self._flag_from_env(raw)
        if self.count:
            return UNSET
        if self.multiple or self.nargs != 1:
            return tuple(self.type.split_envvar_value(raw))
        return raw

    def _flag_from_env(self, raw):
        text = raw.strip().lower()
        if self.is_bool_flag:
            if text in pt._TRUE:
                return True
            if text in pt._FALSE or text == "":
                return False
            raise BadParameter(f"{raw!r} is not a valid boolean.", param=self)
        if raw == str(self.flag_value) or text in pt._TRUE:
            return self.flag_value
        return UNSET

    def raw_value(self, opts, arg_values):
        return opts.get(self)

    def _merge_occurrences(self, raw):
        if raw is None:
            return UNSET
        if self.count:
            return len(raw)
        if self.is_flag:
            return raw[-1]
        if self.multiple:
            return tuple(raw)
        last = raw[-1]
        if last is FLAG_VALUE:
            return self.flag_value
        return last

    def get_default(self, ctx):
        if self.count and self.default is UNSET:
            return 0
        if self.is_flag and (self.default is UNSET or self.default is None):
            return False
        return super().get_default(ctx)

    def resolve(self, ctx, raw):
        """Value order: command line, default map, environment, declared default.

        A prompt runs when it applies; it shows the default-map or declared default
        and is skipped when an environment value supplies the option.
        """
        cmd = self._merge_occurrences(raw)
        if cmd is not UNSET and cmd is not NO_VALUE:
            return cmd, ParameterSource.COMMANDLINE
        prompting = bool(self.prompt) and not ctx.resilient_parsing and (
            cmd is NO_VALUE or (cmd is UNSET and (self.prompt_required or self.required))
        )
        dm = self.default_map_value(ctx)
        if dm is not UNSET:
            if prompting:
                return self._prompt_for_value(ctx, dm), ParameterSource.PROMPT
            return dm, ParameterSource.DEFAULT_MAP
        env = self.value_from_envvar(ctx)
        if env is not UNSET:
            return env, ParameterSource.ENVIRONMENT
        if prompting:
            value = self._prompt_for_value(ctx, self._default_for_prompt(ctx))
            return value, ParameterSource.PROMPT
        dv = self.get_default(ctx)
        if dv is not UNSET:
            return dv, ParameterSource.DEFAULT
        return UNSET, None

    def _default_for_prompt(self, ctx):
        dm = self.default_map_value(ctx)
        if dm is not UNSET:
            return dm
        dv = self.get_default(ctx)
        return None if dv is UNSET else dv

    def _prompt_for_value(self, ctx, default):
        if self.is_flag:
            return confirm(self.prompt_text, default=bool(default))
        return prompt(
            self.prompt_text,
            default=default,
            type=self.type,
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            show_default=self.show_default if self.show_default is not None else ctx.show_default,
        )


class Argument(Parameter):
    """A positional parameter."""

    is_argument = True

    def __init__(self, param_decls, required=None, default=UNSET, nargs=1, type=None, **attrs):
        decls = list(param_decls)
        if len(decls) != 1:
            raise TypeError("An argument takes exactly one destination name.")
        if nargs == 0 or (nargs != -1 and nargs < 1):
            raise TypeError("nargs must be a positive integer or -1.")
        if required is None:
            required = default is UNSET and nargs != -1
        if attrs.get("deprecated") and required:
            raise TypeError("A deprecated argument cannot be required.")
        super().__init__(decls[0], type_=type, required=required, default=default, nargs=nargs, **attrs)

    def add_to_parser(self, parser, ctx):
        parser.add_argument(self)

    def get_error_hint(self, ctx):
        return f"'{self.name.upper()}'"

    def make_metavar(self, ctx=None):
        return self.metavar if self.metavar is not None else self.name.upper()

    def envvar_names(self, ctx):
        return list(self.envvar or [])

    def raw_value(self, opts, arg_values):
        values = arg_values.get(self)
        return values if values else None

    def resolve(self, ctx, raw):
        if raw is not None:
            if self.nargs == 1:
                return str(raw[0]), ParameterSource.COMMANDLINE
            if self.nargs > 0 and len(raw) < self.nargs:
                raise BadArgumentUsage(
                    f"Argument {self.name.upper()!r} takes {self.nargs} values.", ctx=ctx
                )
            return tuple(str(token) for token in raw), ParameterSource.COMMANDLINE
        env = self.value_from_envvar(ctx)
        if env is not UNSET:
            return env, ParameterSource.ENVIRONMENT
        dm = self.default_map_value(ctx)
        if dm is not UNSET:
            return dm, ParameterSource.DEFAULT_MAP
        dv = self.get_default(ctx)
        if dv is not UNSET:
            return dv, ParameterSource.DEFAULT
        return UNSET, None


def _parse_option_decls(decls):
    opts, secondary, dest = [], [], None
    for decl in decls:
        if not decl:
            continue
        if not decl[0].isalnum() and decl[0] != "_":
            first, sep, second = decl.partition("/")
            if sep and first and second and second[0] in _PREFIX_CHARS:
                opts.append(first)
                secondary.append(second)
            else:
                opts.append(decl)
        else:
            dest = decl
    return opts, secondary, dest


def _derive_dest(opts):
    for name in opts:
        if name.isidentifier():
            return name
    for name in opts:
        if len(name) - len(name.lstrip("-+/")) >= 2:
            return name.lstrip("-+/").replace("-", "_")
    return opts[0].lstrip("-+/").replace("-", "_")


def iter_params_for_processing(invocation_order, declaration_order):
    """Eager parameters first, then in invocation order, then declaration order."""

    def sort_key(item):
        try:
            index = invocation_order.index(item)
        except ValueError:
            index = float("inf")
        return (not item.is_eager, index)

    return sorted(declaration_order, key=sort_key)


class Command:
    """A callable unit that parses a slice of the command line."""

    allow_extra_args = False
    allow_interspersed_args = True

    def __init__(
        self,
        name,
        context_settings=None,
        callback=None,
        params=None,
        help=None,
        epilog=None,
        short_help=None,
        options_metavar="[OPTIONS]",
        add_help_option=True,
        no_args_is_help=False,
        hidden=False,
        deprecated=False,
    ):
        self.name = name
        self.context_settings = dict(context_settings or {})
        self.callback = callback
        self.params = list(params or [])
        if sum(1 for p in self.params if isinstance(p, Argument) and p.nargs == -1) > 1:
            raise TypeError("A command may declare at most one variadic argument.")
        if help is None and callback is not None and callback.__doc__:
            help = inspect.cleandoc(callback.__doc__.split("\f", 1)[0])
        if help is not None and "\f" in help:
            help = help.split("\f", 1)[0]
        self.help = help
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = deprecated

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    def get_params(self, ctx):
        rv = list(self.params)
        help_option = self.get_help_option(ctx)
        if help_option is not None:
            rv.append(help_option)
        return rv

    def get_help_option(self, ctx):
        names = ctx.help_option_names
        if not self.add_help_option or not names:
            return None
        declared = set()
        for param in self.params:
            if isinstance(param, Option):
                declared.update(param.opts + param.secondary_opts)
        keep = [name for name in names if name not in declared]
        if not keep:
            return None
        return Option(
            keep,
            is_flag=True,
            is_eager=True,
            expose_value=False,
            callback=_show_help,
            help="Show this message and exit.",
        )

    def make_parser(self, ctx, params=None):
        parser = OptionParser(ctx)
        for param in self.get_params(ctx) if params is None else params:
            param.add_to_parser(parser, ctx)
        return parser

    def make_context(self, info_name, args, parent=None, **extra):
        settings = dict(self.context_settings)
        settings.update(extra)
        if parent is not None and parent.default_map is not None and "default_map" not in extra:
            nested = parent.default_map.get(info_name)
            if isinstance(nested, dict):
                settings["default_map"] = nested
        ctx = Context(self, info_name=info_name, parent=parent, **settings)
        with ctx.scope(cleanup=False):
            try:
                self.parse_args(ctx, args)
            except BaseException:
                ctx.close()
                raise
        return ctx

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsIsHelpError("", ctx=ctx)
        params = self.get_params(ctx)
        parser = self.make_parser(ctx, params)
        opts, arg_values, rest, order = parser.parse_args(list(args))
        if rest and ctx.allow_interspersed_args and ctx.allow_extra_args and not ctx.ignore_unknown_options:
            if not isinstance(self, Group):
                for token in rest:
                    if parser.is_option_like(token):
                        raise NoSuchOption(token, ctx=ctx)
        if rest and not ctx.allow_extra_args and not ctx.resilient_parsing:
            ctx.fail(f"Got unexpected extra argument{'s' if len(rest) > 1 else ''} ({' '.join(map(str, rest))})")
        for param in iter_params_for_processing(order, params):
            param.process_parse(ctx, opts, arg_values)
        ctx.args = [str(token) for token in rest]
        return ctx.args

    def invoke(self, ctx):
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else ""
            message = f"DeprecationWarning: The command {self.name!r} is deprecated."
            echo(f"{message} {note}".rstrip(), file=sys.stdout)
        if self.callback is None:
            return None
        return ctx.invoke(self.callback, **ctx.params)

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True, **extra):
        """Run this command as a program. Returns the callback result when not standalone."""
        args = sys.argv[1:] if args is None else list(args)
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else self.name
        from .shell_completion import maybe_complete

        maybe_complete(self, prog_name, complete_var)
        try:
            try:
                with self.make_context(prog_name, args, **extra) as ctx:
                    rv = self.invoke(ctx)
                    if not standalone_mode:
                        return rv
                    ctx.exit()
            except (EOFError, KeyboardInterrupt) as e:
                echo(file=sys.stderr)
                raise Abort() from e
            except OptlynError as e:
                if not standalone_mode:
                    raise
                e.show()
                sys.exit(e.exit_code)
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return e.exit_code
        except Abort:
            if not standalone_mode:
                raise
            echo("Aborted!", file=sys.stderr)
            sys.exit(1)

    # -- help ----------------------------------------------------------------------

    def get_usage(self, ctx):
        formatter = HelpFormatter(width=ctx.terminal_width, max_width=ctx.max_content_width)
        self.format_usage(ctx, formatter)
        return formatter.getvalue().rstrip("\n")

    def get_help(self, ctx):
        formatter = HelpFormatter(width=ctx.terminal_width, max_width=ctx.max_content_width)
        self.format_help(ctx, formatter)
        return formatter.getvalue().rstrip("\n") + "\n"

    def collect_usage_pieces(self, ctx):
        pieces = [self.options_metavar]
        for param in self.get_params(ctx):
            if isinstance(param, Argument):
                pieces.append(_argument_usage(param))
        return pieces

    def format_usage(self, ctx, formatter):
        formatter.write_usage(ctx.command_path, " ".join(self.collect_usage_pieces(ctx)))

    def format_help(self, ctx, formatter):
        self.format_usage(ctx, formatter)
        self.format_description(ctx, formatter)
        self.format_arguments(ctx, formatter)
        self.format_options(ctx, formatter)
        self.format_epilog(ctx, formatter)

    def format_description(self, ctx, formatter):
        text = self.help or ""
        if self.deprecated:
            text = f"(Deprecated) {text}".strip()
        if text:
            formatter.write_paragraph()
            formatter.write_text(text)

    def format_arguments(self, ctx, formatter):
        rows = [
            (param.make_metavar(ctx), param.help)
            for param in self.get_params(ctx)
            if isinstance(param, Argument) and param.help and not param.hidden
        ]
        if rows:
            formatter.write_paragraph()
            formatter.write_heading("Positional arguments")
            formatter.write_dl(rows)

    def format_options(self, ctx, formatter):
        rows = []
        for param in self.get_params(ctx):
            if isinstance(param, Option) and not param.hidden:
                rows.append(_option_help_record(param, ctx))
        if rows:
            formatter.write_paragraph()
            formatter.write_heading("Options")
            formatter.write_dl(rows)

    def format_epilog(self, ctx, formatter):
        if self.epilog:
            formatter.write_paragraph()
            formatter.write_text(self.epilog)

    def get_short_help_str(self, limit=45):
        if self.short_help:
            return self.short_help
        text = " ".join((self.help or "").split())
        if not text:
            return ""
        index = text.find(". ")
        first = text[: index + 1] if index != -1 else text
        if len(first) > limit:
            cut = first[: max(limit - 3, 0)].rsplit(" ", 1)[0]
            first = cut + "..."
        return first


class Group(Command):
    """A command that dispatches to named subcommands."""

    allow_extra_args = True
    allow_interspersed_args = False

    def __init__(
        self,
        name=None,
        commands=None,
        invoke_without_command=False,
        no_args_is_help=None,
        subcommand_metavar=None,
        chain=False,
        result_callback=None,
        **kwargs,
    ):
        super().__init__(name, **kwargs)
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        self.no_args_is_help = no_args_is_help
        self.invoke_without_command = invoke_without_command
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self.result_callback_func = result_callback
        self.commands = {}
        for cmd_name, cmd in dict(commands or {}).items():
            self.add_command(cmd, cmd_name)

    def add_command(self, cmd, name=None):
        name = name or cmd.name
        if name is None:
            raise TypeError("A subcommand needs a name.")
        if self.chain and isinstance(cmd, Group):
            raise RuntimeError("Groups cannot be nested under a chaining group.")
        self.commands[name] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command

        def decorator(f):
            cmd = command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group

        def decorator(f):
            cmd = group(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self):
        """Return a decorator that registers the function run on the chain's results."""

        def decorator(f):
            self.result_callback_func = f
            return f

        return decorator

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        return self.commands.get(cmd_name)

    def resolve_command(self, ctx, args):
        token = args[0]
        cmd = self.get_command(ctx, token)
        if cmd is None and ctx.token_normalize_func is not None:
            wanted = ctx.token_normalize_func(token)
            for name in self.list_commands(ctx):
                if ctx.token_normalize_func(name) == wanted:
                    token, cmd = name, self.get_command(ctx, name)
                    break
        if cmd is None:
            ctx.fail(f"No such command {token!r}.")
        return token, cmd, args[1:]

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsIsHelpError("", ctx=ctx)
        rest = Command.parse_args(self, ctx, args)
        if self.chain:
            ctx.protected_args = rest
            ctx.args = []
        elif rest:
            ctx.protected_args, ctx.args = rest[:1], rest[1:]
        else:
            ctx.protected_args, ctx.args = [], []
        return ctx.args

    def invoke(self, ctx):
        def process_result(value):
            if self.result_callback_func is not None:
                value = ctx.invoke(self.result_callback_func, value, **ctx.params)
            return value

        if not ctx.protected_args:
            if self.invoke_without_command:
                with ctx:
                    rv = Command.invoke(self, ctx)
                    return process_result([] if self.chain else rv)
            ctx.fail("Missing command.")

        args = [*ctx.protected_args, *ctx.args]
        ctx.args = []
        ctx.protected_args = []

        if not self.chain:
            with ctx:
                cmd_name, cmd, args = self.resolve_command(ctx, args)
                ctx.invoked_subcommand = cmd_name
                Command.invoke(self, ctx)
                sub_ctx = cmd.make_context(cmd_name, args, parent=ctx)
                with sub_ctx:
                    return process_result(sub_ctx.command.invoke(sub_ctx))

        with ctx:
            ctx.invoked_subcommand = "*"
            Command.invoke(self, ctx)
            contexts = []
            try:
                while args:
                    cmd_name, cmd, args = self.resolve_command(ctx, args)
                    sub_ctx = cmd.make_context(
                        cmd_name, args, parent=ctx, allow_extra_args=True, allow_interspersed_args=False
                    )
                    contexts.append(sub_ctx)
                    args = sub_ctx.args
                    sub_ctx.args = []
                results = []
                for sub_ctx in contexts:
                    with sub_ctx:
                        results.append(sub_ctx.command.invoke(sub_ctx))
                return process_result(results)
            finally:
                for sub_ctx in contexts:
                    sub_ctx.close()

    def list_visible(self, ctx):
        rows = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is not None and not cmd.hidden:
                rows.append((name, cmd))
        return rows

    def collect_usage_pieces(self, ctx):
        pieces = Command.collect_usage_pieces(self, ctx)
        if self.subcommand_metavar is not None:
            pieces.append(self.subcommand_metavar)
        elif self.chain:
            pieces.append("COMMAND [ARGS]... [COMMAND [ARGS]...]...")
        elif self.invoke_without_command:
            pieces.append("[COMMAND [ARGS]...]")
        else:
            pieces.append("COMMAND [ARGS]...")
        return pieces

    def format_commands(self, ctx, formatter):
        rows = [(name, cmd.get_short_help_str(formatter.width - 32)) for name, cmd in self.list_visible(ctx)]
        if rows:
            formatter.write_paragraph()
            formatter.write_heading("Commands")
            formatter.write_dl(rows)

    def format_help(self, ctx, formatter):
        Command.format_help(self, ctx, formatter)
        self.format_commands(ctx, formatter)
        Command.format_epilog(self, ctx, formatter)


class CommandCollection(Group):
    """A group whose subcommands are the union of several source groups."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def get_command(self, ctx, cmd_name):
        for source in self.sources:
            rv = source.get_command(ctx, cmd_name)
            if rv is not None:
                return rv
        return None

    def list_commands(self, ctx):
        names = set()
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)


def _argument_usage(param):
    metavar = param.make_metavar()
    if param.nargs == -1:
        text = f"{metavar}..."
        return text if param.required else f"[{metavar}]..."
    text = metavar
    if param.nargs > 1:
        text = " ".join([metavar] * param.nargs)
    return text if param.required else f"[{text}]"


def _option_help_record(param, ctx):
    first = ", ".join(param.opts)
    if param.secondary_opts:
        first += " / " + ", ".join(param.secondary_opts)
    metavar = param.make_metavar(ctx)
    if metavar and not (param.is_flag or param.count):
        first += f" {metavar}"
    text = param.help or ""
    if param.deprecated:
        text = f"(DEPRECATED) {text}".strip()
    extras = []
    show_default = param.show_default if param.show_default is not None else ctx.show_default
    if show_default and param.default is not UNSET:
        hide = param.is_bool_flag and param.default in (False, None)
        if not hide:
            if isinstance(show_default, str):
                extras.append(f"default: {show_default}")
            else:
                try:
                    shown = param.default() if callable(param.default) else param.default
                except Exception:
                    shown = None
                if shown is not None:
                    extras.append(f"default: {shown}")
    if param.show_envvar and param.envvar_names(ctx):
        extras.append(f"env var: {', '.join(param.envvar_names(ctx))}")
    if extras:
        text = f"{text} [{'; '.join(extras)}]".strip()
    return first, text


__all__ = [
    "Argument",
    "Command",
    "CommandCollection",
    "Context",
    "Group",
    "Option",
    "Parameter",
    "ParameterSource",
]
