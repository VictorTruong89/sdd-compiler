"""Shell completion: registration scripts and suggestion output."""

import os
import sys

SHELLS = ("bash", "zsh", "fish", "powershell")


class CompletionItem:
    """A suggestion. ``type`` is ``plain`` for values, or ``file``/``dir`` for path requests."""

    def __init__(self, value, help=None, type="plain"):
        self.value = value
        self.help = help
        self.type = type


def _as_item(item):
    if isinstance(item, CompletionItem):
        return item
    if isinstance(item, str):
        return CompletionItem(item)
    return CompletionItem(item.value, getattr(item, "help", None), getattr(item, "type", "plain") or "plain")


def _env_name(prog_name):
    return "_" + prog_name.replace("-", "_").upper() + "_COMPLETE"


def _function_name(prog_name):
    return "_" + prog_name.replace("-", "_") + "_completion"


def _source_script(shell, prog_name, var):
    fn = _function_name(prog_name)
    if shell == "bash":
        return f"""{fn}() {{
    local IFS=$'\\n'
    local response
    response=$(env COMP_WORDS="${{COMP_WORDS[*]}}" COMP_CWORD=$COMP_CWORD {var}=bash_complete $1)
    local completion
    for completion in $response; do
        local type="${{completion%%,*}}"
        local value="${{completion#*,}}"
        value="${{value%%$'\\t'*}}"
        if [[ $type == 'dir' ]]; then
            COMPREPLY+=("$value")
            compopt -o dirnames
        elif [[ $type == 'file' ]]; then
            COMPREPLY+=("$value")
            compopt -o default
        else
            COMPREPLY+=("$value")
        fi
    done
    return 0
}}

complete -o nosort -F {fn} {prog_name}
"""
    if shell == "zsh":
        return f"""#compdef {prog_name}

{fn}() {{
    local -a response
    local item type rest value
    response=("${{(@f)$(env COMP_WORDS="${{words[*]}}" COMP_CWORD=$((CURRENT-1)) {var}=zsh_complete ${{words[1]}})}}")
    for item in "${{response[@]}}"; do
        type="${{item%%,*}}"
        rest="${{item#*,}}"
        value="${{rest%%$'\\t'*}}"
        if [[ $type == 'dir' ]]; then
            _path_files -/
        elif [[ $type == 'file' ]]; then
            _path_files
        else
            compadd -- "$value"
        fi
    done
}}

compdef {fn} {prog_name}
"""
    if shell == "fish":
        return f"""function {fn}
    set -l response (env COMP_WORDS=(string join " " -- (commandline -cp)) COMP_CWORD=(commandline -ct) {var}=fish_complete {prog_name})
    for completion in $response
        set -l parts (string split -m1 "," -- $completion)
        set -l value (string split -m1 "\\t" -- $parts[2])
        switch $parts[1]
            case dir
                __fish_complete_directories $value[1]
            case file
                __fish_complete_path $value[1]
            case '*'
                printf "%s\\t%s\\n" $value[1] $value[2]
        end
    end
end

complete --no-files --command {prog_name} --arguments "({fn})"
"""
    return f"""Register-ArgumentCompleter -Native -CommandName {prog_name} -ScriptBlock {{
    param($wordToComplete, $commandAst, $cursorPosition)
    $Env:COMP_WORDS = $commandAst.ToString()
    $Env:COMP_CWORD = $commandAst.CommandElements.Count
    $Env:{var} = 'powershell_complete'
    $response = & {prog_name} 2>$null
    Remove-Item Env:{var}
    foreach ($item in $response) {{
        $parts = $item.Split(',', 2)
        $value = $parts[1].Split("`t", 2)[0]
        if ($value -like "$wordToComplete*") {{
            [System.Management.Automation.CompletionResult]::new($value, $value, 'ParameterValue', $value)
        }}
    }}
}}
"""


def _resolve(cmd, info_name, tokens, parent):
    from .core import Group

    ctx = cmd.make_context(info_name, tokens, parent=parent, resilient_parsing=True)
    if isinstance(cmd, Group) and ctx.protected_args:
        sub_name = ctx.protected_args[0]
        sub = cmd.get_command(ctx, sub_name)
        if sub is not None:
            return _resolve(sub, sub_name, ctx.protected_args[1:] + ctx.args, ctx)
    return cmd, ctx


def _suggestions(cli, prog_name, args, incomplete):
    from .core import Argument, Group, Option

    cmd, ctx = _resolve(cli, prog_name, args, None)
    items = []
    if incomplete.startswith("-"):
        for param in cmd.get_params(ctx):
            if not isinstance(param, Option) or param.hidden:
                continue
            for name in param.opts + param.secondary_opts:
                if name.startswith(incomplete):
                    items.append(CompletionItem(name, param.help))
        return items
    previous = args[-1] if args else None
    if previous is not None:
        for param in cmd.get_params(ctx):
            if isinstance(param, Option) and param.takes_value and previous in param.opts:
                return [_as_item(i) for i in param.shell_complete(ctx, incomplete)]
    if isinstance(cmd, Group) and not ctx.protected_args:
        for name in cmd.list_commands(ctx):
            sub = cmd.get_command(ctx, name)
            if sub is not None and not sub.hidden and name.startswith(incomplete):
                items.append(CompletionItem(name, sub.get_short_help_str()))
        return items
    positional = [a for a in args if not a.startswith("-")]
    arguments = [p for p in cmd.get_params(ctx) if isinstance(p, Argument)]
    if len(positional) < len(arguments):
        param = arguments[len(positional)]
        return [_as_item(i) for i in param.shell_complete(ctx, incomplete)]
    return items


def _complete(cli, prog_name, shell):
    words_raw = os.environ.get("COMP_WORDS", "")
    cword = os.environ.get("COMP_CWORD", "")
    words = words_raw.split(" ")
    if shell == "fish":
        incomplete = cword
        args = words[1:]
        if args and args[-1] == incomplete:
            args = args[:-1]
    else:
        try:
            index = int(cword)
        except ValueError:
            index = len(words)
        args = words[1:index]
        incomplete = words[index] if index < len(words) else ""
    out = []
    for item in _suggestions(cli, prog_name, [a for a in args if a], incomplete):
        line = f"{item.type},{item.value}"
        if item.help:
            line += "\t" + " ".join(str(item.help).split())
        out.append(line)
    sys.stdout.write("".join(line + "\n" for line in out))
    sys.stdout.flush()


def maybe_complete(cli, prog_name, complete_var=None):
    """If the completion variable selects a mode, print the script or suggestions and exit."""
    var = complete_var or _env_name(prog_name)
    instruction = os.environ.get(var)
    if not instruction:
        return
    shell, _, mode = instruction.rpartition("_")
    if shell not in SHELLS or mode not in ("source", "complete"):
        sys.exit(1)
    if mode == "source":
        sys.stdout.write(_source_script(shell, prog_name, var))
        sys.stdout.flush()
    else:
        _complete(cli, prog_name, shell)
    sys.exit(0)
