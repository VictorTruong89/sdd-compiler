"""Behavioural tests for Optlyn, named after the feature points they exercise."""

import datetime
import enum
import os
import uuid

import pytest

import optlyn
from optlyn import (
    BOOL, INT, Choice, DateTime, File, FloatRange, IntRange, Path, Tuple, UUID,
    argument, command, confirmation_option, custom_version_option, echo, group,
    help_option, make_pass_decorator, option, pass_context, pass_obj, password_option,
    style, unstyle, version_option, CommandCollection, BadParameter, Abort,
)
from optlyn.formatting import wrap_text
from optlyn.testing import CliRunner


@pytest.fixture
def runner():
    return CliRunner()


# FP-01: naming, invocation, deprecation ---------------------------------------

def test_name_derivation_strips_suffix_and_dashes(runner):
    @command()
    def hello_world_cmd():
        echo("hi")

    assert hello_world_cmd.name == "hello-world"
    assert runner.invoke(hello_world_cmd).output == "hi\n"


def test_explicit_name_only_accepted(runner):
    @command("greet")
    def hello():
        echo("hi")

    assert runner.invoke(hello, []).exit_code == 0
    assert runner.invoke(hello, ["hello"]).exit_code == 2


def test_deprecated_command_warns_on_stdout_and_runs(runner):
    @command(deprecated="use other")
    def old():
        echo("body")

    res = runner.invoke(old, [])
    assert res.exit_code == 0
    assert res.stdout.index("deprecated") < res.stdout.index("body")
    assert "use other" in res.stdout


def test_standalone_off_returns_value(runner):
    @command()
    def c():
        return 42

    assert c.main([], standalone_mode=False) == 42


def test_decorator_moves_declarations(runner):
    def f():
        pass

    f = option("--x")(f)
    cmd = command()(f)
    assert [p.name for p in cmd.params] == ["x"]
    assert "__optlyn_params__" not in f.__dict__


# FP-02: help -----------------------------------------------------------------

def test_help_exit_zero_and_no_callback(runner):
    calls = []

    @command()
    @option("--n", type=int)
    def c(n):
        """Docstring line.

        More.
        """
        calls.append(n)

    res = runner.invoke(c, ["--help"])
    assert res.exit_code == 0
    assert calls == []
    assert "Usage: c [OPTIONS]" in res.stdout
    assert "Docstring line." in res.stdout
    assert "Options:" in res.stdout
    assert "--n INTEGER" in res.stdout


def test_formfeed_truncates_help(runner):
    @command()
    def c():
        """Visible.\f hidden part"""

    res = runner.invoke(c, ["--help"])
    assert "Visible." in res.stdout
    assert "hidden" not in res.stdout
    assert "\f" not in res.stdout


def test_group_no_args_is_usage_failure(runner):
    @group()
    def g():
        """Group."""

    res = runner.invoke(g, [])
    assert res.exit_code == 2
    assert "Group." in res.output


def test_help_before_subcommand_is_group_help(runner):
    ran = []

    @group()
    def g():
        ran.append("g")

    @g.command()
    def sub():
        ran.append("sub")

    res = runner.invoke(g, ["--help", "sub"])
    assert res.exit_code == 0
    assert "Commands:" in res.stdout
    assert ran == []


def test_version_option_identity(runner):
    @command()
    @version_option("1.2.3", prog_name="tool")
    def c():
        pass

    res = runner.invoke(c, ["--version"])
    assert res.exit_code == 0
    assert "1.2.3" in res.stdout


def test_custom_version_option_exact_output(runner):
    @command()
    @custom_version_option(lambda ctx: "custom-id 9")
    def c():
        pass

    res = runner.invoke(c, ["--version"])
    assert res.stdout == "custom-id 9\n"


def test_first_eager_flag_wins(runner):
    @command()
    @custom_version_option(lambda ctx: "V")
    def c():
        pass

    res = runner.invoke(c, ["--version", "--help"])
    assert res.stdout == "V\n"


def test_disabled_help_is_unknown(runner):
    @command(add_help_option=False)
    def c():
        pass

    assert runner.invoke(c, ["--help"]).exit_code == 2


# FP-03: options --------------------------------------------------------------

def test_stacked_flags_and_attached_value(runner):
    seen = {}

    @command()
    @option("-a", is_flag=True)
    @option("-b", is_flag=True)
    @option("-c", "value")
    def c(a, b, value):
        seen.update(a=a, b=b, value=value)

    assert runner.invoke(c, ["-abc", "x"]).exit_code == 0
    assert seen == {"a": True, "b": True, "value": "x"}
    runner.invoke(c, ["-cyy"])
    assert seen["value"] == "yy"


def test_on_off_pair(runner):
    seen = []

    @command()
    @option("--shout/--no-shout", default=False)
    def c(shout):
        seen.append(shout)

    runner.invoke(c, ["--shout"])
    runner.invoke(c, ["--no-shout"])
    runner.invoke(c, [])
    assert seen == [True, False, False]


def test_count_and_multiple(runner):
    seen = {}

    @command()
    @option("-v", count=True)
    @option("-x", multiple=True)
    def c(v, x):
        seen.update(v=v, x=x)

    runner.invoke(c, ["-vvv", "-x", "1", "-x", "2"])
    assert seen == {"v": 3, "x": ("1", "2")}
    runner.invoke(c, [])
    assert seen == {"v": 0, "x": ()}


def test_nargs_and_double_dash(runner):
    seen = {}

    @command()
    @option("--pair", nargs=2, type=INT)
    @argument("rest", nargs=-1)
    def c(pair, rest):
        seen.update(pair=pair, rest=rest)

    runner.invoke(c, ["--pair", "1", "2", "--", "--x", "y"])
    assert seen == {"pair": (1, 2), "rest": ("--x", "y")}


def test_required_missing_option(runner):
    @command()
    @option("--name", required=True)
    def c(name):
        pass

    res = runner.invoke(c, [])
    assert res.exit_code == 2
    assert "--name" in res.output


def test_no_such_option_is_usage_error(runner):
    @command()
    def c():
        pass

    res = runner.invoke(c, ["--nope"])
    assert res.exit_code == 2
    assert "--nope" in res.output


def test_optional_value_flag(runner):
    seen = []

    @command()
    @option("--opt", is_flag=False, flag_value="FLAG", default="DEF")
    def c(opt):
        seen.append(opt)

    runner.invoke(c, ["--opt"])
    runner.invoke(c, ["--opt", "tok"])
    runner.invoke(c, [])
    assert seen == ["FLAG", "tok", "DEF"]


def test_alternative_prefix(runner):
    seen = []

    @command()
    @option("+x/-x", default=False)
    def c(x):
        seen.append(x)

    runner.invoke(c, ["+x"])
    assert seen == [True]


def test_envvar_and_precedence(runner):
    seen = []

    @command()
    @option("--name", envvar="MY_NAME")
    def c(name):
        seen.append(name)

    runner.invoke(c, [], env={"MY_NAME": "fromenv"})
    runner.invoke(c, ["--name", "cli"], env={"MY_NAME": "fromenv"})
    runner.invoke(c, [], env={"MY_NAME": ""})
    assert seen == ["fromenv", "cli", None]


def test_default_map_beats_env(runner):
    seen = []

    @command(context_settings={"default_map": {"name": "dm"}})
    @option("--name", envvar="MY_NAME")
    def c(name):
        seen.append(name)

    runner.invoke(c, [], env={"MY_NAME": "fromenv"})
    assert seen == ["dm"]


def test_parameter_source(runner):
    seen = {}

    @command()
    @option("--a", default="d")
    @option("--b", envvar="B_VAR")
    @option("--c")
    @pass_context
    def c(ctx, a, b, c):
        seen.update(a=ctx.get_parameter_source("a"), b=ctx.get_parameter_source("b"),
                    c=ctx.get_parameter_source("c"), none=ctx.get_parameter_source("zzz"))

    runner.invoke(c, ["--c", "1"], env={"B_VAR": "2"})
    assert seen["a"] == optlyn.ParameterSource.DEFAULT
    assert seen["b"] == optlyn.ParameterSource.ENVIRONMENT
    assert seen["c"] == optlyn.ParameterSource.COMMANDLINE
    assert seen["none"] is None


def test_auto_envvar_prefix(runner):
    seen = []

    @command()
    @option("--verbose-mode", is_flag=True)
    def c(verbose_mode):
        seen.append(verbose_mode)

    runner.invoke(c, [], auto_envvar_prefix="MYAPP", env={"MYAPP_VERBOSE_MODE": "1"})
    assert seen == [True]


def test_bare_string_default_on_repeatable_is_usage_error(runner):
    @command()
    @option("-x", multiple=True, default="abc")
    def c(x):
        pass

    res = runner.invoke(c, [])
    assert res.exit_code == 2
    assert "-x" in res.output


def test_deprecated_option_and_required_refused():
    with pytest.raises(TypeError):
        option("--a", deprecated=True, required=True)(lambda a: None)


def test_parameter_callback_refusal(runner):
    def cb(ctx, param, value):
        if value == "bad":
            raise BadParameter("nope")
        return value.upper()

    seen = []

    @command()
    @option("--v", callback=cb)
    def c(v):
        seen.append(v)

    res = runner.invoke(c, ["--v", "bad"])
    assert res.exit_code == 2
    assert "--v" in res.output
    assert seen == []
    runner.invoke(c, ["--v", "ok"])
    assert seen == ["OK"]


# FP-04: arguments ----------------------------------------------------------------

def test_arguments_fixed_and_variadic(runner):
    seen = {}

    @command()
    @argument("src")
    @argument("dst", nargs=-1)
    def c(src, dst):
        seen.update(src=src, dst=dst)

    runner.invoke(c, ["a", "b", "c"])
    assert seen == {"src": "a", "dst": ("b", "c")}


def test_extra_args_is_usage_error(runner):
    @command()
    @argument("x")
    def c(x):
        pass

    assert runner.invoke(c, ["a", "b"]).exit_code == 2


def test_allow_extra_args(runner):
    seen = []

    @command(context_settings={"allow_extra_args": True})
    @argument("x")
    def c(x):
        seen.append(x)

    assert runner.invoke(c, ["a", "b"]).exit_code == 0
    assert seen == ["a"]


def test_argument_envvar(runner):
    seen = []

    @command()
    @argument("x", envvar="X_VAR")
    def c(x):
        seen.append(x)

    runner.invoke(c, [], env={"X_VAR": "e"})
    assert seen == ["e"]


# FP-05: types -------------------------------------------------------------------

def test_choice_returns_original_member(runner):
    class Color(enum.Enum):
        RED = 1
        GREEN = 2

    seen = []

    @command()
    @option("--c", type=Choice(Color), required=True)
    def c(c):
        seen.append(c)

    runner.invoke(c, ["--c", "GREEN"])
    assert seen == [Color.GREEN]
    assert runner.invoke(c, ["--c", "BLUE"]).exit_code == 2


def test_choice_case_insensitive(runner):
    seen = []

    @command()
    @option("--c", type=Choice(["Alpha", "Beta"], case_sensitive=False))
    def c(c):
        seen.append(c)

    runner.invoke(c, ["--c", "alpha"])
    assert seen == ["Alpha"]


def test_int_range_clamp_and_refuse(runner):
    seen = []

    @command()
    @option("--n", type=IntRange(0, 10, clamp=True))
    def c(n):
        seen.append(n)

    runner.invoke(c, ["--n", "50"])
    assert seen == [10]

    @command()
    @option("--n", type=IntRange(0, 10))
    def d(n):
        pass

    assert runner.invoke(d, ["--n", "50"]).exit_code == 2


def test_float_range_clamp_open_refused():
    with pytest.raises(ValueError):
        FloatRange(0, 1, min_open=True, clamp=True)


def test_datetime_formats(runner):
    seen = []

    @command()
    @option("--t", type=DateTime())
    def c(t):
        seen.append(t)

    runner.invoke(c, ["--t", "2024-01-02 03:04:05"])
    assert seen == [datetime.datetime(2024, 1, 2, 3, 4, 5)]


def test_uuid_and_tuple(runner):
    seen = {}

    @command()
    @option("--u", type=UUID)
    @option("--p", type=Tuple([str, INT]))
    def c(u, p):
        seen.update(u=u, p=p)

    runner.invoke(c, ["--u", "12345678-1234-5678-1234-567812345678", "--p", "a", "3"])
    assert seen["u"] == uuid.UUID("12345678-1234-5678-1234-567812345678")
    assert seen["p"] == ("a", 3)


def test_bool_text_conversion(runner):
    seen = []

    @command()
    @option("--b", type=BOOL)
    def c(b):
        seen.append(b)

    runner.invoke(c, ["--b", "YES"])
    runner.invoke(c, ["--b", "off"])
    assert seen == [True, False]
    assert runner.invoke(c, ["--b", "maybe"]).exit_code == 2


def test_custom_conversion_function(runner):
    seen = []

    def parse_hex(v):
        if not v.startswith("0x"):
            raise ValueError
        return int(v, 16)

    @command()
    @option("--h", type=parse_hex)
    def c(h):
        seen.append(h)

    runner.invoke(c, ["--h", "0x10"])
    assert seen == [16]
    assert runner.invoke(c, ["--h", "10"]).exit_code == 2


# FP-06: groups ------------------------------------------------------------------

def test_group_callback_runs_before_child(runner):
    order = []

    @group()
    def g():
        order.append("g")

    @g.command()
    def child():
        order.append("child")

    runner.invoke(g, ["child"])
    assert order == ["g", "child"]


def test_nested_groups_and_unknown_middle(runner):
    @group()
    def root():
        pass

    @root.group()
    def mid():
        pass

    @mid.command()
    def leaf():
        echo("leaf!")

    assert runner.invoke(root, ["mid", "leaf"]).output == "leaf!\n"
    assert runner.invoke(root, ["leaf"]).exit_code == 2


def test_command_collection_union(runner):
    @group()
    def a():
        pass

    @a.command()
    def one():
        echo("one")

    @group()
    def b():
        pass

    @b.command()
    def two():
        echo("two")

    coll = group(cls=CommandCollection, sources=[a, b])(lambda: None)
    assert runner.invoke(coll, ["one"]).output == "one\n"
    assert runner.invoke(coll, ["two"]).output == "two\n"


def test_chain_group_and_result_callback(runner):
    @group(chain=True)
    def g():
        pass

    @g.command()
    @argument("x")
    def a(x):
        echo(f"a{x}")
        return x

    @g.command()
    @argument("x")
    def b(x):
        echo(f"b{x}")
        return x

    @g.result_callback()
    def done(values):
        echo("results " + ",".join(values))

    res = runner.invoke(g, ["a", "1", "b", "2"])
    assert res.exit_code == 0
    assert res.output == "a1\nb2\nresults 1,2\n"


def test_chain_standalone_off_returns_list(runner):
    @group(chain=True)
    def g():
        pass

    @g.command()
    def a():
        return 1

    assert g.main(["a", "a"], standalone_mode=False) == [1, 1]


def test_chain_refuses_nested_group():
    @group(chain=True)
    def g():
        pass

    with pytest.raises(TypeError):
        g.add_command(group()(lambda: None))


# FP-07: context --------------------------------------------------------------------

def test_obj_passing_and_find_object(runner):
    class Config:
        pass

    seen = {}

    @group()
    @pass_obj
    def g(obj):
        seen["root"] = obj

    @g.command()
    @make_pass_decorator(Config, ensure=True)
    def sub(cfg):
        seen["cfg"] = cfg

    runner.invoke(g, ["sub"], obj="x")
    assert isinstance(seen["cfg"], Config)


def test_invoke_and_forward(runner):
    seen = []

    @command()
    @option("--a", default=1)
    def inner(a):
        seen.append(a)

    @command()
    @option("--a", default=5)
    @pass_context
    def outer(ctx, a):
        ctx.forward(inner)
        ctx.invoke(inner, a=9)

    runner.invoke(outer, [])
    assert seen == [5, 9]


def test_token_normalize(runner):
    seen = []

    @command()
    @option("--name")
    def c(name):
        seen.append(name)

    res = runner.invoke(c, ["--NAME", "x"], token_normalize_func=lambda s: s.lower())
    assert res.exit_code == 0
    assert seen == ["x"]


# FP-08: prompts ----------------------------------------------------------------

def test_prompt_reads_input(runner):
    seen = []

    @command()
    @option("--name", prompt=True)
    def c(name):
        seen.append(name)

    res = runner.invoke(c, [], input="Bob\n")
    assert seen == ["Bob"]
    assert "Name" in res.output


def test_prompt_reasks_on_conversion_failure(runner):
    seen = []

    @command()
    @option("--n", prompt=True, type=INT)
    def c(n):
        seen.append(n)

    runner.invoke(c, [], input="x\n12\n")
    assert seen == [12]


def test_prompt_eof_aborts(runner):
    @command()
    @option("--n", prompt=True)
    def c(n):
        pass

    res = runner.invoke(c, [], input="")
    assert res.exit_code == 1
    assert "Aborted!" in res.output


def test_confirmation_option(runner):
    ran = []

    @command()
    @confirmation_option("--yes", prompt="Sure?")
    def c():
        ran.append(1)

    assert runner.invoke(c, ["--yes"]).exit_code == 0
    res = runner.invoke(c, [], input="n\n")
    assert res.exit_code == 1
    assert ran == [1]
    assert runner.invoke(c, [], input="y\n").exit_code == 0
    assert ran == [1, 1]


def test_password_option_confirmation(runner):
    seen = []

    @command()
    @password_option()
    def c(password):
        seen.append(password)

    runner.invoke(c, [], input="pw\npw\n")
    assert seen == ["pw"]
    res = runner.invoke(c, [], input="a\nb\nc\nc\n")
    assert seen == ["pw", "c"]


# FP-09: files -------------------------------------------------------------------

def test_file_read_missing_is_usage_error(runner):
    @command()
    @argument("f", type=File("r"))
    def c(f):
        pass

    res = runner.invoke(c, ["nope.txt"])
    assert res.exit_code == 2
    assert "nope.txt" in res.output


def test_file_write_lazy_and_roundtrip(runner, tmp_path):
    target = tmp_path / "out.txt"

    @command()
    @argument("f", type=File("w"))
    def writer(f):
        pass

    runner.invoke(writer, [str(target)])
    assert not target.exists()

    @command()
    @argument("f", type=File("w"))
    def writer2(f):
        f.write("hello")

    runner.invoke(writer2, [str(target)])
    assert target.read_text() == "hello"


def test_path_checks(runner, tmp_path):
    @command()
    @argument("p", type=Path(exists=True, dir_okay=False))
    def c(p):
        echo(p)

    assert runner.invoke(c, [str(tmp_path / "missing")]).exit_code == 2
    assert runner.invoke(c, [str(tmp_path)]).exit_code == 2
    f = tmp_path / "f.txt"
    f.write_text("x")
    assert runner.invoke(c, [str(f)]).output == f"{f}\n"


# FP-10: wrap & styling --------------------------------------------------------

def test_style_and_unstyle():
    s = style("hi", fg="red", bold=True)
    assert unstyle(s) == "hi"
    assert s.startswith("\x1b[")
    with pytest.raises(ValueError):
        style("x", fg="nosuchcolor")
    assert style("x", bg="red") != style("x", fg="red")


def test_echo_strips_styles_off_terminal(runner):
    @command()
    def c():
        echo(style("plain", fg="green"))

    res = runner.invoke(c, [])
    assert res.stdout == "plain\n"
    res = runner.invoke(c, [], color=True)
    assert "\x1b[" in res.stdout


def test_wrap_text_never_fails():
    assert wrap_text("") == ""
    assert wrap_text("a b c d e", 3).splitlines()


# FP-13: exit statuses ---------------------------------------------------------

def test_abort_status(runner):
    @command()
    def c():
        raise Abort()

    res = runner.invoke(c, [])
    assert res.exit_code == 1
    assert "Aborted!" in res.stderr


def test_author_exit_status(runner):
    @command()
    @pass_context
    def c(ctx):
        ctx.exit(7)
        echo("never")

    res = runner.invoke(c, [])
    assert res.exit_code == 7
    assert "never" not in res.output


def test_exception_inspectable_when_catching(runner):
    @command()
    def c():
        raise ValueError("boom")

    res = runner.invoke(c, [])
    assert res.exit_code == 1
    assert isinstance(res.exception, ValueError)
    with pytest.raises(ValueError):
        runner.invoke(c, [], catch_exceptions=False)


# FP-14: runner -------------------------------------------------------------------

def test_runner_capture_and_isolated_fs(runner, tmp_path):
    @command()
    @argument("name", type=File("w"))
    def writer(name):
        name.write("data")
        echo("done")

    with runner.isolated_filesystem(temp_dir=str(tmp_path)) as cwd:
        res = runner.invoke(writer, ["out.txt"])
        assert res.stdout == "done\n"
        assert os.path.exists(os.path.join(cwd, "out.txt"))
    assert os.path.isdir(cwd)


def test_runner_echo_stdin(runner):
    @command()
    @option("--name", prompt=True)
    def c(name):
        pass

    res = CliRunner(echo_stdin=True).invoke(c, [], input="zed\n")
    assert "zed" in res.output


def test_hidden_prompt_not_echoed(runner):
    @command()
    @option("--pw", prompt=True, hide_input=True)
    def c(pw):
        echo("got")

    res = runner.invoke(c, [], input="secret\n")
    assert "secret" not in res.output


# Completion -----------------------------------------------------------------------

def test_completion_source_and_complete(monkeypatch):
    from optlyn._completion import run_completion

    @group()
    def tool():
        pass

    @tool.command()
    @option("--flag", is_flag=True)
    def alpha():
        pass

    @tool.command(hidden=True)
    def hidden_cmd():
        pass

    import io
    import sys

    buf = io.StringIO()
    monkeypatch.setattr(sys, "stdout", buf)
    assert run_completion(tool, "tool", "bash_source") == 0
    assert "_TOOL_COMPLETE" not in buf.getvalue() or "bash_complete" in buf.getvalue()

    monkeypatch.setenv("COMP_WORDS", "tool ")
    monkeypatch.setenv("COMP_CWORD", "1")
    buf.seek(0)
    buf.truncate()
    run_completion(tool, "tool", "bash_complete")
    assert "alpha" in buf.getvalue()
    assert "hidden" not in buf.getvalue()


def test_unknown_completion_instruction_is_not_success(monkeypatch):
    from optlyn._completion import run_completion

    @command()
    def c():
        pass

    assert run_completion(c, "c", "klingon_source") == 1
