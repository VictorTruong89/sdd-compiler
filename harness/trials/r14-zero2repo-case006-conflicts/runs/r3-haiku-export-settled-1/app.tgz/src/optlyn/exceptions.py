"""Exception classes raised by Optlyn.

Usage failures exit with status 2, general errors and aborts with status 1
(FP-13). With standalone mode off the exceptions propagate to the caller.
"""

from __future__ import annotations


class OptlynError(Exception):
    """A failure that standalone mode reports on standard error and exits on."""

    exit_code = 1

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message = message

    def format_message(self) -> str:
        return self.message

    def show(self, file=None) -> None:
        from .termui import echo

        echo(f"Error: {self.format_message()}", file=file, err=True)


class UsageError(OptlynError):
    """Incorrect command line (exit status 2). Shows the usage line and a hint."""

    exit_code = 2

    def __init__(self, message: str, ctx=None) -> None:
        super().__init__(message)
        self.ctx = ctx

    def show(self, file=None) -> None:
        from .termui import echo

        if self.ctx is not None:
            echo(self.ctx.get_usage(), file=file, err=True)
            names = self.ctx.help_option_names
            if names:
                hint = f"{self.ctx.command_path} {names[0]}"
                echo(f"Try '{hint}' for help.", file=file, err=True)
            echo("", file=file, err=True)
        echo(f"Error: {self.format_message()}", file=file, err=True)


class BadParameter(UsageError):
    """A value was refused: bad conversion, failed check, or refusing callback (FP-03, FP-05)."""

    def __init__(self, message, ctx=None, param=None, param_hint=None) -> None:
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self) -> str:
        if self.param_hint is not None:
            hint = self.param_hint
        elif self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        else:
            return self.message
        return f"Invalid value for {hint}: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter received no value from any source (FP-03, FP-04)."""

    def __init__(self, message=None, ctx=None, param=None, param_hint=None) -> None:
        super().__init__(message or "", ctx, param, param_hint)

    def format_message(self) -> str:
        if self.param is None and self.param_hint is None:
            return self.message or "Missing parameter."
        kind = "option" if getattr(self.param, "is_option", False) else "argument"
        if self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        else:
            hint = self.param_hint
        if self.message:
            return self.message
        return f"Missing {kind} {hint}."


class NoSuchOption(UsageError):
    """An option token matches no declared flag (FP-03)."""

    def __init__(self, option_name: str, message=None, ctx=None) -> None:
        super().__init__(message or f"No such option: {option_name}", ctx)
        self.option_name = option_name


class BadOptionUsage(UsageError):
    """An option was used incorrectly (missing value, bad default shape, ...)."""


class BadArgumentUsage(UsageError):
    """An argument was used incorrectly."""


class NoSuchCommand(UsageError):
    """A group was asked for a subcommand name it does not have (FP-06)."""

    def __init__(self, name: str, ctx=None) -> None:
        super().__init__(f"No such command {name!r}.", ctx)
        self.name = name


class NoArgsIsHelp(UsageError):
    """Help shown because of incorrect usage with no arguments (FP-02, FP-13).

    Standard error carries the help page; exit status is the usage class.
    """

    def show(self, file=None) -> None:
        from .termui import echo

        if self.ctx is not None:
            echo(self.ctx.get_help(), file=file, err=True)


class FileError(OptlynError):
    """A file failed to open at first I/O (general error class, exit 1)."""

    def __init__(self, filename: str, message: str) -> None:
        super().__init__(f"Could not open file {filename!r}: {message}")
        self.filename = filename


class Abort(RuntimeError):
    """User or author abort (exit status 1, 'Aborted!' on standard error)."""


class Exit(RuntimeError):
    """Author clean stop with a status (FP-13). Internal to the library."""

    def __init__(self, code: int = 0) -> None:
        super().__init__(code)
        self.exit_code = code
