"""File helpers, application directories and filename formatting (FP-09, FP-11)."""

from __future__ import annotations

import io
import os
import re
import sys
import tempfile

from .exceptions import FileError


def _is_writing(mode: str) -> bool:
    return any(c in mode for c in "wax+")


class _StdStream:
    """Proxy for a standard stream: closing it never closes the process stream (FP-09)."""

    def __init__(self, inner, owned_wrapper=None) -> None:
        self._inner = inner
        self._owned_wrapper = owned_wrapper

    def close(self) -> None:
        try:
            self._inner.flush()
        except (OSError, ValueError):
            pass
        if self._owned_wrapper is not None:
            try:
                self._owned_wrapper.detach()
            except (ValueError, AttributeError):
                pass

    def __getattr__(self, name):
        return getattr(self._inner, name)

    def __iter__(self):
        return iter(self._inner)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()


class LazyFile:
    """A file that opens on first I/O; a write that never happens never opens (FP-09)."""

    def __init__(self, filename, mode, encoding=None, errors="strict", atomic=False) -> None:
        self.name = filename
        self._args = (mode, encoding, errors, atomic)
        self._opened = None

    def _open(self):
        if self._opened is None:
            mode, encoding, errors, atomic = self._args
            try:
                self._opened = _open_real(self.name, mode, encoding, errors, atomic)
            except OSError as e:
                raise FileError(str(self.name), e.strerror or str(e)) from e
        return self._opened

    def __getattr__(self, name):
        return getattr(self._open(), name)

    def __iter__(self):
        return iter(self._open())

    def close(self) -> None:
        if self._opened is not None:
            self._opened.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()


class _AtomicFile:
    """Writes to a sibling temporary file; the target is replaced on close (FP-09)."""

    def __init__(self, handle, tmp_path, target) -> None:
        self._handle = handle
        self._tmp = tmp_path
        self._target = target
        self._done = False

    def close(self) -> None:
        if self._done:
            return
        self._done = True
        self._handle.close()
        os.replace(self._tmp, self._target)

    def __getattr__(self, name):
        return getattr(self._handle, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()


def _open_real(filename, mode, encoding, errors, atomic):
    binary = "b" in mode
    enc = None if binary else encoding
    err = None if binary else errors
    if atomic and _is_writing(mode):
        target = os.path.abspath(os.fspath(filename))
        directory = os.path.dirname(target)
        fd, tmp = tempfile.mkstemp(dir=directory, prefix=".optlyn-", suffix=".tmp")
        try:
            handle = os.fdopen(fd, mode, encoding=enc, errors=err)
        except BaseException:
            os.close(fd)
            os.unlink(tmp)
            raise
        return _AtomicFile(handle, tmp, target)
    return open(filename, mode, encoding=enc, errors=err)


def _std_stream(mode: str, encoding, errors):
    """Return the process stdin/stdout as selected by the dash rule (FP-09)."""
    writing = _is_writing(mode)
    base = sys.stdout if writing else sys.stdin
    if "b" in mode:
        buf = getattr(base, "buffer", None)
        return _StdStream(buf if buf is not None else base)
    if encoding is not None:
        buf = getattr(base, "buffer", None)
        if buf is not None:
            wrapper = io.TextIOWrapper(buf, encoding=encoding, errors=errors)
            return _StdStream(wrapper, owned_wrapper=wrapper)
    return _StdStream(base)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file, or `-` for standard input (read) / standard output (write)."""
    if filename == "-":
        return _std_stream(mode, encoding, errors)
    if lazy and _is_writing(mode):
        return LazyFile(filename, mode, encoding, errors, atomic)
    return _open_real(filename, mode, encoding, errors, atomic)


def format_filename(filename, shorten: bool = False) -> str:
    """Make a path printable as UTF-8 text without failing (FP-09)."""
    if hasattr(filename, "__fspath__"):
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        text = os.fsdecode(filename)
    else:
        text = str(filename)
    if shorten:
        text = os.path.basename(text.rstrip("/\\")) or text
    return text.encode("utf-8", "backslashreplace").decode("utf-8")


def get_app_dir(app_name: str, roaming: bool = True, force_posix: bool = False) -> str:
    """Per-user config directory for an application (FP-11)."""
    home = os.path.expanduser("~")
    if force_posix:
        return os.path.join(home, "." + re.sub(r"\s+", "-", app_name.lower()))
    if sys.platform.startswith("win"):
        key = "APPDATA" if roaming else "LOCALAPPDATA"
        base = os.environ.get(key) or os.path.join(home, "AppData", "Roaming" if roaming else "Local")
        return os.path.join(base, app_name)
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    xdg = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(xdg, re.sub(r"\s+", "-", app_name.lower()))
