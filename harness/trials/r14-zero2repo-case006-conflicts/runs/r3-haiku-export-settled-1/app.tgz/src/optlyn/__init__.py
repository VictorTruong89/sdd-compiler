"""Optlyn: the Command Line Interface Composition Kit.

Declare commands, groups, options and arguments with plain Python functions;
Optlyn parses the argument list, converts values, renders help and dispatches
to the callbacks. Pure Python, no runtime dependencies.
"""

from ._state import get_current_context
from .core import (
    Argument,
    Command,
    CommandCollection,
    Context,
    Group,
    Option,
    Parameter,
    ParameterSource,
)
from .decorators import (
    argument,
    command,
    confirmation_option,
    custom_version_option,
    group,
    help_option,
    make_pass_decorator,
    option,
    pass_context,
    pass_obj,
    password_option,
    version_option,
)
from .exceptions import Abort, BadParameter, Exit, MissingParameter, OptlynError, UsageError
from .paramtypes import (
    BOOL,
    FLOAT,
    INT,
    STRING,
    UNPROCESSED,
    UUID,
    Choice,
    DateTime,
    File,
    FloatRange,
    IntRange,
    ParamType,
    Path,
    Tuple,
)
from .termui import (
    clear,
    confirm,
    echo,
    echo_via_pager,
    edit,
    getchar,
    get_pager_file,
    launch,
    pause,
    progressbar,
    prompt,
    secho,
    style,
    unstyle,
)
from .utils import format_filename, get_app_dir, open_file

__version__ = "1.0.0"

__all__ = [
    "Abort", "Argument", "BOOL", "BadParameter", "Choice", "Command", "CommandCollection",
    "Context", "DateTime", "FLOAT", "File", "FloatRange", "Group", "INT", "IntRange", "Option",
    "OptlynError", "Parameter", "ParameterSource", "ParamType", "Path", "STRING", "Tuple",
    "UNPROCESSED", "UUID", "UsageError", "Exit", "MissingParameter",
    "argument", "clear", "command", "confirm", "confirmation_option", "custom_version_option",
    "echo", "echo_via_pager", "edit", "format_filename", "get_app_dir", "get_current_context",
    "get_pager_file", "getchar", "group", "help_option", "launch", "make_pass_decorator",
    "open_file", "option", "pass_context", "pass_obj", "password_option", "pause", "progressbar",
    "prompt", "secho", "style", "unstyle", "version_option",
]
