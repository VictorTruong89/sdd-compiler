"""Parameter types and conversion (FP-05, FP-09; Interface Contract section 5)."""

from __future__ import annotations

import datetime as _dt
import enum
import os
import pathlib
import uuid

from .exceptions import BadParameter
from .utils import open_file


class ParamType:
    """Base class for parameter types. Subclasses implement `convert`."""

    name = "text"
    is_composite = False

    def __call__(self, value, param=None, ctx=None):
        if value is None:
            return None
        return self.convert(value, param, ctx)

    def get_metavar(self, param=None) -> str:
        return self.name.upper()

    def convert(self, value, param, ctx):
        return value

    def split_envvar_value(self, rv: str) -> list:
        return rv.split()

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def shell_complete(self, ctx, param, incomplete):
        return []

    def normalize(self, value, ctx=None):
        func = getattr(ctx, "token_normalize_func", None) if ctx is not None else None
        return func(value) if func is not None else value

    def __repr__(self) -> str:
        return f"<{type(self).__name__} {self.name}>"


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        if isinstance(value, str):
            return value
        return str(value)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        return value


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param, ctx):
        if isinstance(value, int) and not isinstance(value, bool):
            return value
        if isinstance(value, str):
            try:
                return int(value)
            except ValueError:
                pass
        self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param, ctx):
        if isinstance(value, float):
            return value
        if isinstance(value, (str, int)) and not isinstance(value, bool):
            try:
                return float(value)
            except ValueError:
                pass
        self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


_TRUE_TOKENS = {"1", "true", "t", "yes", "y", "on"}
_FALSE_TOKENS = {"0", "false", "f", "no", "n", "off"}


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE_TOKENS:
            return True
        if text in _FALSE_TOKENS:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param, ctx):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value))
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()


class Choice(ParamType):
    """A closed list of values, or the members of an enumeration (FP-05)."""

    name = "choice"

    def __init__(self, choices, case_sensitive: bool = True) -> None:
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.choices = list(choices)
            self._keys = [m.name for m in self.choices]
        else:
            self.choices = list(choices)
            self._keys = [str(c) for c in self.choices]
        self.case_sensitive = case_sensitive

    def _norm(self, text: str, ctx=None) -> str:
        text = self.normalize(text, ctx)
        return text if self.case_sensitive else text.casefold()

    def get_metavar(self, param=None) -> str:
        return "[" + "|".join(self._keys) + "]"

    def convert(self, value, param, ctx):
        for choice in self.choices:
            if value is choice:
                return choice
        if not isinstance(value, str):
            value = str(value)
        normed = self._norm(value, ctx)
        for choice, key in zip(self.choices, self._keys):
            if self._norm(key, ctx) == normed:
                return choice
        options = ", ".join(repr(k) for k in self._keys)
        self.fail(f"{value!r} is not one of {options}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        from ._completion import CompletionItem

        return [CompletionItem(k) for k in self._keys if k.startswith(incomplete)]


DEFAULT_DATETIME_FORMATS = ["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None) -> None:
        self.formats = list(DEFAULT_DATETIME_FORMATS if formats is None else formats)

    def convert(self, value, param, ctx):
        if isinstance(value, _dt.datetime):
            return value
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(str(value), fmt)
            except ValueError:
                continue
        self.fail(
            f"{value!r} does not match the formats {', '.join(repr(f) for f in self.formats)}.",
            param,
            ctx,
        )


class IntRange(IntParamType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open: bool = False, max_open: bool = False,
                 clamp: bool = False) -> None:
        if min is not None and max is not None and min > max:
            raise ValueError("'min' must not be greater than 'max'.")
        self.min, self.max = min, max
        self.min_open, self.max_open = min_open, max_open
        self.clamp = clamp

    def _describe(self) -> str:
        lo = "" if self.min is None else f"{self.min}{'<' if self.min_open else '<='}"
        hi = "" if self.max is None else f"{'<' if self.max_open else '<='}{self.max}"
        return f"{lo}x{hi}"

    def convert(self, value, param, ctx):
        rv = super().convert(value, param, ctx)
        return _clamp_or_fail(self, rv, param, ctx, self.min, self.max, 1)


class FloatRange(FloatParamType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open: bool = False, max_open: bool = False,
                 clamp: bool = False) -> None:
        if min is not None and max is not None and min > max:
            raise ValueError("'min' must not be greater than 'max'.")
        if clamp and (min_open or max_open):
            raise ValueError("Clamping is only allowed when both bounds are closed.")
        self.min, self.max = min, max
        self.min_open, self.max_open = min_open, max_open
        self.clamp = clamp

    def _describe(self) -> str:
        lo = "" if self.min is None else f"{self.min}{'<' if self.min_open else '<='}"
        hi = "" if self.max is None else f"{'<' if self.max_open else '<='}{self.max}"
        return f"{lo}x{hi}"

    def convert(self, value, param, ctx):
        rv = super().convert(value, param, ctx)
        return _clamp_or_fail(self, rv, param, ctx, self.min, self.max, None)


def _clamp_or_fail(rng, rv, param, ctx, lo, hi, step):
    below = lo is not None and (rv <= lo if rng.min_open else rv < lo)
    above = hi is not None and (rv >= hi if rng.max_open else rv > hi)
    if not (below or above):
        return rv
    if rng.clamp:
        if below:
            if rng.min_open:
                return lo + (step if step else 0.0)
            return lo
        if rng.max_open:
            return hi - (step if step else 0.0)
        return hi
    rng.fail(f"{rv} is not in the range {rng._describe()}.", param, ctx)


class Tuple(ParamType):
    """A fixed-length product of inner types (FP-05)."""

    name = "tuple"
    is_composite = True

    def __init__(self, types) -> None:
        self.types = [convert_type(t) for t in types]
        self.name = "<" + " ".join(t.name for t in self.types) + ">"

    def get_metavar(self, param=None) -> str:
        return " ".join(t.get_metavar(param) for t in self.types)

    def convert(self, value, param, ctx):
        if not isinstance(value, (tuple, list)) or len(value) != len(self.types):
            self.fail(f"{value!r} must be a sequence of {len(self.types)} values.", param, ctx)
        return tuple(t(v, param, ctx) for t, v in zip(self.types, value))


class File(ParamType):
    """Opens a file; `-` is standard input or output (FP-09)."""

    name = "filename"

    def __init__(self, mode: str = "r", encoding=None, errors: str = "strict", lazy=None,
                 atomic: bool = False) -> None:
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def split_envvar_value(self, rv: str) -> list:
        return rv.split(os.pathsep)

    def convert(self, value, param, ctx):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        lazy = self.lazy
        if lazy is None:
            lazy = any(c in self.mode for c in "wax")
        filename = os.fspath(value)
        try:
            handle = open_file(filename, self.mode, self.encoding, self.errors,
                               lazy=lazy and filename != "-", atomic=self.atomic)
        except OSError as e:
            self.fail(f"{filename!r}: {e.strerror or e}.", param, ctx)
        if ctx is not None and hasattr(ctx, "call_on_close"):
            ctx.call_on_close(handle.close)
        return handle


class Path(ParamType):
    """Validates a filesystem path and returns it (FP-09)."""

    name = "path"

    def __init__(self, exists: bool = False, file_okay: bool = True, dir_okay: bool = True,
                 writable: bool = False, readable: bool = True, resolve_path: bool = False,
                 allow_dash: bool = False, path_type=None, executable: bool = False) -> None:
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def split_envvar_value(self, rv: str) -> list:
        return rv.split(os.pathsep)

    def _coerce(self, value: str):
        if self.path_type is pathlib.Path:
            return pathlib.Path(value)
        if self.path_type is str or self.path_type is None:
            return value
        return self.path_type(value)

    def convert(self, value, param, ctx):
        raw = os.fspath(value)
        if self.allow_dash and raw == "-":
            return self._coerce("-")
        if self.resolve_path:
            raw_check = os.path.realpath(raw)
        else:
            raw_check = raw
        exists = os.path.exists(raw_check)
        if not exists:
            if self.exists:
                self.fail(f"{raw!r} does not exist.", param, ctx)
            return self._coerce(raw_check if self.resolve_path else raw)
        is_dir = os.path.isdir(raw_check)
        if is_dir and not self.dir_okay:
            self.fail(f"{raw!r} is a directory.", param, ctx)
        if not is_dir and not self.file_okay:
            self.fail(f"{raw!r} is a file.", param, ctx)
        if self.readable and not os.access(raw_check, os.R_OK):
            self.fail(f"{raw!r} is not readable.", param, ctx)
        if self.writable and not os.access(raw_check, os.W_OK):
            self.fail(f"{raw!r} is not writable.", param, ctx)
        if self.executable and not os.access(raw_check, os.X_OK):
            self.fail(f"{raw!r} is not executable.", param, ctx)
        return self._coerce(raw_check if self.resolve_path else raw)

    def shell_complete(self, ctx, param, incomplete):
        from ._completion import CompletionItem

        kind = "dir" if (self.dir_okay and not self.file_okay) else "file"
        return [CompletionItem(incomplete, type=kind)]


class FuncParamType(ParamType):
    """Wraps a conversion function that refuses input by raising ValueError."""

    def __init__(self, func) -> None:
        self.func = func
        self.name = getattr(func, "__name__", "text").lower()

    def convert(self, value, param, ctx):
        try:
            return self.func(value)
        except ValueError:
            self.fail(f"{value!r} is not a valid {self.name}.", param, ctx)


_BUILTIN_MAP = {str: STRING, int: INT, float: FLOAT, bool: BOOL, uuid.UUID: UUID}


def convert_type(ty, default=None) -> ParamType:
    """Turn a type argument (or a default's type) into a ParamType."""
    if ty is None:
        if default is None:
            return STRING
        sample = default
        if isinstance(default, (list, tuple)):
            if not default:
                return STRING
            sample = default[0]
        if isinstance(sample, bool):
            return BOOL
        if isinstance(sample, int):
            return INT
        if isinstance(sample, float):
            return FLOAT
        return STRING
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, type) and ty in _BUILTIN_MAP:
        return _BUILTIN_MAP[ty]
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"Unsupported parameter type: {ty!r}")
