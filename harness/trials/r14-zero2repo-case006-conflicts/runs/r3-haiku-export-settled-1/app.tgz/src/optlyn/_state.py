"""Per-thread stack of the invocation contexts that are currently running (FP-07)."""

from __future__ import annotations

import threading

_local = threading.local()


def _stack() -> list:
    try:
        return _local.stack
    except AttributeError:
        _local.stack = []
        return _local.stack


def push_context(ctx) -> None:
    _stack().append(ctx)


def pop_context() -> None:
    _stack().pop()


def get_current_context(silent: bool = False):
    """Return the context current on this thread (Interface Contract section 6)."""
    stack = _stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context on this thread.")
