"""Shell completion: registration scripts and suggestion output (FP-12, Interface Contract section 8)."""

from __future__ import annotations

import os
import re

from .core import Command, Group, _complete_var_name
from .paramtypes import File, Path
from .termui import echo

SHELLS = ("bash", "zsh", "fish", "powershell")
PATH_MARK = "__optlyn_path__"


class CompletionItem:
    """A suggestion: a value, optional help, and a type ('plain' for ordinary values)."""

    def __init__(self, value, help=None, type="plain") -> None:
        self.value = value
        self.help = help
        self.type = type

    def __repr__(self) -> str:
        return f"CompletionItem({self.value!r}, help={self.help!r}, type={self.type!r})"


def _fn_name(prog_name: str) -> str:
    return "_" + re.sub(r"\W", "_", prog_name) + "_completion"


def _script(shell: str, prog_name: str) -> str:
    var = _complete_var_name(prog_name)
    fn = _fn_name(prog_name)
    if shell == "bash":
        return f"""{fn}() {{
    local IFS=$'\\n'
    local response
    response=$(env COMP_WORDS="${{COMP_WORDS[*]}}" COMP_CWORD=$COMP_CWORD {var}=bash_complete "$1")
    COMPREPLY=()
    for item in $response; do
        case "$item" in
            {PATH_MARK}:file:*) COMPREPLY+=( $(compgen -f -- "${{item#{PATH_MARK}:file:}}") ) ;;
            {PATH_MARK}:dir:*) COMPREPLY+=( $(compgen -d -- "${{item#{PATH_MARK}:dir:}}") ) ;;
            *) COMPREPLY+=( "$item" ) ;;
        esac
    done
    return 0
}}
complete -o default -F {fn} {prog_name}
"""
    if shell == "zsh":
        return f"""#compdef {prog_name}
{fn}() {{
    local -a completions
    local -a response
    response=("${{(@f)$(env COMP_WORDS="${{words[*]}}" COMP_CWORD=$((CURRENT-1)) {var}=zsh_complete {prog_name})}}")
    for item in "${{response[@]}}"; do
        case $item in
            {PATH_MARK}:file:*) _files ;;
            {PATH_MARK}:dir:*) _path_files -/ ;;
            *) completions+=("${{item%%$'\\t'*}}") ;;
        esac
    done
    compadd -- "${{completions[@]}}"
}}
compdef {fn} {prog_name}
"""
    if shell == "fish":
        return f"""function {fn}_complete
    set -l cmd (commandline -opc)
    set -l incomplete (commandline -ct)
    set -lx COMP_WORDS (string join " " -- $cmd)
    set -lx COMP_CWORD "$incomplete"
    set -lx {var} fish_complete
    {prog_name}
end
complete --no-files --command {prog_name} --arguments '({fn}_complete)'
"""
    return f"""Register-ArgumentCompleter -Native -CommandName '{prog_name}' -ScriptBlock {{
    param($wordToComplete, $commandAst, $cursorPosition)
    $env:COMP_WORDS = $commandAst.ToString()
    $env:COMP_CWORD = $commandAst.CommandElements.Count
    $env:{var} = 'powershell_complete'
    & '{prog_name}' | ForEach-Object {{
        [System.Management.Automation.CompletionResult]::new($_, $_, 'ParameterValue', $_)
    }}
    Remove-Item Env:{var}
}}
"""


def _resolve_context(cli, prog_name, args):
    ctx = cli.make_context(prog_name, args, resilient_parsing=True)
    while True:
        left = ctx.protected_args + ctx.args
        if not isinstance(ctx.command, Group) or not left:
            return ctx
        sub = ctx.command.get_command(ctx, left[0])
        if sub is None:
            return ctx
        ctx = sub.make_context(left[0], left[1:], parent=ctx, resilient_parsing=True)


def _path_request(param, ctx, incomplete):
    t = param.type
    if isinstance(t, File):
        kind = "file"
    elif isinstance(t, Path):
        kind = "dir" if (t.dir_okay and not t.file_okay) else "file"
    else:
        kind = "file"
    return [CompletionItem(incomplete, type=kind)]


def _param_items(ctx, param, incomplete):
    if param.shell_complete_func is not None:
        raw = param.shell_complete_func(ctx, param, incomplete)
    elif isinstance(param.type, (File, Path)):
        return _path_request(param, ctx, incomplete)
    else:
        raw = param.type.shell_complete(ctx, param, incomplete)
    items = []
    for item in raw or []:
        if isinstance(item, CompletionItem):
            items.append(item)
        else:
            items.append(CompletionItem(str(item)))
    return items


def get_completions(cli, prog_name, args, incomplete):
    """Suggestions for `incomplete` after the tokens `args` (excluding the program name)."""
    ctx = _resolve_context(cli, prog_name, args)
    cmd = ctx.command
    prefixes = {"-"}
    for p in cmd.get_params(ctx):
        if p.is_option:
            prefixes.update(o[0] for o in p.opts + p.secondary_opts)

    previous = args[-1] if args else None
    if previous is not None and not incomplete.startswith("-"):
        for p in cmd.get_params(ctx):
            if p.is_option and not p.is_flag and not p.hidden and previous in p.opts:
                return _param_items(ctx, p, incomplete)

    if incomplete[:1] in prefixes and incomplete:
        items = []
        for p in cmd.get_params(ctx):
            if not p.is_option or p.hidden:
                continue
            for name in p.opts + p.secondary_opts:
                if name.startswith(incomplete):
                    items.append(CompletionItem(name, help=p.help))
        return items

    items = []
    if isinstance(cmd, Group):
        for name in cmd.list_commands(ctx):
            sub = cmd.get_command(ctx, name)
            if sub is None or sub.hidden or not name.startswith(incomplete):
                continue
            items.append(CompletionItem(name, help=sub.get_short_help_str(45)))
        return items

    for p in cmd.params:
        if p.is_option or p.hidden or p.name in ctx.params:
            continue
        return _param_items(ctx, p, incomplete)
    return items


def _format_item(item, shell: str) -> str:
    if item.type != "plain":
        return f"{PATH_MARK}:{item.type}:{item.value}"
    if shell in ("zsh", "fish") and item.help:
        return f"{item.value}\t{' '.join(str(item.help).split())}"
    return item.value


def run_completion(cli: Command, prog_name: str, instruction: str) -> int:
    """Handle a completion instruction; returns the process status (0 when handled)."""
    shell, _, action = instruction.rpartition("_")
    if shell not in SHELLS or action not in ("source", "complete"):
        return 1
    if action == "source":
        echo(_script(shell, prog_name), nl=False)
        return 0

    words = os.environ.get("COMP_WORDS", "").split(" ")
    raw_cword = os.environ.get("COMP_CWORD", "")
    if shell == "fish":
        incomplete = raw_cword
        args = words[1:]
    else:
        try:
            cword = int(raw_cword) if raw_cword != "" else len(words)
        except ValueError:
            cword = len(words)
        incomplete = words[cword] if cword < len(words) else ""
        args = words[1:cword]
    args = [a for a in args if a != ""] if shell == "fish" else args
    items = get_completions(cli, prog_name, args, incomplete)
    for item in items:
        echo(_format_item(item, shell), nl=True)
    return 0
