"""Declaration decorators: command, group, option, argument and the ready-made options (FP-01..FP-08)."""

from __future__ import annotations

import re
import sys
from functools import update_wrapper
from importlib import metadata

from ._state import get_current_context
from .core import Argument, Command, Group, Option
from .termui import confirm, echo


def _attach_param(f, param) -> None:
    params = f.__dict__.setdefault("__optlyn_params__", [])
    params.append(param)


def _take_params(f) -> list:
    """Declarations attached to f, in declaration order; removes them from f (FP-01, FP-03)."""
    return list(reversed(f.__dict__.pop("__optlyn_params__", [])))


def _derive_name(func_name: str) -> str:
    name = re.sub(r"_(command|cmd|group|grp)$", "", func_name.lower())
    return name.replace("_", "-")


def command(name=None, cls=None, **attrs):
    """Decorator that turns a function into a Command (or an instance of `cls`)."""
    if callable(name) and not isinstance(name, str):
        return command()(name)
    cls = cls or Command

    def decorator(f):
        params = _take_params(f)
        cmd_name = name if name is not None else _derive_name(f.__name__)
        return cls(name=cmd_name, callback=f, params=params, **attrs)

    return decorator


def group(name=None, cls=None, **attrs):
    """Decorator that turns a function into a Group (or an instance of `cls`)."""
    if callable(name) and not isinstance(name, str):
        return group()(name)
    cls = cls or Group

    def decorator(f):
        params = _take_params(f)
        grp_name = name if name is not None else _derive_name(f.__name__)
        return cls(name=grp_name, callback=f, params=params, **attrs)

    return decorator


def option(*param_decls, cls=None, **attrs):
    """Attach an option to the function being decorated (Interface Contract section 4)."""
    cls = cls or Option

    def decorator(f):
        _attach_param(f, cls(list(param_decls), **attrs))
        return f

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach a positional argument to the function being decorated."""
    cls = cls or Argument

    def decorator(f):
        _attach_param(f, cls(list(param_decls), **attrs))
        return f

    return decorator


def _show_help(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


def help_option(*param_decls, **kwargs):
    """An extra eager help flag; it prints help and exits (FP-02)."""
    names = list(param_decls) or ["--help"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs["callback"] = _show_help
    return option(*names, **kwargs)


def _caller_package(depth: int = 2):
    try:
        module = sys._getframe(depth).f_globals.get("__name__", "")
    except ValueError:
        return None
    return module.partition(".")[0] or None


def _detect_version(name: str) -> str:
    try:
        return metadata.version(name)
    except metadata.PackageNotFoundError:
        pass
    providers = metadata.packages_distributions().get(name, [])
    for dist in providers:
        try:
            return metadata.version(dist)
        except metadata.PackageNotFoundError:
            continue
    raise RuntimeError(f"Could not detect the version of {name!r}; pass version=.")


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None,
                   **kwargs):
    """Eager --version flag printing a version identity and exiting (FP-02)."""
    names = list(param_decls) or ["--version"]
    if version is None and package_name is None:
        package_name = _caller_package(depth=2)

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        ident = version if version is not None else _detect_version(package_name)
        prog = prog_name or ctx.find_root().info_name or ""
        template = message or "%(prog)s, version %(version)s"
        echo(template % {"prog": prog, "package": package_name, "version": ident}, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*names, **kwargs)


def custom_version_option(callback, *param_decls, **kwargs):
    """Eager version flag whose whole identity is the string `callback(ctx)` returns (FP-02)."""
    names = list(param_decls) or ["--version"]

    def _callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(callback(ctx))
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = _callback
    return option(*names, **kwargs)


def password_option(*param_decls, **kwargs):
    """Prompting, hidden, confirmed option (FP-08)."""
    names = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    return option(*names, **kwargs)


def _abort_if_false(ctx, param, value):
    if not value:
        ctx.abort()


def confirmation_option(*param_decls, **kwargs):
    """Yes flag that asks when omitted and aborts when declined (FP-08)."""
    names = list(param_decls) or ["--yes"]
    prompt_text = kwargs.pop("prompt", "Do you want to continue?")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", prompt_text)
    kwargs.setdefault("help", "Confirm the action without prompting.")
    kwargs["callback"] = _abort_if_false
    return option(*names, **kwargs)


def pass_context(f):
    """Pass the current Context as the first argument (FP-07)."""

    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return update_wrapper(new_func, f)


def pass_obj(f):
    """Pass the current context's author object as the first argument (FP-07)."""

    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return update_wrapper(new_func, f)


def make_pass_decorator(object_type, ensure: bool = False):
    """Pass the nearest context object of `object_type`, creating one when ensure is set (FP-07)."""

    def decorator(f):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(
                    f"Managed to invoke callback without a context object of type "
                    f"{object_type.__name__!r} existing."
                )
            return f(obj, *args, **kwargs)

        return update_wrapper(new_func, f)

    return decorator
