"""In-process runner: CliRunner, Result and the isolated-filesystem helper (FP-14)."""

from __future__ import annotations

import contextlib
import io
import os
import shlex
import sys
import tempfile


class _Sink:
    """Records writes to the captured streams, both per stream and in write order."""

    def __init__(self) -> None:
        self.chunks = {"out": [], "err": []}
        self.mixed: list = []

    def add(self, key: str, data: bytes) -> None:
        self.chunks[key].append(data)
        self.mixed.append(data)


class _CaptureBuffer(io.BufferedIOBase):
    def __init__(self, sink: _Sink, key: str) -> None:
        self._sink = sink
        self._key = key

    def writable(self) -> bool:
        return True

    def write(self, data) -> int:
        data = bytes(data)
        self._sink.add(self._key, data)
        return len(data)

    def flush(self) -> None:
        pass


class _CaptureText(io.TextIOBase):
    def __init__(self, sink: _Sink, key: str, charset: str) -> None:
        self._buffer = _CaptureBuffer(sink, key)
        self._charset = charset

    @property
    def buffer(self):
        return self._buffer

    @property
    def encoding(self) -> str:
        return self._charset

    def writable(self) -> bool:
        return True

    def write(self, text) -> int:
        self._buffer.write(text.encode(self._charset))
        return len(text)

    def flush(self) -> None:
        pass

    def isatty(self) -> bool:
        return False


class _InputStream(io.TextIOBase):
    """Standard input fed by the runner; optionally echoes what was read (FP-14)."""

    def __init__(self, text: str, charset: str, echo_reads: bool, sink: _Sink) -> None:
        self._text = io.StringIO(text)
        self._charset = charset
        self._echo_reads = echo_reads
        self._sink = sink

    @property
    def encoding(self) -> str:
        return self._charset

    @property
    def _optlyn_echoes(self) -> bool:
        return self._echo_reads

    def _optlyn_prompt_line(self, hide_input: bool) -> str:
        line = self._text.readline()
        if line and self._echo_reads and not hide_input:
            self._sink.add("out", line.encode(self._charset))
        return line

    def readline(self, size: int = -1) -> str:
        line = self._text.readline(size)
        if line and self._echo_reads:
            self._sink.add("out", line.encode(self._charset))
        return line

    def read(self, size: int = -1) -> str:
        return self._text.read(size)

    def isatty(self) -> bool:
        return False

    def readable(self) -> bool:
        return True


class Result:
    """What one in-process invocation produced (FP-14)."""

    def __init__(self, runner, stdout_bytes: bytes, stderr_bytes: bytes, mixed: bytes,
                 return_value, exit_code: int, exception, exc_info) -> None:
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = mixed
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self) -> str:
        return self.output_bytes.decode(self.runner.charset, "replace")

    @property
    def stdout(self) -> str:
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self) -> str:
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    def __repr__(self) -> str:
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    """Invokes a command in-process with captured streams (FP-14)."""

    def __init__(self, charset: str = "utf-8", env=None, echo_stdin: bool = False,
                 catch_exceptions: bool = True, capture: str = "sys") -> None:
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli) -> str:
        return cli.name or "root"

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color: bool = False):
        sink = _Sink()
        if isinstance(input, bytes):
            text = input.decode(self.charset)
        else:
            text = input or ""
        merged_env = dict(self.env)
        merged_env.update(env or {})
        saved_env = {}
        for key, value in merged_env.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)

        old_streams = (sys.stdin, sys.stdout, sys.stderr)
        fd_files = None
        if self.capture == "fd":
            out_file = tempfile.TemporaryFile()
            err_file = tempfile.TemporaryFile()
            saved_fds = (os.dup(1), os.dup(2))
            sys.stdout.flush()
            sys.stderr.flush()
            os.dup2(out_file.fileno(), 1)
            os.dup2(err_file.fileno(), 2)
            sys.stdin = _InputStream(text, self.charset, self.echo_stdin, sink)
            sys.stdout = io.TextIOWrapper(io.FileIO(1, "w", closefd=False), encoding=self.charset,
                                          write_through=True)
            sys.stderr = io.TextIOWrapper(io.FileIO(2, "w", closefd=False), encoding=self.charset,
                                          write_through=True)
            fd_files = (out_file, err_file, saved_fds)
        else:
            sys.stdin = _InputStream(text, self.charset, self.echo_stdin, sink)
            sys.stdout = _CaptureText(sink, "out", self.charset)
            sys.stderr = _CaptureText(sink, "err", self.charset)
        try:
            yield sink
        finally:
            if fd_files is not None:
                out_file, err_file, saved_fds = fd_files
                for stream in (sys.stdout, sys.stderr):
                    try:
                        stream.flush()
                    except (OSError, ValueError):
                        pass
                os.dup2(saved_fds[0], 1)
                os.dup2(saved_fds[1], 2)
                os.close(saved_fds[0])
                os.close(saved_fds[1])
                out_file.seek(0)
                err_file.seek(0)
                out_data, err_data = out_file.read(), err_file.read()
                out_file.close()
                err_file.close()
                sink.chunks["out"] = [out_data]
                sink.chunks["err"] = [err_data]
                sink.mixed = [out_data, err_data]
            sys.stdin, sys.stdout, sys.stderr = old_streams
            for key, old in saved_env.items():
                if old is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = old

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None,
               color: bool = False, **extra) -> Result:
        """Run `cli` with `args` and capture what it writes (FP-14)."""
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if isinstance(args, str):
            args = shlex.split(args)
        prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
        standalone = extra.pop("standalone_mode", True)
        extra.setdefault("color", color)

        exit_code = 0
        exception = None
        exc_info = None
        return_value = None
        with self.isolation(input=input, env=env, color=color) as sink:
            try:
                return_value = cli.main(
                    args=list(args or []),
                    prog_name=prog_name,
                    standalone_mode=standalone,
                    **extra,
                )
            except SystemExit as e:
                if e.code is None:
                    exit_code = 0
                elif isinstance(e.code, int):
                    exit_code = e.code
                else:
                    sys.stderr.write(f"{e.code}\n")
                    exit_code = 1
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()

        return Result(
            self,
            b"".join(sink.chunks["out"]),
            b"".join(sink.chunks["err"]),
            b"".join(sink.mixed),
            return_value,
            exit_code,
            exception,
            exc_info,
        )

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Work in a new empty directory that is left in place afterwards (FP-14)."""
        if temp_dir is not None:
            os.makedirs(temp_dir, exist_ok=True)
        path = tempfile.mkdtemp(dir=temp_dir)
        cwd = os.getcwd()
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
