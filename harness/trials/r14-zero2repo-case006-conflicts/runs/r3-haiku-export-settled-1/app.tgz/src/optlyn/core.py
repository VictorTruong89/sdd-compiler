"""Contexts, parameters, the argument parser, commands and groups (PRD FP-01..FP-07)."""

from __future__ import annotations

import contextlib
import enum
import inspect
import os
import shutil
import sys

from ._state import pop_context, push_context
from .exceptions import (
    Abort,
    BadArgumentUsage,
    BadOptionUsage,
    BadParameter,
    Exit,
    MissingParameter,
    NoArgsIsHelp,
    NoSuchCommand,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .formatting import HelpFormatter, ellipsize, make_default_short_help
from .paramtypes import BOOL, INT, Tuple, convert_type
from .termui import confirm, echo, prompt

UNSET = object()
NEEDS_VALUE = object()
_DEFAULT_MAX_CONTENT_WIDTH = 80


class ParameterSource(enum.Enum):
    """Where a parameter's value came from (FP-07)."""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


# Most explicit wins (FP-03 ranking, with the default map above the environment per CF-000150).
_SOURCE_RANK = {
    ParameterSource.PROMPT: 5,
    ParameterSource.COMMANDLINE: 4,
    ParameterSource.DEFAULT_MAP: 3,
    ParameterSource.ENVIRONMENT: 2,
    ParameterSource.DEFAULT: 1,
}

_OPT_NAME_CHARS = "-/+"


@contextlib.contextmanager
def augment_usage_errors(ctx, param=None):
    """Attach the context and parameter to usage errors raised inside the block."""
    try:
        yield
    except BadParameter as e:
        if e.ctx is None:
            e.ctx = ctx
        if e.param is None:
            e.param = param
        raise
    except UsageError as e:
        if e.ctx is None:
            e.ctx = ctx
        raise


def _help_width(ctx) -> int:
    if ctx.terminal_width is not None:
        return ctx.terminal_width
    detected = shutil.get_terminal_size(fallback=(80, 24)).columns
    return min(detected, ctx.max_content_width)


class Context:
    """The state of one invocation of a command (Interface Contract section 6)."""

    def __init__(
        self,
        command,
        parent=None,
        info_name=None,
        obj=None,
        auto_envvar_prefix=None,
        default_map=None,
        terminal_width=None,
        max_content_width=None,
        allow_extra_args=None,
        allow_interspersed_args=None,
        ignore_unknown_options=None,
        help_option_names=None,
        token_normalize_func=None,
        color=None,
        show_default=None,
        resilient_parsing=False,
    ) -> None:
        self.parent = parent
        self.command = command
        self.info_name = info_name
        self.obj = obj if obj is not None else (parent.obj if parent is not None else None)

        if auto_envvar_prefix is None and parent is not None and parent.auto_envvar_prefix is not None:
            if info_name:
                auto_envvar_prefix = f"{parent.auto_envvar_prefix}_{info_name}"
        self.auto_envvar_prefix = auto_envvar_prefix

        if default_map is None and parent is not None and isinstance(parent.default_map, dict):
            default_map = parent.default_map.get(info_name)
        self.default_map = default_map

        def inherit(value, attr, fallback):
            if value is not None:
                return value
            if parent is not None:
                return getattr(parent, attr)
            return fallback

        self.terminal_width = inherit(terminal_width, "terminal_width", None)
        self.max_content_width = inherit(max_content_width, "max_content_width", _DEFAULT_MAX_CONTENT_WIDTH)
        self.help_option_names = inherit(help_option_names, "help_option_names", ["--help"])
        self.token_normalize_func = inherit(token_normalize_func, "token_normalize_func", None)
        self.color = inherit(color, "color", None)
        self.show_default = inherit(show_default, "show_default", None)
        self.allow_extra_args = (
            command.allow_extra_args if allow_extra_args is None else allow_extra_args
        )
        self.allow_interspersed_args = (
            command.allow_interspersed_args if allow_interspersed_args is None else allow_interspersed_args
        )
        self.ignore_unknown_options = (
            command.ignore_unknown_options if ignore_unknown_options is None else ignore_unknown_options
        )
        self.resilient_parsing = resilient_parsing

        self.params: dict = {}
        self.args: list = []
        self.protected_args: list = []
        self.invoked_subcommand = None
        self._parameter_source: dict = {}
        self._param_rank: dict = {}
        self._depth = 0
        self._exit_stack = contextlib.ExitStack()
        self._passthrough = False

    # -- naming -----------------------------------------------------------
    @property
    def command_path(self) -> str:
        names = []
        ctx = self
        while ctx is not None:
            if ctx.info_name:
                names.append(ctx.info_name)
            ctx = ctx.parent
        return " ".join(reversed(names))

    def make_formatter(self) -> HelpFormatter:
        return HelpFormatter(width=_help_width(self))

    def get_help(self) -> str:
        return self.command.get_help(self)

    def get_usage(self) -> str:
        return self.command.get_usage(self).rstrip("\n")

    # -- defaults and sources ----------------------------------------------
    def lookup_default(self, name):
        if isinstance(self.default_map, dict):
            return self.default_map.get(name)
        return None

    def get_parameter_source(self, name):
        return self._parameter_source.get(name)

    def _store_param(self, param, value, source, index) -> None:
        rank = (_SOURCE_RANK[source], 1 if (source is ParameterSource.DEFAULT and param._default_explicit) else 0, index)
        prev = self._param_rank.get(param.name)
        if prev is None or rank >= prev:
            self.params[param.name] = value
            self._param_rank[param.name] = rank
            self._parameter_source[param.name] = source

    # -- objects ------------------------------------------------------------
    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type):
        node = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

    # -- resources ------------------------------------------------------------
    def call_on_close(self, func) -> None:
        self._exit_stack.callback(func)

    def with_resource(self, cm):
        return self._exit_stack.enter_context(cm)

    def close(self) -> None:
        self._exit_stack.close()

    # -- control --------------------------------------------------------------
    def exit(self, code: int = 0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def invoke(self, callback, *args, **kwargs):
        """Run a command or callable from inside this context (FP-07)."""
        if isinstance(callback, Command):
            other = callback
            sub = Context(other, info_name=other.name, parent=self)
            for param in other.get_params(sub):
                if param.expose_value and param.name not in kwargs:
                    default = param.get_default(sub)
                    if default is None:
                        kwargs[param.name] = param._missing_value()
                    else:
                        kwargs[param.name] = param.type_cast_value(sub, default)
            sub.params.update(kwargs)
            with sub:
                return other.callback(*args, **kwargs)
        with self:
            return callback(*args, **kwargs)

    def forward(self, cmd, *args, **kwargs):
        merged = dict(self.params)
        merged.update(kwargs)
        return self.invoke(cmd, *args, **merged)

    # -- context manager ------------------------------------------------------
    def __enter__(self):
        self._depth += 1
        push_context(self)
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self._depth -= 1
        pop_context()
        if self._depth == 0:
            self.close()


def _show_help_callback(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


def _split_decls(decls):
    """Split declarations into (name, flags, secondary flags) (FP-03)."""
    name = None
    opts, secondary = [], []
    for decl in decls:
        if not decl:
            continue
        if decl[0] in _OPT_NAME_CHARS:
            cut = decl.find("/", 1)
            if cut > 0:
                opts.append(decl[:cut])
                secondary.append(decl[cut + 1:])
            else:
                opts.append(decl)
        elif decl.isidentifier():
            name = decl
        else:
            name = decl.replace("-", "_")
    if name is None and not opts:
        raise TypeError("Could not determine a name for the parameter.")
    if name is None:
        longs = [o for o in opts if len(o) > 2 and o[0] * 2 == o[:2]]
        chosen = (longs or opts)[0]
        name = chosen.lstrip(_OPT_NAME_CHARS).replace("-", "_")
    return name, opts, secondary


class Parameter:
    """Base class of options and arguments."""

    is_option = False

    def __init__(self, name, opts=(), secondary=(), *, type=None, required=False, default=None,
                 callback=None, nargs=1, multiple=False, metavar=None, expose_value=True,
                 is_eager=False, envvar=None, shell_complete=None, deprecated=False,
                 hidden=False, help=None) -> None:
        self.name = name
        self.opts = list(opts)
        self.secondary_opts = list(secondary)
        self.type = type
        self.required = required
        self.default = default
        self._default_explicit = default is not None
        self.callback = callback
        self.nargs = nargs
        self.multiple = multiple
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        self.envvar = envvar
        self.shell_complete_func = shell_complete
        self.deprecated = bool(deprecated)
        self.deprecation_note = deprecated if isinstance(deprecated, str) else None
        self.hidden = hidden
        self.help = help

    def get_default(self, ctx=None):
        default = self.default
        if callable(default):
            default = default()
        return default

    def _missing_value(self):
        if self.multiple or self.nargs == -1:
            return ()
        return None

    def _is_missing(self, value) -> bool:
        if value is None:
            return True
        return bool(self.multiple and isinstance(value, (list, tuple)) and len(value) == 0)

    def _display_name(self) -> str:
        return " / ".join(f"'{o}'" for o in self.opts) if self.opts else f"'{self.name.upper()}'"

    def get_error_hint(self, ctx=None) -> str:
        return self._display_name()

    def _cast_occ(self, ctx, occ):
        if isinstance(self.type, Tuple):
            return self.type(occ, self, ctx)
        if self.nargs != 1:
            return tuple(self.type(v, self, ctx) for v in occ)
        return self.type(occ, self, ctx)

    def type_cast_value(self, ctx, value):
        if self.multiple:
            return tuple(self._cast_occ(ctx, o) for o in value)
        if self.nargs != 1:
            return self._cast_occ(ctx, value)
        return self.type(value, self, ctx)

    def _shape_env(self, rv: str):
        if self.multiple or self.nargs != 1:
            tokens = self.type.split_envvar_value(rv)
            if self.multiple and self.nargs == 1:
                return tokens
            if self.multiple:
                n = self.nargs
                return [tuple(tokens[i:i + n]) for i in range(0, len(tokens), n)]
            return tuple(tokens)
        return rv

    def _shape_raw(self, raw, source):
        if raw is None:
            return None
        if self.multiple:
            if isinstance(raw, str):
                if source is ParameterSource.ENVIRONMENT or (
                    source is ParameterSource.DEFAULT_MAP and self.nargs != 1
                ):
                    return self._shape_env(raw)
                raise BadOptionUsage(
                    f"{self._display_name()} needs an iterable (sequence) default; "
                    "pass a one-element sequence for a single string.",
                    None,
                )
            try:
                return list(raw)
            except TypeError:
                raise BadOptionUsage(
                    f"{self._display_name()} needs an iterable (sequence) default.", None
                ) from None
        if self.nargs != 1:
            if isinstance(raw, str):
                return self._shape_env(raw)
            if isinstance(raw, list):
                return tuple(raw)
        return raw

    def _convert_prompt(self, ctx, raw):
        occ = raw
        if self.nargs != 1:
            if isinstance(raw, str):
                occ = tuple(raw.split())
            elif isinstance(raw, list):
                occ = tuple(raw)
        converted = self._cast_occ(ctx, occ)
        return (converted,) if self.multiple else converted

    def handle_parse_result(self, ctx, raw, index=0):
        """Resolve one parameter from its command-line occurrences, env, prompt and defaults."""
        if raw is not UNSET and self.deprecated and not ctx.resilient_parsing:
            self._warn_deprecated()
        with augment_usage_errors(ctx, param=self):
            value, source = self._resolve(ctx, raw)
            if self.callback is not None and not ctx.resilient_parsing:
                value = self.callback(ctx, self, value)
        if self.expose_value:
            ctx._store_param(self, value, source, index)
        return value

    def _warn_deprecated(self) -> None:
        raise NotImplementedError

    def _resolve(self, ctx, raw):
        value = UNSET
        source = None
        if raw is not UNSET:
            value = self._shape_cmdline(ctx, raw)
            source = ParameterSource.COMMANDLINE
            if value is NEEDS_VALUE:
                if self.prompt_enabled and not ctx.resilient_parsing:
                    return self._prompt(ctx, self._prompt_default(ctx)), ParameterSource.PROMPT
                if self._flag_value_form:
                    value = [self.flag_value] if self.multiple else self.flag_value
                else:
                    raise BadOptionUsage(f"Option {self._display_name()} requires an argument.", ctx)
        if value is UNSET:
            dm = ctx.lookup_default(self.name)
            if dm is not None and not ctx.resilient_parsing:
                if self.prompt_enabled and self.prompt_required:
                    return self._prompt(ctx, dm), ParameterSource.PROMPT
                value = self._shape_raw(dm, ParameterSource.DEFAULT_MAP)
                source = ParameterSource.DEFAULT_MAP
            else:
                env_value = self._from_env(ctx)
                if env_value is not UNSET:
                    value, source = env_value, ParameterSource.ENVIRONMENT
                elif self.prompt_enabled and self.prompt_required and not ctx.resilient_parsing:
                    return self._prompt(ctx, self.get_default(ctx)), ParameterSource.PROMPT
                else:
                    value = self._shape_raw(self.get_default(ctx), ParameterSource.DEFAULT)
                    source = ParameterSource.DEFAULT

        if self._is_missing(value):
            if self.required and not ctx.resilient_parsing:
                raise MissingParameter(ctx=ctx, param=self)
            return self._missing_value(), source
        return self.type_cast_value(ctx, value), source

    # Hooks overridden by subclasses
    prompt_enabled = False
    prompt_required = False
    _flag_value_form = False
    flag_value = None

    def _from_env(self, ctx):
        return UNSET

    def _prompt(self, ctx, default):
        raise NotImplementedError

    def _prompt_default(self, ctx):
        dm = ctx.lookup_default(self.name)
        return dm if dm is not None else self.get_default(ctx)

    def __repr__(self) -> str:
        return f"<{type(self).__name__} {self.name}>"


class Option(Parameter):
    """A named parameter, given as --long, -s, or a declared prefix (FP-03)."""

    is_option = True

    def __init__(self, param_decls=(), *, is_flag=None, flag_value=None, count=False,
                 multiple=False, nargs=None, type=None, default=None, required=False,
                 envvar=None, allow_from_autoenv=True, prompt=None, prompt_required=True,
                 hide_input=False, confirmation_prompt=False, callback=None, is_eager=False,
                 expose_value=True, hidden=False, deprecated=False, help=None, metavar=None,
                 show_default=None, show_envvar=False, shell_complete=None) -> None:
        name, opts, secondary = _split_decls(list(param_decls))
        if not opts:
            raise TypeError("An option needs at least one flag name.")
        if count and multiple:
            raise TypeError("A counting option cannot also be repeatable.")
        if count:
            is_flag = True
            if flag_value is None:
                flag_value = 1
        if is_flag is None:
            is_flag = bool(secondary) or flag_value is not None
        if secondary:
            is_flag = True
        if is_flag and flag_value is None:
            flag_value = True
        if prompt is not None and prompt is not False and deprecated:
            raise TypeError("A deprecated option cannot use a prompt.")
        if deprecated and required:
            raise TypeError("A deprecated option cannot be required.")
        if is_flag and nargs not in (None, 1):
            raise TypeError("A flag takes exactly one value per occurrence.")

        self.is_flag = bool(is_flag)
        self.count = bool(count)
        self.is_bool_flag = self.is_flag and isinstance(flag_value, bool)
        self.flag_value = flag_value
        self._flag_value_form = (not self.is_flag) and flag_value is not None
        self.allow_from_autoenv = allow_from_autoenv
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.prompt_required = prompt_required
        self.prompt_enabled = bool(prompt) and prompt is not None
        self._prompt_text_value = prompt if isinstance(prompt, str) else None
        self.prompt = prompt

        if isinstance(type, Tuple):
            nargs = len(type.types) if nargs is None else nargs
            if nargs != len(type.types):
                raise TypeError("nargs must match the tuple length.")
        if nargs is None:
            nargs = 1
        if nargs < 1:
            raise TypeError("An option takes a positive number of values.")

        if default is None and self.is_bool_flag and not multiple and not count:
            auto_default = False
        elif default is None and count:
            auto_default = 0
        else:
            auto_default = None
        explicit = default is not None
        if type is None:
            if self.is_flag:
                resolved_type = BOOL if self.is_bool_flag or flag_value is None else convert_type(None, flag_value)
            elif count:
                resolved_type = INT
            else:
                resolved_type = convert_type(None, default)
        else:
            resolved_type = convert_type(type, default)

        super().__init__(
            name, opts, secondary, type=resolved_type, required=required,
            default=default if default is not None else auto_default,
            callback=callback, nargs=nargs, multiple=multiple, metavar=metavar,
            expose_value=expose_value, is_eager=is_eager, envvar=envvar,
            shell_complete=shell_complete, deprecated=deprecated, hidden=hidden, help=help,
        )
        self._default_explicit = explicit
        self.help = help

    def flag_value_for(self, secondary: bool):
        if secondary:
            return False
        return self.flag_value

    # -- env ----------------------------------------------------------------
    def resolve_envvar_names(self, ctx) -> list:
        names = []
        if self.envvar:
            names.extend([self.envvar] if isinstance(self.envvar, str) else list(self.envvar))
        if self.allow_from_autoenv and ctx.auto_envvar_prefix is not None:
            auto = f"{ctx.auto_envvar_prefix}_{self.name}".upper().replace("-", "_")
            names.append(auto)
        return names

    def _from_env(self, ctx):
        for name in self.resolve_envvar_names(ctx):
            rv = os.environ.get(name)
            if not rv:
                continue
            if self.is_flag:
                parsed = self._parse_flag_env(ctx, rv)
                if parsed is UNSET:
                    continue
                return parsed
            return self._shape_env(rv)
        return UNSET

    def _parse_flag_env(self, ctx, rv):
        if not self.is_bool_flag and rv == str(self.flag_value):
            return self.flag_value
        text = rv.strip().lower()
        if text in ("true", "1", "yes", "on", "t", "y"):
            return self.flag_value
        if text in ("false", "0", "no", "off", "f", "n"):
            return False
        if self.is_bool_flag and text == "":
            return False
        if self.is_bool_flag:
            raise BadParameter(f"{rv!r} is not a valid boolean.", ctx=ctx, param=self)
        return UNSET

    # -- command line -------------------------------------------------------
    def _shape_cmdline(self, ctx, occs):
        if any(o is NEEDS_VALUE for o in occs):
            return NEEDS_VALUE
        if self.count:
            return sum(occs)
        if self.multiple:
            return list(occs)
        return occs[-1]

    def _warn_deprecated(self) -> None:
        message = f"DeprecationWarning: The {self._display_name()} option is deprecated."
        if self.deprecation_note:
            message += f" {self.deprecation_note}"
        echo(message, err=True)

    # -- prompting ----------------------------------------------------------
    def _prompt(self, ctx, default):
        text = self._prompt_text_value or self.name.replace("_", " ").capitalize()
        if self.is_flag:
            return confirm(text, default=bool(default))
        if self.multiple and isinstance(default, (list, tuple)):
            default = " ".join(str(d) for d in default) if default else None
        return prompt(
            text,
            default=default,
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            value_proc=lambda raw: self._convert_prompt(ctx, raw),
        )

    # -- help -----------------------------------------------------------------
    def get_help_record(self, ctx):
        if self.hidden:
            return None
        first = ", ".join(self.opts)
        if self.secondary_opts:
            first = f"{first}/{', '.join(self.secondary_opts)}"
        if not self.is_flag:
            metavar = self.metavar or self.type.get_metavar(self)
            if metavar:
                first = f"{first} {metavar}"
        extras = []
        if self.deprecated:
            extras.append("Deprecated" + (f": {self.deprecation_note}" if self.deprecation_note else ""))
        show = self.show_default if self.show_default is not None else ctx.show_default
        if show:
            text = self._default_text(ctx, show)
            if text:
                extras.append(f"default: {text}")
        if self.show_envvar:
            names = self.resolve_envvar_names(ctx)
            if names:
                extras.append(f"env var: {', '.join(names)}")
        help_text = self.help or ""
        if extras:
            help_text = f"{help_text} [{'; '.join(extras)}]".strip()
        return first, help_text

    def _default_text(self, ctx, show):
        if isinstance(show, str):
            return show
        if callable(self.default):
            return "(dynamic)"
        value = self.default
        if self.is_flag and not self.multiple and not value:
            return ""
        if value is None or value == ():
            return ""
        if isinstance(value, (list, tuple)):
            return ", ".join(str(v) for v in value)
        return str(value)


class Argument(Parameter):
    """A positional parameter (FP-04)."""

    def __init__(self, param_decls=(), *, type=None, required=None, default=None, nargs=None,
                 envvar=None, deprecated=False, help=None, metavar=None, callback=None,
                 expose_value=True, hidden=False, shell_complete=None) -> None:
        decls = list(param_decls)
        if len(decls) != 1 or decls[0][:1] in _OPT_NAME_CHARS:
            raise TypeError("An argument takes a single destination name.")
        name = decls[0].replace("-", "_")
        if isinstance(type, Tuple):
            nargs = len(type.types) if nargs is None else nargs
        if nargs is None:
            nargs = 1
        if nargs == 0 or nargs < -1:
            raise TypeError("An argument's nargs must be positive or -1.")
        if required is None:
            required = default is None and nargs != -1
        if deprecated and required:
            raise TypeError("A deprecated argument cannot be required.")
        self.metavar = metavar
        resolved_type = convert_type(type, default)
        super().__init__(
            name, type=resolved_type, required=bool(required), default=default,
            callback=callback, nargs=nargs, metavar=metavar, expose_value=expose_value,
            envvar=envvar, shell_complete=shell_complete, deprecated=deprecated,
            hidden=hidden, help=help,
        )

    def _from_env(self, ctx):
        names = [self.envvar] if isinstance(self.envvar, str) else list(self.envvar or [])
        for name in names:
            rv = os.environ.get(name)
            if rv:
                return self._shape_env(rv)
        return UNSET

    def _shape_cmdline(self, ctx, tokens):
        return tokens[0] if self.nargs == 1 else tuple(tokens)

    def _warn_deprecated(self) -> None:
        message = f"DeprecationWarning: The argument {self.name.upper()} is deprecated."
        if self.deprecation_note:
            message += f" {self.deprecation_note}"
        echo(message, err=True)

    def get_error_hint(self, ctx=None) -> str:
        return f"'{(self.metavar or self.name).upper()}'"

    def usage_pieces(self) -> list:
        metavar = self.metavar or self.name.upper()
        if self.nargs == -1:
            text = f"{metavar}..."
            return [text] if self.required else [f"[{text}]"]
        text = " ".join([metavar] * self.nargs)
        return [text] if self.required else [f"[{text}]"]

    def get_help_record(self, ctx=None):
        if self.hidden or not self.help:
            return None
        return self.metavar or self.name.upper(), self.help


def _unpack_args(items, nargs_spec):
    """Split positional tokens among arguments of the given arity (FP-04)."""
    total = len(items)
    pos = 0
    out = []
    for i, nargs in enumerate(nargs_spec):
        if nargs == -1:
            fixed_after = sum(x for x in nargs_spec[i + 1:] if x != -1)
            take = max(0, total - pos - fixed_after)
        else:
            take = nargs
        chunk = items[pos:pos + take]
        pos += len(chunk)
        out.append([tok for tok, _ in chunk])
    return out, items[pos:]


class _OptionParser:
    """POSIX-style parser for one command's options (FP-03)."""

    def __init__(self, ctx, options, passthrough_after_positional=False) -> None:
        self.ctx = ctx
        self.norm = ctx.token_normalize_func
        self.interspersed = ctx.allow_interspersed_args
        self.ignore_unknown = bool(ctx.ignore_unknown_options or ctx.resilient_parsing)
        self.passthrough_after = passthrough_after_positional
        self.prefixes = {"-"}
        self.lookup = {}
        for opt in options:
            for flag in opt.opts:
                self.prefixes.add(flag[0])
                self.lookup[self._key(flag)] = (opt, False)
            for flag in opt.secondary_opts:
                self.prefixes.add(flag[0])
                self.lookup[self._key(flag)] = (opt, True)
        self.occurrences: dict = {}
        self.order: list = []

    def _key(self, name: str) -> str:
        return self.norm(name) if self.norm is not None else name

    def _entry(self, name):
        return self.lookup.get(self._key(name))

    def _record(self, opt, value) -> None:
        self.occurrences.setdefault(opt, []).append(value)
        if opt not in self.order:
            self.order.append(opt)

    def _take(self, opt, name, explicit, rargs):
        if explicit is not None:
            if opt.nargs == 1:
                return explicit
            tokens = [explicit]
            while len(tokens) < opt.nargs and rargs:
                tokens.append(rargs.pop(0))
            return tuple(tokens)
        needs_sentinel = opt.prompt_enabled or opt._flag_value_form
        if opt.nargs == 1:
            if rargs and not (
                opt._flag_value_form and rargs[0][:1] in self.prefixes and len(rargs[0]) > 1
            ):
                return rargs.pop(0)
            if needs_sentinel:
                return NEEDS_VALUE
            if self.ctx.resilient_parsing:
                return None
            raise BadOptionUsage(f"Option {name!r} requires an argument.", self.ctx)
        if len(rargs) >= opt.nargs:
            tokens = rargs[:opt.nargs]
            del rargs[:opt.nargs]
            return tuple(tokens)
        if needs_sentinel:
            return NEEDS_VALUE
        if self.ctx.resilient_parsing:
            return None
        raise BadOptionUsage(f"Option {name!r} requires {opt.nargs} arguments.", self.ctx)

    def _apply(self, entry, name, explicit, rargs):
        opt, secondary = entry
        if opt.is_flag:
            if explicit is not None:
                raise BadOptionUsage(f"Option {name!r} does not take a value.", self.ctx)
            self._record(opt, opt.flag_value_for(secondary))
        else:
            self._record(opt, self._take(opt, name, explicit, rargs))

    def _passthrough(self, seen_positional: bool) -> bool:
        return self.ignore_unknown or (self.passthrough_after and seen_positional)

    def _option(self, arg, rargs, largs, seen_positional) -> None:
        prefix = arg[0]
        entry = self._entry(arg)
        if entry is not None:
            self._apply(entry, arg, None, rargs)
            return
        if arg.startswith(prefix * 2):
            name, sep, explicit = arg.partition("=")
            entry = self._entry(name)
            if entry is None:
                if self._passthrough(seen_positional):
                    largs.append((arg, False))
                    return
                raise NoSuchOption(name, ctx=self.ctx)
            self._apply(entry, name, explicit if sep else None, rargs)
            return
        chars = arg[1:]
        unknown = []
        j = 0
        while j < len(chars):
            key = prefix + chars[j]
            entry = self._entry(key)
            if entry is None:
                if self._passthrough(seen_positional):
                    unknown.append(chars[j])
                    j += 1
                    continue
                raise NoSuchOption(key, ctx=self.ctx)
            opt, secondary = entry
            if opt.is_flag:
                self._record(opt, opt.flag_value_for(secondary))
                j += 1
                continue
            rest = chars[j + 1:]
            self._record(opt, self._take(opt, key, rest or None, rargs))
            j = len(chars)
        if unknown:
            largs.append((prefix + "".join(unknown), False))

    def parse(self, args):
        rargs = list(args)
        largs = []
        dd = False
        seen_positional = False
        while rargs:
            arg = rargs.pop(0)
            if dd:
                largs.append((arg, True))
                continue
            if arg == "--":
                dd = True
                continue
            if len(arg) > 1 and arg[0] in self.prefixes:
                self._option(arg, rargs, largs, seen_positional)
                continue
            largs.append((arg, False))
            if not self.interspersed:
                largs.extend((a, False) for a in rargs)
                rargs = []
                break
            seen_positional = True
        return self.occurrences, self.order, largs


def _processing_order(params, order):
    invoked = {p: i for i, p in enumerate(order)}
    indexed = list(enumerate(params))
    indexed.sort(key=lambda pair: (not pair[1].is_eager, invoked.get(pair[1], float("inf")), pair[0]))
    return indexed


def _opt_shaped(token: str, prefixes) -> bool:
    return len(token) > 1 and token[0] in prefixes


class Command:
    """A leaf command: parameters plus a callback (FP-01)."""

    allow_extra_args = False
    allow_interspersed_args = True
    ignore_unknown_options = False
    _dispatches = False

    def __init__(self, name, context_settings=None, callback=None, params=None, help=None,
                 epilog=None, short_help=None, options_metavar="[OPTIONS]", add_help_option=True,
                 no_args_is_help=False, hidden=False, deprecated=False) -> None:
        self.name = name
        self.context_settings = dict(context_settings or {})
        self.callback = callback
        self.params = list(params or [])
        if help is None and callback is not None and callback.__doc__:
            help = inspect.cleandoc(callback.__doc__)
        if help is not None:
            help = help.split("\f")[0]
        self.help = help
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = bool(deprecated)
        self.deprecation_note = deprecated if isinstance(deprecated, str) else None
        variadic = [p for p in self.params if not p.is_option and p.nargs == -1]
        if len(variadic) > 1:
            raise TypeError("Only one variadic argument is allowed per command.")

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    # -- parameters ----------------------------------------------------------
    def get_help_option(self, ctx):
        if not self.add_help_option:
            return None
        taken = {n for p in self.params if p.is_option for n in p.opts + p.secondary_opts}
        names = [n for n in (ctx.help_option_names or []) if n not in taken]
        if not names:
            return None
        return Option(
            names, is_flag=True, is_eager=True, expose_value=False,
            callback=_show_help_callback, help="Show this message and exit.",
        )

    def get_params(self, ctx):
        extra = self.get_help_option(ctx)
        return self.params + ([extra] if extra is not None else [])

    # -- context ---------------------------------------------------------------
    def make_context(self, info_name, args, parent=None, _passthrough=False, **extra):
        for key, value in self.context_settings.items():
            extra.setdefault(key, value)
        ctx = Context(self, info_name=info_name, parent=parent, **extra)
        ctx._passthrough = _passthrough
        push_context(ctx)
        try:
            self.parse_args(ctx, list(args))
        finally:
            pop_context()
        return ctx

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsIsHelp(ctx=ctx, message="Missing command.")
        extras = self._parse(ctx, args, dispatch=False)
        if extras and not ctx.resilient_parsing and not ctx._passthrough:
            raw = [tok for tok, _ in extras]
            if not ctx.allow_extra_args:
                raise UsageError(f"Got unexpected extra argument(s) ({' '.join(raw)}).", ctx)
            if not ctx.ignore_unknown_options:
                prefixes = {"-", "/", "+"}
                for tok, dd in extras:
                    if not dd and _opt_shaped(tok, prefixes):
                        raise UsageError(f"Got unexpected extra argument ({tok}).", ctx)
        ctx.args = [tok for tok, _ in extras]

    def _parse(self, ctx, args, dispatch: bool):
        params = self.get_params(ctx)
        options = [p for p in params if p.is_option]
        arguments = [p for p in params if not p.is_option]
        parser = _OptionParser(ctx, options, passthrough_after_positional=dispatch)
        occurrences, order, largs = parser.parse(args)
        chunks, extras = _unpack_args(largs, [a.nargs for a in arguments])
        argvals = {}
        for arg, chunk in zip(arguments, chunks):
            if not chunk:
                argvals[arg] = UNSET
            elif arg.nargs != -1 and len(chunk) != arg.nargs:
                raise BadArgumentUsage(
                    f"Argument {arg.name.upper()!r} takes {arg.nargs} values.", ctx
                )
            else:
                argvals[arg] = chunk
        for index, param in _processing_order(params, order):
            if param.is_option:
                raw = occurrences.get(param, UNSET)
            else:
                raw = argvals[param]
            param.handle_parse_result(ctx, raw, index)
        return extras

    # -- invocation ------------------------------------------------------------
    def invoke(self, ctx):
        if self.deprecated:
            message = f"DeprecationWarning: The command {ctx.command_path or self.name!r} is deprecated."
            if self.deprecation_note:
                message += f" {self.deprecation_note}"
            echo(message)
        if self.callback is None:
            return None
        return ctx.invoke(self.callback, **ctx.params)

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True,
             windows_expand_args=True, **extra):
        """Run as a program (FP-01, FP-13)."""
        args = sys.argv[1:] if args is None else list(args)
        if prog_name is None:
            prog_name = _default_prog_name()
        if complete_var is None:
            complete_var = _complete_var_name(prog_name)
        instruction = os.environ.get(complete_var)
        if instruction:
            from ._completion import run_completion

            status = run_completion(self, prog_name, instruction)
            if standalone_mode:
                sys.exit(status)
            return None

        try:
            try:
                with self.make_context(prog_name, args, **extra) as ctx:
                    rv = self.invoke(ctx)
                    if not standalone_mode:
                        return rv
                    ctx.exit()
            except (EOFError, KeyboardInterrupt) as e:
                echo(file=sys.stderr)
                raise Abort() from e
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return e.exit_code
        except Abort:
            if not standalone_mode:
                raise
            echo("Aborted!", file=sys.stderr)
            sys.exit(1)
        except OptlynError as e:
            if not standalone_mode:
                raise
            e.show()
            sys.exit(e.exit_code)

    # -- help ----------------------------------------------------------------------
    def collect_usage_pieces(self, ctx) -> list:
        params = self.get_params(ctx)
        rv = []
        if self.options_metavar and any(p.is_option for p in params):
            rv.append(self.options_metavar)
        for param in params:
            if not param.is_option:
                rv.extend(param.usage_pieces())
        return rv

    def format_usage(self, ctx, formatter) -> None:
        formatter.write_usage(ctx.command_path, " ".join(self.collect_usage_pieces(ctx)))

    def format_help_text(self, ctx, formatter) -> None:
        text = self.help or ""
        if self.deprecated:
            mark = "(Deprecated)" + (f" {self.deprecation_note}" if self.deprecation_note else "")
            text = f"{mark} {text}".strip()
        if text:
            formatter.write_paragraph()
            formatter.write_text(text)

    def format_arguments(self, ctx, formatter) -> None:
        rows = [r for r in (p.get_help_record(ctx) for p in self.get_params(ctx) if not p.is_option) if r]
        if rows:
            with formatter.section("Positional arguments"):
                formatter.write_dl(rows)

    def format_options(self, ctx, formatter) -> None:
        rows = []
        for param in self.get_params(ctx):
            if param.is_option:
                record = param.get_help_record(ctx)
                if record:
                    rows.append(record)
        if rows:
            with formatter.section("Options"):
                formatter.write_dl(rows)

    def format_commands(self, ctx, formatter) -> None:
        pass

    def format_epilog(self, ctx, formatter) -> None:
        if self.epilog:
            formatter.write_paragraph()
            formatter.write_text(self.epilog)

    def format_help(self, ctx, formatter) -> None:
        self.format_usage(ctx, formatter)
        self.format_help_text(ctx, formatter)
        self.format_arguments(ctx, formatter)
        self.format_options(ctx, formatter)
        self.format_commands(ctx, formatter)
        self.format_epilog(ctx, formatter)

    def get_help(self, ctx) -> str:
        formatter = ctx.make_formatter()
        self.format_help(ctx, formatter)
        return formatter.getvalue().rstrip("\n")

    def get_usage(self, ctx) -> str:
        formatter = ctx.make_formatter()
        self.format_usage(ctx, formatter)
        return formatter.getvalue().rstrip("\n")

    def get_short_help_str(self, limit: int = 45) -> str:
        if self.short_help is not None:
            return ellipsize(" ".join(self.short_help.split()), limit)
        return make_default_short_help(self.help or "", limit)


def _default_prog_name() -> str:
    if sys.argv and sys.argv[0]:
        return os.path.basename(sys.argv[0])
    return "main"


def _complete_var_name(prog_name: str) -> str:
    return "_" + prog_name.upper().replace("-", "_") + "_COMPLETE"


class Group(Command):
    """A command that dispatches to named subcommands (FP-06, FP-10)."""

    _dispatches = True
    allow_extra_args = True
    allow_interspersed_args = False

    def __init__(self, name=None, commands=None, invoke_without_command=False,
                 no_args_is_help=None, subcommand_metavar=None, chain=False,
                 result_callback=None, **kwargs) -> None:
        super().__init__(name, **kwargs)
        if commands is None:
            self.commands = {}
        elif isinstance(commands, dict):
            self.commands = dict(commands)
        else:
            self.commands = {c.name: c for c in commands}
        self.invoke_without_command = invoke_without_command
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        self.no_args_is_help = no_args_is_help
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback
        if chain:
            self.allow_interspersed_args = False

    def add_command(self, cmd, name=None) -> None:
        name = name or cmd.name
        if name is None:
            raise TypeError("A command needs a name to be added to a group.")
        if self.chain and isinstance(cmd, Group):
            raise TypeError("Groups cannot be nested beneath a chaining group.")
        self.commands[name] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as command_decorator

        def decorator(f):
            cmd = command_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as group_decorator

        def decorator(f):
            cmd = group_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self):
        def decorator(f):
            self._result_callback = f
            return f

        return decorator

    def list_commands(self, ctx) -> list:
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        return self.commands.get(cmd_name)

    def collect_usage_pieces(self, ctx) -> list:
        rv = super().collect_usage_pieces(ctx)
        name = self.subcommand_metavar or "COMMAND"
        if self.chain:
            rv.append(name)
            rv.append("[ARGS]...")
            rv.append(f"[{name} [ARGS]...]...")
        elif self.invoke_without_command:
            rv.append(f"[{name}]")
            rv.append("[ARGS]...")
        else:
            rv.append(name)
            rv.append("[ARGS]...")
        return rv

    def format_commands(self, ctx, formatter) -> None:
        names = [n for n in self.list_commands(ctx)]
        entries = []
        for name in names:
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            entries.append((name, cmd))
        if not entries:
            return
        first_col = min(max(len(n) for n, _ in entries), 30) + 2
        limit = max(formatter.width - first_col - 2 - formatter.current_indent, 10)
        rows = [(name, cmd.get_short_help_str(limit)) for name, cmd in entries]
        with formatter.section("Commands"):
            formatter.write_dl(rows)

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsIsHelp(ctx=ctx, message="Missing command.")
        extras = self._parse(ctx, args, dispatch=True)
        tokens = [tok for tok, _ in extras]
        ctx.protected_args = tokens[:1]
        ctx.args = tokens[1:]

    def resolve_command(self, ctx, args):
        cmd_name = args[0]
        lookup_name = ctx.token_normalize_func(cmd_name) if ctx.token_normalize_func else cmd_name
        cmd = self.get_command(ctx, lookup_name)
        if cmd is None and not ctx.resilient_parsing:
            raise NoSuchCommand(cmd_name, ctx=ctx)
        return cmd_name, cmd, args[1:]

    def invoke(self, ctx):
        def process_result(value):
            if self._result_callback is not None:
                return ctx.invoke(self._result_callback, value, **ctx.params)
            return value

        if not ctx.protected_args:
            if self.invoke_without_command:
                with ctx:
                    rv = super().invoke(ctx)
                    return process_result([] if self.chain else rv)
            raise UsageError("Missing command.", ctx)

        args = [*ctx.protected_args, *ctx.args]
        ctx.args = []
        ctx.protected_args = []

        if not self.chain:
            with ctx:
                cmd_name, cmd, args = self.resolve_command(ctx, args)
                ctx.invoked_subcommand = cmd_name
                super().invoke(ctx)
                sub_ctx = cmd.make_context(cmd_name, args, parent=ctx)
                with sub_ctx:
                    return process_result(sub_ctx.command.invoke(sub_ctx))

        with ctx:
            ctx.invoked_subcommand = "*" if args else None
            super().invoke(ctx)
            contexts = []
            while args:
                cmd_name, cmd, args = self.resolve_command(ctx, args)
                sub_ctx = cmd.make_context(cmd_name, args, parent=ctx, _passthrough=True)
                contexts.append(sub_ctx)
                args, sub_ctx.args = sub_ctx.args, []
            rv = []
            for sub_ctx in contexts:
                with sub_ctx:
                    rv.append(sub_ctx.command.invoke(sub_ctx))
            process_result(rv)
            return rv


class CommandCollection(Group):
    """Presents the subcommands of several groups under one dispatch surface (FP-06)."""

    def __init__(self, name=None, sources=None, **kwargs) -> None:
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx) -> list:
        names = set(self.commands)
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None
