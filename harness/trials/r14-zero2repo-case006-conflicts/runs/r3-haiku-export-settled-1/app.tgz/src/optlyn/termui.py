"""Terminal helpers: echo, styling, prompts, pager, progress, editor (FP-08, FP-11)."""

from __future__ import annotations

import contextlib
import getpass
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import time

from ._state import get_current_context
from .exceptions import Abort, BadParameter

_ANSI_RE = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")

_FG_COLORS = {
    "black": 30, "red": 31, "green": 32, "yellow": 33,
    "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
    "reset": 39,
}
_BG_COLORS = {name: (code + 10 if code < 90 else code + 10) for name, code in _FG_COLORS.items()}
_BG_COLORS["reset"] = 49


def _isatty(stream) -> bool:
    try:
        return bool(stream is not None and stream.isatty())
    except (AttributeError, ValueError):
        return False


def is_interactive() -> bool:
    """Standard input or standard output is a terminal (FP-11 glossary)."""
    return _isatty(sys.stdin) or _isatty(sys.stdout)


def strip_ansi(text: str) -> str:
    return _ANSI_RE.sub("", text)


def unstyle(text: str) -> str:
    return strip_ansi(text)


def _should_strip(stream, color) -> bool:
    if color is None:
        ctx = get_current_context(silent=True)
        if ctx is not None:
            color = ctx.color
    if color is None:
        return not _isatty(stream)
    return not color


def _write_bytes(file, data: bytes) -> None:
    buf = getattr(file, "buffer", None)
    if buf is not None:
        file.flush()
        buf.write(data)
        buf.flush()
    else:
        file.write(data.decode("utf-8", "replace"))


def _write_text(file, text: str) -> None:
    try:
        file.write(text)
    except UnicodeEncodeError:
        # ASCII-only encodings: fall back to UTF-8 bytes instead of failing (FP-11).
        _write_bytes(file, text.encode("utf-8"))
    try:
        file.flush()
    except (OSError, ValueError):
        pass


def echo(message=None, file=None, nl: bool = True, err: bool = False, color=None) -> None:
    """Write text or bytes to standard output (or error), stripping styles off-terminal."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, (bytes, bytearray)):
        data = bytes(message) + (b"\n" if nl else b"")
        _write_bytes(file, data)
        return
    message = str(message)
    if nl:
        message += "\n"
    if _should_strip(file, color):
        message = strip_ansi(message)
    _write_text(file, message)


def _color_code(color, background: bool) -> str:
    table = _BG_COLORS if background else _FG_COLORS
    if isinstance(color, str):
        if color not in table:
            raise ValueError(f"Unknown color {color!r}.")
        return str(table[color])
    base = "48" if background else "38"
    if isinstance(color, int) and not isinstance(color, bool):
        if 0 <= color <= 255:
            return f"{base};5;{color}"
        raise ValueError(f"Color index {color} is outside 0-255.")
    if isinstance(color, (tuple, list)) and len(color) == 3 and all(
        isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
    ):
        return f"{base};2;{color[0]};{color[1]};{color[2]}"
    raise ValueError(f"Invalid color {color!r}.")


def style(
    text,
    fg=None,
    bg=None,
    bold=None,
    dim=None,
    underline=None,
    overline=None,
    italic=None,
    blink=None,
    reverse=None,
    strikethrough=None,
    reset: bool = True,
) -> str:
    """Wrap text in ANSI SGR sequences (FP-11). Invalid colors raise ValueError."""
    bits = []
    if fg is not None:
        bits.append(_color_code(fg, False))
    if bg is not None:
        bits.append(_color_code(bg, True))
    for flag, code in (
        (bold, 1), (dim, 2), (italic, 3), (underline, 4), (blink, 5),
        (reverse, 7), (strikethrough, 9), (overline, 53),
    ):
        if flag:
            bits.append(str(code))
    text = str(text)
    if not bits:
        return text
    prefix = f"\033[{';'.join(bits)}m"
    return f"{prefix}{text}" + ("\033[0m" if reset else "")


def secho(message=None, file=None, nl: bool = True, err: bool = False, color=None, **styles) -> None:
    if message is not None:
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


def _read_line(stream, hide_input: bool) -> str:
    """Read one line of input for a prompt; EOF raises EOFError."""
    if hide_input and _isatty(stream):
        try:
            return getpass.getpass("")
        except EOFError:
            raise
    custom = getattr(stream, "_optlyn_prompt_line", None)
    if custom is not None:
        line = custom(hide_input)
    else:
        line = stream.readline()
    if line == "" or line is None:
        raise EOFError
    return line.rstrip("\r\n")


def _prompt_line(text: str, hide_input: bool = False, err: bool = False) -> str:
    echo(text, nl=False, err=err)
    stream = sys.stdin
    try:
        line = _read_line(stream, hide_input)
    except EOFError:
        echo("", err=err)
        raise Abort()
    if not hide_input and not _isatty(stream) and not getattr(stream, "_optlyn_echoes", False):
        echo(line, err=err)
    return line


def prompt(
    text,
    default=None,
    hide_input: bool = False,
    confirmation_prompt: bool = False,
    type=None,
    value_proc=None,
    prompt_suffix: str = ": ",
    show_default: bool = True,
    err: bool = False,
    show_choices: bool = True,
):
    """Ask for a value and return it converted; re-asks on conversion failure (FP-08)."""
    from .paramtypes import convert_type

    if callable(default):
        default = default()
    ptype = convert_type(type, default) if (type is not None or value_proc is None) else None
    shown = ""
    if default is not None and show_default:
        shown = f" [{'' if hide_input else default}]" if not hide_input else " [******]"

    def proc(raw):
        if value_proc is not None:
            return value_proc(raw)
        return ptype.convert(raw, None, None)

    while True:
        value = _prompt_line(f"{text}{shown}{prompt_suffix}", hide_input, err)
        if value == "":
            if default is None:
                continue
            value = default
        if confirmation_prompt:
            second = _prompt_line(f"Repeat for confirmation{prompt_suffix}", hide_input, err)
            if second != value:
                echo("Error: The two entered values do not match.", err=True)
                continue
        try:
            return proc(value)
        except BadParameter as e:
            echo(f"Error: {e.message}", err=True)


def confirm(text, default: bool = False, abort: bool = False, prompt_suffix: str = ": ",
            show_default: bool = True, err: bool = False) -> bool:
    """Yes/no question; an answer other than yes/no/empty counts as no (FP-08, CF-000151)."""
    if show_default:
        text = f"{text} [{'Y/n' if default else 'y/N'}]"
    answer = _prompt_line(f"{text}{prompt_suffix}", False, err).strip().lower()
    if answer == "":
        result = default
    elif answer in ("y", "yes"):
        result = True
    else:
        result = False
    if abort and not result:
        raise Abort()
    return result


def _open_terminal():
    try:
        return os.open("/dev/tty", os.O_RDONLY)
    except OSError:
        return None


def getchar(echo: bool = False) -> str:
    """Read one character; interrupt raises KeyboardInterrupt, end-of-file raises EOFError (FP-11)."""
    ch = ""
    fd = None
    try:
        import termios
        import tty
    except ImportError:
        termios = tty = None

    if termios is not None:
        if _isatty(sys.stdin):
            fd = sys.stdin.fileno()
        else:
            fd = _open_terminal()
        if fd is not None and os.isatty(fd):
            old = termios.tcgetattr(fd)
            try:
                tty.setraw(fd)
                ch = os.read(fd, 1).decode("utf-8", "replace")
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
            if not _isatty(sys.stdin) and fd is not None:
                os.close(fd)
        else:
            if fd is not None and not _isatty(sys.stdin):
                os.close(fd)
            fd = None
    if fd is None and ch == "":
        ch = sys.stdin.read(1)
    if ch == "":
        raise EOFError
    if ch == "\x03":
        raise KeyboardInterrupt
    if ch == "\x04":
        raise EOFError
    if echo:
        _write_text(sys.stdout, ch)
    return ch


def pause(info=None, err: bool = False) -> None:
    """Wait for a key when the session is interactive; otherwise return at once (FP-11)."""
    if not is_interactive():
        return
    echo(info if info is not None else "Press any key to continue...", err=err)
    try:
        getchar()
    except (EOFError, KeyboardInterrupt):
        pass
    echo("", err=err)


class _PagerWriter:
    """Writes chunks to the destination, flushing after each one."""

    def __init__(self, sink, strip: bool) -> None:
        self._sink = sink
        self._strip = strip

    def write(self, text: str) -> None:
        if self._strip:
            text = strip_ansi(text)
        _write_text(self._sink, text)

    def flush(self) -> None:
        try:
            self._sink.flush()
        except (OSError, ValueError):
            pass


@contextlib.contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream that goes through the pager when interactive (FP-11)."""
    strip = _should_strip(sys.stdout, color)
    pager_cmd = os.environ.get("PAGER")
    if not is_interactive() or not pager_cmd:
        yield _PagerWriter(sys.stdout, strip)
        return
    proc = subprocess.Popen(pager_cmd, shell=True, stdin=subprocess.PIPE)
    sink = io_text(proc.stdin)
    try:
        yield _PagerWriter(sink, strip)
    finally:
        try:
            sink.close()
        except (OSError, ValueError):
            pass
        proc.wait()


def io_text(binary):
    import io

    return io.TextIOWrapper(binary, encoding="utf-8", errors="replace", write_through=True)


def echo_via_pager(text_or_generator, color=None) -> None:
    """Show long text through the pager when interactive, else write it directly."""
    if callable(text_or_generator) and not isinstance(text_or_generator, str):
        chunks = text_or_generator()
    else:
        chunks = text_or_generator
    if isinstance(chunks, str):
        chunks = [chunks]
    with get_pager_file(color) as writer:
        for chunk in chunks:
            writer.write(chunk)
            writer.flush()


class ProgressBar:
    """Wraps an iterable or a length; visits every item (FP-11)."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, **options) -> None:
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label
        self.pos = 0
        self.start = time.time()
        self.is_hidden = bool(hidden) or not _isatty(sys.stdout)
        self._hidden_explicitly = bool(hidden)
        self.options = options

    def __enter__(self):
        self.start = time.time()
        if self.label and not self._hidden_explicitly and self.is_hidden:
            echo(self.label)
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if not self.is_hidden:
            echo("")

    def __iter__(self):
        if self.iterable is None:
            return
        for item in self.iterable:
            yield item
            self.update(1)

    def update(self, n_steps: int = 1) -> None:
        self.pos += n_steps
        if self.is_hidden:
            return
        label = f"{self.label}  " if self.label else ""
        if self.length:
            frac = min(self.pos / self.length, 1.0)
            filled = int(frac * 36)
            bar = "#" * filled + "-" * (36 - filled)
            elapsed = time.time() - self.start
            eta = (elapsed / self.pos) * (self.length - self.pos) if self.pos else 0
            text = f"\r{label}[{bar}]  {self.pos}/{self.length}  eta {int(eta)}s"
        else:
            text = f"\r{label}{self.pos}"
        _write_text(sys.stdout, text)


def progressbar(iterable=None, length=None, label=None, hidden=False, **options) -> ProgressBar:
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)


def edit(text=None, editor=None, env=None, require_save: bool = True,
         extension: str = ".txt", filename=None):
    """Run an editor on text or a file; returns the saved text or None (FP-11)."""
    editor_cmd = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR")
    if not editor_cmd:
        editor_cmd = "notepad" if sys.platform.startswith("win") else "vi"
    run_env = dict(os.environ)
    run_env.update(env or {})

    if filename is not None:
        _run_editor(editor_cmd, os.fspath(filename), run_env)
        return None

    original = (text or "").replace("\r\n", "\n")
    fd, path = tempfile.mkstemp(prefix="optlyn-edit-", suffix=extension)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(original.encode("utf-8"))
        _run_editor(editor_cmd, path, run_env)
        with open(path, "rb") as handle:
            saved = handle.read().decode("utf-8", "replace").replace("\r\n", "\n")
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass
    if require_save and saved == original:
        return None
    return saved


def _run_editor(editor_cmd: str, path: str, env) -> None:
    subprocess.call(f"{editor_cmd} {shlex.quote(path)}", shell=True, env=env)


def launch(url, wait: bool = False, locate: bool = False) -> int:
    """Open a URL or file with the default application; returns a status (FP-11)."""
    target = os.fspath(url) if hasattr(url, "__fspath__") else str(url)
    if sys.platform.startswith("win"):
        os.startfile(target)  # noqa: S606 - platform API
        return 0
    if sys.platform == "darwin":
        cmd = ["open", "-R", target] if locate else ["open", target]
    else:
        opener = shutil.which("xdg-open")
        if opener is None:
            return 127
        if locate:
            target = os.path.dirname(os.path.abspath(target))
        cmd = [opener, target]
    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0


def clear() -> None:
    """Clear the terminal; does nothing when stdout is not a terminal (FP-11)."""
    if not _isatty(sys.stdout):
        return
    _write_text(sys.stdout, "\033[2J\033[1;1H")
