"""Text wrapping and the help-page formatter (FP-02, FP-11)."""

from __future__ import annotations

import contextlib
import re
import textwrap

_ANSI_RE = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")


def term_len(text: str) -> int:
    return len(_ANSI_RE.sub("", text))


def wrap_text(
    text,
    width: int = 78,
    initial_indent: str = "",
    subsequent_indent: str = "",
    preserve_paragraphs: bool = False,
) -> str:
    """Wrap `text` to `width`; never fails on any string (FP-11).

    With `preserve_paragraphs`, blank lines separate paragraphs; a paragraph whose
    first line is a lone backspace is not rewrapped (FP-02).
    """
    width = max(int(width), 1)
    text = str(text)

    if not preserve_paragraphs:
        wrapper = textwrap.TextWrapper(
            width,
            initial_indent=initial_indent,
            subsequent_indent=subsequent_indent,
            replace_whitespace=False,
            break_long_words=True,
            break_on_hyphens=False,
        )
        return wrapper.fill(" ".join(text.split()))

    wrapper = textwrap.TextWrapper(
        width,
        initial_indent=initial_indent,
        subsequent_indent=subsequent_indent,
        replace_whitespace=False,
        break_long_words=True,
        break_on_hyphens=False,
    )
    out = []
    for para in re.split(r"\n\s*\n", text.strip("\n")):
        lines = para.splitlines()
        if not lines:
            continue
        if lines[0].strip("\b") == "" and lines[0] != "":
            # Backspace marker: keep the author's line breaks, drop the marker line.
            body = [ln for ln in lines[1:]]
            out.append("\n".join(initial_indent + ln for ln in body))
            continue
        out.append(wrapper.fill(" ".join(line.strip() for line in lines)))
    return "\n\n".join(out)


class HelpFormatter:
    """Accumulates help text with indentation and two-column definition lists."""

    def __init__(self, indent_increment: int = 2, width: int = 80) -> None:
        self.indent_increment = indent_increment
        self.width = max(int(width), 1)
        self.current_indent = 0
        self.buffer: list[str] = []

    def write(self, string: str) -> None:
        self.buffer.append(string)

    def indent(self) -> None:
        self.current_indent += self.indent_increment

    def dedent(self) -> None:
        self.current_indent -= self.indent_increment

    def write_usage(self, prog: str, args: str = "", prefix: str = "Usage: ") -> None:
        usage_prefix = f"{prefix}{prog} "
        text_width = self.width - len(usage_prefix)
        if term_len(usage_prefix + args) <= self.width:
            self.write(f"{usage_prefix}{args}\n")
            return
        indent = " " * len(usage_prefix)
        wrapped = wrap_text(args, max(text_width, 10), preserve_paragraphs=False)
        lines = wrapped.splitlines() or [""]
        self.write(f"{usage_prefix}{lines[0]}\n")
        for line in lines[1:]:
            self.write(f"{indent}{line}\n")

    def write_heading(self, heading: str) -> None:
        self.write(f"{'':>{self.current_indent}}{heading}:\n")

    def write_paragraph(self) -> None:
        if self.buffer:
            self.write("\n")

    def write_text(self, text: str) -> None:
        indent = " " * self.current_indent
        wrapped = wrap_text(
            text,
            max(self.width - self.current_indent, 10),
            initial_indent=indent,
            subsequent_indent=indent,
            preserve_paragraphs=True,
        )
        self.write(wrapped)
        self.write("\n")

    def write_dl(self, rows, col_max: int = 30, col_spacing: int = 2) -> None:
        rows = [(str(a), "" if b is None else str(b)) for a, b in rows]
        if not rows:
            return
        first_col = min(max(term_len(a) for a, _ in rows), col_max) + col_spacing
        for first, second in rows:
            self.write(f"{'':>{self.current_indent}}{first}")
            if not second:
                self.write("\n")
                continue
            if term_len(first) <= first_col - col_spacing:
                self.write(" " * (first_col - term_len(first)))
            else:
                self.write("\n")
                self.write(" " * (first_col + self.current_indent))
            text_width = max(self.width - first_col - 2, 10)
            lines = wrap_text(second, text_width, preserve_paragraphs=True).splitlines()
            if lines:
                self.write(f"{lines[0]}\n")
                for line in lines[1:]:
                    self.write(f"{'':>{first_col + self.current_indent}}{line}\n")
            else:
                self.write("\n")

    @contextlib.contextmanager
    def section(self, name: str):
        self.write_paragraph()
        self.write_heading(name)
        self.indent()
        try:
            yield
        finally:
            self.dedent()

    @contextlib.contextmanager
    def indentation(self):
        self.indent()
        try:
            yield
        finally:
            self.dedent()

    def getvalue(self) -> str:
        return "".join(self.buffer)


def make_default_short_help(help_text: str, max_length: int) -> str:
    """First sentence of the first paragraph, ellipsized to `max_length` (FP-02)."""
    first_para = (help_text or "").strip().split("\n\n")[0]
    flat = " ".join(first_para.split())
    match = re.match(r"(.*?[.!?])(\s|$)", flat)
    sentence = match.group(1) if match else flat
    return ellipsize(sentence, max_length)


def ellipsize(text: str, limit: int) -> str:
    if limit is None or len(text) <= limit:
        return text
    if limit <= 3:
        return text[:limit]
    return text[: limit - 3].rstrip() + "..."
