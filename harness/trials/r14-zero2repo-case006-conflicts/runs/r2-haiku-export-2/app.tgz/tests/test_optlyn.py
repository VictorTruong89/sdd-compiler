"""Behaviour tests for Optlyn, run against the in-process runner."""

from __future__ import annotations

import enum
import os

import pytest

from optlyn import Abort
from optlyn import Argument
from optlyn import Choice
from optlyn import Context
from optlyn import DateTime
from optlyn import FloatRange
from optlyn import IntRange
from optlyn import ParamType
from optlyn import Tuple
from optlyn import UsageError
from optlyn import UUID
from optlyn import argument
from optlyn import command
from optlyn import confirmation_option
from optlyn import custom_version_option
from optlyn import echo
from optlyn import get_current_context
from optlyn import group
from optlyn import option
from optlyn import pass_context
from optlyn import pass_obj
from optlyn import secho
from optlyn import style
from optlyn import unstyle
from optlyn import version_option
from optlyn.formatting import wrap_text
from optlyn.testing import CliRunner


@pytest.fixture
def runner():
    return CliRunner()


def test_AC_name_derivation_strips_suffix(runner):
    @command()
    def sync_cmd():
        echo("ok")

    assert sync_cmd.name == "sync"
    assert runner.invoke(sync_cmd, []).output == "ok\n"


def test_AC_missing_argument_is_usage_error(runner):
    @command()
    @argument("name")
    def hello(name):
        echo(name)

    res = runner.invoke(hello, [])
    assert res.exit_code == 2
    assert "Missing argument 'NAME'." in res.output


def test_AC_bad_value_names_parameter(runner):
    @command()
    @option("--count", type=int)
    def cmd(count):
        echo(count)

    res = runner.invoke(cmd, ["--count", "x"])
    assert res.exit_code == 2
    assert "'--count'" in res.output
    assert "not a valid integer" in res.output


def test_AC_help_does_not_run_callback(runner):
    ran = []

    @command()
    def cmd():
        ran.append(True)

    res = runner.invoke(cmd, ["--help"])
    assert res.exit_code == 0
    assert ran == []
    assert res.output.startswith("Usage: cmd [OPTIONS]")


def test_AC_group_without_subcommand_is_usage_failure(runner):
    @group()
    def cli():
        pass

    res = runner.invoke(cli, [])
    assert res.exit_code == 2
    assert res.output.startswith("Usage: cli [OPTIONS] COMMAND [ARGS]...")


def test_AC_group_callback_runs_before_child(runner):
    @group()
    def cli():
        echo("group")

    @cli.command()
    def child():
        echo("child")

    res = runner.invoke(cli, ["child"])
    assert res.output == "group\nchild\n"


def test_AC_unknown_subcommand(runner):
    @group()
    def cli():
        pass

    res = runner.invoke(cli, ["nope"])
    assert res.exit_code == 2
    assert "No such command 'nope'." in res.output


def test_AC_flags_and_counting(runner):
    @command()
    @option("-v", "--verbose", count=True)
    @option("-a", is_flag=True)
    @option("-c", type=str)
    def cmd(verbose, a, c):
        echo(f"{verbose} {a} {c}")

    assert runner.invoke(cmd, ["-vvac", "x"]).output == "2 True x\n"


def test_AC_flag_default_true_yields_true_when_present(runner):
    @command()
    @option("--a", is_flag=True, default=True)
    def cmd(a):
        echo(a)

    assert runner.invoke(cmd, ["--a"]).output == "True\n"


def test_AC_multiple_and_tuple_arity(runner):
    @command()
    @option("--pair", nargs=2, type=int, multiple=True)
    def cmd(pair):
        echo(repr(pair))

    assert runner.invoke(cmd, ["--pair", "1", "2", "--pair", "3", "4"]).output == "((1, 2), (3, 4))\n"


def test_AC_variadic_argument(runner):
    @command()
    @argument("files", nargs=-1)
    @argument("dest")
    def cmd(files, dest):
        echo(f"{files} {dest}")

    assert runner.invoke(cmd, ["a", "b", "c"]).output == "('a', 'b') c\n"


def test_AC_choice_and_enum(runner):
    class Color(enum.Enum):
        red = 1
        green = 2

    @command()
    @option("--c", type=Choice(Color, case_sensitive=False), default=Color.red)
    def cmd(c):
        echo(repr(c))

    assert runner.invoke(cmd, ["--c", "GREEN"]).output == "<Color.green: 2>\n"
    assert runner.invoke(cmd, ["--c", "blue"]).exit_code == 2


def test_AC_ranges_clamp(runner):
    @command()
    @option("--n", type=FloatRange(0.5, 2.0, clamp=True))
    @option("--r", type=IntRange(1, 5, min_open=True, clamp=True))
    def cmd(n, r):
        echo(f"{n} {r}")

    assert runner.invoke(cmd, ["--n", "9", "--r", "1"]).output == "2.0 2\n"


def test_AC_float_range_open_clamp_refused():
    with pytest.raises(ValueError):
        FloatRange(0, 1, min_open=True, clamp=True)


def test_AC_datetime_and_uuid(runner):
    @command()
    @option("--when", type=DateTime())
    @option("--id", type=UUID)
    def cmd(when, id):
        echo(f"{when.year} {id}")

    res = runner.invoke(cmd, ["--when", "2020-01-02", "--id", "12345678123456781234567812345678"])
    assert res.output == "2020 12345678-1234-5678-1234-567812345678\n"


def test_AC_custom_param_type(runner):
    class Upper(ParamType):
        name = "upper"

        def convert(self, value, param, ctx):
            if isinstance(value, str) and value.isupper():
                return value
            self.fail(f"{value!r} must be upper", param, ctx)

    @command()
    @argument("u", type=Upper())
    def cmd(u):
        echo(u)

    assert runner.invoke(cmd, ["ABC"]).output == "ABC\n"
    assert runner.invoke(cmd, ["abc"]).exit_code == 2


def test_AC_tuple_type(runner):
    @command()
    @option("--t", type=Tuple([int, str]))
    def cmd(t):
        echo(repr(t))

    assert runner.invoke(cmd, ["--t", "1", "x"]).output == "(1, 'x')\n"


def test_AC_envvar_and_default_map_precedence(runner):
    @command()
    @option("--port", envvar="PORT", default=80, type=int)
    def cmd(port):
        echo(port)

    assert runner.invoke(cmd, [], env={"PORT": "81"}).output == "81\n"
    assert runner.invoke(cmd, [], default_map={"port": 7}, env={"PORT": "81"}).output == "81\n"
    assert runner.invoke(cmd, ["--port", "9"], default_map={"port": 7}).output == "9\n"


def test_AC_auto_envvar_prefix(runner):
    @command()
    @option("--host", default="localhost")
    def serve(host):
        echo(host)

    res = runner.invoke(serve, [], auto_envvar_prefix="APP", env={"APP_HOST": "h"})
    assert res.output == "h\n"


def test_AC_parameter_source(runner):
    @command()
    @option("--x", default="d")
    @pass_context
    def cmd(ctx, x):
        echo(repr(ctx.get_parameter_source("x")))
        echo(repr(ctx.get_parameter_source("nope")))

    out = runner.invoke(cmd, ["--x", "v"]).output.splitlines()
    assert out == ["<ParameterSource.COMMANDLINE: 'commandline'>", "None"]


def test_AC_confirmation_option(runner):
    @command()
    @confirmation_option(prompt="Sure?")
    def cmd():
        echo("done")

    assert runner.invoke(cmd, [], input="n\n").exit_code == 1
    assert runner.invoke(cmd, [], input="y\n").output == "Sure? [y/N]: y\ndone\n"
    assert runner.invoke(cmd, ["--yes"]).output == "done\n"


def test_AC_prompt_reasks_and_eof_aborts(runner):
    @command()
    @option("--name", prompt=True)
    def cmd(name):
        echo(name)

    assert runner.invoke(cmd, [], input="bob\n").output == "Name: bob\nbob\n"
    res = runner.invoke(cmd, [], input="")
    assert res.exit_code == 1
    assert "Aborted!" in res.output


def test_AC_version_and_custom_version(runner):
    @command()
    @version_option(version="1.2.3", prog_name="tool")
    def v():
        pass

    @command()
    @custom_version_option(lambda ctx: "custom " + ctx.info_name)
    def cv():
        pass

    assert runner.invoke(v, ["--version"]).output == "tool, version 1.2.3\n"
    assert runner.invoke(cv, ["--version"], prog_name="cvx").output == "custom cvx\n"


def test_AC_chain_with_result_callback(runner):
    @group(chain=True)
    def pipe():
        pass

    @pipe.command("up")
    @argument("s")
    def up(s):
        return s.upper()

    @pipe.command("rev")
    @argument("s")
    def rev(s):
        return s[::-1]

    @pipe.result_callback()
    def done(results):
        echo(repr(results))

    assert runner.invoke(pipe, ["up", "abc", "rev", "xyz"]).output == "['ABC', 'zyx']\n"


def test_AC_pass_obj_and_find_object(runner):
    class Obj:
        def __init__(self):
            self.v = 0

    @group()
    @pass_context
    def root(ctx):
        ctx.obj = Obj()

    @root.command()
    @pass_obj
    def inc(obj):
        obj.v += 1
        echo(obj.v)

    assert runner.invoke(root, ["inc"]).output == "1\n"


def test_AC_deprecated_command_warns_and_runs(runner):
    @command(deprecated=True)
    def old():
        echo("ran")

    res = runner.invoke(old, [])
    assert res.exit_code == 0
    assert "DeprecationWarning" in res.stderr
    assert res.stdout == "ran\n"


def test_AC_deprecated_option_and_argument_declaration_refused():
    with pytest.raises(TypeError):
        option("--x", deprecated=True, required=True)(lambda x: None)
    with pytest.raises(TypeError):
        Argument(["x"], deprecated=True)


def test_AC_standalone_off_propagates_usage_error():
    @command()
    @option("--x", type=int)
    def cmd(x):
        return x * 2

    assert cmd.main(["--x", "4"], standalone_mode=False, prog_name="cmd") == 8
    with pytest.raises(UsageError):
        cmd.main(["--x", "bad"], standalone_mode=False, prog_name="cmd")


def test_AC_exit_status_and_abort(runner):
    @command()
    def stop():
        echo("before")
        get_current_context().exit(3)
        echo("after")

    @command()
    def boom():
        raise Abort()

    res = runner.invoke(stop, [])
    assert res.exit_code == 3
    assert res.output == "before\n"
    assert runner.invoke(boom, []).exit_code == 1


def test_AC_ignore_unknown_options_leaves_stack_remainder(runner):
    @command(context_settings={"ignore_unknown_options": True})
    @option("-a", is_flag=True)
    @argument("rest", nargs=-1)
    def cmd(a, rest):
        echo(f"{a} {rest}")

    assert runner.invoke(cmd, ["-abz", "x"]).output == "True ('-bz', 'x')\n"


def test_AC_help_text_form_feed_and_backspace(runner):
    @command()
    def fmt():
        """Summary.\f
        secret
        """

    assert "secret" not in runner.invoke(fmt, ["--help"]).output
    assert "Summary." in runner.invoke(fmt, ["--help"]).output


def test_AC_style_and_unstyle():
    assert unstyle(style("x", fg="red")) == "x"
    with pytest.raises(ValueError):
        style("x", fg="nope")


def test_AC_echo_strips_styles_when_not_a_terminal(runner):
    @command()
    def col():
        secho("hi", fg="green")

    assert runner.invoke(col, []).output == "hi\n"
    assert runner.invoke(col, [], color=True).output == "\x1b[32mhi\x1b[0m\n"


def test_AC_wrap_text_is_total():
    assert wrap_text("a b c " * 30, 20).count("\n") >= 1
    assert wrap_text("", 20) == ""


def test_AC_file_argument_round_trip(runner):
    from optlyn import File

    @command()
    @argument("src", type=File("r"))
    def cp(src):
        echo(src.read().upper(), nl=False)

    with runner.isolated_filesystem():
        with open("in.txt", "w") as f:
            f.write("hello\n")
        assert runner.invoke(cp, ["in.txt"]).output == "HELLO\n"
        assert runner.invoke(cp, ["-"], input="piped\n").output == "PIPED\n"
        res = runner.invoke(cp, ["missing.txt"])
        assert res.exit_code == 2
        assert "missing.txt" in res.output


def test_AC_completion_bash_suggests_choices(runner):
    @command()
    @option("--color", type=Choice(["alpha", "beta"]))
    def comp():
        pass

    res = runner.invoke(
        comp,
        [],
        env={
            "_COMP_COMPLETE": "bash_complete",
            "COMP_WORDS": "comp --color ",
            "COMP_CWORD": "2",
        },
        prog_name="comp",
    )
    assert res.output == "plain,alpha\nplain,beta\n"


def test_AC_unknown_completion_instruction_prints_nothing(runner):
    @command()
    def comp():
        echo("ran")

    res = runner.invoke(comp, [], env={"_COMP_COMPLETE": "weird_complete"}, prog_name="comp")
    assert res.exit_code == 1
    assert res.output == ""


def test_AC_isolated_filesystem_removes_default_dir_and_keeps_parent_dir(runner, tmp_path):
    with runner.isolated_filesystem() as d:
        assert os.getcwd() == d
    assert not os.path.exists(d)

    with runner.isolated_filesystem(temp_dir=str(tmp_path)) as d2:
        pass
    assert os.path.isdir(d2)


def test_AC_custom_group_lazy_listing(runner):
    class Lazy(group.__globals__["Group"]):
        def list_commands(self, ctx):
            return ["alpha", "beta"]

        def get_command(self, ctx, name):
            if name != "alpha":
                return None

            @command()
            def alpha():
                echo("loaded alpha")

            return alpha

    lazy = Lazy("lz")
    assert runner.invoke(lazy, ["alpha"]).output == "loaded alpha\n"
    assert runner.invoke(lazy, ["beta"]).exit_code == 2


def test_AC_invoke_and_forward(runner):
    @command()
    @option("--x", type=int, default=1)
    def callee(x):
        echo(f"callee x={x}")

    @command()
    @option("--x", type=int, default=5)
    def caller(x):
        ctx = get_current_context()
        ctx.invoke(callee, x=10)
        ctx.forward(callee)

    assert runner.invoke(caller, []).output == "callee x=10\ncallee x=5\n"


def test_AC_context_is_importable():
    assert Context.__name__ == "Context"
