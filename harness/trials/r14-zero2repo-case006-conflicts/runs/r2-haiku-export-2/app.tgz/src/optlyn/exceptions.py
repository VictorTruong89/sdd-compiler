"""Exceptions raised by Optlyn, each mapped to the exit status it produces."""

from __future__ import annotations

import typing as t

if t.TYPE_CHECKING:
    from .core import Context
    from .core import Parameter


class Exit(RuntimeError):
    """Raised by ``ctx.exit()``: an author clean stop with a status."""

    def __init__(self, code: int = 0) -> None:
        super().__init__(code)
        self.exit_code = code


class Abort(RuntimeError):
    """Raised to abort the invocation. Standalone mode reports it with status 1."""


class OptlynError(Exception):
    """Base class for errors that Optlyn reports on standard error."""

    exit_code = 1

    def __init__(self, message: str, ctx: Context | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.ctx = ctx

    def format_message(self) -> str:
        return self.message

    def show(self) -> None:
        from .termui import echo

        echo(f"Error: {self.format_message()}", err=True)


class UsageError(OptlynError):
    """A usage failure: bad options, arguments or commands. Exit status 2."""

    exit_code = 2

    def show(self) -> None:
        from .termui import echo

        if self.ctx is not None:
            echo(f"{self.ctx.get_usage()}", err=True)
            help_names = self.ctx.help_option_names
            if help_names:
                echo(f"Try '{self.ctx.command_path} {help_names[0]}' for help.", err=True)
            echo(err=True)
        echo(f"Error: {self.format_message()}", err=True)


class BadParameter(UsageError):
    """A value for a parameter was refused."""

    def __init__(
        self,
        message: str,
        ctx: Context | None = None,
        param: Parameter | None = None,
        param_hint: str | None = None,
    ) -> None:
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self) -> str:
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        if hint is None:
            return f"Invalid value: {self.message}"
        return f"Invalid value for {hint}: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter received no value from any source."""

    def __init__(
        self,
        message: str | None = None,
        ctx: Context | None = None,
        param: Parameter | None = None,
        param_hint: str | None = None,
    ) -> None:
        super().__init__(message or "", ctx, param, param_hint)

    def format_message(self) -> str:
        if self.param is None:
            return self.message
        hint = self.param_hint or self.param.get_error_hint(self.ctx)
        return f"Missing {self.param.param_type_name} {hint}."


class NoSuchOption(UsageError):
    """An option token that matches no declared flag."""

    def __init__(self, option_name: str, ctx: Context | None = None) -> None:
        super().__init__(f"No such option: {option_name}", ctx)
        self.option_name = option_name


class BadOptionUsage(UsageError):
    """An option used incorrectly, for example without its required value."""


class BadArgumentUsage(UsageError):
    """An argument used incorrectly, for example with too few values."""


class NoArgsIsHelpError(UsageError):
    """A command invoked with no arguments where no-args means help.

    The help page is the whole report, so only the help text is shown.
    """

    def __init__(self, ctx: Context) -> None:
        super().__init__(ctx.get_help(), ctx)

    def show(self) -> None:
        from .termui import echo

        echo(self.message, err=True)


class FileError(OptlynError):
    """A file that could not be opened at first I/O. General error status 1."""

    def __init__(self, filename: str, hint: str) -> None:
        super().__init__(f"Could not open file '{filename}': {hint}")
        self.ui_filename = filename
        self.hint = hint
