"""Parameter types: conversion of command-line tokens into Python values."""

from __future__ import annotations

import enum
import os
import pathlib
import stat
import typing as t
import uuid
from datetime import datetime

from .exceptions import BadParameter
from .fileio import LazyFile
from .fileio import open_stream


class CompletionItem:
    """A shell completion suggestion: a value, its help text, and its kind.

    ``type`` is ``"plain"`` for an ordinary value. ``"file"`` and ``"dir"`` ask
    the shell to complete paths.
    """

    def __init__(self, value: t.Any, help: str | None = None, type: str = "plain") -> None:
        self.value = str(value)
        self.help = help
        self.type = type

    def __repr__(self) -> str:
        return f"CompletionItem({self.value!r}, help={self.help!r}, type={self.type!r})"


class ParamType:
    """Base class for parameter types. Subclasses implement ``convert``."""

    name = "text"
    is_composite = False
    envvar_list_splitter: str | None = None

    def __call__(self, value: t.Any, param: t.Any = None, ctx: t.Any = None) -> t.Any:
        if value is not None:
            return self.convert(value, param, ctx)
        return None

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> t.Any:
        return value

    def get_metavar(self, param: t.Any) -> str | None:
        return None

    def split_envvar_value(self, rv: str) -> list[str]:
        if self.envvar_list_splitter is not None:
            return rv.split(self.envvar_list_splitter)
        return rv.split()

    def fail(self, message: str, param: t.Any = None, ctx: t.Any = None) -> t.NoReturn:
        raise BadParameter(message, ctx=ctx, param=param)

    def shell_complete(self, ctx: t.Any, param: t.Any, incomplete: str) -> list[CompletionItem]:
        return []

    def __repr__(self) -> str:
        return self.name.upper()


def _normalize_token(ctx: t.Any, value: str) -> str:
    func = getattr(ctx, "token_normalize_func", None) if ctx is not None else None
    return func(value) if func is not None else value


class StringParamType(ParamType):
    name = "text"

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> str:
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        return str(value)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> t.Any:
        return value


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> int:
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        if isinstance(value, float):
            if value.is_integer():
                return int(value)
            self.fail(f"{value!r} is not a valid integer.", param, ctx)
        try:
            return int(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> float:
        if isinstance(value, float):
            return value
        try:
            return float(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid float.", param, ctx)


BOOL_TRUE = frozenset({"1", "true", "t", "yes", "y", "on"})
BOOL_FALSE = frozenset({"0", "false", "f", "no", "n", "off"})


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> bool:
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in BOOL_TRUE:
            return True
        if text in BOOL_FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> uuid.UUID:
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID value.", param, ctx)


class Choice(ParamType):
    """A closed list of allowed values, or the member names of an enumeration."""

    name = "choice"

    def __init__(self, choices: t.Iterable[t.Any], case_sensitive: bool = True) -> None:
        self.choices = list(choices)
        self.case_sensitive = case_sensitive

    @staticmethod
    def _text_of(choice: t.Any) -> str:
        if isinstance(choice, enum.Enum):
            return choice.name
        return str(choice)

    def _fold(self, text: str) -> str:
        return text if self.case_sensitive else text.casefold()

    def get_metavar(self, param: t.Any) -> str:
        return "[" + "|".join(self._text_of(c) for c in self.choices) + "]"

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> t.Any:
        for choice in self.choices:
            if choice is value:
                return choice
        normed = self._fold(_normalize_token(ctx, str(value)))
        for choice in self.choices:
            if self._fold(_normalize_token(ctx, self._text_of(choice))) == normed:
                return choice
        names = ", ".join(repr(self._text_of(c)) for c in self.choices)
        self.fail(f"{value!r} is not one of {names}.", param, ctx)

    def shell_complete(self, ctx: t.Any, param: t.Any, incomplete: str) -> list[CompletionItem]:
        return [
            CompletionItem(self._text_of(c))
            for c in self.choices
            if self._text_of(c).startswith(incomplete)
        ]


DEFAULT_DATETIME_FORMATS = ["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats: t.Sequence[str] | None = None) -> None:
        self.formats = list(formats) if formats is not None else list(DEFAULT_DATETIME_FORMATS)

    def get_metavar(self, param: t.Any) -> str:
        return "[" + "|".join(self.formats) + "]"

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> datetime:
        if isinstance(value, datetime):
            return value
        text = str(value).strip()
        for fmt in self.formats:
            try:
                return datetime.strptime(text, fmt)
            except ValueError:
                continue
        formats = ", ".join(repr(f) for f in self.formats)
        self.fail(f"{value!r} does not match the format {formats}.", param, ctx)


class IntRange(IntParamType):
    name = "integer range"

    def __init__(
        self,
        min: int | None = None,
        max: int | None = None,
        min_open: bool = False,
        max_open: bool = False,
        clamp: bool = False,
    ) -> None:
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def __repr__(self) -> str:
        return f"IntRange(min={self.min!r}, max={self.max!r})"

    def _range_text(self) -> str:
        lo = "" if self.min is None else f"{self.min}{'<' if self.min_open else '<='}"
        hi = "" if self.max is None else f"{'<' if self.max_open else '<='}{self.max}"
        return f"{lo}x{hi}"

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> int:
        rv = super().convert(value, param, ctx)
        if self.min is not None:
            if rv < self.min or (self.min_open and rv == self.min):
                if self.clamp:
                    return self.min + 1 if self.min_open else self.min
                self.fail(f"{rv} is not in the valid range of {self._range_text()}.", param, ctx)
        if self.max is not None:
            if rv > self.max or (self.max_open and rv == self.max):
                if self.clamp:
                    return self.max - 1 if self.max_open else self.max
                self.fail(f"{rv} is not in the valid range of {self._range_text()}.", param, ctx)
        return rv


class FloatRange(FloatParamType):
    name = "float range"

    def __init__(
        self,
        min: float | None = None,
        max: float | None = None,
        min_open: bool = False,
        max_open: bool = False,
        clamp: bool = False,
    ) -> None:
        if clamp and (min_open or max_open):
            raise ValueError("Clamping is not supported for open bounds.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def __repr__(self) -> str:
        return f"FloatRange(min={self.min!r}, max={self.max!r})"

    def _range_text(self) -> str:
        lo = "" if self.min is None else f"{self.min}{'<' if self.min_open else '<='}"
        hi = "" if self.max is None else f"{'<' if self.max_open else '<='}{self.max}"
        return f"{lo}x{hi}"

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> float:
        rv = super().convert(value, param, ctx)
        if self.min is not None and (rv < self.min or (self.min_open and rv == self.min)):
            if self.clamp:
                return self.min
            self.fail(f"{rv} is not in the valid range of {self._range_text()}.", param, ctx)
        if self.max is not None and (rv > self.max or (self.max_open and rv == self.max)):
            if self.clamp:
                return self.max
            self.fail(f"{rv} is not in the valid range of {self._range_text()}.", param, ctx)
        return rv


class Tuple(ParamType):
    """A fixed-length product of types, one converted value per position."""

    name = "tuple"
    is_composite = True

    def __init__(self, types: t.Sequence[t.Any]) -> None:
        self.types = [convert_type(ty) for ty in types]

    @property
    def name_text(self) -> str:
        return " ".join(ty.name for ty in self.types)

    def get_metavar(self, param: t.Any) -> str:
        return " ".join(ty.name.upper() for ty in self.types)

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> tuple[t.Any, ...]:
        try:
            items = list(value)
        except TypeError:
            self.fail(f"{value!r} is not a sequence.", param, ctx)
        if len(items) != len(self.types):
            self.fail(f"{len(items)} values were given; {len(self.types)} are required.", param, ctx)
        return tuple(ty(item, param, ctx) for ty, item in zip(self.types, items))


class File(ParamType):
    """An open file. ``-`` is standard input for reading and standard output for writing."""

    name = "filename"
    envvar_list_splitter = os.pathsep

    def __init__(
        self,
        mode: str = "r",
        encoding: str | None = None,
        errors: str | None = "strict",
        lazy: bool | None = None,
        atomic: bool = False,
    ) -> None:
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def __repr__(self) -> str:
        return f"File(mode={self.mode!r})"

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> t.Any:
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        lazy = self.lazy if self.lazy is not None else ("w" in self.mode or "a" in self.mode)
        if lazy:
            f: t.Any = LazyFile(value, self.mode, self.encoding, self.errors, self.atomic)
            if ctx is not None:
                ctx.call_on_close(f.close)
            return f
        try:
            f, should_close = open_stream(value, self.mode, self.encoding, self.errors, self.atomic)
        except OSError as e:
            self.fail(f"'{value}': {e.strerror or e}", param, ctx)
        if should_close and ctx is not None:
            ctx.call_on_close(f.close)
        return f

    def shell_complete(self, ctx: t.Any, param: t.Any, incomplete: str) -> list[CompletionItem]:
        return [CompletionItem(incomplete, type="file")]


class Path(ParamType):
    """A filesystem path, checked against the requested properties. The result is a path."""

    name = "path"
    envvar_list_splitter = os.pathsep

    def __init__(
        self,
        exists: bool = False,
        file_okay: bool = True,
        dir_okay: bool = True,
        writable: bool = False,
        readable: bool = True,
        resolve_path: bool = False,
        allow_dash: bool = False,
        path_type: t.Any = None,
        executable: bool = False,
    ) -> None:
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def coerce(self, rv: str) -> t.Any:
        if self.path_type is None or self.path_type is str:
            return rv
        if self.path_type is pathlib.Path:
            return pathlib.Path(rv)
        return self.path_type(rv)

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> t.Any:
        rv = os.fsdecode(value) if isinstance(value, bytes) else str(value)
        if self.allow_dash and rv == "-":
            return self.coerce(rv)
        if self.resolve_path:
            rv = os.path.realpath(rv)
        try:
            st = os.stat(rv)
        except OSError:
            if not self.exists:
                return self.coerce(rv)
            self.fail(f"{self.name.title()} '{value}' does not exist.", param, ctx)
        if not self.file_okay and stat.S_ISREG(st.st_mode):
            self.fail(f"{self.name.title()} '{value}' is a file.", param, ctx)
        if not self.dir_okay and stat.S_ISDIR(st.st_mode):
            self.fail(f"{self.name.title()} '{value}' is a directory.", param, ctx)
        if self.readable and not os.access(rv, os.R_OK):
            self.fail(f"{self.name.title()} '{value}' is not readable.", param, ctx)
        if self.writable and not os.access(rv, os.W_OK):
            self.fail(f"{self.name.title()} '{value}' is not writable.", param, ctx)
        if self.executable and not os.access(rv, os.X_OK):
            self.fail(f"{self.name.title()} '{value}' is not executable.", param, ctx)
        return self.coerce(rv)

    def shell_complete(self, ctx: t.Any, param: t.Any, incomplete: str) -> list[CompletionItem]:
        if self.dir_okay and not self.file_okay:
            return [CompletionItem(incomplete, type="dir")]
        return [CompletionItem(incomplete, type="file")]


class FuncParamType(ParamType):
    """Adapts a conversion function ``f(token) -> value`` that raises ``ValueError`` to refuse."""

    def __init__(self, func: t.Callable[[t.Any], t.Any]) -> None:
        self.name = getattr(func, "__name__", "text") or "text"
        self.func = func

    def __repr__(self) -> str:
        return self.name.upper()

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> t.Any:
        try:
            return self.func(value)
        except ValueError:
            self.fail(f"{value!r} is not a valid {self.name}.", param, ctx)


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()


def _infer_from_value(value: t.Any) -> ParamType:
    if isinstance(value, bool):
        return BOOL
    if isinstance(value, int):
        return INT
    if isinstance(value, float):
        return FLOAT
    if isinstance(value, tuple):
        return Tuple([_infer_from_value(v) for v in value])
    return STRING


def convert_type(ty: t.Any, default: t.Any = None) -> ParamType:
    """Turn a declared type (instance, class, function or tuple) into a ParamType.

    With no declared type, the type is inferred from ``default``.
    """
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, tuple):
        return Tuple(ty)
    if ty is None:
        if default is None or callable(default):
            return STRING
        if isinstance(default, (list, tuple)) and not isinstance(default, tuple):
            return convert_type(None, default[0]) if default else STRING
        return _infer_from_value(default)
    if ty is str:
        return STRING
    if ty is int:
        return INT
    if ty is float:
        return FLOAT
    if ty is bool:
        return BOOL
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"Unsupported parameter type {ty!r}.")
