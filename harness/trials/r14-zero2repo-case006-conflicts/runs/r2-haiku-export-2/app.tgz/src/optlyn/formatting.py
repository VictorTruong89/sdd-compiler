"""Text wrapping and the help-page formatter."""

from __future__ import annotations

import shutil
import textwrap
import typing as t
from contextlib import contextmanager

BACKSPACE = "\x08"


def wrap_text(
    text: str,
    width: int = 100,
    initial_indent: str = "",
    subsequent_indent: str = "",
    preserve_paragraphs: bool = False,
) -> str:
    """Rewrap ``text`` to ``width`` columns.

    Single newlines inside a paragraph are not kept. A paragraph whose first
    line is a lone backspace is kept as written, without the backspace line.
    """
    width = max(width, 1)
    if not preserve_paragraphs:
        return textwrap.fill(
            " ".join(text.split()),
            width,
            initial_indent=initial_indent,
            subsequent_indent=subsequent_indent,
        )
    out: list[str] = []
    paragraphs = _split_paragraphs(text)
    for paragraph in paragraphs:
        lines = paragraph.split("\n")
        if lines and lines[0].strip() == BACKSPACE:
            body = [line.rstrip() for line in lines[1:]]
            out.append("\n".join(subsequent_indent + line for line in body))
            continue
        flat = " ".join(line.strip() for line in lines if line.strip())
        out.append(
            textwrap.fill(
                flat,
                width,
                initial_indent=initial_indent,
                subsequent_indent=subsequent_indent,
            )
        )
    return "\n\n".join(out)


def _split_paragraphs(text: str) -> list[str]:
    paragraphs: list[str] = []
    current: list[str] = []
    for line in text.split("\n"):
        if line.strip() == "":
            if current:
                paragraphs.append("\n".join(current))
                current = []
        else:
            current.append(line)
    if current:
        paragraphs.append("\n".join(current))
    return paragraphs


class HelpFormatter:
    """Collects the lines of a help page: usage, text, sections and definition lists."""

    def __init__(
        self,
        width: int | None = None,
        max_width: int | None = None,
        indent_increment: int = 2,
    ) -> None:
        if width is None:
            cap = 80 if max_width is None else max_width
            width = max(min(shutil.get_terminal_size().columns, cap) - 2, 50)
        self.width = width
        self.current_indent = 0
        self.indent_increment = indent_increment
        self.buffer: list[str] = []

    def write(self, text: str) -> None:
        self.buffer.append(text)

    def getvalue(self) -> str:
        return "".join(self.buffer)

    def indent(self) -> None:
        self.current_indent += self.indent_increment

    def dedent(self) -> None:
        self.current_indent -= self.indent_increment

    def write_paragraph(self) -> None:
        if self.buffer:
            self.write("\n")

    def write_usage(self, prog: str, args: str = "", prefix: str = "Usage: ") -> None:
        first_prefix = f"{prefix}{prog} "
        text = f"{first_prefix}{args}".rstrip()
        indent = " " * len(first_prefix)
        lines = textwrap.wrap(
            text,
            width=self.width,
            initial_indent="",
            subsequent_indent=indent,
            break_on_hyphens=False,
            break_long_words=False,
        )
        self.write("\n".join(lines) + "\n")

    def write_heading(self, heading: str) -> None:
        self.write(f"{'':>{self.current_indent}}{heading}:\n")

    def write_text(self, text: str) -> None:
        text_width = max(self.width - self.current_indent, 11)
        indent = " " * self.current_indent
        self.write(
            wrap_text(
                text,
                text_width,
                initial_indent=indent,
                subsequent_indent=indent,
                preserve_paragraphs=True,
            )
            + "\n"
        )

    def write_dl(
        self,
        rows: t.Sequence[tuple[str, str]],
        col_max: int = 30,
        col_spacing: int = 2,
    ) -> None:
        rows = list(rows)
        if not rows:
            return
        first_col = min(max(len(first) for first, _ in rows), col_max)
        indent = " " * self.current_indent
        second_indent = " " * (self.current_indent + first_col + col_spacing)
        text_width = max(self.width - first_col - col_spacing - self.current_indent, 10)
        for first, second in rows:
            if not second:
                self.write(f"{indent}{first}\n")
                continue
            lines = textwrap.wrap(second, text_width) or [""]
            if len(first) <= first_col:
                self.write(f"{indent}{first:<{first_col}}{' ' * col_spacing}{lines[0]}\n")
                rest = lines[1:]
            else:
                self.write(f"{indent}{first}\n")
                rest = lines
            for line in rest:
                self.write(f"{second_indent}{line}\n")

    @contextmanager
    def section(self, name: str) -> t.Iterator[None]:
        self.write_paragraph()
        self.write_heading(name)
        self.indent()
        try:
            yield
        finally:
            self.dedent()

    @contextmanager
    def indentation(self) -> t.Iterator[None]:
        self.indent()
        try:
            yield
        finally:
            self.dedent()
