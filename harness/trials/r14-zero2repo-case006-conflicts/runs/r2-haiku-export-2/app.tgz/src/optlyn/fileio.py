"""File and standard-stream opening shared by the file type and the open helper."""

from __future__ import annotations

import os
import sys
import tempfile
import typing as t

from .exceptions import FileError


class StdStream:
    """Wraps a standard stream so that closing it does not close the process stream."""

    def __init__(self, stream: t.IO[t.Any]) -> None:
        self._stream = stream

    def __getattr__(self, name: str) -> t.Any:
        return getattr(self._stream, name)

    def __iter__(self) -> t.Iterator[t.Any]:
        return iter(self._stream)

    def close(self) -> None:
        # The process streams stay open; only flush what was written.
        try:
            self._stream.flush()
        except (OSError, ValueError):
            pass

    def __enter__(self) -> StdStream:
        return self

    def __exit__(self, *exc_info: object) -> None:
        self.close()


class AtomicFile:
    """Writes to a sibling temporary file and replaces the target when closed."""

    def __init__(self, path: str, mode: str, encoding: str | None, errors: str | None) -> None:
        self._path = path
        directory = os.path.dirname(os.path.abspath(path))
        fd, self._tmp_path = tempfile.mkstemp(dir=directory, prefix=".optlyn-", suffix=".tmp")
        os.close(fd)
        binary = "b" in mode
        self._f = open(
            self._tmp_path,
            mode,
            encoding=None if binary else encoding,
            errors=None if binary else errors,
        )

    def __getattr__(self, name: str) -> t.Any:
        return getattr(self._f, name)

    def __iter__(self) -> t.Iterator[t.Any]:
        return iter(self._f)

    def close(self) -> None:
        if self._f.closed:
            return
        self._f.close()
        os.replace(self._tmp_path, self._path)

    def __enter__(self) -> AtomicFile:
        return self

    def __exit__(self, *exc_info: object) -> None:
        self.close()


def open_stream(
    filename: str,
    mode: str = "r",
    encoding: str | None = None,
    errors: str | None = "strict",
    atomic: bool = False,
) -> tuple[t.Any, bool]:
    """Open ``filename``. Returns ``(file, should_close)``.

    The token ``-`` means standard input for reading and standard output for
    writing. Those streams are returned wrapped so that closing them is a no-op.
    """
    binary = "b" in mode
    if filename == "-":
        writing = any(c in mode for c in "wax")
        stream = sys.stdout if writing else sys.stdin
        if binary:
            stream = getattr(stream, "buffer", stream)
        return StdStream(stream), False
    if atomic:
        return AtomicFile(filename, mode, encoding, errors), True
    f = open(
        filename,
        mode,
        encoding=None if binary else encoding,
        errors=None if binary else errors,
    )
    return f, True


class LazyFile:
    """A file that is opened on its first I/O rather than when created."""

    def __init__(
        self,
        filename: str,
        mode: str = "r",
        encoding: str | None = None,
        errors: str | None = "strict",
        atomic: bool = False,
    ) -> None:
        self.name = filename
        self.mode = mode
        self._encoding = encoding
        self._errors = errors
        self._atomic = atomic
        self._f: t.Any = None
        self._should_close = False

    def _open(self) -> t.Any:
        if self._f is None:
            try:
                self._f, self._should_close = open_stream(
                    self.name, self.mode, self._encoding, self._errors, self._atomic
                )
            except OSError as e:
                raise FileError(self.name, e.strerror or str(e)) from e
        return self._f

    def __getattr__(self, name: str) -> t.Any:
        return getattr(self._open(), name)

    def __iter__(self) -> t.Iterator[t.Any]:
        return iter(self._open())

    def close(self) -> None:
        if self._f is not None and self._should_close:
            self._f.close()

    close_intelligently = close

    def __enter__(self) -> LazyFile:
        return self

    def __exit__(self, *exc_info: object) -> None:
        self.close()


def open_file(
    filename: str,
    mode: str = "r",
    encoding: str | None = None,
    errors: str | None = "strict",
    lazy: bool = False,
    atomic: bool = False,
) -> t.Any:
    """Open a file, or a standard stream for ``-``, as a context manager."""
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    try:
        f, _ = open_stream(filename, mode, encoding, errors, atomic)
    except OSError as e:
        raise FileError(filename, e.strerror or str(e)) from e
    return f
