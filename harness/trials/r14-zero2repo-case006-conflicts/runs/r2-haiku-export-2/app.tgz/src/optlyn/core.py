"""Commands, groups, parameters, invocation contexts and the option parser."""

from __future__ import annotations

import enum
import os
import re
import sys
import typing as t
from contextlib import ExitStack
from contextlib import contextmanager

from ._state import pop_context
from ._state import push_context
from .exceptions import Abort
from .exceptions import BadOptionUsage
from .exceptions import BadParameter
from .exceptions import Exit
from .exceptions import MissingParameter
from .exceptions import NoArgsIsHelpError
from .exceptions import NoSuchOption
from .exceptions import OptlynError
from .exceptions import UsageError
from .formatting import HelpFormatter
from .param_types import BOOL_FALSE
from .param_types import BOOL_TRUE
from .param_types import BoolParamType
from .param_types import IntRange
from .param_types import STRING
from .param_types import Tuple as TupleType
from .param_types import convert_type
from .termui import confirm
from .termui import echo
from .termui import prompt


class ParameterSource(enum.Enum):
    """Where a parameter's value came from."""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


# Lower rank is more explicit. Auto-derived defaults rank below declared ones.
_SOURCE_RANK = {
    ParameterSource.PROMPT: 0,
    ParameterSource.COMMANDLINE: 1,
    ParameterSource.ENVIRONMENT: 2,
    ParameterSource.DEFAULT_MAP: 3,
    ParameterSource.DEFAULT: 4,
}
_AUTO_DEFAULT_RANK = 5

# Placed in the parsed values when an option is given with no value at all.
_FLAG_NEEDS_VALUE: t.Any = object()

_DEFAULT_HELP_OPTION_NAMES = ["--help"]


def _split_opt(opt: str) -> tuple[str, str]:
    first = opt[:1]
    if first.isalnum() or first == "_":
        return "", opt
    if opt[1:2] == first:
        return opt[:2], opt[2:]
    return first, opt[1:]


def _is_long_opt(token: str) -> bool:
    prefix, name = _split_opt(token)
    return prefix == "--" or (len(prefix) == 1 and prefix != "-" and len(name) > 1)


def _parse_decls(decls: t.Sequence[str]) -> tuple[str | None, list[str], list[str]]:
    name: str | None = None
    opts: list[str] = []
    secondary: list[str] = []
    for decl in decls:
        if not decl:
            continue
        if decl[0].isalnum() or decl[0] == "_":
            if name is not None:
                raise TypeError(f"Name '{name}' defined twice.")
            name = decl.replace("-", "_")
        elif "/" in decl[1:]:
            first, second = decl.split("/", 1)
            opts.append(first)
            secondary.append(second)
        else:
            opts.append(decl)
    return name, opts, secondary


def _name_from_flags(flags: list[str]) -> str:
    if not flags:
        raise TypeError("Could not determine a name for the parameter.")
    ordered = sorted(flags, key=lambda f: -len(_split_opt(f)[0]))
    return _split_opt(ordered[0])[1].replace("-", "_")


def _source_rank(source: ParameterSource, param: Parameter) -> int:
    if source is ParameterSource.DEFAULT and getattr(param, "_auto_default", False):
        return _AUTO_DEFAULT_RANK
    return _SOURCE_RANK[source]


def _display_default(value: t.Any) -> str:
    if isinstance(value, (list, tuple)):
        return ", ".join(str(v) for v in value)
    return str(value)


class Context:
    """The state of one invocation of one command.

    Contexts nest: each one knows its parent, and children inherit settings
    and the author object from it.
    """

    def __init__(
        self,
        command: Command,
        parent: Context | None = None,
        info_name: str | None = None,
        obj: t.Any = None,
        auto_envvar_prefix: str | None = None,
        default_map: t.Mapping[str, t.Any] | None = None,
        terminal_width: int | None = None,
        max_content_width: int | None = None,
        allow_extra_args: bool | None = None,
        allow_interspersed_args: bool | None = None,
        ignore_unknown_options: bool | None = None,
        help_option_names: t.Sequence[str] | None = None,
        token_normalize_func: t.Callable[[str], str] | None = None,
        color: bool | None = None,
        show_default: bool | None = None,
        resilient_parsing: bool = False,
    ) -> None:
        self.parent = parent
        self.command = command
        self.info_name = info_name
        self.params: dict[str, t.Any] = {}
        self.args: list[str] = []
        self.protected_args: list[str] = []
        self.invoked_subcommand: t.Any = None
        self._parameter_source: dict[str, ParameterSource] = {}
        self._param_rank: dict[str, int] = {}
        self._exit_stack = ExitStack()
        self._depth = 0

        if parent is not None:
            if obj is None:
                obj = parent.obj
            if auto_envvar_prefix is None:
                auto_envvar_prefix = parent.auto_envvar_prefix
            if default_map is None and info_name is not None and parent.default_map is not None:
                nested = parent.default_map.get(info_name)
                if isinstance(nested, dict):
                    default_map = nested
            if terminal_width is None:
                terminal_width = parent.terminal_width
            if max_content_width is None:
                max_content_width = parent.max_content_width
            if help_option_names is None:
                help_option_names = parent.help_option_names
            if token_normalize_func is None:
                token_normalize_func = parent.token_normalize_func
            if color is None:
                color = parent.color
            if show_default is None:
                show_default = parent.show_default

        self.obj = obj
        self.auto_envvar_prefix = auto_envvar_prefix
        self.default_map = default_map
        self.terminal_width = terminal_width
        self.max_content_width = 80 if max_content_width is None else max_content_width
        self.allow_extra_args = (
            command.allow_extra_args if allow_extra_args is None else allow_extra_args
        )
        self.allow_interspersed_args = (
            command.allow_interspersed_args
            if allow_interspersed_args is None
            else allow_interspersed_args
        )
        self.ignore_unknown_options = (
            command.ignore_unknown_options
            if ignore_unknown_options is None
            else ignore_unknown_options
        )
        self.help_option_names = list(
            _DEFAULT_HELP_OPTION_NAMES if help_option_names is None else help_option_names
        )
        self.token_normalize_func = token_normalize_func
        self.color = color
        self.show_default = bool(show_default)
        self.resilient_parsing = resilient_parsing

    # Context manager protocol. Entering makes the context current on this thread.

    def __enter__(self) -> Context:
        self._depth += 1
        push_context(self)
        return self

    def __exit__(self, exc_type: t.Any, exc: t.Any, tb: t.Any) -> None:
        self._depth -= 1
        pop_context()
        if self._depth == 0:
            self.close()

    @contextmanager
    def scope(self, cleanup: bool = True) -> t.Iterator[Context]:
        push_context(self)
        try:
            yield self
        finally:
            pop_context()
            if cleanup:
                self.close()

    def close(self) -> None:
        self._exit_stack.close()
        self._exit_stack = ExitStack()

    def call_on_close(self, f: t.Callable[[], t.Any]) -> None:
        self._exit_stack.callback(f)

    def with_resource(self, cm: t.ContextManager[t.Any]) -> t.Any:
        return self._exit_stack.enter_context(cm)

    # Lookups

    @property
    def command_path(self) -> str:
        rv = self.info_name or ""
        if self.parent is not None:
            rv = f"{self.parent.command_path} {rv}"
        return rv.lstrip()

    def find_root(self) -> Context:
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type: type) -> t.Any:
        node: Context | None = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type: type) -> t.Any:
        rv = self.find_object(object_type)
        if rv is None:
            self.obj = rv = object_type()
        return rv

    def lookup_default(self, name: str) -> t.Any:
        if self.default_map is not None:
            value = self.default_map.get(name)
            if callable(value):
                value = value()
            return value
        return None

    def get_parameter_source(self, name: str) -> ParameterSource | None:
        return self._parameter_source.get(name)

    def _set_param(self, param: Parameter, source: ParameterSource, value: t.Any) -> None:
        rank = _source_rank(source, param)
        dest = param.name
        previous = self._param_rank.get(dest)
        if previous is not None and rank > previous:
            return
        self._param_rank[dest] = rank
        self._parameter_source[dest] = source
        self.params[dest] = value

    def _names_below_root(self) -> list[str]:
        names: list[str] = []
        node: Context | None = self
        while node is not None and node.parent is not None:
            names.append(node.info_name or "")
            node = node.parent
        return list(reversed(names))

    # Actions

    def fail(self, message: str) -> t.NoReturn:
        raise UsageError(message, self)

    def abort(self) -> t.NoReturn:
        raise Abort()

    def exit(self, code: int = 0) -> t.NoReturn:
        raise Exit(code)

    def get_usage(self) -> str:
        return self.command.get_usage(self)

    def get_help(self) -> str:
        return self.command.get_help(self)

    def make_formatter(self) -> HelpFormatter:
        return HelpFormatter(width=self.terminal_width, max_width=self.max_content_width)

    def invoke(self, callback: t.Any, /, *args: t.Any, **kwargs: t.Any) -> t.Any:
        """Run ``callback`` in this context. A Command runs its own callback with defaults."""
        if isinstance(callback, Command):
            other = callback
            callback = other.callback
            ctx = Context(other, info_name=other.name, parent=self)
            for param in other.params:
                if param.name not in kwargs and param.expose_value:
                    kwargs[param.name] = param.type_cast_value(ctx, param.get_default(ctx))
            ctx.params.update(kwargs)
        else:
            ctx = self
        if callback is None:
            return None
        with ctx:
            return callback(*args, **kwargs)

    def forward(self, cmd: t.Any, /, *args: t.Any, **kwargs: t.Any) -> t.Any:
        kwargs = {**self.params, **kwargs}
        return self.invoke(cmd, *args, **kwargs)


class Parameter:
    """Base class for options and arguments."""

    param_type_name = "parameter"
    _supports_autoenv = False

    def __init__(
        self,
        name: str,
        opts: t.Sequence[str] = (),
        secondary_opts: t.Sequence[str] = (),
        *,
        type: t.Any = None,
        is_flag: bool = False,
        flag_value: t.Any = None,
        default: t.Any = None,
        required: bool = False,
        callback: t.Callable[..., t.Any] | None = None,
        nargs: int | None = None,
        multiple: bool = False,
        metavar: str | None = None,
        expose_value: bool = True,
        is_eager: bool = False,
        envvar: str | t.Sequence[str] | None = None,
        shell_complete: t.Callable[..., t.Any] | None = None,
        deprecated: bool | str = False,
        hidden: bool = False,
    ) -> None:
        self.name = name
        self.opts = list(opts)
        self.secondary_opts = list(secondary_opts)
        if type is None:
            if is_flag and flag_value is not None:
                type = convert_type(None, flag_value)
            elif default is not None and not callable(default):
                sample = default
                if (multiple or (nargs is not None and nargs != 1)) and isinstance(
                    default, (list, tuple)
                ):
                    sample = default[0] if default else None
                type = convert_type(None, sample)
            else:
                type = STRING
        self.type = convert_type(type)
        if nargs is None:
            nargs = len(self.type.types) if isinstance(self.type, TupleType) else 1
        self.nargs = nargs
        self.default = default
        self.required = required
        self.callback = callback
        self.multiple = multiple
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        if envvar is None:
            self.envvar: list[str] | None = None
        elif isinstance(envvar, str):
            self.envvar = [envvar]
        else:
            self.envvar = list(envvar)
        self.shell_complete = shell_complete
        self.deprecated = bool(deprecated)
        self.deprecation_note = deprecated if isinstance(deprecated, str) else None
        self.hidden = hidden

    def __repr__(self) -> str:
        return f"<{type(self).__name__} {self.name}>"

    # Naming and display

    def get_error_hint(self, ctx: Context | None) -> str:
        return f"'{self.name}'"

    def make_metavar(self) -> str:
        return self.metavar or self.name.upper()

    def get_usage_pieces(self, ctx: Context) -> list[str]:
        return []

    def get_help_record(self, ctx: Context) -> tuple[str, str] | None:
        return None

    def _deprecation_message(self) -> str:
        text = f"DeprecationWarning: The {self.param_type_name} '{self.name}' is deprecated."
        if self.deprecation_note:
            text = f"{text} {self.deprecation_note}"
        return text

    # Values

    def get_default(self, ctx: Context, call: bool = True) -> t.Any:
        value = self.default
        if callable(value) and call:
            value = value()
        return value

    def _split_text(self, text: str) -> list[t.Any]:
        tokens = self.type.split_envvar_value(text)
        if self.multiple and self.nargs > 1:
            n = self.nargs
            return [tuple(tokens[i : i + n]) for i in range(0, len(tokens), n)]
        return tokens

    def _resolve_envvar_value(self, ctx: Context) -> str | None:
        names = list(self.envvar or [])
        if self._supports_autoenv and self.allow_from_autoenv and ctx.auto_envvar_prefix:
            parts = [ctx.auto_envvar_prefix, *ctx._names_below_root(), self.name]
            names.append("_".join(p.replace("-", "_").upper() for p in parts if p))
        for name in names:
            value = os.environ.get(name)
            if value:
                return value
        return None

    def value_from_envvar(self, ctx: Context) -> t.Any:
        rv = self._resolve_envvar_value(ctx)
        if rv is None:
            return None
        if self.multiple or self.nargs != 1:
            return self._split_text(rv)
        return rv

    def _default_map_value(self, ctx: Context) -> t.Any:
        value = ctx.lookup_default(self.name)
        if isinstance(value, str) and self.nargs != 1:
            value = self._split_text(value)
        return value

    def consume_value(self, ctx: Context, opts: dict[str, t.Any]) -> tuple[t.Any, ParameterSource]:
        value = opts.get(self.name)
        if value is not None:
            return value, ParameterSource.COMMANDLINE
        value = self.value_from_envvar(ctx)
        if value is not None:
            return value, ParameterSource.ENVIRONMENT
        value = self._default_map_value(ctx)
        if value is not None:
            return value, ParameterSource.DEFAULT_MAP
        return self.get_default(ctx), ParameterSource.DEFAULT

    def type_cast_value(self, ctx: Context | None, value: t.Any) -> t.Any:
        if value is None:
            return () if (self.multiple or self.nargs == -1) else None

        def convert_occurrence(v: t.Any) -> t.Any:
            if isinstance(self.type, TupleType):
                if isinstance(v, str) or not hasattr(v, "__iter__"):
                    raise BadParameter(f"{v!r} is not a sequence.", ctx, self)
                return self.type(v, self, ctx)
            if self.nargs != 1:
                if isinstance(v, str) or not hasattr(v, "__iter__"):
                    raise BadParameter(
                        f"requires an iterable (sequence) value, not {v!r}.", ctx, self
                    )
                return tuple(self.type(item, self, ctx) for item in v)
            return self.type(v, self, ctx)

        if self.multiple:
            if isinstance(value, str) or not hasattr(value, "__iter__"):
                raise BadParameter(
                    f"requires an iterable (sequence) default, not {value!r}.", ctx, self
                )
            return tuple(convert_occurrence(v) for v in value)
        return convert_occurrence(value)

    def value_is_missing(self, value: t.Any) -> bool:
        if value is None:
            return True
        if (self.nargs != 1 or self.multiple) and value == ():
            return True
        return False

    def process_value(self, ctx: Context, value: t.Any) -> t.Any:
        value = self.type_cast_value(ctx, value)
        if self.required and self.value_is_missing(value):
            raise MissingParameter(ctx=ctx, param=self)
        if self.callback is not None:
            try:
                value = self.callback(ctx, self, value)
            except BadParameter as e:
                if e.param is None:
                    e.param = self
                if e.ctx is None:
                    e.ctx = ctx
                raise
        return value

    def handle_parse_result(self, ctx: Context, opts: dict[str, t.Any]) -> t.Any:
        value, source = self.consume_value(ctx, opts)
        if self.deprecated and source is ParameterSource.COMMANDLINE:
            echo(self._deprecation_message(), err=True)
        if source is not ParameterSource.PROMPT:
            value = self.process_value(ctx, value)
        if self.expose_value:
            ctx._set_param(self, source, value)
        return value


class Option(Parameter):
    """A named parameter, given as ``--name value``, ``-n value``, or as a flag."""

    param_type_name = "option"
    _supports_autoenv = True

    def __init__(
        self,
        param_decls: t.Sequence[str] | None = None,
        *,
        show_default: bool | str | None = None,
        prompt: bool | str = False,
        confirmation_prompt: bool = False,
        prompt_required: bool = True,
        hide_input: bool = False,
        is_flag: bool | None = None,
        flag_value: t.Any = None,
        count: bool = False,
        allow_from_autoenv: bool = True,
        help: str | None = None,
        hidden: bool = False,
        show_envvar: bool = False,
        deprecated: bool | str = False,
        type: t.Any = None,
        multiple: bool = False,
        nargs: int | None = None,
        default: t.Any = None,
        required: bool = False,
        callback: t.Callable[..., t.Any] | None = None,
        envvar: str | t.Sequence[str] | None = None,
        metavar: str | None = None,
        expose_value: bool = True,
        is_eager: bool = False,
        shell_complete: t.Callable[..., t.Any] | None = None,
        show_choices: bool = True,
    ) -> None:
        name, opts, secondary = _parse_decls(list(param_decls or ()))
        if name is None:
            name = _name_from_flags(opts or secondary)

        prompt_text: str | None = None
        if prompt is True:
            prompt_text = name.replace("_", " ").capitalize()
        elif isinstance(prompt, str):
            prompt_text = prompt
        self.prompt = prompt_text
        self.prompt_required = prompt_required
        self.confirmation_prompt = confirmation_prompt
        self.hide_input = hide_input
        self.show_choices = show_choices
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.allow_from_autoenv = allow_from_autoenv
        self.help = help
        self.count = count

        self._flag_needs_value = self.prompt is not None and not prompt_required
        if is_flag is None:
            is_flag = flag_value is not None or bool(secondary)
        elif is_flag is False and not self._flag_needs_value:
            self._flag_needs_value = flag_value is not None
        self.is_flag = bool(is_flag) and not count

        auto_default = False
        if self.is_flag and default is None and not required:
            default = False
            auto_default = True
        if count and default is None:
            default = 0
        if count and type is None:
            type = IntRange(min=0)
        if self.is_flag and flag_value is None:
            flag_value = True
        self.flag_value = flag_value
        self._auto_default = auto_default

        super().__init__(
            name,
            opts,
            secondary,
            type=type,
            is_flag=self.is_flag,
            flag_value=flag_value,
            default=default,
            required=required,
            callback=callback,
            nargs=nargs,
            multiple=multiple,
            metavar=metavar,
            expose_value=expose_value,
            is_eager=is_eager,
            envvar=envvar,
            shell_complete=shell_complete,
            deprecated=deprecated,
            hidden=hidden,
        )
        self.is_bool_flag = self.is_flag and isinstance(self.type, BoolParamType)
        self.secondary_flag_value = (not self.flag_value) if self.is_flag else None

        if self.nargs < 1:
            raise TypeError("Option nargs must be a positive integer.")
        if self.deprecated and self.required:
            raise TypeError("A deprecated option cannot be required.")
        if self.deprecated and self.prompt is not None:
            raise TypeError("A deprecated option cannot use a prompt.")
        if self.count and self.multiple:
            raise TypeError("A counting option cannot be repeatable.")

    @property
    def takes_value(self) -> bool:
        return not (self.is_flag or self.count)

    def get_error_hint(self, ctx: Context | None) -> str:
        return "/".join(f"'{x}'" for x in self.opts or self.secondary_opts)

    def make_metavar(self) -> str | None:
        if self.metavar is not None:
            return self.metavar
        if self.is_flag or self.count:
            return None
        metavar = self.type.get_metavar(self)
        if metavar is None:
            metavar = self.type.name.upper()
        if isinstance(self.type, TupleType):
            return " ".join(ty.name.upper() for ty in self.type.types)
        if self.nargs != 1:
            return " ".join([metavar] * self.nargs)
        return metavar

    def _flag_from_envvar(self, rv: str) -> t.Any:
        text = rv.strip().lower()
        if self.is_bool_flag:
            if text in BOOL_TRUE:
                return True
            if text in BOOL_FALSE or text == "":
                return False
            return rv
        if rv == str(self.flag_value) or text in BOOL_TRUE:
            return self.flag_value
        return None

    def value_from_envvar(self, ctx: Context) -> t.Any:
        rv = self._resolve_envvar_value(ctx)
        if rv is None:
            return None
        if self.is_flag:
            return self._flag_from_envvar(rv)
        if self.multiple or self.nargs != 1:
            return self._split_text(rv)
        return rv

    def prompt_for_value(self, ctx: Context, default: t.Any) -> t.Any:
        assert self.prompt is not None
        if self.is_bool_flag:
            answer = confirm(self.prompt, default=bool(default))
            return self.process_value(ctx, answer)
        return prompt(
            self.prompt,
            default=default,
            type=self.type,
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            value_proc=lambda v: self.process_value(ctx, v),
            show_choices=self.show_choices,
        )

    def consume_value(self, ctx: Context, opts: dict[str, t.Any]) -> tuple[t.Any, ParameterSource]:
        value = opts.get(self.name)
        if value is _FLAG_NEEDS_VALUE:
            if self.prompt is not None and not ctx.resilient_parsing:
                return self.prompt_for_value(ctx, None), ParameterSource.PROMPT
            return self.flag_value, ParameterSource.COMMANDLINE
        if self.multiple and isinstance(value, list) and any(v is _FLAG_NEEDS_VALUE for v in value):
            value = [self.flag_value if v is _FLAG_NEEDS_VALUE else v for v in value]
            return value, ParameterSource.COMMANDLINE
        if value is not None:
            return value, ParameterSource.COMMANDLINE

        value = self.value_from_envvar(ctx)
        if value is not None:
            return value, ParameterSource.ENVIRONMENT

        value = self._default_map_value(ctx)
        if value is not None:
            source = ParameterSource.DEFAULT_MAP
        else:
            value = self.get_default(ctx)
            source = ParameterSource.DEFAULT

        if (
            self.prompt is not None
            and (self.required or self.prompt_required)
            and not ctx.resilient_parsing
        ):
            return self.prompt_for_value(ctx, value), ParameterSource.PROMPT
        return value, source

    def get_help_record(self, ctx: Context) -> tuple[str, str] | None:
        if self.hidden:
            return None
        first = ", ".join(self.opts)
        if self.secondary_opts:
            first = f"{first} / {', '.join(self.secondary_opts)}"
        metavar = self.make_metavar()
        if metavar:
            first = f"{first} {metavar}"

        extras: list[str] = []
        show = self.show_default if self.show_default is not None else ctx.show_default
        if show and self.default is not None:
            if isinstance(show, str):
                text = show
            elif callable(self.default):
                text = "(dynamic)"
            else:
                text = _display_default(self.default)
            if not (self.is_flag and not self.default):
                extras.append(f"[default: {text}]")
        if self.show_envvar and self.envvar:
            extras.append(f"[env var: {', '.join(self.envvar)}]")
        if self.deprecated:
            extras.append("[DEPRECATED]")
        help_text = self.help or ""
        if extras:
            help_text = " ".join(part for part in [help_text, *extras] if part)
        return first, help_text


class Argument(Parameter):
    """A positional parameter. Tokens bind to arguments in declaration order."""

    param_type_name = "argument"

    def __init__(
        self,
        param_decls: t.Sequence[str],
        *,
        required: bool | None = None,
        default: t.Any = None,
        type: t.Any = None,
        nargs: int | None = None,
        envvar: str | t.Sequence[str] | None = None,
        deprecated: bool | str = False,
        help: str | None = None,
        metavar: str | None = None,
        callback: t.Callable[..., t.Any] | None = None,
        expose_value: bool = True,
        is_eager: bool = False,
        hidden: bool = False,
        shell_complete: t.Callable[..., t.Any] | None = None,
    ) -> None:
        decls = list(param_decls or ())
        if len(decls) != 1 or not decls[0]:
            raise TypeError("An argument takes exactly one destination name.")
        name = decls[0].replace("-", "_")
        if nargs is None:
            nargs = 1
        if nargs == 0 or nargs < -1:
            raise TypeError("Argument nargs must be a positive integer or -1.")
        if required is None:
            required = default is None and nargs != -1
        self.help = help
        super().__init__(
            name,
            type=type,
            default=default,
            required=required,
            callback=callback,
            nargs=nargs,
            metavar=metavar,
            expose_value=expose_value,
            is_eager=is_eager,
            envvar=envvar,
            shell_complete=shell_complete,
            deprecated=deprecated,
            hidden=hidden,
        )
        if self.deprecated and self.required:
            raise TypeError("A deprecated argument cannot be required.")

    def get_error_hint(self, ctx: Context | None) -> str:
        return f"'{self.make_metavar()}'"

    def make_metavar(self) -> str:
        return self.metavar or self.name.upper()

    def get_usage_pieces(self, ctx: Context) -> list[str]:
        meta = self.make_metavar()
        if not self.required:
            meta = f"[{meta}]"
        if self.nargs == -1:
            meta = f"{meta}..."
        return [meta]

    def get_help_record(self, ctx: Context) -> tuple[str, str] | None:
        if self.hidden or not self.help:
            return None
        return self.make_metavar(), self.help

    def value_from_envvar(self, ctx: Context) -> t.Any:
        rv = self._resolve_envvar_value(ctx)
        if rv is None:
            return None
        if self.nargs != 1:
            return self._split_text(rv)
        return rv


def _distribute_arguments(
    arguments: list[Argument], pool: list[str], ctx: Context
) -> tuple[list[t.Any], list[str]]:
    """Split the positional tokens across the arguments by their arity."""
    specs = [a.nargs for a in arguments]
    total = len(pool)
    pos = 0
    chunks: list[list[str]] = []
    for i, nargs in enumerate(specs):
        if nargs == -1:
            after = sum(s for s in specs[i + 1 :] if s > 0)
            take = max(0, total - pos - after)
        else:
            take = nargs
        chunk = pool[pos : pos + take]
        pos += len(chunk)
        chunks.append(chunk)
    leftover = pool[pos:]

    values: list[t.Any] = []
    for arg, chunk in zip(arguments, chunks):
        if arg.nargs == -1:
            values.append(tuple(chunk) if chunk else None)
        elif arg.nargs == 1:
            values.append(chunk[0] if chunk else None)
        elif not chunk:
            values.append(None)
        elif len(chunk) == arg.nargs:
            values.append(tuple(chunk))
        else:
            raise BadParameter(
                f"Argument '{arg.make_metavar()}' takes {arg.nargs} values.",
                ctx,
                arg,
            )
    return values, leftover


class _ParseState:
    def __init__(self, rargs: list[str]) -> None:
        self.opts: dict[str, t.Any] = {}
        self.order: list[Parameter] = []
        self.largs: list[str] = []
        self.rargs = rargs


class OptionParser:
    """Parses option tokens. Positional tokens are returned as the remaining pool."""

    def __init__(self, ctx: Context, options: t.Sequence[Option]) -> None:
        self.ctx = ctx
        self.allow_interspersed_args = ctx.allow_interspersed_args
        self.ignore_unknown_options = ctx.ignore_unknown_options
        self._opts: dict[str, tuple[Option, bool, t.Any]] = {}
        self._prefix_chars: set[str] = {"-"}
        for option in options:
            self._add_option(option)

    def _norm(self, token: str) -> str:
        func = self.ctx.token_normalize_func
        return func(token) if func is not None else token

    def _add_option(self, option: Option) -> None:
        for flag in option.opts:
            self._register(flag, option, option.takes_value, option.flag_value)
        for flag in option.secondary_opts:
            self._register(flag, option, False, option.secondary_flag_value)

    def _register(self, flag: str, option: Option, takes: bool, const: t.Any) -> None:
        if flag:
            self._prefix_chars.add(flag[0])
        self._opts[self._norm(flag)] = (option, takes, const)

    def parse(self, args: t.Sequence[str]) -> tuple[dict[str, t.Any], list[Parameter], list[str]]:
        state = _ParseState(list(args))
        self._process_args_for_options(state)
        return state.opts, state.order, state.largs + state.rargs

    def _process_args_for_options(self, state: _ParseState) -> None:
        while state.rargs:
            arg = state.rargs.pop(0)
            if arg == "--":
                return
            if arg[:1] in self._prefix_chars and len(arg) > 1:
                self._process_opts(arg, state)
            elif self.allow_interspersed_args:
                state.largs.append(arg)
            else:
                state.rargs.insert(0, arg)
                return

    def _process_opts(self, arg: str, state: _ParseState) -> None:
        norm = self._norm(arg)
        if norm in self._opts:
            self._match_opt(norm, None, state)
            return
        if "=" in arg:
            name, explicit = arg.split("=", 1)
            norm = self._norm(name)
            if norm in self._opts:
                self._match_opt(norm, explicit, state)
                return
        else:
            name = arg
        if _is_long_opt(name):
            if self.ignore_unknown_options:
                state.largs.append(arg)
                return
            raise NoSuchOption(name, ctx=self.ctx)
        self._match_short_stack(arg, state)

    def _match_opt(self, norm: str, explicit: str | None, state: _ParseState) -> None:
        option, takes, const = self._opts[norm]
        if not takes:
            if explicit is not None:
                raise BadOptionUsage(f"Option '{norm}' does not take a value.", self.ctx)
            self._store(state, option, const)
            return
        value = self._value_from(option, explicit, state, norm)
        self._store(state, option, value)

    def _value_from(
        self, option: Option, explicit: str | None, state: _ParseState, name: str
    ) -> t.Any:
        nargs = option.nargs
        if explicit is not None:
            state.rargs.insert(0, explicit)
        if len(state.rargs) < nargs:
            if option._flag_needs_value:
                return _FLAG_NEEDS_VALUE
            raise BadOptionUsage(f"Option '{name}' requires an argument.", self.ctx)
        if nargs == 1:
            nxt = state.rargs[0]
            if option._flag_needs_value and len(nxt) > 1 and nxt[:1] in self._prefix_chars:
                return _FLAG_NEEDS_VALUE
            return state.rargs.pop(0)
        values = tuple(state.rargs[:nargs])
        del state.rargs[:nargs]
        return values

    def _match_short_stack(self, arg: str, state: _ParseState) -> None:
        prefix = arg[0]
        chars = arg[1:]
        i = 0
        while i < len(chars):
            flag = prefix + chars[i]
            norm = self._norm(flag)
            if norm not in self._opts:
                if self.ignore_unknown_options:
                    state.largs.append(prefix + chars[i:])
                    return
                raise NoSuchOption(flag, ctx=self.ctx)
            option, takes, const = self._opts[norm]
            if not takes:
                self._store(state, option, const)
                i += 1
                continue
            rest = chars[i + 1 :]
            value = self._value_from(option, rest or None, state, norm)
            self._store(state, option, value)
            return

    def _store(self, state: _ParseState, option: Option, value: t.Any) -> None:
        dest = option.name
        if option.count:
            state.opts[dest] = state.opts.get(dest, 0) + 1
        elif option.multiple:
            state.opts.setdefault(dest, []).append(value)
        else:
            state.opts[dest] = value
        if not any(p is option for p in state.order):
            state.order.append(option)


def iter_params_for_processing(
    invocation_order: list[Parameter], declaration_order: list[Parameter]
) -> list[Parameter]:
    """Eager parameters first, then the rest; each group in invocation order."""

    def sort_key(item: Parameter) -> tuple[bool, float]:
        for index, candidate in enumerate(invocation_order):
            if candidate is item:
                return (not item.is_eager, index)
        return (not item.is_eager, float("inf"))

    return sorted(declaration_order, key=sort_key)


def _detect_program_name() -> str:
    if sys.argv and sys.argv[0]:
        return os.path.basename(sys.argv[0])
    return "main"


class Command:
    """A leaf command: parses its own options and arguments and runs a callback."""

    allow_extra_args = False
    allow_interspersed_args = True
    ignore_unknown_options = False

    def __init__(
        self,
        name: str | None,
        context_settings: t.Mapping[str, t.Any] | None = None,
        callback: t.Callable[..., t.Any] | None = None,
        params: list[Parameter] | None = None,
        help: str | None = None,
        epilog: str | None = None,
        short_help: str | None = None,
        options_metavar: str | None = "[OPTIONS]",
        add_help_option: bool = True,
        no_args_is_help: bool = False,
        hidden: bool = False,
        deprecated: bool | str = False,
    ) -> None:
        self.name = name
        self.context_settings: dict[str, t.Any] = dict(context_settings or {})
        self.callback = callback
        self.params: list[Parameter] = list(params or [])
        self.help = help
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = bool(deprecated)
        self.deprecation_note = deprecated if isinstance(deprecated, str) else None
        if sum(1 for p in self.params if isinstance(p, Argument) and p.nargs == -1) > 1:
            raise TypeError("Only one variadic argument is allowed per command.")

    def __repr__(self) -> str:
        return f"<{type(self).__name__} {self.name}>"

    def __call__(self, *args: t.Any, **kwargs: t.Any) -> t.Any:
        return self.main(*args, **kwargs)

    # Parameters and help

    def get_help_option_names(self, ctx: Context) -> list[str]:
        used: set[str] = set()
        for param in self.params:
            used.update(param.opts)
            used.update(param.secondary_opts)
        return [n for n in ctx.help_option_names if n not in used]

    def get_help_option(self, ctx: Context) -> Option | None:
        if not self.add_help_option:
            return None
        names = self.get_help_option_names(ctx)
        if not names:
            return None
        return Option(
            ["_optlyn_help", *names],
            is_flag=True,
            is_eager=True,
            expose_value=False,
            callback=_show_help_callback,
            help="Show this message and exit.",
        )

    def get_params(self, ctx: Context) -> list[Parameter]:
        rv = list(self.params)
        help_option = self.get_help_option(ctx)
        if help_option is not None:
            rv.append(help_option)
        return rv

    def collect_usage_pieces(self, ctx: Context) -> list[str]:
        rv: list[str] = []
        if self.options_metavar and any(
            isinstance(p, Option) for p in self.get_params(ctx)
        ):
            rv.append(self.options_metavar)
        for param in self.get_params(ctx):
            rv.extend(param.get_usage_pieces(ctx))
        return rv

    def get_short_help_str(self, limit: int = 45) -> str:
        if self.short_help is not None:
            text = self.short_help
        else:
            text = " ".join((self.help or "").split())
            match = re.match(r"(.*?[.!?])(\s|$)", text)
            if match:
                text = match.group(1)
        if len(text) > limit:
            text = text[: max(limit - 3, 0)].rstrip() + "..."
        return text

    def format_usage(self, ctx: Context, formatter: HelpFormatter) -> None:
        pieces = self.collect_usage_pieces(ctx)
        formatter.write_usage(ctx.command_path, " ".join(pieces))

    def format_help_text(self, ctx: Context, formatter: HelpFormatter) -> None:
        text = self.help or ""
        if self.deprecated:
            text = f"(Deprecated) {text}".strip()
        if text:
            formatter.write_paragraph()
            with formatter.indentation():
                formatter.write_text(text)

    def format_options(self, ctx: Context, formatter: HelpFormatter) -> None:
        argument_rows: list[tuple[str, str]] = []
        option_rows: list[tuple[str, str]] = []
        for param in self.get_params(ctx):
            record = param.get_help_record(ctx)
            if record is None:
                continue
            if isinstance(param, Argument):
                argument_rows.append(record)
            else:
                option_rows.append(record)
        if argument_rows:
            with formatter.section("Positional arguments"):
                formatter.write_dl(argument_rows)
        if option_rows:
            with formatter.section("Options"):
                formatter.write_dl(option_rows)

    def format_epilog(self, ctx: Context, formatter: HelpFormatter) -> None:
        if self.epilog:
            formatter.write_paragraph()
            with formatter.indentation():
                formatter.write_text(self.epilog)

    def format_help(self, ctx: Context, formatter: HelpFormatter) -> None:
        self.format_usage(ctx, formatter)
        self.format_help_text(ctx, formatter)
        self.format_options(ctx, formatter)
        self.format_epilog(ctx, formatter)

    def get_usage(self, ctx: Context) -> str:
        formatter = ctx.make_formatter()
        self.format_usage(ctx, formatter)
        return formatter.getvalue().rstrip("\n")

    def get_help(self, ctx: Context) -> str:
        formatter = ctx.make_formatter()
        self.format_help(ctx, formatter)
        return formatter.getvalue().rstrip("\n")

    # Parsing and invocation

    def parse_args(self, ctx: Context, args: list[str]) -> list[str]:
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsIsHelpError(ctx)
        params = self.get_params(ctx)
        parser = OptionParser(ctx, [p for p in params if isinstance(p, Option)])
        opts, order, pool = parser.parse(args)
        arguments = [p for p in params if isinstance(p, Argument)]
        values, leftover = _distribute_arguments(arguments, pool, ctx)
        for arg, raw in zip(arguments, values):
            if raw is not None:
                opts[arg.name] = raw
            order.append(arg)
        for param in iter_params_for_processing(order, params):
            param.handle_parse_result(ctx, opts)
        if leftover and not ctx.allow_extra_args and not ctx.resilient_parsing:
            ctx.fail(f"Got unexpected extra argument(s) ({' '.join(leftover)})")
        ctx.args = leftover
        return leftover

    def make_context(
        self,
        info_name: str | None,
        args: list[str],
        parent: Context | None = None,
        **extra: t.Any,
    ) -> Context:
        for key, value in self.context_settings.items():
            if key not in extra:
                extra[key] = value
        ctx = Context(self, info_name=info_name, parent=parent, **extra)
        with ctx.scope(cleanup=False):
            try:
                self.parse_args(ctx, list(args))
            except BaseException:
                ctx.close()
                raise
        return ctx

    def invoke(self, ctx: Context) -> t.Any:
        if self.deprecated:
            text = f"DeprecationWarning: The command '{self.name}' is deprecated."
            if self.deprecation_note:
                text = f"{text} {self.deprecation_note}"
            echo(text, err=True)
        if self.callback is not None:
            return ctx.invoke(self.callback, **ctx.params)
        return None

    def main(
        self,
        args: t.Sequence[str] | None = None,
        prog_name: str | None = None,
        complete_var: str | None = None,
        standalone_mode: bool = True,
        windows_expand_args: bool = True,
        **extra: t.Any,
    ) -> t.Any:
        """Run the command from the process or from ``args``.

        In standalone mode the process exits with the status of the outcome.
        Otherwise failures are raised and the callback's value is returned.
        """
        args = list(sys.argv[1:] if args is None else args)
        if prog_name is None:
            prog_name = _detect_program_name()
        self._main_shell_completion(extra, prog_name, complete_var)
        try:
            try:
                with self.make_context(prog_name, args, **extra) as ctx:
                    rv = self.invoke(ctx)
                    if not standalone_mode:
                        return rv
                    ctx.exit()
            except (EOFError, KeyboardInterrupt) as e:
                echo(file=sys.stderr)
                raise Abort() from e
            except OptlynError as e:
                if not standalone_mode:
                    raise
                e.show()
                sys.exit(e.exit_code)
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return e.exit_code
        except Abort:
            if not standalone_mode:
                raise
            echo("Aborted!", file=sys.stderr)
            sys.exit(1)
        return None

    def _main_shell_completion(
        self, extra: dict[str, t.Any], prog_name: str, complete_var: str | None
    ) -> None:
        if complete_var is None:
            complete_var = "_" + prog_name.replace("-", "_").upper() + "_COMPLETE"
        instruction = os.environ.get(complete_var)
        if not instruction:
            return
        from .shell_completion import shell_complete

        sys.exit(shell_complete(self, prog_name, complete_var, instruction))


def _show_help_callback(ctx: Context, param: Parameter, value: t.Any) -> None:
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


class Group(Command):
    """A command that dispatches to named subcommands."""

    allow_extra_args = True
    allow_interspersed_args = False

    def __init__(
        self,
        name: str | None = None,
        commands: t.Mapping[str, Command] | t.Sequence[Command] | None = None,
        invoke_without_command: bool = False,
        no_args_is_help: bool | None = None,
        subcommand_metavar: str | None = None,
        chain: bool = False,
        result_callback: t.Callable[..., t.Any] | None = None,
        **kwargs: t.Any,
    ) -> None:
        super().__init__(name, **kwargs)
        if commands is None:
            commands = {}
        elif not isinstance(commands, dict):
            commands = {c.name: c for c in commands}  # type: ignore[misc]
        self.commands: dict[str, Command] = dict(commands)
        self.invoke_without_command = invoke_without_command
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        self.no_args_is_help = no_args_is_help
        self.chain = chain
        self._result_callback = result_callback
        if chain:
            for command in self.commands.values():
                if isinstance(command, Group):
                    raise RuntimeError("Cannot attach a group to a chaining group.")
        if subcommand_metavar is None:
            if chain:
                subcommand_metavar = "COMMAND1 [ARGS]... [COMMAND2 [ARGS]...]..."
            elif invoke_without_command:
                subcommand_metavar = "[COMMAND] [ARGS]..."
            else:
                subcommand_metavar = "COMMAND [ARGS]..."
        self.subcommand_metavar = subcommand_metavar

    def add_command(self, cmd: Command, name: str | None = None) -> None:
        name = name or cmd.name
        if name is None:
            raise TypeError("A command needs a name to be added to a group.")
        if self.chain and isinstance(cmd, Group):
            raise RuntimeError("Cannot attach a group to a chaining group.")
        self.commands[name] = cmd

    def command(self, *args: t.Any, **kwargs: t.Any) -> t.Callable[[t.Any], Command]:
        from .decorators import command as command_decorator

        def decorator(f: t.Any) -> Command:
            cmd = command_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args: t.Any, **kwargs: t.Any) -> t.Callable[[t.Any], Group]:
        from .decorators import group as group_decorator

        def decorator(f: t.Any) -> Group:
            cmd = group_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self, replace: bool = False) -> t.Callable[[t.Any], t.Any]:
        def decorator(f: t.Any) -> t.Any:
            self._result_callback = f
            return f

        return decorator

    def list_commands(self, ctx: Context) -> list[str]:
        return sorted(self.commands)

    def get_command(self, ctx: Context, cmd_name: str) -> Command | None:
        return self.commands.get(cmd_name)

    def collect_usage_pieces(self, ctx: Context) -> list[str]:
        rv = super().collect_usage_pieces(ctx)
        rv.append(self.subcommand_metavar)
        return rv

    def format_commands(self, ctx: Context, formatter: HelpFormatter) -> None:
        rows: list[tuple[str, Command]] = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            rows.append((name, cmd))
        if not rows:
            return
        widest = min(max(len(name) for name, _ in rows), 30)
        limit = max(formatter.width - widest - 4, 10)
        with formatter.section("Commands"):
            formatter.write_dl([(name, cmd.get_short_help_str(limit)) for name, cmd in rows])

    def format_help(self, ctx: Context, formatter: HelpFormatter) -> None:
        self.format_usage(ctx, formatter)
        self.format_help_text(ctx, formatter)
        self.format_options(ctx, formatter)
        self.format_commands(ctx, formatter)
        self.format_epilog(ctx, formatter)

    def parse_args(self, ctx: Context, args: list[str]) -> list[str]:
        rest = super().parse_args(ctx, args)
        if self.chain:
            ctx.protected_args = rest
            ctx.args = []
        elif rest:
            ctx.protected_args, ctx.args = rest[:1], rest[1:]
        return ctx.args

    def resolve_command(self, ctx: Context, args: list[str]) -> tuple[str, Command, list[str]]:
        token = args[0]
        cmd_name = token
        cmd = self.get_command(ctx, cmd_name)
        if cmd is None and ctx.token_normalize_func is not None:
            normalized = ctx.token_normalize_func(token)
            for name in self.list_commands(ctx):
                if ctx.token_normalize_func(name) == normalized:
                    cmd_name = name
                    cmd = self.get_command(ctx, name)
                    break
        if cmd is None and not ctx.resilient_parsing:
            if _split_opt(token)[0]:
                raise NoSuchOption(token, ctx=ctx)
            ctx.fail(f"No such command {token!r}.")
        return cmd_name, cmd, args[1:]  # type: ignore[return-value]

    def invoke(self, ctx: Context) -> t.Any:
        def process_result(value: t.Any) -> t.Any:
            if self._result_callback is not None:
                value = ctx.invoke(self._result_callback, value, **ctx.params)
            return value

        if not ctx.protected_args:
            if self.invoke_without_command:
                with ctx:
                    rv = super().invoke(ctx)
                    return process_result([] if self.chain else rv)
            ctx.fail("Missing command.")

        args = [*ctx.protected_args, *ctx.args]
        ctx.args = []
        ctx.protected_args = []

        if not self.chain:
            with ctx:
                cmd_name, cmd, args = self.resolve_command(ctx, args)
                ctx.invoked_subcommand = cmd_name
                super().invoke(ctx)
                sub_ctx = cmd.make_context(cmd_name, args, parent=ctx)
                with sub_ctx:
                    return process_result(sub_ctx.command.invoke(sub_ctx))

        with ctx:
            ctx.invoked_subcommand = "*" if args else None
            super().invoke(ctx)
            results: list[t.Any] = []
            while args:
                cmd_name, cmd, args = self.resolve_command(ctx, args)
                sub_ctx = cmd.make_context(
                    cmd_name,
                    args,
                    parent=ctx,
                    allow_extra_args=True,
                    allow_interspersed_args=False,
                )
                with sub_ctx:
                    results.append(sub_ctx.command.invoke(sub_ctx))
                args = sub_ctx.args
            return process_result(results)


class CommandCollection(Group):
    """Presents the subcommands of several groups under one dispatch surface."""

    def __init__(
        self,
        name: str | None = None,
        sources: t.Sequence[Group] | None = None,
        **kwargs: t.Any,
    ) -> None:
        super().__init__(name, **kwargs)
        self.sources: list[Group] = list(sources or [])

    def add_source(self, group: Group) -> None:
        self.sources.append(group)

    def list_commands(self, ctx: Context) -> list[str]:
        rv: set[str] = set()
        for source in self.sources:
            rv.update(source.list_commands(ctx))
        return sorted(rv)

    def get_command(self, ctx: Context, cmd_name: str) -> Command | None:
        for source in self.sources:
            rv = source.get_command(ctx, cmd_name)
            if rv is not None:
                return rv
        return None
