"""In-process runner: invoke a command with tokens and capture its output and status."""

from __future__ import annotations

import io
import os
import shlex
import shutil
import sys
import tempfile
import typing as t
from contextlib import contextmanager

from .termui import RunnerInput


class _Recorder:
    """Keeps every write in order, tagged by stream, so output can be interleaved."""

    def __init__(self) -> None:
        self.chunks: list[tuple[str, bytes]] = []

    def add(self, name: str, data: bytes) -> None:
        self.chunks.append((name, data))

    def bytes_for(self, name: str) -> bytes:
        return b"".join(data for n, data in self.chunks if n == name)

    def combined(self) -> bytes:
        return b"".join(data for _, data in self.chunks)


class _BytesCapture(io.RawIOBase):
    def __init__(self, name: str, recorder: _Recorder) -> None:
        self._name = name
        self._recorder = recorder

    def writable(self) -> bool:
        return True

    def write(self, b: t.Any) -> int:
        data = bytes(b)
        self._recorder.add(self._name, data)
        return len(data)


class _TextCapture(io.TextIOBase):
    def __init__(self, name: str, recorder: _Recorder, charset: str) -> None:
        self._charset = charset
        self.buffer = _BytesCapture(name, recorder)

    @property
    def encoding(self) -> str:
        return self._charset

    @property
    def errors(self) -> str:
        return "replace"

    def writable(self) -> bool:
        return True

    def isatty(self) -> bool:
        return False

    def write(self, s: str) -> int:
        self.buffer.write(s.encode(self._charset, "replace"))
        return len(s)

    def flush(self) -> None:
        pass


class Result:
    """The outcome of one ``CliRunner.invoke`` call."""

    def __init__(
        self,
        runner: CliRunner,
        stdout_bytes: bytes,
        stderr_bytes: bytes,
        output_bytes: bytes,
        return_value: t.Any,
        exit_code: int,
        exception: BaseException | None,
        exc_info: t.Any = None,
    ) -> None:
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self) -> str:
        return self.output_bytes.decode(self.runner.charset, "replace")

    @property
    def stdout(self) -> str:
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self) -> str:
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    def __repr__(self) -> str:
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    """Invokes commands in-process, with captured streams and an optional environment."""

    def __init__(
        self,
        charset: str = "utf-8",
        env: t.Mapping[str, str | None] | None = None,
        echo_stdin: bool = False,
        catch_exceptions: bool = True,
        capture: str = "sys",
    ) -> None:
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture
        self._last = _Recorder()

    def get_default_prog_name(self, cli: t.Any) -> str:
        return cli.name or "root"

    @contextmanager
    def isolation(
        self,
        input: str | bytes | t.IO[t.Any] | None = None,
        env: t.Mapping[str, str | None] | None = None,
        color: bool = False,
    ) -> t.Iterator[None]:
        """Swap in the captured streams and the input, and apply ``env`` for the block."""
        if isinstance(input, bytes):
            text = input.decode(self.charset, "replace")
        elif input is None:
            text = ""
        elif isinstance(input, str):
            text = input
        else:
            text = input.read()
            if isinstance(text, bytes):
                text = text.decode(self.charset, "replace")

        old_env: dict[str, str | None] = {}
        merged_env = {**self.env, **dict(env or {})}
        for key, value in merged_env.items():
            old_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
        try:
            if self.capture == "fd":
                yield from self._fd_isolation(text)
            else:
                yield from self._sys_isolation(text)
        finally:
            self._restore_env(old_env)

    def _sys_isolation(self, text: str) -> t.Iterator[None]:
        recorder = _Recorder()
        self._last = recorder
        old_stdin, old_stdout, old_stderr = sys.stdin, sys.stdout, sys.stderr
        out = _TextCapture("stdout", recorder, self.charset)
        err = _TextCapture("stderr", recorder, self.charset)
        sys.stdin = RunnerInput(text, echo_out=out, echo_stdin=self.echo_stdin)
        sys.stdout = out
        sys.stderr = err
        try:
            yield
        finally:
            sys.stdin, sys.stdout, sys.stderr = old_stdin, old_stdout, old_stderr

    def _restore_env(self, old_env: dict[str, str | None]) -> None:
        for key, value in old_env.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value

    def _fd_isolation(self, text: str) -> t.Iterator[None]:
        """Capture OS-level writes to descriptors 1 and 2 as well as interpreter writes."""
        recorder = _Recorder()
        self._last = recorder
        old_stdin, old_stdout, old_stderr = sys.stdin, sys.stdout, sys.stderr
        out_file = tempfile.TemporaryFile()
        err_file = tempfile.TemporaryFile()
        saved_out = os.dup(1)
        saved_err = os.dup(2)
        try:
            sys.stdout.flush()
            sys.stderr.flush()
            os.dup2(out_file.fileno(), 1)
            os.dup2(err_file.fileno(), 2)
            sys.stdin = RunnerInput(text, echo_stdin=self.echo_stdin)
            sys.stdout = io.TextIOWrapper(
                io.FileIO(1, "w", closefd=False), encoding=self.charset, write_through=True
            )
            sys.stderr = io.TextIOWrapper(
                io.FileIO(2, "w", closefd=False), encoding=self.charset, write_through=True
            )
            try:
                yield
            finally:
                sys.stdout.flush()
                sys.stderr.flush()
        finally:
            sys.stdin, sys.stdout, sys.stderr = old_stdin, old_stdout, old_stderr
            os.dup2(saved_out, 1)
            os.dup2(saved_err, 2)
            os.close(saved_out)
            os.close(saved_err)
            out_file.seek(0)
            err_file.seek(0)
            recorder.add("stdout", out_file.read())
            recorder.add("stderr", err_file.read())
            out_file.close()
            err_file.close()

    def invoke(
        self,
        cli: t.Any,
        args: str | t.Sequence[str] | None = None,
        input: str | bytes | t.IO[t.Any] | None = None,
        env: t.Mapping[str, str | None] | None = None,
        catch_exceptions: bool | None = None,
        color: bool = False,
        **extra: t.Any,
    ) -> Result:
        """Run ``cli`` with ``args`` and return a :class:`Result`."""
        exc_info: t.Any = None
        exception: BaseException | None = None
        exit_code = 0
        return_value: t.Any = None
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if isinstance(args, str):
            args = shlex.split(args)
        prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)

        with self.isolation(input=input, env=env, color=color):
            try:
                return_value = cli.main(
                    args=list(args or ()),
                    prog_name=prog_name,
                    color=color,
                    **extra,
                )
            except SystemExit as e:
                exc_info = sys.exc_info()
                code = e.code
                if code is None:
                    code = 0
                if code != 0:
                    exception = e
                if not isinstance(code, int):
                    sys.stdout.write(str(code))
                    sys.stdout.write("\n")
                    code = 1
                exit_code = code
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
        recorder = self._last
        return Result(
            runner=self,
            stdout_bytes=recorder.bytes_for("stdout"),
            stderr_bytes=recorder.bytes_for("stderr"),
            output_bytes=recorder.combined(),
            return_value=return_value,
            exit_code=exit_code,
            exception=exception,
            exc_info=exc_info,
        )

    @contextmanager
    def isolated_filesystem(self, temp_dir: str | os.PathLike[str] | None = None) -> t.Iterator[str]:
        """Change into a new empty directory for the block and yield its path.

        With no ``temp_dir`` the directory is removed when the block ends. With a
        parent given, the new directory is created under it and left in place.
        """
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                shutil.rmtree(dt, ignore_errors=True)
