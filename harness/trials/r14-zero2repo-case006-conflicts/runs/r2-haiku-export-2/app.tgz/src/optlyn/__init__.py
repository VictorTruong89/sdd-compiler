"""Optlyn: a composable library for command line interfaces."""

from .core import Argument
from .core import Command
from .core import CommandCollection
from .core import Context
from .core import Group
from .core import Option
from .core import Parameter
from .decorators import argument
from .decorators import command
from .decorators import confirmation_option
from .decorators import custom_version_option
from .decorators import group
from .decorators import help_option
from .decorators import make_pass_decorator
from .decorators import option
from .decorators import pass_context
from .decorators import pass_obj
from .decorators import password_option
from .decorators import version_option
from ._state import get_current_context
from .exceptions import Abort
from .exceptions import BadParameter
from .exceptions import UsageError
from .param_types import BOOL
from .param_types import Choice
from .param_types import DateTime
from .param_types import FLOAT
from .param_types import File
from .param_types import FloatRange
from .param_types import INT
from .param_types import IntRange
from .param_types import ParamType
from .param_types import Path
from .param_types import STRING
from .param_types import Tuple
from .param_types import UNPROCESSED
from .param_types import UUID
from .termui import clear
from .termui import confirm
from .termui import echo
from .termui import echo_via_pager
from .termui import edit
from .termui import format_filename
from .termui import get_app_dir
from .termui import get_pager_file
from .termui import getchar
from .termui import launch
from .termui import open_file
from .termui import pause
from .termui import progressbar
from .termui import prompt
from .termui import secho
from .termui import style
from .termui import unstyle

__version__ = "0.1.0"

__all__ = [
    "Abort",
    "Argument",
    "BOOL",
    "BadParameter",
    "Choice",
    "Command",
    "CommandCollection",
    "Context",
    "DateTime",
    "FLOAT",
    "File",
    "FloatRange",
    "Group",
    "INT",
    "IntRange",
    "Option",
    "Parameter",
    "ParamType",
    "Path",
    "STRING",
    "Tuple",
    "UNPROCESSED",
    "UUID",
    "UsageError",
    "argument",
    "clear",
    "command",
    "confirm",
    "confirmation_option",
    "custom_version_option",
    "echo",
    "echo_via_pager",
    "edit",
    "format_filename",
    "get_app_dir",
    "get_current_context",
    "get_pager_file",
    "getchar",
    "group",
    "help_option",
    "launch",
    "make_pass_decorator",
    "open_file",
    "option",
    "pass_context",
    "pass_obj",
    "password_option",
    "pause",
    "progressbar",
    "prompt",
    "secho",
    "style",
    "unstyle",
    "version_option",
]
