"""Decorators that declare commands, groups and parameters on plain functions."""

from __future__ import annotations

import inspect
import typing as t
from functools import update_wrapper
from importlib import metadata

from ._state import get_current_context
from .core import Argument
from .core import Command
from .core import Context
from .core import Group
from .core import Option
from .core import Parameter
from .termui import echo


def _param_memo(f: t.Any, param: Parameter) -> None:
    if not hasattr(f, "__optlyn_params__"):
        f.__optlyn_params__ = []
    f.__optlyn_params__.append(param)


def _default_command_name(name: str) -> str:
    name = name.lower()
    for suffix in ("_command", "_cmd", "_group", "_grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def _make_command(f: t.Any, name: str | None, attrs: dict[str, t.Any], cls: type) -> t.Any:
    params: list[Parameter] = list(getattr(f, "__optlyn_params__", []))
    params.reverse()
    if hasattr(f, "__optlyn_params__"):
        del f.__optlyn_params__

    help_text = attrs.pop("help", None)
    if help_text is None:
        help_text = inspect.getdoc(f)
    if help_text:
        help_text = help_text.split("\f", 1)[0]
    attrs["help"] = help_text

    if name is None:
        name = _default_command_name(f.__name__)
    return cls(name=name, callback=f, params=params, **attrs)


def command(name: t.Any = None, cls: type | None = None, **attrs: t.Any) -> t.Any:
    """Declare a command from a function. Used as ``@command()`` or ``@command``."""
    if cls is None:
        cls = Command

    def decorator(f: t.Any) -> Command:
        return _make_command(f, name if isinstance(name, str) else None, dict(attrs), cls)

    if callable(name) and not isinstance(name, str):
        f = name
        name = None
        return decorator(f)
    return decorator


def group(name: t.Any = None, cls: type | None = None, **attrs: t.Any) -> t.Any:
    """Declare a group from a function. Used as ``@group()`` or ``@group``."""
    if cls is None:
        cls = Group

    def decorator(f: t.Any) -> Group:
        return _make_command(f, name if isinstance(name, str) else None, dict(attrs), cls)

    if callable(name) and not isinstance(name, str):
        f = name
        name = None
        return decorator(f)
    return decorator


def option(*param_decls: str, cls: type | None = None, **attrs: t.Any) -> t.Callable[[t.Any], t.Any]:
    """Attach an option to the function being decorated."""
    if cls is None:
        cls = Option

    def decorator(f: t.Any) -> t.Any:
        _param_memo(f, cls(param_decls, **attrs))
        return f

    return decorator


def argument(*param_decls: str, cls: type | None = None, **attrs: t.Any) -> t.Callable[[t.Any], t.Any]:
    """Attach a positional argument to the function being decorated."""
    if cls is None:
        cls = Argument

    def decorator(f: t.Any) -> t.Any:
        _param_memo(f, cls(param_decls, **attrs))
        return f

    return decorator


def _show_help(ctx: Context, param: Parameter, value: t.Any) -> None:
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


def help_option(*param_decls: str, **kwargs: t.Any) -> t.Callable[[t.Any], t.Any]:
    """Attach an extra eager help flag that prints help and exits."""
    if not param_decls:
        param_decls = ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _show_help)

    def decorator(f: t.Any) -> t.Any:
        _param_memo(f, Option(param_decls, **kwargs))
        return f

    return decorator


def _detect_version(name: str) -> str:
    try:
        return metadata.version(name)
    except metadata.PackageNotFoundError:
        dists = metadata.packages_distributions().get(name)
        if dists:
            return metadata.version(dists[0])
        raise RuntimeError(f"{name!r} is not an installed distribution or import name.")


def version_option(
    version: str | None = None,
    *param_decls: str,
    package_name: str | None = None,
    prog_name: str | None = None,
    message: str | None = None,
    **kwargs: t.Any,
) -> t.Callable[[t.Any], t.Any]:
    """Attach an eager ``--version`` flag that prints the version and exits."""
    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")

    def callback(ctx: Context, param: Parameter, value: t.Any) -> None:
        if not value or ctx.resilient_parsing:
            return
        identity = version
        if identity is None:
            if package_name is None:
                raise RuntimeError("version_option needs either a version or a package_name.")
            identity = _detect_version(package_name)
        prog = prog_name or ctx.find_root().info_name
        template = message or "%(prog)s, version %(version)s"
        echo(template % {"prog": prog, "package": package_name, "version": identity}, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("callback", callback)

    def decorator(f: t.Any) -> t.Any:
        _param_memo(f, Option(param_decls, **kwargs))
        return f

    return decorator


def custom_version_option(
    callback_fn: t.Callable[[Context], str],
    *param_decls: str,
    **kwargs: t.Any,
) -> t.Callable[[t.Any], t.Any]:
    """Attach an eager version flag whose whole identity is the callback's return value."""
    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")

    def callback(ctx: Context, param: Parameter, value: t.Any) -> None:
        if not value or ctx.resilient_parsing:
            return
        echo(callback_fn(ctx), color=True)
        ctx.exit()

    kwargs.setdefault("callback", callback)

    def decorator(f: t.Any) -> t.Any:
        _param_memo(f, Option(param_decls, **kwargs))
        return f

    return decorator


def password_option(*param_decls: str, **kwargs: t.Any) -> t.Callable[[t.Any], t.Any]:
    """Attach a prompting, hidden-input, confirmed option."""
    if not param_decls:
        param_decls = ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)

    def decorator(f: t.Any) -> t.Any:
        _param_memo(f, Option(param_decls, **kwargs))
        return f

    return decorator


def _confirmation_callback(ctx: Context, param: Parameter, value: t.Any) -> None:
    if not value:
        ctx.abort()


def confirmation_option(*param_decls: str, **kwargs: t.Any) -> t.Callable[[t.Any], t.Any]:
    """Attach a confirmation flag. Omitting it asks; declining aborts the command."""
    if not param_decls:
        param_decls = ("--yes",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("callback", _confirmation_callback)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")

    def decorator(f: t.Any) -> t.Any:
        _param_memo(f, Option(param_decls, **kwargs))
        return f

    return decorator


def pass_context(f: t.Callable[..., t.Any]) -> t.Callable[..., t.Any]:
    """Pass the current context as the first argument."""

    def new_func(*args: t.Any, **kwargs: t.Any) -> t.Any:
        return f(get_current_context(), *args, **kwargs)

    return update_wrapper(new_func, f)


def pass_obj(f: t.Callable[..., t.Any]) -> t.Callable[..., t.Any]:
    """Pass the current context's author object as the first argument."""

    def new_func(*args: t.Any, **kwargs: t.Any) -> t.Any:
        return f(get_current_context().obj, *args, **kwargs)

    return update_wrapper(new_func, f)


def make_pass_decorator(object_type: type, ensure: bool = False) -> t.Callable[[t.Any], t.Any]:
    """Build a decorator that passes the nearest object of ``object_type``."""

    def decorator(f: t.Callable[..., t.Any]) -> t.Callable[..., t.Any]:
        def new_func(*args: t.Any, **kwargs: t.Any) -> t.Any:
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(
                    f"Managed to invoke callback without a context object of type"
                    f" {object_type.__name__!r} existing."
                )
            return ctx.invoke(f, obj, *args, **kwargs)

        return update_wrapper(new_func, f)

    return decorator
