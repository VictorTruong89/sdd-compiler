"""Shell completion: registration scripts and suggestion output for bash, zsh, fish and PowerShell.

Output lines are ``<kind>,<value>``. ``plain`` is an ordinary suggestion, and
``file`` and ``dir`` ask the shell to complete paths. For zsh and fish a tab
and the help text follow the value.
"""

from __future__ import annotations

import os
import re
import sys
import typing as t

from .core import Argument
from .core import Command
from .core import Context
from .core import Group
from .core import Option
from .param_types import CompletionItem
from .termui import echo

SHELLS = ("bash", "zsh", "fish", "powershell")


def _function_name(prog_name: str) -> str:
    return "_" + re.sub(r"\W", "_", prog_name) + "_completion"


def _source_script(shell: str, prog_name: str, complete_var: str) -> str:
    func = _function_name(prog_name)
    if shell == "bash":
        return (
            f"{func}() {{\n"
            "    local IFS=$'\\n'\n"
            f'    local response=$(env COMP_WORDS="${{COMP_WORDS[*]}}" COMP_CWORD=$COMP_CWORD'
            f" {complete_var}=bash_complete {prog_name})\n"
            "    COMPREPLY=()\n"
            "    for item in $response; do\n"
            "        case \"$item\" in\n"
            "            plain,*) COMPREPLY+=(\"${item#plain,}\") ;;\n"
            "            file,*) COMPREPLY+=($(compgen -f -- \"${item#file,}\")) ;;\n"
            "            dir,*) COMPREPLY+=($(compgen -d -- \"${item#dir,}\")) ;;\n"
            "        esac\n"
            "    done\n"
            "    return 0\n"
            "}\n"
            f"complete -o default -F {func} {prog_name}\n"
        )
    if shell == "zsh":
        return (
            f"#compdef {prog_name}\n"
            f"{func}() {{\n"
            f"    local -a completions\n"
            f"    local -a response\n"
            f'    response=("${{(@f)$(env COMP_WORDS="${{words[*]}}" COMP_CWORD=$((CURRENT-1))'
            f" {complete_var}=zsh_complete {prog_name})}}\")\n"
            "    for item in $response; do\n"
            "        kind=${item%%,*}\n"
            "        value=${item#*,}\n"
            "        case $kind in\n"
            "            plain) completions+=(\"${value%%$'\\t'*}\") ;;\n"
            "            file) _files ;;\n"
            "            dir) _files -/ ;;\n"
            "        esac\n"
            "    done\n"
            "    compadd -- $completions\n"
            "}\n"
            f"compdef {func} {prog_name}\n"
        )
    if shell == "fish":
        return (
            f"function {func}\n"
            f"    set -l response (env COMP_WORDS=(commandline -cp) "
            f"COMP_CWORD=(commandline -ct) {complete_var}=fish_complete {prog_name})\n"
            "    for item in $response\n"
            "        set kind (string split -m1 , -- $item)[1]\n"
            "        set value (string split -m1 , -- $item)[2]\n"
            "        switch $kind\n"
            "            case plain\n"
            "                echo $value\n"
            "            case file\n"
            "                __fish_complete_path $value\n"
            "            case dir\n"
            "                __fish_complete_directories $value\n"
            "        end\n"
            "    end\n"
            "end\n"
            f"complete -c {prog_name} -f -a '({func})'\n"
        )
    # powershell
    return (
        f"Register-ArgumentCompleter -Native -CommandName '{prog_name}' -ScriptBlock {{\n"
        "    param($wordToComplete, $commandAst, $cursorPosition)\n"
        f"    $env:COMP_WORDS = $commandAst.ToString()\n"
        f"    $env:COMP_CWORD = $wordToComplete\n"
        f"    $env:{complete_var} = 'powershell_complete'\n"
        f"    & '{prog_name}' | ForEach-Object {{\n"
        "        $kind, $value = $_ -split ',', 2\n"
        "        if ($kind -eq 'plain') {\n"
        "            [System.Management.Automation.CompletionResult]::new($value, $value, 'ParameterValue', $value)\n"
        "        }\n"
        "    }\n"
        f"    Remove-Item Env:{complete_var}\n"
        "}\n"
    )


def _resolve(cli: Command, prog_name: str, args: list[str]) -> tuple[Context, Command, list[str]]:
    """Walk the groups named in ``args`` down to the command that is being completed."""
    ctx = Context(cli, info_name=prog_name)
    cmd: Command = cli
    i = 0
    while i < len(args):
        token = args[i]
        if isinstance(cmd, Group) and not token.startswith("-"):
            sub = cmd.get_command(ctx, token)
            if sub is not None:
                ctx = Context(sub, info_name=token, parent=ctx)
                cmd = sub
        i += 1
    return ctx, cmd, args


def _option_takes_value(cmd: Command, token: str) -> Option | None:
    for param in cmd.params:
        if isinstance(param, Option) and param.takes_value and token in param.opts:
            return param
    return None


def _complete(cli: Command, prog_name: str, args: list[str], incomplete: str) -> list[CompletionItem]:
    ctx, cmd, rest = _resolve(cli, prog_name, args)
    items: list[CompletionItem] = []

    previous = args[-1] if args else ""
    value_option = _option_takes_value(cmd, previous)
    if value_option is not None:
        completer = value_option.shell_complete
        if completer is not None:
            return list(completer(ctx, value_option, incomplete))
        return value_option.type.shell_complete(ctx, value_option, incomplete)

    if incomplete.startswith("-"):
        for param in cmd.get_params(ctx):
            if not isinstance(param, Option) or param.hidden:
                continue
            for flag in [*param.opts, *param.secondary_opts]:
                if flag.startswith(incomplete):
                    items.append(CompletionItem(flag, help=param.help))
        return items

    if isinstance(cmd, Group):
        for name in cmd.list_commands(ctx):
            sub = cmd.get_command(ctx, name)
            if sub is None or sub.hidden or not name.startswith(incomplete):
                continue
            items.append(CompletionItem(name, help=sub.get_short_help_str(45)))
        return items

    positional = [p for p in cmd.params if isinstance(p, Argument)]
    index = sum(1 for tok in rest if not tok.startswith("-"))
    if index < len(positional):
        arg = positional[index]
        completer = arg.shell_complete
        if completer is not None:
            return list(completer(ctx, arg, incomplete))
        return arg.type.shell_complete(ctx, arg, incomplete)
    return items


def _format_items(items: t.Iterable[CompletionItem], shell: str) -> str:
    lines: list[str] = []
    for item in items:
        line = f"{item.type},{item.value}"
        if shell in ("zsh", "fish") and item.help:
            line = f"{line}\t{item.help}"
        lines.append(line)
    return "".join(f"{line}\n" for line in lines)


def shell_complete(cli: Command, prog_name: str, complete_var: str, instruction: str) -> int:
    """Handle a completion instruction. Returns the process exit status."""
    shell, _, mode = instruction.partition("_")
    if shell not in SHELLS or mode not in ("source", "complete"):
        return 1

    if mode == "source":
        echo(_source_script(shell, prog_name, complete_var), nl=False)
        return 0

    words = os.environ.get("COMP_WORDS", "").split(" ")
    if shell == "fish":
        incomplete = os.environ.get("COMP_CWORD", "")
        args = words[1:]
        if args and args[-1] == incomplete:
            args = args[:-1]
    else:
        try:
            cword = int(os.environ.get("COMP_CWORD", "0"))
        except ValueError:
            cword = 0
        incomplete = words[cword] if 0 <= cword < len(words) else ""
        args = words[1:cword] if cword > 0 else []

    items = _complete(cli, prog_name, args, incomplete)
    echo(_format_items(items, shell), nl=False)
    sys.stdout.flush()
    return 0
