"""Terminal helpers: echo, styling, prompts, pager, progress, editor and launch."""

from __future__ import annotations

import getpass
import io
import os
import re
import shlex
import subprocess
import sys
import tempfile
import time
import typing as t
from contextlib import contextmanager

from ._state import get_current_context
from .exceptions import Abort
from .exceptions import UsageError

_ansi_re = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")

_COLOR_CODES = {
    "black": 0,
    "red": 1,
    "green": 2,
    "yellow": 3,
    "blue": 4,
    "magenta": 5,
    "cyan": 6,
    "white": 7,
    "reset": 9,
}


def unstyle(text: str) -> str:
    """Remove ANSI escape sequences from ``text``."""
    return _ansi_re.sub("", text)


def _color_code(color: t.Any, background: bool) -> str:
    base = 40 if background else 30
    if isinstance(color, str):
        if color == "reset":
            return "49" if background else "39"
        bright = color.startswith("bright_")
        name = color[len("bright_"):] if bright else color
        if name in _COLOR_CODES and name != "reset":
            code = base + _COLOR_CODES[name] + (60 if bright else 0)
            return str(code)
        raise ValueError(f"Unknown color {color!r}.")
    selector = "48" if background else "38"
    if isinstance(color, int) and not isinstance(color, bool) and 0 <= color <= 255:
        return f"{selector};5;{color}"
    if isinstance(color, (tuple, list)) and len(color) == 3:
        if all(isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color):
            return f"{selector};2;{color[0]};{color[1]};{color[2]}"
    raise ValueError(f"Unknown color {color!r}.")


_SWITCHES = [
    ("bold", 1, 22),
    ("dim", 2, 22),
    ("italic", 3, 23),
    ("underline", 4, 24),
    ("blink", 5, 25),
    ("reverse", 7, 27),
    ("strikethrough", 9, 29),
    ("overline", 53, 55),
]


def style(
    text: t.Any,
    fg: t.Any = None,
    bg: t.Any = None,
    bold: bool | None = None,
    dim: bool | None = None,
    underline: bool | None = None,
    overline: bool | None = None,
    italic: bool | None = None,
    blink: bool | None = None,
    reverse: bool | None = None,
    strikethrough: bool | None = None,
    reset: bool = True,
) -> str:
    """Wrap ``text`` in ANSI SGR sequences for the given colors and switches."""
    bits: list[str] = []
    if fg is not None:
        bits.append(f"\033[{_color_code(fg, False)}m")
    if bg is not None:
        bits.append(f"\033[{_color_code(bg, True)}m")
    values = {
        "bold": bold,
        "dim": dim,
        "underline": underline,
        "overline": overline,
        "italic": italic,
        "blink": blink,
        "reverse": reverse,
        "strikethrough": strikethrough,
    }
    for name, on_code, off_code in _SWITCHES:
        value = values.get(name)
        if value is not None:
            bits.append(f"\033[{on_code if value else off_code}m")
    text = str(text)
    if reset:
        text = text + "\033[0m"
    return "".join(bits) + text


def _isatty(stream: t.Any) -> bool:
    try:
        return bool(stream.isatty())
    except Exception:
        return False


def _is_interactive() -> bool:
    return _isatty(sys.stdin) or _isatty(sys.stdout)


def _should_strip_ansi(stream: t.Any, color: bool | None) -> bool:
    if color is None:
        ctx = get_current_context(silent=True)
        if ctx is not None:
            color = ctx.color
    if color is None:
        return not _isatty(stream)
    return not color


def _write_text(stream: t.Any, text: str) -> None:
    encoding = (getattr(stream, "encoding", None) or "").lower()
    buffer = getattr(stream, "buffer", None)
    if "ascii" in encoding and buffer is not None:
        # An ASCII-only stream cannot print ordinary Unicode; send UTF-8 bytes instead.
        stream.flush()
        buffer.write(text.encode("utf-8"))
        buffer.flush()
        return
    try:
        stream.write(text)
    except UnicodeEncodeError:
        if buffer is None:
            raise
        stream.flush()
        buffer.write(text.encode("utf-8"))
        buffer.flush()
        return
    stream.flush()


def _write_bytes(stream: t.Any, data: bytes) -> None:
    stream.flush()
    buffer = getattr(stream, "buffer", stream)
    buffer.write(data)
    buffer.flush()


def echo(
    message: t.Any = None,
    file: t.Any = None,
    nl: bool = True,
    err: bool = False,
    color: bool | None = None,
) -> None:
    """Write ``message`` to standard output, standard error, or ``file``.

    Styles are stripped when the stream is not a terminal unless ``color``
    forces them on or off. The active context's color flag is used when
    ``color`` is None.
    """
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, (bytes, bytearray)):
        data = bytes(message) + (b"\n" if nl else b"")
        _write_bytes(file, data)
        return
    text = str(message) + ("\n" if nl else "")
    if _should_strip_ansi(file, color):
        text = unstyle(text)
    _write_text(file, text)


_echo = echo


def secho(
    message: t.Any = None,
    file: t.Any = None,
    nl: bool = True,
    err: bool = False,
    color: bool | None = None,
    **styles: t.Any,
) -> None:
    """Style ``message`` and echo it in one step."""
    if message is not None and not isinstance(message, (bytes, bytearray)):
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


def _pager_command() -> str:
    return os.environ.get("PAGER") or "less"


def echo_via_pager(text_or_generator: t.Any, color: bool | None = None) -> None:
    """Write long text through the pager when the session is interactive."""
    if callable(text_or_generator):
        chunks: t.Iterable[t.Any] = text_or_generator()
    elif isinstance(text_or_generator, str):
        chunks = [text_or_generator]
    else:
        chunks = text_or_generator

    if not _is_interactive():
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return

    proc = subprocess.Popen(_pager_command(), shell=True, stdin=subprocess.PIPE)
    try:
        for chunk in chunks:
            text = str(chunk)
            if color is False:
                text = unstyle(text)
            proc.stdin.write(text.encode("utf-8"))  # type: ignore[union-attr]
            proc.stdin.flush()  # type: ignore[union-attr]
    except BrokenPipeError:
        pass
    finally:
        try:
            proc.stdin.close()  # type: ignore[union-attr]
        except BrokenPipeError:
            pass
        proc.wait()


@contextmanager
def get_pager_file(color: bool | None = None) -> t.Iterator[t.Any]:
    """Yield a writable text stream that goes to the pager when interactive."""
    if not _is_interactive():
        from .fileio import StdStream

        yield StdStream(sys.stdout)
        return
    proc = subprocess.Popen(_pager_command(), shell=True, stdin=subprocess.PIPE)
    stream = io.TextIOWrapper(proc.stdin, encoding="utf-8")  # type: ignore[arg-type]
    try:
        yield stream
    finally:
        try:
            stream.close()
        except BrokenPipeError:
            pass
        proc.wait()


class ProgressBar:
    """A progress bar that is also an iterator over the wrapped items."""

    def __init__(
        self,
        iterable: t.Iterable[t.Any] | None,
        length: int | None,
        label: str | None,
        hidden: bool,
    ) -> None:
        self.iter = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)  # type: ignore[arg-type]
            except TypeError:
                length = None
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.pos = 0
        self.start = time.time()
        self.is_tty = (not hidden) and _isatty(sys.stdout)

    def __enter__(self) -> ProgressBar:
        if not self.hidden and not self.is_tty and self.label:
            echo(self.label)
        self.render()
        return self

    def __exit__(self, *exc_info: object) -> None:
        if self.is_tty:
            echo()

    def __iter__(self) -> t.Iterator[t.Any]:
        if self.iter is None:
            raise TypeError("An iterable is required to iterate a progress bar.")
        for item in self.iter:
            yield item
            self.update(1)

    def update(self, n_steps: int, current_item: t.Any = None) -> None:
        self.pos += n_steps
        self.render()

    def render(self) -> None:
        if not self.is_tty:
            return
        width = 36
        if self.length:
            done = min(self.pos / self.length, 1.0)
            filled = int(done * width)
            bar = "#" * filled + "-" * (width - filled)
            elapsed = time.time() - self.start
            remaining = 0.0
            if self.pos:
                remaining = elapsed / self.pos * (self.length - self.pos)
            eta = f"{int(remaining) // 60:02d}:{int(remaining) % 60:02d}"
            line = f"{self.label}  [{bar}]  {self.pos}/{self.length}  eta {eta}"
        else:
            line = f"{self.label}  {self.pos}"
        sys.stdout.write("\r" + line)
        sys.stdout.flush()


def progressbar(
    iterable: t.Iterable[t.Any] | None = None,
    length: int | None = None,
    label: str | None = None,
    hidden: bool = False,
    **options: t.Any,
) -> ProgressBar:
    """Return a progress bar over ``iterable`` (or of ``length`` steps) as a context manager."""
    return ProgressBar(iterable, length, label, hidden)


def _read_line(hidden: bool = False) -> str:
    stream = sys.stdin
    if hidden and _isatty(stream):
        line = getpass.getpass("")
        return line
    if isinstance(stream, RunnerInput):
        line = stream.readline(echo=not hidden)
    else:
        line = stream.readline()
    if not line:
        raise EOFError
    return line.rstrip("\r\n")


class RunnerInput(io.StringIO):
    """Standard input for the in-process runner. Can echo what it reads."""

    def __init__(self, data: str, echo_out: t.Any = None, echo_stdin: bool = False) -> None:
        super().__init__(data)
        self.echo_out = echo_out
        self.echo_stdin = echo_stdin

    def readline(self, size: int = -1, echo: bool | None = None) -> str:  # type: ignore[override]
        line = super().readline(size)
        if echo is None:
            echo = self.echo_stdin
        if echo and line and self.echo_out is not None:
            self.echo_out.write(line)
        return line


def _prompt_input(text: str, err: bool, hide_input: bool) -> str:
    echo(text, nl=False, err=err)
    try:
        value = _read_line(hidden=hide_input)
    except (KeyboardInterrupt, EOFError):
        if hide_input:
            echo(err=err)
        raise Abort() from None
    if hide_input:
        echo(err=err)
    return value


def prompt(
    text: str,
    default: t.Any = None,
    hide_input: bool = False,
    confirmation_prompt: bool = False,
    type: t.Any = None,
    value_proc: t.Callable[[t.Any], t.Any] | None = None,
    prompt_suffix: str = ": ",
    show_default: bool = True,
    err: bool = False,
    show_choices: bool = True,
) -> t.Any:
    """Ask for a value, converting it with ``type``. Re-asks until a valid value is given."""
    from .param_types import convert_type

    ptype = convert_type(type, default)
    if value_proc is None:
        def value_proc(value: t.Any) -> t.Any:
            return ptype(value, None, None)

    prompt_text = text
    if default is not None and show_default:
        prompt_text += f" [{_display_default(default)}]"
    prompt_text += prompt_suffix

    while True:
        while True:
            value = _prompt_input(prompt_text, err, hide_input)
            if value:
                break
            if default is not None:
                value = default
                break
        try:
            result = value_proc(value)
        except UsageError as e:
            echo(f"Error: {e.format_message()}", err=True)
            continue
        if not confirmation_prompt:
            return result
        while True:
            value2 = _prompt_input("Repeat for confirmation: ", err, hide_input)
            if value2:
                break
        if value == value2:
            return result
        echo("Error: the two entered values do not match", err=True)


def _display_default(value: t.Any) -> str:
    if isinstance(value, (list, tuple)):
        return ", ".join(str(v) for v in value)
    if isinstance(value, bool):
        return "Y/n" if value else "y/N"
    return str(value)


def confirm(
    text: str,
    default: bool | None = False,
    abort: bool = False,
    prompt_suffix: str = ": ",
    show_default: bool = True,
    err: bool = False,
) -> bool:
    """Ask a yes/no question. An empty answer takes ``default``. Other answers re-ask."""
    if default is None:
        suffix = " [y/n]"
    elif default:
        suffix = " [Y/n]"
    else:
        suffix = " [y/N]"
    prompt_text = text + suffix + prompt_suffix
    while True:
        echo(prompt_text, nl=False, err=err)
        try:
            value = _read_line().strip().lower()
        except (KeyboardInterrupt, EOFError):
            raise Abort() from None
        if value in ("y", "yes"):
            rv = True
            break
        if value in ("n", "no"):
            rv = False
            break
        if value == "" and default is not None:
            rv = default
            break
        echo("Error: invalid input", err=True)
    if abort and not rv:
        raise Abort()
    return rv


def getchar(echo: bool = False) -> str:
    """Read one character. Interrupt and end-of-file keys raise distinct exceptions."""
    stream = sys.stdin
    if _isatty(stream) and os.name == "posix":
        import termios
        import tty

        fd = stream.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 1).decode("utf-8", "ignore")
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
    else:
        ch = stream.read(1)
    if ch == "":
        raise EOFError
    if ch == "\x03":
        raise KeyboardInterrupt
    if ch == "\x04":
        raise EOFError
    if echo:
        _echo(ch, nl=False)
    return ch


def pause(info: str | None = None, err: bool = False) -> None:
    """Print a message and wait for a key press when the session is interactive."""
    if not _is_interactive():
        return
    if info is None:
        info = "Press any key to continue..."
    echo(info, nl=False, err=err)
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass
    echo(err=err)


def edit(
    text: str | None = None,
    editor: str | None = None,
    env: t.Mapping[str, str] | None = None,
    require_save: bool = True,
    extension: str = ".txt",
    filename: str | None = None,
) -> str | None:
    """Open an editor on ``text`` (or on ``filename``) and return the saved text."""
    if editor is None:
        editor = (
            os.environ.get("VISUAL")
            or os.environ.get("EDITOR")
            or ("notepad" if sys.platform == "win32" else "vi")
        )
    original = text or ""
    if filename is None:
        fd, path = tempfile.mkstemp(suffix=extension)
        with os.fdopen(fd, "wb") as f:
            f.write(original.replace("\r\n", "\n").encode("utf-8"))
    else:
        path = filename
    run_env = dict(os.environ)
    if env:
        run_env.update(env)
    try:
        subprocess.call(shlex.split(editor) + [path], env=run_env)
        if filename is not None:
            return None
        with open(path, "rb") as f:
            rv = f.read().decode("utf-8", "replace")
        if require_save and rv == original.replace("\r\n", "\n"):
            return None
        return rv
    finally:
        if filename is None:
            try:
                os.unlink(path)
            except OSError:
                pass


def launch(url: str, wait: bool = False, locate: bool = False) -> int:
    """Open ``url`` or a path with the default application."""
    if sys.platform == "win32":
        os.startfile(url)  # type: ignore[attr-defined]
        return 0
    command = ["open"] if sys.platform == "darwin" else ["xdg-open"]
    try:
        proc = subprocess.Popen(
            command + [url],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0


def clear() -> None:
    """Clear the visible terminal. Does nothing when stdout is not a terminal."""
    if not _isatty(sys.stdout):
        return
    echo("\033[2J\033[H", nl=False)


def get_app_dir(app_name: str, roaming: bool = True, force_posix: bool = False) -> str:
    """Return the per-user configuration directory for ``app_name``."""
    home = os.path.expanduser("~")
    if sys.platform == "win32" and not force_posix:
        return os.path.join(os.environ.get("APPDATA", home), app_name)
    if sys.platform == "darwin" and not force_posix:
        return os.path.join(home, "Library", "Application Support", app_name)
    folder = re.sub(r"\s+", "-", app_name.lower())
    if force_posix:
        return os.path.join(home, "." + folder)
    return os.path.join(os.environ.get("XDG_CONFIG_HOME", os.path.join(home, ".config")), folder)


def format_filename(filename: t.Any, shorten: bool = False) -> str:
    """Return ``filename`` as printable text that encodes as strict UTF-8."""
    if isinstance(filename, (bytes, bytearray)):
        filename = os.fsdecode(bytes(filename))
    else:
        filename = os.fspath(filename)
    if shorten:
        filename = os.path.basename(filename)
    return filename.encode("utf-8", "backslashreplace").decode("utf-8")


def open_file(
    filename: str,
    mode: str = "r",
    encoding: str | None = None,
    errors: str | None = "strict",
    lazy: bool = False,
    atomic: bool = False,
) -> t.Any:
    """Open a file, or a standard stream for ``-``. Usable as a context manager."""
    from .fileio import open_file as _open_file

    return _open_file(filename, mode, encoding, errors, lazy=lazy, atomic=atomic)


def get_text_stdin(encoding: str | None = None, errors: str | None = None) -> t.Any:
    return sys.stdin


def get_text_stdout(encoding: str | None = None, errors: str | None = None) -> t.Any:
    return sys.stdout


def get_text_stderr(encoding: str | None = None, errors: str | None = None) -> t.Any:
    return sys.stderr


def get_binary_stdin() -> t.Any:
    return getattr(sys.stdin, "buffer", sys.stdin)


def get_binary_stdout() -> t.Any:
    return getattr(sys.stdout, "buffer", sys.stdout)


def get_binary_stderr() -> t.Any:
    return getattr(sys.stderr, "buffer", sys.stderr)
