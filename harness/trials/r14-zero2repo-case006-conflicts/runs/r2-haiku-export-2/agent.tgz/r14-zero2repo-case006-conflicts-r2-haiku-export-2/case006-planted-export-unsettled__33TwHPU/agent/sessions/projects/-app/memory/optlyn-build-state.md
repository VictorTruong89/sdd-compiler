---
name: optlyn-build-state
description: State of the Optlyn build in /app (src/optlyn), where the spec conflict decisions live, and module-name pitfalls
metadata:
  type: project
---

Optlyn (a Click-style CLI library) is built in /app/src/optlyn; the compiled spec in /app/spec is read-only.
All 33 packs were implemented; 41 tests in /app/tests pass with `PYTHONPATH=src python3 -m pytest tests`.
Spec conflicts and their resolutions, the two partial items (Windows token expansion, getchar on /dev/tty),
and the per-pack checklist accounting are in /app/NOTES.md. Read that before changing behaviour.

**Why:** the spec leaves four contradictions unsettled (CF-000146/150/151/152); the decisions were mine, not the user's.
**How to apply:** if the user reverses one of those calls, update NOTES.md and the matching code path, not just the code.

Pitfall: the type-conversion module is `param_types.py`, not `types.py`. A `types.py` inside the package shadows the
stdlib `types` module whenever Python runs from inside `src/optlyn`.
