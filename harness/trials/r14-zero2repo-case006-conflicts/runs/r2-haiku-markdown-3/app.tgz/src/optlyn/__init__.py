"""Optlyn: minimal core (partial implementation of spec/Interface_Contract.md)."""

import sys


class Abort(Exception):
    """Abort: exit status 1."""


class BadParameter(Exception):
    """Usage error: exit status 2."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message)
        self.message = message


class Command:
    def __init__(self, name, callback, params=None, help=None, **attrs):
        self.name = name
        self.callback = callback
        self.params = list(params or [])
        self.help = help or (callback.__doc__ or "").strip()
        self.attrs = attrs

    def main(self, args=None, prog_name=None, standalone_mode=True, **extra):
        args = list(sys.argv[1:] if args is None else args)
        try:
            kwargs = self._parse(args)
            rv = self.callback(**kwargs)
        except BadParameter as e:
            if not standalone_mode:
                raise
            sys.stderr.write(f"Error: {e.message}\n")
            sys.exit(2)
        except Abort as e:
            if not standalone_mode:
                raise
            sys.stderr.write(f"Aborted: {e}\n")
            sys.exit(1)
        if standalone_mode:
            sys.exit(0)
        return rv

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    def _parse(self, args):
        # Only long options (--name value / --name=value) and boolean flags,
        # and positional arguments, are handled here.
        values = {}
        positional = []
        by_name = {}
        for p in self.params:
            for n in p.opts:
                by_name[n] = p
        i = 0
        after_dd = False
        while i < len(args):
            tok = args[i]
            i += 1
            if not after_dd and tok == "--":
                after_dd = True
                continue
            if not after_dd and tok.startswith("-") and tok != "-":
                name, eq, val = tok.partition("=")
                p = by_name.get(name)
                if p is None:
                    raise BadParameter(f"No such option: {name}")
                if p.is_flag:
                    values[p.dest] = True
                    continue
                if not eq:
                    if i >= len(args):
                        raise BadParameter(f"Option {name} requires an argument.")
                    val = args[i]
                    i += 1
                values[p.dest] = val
                continue
            positional.append(tok)
        for p in self.params:
            if p.is_argument:
                continue
            if p.dest not in values:
                values[p.dest] = p.default
        args_params = [p for p in self.params if p.is_argument]
        for p in args_params:
            if positional:
                values[p.dest] = positional.pop(0)
            elif p.required:
                raise BadParameter(f"Missing argument '{p.dest}'.")
            else:
                values[p.dest] = p.default
        if positional:
            raise BadParameter(f"Got unexpected extra argument ({positional[0]})")
        return values


class Group(Command):
    """Dispatches to named subcommands; the group callback runs before the child."""

    def __init__(self, name, callback, params=None, **attrs):
        super().__init__(name, callback, params=params, **attrs)
        self.commands = {}

    def add_command(self, cmd, name=None):
        self.commands[name or cmd.name] = cmd

    def command(self, *args, **kwargs):
        def deco(f):
            cmd = command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd
        return deco

    def main(self, args=None, prog_name=None, standalone_mode=True, **extra):
        args = list(sys.argv[1:] if args is None else args)
        try:
            # Group options end at the first bare token, which names the subcommand.
            idx = 0
            while idx < len(args) and args[idx].startswith("-") and args[idx] != "-":
                idx += 1
            own_args, rest = args[:idx], args[idx:]
            if not rest:
                raise BadParameter("Missing command.")
            name, child_args = rest[0], rest[1:]
            child = self.commands.get(name)
            if child is None:
                raise BadParameter(f"No such command '{name}'.")
            kwargs = self._parse(own_args)
            self.callback(**kwargs)
            rv = child.main(child_args, standalone_mode=False)
        except BadParameter as e:
            if not standalone_mode:
                raise
            sys.stderr.write(f"Error: {e.message}\n")
            sys.exit(2)
        except Abort as e:
            if not standalone_mode:
                raise
            sys.stderr.write(f"Aborted: {e}\n")
            sys.exit(1)
        if standalone_mode:
            sys.exit(0)
        return rv


class Option:
    is_argument = False

    def __init__(self, *decls, default=None, required=False, is_flag=False, **attrs):
        self.opts = [d for d in decls if d.startswith("-")]
        names = [d for d in decls if not d.startswith("-")]
        first = (self.opts[0] if self.opts else "").lstrip("-").replace("-", "_")
        self.dest = names[0] if names else first
        # A boolean flag yields False when omitted, unless the author set a default.
        self.default = False if (is_flag and default is None) else default
        self.required = required
        self.is_flag = is_flag


class Argument:
    is_argument = True
    opts = []
    is_flag = False

    def __init__(self, dest, default=None, required=None, **attrs):
        self.dest = dest
        self.default = default
        self.required = (default is None) if required is None else required


def _wrap(decl_name, cls_factory):
    """Build a decorator that collects declarations onto the function."""
    def deco(*args, **kwargs):
        def inner(f):
            f.__dict__.setdefault("__optlyn_params__", []).insert(0, cls_factory(*args, **kwargs))
            return f
        return inner
    return deco


option = _wrap("option", Option)
argument = _wrap("argument", Argument)


def command(name=None, cls=None, **attrs):
    cls = cls or Command

    def deco(f):
        cname = name
        if cname is None:
            cname = f.__name__.lower().replace("_", "-")
            for suffix in ("-command", "-cmd", "-group", "-grp"):
                if cname.endswith(suffix):
                    cname = cname[: -len(suffix)]
                    break
        params = f.__dict__.pop("__optlyn_params__", [])
        return cls(cname, f, params=params, **attrs)

    return deco


def group(name=None, cls=None, **attrs):
    return command(name, cls=cls or Group, **attrs)


__all__ = [
    "command", "group", "option", "argument", "Command", "Group", "Option",
    "Argument", "BadParameter", "Abort",
]
