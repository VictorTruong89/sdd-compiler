"""Parameter types: value conversion, metavars and completion hooks."""

import datetime as _dt
import enum
import os
import stat
import typing as t
import uuid
import pathlib as _pathlib

from ._context import get_current_context
from .exceptions import BadParameter
from . import utils


class ParamType:
    """Base class for parameter types.

    Subclasses set ``name`` and implement :meth:`convert`, which receives the
    raw value and the parameter and context (either may be ``None``).
    """

    name = "text"
    is_composite = False
    envvar_list_splitter: t.Optional[str] = None

    def __call__(self, value: t.Any, param: t.Any = None, ctx: t.Any = None) -> t.Any:
        if value is None:
            return None
        return self.convert(value, param, ctx)

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> t.Any:
        return value

    def split_envvar_value(self, rv: str) -> t.List[str]:
        if self.envvar_list_splitter:
            return rv.split(self.envvar_list_splitter)
        return rv.split()

    def get_metavar(self, param: t.Any) -> t.Optional[str]:
        return None

    def shell_complete(self, ctx: t.Any, param: t.Any, incomplete: str) -> t.List[t.Any]:
        return []

    def fail(self, message: str, param: t.Any = None, ctx: t.Any = None) -> t.NoReturn:
        raise BadParameter(message, ctx=ctx, param=param)

    def __repr__(self) -> str:
        return self.name.upper()


class StringParamType(ParamType):
    name = "text"

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> str:
        if isinstance(value, str):
            return value
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        return str(value)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> t.Any:
        return value


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> int:
        if isinstance(value, int) and not isinstance(value, bool):
            return value
        if isinstance(value, float):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)
        try:
            return int(value)
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> float:
        if isinstance(value, float):
            return value
        try:
            return float(value)
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


_true_words = frozenset({"1", "true", "t", "yes", "y", "on"})
_false_words = frozenset({"0", "false", "f", "no", "n", "off"})


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> bool:
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _true_words:
            return True
        if text in _false_words:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> uuid.UUID:
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value))
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()


class FuncParamType(ParamType):
    """Adapts a conversion function ``f(token) -> value`` (refuses with ValueError)."""

    def __init__(self, func: t.Callable[[t.Any], t.Any]) -> None:
        self.func = func
        self.name = getattr(func, "__name__", "value")

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> t.Any:
        try:
            return self.func(value)
        except ValueError:
            self.fail(f"{value!r} is not a valid {self.name}.", param, ctx)


class Choice(ParamType):
    """A closed list of allowed values, or the member names of an enum."""

    name = "choice"

    def __init__(self, choices: t.Iterable[t.Any], case_sensitive: bool = True) -> None:
        self.choices = list(choices)
        self.case_sensitive = case_sensitive

    @staticmethod
    def _key(choice: t.Any) -> str:
        if isinstance(choice, enum.Enum):
            return choice.name
        return str(choice)

    def get_metavar(self, param: t.Any) -> str:
        return "[" + "|".join(self._key(c) for c in self.choices) + "]"

    def _norm(self, text: str, ctx: t.Any) -> str:
        if not self.case_sensitive:
            text = text.casefold()
        func = getattr(ctx, "token_normalize_func", None)
        if func is not None:
            text = func(text)
        return text

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> t.Any:
        for choice in self.choices:
            if choice is value:
                return choice
        normed = self._norm(str(value), ctx)
        for choice in self.choices:
            if self._norm(self._key(choice), ctx) == normed:
                return choice
        options = ", ".join(repr(self._key(c)) for c in self.choices)
        self.fail(f"{value!r} is not one of {options}.", param, ctx)

    def shell_complete(self, ctx: t.Any, param: t.Any, incomplete: str) -> t.List[str]:
        result = []
        for choice in self.choices:
            key = self._key(choice)
            if self._norm(key, ctx).startswith(self._norm(incomplete, ctx)):
                result.append(key)
        return result


class DateTime(ParamType):
    """Parses a date-time with the first matching ``strptime`` format."""

    name = "datetime"
    default_formats = ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S")

    def __init__(self, formats: t.Optional[t.Sequence[str]] = None) -> None:
        self.formats = list(formats) if formats is not None else list(self.default_formats)

    def get_metavar(self, param: t.Any) -> str:
        return "[" + "|".join(self.formats) + "]"

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> _dt.datetime:
        if isinstance(value, _dt.datetime):
            return value
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(str(value), fmt)
            except ValueError:
                continue
        self.fail(f"{value!r} does not match the formats {', '.join(self.formats)}.", param, ctx)


def _describe_range(min_v, max_v, min_open, max_open) -> str:
    parts = []
    if min_v is not None:
        parts.append(f"{'>' if min_open else '>='} {min_v}")
    if max_v is not None:
        parts.append(f"{'<' if max_open else '<='} {max_v}")
    return " and ".join(parts)


class IntRange(IntParamType):
    """An integer within an optional range; ``clamp`` replaces out-of-range values."""

    name = "integer range"

    def __init__(
        self,
        min: t.Optional[int] = None,
        max: t.Optional[int] = None,
        min_open: bool = False,
        max_open: bool = False,
        clamp: bool = False,
    ) -> None:
        if min is not None and max is not None and min > max:
            raise TypeError("IntRange min must not be greater than max.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> int:
        rv = super().convert(value, param, ctx)
        if self.clamp:
            if self.min is not None and (rv < self.min or (self.min_open and rv == self.min)):
                rv = self.min + 1 if self.min_open else self.min
            if self.max is not None and (rv > self.max or (self.max_open and rv == self.max)):
                rv = self.max - 1 if self.max_open else self.max
            return rv
        if self.min is not None and (rv < self.min or (self.min_open and rv == self.min)):
            self._out_of_range(rv, param, ctx)
        if self.max is not None and (rv > self.max or (self.max_open and rv == self.max)):
            self._out_of_range(rv, param, ctx)
        return rv

    def _out_of_range(self, rv, param, ctx):
        desc = _describe_range(self.min, self.max, self.min_open, self.max_open)
        self.fail(f"{rv} is not in the range {desc}.", param, ctx)


class FloatRange(FloatParamType):
    """A float within an optional range; clamp only with closed bounds."""

    name = "float range"

    def __init__(
        self,
        min: t.Optional[float] = None,
        max: t.Optional[float] = None,
        min_open: bool = False,
        max_open: bool = False,
        clamp: bool = False,
    ) -> None:
        if clamp and (min_open or max_open):
            raise TypeError("FloatRange cannot clamp when a bound is open.")
        if min is not None and max is not None and min > max:
            raise TypeError("FloatRange min must not be greater than max.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> float:
        rv = super().convert(value, param, ctx)
        if self.clamp:
            if self.min is not None and rv < self.min:
                rv = float(self.min)
            if self.max is not None and rv > self.max:
                rv = float(self.max)
            return rv
        if self.min is not None and (rv < self.min or (self.min_open and rv == self.min)):
            self._out_of_range(rv, param, ctx)
        if self.max is not None and (rv > self.max or (self.max_open and rv == self.max)):
            self._out_of_range(rv, param, ctx)
        return rv

    def _out_of_range(self, rv, param, ctx):
        desc = _describe_range(self.min, self.max, self.min_open, self.max_open)
        self.fail(f"{rv} is not in the range {desc}.", param, ctx)


class Tuple(ParamType):
    """A fixed-length product of types; one converted value per position."""

    name = "tuple"
    is_composite = True

    def __init__(self, types: t.Sequence[t.Any]) -> None:
        self.types = [convert_type(ty) for ty in types]

    def get_metavar(self, param: t.Any) -> str:
        return " ".join(ty.name.upper() for ty in self.types)

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> tuple:
        values = list(value)
        if len(values) != len(self.types):
            self.fail(f"{value!r} must have exactly {len(self.types)} values.", param, ctx)
        return tuple(ty(v, param, ctx) for ty, v in zip(self.types, values))


class File(ParamType):
    """Opens a file; the value delivered is an open file object."""

    name = "filename"
    envvar_list_splitter = os.pathsep

    def __init__(
        self,
        mode: str = "r",
        encoding: t.Optional[str] = None,
        errors: str = "strict",
        lazy: t.Optional[bool] = None,
        atomic: bool = False,
    ) -> None:
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"Unsupported file mode {mode!r}.")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> t.Any:
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        if ctx is None:
            ctx = get_current_context(silent=True)
        if value == "-":
            stream = utils._open_dash(self.mode, self.encoding, self.errors)
            if ctx is not None:
                ctx.call_on_close(lambda: utils.release_stream(stream))
            return utils.StdStreamProxy(stream)
        lazy = self.lazy if self.lazy is not None else ("w" in self.mode)
        try:
            if lazy:
                f = utils.LazyFile(value, self.mode, self.encoding, self.errors, self.atomic)
            else:
                f = utils._open_real(value, self.mode, self.encoding, self.errors, self.atomic)
        except OSError as e:
            self.fail(f"'{value}': {e.strerror or e}", param, ctx)
        if ctx is not None:
            ctx.call_on_close(f.close)
        return f


class Path(ParamType):
    """Validates a filesystem path and delivers it (not an open file)."""

    name = "path"
    envvar_list_splitter = os.pathsep

    def __init__(
        self,
        exists: bool = False,
        file_okay: bool = True,
        dir_okay: bool = True,
        writable: bool = False,
        readable: bool = True,
        resolve_path: bool = False,
        allow_dash: bool = False,
        path_type: t.Any = None,
        executable: bool = False,
    ) -> None:
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def get_metavar(self, param: t.Any) -> str:
        return "DIRECTORY" if self.dir_okay and not self.file_okay else "PATH"

    def _output(self, rv: str) -> t.Any:
        if self.path_type is _pathlib.Path or self.path_type is _pathlib.PurePath:
            return _pathlib.Path(rv)
        return rv

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> t.Any:
        rv = os.fspath(value) if hasattr(value, "__fspath__") else value
        if isinstance(rv, bytes):
            rv = os.fsdecode(rv)
        if self.allow_dash and rv == "-":
            return self._output(rv)
        if self.resolve_path:
            rv = os.path.realpath(rv)
        display = utils.format_filename(value)
        try:
            st = os.stat(rv)
        except OSError:
            if not self.exists:
                return self._output(rv)
            self.fail(f"{display!r} does not exist.", param, ctx)
        if not self.file_okay and stat.S_ISREG(st.st_mode):
            self.fail(f"{display!r} is a file.", param, ctx)
        if not self.dir_okay and stat.S_ISDIR(st.st_mode):
            self.fail(f"{display!r} is a directory.", param, ctx)
        if self.readable and not os.access(rv, os.R_OK):
            self.fail(f"{display!r} is not readable.", param, ctx)
        if self.writable and not os.access(rv, os.W_OK):
            self.fail(f"{display!r} is not writable.", param, ctx)
        if self.executable and not os.access(rv, os.X_OK):
            self.fail(f"{display!r} is not executable.", param, ctx)
        return self._output(rv)

    def shell_complete(self, ctx: t.Any, param: t.Any, incomplete: str) -> t.List[t.Any]:
        from .shell_completion import CompletionItem

        kind = "dir" if self.dir_okay and not self.file_okay else "file"
        return [CompletionItem(incomplete, type=kind)]


_builtin_types = {str: STRING, int: INT, float: FLOAT, bool: BOOL, uuid.UUID: UUID}


def _guess_type(default: t.Any) -> t.Optional[ParamType]:
    if default is None or callable(default):
        return None
    if isinstance(default, bool):
        return BOOL
    if isinstance(default, int):
        return INT
    if isinstance(default, float):
        return FLOAT
    if isinstance(default, (tuple, list)):
        if default:
            return _guess_type(default[0]) or STRING
        return STRING
    return None


def convert_type(ty: t.Any, default: t.Any = None) -> ParamType:
    """Return a :class:`ParamType` for ``ty``, guessing from ``default`` if needed."""
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, tuple):
        return Tuple(ty)
    if ty is None:
        return _guess_type(default) or STRING
    if isinstance(ty, type) and ty in _builtin_types:
        return _builtin_types[ty]
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"Unsupported parameter type {ty!r}.")
