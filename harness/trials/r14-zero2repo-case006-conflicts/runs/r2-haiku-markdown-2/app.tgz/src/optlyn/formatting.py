"""Text wrapping used by help pages and by ``wrap_text``."""

import textwrap


def wrap_text(
    text: str,
    width: int = 100,
    initial_indent: str = "",
    subsequent_indent: str = "",
    preserve_paragraphs: bool = False,
) -> str:
    """Rewrap ``text`` to ``width`` columns.

    Single newlines are not kept as hard breaks. With ``preserve_paragraphs``,
    blank-line separated paragraphs are wrapped one at a time and kept apart.
    """
    text = text or ""
    width = max(width, len(initial_indent) + 10, len(subsequent_indent) + 10)
    wrapper = textwrap.TextWrapper(
        width=width,
        initial_indent=initial_indent,
        subsequent_indent=subsequent_indent,
        break_long_words=False,
        break_on_hyphens=False,
        replace_whitespace=False,
        drop_whitespace=True,
    )
    if not preserve_paragraphs:
        return wrapper.fill(" ".join(text.split()))
    paragraphs = []
    for block in _split_paragraphs(text):
        paragraphs.append(wrapper.fill(" ".join(block.split())))
    return "\n\n".join(p for p in paragraphs if p)


def _split_paragraphs(text: str):
    current = []
    for line in text.splitlines():
        if not line.strip():
            if current:
                yield "\n".join(current)
                current = []
        else:
            current.append(line)
    if current:
        yield "\n".join(current)


def format_paragraphs(text: str, width: int) -> str:
    """Rewrap a help text block.

    A paragraph whose first line is a lone backspace is kept verbatim (its line
    breaks are preserved) and the backspace line itself is dropped.
    """
    if not text:
        return ""
    out = []
    for block in _split_paragraphs(text):
        lines = block.split("\n")
        if lines[0].strip() == "\b":
            out.append("\n".join(lines[1:]))
        else:
            out.append(textwrap.fill(
                " ".join(block.split()),
                width=max(width, 10),
                break_long_words=False,
                break_on_hyphens=False,
            ))
    return "\n\n".join(out)
