"""Invocation context, commands, groups, the argument parser and value resolution."""

import glob
import inspect
import os
import re
import shutil
import sys
import textwrap
import typing as t
from contextlib import ExitStack, contextmanager

from ._context import get_current_context, pop_context, push_context
from .exceptions import (
    Abort,
    BadArgumentUsage,
    BadOptionUsage,
    BadParameter,
    Exit,
    MissingParameter,
    NoArgsIsHelpError,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .formatting import format_paragraphs
from .parameters import Argument, Option, Parameter, ParameterSource, flag_from_env, split_env_value
from .termui import confirm, prompt
from .types import INT, ParamType
from .utils import echo

_INF = float("inf")


class _ChainSubcommand:
    """Value of ``ctx.invoked_subcommand`` on a chaining group (not a child name)."""

    def __repr__(self) -> str:
        return "<chain>"


CHAIN_SUBCOMMAND = _ChainSubcommand()


def _clean_help(text: t.Optional[str]) -> t.Optional[str]:
    if text is None:
        return None
    return inspect.cleandoc(text).split("\f", 1)[0]


def _wrap_width(ctx: "Context") -> int:
    if ctx.terminal_width is not None:
        return ctx.terminal_width
    detected = shutil.get_terminal_size((80, 24)).columns
    return min(detected, ctx.max_content_width or 80)


def _deprecation_warning(kind: str, label: str, deprecated: t.Any) -> None:
    message = f"DeprecationWarning: The {kind} {label} is deprecated."
    if isinstance(deprecated, str):
        message += f" {deprecated}"
    echo(message, err=True)


def _first_sentence(text: str) -> str:
    paragraph = " ".join(text.strip().split("\n\n")[0].split())
    match = re.search(r"[.!?](\s|$)", paragraph)
    if match:
        return paragraph[: match.start() + 1]
    return paragraph


def _render_rows(rows: t.Sequence[t.Tuple[str, str]], width: int) -> t.List[str]:
    if not rows:
        return []
    col = min(max(len(name) for name, _ in rows), 30)
    text_width = max(width - col - 6, 20)
    lines = []
    for name, help_text in rows:
        wrapped = textwrap.wrap(
            " ".join((help_text or "").split()),
            width=text_width,
            break_long_words=False,
            break_on_hyphens=False,
        ) or [""]
        if len(name) > col:
            lines.append(f"  {name}")
            lines += [" " * (col + 4) + line for line in wrapped]
        else:
            lines.append(f"  {name:<{col}}  {wrapped[0]}".rstrip())
            lines += [" " * (col + 4) + line for line in wrapped[1:]]
    return lines


def _option_names(param: Option) -> str:
    if param.secondary_opts:
        return ", ".join(param.opts) + " / " + ", ".join(param.secondary_opts)
    return ", ".join(param.opts)


class Context:
    """The state of one command invocation.

    Settings come from ``main(**extra)``, ``CliRunner.invoke(**extra)`` and the
    ``context_settings`` mapping of a command. Child contexts inherit unset
    settings from their parent.
    """

    def __init__(
        self,
        command: "Command",
        parent: t.Optional["Context"] = None,
        info_name: t.Optional[str] = None,
        obj: t.Any = None,
        auto_envvar_prefix: t.Optional[str] = None,
        default_map: t.Optional[t.Dict[str, t.Any]] = None,
        terminal_width: t.Optional[int] = None,
        max_content_width: t.Optional[int] = None,
        allow_extra_args: t.Optional[bool] = None,
        allow_interspersed_args: t.Optional[bool] = None,
        ignore_unknown_options: t.Optional[bool] = None,
        help_option_names: t.Optional[t.List[str]] = None,
        token_normalize_func: t.Optional[t.Callable[[str], str]] = None,
        color: t.Optional[bool] = None,
        show_default: t.Optional[bool] = None,
        resilient_parsing: bool = False,
        **extra: t.Any,
    ) -> None:
        self.command = command
        self.parent = parent
        self.info_name = info_name
        self.params: t.Dict[str, t.Any] = {}
        self.args: t.List[str] = []
        self.protected_args: t.List[str] = []
        self.invoked_subcommand: t.Any = None
        self._sources: t.Dict[str, ParameterSource] = {}
        self._depth = 0
        self._exit_stack = ExitStack()
        self.resilient_parsing = resilient_parsing

        def inherit(value: t.Any, attr: str) -> t.Any:
            if value is not None:
                return value
            return getattr(parent, attr) if parent is not None else None

        self.obj = obj if obj is not None else (parent.obj if parent is not None else None)
        if default_map is None and parent is not None and info_name is not None and parent.default_map is not None:
            default_map = parent.default_map.get(info_name)
        self.default_map = default_map
        self.terminal_width = inherit(terminal_width, "terminal_width")
        self.max_content_width = inherit(max_content_width, "max_content_width")
        self.color = inherit(color, "color")
        self.show_default = bool(inherit(show_default, "show_default"))
        self.help_option_names = list(inherit(help_option_names, "help_option_names") or ["--help"])
        self.token_normalize_func = inherit(token_normalize_func, "token_normalize_func")
        self.allow_extra_args = (
            allow_extra_args if allow_extra_args is not None else command.allow_extra_args
        )
        self.allow_interspersed_args = (
            allow_interspersed_args if allow_interspersed_args is not None else command.allow_interspersed_args
        )
        self.ignore_unknown_options = (
            ignore_unknown_options if ignore_unknown_options is not None else command.ignore_unknown_options
        )
        if auto_envvar_prefix is None and parent is not None and parent.auto_envvar_prefix and info_name:
            auto_envvar_prefix = f"{parent.auto_envvar_prefix}_{info_name}"
        if auto_envvar_prefix is not None:
            auto_envvar_prefix = auto_envvar_prefix.upper().replace("-", "_")
        self.auto_envvar_prefix = auto_envvar_prefix

    # Structure -------------------------------------------------------------

    @property
    def command_path(self) -> str:
        rv = self.info_name or ""
        if self.parent is not None:
            parent_path = self.parent.command_path
            rv = f"{parent_path} {rv}" if parent_path else rv
        return rv

    def find_root(self) -> "Context":
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type: type) -> t.Any:
        node: t.Optional[Context] = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type: type) -> t.Any:
        rv = self.find_object(object_type)
        if rv is None:
            self.obj = rv = object_type()
        return rv

    def get_parameter_source(self, name: str) -> t.Optional[ParameterSource]:
        return self._sources.get(name)

    def get_help(self) -> str:
        return self.command.get_help(self)

    def get_usage(self) -> str:
        return self.command.get_usage(self)

    # Control flow ----------------------------------------------------------

    def fail(self, message: str) -> t.NoReturn:
        raise UsageError(message, self)

    def exit(self, code: int = 0) -> t.NoReturn:
        raise Exit(code)

    def abort(self) -> t.NoReturn:
        raise Abort()

    def call_on_close(self, func: t.Callable[[], t.Any]) -> None:
        self._exit_stack.callback(func)

    def with_resource(self, cm: t.ContextManager[t.Any]) -> t.Any:
        return self._exit_stack.enter_context(cm)

    def close(self) -> None:
        self._exit_stack.close()
        self._exit_stack = ExitStack()

    @contextmanager
    def scope(self, cleanup: bool = True) -> t.Iterator["Context"]:
        """Make this context current on the calling thread for the block."""
        push_context(self)
        self._depth += 1
        try:
            yield self
        finally:
            self._depth -= 1
            pop_context()
            if cleanup and self._depth == 0:
                self.close()

    def __enter__(self) -> "Context":
        self._depth += 1
        push_context(self)
        return self

    def __exit__(self, exc_type: t.Any, exc: t.Any, tb: t.Any) -> None:
        self._depth -= 1
        pop_context()
        if self._depth == 0:
            self.close()

    def invoke(self, callback_: t.Any, /, *args: t.Any, **kwargs: t.Any) -> t.Any:
        """Run a callback or another command from inside this context."""
        if isinstance(callback_, Command):
            other = callback_
            if other.callback is None:
                raise TypeError("The given command does not have a callback that can be invoked.")
            sub = Context(other, info_name=other.name, parent=self)
            for param in other.get_params(sub):
                if param.expose_value and param.name not in kwargs:
                    kwargs[param.name] = param.get_default(sub)
            with sub.scope():
                return other.callback(*args, **kwargs)
        with self.scope(cleanup=False):
            return callback_(*args, **kwargs)

    def forward(self, cmd: t.Any, /, **kwargs: t.Any) -> t.Any:
        """Run ``cmd`` with this context's parameter values, overridden by ``kwargs``."""
        merged = {**self.params, **kwargs}
        return self.invoke(cmd, **merged)


class _Occ:
    """One occurrence of a parameter in the command line (or a supplied value)."""

    __slots__ = ("index", "items", "preset", "prompt")

    def __init__(
        self,
        index: float = 0,
        items: t.Optional[t.List[t.Any]] = None,
        preset: bool = False,
        prompt: bool = False,
    ) -> None:
        self.index = index
        self.items = items or []
        self.preset = preset
        self.prompt = prompt


class _OptionParser:
    """Splits an argument list into option occurrences and positional tokens."""

    def __init__(self, ctx: Context, params: t.Sequence[Parameter]) -> None:
        self.ctx = ctx
        self.interspersed = ctx.allow_interspersed_args
        # A group that mixes its options with the subcommand name passes
        # unknown option tokens on to the subcommand.
        self.ignore_unknown = ctx.ignore_unknown_options or (
            isinstance(ctx.command, Group) and self.interspersed
        )
        self.resilient = ctx.resilient_parsing
        self.normalize = ctx.token_normalize_func
        self._normalized: t.Optional[t.Dict[str, t.Tuple[Option, bool]]] = None
        self.opts: t.Dict[str, t.Tuple[Option, bool]] = {}
        self.prefixes = {"-"}
        self.occ: t.Dict[int, t.List[_Occ]] = {}
        self.positional: t.List[str] = []
        self._counter = 0
        for param in params:
            if not isinstance(param, Option):
                continue
            for name in param.opts:
                self.opts[name] = (param, False)
            for name in param.secondary_opts:
                self.opts[name] = (param, True)
            for name in param.all_names:
                self.prefixes.add(name[0])

    def _add(self, param: Parameter, occ: _Occ) -> None:
        self._counter += 1
        occ.index = self._counter
        self.occ.setdefault(id(param), []).append(occ)

    def _opt_like(self, token: str) -> bool:
        return len(token) > 1 and token[0] in self.prefixes

    def parse(self, args: t.Sequence[str]) -> t.Tuple[t.Dict[int, t.List[_Occ]], t.List[str]]:
        i = 0
        while i < len(args):
            token = args[i]
            if token == "--":
                self.positional.extend(args[i + 1 :])
                break
            if self._opt_like(token):
                i = self._handle(token, args, i)
                continue
            if not self.interspersed:
                self.positional.extend(args[i:])
                break
            self.positional.append(token)
            i += 1
        return self.occ, self.positional

    def _unknown(self, name: str, token: str, i: int) -> int:
        if self.ignore_unknown:
            self.positional.append(token)
            return i + 1
        if self.resilient:
            return i + 1
        raise NoSuchOption(name, self.ctx)

    def _lookup(self, name: str) -> t.Optional[t.Tuple[Option, bool]]:
        hit = self.opts.get(name)
        if hit is None and self.normalize is not None:
            if self._normalized is None:
                self._normalized = {self.normalize(key): value for key, value in self.opts.items()}
            hit = self._normalized.get(self.normalize(name))
        return hit

    def _handle(self, token: str, args: t.Sequence[str], i: int) -> int:
        name, eq, attached = token.partition("=")
        hit = self._lookup(name)
        if hit is not None:
            return self._take(hit, name, attached if eq else None, args, i)
        if len(token) > 1 and token[1] == token[0]:
            return self._unknown(name, token, i)
        prefix = token[0]
        stack = token[1:]
        j = 0
        while j < len(stack):
            key = prefix + stack[j]
            hit = self._lookup(key)
            if hit is None:
                if self.ignore_unknown:
                    self.positional.append(prefix + stack[j:])
                    return i + 1
                if self.resilient:
                    return i + 1
                raise NoSuchOption(key, self.ctx)
            if hit[0].is_flag:
                self._record_flag(hit)
                j += 1
                continue
            attached_value = stack[j + 1 :] or None
            return self._take(hit, key, attached_value, args, i)
        return i + 1

    def _record_flag(self, hit: t.Tuple[Option, bool]) -> None:
        param, secondary = hit
        if param.count:
            value: t.Any = 1
        elif secondary:
            value = not param.flag_value
        else:
            value = param.flag_value
        self._add(param, _Occ(items=[value], preset=True))

    def _take(
        self,
        hit: t.Tuple[Option, bool],
        key: str,
        attached: t.Optional[str],
        args: t.Sequence[str],
        i: int,
    ) -> int:
        param, _ = hit
        if param.is_flag:
            if attached is not None:
                raise BadOptionUsage(f"Option {key!r} does not take a value.", self.ctx)
            self._record_flag(hit)
            return i + 1
        j = i + 1
        if param.is_optional_value:
            if attached is not None:
                self._add(param, _Occ(items=[attached]))
            elif j < len(args) and not self._opt_like(args[j]):
                self._add(param, _Occ(items=[args[j]]))
                j += 1
            else:
                self._add(param, _Occ(items=[param.flag_value], preset=True))
            return j
        items: t.List[str] = []
        if attached is not None:
            items.append(attached)
        while len(items) < param.nargs and j < len(args):
            items.append(args[j])
            j += 1
        if len(items) < param.nargs:
            if param.prompted:
                self._add(param, _Occ(prompt=True))
                return j
            if self.resilient:
                return j
            raise BadOptionUsage(f"Option {key!r} requires an argument.", self.ctx)
        self._add(param, _Occ(items=items))
        return j


def _cast(ctx: t.Any, param: Parameter, ty: ParamType, value: t.Any) -> t.Any:
    try:
        return ty(value, param, ctx)
    except BadParameter as e:
        if e.param is None:
            e.param = param
        if e.ctx is None:
            e.ctx = ctx
        raise


def _convert_occ(ctx: Context, param: Parameter, occ: _Occ) -> t.Any:
    if occ.preset:
        return occ.items[0]
    if param.type.is_composite:
        return _cast(ctx, param, param.type, occ.items)
    if param.nargs == 1:
        return _cast(ctx, param, param.type, occ.items[0])
    return tuple(_cast(ctx, param, param.type, item) for item in occ.items)


def _shape(ctx: Context, param: Parameter, occs: t.List[_Occ]) -> t.Any:
    if not occs:
        return () if (param.multiple or param.nargs == -1) else None
    converted = [_convert_occ(ctx, param, occ) for occ in occs]
    if param.multiple:
        return tuple(converted)
    return converted[-1]


def _occs_from_env(param: Parameter, raw: str) -> t.List[_Occ]:
    n = param.nargs
    if not param.multiple and n == 1 and not param.type.is_composite:
        return [_Occ(items=[raw])]
    tokens = split_env_value(param, raw)
    if param.multiple and n > 0:
        return [_Occ(items=tokens[i : i + n]) for i in range(0, len(tokens), n)]
    return [_Occ(items=tokens)]


def _occs_from_value(ctx: Context, param: Parameter, value: t.Any) -> t.List[_Occ]:
    scalar = param.nargs == 1 and not param.type.is_composite
    if isinstance(value, str):
        if param.multiple and scalar:
            raise BadParameter("needs an iterable (sequence) default.", ctx, param)
        if scalar:
            return [_Occ(items=[value])]
        return _occs_from_env(param, value)
    if param.multiple:
        if not isinstance(value, (list, tuple)):
            raise BadParameter("needs an iterable (sequence) default.", ctx, param)
        if scalar:
            return [_Occ(items=[v]) for v in value]
        return [_Occ(items=list(v)) for v in value]
    if scalar:
        return [_Occ(items=[value])]
    return [_Occ(items=list(value) if isinstance(value, (list, tuple)) else [value])]


def _env_raw(ctx: Context, param: Parameter) -> t.Optional[str]:
    for name in param.get_envvar_names(ctx):
        raw = os.environ.get(name)
        if raw:
            return raw
    return None


def _map_lookup(ctx: Context, param: Parameter) -> t.Tuple[bool, t.Any]:
    dm = ctx.default_map
    if dm is not None and param.expose_value and param.name in dm:
        value = dm[param.name]
        if value is not None:
            return True, value
    return False, None


def _prompt_text(param: Parameter) -> str:
    return param.prompt or param.name.replace("_", " ").capitalize()


def _prompt_value(ctx: Context, param: Parameter) -> t.Any:
    found, value = _map_lookup(ctx, param)
    default = value if found else param.get_default(ctx)
    if isinstance(default, (list, tuple)):
        default = None
    return prompt(
        _prompt_text(param),
        default=default,
        hide_input=param.hide_input,
        confirmation_prompt=param.confirmation_prompt,
        type=param.type,
    )


def _warn_deprecated(param: Parameter, ctx: Context) -> None:
    if param.deprecated:
        kind = param.param_type_name
        _deprecation_warning(kind, param.get_error_hint(ctx), param.deprecated)


def _resolve_flag(ctx: Context, param: Option, occs: t.List[_Occ]) -> t.Tuple[t.Any, ParameterSource]:
    if occs:
        _warn_deprecated(param, ctx)
        return occs[-1].items[0], ParameterSource.COMMANDLINE
    raw = _env_raw(ctx, param)
    if raw is not None:
        supplied, value = flag_from_env(param, raw, ctx)
        if supplied:
            return value, ParameterSource.ENVIRONMENT
    if param.prompted and param.prompt_required and not ctx.resilient_parsing:
        default = param.get_default(ctx)
        text = param.prompt or param.name.replace("_", " ").capitalize()
        return confirm(text, default=bool(default)), ParameterSource.PROMPT
    found, value = _map_lookup(ctx, param)
    if found:
        if isinstance(value, str):
            value = _cast(ctx, param, param.type, value)
        return value, ParameterSource.DEFAULT_MAP
    default = param.get_default(ctx)
    return (False if default is None else default), ParameterSource.DEFAULT


def _resolve_count(ctx: Context, param: Option, occs: t.List[_Occ]) -> t.Tuple[t.Any, ParameterSource]:
    if occs:
        return sum(occ.items[0] for occ in occs), ParameterSource.COMMANDLINE
    raw = _env_raw(ctx, param)
    if raw is not None:
        return _cast(ctx, param, INT, raw), ParameterSource.ENVIRONMENT
    found, value = _map_lookup(ctx, param)
    if found:
        return _cast(ctx, param, INT, value), ParameterSource.DEFAULT_MAP
    default = param.get_default(ctx)
    return (0 if default is None else _cast(ctx, param, INT, default)), ParameterSource.DEFAULT


def _resolve_values(
    ctx: Context, param: Parameter, occs: t.List[_Occ]
) -> t.Tuple[t.List[_Occ], ParameterSource]:
    if any(occ.prompt for occ in occs):
        return [_Occ(items=[_prompt_value(ctx, param)], preset=True)], ParameterSource.PROMPT
    supplied = [occ for occ in occs if not occ.prompt]
    if supplied:
        _warn_deprecated(param, ctx)
        return supplied, ParameterSource.COMMANDLINE
    raw = _env_raw(ctx, param)
    if raw is not None:
        return _occs_from_env(param, raw), ParameterSource.ENVIRONMENT
    if isinstance(param, Option) and param.prompted and param.prompt_required and not ctx.resilient_parsing:
        return [_Occ(items=[_prompt_value(ctx, param)], preset=True)], ParameterSource.PROMPT
    found, value = _map_lookup(ctx, param)
    if found:
        return _occs_from_value(ctx, param, value), ParameterSource.DEFAULT_MAP
    default = param.get_default(ctx)
    if default is not None:
        return _occs_from_value(ctx, param, default), ParameterSource.DEFAULT
    if param.required and not ctx.resilient_parsing:
        raise MissingParameter(ctx=ctx, param=param)
    return [], ParameterSource.DEFAULT


def _resolve_param(ctx: Context, param: Parameter, occ: t.Dict[int, t.List[_Occ]]) -> t.Tuple[t.Any, ParameterSource]:
    occs = occ.get(id(param), [])
    if isinstance(param, Option) and param.is_flag:
        if param.count:
            return _resolve_count(ctx, param, occs)
        return _resolve_flag(ctx, param, occs)
    values, source = _resolve_values(ctx, param, occs)
    return _shape(ctx, param, values), source


def _resolve_group(ctx: Context, group: t.List[Parameter], occ: t.Dict[int, t.List[_Occ]]):
    """Pick the winning value among parameters that share one destination."""
    if len(group) == 1:
        return _resolve_param(ctx, group[0], occ)
    supplied = [(max(o.index for o in occ[id(p)]), p) for p in group if occ.get(id(p))]
    if supplied:
        winner = max(supplied, key=lambda pair: pair[0])[1]
    else:
        explicit = [p for p in group if p.default is not None]
        winner = (explicit or group)[-1]
    return _resolve_param(ctx, winner, occ)


def _run_callback(ctx: Context, param: Parameter, value: t.Any) -> t.Any:
    try:
        return param.callback(ctx, param, value)
    except BadParameter as e:
        if e.param is None:
            e.param = param
        if e.ctx is None:
            e.ctx = ctx
        raise


def _help_callback(ctx: Context, param: Parameter, value: t.Any) -> None:
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


def _make_auto_help_option(names: t.List[str]) -> Option:
    option = Option(
        names,
        is_flag=True,
        is_eager=True,
        expose_value=False,
        callback=_help_callback,
        help="Show this message and exit.",
    )
    option._is_help = True  # type: ignore[attr-defined]
    return option


class Command:
    """A leaf command: options, arguments and a callback."""

    allow_extra_args = False
    allow_interspersed_args = True
    ignore_unknown_options = False

    def __init__(
        self,
        name: t.Optional[str],
        context_settings: t.Optional[t.Dict[str, t.Any]] = None,
        callback: t.Optional[t.Callable[..., t.Any]] = None,
        params: t.Optional[t.List[Parameter]] = None,
        help: t.Optional[str] = None,
        epilog: t.Optional[str] = None,
        short_help: t.Optional[str] = None,
        options_metavar: t.Optional[str] = "[OPTIONS]",
        add_help_option: bool = True,
        no_args_is_help: bool = False,
        hidden: bool = False,
        deprecated: t.Any = False,
    ) -> None:
        self.name = name
        self.context_settings = dict(context_settings or {})
        self.callback = callback
        self.params: t.List[Parameter] = list(params or [])
        if help is None and callback is not None:
            help = callback.__doc__
        self.help = _clean_help(help)
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = deprecated

    def __repr__(self) -> str:
        return f"<{type(self).__name__} {self.name}>"

    def __call__(self, *args: t.Any, **kwargs: t.Any) -> t.Any:
        return self.main(*args, **kwargs)

    # Parameters ------------------------------------------------------------

    def get_params(self, ctx: Context) -> t.List[Parameter]:
        params = list(self.params)
        if self.add_help_option:
            used = {n for p in self.params if isinstance(p, Option) and not getattr(p, "_is_help", False)
                    for n in p.all_names}
            names = [n for n in ctx.help_option_names if n not in used]
            if names:
                params.append(_make_auto_help_option(names))
        return params

    # Parsing ---------------------------------------------------------------

    def make_context(
        self,
        info_name: t.Optional[str],
        args: t.Sequence[str],
        parent: t.Optional[Context] = None,
        **extra: t.Any,
    ) -> Context:
        for key, value in self.context_settings.items():
            extra.setdefault(key, value)
        ctx = Context(self, info_name=info_name, parent=parent, **extra)
        with ctx.scope(cleanup=False):
            self.parse_args(ctx, list(args))
        return ctx

    def parse_args(self, ctx: Context, args: t.List[str]) -> t.List[str]:
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsIsHelpError(ctx)
        params = self.get_params(ctx)
        parser = _OptionParser(ctx, params)
        occ, positional = parser.parse(args)
        leftover = self._bind_arguments(ctx, params, positional, occ)
        if leftover and not ctx.allow_extra_args and not ctx.resilient_parsing:
            names = " ".join(leftover)
            plural = "s" if len(leftover) > 1 else ""
            raise UsageError(f"Got unexpected extra argument{plural} ({names})", ctx)
        ctx.args = leftover
        self._process_params(ctx, params, occ)
        return leftover

    def _bind_arguments(
        self,
        ctx: Context,
        params: t.Sequence[Parameter],
        positional: t.List[str],
        occ: t.Dict[int, t.List[_Occ]],
    ) -> t.List[str]:
        arguments = [p for p in params if isinstance(p, Argument)]
        rest = list(positional)
        for position, arg in enumerate(arguments):
            if arg.nargs == -1:
                reserved = sum(a.nargs for a in arguments[position + 1 :] if a.nargs > 0)
                take = max(len(rest) - reserved, 0)
                items, rest = rest[:take], rest[take:]
                if items:
                    occ[id(arg)] = [_Occ(index=1_000_000 + position, items=items)]
                continue
            items, rest = rest[: arg.nargs], rest[arg.nargs :]
            if len(items) == arg.nargs:
                occ[id(arg)] = [_Occ(index=1_000_000 + position, items=items)]
            elif items and not ctx.resilient_parsing:
                raise BadArgumentUsage(f"Argument {arg.name!r} takes {arg.nargs} values.", ctx)
        return rest

    def _process_params(
        self, ctx: Context, params: t.Sequence[Parameter], occ: t.Dict[int, t.List[_Occ]]
    ) -> None:
        groups: t.Dict[t.Any, t.List[Parameter]] = {}
        for param in params:
            key = param.name if param.expose_value else id(param)
            groups.setdefault(key, []).append(param)

        def sort_key(item: t.Tuple[t.Any, t.List[Parameter]]):
            key, members = item
            indexes = [o.index for p in members for o in occ.get(id(p), [])]
            first = min(indexes) if indexes else _INF
            eager = any(p.is_eager for p in members)
            return (not eager, first, params.index(members[0]))

        for key, members in sorted(groups.items(), key=sort_key):
            value, source = _resolve_group(ctx, members, occ)
            for param in members:
                if param.callback is not None and not ctx.resilient_parsing:
                    value = _run_callback(ctx, param, value)
            if members[0].expose_value:
                ctx.params[members[0].name] = value
                ctx._sources[members[0].name] = source

    # Invocation ------------------------------------------------------------

    def invoke(self, ctx: Context) -> t.Any:
        if self.deprecated:
            _deprecation_warning("command", repr(ctx.info_name or self.name), self.deprecated)
        if self.callback is not None:
            return ctx.invoke(self.callback, **ctx.params)
        return None

    def main(
        self,
        args: t.Optional[t.Sequence[str]] = None,
        prog_name: t.Optional[str] = None,
        complete_var: t.Optional[str] = None,
        standalone_mode: bool = True,
        windows_expand_args: bool = True,
        **extra: t.Any,
    ) -> t.Any:
        if args is None:
            args = sys.argv[1:]
            if os.name == "nt" and windows_expand_args:
                args = _expand_args(args)
        else:
            args = list(args)
        if prog_name is None:
            prog_name = _detect_prog_name()
        if complete_var is None:
            complete_var = "_" + prog_name.upper().replace("-", "_") + "_COMPLETE"
        instruction = os.environ.get(complete_var)
        if instruction:
            from .shell_completion import shell_complete

            status = shell_complete(self, prog_name, complete_var, instruction)
            if standalone_mode:
                sys.exit(status)
            return status

        try:
            try:
                ctx = self.make_context(prog_name, args, **extra)
                try:
                    with ctx.scope():
                        rv = self.invoke(ctx)
                        if not standalone_mode:
                            return rv
                        ctx.exit()
                finally:
                    ctx.close()
            except (EOFError, KeyboardInterrupt) as e:
                echo(file=sys.stderr)
                raise Abort() from e
            except OptlynError as e:
                if not standalone_mode:
                    raise
                e.show()
                sys.exit(e.exit_code)
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return e.exit_code
        except Abort:
            if not standalone_mode:
                raise
            echo("Aborted!", file=sys.stderr)
            sys.exit(1)
        return None

    # Help ------------------------------------------------------------------

    def get_usage(self, ctx: Context) -> str:
        pieces = self._usage_pieces(ctx)
        line = " ".join([ctx.command_path] + [p for p in pieces if p])
        return f"Usage: {line}"

    def _usage_pieces(self, ctx: Context) -> t.List[str]:
        pieces = [self.options_metavar or ""]
        for arg in [p for p in self.get_params(ctx) if isinstance(p, Argument)]:
            pieces.append(self._argument_piece(arg))
        return pieces

    @staticmethod
    def _argument_piece(arg: Argument) -> str:
        meta = arg.get_metavar()
        if arg.nargs == -1:
            piece = f"{meta}..." if arg.required else f"[{meta}]..."
            return piece
        piece = " ".join([meta] * arg.nargs)
        return piece if arg.required else f"[{piece}]"

    def get_help(self, ctx: Context) -> str:
        return self.format_help(ctx)

    def get_short_help_str(self, limit: int = 45) -> str:
        text = self.short_help if self.short_help else _first_sentence(self.help or "")
        if len(text) > limit:
            text = text[: max(limit - 3, 0)].rstrip() + "..."
        return text

    def format_help(self, ctx: Context) -> str:
        width = _wrap_width(ctx)
        lines = [self.get_usage(ctx), ""]
        text = self.help or ""
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else None
            mark = "(DEPRECATED)" if note is None else f"(DEPRECATED: {note})"
            text = f"{mark} {text}".strip()
        if text:
            lines += [format_paragraphs(text, width), ""]
        lines += self._sections(ctx, width)
        if self.epilog:
            lines += [format_paragraphs(self.epilog, width), ""]
        return "\n".join(lines).rstrip() + "\n"

    def _sections(self, ctx: Context, width: int) -> t.List[str]:
        out: t.List[str] = []
        params = self.get_params(ctx)
        arg_rows = [
            (a.get_metavar(ctx), a.help)
            for a in params
            if isinstance(a, Argument) and a.help and not a.hidden
        ]
        if arg_rows:
            out += ["Positional arguments:"] + _render_rows(arg_rows, width) + [""]
        opt_rows = [
            (_option_names(o) + (f" {o.get_metavar(ctx)}" if o.get_metavar(ctx) else ""), self._option_help(ctx, o))
            for o in params
            if isinstance(o, Option) and not o.hidden
        ]
        if opt_rows:
            out += ["Options:"] + _render_rows(opt_rows, width) + [""]
        return out

    def _option_help(self, ctx: Context, param: Option) -> str:
        parts = []
        if param.help:
            parts.append(param.help)
        extras = []
        if param.deprecated:
            extras.append("DEPRECATED")
        if param.required:
            extras.append("required")
        show = param.show_default if param.show_default is not None else ctx.show_default
        if show:
            value = self._show_default_value(param, show)
            if value is not None:
                extras.append(f"default: {value}")
        if param.show_envvar:
            names = param.get_envvar_names(ctx)
            if names:
                extras.append("env var: " + ", ".join(names))
        if extras:
            parts.append("[" + "; ".join(extras) + "]")
        return " ".join(parts)

    @staticmethod
    def _show_default_value(param: Option, show: t.Any) -> t.Optional[str]:
        if isinstance(show, str):
            return show
        default = param.default
        if param.is_flag and not param.count and default is not True:
            return None
        if callable(default):
            return "(dynamic)"
        if default is None:
            return None
        if isinstance(default, (list, tuple)):
            return ", ".join(str(x) for x in default) or None
        return str(default)


class Group(Command):
    """A command that dispatches to named subcommands."""

    allow_extra_args = True
    allow_interspersed_args = False

    def __init__(
        self,
        name: t.Optional[str] = None,
        commands: t.Any = None,
        invoke_without_command: bool = False,
        no_args_is_help: t.Optional[bool] = None,
        subcommand_metavar: t.Optional[str] = None,
        chain: bool = False,
        result_callback: t.Optional[t.Callable[..., t.Any]] = None,
        **kwargs: t.Any,
    ) -> None:
        super().__init__(name, **kwargs)
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        self.no_args_is_help = no_args_is_help
        self.invoke_without_command = invoke_without_command
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback
        self.commands: t.Dict[str, Command] = {}
        if isinstance(commands, dict):
            self.commands.update(commands)
        elif commands:
            for cmd in commands:
                self.commands[cmd.name] = cmd

    # Subcommand registry -----------------------------------------------------

    def add_command(self, cmd: Command, name: t.Optional[str] = None) -> None:
        name = name or cmd.name
        if self.chain and isinstance(cmd, Group):
            raise TypeError("Cannot attach a group beneath a chaining group.")
        self.commands[name] = cmd

    def get_command(self, ctx: Context, cmd_name: str) -> t.Optional[Command]:
        return self.commands.get(cmd_name)

    def list_commands(self, ctx: Context) -> t.List[str]:
        return sorted(self.commands)

    def command(self, *args: t.Any, **kwargs: t.Any) -> t.Any:
        from .decorators import command as command_decorator

        if args and callable(args[0]) and not isinstance(args[0], str):
            cmd = command_decorator()(args[0])
            self.add_command(cmd)
            return cmd

        def decorator(f: t.Callable[..., t.Any]) -> Command:
            cmd = command_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args: t.Any, **kwargs: t.Any) -> t.Any:
        from .decorators import group as group_decorator

        if args and callable(args[0]) and not isinstance(args[0], str):
            grp = group_decorator()(args[0])
            self.add_command(grp)
            return grp

        def decorator(f: t.Callable[..., t.Any]) -> "Group":
            grp = group_decorator(*args, **kwargs)(f)
            self.add_command(grp)
            return grp

        return decorator

    def result_callback(self) -> t.Callable[[t.Callable[..., t.Any]], t.Callable[..., t.Any]]:
        def decorator(f: t.Callable[..., t.Any]) -> t.Callable[..., t.Any]:
            self._result_callback = f
            return f

        return decorator

    # Parsing -----------------------------------------------------------------

    def parse_args(self, ctx: Context, args: t.List[str]) -> t.List[str]:
        rest = super().parse_args(ctx, args)
        ctx.protected_args = rest[:1]
        ctx.args = rest[1:]
        return rest

    def resolve_command(self, ctx: Context, args: t.List[str]) -> t.Tuple[str, Command, t.List[str]]:
        cmd_name = args[0]
        cmd = self.get_command(ctx, cmd_name)
        if cmd is None and ctx.token_normalize_func is not None:
            wanted = ctx.token_normalize_func(cmd_name)
            for name in self.list_commands(ctx):
                if ctx.token_normalize_func(name) == wanted:
                    cmd_name = name
                    cmd = self.get_command(ctx, name)
                    break
        if cmd is None:
            raise UsageError(f"No such command {cmd_name!r}.", ctx)
        return cmd_name, cmd, list(args[1:])

    # Invocation --------------------------------------------------------------

    def invoke(self, ctx: Context) -> t.Any:
        def process_result(value: t.Any) -> t.Any:
            if self._result_callback is not None:
                value = ctx.invoke(self._result_callback, value, **ctx.params)
            return value

        if not ctx.protected_args:
            if self.invoke_without_command:
                with ctx.scope():
                    rv = super().invoke(ctx)
                    return process_result([] if self.chain else rv)
            raise UsageError("Missing command.", ctx)

        args = [*ctx.protected_args, *ctx.args]
        ctx.protected_args = []
        ctx.args = []

        if not self.chain:
            with ctx.scope():
                cmd_name, cmd, args = self.resolve_command(ctx, args)
                ctx.invoked_subcommand = cmd_name
                super().invoke(ctx)
                sub_ctx = cmd.make_context(cmd_name, args, parent=ctx)
                with sub_ctx.scope():
                    rv = sub_ctx.command.invoke(sub_ctx)
                return process_result(rv)

        with ctx.scope():
            ctx.invoked_subcommand = CHAIN_SUBCOMMAND
            super().invoke(ctx)
            contexts: t.List[Context] = []
            while args:
                cmd_name, cmd, args = self.resolve_command(ctx, args)
                sub_ctx = cmd.make_context(
                    cmd_name,
                    args,
                    parent=ctx,
                    allow_extra_args=True,
                    allow_interspersed_args=False,
                )
                contexts.append(sub_ctx)
                args, sub_ctx.args = sub_ctx.args, []
            results = []
            for sub_ctx in contexts:
                with sub_ctx.scope():
                    results.append(sub_ctx.command.invoke(sub_ctx))
            return process_result(results)

    # Help ------------------------------------------------------------------

    def _usage_pieces(self, ctx: Context) -> t.List[str]:
        pieces = super()._usage_pieces(ctx)
        meta = self.subcommand_metavar or "COMMAND"
        if self.chain:
            pieces.append(f"{meta} [ARGS]... [{meta} [ARGS]...]...")
        elif self.invoke_without_command:
            pieces.append(f"[{meta}] [ARGS]...")
        else:
            pieces.append(f"{meta} [ARGS]...")
        return pieces

    def _sections(self, ctx: Context, width: int) -> t.List[str]:
        out = super()._sections(ctx, width)
        rows = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            short = cmd.get_short_help_str(limit=max(width - 40, 16))
            if cmd.deprecated:
                short = f"(DEPRECATED) {short}".strip()
            rows.append((name, short))
        if rows:
            out += ["Commands:"] + _render_rows(rows, width) + [""]
        return out


class CommandCollection(Group):
    """Presents the subcommands of several source groups under one dispatch surface."""

    def __init__(self, name: t.Optional[str] = None, sources: t.Optional[t.List[Group]] = None, **kwargs: t.Any) -> None:
        super().__init__(name, **kwargs)
        self.sources: t.List[Group] = list(sources or [])

    def list_commands(self, ctx: Context) -> t.List[str]:
        names: t.Set[str] = set()
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx: Context, cmd_name: str) -> t.Optional[Command]:
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None


def _detect_prog_name() -> str:
    if sys.argv and sys.argv[0]:
        name = os.path.basename(sys.argv[0])
        if name.endswith(".py"):
            name = name[:-3]
        return name or "main"
    return "main"


def _expand_args(args: t.List[str]) -> t.List[str]:
    out: t.List[str] = []
    for arg in args:
        if any(c in arg for c in "*?["):
            matches = sorted(glob.glob(arg))
            out.extend(matches or [arg])
        else:
            out.append(arg)
    return out
