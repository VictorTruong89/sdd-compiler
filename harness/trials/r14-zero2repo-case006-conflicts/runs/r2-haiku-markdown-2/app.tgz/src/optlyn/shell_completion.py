"""Shell completion: registration scripts and suggestion output."""

import os
import typing as t

from .core import Command, Context, Group
from .parameters import Argument, Option
from .utils import echo

SHELLS = ("bash", "zsh", "fish", "powershell")


class CompletionItem:
    """A suggestion: a value, an optional help text and a kind.

    ``type`` is ``"plain"`` for an ordinary value, ``"file"`` or ``"dir"`` for a
    request that the shell complete a path.
    """

    def __init__(self, value: str, help: t.Optional[str] = None, type: str = "plain") -> None:
        self.value = str(value)
        self.help = help
        self.type = type

    def __repr__(self) -> str:
        return f"CompletionItem({self.value!r}, help={self.help!r}, type={self.type!r})"


def _as_item(raw: t.Any) -> CompletionItem:
    if isinstance(raw, CompletionItem):
        return raw
    if isinstance(raw, str):
        return CompletionItem(raw)
    return CompletionItem(raw.value, getattr(raw, "help", None), getattr(raw, "type", "plain") or "plain")


def _function_name(prog_name: str) -> str:
    return "_" + "".join(c if c.isalnum() else "_" for c in prog_name) + "_completion"


_BASH = """\
_FN_() {
    local IFS=$'\\n'
    local response
    response=$(env COMP_WORDS="${COMP_WORDS[*]}" COMP_CWORD=$COMP_CWORD VAR=bash_complete PROG 2>/dev/null)
    for completion in $response; do
        IFS=',' read type value <<< "$completion"
        if [[ $type == 'dir' ]]; then
            COMPREPLY=()
            compopt -o dirnames
        elif [[ $type == 'file' ]]; then
            COMPREPLY=()
            compopt -o default
        elif [[ $type == 'plain' ]]; then
            COMPREPLY+=("$value")
        fi
    done
    return 0
}
complete -o nosort -F _FN_ PROG
"""

_ZSH = """\
#compdef PROG
_FN_() {
    local -a response
    local line type value
    response=("${(@f)$(env COMP_WORDS="${words[*]}" COMP_CWORD=$((CURRENT-1)) VAR=zsh_complete PROG 2>/dev/null)}")
    for line in $response; do
        type="${line%%,*}"
        value="${${line#*,}%%$'\\t'*}"
        if [[ $type == 'plain' ]]; then
            compadd -d "${line#*$'\\t'}" -- "$value"
        elif [[ $type == 'dir' ]]; then
            _files -/
        elif [[ $type == 'file' ]]; then
            _files
        fi
    done
}
compdef _FN_ PROG
"""

_FISH = """\
function _FN_
    set -l response (env COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -ct) VAR=fish_complete PROG 2>/dev/null)
    for completion in $response
        set -l parts (string split -m 1 "," -- $completion)
        if test "$parts[1]" = "plain"
            echo $parts[2]
        else if test "$parts[1]" = "dir"
            __fish_complete_directories (commandline -ct)
        else if test "$parts[1]" = "file"
            __fish_complete_path (commandline -ct)
        end
    end
end
complete -c PROG -f -a '(_FN_)'
"""

_POWERSHELL = """\
Register-ArgumentCompleter -Native -CommandName 'PROG' -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)
    $env:COMP_WORDS = $commandAst.ToString()
    $env:COMP_CWORD = $wordToComplete.Length
    $env:VAR = 'powershell_complete'
    $response = & 'PROG' 2>$null
    Remove-Item Env:VAR
    foreach ($line in $response) {
        $parts = $line -split ',', 2
        if ($parts[0] -eq 'plain') {
            [System.Management.Automation.CompletionResult]::new($parts[1], $parts[1], 'ParameterValue', $parts[1])
        }
    }
}
"""

_TEMPLATES = {"bash": _BASH, "zsh": _ZSH, "fish": _FISH, "powershell": _POWERSHELL}


def source_script(shell: str, prog_name: str, complete_var: str) -> str:
    """Return the script that registers completion for ``prog_name`` in ``shell``."""
    return (
        _TEMPLATES[shell]
        .replace("_FN_", _function_name(prog_name))
        .replace("VAR=", f"{complete_var}=")
        .replace("PROG", prog_name)
    )


def _read_completion_words(shell: str) -> t.Tuple[t.List[str], str]:
    raw_words = os.environ.get("COMP_WORDS", "")
    cword = os.environ.get("COMP_CWORD", "")
    words = raw_words.split(" ")
    if shell == "fish":
        incomplete = cword
        if words and words[-1] == incomplete:
            words = words[:-1]
        return words[1:], incomplete
    try:
        index = int(cword)
    except ValueError:
        index = len(words)
    incomplete = words[index] if index < len(words) else ""
    return words[:index][1:], incomplete


def _prefix_chars(cmd: Command, ctx: Context) -> t.Set[str]:
    chars = {"-"}
    for param in cmd.get_params(ctx):
        if isinstance(param, Option):
            for name in param.all_names:
                chars.add(name[0])
    return chars


def _option_for_token(cmd: Command, ctx: Context, token: str) -> t.Optional[Option]:
    for param in cmd.get_params(ctx):
        if isinstance(param, Option) and token in param.all_names and not param.is_flag:
            return param
    return None


def _complete_option_names(cmd: Command, ctx: Context, incomplete: str) -> t.List[CompletionItem]:
    items = []
    for param in cmd.get_params(ctx):
        if not isinstance(param, Option) or param.hidden:
            continue
        for name in param.all_names:
            if name.startswith(incomplete):
                items.append(CompletionItem(name, param.help))
    return items


def _complete_positional(cmd: Command, ctx: Context, args: t.List[str], incomplete: str) -> t.List[CompletionItem]:
    arguments = [p for p in cmd.get_params(ctx) if isinstance(p, Argument)]
    prefixes = _prefix_chars(cmd, ctx)
    positional_count = 0
    skip_next = False
    for token in args:
        if skip_next:
            skip_next = False
            continue
        if len(token) > 1 and token[0] in prefixes:
            option = _option_for_token(cmd, ctx, token)
            if option is not None:
                skip_next = True
            continue
        positional_count += 1
    consumed = 0
    for arg in arguments:
        if arg.nargs == -1:
            return _complete_with(ctx, arg, incomplete)
        if positional_count < consumed + arg.nargs:
            return _complete_with(ctx, arg, incomplete)
        consumed += arg.nargs
    return []


def _complete_with(ctx: Context, param: Argument, incomplete: str) -> t.List[CompletionItem]:
    return [_as_item(item) for item in param.shell_complete(ctx, incomplete)]


def _resolve(cli: Command, prog_name: str, args: t.List[str]) -> t.Tuple[Command, Context, t.List[str]]:
    """Walk the command tree with resilient parsing, returning the final command."""
    ctx = cli.make_context(prog_name, args, resilient_parsing=True)
    cmd: Command = cli
    rest = list(args)
    while isinstance(cmd, Group) and ctx.protected_args:
        name = ctx.protected_args[0]
        sub = cmd.get_command(ctx, name)
        if sub is None:
            break
        rest = ctx.protected_args[1:] + ctx.args
        ctx = sub.make_context(name, rest, parent=ctx, resilient_parsing=True)
        cmd = sub
    return cmd, ctx, rest


def get_completions(cli: Command, prog_name: str, args: t.List[str], incomplete: str) -> t.List[CompletionItem]:
    """Return the suggestions for ``incomplete`` after the words ``args``."""
    cmd, ctx, final_args = _resolve(cli, prog_name, args)
    prefixes = _prefix_chars(cmd, ctx)
    if final_args and not incomplete.startswith(tuple(prefixes)):
        option = _option_for_token(cmd, ctx, final_args[-1])
        if option is not None:
            if option.shell_complete_func is not None or option.type is not None:
                return [_as_item(item) for item in option.shell_complete(ctx, incomplete)]
    if incomplete[:1] in prefixes and incomplete:
        return [i for i in _complete_option_names(cmd, ctx, incomplete) if i.value.startswith(incomplete)]
    if isinstance(cmd, Group) and not ctx.protected_args:
        items = []
        for name in cmd.list_commands(ctx):
            sub = cmd.get_command(ctx, name)
            if sub is None or sub.hidden or not name.startswith(incomplete):
                continue
            items.append(CompletionItem(name, sub.get_short_help_str(limit=60)))
        return items
    if isinstance(cmd, Group):
        return []
    return _complete_positional(cmd, ctx, final_args, incomplete)


def shell_complete(cli: Command, prog_name: str, complete_var: str, instruction: str) -> int:
    """Handle a completion instruction. Returns the process status (0 on success)."""
    shell, _, mode = instruction.rpartition("_")
    if shell not in SHELLS or mode not in ("source", "complete"):
        return 1
    if mode == "source":
        echo(source_script(shell, prog_name, complete_var))
        return 0
    args, incomplete = _read_completion_words(shell)
    for item in get_completions(cli, prog_name, args, incomplete):
        line = f"{item.type},{item.value}"
        if item.help and shell in ("zsh", "fish"):
            line += "\t" + " ".join(str(item.help).split())
        echo(line)
    return 0
