"""Option and argument declarations (the ``Parameter`` family)."""

import enum
import re
import typing as t

from .exceptions import BadParameter
from .types import BOOL, INT, ParamType, Tuple, convert_type


class ParameterSource(enum.Enum):
    """Where a parameter's value came from."""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


_prefix_re = re.compile(r"^[^A-Za-z0-9_]+")


def _is_flag_decl(decl: str) -> bool:
    return bool(decl) and not (decl[0].isalnum() or decl[0] == "_")


def _strip_prefix(decl: str) -> str:
    return _prefix_re.sub("", decl)


class Parameter:
    """Common state of options and arguments."""

    param_type_name = "parameter"
    is_argument = False

    def __init__(
        self,
        param_decls: t.Sequence[str],
        type: t.Any = None,
        required: t.Optional[bool] = False,
        default: t.Any = None,
        callback: t.Optional[t.Callable[..., t.Any]] = None,
        nargs: t.Optional[int] = None,
        multiple: bool = False,
        metavar: t.Optional[str] = None,
        expose_value: bool = True,
        is_eager: bool = False,
        envvar: t.Any = None,
        shell_complete: t.Optional[t.Callable[..., t.Any]] = None,
        deprecated: t.Any = False,
        help: t.Optional[str] = None,
        hidden: bool = False,
    ) -> None:
        self.opts: t.List[str] = []
        self.secondary_opts: t.List[str] = []
        self.name: str = ""
        self.default = default
        self.callback = callback
        self.multiple = multiple
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        self.shell_complete_func = shell_complete
        self.deprecated = deprecated
        self.help = help
        self.hidden = hidden
        self.is_flag = False
        self.count = False
        self.flag_value: t.Any = None
        self.prompt: t.Optional[str] = None
        self.prompted = False
        self.prompt_required = True
        self.hide_input = False
        self.confirmation_prompt = False
        self.required = bool(required)
        self.type_given = type is not None
        self._parse_decls(param_decls)
        if isinstance(envvar, str):
            envvar = [envvar]
        self.envvar: t.Optional[t.List[str]] = list(envvar) if envvar else None
        self.nargs = nargs if nargs is not None else 1
        self.type: ParamType = convert_type(type, default)
        if isinstance(self.type, Tuple):
            self.nargs = len(self.type.types)

    def _parse_decls(self, decls: t.Sequence[str]) -> None:
        raise NotImplementedError

    def get_default(self, ctx: t.Any, call: bool = True) -> t.Any:
        value = self.default
        if call and callable(value):
            value = value()
        return value

    def get_error_hint(self, ctx: t.Any = None) -> str:
        raise NotImplementedError

    def get_metavar(self, ctx: t.Any = None) -> t.Optional[str]:
        return self.metavar

    def get_envvar_names(self, ctx: t.Any) -> t.List[str]:
        return list(self.envvar) if self.envvar else []

    def shell_complete(self, ctx: t.Any, incomplete: str) -> t.List[t.Any]:
        if self.shell_complete_func is not None:
            return list(self.shell_complete_func(ctx, self, incomplete))
        return list(self.type.shell_complete(ctx, self, incomplete))

    def __repr__(self) -> str:
        return f"<{type(self).__name__} {self.name}>"


class Option(Parameter):
    """A named parameter introduced by a prefix such as ``-`` or ``--``."""

    param_type_name = "option"

    def __init__(
        self,
        param_decls: t.Sequence[str],
        show_default: t.Any = None,
        prompt: t.Any = False,
        confirmation_prompt: bool = False,
        prompt_required: bool = True,
        hide_input: bool = False,
        is_flag: t.Optional[bool] = None,
        flag_value: t.Any = None,
        count: bool = False,
        allow_from_autoenv: bool = True,
        show_envvar: bool = False,
        **kwargs: t.Any,
    ) -> None:
        super().__init__(param_decls, **kwargs)
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.allow_from_autoenv = allow_from_autoenv
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.prompt_required = prompt_required
        self.prompted = bool(prompt)
        if prompt and isinstance(prompt, str):
            self.prompt = prompt

        if count:
            is_flag = True
        if is_flag is None:
            is_flag = bool(self.secondary_opts) or flag_value is not None or isinstance(self.default, bool)
        self.is_flag = bool(is_flag)
        self.count = bool(count)

        if self.is_flag:
            if self.count:
                self.flag_value = 1
                if not self.type_given:
                    self.type = INT
                if self.default is None:
                    self.default = 0
            else:
                if flag_value is not None:
                    self.flag_value = flag_value
                elif self.secondary_opts:
                    self.flag_value = True
                else:
                    self.flag_value = True if self.default is None else not bool(self.default)
                if self.default is None:
                    self.default = False
                if not self.type_given:
                    self.type = BOOL if isinstance(self.flag_value, bool) else convert_type(None, self.flag_value)
        else:
            self.flag_value = flag_value

        if self.deprecated and self.required:
            raise TypeError("A deprecated option cannot also be required.")
        if self.deprecated and self.prompted:
            raise TypeError("A deprecated option cannot use a prompt.")
        if self.nargs < 1:
            raise TypeError("nargs must be a positive integer.")
        if self.is_flag and self.nargs != 1:
            raise TypeError("A flag cannot take a nargs value.")

    @property
    def is_optional_value(self) -> bool:
        """True for an option whose value may be omitted (``flag_value`` given)."""
        return not self.is_flag and self.flag_value is not None

    @property
    def all_names(self) -> t.List[str]:
        return self.opts + self.secondary_opts

    def _parse_decls(self, decls: t.Sequence[str]) -> None:
        explicit_name = None
        for decl in decls:
            if not decl:
                raise TypeError("Empty option declaration.")
            if _is_flag_decl(decl):
                if "/" in decl and decl[0] != "/":
                    first, second = decl.split("/", 1)
                    self.opts.append(first)
                    self.secondary_opts.append(second)
                else:
                    self.opts.append(decl)
            else:
                if explicit_name is not None:
                    raise TypeError("An option declares at most one destination name.")
                explicit_name = decl
        if explicit_name is not None:
            if not explicit_name.isidentifier():
                raise TypeError(f"{explicit_name!r} is not a valid destination name.")
            self.name = explicit_name
            return
        if not self.opts:
            raise TypeError("An option needs at least one flag name or a destination name.")
        names = self.all_names
        longs = [n for n in names if len(n) > 2 and n[0] == n[1]]
        for candidate in longs + [n for n in names if n not in longs]:
            name = _strip_prefix(candidate).replace("-", "_")
            if name.isidentifier():
                self.name = name
                return
        raise TypeError(f"Cannot derive a destination name from {list(decls)!r}.")

    def get_error_hint(self, ctx: t.Any = None) -> str:
        return " / ".join(f"'{n}'" for n in self.all_names)

    def get_envvar_names(self, ctx: t.Any) -> t.List[str]:
        if self.envvar:
            return list(self.envvar)
        prefix = getattr(ctx, "auto_envvar_prefix", None)
        if prefix and self.allow_from_autoenv:
            return [f"{prefix}_{self.name}".upper().replace("-", "_")]
        return []

    def get_metavar(self, ctx: t.Any = None) -> t.Optional[str]:
        if self.metavar is not None:
            return self.metavar
        if self.is_flag:
            return None
        meta = self.type.get_metavar(self)
        return meta if meta is not None else self.type.name.upper()


class Argument(Parameter):
    """A positional parameter; ``nargs=-1`` makes it variadic."""

    param_type_name = "argument"
    is_argument = True

    def __init__(
        self,
        param_decls: t.Sequence[str],
        nargs: t.Optional[int] = None,
        required: t.Optional[bool] = None,
        **kwargs: t.Any,
    ) -> None:
        if nargs is None:
            nargs = 1
        if required is None:
            required = kwargs.get("default") is None and nargs != -1
        super().__init__(param_decls, nargs=nargs, required=required, **kwargs)
        if self.nargs != -1 and self.nargs < 1:
            raise TypeError("nargs must be a positive integer or -1.")
        if self.deprecated and self.required:
            raise TypeError("A deprecated argument cannot be required.")

    def _parse_decls(self, decls: t.Sequence[str]) -> None:
        if len(decls) != 1:
            raise TypeError("An argument takes exactly one destination name.")
        name = decls[0]
        if _is_flag_decl(name) or not name.replace("-", "_").isidentifier():
            raise TypeError(f"{name!r} is not a valid argument name.")
        self.name = name.replace("-", "_")

    def get_error_hint(self, ctx: t.Any = None) -> str:
        return f"'{self.name}'"

    def get_metavar(self, ctx: t.Any = None) -> str:
        return self.metavar if self.metavar is not None else self.name.upper()


def split_env_value(param: Parameter, raw: str) -> t.List[str]:
    """Split an environment or default-map string with the parameter type's splitter."""
    return param.type.split_envvar_value(raw)


_true_env = frozenset({"true", "1", "yes", "on", "t", "y"})
_false_env = frozenset({"false", "0", "no", "off", "f", "n"})


def flag_from_env(param: Parameter, raw: str, ctx: t.Any = None) -> t.Tuple[bool, t.Any]:
    """Interpret an environment value for a flag.

    Returns ``(supplied, value)``. An empty value (or, for a non-boolean flag,
    text that is not recognized) leaves the flag unset. A whitespace-only value
    deactivates a boolean flag. Any other unrecognized text for a boolean flag
    is a usage error.
    """
    if raw == "":
        return False, None
    is_bool = isinstance(param.flag_value, bool) or param.flag_value is None
    if not is_bool and raw == str(param.flag_value):
        return True, param.flag_value
    text = raw.strip().lower()
    if not text:
        return (True, False) if is_bool else (False, None)
    if text in _true_env:
        return True, True if is_bool else param.flag_value
    if text in _false_env:
        return True, False
    if not is_bool:
        return False, None
    raise BadParameter(f"{raw!r} is not a valid boolean.", ctx=ctx, param=param)
