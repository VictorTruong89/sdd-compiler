"""Interactive terminal helpers: prompts, confirmation, single keys, pager, progress."""

import os
import shlex
import subprocess
import sys
import tempfile
import time
import typing as t
from contextlib import contextmanager

from .exceptions import Abort, BadParameter
from .types import convert_type
from .utils import echo


def _is_tty(stream: t.Any) -> bool:
    try:
        return bool(stream.isatty())
    except Exception:
        return False


def is_interactive() -> bool:
    """True when standard input is a terminal, or standard input or output is one."""
    return _is_tty(sys.stdin) or _is_tty(sys.stdout)


def _read_line(hidden: bool) -> str:
    stream = sys.stdin
    if hidden and _is_tty(stream):
        import getpass

        try:
            return getpass.getpass("")
        except (EOFError, KeyboardInterrupt):
            raise
    line = stream.readline()
    if line == "":
        raise EOFError
    return line.rstrip("\r\n")


def _prompt_line(text: str, hide_input: bool, err: bool) -> str:
    stream = sys.stderr if err else sys.stdout
    echo(text, nl=False, err=err)
    try:
        value = _read_line(hide_input)
    except (EOFError, KeyboardInterrupt) as e:
        echo(file=stream, err=err)
        raise Abort() from e
    if hide_input:
        if not _is_tty(sys.stdin):
            echo(file=stream, err=err)
    elif not _is_tty(sys.stdin) and not getattr(sys.stdin, "echoes_input", False):
        echo(value, err=err)
    return value


def prompt(
    text: str,
    default: t.Any = None,
    hide_input: bool = False,
    confirmation_prompt: bool = False,
    type: t.Any = None,
    value_proc: t.Any = None,
    prompt_suffix: str = ": ",
    show_default: bool = True,
    err: bool = False,
    show_choices: bool = True,
) -> t.Any:
    """Ask for a value, converting it with ``type`` and re-asking on failure."""
    ptype = convert_type(type, default)
    shown = text
    if default is not None and show_default and not hide_input:
        shown = f"{text} [{default}]"
    while True:
        value = _prompt_line(shown + prompt_suffix, hide_input, err)
        if value == "":
            if default is None:
                continue
            value = default
        try:
            result = ptype(value, None, None)
        except BadParameter as e:
            echo(f"Error: {e.message}", err=True)
            continue
        if confirmation_prompt:
            other = _prompt_line("Repeat for confirmation" + prompt_suffix, hide_input, err)
            if other != value and str(other) != str(value):
                echo("Error: The two entered values do not match.", err=True)
                continue
        return result


_yes = frozenset({"y", "yes"})
_no = frozenset({"n", "no"})


def confirm(
    text: str,
    default: bool = False,
    abort: bool = False,
    prompt_suffix: str = ": ",
    show_default: bool = True,
    err: bool = False,
) -> bool:
    """Ask a yes/no question. An empty answer takes ``default``; others re-ask."""
    marker = "[Y/n]" if default else "[y/N]"
    shown = f"{text} {marker}" if show_default else text
    while True:
        value = _prompt_line(shown + prompt_suffix, False, err).strip().lower()
        if value == "":
            result = default
            break
        if value in _yes:
            result = True
            break
        if value in _no:
            result = False
            break
        echo("Error: invalid input", err=True)
    if abort and not result:
        raise Abort()
    return result


def _read_tty_char() -> t.Optional[str]:
    """Read one raw character from /dev/tty; ``None`` when there is no terminal."""
    try:
        import termios
        import tty
    except ImportError:
        return None
    try:
        fd = os.open("/dev/tty", os.O_RDONLY)
    except OSError:
        return None
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            return os.read(fd, 1).decode("utf-8", "replace")
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
    except (OSError, termios.error):
        return None
    finally:
        os.close(fd)


def getchar(echo_char: bool = False) -> str:
    """Read one character from the controlling terminal.

    When standard input has been replaced (for example by the in-process
    runner) or there is no terminal, the character is read from standard input.
    """
    char = None
    if sys.stdin is sys.__stdin__:
        char = _read_tty_char()
    if char is None:
        char = sys.stdin.read(1)
    if char == "":
        raise EOFError
    if char == "\x03":
        raise KeyboardInterrupt
    if char == "\x04":
        raise EOFError
    if echo_char:
        echo(char, nl=False)
    return char


def pause(info: t.Optional[str] = None, err: bool = False) -> None:
    """Wait for a key press when the session is interactive; otherwise return at once."""
    if not is_interactive():
        return
    echo(info or "Press any key to continue...", nl=False, err=err)
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass
    echo(err=err)


def clear() -> None:
    """Clear the terminal screen (does nothing when standard output is not a terminal)."""
    if not _is_tty(sys.stdout):
        return
    sys.stdout.write("\033[2J\033[H")
    sys.stdout.flush()


def edit(
    text: t.Optional[str] = None,
    editor: t.Optional[str] = None,
    env: t.Optional[t.Dict[str, str]] = None,
    require_save: bool = True,
    extension: str = ".txt",
    filename: t.Optional[str] = None,
) -> t.Optional[str]:
    """Open an editor on ``text`` (or on ``filename``) and return the saved text."""
    command = editor or (env or {}).get("EDITOR") or os.environ.get("EDITOR")
    if not command:
        command = "notepad" if sys.platform.startswith("win") else "vi"
    if filename is not None:
        subprocess.call(shlex.split(command) + [filename])
        return None
    with tempfile.NamedTemporaryFile("w+", suffix=extension, delete=False, encoding="utf-8") as handle:
        path = handle.name
        handle.write(text or "")
    try:
        subprocess.call(shlex.split(command) + [path])
        with open(path, encoding="utf-8") as handle:
            result = handle.read()
    finally:
        os.remove(path)
    if require_save and result == (text or ""):
        return None
    return result


def launch(url: str, wait: bool = False, locate: bool = False) -> int:
    """Open ``url`` or a file with the default application; returns a status."""
    if sys.platform.startswith("win"):
        os.startfile(url)  # type: ignore[attr-defined]
        return 0
    if sys.platform == "darwin":
        args = ["open"]
        if wait:
            args.append("-W")
        if locate:
            args.append("-R")
    else:
        args = ["xdg-open"]
    args.append(url)
    try:
        proc = subprocess.Popen(args)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0


class ProgressBar:
    """A progress bar that wraps an iterable and/or tracks explicit steps."""

    def __init__(
        self,
        iterable: t.Any = None,
        length: t.Optional[int] = None,
        label: t.Optional[str] = None,
        hidden: bool = False,
        file: t.Any = None,
        width: int = 36,
        **options: t.Any,
    ) -> None:
        self.iterable = iterable
        if length is None and iterable is not None and hasattr(iterable, "__len__"):
            length = len(iterable)
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.file = file if file is not None else sys.stdout
        self.width = width
        self.pos = 0
        self.start = time.time()
        self.tty = not hidden and _is_tty(self.file)
        if not hidden and not self.tty and self.label:
            echo(self.label, file=self.file)

    def __iter__(self) -> t.Iterator[t.Any]:
        if self.iterable is None:
            return
        for item in self.iterable:
            yield item
            self.update(1)

    def update(self, n_steps: int) -> None:
        self.pos += n_steps
        self.render_progress()

    def _eta(self) -> str:
        if not self.length or self.pos <= 0:
            return ""
        elapsed = time.time() - self.start
        remaining = elapsed / self.pos * max(self.length - self.pos, 0)
        return f" eta {int(remaining)}s"

    def render_progress(self) -> None:
        if not self.tty:
            return
        if self.length:
            filled = int(self.width * min(self.pos, self.length) / self.length)
            bar = "#" * filled + "-" * (self.width - filled)
            line = f"{self.label}  [{bar}]  {self.pos}/{self.length}{self._eta()}"
        else:
            line = f"{self.label}  {self.pos}"
        self.file.write("\r" + line)
        self.file.flush()

    def finish(self) -> None:
        if self.tty:
            self.file.write("\n")
            self.file.flush()


@contextmanager
def progressbar(
    iterable: t.Any = None,
    length: t.Optional[int] = None,
    label: t.Optional[str] = None,
    hidden: bool = False,
    **options: t.Any,
) -> t.Iterator[ProgressBar]:
    bar = ProgressBar(iterable, length=length, label=label, hidden=hidden, **options)
    try:
        yield bar
    finally:
        bar.finish()


def _pager_command() -> t.List[str]:
    return shlex.split(os.environ.get("PAGER") or "less")


def _chunks(text_or_generator: t.Any) -> t.Iterable[str]:
    if isinstance(text_or_generator, str):
        return [text_or_generator]
    if callable(text_or_generator):
        return text_or_generator()
    return text_or_generator


def echo_via_pager(text_or_generator: t.Any, color: t.Optional[bool] = None) -> None:
    """Write text through the pager when interactive, otherwise to standard output."""
    chunks = _chunks(text_or_generator)
    if not is_interactive():
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    try:
        proc = subprocess.Popen(_pager_command(), stdin=subprocess.PIPE)
    except OSError:
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    try:
        for chunk in chunks:
            echo(chunk, file=proc.stdin, nl=False, color=color if color is not None else False)
            proc.stdin.flush()
    except BrokenPipeError:
        pass
    finally:
        try:
            proc.stdin.close()
        except BrokenPipeError:
            pass
        proc.wait()


class _PagerStream:
    """A writable text stream whose writes go through :func:`echo`."""

    def __init__(self, file: t.Any, color: t.Optional[bool]) -> None:
        self._file = file
        self._color = color

    def write(self, text: str) -> int:
        echo(text, file=self._file, nl=False, color=self._color)
        return len(text)

    def flush(self) -> None:
        self._file.flush()


@contextmanager
def get_pager_file(color: t.Optional[bool] = None) -> t.Iterator[_PagerStream]:
    """Yield a writable stream; it feeds the pager when the session is interactive."""
    if not is_interactive():
        yield _PagerStream(sys.stdout, color)
        return
    try:
        proc = subprocess.Popen(_pager_command(), stdin=subprocess.PIPE, text=True)
    except OSError:
        yield _PagerStream(sys.stdout, color)
        return
    try:
        yield _PagerStream(proc.stdin, color if color is not None else False)
    finally:
        try:
            proc.stdin.close()
        except BrokenPipeError:
            pass
        proc.wait()


__all__ = [
    "prompt",
    "confirm",
    "getchar",
    "pause",
    "clear",
    "edit",
    "launch",
    "progressbar",
    "echo_via_pager",
    "get_pager_file",
    "is_interactive",
]
