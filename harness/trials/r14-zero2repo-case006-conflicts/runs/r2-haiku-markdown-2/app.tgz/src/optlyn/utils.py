"""Output, styling, and file helpers shared by the library."""

import io
import os
import re
import sys
import tempfile
import typing as t

from ._context import get_current_context
from .exceptions import FileError

_ansi_re = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")

_ansi_colors = {
    "black": 30,
    "red": 31,
    "green": 32,
    "yellow": 33,
    "blue": 34,
    "magenta": 35,
    "cyan": 36,
    "white": 37,
    "reset": 39,
    "bright_black": 90,
    "bright_red": 91,
    "bright_green": 92,
    "bright_yellow": 93,
    "bright_blue": 94,
    "bright_magenta": 95,
    "bright_cyan": 96,
    "bright_white": 97,
}

_ansi_reset_all = "\033[0m"
_ascii_encodings = frozenset({"ascii", "us-ascii", "ansi_x3.4-1968", "646"})


def strip_ansi(value: str) -> str:
    return _ansi_re.sub("", value)


def unstyle(text: str) -> str:
    """Remove ANSI escape sequences from ``text``."""
    return strip_ansi(text)


def _is_tty(stream: t.Any) -> bool:
    try:
        return bool(stream.isatty())
    except Exception:
        return False


def _current_color() -> t.Optional[bool]:
    ctx = get_current_context(silent=True)
    return ctx.color if ctx is not None else None


def _color_code(color: t.Any, background: bool) -> str:
    if isinstance(color, str):
        if color not in _ansi_colors:
            raise TypeError(f"Unknown color {color!r}.")
        code = _ansi_colors[color]
        return str(code + 10 if background else code)
    if isinstance(color, int) and not isinstance(color, bool):
        if 0 <= color <= 255:
            return f"{48 if background else 38};5;{color}"
    elif isinstance(color, (tuple, list)) and len(color) == 3:
        if all(isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color):
            r, g, b = color
            return f"{48 if background else 38};2;{r};{g};{b}"
    raise TypeError(f"Unknown color {color!r}.")


def style(
    text: t.Any,
    fg: t.Any = None,
    bg: t.Any = None,
    bold: t.Optional[bool] = None,
    dim: t.Optional[bool] = None,
    underline: t.Optional[bool] = None,
    overline: t.Optional[bool] = None,
    italic: t.Optional[bool] = None,
    blink: t.Optional[bool] = None,
    reverse: t.Optional[bool] = None,
    strikethrough: t.Optional[bool] = None,
    reset: bool = True,
) -> str:
    """Wrap ``text`` in ANSI SGR sequences for the given colors and switches."""
    bits = []
    if fg is not None:
        bits.append(f"\033[{_color_code(fg, False)}m")
    if bg is not None:
        bits.append(f"\033[{_color_code(bg, True)}m")
    switches = (
        (bold, 1, 22),
        (dim, 2, 22),
        (underline, 4, 24),
        (overline, 53, 55),
        (italic, 3, 23),
        (blink, 5, 25),
        (reverse, 7, 27),
        (strikethrough, 9, 29),
    )
    for value, on, off in switches:
        if value is not None:
            bits.append(f"\033[{on if value else off}m")
    bits.append(str(text))
    if reset:
        bits.append(_ansi_reset_all)
    return "".join(bits)


def secho(
    message: t.Any = None,
    file: t.Any = None,
    nl: bool = True,
    err: bool = False,
    color: t.Optional[bool] = None,
    **styles: t.Any,
) -> None:
    """Echo ``message`` after applying :func:`style` with ``styles``."""
    if message is not None and not isinstance(message, bytes):
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


def _write_text(file: t.Any, text: str) -> None:
    encoding = (getattr(file, "encoding", None) or "").lower()
    buffer = getattr(file, "buffer", None)
    if encoding in _ascii_encodings and buffer is not None:
        file.flush()
        buffer.write(text.encode("utf-8"))
        buffer.flush()
        return
    try:
        file.write(text)
    except UnicodeEncodeError:
        if buffer is None:
            raise
        file.flush()
        buffer.write(text.encode("utf-8"))
        buffer.flush()


def echo(
    message: t.Any = None,
    file: t.Any = None,
    nl: bool = True,
    err: bool = False,
    color: t.Optional[bool] = None,
) -> None:
    """Write ``message`` to standard output (or error) with a trailing newline.

    Styles are stripped unless the color flag (from ``color``, the current
    context, or terminal detection) keeps them.
    """
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        target = getattr(file, "buffer", file)
        file.flush()
        target.write(message + (b"\n" if nl else b""))
        target.flush()
        return
    message = str(message)
    if nl:
        message += "\n"
    if color is None:
        color = _current_color()
    if color is None:
        color = _is_tty(file)
    if not color:
        message = strip_ansi(message)
    _write_text(file, message)
    file.flush()


class AtomicFile:
    """Writes to a sibling temporary file and replaces the target on close."""

    def __init__(self, filename: str, mode: str, encoding: t.Any, errors: str) -> None:
        self._target = filename
        directory = os.path.dirname(os.path.abspath(filename))
        fd, self._tmp_name = tempfile.mkstemp(dir=directory, prefix=".", suffix=".tmp")
        if "b" in mode:
            self._f = os.fdopen(fd, mode)
        else:
            self._f = os.fdopen(fd, mode, encoding=encoding, errors=errors)

    def __getattr__(self, name: str) -> t.Any:
        return getattr(self.__dict__["_f"], name)

    def __enter__(self) -> "AtomicFile":
        return self

    def __exit__(self, *exc: t.Any) -> None:
        self.close()

    def close(self) -> None:
        if self._f.closed:
            return
        self._f.close()
        os.replace(self._tmp_name, self._target)


class LazyFile:
    """A file that is opened on first I/O rather than when created."""

    def __init__(
        self,
        filename: str,
        mode: str = "r",
        encoding: t.Any = None,
        errors: str = "strict",
        atomic: bool = False,
    ) -> None:
        self.name = filename
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f: t.Any = None

    def _open(self) -> t.Any:
        if self._f is None:
            try:
                self._f = _open_real(self.name, self.mode, self.encoding, self.errors, self.atomic)
            except OSError as e:
                raise FileError(self.name, e.strerror or str(e)) from e
        return self._f

    def __getattr__(self, name: str) -> t.Any:
        return getattr(self._open(), name)

    def __iter__(self) -> t.Iterator[t.Any]:
        return iter(self._open())

    def __enter__(self) -> "LazyFile":
        return self

    def __exit__(self, *exc: t.Any) -> None:
        self.close()

    def close(self) -> None:
        if self._f is not None:
            self._f.close()


def _open_real(
    filename: str,
    mode: str,
    encoding: t.Any = None,
    errors: str = "strict",
    atomic: bool = False,
) -> t.Any:
    if atomic and ("w" in mode or "a" in mode):
        return AtomicFile(filename, mode, encoding, errors)
    if "b" in mode:
        return open(filename, mode)
    return open(filename, mode, encoding=encoding, errors=errors)


def _open_dash(mode: str, encoding: t.Any = None, errors: str = "strict") -> t.Any:
    """Return standard input (read modes) or standard output (write modes)."""
    std = sys.stdin if "r" in mode else sys.stdout
    if "b" in mode:
        return getattr(std, "buffer", std)
    if encoding is None:
        return std
    return io.TextIOWrapper(getattr(std, "buffer", std), encoding=encoding, errors=errors)


def release_stream(stream: t.Any) -> None:
    """Flush a dash stream and detach it so it does not close the real stream."""
    try:
        stream.flush()
    except Exception:
        pass
    std = (sys.stdin, sys.stdout, sys.stderr, sys.__stdin__, sys.__stdout__, sys.__stderr__)
    if isinstance(stream, io.TextIOWrapper) and not any(stream is s for s in std):
        try:
            stream.detach()
        except ValueError:
            pass


class StdStreamProxy:
    """Wraps a standard stream so that closing it (or leaving ``with``) only flushes."""

    def __init__(self, stream: t.Any) -> None:
        self._stream = stream

    def __getattr__(self, name: str) -> t.Any:
        return getattr(self.__dict__["_stream"], name)

    def __iter__(self) -> t.Iterator[t.Any]:
        return iter(self._stream)

    def __enter__(self) -> "StdStreamProxy":
        return self

    def __exit__(self, *exc: t.Any) -> None:
        self.close()

    def close(self) -> None:
        self._stream.flush()


def open_file(
    filename: str,
    mode: str = "r",
    encoding: t.Optional[str] = None,
    errors: str = "strict",
    lazy: bool = False,
    atomic: bool = False,
) -> t.Any:
    """Open a file, or a standard stream when ``filename`` is ``-``."""
    if filename == "-":
        return StdStreamProxy(_open_dash(mode, encoding, errors))
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    try:
        return _open_real(filename, mode, encoding, errors, atomic)
    except OSError as e:
        raise FileError(filename, e.strerror or str(e)) from e


def get_text_stream(name: str, encoding: t.Optional[str] = None, errors: str = "strict") -> t.Any:
    """Return the text stream ``stdin``, ``stdout`` or ``stderr``."""
    stream = getattr(sys, name)
    if encoding is None:
        return stream
    return io.TextIOWrapper(getattr(stream, "buffer", stream), encoding=encoding, errors=errors)


def get_binary_stream(name: str) -> t.Any:
    """Return the binary stream behind ``stdin``, ``stdout`` or ``stderr``."""
    stream = getattr(sys, name)
    return getattr(stream, "buffer", stream)


def format_filename(filename: t.Any, shorten: bool = False) -> str:
    """Return a printable text form of a filename that is valid UTF-8."""
    if hasattr(filename, "__fspath__"):
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        filename = os.fsdecode(filename)
    text = str(filename)
    if shorten:
        text = os.path.basename(text)
    return text.encode("utf-8", "surrogateescape").decode("utf-8", "backslashreplace")


def _posix_app_folder(app_name: str) -> str:
    return re.sub(r"\s+", "-", app_name.lower())


def get_app_dir(app_name: str, roaming: bool = True, force_posix: bool = False) -> str:
    """Return the per-user configuration directory for ``app_name``."""
    if sys.platform.startswith("win") and not force_posix:
        key = "APPDATA" if roaming else "LOCALAPPDATA"
        folder = os.environ.get(key) or os.path.expanduser("~")
        return os.path.join(folder, app_name)
    if force_posix:
        return os.path.expanduser("~/." + _posix_app_folder(app_name))
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~/Library/Application Support"), app_name)
    config_home = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
    return os.path.join(config_home, _posix_app_folder(app_name))
