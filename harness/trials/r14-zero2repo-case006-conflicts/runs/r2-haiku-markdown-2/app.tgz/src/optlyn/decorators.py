"""Declaration decorators: commands, groups, options, arguments and their ready-made forms."""

import functools
import inspect
import typing as t
from importlib import metadata

from .core import Command, Group, _help_callback
from .parameters import Argument, Option
from .utils import echo


def _param_memo(f: t.Any, param: t.Any) -> None:
    if not hasattr(f, "__optlyn_params__"):
        f.__optlyn_params__ = []
    f.__optlyn_params__.append(param)


def _pop_params(f: t.Any) -> t.List[t.Any]:
    params = list(getattr(f, "__optlyn_params__", []))
    if hasattr(f, "__optlyn_params__"):
        del f.__optlyn_params__
    params.reverse()
    return params


def _derive_name(f: t.Callable[..., t.Any]) -> str:
    name = f.__name__.lower().replace("_", "-")
    for suffix in ("-command", "-cmd", "-group", "-grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            return name[: -len(suffix)]
    return name


def command(name: t.Any = None, cls: t.Any = None, **attrs: t.Any) -> t.Any:
    """Turn a function into a :class:`Command` (``@command()`` or ``@command``)."""
    if callable(name) and not isinstance(name, str):
        return command()(name)
    cls = cls or Command

    def decorator(f: t.Callable[..., t.Any]) -> Command:
        cmd_name = name if name is not None else _derive_name(f)
        return cls(name=cmd_name, callback=f, params=_pop_params(f), **attrs)

    return decorator


def group(name: t.Any = None, cls: t.Any = None, **attrs: t.Any) -> t.Any:
    """Turn a function into a :class:`Group` (``@group()`` or ``@group``)."""
    if callable(name) and not isinstance(name, str):
        return group()(name)
    cls = cls or Group

    def decorator(f: t.Callable[..., t.Any]) -> Group:
        grp_name = name if name is not None else _derive_name(f)
        return cls(name=grp_name, callback=f, params=_pop_params(f), **attrs)

    return decorator


def option(*param_decls: str, cls: t.Any = None, **attrs: t.Any) -> t.Callable[[t.Any], t.Any]:
    """Attach an option to a command or group function."""
    option_cls = cls or Option

    def decorator(f: t.Any) -> t.Any:
        _param_memo(f, option_cls(param_decls, **attrs))
        return f

    return decorator


def argument(*param_decls: str, cls: t.Any = None, **attrs: t.Any) -> t.Callable[[t.Any], t.Any]:
    """Attach a positional argument to a command or group function."""
    argument_cls = cls or Argument

    def decorator(f: t.Any) -> t.Any:
        _param_memo(f, argument_cls(param_decls, **attrs))
        return f

    return decorator


def help_option(*param_decls: str, **kwargs: t.Any) -> t.Callable[[t.Any], t.Any]:
    """Attach an extra eager help flag that prints help and exits."""
    if not param_decls:
        param_decls = ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _help_callback)

    def decorator(f: t.Any) -> t.Any:
        opt = Option(param_decls, **kwargs)
        opt._is_help = True  # type: ignore[attr-defined]
        _param_memo(f, opt)
        return f

    return decorator


def _detect_version(package_name: str) -> str:
    try:
        return metadata.version(package_name)
    except metadata.PackageNotFoundError:
        pass
    try:
        dists = metadata.packages_distributions().get(package_name)
    except Exception:
        dists = None
    if dists:
        return metadata.version(dists[0])
    return "unknown"


def version_option(
    version: t.Optional[str] = None,
    *param_decls: str,
    package_name: t.Optional[str] = None,
    prog_name: t.Optional[str] = None,
    message: t.Optional[str] = None,
    **kwargs: t.Any,
) -> t.Callable[[t.Any], t.Any]:
    """Attach an eager ``--version`` flag that prints the version and exits."""
    if not param_decls:
        param_decls = ("--version",)
    if version is None and package_name is None:
        caller = inspect.currentframe()
        module = caller.f_back.f_globals.get("__name__", "__main__") if caller and caller.f_back else "__main__"
        package_name = module.partition(".")[0]

    def callback(ctx: t.Any, param: t.Any, value: t.Any) -> None:
        if not value or ctx.resilient_parsing:
            return
        prog = prog_name or ctx.find_root().info_name
        ver = version if version is not None else _detect_version(package_name or "")
        template = message or "%(prog)s, version %(version)s"
        echo(template % {"prog": prog, "version": ver}, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs.setdefault("callback", callback)
    return option(*param_decls, **kwargs)


def custom_version_option(
    callback_: t.Callable[[t.Any], str], *param_decls: str, **kwargs: t.Any
) -> t.Callable[[t.Any], t.Any]:
    """Attach an eager version flag whose identity is the string ``callback_(ctx)`` returns."""
    if not param_decls:
        param_decls = ("--version",)

    def callback(ctx: t.Any, param: t.Any, value: t.Any) -> None:
        if not value or ctx.resilient_parsing:
            return
        echo(callback_(ctx), color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs.setdefault("callback", callback)
    return option(*param_decls, **kwargs)


def password_option(*param_decls: str, **kwargs: t.Any) -> t.Callable[[t.Any], t.Any]:
    """Attach a hidden, prompting, confirmed password option (``--password``)."""
    if not param_decls:
        param_decls = ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    return option(*param_decls, **kwargs)


def _confirm_callback(ctx: t.Any, param: t.Any, value: t.Any) -> None:
    if not value and not ctx.resilient_parsing:
        ctx.abort()


def confirmation_option(*param_decls: str, **kwargs: t.Any) -> t.Callable[[t.Any], t.Any]:
    """Attach a ``--yes`` flag that asks for confirmation when it is omitted."""
    if not param_decls:
        param_decls = ("--yes",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("callback", _confirm_callback)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")
    return option(*param_decls, **kwargs)


def pass_context(f: t.Callable[..., t.Any]) -> t.Callable[..., t.Any]:
    """Pass the current :class:`Context` as the first argument."""
    from ._context import get_current_context

    @functools.wraps(f)
    def new_func(*args: t.Any, **kwargs: t.Any) -> t.Any:
        return f(get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(f: t.Callable[..., t.Any]) -> t.Callable[..., t.Any]:
    """Pass the current context's author object as the first argument."""
    from ._context import get_current_context

    @functools.wraps(f)
    def new_func(*args: t.Any, **kwargs: t.Any) -> t.Any:
        return f(get_current_context().obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type: type, ensure: bool = False) -> t.Callable[[t.Any], t.Any]:
    """Build a decorator that passes the nearest context object of ``object_type``."""
    from ._context import get_current_context

    def decorator(f: t.Callable[..., t.Any]) -> t.Callable[..., t.Any]:
        @functools.wraps(f)
        def new_func(*args: t.Any, **kwargs: t.Any) -> t.Any:
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(
                    f"Managed to invoke callback without a context object of type"
                    f" {object_type.__name__!r} existing."
                )
            return ctx.invoke(f, obj, *args, **kwargs)

        return new_func

    return decorator
