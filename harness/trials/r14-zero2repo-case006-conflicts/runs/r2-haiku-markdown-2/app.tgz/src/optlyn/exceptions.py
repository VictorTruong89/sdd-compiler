"""Exceptions used to report usage failures, aborts, and exits."""

import typing as t


class Exit(RuntimeError):
    """Ends the invocation with an exit status (raised by ``Context.exit``)."""

    def __init__(self, code: int = 0) -> None:
        super().__init__(code)
        self.exit_code = code


class Abort(RuntimeError):
    """Stops the invocation as an abort (raised by ``Context.abort``)."""


class OptlynError(Exception):
    """Base class for errors that are reported on standard error."""

    exit_code = 1

    def __init__(self, message: str, ctx: t.Any = None) -> None:
        super().__init__(message)
        self.message = message
        self.ctx = ctx

    def format_message(self) -> str:
        return self.message

    def show(self, file: t.Any = None) -> None:
        from .utils import echo

        echo(f"Error: {self.format_message()}", file=file, err=True)


class UsageError(OptlynError):
    """Incorrect command line usage; exit status 2."""

    exit_code = 2

    def show(self, file: t.Any = None) -> None:
        from .utils import echo

        ctx = self.ctx
        if ctx is not None:
            names = ctx.help_option_names or ["--help"]
            echo(ctx.get_usage(), file=file, err=True)
            echo(f"Try '{ctx.command_path} {names[0]}' for help.", file=file, err=True)
            echo(file=file, err=True)
        echo(f"Error: {self.format_message()}", file=file, err=True)


class NoArgsIsHelpError(UsageError):
    """Help shown because a command was run with no arguments (usage failure)."""

    def __init__(self, ctx: t.Any) -> None:
        super().__init__("", ctx)

    def show(self, file: t.Any = None) -> None:
        from .utils import echo

        echo(self.ctx.get_help(), file=file, err=True)


class BadParameter(UsageError):
    """A parameter value was refused; the message names the parameter."""

    def __init__(
        self,
        message: str,
        ctx: t.Any = None,
        param: t.Any = None,
        param_hint: t.Optional[str] = None,
    ) -> None:
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def _hint(self) -> t.Optional[str]:
        if self.param_hint:
            return self.param_hint
        if self.param is not None:
            return self.param.get_error_hint(self.ctx)
        return None

    def format_message(self) -> str:
        hint = self._hint()
        if hint:
            return f"Invalid value for {hint}: {self.message}"
        return f"Invalid value: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter received no value."""

    def __init__(
        self,
        message: t.Optional[str] = None,
        ctx: t.Any = None,
        param: t.Any = None,
        param_hint: t.Optional[str] = None,
    ) -> None:
        super().__init__(message or "", ctx=ctx, param=param, param_hint=param_hint)

    def format_message(self) -> str:
        hint = self._hint()
        if self.param is None and not hint:
            return self.message
        kind = getattr(self.param, "param_type_name", "parameter")
        return f"Missing {kind} {hint}."


class NoSuchOption(UsageError):
    """An option token matched no declared flag."""

    def __init__(self, option_name: str, ctx: t.Any = None) -> None:
        super().__init__(f"No such option: {option_name}", ctx)
        self.option_name = option_name


class BadOptionUsage(UsageError):
    """An option was used incorrectly (for example it is missing its value)."""


class BadArgumentUsage(UsageError):
    """A positional argument was used incorrectly."""


class FileError(OptlynError):
    """A file could not be opened at first I/O (general error; exit status 1)."""

    def __init__(self, filename: str, hint: str) -> None:
        super().__init__(f"Could not open file '{filename}': {hint}")
        self.filename = filename
        self.hint = hint
