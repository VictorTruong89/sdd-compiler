"""Optlyn: a composable command line interface toolkit.

Declare commands, groups, options and arguments with decorators; Optlyn parses
the argument list, converts values, generates help pages, dispatches to the
callbacks, and supplies terminal helpers.
"""

from .core import CHAIN_SUBCOMMAND, Command, CommandCollection, Context, Group
from .decorators import (
    argument,
    command,
    confirmation_option,
    custom_version_option,
    group,
    help_option,
    make_pass_decorator,
    option,
    pass_context,
    pass_obj,
    password_option,
    version_option,
)
from .exceptions import (
    Abort,
    BadArgumentUsage,
    BadOptionUsage,
    BadParameter,
    Exit,
    FileError,
    MissingParameter,
    NoArgsIsHelpError,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from ._context import get_current_context
from .parameters import Argument, Option, Parameter, ParameterSource
from .termui import (
    clear,
    confirm,
    echo_via_pager,
    edit,
    get_pager_file,
    getchar,
    launch,
    pause,
    progressbar,
    prompt,
)
from .types import (
    BOOL,
    FLOAT,
    INT,
    STRING,
    UNPROCESSED,
    UUID,
    Choice,
    DateTime,
    File,
    FloatRange,
    IntRange,
    ParamType,
    Path,
    Tuple,
)
from .utils import (
    echo,
    format_filename,
    get_app_dir,
    open_file,
    secho,
    style,
    unstyle,
)

__version__ = "0.1.0"

__all__ = [
    # declaration
    "command",
    "group",
    "option",
    "argument",
    "help_option",
    "version_option",
    "custom_version_option",
    "password_option",
    "confirmation_option",
    "pass_context",
    "pass_obj",
    "make_pass_decorator",
    # classes
    "Command",
    "Group",
    "CommandCollection",
    "Context",
    "Option",
    "Argument",
    "Parameter",
    "ParameterSource",
    "ParamType",
    "BadParameter",
    "MissingParameter",
    "NoSuchOption",
    "BadOptionUsage",
    "BadArgumentUsage",
    "NoArgsIsHelpError",
    "UsageError",
    "OptlynError",
    "FileError",
    "Abort",
    "Exit",
    "CHAIN_SUBCOMMAND",
    # types
    "STRING",
    "INT",
    "FLOAT",
    "BOOL",
    "UUID",
    "UNPROCESSED",
    "Choice",
    "DateTime",
    "IntRange",
    "FloatRange",
    "Tuple",
    "File",
    "Path",
    # terminal helpers
    "echo",
    "secho",
    "style",
    "unstyle",
    "echo_via_pager",
    "get_pager_file",
    "progressbar",
    "prompt",
    "confirm",
    "getchar",
    "pause",
    "edit",
    "launch",
    "clear",
    "get_app_dir",
    "get_current_context",
    "format_filename",
    "open_file",
]
