"""In-process runner for invoking commands with captured output."""

import io
import os
import shutil
import sys
import tempfile
import typing as t
from contextlib import contextmanager

from .utils import echo


class _Sink:
    """Collects bytes written to one captured stream (and to the combined log)."""

    def __init__(self, combined: t.List[bytes], own: t.List[bytes]) -> None:
        self._combined = combined
        self._own = own

    def write(self, data: bytes) -> int:
        self._own.append(bytes(data))
        self._combined.append(bytes(data))
        return len(data)

    def flush(self) -> None:
        pass


class _CaptureStream:
    """A text stream whose writes are recorded as bytes."""

    errors = "replace"

    def __init__(self, charset: str, combined: t.List[bytes], own: t.List[bytes]) -> None:
        self.encoding = charset
        self.buffer = _Sink(combined, own)

    def write(self, text: t.Any) -> int:
        if isinstance(text, bytes):
            self.buffer.write(text)
            return len(text)
        self.buffer.write(text.encode(self.encoding, self.errors))
        return len(text)

    def flush(self) -> None:
        pass

    def isatty(self) -> bool:
        return False

    def writable(self) -> bool:
        return True

    def readable(self) -> bool:
        return False

    def fileno(self) -> int:
        raise io.UnsupportedOperation("fileno")


class _InputStream:
    """Standard input for an invocation; optionally echoes what it reads."""

    echoes_input = False

    def __init__(self, data: bytes, charset: str, echo_to: t.Optional[t.Callable[[str], None]]) -> None:
        self._inner = io.TextIOWrapper(io.BytesIO(data), encoding=charset)
        self._echo_to = echo_to
        self.echoes_input = echo_to is not None

    def _emit(self, text: str) -> str:
        if text and self._echo_to is not None:
            self._echo_to(text)
        return text

    def readline(self, *args: t.Any) -> str:
        return self._emit(self._inner.readline(*args))

    def read(self, size: int = -1) -> str:
        return self._emit(self._inner.read(size))

    def __iter__(self) -> t.Iterator[str]:
        while True:
            line = self.readline()
            if not line:
                return
            yield line

    def isatty(self) -> bool:
        return False

    def __getattr__(self, name: str) -> t.Any:
        return getattr(self._inner, name)


class Result:
    """The outcome of :meth:`CliRunner.invoke`."""

    def __init__(
        self,
        runner: "CliRunner",
        stdout_bytes: bytes,
        stderr_bytes: bytes,
        output_bytes: bytes,
        return_value: t.Any,
        exit_code: int,
        exception: t.Optional[BaseException],
        exc_info: t.Any = None,
    ) -> None:
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self) -> str:
        return self.output_bytes.decode(self.runner.charset, "replace")

    @property
    def stdout(self) -> str:
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self) -> str:
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    def __repr__(self) -> str:
        return f"<Result {self.exit_code} {self.exception!r}>"


class CliRunner:
    """Invokes a command in-process with captured standard streams."""

    def __init__(
        self,
        charset: str = "utf-8",
        env: t.Optional[t.Mapping[str, t.Optional[str]]] = None,
        echo_stdin: bool = False,
        catch_exceptions: bool = True,
        capture: str = "sys",
    ) -> None:
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli: t.Any) -> str:
        return cli.name or "root"

    @contextmanager
    def isolation(
        self,
        input: t.Any = None,
        env: t.Optional[t.Mapping[str, t.Optional[str]]] = None,
        color: bool = False,
    ) -> t.Iterator[t.Tuple[io.BytesIO, io.BytesIO, io.BytesIO]]:
        """Replace the standard streams and environment for the block."""
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        else:
            data = bytes(input)
        if self.capture == "fd":
            out_tmp = tempfile.TemporaryFile()
            err_tmp = tempfile.TemporaryFile()
            saved_fds = (os.dup(1), os.dup(2))
            sys.stdout.flush()
            sys.stderr.flush()
            os.dup2(out_tmp.fileno(), 1)
            os.dup2(err_tmp.fileno(), 2)
            out = io.TextIOWrapper(io.FileIO(1, "w", closefd=False), encoding=self.charset,
                                   errors="replace", write_through=True)
            err = io.TextIOWrapper(io.FileIO(2, "w", closefd=False), encoding=self.charset,
                                   errors="replace", write_through=True)
        else:
            out_tmp = err_tmp = saved_fds = None
            combined: t.List[bytes] = []
            out_own: t.List[bytes] = []
            err_own: t.List[bytes] = []
            out = _CaptureStream(self.charset, combined, out_own)
            err = _CaptureStream(self.charset, combined, err_own)
        echo_to = (lambda text: out.write(text)) if self.echo_stdin else None
        stdin = _InputStream(data, self.charset, echo_to)

        merged_env = {**self.env, **dict(env or {})}
        saved_env = {k: os.environ.get(k) for k in merged_env}
        for key, value in merged_env.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value

        saved_streams = (sys.stdin, sys.stdout, sys.stderr)
        sys.stdin, sys.stdout, sys.stderr = stdin, out, err
        try:
            yield io.BytesIO(b""), io.BytesIO(b""), io.BytesIO(b"")
        finally:
            sys.stdin, sys.stdout, sys.stderr = saved_streams
            for key, value in saved_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            if saved_fds is not None:
                out.flush()
                err.flush()
                os.dup2(saved_fds[0], 1)
                os.dup2(saved_fds[1], 2)
                os.close(saved_fds[0])
                os.close(saved_fds[1])
                out_tmp.seek(0)
                err_tmp.seek(0)
                out_data, err_data = out_tmp.read(), err_tmp.read()
                out_tmp.close()
                err_tmp.close()
                self._last_streams = ([out_data], [err_data], [out_data + err_data])
            else:
                self._last_streams = (out_own, err_own, combined)

    def invoke(
        self,
        cli: t.Any,
        args: t.Any = None,
        input: t.Any = None,
        env: t.Optional[t.Mapping[str, t.Optional[str]]] = None,
        catch_exceptions: t.Optional[bool] = None,
        color: bool = False,
        **extra: t.Any,
    ) -> Result:
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if isinstance(args, str):
            import shlex

            args = shlex.split(args)
        prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
        standalone_mode = extra.pop("standalone_mode", True)
        exception: t.Optional[BaseException] = None
        exit_code = 0
        exc_info = None
        return_value = None
        with self.isolation(input=input, env=env, color=color) as _:
            try:
                return_value = cli.main(
                    args=list(args) if args is not None else [],
                    prog_name=prog_name,
                    standalone_mode=standalone_mode,
                    color=color,
                    **extra,
                )
            except SystemExit as e:
                exc_info = sys.exc_info()
                code = e.code
                if code is None:
                    exit_code = 0
                elif isinstance(code, int):
                    exit_code = code
                else:
                    echo(code, err=True)
                    exit_code = 1
                if exit_code != 0:
                    exception = e
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
        out_own, err_own, combined = self._last_streams
        return Result(
            self,
            stdout_bytes=b"".join(out_own),
            stderr_bytes=b"".join(err_own),
            output_bytes=b"".join(combined),
            return_value=return_value,
            exit_code=exit_code,
            exception=exception,
            exc_info=exc_info,
        )

    @contextmanager
    def isolated_filesystem(self, temp_dir: t.Optional[str] = None) -> t.Iterator[str]:
        """Run the block in a new empty working directory.

        Without ``temp_dir`` the directory is removed on exit; with it, the new
        directory is created under ``temp_dir`` and left in place.
        """
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                shutil.rmtree(dt, ignore_errors=True)
