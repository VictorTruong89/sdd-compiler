"""Behavioural tests for the Optlyn package (run with PYTHONPATH=src)."""

import os

import pytest

from optlyn import (
    Abort,
    Choice,
    IntRange,
    argument,
    command,
    confirmation_option,
    custom_version_option,
    echo,
    group,
    help_option,
    option,
    pass_context,
    pass_obj,
    password_option,
    style,
    unstyle,
    version_option,
)
from optlyn.testing import CliRunner


@pytest.fixture
def runner():
    return CliRunner()


def test_command_name_is_derived_from_function(runner):
    @command()
    def build_cmd():
        echo("built")

    assert build_cmd.name == "build"
    assert runner.invoke(build_cmd, []).output == "built\n"


def test_explicit_name_replaces_derived_name():
    @command("go")
    def start():
        pass

    assert start.name == "go"


def test_options_and_arguments(runner):
    @command()
    @option("--count", type=int, default=1)
    @option("-v", "--verbose", is_flag=True)
    @argument("name")
    def hello(count, verbose, name):
        for _ in range(count):
            echo(f"hi {name}{'!' if verbose else ''}")

    res = runner.invoke(hello, ["--count", "2", "-v", "bob"])
    assert res.exit_code == 0
    assert res.output == "hi bob!\nhi bob!\n"


def test_short_option_stacking_and_attached_values(runner):
    @command()
    @option("-a", is_flag=True)
    @option("-b", is_flag=True)
    @option("-c", "value")
    def stack(a, b, value):
        echo(f"{a} {b} {value}")

    assert runner.invoke(stack, ["-abcXYZ"]).output == "True True XYZ\n"


def test_missing_argument_is_usage_error(runner):
    @command()
    @argument("name")
    def needs(name):
        echo(name)

    res = runner.invoke(needs, [])
    assert res.exit_code == 2
    assert "'name'" in res.output


def test_bad_value_names_the_option(runner):
    @command()
    @option("--count", type=int)
    def counted(count):
        pass

    res = runner.invoke(counted, ["--count", "x"])
    assert res.exit_code == 2
    assert "--count" in res.output


def test_unknown_option_is_usage_error(runner):
    @command()
    def plain():
        pass

    res = runner.invoke(plain, ["--nope"])
    assert res.exit_code == 2


def test_help_exits_zero_and_skips_callback(runner):
    ran = []

    @command()
    @option("--x", help="The x value.")
    def tool(x):
        ran.append(True)

    res = runner.invoke(tool, ["--help"])
    assert res.exit_code == 0
    assert "Usage: tool" in res.output
    assert "The x value." in res.output
    assert ran == []


def test_group_dispatch_and_group_callback(runner):
    @group()
    @option("--debug", is_flag=True)
    def cli(debug):
        echo(f"debug={debug}")

    @cli.command()
    def sub_one():
        echo("one")

    res = runner.invoke(cli, ["--debug", "sub-one"])
    assert res.exit_code == 0
    assert res.output == "debug=True\none\n"


def test_group_without_subcommand_is_usage_failure(runner):
    @group()
    def cli():
        pass

    res = runner.invoke(cli, [])
    assert res.exit_code == 2
    assert "Usage: cli" in res.output


def test_unknown_subcommand(runner):
    @group()
    def cli():
        pass

    res = runner.invoke(cli, ["nope"])
    assert res.exit_code == 2
    assert "No such command" in res.output


def test_chain_group_results(runner):
    @group(chain=True)
    def pipe():
        pass

    @pipe.command()
    @argument("x", type=int)
    def add(x):
        return lambda s: s + x

    @pipe.command()
    def double():
        return lambda s: s * 2

    @pipe.result_callback()
    def run(processors):
        value = 1
        for process in processors:
            value = process(value)
        echo(f"result {value}")

    res = runner.invoke(pipe, ["add", "3", "double"])
    assert res.output == "result 8\n"


def test_nested_groups(runner):
    @group()
    def outer():
        echo("outer")

    @outer.group()
    def middle():
        echo("middle")

    @middle.command()
    def leaf():
        echo("leaf")

    assert runner.invoke(outer, ["middle", "leaf"]).output == "outer\nmiddle\nleaf\n"


def test_environment_variable_fills_option(runner):
    @command()
    @option("--token", envvar="OPTLYN_TEST_TOKEN")
    def auth(token):
        echo(token)

    assert runner.invoke(auth, [], env={"OPTLYN_TEST_TOKEN": "abc"}).output == "abc\n"
    assert runner.invoke(auth, ["--token", "x"], env={"OPTLYN_TEST_TOKEN": "abc"}).output == "x\n"


def test_auto_envvar_prefix(runner):
    @command()
    @option("--token")
    def auth(token):
        echo(token)

    res = runner.invoke(auth, [], auto_envvar_prefix="MYAPP", env={"MYAPP_TOKEN": "t1"})
    assert res.output == "t1\n"


def test_default_map_overrides_default(runner):
    @command()
    @option("--n", type=int, default=1)
    def dm(n):
        echo(n)

    assert runner.invoke(dm, [], default_map={"n": 5}).output == "5\n"


def test_prompt_and_confirmation(runner):
    @command()
    @option("--name", prompt=True)
    @password_option()
    def form(name, password):
        echo(f"{name}/{password}")

    res = runner.invoke(form, [], input="ann\nsecret\nsecret\n")
    assert res.exit_code == 0
    assert res.output.endswith("ann/secret\n")


def test_confirmation_option_declined_aborts(runner):
    @command()
    @confirmation_option()
    def drop():
        echo("dropped")

    res = runner.invoke(drop, [], input="n\n")
    assert res.exit_code == 1
    assert "dropped" not in res.output
    assert "Aborted!" in res.output


def test_confirmation_option_flag_skips_question(runner):
    @command()
    @confirmation_option()
    def drop():
        echo("dropped")

    res = runner.invoke(drop, ["--yes"], input="")
    assert res.output == "dropped\n"


def test_choice_and_int_range(runner):
    @command()
    @option("--color", type=Choice(["red", "green"], case_sensitive=False), default="red")
    @option("--age", type=IntRange(0, 10, clamp=True), default=3)
    def paint(color, age):
        echo(f"{color} {age}")

    assert runner.invoke(paint, ["--color", "GREEN", "--age", "50"]).output == "green 10\n"
    assert runner.invoke(paint, ["--color", "blue"]).exit_code == 2


def test_version_options(runner):
    @command()
    @version_option("1.2.3", prog_name="tool")
    @custom_version_option(lambda ctx: "custom 9", "--cv")
    def tool():
        pass

    assert runner.invoke(tool, ["--version"]).output == "tool, version 1.2.3\n"
    assert runner.invoke(tool, ["--cv"]).output == "custom 9\n"


def test_help_option_extra_flag(runner):
    @command()
    @help_option("-h")
    def tool():
        """Does a thing."""

    res = runner.invoke(tool, ["-h"])
    assert res.exit_code == 0
    assert "Does a thing." in res.output


def test_pass_context_and_obj(runner):
    @group()
    @pass_context
    def cli(ctx):
        ctx.obj = {"level": 3}

    @cli.command()
    @pass_obj
    def show(obj):
        echo(obj["level"])

    assert runner.invoke(cli, ["show"]).output == "3\n"


def test_deprecated_command_warns_and_runs(runner):
    @command(deprecated=True)
    def old():
        echo("still works")

    res = runner.invoke(old, [])
    assert res.exit_code == 0
    assert "deprecated" in res.output
    assert res.output.endswith("still works\n")


def test_custom_return_value_without_standalone(runner):
    @command()
    @option("--x", type=int)
    def double(x):
        return x * 2

    assert double.main(["--x", "4"], standalone_mode=False) == 8


def test_abort_in_standalone(runner):
    @command()
    def stop():
        raise Abort()

    res = runner.invoke(stop, [])
    assert res.exit_code == 1
    assert "Aborted!" in res.output


def test_styles_and_unstyle():
    text = style("hi", fg="red", bold=True)
    assert text.startswith("\x1b[31m")
    assert unstyle(text) == "hi"
    with pytest.raises(TypeError):
        style("x", fg="not-a-color")


def test_no_args_is_help_for_leaf(runner):
    @command(no_args_is_help=True)
    @argument("name")
    def leaf(name):
        pass

    res = runner.invoke(leaf, [])
    assert res.exit_code == 2
    assert "Usage: leaf" in res.output


def test_extra_arguments_allowed_by_context(runner):
    @command(context_settings={"allow_extra_args": True})
    @argument("first")
    def extra(first):
        echo(first)

    assert runner.invoke(extra, ["a", "b", "c"]).output == "a\n"


def test_isolated_filesystem_file_write(runner):
    @command()
    @argument("out", type=__import__("optlyn").File("w"))
    def writer(out):
        out.write("data")

    with runner.isolated_filesystem() as tmp:
        assert runner.invoke(writer, ["o.txt"]).exit_code == 0
        with open(os.path.join(tmp, "o.txt")) as handle:
            assert handle.read() == "data"


def test_shell_completion_source_and_suggestions(runner):
    @group()
    def cli():
        pass

    @cli.command()
    @option("--kind", type=Choice(["alpha", "beta"]))
    def run():
        pass

    source = runner.invoke(cli, [], env={"_CLI_COMPLETE": "bash_source"}, prog_name="cli")
    assert source.exit_code == 0
    assert "_CLI_COMPLETE=bash_complete" in source.output

    suggestions = runner.invoke(
        cli,
        [],
        env={"_CLI_COMPLETE": "bash_complete", "COMP_WORDS": "cli run --kind ", "COMP_CWORD": "3"},
        prog_name="cli",
    )
    assert suggestions.output.splitlines() == ["plain,alpha", "plain,beta"]


def test_unknown_completion_instruction_runs_nothing(runner):
    ran = []

    @command()
    def cmd():
        ran.append(True)

    res = runner.invoke(cmd, [], env={"_CMD_COMPLETE": "tcsh_complete"}, prog_name="cmd")
    assert ran == []
    assert res.output == ""
    assert res.exit_code == 1


def test_standalone_exit_code_from_context(runner):
    @command()
    def stop():
        from optlyn import get_current_context

        get_current_context().exit(7)

    assert runner.invoke(stop, []).exit_code == 7
