# Spec coverage ledger

Every id in `spec/CHECKLIST.md` is listed below with its pack.
Status is recorded per pack: each pack's ids are implemented by the modules named.
Ids that code comments anchor directly (`# spec: N-xxxxxx`) number 295 of 1014; the rest are
covered by the same feature modules. Tests that exercise a pack are named under it.
The only id marked not done is the Windows argv-expansion part of pack 17.

### Pack 01 — 01-hardware-requirements--hardware-requirements.md
- ids: none (the pack has no claims)
- status: implemented — pyproject.toml (zero dependencies, src layout)

### Pack 02 — 02-hardware-requirements--summary.md
- ids: N-000761–N-000764
- status: implemented — pyproject.toml; no runtime imports outside the standard library

### Pack 03 — 03-hardware-requirements--execution-profiles.md
- ids: N-000765–N-000774
- status: implemented — pyproject.toml; pure Python, no build step

### Pack 04 — 04-interface-contract--interface-contract.md
- ids: N-000775
- status: implemented — NOTES.md (choices where the Contract leaves the form open)

### Pack 05 — 05-interface-contract--1-package-and-modules.md
- ids: N-000776–N-000787
- status: implemented — src/optlyn/__init__.py (root exports); optlyn.formatting.wrap_text; optlyn.testing.CliRunner

### Pack 06 — 06-interface-contract--2-global-output-forms.md
- ids: N-000788–N-000833
- status: implemented — termui.echo; exceptions (show, exit codes); core.Command.get_help and main; decorators.version_option / custom_version_option

### Pack 07 — 07-interface-contract--3-declaring-commands-and-groups.md
- ids: N-000834–N-000867
- status: implemented — decorators.command / group; core.Command, Group, CommandCollection; Group.add_command / command / group / result_callback

### Pack 08 — 08-interface-contract--4-parameters.md
- ids: N-000868–N-000922
- status: implemented — core.Parameter, Option, Argument; decorators.option / argument / help_option / version_option / password_option / confirmation_option

### Pack 09 — 09-interface-contract--5-parameter-types.md
- ids: N-000923–N-000931
- status: implemented — paramtypes (ParamType subclasses, convert_type)

### Pack 10 — 10-interface-contract--6-invocation-context.md
- ids: N-000932–N-000962
- status: implemented — core.Context (invoke, forward, exit, abort, with_resource, get_parameter_source); decorators.pass_context / pass_obj / make_pass_decorator; utils.get_current_context

### Pack 11 — 11-interface-contract--7-terminal-helpers.md
- ids: N-000963–N-000969, N-000971–N-000982, N-001015
- status: implemented — termui (echo, style, prompt, confirm, getchar, pause, edit, launch, clear, progressbar, pager); utils.get_app_dir, format_filename, open_file

### Pack 12 — 12-interface-contract--8-shell-completion.md
- ids: N-000983–N-001005
- status: implemented — shell_completion (scripts, suggestions, CompletionItem); core.Option.shell_complete_items

### Pack 13 — 13-interface-contract--9-in-process-runner-optlyn-testing-cliru.md
- ids: N-001006–N-001012
- status: implemented — testing.CliRunner (invoke, isolation, Result, isolated_filesystem)

### Pack 14 — 14-full-prd--product-overview.md
- ids: N-000001–N-000014
- status: implemented — package-wide (pure library, no server, GUI, or web framework)

### Pack 15 — 15-full-prd--terminology.md
- ids: N-000015–N-000019
- status: implemented — package-wide (terminology used by core and parser)

### Pack 16 — 16-full-prd--public-surface-inventory.md
- ids: N-000020–N-000038
- status: implemented — src/optlyn/__init__.py exports; decorators; termui; testing

### Pack 17 — 17-full-prd--non-functional-constraints.md
- ids: N-000039–N-000063
- status: implemented — package-wide; standard library only; Unicode-safe echo (termui._write_text)
- not done: N-000045..N-000049 (in part): on Windows, argv glob / home / environment expansion is not implemented; the target is Linux, and no Windows host was available to check it.

### Pack 18 — 18-full-prd--non-goals.md
- ids: N-000064–N-000072
- status: implemented — non-goals: no server, GUI, aliases, plugin discovery, config syntax, or thread-safe context mutation

### Pack 19 — 19-full-prd--fp-01-command-declaration-naming-and-inv.md
- ids: N-000073–N-000102
- status: implemented — core.Command.invoke / main; decorators._derive_name and _build; core.iter_params_for_processing
- tests: tests/test_commands_and_options.py, tests/test_groups_and_context.py

### Pack 20 — 20-full-prd--fp-02-automatic-help-pages-and-eager-doc.md
- ids: N-000103–N-000164, N-000325–N-000329
- status: implemented — formatting (wrap_text, make_default_short_help, HelpFormatter); core.Command.format_help; core.Group.format_extra; decorators._docstring_help; core.get_help_option
- tests: tests/test_help_types_termui.py

### Pack 21 — 21-full-prd--fp-03-options.md
- ids: N-000165–N-000272
- status: implemented — core.Parameter.consume_value / process_value; core.Option; core.Context._record_param; parser.OptionParser
- tests: tests/test_commands_and_options.py

### Pack 22 — 22-full-prd--fp-04-positional-arguments.md
- ids: N-000273–N-000317
- status: implemented — core.Argument; parser._unpack_args and _process_arguments
- tests: tests/test_groups_and_context.py (extra arguments), tests/test_commands_and_options.py

### Pack 23 — 23-full-prd--fp-05-parameter-types-and-conversion.md
- ids: N-000318–N-000324, N-000330–N-000374
- status: implemented — paramtypes (STRING, INT, FLOAT, BOOL, UUID, Choice, DateTime, IntRange, FloatRange, Tuple)
- tests: tests/test_help_types_termui.py, tests/test_commands_and_options.py

### Pack 24 — 24-full-prd--fp-06-groups-nesting-and-deferred-subcom.md
- ids: N-000375–N-000423
- status: implemented — core.Group (resolve_command, get_command, list_commands, invoke dispatch)
- tests: tests/test_groups_and_context.py

### Pack 25 — 25-full-prd--fp-07-invocation-context-defaults-enviro.md
- ids: N-000424–N-000473
- status: implemented — core.Context (settings, auto_envvar_name, lookup_default, invoke, forward); utils (thread-local stack)
- tests: tests/test_groups_and_context.py

### Pack 26 — 26-full-prd--fp-08-prompts-confirmation-and-hidden-in.md
- ids: N-000474–N-000517
- status: implemented — termui.prompt, confirm, _prompt_raw, _read_line; core.Parameter._prompt_for_value; decorators.password_option / confirmation_option
- tests: tests/test_help_types_termui.py (prompts, confirm)

### Pack 27 — 27-full-prd--fp-09-file-and-path-parameters.md
- ids: N-000518–N-000581
- status: implemented — paramtypes.File and Path; utils.open_file, LazyFile, _AtomicFile, StdStreamProxy, format_filename
- tests: tests/test_help_types_termui.py (files, paths, dash, lazy write)

### Pack 28 — 28-full-prd--fp-10-command-chaining-and-pipelines.md
- ids: N-000582–N-000607
- status: implemented — core.Group.invoke (chain branch); core.Group.add_command refusal
- tests: tests/test_groups_and_context.py (chaining)

### Pack 29 — 29-full-prd--fp-11-terminal-output-and-interaction-he.md
- ids: N-000608–N-000676, N-001013
- status: implemented — termui (echo, style, progressbar, getchar, pause, edit, launch, clear, echo_via_pager); formatting
- tests: tests/test_completion_and_runner.py, tests/test_help_types_termui.py

### Pack 30 — 30-full-prd--fp-12-shell-completion.md
- ids: N-000677–N-000703
- status: implemented — shell_completion.run_completion, completion_items, _source_script
- tests: tests/test_completion_and_runner.py

### Pack 31 — 31-full-prd--fp-13-usage-failures-abort-and-exit-stat.md
- ids: N-000704–N-000723
- status: implemented — exceptions (OptlynError, UsageError, BadParameter, MissingParameter, Abort, Exit, FileError); core.Command.main
- tests: tests/test_groups_and_context.py (usage failures, abort, exit codes)

### Pack 32 — 32-full-prd--fp-14-in-process-runner.md
- ids: N-000724–N-000749, N-001014
- status: implemented — testing.CliRunner (invoke, isolation, fd capture, input echo, isolated_filesystem)
- tests: tests/test_completion_and_runner.py (runner capture modes, isolation)

### Pack 33 — 33-full-prd--cross-cutting-refinements.md
- ids: N-000750–N-000760
- status: implemented — core (refinements of FP-02/03/06/08/09/11 as implemented in the feature modules)

Total checklist ids: 1014. Anchored by `# spec:` comments in code: 295.

