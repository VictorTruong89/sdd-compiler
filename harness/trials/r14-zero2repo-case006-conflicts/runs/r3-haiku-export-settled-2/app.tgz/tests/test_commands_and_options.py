"""Commands, options, flags, counting, repeatable and multi-value options."""

from optlyn import Choice, IntRange, argument, command, echo, group, option
from optlyn.testing import CliRunner


def test_command_name_is_derived_and_suffix_stripped():
    @command()
    def hello_world_cmd():
        pass

    assert hello_world_cmd.name == "hello-world"


def test_explicit_name_is_the_only_accepted_name():
    @group()
    def root():
        pass

    @root.command("greet")
    def say_hi():
        echo("hi")

    runner = CliRunner()
    assert runner.invoke(root, ["greet"]).output == "hi\n"
    assert runner.invoke(root, ["say-hi"]).exit_code == 2


def test_options_and_arguments_are_delivered():
    @command()
    @option("--count", "-c", type=int, default=1)
    @option("--shout/--no-shout", default=False)
    @argument("name")
    def hello(count, shout, name):
        text = f"hi {name}\n" * count
        echo(text.upper() if shout else text, nl=False)

    runner = CliRunner()
    assert runner.invoke(hello, ["-c", "2", "--shout", "bob"]).output == "HI BOB\nHI BOB\n"
    assert runner.invoke(hello, ["bob"]).output == "hi bob\n"


def test_short_flags_stack_and_value_may_be_attached():
    @command()
    @option("-a", is_flag=True)
    @option("-b", is_flag=True)
    @option("-n", type=int)
    def stack(a, b, n):
        echo(f"{a} {b} {n}")

    assert CliRunner().invoke(stack, ["-ab", "-n5"]).output == "True True 5\n"


def test_counting_option_counts_each_flag_in_a_stack():
    @command()
    @option("--verbose", "-v", count=True)
    def loud(verbose):
        echo(verbose)

    runner = CliRunner()
    assert runner.invoke(loud, ["-vvv"]).output == "3\n"
    assert runner.invoke(loud, []).output == "0\n"


def test_repeatable_and_multi_value_options():
    @command()
    @option("--tag", "-t", multiple=True)
    @option("--pair", nargs=2, type=(str, int))
    def tags(tag, pair):
        echo(repr((tag, pair)))

    out = CliRunner().invoke(tags, ["-t", "a", "--tag=b", "--pair", "x", "3"]).output
    assert out == "(('a', 'b'), ('x', 3))\n"
    assert CliRunner().invoke(tags, []).output == "((), None)\n"


def test_choice_matches_case_insensitively_and_returns_original():
    @command()
    @option("--mode", type=Choice(["fast", "slow"], case_sensitive=False), default="fast")
    def run(mode):
        echo(mode)

    runner = CliRunner()
    assert runner.invoke(run, ["--mode", "SLOW"]).output == "slow\n"
    result = runner.invoke(run, ["--mode", "medium"])
    assert result.exit_code == 2
    assert "is not one of" in result.output


def test_int_range_clamps_when_asked():
    @command()
    @option("--x", type=IntRange(1, 5, clamp=True))
    def clampy(x):
        echo(x)

    assert CliRunner().invoke(clampy, ["--x", "9"]).output == "5\n"


def test_unknown_option_is_usage_error_and_callback_does_not_run():
    ran = []

    @command()
    def cmd():
        ran.append(True)

    result = CliRunner().invoke(cmd, ["--nope"])
    assert result.exit_code == 2
    assert "No such option: --nope" in result.output
    assert ran == []


def test_required_option_missing_is_usage_error():
    @command()
    @option("--name", required=True)
    def req(name):
        pass

    result = CliRunner().invoke(req, [])
    assert result.exit_code == 2
    assert "Missing option '--name'" in result.output


def test_default_callable_is_invoked_when_no_source_provides_a_value():
    @command()
    @option("--a")
    @option("--c", default=lambda: "dyn")
    def cmd(a, c):
        echo(f"{a} {c}")

    assert CliRunner().invoke(cmd, ["--a", "1"]).output == "1 dyn\n"


def test_on_off_pair_and_custom_prefixes():
    @command()
    @option("+x", is_flag=True)
    @option("/y", is_flag=True)
    @option("--b/--no-b", "b_flag", default=True)
    def cmd(x, y, b_flag):
        echo(f"{x} {y} {b_flag}")

    runner = CliRunner()
    assert runner.invoke(cmd, ["+x", "/y", "--no-b"]).output == "True True False\n"
    assert runner.invoke(cmd, []).output == "False False True\n"


def test_destination_inferred_from_long_name():
    @command()
    @option("--dry-run", is_flag=True)
    def cmd(dry_run):
        echo(dry_run)

    assert CliRunner().invoke(cmd, ["--dry-run"]).output == "True\n"


def test_callback_can_refuse_a_value_with_bad_parameter():
    from optlyn import BadParameter

    def check(ctx, param, value):
        if value < 1000:
            raise BadParameter("too small", ctx=ctx, param=param)
        return value * 2

    @command()
    @option("--port", type=int, callback=check, default=2000)
    def cmd(port):
        echo(port)

    runner = CliRunner()
    assert runner.invoke(cmd, []).output == "4000\n"
    bad = runner.invoke(cmd, ["--port", "5"])
    assert bad.exit_code == 2
    assert "Invalid value for '--port': too small" in bad.output
