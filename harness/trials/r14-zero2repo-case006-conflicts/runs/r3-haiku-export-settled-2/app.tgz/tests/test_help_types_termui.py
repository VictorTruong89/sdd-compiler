"""Help pages, parameter types, prompts, styling and file handling."""

import os
import uuid

import pytest

from optlyn import (
    BOOL,
    FLOAT,
    INT,
    STRING,
    UUID,
    Choice,
    DateTime,
    File,
    FloatRange,
    Path,
    argument,
    command,
    confirm,
    echo,
    format_filename,
    option,
    prompt,
    secho,
    style,
    unstyle,
    version_option,
)
from optlyn.formatting import wrap_text
from optlyn.testing import CliRunner


def test_help_page_layout_and_no_callback_run():
    ran = []

    @command()
    @option("--count", type=int, default=3, show_default=True, help="How many.")
    @option("--color", type=Choice(["red", "blue"]), help="Pick one.")
    @argument("target", help="Where to go.")
    def greet(count, color, target):
        """Say things.

        More text.
        """
        ran.append(True)

    result = CliRunner().invoke(greet, ["--help"])
    assert result.exit_code == 0
    assert ran == []
    lines = result.output.splitlines()
    assert lines[0].startswith("Usage: greet [OPTIONS] TARGET")
    assert "Say things." in result.output
    assert "Positional arguments:" in result.output
    assert "Where to go." in result.output
    assert "Options:" in result.output
    assert "[default: 3]" in result.output
    assert "[red|blue]" in result.output


def test_docstring_form_feed_truncates_help():
    @command()
    def trunc():
        """Visible.

        \f
        Hidden text.
        """

    result = CliRunner().invoke(trunc, ["--help"])
    assert "Visible." in result.output
    assert "Hidden" not in result.output
    assert "\f" not in result.output


def test_help_respects_explicit_terminal_width():
    @command(help="word " * 40)
    def wide():
        pass

    result = CliRunner().invoke(wide, ["--help"], terminal_width=40)
    assert all(len(line) <= 40 for line in result.output.splitlines())


def test_epilog_is_printed_last():
    @command(epilog="Bye now.")
    def ep():
        """Desc."""

    lines = [l for l in CliRunner().invoke(ep, ["--help"]).output.splitlines() if l]
    assert lines[-1] == "Bye now."


def test_help_is_stdout_but_missing_argument_help_is_stderr():
    @command()
    @argument("name")
    def cmd(name):
        pass

    runner = CliRunner()
    assert runner.invoke(cmd, ["--help"]).stdout.startswith("Usage:")
    result = runner.invoke(cmd, [])
    assert result.stdout == ""
    assert "Missing argument" in result.stderr


def test_version_option_prints_identity():
    @command()
    @version_option("1.2.3", prog_name="mytool")
    def cmd():
        pass

    result = CliRunner().invoke(cmd, ["--version"])
    assert result.output == "mytool, version 1.2.3\n"
    assert result.exit_code == 0


def test_first_typed_eager_flag_wins():
    @command()
    @version_option("9", prog_name="t")
    def cmd():
        pass

    result = CliRunner().invoke(cmd, ["--version", "--help"])
    assert result.output == "t, version 9\n"


def test_int_float_bool_uuid_conversions():
    assert INT.convert("3", None, None) == 3
    with pytest.raises(Exception):
        INT.convert("1.5", None, None)
    assert FLOAT.convert("1.5", None, None) == 1.5
    assert BOOL.convert("Yes", None, None) is True
    assert BOOL.convert("off", None, None) is False
    with pytest.raises(Exception):
        BOOL.convert("maybe", None, None)
    value = uuid.uuid4()
    assert UUID.convert(str(value), None, None) == value
    assert STRING.convert("007", None, None) == "007"


def test_datetime_formats_and_custom_list_replaces_defaults():
    import datetime

    assert DateTime().convert("2024-01-02T03:04:05", None, None) == datetime.datetime(2024, 1, 2, 3, 4, 5)
    custom = DateTime(formats=["%d/%m/%Y"])
    assert custom.convert("02/01/2024", None, None) == datetime.datetime(2024, 1, 2)
    with pytest.raises(Exception):
        custom.convert("2024-01-02", None, None)


def test_float_range_refuses_clamp_with_open_bound():
    with pytest.raises(ValueError):
        FloatRange(0.0, 1.0, min_open=True, clamp=True)
    clamped = FloatRange(0.0, 1.0, clamp=True)
    assert clamped.convert("5", None, None) == 1.0


def test_choice_enum_members_matched_by_name():
    import enum

    class Color(enum.Enum):
        RED = 1
        BLUE = 2

    choice = Choice(Color)
    assert choice.convert("BLUE", None, None) is Color.BLUE


def test_custom_type_and_conversion_function():
    @command()
    @option("--hexval", type=lambda s: int(s, 16))
    def hexed(hexval):
        echo(hexval)

    @command()
    @option("--hexval", type=lambda s: int(s, 16) if s.isalnum() else (_ for _ in ()).throw(ValueError("bad hex")))
    def hexed2(hexval):
        echo(hexval)

    runner = CliRunner()
    assert runner.invoke(hexed, ["--hexval", "ff"]).output == "255\n"
    bad = runner.invoke(hexed2, ["--hexval", "!"])
    assert bad.exit_code == 2
    assert "bad hex" in bad.output


def test_path_checks_and_dash_handling(tmp_path):
    existing = tmp_path / "a.txt"
    existing.write_text("x")
    checked = Path(exists=True, dir_okay=False)
    assert checked.convert(str(existing), None, None) == str(existing)
    with pytest.raises(Exception):
        checked.convert(str(tmp_path / "missing"), None, None)
    with pytest.raises(Exception):
        checked.convert(str(tmp_path), None, None)
    assert Path(allow_dash=True).convert("-", None, None) == "-"


def test_file_type_writes_and_reads_inside_isolated_filesystem():
    @command()
    @argument("out", type=File("w"))
    def writer(out):
        out.write("hi there")

    @command()
    @argument("inp", type=File("r"))
    def reader(inp):
        echo(inp.read().upper())

    runner = CliRunner()
    with runner.isolated_filesystem() as folder:
        assert runner.invoke(writer, ["o.txt"]).exit_code == 0
        assert open(os.path.join(folder, "o.txt")).read() == "hi there"
        assert runner.invoke(reader, ["o.txt"]).output == "HI THERE\n"
        missing = runner.invoke(reader, ["nope.txt"])
        assert missing.exit_code == 2
        assert "nope.txt" in missing.output


def test_lazy_write_file_not_truncated_until_used():
    @command()
    @argument("out", type=File("w"))
    def unused(out):
        pass

    runner = CliRunner()
    with runner.isolated_filesystem() as folder:
        path = os.path.join(folder, "keep.txt")
        with open(path, "w") as handle:
            handle.write("original")
        assert runner.invoke(unused, [path]).exit_code == 0
        assert open(path).read() == "original"


def test_dash_stdout_is_not_closed_by_file_type():
    @command()
    @argument("out", type=File("w"))
    def dash(out):
        out.write("via dash\n")

    runner = CliRunner()
    assert runner.invoke(dash, ["-"]).output == "via dash\n"


def test_format_filename_keeps_names_printable():
    assert format_filename("a/b.txt", shorten=True) == "b.txt"
    assert format_filename(b"\xff.txt").encode("utf-8")


def test_wrap_text_rewraps_and_keeps_backspace_paragraphs():
    assert wrap_text("aaa bbb ccc ddd", 8) == "aaa bbb\nccc ddd"
    kept = wrap_text("\b\nline one\nline two", 40)
    assert kept == "line one\nline two"


def test_styles_strip_when_not_terminal_and_keep_when_forced():
    @command()
    def colored():
        echo(style("ok", fg="green", bold=True))
        echo(style("forced", fg="red"), color=True)

    result = CliRunner().invoke(colored, [])
    assert result.output == "ok\n\x1b[31mforced\x1b[0m\n"


def test_invalid_style_color_raises():
    with pytest.raises(TypeError):
        style("x", fg="chartreuse")
    assert unstyle(style("x", fg="bright_red", bold=True)) == "x"


def test_prompt_and_confirm_in_runner():
    @command()
    def ask():
        name = prompt("Name")
        yes = confirm("Sure?")
        echo(f"{name} {yes}")

    result = CliRunner().invoke(ask, [], input="Ann\ny\n")
    assert result.output == "Name: Ann\nSure? [y/N]: y\nAnn True\n"


def test_confirm_other_answers_count_as_no_and_eof_aborts():
    @command()
    def ask():
        echo(confirm("Go?"))

    runner = CliRunner()
    assert runner.invoke(ask, [], input="maybe\n").output.splitlines()[-1] == "False"
    assert runner.invoke(ask, [], input="").exit_code == 1


def test_hidden_prompt_input_not_echoed():
    @command()
    def pw():
        echo(prompt("Secret", hide_input=True))

    result = CliRunner().invoke(pw, [], input="hunter2\n")
    assert result.output == "Secret: \nhunter2\n"
