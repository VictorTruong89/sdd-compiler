import os
import sys

# Make `import optlyn` work when pytest is run from /app without PYTHONPATH=src.
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))
