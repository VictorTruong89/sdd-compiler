"""Behaviours pinned after review: feature switches, source precedence, eager flags, help names."""

from optlyn import Path, argument, command, echo, group, option, version_option
from optlyn.testing import CliRunner


def test_feature_switch_flags_share_destination_and_default_selects_flag_value():
    @command()
    @option("--fast", "mode", flag_value="fast")
    @option("--slow", "mode", flag_value="slow", default=True)
    def cmd(mode):
        echo(mode)

    runner = CliRunner()
    assert runner.invoke(cmd, ["--fast"]).output == "fast\n"
    assert runner.invoke(cmd, []).output == "slow\n"


def test_optional_value_option_takes_next_token_only_when_given():
    @command()
    @option("--level", is_flag=False, flag_value="high", default="low")
    def lvl(level):
        echo(level)

    runner = CliRunner()
    assert runner.invoke(lvl, ["--level"]).output == "high\n"
    assert runner.invoke(lvl, ["--level", "mid"]).output == "mid\n"
    assert runner.invoke(lvl, []).output == "low\n"


def test_eager_version_runs_even_with_required_option_missing():
    @command()
    @version_option("2.0", prog_name="svc")
    @option("--name", required=True)
    def svc(name):
        pass

    result = CliRunner().invoke(svc, ["--version"])
    assert result.exit_code == 0
    assert result.output == "svc, version 2.0\n"


def test_help_option_names_can_be_replaced_by_context_setting():
    @command(context_settings={"help_option_names": ["-h", "--halp"]})
    @option("--x")
    def hn(x):
        pass

    runner = CliRunner()
    assert runner.invoke(hn, ["-h"]).exit_code == 0
    assert runner.invoke(hn, ["--halp"]).output.startswith("Usage:")
    assert runner.invoke(hn, ["--help"]).exit_code == 2


def test_author_option_reusing_every_help_name_drops_automatic_help():
    @command()
    @option("--help", is_flag=True)
    def one_taken(help):
        echo(f"custom={help}")

    runner = CliRunner()
    assert runner.invoke(one_taken, ["--help"]).output == "custom=True\n"


def test_nested_group_without_subcommand_runs_outer_callbacks_then_shows_help():
    @group()
    def outer():
        echo("outer cb")

    @outer.group()
    def mid():
        """Middle group help."""
        echo("mid cb")

    @mid.command()
    def leaf():
        echo("leaf cb")

    result = CliRunner().invoke(outer, ["mid"])
    assert result.exit_code == 2
    assert result.output.startswith("outer cb\nUsage: outer mid [OPTIONS] COMMAND [ARGS]...")
    assert "mid cb" not in result.output
    assert CliRunner().invoke(outer, ["mid", "leaf"]).output == "outer cb\nmid cb\nleaf cb\n"


def test_default_map_value_beats_environment_variable_and_prompts_with_it_when_required():
    @command()
    @option("--port", envvar="PORT", type=int, default=80)
    def serve(port):
        echo(port)

    assert CliRunner().invoke(serve, [], env={"PORT": "9"}, default_map={"port": 5}).output == "5\n"


def test_completion_skips_option_values_when_choosing_argument():
    @group()
    def tool():
        pass

    @tool.command()
    @option("--color", type=_choice())
    @argument("path", type=Path())
    @argument("more", type=_choice(["m1", "m2"]), required=False)
    def build(color, path, more):
        pass

    def complete(words):
        env = {"_TOOL_COMPLETE": "bash_complete", "COMP_WORDS": " ".join(words),
               "COMP_CWORD": str(len(words) - 1)}
        return CliRunner().invoke(tool, [], env=env).output.split()

    assert complete(["tool", "build", "--color", "red", ""]) == ["file,"]
    assert complete(["tool", "build", "--color", "red", "x", ""]) == ["plain,m1", "plain,m2"]


def _choice(values=("red", "green")):
    from optlyn import Choice

    return Choice(list(values))
