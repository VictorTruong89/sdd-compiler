"""Groups, nesting, chaining, context settings, defaults and invocation."""

import pytest

from optlyn import (
    Abort,
    CommandCollection,
    Group,
    argument,
    command,
    echo,
    group,
    make_pass_decorator,
    option,
    pass_context,
    pass_obj,
)
from optlyn.testing import CliRunner


@pytest.fixture
def tool():
    @group()
    @option("--debug", is_flag=True)
    def cli(debug):
        """Top group."""
        echo(f"debug={debug}")

    @cli.command()
    @option("--n", type=int, default=3)
    def sub_one(n):
        """First sub."""
        echo(f"one {n}")

    @cli.command("two")
    def sub_two():
        echo("two")

    return cli


def test_group_callback_runs_before_child(tool):
    result = CliRunner().invoke(tool, ["--debug", "sub-one", "--n", "5"])
    assert result.output == "debug=True\none 5\n"
    assert result.exit_code == 0


def test_group_options_must_precede_subcommand(tool):
    result = CliRunner().invoke(tool, ["sub-one", "--debug"])
    assert result.exit_code == 2


def test_missing_subcommand_shows_help_as_usage_failure(tool):
    result = CliRunner().invoke(tool, [])
    assert result.exit_code == 2
    assert "Commands:" in result.output
    assert "Missing command." in result.output


def test_unknown_subcommand_is_usage_error(tool):
    result = CliRunner().invoke(tool, ["nope"])
    assert result.exit_code == 2
    assert "No such command 'nope'." in result.output


def test_help_before_subcommand_is_help_for_group(tool):
    result = CliRunner().invoke(tool, ["--help", "sub-one"])
    assert result.exit_code == 0
    assert "Usage: cli [OPTIONS] COMMAND [ARGS]..." in result.output


def test_group_help_lists_children_with_short_help(tool):
    result = CliRunner().invoke(tool, ["--help"])
    assert "sub-one" in result.output and "First sub." in result.output


def test_hidden_command_is_omitted_but_dispatchable():
    @group()
    def cli():
        pass

    @cli.command(hidden=True)
    def secret():
        echo("secret!")

    runner = CliRunner()
    assert "secret" not in runner.invoke(cli, ["--help"]).output
    assert runner.invoke(cli, ["secret"]).output == "secret!\n"


def test_chaining_group_runs_each_subcommand_and_result_callback():
    @group(chain=True)
    def pipe():
        pass

    @pipe.command()
    @argument("n", type=int)
    def add(n):
        return n + 1

    @pipe.command()
    @argument("n", type=int)
    def mul(n):
        return n * 10

    @pipe.result_callback()
    def done(results):
        echo(f"results={results}")

    result = CliRunner().invoke(pipe, ["add", "1", "mul", "5"])
    assert result.output == "results=[2, 50]\n"


def test_chaining_group_returns_list_without_standalone_mode():
    @group(chain=True)
    def pipe():
        pass

    @pipe.command()
    def one():
        return "a"

    assert pipe.main(["one", "one"], standalone_mode=False) == ["a", "a"]


def test_group_cannot_be_attached_beneath_chaining_group():
    chain = Group("chain", chain=True)
    with pytest.raises(TypeError):
        chain.add_command(Group("inner"))


def test_command_collection_unions_sources():
    @group()
    def a():
        pass

    @a.command()
    def c1():
        echo("c1")

    @group()
    def b():
        pass

    @b.command()
    def c2():
        echo("c2")

    both = CommandCollection(name="both", sources=[a, b])
    runner = CliRunner()
    assert runner.invoke(both, ["c1"]).output == "c1\n"
    assert runner.invoke(both, ["c2"]).output == "c2\n"


def test_lazy_listing_via_overrides():
    class Lazy(Group):
        def list_commands(self, ctx):
            return ["dynamic"]

        def get_command(self, ctx, name):
            if name == "dynamic":
                @command()
                def dynamic():
                    echo("loaded")

                return dynamic
            return None

    lazy = Lazy("lazy")
    assert CliRunner().invoke(lazy, ["dynamic"]).output == "loaded\n"


def test_default_map_nests_by_subcommand_and_beats_environment(tool):
    result = CliRunner().invoke(
        tool, ["sub-one"], default_map={"sub-one": {"n": 9}}, env={"N": None}
    )
    assert result.output == "debug=False\none 9\n"


def test_default_map_beats_environment_variable():
    @command()
    @option("--port", envvar="PORT", type=int, default=80)
    def serve(port):
        echo(port)

    runner = CliRunner()
    assert runner.invoke(serve, [], env={"PORT": "9"}, default_map={"port": 5}).output == "5\n"
    assert runner.invoke(serve, [], env={"PORT": "9"}).output == "9\n"


def test_auto_envvar_prefix_includes_subcommand_names_below_root():
    @group()
    def root():
        pass

    @root.command()
    @option("--token")
    def login(token):
        echo(token)

    runner = CliRunner()
    result = runner.invoke(root, ["login"], auto_envvar_prefix="APP", env={"APP_LOGIN_TOKEN": "t1"})
    assert result.output == "t1\n"


def test_parameter_source_reports_each_source():
    @command()
    @option("--x", default="v")
    @option("--y")
    @pass_context
    def insp(ctx, x, y):
        echo(f"{ctx.get_parameter_source('x')} {ctx.get_parameter_source('nope')}")

    runner = CliRunner()
    assert runner.invoke(insp, []).output.startswith("ParameterSource.DEFAULT None")
    assert "COMMANDLINE" in runner.invoke(insp, ["--x", "q"]).output


def test_pass_obj_and_ensure_object():
    class Settings:
        def __init__(self):
            self.level = 7

    @command()
    @make_pass_decorator(Settings, ensure=True)
    def show(settings):
        echo(settings.level)

    @command()
    @pass_obj
    def show_obj(obj):
        echo(obj)

    runner = CliRunner()
    assert runner.invoke(show).output == "7\n"
    assert runner.invoke(show_obj, [], obj="hello").output == "hello\n"


def test_invoke_and_forward_run_another_command():
    @command()
    @option("--a", default="x")
    def target(a):
        echo(f"target {a}")

    @command()
    @option("--a", default="y")
    @pass_context
    def caller(ctx, a):
        ctx.forward(target)
        ctx.invoke(target, a="z")

    assert CliRunner().invoke(caller, []).output == "target y\ntarget z\n"


def test_standalone_mode_off_propagates_errors_and_returns_value():
    @command()
    def ret():
        return 42

    assert ret.main([], standalone_mode=False) == 42
    with pytest.raises(Exception) as info:
        ret.main(["--nope"], standalone_mode=False)
    assert info.value.exit_code == 2


def test_abort_in_standalone_mode_exits_one_with_message():
    @command()
    def fails():
        raise Abort()

    result = CliRunner().invoke(fails)
    assert result.exit_code == 1
    assert result.output == "Aborted!\n"


def test_extra_arguments_rejected_unless_allowed():
    @command()
    @argument("first")
    def strict(first):
        echo(first)

    @command(context_settings={"allow_extra_args": True})
    @argument("first")
    def lenient(first):
        echo(first)

    runner = CliRunner()
    assert runner.invoke(strict, ["a", "b"]).exit_code == 2
    assert runner.invoke(lenient, ["a", "b"]).output == "a\n"


def test_ignore_unknown_options_lets_option_like_tokens_be_arguments():
    @command(context_settings={"ignore_unknown_options": True})
    @argument("rest", nargs=-1)
    def ign(rest):
        echo(repr(rest))

    assert CliRunner().invoke(ign, ["--zzz", "a"]).output == "('--zzz', 'a')\n"
