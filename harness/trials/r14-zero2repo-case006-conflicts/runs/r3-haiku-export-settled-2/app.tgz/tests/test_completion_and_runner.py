"""Shell completion, the in-process runner, and remaining terminal helpers."""

import os

import pytest

from optlyn import Choice, Path, argument, command, echo, group, option
from optlyn.testing import CliRunner
from optlyn.termui import echo_via_pager, getchar, progressbar


@pytest.fixture
def tool():
    @group()
    def tool():
        """Tool."""

    @tool.command()
    @option("--color", type=Choice(["red", "green", "blue"]), help="Pick")
    @option("--verbose", "-v", is_flag=True, help="Loud")
    @option("--hidden-opt", hidden=True)
    @argument("path", type=Path())
    def build(color, verbose, hidden_opt, path):
        """Build."""

    @tool.command(hidden=True)
    def secret():
        pass

    @tool.command()
    def deploy():
        """Deploy things."""

    return tool


def complete(tool, words, cword, shell="bash"):
    env = {
        "_TOOL_COMPLETE": f"{shell}_complete",
        "COMP_WORDS": " ".join(words),
        "COMP_CWORD": str(cword),
    }
    result = CliRunner().invoke(tool, [], env=env)
    assert result.exit_code == 0
    return result.output.splitlines()


def test_subcommand_names_suggested_hidden_omitted(tool):
    assert complete(tool, ["tool", ""], 1) == ["plain,build", "plain,deploy"]
    assert complete(tool, ["tool", "b"], 1) == ["plain,build"]


def test_options_only_after_dash_and_hidden_omitted(tool):
    lines = complete(tool, ["tool", "build", "-"], 2)
    assert "plain,--color" in lines and "plain,--verbose" in lines and "plain,-v" in lines
    assert "plain,--hidden-opt" not in lines


def test_choice_values_suggested_for_pending_option(tool):
    assert complete(tool, ["tool", "build", "--color", ""], 3) == [
        "plain,red", "plain,green", "plain,blue",
    ]
    assert complete(tool, ["tool", "build", "--color", "r"], 3, "zsh") == ["plain,red"]


def test_path_argument_asks_shell_for_files(tool):
    assert complete(tool, ["tool", "build", ""], 2) == ["file,"]


def test_unmatched_token_yields_empty_list(tool):
    assert complete(tool, ["tool", "build", "--color", "x"], 3) == []


def test_source_script_for_each_shell(tool):
    for shell in ("bash", "zsh", "fish", "powershell"):
        result = CliRunner().invoke(tool, [], env={"_TOOL_COMPLETE": f"{shell}_source"})
        assert result.exit_code == 0
        assert "_TOOL_COMPLETE" in result.output and shell_name_present(result.output, shell)


def shell_name_present(text, shell):
    return shell in text or "Register-ArgumentCompleter" in text


def test_unknown_instruction_runs_nothing(tool):
    result = CliRunner().invoke(tool, ["deploy"], env={"_TOOL_COMPLETE": "weird_thing"})
    assert result.exit_code == 1
    assert "Deploying" not in result.output and "plain," not in result.output


def test_other_variable_name_is_ignored(tool):
    result = CliRunner().invoke(tool, ["deploy"], env={"_OTHER_COMPLETE": "bash_complete"})
    assert result.exit_code == 0 and result.output == ""


def test_fd_capture_separates_stdout_and_stderr():
    @command()
    def both():
        echo("out")
        echo("err", err=True)

    result = CliRunner(capture="fd").invoke(both, [])
    assert result.stdout == "out\n"
    assert result.stderr == "err\n"


def test_interpreter_capture_keeps_write_order():
    @command()
    def both():
        echo("one")
        echo("two", err=True)
        echo("three")

    result = CliRunner().invoke(both, [])
    assert result.output == "one\ntwo\nthree\n"
    assert result.stdout == "one\nthree\n"


def test_runner_catches_exception_and_exposes_it():
    @command()
    def boom():
        raise ValueError("kaput")

    result = CliRunner().invoke(boom, [])
    assert result.exit_code == 1
    assert isinstance(result.exception, ValueError)


def test_runner_can_propagate_exceptions():
    @command()
    def boom():
        raise ValueError("kaput")

    with pytest.raises(ValueError):
        CliRunner().invoke(boom, [], catch_exceptions=False)


def test_env_none_unsets_variable(monkeypatch):
    monkeypatch.setenv("OPTLYN_TEST_VAR", "set")

    @command()
    def show():
        echo(os.environ.get("OPTLYN_TEST_VAR", "unset"))

    assert CliRunner().invoke(show, [], env={"OPTLYN_TEST_VAR": None}).output == "unset\n"
    assert os.environ["OPTLYN_TEST_VAR"] == "set"


def test_getchar_reads_from_runner_input():
    @command()
    def one():
        echo(getchar())

    assert CliRunner().invoke(one, [], input="xy").output == "x\n"


def test_pager_and_progressbar_without_terminal():
    @command()
    def pager():
        echo_via_pager(["a\n", "b\n"])
        with progressbar(range(3), label="Work") as bar:
            assert list(bar) == [0, 1, 2]

    result = CliRunner().invoke(pager, [])
    assert result.output == "a\nb\nWork\n"


def test_isolated_filesystem_is_left_in_place():
    runner = CliRunner()
    with runner.isolated_filesystem() as folder:
        with open("kept.txt", "w") as handle:
            handle.write("x")
        assert os.getcwd() == os.path.realpath(folder) or os.getcwd() == folder
    assert os.path.exists(os.path.join(folder, "kept.txt"))
