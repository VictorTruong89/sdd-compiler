"""Parameter types: conversion of command-line tokens into Python values."""

from __future__ import annotations

import datetime as _dt
import enum
import os
import pathlib
import uuid

from .exceptions import BadParameter
from .utils import format_filename, open_file


class ParamType:
    """Base class for parameter types. Subclasses implement :meth:`convert`."""

    # spec: N-000929 — `name` is shown upper-cased as the default metavar.
    name = "text"
    is_composite = False

    def __call__(self, value, param=None, ctx=None):
        return self.convert(value, param, ctx)

    def convert(self, value, param, ctx):
        return value

    def get_metavar(self, param):
        return None

    def get_default_metavar(self):
        return self.name.upper()

    def split_envvar_value(self, rv):
        return rv.split()

    def shell_complete(self, ctx, param, incomplete):
        return []

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"


class FuncParamType(ParamType):
    """Adapts a conversion function ``f(token) -> value`` into a parameter type."""

    # spec: N-000872 — a conversion function that refuses by raising ValueError.

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text") or "text"

    def convert(self, value, param, ctx):
        try:
            return self.func(value)
        except BadParameter:
            raise
        except ValueError as e:
            self.fail(str(e) or f"{value!r} is not valid", param, ctx)


class _StringType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        # spec: N-000320 — an explicit string type keeps numeric/boolean-looking tokens as text.
        if isinstance(value, str):
            return value
        if isinstance(value, (bytes, bytearray)):
            return bytes(value).decode("utf-8", "replace")
        return str(value)


class _UnprocessedType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        # spec: N-000360 — pass-through, no conversion.
        return value


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param, ctx):
        # spec: N-000321, N-000322, N-000323, N-000324
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            return int(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param, ctx):
        # spec: N-000330, N-000331
        if isinstance(value, float):
            return value
        if isinstance(value, int) and not isinstance(value, bool):
            return float(value)
        try:
            return float(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


class BoolParamType(ParamType):
    name = "boolean"

    _true = {"1", "true", "t", "yes", "y", "on"}
    _false = {"0", "false", "f", "no", "n", "off"}

    def convert(self, value, param, ctx):
        # spec: N-000332, N-000333, N-000334, N-000335, N-000336
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in self._true:
            return True
        if text in self._false:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param, ctx):
        # spec: N-000337, N-000338
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


STRING = _StringType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = _UnprocessedType()


class Choice(ParamType):
    """A closed list of allowed values, or the members of an enumeration."""

    # spec: N-000339, N-000340, N-000341, N-000342, N-000343, N-000373, N-000374
    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        self._enum = None
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self._enum = choices
            choices = list(choices)
        self.choices = list(choices)
        self.case_sensitive = case_sensitive

    @staticmethod
    def _text(value):
        if isinstance(value, enum.Enum):
            return value.name
        return str(value)

    def _key(self, value, ctx=None):
        text = self._text(value)
        normalize = getattr(ctx, "token_normalize_func", None) if ctx is not None else None
        if normalize is not None:
            text = normalize(text)
        if not self.case_sensitive:
            text = text.casefold()
        return text

    def convert(self, value, param, ctx):
        if any(value is choice for choice in self.choices):
            return value
        wanted = self._key(value, ctx)
        for choice in self.choices:
            if self._key(choice, ctx) == wanted:
                return choice
        allowed = ", ".join(repr(self._text(c)) for c in self.choices)
        self.fail(f"{self._text(value)!r} is not one of {allowed}.", param, ctx)

    def get_metavar(self, param):
        # spec: N-000832 — closed choice lists its values in the help entry.
        return "[" + "|".join(self._text(c) for c in self.choices) + "]"

    def get_default_metavar(self):
        return self.get_metavar(None)

    def shell_complete(self, ctx, param, incomplete):
        # spec: N-000682, N-000683 — suggest only allowed values matching the prefix.
        from .shell_completion import CompletionItem

        found = []
        for choice in self.choices:
            text = self._text(choice)
            candidate = text
            probe = incomplete
            if not self.case_sensitive:
                candidate, probe = candidate.casefold(), probe.casefold()
            if candidate.startswith(probe):
                found.append(CompletionItem(text))
        return found


class DateTime(ParamType):
    """Parses a date and time with the first matching format."""

    # spec: N-000344, N-000345, N-000346, N-000347, N-000348
    name = "datetime"

    DEFAULT_FORMATS = ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S")

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(self.DEFAULT_FORMATS)

    def convert(self, value, param, ctx):
        if isinstance(value, _dt.datetime):
            return value
        text = str(value).strip()
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(text, fmt)
            except ValueError:
                continue
        formats = ", ".join(repr(f) for f in self.formats)
        self.fail(f"{value!r} does not match the format {formats}.", param, ctx)


class IntRange(ParamType):
    """An integer within an optional range, optionally clamped into it."""

    # spec: N-000349, N-000350, N-000351, N-000352, N-000353
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param, ctx):
        rv = INT.convert(value, param, ctx)
        below = self.min is not None and (rv < self.min or (self.min_open and rv == self.min))
        above = self.max is not None and (rv > self.max or (self.max_open and rv == self.max))
        if not (below or above):
            return rv
        if self.clamp:
            if below:
                return self.min + 1 if self.min_open else self.min
            return self.max - 1 if self.max_open else self.max
        self.fail(f"{rv} is not in the valid range of {self._range_text()}.", param, ctx)

    def _range_text(self):
        lo = "-inf" if self.min is None else self.min
        hi = "inf" if self.max is None else self.max
        left = "(" if self.min_open else "["
        right = ")" if self.max_open else "]"
        return f"{left}{lo}, {hi}{right}"


class FloatRange(ParamType):
    """A float within an optional range. Clamping needs both bounds closed."""

    # spec: N-000354, N-000355, N-000356, N-000372
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min_open or max_open):
            raise ValueError("Clamping is not supported for open bounds.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param, ctx):
        rv = FLOAT.convert(value, param, ctx)
        below = self.min is not None and (rv < self.min or (self.min_open and rv == self.min))
        above = self.max is not None and (rv > self.max or (self.max_open and rv == self.max))
        if not (below or above):
            return rv
        if self.clamp:
            return self.min if below else self.max
        lo = "-inf" if self.min is None else self.min
        hi = "inf" if self.max is None else self.max
        left = "(" if self.min_open else "["
        right = ")" if self.max_open else "]"
        self.fail(f"{rv} is not in the valid range of {left}{lo}, {hi}{right}.", param, ctx)


class Tuple(ParamType):
    """A fixed-length product of inner types, one per position."""

    # spec: N-000357, N-000925
    name = "tuple"
    is_composite = True

    def __init__(self, types):
        self.types = [convert_type(t) for t in types]

    def convert(self, value, param, ctx):
        if isinstance(value, str) or not hasattr(value, "__len__") or len(value) != len(self.types):
            self.fail(f"{value!r} must be a sequence of {len(self.types)} items.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))

    def get_default_metavar(self):
        return " ".join(t.get_default_metavar() for t in self.types)


class File(ParamType):
    """Opens a file. ``-`` is standard input for reading and standard output for writing."""

    # spec: N-000358, N-000518, N-000519, N-000520, N-000522, N-000523, N-000524, N-000525
    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"Unsupported file mode {mode!r}.")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def convert(self, value, param, ctx):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        lazy = self.lazy
        if lazy is None:
            # spec: N-000526, N-000527 — writes open on first I/O by default; reads open immediately.
            lazy = "w" in self.mode
        encoding = None if "b" in self.mode else self.encoding
        errors = None if "b" in self.mode else self.errors
        try:
            handle = open_file(
                value, self.mode, encoding=encoding, errors=errors or "strict",
                lazy=lazy, atomic=self.atomic,
            )
        except OSError as e:
            # spec: N-000569 — a file that cannot be opened while converting is a usage error.
            self.fail(f"'{format_filename(value)}': {e.strerror or e}.", param, ctx)
        if ctx is not None and value != "-":
            ctx.call_on_close(handle.close)
        return handle

    def split_envvar_value(self, rv):
        # spec: N-000565
        return rv.split(os.pathsep)

    def shell_complete(self, ctx, param, incomplete):
        # spec: N-000686, N-000687 — ask the shell to complete file names.
        from .shell_completion import CompletionItem

        return [CompletionItem(incomplete, type="file")]


class Path(ParamType):
    """Validates a filesystem path and returns the path, not an open file."""

    # spec: N-000359, N-000538 .. N-000564, N-000574 .. N-000578
    name = "path"

    def __init__(self, exists=False, file_okay=True, dir_okay=True, writable=False,
                 readable=True, resolve_path=False, allow_dash=False, path_type=None,
                 executable=False):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def convert(self, value, param, ctx):
        if self.allow_dash and value == "-":
            # spec: N-000542 — the dash is delivered as the path '-'; no stream is read.
            return self._finish("-")
        rv = format_filename(value)
        if self.resolve_path:
            rv = os.path.realpath(rv)
        if not os.path.exists(rv):
            if self.exists:
                self.fail(f"{format_filename(rv)!r} does not exist.", param, ctx)
            return self._finish(rv)

        is_dir = os.path.isdir(rv)
        is_file = os.path.isfile(rv)
        if not self.file_okay and is_file:
            self.fail(f"{format_filename(rv)!r} is a file.", param, ctx)
        if not self.dir_okay and is_dir:
            self.fail(f"{format_filename(rv)!r} is a directory.", param, ctx)
        # spec: N-000572, N-000573 — permission checks apply only to a path that exists.
        if self.readable and not os.access(rv, os.R_OK):
            self.fail(f"{format_filename(rv)!r} is not readable.", param, ctx)
        if self.writable and not os.access(rv, os.W_OK):
            self.fail(f"{format_filename(rv)!r} is not writable.", param, ctx)
        if self.executable and not os.access(rv, os.X_OK):
            self.fail(f"{format_filename(rv)!r} is not executable.", param, ctx)
        return self._finish(rv)

    def _finish(self, rv):
        if self.path_type is pathlib.Path:
            return pathlib.Path(rv)
        return rv

    def split_envvar_value(self, rv):
        # spec: N-000565
        return rv.split(os.pathsep)

    def shell_complete(self, ctx, param, incomplete):
        # spec: N-000686, N-000687 — directories only when only directories are allowed.
        from .shell_completion import CompletionItem

        kind = "dir" if self.dir_okay and not self.file_okay else "file"
        return [CompletionItem(incomplete, type=kind)]


def convert_type(ty, default=None):
    """Turn a type spec (instance, class, Python type, function, or None) into a ParamType."""
    # spec: N-000872, N-000923 — instance, subclass, or conversion function.
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, tuple):
        return Tuple(ty)
    if ty is None and default is not None:
        if isinstance(default, (list, tuple)):
            return convert_type(None, default[0]) if default else STRING
        return _infer(default)
    if ty is None:
        return STRING
    if isinstance(ty, type):
        if issubclass(ty, ParamType):
            return ty()
        mapping = {str: STRING, int: INT, float: FLOAT, bool: BOOL, uuid.UUID: UUID}
        if ty in mapping:
            return mapping[ty]
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"Unsupported parameter type {ty!r}.")


def _infer(value):
    if isinstance(value, bool):
        return BOOL
    if isinstance(value, int):
        return INT
    if isinstance(value, float):
        return FLOAT
    if isinstance(value, uuid.UUID):
        return UUID
    return STRING
