"""Terminal helpers: echo, styling, prompts, progress bars, pager, editor and launch."""

from __future__ import annotations

import contextlib
import io
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import time

from .exceptions import Abort, BadParameter
from .utils import get_current_context

_ANSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")

_COLOR_NAMES = {
    "black": 0, "red": 1, "green": 2, "yellow": 3,
    "blue": 4, "magenta": 5, "cyan": 6, "white": 7,
}
_BRIGHT_OFFSET = 60  # bright_black is 90, black is 30
_RESET_FG, _RESET_BG = 39, 49

_SWITCHES = [
    # keyword, on code, off code
    ("bold", 1, 22),
    ("dim", 2, 22),
    ("italic", 3, 23),
    ("underline", 4, 24),
    ("blink", 5, 25),
    ("reverse", 7, 27),
    ("strikethrough", 9, 29),
    ("overline", 53, 55),
]


def _isatty(stream):
    try:
        return bool(stream.isatty())
    except Exception:
        return False


def _is_interactive():
    return _isatty(sys.stdin) and _isatty(sys.stdout)


def _resolve_color(color):
    if color is not None:
        return color
    ctx = get_current_context(silent=True)
    if ctx is not None and ctx.color is not None:
        return ctx.color
    return None


def _should_strip(file, color):
    # spec: N-000610, N-000613, N-000614, N-000615, N-000670, N-000671, N-000672
    resolved = _resolve_color(color)
    if resolved is True:
        return False
    if resolved is False:
        return True
    return not _isatty(file)


def _write_text(file, text):
    try:
        file.write(text)
    except UnicodeEncodeError:
        # spec: N-000610 — a stream that cannot encode the text gets UTF-8 bytes instead.
        try:
            file.flush()
        except Exception:
            pass
        buffer = getattr(file, "buffer", None)
        if buffer is not None:
            buffer.write(text.encode("utf-8"))
            buffer.flush()
        else:
            encoding = getattr(file, "encoding", None) or "ascii"
            file.write(text.encode(encoding, "backslashreplace").decode(encoding))


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write ``message`` (str or bytes) to stdout, stderr or ``file``."""
    # spec: N-000609, N-000963, N-000964, N-000966, N-000967
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, (bytes, bytearray)):
        data = bytes(message) + (b"\n" if nl else b"")
        buffer = getattr(file, "buffer", None)
        try:
            file.flush()
        except Exception:
            pass
        (buffer if buffer is not None else file).write(data)
    else:
        text = str(message) + ("\n" if nl else "")
        if _should_strip(file, color):
            text = unstyle(text)
        _write_text(file, text)
    try:
        file.flush()
    except Exception:
        pass


def _color_code(color, background):
    base = 40 if background else 30
    if isinstance(color, str):
        if color == "reset":
            return str(_RESET_BG if background else _RESET_FG)
        bright = color.startswith("bright_")
        name = color[len("bright_"):] if bright else color
        if name in _COLOR_NAMES:
            code = base + _COLOR_NAMES[name] + (_BRIGHT_OFFSET if bright else 0)
            return str(code)
        raise TypeError(f"Unknown color {color!r}.")
    if isinstance(color, bool):
        raise TypeError(f"Unknown color {color!r}.")
    if isinstance(color, int):
        if 0 <= color <= 255:
            return f"{base + 8};5;{color}"
        raise TypeError(f"Color index {color} is out of range.")
    if isinstance(color, (tuple, list)) and len(color) == 3 and all(
        isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
    ):
        return f"{base + 8};2;{color[0]};{color[1]};{color[2]}"
    raise TypeError(f"Unknown color {color!r}.")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True):
    """Wrap ``text`` in ANSI SGR sequences for the given colors and switches."""
    # spec: N-000618, N-000619, N-000620, N-000621, N-000622, N-000623, N-000624, N-000625
    # spec: N-000626, N-000627, N-000628, N-000629, N-000630, N-000676
    codes = []
    if fg is not None:
        codes.append(_color_code(fg, False))
    if bg is not None:
        codes.append(_color_code(bg, True))
    values = {
        "bold": bold, "dim": dim, "underline": underline, "overline": overline,
        "italic": italic, "blink": blink, "reverse": reverse, "strikethrough": strikethrough,
    }
    for keyword, on_code, off_code in _SWITCHES:
        flag = values[keyword]
        if flag is not None:
            codes.append(str(on_code if flag else off_code))
    if not codes:
        return str(text)
    prefix = "\x1b[" + ";".join(codes) + "m"
    return prefix + str(text) + ("\x1b[0m" if reset else "")


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    """Echo ``message`` after applying :func:`style` with the given keywords."""
    # spec: N-000618 (styled echo is echo plus styling in one step)
    if message is not None:
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def unstyle(text):
    """Remove ANSI escape sequences from ``text``."""
    # spec: N-000630
    return _ANSI_RE.sub("", str(text))


class _StrippingWriter:
    """A writable stream that drops ANSI styles before writing."""

    def __init__(self, stream):
        self._stream = stream

    def write(self, text):
        return self._stream.write(unstyle(text))

    def __getattr__(self, name):
        return getattr(self._stream, name)


def _pager_command():
    return os.environ.get("PAGER") or "less"


def _iter_chunks(text_or_generator):
    if callable(text_or_generator):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, (str, bytes)):
        return [text_or_generator]
    return iter(text_or_generator)


@contextlib.contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream that goes through the pager when interactive."""
    # spec: N-000631, N-000632, N-000633, N-000634, N-000635, N-000636, N-000637
    keep = _resolve_color(color) is True
    if _is_interactive():
        proc = subprocess.Popen(_pager_command(), shell=True, stdin=subprocess.PIPE)
        pipe = io.TextIOWrapper(proc.stdin, encoding="utf-8", write_through=True)
        try:
            yield _StyleFilter(pipe, keep)
        finally:
            try:
                pipe.close()
            except Exception:
                pass
            proc.wait()
        return
    # spec: N-000638 — the process's own stdout is never closed by the pager stream.
    yield _StyleFilter(sys.stdout, keep or _isatty(sys.stdout))


class _StyleFilter:
    """Text writer that flushes after each write and drops styles unless kept."""

    def __init__(self, stream, keep_styles):
        self._stream = stream
        self._keep = keep_styles

    def write(self, text):
        if not self._keep:
            text = unstyle(text)
        _write_text(self._stream, text)
        self.flush()
        return len(text)

    def flush(self):
        try:
            self._stream.flush()
        except Exception:
            pass


def echo_via_pager(text_or_generator, color=None):
    """Show long text through the pager when interactive; otherwise write it to stdout."""
    # spec: N-000631, N-000632, N-000633, N-000634, N-000635, N-000636, N-000637, N-000638
    chunks = _iter_chunks(text_or_generator)
    with get_pager_file(color=color) as stream:
        for chunk in chunks:
            stream.write(chunk.decode("utf-8") if isinstance(chunk, bytes) else chunk)
            stream.flush()


class ProgressBar:
    """Wraps an iterable (or a known length) and shows progress on a terminal."""

    # spec: N-000639, N-000640, N-000641, N-000642, N-000643, N-000644, N-000645, N-000646, N-000647

    def __init__(self, iterable=None, length=None, label=None, hidden=False, **options):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label
        self.hidden = hidden
        self.pos = 0
        self.width = options.get("width", 36)
        self._started = time.monotonic()
        self._tty = (not hidden) and _isatty(sys.stdout)
        self._rendered = False
        self._label_printed = False

    def __enter__(self):
        if not self.hidden and not self._tty and self.label and not self._label_printed:
            echo(self.label)
            self._label_printed = True
        if self._tty:
            self.render_progress()
        return self

    def __exit__(self, exc_type, exc, tb):
        if self._rendered:
            echo(err=False)
        return None

    def __iter__(self):
        if self.iterable is None:
            return
        for item in self.iterable:
            yield item
            self.update(1)

    def update(self, n_steps):
        self.pos += n_steps
        if self._tty:
            self.render_progress()

    def _eta_text(self):
        if not self.length or self.pos <= 0:
            return ""
        elapsed = time.monotonic() - self._started
        remaining = elapsed / self.pos * max(self.length - self.pos, 0)
        seconds = int(remaining)
        return f"  {seconds // 3600:02d}:{(seconds % 3600) // 60:02d}:{seconds % 60:02d}"

    def render_progress(self):
        label = (self.label or "") + "  " if self.label else ""
        if self.length:
            done = min(self.width, int(self.width * self.pos / self.length))
            bar = "#" * done + "-" * (self.width - done)
            text = f"\r{label}[{bar}]  {self.pos}/{self.length}{self._eta_text()}"
        else:
            text = f"\r{label}{self.pos}"
        echo(text, nl=False)
        self._rendered = True


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    """Return a progress bar (a context manager that is also iterable)."""
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)


def _read_line(hide_input, err):
    """Read one line from standard input. Returns None at end of file."""
    # spec: N-000491, N-000500, N-000510, N-000514
    stream = sys.stdin
    reader = getattr(stream, "_optlyn_read_line", None)
    if reader is not None:
        line = reader(echo=not hide_input)
        if hide_input and line is not None:
            echo("", err=err)
        return line
    if hide_input and _isatty(stream):
        import getpass

        try:
            line = getpass.getpass("")
        except EOFError:
            return None
        return line
    line = stream.readline()
    if not line:
        return None
    if hide_input:
        echo("", err=err)
    return line.rstrip("\r\n")


def _ask(text, default_display, hide_input, err, suffix=": "):
    prompt_text = text
    if default_display is not None:
        prompt_text += f" [{default_display}]"
    echo(prompt_text + suffix, nl=False, err=err)
    line = _read_line(hide_input, err)
    if line is None:
        raise Abort()
    return line


def _prompt_raw(text, default_display=None, hide_input=False, confirmation_prompt=False,
                err=False, suffix=": "):
    """Ask for a line, optionally twice for confirmation. Returns the raw answer."""
    # spec: N-000500, N-000501, N-000502
    while True:
        first = _ask(text, default_display, hide_input, err, suffix)
        if not confirmation_prompt:
            return first
        second = _ask("Repeat for confirmation", None, hide_input, err, suffix)
        if first == second:
            return first
        echo("Error: The two entered values do not match.", err=True)


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False, show_choices=True):
    """Ask for a value and return it converted by ``type`` (or the type of ``default``)."""
    # spec: N-000478, N-000491, N-000510, N-000511, N-000512
    from .paramtypes import convert_type

    param_type = convert_type(type, default)
    display = str(default) if default is not None and show_default else None
    while True:
        line = _prompt_raw(text, display, hide_input, confirmation_prompt, err, suffix=prompt_suffix)
        if line == "":
            if default is not None:
                return default
            continue
        try:
            if value_proc is not None:
                return value_proc(line)
            return param_type.convert(line, None, get_current_context(silent=True))
        except BadParameter as e:
            echo(f"Error: {e.format_message()}", err=True)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    """Ask a yes/no question and return the answer as a bool."""
    # spec: N-000491, N-000492, N-000493, N-000494, N-000495, N-000496, N-000497, N-001015
    suffix = ""
    if show_default:
        suffix = " [Y/n]" if default else " [y/N]"
    echo(text + suffix + prompt_suffix, nl=False, err=err)
    line = _read_line(False, err)
    if line is None:
        raise Abort()
    answer = line.strip().lower()
    if answer == "":
        result = bool(default)
    elif answer in ("y", "yes"):
        result = True
    else:
        result = False
    if abort and not result:
        raise Abort()
    return result


_echo_text = echo


def _getchar_posix():
    import termios
    import tty

    try:
        fd = os.open("/dev/tty", os.O_RDONLY)
    except OSError as e:
        raise EOFError("No controlling terminal to read a character from.") from e
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            data = os.read(fd, 1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
    finally:
        os.close(fd)
    return data.decode("utf-8", "replace")


def _getchar_windows():
    import msvcrt

    return msvcrt.getwch()


def getchar(echo=False):
    """Read one character from the terminal (not from a piped standard input)."""
    # spec: N-000648, N-000649, N-000650, N-000651
    runner_reader = getattr(sys.stdin, "_optlyn_getchar", None)
    if runner_reader is not None:
        char = runner_reader()
    elif os.name == "nt":
        char = _getchar_windows()
    else:
        char = _getchar_posix()
    if char == "\x03":
        raise KeyboardInterrupt()
    if char in ("\x04", "\x1a", ""):
        raise EOFError()
    if echo:
        _echo_text(char, nl=False)
    return char


def pause(info=None, err=False):
    """Print a message and wait for a key, only when the session is interactive."""
    # spec: N-000652, N-000653, N-000675
    if not _is_interactive():
        return
    if info is None:
        info = "Press any key to continue..."
    echo(info, nl=False, err=err)
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        raise
    echo(err=err)


def _run_editor(editor, path, env):
    command = shlex.split(editor) if isinstance(editor, str) else list(editor)
    merged = dict(os.environ)
    if env:
        merged.update(env)
    subprocess.call(command + [path], env=merged)


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Open ``text`` (or ``filename``) in an editor. Returns the saved text or None."""
    # spec: N-000654, N-000655, N-000656
    if editor is None:
        editor = (
            os.environ.get("VISUAL") or os.environ.get("EDITOR")
            or ("notepad" if os.name == "nt" else "vi")
        )
    if filename is not None:
        _run_editor(editor, filename, env)
        return None
    original = "" if text is None else str(text)
    fd, path = tempfile.mkstemp(prefix="optlyn-edit-", suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(original)
        _run_editor(editor, path, env)
        with open(path, encoding="utf-8", newline=None) as handle:
            saved = handle.read()
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
    if require_save and saved == original:
        return None
    return saved


def launch(url, wait=False, locate=False):
    """Open ``url`` or a file with the default application. Returns a status value."""
    # spec: N-000657, N-000658, N-000659, N-000660, N-000661
    if os.name == "nt":
        os.startfile(url)  # noqa: S606 — launching is the documented behaviour
        return 0
    if sys.platform == "darwin":
        command = ["open", "-R", url] if locate else ["open", url]
    else:
        opener = shutil.which("xdg-open") or shutil.which("open")
        if opener is None:
            return 127
        command = [opener, url]
    proc = subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if wait:
        return proc.wait()
    return 0


def clear():
    """Clear the terminal screen; does nothing when stdout is not a terminal."""
    # spec: N-000662, N-000663
    if not _isatty(sys.stdout):
        return
    echo("\033[2J\033[H", nl=False)
