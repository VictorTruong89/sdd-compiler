"""Declaration decorators: commands, groups, options, arguments and ready-made options."""

from __future__ import annotations

import functools
import importlib.metadata as _metadata
import inspect

from .core import Argument, Command, Group, Option, _show_help
from .termui import echo
from .utils import get_current_context


def _param_memo(f, param):
    # spec: N-000834 .. N-000851 — declarations stay on the function until a command is built.
    if isinstance(f, Command):
        raise TypeError("Declarations must be attached before the command is created.")
    if not hasattr(f, "__optlyn_params__"):
        f.__optlyn_params__ = []
    f.__optlyn_params__.append(param)


def _derive_name(f):
    # spec: N-000073 .. N-000076 — the function name, lowercased, underscores to dashes, suffix stripped.
    name = f.__name__.lower().replace("_", "-")
    stem, sep, suffix = name.rpartition("-")
    if sep and suffix in {"command", "cmd", "group", "grp"}:
        name = stem
    return name


def _docstring_help(f, attrs):
    if attrs.get("help") is None and f.__doc__:
        text = inspect.cleandoc(f.__doc__)
        # spec: N-000109 — a form feed truncates the help text.
        text = text.split("\f", 1)[0].rstrip()
        attrs["help"] = text


def _build(cls, default_cls, name, f, attrs):
    params = f.__dict__.pop("__optlyn_params__", [])
    params.reverse()
    _docstring_help(f, attrs)
    if name is None:
        name = _derive_name(f)
    if cls is None:
        cls = default_cls
    return cls(name=name, callback=f, params=params, **attrs)


def command(name=None, cls=None, **attrs):
    """Turn a function into a command (``@command()`` or ``@command``)."""
    # spec: N-000834 .. N-000841
    if callable(name) and not isinstance(name, str):
        return command()(name)

    def decorator(f):
        return _build(cls, Command, name, f, dict(attrs))

    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a group (``@group()`` or ``@group``)."""
    # spec: N-000850 .. N-000852
    if callable(name) and not isinstance(name, str):
        return group()(name)

    def decorator(f):
        return _build(cls, Group, name, f, dict(attrs))

    return decorator


def option(*param_decls, cls=None, **attrs):
    """Attach an option to a command or group."""
    # spec: N-000868 .. N-000872
    cls = cls or Option

    def decorator(f):
        _param_memo(f, cls(list(param_decls), **attrs))
        return f

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach a positional argument to a command or group."""
    # spec: N-000897 .. N-000899
    cls = cls or Argument

    def decorator(f):
        _param_memo(f, cls(list(param_decls), **attrs))
        return f

    return decorator


def help_option(*param_decls, **kwargs):
    """An extra eager help flag that prints the help page and exits."""
    # spec: N-000911, N-000916
    if not param_decls:
        param_decls = ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _show_help)
    return option(*param_decls, **kwargs)


def _detect_version(package_name):
    # spec: N-000917, N-000918 — the installed distribution, or the one providing that import.
    try:
        return _metadata.version(package_name)
    except _metadata.PackageNotFoundError:
        pass
    mapping = _metadata.packages_distributions()
    for dist in mapping.get(package_name, []):
        try:
            return _metadata.version(dist)
        except _metadata.PackageNotFoundError:
            continue
    raise RuntimeError(f"Could not determine the version of {package_name!r}.")


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None,
                   **kwargs):
    """An eager flag that prints the program's version and exits."""
    # spec: N-000912, N-000917, N-000918, N-000830, N-000831, N-000832
    if not param_decls:
        param_decls = ("--version",)
    if version is None and package_name is None:
        frame = inspect.currentframe()
        caller = frame.f_back if frame is not None else None
        module_name = caller.f_globals.get("__name__", "") if caller is not None else ""
        package_name = module_name.partition(".")[0] or None

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        ident = version if version is not None else _detect_version(package_name)
        prog = prog_name if prog_name is not None else ctx.find_root().info_name
        template = message or "%(prog)s, version %(version)s"
        echo(template % {"prog": prog, "package": package_name, "version": ident}, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*param_decls, **kwargs)


def custom_version_option(callback, *param_decls, **kwargs):
    """An eager flag whose printed identity is exactly the string the callback returns."""
    # spec: N-000919, N-000833
    if not param_decls:
        param_decls = ("--version",)

    def version_callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(callback(ctx), color=True)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = version_callback
    return option(*param_decls, **kwargs)


def password_option(*param_decls, **kwargs):
    """A hidden, prompting, confirmed option (default ``--password``)."""
    # spec: N-000913
    if not param_decls:
        param_decls = ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    return option(*param_decls, **kwargs)


def confirmation_option(*param_decls, **kwargs):
    """A yes-flag that prompts when omitted and aborts when the user declines."""
    # spec: N-000914, N-000503 .. N-000509

    def callback(ctx, param, value):
        if not value:
            ctx.abort()
        return value

    if not param_decls:
        param_decls = ("--yes",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("callback", callback)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")
    return option(*param_decls, **kwargs)


def pass_context(f):
    """Pass the current context as the first argument."""
    # spec: N-000957

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(f):
    """Pass the current context's author object as the first argument."""
    # spec: N-000957, N-000424 .. N-000433

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        ctx = get_current_context()
        return ctx.invoke(f, ctx.obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type, ensure=False):
    """Build a decorator that passes the nearest object of ``object_type``."""
    # spec: N-000959, N-000426, N-000427, N-000428

    def decorator(f):
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(
                    f"Managed to invoke callback without a context object of type "
                    f"{object_type.__name__!r} existing."
                )
            return ctx.invoke(f, obj, *args, **kwargs)

        return new_func

    return decorator


