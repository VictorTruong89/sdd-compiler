"""Shared helpers: the per-thread context stack, file and stream opening, and paths."""

from __future__ import annotations

import os
import re
import sys
import tempfile
import threading

from .exceptions import FileError

_local = threading.local()


def _context_stack():
    stack = getattr(_local, "stack", None)
    if stack is None:
        stack = _local.stack = []
    return stack


def get_current_context(silent=False):
    """Return the context current on this thread, or None / raise when there is none."""
    # spec: N-000960, N-000961, N-000962
    stack = _context_stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context on this thread.")


def push_context(ctx):
    _context_stack().append(ctx)


def pop_context(ctx):
    stack = _context_stack()
    if stack and stack[-1] is ctx:
        stack.pop()
    elif ctx in stack:
        stack.remove(ctx)


class StdStreamProxy:
    """Wraps a process standard stream so that closing it leaves the real stream open."""

    # spec: N-000579, N-000580, N-000537

    def __init__(self, stream):
        object.__setattr__(self, "_stream", stream)

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __iter__(self):
        return iter(self._stream)

    def close(self):
        try:
            self._stream.flush()
        except Exception:
            pass

    @property
    def closed(self):
        return False

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return None


class _AtomicFile:
    """Writes to a sibling temporary file and replaces the target when closed."""

    # spec: N-000528, N-000529

    def __init__(self, filename, mode, encoding, errors):
        self._filename = filename
        directory = os.path.dirname(os.path.abspath(filename))
        fd, self._tmp_name = tempfile.mkstemp(dir=directory, prefix=".optlyn-", suffix=".tmp")
        os.close(fd)
        self._file = _open_plain(self._tmp_name, mode, encoding, errors)
        self._closed = False

    def __getattr__(self, name):
        return getattr(self._file, name)

    def __iter__(self):
        return iter(self._file)

    def close(self):
        if self._closed:
            return
        self._closed = True
        self._file.close()
        os.replace(self._tmp_name, self._filename)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return None


def _open_plain(filename, mode, encoding, errors):
    if "b" in mode:
        return open(filename, mode)
    return open(filename, mode, encoding=encoding, errors=errors)


def _open_real(filename, mode, encoding, errors, atomic):
    if atomic and any(flag in mode for flag in "wax+"):
        return _AtomicFile(filename, mode, encoding, errors)
    return _open_plain(filename, mode, encoding, errors)


class LazyFile:
    """Opens its target on the first I/O operation instead of when created."""

    # spec: N-000526, N-000527, N-000533, N-000534, N-000535

    def __init__(self, filename, mode, encoding, errors, atomic):
        self.name = filename
        self._args = (mode, encoding, errors, atomic)
        self._file = None

    def _ensure_open(self):
        if self._file is None:
            mode, encoding, errors, atomic = self._args
            try:
                self._file = _open_real(self.name, mode, encoding, errors, atomic)
            except OSError as e:
                raise FileError(format_filename(self.name), e.strerror or str(e)) from e
        return self._file

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return getattr(self._ensure_open(), name)

    def __iter__(self):
        return iter(self._ensure_open())

    def close(self):
        if self._file is not None:
            self._file.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return None


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file, or a standard stream when the name is ``-``."""
    # spec: N-000537, N-000579, N-000580, N-000581, N-000758

    if filename == "-":
        stream = sys.stdin if "r" in mode else sys.stdout
        if "b" in mode:
            stream = getattr(stream, "buffer", stream)
        return StdStreamProxy(stream)
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    return _open_real(filename, mode, encoding, errors, atomic)


def format_filename(filename, shorten=False):
    """Turn a path into printable text that encodes as strict UTF-8."""
    # spec: N-000566, N-000567, N-000568

    if isinstance(filename, (bytes, bytearray)):
        name = os.fsdecode(bytes(filename))
    else:
        name = os.fspath(filename)
        if isinstance(name, bytes):
            name = os.fsdecode(name)
    if shorten:
        name = os.path.basename(name)
    return name.encode("utf-8", "backslashreplace").decode("utf-8")


def get_app_dir(app_name, roaming=True, force_posix=False):
    """Return the per-user configuration directory for ``app_name``."""
    # spec: N-000664, N-000665, N-000666, N-000667, N-000668

    home = os.path.expanduser("~")
    if not force_posix and sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    if not force_posix and sys.platform == "win32":
        base = os.environ.get("APPDATA" if roaming else "LOCALAPPDATA")
        if not base:
            base = os.path.join(home, "AppData", "Roaming" if roaming else "Local")
        return os.path.join(base, app_name)
    folder = re.sub(r"\s+", "-", app_name.lower())
    if force_posix:
        return os.path.join(home, "." + folder)
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(base, folder)
