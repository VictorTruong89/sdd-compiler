"""Exceptions raised by Optlyn, and how each one is reported in standalone mode."""

from __future__ import annotations


class OptlynError(Exception):
    """Base class for errors Optlyn reports to the user (general error, exit 1)."""

    exit_code = 1

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.message = message
        self.ctx = ctx

    def format_message(self):
        return self.message

    def show(self, file=None):
        # spec: N-000714, N-000715
        from .termui import echo

        echo(f"Error: {self.format_message()}", file=file, err=True)


class UsageError(OptlynError):
    """Incorrect command-line usage (exit 2)."""

    exit_code = 2

    def show(self, file=None):
        # spec: N-000707, N-000708
        from .termui import echo

        ctx = self.ctx
        if ctx is not None:
            echo(ctx.get_usage(), file=file, err=True)
            hint = ctx.help_option_names[0] if ctx.help_option_names else None
            if hint:
                echo(f"Try '{ctx.command_path} {hint}' for help.", file=file, err=True)
            echo("", file=file, err=True)
        echo(f"Error: {self.format_message()}", file=file, err=True)


class BadParameter(UsageError):
    """A value that cannot be converted, or that a parameter callback refused."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        if hint:
            return f"Invalid value for {hint}: {self.message}"
        return f"Invalid value: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter received no value from any source."""

    def format_message(self):
        # spec: N-000707 (usage error that identifies the missing parameter)
        if self.param is None:
            return self.message
        kind = "argument" if self.param.param_type_name == "argument" else "option"
        return f"Missing {kind} {self.param.get_error_hint(self.ctx)}."


class NoSuchOption(UsageError):
    """An option token that the command does not declare."""

    def __init__(self, option_name, message=None, ctx=None):
        if message is None:
            message = f"No such option: {option_name}"
        super().__init__(message, ctx)
        self.option_name = option_name


class BadOptionUsage(UsageError):
    """An option used incorrectly, such as one missing its value."""


class BadArgumentUsage(UsageError):
    """A positional argument used incorrectly."""


class NoArgsIsHelpError(UsageError):
    """A group or command was run with no arguments and shows help as a usage failure."""

    def show(self, file=None):
        # spec: N-000157, N-000160 — help goes to standard error, status is the usage class
        from .termui import echo

        if self.ctx is not None:
            echo(self.ctx.get_help(), file=file, err=True)
        echo(f"Error: {self.format_message()}", file=file, err=True)


class FileError(OptlynError):
    """A file that could not be opened at first I/O (general error, exit 1)."""

    def __init__(self, filename, message, ctx=None):
        super().__init__(f"Could not open file '{filename}': {message}", ctx)
        self.filename = filename


class Abort(RuntimeError):
    """The user or the author aborted the invocation (exit 1)."""


class Exit(RuntimeError):
    """An author clean stop, or a successful intentional help/version exit."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code
