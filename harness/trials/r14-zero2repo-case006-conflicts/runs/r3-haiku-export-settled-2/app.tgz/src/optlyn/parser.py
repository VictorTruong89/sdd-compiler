"""Token-level parsing: matches option tokens and distributes positional tokens."""

from __future__ import annotations

from .exceptions import BadArgumentUsage, BadOptionUsage, NoSuchOption

# Marker for an option that was given with no value (only a prompt or flag value can fill it).
NO_VALUE = object()


def split_opt(opt):
    """Split an option name into its prefix and the remaining name."""
    first = opt[:1]
    if first.isalnum():
        return "", opt
    if opt[1:2] == first:
        return opt[:2], opt[2:]
    return first, opt[1:]


class _ParseState:
    def __init__(self, rargs):
        self.rargs = rargs
        self.largs = []
        self.opts = {}
        self.order = []


class OptionParser:
    """Matches tokens against the options and arguments a command declares."""

    def __init__(self, ctx):
        self.ctx = ctx
        self.allow_interspersed_args = ctx.allow_interspersed_args
        self.ignore_unknown_options = ctx.ignore_unknown_options
        self._long = {}
        self._short = {}
        self._prefixes = set()
        self._arguments = []

    def _normalize(self, text):
        func = self.ctx.token_normalize_func
        return func(text) if func is not None else text

    def add_option(self, option):
        names = [(name, False) for name in option.opts] + [(name, True) for name in option.secondary_opts]
        for name, secondary in names:
            prefix, value = split_opt(name)
            self._prefixes.add(prefix)
            self._prefixes.add(prefix[:1])
            key = self._normalize(name)
            if len(prefix) == 1 and len(value) == 1:
                self._short[key] = (option, secondary)
            else:
                self._long[key] = (option, secondary)

    def add_argument(self, argument):
        self._arguments.append(argument)

    # -- entry point -------------------------------------------------------

    def parse(self, args):
        state = _ParseState(list(args))
        self._process_options(state)
        self._process_arguments(state)
        return state

    def _process_options(self, state):
        while state.rargs:
            arg = state.rargs.pop(0)
            if arg == "--":
                return
            if arg[:1] in self._prefixes and len(arg) > 1:
                self._process_opt(arg, state)
            elif self.allow_interspersed_args:
                state.largs.append(arg)
            else:
                state.rargs.insert(0, arg)
                return

    def _process_opt(self, arg, state):
        explicit = None
        long_opt = arg
        if "=" in arg:
            long_opt, explicit = arg.split("=", 1)
        try:
            self._match_long(long_opt, explicit, state)
        except NoSuchOption:
            if arg[:2] not in self._prefixes:
                self._match_short(arg, state)
                return
            if not self.ignore_unknown_options:
                raise
            state.largs.append(arg)

    def _match_long(self, long_opt, explicit, state):
        key = self._normalize(long_opt)
        if key not in self._long:
            raise NoSuchOption(long_opt)
        param, secondary = self._long[key]
        if param.takes_value:
            if explicit is not None:
                if param.nargs == 1:
                    value = explicit
                else:
                    value = tuple([explicit] + self._pop_values(param, state, long_opt, param.nargs - 1))
            else:
                value = self._pop_value(param, state, long_opt)
        elif explicit is not None:
            raise BadOptionUsage(f"Option '{long_opt}' does not take a value.")
        else:
            value = self._flag_value(param, secondary)
        self._store(state, param, value)

    def _match_short(self, arg, state):
        prefix = arg[0]
        unknown = []
        index = 1
        while index < len(arg):
            char = arg[index]
            name = prefix + char
            key = self._normalize(name)
            if key not in self._short:
                if self.ignore_unknown_options:
                    unknown.append(char)
                    index += 1
                    continue
                raise NoSuchOption(name)
            param, secondary = self._short[key]
            if param.takes_value:
                rest = arg[index + 1:]
                if rest:
                    if param.nargs == 1:
                        value = rest
                    else:
                        value = tuple([rest] + self._pop_values(param, state, name, param.nargs - 1))
                else:
                    value = self._pop_value(param, state, name)
                self._store(state, param, value)
                break
            self._store(state, param, self._flag_value(param, secondary))
            index += 1
        if unknown:
            state.largs.append(prefix + "".join(unknown))

    # -- value helpers -----------------------------------------------------

    def _looks_like_option(self, token):
        return token == "--" or (token[:1] in self._prefixes and len(token) > 1)

    def _pop_values(self, param, state, name, count):
        if len(state.rargs) < count:
            raise BadOptionUsage(f"Option '{name}' requires {param.nargs} arguments.")
        values = state.rargs[:count]
        del state.rargs[:count]
        return values

    def _pop_value(self, param, state, name):
        if param.optional_value:
            if state.rargs and not self._looks_like_option(state.rargs[0]):
                return state.rargs.pop(0)
            return NO_VALUE
        if not state.rargs:
            if param.nargs == 1:
                raise BadOptionUsage(f"Option '{name}' requires an argument.")
            raise BadOptionUsage(f"Option '{name}' requires {param.nargs} arguments.")
        if param.nargs == 1:
            return state.rargs.pop(0)
        values = self._pop_values(param, state, name, param.nargs)
        return tuple(values)

    @staticmethod
    def _flag_value(param, secondary):
        if param.count:
            return 1
        if secondary:
            return param.secondary_flag_value
        return param.flag_value

    @staticmethod
    def _store(state, param, value):
        state.opts.setdefault(param, []).append(value)
        if param not in state.order:
            state.order.append(param)

    # -- positional arguments ----------------------------------------------

    def _process_arguments(self, state):
        tokens = state.largs + state.rargs
        specs = [arg.nargs for arg in self._arguments]
        chunks, leftover = _unpack_args(tokens, specs)
        for argument, chunk in zip(self._arguments, chunks):
            if chunk is None:
                continue
            if argument.nargs not in (1, -1) and len(chunk) < argument.nargs:
                raise BadArgumentUsage(
                    f"Argument '{argument.name}' takes {argument.nargs} values."
                )
            value = chunk[0] if argument.nargs == 1 else tuple(chunk)
            self._store(state, argument, value)
        state.largs = leftover
        state.rargs = []


def _unpack_args(tokens, specs):
    """Assign tokens to argument arities in order. Returns (chunks, leftover)."""
    tokens = list(tokens)
    position = 0
    chunks = []
    for index, count in enumerate(specs):
        if count == -1:
            later = sum(size for size in specs[index + 1:] if size > 0)
            take = max(len(tokens) - position - later, 0)
            chunk = tokens[position:position + take]
        else:
            chunk = tokens[position:position + count]
        position += len(chunk)
        chunks.append(chunk if chunk else None)
    return chunks, tokens[position:]
