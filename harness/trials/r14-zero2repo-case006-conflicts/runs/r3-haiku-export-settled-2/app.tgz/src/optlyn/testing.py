"""In-process runner for testing commands: ``optlyn.testing.CliRunner``."""

from __future__ import annotations

import contextlib
import io
import os
import sys
import tempfile

from .exceptions import Exit


class _Output(io.TextIOBase):
    """Captured text stream that also records into the combined output buffer."""

    def __init__(self, combined, charset, name):
        super().__init__()
        self._combined = combined
        self._own = io.BytesIO()
        self._charset = charset
        self._name = name
        self.buffer = _BytesOutput(self)

    @property
    def encoding(self):
        return self._charset

    @property
    def errors(self):
        return "strict"

    def writable(self):
        return True

    def isatty(self):
        return False

    def fileno(self):
        raise io.UnsupportedOperation("fileno")

    def write(self, text):
        data = text.encode(self._charset)
        self._own.write(data)
        self._combined.write(data)
        return len(text)

    def flush(self):
        return None

    def getvalue_bytes(self):
        return self._own.getvalue()


class _BytesOutput(io.RawIOBase):
    def __init__(self, text_stream):
        super().__init__()
        self._text = text_stream

    def writable(self):
        return True

    def write(self, data):
        data = bytes(data)
        self._text._own.write(data)
        self._text._combined.write(data)
        return len(data)

    def flush(self):
        return None


class _Input(io.TextIOBase):
    """Captured standard input. Supports Optlyn's prompt and getchar hooks."""

    def __init__(self, data, charset, echo_stdin, echo_sink):
        super().__init__()
        self._data = data
        self._pos = 0
        self._charset = charset
        self._echo_stdin = echo_stdin
        self._echo_sink = echo_sink

    @property
    def encoding(self):
        return self._charset

    def readable(self):
        return True

    def isatty(self):
        return False

    def fileno(self):
        raise io.UnsupportedOperation("fileno")

    def _take(self, size):
        chunk = self._data[self._pos:self._pos + size]
        self._pos += len(chunk)
        return chunk

    def _read_raw(self):
        end = self._data.find("\n", self._pos)
        end = len(self._data) if end == -1 else end + 1
        line = self._data[self._pos:end]
        self._pos = end
        return line

    def readline(self, size=-1):
        line = self._read_raw()
        if line and self._echo_stdin:
            self._echo_sink(line)
        return line

    def read(self, size=-1):
        if size is None or size < 0:
            chunk = self._data[self._pos:]
            self._pos = len(self._data)
        else:
            chunk = self._take(size)
        if chunk and self._echo_stdin:
            self._echo_sink(chunk)
        return chunk

    def _optlyn_read_line(self, echo):
        """Read a line for a prompt. Visible prompts echo the typed line; hidden ones do not."""
        if self._pos >= len(self._data):
            return None
        line = self._read_raw()
        text = line[:-1] if line.endswith("\n") else line
        if echo:
            self._echo_sink(text + "\n")
        return text

    def _optlyn_getchar(self):
        chunk = self._take(1)
        if not chunk:
            raise EOFError()
        return chunk


class Result:
    """The outcome of :meth:`CliRunner.invoke`."""

    # spec: N-001007 .. N-001011

    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, exit_code, exception,
                 exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self):
        return self.output_bytes.decode(self.runner.charset, "replace")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    def __repr__(self):
        return f"<Result exit_code={self.exit_code!r}>"


class CliRunner:
    """Invokes a command in-process with captured streams and an optional environment."""

    # spec: N-001006 .. N-001012

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        """Swap the process streams for capture streams, and set the environment."""
        combined = io.BytesIO()
        stdout_holder = {}

        data = ""
        if input is not None:
            data = input.decode(self.charset) if isinstance(input, bytes) else str(input)

        def echo_sink(text):
            stdout_holder["stdout"].write(text)

        stdin = _Input(data, self.charset, self.echo_stdin, echo_sink)
        stdout = _Output(combined, self.charset, "stdout")
        stderr = _Output(combined, self.charset, "stderr")
        stdout_holder["stdout"] = stdout

        merged_env = dict(self.env)
        merged_env.update(env or {})
        saved_env = {}
        for key, value in merged_env.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)

        old_streams = (sys.stdin, sys.stdout, sys.stderr)
        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
        try:
            yield stdout, stderr, combined
        finally:
            sys.stdin, sys.stdout, sys.stderr = old_streams
            for key, value in saved_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    @contextlib.contextmanager
    def _fd_isolation(self, input=None, env=None):
        """Capture at the descriptor level (fds 1 and 2), keeping interpreter streams too."""
        out_file = tempfile.TemporaryFile()
        err_file = tempfile.TemporaryFile()
        sys.stdout.flush()
        sys.stderr.flush()
        saved_out = os.dup(1)
        saved_err = os.dup(2)
        os.dup2(out_file.fileno(), 1)
        os.dup2(err_file.fileno(), 2)
        with self.isolation(input=input, env=env) as (stdout, stderr, combined):
            real_stdout = io.TextIOWrapper(os.fdopen(os.dup(1), "wb"), encoding=self.charset,
                                           write_through=True)
            real_stderr = io.TextIOWrapper(os.fdopen(os.dup(2), "wb"), encoding=self.charset,
                                           write_through=True)
            sys.stdout, sys.stderr = real_stdout, real_stderr
            try:
                yield real_stdout, real_stderr, combined
            finally:
                real_stdout.flush()
                real_stderr.flush()
                real_stdout.close()
                real_stderr.close()
                os.dup2(saved_out, 1)
                os.dup2(saved_err, 2)
                os.close(saved_out)
                os.close(saved_err)
        out_file.seek(0)
        err_file.seek(0)
        self._fd_stdout = out_file.read()
        self._fd_stderr = err_file.read()
        out_file.close()
        err_file.close()

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False,
               **extra):
        """Run ``cli`` with ``args`` and return a :class:`Result`."""
        # spec: N-001006 .. N-001011
        exc_catch = self.catch_exceptions if catch_exceptions is None else catch_exceptions
        if args is None:
            args = []
        elif isinstance(args, str):
            args = args.split()
        extra.setdefault("color", color)
        extra.setdefault("prog_name", cli.name or "root")
        standalone = extra.pop("standalone_mode", True)
        prog_name = extra.pop("prog_name")

        exit_code = 0
        exception = None
        exc_info = None
        self._fd_stdout = self._fd_stderr = None
        if self.capture == "fd":
            manager = self._fd_isolation(input=input, env=env)
        else:
            manager = self.isolation(input=input, env=env)
        with manager as (stdout, stderr, combined):
            try:
                cli.main(args=args, prog_name=prog_name, standalone_mode=standalone, **extra)
            except SystemExit as e:
                exit_code = e.code if isinstance(e.code, int) else (0 if e.code is None else 1)
                if exit_code != 0:
                    exception = e
                exc_info = sys.exc_info()
            except Exit as e:
                exit_code = e.exit_code
            except Exception as e:
                if not exc_catch:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
        if self.capture == "fd":
            stdout_bytes = self._fd_stdout or b""
            stderr_bytes = self._fd_stderr or b""
            output_bytes = stdout_bytes + stderr_bytes
        else:
            stdout_bytes = stdout.getvalue_bytes()
            stderr_bytes = stderr.getvalue_bytes()
            output_bytes = combined.getvalue()
        return Result(self, stdout_bytes, stderr_bytes, output_bytes, exit_code, exception, exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Run inside a new empty directory, which is always left in place afterwards."""
        # spec: N-001012, N-000731, N-000732, N-000733, N-001014
        previous = os.getcwd()
        path = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(previous)
