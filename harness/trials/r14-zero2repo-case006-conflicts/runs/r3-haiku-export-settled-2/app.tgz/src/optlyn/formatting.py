"""Text wrapping and the two-column layout used by help pages."""

from __future__ import annotations

import re
import shutil
import textwrap

# spec: N-001013 — wrapped text caps auto-detected width at 100 columns by default.
DEFAULT_WRAP_CAP = 100
# spec: N-000126 — help pages cap auto-detected width at 80 columns by default (FP-02).
DEFAULT_HELP_CAP = 80


def detect_width(cap):
    """Auto-detect the terminal width, capped at ``cap``."""
    columns = shutil.get_terminal_size(fallback=(80, 24)).columns
    return min(columns, cap)


def wrap_text(text, width=None, initial_indent="", subsequent_indent="", preserve_paragraphs=False):
    """Rewrap ``text`` to ``width`` columns. Accepts any string."""
    # spec: N-000669, N-000126, N-000127, N-000128, N-000130, N-000131, N-000972

    if width is None:
        width = detect_width(DEFAULT_WRAP_CAP)
    width = max(width, len(initial_indent) + 1, len(subsequent_indent) + 1)
    text = str(text).expandtabs()
    if not text.strip():
        return ""

    out = []
    for block in re.split(r"\n\s*\n", text.strip("\n")):
        lines = block.split("\n")
        if lines and lines[0].strip() == "\b":
            # spec: N-000129, N-000130 — a backspace-only first line keeps its line breaks.
            out.extend(line.rstrip() for line in lines[1:])
            out.append("")
            continue
        joined = " ".join(line.strip() for line in lines if line.strip())
        if not joined:
            continue
        out.append(
            textwrap.fill(
                joined,
                width=width,
                initial_indent=subsequent_indent if out else initial_indent,
                subsequent_indent=subsequent_indent,
                break_long_words=False,
                break_on_hyphens=False,
            )
        )
        out.append("")
    while out and out[-1] == "":
        out.pop()
    return "\n".join(out)


def ellipsize(text, max_length):
    """Shorten ``text`` to ``max_length`` characters, ending with an ellipsis."""
    if len(text) <= max_length:
        return text
    if max_length <= 3:
        return text[:max_length]
    return text[: max_length - 3].rstrip() + "..."


def make_default_short_help(text, max_length):
    """The first sentence of ``text``, ellipsized to ``max_length``."""
    # spec: N-000115, N-000116, N-000117
    flat = " ".join(str(text).split())
    match = re.match(r"(.*?[.!?])(?:\s|$)", flat)
    sentence = match.group(1) if match else flat
    return ellipsize(sentence, max_length)


class HelpFormatter:
    """Accumulates the lines of a help page at a fixed width."""

    def __init__(self, width=DEFAULT_HELP_CAP):
        self.width = width
        self.lines = []

    def write(self, text=""):
        self.lines.append(text)

    def write_paragraph(self, text):
        if self.lines and self.lines[-1] != "":
            self.lines.append("")
        self.lines.append(wrap_text(text, self.width))

    def write_usage(self, prefix, pieces):
        line = " ".join([prefix] + [p for p in pieces if p])
        indent = " " * (len(prefix) + 1)
        self.lines.append(
            wrap_text(line, self.width, subsequent_indent=indent)
            if len(line) > self.width
            else line
        )

    def write_heading(self, name):
        self.lines.append("")
        self.lines.append(f"{name}:")

    def write_dl(self, rows, col_max=30, col_spacing=2, indent=2):
        """Write ``(first, second)`` rows as an aligned two-column list."""
        # spec: N-000822, N-000823, N-000824
        if not rows:
            return
        first_width = min(max(len(first) for first, _ in rows), col_max)
        for first, second in rows:
            prefix = " " * indent
            body_indent = prefix + " " * (first_width + col_spacing)
            if len(first) > first_width or not second:
                # Long first column: the description goes on the following lines.
                self.lines.append(prefix + first)
                if second:
                    wrapped = wrap_text(second, max(self.width - len(body_indent), 10))
                    self.lines.extend(body_indent + line for line in wrapped.split("\n"))
                continue
            available = max(self.width - len(body_indent), 10)
            wrapped = wrap_text(second, available)
            body_lines = wrapped.split("\n") if wrapped else [""]
            self.lines.append(prefix + first.ljust(first_width) + " " * col_spacing + body_lines[0])
            for extra in body_lines[1:]:
                self.lines.append(body_indent + extra)

    def getvalue(self):
        return "\n".join(self.lines).rstrip("\n")
