"""Parameters, invocation context, commands and groups."""

from __future__ import annotations

import contextlib
import enum
import os
import sys

from .exceptions import (
    Abort,
    BadOptionUsage,
    BadParameter,
    Exit,
    MissingParameter,
    NoArgsIsHelpError,
    OptlynError,
    UsageError,
)
from .formatting import DEFAULT_HELP_CAP, HelpFormatter, detect_width, make_default_short_help
from .paramtypes import BOOL, INT, BoolParamType, Tuple, convert_type
from .parser import NO_VALUE, OptionParser
from .termui import _prompt_raw, confirm, echo
from .utils import pop_context, push_context


class ParameterSource(enum.Enum):
    """Where the value of a parameter came from."""

    # spec: N-000453, N-000454, N-000455, N-000456
    PROMPT = "prompt"
    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"


# Most explicit first (prompt, command line, environment, default map, declared default).
_SOURCE_RANK = {
    ParameterSource.PROMPT: 0,
    ParameterSource.COMMANDLINE: 1,
    ParameterSource.ENVIRONMENT: 2,
    ParameterSource.DEFAULT_MAP: 3,
    ParameterSource.DEFAULT: 4,
}

_TRUE_WORDS = {"true", "1", "yes", "on", "t", "y"}
_FALSE_WORDS = {"false", "0", "no", "off", "f", "n"}


def _split_decls(decls, prefixes_allowed=True):
    """Split declarations into (destination, flag names, secondary flag names)."""
    dest = None
    opts = []
    secondary = []
    for decl in decls:
        if not decl:
            continue
        if decl.isidentifier():
            if dest is not None:
                raise TypeError(f"Multiple destination names: {dest!r} and {decl!r}.")
            dest = decl
            continue
        if decl[:1].isalnum() or decl[:1] == "_":
            raise TypeError(f"Invalid parameter declaration {decl!r}.")
        # spec: N-000868 — `<on-flag>/<off-flag>` declares an on/off pair.
        parts = decl.split("/")
        if len(parts) == 2 and parts[0] and parts[1]:
            opts.append(parts[0])
            secondary.append(parts[1])
        else:
            opts.append(decl)
    if dest is None and opts:
        candidates = [o for o in opts if len(_strip_prefix(o)) > 1]
        chosen = (candidates or opts)[0]
        dest = _strip_prefix(chosen).replace("-", "_")
    return dest, opts, secondary


def _strip_prefix(name):
    value = name
    while value and not value[0].isalnum() and value[0] != "_":
        value = value[1:]
    return value


class Parameter:
    """Common machinery for options and arguments."""

    param_type_name = "parameter"

    def __init__(self, name, opts=(), secondary_opts=(), type=None, required=False, default=None,
                 callback=None, nargs=None, multiple=False, metavar=None, expose_value=True,
                 is_eager=False, envvar=None, shell_complete=None, deprecated=False,
                 hidden=False, help=None):
        self.name = name
        self.opts = list(opts)
        self.secondary_opts = list(secondary_opts)
        if nargs is None:
            nargs = len(type.types) if isinstance(type, Tuple) else 1
        self.type = convert_type(type, default)
        if isinstance(self.type, Tuple) and nargs != len(self.type.types):
            nargs = len(self.type.types)
        self.nargs = nargs
        self.required = bool(required)
        self._declared_default = default
        self.default = default
        self.callback = callback
        self.multiple = bool(multiple)
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        if isinstance(envvar, str):
            envvar = [envvar]
        self.envvar = list(envvar) if envvar else None
        self.shell_complete = shell_complete
        self.deprecated = deprecated
        self.hidden = hidden
        self.help = help
        self.decl_index = 0

    # -- defaults and missing values -----------------------------------------

    def get_default(self, ctx):
        value = self.default
        if callable(value):
            value = value()
        return value

    def value_is_missing(self, value):
        if value is None:
            return True
        if (self.multiple or self.nargs == -1) and value == ():
            return True
        return False

    def get_error_hint(self, ctx):
        raise NotImplementedError

    def process_value(self, ctx, value):
        if self.required and self.value_is_missing(value):
            raise MissingParameter("", ctx=ctx, param=self)
        if self.callback is not None:
            value = self.callback(ctx, self, value)
        return value

    # -- conversion ----------------------------------------------------------

    def _occ_convert(self, ctx, raw):
        """Convert one occurrence (a token, or a tuple of tokens for multi-value)."""
        try:
            if isinstance(self.type, Tuple):
                return self.type.convert(raw, self, ctx)
            if self.nargs != 1:
                if self.nargs > 0 and len(raw) != self.nargs:
                    raise BadParameter(f"Expected {self.nargs} values.", ctx=ctx, param=self)
                return tuple(self.type.convert(item, self, ctx) for item in raw)
            return self.type.convert(raw, self, ctx)
        except BadParameter as e:
            if e.param is None:
                e.param = self
            if e.ctx is None:
                e.ctx = ctx
            raise

    def _collapse(self, ctx, occurrences):
        if self.multiple:
            return tuple(self._occ_convert(ctx, occ) for occ in occurrences)
        return self._occ_convert(ctx, occurrences[-1])

    def _split_env(self, raw):
        """Turn an environment string into occurrences."""
        if self.nargs != 1 or isinstance(self.type, Tuple):
            parts = self.type.split_envvar_value(raw)
            if self.multiple and self.nargs > 0 and not isinstance(self.type, Tuple):
                size = self.nargs
                return [tuple(parts[i:i + size]) for i in range(0, len(parts), size)]
            return [tuple(parts)]
        if self.multiple:
            return self.type.split_envvar_value(raw)
        return [raw]

    def _from_default(self, ctx, raw):
        if self.multiple:
            if raw is None:
                return ()
            if isinstance(raw, str) or not isinstance(raw, (list, tuple)):
                raise BadOptionUsage(
                    f"The default for {self.get_error_hint(ctx)} needs an iterable (sequence) default."
                    " Pass a one-element sequence for a single default.",
                    ctx=ctx,
                )
            return tuple(self._occ_convert(ctx, self._as_occurrence(item)) for item in raw)
        if self.nargs == -1:
            if raw is None:
                return ()
            if isinstance(raw, str):
                raw = self.type.split_envvar_value(raw)
            return tuple(self.type.convert(item, self, ctx) for item in raw)
        if raw is None:
            return None
        if self.nargs != 1 or isinstance(self.type, Tuple):
            if isinstance(raw, str):
                raw = tuple(self.type.split_envvar_value(raw))
            return self._occ_convert(ctx, tuple(raw) if not isinstance(raw, tuple) else raw)
        return self._occ_convert(ctx, raw)

    def _as_occurrence(self, item):
        if self.nargs != 1 and not isinstance(self.type, Tuple) and isinstance(item, (list, tuple)):
            return tuple(item)
        return item

    # -- value resolution ----------------------------------------------------

    def _env_value_names(self, ctx):
        return list(self.envvar or [])

    def value_from_envvar(self, ctx):
        """Return (found, occurrences) from the environment, or (False, None)."""
        # spec: N-000214, N-000215, N-000216, N-000217, N-000218, N-000219, N-000220
        for name in self._env_value_names(ctx):
            raw = os.environ.get(name)
            if raw:
                return True, self._split_env(raw)
        return False, None

    def _default_map_value(self, ctx):
        """Return (found, value) from the invocation context's default map."""
        mapping = ctx.default_map
        if isinstance(mapping, dict) and self.name in mapping and mapping[self.name] is not None:
            return True, mapping[self.name]
        return False, None

    def _prompt_text(self):
        if isinstance(self.prompt, str):
            return self.prompt
        return self.name.replace("_", " ").capitalize()

    def _prompt_for_value(self, ctx, has_default, raw_default, source, auto):
        # spec: N-000478, N-000479, N-000480, N-000487, N-000489, N-000510, N-000511, N-000512
        if ctx is not None and ctx.resilient_parsing:
            return (self._from_default(ctx, raw_default) if has_default else None), source, auto
        text = self._prompt_text()
        if getattr(self, "is_bool_flag", False):
            answer = confirm(text, default=bool(raw_default) if has_default else False)
            return answer, ParameterSource.PROMPT, False
        display = None
        if has_default and getattr(self, "show_default", True) is not False:
            display = str(raw_default)
        while True:
            line = _prompt_raw(text, display, self.hide_input, self.confirmation_prompt)
            if line == "":
                if has_default:
                    return self._from_default(ctx, raw_default), source, auto
                continue
            try:
                value = self._collapse(ctx, self._split_prompt(line))
                return value, ParameterSource.PROMPT, False
            except BadParameter as e:
                echo(f"Error: {e.format_message()}", err=True)

    def _split_prompt(self, line):
        if self.nargs != 1 or isinstance(self.type, Tuple):
            parts = tuple(line.split())
            return [parts]
        return [line]

    def consume_value(self, ctx, opts):
        """Resolve the value from command line, environment, default map, default or prompt."""
        occurrences = opts.get(self)
        if occurrences and occurrences[-1] is not NO_VALUE:
            self._maybe_warn_deprecated(ctx)
            return self._from_occurrences(ctx, occurrences), ParameterSource.COMMANDLINE, False
        if occurrences:
            # The option was given with no value.
            self._maybe_warn_deprecated(ctx)
            if self.optional_value:
                return self.flag_value, ParameterSource.COMMANDLINE, False
            if self.prompt is not None:
                has_default, raw = self._resolve_raw_default(ctx)[:2]
                return self._prompt_for_value(ctx, has_default, raw, ParameterSource.DEFAULT, False)
            raise BadOptionUsage(f"Option '{self.get_error_hint(ctx)}' requires an argument.", ctx=ctx)

        # spec: N-000230 (as ruled by CF-000150) — command line, default map, environment, declared default.
        found, mapped = self._default_map_value(ctx)
        if found:
            if self._prompting(ctx):
                return self._prompt_for_value(ctx, True, mapped, ParameterSource.DEFAULT_MAP, False)
            return self._from_default(ctx, mapped), ParameterSource.DEFAULT_MAP, False

        found, env_occurrences = self.value_from_envvar(ctx)
        if found:
            return self._collapse(ctx, env_occurrences), ParameterSource.ENVIRONMENT, False

        has_default, raw, source, auto = self._resolve_raw_default(ctx)
        if self._prompting(ctx):
            return self._prompt_for_value(ctx, has_default, raw, source, auto)
        return self._from_default(ctx, raw), source, auto

    def _prompting(self, ctx):
        return self.prompt is not None and (self.prompt_required or self.required)

    def _resolve_raw_default(self, ctx):
        raw = self.get_default(ctx)
        auto = getattr(self, "_default_is_auto", False)
        return raw is not None, raw, ParameterSource.DEFAULT, auto

    def _from_occurrences(self, ctx, occurrences):
        return self._collapse(ctx, occurrences)

    def _maybe_warn_deprecated(self, ctx):
        pass

    def handle_parse_result(self, ctx, opts):
        value, source, auto = self.consume_value(ctx, opts)
        value = self.process_value(ctx, value)
        if self.expose_value:
            ctx._record_param(self, value, source, auto)
        return value

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"


class Option(Parameter):
    """A named parameter introduced by one or more flag names."""

    param_type_name = "option"

    def __init__(self, param_decls=None, show_default=None, prompt=False, confirmation_prompt=False,
                 prompt_required=True, hide_input=False, is_flag=None, flag_value=None, count=False,
                 multiple=False, allow_from_autoenv=True, help=None, hidden=False, show_choices=True,
                 show_envvar=False, shell_complete=None, deprecated=False, **attrs):
        dest, opts, secondary = _split_decls(list(param_decls or []))
        if dest is None:
            raise TypeError("An option needs at least one flag name or a destination name.")
        if not opts:
            raise TypeError("An option needs at least one flag name.")
        if is_flag is None:
            if flag_value is not None:
                is_flag = True
            elif count:
                is_flag = False
            else:
                is_flag = bool(secondary)
        if count:
            is_flag = False
            if attrs.get("default") is None:
                attrs["default"] = 0
            attrs.setdefault("type", INT)
        declared_default = attrs.get("default")
        if is_flag:
            if attrs.get("default") is None:
                attrs["default"] = False
            default_bool = bool(attrs["default"])
            if flag_value is None:
                flag_value = True if secondary else (not default_bool)
            if attrs.get("type") is None:
                attrs["type"] = BOOL if isinstance(flag_value, bool) else convert_type(None, flag_value)
        if attrs.get("required") and deprecated:
            raise TypeError("A deprecated option cannot also be required.")
        if prompt and deprecated:
            raise TypeError("A deprecated option cannot use a prompt.")
        if attrs.get("nargs") is not None and attrs["nargs"] < 1:
            raise TypeError("An option takes a positive number of values.")
        if multiple and is_flag:
            raise TypeError("A flag cannot be repeatable.")
        super().__init__(
            dest, opts=opts, secondary_opts=secondary, multiple=multiple, deprecated=deprecated,
            hidden=hidden, help=help, shell_complete=shell_complete, **attrs,
        )
        self.is_flag = bool(is_flag)
        self.count = bool(count)
        self.flag_value = flag_value
        self.secondary_flag_value = (not flag_value) if isinstance(flag_value, bool) else False
        if secondary and self.is_flag:
            self.secondary_flag_value = False
        self.optional_value = (not self.is_flag) and flag_value is not None and not self.count
        self.is_bool_flag = self.is_flag and isinstance(self.type, BoolParamType)
        self._default_is_auto = self.is_flag and declared_default is None
        self.prompt = _prompt_text_option(prompt)
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.show_default = show_default
        self.show_choices = show_choices
        self.show_envvar = show_envvar
        self.allow_from_autoenv = allow_from_autoenv

    @property
    def takes_value(self):
        return not self.is_flag and not self.count

    def get_default(self, ctx):
        # spec: N-000233 — a truthy default on a non-boolean flag selects that flag's value.
        if self.is_flag and not self.is_bool_flag and self.default and not callable(self.default):
            return self.flag_value
        return super().get_default(ctx)

    def get_error_hint(self, ctx):
        return " / ".join(f"'{o}'" for o in self.opts + self.secondary_opts)

    def _env_value_names(self, ctx):
        names = list(self.envvar or [])
        if not names and self.allow_from_autoenv and ctx is not None and ctx.auto_envvar_prefix:
            names.append(ctx.auto_envvar_name(self.name))
        return names

    def value_from_envvar(self, ctx):
        if self.is_flag:
            return self._flag_from_envvar(ctx)
        return super().value_from_envvar(ctx)

    def _flag_from_envvar(self, ctx):
        # spec: N-000221 .. N-000229
        for name in self._env_value_names(ctx):
            raw = os.environ.get(name)
            if not raw:
                continue
            text = raw.strip().lower()
            if self.is_bool_flag:
                if text in _TRUE_WORDS:
                    return True, [True]
                if text == "" or text in _FALSE_WORDS:
                    return True, [False]
                raise BadParameter(f"{raw!r} is not a valid boolean.", ctx=ctx, param=self)
            if raw == self.flag_value or str(self.flag_value) == raw:
                return True, [self.flag_value]
            if text in _TRUE_WORDS:
                return True, [self.flag_value]
            if text in _FALSE_WORDS:
                return True, [False]
        return False, None

    def consume_value(self, ctx, opts):
        if self.count and self not in opts:
            found, mapped = self._default_map_value(ctx)
            if found:
                return mapped, ParameterSource.DEFAULT_MAP, False
            has_default, raw, source, auto = self._resolve_raw_default(ctx)
            return (raw if raw is not None else 0), source, auto
        if self.count:
            self._maybe_warn_deprecated(ctx)
            return sum(opts[self]), ParameterSource.COMMANDLINE, False
        if self.is_flag:
            return self._consume_flag(ctx, opts)
        return super().consume_value(ctx, opts)

    def _consume_flag(self, ctx, opts):
        occurrences = opts.get(self)
        if occurrences:
            self._maybe_warn_deprecated(ctx)
            return occurrences[-1], ParameterSource.COMMANDLINE, False
        found, mapped = self._default_map_value(ctx)
        if found:
            return bool(mapped) if self.is_bool_flag else mapped, ParameterSource.DEFAULT_MAP, False
        found, values = self.value_from_envvar(ctx)
        if found:
            return values[-1], ParameterSource.ENVIRONMENT, False
        has_default, raw, source, auto = self._resolve_raw_default(ctx)
        if self._prompting(ctx):
            return self._prompt_for_value(ctx, has_default, raw, source, auto)
        return raw, source, auto

    def _from_default(self, ctx, raw):
        if self.is_flag and not self.multiple:
            return raw
        if self.count:
            return raw
        return super()._from_default(ctx, raw)

    def _collapse(self, ctx, occurrences):
        if self.is_flag or self.count:
            return occurrences[-1] if not self.count else sum(occurrences)
        return super()._collapse(ctx, occurrences)

    def _maybe_warn_deprecated(self, ctx):
        # spec: N-000253, N-000254 — a deprecation warning only when the user supplied the option.
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else ""
            echo(f"DeprecationWarning: The '{self.name}' option is deprecated. {note}".rstrip(),
                 err=True)

    def get_usage_pieces(self, ctx):
        return []

    def get_help_record(self, ctx):
        """Return (first column, second column) for the help page, or None when hidden."""
        # spec: N-000822 .. N-000826, N-000132 .. N-000139
        if self.hidden:
            return None
        if self.secondary_opts:
            names_text = " / ".join(self.opts + self.secondary_opts)
        else:
            names_text = ", ".join(self.opts)
        first = names_text
        if self.takes_value:
            metavar = self.get_metavar(ctx)
            if metavar:
                first = f"{first} {metavar}"
        extras = []
        text = self.help or ""
        if self.deprecated:
            extras.append("(DEPRECATED)")
        default_text = self._help_default_text(ctx)
        if default_text is not None:
            extras.append(f"[default: {default_text}]")
        if self.show_envvar and self.envvar:
            extras.append(f"[env var: {self.envvar[0]}]")
        elif self.show_envvar and ctx is not None and ctx.auto_envvar_prefix and self.allow_from_autoenv:
            extras.append(f"[env var: {ctx.auto_envvar_name(self.name)}]")
        if extras:
            text = (text + " " if text else "") + " ".join(extras)
        return first, text

    def _help_default_text(self, ctx):
        show = self.show_default
        if show is None and ctx is not None:
            show = ctx.show_default
        if isinstance(show, str):
            return show
        if not show:
            return None
        if self.is_bool_flag and not self.default:
            return None
        if callable(self.default):
            return "(dynamic)"
        value = self.default
        if value is None:
            return None
        if isinstance(value, (list, tuple)):
            return ", ".join(str(v) for v in value)
        return str(value)

    def get_metavar(self, ctx):
        if self.metavar is not None:
            return self.metavar
        if self.is_flag or self.count:
            return None
        base = self.type.get_metavar(self) or self.type.get_default_metavar()
        if isinstance(self.type, Tuple):
            return base
        return " ".join([base] * self.nargs)

    def shell_complete_items(self, ctx, incomplete):
        if self.shell_complete is not None:
            return self.shell_complete(ctx, self, incomplete)
        return self.type.shell_complete(ctx, self, incomplete)


def _prompt_text_option(prompt):
    if prompt is False or prompt is None:
        return None
    return prompt


class Argument(Parameter):
    """A positional parameter."""

    param_type_name = "argument"

    def __init__(self, param_decls=None, required=None, **attrs):
        decls = list(param_decls or [])
        if len(decls) != 1:
            raise TypeError("An argument takes exactly one destination name.")
        name = decls[0]
        if not name.replace("-", "_").isidentifier():
            raise TypeError(f"Invalid argument name {name!r}.")
        nargs = attrs.get("nargs", 1)
        if nargs is None:
            nargs = 1
        if nargs == 0 or nargs < -1:
            raise TypeError("An argument takes a positive number of values, or -1 for variadic.")
        attrs["nargs"] = nargs
        if required is None:
            required = attrs.get("default") is None and nargs != -1
        if attrs.get("deprecated") and required:
            raise TypeError("A deprecated argument cannot be required.")
        super().__init__(name.replace("-", "_"), required=required, **attrs)
        self._default_is_auto = False

    def get_error_hint(self, ctx):
        return f"'{self.metavar or self.name.upper()}'"

    def get_metavar(self, ctx):
        if self.metavar is not None:
            return self.metavar
        return self.name.upper()

    def get_usage_pieces(self, ctx):
        metavar = self.get_metavar(ctx)
        if self.nargs == -1:
            piece = metavar + "..."
            return [piece if self.required else f"[{piece}]"]
        pieces = [metavar] * self.nargs
        if not self.required:
            return [f"[{' '.join(pieces)}]"]
        return [" ".join(pieces)]

    def get_help_record(self, ctx):
        if self.help is None or self.hidden:
            return None
        return self.get_metavar(ctx), self.help

    def _maybe_warn_deprecated(self, ctx):
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else ""
            echo(f"DeprecationWarning: The '{self.name}' argument is deprecated. {note}".rstrip(),
                 err=True)

    def consume_value(self, ctx, opts):
        occurrences = opts.get(self)
        if occurrences:
            self._maybe_warn_deprecated(ctx)
            return self._collapse(ctx, occurrences), ParameterSource.COMMANDLINE, False
        found, env_occurrences = self.value_from_envvar(ctx)
        if found:
            return self._collapse(ctx, env_occurrences), ParameterSource.ENVIRONMENT, False
        has_default, raw, source, auto = self._resolve_raw_default(ctx)
        return self._from_default(ctx, raw), source, auto

    def shell_complete_items(self, ctx, incomplete):
        if self.shell_complete is not None:
            return self.shell_complete(ctx, self, incomplete)
        return self.type.shell_complete(ctx, self, incomplete)


def iter_params_for_processing(invocation_order, declared):
    """Order parameters: eager ones first, then by invocation order, then declaration order."""
    # spec: N-000001 (eager flags: the one typed first takes effect)
    index = {param: i for i, param in enumerate(invocation_order)}
    inf = float("inf")

    def key(param):
        return (not param.is_eager, index.get(param, inf), param.decl_index)

    return sorted(declared, key=key)


class Context:
    """Per-invocation state: parsed values, parent linkage, settings and resources."""

    # spec: N-000932 .. N-000962

    def __init__(self, command, parent=None, info_name=None, obj=None, auto_envvar_prefix=None,
                 default_map=None, terminal_width=None, max_content_width=None,
                 resilient_parsing=False, allow_extra_args=None, allow_interspersed_args=None,
                 ignore_unknown_options=None, help_option_names=None, token_normalize_func=None,
                 color=None, show_default=None):
        self.parent = parent
        self.command = command
        self.info_name = info_name
        self.params = {}
        self._param_sources = {}
        self._chain_child = False
        self.args = []
        self.protected_args = []
        self.invoked_subcommand = None
        self._depth = 0
        self._exit_stack = contextlib.ExitStack()

        if obj is None and parent is not None:
            obj = parent.obj
        self.obj = obj
        if auto_envvar_prefix is None and parent is not None:
            auto_envvar_prefix = parent.auto_envvar_prefix
        self.auto_envvar_prefix = auto_envvar_prefix
        if default_map is None and parent is not None and isinstance(parent.default_map, dict):
            default_map = parent.default_map.get(info_name)
        self.default_map = default_map
        self.terminal_width = terminal_width if terminal_width is not None else (
            parent.terminal_width if parent is not None else None)
        self.max_content_width = max_content_width if max_content_width is not None else (
            parent.max_content_width if parent is not None else None)
        self.resilient_parsing = resilient_parsing
        if allow_extra_args is None:
            allow_extra_args = command.allow_extra_args
        self.allow_extra_args = allow_extra_args
        if allow_interspersed_args is None:
            allow_interspersed_args = command.allow_interspersed_args
        self.allow_interspersed_args = allow_interspersed_args
        if ignore_unknown_options is None:
            ignore_unknown_options = command.ignore_unknown_options
        self.ignore_unknown_options = ignore_unknown_options
        if help_option_names is None:
            help_option_names = parent.help_option_names if parent is not None else ["--help"]
        self.help_option_names = list(help_option_names)
        self.token_normalize_func = token_normalize_func if token_normalize_func is not None else (
            parent.token_normalize_func if parent is not None else None)
        self.color = color if color is not None else (parent.color if parent is not None else None)
        self.show_default = show_default if show_default is not None else (
            parent.show_default if parent is not None else None)

    # -- context-manager protocol ------------------------------------------

    def __enter__(self):
        self._depth += 1
        push_context(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        self._depth -= 1
        pop_context(self)
        if self._depth == 0:
            self.close()
        return None

    @contextlib.contextmanager
    def scope(self, cleanup=True):
        self._depth += 1
        push_context(self)
        try:
            yield self
        finally:
            self._depth -= 1
            pop_context(self)
            if cleanup and self._depth == 0:
                self.close()

    # -- resources ----------------------------------------------------------

    def call_on_close(self, func):
        self._exit_stack.callback(func)
        return func

    def with_resource(self, context_manager):
        return self._exit_stack.enter_context(context_manager)

    def close(self):
        stack = self._exit_stack
        self._exit_stack = contextlib.ExitStack()
        stack.close()

    # -- lookups ------------------------------------------------------------

    @property
    def command_path(self):
        rv = self.info_name or ""
        if self.parent is not None:
            parent_path = self.parent.command_path
            rv = f"{parent_path} {rv}" if parent_path else rv
        return rv

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type):
        node = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

    def lookup_default(self, name):
        if isinstance(self.default_map, dict):
            return self.default_map.get(name)
        return None

    def auto_envvar_name(self, name):
        parts = [self.auto_envvar_prefix]
        node = self
        names = []
        while node.parent is not None:
            names.insert(0, node.info_name)
            node = node.parent
        parts.extend(n for n in names if n)
        parts.append(name)
        return "_".join(str(p) for p in parts).replace("-", "_").upper()

    def get_parameter_source(self, name):
        declared = {p.name for p in self.command.params}
        if name not in declared:
            return None
        entry = self._param_sources.get(name)
        if entry is None:
            return ParameterSource.DEFAULT
        return entry[1]

    def _record_param(self, param, value, source, auto):
        # spec: N-000233, N-000234, N-000235, N-000236 — feature-switch winner selection.
        rank = (_SOURCE_RANK[source], 1 if auto else 0, -param.decl_index)
        previous = self._param_sources.get(param.name)
        if previous is None or rank < previous[0]:
            self._param_sources[param.name] = (rank, source)
            self.params[param.name] = value

    # -- output / failure ---------------------------------------------------

    def fail(self, message):
        raise UsageError(message, self)

    def abort(self):
        raise Abort()

    def exit(self, code=0):
        raise Exit(code)

    def get_usage(self):
        return self.command.get_usage(self)

    def get_help(self):
        return self.command.get_help(self)

    # -- invoking -----------------------------------------------------------

    def invoke(self, callback, *args, **kwargs):
        """Call a command (filling its declared defaults) or a plain callable."""
        # spec: N-000947, N-000948, N-000949
        if isinstance(callback, Command):
            other = callback
            ctx = Context(other, info_name=other.name, parent=self)
            for param in other.params:
                if param.name not in kwargs and param.expose_value:
                    kwargs[param.name] = param._from_default(ctx, param.get_default(ctx))
            ctx.params.update(kwargs)
            func = other.callback
            if func is None:
                return None
            with ctx:
                return func(*args, **kwargs)
        with self:
            return callback(*args, **kwargs)

    def forward(self, cmd, **kwargs):
        """Run ``cmd`` with this context's parameter values, overridden by ``kwargs``."""
        # spec: N-000463, N-000464, N-000465, N-000466
        values = dict(self.params)
        values.update(kwargs)
        return self.invoke(cmd, **values)


def _show_help(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


class Command:
    """A leaf command: parses its own options and arguments, then runs a callback."""

    allow_extra_args = False
    allow_interspersed_args = True
    ignore_unknown_options = False
    _accepts_subcommands = False

    def __init__(self, name, context_settings=None, callback=None, params=None, help=None,
                 epilog=None, short_help=None, options_metavar="[OPTIONS]", add_help_option=True,
                 no_args_is_help=False, hidden=False, deprecated=False):
        self.name = name
        self.context_settings = dict(context_settings or {})
        self.callback = callback
        self.params = list(params or [])
        self.help = help
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = deprecated
        self._check_params()

    def _check_params(self):
        arguments = [p for p in self.params if isinstance(p, Argument)]
        variadic = [a for a in arguments if a.nargs == -1]
        if len(variadic) > 1:
            raise TypeError("Only one argument may consume the rest of the tokens.")
        for index, param in enumerate(self.params):
            param.decl_index = index

    # -- parameters -----------------------------------------------------------

    def get_help_option_names(self, ctx):
        used = set()
        for param in self.params:
            used.update(param.opts)
            used.update(param.secondary_opts)
        return [name for name in ctx.help_option_names if name not in used]

    def get_help_option(self, ctx):
        if not self.add_help_option:
            return None
        names = self.get_help_option_names(ctx)
        if not names:
            return None
        return Option(
            names, is_flag=True, is_eager=True, expose_value=False,
            callback=_show_help, help="Show this message and exit.",
        )

    def get_params(self, ctx):
        params = list(self.params)
        help_option = self.get_help_option(ctx)
        if help_option is not None:
            help_option.decl_index = len(params)
            params.append(help_option)
        return params

    # -- parsing --------------------------------------------------------------

    def make_context(self, info_name, args, parent=None, **extra):
        chain_child = extra.pop("_chain_child", False)
        for key, value in self.context_settings.items():
            extra.setdefault(key, value)
        ctx = Context(self, info_name=info_name, parent=parent, **extra)
        ctx._chain_child = chain_child
        with ctx.scope(cleanup=False):
            self.parse_args(ctx, list(args))
        return ctx

    def parse_args(self, ctx, args):
        # spec: N-000094, N-000095, N-000096, N-000097, N-000098 .. N-000102
        try:
            if not args and self.no_args_is_help and not ctx.resilient_parsing:
                raise NoArgsIsHelpError(self._no_args_message(), ctx)
            params = self.get_params(ctx)
            parser = OptionParser(ctx)
            for param in params:
                if isinstance(param, Argument):
                    parser.add_argument(param)
                else:
                    parser.add_option(param)
            state = parser.parse(args)
            leftover = state.largs
            if not self._accepts_subcommands:
                self._check_leftover(ctx, leftover)
            for param in iter_params_for_processing(state.order, params):
                param.handle_parse_result(ctx, state.opts)
        except UsageError as e:
            if e.ctx is None:
                e.ctx = ctx
            raise
        ctx.args = leftover
        return leftover

    def _no_args_message(self):
        return "Missing command."

    def _check_leftover(self, ctx, leftover):
        if not leftover:
            return
        if ctx.allow_extra_args:
            if not ctx.ignore_unknown_options:
                bad = [t for t in leftover if t[:1] in ("-", "/", "+") and len(t) > 1 and t != "-"]
                if bad and not ctx._chain_child:
                    raise UsageError(f"No such option: {bad[0]}", ctx)
            return
        if ctx._chain_child:
            return
        if leftover:
            raise UsageError(f"Got unexpected extra argument{'s' if len(leftover) > 1 else ''} "
                             f"({' '.join(leftover)})", ctx)

    # -- running ----------------------------------------------------------------

    def invoke(self, ctx):
        # spec: N-000080 .. N-000084 — a deprecated command still runs, with a warning first.
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else ""
            echo(f"DeprecationWarning: The command '{ctx.info_name}' is deprecated. {note}".rstrip())
        if self.callback is None:
            return None
        return ctx.invoke(self.callback, **ctx.params)

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True, **extra):
        """Run the command as a program (or in-process when ``standalone_mode`` is false)."""
        # spec: N-000842 .. N-000849
        if args is None:
            args = sys.argv[1:]
        else:
            args = list(args)
        if prog_name is None:
            prog_name = _detect_program_name()
        if complete_var is None:
            complete_var = "_" + prog_name.upper().replace("-", "_") + "_COMPLETE"
        if self._maybe_complete(prog_name, complete_var, args, standalone_mode):
            return None
        try:
            try:
                with self.make_context(prog_name, args, **extra) as ctx:
                    rv = self.invoke(ctx)
                    if not standalone_mode:
                        return rv
                ctx.exit()
            except (EOFError, KeyboardInterrupt) as e:
                echo(file=sys.stderr)
                raise Abort() from e
            except OptlynError as e:
                if not standalone_mode:
                    raise
                e.show()
                sys.exit(e.exit_code)
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return e.exit_code
        except Abort:
            if not standalone_mode:
                raise
            echo("Aborted!", file=sys.stderr)
            sys.exit(1)
        return None

    def _maybe_complete(self, prog_name, complete_var, args, standalone_mode):
        instruction = os.environ.get(complete_var)
        if not instruction:
            return False
        from .shell_completion import run_completion

        return run_completion(self, prog_name, complete_var, instruction, standalone_mode)

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    # -- help -----------------------------------------------------------------

    def get_usage(self, ctx):
        pieces = self.collect_usage_pieces(ctx)
        return " ".join(["Usage:", ctx.command_path] + [p for p in pieces if p])

    def collect_usage_pieces(self, ctx):
        pieces = [self.options_metavar] if self.options_metavar else []
        for param in self.get_params(ctx):
            pieces.extend(param.get_usage_pieces(ctx))
        return pieces

    def get_help(self, ctx):
        formatter = HelpFormatter(width=self._help_width(ctx))
        self.format_help(ctx, formatter)
        return formatter.getvalue()

    def _help_width(self, ctx):
        # spec: N-000126, N-000127 — explicit terminal width is the wrap width as-is.
        if ctx.terminal_width is not None:
            return ctx.terminal_width
        cap = ctx.max_content_width if ctx.max_content_width is not None else DEFAULT_HELP_CAP
        return detect_width(cap)

    def format_help(self, ctx, formatter):
        formatter.write_usage(f"Usage: {ctx.command_path}", self.collect_usage_pieces(ctx))
        self.format_help_text(ctx, formatter)
        self.format_positional_args(ctx, formatter)
        self.format_options(ctx, formatter)
        self.format_extra(ctx, formatter)
        self.format_epilog(ctx, formatter)

    def format_help_text(self, ctx, formatter):
        text = self.help or ""
        if self.deprecated:
            formatter.write_paragraph("(Deprecated)")
        if text:
            formatter.write_paragraph(text)

    def format_positional_args(self, ctx, formatter):
        rows = []
        for param in self.get_params(ctx):
            if isinstance(param, Argument):
                record = param.get_help_record(ctx)
                if record is not None:
                    rows.append(record)
        if rows:
            formatter.write_heading("Positional arguments")
            formatter.write_dl(rows)

    def format_options(self, ctx, formatter):
        rows = []
        for param in self.get_params(ctx):
            if isinstance(param, Option):
                record = param.get_help_record(ctx)
                if record is not None:
                    rows.append(record)
        if rows:
            formatter.write_heading("Options")
            formatter.write_dl(rows)

    def format_extra(self, ctx, formatter):
        return None

    def format_epilog(self, ctx, formatter):
        if self.epilog:
            formatter.write_paragraph(self.epilog)

    def get_short_help_str(self, limit=45):
        if self.short_help:
            return self.short_help
        return make_default_short_help(self.help or "", limit)

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"


def _detect_program_name():
    argv0 = sys.argv[0] if sys.argv and sys.argv[0] else "root"
    base = os.path.basename(argv0)
    if base in ("__main__.py", "-c", "-m", ""):
        base = "root"
    return base


class Group(Command):
    """A command that dispatches to named subcommands."""

    allow_interspersed_args = False
    _accepts_subcommands = True

    def __init__(self, name=None, commands=None, invoke_without_command=False, no_args_is_help=None,
                 subcommand_metavar=None, chain=False, result_callback=None, **kwargs):
        super().__init__(name, **kwargs)
        self.commands = {}
        if isinstance(commands, dict):
            for cmd_name, cmd in commands.items():
                self.commands[cmd_name] = cmd
        elif commands:
            for cmd in commands:
                self.commands[cmd.name] = cmd
        self.invoke_without_command = invoke_without_command
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        self.no_args_is_help = no_args_is_help
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback

    def _no_args_message(self):
        return "Missing command."

    # -- subcommands --------------------------------------------------------

    def add_command(self, cmd, name=None):
        # spec: N-000857, N-000858, N-000859 — a group beneath a chaining group is refused.
        if self.chain and isinstance(cmd, Group):
            raise TypeError("Groups cannot be attached beneath a chaining group.")
        name = name or cmd.name
        if name is None:
            raise TypeError("A subcommand needs a name.")
        self.commands[name] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as command_decorator

        if len(args) == 1 and not kwargs and callable(args[0]) and not isinstance(args[0], str):
            cmd = command_decorator()(args[0])
            self.add_command(cmd)
            return cmd

        def decorator(f):
            cmd = command_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as group_decorator

        if len(args) == 1 and not kwargs and callable(args[0]) and not isinstance(args[0], str):
            cmd = group_decorator()(args[0])
            self.add_command(cmd)
            return cmd

        def decorator(f):
            cmd = group_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self):
        def decorator(f):
            self._result_callback = f
            return f

        return decorator

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        return self.commands.get(cmd_name)

    def _visible_commands(self, ctx):
        rows = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            rows.append((name, cmd))
        return rows

    def resolve_command(self, ctx, args):
        # spec: N-000419 .. N-000422
        token = args[0]
        cmd = self.get_command(ctx, token)
        cmd_name = token
        if cmd is None and ctx.token_normalize_func is not None:
            wanted = ctx.token_normalize_func(token)
            for name in self.list_commands(ctx):
                if ctx.token_normalize_func(name) == wanted:
                    cmd = self.get_command(ctx, name)
                    cmd_name = name
                    break
        if cmd is None:
            raise UsageError(f"No such command '{token}'.", ctx)
        return cmd_name, cmd, args[1:]

    # -- parsing ------------------------------------------------------------

    def parse_args(self, ctx, args):
        rest = super().parse_args(ctx, args)
        if self.chain:
            ctx.protected_args = rest
            ctx.args = []
        else:
            ctx.protected_args = rest[:1]
            ctx.args = rest[1:]
        return rest

    def invoke(self, ctx):
        # spec: N-000379 .. N-000402, N-000589 .. N-000593, N-000594
        def process_result(value):
            if self._result_callback is not None:
                value = ctx.invoke(self._result_callback, value, **ctx.params)
            return value

        if not ctx.protected_args:
            if self.invoke_without_command:
                with ctx:
                    ctx.invoked_subcommand = None
                    rv = Command.invoke(self, ctx)
                    result = process_result([] if self.chain else rv)
                return [] if self.chain else result
            raise UsageError("Missing command.", ctx)

        args = [*ctx.protected_args, *ctx.args]
        ctx.args = []
        ctx.protected_args = []

        if not self.chain:
            with ctx:
                cmd_name, cmd, args = self.resolve_command(ctx, args)
                ctx.invoked_subcommand = cmd_name
                Command.invoke(self, ctx)
                sub_ctx = cmd.make_context(cmd_name, args, parent=ctx)
                with sub_ctx:
                    return process_result(sub_ctx.command.invoke(sub_ctx))

        with ctx:
            ctx.invoked_subcommand = "*" if args else None
            Command.invoke(self, ctx)
            contexts = []
            while args:
                cmd_name, cmd, args = self.resolve_command(ctx, args)
                sub_ctx = cmd.make_context(
                    cmd_name, args, parent=ctx, allow_extra_args=True,
                    allow_interspersed_args=False, _chain_child=True,
                )
                contexts.append(sub_ctx)
                args, sub_ctx.args = sub_ctx.args, []
            results = []
            for sub_ctx in contexts:
                with sub_ctx:
                    results.append(sub_ctx.command.invoke(sub_ctx))
            process_result(results)
            return results

    # -- help ----------------------------------------------------------------

    def collect_usage_pieces(self, ctx):
        pieces = super().collect_usage_pieces(ctx)
        if self.subcommand_metavar is not None:
            pieces.append(self.subcommand_metavar)
        elif self.chain:
            pieces.append("COMMAND [ARGS]... [COMMAND [ARGS]...]...")
        elif self.invoke_without_command:
            pieces.append("[COMMAND] [ARGS]...")
        else:
            pieces.append("COMMAND [ARGS]...")
        return pieces

    def format_extra(self, ctx, formatter):
        rows = []
        width = formatter.width
        for name, cmd in self._visible_commands(ctx):
            short = cmd.get_short_help_str(limit=max(width - 2 - 30 - 2, 10))
            rows.append((name, short))
        if rows:
            formatter.write_heading("Commands")
            formatter.write_dl(rows)


class CommandCollection(Group):
    """A group whose subcommands are the union of several source groups."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = set()
        for source in self.sources:
            names.update(source.list_commands(ctx))
        names.update(self.commands)
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None

