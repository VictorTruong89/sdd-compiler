"""Shell completion: registration scripts and suggestion emission."""

from __future__ import annotations

import os
import re
import sys

from .core import Argument, Context, Group, Option
from .termui import echo

SHELLS = ("bash", "zsh", "fish", "powershell")


class CompletionItem:
    """One suggestion: a value, an optional help string, and a kind (``plain`` by default)."""

    # spec: N-001003, N-001004, N-001005

    def __init__(self, value, help=None, type="plain"):
        self.value = str(value)
        self.help = help
        self.type = type

    def __repr__(self):
        return f"<CompletionItem {self.value!r}>"


def _safe_name(prog_name):
    return re.sub(r"\W", "_", prog_name)


def _source_script(shell, prog_name, complete_var):
    # spec: N-000989, N-000990, N-000991, N-000992
    name = _safe_name(prog_name)
    if shell == "bash":
        return f"""_{name}_completion() {{
    local IFS=$'\\n'
    local response
    response=$(env COMP_WORDS="${{COMP_WORDS[*]}}" COMP_CWORD=$COMP_CWORD {complete_var}=bash_complete $1)
    local completion type value
    for completion in $response; do
        type="${{completion%%,*}}"
        value="${{completion#*,}}"
        if [[ $type == 'plain' ]]; then
            COMPREPLY+=("$value")
        elif [[ $type == 'file' ]]; then
            COMPREPLY+=($(compgen -f -- "$value"))
        elif [[ $type == 'dir' ]]; then
            COMPREPLY+=($(compgen -d -- "$value"))
        fi
    done
    return 0
}}

complete -o default -F _{name}_completion {prog_name}
"""
    if shell == "zsh":
        return f"""#compdef {prog_name}

_{name}_completion() {{
    local -a response
    local item type rest value help
    response=("${{(@f)$(env COMP_WORDS="${{words[*]}}" COMP_CWORD=$((CURRENT-1)) {complete_var}=zsh_complete {prog_name})}}")
    for item in "${{response[@]}}"; do
        type="${{item%%,*}}"
        rest="${{item#*,}}"
        value="${{rest%%$'\\t'*}}"
        help="${{rest#*$'\\t'}}"
        if [[ $type == 'plain' ]]; then
            if [[ $rest == *$'\\t'* ]]; then
                compadd -d "$help" -- "$value"
            else
                compadd -- "$value"
            fi
        elif [[ $type == 'file' ]]; then
            _files
        elif [[ $type == 'dir' ]]; then
            _files -/
        fi
    done
}}

compdef _{name}_completion {prog_name}
"""
    if shell == "fish":
        return f"""function _{name}_completion
    set -l response (env COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -ct) {complete_var}=fish_complete {prog_name})
    for completion in $response
        set -l metadata (string split -m 1 "," $completion)
        if test $metadata[1] = "plain"
            echo $metadata[2]
        else if test $metadata[1] = "dir"
            __fish_complete_directories $metadata[2]
        else if test $metadata[1] = "file"
            __fish_complete_path $metadata[2]
        end
    end
end

complete --no-files --command {prog_name} --arguments "(_{name}_completion)"
"""
    return f"""Register-ArgumentCompleter -Native -CommandName '{prog_name}' -ScriptBlock {{
    param($wordToComplete, $commandAst, $cursorPosition)
    $elements = @($commandAst.CommandElements | ForEach-Object {{ $_.ToString() }})
    $cword = $elements.Count - 1
    if ($wordToComplete -eq '') {{ $cword = $elements.Count }}
    $env:COMP_WORDS = $elements -join ' '
    $env:COMP_CWORD = $cword
    $env:{complete_var} = 'powershell_complete'
    $response = & '{prog_name}' 2>$null
    Remove-Item Env:{complete_var}
    foreach ($item in $response) {{
        $type, $value = $item.Split(',', 2)
        if ($type -eq 'plain') {{
            [System.Management.Automation.CompletionResult]::new($value, $value, 'ParameterValue', $value)
        }}
    }}
}}
"""


def _option_for_token(params, token):
    for param in params:
        if isinstance(param, Option) and token in param.opts + param.secondary_opts:
            return param
    return None


def _visible_option_names(ctx, params):
    rows = []
    for param in params:
        if not isinstance(param, Option) or param.hidden:
            continue
        for name in param.opts + param.secondary_opts:
            rows.append((name, param.help))
    return rows


def _normalize_items(raw):
    items = []
    for entry in raw or []:
        if isinstance(entry, CompletionItem):
            items.append(entry)
        elif isinstance(entry, str):
            items.append(CompletionItem(entry))
        else:
            items.append(CompletionItem(entry.value, getattr(entry, "help", None),
                                        getattr(entry, "type", "plain") or "plain"))
    return items


def _descend(cli, preceding):
    """Walk the command tree along ``preceding``. Returns (command, name, remaining tokens)."""
    node = cli
    name = cli.name or "root"
    rest = list(preceding)
    while isinstance(node, Group) and rest:
        token = rest[0]
        if token[:1] in ("-", "/", "+") and len(token) > 1:
            rest.pop(0)
            continue
        probe = Context(node, info_name=name, resilient_parsing=True)
        child = node.get_command(probe, token)
        if child is None:
            break
        name = token
        node = child
        rest.pop(0)
    return node, name, rest


def completion_items(cli, preceding, incomplete, shell):
    """Suggestions for ``incomplete`` after the tokens ``preceding``."""
    # spec: N-000682 .. N-000688, N-000694 .. N-000700
    node, name, rest = _descend(cli, preceding)
    try:
        ctx = node.make_context(name, rest, resilient_parsing=True)
    except Exception:
        ctx = Context(node, info_name=name, resilient_parsing=True)
    params = node.get_params(ctx)
    prefixes = {name_[:1] for p in params if isinstance(p, Option) for name_ in p.opts + p.secondary_opts}
    prefixes.update(ch[:1] for ch in ctx.help_option_names if ch)

    previous = rest[-1] if rest else None
    pending = None
    if previous is not None and previous[:1] in prefixes and "=" not in previous:
        option = _option_for_token(params, previous)
        if option is not None and option.takes_value:
            pending = option
    if pending is not None:
        return _normalize_items(pending.shell_complete_items(ctx, incomplete))

    if incomplete[:1] and incomplete[:1] in prefixes:
        items = []
        seen = set()
        for option_name, help_text in _visible_option_names(ctx, params):
            if option_name.startswith(incomplete) and option_name not in seen:
                seen.add(option_name)
                items.append(CompletionItem(option_name, help_text))
        for help_name in node.get_help_option_names(ctx):
            if help_name.startswith(incomplete) and help_name not in seen:
                seen.add(help_name)
                items.append(CompletionItem(help_name, "Show this message and exit."))
        return items

    if isinstance(node, Group) and not rest:
        items = []
        for cmd_name in node.list_commands(ctx):
            cmd = node.get_command(ctx, cmd_name)
            if cmd is None or cmd.hidden or not cmd_name.startswith(incomplete):
                continue
            items.append(CompletionItem(cmd_name, cmd.get_short_help_str(limit=45)))
        return items

    positional = [p for p in params if isinstance(p, Argument)]
    index = _positional_count(params, rest, prefixes)
    if index < len(positional):
        return _normalize_items(positional[index].shell_complete_items(ctx, incomplete))
    if positional and positional[-1].nargs == -1:
        return _normalize_items(positional[-1].shell_complete_items(ctx, incomplete))
    return []


def _positional_count(params, tokens, prefixes):
    """How many positional values the tokens already supply (option values are skipped)."""
    count = 0
    skip = False
    for token in tokens:
        if skip:
            skip = False
            continue
        if token[:1] in prefixes and len(token) > 1:
            option = _option_for_token(params, token)
            if option is not None and option.takes_value and "=" not in token:
                skip = True
            continue
        count += 1
    return count


def _render(items, shell, incomplete):
    lines = []
    for item in items:
        if item.type == "file":
            lines.append(f"file,{incomplete}")
        elif item.type == "dir":
            lines.append(f"dir,{incomplete}")
        else:
            line = f"plain,{item.value}"
            if item.help and shell in ("zsh", "fish"):
                line += "\t" + " ".join(str(item.help).split())
            lines.append(line)
    return lines


def run_completion(cli, prog_name, complete_var, instruction, standalone_mode):
    """Handle a completion instruction from ``complete_var``. Returns True when handled."""
    # spec: N-000680, N-000681, N-000689 .. N-000693, N-000702, N-000703
    shell, _, action = instruction.partition("_")
    if shell not in SHELLS or action not in ("source", "complete"):
        echo(f"Unsupported completion instruction: {instruction}", err=True)
        if standalone_mode:
            sys.exit(1)
        return True

    if action == "source":
        echo(_source_script(shell, prog_name, complete_var), nl=False)
    else:
        words = os.environ.get("COMP_WORDS", "").split()
        raw_index = os.environ.get("COMP_CWORD", "")
        if shell == "fish":
            incomplete = raw_index
            if words and words[-1] == incomplete and len(words) > 1:
                words = words[:-1]
        else:
            try:
                index = int(raw_index)
            except ValueError:
                index = len(words)
            incomplete = words[index] if 0 <= index < len(words) else ""
            words = words[:index] if index <= len(words) else words
        preceding = words[1:]
        items = completion_items(cli, preceding, incomplete, shell)
        for line in _render(items, shell, incomplete):
            echo(line)
    if standalone_mode:
        sys.exit(0)
    return True
