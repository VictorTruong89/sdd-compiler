---
name: optlyn-build-state
description: State of the from-scratch Optlyn (Click-like CLI library) build in /app, its layout, and the spec rulings applied
metadata:
  type: project
---

Building Optlyn from the spec in /app/spec (33 packs, 1014 checklist ids) into /app/src/optlyn.

- Modules: exceptions, utils, formatting, paramtypes (NOT `types` — that name shadows stdlib when cwd is the package dir), parser, core, decorators, termui, shell_completion, testing, __init__.
- Tests live in /app/tests (run `python3 -m pytest -q tests` from /app; conftest adds src to path).
- Rulings and open choices are recorded in /app/NOTES.md; keep it in sync when behavior changes.
- Spec rulings that surprise: deprecated-command warning goes to stdout; default_map beats env; standalone confirm treats other answers as no; isolated fs never removed; help width cap 80 but wrap_text cap 100.
- Id coverage: each implemented id is marked `# spec: N-xxxxxx` in code; checklist status goes in NOTES.md.
