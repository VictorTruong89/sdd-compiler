"""Core objects: invocation context, parameters, commands and groups."""

import enum
import os
import sys
import threading

from . import termui
from .exceptions import (Abort, BadParameter, DeclarationError, Exit,
                         MissingParameter, NoArgsIsHelpError, UsageError,
                         UsageNoSuchCommand)
from .parser import KIND_PROMPT, OptionParser, split_flag_prefix
from .param_types import BOOL, INT, Tuple, convert_type

_state = threading.local()

CHAIN_SENTINEL = object()

_TRUE_ENV = {"true", "1", "yes", "on", "t", "y"}
_FALSE_ENV = {"false", "0", "no", "off", "f", "n"}


class ParameterSource(enum.Enum):
    PROMPT = "prompt"
    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"


def get_current_context(silent=False):
    stack = getattr(_state, "stack", None)
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")


class Context:
    """The state of one invocation of a command."""

    def __init__(self, command, parent=None, info_name=None, obj=None, default_map=None,
                 terminal_width=None, max_content_width=None, help_option_names=None,
                 token_normalize_func=None, color=None, show_default=None,
                 allow_extra_args=None, ignore_unknown_options=None,
                 allow_interspersed_args=None, auto_envvar_prefix=None, **extra):
        self.parent = parent
        self.command = command
        self.info_name = info_name
        self.obj = obj if obj is not None else (parent.obj if parent is not None else None)
        self.default_map = default_map

        def inherit(value, attr, default):
            if value is not None:
                return value
            if parent is not None:
                return getattr(parent, attr)
            return default

        self.terminal_width = inherit(terminal_width, "terminal_width", None)
        self.max_content_width = inherit(max_content_width, "max_content_width", 80)
        self.help_option_names = inherit(help_option_names, "help_option_names", ["--help"])
        self.token_normalize_func = inherit(token_normalize_func, "token_normalize_func", None)
        self.color = inherit(color, "color", None)
        self.show_default = inherit(show_default, "show_default", None)
        self.allow_extra_args = inherit(allow_extra_args, "allow_extra_args", False)
        self.ignore_unknown_options = inherit(ignore_unknown_options, "ignore_unknown_options", False)
        self.allow_interspersed_args = inherit(allow_interspersed_args, "allow_interspersed_args", None)
        self.auto_envvar_prefix = inherit(auto_envvar_prefix, "auto_envvar_prefix", None)
        self.extra = extra
        self.params = {}
        self.args = []
        self.protected_args = []
        self.invoked_subcommand = None
        self._close_callbacks = []
        self._parameter_sources = {}

    # -- tree helpers -----------------------------------------------------
    @property
    def command_path(self):
        rv = self.info_name or ""
        if self.parent is not None:
            parent_path = self.parent.command_path
            rv = f"{parent_path} {rv}" if parent_path else rv
        return rv.lstrip()

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type):
        node = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        obj = self.find_object(object_type)
        if obj is None:
            obj = object_type()
            self.obj = obj
        return obj

    def get_parameter_source(self, name):
        return self._parameter_sources.get(name)

    def lookup_default(self, name):
        if self.default_map and name in self.default_map:
            return True, self.default_map[name]
        return False, None

    def auto_envvar_name(self, name):
        if not self.auto_envvar_prefix:
            return None
        parts = [self.auto_envvar_prefix]
        chain = []
        node = self
        while node.parent is not None:
            chain.append(node.info_name)
            node = node.parent
        parts.extend(reversed(chain))
        parts.append(name)
        return "_".join(str(p).replace("-", "_").upper() for p in parts)

    # -- resources and control ------------------------------------------
    def call_on_close(self, func):
        self._close_callbacks.append(func)

    def close(self):
        while self._close_callbacks:
            self._close_callbacks.pop()()

    def with_resource(self, cm):
        value = cm.__enter__()
        self.call_on_close(lambda: cm.__exit__(None, None, None))
        return value

    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def get_help(self):
        return self.command.get_help(self)

    def get_usage(self):
        return self.command.get_usage(self)

    def invoke(self, other, /, *args, **kwargs):
        """Run ``other`` (a command or a callable) with exactly ``kwargs``."""
        if isinstance(other, Command):
            sub = Context(other, parent=self, info_name=other.name)
            sub.params = dict(kwargs)
            with sub:
                try:
                    return other.invoke(sub)
                finally:
                    sub.close()
        with self:
            return other(*args, **kwargs)

    def forward(self, other, /, **kwargs):
        merged = dict(self.params)
        merged.update(kwargs)
        return self.invoke(other, **merged)

    # -- context manager protocol ---------------------------------------
    def __enter__(self):
        stack = getattr(_state, "stack", None)
        if stack is None:
            stack = _state.stack = []
        stack.append(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        _state.stack.pop()
        return False


# ---------------------------------------------------------------------------
# Parameters
# ---------------------------------------------------------------------------

class Parameter:
    """Common base for options and arguments."""

    def __init__(self, name, type=None, default=None, required=False, callback=None,
                 nargs=1, multiple=False, metavar=None, expose_value=True,
                 is_eager=False, envvar=None, shell_complete=None, deprecated=False,
                 hidden=False, help=None, show_default=None):
        self.name = name
        self.default = default
        self.type = convert_type(type, default)
        if isinstance(self.type, Tuple):
            nargs = self.type.arity
        self.required = required
        self.callback = callback
        self.nargs = nargs
        self.multiple = multiple
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        self.envvar = _as_list(envvar)
        self.shell_complete = shell_complete
        self.deprecated = deprecated
        self.hidden = hidden
        self.help = help
        self.show_default = show_default

    def get_error_hint(self):
        return self.name

    def get_default(self, ctx):
        return self.default() if callable(self.default) else self.default

    def convert_one(self, ctx, raw):
        """Convert one occurrence (a token, or a tuple of tokens for nargs>1)."""
        if self.nargs == -1:
            return self.type.convert(raw, self, ctx)
        if self.type.is_composite:
            if not isinstance(raw, (tuple, list)):
                raw = (raw,)
            return self.type.convert(tuple(raw), self, ctx)
        if self.nargs == 1 and not isinstance(raw, (tuple, list)):
            return self.type.convert(raw, self, ctx)
        if not isinstance(raw, (tuple, list)):
            raw = (raw,)
        return tuple(self.type.convert(r, self, ctx) for r in raw)

    def _env_raw(self, ctx):
        names = list(self.envvar)
        if isinstance(self, Option) and self.allow_from_autoenv:
            auto = ctx.auto_envvar_name(self.name)
            if auto:
                names.append(auto)
        for env_name in names:
            value = os.environ.get(env_name)
            if value:
                return value
        return None

    def process_value(self, ctx, value):
        if self.callback is not None:
            value = self.callback(ctx, self, value)
        return value

    def __repr__(self):
        return f"<{self.__class__.__name__} {self.name}>"


def _as_list(value):
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    return list(value)


def _split_decls(decls):
    dest = None
    opts = []
    secondary = []
    for decl in decls:
        prefix, rest = split_flag_prefix(decl)
        if not prefix:
            if dest is not None:
                raise DeclarationError(f"Multiple destinations declared: {dest!r} and {decl!r}.")
            dest = decl
            continue
        if "/" in decl and not decl.startswith("/"):
            on, off = decl.split("/", 1)
            opts.append(on)
            secondary.append(off)
        else:
            opts.append(decl)
    if dest is None:
        if opts:
            dest = _infer_name(opts)
        elif secondary:
            dest = _infer_name(secondary)
        else:
            raise DeclarationError("An option needs a flag name or a destination.")
    return dest, opts, secondary


def _infer_name(names):
    longs = [n for n in names if split_flag_prefix(n)[0][:2] == "--" or len(split_flag_prefix(n)[0]) >= 2]
    if longs:
        return split_flag_prefix(longs[0])[1].replace("-", "_")
    return split_flag_prefix(names[0])[1].replace("-", "_")


class Option(Parameter):
    """A named parameter, introduced by a prefix such as ``--``."""

    def __init__(self, param_decls=(), name=None, is_flag=None, flag_value=None,
                 count=False, prompt=False, prompt_required=True, hide_input=False,
                 confirmation_prompt=False, allow_from_autoenv=True, show_envvar=False,
                 type=None, default=None, required=False, **attrs):
        dest, opts, secondary = _split_decls(list(param_decls))
        if not opts and not secondary:
            raise DeclarationError("An option needs at least one flag name.")
        super().__init__(name or dest, type=None, default=default, required=required, **attrs)
        self.opts = opts
        self.secondary_opts = secondary
        self.count = bool(count)
        if is_flag is None:
            is_flag = bool(secondary) or isinstance(default, bool) or (
                flag_value is None and type is BOOL)
        if self.count:
            is_flag = False
        self.is_flag = bool(is_flag)
        self.flag_value = flag_value
        self.takes_value = not self.is_flag and not self.count
        self.optional_value = flag_value is not None and self.takes_value
        if self.is_flag:
            self.default = False if default is None else default
        if self.count and default is None:
            self.default = 0
        if self.is_flag and type is None:
            resolved_type = BOOL
        elif self.count and type is None:
            resolved_type = INT
        else:
            resolved_type = convert_type(type, self.default)
        self.type = resolved_type
        if isinstance(self.type, Tuple):
            self.nargs = self.type.arity
        if self.nargs < 1:
            raise DeclarationError("nargs must be a positive integer.")
        if self.is_flag and self.nargs != 1:
            raise DeclarationError("A flag cannot take a number of values.")
        if self.multiple and self.count:
            raise DeclarationError("A counting option cannot be repeatable.")
        self.prompt = prompt
        self.prompt_required = prompt_required
        self.prompt_text = prompt if isinstance(prompt, str) else None
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.allow_from_autoenv = allow_from_autoenv
        self.show_envvar = show_envvar
        if self.deprecated and self.required:
            raise DeclarationError("A deprecated option cannot be required.")
        if self.deprecated and self.prompt:
            raise DeclarationError("A deprecated option cannot use a prompt.")
        if self.is_flag and self.prompt:
            raise DeclarationError("A flag cannot prompt.")

    def all_flag_decls(self):
        return [(d, False) for d in self.opts] + [(d, True) for d in self.secondary_opts]

    def flag_value_for(self, secondary):
        if secondary:
            return False
        if self.flag_value is not None:
            return self.flag_value
        return True

    def get_error_hint(self):
        return " / ".join(self.opts + self.secondary_opts)

    @property
    def metavar_text(self):
        if self.metavar is not None:
            return self.metavar
        if not self.takes_value:
            return None
        return self.type.get_metavar(self) or self.type.name.upper()

    def get_default(self, ctx):
        if self.is_flag and self.default is None:
            return False
        return super().get_default(ctx)

    def env_flag_value(self, ctx, raw):
        """Interpret an environment value for a flag. Returns None when unset."""
        text = raw.strip().lower()
        if self.flag_value is not None and raw == str(self.flag_value):
            return self.flag_value
        if text in _TRUE_ENV:
            return True
        if text in _FALSE_ENV:
            return False
        if text == "":
            return None
        if self.flag_value is not None:
            return None
        raise BadParameter(f"{raw!r} is not a valid boolean.", ctx=ctx, param=self)


class Argument(Parameter):
    """A positional parameter."""

    def __init__(self, param_decls, **attrs):
        decls = list(param_decls)
        if len(decls) != 1 or split_flag_prefix(decls[0])[0]:
            raise DeclarationError("An argument takes exactly one destination name.")
        name = decls[0]
        nargs = attrs.pop("nargs", 1)
        default = attrs.get("default")
        required = attrs.pop("required", None)
        if required is None:
            required = (nargs != -1) and default is None
        if nargs == 0 or nargs < -1:
            raise DeclarationError("nargs must be a positive integer or -1.")
        self.variadic = nargs == -1
        if attrs.get("deprecated") and required:
            raise DeclarationError("A deprecated argument cannot be required.")
        attrs["required"] = required
        attrs["nargs"] = nargs
        envvar = attrs.pop("envvar", None)
        super().__init__(name, **attrs)
        self.envvar = _as_list(envvar)

    @property
    def metavar_text(self):
        if self.metavar is not None:
            return self.metavar
        return self.name.upper()

    def convert_missing(self, ctx):
        return () if self.variadic else None

    def get_default(self, ctx):
        return super().get_default(ctx)

    def env_raw(self, ctx):
        for env_name in self.envvar:
            value = os.environ.get(env_name)
            if value:
                return value
        return None


# ---------------------------------------------------------------------------
# Commands and groups
# ---------------------------------------------------------------------------

def _make_help_option(names):
    def show_help(ctx, param, value):
        if not value or ctx is None:
            return
        termui.echo(ctx.get_help(), color=ctx.color)
        ctx.exit(0)

    return Option(names, name="_optlyn_help", is_flag=True, is_eager=True,
                  expose_value=False, callback=show_help,
                  help="Show this message and exit.")


class Command:
    """A leaf command: options and arguments plus a callback."""

    def __init__(self, name, callback=None, params=None, help=None, short_help=None,
                 epilog=None, options_metavar="[OPTIONS]", context_settings=None,
                 add_help_option=True, no_args_is_help=False, deprecated=False,
                 hidden=False, **kwargs):
        self.name = name
        self.callback = callback
        self.params = list(params or [])
        doc = getattr(callback, "__doc__", None) if callback is not None else None
        if help is None and doc:
            help = doc.split("\f")[0]
        self.help = help
        self.short_help = short_help
        self.epilog = epilog
        self.options_metavar = options_metavar
        self.context_settings = dict(context_settings or {})
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.deprecated = bool(deprecated)
        self.deprecation_note = deprecated if isinstance(deprecated, str) else None
        self.hidden = hidden
        self.extra = kwargs

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    # -- parameter sets -------------------------------------------------
    def get_help_option(self, ctx):
        if not self.add_help_option:
            return None
        author = set()
        for p in self.params:
            if isinstance(p, Option):
                author.update(d for d, _ in p.all_flag_decls())
        names = [n for n in ctx.help_option_names if n not in author]
        if not names:
            return None
        return _make_help_option(names)

    def get_params(self, ctx):
        params = list(self.params)
        help_opt = self.get_help_option(ctx)
        if help_opt is not None:
            params.append(help_opt)
        return params

    def _fixed_arg_count(self):
        total = 0
        for p in self.params:
            if isinstance(p, Argument):
                if p.nargs == -1:
                    return None
                total += p.nargs
        return total

    # -- parsing --------------------------------------------------------
    def _parser_settings(self, ctx, chain):
        if chain:
            return dict(interspersed=False, stop_after=self._fixed_arg_count())
        return dict(interspersed=ctx.allow_interspersed_args is not False, stop_after=None)

    def make_context(self, info_name, args, parent=None, chain=False, **extra):
        settings = dict(self.context_settings)
        settings.update(extra)
        if parent is not None:
            nested = (parent.default_map or {}).get(info_name)
            settings["default_map"] = nested if isinstance(nested, dict) else None
        ctx = Context(self, parent=parent, info_name=info_name, **settings)
        with ctx:
            if not args and self.no_args_is_help:
                raise NoArgsIsHelpError(ctx)
            self.parse_args(ctx, list(args), chain=chain)
        return ctx

    def parse_args(self, ctx, args, chain=False):
        params = self.get_params(ctx)
        settings = self._parser_settings(ctx, chain)
        parser = OptionParser(
            [p for p in params if isinstance(p, Option)],
            ignore_unknown=bool(ctx.ignore_unknown_options),
            **settings)
        occurrences, positional, child_args, rest = parser.parse(args)
        rest = child_args + rest if child_args else rest

        occ_by = {}
        for occ in occurrences:
            occ_by.setdefault(id(occ.param), []).append(occ)

        arg_tokens, leftover = self._bind_arguments(ctx, positional)
        if leftover:
            if not ctx.allow_extra_args:
                raise UsageError(
                    f"Got unexpected extra argument{'s' if len(leftover) > 1 else ''} "
                    f"({' '.join(leftover)})", ctx)
            for tok in leftover:
                if tok.startswith("-") and len(tok) > 1 and not ctx.ignore_unknown_options:
                    raise UsageError(f"No such option: {tok}", ctx)
            ctx.args = leftover
        ctx.protected_args = rest

        eager = [p for p in params if p.is_eager]
        given = sorted((p for p in eager if id(p) in occ_by),
                       key=lambda p: min(o.index for o in occ_by[id(p)]))
        order = given + [p for p in eager if p not in given] + [p for p in params if not p.is_eager]
        for param in order:
            if isinstance(param, Option):
                self._process_option(ctx, param, occ_by.get(id(param), []))
            else:
                self._process_argument(ctx, param, arg_tokens.get(id(param), []))

    def _bind_arguments(self, ctx, positional):
        arguments = [p for p in self.params if isinstance(p, Argument)]
        result = {}
        idx = 0
        for i, arg in enumerate(arguments):
            if arg.nargs == -1:
                reserved = sum(a.nargs for a in arguments[i + 1:] if a.nargs > 0)
                count = max(0, len(positional) - idx - reserved)
                result[id(arg)] = positional[idx:idx + count]
                idx += count
            else:
                chunk = positional[idx:idx + arg.nargs]
                if chunk and len(chunk) < arg.nargs:
                    raise UsageError(
                        f"Argument '{arg.name}' takes {arg.nargs} values.", ctx)
                result[id(arg)] = chunk
                idx += len(chunk)
        return result, positional[idx:]

    # -- value resolution ------------------------------------------------
    def _process_option(self, ctx, param, occs):
        value, source = self._resolve_option(ctx, param, occs)
        if source is ParameterSource.COMMANDLINE and param.deprecated:
            note = param.deprecated if isinstance(param.deprecated, str) else None
            _warn_deprecated(f"The '{param.opts[0]}' option", note)
        ctx._parameter_sources[param.name] = source
        value = param.process_value(ctx, value)
        ctx.params[param.name] = value
        return value

    def _process_argument(self, ctx, param, tokens):
        value, source = self._resolve_argument(ctx, param, tokens)
        if source is ParameterSource.COMMANDLINE and param.deprecated:
            note = param.deprecated if isinstance(param.deprecated, str) else None
            _warn_deprecated(f"The '{param.name}' argument", note)
        ctx._parameter_sources[param.name] = source
        value = param.process_value(ctx, value)
        ctx.params[param.name] = value
        return value

    def _resolve_option(self, ctx, param, occs):
        cmd_occs = [o for o in occs if o.kind != KIND_PROMPT]
        prompt_asked = any(o.kind == KIND_PROMPT for o in occs)

        if param.count:
            if cmd_occs:
                return sum(o.value for o in cmd_occs), ParameterSource.COMMANDLINE
            return param.get_default(ctx), ParameterSource.DEFAULT

        if param.is_flag:
            if cmd_occs:
                return cmd_occs[-1].value, ParameterSource.COMMANDLINE
            env_raw = param._env_raw(ctx)
            if env_raw is not None:
                env_value = param.env_flag_value(ctx, env_raw)
                if env_value is not None:
                    return env_value, ParameterSource.ENVIRONMENT
            has_dm, dm_value = ctx.lookup_default(param.name)
            if has_dm:
                return dm_value, ParameterSource.DEFAULT_MAP
            return param.get_default(ctx), ParameterSource.DEFAULT

        if cmd_occs:
            if param.multiple:
                value = tuple(param.convert_one(ctx, o.value) for o in cmd_occs)
            else:
                value = param.convert_one(ctx, cmd_occs[-1].value)
            return value, ParameterSource.COMMANDLINE

        env_raw = param._env_raw(ctx)
        prompt_triggered = param.prompt and (
            prompt_asked or (param.required and env_raw is None))
        if env_raw is not None and not prompt_asked:
            return self._convert_collection(ctx, param, env_raw), ParameterSource.ENVIRONMENT

        if prompt_triggered:
            has_dm, dm_value = ctx.lookup_default(param.name)
            default = dm_value if has_dm else param.default
            text = param.prompt_text or param.name.replace("_", " ").capitalize()
            value = termui.prompt(
                text, default=default, hide_input=param.hide_input,
                confirmation_prompt=param.confirmation_prompt, type=param.type)
            if param.multiple:
                value = (value,)
            return value, ParameterSource.PROMPT

        has_dm, dm_value = ctx.lookup_default(param.name)
        if has_dm:
            return self._convert_collection(ctx, param, dm_value), ParameterSource.DEFAULT_MAP

        default = param.get_default(ctx)
        if default is None and param.required:
            raise MissingParameter(ctx=ctx, param=param)
        if default is None and param.multiple:
            return (), ParameterSource.DEFAULT
        if param.multiple:
            if isinstance(default, str):
                raise BadParameter(
                    "The default for this repeatable option must be an iterable (sequence) of values.",
                    ctx=ctx, param=param)
            return tuple(param.convert_one(ctx, v) for v in default), ParameterSource.DEFAULT
        if default is None:
            return None, ParameterSource.DEFAULT
        return param.convert_one(ctx, default), ParameterSource.DEFAULT

    def _convert_collection(self, ctx, param, raw):
        """Convert an environment or default-map value for a parameter."""
        if param.multiple:
            if isinstance(raw, str):
                if param.nargs == 1 and not param.type.is_composite:
                    raise BadParameter(
                        "The default for this repeatable option must be an iterable (sequence) of values.",
                        ctx=ctx, param=param)
                raw = param.type.split_envvar_value(raw)
            if param.nargs == 1 and not param.type.is_composite:
                return tuple(param.convert_one(ctx, v) for v in raw)
            return tuple(param.convert_one(ctx, tuple(v) if isinstance(v, list) else v) for v in raw)
        if isinstance(raw, str) and (param.nargs != 1 or param.type.is_composite):
            raw = tuple(param.type.split_envvar_value(raw))
        return param.convert_one(ctx, raw)

    def _resolve_argument(self, ctx, param, tokens):
        if tokens:
            if param.variadic:
                value = tuple(param.convert_one(ctx, t) for t in tokens)
            elif param.nargs == 1 and not param.type.is_composite:
                value = param.convert_one(ctx, tokens[0])
            else:
                value = param.convert_one(ctx, tuple(tokens))
            return value, ParameterSource.COMMANDLINE

        env_raw = param.env_raw(ctx)
        if env_raw is not None:
            return self._convert_collection(ctx, param, env_raw), ParameterSource.ENVIRONMENT

        has_dm, dm_value = ctx.lookup_default(param.name)
        if has_dm:
            return self._convert_collection(ctx, param, dm_value), ParameterSource.DEFAULT_MAP

        default = param.get_default(ctx)
        if default is None:
            if param.required:
                raise MissingParameter(ctx=ctx, param=param)
            return param.convert_missing(ctx), ParameterSource.DEFAULT
        if param.variadic:
            return tuple(param.type.convert(v, param, ctx) for v in default), ParameterSource.DEFAULT
        return param.convert_one(ctx, default), ParameterSource.DEFAULT

    # -- invocation -------------------------------------------------------
    def _callback_kwargs(self, ctx):
        return {p.name: ctx.params[p.name] for p in self.params
                if p.expose_value and p.name in ctx.params}

    def invoke(self, ctx):
        if self.deprecated:
            _warn_deprecated(f"The command '{ctx.command_path}'", self.deprecation_note)
        if self.callback is None:
            return None
        with ctx:
            return self.callback(**self._callback_kwargs(ctx))

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True, **extra):
        if args is None:
            args = sys.argv[1:]
        if prog_name is None:
            prog_name = _detect_prog_name()
        from .shell_completion import handle_completion_env

        completed, status = handle_completion_env(self, prog_name, complete_var)
        if completed:
            if standalone_mode:
                sys.exit(status)
            return status

        ctx = None
        try:
            try:
                ctx = self.make_context(prog_name, list(args), **extra)
                with ctx:
                    rv = self.invoke(ctx)
                if not standalone_mode:
                    return rv
                ctx.exit()
            finally:
                if ctx is not None:
                    ctx.close()
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return e.exit_code
        except (EOFError, KeyboardInterrupt):
            if not standalone_mode:
                raise
            termui.echo(file=sys.stderr)
            Abort().show()
            sys.exit(1)
        except Abort as e:
            if not standalone_mode:
                raise
            e.show()
            sys.exit(1)
        except UsageError as e:
            if not standalone_mode:
                raise
            if isinstance(e, NoArgsIsHelpError):
                termui.echo(e.ctx.get_help(), err=True, color=e.ctx.color)
            else:
                e.show()
                if e.ctx is not None:
                    termui.echo(f"Try '{e.ctx.command_path} --help' for help.", err=True)
            sys.exit(2)
        except Exception as e:
            from .exceptions import OptlynError

            if isinstance(e, OptlynError) and standalone_mode:
                e.show()
                sys.exit(e.exit_code)
            raise

    # -- help -------------------------------------------------------------
    def get_help(self, ctx):
        from .formatting import format_help

        return format_help(ctx, self)

    def get_usage(self, ctx):
        from .formatting import format_usage

        return format_usage(ctx, self)

    def get_short_help(self):
        if self.short_help is not None:
            return self.short_help
        text = self.help or ""
        first = text.strip().split("\n\n")[0].replace("\n", " ")
        idx = first.find(". ")
        return first[:idx + 1] if idx != -1 else first


class Group(Command):
    """A command that dispatches to named subcommands."""

    def __init__(self, name=None, commands=None, invoke_without_command=False,
                 no_args_is_help=None, subcommand_metavar=None, chain=False,
                 result_callback=None, **kwargs):
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        super().__init__(name, no_args_is_help=no_args_is_help, **kwargs)
        self.commands = dict(commands or {})
        self.invoke_without_command = invoke_without_command
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self.result_callback_func = result_callback
        self.mixing = False

    def _parser_settings(self, ctx, chain):
        return dict(interspersed=True, stop_after=self._fixed_arg_count(),
                    mixing=bool(ctx.allow_interspersed_args))

    def add_command(self, cmd, name=None):
        if self.chain and isinstance(cmd, Group):
            raise DeclarationError("Groups cannot be nested under a chaining group.")
        self.commands[name or cmd.name] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as command_decorator

        def decorator(f):
            cmd = command_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as group_decorator

        def decorator(f):
            cmd = group_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self):
        """Decorator that registers the function receiving subcommand return values."""
        def decorator(f):
            self.result_callback_func = f
            return f

        return decorator

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        cmd = self.commands.get(cmd_name)
        if cmd is None and ctx is not None and ctx.token_normalize_func:
            norm = ctx.token_normalize_func(cmd_name)
            for name, candidate in self.commands.items():
                if ctx.token_normalize_func(name) == norm:
                    return candidate
        return cmd

    def _invoke_result(self, ctx, value):
        if self.result_callback_func is None:
            return value
        return self.result_callback_func(value, **self._callback_kwargs(ctx))

    def invoke(self, ctx):
        if self.chain:
            return self._invoke_chain(ctx)
        rest = list(ctx.protected_args)
        if not rest:
            if self.invoke_without_command:
                ret = self._run_callback(ctx)
                return self._invoke_result(ctx, ret)
            raise UsageError("Missing command.", ctx)
        name, sub_args = rest[0], rest[1:]
        cmd = self.get_command(ctx, name)
        if cmd is None:
            raise UsageNoSuchCommand(name, ctx=ctx)
        ctx.invoked_subcommand = name
        self._run_callback(ctx)
        sub = cmd.make_context(name, sub_args, parent=ctx)
        try:
            value = cmd.invoke(sub)
        finally:
            sub.close()
        return self._invoke_result(ctx, value)

    def _run_callback(self, ctx):
        if self.callback is None:
            return None
        with ctx:
            return self.callback(**self._callback_kwargs(ctx))

    def _invoke_chain(self, ctx):
        rest = list(ctx.protected_args)
        subs = []
        while rest:
            name = rest[0]
            cmd = self.get_command(ctx, name)
            if cmd is None:
                raise UsageNoSuchCommand(name, ctx=ctx)
            sub = cmd.make_context(name, rest[1:], parent=ctx, chain=True)
            subs.append((cmd, sub))
            rest = sub.protected_args
        if not subs and not self.invoke_without_command:
            raise UsageError("Missing command.", ctx)
        ctx.invoked_subcommand = CHAIN_SENTINEL
        self._run_callback(ctx)
        results = []
        for cmd, sub in subs:
            try:
                results.append(cmd.invoke(sub))
            finally:
                sub.close()
        if self.result_callback_func is not None:
            self.result_callback_func(results, **self._callback_kwargs(ctx))
        return results


class CommandCollection(Group):
    """Presents the union of the subcommands of several source groups."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = set()
        for source in self.sources:
            names.update(source.list_commands(ctx))
        names.update(self.commands)
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        cmd = self.commands.get(cmd_name)
        if cmd is not None:
            return cmd
        for source in self.sources:
            found = source.get_command(ctx, cmd_name)
            if found is not None:
                return found
        return None


def _detect_prog_name():
    argv0 = sys.argv[0] if sys.argv and sys.argv[0] else "main"
    name = os.path.basename(argv0)
    if name.endswith(".py"):
        name = name[:-3]
    return name or "main"


def _warn_deprecated(subject, note):
    message = f"DeprecationWarning: {subject} is deprecated."
    if note:
        message += f" {note}"
    termui.echo(message, err=True)
