"""Exception classes used by Optlyn."""


class OptlynError(Exception):
    """Base class for all Optlyn errors."""

    exit_code = 1

    def __init__(self, message=None):
        super().__init__(message)
        self.message = message

    def show(self, file=None):
        import sys

        from .termui import echo

        echo(f"Error: {self.message}", file=file or sys.stderr, err=True)


class UsageError(OptlynError):
    """A usage failure: bad options, missing parameters, conversion failures."""

    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.ctx = ctx

    def show(self, file=None):
        import sys

        from .termui import echo

        echo(f"Usage error: {self.message}", file=file or sys.stderr, err=True)


class BadParameter(UsageError):
    """Raised to refuse a parameter value.

    ``param`` and ``param_hint`` identify the offending parameter in the report.
    """

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        if self.param_hint is not None:
            hint = self.param_hint
        elif self.param is not None:
            hint = self.param.get_error_hint()
        else:
            return self.message
        if isinstance(hint, (list, tuple)):
            hint = " / ".join(f"'{h}'" for h in hint)
        else:
            hint = f"'{hint}'"
        return f"Invalid value for {hint}: {self.message}"

    def show(self, file=None):
        import sys

        from .termui import echo

        echo(f"Usage error: {self.format_message()}", file=file or sys.stderr, err=True)


class MissingParameter(BadParameter):
    """A required parameter received no value."""

    def __init__(self, message=None, ctx=None, param=None, param_hint=None):
        super().__init__(message or "", ctx=ctx, param=param, param_hint=param_hint)

    def format_message(self):
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint()
        if isinstance(hint, (list, tuple)):
            hint = " / ".join(f"'{h}'" for h in hint)
        elif hint is not None:
            hint = f"'{hint}'"
        return f"Missing parameter: {hint}" if hint else "Missing parameter."


class NoSuchOption(UsageError):
    """An option name is not known to the command."""

    def __init__(self, option_name, message=None, ctx=None):
        super().__init__(message or f"No such option: {option_name}", ctx)
        self.option_name = option_name


class UsageNoSuchCommand(UsageError):
    """A subcommand name is not known to the group."""

    def __init__(self, cmd_name, message=None, ctx=None):
        super().__init__(message or f"No such command '{cmd_name}'.", ctx)
        self.cmd_name = cmd_name


class NoArgsIsHelpError(UsageError):
    """Usage failure that shows the help page of ``ctx`` (exit status 2)."""

    def __init__(self, ctx):
        super().__init__("Missing command.", ctx)
        self.show_help = True


class Abort(OptlynError):
    """Abort: user declined, end of input, keyboard interrupt, or author abort."""

    exit_code = 1

    def show(self, file=None):
        import sys

        from .termui import echo

        echo("Aborted!", file=file or sys.stderr, err=True)


class Exit(Exception):
    """Author clean stop with a status code. Raised by ``Context.exit``."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code


class FileError(OptlynError):
    """A file could not be opened at first I/O (general error class)."""

    exit_code = 1

    def __init__(self, filename, message=None):
        super().__init__(message or f"Could not open file: {filename}")
        self.filename = filename

    def show(self, file=None):
        import sys

        from .termui import echo

        echo(f"Error: {self.message}", file=file or sys.stderr, err=True)


class DeclarationError(TypeError):
    """An invalid declaration combination, refused when applied."""
