"""Help page, usage line, and text wrapping."""

import shutil
import textwrap

from .core import Argument, Group, Option


def wrap_text(text, width=78, initial_indent="", subsequent_indent="",
              preserve_paragraphs=False):
    """Rewrap ``text`` to ``width`` columns. Single newlines are not kept.

    A paragraph whose first line is only a backspace is not rewrapped: its
    line breaks are kept and the backspace line itself is removed.
    """
    if text is None:
        return ""
    width = max(int(width), 1)
    paragraphs = []
    for block in str(text).split("\n\n"):
        lines = block.split("\n")
        if lines and lines[0].strip("\b") == "" and lines[0] != "":
            kept = [ln for ln in lines[1:]]
            paragraphs.append(("raw", "\n".join(kept)))
        else:
            paragraphs.append(("wrap", " ".join(ln.strip() for ln in lines if ln.strip())))
    out = []
    for kind, body in paragraphs:
        if kind == "raw":
            prefix = initial_indent if not out else subsequent_indent
            out.append("\n".join(prefix + ln for ln in body.split("\n")))
        elif body:
            wrapped = textwrap.fill(
                body, width=width,
                initial_indent=initial_indent if not out else subsequent_indent,
                subsequent_indent=subsequent_indent,
                break_long_words=False, break_on_hyphens=False)
            out.append(wrapped)
    return "\n\n".join(out)


def _wrap_width(ctx):
    if ctx is None:
        return 78
    if ctx.terminal_width is not None:
        return ctx.terminal_width
    detected = shutil.get_terminal_size((80, 24)).columns
    return max(min(detected, ctx.max_content_width) - 2, 20)


def _visible_options(cmd):
    return [p for p in cmd.params if isinstance(p, Option) and not p.hidden]


def _has_help_option(ctx, cmd):
    return cmd.get_help_option(ctx) is not None


def _argument_placeholder(arg):
    if arg.nargs == -1:
        text = f"{arg.metavar_text}..."
    else:
        text = arg.metavar_text
        if arg.nargs > 1:
            text = " ".join([text] * arg.nargs)
    return text if arg.required else f"[{text}]"


def format_usage(ctx, cmd):
    pieces = [ctx.command_path if ctx is not None else (cmd.name or "")]
    options = _visible_options(cmd)
    if options or (ctx is not None and _has_help_option(ctx, cmd)):
        pieces.append(cmd.options_metavar)
    for arg in cmd.params:
        if isinstance(arg, Argument):
            pieces.append(_argument_placeholder(arg))
    if isinstance(cmd, Group):
        metavar = cmd.subcommand_metavar
        if cmd.chain:
            pieces.append(metavar or "COMMAND [ARGS]... [COMMAND [ARGS]...]...")
        elif cmd.invoke_without_command:
            pieces.append(metavar or "[COMMAND] [ARGS]...")
        else:
            pieces.append(metavar or "COMMAND [ARGS]...")
    return "Usage: " + " ".join(p for p in pieces if p)


def _option_default_text(ctx, param):
    show = param.show_default
    if show is None:
        show = ctx.show_default if ctx is not None else None
    if not show:
        return None
    if isinstance(show, str):
        return show
    if param.is_flag and not param.default:
        return None
    if param.default is None:
        return None
    default = param.default() if callable(param.default) else param.default
    if isinstance(default, (list, tuple)):
        return ", ".join(str(d) for d in default)
    return str(default)


def _option_entry(ctx, param):
    names = " / ".join(param.opts + param.secondary_opts)
    head = names
    if param.metavar_text:
        head += f" {param.metavar_text}"
    text = param.help or ""
    extras = []
    if param.deprecated:
        extras.append("(deprecated)")
    default_text = _option_default_text(ctx, param)
    if default_text is not None:
        extras.append(f"[default: {default_text}]")
    if param.show_envvar:
        names_env = list(param.envvar)
        if param.allow_from_autoenv and ctx is not None:
            auto = ctx.auto_envvar_name(param.name)
            if auto:
                names_env.append(auto)
        if names_env:
            extras.append(f"[env var: {names_env[0]}]")
    line_text = " ".join(t for t in [text] + extras if t)
    return head, line_text


def _argument_entry(ctx, arg):
    text = arg.help or ""
    if arg.deprecated:
        text = " ".join(t for t in [text, "(deprecated)"] if t)
    return arg.metavar_text, text


def _section(title, rows, width):
    if not rows:
        return []
    left = max(len(head) for head, _ in rows)
    left = min(left, 30)
    lines = [f"{title}:"]
    for head, text in rows:
        indent = "  "
        if not text:
            lines.append(f"{indent}{head}")
            continue
        if len(head) > left:
            lines.append(f"{indent}{head}")
            lines.append(textwrap.indent(
                wrap_text(text, width=max(width - left - 6, 20)), " " * (left + 4)))
        else:
            wrapped = wrap_text(text, width=max(width - left - 6, 20)).split("\n")
            lines.append(f"{indent}{head.ljust(left)}  {wrapped[0]}")
            for extra in wrapped[1:]:
                lines.append(" " * (left + 4) + extra)
    lines.append("")
    return lines


def format_help(ctx, cmd):
    width = _wrap_width(ctx)
    out = [format_usage(ctx, cmd), ""]
    if cmd.deprecated:
        note = cmd.deprecation_note or "This command is deprecated."
        out.append(wrap_text(f"DeprecationWarning: {note}", width=width))
        out.append("")
    description = cmd.help
    if description:
        out.append(wrap_text(description.strip(), width=width))
        out.append("")

    args = [(p, _argument_entry(ctx, p)) for p in cmd.params
            if isinstance(p, Argument) and not p.hidden and p.help]
    if args:
        out.extend(_section("Positional arguments", [e for _, e in args], width))

    opt_rows = []
    for param in cmd.params:
        if isinstance(param, Option) and not param.hidden:
            opt_rows.append(_option_entry(ctx, param))
    help_opt = cmd.get_help_option(ctx) if ctx is not None else None
    if help_opt is not None:
        opt_rows.append(_option_entry(ctx, help_opt))
    if opt_rows:
        out.extend(_section("Options", opt_rows, width))

    if isinstance(cmd, Group) and ctx is not None:
        rows = []
        for name in cmd.list_commands(ctx):
            child = cmd.get_command(ctx, name)
            if child is None or child.hidden:
                continue
            rows.append((name, child.get_short_help()))
        if rows:
            out.extend(_section("Commands", rows, width))

    if cmd.epilog:
        out.append(wrap_text(cmd.epilog.strip(), width=width))
        out.append("")
    return "\n".join(out).rstrip("\n") + "\n"
