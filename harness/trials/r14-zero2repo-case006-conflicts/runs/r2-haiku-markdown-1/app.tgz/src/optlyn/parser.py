"""Token-level parser for options.

The parser turns an argument list into option occurrences plus the
positional tokens it did not consume. Converting and binding values is done
by the command (see ``core.py``).
"""

from .exceptions import NoSuchOption, UsageError

KIND_RAW = "raw"          # a token to be converted with the parameter type
KIND_VALUE = "value"      # an already-final value (flag values)
KIND_PROMPT = "prompt"    # value omitted but the flag was present: prompt for it


class Occurrence:
    __slots__ = ("param", "kind", "value", "index")

    def __init__(self, param, kind, value, index):
        self.param = param
        self.kind = kind
        self.value = value
        self.index = index


def is_prefix_char(ch):
    return not (ch.isalnum() or ch == "_") and not ch.isspace() and ch != ""


def split_flag_prefix(decl):
    """Split a declared flag name into (prefix, rest). Prefix is up to 2 chars."""
    prefix = ""
    while len(prefix) < 2 and decl[len(prefix):len(prefix) + 1] and is_prefix_char(decl[len(prefix)]):
        prefix += decl[len(prefix)]
    return prefix, decl[len(prefix):]


class OptionParser:
    """Parse option tokens for one command.

    ``stop_after`` is the number of positional tokens after which the next
    positional token ends this command's part of the line (groups and chained
    commands). ``None`` means the command takes every token.
    """

    def __init__(self, options, *, interspersed=True, ignore_unknown=False,
                 stop_after=None, mixing=False, allow_extra=False):
        self.options = list(options)
        self.interspersed = interspersed
        self.ignore_unknown = ignore_unknown
        self.stop_after = stop_after
        self.mixing = mixing
        self.allow_extra = allow_extra
        self.table = {}
        self.prefixes = {"-"}
        for opt in self.options:
            for decl, secondary in opt.all_flag_decls():
                prefix, _ = split_flag_prefix(decl)
                self.prefixes.update(prefix[:1])
                self.table[decl] = (opt, secondary)

    # -- token classification -------------------------------------------
    def _is_option_like(self, tok):
        return len(tok) > 1 and tok[0] in self.prefixes

    def _is_known_option(self, tok):
        name = tok.split("=", 1)[0]
        if name in self.table:
            return True
        return len(name) > 1 and name[0] in self.prefixes and any(
            (name[0] + c) in self.table for c in name[1:2])

    # -- main loop --------------------------------------------------------
    def parse(self, args):
        occurrences = []
        positional = []
        child_args = []
        rest = []
        i = 0
        n = len(args)
        dd = False
        options_off = False
        while i < n:
            tok = args[i]
            if dd:
                positional.append(tok)
                i += 1
                continue
            if tok == "--" and not options_off:
                dd = True
                i += 1
                continue
            if not options_off and self._is_option_like(tok):
                i = self._parse_option_token(args, i, occurrences, positional, child_args)
                continue
            # a positional token; after a positional, options may be switched off
            if self.stop_after is not None and len(positional) >= self.stop_after:
                if not self.mixing:
                    rest = args[i:]
                    break
                child_args.append(tok)
                i += 1
                continue
            positional.append(tok)
            if not self.interspersed:
                options_off = True
            i += 1
        return occurrences, positional, child_args, rest

    def _parse_option_token(self, args, i, occurrences, positional, child_args):
        tok = args[i]
        name, eq, attached = tok.partition("=")
        if name in self.table:
            opt, secondary = self.table[name]
            self._take(args, i, occurrences, opt, secondary,
                       attached if eq else None, has_eq=bool(eq))
            return self._next_index

        if len(tok) > 1 and tok[1] in self.prefixes:
            # unknown long option
            return self._unknown(tok, i, positional, child_args, args)

        # short option stack, e.g. "-abc" or "-n5"
        prefix = tok[0]
        j = 1
        while j < len(tok):
            key = prefix + tok[j]
            if key not in self.table:
                if self.ignore_unknown or self.mixing:
                    leftover = prefix + tok[j:]
                    if self.mixing and not self.ignore_unknown:
                        child_args.append(leftover)
                    else:
                        positional.append(leftover)
                    return i + 1
                raise NoSuchOption(key, message=f"No such option: {key}")
            opt, secondary = self.table[key]
            if opt.takes_value:
                attached = tok[j + 1:]
                self._take(args, i, occurrences, opt, secondary,
                           attached if attached else None, has_eq=False, short=True)
                return self._next_index
            self._take(args, i, occurrences, opt, secondary, None, has_eq=False, short=True)
            j += 1
        return i + 1

    def _unknown(self, tok, i, positional, child_args, args):
        if self.mixing and not self.ignore_unknown:
            child_args.append(tok)
            return i + 1
        if self.ignore_unknown:
            positional.append(tok)
            return i + 1
        raise NoSuchOption(tok.split("=", 1)[0])

    def _take(self, args, i, occurrences, opt, secondary, attached, has_eq, short=False):
        """Consume the value(s) of one option occurrence starting at ``args[i]``."""
        index = i
        nxt = i + 1
        if opt.is_flag:
            if has_eq and attached is not None and not short:
                raise UsageError(f"Option '{opt.opts[0]}' does not take a value.")
            occurrences.append(Occurrence(opt, KIND_VALUE, opt.flag_value_for(secondary), index))
            self._next_index = nxt
            return
        if opt.count:
            occurrences.append(Occurrence(opt, KIND_VALUE, 1, index))
            self._next_index = nxt
            return
        if opt.optional_value:
            if attached is not None:
                occurrences.append(Occurrence(opt, KIND_RAW, attached, index))
                self._next_index = nxt
            elif nxt < len(args) and not self._is_option_like(args[nxt]) and args[nxt] != "--":
                occurrences.append(Occurrence(opt, KIND_RAW, args[nxt], index))
                self._next_index = nxt + 1
            else:
                occurrences.append(Occurrence(opt, KIND_RAW, opt.flag_value, index))
                self._next_index = nxt
            return
        needed = opt.nargs
        if attached is not None and needed == 1:
            occurrences.append(Occurrence(opt, KIND_RAW, attached, index))
            self._next_index = nxt
            return
        values = []
        j = nxt
        if needed > 1 and attached is not None:
            values.append(attached)
        while len(values) < needed and j < len(args):
            if args[j] == "--" or (self._is_option_like(args[j]) and self._is_known_option(args[j])):
                break
            values.append(args[j])
            j += 1
        if len(values) < needed:
            if opt.prompt and needed == 1:
                occurrences.append(Occurrence(opt, KIND_PROMPT, None, index))
                self._next_index = j
                return
            raise UsageError(f"Option '{opt.opts[0]}' requires {needed} argument{'s' if needed != 1 else ''}.")
        if needed == 1:
            occurrences.append(Occurrence(opt, KIND_RAW, values[0], index))
        else:
            occurrences.append(Occurrence(opt, KIND_RAW, tuple(values), index))
        self._next_index = j
