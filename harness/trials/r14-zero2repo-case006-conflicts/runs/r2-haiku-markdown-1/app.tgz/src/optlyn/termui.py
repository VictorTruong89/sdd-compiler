"""Terminal helpers: echo, styling, prompts, pager, progress bars, and friends."""

import os
import re
import shlex
import subprocess
import sys
import tempfile
import time
from contextlib import contextmanager

_ANSI_RE = re.compile(r"\033\[[0-9;]*[A-Za-z]")

_COLORS = {
    "black": 30, "red": 31, "green": 32, "yellow": 33,
    "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "bright_black": 90, "bright_red": 91, "bright_green": 92,
    "bright_yellow": 93, "bright_blue": 94, "bright_magenta": 95,
    "bright_cyan": 96, "bright_white": 97,
}


def _ctx_color():
    from .core import get_current_context

    ctx = get_current_context(silent=True)
    return ctx.color if ctx is not None else None


def _is_tty(stream):
    try:
        return stream is not None and stream.isatty()
    except Exception:
        return False


def should_strip_ansi(stream=None, color=None):
    if color is None:
        color = _ctx_color()
    if color is not None:
        return not color
    return not _is_tty(stream)


def unstyle(text):
    """Remove ANSI escape sequences from ``text``."""
    return _ANSI_RE.sub("", text)


def _color_code(color, base):
    if color is None:
        return None
    if isinstance(color, str):
        if color == "reset":
            return None
        if color not in _COLORS:
            raise TypeError(f"Unknown color '{color}'.")
        code = _COLORS[color]
        return str(code + 10) if base == "bg" else str(code)
    if isinstance(color, bool):
        raise TypeError("Invalid color value.")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise TypeError(f"Color {color} is out of range 0-255.")
        return f"{'48' if base == 'bg' else '38'};5;{color}"
    if isinstance(color, (tuple, list)) and len(color) == 3:
        for c in color:
            if not isinstance(c, int) or not 0 <= c <= 255:
                raise TypeError(f"Invalid RGB color {color!r}.")
        return f"{'48' if base == 'bg' else '38'};2;{color[0]};{color[1]};{color[2]}"
    raise TypeError(f"Invalid color value {color!r}.")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None,
          overline=None, italic=None, blink=None, reverse=None,
          strikethrough=None, reset=True):
    """Wrap ``text`` in ANSI SGR sequences."""
    bits = []
    fgc = _color_code(fg, "fg")
    bgc = _color_code(bg, "bg")
    if fgc is not None:
        bits.append(fgc)
    if bgc is not None:
        bits.append(bgc)
    switches = [
        (bold, "1"), (dim, "2"), (italic, "3"), (underline, "4"),
        (blink, "5"), (reverse, "7"), (strikethrough, "9"), (overline, "53"),
    ]
    for flag, code in switches:
        if flag is not None:
            bits.append(code if flag else _OFF_CODES[code])
    if not bits:
        return text
    prefix = "\033[" + ";".join(bits) + "m"
    suffix = "\033[0m" if reset else ""
    return prefix + text + suffix


_OFF_CODES = {"1": "22", "2": "22", "3": "23", "4": "24", "5": "25",
              "7": "27", "9": "29", "53": "55"}


def _to_text(message):
    if message is None:
        return ""
    if isinstance(message, bytes):
        return message.decode("utf-8", errors="replace")
    return str(message)


def _write_text(stream, text):
    try:
        stream.write(text)
    except UnicodeEncodeError:
        enc = getattr(stream, "encoding", None) or "ascii"
        data = text.encode("utf-8")
        buffer = getattr(stream, "buffer", None)
        if buffer is not None:
            stream.flush()
            buffer.write(data)
        else:
            stream.write(data.decode(enc, errors="replace"))
    stream.flush()


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write ``message`` to stdout, stderr, or ``file``."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        buffer = getattr(file, "buffer", None)
        if buffer is not None:
            file.flush()
            buffer.write(message + (b"\n" if nl else b""))
            buffer.flush()
        else:
            file.write(message.decode("utf-8", errors="replace") + ("\n" if nl else ""))
        return
    text = _to_text(message)
    if should_strip_ansi(file, color):
        text = unstyle(text)
    if nl:
        text += "\n"
    _write_text(file, text)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None:
        message = style(_to_text(message), **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


def prompt(text, default=None, hide_input=False, confirmation_prompt=False,
           type=None, value_proc=None, prompt_suffix=": ", show_default=True,
           err=False, show_choices=True):
    """Ask for a value on stdin and return it converted with ``type``."""
    from .param_types import convert_type

    ptype = convert_type(type, default)
    dflt_text = None
    if default is not None and show_default:
        dflt_text = default() if callable(default) else default
        dflt_text = str(dflt_text)
    out = sys.stderr if err else sys.stdout
    while True:
        label = f"{text} [{dflt_text}]" if dflt_text is not None else text
        echo(f"{label}{prompt_suffix}", nl=False, file=out, err=err)
        value = _read_line(hide_input)
        if value is None:
            from .exceptions import Abort

            raise Abort()
        if value == "" and default is not None:
            value = default() if callable(default) else default
            if not isinstance(value, str):
                return value
        elif value == "" and default is None:
            continue
        if confirmation_prompt:
            echo(f"Repeat for confirmation{prompt_suffix}", nl=False, file=out, err=err)
            second = _read_line(hide_input)
            if second is None:
                from .exceptions import Abort

                raise Abort()
            if second != value:
                echo("Error: the two entered values do not match", file=out, err=err)
                continue
        try:
            return ptype.convert(value, None, None)
        except Exception as exc:
            echo(f"Error: {getattr(exc, 'message', exc)}", file=out, err=err)


def _read_line(hide_input=False):
    stream = sys.stdin
    if hide_input and _is_tty(stream):
        try:
            import getpass

            return getpass.getpass("")
        except EOFError:
            return None
    line = stream.readline()
    if line == "":
        return None
    return line.rstrip("\r\n")


def confirm(text, default=False, abort=False, prompt_suffix=": ",
            show_default=True, err=False):
    """Ask a yes/no question; return a bool. Abort on ``no`` if requested."""
    from .exceptions import Abort

    out = sys.stderr if err else sys.stdout
    if show_default:
        suffix = " [Y/n]" if default else " [y/N]"
    else:
        suffix = ""
    while True:
        echo(f"{text}{suffix}{prompt_suffix}", nl=False, file=out, err=err)
        answer = _read_line()
        if answer is None:
            raise Abort()
        answer = answer.strip().lower()
        if answer == "":
            result = default
            break
        if answer in ("y", "yes"):
            result = True
            break
        if answer in ("n", "no"):
            result = False
            break
        echo("Error: invalid input", file=out, err=err)
    if not result and abort:
        raise Abort()
    return result


def getchar(echo=False):
    """Read one character from the controlling terminal."""
    from .exceptions import Abort

    try:
        import termios
        import tty

        fd = os.open("/dev/tty", os.O_RDONLY)
        try:
            old = termios.tcgetattr(fd)
            try:
                tty.setraw(fd)
                ch = os.read(fd, 1).decode("utf-8", errors="replace")
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
        finally:
            os.close(fd)
    except OSError:
        ch = sys.stdin.read(1)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04" or ch == "":
        raise EOFError()
    if echo:
        echo(ch, nl=False)
    return ch


def pause(info=None, err=False):
    """Print a message and wait for a key when interactive; no-op otherwise."""
    if not (_is_tty(sys.stdin) and _is_tty(sys.stdout)):
        return
    if info is None:
        info = "Press any key to continue..."
    echo(info, nl=False, err=err)
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass
    echo("", err=err)


def clear():
    if _is_tty(sys.stdout):
        sys.stdout.write("\033[2J\033[H")
        sys.stdout.flush()


def echo_via_pager(text_or_generator, color=None):
    if callable(text_or_generator):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        chunks = [text_or_generator]
    else:
        chunks = text_or_generator
    if not _is_tty(sys.stdin) or not _is_tty(sys.stdout):
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    cmd = os.environ.get("PAGER", "less")
    proc = subprocess.Popen(shlex.split(cmd), stdin=subprocess.PIPE)
    try:
        for chunk in chunks:
            data = _to_text(chunk)
            if should_strip_ansi(None, color):
                data = unstyle(data)
            proc.stdin.write(data.encode("utf-8", errors="replace"))
            proc.stdin.flush()
    except BrokenPipeError:
        pass
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        proc.wait()


class _PagerWriter:
    def __init__(self, color=None):
        self.color = color
        self.parts = []

    def write(self, text):
        self.parts.append(text)
        return len(text)

    def flush(self):
        pass


@contextmanager
def get_pager_file(color=None):
    writer = _PagerWriter(color)
    yield writer
    echo_via_pager("".join(writer.parts), color=color)


class ProgressBar:
    """Iterable progress bar. Shows progress on a terminal, otherwise silent."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False,
                 **options):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label or ""
        self.pos = 0
        self.start = time.time()
        self.hidden = hidden or not _is_tty(sys.stdout)
        self.file = sys.stdout
        if self.label and not hidden and not _is_tty(sys.stdout):
            echo(self.label)

    def _render(self):
        if self.hidden:
            return
        if self.length:
            frac = min(self.pos / self.length, 1.0)
            filled = int(frac * 30)
            elapsed = time.time() - self.start
            eta = int(elapsed / self.pos * (self.length - self.pos)) if self.pos else 0
            bar = "#" * filled + "-" * (30 - filled)
            line = f"\r{self.label} [{bar}] {self.pos}/{self.length} eta {eta}s"
        else:
            line = f"\r{self.label} {self.pos}"
        self.file.write(line)
        self.file.flush()

    def update(self, n_steps, current_item=None):
        self.pos += n_steps
        self._render()

    def __iter__(self):
        if self.iterable is None:
            return
        for item in self.iterable:
            yield item
            self.update(1)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        if not self.hidden:
            self.file.write("\n")
            self.file.flush()
        return False


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    return ProgressBar(iterable, length=length, label=label, hidden=hidden, **options)


def edit(text=None, editor=None, env=None, require_save=True,
         extension=".txt", filename=None):
    """Open an editor on a file. Returns the saved text, or None."""
    editor = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR") or "vi"
    argv = shlex.split(editor)
    if filename is not None:
        subprocess.call(argv + [os.fspath(filename)], env=env)
        return None
    with tempfile.NamedTemporaryFile("w+", suffix=extension, delete=False,
                                     encoding="utf-8") as fh:
        if text:
            fh.write(text)
        path = fh.name
    try:
        before = open(path, encoding="utf-8").read()
        subprocess.call(argv + [path], env=env)
        with open(path, encoding="utf-8") as fh:
            after = fh.read()
        if require_save and after == before:
            return None
        return after
    finally:
        os.unlink(path)


def launch(url, wait=False, locate=False):
    if sys.platform == "darwin":
        argv = ["open"]
    elif sys.platform == "win32":
        os.startfile(url)  # type: ignore[attr-defined]
        return 0
    else:
        argv = ["xdg-open"]
    if locate and sys.platform == "darwin":
        argv.append("-R")
    argv.append(url)
    return subprocess.call(argv)


def get_app_dir(app_name, roaming=True, force_posix=False):
    if force_posix:
        return os.path.join(os.path.expanduser("~"), "." + app_name.lower().replace(" ", "-"))
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~"), "Library", "Application Support", app_name)
    if sys.platform == "win32":
        base = os.environ.get("APPDATA") or os.path.expanduser("~")
        return os.path.join(base, app_name)
    folder = re.sub(r"\s+", "-", app_name.lower())
    config = os.environ.get("XDG_CONFIG_HOME")
    if not config:
        config = os.path.join(os.path.expanduser("~"), ".config")
    return os.path.join(config, folder)


def format_filename(filename, shorten=False):
    if isinstance(filename, bytes):
        text = filename.decode("utf-8", errors="surrogateescape")
    else:
        text = os.fspath(filename)
    text = text.encode("utf-8", errors="surrogateescape").decode("utf-8", errors="backslashreplace")
    if shorten:
        text = os.path.basename(text)
    return text


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False,
              atomic=False):
    """Open a file; ``-`` means stdin for reading and stdout for writing."""
    from .param_types import open_stream

    return open_stream(filename, mode, encoding, errors, lazy, atomic)
