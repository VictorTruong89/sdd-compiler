"""Parameter types: built-in conversions, file and path types, and custom types."""

import datetime as _dt
import enum
import os
import sys
import tempfile
import uuid as _uuid

from .exceptions import BadParameter, FileError


class ParamType:
    """Base class for parameter types.

    Subclasses set ``name`` and implement :meth:`convert`. ``convert`` must
    accept ``param=None, ctx=None`` and refuse invalid input by raising
    :class:`BadParameter`.
    """

    name = "text"
    is_composite = False
    envvar_list_splitter = None

    def convert(self, value, param=None, ctx=None):
        return value

    def get_metavar(self, param):
        return None

    def get_missing_message(self, param):
        return None

    def shell_complete(self, ctx, param, incomplete):
        return []

    def split_envvar_value(self, rv):
        if self.envvar_list_splitter is not None:
            return rv.split(self.envvar_list_splitter)
        return rv.split()

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def __repr__(self):
        return self.name.upper()


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            try:
                return value.decode("utf-8")
            except UnicodeDecodeError:
                return value.decode("utf-8", errors="replace")
        if isinstance(value, str):
            return value
        return str(value)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            return int(str(value).strip(), 10)
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        if isinstance(value, int) and not isinstance(value, bool):
            return float(value)
        try:
            return float(str(value).strip())
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value).strip())
        except (ValueError, TypeError, AttributeError):
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()


class Choice(ParamType):
    """A closed list of allowed values, or the members of an Enum class."""

    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.enum_cls = choices
            self.choices = list(choices)
            self._tokens = [m.name for m in choices]
        else:
            self.enum_cls = None
            self.choices = list(choices)
            self._tokens = [str(c) for c in self.choices]
        self.case_sensitive = case_sensitive

    def get_metavar(self, param):
        return "[" + "|".join(self._tokens) + "]"

    def _normalize(self, text):
        return text if self.case_sensitive else text.casefold()

    def convert(self, value, param=None, ctx=None):
        for choice, token in zip(self.choices, self._tokens):
            if value is choice or (self.enum_cls is None and value == choice):
                return choice
        text = value if isinstance(value, str) else str(value)
        if ctx is not None and getattr(ctx, "token_normalize_func", None):
            text = ctx.token_normalize_func(text)
        norm = self._normalize(text)
        for choice, token in zip(self.choices, self._tokens):
            if self._normalize(token) == norm:
                return choice
        shown = ", ".join(f"'{t}'" for t in self._tokens)
        self.fail(f"{value!r} is not {shown}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        return [CompletionItem(t) for t in self._tokens if t.startswith(incomplete)]


_DEFAULT_DT_FORMATS = ["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(_DEFAULT_DT_FORMATS)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        text = str(value).strip()
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(text, fmt)
            except ValueError:
                continue
        shown = ", ".join(repr(f) for f in self.formats)
        self.fail(f"{value!r} does not match the formats {shown}.", param, ctx)


class _RangeMixin:
    def _check_range(self, value, param, ctx):
        lo, hi = self.min, self.max
        if lo is not None:
            if self.min_open and value <= lo:
                if self.clamp:
                    return self._adjacent(lo, +1)
                self.fail(f"{value!r} is not in the range {self._range_text()}.", param, ctx)
            if not self.min_open and value < lo:
                if self.clamp:
                    return lo
                self.fail(f"{value!r} is not in the range {self._range_text()}.", param, ctx)
        if hi is not None:
            if self.max_open and value >= hi:
                if self.clamp:
                    return self._adjacent(hi, -1)
                self.fail(f"{value!r} is not in the range {self._range_text()}.", param, ctx)
            if not self.max_open and value > hi:
                if self.clamp:
                    return hi
                self.fail(f"{value!r} is not in the range {self._range_text()}.", param, ctx)
        return value

    def _range_text(self):
        lo = "-inf" if self.min is None else self.min
        hi = "inf" if self.max is None else self.max
        lb = "(" if self.min_open else "["
        rb = ")" if self.max_open else "]"
        return f"{lb}{lo}, {hi}{rb}"


class IntRange(_RangeMixin, IntParamType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min, self.max = min, max
        self.min_open, self.max_open = min_open, max_open
        self.clamp = clamp

    def _adjacent(self, bound, direction):
        return bound + direction

    def convert(self, value, param=None, ctx=None):
        value = IntParamType.convert(self, value, param, ctx)
        return self._check_range(value, param, ctx)


class FloatRange(_RangeMixin, FloatParamType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min_open or max_open):
            raise ValueError("Clamping is not supported for open bounds.")
        if min is not None and max is not None and min > max:
            raise ValueError("The minimum bound is above the maximum bound.")
        self.min, self.max = min, max
        self.min_open, self.max_open = min_open, max_open
        self.clamp = clamp

    def _adjacent(self, bound, direction):
        return bound  # unreachable: clamp is refused with open bounds

    def convert(self, value, param=None, ctx=None):
        value = FloatParamType.convert(self, value, param, ctx)
        return self._check_range(value, param, ctx)


class Tuple(ParamType):
    name = "tuple"
    is_composite = True

    def __init__(self, types):
        self.types = [convert_type(t) for t in types]

    @property
    def arity(self):
        return len(self.types)

    def convert(self, value, param=None, ctx=None):
        if not isinstance(value, (tuple, list)) or len(value) != len(self.types):
            self.fail(f"{value!r} must be a sequence of {len(self.types)} items.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))


class _NonClosing:
    """Wraps a standard stream; closing the wrapper does not close the stream."""

    def __init__(self, stream):
        object.__setattr__(self, "_stream", stream)

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def __iter__(self):
        return iter(self._stream)


class LazyFile:
    """A file that opens on first I/O. Closing it before any I/O is a no-op."""

    def __init__(self, filename, mode, encoding, errors, atomic):
        self._filename = filename
        self._mode = mode
        self._encoding = encoding
        self._errors = errors
        self._atomic = atomic
        self._fh = None
        self._tmp = None

    def _open(self):
        if self._fh is not None:
            return self._fh
        binary = "b" in self._mode
        kwargs = {} if binary else {"encoding": self._encoding, "errors": self._errors}
        try:
            if self._atomic:
                directory = os.path.dirname(os.path.abspath(self._filename))
                fd, self._tmp = tempfile.mkstemp(dir=directory, prefix=".optlyn-")
                os.close(fd)
                self._fh = open(self._tmp, self._mode, **kwargs)
            else:
                self._fh = open(self._filename, self._mode, **kwargs)
        except OSError as exc:
            raise FileError(self._filename, f"Could not open file '{self._filename}': {exc.strerror}")
        return self._fh

    def __getattr__(self, name):
        return getattr(self._open(), name)

    def write(self, data):
        return self._open().write(data)

    def read(self, *args):
        return self._open().read(*args)

    def close(self):
        if self._fh is None:
            return
        self._fh.close()
        if self._atomic and self._tmp is not None:
            os.replace(self._tmp, self._filename)
            self._tmp = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False


def open_stream(filename, mode="r", encoding=None, errors="strict", lazy=False,
                atomic=False):
    """Open ``filename`` (``-`` for stdin/stdout). Raises FileError on failure."""
    binary = "b" in mode
    writing = "w" in mode
    if filename == "-":
        if writing:
            stream = sys.stdout.buffer if binary else sys.stdout
        else:
            stream = sys.stdin.buffer if binary else sys.stdin
        return _NonClosing(stream)
    if lazy or (atomic and writing):
        handle = LazyFile(filename, mode, encoding, errors, atomic)
        if not lazy:
            handle._open()
        return handle
    kwargs = {} if binary else {"encoding": encoding, "errors": errors}
    try:
        return open(filename, mode, **kwargs)
    except OSError as exc:
        raise FileError(filename, f"Could not open file '{filename}': {exc.strerror}")


class File(ParamType):
    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"Unsupported file mode {mode!r}.")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    @property
    def _is_lazy(self):
        if self.lazy is not None:
            return self.lazy
        return "w" in self.mode

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        lazy = self._is_lazy
        try:
            fh = open_stream(value, self.mode, self.encoding, self.errors, lazy, self.atomic)
        except FileError as exc:
            self.fail(f"'{value}': could not be opened.", param, ctx)
        if ctx is not None and hasattr(fh, "close") and value != "-":
            ctx.call_on_close(fh.close)
        return fh


class Path(ParamType):
    name = "path"

    def __init__(self, exists=False, file_okay=True, dir_okay=True, writable=False,
                 readable=True, resolve_path=False, allow_dash=False, path_type=None,
                 executable=False):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def convert(self, value, param=None, ctx=None):
        rv = os.fspath(value) if not isinstance(value, bytes) else os.fsdecode(value)
        is_dash = self.file_okay and self.allow_dash and rv == "-"
        if not is_dash:
            if self.resolve_path:
                rv = os.path.realpath(rv)
            exists = os.path.exists(rv)
            if not exists:
                if self.exists:
                    self.fail(f"'{rv}' does not exist.", param, ctx)
            else:
                if not self.file_okay and os.path.isfile(rv):
                    self.fail(f"'{rv}' is a file.", param, ctx)
                if not self.dir_okay and os.path.isdir(rv):
                    self.fail(f"'{rv}' is a directory.", param, ctx)
                if self.readable and not os.access(rv, os.R_OK):
                    self.fail(f"'{rv}' is not readable.", param, ctx)
                if self.writable and not os.access(rv, os.W_OK):
                    self.fail(f"'{rv}' is not writable.", param, ctx)
                if self.executable and not os.access(rv, os.X_OK):
                    self.fail(f"'{rv}' is not executable.", param, ctx)
        if self.path_type is None or self.path_type is str:
            return rv
        if self.path_type is bytes:
            return os.fsencode(rv)
        return self.path_type(rv)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        kind = "dir" if (self.dir_okay and not self.file_okay) else "file"
        return [CompletionItem(incomplete, type="dir" if kind == "dir" else "file")]


class FunctionParamType(ParamType):
    """Adapter for a conversion function ``f(token) -> value``."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text")

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except ValueError as exc:
            self.fail(str(exc) or f"{value!r} is not valid.", param, ctx)


_PY_TYPES = {str: STRING, int: INT, float: FLOAT, bool: BOOL, _uuid.UUID: UUID}


def convert_type(ty, default=None):
    """Resolve a ``type=`` spec (or infer one from ``default``) to a ParamType."""
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    if ty is not None:
        if isinstance(ty, (tuple, list)):
            return Tuple(ty)
        if ty in _PY_TYPES:
            return _PY_TYPES[ty]
        if callable(ty):
            return FunctionParamType(ty)
        raise TypeError(f"Unsupported parameter type {ty!r}.")
    if isinstance(default, bool):
        return BOOL
    if isinstance(default, int):
        return INT
    if isinstance(default, float):
        return FLOAT
    if isinstance(default, (list, tuple)) and default:
        return convert_type(None, default[0])
    if isinstance(default, enum.Enum):
        return Choice(type(default))
    return STRING
