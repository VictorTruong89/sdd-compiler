"""Declaration decorators: command, group, option, argument and friends."""

from functools import update_wrapper

from . import termui
from .core import (Argument, Command, Group, Option, _make_help_option,
                   get_current_context)
from .exceptions import DeclarationError

_SUFFIXES = ("_command", "_cmd", "_group", "_grp")


def _param_memo(f, param):
    if not hasattr(f, "__optlyn_params__"):
        f.__optlyn_params__ = []
    f.__optlyn_params__.append(param)


def _pop_params(f):
    params = f.__dict__.pop("__optlyn_params__", [])
    params.reverse()
    return params


def _derive_name(func_name):
    name = func_name.lower()
    for suffix in _SUFFIXES:
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def command(name=None, cls=None, **attrs):
    """Turn a function into a :class:`Command`. Usable bare or with arguments."""
    if callable(name) and not isinstance(name, str):
        return command(None, cls, **attrs)(name)

    def decorator(f):
        cmd_name = name if name is not None else _derive_name(f.__name__)
        params = _pop_params(f)
        return (cls or Command)(name=cmd_name, callback=f, params=params, **attrs)

    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a :class:`Group`. Usable bare or with arguments."""
    if callable(name) and not isinstance(name, str):
        return group(None, cls, **attrs)(name)

    def decorator(f):
        grp_name = name if name is not None else _derive_name(f.__name__)
        params = _pop_params(f)
        return (cls or Group)(name=grp_name, callback=f, params=params, **attrs)

    return decorator


def option(*param_decls, cls=None, **attrs):
    def decorator(f):
        _param_memo(f, (cls or Option)(list(param_decls), **attrs))
        return f

    return decorator


def argument(*param_decls, cls=None, **attrs):
    def decorator(f):
        _param_memo(f, (cls or Argument)(list(param_decls), **attrs))
        return f

    return decorator


def _attach(opt):
    def decorator(f):
        _param_memo(f, opt)
        return f

    return decorator


def help_option(*param_decls, **kwargs):
    """An extra eager flag that prints help and exits."""
    names = list(param_decls) or ["--help"]
    return _attach(_make_help_option(names))


def _detect_version(package_name):
    from importlib import metadata

    try:
        return metadata.version(package_name)
    except metadata.PackageNotFoundError:
        pass
    try:
        dists = metadata.packages_distributions().get(package_name)
        if dists:
            return metadata.version(dists[0])
    except Exception:
        pass
    raise RuntimeError(f"Could not detect the version of {package_name!r}.")


def version_option(version=None, *param_decls, package_name=None, prog_name=None,
                   message=None, **kwargs):
    decls = list(param_decls) or ["--version"]

    def callback(ctx, param, value):
        if not value or ctx is None:
            return
        ver = version
        if ver is None:
            ver = _detect_version(package_name or ctx.find_root().info_name)
        prog = prog_name or ctx.find_root().info_name
        text = message or "%(prog)s, version %(version)s"
        text = text.replace("%(prog)s", str(prog)).replace("%(version)s", str(ver))
        termui.echo(text, color=ctx.color)
        ctx.exit()

    attrs = dict(is_flag=True, is_eager=True, expose_value=False,
                 callback=callback, help="Show the version and exit.")
    attrs.update(kwargs)
    return _attach(Option(decls, **attrs))


def custom_version_option(callback, *param_decls, **kwargs):
    decls = list(param_decls) or ["--version"]

    def wrapped(ctx, param, value):
        if not value or ctx is None:
            return
        termui.echo(callback(ctx), color=ctx.color)
        ctx.exit()

    attrs = dict(is_flag=True, is_eager=True, expose_value=False,
                 callback=wrapped, help="Show the version and exit.")
    attrs.update(kwargs)
    return _attach(Option(decls, **attrs))


def password_option(*param_decls, **kwargs):
    decls = list(param_decls) or ["--password"]
    attrs = dict(prompt=True, hide_input=True, confirmation_prompt=True)
    attrs.update(kwargs)
    return _attach(Option(decls, **attrs))


def confirmation_option(*param_decls, **kwargs):
    decls = list(param_decls) or ["--yes"]
    question = kwargs.pop("prompt", "Do you want to continue?")

    def callback(ctx, param, value):
        if not value and ctx is not None:
            termui.confirm(question, default=False, abort=True)
        return value

    attrs = dict(is_flag=True, expose_value=False, callback=callback,
                 help="Confirm the action without prompting.")
    attrs.update(kwargs)
    return _attach(Option(decls, **attrs))


def pass_context(f):
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return update_wrapper(new_func, f)


def pass_obj(f):
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return update_wrapper(new_func, f)


def make_pass_decorator(object_type, ensure=False):
    def decorator(f):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(
                    f"Managed to invoke callback without a context object of type "
                    f"{object_type.__name__!r} existing.")
            return f(obj, *args, **kwargs)

        return update_wrapper(new_func, f)

    return decorator
