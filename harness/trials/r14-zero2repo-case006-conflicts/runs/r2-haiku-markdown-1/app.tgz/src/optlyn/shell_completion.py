"""Shell completion: registration scripts and suggestion output."""

import os
import sys

SHELLS = ("bash", "zsh", "fish", "powershell")


class CompletionItem:
    """One suggestion. ``type`` is ``plain`` for values, ``file``/``dir`` for path requests."""

    def __init__(self, value, help=None, type="plain"):
        self.value = value
        self.help = help
        self.type = type

    def __repr__(self):
        return f"CompletionItem({self.value!r}, help={self.help!r}, type={self.type!r})"


def complete_var_name(prog_name):
    return "_" + prog_name.upper().replace("-", "_") + "_COMPLETE"


def handle_completion_env(cli, prog_name, complete_var=None):
    """Handle the completion instruction in the environment.

    Returns ``(handled, status)``. ``handled`` is False when no completion
    instruction is present, so the command should run normally.
    """
    var = complete_var or complete_var_name(prog_name)
    instruction = os.environ.get(var)
    if not instruction:
        return False, 0
    shell, _, mode = instruction.rpartition("_")
    if shell not in SHELLS or mode not in ("source", "complete"):
        # An unrecognised instruction prints nothing and is not a success.
        return True, 1
    if mode == "source":
        sys.stdout.write(_SCRIPTS[shell](prog_name, var) + "\n")
        sys.stdout.flush()
        return True, 0
    items = _suggest(cli, prog_name, shell)
    lines = []
    for item in items:
        line = f"{item.type},{item.value}"
        if shell in ("zsh", "fish") and item.help:
            line += "\t" + item.help.replace("\n", " ")
        lines.append(line)
    if lines:
        sys.stdout.write("\n".join(lines) + "\n")
    sys.stdout.flush()
    return True, 0


def _suggest(cli, prog_name, shell):
    from .core import Context

    words_raw = os.environ.get("COMP_WORDS", "")
    cword_raw = os.environ.get("COMP_CWORD", "0")
    words = words_raw.split(" ")
    if shell == "fish":
        incomplete = cword_raw
        if words and words[-1] == incomplete:
            words = words[:-1]
        args = words[1:]
    else:
        try:
            cword = int(cword_raw)
        except ValueError:
            cword = len(words)
        args = words[1:cword]
        incomplete = words[cword] if cword < len(words) else ""
    root = Context(cli, info_name=prog_name)
    return complete_tokens(cli, root, args, incomplete)


def _visible_commands(ctx, group):
    out = []
    for name in group.list_commands(ctx):
        child = group.get_command(ctx, name)
        if child is not None and not child.hidden:
            out.append((name, child))
    return out


def _normalize(item):
    if isinstance(item, CompletionItem):
        return item
    if isinstance(item, str):
        return CompletionItem(item)
    return CompletionItem(item.value, getattr(item, "help", None),
                          getattr(item, "type", "plain") or "plain")


def _find_option(cmd, tok):
    from .core import Option

    name = tok.split("=", 1)[0]
    for p in cmd.params:
        if isinstance(p, Option) and not p.hidden:
            if name in p.opts or name in p.secondary_opts:
                return p
    return None


def _value_items(ctx, param, incomplete):
    from .param_types import File

    if param.shell_complete is not None:
        return [_normalize(i) for i in param.shell_complete(ctx, param, incomplete)]
    ptype = param.type
    if isinstance(ptype, File):
        return [CompletionItem(incomplete, type="file")]
    return [_normalize(i) for i in ptype.shell_complete(ctx, param, incomplete)]


def complete_tokens(cli, root, args, incomplete):
    from .core import Argument, Context, Group, Option

    ctx = root
    cmd = cli
    positional = 0
    pending = None
    options_ended = False
    for tok in args:
        if pending is not None:
            pending = None
            continue
        if not options_ended and tok == "--":
            options_ended = True
            continue
        if not options_ended and tok.startswith("-") and len(tok) > 1:
            opt = _find_option(cmd, tok)
            if opt is not None and opt.takes_value and "=" not in tok:
                pending = opt
            continue
        if isinstance(cmd, Group):
            arg_count = sum(1 for p in cmd.params if isinstance(p, Argument))
            if positional >= arg_count:
                child = cmd.get_command(ctx, tok)
                if child is not None:
                    ctx = Context(child, parent=ctx, info_name=tok)
                    cmd = child
                    positional = 0
                    continue
        positional += 1

    if pending is not None:
        return _value_items(ctx, pending, incomplete)
    if incomplete.startswith("-"):
        items = []
        for p in cmd.params:
            if isinstance(p, Option) and not p.hidden:
                for decl in p.opts + p.secondary_opts:
                    if decl.startswith(incomplete):
                        items.append(CompletionItem(decl, p.help))
        help_opt = cmd.get_help_option(ctx)
        if help_opt is not None:
            for decl in help_opt.opts:
                if decl.startswith(incomplete):
                    items.append(CompletionItem(decl, help_opt.help))
        return items

    items = []
    if isinstance(cmd, Group):
        for name, child in _visible_commands(ctx, cmd):
            if name.startswith(incomplete):
                items.append(CompletionItem(name, child.get_short_help()))
    arguments = [p for p in cmd.params if isinstance(p, Argument)]
    if positional < len(arguments):
        arg = arguments[positional]
        items.extend(_value_items(ctx, arg, incomplete))
    return items


# ---------------------------------------------------------------------------
# Registration scripts
# ---------------------------------------------------------------------------

def _func_name(prog):
    return "_" + prog.replace("-", "_").replace(".", "_") + "_completion"


def _bash_script(prog, var):
    func = _func_name(prog)
    return f"""{func}() {{
    local IFS=$'\\n'
    local response
    response=$(env COMP_WORDS="${{COMP_WORDS[*]}}" COMP_CWORD=$COMP_CWORD {var}=bash_complete $1)
    for completion in $response; do
        IFS=',' read type value <<< "$completion"
        if [[ $type == 'dir' ]]; then
            COMPREPLY=()
            compopt -o dirnames
        elif [[ $type == 'file' ]]; then
            COMPREPLY=()
            compopt -o default
        elif [[ $type == 'plain' ]]; then
            COMPREPLY+=("$value")
        fi
    done
    return 0
}}

complete -o nosort -F {func} {prog}"""


def _zsh_script(prog, var):
    func = _func_name(prog)
    return f"""#compdef {prog}

{func}() {{
    local -a response completions
    local item type value
    response=("${{(@f)$(env COMP_WORDS="${{words[*]}}" COMP_CWORD=$((CURRENT-1)) {var}=zsh_complete {prog})}}")
    for item in "${{response[@]}}"; do
        type="${{item%%,*}}"
        value="${{item#*,}}"
        if [[ $type == 'dir' ]]; then
            _path_files -/
        elif [[ $type == 'file' ]]; then
            _files
        elif [[ $type == 'plain' ]]; then
            completions+=("${{value//:/\\\\:}}")
        fi
    done
    if (( ${{#completions}} )); then
        _describe 'values' completions
    fi
}}

compdef {func} {prog}"""


def _fish_script(prog, var):
    func = _func_name(prog)
    return f"""function {func}
    set -l response (env COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -ct) {var}=fish_complete {prog})
    for completion in $response
        set -l metadata (string split -m 1 "," $completion)
        if test $metadata[1] = "dir"
            __fish_complete_directories $metadata[2]
        else if test $metadata[1] = "file"
            __fish_complete_path $metadata[2]
        else if test $metadata[1] = "plain"
            echo $metadata[2]
        end
    end
end

complete --no-files --command {prog} --arguments "({func})"
"""


def _powershell_script(prog, var):
    return f"""Import-Module PSReadLine
Register-ArgumentCompleter -Native -CommandName '{prog}' -ScriptBlock {{
    param($wordToComplete, $commandAst, $cursorPosition)
    $words = $commandAst.CommandElements | ForEach-Object {{ $_.ToString() }}
    $cword = $words.Count
    if ($wordToComplete -eq '') {{ $cword = $words.Count }} else {{ $cword = $words.Count - 1 }}
    $env:COMP_WORDS = $words -join ' '
    $env:COMP_CWORD = $cword
    $env:{var} = 'powershell_complete'
    & '{prog}' | ForEach-Object {{
        $type, $value = $_ -split ',', 2
        if ($type -eq 'plain') {{
            [System.Management.Automation.CompletionResult]::new($value, $value, 'ParameterValue', $value)
        }}
    }}
    Remove-Item Env:\\{var} -ErrorAction SilentlyContinue
}}"""


_SCRIPTS = {
    "bash": _bash_script,
    "zsh": _zsh_script,
    "fish": _fish_script,
    "powershell": _powershell_script,
}
