"""In-process runner: invoke a command with tokens and capture its output."""

import contextlib
import io
import os
import shutil
import sys
import tempfile


class _Tee(io.BytesIO):
    """A byte buffer that also appends each write to a shared, ordered log."""

    def __init__(self, name, log):
        super().__init__()
        self._name = name
        self._log = log

    def write(self, data):
        self._log.append((self._name, bytes(data)))
        return super().write(data)


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, exit_code,
                 exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self):
        return self.output_bytes.decode(self.runner.charset, errors="replace")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self.runner.charset, errors="replace")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self.runner.charset, errors="replace")

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False,
                 catch_exceptions=True, capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        if isinstance(input, str):
            input_bytes = input.encode(self.charset)
        else:
            input_bytes = input or b""
        log = []
        stdout_buf = _Tee("stdout", log)
        stderr_buf = _Tee("stderr", log)
        stdout = io.TextIOWrapper(stdout_buf, encoding=self.charset,
                                  errors="replace", write_through=True)
        stderr = io.TextIOWrapper(stderr_buf, encoding=self.charset,
                                  errors="replace", write_through=True)
        stdin = io.TextIOWrapper(io.BytesIO(input_bytes), encoding=self.charset)

        merged_env = dict(self.env)
        merged_env.update(env or {})
        old_env = {}
        for key, value in merged_env.items():
            old_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)

        old_streams = (sys.stdin, sys.stdout, sys.stderr)
        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
        try:
            yield (stdout_buf, stderr_buf, log)
        finally:
            stdout.flush()
            stderr.flush()
            sys.stdin, sys.stdout, sys.stderr = old_streams
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None,
               color=False, **extra):
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if args is None:
            args = []
        elif isinstance(args, str):
            import shlex

            args = shlex.split(args)
        prog_name = extra.pop("prog_name", None) or getattr(cli, "name", None) or "main"
        standalone = extra.pop("standalone_mode", True)
        extra.setdefault("color", color)

        exit_code = 0
        exception = None
        exc_info = None
        with self.isolation(input=input, env=env, color=color) as (out_buf, err_buf, log):
            try:
                cli.main(args=list(args), prog_name=prog_name,
                         standalone_mode=standalone, **extra)
            except SystemExit as e:
                if e.code is None:
                    exit_code = 0
                elif isinstance(e.code, int):
                    exit_code = e.code
                else:
                    sys.stderr.write(str(e.code) + "\n")
                    exit_code = 1
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exc_info = sys.exc_info()
                exit_code = 1
            finally:
                sys.stdout.flush()
                sys.stderr.flush()
            stdout_bytes = out_buf.getvalue()
            stderr_bytes = err_buf.getvalue()
            output_bytes = b"".join(chunk for _, chunk in log)
        return Result(self, stdout_bytes, stderr_bytes, output_bytes, exit_code,
                      exception, exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        if temp_dir is None:
            path = tempfile.mkdtemp()
            cleanup = True
        else:
            path = tempfile.mkdtemp(dir=temp_dir)
            cleanup = False
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if cleanup:
                shutil.rmtree(path, ignore_errors=True)
