"""More behaviour tests: eager flags, prompts, completion, terminal helpers, runner modes."""
import io
import os
import sys

import pytest

import optlyn as o
from optlyn import testing
from optlyn.shell_completion import suggest
from optlyn.param_types import PathRequest

CliRunner = testing.CliRunner


def invoke(cmd, args, **kwargs):
    return CliRunner().invoke(cmd, args, prog_name=kwargs.pop("prog_name", "tool"), **kwargs)


def test_N000157_eager_flags_first_typed_wins():
    @o.command()
    @o.version_option("1.2", prog_name="t")
    @o.option("--flag", is_flag=True)
    def cmd(flag):
        o.echo("body")

    assert invoke(cmd, ["--version", "--help"]).stdout == "t, version 1.2\n"
    res = invoke(cmd, ["--help", "--version"])
    assert res.exit_code == 0 and res.stdout.startswith("Usage:")
    assert "t, version 1.2" not in res.stdout


def test_N000116_eager_flag_skips_required_missing():
    @o.command()
    @o.version_option("3", prog_name="t")
    @o.option("--must", required=True)
    def cmd(must):
        pass

    res = invoke(cmd, ["--version"])
    assert res.exit_code == 0 and res.stdout == "t, version 3\n"


def test_N000480_prompt_required_false_only_on_flag_without_value():
    @o.command()
    @o.option("--secret", prompt=True, prompt_required=False, is_flag=False, flag_value="x")
    def cmd(secret):
        o.echo(str(secret))

    assert invoke(cmd, []).stdout == "None\n"
    res = CliRunner().invoke(cmd, ["--secret"], prog_name="t", input="typed\n")
    assert res.stdout.rstrip().endswith("typed")


def test_N000487_default_prompts_and_empty_answer_uses_default():
    @o.command()
    @o.option("--name", prompt=True, default="anon")
    def cmd(name):
        o.echo(name)

    res = CliRunner().invoke(cmd, [], prog_name="t", input="\n")
    assert res.exit_code == 0 and res.stdout.rstrip().endswith("anon")


def test_N000510_prompt_reasks_on_conversion_failure():
    @o.command()
    @o.option("--n", type=int, prompt=True)
    def cmd(n):
        o.echo(str(n))

    res = CliRunner().invoke(cmd, [], prog_name="t", input="abc\n12\n")
    assert res.exit_code == 0 and res.stdout.rstrip().endswith("12")


def test_N000434_auto_prefix_nested_path(monkeypatch):
    @o.group(context_settings={"auto_envvar_prefix": "APP"})
    def top():
        pass

    @top.group()
    def mid():
        pass

    @mid.command()
    @o.option("--port", type=int, default=1)
    def serve(port):
        o.echo(str(port))

    monkeypatch.setenv("APP_MID_SERVE_PORT", "8080")
    assert CliRunner().invoke(top, ["mid", "serve"], prog_name="top").stdout == "8080\n"


def test_N000441_source_is_default_map_and_env():
    @o.command()
    @o.option("--a", envvar="SRC_A")
    @o.option("--b")
    @o.pass_context
    def cmd(ctx, a, b):
        o.echo(str(ctx.get_parameter_source("a")))
        o.echo(str(ctx.get_parameter_source("b")))

    res = CliRunner().invoke(cmd, [], prog_name="t", env={"SRC_A": "x"},
                             default_map={"b": "m"})
    assert res.stdout.splitlines() == ["ParameterSource.ENVIRONMENT",
                                       "ParameterSource.DEFAULT_MAP"]


def test_N000459_token_normalize_func_applies_to_choices():
    @o.command()
    @o.option("--c", type=o.Choice(["Alpha"]))
    def cmd(c):
        o.echo(c)

    res = CliRunner().invoke(cmd, ["--c", "ALPHA"], prog_name="t",
                             token_normalize_func=str.lower)
    assert res.stdout == "Alpha\n"


def test_N000461_invoke_and_forward_between_commands():
    @o.command()
    @o.option("--x", default=1)
    def target(x):
        o.echo(f"target x={x}")

    @o.command()
    @o.option("--x", default=5)
    @o.pass_context
    def caller(ctx, x):
        ctx.invoke(target, x=9)
        ctx.forward(target)

    assert invoke(caller, ["--x", "2"]).stdout == "target x=9\ntarget x=2\n"


def test_N000470_color_forced_on_keeps_styles():
    @o.command()
    def cmd():
        o.echo(o.style("hi", fg="blue"))

    assert "\x1b[" in CliRunner().invoke(cmd, [], prog_name="t", color=True).stdout
    assert "\x1b[" not in CliRunner().invoke(cmd, [], prog_name="t", color=False).stdout


def test_N000644_echo_ascii_stream_writes_utf8(monkeypatch):
    buf = io.BytesIO()
    stream = io.TextIOWrapper(buf, encoding="ascii", write_through=True)
    o.echo("café", file=stream)
    stream.flush()
    assert buf.getvalue() == "café\n".encode("utf-8")


def test_N000980_pager_uses_pager_env_when_interactive(monkeypatch):
    calls = []
    monkeypatch.setenv("PAGER", "cat")
    monkeypatch.setattr("optlyn.termui.is_interactive", lambda: True)

    class FakeProc:
        def __init__(self, args, stdin=None, text=None):
            calls.append(args)
            self.stdin = io.StringIO()

        def wait(self):
            return 0

    monkeypatch.setattr("optlyn.termui.subprocess.Popen", FakeProc)
    o.echo_via_pager(["one\n", "two\n"])
    assert calls == [["cat"]]


def test_N000652_pause_noop_when_not_interactive(monkeypatch):
    monkeypatch.setattr("optlyn.termui.is_interactive", lambda: False)
    o.pause()  # must return without reading input


def test_N000663_clear_writes_nothing_without_tty():
    @o.command()
    def cmd():
        o.clear()

    assert invoke(cmd, []).stdout == ""


def test_N000657_launch_uses_opener_with_url(monkeypatch):
    seen = []

    class FakeProc:
        def __init__(self, args):
            seen.append(args)

        def wait(self):
            return 0

    monkeypatch.setattr("optlyn.termui.subprocess.Popen", FakeProc)
    monkeypatch.setattr("optlyn.termui.sys.platform", "linux")
    assert o.launch("https://example.com") == 0
    assert seen and seen[0][-1] == "https://example.com"


def test_N000664_get_app_dir_darwin(monkeypatch, tmp_path):
    monkeypatch.setattr("sys.platform", "darwin")
    from optlyn.utils import get_app_dir

    assert get_app_dir("Tool X").endswith(os.path.join("Library", "Application Support",
                                                      "Tool X"))


def test_N000729_open_file_dash_and_helper(tmp_path):
    from optlyn.utils import open_file

    path = tmp_path / "f.txt"
    with open_file(str(path), "w") as handle:
        handle.write("data")
    with open_file(str(path)) as handle:
        assert handle.read() == "data"


def test_N000558_path_dash_when_not_allowed_is_ordinary_file(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    (tmp_path / "-").write_text("x")

    @o.command()
    @o.argument("p", type=o.Path(exists=True))
    def cmd(p):
        o.echo(p)

    assert invoke(cmd, ["-"]).stdout == "-\n"


def test_N000696_choice_completion_values_match_prefix():
    @o.group()
    def cli():
        pass

    @cli.command()
    @o.option("--color", type=o.Choice(["red", "green", "blue"]))
    def paint(color):
        pass

    items = suggest(cli, "t", ["paint", "--color"], "gr")
    assert [i.value for i in items] == ["green"]


def test_N000688_hidden_options_never_suggested():
    @o.command()
    @o.option("--public")
    @o.option("--private", hidden=True)
    def cmd(public, private):
        pass

    values = [i.value for i in suggest(cmd, "t", [], "--")]
    assert "--public" in values and "--private" not in values


def test_N000689_file_argument_yields_path_request():
    @o.command()
    @o.argument("f", type=o.File("r"))
    def cmd(f):
        pass

    items = suggest(cmd, "t", [], "sr")
    assert isinstance(items[0], PathRequest) and items[0].kind == "file"
    assert items[0].incomplete == "sr"


def test_N000694_completion_function_replaces_type_completion():
    def comp(ctx, param, incomplete):
        return [o.ParamType and "alpha", "beta"]

    @o.command()
    @o.option("--x", shell_complete=comp)
    def cmd(x):
        pass

    assert [i.value for i in suggest(cmd, "t", ["--x"], "")] == ["alpha", "beta"]


def test_N000250_parameter_sees_earlier_values_through_context():
    @o.command()
    @o.option("--a", default="A")
    @o.option("--b", default=None)
    @o.pass_context
    def cmd(ctx, a, b):
        o.echo(f"{ctx.params['a']}")

    assert invoke(cmd, []).stdout == "A\n"


def test_N000107_docstring_becomes_description_when_no_help():
    @o.command()
    def documented():
        """Describe me please."""

    assert "Describe me please." in invoke(documented, ["--help"]).stdout


def test_N000459_choice_case_insensitive_matches_first_registered():
    choice = o.Choice(["Yes", "yes"], case_sensitive=False)
    assert choice.convert("YES", None, None) == "Yes"


def test_N000402_nested_group_no_args_shows_nested_help_after_outer_callbacks():
    order = []

    @o.group()
    def outer():
        order.append("outer")

    @outer.group()
    def inner():
        """Inner group help."""
        order.append("inner")

    res = invoke(outer, ["inner"])
    assert res.exit_code == 2
    assert order == ["outer"]
    assert "Inner group help." in res.stderr


def test_N000337_dash_stdin_read_file():
    @o.command()
    @o.argument("src", type=o.File("r"))
    def cmd(src):
        o.echo(src.read().strip())

    res = CliRunner().invoke(cmd, ["-"], prog_name="t", input="piped\n")
    assert res.stdout == "piped\n"


def test_N000369_bad_choice_names_parameter():
    @o.command()
    @o.option("--mode", type=o.Choice(["a"]))
    def cmd(mode):
        pass

    res = invoke(cmd, ["--mode", "zz"])
    assert res.exit_code == 2 and "--mode" in res.stderr


def test_N000166_nargs_option_with_repetition():
    @o.command()
    @o.option("--xy", nargs=2, multiple=True, type=int)
    def cmd(xy):
        o.echo(repr(xy))

    assert invoke(cmd, ["--xy", "1", "2", "--xy", "3", "4"]).stdout == "((1, 2), (3, 4))\n"


def test_N000206_tuple_type_option_arity():
    @o.command()
    @o.option("--rgb", type=o.Tuple([int, int, int]))
    def cmd(rgb):
        o.echo(repr(rgb))

    assert invoke(cmd, ["--rgb", "1", "2", "3"]).stdout == "(1, 2, 3)\n"


def test_N000204_multivalue_is_not_consume_rest():
    @o.command()
    @o.option("--pair", nargs=2)
    @o.argument("tail", nargs=-1)
    def cmd(pair, tail):
        o.echo(f"{pair}|{tail}")

    assert invoke(cmd, ["--pair", "a", "b", "c"]).stdout == "('a', 'b')|('c',)\n"


def test_N000217_env_split_for_multiple_option(monkeypatch):
    @o.command()
    @o.option("--item", multiple=True, envvar="ITEMS_X")
    def cmd(item):
        o.echo(repr(item))

    monkeypatch.setenv("ITEMS_X", "a b  c")
    assert invoke(cmd, []).stdout == "('a', 'b', 'c')\n"
