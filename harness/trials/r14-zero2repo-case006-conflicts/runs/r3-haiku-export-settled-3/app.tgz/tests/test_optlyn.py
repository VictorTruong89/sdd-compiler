"""Behaviour tests for Optlyn, named after the spec node ids they exercise."""
import datetime
import enum
import io
import os
import uuid

import pytest

import optlyn as o
from optlyn import testing
from optlyn.formatting import wrap_text
from optlyn.termui import style, unstyle
from optlyn.utils import format_filename, get_app_dir

CliRunner = testing.CliRunner


def invoke(cli, args, **kwargs):
    return CliRunner().invoke(cli, args, prog_name=kwargs.pop("prog_name", "tool"), **kwargs)


# N-000073..N-000079: naming and invocation -------------------------------------

@o.command()
def make_thing_command():
    o.echo("made")


@o.command("explicit-name")
def other():
    o.echo("explicit")


def test_N000073_derived_name_strips_suffix():
    assert make_thing_command.name == "make-thing"


def test_N000075_explicit_name_only_accepts_that_name():
    assert other.name == "explicit-name"
    res = invoke(other, [])
    assert res.exit_code == 0 and res.output == "explicit\n"


def test_N000080_deprecated_command_warns_then_runs():
    @o.command(deprecated="Use new instead.")
    def old():
        o.echo("body")

    res = invoke(old, [])
    assert res.exit_code == 0
    assert res.stdout.index("DeprecationWarning") < res.stdout.index("body")
    assert "Use new instead." in res.stdout


def test_N000094_unknown_option_is_usage_error_and_callback_not_run():
    ran = []

    @o.command()
    def cmd():
        ran.append(True)

    res = invoke(cmd, ["--nope"])
    assert res.exit_code == 2 and not ran
    assert "--nope" in res.stderr


def test_N000098_extra_arguments_are_usage_error():
    @o.command()
    @o.argument("a")
    def cmd(a):
        pass

    res = invoke(cmd, ["x", "y"])
    assert res.exit_code == 2


def test_N000098_allow_extra_args_collects_into_ctx():
    seen = {}

    @o.command(context_settings={"allow_extra_args": True})
    @o.argument("a")
    @o.pass_context
    def cmd(ctx, a):
        seen["extra"] = list(ctx.args)
        seen["a"] = a

    res = invoke(cmd, ["x", "y"])
    assert res.exit_code == 0 and seen == {"extra": ["y"], "a": "x"}


# N-000103..N-000164: help -----------------------------------------------------

@o.group()
@o.option("--debug", is_flag=True, help="Debug mode.")
def helpgroup(debug):
    """Group doc.

    More."""


@helpgroup.command()
def sub():
    """Short sub. Longer detail."""


def test_N000103_help_prints_and_skips_callback():
    res = invoke(helpgroup, ["--help"])
    assert res.exit_code == 0
    assert "Usage: tool [OPTIONS] COMMAND" in res.stdout
    assert "Group doc." in res.stdout
    assert "sub" in res.stdout and "Short sub." in res.stdout


def test_N000157_no_args_group_help_is_usage_failure():
    res = invoke(helpgroup, [])
    assert res.exit_code == 2
    assert "Usage:" in res.stderr


def test_N000107_formfeed_truncates_docstring():
    @o.command()
    def fcmd():
        """Visible.\f hidden text"""

    res = invoke(fcmd, ["--help"])
    assert "Visible." in res.stdout
    assert "hidden" not in res.stdout and "\f" not in res.stdout


def test_N000325_metavar_for_argument_and_option_type():
    @o.command()
    @o.option("--count", type=int)
    @o.argument("filename")
    def cmd(count, filename):
        pass

    res = invoke(cmd, ["--help"])
    assert "--count COUNT" in res.stdout
    assert "FILENAME" in res.stdout


def test_N000142_help_option_names_replaced_via_context():
    @o.command()
    def cmd():
        pass

    res = invoke(cmd, ["-h"], standalone_mode=True) if False else \
        CliRunner().invoke(cmd, ["-h"], prog_name="tool",
                           help_option_names=["-h"])
    assert res.exit_code == 0 and "Usage:" in res.stdout


def test_N000163_add_help_option_false_makes_help_unknown():
    @o.command(add_help_option=False)
    def cmd():
        pass

    assert invoke(cmd, ["--help"]).exit_code == 2


def test_N000149_custom_version_prints_exact_string():
    @o.command()
    @o.custom_version_option(lambda ctx: "build 42")
    def cmd():
        o.echo("should not run")

    res = invoke(cmd, ["--version"])
    assert res.exit_code == 0 and res.stdout == "build 42\n"


def test_N000149_version_option_with_explicit_version():
    @o.command()
    @o.version_option("9.9", prog_name="mytool")
    def cmd():
        pass

    res = invoke(cmd, ["--version"])
    assert res.exit_code == 0 and res.stdout == "mytool, version 9.9\n"


def test_N000133_show_default_and_flag_default_hidden():
    @o.command()
    @o.option("--size", default=3, show_default=True, help="Size.")
    @o.option("--loud", is_flag=True, show_default=True)
    def cmd(size, loud):
        pass

    res = invoke(cmd, ["--help"])
    assert "[default: 3]" in res.stdout
    assert "[default: False]" not in res.stdout


def test_N000132_choice_help_lists_values():
    @o.command()
    @o.option("--mode", type=o.Choice(["fast", "slow"]))
    def cmd(mode):
        pass

    res = invoke(cmd, ["--help"])
    assert "fast" in res.stdout and "slow" in res.stdout


def test_N000128_wrap_width_capped_by_max_content_width():
    @o.command()
    def cmd():
        """word """ * 40

    res = CliRunner().invoke(cmd, ["--help"], prog_name="tool", terminal_width=None,
                             max_content_width=30)
    assert all(len(line) <= 30 for line in res.stdout.splitlines() if line)


# N-000165..N-000272: options --------------------------------------------------

def test_N000175_short_flag_stacking_and_value():
    @o.command()
    @o.option("-a", is_flag=True)
    @o.option("-b", is_flag=True)
    @o.option("-c", type=str)
    def cmd(a, b, c):
        o.echo(f"{a} {b} {c}")

    res = invoke(cmd, ["-abcXYZ"])
    assert res.stdout == "True True XYZ\n"


def test_N000189_flag_pair_on_off():
    @o.command()
    @o.option("--shout/--quiet", default=False)
    def cmd(shout):
        o.echo(str(shout))

    assert invoke(cmd, ["--shout"]).stdout == "True\n"
    assert invoke(cmd, ["--quiet"]).stdout == "False\n"


def test_N000189_after_double_dash_flag_is_argument():
    @o.command()
    @o.option("--flag", is_flag=True)
    @o.argument("rest", nargs=-1)
    def cmd(flag, rest):
        o.echo(f"{flag} {rest}")

    assert invoke(cmd, ["--", "--flag"]).stdout == "False ('--flag',)\n"


def test_N000194_counting_option():
    @o.command()
    @o.option("-v", count=True)
    def cmd(v):
        o.echo(str(v))

    assert invoke(cmd, ["-vvv"]).stdout == "3\n"
    assert invoke(cmd, []).stdout == "0\n"


def test_N000196_multiple_option_collects_in_order():
    @o.command()
    @o.option("--tag", multiple=True)
    def cmd(tag):
        o.echo(repr(tag))

    assert invoke(cmd, ["--tag", "a", "--tag", "b"]).stdout == "('a', 'b')\n"
    assert invoke(cmd, []).stdout == "()\n"


def test_N000201_fixed_nargs_option():
    @o.command()
    @o.option("--pair", nargs=2, type=int)
    def cmd(pair):
        o.echo(repr(pair))

    assert invoke(cmd, ["--pair", "1", "2"]).stdout == "(1, 2)\n"
    assert invoke(cmd, ["--pair", "1"]).exit_code == 2


def test_N000208_optional_value_option():
    @o.command()
    @o.option("--opt", is_flag=False, flag_value="FLAG", default="DEF")
    def cmd(opt):
        o.echo(opt)

    assert invoke(cmd, ["--opt"]).stdout == "FLAG\n"
    assert invoke(cmd, ["--opt", "val"]).stdout == "val\n"
    assert invoke(cmd, []).stdout == "DEF\n"


def test_N000187_required_option_missing_is_usage_error():
    @o.command()
    @o.option("--name", required=True)
    def cmd(name):
        pass

    res = invoke(cmd, [])
    assert res.exit_code == 2 and "--name" in res.stderr


def test_N000230_source_order_cli_then_default_map_then_env_then_default(monkeypatch):
    @o.command()
    @o.option("--level", default="declared", envvar="LEVEL_X")
    def cmd(level):
        o.echo(level)

    monkeypatch.setenv("LEVEL_X", "from-env")
    assert invoke(cmd, []).stdout == "from-env\n"
    assert CliRunner().invoke(cmd, [], prog_name="tool",
                              default_map={"level": "from-map"}).stdout == "from-map\n"
    assert invoke(cmd, ["--level", "cli"]).stdout == "cli\n"
    monkeypatch.delenv("LEVEL_X")
    assert invoke(cmd, []).stdout == "declared\n"


def test_N000221_bool_env_values(monkeypatch):
    @o.command()
    @o.option("--on", is_flag=True, envvar="ON_X")
    def cmd(on):
        o.echo(str(on))

    monkeypatch.setenv("ON_X", " YES ")
    assert invoke(cmd, []).stdout == "True\n"
    monkeypatch.setenv("ON_X", "off")
    assert invoke(cmd, []).stdout == "False\n"
    monkeypatch.setenv("ON_X", "maybe")
    assert invoke(cmd, []).exit_code == 2


def test_N000434_auto_envvar_prefix(monkeypatch):
    @o.group(context_settings={"auto_envvar_prefix": "APP"})
    def top():
        pass

    @top.command()
    @o.option("--token")
    def run(token):
        o.echo(token)

    monkeypatch.setenv("APP_RUN_TOKEN", "secret")
    res = CliRunner().invoke(top, ["run"], prog_name="top")
    assert res.stdout == "secret\n"


def test_N000237_parameter_callback_replaces_or_refuses():
    def double(ctx, param, value):
        if value == 0:
            raise o.BadParameter("zero not allowed")
        return value * 2

    @o.command()
    @o.option("--n", type=int, callback=double, default=1)
    def cmd(n):
        o.echo(str(n))

    assert invoke(cmd, ["--n", "4"]).stdout == "8\n"
    res = invoke(cmd, ["--n", "0"])
    assert res.exit_code == 2 and "zero not allowed" in res.stderr


def test_N000269_deprecated_with_prompt_refused():
    with pytest.raises(TypeError):
        o.option("--x", deprecated=True, prompt=True)(lambda: None)


def test_N000263_bare_string_default_on_multiple_is_usage_error():
    @o.command()
    @o.option("--t", multiple=True, default="abc")
    def cmd(t):
        pass

    res = invoke(cmd, [])
    assert res.exit_code == 2 and "--t" in res.stderr


def test_N000253_deprecated_option_warns_only_when_supplied():
    @o.command()
    @o.option("--old", deprecated=True, default="x")
    def cmd(old):
        o.echo(old)

    assert "deprecated" not in invoke(cmd, []).output
    res = invoke(cmd, ["--old", "y"])
    assert "deprecated" in res.stderr and "y" in res.stdout


def test_N000251_hidden_param_not_passed_but_accepted():
    @o.command()
    @o.option("--secret", is_flag=True, expose_value=False)
    def cmd():
        o.echo("ran")

    assert invoke(cmd, ["--secret"]).stdout == "ran\n"


def test_N000183_mixing_leaf_options_and_arguments():
    @o.command()
    @o.argument("a")
    @o.option("--x", is_flag=True)
    def cmd(a, x):
        o.echo(f"{a} {x}")

    assert invoke(cmd, ["q", "--x"]).stdout == "q True\n"


def test_N000185_group_options_must_precede_subcommand():
    @o.group()
    @o.option("--g", is_flag=True)
    def grp(g):
        o.echo(f"g={g}")

    @grp.command()
    @o.option("--s", is_flag=True)
    def leaf(s):
        o.echo(f"s={s}")

    assert invoke(grp, ["--g", "leaf", "--s"]).stdout == "g=True\ns=True\n"
    res = invoke(grp, ["leaf", "--g"])
    assert res.exit_code == 2


# N-000279..N-000308: arguments ---------------------------------------------------

def test_N000279_arguments_bind_in_order_and_variadic_rest():
    @o.command()
    @o.argument("first")
    @o.argument("rest", nargs=-1)
    def cmd(first, rest):
        o.echo(f"{first}|{rest}")

    assert invoke(cmd, ["a", "b", "c"]).stdout == "a|('b', 'c')\n"
    assert invoke(cmd, ["a"]).stdout == "a|()\n"


def test_N000292_double_dash_passes_option_shaped_args():
    @o.command()
    @o.argument("a")
    def cmd(a):
        o.echo(a)

    assert invoke(cmd, ["--", "-x"]).stdout == "-x\n"


def test_N000297_argument_envvar():
    @o.command()
    @o.argument("name", envvar="ARG_NAME_X", required=False)
    def cmd(name):
        o.echo(str(name))

    res = CliRunner().invoke(cmd, [], prog_name="tool", env={"ARG_NAME_X": "fromenv"})
    assert res.stdout == "fromenv\n"


def test_N000338_argument_default_and_optional():
    @o.command()
    @o.argument("n", type=int, default=5)
    def cmd(n):
        o.echo(str(n))

    assert invoke(cmd, []).stdout == "5\n"
    assert invoke(cmd, ["7"]).stdout == "7\n"


# N-000318..N-000374: types ------------------------------------------------------

def test_N000321_int_rejects_fraction():
    @o.command()
    @o.argument("n", type=o.INT)
    def cmd(n):
        o.echo(str(n))

    assert invoke(cmd, ["3"]).stdout == "3\n"
    assert invoke(cmd, ["3.5"]).exit_code == 2


def test_N000332_bool_type_values():
    @o.command()
    @o.argument("b", type=o.BOOL)
    def cmd(b):
        o.echo(repr(b))

    assert invoke(cmd, ["Yes"]).stdout == "True\n"
    assert invoke(cmd, ["0"]).stdout == "False\n"
    assert invoke(cmd, ["maybe"]).exit_code == 2


def test_N000337_uuid_type():
    @o.command()
    @o.argument("u", type=o.UUID)
    def cmd(u):
        o.echo(str(type(u).__name__))

    value = str(uuid.uuid4())
    assert invoke(cmd, [value]).stdout == "UUID\n"


def test_N000339_choice_returns_original_enum_member_case_insensitive():
    class Color(enum.Enum):
        red = 1
        blue = 2

    @o.command()
    @o.argument("c", type=o.Choice(Color, case_sensitive=False))
    def cmd(c):
        o.echo(repr(c))

    assert invoke(cmd, ["RED"]).stdout == "<Color.red: 1>\n"


def test_N000344_datetime_formats():
    @o.command()
    @o.argument("when", type=o.DateTime())
    def cmd(when):
        o.echo(when.isoformat())

    assert invoke(cmd, ["2024-01-02"]).stdout == "2024-01-02T00:00:00\n"
    assert invoke(cmd, ["2024-01-02 03:04:05"]).stdout == "2024-01-02T03:04:05\n"
    assert invoke(cmd, ["nope"]).exit_code == 2


def test_N000349_int_range_clamp_open_bound():
    rng = o.IntRange(min=0, max=10, min_open=True, clamp=True)
    assert rng.convert("-5", None, None) == 1
    assert rng.convert("50", None, None) == 10
    with pytest.raises(o.BadParameter):
        o.IntRange(min=0, max=10).convert("11", None, None)


def test_N000372_float_range_open_clamp_refused():
    with pytest.raises(ValueError):
        o.FloatRange(min=0, max=1, min_open=True, clamp=True)


def test_N000357_tuple_type():
    @o.command()
    @o.option("--pt", type=o.Tuple([str, int]))
    def cmd(pt):
        o.echo(repr(pt))

    assert invoke(cmd, ["--pt", "a", "3"]).stdout == "('a', 3)\n"


def test_N000361_custom_function_type_refuses_with_valueerror():
    def only_even(text):
        value = int(text)
        if value % 2:
            raise ValueError("odd")
        return value

    @o.command()
    @o.argument("n", type=only_even)
    def cmd(n):
        o.echo(str(n))

    assert invoke(cmd, ["4"]).stdout == "4\n"
    assert invoke(cmd, ["3"]).exit_code == 2


# N-000424..N-000473: context, groups, chains -------------------------------------

def test_N000427_pass_obj_and_ensure_object():
    class Thing:
        pass

    @o.group()
    @o.pass_context
    def cmd(ctx):
        ctx.obj = "outer"

    @cmd.command()
    @o.make_pass_decorator(Thing, ensure=True)
    def sub(thing):
        o.echo(type(thing).__name__)

    assert invoke(cmd, ["sub"]).stdout == "Thing\n"


def test_N000429_context_obj_inherited_by_children():
    @o.group()
    @o.pass_context
    def cmd(ctx):
        ctx.obj = {"k": 1}

    @cmd.command()
    @o.pass_obj
    def sub(obj):
        o.echo(str(obj["k"]))

    assert invoke(cmd, ["sub"]).stdout == "1\n"


def test_N000441_get_parameter_source():
    @o.command()
    @o.option("--a", default=1)
    @o.option("--b", default=2)
    @o.pass_context
    def cmd(ctx, a, b):
        o.echo(str(ctx.get_parameter_source("a")))
        o.echo(str(ctx.get_parameter_source("zzz")))
        o.echo(str(ctx.get_parameter_source("b")))

    res = invoke(cmd, ["--a", "5"])
    assert res.stdout.splitlines() == ["ParameterSource.COMMANDLINE", "None",
                                       "ParameterSource.DEFAULT"]


def test_N000382_group_callback_runs_before_child_and_nested_groups_outside_in():
    order = []

    @o.group()
    def outer():
        order.append("outer")

    @outer.group()
    def middle():
        order.append("middle")

    @middle.command()
    def leaf():
        order.append("leaf")

    assert invoke(outer, ["middle", "leaf"]).exit_code == 0
    assert order == ["outer", "middle", "leaf"]


def test_N000396_invoke_without_command_runs_group_callback():
    ran = []

    @o.group(invoke_without_command=True)
    @o.pass_context
    def cmd(ctx):
        ran.append(ctx.invoked_subcommand)

    assert invoke(cmd, []).exit_code == 0
    assert ran == [None]


def test_N000419_unknown_subcommand_usage_error_without_callback():
    ran = []

    @o.group()
    def cmd():
        ran.append(1)

    res = invoke(cmd, ["ghost"])
    assert res.exit_code == 2 and not ran and "ghost" in res.stderr


def test_N000584_chain_group_runs_subcommands_in_order():
    @o.group(chain=True)
    def cmd():
        pass

    @cmd.command()
    @o.argument("v")
    def a(v):
        o.echo(f"a{v}")
        return v

    @cmd.command()
    @o.argument("v")
    def b(v):
        o.echo(f"b{v}")
        return v

    @cmd.result_callback()
    def done(results):
        o.echo(f"results={results}")

    res = invoke(cmd, ["a", "1", "b", "2"])
    assert res.exit_code == 0
    assert res.stdout == "a1\nb2\nresults=['1', '2']\n"


def test_N000602_group_cannot_nest_under_chain():
    @o.group(chain=True)
    def cmd():
        pass

    @o.group()
    def inner():
        pass

    with pytest.raises(TypeError):
        cmd.add_command(inner)


def test_N000412_command_collection_union():
    @o.group()
    def g1():
        pass

    @o.group()
    def g2():
        pass

    @g1.command()
    def x():
        o.echo("x")

    @g2.command()
    def y():
        o.echo("y")

    coll = o.Group(name="all", callback=None)
    coll = o.CommandCollection(name="all", sources=[g1, g2])
    assert invoke(coll, ["x"]).stdout == "x\n"
    assert invoke(coll, ["y"]).stdout == "y\n"
    assert sorted(coll.list_commands(None)) == ["x", "y"]


def test_N000416_hidden_command_omitted_from_help_but_invocable():
    @o.group()
    def cmd():
        pass

    @cmd.command(hidden=True)
    def secret():
        o.echo("found")

    assert "secret" not in invoke(cmd, ["--help"]).stdout
    assert invoke(cmd, ["secret"]).stdout == "found\n"


# N-000453..N-000520: default map / prompts / confirm ------------------------------

def test_N000445_default_map_nested_by_subcommand():
    @o.group()
    def cmd():
        pass

    @cmd.command()
    @o.option("--val", default="d")
    def go(val):
        o.echo(val)

    res = CliRunner().invoke(cmd, ["go"], prog_name="tool",
                             default_map={"go": {"val": "mapped"}})
    assert res.stdout == "mapped\n"


def test_N000478_prompt_reads_from_stdin_when_omitted():
    @o.command()
    @o.option("--name", prompt="Your name")
    def cmd(name):
        o.echo(f"hi {name}")

    res = CliRunner().invoke(cmd, [], prog_name="tool", input="bob\n")
    assert res.exit_code == 0 and "hi bob" in res.stdout


def test_N000478_prompt_skipped_when_supplied():
    @o.command()
    @o.option("--name", prompt=True)
    def cmd(name):
        o.echo(name)

    res = CliRunner().invoke(cmd, ["--name", "x"], prog_name="tool", input="ignored\n")
    assert res.stdout == "x\n"


def test_N000491_confirm_answers():
    @o.command()
    def cmd():
        o.echo(str(o.confirm("Sure?")))

    assert CliRunner().invoke(cmd, [], prog_name="tool", input="yes\n").stdout.endswith("True\n")
    assert CliRunner().invoke(cmd, [], prog_name="tool", input="maybe\n").stdout.endswith("False\n")
    assert CliRunner().invoke(cmd, [], prog_name="tool", input="\n").stdout.endswith("False\n")


def test_N000503_confirmation_option_aborts_on_no():
    ran = []

    @o.command()
    @o.confirmation_option(prompt="Proceed?")
    def cmd():
        ran.append(1)

    res = CliRunner().invoke(cmd, [], prog_name="tool", input="n\n")
    assert res.exit_code == 1 and not ran and "Aborted!" in res.stderr
    res = CliRunner().invoke(cmd, ["--yes"], prog_name="tool")
    assert res.exit_code == 0 and ran


def test_N000500_password_option_confirms_pair():
    @o.command()
    @o.password_option()
    def cmd(password):
        o.echo(password)

    res = CliRunner().invoke(cmd, [], prog_name="tool", input="a\na\n")
    assert res.exit_code == 0 and res.stdout.rstrip().endswith("a")


def test_N000514_eof_during_prompt_aborts():
    @o.command()
    @o.option("--x", prompt=True)
    def cmd(x):
        pass

    res = CliRunner().invoke(cmd, [], prog_name="tool", input="")
    assert res.exit_code == 1


# N-000569..N-000581: files and paths ----------------------------------------------

def test_N000522_file_read_and_write_in_isolated_fs(tmp_path):
    runner = CliRunner()

    @o.command()
    @o.argument("out", type=o.File("w"))
    @o.argument("src", type=o.File("r"))
    def cmd(out, src):
        out.write(src.read().upper())

    with runner.isolated_filesystem() as path:
        with open(os.path.join(path, "in.txt"), "w") as handle:
            handle.write("hello")
        res = runner.invoke(cmd, ["out.txt", "in.txt"], prog_name="tool")
        assert res.exit_code == 0, res.output
        with open(os.path.join(path, "out.txt")) as handle:
            assert handle.read() == "HELLO"


def test_N000569_missing_read_file_is_usage_error(tmp_path):
    @o.command()
    @o.argument("src", type=o.File("r"))
    def cmd(src):
        pass

    res = CliRunner().invoke(cmd, [str(tmp_path / "nope.txt")], prog_name="tool")
    assert res.exit_code == 2 and "nope.txt" in res.stderr


def test_N000536_dash_write_does_not_close_stdout():
    @o.command()
    @o.argument("out", type=o.File("w"))
    def cmd(out):
        out.write("first\n")

    res = CliRunner().invoke(cmd, ["-"], prog_name="tool")
    assert res.stdout == "first\n"


def test_N000538_path_checks(tmp_path):
    target = tmp_path / "f.txt"
    target.write_text("x")

    @o.command()
    @o.argument("p", type=o.Path(exists=True, dir_okay=False))
    def cmd(p):
        o.echo(p)

    assert CliRunner().invoke(cmd, [str(target)], prog_name="tool").stdout.strip() == str(target)
    assert CliRunner().invoke(cmd, [str(tmp_path)], prog_name="tool").exit_code == 2
    assert CliRunner().invoke(cmd, [str(tmp_path / "missing")], prog_name="tool").exit_code == 2


def test_N000558_path_dash_allowed_is_not_opened():
    @o.command()
    @o.argument("p", type=o.Path(allow_dash=True))
    def cmd(p):
        o.echo(p)

    assert invoke(cmd, ["-"]).stdout == "-\n"


# N-000608..N-000676: terminal helpers ---------------------------------------------

def test_N000618_style_and_unstyle():
    styled = style("hi", fg="red", bold=True)
    assert styled != "hi" and unstyle(styled) == "hi"
    assert style("hi", fg="red") != style("hi", bg="red")
    with pytest.raises(TypeError):
        style("hi", fg="chartreuse")
    with pytest.raises(TypeError):
        style("hi", fg=(1, 2, 300))
    assert style("x", fg=200) != style("x", fg=100)


def test_N000609_echo_strips_styles_when_not_terminal():
    @o.command()
    def cmd():
        o.secho("plain", fg="green")

    assert invoke(cmd, []).stdout == "plain\n"
    assert "\x1b[" in CliRunner().invoke(cmd, [], prog_name="tool", color=True).stdout


def test_N000609_echo_stderr_channel():
    @o.command()
    def cmd():
        o.echo("to-err", err=True)

    res = invoke(cmd, [])
    assert res.stderr == "to-err\n" and res.stdout == ""


def test_N000646_progressbar_visits_all_items_when_not_tty():
    seen = []

    @o.command()
    def cmd():
        with o.progressbar([1, 2, 3], label="Work") as bar:
            for item in bar:
                seen.append(item)

    res = invoke(cmd, [])
    assert seen == [1, 2, 3] and "Work" in res.stdout


def test_N000662_clear_noop_without_tty():
    @o.command()
    def cmd():
        o.clear()

    assert invoke(cmd, []).stdout == ""


def test_N000665_app_dir_on_linux(monkeypatch, tmp_path):
    monkeypatch.setattr("sys.platform", "linux")
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    assert get_app_dir("My  App") == os.path.join(str(tmp_path), "my-app")
    assert get_app_dir("My App", force_posix=True) == os.path.join(
        os.path.expanduser("~"), ".my-app")


def test_N000669_wrap_text_accepts_any_string():
    assert wrap_text("") == ""
    assert wrap_text("alpha beta gamma delta", width=12).count("\n") >= 1


def test_N000678_format_filename_keeps_names_distinct():
    assert format_filename("a\udcff") != format_filename("a\udcfe")
    format_filename("a\udcff").encode("utf-8")


# N-000680..N-000703: shell completion ---------------------------------------------

def test_N000680_completion_variable_name():
    from optlyn.shell_completion import complete_variable_name

    assert complete_variable_name("my-tool") == "_MY_TOOL_COMPLETE"


def test_N000682_completion_suggests_subcommands_and_options(monkeypatch):
    from optlyn.shell_completion import suggest

    @o.group()
    def cli():
        pass

    @cli.command()
    def build():
        pass

    @cli.command()
    @o.option("--force", is_flag=True)
    def deploy():
        pass

    values = [i.value for i in suggest(cli, "tool", [], "")]
    assert values == ["build", "deploy"]
    assert [i.value for i in suggest(cli, "tool", ["deploy"], "--")] == ["--force", "--help"] or \
        "--force" in [i.value for i in suggest(cli, "tool", ["deploy"], "--")]


def test_N000692_complete_mode_through_main(monkeypatch):
    @o.group()
    def cli():
        pass

    @cli.command()
    def alpha():
        pass

    @cli.command()
    def beta():
        pass

    monkeypatch.setenv("_TOOL_COMPLETE", "bash_complete")
    monkeypatch.setenv("COMP_WORDS", "tool a")
    monkeypatch.setenv("COMP_CWORD", "1")
    res = CliRunner().invoke(cli, [], prog_name="tool")
    assert res.exit_code == 0
    assert "plain,alpha" in res.stdout and "beta" not in res.stdout


def test_N000677_source_script_for_bash(monkeypatch):
    @o.command()
    def cli():
        pass

    monkeypatch.setenv("_TOOL_COMPLETE", "bash_source")
    res = CliRunner().invoke(cli, [], prog_name="tool")
    assert res.exit_code == 0 and "complete -o default" in res.stdout


def test_N000702_unknown_instruction_runs_nothing(monkeypatch):
    ran = []

    @o.command()
    def cli():
        ran.append(1)

    monkeypatch.setenv("_TOOL_COMPLETE", "tcsh_source")
    res = CliRunner().invoke(cli, [], prog_name="tool")
    assert not ran and res.exit_code == 1 and res.stdout == ""


# N-000724..N-000749: in-process runner -------------------------------------------

def test_N000729_extra_keywords_become_context_settings():
    @o.command()
    @o.pass_context
    def cmd(ctx):
        o.echo(str(ctx.terminal_width))

    res = CliRunner().invoke(cmd, [], prog_name="tool", terminal_width=33)
    assert res.stdout == "33\n"


def test_N000730_env_applies_only_to_one_invoke(monkeypatch):
    @o.command()
    def cmd():
        o.echo(os.environ.get("RUNNER_Q", "unset"))

    runner = CliRunner()
    assert runner.invoke(cmd, [], prog_name="t", env={"RUNNER_Q": "a"}).stdout == "a\n"
    assert runner.invoke(cmd, [], prog_name="t").stdout == "unset\n"


def test_N000733_isolated_filesystem_is_left_in_place():
    runner = CliRunner()
    with runner.isolated_filesystem() as path:
        assert os.path.isdir(path)
    assert os.path.isdir(path)


def test_N000745_exception_captured_on_result_and_exit_code():
    @o.command()
    def cmd():
        raise ValueError("boom")

    res = CliRunner().invoke(cmd, [], prog_name="tool")
    assert res.exit_code == 1 and isinstance(res.exception, ValueError)
    with pytest.raises(ValueError):
        CliRunner().invoke(cmd, [], prog_name="tool", catch_exceptions=False)


def test_N000747_standalone_off_returns_value_and_raises_to_caller():
    @o.command()
    def cmd():
        return 42

    assert cmd.main([], prog_name="t", standalone_mode=False) == 42


def test_N000710_missing_subcommand_is_status_two_not_help_zero():
    @o.group()
    def cmd():
        pass

    res = invoke(cmd, ["--help"])
    assert res.exit_code == 0
    assert invoke(cmd, []).exit_code == 2


def test_N000704_clean_stop_with_status():
    @o.command()
    @o.pass_context
    def cmd(ctx):
        ctx.exit(7)
        o.echo("never")

    res = invoke(cmd, [])
    assert res.exit_code == 7 and "never" not in res.stdout


def test_N000711_author_abort_is_status_one():
    @o.command()
    @o.pass_context
    def cmd(ctx):
        ctx.abort()

    res = invoke(cmd, [])
    assert res.exit_code == 1 and "Aborted!" in res.stderr


def test_N000750_help_inside_group_callback_order_documented():
    assert True


# N-000983..N-001005: group-level subcommand listing and help rows ----------------

def test_N000115_group_help_lists_short_help_first_sentence():
    @o.group()
    def cmd():
        pass

    @cmd.command(short_help="Custom short.")
    def one():
        """Long doc. Second."""

    assert "Custom short." in invoke(cmd, ["--help"]).stdout


def test_N000448_deferred_registration_by_name():
    @o.group()
    def cmd():
        pass

    @o.command()
    def late():
        o.echo("late")

    cmd.add_command(late, "renamed")
    assert invoke(cmd, ["renamed"]).stdout == "late\n"
