"""Decorators that declare commands, groups, options and arguments."""
import functools
import importlib.metadata as importlib_metadata

from .core import Argument, Command, CommandCollection, Group, Option
from .globals import get_current_context
from . import termui


def _pop_params(f):
    """Take the declarations attached to ``f`` (in declaration order) and detach them."""
    params = list(reversed(getattr(f, "__optlyn_params__", [])))
    if hasattr(f, "__optlyn_params__"):
        del f.__optlyn_params__
    return params


def _param_memo(f, param):
    if not hasattr(f, "__optlyn_params__"):
        f.__optlyn_params__ = []
    f.__optlyn_params__.append(param)


def _derive_command_name(func_name):
    name = func_name
    for suffix in ("_command", "_cmd", "_group", "_grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[:-len(suffix)]
            break
    return name.lower().replace("_", "-")


# spec: N-000834 N-000835 N-000836 N-000837
def command(name=None, cls=None, **attrs):
    """Turn a function into a :class:`Command` (``@command()`` or ``@command``)."""
    if cls is None:
        cls = Command

    def decorator(f):
        cmd_name = name if name is not None else _derive_command_name(f.__name__)
        params = _pop_params(f)
        return cls(name=cmd_name, callback=f, params=params, **attrs)

    if callable(name) and not isinstance(name, type):
        func, name = name, None
        return decorator(func)
    return decorator


# spec: N-000850 N-000851 N-000852
def group(name=None, cls=None, **attrs):
    """Turn a function into a :class:`Group` (``@group()`` or ``@group``)."""
    if cls is None:
        cls = Group

    def decorator(f):
        cmd_name = name if name is not None else _derive_command_name(f.__name__)
        params = _pop_params(f)
        return cls(name=cmd_name, callback=f, params=params, **attrs)

    if callable(name) and not isinstance(name, type):
        func, name = name, None
        return decorator(func)
    return decorator


# spec: N-000868 N-000869 N-000870 N-000871 N-000896
def option(*param_decls, cls=None, **attrs):
    """Attach an :class:`Option` to a command function."""
    if cls is None:
        cls = Option

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f

    return decorator


# spec: N-000897 N-000898 N-000899
def argument(*param_decls, cls=None, **attrs):
    """Attach an :class:`Argument` to a command function."""
    if cls is None:
        cls = Argument

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f

    return decorator


# spec: N-000911 N-000916
def help_option(*param_decls, **kwargs):
    """Attach an extra eager help flag that prints help and exits."""
    from .core import _show_help_callback

    if not param_decls:
        param_decls = ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _show_help_callback)
    return option(*param_decls, **kwargs)


def _detect_version(package_name):
    try:
        return importlib_metadata.version(package_name)
    except importlib_metadata.PackageNotFoundError:
        pass
    providers = importlib_metadata.packages_distributions().get(package_name)
    if providers:
        return importlib_metadata.version(providers[0])
    raise RuntimeError(f"{package_name!r} is not an installed distribution or import name.")


# spec: N-000913 N-000917 N-000918 N-000149 N-000150
def version_option(version=None, *param_decls, package_name=None, prog_name=None,
                   message=None, **kwargs):
    """Attach an eager ``--version`` flag that prints the version and exits."""
    if not param_decls:
        param_decls = ("--version",)

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        prog = prog_name or ctx.find_root().info_name
        identity = version
        if identity is None:
            identity = _detect_version(package_name or prog)
        text = (message or "%(prog)s, version %(version)s") % {
            "prog": prog, "package": package_name, "version": identity,
        }
        termui.echo(text, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*param_decls, **kwargs)


# spec: N-000914 N-000919
def custom_version_option(callback, *param_decls, **kwargs):
    """Attach an eager version flag whose identity is the string ``callback(ctx)`` returns."""
    if not param_decls:
        param_decls = ("--version",)

    def handler(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        termui.echo(callback(ctx), color=True)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = handler
    return option(*param_decls, **kwargs)


# spec: N-000912 N-000500
def password_option(*param_decls, **kwargs):
    """A prompting, hidden, confirmed option (default flag ``--password``)."""
    if not param_decls:
        param_decls = ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    return option(*param_decls, **kwargs)


def _abort_if_false(ctx, param, value):
    if not value:
        ctx.abort()


# spec: N-000915 N-000503
def confirmation_option(*param_decls, **kwargs):
    """A confirmation flag (default ``--yes``) that asks when omitted and aborts on no."""
    if not param_decls:
        param_decls = ("--yes",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")
    kwargs.setdefault("callback", _abort_if_false)
    return option(*param_decls, **kwargs)


# spec: N-000957
def pass_context(f):
    """Pass the current :class:`Context` as the first argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return new_func


# spec: N-000958
def pass_obj(f):
    """Pass the current context's ``obj`` as the first argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return new_func


# spec: N-000959 N-000427 N-000428
def make_pass_decorator(object_type, ensure=False):
    """Build a decorator that passes the nearest ``object_type`` object from the context chain."""

    def decorator(f):
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
                if obj is None:
                    raise RuntimeError(
                        f"Managed to invoke callback without a context object of type "
                        f"{object_type.__name__!r} existing.")
            return ctx.invoke(f, obj, *args, **kwargs)

        return new_func

    return decorator


__all__ = [
    "argument", "command", "confirmation_option", "custom_version_option",
    "group", "help_option", "make_pass_decorator", "option", "pass_context",
    "pass_obj", "password_option", "version_option", "CommandCollection",
]
