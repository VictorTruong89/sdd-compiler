"""Exceptions raised by Optlyn."""


class OptlynError(Exception):
    """A library-signalled error that is not a usage error (exit status 1)."""

    exit_code = 1

    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def format_message(self):
        return self.message

    def show(self, file=None):
        from .termui import echo

        echo(f"Error: {self.format_message()}", file=file, err=True)


class UsageError(OptlynError):
    """Incorrect command-line usage (exit status 2)."""

    exit_code = 2
    show_usage = True

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.ctx = ctx

    def show(self, file=None):
        from .termui import echo

        if self.ctx is not None and self.show_usage:
            hint = ""
            if self.ctx.help_option_names:
                hint = f" {self.ctx.help_option_names[0]}"
            echo(self.ctx.get_usage(), file=file, err=True)
            echo(f"Try '{self.ctx.command_path}{hint}' for help.", file=file, err=True)
        echo(f"Error: {self.format_message()}", file=file, err=True)


class BadParameter(UsageError):
    """A value was refused: a conversion or a parameter callback failed."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        if hint:
            return f"Invalid value for {hint}: {self.message}"
        return f"Invalid value: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter received no value from any source."""

    def format_message(self):
        return self.message


class NoSuchOption(UsageError):
    """An option token matches no declared flag."""

    def __init__(self, option_name, ctx=None):
        super().__init__(f"No such option: {option_name}", ctx)
        self.option_name = option_name


class BadOptionUsage(UsageError):
    """An option was used incorrectly (for example, a missing value)."""


class BadArgumentUsage(UsageError):
    """A positional argument was used incorrectly."""


class FileError(OptlynError):
    """A file could not be opened when I/O started (general error, exit status 1)."""


class Abort(RuntimeError):
    """The program was aborted (exit status 1)."""


class Exit(RuntimeError):
    """An author-requested clean stop with an exit status."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code
