"""Terminal helpers: output, styling, prompts, pager, progress bars, editor and launch."""
import contextlib
import getpass
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import time

from .exceptions import Abort
from .globals import get_current_context
from .param_types import STRING, convert_type, infer_type
from .exceptions import BadParameter

_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")

_BASE_COLORS = ["black", "red", "green", "yellow", "blue", "magenta", "cyan", "white"]

_STYLE_CODES = [
    ("bold", 1), ("dim", 2), ("italic", 3), ("underline", 4), ("blink", 5),
    ("reverse", 7), ("strikethrough", 9), ("overline", 53),
]


def is_tty(stream):
    try:
        return bool(stream.isatty())
    except (AttributeError, ValueError):
        return False


# spec: N-000980 N-000982
def is_interactive():
    """A session is interactive when standard input or standard output is a terminal."""
    return is_tty(sys.stdin) or is_tty(sys.stdout)


# spec: N-000628 N-000629 N-000630
def unstyle(text):
    """Remove ANSI escape sequences, leaving the rest of the text."""
    return _ANSI_RE.sub("", str(text))


def _color_code(color, background):
    if isinstance(color, bool):
        raise TypeError(f"Invalid color {color!r}.")
    if isinstance(color, str):
        name = color.lower()
        if name == "reset":
            return "49" if background else "39"
        bright = name.startswith("bright_")
        base = name[len("bright_"):] if bright else name
        if base not in _BASE_COLORS:
            raise TypeError(f"Unknown color {color!r}.")
        index = _BASE_COLORS.index(base)
        if background:
            return str((100 if bright else 40) + index)
        return str((90 if bright else 30) + index)
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise TypeError(f"Color index {color} is outside 0-255.")
        return f"{48 if background else 38};5;{color}"
    try:
        parts = tuple(color)
    except TypeError:
        raise TypeError(f"Invalid color {color!r}.") from None
    if len(parts) == 3 and all(isinstance(p, int) and not isinstance(p, bool)
                               and 0 <= p <= 255 for p in parts):
        return f"{48 if background else 38};2;{parts[0]};{parts[1]};{parts[2]}"
    raise TypeError(f"Invalid color {color!r}.")


# spec: N-000618 N-000619 N-000620 N-000621 N-000622 N-000623 N-000624 N-000625 N-000626 N-000627 N-000676 N-000965
def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True):
    """Wrap ``text`` in ANSI SGR sequences for the given colors and switches."""
    codes = []
    if fg is not None:
        codes.append(_color_code(fg, False))
    if bg is not None:
        codes.append(_color_code(bg, True))
    switches = {
        "bold": bold, "dim": dim, "underline": underline, "overline": overline,
        "italic": italic, "blink": blink, "reverse": reverse,
        "strikethrough": strikethrough,
    }
    for key, code in _STYLE_CODES:
        if switches.get(key):
            codes.append(str(code))
    text = str(text)
    if not codes:
        return text
    return f"\x1b[{';'.join(codes)}m{text}" + ("\x1b[0m" if reset else "")


def _write_text(file, text):
    encoding = (getattr(file, "encoding", None) or "").lower()
    buffer = getattr(file, "buffer", None)
    if "ascii" in encoding and buffer is not None and not text.isascii():
        file.flush()
        buffer.write(text.encode("utf-8"))
        buffer.flush()
        return
    try:
        file.write(text)
    except UnicodeEncodeError:
        if buffer is None:
            raise
        file.flush()
        buffer.write(text.encode("utf-8"))
        buffer.flush()


def _write_bytes(file, data, nl):
    if nl:
        data += b"\n"
    target = getattr(file, "buffer", file)
    file.flush()
    target.write(data)
    target.flush()


# spec: N-000609 N-000610 N-000611 N-000612 N-000613 N-000614 N-000615 N-000616 N-000617 N-000963 N-000964
def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write ``message`` to standard output (or standard error), stripping styles when not wanted."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, (bytes, bytearray)):
        _write_bytes(file, bytes(message), nl)
        return
    text = str(message)
    if color is None:
        ctx = get_current_context(silent=True)
        if ctx is not None:
            color = ctx.color
    keep_styles = is_tty(file) if color is None else bool(color)
    if not keep_styles:
        text = unstyle(text)
    if nl:
        text += "\n"
    _write_text(file, text)
    file.flush()


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    """Echo ``message`` after applying :func:`style` with the given keywords."""
    if message is not None:
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


_echo_text = echo


def _read_line(stream):
    line = stream.readline()
    if not line:
        raise Abort()
    return line.rstrip("\r\n")


def _prompt_line(text, default, hide_input, err, suffix, show_default):
    shown = ""
    if default is not None and show_default:
        shown = f" [{'*' * 8 if hide_input else default}]"
    prompt_text = f"{text}{shown}{suffix}"
    stream = sys.stdin
    if hide_input and is_tty(stream):
        return getpass.getpass(prompt_text)
    echo(prompt_text, nl=False, err=err)
    line = _read_line(stream)
    if hide_input:
        echo(err=err)
    elif not is_tty(stream) and not getattr(stream, "echoes", False):
        echo(line, err=err)
    return line


# spec: N-000478 N-000479 N-000480 N-000481 N-000487 N-000490 N-000500 N-000501 N-000502 N-000510 N-000511 N-000512 N-000514 N-000515 N-000516 N-000517
def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           prompt_suffix=": ", show_default=True, err=False):
    """Ask for a value until it converts, returning the converted value."""
    if callable(default):
        default = default()
    param_type = convert_type(type) if type is not None else None
    if param_type is None:
        inferred = infer_type(default) if default is not None else None
        param_type = inferred if inferred is not None else STRING
    while True:
        value = _prompt_line(text, default, hide_input, err, prompt_suffix, show_default)
        if value == "":
            if default is None:
                continue
            value = default
            if not isinstance(value, str):
                return param_type.convert(value, None, None)
        if confirmation_prompt:
            again = _prompt_line("Repeat for confirmation", None, hide_input, err,
                                 prompt_suffix, False)
            if again != value:
                echo("Error: The two entered values do not match.", err=True)
                continue
        try:
            return param_type.convert(value, None, None)
        except BadParameter as exc:
            echo(f"Error: {exc.message}", err=True)


# spec: N-000491 N-000495 N-000496 N-000497 N-000498 N-000499 N-001015 N-000495
def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    """Ask a yes/no question. Only ``y``/``yes`` is yes; any other answer counts as no."""
    if default is None:
        marker = "[y/n]"
    elif default:
        marker = "[Y/n]"
    else:
        marker = "[y/N]"
    while True:
        shown = f" {marker}" if show_default else ""
        echo(f"{text}{shown}{prompt_suffix}", nl=False, err=err)
        line = _read_line(sys.stdin)
        if not is_tty(sys.stdin):
            echo(line, err=err)
        answer = line.strip().lower()
        if answer == "":
            if default is None:
                continue
            result = bool(default)
        else:
            result = answer in ("y", "yes")
        break
    if abort and not result:
        raise Abort()
    return result


# spec: N-000648 N-000649 N-000650 N-000651
def getchar(echo=False):
    """Read one character from the terminal (not from a piped standard input)."""
    char = None
    try:
        import termios
        import tty

        fd = os.open("/dev/tty", os.O_RDONLY)
        try:
            old = termios.tcgetattr(fd)
            try:
                tty.setraw(fd)
                char = os.read(fd, 1).decode("utf-8", "replace")
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
        finally:
            os.close(fd)
    except (ImportError, OSError, ValueError, AttributeError):
        char = None
    if char is None:
        char = sys.stdin.read(1)
    if char == "":
        raise EOFError()
    if char == "\x03":
        raise KeyboardInterrupt()
    if char == "\x04":
        raise EOFError()
    if echo:
        _echo_text(char)
    return char


# spec: N-000652 N-000653 N-000675
def pause(info=None, err=False):
    """Wait for a key press when the session is interactive; otherwise do nothing."""
    if not is_interactive():
        return
    echo(info or "Press any key to continue...", err=err, nl=False)
    try:
        getchar()
    except (EOFError, KeyboardInterrupt):
        pass
    echo(err=err)


def _pager_command():
    return os.environ.get("PAGER")


# spec: N-000631 N-000632 N-000633 N-000634 N-000635 N-000636 N-000637 N-000638
def echo_via_pager(text_or_generator, color=None):
    """Write long text through the ``PAGER`` command when interactive, else to standard output."""
    value = text_or_generator() if callable(text_or_generator) else text_or_generator
    chunks = [value] if isinstance(value, str) else value
    pager = _pager_command()
    if is_interactive() and pager:
        with get_pager_file(color=color) as stream:
            for chunk in chunks:
                stream.write(chunk)
                stream.flush()
        return
    for chunk in chunks:
        echo(chunk, nl=False, color=color)


@contextlib.contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream that goes through the pager when interactive."""
    pager = _pager_command()
    if is_interactive() and pager:
        proc = subprocess.Popen(shlex.split(pager), stdin=subprocess.PIPE, text=True)
        try:
            yield proc.stdin
        finally:
            try:
                proc.stdin.close()
            except OSError:
                pass
            proc.wait()
        return
    from .utils import ProxyStream

    yield ProxyStream(sys.stdout)


# spec: N-000639 N-000640 N-000641 N-000642 N-000643 N-000644 N-000645 N-000646 N-000647 N-000673 N-000674
class ProgressBar:
    """A progress bar that wraps an iterable or a known length."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, width=36, **options):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.width = width
        self.pos = 0
        self.start = time.time()
        self.tty = not hidden and is_tty(sys.stdout)
        self._printed_label = False
        if not hidden and not self.tty and self.label:
            echo(self.label)
            self._printed_label = True

    def __iter__(self):
        if self.iterable is None:
            raise TypeError("This progress bar was not created with an iterable.")
        for item in self.iterable:
            yield item
            self.update(1)

    def _eta(self):
        if not self.length or self.pos == 0:
            return ""
        elapsed = time.time() - self.start
        remaining = elapsed / self.pos * max(self.length - self.pos, 0)
        return f" eta {int(remaining)}s"

    def render(self):
        if not self.tty:
            return
        if self.length:
            filled = int(self.width * min(self.pos, self.length) / self.length)
            bar = "#" * filled + "-" * (self.width - filled)
            text = f"\r{self.label} [{bar}] {self.pos}/{self.length}{self._eta()}"
        else:
            text = f"\r{self.label} {self.pos}"
        echo(text, nl=False)

    def update(self, n_steps):
        self.pos += n_steps
        self.render()

    def finish(self):
        if self.tty:
            echo()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.finish()


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    """Return a :class:`ProgressBar`; use it as a context manager."""
    return ProgressBar(iterable, length=length, label=label, hidden=hidden, **options)


# spec: N-000654 N-000655 N-000656
def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Open an editor on ``text`` (or on ``filename``) and return the saved text."""
    if editor is None:
        editor = os.environ.get("VISUAL") or os.environ.get("EDITOR")
        if not editor:
            editor = "notepad" if sys.platform.startswith("win") else "vi"
    if filename is None:
        fd, path = tempfile.mkstemp(suffix=extension)
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(text or "")
        initial = text or ""
    else:
        path = filename
        initial = None
    environ = os.environ.copy()
    if env:
        environ.update(env)
    subprocess.call(shlex.split(editor) + [path], env=environ)
    if filename is not None:
        return None
    try:
        with open(path, encoding="utf-8", newline="") as handle:
            result = handle.read()
    finally:
        os.remove(path)
    if require_save and result == initial:
        return None
    return result


# spec: N-000657 N-000658 N-000659 N-000660 N-000661
def launch(url, wait=False, locate=False):
    """Open ``url`` or a path with the default application; return a status value."""
    if sys.platform.startswith("win"):
        os.startfile(url)  # noqa: S606 - documented platform behaviour
        return 0
    if sys.platform == "darwin":
        opener = shutil.which("open") or "open"
        args = [opener] + (["-R"] if locate else []) + [url]
    else:
        opener = shutil.which("xdg-open") or "xdg-open"
        args = [opener, url]
    try:
        proc = subprocess.Popen(args)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0


# spec: N-000662 N-000663
def clear():
    """Clear the terminal screen; does nothing when standard output is not a terminal."""
    if not is_tty(sys.stdout):
        return
    sys.stdout.write("\x1b[2J\x1b[H")
    sys.stdout.flush()
