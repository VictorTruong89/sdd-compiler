"""Tokenising and binding of command-line tokens for one command."""
from .exceptions import BadArgumentUsage, BadOptionUsage, NoSuchOption
from .param_types import Tuple


class Occurrences:
    """What the command line supplied for one parameter."""

    __slots__ = ("values", "present", "no_value")

    def __init__(self):
        self.values = []
        self.present = False
        self.no_value = False


# spec: N-000175 N-000176 N-000177 N-000178 N-000179 N-000180 N-000183 N-000184 N-000185 N-000186 N-000292 N-000293 N-000294 N-000255 N-000256 N-000257 N-000258 N-000261 N-000262 N-000204 N-000205 N-000207
class Parser:
    """Parses a token list against a command's parameters.

    Values are recorded per parameter in ``records``; tokens that no parameter
    consumes are returned as leftovers.
    """

    def __init__(self, ctx, params, interspersed=True):
        self.ctx = ctx
        self.interspersed = interspersed
        self.ignore_unknown = ctx.ignore_unknown_options
        self.options = [p for p in params if p.is_option]
        self.arguments = [p for p in params if not p.is_option]
        self.records = {p: Occurrences() for p in params}
        self.cli_order = []
        self.by_name = {}
        self.prefixes = {"-"}
        for opt in self.options:
            for name in opt.opts:
                self.by_name[name] = (opt, opt.flag_value if opt.is_flag else None)
                self.prefixes.add(name[0])
            for name in opt.secondary_opts:
                self.by_name[name] = (opt, False)
                self.prefixes.add(name[0])

    def _is_option_like(self, token):
        return len(token) > 1 and token[0] in self.prefixes

    def parse(self, args):
        positional = []
        index = 0
        stop = False
        while index < len(args):
            token = args[index]
            index += 1
            if stop:
                positional.append(token)
                continue
            if token == "--":
                stop = True
                continue
            if not self._is_option_like(token):
                positional.append(token)
                if not self.interspersed:
                    positional.extend(args[index:])
                    break
                continue
            index = self._consume_option(token, args, index, positional)
        return self._bind_arguments(positional)

    def _consume_option(self, token, args, index, positional):
        prefix = token[0]
        if len(token) > 1 and token[1] == prefix:
            name, equals, attached = token.partition("=")
            entry = self.by_name.get(name)
            if entry is None:
                if self.ignore_unknown:
                    positional.append(token)
                    return index
                raise NoSuchOption(name, ctx=self.ctx)
            opt, flag_value = entry
            return self._take(opt, name, flag_value, attached if equals else None, args, index)
        chars = token[1:]
        position = 0
        while position < len(chars):
            key = prefix + chars[position]
            entry = self.by_name.get(key)
            if entry is None:
                if self.ignore_unknown:
                    positional.append(prefix + chars[position:])
                    return index
                raise NoSuchOption(key, ctx=self.ctx)
            opt, flag_value = entry
            rest = chars[position + 1:]
            if opt.takes_value:
                return self._take(opt, key, flag_value, rest or None, args, index)
            index = self._take(opt, key, flag_value, None, args, index)
            position += 1
        return index

    def _take(self, opt, name, flag_value, attached, args, index):
        record = self.records[opt]
        if not record.present:
            record.present = True
            self.cli_order.append(opt)
        if opt.count:
            if attached is not None:
                raise BadOptionUsage(f"Option '{name}' does not take a value.", self.ctx)
            record.values.append(1)
            return index
        if opt.is_flag:
            if attached is not None:
                raise BadOptionUsage(f"Option '{name}' does not take a value.", self.ctx)
            record.values.append(flag_value)
            return index
        if opt.flag_value is not None:
            # An option with an optional value: the flag alone yields flag_value.
            if attached is not None:
                record.values.append(attached)
            elif index < len(args) and not self._is_option_like(args[index]):
                record.values.append(args[index])
                index += 1
            else:
                record.values.append(opt.flag_value)
                record.no_value = True
            return index
        values = []
        if attached is not None:
            values.append(attached)
        while len(values) < opt.nargs:
            if index >= len(args):
                raise BadOptionUsage(f"Option '{name}' requires an argument.", self.ctx)
            values.append(args[index])
            index += 1
        record.values.append(tuple(values) if opt.is_tuple_occurrence else values[0])
        return index

    def _bind_arguments(self, positional):
        remaining = list(positional)
        for position, arg in enumerate(self.arguments):
            record = self.records[arg]
            if arg.nargs == -1:
                later = sum(a.nargs for a in self.arguments[position + 1:] if a.nargs > 0)
                take = max(len(remaining) - later, 0)
                tokens = remaining[:take]
                remaining = remaining[take:]
                if tokens:
                    record.present = True
                    record.values.append(tuple(tokens))
                    self.cli_order.append(arg)
                continue
            tokens = remaining[:arg.nargs]
            if len(tokens) == arg.nargs:
                remaining = remaining[arg.nargs:]
                record.present = True
                record.values.append(tuple(tokens) if arg.is_tuple_occurrence else tokens[0])
            elif tokens and arg.required:
                raise BadArgumentUsage(
                    f"Argument '{arg.name.upper()}' takes {arg.nargs} values.", self.ctx
                )
        return remaining


__all__ = ["Parser", "Occurrences", "Tuple"]
