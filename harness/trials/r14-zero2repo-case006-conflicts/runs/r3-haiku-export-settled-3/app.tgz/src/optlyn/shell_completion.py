"""Shell completion: registration scripts and suggestion output."""
import os
import re
import sys

from . import termui
from .core import Context, Group
from .param_types import CompletionItem, PathRequest

SHELLS = ("bash", "zsh", "fish", "powershell")
_PREFIX_CHARS = "-/+"


# spec: N-000677 N-000680 N-000681 N-000983 N-000984
def complete_variable_name(prog_name):
    """The environment variable that selects completion mode for ``prog_name``."""
    return "_" + prog_name.replace("-", "_").upper() + "_COMPLETE"


# spec: N-000689 N-000690 N-000691 N-000692 N-000693 N-000702 N-000703
def handle_completion(cli, prog_name, instruction, standalone_mode=True):
    """Print a registration script or suggestions for an ``<shell>_source``/``<shell>_complete`` value."""
    shell, _, action = instruction.rpartition("_")
    if shell not in SHELLS or action not in ("source", "complete"):
        termui.echo(f"Error: Unknown completion instruction {instruction!r}.", err=True)
        if standalone_mode:
            sys.exit(1)
        return
    if action == "source":
        termui.echo(_script(shell, prog_name, complete_variable_name(prog_name)), nl=False)
    else:
        args, incomplete = _completion_words(shell)
        items = suggest(cli, prog_name, args, incomplete)
        for item in items:
            termui.echo(_format_item(item, shell))
    if standalone_mode:
        sys.exit(0)


def _completion_words(shell):
    raw = os.environ.get("COMP_WORDS", "")
    words = raw.split(" ")
    if shell == "fish":
        incomplete = os.environ.get("COMP_CWORD", "")
        args = words[1:]
        if args and args[-1] == incomplete:
            args = args[:-1]
        return args, incomplete
    try:
        cword = int(os.environ.get("COMP_CWORD", len(words)))
    except ValueError:
        cword = len(words)
    if cword >= len(words):
        return words[1:], ""
    return words[1:cword], words[cword]


def _format_item(item, shell):
    if isinstance(item, PathRequest):
        return f"{item.kind},{item.incomplete}"
    line = f"{item.type},{item.value}"
    if item.help and shell in ("zsh", "fish"):
        line += "\t" + item.help
    return line


def _is_option_like(token):
    return len(token) > 1 and token[0] in _PREFIX_CHARS


def _find_option(params, token):
    for param in params:
        if param.is_option and token in param.opts + param.secondary_opts:
            return param
    return None


# spec: N-000682 N-000683 N-000684 N-000685 N-000686 N-000687 N-000688 N-000700 N-000701
def suggest(cli, prog_name, args, incomplete):
    """Return the suggestions (``CompletionItem`` or ``PathRequest``) for an incomplete token."""
    ctx = Context(cli, info_name=prog_name, resilient_parsing=True)
    cmd = cli
    positional = []
    consumed = []
    pending = None
    index = 0
    while index < len(args):
        token = args[index]
        index += 1
        if pending is not None:
            pending = None
            consumed.append(token)
            continue
        if token == "--":
            positional.extend(args[index:])
            break
        if isinstance(cmd, Group) and not positional and not _is_option_like(token):
            sub = cmd.get_command(ctx, token)
            if sub is not None:
                cmd = sub
                ctx = Context(sub, info_name=token, parent=ctx, resilient_parsing=True)
                consumed.append(token)
                continue
        if _is_option_like(token):
            option = _find_option(cmd.get_params(ctx), token)
            if option is not None and option.takes_value and "=" not in token:
                pending = option
            consumed.append(token)
            continue
        positional.append(token)
        consumed.append(token)
    if pending is not None:
        return _param_values(ctx, pending, incomplete, args)
    if _is_option_like(incomplete):
        names = []
        for param in cmd.get_params(ctx):
            if param.is_option and not param.hidden:
                names.extend(param.opts + param.secondary_opts)
        return [CompletionItem(name, help=None) for name in names if name.startswith(incomplete)]
    if isinstance(cmd, Group) and not positional:
        items = []
        for name in cmd.list_commands(ctx):
            sub = cmd.get_command(ctx, name)
            if sub is None or sub.hidden or not name.startswith(incomplete):
                continue
            items.append(CompletionItem(name, help=sub.get_short_help_str(60)))
        return items
    arguments = [p for p in cmd.get_params(ctx) if not p.is_option]
    if len(positional) < len(arguments):
        return _param_values(ctx, arguments[len(positional)], incomplete, args)
    return []


def _param_values(ctx, param, incomplete, args):
    ctx.params = _parsed_values(ctx, args)
    if param.shell_complete_func is not None:
        result = param.shell_complete_func(ctx, param, incomplete)
    else:
        result = param.type.shell_complete(ctx, param, incomplete)
    items = []
    for item in result or []:
        if isinstance(item, (CompletionItem, PathRequest)):
            items.append(item)
        else:
            items.append(CompletionItem(str(item)))
    return items


def _parsed_values(ctx, args):
    """Best-effort values for the tokens already on the line (no callbacks, no prompts)."""
    values = {}
    try:
        cmd = ctx.command
        cmd._parse_tokens(ctx, [a for a in args if _is_option_like(a)])
        for param in cmd.get_params(ctx):
            occurrence = ctx._raw.get(param)
            if occurrence is not None and occurrence.present and param.expose_value:
                values[param.name] = param._combine(ctx, occurrence.values)
    except Exception:
        return values
    return values


def _script(shell, prog_name, variable):
    func = "_" + re.sub(r"\W", "_", prog_name) + "_completion"
    if shell == "bash":
        return _BASH.format(func=func, prog=prog_name, var=variable)
    if shell == "zsh":
        return _ZSH.format(func=func, prog=prog_name, var=variable)
    if shell == "fish":
        return _FISH.format(func=func, prog=prog_name, var=variable)
    return _POWERSHELL.format(prog=prog_name, var=variable)


_BASH = """{func}() {{
    local out line
    out=$(env {var}=bash_complete COMP_WORDS="${{COMP_WORDS[*]}}" COMP_CWORD=$COMP_CWORD {prog} 2>/dev/null)
    local IFS=$'\\n'
    COMPREPLY=()
    for line in $out; do
        case "$line" in
            plain,*) COMPREPLY+=("${{line#plain,}}") ;;
            file,*) COMPREPLY+=($(compgen -f -- "${{line#file,}}")) ;;
            dir,*) COMPREPLY+=($(compgen -d -- "${{line#dir,}}")) ;;
        esac
    done
}}
complete -o default -F {func} {prog}
"""

_ZSH = """#compdef {prog}
{func}() {{
    local -a items
    items=(${{(f)"$(env {var}=zsh_complete COMP_WORDS="${{words[*]}}" COMP_CWORD=$((CURRENT-1)) {prog} 2>/dev/null)"}})
    items=(${{items#plain,}})
    compadd -- ${{items%%$'\\t'*}}
}}
compdef {func} {prog}
"""

_FISH = """function _{func}_complete
    set -l words (commandline -cp)
    set -l cur (commandline -ct)
    env {var}=fish_complete COMP_WORDS="$words" COMP_CWORD="$cur" {prog} 2>/dev/null | string replace -r '^plain,' ''
end
complete -c {prog} -f -a '(_{func}_complete)'
"""

_POWERSHELL = """Register-ArgumentCompleter -Native -CommandName {prog} -ScriptBlock {{
    param($wordToComplete, $commandAst, $cursorPosition)
    $env:{var} = 'powershell_complete'
    $env:COMP_WORDS = $commandAst.ToString()
    $env:COMP_CWORD = [string]($commandAst.CommandElements.Count - 1)
    & {prog} 2>$null | ForEach-Object {{
        $value = $_ -replace '^plain,', ''
        $parts = $value -split "`t", 2
        [System.Management.Automation.CompletionResult]::new($parts[0], $parts[0], 'ParameterValue', $parts[0])
    }}
    Remove-Item Env:\\{var} -ErrorAction SilentlyContinue
}}
"""
