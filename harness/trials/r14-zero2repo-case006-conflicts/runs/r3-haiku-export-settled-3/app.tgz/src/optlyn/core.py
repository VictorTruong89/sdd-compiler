"""Contexts, parameters, commands and groups."""
import enum
import inspect
import os
import re
import shutil
import sys
from collections.abc import Iterable, Mapping

from . import termui
from .exceptions import (
    Abort, BadOptionUsage, BadParameter, Exit, MissingParameter, NoSuchOption,
    OptlynError, UsageError,
)
from .formatting import format_definition_list, format_help_text
from .globals import pop_context, push_context
from .param_types import (
    BOOL, Choice, File, INT, STRING, Tuple, convert_type, infer_type,
)
from .parser import Parser

DEFAULT_MAX_CONTENT_WIDTH = 80
_MISSING = object()
_CHAIN = object()
_PREFIX_CHARS = "-/+"


# spec: N-000453 N-000454 N-000455 N-000456 N-000951
class ParameterSource(enum.Enum):
    """Where a parameter's value came from."""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


# Precedence when feature-switch options share a destination (lower wins).
_SOURCE_RANK = {
    ParameterSource.PROMPT: 0,
    ParameterSource.COMMANDLINE: 1,
    ParameterSource.DEFAULT_MAP: 2,
    ParameterSource.ENVIRONMENT: 3,
    ParameterSource.DEFAULT: 4,
}


class _HelpShownError(UsageError):
    """Help was already printed because of incorrect usage; nothing more to show."""

    def show(self, file=None):
        return None


# spec: N-000932 N-000933 N-000934 N-000935 N-000936 N-000937
class Context:
    """The state of one invocation of one command."""

    def __init__(self, command, parent=None, info_name=None, obj=None,
                 auto_envvar_prefix=None, default_map=None, terminal_width=None,
                 max_content_width=None, help_option_names=None,
                 token_normalize_func=None, color=None, show_default=None,
                 allow_extra_args=None, ignore_unknown_options=None,
                 allow_interspersed_args=None, resilient_parsing=False):
        self.command = command
        self.parent = parent
        self.info_name = info_name if info_name is not None else command.name
        self.params = {}
        self.args = []
        self.invoked_subcommand = None
        self.resilient_parsing = resilient_parsing
        self._raw = {}
        self._cli_order = []
        self._sources = {}
        self._param_list = None
        self._pending_help = False
        self._pending_missing = False
        self._closers = []
        if parent is None:
            self._registry = [self]
        else:
            self._registry = None
            parent.find_root()._registry.append(self)

        def inherit(value, attr, default=None):
            if value is not None:
                return value
            if parent is not None:
                return getattr(parent, attr)
            return default

        self.obj = obj if obj is not None else (parent.obj if parent is not None else None)
        self.auto_envvar_prefix = inherit(auto_envvar_prefix, "auto_envvar_prefix")
        if default_map is None and parent is not None and isinstance(parent.default_map, Mapping):
            default_map = parent.default_map.get(self.info_name)
        self.default_map = default_map
        self.terminal_width = inherit(terminal_width, "terminal_width")
        self.max_content_width = inherit(max_content_width, "max_content_width",
                                         DEFAULT_MAX_CONTENT_WIDTH)
        self.help_option_names = list(inherit(help_option_names, "help_option_names", ["--help"]))
        self.token_normalize_func = inherit(token_normalize_func, "token_normalize_func")
        self.color = inherit(color, "color")
        self.show_default = inherit(show_default, "show_default")
        self.allow_extra_args = (command.allow_extra_args if allow_extra_args is None
                                 else bool(allow_extra_args))
        self.ignore_unknown_options = (command.ignore_unknown_options
                                       if ignore_unknown_options is None
                                       else bool(ignore_unknown_options))
        self.allow_interspersed_args = (command.allow_interspersed_args
                                        if allow_interspersed_args is None
                                        else bool(allow_interspersed_args))

    # -- structure ----------------------------------------------------------

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    @property
    def command_path(self):
        if self.parent is None:
            return self.info_name
        return f"{self.parent.command_path} {self.info_name}"

    def find_object(self, object_type):
        node = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

    # -- context manager and cleanup ------------------------------------------

    def __enter__(self):
        push_context(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        pop_context(self)

    def call_on_close(self, func):
        self._closers.append(func)
        return func

    # spec: N-000952 N-000457
    def with_resource(self, cm):
        value = cm.__enter__()
        self.call_on_close(lambda: cm.__exit__(None, None, None))
        return value

    def _run_closers(self):
        while self._closers:
            self._closers.pop()()

    def close(self):
        """Close resources of this invocation and of every context created under it."""
        for ctx in reversed(self.find_root()._registry):
            ctx._run_closers()

    # -- actions ----------------------------------------------------------------

    # spec: N-000953 N-000461 N-000462
    def invoke(self, callback, *args, **kwargs):
        """Call a callback, or run another command with missing values defaulted."""
        if isinstance(callback, Command):
            cmd = callback
            if cmd.callback is None:
                return None
            sub = Context(cmd, info_name=cmd.name, parent=self)
            for param in cmd.get_params(sub):
                if param.expose_value and param.name not in kwargs:
                    kwargs[param.name] = param.get_default(sub)
            with sub:
                return cmd.callback(*args, **kwargs)
        with self:
            return callback(*args, **kwargs)

    # spec: N-000463 N-000464 N-000465 N-000466
    def forward(self, cmd, **kwargs):
        values = dict(self.params)
        values.update(kwargs)
        return self.invoke(cmd, **values)

    # spec: N-000954 N-000704 N-000705
    def exit(self, code=0):
        raise Exit(code)

    # spec: N-000955 N-000711
    def abort(self):
        raise Abort()

    # spec: N-000951 N-000453 N-000456
    def get_parameter_source(self, name):
        if name not in {p.name for p in self.command.get_params(self)}:
            return None
        return self._sources.get(name, ParameterSource.DEFAULT)

    def get_wrap_width(self):
        if self.terminal_width is not None:
            return self.terminal_width
        detected = shutil.get_terminal_size(fallback=(80, 24)).columns
        return min(detected, self.max_content_width)

    def get_usage(self):
        return self.command.get_usage(self)

    def get_help(self):
        return self.command.get_help(self)

    # -- parameter processing -------------------------------------------------

    def _store(self, param, value, source):
        if param.expose_value:
            self.params[param.name] = value
            self._sources[param.name] = source

    def _run_eager(self, done):
        for param in list(self._cli_order):
            if param.is_eager and param not in done:
                done.add(param)
                value, source = param.consume_value(self)
                self._store(param, value, source)

    def _check_pending(self):
        if self._pending_help:
            termui.echo(self.get_help(), err=True)
            raise _HelpShownError("Incorrect usage.", self)
        if self._pending_missing:
            raise UsageError("Missing command.", self)

    def _run_params(self, done):
        candidates = {}
        for index, param in enumerate(self.command.get_params(self)):
            if param in done:
                continue
            done.add(param)
            value, source = param.consume_value(self)
            if param.expose_value:
                candidates.setdefault(param.name, []).append((index, param, value, source))
        for options in candidates.values():
            if len(options) == 1:
                _, param, value, source = options[0]
            else:
                _, param, value, source = min(options, key=_winner_key)
            self._store(param, value, source)


def _winner_key(item):
    index, param, _, source = item
    auto_default = source is ParameterSource.DEFAULT and param.default is None
    return (_SOURCE_RANK[source], 1 if auto_default else 0, -index)


# spec: N-000908 N-000909 N-000910 N-000900 N-000901 N-000902 N-000903 N-000904 N-000905 N-000906 N-000907
class Parameter:
    """Common behaviour of options and arguments."""

    is_option = False
    is_flag = False
    count = False
    prompt = None
    prompt_required = True
    hide_input = False
    confirmation_prompt = False
    allow_from_autoenv = False

    def __init__(self, name, *, type=None, required=False, default=None, callback=None,
                 nargs=1, multiple=False, metavar=None, expose_value=True, is_eager=False,
                 envvar=None, shell_complete=None, deprecated=False, hidden=False,
                 help=None):
        self.name = name
        self.type = type
        self.required = required
        self.default = default
        self.callback = callback
        self.nargs = nargs
        self.multiple = multiple
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        if envvar is None:
            self.envvar = []
        elif isinstance(envvar, str):
            self.envvar = [envvar]
        else:
            self.envvar = list(envvar)
        self.shell_complete_func = shell_complete
        self.deprecated = bool(deprecated)
        self.deprecation_note = deprecated if isinstance(deprecated, str) else None
        self.hidden = hidden
        self.help = help

    @property
    def is_tuple_occurrence(self):
        """True when one occurrence delivers several tokens (a tuple)."""
        return self.nargs != 1 or isinstance(self.type, Tuple)

    def get_error_hint(self, ctx):
        return f"'{self.name}'"

    def make_metavar(self):
        if self.metavar is not None:
            return self.metavar
        return self.name.upper()

    # -- conversion -------------------------------------------------------------

    def _convert(self, ctx, value):
        if value is None:
            return None
        try:
            return self.type.convert(value, self, ctx)
        except BadParameter:
            raise
        except ValueError as exc:
            raise BadParameter(f"{value!r} is not a valid {self.type.name}. {exc}",
                               ctx=ctx, param=self) from None

    def _convert_occurrence(self, ctx, raw):
        if self.is_tuple_occurrence:
            if isinstance(self.type, Tuple):
                return self._convert(ctx, tuple(raw))
            return tuple(self._convert(ctx, item) for item in raw)
        return self._convert(ctx, raw)

    def _combine(self, ctx, occurrences):
        if self.count:
            return sum(occurrences)
        if self.multiple:
            return tuple(self._convert_occurrence(ctx, item) for item in occurrences)
        return self._convert_occurrence(ctx, occurrences[-1])

    def _occurrences_from_tokens(self, tokens):
        if self.multiple:
            if not self.is_tuple_occurrence:
                return list(tokens)
            size = self.nargs
            if len(tokens) % size:
                raise BadParameter(f"Expected a multiple of {size} values.",
                                   ctx=None, param=self)
            return [tuple(tokens[i:i + size]) for i in range(0, len(tokens), size)]
        if self.is_tuple_occurrence:
            return [tuple(tokens)] if self.nargs == -1 else [tuple(tokens[:self.nargs])]
        return [tokens[0]]

    def _from_text(self, ctx, text):
        """Convert text from the environment or a default map: split it when needed."""
        if self.multiple or self.is_tuple_occurrence:
            tokens = self.type.split_envvar_value(text)
            if not tokens:
                return self._empty_value()
            return self._combine(ctx, self._occurrences_from_tokens(tokens))
        return self._convert(ctx, text)

    def _empty_value(self):
        if self.multiple or self.nargs == -1:
            return ()
        return None

    def _env_names(self):
        return list(self.envvar)

    # spec: N-000214 N-000215 N-000216 N-000217 N-000218 N-000219 N-000220
    def _env_lookup(self, ctx):
        names = self._env_names()
        if self.is_option and self.allow_from_autoenv and ctx.auto_envvar_prefix:
            names.append(self._auto_env_name(ctx))
        for name in names:
            raw = os.environ.get(name)
            if raw is None or raw == "":
                continue
            value = self.env_value(ctx, raw)
            if value is not _MISSING:
                return value
        return _MISSING

    def env_value(self, ctx, raw):
        return self._from_text(ctx, raw)

    def _from_default_map(self, ctx, given):
        if isinstance(given, str):
            if self.multiple and not self.is_tuple_occurrence:
                raise BadOptionUsage(
                    f"Default for {self.get_error_hint(ctx)} must be an iterable "
                    "(sequence) of values, not a string.", ctx)
            return self._from_text(ctx, given)
        if self.multiple:
            if not isinstance(given, Iterable):
                raise BadOptionUsage(
                    f"Default for {self.get_error_hint(ctx)} must be an iterable "
                    "(sequence) of values.", ctx)
            return tuple(self._convert_occurrence(ctx, item) for item in given)
        return self._convert_occurrence(ctx, given)

    def _default_map_value(self, ctx):
        if not isinstance(ctx.default_map, Mapping) or self.name not in ctx.default_map:
            return _MISSING
        return ctx.default_map[self.name]

    def _declared_default(self):
        value = self.default
        if callable(value):
            value = value()
        return value

    def get_default(self, ctx):
        """The declared default, converted; callable defaults are invoked."""
        value = self._declared_default()
        if value is None:
            return self._empty_value()
        return self._from_default_map(ctx, value)

    # -- value resolution ---------------------------------------------------------

    def _prompt_applicable(self):
        return self.prompt is not None and (self.prompt_required or self.required)

    def _run_prompt(self, default):
        if self.is_flag:
            return termui.confirm(self.prompt, default=bool(default))
        value = termui.prompt(
            self.prompt, default=default, hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt, type=self.type,
        )
        return (value,) if self.multiple else value

    # spec: N-000230 N-000231 N-000232 N-000237 N-000238 N-000239 N-000250
    def consume_value(self, ctx):
        """Resolve this parameter from its sources and run its callback.

        Sources, most explicit first: command line, default map, environment,
        prompt, declared default. Returns ``(value, source)``.
        """
        occurrence = ctx._raw.get(self)
        value = None
        source = None
        if occurrence is not None and occurrence.present:
            if self.is_option and occurrence.no_value and self.prompt is not None:
                value = self._run_prompt(self._declared_default())
                source = ParameterSource.PROMPT
            else:
                value = self._combine(ctx, occurrence.values)
                source = ParameterSource.COMMANDLINE
            if self.deprecated:
                termui.echo(self._deprecation_text(), err=True)
        if source is None:
            given = self._default_map_value(ctx)
            if given is not _MISSING and given is not None:
                if self._prompt_applicable():
                    value = self._run_prompt(self._from_default_map(ctx, given))
                    source = ParameterSource.PROMPT
                else:
                    value = self._from_default_map(ctx, given)
                    source = ParameterSource.DEFAULT_MAP
        if source is None and (self.envvar or self.is_option):
            found = self._env_lookup(ctx)
            if found is not _MISSING:
                value = found
                source = ParameterSource.ENVIRONMENT
        if source is None and self._prompt_applicable():
            value = self._run_prompt(self._declared_default())
            source = ParameterSource.PROMPT
        if source is None:
            value = self.get_default(ctx)
            source = ParameterSource.DEFAULT
            if self.required and self._declared_default() is None:
                raise MissingParameter(self._missing_message(), ctx=ctx, param=self)
        if isinstance(self.type, File) and value is not None and hasattr(value, "close"):
            ctx.call_on_close(value.close)
        if self.callback is not None:
            value = self.callback(ctx, self, value)
        return value, source

    def _missing_message(self):
        return f"Missing parameter {self.name!r}."

    def _deprecation_text(self):
        note = f" {self.deprecation_note}" if self.deprecation_note else ""
        return f"DeprecationWarning: The parameter '{self.name}' is deprecated.{note}"


# spec: N-000165 N-000166 N-000175 N-000189 N-000194 N-000196 N-000208
class Option(Parameter):
    """A named parameter introduced by a prefix such as ``--`` or ``-``."""

    is_option = True

    def __init__(self, param_decls=None, *, type=None, required=False, default=None,
                 is_flag=None, flag_value=None, count=False, multiple=False, nargs=1,
                 envvar=None, allow_from_autoenv=True, prompt=False, prompt_required=True,
                 hide_input=False, confirmation_prompt=False, callback=None, is_eager=False,
                 expose_value=True, hidden=False, deprecated=False, help=None,
                 metavar=None, show_default=None, show_envvar=False, show_choices=True,
                 shell_complete=None, **extra):
        if extra:
            raise TypeError(f"Unknown option keyword(s): {', '.join(extra)}")
        opts, secondary, name = _split_decls(list(param_decls or ()))
        if name is None:
            name = _infer_name(opts)
        if name is None:
            raise TypeError("An option needs at least one flag name or a destination name.")
        if not opts and not secondary:
            opts = ["--" + name.replace("_", "-")]
        if nargs < 1:
            raise TypeError("nargs must be a positive integer for an option.")
        if deprecated and required:
            raise TypeError("A deprecated option cannot also be required.")
        if deprecated and prompt:
            raise TypeError("A deprecated option cannot use a prompt.")
        if is_flag is None:
            is_flag = bool(secondary)
        if is_flag and flag_value is None:
            flag_value = True
        if is_flag and count:
            raise TypeError("An option cannot be both a flag and a counting option.")
        self.opts = opts
        self.secondary_opts = secondary
        self.is_flag = bool(is_flag)
        self.flag_value = flag_value
        self.count = bool(count)
        self.allow_from_autoenv = allow_from_autoenv
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.show_choices = show_choices
        if prompt is True:
            self.prompt = name.replace("_", " ").capitalize()
        elif isinstance(prompt, str):
            self.prompt = prompt
        else:
            self.prompt = None
        resolved = _resolve_option_type(type, default, self.is_flag, flag_value, self.count)
        if isinstance(resolved, Tuple):
            nargs = len(resolved.types)
        super().__init__(
            name, type=resolved, required=required, default=default, callback=callback,
            nargs=nargs, multiple=multiple, metavar=metavar, expose_value=expose_value,
            is_eager=is_eager, envvar=envvar, shell_complete=shell_complete,
            deprecated=deprecated, hidden=hidden, help=help,
        )

    @property
    def takes_value(self):
        return not self.is_flag and not self.count

    def get_error_hint(self, ctx):
        return " / ".join(f"'{flag}'" for flag in self.opts + self.secondary_opts)

    def _missing_message(self):
        return f"Missing option {self.get_error_hint(None)}."

    def _empty_value(self):
        if self.count:
            return 0
        if self.is_flag:
            return False
        return super()._empty_value()

    def make_metavar(self):
        if self.metavar is not None:
            return self.metavar
        if not self.takes_value:
            return None
        if isinstance(self.type, Choice):
            return self.type.get_metavar()
        return self.name.upper()

    # spec: N-000434 N-000435 N-000436 N-000437 N-000438 N-000439
    def _auto_env_name(self, ctx):
        chain = []
        node = ctx
        while node is not None and node.parent is not None:
            chain.append(node.info_name)
            node = node.parent
        chain.reverse()
        pieces = [ctx.auto_envvar_prefix] + chain + [self.name]
        return "_".join(re.sub(r"[-\s]", "_", str(piece)).upper() for piece in pieces)

    def env_value(self, ctx, raw):
        if self.is_flag:
            return self._flag_from_env(ctx, raw)
        return self._from_text(ctx, raw)

    # spec: N-000221 N-000222 N-000223 N-000224 N-000225 N-000226 N-000227 N-000228 N-000229
    def _flag_from_env(self, ctx, raw):
        text = raw.strip().lower()
        if text in ("true", "1", "yes", "on", "t", "y"):
            return True
        if text in ("false", "0", "no", "off", "f", "n"):
            return False
        if self.flag_value is not None and not isinstance(self.flag_value, bool) \
                and raw == str(self.flag_value):
            return self.flag_value
        if self.type is BOOL and text != "":
            raise BadParameter(f"{raw!r} is not a valid boolean.", ctx=ctx, param=self)
        return _MISSING


# spec: N-000273 N-000274 N-000275 N-000276 N-000277 N-000278 N-000279 N-000297 N-000298 N-000299
class Argument(Parameter):
    """A positional parameter."""

    def __init__(self, param_decls=None, *, type=None, required=None, default=None,
                 nargs=1, envvar=None, deprecated=False, help=None, metavar=None,
                 callback=None, expose_value=True, is_eager=False, shell_complete=None,
                 hidden=False, **extra):
        if extra:
            raise TypeError(f"Unknown argument keyword(s): {', '.join(extra)}")
        decls = list(param_decls or ())
        if len(decls) != 1:
            raise TypeError("An argument takes exactly one destination name.")
        name = decls[0]
        if not name.isidentifier():
            raise TypeError(f"Argument name {name!r} must be a valid identifier.")
        if nargs != -1 and nargs < 1:
            raise TypeError("nargs must be a positive integer or -1 for an argument.")
        if required is None:
            required = default is None and nargs != -1
        if deprecated and required:
            raise TypeError("A deprecated argument cannot be required.")
        resolved = convert_type(type) if type is not None else (
            infer_type(default) or STRING)
        if isinstance(resolved, Tuple):
            nargs = len(resolved.types)
        super().__init__(
            name, type=resolved, required=required, default=default, callback=callback,
            nargs=nargs, metavar=metavar, expose_value=expose_value, is_eager=is_eager,
            envvar=envvar, shell_complete=shell_complete, deprecated=deprecated,
            hidden=hidden, help=help,
        )

    def get_error_hint(self, ctx):
        return f"'{self.name.upper()}'"

    def _missing_message(self):
        return f"Missing argument {self.name.upper()!r}."

    def _deprecation_text(self):
        note = f" {self.deprecation_note}" if self.deprecation_note else ""
        return f"DeprecationWarning: The argument '{self.name}' is deprecated.{note}"


# spec: N-000868 N-000869 N-000870 N-000181 N-000182
def _split_decls(decls):
    """Split declarations into flag names, on/off flag names, and the destination."""
    opts, secondary, name = [], [], None
    for decl in decls:
        if decl[:1] and decl[0] in _PREFIX_CHARS:
            on_name, off_name = _split_pair(decl)
            if off_name is not None:
                opts.append(on_name)
                secondary.append(off_name)
            else:
                opts.append(decl)
        else:
            if name is not None:
                raise TypeError(f"Only one destination name is allowed, got {name!r} and {decl!r}.")
            name = decl
    return opts, secondary, name


def _split_pair(decl):
    start = 2 if decl.startswith("//") else 1
    index = decl.find("/", start)
    if index == -1:
        return decl, None
    on_name, off_name = decl[:index], decl[index + 1:]
    if not on_name or not off_name or off_name[0] not in _PREFIX_CHARS:
        return decl, None
    return on_name, off_name


def _infer_name(opts):
    for flag in opts:
        if flag[:2] in ("--", "//", "++"):
            return flag.lstrip(_PREFIX_CHARS).replace("-", "_")
    if opts:
        return opts[0].lstrip(_PREFIX_CHARS).replace("-", "_")
    return None


def _resolve_option_type(type_, default, is_flag, flag_value, count):
    if type_ is not None:
        return convert_type(type_)
    if is_flag:
        if flag_value is None or isinstance(flag_value, bool):
            return BOOL
        return infer_type(flag_value) or STRING
    if count:
        return INT
    if flag_value is not None:
        return infer_type(flag_value) or STRING
    if default is not None and not callable(default):
        return infer_type(default) or STRING
    return STRING


def _show_help_callback(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    termui.echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


# spec: N-000842 N-000843 N-000844 N-000849 N-000098 N-000099
class Command:
    """A leaf command: parses its parameters and runs a callback."""

    is_group = False
    allow_extra_args = False
    ignore_unknown_options = False
    allow_interspersed_args = True

    def __init__(self, name=None, callback=None, params=None, help=None, short_help=None,
                 epilog=None, options_metavar="[OPTIONS]", context_settings=None,
                 add_help_option=True, no_args_is_help=False, deprecated=False,
                 hidden=False):
        self.name = name
        self.callback = callback
        self.params = list(params or [])
        if help is None and callback is not None:
            help = inspect.getdoc(callback)
        self.help = help
        self.short_help = short_help
        self.epilog = epilog
        self.options_metavar = options_metavar
        self.context_settings = dict(context_settings or {})
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.deprecated = bool(deprecated)
        self.deprecation_note = deprecated if isinstance(deprecated, str) else None
        self.hidden = hidden
        variadic = [p for p in self.params if not p.is_option and p.nargs == -1]
        if len(variadic) > 1:
            raise TypeError("Only one variadic argument is allowed on a command.")

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    # -- parameters -----------------------------------------------------------

    def get_params(self, ctx):
        if ctx._param_list is None:
            params = list(self.params)
            help_option = self.get_help_option(ctx)
            if help_option is not None:
                params.append(help_option)
            ctx._param_list = params
        return ctx._param_list

    # spec: N-000142 N-000143 N-000144 N-000145 N-000146 N-000147
    def get_help_option(self, ctx):
        if not self.add_help_option:
            return None
        taken = {flag for p in self.params if p.is_option
                 for flag in p.opts + p.secondary_opts}
        remaining = [name for name in ctx.help_option_names if name not in taken]
        if not remaining:
            return None
        return Option(remaining, is_flag=True, expose_value=False, is_eager=True,
                      callback=_show_help_callback, help="Show this message and exit.")

    # -- parsing --------------------------------------------------------------

    # spec: N-000846 N-000848 N-000729
    def make_context(self, info_name, args, parent=None, **extra):
        for key, value in self.context_settings.items():
            extra.setdefault(key, value)
        ctx = Context(self, info_name=info_name, parent=parent, **extra)
        with ctx:
            self.parse_args(ctx, list(args))
        return ctx

    def _parse_tokens(self, ctx, args):
        parser = Parser(ctx, self.get_params(ctx), interspersed=ctx.allow_interspersed_args)
        ctx._raw = parser.records
        ctx._cli_order = parser.cli_order
        return parser.parse(args)

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            ctx._pending_help = True
        leftover = self._parse_tokens(ctx, args)
        if leftover and not ctx.resilient_parsing:
            if not ctx.allow_extra_args:
                count = len(leftover)
                raise UsageError(
                    f"Got unexpected extra argument{'s' if count > 1 else ''} "
                    f"({' '.join(leftover)})", ctx)
            if not ctx.ignore_unknown_options:
                for token in leftover:
                    if len(token) > 1 and token[0] in _PREFIX_CHARS:
                        raise NoSuchOption(token, ctx=ctx)
        ctx.args = leftover
        return leftover

    # -- running --------------------------------------------------------------

    def invoke(self, ctx):
        done = set()
        ctx._run_eager(done)
        ctx._check_pending()
        ctx._run_params(done)
        if self.deprecated:
            termui.echo(_deprecation_for_command(self))
        if self.callback is None:
            return None
        return ctx.invoke(self.callback, **ctx.params)

    # spec: N-000842 N-000843 N-000844 N-000845 N-000090 N-000091 N-000092 N-000093
    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True,
             **extra):
        """Run the command as a program, or in-process when standalone mode is off."""
        from .shell_completion import complete_variable_name, handle_completion

        if args is None:
            args = sys.argv[1:]
        else:
            args = list(args)
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else "root"
        var = complete_var or complete_variable_name(prog_name)
        instruction = os.environ.get(var)
        if instruction:
            handle_completion(self, prog_name, instruction, standalone_mode)
            return None
        ctx = None
        try:
            try:
                ctx = self.make_context(prog_name, args, **extra)
                with ctx:
                    rv = self.invoke(ctx)
                if not standalone_mode:
                    return rv
                ctx.exit()
            finally:
                if ctx is not None:
                    ctx.close()
        except Exit as exc:
            if standalone_mode:
                sys.exit(exc.exit_code)
            return exc.exit_code
        except Abort:
            if not standalone_mode:
                raise
            termui.echo("Aborted!", err=True)
            sys.exit(1)
        except (EOFError, KeyboardInterrupt):
            if not standalone_mode:
                raise
            termui.echo(err=True)
            termui.echo("Aborted!", err=True)
            sys.exit(1)
        except OptlynError as exc:
            if not standalone_mode:
                raise
            exc.show()
            sys.exit(exc.exit_code)

    # -- help -----------------------------------------------------------------

    def get_usage(self, ctx):
        return "Usage: " + " ".join(self._usage_pieces(ctx))

    def _usage_pieces(self, ctx):
        pieces = [ctx.command_path]
        params = self.get_params(ctx)
        if any(p.is_option and not p.hidden for p in params):
            pieces.append(self.options_metavar)
        for arg in params:
            if arg.is_option or arg.hidden:
                continue
            placeholder = arg.make_metavar()
            if arg.nargs == -1:
                placeholder += "..."
            if not arg.required:
                placeholder = f"[{placeholder}]"
            pieces.append(placeholder)
        return pieces

    def get_short_help_str(self, limit):
        text = self.short_help
        if text is None:
            text = _first_sentence((self.help or "").split("\f", 1)[0])
        if len(text) > limit:
            text = text[:max(limit - 3, 0)].rstrip() + "..."
        return text

    # spec: N-000103 N-000104 N-000105 N-000812 N-000829
    def get_help(self, ctx):
        width = ctx.get_wrap_width()
        lines = [self.get_usage(ctx)]
        description = (self.help or "").split("\f", 1)[0]
        if self.deprecated:
            note = self.deprecation_note or "This command is deprecated."
            description = f"(Deprecated) {note}\n\n{description}" if description.strip() \
                else f"(Deprecated) {note}"
        described = format_help_text(description, width)
        if described:
            lines.append("")
            lines.extend(described)
        self._append_sections(ctx, lines, width)
        if self.epilog:
            lines.append("")
            lines.extend(format_help_text(self.epilog, width))
        return "\n".join(lines) + "\n"

    def _append_sections(self, ctx, lines, width):
        params = self.get_params(ctx)
        arguments = [(a.make_metavar(), a.help) for a in params
                     if not a.is_option and not a.hidden and a.help]
        if arguments:
            lines.append("")
            lines.append("Positional arguments:")
            lines.extend(format_definition_list(arguments, width))
        options = [(_option_names(o), _option_help(o, ctx)) for o in params
                   if o.is_option and not o.hidden]
        if options:
            lines.append("")
            lines.append("Options:")
            lines.extend(format_definition_list(options, width))


def _deprecation_for_command(cmd):
    note = f" {cmd.deprecation_note}" if cmd.deprecation_note else ""
    return f"DeprecationWarning: The command '{cmd.name}' is deprecated.{note}"


def _first_sentence(text):
    text = " ".join(text.split())
    match = re.search(r"(?<=\.)\s", text)
    return text[:match.start()] if match else text


def _option_names(option):
    if option.secondary_opts:
        names = "/".join([option.opts[0], option.secondary_opts[0]])
    else:
        names = ", ".join(option.opts)
    metavar = option.make_metavar()
    return f"{names} {metavar}" if metavar else names


def _option_help(option, ctx):
    parts = []
    if option.help:
        parts.append(option.help)
    if option.deprecated:
        parts.append("(Deprecated)")
    if isinstance(option.show_default, str):
        parts.append(f"[default: {option.show_default}]")
    else:
        show = option.show_default if option.show_default is not None else ctx.show_default
        hidden_false_flag = option.is_flag and option.default is False
        if show and option.default is not None and not callable(option.default) \
                and not hidden_false_flag:
            parts.append(f"[default: {option.default}]")
    if option.show_envvar and option.envvar:
        parts.append(f"[env var: {', '.join(option.envvar)}]")
    if isinstance(option.type, Choice) and option.show_choices:
        parts.append(f"[choices: {', '.join(option.type.names())}]")
    return "  ".join(parts)


# spec: N-000853 N-000854 N-000855 N-000856
class Group(Command):
    """A command that dispatches to named subcommands."""

    is_group = True
    allow_interspersed_args = False

    def __init__(self, name=None, commands=None, invoke_without_command=False,
                 no_args_is_help=None, subcommand_metavar=None, chain=False,
                 result_callback=None, **kwargs):
        super().__init__(name, **kwargs)
        self.commands = {}
        self.invoke_without_command = invoke_without_command
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        self.no_args_is_help = no_args_is_help
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback
        if commands:
            items = commands.items() if isinstance(commands, Mapping) else \
                ((c.name, c) for c in commands)
            for cmd_name, cmd in items:
                self.add_command(cmd, cmd_name)

    # spec: N-000857 N-000858 N-000859 N-000603 N-000602
    def add_command(self, cmd, name=None):
        name = name or cmd.name
        if self.chain and isinstance(cmd, Group):
            raise TypeError("Groups cannot be nested under a chaining group.")
        self.commands[name] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as command_decorator

        def decorator(f):
            cmd = command_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as group_decorator

        def decorator(f):
            cmd = group_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    # spec: N-000862 N-000863
    def result_callback(self):
        def decorator(f):
            self._result_callback = f
            return f

        return decorator

    # spec: N-000864 N-000403 N-000404
    def list_commands(self, ctx):
        return sorted(self.commands)

    # spec: N-000865 N-000405 N-000406 N-000407
    def get_command(self, ctx, cmd_name):
        return self.commands.get(cmd_name)

    # -- parsing --------------------------------------------------------------

    def parse_args(self, ctx, args):
        leftover = self._parse_tokens(ctx, args)
        ctx.args = leftover
        if not leftover and not self.invoke_without_command and not ctx.resilient_parsing:
            if not args and self.no_args_is_help:
                ctx._pending_help = True
            else:
                ctx._pending_missing = True
        return leftover

    # -- running --------------------------------------------------------------

    # spec: N-000379 N-000380 N-000381 N-000382 N-000383 N-000384 N-000385 N-000386
    def invoke(self, ctx):
        done = set()
        ctx._run_eager(done)
        ctx._check_pending()
        ctx._run_params(done)
        if self.deprecated:
            termui.echo(_deprecation_for_command(self))
        if self.chain:
            return self._invoke_chain(ctx)
        if not ctx.args:
            rv = ctx.invoke(self.callback, **ctx.params) if self.callback else None
            if self._result_callback is not None:
                return ctx.invoke(self._result_callback, rv, **ctx.params)
            return rv
        name = ctx.args[0]
        cmd = self.get_command(ctx, name)
        if cmd is None:
            raise UsageError(f"No such command {name!r}.", ctx)
        ctx.invoked_subcommand = name
        if self.callback is not None:
            ctx.invoke(self.callback, **ctx.params)
        sub_ctx = cmd.make_context(name, ctx.args[1:], parent=ctx)
        with sub_ctx:
            sub_rv = cmd.invoke(sub_ctx)
        if self._result_callback is not None:
            return ctx.invoke(self._result_callback, sub_rv, **ctx.params)
        return sub_rv

    # spec: N-000584 N-000585 N-000586 N-000587 N-000588 N-000594 N-000595
    def _invoke_chain(self, ctx):
        subs = []
        rest = list(ctx.args)
        while rest:
            name = rest[0]
            cmd = self.get_command(ctx, name)
            if cmd is None:
                raise UsageError(f"No such command {name!r}.", ctx)
            sub_ctx = cmd.make_context(name, rest[1:], parent=ctx,
                                       allow_interspersed_args=False,
                                       allow_extra_args=True)
            subs.append((cmd, sub_ctx))
            rest = list(sub_ctx.args)
        ctx.invoked_subcommand = _CHAIN if subs else None
        if self.callback is not None:
            ctx.invoke(self.callback, **ctx.params)
        results = []
        for cmd, sub_ctx in subs:
            with sub_ctx:
                results.append(cmd.invoke(sub_ctx))
            sub_ctx._run_closers()
        if self._result_callback is not None:
            ctx.invoke(self._result_callback, results, **ctx.params)
        return results

    # -- help -----------------------------------------------------------------

    def _usage_pieces(self, ctx):
        pieces = super()._usage_pieces(ctx)
        metavar = self.subcommand_metavar
        if self.chain:
            pieces.append(metavar or "COMMAND [ARGS]...")
            pieces.append("[COMMAND [ARGS]...]...")
        elif self.invoke_without_command:
            pieces.append(metavar or "[COMMAND] [ARGS]...")
        else:
            pieces.append(metavar or "COMMAND [ARGS]...")
        return pieces

    def _append_sections(self, ctx, lines, width):
        super()._append_sections(ctx, lines, width)
        rows = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            rows.append((name, cmd.get_short_help_str(max(width - 32, 20))))
        if rows:
            lines.append("")
            lines.append("Commands:")
            lines.extend(format_definition_list(rows, width))


# spec: N-000866 N-000867 N-000412 N-000413 N-000414 N-000415
class CommandCollection(Group):
    """A group that presents the subcommands of several source groups."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = set()
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None
