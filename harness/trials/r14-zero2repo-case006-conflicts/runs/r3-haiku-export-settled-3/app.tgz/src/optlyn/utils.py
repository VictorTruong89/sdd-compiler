"""File, path and application-directory helpers."""
import io
import os
import re
import sys
import tempfile

from .exceptions import FileError

WRITE_MODE_CHARS = "wax+"


def is_writing(mode):
    return any(char in mode for char in WRITE_MODE_CHARS)


class ProxyStream:
    """Wraps a standard stream so that closing it does not close the real one."""

    def __init__(self, stream, detach=False):
        self._stream = stream
        self._detach = detach

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __iter__(self):
        return iter(self._stream)

    def __next__(self):
        return next(self._stream)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def close(self):
        try:
            self._stream.flush()
        except (OSError, ValueError):
            pass
        if self._detach:
            self._stream.detach()
            self._detach = False


def _dash_stream(mode, encoding, errors):
    writing = is_writing(mode)
    base = sys.stdout if writing else sys.stdin
    if "b" in mode:
        return ProxyStream(base.buffer)
    if encoding:
        wrapper = io.TextIOWrapper(
            base.buffer, encoding=encoding, errors=errors, write_through=True
        )
        return ProxyStream(wrapper, detach=True)
    return ProxyStream(base)


class LazyFile:
    """A file that opens on first I/O (lazy) and may replace its target on close (atomic)."""

    def __init__(self, filename, mode, encoding=None, errors="strict", atomic=False):
        self.name = filename
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._file = None
        self._temp_name = None
        self._closed = False

    def _ensure(self):
        if self._file is None:
            target = self.name
            try:
                if self.atomic:
                    folder = os.path.dirname(os.path.abspath(self.name))
                    fd, temp_name = tempfile.mkstemp(dir=folder, prefix=".optlyn-", suffix=".tmp")
                    os.close(fd)
                    self._temp_name = temp_name
                    target = temp_name
                binary = "b" in self.mode
                self._file = open(
                    target,
                    self.mode,
                    encoding=None if binary else self.encoding,
                    errors=None if binary else self.errors,
                )
            except OSError as exc:
                raise FileError(
                    f"Could not open file '{self.name}': {exc.strerror or exc}"
                ) from exc
        return self._file

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return getattr(self._ensure(), name)

    def __iter__(self):
        return iter(self._ensure())

    def __next__(self):
        return next(self._ensure())

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def close(self):
        if self._closed:
            return
        self._closed = True
        if self._file is not None:
            self._file.close()
            if self.atomic and self._temp_name is not None:
                os.replace(self._temp_name, self.name)


# spec: N-000522 N-000523 N-000524 N-000525 N-000526 N-000527 N-000528 N-000529 N-000530 N-000531 N-000532 N-000533 N-000534 N-000535 N-000536 N-000569 N-000570 N-000571 N-000572 N-000573
def open_stream(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open ``filename``; ``-`` selects the standard stream for the mode."""
    if filename == "-":
        return _dash_stream(mode, encoding, errors)
    if not is_writing(mode) and not atomic and not lazy:
        binary = "b" in mode
        return open(
            filename,
            mode,
            encoding=None if binary else encoding,
            errors=None if binary else errors,
        )
    handle = LazyFile(filename, mode, encoding, errors, atomic)
    if not lazy:
        handle._ensure()
    return handle


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file or standard stream; see :func:`open_stream`."""
    return open_stream(os.fspath(filename), mode, encoding, errors, lazy, atomic)


# spec: N-000566 N-000567 N-000568
def format_filename(filename, shorten=False):
    """Return ``filename`` as text that can always be printed as strict UTF-8."""
    if isinstance(filename, bytes):
        text = os.fsdecode(filename)
    else:
        text = os.fspath(filename)
    if shorten:
        text = os.path.basename(text)
    return text.encode("utf-8", "backslashreplace").decode("utf-8")


# spec: N-000664 N-000665 N-000666 N-000667 N-000668
def get_app_dir(app_name, roaming=True, force_posix=False):
    """Return the per-user configuration directory for ``app_name``."""
    home = os.path.expanduser("~")
    is_windows = sys.platform.startswith("win")
    if is_windows and not force_posix:
        base = os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming")
        return os.path.join(base, app_name)
    folder = re.sub(r"\s+", "-", app_name.lower())
    if force_posix:
        return os.path.join(home, "." + folder)
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    config_home = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(config_home, folder)
