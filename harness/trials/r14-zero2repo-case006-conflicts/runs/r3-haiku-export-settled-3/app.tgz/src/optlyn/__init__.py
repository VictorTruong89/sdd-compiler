"""Optlyn: a composable toolkit for building command line interfaces."""
from .core import Argument, Command, CommandCollection, Context, Group, Option, Parameter
from .decorators import (
    argument, command, confirmation_option, custom_version_option, group,
    help_option, make_pass_decorator, option, pass_context, pass_obj,
    password_option, version_option,
)
from .exceptions import Abort, BadParameter, UsageError
from .globals import get_current_context
from .param_types import (
    BOOL, FLOAT, INT, UNPROCESSED, UUID, STRING, Choice, DateTime, File, FloatRange,
    IntRange, ParamType, Path, Tuple,
)
from .termui import (
    clear, confirm, echo, echo_via_pager, edit, get_pager_file, getchar, launch,
    pause, progressbar, prompt, secho, style, unstyle,
)
from .utils import format_filename, get_app_dir, open_file

__version__ = "0.1.0"

__all__ = [
    "Abort", "Argument", "BadParameter", "BOOL", "Choice", "Command", "CommandCollection",
    "Context", "DateTime", "File", "FLOAT", "FloatRange", "Group", "INT", "IntRange",
    "Option", "Parameter", "ParamType", "Path", "STRING", "Tuple", "UNPROCESSED", "UUID",
    "UsageError", "argument", "clear", "command", "confirm", "confirmation_option",
    "custom_version_option", "echo", "echo_via_pager", "edit", "format_filename",
    "get_app_dir", "get_current_context", "get_pager_file", "getchar", "group",
    "help_option", "launch", "make_pass_decorator", "open_file", "option", "pass_context",
    "pass_obj", "pause", "password_option", "progressbar", "prompt", "secho", "style",
    "unstyle", "version_option",
]
