"""In-process runner for invoking commands in tests: ``optlyn.testing.CliRunner``."""
import contextlib
import io
import os
import shlex
import sys
import tempfile

from .exceptions import OptlynError


class _Sink(io.BytesIO):
    """A byte sink that also appends everything written to a shared, ordered buffer."""

    def __init__(self, combined):
        super().__init__()
        self._combined = combined

    def write(self, data):
        self._combined.extend(data)
        return super().write(data)


class _InputStream(io.TextIOWrapper):
    """Standard input for the runner; optionally echoes the lines that are read."""

    def __init__(self, data, charset, echo_to=None):
        super().__init__(io.BytesIO(data), encoding=charset)
        self._echo_to = echo_to
        self.echoes = echo_to is not None

    def readline(self, *args):
        line = super().readline(*args)
        if self._echo_to is not None and line:
            self._echo_to.write(line)
            self._echo_to.flush()
        return line


class _Capture:
    """Holds the captured bytes of one invocation."""

    def __init__(self, runner, data):
        self.runner = runner
        self.combined = bytearray()
        self.stdout_sink = _Sink(self.combined)
        self.stderr_sink = _Sink(self.combined)
        self.stdin = _InputStream(data, runner.charset)
        self.stdout = io.TextIOWrapper(self.stdout_sink, encoding=runner.charset,
                                       write_through=True)
        self.stderr = io.TextIOWrapper(self.stderr_sink, encoding=runner.charset,
                                       write_through=True)
        self._fd_files = None

    def results(self):
        if self._fd_files is None:
            return (self.stdout_sink.getvalue(), self.stderr_sink.getvalue(),
                    bytes(self.combined))
        out_bytes, err_bytes = self._fd_files
        return out_bytes, err_bytes, out_bytes + err_bytes


class Result:
    """The outcome of :meth:`CliRunner.invoke`."""

    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value,
                 exit_code, exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self):
        return self.output_bytes.decode(self.runner.charset, "replace")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    def __repr__(self):
        return f"<Result exit_code={self.exit_code!r}>"


# spec: N-001006 N-001007 N-001008 N-001009 N-001010 N-001011 N-001012 N-000734 N-000735 N-000736 N-000737 N-000738 N-000739 N-000740 N-000741
class CliRunner:
    """Invokes a command in-process with captured standard streams."""

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        """Replace the standard streams and environment for the duration of a block.

        Yields a capture object whose ``results()`` gives the captured bytes.
        """
        if isinstance(input, str):
            data = input.encode(self.charset)
        elif isinstance(input, bytes):
            data = input
        else:
            data = b""
        merged_env = dict(self.env)
        merged_env.update(env or {})
        saved_env = {key: os.environ.get(key) for key in merged_env}
        for key, value in merged_env.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)
        saved_streams = (sys.stdin, sys.stdout, sys.stderr)
        capture = _Capture(self, data)
        if self.echo_stdin:
            capture.stdin = _InputStream(data, self.charset, echo_to=capture.stdout)
        if self.capture == "fd":
            self._start_fd_capture(capture, data)
        sys.stdin, sys.stdout, sys.stderr = capture.stdin, capture.stdout, capture.stderr
        try:
            yield capture
        finally:
            for stream in (capture.stdout, capture.stderr):
                try:
                    stream.flush()
                except (OSError, ValueError):
                    pass
            sys.stdin, sys.stdout, sys.stderr = saved_streams
            if self.capture == "fd":
                self._stop_fd_capture(capture)
            for key, value in saved_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def _start_fd_capture(self, capture, data):
        out_file = tempfile.TemporaryFile()
        err_file = tempfile.TemporaryFile()
        capture._fd_files = (out_file, err_file)
        capture._saved_fds = (os.dup(1), os.dup(2))
        sys.stdout.flush()
        sys.stderr.flush()
        os.dup2(out_file.fileno(), 1)
        os.dup2(err_file.fileno(), 2)
        capture.stdout = io.TextIOWrapper(open(1, "wb", closefd=False),
                                          encoding=self.charset, write_through=True)
        capture.stderr = io.TextIOWrapper(open(2, "wb", closefd=False),
                                          encoding=self.charset, write_through=True)

    def _stop_fd_capture(self, capture):
        for stream in (capture.stdout, capture.stderr):
            try:
                stream.flush()
            except (OSError, ValueError):
                pass
        os.dup2(capture._saved_fds[0], 1)
        os.dup2(capture._saved_fds[1], 2)
        os.close(capture._saved_fds[0])
        os.close(capture._saved_fds[1])
        out_file, err_file = capture._fd_files
        out_file.seek(0)
        err_file.seek(0)
        out_bytes, err_bytes = out_file.read(), err_file.read()
        out_file.close()
        err_file.close()
        capture._fd_files = (out_bytes, err_bytes)

    # spec: N-001006 N-001007 N-000726 N-000727 N-000744 N-000745 N-000746 N-000747
    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None,
               color=False, **extra):
        """Run ``cli`` with the token list ``args`` and return a :class:`Result`."""
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if isinstance(args, str):
            args = shlex.split(args)
        args = list(args or [])
        prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
        standalone = extra.pop("standalone_mode", True)
        extra.setdefault("color", color)
        exit_code = 0
        exception = None
        exc_info = None
        return_value = None
        with self.isolation(input=input, env=env, color=color) as capture:
            try:
                return_value = cli.main(args=args, prog_name=prog_name,
                                        standalone_mode=standalone, **extra)
            except SystemExit as exc:
                if exc.code is None:
                    exit_code = 0
                elif isinstance(exc.code, int):
                    exit_code = exc.code
                else:
                    exit_code = 1
            except Exception as exc:
                if not catch_exceptions:
                    raise
                exception = exc
                exit_code = exc.exit_code if isinstance(exc, OptlynError) else 1
                exc_info = sys.exc_info()
        stdout_bytes, stderr_bytes, output_bytes = capture.results()
        return Result(self, stdout_bytes, stderr_bytes, output_bytes, return_value,
                      exit_code, exception, exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Change into a new empty directory for the block; the directory is left in place."""
        cwd = os.getcwd()
        path = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
