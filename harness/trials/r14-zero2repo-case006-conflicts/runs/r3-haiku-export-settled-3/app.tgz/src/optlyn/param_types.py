"""Parameter types: conversion of command-line tokens into values."""
import datetime as _dt
import enum
import os
import pathlib
import stat
import uuid

from .exceptions import BadParameter, FileError
from .utils import open_stream


class CompletionItem:
    """A shell-completion suggestion with optional help text and kind."""

    def __init__(self, value, help=None, type="plain"):
        self.value = str(value)
        self.help = help
        self.type = type

    def __repr__(self):
        return f"CompletionItem({self.value!r}, help={self.help!r}, type={self.type!r})"


class PathRequest:
    """Asks the shell to complete a filesystem path (``kind`` is ``file`` or ``dir``)."""

    def __init__(self, kind, incomplete):
        self.kind = kind
        self.incomplete = incomplete

    def __repr__(self):
        return f"PathRequest({self.kind!r}, {self.incomplete!r})"


class ParamType:
    """Base class for parameter types. Subclasses set ``name`` and implement ``convert``."""

    name = "text"
    is_composite = False

    def __call__(self, value, param=None, ctx=None):
        if value is not None:
            return self.convert(value, param, ctx)
        return value

    def convert(self, value, param, ctx):
        return value

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def shell_complete(self, ctx, param, incomplete):
        return []

    def split_envvar_value(self, rv):
        return rv.split()


class _StringType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        return str(value)


class _UnprocessedType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        return value


# spec: N-000321 N-000322 N-000323 N-000324
class _IntType(ParamType):
    name = "integer"

    def convert(self, value, param, ctx):
        if isinstance(value, int) and not isinstance(value, bool):
            return value
        try:
            return int(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class _FloatType(ParamType):
    name = "float"

    def convert(self, value, param, ctx):
        if isinstance(value, float):
            return value
        try:
            return float(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


_TRUE_TEXT = {"1", "true", "t", "yes", "y", "on"}
_FALSE_TEXT = {"0", "false", "f", "no", "n", "off"}


# spec: N-000332 N-000333 N-000334 N-000335 N-000336
class _BoolType(ParamType):
    name = "boolean"

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE_TEXT:
            return True
        if text in _FALSE_TEXT:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class _UUIDType(ParamType):
    name = "uuid"

    def convert(self, value, param, ctx):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


STRING = _StringType()
INT = _IntType()
FLOAT = _FloatType()
BOOL = _BoolType()
UUID = _UUIDType()
UNPROCESSED = _UnprocessedType()


class FuncParamType(ParamType):
    """Adapts a conversion function ``f(token) -> value`` that refuses with ``ValueError``."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text")

    def convert(self, value, param, ctx):
        try:
            return self.func(value)
        except ValueError:
            self.fail(f"{value!r} is not a valid {self.name}.", param, ctx)


def convert_type(ty):
    """Return a ParamType for ``ty`` (an instance, a Python builtin, or a function)."""
    if ty is None:
        return STRING
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, type):
        if issubclass(ty, bool):
            return BOOL
        if issubclass(ty, int):
            return INT
        if issubclass(ty, float):
            return FLOAT
        if issubclass(ty, str):
            return STRING
        if issubclass(ty, uuid.UUID):
            return UUID
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"Unsupported parameter type: {ty!r}")


def infer_type(value):
    """Infer a built-in type from a default value, or return ``None``."""
    if isinstance(value, bool):
        return BOOL
    if isinstance(value, int):
        return INT
    if isinstance(value, float):
        return FLOAT
    if isinstance(value, (list, tuple)) and value:
        return infer_type(value[0])
    return None


# spec: N-000339 N-000340 N-000341 N-000342 N-000343 N-000373 N-000374 N-000923 N-000924
class Choice(ParamType):
    """A closed list of allowed values, or the member names of an enumeration."""

    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        self.choices = choices
        self.case_sensitive = case_sensitive

    def _entries(self):
        if isinstance(self.choices, type) and issubclass(self.choices, enum.Enum):
            return [(member.name, member) for member in self.choices]
        return [(str(choice), choice) for choice in self.choices]

    def _normalize(self, text, ctx):
        if ctx is not None and ctx.token_normalize_func is not None:
            text = ctx.token_normalize_func(text)
        if not self.case_sensitive:
            text = text.casefold()
        return text

    def names(self):
        return [name for name, _ in self._entries()]

    def convert(self, value, param, ctx):
        token = self._normalize(str(value), ctx)
        for name, original in self._entries():
            if self._normalize(name, ctx) == token:
                return original
        self.fail(
            f"{value!r} is not one of {', '.join(repr(n) for n in self.names())}.",
            param, ctx,
        )

    def get_metavar(self):
        return "[" + "|".join(self.names()) + "]"

    def shell_complete(self, ctx, param, incomplete):
        return [
            CompletionItem(name) for name in self.names()
            if name.startswith(incomplete)
        ]


DEFAULT_DATETIME_FORMATS = ["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]


# spec: N-000344 N-000345 N-000346 N-000347 N-000348
class DateTime(ParamType):
    """Parses text with the first matching ``strftime`` format."""

    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(DEFAULT_DATETIME_FORMATS if formats is None else formats)

    def convert(self, value, param, ctx):
        if isinstance(value, _dt.datetime):
            return value
        text = str(value).strip()
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(text, fmt)
            except ValueError:
                continue
        self.fail(
            f"{value!r} does not match the formats {', '.join(self.formats)}.",
            param, ctx,
        )


# spec: N-000349 N-000350 N-000351 N-000352 N-000353 N-000354 N-000355 N-000356
class _RangeType(ParamType):
    base = None
    kind = "number"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if min is not None and max is not None and min > max:
            raise ValueError("The minimum bound must not exceed the maximum bound.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def _describe(self):
        low = "" if self.min is None else (f"{self.min}<" if self.min_open else f"{self.min}<=")
        high = "" if self.max is None else (f"<{self.max}" if self.max_open else f"<={self.max}")
        if not low and not high:
            return "any value"
        return f"{low}x{high}"

    def convert(self, value, param, ctx):
        number = self.base.convert(value, param, ctx)
        below = self.min is not None and (
            number <= self.min if self.min_open else number < self.min
        )
        above = self.max is not None and (
            number >= self.max if self.max_open else number > self.max
        )
        if not below and not above:
            return number
        if self.clamp:
            return self._clamp(number, below)
        self.fail(f"{value!r} is not in the range {self._describe()}.", param, ctx)

    def _clamp(self, number, below):
        raise NotImplementedError


class IntRange(_RangeType):
    name = "integer range"
    base = INT

    def _clamp(self, number, below):
        if below:
            return self.min + 1 if self.min_open else self.min
        return self.max - 1 if self.max_open else self.max


class FloatRange(_RangeType):
    name = "float range"
    base = FLOAT

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min_open or max_open):
            raise ValueError("Clamping is only allowed when both bounds are closed.")
        super().__init__(min, max, min_open, max_open, clamp)

    def _clamp(self, number, below):
        return float(self.min) if below else float(self.max)


# spec: N-000357 N-000926
class Tuple(ParamType):
    """A fixed-length product of inner types, one converted value per position."""

    name = "tuple"
    is_composite = True

    def __init__(self, types):
        self.types = [convert_type(ty) for ty in types]

    def convert(self, value, param, ctx):
        items = tuple(value)
        if len(items) != len(self.types):
            self.fail(f"Expected {len(self.types)} values, got {len(items)}.", param, ctx)
        return tuple(ty.convert(item, param, ctx) for ty, item in zip(self.types, items))


_FILE_MODES = ("r", "w", "rb", "wb")


# spec: N-000358 N-000522 N-000529 N-000553
class File(ParamType):
    """Opens a file; the value is an open file object."""

    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in _FILE_MODES:
            raise ValueError(f"Unsupported file mode {mode!r}.")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def convert(self, value, param, ctx):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        writing = "w" in self.mode
        lazy = writing if self.lazy is None else self.lazy
        try:
            return open_stream(
                str(value), self.mode, self.encoding, self.errors, lazy, self.atomic
            )
        except (OSError, FileError) as exc:
            reason = getattr(exc, "strerror", None) or str(exc)
            self.fail(f"Could not open file {str(value)!r}: {reason}", param, ctx)

    def split_envvar_value(self, rv):
        return rv.split(os.pathsep)

    def shell_complete(self, ctx, param, incomplete):
        return [PathRequest("file", incomplete)]


# spec: N-000359 N-000538 N-000539 N-000540 N-000541 N-000542 N-000543 N-000544 N-000545
class Path(ParamType):
    """Validates a filesystem path and delivers the path (not an open file)."""

    name = "path"

    def __init__(self, exists=False, file_okay=True, dir_okay=True, writable=False,
                 readable=True, resolve_path=False, allow_dash=False, path_type=None,
                 executable=False):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def _deliver(self, text):
        if self.path_type is pathlib.Path:
            return pathlib.Path(text)
        return text

    def convert(self, value, param, ctx):
        text = os.fspath(value)
        if self.allow_dash and text == "-":
            return self._deliver("-")
        if self.resolve_path:
            text = os.path.realpath(text)
        try:
            mode = os.stat(text).st_mode
        except OSError:
            if not self.exists:
                return self._deliver(text)
            self.fail(f"{text!r} does not exist.", param, ctx)
        if not self.file_okay and stat.S_ISREG(mode):
            self.fail(f"{text!r} is a file.", param, ctx)
        if not self.dir_okay and stat.S_ISDIR(mode):
            self.fail(f"{text!r} is a directory.", param, ctx)
        if self.readable and not os.access(text, os.R_OK):
            self.fail(f"{text!r} is not readable.", param, ctx)
        if self.writable and not os.access(text, os.W_OK):
            self.fail(f"{text!r} is not writable.", param, ctx)
        if self.executable and not os.access(text, os.X_OK):
            self.fail(f"{text!r} is not executable.", param, ctx)
        return self._deliver(text)

    def split_envvar_value(self, rv):
        return rv.split(os.pathsep)

    def shell_complete(self, ctx, param, incomplete):
        kind = "dir" if self.dir_okay and not self.file_okay else "file"
        return [PathRequest(kind, incomplete)]
