"""Text wrapping and help-page layout helpers."""
import re
import textwrap


# spec: N-000669 N-000126 N-000127 N-000128 N-000129 N-000130 N-000131
def wrap_text(text, width=100, initial_indent="", subsequent_indent="", preserve_paragraphs=False):
    """Wrap ``text`` to ``width`` columns. Accepts any string."""
    text = "" if text is None else str(text)
    width = max(int(width), 1)
    if not preserve_paragraphs:
        flat = " ".join(part.strip() for part in text.splitlines()).strip()
        return textwrap.fill(
            flat, width=width, initial_indent=initial_indent,
            subsequent_indent=subsequent_indent, break_long_words=False,
            break_on_hyphens=False,
        ) if flat else ""
    return "\n\n".join(
        _wrap_paragraph(paragraph, width, initial_indent, subsequent_indent)
        for paragraph in _split_paragraphs(text)
    )


def _split_paragraphs(text):
    return [part for part in re.split(r"\n\s*\n", text.strip("\n")) if part.strip()]


def _wrap_paragraph(paragraph, width, initial_indent, subsequent_indent):
    lines = paragraph.split("\n")
    if lines[0].strip() == "\b":
        # A backspace-only first line keeps its line breaks and is not rewrapped.
        kept = [line for line in lines[1:]]
        return "\n".join(initial_indent + line for line in kept)
    flat = " ".join(line.strip() for line in lines).strip()
    return textwrap.fill(
        flat, width=width, initial_indent=initial_indent,
        subsequent_indent=subsequent_indent, break_long_words=False,
        break_on_hyphens=False,
    )


def format_help_text(text, width):
    """Return the lines of a help description rewrapped to ``width`` columns."""
    text = text.split("\f", 1)[0]
    if not text.strip():
        return []
    rendered = []
    for paragraph in _split_paragraphs(text):
        lines = paragraph.split("\n")
        if lines[0].strip() == "\b":
            rendered.extend(line for line in lines[1:])
        else:
            rendered.extend(
                textwrap.wrap(
                    " ".join(line.strip() for line in lines).strip(),
                    width=max(width, 10), break_long_words=False, break_on_hyphens=False,
                )
            )
        rendered.append("")
    return rendered[:-1]


def format_definition_list(rows, width, col_max=30, col_spacing=2, indent=2):
    """Lay out ``(first, second)`` rows as an indented two-column list."""
    if not rows:
        return []
    first_width = min(max(len(first) for first, _ in rows), col_max)
    text_width = max(width - indent - first_width - col_spacing, 20)
    lines = []
    for first, second in rows:
        pad = " " * indent
        if not second:
            lines.append(f"{pad}{first}")
            continue
        wrapped = textwrap.wrap(second, width=text_width, break_long_words=False,
                                break_on_hyphens=False) or [""]
        if len(first) <= first_width:
            lines.append(f"{pad}{first.ljust(first_width)}{' ' * col_spacing}{wrapped[0]}")
        else:
            lines.append(f"{pad}{first}")
            wrapped_lines = wrapped
            lines.extend(" " * (indent + first_width + col_spacing) + line for line in wrapped_lines)
            continue
        for line in wrapped[1:]:
            lines.append(" " * (indent + first_width + col_spacing) + line)
    return lines
