"""Groups, chaining, lazy subcommand lookup, and command collections (FP-06, FP-10)."""

from __future__ import annotations

from .command import Command, _entry, _HelpUsage
from .context import Context
from .exceptions import NoSuchCommand
from .params import Argument

_CHAIN = object()


class Group(Command):
    """A command that dispatches to named subcommands."""

    is_group = True

    def __init__(
        self,
        name=None,
        commands=None,
        invoke_without_command=False,
        no_args_is_help=None,
        subcommand_metavar=None,
        chain=False,
        result_callback=None,
        allow_interspersed_args=None,
        **kwargs,
    ) -> None:
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        if allow_interspersed_args is None:
            allow_interspersed_args = False
        super().__init__(
            name,
            no_args_is_help=no_args_is_help,
            allow_interspersed_args=allow_interspersed_args,
            **kwargs,
        )
        self.invoke_without_command = invoke_without_command
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback
        self.commands: dict = {}
        if isinstance(commands, dict):
            self.commands.update(commands)
        elif commands:
            for cmd in commands:
                self.add_command(cmd)

    # ----- registration -------------------------------------------------------

    def add_command(self, cmd, name=None) -> None:
        if self.chain and cmd.is_group:
            raise ValueError("Groups cannot be nested under a chaining group.")
        self.commands[name or cmd.name] = cmd

    def command(self, *args, **kwargs):
        """Decorator that creates a leaf command and registers it here."""
        from .decorators import command as make_command

        if len(args) == 1 and callable(args[0]) and not isinstance(args[0], str):
            cmd = make_command()(args[0])
            self.add_command(cmd)
            return cmd

        def decorator(f):
            cmd = make_command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        """Decorator that creates a subgroup and registers it here."""
        from .decorators import group as make_group

        if len(args) == 1 and callable(args[0]) and not isinstance(args[0], str):
            cmd = make_group()(args[0])
            self.add_command(cmd)
            return cmd

        def decorator(f):
            cmd = make_group(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self):
        """Decorator that registers the callback receiving subcommand return values."""

        def decorator(f):
            self._result_callback = f
            return f

        return decorator

    # ----- lookup (override points for lazy loading) ---------------------------

    def list_commands(self, ctx) -> list:
        return list(self.commands)

    def get_command(self, ctx, cmd_name):
        cmd = self.commands.get(cmd_name)
        if cmd is None and ctx.token_normalize_func is not None:
            wanted = ctx.token_normalize_func(cmd_name)
            for key, value in self.commands.items():
                if ctx.token_normalize_func(key) == wanted:
                    return value
        return cmd

    # ----- parsing and dispatch -------------------------------------------------

    def _group_need(self) -> int:
        return sum(p.nargs for p in self.params if isinstance(p, Argument) and not p.variadic)

    def _run(self, ctx, args):
        if not args and self.no_args_is_help:
            raise _HelpUsage("", ctx)
        st, items, rest = self._parse(ctx, args)
        need = self._group_need()
        has_name = len(items) > need
        name = items[need][0] if has_name else None
        self._bind_arguments(ctx, st, items[:need] if has_name else items)
        child_args = [t for t, _ in items[need + 1 :]] + rest if has_name else []

        if name is None:
            if not (self.invoke_without_command or self.chain):
                raise NoSuchCommand("Missing command.", ctx=ctx)
            self._resolve(ctx, st)
            if self.chain:
                ctx.invoked_subcommand = None
                rv = self.run_callback_with_context(ctx)
                return self._finish(ctx, [])
            rv = self.run_callback_with_context(ctx)
            return self._finish(ctx, rv)

        if self.chain:
            return self._run_chain(ctx, st, [name] + child_args)

        child = self.get_command(ctx, name)
        if child is None:
            raise NoSuchCommand(f"No such command {name!r}.", ctx=ctx)
        ctx.invoked_subcommand = child.name
        self._resolve(ctx, st)
        self.run_callback_with_context(ctx)
        child_ctx = self._child_context(ctx, child)
        rv = child._run(child_ctx, child_args)
        return self._finish(ctx, rv)

    def _run_chain(self, ctx, st, tokens):
        ctx.invoked_subcommand = _CHAIN
        self._resolve(ctx, st)
        self.run_callback_with_context(ctx)
        results = []
        pending = tokens
        while pending:
            child = self.get_command(ctx, pending[0])
            if child is None:
                raise NoSuchCommand(f"No such command {pending[0]!r}.", ctx=ctx)
            end = 1
            while end < len(pending) and self.get_command(ctx, pending[end]) is None:
                end += 1
            child_ctx = self._child_context(ctx, child)
            results.append(child._run(child_ctx, pending[1:end]))
            pending = pending[end:]
        return self._finish(ctx, results)

    def _child_context(self, ctx, child):
        kwargs = dict(child.context_settings)
        if isinstance(ctx.default_map, dict):
            kwargs.setdefault("default_map", ctx.default_map.get(child.name))
        return Context(child, parent=ctx, **kwargs)

    def _finish(self, ctx, value):
        if self._result_callback is None:
            return value
        kwargs = {p.name: ctx.params.get(p.name) for p in self.params if p.expose_value}
        return self._result_callback(value, **kwargs)

    # ----- help ---------------------------------------------------------------

    def get_usage(self, ctx) -> str:
        base = super().get_usage(ctx)
        sub = "[COMMAND] [ARGS]..." if self.invoke_without_command else "COMMAND [ARGS]..."
        if self.subcommand_metavar:
            sub = self.subcommand_metavar
        if self.chain:
            sub += " [COMMAND [ARGS]...]..."
        return f"{base} {sub}"

    def _help_extra_sections(self, ctx, width):
        rows = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            rows += _entry(name, cmd.get_short_help() or "", width)
        if not rows:
            return []
        return ["Commands:"] + rows + [""]


class CommandCollection(Group):
    """A group whose subcommands are the union of several source groups."""

    def __init__(self, name=None, sources=None, **kwargs) -> None:
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx) -> list:
        names: list = []
        for source in self.sources:
            for name in source.list_commands(ctx):
                if name not in names:
                    names.append(name)
        return names

    def get_command(self, ctx, cmd_name):
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None
