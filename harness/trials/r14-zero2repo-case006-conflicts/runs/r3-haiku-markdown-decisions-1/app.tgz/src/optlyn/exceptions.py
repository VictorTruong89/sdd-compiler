"""Exception classes and exit statuses for Optlyn."""

from __future__ import annotations

EXIT_SUCCESS = 0
EXIT_ABORT = 1
EXIT_USAGE = 2


class OptlynError(Exception):
    """Base class for errors signalled by Optlyn."""

    exit_code = EXIT_ABORT

    def __init__(self, message: str = "") -> None:
        super().__init__(message)
        self.message = message

    def show(self, file=None) -> None:
        import sys

        print(f"Error: {self.message}", file=file or sys.stderr)


class UsageError(OptlynError):
    """Incorrect command line usage; exit status 2."""

    exit_code = EXIT_USAGE

    def __init__(self, message: str = "", ctx=None) -> None:
        super().__init__(message)
        self.ctx = ctx

    def show(self, file=None) -> None:
        import sys

        out = file or sys.stderr
        print(self.message, file=out)
        if self.ctx is not None and self.ctx.command is not None:
            print(self.ctx.get_usage(), file=out)
            print(
                f"Try '{self.ctx.command_path} {self.ctx.help_option_names[0]}' for help.",
                file=out,
            )


class BadParameter(UsageError):
    """A value was refused. ``param`` identifies the offending parameter."""

    def __init__(self, message: str = "", ctx=None, param=None, param_hint=None) -> None:
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self) -> str:
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.hint
        if hint:
            return f"Invalid value for {hint}: {self.message}"
        return f"Invalid value: {self.message}"

    def show(self, file=None) -> None:
        import sys

        out = file or sys.stderr
        print(self.format_message(), file=out)
        if self.ctx is not None and self.ctx.command is not None:
            print(self.ctx.get_usage(), file=out)


class MissingParameter(BadParameter):
    """A required parameter was not supplied by any source."""

    def format_message(self) -> str:
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.hint
        return f"Missing parameter: {hint}" if hint else "Missing parameter"


class NoSuchOption(UsageError):
    """An unknown option token."""


class NoSuchCommand(UsageError):
    """An unknown subcommand name, or a missing subcommand."""


class Abort(OptlynError):
    """The user or author aborted the invocation; exit status 1."""

    exit_code = EXIT_ABORT

    def show(self, file=None) -> None:
        import sys

        print("Aborted!", file=file or sys.stderr)


class Exit(Exception):
    """Author clean stop, or an eager flag finishing the invocation."""

    def __init__(self, code: int = 0) -> None:
        super().__init__(code)
        self.exit_code = code
