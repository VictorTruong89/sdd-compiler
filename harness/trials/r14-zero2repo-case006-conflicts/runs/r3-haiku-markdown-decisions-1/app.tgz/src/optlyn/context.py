"""Invocation context, value sources, and context-aware callback decorators (FP-07)."""

from __future__ import annotations

import contextlib
import enum
import functools
import threading

from .exceptions import Abort, Exit

_local = threading.local()


class ParameterSource(enum.Enum):
    """Where a parameter's value came from, most explicit first."""

    PROMPT = "prompt"
    COMMANDLINE = "command line"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default map"
    DEFAULT = "declared default"


def get_current_context(silent: bool = False):
    """Return the context current on this thread, or raise / return None."""
    stack = getattr(_local, "stack", None)
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")


class Context:
    """Per-invocation state. Built by the library, one per command run."""

    def __init__(
        self,
        command,
        parent=None,
        info_name=None,
        obj=None,
        default_map=None,
        auto_envvar_prefix=None,
        terminal_width=None,
        max_content_width=None,
        help_option_names=None,
        token_normalize_func=None,
        color=None,
        show_default=None,
        allow_extra_args=None,
        ignore_unknown_options=None,
        allow_interspersed_args=None,
    ) -> None:
        self.command = command
        self.parent = parent
        self.info_name = info_name or command.name
        self.params: dict = {}
        self.sources: dict = {}
        self.protected_args: list = []
        self.args: list = []
        self.invoked_subcommand = None
        self.default_map = default_map
        self._exit_stack = contextlib.ExitStack()

        self.obj = obj if obj is not None else (parent.obj if parent is not None else None)

        if parent is None:
            self.auto_envvar_prefix = auto_envvar_prefix
        elif parent.auto_envvar_prefix:
            self.auto_envvar_prefix = f"{parent.auto_envvar_prefix}_{command.name}"
        else:
            self.auto_envvar_prefix = None

        self.terminal_width = _inherit(terminal_width, parent, "terminal_width", None)
        self.max_content_width = _inherit(max_content_width, parent, "max_content_width", 80)
        self.help_option_names = _inherit(
            help_option_names, parent, "help_option_names", ["--help"]
        )
        self.token_normalize_func = _inherit(
            token_normalize_func, parent, "token_normalize_func", None
        )
        self.color = _inherit(color, parent, "color", None)
        self.show_default = _inherit(show_default, parent, "show_default", False)

        # Command-specific parsing switches: the command's own value unless set here.
        self.allow_extra_args = (
            allow_extra_args if allow_extra_args is not None else command.allow_extra_args
        )
        self.ignore_unknown_options = (
            ignore_unknown_options
            if ignore_unknown_options is not None
            else command.ignore_unknown_options
        )
        self.allow_interspersed_args = (
            allow_interspersed_args
            if allow_interspersed_args is not None
            else command.allow_interspersed_args
        )

    @property
    def command_path(self) -> str:
        names = []
        ctx = self
        while ctx is not None:
            if ctx.info_name:
                names.append(ctx.info_name)
            ctx = ctx.parent
        return " ".join(reversed(names))

    def get_usage(self) -> str:
        return self.command.get_usage(self)

    def get_help(self) -> str:
        return self.command.get_help(self)

    def get_parameter_source(self, name: str):
        """The source that supplied ``name``; None when it is not declared."""
        if not any(p.name == name for p in self.command.params):
            return None
        return self.sources.get(name, ParameterSource.DEFAULT)

    def with_resource(self, cm):
        """Enter ``cm`` and keep it open until this invocation ends."""
        return self._exit_stack.enter_context(cm)

    def close(self) -> None:
        self._exit_stack.close()

    def exit(self, code: int = 0):
        raise Exit(code)

    def abort(self):
        raise Abort("Aborted.")

    def find_object(self, object_type):
        """Nearest object of exactly ``object_type`` walking up the parents."""
        ctx = self
        while ctx is not None:
            if isinstance(ctx.obj, object_type):
                return ctx.obj
            ctx = ctx.parent
        return None

    def invoke(self, other, /, **values):
        """Run ``other`` with exactly the given values."""
        child = Context(other, parent=self)
        with child:
            child.params = {p.name: values.get(p.name) for p in other.params}
            for p in other.params:
                child.sources[p.name] = None
            return other.run_callback_with_context(child)

    def forward(self, other, /, **values):
        """Run ``other`` with this command's values, overridden by ``values``."""
        merged = {
            p.name: self.params[p.name] for p in other.params if p.name in self.params
        }
        merged.update(values)
        return self.invoke(other, **merged)

    def __enter__(self):
        stack = getattr(_local, "stack", None)
        if stack is None:
            stack = _local.stack = []
        stack.append(self)
        return self

    def __exit__(self, *exc) -> None:
        _local.stack.pop()


def _inherit(value, parent, attr, default):
    if value is not None:
        return value
    if parent is not None:
        return getattr(parent, attr)
    return default


def pass_context(f):
    """Pass the current context as the first positional argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(f):
    """Pass the current context's author object as the first positional argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type, ensure: bool = False):
    """Pass the nearest object of ``object_type``; create one when ``ensure``."""

    def decorator(f):
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            obj = ctx.find_object(object_type)
            if obj is None and ensure:
                obj = object_type()
                ctx.obj = obj
            return f(obj, *args, **kwargs)

        return new_func

    return decorator
