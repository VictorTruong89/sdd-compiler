"""In-process runner for invoking commands with captured output (FP-14)."""

from __future__ import annotations

import contextlib
import io
import os
import sys
import tempfile


class _Capture:
    """A text stream that records writes as text and as encoded bytes."""

    def __init__(self, charset: str, order: list) -> None:
        self.encoding = charset
        self.errors = "strict"
        self._bytes = io.BytesIO()
        self._parts: list = []
        self._order = order

    @property
    def buffer(self):
        return self._bytes

    def write(self, text) -> int:
        if isinstance(text, bytes):
            self._bytes.write(text)
            text = text.decode(self.encoding, "replace")
        else:
            self._bytes.write(text.encode(self.encoding, "replace"))
        self._parts.append(text)
        self._order.append(text)
        return len(text)

    def flush(self) -> None:
        pass

    def isatty(self) -> bool:
        return False

    def fileno(self):
        raise io.UnsupportedOperation("fileno")

    def getvalue(self) -> str:
        return "".join(self._parts)

    def getbytes(self) -> bytes:
        return self._bytes.getvalue()


class Result:
    """The outcome of a runner invocation."""

    def __init__(self, exit_code, output, stdout, stderr, stdout_bytes, stderr_bytes, exception):
        self.exit_code = exit_code
        self.output = output
        self.stdout = stdout
        self.stderr = stderr
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.exception = exception

    def __repr__(self) -> str:
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    """Invokes a command with a token list and captures its output."""

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys") -> None:
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        order: list = []
        stdout = _Capture(self.charset, order)
        stderr = _Capture(self.charset, order)
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        else:
            data = input
        stdin = io.TextIOWrapper(io.BytesIO(data), encoding=self.charset)

        merged = dict(self.env)
        merged.update(env or {})
        saved_env = {}
        for key, value in merged.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)

        saved = (sys.stdin, sys.stdout, sys.stderr)
        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
        try:
            yield stdout, stderr, order
        finally:
            sys.stdin, sys.stdout, sys.stderr = saved
            for key, value in saved_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        """Run ``cli`` with ``args`` and capture everything it writes."""
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        extra.setdefault("standalone_mode", True)
        extra.setdefault("prog_name", "cli")
        extra.setdefault("color", color)
        if args is None:
            args = []
        elif isinstance(args, str):
            args = args.split()

        exit_code = 0
        exception = None
        rv = None
        with self.isolation(input=input, env=env, color=color) as (stdout, stderr, order):
            try:
                rv = cli.main(args=list(args), **extra)
            except SystemExit as exc:
                exit_code = exc.code if isinstance(exc.code, int) else (0 if exc.code is None else 1)
            except Exception as exc:  # noqa: BLE001 - reported on the result
                if not catch_exceptions:
                    raise
                exception = exc
                exit_code = 1

        result = Result(
            exit_code=exit_code,
            output="".join(order),
            stdout=stdout.getvalue(),
            stderr=stderr.getvalue(),
            stdout_bytes=stdout.getbytes(),
            stderr_bytes=stderr.getbytes(),
            exception=exception,
        )
        result.return_value = rv
        return result

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Work in a new empty directory; the directory is left in place afterwards."""
        cwd = os.getcwd()
        path = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
