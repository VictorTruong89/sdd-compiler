"""Parameter types and conversion (FP-05)."""

from __future__ import annotations

import datetime as _dt
import enum
import os
import uuid as _uuid

from .exceptions import BadParameter

TRUE_WORDS = ("1", "true", "t", "yes", "y", "on")
FALSE_WORDS = ("0", "false", "f", "no", "n", "off")


class ParamType:
    """Base class for parameter types.

    Subclasses set ``name`` and implement ``convert``. ``convert`` must pass
    through values that already have the right type.
    """

    name = "text"
    envvar_list_splitter = None  # None means whitespace split

    def convert(self, value, param=None, ctx=None):
        return value

    def split_envvar(self, value: str) -> list[str]:
        return value.split()

    def get_metavar(self, param=None):
        return self.name.upper()

    def shell_complete(self, ctx, param, incomplete):
        return []

    def __repr__(self) -> str:
        return self.name.upper()


def _fail(self, value, param, ctx, what: str):
    raise BadParameter(f"{value!r} is not {what}.", ctx=ctx, param=param)


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        return str(value)


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            text = str(value).strip()
            if text.lower().startswith(("0x", "-0x")):
                return int(text, 16)
            return int(text, 10)
        except (TypeError, ValueError):
            _fail(self, value, param, ctx, "a valid integer")


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        try:
            return float(value)
        except (TypeError, ValueError):
            _fail(self, value, param, ctx, "a valid float")


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in TRUE_WORDS:
            return True
        if text in FALSE_WORDS:
            return False
        _fail(self, value, param, ctx, "a valid boolean")


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value).strip())
        except (TypeError, ValueError):
            _fail(self, value, param, ctx, "a valid UUID")


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


class Choice(ParamType):
    """A closed list of allowed values, or the members of an enum."""

    name = "choice"

    def __init__(self, choices, case_sensitive: bool = True) -> None:
        self.case_sensitive = case_sensitive
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.choices = list(choices)
            self._tokens = [m.name for m in self.choices]
        else:
            self.choices = list(choices)
            self._tokens = [str(c) for c in self.choices]

    def get_metavar(self, param=None):
        return "[" + "|".join(self._tokens) + "]"

    def convert(self, value, param=None, ctx=None):
        if value in self.choices:
            return value
        text = str(value)
        for choice, token in zip(self.choices, self._tokens):
            if token == text:
                return choice
        if not self.case_sensitive:
            folded = text.casefold()
            for choice, token in zip(self.choices, self._tokens):
                if token.casefold() == folded:
                    return choice
        options = ", ".join(repr(t) for t in self._tokens)
        raise BadParameter(f"{text!r} is not one of {options}.", ctx=ctx, param=param)

    def shell_complete(self, ctx, param, incomplete):
        return [t for t in self._tokens if t.startswith(incomplete)]


class DateTime(ParamType):
    name = "datetime"
    DEFAULT_FORMATS = (
        "%Y-%m-%d",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
    )

    def __init__(self, formats=None) -> None:
        self.formats = tuple(formats) if formats is not None else self.DEFAULT_FORMATS

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        text = str(value).strip()
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(text, fmt)
            except ValueError:
                continue
        formats = ", ".join(repr(f) for f in self.formats)
        raise BadParameter(f"{text!r} does not match the formats {formats}.", ctx=ctx, param=param)


class IntRange(IntParamType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False) -> None:
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        result = super().convert(value, param, ctx)
        return _check_range(self, result, param, ctx, integer=True)


class FloatRange(FloatParamType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False) -> None:
        if clamp and (min_open or max_open):
            raise ValueError("Clamp is not supported for open bounds.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        result = super().convert(value, param, ctx)
        return _check_range(self, result, param, ctx, integer=False)


def _check_range(rng, result, param, ctx, integer: bool):
    lo, hi = rng.min, rng.max
    below = lo is not None and (result < lo or (rng.min_open and result == lo))
    above = hi is not None and (result > hi or (rng.max_open and result == hi))
    if not (below or above):
        return result
    if rng.clamp:
        if below:
            if rng.min_open:
                return lo + 1 if integer else lo
            return lo
        if rng.max_open:
            return hi - 1 if integer else hi
        return hi
    desc = _range_desc(rng)
    raise BadParameter(f"{result} is not in the range {desc}.", ctx=ctx, param=param)


def _range_desc(rng) -> str:
    lo = "-inf" if rng.min is None else str(rng.min)
    hi = "inf" if rng.max is None else str(rng.max)
    lb = "(" if rng.min_open or rng.min is None else "["
    rb = ")" if rng.max_open or rng.max is None else "]"
    return f"{lb}{lo}, {hi}{rb}"


class Tuple(ParamType):
    name = "tuple"

    def __init__(self, types) -> None:
        self.types = [convert_type(t) for t in types]

    def convert(self, value, param=None, ctx=None):
        if len(value) != len(self.types):
            raise BadParameter(
                f"Expected {len(self.types)} values, got {len(value)}.", ctx=ctx, param=param
            )
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))

    def split_envvar(self, value: str) -> list[str]:
        return value.split()


class File(ParamType):
    """Opens a file. ``-`` is stdin when reading and stdout when writing."""

    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False) -> None:
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def split_envvar(self, value: str) -> list[str]:
        return value.split(os.pathsep)

    def convert(self, value, param=None, ctx=None):
        from .fileio import open_file

        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        try:
            return open_file(
                str(value),
                self.mode,
                self.encoding,
                self.errors,
                lazy=self.lazy,
                atomic=self.atomic,
            )
        except OSError as exc:
            raise BadParameter(
                f"Could not open file {value!s}: {exc.strerror or exc}.",
                ctx=ctx,
                param=param,
            ) from exc


class Path(ParamType):
    name = "path"

    def __init__(
        self,
        exists=False,
        file_okay=True,
        dir_okay=True,
        writable=False,
        readable=True,
        resolve_path=False,
        allow_dash=False,
        path_type=None,
        executable=False,
    ) -> None:
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def split_envvar(self, value: str) -> list[str]:
        return value.split(os.pathsep)

    def convert(self, value, param=None, ctx=None):
        text = os.fspath(value) if not isinstance(value, str) else value
        if self.allow_dash and text == "-":
            result = "-"
        else:
            result = text
            if self.resolve_path:
                result = os.path.realpath(result)
            self._check(result, param, ctx)
        if self.path_type is not None and self.path_type is not str:
            return self.path_type(result)
        return result

    def _check(self, text, param, ctx):
        if self.allow_dash and text == "-":
            return
        exists = os.path.exists(text)
        if not exists:
            if self.exists:
                raise BadParameter(f"{text} does not exist.", ctx=ctx, param=param)
            return
        if os.path.isdir(text) and not self.dir_okay:
            raise BadParameter(f"{text} is a directory.", ctx=ctx, param=param)
        if not os.path.isdir(text) and not self.file_okay:
            raise BadParameter(f"{text} is a file.", ctx=ctx, param=param)
        checks = (
            (self.readable, os.R_OK, "readable"),
            (self.writable, os.W_OK, "writable"),
            (self.executable, os.X_OK, "executable"),
        )
        for wanted, flag, label in checks:
            if wanted and not os.access(text, flag):
                raise BadParameter(f"{text} is not {label}.", ctx=ctx, param=param)


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()


def convert_type(ty, default=None) -> ParamType:
    """Map a declared type or default to a ``ParamType`` instance."""
    if isinstance(ty, ParamType):
        return ty
    if ty is None and default is not None:
        if isinstance(default, bool):
            return BOOL
        if isinstance(default, int):
            return INT
        if isinstance(default, float):
            return FLOAT
        if isinstance(default, (tuple, list)) and default:
            return Tuple([type(v) for v in default])
        return STRING
    if ty is None:
        return STRING
    if ty is str:
        return STRING
    if ty is int:
        return INT
    if ty is float:
        return FLOAT
    if ty is bool:
        return BOOL
    if ty is _uuid.UUID:
        return UUID
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"Unsupported type: {ty!r}")


class FuncParamType(ParamType):
    """Wraps a conversion function that raises ``ValueError`` to refuse."""

    def __init__(self, func) -> None:
        self.func = func
        self.name = getattr(func, "__name__", "value")

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except ValueError as exc:
            raise BadParameter(str(exc) or f"{value!r} is invalid.", ctx=ctx, param=param) from exc
