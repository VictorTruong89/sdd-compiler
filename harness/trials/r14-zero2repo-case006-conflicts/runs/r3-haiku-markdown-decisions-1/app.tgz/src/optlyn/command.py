"""Leaf commands: parsing, value resolution, help, and standalone main (FP-01, FP-03, FP-04, FP-07, FP-13)."""

from __future__ import annotations

import inspect
import os
import shutil
import sys
import textwrap

from .context import Context, ParameterSource
from .exceptions import (
    Abort,
    BadParameter,
    Exit,
    MissingParameter,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .formatting import wrap_text
from .params import Argument, Option
from .types import FALSE_WORDS, TRUE_WORDS, Tuple

_NOVALUE = object()
_LONG_STARTS = ("--", "//", "++")


class _HelpUsage(UsageError):
    """Help shown because a command got no arguments (usage class, exit 2)."""

    def show(self, file=None) -> None:
        print(self.ctx.get_help(), file=file or sys.stderr)


class _ParseState:
    """Raw occurrences collected while parsing one command's tokens."""

    def __init__(self) -> None:
        self.occ: dict = {}

    def add(self, dest, item) -> None:
        self.occ.setdefault(dest, []).append(item)


class Command:
    """A callable unit that parses its tokens and runs an author callback."""

    is_group = False

    def __init__(
        self,
        name=None,
        callback=None,
        params=None,
        *,
        help=None,
        short_help=None,
        epilog=None,
        options_metavar="[OPTIONS]",
        add_help_option=True,
        no_args_is_help=False,
        deprecated=False,
        hidden=False,
        context_settings=None,
        allow_extra_args=False,
        ignore_unknown_options=False,
        allow_interspersed_args=True,
    ) -> None:
        self.name = name
        self.callback = callback
        self.params = list(params or [])
        if help is None and callback is not None:
            help = callback.__doc__
        self.help = _clean_help(help)
        self.short_help = short_help if short_help is not None else _first_sentence(self.help)
        self.epilog = epilog
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.deprecated = deprecated
        self.hidden = hidden
        self.context_settings = dict(context_settings or {})
        self.allow_extra_args = allow_extra_args
        self.ignore_unknown_options = ignore_unknown_options
        self.allow_interspersed_args = allow_interspersed_args

        if sum(1 for p in self.params if isinstance(p, Argument) and p.variadic) > 1:
            raise ValueError("Only one variadic argument is allowed per command.")
        self._opt_map: dict = {}
        for p in self.params:
            if isinstance(p, Option):
                for n in p.opts:
                    self._opt_map[n] = (p, "main")
                for n in p.secondary_opts:
                    self._opt_map[n] = (p, "off")
        self._prefixes = {"-"} | {n[0] for n in self._opt_map}

    # ----- public entry points -------------------------------------------------

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    def main(
        self,
        args=None,
        prog_name=None,
        complete_var=None,
        standalone_mode=True,
        **extra,
    ):
        """Run this command from the process (or from ``args``)."""
        if args is None:
            args = sys.argv[1:]
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else "main"

        from .completion import run_completion_if_requested

        if run_completion_if_requested(self, prog_name, complete_var, standalone_mode):
            return None

        settings = dict(self.context_settings)
        settings.update(extra)
        ctx = Context(self, info_name=prog_name, **settings)
        try:
            with ctx:
                try:
                    rv = self._run(ctx, list(args))
                finally:
                    ctx.close()
        except Exit as exc:
            if not standalone_mode:
                if exc.exit_code:
                    raise
                return None
            sys.exit(exc.exit_code)
        except OptlynError as exc:
            if not standalone_mode:
                raise
            exc.show()
            sys.exit(exc.exit_code)
        except (KeyboardInterrupt, EOFError):
            if not standalone_mode:
                raise
            Abort("Aborted!").show()
            sys.exit(1)

        if standalone_mode:
            sys.exit(0)
        return rv

    def run_callback_with_context(self, ctx):
        """Run the author callback with values already bound on ``ctx``."""
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else None
            message = f"DeprecationWarning: The command {ctx.command_path!r} is deprecated."
            if note:
                message += f" {note}"
            print(message)
        if self.callback is None:
            return None
        kwargs = {p.name: ctx.params.get(p.name) for p in self.params if p.expose_value}
        with ctx:
            return self.callback(**kwargs)

    # ----- parsing ------------------------------------------------------------

    def _run(self, ctx, args):
        if not args and self.no_args_is_help:
            raise _HelpUsage("", ctx)
        st, items, _ = self._parse(ctx, args)
        leftover = self._bind_arguments(ctx, st, items)
        self._check_leftover(ctx, leftover)
        self._resolve(ctx, st)
        return self.run_callback_with_context(ctx)

    def _parse(self, ctx, args):
        """Parse options. Returns (state, positional items, raw rest for a child)."""
        st = _ParseState()
        items = []
        rest = []
        need = self._group_need() if self.is_group else None
        mixing = ctx.allow_interspersed_args
        i = 0
        while i < len(args):
            tok = args[i]
            i += 1
            if tok == "--":
                items.extend((t, True) for t in args[i:])
                i = len(args)
                break
            if self._is_option_token(tok):
                i = self._take_option(ctx, st, tok, args, i, items)
                continue
            items.append((tok, False))
            if self.is_group:
                if not mixing and len(items) == need + 1:
                    rest = args[i:]
                    break
            elif not mixing:
                items.extend((t, False) for t in args[i:])
                i = len(args)
                break
        return st, items, rest

    def _is_option_token(self, tok: str) -> bool:
        return len(tok) > 1 and tok[0] in self._prefixes

    def _lookup_option(self, ctx, name):
        found = self._opt_map.get(name)
        if found is not None or ctx.token_normalize_func is None:
            return found
        wanted = ctx.token_normalize_func(name)
        for key, value in self._opt_map.items():
            if ctx.token_normalize_func(key) == wanted:
                return value
        return None

    def _take_option(self, ctx, st, tok, args, i, items):
        """Consume one option token (and its value tokens); return the new index."""
        if tok[:2] in _LONG_STARTS:
            name, eq, inline = tok.partition("=")
            found = self._lookup_option(ctx, name)
            if found is None:
                if name in ctx.help_option_names:
                    _show_help(ctx)
                if ctx.ignore_unknown_options:
                    items.append((tok, False))
                    return i
                raise NoSuchOption(f"No such option: {name}", ctx=ctx)
            param, kind = found
            if param.is_flag or param.count:
                if eq:
                    raise UsageError(f"Option {name} does not take a value.", ctx=ctx)
                self._record_flag(ctx, st, param, kind)
                return i
            return self._take_value(ctx, st, param, name, inline if eq else None, args, i)

        prefix = tok[0]
        j = 1
        while j < len(tok):
            key = prefix + tok[j]
            found = self._lookup_option(ctx, key)
            if found is None:
                if key in ctx.help_option_names:
                    _show_help(ctx)
                if ctx.ignore_unknown_options:
                    items.append((prefix + tok[j:], False))
                    return i
                raise NoSuchOption(f"No such option: {key}", ctx=ctx)
            param, kind = found
            if param.is_flag or param.count:
                self._record_flag(ctx, st, param, kind)
                j += 1
                continue
            inline = tok[j + 1 :] or None
            return self._take_value(ctx, st, param, key, inline, args, i)
        return i

    def _take_value(self, ctx, st, param, name, inline, args, i):
        n = param.nargs
        if inline is not None:
            if n == 1:
                item = inline
            else:
                tokens = [inline] + args[i : i + n - 1]
                if len(tokens) < n:
                    raise UsageError(f"Option {name} requires {n} values.", ctx=ctx)
                item = tuple(tokens)
                i += n - 1
        else:
            avail = args[i : i + n]
            if len(avail) < n or any(self._is_option_token(t) for t in avail):
                if param.prompt or param.flag_value is not None:
                    self._record(ctx, st, param, _NOVALUE)
                    return i
                raise UsageError(f"Option {name} requires an argument.", ctx=ctx)
            item = avail[0] if n == 1 else tuple(avail)
            i += n
        self._record(ctx, st, param, item)
        return i

    def _record_flag(self, ctx, st, param, kind):
        if param.count:
            item = 1
        else:
            item = param.flag_value if kind == "main" else False
        self._record(ctx, st, param, item)

    def _record(self, ctx, st, param, item):
        st.add(param.name, item)
        if param.is_eager and param.callback is not None:
            if item is _NOVALUE:
                item = param.flag_value
            value = item if (param.is_flag or param.count) else param.type.convert(item, param, ctx)
            param.callback(ctx, param, value)

    def _bind_arguments(self, ctx, st, items):
        """Bind positional items to declared arguments. Returns leftover items."""
        args = [p for p in self.params if isinstance(p, Argument)]
        idx = 0
        for n, arg in enumerate(args):
            later = sum(a.min_tokens for a in args[n + 1 :])
            avail = len(items) - idx
            if arg.variadic:
                take = max(0, avail - later)
            elif avail >= arg.nargs:
                take = arg.nargs
            else:
                take = 0
            if take:
                tokens = [t for t, _ in items[idx : idx + take]]
                st.add(arg.name, tokens[0] if arg.nargs == 1 else tuple(tokens))
                idx += take
        return items[idx:]

    def _check_leftover(self, ctx, leftover):
        for tok, literal in leftover:
            if self._is_option_token(tok) and not literal:
                raise NoSuchOption(f"No such option: {tok.partition('=')[0]}", ctx=ctx)
        if leftover and not ctx.allow_extra_args:
            words = " ".join(t for t, _ in leftover)
            raise UsageError(f"Got unexpected extra argument(s) ({words}).", ctx=ctx)
        ctx.args = [t for t, _ in leftover]

    # ----- value resolution ---------------------------------------------------

    def _resolve(self, ctx, st):
        for p in self.params:
            value, src = self._resolve_one(ctx, p, st)
            if src is None and p.required:
                raise MissingParameter(ctx=ctx, param=p)
            if p.deprecated and src is ParameterSource.COMMANDLINE:
                _warn_deprecated_param(p)
            if src is not None:
                ctx.sources[p.name] = src
            if p.callback is not None:
                value = p.callback(ctx, p, value)
            ctx.params[p.name] = value

    def _resolve_one(self, ctx, p, st):
        occ = st.occ.get(p.name)
        if occ:
            if any(item is _NOVALUE for item in occ):
                if p.prompt:
                    return self._prompt(ctx, p), ParameterSource.PROMPT
                occ = [p.flag_value if item is _NOVALUE else item for item in occ]
            return self._finalize(ctx, p, occ), ParameterSource.COMMANDLINE

        env = self._env_occurrences(ctx, p)
        if env is not None:
            return self._finalize(ctx, p, env), ParameterSource.ENVIRONMENT

        dmap = self._default_map_occurrences(ctx, p)
        if p.prompt and p.prompt_required:
            return self._prompt(ctx, p), ParameterSource.PROMPT
        if dmap is not None:
            return self._finalize(ctx, p, dmap), ParameterSource.DEFAULT_MAP

        default = p.get_default(ctx)
        if default is None:
            return (() if (p.multiple or p.variadic) else None), None
        occ = self._occurrences_from_value(ctx, p, default)
        return self._finalize(ctx, p, occ), ParameterSource.DEFAULT

    def _finalize(self, ctx, p, occ):
        if p.count:
            return sum(int(x) for x in occ)
        if p.is_flag:
            return occ[-1]
        values = [self._convert_item(ctx, p, item) for item in occ]
        if p.multiple:
            return tuple(values)
        return values[-1] if values else None

    def _convert_item(self, ctx, p, item):
        if isinstance(p.type, Tuple):
            return p.type.convert(tuple(item), p, ctx)
        if p.nargs != 1:
            return tuple(p.type.convert(t, p, ctx) for t in item)
        return p.type.convert(item, p, ctx)

    def _occurrences_from_value(self, ctx, p, value):
        """Turn a declared or default-map value into raw occurrences."""
        if p.multiple:
            if isinstance(value, str) or not isinstance(value, (list, tuple)):
                raise UsageError(
                    f"The default for {p.hint} needs an iterable (sequence) default.", ctx=ctx
                )
            if p.nargs > 1:
                return [tuple(v) for v in value]
            return list(value)
        if p.nargs != 1 or isinstance(p.type, Tuple):
            return [(value,)] if isinstance(value, str) else [tuple(value)]
        return [value]

    def _default_map_occurrences(self, ctx, p):
        dm = ctx.default_map
        if not isinstance(dm, dict) or p.name not in dm:
            return None
        value = dm[p.name]
        if isinstance(value, str) and (p.nargs != 1 or isinstance(p.type, Tuple)):
            return _split_occurrences(p, p.type.split_envvar(value))
        return self._occurrences_from_value(ctx, p, value)

    def _env_occurrences(self, ctx, p):
        names = []
        if p.envvar:
            names += [p.envvar] if isinstance(p.envvar, str) else list(p.envvar)
        if isinstance(p, Option) and p.allow_from_autoenv and ctx.auto_envvar_prefix:
            names.append(_env_name(f"{ctx.auto_envvar_prefix}_{p.name}"))
        for name in names:
            text = os.environ.get(name)
            if not text:
                continue
            if p.is_flag:
                value = _flag_from_env(p, text, ctx)
                if value is None:
                    continue
                return [value]
            if p.count:
                return [text]
            tokens = p.type.split_envvar(text) if (p.multiple or p.nargs != 1) else [text]
            if not tokens:
                continue
            return _split_occurrences(p, tokens)
        return None

    def _prompt(self, ctx, p):
        from .terminal import prompt as ask

        text = p.prompt if isinstance(p.prompt, str) else p.name.replace("_", " ").capitalize()
        default = p.get_default(ctx)
        return ask(
            text,
            default=default,
            hide_input=p.hide_input,
            confirmation_prompt=p.confirmation_prompt,
            type=p.type,
        )

    # ----- help ---------------------------------------------------------------

    def get_usage(self, ctx) -> str:
        pieces = [ctx.command_path, self.options_metavar]
        for p in self.params:
            if isinstance(p, Argument):
                meta = p.get_metavar()
                if p.variadic:
                    meta += "..."
                pieces.append(meta if p.required else f"[{meta}]")
        return "Usage: " + " ".join(piece for piece in pieces if piece)

    def get_help(self, ctx) -> str:
        width = _wrap_width(ctx)
        lines = [self.get_usage(ctx), ""]
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else ""
            lines += [f"DeprecationWarning: This command is deprecated. {note}".rstrip(), ""]
        if self.help:
            lines += [wrap_text(self.help, width), ""]

        positional = [p for p in self.params if isinstance(p, Argument) and p.help and not p.hidden]
        if positional:
            lines.append("Positional arguments:")
            for p in positional:
                lines += _entry(p.get_metavar(), p.help, width)
            lines.append("")

        options = [p for p in self.params if isinstance(p, Option) and not p.hidden]
        if options or self.add_help_option:
            lines.append("Options:")
            for p in options:
                lines += _entry(_option_head(p), _option_text(ctx, p), width)
            if self.add_help_option:
                names = ", ".join(ctx.help_option_names)
                lines += _entry(names, "Show this message and exit.", width)
            lines.append("")

        lines += self._help_extra_sections(ctx, width)
        if self.epilog:
            lines += [wrap_text(self.epilog, width), ""]
        return "\n".join(lines).rstrip() + "\n"

    def _help_extra_sections(self, ctx, width):
        return []

    def _group_need(self) -> int:
        return 0

    def get_short_help(self) -> str | None:
        return self.short_help


def _show_help(ctx):
    sys.stdout.write(ctx.get_help() + "\n")
    raise Exit(0)


def _warn_deprecated_param(p):
    kind = "option" if isinstance(p, Option) else "argument"
    message = f"DeprecationWarning: The {kind} {p.hint!r} is deprecated."
    if isinstance(p.deprecated, str):
        message += f" {p.deprecated}"
    print(message, file=sys.stderr)


def _clean_help(text):
    if not text:
        return None
    text = text.split("\f", 1)[0]
    return inspect.cleandoc(text).strip() or None


def _first_sentence(text):
    if not text:
        return ""
    flat = " ".join(text.split())
    parts = flat.split(". ", 1)
    return parts[0] if len(parts) == 1 else parts[0] + "."


def _wrap_width(ctx) -> int:
    if ctx.terminal_width:
        return ctx.terminal_width
    detected = shutil.get_terminal_size((80, 20)).columns
    return min(detected, ctx.max_content_width) - 2


def _entry(head, text, width):
    lines = [f"  {head}"]
    if not text:
        return lines
    body = textwrap.wrap(text, width=max(10, width - 32))
    if len(head) < 28:
        lines[0] = f"  {head.ljust(28)}  {body[0]}"
        body = body[1:]
    return lines + [" " * 32 + line for line in body]


def _option_head(p) -> str:
    names = ", ".join(p.opts + p.secondary_opts)
    meta = p.get_metavar()
    return f"{names} {meta}" if meta else names


def _option_text(ctx, p) -> str:
    parts = [p.help or ""]
    if p.show_envvar and p.envvar:
        envs = p.envvar if isinstance(p.envvar, str) else ", ".join(p.envvar)
        parts.append(f"[env var: {envs}]")
    show = p.show_default if p.show_default is not None else ctx.show_default
    if show and p.default is not None and not (p.is_flag and p.default is False):
        if isinstance(show, str):
            parts.append(f"[default: {show}]")
        else:
            parts.append(f"[default: {p.default}]")
    return " ".join(part for part in parts if part)


def _split_occurrences(p, tokens):
    """Group split tokens into occurrences: one per token, or one tuple per arity."""
    if p.nargs != 1 and not p.multiple:
        return [tuple(tokens)]
    if p.nargs > 1:
        n = p.nargs
        return [tuple(tokens[k : k + n]) for k in range(0, len(tokens), n)]
    return list(tokens)


def _env_name(name: str) -> str:
    return name.upper().replace("-", "_")


def _flag_from_env(p, text, ctx):
    """Interpret an environment value for a flag; None means unset."""
    stripped = text.strip().lower()
    if isinstance(p.flag_value, bool) or p.flag_value is None:
        if stripped in TRUE_WORDS:
            return True
        if stripped in FALSE_WORDS or stripped == "":
            return False
        raise BadParameter(f"{text!r} is not a valid boolean.", ctx=ctx, param=p)
    if text == str(p.flag_value):
        return p.flag_value
    if stripped in TRUE_WORDS:
        return True
    if stripped in FALSE_WORDS:
        return False
    return None
