"""Declaration decorators and ready-made options (FP-01, FP-02, FP-03, FP-08)."""

from __future__ import annotations

import sys

from .command import Command, _show_help
from .exceptions import Exit
from .group import Group
from .params import Argument, Option


def _derive_name(fn_name: str) -> str:
    name = fn_name.lower()
    for suffix in ("_command", "_cmd", "_group", "_grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def _attach(f, param) -> None:
    f.__dict__.setdefault("__optlyn_params__", []).append(param)


def _take_params(f) -> list:
    """Move declarations off the function. They were appended bottom-up, so reverse."""
    params = f.__dict__.pop("__optlyn_params__", [])
    params.reverse()
    return params


def command(name=None, cls=None, **attrs):
    """Turn a function into a leaf command."""
    if callable(name) and not isinstance(name, str):
        return command(None, cls, **attrs)(name)

    def decorator(f):
        klass = cls or Command
        cmd_name = name if name is not None else _derive_name(f.__name__)
        return klass(cmd_name, callback=f, params=_take_params(f), **attrs)

    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a group."""
    if callable(name) and not isinstance(name, str):
        return group(None, cls, **attrs)(name)

    def decorator(f):
        klass = cls or Group
        grp_name = name if name is not None else _derive_name(f.__name__)
        return klass(grp_name, callback=f, params=_take_params(f), **attrs)

    return decorator


def option(*param_decls, cls=None, **attrs):
    """Attach an option to the function below the decorator."""

    def decorator(f):
        klass = cls or Option
        _attach(f, klass(param_decls, **attrs))
        return f

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach a positional argument to the function below the decorator."""

    def decorator(f):
        klass = cls or Argument
        _attach(f, klass(param_decls, **attrs))
        return f

    return decorator


def help_option(*param_decls, **kwargs):
    """An extra eager help flag that prints help and exits."""
    decls = param_decls or ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")

    def callback(ctx, param, value):
        if value:
            _show_help(ctx)
        return value

    kwargs["callback"] = callback
    return option(*decls, **kwargs)


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    """An eager version flag. The identity comes from ``version`` or the package."""
    decls = param_decls or ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")

    def callback(ctx, param, value):
        if not value:
            return value
        ver = version or _detect_version(package_name)
        prog = prog_name or _root_name(ctx)
        template = message or "%(prog)s, version %(version)s"
        sys.stdout.write(template % {"prog": prog, "version": ver} + "\n")
        raise Exit(0)

    kwargs["callback"] = callback
    return option(*decls, **kwargs)


def custom_version_option(callback_fn, *param_decls, **kwargs):
    """An eager version flag whose whole output is ``callback_fn(ctx)``."""
    decls = param_decls or ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")

    def callback(ctx, param, value):
        if not value:
            return value
        sys.stdout.write(callback_fn(ctx) + "\n")
        raise Exit(0)

    kwargs["callback"] = callback
    return option(*decls, **kwargs)


def password_option(*param_decls, **kwargs):
    """A prompting option with hidden input and a confirmation prompt."""
    decls = param_decls or ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    return option(*decls, **kwargs)


def confirmation_option(*param_decls, **kwargs):
    """A yes flag that asks when omitted and aborts when the answer is no."""
    decls = param_decls or ("--yes",)
    question = kwargs.pop("prompt", "Do you want to continue?")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Confirm the action without prompting.")

    def callback(ctx, param, value):
        if not value:
            from .terminal import confirm

            confirm(question, abort=True)
        return value

    kwargs["callback"] = callback
    return option(*decls, **kwargs)


def _detect_version(package_name) -> str:
    from importlib import metadata

    if package_name is None:
        return "unknown"
    try:
        return metadata.version(package_name)
    except metadata.PackageNotFoundError:
        pass
    for dist in metadata.packages_distributions().get(package_name, []):
        try:
            return metadata.version(dist)
        except metadata.PackageNotFoundError:
            continue
    return "unknown"


def _root_name(ctx) -> str:
    while ctx.parent is not None:
        ctx = ctx.parent
    return ctx.info_name or ""
