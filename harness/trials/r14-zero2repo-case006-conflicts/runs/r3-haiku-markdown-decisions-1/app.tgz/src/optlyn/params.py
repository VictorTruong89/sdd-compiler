"""Options and arguments: declaration, defaults, and metadata (FP-03, FP-04)."""

from __future__ import annotations

from .types import BOOL, INT, ParamType, Tuple, convert_type

PREFIX_CHARS = ("-", "/", "+")
_LONG_STARTS = ("--", "//", "++")


class Parameter:
    """Common base of options and arguments."""

    def __init__(
        self,
        name,
        type=None,
        default=None,
        required=False,
        envvar=None,
        callback=None,
        expose_value=True,
        is_eager=False,
        hidden=False,
        deprecated=False,
        help=None,
        metavar=None,
        shell_complete=None,
        show_default=None,
        show_envvar=False,
        prompt=None,
        prompt_required=True,
        hide_input=False,
        confirmation_prompt=False,
    ) -> None:
        self.name = name
        self.default = default
        self.required = required
        # Shape flags read by the resolver; options override these.
        self.nargs = 1
        self.variadic = False
        self.is_flag = False
        self.flag_value = None
        self.count = False
        self.multiple = False
        self.envvar = envvar
        self.callback = callback
        self.expose_value = expose_value
        self.is_eager = is_eager
        self.hidden = hidden
        self.deprecated = deprecated
        self.help = help
        self.metavar = metavar
        self.shell_complete = shell_complete
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.prompt = prompt
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.type: ParamType = type if isinstance(type, ParamType) else convert_type(type, default)
        if self.deprecated and (self.required or self.prompt):
            raise ValueError("A deprecated parameter cannot be required or prompt.")

    @property
    def hint(self) -> str:
        return self.name

    def get_default(self, ctx=None):
        """The declared default, calling it when it is callable."""
        default = self.default
        if callable(default):
            default = default()
        return default

    def get_metavar(self) -> str:
        if self.metavar is not None:
            return self.metavar
        return self.type.get_metavar(self)


class Option(Parameter):
    """A named parameter introduced by a prefix such as ``--`` or ``-``."""

    def __init__(
        self,
        param_decls=(),
        is_flag=None,
        flag_value=None,
        count=False,
        multiple=False,
        nargs=None,
        allow_from_autoenv=True,
        **kwargs,
    ) -> None:
        opts, secondary, dest = _split_decls(param_decls)
        if not opts and not secondary:
            raise TypeError("An option needs at least one flag name.")
        default = kwargs.get("default")

        if secondary and is_flag is None:
            is_flag = True
        if is_flag is None:
            is_flag = isinstance(default, bool)
        if count:
            is_flag = False

        if is_flag and "type" not in kwargs:
            kwargs["type"] = BOOL
        if count and "type" not in kwargs:
            kwargs["type"] = INT
        if is_flag:
            if default is None:
                default = False
            if flag_value is None:
                flag_value = not default if isinstance(default, bool) else True
        if count and default is None:
            default = 0
        ty = kwargs.get("type")
        if nargs is None:
            nargs = len(ty.types) if isinstance(ty, Tuple) else 1
        if nargs < 1:
            raise ValueError("nargs must be a positive integer for options.")

        if multiple and "type" not in kwargs and isinstance(default, (list, tuple)) and default:
            kwargs["type"] = convert_type(None, default[0])
        kwargs["default"] = default
        name = dest or _infer_name(opts + secondary)
        super().__init__(name, **kwargs)

        if not isinstance(self.type, Tuple) and is_flag and self.type is None:
            self.type = BOOL
        self.opts = opts
        self.secondary_opts = secondary
        self.is_flag = bool(is_flag)
        self.flag_value = flag_value
        self.count = bool(count)
        self.multiple = bool(multiple)
        self.nargs = nargs
        self.allow_from_autoenv = allow_from_autoenv

    @property
    def hint(self) -> str:
        return " / ".join(self.opts + self.secondary_opts)

    @property
    def takes_value(self) -> bool:
        return not (self.is_flag or self.count)

    def get_default(self, ctx=None):
        return super().get_default(ctx)

    def get_metavar(self) -> str | None:
        if not self.takes_value:
            return None
        return super().get_metavar()


class Argument(Parameter):
    """A positional parameter bound in declaration order."""

    def __init__(self, param_decls, nargs=None, required=None, **kwargs) -> None:
        if len(param_decls) != 1:
            raise TypeError("An argument takes exactly one destination name.")
        name = param_decls[0]
        default = kwargs.get("default")
        if nargs is None:
            nargs = 1
        if nargs == 0 or nargs < -1:
            raise ValueError("nargs must be a positive integer or -1 (variadic).")
        if required is None:
            # A variadic argument is optional unless the author marks it required.
            required = default is None and nargs != -1 and not kwargs.get("prompt")
        super().__init__(name, required=required, **kwargs)
        self.nargs = nargs
        self.variadic = nargs == -1

    @property
    def hint(self) -> str:
        return self.name

    @property
    def min_tokens(self) -> int:
        """Tokens this argument needs at least when it is required."""
        return self.nargs if (self.nargs > 0 and self.required) else 0

    def get_metavar(self) -> str:
        if self.metavar is not None:
            return self.metavar
        return self.name.upper()


def _split_decls(decls):
    opts, secondary, dest = [], [], None
    for decl in decls:
        if decl[:1] in PREFIX_CHARS:
            if "/" in decl[1:] and decl[0] in PREFIX_CHARS:
                on, off = decl.split("/", 1)
                opts.append(on)
                secondary.append(off)
            else:
                opts.append(decl)
        else:
            dest = decl
    return opts, secondary, dest


def _infer_name(names) -> str:
    longs = [n for n in names if n[:2] in _LONG_STARTS]
    chosen = (longs or names)[0]
    return chosen.lstrip("".join(PREFIX_CHARS)).replace("-", "_")
