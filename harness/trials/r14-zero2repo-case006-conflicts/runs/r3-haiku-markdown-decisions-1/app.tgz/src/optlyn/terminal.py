"""Terminal helpers: echo, styling, prompts, pager, progress, and platform launchers (FP-08, FP-11)."""

from __future__ import annotations

import contextlib
import getpass
import os
import re
import shlex
import subprocess
import sys
import tempfile
import time

from .context import get_current_context
from .exceptions import Abort, BadParameter
from .fileio import open_file as _open_file
from .types import convert_type

open_file = _open_file

_ANSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")

_COLOR_NAMES = {
    "black": 30, "red": 31, "green": 32, "yellow": 33,
    "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
}

_STYLE_CODES = {
    "bold": 1, "dim": 2, "italic": 3, "underline": 4, "blink": 5,
    "reverse": 7, "strikethrough": 9, "overline": 53,
}


def unstyle(text: str) -> str:
    """Remove ANSI style sequences."""
    return _ANSI_RE.sub("", str(text))


def _color_code(color, background: bool) -> str:
    base = 48 if background else 38
    if isinstance(color, str):
        if color == "reset":
            return "49" if background else "39"
        if color not in _COLOR_NAMES:
            raise ValueError(f"Unknown color {color!r}.")
        return str(_COLOR_NAMES[color] + (10 if background else 0))
    if isinstance(color, int) and not isinstance(color, bool) and 0 <= color <= 255:
        return f"{base};5;{color}"
    if (
        isinstance(color, (tuple, list))
        and len(color) == 3
        and all(isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color)
    ):
        return f"{base};2;{color[0]};{color[1]};{color[2]}"
    raise ValueError(f"Invalid color {color!r}.")


def style(
    text,
    fg=None,
    bg=None,
    bold=None,
    dim=None,
    underline=None,
    overline=None,
    italic=None,
    blink=None,
    reverse=None,
    strikethrough=None,
    reset=True,
) -> str:
    """Wrap ``text`` in ANSI SGR sequences. Invalid colors raise ValueError."""
    codes = []
    if fg is not None:
        codes.append(_color_code(fg, background=False))
    if bg is not None:
        codes.append(_color_code(bg, background=True))
    switches = {
        "bold": bold, "dim": dim, "underline": underline, "overline": overline,
        "italic": italic, "blink": blink, "reverse": reverse, "strikethrough": strikethrough,
    }
    for key, on in switches.items():
        if on is not None and on is not False:
            codes.append(str(_STYLE_CODES[key]))
    text = str(text)
    if not codes:
        return text
    prefix = f"\x1b[{';'.join(codes)}m"
    return prefix + text + ("\x1b[0m" if reset else "")


def _stream_is_tty(stream) -> bool:
    try:
        return bool(stream.isatty())
    except (AttributeError, ValueError):
        return False


def _should_color(file, color) -> bool:
    if color is None:
        ctx = get_current_context(silent=True)
        color = ctx.color if ctx is not None else None
    if color is None:
        return _stream_is_tty(file)
    return bool(color)


def _write(file, text: str) -> None:
    try:
        file.write(text)
    except UnicodeEncodeError:
        data = text.encode("utf-8")
        buffer = getattr(file, "buffer", None)
        if buffer is not None:
            file.flush()
            buffer.write(data)
        else:
            file.write(data.decode("ascii", "replace"))
    file.flush()


def echo(message=None, file=None, nl=True, err=False, color=None) -> None:
    """Write text or bytes to standard output (or standard error)."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        buffer = getattr(file, "buffer", file)
        buffer.write(message + (b"\n" if nl else b""))
        buffer.flush()
        return
    text = str(message) + ("\n" if nl else "")
    if not _should_color(file, color):
        text = unstyle(text)
    _write(file, text)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles) -> None:
    """Echo with styling applied in one step."""
    if message is not None:
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


def _is_interactive() -> bool:
    return _stream_is_tty(sys.stdin) and _stream_is_tty(sys.stdout)


def echo_via_pager(text_or_generator, color=None) -> None:
    """Write long text through the pager when the session is interactive."""
    if callable(text_or_generator) and not isinstance(text_or_generator, str):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        chunks = [text_or_generator]
    else:
        chunks = text_or_generator
    if not _is_interactive():
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    pager = os.environ.get("PAGER") or "less"
    proc = subprocess.Popen(shlex.split(pager), stdin=subprocess.PIPE, text=True)
    try:
        for chunk in chunks:
            proc.stdin.write(chunk if _should_color(sys.stdout, color) else unstyle(chunk))
            proc.stdin.flush()
    finally:
        if proc.stdin:
            proc.stdin.close()
        proc.wait()


@contextlib.contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream routed through the pager when interactive."""
    if not _is_interactive():
        yield _NonClosing(sys.stdout)
        return
    pager = os.environ.get("PAGER") or "less"
    proc = subprocess.Popen(shlex.split(pager), stdin=subprocess.PIPE, text=True)
    try:
        yield proc.stdin
    finally:
        proc.stdin.close()
        proc.wait()


class _NonClosing:
    """Proxy that keeps the wrapped stream open when the block ends."""

    def __init__(self, stream) -> None:
        self._stream = stream

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def close(self) -> None:
        pass


class ProgressBar:
    """Iterates a sequence while showing progress on a terminal."""

    def __init__(self, iterable, length, label, hidden) -> None:
        self.iterable = iterable
        if length is None and iterable is not None and hasattr(iterable, "__len__"):
            length = len(iterable)
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.pos = 0
        self.start = time.monotonic()
        self.tty = (not hidden) and _stream_is_tty(sys.stdout)
        if self.label and not self.tty and not hidden:
            echo(self.label)

    def update(self, n_steps: int = 1) -> None:
        self.pos += n_steps
        if self.tty:
            sys.stdout.write("\r" + self._line())
            sys.stdout.flush()

    def _line(self) -> str:
        elapsed = time.monotonic() - self.start
        if self.length:
            frac = min(1.0, self.pos / self.length)
            filled = int(frac * 30)
            bar = "#" * filled + "-" * (30 - filled)
            eta = (elapsed / self.pos * (self.length - self.pos)) if self.pos else 0.0
            return f"{self.label} [{bar}] {self.pos}/{self.length} eta {eta:.0f}s"
        return f"{self.label} {self.pos}"

    def __iter__(self):
        for item in self.iterable or []:
            yield item
            self.update(1)

    def __enter__(self):
        return self

    def __exit__(self, *exc) -> None:
        if self.tty:
            sys.stdout.write("\n")
            sys.stdout.flush()


@contextlib.contextmanager
def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    """Context manager yielding a progress bar wrapped around ``iterable``."""
    bar = ProgressBar(iterable, length, label, hidden)
    with bar:
        yield bar


def getchar(echo=False) -> str:
    """Read one character from the terminal (not from a piped stdin)."""
    try:
        import termios
        import tty

        fd = os.open("/dev/tty", os.O_RDONLY)
        try:
            old = termios.tcgetattr(fd)
            try:
                tty.setraw(fd)
                ch = os.read(fd, 1).decode("utf-8", "replace")
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
        finally:
            os.close(fd)
    except (ImportError, OSError):
        ch = sys.stdin.read(1)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04" or ch == "":
        raise EOFError()
    if echo:
        echo(ch, nl=False)
    return ch


def pause(info=None, err=False) -> None:
    """Wait for a key press when interactive; do nothing otherwise."""
    if not _is_interactive():
        return
    echo(info or "Press any key to continue...", err=err, nl=False)
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass
    echo("", err=err)


def _read_line(message: str, hide_input: bool = False, err: bool = False) -> str:
    out = sys.stderr if err else sys.stdout
    if hide_input and _stream_is_tty(sys.stdin):
        try:
            return getpass.getpass(message)
        except EOFError as exc:
            raise Abort("Aborted!") from exc
    out.write(message)
    out.flush()
    line = sys.stdin.readline()
    if line == "":
        raise Abort("Aborted!")
    return line.rstrip("\r\n")


def prompt(
    text,
    default=None,
    hide_input=False,
    confirmation_prompt=False,
    type=None,
    prompt_suffix=": ",
    show_default=True,
    err=False,
    **_ignored,
):
    """Ask for a value, convert it, and re-ask on conversion failure."""
    ptype = convert_type(type, default)
    if callable(default):
        default = default()
    shown = f" [{default}]" if (default is not None and show_default and not hide_input) else ""
    if not _stream_is_tty(sys.stdout):
        text = unstyle(text)
    while True:
        value = _read_line(f"{text}{shown}{prompt_suffix}", hide_input, err)
        if value == "":
            if default is None:
                continue
            value = default
        else:
            if confirmation_prompt:
                second = _read_line("Repeat for confirmation: ", hide_input, err)
                if second != value:
                    echo("Error: the two entered values do not match", err=True)
                    continue
        try:
            return ptype.convert(value, None, None)
        except BadParameter as exc:
            echo(f"Error: {exc.message}", err=True)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    """Ask a yes/no question. Any answer other than yes or no counts as no."""
    if default is True:
        suffix = " [Y/n]"
    elif default is False:
        suffix = " [y/N]"
    else:
        suffix = " [y/n]"
    if not _stream_is_tty(sys.stdout):
        text = unstyle(text)
    answer = _read_line(f"{text}{suffix}{prompt_suffix}", False, err).strip().lower()
    if answer == "":
        result = bool(default)
    else:
        result = answer in ("y", "yes")
    if abort and not result:
        raise Abort("Aborted!")
    return result


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Open an editor on text (returns the saved text) or on a file (returns None)."""
    editor = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR")
    if not editor:
        editor = "notepad" if sys.platform.startswith("win") else "vi"
    run_env = dict(os.environ)
    run_env.update(env or {})
    if filename is not None:
        subprocess.run(shlex.split(editor) + [os.fspath(filename)], env=run_env, check=False)
        return None
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(text or "")
        subprocess.run(shlex.split(editor) + [path], env=run_env, check=False)
        with open(path, encoding="utf-8") as handle:
            result = handle.read()
    finally:
        os.remove(path)
    if require_save and result == (text or ""):
        return None
    return result


def launch(url, wait=False, locate=False) -> int:
    """Open ``url`` or a file with the default application."""
    url = os.fspath(url)
    try:
        if sys.platform.startswith("win"):
            os.startfile(url)  # type: ignore[attr-defined]
            return 0
        opener = "open" if sys.platform == "darwin" else "xdg-open"
        args = [opener]
        if locate and sys.platform == "darwin":
            args.append("-R")
        args.append(url)
        proc = subprocess.Popen(args)
        return proc.wait() if wait else 0
    except OSError:
        return 127


def clear() -> None:
    """Clear the visible terminal; no-op when not connected to one."""
    if not _stream_is_tty(sys.stdout):
        return
    sys.stdout.write("\x1b[2J\x1b[H")
    sys.stdout.flush()


def get_app_dir(app_name, roaming=True, force_posix=False) -> str:
    """Per-user config directory for ``app_name``."""
    home = os.path.expanduser("~")
    if force_posix:
        return os.path.join(home, "." + _unix_folder(app_name))
    if sys.platform.startswith("win"):
        base = os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming")
        return os.path.join(base, app_name)
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(base, _unix_folder(app_name))


def _unix_folder(app_name: str) -> str:
    return "-".join(app_name.lower().split())


def format_filename(filename, shorten=False) -> str:
    """Printable, strict-UTF-8-encodable form of a file name."""
    if hasattr(filename, "__fspath__"):
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        filename = os.fsdecode(filename)
    if shorten:
        filename = os.path.basename(filename)
    return filename.encode("utf-8", "backslashreplace").decode("utf-8")
