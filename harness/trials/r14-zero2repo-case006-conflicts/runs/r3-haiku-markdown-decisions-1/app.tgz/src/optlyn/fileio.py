"""File opening helpers shared by the File type and ``open_file`` (FP-09)."""

from __future__ import annotations

import os
import sys
import tempfile


class _StdStream:
    """Wraps a standard stream so that closing it does not close the process stream."""

    def __init__(self, stream) -> None:
        self._stream = stream

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __iter__(self):
        return iter(self._stream)

    def close(self) -> None:
        pass

    def __enter__(self):
        return self

    def __exit__(self, *exc) -> None:
        pass


class _AtomicFile:
    """Writes to a sibling temp file and replaces the target on close."""

    def __init__(self, target: str, mode: str, encoding, errors) -> None:
        self._target = target
        directory = os.path.dirname(os.path.abspath(target))
        fd, self._tmp = tempfile.mkstemp(dir=directory, prefix=".optlyn-")
        os.close(fd)
        self._file = open(self._tmp, mode, encoding=encoding, errors=errors)
        self.closed = False

    def __getattr__(self, name):
        return getattr(self._file, name)

    def close(self) -> None:
        if self.closed:
            return
        self._file.close()
        os.replace(self._tmp, self._target)
        self.closed = True

    def __enter__(self):
        return self

    def __exit__(self, *exc) -> None:
        self.close()


class _LazyFile:
    """Opens a write-mode file on first I/O (the default for write modes)."""

    def __init__(self, filename: str, mode: str, encoding, errors, atomic: bool) -> None:
        self._args = (filename, mode, encoding, errors, atomic)
        self._file = None
        self.name = filename
        self.mode = mode

    def _open(self):
        if self._file is None:
            filename, mode, encoding, errors, atomic = self._args
            if atomic:
                self._file = _AtomicFile(filename, mode, encoding, errors)
            else:
                self._file = open(filename, mode, encoding=encoding, errors=errors)
        return self._file

    def __getattr__(self, name):
        return getattr(self._open(), name)

    def write(self, data):
        return self._open().write(data)

    def flush(self):
        if self._file is not None:
            self._file.flush()

    def close(self) -> None:
        if self._file is not None:
            self._file.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc) -> None:
        self.close()


def open_file(
    filename,
    mode: str = "r",
    encoding=None,
    errors: str = "strict",
    lazy=None,
    atomic: bool = False,
):
    """Open ``filename``; ``-`` means standard input (read) or output (write).

    Read modes open immediately. Write modes are lazy by default, so the file
    is not truncated until first I/O. ``lazy=True`` / ``lazy=False`` forces it.
    """
    filename = os.fspath(filename)
    writing = any(c in mode for c in "wa+x")
    binary = "b" in mode
    if lazy is None:
        lazy = writing

    if filename == "-":
        if writing:
            stream = sys.stdout.buffer if binary else sys.stdout
        else:
            stream = sys.stdin.buffer if binary else sys.stdin
        return _StdStream(stream)

    if writing and lazy:
        return _LazyFile(filename, mode, None if binary else encoding, errors, atomic)
    if writing and atomic:
        return _AtomicFile(filename, mode, None if binary else encoding, errors)
    return open(filename, mode, encoding=None if binary else encoding, errors=errors)
