"""Text wrapping for help pages (FP-02, FP-11)."""

from __future__ import annotations

import textwrap


def wrap_text(text, width: int = 100, indent: int = 0, preserve_paragraphs: bool = False) -> str:
    """Rewrap ``text`` to ``width``.

    A paragraph whose first line is only a backspace is kept verbatim (line
    breaks preserved) and the backspace line is removed.
    """
    if text is None:
        return ""
    text = str(text)
    prefix = " " * indent
    inner = max(1, width - indent)
    out = []
    for para in text.split("\n\n"):
        lines = para.split("\n")
        if lines and lines[0].strip() == "\b":
            body = [line for line in lines[1:]]
            out.append("\n".join(prefix + line for line in body))
            continue
        flat = " ".join(line.strip() for line in lines if line.strip())
        if not flat:
            continue
        out.append(
            textwrap.fill(
                flat,
                width=inner,
                initial_indent=prefix,
                subsequent_indent=prefix,
                break_long_words=False,
                break_on_hyphens=False,
            )
        )
    return "\n\n".join(out)


def ellipsize(text: str, width: int) -> str:
    """Shorten ``text`` to fit ``width`` columns with a trailing ellipsis."""
    if len(text) <= width:
        return text
    if width <= 3:
        return text[:width]
    return text[: width - 3].rstrip() + "..."
