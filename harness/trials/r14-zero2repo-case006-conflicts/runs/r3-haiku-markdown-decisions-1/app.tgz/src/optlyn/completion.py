"""Shell completion: registration scripts and suggestions (FP-12)."""

from __future__ import annotations

import os
import sys
from types import SimpleNamespace

from .params import Option

SHELLS = ("bash", "zsh", "fish", "powershell")
_ACTIONS = ("source", "complete")


def default_complete_var(prog_name: str) -> str:
    return "_" + prog_name.upper().replace("-", "_").replace(".", "_") + "_COMPLETE"


def run_completion_if_requested(root, prog_name, complete_var, standalone_mode) -> bool:
    """Handle a completion request. Returns True when the request was consumed."""
    var = complete_var or default_complete_var(prog_name)
    value = os.environ.get(var)
    if value is None:
        return False
    shell, _, action = value.partition("_")
    if shell not in SHELLS or action not in _ACTIONS:
        return True  # neither script nor suggestions; the callback does not run
    if action == "source":
        sys.stdout.write(_registration_script(shell, prog_name, var) + "\n")
        return True

    words = os.environ.get("COMP_WORDS", "").split(" ")
    if shell == "fish":
        incomplete = os.environ.get("COMP_CWORD", "")
        prior = words[1:]
    else:
        cword = int(os.environ.get("COMP_CWORD", str(len(words) - 1)) or 0)
        incomplete = words[cword] if cword < len(words) else ""
        prior = words[1:cword]
    for suggestion in _suggest(root, prior, incomplete):
        sys.stdout.write(suggestion + "\n")
    return True


def _suggest(root, words, incomplete):
    ctx = SimpleNamespace(token_normalize_func=None, help_option_names=["--help"])
    node = root
    for tok in words:
        if node.is_group and not tok.startswith("-"):
            child = node.get_command(ctx, tok)
            if child is not None:
                node = child
    if incomplete.startswith("-"):
        names = [n for p in node.params if isinstance(p, Option) and not p.hidden for n in p.opts + p.secondary_opts]
        if node.add_help_option:
            names.append("--help")
        return [n for n in names if n.startswith(incomplete)]
    if node.is_group:
        out = []
        for name in node.list_commands(ctx):
            child = node.get_command(ctx, name)
            if child is not None and not child.hidden and name.startswith(incomplete):
                out.append(name)
        return out
    return []


def _registration_script(shell: str, prog_name: str, var: str) -> str:
    if shell == "bash":
        return (
            f'_{prog_name}_completion() {{\n'
            f'  local IFS=$\'\\n\'\n'
            f'  COMPREPLY=( $(COMP_WORDS="${{COMP_WORDS[*]}}" COMP_CWORD=$COMP_CWORD '
            f'{var}=bash_complete "${{COMP_WORDS[0]}}") )\n'
            f'}}\n'
            f'complete -o default -F _{prog_name}_completion {prog_name}'
        )
    if shell == "zsh":
        return (
            f'#compdef {prog_name}\n'
            f'_{prog_name}_completion() {{\n'
            f'  local -a suggestions\n'
            f'  suggestions=( ${{(f)"$(COMP_WORDS="${{words[*]}}" COMP_CWORD=$((CURRENT-1)) '
            f'{var}=zsh_complete {prog_name})"}} )\n'
            f'  compadd -a suggestions\n'
            f'}}\n'
            f'compdef _{prog_name}_completion {prog_name}'
        )
    if shell == "fish":
        return (
            f'function _{prog_name}_completion\n'
            f'  set -l cmd (commandline -opc)\n'
            f'  set -l cur (commandline -ct)\n'
            f'  env COMP_WORDS="$cmd $cur" COMP_CWORD="$cur" {var}=fish_complete {prog_name}\n'
            f'end\n'
            f'complete -c {prog_name} -f -a "(_{prog_name}_completion)"'
        )
    return (
        f'Register-ArgumentCompleter -Native -CommandName {prog_name} -ScriptBlock {{\n'
        f'  param($wordToComplete, $commandAst, $cursorPosition)\n'
        f'  $env:COMP_WORDS = $commandAst.ToString()\n'
        f'  $env:COMP_CWORD = $wordToComplete\n'
        f'  $env:{var} = "powershell_complete"\n'
        f'  & {prog_name} | ForEach-Object {{ [System.Management.Automation.CompletionResult]::new($_) }}\n'
        f'}}'
    )
