"""Exception classes used by Optlyn."""

from __future__ import annotations

from typing import Optional


class OptlynError(Exception):
    """Base class for errors signalled by the library."""

    exit_code = 1

    def __init__(self, message: str, ctx: Optional["Context"] = None) -> None:  # noqa: F821
        super().__init__(message)
        self.message = message
        self.ctx = ctx

    def show(self, file=None) -> None:
        import sys

        from .termui import echo

        echo(f"Error: {self.message}", file=file or sys.stderr, err=True)


class UsageError(OptlynError):
    """Usage failure: exit status 2."""

    exit_code = 2

    def __init__(self, message: str, ctx=None, command=None) -> None:
        super().__init__(message, ctx)
        self.command = command

    def show(self, file=None) -> None:
        import sys

        from .termui import echo

        echo(f"Usage: {self.ctx.command_path if self.ctx else ''} {self.message}".rstrip(),
             file=file or sys.stderr, err=True)


class BadParameter(UsageError):
    """A value was refused. Carries the offending parameter identity."""

    def __init__(self, message, ctx=None, param=None, param_hint=None) -> None:
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self) -> str:
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint()
        if hint:
            return f"Invalid value for {hint}: {self.message}"
        return f"Invalid value: {self.message}"

    def show(self, file=None) -> None:
        import sys

        from .termui import echo

        echo(f"Error: {self.format_message()}", file=file or sys.stderr, err=True)


class MissingParameter(BadParameter):
    """A required parameter was not supplied."""

    def format_message(self) -> str:
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint()
        return f"Missing parameter: {hint}" if hint else "Missing parameter"


class NoSuchOption(UsageError):
    """An unknown option was given."""


class BadOptionUsage(UsageError):
    """Option-specific usage error (e.g. missing value, bad combination)."""


class BadArgumentUsage(UsageError):
    """Argument-specific usage error."""


class NoArgsIsHelpError(UsageError):
    """Raised for a group invoked with no subcommand (help is shown)."""


class FileError(OptlynError):
    """A file could not be opened at first I/O (general error, exit 1)."""

    def __init__(self, filename: str, hint: str = "") -> None:
        super().__init__(f"Could not open file {filename!r}: {hint}".rstrip(": "))
        self.ui_filename = filename


class Abort(RuntimeError):
    """Abort the program: exit status 1."""

    exit_code = 1


class Exit(RuntimeError):
    """Author-requested clean stop with an optional status."""

    def __init__(self, code: int = 0) -> None:
        super().__init__(code)
        self.exit_code = code
