"""Value resolution: command line, environment, default map, prompt, default (FP-03)."""

from __future__ import annotations

import os
from typing import List, Tuple

from . import paramtypes as _types
from .exceptions import BadOptionUsage, MissingParameter
from .params import Argument, Option

_UNSET = object()
_TRUE = {"true", "1", "yes", "on", "t", "y"}
_FALSE = {"false", "0", "no", "off", "f", "n"}


def _is_sequenced(param) -> bool:
    return param.multiple or param.is_variadic


def _convert_chunk(ctx, param, tokens):
    """Convert the tokens of one occurrence to a value (scalar or tuple)."""
    if isinstance(param.type, _types.Tuple):
        return param.type(tuple(tokens), param, ctx)
    if param.nargs == 1:
        return param.type(tokens[0], param, ctx)
    return tuple(param.type(t, param, ctx) for t in tokens)


def _from_occurrences(ctx, param, occs):
    real = [o for o in occs if o.kind != "noval"]
    if param.is_flag:
        return real[-1].value
    if param.count:
        return sum(o.value for o in real)
    if _is_sequenced(param):
        out = []
        for occ in real:
            if param.is_variadic and not param.multiple:
                out.extend(param.type(t, param, ctx) for t in occ.value)
            else:
                out.append(_convert_chunk(ctx, param, occ.value))
        return tuple(out)
    return _convert_chunk(ctx, param, real[-1].value)


def _from_env(ctx, param, raw: str):
    # spec: FP-03 boolean flags accept a fixed set of strings; unknown text is an error
    if param.is_flag:
        text = raw.strip().lower()
        if param.flag_value is not True and raw.strip() == str(param.flag_value):
            return param.flag_value
        if text in _TRUE:
            return param.flag_value
        if text in _FALSE or text == "":
            return False if param.is_bool_flag else _UNSET
        if param.is_bool_flag:
            raise BadOptionUsage(f"{raw!r} is not a valid boolean value.", ctx)
        return _UNSET
    if _is_sequenced(param) or param.nargs != 1 or isinstance(param.type, _types.Tuple):
        tokens = param.split_envvar(raw)
        if param.multiple:
            return tuple(param.type(t, param, ctx) for t in tokens)
        if param.is_variadic:
            return tuple(param.type(t, param, ctx) for t in tokens)
        return _convert_chunk(ctx, param, tokens)
    return param.type(raw, param, ctx)


def _from_map(ctx, param, raw):
    # spec: FP-07 a string in the default map is split only for non-unary parameters
    if isinstance(raw, str):
        if _is_sequenced(param) and not param.is_variadic and param.multiple and param.nargs == 1:
            raise BadOptionUsage(
                f"Default for {param.get_error_hint()} needs an iterable (sequence) default.", ctx)
        if param.nargs != 1 or isinstance(param.type, _types.Tuple) or param.is_variadic:
            tokens = raw.split()
            if param.multiple or param.is_variadic:
                return tuple(param.type(t, param, ctx) for t in tokens)
            return _convert_chunk(ctx, param, tokens)
        return param.type(raw, param, ctx)
    if _is_sequenced(param):
        if not isinstance(raw, (list, tuple)):
            raise BadOptionUsage(
                f"Default for {param.get_error_hint()} needs an iterable (sequence) default.", ctx)
        return tuple(param.type(v, param, ctx) for v in raw)
    return param.type(raw, param, ctx)


def _from_default(ctx, param):
    value = param.default() if callable(param.default) else param.default
    if value is None:
        return None
    if _is_sequenced(param):
        if isinstance(value, str) or not isinstance(value, (list, tuple)):
            raise BadOptionUsage(
                f"Default for {param.get_error_hint()} needs an iterable (sequence) default.", ctx)
        return tuple(param.type(v, param, ctx) for v in value)
    if isinstance(param.type, _types.Tuple):
        return param.type(tuple(value), param, ctx)
    return param.type(value, param, ctx)


def _prompt(ctx, param):
    from .termui import prompt

    default = param.default
    value = prompt(param.prompt, default=default, hide_input=param.hide_input,
                   confirmation_prompt=param.confirmation_prompt, type=param.type)
    return value


def resolve_param(ctx, param, occs) -> Tuple[object, str]:
    """Return ``(value, source)`` for ``param`` given its occurrences."""
    prompting = isinstance(param, Option) and bool(param.prompt)
    if occs and all(o.kind == "noval" for o in occs):
        value = _prompt(ctx, param)
        return _finish(ctx, param, value), "prompt"
    real = [o for o in occs if o.kind != "noval"]
    if real:
        value = _from_occurrences(ctx, param, real)
        return _finish(ctx, param, value), "commandline"
    if param.count:
        return _finish(ctx, param, 0), "default"
    if param.name is not None:
        # spec: FP-03 first environment name that is set and non-empty wins
        for name in param.env_names(ctx):
            raw = os.environ.get(name)
            if not raw:
                continue
            value = _from_env(ctx, param, raw)
            if value is not _UNSET:
                return _finish(ctx, param, value), "environment"
        found, raw = ctx.lookup_default(param.name)
        if found:
            return _finish(ctx, param, _from_map(ctx, param, raw)), "default_map"
    if prompting and param.prompt_required:
        return _finish(ctx, param, _prompt(ctx, param)), "prompt"
    if param.default is not None or param.is_flag:
        return _finish(ctx, param, _from_default(ctx, param)), "default"
    if _is_sequenced(param):
        return _finish(ctx, param, ()), "default"
    if param.required:
        raise MissingParameter(_missing_message(param), ctx, param)
    return _finish(ctx, param, None), "default"


def _missing_message(param) -> str:
    return f"Missing parameter: {param.get_error_hint()}"


def _finish(ctx, param, value):
    # spec: FP-03 parameter callbacks may replace or refuse the value
    if param.callback is not None and not param.is_eager:
        value = param.callback(ctx, param, value)
    return value
