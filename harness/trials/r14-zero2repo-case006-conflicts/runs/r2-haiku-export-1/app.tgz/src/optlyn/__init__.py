"""Optlyn: a command line interface composition kit."""

from .core import Command, CommandCollection, Context, Group
from .decorators import (argument, command, confirmation_option, custom_version_option,
                         group, help_option, make_pass_decorator, option, pass_context,
                         pass_obj, password_option, version_option)
from .exceptions import Abort, BadParameter, Exit
from .params import Argument, Option, Parameter
from .paramtypes import (BOOL, FLOAT, INT, STRING, UNPROCESSED, UUID, Choice, DateTime,
                         File, FloatRange, IntRange, ParamType, Path, Tuple)
from .termui import (clear, confirm, echo, echo_via_pager, edit, format_filename,
                     get_app_dir, get_current_context, get_pager_file, getchar, launch,
                     open_file, pause, progressbar, prompt, secho, style, unstyle)

__all__ = [
    "command", "group", "option", "argument", "help_option", "version_option",
    "custom_version_option", "password_option", "confirmation_option", "pass_context",
    "pass_obj", "make_pass_decorator",
    "Command", "Group", "CommandCollection", "Context", "Option", "Parameter", "ParamType",
    "BadParameter", "Abort", "Exit",
    "STRING", "INT", "FLOAT", "BOOL", "UUID", "UNPROCESSED",
    "Choice", "DateTime", "IntRange", "FloatRange", "Tuple", "File", "Path",
    "echo", "secho", "style", "unstyle", "echo_via_pager", "get_pager_file", "progressbar",
    "prompt", "confirm", "getchar", "pause", "edit", "launch", "clear", "get_app_dir",
    "get_current_context", "format_filename", "open_file",
]
