"""Thread-local storage for the current invocation context."""

from __future__ import annotations

import threading

_local = threading.local()


def _stack() -> list:
    stack = getattr(_local, "stack", None)
    if stack is None:
        stack = []
        _local.stack = stack
    return stack


def push(ctx) -> None:
    _stack().append(ctx)


def pop() -> None:
    _stack().pop()


def get_current_context(silent: bool = False):
    # spec: N-000960..N-000962 raise when absent unless silent
    stack = _stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")


def abort_exception():
    from .exceptions import Abort

    return Abort("Aborted!")
