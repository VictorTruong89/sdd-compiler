"""In-process runner: optlyn.testing.CliRunner (interface contract section 9)."""

from __future__ import annotations

import contextlib
import io
import os
import shutil
import sys
import tempfile
from typing import Optional


class Result:
    """Outcome of CliRunner.invoke."""

    def __init__(self, runner, stdout_bytes: bytes, stderr_bytes: bytes, combined: str,
                 exit_code: int, exception: Optional[BaseException], return_value=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = bytes(combined, "utf-8") if combined else b""
        self._combined = combined
        self.exit_code = exit_code
        self.exception = exception
        self.return_value = return_value

    @property
    def stdout(self) -> str:
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self) -> str:
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    @property
    def output(self) -> str:
        return self._combined

    def __repr__(self) -> str:
        return f"<Result exit_code={self.exit_code}>"


class _Capture(io.TextIOBase):
    """A text stream recording bytes into a shared log, for write-order output."""

    def __init__(self, log, kind: str, charset: str, fd: Optional[int] = None) -> None:
        self._log = log
        self._kind = kind
        self._charset = charset
        self._buf = bytearray()
        self._fd = fd
        self._optlyn_echo = False

    def writable(self) -> bool:
        return True

    @property
    def encoding(self) -> str:
        return self._charset

    def write(self, text) -> int:
        data = text.encode(self._charset, "replace") if isinstance(text, str) else bytes(text)
        self._buf.extend(data)
        self._log.append((self._kind, data))
        return len(text)

    def flush(self) -> None:
        return None

    def isatty(self) -> bool:
        return False

    def fileno(self) -> int:
        if self._fd is None:
            raise io.UnsupportedOperation("fileno")
        return self._fd

    @property
    def buffer(self):
        outer = self

        class _B:
            def write(self_inner, data: bytes):
                outer._buf.extend(data)
                outer._log.append((outer._kind, bytes(data)))
                return len(data)

            def flush(self_inner):
                return None

        return _B()

    def getvalue_bytes(self) -> bytes:
        return bytes(self._buf)


class _Input(io.TextIOBase):
    def __init__(self, data: bytes, charset: str, echo: bool, log) -> None:
        self._text = io.TextIOWrapper(io.BytesIO(data), encoding=charset)
        self._optlyn_echo = True
        self._log = log

    def readline(self, size: int = -1) -> str:
        return self._text.readline()

    def read(self, size: int = -1) -> str:
        return self._text.read(size)

    def __iter__(self):
        return iter(self._text)

    def isatty(self) -> bool:
        return False

    def fileno(self) -> int:
        raise io.UnsupportedOperation("fileno")


class CliRunner:
    """Invoke a command in-process with captured streams."""

    def __init__(self, charset: str = "utf-8", env=None, echo_stdin: bool = False,
                 catch_exceptions: bool = True, capture: str = "sys") -> None:
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color: bool = False):
        log: list = []
        data = input.encode(self.charset) if isinstance(input, str) else (input or b"")
        stdin = _Input(data, self.charset, self.echo_stdin, log)
        stdout = _Capture(log, "stdout", self.charset, 1 if self.capture == "fd" else None)
        stderr = _Capture(log, "stderr", self.charset, 2 if self.capture == "fd" else None)
        merged = dict(self.env)
        merged.update(env or {})
        old_env = {}
        for key, value in merged.items():
            old_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)
        saved = (sys.stdin, sys.stdout, sys.stderr)
        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
        try:
            yield stdout, stderr, log
        finally:
            sys.stdin, sys.stdout, sys.stderr = saved
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None,
               color: bool = False, **extra) -> Result:
        exc_catch = self.catch_exceptions if catch_exceptions is None else catch_exceptions
        if args is None:
            args = []
        elif isinstance(args, str):
            import shlex

            args = shlex.split(args)
        prog = extra.pop("prog_name", None) or "root"
        extra.setdefault("standalone_mode", True)
        with self.isolation(input=input, env=env, color=color) as (out, err, log):
            exit_code = 0
            exception = None
            rv = None
            try:
                rv = cli.main(args=list(args), prog_name=prog, color=color, **extra)
            except SystemExit as exc:
                code = exc.code
                exit_code = code if isinstance(code, int) else (0 if code is None else 1)
            except Exception as exc:  # noqa: BLE001
                if not exc_catch:
                    raise
                exception = exc
                exit_code = 1
        stdout_bytes = b"".join(d for k, d in log if k == "stdout")
        stderr_bytes = b"".join(d for k, d in log if k == "stderr")
        combined = b"".join(d for _, d in log).decode(self.charset, "replace")
        return Result(self, stdout_bytes, stderr_bytes, combined, exit_code, exception, rv)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        # spec: FP-14 the new directory is always left in place after the block
        cwd = os.getcwd()
        path = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
