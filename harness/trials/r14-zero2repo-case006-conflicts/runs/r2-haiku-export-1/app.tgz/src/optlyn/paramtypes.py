"""Parameter types and conversion."""

from __future__ import annotations

import datetime as _dt
import enum
import os
import pathlib
import uuid as _uuid
from typing import Any, Iterable, Optional, Sequence

from .exceptions import BadParameter


class ParamType:
    """Base class for parameter types. Subclasses implement ``convert``."""

    name = "text"
    envvar_list_splitter: Optional[str] = None

    def __call__(self, value, param=None, ctx=None):
        return self.convert(value, param, ctx)

    def convert(self, value, param=None, ctx=None):
        return value

    def get_metavar(self, param=None) -> Optional[str]:
        return None

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def shell_complete(self, ctx, param, incomplete: str):
        return []

    @property
    def arity(self) -> int:
        return 1


class _StringType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        return str(value)


class _IntType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            return int(str(value).strip(), 10)
        except ValueError:
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class _FloatType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        try:
            return float(value)
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class _BoolType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class _UUIDType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value))
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID value.", param, ctx)


class _UnprocessedType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


STRING = _StringType()
INT = _IntType()
FLOAT = _FloatType()
BOOL = _BoolType()
UUID = _UUIDType()
UNPROCESSED = _UnprocessedType()


class Choice(ParamType):
    """A closed list of allowed values, or an enum.Enum subclass."""

    name = "choice"

    def __init__(self, choices, case_sensitive: bool = True) -> None:
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.choices = list(choices)
            self._names = {m.name: m for m in choices}
            self._enum = True
        else:
            self.choices = list(choices)
            self._enum = False
        self.case_sensitive = case_sensitive

    def get_metavar(self, param=None) -> str:
        names = [m.name if isinstance(m, enum.Enum) else str(m) for m in self.choices]
        return "[" + "|".join(names) + "]"

    def _tokens(self):
        for choice in self.choices:
            if isinstance(choice, enum.Enum):
                yield choice.name, choice
            else:
                yield str(choice), choice

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, enum.Enum) and value in self.choices:
            return value
        normed = str(value)
        if ctx is not None and ctx.token_normalize_func is not None:
            normed = ctx.token_normalize_func(normed)
        for token, original in self._tokens():
            candidate = token
            probe = normed
            if ctx is not None and ctx.token_normalize_func is not None:
                candidate = ctx.token_normalize_func(token)
            if not self.case_sensitive:
                candidate, probe = candidate.casefold(), probe.casefold()
            # spec: FP-05 first registered original wins on equal normalized token
            if candidate == probe:
                return original
        choices_str = ", ".join(repr(t) for t, _ in self._tokens())
        self.fail(f"{value!r} is not {choices_str}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete: str):
        out = []
        for token, _ in self._tokens():
            if token.startswith(incomplete):
                out.append(token)
        return out


DEFAULT_DATETIME_FORMATS = [
    "%Y-%m-%d",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M:%S",
]


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None) -> None:
        # spec: FP-05 custom list replaces the defaults
        self.formats = list(formats) if formats is not None else list(DEFAULT_DATETIME_FORMATS)

    def get_metavar(self, param=None) -> str:
        return "[" + "|".join(self.formats) + "]"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(str(value), fmt)
            except ValueError:
                continue
        self.fail(f"{value!r} does not match the formats {', '.join(self.formats)}.",
                  param, ctx)


class _RangeBase(ParamType):
    base_type = int

    def __init__(self, min=None, max=None, min_open: bool = False,
                 max_open: bool = False, clamp: bool = False) -> None:
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def _check(self, value, param, ctx):
        if self.min is not None:
            if self.min_open:
                if value <= self.min:
                    return self._out_low(param, ctx)
            elif value < self.min:
                return self._out_low(param, ctx)
        if self.max is not None:
            if self.max_open:
                if value >= self.max:
                    return self._out_high(param, ctx)
            elif value > self.max:
                return self._out_high(param, ctx)
        return value

    def _out_low(self, param, ctx):
        if self.clamp:
            return self.min if not self.min_open else self._adjacent_up()
        self.fail(f"{self._text()}", param, ctx)

    def _out_high(self, param, ctx):
        if self.clamp:
            return self.max if not self.max_open else self._adjacent_down()
        self.fail(f"{self._text()}", param, ctx)

    def _adjacent_up(self):
        return self.min + 1

    def _adjacent_down(self):
        return self.max - 1

    def _text(self) -> str:
        lo = "" if self.min is None else (">" if self.min_open else ">=") + f" {self.min}"
        hi = "" if self.max is None else ("<" if self.max_open else "<=") + f" {self.max}"
        parts = [p for p in (lo, hi) if p]
        return "is not in the valid range of " + " and ".join(parts) + "."

    def get_metavar(self, param=None) -> str:
        return f"[{self.name.upper()}]"


class IntRange(_RangeBase):
    name = "integer range"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool) or not isinstance(value, int):
            value = INT.convert(value, param, ctx)
        return self._check(value, param, ctx)


class FloatRange(_RangeBase):
    name = "float range"

    def __init__(self, min=None, max=None, min_open: bool = False,
                 max_open: bool = False, clamp: bool = False) -> None:
        if clamp and (min_open or max_open):
            raise ValueError("Clamping is not supported for open bounds.")
        super().__init__(min, max, min_open, max_open, clamp)

    def convert(self, value, param=None, ctx=None):
        if not isinstance(value, float):
            value = FLOAT.convert(value, param, ctx)
        return self._check(value, param, ctx)


class Tuple(ParamType):
    name = "tuple"

    def __init__(self, types: Sequence) -> None:
        self.types = [convert_type(t) for t in types]

    @property
    def arity(self) -> int:
        return len(self.types)

    def convert(self, value, param=None, ctx=None):
        if len(value) != len(self.types):
            self.fail(f"{value!r} must have {len(self.types)} items.", param, ctx)
        return tuple(t(v, param, ctx) for t, v in zip(self.types, value))


class _PassThrough(ParamType):
    name = "passthrough"


def convert_type(ty, default=None) -> ParamType:
    """Resolve a ``type=`` value (instance, ParamType, function or Python type)."""
    if isinstance(ty, ParamType):
        return ty
    if ty is None:
        if default is not None and not callable(default):
            return _infer(default)
        return STRING
    if ty is str:
        return STRING
    if ty is int:
        return INT
    if ty is float:
        return FLOAT
    if ty is bool:
        return BOOL
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    if callable(ty):
        return _FuncType(ty)
    raise TypeError(f"Unknown type {ty!r}")


def _infer(default) -> ParamType:
    if isinstance(default, bool):
        return BOOL
    if isinstance(default, int):
        return INT
    if isinstance(default, float):
        return FLOAT
    if isinstance(default, (tuple, list)) and default:
        return _infer(default[0])
    return STRING


class _FuncType(ParamType):
    """Adapter for a conversion function that refuses by raising ValueError."""

    def __init__(self, func) -> None:
        self.func = func
        self.name = getattr(func, "__name__", "text")

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except BadParameter:
            raise
        except ValueError as exc:
            self.fail(str(exc) or f"{value!r} is not valid.", param, ctx)


def _is_path_like(value) -> bool:
    return isinstance(value, (str, bytes, os.PathLike))


def open_stream(filename, mode: str = "r", encoding=None, errors: str = "strict",
                lazy: bool = False, atomic: bool = False):
    """Open ``filename`` or the standard stream for ``-``.

    Reads open immediately; writes open lazily unless ``lazy`` is False and
    the write is requested immediately (spec FP-09).
    """
    import contextlib
    import io
    import sys

    # spec: FP-09 dash means stdin when reading, stdout when writing
    if os.fspath(filename) == "-":
        if "r" in mode:
            stream = sys.stdin.buffer if "b" in mode else sys.stdin
        else:
            stream = sys.stdout.buffer if "b" in mode else sys.stdout
        return _NoCloseStream(stream)
    return _LazyFile(filename, mode, encoding, errors, lazy, atomic)


class _NoCloseStream:
    def __init__(self, stream) -> None:
        self._stream = stream

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def __iter__(self):
        return iter(self._stream)

    def close(self):
        return None


class _LazyFile:
    """A file that opens on first I/O (lazy) or immediately (non-lazy)."""

    def __init__(self, filename, mode, encoding, errors, lazy, atomic):
        self.filename = os.fspath(filename)
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._fh = None
        self._tmp = None
        if lazy is None or lazy is False:
            if "r" in mode or lazy is False:
                self._open()

    def _open(self):
        if self._fh is not None:
            return self._fh
        if "w" in self.mode and self.atomic:
            self._tmp = self.filename + ".tmp-optlyn"
            target = self._tmp
        else:
            target = self.filename
        try:
            kwargs = {} if "b" in self.mode else {"encoding": self.encoding,
                                                  "errors": self.errors}
            self._fh = open(target, self.mode, **kwargs)
        except OSError as exc:
            from .exceptions import FileError

            raise FileError(self.filename, exc.strerror or str(exc)) from exc
        return self._fh

    def __getattr__(self, name):
        return getattr(self._open(), name)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    def close(self):
        if self._fh is not None and not self._fh.closed:
            self._fh.close()
            if self._tmp is not None:
                os.replace(self._tmp, self.filename)
                self._tmp = None


class File(ParamType):
    """Opens a file; ``-`` is stdin (reading) or stdout (writing)."""

    name = "filename"

    def __init__(self, mode: str = "r", encoding=None, errors: str = "strict",
                 lazy=None, atomic: bool = False) -> None:
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        try:
            return open_stream(value, self.mode, self.encoding, self.errors,
                               self.lazy, self.atomic)
        except OSError as exc:
            self.fail(f"{os.fspath(value)!r}: {exc.strerror or exc}", param, ctx)
        except Exception as exc:  # FileError from the lazy opener
            from .exceptions import FileError

            if isinstance(exc, FileError):
                self.fail(f"{exc.ui_filename!r}: {exc.message.split(': ', 1)[-1]}", param, ctx)
            raise


class Path(ParamType):
    """Validates a filesystem path and returns it (not an open file)."""

    name = "path"

    def __init__(self, exists: bool = False, file_okay: bool = True, dir_okay: bool = True,
                 writable: bool = False, readable: bool = True, resolve_path: bool = False,
                 allow_dash: bool = False, path_type=None, executable: bool = False) -> None:
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def convert(self, value, param=None, ctx=None):
        text = os.fspath(value)
        if self.allow_dash and text == "-":
            # spec: FP-09 dash delivered as the path "-" without reading a stream
            return "-"
        rv = text
        if self.resolve_path:
            rv = os.path.realpath(rv)
        # spec: FP-09 permission checks apply only to a path that exists
        if not os.path.exists(rv):
            if self.exists:
                self.fail(f"{text!r} does not exist.", param, ctx)
        else:
            if not self.file_okay and os.path.isfile(rv):
                self.fail(f"{text!r} is a file.", param, ctx)
            if not self.dir_okay and os.path.isdir(rv):
                self.fail(f"{text!r} is a directory.", param, ctx)
            if self.readable and not os.access(rv, os.R_OK):
                self.fail(f"{text!r} is not readable.", param, ctx)
            if self.writable and not os.access(rv, os.W_OK):
                self.fail(f"{text!r} is not writable.", param, ctx)
            if self.executable and not os.access(rv, os.X_OK):
                self.fail(f"{text!r} is not executable.", param, ctx)
        if self.path_type is pathlib.Path:
            return pathlib.Path(rv)
        return rv
