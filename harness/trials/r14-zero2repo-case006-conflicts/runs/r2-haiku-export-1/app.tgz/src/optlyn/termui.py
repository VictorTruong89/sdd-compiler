"""Terminal helpers: echo, styling, prompts, pager, progress, and more."""

from __future__ import annotations

import contextlib
import os
import re
import shlex
import subprocess
import sys
import tempfile
import time
from typing import Any, Callable, Iterable, Optional

from . import _context

_ANSI_RE = re.compile(r"\033\[[0-9;?]*[ -/]*[@-~]")

_NAMED_COLORS = {
    "black": 30, "red": 31, "green": 32, "yellow": 33,
    "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
    "reset": 39,
}

_STYLE_CODES = {
    "bold": (1, 22), "dim": (2, 22), "underline": (4, 24), "overline": (53, 55),
    "italic": (3, 23), "blink": (5, 25), "reverse": (7, 27), "strikethrough": (9, 29),
}


def _color_code(color, background: bool) -> str:
    if isinstance(color, str):
        if color not in _NAMED_COLORS:
            raise TypeError(f"Unknown color {color!r}")
        base = _NAMED_COLORS[color]
        if color == "reset":
            return "49" if background else "39"
        return str(base + 10) if background else str(base)
    if isinstance(color, int) and not isinstance(color, bool):
        if not 0 <= color <= 255:
            raise ValueError(f"Color index out of range: {color}")
        return f"{'48' if background else '38'};5;{color}"
    if (isinstance(color, (tuple, list)) and len(color) == 3
            and all(isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255
                    for c in color)):
        return f"{'48' if background else '38'};2;{color[0]};{color[1]};{color[2]}"
    raise TypeError(f"Invalid color {color!r}")


def style(text: Any, fg=None, bg=None, bold=None, dim=None, underline=None,
          overline=None, italic=None, blink=None, reverse=None,
          strikethrough=None, reset: bool = True) -> str:
    """Wrap ``text`` in ANSI SGR sequences. Invalid colors raise."""
    codes: list[str] = []
    if fg is not None:
        codes.append(_color_code(fg, False))
    if bg is not None:
        codes.append(_color_code(bg, True))
    switches = {"bold": bold, "dim": dim, "underline": underline,
                "overline": overline, "italic": italic, "blink": blink,
                "reverse": reverse, "strikethrough": strikethrough}
    for name, on in switches.items():
        if on is not None:
            codes.append(str(_STYLE_CODES[name][0 if on else 1]))
    if not codes:
        return str(text)
    prefix = f"\033[{';'.join(codes)}m"
    suffix = "\033[0m" if reset else ""
    return f"{prefix}{text}{suffix}"


def unstyle(text: str) -> str:
    """Remove ANSI escape sequences."""
    return _ANSI_RE.sub("", text)


def _should_strip(stream, color) -> bool:
    if color is not None:
        return not color
    ctx = _context.get_current_context(silent=True)
    if ctx is not None and ctx.color is not None:
        return not ctx.color
    isatty = getattr(stream, "isatty", None)
    return not (isatty is not None and isatty())


def _write(stream, text: str) -> None:
    try:
        stream.write(text)
    except UnicodeEncodeError:
        # spec: N-000965 / FP-11 ASCII-only stream: write UTF-8 bytes instead
        buf = getattr(stream, "buffer", None)
        if buf is None:
            stream.write(text.encode("utf-8", "replace").decode("ascii", "replace"))
        else:
            buf.write(text.encode("utf-8"))
            buf.flush()


def echo(message: Any = None, file=None, nl: bool = True, err: bool = False,
         color=None) -> None:
    """Write to stdout, stderr (``err=True``) or ``file``."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        buf = getattr(file, "buffer", None)
        if buf is not None:
            buf.write(message + (b"\n" if nl else b""))
            buf.flush()
        else:
            file.write(message.decode("utf-8", "replace") + ("\n" if nl else ""))
        return
    text = str(message)
    if _should_strip(file, color):
        text = unstyle(text)
    if nl:
        text += "\n"
    _write(file, text)
    file.flush()


def secho(message: Any = None, file=None, nl: bool = True, err: bool = False,
          color=None, **styles) -> None:
    if message is not None:
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


def is_interactive() -> bool:
    """True when stdin is a terminal or stdin/stdout is a TTY."""
    return sys.stdin.isatty() or sys.stdout.isatty()


def echo_via_pager(text_or_generator, color=None) -> None:
    if callable(text_or_generator):
        source = text_or_generator()
    else:
        source = text_or_generator
    if isinstance(source, str):
        chunks: Iterable[str] = [source]
    else:
        chunks = source
    if not is_interactive() or not os.environ.get("PAGER"):
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    proc = subprocess.Popen(shlex.split(os.environ["PAGER"]), stdin=subprocess.PIPE)
    try:
        for chunk in chunks:
            proc.stdin.write(unstyle(chunk).encode("utf-8") if not color else
                             chunk.encode("utf-8"))
            proc.stdin.flush()
    finally:
        try:
            proc.stdin.close()
        except OSError:
            pass
        proc.wait()


@contextlib.contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream; text goes to the pager when interactive."""
    if not is_interactive() or not os.environ.get("PAGER"):
        yield sys.stdout
        return
    proc = subprocess.Popen(shlex.split(os.environ["PAGER"]), stdin=subprocess.PIPE,
                            text=True)
    try:
        yield proc.stdin
    finally:
        proc.stdin.close()
        proc.wait()


class ProgressBar:
    """Iterable progress bar. Items are always visited."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, **options):
        self.iterable = iterable
        self.length = length if length is not None else (
            len(iterable) if iterable is not None and hasattr(iterable, "__len__") else None)
        self.label = label
        self.hidden = hidden
        self.pos = 0
        self.start = time.time()
        self.options = options
        self._show = (not hidden) and sys.stdout.isatty()

    def __iter__(self):
        if self.iterable is None:
            return
        for item in self.iterable:
            yield item
            self.update(1)

    def update(self, n_steps: int = 1) -> None:
        self.pos += n_steps
        if self._show:
            total = self.length or "?"
            sys.stdout.write(f"\r{self.label or ''} {self.pos}/{total}")
            sys.stdout.flush()

    def render_finish(self) -> None:
        if self._show:
            sys.stdout.write("\n")
            sys.stdout.flush()
        elif self.label and not self.hidden:
            echo(self.label)


@contextlib.contextmanager
def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    bar = ProgressBar(iterable, length, label, hidden, **options)
    try:
        yield bar
    finally:
        bar.render_finish()


def _read_input(prompt_text: str, hide_input: bool) -> str:
    # spec: FP-08 hidden input does not echo; a non-terminal stdin is read directly
    if hide_input and sys.stdin.isatty():
        import getpass

        return getpass.getpass(prompt_text)
    echo(prompt_text, nl=False)
    line = sys.stdin.readline()
    if line == "":
        raise EOFError
    line = line.rstrip("\r\n")
    # spec: FP-14 the in-process runner echoes visible input into captured output
    if not hide_input and getattr(sys.stdin, "_optlyn_echo", False):
        echo(line)
    return line


def prompt(text: str, default=None, hide_input: bool = False,
           confirmation_prompt: bool = False, type=None, value_proc=None,
           prompt_suffix: str = ": ", show_default: bool = True,
           err: bool = False, show_choices: bool = True):
    """Ask for a value. Re-asks on conversion failure; EOF raises EOFError."""
    from .paramtypes import convert_type

    ptype = convert_type(type, default)
    suffix = ""
    if show_default and default is not None and not callable(default):
        suffix = f" [{default}]"
    elif show_default and callable(default):
        suffix = ""
    full = f"{text}{suffix}{prompt_suffix}"
    while True:
        raw = _read_input(full, hide_input)
        if raw == "" and default is not None:
            value = default() if callable(default) else default
            return value
        if confirmation_prompt:
            again = _read_input(f"Repeat for confirmation{prompt_suffix}", hide_input)
            if again != raw:
                echo("Error: the two entered values do not match", err=True)
                continue
        try:
            return ptype(raw)
        except Exception as exc:  # noqa: BLE001 - re-ask on any refusal
            echo(f"Error: {exc}", err=True)


def confirm(text: str, default: bool = False, abort: bool = False,
            prompt_suffix: str = ": ", show_default: bool = True,
            err: bool = False) -> bool:
    """Ask a yes/no question. Invalid answers re-ask (CF-000151 resolution)."""
    hint = " [y/N]" if default is False else " [Y/n]"
    if not show_default:
        hint = ""
    full = f"{text}{hint}{prompt_suffix}"
    while True:
        raw = _read_input(full, False).strip().lower()
        if raw in ("y", "yes"):
            value = True
        elif raw in ("n", "no"):
            value = False
        elif raw == "":
            value = default
        else:
            continue
        if not value and abort:
            raise _context.abort_exception()
        return value


def getchar(echo_char: bool = False) -> str:
    """Read one character from the controlling terminal."""
    import termios
    import tty

    try:
        fd = os.open("/dev/tty", os.O_RDWR)
    except OSError:
        fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        ch = os.read(fd, 1).decode("utf-8", "replace")
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)
    if ch == "\x03":
        raise KeyboardInterrupt
    if ch == "\x04":
        raise EOFError
    if echo_char:
        echo(ch, nl=False)
    return ch


def pause(info: Optional[str] = None, err: bool = False) -> None:
    if not is_interactive():
        return
    echo(info or "Press any key to continue...", nl=False, err=err)
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass
    echo("", err=err)


def edit(text=None, editor=None, env=None, require_save: bool = True,
         extension: str = ".txt", filename=None):
    editor_cmd = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR") or "vi"
    if filename is not None:
        subprocess.call(shlex.split(editor_cmd) + [str(filename)], env=env)
        return None
    with tempfile.NamedTemporaryFile("w+", suffix=extension, delete=False,
                                     encoding="utf-8") as fh:
        fh.write(text or "")
        path = fh.name
    try:
        subprocess.call(shlex.split(editor_cmd) + [path], env=env)
        with open(path, encoding="utf-8") as fh:
            result = fh.read()
    finally:
        os.remove(path)
    if require_save and text is not None and result == text:
        return None
    return result


def launch(url: str, wait: bool = False, locate: bool = False) -> int:
    opener = "open" if sys.platform == "darwin" else "xdg-open"
    if sys.platform == "win32":
        os.startfile(url)  # type: ignore[attr-defined]
        return 0
    proc = subprocess.Popen([opener, url])
    if wait:
        return proc.wait()
    return 0


def clear() -> None:
    if not sys.stdout.isatty():
        return
    echo("\033[2J\033[H", nl=False)


def get_app_dir(app_name: str, roaming: bool = True, force_posix: bool = False) -> str:
    folder = re.sub(r"\s+", "-", app_name.lower().strip()) if app_name else app_name
    home = os.path.expanduser("~")
    if sys.platform == "darwin" and not force_posix:
        return os.path.join(home, "Library", "Application Support", app_name)
    if force_posix or sys.platform != "win32":
        if force_posix:
            return os.path.join(home, "." + folder)
        base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
        return os.path.join(base, folder)
    return os.path.join(os.environ.get("APPDATA", home), app_name)


def get_current_context(silent: bool = False):
    return _context.get_current_context(silent=silent)


def format_filename(filename, shorten: bool = False) -> str:
    if isinstance(filename, bytes):
        name = filename.decode("utf-8", "surrogateescape")
    else:
        name = os.fspath(filename)
    if shorten:
        name = os.path.basename(name)
    # spec: FP-09 printable text that encodes as strict UTF-8 without failing
    return name.encode("utf-8", "surrogateescape").decode("utf-8", "backslashreplace")


def open_file(filename, mode: str = "r", encoding=None, errors: str = "strict",
              lazy: bool = False, atomic: bool = False):
    from .paramtypes import open_stream

    return open_stream(filename, mode, encoding, errors, lazy, atomic)
