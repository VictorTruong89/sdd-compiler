"""Parameter objects: options and arguments, and their value resolution."""

from __future__ import annotations

import os
from typing import Any, Callable, List, Optional

from . import paramtypes as _types
from .exceptions import BadParameter, MissingParameter

_UNSET = object()
_SOURCES = ("prompt", "commandline", "environment", "default_map", "default")
_SOURCE_RANK = {s: i for i, s in enumerate(_SOURCES)}
# spec: N-000230 precedence, most explicit first, as stated in FP-03


class ValueSource:
    """Distinct per-source tokens for Context.get_parameter_source."""

    def __init__(self, name: str) -> None:
        self.name = name

    def __eq__(self, other) -> bool:
        return isinstance(other, ValueSource) and other.name == self.name

    def __hash__(self) -> int:
        return hash(self.name)

    def __repr__(self) -> str:
        return f"ParameterSource.{self.name.upper()}"


SOURCE_OBJECTS = {name: ValueSource(name) for name in _SOURCES}


class Parameter:
    """Common base for Option and Argument."""

    param_type_name = "parameter"
    is_flag = False
    count = False
    prompt = None
    flag_value_explicit = False

    def __init__(self, param_decls=None, type=None, required: bool = False,
                 default=None, callback=None, nargs: int = 1, multiple: bool = False,
                 envvar=None, deprecated=False, metavar=None, expose_value: bool = True,
                 is_eager: bool = False, shell_complete=None, hidden: bool = False,
                 help=None, **attrs) -> None:
        self.name, self.opts, self.secondary_opts = self._parse_decls(param_decls or [])
        self.type = _types.convert_type(type, default)
        self.required = required
        self.default = default
        self.callback = callback
        self.nargs = nargs
        self.multiple = multiple
        self.envvar = envvar
        self.deprecated = deprecated
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        self.shell_complete = shell_complete
        self.hidden = hidden
        self.help = help
        self.allow_from_autoenv = attrs.pop("allow_from_autoenv", True)
        self.attrs = attrs
        self.type_explicit = type is not None
        if isinstance(self.type, _types.Tuple):
            self.nargs = self.type.arity
        if self.nargs < 1 and self.nargs != -1:
            raise ValueError("nargs must be a positive integer, or -1 for variadic.")
        if self.deprecated and self.required:
            raise ValueError("A deprecated parameter cannot also be required.")

    # spec: FP-03 destination inference
    @staticmethod
    def _parse_decls(decls):
        opts, secondary, dest = [], [], None
        for decl in decls:
            if "/" in decl and decl[:1] in "-+/" and not decl.startswith("/"):
                first, second = decl.split("/", 1)
                opts.append(first)
                secondary.append(second)
            elif decl[:1] and decl[0] in "-/+":
                opts.append(decl)
            else:
                if dest is not None:
                    raise ValueError(f"Got multiple destinations: {dest!r}, {decl!r}")
                dest = decl
        if dest is None and opts:
            ident = None
            for o in opts:
                cand = o.lstrip("-+/").replace("-", "_")
                if cand.isidentifier():
                    ident = cand
                    break
            if ident is None:
                longs = [o for o in opts if o.startswith("--")] or opts
                ident = longs[0].lstrip("-+/").replace("-", "_")
            dest = ident
        return dest, opts, secondary

    # ---- value resolution helpers -------------------------------------
    @property
    def is_variadic(self) -> bool:
        return self.nargs == -1

    @property
    def unary(self) -> bool:
        return self.nargs == 1 and not self.multiple and not isinstance(self.type, _types.Tuple)

    def get_error_hint(self) -> str:
        return self.name or ""

    def get_default(self, ctx):
        # spec: callable defaults are invoked when no earlier value source produced a value
        if callable(self.default):
            return self.default()
        return self.default

    def has_default(self) -> bool:
        return self.default is not None

    def split_envvar(self, raw: str) -> List[str]:
        # spec: FP-03 default split is whitespace; path types split on os.pathsep
        if isinstance(self.type, _types.ParamType) and getattr(self.type, "name", "") == "path":
            return raw.split(os.pathsep)
        return raw.split()

    def env_names(self, ctx) -> List[str]:
        if self.envvar is None:
            return []
        if isinstance(self.envvar, str):
            return [self.envvar]
        return list(self.envvar)

    def envvar_value(self, ctx) -> Optional[str]:
        for name in self.env_names(ctx):
            raw = os.environ.get(name)
            if raw:
                return raw
        return None

class Option(Parameter):
    """A named parameter introduced by a flag."""

    param_type_name = "option"

    def __init__(self, param_decls=None, cls=None, is_flag=None, flag_value=None,
                 count: bool = False, prompt=None, prompt_required: bool = True,
                 hide_input: bool = False, confirmation_prompt: bool = False,
                 show_default=False, show_envvar: bool = False, **attrs) -> None:
        super().__init__(param_decls, **attrs)
        self.count = count
        self.prompt = prompt
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.show_default = show_default
        self.show_envvar = show_envvar
        if is_flag is None:
            # spec: FP-03 a flag is inferred from a bool default, a secondary (off) flag, or a flag value
            is_flag = isinstance(self.default, bool) or bool(self.secondary_opts) or flag_value is not None
        if count:
            is_flag = False
        self.is_flag = is_flag
        self.flag_value_explicit = flag_value is not None and not is_flag
        if self.is_flag and not self.type_explicit:
            self.type = _types.BOOL
        self.flag_value = True if flag_value is None else flag_value
        if self.is_flag and self.default is None:
            self.default = False
        self.is_bool_flag = self.is_flag
        if self.is_flag and self.nargs != 1:
            raise ValueError("Flags cannot take nargs other than 1.")
        if self.deprecated and self.prompt:
            raise ValueError("A deprecated option cannot use a prompt.")
        if self.prompt is True:
            self.prompt = (self.name or "value").replace("_", " ").capitalize()

    def get_error_hint(self) -> str:
        # spec: usage-error report contains the flag names as declared
        return " / ".join(self.opts) if self.opts else (self.name or "")

    def env_names(self, ctx) -> List[str]:
        names = super().env_names(ctx)
        if not names and self.allow_from_autoenv and ctx is not None:
            prefix = ctx.auto_envvar_prefix_name_for(self)
            if prefix:
                names = [prefix]
        return names

    def run_eager(self, ctx, value) -> None:
        # spec: FP-02 eager flags run their callback as soon as they are seen
        if self.callback is not None:
            self.callback(ctx, self, value)


class Argument(Parameter):
    """A positional parameter. Binds tokens in declaration order."""

    param_type_name = "argument"

    def __init__(self, param_decls=None, cls=None, required=None, **attrs) -> None:
        if param_decls is None or len(param_decls) != 1:
            # spec: FP-04 an argument is declared with a single destination name
            raise TypeError("An argument takes exactly one destination name.")
        super().__init__(list(param_decls), **attrs)
        if self.opts:
            raise TypeError("Arguments cannot have flag names.")
        # spec: FP-04 an argument with neither a default nor an optional marking is required
        if required is None:
            # spec: FP-04 a variadic argument omitted yields () unless marked required
            required = self.default is None and not self.is_variadic
        self.required = required and not self.is_variadic_default_ok()
        if self.deprecated and self.required:
            raise ValueError("A deprecated argument cannot also be required.")

    def is_variadic_default_ok(self) -> bool:
        return False

    def get_error_hint(self) -> str:
        return self.metavar or (self.name or "").upper()

    def placeholder(self) -> str:
        return self.metavar or self.name.upper()

    def env_names(self, ctx) -> List[str]:
        # spec: FP-04 arguments read only explicitly named environment variables
        return super().env_names(ctx) if self.envvar is not None else []
