"""Context, Command, Group and CommandCollection: the invocation machinery."""

from __future__ import annotations

import contextlib
import os
import shutil
import sys
from typing import Any, Callable, Dict, List, Optional

from . import _context
from . import paramtypes as _types
from .exceptions import (Abort, BadOptionUsage, BadParameter, Exit, FileError,
                         MissingParameter, NoArgsIsHelpError, OptlynError, UsageError)
from .helptext import render_help
from .params import SOURCE_OBJECTS, Argument, Option, Parameter
from .parser import Parser

# spec: FP-02 maximum content width defaults to 80 unless the caller raises it
DEFAULT_MAX_CONTENT_WIDTH = 80

_SETTING_DEFAULTS = {
    "auto_envvar_prefix": None,
    "default_map": None,
    "terminal_width": None,
    "max_content_width": DEFAULT_MAX_CONTENT_WIDTH,
    "help_option_names": ["--help"],
    "token_normalize_func": None,
    "color": None,
    "show_default": False,
    "allow_extra_args": False,
    "ignore_unknown_options": False,
    "allow_interspersed_args": True,
}
# keys inherited unchanged from the parent context
_INHERITED = ("auto_envvar_prefix", "terminal_width", "max_content_width",
              "help_option_names", "token_normalize_func", "color", "show_default")


class Context:
    """Per-invocation state. Built by the library, one per invocation."""

    def __init__(self, command, parent=None, info_name=None, obj=None,
                 default_map=None, **settings) -> None:
        self.command = command
        self.parent = parent
        self.info_name = info_name
        self._obj = obj
        self.params: Dict[str, Any] = {}
        self.param_sources: Dict[str, str] = {}
        self.invoked_subcommand = None
        self.args: List[str] = []
        self._exit_stack = contextlib.ExitStack()
        self._closed = False

        # spec: FP-07 defaults flow down from parent; command context_settings then explicit extras win
        values = dict(_SETTING_DEFAULTS)
        if parent is not None:
            for key in _INHERITED:
                values[key] = getattr(parent, key)
            values["allow_extra_args"] = False
            values["ignore_unknown_options"] = False
            values["allow_interspersed_args"] = command.interspersed_default
        else:
            values["allow_interspersed_args"] = command.interspersed_default
        values.update(command.context_settings or {})
        values.update(settings)
        for key, val in values.items():
            setattr(self, key, val)
        if obj is None and parent is not None:
            self._obj = parent._obj
        # spec: FP-07 default map nests by subcommand name below the parent
        if default_map is not None:
            self.default_map = default_map
        elif parent is not None and isinstance(parent.default_map, dict):
            self.default_map = parent.default_map.get(command.name)
        elif parent is None and command.context_defaults is not None:
            self.default_map = command.context_defaults

    @property
    def obj(self):
        return self._obj

    @obj.setter
    def obj(self, value) -> None:
        self._obj = value

    @property
    def root(self) -> "Context":
        ctx = self
        while ctx.parent is not None:
            ctx = ctx.parent
        return ctx

    @property
    def command_path(self) -> str:
        names = []
        ctx = self
        while ctx is not None:
            if ctx.info_name:
                names.append(ctx.info_name)
            ctx = ctx.parent
        return " ".join(reversed(names))

    @property
    def terminal_width_value(self) -> int:
        if self.terminal_width is not None:
            return self.terminal_width
        return min(shutil.get_terminal_size((80, 24)).columns, self.max_content_width)

    def auto_envvar_prefix_name_for(self, param) -> Optional[str]:
        # spec: FP-07 PREFIX_SUB_COMMAND..._DEST uppercased with underscores
        root = self.root
        if root.auto_envvar_prefix is None:
            return None
        names = [root.auto_envvar_prefix]
        chain = []
        ctx = self
        while ctx is not None and ctx.parent is not None:
            chain.append(ctx.info_name or ctx.command.name)
            ctx = ctx.parent
        names.extend(reversed(chain))
        names.append(param.name)
        return "_".join(str(n) for n in names).replace("-", "_").upper()

    def get_parameter_source(self, name: str):
        if name not in {p.name for p in self.command.get_params(self) if p.name}:
            return None
        src = self.param_sources.get(name)
        return SOURCE_OBJECTS.get(src) if src else None

    def lookup_default(self, name: str):
        if isinstance(self.default_map, dict) and name in self.default_map:
            return True, self.default_map[name]
        return False, None

    def find_object(self, object_type, ensure: bool = False):
        ctx = self
        while ctx is not None:
            if ctx.obj is not None and type(ctx.obj) is object_type:
                return ctx.obj
            ctx = ctx.parent
        if ensure:
            obj = object_type()
            self.obj = obj
            return obj
        return None

    def with_resource(self, cm):
        # spec: FP-07 resources stay open until the invocation ends
        return self._exit_stack.enter_context(cm)

    def call_on_close(self, func: Callable[[], None]) -> None:
        self._exit_stack.callback(func)

    def invoke(self, other, *args, **kwargs):
        """Run another command from inside a callback, with exactly these values."""
        if isinstance(other, Command):
            sub = other.make_context(other.name, [], parent=self)
            with sub:
                try:
                    # spec: FP-07 invoke supplies exactly the caller's chosen values
                    if other.callback is None:
                        return None
                    return other.callback(*args, **kwargs)
                finally:
                    sub.close()
        return other(*args, **kwargs)

    def forward(self, other, *args, **kwargs):
        merged = dict(self.params)
        merged.update(kwargs)
        return self.invoke(other, *args, **merged)

    def exit(self, code: int = 0):
        raise Exit(code)

    def abort(self):
        raise Abort("Aborted!")

    def __enter__(self):
        _context.push(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        _context.pop()
        return False

    def close(self) -> None:
        if not self._closed:
            self._closed = True
            self._exit_stack.close()


class Command:
    """A leaf command. Created by the ``command`` decorator."""

    interspersed_default = True
    context_defaults = None

    def __init__(self, name=None, callback=None, params=None, help=None,
                 short_help=None, epilog=None, options_metavar="[OPTIONS]",
                 context_settings=None, add_help_option=True,
                 no_args_is_help=False, deprecated=False, hidden=False,
                 **attrs) -> None:
        self.name = name
        self.callback = callback
        self.params: List[Parameter] = list(params or [])
        self.help = help
        self.short_help = short_help
        self.epilog = epilog
        self.options_metavar = options_metavar
        self.context_settings = dict(context_settings or {})
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.deprecated = deprecated
        self.hidden = hidden
        self.attrs = attrs

    # ---- declarations -------------------------------------------------
    def get_params(self, ctx) -> List[Parameter]:
        params = list(self.params)
        if self.add_help_option:
            author_names = set()
            for p in params:
                if isinstance(p, Option):
                    author_names.update(p.opts)
            names = [n for n in ctx.help_option_names if n not in author_names]
            if names:
                # spec: FP-02 help names overlapping an author option are left to the author option
                params.insert(0, Option(
                    ["help_option_"] + names, is_flag=True, is_eager=True,
                    expose_value=False, callback=_help_callback, help="Show this message and exit."))
        return params

    def get_help(self, ctx) -> str:
        return render_help(self, ctx)

    def get_short_help(self) -> str:
        if self.short_help:
            return self.short_help
        return _first_sentence(self.help or "")

    @property
    def is_group(self) -> bool:
        return False

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    # ---- invocation ---------------------------------------------------
    def make_context(self, info_name, args, parent=None, **extra) -> Context:
        ctx = Context(self, parent=parent, info_name=info_name, **extra)
        ctx.args = list(args)
        return ctx

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True,
             **extra):
        tokens = list(sys.argv[1:] if args is None else args)
        prog = prog_name or os.path.basename(sys.argv[0] or "app")
        if prog.endswith(".py"):
            prog = prog[:-3]
        var = complete_var or "_" + prog.upper().replace("-", "_") + "_COMPLETE"
        if var in os.environ:
            from .completion import run_completion

            return run_completion(self, prog, os.environ[var], tokens, standalone_mode)
        ctx = self.make_context(prog, tokens, **extra)
        try:
            try:
                with ctx:
                    rv = self.invoke(ctx)
                    if not standalone_mode:
                        return rv
            finally:
                ctx.close()
        except (EOFError, KeyboardInterrupt) as exc:
            if not standalone_mode:
                raise
            _echo_err("Aborted!")
            sys.exit(1)
        except Exit as exc:
            if not standalone_mode:
                return exc.exit_code
            sys.exit(exc.exit_code)
        except NoArgsIsHelpError as exc:
            if not standalone_mode:
                raise
            # spec: FP-13 the help shown for incorrect usage is the failing command's own page
            _echo_err(render_help(exc.command or self, exc.ctx or ctx, stream_err=True))
            sys.exit(2)
        except UsageError as exc:
            if not standalone_mode:
                raise
            exc.show()
            if exc.ctx is None:
                _echo_err(f"Try '{prog} --help' for help.")
            sys.exit(2)
        except Abort as exc:
            if not standalone_mode:
                raise
            _echo_err(f"Aborted! {exc}".rstrip() if str(exc) not in ("", "Aborted!") else "Aborted!")
            sys.exit(1)
        except (OptlynError, FileError) as exc:
            if not standalone_mode:
                raise
            _echo_err(f"Error: {exc.message if hasattr(exc, 'message') else exc}")
            sys.exit(1)
        if standalone_mode:
            sys.exit(0)
        return rv

    def invoke(self, ctx: Context):
        """Parse this command's own tokens and run its callback."""
        self.parse_and_bind(ctx, ctx.args)
        if ctx.args_extra_error:
            raise UsageError(ctx.args_extra_error, ctx, self)
        return self._run_callback(ctx)

    def _run_callback(self, ctx):
        if self.deprecated:
            _warn_deprecated(self, ctx)
        if self.callback is None:
            return None
        kwargs = {p.name: ctx.params.get(p.name) for p in self.get_params(ctx)
                  if p.name and p.expose_value}
        return self.callback(**kwargs)

    def parse_and_bind(self, ctx, tokens, interspersed=None):
        """Parse options and arguments from ``tokens``; fills ctx.params."""
        params = self.get_params(ctx)
        options = [p for p in params if isinstance(p, Option)]
        arguments = [p for p in params if isinstance(p, Argument)]
        parser = Parser(options, ctx)
        result = parser.parse(list(tokens), interspersed=interspersed)
        ctx.args_extra_error = None
        if result.stop_index is not None:
            ctx.leftover_tokens = result.positionals
            ctx.stopped = True
        else:
            ctx.stopped = False
        bound_args, leftover = _bind_arguments(ctx, arguments, result.positionals, self,
                                               is_last=(not ctx.stopped))
        ctx.leftover_tokens = leftover
        for param in options + arguments:
            if param.is_eager:
                continue  # eager flags already ran during parsing
            if isinstance(param, Argument):
                occs = bound_args.get(param.name, [])
            else:
                occs = result.seen.get(param.name, []) if param.name else []
            _resolve_and_store(ctx, param, occs)
        ctx.args = leftover
        if not ctx.stopped and leftover and not ctx.allow_extra_args \
                and not self.has_variadic(arguments):
            ctx.args_extra_error = f"Got unexpected extra argument(s): {' '.join(leftover)}"
        return ctx

    def has_variadic(self, arguments) -> bool:
        return any(a.is_variadic for a in arguments)


class Group(Command):
    """A command that dispatches to named subcommands."""

    interspersed_default = False

    def __init__(self, name=None, commands=None, invoke_without_command=False,
                 no_args_is_help=None, subcommand_metavar=None, chain=False,
                 result_callback=None, **kwargs) -> None:
        if no_args_is_help is None:
            # spec: FP-06 no-args-is-help defaults to the opposite of invoke_without_command
            no_args_is_help = not invoke_without_command
        super().__init__(name=name, no_args_is_help=no_args_is_help, **kwargs)
        self.commands: Dict[str, Command] = dict(commands or {})
        self.invoke_without_command = invoke_without_command
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback
        self.interspersed = False

    @property
    def is_group(self) -> bool:
        return True

    def add_command(self, cmd: Command, name=None) -> None:
        # spec: FP-10 groups cannot be nested beneath a chaining group
        if isinstance(cmd, Group) and self.chain:
            raise TypeError("Cannot attach a group beneath a chaining group.")
        key = name or cmd.name
        if key is None:
            raise TypeError("A command needs a name to be registered.")
        self.commands[key] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as _command_deco

        # spec: FP-06 the group's helper attaches the decorated child to this group
        deco = _command_deco(*args, **kwargs)

        def decorator(f):
            cmd = deco(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as _group_deco

        deco = _group_deco(*args, **kwargs)

        def decorator(f):
            grp = deco(f)
            self.add_command(grp)
            return grp

        return decorator

    def result_callback(self, f=None):
        """Decorator: register the callback that receives subcommand return values."""
        def decorator(func):
            self._result_callback = func
            return func

        return decorator(f) if f is not None else decorator

    def list_commands(self, ctx) -> List[str]:
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name: str):
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        return None

    def _resolve_name(self, ctx, token: str):
        cmd = self.get_command(ctx, token)
        if cmd is not None:
            return token, cmd
        func = ctx.token_normalize_func
        if func is not None:
            for name in self.list_commands(ctx):
                if func(name) == func(token):
                    return name, self.get_command(ctx, name)
        return None, None

    def invoke(self, ctx: Context):
        # spec: FP-06 group options come before the subcommand name
        self.parse_and_bind(ctx, ctx.args)
        if ctx.args_extra_error:
            raise UsageError(ctx.args_extra_error, ctx, self)
        rest = list(ctx.leftover_tokens)
        if not rest:
            if self.no_args_is_help and not ctx.args:
                raise NoArgsIsHelpError(f"Missing command.", ctx, self)
            if not self.invoke_without_command:
                raise UsageError("Missing command.", ctx, self)
            if self.chain:
                return self._finish_chain(ctx, [])
            return self._run_callback(ctx)
        if self.chain:
            return self._invoke_chain(ctx, rest)
        name_token = rest[0]
        name, cmd = self._resolve_name(ctx, name_token)
        if cmd is None:
            raise UsageError(f"No such command {name_token!r}.", ctx, self)
        ctx.invoked_subcommand = name
        group_value = self._run_callback(ctx)
        sub = cmd.make_context(name, rest[1:], parent=ctx)
        try:
            with sub:
                value = cmd.invoke(sub)
        finally:
            sub.close()
        if self._result_callback is not None:
            return self._result_callback(value, **ctx.params)
        return value

    def _invoke_chain(self, ctx: Context, rest: List[str]):
        ctx.invoked_subcommand = _CHAIN_MARKER
        self._run_callback(ctx)
        values = []
        tokens = list(rest)
        while tokens:
            name, cmd = self._resolve_name(ctx, tokens[0])
            if cmd is None:
                raise UsageError(f"No such command {tokens[0]!r}.", ctx, self)
            sub = cmd.make_context(name, [], parent=ctx)
            try:
                with sub:
                    # chained children take their own options and arguments, then the next name
                    sub.args = tokens[1:]
                    cmd.parse_and_bind(sub, tokens[1:], interspersed=False)
                    tokens = list(sub.leftover_tokens)
                    if sub.args_extra_error and not tokens:
                        pass
                    values.append(cmd._run_callback(sub))
            finally:
                sub.close()
        return self._finish_chain(ctx, values)

    def _finish_chain(self, ctx, values):
        if self._result_callback is not None:
            return self._result_callback(values, **ctx.params)
        return values


_CHAIN_MARKER = object()


class CommandCollection(Group):
    """Presents subcommands gathered from several groups under one surface."""

    def __init__(self, name=None, sources=None, **kwargs) -> None:
        super().__init__(name=name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx) -> List[str]:
        names = set()
        for src in self.sources:
            names.update(src.list_commands(ctx))
        names.update(self.commands)
        return sorted(names)

    def get_command(self, ctx, cmd_name: str):
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        for src in self.sources:
            found = src.get_command(ctx, cmd_name)
            if found is not None:
                return found
        return None


def _help_callback(ctx, param, value):
    # spec: FP-02 help prints to stdout and exits 0 without running the callback
    if not value or ctx is None:
        return
    from .termui import echo

    echo(ctx.command.get_help(ctx), nl=False)
    raise Exit(0)


def _first_sentence(text: str) -> str:
    text = text.split("\f")[0].strip()
    if not text:
        return ""
    for end in (". ", ".\n"):
        if end in text:
            return text[: text.index(end) + 1]
    return text.split("\n\n")[0].strip()


def _echo_err(text: str) -> None:
    from .termui import echo

    echo(text, err=True)


def _warn_deprecated(obj, ctx) -> None:
    # spec: FP-01 deprecation warning; CF-000146 resolved to standard error
    from .termui import echo

    msg = obj.name and f"DeprecationWarning: The command {obj.name!r} is deprecated."
    if isinstance(obj.deprecated, str):
        msg += " " + obj.deprecated
    echo(msg, err=True)


def _resolve_and_store(ctx, param, occs):
    from .resolution import resolve_param

    value, source = resolve_param(ctx, param, occs)
    if param.expose_value and param.name:
        ctx.params[param.name] = value
        ctx.param_sources[param.name] = source
    elif param.name:
        ctx.params[param.name] = value
        ctx.param_sources[param.name] = source


def _bind_arguments(ctx, arguments, tokens, command, is_last=True):
    """Bind positional tokens to arguments in declaration order (FP-04)."""
    bound: Dict[str, list] = {}
    pos = 0
    remaining = list(tokens)
    for idx, arg in enumerate(arguments):
        later_fixed = sum(a.nargs for a in arguments[idx + 1:] if not a.is_variadic)
        if arg.is_variadic:
            take = max(0, len(remaining) - pos - later_fixed)
            chunk = remaining[pos:pos + take]
            pos += take
            if chunk:
                bound[arg.name] = [_Occ("tokens", chunk)]
            continue
        need = arg.nargs
        available = remaining[pos:pos + need]
        if len(available) == need and available:
            bound[arg.name] = [_Occ("tokens", list(available))]
            pos += need
    leftover = remaining[pos:]
    # a missing required fixed argument is caught when resolving (no occurrence)
    return bound, leftover


class _Occ:
    __slots__ = ("kind", "value")

    def __init__(self, kind, value):
        self.kind = kind
        self.value = value

