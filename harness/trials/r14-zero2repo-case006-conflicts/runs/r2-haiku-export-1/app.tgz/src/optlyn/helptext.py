"""Help page rendering (FP-02, interface contract section 2)."""

from __future__ import annotations

from .formatting import HelpFormatter, wrap_text
from .params import Argument, Option


def _usage_line(command, ctx) -> str:
    prog = ctx.command_path if ctx is not None else (command.name or "")
    parts = [prog]
    opts_ph = command.options_metavar
    params = command.get_params(ctx) if ctx is not None else command.params
    if opts_ph:
        parts.append(opts_ph)
    for arg in (p for p in params if isinstance(p, Argument)):
        ph = arg.placeholder()
        if arg.is_variadic:
            ph = f"[{ph}]..." if not arg.required else f"{ph}..."
        elif not arg.required:
            ph = f"[{ph}]"
        parts.append(ph)
    if command.is_group:
        if command.invoke_without_command or not command.no_args_is_help:
            parts.append("[COMMAND [ARGS]...]" if not command.chain else "[COMMAND [ARGS]]...")
        else:
            parts.append("COMMAND [ARGS]...")
        if command.chain:
            parts[-1] = "[COMMAND [ARGS]]..."
    return "Usage: " + " ".join(parts)


def _option_entry(opt: Option, ctx) -> tuple[str, str]:
    names = list(opt.opts)
    if opt.secondary_opts:
        names = [f"{a}/{b}" for a, b in zip(opt.opts, opt.secondary_opts)] + names[len(opt.secondary_opts):]
    first = ", ".join(names)
    if opt.metavar and not opt.is_flag:
        first += f" {opt.metavar}"
    elif not opt.is_flag and not opt.count and opt.opts:
        first += f" {opt.type.get_metavar(opt) or opt.type.name.upper()}"
    extras = []
    if opt.help:
        text = opt.help
    else:
        text = ""
    from .paramtypes import Choice

    if isinstance(opt.type, Choice):
        extras.append("choices: " + ", ".join(str(getattr(c, "name", c)) for c in opt.type.choices))
    show = opt.show_default if opt.show_default is not None else (ctx.show_default if ctx else False)
    if show and opt.default is not None and not (opt.is_flag and opt.default is False):
        shown = opt.show_default if isinstance(opt.show_default, str) else opt.default
        extras.append(f"default: {shown}")
    if opt.show_envvar and opt.envvar:
        env = opt.envvar if isinstance(opt.envvar, str) else ", ".join(opt.envvar)
        extras.append(f"env var: {env}")
    if opt.deprecated:
        extras.append("deprecated")
    if extras:
        text = (text + " " if text else "") + "[" + "; ".join(extras) + "]"
    return first, text


def render_help(command, ctx, stream_err: bool = False) -> str:
    """Render the help page for ``command`` as a string."""
    width = ctx.terminal_width_value if ctx is not None else 80
    explicit = ctx is not None and ctx.terminal_width is not None
    fmt = HelpFormatter(width=width, explicit_width=explicit)
    params = command.get_params(ctx) if ctx is not None else command.params
    fmt.write(_usage_line(command, ctx))
    fmt.write("")
    description = command.help or ""
    if not command.help and command.callback is not None and command.callback.__doc__:
        description = command.callback.__doc__
    description = description.split("\f")[0]
    if command.deprecated:
        description = (description + "\n\n" if description else "") + "(Deprecated)"
    fmt.write_paragraph(description.strip("\n"))
    args = [p for p in params if isinstance(p, Argument) and p.help]
    if args:
        fmt.write("Positional arguments:")
        fmt.write_definitions([(a.placeholder(), a.help) for a in args])
    options = [p for p in params if isinstance(p, Option) and not p.hidden]
    if options:
        fmt.write("Options:")
        fmt.write_definitions([_option_entry(o, ctx) for o in options])
    if command.is_group:
        children = []
        if ctx is not None:
            for name in command.list_commands(ctx):
                cmd = command.get_command(ctx, name)
                if cmd is None or cmd.hidden:
                    continue
                children.append((name, cmd.get_short_help()))
        if children:
            fmt.write("Commands:")
            fmt.write_definitions(children)
    if command.epilog:
        fmt.write_paragraph(command.epilog)
    return fmt.getvalue()
