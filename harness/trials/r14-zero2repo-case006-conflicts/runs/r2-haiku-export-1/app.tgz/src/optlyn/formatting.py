"""Text wrapping helpers."""

from __future__ import annotations

import textwrap

# spec: N-001013 maximum content width of 100 columns unless the caller sets another
MAX_CONTENT_WIDTH = 100


def wrap_text(text: str, width: int = 78, initial_indent: str = "",
              subsequent_indent: str = "", preserve_paragraphs: bool = False) -> str:
    """Wrap ``text`` to ``width`` columns. Accepts any string."""
    if not text:
        return ""
    width = max(width, 1)
    if not preserve_paragraphs:
        return textwrap.fill(" ".join(text.split()), width=width,
                             initial_indent=initial_indent,
                             subsequent_indent=subsequent_indent,
                             break_long_words=True, break_on_hyphens=False)
    out = []
    for para in text.split("\n\n"):
        lines = para.split("\n")
        if lines and lines[0].strip() == "\b":
            # spec: N-000131 backspace-first paragraph keeps its line breaks
            kept = [ln for ln in lines[1:]]
            out.append("\n".join(subsequent_indent + ln for ln in kept))
            continue
        out.append(textwrap.fill(" ".join(para.split()), width=width,
                                 initial_indent=initial_indent,
                                 subsequent_indent=subsequent_indent,
                                 break_on_hyphens=False))
    return "\n\n".join(out)


class HelpFormatter:
    """Collects and renders help sections with consistent indentation."""

    def __init__(self, width: int = 80, max_width: int = MAX_CONTENT_WIDTH,
                 explicit_width: bool = False) -> None:
        # spec: N-000126..N-000131 max content width caps auto-detected width only
        self.width = width if explicit_width else min(width, max_width)
        self.indent = 0
        self.parts: list[str] = []

    def write(self, text: str = "") -> None:
        self.parts.append(text)

    def write_paragraph(self, text: str) -> None:
        if text:
            self.parts.append(wrap_text(text, self.width, preserve_paragraphs=True))
            self.parts.append("")

    def write_definitions(self, rows: list[tuple[str, str]], col: int = 24) -> None:
        for first, second in rows:
            pad = " " * 2
            if len(first) + 2 >= col or not second:
                self.parts.append(f"{pad}{first}")
                if second:
                    self.parts.append(
                        wrap_text(second, self.width - col - 2,
                                  initial_indent=" " * (col + 2),
                                  subsequent_indent=" " * (col + 2)))
            else:
                body = wrap_text(second, self.width - col - 2,
                                 initial_indent="", subsequent_indent=" " * (col + 2))
                self.parts.append(f"{pad}{first.ljust(col)}{body}")
        self.parts.append("")

    def getvalue(self) -> str:
        return "\n".join(self.parts).rstrip("\n") + "\n"
