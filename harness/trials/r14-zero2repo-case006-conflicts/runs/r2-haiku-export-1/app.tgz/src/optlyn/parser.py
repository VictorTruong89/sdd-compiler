"""Token parsing for options and positional arguments (POSIX-style)."""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

from .exceptions import BadOptionUsage, NoSuchOption


class Occurrence:
    """One appearance of a parameter on the command line."""

    __slots__ = ("kind", "value")

    def __init__(self, kind: str, value=None) -> None:
        # kind: "flag" (value is the flag value), "count", "tokens" (list of str),
        # or "noval" (a value option given with no value)
        self.kind = kind
        self.value = value


class ParseResult:
    def __init__(self) -> None:
        self.seen: Dict[str, List[Occurrence]] = {}
        self.positionals: List[str] = []
        self.stop_index: Optional[int] = None  # index where non-interspersed parsing stopped
        self.order: List = []  # (param, occurrence) in command-line order

    def add(self, param, occ: Occurrence) -> None:
        self.seen.setdefault(param.name, []).append(occ)
        self.order.append((param, occ))


class Parser:
    """Parses a token list against a set of Option objects."""

    def __init__(self, options, ctx) -> None:
        self.ctx = ctx
        self.table: Dict[str, Tuple[object, bool]] = {}
        self.prefixes = {"-"}
        for opt in options:
            for name in opt.opts:
                self.table[self._norm(name)] = (opt, False)
                self.prefixes.add(name[0])
            for name in opt.secondary_opts:
                self.table[self._norm(name)] = (opt, True)
        self.interspersed = ctx.allow_interspersed_args
        self.ignore_unknown = ctx.ignore_unknown_options

    def _norm(self, token: str) -> str:
        func = self.ctx.token_normalize_func
        return func(token) if func else token

    def _lookup(self, token: str):
        return self.table.get(self._norm(token))

    def is_option_like(self, token: str) -> bool:
        return len(token) > 1 and token[0] in self.prefixes

    def parse(self, tokens: List[str], interspersed: Optional[bool] = None) -> ParseResult:
        if interspersed is None:
            interspersed = self.interspersed
        result = ParseResult()
        i = 0
        n = len(tokens)
        while i < n:
            tok = tokens[i]
            if tok == "--":
                # spec: FP-04 after `--` tokens are arguments; the `--` is not delivered
                result.positionals.extend(tokens[i + 1:])
                break
            if not self.is_option_like(tok):
                if not interspersed:
                    result.stop_index = i
                    result.positionals.extend(tokens[i:])
                    break
                result.positionals.append(tok)
                i += 1
                continue
            consumed = self._handle_option(tok, tokens, i, result)
            if consumed is None:
                # unknown option treated as an argument (ignore_unknown_options)
                result.positionals.append(tok)
                i += 1
            else:
                i += consumed
        return result

    def _handle_option(self, tok, tokens, i, result) -> Optional[int]:
        if tok[:2] == tok[0] * 2 and len(tok) > 2:
            name, eq, value = tok.partition("=")
            found = self._lookup(name)
            if found is None:
                return self._unknown(tok)
            return self._take(found, name, eq == "=" and value, tokens, i, result)
        # short option(s) possibly stacked
        prefix = tok[0]
        stack = tok[1:]
        for j, ch in enumerate(stack):
            name = prefix + ch
            found = self._lookup(name)
            if found is None:
                if self.ignore_unknown:
                    return None
                raise NoSuchOption(f"No such option: {name}", self.ctx)
            rest = stack[j + 1:]
            param, _ = found
            if param.is_flag or param.count:
                self._take_flag(found, result)
                continue
            # value option: attached value or the next token
            return self._take(found, name, rest if rest else False, tokens, i, result)
        return 1

    def _take_flag(self, found, result):
        param, secondary = found
        if param.is_eager:
            # spec: FP-02 the eager flag the user typed first takes effect
            occ = Occurrence("flag", False if secondary else param.flag_value)
            result.add(param, occ)
            param.run_eager(self.ctx, occ.value)
            return
        if param.count:
            result.add(param, Occurrence("count", 1))
        else:
            result.add(param, Occurrence("flag", False if secondary else param.flag_value))

    def _take(self, found, name, attached, tokens, i, result) -> int:
        param, secondary = found
        if param.is_flag or param.count:
            if attached:
                # a flag cannot take an attached value
                raise BadOptionUsage(f"Option {name} does not take a value.", self.ctx)
            self._take_flag(found, result)
            return 1
        if attached is not False and attached is not None and attached != "":
            if param.nargs != 1:
                raise BadOptionUsage(f"Option {name} requires {param.nargs} values.", self.ctx)
            result.add(param, Occurrence("tokens", [attached]))
            return 1
        # optional-value options take a following token only if it is not option-like
        if param.flag_value_explicit:
            nxt = tokens[i + 1] if i + 1 < len(tokens) else None
            if nxt is None or self.is_option_like(nxt) or nxt == "--":
                result.add(param, Occurrence("flag", param.flag_value))
                return 1
            result.add(param, Occurrence("tokens", [nxt]))
            return 2
        needed = param.nargs
        available = tokens[i + 1:i + 1 + needed]
        if len(available) < needed or any(t == "--" for t in available):
            if param.prompt:
                result.add(param, Occurrence("noval"))
                return 1
            raise BadOptionUsage(f"Option {name} requires an argument.", self.ctx)
        result.add(param, Occurrence("tokens", list(available)))
        return 1 + needed

    def _unknown(self, tok):
        if self.ignore_unknown:
            return None
        raise NoSuchOption(f"No such option: {tok}", self.ctx)
