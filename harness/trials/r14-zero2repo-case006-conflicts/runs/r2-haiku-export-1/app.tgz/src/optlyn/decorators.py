"""Declaration decorators: command, group, option, argument, and ready-made options."""

from __future__ import annotations

import functools
import importlib.metadata
import sys
from typing import Callable

from . import _context
from .core import Command, CommandCollection, Group, _help_callback
from .exceptions import Exit
from .params import Argument, Option


def _is_bare(args) -> bool:
    """True when a ready-made decorator was applied without parentheses."""
    return len(args) == 1 and callable(args[0]) and not isinstance(args[0], str)


def _attach(f, param) -> None:
    if not hasattr(f, "__optlyn_params__"):
        f.__optlyn_params__ = []
    f.__optlyn_params__.append(param)


def _pop_params(f):
    params = getattr(f, "__optlyn_params__", [])
    try:
        del f.__optlyn_params__
    except AttributeError:
        pass
    return list(reversed(params))


def _derive_name(func_name: str) -> str:
    # spec: FP-01 lowercase, underscores to dashes, strip a trailing _command/_cmd/_group/_grp
    name = func_name.lower()
    for suffix in ("_command", "_cmd", "_group", "_grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def command(name=None, cls=None, **attrs):
    """Turn a function into a Command. Usable as ``@command`` or ``@command()``."""
    if callable(name) and not isinstance(name, str):
        return command()(name)

    def decorator(f):
        params = _pop_params(f)
        cmd_cls = cls or Command
        cmd_name = name if name is not None else _derive_name(f.__name__)
        cmd = cmd_cls(name=cmd_name, callback=f, params=params, **attrs)
        return cmd

    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a Group. Usable as ``@group`` or ``@group()``."""
    if callable(name) and not isinstance(name, str):
        return group()(name)

    def decorator(f):
        params = _pop_params(f)
        grp_cls = cls or Group
        grp_name = name if name is not None else _derive_name(f.__name__)
        grp = grp_cls(name=grp_name, callback=f, params=params, **attrs)
        return grp

    return decorator


def option(*param_decls, cls=None, **attrs):
    """Attach an option to the function beneath it."""
    option_cls = cls or Option

    def decorator(f):
        _attach(f, option_cls(list(param_decls), **attrs))
        return f

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach a positional argument to the function beneath it."""
    arg_cls = cls or Argument

    def decorator(f):
        _attach(f, arg_cls(list(param_decls), **attrs))
        return f

    return decorator


def pass_context(f: Callable) -> Callable:
    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(_context.get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(f: Callable) -> Callable:
    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(_context.get_current_context().obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type, ensure: bool = False):
    def decorator(f):
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = _context.get_current_context()
            obj = ctx.find_object(object_type, ensure)
            return f(obj, *args, **kwargs)

        return new_func

    return decorator


def help_option(*param_decls, **kwargs):
    """An extra eager help flag. The declared names print help and exit 0."""
    if _is_bare(param_decls):
        return help_option()(param_decls[0])
    decls = list(param_decls) or ["--help"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("callback", _help_callback)
    kwargs.setdefault("help", "Show this message and exit.")

    def decorator(f):
        _attach(f, Option(decls, **kwargs))
        return f

    return decorator


def _version_text(package_name, prog_name):
    if package_name is None:
        return None
    try:
        return importlib.metadata.version(package_name)
    except importlib.metadata.PackageNotFoundError:
        pass
    # spec: FP-02 an import name resolves to the distribution that provides it
    mapping = importlib.metadata.packages_distributions()
    for dist in mapping.get(package_name, []):
        try:
            return importlib.metadata.version(dist)
        except importlib.metadata.PackageNotFoundError:
            continue
    return None


def version_option(version=None, *param_decls, package_name=None, prog_name=None,
                   message=None, **kwargs):
    """Eager version flag. Prints the identity and exits 0."""
    if version is not None and _is_bare((version,)) and not param_decls:
        return version_option()(version)
    decls = list(param_decls) or ["--version"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")

    def callback(ctx, param, value):
        if not value or ctx is None:
            return
        from .termui import echo

        ver = version if version is not None else _version_text(package_name, prog_name)
        if ver is None:
            ver = "unknown"
        name = prog_name or ctx.root.info_name or ctx.command.name or "app"
        text = (message or "%(prog)s, version %(version)s") % {"prog": name, "version": ver}
        echo(text)
        raise Exit(0)

    kwargs.setdefault("callback", callback)

    def decorator(f):
        _attach(f, Option(decls, **kwargs))
        return f

    return decorator


def custom_version_option(callback, *param_decls, **kwargs):
    """Eager version flag whose whole identity is ``callback(ctx)``."""
    decls = list(param_decls) or ["--version"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")

    def _cb(ctx, param, value):
        if not value or ctx is None:
            return
        from .termui import echo

        echo(callback(ctx))
        raise Exit(0)

    kwargs["callback"] = _cb

    def decorator(f):
        _attach(f, Option(decls, **kwargs))
        return f

    return decorator


def password_option(*param_decls, **kwargs):
    """A prompting, hidden, confirmed option (default ``--password``)."""
    if _is_bare(param_decls):
        return password_option()(param_decls[0])
    decls = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)

    def decorator(f):
        _attach(f, Option(decls, **kwargs))
        return f

    return decorator


def confirmation_option(*param_decls, **kwargs):
    """A yes flag that asks when omitted and aborts when declined."""
    if _is_bare(param_decls):
        return confirmation_option()(param_decls[0])
    decls = list(param_decls) or ["--yes"]
    prompt_text = kwargs.pop("prompt", "Do you want to continue?")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Confirm the action without prompting.")

    def _cb(ctx, param, value):
        if value:
            return value
        from .termui import confirm

        confirm(prompt_text, default=False, abort=True)
        return True

    kwargs["callback"] = _cb

    def decorator(f):
        _attach(f, Option(decls, **kwargs))
        return f

    return decorator
