"""Shell completion: registration scripts and suggestion streams (FP-12, section 8)."""

from __future__ import annotations

import os
import sys
from typing import List

from .params import Argument, Option
from .paramtypes import Choice, File, Path

SHELLS = ("bash", "zsh", "fish", "powershell")


def _script(shell: str, prog: str, var: str) -> str:
    if shell == "bash":
        fn = "_" + prog.replace("-", "_") + "_completion"
        return (
            f"{fn}() {{\n"
            f"    local IFS=$'\\n'\n"
            f"    COMPREPLY=( $( env COMP_WORDS=\"${{COMP_WORDS[*]}}\" COMP_CWORD=$COMP_CWORD "
            f"{var}=bash_complete {prog} ) )\n"
            f"    return 0\n}}\n"
            f"complete -o default -F {fn} {prog}\n")
    if shell == "zsh":
        fn = "_" + prog.replace("-", "_") + "_completion"
        return (
            f"#compdef {prog}\n"
            f"{fn}() {{\n"
            f"    local -a items\n"
            f"    items=(${{(f)\"$(env COMP_WORDS=\"${{words[*]}}\" COMP_CWORD=$((CURRENT-1)) "
            f"{var}=zsh_complete {prog})\"}})\n"
            f"    _describe 'values' items\n}}\n"
            f"compdef {fn} {prog}\n")
    if shell == "fish":
        return (
            f"complete --no-files --command {prog} --arguments "
            f"'(env COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -ct) "
            f"{var}=fish_complete {prog})'\n")
    return (
        f"Register-ArgumentCompleter -Native -CommandName {prog} -ScriptBlock {{\n"
        f"    param($wordToComplete, $commandAst, $cursorPosition)\n"
        f"    $env:COMP_WORDS = $commandAst.ToString()\n"
        f"    $env:COMP_CWORD = $wordToComplete\n"
        f"    $env:{var} = 'powershell_complete'\n"
        f"    & {prog} | ForEach-Object {{ [System.Management.Automation.CompletionResult]::new($_) }}\n"
        f"    Remove-Item Env:{var}\n}}\n")


def _param_suggestions(ctx, param, incomplete: str):
    """Yield (type, value, help) tuples for a parameter's value."""
    func = getattr(param, "shell_complete", None)
    if func is not None:
        for item in func(ctx, param, incomplete) or []:
            if isinstance(item, str):
                yield ("plain", item, None)
            else:
                yield (getattr(item, "type", "plain") or "plain", item.value, item.help)
        return
    ptype = param.type
    if isinstance(ptype, (File, Path)):
        kind = "dir" if isinstance(ptype, Path) and not ptype.file_okay else "file"
        yield (kind, incomplete, None)
        return
    if isinstance(ptype, Choice):
        for val in ptype.shell_complete(ctx, param, incomplete):
            yield ("plain", val, None)
        return
    custom = getattr(ptype, "shell_complete", None)
    if custom is not None:
        for item in custom(ctx, param, incomplete) or []:
            if isinstance(item, str):
                yield ("plain", item, None)
            else:
                yield (getattr(item, "type", "plain") or "plain", item.value, item.help)


def _suggest(cmd, ctx, args: List[str], incomplete: str):
    """Return the suggestion tuples for ``incomplete`` after ``args``."""
    from .core import Group

    params = cmd.get_params(ctx)
    options = [p for p in params if isinstance(p, Option)]
    by_name = {}
    for opt in options:
        for n in list(opt.opts) + list(opt.secondary_opts):
            by_name[n] = opt
    # walk the already-typed tokens
    i = 0
    pending_value_for = None
    while i < len(args):
        tok = args[i]
        if pending_value_for is not None:
            pending_value_for = None
            i += 1
            continue
        if tok == "--":
            i += 1
            break
        if tok in by_name and not by_name[tok].is_flag and not by_name[tok].count:
            pending_value_for = by_name[tok]
            i += 1
            continue
        if isinstance(cmd, Group) and not tok.startswith("-"):
            name, child = cmd._resolve_name(ctx, tok)
            if child is not None:
                return _suggest(child, ctx, args[i + 1:], incomplete)
            break
        i += 1
    if pending_value_for is not None:
        return list(_param_suggestions(ctx, pending_value_for, incomplete))
    out = []
    if incomplete.startswith("-") or (incomplete == "" and not isinstance(cmd, Group) and False):
        for opt in options:
            if opt.hidden:
                continue
            for n in list(opt.opts) + list(opt.secondary_opts):
                if n.startswith(incomplete):
                    out.append(("plain", n, opt.help))
        return out
    if isinstance(cmd, Group):
        for name in cmd.list_commands(ctx):
            child = cmd.get_command(ctx, name)
            if child is None or child.hidden:
                continue
            if name.startswith(incomplete):
                out.append(("plain", name, child.get_short_help()))
        return out
    for arg in [p for p in params if isinstance(p, Argument)]:
        out.extend(_param_suggestions(ctx, arg, incomplete))
        break
    return out


def run_completion(cmd, prog: str, instruction: str, tokens, standalone: bool):
    """Handle the completion environment variable; never runs the callback."""
    var = "_" + prog.upper().replace("-", "_") + "_COMPLETE"
    shell, _, action = instruction.partition("_")
    if shell not in SHELLS or action not in ("source", "complete"):
        # spec: FP-12 unknown instruction prints nothing and does not run the callback
        if standalone:
            sys.exit(1)
        return None
    if action == "source":
        sys.stdout.write(_script(shell, prog, var))
        sys.stdout.flush()
        if standalone:
            sys.exit(0)
        return None
    raw = os.environ.get("COMP_WORDS", "")
    words = raw.split(" ")
    if shell == "fish":
        incomplete = os.environ.get("COMP_CWORD", "")
        args = words[1:]
        if args and args[-1] == incomplete:
            args = args[:-1]
    else:
        try:
            cword = int(os.environ.get("COMP_CWORD", str(len(words))))
        except ValueError:
            cword = len(words)
        args = words[1:cword]
        incomplete = words[cword] if 0 <= cword < len(words) else ""
    from .core import Context

    ctx = cmd.make_context(prog, [])
    with ctx:
        suggestions = _suggest(cmd, ctx, args, incomplete)
    lines = []
    for kind, value, help_text in suggestions:
        if kind == "plain":
            lines.append(f"{value}\t{help_text or ''}".rstrip("\t") if shell in ("zsh", "fish")
                         else value)
        else:
            lines.append(f"__{kind}__:{value}")
    sys.stdout.write("\n".join(lines) + ("\n" if lines else ""))
    sys.stdout.flush()
    if standalone:
        sys.exit(0)
    return None
