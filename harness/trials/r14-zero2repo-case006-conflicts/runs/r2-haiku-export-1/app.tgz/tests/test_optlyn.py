"""Behavioural tests for the Optlyn package (run with PYTHONPATH=src)."""

import optlyn as o
from optlyn.testing import CliRunner


def _runner():
    return CliRunner()


def test_command_name_derivation_strips_suffix():
    @o.command()
    def fetch_all_cmd():
        pass

    assert fetch_all_cmd.name == "fetch-all"


def test_option_and_argument_delivery():
    @o.command()
    @o.option("--count", "-c", type=int, default=1)
    @o.option("--tag", multiple=True)
    @o.argument("items", nargs=-1)
    def run(count, tag, items):
        o.echo(f"{count}|{tag}|{items}")

    res = _runner().invoke(run, ["-c", "3", "--tag", "a", "--tag", "b", "x", "y"])
    assert res.exit_code == 0
    assert res.output == "3|('a', 'b')|('x', 'y')\n"


def test_usage_error_exit_two_and_no_callback():
    ran = []

    @o.command()
    @o.option("--n", type=int)
    def run(n):
        ran.append(n)

    res = _runner().invoke(run, ["--n", "abc"])
    assert res.exit_code == 2
    assert ran == []
    assert "--n" in res.stderr


def test_group_no_args_is_usage_failure_with_help():
    @o.group()
    def cli():
        """Root."""

    @cli.command()
    def sub():
        pass

    res = _runner().invoke(cli, [])
    assert res.exit_code == 2
    assert "Commands:" in res.stderr


def test_intentional_help_exits_zero_and_skips_callback():
    ran = []

    @o.command()
    def run():
        ran.append(1)

    res = _runner().invoke(run, ["--help"])
    assert res.exit_code == 0
    assert "Usage:" in res.stdout
    assert ran == []


def test_env_prefix_and_default_map_precedence():
    @o.command(context_settings={"auto_envvar_prefix": "APP"})
    @o.option("--level", type=int, default=0)
    def run(level):
        o.echo(f"level={level}")

    assert _runner().invoke(run, [], env={"APP_LEVEL": "9"}).output == "level=9\n"
    assert _runner().invoke(run, [], default_map={"level": 3}).output == "level=3\n"


def test_chain_group_result_callback():
    @o.group(chain=True)
    def pipe():
        pass

    @pipe.command("double")
    def double():
        return lambda x: x * 2

    @pipe.command("inc")
    def inc():
        return lambda x: x + 1

    @pipe.result_callback()
    def run(processors):
        v = 3
        for p in processors:
            v = p(v)
        o.echo(f"result {v}")

    assert _runner().invoke(pipe, ["double", "inc"]).output == "result 7\n"


def test_prompt_reads_from_input_and_echoes():
    @o.command()
    @o.option("--ans", prompt="Answer", type=int)
    def run(ans):
        o.echo(ans)

    res = _runner().invoke(run, [], input="5\n")
    assert res.exit_code == 0
    assert res.stdout.endswith("5\n")


def test_confirmation_option_declined_aborts():
    @o.command()
    @o.confirmation_option
    def run():
        o.echo("done")

    assert _runner().invoke(run, ["--yes"]).output == "done\n"
    assert _runner().invoke(run, [], input="n\n").exit_code == 1


def test_choice_and_enum_delivery():
    import enum

    class Color(enum.Enum):
        RED = 1
        BLUE = 2

    @o.command()
    @o.option("--c", type=o.Choice(Color))
    def run(c):
        o.echo(repr(c))

    assert _runner().invoke(run, ["--c", "BLUE"]).output == "<Color.BLUE: 2>\n"
    assert _runner().invoke(run, ["--c", "PINK"]).exit_code == 2


def test_completion_lists_options_after_dash():
    @o.group()
    def root():
        pass

    @root.command()
    @o.option("--alpha")
    def leaf(alpha):
        pass

    res = _runner().invoke(root, [], env={
        "_ROOT_COMPLETE": "bash_complete",
        "COMP_WORDS": "root leaf --",
        "COMP_CWORD": "2",
    })
    assert "--alpha" in res.stdout.split()


def test_wrap_text_accepts_any_string():
    from optlyn.formatting import wrap_text

    assert wrap_text("alpha beta gamma delta", 10) == "alpha beta\ngamma\ndelta"
