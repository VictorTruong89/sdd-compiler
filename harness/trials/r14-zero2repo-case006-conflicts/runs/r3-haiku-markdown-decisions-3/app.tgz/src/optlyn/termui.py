"""Terminal helpers: echo, styling, prompts, pager, progress bars, and launchers."""

import contextlib
import io
import os
import re
import shlex
import subprocess
import sys
import tempfile
import time

from .exceptions import Abort
from .utils import _NonClosing

_ANSI_RE = re.compile(r"\033\[[0-9;?]*[ -/]*[@-~]")

_FG_COLORS = {
    "black": 30,
    "red": 31,
    "green": 32,
    "yellow": 33,
    "blue": 34,
    "magenta": 35,
    "cyan": 36,
    "white": 37,
    "reset": 39,
    "bright_black": 90,
    "bright_red": 91,
    "bright_green": 92,
    "bright_yellow": 93,
    "bright_blue": 94,
    "bright_magenta": 95,
    "bright_cyan": 96,
    "bright_white": 97,
}

_STYLE_CODES = {
    "bold": 1,
    "dim": 2,
    "italic": 3,
    "underline": 4,
    "blink": 5,
    "reverse": 7,
    "strikethrough": 9,
    "overline": 53,
}


def _current_color_flag():
    from .context import get_current_context

    ctx = get_current_context(silent=True)
    return None if ctx is None else ctx.color


def _is_tty(stream):
    try:
        return bool(stream is not None and stream.isatty())
    except (AttributeError, ValueError):
        return False


def is_interactive():
    """A session is interactive when stdin or stdout is a terminal."""
    return _is_tty(sys.stdin) or _is_tty(sys.stdout)


def strip_ansi(text):
    return _ANSI_RE.sub("", text)


def unstyle(text):
    """Remove ANSI style sequences and leave all other text."""
    return strip_ansi(text)


def _color_code(color, base):
    """Return the SGR parameter for a foreground (base 38) or background (base 48) color."""
    if isinstance(color, str):
        if color not in _FG_COLORS:
            raise ValueError(f"Unknown color {color!r}.")
        code = _FG_COLORS[color]
        if base == 48:
            if color == "reset":
                return "49"
            code += 10
        return str(code)
    if isinstance(color, bool):
        raise ValueError("Invalid color value.")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise ValueError("Color number must be between 0 and 255.")
        return f"{base};5;{color}"
    if isinstance(color, (tuple, list)) and len(color) == 3:
        if not all(isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color):
            raise ValueError("RGB components must be integers between 0 and 255.")
        return f"{base};2;{color[0]};{color[1]};{color[2]}"
    raise ValueError(f"Invalid color value {color!r}.")


def style(
    text,
    fg=None,
    bg=None,
    bold=None,
    dim=None,
    underline=None,
    overline=None,
    italic=None,
    blink=None,
    reverse=None,
    strikethrough=None,
    reset=True,
):
    """Wrap ``text`` in ANSI SGR sequences. Invalid colors raise ValueError."""
    codes = []
    if fg is not None:
        codes.append(_color_code(fg, 38))
    if bg is not None:
        codes.append(_color_code(bg, 48))
    switches = {
        "bold": bold,
        "dim": dim,
        "underline": underline,
        "overline": overline,
        "italic": italic,
        "blink": blink,
        "reverse": reverse,
        "strikethrough": strikethrough,
    }
    for name, on in switches.items():
        if on is not None and on is not False:
            codes.append(str(_STYLE_CODES[name]))
    if not codes:
        return text
    prefix = f"\033[{';'.join(codes)}m"
    suffix = "\033[0m" if reset else ""
    return f"{prefix}{text}{suffix}"


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None:
        message = style(str(message), **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def _write_text(stream, text):
    try:
        stream.write(text)
    except UnicodeEncodeError:
        # ASCII-only streams: fall back to UTF-8 bytes on the underlying buffer.
        data = text.encode("utf-8")
        buffer = getattr(stream, "buffer", None)
        if buffer is None:
            stream.write(text.encode("ascii", "backslashreplace").decode("ascii"))
        else:
            stream.flush()
            buffer.write(data)
            buffer.flush()


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write text or bytes to stdout (or stderr when ``err`` is true)."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, (bytes, bytearray)):
        buffer = getattr(file, "buffer", None)
        if buffer is not None:
            file.flush()
            buffer.write(bytes(message))
            if nl:
                buffer.write(b"\n")
            buffer.flush()
        else:
            file.write(bytes(message).decode("utf-8", "replace") + ("\n" if nl else ""))
        return
    text = str(message)
    if nl:
        text += "\n"
    if color is None:
        color = _current_color_flag()
    if color is None:
        color = _is_tty(file)
    if not color:
        text = strip_ansi(text)
    _write_text(file, text)
    try:
        file.flush()
    except (AttributeError, ValueError):
        pass


def prompt_text_input(prompt_str, hide_input=False):
    """Read one line from stdin, showing ``prompt_str`` on stdout."""
    sys.stdout.write(prompt_str)
    sys.stdout.flush()
    line = sys.stdin.readline()
    if line == "":
        raise EOFError()
    if hide_input:
        sys.stdout.write("\n")
    elif not _is_tty(sys.stdin):
        # Piped input is not shown by the terminal, so echo the line that was read.
        sys.stdout.write(line.rstrip("\r\n") + "\n")
    sys.stdout.flush()
    return line.rstrip("\r\n")


def _prompt_once(text, hide_input):
    return prompt_text_input(text, hide_input)


def prompt(
    text,
    default=None,
    hide_input=False,
    confirmation_prompt=False,
    type=None,
    value_proc=None,
    prompt_suffix=": ",
    show_default=True,
    err=False,
):
    """Ask for a value, converting it with ``type``; re-asks on conversion failure."""
    from .param_types import convert_type

    param_type = convert_type(type, default)
    shown_default = None
    if default is not None:
        shown_default = default() if callable(default) else default
    while True:
        suffix = ""
        if show_default and shown_default is not None:
            suffix = f" [{shown_default}]"
        question = f"{text}{suffix}{prompt_suffix}"
        raw = _prompt_once(question, hide_input)
        if raw == "" and shown_default is not None:
            value = shown_default
        else:
            value = raw
        if confirmation_prompt:
            again = _prompt_once(f"Repeat for confirmation{prompt_suffix}", hide_input)
            if again != raw:
                echo("Error: The two entered values do not match.", err=True)
                continue
        try:
            return param_type.convert(value)
        except Exception as exc:  # BadParameter from convert: re-ask.
            from .exceptions import BadParameter

            if isinstance(exc, BadParameter):
                echo(f"Error: {exc.message}", err=True)
                continue
            raise


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    """Ask a yes/no question.

    ``y``/``yes`` is yes and ``n``/``no`` is no (ignoring case). An empty answer
    takes ``default``. Any other answer counts as no and is not asked again.
    """
    if show_default:
        hint = " [Y/n]" if default else " [y/N]"
    else:
        hint = ""
    raw = _prompt_once(f"{text}{hint}{prompt_suffix}", False)
    answer = raw.strip().lower()
    if answer == "":
        result = bool(default)
    elif answer in ("y", "yes"):
        result = True
    else:
        result = False
    if abort and not result:
        raise Abort("User declined.")
    return result


def getchar(echo=False):
    """Read one character from the terminal, even when stdin is a pipe."""
    tty = None
    try:
        if os.name == "posix" and not _is_tty(sys.stdin):
            tty = open("/dev/tty", "r")
            stream = tty
        else:
            stream = sys.stdin
        char = _read_char(stream, echo)
    finally:
        if tty is not None:
            tty.close()
    if char == "\x03":
        raise KeyboardInterrupt()
    if char == "\x04" or char == "" or char == "\x1a":
        raise EOFError()
    return char


def _read_char(stream, echo_char):
    if os.name == "posix" and _is_tty(stream):
        import termios
        import tty as _tty

        fd = stream.fileno()
        old = termios.tcgetattr(fd)
        try:
            _tty.setraw(fd)
            char = os.read(fd, 1).decode("utf-8", "replace")
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
    else:
        char = stream.read(1)
    if echo_char and char:
        sys.stdout.write(char)
        sys.stdout.flush()
    return char


def pause(info=None, err=False):
    """Wait for a key when the session is interactive; do nothing otherwise."""
    if not is_interactive():
        return
    if info is None:
        info = "Press any key to continue..."
    echo(info, err=err, nl=False)
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass
    echo(err=err)


def clear():
    """Clear the visible terminal; do nothing when not connected to one."""
    if not _is_tty(sys.stdout):
        return
    sys.stdout.write("\033[2J\033[H")
    sys.stdout.flush()


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Open an editor on text or a file. Returns saved text, or None."""
    editor_cmd = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR") or "vi"
    argv = shlex.split(editor_cmd)
    run_env = dict(os.environ)
    if env:
        run_env.update(env)

    if filename is not None:
        subprocess.call(argv + [os.fspath(filename)], env=run_env)
        return None

    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            if text:
                handle.write(text.replace("\r\n", "\n"))
        before = os.path.getmtime(path), os.path.getsize(path)
        subprocess.call(argv + [path], env=run_env)
        with open(path, "r", encoding="utf-8", newline="") as handle:
            result = handle.read()
        after = os.path.getmtime(path), os.path.getsize(path)
        if require_save and before == after and result == (text or ""):
            return None
        return result
    finally:
        os.remove(path)


def launch(url, wait=False, locate=False):
    """Open ``url`` or a path with the default application; returns a status code."""
    if sys.platform == "darwin":
        argv = ["open"]
    elif sys.platform.startswith("win"):
        os.startfile(url)  # type: ignore[attr-defined]
        return 0
    else:
        argv = ["xdg-open"]
    if locate and sys.platform == "darwin":
        argv.append("-R")
    argv.append(url)
    try:
        proc = subprocess.Popen(argv)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0


class ProgressBar:
    """Wraps an iterable (or a length) and reports progress when attached to a terminal."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, file=None, width=36):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label
        self.hidden = hidden
        self.file = file or sys.stdout
        self.width = width
        self.pos = 0
        self.start = time.time()
        self.visible = not hidden and _is_tty(self.file)
        self._printed_label = False

    def _render(self):
        if not self.visible:
            return
        label = f"{self.label}  " if self.label else ""
        if self.length:
            frac = min(self.pos / self.length, 1.0)
            filled = int(self.width * frac)
            bar = "#" * filled + "-" * (self.width - filled)
            elapsed = time.time() - self.start
            eta = ""
            if self.pos:
                remaining = elapsed / self.pos * (self.length - self.pos)
                eta = f"  eta {int(remaining)}s"
            text = f"\r{label}[{bar}] {self.pos}/{self.length}{eta}"
        else:
            text = f"\r{label}{self.pos}"
        self.file.write(text)
        self.file.flush()

    def update(self, n_steps):
        self.pos += n_steps
        self._render()

    def __iter__(self):
        if self.iterable is None:
            return
        if not self.visible and not self._printed_label and self.label and not self.hidden:
            self.file.write(f"{self.label}\n")
            self._printed_label = True
        self._render()
        for item in self.iterable:
            yield item
            self.update(1)

    def finish(self):
        if self.visible:
            self.file.write("\n")
            self.file.flush()
        elif self.label and not self.hidden and not self._printed_label and self.iterable is None:
            self.file.write(f"{self.label}\n")


@contextlib.contextmanager
def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    bar = ProgressBar(iterable, length=length, label=label, hidden=hidden, **options)
    try:
        yield bar
    finally:
        bar.finish()


def _pager_command():
    return os.environ.get("PAGER") or "less"


def echo_via_pager(text_or_generator, color=None):
    """Write long text through a pager when interactive; otherwise to stdout."""
    if callable(text_or_generator) and not isinstance(text_or_generator, (str, bytes)):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        chunks = [text_or_generator]
    else:
        chunks = text_or_generator
    if not is_interactive():
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    proc = subprocess.Popen(shlex.split(_pager_command()), stdin=subprocess.PIPE, text=True)
    try:
        for chunk in chunks:
            proc.stdin.write(strip_ansi(chunk) if color is False else chunk)
            proc.stdin.flush()
    except BrokenPipeError:
        pass
    finally:
        try:
            proc.stdin.close()
        except BrokenPipeError:
            pass
        proc.wait()


@contextlib.contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream that goes through the pager when interactive."""
    if not is_interactive():
        yield _NonClosing(sys.stdout)
        return
    proc = subprocess.Popen(shlex.split(_pager_command()), stdin=subprocess.PIPE, text=True)
    try:
        yield proc.stdin
    finally:
        try:
            proc.stdin.close()
        except BrokenPipeError:
            pass
        proc.wait()
