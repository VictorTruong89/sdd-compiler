"""Options and arguments: declaration, value sources, prompting, conversion, and callbacks."""

import os

from .context import ParameterSource
from .exceptions import BadParameter, DeclarationError, MissingParameter, UsageError
from .termui import echo, prompt as _prompt
from .param_types import BOOL, FALSE_WORDS, TRUE_WORDS, Path as PathType, Tuple, convert_type, File

PREFIX_CHARS = ("-", "/", "+")

# Marks an occurrence of an option that had its flag but no value token.
NEEDS_PROMPT = object()


def _is_identifier(text):
    return text.isidentifier()


class Parameter:
    """Common machinery for options and arguments."""

    param_kind = "parameter"

    def __init__(
        self,
        param_decls=None,
        type=None,
        required=False,
        default=None,
        callback=None,
        nargs=None,
        multiple=False,
        envvar=None,
        expose_value=True,
        is_eager=False,
        metavar=None,
        hidden=False,
        deprecated=False,
        help=None,
        shell_complete=None,
        allow_from_autoenv=True,
    ):
        self.opts = []
        self.secondary_opts = []
        names = []
        for decl in param_decls or ():
            if decl[0] in PREFIX_CHARS and "/" in decl[1:] and decl[0] != "/":
                first, second = decl.split("/", 1)
                self.opts.append(first)
                self.secondary_opts.append(second)
            elif decl[:1] in PREFIX_CHARS:
                self.opts.append(decl)
            else:
                names.append(decl)
        if len(names) > 1:
            raise DeclarationError("Only one destination name may be declared.")
        self._explicit_name = names[0] if names else None
        self.name = self._derive_name()

        self.required = bool(required)
        self.multiple = bool(multiple)
        self.nargs = nargs
        self.default = default
        self.callback = callback
        self.expose_value = expose_value
        self.is_eager = is_eager
        self.metavar = metavar
        self.hidden = hidden
        self.deprecated = deprecated
        self.help = help
        self.shell_complete = shell_complete
        self.allow_from_autoenv = allow_from_autoenv
        if isinstance(envvar, str):
            self.envvar = [envvar]
        elif envvar is None:
            self.envvar = []
        else:
            self.envvar = list(envvar)
        self._type_arg = type

    def _derive_name(self):
        if self._explicit_name is not None:
            return self._explicit_name
        all_names = self.opts + self.secondary_opts
        for candidate in all_names:
            if candidate.startswith("--"):
                return candidate[2:].replace("-", "_")
        for candidate in all_names:
            return candidate.lstrip("".join(PREFIX_CHARS)).replace("-", "_")
        raise DeclarationError("A parameter needs a name or a flag name.")

    def finish_setup(self):
        """Resolve the type after subclass attributes are set."""
        default_for_type = self.default if not callable(self.default) else None
        if self.multiple and isinstance(default_for_type, (list, tuple)) and default_for_type:
            default_for_type = default_for_type[0]
        self.type = convert_type(self._type_arg, default_for_type)
        if self.nargs is None:
            self.nargs = self.type.arity if self.type.is_composite else 1
        if self.deprecated and self.required:
            raise DeclarationError("A deprecated parameter cannot be required.")
        if self.deprecated and getattr(self, "prompt", False):
            raise DeclarationError("A deprecated parameter cannot use a prompt.")

    # ----- display helpers ----------------------------------------------------

    def get_error_hint(self):
        if self.opts:
            return " / ".join(self.opts + self.secondary_opts)
        return self.name

    def get_metavar(self):
        if self.metavar is not None:
            return self.metavar
        return self.type.get_metavar(self)

    def get_default_text(self, ctx):
        return self.default

    # ----- sources ------------------------------------------------------------

    def env_names(self, ctx):
        names = list(self.envvar)
        prefix = None
        node = ctx
        while node is not None and node.parent is not None:
            node = node.parent
        if node is not None:
            prefix = node.auto_envvar_prefix
        if prefix and self.allow_from_autoenv:
            parts = []
            cur = ctx
            path = []
            while cur is not None and cur.parent is not None:
                path.append(cur.info_name)
                cur = cur.parent
            for part in [prefix] + list(reversed(path)) + [self.name]:
                parts.append(str(part).replace("-", "_").upper())
            names.append("_".join(parts))
        return names

    def _env_text(self, ctx):
        for name in self.env_names(ctx):
            value = os.environ.get(name)
            if value is not None and value != "":
                return value
        return None

    def split_text(self, text):
        return self.type.split_env_value(text)

    def _default_map_value(self, ctx):
        dm = ctx.default_map
        if not isinstance(dm, dict) or self.name not in dm:
            return None, False
        value = dm[self.name]
        if isinstance(value, str) and (self.nargs != 1 or self.type.is_composite):
            value = self.split_text(value)
        elif isinstance(value, str) and self.multiple:
            self._refuse_default(ctx, "needs an iterable (sequence) default")
        return value, True

    def _declared_default(self):
        value = self.default() if callable(self.default) else self.default
        return value

    def _refuse_default(self, ctx, reason):
        raise BadParameter(f"{self.get_error_hint()} {reason}.", ctx=ctx, param=self)

    def _prompt_text(self):
        if isinstance(self.prompt, str):
            return self.prompt
        return self.name.replace("_", " ").capitalize()

    def _ask(self, ctx, default_value):
        text = self._prompt_text()
        shown = default_value
        try:
            return _prompt(
                text,
                default=(lambda: shown) if shown is not None else None,
                hide_input=self.hide_input,
                confirmation_prompt=self.confirmation_prompt,
                type=self.type,
            )
        except EOFError:
            from .exceptions import Abort

            raise Abort("Prompt ended unexpectedly.")

    # ----- value resolution ---------------------------------------------------

    def convert_one(self, ctx, value):
        return self.type.convert(value, self, ctx)

    def _convert_occurrence(self, ctx, raw):
        if isinstance(raw, tuple) and self.nargs != 1 and not self.type.is_composite:
            return tuple(self.convert_one(ctx, v) for v in raw)
        if self.type.is_composite:
            return self.convert_one(ctx, raw)
        if isinstance(raw, list) and self.nargs == 1:
            return self.convert_one(ctx, raw[0])
        return self.convert_one(ctx, raw)

    def resolve(self, ctx, occurrences):
        """Return ``(source, value)`` for this parameter, converted, before its callback runs.

        ``value`` is None when no source supplied one.
        """
        present_wo = any(v is NEEDS_PROMPT for _, v in occurrences)
        given = [(i, v) for i, v in occurrences if v is not NEEDS_PROMPT]
        dm_value, dm_present = self._default_map_value(ctx)

        if self.count:
            if occurrences:
                return ParameterSource.COMMANDLINE, len(occurrences)
            return ParameterSource.DEFAULT, self._declared_default() or 0

        if present_wo and self.prompt:
            fallback = dm_value if dm_present else self._declared_default()
            value = self._ask(ctx, fallback)
            return ParameterSource.PROMPT, value

        if given:
            if self.multiple:
                return ParameterSource.COMMANDLINE, tuple(
                    self._convert_occurrence(ctx, v) for _, v in given
                )
            return ParameterSource.COMMANDLINE, self._convert_occurrence(ctx, given[-1][1])

        if dm_present and dm_value is not None:
            return ParameterSource.DEFAULT_MAP, self._convert_sequence(ctx, dm_value, from_map=True)

        env_text = self._env_text(ctx)
        if env_text is not None:
            value = self._env_value(ctx, env_text)
            if value is not None:
                return ParameterSource.ENVIRONMENT, value

        if self.required and self.prompt:
            value = self._ask(ctx, self._declared_default())
            return ParameterSource.PROMPT, value

        declared = self._declared_default()
        if declared is None:
            if self.required:
                raise MissingParameter(
                    f"Missing required {self.param_kind} {self.get_error_hint()}.", ctx=ctx, param=self
                )
            if self.multiple:
                return ParameterSource.DEFAULT, ()
            return ParameterSource.DEFAULT, None
        return ParameterSource.DEFAULT, self._convert_sequence(ctx, declared, from_map=False)

    def _convert_sequence(self, ctx, value, from_map):
        if self.multiple:
            if isinstance(value, (str, bytes)) or not hasattr(value, "__iter__"):
                self._refuse_default(ctx, "needs an iterable (sequence) default")
            return tuple(self.convert_one(ctx, v) for v in value)
        if self.nargs != 1 and not self.type.is_composite and isinstance(value, (list, tuple)):
            return tuple(self.convert_one(ctx, v) for v in value)
        return self.convert_one(ctx, value)

    def _env_value(self, ctx, text):
        if self.multiple or self.nargs != 1:
            parts = self.split_text(text)
            if self.multiple:
                return tuple(self.convert_one(ctx, p) for p in parts)
            return self.convert_one(ctx, tuple(parts))
        return self.convert_one(ctx, text)

    def process(self, ctx, occurrences):
        """Resolve, convert, run the callback, and record the value on the context."""
        source, value = self.resolve(ctx, occurrences)
        if self.callback is not None:
            value = self.callback(ctx, self, value)
        ctx.params[self.name] = value
        ctx.set_parameter_source(self.name, source)
        return value

    def consume_occurrence(self, ctx, tokens):
        """Return the raw value for one occurrence from ``tokens`` (already split)."""
        if self.nargs == 1:
            return tokens[0]
        return tuple(tokens)


class Option(Parameter):
    """A named parameter introduced by a prefix such as ``--`` or ``-``."""

    param_kind = "option"

    def __init__(
        self,
        param_decls=None,
        is_flag=None,
        flag_value=None,
        count=False,
        prompt=False,
        prompt_required=True,
        hide_input=False,
        confirmation_prompt=False,
        show_default=None,
        show_envvar=False,
        required=False,
        type=None,
        default=None,
        **kwargs,
    ):
        super().__init__(param_decls, type=type, required=required, default=default, **kwargs)
        self.count = bool(count)
        self.prompt = prompt
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.show_default = show_default
        self.show_envvar = show_envvar

        if self.count and not self.multiple:
            is_flag = True
        has_secondary = bool(self.secondary_opts)
        if is_flag is None:
            is_flag = has_secondary or flag_value is not None or (
                isinstance(default, bool) and type is None and flag_value is None and not prompt
            )
        self.is_flag = bool(is_flag) or has_secondary
        if self.is_flag and flag_value is None:
            if isinstance(default, bool):
                flag_value = not default
            else:
                flag_value = True
        self.flag_value = flag_value
        self.optional_value = (not self.is_flag) and flag_value is not None

        if self.is_flag and not self.count and default is None:
            default = False
        if self.count and default is None:
            default = 0
        self.default = default
        self._type_arg = BOOL if (self.is_flag and not self.count and type is None) else type
        if self.secondary_opts and not self.is_flag:
            raise DeclarationError("An on/off pair must be a flag.")
        if self.is_flag and self.multiple and not self.count:
            raise DeclarationError("A flag cannot be repeatable.")
        self.finish_setup()
        if self.is_flag and not self.count and self.nargs != 1:
            raise DeclarationError("A flag takes no values.")
        if self.confirmation_prompt and not self.prompt:
            raise DeclarationError("confirmation_prompt needs prompt.")

    def get_error_hint(self):
        return " / ".join(self.opts + self.secondary_opts)

    # ----- parsing hooks ------------------------------------------------------

    def takes_value(self):
        return not self.is_flag

    def flag_occurrence(self, on=True):
        """Value recorded for an occurrence of a flag."""
        if self.count:
            return 1
        if on:
            return self.flag_value
        return not self.flag_value if isinstance(self.flag_value, bool) else False

    def _env_value(self, ctx, text):
        if self.is_flag:
            return self._flag_env_value(ctx, text)
        return super()._env_value(ctx, text)

    def _flag_env_value(self, ctx, text):
        word = text.strip().lower()
        if word in TRUE_WORDS and self.type is BOOL:
            return True
        if word in FALSE_WORDS and self.type is BOOL:
            return False
        if isinstance(self.flag_value, str) and text == self.flag_value:
            return self.flag_value
        if word in TRUE_WORDS or word in FALSE_WORDS:
            return word in TRUE_WORDS
        if word == "":
            return None
        if self.type is BOOL or isinstance(self.flag_value, bool):
            raise BadParameter(f"{text!r} is not a valid boolean.", ctx=ctx, param=self)
        return None

    def resolve(self, ctx, occurrences):
        if self.is_flag and not self.count:
            source, value = self._resolve_flag(ctx, occurrences)
            return source, value
        return super().resolve(ctx, occurrences)

    def _resolve_flag(self, ctx, occurrences):
        if occurrences:
            value = occurrences[-1][1]
            if self.multiple:
                return ParameterSource.COMMANDLINE, tuple(v for _, v in occurrences)
            return ParameterSource.COMMANDLINE, value
        env_text = self._env_text(ctx)
        if env_text is not None:
            value = self._flag_env_value(ctx, env_text)
            if value is not None:
                return ParameterSource.ENVIRONMENT, value
        dm_value, dm_present = self._default_map_value(ctx)
        if dm_present and dm_value is not None:
            return ParameterSource.DEFAULT_MAP, self._convert_sequence(ctx, dm_value, from_map=True)
        return ParameterSource.DEFAULT, self._declared_default()

    def _convert_occurrence(self, ctx, raw):
        if self.is_flag:
            return raw
        return super()._convert_occurrence(ctx, raw)

    def process(self, ctx, occurrences):
        if self.is_flag and not self.count and not self.multiple and not self.optional_value:
            # Flags are already typed; apply the boolean type only when needed.
            source, value = self.resolve(ctx, occurrences)
            if isinstance(value, str):
                value = self.convert_one(ctx, value)
            if self.callback is not None:
                value = self.callback(ctx, self, value)
            ctx.params[self.name] = value
            ctx.set_parameter_source(self.name, source)
            return value
        return super().process(ctx, occurrences)


class Argument(Parameter):
    """A positional parameter."""

    param_kind = "argument"

    def __init__(self, param_decls=None, required=None, default=None, nargs=None, **kwargs):
        self.variadic = nargs == -1
        nargs_val = -1 if self.variadic else nargs
        if required is None:
            # A bare argument is required unless it has a default or is variadic.
            required = default is None and not self.variadic
        super().__init__(param_decls, required=required, default=default, nargs=nargs_val, **kwargs)
        if self.variadic:
            self.multiple = True
        if self.nargs is not None and self.nargs == 0:
            raise DeclarationError("nargs must be positive.")
        if self.deprecated and self.required:
            raise DeclarationError("A deprecated argument cannot be required.")
        self.count = False
        self.prompt = False
        self.hide_input = False
        self.confirmation_prompt = False
        self.show_default = False
        self.show_envvar = False
        self.is_flag = False
        self.flag_value = None
        self.optional_value = False
        self.finish_setup_argument()

    def finish_setup_argument(self):
        self.finish_setup()
        if self.variadic:
            self.nargs = -1

    def get_metavar(self):
        if self.metavar is not None:
            return self.metavar
        if self.variadic:
            return self.name.upper()
        return self.name.upper()

    def get_error_hint(self):
        return self.name

    def _env_value(self, ctx, text):
        if self.variadic or self.nargs != 1:
            return self.convert_one(ctx, tuple(self.split_text(text)))
        return self.convert_one(ctx, text)

    def env_names(self, ctx):
        return list(self.envvar)

    def _default_map_value(self, ctx):
        return super()._default_map_value(ctx)

    def resolve(self, ctx, occurrences):
        if self.variadic:
            if occurrences:
                return ParameterSource.COMMANDLINE, tuple(
                    self.convert_one(ctx, v) for _, v in occurrences
                )
            if self.required:
                raise MissingParameter(f"Argument {self.name!r} is required.", ctx=ctx, param=self)
            return ParameterSource.DEFAULT, ()
        if occurrences:
            value = occurrences[0][1]
            return ParameterSource.COMMANDLINE, self._convert_occurrence(ctx, value)
        return super().resolve(ctx, occurrences)

