"""Command, Group, and CommandCollection: parsing, dispatch, invocation, and main()."""

import inspect
import os
import sys

from .context import Context, get_current_context
from .exceptions import (
    Abort,
    DeclarationError,
    Exit,
    MissingCommand,
    NoSuchCommand,
    OptlynError,
    UsageError,
)
from .parameters import Option, Parameter
from .parser import parse
from .termui import echo, is_interactive


class _ChainMarker:
    """``invoked_subcommand`` value on a chaining group that is about to run several children."""

    def __str__(self):
        return "*"

    def __repr__(self):
        return "<chain>"


CHAIN_MARKER = _ChainMarker()


class _NoArgsHelp(UsageError):
    """Help shown because the invocation was incomplete (usage failure)."""

    def __init__(self, ctx):
        super().__init__("", ctx)

    def show(self, file=None):
        echo(self.ctx.get_help(), file=file or sys.stderr, err=True)


def _help_callback(ctx, param, value):
    if value:
        echo(ctx.get_help(), color=ctx.color)
        ctx.exit(0)
    return value


def _cleandoc(text):
    if not text:
        return None
    return inspect.cleandoc(text)


class Command:
    """A leaf command: parses its own options and arguments and runs a callback."""

    is_group = False

    def __init__(
        self,
        name=None,
        callback=None,
        params=None,
        help=None,
        short_help=None,
        epilog=None,
        options_metavar="[OPTIONS]",
        context_settings=None,
        add_help_option=True,
        no_args_is_help=False,
        deprecated=False,
        hidden=False,
        allow_extra_args=None,
        ignore_unknown_options=None,
        allow_interspersed_args=None,
        **_ignored,
    ):
        self.name = name
        self.callback = callback
        self.params = list(params or [])
        self.help = _cleandoc(help) if help is not None else _cleandoc(getattr(callback, "__doc__", None))
        self.short_help = short_help
        self.epilog = epilog
        self.options_metavar = options_metavar
        self.context_settings = dict(context_settings or {})
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.deprecated = deprecated
        self.hidden = hidden
        self.allow_extra_args = allow_extra_args
        self.ignore_unknown_options = ignore_unknown_options
        self.allow_interspersed_args = allow_interspersed_args

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    # ----- parameters ---------------------------------------------------------

    def _help_option_params(self, ctx):
        if not self.add_help_option:
            return []
        declared = set()
        for p in self.params:
            declared.update(p.opts)
            declared.update(p.secondary_opts)
        names = [n for n in ctx.help_option_names if n not in declared]
        if not names:
            return []
        return [
            Option(
                ["__optlyn_help__"] + names,
                is_flag=True,
                is_eager=True,
                expose_value=False,
                help="Show this message and exit.",
                callback=_help_callback,
            )
        ]

    def get_params(self, ctx):
        return list(self.params) + self._help_option_params(ctx)

    def allow_interspersed_args_effective(self, ctx):
        if ctx.allow_interspersed_args is not None:
            return ctx.allow_interspersed_args
        if self.allow_interspersed_args is not None:
            return self.allow_interspersed_args
        # Leaves mix options and positionals; groups stop at the subcommand name.
        return not self.is_group

    # ----- context creation ---------------------------------------------------

    def make_context(self, info_name, args, parent=None, **extra):
        settings = dict(self.context_settings)
        settings.update(extra)
        ctx = Context(self, info_name=info_name, parent=parent, **settings)
        ctx._raw_args = list(args)
        try:
            with ctx:
                ctx._rest = self.parse_args(ctx, args)
        except BaseException:
            ctx.close()
            raise
        return ctx

    def parse_args(self, ctx, args, chain_child=False):
        """Parse ``args``, process every parameter, and return leftover tokens for a child."""
        if not args and self.no_args_is_help and not self.is_group:
            raise _NoArgsHelp(ctx)
        result = parse(self, ctx, args, chain_child=chain_child)
        if result.extra and not ctx.allow_extra_args:
            extra = " ".join(result.extra)
            raise UsageError(f"Got unexpected extra argument(s) ({extra}).", ctx)
        self.process_params(ctx, result)
        return result.rest

    def process_params(self, ctx, result):
        """Process eager flags first (first typed wins), then every other parameter in order."""
        params = self.get_params(ctx)
        eager_hits = sorted(result.eager, key=lambda item: item[0])
        eager_done = None
        if eager_hits:
            eager_done = eager_hits[0][1]
            eager_done.process(ctx, result.given.get(eager_done.name, []))
        for param in params:
            if param is eager_done:
                continue
            occ = result.given.get(param.name, [])
            if occ and param.deprecated:
                self._warn_deprecated_parameter(param)
            param.process(ctx, occ)

    def _warn_deprecated_parameter(self, param):
        if isinstance(param, Option):
            kind = "option"
            label = " / ".join(param.opts + param.secondary_opts)
        else:
            kind = "argument"
            label = param.name
        note = param.deprecated if isinstance(param.deprecated, str) else None
        message = f"DeprecationWarning: The {kind} {label!r} is deprecated."
        if note:
            message = f"{message} {note}"
        echo(message, err=True)

    # ----- invocation ---------------------------------------------------------

    def _kwargs(self, ctx):
        return {p.name: ctx.params.get(p.name) for p in self.get_params(ctx) if p.expose_value}

    def _warn_deprecated_command(self, ctx):
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else None
            message = f"DeprecationWarning: The command {ctx.info_name!r} is deprecated."
            if note:
                message = f"{message} {note}"
            echo(message)

    def invoke(self, ctx):
        self._warn_deprecated_command(ctx)
        if self.callback is None:
            return None
        return self.callback(**self._kwargs(ctx))

    def invoke_with_values(self, ctx, values):
        """Run the callback with values supplied by ``Context.invoke``/``forward``."""
        if self.callback is None:
            return None
        params = self.get_params(ctx)
        kwargs = {p.name: values.get(p.name) for p in params if p.expose_value}
        declared = {p.name for p in params}
        for key, value in values.items():
            if key not in declared:
                kwargs[key] = value
        return self.callback(**kwargs)

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True, **extra):
        if args is None:
            args = sys.argv[1:]
        prog = prog_name or os.path.basename(sys.argv[0] or "") or "cli"
        from . import shell_completion

        var_name = complete_var or shell_completion.complete_var_name(prog)
        if os.environ.get(var_name):
            return shell_completion.handle_completion(self, prog, var_name, args, standalone_mode)

        ctx = None
        try:
            try:
                ctx = self.make_context(prog, args, **extra)
                with ctx:
                    rv = self.invoke(ctx)
                if not standalone_mode:
                    return rv
                _exit(0)
            finally:
                if ctx is not None:
                    ctx.close()
        except Exit as exc:
            if standalone_mode:
                _exit(exc.exit_code)
            if exc.exit_code == 0:
                return None
            raise
        except OptlynError as exc:
            if not standalone_mode:
                raise
            exc.show()
            _exit(exc.exit_code)
        except (KeyboardInterrupt, EOFError):
            if not standalone_mode:
                raise
            echo("Aborted!", err=True)
            _exit(1)
        except SystemExit:
            raise

    def get_help(self, ctx):
        from .help import format_help

        return format_help(self, ctx)


def _exit(code):
    sys.stdout.flush()
    sys.stderr.flush()
    raise SystemExit(code)


class Group(Command):
    """A command that dispatches to named subcommands."""

    is_group = True

    def __init__(
        self,
        name=None,
        commands=None,
        invoke_without_command=False,
        no_args_is_help=None,
        subcommand_metavar=None,
        chain=False,
        result_callback=None,
        **kwargs,
    ):
        super().__init__(name=name, **kwargs)
        self.commands = dict(commands or {})
        self.invoke_without_command = invoke_without_command
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        self.no_args_is_help = no_args_is_help
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback

    def add_command(self, cmd, name=None):
        if self.chain and cmd.is_group:
            raise DeclarationError("Groups cannot be nested under a chaining group.")
        key = name or cmd.name
        if key is None:
            raise DeclarationError("A command needs a name.")
        self.commands[key] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as command_decorator

        def decorator(f):
            cmd = command_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as group_decorator

        def decorator(f):
            cmd = group_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self):
        """Return a decorator that registers the result callback of this group."""

        def decorator(f):
            self._result_callback = f
            return f

        return decorator

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        func = ctx.token_normalize_func
        if func:
            wanted = func(cmd_name)
            for key in self.list_commands(ctx):
                if func(key) == wanted:
                    return self.commands.get(key)
        return None

    def _resolve(self, ctx, name):
        cmd = self.get_command(ctx, name)
        if cmd is None:
            raise NoSuchCommand(name, message=f"No such command {name!r}.", ctx=ctx)
        return cmd

    def _run_group_callback(self, ctx):
        if self.callback is None:
            return None
        return self.callback(**self._kwargs(ctx))

    def invoke(self, ctx):
        self._warn_deprecated_command(ctx)
        rest = ctx._rest
        if self.chain:
            return self._invoke_chain(ctx, rest)

        if not rest:
            if self.invoke_without_command:
                ctx.invoked_subcommand = None
                rv = self._run_group_callback(ctx)
                return self._result(ctx, rv)
            if self.no_args_is_help and not ctx._raw_args:
                raise _NoArgsHelp(ctx)
            raise MissingCommand("Missing command.", ctx=ctx)

        name = rest[0]
        cmd = self._resolve(ctx, name)
        ctx.invoked_subcommand = name
        self._run_group_callback(ctx)
        sub_ctx = cmd.make_context(name, rest[1:], parent=ctx)
        try:
            with sub_ctx:
                rv = cmd.invoke(sub_ctx)
        finally:
            sub_ctx.close()
        return self._result(ctx, rv)

    def _invoke_chain(self, ctx, rest):
        ctx.invoked_subcommand = CHAIN_MARKER if rest else None
        if not rest and not self.invoke_without_command:
            raise MissingCommand("Missing command.", ctx=ctx)
        self._run_group_callback(ctx)
        results = []
        while rest:
            name = rest[0]
            cmd = self._resolve(ctx, name)
            child_ctx = Context(cmd, info_name=name, parent=ctx, obj=ctx.obj)
            child_ctx._chain_child = True
            child_ctx._raw_args = list(rest[1:])
            try:
                with child_ctx:
                    child_ctx._rest = cmd.parse_args(child_ctx, rest[1:], chain_child=True)
                    rv = cmd.invoke(child_ctx)
                    results.append(rv)
                rest = child_ctx._rest
            finally:
                child_ctx.close()
        if self._result_callback is not None:
            params = {k: v for k, v in ctx.params.items()}
            return self._result_callback(results, **params)
        return results

    def _result(self, ctx, rv):
        if self._result_callback is not None:
            return self._result_callback(rv, **dict(ctx.params))
        return rv


class CommandCollection(Group):
    """A group presenting the union of subcommands of several source groups."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name=name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = set(super().list_commands(ctx))
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        cmd = super().get_command(ctx, cmd_name)
        if cmd is not None:
            return cmd
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None
