"""Help-page rendering for commands and groups."""

import shutil

from .formatting import ellipsize, first_sentence, wrap_text
from .parameters import Option
from .param_types import Choice

_NAME_COLUMN_MAX = 30
_INDENT = 2
_GAP = 2


def _wrap_width(ctx):
    if ctx.terminal_width is not None:
        return int(ctx.terminal_width)
    columns = shutil.get_terminal_size((80, 24)).columns
    return min(columns, int(ctx.max_content_width))


def _usage(cmd, ctx):
    parts = [ctx.get_command_path(), cmd.options_metavar]
    for arg in cmd.params:
        if isinstance(arg, Option):
            continue
        if arg.metavar is not None:
            placeholder = arg.metavar
        else:
            placeholder = arg.name.upper()
        if arg.variadic:
            placeholder = f"{placeholder}..."
        if not arg.required and not placeholder.startswith("["):
            placeholder = f"[{placeholder}]"
        parts.append(placeholder)
    if cmd.is_group:
        if cmd.chain:
            parts.append("COMMAND [ARGS]... [COMMAND [ARGS]...]...")
        elif cmd.invoke_without_command:
            parts.append("[COMMAND] [ARGS]...")
        else:
            parts.append("COMMAND [ARGS]...")
    return "Usage: " + " ".join(p for p in parts if p)


def _layout(rows, width):
    """Two-column layout: name on the left, wrapped text on the right."""
    if not rows:
        return []
    name_width = min(max(len(name) for name, _ in rows), _NAME_COLUMN_MAX)
    lines = []
    for name, text in rows:
        if len(name) <= name_width:
            head = " " * _INDENT + name.ljust(name_width) + " " * _GAP
            body_width = max(width - len(head), 20)
            wrapped = wrap_text(text, width=body_width, subsequent_indent="") if text else ""
            body = wrapped.split("\n")
            if not text:
                lines.append(head.rstrip())
                continue
            lines.append(head + body[0])
            for extra in body[1:]:
                lines.append(" " * len(head) + extra)
        else:
            lines.append(" " * _INDENT + name)
            if text:
                body_width = max(width - (_INDENT + _GAP + name_width), 20)
                wrapped = wrap_text(text, width=body_width)
                for line in wrapped.split("\n"):
                    lines.append(" " * (_INDENT + name_width + _GAP) + line)
    return lines


def _option_name(opt):
    if opt.secondary_opts:
        return "/".join(opt.opts + opt.secondary_opts)
    return ", ".join(opt.opts)


def _option_text(opt, ctx):
    pieces = []
    if opt.help:
        pieces.append(opt.help)
    if isinstance(opt.type, Choice) and opt.type.choices:
        pieces.append("Choices: " + ", ".join(opt.type.choices))
    show = opt.show_default if opt.show_default is not None else ctx.show_default
    if show and opt.default is not None and not callable(opt.default):
        if isinstance(opt.show_default, str):
            pieces.append(f"[default: {opt.show_default}]")
        elif opt.is_flag and not opt.count and opt.default is False:
            pass
        else:
            default = opt.default
            if isinstance(default, (list, tuple)):
                default = ", ".join(str(d) for d in default)
            pieces.append(f"[default: {default}]")
    elif show and isinstance(opt.show_default, str):
        pieces.append(f"[default: {opt.show_default}]")
    if opt.show_envvar and opt.envvar:
        pieces.append(f"[env var: {', '.join(opt.envvar)}]")
    if opt.deprecated:
        pieces.append("(deprecated)")
    return " ".join(pieces)


def format_help(cmd, ctx):
    width = _wrap_width(ctx)
    lines = [_usage(cmd, ctx), ""]

    if cmd.deprecated:
        note = cmd.deprecated if isinstance(cmd.deprecated, str) else ""
        lines.append(wrap_text(f"DEPRECATED: This command is deprecated. {note}".rstrip(), width=width))
        lines.append("")

    if cmd.help:
        description = cmd.help.split("\f", 1)[0]
        text = wrap_text(description, width=width)
        if text:
            lines.append(text)
            lines.append("")

    arg_rows = []
    for param in cmd.params:
        if isinstance(param, Option) or param.help is None:
            continue
        placeholder = param.metavar or param.name.upper()
        arg_rows.append((placeholder, param.help))
    if arg_rows:
        lines.append("Arguments:")
        lines.extend(_layout(arg_rows, width))
        lines.append("")

    opt_rows = []
    for param in cmd.get_params(ctx):
        if not isinstance(param, Option) or param.hidden:
            continue
        name = _option_name(param)
        if not param.is_flag:
            name = f"{name} {param.get_metavar()}"
        opt_rows.append((name, _option_text(param, ctx)))
    if opt_rows:
        lines.append("Options:")
        lines.extend(_layout(opt_rows, width))
        lines.append("")

    if cmd.is_group:
        command_rows = []
        for name in cmd.list_commands(ctx):
            sub = cmd.get_command(ctx, name)
            if sub is None or sub.hidden:
                continue
            short = sub.short_help or first_sentence(sub.help or "")
            command_rows.append((name, ellipsize(short, max(width - 40, 20))))
        if command_rows:
            lines.append("Commands:")
            lines.extend(_layout(command_rows, width))
            lines.append("")

    if cmd.epilog:
        lines.append(wrap_text(cmd.epilog, width=width))
        lines.append("")

    while lines and lines[-1] == "":
        lines.pop()
    return "\n".join(lines) + "\n"
