"""Token parser: binds command-line tokens to options and positional arguments."""

from .exceptions import BadParameter, MissingCommand, NoSuchOption, UsageError
from .parameters import NEEDS_PROMPT


class ParseResult:
    def __init__(self):
        # name -> list of (token index, raw value)
        self.given = {}
        # tokens that belong to a subcommand (groups and chained commands)
        self.rest = []
        # (token index, parameter) for every eager parameter that occurred
        self.eager = []
        # tokens left unclaimed by any argument
        self.extra = []


class _Parser:
    def __init__(self, command, ctx, tokens, chain_child=False):
        self.command = command
        self.ctx = ctx
        self.tokens = list(tokens)
        self.chain_child = chain_child
        self.is_group = command.is_group
        self.result = ParseResult()

        self.options = [p for p in command.get_params(ctx) if p.opts]
        self.arguments = [p for p in command.get_params(ctx) if not p.opts]
        self.index = {}
        for opt in self.options:
            for name in opt.opts:
                self.index[self._norm(name)] = (opt, True)
            for name in opt.secondary_opts:
                self.index[self._norm(name)] = (opt, False)
        self.prefixes = {opt.opts[0][0] if opt.opts else opt.secondary_opts[0][0] for opt in self.options}
        self.prefixes |= {n[0] for n in self.index if n}

    def _norm(self, token):
        func = self.ctx.token_normalize_func
        return func(token) if func else token

    def _is_option_like(self, token):
        return len(token) > 1 and token[0] in self.prefixes

    def _record(self, opt, idx, value):
        self.result.given.setdefault(opt.name, []).append((idx, value))
        if opt.is_eager:
            self.result.eager.append((idx, opt))

    def _take_value(self, opt, i, inline=None):
        """Return (value, next index) for an option that needs a value."""
        if opt.optional_value:
            if inline is not None:
                return inline, i
            if i < len(self.tokens) and not self._is_option_like(self.tokens[i]):
                return self.tokens[i], i + 1
            return opt.flag_value, i
        width = opt.nargs
        if inline is not None:
            values = [inline]
            if width > 1:
                needed = width - 1
                values += self.tokens[i : i + needed]
                i += needed
                if len(values) < width:
                    raise UsageError(f"Option {opt.get_error_hint()} requires {width} arguments.", self.ctx)
            return (tuple(values) if width > 1 else values[0]), i
        if i + width > len(self.tokens):
            if width == 1:
                raise UsageError(f"Option {opt.get_error_hint()} requires an argument.", self.ctx)
            raise UsageError(f"Option {opt.get_error_hint()} requires {width} arguments.", self.ctx)
        values = self.tokens[i : i + width]
        return (tuple(values) if width > 1 else values[0]), i + width

    def _handle_option(self, idx, opt, on, i, inline=None):
        """Handle a matched option; returns the next token index."""
        if opt.is_flag:
            if inline is not None:
                raise UsageError(f"Option {opt.get_error_hint()} does not take a value.", self.ctx)
            if opt.count:
                self._record(opt, idx, 1)
            elif opt.secondary_opts:
                self._record(opt, idx, bool(on))
            else:
                self._record(opt, idx, opt.flag_value)
            return i
        if opt.prompt and not opt.optional_value and inline is None and (
            i >= len(self.tokens) or self._is_option_like(self.tokens[i])
        ):
            self._record(opt, idx, NEEDS_PROMPT)
            return i
        value, i = self._take_value(opt, i, inline)
        self._record(opt, idx, value)
        return i

    def _unknown(self, token):
        if self.ctx.ignore_unknown_options:
            return False
        if token.startswith("--"):
            raise NoSuchOption(token.split("=", 1)[0], ctx=self.ctx)
        raise NoSuchOption(token[:2], message=f"No such option: {token[:2]}", ctx=self.ctx)

    def parse(self):
        tokens = self.tokens
        n = len(tokens)
        i = 0
        positional = []  # (index, token)
        stop_options = False
        fixed_total = sum(a.nargs for a in self.arguments if not a.variadic and a.nargs not in (None, -1))
        has_variadic = any(a.variadic for a in self.arguments)
        mixing = bool(self.command.allow_interspersed_args_effective(self.ctx))

        while i < n:
            tok = tokens[i]
            idx = i
            if stop_options:
                positional.append((idx, tok))
                i += 1
                continue
            if tok == "--":
                stop_options = True
                i += 1
                continue
            if not self._is_option_like(tok):
                if self._args_full(positional, fixed_total, has_variadic) and self.is_group:
                    if not mixing:
                        self.result.rest = tokens[i:]
                        break
                    self.result.rest.append(tok)
                    i += 1
                    continue
                if self.chain_child and self._args_full(positional, fixed_total, has_variadic):
                    self.result.rest = tokens[i:]
                    break
                positional.append((idx, tok))
                i += 1
                continue

            if self.is_group and mixing and self._args_full(positional, fixed_total, has_variadic):
                if self._norm_name(tok) not in self.index:
                    self.result.rest.append(tok)
                    i += 1
                    continue

            i = self._parse_option_token(idx, tok, i, positional)

        self._assign_arguments(positional)
        return self.result

    def _norm_name(self, token):
        return self._norm(token.split("=", 1)[0])

    def _args_full(self, positional, fixed_total, has_variadic):
        return not has_variadic and len(positional) >= fixed_total

    def _parse_option_token(self, idx, tok, i, positional):
        key = self._norm(tok)
        if key in self.index:
            opt, on = self.index[key]
            return self._handle_option(idx, opt, on, i + 1)
        if "=" in tok and tok.split("=", 1)[0] and self._norm(tok.split("=", 1)[0]) in self.index:
            name, value = tok.split("=", 1)
            opt, on = self.index[self._norm(name)]
            return self._handle_option(idx, opt, on, i + 1, inline=value)
        if tok.startswith("--"):
            if self.ctx.ignore_unknown_options:
                positional.append((idx, tok))
                return i + 1
            raise NoSuchOption(tok.split("=", 1)[0], ctx=self.ctx)
        # Short option stack: -abc, or a single declared prefix character.
        prefix = tok[0]
        body = tok[1:]
        j = 0
        next_i = i + 1
        while j < len(body):
            ch = body[j]
            key = self._norm(prefix + ch)
            if key not in self.index:
                if self.ctx.ignore_unknown_options:
                    leftover = prefix + body[j:]
                    positional.append((idx, leftover))
                    return next_i
                raise NoSuchOption(prefix + ch, message=f"No such option: {prefix + ch}", ctx=self.ctx)
            opt, on = self.index[key]
            rest = body[j + 1 :]
            if opt.is_flag:
                self._handle_option(idx, opt, on, next_i)
                j += 1
                continue
            inline = rest if rest else None
            next_i = self._handle_option(idx, opt, on, next_i, inline=inline)
            return next_i
        return next_i

    def _assign_arguments(self, positional):
        tokens = [t for _, t in positional]
        indices = [k for k, _ in positional]
        pos = 0
        for arg_pos, arg in enumerate(self.arguments):
            later_fixed = sum(a.nargs for a in self.arguments[arg_pos + 1 :] if not a.variadic)
            if arg.variadic:
                take = max(len(tokens) - pos - later_fixed, 0)
                for k in range(pos, pos + take):
                    self.result.given.setdefault(arg.name, []).append((indices[k], tokens[k]))
                pos += take
                continue
            width = arg.nargs or 1
            available = len(tokens) - pos
            if available <= 0:
                continue
            if width == 1:
                self.result.given.setdefault(arg.name, []).append((indices[pos], tokens[pos]))
                pos += 1
            else:
                if available < width:
                    raise UsageError(f"Argument {arg.name} requires {width} values.", self.ctx)
                chunk = tuple(tokens[pos : pos + width])
                self.result.given.setdefault(arg.name, []).append((indices[pos], chunk))
                pos += width
        self.result.extra = tokens[pos:]


def parse(command, ctx, tokens, chain_child=False):
    return _Parser(command, ctx, tokens, chain_child=chain_child).parse()
