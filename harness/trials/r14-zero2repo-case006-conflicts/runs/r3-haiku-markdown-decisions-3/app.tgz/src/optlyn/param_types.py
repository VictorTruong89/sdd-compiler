"""Parameter types: conversion of raw command-line tokens into Python values."""

import datetime as _dt
import enum
import os
import pathlib
import uuid as _uuid

from .exceptions import BadParameter, DeclarationError

__all__ = [
    "ParamType",
    "STRING",
    "INT",
    "FLOAT",
    "BOOL",
    "UUID",
    "UNPROCESSED",
    "Choice",
    "DateTime",
    "IntRange",
    "FloatRange",
    "Tuple",
    "File",
    "Path",
    "convert_type",
]

TRUE_WORDS = ("1", "true", "t", "yes", "y", "on")
FALSE_WORDS = ("0", "false", "f", "no", "n", "off")


class ParamType:
    """Base class for parameter types.

    Subclasses set ``name`` and implement :meth:`convert`. ``convert`` must
    accept ``param=None, ctx=None`` and refuse invalid input by raising
    :class:`BadParameter` (use :meth:`fail`).
    """

    name = "text"
    is_composite = False
    arity = 1
    # Set on choice types; used by help and completion.
    choices = None

    def __call__(self, value, param=None, ctx=None):
        return self.convert(value, param, ctx)

    def convert(self, value, param=None, ctx=None):
        return value

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def get_metavar(self, param):
        return self.name.upper()

    def get_missing_message(self, param):
        return None

    def split_env_value(self, value):
        """Split a non-empty environment string for a repeatable or multi-value parameter."""
        return value.split()

    def shell_complete(self, ctx, param, incomplete):
        return []

    def __repr__(self):
        return self.name.upper()


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            try:
                return value.decode("utf-8")
            except UnicodeError:
                return value.decode("utf-8", "replace")
        if isinstance(value, str):
            return value
        return str(value)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            return int(str(value).strip(), 10)
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        if isinstance(value, int) and not isinstance(value, bool):
            return float(value)
        try:
            return float(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in TRUE_WORDS:
            return True
        if text in FALSE_WORDS:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


class Choice(ParamType):
    """A closed list of allowed values, or the members of an enumeration."""

    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        self.case_sensitive = case_sensitive
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self._is_enum = True
            self._originals = list(choices)
            self._tokens = [m.name for m in self._originals]
        else:
            self._is_enum = False
            self._originals = list(choices)
            self._tokens = [str(c) for c in self._originals]
        self.choices = self._tokens

    def _normalize(self, token):
        return token if self.case_sensitive else token.casefold()

    def get_metavar(self, param):
        return "[" + "|".join(self._tokens) + "]"

    def convert(self, value, param=None, ctx=None):
        if self._is_enum and isinstance(value, enum.Enum):
            return value
        if not self._is_enum and any(value is o or value == o for o in self._originals if not isinstance(o, str)):
            return value
        token = str(value)
        if ctx is not None and ctx.token_normalize_func is not None:
            token = ctx.token_normalize_func(token)
        wanted = self._normalize(token)
        for original, tok in zip(self._originals, self._tokens):
            if self._normalize(tok) == wanted:
                return original
        choices_str = ", ".join(repr(t) for t in self._tokens)
        self.fail(f"{value!r} is not {choices_str}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        return [t for t in self._tokens if t.startswith(incomplete)]


class DateTime(ParamType):
    name = "datetime"

    DEFAULT_FORMATS = ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S")

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(self.DEFAULT_FORMATS)

    def get_metavar(self, param):
        return "[" + "|".join(self.formats) + "]"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        text = str(value).strip()
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(text, fmt)
            except ValueError:
                continue
        formats_str = ", ".join(repr(f) for f in self.formats)
        self.fail(f"{value!r} does not match the formats {formats_str}.", param, ctx)


class _RangeMixin:
    def _check_range(self, value, param, ctx, lo_clampable, hi_clampable):
        if self.min is not None:
            if value < self.min or (self.min_open and value == self.min):
                if self.clamp:
                    if self.min_open:
                        return self._adjacent_up(self.min)
                    return self.min
                self._range_fail(value, param, ctx)
        if self.max is not None:
            if value > self.max or (self.max_open and value == self.max):
                if self.clamp:
                    if self.max_open:
                        return self._adjacent_down(self.max)
                    return self.max
                self._range_fail(value, param, ctx)
        return value

    def _range_text(self):
        lo = "" if self.min is None else ("(" if self.min_open else "[") + str(self.min)
        hi = "" if self.max is None else str(self.max) + (")" if self.max_open else "]")
        if self.min is None:
            return f"x {'<' if self.max_open else '<='} {self.max}"
        if self.max is None:
            return f"x {'>' if self.min_open else '>='} {self.min}"
        return f"{lo}, {hi}"

    def _range_fail(self, value, param, ctx):
        self.fail(f"{value} is not in the valid range of {self._range_text()}.", param, ctx)


class IntRange(_RangeMixin, IntParamType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def _adjacent_up(self, v):
        return v + 1

    def _adjacent_down(self, v):
        return v - 1

    def convert(self, value, param=None, ctx=None):
        number = IntParamType.convert(self, value, param, ctx)
        return self._check_range(number, param, ctx, True, True)


class FloatRange(_RangeMixin, FloatParamType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min_open or max_open):
            raise DeclarationError("Clamping is not supported for open bounds.")
        if min is not None and max is not None and min > max:
            raise DeclarationError("The minimum bound must not exceed the maximum bound.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        number = FloatParamType.convert(self, value, param, ctx)
        return self._check_range(number, param, ctx, True, True)


class Tuple(ParamType):
    name = "tuple"
    is_composite = True

    def __init__(self, types):
        self.types = [convert_type(t) for t in types]
        self.arity = len(self.types)

    def get_metavar(self, param):
        return " ".join(t.get_metavar(param) for t in self.types)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, (str, bytes)) or not hasattr(value, "__len__"):
            self.fail(f"{value!r} is not a sequence of {self.arity} values.", param, ctx)
        if len(value) != self.arity:
            self.fail(f"{value!r} must have exactly {self.arity} items.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))


class File(ParamType):
    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise DeclarationError(f"Unsupported file mode {mode!r}.")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def get_metavar(self, param):
        return "FILENAME"

    def _lazy_for(self):
        if self.lazy is not None:
            return self.lazy
        return "w" in self.mode

    def convert(self, value, param=None, ctx=None):
        from .utils import open_file

        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        if isinstance(value, bytes):
            value = os.fsdecode(value)
        lazy = self._lazy_for()
        try:
            if "w" in self.mode and not lazy:
                # Non-lazy write: open (and truncate) now, before the callback runs.
                return open_file(value, self.mode, self.encoding, self.errors, lazy=False, atomic=self.atomic)
            if "w" in self.mode:
                return open_file(value, self.mode, self.encoding, self.errors, lazy=True, atomic=self.atomic)
            return open_file(value, self.mode, self.encoding, self.errors, lazy=False, atomic=self.atomic)
        except OSError as exc:
            self.fail(f"'{value}': {exc.strerror or exc}", param, ctx)


class Path(ParamType):
    name = "path"

    def __init__(
        self,
        exists=False,
        file_okay=True,
        dir_okay=True,
        writable=False,
        readable=True,
        resolve_path=False,
        allow_dash=False,
        path_type=None,
        executable=False,
    ):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def get_metavar(self, param):
        return "PATH"

    def _deliver(self, text):
        if self.path_type is pathlib.Path:
            return pathlib.Path(text)
        if self.path_type is None or self.path_type is str:
            return text
        return self.path_type(text)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, pathlib.PurePath):
            value = str(value)
        if isinstance(value, bytes):
            value = os.fsdecode(value)
        if self.allow_dash and value == "-":
            return self._deliver("-")

        text = value
        if self.resolve_path:
            text = os.path.realpath(text)

        if not os.path.exists(text):
            if self.exists:
                self.fail(f"{value!r} does not exist.", param, ctx)
            return self._deliver(text)

        is_dir = os.path.isdir(text)
        if is_dir and not self.dir_okay:
            self.fail(f"{value!r} is a directory.", param, ctx)
        if not is_dir and not self.file_okay:
            self.fail(f"{value!r} is a file.", param, ctx)
        if self.readable and not os.access(text, os.R_OK):
            self.fail(f"{value!r} is not readable.", param, ctx)
        if self.writable and not os.access(text, os.W_OK):
            self.fail(f"{value!r} is not writable.", param, ctx)
        if self.executable and not os.access(text, os.X_OK):
            self.fail(f"{value!r} is not executable.", param, ctx)
        return self._deliver(text)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import PathRequest

        return [PathRequest(incomplete, directories_only=not self.file_okay and self.dir_okay)]


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()

_PY_TYPE_MAP = {
    str: STRING,
    int: INT,
    float: FLOAT,
    bool: BOOL,
    _uuid.UUID: UUID,
}


def convert_type(ty, default=None):
    """Turn a declared type (instance, class, Python type, or conversion function) into a ParamType."""
    if ty is None and default is not None:
        if isinstance(default, (tuple, list)) and default:
            return convert_type(None, default[0])
        if isinstance(default, bool):
            return BOOL
        for py_type in (bool, int, float, str):
            if isinstance(default, py_type):
                return _PY_TYPE_MAP[py_type]
        return STRING
    if ty is None:
        return STRING
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    if isinstance(ty, type) and ty in _PY_TYPE_MAP:
        return _PY_TYPE_MAP[ty]
    if callable(ty):
        return FunctionParamType(ty)
    raise DeclarationError(f"Unsupported parameter type {ty!r}.")


class FunctionParamType(ParamType):
    """Wraps a conversion function ``f(token) -> value`` that refuses by raising ValueError."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text")

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except BadParameter:
            raise
        except ValueError as exc:
            self.fail(str(exc) or f"{value!r} is not valid.", param, ctx)
