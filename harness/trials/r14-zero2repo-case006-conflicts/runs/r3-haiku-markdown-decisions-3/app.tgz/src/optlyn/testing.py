"""In-process runner: invoke a command with tokens and capture its output and exit status."""

import contextlib
import io
import os
import sys
import tempfile


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output, exit_code, exception, return_value=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output
        self.exit_code = exit_code
        self.exception = exception
        self.return_value = return_value

    @property
    def output(self):
        return self.output_bytes.decode(self.runner.charset, "replace")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class _Log:
    """Shared, ordered record of everything written to either stream."""

    def __init__(self):
        self.chunks = []  # (stream name, bytes)

    def add(self, name, data):
        self.chunks.append((name, data))


class _OutputStream(io.TextIOBase):
    def __init__(self, name, log, charset):
        self._name = name
        self._log = log
        self._charset = charset
        self._stdout_bytes = bytearray()
        self._stderr_bytes = bytearray()
        self.buffer = _BinaryWriter(self)

    @property
    def encoding(self):
        return self._charset

    @property
    def errors(self):
        return "strict"

    def isatty(self):
        return False

    def writable(self):
        return True

    def write(self, text):
        data = text.encode(self._charset, "strict")
        self._record(data)
        return len(text)

    def _record(self, data):
        self._log.add(self._name, data)
        target = self._stdout_bytes if self._name == "stdout" else self._stderr_bytes
        target.extend(data)

    def flush(self):
        pass

    @property
    def bytes_written(self):
        return bytes(self._stdout_bytes if self._name == "stdout" else self._stderr_bytes)


class _BinaryWriter:
    def __init__(self, stream):
        self._stream = stream

    def write(self, data):
        self._stream._record(bytes(data))
        return len(data)

    def flush(self):
        pass


class _Input(io.TextIOBase):
    def __init__(self, data, log, echo_stdin, charset):
        self._buf = io.BytesIO(data)
        self._log = log
        self._echo = echo_stdin
        self._charset = charset

    @property
    def encoding(self):
        return self._charset

    def isatty(self):
        return False

    def readable(self):
        return True

    def readline(self, size=-1):
        raw = self._buf.readline()
        line = raw.decode(self._charset, "replace")
        if self._echo and line:
            self._log.add("stdout", line.encode(self._charset, "replace"))
        return line

    def read(self, size=-1):
        raw = self._buf.read() if size is None or size < 0 else self._buf.read(size)
        return raw.decode(self._charset, "replace")


class CliRunner:
    """Runs a command in-process with captured streams."""

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        if isinstance(input, str):
            data = input.encode(self.charset)
        elif input is None:
            data = b""
        else:
            data = bytes(input)
        log = _Log()
        stdin = _Input(data, log, self.echo_stdin, self.charset)
        stdout = _OutputStream("stdout", log, self.charset)
        stderr = _OutputStream("stderr", log, self.charset)

        merged_env = dict(self.env)
        merged_env.update(env or {})
        saved_env = {}
        for key, value in merged_env.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)

        saved = (sys.stdin, sys.stdout, sys.stderr)
        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
        try:
            yield (stdout, stderr, log)
        finally:
            sys.stdin, sys.stdout, sys.stderr = saved
            for key, value in saved_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if args is None:
            args = []
        elif isinstance(args, str):
            import shlex

            args = shlex.split(args)
        extra.setdefault("prog_name", "root")
        extra.setdefault("standalone_mode", True)
        extra["color"] = color

        exit_code = 0
        exception = None
        return_value = None
        with self.isolation(input=input, env=env, color=color) as (stdout, stderr, log):
            try:
                return_value = cli.main(args=list(args), **extra)
            except SystemExit as exc:
                code = exc.code
                if code is None:
                    exit_code = 0
                elif isinstance(code, int):
                    exit_code = code
                else:
                    exit_code = 1
                if exit_code != 0:
                    exception = exc
            except Exception as exc:
                if not catch_exceptions:
                    raise
                exit_code = 1
                exception = exc

        output = b"".join(data for _, data in log.chunks)
        return Result(
            self,
            stdout.bytes_written,
            stderr.bytes_written,
            output,
            exit_code,
            exception,
            return_value,
        )

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Change into a new empty directory. The directory is left in place on exit."""
        cwd = os.getcwd()
        path = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
