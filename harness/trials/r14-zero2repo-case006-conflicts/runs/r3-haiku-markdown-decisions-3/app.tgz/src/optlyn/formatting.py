"""Text wrapping and help-page layout helpers."""

import textwrap

DEFAULT_MAX_CONTENT_WIDTH = 80
DEFAULT_TEXT_WIDTH = 100


def _paragraphs(text):
    """Split into paragraphs separated by blank lines."""
    paragraphs = []
    current = []
    for line in text.split("\n"):
        if line.strip() == "":
            if current:
                paragraphs.append(current)
                current = []
        else:
            current.append(line)
    if current:
        paragraphs.append(current)
    return paragraphs


def wrap_text(
    text,
    width=78,
    initial_indent="",
    subsequent_indent="",
    preserve_paragraphs=False,
):
    """Rewrap ``text`` to ``width`` columns. Never fails on any string.

    A paragraph whose first line is only a backspace character is not rewrapped:
    its line breaks are kept, and the backspace line is removed.
    """
    width = max(int(width), 1)
    text = text.replace("\f", "")
    out = []
    first_block = True
    for para in _paragraphs(text):
        if para[0].strip() == "\b":
            # Verbatim paragraph: drop the backspace line, keep the rest as-is.
            lines = [line for line in para[1:]]
            if not lines:
                continue
            body = [initial_indent + lines[0]] if first_block else [subsequent_indent + lines[0]]
            body += [subsequent_indent + line for line in lines[1:]]
            out.append("\n".join(body))
        else:
            joined = " ".join(line.strip() for line in para)
            wrapped = textwrap.fill(
                joined,
                width=width,
                initial_indent=initial_indent if first_block else subsequent_indent,
                subsequent_indent=subsequent_indent,
                break_long_words=False,
                break_on_hyphens=False,
            )
            out.append(wrapped)
        first_block = False
    return "\n\n".join(out)


def ellipsize(text, width):
    """Shorten ``text`` to fit ``width`` columns, ending with an ellipsis when cut."""
    if len(text) <= width:
        return text
    if width <= 3:
        return text[:width]
    return text[: width - 3].rstrip() + "..."


def first_sentence(text):
    """Return the first sentence of a docstring-like text, on one line."""
    flat = " ".join(text.split())
    for end in (". ", ".\n"):
        idx = flat.find(end)
        if idx != -1:
            return flat[: idx + 1]
    return flat.rstrip(".") + ("." if flat.endswith(".") else "")


def write_columns(rows, indent=2, gap=2, width=78):
    """Lay out ``(first, second)`` rows as two aligned columns."""
    if not rows:
        return []
    first_width = max(len(first) for first, _ in rows)
    first_width = min(first_width, max(width // 2, 10))
    lines = []
    for first, second in rows:
        pad = " " * indent
        if second:
            if len(first) <= first_width:
                lines.append(f"{pad}{first.ljust(first_width)}{' ' * gap}{second}")
            else:
                lines.append(f"{pad}{first}")
                lines.append(f"{pad}{' ' * first_width}{' ' * gap}{second}")
        else:
            lines.append(f"{pad}{first}")
    return lines
