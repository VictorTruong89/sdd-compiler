"""Invocation context: per-run state, value sources, resources, and the thread-local current context."""

import contextlib
import enum
import threading

from .exceptions import Abort, Exit

_local = threading.local()


class ParameterSource(enum.Enum):
    """Where a parameter's value came from, most explicit first (after prompt)."""

    PROMPT = "prompt"
    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"


def _stack():
    stack = getattr(_local, "stack", None)
    if stack is None:
        stack = _local.stack = []
    return stack


def get_current_context(silent=False):
    """Return the context current on this thread; raise or return None when there is none."""
    stack = _stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")


# Keys copied from the parent when a child context does not set them.
_INHERITED_SETTINGS = (
    "auto_envvar_prefix",
    "terminal_width",
    "max_content_width",
    "help_option_names",
    "token_normalize_func",
    "color",
    "show_default",
    "allow_extra_args",
    "ignore_unknown_options",
    "allow_interspersed_args",
)


class Context:
    """State for one invocation of one command."""

    def __init__(
        self,
        command,
        info_name=None,
        parent=None,
        obj=None,
        default_map=None,
        auto_envvar_prefix=None,
        terminal_width=None,
        max_content_width=None,
        help_option_names=None,
        token_normalize_func=None,
        color=None,
        show_default=None,
        allow_extra_args=None,
        ignore_unknown_options=None,
        allow_interspersed_args=None,
        **_ignored,
    ):
        self.command = command
        self.info_name = info_name
        self.parent = parent
        self.params = {}
        self._sources = {}
        self.invoked_subcommand = None
        self._exit_stack = contextlib.ExitStack()
        self._closed = False

        if obj is None and parent is not None:
            obj = parent.obj
        self.obj = obj

        if default_map is None and parent is not None and isinstance(parent.default_map, dict):
            default_map = parent.default_map.get(info_name) if info_name is not None else None
        self.default_map = default_map

        local = {
            "auto_envvar_prefix": auto_envvar_prefix,
            "terminal_width": terminal_width,
            "max_content_width": max_content_width,
            "help_option_names": help_option_names,
            "token_normalize_func": token_normalize_func,
            "color": color,
            "show_default": show_default,
            "allow_extra_args": allow_extra_args,
            "ignore_unknown_options": ignore_unknown_options,
            "allow_interspersed_args": allow_interspersed_args,
        }
        for key in _INHERITED_SETTINGS:
            value = local[key]
            if value is None and parent is not None:
                value = getattr(parent, key)
            setattr(self, key, value)

        if self.help_option_names is None:
            self.help_option_names = ["--help"]
        if self.max_content_width is None:
            self.max_content_width = 80
        if self.show_default is None:
            self.show_default = False
        if self.allow_extra_args is None:
            self.allow_extra_args = bool(getattr(command, "allow_extra_args", False))
        if self.ignore_unknown_options is None:
            self.ignore_unknown_options = bool(getattr(command, "ignore_unknown_options", False))

    # ----- stack and lifetime -------------------------------------------------

    def __enter__(self):
        _stack().append(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        stack = _stack()
        if stack and stack[-1] is self:
            stack.pop()
        elif self in stack:
            stack.remove(self)
        return False

    def with_resource(self, cm):
        """Enter ``cm`` now and close it when the invocation ends."""
        return self._exit_stack.enter_context(cm)

    def call_on_close(self, func):
        self._exit_stack.callback(func)
        return func

    def close(self):
        if not self._closed:
            self._closed = True
            self._exit_stack.close()

    # ----- parameter values ---------------------------------------------------

    def set_parameter_source(self, name, source):
        self._sources[name] = source

    def get_parameter_source(self, name):
        """Return the source of a declared parameter's value, or None for an unknown name."""
        return self._sources.get(name)

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type):
        node = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

    # ----- calling other commands ---------------------------------------------

    def invoke(self, command, **kwargs):
        """Run ``command`` with exactly the given values."""
        return _run_nested(self, command, kwargs, forward=False)

    def forward(self, command, **kwargs):
        """Run ``command`` with this context's values, overridden by ``kwargs``."""
        return _run_nested(self, command, kwargs, forward=True)

    # ----- control ------------------------------------------------------------

    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort("Aborted.")

    def get_help_option_hint(self):
        if not self.help_option_names:
            return None
        name = self.help_option_names[0]
        return f"Try '{self.get_command_path()} {name}' for help."

    def get_command_path(self):
        names = []
        node = self
        while node is not None:
            if node.info_name:
                names.append(node.info_name)
            node = node.parent
        return " ".join(reversed(names))

    def get_help(self):
        return self.command.get_help(self)


def _run_nested(ctx, command, kwargs, forward):
    values = dict(ctx.params) if forward else {}
    values.update(kwargs)
    child = Context(command, info_name=command.name, parent=ctx, obj=ctx.obj)
    with child:
        for key, value in values.items():
            child.params[key] = value
            child.set_parameter_source(key, None)
        return command.invoke_with_values(child, values)
