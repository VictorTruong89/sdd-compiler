"""File opening, filename formatting, and application directory helpers."""

import io
import os
import sys
import tempfile


class _NonClosing:
    """Wraps a standard stream so that exiting a ``with`` block does not close it."""

    def __init__(self, stream):
        object.__setattr__(self, "_stream", stream)

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __iter__(self):
        return iter(self._stream)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def close(self):
        # Standard streams are never closed by Optlyn.
        pass


class LazyFile:
    """A file object that opens on first I/O, and optionally writes atomically.

    Atomic writes go to a sibling temporary file that replaces the target on close.
    """

    def __init__(self, filename, mode, encoding=None, errors="strict", atomic=False):
        self.name = filename
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._file = None
        self._tmp_path = None
        self._closed = False

    def _open(self):
        if self._file is not None:
            return self._file
        if self.atomic and "w" in self.mode:
            directory = os.path.dirname(os.path.abspath(self.name))
            fd, self._tmp_path = tempfile.mkstemp(dir=directory, prefix=".optlyn-", suffix=".tmp")
            os.close(fd)
            target = self._tmp_path
        else:
            target = self.name
        if "b" in self.mode:
            self._file = open(target, self.mode)
        else:
            self._file = open(target, self.mode, encoding=self.encoding, errors=self.errors)
        return self._file

    def __getattr__(self, name):
        return getattr(self._open(), name)

    def __iter__(self):
        return iter(self._open())

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False

    def close(self):
        if self._closed:
            return
        self._closed = True
        if self._file is not None:
            self._file.close()
        if self._tmp_path is not None:
            os.replace(self._tmp_path, self.name)
            self._tmp_path = None


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file, or return a standard stream for ``-``.

    Reads (and standard streams) open immediately unless ``lazy`` is set.
    """
    filename = os.fsdecode(filename) if isinstance(filename, bytes) else filename
    if filename == "-":
        if "w" in mode:
            stream = sys.stdout
        else:
            stream = sys.stdin
        if "b" in mode:
            stream = getattr(stream, "buffer", stream)
        return _NonClosing(stream)
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    if atomic and "w" in mode:
        lf = LazyFile(filename, mode, encoding, errors, atomic)
        lf._open()
        return lf
    if "b" in mode:
        return open(filename, mode)
    return open(filename, mode, encoding=encoding, errors=errors)


def format_filename(filename, shorten=False):
    """Return a printable text form of a file name; never fails on undecodable names."""
    if isinstance(filename, os.PathLike):
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        text = os.fsdecode(filename)
    else:
        text = str(filename)
    if shorten:
        text = os.path.basename(text)
    # Lone surrogates from undecodable bytes are shown with backslash escapes so
    # that different names stay different and the text encodes as strict UTF-8.
    return text.encode("utf-8", "backslashreplace").decode("utf-8")


def get_app_dir(app_name, roaming=True, force_posix=False):
    """Return the per-user config directory for ``app_name``."""
    if sys.platform == "darwin" and not force_posix:
        return os.path.join(os.path.expanduser("~"), "Library", "Application Support", app_name)
    if sys.platform.startswith("win") and not force_posix:
        base = os.environ.get("APPDATA") or os.path.expanduser("~")
        return os.path.join(base, app_name)
    folder = "-".join(app_name.lower().split())
    if force_posix:
        return os.path.join(os.path.expanduser("~"), "." + folder)
    config_home = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
    return os.path.join(config_home, folder)
