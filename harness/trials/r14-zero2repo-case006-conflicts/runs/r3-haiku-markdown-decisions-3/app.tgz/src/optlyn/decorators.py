"""Declaration decorators and ready-made option decorators."""

import functools
import importlib.metadata
import sys

from .commands import Command, Group, _help_callback
from .context import get_current_context
from .exceptions import DeclarationError
from .parameters import Argument, Option
from .termui import confirm, echo

_NAME_SUFFIXES = ("_command", "_cmd", "_group", "_grp")


def _attach_param(f, param):
    """Record a parameter on a function; ``command``/``group`` later claim the list."""
    params = f.__dict__.setdefault("__optlyn_params__", [])
    params.append(param)
    return f


def _claim_params(f):
    params = f.__dict__.pop("__optlyn_params__", [])
    params.reverse()
    return params


def _derive_name(f):
    name = f.__name__.lower().replace("_", "-")
    for suffix in _NAME_SUFFIXES:
        suffix = suffix.replace("_", "-")
        if name.endswith(suffix) and len(name) > len(suffix):
            return name[: -len(suffix)]
    return name


def command(name=None, cls=None, **attrs):
    """Turn a function into a :class:`Command`."""
    cls = cls or Command

    def decorator(f):
        params = _claim_params(f)
        cmd_name = name if name is not None else _derive_name(f)
        if "help" not in attrs:
            attrs["help"] = f.__doc__
        cmd = cls(name=cmd_name, callback=f, params=params, **attrs)
        return cmd

    if callable(name):
        # Used bare as ``@command`` with no parentheses.
        func, name = name, None
        return decorator(func)
    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a :class:`Group`."""
    cls = cls or Group
    return command(name=name, cls=cls, **attrs)


def option(*param_decls, cls=None, **attrs):
    """Attach an :class:`Option` to a function (or to a command)."""
    cls = cls or Option

    def decorator(f):
        param = cls(param_decls, **attrs)
        return _apply(f, param)

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach an :class:`Argument` to a function (or to a command)."""
    cls = cls or Argument

    def decorator(f):
        param = cls(param_decls, **attrs)
        return _apply(f, param)

    return decorator


def _apply(f, param):
    if isinstance(f, Command):
        f.params.insert(0, param)
        return f
    return _attach_param(f, param)


def help_option(*param_decls, **kwargs):
    """An extra eager help flag; it prints help and exits like the automatic option."""
    names = list(param_decls) or ["--help"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _help_callback)

    def decorator(f):
        return _apply(f, Option(["__optlyn_help__"] + names, **kwargs))

    return decorator


def _detect_version(package_name):
    try:
        return importlib.metadata.version(package_name)
    except importlib.metadata.PackageNotFoundError:
        pass
    try:
        mapping = importlib.metadata.packages_distributions()
        dists = mapping.get(package_name)
        if dists:
            return importlib.metadata.version(dists[0])
    except Exception:
        pass
    return "unknown"


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    """An eager flag that prints a version identity and exits."""
    names = list(param_decls) or ["--version"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")

    def callback(ctx, param, value):
        if not value:
            return value
        resolved = version
        if resolved is None:
            resolved = _detect_version(package_name or (ctx.find_root().info_name or ""))
        name = prog_name or ctx.find_root().info_name or ""
        text = message or "%(prog)s, version %(version)s"
        echo(text % {"prog": name, "version": resolved})
        ctx.exit(0)

    kwargs.setdefault("callback", callback)

    def decorator(f):
        return _apply(f, Option(["__optlyn_version__"] + names, **kwargs))

    return decorator


def custom_version_option(callback, *param_decls, **kwargs):
    """An eager flag whose identity is exactly the string ``callback(ctx)`` returns."""
    names = list(param_decls) or ["--version"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")

    def handler(ctx, param, value):
        if not value:
            return value
        echo(callback(ctx))
        ctx.exit(0)

    kwargs["callback"] = handler

    def decorator(f):
        return _apply(f, Option(["__optlyn_version__"] + names, **kwargs))

    return decorator


def password_option(*param_decls, **kwargs):
    """A prompting, hidden-input option with confirmation."""
    names = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)

    def decorator(f):
        return _apply(f, Option(names, **kwargs))

    return decorator


def confirmation_option(*param_decls, **kwargs):
    """A yes flag that asks when omitted and aborts when the user declines."""
    names = list(param_decls) or ["--yes"]
    text = kwargs.pop("prompt", "Do you want to continue?")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("default", False)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Confirm the action without prompting.")

    def handler(ctx, param, value):
        if value:
            return value
        confirm(text, abort=True)
        return True

    kwargs["callback"] = handler

    def decorator(f):
        return _apply(f, Option(names, **kwargs))

    return decorator


def pass_context(f):
    """Pass the current :class:`Context` as the first argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(f):
    """Pass the current context's ``obj`` as the first argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type, ensure=False):
    """Pass the nearest object of ``object_type`` (created when ``ensure``)."""

    def decorator(f):
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(f"Managed to invoke callback without a context object of type {object_type.__name__!r} existing.")
            return f(obj, *args, **kwargs)

        return new_func

    return decorator
