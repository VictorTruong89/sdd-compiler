"""Exception classes used for standalone exit statuses and parameter failures."""

import sys


class OptlynError(Exception):
    """Base class for errors Optlyn signals to the caller."""

    exit_code = 1

    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def show(self, file=None):
        from .termui import echo

        echo(f"Error: {self.message}", file=file or sys.stderr, err=True)


class UsageError(OptlynError):
    """Incorrect usage; standalone exit status 2."""

    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.ctx = ctx

    def show(self, file=None):
        from .termui import echo

        echo(f"Usage error: {self.message}", file=file or sys.stderr, err=True)
        if self.ctx is not None and self.ctx.command is not None:
            hint = self.ctx.get_help_option_hint()
            if hint:
                echo(hint, file=file or sys.stderr, err=True)


class BadParameter(UsageError):
    """A value was refused for one parameter.

    ``param_hint`` (the parameter's identity) appears in the report.
    """

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint()
        if hint:
            return f"Invalid value for {hint}: {self.message}"
        return f"Invalid value: {self.message}"

    def show(self, file=None):
        from .termui import echo

        echo(f"Usage error: {self.format_message()}", file=file or sys.stderr, err=True)
        if self.ctx is not None and self.ctx.command is not None:
            hint = self.ctx.get_help_option_hint()
            if hint:
                echo(hint, file=file or sys.stderr, err=True)


class MissingParameter(BadParameter):
    """A required parameter was not supplied by any source."""

    def format_message(self):
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint()
        return f"Missing required parameter {hint}" if hint else "Missing required parameter"


class NoSuchOption(UsageError):
    """An option token is not declared on the command."""

    def __init__(self, option_name, message=None, ctx=None):
        super().__init__(message or f"No such option: {option_name}", ctx)
        self.option_name = option_name


class NoSuchCommand(UsageError):
    """A subcommand name is not known to a group."""

    def __init__(self, name, message=None, ctx=None):
        super().__init__(message or f"No such command: {name}", ctx)
        self.command_name = name


class MissingCommand(UsageError):
    """A group was invoked without a subcommand where one is required."""

    def __init__(self, message="Missing command.", ctx=None):
        super().__init__(message, ctx)


class Abort(OptlynError):
    """User abort, EOF on a prompt, or keyboard interrupt; standalone exit 1."""

    exit_code = 1

    def show(self, file=None):
        from .termui import echo

        echo("Aborted!", file=file or sys.stderr, err=True)


class Exit(Exception):
    """Author clean stop; carries the exit status."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code


class DeclarationError(TypeError):
    """An invalid combination of declaration keywords."""
