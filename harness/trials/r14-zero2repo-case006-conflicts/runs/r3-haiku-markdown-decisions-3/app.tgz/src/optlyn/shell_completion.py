"""Shell completion: registration scripts and suggestion output for bash, zsh, fish, and PowerShell."""

import os
import sys

from .context import Context
from .parameters import Option
from .termui import echo

SHELLS = ("bash", "zsh", "fish", "powershell")
MODES = ("source", "complete")
PATH_FILE = "__optlyn_path_file__"
PATH_DIR = "__optlyn_path_dir__"


class PathRequest:
    """Completion entry asking the shell to complete a path."""

    def __init__(self, incomplete, directories_only=False):
        self.incomplete = incomplete
        self.directories_only = directories_only

    def __repr__(self):
        return f"PathRequest({self.incomplete!r}, directories_only={self.directories_only})"


class CompletionItem:
    def __init__(self, value, help=None, type="plain"):
        self.value = value
        self.help = help
        self.type = type


def complete_var_name(prog):
    return "_" + prog.upper().replace("-", "_") + "_COMPLETE"


def _script(shell, prog, var_name):
    if shell == "bash":
        return (
            f"_{prog.replace('-', '_')}_completion() {{\n"
            f"    local IFS=$'\\n'\n"
            f"    COMPREPLY=( $(env COMP_WORDS=\"${{COMP_WORDS[*]}}\" COMP_CWORD=$COMP_CWORD "
            f"{var_name}=bash_complete {prog}) )\n"
            f"    return 0\n}}\n"
            f"complete -o default -F _{prog.replace('-', '_')}_completion {prog}\n"
        )
    if shell == "zsh":
        return (
            f"#compdef {prog}\n"
            f"_{prog.replace('-', '_')}_completion() {{\n"
            f"    local -a completions\n"
            f"    completions=(\"${{(@f)$(env COMP_WORDS=\"${{words[*]}}\" COMP_CWORD=$((CURRENT-1)) "
            f"{var_name}=zsh_complete {prog})}}\")\n"
            f"    compadd -a completions\n}}\n"
            f"compdef _{prog.replace('-', '_')}_completion {prog}\n"
        )
    if shell == "fish":
        return (
            f"complete --no-files --command {prog} --arguments "
            f"\"(env {var_name}=fish_complete COMP_WORDS=(commandline -cp) "
            f"COMP_CWORD=(commandline -ct) {prog})\"\n"
        )
    return (
        f"Register-ArgumentCompleter -Native -CommandName {prog} -ScriptBlock {{\n"
        f"    param($wordToComplete, $commandAst, $cursorPosition)\n"
        f"    $env:COMP_WORDS = $commandAst.ToString()\n"
        f"    $env:COMP_CWORD = $wordToComplete\n"
        f"    $env:{var_name} = 'powershell_complete'\n"
        f"    & {prog} | ForEach-Object {{ [System.Management.Automation.CompletionResult]::new($_, $_, 'ParameterValue', $_) }}\n"
        f"    Remove-Item Env:{var_name}\n}}\n"
    )


def _split_words(shell):
    words = os.environ.get("COMP_WORDS", "").split(" ")
    if shell == "fish":
        incomplete = os.environ.get("COMP_CWORD", "")
        preceding = words[1:]
        if preceding and preceding[-1] == incomplete:
            preceding = preceding[:-1]
        return preceding, incomplete
    try:
        cword = int(os.environ.get("COMP_CWORD", str(len(words))))
    except ValueError:
        cword = len(words)
    preceding = words[1:cword]
    incomplete = words[cword] if cword < len(words) else ""
    return [w for w in preceding if w != ""], incomplete


def _suggest(cmd, prog, preceding, incomplete):
    from .commands import Group

    ctx = Context(cmd, info_name=prog)
    items = []
    pending_param = None
    tokens = list(preceding)
    i = 0
    while i < len(tokens):
        tok = tokens[i]
        i += 1
        if pending_param is not None:
            pending_param = None
            continue
        if tok.startswith("-") and tok != "-":
            name = tok.split("=", 1)[0]
            for param in cmd.get_params(ctx):
                if isinstance(param, Option) and name in param.opts and not param.is_flag:
                    if "=" not in tok:
                        pending_param = param
                    break
            continue
        if isinstance(cmd, Group):
            child = cmd.get_command(ctx, tok)
            if child is not None:
                cmd = child
                ctx = Context(cmd, info_name=tok, parent=ctx)
                continue
    if pending_param is not None:
        return _value_suggestions(ctx, pending_param, incomplete)

    if incomplete.startswith("-"):
        for param in cmd.get_params(ctx):
            if not isinstance(param, Option) or param.hidden:
                continue
            for opt in param.opts + param.secondary_opts:
                if opt.startswith(incomplete):
                    items.append(CompletionItem(opt, param.help))
        return items

    if isinstance(cmd, Group):
        for name in cmd.list_commands(ctx):
            sub = cmd.get_command(ctx, name)
            if sub is None or sub.hidden or not name.startswith(incomplete):
                continue
            items.append(CompletionItem(name, sub.short_help or (sub.help or "").split("\n")[0]))
        return items

    arguments = [p for p in cmd.params if not isinstance(p, Option)]
    consumed = [t for t in preceding if not t.startswith("-")]
    index = min(len(consumed), len(arguments) - 1) if arguments else -1
    if index >= 0:
        return _value_suggestions(ctx, arguments[index], incomplete)
    return items


def _value_suggestions(ctx, param, incomplete):
    if param.shell_complete is not None:
        result = param.shell_complete(ctx, param, incomplete)
    else:
        result = param.type.shell_complete(ctx, param, incomplete)
    items = []
    for entry in result or []:
        if isinstance(entry, PathRequest):
            items.append(entry)
        elif isinstance(entry, str):
            if entry.startswith(incomplete):
                items.append(CompletionItem(entry))
        else:
            value = getattr(entry, "value", None)
            if value is not None and str(value).startswith(incomplete):
                items.append(CompletionItem(str(value), getattr(entry, "help", None), getattr(entry, "type", "plain")))
    return items


def _emit(items, shell):
    for item in items:
        if isinstance(item, PathRequest):
            kind = PATH_DIR if item.directories_only else PATH_FILE
            echo(f"{kind} {item.incomplete}")
            continue
        if item.help and shell in ("zsh", "fish"):
            echo(f"{item.value}\t{item.help}")
        else:
            echo(item.value)


def handle_completion(cmd, prog, var_name, args, standalone_mode=True):
    value = os.environ.get(var_name, "")
    shell, _, mode = value.rpartition("_")
    if shell not in SHELLS or mode not in MODES:
        echo(f"Unknown completion instruction {value!r}.", err=True)
        if standalone_mode:
            raise SystemExit(1)
        return None
    if mode == "source":
        echo(_script(shell, prog, var_name), nl=False)
    else:
        preceding, incomplete = _split_words(shell)
        _emit(_suggest(cmd, prog, preceding, incomplete), shell)
    if standalone_mode:
        raise SystemExit(0)
    return None
