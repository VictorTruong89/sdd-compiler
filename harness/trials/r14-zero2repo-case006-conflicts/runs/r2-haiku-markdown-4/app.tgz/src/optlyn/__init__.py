"""Optlyn: the Command Line Interface Composition Kit.

Import the public names from the package root::

    from optlyn import command, group, option, argument, echo
"""

from __future__ import annotations

from .completion import CompletionItem
from .context import Context, ParameterSource, get_current_context
from .core import Command, CommandCollection, Group
from .decorators import (
    argument,
    command,
    confirmation_option,
    custom_version_option,
    group,
    help_option,
    make_pass_decorator,
    option,
    pass_context,
    pass_obj,
    password_option,
    version_option,
)
from .exceptions import (
    Abort,
    BadParameter,
    DeclarationError,
    Exit,
    MissingParameter,
    NoSuchOption,
    OptlynError,
    UnknownCommand,
    UsageError,
)
from .params import Argument, Option, Parameter
from .termui import (
    clear,
    confirm,
    echo,
    echo_via_pager,
    edit,
    get_app_dir,
    get_pager_file,
    getchar,
    format_filename,
    launch,
    open_file,
    pause,
    progressbar,
    prompt,
    secho,
    style,
    unstyle,
)
from .paramtypes import (
    BOOL,
    FLOAT,
    INT,
    STRING,
    UNPROCESSED,
    UUID,
    Choice,
    DateTime,
    File,
    FloatRange,
    IntRange,
    ParamType,
    Path,
    Tuple,
)
__version__ = "0.1.0"

__all__ = [
    # declaration
    "command",
    "group",
    "option",
    "argument",
    "help_option",
    "version_option",
    "custom_version_option",
    "password_option",
    "confirmation_option",
    "pass_context",
    "pass_obj",
    "make_pass_decorator",
    # classes
    "Command",
    "Group",
    "CommandCollection",
    "Context",
    "Option",
    "Parameter",
    "ParamType",
    "BadParameter",
    "Abort",
    "Exit",
    "UsageError",
    "MissingParameter",
    "NoSuchOption",
    "UnknownCommand",
    "OptlynError",
    "DeclarationError",
    "ParameterSource",
    "CompletionItem",
    "Argument",
    # types
    "STRING",
    "INT",
    "FLOAT",
    "BOOL",
    "UUID",
    "UNPROCESSED",
    "Choice",
    "DateTime",
    "IntRange",
    "FloatRange",
    "Tuple",
    "File",
    "Path",
    # terminal helpers
    "echo",
    "secho",
    "style",
    "unstyle",
    "echo_via_pager",
    "get_pager_file",
    "progressbar",
    "prompt",
    "confirm",
    "getchar",
    "pause",
    "edit",
    "launch",
    "clear",
    "get_app_dir",
    "get_current_context",
    "format_filename",
    "open_file",
]
