"""Text wrapping and help-page formatting (FP-02, FP-11)."""

from __future__ import annotations

import textwrap


def wrap_text(text: str, width: int = 80, indent: int = 0) -> str:
    """Rewrap ``text`` to ``width`` columns. Accepts any string (FP-11).

    Single newlines inside a paragraph are not kept as hard breaks. A
    paragraph whose first line is only a backspace character is not
    rewrapped: its line breaks are kept and the backspace line is removed.
    """
    width = max(width, 10)
    pad = " " * indent
    out: list[str] = []
    for para in text.split("\n\n"):
        lines = para.split("\n")
        if lines and lines[0] != "" and lines[0].strip("\b") == "":
            out.append("\n".join(pad + ln for ln in lines[1:]))
            continue
        flat = " ".join(ln.strip() for ln in lines if ln.strip())
        if not flat:
            continue
        out.append(textwrap.fill(flat, width=width, initial_indent=pad, subsequent_indent=pad))
    return "\n\n".join(out)


def first_sentence(text: str) -> str:
    """The first sentence of a docstring, used as the short help."""
    flat = " ".join(text.split())
    if not flat:
        return ""
    for i, ch in enumerate(flat):
        if ch == "." and (i + 1 == len(flat) or flat[i + 1] == " "):
            return flat[: i + 1]
    return flat


def ellipsize(text: str, width: int) -> str:
    if len(text) <= width:
        return text
    if width <= 3:
        return text[:width]
    return text[: width - 3].rstrip() + "..."


class HelpFormatter:
    """Accumulates a help page in a fixed section order."""

    def __init__(self, width: int = 80, max_width: int = 80, indent_increment: int = 2) -> None:
        self.width = min(width, max_width) if width else max_width
        self.indent_increment = indent_increment
        self.lines: list[str] = []

    def write(self, text: str = "") -> None:
        self.lines.append(text)

    def write_usage(self, prog: str, args: str) -> None:
        self.write("Usage: " + " ".join(p for p in (prog, args) if p))

    def write_text(self, text: str) -> None:
        if text:
            self.write(wrap_text(text, self.width))
            self.write()

    def write_section(self, heading: str, rows: list[tuple[str, str]]) -> None:
        if not rows:
            return
        self.write(heading + ":")
        first_col = max(len(r[0]) for r in rows)
        first_col = min(first_col, self.width // 2)
        for left, right in rows:
            if not right:
                self.write(self.indent_increment * " " + left)
                continue
            if len(left) <= first_col:
                head = left.ljust(first_col)
                body = textwrap.wrap(right, width=max(self.width - first_col - 2 - self.indent_increment, 10))
                self.write(self.indent_increment * " " + head + "  " + (body[0] if body else ""))
                for extra in body[1:]:
                    self.write(" " * (self.indent_increment + first_col + 2) + extra)
            else:
                self.write(self.indent_increment * " " + left)
                for extra in textwrap.wrap(right, width=max(self.width - first_col - 2 - self.indent_increment, 10)):
                    self.write(" " * (self.indent_increment + first_col + 2) + extra)
        self.write()

    def getvalue(self) -> str:
        text = "\n".join(self.lines).rstrip() + "\n"
        return text
