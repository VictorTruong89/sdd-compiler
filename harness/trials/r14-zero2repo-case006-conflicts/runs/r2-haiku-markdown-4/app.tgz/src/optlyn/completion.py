"""Shell completion (FP-12)."""

from __future__ import annotations

import os
import re
import sys
import typing as t

SHELLS = ("bash", "zsh", "fish", "powershell")


class CompletionItem:
    """One suggestion. ``type`` is ``plain`` for values; path requests use ``path:dir``/``path:file``."""

    def __init__(self, value: str, help: str | None = None, type: str = "plain") -> None:
        self.value = value
        self.help = help
        self.type = type

    def __repr__(self) -> str:
        return f"CompletionItem({self.value!r}, help={self.help!r}, type={self.type!r})"


def complete_var_name(prog_name: str) -> str:
    return "_" + re.sub(r"[-.\s]", "_", os.path.basename(prog_name)).upper() + "_COMPLETE"


def _normalize_item(item) -> CompletionItem:
    if isinstance(item, CompletionItem):
        return item
    if isinstance(item, str):
        return CompletionItem(item)
    return CompletionItem(item.value, getattr(item, "help", None), getattr(item, "type", "plain"))


def parse_words(shell: str, comp_words: str, comp_cword: str) -> tuple[list[str], str]:
    """Split the completion environment into (words before the incomplete one, incomplete token)."""
    words = comp_words.split(" ")
    if shell == "fish":
        incomplete = comp_cword
        # fish supplies the incomplete token directly; words are complete ones.
        return words, incomplete
    try:
        idx = int(comp_cword)
    except ValueError:
        idx = len(words)
    idx = max(0, min(idx, len(words)))
    incomplete = words[idx] if idx < len(words) else ""
    return words[:idx], incomplete


def source_script(shell: str, prog: str, complete_var: str) -> str:
    """Registration script printed by ``<shell>_source``."""
    name = re.sub(r"\W", "_", prog)
    if shell == "bash":
        return (
            f"_{name}_completion() {{\n"
            f"    local IFS=$'\\n'\n"
            f"    COMPREPLY=( $( env COMP_WORDS=\"${{COMP_WORDS[*]}}\" "
            f"COMP_CWORD=$COMP_CWORD {complete_var}=bash_complete {prog} ) )\n"
            f"    return 0\n"
            f"}}\n"
            f"complete -o default -F _{name}_completion {prog}\n"
        )
    if shell == "zsh":
        return (
            f"#compdef {prog}\n"
            f"_{name}_completion() {{\n"
            f"    local -a completions\n"
            f"    completions=(${{(f)\"$(env COMP_WORDS=\"${{words[*]}}\" "
            f"COMP_CWORD=$((CURRENT-1)) {complete_var}=zsh_complete {prog})\"}})\n"
            f"    compadd -a completions\n"
            f"}}\n"
            f"compdef _{name}_completion {prog}\n"
        )
    if shell == "fish":
        return (
            f"complete --no-files --command {prog} --arguments "
            f"'(env {complete_var}=fish_complete COMP_WORDS=(commandline -cp) "
            f"COMP_CWORD=(commandline -ct) {prog})'\n"
        )
    if shell == "powershell":
        return (
            f"Register-ArgumentCompleter -Native -CommandName {prog} -ScriptBlock {{\n"
            f"    param($wordToComplete, $commandAst, $cursorPosition)\n"
            f"    $env:COMP_WORDS = $commandAst.ToString()\n"
            f"    $env:COMP_CWORD = $wordToComplete\n"
            f"    $env:{complete_var} = 'powershell_complete'\n"
            f"    & {prog} | ForEach-Object {{ [System.Management.Automation.CompletionResult]::new($_, $_, 'ParameterValue', $_) }}\n"
            f"    Remove-Item Env:\\{complete_var}\n"
            f"}}\n"
        )
    raise ValueError(shell)


def format_suggestions(shell: str, items: t.Iterable[CompletionItem]) -> str:
    """Render suggestions for the shell. Help text is shown for zsh and fish only."""
    lines = []
    for item in items:
        if item.type != "plain":
            lines.append(f"{item.type}\t{item.value}")
            continue
        if shell in ("zsh", "fish") and item.help:
            lines.append(f"{item.value}\t{item.help}")
        else:
            lines.append(item.value)
    return "\n".join(lines) + ("\n" if lines else "")


def run_complete(cmd, prog: str, complete_var: str, instruction: str, args_env=None) -> int | None:
    """If the completion variable selects an instruction, handle it and return an exit code.

    Returns None when the variable is not set for this program.
    """
    shell, _, mode = instruction.partition("_")
    if mode not in ("source", "complete") or shell not in SHELLS:
        # Unrecognized instruction: neither a script nor suggestions, no callback.
        return 1
    if mode == "source":
        sys.stdout.write(source_script(shell, prog, complete_var))
        return 0
    comp_words = os.environ.get("COMP_WORDS", "")
    comp_cword = os.environ.get("COMP_CWORD", "0")
    ctx_words, incomplete = parse_words(shell, comp_words, comp_cword)
    items = cmd._complete(ctx_words[1:], incomplete)
    sys.stdout.write(format_suggestions(shell, items))
    return 0
