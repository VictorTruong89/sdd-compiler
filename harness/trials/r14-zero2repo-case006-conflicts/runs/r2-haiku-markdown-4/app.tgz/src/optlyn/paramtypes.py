"""Parameter types and conversion (FP-05, FP-09)."""

from __future__ import annotations

import datetime as dt
import enum
import os
import pathlib
import typing as t
import uuid

from .exceptions import BadParameter


class ParamType:
    """Base class for parameter types.

    Subclasses set ``name`` and implement :meth:`convert`. A type that
    supplies its own placeholder sets ``metavar``.
    """

    name: str = "text"
    envvar_list_splitter: str | None = None
    is_composite: bool = False

    def __call__(self, value: t.Any, param: t.Any = None, ctx: t.Any = None) -> t.Any:
        return self.convert(value, param, ctx)

    def convert(self, value: t.Any, param: t.Any = None, ctx: t.Any = None) -> t.Any:
        return value

    def get_metavar(self, param: t.Any = None) -> str | None:
        return self.name.upper()

    def shell_complete(self, ctx: t.Any, param: t.Any, incomplete: str) -> list:
        return []

    def split_envvar_value(self, rv: str) -> list[str]:
        if self.envvar_list_splitter:
            return [x for x in rv.split(self.envvar_list_splitter) if x]
        return rv.split()

    def fail(self, message: str, param: t.Any = None, ctx: t.Any = None) -> t.NoReturn:
        raise BadParameter(message, ctx=ctx, param=param)

    def __repr__(self) -> str:
        return self.name.upper()


class _StringType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            try:
                return value.decode("utf-8")
            except UnicodeError:
                self.fail(f"{value!r} is not valid text", param, ctx)
        return str(value)


class _UnprocessedType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


class _IntType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            return int(str(value).strip(), 10)
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid integer", param, ctx)


class _FloatType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        try:
            return float(value)
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid floating point value", param, ctx)


_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class _BoolType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean", param, ctx)


class _UUIDType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except (ValueError, TypeError, AttributeError):
            self.fail(f"{value!r} is not a valid UUID", param, ctx)


STRING = _StringType()
INT = _IntType()
FLOAT = _FloatType()
BOOL = _BoolType()
UUID = _UUIDType()
UNPROCESSED = _UnprocessedType()


class Choice(ParamType):
    """A closed list of allowed values, or an enumeration.

    Matching is by string form. Enumeration members are matched by name.
    The delivered value is the original choice object.
    """

    name = "choice"

    def __init__(self, choices, case_sensitive: bool = True) -> None:
        self.case_sensitive = case_sensitive
        self._is_enum = isinstance(choices, type) and issubclass(choices, enum.Enum)
        if self._is_enum:
            self.choices: list = list(choices)  # members
            self._tokens = [m.name for m in self.choices]
        else:
            self.choices = list(choices)
            self._tokens = [str(c) for c in self.choices]

    def get_metavar(self, param=None):
        return "[" + "|".join(self._tokens) + "]"

    def _norm(self, s: str) -> str:
        return s if self.case_sensitive else s.casefold()

    def convert(self, value, param=None, ctx=None):
        if self._is_enum and isinstance(value, enum.Enum):
            if value in self.choices:
                return value
        if not self._is_enum and value in self.choices:
            return value
        token = value if isinstance(value, str) else str(value)
        normf = getattr(ctx, "token_normalize_func", None) if ctx is not None else None

        def norm(s: str) -> str:
            if normf is not None:
                s = normf(s)
            return self._norm(s)

        for orig, tok in zip(self.choices, self._tokens):
            if norm(tok) == norm(token):
                return orig
        self.fail(
            f"{token!r} is not one of " + ", ".join(repr(x) for x in self._tokens) + ".",
            param,
            ctx,
        )

    def shell_complete(self, ctx, param, incomplete):
        from .completion import CompletionItem

        out = []
        for tok in self._tokens:
            if self._norm(tok).startswith(self._norm(incomplete)):
                out.append(CompletionItem(tok))
        return out


_DEFAULT_DT_FORMATS = ["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None) -> None:
        self.formats = list(formats) if formats is not None else list(_DEFAULT_DT_FORMATS)

    def get_metavar(self, param=None):
        return "[" + "|".join(self.formats) + "]"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, dt.datetime):
            return value
        for fmt in self.formats:
            try:
                return dt.datetime.strptime(str(value).strip(), fmt)
            except ValueError:
                continue
        self.fail(
            f"{value!r} does not match the formats {', '.join(self.formats)}.",
            param,
            ctx,
        )


class _RangeMixin:
    def _bounds_check(self, value, param, ctx):
        lo, hi = self.min, self.max
        if lo is not None:
            if self.min_open:
                if value <= lo:
                    return self._clamp_or_fail(value, "min", param, ctx)
            elif value < lo:
                return self._clamp_or_fail(value, "min", param, ctx)
        if hi is not None:
            if self.max_open:
                if value >= hi:
                    return self._clamp_or_fail(value, "max", param, ctx)
            elif value > hi:
                return self._clamp_or_fail(value, "max", param, ctx)
        return value

    def _range_desc(self):
        lo = "" if self.min is None else (">" if self.min_open else ">=") + f" {self.min}"
        hi = "" if self.max is None else ("<" if self.max_open else "<=") + f" {self.max}"
        return " and ".join(x for x in (lo, hi) if x) or "any value"


class IntRange(_RangeMixin, _IntType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def get_metavar(self, param=None):
        return "integer range"

    def _clamp_or_fail(self, value, side, param, ctx):
        if not self.clamp:
            self.fail(f"{value} is not in the range {self._range_desc()}.", param, ctx)
        if side == "min":
            if self.min_open:
                return self.min + 1
            return self.min
        if self.max_open:
            return self.max - 1
        return self.max

    def convert(self, value, param=None, ctx=None):
        value = _IntType.convert(self, value, param, ctx)
        return self._bounds_check(value, param, ctx)


class FloatRange(_RangeMixin, _FloatType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min_open or max_open):
            raise ValueError("Clamping is not supported for open bounds.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def get_metavar(self, param=None):
        return "float range"

    def _clamp_or_fail(self, value, side, param, ctx):
        if not self.clamp:
            self.fail(f"{value} is not in the range {self._range_desc()}.", param, ctx)
        return self.min if side == "min" else self.max

    def convert(self, value, param=None, ctx=None):
        value = _FloatType.convert(self, value, param, ctx)
        return self._bounds_check(value, param, ctx)


class Tuple(ParamType):
    name = "tuple"
    is_composite = True

    def __init__(self, types) -> None:
        self.types = [_as_type(x) for x in types]

    def get_metavar(self, param=None):
        return " ".join(x.name.upper() for x in self.types)

    def convert(self, value, param=None, ctx=None):
        if not isinstance(value, (tuple, list)) or len(value) != len(self.types):
            self.fail(f"{value!r} must have {len(self.types)} items", param, ctx)
        return tuple(ty.convert(v, param, ctx) for ty, v in zip(self.types, value))


def _as_type(obj) -> ParamType:
    """Turn a Python type or conversion function into a ParamType."""
    if isinstance(obj, ParamType):
        return obj
    if isinstance(obj, (tuple, list)):
        return Tuple(obj)
    if obj is str:
        return STRING
    if obj is int:
        return INT
    if obj is float:
        return FLOAT
    if obj is bool:
        return BOOL
    if obj is uuid.UUID:
        return UUID
    return FuncType(obj)


class FuncType(ParamType):
    """Wrap a conversion function ``f(token) -> value`` that raises ValueError to refuse."""

    def __init__(self, func) -> None:
        self.func = func
        self.name = getattr(func, "__name__", "text")

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except BadParameter:
            raise
        except ValueError as e:
            self.fail(str(e) or f"{value!r} is not valid", param, ctx)


def convert_type(ty, default=None) -> ParamType:
    """Resolve a type argument or infer one from a default value."""
    if ty is not None:
        return _as_type(ty)
    if default is not None and not callable(default):
        if isinstance(default, bool):
            return BOOL
        if isinstance(default, int):
            return INT
        if isinstance(default, float):
            return FLOAT
        if isinstance(default, uuid.UUID):
            return UUID
        if isinstance(default, (tuple, list)) and default:
            return convert_type(None, default[0])
    return STRING


class File(ParamType):
    """An open file object. ``-`` means stdin (read) or stdout (write)."""

    name = "filename"
    envvar_list_splitter = os.pathsep

    def __init__(
        self,
        mode: str = "r",
        encoding: str | None = None,
        errors: str = "strict",
        lazy: bool | None = None,
        atomic: bool = False,
    ) -> None:
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"unsupported file mode {mode!r}")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def get_metavar(self, param=None):
        return "FILENAME"

    def convert(self, value, param=None, ctx=None):
        from .termui import open_file

        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        lazy = self.lazy
        if lazy is None:
            lazy = "w" in self.mode
        filename = str(value)
        try:
            return open_file(
                filename,
                self.mode,
                self.encoding,
                self.errors,
                lazy=lazy,
                atomic=self.atomic,
            )
        except OSError as e:
            self.fail(f"'{filename}': {e.strerror or e}", param, ctx)


class Path(ParamType):
    """A filesystem path. Delivers the path, not an open file."""

    name = "path"
    envvar_list_splitter = os.pathsep

    def __init__(
        self,
        exists: bool = False,
        file_okay: bool = True,
        dir_okay: bool = True,
        writable: bool = False,
        readable: bool = True,
        resolve_path: bool = False,
        allow_dash: bool = False,
        path_type=None,
        executable: bool = False,
    ) -> None:
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def get_metavar(self, param=None):
        return "PATH"

    def convert(self, value, param=None, ctx=None):
        rv = os.fspath(value) if isinstance(value, os.PathLike) else value
        if isinstance(rv, bytes):
            rv = os.fsdecode(rv)
        if self.allow_dash and rv == "-":
            return self._deliver(rv)
        is_dash = rv == "-"
        if is_dash and self.allow_dash:  # pragma: no cover - handled above
            return self._deliver(rv)
        if self.resolve_path:
            rv = os.path.realpath(rv)
        if not os.path.exists(rv):
            if not self.exists:
                return self._deliver(rv)
            self.fail(f"{value!r} does not exist.", param, ctx)
        if not self.file_okay and not os.path.isdir(rv):
            self.fail(f"{value!r} is a file.", param, ctx)
        if not self.dir_okay and os.path.isdir(rv):
            self.fail(f"{value!r} is a directory.", param, ctx)
        if self.readable and not os.access(rv, os.R_OK):
            self.fail(f"{value!r} is not readable.", param, ctx)
        if self.writable and not os.access(rv, os.W_OK):
            self.fail(f"{value!r} is not writable.", param, ctx)
        if self.executable and not os.access(rv, os.X_OK):
            self.fail(f"{value!r} is not executable.", param, ctx)
        return self._deliver(rv)

    def _deliver(self, rv: str):
        if self.path_type is None or self.path_type is str:
            return rv
        if self.path_type is pathlib.Path:
            return pathlib.Path(rv)
        return self.path_type(rv)

    def shell_complete(self, ctx, param, incomplete):
        from .completion import CompletionItem

        kind = "dir" if (self.dir_okay and not self.file_okay) else "file"
        return [CompletionItem(incomplete, type=f"path:{kind}")]
