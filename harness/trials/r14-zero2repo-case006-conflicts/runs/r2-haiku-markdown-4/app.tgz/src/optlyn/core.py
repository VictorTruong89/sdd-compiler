"""Commands, groups, parsing, dispatch and help (FP-01, FP-02, FP-06, FP-10, FP-13)."""

from __future__ import annotations

import os
import shutil
import sys
import typing as t

from . import termui
from .completion import CompletionItem, complete_var_name, run_complete
from .context import Context
from .exceptions import (
    Abort,
    DeclarationError,
    Exit,
    NoArgsIsHelpError,
    NoSuchOption,
    OptlynError,
    UnknownCommand,
    UsageError,
)
from .formatting import HelpFormatter, first_sentence
from .params import Argument, Option, Parameter
from .paramtypes import File

CHAIN = object()  # invoked_subcommand while a chaining group runs several children


class Command:
    """A leaf command: options and arguments plus an author callback (FP-01)."""

    def __init__(
        self,
        name: str | None,
        callback: t.Callable | None = None,
        params: list[Parameter] | None = None,
        help: str | None = None,
        short_help: str | None = None,
        epilog: str | None = None,
        options_metavar: str | None = "[OPTIONS]",
        context_settings: dict | None = None,
        add_help_option: bool = True,
        no_args_is_help: bool = False,
        deprecated: bool | str = False,
        hidden: bool = False,
        **_ignored: t.Any,
    ) -> None:
        self.name = name
        self.callback = callback
        self.params: list[Parameter] = list(params or [])
        self.help = help
        self.short_help = short_help
        self.epilog = epilog
        self.options_metavar = options_metavar
        self.context_settings = dict(context_settings or {})
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.deprecated = deprecated
        self.hidden = hidden

    def __call__(self, *args: t.Any, **kwargs: t.Any) -> t.Any:
        return self.main(*args, **kwargs)

    # -- option index ---------------------------------------------------

    def _help_names(self, ctx: Context) -> list[str]:
        return list(ctx.get_setting("help_option_names") or ["--help"])

    def _auto_help_option(self, ctx: Context) -> Option | None:
        """The automatic help flag, minus any names an author option already uses (FP-02)."""
        if not self.add_help_option:
            return None
        claimed = {f for p in self.params if isinstance(p, Option) for f in p.opts + p.secondary_opts}
        names = [n for n in self._help_names(ctx) if n not in claimed]
        if not names:
            return None
        return _make_help_option(names)

    def _all_options(self, ctx: Context) -> list[Option]:
        out = [p for p in self.params if isinstance(p, Option)]
        auto = self._auto_help_option(ctx)
        if auto is not None:
            out.append(auto)
        return out

    def _option_index(self, ctx: Context) -> dict[str, tuple[Option, str, t.Any]]:
        index: dict[str, tuple[Option, str, t.Any]] = {}
        for p in self._all_options(ctx):
            if p.is_flag:
                if p.flag_value is None:
                    on_value: t.Any = True
                else:
                    on_value = p.flag_value
                for flag in p.opts:
                    index.setdefault(flag, (p, "flag", on_value))
                for flag in p.secondary_opts:
                    index.setdefault(flag, (p, "flag", False))
            elif p.count:
                for flag in p.opts:
                    index.setdefault(flag, (p, "count", 1))
            else:
                for flag in p.opts:
                    index.setdefault(flag, (p, "value", None))
        return index

    def _prefixes(self, ctx: Context) -> set[str]:
        out = {"-"}
        for p in self._all_options(ctx):
            for flag in p.opts + p.secondary_opts:
                out.add(flag[0])
        return out

    def _fixed_arg_count(self) -> int | None:
        """Positional tokens needed before the scan may stop (None: variadic, consume all)."""
        total = 0
        for a in self.params:
            if isinstance(a, Argument):
                if a.nargs == -1:
                    return None
                total += a.nargs
        return total

    # -- scanning -------------------------------------------------------

    def _scan(
        self,
        ctx: Context,
        args: list[str],
        stop_after: int | None,
        chain: bool = False,
        group: bool = False,
    ) -> tuple[dict[str, list], list[str], int]:
        """Read options and positional tokens from ``args``.

        Returns ``(occurrences, positionals, stop_index)``. Scanning stops at
        the first positional token once ``stop_after`` positionals were taken;
        ``args[stop_index:]`` is then what follows (a subcommand name or a
        chained command). Eager parameters run as soon as they are seen.
        """
        occ: dict[str, list] = {}
        pos: list[str] = []
        index = self._option_index(ctx)
        prefixes = self._prefixes(ctx)
        normf = ctx.get_setting("token_normalize_func")
        ignore_unknown = ctx.get_setting("ignore_unknown_options")
        interspersed = (not chain) and (not group) and bool(ctx.get_setting("allow_interspersed_args"))

        def lookup(flag: str):
            if flag in index:
                return index[flag]
            if normf is not None:
                for key, hit in index.items():
                    if normf(key) == normf(flag):
                        return hit
            return None

        eager_done: set[str] = ctx.__dict__.setdefault("_eager_done", set())

        def record(param: Parameter, value: t.Any) -> None:
            if param.is_eager:
                if param.name in eager_done:
                    return
                eager_done.add(param.name)
                param.resolve(ctx, [value])
                return
            occ.setdefault(param.name, []).append(value)

        seen_positional = False
        dd = False
        i = 0
        while i < len(args):
            tok = args[i]
            if not dd and tok == "--":
                dd = True
                i += 1
                continue
            is_opt = not dd and len(tok) > 1 and tok[0] in prefixes
            if is_opt and (interspersed or not seen_positional):
                new_i = self._take_option(ctx, tok, args, i, lookup, record, pos, ignore_unknown, prefixes)
                if new_i is not None:
                    i = new_i
                    continue
            # Positional token.
            if stop_after is not None and len(pos) >= stop_after:
                return occ, pos, i
            pos.append(tok)
            seen_positional = True
            i += 1
        return occ, pos, len(args)

    def _take_option(self, ctx, tok, args, i, lookup, record, pos, ignore_unknown, prefixes):
        """Handle one option-shaped token at ``i``. Returns the next index, or None for a positional."""
        if tok.startswith("--") or tok[0] != "-" or len(tok) == 2:
            name, eq, inline = tok.partition("=")
            hit = lookup(name)
            if hit is None:
                if ignore_unknown:
                    return None
                raise NoSuchOption(name, ctx)
            param, kind, value = hit
            if kind in ("flag", "count"):
                record(param, value)
                return i + 1
            return self._take_value(ctx, param, args, i + 1, tok, record, inline if eq else None)
        # Short option stack such as -abc.
        j = 1
        while j < len(tok):
            flag = "-" + tok[j]
            hit = lookup(flag)
            if hit is None:
                if ignore_unknown:
                    if j == 1:
                        return None
                    pos.append("-" + tok[j:])
                    return i + 1
                raise NoSuchOption(flag, ctx)
            param, kind, value = hit
            if kind in ("flag", "count"):
                record(param, value)
                j += 1
                continue
            rest = tok[j + 1 :]
            return self._take_value(ctx, param, args, i + 1, flag, record, rest or None)
        return i + 1

    def _take_value(self, ctx, param: Option, args, i, flag, record, inline):
        """Read the value tokens of a value option whose flag was at ``i - 1``."""
        need = param.nargs
        if inline is not None:
            tokens = [inline] + list(args[i : i + need - 1])
            record(param, tuple(tokens))
            return i + need - 1
        following = args[i : i + need]
        if param.flag_value is not None and (not following or _looks_like_option(following[0], ctx)):
            record(param, ())
            return i
        if len(following) < need:
            if param.prompt:
                record(param, ())
                return i
            raise UsageError(f"Option {flag!r} requires an argument.", ctx)
        record(param, tuple(following))
        return i + need

    # -- resolution -----------------------------------------------------

    def _resolve_params(self, ctx: Context, occ: dict[str, list], pos: list[str]) -> None:
        """Bind positional tokens to arguments, then resolve every parameter in order."""
        remaining = list(pos)
        arg_decls = [p for p in self.params if isinstance(p, Argument)]
        for idx, arg in enumerate(arg_decls):
            if arg.nargs == -1:
                later = sum(a.nargs for a in arg_decls[idx + 1 :] if a.nargs != -1)
                take = max(0, len(remaining) - later)
            else:
                if 0 < len(remaining) < arg.nargs:
                    raise UsageError(f"Argument {arg.name!r} takes {arg.nargs} values.", ctx)
                take = min(arg.nargs, len(remaining))
            tokens = remaining[:take]
            remaining = remaining[take:]
            occ[arg.name] = [tuple(tokens)] if tokens else []
        if remaining:
            if not ctx.get_setting("allow_extra_args"):
                raise UsageError(f"Got unexpected extra argument(s) ({' '.join(remaining)})", ctx)
            if not ctx.get_setting("ignore_unknown_options"):
                bad = next((r for r in remaining if r.startswith("-") and r != "-"), None)
                if bad is not None:
                    raise NoSuchOption(bad, ctx)
        eager_done = ctx.__dict__.get("_eager_done", set())
        for param in self.params:
            if param.is_eager and param.name in eager_done:
                continue
            value = param.resolve(ctx, occ.get(param.name, []))
            if param.expose_value and isinstance(param.type, File) and hasattr(value, "close"):
                ctx.call_on_close(value.close)
            del value

    def _callback_kwargs(self, ctx: Context) -> dict[str, t.Any]:
        return {p.name: ctx.params[p.name] for p in self.params if p.expose_value and p.name in ctx.params}

    def _run_callback(self, ctx: Context) -> t.Any:
        if self.callback is None:
            return None
        return self.callback(**self._callback_kwargs(ctx))

    def _emit_deprecation(self) -> None:
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else f"{self.name} is deprecated."
            termui.echo(f"DeprecationWarning: {note}", err=True)

    def _no_args_help(self, ctx: Context) -> None:
        if self.no_args_is_help and not ctx.args:
            termui.echo(self.get_help(ctx), err=True, nl=False)
            raise NoArgsIsHelpError(ctx)

    def make_context(self, info_name: str | None, args: t.Sequence[str], parent: Context | None = None, **extra: t.Any) -> Context:
        ctx = Context(self, parent=parent, info_name=info_name, **extra)
        ctx.args = list(args)
        return ctx

    def invoke(self, ctx: Context) -> t.Any:
        """Parse, resolve and run this leaf command in ``ctx``."""
        try:
            with ctx:
                self._no_args_help(ctx)
                occ, pos, _ = self._scan(ctx, ctx.args, stop_after=None)
                self._resolve_params(ctx, occ, pos)
                self._emit_deprecation()
                return self._run_callback(ctx)
        finally:
            ctx.close()

    def invoke_prepared(self, ctx: Context, values: dict) -> t.Any:
        """Run with explicitly supplied values; the others come from their defaults (FP-07)."""
        with ctx:
            ctx.params = {}
            for param in self.params:
                if param.name in values:
                    ctx.params[param.name] = values[param.name]
                else:
                    param.resolve(ctx, [])
            return self._run_callback(ctx)

    def main(
        self,
        args: t.Sequence[str] | None = None,
        prog_name: str | None = None,
        complete_var: str | None = None,
        standalone_mode: bool = True,
        **extra: t.Any,
    ) -> t.Any:
        """Run the command as a program (FP-01, FP-13)."""
        if args is None:
            args = sys.argv[1:]
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else "main"
        var = complete_var or complete_var_name(prog_name)
        instruction = os.environ.get(var)
        if instruction:
            rc = run_complete(self, prog_name, var, instruction)
            if standalone_mode:
                sys.exit(rc or 0)
            return None
        ctx = None
        try:
            if "default_map" not in extra:
                extra["default_map"] = self.context_settings.get("default_map")
            ctx = self.make_context(prog_name, list(args), standalone_mode=standalone_mode, **extra)
            rv = self.invoke(ctx)
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return None
        except UsageError as e:
            if not standalone_mode:
                raise
            termui.echo(e.format_message(), err=True)
            if e.ctx is not None and not isinstance(e, NoArgsIsHelpError):
                termui.echo(f"Try '{e.ctx.command_path} {e.ctx.command._help_name(e.ctx)}' for help.", err=True)
            sys.exit(e.exit_code)
        except OptlynError as e:
            if not standalone_mode:
                raise
            termui.echo(e.format_message(), err=True)
            sys.exit(e.exit_code)
        except (KeyboardInterrupt, EOFError):
            if not standalone_mode:
                raise Abort()
            termui.echo("Aborted!", err=True)
            sys.exit(1)
        if standalone_mode:
            sys.exit(0)
        return rv

    def _help_name(self, ctx: Context) -> str:
        return self._help_names(ctx)[0]

    # -- help -----------------------------------------------------------

    def get_short_help_str(self) -> str:
        if self.short_help:
            return self.short_help
        return first_sentence(self.help or "")

    def _usage_args(self) -> str:
        return " ".join(p.get_placeholder() for p in self.params if isinstance(p, Argument))

    def get_usage(self, ctx: Context) -> str:
        pieces = [ctx.command_path]
        if self.options_metavar:
            pieces.append(self.options_metavar)
        usage_args = self._usage_args()
        if usage_args:
            pieces.append(usage_args)
        return "Usage: " + " ".join(pieces)

    def _help_width(self, ctx: Context) -> int:
        explicit = ctx.get_setting("terminal_width")
        if explicit:
            return explicit
        max_width = ctx.get_setting("max_content_width") or 80
        return min(shutil.get_terminal_size((80, 24)).columns, max_width)

    def get_help(self, ctx: Context) -> str:
        width = self._help_width(ctx)
        fmt = HelpFormatter(width=width, max_width=width)
        fmt.write(self.get_usage(ctx))
        fmt.write()
        if self.deprecated:
            fmt.write("DEPRECATED" + (f": {self.deprecated}" if isinstance(self.deprecated, str) else ""))
            fmt.write()
        if self.help:
            fmt.write_text(self.help)
        self._write_sections(ctx, fmt)
        if self.epilog:
            fmt.write_text(self.epilog)
        return fmt.getvalue()

    def _write_sections(self, ctx: Context, fmt: HelpFormatter) -> None:
        arg_rows = [p.get_help_record(ctx) for p in self.params if isinstance(p, Argument) and not p.hidden]
        arg_rows = [r for r in arg_rows if r]
        if arg_rows:
            fmt.write_section("Positional arguments", arg_rows)
        opt_rows = [p.get_help_record(ctx) for p in self._all_options(ctx) if not p.hidden]
        if opt_rows:
            fmt.write_section("Options", opt_rows)

    def _complete(self, words: list[str], incomplete: str) -> list[CompletionItem]:
        return _complete_words(self, words, incomplete)


def _looks_like_option(token: str, ctx: Context) -> bool:
    return len(token) > 1 and token[0] == "-" and not _is_number(token)


def _is_number(token: str) -> bool:
    try:
        float(token)
        return True
    except ValueError:
        return False


def _make_help_option(names: list[str]) -> Option:
    def _show_help(ctx, param, value):
        if value:
            termui.echo(ctx.command.get_help(ctx), nl=False)
            raise Exit(0)
        return value

    return Option(
        names,
        is_flag=True,
        is_eager=True,
        expose_value=False,
        help="Show this message and exit.",
        callback=_show_help,
    )


class Group(Command):
    """A command that dispatches to named subcommands (FP-06, FP-10)."""

    def __init__(
        self,
        name: str | None = None,
        commands: t.Mapping[str, Command] | t.Iterable[Command] | None = None,
        invoke_without_command: bool = False,
        no_args_is_help: bool | None = None,
        subcommand_metavar: str | None = None,
        chain: bool = False,
        result_callback: t.Callable | None = None,
        **kwargs: t.Any,
    ) -> None:
        super().__init__(name, **kwargs)
        self.commands: dict[str, Command] = {}
        if isinstance(commands, dict):
            for key, cmd in commands.items():
                self.add_command(cmd, key)
        elif commands:
            for cmd in commands:
                self.add_command(cmd)
        self.invoke_without_command = invoke_without_command
        self.no_args_is_help = (not invoke_without_command) if no_args_is_help is None else no_args_is_help
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self.result_callback_func = result_callback

    # -- children -------------------------------------------------------

    def add_command(self, cmd: Command, name: str | None = None) -> None:
        if self.chain and isinstance(cmd, Group):
            raise DeclarationError("Groups cannot be nested under a chaining group.")
        key = name or cmd.name
        if not key:
            raise DeclarationError("A command needs a name.")
        self.commands[key] = cmd

    def command(self, *args: t.Any, **kwargs: t.Any):
        from .decorators import command as command_decorator

        def decorator(f):
            cmd = command_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args: t.Any, **kwargs: t.Any):
        from .decorators import group as group_decorator

        def decorator(f):
            cmd = group_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self):
        def decorator(f):
            self.result_callback_func = f
            return f

        return decorator

    def list_commands(self, ctx: Context) -> list[str]:
        return sorted(self.commands)

    def get_command(self, ctx: Context, cmd_name: str) -> Command | None:
        return self.commands.get(cmd_name)

    def _lookup(self, ctx: Context, name: str) -> Command | None:
        cmd = self.get_command(ctx, name)
        if cmd is not None:
            return cmd
        normf = ctx.get_setting("token_normalize_func")
        if normf is not None:
            for candidate in self.list_commands(ctx):
                if normf(candidate) == normf(name):
                    return self.get_command(ctx, candidate)
        return None

    def _visible_names(self, ctx: Context) -> list[str]:
        names = []
        for n in self.list_commands(ctx):
            cmd = self.get_command(ctx, n)
            if cmd is not None and not cmd.hidden:
                names.append(n)
        return names

    # -- help -----------------------------------------------------------

    def get_usage(self, ctx: Context) -> str:
        pieces = [ctx.command_path]
        if self.options_metavar:
            pieces.append(self.options_metavar)
        usage_args = self._usage_args()
        if usage_args:
            pieces.append(usage_args)
        meta = self.subcommand_metavar or "COMMAND [ARGS]..."
        if self.chain:
            meta = "COMMAND [ARGS]..."
        if self.invoke_without_command:
            meta = "[" + meta + "]"
        pieces.append(meta)
        return "Usage: " + " ".join(pieces)

    def _write_sections(self, ctx: Context, fmt: HelpFormatter) -> None:
        super()._write_sections(ctx, fmt)
        rows = []
        for n in self._visible_names(ctx):
            cmd = self.get_command(ctx, n)
            rows.append((n, cmd.get_short_help_str()))
        if rows:
            fmt.write_section("Commands", rows)

    # -- invocation -----------------------------------------------------

    def _group_stop_count(self) -> int | None:
        return self._fixed_arg_count()

    def invoke(self, ctx: Context) -> t.Any:
        try:
            with ctx:
                self._no_args_help(ctx)
                occ, pos, idx = self._scan(ctx, ctx.args, stop_after=self._group_stop_count(), group=True)
                rest = ctx.args[idx:]
                self._resolve_params(ctx, occ, pos)
                return self._dispatch(ctx, rest)
        finally:
            ctx.close()

    def _dispatch(self, ctx: Context, rest: list[str]) -> t.Any:
        if self.chain:
            return self._dispatch_chain(ctx, rest)
        if not rest:
            if not self.invoke_without_command:
                raise UsageError("Missing command.", ctx)
            ctx.invoked_subcommand = None
            rv = self._run_callback(ctx)
            return self._finish_single(ctx, rv)
        name = rest[0]
        cmd = self._lookup(ctx, name)
        if cmd is None:
            raise UnknownCommand(name, ctx)
        ctx.invoked_subcommand = name
        self._run_callback(ctx)
        sub = cmd.make_context(name, rest[1:], parent=ctx)
        return self._finish_single(ctx, cmd.invoke(sub))

    def _dispatch_chain(self, ctx: Context, rest: list[str]) -> t.Any:
        if not rest:
            if not self.invoke_without_command:
                raise UsageError("Missing command.", ctx)
            ctx.invoked_subcommand = None
            self._run_callback(ctx)
            return self._finish_chain(ctx, [])
        if self._lookup(ctx, rest[0]) is None:
            raise UnknownCommand(rest[0], ctx)
        ctx.invoked_subcommand = CHAIN
        self._run_callback(ctx)
        values: list = []
        tokens = list(rest)
        while tokens:
            name = tokens[0]
            cmd = self._lookup(ctx, name)
            if cmd is None:
                raise UnknownCommand(name, ctx)
            sub = cmd.make_context(name, tokens[1:], parent=ctx)
            try:
                with sub:
                    occ, pos, idx = cmd._scan(sub, sub.args, stop_after=cmd._fixed_arg_count(), chain=True)
                    sub.args = sub.args[idx:]
                    cmd._resolve_params(sub, occ, pos)
                    cmd._emit_deprecation()
                    values.append(cmd._run_callback(sub))
                tokens = list(sub.args)
            finally:
                sub.close()
        return self._finish_chain(ctx, values)

    def _finish_chain(self, ctx: Context, values: list) -> t.Any:
        if self.result_callback_func is not None:
            return self.result_callback_func(values, **self._callback_kwargs(ctx))
        return values

    def _finish_single(self, ctx: Context, rv: t.Any) -> t.Any:
        if self.result_callback_func is not None:
            return self.result_callback_func(rv, **self._callback_kwargs(ctx))
        return rv


class CommandCollection(Group):
    """A group presenting the union of subcommands from several source groups (FP-06)."""

    def __init__(self, name: str | None = None, sources: list[Group] | None = None, **kwargs: t.Any) -> None:
        super().__init__(name, **kwargs)
        self.sources: list[Group] = list(sources or [])

    def list_commands(self, ctx: Context) -> list[str]:
        names: set[str] = set()
        for src in self.sources:
            names.update(src.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx: Context, cmd_name: str) -> Command | None:
        for src in self.sources:
            cmd = src.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None


def _complete_words(cmd: Command, words: list[str], incomplete: str) -> list[CompletionItem]:
    """Suggestions for ``incomplete`` after ``words`` (FP-12)."""
    node: Command = cmd
    node_ctx = Context(cmd, info_name=cmd.name)
    for word in words:
        if isinstance(node, Group) and not word.startswith("-"):
            child = node._lookup(node_ctx, word)
            if child is not None:
                node_ctx = Context(child, parent=node_ctx, info_name=word)
                node = child
    last = words[-1] if words else ""
    if last.startswith("-") and "=" not in last and not incomplete.startswith("-"):
        hit = node._option_index(node_ctx).get(last)
        if hit is not None and hit[1] == "value":
            return [_as_completion(x) for x in hit[0].shell_complete(node_ctx, incomplete)]
    if incomplete.startswith("-"):
        out = []
        for p in node._all_options(node_ctx):
            if p.hidden:
                continue
            for flag in p.opts + p.secondary_opts:
                if flag.startswith(incomplete):
                    out.append(CompletionItem(flag, p.help))
        return out
    if isinstance(node, Group):
        out = []
        for name in node._visible_names(node_ctx):
            if name.startswith(incomplete):
                child = node.get_command(node_ctx, name)
                out.append(CompletionItem(name, child.get_short_help_str() if child else None))
        return out
    for arg in node.params:
        if isinstance(arg, Argument) and not arg.hidden:
            return [_as_completion(x) for x in arg.shell_complete(node_ctx, incomplete)]
    return []


def _as_completion(item) -> CompletionItem:
    if isinstance(item, CompletionItem):
        return item
    return CompletionItem(str(item))
