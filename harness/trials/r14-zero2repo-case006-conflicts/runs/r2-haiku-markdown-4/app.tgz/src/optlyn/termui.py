"""Terminal helpers: echo, styling, prompts, pager, progress, files (FP-11, FP-08, FP-09)."""

from __future__ import annotations

import contextlib
import os
import re
import subprocess
import sys
import tempfile
import time

from .exceptions import Abort

_ANSI_RE = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")

_COLORS = {
    "black": 30,
    "red": 31,
    "green": 32,
    "yellow": 33,
    "blue": 34,
    "magenta": 35,
    "cyan": 36,
    "white": 37,
    "reset": 39,
    "bright_black": 90,
    "bright_red": 91,
    "bright_green": 92,
    "bright_yellow": 93,
    "bright_blue": 94,
    "bright_magenta": 95,
    "bright_cyan": 96,
    "bright_white": 97,
}

_STYLE_CODES = {
    "bold": (1, 22),
    "dim": (2, 22),
    "italic": (3, 23),
    "underline": (4, 24),
    "overline": (53, 55),
    "blink": (5, 25),
    "reverse": (7, 27),
    "strikethrough": (9, 29),
}


def _color_code(color, base: int) -> str:
    """Return the SGR parameter for a color, base 38 (fg) or 48 (bg)."""
    if isinstance(color, str):
        if color not in _COLORS:
            raise TypeError(f"Unknown color {color!r}.")
        code = _COLORS[color]
        if base == 48:
            code += 10
        return str(code)
    if isinstance(color, int) and not isinstance(color, bool):
        if not 0 <= color <= 255:
            raise TypeError(f"Color {color} is out of range 0-255.")
        return f"{base};5;{color}"
    if isinstance(color, (tuple, list)) and len(color) == 3 and all(
        isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
    ):
        return f"{base};2;{color[0]};{color[1]};{color[2]}"
    raise TypeError(f"Invalid color {color!r}.")


def style(
    text,
    fg=None,
    bg=None,
    bold=None,
    dim=None,
    underline=None,
    overline=None,
    italic=None,
    blink=None,
    reverse=None,
    strikethrough=None,
    reset: bool = True,
) -> str:
    """Wrap ``text`` in ANSI SGR sequences."""
    if not isinstance(text, str):
        text = str(text)
    bits: list[str] = []
    if fg is not None:
        bits.append(_color_code(fg, 38))
    if bg is not None:
        bits.append(_color_code(bg, 48))
    switches = {
        "bold": bold,
        "dim": dim,
        "underline": underline,
        "overline": overline,
        "italic": italic,
        "blink": blink,
        "reverse": reverse,
        "strikethrough": strikethrough,
    }
    for key, on in switches.items():
        if on is not None:
            on_code, _ = _STYLE_CODES[key]
            bits.append(str(on_code) if on else str(_STYLE_CODES[key][1]))
    if not bits:
        return text
    prefix = "\033[" + ";".join(bits) + "m"
    suffix = "\033[0m" if reset else ""
    return prefix + text + suffix


def unstyle(text: str) -> str:
    """Remove ANSI escape sequences from ``text``."""
    return _ANSI_RE.sub("", text)


def _current_color_flag():
    from .context import get_current_context

    ctx = get_current_context(silent=True)
    if ctx is None:
        return None
    return ctx.color


def _is_tty(stream) -> bool:
    try:
        return bool(stream.isatty())
    except Exception:
        return False


def _should_strip(file, color) -> bool:
    if color is None:
        color = _current_color_flag()
    if color is True:
        return False
    if color is False:
        return True
    return not _is_tty(file)


def _write_text(file, text: str) -> None:
    try:
        file.write(text)
    except UnicodeEncodeError:
        # Misconfigured (ASCII-only) stream: fall back to UTF-8 bytes (FP-11).
        buf = getattr(file, "buffer", None)
        if buf is not None:
            file.flush()
            buf.write(text.encode("utf-8"))
            buf.flush()
        else:
            file.write(text.encode("utf-8", "replace").decode("ascii", "replace"))
    if hasattr(file, "flush"):
        file.flush()


def echo(
    message=None,
    file=None,
    nl: bool = True,
    err: bool = False,
    color=None,
) -> None:
    """Write text or bytes to stdout (or stderr when ``err`` is true)."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        buf = getattr(file, "buffer", None)
        if buf is not None:
            file.flush()
            buf.write(message)
            if nl:
                buf.write(b"\n")
            buf.flush()
        else:
            file.write(message.decode("utf-8", "replace") + ("\n" if nl else ""))
        return
    text = str(message)
    if _should_strip(file, color):
        text = unstyle(text)
    if nl:
        text += "\n"
    _write_text(file, text)


def secho(message=None, file=None, nl: bool = True, err: bool = False, color=None, **styles) -> None:
    if message is not None:
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


def _pager_command() -> str | None:
    return os.environ.get("PAGER") or None


def echo_via_pager(text_or_generator, color=None) -> None:
    """Write long text through the pager when interactive (FP-11)."""
    if callable(text_or_generator) and not isinstance(text_or_generator, str):
        chunks = text_or_generator()
    else:
        chunks = text_or_generator
    if isinstance(chunks, str):
        chunks = [chunks]
    interactive = _is_tty(sys.stdin) or _is_tty(sys.stdout)
    cmd = _pager_command()
    if not (interactive and cmd and _is_tty(sys.stdout)):
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, text=True)
    try:
        for chunk in chunks:
            if _should_strip(proc.stdin, color):
                chunk = unstyle(chunk)
            proc.stdin.write(chunk)
            proc.stdin.flush()
    except BrokenPipeError:
        pass
    finally:
        with contextlib.suppress(BrokenPipeError):
            proc.stdin.close()
        proc.wait()


@contextlib.contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream that goes through the pager (or stdout)."""
    buf: list[str] = []

    class _Sink:
        def write(self, s):
            buf.append(s)
            return len(s)

        def flush(self):
            pass

    yield _Sink()
    echo_via_pager(lambda: iter(buf), color=color)


class ProgressBar:
    """A minimal progress bar. Iterates the wrapped items in order (FP-11)."""

    def __init__(self, iterable, length, label, hidden, file=None):
        self.iterable = iterable
        self.length = length
        if self.length is None and iterable is not None:
            try:
                self.length = len(iterable)
            except TypeError:
                self.length = None
        self.label = label
        self.hidden = hidden or not _is_tty(file or sys.stdout)
        self.file = file or sys.stdout
        self.pos = 0
        self.start = time.time()
        if label and not hidden and not _is_tty(self.file):
            self.file.write(f"{label}\n")

    def _render(self):
        if self.hidden or self.length is None:
            return
        width = 30
        frac = min(self.pos / self.length, 1.0) if self.length else 1.0
        filled = int(width * frac)
        bar = "#" * filled + "-" * (width - filled)
        elapsed = time.time() - self.start
        eta = ""
        if self.pos:
            remaining = elapsed / self.pos * (self.length - self.pos)
            eta = f" eta {int(remaining)}s"
        label = f"{self.label} " if self.label else ""
        self.file.write(f"\r{label}[{bar}] {self.pos}/{self.length}{eta}")
        self.file.flush()

    def update(self, n_steps: int = 1) -> None:
        self.pos += n_steps
        self._render()

    def __iter__(self):
        if self.iterable is None:
            return
        for item in self.iterable:
            yield item
            self.update(1)
        if not self.hidden and _is_tty(self.file):
            self.file.write("\n")


@contextlib.contextmanager
def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    bar = ProgressBar(iterable, length, label, hidden)
    try:
        yield bar
    finally:
        if not bar.hidden and _is_tty(bar.file):
            bar.file.write("\n")
            bar.file.flush()


def _read_line(prompt_text: str, hide_input: bool) -> str:
    from_runner = getattr(sys.stdin, "_optlyn_runner", False)
    if hide_input and not from_runner:
        import getpass

        try:
            return getpass.getpass(prompt_text, stream=sys.stdout)
        except EOFError:
            raise Abort()
    sys.stdout.write(prompt_text)
    sys.stdout.flush()
    line = sys.stdin.readline()
    if line == "":
        sys.stdout.write("\n")
        raise Abort()
    if from_runner and not hide_input and not sys.stdin.echo_on_read:
        # Visible prompts echo the typed line into captured output (FP-14).
        sys.stdout.write(line)
    return line.rstrip("\r\n")


def prompt(
    text: str,
    default=None,
    hide_input: bool = False,
    confirmation_prompt: bool = False,
    type=None,
    value_proc=None,
    prompt_suffix: str = ": ",
    show_default: bool = True,
    err: bool = False,
    show_choices: bool = True,
):
    """Ask for a value, converting it with ``type`` (FP-08)."""
    from .paramtypes import convert_type

    ty = convert_type(type, default)
    suffix = ""
    if default is not None and show_default:
        shown = default() if callable(default) else default
        suffix = f" [{shown}]"
    while True:
        value = _read_line(f"{text}{suffix}{prompt_suffix}", hide_input)
        if value == "" and default is not None:
            value = default() if callable(default) else default
            return value if not isinstance(value, str) else ty.convert(value)
        if confirmation_prompt:
            again = _read_line(f"Repeat for confirmation{prompt_suffix}", hide_input)
            if again != value:
                echo("Error: the two entered values do not match", err=True)
                continue
        try:
            return ty.convert(value) if not value_proc else value_proc(value)
        except Exception as e:
            from .exceptions import BadParameter

            if isinstance(e, BadParameter):
                echo(f"Error: {e.message}", err=True)
                continue
            raise


def confirm(text: str, default: bool = False, abort: bool = False, prompt_suffix: str = ": ", show_default: bool = True, err: bool = False) -> bool:
    """Ask a yes/no question (FP-08). ``abort`` raises Abort on no."""
    suffix = " [Y/n]" if default else " [y/N]" if show_default else ""
    while True:
        value = _read_line(f"{text}{suffix}{prompt_suffix}", False).strip().lower()
        if value == "":
            result = default
            break
        if value in ("y", "yes"):
            result = True
            break
        if value in ("n", "no"):
            result = False
            break
        echo("Error: invalid input", err=True)
    if abort and not result:
        raise Abort()
    return result


def getchar(echo: bool = False) -> str:
    """Read one character from the terminal (FP-11)."""
    try:
        import termios
        import tty
    except ImportError:
        ch = sys.stdin.read(1)
        if ch == "":
            raise EOFError()
        return ch
    fd = None
    try:
        fd = os.open("/dev/tty", os.O_RDONLY)
    except OSError:
        fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        ch = os.read(fd, 1).decode("utf-8", "replace")
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)
        if fd != sys.stdin.fileno():
            os.close(fd)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04" or ch == "":
        raise EOFError()
    if echo:
        sys.stdout.write(ch)
        sys.stdout.flush()
    return ch


def pause(info: str | None = None, err: bool = False) -> None:
    """Wait for a key when interactive; do nothing otherwise (FP-11)."""
    if not (_is_tty(sys.stdin) and _is_tty(sys.stdout)):
        return
    if info is None:
        info = "Press any key to continue..."
    echo(info, err=err, nl=False)
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass
    echo("", err=err)


def edit(
    text=None,
    editor=None,
    env=None,
    require_save: bool = True,
    extension: str = ".txt",
    filename=None,
):
    """Open an editor and return the saved text, or None (FP-11)."""
    editor_cmd = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR") or (
        "notepad" if os.name == "nt" else "vi"
    )
    if filename is not None:
        subprocess.call(editor_cmd.split() + [str(filename)], env=env)
        return None
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            if text:
                f.write(text)
        mtime = os.path.getmtime(path)
        subprocess.call(editor_cmd.split() + [path], env=env)
        with open(path, encoding="utf-8") as f:
            result = f.read()
        if require_save and os.path.getmtime(path) == mtime:
            return None
        return result
    finally:
        os.unlink(path)


def launch(url: str, wait: bool = False, locate: bool = False) -> int:
    """Open a URL or file with the default application (FP-11)."""
    if sys.platform == "darwin":
        args = ["open"]
    elif sys.platform == "win32":
        os.startfile(url)  # type: ignore[attr-defined]
        return 0
    else:
        args = ["xdg-open"]
    if locate and sys.platform == "darwin":
        args.append("-R")
    args.append(url)
    proc = subprocess.Popen(args)
    if wait:
        return proc.wait()
    return 0


def clear() -> None:
    """Clear the terminal when connected to one (FP-11)."""
    if not _is_tty(sys.stdout):
        return
    sys.stdout.write("\033[2J\033[1;1H")
    sys.stdout.flush()


def get_app_dir(app_name: str, roaming: bool = True, force_posix: bool = False) -> str:
    """Per-user config directory for ``app_name`` (FP-11)."""
    if sys.platform == "darwin" and not force_posix:
        return os.path.join(os.path.expanduser("~"), "Library", "Application Support", app_name)
    if sys.platform == "win32" and not force_posix:
        base = os.environ.get("APPDATA") or os.path.expanduser("~")
        return os.path.join(base, app_name)
    if force_posix:
        return os.path.join(os.path.expanduser("~"), "." + re.sub(r"\s+", "-", app_name.lower()))
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
    return os.path.join(base, re.sub(r"\s+", "-", app_name.lower()))


def format_filename(filename, shorten: bool = False) -> str:
    """Printable text for a filename (FP-09)."""
    if isinstance(filename, bytes):
        text = os.fsdecode(filename)
    else:
        text = os.fspath(filename)
    text = text.encode("utf-8", "surrogateescape").decode("utf-8", "backslashreplace")
    if shorten:
        text = os.path.basename(text)
    return text


def open_file(
    filename,
    mode: str = "r",
    encoding: str | None = None,
    errors: str = "strict",
    lazy: bool = False,
    atomic: bool = False,
):
    """Open a file or a standard stream; ``-`` is stdin or stdout (FP-09)."""
    binary = "b" in mode
    writing = "w" in mode
    if filename == "-":
        if writing:
            stream = sys.stdout.buffer if binary else sys.stdout
        else:
            stream = sys.stdin.buffer if binary else sys.stdin
        return _NonClosing(stream)
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    if atomic and writing:
        return AtomicFile(filename, mode, encoding, errors)
    if binary:
        return open(filename, mode)
    return open(filename, mode, encoding=encoding, errors=errors)


class _NonClosing:
    """Wrap a standard stream so that leaving the block does not close it."""

    def __init__(self, stream):
        self._stream = stream

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __enter__(self):
        return self

    def close(self):
        # Standard streams stay open when the block ends (FP-09).
        self._stream.flush()

    def __exit__(self, *exc):
        self.close()
        return False

    def __iter__(self):
        return iter(self._stream)


class LazyFile:
    """Opens its real file on first I/O (FP-09)."""

    def __init__(self, filename, mode, encoding, errors, atomic=False):
        self.filename = filename
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None

    def _open(self):
        if self._f is None:
            try:
                if self.atomic and "w" in self.mode:
                    self._f = AtomicFile(self.filename, self.mode, self.encoding, self.errors)
                elif "b" in self.mode:
                    self._f = open(self.filename, self.mode)
                else:
                    self._f = open(self.filename, self.mode, encoding=self.encoding, errors=self.errors)
            except OSError as e:
                from .exceptions import FileError

                raise FileError(self.filename, e.strerror or str(e))
        return self._f

    def __getattr__(self, name):
        return getattr(self._open(), name)

    def __iter__(self):
        return iter(self._open())

    def close(self):
        if self._f is not None:
            self._f.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False


class AtomicFile:
    """Writes to a sibling temp file and replaces the target on close (FP-09)."""

    def __init__(self, filename, mode, encoding=None, errors="strict"):
        self._target = filename
        directory = os.path.dirname(os.path.abspath(filename))
        fd, self._tmp = tempfile.mkstemp(dir=directory)
        os.close(fd)
        self._f = open(self._tmp, mode, encoding=None if "b" in mode else encoding, errors=None if "b" in mode else errors)

    def __getattr__(self, name):
        return getattr(self._f, name)

    def close(self):
        if self._f.closed:
            return
        self._f.close()
        os.replace(self._tmp, self._target)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False
