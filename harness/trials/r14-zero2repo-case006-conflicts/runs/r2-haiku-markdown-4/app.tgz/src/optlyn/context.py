"""Invocation context (FP-07)."""

from __future__ import annotations

import contextlib
import enum
import threading
import typing as t

from .exceptions import Abort, Exit

if t.TYPE_CHECKING:  # pragma: no cover
    from .core import Command


class ParameterSource(enum.Enum):
    """Where a parameter value came from, most explicit first."""

    PROMPT = "prompt"
    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"


_local = threading.local()


def _stack() -> list:
    stack = getattr(_local, "stack", None)
    if stack is None:
        stack = _local.stack = []
    return stack


def get_current_context(silent: bool = False):
    """Return the context current on this thread (FP-07)."""
    stack = _stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")


# Keys that a context inherits from its parent unless overridden.
_SETTING_KEYS = (
    "auto_envvar_prefix",
    "terminal_width",
    "max_content_width",
    "help_option_names",
    "token_normalize_func",
    "color",
    "show_default",
    "allow_extra_args",
    "ignore_unknown_options",
    "allow_interspersed_args",
)

_DEFAULTS: dict[str, t.Any] = {
    "auto_envvar_prefix": None,
    "terminal_width": None,
    "max_content_width": 80,
    "help_option_names": ["--help"],
    "token_normalize_func": None,
    "color": None,
    "show_default": False,
    "allow_extra_args": False,
    "ignore_unknown_options": False,
    "allow_interspersed_args": True,
}


class Context:
    """State for one invocation of one command (FP-07)."""

    def __init__(
        self,
        command: Command,
        parent: Context | None = None,
        info_name: str | None = None,
        obj: t.Any = None,
        default_map: dict | None = None,
        standalone_mode: bool = True,
        **settings: t.Any,
    ) -> None:
        self.command = command
        self.parent = parent
        self.info_name = info_name
        self.params: dict[str, t.Any] = {}
        self.args: list[str] = []
        self.invoked_subcommand: t.Any = None
        self.standalone_mode = standalone_mode
        self._sources: dict[str, ParameterSource] = {}
        self._exit_stack = contextlib.ExitStack()

        if parent is not None:
            self._settings = {k: parent._settings.get(k, _DEFAULTS.get(k)) for k in _SETTING_KEYS}
            if obj is None:
                obj = parent.obj
            if default_map is None and isinstance(parent.default_map, dict) and info_name:
                nested = parent.default_map.get(info_name)
                if isinstance(nested, dict):
                    default_map = nested
        else:
            self._settings = dict(_DEFAULTS)
        self._settings.update(getattr(command, "context_settings", {}) or {})
        for key, value in settings.items():
            if key in _SETTING_KEYS:
                self._settings[key] = value
        if parent is None and default_map is None:
            default_map = self._settings.get("default_map")
        self.default_map = default_map
        self.obj = obj
        # Keys in ``settings`` that are not recognised settings are kept as extras.
        self.extra = {k: v for k, v in settings.items() if k not in _SETTING_KEYS}

    # -- settings -------------------------------------------------------

    def __getattr__(self, name: str) -> t.Any:
        settings = self.__dict__.get("_settings")
        if settings is not None and name in settings:
            return settings[name]
        raise AttributeError(name)

    def get_setting(self, key: str, default: t.Any = None) -> t.Any:
        return self._settings.get(key, default)

    @property
    def command_path(self) -> str:
        names = []
        ctx: Context | None = self
        while ctx is not None:
            if ctx.info_name:
                names.append(ctx.info_name)
            ctx = ctx.parent
        return " ".join(reversed(names))

    @property
    def root(self) -> Context:
        ctx = self
        while ctx.parent is not None:
            ctx = ctx.parent
        return ctx

    @property
    def envvar_path(self) -> list[str]:
        """Names of subcommands on the path below the top-level command."""
        names = []
        ctx: Context | None = self
        while ctx is not None and ctx.parent is not None:
            names.append(ctx.info_name or ctx.command.name)
            ctx = ctx.parent
        return list(reversed(names))

    # -- sources --------------------------------------------------------

    def get_parameter_source(self, name: str) -> ParameterSource | None:
        declared = {p.name for p in self.command.params}
        if name not in declared:
            return None
        return self._sources.get(name)

    def _set_source(self, name: str, source: ParameterSource) -> None:
        self._sources[name] = source

    # -- resources, exit, abort ----------------------------------------

    def with_resource(self, cm: t.ContextManager) -> t.Any:
        return self._exit_stack.enter_context(cm)

    def call_on_close(self, f: t.Callable[[], t.Any]) -> None:
        self._exit_stack.callback(f)

    def close(self) -> None:
        self._exit_stack.close()

    def exit(self, code: int = 0) -> t.NoReturn:
        raise Exit(code)

    def abort(self) -> t.NoReturn:
        raise Abort()

    # -- invoking other commands ----------------------------------------

    def invoke(self, other: t.Any, **kwargs: t.Any) -> t.Any:
        """Run ``other`` with exactly the caller's chosen values (FP-07)."""
        from .core import Command

        cmd = other if isinstance(other, Command) else other.command
        sub = cmd.make_context(cmd.name, [], parent=self, standalone_mode=False)
        try:
            return cmd.invoke_prepared(sub, kwargs)
        finally:
            sub.close()

    def forward(self, other: t.Any, **kwargs: t.Any) -> t.Any:
        """Run ``other`` filling in this command's current parameters (FP-07)."""
        merged = dict(self.params)
        merged.update(kwargs)
        return self.invoke(other, **merged)

    # -- thread-local current context ----------------------------------

    def __enter__(self) -> Context:
        _stack().append(self)
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        stack = _stack()
        if stack and stack[-1] is self:
            stack.pop()
        else:  # pragma: no cover - defensive
            with contextlib.suppress(ValueError):
                stack.remove(self)
