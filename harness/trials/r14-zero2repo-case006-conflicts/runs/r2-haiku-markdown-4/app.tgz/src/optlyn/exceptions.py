"""Exception classes used by Optlyn.

Exit-status classes (see the interface contract, section 2):

* ``0`` success, intentional help or version, clean stop
* ``1`` abort, or a general error that is not a usage error
* ``2`` usage error
"""

from __future__ import annotations

import typing as t

if t.TYPE_CHECKING:  # pragma: no cover
    from .core import Context, Parameter


class OptlynError(Exception):
    """Base class for all Optlyn exceptions.

    Carries the process exit status that standalone mode uses.
    """

    exit_code: int = 1

    def __init__(self, message: str = "") -> None:
        super().__init__(message)
        self.message = message

    def show(self, file: t.Any = None) -> None:
        from .termui import echo

        echo(self.format_message(), file=file, err=True)

    def format_message(self) -> str:
        return self.message


class UsageError(OptlynError):
    """Incorrect usage of a command line. Exit status 2."""

    exit_code = 2

    def __init__(
        self,
        message: str,
        ctx: Context | None = None,
    ) -> None:
        super().__init__(message)
        self.ctx = ctx
        self.cmd = ctx.command if ctx is not None else None

    def format_message(self) -> str:
        prog = ""
        if self.ctx is not None and self.ctx.command_path:
            prog = f"{self.ctx.command_path}: "
        return f"{prog}Error: {self.message}"


class BadParameter(UsageError):
    """A value was refused for a parameter. Exit status 2.

    ``param_hint`` names the parameter in the report. The default report
    identifies the parameter by its declared name.
    """

    def __init__(
        self,
        message: str,
        ctx: Context | None = None,
        param: Parameter | None = None,
        param_hint: str | None = None,
    ) -> None:
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self) -> str:
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.describe()
        prog = ""
        if self.ctx is not None and self.ctx.command_path:
            prog = f"{self.ctx.command_path}: "
        if hint:
            return f"{prog}Invalid value for {hint}: {self.message}"
        return f"{prog}Invalid value: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter was not supplied."""

    def __init__(
        self,
        message: str | None = None,
        ctx: Context | None = None,
        param: Parameter | None = None,
        param_hint: str | None = None,
    ) -> None:
        super().__init__(message or "", ctx, param, param_hint)

    def format_message(self) -> str:
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.describe()
        kind = getattr(self.param, "param_type_name", "parameter")
        prog = ""
        if self.ctx is not None and self.ctx.command_path:
            prog = f"{self.ctx.command_path}: "
        return f"{prog}Missing {kind} {hint or ''}".rstrip() + "."


class NoSuchOption(UsageError):
    """An unknown option was given."""

    def __init__(self, option_name: str, ctx: Context | None = None) -> None:
        super().__init__(f"No such option: {option_name}", ctx)
        self.option_name = option_name


class UnknownCommand(UsageError):
    """An unknown subcommand name was given."""

    def __init__(self, name: str, ctx: Context | None = None) -> None:
        super().__init__(f"No such command {name!r}", ctx)
        self.name = name


class NoArgsIsHelpError(UsageError):
    """Shown help because the invocation was incomplete.

    The help page is printed by the caller; this exception only carries
    the usage-error exit status.
    """

    def __init__(self, ctx: Context) -> None:
        super().__init__("Missing command.", ctx)


class Abort(OptlynError):
    """Abort the program. Exit status 1."""

    exit_code = 1

    def __init__(self, message: str = "Aborted!") -> None:
        super().__init__(message)

    def format_message(self) -> str:
        return self.message


class Exit(RuntimeError):
    """An author clean stop with a status code."""

    def __init__(self, code: int = 0) -> None:
        super().__init__(code)
        self.exit_code = code


class FileError(OptlynError):
    """A file could not be opened during I/O. General error, exit status 1."""

    exit_code = 1

    def __init__(self, filename: str, message: str) -> None:
        super().__init__(f"Could not open file {filename!r}: {message}")
        self.filename = filename


class DeprecationRefused(RuntimeError):
    """A declaration combination that the PRD refuses."""


class DeclarationError(TypeError):
    """An invalid declaration (raised when a decorator is applied)."""
