"""Declaration decorators and ready-made options (FP-01, FP-02, FP-03, FP-07, FP-08)."""

from __future__ import annotations

import functools
import importlib.metadata
import inspect
import typing as t

from . import termui
from .context import Context, get_current_context
from .core import Command, CommandCollection, Group
from .exceptions import Exit
from .params import Argument, Option, Parameter

_SUFFIXES = ("_command", "_cmd", "_group", "_grp")


def _attach_param(f: t.Callable, param: Parameter) -> t.Callable:
    if not hasattr(f, "__optlyn_params__"):
        f.__optlyn_params__ = []  # type: ignore[attr-defined]
    f.__optlyn_params__.append(param)  # type: ignore[attr-defined]
    return f


def _pop_params(f: t.Callable) -> list[Parameter]:
    params = list(getattr(f, "__optlyn_params__", []))
    params.reverse()
    if hasattr(f, "__optlyn_params__"):
        del f.__optlyn_params__  # type: ignore[attr-defined]
    return params


def _derive_name(func_name: str) -> str:
    name = func_name.lower()
    for suffix in _SUFFIXES:
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def _doc_help(f: t.Callable) -> str | None:
    doc = inspect.getdoc(f)
    if not doc:
        return None
    return doc.split("\f", 1)[0].rstrip()


def _decorator_name(name, f) -> tuple[str | None, t.Callable | None]:
    """Support both ``@command`` and ``@command()`` forms."""
    if callable(name) and not isinstance(name, str):
        return None, name
    return name, None


def command(name: t.Any = None, cls: type | None = None, **attrs: t.Any):
    """Turn a function into a command (FP-01)."""
    name, bare = _decorator_name(name, None)
    klass = cls or Command

    def decorator(f: t.Callable) -> Command:
        cmd_name = name if name is not None else _derive_name(f.__name__)
        help_text = attrs.pop("help", None) or _doc_help(f)
        params = _pop_params(f)
        return klass(name=cmd_name, callback=f, params=params, help=help_text, **attrs)

    if bare is not None:
        return decorator(bare)
    return decorator


def group(name: t.Any = None, cls: type | None = None, **attrs: t.Any):
    """Turn a function into a group (FP-06)."""
    name, bare = _decorator_name(name, None)
    klass = cls or Group

    def decorator(f: t.Callable) -> Group:
        grp_name = name if name is not None else _derive_name(f.__name__)
        help_text = attrs.pop("help", None) or _doc_help(f)
        params = _pop_params(f)
        if issubclass(klass, CommandCollection):
            sources = attrs.pop("sources", None)
            return klass(name=grp_name, callback=f, params=params, help=help_text, sources=sources, **attrs)
        return klass(name=grp_name, callback=f, params=params, help=help_text, **attrs)

    if bare is not None:
        return decorator(bare)
    return decorator


def option(*param_decls: str, cls: type | None = None, **attrs: t.Any):
    """Attach an option to the function it decorates (FP-03)."""
    klass = cls or Option

    def decorator(f: t.Callable) -> t.Callable:
        return _attach_param(f, klass(list(param_decls), **attrs))

    return decorator


def argument(*param_decls: str, cls: type | None = None, **attrs: t.Any):
    """Attach a positional argument to the function it decorates (FP-04)."""
    klass = cls or Argument

    def decorator(f: t.Callable) -> t.Callable:
        return _attach_param(f, klass(list(param_decls), **attrs))

    return decorator


def help_option(*param_decls: str, **kwargs: t.Any):
    """An extra eager help flag that prints help and exits (FP-02)."""
    decls = list(param_decls) or ["--help"]

    def callback(ctx, param, value):
        if value:
            termui.echo(ctx.command.get_help(ctx), nl=False)
            raise Exit(0)
        return value

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", callback)

    def decorator(f: t.Callable) -> t.Callable:
        return _attach_param(f, Option(decls, **kwargs))

    return decorator


def version_option(
    version: str | None = None,
    *param_decls: str,
    package_name: str | None = None,
    prog_name: str | None = None,
    message: str | None = None,
    **kwargs: t.Any,
):
    """An eager version flag (FP-02)."""
    decls = list(param_decls) or ["--version"]

    def _detect() -> str:
        if version is not None:
            return version
        if package_name is None:
            raise RuntimeError("Could not determine the version; pass version or package_name.")
        try:
            return importlib.metadata.version(package_name)
        except importlib.metadata.PackageNotFoundError:
            pass
        # Treat the name as an import name and use the distribution providing it.
        providers = importlib.metadata.packages_distributions().get(package_name, [])
        if not providers:
            raise RuntimeError(f"{package_name!r} is not an installed distribution or import.")
        return importlib.metadata.version(providers[0])

    def callback(ctx, param, value):
        if not value:
            return value
        ident = _detect()
        prog = prog_name or ctx.root.info_name or ctx.command.name
        text = message % {"prog": prog, "package": package_name, "version": ident} if message else f"{prog}, version {ident}"
        termui.echo(text)
        raise Exit(0)

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs.setdefault("callback", callback)

    def decorator(f: t.Callable) -> t.Callable:
        return _attach_param(f, Option(decls, **kwargs))

    return decorator


def custom_version_option(callback_fn: t.Callable[[Context], str], *param_decls: str, **kwargs: t.Any):
    """An eager version flag whose identity is the callback's string (FP-02)."""
    decls = list(param_decls) or ["--version"]

    def callback(ctx, param, value):
        if not value:
            return value
        termui.echo(callback_fn(ctx))
        raise Exit(0)

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback

    def decorator(f: t.Callable) -> t.Callable:
        return _attach_param(f, Option(decls, **kwargs))

    return decorator


def password_option(*param_decls: str, **kwargs: t.Any):
    """A hidden, prompting, confirmed option (FP-08)."""
    decls = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("help", "The password to use.")

    def decorator(f: t.Callable) -> t.Callable:
        return _attach_param(f, Option(decls, **kwargs))

    return decorator


def confirmation_option(*param_decls: str, **kwargs: t.Any):
    """A confirmation flag that asks when omitted and aborts when declined (FP-08)."""
    decls = list(param_decls) or ["--yes"]
    question = kwargs.pop("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")

    def callback(ctx, param, value):
        if not value:
            termui.confirm(question, abort=True)
        return value

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs["callback"] = callback

    def decorator(f: t.Callable) -> t.Callable:
        return _attach_param(f, Option(decls, **kwargs))

    return decorator


def pass_context(f: t.Callable) -> t.Callable:
    """Pass the current :class:`Context` as the first argument (FP-07)."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(f: t.Callable) -> t.Callable:
    """Pass the current context's ``obj`` as the first argument (FP-07)."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type: type, ensure: bool = False):
    """Pass the nearest context object of ``object_type`` (FP-07)."""

    def decorator(f: t.Callable) -> t.Callable:
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            node: Context | None = ctx
            found = None
            while node is not None:
                if isinstance(node.obj, object_type):
                    found = node.obj
                    break
                node = node.parent
            if found is None:
                if not ensure:
                    raise RuntimeError(f"Managed to invoke callback without a context object of type {object_type.__name__!r} existing.")
                found = object_type()
                ctx.obj = found
            return f(found, *args, **kwargs)

        return new_func

    return decorator
