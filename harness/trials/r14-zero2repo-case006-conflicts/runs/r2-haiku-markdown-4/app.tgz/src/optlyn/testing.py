"""In-process runner for commands (FP-14)."""

from __future__ import annotations

import contextlib
import io
import os
import shutil
import sys
import tempfile
import typing as t


class _Capture(io.TextIOBase):
    """Text stream that records writes to a shared, ordered transcript."""

    def __init__(self, transcript: list[tuple[str, str]], name: str, charset: str) -> None:
        self._transcript = transcript
        self._name = name
        self._charset = charset
        self.chunks: list[str] = []

    def write(self, s: str) -> int:
        self.chunks.append(s)
        self._transcript.append((self._name, s))
        return len(s)

    def writable(self) -> bool:
        return True

    def isatty(self) -> bool:
        return False

    @property
    def encoding(self) -> str:
        return self._charset

    def getvalue(self) -> str:
        return "".join(self.chunks)


class _RunnerStdin(io.TextIOBase):
    """Stdin that feeds the runner input and optionally echoes what was read."""

    _optlyn_runner = True

    def __init__(self, data: str, transcript: list, echo_on_read: bool) -> None:
        self._buf = io.StringIO(data)
        self._transcript = transcript
        self.echo_on_read = echo_on_read

    def readline(self, size: int = -1) -> str:
        line = self._buf.readline(size)
        if self.echo_on_read and line:
            self._transcript.append(("stdout", line))
        return line

    def read(self, size: int = -1) -> str:
        data = self._buf.read(size)
        if self.echo_on_read and data:
            self._transcript.append(("stdout", data))
        return data

    def __iter__(self):
        return iter(self.readline, "")

    def isatty(self) -> bool:
        return False

    def fileno(self) -> int:
        raise io.UnsupportedOperation("fileno")


class Result:
    """The outcome of :meth:`CliRunner.invoke`."""

    def __init__(
        self,
        runner: CliRunner,
        stdout: str,
        stderr: str,
        output: str,
        exit_code: int,
        exception: BaseException | None,
    ) -> None:
        self.runner = runner
        self.exit_code = exit_code
        self.exception = exception
        self.stdout = stdout
        self.stderr = stderr
        self.output = output
        self.stdout_bytes = stdout.encode(runner.charset, "replace")
        self.stderr_bytes = stderr.encode(runner.charset, "replace")

    def __repr__(self) -> str:
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    """Invoke a command with argument tokens and capture its output (FP-14)."""

    def __init__(
        self,
        charset: str = "utf-8",
        env: t.Mapping[str, str | None] | None = None,
        echo_stdin: bool = False,
        catch_exceptions: bool = True,
        capture: str = "sys",
    ) -> None:
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(
        self,
        input: str | bytes | None = None,
        env: t.Mapping[str, str | None] | None = None,
        color: bool = False,
    ):
        transcript: list[tuple[str, str]] = []
        if isinstance(input, bytes):
            data = input.decode(self.charset)
        else:
            data = input or ""
        stdin = _RunnerStdin(data, transcript, self.echo_stdin)
        stdout = _Capture(transcript, "stdout", self.charset)
        stderr = _Capture(transcript, "stderr", self.charset)
        merged_env = dict(self.env)
        merged_env.update(env or {})
        old_env = {k: os.environ.get(k) for k in merged_env}
        old_streams = (sys.stdin, sys.stdout, sys.stderr)
        for key, value in merged_env.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
        try:
            yield stdin, stdout, stderr, transcript
        finally:
            sys.stdin, sys.stdout, sys.stderr = old_streams
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def invoke(
        self,
        cli,
        args: t.Sequence[str] | str | None = None,
        input: str | bytes | None = None,
        env: t.Mapping[str, str | None] | None = None,
        catch_exceptions: bool | None = None,
        color: bool = False,
        **extra: t.Any,
    ) -> Result:
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if args is None:
            arg_list: list[str] = []
        elif isinstance(args, str):
            arg_list = args.split()
        else:
            arg_list = list(args)
        prog_name = extra.pop("prog_name", "main")
        standalone = extra.pop("standalone_mode", True)
        extra.setdefault("color", color)
        exit_code = 0
        exception: BaseException | None = None
        with self.isolation(input=input, env=env, color=color) as (stdin, stdout, stderr, transcript):
            try:
                cli.main(
                    args=arg_list,
                    prog_name=prog_name,
                    standalone_mode=standalone,
                    complete_var=extra.pop("complete_var", None),
                    **extra,
                )
            except SystemExit as e:
                exit_code = e.code if isinstance(e.code, int) else (0 if e.code is None else 1)
            except Exception as e:  # noqa: BLE001 - captured on the result
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
        out = "".join(text for name, text in transcript if name == "stdout")
        err = "".join(text for name, text in transcript if name == "stderr")
        output = "".join(text for _, text in transcript)
        return Result(self, out, err, output, exit_code, exception)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir: str | os.PathLike | None = None):
        """Run inside a new empty directory (FP-14).

        Without ``temp_dir`` the directory is a fresh temporary one and is
        removed on exit. With ``temp_dir`` it is created under that parent
        and left in place.
        """
        cwd = os.getcwd()
        if temp_dir is None:
            path = tempfile.mkdtemp()
            remove = True
        else:
            path = tempfile.mkdtemp(dir=os.fspath(temp_dir))
            remove = False
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if remove:
                shutil.rmtree(path, ignore_errors=True)


__all__ = ["CliRunner", "Result"]
