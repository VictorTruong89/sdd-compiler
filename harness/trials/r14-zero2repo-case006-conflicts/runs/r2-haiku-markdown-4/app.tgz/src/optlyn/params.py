"""Parameters: options and arguments, value sources, and conversion (FP-03, FP-04, FP-05, FP-08)."""

from __future__ import annotations

import os
import typing as t

from . import termui
from .context import ParameterSource
from .exceptions import DeclarationError, MissingParameter, UsageError
from .paramtypes import BOOL, INT, Choice, Tuple, convert_type

_PREFIX_CHARS = ("-", "/", "+")
_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}
_MISSING = object()


def _is_flag_decl(decl: str) -> bool:
    return decl[:1] in _PREFIX_CHARS and len(decl) > 1


class Parameter:
    """Common base of :class:`Option` and :class:`Argument`."""

    param_type_name = "parameter"

    def __init__(
        self,
        name: str | None,
        type: t.Any = None,
        default: t.Any = None,
        required: bool = False,
        nargs: int | None = None,
        envvar: str | t.Sequence[str] | None = None,
        callback: t.Callable | None = None,
        is_eager: bool = False,
        expose_value: bool = True,
        hidden: bool = False,
        deprecated: bool | str = False,
        help: str | None = None,
        metavar: str | None = None,
        show_default: bool | str | None = None,
        show_envvar: bool = False,
        shell_complete: t.Callable | None = None,
        **_ignored: t.Any,
    ) -> None:
        self.name = name
        self.type = convert_type(type, default)
        self.default = default
        self.required = required
        self.nargs = 1 if nargs is None else nargs
        if self.nargs == 0 or self.nargs < -1:
            raise DeclarationError("nargs must be a positive integer, or -1 for variadic")
        if isinstance(self.type, Tuple) and nargs is None:
            self.nargs = len(self.type.types)
        if envvar is None:
            self.envvar: list[str] = []
        elif isinstance(envvar, str):
            self.envvar = [envvar]
        else:
            self.envvar = list(envvar)
        self.callback = callback
        self.is_eager = is_eager
        self.expose_value = expose_value
        self.hidden = hidden
        self.deprecated = deprecated
        self.help = help
        self.metavar = metavar
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.shell_complete_func = shell_complete

    # -- description ----------------------------------------------------

    @property
    def is_variadic(self) -> bool:
        return self.nargs == -1

    def describe(self) -> str:
        return self.name or "parameter"

    def get_help_record(self, ctx) -> tuple[str, str] | None:
        return None

    def get_metavar_text(self) -> str:
        if self.metavar is not None:
            return self.metavar
        return self.name.upper() if self.name else "VALUE"

    def shell_complete(self, ctx, incomplete: str) -> list:
        if self.shell_complete_func is not None:
            return [_as_item(x) for x in self.shell_complete_func(ctx, self, incomplete)]
        return self.type.shell_complete(ctx, self, incomplete)

    # -- value conversion ----------------------------------------------

    def _convert_tokens(self, ctx, tokens: tuple) -> t.Any:
        """Convert one occurrence (a tuple of raw tokens)."""
        if isinstance(self.type, Tuple):
            return self.type.convert(tuple(tokens), self, ctx)
        if self.nargs != 1:
            if len(tokens) != self.nargs:
                raise UsageError(f"{self.describe()} takes {self.nargs} values.", ctx)
            return tuple(self.type.convert(x, self, ctx) for x in tokens)
        return self.type.convert(tokens[0], self, ctx)

    def _convert_value(self, ctx, value: t.Any) -> t.Any:
        """Convert a value already in its source form (default, default map, env)."""
        if isinstance(self.type, Tuple):
            return self.type.convert(value, self, ctx)
        if self.nargs != 1:
            if not isinstance(value, (tuple, list)):
                raise UsageError(f"{self.describe()} needs a sequence value.", ctx)
            return tuple(self.type.convert(x, self, ctx) for x in value)
        return self.type.convert(value, self, ctx)

    def _split_string(self, raw: str) -> list:
        return self.type.split_envvar_value(raw)

    # -- sources --------------------------------------------------------

    def _env_names(self, ctx) -> list[str]:
        return list(self.envvar)

    def _env_raw(self, ctx) -> str | None:
        for name in self._env_names(ctx):
            value = os.environ.get(name)
            if value:
                return value
        return None

    def _default_value(self, ctx) -> t.Any:
        return self.default() if callable(self.default) else self.default

    def _default_map_value(self, ctx) -> t.Any:
        if ctx.default_map and self.name in ctx.default_map:
            return ctx.default_map[self.name], True
        return None, False

    def _finish(self, ctx, value: t.Any, source: ParameterSource | None) -> t.Any:
        if source is not None and self.name:
            ctx._set_source(self.name, source)
        if self.callback is not None:
            value = self.callback(ctx, self, value)
        if self.expose_value and self.name:
            ctx.params[self.name] = value
        return value

    def resolve(self, ctx, occurrences: list) -> t.Any:
        raise NotImplementedError


class Option(Parameter):
    """A named parameter (FP-03)."""

    param_type_name = "option"

    def __init__(
        self,
        param_decls: t.Sequence[str] = (),
        is_flag: bool | None = None,
        flag_value: t.Any = None,
        count: bool = False,
        multiple: bool = False,
        prompt: bool | str = False,
        prompt_required: bool = True,
        hide_input: bool = False,
        confirmation_prompt: bool = False,
        allow_from_autoenv: bool = True,
        **attrs: t.Any,
    ) -> None:
        opts: list[str] = []
        secondary: list[str] = []
        dest = None
        for decl in param_decls:
            if _is_flag_decl(decl):
                if "/" in decl[1:]:
                    first, second = decl.split("/", 1)
                    opts.append(first)
                    secondary.append(second)
                    if is_flag is None:
                        is_flag = True
                else:
                    opts.append(decl)
            elif decl.isidentifier():
                dest = decl
            else:
                raise DeclarationError(f"Invalid parameter declaration {decl!r}.")
        if not opts and dest is None:
            raise DeclarationError("An option needs a flag name or a destination.")
        self.opts = opts
        self.secondary_opts = secondary
        if dest is None:
            dest = _infer_name(opts + secondary)
        if count and is_flag:
            raise DeclarationError("A counting option cannot also be a flag.")
        if is_flag is None:
            is_flag = False
        if is_flag and attrs.get("type") is None:
            attrs["type"] = BOOL
        if count and attrs.get("type") is None:
            attrs["type"] = INT
        if is_flag and multiple:
            raise DeclarationError("A flag cannot be repeatable.")
        if attrs.get("deprecated") and attrs.get("required"):
            raise DeclarationError("A deprecated option cannot be required.")
        if attrs.get("deprecated") and prompt:
            raise DeclarationError("A deprecated option cannot use a prompt.")
        if count:
            attrs.setdefault("default", 0)
        if (is_flag or count) and attrs.get("nargs") not in (None, 1):
            raise DeclarationError("A flag takes no more than one value.")
        self.is_flag = is_flag
        self.flag_value = flag_value
        self.count = count
        self.multiple = multiple
        self.prompt = bool(prompt)
        self.prompt_text = prompt if isinstance(prompt, str) else None
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.allow_from_autoenv = allow_from_autoenv
        super().__init__(dest, **attrs)

    # -- description and help -------------------------------------------

    def describe(self) -> str:
        names = self.opts + self.secondary_opts
        return "/".join(names) if names else (self.name or "option")

    def _all_flag_names(self) -> list[tuple[str, str]]:
        out = [(n, "on") for n in self.opts]
        out += [(n, "off") for n in self.secondary_opts]
        return out

    def get_help_record(self, ctx) -> tuple[str, str]:
        if self.secondary_opts:
            left = ", ".join(self.opts) + "/" + ", ".join(self.secondary_opts)
        else:
            left = ", ".join(self.opts)
        if not self.is_flag and not self.count:
            left += " " + self.get_metavar_text()
        extras = []
        if self.help:
            text = self.help
        else:
            text = ""
        if self.deprecated:
            extras.append("(deprecated)" + (f" {self.deprecated}" if isinstance(self.deprecated, str) else ""))
        if isinstance(self.type, Choice):
            extras.append("Choices: " + ", ".join(self.type._tokens))
        if self.show_default:
            shown = self.show_default if isinstance(self.show_default, str) else self._shown_default_text(ctx)
            if shown is not None:
                extras.append(f"[default: {shown}]")
        if self.show_envvar and self.envvar:
            extras.append(f"[env var: {', '.join(self.envvar)}]")
        if self.required:
            extras.append("[required]")
        if extras:
            text = (text + " " if text else "") + " ".join(extras)
        return left, text

    def get_metavar_text(self) -> str:
        if self.metavar is not None:
            return self.metavar
        if isinstance(self.type, Choice):
            return self.type.get_metavar(self)
        return self.type.name.upper().replace(" ", "_")

    def _shown_default_text(self, ctx) -> str | None:
        if self.is_flag:
            if not self.default:
                return None
            return str(self.default)
        value = self.default
        if callable(value):
            return None
        if value is None:
            return None
        return str(value)

    # -- value resolution ----------------------------------------------

    def _env_names(self, ctx) -> list[str]:
        names = list(self.envvar)
        prefix = ctx.get_setting("auto_envvar_prefix")
        if prefix and self.allow_from_autoenv:
            parts = [prefix] + ctx.envvar_path + [self.name or ""]
            auto = "_".join(p for p in parts if p).upper().replace("-", "_")
            names.append(auto)
        return names

    def _flag_from_env(self, ctx) -> t.Any:
        """Return a bool (or flag value) from the environment, or _MISSING."""
        raw = self._env_raw(ctx)
        if raw is None:
            return _MISSING
        text = raw.strip().lower()
        if self.flag_value is not None and not isinstance(self.flag_value, bool):
            if raw == str(self.flag_value):
                return self.flag_value
        if text in _TRUE:
            return True
        if text in _FALSE or text == "":
            return False
        if self.flag_value is not None and not isinstance(self.flag_value, bool):
            return _MISSING
        raise UsageError(f"{raw!r} is not a valid boolean for {self.describe()}.", ctx)

    def resolve(self, ctx, occurrences: list) -> t.Any:
        if self.deprecated and occurrences:
            _warn_deprecated(ctx, self.describe(), self.deprecated)
        if self.is_flag:
            return self._resolve_flag(ctx, occurrences)
        if self.count:
            return self._resolve_count(ctx, occurrences)
        if self.multiple:
            return self._resolve_multiple(ctx, occurrences)
        return self._resolve_single(ctx, occurrences)

    def _resolve_flag(self, ctx, occurrences):
        if occurrences:
            value = occurrences[-1]
            return self._finish(ctx, value, ParameterSource.COMMANDLINE)
        from_env = self._flag_from_env(ctx)
        if from_env is not _MISSING:
            return self._finish(ctx, from_env, ParameterSource.ENVIRONMENT)
        mapped, found = self._default_map_value(ctx)
        if found:
            return self._finish(ctx, bool(mapped), ParameterSource.DEFAULT_MAP)
        value = self._default_value(ctx)
        return self._finish(ctx, False if value is None else value, ParameterSource.DEFAULT)

    def _resolve_count(self, ctx, occurrences):
        if occurrences:
            return self._finish(ctx, len(occurrences), ParameterSource.COMMANDLINE)
        mapped, found = self._default_map_value(ctx)
        if found:
            return self._finish(ctx, int(mapped), ParameterSource.DEFAULT_MAP)
        value = self._default_value(ctx)
        return self._finish(ctx, int(value or 0), ParameterSource.DEFAULT)

    def _occurrence_value(self, ctx, tokens: tuple):
        """Convert one command-line occurrence; handles optional and prompt values."""
        if tokens == ():
            if self.flag_value is not None:
                return self._convert_value(ctx, self.flag_value) if self.nargs == 1 else self.flag_value
            if self.prompt:
                return self._prompt(ctx, None)
            raise UsageError(f"{self.describe()} requires an argument.", ctx)
        return self._convert_tokens(ctx, tokens)

    def _resolve_single(self, ctx, occurrences):
        if occurrences:
            value = self._occurrence_value(ctx, occurrences[-1])
            return self._finish(ctx, value, ParameterSource.COMMANDLINE)
        env_raw = self._env_raw(ctx)
        if env_raw is not None:
            if self.nargs != 1:
                tokens = tuple(self._split_string(env_raw))
                value = self._convert_tokens(ctx, tokens)
            else:
                value = self._convert_value(ctx, env_raw)
            return self._finish(ctx, value, ParameterSource.ENVIRONMENT)
        mapped, found = self._default_map_value(ctx)
        declared = self._default_value(ctx)
        if self.prompt and self.prompt_required:
            shown = mapped if found else declared
            value = self._prompt(ctx, shown)
            return self._finish(ctx, value, ParameterSource.PROMPT)
        if found:
            value = self._map_default(ctx, mapped)
            return self._finish(ctx, value, ParameterSource.DEFAULT_MAP)
        if declared is not None:
            value = self._convert_default(ctx, declared)
            return self._finish(ctx, value, ParameterSource.DEFAULT)
        if self.required:
            raise MissingParameter(ctx=ctx, param=self, param_hint=self.describe())
        return self._finish(ctx, None, None)

    def _resolve_multiple(self, ctx, occurrences):
        if occurrences:
            value = tuple(self._occurrence_value(ctx, o) for o in occurrences)
            return self._finish(ctx, value, ParameterSource.COMMANDLINE)
        env_raw = self._env_raw(ctx)
        if env_raw is not None:
            tokens = self._split_string(env_raw)
            if self.nargs == 1:
                value = tuple(self._convert_tokens(ctx, (x,)) for x in tokens)
            else:
                chunks = [tuple(tokens[i : i + self.nargs]) for i in range(0, len(tokens), self.nargs)]
                value = tuple(self._convert_tokens(ctx, c) for c in chunks)
            return self._finish(ctx, value, ParameterSource.ENVIRONMENT)
        mapped, found = self._default_map_value(ctx)
        if found:
            if isinstance(mapped, str):
                raise UsageError(f"{self.describe()} needs an iterable (sequence) default.", ctx)
            return self._finish(ctx, self._map_default(ctx, mapped), ParameterSource.DEFAULT_MAP)
        declared = self._default_value(ctx)
        if declared is not None:
            value = self._convert_default(ctx, declared)
            return self._finish(ctx, value, ParameterSource.DEFAULT)
        if self.required:
            raise MissingParameter(ctx=ctx, param=self, param_hint=self.describe())
        return self._finish(ctx, (), None)

    def _map_default(self, ctx, value):
        if self.nargs != 1 or isinstance(self.type, Tuple):
            if isinstance(value, str):
                tokens = self._split_string(value)
                return self._convert_tokens(ctx, tuple(tokens))
        if self.multiple:
            if isinstance(value, str) or not isinstance(value, (list, tuple)):
                raise UsageError(f"{self.describe()} needs an iterable (sequence) default.", ctx)
            return tuple(self._convert_value(ctx, x) for x in value)
        return self._convert_value(ctx, value)

    def _convert_default(self, ctx, value):
        if self.multiple:
            if isinstance(value, str) or not isinstance(value, (list, tuple)):
                raise UsageError(f"{self.describe()} needs an iterable (sequence) default.", ctx)
            return tuple(self._convert_value(ctx, x) for x in value)
        return self._convert_value(ctx, value)

    def _prompt(self, ctx, default):
        text = self.prompt_text or self.name.replace("_", " ").capitalize()
        value = termui.prompt(
            text,
            default=default,
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            type=self.type,
        )
        return value


class Argument(Parameter):
    """A positional parameter (FP-04)."""

    param_type_name = "argument"

    def __init__(self, param_decls: t.Sequence[str] = (), **attrs: t.Any) -> None:
        if len(param_decls) != 1 or not param_decls[0].isidentifier():
            raise DeclarationError("An argument takes a single destination name.")
        if attrs.get("deprecated") and attrs.get("required"):
            raise DeclarationError("A deprecated argument cannot be required.")
        self.required_flag = attrs.pop("required", None)
        self.optional = attrs.pop("optional", False)
        super().__init__(param_decls[0], **attrs)
        has_default = self.default is not None
        if self.required_flag is not None:
            self.required = bool(self.required_flag)
        elif self.nargs == -1:
            # A variadic argument is optional unless marked required.
            self.required = False
        else:
            self.required = not has_default and not self.optional
        if self.deprecated and self.required:
            raise DeclarationError("A deprecated argument cannot be required.")

    def describe(self) -> str:
        return self.name

    def get_help_record(self, ctx):
        if not self.help:
            return None
        return self.get_placeholder(), self.help

    def get_placeholder(self) -> str:
        text = self.get_metavar_text()
        if self.required:
            base = text
        else:
            base = f"[{text}]"
        if self.is_variadic:
            base += "..."
        return base

    def resolve(self, ctx, occurrences: list) -> t.Any:
        if self.deprecated and occurrences:
            _warn_deprecated(ctx, self.describe(), self.deprecated)
        tokens = occurrences[0] if occurrences else None
        if tokens is not None and (len(tokens) > 0 or self.nargs == -1):
            if self.nargs == -1:
                value = tuple(self.type.convert(x, self, ctx) for x in tokens)
            elif self.nargs == 1:
                value = self.type.convert(tokens[0], self, ctx)
            else:
                value = self._convert_tokens(ctx, tuple(tokens))
            return self._finish(ctx, value, ParameterSource.COMMANDLINE)
        env_raw = self._env_raw(ctx)
        if env_raw is not None:
            if self.nargs == 1:
                value = self.type.convert(env_raw, self, ctx)
            else:
                items = self._split_string(env_raw)
                if self.nargs == -1:
                    value = tuple(self.type.convert(x, self, ctx) for x in items)
                else:
                    value = self._convert_tokens(ctx, tuple(items))
            return self._finish(ctx, value, ParameterSource.ENVIRONMENT)
        mapped, found = self._default_map_value(ctx)
        if found:
            return self._finish(ctx, self._convert_value(ctx, mapped), ParameterSource.DEFAULT_MAP)
        declared = self._default_value(ctx)
        if declared is not None:
            return self._finish(ctx, self._convert_value(ctx, declared), ParameterSource.DEFAULT)
        if self.nargs == -1:
            if self.required:
                raise MissingParameter(ctx=ctx, param=self, param_hint=self.name)
            return self._finish(ctx, (), None)
        if self.required:
            raise MissingParameter(ctx=ctx, param=self, param_hint=self.name)
        return self._finish(ctx, None, None)


def _as_item(x):
    from .completion import CompletionItem

    if isinstance(x, CompletionItem):
        return x
    if isinstance(x, str):
        return CompletionItem(x)
    return CompletionItem(x.value, getattr(x, "help", None), getattr(x, "type", "plain"))


def _infer_name(decls: list[str]) -> str:
    """Destination from the flag names: first long name, otherwise first short name (FP-03)."""
    longs = [d for d in decls if d.startswith("--")]
    for d in longs + decls:
        cand = d.lstrip("-/+").replace("-", "_")
        if cand.isidentifier():
            return cand
    raise DeclarationError(f"Cannot infer a destination name from {decls!r}.")


def _warn_deprecated(ctx, name: str, note) -> None:
    msg = f"DeprecationWarning: {name} is deprecated."
    if isinstance(note, str):
        msg = f"DeprecationWarning: {note}"
    termui.echo(msg, err=True)

