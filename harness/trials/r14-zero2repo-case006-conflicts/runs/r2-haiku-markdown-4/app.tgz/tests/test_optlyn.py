"""Behavioural tests for Optlyn. Run with: PYTHONPATH=src python3 -m pytest tests"""

from optlyn import (
    Choice,
    IntRange,
    argument,
    command,
    echo,
    get_current_context,
    group,
    option,
    style,
    unstyle,
)
from optlyn.testing import CliRunner


def _tool():
    @group()
    @option("--verbose", "-v", is_flag=True)
    def cli(verbose):
        """Top level."""
        echo(f"verbose={verbose}")

    @cli.command()
    @option("--count", type=int, default=1, help="How many")
    @argument("name")
    def hello(count, name):
        """Say hello."""
        echo(f"hello {name} {count}")

    return cli


def test_nested_dispatch_runs_group_then_leaf():
    res = CliRunner().invoke(_tool(), ["-v", "hello", "--count", "3", "bob"])
    assert res.exit_code == 0
    assert res.output == "verbose=True\nhello bob 3\n"


def test_help_is_success_and_skips_callback():
    res = CliRunner().invoke(_tool(), ["hello", "--help"])
    assert res.exit_code == 0
    assert "Usage: main hello [OPTIONS] NAME" in res.output
    assert "--count INTEGER" in res.output


def test_group_without_subcommand_is_usage_error():
    res = CliRunner().invoke(_tool(), [])
    assert res.exit_code == 2


def test_unknown_option_is_usage_error_and_names_it():
    res = CliRunner().invoke(_tool(), ["hello", "--nope", "x"])
    assert res.exit_code == 2
    assert "--nope" in res.output


def test_choice_and_range_conversion():
    @command()
    @option("--level", type=Choice(["low", "high"]), default="low")
    @option("--num", type=IntRange(1, 10, clamp=True), default=5)
    def tool(level, num):
        echo(f"{level} {num}")

    assert CliRunner().invoke(tool, ["--level", "high", "--num", "99"]).output == "high 10\n"
    assert CliRunner().invoke(tool, ["--level", "mid"]).exit_code == 2


def test_envvar_and_default_map_precedence():
    @command()
    @option("--port", type=int, default=80, envvar="OPTLYN_TEST_PORT")
    def serve(port):
        echo(str(port))

    runner = CliRunner()
    assert runner.invoke(serve, [], default_map={"port": 8080}).output == "8080\n"
    assert runner.invoke(serve, [], env={"OPTLYN_TEST_PORT": "9000"}, default_map={"port": 8080}).output == "9000\n"


def test_counting_and_variadic_arguments():
    @command()
    @option("-c", "--count", count=True)
    @argument("files", nargs=-1)
    def cnt(count, files):
        echo(f"{count} {files}")

    assert CliRunner().invoke(cnt, ["-cc", "a", "b"]).output == "2 ('a', 'b')\n"
    assert CliRunner().invoke(cnt, []).output == "0 ()\n"


def test_prompt_reads_input_and_echoes_it():
    @command()
    @option("--name", prompt=True)
    def ask(name):
        echo(f"name={name}")

    res = CliRunner().invoke(ask, [], input="bob\n")
    assert res.output == "Name: bob\nname=bob\n"


def test_chain_result_callback_receives_values():
    @group(chain=True)
    def pipe():
        pass

    @pipe.command()
    @argument("n", type=int)
    def add(n):
        return lambda s: s + n

    @pipe.result_callback()
    def done(procs):
        s = 0
        for p in procs:
            s = p(s)
        echo(f"sum={s}")

    assert CliRunner().invoke(pipe, ["add", "2", "add", "5"]).output == "sum=7\n"


def test_style_and_strip():
    assert unstyle(style("hi", fg="red", bold=True)) == "hi"
    assert style("x", fg="red") != "x"


def test_current_context_and_exit_status():
    @command()
    def stop():
        get_current_context().exit(3)

    assert CliRunner().invoke(stop, []).exit_code == 3


def test_completion_suggests_subcommands():
    res = CliRunner().invoke(
        _tool(),
        [],
        env={"COMP_WORDS": "main h", "COMP_CWORD": "1", "_MAIN_COMPLETE": "bash_complete"},
    )
    assert res.output == "hello\n"


def test_deprecated_command_still_runs_with_warning():
    @command(deprecated=True)
    def old():
        echo("ran")

    res = CliRunner().invoke(old, [])
    assert res.exit_code == 0
    assert res.output.index("DeprecationWarning") < res.output.index("ran")
