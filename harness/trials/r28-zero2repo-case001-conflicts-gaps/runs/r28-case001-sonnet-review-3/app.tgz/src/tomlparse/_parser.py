import re
from datetime import date, datetime, time, timedelta, timezone

WS = " \t"
NEWLINE = "\n"
BARE = frozenset("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_")
HEXD = frozenset("0123456789abcdefABCDEF")
ESC = {"b": "\b", "t": "\t", "n": "\n", "f": "\f", "r": "\r", "e": "\x1b",
       '"': '"', "\\": "\\"}

RE_NUM = re.compile(r"""
0
(?:
    x[0-9A-Fa-f](?:_?[0-9A-Fa-f])*
    |
    b[01](?:_?[01])*
    |
    o[0-7](?:_?[0-7])*
)
|
[+-]?
(?:0|[1-9](?:_?[0-9])*)
(?:
    (?:\.[0-9](?:_?[0-9])*)?
    (?:[eE][+-]?[0-9](?:_?[0-9])*)?
)
""", re.VERBOSE)
RE_TIME = r"([01][0-9]|2[0-3]):([0-5][0-9])(?::([0-5][0-9])(?:\.([0-9]+))?)?"
RE_DATE = r"([0-9]{4})-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])"
RE_LTIME = re.compile(RE_TIME)
RE_DT = re.compile(
    RE_DATE + r"(?:[Tt ]" + RE_TIME + r"(?:([Zz])|([+-])([01][0-9]|2[0-3]):([0-5][0-9]))?)?")


class TOMLDecodeError(ValueError):
    def __init__(self, msg="", doc="", pos=0, *args):
        if args:
            # tolerate odd call spellings
            pass
        self.msg = msg
        self.doc = doc
        self.pos = pos
        if isinstance(doc, str) and isinstance(pos, int):
            p = max(pos, 0)
            self.lineno = doc.count("\n", 0, p) + 1
            if self.lineno == 1:
                self.colno = p + 1
            else:
                self.colno = p - doc.rindex("\n", 0, p)
            if pos >= len(doc):
                loc = "end of document"
            else:
                loc = "line %d, column %d" % (self.lineno, self.colno)
        else:
            self.lineno = self.colno = 1
            loc = "unknown location"
        ValueError.__init__(self, "%s (at %s)" % (msg, loc))


def load(fp, *, parse_float=float):
    b = fp.read()
    if not isinstance(b, (bytes, bytearray)):
        raise TypeError("File must be opened in binary mode, e.g. use `open('foo.toml', 'rb')`")
    try:
        s = bytes(b).decode("utf-8")
    except UnicodeDecodeError as e:
        raise TOMLDecodeError("Invalid UTF-8: %s" % e, "", 0) from None
    return loads(s, parse_float=parse_float)


def _loads_check(s, parse_float):
    if not isinstance(s, str):
        raise TypeError("Expected str object, not '%s'" % type(s).__name__)
    if not callable(parse_float):
        raise TypeError("parse_float must be callable")


def loads(s, *, parse_float=float):
    _loads_check(s, parse_float)
    src = s.replace("\r\n", "\n")
    if parse_float is float:
        pf = float
    else:
        def pf(tok):
            r = parse_float(tok)
            if isinstance(r, (dict, list)):
                raise ValueError("parse_float must not return dicts or lists")
            return r
    P = _P(src, pf)
    return P.run()


def _err(src, pos, msg):
    return TOMLDecodeError(msg, src, pos)


class _P:
    def __init__(self, src, pf):
        self.src = src
        self.pf = pf
        self.data = {}
        self.cur = self.data
        self.aot = set()
        self.hdr = set()
        self.implicit = set()
        self.dotted = set()

    def e(self, pos, msg):
        return TOMLDecodeError(msg, self.src, pos)

    def skip_chars(self, pos, chars):
        src = self.src
        n = len(src)
        while pos < n and src[pos] in chars:
            pos += 1
        return pos

    def skip_comment(self, pos):
        src = self.src
        if src.startswith("#", pos):
            n = len(src)
            pos += 1
            while pos < n and src[pos] != "\n":
                c = src[pos]
                if (c < " " and c != "\t") or c == "\x7f":
                    raise self.e(pos, "Illegal character in comment")
                pos += 1
        return pos

    def skip_ws_comments(self, pos):
        # whitespace, comments, newlines
        src = self.src
        while True:
            pos = self.skip_chars(pos, WS)
            if pos < len(src) and src[pos] == "#":
                pos = self.skip_comment(pos)
            if pos < len(src) and src[pos] == "\n":
                pos += 1
                continue
            return pos

    def run(self):
        src = self.src
        n = len(src)
        header = ()
        pos = 0
        while True:
            pos = self.skip_chars(pos, WS)
            if pos >= n:
                break
            c = src[pos]
            if c == "\n":
                pos += 1
                continue
            if c == "[":
                pos, header = self.header(pos, header)
            elif c == "#":
                pos = self.skip_comment(pos)
                continue
            else:
                pos = self.keyval_line(pos, header)
            pos = self.skip_chars(pos, WS)
            if pos < n and src[pos] == "#":
                pos = self.skip_comment(pos)
            if pos < n:
                if src[pos] != "\n":
                    raise self.e(pos, "Expected newline or end of document after a statement")
                pos += 1
        return self.data

    def header(self, pos, header):
        src = self.src
        is_arr = src.startswith("[[", pos)
        pos += 2 if is_arr else 1
        pos = self.skip_chars(pos, WS)
        pos, key = self.parse_key(pos)
        closer = "]]" if is_arr else "]"
        if not src.startswith(closer, pos):
            raise self.e(pos, "Expected '%s' at end of table header" % closer)
        pos += len(closer)
        cur = self.data
        for k in key[:-1]:
            cur = self.descend(cur, k, pos)
        last = key[-1]
        if is_arr:
            if last in cur:
                v = cur[last]
                if not isinstance(v, list) or id(v) not in self.aot:
                    raise self.e(pos, "Cannot append to non-array-of-tables")
            else:
                v = cur[last] = []
                self.aot.add(id(v))
            t = {}
            v.append(t)
            self.hdr.add(id(t))
        else:
            if last in cur:
                t = cur[last]
                if (not isinstance(t, dict) or id(t) not in self.implicit):
                    raise self.e(pos, "Cannot declare %s twice" % (key,))
                self.implicit.discard(id(t))
            else:
                t = cur[last] = {}
                self.hdr.add(id(t))
        self.cur = t
        return pos, key

    def descend(self, cur, k, pos):
        if k in cur:
            v = cur[k]
            if isinstance(v, list):
                if id(v) not in self.aot or not v:
                    raise self.e(pos, "Cannot overwrite a value")
                return v[-1]
            if isinstance(v, dict) and (id(v) in self.hdr or id(v) in self.dotted):
                return v
            raise self.e(pos, "Cannot mutate a value or immutable table")
        t = cur[k] = {}
        self.hdr.add(id(t))
        self.implicit.add(id(t))
        return t

    def keyval_line(self, pos, header):
        pos, key, value = self.keyval(pos)
        cur = self.cur
        for k in key[:-1]:
            if k in cur:
                v = cur[k]
                if not isinstance(v, dict) or id(v) not in self.dotted:
                    raise self.e(pos, "Cannot extend an existing value or table")
                cur = v
            else:
                t = cur[k] = {}
                self.dotted.add(id(t))
                cur = t
        if key[-1] in cur:
            raise self.e(pos, "Duplicate key")
        cur[key[-1]] = value
        return pos

    # ---- keys / values ----
    def parse_key(self, pos):
        src = self.src
        parts = []
        while True:
            pos, k = self.key_part(pos)
            parts.append(k)
            pos = self.skip_chars(pos, WS)
            if pos < len(src) and src[pos] == ".":
                pos = self.skip_chars(pos + 1, WS)
                continue
            return pos, tuple(parts)

    def key_part(self, pos):
        src = self.src
        n = len(src)
        if pos >= n:
            raise self.e(pos, "Expected key")
        c = src[pos]
        if c == '"':
            if src.startswith('"""', pos):
                raise self.e(pos, "Multiline strings are not allowed as keys")
            return self.basic_str(pos)
        if c == "'":
            if src.startswith("'''", pos):
                raise self.e(pos, "Multiline strings are not allowed as keys")
            return self.literal_str(pos)
        start = pos
        while pos < n and src[pos] in BARE:
            pos += 1
        if pos == start:
            raise self.e(pos, "Invalid key")
        return pos, src[start:pos]

    def keyval(self, pos):
        src = self.src
        pos, key = self.parse_key(pos)
        if pos >= len(src) or src[pos] != "=":
            raise self.e(pos, "Expected '=' after a key")
        pos = self.skip_chars(pos + 1, WS)
        pos, v = self.value(pos)
        return pos, key, v

    def value(self, pos):
        src = self.src
        n = len(src)
        if pos >= n:
            raise self.e(pos, "Expected value")
        c = src[pos]
        if c == '"':
            if src.startswith('"""', pos):
                return self.ml_basic(pos)
            return self.basic_str(pos)
        if c == "'":
            if src.startswith("'''", pos):
                return self.ml_literal(pos)
            return self.literal_str(pos)
        if src.startswith("true", pos) and self._delim(pos + 4):
            return pos + 4, True
        if src.startswith("false", pos) and self._delim(pos + 5):
            return pos + 5, False
        if c == "[":
            return self.array(pos)
        if c == "{":
            return self.inline_table(pos)
        m = RE_DT.match(src, pos)
        if m and self._delim(m.end()):
            return m.end(), self.datetime_(m)
        m = RE_LTIME.match(src, pos)
        if m and self._delim(m.end()):
            h, mi, s, f = m.groups()
            return m.end(), time(int(h), int(mi), int(s or 0), self.micro(f))
        m = RE_NUM.match(src, pos)
        if m and self._delim(m.end()):
            tok = m.group()
            end = m.end()
            if tok[:2] in ("0x", "0o", "0b"):
                return end, int(tok.replace("_", ""), 0)
            if "." in tok or "e" in tok or "E" in tok:
                return end, self.pf(tok)
            return end, int(tok.replace("_", ""))
        for sp in ("inf", "nan"):
            for sg in ("", "+", "-"):
                t = sg + sp
                if src.startswith(t, pos) and self._delim(pos + len(t)):
                    return pos + len(t), self.pf(t)
        raise self.e(pos, "Invalid value")

    def _delim(self, pos):
        src = self.src
        return pos >= len(src) or src[pos] in " \t\n#,]}"

    @staticmethod
    def micro(f):
        if not f:
            return 0
        return int(f[:6].ljust(6, "0"))

    def datetime_(self, m):
        y, mo, d, h, mi, s, f, z, sg, oh, om = m.groups()
        try:
            dt = date(int(y), int(mo), int(d))
        except ValueError:
            raise self.e(m.start(), "Invalid date")
        if h is None:
            return dt
        tz = None
        if z:
            tz = timezone.utc
        elif sg:
            delta = timedelta(hours=int(oh), minutes=int(om))
            tz = timezone(delta if sg == "+" else -delta)
        return datetime(dt.year, dt.month, dt.day, int(h), int(mi), int(s or 0),
                        self.micro(f), tzinfo=tz)

    # ---- strings ----
    def check_char(self, pos, c):
        if (c < " " and c != "\t") or c == "\x7f":
            raise self.e(pos, "Illegal control character in string")

    def literal_str(self, pos):
        src = self.src
        n = len(src)
        pos += 1
        start = pos
        while pos < n:
            c = src[pos]
            if c == "'":
                return pos + 1, src[start:pos]
            if c == "\n":
                break
            self.check_char(pos, c)
            pos += 1
        raise self.e(pos, "Unterminated string")

    def ml_literal(self, pos):
        src = self.src
        n = len(src)
        pos += 3
        if pos < n and src[pos] == "\n":
            pos += 1
        start = pos
        while pos < n:
            if src.startswith("'''", pos):
                end = pos
                pos += 3
                # up to two extra quotes belong to content
                extra = 0
                while extra < 2 and pos < n and src[pos] == "'":
                    pos += 1
                    extra += 1
                    end += 1
                return pos, src[start:end]
            c = src[pos]
            if c != "\n":
                self.check_char(pos, c)
            pos += 1
        raise self.e(pos, "Unterminated string")

    def escape(self, pos):
        # src[pos] == "\\" ; returns (newpos, text)
        src = self.src
        n = len(src)
        nxt = src[pos + 1] if pos + 1 < n else ""
        if nxt in ESC and nxt:
            return pos + 2, ESC[nxt]
        width = {"x": 2, "u": 4, "U": 8}.get(nxt)
        if width:
            h = src[pos + 2:pos + 2 + width]
            if len(h) != width or not all(ch in HEXD for ch in h):
                raise self.e(pos, "Invalid hex escape")
            cp = int(h, 16)
            if cp > 0x10FFFF or 0xD800 <= cp <= 0xDFFF:
                raise self.e(pos, "Escaped character is not a Unicode scalar value")
            return pos + 2 + width, chr(cp)
        raise self.e(pos, "Invalid escape sequence")

    def basic_str(self, pos):
        src = self.src
        n = len(src)
        pos += 1
        buf = []
        while pos < n:
            c = src[pos]
            if c == '"':
                return pos + 1, "".join(buf)
            if c == "\n":
                break
            if c == "\\":
                pos, t = self.escape(pos)
                buf.append(t)
                continue
            self.check_char(pos, c)
            buf.append(c)
            pos += 1
        raise self.e(pos, "Unterminated string")

    def ml_basic(self, pos):
        src = self.src
        n = len(src)
        pos += 3
        if pos < n and src[pos] == "\n":
            pos += 1
        buf = []
        while pos < n:
            c = src[pos]
            if c == '"':
                if src.startswith('"""', pos):
                    pos += 3
                    extra = 0
                    while extra < 2 and pos < n and src[pos] == '"':
                        buf.append('"')
                        pos += 1
                        extra += 1
                    return pos, "".join(buf)
                buf.append(c)
                pos += 1
                continue
            if c == "\\":
                # line-ending backslash?
                j = pos + 1
                while j < n and src[j] in WS:
                    j += 1
                if j < n and src[j] == "\n":
                    while j < n and src[j] in " \t\n":
                        j += 1
                    pos = j
                    continue
                pos, t = self.escape(pos)
                buf.append(t)
                continue
            if c != "\n":
                self.check_char(pos, c)
            buf.append(c)
            pos += 1
        raise self.e(pos, "Unterminated string")

    # ---- compound ----
    def array(self, pos):
        src = self.src
        pos += 1
        res = []
        while True:
            pos = self.skip_ws_comments(pos)
            if pos >= len(src):
                raise self.e(pos, "Unterminated array")
            if src[pos] == "]":
                return pos + 1, res
            pos, v = self.value(pos)
            res.append(v)
            pos = self.skip_ws_comments(pos)
            if pos >= len(src):
                raise self.e(pos, "Unterminated array")
            if src[pos] == ",":
                pos += 1
                continue
            if src[pos] == "]":
                return pos + 1, res
            raise self.e(pos, "Unclosed array")

    def inline_table(self, pos):
        src = self.src
        pos += 1
        data = {}
        dotted = set()  # paths created by dotted keys inside this table
        while True:
            pos = self.skip_ws_comments(pos)
            if pos >= len(src):
                raise self.e(pos, "Unterminated inline table")
            if src[pos] == "}":
                return pos + 1, data
            pos, key, v = self.keyval(pos)
            cur = data
            for i, k in enumerate(key[:-1]):
                if k in cur:
                    if not isinstance(cur[k], dict) or key[: i + 1] not in dotted:
                        raise self.e(pos, "Cannot overwrite a value")
                    cur = cur[k]
                else:
                    cur[k] = {}
                    dotted.add(key[: i + 1])
                    cur = cur[k]
            if key[-1] in cur:
                raise self.e(pos, "Duplicate key")
            cur[key[-1]] = v
            if isinstance(v, dict):
                pass
            pos = self.skip_ws_comments(pos)
            if pos >= len(src):
                raise self.e(pos, "Unterminated inline table")
            if src[pos] == ",":
                pos += 1
                continue
            if src[pos] == "}":
                return pos + 1, data
            raise self.e(pos, "Unclosed inline table")
