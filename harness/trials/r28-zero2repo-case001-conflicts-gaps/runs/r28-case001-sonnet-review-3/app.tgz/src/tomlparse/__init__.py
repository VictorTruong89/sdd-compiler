from ._parser import loads, load, TOMLDecodeError

__all__ = ("loads", "load", "TOMLDecodeError")
