# spec: N-000266 N-000270 N-000271 N-000272 (public entries, pure Python)
import re
from datetime import date, datetime, time, timedelta, timezone


class TOMLDecodeError(ValueError):
    """Raised when a document is not valid TOML. spec: N-000307..N-000322"""

    def __init__(self, msg, doc, pos):
        self.msg = msg
        self.doc = doc
        self.pos = pos
        self.lineno = doc.count("\n", 0, pos) + 1
        if self.lineno == 1:
            self.colno = pos + 1
        else:
            self.colno = pos - doc.rindex("\n", 0, pos)
        if pos >= len(doc):
            where = "end of document"
        else:
            where = "line %d, column %d" % (self.lineno, self.colno)
        ValueError.__init__(self, "%s (at %s)" % (msg, where))

    def __reduce__(self):
        return (self.__class__, (self.msg, self.doc, self.pos))


class _Err(Exception):
    def __init__(self, msg, pos):
        Exception.__init__(self, msg)
        self.msg = msg
        self.pos = pos


_WS = " \t"
_BARE = re.compile(r"[A-Za-z0-9_-]+")
_DATE = r"(\d{4})-(\d\d)-(\d\d)"
_TIME = r"(\d\d):(\d\d)(?::(\d\d)(?:\.(\d+))?)?"
_DT = re.compile(
    _DATE + r"(?:[Tt ]" + _TIME + r"(?:([Zz])|([+-])(\d\d):(\d\d))?)?"
)
_LT = re.compile(_TIME)
_DEC = re.compile(r"[+-]?(?:0|[1-9](?:_?\d)*)")
_FLOAT = re.compile(
    r"[+-]?(?:0|[1-9](?:_?\d)*)(?:\.\d(?:_?\d)*)?(?:[eE][+-]?\d(?:_?\d)*)?"
)
_HEX = re.compile(r"0x[0-9A-Fa-f](?:_?[0-9A-Fa-f])*")
_OCT = re.compile(r"0o[0-7](?:_?[0-7])*")
_BIN = re.compile(r"0b[01](?:_?[01])*")
_SPECIAL = re.compile(r"[+-]?(?:inf|nan)")
_TOKEN_END = " \t\n,]}#"
_ESC = {"b": "\b", "t": "\t", "n": "\n", "f": "\f", "r": "\r",
        "e": "\x1b", '"': '"', "\\": "\\"}
_HEXD = "0123456789abcdefABCDEF"


class _Parser:
    def __init__(self, s, parse_float):
        self.s = s
        self.n = len(s)
        self.pf = parse_float
        self.dotted = set()      # ids of dicts made by dotted keys
        self.implicit = set()    # ids of dicts made implicitly by headers
        self.aot = set()         # ids of lists made by [[ ]]
        self.doc = {}

    def err(self, msg, pos):
        raise _Err(msg, pos)

    # ---- helpers
    def skip_ws(self, i):
        s, n = self.s, self.n
        while i < n and s[i] in _WS:
            i += 1
        return i

    def skip_comment(self, i):
        s, n = self.s, self.n
        if i < n and s[i] == "#":
            i += 1
            while i < n and s[i] != "\n":
                c = s[i]
                if (c < " " and c != "\t") or c == "\x7f":
                    self.err("control character in comment", i)
                i += 1
        return i

    def skip_ws_nl(self, i):
        """whitespace, comments and newlines (inside arrays/inline tables)"""
        while True:
            i = self.skip_ws(i)
            i = self.skip_comment(i)
            if i < self.n and self.s[i] == "\n":
                i += 1
            else:
                return i

    def end_of_line(self, i):
        i = self.skip_ws(i)
        i = self.skip_comment(i)
        if i < self.n:
            if self.s[i] != "\n":
                self.err("unexpected content after value", i)
            i += 1
        return i

    # ---- main
    def parse(self):
        s, n = self.s, self.n
        cur = self.doc
        i = 0
        while True:
            i = self.skip_ws(i)
            if i >= n:
                break
            c = s[i]
            if c == "#":
                i = self.end_of_line(i)
            elif c == "\n":
                i += 1
            elif c == "[":
                if s.startswith("[[", i):
                    i, cur = self.aot_header(i + 2)
                else:
                    i, cur = self.table_header(i + 1)
                i = self.end_of_line(i)
            else:
                i = self.key_value(i, cur)
                i = self.end_of_line(i)
        return self.doc

    # ---- keys
    def parse_key(self, i):
        parts = []
        while True:
            i = self.skip_ws(i)
            if i >= self.n:
                self.err("expected key", i)
            c = self.s[i]
            if c == '"':
                i, k = self.basic_string(i + 1)
            elif c == "'":
                i, k = self.literal_string(i + 1)
            else:
                m = _BARE.match(self.s, i)
                if not m:
                    self.err("invalid key", i)
                k = m.group()
                i = m.end()
            parts.append(k)
            i = self.skip_ws(i)
            if i < self.n and self.s[i] == ".":
                i += 1
                continue
            return i, parts

    def descend(self, cur, key, pos):
        """walk into an existing table (through arrays of tables) for a header"""
        v = cur[key]
        if isinstance(v, list):
            if id(v) not in self.aot or not v:
                self.err("cannot extend a static array", pos)
            v = v[-1]
        if not isinstance(v, dict) or id(v) in self.frozen_ids:
            self.err("cannot extend value", pos)
        return v

    frozen_ids = None

    def header_parents(self, parts, pos):
        cur = self.doc
        for k in parts[:-1]:
            if k in cur:
                cur = self.descend(cur, k, pos)
            else:
                d = {}
                self.implicit.add(id(d))
                cur[k] = d
                cur = d
        return cur

    def table_header(self, i):
        pos = i
        i, parts = self.parse_key(i)
        i = self.skip_ws(i)
        if i >= self.n or self.s[i] != "]":
            self.err("unclosed table header", i)
        i += 1
        cur = self.header_parents(parts, pos)
        k = parts[-1]
        if k in cur:
            v = cur[k]
            if isinstance(v, dict) and id(v) in self.implicit and id(v) not in self.frozen_ids:
                self.implicit.discard(id(v))
                return i, v
            self.err("table already defined", pos)
        d = {}
        cur[k] = d
        return i, d

    def aot_header(self, i):
        pos = i
        i, parts = self.parse_key(i)
        i = self.skip_ws(i)
        if not self.s.startswith("]]", i):
            self.err("unclosed array-of-tables header", i)
        i += 2
        cur = self.header_parents(parts, pos)
        k = parts[-1]
        d = {}
        if k in cur:
            v = cur[k]
            if not isinstance(v, list) or id(v) not in self.aot:
                self.err("cannot redefine as array of tables", pos)
            v.append(d)
        else:
            v = [d]
            self.aot.add(id(v))
            cur[k] = v
        return i, d

    def key_value(self, i, table):
        pos = i
        i, parts = self.parse_key(i)
        i = self.skip_ws(i)
        if i >= self.n or self.s[i] != "=":
            self.err("expected '='", i)
        i = self.skip_ws(i + 1)
        if i >= self.n or self.s[i] in "\n#":
            self.err("missing value", i)
        cur = table
        for k in parts[:-1]:
            if k in cur:
                v = cur[k]
                if not isinstance(v, dict) or id(v) not in self.dotted:
                    self.err("cannot extend value with dotted key", pos)
                cur = v
            else:
                d = {}
                self.dotted.add(id(d))
                cur[k] = d
                cur = d
        k = parts[-1]
        if k in cur:
            self.err("duplicate key", pos)
        i, v = self.value(i)
        cur[k] = v
        return i

    # ---- values
    def value(self, i):
        s, n = self.s, self.n
        if i >= n:
            self.err("missing value", i)
        c = s[i]
        if c == '"':
            if s.startswith('"""', i):
                return self.ml_basic(i + 3)
            return self.basic_string(i + 1)
        if c == "'":
            if s.startswith("'''", i):
                return self.ml_literal(i + 3)
            return self.literal_string(i + 1)
        if c == "[":
            return self.array(i + 1)
        if c == "{":
            return self.inline_table(i + 1)
        return self.scalar(i)

    def array(self, i):
        out = []
        while True:
            i = self.skip_ws_nl(i)
            if i >= self.n:
                self.err("unclosed array", i)
            if self.s[i] == "]":
                return i + 1, out
            i, v = self.value(i)
            out.append(v)
            i = self.skip_ws_nl(i)
            if i >= self.n:
                self.err("unclosed array", i)
            c = self.s[i]
            if c == ",":
                i += 1
            elif c == "]":
                return i + 1, out
            else:
                self.err("expected ',' or ']'", i)

    def inline_table(self, i):
        t = {}
        first = True
        while True:
            i = self.skip_ws_nl(i)
            if i >= self.n:
                self.err("unclosed inline table", i)
            if self.s[i] == "}":
                break
            i = self.key_value(i, t)
            i = self.skip_ws_nl(i)
            if i >= self.n:
                self.err("unclosed inline table", i)
            c = self.s[i]
            if c == ",":
                i += 1
            elif c == "}":
                break
            else:
                self.err("expected ',' or '}'", i)
        self.freeze(t)
        return i + 1, t

    def freeze(self, t):
        self.frozen_ids.add(id(t))
        for v in t.values():
            if isinstance(v, dict) and id(v) in self.dotted:
                self.freeze(v)

    def scalar(self, i):
        s, n = self.s, self.n
        m = _DT.match(s, i)
        if m:
            return self.datetime(m, i)
        m = _LT.match(s, i)
        if m and not (m.end() < n and s[m.end()] not in _TOKEN_END):
            return m.end(), self.mk_time(m, 1, i)
        j = i
        while j < n and s[j] not in _TOKEN_END:
            j += 1
        tok = s[i:j]
        if not tok:
            self.err("invalid value", i)
        if tok == "true":
            return j, True
        if tok == "false":
            return j, False
        if _DEC.fullmatch(tok):
            return j, int(tok.replace("_", ""))
        if _HEX.fullmatch(tok):
            return j, int(tok[2:].replace("_", ""), 16)
        if _OCT.fullmatch(tok):
            return j, int(tok[2:].replace("_", ""), 8)
        if _BIN.fullmatch(tok):
            return j, int(tok[2:].replace("_", ""), 2)
        if _FLOAT.fullmatch(tok) or _SPECIAL.fullmatch(tok):
            if self.pf is float:
                r = float(tok.replace("_", ""))
            else:
                r = self.pf(tok)
                if isinstance(r, (dict, list)):
                    raise ValueError(
                        "parse_float must not return a dict or list")
            return j, r
        self.err("invalid value", i)

    def mk_time(self, m, g, pos):
        h, mi, sec, frac = m.group(g, g + 1, g + 2, g + 3)
        h, mi = int(h), int(mi)
        sec = int(sec) if sec else 0
        if h > 23 or mi > 59 or sec > 59:
            self.err("invalid time", pos)
        us = int((frac + "000000")[:6]) if frac else 0
        return time(h, mi, sec, us)

    def datetime(self, m, pos):
        end = m.end()
        if end < self.n and self.s[end] not in _TOKEN_END:
            self.err("invalid date-time", pos)
        try:
            d = date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            self.err("invalid date", pos)
        if m.group(4) is None:
            return end, d
        t = self.mk_time(m, 4, pos)
        tz = None
        if m.group(8):
            tz = timezone.utc
        elif m.group(9):
            oh, om = int(m.group(10)), int(m.group(11))
            if oh > 23 or om > 59:
                self.err("invalid offset", pos)
            delta = timedelta(hours=oh, minutes=om)
            tz = timezone(delta if m.group(9) == "+" else -delta)
        return end, datetime.combine(d, t).replace(tzinfo=tz)

    # ---- strings
    def check_char(self, c, i, multiline):
        if (c < " " and c != "\t" and not (multiline and c == "\n")) or c == "\x7f":
            self.err("control character in string", i)

    def escape(self, i):
        """s[i] is the char after a backslash; returns (new_i, text)"""
        s = self.s
        if i >= self.n:
            self.err("unterminated escape", i)
        c = s[i]
        if c in _ESC:
            return i + 1, _ESC[c]
        ln = {"x": 2, "u": 4, "U": 8}.get(c)
        if ln:
            h = s[i + 1:i + 1 + ln]
            if len(h) != ln or any(x not in _HEXD for x in h):
                self.err("invalid unicode escape", i)
            cp = int(h, 16)
            if 0xD800 <= cp <= 0xDFFF or cp > 0x10FFFF:
                self.err("invalid unicode scalar value", i)
            return i + 1 + ln, chr(cp)
        self.err("invalid escape", i)

    def basic_string(self, i):
        s, n = self.s, self.n
        out = []
        while True:
            if i >= n:
                self.err("unterminated string", i)
            c = s[i]
            if c == '"':
                return i + 1, "".join(out)
            if c == "\\":
                i, t = self.escape(i + 1)
                out.append(t)
                continue
            if c == "\n":
                self.err("newline in string", i)
            self.check_char(c, i, False)
            out.append(c)
            i += 1

    def literal_string(self, i):
        s, n = self.s, self.n
        j = i
        while True:
            if j >= n:
                self.err("unterminated string", j)
            c = s[j]
            if c == "'":
                return j + 1, s[i:j]
            if c == "\n":
                self.err("newline in string", j)
            self.check_char(c, j, False)
            j += 1

    def ml_basic(self, i):
        s, n = self.s, self.n
        if i < n and s[i] == "\n":
            i += 1
        out = []
        while True:
            if i >= n:
                self.err("unterminated string", i)
            c = s[i]
            if c == '"':
                j = i
                while j < n and s[j] == '"':
                    j += 1
                run = j - i
                if run < 3:
                    out.append('"' * run)
                    i = j
                    continue
                if run > 5:
                    self.err("too many quotes", i)
                out.append('"' * (run - 3))
                return j, "".join(out)
            if c == "\\":
                j = i + 1
                k = j
                while k < n and s[k] in _WS:
                    k += 1
                if k < n and s[k] == "\n":
                    while k < n and s[k] in " \t\n":
                        k += 1
                    i = k
                    continue
                i, t = self.escape(i + 1)
                out.append(t)
                continue
            self.check_char(c, i, True)
            out.append(c)
            i += 1

    def ml_literal(self, i):
        s, n = self.s, self.n
        if i < n and s[i] == "\n":
            i += 1
        out = []
        while True:
            if i >= n:
                self.err("unterminated string", i)
            c = s[i]
            if c == "'":
                j = i
                while j < n and s[j] == "'":
                    j += 1
                run = j - i
                if run < 3:
                    out.append("'" * run)
                    i = j
                    continue
                if run > 5:
                    self.err("too many quotes", i)
                out.append("'" * (run - 3))
                return j, "".join(out)
            self.check_char(c, i, True)
            out.append(c)
            i += 1


def _orig_pos(orig, pos):
    """map an offset in the CRLF-normalised text back to the original"""
    if "\r\n" not in orig:
        return pos
    count = 0
    i = 0
    n = len(orig)
    while i < n:
        if count >= pos:
            return i
        if orig[i] == "\r" and i + 1 < n and orig[i + 1] == "\n":
            i += 1
        i += 1
        count += 1
    return n


def loads(s, *, parse_float=float):
    """Parse a TOML document from a str. spec: N-000274..N-000296"""
    if not isinstance(s, str):
        raise TypeError("Expected str object, not %r" % type(s).__name__)
    text = s.replace("\r\n", "\n")
    p = _Parser(text, parse_float)
    p.frozen_ids = set()
    try:
        return p.parse()
    except _Err as e:
        raise TOMLDecodeError(e.msg, s, _orig_pos(s, e.pos)) from None
    except RecursionError:
        raise TOMLDecodeError("document nested too deeply", s, 0) from None


def load(fp, *, parse_float=float):
    """Parse a TOML document from a binary file. spec: N-000299..N-000306"""
    b = fp.read()
    if isinstance(b, str):
        raise TypeError(
            "File must be opened in binary mode, e.g. use `open('foo.toml', 'rb')`")
    try:
        s = bytes(b).decode("utf-8")
    except UnicodeDecodeError as e:
        raise TOMLDecodeError("invalid UTF-8: %s" % e.reason, "", 0) from None
    return loads(s, parse_float=parse_float)
