# spec: N-000255 parser only; no writer, no CLI, no I/O besides reading fp.
import re
from datetime import date, datetime, time, timedelta, timezone


class TOMLDecodeError(ValueError):
    """Raised when a document is not valid TOML v1.1.0."""  # spec: N-000307

    def __init__(self, msg, doc, pos):
        self.msg = msg
        self.doc = doc
        self.pos = pos
        if isinstance(doc, str) and isinstance(pos, int) and 0 <= pos < len(doc):
            self.lineno = doc.count("\n", 0, pos) + 1
            self.colno = pos - doc.rfind("\n", 0, pos)
            where = "line %d, column %d" % (self.lineno, self.colno)
        else:
            if isinstance(doc, str) and isinstance(pos, int):
                p = min(max(pos, 0), len(doc))
                self.lineno = doc.count("\n", 0, p) + 1
                self.colno = p - doc.rfind("\n", 0, p)
            else:
                self.lineno = self.colno = 1
            where = "end of document"
        self.where = where
        ValueError.__init__(self, "%s (at %s)" % (msg, where))

    def __reduce__(self):
        return (self.__class__, (self.msg, self.doc, self.pos))


WS = " \t"
BARE = re.compile(r"[A-Za-z0-9_-]+")
RE_DT = re.compile(
    r"(\d{4})-(\d{2})-(\d{2})"
    r"(?:[Tt ](\d{2}):(\d{2})(?::(\d{2})(?:\.(\d+))?)?"
    r"(Z|z|[+-]\d{2}:\d{2})?)?"
)
RE_TIME = re.compile(r"(\d{2}):(\d{2})(?::(\d{2})(?:\.(\d+))?)?")
RE_FLOAT = re.compile(
    r"[+-]?(?:0|[1-9](?:_?\d)*)(?:\.\d+(?:_\d+)*(?:[eE][+-]?\d+(?:_\d+)*)?|[eE][+-]?\d+(?:_\d+)*)"
)
RE_INT = re.compile(r"[+-]?(?:0|[1-9](?:_?\d)*)")
RE_HEX = re.compile(r"0x[0-9A-Fa-f]+(?:_[0-9A-Fa-f]+)*")
RE_OCT = re.compile(r"0o[0-7]+(?:_[0-7]+)*")
RE_BIN = re.compile(r"0b[01]+(?:_[01]+)*")
RE_SPECIAL = re.compile(r"[+-]?(?:inf|nan)")
ESC = {"b": "\b", "t": "\t", "n": "\n", "f": "\f", "r": "\r",
       "e": "\x1b", '"': '"', "\\": "\\"}
HEXD = set("0123456789abcdefABCDEF")
DELIMS = set(" \t\r\n,]}#")

FROZEN, EXPLICIT, DOTTED, AOT = 1, 2, 4, 8


def _days_in_month(y, m):
    if m == 2:
        return 29 if (y % 4 == 0 and (y % 100 != 0 or y % 400 == 0)) else 28
    return 30 if m in (4, 6, 9, 11) else 31


class _Parser:
    def __init__(self, doc, parse_float):
        self.doc = doc
        self.n = len(doc)
        self.i = 0
        self.pf = parse_float
        self.flags = {}

    def err(self, msg, pos=None):
        return TOMLDecodeError(msg, self.doc, self.i if pos is None else pos)

    # ---- whitespace / comments
    def skip_ws(self):
        d, i, n = self.doc, self.i, self.n
        while i < n and d[i] in WS:
            i += 1
        self.i = i

    def skip_comment(self):
        d = self.doc
        if self.i < self.n and d[self.i] == "#":
            i = self.i + 1
            while i < self.n and d[i] != "\n":
                c = d[i]
                if c == "\r":
                    if i + 1 < self.n and d[i + 1] == "\n":
                        break
                    raise self.err("Invalid control character in comment", i)
                if (c < " " and c != "\t") or c == "\x7f":
                    raise self.err("Invalid control character in comment", i)
                i += 1
            self.i = i

    def skip_newline(self):
        """Consume one line ending if present."""
        d = self.doc
        if self.i < self.n:
            if d[self.i] == "\n":
                self.i += 1
                return True
            if d[self.i] == "\r" and d.startswith("\r\n", self.i):
                self.i += 2
                return True
        return False

    def skip_ws_nl_comments(self):
        while True:
            self.skip_ws()
            self.skip_comment()
            if not self.skip_newline():
                return

    def end_of_line(self):
        self.skip_ws()
        self.skip_comment()
        if self.i >= self.n:
            return
        if not self.skip_newline():
            raise self.err("Expected end of line")

    # ---- document
    def parse(self):
        root = {}
        cur = root
        cur_path = ()
        while True:
            self.skip_ws()
            if self.i >= self.n:
                break
            c = self.doc[self.i]
            if c == "#":
                self.skip_comment()
                if self.i < self.n and not self.skip_newline():
                    raise self.err("Expected end of line")
                continue
            if c == "\n" or self.doc.startswith("\r\n", self.i):
                self.skip_newline()
                continue
            if c == "[":
                cur, cur_path = self.header(root)
                self.end_of_line()
                continue
            parts, kpos = self.key()
            self.skip_ws()
            if self.i >= self.n or self.doc[self.i] != "=":
                raise self.err("Expected '=' after key")
            self.i += 1
            self.skip_ws()
            val = self.value()
            self.assign(cur, cur_path, self.flags, parts, val, kpos)
            self.end_of_line()
        return root

    # ---- keys
    def key_part(self):
        d = self.doc
        if self.i >= self.n:
            raise self.err("Expected key")
        c = d[self.i]
        if c == '"':
            return self.basic_string()
        if c == "'":
            return self.literal_string()
        m = BARE.match(d, self.i)
        if not m:
            raise self.err("Invalid key")
        self.i = m.end()
        return m.group()

    def key(self):
        pos = self.i
        parts = [self.key_part()]
        while True:
            self.skip_ws()
            if self.i < self.n and self.doc[self.i] == ".":
                self.i += 1
                self.skip_ws()
                parts.append(self.key_part())
            else:
                return parts, pos

    def assign(self, table, base, flags, parts, val, pos):
        path = base
        for p in parts[:-1]:
            path = path + (p,)
            f = flags.get(path, 0)
            if f & FROZEN:
                raise self.err("Cannot extend a frozen table or array", pos)
            if p in table:
                nxt = table[p]
                if not isinstance(nxt, dict) or not (f & DOTTED):
                    raise self.err("Cannot redefine key '%s'" % p, pos)
                table = nxt
            else:
                nxt = {}
                table[p] = nxt
                flags[path] = DOTTED
                table = nxt
        last = parts[-1]
        if last in table:
            raise self.err("Duplicate key '%s'" % last, pos)
        table[last] = val
        if isinstance(val, (dict, list)):
            path = path + (last,)
            flags[path] = flags.get(path, 0) | FROZEN

    def header(self, root):
        pos = self.i
        is_aot = self.doc.startswith("[[", pos)
        self.i += 2 if is_aot else 1
        self.skip_ws()
        parts, _ = self.key()
        self.skip_ws()
        close = "]]" if is_aot else "]"
        if not self.doc.startswith(close, self.i):
            raise self.err("Expected '%s'" % close)
        self.i += len(close)
        flags = self.flags
        table = root
        path = ()
        for p in parts[:-1]:
            path = path + (p,)
            f = flags.get(path, 0)
            if f & FROZEN:
                raise self.err("Cannot extend a frozen table or array", pos)
            if p in table:
                nxt = table[p]
                if isinstance(nxt, list):
                    if not (f & AOT) or not nxt:
                        raise self.err("Invalid table path", pos)
                    nxt = nxt[-1]
                elif not isinstance(nxt, dict):
                    raise self.err("Invalid table path", pos)
                table = nxt
            else:
                nxt = {}
                table[p] = nxt
                table = nxt
        last = parts[-1]
        path = path + (last,)
        f = flags.get(path, 0)
        if is_aot:
            if last in table:
                lst = table[last]
                if not (f & AOT) or not isinstance(lst, list):
                    raise self.err("Cannot define array of tables here", pos)
            else:
                lst = []
                table[last] = lst
                flags[path] = AOT
            item = {}
            lst.append(item)
            n = len(path)
            for k in [k for k in flags if len(k) > n and k[:n] == path]:
                del flags[k]
            return item, path
        if last in table:
            t = table[last]
            if not isinstance(t, dict) or f & (FROZEN | EXPLICIT | DOTTED):
                raise self.err("Cannot redefine table '%s'" % last, pos)
            flags[path] = f | EXPLICIT
            return t, path
        t = {}
        table[last] = t
        flags[path] = EXPLICIT
        return t, path

    # ---- values
    def value(self):
        d = self.doc
        if self.i >= self.n:
            raise self.err("Expected a value")
        c = d[self.i]
        if c == '"':
            if d.startswith('"""', self.i):
                return self.ml_basic()
            return self.basic_string()
        if c == "'":
            if d.startswith("'''", self.i):
                return self.ml_literal()
            return self.literal_string()
        if c == "[":
            return self.array()
        if c == "{":
            return self.inline_table()
        return self.scalar()

    def array(self):
        self.i += 1
        out = []
        while True:
            self.skip_ws_nl_comments()
            if self.i >= self.n:
                raise self.err("Unterminated array")
            if self.doc[self.i] == "]":
                self.i += 1
                return out
            out.append(self.value())
            self.skip_ws_nl_comments()
            if self.i >= self.n:
                raise self.err("Unterminated array")
            c = self.doc[self.i]
            if c == ",":
                self.i += 1
            elif c == "]":
                self.i += 1
                return out
            else:
                raise self.err("Expected ',' or ']' in array")

    def inline_table(self):
        self.i += 1
        out = {}
        flags = {}
        while True:
            self.skip_ws_nl_comments()
            if self.i >= self.n:
                raise self.err("Unterminated inline table")
            if self.doc[self.i] == "}":
                self.i += 1
                return out
            parts, kpos = self.key()
            self.skip_ws()
            if self.i >= self.n or self.doc[self.i] != "=":
                raise self.err("Expected '=' after key")
            self.i += 1
            self.skip_ws()
            val = self.value()
            self.assign(out, (), flags, parts, val, kpos)
            self.skip_ws_nl_comments()
            if self.i >= self.n:
                raise self.err("Unterminated inline table")
            c = self.doc[self.i]
            if c == ",":
                self.i += 1
            elif c == "}":
                self.i += 1
                return out
            else:
                raise self.err("Expected ',' or '}' in inline table")

    def check_delim(self):
        if self.i < self.n and self.doc[self.i] not in DELIMS:
            raise self.err("Invalid value")

    def scalar(self):
        d, i = self.doc, self.i
        if d.startswith("true", i):
            self.i += 4
            self.check_delim()
            return True
        if d.startswith("false", i):
            self.i += 5
            self.check_delim()
            return False
        m = RE_DT.match(d, i)
        if m:
            return self.datetime(m)
        m = RE_TIME.match(d, i)
        if m:
            h, mi, s, frac = m.groups()
            self.i = m.end()
            self.check_delim()
            return self.mktime(h, mi, s, frac, i)
        for rx, base in ((RE_HEX, 16), (RE_OCT, 8), (RE_BIN, 2)):
            m = rx.match(d, i)
            if m:
                self.i = m.end()
                self.check_delim()
                return int(m.group().replace("_", ""), base)
        m = RE_FLOAT.match(d, i) or RE_SPECIAL.match(d, i)
        if m:
            self.i = m.end()
            self.check_delim()
            tok = m.group()
            if self.pf is float:
                return float(tok.replace("_", ""))
            res = self.pf(tok)
            if isinstance(res, (dict, list)):  # spec: N-000296
                raise ValueError("parse_float must not return a dict or list")
            return res
        m = RE_INT.match(d, i)
        if m:
            self.i = m.end()
            self.check_delim()
            return int(m.group().replace("_", ""))
        raise self.err("Invalid value")

    def mktime(self, h, mi, s, frac, pos):
        h, mi = int(h), int(mi)
        s = int(s) if s else 0
        if h > 23 or mi > 59 or s > 59:
            raise self.err("Invalid time", pos)
        us = int((frac + "000000")[:6]) if frac else 0
        return time(h, mi, s, us)

    def datetime(self, m):
        pos = self.i
        y, mo, dd, h, mi, s, frac, off = m.groups()
        self.i = m.end()
        self.check_delim()
        y, mo, dd = int(y), int(mo), int(dd)
        if not (1 <= mo <= 12 and 1 <= dd <= _days_in_month(y, mo)) or y < 1:
            raise self.err("Invalid date", pos)
        if h is None:
            return date(y, mo, dd)
        t = self.mktime(h, mi, s, frac, pos)
        tz = None
        if off:
            if off in ("Z", "z"):
                tz = timezone.utc
            else:
                oh, om = int(off[1:3]), int(off[4:6])
                if oh > 23 or om > 59:
                    raise self.err("Invalid offset", pos)
                delta = timedelta(hours=oh, minutes=om)
                tz = timezone(-delta if off[0] == "-" else delta)
        return datetime(y, mo, dd, t.hour, t.minute, t.second, t.microsecond, tz)

    # ---- strings
    def escape(self, i):
        """doc[i] is the char after a backslash. Returns (text, new_i)."""
        d = self.doc
        if i >= self.n:
            raise self.err("Unterminated string", i)
        c = d[i]
        if c in ESC:
            return ESC[c], i + 1
        ln = {"x": 2, "u": 4, "U": 8}.get(c)
        if ln:
            h = d[i + 1:i + 1 + ln]
            if len(h) != ln or any(ch not in HEXD for ch in h):
                raise self.err("Invalid escape sequence", i - 1)
            cp = int(h, 16)
            if cp > 0x10FFFF or 0xD800 <= cp <= 0xDFFF:
                raise self.err("Invalid Unicode scalar value", i - 1)
            return chr(cp), i + 1 + ln
        raise self.err("Invalid escape sequence", i - 1)

    def basic_string(self):
        d = self.doc
        i = self.i + 1
        out = []
        start = i
        while True:
            if i >= self.n:
                raise self.err("Unterminated string", self.i)
            c = d[i]
            if c == '"':
                out.append(d[start:i])
                self.i = i + 1
                return "".join(out)
            if c == "\\":
                out.append(d[start:i])
                t, i = self.escape(i + 1)
                out.append(t)
                start = i
                continue
            if (c < " " and c != "\t") or c == "\x7f":
                raise self.err("Invalid control character in string", i)
            i += 1

    def literal_string(self):
        d = self.doc
        i = self.i + 1
        start = i
        while True:
            if i >= self.n:
                raise self.err("Unterminated string", self.i)
            c = d[i]
            if c == "'":
                self.i = i + 1
                return d[start:i]
            if (c < " " and c != "\t") or c == "\x7f":
                raise self.err("Invalid control character in string", i)
            i += 1

    def ml_open(self):
        i = self.i + 3
        d = self.doc
        if d.startswith("\r\n", i):
            i += 2
        elif d.startswith("\n", i):
            i += 1
        return i

    def ml_basic(self):
        d = self.doc
        i = self.ml_open()
        out = []
        n = self.n
        while True:
            if i >= n:
                raise self.err("Unterminated string", self.i)
            c = d[i]
            if c == '"':
                j = i
                while j < n and d[j] == '"':
                    j += 1
                run = j - i
                if run >= 3:
                    if run > 5:
                        raise self.err("Invalid quotes in string", i + 5)
                    out.append('"' * (run - 3))
                    self.i = j
                    return "".join(out)
                out.append('"' * run)
                i = j
                continue
            if c == "\\":
                j = i + 1
                while j < n and d[j] in WS:
                    j += 1
                if j < n and (d[j] == "\n" or d.startswith("\r\n", j)):
                    while j < n and (d[j] in " \t\n" or d.startswith("\r\n", j)):
                        j += 2 if d[j] == "\r" else 1
                    i = j
                    continue
                t, i = self.escape(i + 1)
                out.append(t)
                continue
            if c == "\r":
                if d.startswith("\r\n", i):
                    out.append("\n")
                    i += 2
                    continue
                raise self.err("Invalid carriage return in string", i)
            if (c < " " and c not in "\t\n") or c == "\x7f":
                raise self.err("Invalid control character in string", i)
            out.append(c)
            i += 1

    def ml_literal(self):
        d = self.doc
        i = self.ml_open()
        out = []
        n = self.n
        while True:
            if i >= n:
                raise self.err("Unterminated string", self.i)
            c = d[i]
            if c == "'":
                j = i
                while j < n and d[j] == "'":
                    j += 1
                run = j - i
                if run >= 3:
                    if run > 5:
                        raise self.err("Invalid quotes in string", i + 5)
                    out.append("'" * (run - 3))
                    self.i = j
                    return "".join(out)
                out.append("'" * run)
                i = j
                continue
            if c == "\r":
                if d.startswith("\r\n", i):
                    out.append("\n")
                    i += 2
                    continue
                raise self.err("Invalid carriage return in string", i)
            if (c < " " and c not in "\t\n") or c == "\x7f":
                raise self.err("Invalid control character in string", i)
            out.append(c)
            i += 1


def loads(s, *, parse_float=float):
    """Parse a TOML v1.1.0 document from a str."""
    if not isinstance(s, str):
        raise TypeError("Expected str object, not '%s'" % type(s).__name__)
    return _Parser(s, parse_float).parse()


def load(fp, *, parse_float=float):
    """Parse a TOML v1.1.0 document from a binary file object."""
    b = fp.read()
    if isinstance(b, str) or not isinstance(b, (bytes, bytearray, memoryview)):
        raise TypeError("File must be opened in binary mode, e.g. use `open('foo.toml', 'rb')`")
    try:
        s = bytes(b).decode("utf-8")
    except UnicodeDecodeError as e:
        raise TOMLDecodeError("Invalid UTF-8: %s" % e.reason, "", 0)
    return loads(s, parse_float=parse_float)
