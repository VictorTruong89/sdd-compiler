"""Tomlparse: a pure-Python parser for TOML v1.1.0.

Public names: ``loads``, ``load`` and ``TOMLDecodeError``.
"""

from ._errors import TOMLDecodeError
from ._parser import decode as _decode

# spec: N-000001 N-000002 N-000003 N-000004 N-000005 N-000006 N-000007
# spec: N-000008 N-000009 N-000010 N-000011
# spec: N-000012 N-000013 N-000014 N-000015 N-000016 N-000017 N-000018
# spec: N-000019 N-000020 N-000021 N-000022 N-000023 N-000024 N-000025
# spec: N-000026 N-000027 N-000028 N-000029 N-000030
# spec: N-000031 N-000032 N-000033 N-000034 N-000035 N-000036 N-000037
# spec: N-000038 N-000039
# spec: N-000040 N-000043 N-000044 N-000045 N-000046 N-000047 N-000048
# spec: N-000049 N-000050 N-000051 N-000052 N-000053 N-000054 N-000055
# spec: N-000056 N-000057 N-000058 N-000059 N-000060 N-000061 N-000062
# spec: N-000234 N-000235 N-000236 N-000237 N-000238 N-000239 N-000240
# spec: N-000241 N-000242 N-000243 N-000244 N-000245 N-000246 N-000247
# spec: N-000248 N-000249 N-000250 N-000251 N-000252 N-000253 N-000254

__version__ = "2.4.0"
__all__ = ["loads", "load", "TOMLDecodeError"]


# spec: N-000266 N-000267 N-000268 N-000269 N-000270 N-000271 N-000272
# spec: N-000273 N-000274 N-000275 N-000276 N-000277 N-000278 N-000279
# spec: N-000280 N-000281 N-000282 N-000283 N-000284 N-000285 N-000286
# spec: N-000287 N-000288 N-000289 N-000290 N-000291 N-000292 N-000293
# spec: N-000294 N-000295 N-000296 N-000297 N-000298 N-000299 N-000300
# spec: N-000301 N-000302 N-000303 N-000304 N-000305 N-000306
# spec: N-000255 N-000256 N-000257 N-000258 N-000259 N-000260 N-000261
# spec: N-000262 N-000263 N-000264 N-000265


def loads(s, *, parse_float=float):
    """Parse a TOML v1.1.0 document from a text string into a dict.

    ``parse_float`` is called with each float's text as written and its
    return value is stored in place of the float.
    """
    if not isinstance(s, str):
        raise TypeError(
            "loads() expects a str, not %s" % type(s).__name__
        )
    return _decode(s, parse_float)


def load(fp, *, parse_float=float):
    """Parse a TOML v1.1.0 document from a binary file object into a dict.

    ``fp`` must be opened for binary reading; its bytes are decoded as UTF-8.
    """
    read = getattr(fp, "read", None)
    if not callable(read):
        raise TypeError("load() expects a binary file object with a read() method")
    data = read()
    if isinstance(data, str):
        raise TypeError("load() expects a file object opened in binary mode")
    if not isinstance(data, (bytes, bytearray, memoryview)):
        raise TypeError(
            "load() expects bytes from read(), not %s" % type(data).__name__
        )
    data = bytes(data)
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        text = data.decode("utf-8", "replace")
        pos = len(data[: exc.start].decode("utf-8", "replace"))
        raise TOMLDecodeError("invalid UTF-8 in document", text, pos) from None
    return loads(text, parse_float=parse_float)
