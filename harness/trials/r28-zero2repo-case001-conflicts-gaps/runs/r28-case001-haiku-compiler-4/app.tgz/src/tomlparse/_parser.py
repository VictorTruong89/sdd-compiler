"""TOML v1.1.0 decoder: a hand-written recursive-descent parser.

Positions are character offsets into the text as given, so a carriage-return
line-feed pair is two characters here and one line feed in the result.

Container kinds, tracked by identity, enforce the table rules:

* ``root``     the document mapping
* ``header``   a table defined by a ``[table]`` header (or an array-of-tables
               element)
* ``implicit`` a super-table created by a header path; may still be defined
               later by its own header
* ``dotted``   a table created by dotted keys; may take more dotted keys and
               undefined sub-tables by header, but cannot be defined by header
* ``inline``   an inline table (or an element of an inline array); frozen once
               written
* ``aot``      an array of tables (a list created by ``[[...]]``)
"""

import datetime as _dt
import re

from ._errors import TOMLDecodeError

# spec: N-000063 N-000064 N-000065 N-000066 N-000067 N-000068 N-000069
# spec: N-000070 N-000071 N-000072 N-000073 N-000074 N-000075 N-000076

# spec: N-000077 N-000078 N-000079 N-000080 N-000081 N-000082 N-000083
# spec: N-000084 N-000085 N-000086 N-000087 N-000088 N-000089 N-000090
# spec: N-000091 N-000092 N-000093 N-000094 N-000095 N-000096 N-000097
# spec: N-000098 N-000099 N-000100 N-000101 N-000102 N-000103 N-000104
# spec: N-000105 N-000106 N-000107 N-000108 N-000109 N-000110 N-000111
# spec: N-000112 N-000113 N-000114 N-000115 N-000116 N-000117 N-000118
# spec: N-000119 N-000120 N-000121 N-000122
# spec: N-000181 N-000182 N-000183 N-000184 N-000185 N-000186 N-000187
# spec: N-000188 N-000189 N-000193 N-000194 N-000195 N-000196

_BARE_KEY_CHARS = frozenset(
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-"
)
_HEX_CHARS = frozenset("0123456789abcdefABCDEF")
_BASIC_ESCAPES = {
    "b": "\b",
    "t": "\t",
    "n": "\n",
    "f": "\f",
    "r": "\r",
    "e": "\x1b",
    '"': '"',
    "\\": "\\",
}
_ESCAPE_WIDTHS = {"x": 2, "u": 4, "U": 8}

# Runs of characters that may appear unchanged in a single-line string.
# Tab is allowed; other control characters, quotes and backslash are not.
_BASIC_RUN = re.compile(r'[^"\\\x00-\x08\x0a-\x1f\x7f]+')
_LITERAL_RUN = re.compile(r"[^'\x00-\x08\x0a-\x1f\x7f]+")

_RE_DATETIME = re.compile(
    r"([0-9]{4})-([0-9]{2})-([0-9]{2})"
    r"(?:[Tt ]([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?"
    r"([Zz]|[+-][0-9]{2}:[0-9]{2})?)?"
)
_RE_TIME = re.compile(r"([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?")
_RE_PREFIXED = re.compile(
    r"0x[0-9a-fA-F]+(?:_[0-9a-fA-F]+)*"
    r"|0o[0-7]+(?:_[0-7]+)*"
    r"|0b[01]+(?:_[01]+)*"
)
_RE_SPECIAL = re.compile(r"[+-]?(?:inf|nan)")
_RE_DEC = re.compile(
    r"[+-]?(?:0|[1-9](?:_?[0-9])*)"
    r"(\.[0-9](?:_?[0-9])*)?"
    r"([eE][+-]?[0-9](?:_?[0-9])*)?"
)


_INT_CHUNK = 1000


def _decimal_int(text):
    """int() for a signed decimal digit string of any length.

    CPython limits str->int conversion to a few thousand digits; longer TOML
    integers are converted in chunks so every document the spec allows parses.
    """
    # spec: N-000144 N-000147
    sign = -1 if text.startswith("-") else 1
    digits = text.lstrip("+-")
    if len(digits) <= _INT_CHUNK:
        return int(text)
    value = 0
    for start in range(0, len(digits), _INT_CHUNK):
        chunk = digits[start : start + _INT_CHUNK]
        value = value * (10 ** len(chunk)) + int(chunk)
    return sign * value


def _micro(fraction):
    # spec: N-000157 N-000158
    if not fraction:
        return 0
    return int((fraction + "000000")[:6])


class _Parser:
    def __init__(self, text, parse_float):
        self.s = text
        self.n = len(text)
        self.i = 0
        self.parse_float = parse_float
        self._kinds = {}
        self._keep = []

    # ----- bookkeeping -------------------------------------------------

    def error(self, msg, pos=None):
        raise TOMLDecodeError(msg, self.s, self.i if pos is None else pos)

    def _mark(self, obj, kind):
        self._kinds[id(obj)] = kind
        self._keep.append(obj)

    def _kind(self, obj):
        return self._kinds.get(id(obj))

    # ----- whitespace, comments, line ends -----------------------------

    def _skip_ws(self):
        s, i, n = self.s, self.i, self.n
        while i < n and s[i] in " \t":
            i += 1
        self.i = i

    def _skip_comment(self):
        # spec: N-000107 N-000108 N-000109
        s, n = self.s, self.n
        i = self.i + 1
        while i < n:
            c = s[i]
            if c == "\n":
                break
            if c == "\r":
                if s.startswith("\n", i + 1):
                    break
                self.error("carriage return not part of a line ending", i)
            if c != "\t" and (c < " " or c == "\x7f"):
                self.error("control character in comment", i)
            i += 1
        self.i = i

    def _expect_eol(self):
        # spec: N-000113 N-000122
        self._skip_ws()
        if self.i >= self.n:
            return
        if self.s[self.i] == "#":
            self._skip_comment()
        if self.i >= self.n:
            return
        if self.s[self.i] == "\n":
            self.i += 1
        elif self.s.startswith("\r\n", self.i):
            self.i += 2
        else:
            self.error("expected end of line")

    def _skip_wsnl(self):
        # Whitespace, comments and line endings, as allowed inside arrays and
        # inline tables (TOML v1.1.0).
        s = self.s
        while True:
            self._skip_ws()
            if self.i >= self.n:
                return
            c = s[self.i]
            if c == "#":
                self._skip_comment()
            elif c == "\n":
                self.i += 1
            elif s.startswith("\r\n", self.i):
                self.i += 2
            else:
                return

    def _expect_char(self, ch):
        if self.i < self.n and self.s[self.i] == ch:
            self.i += 1
        else:
            self.error("expected %r" % ch)

    # ----- document ----------------------------------------------------

    def parse(self):
        root = {}
        self._mark(root, "root")
        cur = root
        s = self.s
        while True:
            self._skip_ws()
            if self.i >= self.n:
                break
            c = s[self.i]
            if c == "\n":
                self.i += 1
                continue
            if s.startswith("\r\n", self.i):
                self.i += 2
                continue
            if c == "#":
                self._skip_comment()
                continue
            if c == "[":
                cur = self._header(root)
            else:
                pos = self.i
                keys = self._dotted_key()
                self._skip_ws()
                self._expect_char("=")
                self._skip_ws()
                value = self._value()
                self._add(cur, keys, value, pos)
            self._expect_eol()
        return root

    # ----- keys --------------------------------------------------------

    def _key(self):
        # spec: N-000085 N-000086 N-000087 N-000088 N-000089 N-000090 N-000091
        # spec: N-000092 N-000113 N-000122
        s, n, i = self.s, self.n, self.i
        if i >= n:
            self.error("expected key")
        c = s[i]
        if c == '"':
            if s.startswith('"""', i):
                self.error("multiline string cannot be a key")
            return self._basic_string()
        if c == "'":
            if s.startswith("'''", i):
                self.error("multiline string cannot be a key")
            return self._literal_string()
        j = i
        while j < n and s[j] in _BARE_KEY_CHARS:
            j += 1
        if j == i:
            self.error("expected key")
        self.i = j
        return s[i:j]

    def _dotted_key(self):
        # spec: N-000093 N-000094
        parts = [self._key()]
        while True:
            self._skip_ws()
            if self.i < self.n and self.s[self.i] == ".":
                self.i += 1
                self._skip_ws()
                parts.append(self._key())
            else:
                return parts

    # ----- tables ------------------------------------------------------

    def _header(self, root):
        start = self.i
        self.i += 1
        is_aot = False
        if self.i < self.n and self.s[self.i] == "[":
            is_aot = True
            self.i += 1
        self._skip_ws()
        keys = self._dotted_key()
        self._skip_ws()
        self._expect_char("]")
        if is_aot:
            self._expect_char("]")
            return self._open_aot(root, keys, start)
        return self._open_table(root, keys, start)

    def _walk_parents(self, root, keys, pos):
        # spec: N-000096 N-000097 N-000099 N-000100 N-000101 N-000102
        cur = root
        for part in keys[:-1]:
            if part not in cur:
                new = {}
                self._mark(new, "implicit")
                cur[part] = new
                cur = new
                continue
            child = cur[part]
            if isinstance(child, list):
                if self._kind(child) != "aot":
                    self.error("cannot extend a static array with a table", pos)
                child = child[-1]
            if not isinstance(child, dict) or self._kind(child) == "inline":
                self.error("cannot extend %r as a table" % part, pos)
            cur = child
        return cur

    def _open_table(self, root, keys, pos):
        # spec: N-000096 N-000097 N-000098 N-000113 N-000114 N-000115
        # spec: N-000116 N-000117 N-000118
        cur = self._walk_parents(root, keys, pos)
        last = keys[-1]
        if last in cur:
            child = cur[last]
            if not isinstance(child, dict):
                self.error("cannot define table %r: key already holds a value" % last, pos)
            if self._kind(child) != "implicit":
                self.error("table %r is already defined" % last, pos)
            self._mark(child, "header")
            return child
        new = {}
        self._mark(new, "header")
        cur[last] = new
        return new

    def _open_aot(self, root, keys, pos):
        # spec: N-000099 N-000100 N-000101 N-000102 N-000119 N-000120 N-000121
        cur = self._walk_parents(root, keys, pos)
        last = keys[-1]
        new = {}
        self._mark(new, "header")
        if last in cur:
            child = cur[last]
            if not (isinstance(child, list) and self._kind(child) == "aot"):
                self.error("cannot append to %r as an array of tables" % last, pos)
            child.append(new)
            return new
        arr = [new]
        self._mark(arr, "aot")
        cur[last] = arr
        return new

    def _add(self, cur, keys, value, pos):
        # Dotted keys and key/value pairs.
        # spec: N-000093 N-000094 N-000095 N-000113 N-000114 N-000115
        # spec: N-000116 N-000117 N-000118 N-000121 N-000122
        for part in keys[:-1]:
            if part not in cur:
                new = {}
                self._mark(new, "dotted")
                cur[part] = new
                cur = new
                continue
            child = cur[part]
            if not isinstance(child, dict) or self._kind(child) != "dotted":
                self.error("cannot extend %r with dotted keys" % part, pos)
            cur = child
        last = keys[-1]
        if last in cur:
            self.error("duplicate key %r" % last, pos)
        cur[last] = value

    # ----- values ------------------------------------------------------

    def _value(self):
        # spec: N-000123 N-000124 N-000125 N-000126 N-000162 N-000164
        s, i = self.s, self.i
        if i >= self.n:
            self.error("expected value")
        c = s[i]
        if c == '"':
            if s.startswith('"""', i):
                return self._multiline_string('"', True)
            return self._basic_string()
        if c == "'":
            if s.startswith("'''", i):
                return self._multiline_string("'", False)
            return self._literal_string()
        if c == "[":
            return self._array()
        if c == "{":
            return self._inline_table()
        if s.startswith("true", i):
            self.i = i + 4
            return True
        if s.startswith("false", i):
            self.i = i + 5
            return False
        return self._number_or_datetime()

    def _number_or_datetime(self):
        # spec: N-000144 N-000145 N-000146 N-000147 N-000148 N-000149
        # spec: N-000150 N-000151 N-000152 N-000153 N-000154 N-000155
        # spec: N-000156 N-000157 N-000158 N-000159 N-000160 N-000161
        # spec: N-000163 N-000165 N-000166 N-000167 N-000168 N-000169
        # spec: N-000170 N-000171 N-000172 N-000173 N-000179 N-000180
        s, start = self.s, self.i
        m = _RE_DATETIME.match(s, start)
        if m:
            self.i = m.end()
            return self._make_datetime(m, start)
        m = _RE_TIME.match(s, start)
        if m:
            self.i = m.end()
            return self._make_time(m, start)
        m = _RE_PREFIXED.match(s, start)
        if m:
            self.i = m.end()
            text = m.group(0).replace("_", "")
            base = {"x": 16, "o": 8, "b": 2}[text[1]]
            return int(text[2:], base)
        m = _RE_SPECIAL.match(s, start)
        if m:
            self.i = m.end()
            return self._float(m.group(0))
        m = _RE_DEC.match(s, start)
        if m:
            self.i = m.end()
            text = m.group(0)
            if m.group(1) is not None or m.group(2) is not None:
                return self._float(text)
            return _decimal_int(text.replace("_", ""))
        self.error("invalid value", start)

    def _float(self, text):
        # spec: N-000148 N-000149 N-000150 N-000220 N-000221 N-000223
        # spec: N-000224 N-000225 N-000226 N-000227 N-000228 N-000229
        # spec: N-000230 N-000231 N-000232 N-000233
        if self.parse_float is float:
            return float(text.replace("_", ""))
        value = self.parse_float(text)
        if isinstance(value, (dict, list)):
            raise ValueError(
                "parse_float returned a dict or list, which is not allowed"
            )
        return value

    def _make_datetime(self, m, start):
        # spec: N-000151 N-000152 N-000153 N-000154 N-000155 N-000156
        # spec: N-000157 N-000158 N-000159 N-000179 N-000180
        year, month, day = int(m.group(1)), int(m.group(2)), int(m.group(3))
        try:
            date = _dt.date(year, month, day)
        except ValueError:
            self.error("invalid calendar date", start)
        if m.group(4) is None:
            return date
        hour, minute = int(m.group(4)), int(m.group(5))
        second = int(m.group(6)) if m.group(6) else 0
        micro = _micro(m.group(7))
        if hour > 23 or minute > 59 or second > 59:
            self.error("invalid time", start)
        offset = m.group(8)
        if offset is None:
            try:
                return _dt.datetime(year, month, day, hour, minute, second, micro)
            except ValueError:
                self.error("invalid date-time", start)
        if offset in ("Z", "z"):
            tz = _dt.timezone.utc
        else:
            oh, om = int(offset[1:3]), int(offset[4:6])
            if oh > 23 or om > 59:
                self.error("invalid UTC offset", start)
            delta = _dt.timedelta(hours=oh, minutes=om)
            tz = _dt.timezone(-delta if offset[0] == "-" else delta)
        try:
            return _dt.datetime(
                year, month, day, hour, minute, second, micro, tzinfo=tz
            )
        except ValueError:
            self.error("invalid date-time", start)

    def _make_time(self, m, start):
        hour, minute = int(m.group(1)), int(m.group(2))
        second = int(m.group(3)) if m.group(3) else 0
        micro = _micro(m.group(4))
        if hour > 23 or minute > 59 or second > 59:
            self.error("invalid time", start)
        return _dt.time(hour, minute, second, micro)

    # ----- strings -----------------------------------------------------

    def _escape(self, i):
        # ``i`` is the index just after a backslash. Returns (char, next index).
        # spec: N-000137 N-000138 N-000139 N-000140 N-000141 N-000142 N-000143
        # spec: N-000174 N-000175 N-000176 N-000177
        s = self.s
        if i >= self.n:
            self.error("unterminated escape sequence", i - 1)
        c = s[i]
        if c in _BASIC_ESCAPES:
            return _BASIC_ESCAPES[c], i + 1
        width = _ESCAPE_WIDTHS.get(c)
        if width is None:
            self.error("invalid escape sequence", i - 1)
        digits = s[i + 1 : i + 1 + width]
        if len(digits) != width or any(d not in _HEX_CHARS for d in digits):
            self.error("invalid hexadecimal escape", i - 1)
        code = int(digits, 16)
        if code > 0x10FFFF or 0xD800 <= code <= 0xDFFF:
            self.error("escape is not a Unicode scalar value", i - 1)
        return chr(code), i + 1 + width

    def _basic_string(self):
        # Single-line basic string, starting at the opening quote.
        s, start = self.s, self.i
        i = start + 1
        pieces = []
        while True:
            m = _BASIC_RUN.match(s, i)
            if m:
                pieces.append(m.group(0))
                i = m.end()
            if i >= self.n:
                self.error("unterminated string", self.n)
            c = s[i]
            if c == '"':
                self.i = i + 1
                return "".join(pieces)
            if c == "\\":
                ch, i = self._escape(i + 1)
                pieces.append(ch)
                continue
            self.error("invalid character in string", i)

    def _literal_string(self):
        # Single-line literal string, starting at the opening quote.
        s, start = self.s, self.i
        i = start + 1
        pieces = []
        while True:
            m = _LITERAL_RUN.match(s, i)
            if m:
                pieces.append(m.group(0))
                i = m.end()
            if i >= self.n:
                self.error("unterminated string", self.n)
            if s[i] == "'":
                self.i = i + 1
                return "".join(pieces)
            self.error("invalid character in string", i)

    def _multiline_string(self, quote, escapes):
        # spec: N-000127 N-000128 N-000129 N-000130 N-000131 N-000132
        # spec: N-000133 N-000134 N-000135 N-000136 N-000141 N-000178
        # spec: N-000111 N-000112
        s, n = self.s, self.n
        start = self.i
        i = start + 3
        # A newline immediately after the opening delimiter is discarded.
        if s.startswith("\n", i):
            i += 1
        elif s.startswith("\r\n", i):
            i += 2
        pieces = []
        while True:
            if i >= n:
                self.error("unterminated multiline string", self.n)
            c = s[i]
            if c == quote:
                j = i
                while j < n and s[j] == quote:
                    j += 1
                run = j - i
                if run < 3:
                    pieces.append(quote * run)
                    i = j
                    continue
                if run > 5:
                    self.error("too many quotes before closing delimiter", i)
                pieces.append(quote * (run - 3))
                i = j
                break
            if c == "\\" and escapes:
                k = i + 1
                while k < n and s[k] in " \t":
                    k += 1
                if k < n and (s[k] == "\n" or s.startswith("\r\n", k)):
                    # Line-ending backslash: drop it and all whitespace,
                    # including line endings, up to the next other character.
                    i = k
                    while i < n:
                        if s[i] in " \t\n":
                            i += 1
                        elif s.startswith("\r\n", i):
                            i += 2
                        else:
                            break
                    continue
                ch, i = self._escape(i + 1)
                pieces.append(ch)
                continue
            if c == "\n":
                pieces.append("\n")
                i += 1
                continue
            if c == "\r":
                if s.startswith("\r\n", i):
                    pieces.append("\n")
                    i += 2
                    continue
                self.error("carriage return not part of a line ending", i)
            if c != "\t" and (c < " " or c == "\x7f"):
                self.error("control character in string", i)
            pieces.append(c)
            i += 1
        self.i = i
        return "".join(pieces)

    # ----- arrays and inline tables ------------------------------------

    def _array(self):
        # spec: N-000105 N-000106 N-000281 N-000282
        start = self.i
        self.i += 1
        items = []
        while True:
            self._skip_wsnl()
            if self.i >= self.n:
                self.error("unterminated array", self.n)
            if self.s[self.i] == "]":
                self.i += 1
                return items
            items.append(self._value())
            self._skip_wsnl()
            if self.i >= self.n:
                self.error("unterminated array", self.n)
            c = self.s[self.i]
            if c == ",":
                self.i += 1
            elif c == "]":
                self.i += 1
                return items
            else:
                self.error("expected ',' or ']' in array")

    def _inline_table(self):
        # spec: N-000103 N-000104 N-000282 N-000069
        start = self.i
        self.i += 1
        table = {}
        self._mark(table, "inline")
        self._skip_wsnl()
        if self.i < self.n and self.s[self.i] == "}":
            self.i += 1
            return table
        while True:
            pos = self.i
            keys = self._dotted_key()
            self._skip_ws()
            self._expect_char("=")
            self._skip_ws()
            value = self._value()
            self._add(table, keys, value, pos)
            self._skip_wsnl()
            if self.i >= self.n:
                self.error("unterminated inline table", self.n)
            c = self.s[self.i]
            if c == ",":
                self.i += 1
                self._skip_wsnl()
                if self.i < self.n and self.s[self.i] == "}":
                    # TOML v1.1.0 allows a trailing comma.
                    self.i += 1
                    return table
            elif c == "}":
                self.i += 1
                return table
            else:
                self.error("expected ',' or '}' in inline table")


def decode(text, parse_float=float):
    """Decode a TOML text string into a dict."""
    parser = _Parser(text, parse_float)
    try:
        return parser.parse()
    except RecursionError:
        raise TOMLDecodeError(
            "document is nested too deeply", text, parser.i
        ) from None
