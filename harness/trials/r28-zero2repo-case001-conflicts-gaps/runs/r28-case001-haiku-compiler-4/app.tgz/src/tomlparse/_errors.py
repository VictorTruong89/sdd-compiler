"""The decode error raised for invalid TOML.

# spec: N-000307 N-000308 N-000309 N-000310 N-000311 N-000312 N-000313
# spec: N-000314 N-000315 N-000316 N-000317 N-000318 N-000319 N-000320
# spec: N-000321 N-000322 N-000323 N-000203 N-000204 N-000205 N-000206
# spec: N-000207 N-000208 N-000209 N-000210 N-000211 N-000212 N-000217
# spec: N-000218 N-000219 N-000198 N-000199 N-000200 N-000201 N-000202
"""


class TOMLDecodeError(ValueError):
    """A document is not valid TOML v1.1.0.

    Constructed as ``TOMLDecodeError(msg, doc, pos)``. ``msg`` is the reason,
    ``doc`` the document text and ``pos`` a 0-based character offset into
    ``doc``. ``lineno`` and ``colno`` are 1-based and derived from ``pos``.
    """

    def __init__(self, msg, doc, pos):
        self.msg = msg
        self.doc = doc
        self.pos = pos
        # Line is 1 + number of line feeds before the offset; column is
        # 1 + number of characters between the last line feed before the
        # offset (or the start of the document) and the offset.
        clamped = min(max(pos, 0), len(doc))
        self.lineno = doc.count("\n", 0, clamped) + 1
        self.colno = clamped - (doc.rfind("\n", 0, clamped) + 1) + 1
        if pos >= len(doc):
            location = "at end of document"
        else:
            location = "line %d column %d (char %d)" % (self.lineno, self.colno, pos)
        super().__init__("%s (%s)" % (msg, location))

    def __reduce__(self):
        return (self.__class__, (self.msg, self.doc, self.pos))
