"""Product-level checks: package layout, dependencies, interpreter floor and
absence of out-of-scope surfaces."""

import ast
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC = ROOT / "src" / "tomlparse"


def _sources():
    return sorted(SRC.glob("*.py"))


# spec: N-000039 N-000032 N-000259 N-000072
def test_no_command_line_or_module_entry_point():
    assert not (SRC / "__main__.py").exists()
    pyproject = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
    assert "[project.scripts]" not in pyproject
    assert "[project.gui-scripts]" not in pyproject


# spec: N-000040 N-000262 N-000247
def test_zero_runtime_dependencies():
    text = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
    assert "dependencies = []" in text


# spec: N-000041 N-000042 N-000248 N-000236
def test_no_compiled_extensions_on_default_path():
    assert not list(SRC.rglob("*.so")) and not list(SRC.rglob("*.pyd"))


# spec: N-000043 N-000263 N-000237 N-000246
def test_source_is_valid_python_3_8():
    for path in _sources():
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path), feature_version=(3, 8))


# spec: N-000251 N-000252 N-000253 N-000254 N-000250
def test_src_layout_and_pep517_build_declared():
    text = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
    assert "build-backend" in text
    assert 'where = ["src"]' in text
    assert (SRC / "__init__.py").exists()


# spec: N-000266 N-000267 N-000268
def test_package_lives_under_src():
    assert SRC.is_dir()
    assert (ROOT / "src").is_dir()


# spec: N-000049 N-000050 N-000005
def test_package_declares_toml_1_1_0_target():
    import tomlparse

    assert tomlparse.__version__ == "2.4.0"


# spec: N-000031 N-000033 N-000039
def test_public_surface_is_only_the_three_names():
    import tomlparse

    public = {name for name in dir(tomlparse) if not name.startswith("_")}
    assert public == {"loads", "load", "TOMLDecodeError"}


# spec: N-000058 N-000060 N-000061
def test_no_delegation_to_stdlib_or_third_party_toml():
    for path in _sources():
        text = path.read_text(encoding="utf-8")
        assert "tomllib" not in text
        assert "import toml" not in text
