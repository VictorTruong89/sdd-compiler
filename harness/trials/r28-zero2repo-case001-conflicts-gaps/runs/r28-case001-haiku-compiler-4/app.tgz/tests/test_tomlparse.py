"""Acceptance tests for tomlparse, one group per feature point of the spec.

Run from /app with: PYTHONPATH=src python3 -m pytest tests
"""

import datetime as dt
import io

import pytest

from tomlparse import TOMLDecodeError, load, loads


def bad(text):
    with pytest.raises(TOMLDecodeError) as info:
        loads(text)
    return info.value


# ---- FP-01 / interface: document structure ----------------------------------

# spec: N-000082
@pytest.mark.parametrize("text", ["", "   \t ", "# only a comment", "# c\n\n  \n"])
def test_empty_and_comment_only_documents(text):
    assert loads(text) == {}


# spec: N-000083 N-000084
def test_root_and_table_pairs():
    assert loads('a = 1\n[t]\nb = 2\n[u]\nc = 3\n') == {
        "a": 1,
        "t": {"b": 2},
        "u": {"c": 3},
    }


# spec: N-000085 N-000086 N-000087 N-000088
def test_keys_are_strings_and_case_sensitive():
    assert loads('1234 = 1\ntrue = 2\ninf = 3\nnan = 4\nA = 5\na = 6\n') == {
        "1234": 1,
        "true": 2,
        "inf": 3,
        "nan": 4,
        "A": 5,
        "a": 6,
    }


# spec: N-000089 N-000090 N-000091 N-000092
def test_quoted_keys():
    assert loads('"" = 1\n"a.b" = 2\n\'x # y\' = 3\n"\\u00e9" = 4\n') == {
        "": 1,
        "a.b": 2,
        "x # y": 3,
        "é": 4,
    }


# spec: N-000142
def test_literal_key_does_not_process_escapes():
    assert loads("'a\\nb' = 1\n\"a\\nb\" = 2\n") == {"a\\nb": 1, "a\nb": 2}


# spec: N-000093 N-000094 N-000095
def test_dotted_keys_nest_and_extend():
    assert loads('a . b.c = 1\na.b.d = 2\n') == {"a": {"b": {"c": 1, "d": 2}}}


# spec: N-000096 N-000097 N-000098
def test_headers_create_parents_and_later_super_tables():
    assert loads("[a.b.c]\nz = 9\n[a]\nq = 1\n") == {"a": {"b": {"c": {"z": 9}}, "q": 1}}


# spec: N-000098
def test_header_may_declare_undefined_subtable_of_dotted_table():
    doc = loads('[fruit]\napple.color = "red"\napple.taste.sweet = true\n'
                "[fruit.apple.texture]\nsmooth = true\n")
    assert doc == {
        "fruit": {
            "apple": {"color": "red", "taste": {"sweet": True}, "texture": {"smooth": True}}
        }
    }


# spec: N-000099 N-000100 N-000101 N-000102
def test_array_of_tables_nesting():
    doc = loads(
        "[[fruits]]\nname = 'apple'\n[fruits.physical]\ncolor = 'red'\n"
        "[[fruits.varieties]]\nname = 'red delicious'\n"
        "[[fruits]]\nname = 'banana'\n"
        "[[fruits.varieties]]\nname = 'plantain'\n"
    )
    assert doc == {
        "fruits": [
            {
                "name": "apple",
                "physical": {"color": "red"},
                "varieties": [{"name": "red delicious"}],
            },
            {"name": "banana", "varieties": [{"name": "plantain"}]},
        ]
    }


# spec: N-000102
def test_aot_implied_parent_can_be_declared_later():
    assert loads("[[a.b]]\nx = 1\n[a]\ny = 2\n") == {"a": {"b": [{"x": 1}], "y": 2}}


# spec: N-000103 N-000104
def test_inline_tables():
    assert loads("t = {}\nu = { a.b = 1, c = [1, 2] }\n") == {
        "t": {},
        "u": {"a": {"b": 1}, "c": [1, 2]},
    }


# spec: N-000104
def test_inline_table_spans_lines_with_comments_and_trailing_comma():
    doc = loads("t = {\n  a = 1, # first\n  b = 2,\n}\n")
    assert doc == {"t": {"a": 1, "b": 2}}


# spec: N-000105 N-000106
def test_arrays_mixed_nested_multiline_trailing_comma():
    doc = loads("a = []\nb = [1, 'x', [true], [ 1.5 ],]\nc = [\n  1, # one\n  2\n]\n")
    assert doc == {"a": [], "b": [1, "x", [True], [1.5]], "c": [1, 2]}


# spec: N-000107 N-000108 N-000109 N-000110
def test_comments_and_indentation():
    assert loads("\t# comment é\n\ta=1# tail\n  [t]  # x\n\tb = 2\n") == {
        "a": 1,
        "t": {"b": 2},
    }


# spec: N-000111 N-000112
def test_crlf_is_one_line_feed_inside_strings():
    assert loads('a = """x\r\ny"""\r\nb = 1\r\n') == {"a": "x\ny", "b": 1}


# spec: N-000113 N-000114 N-000115 N-000116 N-000117 N-000118 N-000119 N-000120
# spec: N-000121 N-000122
@pytest.mark.parametrize(
    "text",
    [
        "a = 1\na = 2\n",
        "[a]\n[a]\n",
        "a.b = 1\n[a]\n",
        "[a.b]\n[a]\nb.c = 1\n",
        "a = 1\n[a]\n",
        "a = 1\n[[a]]\n",
        "[[a]]\n[a]\n",
        "a = {b = 1}\n[a.c]\n",
        "a = {b = 1}\na.c = 2\n",
        "a = [1]\n[[a]]\n",
        "[a]\nb = 1\n[a.b]\n",
        "a = 1 b = 2\n",
        "= 1\n",
        "a =\n",
        "[a] b = 1\n",
        "[a\n",
        '"""k""" = 1\n',
        "a = { b = 1,, }\n",
        "a = { b = 1 c = 2 }\n",
        "[a]\nb=1\n[a.b.c]\nd=1\n[a]\n",
    ],
)
def test_structural_conflicts_are_refused(text):
    bad(text)


# ---- FP-02: scalar types ----------------------------------------------------

# spec: N-000124 N-000125 N-000126
def test_booleans():
    assert loads("a = true\nb = false\n") == {"a": True, "b": False}
    assert loads("a = true\n")["a"] is True


# spec: N-000127 N-000128 N-000129 N-000130 N-000131 N-000132 N-000133
def test_string_forms():
    doc = loads(
        "basic = \"x\\ty\"\n"
        "lit = 'a\\b'\n"
        "mlb = \"\"\"\nline1\nline2\"\"\"\n"
        "mll = '''\nkeep\\n'''\n"
    )
    assert doc == {
        "basic": "x\ty",
        "lit": "a\\b",
        "mlb": "line1\nline2",
        "mll": "keep\\n",
    }


# spec: N-000134 N-000135 N-000136
def test_multiline_basic_line_ending_backslash_and_quotes():
    doc = loads('a = """one \\\n    two"""\nb = """q""\\""""\nc = """x\n"""""\n')
    assert doc["a"] == "one two"
    assert doc["b"] == 'q"""'
    assert doc["c"] == 'x\n""'


# spec: N-000137 N-000138 N-000139 N-000140 N-000143 N-000174 N-000175 N-000176
def test_basic_escapes():
    doc = loads('a = "\\b\\t\\n\\f\\r\\e\\"\\\\"\nb = "\\x41\\u00e9\\U0001F600\\x7a"\n')
    assert doc == {"a": "\b\t\n\f\r\x1b\"\\", "b": "Aé😀z"}


# spec: N-000139 N-000146
def test_hex_escape_digits_are_case_insensitive():
    assert loads('a = "\\u00E9\\u00e9"\n') == {"a": "éé"}


# spec: N-000177 N-000174
@pytest.mark.parametrize(
    "text",
    [
        'a = "\\q"',
        'a = "\\x4"',
        'a = "\\u12"',
        'a = "\\uD800"',
        'a = "\\U00110000"',
        'a = "\\ "',
    ],
)
def test_bad_escapes_are_refused(text):
    bad(text)


# spec: N-000144 N-000145 N-000147 N-000148 N-000149 N-000150 N-000151
def test_integers_all_bases_and_signs():
    assert loads("a = 0\nb = +0\nc = -0\nd = -17\ne = 1_000\n") == {
        "a": 0,
        "b": 0,
        "c": 0,
        "d": -17,
        "e": 1000,
    }
    assert loads("h = 0xDEAD_beef\no = 0o755\nb = 0b1101_0110\n") == {
        "h": 0xDEADBEEF,
        "o": 0o755,
        "b": 0b11010110,
    }


# spec: N-000167 N-000168 N-000169 N-000170 N-000171 N-000172
@pytest.mark.parametrize(
    "text",
    ["a = 01", "a = 1__0", "a = 1_", "a = 0X1F", "a = 0x_1", "a = -0x1", "a = 0b102", "a = 0o8"],
)
def test_bad_integers_are_refused(text):
    bad(text)


# spec: N-000148 N-000149 N-000150 N-000173
def test_floats_and_specials():
    doc = loads("a = 3.14\nb = -1e3\nc = 6.626e-34\nd = 5_349.5\ne = inf\nf = -inf\ng = +nan\n")
    assert doc["a"] == 3.14 and doc["b"] == -1000.0
    assert doc["c"] == 6.626e-34 and doc["d"] == 5349.5
    assert doc["e"] == float("inf") and doc["f"] == float("-inf")
    assert doc["g"] != doc["g"]


# spec: N-000173
@pytest.mark.parametrize("text", ["a = 1.", "a = .5", "a = 1.e5", "a = 1e", "a = 01.5"])
def test_bad_floats_are_refused(text):
    bad(text)


# spec: N-000151 N-000152 N-000153 N-000288 N-000289 N-000290 N-000291 N-000292
def test_date_times():
    doc = loads(
        "odt = 1979-05-27T07:32:00Z\n"
        "odt2 = 1979-05-27 07:32:00.5-07:00\n"
        "ldt = 1979-05-27T07:32:00\n"
        "ld = 1979-05-27\n"
        "lt = 07:32:00.123456789\n"
    )
    assert doc["odt"] == dt.datetime(1979, 5, 27, 7, 32, tzinfo=dt.timezone.utc)
    assert doc["odt"].utcoffset() == dt.timedelta(0)
    assert doc["odt2"].utcoffset() == dt.timedelta(hours=-7)
    assert doc["odt2"].microsecond == 500000
    assert doc["ldt"] == dt.datetime(1979, 5, 27, 7, 32)
    assert doc["ldt"].tzinfo is None
    assert doc["ld"] == dt.date(1979, 5, 27)
    assert doc["lt"] == dt.time(7, 32, 0, 123456)
    assert doc["lt"].tzinfo is None


# spec: N-000154 N-000155 N-000156 N-000157 N-000158 N-000159
def test_seconds_optional_and_fraction_truncated():
    doc = loads("a = 07:32\nb = 1979-05-27T07:32Z\nc = 07:32:01.9999999\nd = 00:00:00.1\n")
    assert doc["a"] == dt.time(7, 32)
    assert doc["b"] == dt.datetime(1979, 5, 27, 7, 32, tzinfo=dt.timezone.utc)
    assert doc["c"].microsecond == 999999
    assert doc["d"].microsecond == 100000


# spec: N-000159
def test_leap_day():
    assert loads("a = 2024-02-29\n") == {"a": dt.date(2024, 2, 29)}
    bad("a = 2023-02-29\n")


# spec: N-000179 N-000180
@pytest.mark.parametrize(
    "text",
    ["a = 24:00:00", "a = 07:60:00", "a = 07:32:60", "a = 1979-13-01", "a = 1979-05-27T07:32:00+24:00"],
)
def test_bad_date_times(text):
    bad(text)


# spec: N-000162 N-000164 N-000165 N-000166
@pytest.mark.parametrize("text", ["a = True", "a = TRUE", "a = nan_", "a = 1979-05-27T"])
def test_bad_scalars(text):
    bad(text)


# spec: N-000161
def test_native_types_compare_and_copy():
    import copy

    doc = loads("d = 1979-05-27T07:32:00Z\n")
    assert copy.deepcopy(doc) == doc


# ---- FP-03: binary file -----------------------------------------------------

# spec: N-000183 N-000184 N-000186 N-000189
def test_load_binary_file():
    assert load(io.BytesIO(b"a = 1\r\nb = \"\"\"x\r\ny\"\"\"\n")) == {"a": 1, "b": "x\ny"}


# spec: N-000188
def test_load_empty_file():
    assert load(io.BytesIO(b"")) == {}


# spec: N-000190 N-000192 N-000216
def test_load_refuses_text_mode_with_type_error(tmp_path):
    with pytest.raises(TypeError) as info:
        load(io.StringIO("a = 1"))
    assert not isinstance(info.value, TOMLDecodeError)
    path = tmp_path / "doc.toml"
    path.write_text("")
    with open(path, "r", encoding="utf-8") as fh:
        with pytest.raises(TypeError):
            load(fh)


# spec: N-000193 N-000194 N-000195
def test_load_decode_error_carries_decoded_text(tmp_path):
    with pytest.raises(TOMLDecodeError) as info:
        load(io.BytesIO("ok = 1\nbad = é\n".encode("utf-8")))
    assert info.value.doc == "ok = 1\nbad = é\n"
    assert (info.value.lineno, info.value.colno) == (2, 7)


# spec: N-000191
def test_load_is_path_free(tmp_path):
    with pytest.raises(TypeError):
        load(str(tmp_path / "x.toml"))


# ---- FP-04: rejecting invalid TOML ------------------------------------------

# spec: N-000213 N-000214 N-000215 N-000217
@pytest.mark.parametrize("value", [b"a = 1", bytearray(b"a = 1"), 1, None, ["a = 1"]])
def test_loads_wrong_type_is_type_error(value):
    with pytest.raises(TypeError) as info:
        loads(value)
    assert not isinstance(info.value, TOMLDecodeError)


# spec: N-000197 N-000198 N-000200 N-000201 N-000202
def test_decode_error_is_value_error_and_no_mapping():
    with pytest.raises(ValueError) as info:
        loads("a = 1\nb = \n")
    assert isinstance(info.value, TOMLDecodeError)
    assert not isinstance(info.value, (TypeError, RecursionError))


# spec: N-000203 N-000204 N-000205 N-000206 N-000207 N-000208 N-000209
def test_error_location_fields():
    err = bad("a = 1\nb = @\n")
    assert err.doc == "a = 1\nb = @\n"
    assert err.pos == 10
    assert err.lineno == 2
    assert err.colno == 5
    assert "line 2" in str(err) and "column 5" in str(err)


# spec: N-000209 N-000322
def test_error_at_end_of_document_mentions_end():
    err = bad("a = [1, 2")
    assert err.pos >= len(err.doc)
    assert "end of document" in str(err)


# spec: N-000210 N-000211 N-000212 N-000218 N-000219
def test_constructed_error_carries_three_values():
    err = TOMLDecodeError("oops", "x = 1\ny = 2\n", 8)
    assert (err.msg, err.doc, err.pos) == ("oops", "x = 1\ny = 2\n", 8)
    assert (err.lineno, err.colno) == (2, 3)
    assert "oops" in str(err) and "line 2" in str(err)
    assert isinstance(err, ValueError)
    assert not isinstance(err, (TypeError, RecursionError))


# spec: N-000307 N-000308 N-000309 N-000310 N-000311 N-000312 N-000313
# spec: N-000314 N-000315 N-000316 N-000317 N-000318 N-000319 N-000320
# spec: N-000321 N-000322 N-000323
def test_error_type_and_attributes():
    err = TOMLDecodeError("m", "ab\ncd", 4)
    assert issubclass(TOMLDecodeError, ValueError)
    assert (err.msg, err.doc, err.pos, err.lineno, err.colno) == ("m", "ab\ncd", 4, 2, 2)
    assert isinstance(str(err), str)


# spec: N-000310
def test_error_document_is_text_not_bytes():
    err = bad("a = 1\n= 2")
    assert isinstance(err.doc, str)


# ---- FP-05: float converter -------------------------------------------------

# spec: N-000223 N-000224 N-000225 N-000226 N-000227 N-000228 N-000229
# spec: N-000230 N-000231
def test_parse_float_called_with_text_as_written():
    seen = []

    def conv(text):
        seen.append(text)
        return ("F", text)

    doc = loads(
        "a = 1_0.5e+3\nb = -inf\nc = [+nan]\nd = { e = 2.0 }\nf = 7\n",
        parse_float=conv,
    )
    assert doc == {
        "a": ("F", "1_0.5e+3"),
        "b": ("F", "-inf"),
        "c": [("F", "+nan")],
        "d": {"e": ("F", "2.0")},
        "f": 7,
    }
    assert seen == ["1_0.5e+3", "-inf", "+nan", "2.0"]


# spec: N-000232 N-000233 N-000199
@pytest.mark.parametrize("result", [{}, [], type("D", (dict,), {})(), type("L", (list,), {})()])
def test_parse_float_dict_or_list_is_value_error(result):
    with pytest.raises(ValueError) as info:
        loads("a = 1.5\n", parse_float=lambda text: result)
    assert not isinstance(info.value, TOMLDecodeError)


# spec: N-000221 N-000222
def test_parse_float_does_not_change_integers_or_strings():
    doc = loads('i = 3\ns = "1.5"\n', parse_float=lambda t: None)
    assert doc == {"i": 3, "s": "1.5"}


# ---- Interface: public surface -----------------------------------------------

# spec: N-000266 N-000270 N-000271 N-000272 N-000273
def test_public_names_are_importable():
    import tomlparse

    assert callable(tomlparse.loads)
    assert callable(tomlparse.load)
    assert issubclass(tomlparse.TOMLDecodeError, ValueError)
    from tomlparse import TOMLDecodeError as Imported

    assert Imported is TOMLDecodeError


# spec: N-000274 N-000278 N-000279 N-000284 N-000285 N-000293
def test_loads_return_shape():
    doc = loads("a = 1\n")
    assert type(doc) is dict
    assert list(doc) == ["a"]


# spec: N-000259 N-000260 N-000261
def test_no_writer_or_cli_surface():
    import tomlparse

    for name in ("dump", "dumps", "write", "encode"):
        assert not hasattr(tomlparse, name)


# spec: N-000268 N-000269
def test_import_does_no_io_and_starts_no_processes(tmp_path):
    import subprocess
    import sys

    import os
    import pathlib

    src = str(pathlib.Path(__file__).resolve().parent.parent / "src")
    env = dict(os.environ, PYTHONPATH=src)
    code = "import sys, tomlparse; print(sorted(m for m in sys.modules if m.startswith('subprocess')))"
    out = subprocess.run(
        [sys.executable, "-c", code],
        capture_output=True,
        text=True,
        check=True,
        cwd=str(tmp_path),
        env=env,
    ).stdout
    assert out.strip() == "[]"


# ---- Acceptance: TOML v1.1.0 examples -------------------------------------

# spec: N-000049 N-000080 N-000081
def test_toml_spec_example_document():
    doc = loads(
        """
# This is a TOML document

title = "TOML Example"

[owner]
name = "Tom Preston-Werner"
dob = 1979-05-27T07:32:00-08:00

[database]
enabled = true
ports = [ 8000, 8001, 8002 ]
data = [ ["delta", "phi"], [3.14] ]
temp_targets = { cpu = 79.5, case = 72.0 }

[servers]

[servers.alpha]
ip = "10.0.0.1"
role = "frontend"

[servers.beta]
ip = "10.0.0.2"
role = "backend"
"""
    )
    assert doc["servers"]["beta"]["role"] == "backend"
    assert doc["database"]["ports"] == [8000, 8001, 8002]
    assert doc["owner"]["dob"].utcoffset() == dt.timedelta(hours=-8)


# spec: N-000067 N-000069
def test_toml_1_1_features():
    doc = loads(
        "esc = \"\\e[0m \\x41\"\n"
        "t = 1979-05-27T07:32\n"
        "i = { a = 1,\n  b = 2, }\n"
    )
    assert doc == {
        "esc": "\x1b[0m A",
        "t": dt.datetime(1979, 5, 27, 7, 32),
        "i": {"a": 1, "b": 2},
    }


# spec: N-000005 N-000049 N-000111
def test_empty_string_and_multiline_with_newline_first():
    assert loads('a = ""\nb = """\n"""\nc = \'\'\'\n\'\'\'\n') == {"a": "", "b": "", "c": ""}


# spec: N-000057 N-000058 N-000060 N-000061 N-000062 N-000063
def test_parser_is_stdlib_free_of_toml_module():
    import pathlib

    src = pathlib.Path(__file__).resolve().parent.parent / "src" / "tomlparse"
    for path in src.glob("*.py"):
        text = path.read_text(encoding="utf-8")
        assert "import tomllib" not in text
        assert "from tomllib" not in text
        assert "import toml\n" not in text
