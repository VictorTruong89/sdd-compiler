import re
from datetime import date, datetime, time, timedelta, timezone


class TOMLDecodeError(ValueError):
    """Raised when a document is not valid TOML."""

    def __init__(self, msg="", doc="", pos=0):
        # spec: N-000307 N-000309 N-000310 N-000311 N-000313
        self.msg = msg
        self.doc = doc
        self.pos = pos
        lineno = doc.count("\n", 0, pos) + 1
        if lineno == 1:
            colno = pos + 1
        else:
            colno = pos - doc.rindex("\n", 0, pos)
        self.lineno = lineno
        self.colno = colno
        if pos >= len(doc):
            loc = "at end of document"
        else:
            loc = "at line %d, column %d" % (lineno, colno)
        ValueError.__init__(self, "%s (%s)" % (msg, loc))


class _Err(Exception):
    def __init__(self, msg, pos):
        Exception.__init__(self, msg)
        self.msg = msg
        self.pos = pos


BARE = re.compile(r"[A-Za-z0-9_-]+")
DT_RE = re.compile(
    r"(\d{4})-(\d\d)-(\d\d)"
    r"(?:[Tt ](\d\d):(\d\d)(?::(\d\d)(?:\.(\d+))?)?(Z|z|[+-]\d\d:\d\d)?)?"
)
TIME_RE = re.compile(r"(\d\d):(\d\d)(?::(\d\d)(?:\.(\d+))?)?")
DEC = re.compile(r"[+-]?(?:0|[1-9](?:_?\d)*)")
HEX = re.compile(r"0x[0-9A-Fa-f](?:_?[0-9A-Fa-f])*")
OCT = re.compile(r"0o[0-7](?:_?[0-7])*")
BIN = re.compile(r"0b[01](?:_?[01])*")
FLOAT = re.compile(
    r"[+-]?(?:0|[1-9](?:_?\d)*)(?:\.\d(?:_?\d)*)?(?:[eE][+-]?\d(?:_?\d)*)?"
)
SPECIAL = re.compile(r"[+-]?(?:inf|nan)")
HEXDIGITS = "0123456789abcdefABCDEF"
ESC = {"b": "\b", "t": "\t", "n": "\n", "f": "\f", "r": "\r", "e": "\x1b",
       '"': '"', "\\": "\\"}
WS = " \t"
DELIMS = " \t\n,]}#"

# dict kinds
HEADER, IMPLICIT, DOTTED, INLINE = 1, 2, 3, 4


def _bad_ctrl(c):
    return (c < " " and c != "\t") or c == "\x7f"


class _Parser:
    def __init__(self, s, parse_float):
        self.s = s
        self.n = len(s)
        self.pf = parse_float
        self.kinds = {}
        self.aots = set()

    # --- helpers
    def skip_ws(self, i):
        s, n = self.s, self.n
        while i < n and s[i] in WS:
            i += 1
        return i

    def skip_comment(self, i):
        s, n = self.s, self.n
        if i < n and s[i] == "#":
            i += 1
            while i < n and s[i] != "\n":
                if _bad_ctrl(s[i]):
                    raise _Err("Illegal character in comment", i)
                i += 1
        return i

    def skip_ws_nl_comments(self, i):
        s, n = self.s, self.n
        while True:
            i = self.skip_ws(i)
            if i < n and s[i] == "#":
                i = self.skip_comment(i)
            elif i < n and s[i] == "\n":
                i += 1
            else:
                return i

    # --- main
    def parse(self):
        s, n = self.s, self.n
        root = {}
        self.kinds[id(root)] = HEADER
        cur = root
        i = 0
        while True:
            i = self.skip_ws_nl_comments(i)
            if i >= n:
                return root
            c = s[i]
            if c == "[":
                if s.startswith("[[", i):
                    i, cur = self.aot_header(i, root)
                else:
                    i, cur = self.table_header(i, root)
                i = self.end_line(i)
            else:
                i = self.key_value(i, cur)
                i = self.end_line(i)

    def end_line(self, i):
        i = self.skip_ws(i)
        i = self.skip_comment(i)
        if i >= self.n:
            return i
        if self.s[i] != "\n":
            raise _Err("Expected newline or end of document", i)
        return i + 1

    def parse_key(self, i):
        parts = []
        while True:
            i = self.skip_ws(i)
            if i >= self.n:
                raise _Err("Expected key", i)
            c = self.s[i]
            if c == '"':
                if self.s.startswith('"""', i):
                    raise _Err("Multiline string as key", i)
                k, i = self.basic_string(i)
            elif c == "'":
                if self.s.startswith("'''", i):
                    raise _Err("Multiline string as key", i)
                k, i = self.literal_string(i)
            else:
                m = BARE.match(self.s, i)
                if not m:
                    raise _Err("Invalid key", i)
                k = m.group()
                i = m.end()
            parts.append(k)
            i = self.skip_ws(i)
            if i < self.n and self.s[i] == ".":
                i += 1
                continue
            return parts, i

    def walk_header(self, parts, root, pos):
        cur = root
        for k in parts[:-1]:
            if k not in cur:
                nd = {}
                self.kinds[id(nd)] = IMPLICIT
                cur[k] = nd
                cur = nd
                continue
            v = cur[k]
            if isinstance(v, dict):
                if self.kinds.get(id(v)) == INLINE:
                    raise _Err("Cannot extend inline table", pos)
                cur = v
            elif isinstance(v, list) and id(v) in self.aots:
                cur = v[-1]
            else:
                raise _Err("Key already defined as a value", pos)
        return cur

    def table_header(self, i, root):
        start = i
        parts, i = self.parse_key(i + 1)
        if i >= self.n or self.s[i] != "]":
            raise _Err("Expected ']'", i)
        i += 1
        parent = self.walk_header(parts, root, start)
        k = parts[-1]
        if k in parent:
            v = parent[k]
            if (isinstance(v, dict) and self.kinds.get(id(v)) == IMPLICIT):
                self.kinds[id(v)] = HEADER
                return i, v
            raise _Err("Cannot declare table twice", start)
        nd = {}
        self.kinds[id(nd)] = HEADER
        parent[k] = nd
        return i, nd

    def aot_header(self, i, root):
        start = i
        parts, i = self.parse_key(i + 2)
        if not self.s.startswith("]]", i):
            raise _Err("Expected ']]'", i)
        i += 2
        parent = self.walk_header(parts, root, start)
        k = parts[-1]
        nd = {}
        self.kinds[id(nd)] = HEADER
        if k in parent:
            v = parent[k]
            if isinstance(v, list) and id(v) in self.aots:
                v.append(nd)
            else:
                raise _Err("Cannot redefine as array of tables", start)
        else:
            lst = [nd]
            self.aots.add(id(lst))
            parent[k] = lst
        return i, nd

    def key_value(self, i, table):
        start = i
        parts, i = self.parse_key(i)
        i = self.skip_ws(i)
        if i >= self.n or self.s[i] != "=":
            raise _Err("Expected '=' after key", i)
        i = self.skip_ws(i + 1)
        if i >= self.n or self.s[i] in "\n#":
            raise _Err("Missing value", i)
        v, i = self.value(i)
        cur = table
        for k in parts[:-1]:
            if k not in cur:
                nd = {}
                self.kinds[id(nd)] = DOTTED
                cur[k] = nd
                cur = nd
            else:
                v2 = cur[k]
                if isinstance(v2, dict) and self.kinds.get(id(v2)) == DOTTED:
                    cur = v2
                else:
                    raise _Err("Cannot extend existing key", start)
        if parts[-1] in cur:
            raise _Err("Duplicate key", start)
        cur[parts[-1]] = v
        return i

    # --- values
    def value(self, i):
        s, n = self.s, self.n
        if i >= n:
            raise _Err("Expected value", i)
        c = s[i]
        if c == '"':
            if s.startswith('"""', i):
                return self.ml_basic(i)
            return self.basic_string(i)
        if c == "'":
            if s.startswith("'''", i):
                return self.ml_literal(i)
            return self.literal_string(i)
        if c == "[":
            return self.array(i)
        if c == "{":
            return self.inline_table(i)
        if s.startswith("true", i) and (i + 4 >= n or s[i + 4] in DELIMS):
            return True, i + 4
        if s.startswith("false", i) and (i + 5 >= n or s[i + 5] in DELIMS):
            return False, i + 5
        m = DT_RE.match(s, i)
        if m and (m.end() >= n or s[m.end()] in DELIMS):
            return self.make_dt(m, i), m.end()
        m = TIME_RE.match(s, i)
        if m and (m.end() >= n or s[m.end()] in DELIMS):
            return self.make_time(m, i), m.end()
        j = i
        while j < n and s[j] not in DELIMS:
            j += 1
        tok = s[i:j]
        if not tok:
            raise _Err("Invalid value", i)
        if DEC.fullmatch(tok):
            return int(tok.replace("_", "")), j
        if HEX.fullmatch(tok):
            return int(tok[2:].replace("_", ""), 16), j
        if OCT.fullmatch(tok):
            return int(tok[2:].replace("_", ""), 8), j
        if BIN.fullmatch(tok):
            return int(tok[2:].replace("_", ""), 2), j
        if FLOAT.fullmatch(tok) or SPECIAL.fullmatch(tok):
            r = self.pf(tok)
            if isinstance(r, (dict, list)):
                raise ValueError("parse_float must not return dicts or lists")
            return r, j
        raise _Err("Invalid value", i)

    def make_time(self, m, pos):
        h, mi, sec, frac = m.groups()
        h, mi, sec = int(h), int(mi), int(sec or 0)
        if h > 23 or mi > 59 or sec > 59:
            raise _Err("Invalid time", pos)
        us = int((frac or "")[:6].ljust(6, "0"))
        return time(h, mi, sec, us)

    def make_dt(self, m, pos):
        y, mo, d, h, mi, sec, frac, off = m.groups()
        try:
            dd = date(int(y), int(mo), int(d))
        except ValueError:
            raise _Err("Invalid date", pos)
        if h is None:
            return dd
        h, mi, sec = int(h), int(mi), int(sec or 0)
        if h > 23 or mi > 59 or sec > 59:
            raise _Err("Invalid time", pos)
        us = int((frac or "")[:6].ljust(6, "0"))
        tz = None
        if off:
            if off in "Zz":
                tz = timezone.utc
            else:
                oh, om = int(off[1:3]), int(off[4:6])
                if oh > 23 or om > 59:
                    raise _Err("Invalid offset", pos)
                delta = timedelta(hours=oh, minutes=om)
                tz = timezone(-delta if off[0] == "-" else delta)
        return datetime(dd.year, dd.month, dd.day, h, mi, sec, us, tz)

    def array(self, i):
        out = []
        i += 1
        while True:
            i = self.skip_ws_nl_comments(i)
            if i >= self.n:
                raise _Err("Unterminated array", i)
            if self.s[i] == "]":
                return out, i + 1
            v, i = self.value(i)
            out.append(v)
            i = self.skip_ws_nl_comments(i)
            if i >= self.n:
                raise _Err("Unterminated array", i)
            if self.s[i] == ",":
                i += 1
            elif self.s[i] != "]":
                raise _Err("Expected ',' or ']'", i)

    def inline_table(self, i):
        tbl = {}
        self.kinds[id(tbl)] = DOTTED
        i += 1
        while True:
            i = self.skip_ws_nl_comments(i)
            if i >= self.n:
                raise _Err("Unterminated inline table", i)
            if self.s[i] == "}":
                self.kinds[id(tbl)] = INLINE
                return tbl, i + 1
            i = self.key_value(i, tbl)
            i = self.skip_ws_nl_comments(i)
            if i >= self.n:
                raise _Err("Unterminated inline table", i)
            if self.s[i] == ",":
                i += 1
            elif self.s[i] != "}":
                raise _Err("Expected ',' or '}'", i)

    # --- strings
    def literal_string(self, i):
        s = self.s
        j = i + 1
        while j < self.n:
            c = s[j]
            if c == "'":
                return s[i + 1:j], j + 1
            if c == "\n" or _bad_ctrl(c):
                raise _Err("Illegal character in string", j)
            j += 1
        raise _Err("Unterminated string", i)

    def ml_literal(self, i):
        s, n = self.s, self.n
        j = i + 3
        if j < n and s[j] == "\n":
            j += 1
        out = []
        while j < n:
            c = s[j]
            if c == "'":
                k = j
                while k < n and s[k] == "'":
                    k += 1
                run = k - j
                if run >= 3:
                    if run > 5:
                        raise _Err("Too many quotes", j)
                    out.append("'" * (run - 3))
                    return "".join(out), k
                out.append("'" * run)
                j = k
                continue
            if _bad_ctrl(c) and c != "\n":
                raise _Err("Illegal character in string", j)
            out.append(c)
            j += 1
        raise _Err("Unterminated string", i)

    def escape(self, j):
        # s[j] == backslash; returns (char, next index)
        s = self.s
        if j + 1 >= self.n:
            raise _Err("Invalid escape", j)
        e = s[j + 1]
        if e in ESC:
            return ESC[e], j + 2
        ln = {"x": 2, "u": 4, "U": 8}.get(e)
        if ln is None:
            raise _Err("Invalid escape", j)
        h = s[j + 2:j + 2 + ln]
        if len(h) != ln or any(c not in HEXDIGITS for c in h):
            raise _Err("Invalid hex escape", j)
        cp = int(h, 16)
        if 0xD800 <= cp <= 0xDFFF or cp > 0x10FFFF:
            raise _Err("Invalid Unicode scalar value", j)
        return chr(cp), j + 2 + ln

    def basic_string(self, i):
        s, n = self.s, self.n
        j = i + 1
        out = []
        while j < n:
            c = s[j]
            if c == '"':
                return "".join(out), j + 1
            if c == "\\":
                ch, j = self.escape(j)
                out.append(ch)
                continue
            if c == "\n" or _bad_ctrl(c):
                raise _Err("Illegal character in string", j)
            out.append(c)
            j += 1
        raise _Err("Unterminated string", i)

    def ml_basic(self, i):
        s, n = self.s, self.n
        j = i + 3
        if j < n and s[j] == "\n":
            j += 1
        out = []
        while j < n:
            c = s[j]
            if c == '"':
                k = j
                while k < n and s[k] == '"':
                    k += 1
                run = k - j
                if run >= 3:
                    if run > 5:
                        raise _Err("Too many quotes", j)
                    out.append('"' * (run - 3))
                    return "".join(out), k
                out.append('"' * run)
                j = k
                continue
            if c == "\\":
                k = j + 1
                while k < n and s[k] in WS:
                    k += 1
                if k < n and s[k] == "\n":
                    while k < n and s[k] in " \t\n":
                        k += 1
                    j = k
                    continue
                ch, j = self.escape(j)
                out.append(ch)
                continue
            if _bad_ctrl(c) and c != "\n":
                raise _Err("Illegal character in string", j)
            out.append(c)
            j += 1
        raise _Err("Unterminated string", i)


def _orig_pos(s, p):
    """Map a position in the CRLF-normalised text back to the original."""
    off = 0
    idx = s.find("\r\n")
    while idx != -1 and idx - off < p:
        off += 1
        idx = s.find("\r\n", idx + 2)
    return p + off


def loads(s, *, parse_float=float):
    if not isinstance(s, str):
        raise TypeError("Expected str object, not %r" % type(s).__name__)
    norm = s.replace("\r\n", "\n") if "\r\n" in s else s
    try:
        return _Parser(norm, parse_float).parse()
    except _Err as e:
        pos = _orig_pos(s, e.pos) if norm is not s else e.pos
        raise TOMLDecodeError(e.msg, s, pos) from None
    except RecursionError:
        raise TOMLDecodeError("Document nested too deeply", s, 0) from None


def load(fp, *, parse_float=float):
    b = fp.read()
    if isinstance(b, str):
        raise TypeError("File must be opened in binary mode, e.g. use "
                        "`open('foo.toml', 'rb')`")
    try:
        s = bytes(b).decode("utf-8")
    except UnicodeDecodeError as e:
        doc = bytes(b).decode("utf-8", "replace")
        raise TOMLDecodeError("Invalid UTF-8: %s" % e.reason, doc, 0) from None
    return loads(s, parse_float=parse_float)
