import re
from datetime import date, datetime, time, timedelta, timezone

__all__ = ("loads", "load", "TOMLDecodeError")


class TOMLDecodeError(ValueError):
    """Raised when a document is not valid TOML."""

    def __init__(self, msg, doc, pos):
        self.msg = msg
        self.doc = doc
        self.pos = pos
        self.lineno = doc.count("\n", 0, pos) + 1
        self.colno = pos - doc.rfind("\n", 0, pos)
        if pos >= len(doc):
            where = "at end of document"
        else:
            where = "at line %d, column %d" % (self.lineno, self.colno)
        ValueError.__init__(self, "%s (%s)" % (msg, where))

    def __reduce__(self):
        return (self.__class__, (self.msg, self.doc, self.pos))


_BARE = re.compile(r"[A-Za-z0-9_-]+")
_DT = re.compile(
    r"(\d{4})-(\d{2})-(\d{2})"
    r"(?:[Tt ](\d{2}):(\d{2})(?::(\d{2})(?:\.(\d+))?)?"
    r"(?:([Zz])|([+-])(\d{2}):(\d{2}))?)?"
)
_TIME = re.compile(r"(\d{2}):(\d{2})(?::(\d{2})(?:\.(\d+))?)?")
_HEX = re.compile(r"0x[0-9a-fA-F]+(?:_[0-9a-fA-F]+)*")
_OCT = re.compile(r"0o[0-7]+(?:_[0-7]+)*")
_BIN = re.compile(r"0b[01]+(?:_[01]+)*")
_NUM = re.compile(
    r"[+-]?(?:0|[1-9](?:_?[0-9])*)(\.[0-9](?:_?[0-9])*)?([eE][+-]?[0-9](?:_?[0-9])*)?"
)
_SPECIAL = re.compile(r"[+-]?(?:inf|nan)")
_WS_NL = re.compile(r"[ \t]*\r?\n")
_ESC = {"b": "\b", "t": "\t", "n": "\n", "f": "\f", "r": "\r", "e": "\x1b",
        '"': '"', "\\": "\\"}
_HEXDIGITS = frozenset("0123456789abcdefABCDEF")


def _bad_ctrl(c):
    return (c < " " and c != "\t") or c == "\x7f"


class _Parser:
    def __init__(self, src, parse_float):
        self.s = src
        self.n = len(src)
        self.i = 0
        self.pf = parse_float
        self.dotted = set()
        self.explicit = set()
        self.frozen = set()
        self.aot = set()

    def err(self, msg, pos=None):
        return TOMLDecodeError(msg, self.s, self.i if pos is None else pos)

    # ---- whitespace / comments
    def ws(self):
        s, n, i = self.s, self.n, self.i
        while i < n and s[i] in " \t":
            i += 1
        self.i = i

    def comment(self):
        # at '#'
        s, n = self.s, self.n
        i = self.i + 1
        while i < n:
            c = s[i]
            if c == "\n":
                break
            if c == "\r":
                if i + 1 < n and s[i + 1] == "\n":
                    break
                raise self.err("bare carriage return in comment", i)
            if _bad_ctrl(c):
                raise self.err("control character in comment", i)
            i += 1
        self.i = i

    def newline(self):
        """Consume newline at i if present; return True if consumed."""
        s = self.s
        if self.i < self.n:
            if s[self.i] == "\n":
                self.i += 1
                return True
            if s[self.i] == "\r":
                if self.i + 1 < self.n and s[self.i + 1] == "\n":
                    self.i += 2
                    return True
                raise self.err("bare carriage return")
        return False

    def skip_all(self):
        """Skip whitespace, newlines and comments."""
        while True:
            self.ws()
            if self.i >= self.n:
                return
            c = self.s[self.i]
            if c == "#":
                self.comment()
            elif not self.newline():
                return

    def end_of_line(self):
        self.ws()
        if self.i < self.n and self.s[self.i] == "#":
            self.comment()
        if self.i >= self.n:
            return
        if not self.newline():
            raise self.err("expected end of line")

    # ---- top level
    def parse(self):
        root = {}
        cur = root
        s = self.s
        while True:
            self.skip_all()
            if self.i >= self.n:
                break
            if s[self.i] == "[":
                cur = self.header(root)
            else:
                self.keyval(cur)
            self.end_of_line()
        return root

    def header(self, root):
        is_aot = self.s.startswith("[[", self.i)
        self.i += 2 if is_aot else 1
        self.ws()
        start = self.i
        keys = self.key()
        self.ws()
        close = "]]" if is_aot else "]"
        if not self.s.startswith(close, self.i):
            raise self.err("expected '%s'" % close)
        self.i += len(close)
        t = root
        for k in keys[:-1]:
            if k in t:
                n = t[k]
                if isinstance(n, dict):
                    if id(n) in self.frozen:
                        raise self.err("cannot extend inline table", start)
                    t = n
                elif isinstance(n, list) and id(n) in self.aot:
                    t = n[-1]
                else:
                    raise self.err("key is not a table", start)
            else:
                n = {}
                t[k] = n
                t = n
        k = keys[-1]
        if is_aot:
            if k in t:
                n = t[k]
                if not (isinstance(n, list) and id(n) in self.aot):
                    raise self.err("cannot redefine as array of tables", start)
            else:
                n = []
                t[k] = n
                self.aot.add(id(n))
            d = {}
            n.append(d)
            return d
        if k in t:
            n = t[k]
            if (isinstance(n, dict) and id(n) not in self.explicit
                    and id(n) not in self.dotted and id(n) not in self.frozen):
                self.explicit.add(id(n))
                return n
            raise self.err("table already defined", start)
        n = {}
        t[k] = n
        self.explicit.add(id(n))
        return n

    # ---- keys
    def key(self):
        keys = [self.key_part()]
        while True:
            self.ws()
            if self.i < self.n and self.s[self.i] == ".":
                self.i += 1
                self.ws()
                keys.append(self.key_part())
            else:
                return keys

    def key_part(self):
        if self.i >= self.n:
            raise self.err("expected key")
        c = self.s[self.i]
        if c == '"':
            if self.s.startswith('"""', self.i):
                raise self.err("multiline string as key")
            return self.basic_string()
        if c == "'":
            if self.s.startswith("'''", self.i):
                raise self.err("multiline string as key")
            return self.literal_string()
        m = _BARE.match(self.s, self.i)
        if not m:
            raise self.err("invalid key")
        self.i = m.end()
        return m.group()

    def keyval(self, table):
        start = self.i
        keys = self.key()
        self.ws()
        if self.i >= self.n or self.s[self.i] != "=":
            raise self.err("expected '='")
        self.i += 1
        self.ws()
        t = table
        for k in keys[:-1]:
            if k in t:
                n = t[k]
                if (isinstance(n, dict) and id(n) in self.dotted
                        and id(n) not in self.frozen):
                    t = n
                else:
                    raise self.err("cannot redefine key", start)
            else:
                n = {}
                t[k] = n
                self.dotted.add(id(n))
                t = n
        k = keys[-1]
        if k in t:
            raise self.err("duplicate key", start)
        value = self.value()
        t[k] = value

    # ---- values
    def value(self):
        s = self.s
        if self.i >= self.n:
            raise self.err("expected value")
        c = s[self.i]
        if c == '"':
            if s.startswith('"""', self.i):
                return self.ml_basic()
            return self.basic_string()
        if c == "'":
            if s.startswith("'''", self.i):
                return self.ml_literal()
            return self.literal_string()
        if c == "[":
            return self.array()
        if c == "{":
            return self.inline_table()
        if s.startswith("true", self.i):
            self.i += 4
            return True
        if s.startswith("false", self.i):
            self.i += 5
            return False
        if c.isdigit() and c in "0123456789":
            m = _DT.match(s, self.i)
            if m and (m.end() - self.i >= 10):
                return self.datetime(m)
            m = _TIME.match(s, self.i)
            if m:
                return self.localtime(m)
            for rx, base in ((_HEX, 16), (_OCT, 8), (_BIN, 2)):
                m = rx.match(s, self.i)
                if m:
                    self.i = m.end()
                    return int(m.group()[2:].replace("_", ""), base)
        m = _SPECIAL.match(s, self.i)
        if m:
            return self.float_tok(m)
        m = _NUM.match(s, self.i)
        if m:
            if m.group(1) or m.group(2):
                return self.float_tok(m)
            self.i = m.end()
            return int(m.group().replace("_", ""))
        raise self.err("invalid value")

    def float_tok(self, m):
        self.i = m.end()
        res = self.pf(m.group())
        if isinstance(res, (dict, list)):
            raise ValueError("parse_float must not return dicts or lists")
        return res

    def frac(self, f):
        if not f:
            return 0
        return int(f[:6].ljust(6, "0"))

    def mk_time(self, h, mi, sec, f, pos):
        try:
            return time(int(h), int(mi), int(sec) if sec else 0, self.frac(f))
        except ValueError:
            raise self.err("invalid time", pos)

    def localtime(self, m):
        pos = self.i
        t = self.mk_time(m.group(1), m.group(2), m.group(3), m.group(4), pos)
        self.i = m.end()
        return t

    def datetime(self, m):
        pos = self.i
        try:
            d = date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            raise self.err("invalid date", pos)
        self.i = m.end()
        if m.group(4) is None:
            return d
        t = self.mk_time(m.group(4), m.group(5), m.group(6), m.group(7), pos)
        tz = None
        if m.group(8):
            tz = timezone.utc
        elif m.group(9):
            oh, om = int(m.group(10)), int(m.group(11))
            if oh > 23 or om > 59:
                raise self.err("invalid offset", pos)
            delta = timedelta(hours=oh, minutes=om)
            tz = timezone(delta if m.group(9) == "+" else -delta)
        return datetime.combine(d, t).replace(tzinfo=tz)

    # ---- strings
    def literal_string(self):
        s, n = self.s, self.n
        i = self.i + 1
        start = i
        while i < n:
            c = s[i]
            if c == "'":
                self.i = i + 1
                return s[start:i]
            if _bad_ctrl(c):
                raise self.err("invalid character in string", i)
            i += 1
        raise self.err("unterminated string", self.i)

    def ml_literal(self):
        s, n = self.s, self.n
        begin = self.i
        i = self.i + 3
        if s.startswith("\r\n", i):
            i += 2
        elif s.startswith("\n", i):
            i += 1
        out = []
        while i < n:
            c = s[i]
            if c == "'":
                q = 1
                while i + q < n and s[i + q] == "'":
                    q += 1
                if q >= 3:
                    if q > 5:
                        raise self.err("too many quotes", i + 5)
                    out.append("'" * (q - 3))
                    self.i = i + q
                    return "".join(out)
                out.append("'" * q)
                i += q
                continue
            if c == "\r":
                if s.startswith("\r\n", i):
                    out.append("\n")
                    i += 2
                    continue
                raise self.err("bare carriage return", i)
            if _bad_ctrl(c) and c != "\n":
                raise self.err("invalid character in string", i)
            out.append(c)
            i += 1
        raise self.err("unterminated string", begin)

    def escape(self, i, out):
        """s[i] is a backslash followed by an escape letter; returns new i."""
        s = self.s
        c = s[i + 1] if i + 1 < self.n else ""
        if c in _ESC:
            out.append(_ESC[c])
            return i + 2
        if c in ("x", "u", "U"):
            ln = {"x": 2, "u": 4, "U": 8}[c]
            digits = s[i + 2:i + 2 + ln]
            if len(digits) != ln or any(d not in _HEXDIGITS for d in digits):
                raise self.err("invalid escape sequence", i)
            cp = int(digits, 16)
            if cp > 0x10FFFF or 0xD800 <= cp <= 0xDFFF:
                raise self.err("invalid unicode scalar value", i)
            out.append(chr(cp))
            return i + 2 + ln
        raise self.err("invalid escape sequence", i)

    def basic_string(self):
        s, n = self.s, self.n
        begin = self.i
        i = begin + 1
        out = []
        while i < n:
            c = s[i]
            if c == '"':
                self.i = i + 1
                return "".join(out)
            if c == "\\":
                i = self.escape(i, out)
                continue
            if _bad_ctrl(c):
                raise self.err("invalid character in string", i)
            out.append(c)
            i += 1
        raise self.err("unterminated string", begin)

    def ml_basic(self):
        s, n = self.s, self.n
        begin = self.i
        i = begin + 3
        if s.startswith("\r\n", i):
            i += 2
        elif s.startswith("\n", i):
            i += 1
        out = []
        while i < n:
            c = s[i]
            if c == '"':
                q = 1
                while i + q < n and s[i + q] == '"':
                    q += 1
                if q >= 3:
                    if q > 5:
                        raise self.err("too many quotes", i + 5)
                    out.append('"' * (q - 3))
                    self.i = i + q
                    return "".join(out)
                out.append('"' * q)
                i += q
                continue
            if c == "\\":
                m = _WS_NL.match(s, i + 1)
                if m:
                    i = m.end()
                    while i < n:
                        if s[i] in " \t\n":
                            i += 1
                        elif s.startswith("\r\n", i):
                            i += 2
                        else:
                            break
                    continue
                i = self.escape(i, out)
                continue
            if c == "\r":
                if s.startswith("\r\n", i):
                    out.append("\n")
                    i += 2
                    continue
                raise self.err("bare carriage return", i)
            if _bad_ctrl(c) and c != "\n":
                raise self.err("invalid character in string", i)
            out.append(c)
            i += 1
        raise self.err("unterminated string", begin)

    # ---- containers
    def array(self):
        self.i += 1
        res = []
        while True:
            self.skip_all()
            if self.i >= self.n:
                raise self.err("unterminated array")
            if self.s[self.i] == "]":
                self.i += 1
                return res
            res.append(self.value())
            self.skip_all()
            if self.i >= self.n:
                raise self.err("unterminated array")
            c = self.s[self.i]
            if c == ",":
                self.i += 1
            elif c != "]":
                raise self.err("expected ',' or ']'")

    def inline_table(self):
        self.i += 1
        res = {}
        while True:
            self.skip_all()
            if self.i >= self.n:
                raise self.err("unterminated inline table")
            if self.s[self.i] == "}":
                self.i += 1
                self.frozen.add(id(res))
                return res
            self.keyval(res)
            self.skip_all()
            if self.i >= self.n:
                raise self.err("unterminated inline table")
            c = self.s[self.i]
            if c == ",":
                self.i += 1
            elif c != "}":
                raise self.err("expected ',' or '}'")


def loads(s, *, parse_float=float):
    if not isinstance(s, str):
        raise TypeError("Expected str object, not %r" % type(s).__name__)
    try:
        return _Parser(s, parse_float).parse()
    except RecursionError:
        raise TOMLDecodeError("document nested too deeply", s, 0)


def load(fp, *, parse_float=float):
    b = fp.read()
    if isinstance(b, str):
        raise TypeError("File must be opened in binary mode, e.g. use open('foo.toml', 'rb')")
    try:
        s = bytes(b).decode("utf-8")
    except UnicodeDecodeError as e:
        raise TOMLDecodeError("invalid UTF-8: %s" % e.reason, "", 0)
    return loads(s, parse_float=parse_float)
