"""Public entry points: ``loads`` (text) and ``load`` (binary file object)."""

import io

from ._errors import TOMLDecodeError
from ._parser import parse_document


def loads(s, *, parse_float=float):
    """Parse a TOML v1.1.0 document from a Python text string.

    Returns a dict. Raises TypeError if ``s`` is not a str, TOMLDecodeError
    if the document is invalid, and ValueError if ``parse_float`` returns a
    dict or list (or an instance of a subclass of either).
    """
    if not isinstance(s, str):
        raise TypeError("loads() expects a str, not %s" % type(s).__name__)
    return parse_document(s, parse_float)


def load(fp, *, parse_float=float):
    """Parse a TOML v1.1.0 document from a file object opened for binary reading.

    The bytes are decoded as UTF-8 and then parsed exactly as ``loads`` would
    parse the decoded text. Raises TypeError for a text-mode file object.
    """
    if isinstance(fp, io.TextIOBase):
        raise TypeError("load() needs a file object opened in binary mode, not text mode")
    read = getattr(fp, "read", None)
    if read is None:
        raise TypeError("load() expects a binary file object with a read() method")
    data = read()
    if isinstance(data, str):
        raise TypeError("load() needs a file object opened in binary mode, not text mode")
    if not isinstance(data, (bytes, bytearray)):
        raise TypeError("load() expects read() to return bytes, not %s" % type(data).__name__)
    return loads(_decode_utf8(bytes(data)), parse_float=parse_float)


def _decode_utf8(data):
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError as exc:
        # The text before the first bad byte is valid UTF-8; report the
        # failure at the character offset where it starts.
        valid_prefix = data[: exc.start].decode("utf-8")
        replaced = data.decode("utf-8", "replace")
        raise TOMLDecodeError(
            "invalid UTF-8 in document: %s" % exc.reason, replaced, len(valid_prefix)
        ) from None
