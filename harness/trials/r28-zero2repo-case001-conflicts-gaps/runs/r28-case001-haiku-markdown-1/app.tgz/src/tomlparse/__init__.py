"""tomlparse: a pure-Python parser for TOML v1.1.0 documents.

Public surface:
    loads(s, *, parse_float=float) -> dict
    load(fp, *, parse_float=float) -> dict
    TOMLDecodeError

Importing this package performs no I/O.
"""

from ._errors import TOMLDecodeError
from ._api import load, loads

__all__ = ["loads", "load", "TOMLDecodeError"]
__version__ = "2.4.0"
