"""The documented parse-failure exception of tomlparse."""


class TOMLDecodeError(ValueError):
    """Raised when a document is not valid TOML v1.1.0.

    Attributes:
        msg:    the unformatted reason (str)
        doc:    the document text (str)
        pos:    0-based character offset into ``doc``
        lineno: 1-based line of ``pos`` (1 + number of line feeds before it)
        colno:  1-based column of ``pos`` (1 + characters since the last
                line feed before ``pos``, or since the start of ``doc``)
    """

    def __init__(self, msg, doc, pos):
        self.msg = msg
        self.doc = doc
        self.pos = pos
        self.lineno = doc.count("\n", 0, pos) + 1
        self.colno = pos - doc.rfind("\n", 0, pos)
        if pos >= len(doc):
            location = "at end of document, line %d, column %d" % (self.lineno, self.colno)
        else:
            location = "line %d, column %d (char %d)" % (self.lineno, self.colno, pos)
        super().__init__("%s (%s)" % (msg, location))

    def __reduce__(self):
        # Keep pickling/copying working despite the three-argument constructor.
        return (self.__class__, (self.msg, self.doc, self.pos))
