"""A hand-written TOML v1.1.0 parser.

The parser works on the document text by index. It does not use any other
TOML implementation.

Table bookkeeping: every dict the parser creates is tagged in ``kinds`` with
how it came to exist:

* ``implicit`` - created as a parent by a table header; may still be defined
  by its own header.
* ``header``   - defined by a ``[table]`` header or as an element of an array
  of tables; may not be defined again, and dotted keys may not reopen it.
* ``dotted``   - created (or defined) by dotted keys; may receive more dotted
  keys, and may receive sub-tables through headers, but may not itself be
  defined by a header.
* ``inline``   - an inline table; frozen once its closing brace is read.

Arrays of tables are lists whose ids are recorded in ``arrays``.
"""

import datetime as _dt
import re

from ._errors import TOMLDecodeError

_IMPLICIT = "implicit"
_HEADER = "header"
_DOTTED = "dotted"
_INLINE = "inline"

_BARE_KEY_RE = re.compile(r"[A-Za-z0-9_-]+")

_DATETIME_RE = re.compile(
    r"([0-9]{4})-([0-9]{2})-([0-9]{2})"
    r"(?:[Tt ]([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?"
    r"([Zz]|[+-][0-9]{2}:[0-9]{2})?)?"
)
_TIME_RE = re.compile(r"([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?")
_HEX_RE = re.compile(r"0x([0-9a-fA-F]+(?:_[0-9a-fA-F]+)*)")
_OCT_RE = re.compile(r"0o([0-7]+(?:_[0-7]+)*)")
_BIN_RE = re.compile(r"0b([01]+(?:_[01]+)*)")
_DEC_RE = re.compile(
    r"[+-]?(?:0|[1-9](?:_?[0-9])*)"
    r"(\.[0-9](?:_?[0-9])*)?"
    r"([eE][+-]?[0-9](?:_?[0-9])*)?"
)
_SPECIAL_FLOAT_RE = re.compile(r"[+-]?(?:inf|nan)")

_SIMPLE_ESCAPES = {
    "b": "\b",
    "t": "\t",
    "n": "\n",
    "f": "\f",
    "r": "\r",
    "e": "\x1b",
    '"': '"',
    "\\": "\\",
}
_HEX_ESCAPE_LENGTHS = {"x": 2, "u": 4, "U": 8}
_HEX_DIGITS = frozenset("0123456789abcdefABCDEF")


def _is_bad_control(c):
    """Control characters TOML forbids in strings and comments (tab is allowed)."""
    return (c < " " and c != "\t") or c == "\x7f"


def parse_document(doc, parse_float):
    """Parse ``doc`` (a str) and return the document mapping."""
    return _Parser(doc, parse_float).parse()


class _Parser(object):
    def __init__(self, doc, parse_float):
        self.doc = doc
        self.n = len(doc)
        self.pos = 0
        self.parse_float = parse_float
        self.root = {}
        self.current = self.root
        self.kinds = {}  # id(dict) -> one of the kind constants above
        self.arrays = set()  # ids of lists that are arrays of tables

    # ------------------------------------------------------------------
    # Low-level helpers
    # ------------------------------------------------------------------

    def _error(self, msg, pos):
        raise TOMLDecodeError(msg, self.doc, pos)

    def _peek(self):
        return self.doc[self.pos] if self.pos < self.n else ""

    def _skip_spaces(self):
        doc, n, i = self.doc, self.n, self.pos
        while i < n and doc[i] in " \t":
            i += 1
        self.pos = i

    def _newline_at(self, i):
        """Length of the line ending at index ``i`` (0 if there is none)."""
        if i >= self.n:
            return 0
        c = self.doc[i]
        if c == "\n":
            return 1
        if c == "\r" and i + 1 < self.n and self.doc[i + 1] == "\n":
            return 2
        return 0

    def _skip_comment(self):
        doc, n = self.doc, self.n
        i = self.pos + 1  # past the '#'
        while i < n:
            c = doc[i]
            if c == "\n":
                break
            if c == "\r":
                if i + 1 < n and doc[i + 1] == "\n":
                    break
                self._error("bare carriage return in comment", i)
            if _is_bad_control(c):
                self._error("control character in comment", i)
            i += 1
        self.pos = i

    def _skip_ws_comments_nl(self):
        """Skip spaces, tabs, line endings and comments (inside brackets)."""
        while True:
            self._skip_spaces()
            if self.pos >= self.n:
                return
            c = self.doc[self.pos]
            if c == "#":
                self._skip_comment()
                continue
            nl = self._newline_at(self.pos)
            if nl:
                self.pos += nl
                continue
            return

    def _expect_eol(self):
        """After a key/value pair or a table header: only a comment may follow."""
        self._skip_spaces()
        if self.pos >= self.n:
            return
        if self._peek() == "#":
            self._skip_comment()
            if self.pos >= self.n:
                return
        nl = self._newline_at(self.pos)
        if nl:
            self.pos += nl
            return
        self._error("expected end of line", self.pos)

    # ------------------------------------------------------------------
    # Document structure
    # ------------------------------------------------------------------

    def parse(self):
        while True:
            self._skip_spaces()
            if self.pos >= self.n:
                break
            c = self.doc[self.pos]
            if c == "#":
                self._skip_comment()
                continue
            nl = self._newline_at(self.pos)
            if nl:
                self.pos += nl
                continue
            if c == "[":
                self.current = self._parse_header()
            else:
                self._parse_keyval_into(self.current)
            self._expect_eol()
        return self.root

    def _parse_header(self):
        start = self.pos
        is_array = self.doc.startswith("[[", start)
        self.pos = start + (2 if is_array else 1)
        self._skip_spaces()
        keys = self._parse_key()
        self._skip_spaces()
        if self._peek() != "]":
            self._error("expected ']' to close table header", self.pos)
        self.pos += 1
        if is_array:
            if self._peek() != "]":
                self._error("expected ']]' to close array of tables header", self.pos)
            self.pos += 1
        parent = self._walk_header_parents(keys[:-1])
        name, name_pos = keys[-1]
        if is_array:
            return self._append_array_table(parent, name, name_pos)
        return self._define_table(parent, name, name_pos)

    def _walk_header_parents(self, keys):
        """Walk (creating as needed) the tables above a header's last key."""
        cur = self.root
        for name, pos in keys:
            if name in cur:
                val = cur[name]
                if isinstance(val, list):
                    # Only arrays of tables may be walked, into their last element.
                    if id(val) not in self.arrays or not val:
                        self._error("key %r holds a static array" % name, pos)
                    cur = val[-1]
                elif isinstance(val, dict):
                    if self.kinds.get(id(val)) == _INLINE:
                        self._error("cannot extend inline table %r" % name, pos)
                    cur = val
                else:
                    self._error("key %r holds a value, not a table" % name, pos)
            else:
                new = {}
                self.kinds[id(new)] = _IMPLICIT
                cur[name] = new
                cur = new
        return cur

    def _define_table(self, parent, name, pos):
        if name in parent:
            val = parent[name]
            if isinstance(val, dict) and self.kinds.get(id(val)) == _IMPLICIT:
                self.kinds[id(val)] = _HEADER
                return val
            self._error("table %r is already defined" % name, pos)
        new = {}
        self.kinds[id(new)] = _HEADER
        parent[name] = new
        return new

    def _append_array_table(self, parent, name, pos):
        if name in parent:
            val = parent[name]
            if isinstance(val, list) and id(val) in self.arrays:
                elem = {}
                self.kinds[id(elem)] = _HEADER
                val.append(elem)
                return elem
            self._error("key %r is not an array of tables" % name, pos)
        arr = []
        self.arrays.add(id(arr))
        elem = {}
        self.kinds[id(elem)] = _HEADER
        arr.append(elem)
        parent[name] = arr
        return elem

    def _walk_dotted(self, table, keys):
        """Walk the dotted-key prefix of a key/value pair; return the innermost table."""
        cur = table
        for name, pos in keys[:-1]:
            if name in cur:
                val = cur[name]
                kind = self.kinds.get(id(val)) if isinstance(val, dict) else None
                if kind not in (_DOTTED, _IMPLICIT):
                    self._error("cannot add dotted key %r to an existing value or table" % name, pos)
                # The key part now counts as defined by dotted keys.
                self.kinds[id(val)] = _DOTTED
                cur = val
            else:
                new = {}
                self.kinds[id(new)] = _DOTTED
                cur[name] = new
                cur = new
        return cur

    def _parse_keyval_into(self, table):
        keys = self._parse_key()
        self._skip_spaces()
        if self._peek() != "=":
            self._error("expected '=' after key", self.pos)
        self.pos += 1
        self._skip_spaces()
        container = self._walk_dotted(table, keys)
        name, name_pos = keys[-1]
        if name in container:
            self._error("duplicate key %r" % name, name_pos)
        container[name] = self._parse_value()

    # ------------------------------------------------------------------
    # Keys
    # ------------------------------------------------------------------

    def _parse_key(self):
        """Parse a (possibly dotted) key; return a list of (name, start_pos)."""
        keys = []
        while True:
            start = self.pos
            keys.append((self._parse_simple_key(), start))
            self._skip_spaces()
            if self._peek() == ".":
                self.pos += 1
                self._skip_spaces()
                continue
            return keys

    def _parse_simple_key(self):
        c = self._peek()
        if c == '"':
            return self._parse_basic_string()
        if c == "'":
            return self._parse_literal_string()
        m = _BARE_KEY_RE.match(self.doc, self.pos)
        if not m:
            self._error("expected a key", self.pos)
        self.pos = m.end()
        return m.group(0)

    # ------------------------------------------------------------------
    # Values
    # ------------------------------------------------------------------

    def _parse_value(self):
        doc, pos = self.doc, self.pos
        if pos >= self.n:
            self._error("expected a value", pos)
        c = doc[pos]
        if c == '"':
            if doc.startswith('"""', pos):
                return self._parse_multiline_basic_string()
            return self._parse_basic_string()
        if c == "'":
            if doc.startswith("'''", pos):
                return self._parse_multiline_literal_string()
            return self._parse_literal_string()
        if c == "[":
            return self._parse_array()
        if c == "{":
            return self._parse_inline_table()
        if doc.startswith("true", pos):
            self.pos = pos + 4
            return True
        if doc.startswith("false", pos):
            self.pos = pos + 5
            return False

        m = _DATETIME_RE.match(doc, pos)
        if m:
            return self._datetime_value(m)
        m = _TIME_RE.match(doc, pos)
        if m:
            return self._time_value(m)

        m = _HEX_RE.match(doc, pos)
        if m:
            self.pos = m.end()
            return int(m.group(1).replace("_", ""), 16)
        m = _OCT_RE.match(doc, pos)
        if m:
            self.pos = m.end()
            return int(m.group(1).replace("_", ""), 8)
        m = _BIN_RE.match(doc, pos)
        if m:
            self.pos = m.end()
            return int(m.group(1).replace("_", ""), 2)

        m = _DEC_RE.match(doc, pos)
        if m:
            self.pos = m.end()
            if m.group(1) is None and m.group(2) is None:
                return _decimal_int(m.group(0))
            return self._float_value(m.group(0))

        m = _SPECIAL_FLOAT_RE.match(doc, pos)
        if m:
            self.pos = m.end()
            return self._float_value(m.group(0))

        self._error("expected a value", pos)

    def _float_value(self, text):
        if self.parse_float is float:
            value = float(text.replace("_", ""))
        else:
            value = self.parse_float(text)
            if isinstance(value, (dict, list)):
                raise ValueError(
                    "parse_float returned a %s for %r; only scalar results are allowed"
                    % (type(value).__name__, text)
                )
        return value

    def _datetime_value(self, m):
        pos = m.start()
        try:
            day = _dt.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            self._error("invalid calendar date", pos)
        self.pos = m.end()
        if m.group(4) is None:
            return day
        hour, minute = int(m.group(4)), int(m.group(5))
        second = int(m.group(6) or 0)
        micro = _microseconds(m.group(7))
        if hour > 23 or minute > 59 or second > 59:
            self._error("invalid time of day", pos)
        clock = _dt.time(hour, minute, second, micro)
        offset = m.group(8)
        if offset is None:
            return _dt.datetime.combine(day, clock)
        if offset in ("Z", "z"):
            tz = _dt.timezone.utc
        else:
            sign = -1 if offset[0] == "-" else 1
            off_h, off_m = int(offset[1:3]), int(offset[4:6])
            if off_h > 23 or off_m > 59:
                self._error("invalid UTC offset", pos)
            tz = _dt.timezone(sign * _dt.timedelta(hours=off_h, minutes=off_m))
        return _dt.datetime.combine(day, clock.replace(tzinfo=tz))

    def _time_value(self, m):
        hour, minute = int(m.group(1)), int(m.group(2))
        second = int(m.group(3) or 0)
        if hour > 23 or minute > 59 or second > 59:
            self._error("invalid time of day", m.start())
        self.pos = m.end()
        return _dt.time(hour, minute, second, _microseconds(m.group(4)))

    def _parse_array(self):
        self.pos += 1  # '['
        items = []
        while True:
            self._skip_ws_comments_nl()
            if self._peek() == "]":
                self.pos += 1
                return items
            items.append(self._parse_value())
            self._skip_ws_comments_nl()
            c = self._peek()
            if c == ",":
                self.pos += 1
                continue
            if c == "]":
                self.pos += 1
                return items
            self._error("expected ',' or ']' in array", self.pos)

    def _parse_inline_table(self):
        self.pos += 1  # '{'
        table = {}
        self.kinds[id(table)] = _INLINE
        self._skip_ws_comments_nl()
        if self._peek() == "}":
            self.pos += 1
            return table
        while True:
            self._parse_keyval_into(table)
            self._skip_ws_comments_nl()
            c = self._peek()
            if c == ",":
                self.pos += 1
                self._skip_ws_comments_nl()
                if self._peek() == "}":  # trailing comma (allowed in TOML v1.1.0)
                    self.pos += 1
                    return table
                continue
            if c == "}":
                self.pos += 1
                return table
            self._error("expected ',' or '}' in inline table", self.pos)

    # ------------------------------------------------------------------
    # Strings
    # ------------------------------------------------------------------

    def _parse_basic_string(self):
        doc, n = self.doc, self.n
        start = self.pos
        i = start + 1
        out = []
        while True:
            if i >= n:
                self._error("unterminated string", start)
            c = doc[i]
            if c == '"':
                self.pos = i + 1
                return "".join(out)
            if c == "\\":
                i = self._escape(i, out)
                continue
            if c == "\n" or c == "\r" or _is_bad_control(c):
                self._error("unterminated string or invalid character in string", i)
            out.append(c)
            i += 1

    def _parse_literal_string(self):
        doc, n = self.doc, self.n
        start = self.pos
        i = start + 1
        while True:
            if i >= n:
                self._error("unterminated string", start)
            c = doc[i]
            if c == "'":
                self.pos = i + 1
                return doc[start + 1 : i]
            if c == "\n" or c == "\r" or _is_bad_control(c):
                self._error("unterminated string or invalid character in string", i)
            i += 1

    def _parse_multiline_basic_string(self):
        doc, n = self.doc, self.n
        start = self.pos
        i = start + 3
        i += self._newline_at(i)  # a line ending right after the opener is dropped
        out = []
        while True:
            if i >= n:
                self._error("unterminated multiline string", start)
            c = doc[i]
            if c == '"':
                run = 0
                while i + run < n and doc[i + run] == '"':
                    run += 1
                if run >= 3:
                    if run > 5:
                        self._error("too many quotation marks before closing delimiter", i)
                    out.append('"' * (run - 3))
                    self.pos = i + run
                    return "".join(out)
                out.append('"' * run)
                i += run
                continue
            if c == "\\":
                j = i + 1
                while j < n and doc[j] in " \t":
                    j += 1
                if j < n and self._newline_at(j):
                    # Line-ending backslash: trim up to the next non-whitespace.
                    i = j
                    while i < n:
                        ch = doc[i]
                        if ch in " \t\n":
                            i += 1
                        elif ch == "\r" and self._newline_at(i) == 2:
                            i += 2
                        else:
                            break
                    continue
                i = self._escape(i, out)
                continue
            if c == "\n":
                out.append("\n")
                i += 1
                continue
            if c == "\r":
                if self._newline_at(i) == 2:
                    out.append("\n")
                    i += 2
                    continue
                self._error("bare carriage return in string", i)
            if _is_bad_control(c):
                self._error("control character in string", i)
            out.append(c)
            i += 1

    def _parse_multiline_literal_string(self):
        doc, n = self.doc, self.n
        start = self.pos
        i = start + 3
        i += self._newline_at(i)
        out = []
        while True:
            if i >= n:
                self._error("unterminated multiline string", start)
            c = doc[i]
            if c == "'":
                run = 0
                while i + run < n and doc[i + run] == "'":
                    run += 1
                if run >= 3:
                    if run > 5:
                        self._error("too many apostrophes before closing delimiter", i)
                    out.append("'" * (run - 3))
                    self.pos = i + run
                    return "".join(out)
                out.append("'" * run)
                i += run
                continue
            if c == "\n":
                out.append("\n")
                i += 1
                continue
            if c == "\r":
                if self._newline_at(i) == 2:
                    out.append("\n")
                    i += 2
                    continue
                self._error("bare carriage return in string", i)
            if _is_bad_control(c):
                self._error("control character in string", i)
            out.append(c)
            i += 1

    def _escape(self, i, out):
        """Decode the escape whose backslash is at index ``i``; return the next index."""
        doc = self.doc
        j = i + 1
        if j >= self.n:
            self._error("unterminated escape sequence", i)
        e = doc[j]
        if e in _SIMPLE_ESCAPES:
            out.append(_SIMPLE_ESCAPES[e])
            return j + 1
        length = _HEX_ESCAPE_LENGTHS.get(e)
        if length is not None:
            digits = doc[j + 1 : j + 1 + length]
            if len(digits) != length or any(ch not in _HEX_DIGITS for ch in digits):
                self._error("invalid \\%s escape" % e, i)
            code = int(digits, 16)
            if 0xD800 <= code <= 0xDFFF or code > 0x10FFFF:
                self._error("escape is not a Unicode scalar value", i)
            out.append(chr(code))
            return j + 1 + length
        self._error("invalid escape sequence", i)


def _microseconds(fraction):
    """First six fraction digits as microseconds, padded right and truncated."""
    if not fraction:
        return 0
    return int((fraction + "000000")[:6])


def _decimal_int(text):
    """Convert a signed decimal integer token (may contain underscores)."""
    t = text.replace("_", "")
    negative = t.startswith("-")
    digits = t.lstrip("+-")
    if len(digits) <= 1000:
        value = int(digits)
    else:
        # Avoid the int-from-str digit limit on very long numbers.
        value = 0
        for start in range(0, len(digits), 1000):
            chunk = digits[start : start + 1000]
            value = value * 10 ** len(chunk) + int(chunk)
    return -value if negative else value
