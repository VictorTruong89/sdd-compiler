"""Tests for tomlparse, written from spec/ (run: PYTHONPATH=src python -m unittest discover -s tests)."""

import datetime as dt
import io
import pickle
import unittest

import tomlparse
from tomlparse import TOMLDecodeError, load, loads


class Valid(unittest.TestCase):
    def test_empty_and_comments(self):
        self.assertEqual(loads(""), {})
        self.assertEqual(loads("   \t  "), {})
        self.assertEqual(loads("# only\n# comments"), {})
        self.assertEqual(loads("# only\n# comments\n"), {})

    def test_root_keys_and_comments(self):
        self.assertEqual(loads("a = 1 # trailing\n# full\nb='x'"), {"a": 1, "b": "x"})

    def test_keys_are_always_strings(self):
        self.assertEqual(
            loads('1 = 1\ntrue = 2\ninf = 3\nnan = 4\n"" = 5\n"a.b" = 6\n\'q #\' = 7'),
            {"1": 1, "true": 2, "inf": 3, "nan": 4, "": 5, "a.b": 6, "q #": 7},
        )

    def test_key_case_is_significant(self):
        self.assertEqual(loads("a = 1\nA = 2"), {"a": 1, "A": 2})

    def test_dotted_keys_and_whitespace(self):
        self.assertEqual(loads("a . b  .c = 1"), {"a": {"b": {"c": 1}}})

    def test_dotted_keys_extend_implicit_tables(self):
        self.assertEqual(loads("a.b.c = 1\na.b.d = 2"), {"a": {"b": {"c": 1, "d": 2}}})

    def test_headers_create_parents(self):
        self.assertEqual(loads("[a.b.c]\nx = 1\n[a]\ny = 2"), {"a": {"b": {"c": {"x": 1}}, "y": 2}})

    def test_header_under_dotted_table(self):
        doc = '[fruit]\napple.color = "red"\napple.taste.sweet = true\n\n[fruit.apple.texture]\nsmooth = true'
        self.assertEqual(
            loads(doc),
            {"fruit": {"apple": {"color": "red", "taste": {"sweet": True}, "texture": {"smooth": True}}}},
        )

    def test_array_of_tables(self):
        doc = "[[p]]\nname='a'\n[[p]]\nname='b'\n[p.sub]\nz=1\n[[p]]\n[[p.list]]\nq=2\n[[p.list]]\nq=3"
        self.assertEqual(
            loads(doc),
            {
                "p": [
                    {"name": "a"},
                    {"name": "b", "sub": {"z": 1}},
                    {"list": [{"q": 2}, {"q": 3}]},
                ]
            },
        )

    def test_array_of_tables_implies_plain_parent(self):
        self.assertEqual(loads("[[a.b]]\nx=1\n[a]\ny=2"), {"a": {"b": [{"x": 1}], "y": 2}})

    def test_quoted_header_parts(self):
        self.assertEqual(loads('["a.b"."c d"]\nk=1'), {"a.b": {"c d": {"k": 1}}})

    def test_inline_tables(self):
        self.assertEqual(loads("a = {}"), {"a": {}})
        self.assertEqual(loads("a = {b = 1, c.d = 2}"), {"a": {"b": 1, "c": {"d": 2}}})
        self.assertEqual(loads("a = {\n  b = 1, # c\n  c = 2,\n}"), {"a": {"b": 1, "c": 2}})
        self.assertEqual(loads("a = [{x=1}, {x=2}]"), {"a": [{"x": 1}, {"x": 2}]})

    def test_arrays(self):
        self.assertEqual(loads("a = []"), {"a": []})
        self.assertEqual(loads("a = [1, 'two', [3], true,]"), {"a": [1, "two", [3], True]})
        self.assertEqual(loads("a = [\n  1, # one\n  2,\n]"), {"a": [1, 2]})
        self.assertEqual(loads("a = [[1,2],[3]]"), {"a": [[1, 2], [3]]})

    def test_crlf_is_one_line_feed(self):
        self.assertEqual(loads("a = 1\r\nb = 2\r\n"), {"a": 1, "b": 2})
        self.assertEqual(loads('s = """x\r\ny"""'), {"s": "x\ny"})
        self.assertEqual(loads("s = '''\r\nx\r\n'''"), {"s": "x\n"})

    def test_indentation_insignificant(self):
        self.assertEqual(loads("[a]\n\t\tb = 1\n    c = 2"), {"a": {"b": 1, "c": 2}})


class Scalars(unittest.TestCase):
    def test_booleans(self):
        self.assertIs(loads("a = true")["a"], True)
        self.assertIs(loads("a = false")["a"], False)

    def test_basic_string_escapes(self):
        self.assertEqual(
            loads(r'a = "\b\t\n\f\r\e\"\\"')["a"], "\b\t\n\f\r\x1b\"\\"
        )
        self.assertEqual(loads(r'a = "\x41\u00e9\U0001F600\u00E9\xfF"')["a"], "A\u00e9\U0001F600\u00e9\u00ff")

    def test_literal_strings_are_raw(self):
        self.assertEqual(loads(r"a = 'C:\path\n'")["a"], r"C:\path\n")

    def test_quoted_key_escapes(self):
        self.assertEqual(loads(r'"\u0041" = 1\n'.replace("\\n", "")), {"A": 1})
        self.assertEqual(loads(r"'\u0041' = 1"), {"\\u0041": 1})

    def test_multiline_basic(self):
        self.assertEqual(loads('a = """\nx\ny"""')["a"], "x\ny")
        self.assertEqual(loads('a = """\n\nx"""')["a"], "\nx")
        self.assertEqual(loads('a = """one \\\n    two\n   \\\n  three"""')["a"], "one two\n   three")
        self.assertEqual(loads('a = """a\\   \n  b"""')["a"], "ab")

    def test_multiline_literal(self):
        self.assertEqual(loads("a = '''\nx\\n'''")["a"], "x\\n")
        self.assertEqual(loads("a = '''\n\nx'''")["a"], "\nx")
        self.assertEqual(loads("a = '''I [dont] \"need\" escapes'''")["a"], 'I [dont] "need" escapes')

    def test_quotes_before_closing_delimiter(self):
        self.assertEqual(loads('a = """x""""')["a"], 'x"')
        self.assertEqual(loads('a = """x"""""')["a"], 'x""')
        self.assertEqual(loads("a = '''x''''")["a"], "x'")
        self.assertEqual(loads('a = """""" ')["a"], "")

    def test_raw_tab_allowed(self):
        self.assertEqual(loads("a = \"x\ty\"")["a"], "x\ty")

    def test_integers(self):
        self.assertEqual(
            loads("a=0\nb=-17\nc=+42\nd=1_000\ne=0xDEAD_beef\nf=0o755\ng=0b1101\nh=-0\ni=+0")["e"],
            0xDEADBEEF,
        )
        d = loads("a=0\nb=-17\nc=+42\nd=1_000\nf=0o755\ng=0b1101\nh=-0\ni=+0")
        self.assertEqual(d, {"a": 0, "b": -17, "c": 42, "d": 1000, "f": 0o755, "g": 0b1101, "h": 0, "i": 0})
        self.assertIs(type(d["a"]), int)
        self.assertEqual(loads("a = 0xff")["a"], 255)
        self.assertEqual(loads("a = 0XFF".lower())["a"], 255)

    def test_floats(self):
        d = loads("a=3.14\nb=-0.01\nc=5e+22\nd=1e06\ne=-2E-2\nf=6.626_070_15e-34\ng=+1.0")
        self.assertEqual(d["a"], 3.14)
        self.assertEqual(d["b"], -0.01)
        self.assertEqual(d["c"], 5e22)
        self.assertEqual(d["d"], 1e6)
        self.assertEqual(d["e"], -2e-2)
        self.assertEqual(d["f"], 6.62607015e-34)
        self.assertIsInstance(d["g"], float)

    def test_special_floats(self):
        d = loads("a=inf\nb=+inf\nc=-inf\nd=nan\ne=+nan\nf=-nan")
        self.assertEqual(d["a"], float("inf"))
        self.assertEqual(d["b"], float("inf"))
        self.assertEqual(d["c"], float("-inf"))
        for k in "def":
            self.assertTrue(d[k] != d[k])

    def test_datetimes(self):
        d = loads(
            "odt1 = 1979-05-27T07:32:00Z\n"
            "odt2 = 1979-05-27 07:32:00-07:00\n"
            "odt3 = 1979-05-27t00:32:00.999999+00:30\n"
            "ldt = 1979-05-27T07:32:00\n"
            "ld = 1979-05-27\n"
            "lt = 07:32:00.5\n"
            "omit = 1979-05-27T07:32Z\n"
        )
        self.assertEqual(d["odt1"], dt.datetime(1979, 5, 27, 7, 32, tzinfo=dt.timezone.utc))
        self.assertEqual(d["odt1"].utcoffset(), dt.timedelta(0))
        self.assertEqual(d["odt2"].utcoffset(), dt.timedelta(hours=-7))
        self.assertEqual(d["odt3"].utcoffset(), dt.timedelta(minutes=30))
        self.assertEqual(d["odt3"].microsecond, 999999)
        self.assertIsNone(d["ldt"].tzinfo)
        self.assertIs(type(d["ld"]), dt.date)
        self.assertEqual(d["lt"], dt.time(7, 32, 0, 500000))
        self.assertIsNone(d["lt"].tzinfo)
        self.assertEqual(d["omit"].second, 0)

    def test_fraction_truncated(self):
        d = loads("a = 07:00:00.1234569\nb = 07:00:00.1\nc = 07:00:00.0000001")
        self.assertEqual(d["a"].microsecond, 123456)
        self.assertEqual(d["b"].microsecond, 100000)
        self.assertEqual(d["c"].microsecond, 0)

    def test_leap_day(self):
        self.assertEqual(loads("a = 2024-02-29")["a"], dt.date(2024, 2, 29))

    def test_date_space_separator(self):
        self.assertEqual(loads("a = 1979-05-27 07:32:00")["a"], dt.datetime(1979, 5, 27, 7, 32))

    def test_datetime_copy_and_compare(self):
        import copy
        v = loads("a = 1979-05-27T07:32:00Z")["a"]
        self.assertEqual(copy.deepcopy(v), v)


class Load(unittest.TestCase):
    def test_binary_file(self):
        self.assertEqual(load(io.BytesIO(b'a = "\xc3\xa9"\n[t]\nb=1')), {"a": "\u00e9", "t": {"b": 1}})

    def test_empty_file(self):
        self.assertEqual(load(io.BytesIO(b"")), {})

    def test_text_file_is_type_error(self):
        with self.assertRaises(TypeError):
            load(io.StringIO("a = 1"))
        with self.assertRaises(TypeError) as ctx:
            load(io.StringIO(""))
        self.assertNotIsInstance(ctx.exception, TOMLDecodeError)

    def test_matches_loads(self):
        doc = "x = [1, {y = 2.5}]\n[[z]]\nw = 1979-05-27"
        self.assertEqual(load(io.BytesIO(doc.encode())), loads(doc))

    def test_invalid_utf8(self):
        with self.assertRaises(TOMLDecodeError) as ctx:
            load(io.BytesIO(b'a = "\xff"'))
        self.assertIsInstance(ctx.exception, ValueError)

    def test_decode_error_carries_decoded_text(self):
        with self.assertRaises(TOMLDecodeError) as ctx:
            load(io.BytesIO("a = 1\nb = 01".encode("utf-8")))
        self.assertEqual(ctx.exception.doc, "a = 1\nb = 01")
        self.assertIsInstance(ctx.exception.doc, str)


class Refusals(unittest.TestCase):
    def assertInvalid(self, doc):
        with self.assertRaises(TOMLDecodeError, msg=repr(doc)) as ctx:
            loads(doc)
        self.assertIsInstance(ctx.exception, ValueError)
        self.assertIsInstance(ctx.exception.pos, int)

    def test_wrong_python_type(self):
        for bad in (b"a = 1", 1, None, io.BytesIO(b"a=1"), io.StringIO("a=1")):
            with self.assertRaises(TypeError) as ctx:
                loads(bad)
            self.assertNotIsInstance(ctx.exception, TOMLDecodeError)

    def test_duplicates_and_redefinitions(self):
        for doc in [
            "a = 1\na = 2",
            "[a]\n[a]",
            "[a]\nx=1\n[a]",
            "a.b = 1\na.b = 2",
            "[a.b]\n[a]\nb = 1",
            "a.b = 1\n[a]\nb.c = 2",
            "[a.b]\n[a]\nb.c = 2",
            "[a.b.c]\nd=1\n[a]\nb.c.e = 2",
            "a = 1\n[a]",
            "a = 1\n[[a]]",
            "[[a]]\n[a]",
            "a = []\n[[a]]",
            "a = 1\na.b = 2",
            "[[a]]\n[a.b]\n[a.b]",
            "a = [1]\n[a.b]",
            "a = [{x=1}]\n[a.b]",
        ]:
            self.assertInvalid(doc)

    def test_inline_tables_are_frozen(self):
        for doc in [
            "a = {}\n[a]",
            "a = {}\n[a.b]",
            "a = {b = 1}\na.c = 2",
            "a = {b.c = 1}\na.b.d = 2",
            "a = {}\n[[a]]",
            "a = {b={}}\n[a.b]",
        ]:
            self.assertInvalid(doc)

    def test_extending_array_of_tables_with_dotted_keys(self):
        self.assertInvalid("a = [{}]\na.c = 1")
        self.assertInvalid("[[a]]\n\n[[a]]\nb.c = 1\n[a]")
        self.assertInvalid("[[a]]\n[a.b]\n[[a.b]]")

    def test_pairs_and_headers_structure(self):
        for doc in [
            "= 1",
            "a =",
            "a 1",
            "a = 1 b = 2",
            "[a] b = 1",
            "[a]]",
            "[[a]",
            "[a",
            "[ ]",
            "a = \"\"\"x\"\"\" \"\"\"",
            '"""a""" = 1',
            "[a.]",
            "a..b = 1",
            "a = 1\n = 2",
            "[a]\n[[a]] = 1",
            "a=1 # ok\nb",
        ]:
            self.assertInvalid(doc)

    def test_invalid_bare_keys(self):
        self.assertInvalid("é = 1")
        self.assertInvalid("a+b = 1")

    def test_multiline_string_as_key_or_table(self):
        self.assertInvalid('"""a""" = 1')
        self.assertInvalid('[""" a """]')

    def test_bad_booleans_and_numbers(self):
        for doc in [
            "a = True", "a = TRUE", "a = trueX", "a = tru",
            "a = 01", "a = 00", "a = -01", "a = +01", "a = 1__0", "a = 1_", "a = _1",
            "a = 0X1F", "a = 0O7", "a = 0B1", "a = 0xG", "a = -0x1", "a = +0o7",
            "a = 0b2", "a = 0o8", "a = 0x_1", "a = 1.", "a = .5", "a = 1.e5",
            "a = 1e", "a = 1.0_", "a = 1._0", "a = 01.5", "a = 1 . 5", "a = 1.5.5",
            "a = infinity", "a = nany", "a = Inf", "a = 1_.5", "a = 1__000",
            "a = 1979-13-01", "a = 1979-02-29", "a = 2023-02-29T00:00:00Z",
            "a = 07:60:00", "a = 24:00:00", "a = 07:00:60", "a = 0000-01-01",
            "a = 1979-05-27T07:32:00+24:00", "a = 1979-05-27T07:32:00+07:60",
            "a = 1979-05-27T07:32:00.Z", "a = 1979-05-27T07:32:00-07",
            "a = 07:32.5", "a = 1979-05-27T", "a = 1979-05-27T07:3",
        ]:
            self.assertInvalid(doc)

    def test_bad_strings(self):
        for doc in [
            'a = "unterminated',
            'a = "line\nbreak"',
            "a = 'line\nbreak'",
            'a = "\\q"',
            'a = "\\x4"',
            'a = "\\xG1"',
            'a = "\\X41"',
            'a = "\\u00"',
            'a = "\\u00e"',
            'a = "\\uD800"',
            'a = "\\UDFFFFFFF"',
            'a = "\\U00110000"',
            'a = "\\U0011FFFF"',
            "a = \"\x01\"",
            "a = \"\x7f\"",
            "a = '\x01'",
            'a = """a\rb"""',
            'a = """a\\ x\n"""',
            'a = """\x01"""',
            'a = """a""""""',
            'a = """unterminated',
            "a = '''unterminated",
            "a = \"\"\"x\"\"\"\"\"\"",
            'a = "\\\n"',
        ]:
            self.assertInvalid(doc)

    def test_bare_cr_outside_strings(self):
        self.assertInvalid("a = 1\rb = 2")

    def test_control_characters_in_comments(self):
        self.assertInvalid("a = 1 # bad\x01")

    def test_pairs_in_arrays_and_inline_tables(self):
        for doc in [
            "a = [,]", "a = [1,,2]", "a = [1 2]", "a = {a=1 b=2}", "a = {,}",
            "a = {a=1,,}", "a = {a=1", "a = [1", "a = {a = [1}", "a = {a=1}}",
            "a = {a.b=1, a=2}",
        ]:
            self.assertInvalid(doc)


class FloatConverter(unittest.TestCase):
    def test_converter_called_for_every_float(self):
        seen = []

        def conv(text):
            seen.append(text)
            return ("f", text)

        d = loads("a = 1.5\nb = 1_000e3\nc = [-inf, +nan]\nd = {e = 0.5}\ni = 5\ns = 'x'", parse_float=conv)
        self.assertEqual(seen, ["1.5", "1_000e3", "-inf", "+nan", "0.5"])
        self.assertEqual(d["a"], ("f", "1.5"))
        self.assertEqual(d["d"]["e"], ("f", "0.5"))
        self.assertEqual(d["i"], 5)
        self.assertIsInstance(d["i"], int)
        self.assertEqual(d["s"], "x")

    def test_converter_result_bound_as_returned(self):
        marker = object()
        self.assertIs(loads("a = 1.0", parse_float=lambda t: marker)["a"], marker)

    def test_converter_result_dict_or_list_is_value_error(self):
        for bad in (lambda t: {}, lambda t: []):
            with self.assertRaises(ValueError) as ctx:
                loads("a = 1.0", parse_float=bad)
            self.assertNotIsInstance(ctx.exception, TOMLDecodeError)

    def test_converter_subclass_result_refused(self):
        class D(dict):
            pass

        class L(list):
            pass

        for bad in (lambda t: D(), lambda t: L()):
            with self.assertRaises(ValueError) as ctx:
                loads("a = 1.0", parse_float=bad)
            self.assertNotIsInstance(ctx.exception, TOMLDecodeError)

    def test_load_with_converter(self):
        d = load(io.BytesIO(b"a = 2.0"), parse_float=lambda t: t)
        self.assertEqual(d, {"a": "2.0"})

    def test_converter_not_applied_to_ints_in_document(self):
        self.assertEqual(loads("a = 0x10", parse_float=lambda t: "never"), {"a": 16})


class ErrorObject(unittest.TestCase):
    def test_location_fields(self):
        try:
            loads("a = 1\nb = 01")
        except TOMLDecodeError as e:
            self.assertEqual(e.doc, "a = 1\nb = 01")
            self.assertEqual(e.lineno, 2)
            # The error is at offset 11 (the '1' after the '0'); the last line feed is at 5.
            self.assertEqual(e.pos, 11)
            self.assertEqual(e.colno, 6)
            self.assertIsInstance(e.msg, str)
            self.assertIn("line 2", str(e))
        else:
            self.fail("expected TOMLDecodeError")

    def test_constructed_error(self):
        e = TOMLDecodeError("bad thing", "ab\ncd", 4)
        self.assertEqual(e.msg, "bad thing")
        self.assertEqual(e.doc, "ab\ncd")
        self.assertEqual(e.pos, 4)
        self.assertEqual(e.lineno, 2)
        self.assertEqual(e.colno, 2)
        self.assertIn("bad thing", str(e))
        self.assertIn("line 2", str(e))
        self.assertIsInstance(e, ValueError)
        self.assertNotIsInstance(e, TypeError)
        self.assertNotIsInstance(e, RecursionError)

    def test_end_of_document_location(self):
        e = TOMLDecodeError("eof", "abc", 3)
        self.assertEqual((e.lineno, e.colno), (1, 4))
        self.assertIn("end", str(e).lower())

    def test_first_char_location(self):
        e = TOMLDecodeError("x", "abc", 0)
        self.assertEqual((e.lineno, e.colno), (1, 1))

    def test_pickle_roundtrip(self):
        e = TOMLDecodeError("m", "a\nb", 2)
        e2 = pickle.loads(pickle.dumps(e))
        self.assertEqual((e2.msg, e2.doc, e2.pos, e2.lineno, e2.colno), ("m", "a\nb", 2, 2, 1))

    def test_parse_error_positions_are_interior(self):
        try:
            loads("[a]\nb = 1\nb = 2")
        except TOMLDecodeError as e:
            self.assertLess(e.pos, len("[a]\nb = 1\nb = 2"))
            self.assertEqual(e.lineno, 3)
        else:
            self.fail("expected TOMLDecodeError")


class Package(unittest.TestCase):
    def test_public_names(self):
        self.assertTrue(callable(tomlparse.loads))
        self.assertTrue(callable(tomlparse.load))
        self.assertTrue(issubclass(tomlparse.TOMLDecodeError, ValueError))
        self.assertFalse(issubclass(tomlparse.TOMLDecodeError, TypeError))


if __name__ == "__main__":
    unittest.main()
