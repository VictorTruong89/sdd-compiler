"""Pure-Python TOML v1.1.0 parser.

The parser works on a normalised copy of the text (CR LF pairs become LF)
and maps error offsets back onto the caller's original text.

# spec: N-000057 N-000058 N-000059 N-000060 N-000061 N-000062
# spec: N-000077 N-000078 N-000079 N-000080 N-000081 N-000082 N-000083
# spec: N-000084 N-000085 N-000086 N-000087 N-000088 N-000089 N-000090
# spec: N-000091 N-000092 N-000093 N-000094 N-000095 N-000096 N-000097
# spec: N-000098 N-000099 N-000100 N-000101 N-000102 N-000103 N-000104
# spec: N-000105 N-000106 N-000107 N-000108 N-000109 N-000110 N-000111
# spec: N-000112 N-000113 N-000114 N-000115 N-000116 N-000117 N-000118
# spec: N-000119 N-000120 N-000121 N-000122
# spec: N-000123 N-000124 N-000125 N-000126 N-000127 N-000128 N-000129
# spec: N-000130 N-000131 N-000132 N-000133 N-000134 N-000135 N-000136
# spec: N-000137 N-000138 N-000139 N-000140 N-000141 N-000142 N-000143
# spec: N-000144 N-000145 N-000146 N-000147 N-000148 N-000149 N-000150
# spec: N-000151 N-000152 N-000153 N-000154 N-000155 N-000156 N-000157
# spec: N-000158 N-000159 N-000160 N-000161 N-000162 N-000163 N-000164
# spec: N-000165 N-000166 N-000167 N-000168 N-000169 N-000170 N-000171
# spec: N-000172 N-000173 N-000174 N-000175 N-000176 N-000177 N-000178
# spec: N-000179 N-000180
# spec: N-000220 N-000221 N-000222 N-000223 N-000224 N-000225 N-000226
# spec: N-000227 N-000228 N-000229 N-000230 N-000231 N-000232 N-000233
# spec: N-000255 N-000256 N-000257 N-000258 N-000259 N-000260 N-000261
# spec: N-000262 N-000263 N-000264 N-000265 N-000266 N-000267 N-000268
# spec: N-000269 N-000270 N-000271 N-000272 N-000273 N-000274 N-000275
# spec: N-000276 N-000277 N-000278 N-000279 N-000280 N-000281 N-000282
# spec: N-000283 N-000284 N-000285 N-000286 N-000287 N-000288 N-000289
# spec: N-000290 N-000291 N-000292 N-000293 N-000294 N-000295 N-000296
# spec: N-000297 N-000298
"""

import bisect
import datetime
import re

from ._errors import TOMLDecodeError

# Flags kept per container (keyed by id) to enforce TOML's table rules.
_HEADER = 1  # defined by a [table] or [[array]] header (or is an AoT element)
_DOTTED = 2  # created by dotted keys; a header may not define it
_INLINE = 4  # an inline table; frozen once written
_AOT = 8  # a list that is an array of tables

# Limit on nesting of arrays and inline tables. The parser is recursive; the
# limit keeps very deep documents from exhausting the interpreter stack.
MAX_DEPTH = 250

_BARE_KEY_RE = re.compile(r"[A-Za-z0-9_-]+")
_TOKEN_RE = re.compile(r"[A-Za-z0-9_+.\-]+")
_DEC_INT_RE = re.compile(r"[+-]?(?:0|[1-9](?:_?[0-9])*)")
_HEX_INT_RE = re.compile(r"[0-9A-Fa-f](?:_?[0-9A-Fa-f])*")
_OCT_INT_RE = re.compile(r"[0-7](?:_?[0-7])*")
_BIN_INT_RE = re.compile(r"[01](?:_?[01])*")
_FLOAT_RE = re.compile(
    r"[+-]?(?:0|[1-9](?:_?[0-9])*)"
    r"(?:\.[0-9](?:_?[0-9])*)?"
    r"(?:[eE][+-]?[0-9](?:_?[0-9])*)?"
)
_SPECIAL_FLOATS = frozenset(("inf", "+inf", "-inf", "nan", "+nan", "-nan"))

_DATE = r"(?P<y>[0-9]{4})-(?P<mo>[0-9]{2})-(?P<d>[0-9]{2})"
_TIME = r"(?P<h>[0-9]{2}):(?P<mi>[0-9]{2})(?::(?P<s>[0-9]{2})(?:\.(?P<frac>[0-9]+))?)?"
_OFFSET = r"(?P<off>[Zz]|(?P<osign>[+-])(?P<oh>[0-9]{2}):(?P<om>[0-9]{2}))"
_DT_RE = re.compile(_DATE + r"(?:[Tt ]" + _TIME + r"(?:" + _OFFSET + r")?)?")
_TIME_RE = re.compile(_TIME)

_HEX_DIGITS_RE = re.compile(r"[0-9A-Fa-f]+")

_ESCAPES = {
    "b": "\b",
    "t": "\t",
    "n": "\n",
    "f": "\f",
    "r": "\r",
    "e": "\x1b",
    '"': '"',
    "\\": "\\",
}
_UNICODE_ESCAPE_LEN = {"x": 2, "u": 4, "U": 8}

# Character runs that contain no special characters. Control characters other
# than tab are excluded; LF is excluded where it ends a line.
_BASIC_CHUNK = re.compile(r"[^\"\\\x00-\x08\x0a-\x1f\x7f]+")
_ML_BASIC_CHUNK = re.compile(r"[^\"\\\x00-\x08\x0b-\x1f\x7f]+")
_LITERAL_CHUNK = re.compile(r"[^'\x00-\x08\x0a-\x1f\x7f]+")
_ML_LITERAL_CHUNK = re.compile(r"[^'\x00-\x08\x0b-\x1f\x7f]+")
_COMMENT_RE = re.compile(r"#[^\n\x00-\x08\x0b-\x1f\x7f]*")


def _normalise(text):
    """Return (normalised text, shifts) where shifts maps CR LF back to offsets."""
    shifts = []
    removed = 0
    for match in re.finditer("\r\n", text):
        # Normalised index of the LF that replaces this CR LF pair.
        shifts.append(match.start() - removed)
        removed += 1
    return text.replace("\r\n", "\n"), shifts


class _Parser(object):
    def __init__(self, text, parse_float):
        self.orig = text
        if "\r" in text:
            self.src, self._shifts = _normalise(text)
        else:
            self.src, self._shifts = text, []
        self.n = len(self.src)
        self.pos = 0
        self.parse_float = parse_float
        self.flags = {}
        self.root = {}
        self.cur = self.root
        self.depth = 0

    # ----------------------------------------------------------- utilities

    def _orig_pos(self, p):
        if not self._shifts:
            return p
        return p + bisect.bisect_left(self._shifts, p)

    def _err(self, msg, p=None):
        if p is None:
            p = self.pos
        raise TOMLDecodeError(msg, self.orig, self._orig_pos(p))

    def _peek(self):
        return self.src[self.pos] if self.pos < self.n else ""

    def _skip_ws(self):
        src, n, p = self.src, self.n, self.pos
        while p < n and (src[p] == " " or src[p] == "\t"):
            p += 1
        self.pos = p

    def _skip_comment(self):
        # spec: N-000107 N-000108 N-000109 N-000110
        m = _COMMENT_RE.match(self.src, self.pos)
        self.pos = m.end()
        if self.pos < self.n and self.src[self.pos] != "\n":
            self._err("control character in comment")

    def _skip_wsnc(self):
        """Skip whitespace, line feeds and comments (inside arrays and inline tables)."""
        # spec: N-000103 N-000105 N-000107
        while True:
            c = self._peek()
            if c == " " or c == "\t" or c == "\n":
                self.pos += 1
            elif c == "#":
                self._skip_comment()
            else:
                return

    def _end_of_line(self):
        self._skip_ws()
        if self._peek() == "#":
            self._skip_comment()
        c = self._peek()
        if c != "" and c != "\n":
            self._err("expected end of line")

    def _enter(self, p):
        self.depth += 1
        if self.depth > MAX_DEPTH:
            self._err("nesting too deep", p)

    # -------------------------------------------------------------- driver

    def parse(self):
        # spec: N-000082 N-000083 N-000084 N-000110
        src, n = self.src, self.n
        while True:
            self._skip_ws()
            if self.pos >= n:
                break
            c = src[self.pos]
            if c == "\n":
                self.pos += 1
                continue
            if c == "#":
                self._skip_comment()
                continue
            if c == "[":
                if src.startswith("[[", self.pos):
                    self._array_table_header()
                else:
                    self._table_header()
            else:
                self._key_value(self.cur)
            self._end_of_line()
        return self.root

    # ---------------------------------------------------------------- keys

    def _parse_simple_key(self):
        # spec: N-000085 N-000086 N-000087 N-000088 N-000089 N-000090 N-000091
        # spec: N-000092 N-000113 N-000122
        c = self._peek()
        if c == '"':
            return self._basic_string_one_line()
        if c == "'":
            return self._literal_string_one_line()
        m = _BARE_KEY_RE.match(self.src, self.pos)
        if m is None:
            self._err("expected a key")
        self.pos = m.end()
        return m.group()

    def _parse_key_path(self):
        # spec: N-000093 N-000094 N-000095
        parts = [self._parse_simple_key()]
        while True:
            self._skip_ws()
            if self._peek() != ".":
                break
            self.pos += 1
            self._skip_ws()
            parts.append(self._parse_simple_key())
        return parts

    def _key_value(self, table):
        kstart = self.pos
        parts = self._parse_key_path()
        self._skip_ws()
        if self._peek() != "=":
            self._err("expected '=' after key")
        self.pos += 1
        self._skip_ws()
        value = self._parse_value()
        self._assign(table, parts, value, kstart)

    def _assign(self, table, parts, value, kstart):
        """Insert ``value`` at the dotted path ``parts`` under ``table``."""
        # spec: N-000093 N-000094 N-000095 N-000113 N-000114 N-000115 N-000116
        # spec: N-000117 N-000118 N-000122
        t = table
        for key in parts[:-1]:
            if key in t:
                child = t[key]
                if not isinstance(child, dict):
                    self._err("key %r already holds a value" % (key,), kstart)
                if self.flags.get(id(child), 0) & (_HEADER | _INLINE):
                    self._err(
                        "cannot add keys to table %r; it was already defined"
                        % (key,),
                        kstart,
                    )
                t = child
            else:
                child = {}
                t[key] = child
                self.flags[id(child)] = _DOTTED
                t = child
        last = parts[-1]
        if last in t:
            self._err("duplicate key %r" % (last,), kstart)
        t[last] = value

    # -------------------------------------------------------------- headers

    def _walk_header(self, table, key, kstart):
        """Step into ``table[key]`` for a header path, creating implicit tables."""
        # spec: N-000096 N-000097 N-000098 N-000099 N-000100 N-000101 N-000102
        if key not in table:
            child = {}
            table[key] = child
            return child
        child = table[key]
        if isinstance(child, list):
            if self.flags.get(id(child), 0) & _AOT and child:
                return child[-1]
            self._err("cannot use static array %r as a table" % (key,), kstart)
        if not isinstance(child, dict):
            self._err("key %r already holds a value" % (key,), kstart)
        if self.flags.get(id(child), 0) & _INLINE:
            self._err("cannot extend inline table %r" % (key,), kstart)
        return child

    def _table_header(self):
        # spec: N-000096 N-000097 N-000098 N-000113 N-000114 N-000119 N-000121
        # spec: N-000122
        start = self.pos
        self.pos += 1
        self._skip_ws()
        parts = self._parse_key_path()
        self._skip_ws()
        if self._peek() != "]":
            self._err("expected ']' to close table header")
        self.pos += 1
        table = self.root
        for key in parts[:-1]:
            table = self._walk_header(table, key, start)
        last = parts[-1]
        if last in table:
            child = table[last]
            if not isinstance(child, dict):
                self._err("table header redefines key %r" % (last,), start)
            flags = self.flags.get(id(child), 0)
            if flags & (_HEADER | _DOTTED | _INLINE):
                self._err("table %r is defined more than once" % (last,), start)
            self.flags[id(child)] = flags | _HEADER
            self.cur = child
        else:
            child = {}
            table[last] = child
            self.flags[id(child)] = _HEADER
            self.cur = child

    def _array_table_header(self):
        # spec: N-000099 N-000100 N-000101 N-000102 N-000113 N-000114
        start = self.pos
        self.pos += 2
        self._skip_ws()
        parts = self._parse_key_path()
        self._skip_ws()
        if not self.src.startswith("]]", self.pos):
            self._err("expected ']]' to close array of tables header")
        self.pos += 2
        table = self.root
        for key in parts[:-1]:
            table = self._walk_header(table, key, start)
        last = parts[-1]
        if last in table:
            arr = table[last]
            if not (isinstance(arr, list) and self.flags.get(id(arr), 0) & _AOT):
                self._err("%r is not an array of tables" % (last,), start)
        else:
            arr = []
            table[last] = arr
            self.flags[id(arr)] = _AOT
        element = {}
        self.flags[id(element)] = _HEADER
        arr.append(element)
        self.cur = element

    # --------------------------------------------------------------- values

    def _parse_value(self):
        src, p = self.src, self.pos
        if p >= self.n:
            self._err("expected a value")
        c = src[p]
        if c == '"':
            if src.startswith('"""', p):
                return self._ml_basic_string()
            return self._basic_string_one_line()
        if c == "'":
            if src.startswith("'''", p):
                return self._ml_literal_string()
            return self._literal_string_one_line()
        if c == "[":
            return self._parse_array()
        if c == "{":
            return self._parse_inline_table()
        m = _DT_RE.match(src, p)
        if m is not None:
            self.pos = m.end()
            return self._datetime(m.groupdict(), p)
        m = _TIME_RE.match(src, p)
        if m is not None:
            self.pos = m.end()
            return self._local_time(m.groupdict(), p)
        m = _TOKEN_RE.match(src, p)
        if m is None:
            self._err("expected a value")
        self.pos = m.end()
        return self._scalar(m.group(), p)

    def _scalar(self, tok, p):
        """Booleans and numbers. ``tok`` is a run of bare-value characters."""
        # spec: N-000124 N-000125 N-000126 N-000144 N-000145 N-000146 N-000147
        # spec: N-000148 N-000149 N-000150 N-000166 N-000167 N-000168 N-000169
        # spec: N-000170 N-000171 N-000172 N-000173
        if tok == "true":
            return True
        if tok == "false":
            return False
        if _DEC_INT_RE.fullmatch(tok):
            return int(tok.replace("_", ""))
        for prefix, base, rx in (
            ("0x", 16, _HEX_INT_RE),
            ("0o", 8, _OCT_INT_RE),
            ("0b", 2, _BIN_INT_RE),
        ):
            if tok.startswith(prefix):
                if rx.fullmatch(tok[2:]):
                    return int(tok[2:].replace("_", ""), base)
                self._err("invalid integer literal", p)
        if _FLOAT_RE.fullmatch(tok) or tok in _SPECIAL_FLOATS:
            # The converter receives the characters exactly as written.
            value = self.parse_float(tok)
            if isinstance(value, (dict, list)):
                raise ValueError(
                    "parse_float returned a %s; only scalar values may be "
                    "produced for TOML floats" % type(value).__name__
                )
            return value
        self._err("invalid value %r" % (tok,), p)

    # -------------------------------------------------------- date and time

    def _make_time(self, g, p):
        h, mi = int(g["h"]), int(g["mi"])
        s = int(g["s"]) if g.get("s") else 0
        if h > 23 or mi > 59 or s > 59:
            self._err("invalid time of day", p)
        frac = g.get("frac") or ""
        # spec: N-000156 N-000157 N-000158 N-000291 N-000292
        us = int(frac[:6].ljust(6, "0")) if frac else 0
        return datetime.time(h, mi, s, us)

    def _local_time(self, g, p):
        # spec: N-000154 N-000155 N-000160 N-000161
        return self._make_time(g, p)

    def _datetime(self, g, p):
        # spec: N-000151 N-000152 N-000153 N-000159 N-000160 N-000161
        # spec: N-000179 N-000180
        try:
            day = datetime.date(int(g["y"]), int(g["mo"]), int(g["d"]))
        except ValueError:
            self._err("invalid calendar date", p)
        if g.get("h") is None:
            return day
        t = self._make_time(g, p)
        off = g.get("off")
        if off is None:
            return datetime.datetime.combine(day, t)
        if off == "Z" or off == "z":
            tz = datetime.timezone.utc
        else:
            oh, om = int(g["oh"]), int(g["om"])
            if oh > 23 or om > 59:
                self._err("invalid UTC offset", p)
            delta = datetime.timedelta(hours=oh, minutes=om)
            if g["osign"] == "-":
                delta = -delta
            tz = datetime.timezone(delta)
        return datetime.datetime.combine(day, t, tzinfo=tz)

    # -------------------------------------------------------------- strings

    def _escape(self):
        """Decode the escape at ``self.pos`` (a backslash) and advance past it."""
        # spec: N-000137 N-000138 N-000139 N-000140 N-000141 N-000142 N-000143
        # spec: N-000174 N-000175 N-000176 N-000177
        p, src = self.pos, self.src
        c = src[p + 1] if p + 1 < self.n else ""
        if c and c in _ESCAPES:
            self.pos = p + 2
            return _ESCAPES[c]
        if c and c in _UNICODE_ESCAPE_LEN:
            width = _UNICODE_ESCAPE_LEN[c]
            digits = src[p + 2 : p + 2 + width]
            if len(digits) == width and _HEX_DIGITS_RE.fullmatch(digits):
                code = int(digits, 16)
                if code > 0x10FFFF or 0xD800 <= code <= 0xDFFF:
                    self._err("escape is not a Unicode scalar value", p)
                self.pos = p + 2 + width
                return chr(code)
        self._err("invalid escape sequence", p)

    def _basic_string_one_line(self):
        # spec: N-000127 N-000128 N-000129 N-000137 N-000143 N-000178
        start = self.pos
        p = start + 1
        src, n = self.src, self.n
        out = []
        while True:
            m = _BASIC_CHUNK.match(src, p)
            if m is not None:
                out.append(m.group())
                p = m.end()
            if p >= n:
                self._err("unterminated string", start)
            c = src[p]
            if c == '"':
                self.pos = p + 1
                return "".join(out)
            if c == "\\":
                self.pos = p
                out.append(self._escape())
                p = self.pos
                continue
            self._err("invalid character in string", p)

    def _literal_string_one_line(self):
        # spec: N-000127 N-000129 N-000178
        start = self.pos
        p = start + 1
        src, n = self.src, self.n
        out = []
        while True:
            m = _LITERAL_CHUNK.match(src, p)
            if m is not None:
                out.append(m.group())
                p = m.end()
            if p >= n:
                self._err("unterminated string", start)
            c = src[p]
            if c == "'":
                self.pos = p + 1
                return "".join(out)
            self._err("invalid character in string", p)

    def _ml_basic_string(self):
        # spec: N-000131 N-000132 N-000133 N-000134 N-000135 N-000136
        # spec: N-000137 N-000138 N-000140 N-000178 N-000179
        start = self.pos
        p = start + 3
        src, n = self.src, self.n
        if p < n and src[p] == "\n":
            p += 1
        out = []
        while True:
            m = _ML_BASIC_CHUNK.match(src, p)
            if m is not None:
                out.append(m.group())
                p = m.end()
            if p >= n:
                self._err("unterminated multi-line string", start)
            c = src[p]
            if c == '"':
                closed, p = self._quote_run(p, '"', out)
                if closed:
                    self.pos = p
                    return "".join(out)
                continue
            if c == "\\":
                j = p + 1
                while j < n and (src[j] == " " or src[j] == "\t"):
                    j += 1
                if j < n and src[j] == "\n":
                    # Line-ending backslash: drop it and all following whitespace.
                    p = j
                    while p < n and (src[p] == " " or src[p] == "\t" or src[p] == "\n"):
                        p += 1
                    continue
                self.pos = p
                out.append(self._escape())
                p = self.pos
                continue
            self._err("invalid character in multi-line string", p)

    def _ml_literal_string(self):
        # spec: N-000130 N-000131 N-000132 N-000135 N-000178
        start = self.pos
        p = start + 3
        src, n = self.src, self.n
        if p < n and src[p] == "\n":
            p += 1
        out = []
        while True:
            m = _ML_LITERAL_CHUNK.match(src, p)
            if m is not None:
                out.append(m.group())
                p = m.end()
            if p >= n:
                self._err("unterminated multi-line string", start)
            c = src[p]
            if c == "'":
                closed, p = self._quote_run(p, "'", out)
                if closed:
                    self.pos = p
                    return "".join(out)
                continue
            self._err("invalid character in multi-line string", p)

    def _quote_run(self, p, quote, out):
        """Consume a run of ``quote`` characters at ``p`` inside a multi-line string.

        Up to two quotes may sit before the closing delimiter, so a run of three
        to five closes the string and a run of six or more is an error.
        Returns ``(closed, new_position)``; quotes that are content are appended.
        """
        # spec: N-000135 N-000136
        j = p
        while j < self.n and self.src[j] == quote:
            j += 1
        run = j - p
        if run >= 3:
            if run > 5:
                self._err("too many quote characters before closing delimiter", p)
            out.append(quote * (run - 3))
            return True, j
        out.append(quote * run)
        return False, j

    # ---------------------------------------------------- arrays and tables

    def _parse_array(self):
        # spec: N-000105 N-000106 N-000220 N-000221
        start = self.pos
        self._enter(start)
        self.pos += 1
        arr = []
        while True:
            self._skip_wsnc()
            c = self._peek()
            if c == "]":
                self.pos += 1
                break
            if c == "":
                self._err("unterminated array")
            arr.append(self._parse_value())
            self._skip_wsnc()
            c = self._peek()
            if c == ",":
                self.pos += 1
                continue
            if c == "]":
                self.pos += 1
                break
            self._err("expected ',' or ']' in array")
        self.depth -= 1
        return arr

    def _parse_inline_table(self):
        # spec: N-000103 N-000104 N-000113 N-000114 N-000115 N-000116
        start = self.pos
        self._enter(start)
        self.pos += 1
        table = {}
        self._skip_wsnc()
        if self._peek() == "}":
            self.pos += 1
        else:
            while True:
                self._key_value(table)
                self._skip_wsnc()
                c = self._peek()
                if c == ",":
                    self.pos += 1
                    self._skip_wsnc()
                    if self._peek() == "}":
                        self.pos += 1
                        break
                    continue
                if c == "}":
                    self.pos += 1
                    break
                self._err("expected ',' or '}' in inline table")
        self.flags[id(table)] = _INLINE
        self.depth -= 1
        return table


def parse_document(text, parse_float):
    """Parse TOML text (a ``str``) and return the document mapping."""
    return _Parser(text, parse_float).parse()
