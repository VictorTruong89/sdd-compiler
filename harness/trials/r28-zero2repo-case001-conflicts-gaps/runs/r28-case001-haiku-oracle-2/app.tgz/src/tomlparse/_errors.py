"""The decode error raised for invalid TOML.

# spec: N-000307 N-000308 N-000309 N-000310 N-000311 N-000312 N-000313
# spec: N-000314 N-000315 N-000316 N-000317 N-000318 N-000319 N-000320
# spec: N-000321 N-000322 N-000323
# spec: N-000198 N-000199 N-000200 N-000201 N-000202 N-000203 N-000204
# spec: N-000205 N-000206 N-000207 N-000208 N-000209 N-000210 N-000211
# spec: N-000212 N-000217 N-000218 N-000219
"""


class TOMLDecodeError(ValueError):
    """Raised when a document is not valid TOML v1.1.0.

    Constructed as ``TOMLDecodeError(msg, doc, pos)``: ``msg`` is the
    unformatted reason, ``doc`` the document text and ``pos`` a 0-based
    character offset into ``doc``. ``lineno`` and ``colno`` (both 1-based)
    are derived from ``pos``.
    """

    def __init__(self, msg, doc, pos):
        self.msg = msg
        self.doc = doc
        self.pos = pos
        end = len(doc)
        prefix = doc[: min(max(pos, 0), end)]
        self.lineno = prefix.count("\n") + 1
        self.colno = len(prefix) - prefix.rfind("\n")
        if pos >= end:
            text = "%s (at end of document, line %d, column %d)" % (
                msg,
                self.lineno,
                self.colno,
            )
        else:
            text = "%s (line %d, column %d, char %d)" % (
                msg,
                self.lineno,
                self.colno,
                pos,
            )
        super().__init__(text)

    def __reduce__(self):
        return (self.__class__, (self.msg, self.doc, self.pos))
