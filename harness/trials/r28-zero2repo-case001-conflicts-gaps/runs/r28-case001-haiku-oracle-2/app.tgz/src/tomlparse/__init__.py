"""tomlparse: a pure-Python TOML v1.1.0 parser.

Public surface: ``loads``, ``load`` and ``TOMLDecodeError``.

# spec: N-000266 N-000267 N-000268 N-000270 N-000271 N-000272 N-000273
"""

from ._api import load, loads
from ._errors import TOMLDecodeError

__all__ = ["loads", "load", "TOMLDecodeError"]
