"""The two parse entries: ``loads`` (text) and ``load`` (binary file).

# spec: N-000266 N-000267 N-000268 N-000269 N-000270 N-000271 N-000272
# spec: N-000273 N-000274 N-000275 N-000276 N-000277 N-000278 N-000279
# spec: N-000280 N-000281 N-000282 N-000283 N-000284 N-000285 N-000286
# spec: N-000287 N-000288 N-000289 N-000290 N-000291 N-000292 N-000293
# spec: N-000294 N-000295 N-000296 N-000297 N-000298
# spec: N-000181 N-000182 N-000183 N-000184 N-000185 N-000186 N-000187
# spec: N-000188 N-000189 N-000190 N-000191 N-000192 N-000193 N-000194
# spec: N-000195 N-000196 N-000197 N-000213 N-000214 N-000215 N-000216
# spec: N-000299 N-000300 N-000301 N-000302 N-000303 N-000304 N-000305
# spec: N-000306
"""

import io

from ._parser import parse_document


def loads(s, *, parse_float=float):
    """Parse the TOML document in the text string ``s`` into a ``dict``.

    ``parse_float`` is called with each float's characters as written in the
    document and its return value is stored in place of the float. Raises
    ``TypeError`` if ``s`` is not a ``str``, ``TOMLDecodeError`` if the text is
    not valid TOML v1.1.0, and ``ValueError`` if ``parse_float`` returns a dict
    or list.
    """
    if not isinstance(s, str):
        raise TypeError(
            "loads() expects a str, not %s" % type(s).__name__
        )
    return parse_document(s, parse_float)


def load(fp, *, parse_float=float):
    """Parse the TOML document read from the binary file object ``fp``.

    The bytes are decoded as UTF-8 and then parsed as ``loads`` would parse
    them. A text-mode file object is refused with ``TypeError``.
    """
    # spec: N-000181 N-000190 N-000299 N-000300 N-000304
    if isinstance(fp, io.TextIOBase):
        raise TypeError("load() expects a file opened in binary mode, not text mode")
    read = getattr(fp, "read", None)
    if read is None:
        raise TypeError("load() expects a binary file object with a read() method")
    data = read()
    if isinstance(data, str):
        raise TypeError("load() expects bytes from the file, not text")
    if not isinstance(data, (bytes, bytearray)):
        raise TypeError("load() expects bytes from the file, not %s" % type(data).__name__)
    text = bytes(data).decode("utf-8")
    return parse_document(text, parse_float)
