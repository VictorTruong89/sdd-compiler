"""Every id in spec/CHECKLIST.md must be referenced by the implementation or the tests.

Ids that have nothing to implement are listed in NOT_APPLICABLE with the reason.
"""
import os
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ID_RE = re.compile(r"N[-_]\d{6}")  # node ids, written N-000001 or in test names as N_000001

NOT_APPLICABLE = {
    "N-000073": "Non-goal: throughput is not guaranteed. Speed is a design goal, "
    "so there is no performance requirement to test.",
    "N-000074": "Non-goal statement about speed (design goal, not a requirement); "
    "no behaviour to check.",
}


def _norm(match_text):
    return match_text.replace("_", "-")


def _ids_in_checklist():
    with open(os.path.join(ROOT, "spec", "CHECKLIST.md"), encoding="utf-8") as fh:
        return sorted(set(ID_RE.findall(fh.read())))


def _referenced_ids():
    found = set()
    for base in ("src", "tests"):
        for dirpath, _dirs, files in os.walk(os.path.join(ROOT, base)):
            for name in files:
                if name.endswith((".py", ".toml")):
                    with open(os.path.join(dirpath, name), encoding="utf-8") as fh:
                        found.update(_norm(i) for i in ID_RE.findall(fh.read()))
    return found


def test_every_checklist_id_is_referenced_or_explained():
    ids = _ids_in_checklist()
    assert len(ids) == 323
    refs = _referenced_ids()
    missing = [i for i in ids if i not in refs and i not in NOT_APPLICABLE]
    assert missing == []


def test_not_applicable_entries_are_real_checklist_ids():
    ids = set(_ids_in_checklist())
    for node_id in NOT_APPLICABLE:
        assert node_id in ids
    for node_id, reason in NOT_APPLICABLE.items():
        assert ID_RE.fullmatch(node_id) and reason.strip()
