"""FP-01: document structure, tables, arrays, comments, invalid structure.

# spec: N-000077 N-000078 N-000079 N-000080 N-000081 N-000082 N-000083
# spec: N-000084 N-000085 N-000086 N-000087 N-000088 N-000089 N-000090
# spec: N-000091 N-000092 N-000093 N-000094 N-000095 N-000096 N-000097
# spec: N-000098 N-000099 N-000100 N-000101 N-000102 N-000103 N-000104
# spec: N-000105 N-000106 N-000107 N-000108 N-000109 N-000110 N-000111
# spec: N-000112 N-000113 N-000114 N-000115 N-000116 N-000117 N-000118
# spec: N-000119 N-000120 N-000121 N-000122 N-000123 N-000141 N-000142
# spec: N-000183 N-000184 N-000185 N-000186 N-000187 N-000188
# spec: N-000280 N-000281 N-000282 N-000293 N-000294 N-000295 N-000296
"""
import pytest

from tomlparse import TOMLDecodeError, loads


def test_N_000082_empty_and_comment_only_documents():
    assert loads("") == {}
    assert loads("   \t  ") == {}
    assert loads("# only a comment") == {}
    assert loads("# only a comment\n") == {}
    assert loads("\n\n# c\n\n") == {}


def test_N_000083_N_000084_root_and_table_pairs():
    doc = "root = 1\n[t]\na = 2\n[u]\nb = 3\n"
    assert loads(doc) == {"root": 1, "t": {"a": 2}, "u": {"b": 3}}


def test_N_000085_N_000086_N_000087_keys_are_strings_and_case_sensitive():
    assert loads("1 = 1\ntrue = 2\ninf = 3\nnan = 4") == {"1": 1, "true": 2, "inf": 3, "nan": 4}
    assert loads("Key = 1\nkey = 2") == {"Key": 1, "key": 2}
    assert loads("a-b_c-1 = 0") == {"a-b_c-1": 0}


def test_N_000088_table_names_case_sensitive():
    assert loads("[T]\nx=1\n[t]\nx=2") == {"T": {"x": 1}, "t": {"x": 2}}


def test_N_000089_N_000090_N_000091_N_000092_quoted_keys():
    assert loads('"a.b" = 1') == {"a.b": 1}
    assert loads("'a.b' = 1") == {"a.b": 1}
    assert loads('"# sp ace é" = 1') == {"# sp ace é": 1}
    assert loads('"" = 1') == {"": 1}  # empty quoted key allowed (CF-000074)


def test_N_000141_N_000142_literal_key_not_escaped_and_distinct_spellings():
    assert loads(r"'\u0041' = 1") == {"\\u0041": 1}
    assert loads(r'"A" = 1') == {"A": 1}
    assert loads(r"""'a\t' = 1
"a\t" = 2""") == {"a\\t": 1, "a\t": 2}


def test_N_000093_N_000094_N_000095_dotted_keys_and_whitespace():
    assert loads("a . b . c = 1") == {"a": {"b": {"c": 1}}}
    assert loads("a.b = 1\na.c = 2") == {"a": {"b": 1, "c": 2}}
    assert loads("[t]\na.b = 1\na.c.d = 2") == {"t": {"a": {"b": 1, "c": {"d": 2}}}}


def test_N_000096_N_000097_header_creates_missing_parents():
    assert loads("[a.b.c]\nx = 1") == {"a": {"b": {"c": {"x": 1}}}}
    assert loads("[a.b.c]\nx = 1\n[a]\ny = 2") == {"a": {"b": {"c": {"x": 1}}, "y": 2}}


def test_N_000098_sub_table_of_dotted_table_may_be_declared_by_header():
    doc = "[fruit]\napple.color = 'red'\n[fruit.apple.texture]\nsmooth = true\n"
    assert loads(doc) == {"fruit": {"apple": {"color": "red", "texture": {"smooth": True}}}}


def test_N_000099_N_000100_N_000101_N_000102_array_of_tables():
    doc = (
        "[[fruit]]\nname = 'apple'\n[[fruit.variety]]\nname='red'\n"
        "[[fruit.variety]]\nname='gala'\n[[fruit]]\nname='banana'\n"
    )
    assert loads(doc) == {"fruit": [
        {"name": "apple", "variety": [{"name": "red"}, {"name": "gala"}]},
        {"name": "banana"},
    ]}


def test_N_000102_implied_parent_is_mapping_and_can_be_declared_later():
    doc = "[[a.b]]\nx = 1\n[a]\ny = 2\n"
    assert loads(doc) == {"a": {"b": [{"x": 1}], "y": 2}}
    with pytest.raises(TOMLDecodeError):
        loads("[[a.b]]\n[a]\n[[a]]")


def test_N_000103_N_000104_inline_tables():
    assert loads("a = {}") == {"a": {}}
    assert loads("a = {b = 1, c.d = 2}") == {"a": {"b": 1, "c": {"d": 2}}}
    assert loads("a = {\n  b = 1, # comment\n  c = 2,\n}") == {"a": {"b": 1, "c": 2}}


def test_N_000105_N_000106_arrays():
    assert loads("a = []") == {"a": []}
    assert loads("a = [1, 'two', [3], {x = 4}]") == {"a": [1, "two", [3], {"x": 4}]}
    assert loads("a = [\n 1, # one\n 2,\n]") == {"a": [1, 2]}
    assert loads("a = [[1,2],[3]]") == {"a": [[1, 2], [3]]}


def test_N_000107_N_000108_N_000109_comments():
    assert loads("a = 1 # trailing") == {"a": 1}
    assert loads("a = 1#no space") == {"a": 1}
    assert loads("a = 'x#y' # real") == {"a": "x#y"}
    assert loads("# ünïcode comment\na = 1") == {"a": 1}
    assert loads("[t] # c\nx = 1") == {"t": {"x": 1}}


def test_N_000110_indentation_insignificant():
    assert loads("[t]\n\t\ta\t=\t1\n    b = 2") == {"t": {"a": 1, "b": 2}}


def test_N_000111_N_000112_crlf_is_single_line_feed():
    assert loads("a = 1\r\nb = 2\r\n") == {"a": 1, "b": 2}
    assert loads('s = """x\r\ny\r\n"""') == {"s": "x\ny\n"}
    assert loads("s = '''\r\na\r\nb'''") == {"s": "a\nb"}


def test_N_000113_N_000114_N_000115_N_000116_N_000117_structural_violations():
    bad = [
        "a = 1\na = 2",                 # duplicate key
        "[a]\n[a]",                     # table defined twice
        "[a]\nx=1\n[a.x]",              # reopen via header a non-table
        "a.b = 1\n[a]\nb = 2",          # dotted-defined table redefined
        "a = 1\n[a]",                   # value replaced with table
        "[[a]]\n[a]",                   # array of tables replaced with table
        "[a]\nb = 1\n[a.b]",            # value replaced by table
        "a = {b = 1}\n[a.c]",           # adding to inline table via header
        "a = {b = 1}\na.c = 2",         # adding to inline table via dotted
        "x = [1]\n[[x]]",               # static array used as AoT
        "[a]\nb.c = 1\n[a.b]",          # reopen dotted table via header
        "a = 1 b = 2",                  # two pairs on one line
        "a.b = 1\na.b.c = 2",           # dotted key path crosses a value
        "[t]\n[t.u]\n[t]",              # table defined twice (later)
    ]
    for doc in bad:
        with pytest.raises(TOMLDecodeError):
            loads(doc)


def test_N_000118_N_000119_N_000120_N_000121_N_000122_more_invalid_structure():
    bad = [
        "= 1",                      # pair with no key
        "a =",                      # pair with no value
        "a",                        # key without '='
        '"""a""" = 1',              # multi-line string as key
        "[\"\"\"a\"\"\"]",          # multi-line string as table name
        "[a\nb = 1]",               # header not closed on its line
        "[a] b = 1",                # header shares its line with a pair
        "[a",                       # unclosed header
        "a = {b = 1,,}",            # double comma in inline table
        "a = [1 2]",                # missing comma
    ]
    for doc in bad:
        with pytest.raises(TOMLDecodeError):
            loads(doc)


def test_N_000113_inline_table_is_frozen_after_written():
    with pytest.raises(TOMLDecodeError):
        loads("a = {}\n[a]\nx = 1")


def test_N_000119_non_error_table_after_array_of_tables_element():
    assert loads("[[t]]\n[t.sub]\nx = 1") == {"t": [{"sub": {"x": 1}}]}


def test_N_000123_N_000183_N_000184_N_000187_N_000188_structure_matches_text():
    doc = "[a]\nb = [1, {c = 2}]\n"
    assert loads(doc) == {"a": {"b": [1, {"c": 2}]}}
    assert type(loads(doc)) is dict


def test_N_000280_keys_are_str_and_document_is_dict():
    d = loads("[t]\nq = 1")
    assert type(d) is dict and type(d["t"]) is dict
    assert all(type(k) is str for k in d["t"])


def test_N_000281_N_000282_arrays_are_lists_in_order():
    assert loads("a = [3, 1, 2]") == {"a": [3, 1, 2]}
    assert type(loads("a = [1]")["a"]) is list


def test_N_000293_empty_document_yields_empty_dict():
    assert loads("") == {} and type(loads("")) is dict


def test_N_000294_N_000295_N_000296_failures_return_no_mapping():
    with pytest.raises(TOMLDecodeError):
        loads("a = 1\nb = ")
