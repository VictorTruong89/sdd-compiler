"""PRD terminology and public-surface inventory (FP entries as observed by callers).

# spec: N-000012 N-000013 N-000014 N-000015 N-000016 N-000017 N-000018
# spec: N-000019 N-000020 N-000021 N-000022 N-000023 N-000024 N-000025
# spec: N-000026 N-000027 N-000028 N-000029 N-000030
# spec: N-000031 N-000032 N-000033 N-000034 N-000035 N-000036 N-000037
# spec: N-000038 N-000039 N-000001 N-000002 N-000003 N-000004 N-000005
# spec: N-000006 N-000007 N-000008 N-000009 N-000010 N-000011
# spec: N-000049 N-000050 N-000051 N-000052 N-000053 N-000054 N-000055
# spec: N-000056 N-000057 N-000058 N-000059 N-000060 N-000061 N-000062
# spec: N-000063 N-000064 N-000065 N-000066 N-000067 N-000068 N-000069
# spec: N-000070 N-000071 N-000072 N-000075 N-000076
"""
import datetime as dt
import pathlib
import re

import pytest

import tomlparse
from tomlparse import loads

SRC_DIR = pathlib.Path(tomlparse.__file__).resolve().parent


def test_N_000012_one_document_per_call():
    assert loads("a = 1") == {"a": 1}
    assert loads("b = 2") == {"b": 2}  # independent calls; no state carried over


def test_N_000013_N_000014_entries_take_text_and_binary():
    import io
    assert loads("x = 1") == {"x": 1}
    assert tomlparse.load(io.BytesIO(b"x = 1")) == {"x": 1}


def test_N_000015_document_mapping_keys_str_values_native():
    d = loads("a = 1\nb = 'x'\nc = [true]\nd = {e = 1.5}")
    assert all(isinstance(k, str) for k in d)
    assert d == {"a": 1, "b": "x", "c": [True], "d": {"e": 1.5}}


def test_N_000016_table_forms_are_mappings():
    d = loads("[h]\na = 1\n[h.i]\nb = 2\n[x]\nc.d = 3\n[y]\nz = {q = 1}")
    assert type(d["h"]) is dict and type(d["h"]["i"]) is dict
    assert type(d["x"]["c"]) is dict and type(d["y"]["z"]) is dict


def test_N_000017_N_000018_arrays_are_lists():
    d = loads("a = [1, 2]\n[[t]]\nx = 1")
    assert type(d["a"]) is list and type(d["t"]) is list and type(d["t"][0]) is dict


def test_N_000019_bare_keys_are_latin_letters_digits_underscore_hyphen():
    assert loads("Az09_-q = 1") == {"Az09_-q": 1}
    with pytest.raises(Exception):
        loads("é = 1")


def test_N_000020_N_000021_dotted_key_parts_and_quoted_dots():
    assert loads('a."b.c".d = 1') == {"a": {"b.c": {"d": 1}}}


def test_N_000022_inline_table_frozen_after_written():
    with pytest.raises(Exception):
        loads("a = {b = 1}\na.c = 2")


def test_N_000023_N_000024_offset_datetime_joined_by_T_or_t():
    v = loads("a = 1979-05-27t07:32:00Z")["a"]
    assert v.tzinfo is not None and v.utcoffset() == dt.timedelta(0)


def test_N_000025_N_000026_N_000027_local_forms():
    d = loads("a = 1979-05-27T07:32:00\nb = 1979-05-27\nc = 07:32:00")
    assert d["a"].tzinfo is None and type(d["b"]) is dt.date and type(d["c"]) is dt.time


def test_N_000028_local_time_seconds_optional_per_TOML_1_1():
    assert loads("c = 07:32")["c"] == dt.time(7, 32)  # CF-000062


def test_N_000029_converter_result_rules_are_checked_in_float_tests():
    # Covered in test_load_and_converter.py (N-000232 .. N-000233).
    assert loads("a = 1.5", parse_float=lambda t: "s") == {"a": "s"}


def test_N_000030_decode_error_is_value_error():
    with pytest.raises(ValueError):
        loads("=")


def test_N_000031_N_000032_library_only_no_cli_or_writer_surface():
    names = set(n for n in dir(tomlparse) if not n.startswith("_"))
    assert names == {"loads", "load", "TOMLDecodeError"}
    assert not (SRC_DIR / "__main__.py").exists()


def test_N_000033_N_000034_N_000035_N_000036_N_000037_N_000038_N_000039_surface_inventory():
    import io
    assert loads("a = 1") == {"a": 1}                                   # FP-01 text entry
    assert loads("v = 1979-05-27") == {"v": dt.date(1979, 5, 27)}       # FP-02 scalars
    assert tomlparse.load(io.BytesIO(b"a=1")) == {"a": 1}               # FP-03 binary entry
    with pytest.raises(tomlparse.TOMLDecodeError):                      # FP-04 invalid
        loads("a = ")
    assert loads("a = 1.5", parse_float=float) == {"a": 1.5}            # FP-05 optional converter
    assert set(tomlparse.__all__) == {"loads", "load", "TOMLDecodeError"}  # no extra surfaces


def test_N_000040_N_000041_N_000042_pure_python_no_runtime_dependencies():
    import ast
    stdlib = {"bisect", "datetime", "re", "io", "os", "sys"}
    for path in SRC_DIR.glob("*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                mods = [a.name.split(".")[0] for a in node.names]
            elif isinstance(node, ast.ImportFrom) and node.level == 0:
                mods = [node.module.split(".")[0]]
            else:
                continue
            assert all(m in stdlib for m in mods), (path.name, mods)


def test_N_000043_N_000237_N_000246_python_3_8_syntax():
    import ast
    for path in SRC_DIR.glob("*.py"):
        ast.parse(path.read_text(encoding="utf-8"), feature_version=(3, 8))


def test_N_000044_N_000045_N_000242_N_000243_no_platform_specific_code():
    for path in SRC_DIR.glob("*.py"):
        text = path.read_text(encoding="utf-8")
        assert not re.search(r"sys\.platform|os\.name|platform\.system", text), path.name


def test_N_000046_N_000047_N_000048_N_000254_cpu_only_import_from_source_tree():
    # Parser imports from the source tree; no accelerator library is pulled in.
    text = "".join(p.read_text(encoding="utf-8") for p in SRC_DIR.glob("*.py"))
    assert not re.search(r"\b(torch|numpy|cupy|cuda|jax)\b", text)


def test_N_000049_N_000067_N_000068_N_000069_N_000070_N_000071_TOML_1_1_features_accepted():
    assert loads("a = {b = 1,\n c = 2,}") == {"a": {"b": 1, "c": 2}}   # newlines + trailing comma
    assert loads(r's = "\e\x41"') == {"s": "\x1b" + "A"}               # \e and \x escapes
    assert loads("t = 07:32") == {"t": dt.time(7, 32)}                  # seconds omitted
    assert loads("d = 1979-05-27T07:32Z")["d"].tzinfo is not None


def test_N_000050_text_mode_is_not_product_input():
    import io
    with pytest.raises(TypeError):
        tomlparse.load(io.StringIO("a = 1"))


def test_N_000051_N_000052_plain_builtin_results_no_custom_node_types():
    d = loads("a = [1, {b = 'c'}]\n[t]\nq = 2.5")
    assert type(d) is dict and type(d["a"]) is list and type(d["a"][1]) is dict
    assert type(d["t"]["q"]) is float


def test_N_000053_error_text_wording_not_asserted():
    # The tests check kind and location, not message wording (N-000055, N-000056).
    err = tomlparse.TOMLDecodeError("x", "a\nb", 2)
    assert err.lineno == 2 and err.colno == 1


def test_N_000054_N_000055_failure_kind_and_location_are_fixed():
    with pytest.raises(tomlparse.TOMLDecodeError) as info:
        loads("a = 1\n@")
    assert (info.value.lineno, info.value.colno, info.value.pos) == (2, 1, 6)


def test_N_000057_N_000058_N_000058_N_000076_no_external_toml_parser_used():
    text = "".join(p.read_text(encoding="utf-8") for p in SRC_DIR.glob("*.py"))
    assert not re.search(r"^\s*(import|from)\s+(tomllib|toml|tomli)\b", text, re.M)


def test_N_000059_N_000060_N_000061_N_000062_no_gpu_or_service_in_product():
    text = "".join(p.read_text(encoding="utf-8") for p in SRC_DIR.glob("*.py"))
    assert not re.search(r"^\s*(import|from)\s+(socket|threading|subprocess|http|urllib|multiprocessing)\b", text, re.M)


def test_N_000063_N_000064_N_000065_N_000066_no_writer_no_round_trip():
    assert not hasattr(tomlparse, "dump") and not hasattr(tomlparse, "dumps")
    d = loads("# comment\nb = 1\na = 2")
    assert d == {"b": 1, "a": 2} and "comment" not in repr(d)


def test_N_000072_no_command_line_or_server_product():
    assert not (SRC_DIR / "__main__.py").exists()
    text = "".join(p.read_text(encoding="utf-8") for p in SRC_DIR.glob("*.py"))
    assert "sys.argv" not in text and "__main__" not in text


def test_N_000075_no_speed_fuzzer_or_packaging_scripts_in_product_package():
    names = {p.name for p in SRC_DIR.iterdir()}
    assert not any(n in names for n in ("bench.py", "fuzz.py", "profile.py", "setup.py"))
