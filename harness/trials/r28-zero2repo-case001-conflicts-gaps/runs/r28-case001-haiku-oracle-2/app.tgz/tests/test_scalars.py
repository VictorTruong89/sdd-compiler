"""FP-02: TOML scalars as native Python values, and refusal of invalid scalars.

# spec: N-000124 N-000125 N-000126 N-000127 N-000128 N-000129 N-000130
# spec: N-000131 N-000132 N-000133 N-000134 N-000135 N-000136 N-000137
# spec: N-000138 N-000139 N-000140 N-000142 N-000143 N-000144 N-000145
# spec: N-000146 N-000147 N-000148 N-000149 N-000150 N-000151 N-000152
# spec: N-000153 N-000154 N-000155 N-000156 N-000157 N-000158 N-000159
# spec: N-000160 N-000161 N-000162 N-000163 N-000164 N-000165 N-000166
# spec: N-000167 N-000168 N-000169 N-000170 N-000171 N-000172 N-000173
# spec: N-000174 N-000175 N-000176 N-000177 N-000178 N-000179 N-000180
# spec: N-000283 N-000284 N-000285 N-000286 N-000287 N-000288 N-000289
# spec: N-000290 N-000291 N-000292
"""
import copy
import datetime as dt
import math

import pytest

from tomlparse import TOMLDecodeError, loads


def one(text):
    return loads("v = " + text)["v"]


def test_N_000124_N_000125_N_000126_booleans():
    assert one("true") is True and one("false") is False
    assert type(one("true")) is bool


@pytest.mark.parametrize("bad", ["True", "TRUE", "tRue", "truex"])
def test_N_000166_booleans_must_be_lowercase(bad):
    with pytest.raises(TOMLDecodeError):
        one(bad)


def test_N_000127_N_000128_N_000129_string_forms():
    assert one('"basic \\t"') == "basic \t"
    assert one("'lit \\t'") == "lit \\t"
    assert one('"""ml\nline"""') == "ml\nline"
    assert one("'''ml\nlit'''") == "ml\nlit"


def test_N_000130_N_000131_N_000132_multiline_first_newline_trimmed():
    # CF-000009: first line feed trimmed in both multi-line forms (TOML rule).
    assert one("'''\nabc'''") == "abc"
    assert one('"""\nabc"""') == "abc"
    assert one("'''\n\nabc'''") == "\nabc"
    assert one("'''  \nabc'''") == "  \nabc"


def test_N_000133_multiline_line_endings_kept():
    assert one('"""a\nb\n"""') == "a\nb\n"


def test_N_000134_N_000136_line_ending_backslash_trims_whitespace():
    # CF-000015: whitespace after a line-ending backslash is removed.
    assert one('"""a \\  \n   \n  b"""') == "a b"  # space before the backslash is content
    assert one('"""x\\\n    y"""') == "xy"


def test_N_000135_quotes_before_closing_delimiter_allowed():
    assert one('"""a""""') == 'a"'
    assert one('"""a"""""') == 'a""'
    assert one("'''a''''") == "a'"
    assert one("'''a'''''") == "a''"
    assert one('""""""') == ""


def test_N_000137_N_000138_N_000139_N_000140_escapes():
    assert one(r'"\b\t\n\f\r\e\"\\"') == "\b\t\n\f\r\x1b\"\\"
    assert one(r'"\x41\u00e9\U0001F600"') == "A\u00e9\U0001F600"
    assert one(r'"\u00E9"') == "\u00e9"           # hex digits case-insensitive
    assert one(r'"\x7f\x00"') == "\x7f\x00"


@pytest.mark.parametrize("bad", [
    r'"\q"', r'"\x4"', r'"\x"', r'"\u12"', r'"\U0011FFFF"', r'"\uD800"', r'"\UDFFFFFFF"',
    r'"\ "',
])
def test_N_000174_N_000175_N_000176_N_000177_bad_escapes(bad):
    with pytest.raises(TOMLDecodeError):
        one(bad)


def test_N_000141_literal_strings_take_backslashes_as_written():
    assert one(r"'C:\path\n'") == r"C:\path\n"
    assert one(r"'''a\nb'''") == r"a\nb"


def test_N_000143_tab_inside_strings_is_allowed_raw():
    # CF-000028, CF-000035, CF-000071: a raw tab is accepted in any one-line string.
    assert one('"a\tb"') == "a\tb"
    assert one("'a\tb'") == "a\tb"
    assert one('"a\\tb"') == "a\tb"


@pytest.mark.parametrize("bad", [
    '"a\x01b"', "'a\x7fb'", '"a\nb"', "'a\nb'", '"unterminated', "'unterminated",
    '"""never closed', "'''never closed",
    '"""a\rb"""',         # lone carriage return in multi-line basic string
    '"""a\\  b"""',       # line-ending backslash not followed by line ending
    '"""a""""""',        # six quotes before the close is more than two extra
])
def test_N_000178_control_chars_and_unclosed_strings(bad):
    with pytest.raises(TOMLDecodeError):
        one(bad)


def test_N_000144_N_000145_integers():
    assert one("0") == 0 and one("+0") == 0 and one("-0") == 0
    assert one("-17") == -17 and one("+17") == 17
    assert one("1_000_000") == 1000000
    assert one("0xdead_beef") == 0xDEADBEEF
    assert one("0xDEAD") == 0xDEAD              # hex digits either case
    assert one("0o755") == 0o755
    assert one("0b1101_0010") == 0b11010010
    assert type(one("1")) is int


def test_N_000146_N_000147_integer_digits_and_underscores():
    for bad in ["01", "-01", "1__0", "1_", "_1", "0_1", "+0x1", "-0x1", "0X1F",
                "0O7", "0B1", "0o8", "0b2", "0xG", "0x_1", "0x1_", "+0o7", "-0b1"]:
        with pytest.raises(TOMLDecodeError):
            one(bad)


def test_N_000148_N_000149_N_000150_floats():
    assert one("1.0") == 1.0 and type(one("1.0")) is float
    assert one("-0.5") == -0.5
    assert one("6.626e-34") == 6.626e-34
    assert one("1E3") == 1000.0
    assert one("1_000.5") == 1000.5
    assert one("1e+1_0") == 1e10
    assert one("inf") == math.inf and one("+inf") == math.inf and one("-inf") == -math.inf
    assert math.isnan(one("nan")) and math.isnan(one("+nan")) and math.isnan(one("-nan"))


@pytest.mark.parametrize("bad", ["1.", ".5", "1.e5", "00.5", "1e", "1.0e", "1__0.5", "1._5",
                                 "-.5", "+.1", "1..0", "1.0.0"])
def test_N_000173_floats_need_digits_on_both_sides(bad):
    with pytest.raises(TOMLDecodeError):
        one(bad)


def test_N_000151_N_000152_N_000153_offset_datetime():
    z = one("1979-05-27T07:32:00Z")
    assert z == dt.datetime(1979, 5, 27, 7, 32, tzinfo=dt.timezone.utc)
    assert z.utcoffset() == dt.timedelta(0)
    assert one("1979-05-27t07:32:00z").utcoffset() == dt.timedelta(0)
    off = one("1979-05-27T00:32:00-07:00")
    assert off.utcoffset() == dt.timedelta(hours=-7)
    assert one("1979-05-27 00:32:00+05:30").utcoffset() == dt.timedelta(hours=5, minutes=30)
    assert isinstance(off.tzinfo, dt.tzinfo)


def test_N_000151_local_datetime_is_naive():
    v = one("1979-05-27T07:32:00")
    assert v == dt.datetime(1979, 5, 27, 7, 32) and v.tzinfo is None


def test_N_000152_local_date_and_time():
    assert one("1979-05-27") == dt.date(1979, 5, 27)
    assert type(one("1979-05-27")) is dt.date
    t = one("07:32:00")
    assert t == dt.time(7, 32) and t.tzinfo is None


def test_N_000154_N_000155_seconds_may_be_omitted():
    # CF-000062: seconds may be omitted, including for local time.
    assert one("07:32") == dt.time(7, 32, 0)
    assert one("1979-05-27T07:32Z") == dt.datetime(1979, 5, 27, 7, 32, tzinfo=dt.timezone.utc)
    assert one("1979-05-27T07:32") == dt.datetime(1979, 5, 27, 7, 32)


def test_N_000156_N_000157_N_000291_N_000292_fractions_truncated_to_microseconds():
    # CF-000045 and CF-000069: truncation to six digits, not rounding.
    assert one("07:32:00.5").microsecond == 500000
    assert one("07:32:00.123").microsecond == 123000
    assert one("07:32:00.1234567").microsecond == 123456
    assert one("07:32:00.9999999").microsecond == 999999
    assert one("07:32:00.0000001").microsecond == 0
    assert one("07:32:00").microsecond == 0
    assert one("07:32:00.5").tzinfo is None


def test_N_000158_offset_fraction_and_copy_compare():
    v = one("1979-05-27T07:32:00.25+01:00")
    assert v.microsecond == 250000
    assert copy.deepcopy(v) == v and copy.copy(v) == v


def test_N_000159_leap_day_valid_in_leap_year_only():
    assert one("2024-02-29") == dt.date(2024, 2, 29)
    with pytest.raises(TOMLDecodeError):
        one("2023-02-29")


def test_N_000160_N_000161_dates_compare_as_standard_values():
    a = loads("a = 1979-05-27T07:32:00Z")["a"]
    assert a == dt.datetime(1979, 5, 27, 7, 32, tzinfo=dt.timezone.utc)
    assert one("1979-05-27") < dt.date(1980, 1, 1)


@pytest.mark.parametrize("bad", [
    "1979-13-01", "1979-00-10", "1979-02-30", "1979-05-32", "0000-01-01",
    "07:60:00", "24:00:00", "07:32:60", "07:99", "1979-05-27T25:00:00Z",
    "1979-05-27T07:32:00+24:00", "1979-05-27T07:32:00+05:60",
])
def test_N_000179_N_000180_invalid_dates_and_times_refused(bad):
    with pytest.raises(TOMLDecodeError):
        one(bad)


def test_N_000162_N_000163_N_000164_scalar_refusal_is_decode_error_not_type_error():
    for bad in ("nope", "0x", "1979-02-30", "'x", "=", "true false"):
        with pytest.raises(TOMLDecodeError) as info:
            one(bad)
        assert not isinstance(info.value, TypeError)


def test_N_000283_N_000285_integers_and_hex_in_lowercase_are_values():
    # CF-000037: the value of a hex literal is an int; case of the input digits is free.
    assert one("0xabcdef") == one("0xABCDEF") == 0xABCDEF


def test_N_000286_booleans_are_bool_not_int():
    assert type(one("true")) is bool
    assert type(one("false")) is bool


def test_N_000288_N_000289_N_000290_datetime_types():
    assert isinstance(one("1979-05-27T07:32:00Z"), dt.datetime)
    assert isinstance(one("1979-05-27T07:32:00"), dt.datetime)
    assert type(one("1979-05-27")) is dt.date
    assert type(one("07:32:00")) is dt.time
