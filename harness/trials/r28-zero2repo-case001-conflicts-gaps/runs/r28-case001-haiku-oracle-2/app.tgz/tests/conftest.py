import os
import sys

# Make the src layout importable when pytest runs from /app without PYTHONPATH.
_SRC = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src")
if _SRC not in sys.path:
    sys.path.insert(0, _SRC)
