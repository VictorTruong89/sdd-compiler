"""Hardware requirements and the CPU baseline execution profile.

# spec: N-000234 N-000235 N-000236 N-000237 N-000238 N-000239 N-000240
# spec: N-000241 N-000242 N-000243 N-000244 N-000245 N-000246 N-000247
# spec: N-000248 N-000249 N-000250 N-000251 N-000252 N-000253 N-000254
"""
import ast
import pathlib
import subprocess
import sys

import tomlparse

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC_DIR = ROOT / "src" / "tomlparse"


def test_N_000234_N_000235_N_000240_N_000245_cpu_baseline_parses_in_memory_text():
    out = subprocess.run(
        [sys.executable, "-c",
         "import sys; sys.path.insert(0, %r); import tomlparse; "
         "print(tomlparse.loads('a = [1, 2.5, \"x\"]'))" % str(ROOT / "src")],
        capture_output=True, text=True,
    )
    assert out.returncode == 0, out.stderr
    assert out.stdout.strip() == "{'a': [1, 2.5, 'x']}"


def test_N_000236_N_000239_N_000249_no_compiled_extensions_or_wheels_required():
    for path in ROOT.rglob("*"):
        if path.suffix in (".so", ".pyd", ".dylib", ".c", ".h", ".cpp", ".whl"):
            raise AssertionError("native artefact found: %s" % path)
    assert not (ROOT / "setup.py").exists()


def test_N_000237_N_000246_python_floor_3_8():
    text = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
    assert 'requires-python = ">=3.8"' in text
    for path in SRC_DIR.glob("*.py"):
        ast.parse(path.read_text(encoding="utf-8"), feature_version=(3, 8))


def test_N_000238_N_000242_N_000243_portable_pure_python_only():
    for path in SRC_DIR.glob("*.py"):
        assert "ctypes" not in path.read_text(encoding="utf-8")


def test_N_000244_N_000254_import_from_source_tree_without_install():
    code = (
        "import sys; sys.path.insert(0, %r); import tomlparse; "
        "assert tomlparse.__file__.startswith(%r)"
    ) % (str(ROOT / "src"), str(ROOT / "src"))
    assert subprocess.run([sys.executable, "-c", code]).returncode == 0


def test_N_000247_zero_runtime_dependencies_declared():
    text = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
    assert "dependencies = []" in text


def test_N_000250_N_000251_N_000252_N_000253_src_layout_pep517_build():
    text = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
    assert "build-backend" in text
    assert 'where = ["src"]' in text
    assert (ROOT / "src" / "tomlparse" / "__init__.py").exists()
    assert tomlparse.__name__ == "tomlparse"
