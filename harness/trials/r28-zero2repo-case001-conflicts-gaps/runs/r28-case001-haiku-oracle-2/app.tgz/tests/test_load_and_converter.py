"""FP-03 (binary-file entry) and FP-05 (float converter).

# spec: N-000181 N-000182 N-000183 N-000184 N-000185 N-000186 N-000187
# spec: N-000188 N-000189 N-000190 N-000191 N-000192 N-000193 N-000194
# spec: N-000195 N-000196 N-000216 N-000220 N-000221 N-000222 N-000223
# spec: N-000224 N-000225 N-000226 N-000227 N-000228 N-000229 N-000230
# spec: N-000231 N-000232 N-000233 N-000275 N-000276 N-000277 N-000296
# spec: N-000299 N-000300 N-000301 N-000302 N-000303 N-000305 N-000306
# spec: N-000294 N-000295 N-000297 N-000298
"""
import decimal
import io

import pytest

from tomlparse import TOMLDecodeError, load, loads


def test_N_000181_N_000189_N_000299_N_000300_load_reads_binary_file_object(tmp_path):
    p = tmp_path / "doc.toml"
    p.write_bytes(b'title = "x"\n[t]\nn = 1\n')
    with open(p, "rb") as fh:
        assert load(fh) == {"title": "x", "t": {"n": 1}}
    assert load(io.BytesIO(b"a = 2")) == {"a": 2}


def test_N_000183_N_000303_N_000302_empty_file_yields_empty_dict():
    assert load(io.BytesIO(b"")) == {}


def test_N_000183_N_000184_load_equals_loads_on_decoded_text():
    text = 'a = "café"\r\nb = [1, 2.5]\r\n'
    assert load(io.BytesIO(text.encode("utf-8"))) == loads(text)


def test_N_000190_N_000191_N_000192_N_000216_text_mode_refused(tmp_path):
    p = tmp_path / "t.toml"
    p.write_text("a = 1\n", encoding="utf-8")
    with open(p, "r") as fh:
        with pytest.raises(TypeError):
            load(fh)
    with pytest.raises(TypeError):
        load(io.StringIO(""))  # text-mode in-memory, even when empty


def test_N_000193_N_000194_N_000195_decode_error_from_binary_has_text_doc():
    with pytest.raises(TOMLDecodeError) as info:
        load(io.BytesIO("a = 1\nb = ".encode("utf-8")))
    assert info.value.doc == "a = 1\nb = "
    assert isinstance(info.value.doc, str)
    assert info.value.lineno == 2


def test_N_000196_loads_refuses_file_objects_and_bytes():
    with pytest.raises(TypeError):
        loads(io.BytesIO(b"a=1"))
    with pytest.raises(TypeError):
        loads(b"a=1")


def test_N_000297_N_000298_wrong_type_raises_without_mapping():
    with pytest.raises(TypeError):
        loads(12)


def test_N_000220_N_000221_N_000222_converter_called_for_floats_only():
    seen = []

    def conv(text):
        seen.append(text)
        return decimal.Decimal(text)

    doc = 'i = 1\ns = "x"\nb = true\nd = 1979-05-27\nf = 1.5\nlist = [2.5, 3]\n[t]\ng = -1_0e+2\nh = inf\nk = -nan'
    out = loads(doc, parse_float=conv)
    assert out["f"] == decimal.Decimal("1.5")
    assert out["list"] == [decimal.Decimal("2.5"), 3]
    assert out["t"]["g"] == decimal.Decimal("-1_0e+2")
    assert out["t"]["h"] == decimal.Decimal("inf")
    assert seen == ["1.5", "2.5", "-1_0e+2", "inf", "-nan"]
    assert out["i"] == 1 and type(out["i"]) is int


def test_N_000223_N_000224_N_000225_converter_receives_exact_text_and_result_bound():
    seen = []
    loads("a = +1.0e-3\nb = 6.626_070e+34", parse_float=lambda t: (seen.append(t), t.upper())[1])
    assert seen == ["+1.0e-3", "6.626_070e+34"]


def test_N_000226_converter_result_stored_unchanged():
    marker = object()
    out = loads("a = 1.5", parse_float=lambda t: marker)
    assert out["a"] is marker


def test_N_000227_N_000228_N_000229_structure_unaffected_by_converter():
    out = loads("[a]\nx = [1.0, {y = 2.0}]\nz = 1979-05-27T00:00:00Z\nw = 'str'",
                parse_float=lambda t: "F")
    assert out == {"a": {"x": ["F", {"y": "F"}], "z": out["a"]["z"], "w": "str"}}
    assert type(out["a"]["x"][1]["y"]) is str


def test_N_000230_N_000231_converter_may_return_any_non_container():
    assert loads("a = 1.0", parse_float=lambda t: None) == {"a": None}
    assert loads("a = 1.0", parse_float=lambda t: 42) == {"a": 42}


@pytest.mark.parametrize("returned", [{}, {"k": 1}, [], [1], "not-error"])
def test_N_000232_N_000233_illegal_converter_results(returned):
    doc = "a = 1.0"
    if returned == "not-error":
        assert loads(doc, parse_float=lambda t: returned) == {"a": "not-error"}
        return
    with pytest.raises(ValueError) as info:
        loads(doc, parse_float=lambda t: returned)
    assert not isinstance(info.value, TOMLDecodeError)


def test_N_000233_N_000296_subclass_of_dict_or_list_refused():
    class MyDict(dict):
        pass

    class MyList(list):
        pass

    for returned in (MyDict(), MyList()):
        with pytest.raises(ValueError) as info:
            loads("a = 1.0", parse_float=lambda t: returned)
        assert not isinstance(info.value, TOMLDecodeError)


def test_N_000232_load_path_also_applies_converter_rules(tmp_path):
    with pytest.raises(ValueError) as info:
        load(io.BytesIO(b"a = 1.0"), parse_float=lambda t: {})
    assert not isinstance(info.value, TOMLDecodeError)


def test_N_000275_N_000276_N_000277_default_is_builtin_float():
    assert type(loads("a = 2.5")["a"]) is float
    assert loads("a = 2.5", parse_float=float) == {"a": 2.5}


def test_N_000304_N_000305_N_000306_load_failure_kinds(tmp_path):
    with pytest.raises(TOMLDecodeError):
        load(io.BytesIO(b"a = "))
    with pytest.raises(TypeError):
        load(io.TextIOWrapper(io.BytesIO(b"a = 1"), encoding="utf-8"))
