"""Public surface, product constraints, and the decode error class.

# spec: N-000255 N-000256 N-000257 N-000258 N-000259 N-000260 N-000261
# spec: N-000262 N-000263 N-000264 N-000265 N-000266 N-000267 N-000268
# spec: N-000269 N-000270 N-000271 N-000272 N-000273 N-000307 N-000308
# spec: N-000309 N-000310 N-000311 N-000312 N-000313 N-000314 N-000315
# spec: N-000316 N-000317 N-000318 N-000319 N-000320 N-000321 N-000322
# spec: N-000323 N-000197 N-000198 N-000199 N-000200 N-000201 N-000202
# spec: N-000213 N-000214 N-000215 N-000217 N-000218 N-000219
"""
import builtins
import io
import os
import pickle
import subprocess
import sys

import pytest

import tomlparse
from tomlparse import TOMLDecodeError, load, loads

SRC = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src")


def test_N_000270_N_000271_N_000272_names_importable_from_root():
    from tomlparse import load as l2, loads as s2
    assert tomlparse.loads is s2 and tomlparse.load is l2
    assert tomlparse.TOMLDecodeError is TOMLDecodeError


def test_N_000255_N_000259_N_000260_no_writer_or_cli_surface():
    # Parser only: no dump/encode entry, no console entry point, no __main__.
    for name in ("dump", "dumps", "encode", "main"):
        assert not hasattr(tomlparse, name)
    assert not os.path.exists(os.path.join(SRC, "tomlparse", "__main__.py"))


def test_N_000261_parse_does_not_touch_files(monkeypatch):
    def boom(*a, **k):
        raise AssertionError("parse must not open files")
    monkeypatch.setattr(builtins, "open", boom)
    assert loads("a = [1, 2]") == {"a": [1, 2]}


def test_N_000266_N_000267_N_000268_importing_has_no_io_and_no_extensions():
    code = (
        "import builtins,sys\n"
        "sys.path.insert(0, %r)\n"
        "def boom(*a,**k): raise SystemExit('io during import')\n"
        "builtins.open = boom\n"
        "import tomlparse\n"
        "print('ok')\n"
    ) % SRC
    out = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True)
    assert out.returncode == 0 and out.stdout.strip() == "ok", out.stderr
    pkg = os.path.join(SRC, "tomlparse")
    assert not [f for f in os.listdir(pkg) if f.endswith((".so", ".pyd", ".pyc"))]
    assert os.path.realpath(tomlparse.__file__).startswith(os.path.realpath(SRC))


def test_N_000269_N_000262_N_000263_N_000264_N_000265_pure_python_no_deps():
    # Zero runtime third-party dependencies; pure Python source only.
    pkg = os.path.join(SRC, "tomlparse")
    assert all(f.endswith(".py") for f in os.listdir(pkg) if not f.startswith("__pycache__"))


def test_N_000198_N_000199_N_000200_decode_error_is_value_error_not_type_error():
    with pytest.raises(ValueError) as info:
        loads("a = ")
    assert isinstance(info.value, TOMLDecodeError)
    assert not isinstance(info.value, (TypeError, RecursionError))


def test_N_000307_N_000308_decode_error_hierarchy():
    assert issubclass(TOMLDecodeError, ValueError)
    assert not issubclass(TOMLDecodeError, TypeError)
    assert not issubclass(TOMLDecodeError, RecursionError)


def test_N_000309_N_000310_N_000311_N_000314_N_000315_N_000316_N_000317_attributes():
    err = TOMLDecodeError("bad thing", "ab\ncd", 4)
    assert err.msg == "bad thing"
    assert err.doc == "ab\ncd"
    assert err.pos == 4
    assert err.lineno == 2
    assert err.colno == 2


def test_N_000318_N_000319_lineno_colno_rules():
    # line = 1 + number of LF before offset; column = chars since last LF + 1
    err = TOMLDecodeError("m", "x\ny\nzz", 0)
    assert (err.lineno, err.colno) == (1, 1)
    err = TOMLDecodeError("m", "x\ny\nzz", 2)
    assert (err.lineno, err.colno) == (2, 1)
    err = TOMLDecodeError("m", "x\ny\nzz", 5)
    assert (err.lineno, err.colno) == (3, 2)


def test_N_000320_N_000321_N_000322_formatted_report_mentions_location():
    interior = str(TOMLDecodeError("oops", "a\nb", 2))
    assert "oops" in interior and "line 2" in interior and "column 1" in interior
    at_end = str(TOMLDecodeError("oops", "a\nb", 3))
    assert "end of document" in at_end and "oops" in at_end


def test_N_000323_N_000218_wording_is_free_but_contains_reason():
    assert "reason" in str(TOMLDecodeError("reason", "", 0))


def test_N_000312_N_000313_constructed_instances_and_pickling():
    err = TOMLDecodeError("m", "x = 1\ny", 6)
    again = pickle.loads(pickle.dumps(err))
    assert (again.msg, again.doc, again.pos, again.lineno, again.colno) == (
        "m", "x = 1\ny", 6, 2, 1)


def test_N_000205_N_000206_N_000207_N_000208_N_000209_error_positions_from_parse():
    with pytest.raises(TOMLDecodeError) as info:
        loads("a = 1\nb = @\n")
    err = info.value
    assert err.doc == "a = 1\nb = @\n"
    assert err.lineno == 2
    assert err.pos == 10  # index of '@'
    assert err.colno == 5


def test_N_000198_N_000212_end_of_document_position():
    with pytest.raises(TOMLDecodeError) as info:
        loads("a = [1,")
    assert info.value.pos == len("a = [1,")
    assert "end of document" in str(info.value)


def test_N_000210_N_000211_N_000212_caller_constructed_error_has_exact_values():
    e = TOMLDecodeError("r", "one\ntwo", 5)
    assert (e.msg, e.doc, e.pos) == ("r", "one\ntwo", 5)
    assert (e.lineno, e.colno) == (2, 2)
    assert "line 2" in str(e)


def test_N_000213_N_000214_N_000215_wrong_input_type_is_type_error():
    for bad in (b"a = 1", bytearray(b"a = 1"), 1, True, None, io.BytesIO(b"a=1")):
        with pytest.raises(TypeError) as info:
            loads(bad)
        assert not isinstance(info.value, TOMLDecodeError)


def test_N_000197_decode_error_for_invalid_toml_never_returns_mapping():
    with pytest.raises(TOMLDecodeError):
        loads("a = 1\nb = ")


def test_N_000216_N_000304_text_mode_file_is_type_error(tmp_path):
    p = tmp_path / "x.toml"
    p.write_text("a = 1\n", encoding="utf-8")
    with open(p, "r", encoding="utf-8") as fh:
        with pytest.raises(TypeError) as info:
            load(fh)
    assert not isinstance(info.value, TOMLDecodeError)
    with pytest.raises(TypeError):
        load(io.StringIO("a = 1"))
