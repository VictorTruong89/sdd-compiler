"""Table, array-of-tables and dotted-key rules, pinned against TOML v1.0 behaviour.

# spec: N-000096 N-000097 N-000098 N-000099 N-000100 N-000101 N-000102
# spec: N-000113 N-000114 N-000115 N-000116 N-000117 N-000118 N-000119
"""
import pytest

from tomlparse import TOMLDecodeError, loads

ACCEPTED = [
    ("[a.b.c]\nx=1\n[a]\nb.d = 1", {"a": {"b": {"c": {"x": 1}, "d": 1}}}),
    ("[a]\nb.c = 1\n[a.b.d]\nx=1", {"a": {"b": {"c": 1, "d": {"x": 1}}}}),
    ("a.b.c = 1\na.b.d = 2", {"a": {"b": {"c": 1, "d": 2}}}),
    ("[x.y.z.w]\n[x]", {"x": {"y": {"z": {"w": {}}}}}),
    ("[[a]]\nb = 1\n[a.c]\nd = 2\n[[a]]\n[a.c]\nd = 3",
     {"a": [{"b": 1, "c": {"d": 2}}, {"c": {"d": 3}}]}),
    ("[[a]]\n[[a.b]]\n[[a]]\n[[a.b]]", {"a": [{"b": [{}]}, {"b": [{}]}]}),
    ("[fruit]\napple.color = 'red'\napple.taste.sweet = true\n[fruit.apple.texture]\nsmooth = true",
     {"fruit": {"apple": {"color": "red", "taste": {"sweet": True}, "texture": {"smooth": True}}}}),
    ("[[a]]\nb.c = 1\n[[a]]\nb.c = 2", {"a": [{"b": {"c": 1}}, {"b": {"c": 2}}]}),
]

REJECTED = [
    "[a.b]\n[a]\nb.c = 1",
    "a = [{b = 1}]\n[[a]]",
    "[a]\n[a.b]\n[a]",
    "a = {b.c = 1}\n[a.b]",
    "[fruit]\napple.color = 'red'\n[fruit.apple]",
    "a.b = {c = 1}\na.b.d = 2",
    "[t]\nx = { y = 1 }\n[t.x.z]",
    "a = []\na.b = 1",
]


@pytest.mark.parametrize("doc,expected", ACCEPTED)
def test_N_000096_to_N_000102_accepted_table_structures(doc, expected):
    assert loads(doc) == expected


@pytest.mark.parametrize("doc", REJECTED)
def test_N_000113_to_N_000118_rejected_table_structures(doc):
    with pytest.raises(TOMLDecodeError):
        loads(doc)


def test_N_000119_array_of_tables_element_takes_sub_table_header():
    assert loads("[[t]]\n[t.sub]\nx = 1") == {"t": [{"sub": {"x": 1}}]}
