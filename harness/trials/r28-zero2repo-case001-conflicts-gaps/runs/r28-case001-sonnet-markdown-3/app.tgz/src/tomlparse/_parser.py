import re
from datetime import date, datetime, time, timedelta, timezone


class TOMLDecodeError(ValueError):
    """Raised when TOML text is invalid."""

    def __init__(self, msg, doc, pos):
        if not isinstance(msg, str):
            msg = str(msg)
        self.msg = msg
        self.doc = doc
        self.pos = pos
        try:
            self.lineno = doc.count("\n", 0, pos) + 1
            colno = pos - doc.rfind("\n", 0, pos)
        except Exception:
            self.lineno, colno = 1, pos + 1
        self.colno = colno
        if pos >= len(doc):
            loc = "at end of document"
        else:
            loc = "at line %d, column %d" % (self.lineno, self.colno)
        ValueError.__init__(self, "%s (%s)" % (msg, loc))

    def __reduce__(self):
        return (self.__class__, (self.msg, self.doc, self.pos))


class _Err(Exception):
    def __init__(self, msg, pos):
        self.msg = msg
        self.pos = pos


BARE = re.compile(r"[A-Za-z0-9_-]+")
TOKEN = re.compile(r"[A-Za-z0-9_+\-.:]+")
DEC = re.compile(r"[+-]?(?:0|[1-9](?:_?[0-9])*)")
HEX = re.compile(r"0x[0-9a-fA-F](?:_?[0-9a-fA-F])*")
OCT = re.compile(r"0o[0-7](?:_?[0-7])*")
BIN = re.compile(r"0b[01](?:_?[01])*")
FLOAT = re.compile(
    r"[+-]?(?:0|[1-9](?:_?[0-9])*)"
    r"(?:\.[0-9](?:_?[0-9])*(?:[eE][+-]?[0-9](?:_?[0-9])*)?|[eE][+-]?[0-9](?:_?[0-9])*)"
)
SPECIAL = re.compile(r"[+-]?(?:inf|nan)")
DATETIME = re.compile(
    r"([0-9]{4})-([0-9]{2})-([0-9]{2})"
    r"(?:[Tt ]([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?"
    r"([Zz]|[+-][0-9]{2}:[0-9]{2})?)?"
)
LOCALTIME = re.compile(r"([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?")
HEXRE = re.compile(r"[0-9a-fA-F]+")
ESC = {"b": "\b", "t": "\t", "n": "\n", "f": "\f", "r": "\r", "e": "\x1b",
       '"': '"', "\\": "\\"}
WS = " \t"


def _bad_ctrl(c):
    o = ord(c)
    return (o < 32 and c != "\t") or o == 127


def _mk_time(m, pos, off=None):
    h, mi, sec, frac = m
    h = int(h); mi = int(mi); sec = int(sec) if sec else 0
    if h > 23 or mi > 59 or sec > 59:
        raise _Err("Invalid time", pos)
    us = int((frac + "000000")[:6]) if frac else 0
    return h, mi, sec, us


class _Parser:
    def __init__(self, s, parse_float):
        self.s = s
        self.n = len(s)
        self.pf = parse_float
        self.dotted = set()
        self.implicit = set()
        self.inline = set()
        self.aot = set()

    # ---- helpers
    def skip_ws(self, i):
        s, n = self.s, self.n
        while i < n and s[i] in WS:
            i += 1
        return i

    def skip_comment(self, i):
        s, n = self.s, self.n
        j = i
        while j < n and s[j] != "\n":
            if _bad_ctrl(s[j]):
                raise _Err("Invalid control character in comment", j)
            j += 1
        return j

    def skip_wsnlc(self, i):
        s, n = self.s, self.n
        while i < n:
            c = s[i]
            if c in WS or c == "\n":
                i += 1
            elif c == "#":
                i = self.skip_comment(i)
            else:
                break
        return i

    def end_line(self, i):
        i = self.skip_ws(i)
        if i < self.n:
            if self.s[i] == "#":
                i = self.skip_comment(i)
            if i < self.n:
                if self.s[i] != "\n":
                    raise _Err("Expected end of line", i)
                i += 1
        return i

    # ---- keys
    def parse_key(self, i):
        parts = []
        s = self.s
        while True:
            i = self.skip_ws(i)
            if i >= self.n:
                raise _Err("Expected key", i)
            c = s[i]
            if c == '"':
                if s.startswith('"""', i):
                    raise _Err("Multiline string as key", i)
                k, i = self.basic(i)
            elif c == "'":
                if s.startswith("'''", i):
                    raise _Err("Multiline string as key", i)
                k, i = self.literal(i)
            else:
                m = BARE.match(s, i)
                if not m:
                    raise _Err("Invalid key", i)
                k = m.group()
                i = m.end()
            parts.append(k)
            i = self.skip_ws(i)
            if i < self.n and s[i] == ".":
                i += 1
                continue
            return parts, i

    # ---- strings
    def escape(self, i):
        # s[i] == backslash
        s = self.s
        if i + 1 >= self.n:
            raise _Err("Unterminated escape", i)
        c = s[i + 1]
        if c in ESC:
            return ESC[c], i + 2
        ln = {"x": 2, "u": 4, "U": 8}.get(c)
        if ln is None:
            raise _Err("Invalid escape", i)
        h = s[i + 2:i + 2 + ln]
        if len(h) != ln or not HEXRE.fullmatch(h):
            raise _Err("Invalid hex escape", i)
        cp = int(h, 16)
        if cp > 0x10FFFF or 0xD800 <= cp <= 0xDFFF:
            raise _Err("Invalid code point", i)
        return chr(cp), i + 2 + ln

    def basic(self, i):
        s, n = self.s, self.n
        i += 1
        out = []
        while True:
            if i >= n:
                raise _Err("Unterminated string", i)
            c = s[i]
            if c == '"':
                return "".join(out), i + 1
            if c == "\\":
                r, i = self.escape(i)
                out.append(r)
                continue
            if _bad_ctrl(c):
                raise _Err("Invalid character in string", i)
            out.append(c)
            i += 1

    def literal(self, i):
        s, n = self.s, self.n
        j = i + 1
        while True:
            if j >= n:
                raise _Err("Unterminated string", j)
            c = s[j]
            if c == "'":
                return s[i + 1:j], j + 1
            if _bad_ctrl(c):
                raise _Err("Invalid character in string", j)
            j += 1

    def ml_basic(self, i):
        s, n = self.s, self.n
        i += 3
        if i < n and s[i] == "\n":
            i += 1
        out = []
        while True:
            if i >= n:
                raise _Err("Unterminated string", i)
            c = s[i]
            if c == '"':
                j = i
                while j < n and s[j] == '"':
                    j += 1
                run = j - i
                if run >= 3:
                    if run > 5:
                        raise _Err("Too many quotes", i + 5)
                    out.append('"' * (run - 3))
                    return "".join(out), j
                out.append('"' * run)
                i = j
                continue
            if c == "\\":
                j = self.skip_ws(i + 1)
                if j < n and s[j] == "\n":
                    while j < n and s[j] in " \t\n":
                        j += 1
                    i = j
                    continue
                r, i = self.escape(i)
                out.append(r)
                continue
            if _bad_ctrl(c) and c != "\n":
                raise _Err("Invalid character in string", i)
            out.append(c)
            i += 1

    def ml_literal(self, i):
        s, n = self.s, self.n
        i += 3
        if i < n and s[i] == "\n":
            i += 1
        out = []
        while True:
            if i >= n:
                raise _Err("Unterminated string", i)
            c = s[i]
            if c == "'":
                j = i
                while j < n and s[j] == "'":
                    j += 1
                run = j - i
                if run >= 3:
                    if run > 5:
                        raise _Err("Too many quotes", i + 5)
                    out.append("'" * (run - 3))
                    return "".join(out), j
                out.append("'" * run)
                i = j
                continue
            if _bad_ctrl(c) and c != "\n":
                raise _Err("Invalid character in string", i)
            out.append(c)
            i += 1

    # ---- values
    def value(self, i):
        s = self.s
        if i >= self.n:
            raise _Err("Expected value", i)
        c = s[i]
        if c == '"':
            if s.startswith('"""', i):
                return self.ml_basic(i)
            return self.basic(i)
        if c == "'":
            if s.startswith("'''", i):
                return self.ml_literal(i)
            return self.literal(i)
        if c == "[":
            return self.array(i)
        if c == "{":
            return self.inline_table(i)
        if c.isdigit():
            m = DATETIME.match(s, i)
            if m and m.end() - i >= 10 and s[i + 4:i + 5] == "-":
                return self.datetime(m, i), m.end()
            m = LOCALTIME.match(s, i)
            if m and s[i + 2:i + 3] == ":":
                h, mi, sec, us = _mk_time(m.groups(), i)
                return time(h, mi, sec, us), m.end()
        m = TOKEN.match(s, i)
        if not m:
            raise _Err("Invalid value", i)
        tok = m.group()
        end = m.end()
        if tok == "true":
            return True, end
        if tok == "false":
            return False, end
        if DEC.fullmatch(tok):
            return int(tok.replace("_", "")), end
        if HEX.fullmatch(tok):
            return int(tok[2:].replace("_", ""), 16), end
        if OCT.fullmatch(tok):
            return int(tok[2:].replace("_", ""), 8), end
        if BIN.fullmatch(tok):
            return int(tok[2:].replace("_", ""), 2), end
        if FLOAT.fullmatch(tok):
            return self.mkfloat(tok), end
        if SPECIAL.fullmatch(tok):
            return self.mkfloat(tok), end
        raise _Err("Invalid value", i)

    def mkfloat(self, tok):
        if self.pf is float:
            return float(tok.replace("_", ""))
        r = self.pf(tok)
        if isinstance(r, (dict, list)):
            raise ValueError("parse_float must not return dicts or lists")
        return r

    def datetime(self, m, i):
        y, mo, d, hh, mm, ss, frac, off = m.groups()
        try:
            dt = date(int(y), int(mo), int(d))
        except ValueError:
            raise _Err("Invalid date", i)
        if hh is None:
            return dt
        h, mi, sec, us = _mk_time((hh, mm, ss, frac), i)
        tz = None
        if off:
            if off in "Zz":
                tz = timezone.utc
            else:
                oh, om = int(off[1:3]), int(off[4:6])
                if oh > 23 or om > 59:
                    raise _Err("Invalid offset", i)
                delta = timedelta(hours=oh, minutes=om)
                tz = timezone(-delta if off[0] == "-" else delta)
        return datetime(dt.year, dt.month, dt.day, h, mi, sec, us, tz)

    def array(self, i):
        s = self.s
        i += 1
        out = []
        while True:
            i = self.skip_wsnlc(i)
            if i >= self.n:
                raise _Err("Unterminated array", i)
            if s[i] == "]":
                return out, i + 1
            v, i = self.value(i)
            out.append(v)
            i = self.skip_wsnlc(i)
            if i >= self.n:
                raise _Err("Unterminated array", i)
            if s[i] == ",":
                i += 1
            elif s[i] == "]":
                return out, i + 1
            else:
                raise _Err("Expected ',' or ']'", i)

    def inline_table(self, i):
        s = self.s
        i += 1
        d = {}
        first = True
        while True:
            i = self.skip_wsnlc(i)
            if i >= self.n:
                raise _Err("Unterminated inline table", i)
            if s[i] == "}":
                self.inline.add(id(d))
                return d, i + 1
            i = self.keyvalue(d, i)
            i = self.skip_wsnlc(i)
            if i >= self.n:
                raise _Err("Unterminated inline table", i)
            if s[i] == ",":
                i += 1
            elif s[i] == "}":
                self.inline.add(id(d))
                return d, i + 1
            else:
                raise _Err("Expected ',' or '}'", i)

    # ---- structure
    def keyvalue(self, table, i):
        start = i
        parts, i = self.parse_key(i)
        i = self.skip_ws(i)
        if i >= self.n or self.s[i] != "=":
            raise _Err("Expected '='", i)
        i = self.skip_ws(i + 1)
        t = table
        for p in parts[:-1]:
            if p in t:
                nt = t[p]
                if (not isinstance(nt, dict) or id(nt) not in self.dotted
                        or id(nt) in self.inline):
                    raise _Err("Cannot extend existing key", start)
            else:
                nt = {}
                t[p] = nt
                self.dotted.add(id(nt))
            t = nt
        last = parts[-1]
        if last in t:
            raise _Err("Duplicate key", start)
        v, i = self.value(i)
        t[last] = v
        return i

    def walk_header(self, root, parts, start):
        t = root
        for p in parts[:-1]:
            if p in t:
                nt = t[p]
                if isinstance(nt, list):
                    if id(nt) not in self.aot:
                        raise _Err("Cannot extend array", start)
                    nt = nt[-1]
                if not isinstance(nt, dict) or id(nt) in self.inline:
                    raise _Err("Cannot extend existing key", start)
            else:
                nt = {}
                t[p] = nt
                self.implicit.add(id(nt))
            t = nt
        return t

    def run(self):
        s, n = self.s, self.n
        root = {}
        cur = root
        i = 0
        while True:
            i = self.skip_ws(i)
            if i >= n:
                break
            c = s[i]
            if c == "\n":
                i += 1
            elif c == "#":
                i = self.skip_comment(i)
            elif c == "[":
                start = i
                isaot = s.startswith("[[", i)
                i += 2 if isaot else 1
                parts, i = self.parse_key(i)
                closer = "]]" if isaot else "]"
                if not s.startswith(closer, i):
                    raise _Err("Expected '%s'" % closer, i)
                i += len(closer)
                parent = self.walk_header(root, parts, start)
                last = parts[-1]
                if isaot:
                    if last in parent:
                        arr = parent[last]
                        if not isinstance(arr, list) or id(arr) not in self.aot:
                            raise _Err("Cannot redefine as array of tables", start)
                    else:
                        arr = []
                        parent[last] = arr
                        self.aot.add(id(arr))
                    cur = {}
                    arr.append(cur)
                else:
                    if last in parent:
                        ex = parent[last]
                        if (isinstance(ex, dict) and id(ex) in self.implicit
                                and id(ex) not in self.inline):
                            self.implicit.discard(id(ex))
                            cur = ex
                        else:
                            raise _Err("Table already defined", start)
                    else:
                        cur = {}
                        parent[last] = cur
                i = self.end_line(i)
            else:
                i = self.keyvalue(cur, i)
                i = self.end_line(i)
        return root


def _orig_pos(pos, crs):
    for c in crs:
        if c <= pos:
            pos += 1
        else:
            break
    return pos


def loads(s, *, parse_float=float):
    if not isinstance(s, str):
        raise TypeError("Expected str object, not %r" % type(s).__name__)
    crs = []
    text = s
    if "\r\n" in s:
        i = s.find("\r\n")
        while i != -1:
            crs.append(i)
            i = s.find("\r\n", i + 2)
        text = s.replace("\r\n", "\n")
        # positions in crs are original indices
    try:
        return _Parser(text, parse_float).run()
    except _Err as e:
        raise TOMLDecodeError(e.msg, s, _orig_pos(e.pos, crs)) from None
    except RecursionError:
        raise TOMLDecodeError("Document nested too deeply", s, 0) from None


def load(fp, *, parse_float=float):
    b = fp.read()
    if isinstance(b, str):
        raise TypeError("File must be opened in binary mode, e.g. use open('foo.toml', 'rb')")
    try:
        s = b.decode("utf-8")
    except AttributeError:
        raise TypeError("File must be opened in binary mode") from None
    except UnicodeDecodeError as e:
        doc = bytes(b).decode("utf-8", "replace")
        raise TOMLDecodeError("Invalid UTF-8", doc, min(e.start, len(doc))) from None
    return loads(s, parse_float=parse_float)
