"""Tomlparse: a TOML v1.1.0 parser (reads only)."""
from ._errors import TOMLDecodeError
from ._parser import load, loads

__all__ = ("loads", "load", "TOMLDecodeError")
