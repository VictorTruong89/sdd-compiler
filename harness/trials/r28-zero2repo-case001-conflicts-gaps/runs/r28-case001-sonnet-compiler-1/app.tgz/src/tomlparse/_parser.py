# spec: N-000274 N-000275 N-000276 N-000277 N-000278 N-000299 N-000300 N-000301
import re
from datetime import date, datetime, time, timedelta, timezone

from ._errors import TOMLDecodeError

_BARE = re.compile(r"[A-Za-z0-9_-]+")
_DEC = re.compile(r"[+-]?(?:0|[1-9](?:_?[0-9])*)")
_HEX = re.compile(r"0x[0-9a-fA-F](?:_?[0-9a-fA-F])*")
_OCT = re.compile(r"0o[0-7](?:_?[0-7])*")
_BIN = re.compile(r"0b[01](?:_?[01])*")
_FLOAT = re.compile(
    r"[+-]?(?:0|[1-9](?:_?[0-9])*)"
    r"(?:\.[0-9](?:_?[0-9])*(?:[eE][+-]?[0-9](?:_?[0-9])*)?|[eE][+-]?[0-9](?:_?[0-9])*)"
)
_SPECIAL = re.compile(r"[+-]?(?:inf|nan)")
_DT = re.compile(
    r"(\d{4})-(\d\d)-(\d\d)"
    r"(?:[Tt ](\d\d):(\d\d)(?::(\d\d)(?:\.(\d+))?)?(Z|z|[+-]\d\d:\d\d)?)?"
)
_TIME = re.compile(r"(\d\d):(\d\d)(?::(\d\d)(?:\.(\d+))?)?")
_TOKEN_END = re.compile(r"[ \t\r\n,\]}#]")
_ESC = {"b": "\b", "t": "\t", "n": "\n", "f": "\f", "r": "\r", "e": "\x1b",
        '"': '"', "\\": "\\"}
_HEXDIGITS = frozenset("0123456789abcdefABCDEF")


class _Err(Exception):
    def __init__(self, msg, pos):
        Exception.__init__(self, msg)
        self.msg = msg
        self.pos = pos


def _bad_ctrl(c):
    return (c < " " and c != "\t") or c == "\x7f"


class _Parser:
    def __init__(self, s, parse_float):
        self.s = s
        self.n = len(s)
        self.parse_float = parse_float
        self.dotted = set()   # ids of tables created by dotted keys
        self.defined = set()  # ids of tables defined by header
        self.frozen = set()   # ids of inline tables
        self.aots = set()     # ids of arrays of tables

    # ---- low level helpers
    def ws(self, i):
        s, n = self.s, self.n
        while i < n and s[i] in " \t":
            i += 1
        return i

    def comment(self, i):
        # s[i] == '#'
        s, n = self.s, self.n
        i += 1
        while i < n:
            c = s[i]
            if c == "\n":
                break
            if c == "\r":
                if i + 1 < n and s[i + 1] == "\n":
                    break
                raise _Err("Invalid control character in comment", i)
            if _bad_ctrl(c):
                raise _Err("Invalid control character in comment", i)
            i += 1
        return i

    def newline(self, i):
        """Return index after a newline at i, or -1."""
        s = self.s
        if s.startswith("\n", i):
            return i + 1
        if s.startswith("\r\n", i):
            return i + 2
        return -1

    def skip_all(self, i):
        """Skip whitespace, newlines and comments."""
        s, n = self.s, self.n
        while i < n:
            c = s[i]
            if c in " \t":
                i += 1
            elif c == "#":
                i = self.comment(i)
            else:
                j = self.newline(i)
                if j < 0:
                    break
                i = j
        return i

    def end_of_line(self, i):
        i = self.ws(i)
        if i < self.n and self.s[i] == "#":
            i = self.comment(i)
        if i >= self.n:
            return i
        j = self.newline(i)
        if j < 0:
            raise _Err("Expected end of line", i)
        return j

    # ---- document
    def parse(self):
        s, n = self.s, self.n
        root = {}
        cur = root
        i = 0
        while True:
            i = self.skip_all(i)
            if i >= n:
                break
            if s[i] == "[":
                if s.startswith("[[", i):
                    cur, i = self.header(i, root, True)
                else:
                    cur, i = self.header(i, root, False)
                i = self.end_of_line(i)
            else:
                i = self.keyval(i, cur)
                i = self.end_of_line(i)
        return root

    def header(self, i, root, aot):
        s = self.s
        start = i
        i += 2 if aot else 1
        i = self.ws(i)
        parts, i = self.key(i)
        i = self.ws(i)
        close = "]]" if aot else "]"
        if not s.startswith(close, i):
            raise _Err("Expected '%s' to close table header" % close, i)
        i += len(close)
        t = root
        for p in parts[:-1]:
            if p not in t:
                nt = {}
                t[p] = nt
                t = nt
                continue
            v = t[p]
            if isinstance(v, list):
                if id(v) not in self.aots or not v:
                    raise _Err("Cannot extend a static array", start)
                v = v[-1]
            elif not isinstance(v, dict):
                raise _Err("Key is already a value", start)
            if id(v) in self.frozen:
                raise _Err("Cannot extend an inline table", start)
            t = v
        last = parts[-1]
        if aot:
            if last not in t:
                lst = []
                self.aots.add(id(lst))
                t[last] = lst
            else:
                lst = t[last]
                if not isinstance(lst, list) or id(lst) not in self.aots:
                    raise _Err("Cannot define array of tables here", start)
            nt = {}
            lst.append(nt)
            return nt, i
        if last not in t:
            nt = {}
            t[last] = nt
        else:
            nt = t[last]
            if (not isinstance(nt, dict) or id(nt) in self.defined
                    or id(nt) in self.dotted or id(nt) in self.frozen):
                raise _Err("Cannot redefine table or key", start)
        self.defined.add(id(nt))
        return nt, i

    # ---- keys
    def key(self, i):
        parts = []
        while True:
            i = self.ws(i)
            if i >= self.n:
                raise _Err("Expected key", i)
            c = self.s[i]
            if c == '"':
                if self.s.startswith('"""', i):
                    raise _Err("Multiline string cannot be a key", i)
                k, i = self.basic(i)
            elif c == "'":
                if self.s.startswith("'''", i):
                    raise _Err("Multiline string cannot be a key", i)
                k, i = self.literal(i)
            else:
                m = _BARE.match(self.s, i)
                if not m:
                    raise _Err("Invalid or missing key", i)
                k = m.group()
                i = m.end()
            parts.append(k)
            i = self.ws(i)
            if i < self.n and self.s[i] == ".":
                i += 1
                continue
            return parts, i

    def keyval(self, i, table):
        start = i
        parts, i = self.key(i)
        i = self.ws(i)
        if i >= self.n or self.s[i] != "=":
            raise _Err("Expected '=' after key", i)
        i = self.ws(i + 1)
        val, i = self.value(i)
        t = table
        for p in parts[:-1]:
            if p not in t:
                nt = {}
                self.dotted.add(id(nt))
                t[p] = nt
                t = nt
            else:
                v = t[p]
                if (not isinstance(v, dict) or id(v) not in self.dotted
                        or id(v) in self.frozen):
                    raise _Err("Cannot extend existing key", start)
                t = v
        if parts[-1] in t:
            raise _Err("Duplicate key", start)
        t[parts[-1]] = val
        return i

    # ---- values
    def value(self, i):
        s, n = self.s, self.n
        if i >= n:
            raise _Err("Missing value", i)
        c = s[i]
        if c == '"':
            if s.startswith('"""', i):
                return self.ml_basic(i)
            return self.basic(i)
        if c == "'":
            if s.startswith("'''", i):
                return self.ml_literal(i)
            return self.literal(i)
        if c == "[":
            return self.array(i)
        if c == "{":
            return self.inline(i)
        return self.scalar(i)

    def array(self, i):
        s = self.s
        i += 1
        out = []
        while True:
            i = self.skip_all(i)
            if i >= self.n:
                raise _Err("Unterminated array", i)
            if s[i] == "]":
                return out, i + 1
            v, i = self.value(i)
            out.append(v)
            i = self.skip_all(i)
            if i >= self.n:
                raise _Err("Unterminated array", i)
            if s[i] == ",":
                i += 1
            elif s[i] == "]":
                return out, i + 1
            else:
                raise _Err("Expected ',' or ']' in array", i)

    def inline(self, i):
        s = self.s
        i += 1
        out = {}
        i = self.skip_all(i)
        if i < self.n and s[i] == "}":
            self.frozen.add(id(out))
            return out, i + 1
        while True:
            i = self.skip_all(i)
            if i >= self.n:
                raise _Err("Unterminated inline table", i)
            i = self.keyval(i, out)
            i = self.skip_all(i)
            if i >= self.n:
                raise _Err("Unterminated inline table", i)
            if s[i] == ",":
                i = self.skip_all(i + 1)
                if i < self.n and s[i] == "}":
                    self.frozen.add(id(out))
                    return out, i + 1
            elif s[i] == "}":
                self.frozen.add(id(out))
                return out, i + 1
            else:
                raise _Err("Expected ',' or '}' in inline table", i)

    # ---- strings
    def escape(self, i, multiline):
        """s[i] is backslash. Return (text, new_i)."""
        s = self.s
        if i + 1 >= self.n:
            raise _Err("Unterminated string", i)
        c = s[i + 1]
        if c in _ESC:
            return _ESC[c], i + 2
        if c in "xuU":
            ln = {"x": 2, "u": 4, "U": 8}[c]
            h = s[i + 2:i + 2 + ln]
            if len(h) != ln or any(ch not in _HEXDIGITS for ch in h):
                raise _Err("Invalid escape sequence", i)
            cp = int(h, 16)
            if cp > 0x10FFFF or 0xD800 <= cp <= 0xDFFF:
                raise _Err("Escape is not a Unicode scalar value", i)
            return chr(cp), i + 2 + ln
        raise _Err("Invalid escape sequence", i)

    def basic(self, i):
        s, n = self.s, self.n
        i += 1
        buf = []
        while True:
            if i >= n:
                raise _Err("Unterminated string", i)
            c = s[i]
            if c == '"':
                return "".join(buf), i + 1
            if c == "\\":
                t, i = self.escape(i, False)
                buf.append(t)
                continue
            if _bad_ctrl(c):
                raise _Err("Invalid character in string", i)
            buf.append(c)
            i += 1

    def literal(self, i):
        s, n = self.s, self.n
        i += 1
        j = i
        while True:
            if j >= n:
                raise _Err("Unterminated string", j)
            c = s[j]
            if c == "'":
                return s[i:j], j + 1
            if _bad_ctrl(c):
                raise _Err("Invalid character in string", j)
            j += 1

    def ml_basic(self, i):
        s, n = self.s, self.n
        i += 3
        j = self.newline(i)
        if j >= 0:
            i = j
        buf = []
        while True:
            if i >= n:
                raise _Err("Unterminated string", i)
            c = s[i]
            if c == '"':
                k = i
                while k < n and s[k] == '"':
                    k += 1
                run = k - i
                if run >= 3:
                    if run > 5:
                        raise _Err("Too many quotes in string", i)
                    buf.append('"' * (run - 3))
                    return "".join(buf), k
                buf.append('"' * run)
                i = k
                continue
            if c == "\\":
                k = self.ws(i + 1)
                if k < n and self.newline(k) >= 0:
                    while k < n:
                        if s[k] in " \t":
                            k += 1
                        else:
                            m = self.newline(k)
                            if m < 0:
                                break
                            k = m
                    i = k
                    continue
                t, i = self.escape(i, True)
                buf.append(t)
                continue
            if c == "\r":
                if s.startswith("\r\n", i):
                    buf.append("\n")
                    i += 2
                    continue
                raise _Err("Invalid carriage return in string", i)
            if _bad_ctrl(c) and c != "\n":
                raise _Err("Invalid character in string", i)
            buf.append(c)
            i += 1

    def ml_literal(self, i):
        s, n = self.s, self.n
        i += 3
        j = self.newline(i)
        if j >= 0:
            i = j
        buf = []
        while True:
            if i >= n:
                raise _Err("Unterminated string", i)
            c = s[i]
            if c == "'":
                k = i
                while k < n and s[k] == "'":
                    k += 1
                run = k - i
                if run >= 3:
                    if run > 5:
                        raise _Err("Too many quotes in string", i)
                    buf.append("'" * (run - 3))
                    return "".join(buf), k
                buf.append("'" * run)
                i = k
                continue
            if c == "\r":
                if s.startswith("\r\n", i):
                    buf.append("\n")
                    i += 2
                    continue
                raise _Err("Invalid carriage return in string", i)
            if _bad_ctrl(c) and c != "\n":
                raise _Err("Invalid character in string", i)
            buf.append(c)
            i += 1

    # ---- scalars
    def scalar(self, i):
        s = self.s
        m = _DT.match(s, i)
        if m and m.end() - i >= 10:
            return self.datetime(m, i), m.end()
        m = _TIME.match(s, i)
        if m:
            return self.localtime(m, i), m.end()
        m = _TOKEN_END.search(s, i)
        end = m.start() if m else self.n
        tok = s[i:end]
        if not tok:
            raise _Err("Missing value", i)
        if tok == "true":
            return True, end
        if tok == "false":
            return False, end
        if _DEC.fullmatch(tok):
            return int(tok.replace("_", "")), end
        if _HEX.fullmatch(tok):
            return int(tok[2:].replace("_", ""), 16), end
        if _OCT.fullmatch(tok):
            return int(tok[2:].replace("_", ""), 8), end
        if _BIN.fullmatch(tok):
            return int(tok[2:].replace("_", ""), 2), end
        if _FLOAT.fullmatch(tok) or _SPECIAL.fullmatch(tok):
            if self.parse_float is float:
                return float(tok.replace("_", "")), end
            r = self.parse_float(tok)
            if isinstance(r, (dict, list)):
                raise ValueError("parse_float must not return a dict or list")
            return r, end
        raise _Err("Invalid value", i)

    def _time_parts(self, h, mi, sec, frac, pos):
        h, mi = int(h), int(mi)
        sec = int(sec) if sec is not None else 0
        if h > 23 or mi > 59 or sec > 59:
            raise _Err("Invalid time", pos)
        us = int((frac + "000000")[:6]) if frac else 0
        return h, mi, sec, us

    def datetime(self, m, pos):
        y, mo, d, h, mi, sec, frac, off = m.groups()
        try:
            dt = date(int(y), int(mo), int(d))
        except ValueError:
            raise _Err("Invalid date", pos)
        if h is None:
            return dt
        h, mi, sec, us = self._time_parts(h, mi, sec, frac, pos)
        tz = None
        if off is not None:
            if off in "Zz":
                tz = timezone.utc
            else:
                oh, om = int(off[1:3]), int(off[4:6])
                if oh > 23 or om > 59:
                    raise _Err("Invalid offset", pos)
                delta = timedelta(hours=oh, minutes=om)
                tz = timezone(-delta if off[0] == "-" else delta)
        return datetime(dt.year, dt.month, dt.day, h, mi, sec, us, tz)

    def localtime(self, m, pos):
        h, mi, sec, frac = m.groups()
        h, mi, sec, us = self._time_parts(h, mi, sec, frac, pos)
        return time(h, mi, sec, us)


def loads(s, *, parse_float=float):
    if not isinstance(s, str):
        raise TypeError("Expected str object, not %r" % type(s).__name__)
    p = _Parser(s, parse_float)
    try:
        return p.parse()
    except _Err as e:
        raise TOMLDecodeError(e.msg, s, e.pos) from None
    except RecursionError:
        raise TOMLDecodeError("Document nesting is too deep", s, 0) from None


def load(fp, *, parse_float=float):
    b = fp.read()
    if isinstance(b, str):
        raise TypeError("File must be opened in binary mode, e.g. use open('foo.toml', 'rb')")
    try:
        s = bytes(b).decode("utf-8")
    except UnicodeDecodeError as e:
        doc = bytes(b).decode("utf-8", "replace")
        raise TOMLDecodeError("Invalid UTF-8: %s" % e.reason, doc, min(e.start, len(doc))) from None
    return loads(s, parse_float=parse_float)
