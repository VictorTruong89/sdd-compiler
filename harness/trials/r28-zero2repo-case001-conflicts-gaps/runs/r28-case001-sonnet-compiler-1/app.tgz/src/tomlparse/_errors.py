# spec: N-000307 N-000308 N-000309 N-000310 N-000311 N-000314 N-000315 N-000316
# spec: N-000317 N-000318 N-000319 N-000320 N-000321 N-000322
class TOMLDecodeError(ValueError):
    """Raised when a document is not valid TOML."""

    def __init__(self, msg, doc, pos):
        self.msg = msg
        self.doc = doc
        self.pos = pos
        self.lineno = doc.count("\n", 0, pos) + 1
        self.colno = pos - doc.rfind("\n", 0, pos)
        if pos >= len(doc):
            where = "at end of document"
        else:
            where = "at line %d, column %d" % (self.lineno, self.colno)
        ValueError.__init__(self, "%s (%s)" % (msg, where))

    def __reduce__(self):
        return (self.__class__, (self.msg, self.doc, self.pos))
