"""Exception type for TOML parse failures."""


class TOMLDecodeError(ValueError):
    """Raised when a document is not valid TOML v1.1.0.

    Constructed as ``TOMLDecodeError(msg, doc, pos)``. ``pos`` is a 0-based
    character offset into ``doc``; ``lineno`` and ``colno`` are the 1-based
    line and column of that offset.
    """

    def __init__(self, msg, doc, pos):
        super().__init__(msg, doc, pos)
        self.msg = msg
        self.doc = doc
        self.pos = pos
        # Line feeds before the offset determine the line. The column counts
        # characters after the last line feed before the offset.
        last_lf = doc.rfind("\n", 0, pos)
        self.lineno = doc.count("\n", 0, pos) + 1
        self.colno = pos - last_lf

    def __str__(self):
        if self.pos >= len(self.doc):
            location = "at end of document"
        else:
            location = "line %d, column %d" % (self.lineno, self.colno)
        return "%s (%s, char %d)" % (self.msg, location, self.pos)

    def __reduce__(self):
        return (self.__class__, (self.msg, self.doc, self.pos))
