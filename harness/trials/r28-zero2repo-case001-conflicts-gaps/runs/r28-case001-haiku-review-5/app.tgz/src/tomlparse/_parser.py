"""Recursive-descent parser for TOML v1.1.0 documents.

The parser works on the document text directly, so every error offset refers
to the caller's text (CR LF pairs are not rewritten first).

Every table the parser creates is tagged with a kind, which decides what later
headers and dotted keys may do with it:

* ``root``      the document mapping;
* ``header``    a table defined by a ``[table]`` header;
* ``implicit``  a parent created by a header and not yet defined itself;
* ``dotted``    a table created by dotted keys;
* ``inline``    an inline table (frozen once written);
* ``aotelem``   one element of an array of tables.

Arrays of tables are lists tagged ``aot``.
"""

import datetime as _datetime
import io as _io
import re as _re

from ._errors import TOMLDecodeError

_ROOT = "root"
_HEADER = "header"
_IMPLICIT = "implicit"
_DOTTED = "dotted"
_INLINE = "inline"
_AOT_ELEM = "aotelem"
_AOT = "aot"

_BARE_KEY = _re.compile(r"[A-Za-z0-9_-]+")
_DATE = _re.compile(r"([0-9]{4})-([0-9]{2})-([0-9]{2})")
_TIME = _re.compile(r"([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?")
_OFFSET = _re.compile(r"[Zz]|([+-])([0-9]{2}):([0-9]{2})")
_INT_DEC = _re.compile(r"[+-]?(?:0|[1-9](?:_?[0-9])*)")
_FLOAT = _re.compile(
    r"[+-]?(?:0|[1-9](?:_?[0-9])*)"
    r"(?:\.[0-9](?:_?[0-9])*(?:[eE][+-]?[0-9](?:_?[0-9])*)?"
    r"|[eE][+-]?[0-9](?:_?[0-9])*)"
)
_FLOAT_SPECIAL = _re.compile(r"[+-]?(?:inf|nan)")
_INT_HEX = _re.compile(r"0x[0-9A-Fa-f](?:_?[0-9A-Fa-f])*")
_INT_OCT = _re.compile(r"0o[0-7](?:_?[0-7])*")
_INT_BIN = _re.compile(r"0b[01](?:_?[01])*")
_COMMENT = _re.compile(r"#[^\r\n\x00-\x08\x0a-\x1f\x7f]*")
# Runs of ordinary characters: no quote/backslash, no CR/LF, no control
# characters other than tab.
_BASIC_CHUNK = _re.compile(r'[^"\\\r\n\x00-\x08\x0a-\x1f\x7f]+')
_LITERAL_CHUNK = _re.compile(r"[^'\r\n\x00-\x08\x0a-\x1f\x7f]+")

_SIMPLE_ESCAPES = {
    "b": "\b",
    "t": "\t",
    "n": "\n",
    "f": "\f",
    "r": "\r",
    "e": "\x1b",
    '"': '"',
    "\\": "\\",
}
_ESCAPE_WIDTHS = {"x": 2, "u": 4, "U": 8}
_HEX_DIGITS = frozenset("0123456789abcdefABCDEF")


class _Parser(object):
    def __init__(self, text, parse_float):
        self.s = text
        self.n = len(text)
        # None means the builtin float; otherwise the caller's converter.
        self.parse_float = None if parse_float is float else parse_float
        self.root = {}
        self.kinds = {id(self.root): _ROOT}

    # ----- low-level helpers -------------------------------------------

    def _fail(self, pos, msg):
        raise TOMLDecodeError(msg, self.s, pos)

    def _mark(self, container, kind):
        self.kinds[id(container)] = kind

    def _kind_of(self, container):
        return self.kinds.get(id(container))

    def _skip_ws(self, i):
        s, n = self.s, self.n
        while i < n and s[i] in " \t":
            i += 1
        return i

    def _newline_len(self, i):
        s = self.s
        if i < self.n:
            if s[i] == "\n":
                return 1
            if s[i] == "\r" and s.startswith("\n", i + 1):
                return 2
        return 0

    def _skip_wsnlc(self, i):
        """Skip whitespace, newlines and comments (inside brackets)."""
        s, n = self.s, self.n
        while True:
            i = self._skip_ws(i)
            if i >= n:
                return i
            nl = self._newline_len(i)
            if nl:
                i += nl
                continue
            if s[i] == "#":
                i = _COMMENT.match(s, i).end()
                continue
            return i

    def _expect_eol(self, i):
        """After a statement: optional comment, then a newline or end."""
        s, n = self.s, self.n
        i = self._skip_ws(i)
        if i < n and s[i] == "#":
            i = _COMMENT.match(s, i).end()
        if i < n and self._newline_len(i) == 0:
            self._fail(i, "expected end of line")
        return i

    # ----- document level ------------------------------------------------

    def parse(self):
        s, n = self.s, self.n
        cur = self.root
        i = 0
        while True:
            i = self._skip_ws(i)
            if i >= n:
                break
            nl = self._newline_len(i)
            if nl:
                i += nl
                continue
            c = s[i]
            if c == "#":
                i = _COMMENT.match(s, i).end()
                continue
            if c == "[":
                if s.startswith("[[", i):
                    cur, i = self._array_table_header(i)
                else:
                    cur, i = self._table_header(i)
            else:
                i = self._keyval(cur, i)
            i = self._expect_eol(i)
        return self.root

    def _table_header(self, i):
        parts, j = self._key_path(i + 1)
        if not self.s.startswith("]", j):
            self._fail(j, "expected ']' to close table header")
        table = self._open_table(parts, i, array=False)
        return table, j + 1

    def _array_table_header(self, i):
        parts, j = self._key_path(i + 2)
        if not self.s.startswith("]]", j):
            self._fail(j, "expected ']]' to close array of tables header")
        table = self._open_table(parts, i, array=True)
        return table, j + 2

    def _open_table(self, parts, pos, array):
        """Create or enter the table named by a header; return it."""
        cur = self.root
        for key in parts[:-1]:
            if key not in cur:
                new = {}
                self._mark(new, _IMPLICIT)
                cur[key] = new
                cur = new
            else:
                cur = self._header_step(cur[key], pos)
        last = parts[-1]
        if array:
            if last not in cur:
                elem = {}
                self._mark(elem, _AOT_ELEM)
                lst = [elem]
                self._mark(lst, _AOT)
                cur[last] = lst
                return elem
            lst = cur[last]
            if not (isinstance(lst, list) and self._kind_of(lst) == _AOT):
                self._fail(pos, "array of tables conflicts with an existing key")
            elem = {}
            self._mark(elem, _AOT_ELEM)
            lst.append(elem)
            return elem
        if last not in cur:
            new = {}
            self._mark(new, _HEADER)
            cur[last] = new
            return new
        child = cur[last]
        if isinstance(child, dict) and self._kind_of(child) == _IMPLICIT:
            # A super-table created earlier may be defined now.
            self._mark(child, _HEADER)
            return child
        self._fail(pos, "table is already defined")

    def _header_step(self, child, pos):
        """Descend through an existing key while resolving a header path."""
        if isinstance(child, dict):
            if self._kind_of(child) == _INLINE:
                self._fail(pos, "cannot extend an inline table")
            return child
        if isinstance(child, list) and self._kind_of(child) == _AOT:
            return child[-1]
        self._fail(pos, "key is already defined as a value")

    # ----- keys ----------------------------------------------------------

    def _key_path(self, i):
        """Parse ``key(.key)*`` allowing spaces around the dots.

        Returns (parts, index just after trailing whitespace).
        """
        s = self.s
        parts = []
        while True:
            i = self._skip_ws(i)
            key, i = self._key(i)
            parts.append(key)
            j = self._skip_ws(i)
            if j < self.n and s[j] == ".":
                i = j + 1
                continue
            return parts, j

    def _key(self, i):
        s = self.s
        if i >= self.n:
            self._fail(i, "expected key")
        c = s[i]
        if c == '"':
            if s.startswith('"""', i):
                self._fail(i, "multiline strings cannot be used as keys")
            return self._basic_string(i)
        if c == "'":
            if s.startswith("'''", i):
                self._fail(i, "multiline strings cannot be used as keys")
            return self._literal_string(i)
        m = _BARE_KEY.match(s, i)
        if m:
            return m.group(), m.end()
        self._fail(i, "expected key")

    def _keyval(self, table, i):
        key_pos = i
        parts, i = self._key_path(i)
        if not self.s.startswith("=", i):
            self._fail(i, "expected '=' after key")
        i = self._skip_ws(i + 1)
        value, i = self._value(i)
        self._insert(table, parts, value, key_pos)
        return i

    def _insert(self, table, parts, value, pos):
        """Store a key/value pair, creating dotted-key tables as needed."""
        cur = table
        for key in parts[:-1]:
            if key not in cur:
                new = {}
                self._mark(new, _DOTTED)
                cur[key] = new
                cur = new
            else:
                child = cur[key]
                if isinstance(child, dict) and self._kind_of(child) == _DOTTED:
                    cur = child
                else:
                    self._fail(pos, "key is already defined")
        last = parts[-1]
        if last in cur:
            self._fail(pos, "duplicate key")
        cur[last] = value
        if isinstance(value, dict):
            self._mark(value, _INLINE)

    # ----- values --------------------------------------------------------

    def _value(self, i):
        if i >= self.n:
            self._fail(i, "expected value")
        c = self.s[i]
        try:
            if c == "[":
                return self._array(i)
            if c == "{":
                return self._inline_table(i)
            return self._scalar(i)
        except RecursionError:
            # Nesting is bounded by Python's recursion limit. Report that as a
            # decode error rather than letting RecursionError escape.
            self._fail(i, "value is nested too deeply")

    def _array(self, i):
        s = self.s
        arr = []
        i = self._skip_wsnlc(i + 1)
        if i < self.n and s[i] == "]":
            return arr, i + 1
        while True:
            value, i = self._value(i)
            arr.append(value)
            i = self._skip_wsnlc(i)
            if i >= self.n:
                self._fail(i, "unterminated array")
            c = s[i]
            if c == ",":
                i = self._skip_wsnlc(i + 1)
                if i < self.n and s[i] == "]":
                    return arr, i + 1
                continue
            if c == "]":
                return arr, i + 1
            self._fail(i, "expected ',' or ']' in array")

    def _inline_table(self, i):
        s = self.s
        tbl = {}
        i = self._skip_wsnlc(i + 1)
        if i < self.n and s[i] == "}":
            return tbl, i + 1
        while True:
            key_pos = i
            parts, i = self._key_path(i)
            if not s.startswith("=", i):
                self._fail(i, "expected '=' after key")
            i = self._skip_ws(i + 1)
            value, i = self._value(i)
            self._insert(tbl, parts, value, key_pos)
            i = self._skip_wsnlc(i)
            if i >= self.n:
                self._fail(i, "unterminated inline table")
            c = s[i]
            if c == ",":
                i = self._skip_wsnlc(i + 1)
                if i < self.n and s[i] == "}":
                    return tbl, i + 1
                continue
            if c == "}":
                return tbl, i + 1
            self._fail(i, "expected ',' or '}' in inline table")

    def _scalar(self, i):
        s, n = self.s, self.n
        c = s[i]
        if c == '"':
            if s.startswith('"""', i):
                return self._ml_basic(i)
            return self._basic_string(i)
        if c == "'":
            if s.startswith("'''", i):
                return self._ml_literal(i)
            return self._literal_string(i)
        if s.startswith("true", i):
            return True, i + 4
        if s.startswith("false", i):
            return False, i + 5
        m = _DATE.match(s, i)
        if m:
            return self._date_time(m, i)
        m = _TIME.match(s, i)
        if m:
            return self._local_time(m, i)
        if s.startswith(("0x", "0o", "0b"), i):
            for regex, base in ((_INT_HEX, 16), (_INT_OCT, 8), (_INT_BIN, 2)):
                m = regex.match(s, i)
                if m:
                    return int(m.group()[2:].replace("_", ""), base), m.end()
            self._fail(i, "invalid integer")
        m = _FLOAT_SPECIAL.match(s, i)
        if m:
            return self._float(m.group(), m.end())
        m = _FLOAT.match(s, i)
        if m:
            return self._float(m.group(), m.end())
        m = _INT_DEC.match(s, i)
        if m:
            return int(m.group().replace("_", "")), m.end()
        self._fail(i, "expected value")

    def _float(self, text, end):
        if self.parse_float is None:
            return float(text.replace("_", "")), end
        value = self.parse_float(text)
        if isinstance(value, (dict, list)):
            raise ValueError(
                "parse_float must not return a dict or list (got %s)"
                % type(value).__name__
            )
        return value, end

    # ----- date and time -------------------------------------------------

    def _time_fields(self, m, pos):
        hour = int(m.group(1))
        minute = int(m.group(2))
        second = int(m.group(3)) if m.group(3) else 0
        if hour > 23 or minute > 59 or second > 59:
            self._fail(pos, "invalid time")
        frac = m.group(4) or ""
        microsecond = int(frac[:6].ljust(6, "0"))
        return hour, minute, second, microsecond

    def _date_time(self, m, i):
        s = self.s
        year, month, day = int(m.group(1)), int(m.group(2)), int(m.group(3))
        try:
            _datetime.date(year, month, day)
        except ValueError:
            self._fail(i, "invalid date")
        j = m.end()
        sep = s[j:j + 1]
        tm = None
        if sep in ("T", "t", " "):
            tm = _TIME.match(s, j + 1)
            if tm is None and sep != " ":
                # 'T' or 't' must be followed by a time; a space that is not
                # followed by one simply ends the date.
                self._fail(j + 1, "expected time after date-time separator")
        if tm is None:
            return _datetime.date(year, month, day), j
        hour, minute, second, microsecond = self._time_fields(tm, j + 1)
        k = tm.end()
        off = _OFFSET.match(s, k)
        if off is None:
            value = _datetime.datetime(
                year, month, day, hour, minute, second, microsecond
            )
            return value, k
        if off.group(1) is None:
            tzinfo = _datetime.timezone.utc
        else:
            oh, om = int(off.group(2)), int(off.group(3))
            if oh > 23 or om > 59:
                self._fail(k, "invalid UTC offset")
            delta = _datetime.timedelta(hours=oh, minutes=om)
            if off.group(1) == "-":
                delta = -delta
            tzinfo = _datetime.timezone(delta)
        value = _datetime.datetime(
            year, month, day, hour, minute, second, microsecond, tzinfo=tzinfo
        )
        return value, off.end()

    def _local_time(self, m, i):
        hour, minute, second, microsecond = self._time_fields(m, i)
        return _datetime.time(hour, minute, second, microsecond), m.end()

    # ----- strings -------------------------------------------------------

    def _escape(self, i):
        """Decode the escape starting at the backslash at ``i``."""
        s, n = self.s, self.n
        j = i + 1
        if j >= n:
            self._fail(n, "unterminated escape sequence")
        e = s[j]
        if e in _SIMPLE_ESCAPES:
            return _SIMPLE_ESCAPES[e], j + 1
        width = _ESCAPE_WIDTHS.get(e)
        if width is None:
            self._fail(j, "invalid escape sequence")
        digits = s[j + 1:j + 1 + width]
        if len(digits) != width or not all(ch in _HEX_DIGITS for ch in digits):
            self._fail(i, "invalid unicode escape")
        code = int(digits, 16)
        if code > 0x10FFFF or 0xD800 <= code <= 0xDFFF:
            self._fail(i, "escape is not a Unicode scalar value")
        return chr(code), j + 1 + width

    def _basic_string(self, i):
        s, n = self.s, self.n
        i += 1
        out = []
        while True:
            if i >= n:
                self._fail(n, "unterminated string")
            c = s[i]
            if c == '"':
                return "".join(out), i + 1
            if c == "\\":
                ch, i = self._escape(i)
                out.append(ch)
                continue
            m = _BASIC_CHUNK.match(s, i)
            if m:
                out.append(m.group())
                i = m.end()
                continue
            self._fail(i, "invalid character in string")

    def _literal_string(self, i):
        s, n = self.s, self.n
        i += 1
        out = []
        while True:
            if i >= n:
                self._fail(n, "unterminated string")
            c = s[i]
            if c == "'":
                return "".join(out), i + 1
            m = _LITERAL_CHUNK.match(s, i)
            if m:
                out.append(m.group())
                i = m.end()
                continue
            self._fail(i, "invalid character in string")

    def _ml_basic(self, i):
        s, n = self.s, self.n
        i += 3
        i += self._newline_len(i)  # a newline right after the delimiter is trimmed
        out = []
        while True:
            if i >= n:
                self._fail(n, "unterminated multiline string")
            c = s[i]
            if c == '"':
                j = i
                while j < n and s[j] == '"':
                    j += 1
                run = j - i
                if run >= 3:
                    if run > 5:
                        self._fail(i + 5, "too many quotation marks in string")
                    out.append('"' * (run - 3))
                    return "".join(out), j
                out.append('"' * run)
                i = j
                continue
            if c == "\\":
                j = i + 1
                while j < n and s[j] in " \t":
                    j += 1
                if self._newline_len(j):
                    # Line-ending backslash: drop it and all following whitespace.
                    i = j
                    while i < n:
                        if s[i] in " \t":
                            i += 1
                            continue
                        nl = self._newline_len(i)
                        if nl:
                            i += nl
                            continue
                        break
                    continue
                ch, i = self._escape(i)
                out.append(ch)
                continue
            m = _BASIC_CHUNK.match(s, i)
            if m:
                out.append(m.group())
                i = m.end()
                continue
            nl = self._newline_len(i)
            if nl:
                out.append("\n")
                i += nl
                continue
            self._fail(i, "invalid character in multiline string")

    def _ml_literal(self, i):
        s, n = self.s, self.n
        i += 3
        i += self._newline_len(i)
        out = []
        while True:
            if i >= n:
                self._fail(n, "unterminated multiline string")
            c = s[i]
            if c == "'":
                j = i
                while j < n and s[j] == "'":
                    j += 1
                run = j - i
                if run >= 3:
                    if run > 5:
                        self._fail(i + 5, "too many quotation marks in string")
                    out.append("'" * (run - 3))
                    return "".join(out), j
                out.append("'" * run)
                i = j
                continue
            m = _LITERAL_CHUNK.match(s, i)
            if m:
                out.append(m.group())
                i = m.end()
                continue
            nl = self._newline_len(i)
            if nl:
                out.append("\n")
                i += nl
                continue
            self._fail(i, "invalid character in multiline string")


def loads(s, *, parse_float=float):
    """Parse a TOML v1.1.0 document from a text string into a dict."""
    if not isinstance(s, str):
        raise TypeError(
            "loads() takes a str, not %s" % type(s).__name__
        )
    return _Parser(s, parse_float).parse()


def load(fp, *, parse_float=float):
    """Parse a TOML v1.1.0 document from a binary file object into a dict."""
    if isinstance(fp, _io.TextIOBase):
        raise TypeError("load() requires a file opened in binary mode")
    data = fp.read()
    if isinstance(data, str):
        raise TypeError("load() requires a file opened in binary mode")
    if not isinstance(data, (bytes, bytearray)):
        raise TypeError("load() expects bytes from fp.read()")
    return loads(bytes(data).decode("utf-8"), parse_float=parse_float)
