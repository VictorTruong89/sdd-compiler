"""Tests for tomlparse. Run from /app with: PYTHONPATH=src python -m pytest tests"""

import datetime
import io
import unittest

from tomlparse import TOMLDecodeError, load, loads


class ValidDocuments(unittest.TestCase):
    def test_empty_and_comment_only(self):
        self.assertEqual(loads(""), {})
        self.assertEqual(loads("   \t\n"), {})
        self.assertEqual(loads("# just a comment"), {})
        self.assertEqual(loads("# c\n# d\n"), {})

    def test_scalars(self):
        d = loads(
            'b = true\nf = false\ni = +99\nh = 0xDEAD_beef\no = 0o755\n'
            'n = 0b1101\nz = -0\nfl = -1_000.5e+3\nx = 5e2\n'
        )
        self.assertIs(d["b"], True)
        self.assertIs(d["f"], False)
        self.assertEqual(d["i"], 99)
        self.assertEqual(d["h"], 0xDEADBEEF)
        self.assertEqual(d["o"], 0o755)
        self.assertEqual(d["n"], 0b1101)
        self.assertEqual(d["z"], 0)
        self.assertIsInstance(d["z"], int)
        self.assertEqual(d["fl"], -1000500.0)
        self.assertEqual(d["x"], 500.0)
        self.assertIsInstance(d["x"], float)

    def test_special_floats(self):
        d = loads("a = inf\nb = +inf\nc = -inf\nd = nan\ne = -nan\n")
        self.assertEqual(d["a"], float("inf"))
        self.assertEqual(d["c"], float("-inf"))
        self.assertTrue(d["d"] != d["d"])
        self.assertTrue(d["e"] != d["e"])

    def test_basic_string_escapes(self):
        d = loads(r'a = "t\tn\nq\"b\\e\e\x41\u00e9\U0001F600"')
        self.assertEqual(d["a"], "t\tn\nq\"b\\e\x1b" + "A\u00e9\U0001F600")

    def test_uppercase_hex_digits_in_escapes_accepted(self):
        self.assertEqual(loads(r'a = "\u00E9"')["a"], "\u00e9")

    def test_raw_tab_in_one_line_string_accepted(self):
        self.assertEqual(loads('a = "x\ty"')["a"], "x\ty")
        self.assertEqual(loads("a = 'x\ty'")["a"], "x\ty")

    def test_literal_string_has_no_escapes(self):
        self.assertEqual(loads(r"a = 'C:\path\n'")["a"], r"C:\path\n")

    def test_multiline_basic_trims_first_newline_and_line_ending_backslash(self):
        doc = 'a = """\nRoses\n  are \\\n     red"""\n'
        self.assertEqual(loads(doc)["a"], "Roses\n  are red")

    def test_multiline_literal_trims_first_newline(self):
        self.assertEqual(loads("a = '''\nfirst\n  raw \\n'''")["a"], "first\n  raw \\n")

    def test_multiline_quotes_before_closing_delimiter(self):
        self.assertEqual(loads('a = """x""""')["a"], 'x"')
        self.assertEqual(loads('a = """x"""""')["a"], 'x""')
        self.assertEqual(loads("a = '''x''''")["a"], "x'")

    def test_crlf_in_multiline_string_is_lf(self):
        self.assertEqual(loads('a = """x\r\ny"""\r\n')["a"], "x\ny")

    def test_crlf_document_line_endings(self):
        self.assertEqual(loads("a = 1\r\nb = 2\r\n"), {"a": 1, "b": 2})

    def test_integers_are_not_bool(self):
        d = loads("a = 1\nb = true")
        self.assertIs(type(d["a"]), int)

    def test_date_times(self):
        d = loads(
            "odt = 1979-05-27T07:32:00.123456789-07:00\n"
            "odt2 = 1979-05-27 07:32Z\n"
            "odt3 = 1979-05-27t07:32:00z\n"
            "ldt = 1979-05-27T07:32:00\n"
            "ld = 1980-02-29\n"
            "lt = 07:32\n"
            "lt2 = 07:32:01.5\n"
        )
        off = datetime.timezone(datetime.timedelta(hours=-7))
        self.assertEqual(d["odt"].utcoffset(), datetime.timedelta(hours=-7))
        self.assertEqual(d["odt"].microsecond, 123456)
        self.assertEqual(d["odt"].tzinfo, off)
        self.assertEqual(d["odt2"].utcoffset(), datetime.timedelta(0))
        self.assertIsNotNone(d["odt2"].tzinfo)
        self.assertIsNone(d["ldt"].tzinfo)
        self.assertIs(type(d["ld"]), datetime.date)
        self.assertEqual(d["lt"], datetime.time(7, 32, 0))
        self.assertIsNone(d["lt"].tzinfo)
        self.assertEqual(d["lt2"].microsecond, 500000)

    def test_fraction_truncated_not_rounded(self):
        self.assertEqual(loads("t = 07:32:00.1234569")["t"].microsecond, 123456)

    def test_tables_and_dotted_keys(self):
        d = loads('[a]\nb.c = 1\nb.d = 2\n[a.e]\nf = 3\n')
        self.assertEqual(d, {"a": {"b": {"c": 1, "d": 2}, "e": {"f": 3}}})

    def test_super_table_declared_later(self):
        d = loads("[a.b.c]\nx = 1\n[a]\ny = 2\n")
        self.assertEqual(d, {"a": {"b": {"c": {"x": 1}}, "y": 2}})

    def test_header_subtable_under_dotted_keys(self):
        doc = (
            "[fruit]\napple.color = \"red\"\napple.taste.sweet = true\n\n"
            "[fruit.apple.texture]\nsmooth = true\n"
        )
        self.assertEqual(
            loads(doc),
            {"fruit": {"apple": {
                "color": "red",
                "taste": {"sweet": True},
                "texture": {"smooth": True},
            }}},
        )

    def test_array_of_tables_nested(self):
        doc = (
            "[[fruit]]\nname = 'apple'\n"
            "[[fruit.variety]]\nn = 1\n"
            "[[fruit.variety]]\nn = 2\n"
            "[[fruit]]\nname = 'banana'\n"
            "[fruit.physical]\ncolor = 'yellow'\n"
        )
        d = loads(doc)
        self.assertEqual(d["fruit"][0]["variety"], [{"n": 1}, {"n": 2}])
        self.assertEqual(d["fruit"][1], {"name": "banana", "physical": {"color": "yellow"}})

    def test_array_of_tables_implicit_parent_is_mapping(self):
        d = loads("[[a.b]]\nx = 1\n[a]\ny = 2\n")
        self.assertEqual(d, {"a": {"b": [{"x": 1}], "y": 2}})

    def test_inline_tables(self):
        d = loads("t = { a = 1, b.c = 'x', d = {} }\ne = {}\n")
        self.assertEqual(d, {"t": {"a": 1, "b": {"c": "x"}, "d": {}}, "e": {}})

    def test_inline_table_multiline_and_trailing_comma(self):
        d = loads("t = {\n  a = 1, # note\n  b = 2,\n}\n")
        self.assertEqual(d, {"t": {"a": 1, "b": 2}})

    def test_arrays(self):
        d = loads("a = []\nb = [1, 'x', [2.5], {c = 3}]\nc = [\n  1, # one\n  2,\n]\n")
        self.assertEqual(d["a"], [])
        self.assertEqual(d["b"], [1, "x", [2.5], {"c": 3}])
        self.assertEqual(d["c"], [1, 2])

    def test_keys(self):
        d = loads('1 = "n"\ntrue = "t"\n"a.b" = 1\n\'c d\' = 2\n"" = 3\n"#" = 4\n')
        self.assertEqual(d, {"1": "n", "true": "t", "a.b": 1, "c d": 2, "": 3, "#": 4})

    def test_quoted_basic_key_escapes_literal_key_does_not(self):
        d = loads('"\\u0041" = 1\n\'\\u0041\' = 2\n')
        self.assertEqual(d, {"A": 1, "\\u0041": 2})

    def test_key_case_is_significant(self):
        self.assertEqual(loads("a = 1\nA = 2"), {"a": 1, "A": 2})

    def test_float_converter_applies_everywhere(self):
        seen = []

        def conv(text):
            seen.append(text)
            return ("F", text)

        d = loads("a = 1.5\nb = [2e3, 1_0.0]\nc = {d = -inf}\ne = 7\n", parse_float=conv)
        self.assertEqual(d["a"], ("F", "1.5"))
        self.assertEqual(d["b"], [("F", "2e3"), ("F", "1_0.0")])
        self.assertEqual(d["c"], {"d": ("F", "-inf")})
        self.assertEqual(d["e"], 7)
        self.assertEqual(seen, ["1.5", "2e3", "1_0.0", "-inf"])

    def test_float_converter_result_can_be_non_dict(self):
        self.assertEqual(loads("a = 1.5", parse_float=lambda t: None), {"a": None})

    def test_load_from_binary_file(self):
        d = load(io.BytesIO(b'a = "\xc3\xa9"\r\nb = """x\r\ny"""\r\n'))
        self.assertEqual(d, {"a": "\u00e9", "b": "x\ny"})
        self.assertEqual(load(io.BytesIO(b"")), {})


class InvalidDocuments(unittest.TestCase):
    def assertInvalid(self, doc):
        with self.assertRaises(TOMLDecodeError, msg=repr(doc)):
            loads(doc)

    def test_redefinitions(self):
        for doc in [
            "[a]\n[a]",
            "a=1\na=2",
            "a.b=1\na.b=2",
            "[a]\nb.c=1\n[a.b]",
            "a.b=1\n[a]",
            "a = 1\n[a]",
            "a = [1]\n[[a]]",
            "[a]\nb=1\n[[a.b]]",
            "[[a]]\na=1\n[a]",
            "[a.b.c]\n[a]\nb.d = 1",
            "a = {}\n[a.b]",
            "a = {b = 1}\n[a]",
            "t = {x = 1}\nt.y = 2",
            "[[a]]\nb = 1\n[a]\nb = 2",
            "a = [1]\na.b = 2",
        ]:
            self.assertInvalid(doc)

    def test_syntax(self):
        for doc in [
            "a = 01",
            "a = 1.",
            "a = .5",
            "a = [1,,]",
            "a = [,]",
            "a = 1 b = 2",
            "[a] b = 1",
            "a =\n1",
            "a",
            "= 1",
            "{}",
            "[]",
            "a = 0x",
            "a = 0X1",
            "a = 1__0",
            "a = 1_",
            "a = 0x_1",
            "a = 0b102",
            "a = +0x1",
            "a = 1e",
            "a = 1979-02-29",
            "a = 1900-02-29",
            "a = 25:00:00",
            "a = 07:60:00",
            "a = 07:00:60",
            "a = 1979-05-27T07:32:00+24:00",
            "a = True",
            "a = 'x",
            'a = "x',
            'a = "x\ny"',
            "a = 'x\ny'",
            'a = """x\ry"""',
            'a = """x\\ y"""',
            'a = "\\q"',
            'a = "\\x4"',
            'a = "\\uD800"',
            'a = "\\U00110000"',
            'a = "\x01"',
            'a = "\x7f"',
            "a = 1\rb = 2",
            '"""k""" = 1',
            "'''k''' = 1",
            'a = """x"""""""',
            "a = 1 # \x01",
            "a = \ufeff1",
        ]:
            self.assertInvalid(doc)

    def test_error_is_value_error_not_type_error(self):
        with self.assertRaises(ValueError) as cm:
            loads("a = [")
        self.assertIsInstance(cm.exception, TOMLDecodeError)
        self.assertNotIsInstance(cm.exception, TypeError)

    def test_wrong_input_type_is_type_error(self):
        for bad in [b"a = 1", 1, None, io.StringIO("a = 1")]:
            with self.assertRaises(TypeError) as cm:
                loads(bad)
            self.assertNotIsInstance(cm.exception, TOMLDecodeError)

    def test_text_mode_file_refused(self):
        with self.assertRaises(TypeError) as cm:
            load(io.StringIO("a = 1"))
        self.assertNotIsInstance(cm.exception, TOMLDecodeError)

    def test_converter_returning_dict_or_list_is_value_error(self):
        for result in [{}, []]:
            with self.assertRaises(ValueError) as cm:
                loads("a = 1.0", parse_float=lambda t, r=result: r)
            self.assertNotIsInstance(cm.exception, TOMLDecodeError)

    def test_converter_returning_dict_subclass_is_value_error(self):
        class D(dict):
            pass

        with self.assertRaises(ValueError) as cm:
            loads("a = 1.0", parse_float=lambda t: D())
        self.assertNotIsInstance(cm.exception, TOMLDecodeError)

    def test_decode_error_location(self):
        with self.assertRaises(TOMLDecodeError) as cm:
            loads("a = 1\nb = 2\nc = [1, @]\n")
        err = cm.exception
        self.assertEqual(err.lineno, 3)
        self.assertEqual(err.colno, 9)
        self.assertEqual(err.doc[err.pos], "@")
        self.assertIn("line 3", str(err))
        self.assertIn("column 9", str(err))

    def test_decode_error_at_end_of_document(self):
        with self.assertRaises(TOMLDecodeError) as cm:
            loads("a = [")
        self.assertIn("end of document", str(cm.exception))
        self.assertEqual(cm.exception.pos, 5)

    def test_decode_error_constructed_directly(self):
        err = TOMLDecodeError("bad", "x = 1\ny = 2", 8)
        self.assertEqual(err.msg, "bad")
        self.assertEqual(err.doc, "x = 1\ny = 2")
        self.assertEqual(err.pos, 8)
        self.assertEqual(err.lineno, 2)
        self.assertEqual(err.colno, 3)
        self.assertIsInstance(err, ValueError)
        self.assertIn("line 2", str(err))
        self.assertIn("column 3", str(err))


if __name__ == "__main__":
    unittest.main()
