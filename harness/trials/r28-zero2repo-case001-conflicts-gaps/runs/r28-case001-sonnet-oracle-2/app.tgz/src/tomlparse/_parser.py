# spec: N-000266 N-000270 N-000271 N-000272 (public surface)
import re
from datetime import date, datetime, time, timedelta, timezone


class TOMLDecodeError(ValueError):
    """Raised when a document is not valid TOML."""

    def __init__(self, msg="", doc="", pos=0, *args):
        self.msg = msg
        self.doc = doc
        self.pos = pos
        self.lineno = doc.count("\n", 0, pos) + 1
        last = doc.rfind("\n", 0, pos)
        self.colno = pos - last  # 1 + chars between last LF and pos
        if pos >= len(doc):
            loc = "at end of document"
        else:
            loc = "at line %d, column %d" % (self.lineno, self.colno)
        ValueError.__init__(self, "%s (%s)" % (msg, loc))


_BARE = re.compile(r"[A-Za-z0-9_-]+")
_TOKEN = re.compile(r"[^\s,\]}#]*")
_DEC = re.compile(r"[+-]?(?:0|[1-9](?:_?[0-9])*)\Z")
_FLOAT = re.compile(
    r"[+-]?(?:0|[1-9](?:_?[0-9])*)(?:\.[0-9](?:_?[0-9])*)?(?:[eE][+-]?[0-9](?:_?[0-9])*)?\Z")
_HEX = re.compile(r"0x[0-9a-fA-F](?:_?[0-9a-fA-F])*\Z")
_OCT = re.compile(r"0o[0-7](?:_?[0-7])*\Z")
_BIN = re.compile(r"0b[01](?:_?[01])*\Z")
_SPECIAL = re.compile(r"[+-]?(?:inf|nan)\Z")
_DT = re.compile(
    r"(\d{4})-(\d\d)-(\d\d)"
    r"(?:[Tt ](?=\d\d:)(\d\d):(\d\d)(?::(\d\d)(?:\.(\d+))?)?(Z|z|[+-]\d\d:\d\d)?)?")
_TM = re.compile(r"(\d\d):(\d\d)(?::(\d\d)(?:\.(\d+))?)?")
_WS = " \t"
_ESC = {"b": "\b", "t": "\t", "n": "\n", "f": "\f", "r": "\r", "e": "\x1b",
        '"': '"', "\\": "\\"}
_HEXD = "0123456789abcdefABCDEF"


class _Err(Exception):
    def __init__(self, msg, pos):
        self.msg = msg
        self.pos = pos


def _bad_ctrl(c):
    return (c < " " and c != "\t") or c == "\x7f"


class _Parser:
    def __init__(self, s, parse_float):
        self.s = s
        self.n = len(s)
        self.i = 0
        self.pf = parse_float
        self.defined = set()   # ids of tables defined by header
        self.dotted = set()    # ids of tables created by dotted keys
        self.frozen = set()    # ids of inline tables
        self.aot = set()       # ids of arrays of tables
        self.keep = []         # keep objects alive so ids stay unique

    def err(self, msg, pos=None):
        raise _Err(msg, self.i if pos is None else pos)

    # ---- whitespace / comments
    def skip_ws(self):
        s, n = self.s, self.n
        while self.i < n and s[self.i] in _WS:
            self.i += 1

    def skip_comment(self):
        s = self.s
        if self.i < self.n and s[self.i] == "#":
            while self.i < self.n and s[self.i] != "\n":
                if _bad_ctrl(s[self.i]):
                    self.err("Illegal character in comment")
                self.i += 1

    def skip_ws_nl_comments(self):
        while True:
            self.skip_ws()
            self.skip_comment()
            if self.i < self.n and self.s[self.i] == "\n":
                self.i += 1
            else:
                return

    def end_of_line(self):
        self.skip_ws()
        self.skip_comment()
        if self.i < self.n:
            if self.s[self.i] != "\n":
                self.err("Expected end of line")
            self.i += 1

    # ---- top level
    def parse(self):
        root = {}
        cur = root
        self.keep.append(root)
        while True:
            self.skip_ws_nl_comments()
            if self.i >= self.n:
                return root
            c = self.s[self.i]
            if c == "[":
                cur = self.header(root)
                self.end_of_line()
            else:
                self.keyval(cur)
                self.end_of_line()

    def header(self, root):
        s = self.s
        self.i += 1
        is_aot = self.i < self.n and s[self.i] == "["
        if is_aot:
            self.i += 1
        self.skip_ws()
        path = self.key_path()
        self.skip_ws()
        close = "]]" if is_aot else "]"
        if not s.startswith(close, self.i):
            self.err("Expected '%s'" % close)
        self.i += len(close)
        start = self.i
        tbl = root
        for k in path[:-1]:
            tbl = self.descend_header(tbl, k)
        last = path[-1]
        if is_aot:
            if last not in tbl:
                lst = []
                self.aot.add(id(lst))
                self.keep.append(lst)
                tbl[last] = lst
            else:
                lst = tbl[last]
                if not (isinstance(lst, list) and id(lst) in self.aot):
                    self.err("Cannot extend non array-of-tables", start - 1)
            new = {}
            self.keep.append(new)
            lst.append(new)
            return new
        if last not in tbl:
            new = {}
            self.keep.append(new)
            tbl[last] = new
            self.defined.add(id(new))
            return new
        t = tbl[last]
        if (not isinstance(t, dict) or id(t) in self.defined
                or id(t) in self.dotted or id(t) in self.frozen):
            self.err("Cannot redefine table", start - 1)
        self.defined.add(id(t))
        return t

    def descend_header(self, tbl, k):
        if k not in tbl:
            new = {}
            self.keep.append(new)
            tbl[k] = new
            return new
        t = tbl[k]
        if isinstance(t, list):
            if id(t) in self.aot and t:
                return t[-1]
            self.err("Cannot extend static array", self.i - 1)
        if isinstance(t, dict):
            if id(t) in self.frozen:
                self.err("Cannot extend inline table", self.i - 1)
            return t
        self.err("Cannot extend a value", self.i - 1)

    # ---- keys
    def key_path(self):
        parts = [self.one_key()]
        while True:
            save = self.i
            self.skip_ws()
            if self.i < self.n and self.s[self.i] == ".":
                self.i += 1
                self.skip_ws()
                parts.append(self.one_key())
            else:
                self.i = save
                return parts

    def one_key(self):
        if self.i >= self.n:
            self.err("Expected key")
        c = self.s[self.i]
        if c == '"':
            return self.basic_string()
        if c == "'":
            return self.literal_string()
        m = _BARE.match(self.s, self.i)
        if not m:
            self.err("Invalid key")
        self.i = m.end()
        return m.group()

    def keyval(self, tbl):
        keypos = self.i
        path = self.key_path()
        self.skip_ws()
        if self.i >= self.n or self.s[self.i] != "=":
            self.err("Expected '=' after key")
        self.i += 1
        self.skip_ws()
        for k in path[:-1]:
            if k not in tbl:
                new = {}
                self.keep.append(new)
                self.dotted.add(id(new))
                tbl[k] = new
                tbl = new
            else:
                t = tbl[k]
                if not isinstance(t, dict) or id(t) not in self.dotted \
                        or id(t) in self.frozen:
                    self.err("Cannot extend table with dotted key", keypos)
                tbl = t
        last = path[-1]
        if last in tbl:
            self.err("Duplicate key", keypos)
        tbl[last] = self.value()

    # ---- values
    def value(self):
        s = self.s
        if self.i >= self.n:
            self.err("Expected value")
        c = s[self.i]
        if c == '"':
            if s.startswith('"""', self.i):
                return self.ml_basic()
            return self.basic_string()
        if c == "'":
            if s.startswith("'''", self.i):
                return self.ml_literal()
            return self.literal_string()
        if c == "[":
            return self.array()
        if c == "{":
            return self.inline_table()
        if s.startswith("true", self.i) and self._ends(self.i + 4):
            self.i += 4
            return True
        if s.startswith("false", self.i) and self._ends(self.i + 5):
            self.i += 5
            return False
        return self.number_or_date()

    def _ends(self, j):
        return j >= self.n or self.s[j] in " \t\n,]}#"

    def number_or_date(self):
        s = self.s
        start = self.i
        m = _DT.match(s, start)
        if m and self._ends(m.end()):
            self.i = m.end()
            return self.make_dt(m, start)
        m = _TM.match(s, start)
        if m and self._ends(m.end()):
            self.i = m.end()
            h, mi, sec, frac = m.groups()
            h, mi, sec = int(h), int(mi), int(sec or 0)
            if h > 23 or mi > 59 or sec > 59:
                self.err("Invalid time", start)
            return time(h, mi, sec, self.micro(frac))
        tok = _TOKEN.match(s, start).group()
        if not tok:
            self.err("Invalid value", start)
        end = start + len(tok)
        if _DEC.match(tok):
            self.i = end
            return int(tok)
        for rx, base in ((_HEX, 16), (_OCT, 8), (_BIN, 2)):
            if rx.match(tok):
                self.i = end
                return int(tok[2:].replace("_", ""), base)
        if _FLOAT.match(tok) or _SPECIAL.match(tok):
            self.i = end
            r = self.pf(tok)
            if isinstance(r, (dict, list)):
                raise ValueError("parse_float must not return a dict or list")
            return r
        self.err("Invalid value", start)

    @staticmethod
    def micro(frac):
        if not frac:
            return 0
        return int(frac[:6].ljust(6, "0"))

    def make_dt(self, m, start):
        y, mo, d, h, mi, sec, frac, off = m.groups()
        try:
            dd = date(int(y), int(mo), int(d))
        except ValueError:
            self.err("Invalid date", start)
        if h is None:
            return dd
        h, mi, sec = int(h), int(mi), int(sec or 0)
        if h > 23 or mi > 59 or sec > 59:
            self.err("Invalid time", start)
        tz = None
        if off:
            if off in "Zz":
                tz = timezone.utc
            else:
                oh, om = int(off[1:3]), int(off[4:6])
                if oh > 23 or om > 59:
                    self.err("Invalid offset", start)
                delta = timedelta(hours=oh, minutes=om)
                tz = timezone(-delta if off[0] == "-" else delta)
        return datetime(dd.year, dd.month, dd.day, h, mi, sec,
                        self.micro(frac), tz)

    # ---- strings
    def literal_string(self):
        s = self.s
        start = self.i
        self.i += 1
        j = self.i
        while j < self.n and s[j] != "'":
            if s[j] == "\n" or _bad_ctrl(s[j]):
                self.err("Illegal character in string", j)
            j += 1
        if j >= self.n:
            self.err("Unterminated string", start)
        self.i = j + 1
        return s[start + 1:j]

    def ml_literal(self):
        s = self.s
        start = self.i
        self.i += 3
        if self.i < self.n and s[self.i] == "\n":
            self.i += 1
        out = []
        while True:
            if self.i >= self.n:
                self.err("Unterminated string", start)
            if s.startswith("'''", self.i):
                j = self.i + 3
                extra = 0
                while extra < 2 and j < self.n and s[j] == "'":
                    j += 1
                    extra += 1
                out.append("'" * extra)
                self.i = j
                return "".join(out)
            c = s[self.i]
            if _bad_ctrl(c) and c != "\n":
                self.err("Illegal character in string")
            out.append(c)
            self.i += 1

    def escape(self, out):
        s = self.s
        # self.i is at the backslash
        j = self.i + 1
        if j >= self.n:
            self.err("Unterminated string", self.i)
        c = s[j]
        if c in _ESC:
            out.append(_ESC[c])
            self.i = j + 1
            return
        if c in "xuU":
            ln = {"x": 2, "u": 4, "U": 8}[c]
            h = s[j + 1:j + 1 + ln]
            if len(h) != ln or any(ch not in _HEXD for ch in h):
                self.err("Invalid escape", self.i)
            cp = int(h, 16)
            if cp > 0x10FFFF or 0xD800 <= cp <= 0xDFFF:
                self.err("Invalid Unicode scalar value", self.i)
            out.append(chr(cp))
            self.i = j + 1 + ln
            return
        self.err("Invalid escape", self.i)

    def basic_string(self):
        s = self.s
        start = self.i
        self.i += 1
        out = []
        while True:
            if self.i >= self.n:
                self.err("Unterminated string", start)
            c = s[self.i]
            if c == '"':
                self.i += 1
                return "".join(out)
            if c == "\\":
                self.escape(out)
                continue
            if c == "\n" or _bad_ctrl(c):
                self.err("Illegal character in string")
            out.append(c)
            self.i += 1

    def ml_basic(self):
        s = self.s
        start = self.i
        self.i += 3
        if self.i < self.n and s[self.i] == "\n":
            self.i += 1
        out = []
        while True:
            if self.i >= self.n:
                self.err("Unterminated string", start)
            if s.startswith('"""', self.i):
                j = self.i + 3
                extra = 0
                while extra < 2 and j < self.n and s[j] == '"':
                    j += 1
                    extra += 1
                out.append('"' * extra)
                self.i = j
                return "".join(out)
            c = s[self.i]
            if c == "\\":
                j = self.i + 1
                while j < self.n and s[j] in _WS:
                    j += 1
                if j < self.n and s[j] == "\n":
                    while j < self.n and s[j] in " \t\n":
                        j += 1
                    self.i = j
                    continue
                self.escape(out)
                continue
            if _bad_ctrl(c) and c != "\n":
                self.err("Illegal character in string")
            out.append(c)
            self.i += 1

    # ---- containers
    def array(self):
        s = self.s
        self.i += 1
        arr = []
        while True:
            self.skip_ws_nl_comments()
            if self.i >= self.n:
                self.err("Unterminated array")
            if s[self.i] == "]":
                self.i += 1
                return arr
            arr.append(self.value())
            self.skip_ws_nl_comments()
            if self.i >= self.n:
                self.err("Unterminated array")
            if s[self.i] == ",":
                self.i += 1
            elif s[self.i] == "]":
                self.i += 1
                return arr
            else:
                self.err("Expected ',' or ']' in array")

    def inline_table(self):
        s = self.s
        self.i += 1
        tbl = {}
        self.keep.append(tbl)
        while True:
            self.skip_ws_nl_comments()
            if self.i >= self.n:
                self.err("Unterminated inline table")
            if s[self.i] == "}":
                self.i += 1
                break
            self.keyval(tbl)
            self.skip_ws_nl_comments()
            if self.i >= self.n:
                self.err("Unterminated inline table")
            if s[self.i] == ",":
                self.i += 1
            elif s[self.i] == "}":
                self.i += 1
                break
            else:
                self.err("Expected ',' or '}' in inline table")
        self.freeze(tbl)
        return tbl

    def freeze(self, v):
        if isinstance(v, dict):
            self.frozen.add(id(v))
            for x in v.values():
                self.freeze(x)
        elif isinstance(v, list):
            for x in v:
                self.freeze(x)


def loads(s, *, parse_float=float):
    if not isinstance(s, str):
        raise TypeError("Expected str object, not '%s'" % type(s).__name__)
    doc = s.replace("\r\n", "\n")
    p = _Parser(doc, parse_float)
    try:
        return p.parse()
    except _Err as e:
        raise TOMLDecodeError(e.msg, doc, e.pos) from None
    except RecursionError:
        raise TOMLDecodeError("Document too deeply nested", doc, 0) from None


def load(fp, *, parse_float=float):
    b = fp.read()
    if isinstance(b, str):
        raise TypeError("File must be opened in binary mode")
    try:
        s = b.decode("utf-8")
    except UnicodeDecodeError as e:
        raise TOMLDecodeError("Invalid UTF-8", b.decode("utf-8", "replace"),
                              e.start) from None
    return loads(s, parse_float=parse_float)
