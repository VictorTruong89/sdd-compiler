"""Hand-written TOML v1.1.0 parser.

The parser works on a text string with newlines normalised (CR LF becomes
LF). When the input contains carriage returns, a position map is kept so
that decode errors report offsets into the caller's original text.
"""

import datetime as _datetime
import io
import re

from ._errors import TOMLDecodeError

_MISSING = object()

_WS = re.compile(r"[ \t]*")
_BARE_KEY = re.compile(r"[A-Za-z0-9_-]+")
# Characters allowed unescaped in a basic string / literal string run.
_BASIC_RUN = re.compile(r'[^"\\\x00-\x08\x0a-\x1f\x7f]+')
_LITERAL_RUN = re.compile(r"[^'\x00-\x08\x0a-\x1f\x7f]+")
_COMMENT_BAD = re.compile(r"[\x00-\x08\x0a-\x1f\x7f]")

_DATETIME = re.compile(
    r"([0-9]{4})-([0-9]{2})-([0-9]{2})"
    r"(?:[Tt ]([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?"
    r"([Zz]|[+-][0-9]{2}:[0-9]{2})?)?"
)
_TIME = re.compile(r"([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?")
_SPECIAL_FLOAT = re.compile(r"[+-]?(?:inf|nan)(?![A-Za-z0-9_])")
_PREFIXED_INT = re.compile(
    r"0x([0-9A-Fa-f](?:_?[0-9A-Fa-f])*)"
    r"|0o([0-7](?:_?[0-7])*)"
    r"|0b([01](?:_?[01])*)"
)
_DECIMAL = re.compile(
    r"[+-]?(?:0|[1-9](?:_?[0-9])*)"
    r"(\.[0-9](?:_?[0-9])*)?"
    r"([eE][+-]?[0-9](?:_?[0-9])*)?"
)

_SIMPLE_ESCAPES = {
    "b": "\b",
    "t": "\t",
    "n": "\n",
    "f": "\f",
    "r": "\r",
    "e": "\x1b",
    '"': '"',
    "\\": "\\",
}
_ESCAPE_WIDTHS = {"x": 2, "u": 4, "U": 8}
_HEXDIGITS = frozenset("0123456789abcdefABCDEF")


def _normalize_newlines(s):
    """Return (text, posmap). posmap maps text indexes to indexes in s."""
    if "\r" not in s:
        return s, None
    out = []
    index = []
    length = len(s)
    j = 0
    while j < length:
        c = s[j]
        if c == "\r" and j + 1 < length and s[j + 1] == "\n":
            out.append("\n")
            index.append(j)
            j += 2
        else:
            out.append(c)
            index.append(j)
            j += 1
    index.append(length)
    return "".join(out), index


class _Parser(object):
    def __init__(self, text, posmap, doc, parse_float):
        self.src = text
        self.n = len(text)
        self.i = 0
        self.posmap = posmap
        self.doc = doc
        self.parse_float = parse_float
        # id(container) -> (kind, container). Kinds:
        #   "implicit" table created by a header as a super-table
        #   "explicit" table defined by a header (or array-of-tables item)
        #   "dotted"   table created by dotted keys
        #   "inline"   inline table (frozen once written)
        #   "aot"      array of tables (a list)
        self.kinds = {}

    # ----------------------------------------------------------- utilities

    def error(self, msg, pos=None):
        if pos is None:
            pos = self.i
        if self.posmap is not None:
            pos = self.posmap[min(pos, len(self.posmap) - 1)]
        return TOMLDecodeError(msg, self.doc, pos)

    def _mark(self, obj, kind):
        self.kinds[id(obj)] = (kind, obj)

    def _kind(self, obj):
        entry = self.kinds.get(id(obj))
        return entry[0] if entry is not None else None

    def _peek(self):
        return self.src[self.i] if self.i < self.n else ""

    def _skip_ws(self):
        self.i = _WS.match(self.src, self.i).end()

    def _skip_ws_nl(self):
        while True:
            self._skip_ws()
            if self.i >= self.n:
                return
            c = self.src[self.i]
            if c == "\n":
                self.i += 1
            elif c == "#":
                self._comment()
            else:
                return

    def _comment(self):
        start = self.i
        end = self.src.find("\n", start)
        if end < 0:
            end = self.n
        bad = _COMMENT_BAD.search(self.src, start, end)
        if bad is not None:
            raise self.error("control character in comment", bad.start())
        self.i = end

    def _end_of_line(self):
        self._skip_ws()
        if self._peek() == "#":
            self._comment()
        if self.i < self.n and self.src[self.i] != "\n":
            raise self.error("expected end of line")

    # ------------------------------------------------------------ document

    def parse(self):
        root = {}
        cur = root
        src = self.src
        while True:
            self._skip_ws()
            if self.i >= self.n:
                break
            c = src[self.i]
            if c == "\n":
                self.i += 1
                continue
            if c == "#":
                self._comment()
                continue
            if c == "[":
                if src.startswith("[[", self.i):
                    cur = self._array_header(root)
                else:
                    cur = self._table_header(root)
            else:
                self._key_value(cur)
            self._end_of_line()
        return root

    def _table_header(self, root):
        start = self.i
        self.i += 1
        self._skip_ws()
        keys = self._key()
        self._skip_ws()
        if self._peek() != "]":
            raise self.error("expected ']' to close table header")
        self.i += 1
        node = root
        for key in keys[:-1]:
            node = self._header_step(node, key, start)
        last = keys[-1]
        child = node.get(last, _MISSING)
        if child is _MISSING:
            table = {}
            node[last] = table
            self._mark(table, "explicit")
            return table
        if isinstance(child, dict) and self._kind(child) == "implicit":
            self._mark(child, "explicit")
            return child
        raise self.error("table is already defined", start)

    def _array_header(self, root):
        start = self.i
        self.i += 2
        self._skip_ws()
        keys = self._key()
        self._skip_ws()
        if not self.src.startswith("]]", self.i):
            raise self.error("expected ']]' to close array of tables header")
        self.i += 2
        node = root
        for key in keys[:-1]:
            node = self._header_step(node, key, start)
        last = keys[-1]
        child = node.get(last, _MISSING)
        if child is _MISSING:
            seq = []
            self._mark(seq, "aot")
            node[last] = seq
        elif isinstance(child, list) and self._kind(child) == "aot":
            seq = child
        else:
            raise self.error("array of tables conflicts with existing key", start)
        item = {}
        self._mark(item, "explicit")
        seq.append(item)
        return item

    def _header_step(self, node, key, start):
        """Walk one intermediate part of a table header."""
        child = node.get(key, _MISSING)
        if child is _MISSING:
            table = {}
            node[key] = table
            self._mark(table, "implicit")
            return table
        if isinstance(child, list):
            if self._kind(child) == "aot":
                return child[-1]
            raise self.error("static array cannot be extended by a table header", start)
        if isinstance(child, dict):
            if self._kind(child) == "inline":
                raise self.error("inline table cannot be extended", start)
            return child
        raise self.error("key already holds a value", start)

    def _key_value(self, table):
        start = self.i
        keys = self._key()
        self._skip_ws()
        if self._peek() != "=":
            raise self.error("expected '=' after key")
        self.i += 1
        self._skip_ws()
        node = table
        for key in keys[:-1]:
            child = node.get(key, _MISSING)
            if child is _MISSING:
                sub = {}
                node[key] = sub
                self._mark(sub, "dotted")
                node = sub
            elif isinstance(child, dict) and self._kind(child) == "dotted":
                node = child
            else:
                raise self.error("dotted key conflicts with an existing key", start)
        last = keys[-1]
        if last in node:
            raise self.error("duplicate key", start)
        value = self._value()
        node[last] = value

    def _key(self):
        parts = []
        while True:
            self._skip_ws()
            c = self._peek()
            if c == '"':
                parts.append(self._single_line('"', True))
            elif c == "'":
                parts.append(self._single_line("'", False))
            else:
                m = _BARE_KEY.match(self.src, self.i)
                if m is None:
                    raise self.error("expected a key")
                parts.append(m.group())
                self.i = m.end()
            self._skip_ws()
            if self._peek() == ".":
                self.i += 1
                continue
            return parts

    # -------------------------------------------------------------- values

    def _value(self):
        if self.i >= self.n:
            raise self.error("expected a value")
        src = self.src
        i = self.i
        c = src[i]
        if c == '"':
            if src.startswith('"""', i):
                return self._multiline('"', True)
            return self._single_line('"', True)
        if c == "'":
            if src.startswith("'''", i):
                return self._multiline("'", False)
            return self._single_line("'", False)
        if c == "[":
            return self._array()
        if c == "{":
            return self._inline()
        if src.startswith("true", i):
            self.i = i + 4
            return True
        if src.startswith("false", i):
            self.i = i + 5
            return False
        return self._scalar()

    def _scalar(self):
        src = self.src
        start = self.i
        m = _DATETIME.match(src, start)
        if m is not None:
            self.i = m.end()
            return self._make_datetime(m, start)
        m = _TIME.match(src, start)
        if m is not None:
            self.i = m.end()
            return self._make_time(m, start)
        m = _SPECIAL_FLOAT.match(src, start)
        if m is not None:
            self.i = m.end()
            return self._float(m.group())
        m = _PREFIXED_INT.match(src, start)
        if m is not None:
            self.i = m.end()
            if m.group(1) is not None:
                return int(m.group(1).replace("_", ""), 16)
            if m.group(2) is not None:
                return int(m.group(2).replace("_", ""), 8)
            return int(m.group(3).replace("_", ""), 2)
        m = _DECIMAL.match(src, start)
        if m is not None:
            self.i = m.end()
            if m.group(1) or m.group(2):
                return self._float(m.group())
            return int(m.group().replace("_", ""))
        raise self.error("invalid value", start)

    def _float(self, text):
        if self.parse_float is float:
            return float(text.replace("_", ""))
        value = self.parse_float(text)
        if isinstance(value, (dict, list)):
            raise ValueError("parse_float returned a dict or list, which is not allowed")
        return value

    def _clock(self, m, group, start):
        hour = int(m.group(group))
        minute = int(m.group(group + 1))
        sec_text = m.group(group + 2)
        second = int(sec_text) if sec_text else 0
        frac = m.group(group + 3) or ""
        micro = int(frac[:6].ljust(6, "0"))
        if hour > 23 or minute > 59 or second > 59:
            raise self.error("invalid time of day", start)
        return hour, minute, second, micro

    def _make_time(self, m, start):
        hour, minute, second, micro = self._clock(m, 1, start)
        return _datetime.time(hour, minute, second, micro)

    def _make_datetime(self, m, start):
        year, month, day = int(m.group(1)), int(m.group(2)), int(m.group(3))
        try:
            date = _datetime.date(year, month, day)
        except ValueError:
            raise self.error("invalid calendar date", start)
        if m.group(4) is None:
            return date
        hour, minute, second, micro = self._clock(m, 4, start)
        offset = m.group(8)
        if offset is None:
            return _datetime.datetime(
                year, month, day, hour, minute, second, micro
            )
        tz = self._offset(offset, start)
        return _datetime.datetime(
            year, month, day, hour, minute, second, micro, tzinfo=tz
        )

    def _offset(self, text, start):
        if text in ("Z", "z"):
            return _datetime.timezone.utc
        hours = int(text[1:3])
        minutes = int(text[4:6])
        if hours > 23 or minutes > 59:
            raise self.error("invalid UTC offset", start)
        delta = _datetime.timedelta(hours=hours, minutes=minutes)
        if text[0] == "-":
            delta = -delta
        return _datetime.timezone(delta)

    # ------------------------------------------------------------- strings

    def _escape(self, i):
        """Decode the escape whose backslash is at index i.

        Returns (character, index just past the escape).
        """
        j = i + 1
        if j >= self.n:
            raise self.error("unterminated escape sequence", i)
        c = self.src[j]
        if c in _SIMPLE_ESCAPES:
            return _SIMPLE_ESCAPES[c], j + 1
        width = _ESCAPE_WIDTHS.get(c)
        if width is not None:
            digits = self.src[j + 1:j + 1 + width]
            if len(digits) != width or not all(d in _HEXDIGITS for d in digits):
                raise self.error("invalid hexadecimal escape", i)
            code = int(digits, 16)
            if code > 0x10FFFF or 0xD800 <= code <= 0xDFFF:
                raise self.error("escape is not a Unicode scalar value", i)
            return chr(code), j + 1 + width
        raise self.error("invalid escape sequence", i)

    def _single_line(self, quote, escapes):
        src = self.src
        start = self.i
        i = start + 1
        buf = []
        run = _BASIC_RUN if escapes else _LITERAL_RUN
        while True:
            m = run.match(src, i)
            if m is not None:
                buf.append(m.group())
                i = m.end()
            if i >= self.n:
                raise self.error("unterminated string", self.n)
            c = src[i]
            if c == quote:
                self.i = i + 1
                return "".join(buf)
            if escapes and c == "\\":
                ch, i = self._escape(i)
                buf.append(ch)
                continue
            raise self.error("invalid character in string", i)

    def _multiline(self, quote, escapes):
        src = self.src
        n = self.n
        i = self.i + 3
        if i < n and src[i] == "\n":
            i += 1  # a newline right after the opening delimiter is trimmed
        buf = []
        run = _BASIC_RUN if escapes else _LITERAL_RUN
        while True:
            m = run.match(src, i)
            if m is not None:
                buf.append(m.group())
                i = m.end()
                continue
            if i >= n:
                raise self.error("unterminated multiline string", n)
            c = src[i]
            if c == quote:
                j = i
                while j < n and src[j] == quote:
                    j += 1
                count = j - i
                if count >= 3:
                    if count > 5:
                        raise self.error("too many quotation marks", i)
                    buf.append(quote * (count - 3))
                    self.i = j
                    return "".join(buf)
                buf.append(quote * count)
                i = j
                continue
            if c == "\n":
                buf.append("\n")
                i += 1
                continue
            if escapes and c == "\\":
                j = i + 1
                while j < n and src[j] in " \t":
                    j += 1
                if j < n and src[j] == "\n":
                    # line-ending backslash: drop the newline and all
                    # whitespace up to the next non-whitespace character
                    i = j
                    while i < n and src[i] in " \t\n":
                        i += 1
                    continue
                ch, i = self._escape(i)
                buf.append(ch)
                continue
            raise self.error("invalid character in string", i)

    # ------------------------------------------------------------ containers

    def _array(self):
        self.i += 1
        items = []
        while True:
            self._skip_ws_nl()
            if self._peek() == "]":
                self.i += 1
                return items
            items.append(self._value())
            self._skip_ws_nl()
            c = self._peek()
            if c == ",":
                self.i += 1
                continue
            if c == "]":
                self.i += 1
                return items
            raise self.error("expected ',' or ']' in array")

    def _inline(self):
        self.i += 1
        table = {}
        self._skip_ws_nl()
        if self._peek() == "}":
            self.i += 1
            self._mark(table, "inline")
            return table
        while True:
            self._key_value(table)
            self._skip_ws_nl()
            c = self._peek()
            if c == ",":
                self.i += 1
                self._skip_ws_nl()
                if self._peek() == "}":
                    self.i += 1
                    self._mark(table, "inline")
                    return table
                continue
            if c == "}":
                self.i += 1
                self._mark(table, "inline")
                return table
            raise self.error("expected ',' or '}' in inline table")


def loads(s, *, parse_float=float):
    """Parse a TOML v1.1.0 document from a text string into a dict."""
    if not isinstance(s, str):
        raise TypeError("loads() expects a str, not %s" % type(s).__name__)
    text, posmap = _normalize_newlines(s)
    parser = _Parser(text, posmap, s, parse_float)
    try:
        return parser.parse()
    except RecursionError:
        raise parser.error("document is nested too deeply")


def load(fp, *, parse_float=float):
    """Parse a TOML v1.1.0 document from a binary file object into a dict."""
    if isinstance(fp, io.TextIOBase):
        raise TypeError("load() expects a file opened in binary mode")
    read = getattr(fp, "read", None)
    if read is None:
        raise TypeError("load() expects a binary file object")
    data = read()
    if isinstance(data, str):
        raise TypeError("load() expects a file opened in binary mode")
    if not isinstance(data, (bytes, bytearray)):
        raise TypeError("load() expects bytes from the file object")
    data = bytes(data)
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        doc = data.decode("utf-8", "replace")
        pos = len(data[:exc.start].decode("utf-8"))
        raise TOMLDecodeError("document is not valid UTF-8", doc, pos)
    return loads(text, parse_float=parse_float)
