"""The decode error raised for invalid TOML documents."""


class TOMLDecodeError(ValueError):
    """A TOML document could not be parsed.

    Constructed as ``TOMLDecodeError(msg, doc, pos)``. ``msg`` is the
    unformatted reason, ``doc`` the document text, and ``pos`` a 0-based
    character offset into ``doc``. ``lineno`` and ``colno`` are the 1-based
    line and column of ``pos``.
    """

    def __init__(self, msg, doc, pos):
        self.msg = msg
        self.doc = doc
        self.pos = pos
        self.lineno = doc.count("\n", 0, pos) + 1
        self.colno = pos - doc.rfind("\n", 0, pos)
        if pos < len(doc):
            text = "%s (line %d, column %d, char %d)" % (
                msg,
                self.lineno,
                self.colno,
                pos,
            )
        else:
            text = "%s (at end of document, char %d)" % (msg, pos)
        ValueError.__init__(self, text)

    def __reduce__(self):
        return (self.__class__, (self.msg, self.doc, self.pos))
