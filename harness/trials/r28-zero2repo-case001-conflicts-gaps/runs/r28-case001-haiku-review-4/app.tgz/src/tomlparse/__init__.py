"""Tomlparse: a pure-Python parser for TOML v1.1.0 documents.

Public names: ``loads`` (text string), ``load`` (binary file object) and
``TOMLDecodeError`` (the parse-failure exception, a ``ValueError``).
"""

from ._core import load, loads
from ._errors import TOMLDecodeError

__all__ = ["load", "loads", "TOMLDecodeError"]
__version__ = "2.4.0"
