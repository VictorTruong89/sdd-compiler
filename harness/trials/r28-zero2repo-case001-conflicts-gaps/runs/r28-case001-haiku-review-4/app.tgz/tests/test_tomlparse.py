import copy
import datetime as dt
import io
import pickle
import unittest

import tomlparse
from tomlparse import TOMLDecodeError, load, loads


def bad(text):
    with unittest.TestCase().assertRaises(TOMLDecodeError) as cm:
        loads(text)
    return cm.exception


class StructureTests(unittest.TestCase):
    def test_empty_and_comments(self):
        self.assertEqual(loads(""), {})
        self.assertEqual(loads("   \t "), {})
        self.assertEqual(loads("# only a comment"), {})
        self.assertEqual(loads("# c\n\n# d\n"), {})

    def test_root_and_tables(self):
        doc = 'a = 1\n[t]\nb = "x" # comment\n[t.u]\nc = []\n'
        self.assertEqual(loads(doc), {"a": 1, "t": {"b": "x", "u": {"c": []}}})

    def test_keys_are_strings(self):
        self.assertEqual(
            loads('1 = 1\ntrue = 2\ninf = 3\nnan = 4\n"" = 5\n"a.b" = 6\n'),
            {"1": 1, "true": 2, "inf": 3, "nan": 4, "": 5, "a.b": 6},
        )

    def test_case_sensitive_keys(self):
        self.assertEqual(loads("a = 1\nA = 2"), {"a": 1, "A": 2})

    def test_dotted_keys(self):
        self.assertEqual(
            loads('a . "b.c" . d = 1\na.e = 2'),
            {"a": {"b.c": {"d": 1}, "e": 2}},
        )

    def test_implicit_super_tables_later_declared(self):
        self.assertEqual(loads("[a.b.c]\nx = 1\n[a]\ny = 2"),
                         {"a": {"b": {"c": {"x": 1}}, "y": 2}})

    def test_dotted_then_subtable_header(self):
        self.assertEqual(
            loads("[fruit]\napple.color = 'red'\n[fruit.apple.texture]\nsmooth = true"),
            {"fruit": {"apple": {"color": "red", "texture": {"smooth": True}}}},
        )

    def test_array_of_tables(self):
        doc = "[[p]]\na = 1\n[p.sub]\nx = 1\n[[p]]\na = 2\n[[p.list]]\nq = 3\n"
        self.assertEqual(
            loads(doc),
            {"p": [{"a": 1, "sub": {"x": 1}}, {"a": 2, "list": [{"q": 3}]}]},
        )

    def test_dotted_key_inside_aot_item_then_header(self):
        self.assertEqual(
            loads("[[a]]\na.b = 1\n[a.b]\nc = 2"),
            {"a": [{"a": {"b": 1}, "b": {"c": 2}}]},
        )

    def test_aot_parent_implicit_then_declared(self):
        self.assertEqual(
            loads("[[a.b]]\nx = 1\n[a]\ny = 2"),
            {"a": {"b": [{"x": 1}], "y": 2}},
        )

    def test_inline_tables(self):
        self.assertEqual(loads("t = {}"), {"t": {}})
        self.assertEqual(loads("t = {a.b = 1, c = [1, 'x']}"),
                         {"t": {"a": {"b": 1}, "c": [1, "x"]}})
        self.assertEqual(loads("t = {\n  a = 1, # c\n  b = 2,\n}\n"),
                         {"t": {"a": 1, "b": 2}})

    def test_arrays(self):
        self.assertEqual(loads("a = []"), {"a": []})
        self.assertEqual(loads("a = [1, 'two', [3], {x=4}]"),
                         {"a": [1, "two", [3], {"x": 4}]})
        self.assertEqual(loads("a = [\n  1, # one\n  2,\n]\n"), {"a": [1, 2]})
        self.assertEqual(loads("a = [[1,2,],[]]"), {"a": [[1, 2], []]})

    def test_crlf_is_lf(self):
        self.assertEqual(loads("a = 1\r\nb = \"\"\"x\r\ny\"\"\"\r\n"),
                         {"a": 1, "b": "x\ny"})

    def test_whitespace_indentation(self):
        self.assertEqual(loads("\t[t]\n\t\tk\t=\t1"), {"t": {"k": 1}})


class RefusedStructureTests(unittest.TestCase):
    CASES = [
        "a = 1\na = 2",
        "[t]\n[t]",
        "[a.b]\n[a]\n[a.b]",
        "a.b = 1\n[a]",
        "a.b = 1\n[a.b]",
        "[a]\nb = 1\n[a.b]",
        "a = 1\n[a]",
        "a = 1\n[a.b]",
        "a = {b = 1}\n[a.c]",
        "a = {b = 1}\n[a]\nc = 2\n[a.c]" ,
        "t = {a = 1}\nt.b = 2",
        "t = {a.b = 1}\nt.a.c = 2",
        "[[a]]\n[a]",
        "[a]\n[[a]]",
        "a = [1]\n[[a]]",
        "a = [1]\n[a.b]",
        "a = [{x=1}]\nb = 1\na.c = 2",
        "[[a]]\na.b = 1\n[a.a]",
        "[x]\na.b = 1\n[x.a]",
        "a.b = 1\na.b.c = 2",
        "[a.b]\n[[a.b]]",
        "[a]\n[a.b]\n[a.b]",
        "[t]\nk = 1 x = 2",
        "[t] k = 1",
        "k = 1 [t]",
        "k 1",
        "k =",
        "= 1",
        "k = 1 2",
        '"""k""" = 1',
        "[ [a]]",
        "[[a]\n",
        "[a]]",
        "a..b = 1",
        "a = [1,,2]",
        "a = [,]",
        "a = {,}",
        "a = {b = 1 c = 2}",
        "a = {b = 1,,}",
        "a = {b = 1}\na.c = 2",
        "a = 1 # ok\nb",
    ]

    def test_refused(self):
        for doc in self.CASES:
            with self.subTest(doc=doc):
                with self.assertRaises(TOMLDecodeError):
                    loads(doc)


class ScalarTests(unittest.TestCase):
    def test_booleans(self):
        v = loads("a = true\nb = false")
        self.assertIs(v["a"], True)
        self.assertIs(v["b"], False)

    def test_refused_booleans(self):
        for t in ["True", "TRUE", "tRue", "yes"]:
            with self.subTest(t=t):
                with self.assertRaises(TOMLDecodeError):
                    loads("a = " + t)

    def test_basic_strings_and_escapes(self):
        self.assertEqual(loads(r'a = "\b\t\n\f\r\e\"\\"')["a"],
                         "\b\t\n\f\r\x1b\"\\")
        self.assertEqual(loads(r'a = "\x41\u00e9\U0001F600\u00E9"')["a"],
                         "A\u00e9\U0001F600\u00e9")
        self.assertEqual(loads('a = "tab\there"')["a"], "tab\there")

    def test_literal_strings(self):
        self.assertEqual(loads(r"a = 'C:\path\n'")["a"], r"C:\path\n")
        self.assertEqual(loads("a = ''")["a"], "")

    def test_multiline_basic(self):
        self.assertEqual(loads('a = """\nx\ny"""')["a"], "x\ny")
        self.assertEqual(loads('a = """x\n  y"""')["a"], "x\n  y")
        self.assertEqual(loads('a = """one\\\n   \t\n   two"""')["a"], "onetwo")
        self.assertEqual(loads('a = """\\  \nb"""'), {"a": "b"})
        self.assertEqual(loads('a = """a""""')["a"], 'a"')
        self.assertEqual(loads('a = """a"""""')["a"], 'a""')
        self.assertEqual(loads('a = """q"" x"""')["a"], 'q"" x')
        self.assertEqual(loads('a = """\n\n"""')["a"], "\n")
        self.assertEqual(loads('a = """x\\""""')["a"], 'x"')

    def test_multiline_literal(self):
        self.assertEqual(loads("a = '''\nx\\n'''")["a"], "x\\n")
        self.assertEqual(loads("a = '''a'''' ")["a"], "a'")
        self.assertEqual(loads("a = '''\\\\'''")["a"], "\\\\")
        self.assertEqual(loads("a = '''x\ny'''")["a"], "x\ny")

    def test_refused_strings(self):
        for doc in [
            'a = "\\q"',
            'a = "\\x4"',
            'a = "\\xG1"',
            'a = "\\u00E"',
            'a = "\\uD800"',
            'a = "\\U00110000"',
            'a = "unclosed',
            'a = "line\nbreak"',
            'a = "\x01"',
            'a = "\x7f"',
            "a = 'unclosed",
            "a = 'x\ny'",
            'a = """x"""""" ',
            'a = """x\\ y"""',
            'a = """x\r y"""',
            'a = """unterminated',
            "a = '''x",
        ]:
            with self.subTest(doc=doc):
                with self.assertRaises(TOMLDecodeError):
                    loads(doc)

    def test_quoted_keys_escapes(self):
        self.assertEqual(loads(r'"\u0041" = 1'), {"A": 1})
        self.assertEqual(loads(r"'\u0041' = 1"), {"\\u0041": 1})
        self.assertEqual(loads('"a b#c" = 1'), {"a b#c": 1})

    def test_integers(self):
        self.assertEqual(loads("a = 0\nb = +0\nc = -0\nd = 1_000\ne = -17")["a"], 0)
        v = loads("a = 0\nb = +0\nc = -0\nd = 1_000\ne = -17")
        self.assertEqual([v["a"], v["b"], v["c"], v["d"], v["e"]], [0, 0, 0, 1000, -17])
        self.assertIs(type(v["d"]), int)
        self.assertEqual(loads("a = 0xdead_BEEF")["a"], 0xDEADBEEF)
        self.assertEqual(loads("a = 0o755")["a"], 0o755)
        self.assertEqual(loads("a = 0b1101_0110")["a"], 0b11010110)

    def test_refused_integers(self):
        for doc in ["a = 01", "a = -01", "a = 00", "a = 1__0", "a = 1_",
                    "a = _1", "a = 0X1F", "a = 0O7", "a = 0B1", "a = 0xG",
                    "a = +0x1", "a = -0o7", "a = 0b102", "a = 0o8", "a = 1-2"]:
            with self.subTest(doc=doc):
                with self.assertRaises(TOMLDecodeError):
                    loads(doc)

    def test_floats(self):
        v = loads("a = 3.14\nb = -1e3\nc = 6.02E+23\nd = 1_000.0_1\ne = 1e05\nf = 0.0")
        self.assertEqual(v["a"], 3.14)
        self.assertEqual(v["b"], -1000.0)
        self.assertEqual(v["c"], 6.02e23)
        self.assertEqual(v["d"], 1000.01)
        self.assertEqual(v["e"], 1e5)
        self.assertIsInstance(v["f"], float)
        v = loads("a = inf\nb = +inf\nc = -inf\nd = nan\ne = +nan\nf = -nan")
        self.assertEqual(v["a"], float("inf"))
        self.assertEqual(v["b"], float("inf"))
        self.assertEqual(v["c"], float("-inf"))
        self.assertTrue(v["d"] != v["d"])
        self.assertTrue(v["e"] != v["e"])
        self.assertTrue(v["f"] != v["f"])

    def test_refused_floats(self):
        for doc in ["a = .5", "a = 5.", "a = 01.5", "a = 1.e5", "a = 1e",
                    "a = 1__0.0", "a = .", "a = 1.5.5", "a = infinity",
                    "a = Inf", "a = NaN", "a = 1e_5", "a = -.1"]:
            with self.subTest(doc=doc):
                with self.assertRaises(TOMLDecodeError):
                    loads(doc)

    def test_datetimes(self):
        v = loads(
            "a = 1979-05-27T07:32:00Z\n"
            "b = 1979-05-27 07:32:00.999999-07:00\n"
            "c = 1979-05-27T00:32:00.1234567z\n"
            "d = 1979-05-27\n"
            "e = 07:32:00\n"
            "f = 1979-05-27T07:32:00\n"
            "g = 1979-05-27T07:32Z\n"
            "h = 07:32\n"
            "i = 2024-02-29\n"
            "j = 1979-05-27t07:32:00+05:30\n"
        )
        self.assertEqual(v["a"], dt.datetime(1979, 5, 27, 7, 32, tzinfo=dt.timezone.utc))
        self.assertEqual(v["a"].utcoffset(), dt.timedelta(0))
        self.assertEqual(v["b"].microsecond, 999999)
        self.assertEqual(v["b"].utcoffset(), dt.timedelta(hours=-7))
        self.assertEqual(v["c"].microsecond, 123456)
        self.assertEqual(v["d"], dt.date(1979, 5, 27))
        self.assertEqual(v["e"], dt.time(7, 32, 0))
        self.assertIsNone(v["e"].tzinfo)
        self.assertIsNone(v["f"].tzinfo)
        self.assertEqual(v["g"], dt.datetime(1979, 5, 27, 7, 32, tzinfo=dt.timezone.utc))
        self.assertEqual(v["h"], dt.time(7, 32))
        self.assertEqual(v["i"], dt.date(2024, 2, 29))
        self.assertEqual(v["j"].utcoffset(), dt.timedelta(hours=5, minutes=30))
        self.assertEqual(copy.deepcopy(v["a"]), v["a"])

    def test_refused_datetimes(self):
        for doc in ["a = 2023-02-29", "a = 1900-02-29", "a = 2023-13-01",
                    "a = 07:60:00", "a = 24:00:00", "a = 12:00:60",
                    "a = 1979-05-27T07:32:00+24:00", "a = 1979-05-27T07:32:00+05:60",
                    "a = 1979-05-27T07:32:00Zx", "a = 1979-05-27T07",
                    "a = 1979-5-27", "a = 07:32:00.", "a = 1979-05-27T07:32:00+5:00"]:
            with self.subTest(doc=doc):
                with self.assertRaises(TOMLDecodeError):
                    loads(doc)

    def test_fraction_truncated(self):
        self.assertEqual(loads("a = 07:00:00.1234569")["a"].microsecond, 123456)


class ParseFloatTests(unittest.TestCase):
    def test_converter_called_with_text(self):
        seen = []

        def conv(text):
            seen.append(text)
            return ("F", text)

        v = loads("a = 1_0.5\nb = 1\nc = [2e3, {d = -inf}]\ne = 'x'", parse_float=conv)
        self.assertEqual(seen, ["1_0.5", "2e3", "-inf"])
        self.assertEqual(v["a"], ("F", "1_0.5"))
        self.assertEqual(v["b"], 1)
        self.assertEqual(v["c"][0], ("F", "2e3"))
        self.assertEqual(v["c"][1]["d"], ("F", "-inf"))

    def test_converter_result_dict_or_list_refused(self):
        class D(dict):
            pass

        for result in [{}, [], D(), type("L", (list,), {})()]:
            with self.subTest(result=result):
                with self.assertRaises(ValueError) as cm:
                    loads("a = 1.0", parse_float=lambda t, r=result: r)
                self.assertNotIsInstance(cm.exception, TOMLDecodeError)

    def test_converter_result_not_dict_list_allowed(self):
        self.assertEqual(loads("a = 1.5", parse_float=lambda t: None), {"a": None})
        self.assertEqual(loads("a = 1.5", parse_float=lambda t: "x"), {"a": "x"})

    def test_converter_only_for_floats(self):
        calls = []
        loads("a = 1\nb = 1979-05-27\nc = 'x'\nd = true", parse_float=lambda t: calls.append(t))
        self.assertEqual(calls, [])


class LoadTests(unittest.TestCase):
    def test_binary_file(self):
        self.assertEqual(load(io.BytesIO(b'a = "\xc3\xa9"\r\nb = 1')),
                         {"a": "\u00e9", "b": 1})
        self.assertEqual(load(io.BytesIO(b"")), {})

    def test_text_mode_refused(self):
        with self.assertRaises(TypeError) as cm:
            load(io.StringIO("a = 1"))
        self.assertNotIsInstance(cm.exception, TOMLDecodeError)

    def test_invalid_document_in_file(self):
        with self.assertRaises(TOMLDecodeError) as cm:
            load(io.BytesIO(b"a = 1\nb = "))
        self.assertIsInstance(cm.exception.doc, str)
        self.assertEqual(cm.exception.lineno, 2)

    def test_load_parse_float(self):
        self.assertEqual(load(io.BytesIO(b"a = 1.5"), parse_float=lambda t: t), {"a": "1.5"})

    def test_file_objects_on_disk(self):
        import os
        import tempfile

        fd, path = tempfile.mkstemp(suffix=".toml")
        os.close(fd)
        try:
            with open(path, "wb") as fh:
                fh.write(b"x = [1, 2]")
            with open(path, "rb") as fh:
                self.assertEqual(load(fh), {"x": [1, 2]})
        finally:
            os.remove(path)


class TypeErrorTests(unittest.TestCase):
    def test_wrong_input_types(self):
        for value in [b"a = 1", 1, True, None, io.BytesIO(b"a = 1"), ["a = 1"]]:
            with self.subTest(value=value):
                with self.assertRaises(TypeError) as cm:
                    loads(value)
                self.assertNotIsInstance(cm.exception, TOMLDecodeError)


class ErrorLocationTests(unittest.TestCase):
    def test_location_fields(self):
        err = bad("a = 1\nb = @")
        self.assertIsInstance(err, ValueError)
        self.assertEqual(err.pos, 10)
        self.assertEqual(err.lineno, 2)
        self.assertEqual(err.colno, 5)
        self.assertEqual(err.doc, "a = 1\nb = @")
        self.assertIsInstance(err.msg, str)
        self.assertIn("2", str(err))
        self.assertIn("5", str(err))

    def test_crlf_location_maps_to_original(self):
        doc = "a = 1\r\nb = @"
        err = bad(doc)
        self.assertEqual(err.doc, doc)
        self.assertEqual(doc[err.pos], "@")
        self.assertEqual(err.lineno, 2)
        self.assertEqual(err.colno, 5)

    def test_end_of_document(self):
        err = bad("a = [1, 2")
        self.assertEqual(err.pos, len("a = [1, 2"))
        self.assertIn("end of document", str(err))

    def test_constructed_error(self):
        err = TOMLDecodeError("oops", "ab\ncd", 4)
        self.assertEqual(err.msg, "oops")
        self.assertEqual(err.doc, "ab\ncd")
        self.assertEqual(err.pos, 4)
        self.assertEqual(err.lineno, 2)
        self.assertEqual(err.colno, 2)
        self.assertIsInstance(err, ValueError)
        self.assertNotIsInstance(err, (TypeError, RecursionError))
        self.assertIn("oops", str(err))
        again = pickle.loads(pickle.dumps(err))
        self.assertEqual((again.msg, again.doc, again.pos), ("oops", "ab\ncd", 4))

    def test_no_mapping_on_failure(self):
        with self.assertRaises(TOMLDecodeError):
            loads("a = 1\nb = [")

    def test_deep_nesting_is_decode_error(self):
        with self.assertRaises(TOMLDecodeError):
            loads("a = " + "[" * 100000 + "]" * 100000)


class ExportTests(unittest.TestCase):
    def test_exports(self):
        self.assertTrue(issubclass(TOMLDecodeError, ValueError))
        self.assertIs(tomlparse.loads, loads)
        self.assertIs(tomlparse.load, load)
        self.assertIs(tomlparse.TOMLDecodeError, TOMLDecodeError)
        self.assertFalse(issubclass(TOMLDecodeError, TypeError))
        self.assertFalse(issubclass(TOMLDecodeError, RecursionError))


if __name__ == "__main__":
    unittest.main()
