"""Tomlparse: a pure-Python parser for TOML v1.1.0.

Public names: ``loads``, ``load``, ``TOMLDecodeError``.
"""

from ._api import load, loads
from ._errors import TOMLDecodeError

__all__ = ["loads", "load", "TOMLDecodeError"]
__version__ = "2.4.0"
