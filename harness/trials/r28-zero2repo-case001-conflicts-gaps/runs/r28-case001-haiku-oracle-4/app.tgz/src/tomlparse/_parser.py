"""TOML v1.1.0 grammar and document builder.

The parser is a single-pass recursive-descent reader over the document text.
Every position it reports is an index into the original text, so CRLF input
reports the same offsets the caller sees.
"""

import datetime as _dt
import re

from ._errors import TOMLDecodeError

# Table state, keyed by id(dict). A dict's state decides which later statements
# may touch it.
_HEADER = "header"  # defined by a [table] or [[array]] header
_IMPLICIT = "implicit"  # created as a missing parent of a header
_DOTTED = "dotted"  # created by dotted keys in a key/value pair
_INLINE = "inline"  # an inline table; frozen once written

_MISSING = object()

_BARE_KEY_RE = re.compile(r"[A-Za-z0-9_-]+")

# Date and time. Digits are [0-9], never \d, which matches other Unicode digits.
_DATETIME_RE = re.compile(
    r"(?P<y>[0-9]{4})-(?P<mo>[0-9]{2})-(?P<d>[0-9]{2})"
    r"(?:[Tt ](?P<H>[0-9]{2}):(?P<M>[0-9]{2})"
    r"(?::(?P<S>[0-9]{2})(?:\.(?P<F>[0-9]+))?)?"
    r"(?P<off>[Zz]|(?P<osign>[+-])(?P<oh>[0-9]{2}):(?P<om>[0-9]{2}))?)?"
)
_TIME_RE = re.compile(
    r"(?P<H>[0-9]{2}):(?P<M>[0-9]{2})(?::(?P<S>[0-9]{2})(?:\.(?P<F>[0-9]+))?)?"
)

_HEX_RE = re.compile(r"0x[0-9A-Fa-f]+(?:_[0-9A-Fa-f]+)*")
_OCT_RE = re.compile(r"0o[0-7]+(?:_[0-7]+)*")
_BIN_RE = re.compile(r"0b[01]+(?:_[01]+)*")
_INT_RE = re.compile(r"[+-]?(?:0|[1-9](?:_?[0-9])*)")
_FLOAT_RE = re.compile(
    r"[+-]?(?:0|[1-9](?:_?[0-9])*)"
    r"(?:\.[0-9](?:_?[0-9])*(?:[eE][+-]?[0-9](?:_?[0-9])*)?"
    r"|[eE][+-]?[0-9](?:_?[0-9])*)"
)
_SPECIAL_FLOAT_RE = re.compile(r"[+-]?(?:inf|nan)")

# Runs of characters that need no per-character handling in a string.
_BASIC_RUN_RE = re.compile(r'[^"\\\x00-\x08\x0a-\x1f\x7f]+')
_LITERAL_RUN_RE = re.compile(r"[^'\x00-\x08\x0a-\x1f\x7f]+")

_SIMPLE_ESCAPES = {
    "b": "\b",
    "t": "\t",
    "n": "\n",
    "f": "\f",
    "r": "\r",
    "e": "\x1b",
    '"': '"',
    "\\": "\\",
}
_HEX_ESCAPE_WIDTH = {"x": 2, "u": 4, "U": 8}
_HEX_DIGITS = frozenset("0123456789abcdefABCDEF")
_END_CHARS = " \t\r\n#,]}"


def _bad_ctrl(c):
    """True for control characters that TOML forbids; tab is allowed."""
    return (c < " " and c != "\t") or c == "\x7f"


def _split_fraction(frac):
    """Microseconds from a fraction's digits: first six, padded, truncated."""
    if not frac:
        return 0
    return int((frac + "000000")[:6])


class _Parser:
    def __init__(self, doc, parse_float):
        self.s = doc
        self.n = len(doc)
        self.i = 0
        self.parse_float = parse_float
        self.states = {}
        self.aot = set()  # ids of lists that are arrays of tables

    # ----- helpers -------------------------------------------------------

    def error(self, msg, pos=None):
        raise TOMLDecodeError(msg, self.s, self.i if pos is None else pos)

    def skip_ws(self):
        s, n, i = self.s, self.n, self.i
        while i < n and s[i] in " \t":
            i += 1
        self.i = i

    def skip_blank(self):
        """Skip spaces, tabs, line endings and comments (inside arrays and inline tables)."""
        s, n = self.s, self.n
        i = self.i
        while i < n:
            c = s[i]
            if c == " " or c == "\t" or c == "\n":
                i += 1
            elif c == "\r" and s.startswith("\n", i + 1):
                i += 2
            elif c == "#":
                self.i = i
                self.comment()
                i = self.i
            else:
                break
        self.i = i

    def comment(self):
        # spec: N-000107 N-000108 N-000109
        s, n = self.s, self.n
        i = self.i + 1
        while i < n:
            c = s[i]
            if c == "\n":
                break
            if c == "\r":
                if s.startswith("\n", i + 1):
                    break
                self.error("carriage return without line feed", i)
            if _bad_ctrl(c):
                self.error("control character in comment", i)
            i += 1
        self.i = i

    def expect_eol(self):
        self.skip_ws()
        if self.i < self.n and self.s[self.i] == "#":
            self.comment()
        if self.i >= self.n:
            return
        c = self.s[self.i]
        if c == "\n":
            self.i += 1
        elif c == "\r" and self.s.startswith("\n", self.i + 1):
            self.i += 2
        else:
            self.error("expected end of line")

    def end_at(self, j):
        return j >= self.n or self.s[j] in _END_CHARS

    def check_end(self, j):
        if not self.end_at(j):
            self.error("unexpected character after value", j)

    # ----- document ------------------------------------------------------

    def parse(self):
        root = {}
        current = root
        while True:
            self.skip_blank()
            if self.i >= self.n:
                break
            if self.s[self.i] == "[":
                if self.s.startswith("[[", self.i):
                    current = self.array_table_header(root)
                else:
                    current = self.table_header(root)
            else:
                self.key_value(current)
                self.expect_eol()
        return root

    # ----- keys ----------------------------------------------------------

    def key(self):
        parts = [self.key_part()]
        while True:
            self.skip_ws()
            if self.i < self.n and self.s[self.i] == ".":
                self.i += 1
                self.skip_ws()
                parts.append(self.key_part())
            else:
                return parts

    def key_part(self):
        # spec: N-000085 N-000086 N-000087 N-000089 N-000090 N-000091 N-000092
        s, i = self.s, self.i
        c = s[i : i + 1]
        if c == '"':
            return self.basic_string()
        if c == "'":
            return self.literal_string()
        m = _BARE_KEY_RE.match(s, i)
        if m is not None:
            self.i = m.end()
            return m.group()
        self.error("expected key")

    def key_value(self, table):
        key_pos = self.i
        parts = self.key()
        if self.i >= self.n or self.s[self.i] != "=":
            self.error("expected '=' after key")
        self.i += 1
        self.skip_ws()
        value = self.value()
        self.insert(table, parts, value, key_pos)

    def insert(self, table, parts, value, key_pos):
        # spec: N-000093 N-000094 N-000095 N-000113 N-000114 N-000115 N-000116
        # spec: N-000118 N-000120 N-000121
        cur = table
        for part in parts[:-1]:
            nxt = cur.get(part, _MISSING)
            if nxt is _MISSING:
                nxt = {}
                cur[part] = nxt
                self.states[id(nxt)] = _DOTTED
            elif not (isinstance(nxt, dict) and self.states.get(id(nxt)) == _DOTTED):
                self.error("key path conflicts with an existing value", key_pos)
            cur = nxt
        last = parts[-1]
        if last in cur:
            self.error("duplicate key %r" % (last,), key_pos)
        cur[last] = value

    # ----- headers -------------------------------------------------------

    def step(self, cur, part):
        """Move into the table named ``part`` while walking a header path."""
        # spec: N-000096 N-000097 N-000098 N-000099 N-000100 N-000101 N-000102
        nxt = cur.get(part, _MISSING)
        if nxt is _MISSING:
            new = {}
            cur[part] = new
            self.states[id(new)] = _IMPLICIT
            return new
        if isinstance(nxt, list):
            if id(nxt) in self.aot and nxt:
                return nxt[-1]
            self.error("header path goes through a static array")
        if isinstance(nxt, dict) and self.states.get(id(nxt)) != _INLINE:
            return nxt
        self.error("header path goes through a value that is not a table")

    def table_header(self, root):
        self.i += 1
        self.skip_ws()
        parts = self.key()
        self.skip_ws()
        if self.i >= self.n or self.s[self.i] != "]":
            self.error("expected ']' to close table header")
        self.i += 1
        self.expect_eol()
        cur = root
        for part in parts[:-1]:
            cur = self.step(cur, part)
        last = parts[-1]
        existing = cur.get(last, _MISSING)
        if existing is _MISSING:
            new = {}
            cur[last] = new
            self.states[id(new)] = _HEADER
            return new
        if isinstance(existing, dict) and self.states.get(id(existing)) == _IMPLICIT:
            self.states[id(existing)] = _HEADER
            return existing
        self.error("table %r is already defined" % (last,))

    def array_table_header(self, root):
        # spec: N-000099 N-000100 N-000101 N-000102
        self.i += 2
        self.skip_ws()
        parts = self.key()
        self.skip_ws()
        if not self.s.startswith("]]", self.i):
            self.error("expected ']]' to close array of tables header")
        self.i += 2
        self.expect_eol()
        cur = root
        for part in parts[:-1]:
            cur = self.step(cur, part)
        last = parts[-1]
        arr = cur.get(last, _MISSING)
        if arr is _MISSING:
            arr = []
            self.aot.add(id(arr))
            cur[last] = arr
        elif not (isinstance(arr, list) and id(arr) in self.aot):
            self.error("%r is not an array of tables" % (last,))
        new = {}
        self.states[id(new)] = _HEADER
        arr.append(new)
        return new

    # ----- values --------------------------------------------------------

    def value(self):
        s, i = self.s, self.i
        if i >= self.n:
            self.error("expected a value")
        c = s[i]
        if c == '"':
            if s.startswith('"""', i):
                return self.multiline_string('"', True)
            return self.basic_string()
        if c == "'":
            if s.startswith("'''", i):
                return self.multiline_string("'", False)
            return self.literal_string()
        if c == "[":
            return self.array()
        if c == "{":
            return self.inline_table()
        if s.startswith("true", i) and self.end_at(i + 4):
            self.i = i + 4
            return True
        if s.startswith("false", i) and self.end_at(i + 5):
            self.i = i + 5
            return False

        m = _DATETIME_RE.match(s, i)
        if m is not None:
            self.check_end(m.end())
            self.i = m.end()
            return self.make_datetime(m)
        m = _TIME_RE.match(s, i)
        if m is not None:
            self.check_end(m.end())
            self.i = m.end()
            return self.make_time(m)

        for pattern, base in ((_HEX_RE, 16), (_OCT_RE, 8), (_BIN_RE, 2)):
            m = pattern.match(s, i)
            if m is not None:
                self.check_end(m.end())
                self.i = m.end()
                return int(m.group().replace("_", ""), base)

        m = _SPECIAL_FLOAT_RE.match(s, i) or _FLOAT_RE.match(s, i)
        if m is not None:
            self.check_end(m.end())
            self.i = m.end()
            return self.float_value(m.group())

        m = _INT_RE.match(s, i)
        if m is not None:
            self.check_end(m.end())
            self.i = m.end()
            return int(m.group())

        self.error("invalid value")

    def float_value(self, token):
        # spec: N-000275 N-000276 N-000277 N-000220 N-000223 N-000224 N-000225
        # spec: N-000226 N-000227 N-000228 N-000229 N-000230 N-000231 N-000232
        # spec: N-000233 N-000296 N-000148 N-000149 N-000150
        if self.parse_float is float:
            return float(token.replace("_", ""))
        result = self.parse_float(token)
        if isinstance(result, (dict, list)):
            raise ValueError(
                "parse_float returned a %s, which is not allowed"
                % type(result).__name__
            )
        return result

    def make_datetime(self, m):
        # spec: N-000151 N-000152 N-000153 N-000154 N-000155 N-000156 N-000157
        # spec: N-000158 N-000159 N-000179 N-000180 N-000288 N-000289 N-000290
        y, mo, d = int(m.group("y")), int(m.group("mo")), int(m.group("d"))
        try:
            day = _dt.date(y, mo, d)
        except ValueError:
            self.error("invalid calendar date", m.start())
        if m.group("H") is None:
            return day
        hour, minute = int(m.group("H")), int(m.group("M"))
        second = int(m.group("S")) if m.group("S") else 0
        if hour > 23 or minute > 59 or second > 59:
            self.error("time out of range", m.start())
        micro = _split_fraction(m.group("F"))
        off = m.group("off")
        if off is None:
            return _dt.datetime(y, mo, d, hour, minute, second, micro)
        if off in ("Z", "z"):
            tz = _dt.timezone.utc
        else:
            oh, om = int(m.group("oh")), int(m.group("om"))
            if oh > 23 or om > 59:
                self.error("UTC offset out of range", m.start())
            delta = _dt.timedelta(hours=oh, minutes=om)
            if m.group("osign") == "-":
                delta = -delta
            tz = _dt.timezone(delta)
        return _dt.datetime(y, mo, d, hour, minute, second, micro, tzinfo=tz)

    def make_time(self, m):
        hour, minute = int(m.group("H")), int(m.group("M"))
        second = int(m.group("S")) if m.group("S") else 0
        if hour > 23 or minute > 59 or second > 59:
            self.error("time out of range", m.start())
        return _dt.time(hour, minute, second, _split_fraction(m.group("F")))

    # ----- strings -------------------------------------------------------

    def escape(self):
        # spec: N-000137 N-000138 N-000139 N-000140 N-000141 N-000142 N-000143
        # spec: N-000146 N-000174 N-000175 N-000176 N-000177
        s = self.s
        at = self.i
        j = at + 1
        c = s[j : j + 1]
        if c in _SIMPLE_ESCAPES:
            self.i = j + 1
            return _SIMPLE_ESCAPES[c]
        width = _HEX_ESCAPE_WIDTH.get(c)
        if width is not None:
            digits = s[j + 1 : j + 1 + width]
            if len(digits) != width or any(d not in _HEX_DIGITS for d in digits):
                self.error("invalid hexadecimal escape", at)
            code = int(digits, 16)
            if code > 0x10FFFF or 0xD800 <= code <= 0xDFFF:
                self.error("escape is not a Unicode scalar value", at)
            self.i = j + 1 + width
            return chr(code)
        self.error("invalid escape sequence", at)

    def basic_string(self):
        s, n = self.s, self.n
        start = self.i
        i = start + 1
        buf = []
        while True:
            m = _BASIC_RUN_RE.match(s, i)
            if m is not None:
                buf.append(m.group())
                i = m.end()
            if i >= n:
                self.error("unterminated string", start)
            c = s[i]
            if c == '"':
                self.i = i + 1
                return "".join(buf)
            if c == "\\":
                self.i = i
                buf.append(self.escape())
                i = self.i
                continue
            self.error("control character in string", i)

    def literal_string(self):
        s, n = self.s, self.n
        start = self.i
        i = start + 1
        buf = []
        while True:
            m = _LITERAL_RUN_RE.match(s, i)
            if m is not None:
                buf.append(m.group())
                i = m.end()
            if i >= n:
                self.error("unterminated string", start)
            c = s[i]
            if c == "'":
                self.i = i + 1
                return "".join(buf)
            self.error("control character in string", i)

    def multiline_string(self, q, escapes):
        # spec: N-000127 N-000128 N-000129 N-000130 N-000131 N-000132 N-000133
        # spec: N-000134 N-000135 N-000136 N-000178 N-000186 N-000111 N-000112
        s, n = self.s, self.n
        start = self.i
        i = start + 3
        # A newline right after the opening delimiter is trimmed.
        if s.startswith("\n", i):
            i += 1
        elif s.startswith("\r\n", i):
            i += 2
        buf = []
        while True:
            if i >= n:
                self.error("unterminated multiline string", start)
            c = s[i]
            if c == q:
                run = 1
                while i + run < n and s[i + run] == q:
                    run += 1
                if run >= 3:
                    if run > 5:
                        self.error("too many quotes in multiline string", i)
                    buf.append(q * (run - 3))
                    self.i = i + run
                    return "".join(buf)
                buf.append(q * run)
                i += run
                continue
            if c == "\\" and escapes:
                j = i + 1
                while j < n and s[j] in " \t":
                    j += 1
                if j < n and (s[j] == "\n" or s.startswith("\r\n", j)):
                    # Line-ending backslash: drop the line ending and the
                    # whitespace that follows, up to the next non-blank.
                    i = j
                    while i < n:
                        ch = s[i]
                        if ch in " \t\n":
                            i += 1
                        elif s.startswith("\r\n", i):
                            i += 2
                        else:
                            break
                    continue
                self.i = i
                buf.append(self.escape())
                i = self.i
                continue
            if c == "\n":
                buf.append("\n")
                i += 1
                continue
            if c == "\r":
                if s.startswith("\n", i + 1):
                    # CRLF is one line feed.
                    buf.append("\n")
                    i += 2
                    continue
                self.error("carriage return without line feed", i)
            if _bad_ctrl(c):
                self.error("control character in string", i)
            buf.append(c)
            i += 1

    # ----- arrays and inline tables ---------------------------------------

    def array(self):
        # spec: N-000105 N-000106 N-000281 N-000282
        self.i += 1
        items = []
        while True:
            self.skip_blank()
            if self.i >= self.n:
                self.error("unterminated array")
            if self.s[self.i] == "]":
                self.i += 1
                return items
            items.append(self.value())
            self.skip_blank()
            if self.i >= self.n:
                self.error("unterminated array")
            c = self.s[self.i]
            if c == ",":
                self.i += 1
            elif c == "]":
                self.i += 1
                return items
            else:
                self.error("expected ',' or ']' in array")

    def inline_table(self):
        # spec: N-000103 N-000104 N-000122
        self.i += 1
        table = {}
        self.states[id(table)] = _INLINE
        while True:
            self.skip_blank()
            if self.s[self.i : self.i + 1] == "}":
                self.i += 1
                return table
            self.key_value(table)
            self.skip_blank()
            c = self.s[self.i : self.i + 1]
            if c == "}":
                self.i += 1
                return table
            if c == ",":
                self.i += 1
                continue
            self.error("expected ',' or '}' in inline table")


def _parse(doc, parse_float):
    return _Parser(doc, parse_float).parse()
