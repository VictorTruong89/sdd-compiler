"""The public parse entries: ``loads`` (text) and ``load`` (binary file)."""

# spec: N-000274 N-000275 N-000276 N-000277 N-000278 N-000293 N-000294 N-000295
# spec: N-000296 N-000297 N-000298 N-000299 N-000300 N-000301 N-000302 N-000303
# spec: N-000304 N-000305 N-000306 N-000181 N-000182 N-000183 N-000184 N-000185
# spec: N-000186 N-000187 N-000188 N-000189 N-000190 N-000191 N-000192 N-000193
# spec: N-000194 N-000195 N-000196 N-000197 N-000198 N-000199 N-000200 N-000201
# spec: N-000202 N-000213 N-000214 N-000215 N-000216 N-000077 N-000078 N-000079
# spec: N-000080 N-000081 N-000082 N-000083 N-000084 N-000123 N-000162 N-000163
# spec: N-000164 N-000165 N-000166 N-000167 N-000168 N-000169 N-000170 N-000171
# spec: N-000172 N-000173 N-000174 N-000220 N-000221 N-000222 N-000232

from ._errors import TOMLDecodeError
from ._parser import _parse


def loads(s, *, parse_float=float):
    """Parse a TOML v1.1.0 document given as a text string.

    Returns a dict. Raises TypeError if ``s`` is not a str, and TOMLDecodeError
    if the document is invalid. A converter result that is a dict or list
    raises ValueError.
    """
    if not isinstance(s, str):
        raise TypeError(
            "loads() expects a str, not %s" % type(s).__name__
        )
    return _parse(s, parse_float)


def load(fp, *, parse_float=float):
    """Parse a TOML v1.1.0 document read from a binary file object.

    ``fp`` must be opened for binary reading. The bytes are decoded as UTF-8
    and parsed the same way as ``loads``. A text-mode file raises TypeError.
    """
    read = getattr(fp, "read", None)
    if read is None:
        raise TypeError("load() expects a binary file object with a read() method")
    data = read()
    if not isinstance(data, (bytes, bytearray)):
        raise TypeError(
            "load() expects a file opened in binary mode, not %s"
            % type(data).__name__
        )
    data = bytes(data)
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        # Locate the first byte that is not valid UTF-8, as a character offset
        # into the text that replaces the invalid bytes.
        prefix = data[: exc.start].decode("utf-8", "ignore")
        replaced = data.decode("utf-8", "replace")
        raise TOMLDecodeError("invalid UTF-8 in document", replaced, len(prefix))
    return loads(text, parse_float=parse_float)
