"""The decode error raised for invalid TOML."""

# spec: N-000307 N-000308 N-000309 N-000310 N-000311 N-000312 N-000313 N-000314
# spec: N-000315 N-000316 N-000317 N-000318 N-000319 N-000320 N-000321 N-000322
# spec: N-000323 N-000203 N-000204 N-000205 N-000206 N-000207 N-000210 N-000211
# spec: N-000212 N-000217 N-000218 N-000219


class TOMLDecodeError(ValueError):
    """Raised when a document is not valid TOML v1.1.0.

    Constructed as ``TOMLDecodeError(msg, doc, pos)``. ``msg`` is the unformatted
    reason, ``doc`` the document text, and ``pos`` a 0-based character offset
    into ``doc``. ``lineno`` (1-based) and ``colno`` (1-based) are derived from
    ``pos``.
    """

    def __init__(self, msg, doc, pos):
        ValueError.__init__(self, msg, doc, pos)
        self.msg = msg
        self.doc = doc
        self.pos = pos
        # Line is 1 + number of line feeds before pos.
        self.lineno = doc.count("\n", 0, pos) + 1
        # Column is 1 + characters between the last line feed before pos (or the
        # start of the document) and pos. rfind returns -1 when there is none.
        self.colno = pos - doc.rfind("\n", 0, pos)

    def __str__(self):
        if self.pos >= len(self.doc):
            return "%s (at end of document, line %d, column %d)" % (
                self.msg,
                self.lineno,
                self.colno,
            )
        return "%s (at line %d, column %d)" % (self.msg, self.lineno, self.colno)
