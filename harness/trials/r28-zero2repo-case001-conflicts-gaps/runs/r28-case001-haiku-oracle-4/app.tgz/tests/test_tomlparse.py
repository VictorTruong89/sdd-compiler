"""Tests for tomlparse. Run from /app with PYTHONPATH=src (pytest or unittest)."""

import copy
import datetime as dt
import io
import pickle
import unittest

from tomlparse import TOMLDecodeError, load, loads


class TestFP01Structure(unittest.TestCase):
    # spec: N-000082 N-000083 N-000084 N-000085 N-000086 N-000087 N-000088
    def test_empty_and_comment_only_documents(self):
        self.assertEqual(loads(""), {})
        self.assertEqual(loads("   \t\n"), {})
        self.assertEqual(loads("# only a comment"), {})
        self.assertEqual(loads("# only a comment\n"), {})

    def test_root_and_table_pairs(self):
        doc = loads("a = 1\n[t]\nb = 2\n[t.u]\nc = 3\n")
        self.assertEqual(doc, {"a": 1, "t": {"b": 2, "u": {"c": 3}}})

    def test_keys_are_always_strings(self):
        doc = loads("1 = 1\ntrue = 2\ninf = 3\nnan = 4\n1979-05-27 = 5\n")
        self.assertEqual(doc, {"1": 1, "true": 2, "inf": 3, "nan": 4, "1979-05-27": 5})
        for key in doc:
            self.assertIsInstance(key, str)

    def test_case_sensitive_keys(self):
        self.assertEqual(loads("a = 1\nA = 2\n"), {"a": 1, "A": 2})

    # spec: N-000089 N-000090 N-000091 N-000092
    def test_quoted_keys(self):
        doc = loads('"a.b" = 1\n\'#x y\' = 2\n"é" = 3\n"" = 4\n')
        self.assertEqual(doc, {"a.b": 1, "#x y": 2, "é": 3, "": 4})

    def test_basic_quoted_key_escapes_literal_key_does_not(self):
        doc = loads('"a\\tb" = 1\n\'a\\tb\' = 2\n')
        self.assertEqual(doc, {"a\tb": 1, "a\\tb": 2})

    # spec: N-000093 N-000094 N-000095
    def test_dotted_keys_and_whitespace(self):
        doc = loads("a . b  .  c = 1\na.d = 2\n")
        self.assertEqual(doc, {"a": {"b": {"c": 1}, "d": 2}})

    # spec: N-000096 N-000097 N-000098
    def test_header_creates_parents_and_later_subtable_after_dotted_keys(self):
        doc = loads("[a.b.c]\nx = 1\n[a]\ny = 2\n")
        self.assertEqual(doc, {"a": {"b": {"c": {"x": 1}}, "y": 2}})
        doc = loads("[fruit]\napple.color = 'red'\n[fruit.apple.texture]\nsmooth = true\n")
        self.assertEqual(doc, {"fruit": {"apple": {"color": "red", "texture": {"smooth": True}}}})

    # spec: N-000099 N-000100 N-000101 N-000102
    def test_arrays_of_tables(self):
        doc = loads("[[p]]\nn = 1\n[[p.s]]\nm = 1\n[[p.s]]\nm = 2\n[[p]]\nn = 3\n")
        self.assertEqual(
            doc,
            {"p": [{"n": 1, "s": [{"m": 1}, {"m": 2}]}, {"n": 3}]},
        )

    def test_implied_parent_of_array_of_tables_is_a_mapping(self):
        doc = loads("[[a.b]]\nx = 1\n[a]\ny = 2\n")
        self.assertEqual(doc, {"a": {"b": [{"x": 1}], "y": 2}})
        self.assertIsInstance(doc["a"], dict)

    # spec: N-000103 N-000104 N-000105 N-000106
    def test_inline_tables_and_arrays_multiline(self):
        doc = loads("t = {a = 1, b.c = 2,}\nu = {\n  x = 1, # c\n}\n")
        self.assertEqual(doc, {"t": {"a": 1, "b": {"c": 2}}, "u": {"x": 1}})
        doc = loads("arr = [\n  1, # one\n  'two',\n  [3],\n]\n")
        self.assertEqual(doc, {"arr": [1, "two", [3]]})
        self.assertEqual(loads("e = []\nf = {}\n"), {"e": [], "f": {}})

    # spec: N-000107 N-000108 N-000109 N-000110
    def test_comments_and_indentation(self):
        doc = loads("\t a = 1 # trailing é\n# comment = 2\n  [t] #c\n\tb=3#x\n")
        self.assertEqual(doc, {"a": 1, "t": {"b": 3}})

    # spec: N-000111 N-000112
    def test_crlf_is_one_line_feed(self):
        doc = loads('a = """x\r\ny\r\n"""\r\nb = 1\r\n')
        self.assertEqual(doc, {"a": "x\ny\n", "b": 1})

    # spec: N-000113 .. N-000122
    def test_structural_violations_are_refused(self):
        bad = [
            "a = 1\na = 2",  # duplicate key
            "[t]\n[t]",  # table defined twice
            "[t]\nx=1\n[t.x]",  # header onto a value
            "a.b = 1\n[a]",  # header reopens dotted table
            "[a]\nb.c = 1\n[a.b]",  # header onto dotted table
            "a = 1\n[a]",  # table replaces a value
            "a = 1\na.b = 2",  # dotted key through a value
            "a = {x = 1}\na.y = 2",  # adding to inline table
            "a = {x = 1}\n[a.y]",  # header through inline table
            "[[a]]\n[a]",  # table replaces array of tables
            "a = [1]\n[[a]]",  # array of tables replaces static array
            "[[a]]\nx = 1\n[a]\n",  # header reopens array
            "x = 1 y = 2",  # two pairs on one line
            "[t] x = 1",  # header shares line
            "= 1",  # no key
            "a =",  # no value
            "a\n",  # no value, no equals
            '"""k""" = 1',  # multiline string as key
            "[\"\"\"t\"\"\"]",  # multiline string as table name
            "[t\nx = 1",  # header not closed on its line
            "[[a]] \n[[a.b.c]",  # header not closed
        ]
        for doc in bad:
            with self.subTest(doc=doc):
                with self.assertRaises(TOMLDecodeError):
                    loads(doc)

    def test_extending_array_through_dotted_key_is_refused(self):
        with self.assertRaises(TOMLDecodeError):
            loads("[t]\n[[t.sub]]\nx = 1\n[t]\nsub.y = 2\n")
        with self.assertRaises(TOMLDecodeError):
            loads("a = [{x = 1}]\na.y = 2")

    def test_header_onto_dotted_table_is_refused_but_new_subtable_ok(self):
        with self.assertRaises(TOMLDecodeError):
            loads("[fruit]\napple.color = 'red'\n[fruit.apple]\n")
        with self.assertRaises(TOMLDecodeError):
            loads("[fruit]\napple.taste.sweet = true\n[fruit.apple.taste]\n")
        doc = loads("[fruit]\napple.color = 'red'\n[fruit.apple.taste]\nsweet = true\n")
        self.assertEqual(doc, {"fruit": {"apple": {"color": "red", "taste": {"sweet": True}}}})


class TestFP02Scalars(unittest.TestCase):
    # spec: N-000124 N-000125 N-000126
    def test_booleans(self):
        doc = loads("a = true\nb = false\n")
        self.assertIs(doc["a"], True)
        self.assertIs(doc["b"], False)
        for bad in ["a = True", "a = TRUE", "a = t"]:
            with self.subTest(bad=bad):
                with self.assertRaises(TOMLDecodeError):
                    loads(bad)

    # spec: N-000127 .. N-000136
    def test_strings(self):
        doc = loads(
            'basic = "a\\tb\\nc"\n'
            "literal = 'a\\tb'\n"
            'ml = """\nLine one\nLine two"""\n'
            "mll = '''\nraw \\n text'''\n"
        )
        self.assertEqual(doc["basic"], "a\tb\nc")
        self.assertEqual(doc["literal"], "a\\tb")
        self.assertEqual(doc["ml"], "Line one\nLine two")
        self.assertEqual(doc["mll"], "raw \\n text")

    def test_multiline_trims_line_ending_backslash(self):
        doc = loads('s = """one \\\n     two \\\n\n   three"""\n')
        self.assertEqual(doc["s"], "one two three")

    def test_multiline_quotes_before_closing_delimiter(self):
        doc = loads('a = """x""""\nb = """y"""""\nc = \'\'\'z\'\'\'\'\n')
        self.assertEqual(doc, {"a": 'x"', "b": 'y""', "c": "z'"})

    # spec: N-000137 .. N-000143
    def test_basic_escapes(self):
        doc = loads(
            r'a = "\b\t\n\f\r\e\"\\"' + "\n"
            r'b = "\x41é\U0001F600"' + "\n"
            r'c = "\x4Aé"' + "\n"
        )
        self.assertEqual(doc["a"], "\b\t\n\f\r\x1b\"\\")
        self.assertEqual(doc["b"], "Aé😀")
        self.assertEqual(doc["c"], "Jé")

    # spec: N-000174 .. N-000178
    def test_invalid_strings_are_refused(self):
        bad = [
            r'a = "\q"',  # unknown escape
            r'a = "\u12"',  # incomplete
            r'a = "\uD800"',  # surrogate
            r'a = "\U00110000"',  # out of range
            'a = "unclosed',
            'a = "tab\x01"',
            'a = """bad\rcr"""',
            'a = """line\\\n  \\x"""',
            "a = '''x''''''",
        ]
        for doc in bad:
            with self.subTest(doc=doc):
                with self.assertRaises(TOMLDecodeError):
                    loads(doc)

    # spec: N-000144 .. N-000147
    def test_integers(self):
        doc = loads(
            "a = 0\nb = +0\nc = -0\nd = 1_000\ne = -17\n"
            "f = 0xDEADbeef\ng = 0o755\nh = 0b1101_0110\n"
        )
        self.assertEqual(doc, {
            "a": 0, "b": 0, "c": 0, "d": 1000, "e": -17,
            "f": 0xDEADBEEF, "g": 0o755, "h": 0b11010110,
        })
        for value in doc.values():
            self.assertIs(type(value), int)

    def test_invalid_integers_are_refused(self):
        bad = ["a = 01", "a = 00", "a = 0X1", "a = 0xG", "a = +0x1", "a = 1__0",
               "a = _1", "a = 1_", "a = 0b102", "a = 0o8", "a = -0x1", "a = 0_1"]
        for doc in bad:
            with self.subTest(doc=doc):
                with self.assertRaises(TOMLDecodeError):
                    loads(doc)

    # spec: N-000148 .. N-000150
    def test_floats_default(self):
        doc = loads("a = 3.14\nb = -1e3\nc = 6.626e-34\nd = 1_0.0_1\n"
                    "e = inf\nf = +inf\ng = -inf\nh = nan\ni = +nan\nj = -nan\n")
        self.assertEqual(doc["a"], 3.14)
        self.assertEqual(doc["b"], -1000.0)
        self.assertEqual(doc["c"], 6.626e-34)
        self.assertEqual(doc["d"], 10.01)
        self.assertEqual(doc["e"], float("inf"))
        self.assertEqual(doc["g"], float("-inf"))
        import math
        self.assertTrue(math.isnan(doc["h"]))
        self.assertTrue(math.isnan(doc["j"]))
        for key in "abcdefghij":
            self.assertIs(type(doc[key]), float)

    def test_invalid_floats_are_refused(self):
        bad = ["a = .5", "a = 5.", "a = 01.5", "a = 1.e5", "a = 1e", "a = 1.5.2",
               "a = -.inf", "a = infinity", "a = nan_"]
        for doc in bad:
            with self.subTest(doc=doc):
                with self.assertRaises(TOMLDecodeError):
                    loads(doc)

    # spec: N-000151 .. N-000161
    def test_datetimes(self):
        doc = loads(
            "odt1 = 1979-05-27T07:32:00Z\n"
            "odt2 = 1979-05-27T00:32:00-07:00\n"
            "odt3 = 1979-05-27T00:32:00.999999+07:00\n"
            "odt4 = 1979-05-27 07:32:00z\n"
            "ldt = 1979-05-27T07:32:00\n"
            "ld = 1979-05-27\n"
            "lt = 07:32:00\n"
            "lt2 = 07:32\n"
        )
        self.assertEqual(doc["odt1"], dt.datetime(1979, 5, 27, 7, 32, tzinfo=dt.timezone.utc))
        self.assertEqual(doc["odt1"].utcoffset(), dt.timedelta(0))
        self.assertEqual(doc["odt2"].utcoffset(), dt.timedelta(hours=-7))
        self.assertEqual(doc["odt3"].utcoffset(), dt.timedelta(hours=7))
        self.assertEqual(doc["odt3"].microsecond, 999999)
        self.assertEqual(doc["odt4"].utcoffset(), dt.timedelta(0))
        self.assertIsNone(doc["ldt"].tzinfo)
        self.assertIs(type(doc["ld"]), dt.date)
        self.assertEqual(doc["lt"], dt.time(7, 32, 0))
        self.assertIsNone(doc["lt"].tzinfo)
        self.assertEqual(doc["lt2"], dt.time(7, 32, 0))

    def test_datetime_fraction_truncated_to_microseconds(self):
        doc = loads("a = 07:32:00.1234569\nb = 07:32:00.5\nc = 07:32:00.0000001\n")
        self.assertEqual(doc["a"].microsecond, 123456)
        self.assertEqual(doc["b"].microsecond, 500000)
        self.assertEqual(doc["c"].microsecond, 0)

    def test_leap_day_and_invalid_dates(self):
        self.assertEqual(loads("a = 2024-02-29")["a"], dt.date(2024, 2, 29))
        for bad in ["a = 2023-02-29", "a = 2023-13-01", "a = 07:60:00",
                    "a = 24:00:00", "a = 1979-05-27T07:32:00+24:00"]:
            with self.subTest(bad=bad):
                with self.assertRaises(TOMLDecodeError):
                    loads(bad)

    def test_datetimes_copy_and_compare(self):
        doc = loads("a = 1979-05-27T07:32:00Z\n")
        self.assertEqual(copy.deepcopy(doc), doc)
        self.assertEqual(pickle.loads(pickle.dumps(doc)), doc)


class TestFP04Errors(unittest.TestCase):
    # spec: N-000203 .. N-000212
    def test_decode_error_location(self):
        with self.assertRaises(TOMLDecodeError) as cm:
            loads("a = 1\nb = @\n")
        err = cm.exception
        self.assertIsInstance(err, ValueError)
        self.assertEqual(err.doc, "a = 1\nb = @\n")
        self.assertEqual(err.pos, err.doc.index("@"))
        self.assertEqual(err.lineno, 2)
        self.assertEqual(err.colno, 5)
        self.assertIn("line 2", str(err))
        self.assertIn("column 5", str(err))

    def test_constructed_error_carries_values(self):
        err = TOMLDecodeError("reason", "x = 1\n\ny", 8)
        self.assertEqual(err.msg, "reason")
        self.assertEqual(err.doc, "x = 1\n\ny")
        self.assertEqual(err.pos, 8)
        self.assertEqual(err.lineno, 3)
        self.assertEqual(err.colno, 2)
        self.assertIn("reason", str(err))
        self.assertIn("line 3", str(err))

    def test_end_of_document_position(self):
        err = TOMLDecodeError("reason", "ab", 2)
        self.assertEqual((err.lineno, err.colno), (1, 3))
        self.assertIn("end of document", str(err))

    def test_first_line_column(self):
        err = TOMLDecodeError("reason", "abc", 0)
        self.assertEqual((err.lineno, err.colno), (1, 1))

    def test_not_a_type_or_recursion_error(self):
        self.assertFalse(issubclass(TOMLDecodeError, TypeError))
        self.assertFalse(issubclass(TOMLDecodeError, RecursionError))

    def test_wrong_python_type_is_type_error(self):
        for value in (b"a = 1", 1, True, None, io.StringIO("a = 1")):
            with self.subTest(value=value):
                with self.assertRaises(TypeError) as cm:
                    loads(value)
                self.assertNotIsInstance(cm.exception, TOMLDecodeError)

    def test_no_mapping_returned_on_failure(self):
        with self.assertRaises(TOMLDecodeError):
            loads("a = 1\nb = ")


class TestFP03BinaryFile(unittest.TestCase):
    # spec: N-000181 .. N-000189
    def test_binary_file_and_buffer(self):
        data = 'a = "é"\n\n[t]\nb = 1\r\n'.encode("utf-8")
        self.assertEqual(load(io.BytesIO(data)), loads('a = "é"\n\n[t]\nb = 1\r\n'))

    def test_empty_file_is_empty_mapping(self):
        self.assertEqual(load(io.BytesIO(b"")), {})

    def test_text_mode_file_is_type_error(self):
        with self.assertRaises(TypeError) as cm:
            load(io.StringIO("a = 1"))
        self.assertNotIsInstance(cm.exception, TOMLDecodeError)
        with self.assertRaises(TypeError):
            load(io.StringIO(""))

    def test_on_disk_binary_file(self):
        import tempfile, os
        fd, path = tempfile.mkstemp(suffix=".toml")
        try:
            with os.fdopen(fd, "wb") as fh:
                fh.write(b"x = [1, 2]\n")
            with open(path, "rb") as fh:
                self.assertEqual(load(fh), {"x": [1, 2]})
            with open(path, "r", encoding="utf-8") as fh:
                with self.assertRaises(TypeError):
                    load(fh)
        finally:
            os.remove(path)

    def test_invalid_toml_in_file_reports_decoded_text(self):
        with self.assertRaises(TOMLDecodeError) as cm:
            load(io.BytesIO("a = 1\nb = é\n".encode("utf-8")))
        self.assertEqual(cm.exception.doc, "a = 1\nb = é\n")
        self.assertEqual(cm.exception.lineno, 2)

    def test_invalid_utf8_is_decode_error(self):
        with self.assertRaises(TOMLDecodeError) as cm:
            load(io.BytesIO(b"a = 1\nb = \xff\n"))
        self.assertEqual(cm.exception.lineno, 2)


class TestFP05Converter(unittest.TestCase):
    # spec: N-000220 .. N-000231
    def test_converter_receives_float_text_everywhere(self):
        seen = []

        def conv(text):
            seen.append(text)
            return ("F", text)

        doc = loads(
            "a = 1_0.5e+1\nb = 7\nc = 'x'\n[t]\nd = [-inf, +nan]\n"
            "e = {f = 2.0}\n",
            parse_float=conv,
        )
        self.assertEqual(doc["a"], ("F", "1_0.5e+1"))
        self.assertEqual(doc["b"], 7)
        self.assertEqual(doc["c"], "x")
        self.assertEqual(doc["t"]["d"], [("F", "-inf"), ("F", "+nan")])
        self.assertEqual(doc["t"]["e"], {"f": ("F", "2.0")})
        self.assertEqual(seen, ["1_0.5e+1", "-inf", "+nan", "2.0"])

    def test_converter_result_bound_as_returned(self):
        self.assertEqual(loads("a = 1.5", parse_float=lambda t: "text")["a"], "text")
        self.assertEqual(loads("a = 1.5", parse_float=lambda t: None)["a"], None)

    # spec: N-000232 N-000233 N-000199
    def test_dict_or_list_result_is_value_error(self):
        for result in ({}, [], {"k": 1}, [1]):
            with self.subTest(result=result):
                with self.assertRaises(ValueError) as cm:
                    loads("a = 1.5", parse_float=lambda t, r=result: r)
                self.assertNotIsInstance(cm.exception, TOMLDecodeError)

    def test_subclass_result_is_refused(self):
        class D(dict):
            pass

        class L(list):
            pass

        for result in (D(), L()):
            with self.subTest(result=type(result).__name__):
                with self.assertRaises(ValueError) as cm:
                    loads("a = 1.5", parse_float=lambda t, r=result: r)
                self.assertNotIsInstance(cm.exception, TOMLDecodeError)

    def test_converter_not_called_for_non_floats(self):
        calls = []
        doc = loads(
            "a = 1\nb = 'x'\nc = true\nd = 1979-05-27\n", parse_float=lambda t: calls.append(t)
        )
        self.assertEqual(calls, [])
        self.assertEqual(doc["a"], 1)

    def test_converter_applies_to_binary_entry(self):
        doc = load(io.BytesIO(b"a = 2.5"), parse_float=lambda t: t.upper())
        self.assertEqual(doc, {"a": "2.5"})


class TestEntryTypes(unittest.TestCase):
    # spec: N-000274 N-000278 N-000293
    def test_loads_returns_dict(self):
        self.assertIsInstance(loads("a = 1"), dict)
        self.assertIsInstance(loads(""), dict)

    def test_parse_float_is_keyword_only(self):
        with self.assertRaises(TypeError):
            loads("a = 1.0", float)

    def test_load_parse_float_is_keyword_only(self):
        with self.assertRaises(TypeError):
            load(io.BytesIO(b""), float)

    def test_public_names(self):
        import tomlparse
        self.assertEqual(set(tomlparse.__all__), {"loads", "load", "TOMLDecodeError"})
        self.assertIs(tomlparse.TOMLDecodeError, TOMLDecodeError)


if __name__ == "__main__":
    unittest.main()
