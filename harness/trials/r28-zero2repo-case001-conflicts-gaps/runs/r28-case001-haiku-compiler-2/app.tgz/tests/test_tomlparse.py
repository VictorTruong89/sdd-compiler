"""Behavioural tests for tomlparse, one group per feature point of the PRD.

Run from /app with:  PYTHONPATH=src python -m pytest tests
"""

import copy
import datetime as dt
import io
import pickle

import pytest

import tomlparse
from tomlparse import TOMLDecodeError, load, loads


# --- surface (N-000266..N-000273, N-000299..N-000306) -------------------------

def test_public_names_importable_from_root():
    # spec: N-000270 N-000271 N-000272
    from tomlparse import load as f_load, loads as f_loads, TOMLDecodeError as E
    assert f_load is load and f_loads is loads and E is TOMLDecodeError


def test_decode_error_is_value_error_only():
    # spec: N-000307 N-000308
    assert issubclass(TOMLDecodeError, ValueError)
    assert not issubclass(TOMLDecodeError, TypeError)
    assert not issubclass(TOMLDecodeError, RecursionError)


def test_decode_error_constructor_and_attributes():
    # spec: N-000309 N-000310 N-000311 N-000314 N-000315 N-000316 N-000317
    err = TOMLDecodeError("bad thing", "a = 1\nb = @\n", 10)
    assert err.msg == "bad thing"
    assert err.doc == "a = 1\nb = @\n"
    assert err.pos == 10
    assert err.lineno == 2
    assert err.colno == 5
    assert "bad thing" in str(err)
    assert "line 2" in str(err) and "column 5" in str(err)


def test_decode_error_end_of_document_report():
    # spec: N-000320 N-000322
    err = TOMLDecodeError("unexpected end", "a = [", 5)
    assert "end of document" in str(err)
    assert err.lineno == 1 and err.colno == 6


def test_decode_error_pickles():
    err = TOMLDecodeError("m", "x\ny", 2)
    back = pickle.loads(pickle.dumps(err))
    assert (back.msg, back.doc, back.pos, back.lineno, back.colno) == ("m", "x\ny", 2, 2, 1)


# --- FP-01 structure --------------------------------------------------------

@pytest.mark.parametrize("text", ["", "   \n\t\n", "# only a comment", "# c\n\n  # d\n"])
def test_empty_and_comment_only_documents(text):
    # spec: N-000082
    assert loads(text) == {}


def test_root_and_table_pairs():
    # spec: N-000083 N-000084
    doc = loads("a = 1\n[t]\nb = 2\n[u]\nc = 3\n")
    assert doc == {"a": 1, "t": {"b": 2}, "u": {"c": 3}}


def test_keys_are_strings_even_when_number_or_keyword_like():
    # spec: N-000085 N-000086 N-000087
    doc = loads("1 = 'a'\ntrue = 'b'\ninf = 'c'\nnan = 'd'\n")
    assert doc == {"1": "a", "true": "b", "inf": "c", "nan": "d"}
    assert all(isinstance(k, str) for k in doc)


def test_keys_are_case_sensitive():
    # spec: N-000088
    assert loads("a = 1\nA = 2\n") == {"a": 1, "A": 2}
    assert loads("[t]\n[T]\n") == {"t": {}, "T": {}}


def test_quoted_keys_including_empty_and_dots():
    # spec: N-000089 N-000090 N-000091 N-000092
    doc = loads('"" = 1\n"a.b" = 2\n\'c#d e\' = 3\n"é" = 4\n')
    assert doc == {"": 1, "a.b": 2, "c#d e": 3, "é": 4}


def test_basic_quoted_key_uses_escapes_literal_does_not():
    # spec: N-000142 N-000087
    assert loads('"\\u0041" = 1\n') == {"A": 1}
    assert loads("'\\u0041' = 1\n") == {"\\u0041": 1}


def test_dotted_keys_create_nested_mappings():
    # spec: N-000093 N-000094 N-000095
    assert loads("a . b . c = 1\na.d = 2\n") == {"a": {"b": {"c": 1}, "d": 2}}


def test_dotted_key_table_can_receive_subtable_via_header():
    # spec: N-000096 N-000097 N-000098
    doc = loads("a.b.c = 1\n[a.b.d]\nx = 2\n")
    assert doc == {"a": {"b": {"c": 1, "d": {"x": 2}}}}


def test_header_creates_missing_parents_and_super_table_later_defined():
    # spec: N-000096
    doc = loads("[x.y.z]\nk = 1\n[x]\nm = 2\n")
    assert doc == {"x": {"m": 2, "y": {"z": {"k": 1}}}}


def test_array_of_tables_appends_and_attaches_subtables():
    # spec: N-000099 N-000100 N-000101 N-000102
    text = "[[fruit]]\nname='apple'\n[fruit.physical]\ncolor='red'\n[[fruit]]\nname='banana'\n"
    assert loads(text) == {
        "fruit": [
            {"name": "apple", "physical": {"color": "red"}},
            {"name": "banana"},
        ]
    }


def test_array_of_tables_implies_plain_parent_tables():
    # spec: N-000101 N-000102
    doc = loads("[[a.b]]\nx = 1\n[a]\ny = 2\n")
    assert doc == {"a": {"b": [{"x": 1}], "y": 2}}


def test_inline_tables_empty_dotted_multiline_trailing_comma():
    # spec: N-000103 N-000104 N-000069
    assert loads("t = {}\n") == {"t": {}}
    assert loads("t = { a.b = 1, c = 2, }\n") == {"t": {"a": {"b": 1}, "c": 2}}
    assert loads("t = {\n  a = 1, # comment\n  b = 2,\n}\n") == {"t": {"a": 1, "b": 2}}


def test_arrays_mixed_nested_multiline_trailing_comma_comments():
    # spec: N-000105 N-000106 N-000003
    doc = loads("a = [ 1, 'x', [true, []], ]\nb = [\n  # c\n  1,\n  2 # d\n]\n")
    assert doc == {"a": [1, "x", [True, []]], "b": [1, 2]}


def test_comments_never_become_values_and_allow_non_ascii():
    # spec: N-000107 N-000108 N-000109
    assert loads("# é ü\na = 1 # trailing\n") == {"a": 1}
    assert loads("a=1#no space\n") == {"a": 1}


def test_indentation_insignificant():
    # spec: N-000110
    assert loads("[t]\n\t  a = 1\n\t b = 2\n") == {"t": {"a": 1, "b": 2}}


def test_crlf_is_single_line_feed_everywhere():
    # spec: N-000111 N-000112
    assert loads('a = """x\r\ny"""\r\n') == {"a": "x\ny"}
    assert loads("a = 1\r\nb = 2\r\n") == {"a": 1, "b": 2}


@pytest.mark.parametrize(
    "text",
    [
        "a = 1\na = 2\n",           # duplicate key
        "[t]\n[t]\n",               # table defined twice
        "[a.b]\n[a]\n[a.b]\n",      # header-defined table reopened
        "a.b = 1\n[a.b]\n",         # dotted-defined table then header
        "a.b = 1\n[a]\nb = 2\n",    # dotted table cannot be redefined by key
        "a = 1\n[a]\n",             # value replaced by table
        "a = 1\n[[a]]\n",           # value replaced by array of tables
        "[[a]]\n[a]\n",             # array of tables replaced by table
        "t = {x = 1}\n[t.y]\n",     # inline table is frozen
        "t = {x = 1}\nt.y = 2\n",   # inline table frozen to dotted keys
        "t = {}\n[t]\n",            # inline table cannot be a header target
        "[[a]]\nb = 1\n[a.b]\n",    # header runs through scalar inside aot element
        "a = [1]\n[a.b]\n",         # header runs through static array
        "a = [{x = 1}]\n[[a]]\n",   # static array replaced by array of tables
        "[a]\nb = 1\n[a.b.c]\n",    # header runs through scalar
        "a = 1\n[[a.b]]\n",
        "a = 1 2\n",                # missing newline between pairs
        "= 1\n",                    # pair with no key
        "a =\n",                    # pair with no value
        "a\n",
        "[a] b = 1\n",              # header shares its line with a pair
        "[a\n",                     # header not closed
        '"""k""" = 1\n',            # multiline key
        "[\"\"\"t\"\"\"]\n",         # multiline table name
        "[[a]\n",
        "[[a]\n]\n",
    ],
)
def test_structural_conflicts_are_refused(text):
    # spec: N-000113 N-000114 N-000115 N-000116 N-000117 N-000118 N-000119
    # spec: N-000120 N-000121 N-000122
    with pytest.raises(TOMLDecodeError):
        loads(text)


def test_dotted_key_into_header_defined_table_refused():
    # spec: N-000116 N-000117
    with pytest.raises(TOMLDecodeError):
        loads("[a.b]\nx = 1\n[a]\nb.y = 2\n")


def test_dotted_key_into_implicit_table_is_allowed():
    # spec: N-000093 N-000095
    assert loads("[a.b.c]\n[a]\nb.d = 1\n") == {"a": {"b": {"c": {}, "d": 1}}}


def test_dotted_keys_allowed_when_sub_header_defined_later():
    assert loads("[t]\na.b = 1\n[t.a.c]\nz = 2\n") == {"t": {"a": {"b": 1, "c": {"z": 2}}}}


# --- FP-02 scalars -------------------------------------------------------------

def test_booleans():
    # spec: N-000124 N-000125 N-000126
    doc = loads("a = true\nb = false\n")
    assert doc == {"a": True, "b": False}
    assert doc["a"] is True and doc["b"] is False


@pytest.mark.parametrize("text", ["a = True\n", "a = FALSE\n", "a = tru\n", "a = truex\n"])
def test_non_lowercase_booleans_refused(text):
    # spec: N-000166
    with pytest.raises(TOMLDecodeError):
        loads(text)


def test_basic_string_escapes():
    # spec: N-000137 N-000138 N-000139 N-000141
    doc = loads(r'a = "\b\t\n\f\r\e\"\\"' + "\n" + r'b = "\x41\u00e9\U0001F600"' + "\n")
    assert doc == {"a": "\b\t\n\f\r\x1b\"\\", "b": "A\u00e9\U0001F600"}


def test_hex_escape_digits_either_case():
    # spec: N-000139 N-000146
    assert loads(r'a = "\u00E9\u00e9"' + "\n") == {"a": "\u00e9\u00e9"}


def test_literal_string_no_escapes():
    # spec: N-000129 N-000141
    assert loads(r"a = 'C:\path\n'" + "\n") == {"a": "C:\\path\\n"}


def test_multiline_basic_trims_first_newline_and_keeps_others():
    # spec: N-000131 N-000132
    assert loads('a = """\nx\ny\n"""\n') == {"a": "x\ny\n"}


def test_multiline_literal_trims_first_newline():
    # spec: N-000131
    assert loads("a = '''\nx\n'''\n") == {"a": "x\n"}
    assert loads("a = '''\n\nx'''\n") == {"a": "\nx"}


def test_line_ending_backslash_trims_whitespace_including_newlines():
    # spec: N-000134
    assert loads('a = """one \\\n   \n    two"""\n') == {"a": "one two"}


def test_quotes_before_multiline_closing_delimiter():
    # spec: N-000135 N-000136
    assert loads('a = """x""""\n') == {"a": 'x"'}
    assert loads('a = """x"""""\n') == {"a": 'x""'}
    assert loads("a = '''x''''\n") == {"a": "x'"}
    assert loads('a = """"""\n') == {"a": ""}


def test_tab_is_allowed_raw_in_one_line_strings():
    # spec: N-000178
    assert loads("a = 'x\ty'\nb = \"x\ty\"\n") == {"a": "x\ty", "b": "x\ty"}


@pytest.mark.parametrize(
    "text",
    [
        'a = "\\q"\n',              # escape outside the set
        'a = "\\x4"\n',             # short \x run
        'a = "\\u12G4"\n',          # non-hex \u run
        'a = "\\UD800DC00"\n',      # surrogate code point
        'a = "\\U00110000"\n',      # beyond Unicode range
        'a = "line\nbreak"\n',      # raw newline in one-line string
        'a = "unterminated\n',
        "a = 'unterminated\n",
        'a = "ctl\x01"\n',          # raw control character
        'a = "del\x7f"\n',
        'a = """x\\ y"""\n',        # line-ending backslash with text after it
        'a = """x\ry"""\n',         # bare carriage return
        'a = """x""""""\n',         # too many quotes before closing
    ],
)
def test_invalid_strings_refused(text):
    # spec: N-000174 N-000175 N-000176 N-000177 N-000178
    with pytest.raises(TOMLDecodeError):
        loads(text)


def test_integers_all_bases():
    # spec: N-000144 N-000145 N-000147
    doc = loads("a = 0\nb = +0\nc = -0\nd = -17\ne = 1_000\nf = 0xdead_beef\n"
                "g = 0o755\nh = 0b1101_0110\ni = 0xDEADBEEF\n")
    assert doc == {"a": 0, "b": 0, "c": 0, "d": -17, "e": 1000, "f": 0xDEADBEEF,
                   "g": 0o755, "h": 0b11010110, "i": 0xDEADBEEF}
    assert all(type(v) is int for v in doc.values())


def test_very_long_integer_is_exact():
    digits = "9" * 6000
    result = loads("a = " + digits + "\n")["a"]
    assert result == 10 ** 6000 - 1


@pytest.mark.parametrize(
    "text",
    [
        "a = 01\n", "a = -01\n", "a = 0x_1\n", "a = 1_\n", "a = _1\n", "a = 1__0\n",
        "a = 0X1F\n", "a = 0O7\n", "a = 0B1\n", "a = +0x1\n", "a = -0o7\n",
        "a = 0xG\n", "a = 0o8\n", "a = 0b2\n", "a = 0x\n",
        "a = 1.\n", "a = .5\n", "a = 1._5\n", "a = 00.5\n", "a = 1.e5\n",
        "a = .\n", "a = 1e\n", "a = 1.0e\n",
    ],
)
def test_invalid_numbers_refused(text):
    # spec: N-000167 N-000168 N-000169 N-000170 N-000171 N-000172 N-000173
    with pytest.raises(TOMLDecodeError):
        loads(text)


def test_floats_default_and_special():
    # spec: N-000148 N-000149 N-000150
    doc = loads("a = 3.14\nb = -0.5\nc = 1e3\nd = 6.626e-34\ne = 5e+22\nf = 1_000.5\n"
                "g = inf\nh = +inf\ni = -inf\nj = nan\nk = +nan\nl = -nan\n")
    assert doc["a"] == 3.14 and doc["b"] == -0.5 and doc["c"] == 1000.0
    assert doc["d"] == 6.626e-34 and doc["e"] == 5e22 and doc["f"] == 1000.5
    assert doc["g"] == float("inf") and doc["h"] == float("inf") and doc["i"] == float("-inf")
    for key in ("j", "k", "l"):
        assert doc[key] != doc[key]  # NaN
    assert all(type(doc[k]) is float for k in "abcdefghijkl")


def test_local_dates_and_date_times():
    # spec: N-000151 N-000152 N-000159 N-000160
    doc = loads("d = 1979-05-27\nleap = 2024-02-29\n")
    assert doc == {"d": dt.date(1979, 5, 27), "leap": dt.date(2024, 2, 29)}
    assert doc["d"] is not None and type(doc["d"]) is dt.date


def test_offset_date_times_utc_and_numeric():
    # spec: N-000151 N-000288 N-000024
    doc = loads("a = 1979-05-27T07:32:00Z\nb = 1979-05-27t07:32:00z\n"
                "c = 1979-05-27T00:32:00-07:00\nd = 1979-05-27 07:32:00+05:30\n")
    assert doc["a"] == dt.datetime(1979, 5, 27, 7, 32, tzinfo=dt.timezone.utc)
    assert doc["b"].utcoffset() == dt.timedelta(0)
    assert doc["c"].utcoffset() == dt.timedelta(hours=-7)
    assert doc["d"].utcoffset() == dt.timedelta(hours=5, minutes=30)
    assert all(isinstance(v, dt.datetime) and v.tzinfo is not None for v in doc.values())


def test_local_date_time_is_naive():
    # spec: N-000289 N-000025
    doc = loads("a = 1979-05-27T07:32:00\nb = 1979-05-27 07:32:00.5\n")
    assert doc["a"] == dt.datetime(1979, 5, 27, 7, 32)
    assert doc["a"].tzinfo is None
    assert doc["b"] == dt.datetime(1979, 5, 27, 7, 32, 0, 500000)


def test_local_time_naive_and_fraction_truncated():
    # spec: N-000291 N-000292 N-000156 N-000157 N-000027
    doc = loads("t = 07:32:00.999999999\nu = 07:32:00.1\nv = 07:32:00.1234567\n")
    assert doc["t"] == dt.time(7, 32, 0, 999999)
    assert doc["u"] == dt.time(7, 32, 0, 100000)
    assert doc["v"] == dt.time(7, 32, 0, 123456)
    assert doc["t"].tzinfo is None


def test_seconds_may_be_omitted_in_times():
    # spec: N-000154 N-000155 N-000028
    doc = loads("a = 07:32\nb = 1979-05-27T07:32Z\nc = 1979-05-27T07:32\n")
    assert doc["a"] == dt.time(7, 32, 0)
    assert doc["b"] == dt.datetime(1979, 5, 27, 7, 32, tzinfo=dt.timezone.utc)
    assert doc["c"] == dt.datetime(1979, 5, 27, 7, 32)


def test_fraction_without_digits_after_point_refused():
    # spec: N-000157
    with pytest.raises(TOMLDecodeError):
        loads("a = 07:32:00.\n")


@pytest.mark.parametrize(
    "text",
    [
        "a = 1979-02-30\n", "a = 1979-02-29\n", "a = 2023-02-29\n",
        "a = 07:60:00\n", "a = 24:00:00\n", "a = 07:32:60\n",
        "a = 1979-05-27T07:32:00+24:00\n", "a = 1979-05-27T07:32:00+05:60\n",
        "a = 1979-5-27\n", "a = 1979-05-27x\n", "a = 1979-05-27T\n",
        "a = 1979-05-27T07:32:00.5x\n",
    ],
)
def test_invalid_date_times_refused(text):
    # spec: N-000179 N-000180 N-000162
    with pytest.raises(TOMLDecodeError):
        loads(text)


def test_leap_day_2024_accepted_and_not_in_1900():
    # spec: N-000159
    assert loads("a = 2000-02-29\n") == {"a": dt.date(2000, 2, 29)}
    with pytest.raises(TOMLDecodeError):
        loads("a = 1900-02-29\n")


def test_parsed_values_copy_and_compare_as_usual():
    # spec: N-000160 N-000161
    doc = loads("a = 1979-05-27T07:32:00Z\nb = [1, 'x']\n")
    clone = copy.deepcopy(doc)
    assert clone == doc and clone is not doc


def test_scalar_type_refusals_are_decode_errors_not_type_errors():
    # spec: N-000162 N-000164 N-000165
    with pytest.raises(TOMLDecodeError) as info:
        loads("a = 0xZZ\n")
    assert not isinstance(info.value, TypeError)


# --- FP-03 binary file ---------------------------------------------------------

def test_load_from_binary_buffer_equals_loads():
    # spec: N-000181 N-000183 N-000184 N-000188 N-000189
    text = 'a = "é"\n[t]\nb = [1, 2]\n'
    assert load(io.BytesIO(text.encode("utf-8"))) == loads(text)


def test_load_empty_file_yields_empty_dict():
    # spec: N-000188 N-000303
    assert load(io.BytesIO(b"")) == {}


def test_load_accepts_bytearray_and_memoryview_reads():
    # spec: N-000187 N-000299 N-000300
    class Reader:
        def read(self):
            return bytearray(b"a = 1\n")
    assert load(Reader()) == {"a": 1}


def test_load_reads_disk_binary_file(tmp_path):
    # spec: N-000189
    path = tmp_path / "doc.toml"
    path.write_bytes(b"x = 2\n")
    with open(path, "rb") as fh:
        assert load(fh) == {"x": 2}


def test_load_refuses_text_mode_file_whatever_it_holds(tmp_path):
    # spec: N-000190 N-000191 N-000192 N-000304 N-000216
    path = tmp_path / "doc.toml"
    path.write_text("")
    with open(path, "r", encoding="utf-8") as fh:
        with pytest.raises(TypeError) as info:
            load(fh)
    assert not isinstance(info.value, TOMLDecodeError)
    with pytest.raises(TypeError):
        load(io.StringIO("a = 1\n"))


def test_load_decode_error_carries_decoded_text_and_position():
    # spec: N-000193 N-000194 N-000195 N-000305
    with pytest.raises(TOMLDecodeError) as info:
        load(io.BytesIO("a = 1\nb = é ?\n".encode("utf-8")))
    assert info.value.doc == "a = 1\nb = é ?\n"
    assert isinstance(info.value.doc, str)
    assert info.value.lineno == 2


def test_load_invalid_utf8_is_decode_error():
    with pytest.raises(TOMLDecodeError):
        load(io.BytesIO(b"a = '\xff'\n"))


def test_load_refuses_non_binary_arguments():
    with pytest.raises(TypeError):
        load("a = 1")  # type: ignore[arg-type]


def test_load_parse_float_applies_like_loads():
    # spec: N-000182 N-000220 N-000301
    doc = load(io.BytesIO(b"a = 1.5\n"), parse_float=lambda text: "F" + text)
    assert doc == {"a": "F1.5"}


# --- FP-04 rejection and types --------------------------------------------------

@pytest.mark.parametrize("bad", [b"a = 1", bytearray(b"a=1"), 1, None, ["a = 1"], io.BytesIO(b"a=1")])
def test_loads_refuses_non_text_with_type_error(bad):
    # spec: N-000213 N-000214 N-000215 N-000274
    with pytest.raises(TypeError) as info:
        loads(bad)  # type: ignore[arg-type]
    assert not isinstance(info.value, TOMLDecodeError)


def test_loads_parse_float_is_keyword_only():
    # spec: N-000275
    with pytest.raises(TypeError):
        loads("a = 1", float)  # type: ignore[misc]


def test_decode_error_location_for_interior_offset():
    # spec: N-000203 N-000204 N-000205 N-000206 N-000207
    with pytest.raises(TOMLDecodeError) as info:
        loads("a = 1\nb = 2\nc = @\n")
    err = info.value
    assert err.doc == "a = 1\nb = 2\nc = @\n"
    assert err.pos == 16
    assert err.lineno == 3
    assert err.colno == 5


def test_decode_error_location_for_end_offset():
    # spec: N-000208 N-000209
    with pytest.raises(TOMLDecodeError) as info:
        loads("a = [1,\n")
    assert info.value.pos >= len("a = [1,\n") - 1
    assert "end of document" in str(info.value)


def test_caller_constructed_error_matches_rules():
    # spec: N-000210 N-000211 N-000212
    err = TOMLDecodeError("reason", "first\nsecond", 8)
    assert (err.msg, err.doc, err.pos) == ("reason", "first\nsecond", 8)
    assert (err.lineno, err.colno) == (2, 3)
    assert "reason" in str(err) and "line 2" in str(err)


def test_error_position_after_crlf_maps_to_original_text():
    text = "a = 1\r\nb = @\r\n"
    with pytest.raises(TOMLDecodeError) as info:
        loads(text)
    assert info.value.doc == text
    assert text[info.value.pos] == "@"
    assert info.value.lineno == 2 and info.value.colno == 5


def test_decode_error_not_raised_for_valid_document():
    assert loads("a = 1") == {"a": 1}


def test_value_error_from_parse_float_is_not_decode_error():
    # spec: N-000232 N-000233 N-000296
    for bad in (lambda t: {}, lambda t: [], lambda t: type("D", (dict,), {})(),
                lambda t: type("L", (list,), {})()):
        with pytest.raises(ValueError) as info:
            loads("a = 1.5\n", parse_float=bad)
        assert not isinstance(info.value, TOMLDecodeError)


# --- FP-05 converter -----------------------------------------------------------

def test_converter_called_with_text_everywhere_for_floats_only():
    # spec: N-000223 N-000224 N-000225 N-000226 N-000227 N-000228 N-000229 N-000222
    seen = []

    def conv(text):
        seen.append(text)
        return ("F", text)

    doc = loads("a = 1_0.5e+2\nb = 3\nc = 'x'\nd = inf\n"
                "[t]\ne = [1.5, {f = -nan}]\n", parse_float=conv)
    assert seen == ["1_0.5e+2", "inf", "1.5", "-nan"]
    assert doc == {
        "a": ("F", "1_0.5e+2"),
        "b": 3,
        "c": "x",
        "d": ("F", "inf"),
        "t": {"e": [("F", "1.5"), {"f": ("F", "-nan")}]},
    }


def test_converter_returning_non_container_values_is_bound():
    # spec: N-000230 N-000231
    assert loads("a = 2.5\n", parse_float=lambda t: 1) == {"a": 1}
    assert loads("a = 2.5\n", parse_float=lambda t: None) == {"a": None}


def test_converter_result_not_checked_for_non_float_scalars():
    assert loads("a = 2\n", parse_float=lambda t: {}) == {"a": 2}


# --- non-functional and global ----------------------------------------------------

def test_package_has_version_and_no_third_party_imports():
    # spec: N-000040 N-000266 N-000267 N-000268 N-000269
    import pathlib
    assert tomlparse.__version__
    src = pathlib.Path(tomlparse.__file__).parent
    allowed = {"re", "io", "datetime", "pathlib", "copy", "pickle", "sys"}
    for path in src.glob("*.py"):
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.startswith(("import ", "from ")) and not line.startswith("from ."):
                module = line.split()[1].split(".")[0]
                assert module in allowed or module == "__future__", (path.name, line)


def test_parser_does_not_use_stdlib_toml():
    # spec: N-000057 N-000058 N-000060
    import pathlib
    src = pathlib.Path(tomlparse.__file__).parent
    for path in src.glob("*.py"):
        text = path.read_text(encoding="utf-8")
        assert "import tomllib" not in text and "import toml\n" not in text


def test_no_write_or_cli_surface():
    # spec: N-000031 N-000032 N-000063 N-000064
    assert not hasattr(tomlparse, "dump")
    assert not hasattr(tomlparse, "dumps")
    assert not hasattr(tomlparse, "main")


def test_load_takes_a_file_object_never_a_path(tmp_path):
    # spec: N-000299 N-000300
    path = tmp_path / "doc.toml"
    path.write_bytes(b"a = 1\n")
    with pytest.raises(TypeError):
        load(str(path))  # type: ignore[arg-type]


def test_parse_entries_print_nothing_and_leave_environment_alone(capsys, monkeypatch):
    # spec: N-000259 N-000261
    import os
    monkeypatch.setenv("TOMLPARSE_PROBE", "1")
    before = dict(os.environ)
    loads("a = 1\n")
    with pytest.raises(TOMLDecodeError):
        loads("a = @\n")
    load(io.BytesIO(b"b = 2\n"))
    captured = capsys.readouterr()
    assert captured.out == "" and captured.err == ""
    assert dict(os.environ) == before


def test_empty_quoted_key_is_a_valid_key():
    # spec: N-000279 N-000089 N-000090 (decision: empty quoted keys allowed)
    assert loads('"" = {"" = 1}\n') == {"": {"": 1}}
