"""The two public parse entries: ``loads`` (text) and ``load`` (binary file)."""

import io

from ._errors import TOMLDecodeError
from ._parser import ParseFailure, parse_document



# spec: N-000266 N-000267 N-000268 N-000269 (package surface, pure Python, no I/O at import)
# spec: N-000273 N-000298 (internal layout and message wording left to the implementer)
def _check_parse_float(parse_float):
    if parse_float is not float and not callable(parse_float):
        raise TypeError("parse_float must be callable")


# spec: N-000111 N-000112 N-000203 N-000204 (CR LF normalization; offsets reported against the caller text)
def _original_offset(original, pos):
    """Map an offset in the CR LF-normalized text back to ``original``."""
    seen = 0
    last = len(original)
    for k, ch in enumerate(original):
        if ch == "\r" and k + 1 < last and original[k + 1] == "\n":
            continue
        if seen == pos:
            return k
        seen += 1
    return last


# spec: N-000270 N-000271 N-000274 N-000275 N-000276 N-000277 N-000278 N-000287
# spec: N-000293 N-000294 N-000295 N-000296 N-000297 N-000077 N-000078 N-000079
# spec: N-000081 N-000082 N-000083 N-000084 N-000213 N-000214 N-000215 N-000220
# spec: N-000221 N-000222 N-000223 N-000224 N-000225 N-000226 N-000227 N-000228
# spec: N-000229 N-000230 N-000231 N-000232 N-000233
def loads(s, *, parse_float=float):
    """Parse a TOML v1.1.0 document from a text string into a dict.

    ``parse_float`` is called with the characters of each TOML float and
    its return value is stored in place of the float.
    """
    if not isinstance(s, str):
        raise TypeError("loads() expects str, not {}".format(type(s).__name__))
    _check_parse_float(parse_float)
    text = s.replace("\r\n", "\n") if "\r" in s else s
    try:
        return parse_document(text, parse_float)
    except ParseFailure as failure:
        pos = failure.pos
        if text is not s:
            pos = _original_offset(s, pos)
        raise TOMLDecodeError(failure.msg, s, pos) from None


# spec: N-000272 N-000299 N-000300 N-000301 N-000302 N-000303 N-000304 N-000305
# spec: N-000306 N-000181 N-000182 N-000183 N-000184 N-000185 N-000186 N-000187
# spec: N-000188 N-000189 N-000190 N-000191 N-000192 N-000193 N-000194 N-000195
# spec: N-000196 N-000216 N-000217 N-000218
def load(fp, *, parse_float=float):
    """Parse a TOML v1.1.0 document read from a binary file object."""
    if isinstance(fp, io.TextIOBase):
        raise TypeError("load() expects a file opened in binary mode, not text mode")
    read = getattr(fp, "read", None)
    if not callable(read):
        raise TypeError("load() expects a binary file object with a read() method")
    _check_parse_float(parse_float)
    data = read()
    if isinstance(data, str):
        raise TypeError("load() expects bytes from a binary file object, got str")
    if not isinstance(data, (bytes, bytearray, memoryview)):
        raise TypeError("load() expects bytes, got {}".format(type(data).__name__))
    raw = bytes(data)
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as failure:
        valid_prefix = raw[:failure.start].decode("utf-8")
        raise TOMLDecodeError(
            "invalid UTF-8 byte sequence",
            raw.decode("utf-8", "replace"),
            len(valid_prefix),
        ) from None
    return loads(text, parse_float=parse_float)
