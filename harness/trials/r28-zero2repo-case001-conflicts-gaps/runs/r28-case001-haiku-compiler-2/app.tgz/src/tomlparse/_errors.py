"""The decode-error class of the Tomlparse product."""



# spec: N-000307 N-000308 (ValueError subclass, not TypeError/RecursionError)
# spec: N-000309 N-000310 N-000311 N-000312 N-000313 N-000314 N-000315
# spec: N-000316 N-000317 N-000318 N-000319 N-000320 N-000321 N-000322 N-000323
# spec: N-000203 N-000204 N-000205 N-000206 N-000207 N-000208 N-000209
# spec: N-000210 N-000211 N-000212 N-000219 N-000030
class TOMLDecodeError(ValueError):
    """Raised when a document is not valid TOML v1.1.0.

    Constructed as ``TOMLDecodeError(msg, doc, pos)``: ``msg`` is the
    unformatted reason, ``doc`` the document text, and ``pos`` a 0-based
    character offset into ``doc``. ``lineno`` (1-based line) and ``colno``
    (1-based column) are derived from ``pos``.
    """

    def __init__(self, msg, doc, pos):
        lineno = doc.count("\n", 0, pos) + 1
        last_newline = doc.rfind("\n", 0, pos)
        colno = pos - last_newline
        if pos >= len(doc):
            where = "at end of document, line {}, column {}".format(lineno, colno)
        else:
            where = "line {}, column {}".format(lineno, colno)
        ValueError.__init__(self, "{} ({}, char {})".format(msg, where, pos))
        self.msg = msg
        self.doc = doc
        self.pos = pos
        self.lineno = lineno
        self.colno = colno

    def __reduce__(self):
        # Rebuild from the three constructor arguments, not from the report.
        return (self.__class__, (self.msg, self.doc, self.pos))


TOMLDecodeError.__module__ = "tomlparse"
