"""Recursive-descent parser for TOML v1.1.0 text.

The parser works on a normalized string in which every CR LF pair has been
replaced by a single LF. Any failure is reported as ``ParseFailure`` with an
offset into that normalized string; the public layer converts it into a
``TOMLDecodeError`` against the caller's original text.

Scalar construction (numbers, date-times, strings) lives here as well so the
whole grammar is in one place.
"""

import re
from datetime import date, datetime, time, timedelta, timezone

# Decisions on the specification's unsettled conflicts (see NOTES.md):
#   - a quote run of 1 or 2 may sit directly before a multiline closing delimiter
#   - a line-ending backslash trims all following whitespace, line feeds included
#   - a first line feed after a multiline opening delimiter is discarded (both kinds)
#   - a CR LF pair is one line feed everywhere (so no CR survives in strings)
#   - raw tabs are allowed in every one-line string, literal ones included
#   - hex digits of integers and of escapes may be either case
#   - fractional seconds are truncated to six digits
#   - arrays may end with a trailing comma
#   - local times and date-times may omit seconds
#   - "+0" and "-0" are the integer 0
#   - a space may separate date and time in every date-time form
#   - a dotted-key table can never be defined by a header, but may receive one below it
#   - a converter result that is a dict or list, or a subclass of either, is refused

# spec: N-000255 N-000256 N-000257 N-000258 N-000259 N-000260 N-000261
# spec: N-000262 N-000263 N-000264 N-000265


class ParseFailure(Exception):
    """Internal signal: the document is invalid at offset ``pos``."""

    def __init__(self, msg, pos):
        Exception.__init__(self, msg)
        self.msg = msg
        self.pos = pos


_BARE_KEY = re.compile(r"[A-Za-z0-9_-]+")
_VALUE_RUN = re.compile(r"[0-9A-Za-z_+\-.]+")

_DEC_INT = re.compile(r"[+-]?(?:0|[1-9](?:_?[0-9])*)")
_HEX_INT = re.compile(r"0x[0-9A-Fa-f](?:_?[0-9A-Fa-f])*")
_OCT_INT = re.compile(r"0o[0-7](?:_?[0-7])*")
_BIN_INT = re.compile(r"0b[01](?:_?[01])*")
_FLOAT = re.compile(
    r"[+-]?(?:0|[1-9](?:_?[0-9])*)"
    r"(?:\.[0-9](?:_?[0-9])*(?:[eE][+-]?[0-9](?:_?[0-9])*)?"
    r"|[eE][+-]?[0-9](?:_?[0-9])*)"
)
_SPECIAL_FLOAT = re.compile(r"[+-]?(?:inf|nan)")

_DATETIME = re.compile(
    r"(?P<y>[0-9]{4})-(?P<mo>[0-9]{2})-(?P<d>[0-9]{2})"
    r"(?:[Tt ](?P<H>[0-9]{2}):(?P<M>[0-9]{2})"
    r"(?::(?P<S>[0-9]{2})(?:\.(?P<f>[0-9]+))?)?"
    r"(?P<z>[Zz]|[+-][0-9]{2}:[0-9]{2})?)?"
)
_LOCAL_TIME = re.compile(
    r"(?P<H>[0-9]{2}):(?P<M>[0-9]{2})"
    r"(?::(?P<S>[0-9]{2})(?:\.(?P<f>[0-9]+))?)?"
)

# Runs of characters that need no per-character handling inside strings.
_BASIC_PLAIN = re.compile(r'[^"\\\x00-\x08\x0a-\x1f\x7f]+')
_ML_BASIC_PLAIN = re.compile(r'[^"\\\x00-\x08\x0b-\x1f\x7f]+')
_LITERAL_PLAIN = re.compile(r"[^'\x00-\x08\x0a-\x1f\x7f]+")
_ML_LITERAL_PLAIN = re.compile(r"[^'\x00-\x08\x0b-\x1f\x7f]+")

_SIMPLE_ESCAPES = {
    "b": "\b",
    "t": "\t",
    "n": "\n",
    "f": "\f",
    "r": "\r",
    "e": "\x1b",
    '"': '"',
    "\\": "\\",
}
_UNICODE_ESCAPE_LENGTHS = {"x": 2, "u": 4, "U": 8}
_HEX_DIGITS = frozenset("0123456789abcdefABCDEF")
_DIGITS = frozenset("0123456789")


def _dec_int(clean):
    """Convert a validated decimal literal (sign allowed) to an int.

    Python may refuse very long decimal strings; fall back to chunked
    conversion so every valid TOML integer is accepted.
    """
    try:
        return int(clean)
    except ValueError:
        negative = clean.startswith("-")
        digits = clean.lstrip("+-")
        result = 0
        for start in range(0, len(digits), 1000):
            chunk = digits[start:start + 1000]
            result = result * (10 ** len(chunk)) + int(chunk)
        return -result if negative else result


class _Parser:
    def __init__(self, text, parse_float):
        self.s = text
        self.n = len(text)
        self.i = 0
        self.parse_float = parse_float
        self.root = {}
        # id(table) -> "header" | "implicit" | "dotted" | "inline"
        self.kind = {}
        # ids of lists that are arrays of tables
        self.aot_ids = set()

    # ----- low-level helpers -------------------------------------------------

    def fail(self, msg, pos=None):
        raise ParseFailure(msg, self.i if pos is None else pos)

    def peek(self):
        return self.s[self.i] if self.i < self.n else ""

    def skip_ws(self):
        s, n, i = self.s, self.n, self.i
        while i < n and s[i] in " \t":
            i += 1
        self.i = i

    def skip_ws_and_newlines(self):
        while True:
            self.skip_ws()
            c = self.peek()
            if c == "\n":
                self.i += 1
            elif c == "#":
                self.skip_comment()
            else:
                return

# spec: N-000107 N-000108 N-000109 N-000110 (comments discarded; spaces and tabs insignificant)
    def skip_comment(self):
        s, n = self.s, self.n
        j = self.i + 1
        while j < n and s[j] != "\n":
            c = s[j]
            if (c < " " and c != "\t") or c == "\x7f":
                self.fail("control character in comment", j)
            j += 1
        self.i = j

# spec: N-000120 N-000121 N-000122 (a header or pair must end its own line)
    def end_of_line(self):
        """Allow only blanks, an optional comment, then a line feed or end."""
        self.skip_ws()
        if self.peek() == "#":
            self.skip_comment()
        if self.i >= self.n:
            return
        if self.s[self.i] == "\n":
            self.i += 1
            return
        self.fail("expected end of line")

    # ----- document ----------------------------------------------------------

    def parse(self):
        current = self.root
        while True:
            self.skip_ws()
            if self.i >= self.n:
                break
            c = self.s[self.i]
            if c == "\n":
                self.i += 1
            elif c == "#":
                self.skip_comment()
            elif c == "[":
                current = self.header()
            else:
                self.keyval(current)
                self.end_of_line()
        return self.root

    # ----- keys --------------------------------------------------------------

# spec: N-000085 N-000086 N-000087 N-000089 N-000090 N-000121 (key forms; multiline strings refused as keys)
    def simple_key(self):
        s, i = self.s, self.i
        if i >= self.n:
            self.fail("expected key")
        c = s[i]
        if c == '"':
            if s.startswith('"""', i):
                self.fail("multiline string cannot be a key")
            return self.single_basic()
        if c == "'":
            if s.startswith("'''", i):
                self.fail("multiline string cannot be a key")
            return self.single_literal()
        m = _BARE_KEY.match(s, i)
        if m is None:
            self.fail("expected key")
        self.i = m.end()
        return m.group()

# spec: N-000093 N-000094 (dotted keys; whitespace around dots insignificant)
    def key_path(self):
        parts = [self.simple_key()]
        while True:
            self.skip_ws()
            if self.peek() != ".":
                return parts
            self.i += 1
            self.skip_ws()
            parts.append(self.simple_key())

    def keyval(self, table):
        start = self.i
        keys = self.key_path()
        self.skip_ws()
        if self.peek() != "=":
            self.fail("expected '=' after key")
        self.i += 1
        self.skip_ws()
        value = self.value()
        self.insert(table, keys, value, start)

# spec: N-000091 N-000092 N-000093 N-000095 N-000113 N-000114 N-000115 N-000116 N-000117 N-000118 N-000119
    def insert(self, table, keys, value, start):
        """Store ``value`` at the dotted path ``keys`` below ``table``.

        ``start`` is the offset of the key, used to locate conflicts.
        """
        node = table
        for part in keys[:-1]:
            if part in node:
                child = node[part]
                if not isinstance(child, dict) or self.kind.get(id(child)) not in (
                    "dotted",
                    "implicit",
                ):
                    self.fail(
                        "key {!r} already has a value that dotted keys cannot extend".format(part),
                        start,
                    )
                node = child
            else:
                child = {}
                self.kind[id(child)] = "dotted"
                node[part] = child
                node = child
        last = keys[-1]
        if last in node:
            self.fail("duplicate key {!r}".format(last), start)
        node[last] = value

    # ----- table headers ------------------------------------------------------

# spec: N-000096 N-000099 N-000113 N-000115 N-000122 (table and array-of-tables headers)
    def header(self):
        s = self.s
        is_array = s.startswith("[[", self.i)
        self.i += 2 if is_array else 1
        self.skip_ws()
        path = self.key_path()
        self.skip_ws()
        if is_array:
            if not s.startswith("]]", self.i):
                self.fail("expected ']]' to close array of tables header")
            self.i += 2
        else:
            if self.peek() != "]":
                self.fail("expected ']' to close table header")
            self.i += 1
        self.end_of_line()
        return self.resolve_header(path, is_array)

# spec: N-000096 N-000097 N-000098 N-000099 N-000100 N-000101 N-000102 N-000113 N-000114 N-000115 N-000116 N-000117 N-000119
    def resolve_header(self, path, is_array):
        node = self.root
        for part in path[:-1]:
            if part in node:
                child = node[part]
                if isinstance(child, list) and id(child) in self.aot_ids:
                    child = child[-1]
                elif not isinstance(child, dict) or self.kind.get(id(child)) == "inline":
                    self.fail("header path {!r} runs through a value".format(part))
                node = child
            else:
                child = {}
                self.kind[id(child)] = "implicit"
                node[part] = child
                node = child

        last = path[-1]
        if is_array:
            if last in node:
                items = node[last]
                if not (isinstance(items, list) and id(items) in self.aot_ids):
                    self.fail("{!r} is already defined as a value, not an array of tables".format(last))
            else:
                items = []
                self.aot_ids.add(id(items))
                node[last] = items
            new = {}
            self.kind[id(new)] = "header"
            items.append(new)
            return new

        if last in node:
            child = node[last]
            if isinstance(child, dict) and self.kind.get(id(child)) == "implicit":
                self.kind[id(child)] = "header"
                return child
            self.fail("table {!r} is defined more than once".format(last))
        new = {}
        self.kind[id(new)] = "header"
        node[last] = new
        return new

    # ----- values -------------------------------------------------------------

# spec: N-000124 N-000125 N-000126 N-000166 N-000162 N-000163 N-000165 N-000164 (value dispatch; TOML scalar and container values)
    def value(self):
        s, i = self.s, self.i
        if i >= self.n:
            self.fail("expected a value")
        c = s[i]
        if c == '"':
            if s.startswith('"""', i):
                return self.multi_basic()
            return self.single_basic()
        if c == "'":
            if s.startswith("'''", i):
                return self.multi_literal()
            return self.single_literal()
        if c == "[":
            return self.array()
        if c == "{":
            return self.inline_table()
        if c in "tf":
            m = _VALUE_RUN.match(s, i)
            word = m.group() if m else ""
            if word == "true":
                self.i = m.end()
                return True
            if word == "false":
                self.i = m.end()
                return False
            self.fail("invalid value")
        if c in _DIGITS or c in "+-" or c in "in":
            return self.number_or_datetime()
        self.fail("expected a value")

# spec: N-000105 N-000106 N-000282 N-000281 (arrays: document order, nesting, trailing comma)
    def array(self):
        self.i += 1
        items = []
        self.skip_ws_and_newlines()
        while True:
            if self.peek() == "]":
                self.i += 1
                return items
            items.append(self.value())
            self.skip_ws_and_newlines()
            c = self.peek()
            if c == ",":
                self.i += 1
                self.skip_ws_and_newlines()
            elif c == "]":
                self.i += 1
                return items
            else:
                self.fail("expected ',' or ']' in array")

# spec: N-000103 N-000104 N-000069 N-000118 (inline tables; frozen once closed)
    def inline_table(self):
        self.i += 1
        table = {}
        self.kind[id(table)] = "inline"
        self.skip_ws_and_newlines()
        if self.peek() == "}":
            self.i += 1
            return table
        while True:
            start = self.i
            keys = self.key_path()
            self.skip_ws()
            if self.peek() != "=":
                self.fail("expected '=' in inline table")
            self.i += 1
            self.skip_ws()
            self.insert(table, keys, self.value(), start)
            self.skip_ws_and_newlines()
            c = self.peek()
            if c == ",":
                self.i += 1
                self.skip_ws_and_newlines()
                if self.peek() == "}":
                    self.i += 1
                    return table
            elif c == "}":
                self.i += 1
                return table
            else:
                self.fail("expected ',' or '}' in inline table")

    # ----- numbers and date-times ----------------------------------------------

# spec: N-000144 N-000145 N-000146 N-000147 N-000148 N-000149 N-000150 N-000167 N-000168 N-000169 N-000170 N-000171 N-000172 N-000173 N-000162
    def number_or_datetime(self):
        s, i = self.s, self.i
        if s[i] in _DIGITS:
            m = _DATETIME.match(s, i)
            if m is not None:
                self.i = m.end()
                return self.build_datetime(m)
            m = _LOCAL_TIME.match(s, i)
            if m is not None:
                self.i = m.end()
                return self.build_local_time(m)
        m = _VALUE_RUN.match(s, i)
        if m is None:
            self.fail("expected a value")
        text = m.group()
        clean = text.replace("_", "")
        if _DEC_INT.fullmatch(text):
            value = _dec_int(clean)
        elif _HEX_INT.fullmatch(text):
            value = int(clean[2:], 16)
        elif _OCT_INT.fullmatch(text):
            value = int(clean[2:], 8)
        elif _BIN_INT.fullmatch(text):
            value = int(clean[2:], 2)
        elif _FLOAT.fullmatch(text) or _SPECIAL_FLOAT.fullmatch(text):
            value = self.convert_float(text, clean)
        else:
            self.fail("invalid value {!r}".format(text), i)
        self.i = m.end()
        return value

# spec: N-000223 N-000224 N-000225 N-000226 N-000227 N-000232 N-000233 N-000287 N-000288
    def convert_float(self, text, clean):
        if self.parse_float is float:
            return float(clean)
        value = self.parse_float(text)
        if isinstance(value, (dict, list)):
            raise ValueError(
                "parse_float must not return a dict or list (got {})".format(type(value).__name__)
            )
        return value

# spec: N-000151 N-000152 N-000153 N-000154 N-000159 N-000179 N-000180 N-000288 N-000289 N-000158
    def build_datetime(self, m):
        year, month, day = int(m.group("y")), int(m.group("mo")), int(m.group("d"))
        try:
            calendar_date = date(year, month, day)
        except ValueError:
            self.fail("invalid calendar date", m.start())
        if m.group("H") is None:
            return calendar_date
        hour, minute = int(m.group("H")), int(m.group("M"))
        second = int(m.group("S") or 0)
        micro = self.microseconds(m.group("f"))
        if hour > 23 or minute > 59 or second > 59:
            self.fail("time out of range", m.start("H"))
        zone = m.group("z")
        tzinfo = None
        if zone is not None:
            if zone in ("Z", "z"):
                tzinfo = timezone.utc
            else:
                off_hours, off_minutes = int(zone[1:3]), int(zone[4:6])
                if off_hours > 23 or off_minutes > 59:
                    self.fail("UTC offset out of range", m.start("z"))
                offset = timedelta(hours=off_hours, minutes=off_minutes)
                if zone[0] == "-":
                    offset = -offset
                tzinfo = timezone(offset)
        return datetime(year, month, day, hour, minute, second, micro, tzinfo=tzinfo)

# spec: N-000155 N-000156 N-000157 N-000158 N-000291 N-000179 N-000180 N-000027
    def build_local_time(self, m):
        hour, minute = int(m.group("H")), int(m.group("M"))
        second = int(m.group("S") or 0)
        if hour > 23 or minute > 59 or second > 59:
            self.fail("time out of range", m.start())
        return time(hour, minute, second, self.microseconds(m.group("f")))

    @staticmethod
    def microseconds(fraction):
        if fraction is None:
            return 0
        return int((fraction + "000000")[:6])

    # ----- strings -------------------------------------------------------------

# spec: N-000137 N-000138 N-000139 N-000140 N-000174 N-000175 N-000176 N-000177
    def escape(self, i):
        """Decode the escape starting at the backslash at ``i``.

        Returns the produced character and the offset just past the escape.
        """
        s, n = self.s, self.n
        if i + 1 >= n:
            self.fail("unfinished escape", i)
        code = s[i + 1]
        if code in _SIMPLE_ESCAPES:
            return _SIMPLE_ESCAPES[code], i + 2
        if code in _UNICODE_ESCAPE_LENGTHS:
            width = _UNICODE_ESCAPE_LENGTHS[code]
            digits = s[i + 2:i + 2 + width]
            if len(digits) != width or not all(d in _HEX_DIGITS for d in digits):
                self.fail("invalid \\{} escape".format(code), i)
            point = int(digits, 16)
            if point > 0x10FFFF or 0xD800 <= point <= 0xDFFF:
                self.fail("escape is not a Unicode scalar value", i)
            return chr(point), i + 2 + width
        self.fail("invalid escape sequence", i)

# spec: N-000127 N-000128 N-000137 N-000140 N-000178 N-000160 N-000161
    def single_basic(self):
        s, n = self.s, self.n
        i = self.i + 1
        out = []
        while True:
            m = _BASIC_PLAIN.match(s, i)
            if m is not None:
                out.append(m.group())
                i = m.end()
                continue
            if i >= n:
                self.fail("unterminated string", i)
            c = s[i]
            if c == '"':
                self.i = i + 1
                return "".join(out)
            if c == "\\":
                ch, i = self.escape(i)
                out.append(ch)
                continue
            self.fail("invalid character in string", i)

# spec: N-000127 N-000129 N-000141 N-000178
    def single_literal(self):
        s, n = self.s, self.n
        i = self.i + 1
        out = []
        while True:
            m = _LITERAL_PLAIN.match(s, i)
            if m is not None:
                out.append(m.group())
                i = m.end()
                continue
            if i >= n:
                self.fail("unterminated string", i)
            if s[i] == "'":
                self.i = i + 1
                return "".join(out)
            self.fail("invalid character in string", i)

    def _closing_run(self, i, quote):
        """Return the length of the run of ``quote`` characters starting at ``i``."""
        s, n = self.s, self.n
        j = i
        while j < n and s[j] == quote:
            j += 1
        return j - i

# spec: N-000127 N-000128 N-000131 N-000132 N-000133 N-000134 N-000135 N-000136 N-000178
    def multi_basic(self):
        s, n = self.s, self.n
        i = self.i + 3
        if s.startswith("\n", i):
            i += 1
        out = []
        while True:
            m = _ML_BASIC_PLAIN.match(s, i)
            if m is not None:
                out.append(m.group())
                i = m.end()
                continue
            if i >= n:
                self.fail("unterminated multiline string", i)
            c = s[i]
            if c == '"':
                run = self._closing_run(i, '"')
                if run >= 3:
                    if run > 5:
                        self.fail("too many quotes before closing delimiter", i)
                    out.append('"' * (run - 3))
                    self.i = i + run
                    return "".join(out)
                out.append('"' * run)
                i += run
                continue
            if c == "\\":
                j = i + 1
                while j < n and s[j] in " \t":
                    j += 1
                if j < n and s[j] == "\n":
                    i = j + 1
                    while i < n and s[i] in " \t\n":
                        i += 1
                    continue
                ch, i = self.escape(i)
                out.append(ch)
                continue
            self.fail("invalid character in multiline string", i)

# spec: N-000127 N-000129 N-000131 N-000132 N-000135 N-000178
    def multi_literal(self):
        s, n = self.s, self.n
        i = self.i + 3
        if s.startswith("\n", i):
            i += 1
        out = []
        while True:
            m = _ML_LITERAL_PLAIN.match(s, i)
            if m is not None:
                out.append(m.group())
                i = m.end()
                continue
            if i >= n:
                self.fail("unterminated multiline string", i)
            c = s[i]
            if c == "'":
                run = self._closing_run(i, "'")
                if run >= 3:
                    if run > 5:
                        self.fail("too many quotes before closing delimiter", i)
                    out.append("'" * (run - 3))
                    self.i = i + run
                    return "".join(out)
                out.append("'" * run)
                i += run
                continue
            self.fail("invalid character in multiline string", i)


def parse_document(text, parse_float):
    """Parse normalized ``text``; raise ``ParseFailure`` on invalid input."""
    return _Parser(text, parse_float).parse()
