"""Tomlparse: a pure-Python parser for TOML v1.1.0 documents."""

from ._errors import TOMLDecodeError
from ._parser import load, loads

__all__ = ["loads", "load", "TOMLDecodeError"]
__version__ = "2.4.0"
