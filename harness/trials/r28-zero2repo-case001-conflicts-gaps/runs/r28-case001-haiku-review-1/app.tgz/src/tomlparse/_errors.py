"""The parse-failure exception of Tomlparse."""


class TOMLDecodeError(ValueError):
    """Raised when a document is not valid TOML v1.1.0.

    Constructed as ``TOMLDecodeError(msg, doc, pos)``: ``msg`` is the unformatted
    reason, ``doc`` the document text and ``pos`` a 0-based character offset into
    ``doc``. ``lineno`` and ``colno`` are 1-based and derived from ``pos``.
    """

    def __init__(self, msg, doc, pos):
        ValueError.__init__(self, msg, doc, pos)
        self.msg = msg
        self.doc = doc
        self.pos = pos
        self.lineno = doc.count("\n", 0, pos) + 1
        self.colno = pos - doc.rfind("\n", 0, pos)

    def __str__(self):
        where = "line %d, column %d, char %d" % (self.lineno, self.colno, self.pos)
        if self.pos >= len(self.doc):
            return "%s (at end of document; %s)" % (self.msg, where)
        return "%s (%s)" % (self.msg, where)
