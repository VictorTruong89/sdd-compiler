"""Recursive-descent TOML v1.1.0 parser producing native Python values.

Table bookkeeping: every dict/list the parser creates carries a state kept in
``_Parser.state`` (keyed by ``id``; the objects are also kept alive in
``_Parser.keep``):

* dict states: ``header`` (defined by a ``[table]`` header or the root),
  ``implicit`` (created as a missing parent of a header, not yet defined),
  ``dotted`` (created by dotted keys), ``inline`` (an inline table, frozen);
* list states: ``aot`` (array of tables), ``static`` (ordinary array).

Nested arrays and inline tables are parsed with an explicit stack, so deep
nesting never raises ``RecursionError``.
"""

import io
import re
from datetime import date, datetime, time as _clock_time, timedelta, timezone

from ._errors import TOMLDecodeError

_DIGITS = "0123456789"
_HEXDIGITS = frozenset("0123456789abcdefABCDEF")
_BARE_RE = re.compile(r"[A-Za-z0-9_-]+")
_TOKEN_RE = re.compile(r"[A-Za-z0-9_+\-.]*")
_DEC_INT_RE = re.compile(r"[+-]?(?:0|[1-9](?:_?[0-9])*)")
_HEX_INT_RE = re.compile(r"0x[0-9A-Fa-f](?:_?[0-9A-Fa-f])*")
_OCT_INT_RE = re.compile(r"0o[0-7](?:_?[0-7])*")
_BIN_INT_RE = re.compile(r"0b[01](?:_?[01])*")
_FLOAT_RE = re.compile(
    r"[+-]?(?:0|[1-9](?:_?[0-9])*)"
    r"(?:\.[0-9](?:_?[0-9])*(?:[eE][+-]?[0-9](?:_?[0-9])*)?"
    r"|[eE][+-]?[0-9](?:_?[0-9])*)"
)
_SPECIAL_FLOAT_RE = re.compile(r"[+-]?(?:inf|nan)")
_DATETIME_RE = re.compile(
    r"(?P<y>[0-9]{4})-(?P<mo>[0-9]{2})-(?P<d>[0-9]{2})"
    r"(?:(?:[Tt]| (?=[0-9]{2}:))"
    r"(?P<h>[0-9]{2}):(?P<mi>[0-9]{2})"
    r"(?::(?P<s>[0-9]{2})(?:\.(?P<f>[0-9]+))?)?"
    r"(?:(?P<z>[Zz])|(?P<sign>[+-])(?P<oh>[0-9]{2}):(?P<om>[0-9]{2}))?"
    r")?"
)
_LOCALTIME_RE = re.compile(
    r"(?P<h>[0-9]{2}):(?P<mi>[0-9]{2})"
    r"(?::(?P<s>[0-9]{2})(?:\.(?P<f>[0-9]+))?)?"
)

_SIMPLE_ESCAPES = {
    "b": "\b",
    "t": "\t",
    "n": "\n",
    "f": "\f",
    "r": "\r",
    "e": "\x1b",
    '"': '"',
    "\\": "\\",
}
_UNICODE_ESCAPES = {"x": 2, "u": 4, "U": 8}
_BASES = {"0x": (_HEX_INT_RE, 16), "0o": (_OCT_INT_RE, 8), "0b": (_BIN_INT_RE, 2)}


def _is_ctrl(c):
    """Control characters that TOML forbids unescaped (tab excluded)."""
    o = ord(c)
    return (o < 0x20 and c != "\t") or o == 0x7F


class _Parser:
    def __init__(self, doc, parse_float):
        self.s = doc
        self.n = len(doc)
        self.parse_float = parse_float
        self.state = {}
        self.keep = []
        self.root = self._new_table("header")

    # ------------------------------------------------------------------
    # helpers

    def _err(self, msg, pos):
        raise TOMLDecodeError(msg, self.s, pos)

    def _ch(self, pos):
        return self.s[pos] if pos < self.n else ""

    def _new_table(self, state):
        d = {}
        self.state[id(d)] = state
        self.keep.append(d)
        return d

    def _new_list(self, state):
        lst = []
        self.state[id(lst)] = state
        self.keep.append(lst)
        return lst

    def _state_of(self, obj):
        return self.state.get(id(obj))

    def _ws(self, pos):
        """Skip spaces and tabs."""
        s, n = self.s, self.n
        while pos < n and s[pos] in " \t":
            pos += 1
        return pos

    def _newline_len(self, pos):
        """Length of the line ending at pos (LF or CRLF), or 0."""
        if pos < self.n:
            if self.s[pos] == "\n":
                return 1
            if self.s[pos] == "\r" and self.s.startswith("\n", pos + 1):
                return 2
        return 0

    def _comment(self, pos):
        """pos is at '#'; returns the position of the line ending (or end)."""
        s, n = self.s, self.n
        i = pos + 1
        while i < n:
            c = s[i]
            if c == "\n" or (c == "\r" and s.startswith("\n", i + 1)):
                break
            if _is_ctrl(c):
                self._err("control character in comment", i)
            i += 1
        return i

    def _ws_nl(self, pos):
        """Skip whitespace, line endings and comments (inside brackets)."""
        while True:
            pos = self._ws(pos)
            nl = self._newline_len(pos)
            if nl:
                pos += nl
            elif self._ch(pos) == "#":
                pos = self._comment(pos)
            else:
                return pos

    def _eol(self, pos):
        """Expect the end of a line (optional comment, then line ending or end)."""
        pos = self._ws(pos)
        if self._ch(pos) == "#":
            pos = self._comment(pos)
        if pos >= self.n:
            return pos
        nl = self._newline_len(pos)
        if nl:
            return pos + nl
        self._err("expected end of line", pos)

    def _run(self, pos, q):
        i = pos
        while i < self.n and self.s[i] == q:
            i += 1
        return i - pos

    # ------------------------------------------------------------------
    # strings

    def _escape(self, pos):
        """pos is at a backslash; returns (character, position after escape)."""
        e = self._ch(pos + 1)
        if e in _SIMPLE_ESCAPES:
            return _SIMPLE_ESCAPES[e], pos + 2
        if e in _UNICODE_ESCAPES:
            k = _UNICODE_ESCAPES[e]
            digits = self.s[pos + 2:pos + 2 + k]
            if len(digits) == k and all(c in _HEXDIGITS for c in digits):
                cp = int(digits, 16)
                if cp > 0x10FFFF or 0xD800 <= cp <= 0xDFFF:
                    self._err("escaped code point is not a Unicode scalar value", pos)
                return chr(cp), pos + 2 + k
            self._err("invalid unicode escape", pos)
        self._err("invalid escape sequence", pos)

    def _basic(self, pos):
        """Single-line basic string; pos is at the opening quote."""
        s, n = self.s, self.n
        start = pos
        pos += 1
        buf = []
        while True:
            if pos >= n:
                self._err("unterminated string", start)
            c = s[pos]
            if c == '"':
                return "".join(buf), pos + 1
            if c == "\\":
                ch, pos = self._escape(pos)
                buf.append(ch)
                continue
            if c in "\r\n" or _is_ctrl(c):
                self._err("invalid character in string", pos)
            buf.append(c)
            pos += 1

    def _literal(self, pos):
        """Single-line literal string; pos is at the opening apostrophe."""
        s, n = self.s, self.n
        start = pos
        pos += 1
        i = pos
        while True:
            if i >= n:
                self._err("unterminated string", start)
            c = s[i]
            if c == "'":
                return s[pos:i], i + 1
            if c in "\r\n" or _is_ctrl(c):
                self._err("invalid character in string", i)
            i += 1

    def _multiline(self, pos, literal):
        """Multiline basic (or literal) string; pos is at the first of three quotes."""
        s, n = self.s, self.n
        start = pos
        quote = "'" if literal else '"'
        pos += 3
        pos += self._newline_len(pos)  # a newline right after the delimiter is trimmed
        buf = []
        while True:
            if pos >= n:
                self._err("unterminated multiline string", start)
            c = s[pos]
            if c == quote:
                run = self._run(pos, quote)
                if run < 3:
                    buf.append(quote * run)
                    pos += run
                    continue
                if run > 5:
                    self._err("too many quote characters before closing delimiter", pos)
                buf.append(quote * (run - 3))
                return "".join(buf), pos + run
            if c == "\\" and not literal:
                j = self._ws(pos + 1)
                nl = self._newline_len(j)
                if nl:
                    # line-ending backslash: trim it and all following whitespace
                    pos = j + nl
                    while pos < n:
                        ch = s[pos]
                        if ch in " \t\n":
                            pos += 1
                        elif ch == "\r" and s.startswith("\n", pos + 1):
                            pos += 2
                        else:
                            break
                    continue
                ch, pos = self._escape(pos)
                buf.append(ch)
                continue
            if c == "\r":
                if s.startswith("\n", pos + 1):
                    buf.append("\n")
                    pos += 2
                    continue
                self._err("bare carriage return in string", pos)
            if c == "\n":
                buf.append("\n")
                pos += 1
                continue
            if _is_ctrl(c):
                self._err("control character in string", pos)
            buf.append(c)
            pos += 1

    # ------------------------------------------------------------------
    # keys

    def _key(self, pos):
        """Parse a (possibly dotted) key; returns (list of parts, position after)."""
        parts = []
        while True:
            pos = self._ws(pos)
            c = self._ch(pos)
            if c == '"':
                key, pos = self._basic(pos)
            elif c == "'":
                key, pos = self._literal(pos)
            else:
                m = _BARE_RE.match(self.s, pos)
                if not m:
                    self._err("expected a key", pos)
                key = m.group()
                pos = m.end()
            parts.append(key)
            after = self._ws(pos)
            if self._ch(after) == ".":
                pos = after + 1
                continue
            return parts, pos

    def _dotted_target(self, cur, keys, pos):
        """Create the intermediate tables of a dotted key below ``cur``.

        Returns (container, final key) where the value is to be stored.
        """
        for key in keys[:-1]:
            if key in cur:
                nxt = cur[key]
                if isinstance(nxt, dict) and self._state_of(nxt) == "dotted":
                    cur = nxt
                    continue
                self._err("dotted key redefines an existing table or value", pos)
            new = self._new_table("dotted")
            cur[key] = new
            cur = new
        last = keys[-1]
        if last in cur:
            self._err("duplicate key", pos)
        return cur, last

    def _header_table(self, keys, aot, pos):
        """Resolve a [table] or [[array of tables]] header to its table."""
        cur = self.root
        for key in keys[:-1]:
            if key in cur:
                nxt = cur[key]
                if isinstance(nxt, list):
                    if self._state_of(nxt) != "aot":
                        self._err("table header goes through a static array", pos)
                    cur = nxt[-1]
                elif isinstance(nxt, dict):
                    if self._state_of(nxt) == "inline":
                        self._err("table header extends an inline table", pos)
                    cur = nxt
                else:
                    self._err("table header redefines a value", pos)
            else:
                new = self._new_table("implicit")
                cur[key] = new
                cur = new
        last = keys[-1]
        if aot:
            if last in cur:
                arr = cur[last]
                if not isinstance(arr, list) or self._state_of(arr) != "aot":
                    self._err("array of tables redefines a value", pos)
            else:
                arr = self._new_list("aot")
                cur[last] = arr
            elem = self._new_table("header")
            arr.append(elem)
            return elem
        if last in cur:
            nxt = cur[last]
            if isinstance(nxt, dict) and self._state_of(nxt) == "implicit":
                self.state[id(nxt)] = "header"
                return nxt
            self._err("table is already defined", pos)
        new = self._new_table("header")
        cur[last] = new
        return new

    # ------------------------------------------------------------------
    # scalars

    def _float(self, tok, pos):
        value = self.parse_float(tok)
        if isinstance(value, (dict, list)):
            raise ValueError("parse_float returned a dict or list, which is not allowed")
        return value

    def _clock(self, g, pos):
        hour = int(g["h"])
        minute = int(g["mi"])
        sec = int(g["s"] or 0)
        frac = g["f"] or ""
        usec = int(frac[:6].ljust(6, "0")) if frac else 0
        if hour > 23 or minute > 59 or sec > 59:
            self._err("invalid time", pos)
        return hour, minute, sec, usec

    def _datetime(self, m, pos):
        g = m.groupdict()
        try:
            day = date(int(g["y"]), int(g["mo"]), int(g["d"]))
        except ValueError:
            self._err("invalid date", pos)
        if g["h"] is None:
            return day
        hour, minute, sec, usec = self._clock(g, pos)
        tz = None
        if g["z"]:
            tz = timezone.utc
        elif g["sign"]:
            oh = int(g["oh"])
            om = int(g["om"])
            if oh > 23 or om > 59:
                self._err("invalid UTC offset", pos)
            delta = timedelta(hours=oh, minutes=om)
            tz = timezone(-delta if g["sign"] == "-" else delta)
        return datetime(day.year, day.month, day.day, hour, minute, sec, usec, tzinfo=tz)

    def _scalar(self, pos):
        """Parse a non-container value at pos; returns (value, position after)."""
        s = self.s
        c = self._ch(pos)
        if c == '"':
            if s.startswith('"""', pos):
                return self._multiline(pos, False)
            return self._basic(pos)
        if c == "'":
            if s.startswith("'''", pos):
                return self._multiline(pos, True)
            return self._literal(pos)
        if c and c in _DIGITS:
            m = _DATETIME_RE.match(s, pos)
            if m:
                return self._datetime(m, pos), m.end()
            m = _LOCALTIME_RE.match(s, pos)
            if m:
                return _clock_time(*self._clock(m.groupdict(), pos)), m.end()
        end = _TOKEN_RE.match(s, pos).end()
        tok = s[pos:end]
        if tok == "true":
            return True, end
        if tok == "false":
            return False, end
        if _DEC_INT_RE.fullmatch(tok):
            return int(tok.replace("_", "")), end
        if tok[:2] in _BASES:
            rx, base = _BASES[tok[:2]]
            if rx.fullmatch(tok):
                return int(tok[2:].replace("_", ""), base), end
            self._err("invalid integer", pos)
        if _FLOAT_RE.fullmatch(tok) or _SPECIAL_FLOAT_RE.fullmatch(tok):
            return self._float(tok, pos), end
        self._err("invalid value", pos)

    # ------------------------------------------------------------------
    # values (arrays and inline tables use an explicit stack)

    def _value(self, pos):
        """Parse a value starting at pos; returns (value, position after)."""
        stack = []
        while True:
            c = self._ch(pos)
            if c == "[":
                arr = self._new_list("static")
                p = self._ws_nl(pos + 1)
                if self._ch(p) == "]":
                    value, pos = arr, p + 1
                else:
                    stack.append(["array", arr, None, None, None])
                    pos = p
                    continue
            elif c == "{":
                tbl = self._new_table("inline")
                p = self._ws_nl(pos + 1)
                if self._ch(p) == "}":
                    value, pos = tbl, p + 1
                else:
                    frame = self._inline_pair(tbl, p)
                    stack.append(frame)
                    pos = frame[4]
                    continue
            else:
                value, pos = self._scalar(pos)

            # deliver the completed value to its parent
            while True:
                if not stack:
                    return value, pos
                top = stack[-1]
                if top[0] == "array":
                    top[1].append(value)
                    p = self._ws_nl(pos)
                    c = self._ch(p)
                    if c == ",":
                        p = self._ws_nl(p + 1)
                        if self._ch(p) == "]":
                            value, pos = top[1], p + 1
                            stack.pop()
                            continue
                        pos = p
                        break  # parse the next element
                    if c == "]":
                        value, pos = top[1], p + 1
                        stack.pop()
                        continue
                    self._err("expected ',' or ']' in array", p)
                else:  # inline table
                    top[2][top[3]] = value
                    p = self._ws_nl(pos)
                    c = self._ch(p)
                    if c == ",":
                        p = self._ws_nl(p + 1)
                        if self._ch(p) == "}":
                            value, pos = top[1], p + 1
                            stack.pop()
                            continue
                        frame = self._inline_pair(top[1], p)
                        stack[-1] = frame
                        pos = frame[4]
                        break  # parse the next pair's value
                    if c == "}":
                        value, pos = top[1], p + 1
                        stack.pop()
                        continue
                    self._err("expected ',' or '}' in inline table", p)

    def _inline_pair(self, tbl, pos):
        """Parse ``key = `` inside an inline table; returns a pending frame.

        The frame is ['inline', tbl, container, key, value_position].
        """
        keys, p = self._key(pos)
        p = self._ws(p)
        if self._ch(p) != "=":
            self._err("expected '=' after key", p)
        p = self._ws(p + 1)
        container, last = self._dotted_target(tbl, keys, pos)
        return ["inline", tbl, container, last, p]  # value starts at p

    # ------------------------------------------------------------------
    # document

    def _header(self, pos):
        aot = self.s.startswith("[[", pos)
        p = pos + 2 if aot else pos + 1
        keys, p = self._key(p)
        p = self._ws(p)
        close = "]]" if aot else "]"
        if not self.s.startswith(close, p):
            self._err("expected closing bracket of table header", p)
        return self._header_table(keys, aot, pos), p + len(close)

    def parse(self):
        s, n = self.s, self.n
        pos = 0
        current = self.root
        while pos < n:
            c = s[pos]
            if c in " \t":
                pos += 1
                continue
            nl = self._newline_len(pos)
            if nl:
                pos += nl
                continue
            if c == "#":
                pos = self._comment(pos)
                continue
            if c == "[":
                current, pos = self._header(pos)
                pos = self._eol(pos)
                continue
            keys, after = self._key(pos)
            p = self._ws(after)
            if self._ch(p) != "=":
                self._err("expected '=' after key", p)
            container, last = self._dotted_target(current, keys, pos)
            value, p = self._value(self._ws(p + 1))
            container[last] = value
            pos = self._eol(p)
        return self.root


def loads(s, *, parse_float=float):
    """Parse a TOML v1.1.0 document from a text string into a dict."""
    if not isinstance(s, str):
        raise TypeError("loads() expects a str, not %s" % type(s).__name__)
    return _Parser(s, parse_float).parse()


def load(fp, *, parse_float=float):
    """Parse a TOML v1.1.0 document from a file object opened in binary mode."""
    if isinstance(fp, io.TextIOBase):
        raise TypeError("load() expects a binary file object, not a text-mode file")
    data = fp.read()
    if isinstance(data, str):
        raise TypeError("load() expects a binary file object, not a text-mode file")
    if not isinstance(data, (bytes, bytearray, memoryview)):
        raise TypeError("load() expects a binary file object")
    data = bytes(data)
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        # The decoded text cannot be formed; report against the replacement-decoded text.
        text = data.decode("utf-8", "replace")
        prefix_chars = len(data[:exc.start].decode("utf-8"))
        raise TOMLDecodeError("document is not valid UTF-8", text, prefix_chars)
    return loads(text, parse_float=parse_float)
