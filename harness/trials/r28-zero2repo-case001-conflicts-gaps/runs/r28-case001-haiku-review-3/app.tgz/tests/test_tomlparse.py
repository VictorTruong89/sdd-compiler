import datetime as dt
import decimal
import io
import unittest

from tomlparse import TOMLDecodeError, load, loads


class ParseTests(unittest.TestCase):

    def test_empty_and_comments(self):
        self.assertEqual(loads(""), {})
        self.assertEqual(loads("  \n# only a comment"), {})

    def test_tables_and_dotted_keys(self):
        self.assertEqual(loads("a.b.c = 1"), {"a": {"b": {"c": 1}}})
        self.assertEqual(loads("[a.b]\nx=1\n[a]\ny=2"),
                         {"a": {"b": {"x": 1}, "y": 2}})
        self.assertEqual(loads("[fruit]\napple.color = 'red'\n[fruit.apple.texture]\nsmooth = true"),
                         {"fruit": {"apple": {"color": "red", "texture": {"smooth": True}}}})

    def test_arrays_of_tables(self):
        self.assertEqual(
            loads("[[p]]\na=1\n[[p]]\na=2\n[p.sub]\nk=3"),
            {"p": [{"a": 1}, {"a": 2, "sub": {"k": 3}}]})

    def test_strings(self):
        self.assertEqual(loads(r'a = "x\t\e\x41\u00e9\U0001F600"'),
                         {"a": "x\t\x1bA\u00e9\U0001F600"})
        self.assertEqual(loads("a = '''\nx'''"), {"a": "x"})
        self.assertEqual(loads('a = """\nl1\\\n   l2"""'), {"a": "l1l2"})
        self.assertEqual(loads('a = """a""""'), {"a": 'a"'})

    def test_numbers_and_datetimes(self):
        r = loads("a=1_000\nb=0xdead_BEEF\nc=0o755\nd=0b11\ne=-0\nf=6.626e-34\ng=inf\nh=-nan")
        self.assertEqual(r["a"], 1000)
        self.assertEqual(r["b"], 0xDEADBEEF)
        self.assertEqual((r["c"], r["d"], r["e"]), (0o755, 3, 0))
        self.assertEqual(r["f"], 6.626e-34)
        self.assertEqual(r["g"], float("inf"))
        self.assertTrue(r["h"] != r["h"])
        r = loads("o = 1979-05-27T07:32:00.1234567Z\nl = 07:32\nd = 1979-05-27")
        self.assertEqual(r["o"], dt.datetime(1979, 5, 27, 7, 32, 0, 123456, tzinfo=dt.timezone.utc))
        self.assertEqual(r["l"], dt.time(7, 32))
        self.assertEqual(r["d"], dt.date(1979, 5, 27))

    def test_trailing_commas(self):
        self.assertEqual(loads("a = [1, 2,]"), {"a": [1, 2]})
        self.assertEqual(loads("a = {x = 1,}"), {"a": {"x": 1}})

    def test_refusals(self):
        for doc in ["a = 1\na = 2", "[a]\n[a]", "a.b = 1\n[a.b]", "[[a]]\n[a]",
                    "a = 01", "a = 1979-02-29", "a = 'x", "a = {x=1}\n[a.y]",
                    "a = \"\\uD800\"", "a = 1 b = 2"]:
            with self.subTest(doc=doc):
                with self.assertRaises(TOMLDecodeError):
                    loads(doc)

    def test_error_location(self):
        err = None
        try:
            loads("a = 1\nb = @")
        except TOMLDecodeError as exc:
            err = exc
        self.assertEqual((err.pos, err.lineno, err.colno), (10, 2, 5))

    def test_wrong_type_is_type_error(self):
        with self.assertRaises(TypeError):
            loads(b"a = 1")
        with self.assertRaises(TypeError):
            load(io.StringIO("a = 1"))

    def test_load_binary(self):
        self.assertEqual(load(io.BytesIO(b"a = 1\r\nb = 'x'")), {"a": 1, "b": "x"})
        self.assertEqual(load(io.BytesIO(b"")), {})

    def test_parse_float(self):
        seen = []

        def conv(text):
            seen.append(text)
            return decimal.Decimal(text)

        r = loads("a = 1.5\nb = 2\nc = -inf", parse_float=conv)
        self.assertEqual(r["a"], decimal.Decimal("1.5"))
        self.assertEqual(r["b"], 2)
        self.assertEqual(seen, ["1.5", "-inf"])

        class D(dict):
            pass

        with self.assertRaises(ValueError) as ctx:
            loads("a = 1.5", parse_float=lambda s: D())
        self.assertNotIsInstance(ctx.exception, TOMLDecodeError)


class ErrorTests(unittest.TestCase):

    def test_constructed_error(self):
        err = TOMLDecodeError("bad", "ab\ncd", 4)
        self.assertEqual((err.lineno, err.colno), (2, 2))
        self.assertIsInstance(err, ValueError)
        self.assertIn("line 2", str(err))


if __name__ == "__main__":
    unittest.main()
