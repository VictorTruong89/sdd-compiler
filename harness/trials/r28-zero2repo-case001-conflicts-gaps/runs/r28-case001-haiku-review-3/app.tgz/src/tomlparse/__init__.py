"""tomlparse: a pure-Python TOML v1.1.0 parser.

Public names: ``loads`` (text string), ``load`` (binary file object) and
``TOMLDecodeError``.
"""

from ._parser import TOMLDecodeError, load, loads

__all__ = ["loads", "load", "TOMLDecodeError"]
__version__ = "2.4.0"
