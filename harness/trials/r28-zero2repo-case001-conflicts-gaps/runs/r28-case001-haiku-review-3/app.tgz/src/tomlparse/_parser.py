"""Pure-Python TOML v1.1.0 parser.

The whole grammar is implemented here: a character-position scanner with
small regular expressions for token shapes. No other TOML parser is used.
"""

import datetime as _datetime
import re as _re

__all__ = ["loads", "load", "TOMLDecodeError"]


class TOMLDecodeError(ValueError):
    """A document is not valid TOML v1.1.0.

    Constructed as ``TOMLDecodeError(msg, doc, pos)``; ``pos`` is a 0-based
    character offset into ``doc``. ``lineno`` and ``colno`` are 1-based and
    derived from ``pos``.
    """

    def __init__(self, msg, doc, pos):
        ValueError.__init__(self, msg, doc, pos)
        self.msg = msg
        self.doc = doc
        self.pos = pos
        self.lineno = doc.count("\n", 0, pos) + 1
        self.colno = pos - doc.rfind("\n", 0, pos)
        if pos >= len(doc):
            self._report = "%s (line %d, column %d, at end of document)" % (
                msg, self.lineno, self.colno)
        else:
            self._report = "%s (line %d, column %d)" % (msg, self.lineno, self.colno)

    def __str__(self):
        return self._report


# --- token shapes -----------------------------------------------------------

_WS = _re.compile(r"[ \t]*")
_WS_NL = _re.compile(r"[ \t\n]*")
_COMMENT = _re.compile(r"[^\x00-\x08\x0a-\x1f\x7f]*")
_BARE_KEY = _re.compile(r"[A-Za-z0-9_-]+")

_DATETIME = _re.compile(
    r"([0-9]{4})-([0-9]{2})-([0-9]{2})"
    r"(?:[Tt ]([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?"
    r"([Zz]|[+-][0-9]{2}:[0-9]{2})?)?"
)
_LOCALTIME = _re.compile(r"([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?")
_PREFIXED = _re.compile(
    r"0(?:x[0-9a-fA-F](?:_?[0-9a-fA-F])*"
    r"|o[0-7](?:_?[0-7])*"
    r"|b[01](?:_?[01])*)"
)
_FLOAT = _re.compile(
    r"[+-]?(?:0|[1-9](?:_?[0-9])*)"
    r"(?:\.[0-9](?:_?[0-9])*(?:[eE][+-]?[0-9](?:_?[0-9])*)?"
    r"|[eE][+-]?[0-9](?:_?[0-9])*)"
)
_SPECIAL_FLOAT = _re.compile(r"[+-]?(?:inf|nan)")
_DECINT = _re.compile(r"[+-]?(?:0|[1-9](?:_?[0-9])*)")

# String body runs: stop at the quote, at a backslash (escaped strings only),
# and at control characters that are not allowed in that string form.
_CHUNKS = {
    ('"', False): _re.compile(r'[^"\\\x00-\x08\x0a-\x1f\x7f]*'),
    ('"', True): _re.compile(r'[^"\\\x00-\x08\x0b-\x1f\x7f]*'),
    ("'", False): _re.compile(r"[^'\x00-\x08\x0a-\x1f\x7f]*"),
    ("'", True): _re.compile(r"[^'\x00-\x08\x0b-\x1f\x7f]*"),
}

_SIMPLE_ESC = {
    "b": "\b", "t": "\t", "n": "\n", "f": "\f", "r": "\r",
    "e": "\x1b", '"': '"', "\\": "\\",
}
_ESC_SIZE = {"x": 2, "u": 4, "U": 8}
_HEX = frozenset("0123456789abcdefABCDEF")

# Table kinds stored in _Parser.kinds (keyed by id). Lists without an entry
# are static arrays; dicts without an entry are only the root.
_DOTTABLE = ("dotted", "implicit")


def _micro(frac):
    if not frac:
        return 0
    return int((frac + "000000")[:6])


class _Parser(object):

    def __init__(self, doc, text, cr, parse_float):
        self.doc = doc            # original document text (for errors)
        self.t = text             # text with CR/LF pairs folded to LF
        self.n = len(text)
        self.i = 0
        self.cr = cr              # original indices of folded CR characters
        self.parse_float = parse_float
        self.custom_float = parse_float is not float
        self.root = {}
        self.kinds = {}
        self.current = self.root

    # --- errors -------------------------------------------------------------

    def _orig(self, pos):
        orig = pos
        for r in self.cr:
            if r <= orig:
                orig += 1
            else:
                break
        return orig

    def fail(self, msg, pos=None):
        if pos is None:
            pos = self.i
        raise TOMLDecodeError(msg, self.doc, self._orig(pos))

    def peek(self):
        return self.t[self.i] if self.i < self.n else ""

    def skip_ws(self):
        self.i = _WS.match(self.t, self.i).end()

    def skip_ws_nl(self):
        while True:
            self.i = _WS_NL.match(self.t, self.i).end()
            if self.peek() == "#":
                self.comment()
            else:
                return

    def comment(self):
        self.i = _COMMENT.match(self.t, self.i + 1).end()
        if self.i < self.n and self.t[self.i] != "\n":
            self.fail("control character in comment")

    # --- document -----------------------------------------------------------

    def run(self):
        t = self.t
        while True:
            self.skip_ws()
            if self.i >= self.n:
                break
            c = t[self.i]
            if c == "\n":
                self.i += 1
                continue
            if c == "#":
                self.comment()
                continue
            if c == "[":
                self.header()
            else:
                self.keyval(self.current)
            self.skip_ws()
            if self.peek() == "#":
                self.comment()
            c = self.peek()
            if c and c != "\n":
                self.fail("expected end of line")
        return self.root

    def header(self):
        aot = self.t.startswith("[[", self.i)
        self.i += 2 if aot else 1
        self.skip_ws()
        kpos = self.i
        parts = self.key()
        self.skip_ws()
        close = "]]" if aot else "]"
        if not self.t.startswith(close, self.i):
            self.fail("expected '%s' after table name" % close)
        self.i += len(close)
        self.current = self.define_table(parts, aot, kpos)

    def define_table(self, parts, aot, kpos):
        kinds = self.kinds
        cur = self.root
        for part in parts[:-1]:
            if part not in cur:
                nxt = {}
                kinds[id(nxt)] = "implicit"
                cur[part] = nxt
                cur = nxt
                continue
            nxt = cur[part]
            if isinstance(nxt, list):
                if kinds.get(id(nxt)) != "aot" or not nxt:
                    self.fail("table name conflicts with an existing value", kpos)
                nxt = nxt[-1]
            if not isinstance(nxt, dict) or kinds.get(id(nxt)) == "inline":
                self.fail("table name conflicts with an existing value", kpos)
            cur = nxt

        last = parts[-1]
        if aot:
            if last not in cur:
                lst = []
                kinds[id(lst)] = "aot"
                cur[last] = lst
            else:
                lst = cur[last]
                if not isinstance(lst, list) or kinds.get(id(lst)) != "aot":
                    self.fail("array of tables conflicts with an existing value", kpos)
            new = {}
            kinds[id(new)] = "header"
            lst.append(new)
            return new

        if last not in cur:
            new = {}
            kinds[id(new)] = "header"
            cur[last] = new
            return new
        nxt = cur[last]
        if isinstance(nxt, dict) and kinds.get(id(nxt)) == "implicit":
            kinds[id(nxt)] = "header"
            return nxt
        self.fail("table is already defined", kpos)

    def key(self):
        parts = [self.simple_key()]
        while True:
            self.skip_ws()
            if self.peek() == ".":
                self.i += 1
                self.skip_ws()
                parts.append(self.simple_key())
            else:
                return parts

    def simple_key(self):
        c = self.peek()
        if c == '"':
            self.i += 1
            return self.string('"', False)
        if c == "'":
            self.i += 1
            return self.string("'", False)
        m = _BARE_KEY.match(self.t, self.i)
        if not m:
            self.fail("expected a key")
        self.i = m.end()
        return m.group()

    def keyval(self, table):
        kpos = self.i
        parts = self.key()
        self.skip_ws()
        if self.peek() != "=":
            self.fail("expected '=' after key")
        self.i += 1
        self.skip_ws()
        value = self.value()
        self.insert(table, parts, value, kpos)

    def insert(self, table, parts, value, kpos):
        kinds = self.kinds
        cur = table
        for part in parts[:-1]:
            if part in cur:
                nxt = cur[part]
                if not isinstance(nxt, dict) or kinds.get(id(nxt)) not in _DOTTABLE:
                    self.fail("key conflicts with an existing value", kpos)
                cur = nxt
            else:
                nxt = {}
                kinds[id(nxt)] = "dotted"
                cur[part] = nxt
                cur = nxt
        last = parts[-1]
        if last in cur:
            self.fail("duplicate key", kpos)
        cur[last] = value

    # --- values -------------------------------------------------------------

    def value(self):
        t = self.t
        i = self.i
        c = self.peek()
        if c == '"':
            if t.startswith('"""', i):
                self.i = i + 3
                return self.string('"', True)
            self.i = i + 1
            return self.string('"', False)
        if c == "'":
            if t.startswith("'''", i):
                self.i = i + 3
                return self.string("'", True)
            self.i = i + 1
            return self.string("'", False)
        if c == "[":
            return self.array()
        if c == "{":
            return self.inline_table()
        if t.startswith("true", i):
            self.i = i + 4
            return True
        if t.startswith("false", i):
            self.i = i + 5
            return False
        m = _PREFIXED.match(t, i)
        if m:
            self.i = m.end()
            base = {"x": 16, "o": 8, "b": 2}[m.group()[1]]
            return int(m.group()[2:].replace("_", ""), base)
        m = _DATETIME.match(t, i)
        if m:
            self.i = m.end()
            return self.make_datetime(m, i)
        m = _LOCALTIME.match(t, i)
        if m:
            self.i = m.end()
            return self.make_time(m, i)
        m = _FLOAT.match(t, i)
        if m:
            self.i = m.end()
            return self.make_float(m.group())
        m = _SPECIAL_FLOAT.match(t, i)
        if m:
            self.i = m.end()
            return self.make_float(m.group())
        m = _DECINT.match(t, i)
        if m:
            self.i = m.end()
            return int(m.group().replace("_", ""))
        self.fail("expected a value")

    def make_float(self, text):
        if self.custom_float:
            result = self.parse_float(text)
            if isinstance(result, (dict, list)):
                raise ValueError(
                    "parse_float must not return a dict or list (got %s)"
                    % type(result).__name__)
            return result
        return float(text.replace("_", ""))

    def make_datetime(self, m, start):
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if m.group(4) is None:
            try:
                return _datetime.date(y, mo, d)
            except ValueError:
                self.fail("invalid date", start)
        hh, mi = int(m.group(4)), int(m.group(5))
        ss = int(m.group(6) or 0)
        us = _micro(m.group(7))
        off = m.group(8)
        try:
            if off is None:
                return _datetime.datetime(y, mo, d, hh, mi, ss, us)
            if off in ("Z", "z"):
                tz = _datetime.timezone.utc
            else:
                oh, om = int(off[1:3]), int(off[4:6])
                if oh > 23 or om > 59:
                    raise ValueError("offset out of range")
                delta = _datetime.timedelta(hours=oh, minutes=om)
                if off[0] == "-":
                    delta = -delta
                tz = _datetime.timezone(delta)
            return _datetime.datetime(y, mo, d, hh, mi, ss, us, tzinfo=tz)
        except ValueError:
            self.fail("invalid date-time", start)

    def make_time(self, m, start):
        hh, mi = int(m.group(1)), int(m.group(2))
        ss = int(m.group(3) or 0)
        us = _micro(m.group(4))
        try:
            return _datetime.time(hh, mi, ss, us)
        except ValueError:
            self.fail("invalid time", start)

    def string(self, q, multi):
        esc = q == '"'
        t = self.t
        n = self.n
        i = self.i
        if multi and i < n and t[i] == "\n":
            i += 1
        chunk = _CHUNKS[(q, multi)]
        out = []
        while True:
            m = chunk.match(t, i)
            out.append(m.group())
            i = m.end()
            if i >= n:
                self.fail("unterminated string", n)
            c = t[i]
            if c == q:
                if not multi:
                    self.i = i + 1
                    return "".join(out)
                j = i
                while j < n and t[j] == q:
                    j += 1
                r = j - i
                if r < 3:
                    out.append(q * r)
                    i = j
                    continue
                if r > 5:
                    self.fail("too many quote characters before closing delimiter", i)
                out.append(q * (r - 3))
                self.i = j
                return "".join(out)
            if c == "\\" and esc:
                if multi:
                    j = i + 1
                    while j < n and t[j] in " \t":
                        j += 1
                    if j < n and t[j] == "\n":
                        i = _WS_NL.match(t, j).end()
                        continue
                i = self.escape(i, out)
                continue
            self.fail("invalid character in string")

    def escape(self, i, out):
        t = self.t
        c = t[i + 1] if i + 1 < self.n else ""
        if c in _SIMPLE_ESC:
            out.append(_SIMPLE_ESC[c])
            return i + 2
        size = _ESC_SIZE.get(c)
        if size is None:
            self.fail("invalid escape sequence", i)
        digits = t[i + 2:i + 2 + size]
        if len(digits) != size or not all(ch in _HEX for ch in digits):
            self.fail("invalid hexadecimal escape", i)
        cp = int(digits, 16)
        if cp > 0x10FFFF or 0xD800 <= cp <= 0xDFFF:
            self.fail("escape is not a Unicode scalar value", i)
        out.append(chr(cp))
        return i + 2 + size

    def array(self):
        self.i += 1
        out = []
        self.skip_ws_nl()
        while True:
            if self.peek() == "]":
                self.i += 1
                return out
            out.append(self.value())
            self.skip_ws_nl()
            c = self.peek()
            if c == ",":
                self.i += 1
                self.skip_ws_nl()
                continue
            if c == "]":
                self.i += 1
                return out
            self.fail("expected ',' or ']' in array")

    def inline_table(self):
        self.i += 1
        table = {}
        self.skip_ws_nl()
        if self.peek() == "}":
            self.i += 1
        else:
            while True:
                kpos = self.i
                parts = self.key()
                self.skip_ws()
                if self.peek() != "=":
                    self.fail("expected '=' after key")
                self.i += 1
                self.skip_ws()
                value = self.value()
                self.insert(table, parts, value, kpos)
                self.skip_ws_nl()
                c = self.peek()
                if c == ",":
                    self.i += 1
                    self.skip_ws_nl()
                    if self.peek() == "}":
                        self.i += 1
                        break
                    continue
                if c == "}":
                    self.i += 1
                    break
                self.fail("expected ',' or '}' in inline table")
        self.kinds[id(table)] = "inline"
        return table


def _normalize(s):
    if "\r" not in s:
        return s, []
    cr = [m.start() for m in _re.finditer("\r\n", s)]
    return s.replace("\r\n", "\n"), cr


def _parse(doc, text, cr, parse_float):
    parser = _Parser(doc, text, cr, parse_float)
    try:
        return parser.run()
    except RecursionError:
        parser.fail("document is nested too deeply")


def loads(s, *, parse_float=float):
    """Parse a TOML v1.1.0 document from a text string into a dict."""
    if not isinstance(s, str):
        raise TypeError("loads() argument must be str, not %s" % type(s).__name__)
    text, cr = _normalize(s)
    return _parse(s, text, cr, parse_float)


def load(fp, *, parse_float=float):
    """Parse a TOML v1.1.0 document from a binary file object into a dict."""
    read = getattr(fp, "read", None)
    if read is None:
        raise TypeError("load() argument must be a binary file object")
    data = read()
    if isinstance(data, str):
        raise TypeError("load() requires a file opened in binary mode, not text mode")
    if not isinstance(data, (bytes, bytearray)):
        raise TypeError("load() expected bytes from read(), got %s" % type(data).__name__)
    data = bytes(data)
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        prefix = data[:exc.start].decode("utf-8")
        doc = data.decode("utf-8", "replace")
        raise TOMLDecodeError("document is not valid UTF-8", doc, len(prefix))
    normalized, cr = _normalize(text)
    return _parse(text, normalized, cr, parse_float)
