"""The decode-error exception of Tomlparse."""


class TOMLDecodeError(ValueError):
    """A document is not valid TOML v1.1.0, or a converter result is illegal.

    Constructed as ``TOMLDecodeError(msg, doc, pos)``: ``msg`` is the
    unformatted reason, ``doc`` the document text, and ``pos`` a 0-based
    character offset into ``doc``. ``lineno`` and ``colno`` are 1-based and
    derived from ``pos``.
    """

    def __init__(self, msg, doc, pos):
        self.msg = msg
        self.doc = doc
        self.pos = pos
        self.lineno = doc.count("\n", 0, pos) + 1
        # Column = 1 + characters between the last line feed before pos (or
        # the start of the document) and pos.  rfind returns -1 when there is
        # no line feed, which gives pos + 1 as required.
        self.colno = pos - doc.rfind("\n", 0, pos)
        if pos >= len(doc):
            where = "end of document"
        else:
            where = "line %d column %d" % (self.lineno, self.colno)
        report = "%s (%s, char %d)" % (msg, where, pos)
        ValueError.__init__(self, report)

    def __reduce__(self):
        return (type(self), (self.msg, self.doc, self.pos))
