"""Recursive-descent TOML v1.1.0 parser.

The parser works directly on the document text. Positions are indexes into
the text as given (carriage-return/line-feed pairs are not rewritten), so
decode-error offsets refer to the caller's document.

Structural bookkeeping: every dict and list the parser creates is recorded in
``_Parser.kind`` (keyed by ``id``; the objects stay alive in the result tree,
so ids are never reused). The kind says how the container came to exist,
which decides what later headers and dotted keys may do with it.
"""

import datetime as _dt
import re

from ._errors import TOMLDecodeError

# Kinds of containers.
_HEADER = "header"  # defined by a [table] header or is an array-of-tables item
_IMPLICIT = "implicit"  # created only as a parent of a later header
_DOTTED = "dotted"  # created by dotted keys
_INLINE = "inline"  # an inline table
_AOT = "aot"  # a list that is an array of tables

# Containers a header may walk through on the way to its final key.
_HEADER_WALKABLE = frozenset([_HEADER, _IMPLICIT, _DOTTED])
# Containers a dotted key may walk through on the way to its final key.
_DOTTED_WALKABLE = frozenset([_DOTTED, _IMPLICIT])

_WS_RE = re.compile(r"[ \t]*")
_BARE_KEY_RE = re.compile(r"[A-Za-z0-9_-]+")
_BASIC_CHUNK_RE = re.compile(r'[^"\\\x00-\x08\x0a-\x1f\x7f]+')
_LITERAL_CHUNK_RE = re.compile(r"[^'\x00-\x08\x0a-\x1f\x7f]+")
_COMMENT_BODY_RE = re.compile(r"[^\x00-\x08\x0a-\x1f\x7f]*")
_HEX_RE = re.compile(r"[0-9a-fA-F]+")
_ESCAPES = {
    "b": "\b",
    "t": "\t",
    "n": "\n",
    "f": "\f",
    "r": "\r",
    "e": "\x1b",
    '"': '"',
    "\\": "\\",
}
_ESCAPE_WIDTHS = {"x": 2, "u": 4, "U": 8}
_TOKEN_RE = re.compile(r"[0-9A-Za-z_+.\-]+")
_INT_RE = re.compile(r"[+-]?(?:0|[1-9](?:_?[0-9])*)")
_HEX_INT_RE = re.compile(r"0x[0-9a-fA-F](?:_?[0-9a-fA-F])*")
_OCT_INT_RE = re.compile(r"0o[0-7](?:_?[0-7])*")
_BIN_INT_RE = re.compile(r"0b[01](?:_?[01])*")
_FLOAT_RE = re.compile(
    r"[+-]?(?:0|[1-9](?:_?[0-9])*)"
    r"(?:\.[0-9](?:_?[0-9])*(?:[eE][+-]?[0-9](?:_?[0-9])*)?"
    r"|[eE][+-]?[0-9](?:_?[0-9])*)"
)
_SPECIAL_FLOATS = frozenset(["inf", "+inf", "-inf", "nan", "+nan", "-nan"])
_DATETIME_RE = re.compile(
    r"([0-9]{4})-([0-9]{2})-([0-9]{2})"
    r"(?:[Tt ]([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?"
    r"([Zz]|[+-][0-9]{2}:[0-9]{2})?)?"
)
_TIME_RE = re.compile(r"([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?")


def _run_length(s, i, ch):
    """Number of consecutive copies of ``ch`` starting at index ``i``."""
    j = i
    n = len(s)
    while j < n and s[j] == ch:
        j += 1
    return j - i


def _skip_blank(s, i):
    """Skip spaces, tabs, line feeds and carriage-return/line-feed pairs."""
    n = len(s)
    while i < n:
        if s[i] in " \t\n":
            i += 1
        elif s.startswith("\r\n", i):
            i += 2
        else:
            break
    return i


def _micro(frac):
    """Microseconds from the digits after a decimal point (truncated)."""
    return int((frac or "")[:6].ljust(6, "0"))


class _Parser(object):
    def __init__(self, text, parse_float):
        self.s = text
        self.n = len(text)
        self.i = 0
        self.parse_float = parse_float
        self.root = {}
        self.kind = {id(self.root): "table"}

    # ----- helpers -------------------------------------------------------

    def _error(self, msg, pos=None):
        if pos is None:
            pos = self.i
        if pos > self.n:
            pos = self.n
        raise TOMLDecodeError(msg, self.s, pos)

    def _peek(self, i):
        return self.s[i] if i < self.n else ""

    def _skip_ws(self, i):
        return _WS_RE.match(self.s, i).end()

    def _newline(self, i):
        """Consume one line ending (LF or CRLF) at ``i``."""
        s = self.s
        if s[i] == "\n":
            return i + 1
        if s.startswith("\n", i + 1):
            return i + 2
        self._error("bare carriage return is not allowed", i)

    def _comment(self, i):
        """Scan a comment starting at ``i`` (a ``#``); return the index of its
        line ending or of the end of the document."""
        s = self.s
        j = _COMMENT_BODY_RE.match(s, i + 1).end()
        if j < self.n:
            c = s[j]
            if not (c == "\n" or (c == "\r" and s.startswith("\n", j + 1))):
                self._error("invalid character in comment", j)
        return j

    def _skip_ws_nl(self, i):
        """Skip whitespace, line endings and comments (inside arrays and
        inline tables)."""
        s, n = self.s, self.n
        while True:
            i = self._skip_ws(i)
            if i >= n:
                return i
            c = s[i]
            if c == "#":
                i = self._comment(i)
            elif c == "\n" or c == "\r":
                i = self._newline(i)
            else:
                return i

    def _end_of_line(self):
        """After a header or key/value: only a comment, then a line ending or
        the end of the document may follow."""
        i = self._skip_ws(self.i)
        if i < self.n and self.s[i] == "#":
            i = self._comment(i)
        if i < self.n and self.s[i] not in "\r\n":
            self._error("expected end of line", i)
        self.i = i

    # ----- document ------------------------------------------------------

    def parse(self):
        n = self.n
        table = self.root
        while True:
            i = self._skip_ws(self.i)
            self.i = i
            if i >= n:
                break
            c = self.s[i]
            if c == "#":
                self.i = self._comment(i)
            elif c == "\n" or c == "\r":
                self.i = self._newline(i)
            elif c == "[":
                table = self._header()
                self._end_of_line()
            else:
                self._keyval(table)
                self._end_of_line()
        return self.root

    # ----- headers -------------------------------------------------------

    def _header(self):
        s = self.s
        start = self.i
        aot = s.startswith("[[", start)
        self.i = self._skip_ws(start + (2 if aot else 1))
        parts = self._key()
        i = self._skip_ws(self.i)
        close = "]]" if aot else "]"
        if not s.startswith(close, i):
            self._error("expected %r to close table header" % close, i)
        self.i = i + len(close)
        return self._walk_header(parts, aot, start)

    def _walk_header(self, parts, aot, pos):
        kind = self.kind
        cur = self.root
        for k in parts[:-1]:
            if k not in cur:
                nxt = {}
                kind[id(nxt)] = _IMPLICIT
                cur[k] = nxt
            else:
                nxt = cur[k]
                if isinstance(nxt, list) and kind.get(id(nxt)) == _AOT:
                    nxt = nxt[-1]
                elif not (
                    isinstance(nxt, dict) and kind.get(id(nxt)) in _HEADER_WALKABLE
                ):
                    self._error("table header path runs through a non-table value", pos)
            cur = nxt

        last = parts[-1]
        if aot:
            if last not in cur:
                item = {}
                kind[id(item)] = _HEADER
                arr = [item]
                kind[id(arr)] = _AOT
                cur[last] = arr
                return item
            arr = cur[last]
            if isinstance(arr, list) and kind.get(id(arr)) == _AOT:
                item = {}
                kind[id(item)] = _HEADER
                arr.append(item)
                return item
            self._error("array of tables conflicts with an existing key", pos)

        if last not in cur:
            table = {}
            kind[id(table)] = _HEADER
            cur[last] = table
            return table
        table = cur[last]
        if isinstance(table, dict) and kind.get(id(table)) == _IMPLICIT:
            kind[id(table)] = _HEADER
            return table
        self._error("table is already defined", pos)

    # ----- keys and key/value pairs --------------------------------------

    def _key(self):
        """Parse a dotted key at ``self.i``; return the list of its parts."""
        parts = [self._simple_key()]
        while True:
            j = self._skip_ws(self.i)
            if j < self.n and self.s[j] == ".":
                self.i = self._skip_ws(j + 1)
                parts.append(self._simple_key())
            else:
                return parts

    def _simple_key(self):
        s, i = self.s, self.i
        c = self._peek(i)
        if c == '"':
            if s.startswith('"""', i):
                self._error("multiline string is not allowed as a key", i)
            return self._basic_string()
        if c == "'":
            if s.startswith("'''", i):
                self._error("multiline string is not allowed as a key", i)
            return self._literal_string()
        m = _BARE_KEY_RE.match(s, i)
        if m is None:
            self._error("expected a key", i)
        self.i = m.end()
        return m.group()

    def _keyval(self, table):
        key_pos = self.i
        parts = self._key()
        self.i = self._skip_ws(self.i)
        if self._peek(self.i) != "=":
            self._error("expected '=' after key", self.i)
        self.i = self._skip_ws(self.i + 1)
        value = self._value()
        self._insert(table, parts, value, key_pos)

    def _insert(self, table, parts, value, pos):
        kind = self.kind
        cur = table
        for k in parts[:-1]:
            if k not in cur:
                nxt = {}
                kind[id(nxt)] = _DOTTED
                cur[k] = nxt
            else:
                nxt = cur[k]
                if not (isinstance(nxt, dict) and kind.get(id(nxt)) in _DOTTED_WALKABLE):
                    self._error("dotted key runs through an existing value", pos)
            cur = nxt
        last = parts[-1]
        if last in cur:
            self._error("duplicate key %r" % (last,), pos)
        cur[last] = value

    # ----- values --------------------------------------------------------

    def _value(self):
        s, i = self.s, self.i
        c = self._peek(i)
        if c == '"':
            if s.startswith('"""', i):
                return self._ml_basic()
            return self._basic_string()
        if c == "'":
            if s.startswith("'''", i):
                return self._ml_literal()
            return self._literal_string()
        if c == "[":
            return self._array()
        if c == "{":
            return self._inline_table()
        if c == "t" and s.startswith("true", i):
            self.i = i + 4
            return True
        if c == "f" and s.startswith("false", i):
            self.i = i + 5
            return False
        if "0" <= c <= "9":
            m = _DATETIME_RE.match(s, i)
            if m is not None:
                return self._datetime(m)
            m = _TIME_RE.match(s, i)
            if m is not None:
                return self._local_time(m)
        return self._number()

    def _number(self):
        s, i = self.s, self.i
        m = _TOKEN_RE.match(s, i)
        if m is None:
            self._error("expected a value", i)
        tok = m.group()
        if tok in _SPECIAL_FLOATS:
            val = self._float(tok)
        elif _INT_RE.fullmatch(tok):
            val = int(tok.replace("_", ""))
        elif _HEX_INT_RE.fullmatch(tok):
            val = int(tok[2:].replace("_", ""), 16)
        elif _OCT_INT_RE.fullmatch(tok):
            val = int(tok[2:].replace("_", ""), 8)
        elif _BIN_INT_RE.fullmatch(tok):
            val = int(tok[2:].replace("_", ""), 2)
        elif _FLOAT_RE.fullmatch(tok):
            val = self._float(tok)
        else:
            self._error("invalid value %r" % (tok,), i)
        self.i = m.end()
        return val

    def _float(self, tok):
        value = self.parse_float(tok)
        if isinstance(value, (dict, list)):
            raise ValueError(
                "parse_float returned a %s, which is not allowed for a float"
                % type(value).__name__
            )
        return value

    def _check_time(self, hh, mi, ss, pos):
        if hh > 23 or mi > 59 or ss > 59:
            self._error("time value out of range", pos)

    def _datetime(self, m):
        start = self.i
        self.i = m.end()
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        try:
            date = _dt.date(y, mo, d)
        except ValueError:
            self._error("date value out of range", start)
        if m.group(4) is None:
            return date
        hh, mi = int(m.group(4)), int(m.group(5))
        ss = int(m.group(6)) if m.group(6) else 0
        us = _micro(m.group(7))
        self._check_time(hh, mi, ss, start)
        tz = m.group(8)
        if tz is None:
            return _dt.datetime(y, mo, d, hh, mi, ss, us)
        if tz in ("Z", "z"):
            tzinfo = _dt.timezone.utc
        else:
            oh, om = int(tz[1:3]), int(tz[4:6])
            if oh > 23 or om > 59:
                self._error("UTC offset out of range", start)
            delta = _dt.timedelta(hours=oh, minutes=om)
            if tz[0] == "-":
                delta = -delta
            tzinfo = _dt.timezone(delta)
        return _dt.datetime(y, mo, d, hh, mi, ss, us, tzinfo=tzinfo)

    def _local_time(self, m):
        start = self.i
        self.i = m.end()
        hh, mi = int(m.group(1)), int(m.group(2))
        ss = int(m.group(3)) if m.group(3) else 0
        us = _micro(m.group(4))
        self._check_time(hh, mi, ss, start)
        return _dt.time(hh, mi, ss, us)

    # ----- strings -------------------------------------------------------

    def _escape(self, i):
        """Decode the escape sequence whose backslash is at ``i``.

        Returns (character, index after the sequence).
        """
        c = self._peek(i + 1)
        if c in _ESCAPES:
            return _ESCAPES[c], i + 2
        width = _ESCAPE_WIDTHS.get(c)
        if width is not None:
            digits = self.s[i + 2 : i + 2 + width]
            if len(digits) == width and _HEX_RE.fullmatch(digits):
                cp = int(digits, 16)
                if cp > 0x10FFFF or 0xD800 <= cp <= 0xDFFF:
                    self._error("escaped code point is not a Unicode scalar value", i)
                return chr(cp), i + 2 + width
            self._error("invalid unicode escape", i)
        self._error("invalid escape sequence", i)

    def _basic_string(self):
        s, n = self.s, self.n
        i = self.i + 1
        parts = []
        while True:
            m = _BASIC_CHUNK_RE.match(s, i)
            if m is not None:
                parts.append(m.group())
                i = m.end()
            if i >= n:
                self._error("unterminated string", i)
            c = s[i]
            if c == '"':
                self.i = i + 1
                return "".join(parts)
            if c == "\\":
                ch, i = self._escape(i)
                parts.append(ch)
            else:
                self._error("invalid character in string", i)

    def _literal_string(self):
        s, n = self.s, self.n
        i = self.i + 1
        parts = []
        while True:
            m = _LITERAL_CHUNK_RE.match(s, i)
            if m is not None:
                parts.append(m.group())
                i = m.end()
            if i >= n:
                self._error("unterminated string", i)
            c = s[i]
            if c == "'":
                self.i = i + 1
                return "".join(parts)
            self._error("invalid character in string", i)

    def _ml_basic(self):
        s, n = self.s, self.n
        i = self.i + 3
        if s.startswith("\n", i):
            i += 1
        elif s.startswith("\r\n", i):
            i += 2
        parts = []
        while True:
            m = _BASIC_CHUNK_RE.match(s, i)
            if m is not None:
                parts.append(m.group())
                i = m.end()
            if i >= n:
                self._error("unterminated multiline string", i)
            c = s[i]
            if c == '"':
                k = _run_length(s, i, '"')
                if k >= 3:
                    if k > 5:
                        self._error("too many quotation marks before closing delimiter", i)
                    parts.append('"' * (k - 3))
                    self.i = i + k
                    return "".join(parts)
                parts.append('"' * k)
                i += k
            elif c == "\\":
                j = i + 1
                while j < n and s[j] in " \t":
                    j += 1
                if j < n and (s[j] == "\n" or s.startswith("\r\n", j)):
                    # Line-ending backslash: drop it and the following blanks.
                    i = _skip_blank(s, j)
                elif j > i + 1:
                    self._error("whitespace after backslash is not a line ending", i)
                else:
                    ch, i = self._escape(i)
                    parts.append(ch)
            elif c == "\n":
                parts.append("\n")
                i += 1
            elif c == "\r":
                if s.startswith("\r\n", i):
                    parts.append("\n")
                    i += 2
                else:
                    self._error("bare carriage return is not allowed", i)
            else:
                self._error("invalid character in string", i)

    def _ml_literal(self):
        s, n = self.s, self.n
        i = self.i + 3
        if s.startswith("\n", i):
            i += 1
        elif s.startswith("\r\n", i):
            i += 2
        parts = []
        while True:
            m = _LITERAL_CHUNK_RE.match(s, i)
            if m is not None:
                parts.append(m.group())
                i = m.end()
            if i >= n:
                self._error("unterminated multiline string", i)
            c = s[i]
            if c == "'":
                k = _run_length(s, i, "'")
                if k >= 3:
                    if k > 5:
                        self._error("too many quotation marks before closing delimiter", i)
                    parts.append("'" * (k - 3))
                    self.i = i + k
                    return "".join(parts)
                parts.append("'" * k)
                i += k
            elif c == "\n":
                parts.append("\n")
                i += 1
            elif c == "\r":
                if s.startswith("\r\n", i):
                    parts.append("\n")
                    i += 2
                else:
                    self._error("bare carriage return is not allowed", i)
            else:
                self._error("invalid character in string", i)

    # ----- arrays and inline tables --------------------------------------

    def _array(self):
        arr = []
        self.i = self._skip_ws_nl(self.i + 1)
        while True:
            if self._peek(self.i) == "]":
                self.i += 1
                return arr
            arr.append(self._value())
            self.i = self._skip_ws_nl(self.i)
            c = self._peek(self.i)
            if c == ",":
                self.i = self._skip_ws_nl(self.i + 1)
            elif c == "]":
                self.i += 1
                return arr
            else:
                self._error("expected ',' or ']' in array", self.i)

    def _inline_table(self):
        table = {}
        self.kind[id(table)] = _INLINE
        self.i = self._skip_ws_nl(self.i + 1)
        if self._peek(self.i) == "}":
            self.i += 1
            return table
        while True:
            self._keyval(table)
            self.i = self._skip_ws_nl(self.i)
            c = self._peek(self.i)
            if c == ",":
                self.i = self._skip_ws_nl(self.i + 1)
                if self._peek(self.i) == "}":  # trailing comma (TOML v1.1.0)
                    self.i += 1
                    return table
            elif c == "}":
                self.i += 1
                return table
            else:
                self._error("expected ',' or '}' in inline table", self.i)


def _check_float_parser(parse_float):
    if not callable(parse_float):
        raise TypeError("parse_float must be callable")


def loads(s, *, parse_float=float):
    """Parse a TOML v1.1.0 document given as a text string."""
    if not isinstance(s, str):
        raise TypeError(
            "loads() expects a str, not %s" % type(s).__name__
        )
    _check_float_parser(parse_float)
    return _Parser(s, parse_float).parse()


def load(fp, *, parse_float=float):
    """Parse a TOML v1.1.0 document read from a binary file object."""
    data = fp.read()
    if isinstance(data, str):
        raise TypeError("load() expects a file opened in binary mode, not text mode")
    if not isinstance(data, (bytes, bytearray)):
        raise TypeError(
            "load() expects bytes from the file object, not %s" % type(data).__name__
        )
    data = bytes(data)
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        # Not valid UTF-8, so it is not a TOML document. Report the first bad
        # byte as a character offset into the text with replacement characters.
        good = data[: exc.start].decode("utf-8")
        doc = data.decode("utf-8", errors="replace")
        raise TOMLDecodeError("document is not valid UTF-8", doc, len(good))
    return loads(text, parse_float=parse_float)
