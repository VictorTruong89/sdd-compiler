import datetime as dt
import io
import unittest

from tomlparse import TOMLDecodeError, load, loads


class ScalarTests(unittest.TestCase):
    def test_booleans(self):
        self.assertIs(loads("a = true\nb = false")["a"], True)
        self.assertIs(loads("a = false")["a"], False)
        for bad in ["a = True", "a = TRUE", "a = t"]:
            with self.assertRaises(TOMLDecodeError):
                loads(bad)

    def test_strings(self):
        d = loads(
            'a = "x\\ty\\u00e9\\U0001F600\\x41\\e"\n'
            "b = 'C:\\raw'\n"
            'c = """\nfirst\n  second\\\n   joined"""\n'
            "d = '''\nlit\\n'''\n"
            'e = """a""""\n'
            'f = """x"""""\n'
        )
        self.assertEqual(d["a"], "x\ty\u00e9\U0001F600A\x1b")
        self.assertEqual(d["b"], "C:\\raw")
        self.assertEqual(d["c"], "first\n  secondjoined")
        self.assertEqual(d["d"], "lit\\n")
        self.assertEqual(d["e"], 'a"')
        self.assertEqual(d["f"], 'x""')

    def test_crlf_is_lf_inside_multiline(self):
        self.assertEqual(loads('a = """\r\nx\r\ny"""\r\n')["a"], "x\ny")

    def test_invalid_strings(self):
        for bad in [
            'a = "\\q"',
            'a = "\\X41"',
            'a = "\\uD800"',
            'a = "\\U00110000"',
            'a = "\\x4"',
            'a = "tab\there\x01"',
            'a = "unterminated',
            'a = """x\\   y"""',
            'a = """x""""""',
            "a = 'no\nnewline'",
            'a = """x\ry"""',
        ]:
            with self.subTest(bad=bad):
                with self.assertRaises(TOMLDecodeError):
                    loads(bad)

    def test_integers(self):
        d = loads("a = 1_000\nb = 0xdead_BEEF\nc = 0o755\nd = 0b1101\ne = -0\nf = +17")
        self.assertEqual(d, {"a": 1000, "b": 0xDEADBEEF, "c": 0o755, "d": 13, "e": 0, "f": 17})
        self.assertIs(type(d["e"]), int)

    def test_invalid_integers(self):
        for bad in ["a = 01", "a = 1__0", "a = 1_", "a = 0X1F", "a = 0x-1", "a = 0b102", "a = _1"]:
            with self.subTest(bad=bad):
                with self.assertRaises(TOMLDecodeError):
                    loads(bad)

    def test_floats(self):
        d = loads("a = 6.02e+23\nb = -0.5\nc = inf\nd = -inf\ne = +nan\nf = 1e05\ng = 3.1_4")
        self.assertEqual(d["a"], 6.02e23)
        self.assertEqual(d["b"], -0.5)
        self.assertEqual(d["c"], float("inf"))
        self.assertEqual(d["d"], float("-inf"))
        self.assertTrue(d["e"] != d["e"])
        self.assertEqual(d["f"], 1e5)
        self.assertEqual(d["g"], 3.14)

    def test_invalid_floats(self):
        for bad in ["a = .5", "a = 1.", "a = 01.5", "a = 1.e5", "a = 1e", "a = ."]:
            with self.subTest(bad=bad):
                with self.assertRaises(TOMLDecodeError):
                    loads(bad)

    def test_datetimes(self):
        d = loads(
            "a = 1979-05-27T07:32:00.1234567Z\n"
            "b = 1979-05-27 07:32:00-08:00\n"
            "c = 1979-05-27\n"
            "d = 07:32\n"
            "e = 1979-05-27T07:32\n"
            "f = 1987-07-05T17:45:00.5+01:00\n"
            "g = 2024-02-29T00:00:00z\n"
        )
        self.assertEqual(d["a"], dt.datetime(1979, 5, 27, 7, 32, 0, 123456, tzinfo=dt.timezone.utc))
        self.assertEqual(d["b"].utcoffset(), dt.timedelta(hours=-8))
        self.assertEqual(d["c"], dt.date(1979, 5, 27))
        self.assertEqual(d["d"], dt.time(7, 32))
        self.assertIsNone(d["e"].tzinfo)
        self.assertEqual(d["e"].second, 0)
        self.assertEqual(d["f"].microsecond, 500000)
        self.assertEqual(d["g"].day, 29)

    def test_invalid_datetimes(self):
        for bad in [
            "a = 2023-02-29",
            "a = 1979-05-27T24:00:00",
            "a = 07:60",
            "a = 07:32:60",
            "a = 1979-05-27T07:32:00+24:00",
            "a = 07:32Z",
        ]:
            with self.subTest(bad=bad):
                with self.assertRaises(TOMLDecodeError):
                    loads(bad)


class StructureTests(unittest.TestCase):
    def test_empty(self):
        self.assertEqual(loads(""), {})
        self.assertEqual(loads("  \t\n# c"), {})

    def test_keys_are_strings(self):
        d = loads('1234 = 1\ntrue = 2\ninf = 3\n"" = 4\n"a.b" = 5\n\'x\' = 6\n"\\u0041" = 7\n\'\\u0041\' = 8')
        self.assertEqual(d, {"1234": 1, "true": 2, "inf": 3, "": 4, "a.b": 5, "x": 6, "A": 7, "\\u0041": 8})

    def test_dotted_keys_and_tables(self):
        d = loads("a . b.c = 1\n[x . y]\nz = 2\n[a.d]\nq = 3")
        self.assertEqual(d, {"a": {"b": {"c": 1}, "d": {"q": 3}}, "x": {"y": {"z": 2}}})

    def test_implicit_super_table_later_declared(self):
        d = loads("[a.b.c]\nv = 1\n[a]\nw = 2")
        self.assertEqual(d, {"a": {"w": 2, "b": {"c": {"v": 1}}}})

    def test_subtable_under_dotted_table(self):
        d = loads('[fruit]\napple.color = "red"\n[fruit.apple.texture]\nsmooth = true')
        self.assertEqual(d, {"fruit": {"apple": {"color": "red", "texture": {"smooth": True}}}})

    def test_arrays_of_tables(self):
        d = loads("[[p]]\nx = 1\n[[p.s]]\ny = 1\n[[p.s]]\ny = 2\n[p.t]\nz = 0\n[[p]]\nx = 3")
        self.assertEqual(
            d,
            {"p": [{"x": 1, "s": [{"y": 1}, {"y": 2}], "t": {"z": 0}}, {"x": 3}]},
        )

    def test_array_of_tables_implies_plain_parent(self):
        d = loads("[[a.b]]\nx = 1\n[a]\ny = 2")
        self.assertEqual(d, {"a": {"b": [{"x": 1}], "y": 2}})

    def test_arrays(self):
        d = loads("a = []\nb = [1, 'two', [3.0], {c = 4}]\nc = [\n  1, # one\n  2,\n]")
        self.assertEqual(d["a"], [])
        self.assertEqual(d["b"], [1, "two", [3.0], {"c": 4}])
        self.assertEqual(d["c"], [1, 2])

    def test_inline_tables(self):
        d = loads("a = {}\nb = { x = 1, y.z = 2, }\nc = {\n  k = 'v', # c\n  n = { q = 1 },\n}")
        self.assertEqual(d, {"a": {}, "b": {"x": 1, "y": {"z": 2}}, "c": {"k": "v", "n": {"q": 1}}})

    def test_comments_everywhere(self):
        d = loads("# top é\na = 1 # trailing\n[t] # header\nb = 2#tight\n")
        self.assertEqual(d, {"a": 1, "t": {"b": 2}})

    def test_whitespace_and_indentation(self):
        self.assertEqual(loads("\t a\t=\t1\n\t[ t ]\n\t b = 2"), {"a": 1, "t": {"b": 2}})

    def test_crlf_document(self):
        self.assertEqual(loads("a = 1\r\n[t]\r\nb = 2\r\n"), {"a": 1, "t": {"b": 2}})


class InvalidStructureTests(unittest.TestCase):
    def assertInvalid(self, text):
        with self.assertRaises(TOMLDecodeError, msg=repr(text)):
            loads(text)

    def test_duplicates_and_redefinitions(self):
        for text in [
            "a = 1\na = 2",
            "[a]\n[a]",
            "[a.b]\n[a]\n[a]",
            "a.b = 1\n[a]",
            "[a]\nb.c = 1\n[a.b]",
            "[a.b]\nc = 1\n[a]\nb.c = 2",
            "a = 1\n[a]",
            "a = 1\n[a.b]",
            "[[a]]\n[a]",
            "[a]\n[[a]]",
            "a = [1]\n[[a]]",
            "a = {}\n[a.b]",
            "a = {b = 1}\na.c = 2",
            "a = {b = 1, b = 2}",
            "a = [{x=1}]\n[a.y]",
            "a.b = 1\na.b.c = 2",
            "[x]\ny = 1\n[x.y]",
        ]:
            with self.subTest(text=text):
                self.assertInvalid(text)

    def test_dotted_into_aot_is_refused(self):
        self.assertInvalid("[[a]]\nb = 1\n[[a]]\nc.d = 2\n[[a.c]]")
        self.assertInvalid("[t]\n[[t.a]]\n[t]\na.b = 1")

    def test_syntax(self):
        for text in [
            "a",
            "a =",
            "a = 1 b = 2",
            "a = 1 # ok\nb = [1 2]",
            "[a",
            "[a]]",
            "[ [a] ]",
            "[]",
            "[a..b]",
            "\"\"\"k\"\"\" = 1",
            "[a] b = 1",
            "a = {b = 1 c = 2}",
            "a = {,}",
            "a = [,]",
            "a = [1,,]",
            "a = {b = 1,,}",
            "a = 1979-05-27T07:32:00Z extra",
            "a = \ufeff1",
            "a = 1\x00",
            "a = 1 # bad \x01",
        ]:
            with self.subTest(text=text):
                self.assertInvalid(text)

    def test_empty_key_value_without_key_or_value(self):
        self.assertInvalid("= 1")
        self.assertInvalid("a =\n")


class LocationTests(unittest.TestCase):
    def test_error_location(self):
        doc = "a = 1\nb = [1,\n  @]"
        with self.assertRaises(TOMLDecodeError) as cm:
            loads(doc)
        err = cm.exception
        self.assertEqual(err.doc, doc)
        self.assertEqual(doc[err.pos], "@")
        self.assertEqual((err.lineno, err.colno), (3, 3))
        self.assertIn("line 3", str(err))

    def test_end_of_document(self):
        with self.assertRaises(TOMLDecodeError) as cm:
            loads("a = [1,")
        self.assertIn("end of document", str(cm.exception))

    def test_constructor(self):
        err = TOMLDecodeError("boom", "ab\ncd", 4)
        self.assertEqual((err.msg, err.doc, err.pos, err.lineno, err.colno), ("boom", "ab\ncd", 4, 2, 2))
        self.assertIsInstance(err, ValueError)
        self.assertNotIsInstance(err, TypeError)
        self.assertIn("boom", str(err))
        self.assertEqual(TOMLDecodeError("x", "", 0).colno, 1)

    def test_error_is_not_type_or_recursion_error(self):
        self.assertFalse(issubclass(TOMLDecodeError, TypeError))
        self.assertFalse(issubclass(TOMLDecodeError, RecursionError))


class EntryTests(unittest.TestCase):
    def test_type_errors(self):
        for bad in [b"a = 1", bytearray(b"a=1"), 5, None, io.BytesIO(b"a=1")]:
            with self.subTest(bad=bad):
                with self.assertRaises(TypeError):
                    loads(bad)

    def test_load_binary(self):
        self.assertEqual(load(io.BytesIO(b"a = 'caf\xc3\xa9'")), {"a": "caf\u00e9"})
        self.assertEqual(load(io.BytesIO(b"")), {})

    def test_load_text_mode_refused(self):
        with self.assertRaises(TypeError):
            load(io.StringIO("a = 1"))

    def test_load_invalid_toml_is_decode_error_with_text_doc(self):
        with self.assertRaises(TOMLDecodeError) as cm:
            load(io.BytesIO(b"a = 1\nb = @"))
        self.assertIsInstance(cm.exception.doc, str)

    def test_load_invalid_utf8(self):
        with self.assertRaises(TOMLDecodeError):
            load(io.BytesIO(b"a = '\xff'"))

    def test_parse_float_converter(self):
        seen = []

        def conv(text):
            seen.append(text)
            return ("f", text)

        d = loads("a = 1.5\nb = 1_0.0e1\nc = [-inf, 2]\nd = {e = +nan}\nf = 3", parse_float=conv)
        self.assertEqual(seen, ["1.5", "1_0.0e1", "-inf", "+nan"])
        self.assertEqual(d["a"], ("f", "1.5"))
        self.assertEqual(d["c"][1], 2)
        self.assertIs(type(d["f"]), int)

    def test_parse_float_illegal_result(self):
        class MyDict(dict):
            pass

        for bad in [lambda t: {}, lambda t: [], lambda t: MyDict(), lambda t: [1]]:
            with self.subTest(bad=bad):
                with self.assertRaises(ValueError) as cm:
                    loads("a = 1.0", parse_float=bad)
                self.assertNotIsInstance(cm.exception, TOMLDecodeError)

    def test_parse_float_returns_anything_else(self):
        self.assertEqual(loads("a = 1.0", parse_float=lambda t: "x")["a"], "x")

    def test_converter_not_called_for_integers(self):
        def conv(t):
            raise AssertionError("should not be called")

        self.assertEqual(loads("a = 1\nb = 0x1f", parse_float=conv), {"a": 1, "b": 31})


if __name__ == "__main__":
    unittest.main()
