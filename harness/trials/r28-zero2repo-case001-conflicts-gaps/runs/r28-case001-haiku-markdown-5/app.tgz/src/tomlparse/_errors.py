"""The decode-error exception of Tomlparse."""


class TOMLDecodeError(ValueError):
    """Raised when a document is not valid TOML v1.1.0.

    Constructed as ``TOMLDecodeError(msg, doc, pos)``: ``msg`` is the reason,
    ``doc`` the document text and ``pos`` a 0-based character offset into it.
    ``lineno`` and ``colno`` are derived from ``pos`` (both 1-based).
    """

    def __init__(self, msg, doc, pos):
        self.msg = msg
        self.doc = doc
        self.pos = pos
        self.lineno = doc.count("\n", 0, pos) + 1
        last_newline = doc.rfind("\n", 0, pos)
        self.colno = pos - last_newline
        if pos >= len(doc):
            where = "end of document, line %d, column %d" % (self.lineno, self.colno)
        else:
            where = "line %d, column %d (char %d)" % (self.lineno, self.colno, pos)
        super().__init__("%s (%s)" % (msg, where))

    def __reduce__(self):
        return (self.__class__, (self.msg, self.doc, self.pos))
