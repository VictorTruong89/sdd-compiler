"""Recursive-descent TOML v1.1.0 parser (internal module).

The parser works directly on the caller's text. Offsets reported in errors are
offsets into that text. A carriage-return/line-feed pair is treated as one line
feed wherever it occurs; a carriage return that is not followed by a line feed
is an error.
"""

import datetime as _dt
import re

from ._errors import TOMLDecodeError

# Character classes are written with explicit ASCII ranges: \d would also match
# non-ASCII digits in str patterns.
_DATE_RE = re.compile(r"([0-9]{4})-([0-9]{2})-([0-9]{2})")
_TIME_RE = re.compile(r"([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?")
_OFFSET_RE = re.compile(r"[Zz]|([+-])([0-9]{2}):([0-9]{2})")
_BARE_RE = re.compile(r"[A-Za-z0-9_-]+")
_SPECIAL_FLOAT_RE = re.compile(r"[+-]?(?:inf|nan)")
_HEX_RE = re.compile(r"0x[0-9A-Fa-f]+(?:_[0-9A-Fa-f]+)*")
_OCT_RE = re.compile(r"0o[0-7]+(?:_[0-7]+)*")
_BIN_RE = re.compile(r"0b[01]+(?:_[01]+)*")
# Groups: 1 sign, 2 integer digits, 3 fraction, 4 exponent.
_DEC_RE = re.compile(
    r"([+-]?)(0|[1-9][0-9]*(?:_[0-9]+)*)"
    r"(\.[0-9]+(?:_[0-9]+)*)?"
    r"([eE][+-]?[0-9]+(?:_[0-9]+)*)?"
)

_ESCAPES = {
    "b": "\b",
    "t": "\t",
    "n": "\n",
    "f": "\f",
    "r": "\r",
    "e": "\x1b",
    '"': '"',
    "\\": "\\",
}
_UNICODE_ESCAPE_LEN = {"x": 2, "u": 4, "U": 8}
_HEX_DIGITS = frozenset("0123456789abcdefABCDEF")

# Node kinds for tables created by the parser (keyed by id()).
_IMPLICIT = "implicit"  # created as a super-table by a header; may still be defined
_HEADER = "header"  # defined by a [table] or [[array]] header
_DOTTED = "dotted"  # created by dotted keys
_INLINE = "inline"  # an inline table; frozen once written


def _bad_char(c):
    """Control characters that TOML forbids in strings and comments (tab is allowed)."""
    code = ord(c)
    return (code < 0x20 and c != "\t") or code == 0x7F


class _Parser:
    def __init__(self, text, parse_float):
        self.s = text
        self.n = len(text)
        self.i = 0
        self.parse_float = parse_float
        self.kind = {}
        self.aot = set()  # ids of lists that are arrays of tables

    # ----- low-level helpers -------------------------------------------------

    def _err(self, msg):
        raise TOMLDecodeError(msg, self.s, self.i)

    def _err_at(self, pos, msg):
        raise TOMLDecodeError(msg, self.s, pos)

    def _peek(self):
        return self.s[self.i] if self.i < self.n else ""

    def _skip_ws(self):
        s, i, n = self.s, self.i, self.n
        while i < n and s[i] in " \t":
            i += 1
        self.i = i

    def _newline(self):
        if self.s.startswith("\n", self.i):
            self.i += 1
        elif self.s.startswith("\r\n", self.i):
            self.i += 2
        else:
            self._err("expected a line ending")

    def _comment(self):
        s, n = self.s, self.n
        i = self.i + 1
        while i < n:
            c = s[i]
            if c == "\n":
                break
            if c == "\r":
                if s.startswith("\r\n", i):
                    break
                self._err_at(i, "bare carriage return")
            if _bad_char(c):
                self._err_at(i, "control character not allowed in comment")
            i += 1
        self.i = i

    def _skip_ws_nl_comment(self):
        while True:
            self._skip_ws()
            c = self._peek()
            if c == "#":
                self._comment()
            elif c == "\n" or c == "\r":
                self._newline()
            else:
                return

    def _end_of_statement(self):
        self._skip_ws()
        if self._peek() == "#":
            self._comment()
        c = self._peek()
        if c == "":
            return
        if c == "\n" or c == "\r":
            self._newline()
            return
        self._err("expected end of line")

    def _check_term(self):
        """After a scalar, only a delimiter may follow."""
        c = self._peek()
        if c and c not in " \t\r\n,]}#":
            self._err("unexpected character after value")

    # ----- document structure -----------------------------------------------

    def parse(self):
        root = {}
        current = root
        s, n = self.s, self.n
        while True:
            self._skip_ws()
            if self.i >= n:
                break
            c = s[self.i]
            if c == "\n" or c == "\r":
                self._newline()
            elif c == "#":
                self._comment()
            elif c == "[":
                current = self._header(root)
                self._end_of_statement()
            else:
                self._keyval(current)
                self._end_of_statement()
        return root

    def _keyval(self, table):
        key_start = self.i
        path = self._key_path()
        self._skip_ws()
        if self._peek() != "=":
            self._err("expected '=' after key")
        self.i += 1
        self._skip_ws()
        value = self._value()
        self._assign(table, path, value, key_start)

    def _key_path(self):
        parts = [self._key()]
        while True:
            self._skip_ws()
            if self._peek() != ".":
                return parts
            self.i += 1
            self._skip_ws()
            parts.append(self._key())

    def _key(self):
        c = self._peek()
        if c == '"':
            if self.s.startswith('"""', self.i):
                self._err("multiline string is not allowed as a key")
            return self._basic_string()
        if c == "'":
            if self.s.startswith("'''", self.i):
                self._err("multiline string is not allowed as a key")
            return self._literal_string()
        m = _BARE_RE.match(self.s, self.i)
        if m:
            self.i = m.end()
            return m.group()
        self._err("expected a key")

    def _header(self, root):
        s = self.s
        start = self.i
        is_aot = s.startswith("[[", start)
        self.i += 2 if is_aot else 1
        self._skip_ws()
        path = self._key_path()
        self._skip_ws()
        if is_aot:
            if not s.startswith("]]", self.i):
                self._err("expected ']]'")
            self.i += 2
        else:
            if self._peek() != "]":
                self._err("expected ']'")
            self.i += 1
        return self._open_table(root, path, is_aot, start)

    def _open_table(self, root, path, is_aot, pos):
        node = root
        for part in path[:-1]:
            node = self._descend_header(node, part)
        last = path[-1]
        if is_aot:
            if last not in node:
                item = {}
                self.kind[id(item)] = _HEADER
                arr = [item]
                self.aot.add(id(arr))
                node[last] = arr
                return item
            arr = node[last]
            if not (isinstance(arr, list) and id(arr) in self.aot):
                self._err_at(pos, "array of tables conflicts with an existing key")
            item = {}
            self.kind[id(item)] = _HEADER
            arr.append(item)
            return item
        if last not in node:
            table = {}
            self.kind[id(table)] = _HEADER
            node[last] = table
            return table
        existing = node[last]
        if isinstance(existing, dict) and self.kind.get(id(existing)) == _IMPLICIT:
            self.kind[id(existing)] = _HEADER
            return existing
        self._err_at(pos, "table defined more than once or conflicts with an existing key")

    def _descend_header(self, node, part):
        """Step through one intermediate part of a table header."""
        if part not in node:
            table = {}
            self.kind[id(table)] = _IMPLICIT
            node[part] = table
            return table
        value = node[part]
        if isinstance(value, dict):
            if self.kind.get(id(value)) == _INLINE:
                self._err("cannot extend an inline table")
            return value
        if isinstance(value, list) and id(value) in self.aot:
            return value[-1]
        self._err("key already defined as a value")

    def _assign(self, table, path, value, pos):
        """Store ``value`` at the dotted ``path`` below ``table``; ``pos`` is the key's offset."""
        node = table
        for part in path[:-1]:
            if part not in node:
                child = {}
                self.kind[id(child)] = _DOTTED
                node[part] = child
                node = child
                continue
            existing = node[part]
            if not isinstance(existing, dict):
                self._err_at(pos, "dotted key goes through a value or array")
            kind = self.kind.get(id(existing))
            if kind == _HEADER or kind == _INLINE:
                self._err_at(
                    pos, "dotted key cannot extend a table defined by a header or an inline table"
                )
            if kind == _IMPLICIT:
                self.kind[id(existing)] = _DOTTED
            node = existing
        last = path[-1]
        if last in node:
            self._err_at(pos, "duplicate key")
        node[last] = value

    # ----- values -----------------------------------------------------------

    def _value(self):
        s, i = self.s, self.i
        c = self._peek()
        if c == "":
            self._err("expected a value")
        if c == '"':
            if s.startswith('"""', i):
                return self._ml_string('"', True)
            return self._basic_string()
        if c == "'":
            if s.startswith("'''", i):
                return self._ml_string("'", False)
            return self._literal_string()
        if c == "[":
            return self._array()
        if c == "{":
            return self._inline_table()
        if "0" <= c <= "9":
            value = self._datetime()
            if value is not None:
                return value
            return self._number()
        m = _SPECIAL_FLOAT_RE.match(s, i)
        if m:
            self.i = m.end()
            self._check_term()
            return self._float(m.group())
        if c == "+" or c == "-":
            return self._number()
        if s.startswith("true", i):
            self.i = i + 4
            self._check_term()
            return True
        if s.startswith("false", i):
            self.i = i + 5
            self._check_term()
            return False
        self._err("invalid value")

    def _number(self):
        s, start = self.s, self.i
        for regex, base in ((_HEX_RE, 16), (_OCT_RE, 8), (_BIN_RE, 2)):
            m = regex.match(s, start)
            if m:
                self.i = m.end()
                self._check_term()
                return int(m.group()[2:].replace("_", ""), base)
        m = _DEC_RE.match(s, start)
        if not m:
            self._err("invalid number")
        self.i = m.end()
        self._check_term()
        if m.group(3) is None and m.group(4) is None:
            return int(m.group().replace("_", ""))
        return self._float(m.group())

    def _float(self, token):
        value = self.parse_float(token)
        if isinstance(value, (dict, list)):
            raise ValueError("parse_float returned a dict or list for %r" % token)
        return value

    def _datetime(self):
        """Parse a date, time or date-time at the current position, or return None."""
        s, start = self.s, self.i
        m = _DATE_RE.match(s, start)
        if m:
            year, month, day = (int(g) for g in m.groups())
            try:
                date = _dt.date(year, month, day)
            except ValueError:
                self._err_at(start, "invalid calendar date")
            pos = m.end()
            if pos < self.n and s[pos] in "Tt ":
                tm = _TIME_RE.match(s, pos + 1)
                if tm:
                    hour, minute, second, micro = self._time_parts(tm)
                    pos = tm.end()
                    om = _OFFSET_RE.match(s, pos)
                    if om:
                        tzinfo = self._offset(om)
                        self.i = om.end()
                        self._check_term()
                        return _dt.datetime(
                            year, month, day, hour, minute, second, micro, tzinfo=tzinfo
                        )
                    self.i = pos
                    self._check_term()
                    return _dt.datetime(year, month, day, hour, minute, second, micro)
            self.i = pos
            self._check_term()
            return date
        tm = _TIME_RE.match(s, start)
        if tm:
            hour, minute, second, micro = self._time_parts(tm)
            self.i = tm.end()
            self._check_term()
            return _dt.time(hour, minute, second, micro)
        return None

    def _time_parts(self, tm):
        hour, minute = int(tm.group(1)), int(tm.group(2))
        second = int(tm.group(3)) if tm.group(3) is not None else 0
        fraction = tm.group(4) or ""
        micro = int((fraction + "000000")[:6])  # truncated, not rounded
        if hour > 23 or minute > 59 or second > 59:
            self._err_at(tm.start(), "time out of range")
        return hour, minute, second, micro

    def _offset(self, om):
        if om.group(1) is None:
            return _dt.timezone.utc
        hours, minutes = int(om.group(2)), int(om.group(3))
        if hours > 23 or minutes > 59:
            self._err_at(om.start(), "UTC offset out of range")
        delta = _dt.timedelta(hours=hours, minutes=minutes)
        if om.group(1) == "-":
            delta = -delta
        return _dt.timezone(delta)

    # ----- strings ----------------------------------------------------------

    def _escape(self):
        """Decode the escape sequence whose backslash is at ``self.i``."""
        s, j = self.s, self.i
        c = s[j + 1] if j + 1 < self.n else ""
        if c and c in _ESCAPES:
            self.i = j + 2
            return _ESCAPES[c]
        if c and c in _UNICODE_ESCAPE_LEN:
            width = _UNICODE_ESCAPE_LEN[c]
            digits = s[j + 2 : j + 2 + width]
            if len(digits) != width or any(ch not in _HEX_DIGITS for ch in digits):
                self._err_at(j, "invalid unicode escape")
            code = int(digits, 16)
            if code > 0x10FFFF or 0xD800 <= code <= 0xDFFF:
                self._err_at(j, "escape is not a Unicode scalar value")
            self.i = j + 2 + width
            return chr(code)
        self._err_at(j, "invalid escape sequence")

    def _basic_string(self):
        s, n = self.s, self.n
        self.i += 1
        buf = []
        while True:
            j = self.i
            if j >= n:
                self._err_at(n, "unterminated string")
            c = s[j]
            if c == '"':
                self.i = j + 1
                return "".join(buf)
            if c == "\\":
                buf.append(self._escape())
            elif c == "\n" or c == "\r" or _bad_char(c):
                self._err_at(j, "invalid character in single-line string")
            else:
                buf.append(c)
                self.i = j + 1

    def _literal_string(self):
        s, n = self.s, self.n
        self.i += 1
        start = self.i
        j = start
        while True:
            if j >= n:
                self._err_at(n, "unterminated string")
            c = s[j]
            if c == "'":
                self.i = j + 1
                return s[start:j]
            if c == "\n" or c == "\r" or _bad_char(c):
                self._err_at(j, "invalid character in single-line string")
            j += 1

    def _run(self, j, quote):
        count = 0
        while j + count < self.n and self.s[j + count] == quote:
            count += 1
        return count

    def _skip_line_ending_whitespace(self):
        s, n = self.s, self.n
        while self.i < n:
            c = s[self.i]
            if c == " " or c == "\t" or c == "\n":
                self.i += 1
            elif c == "\r" and s.startswith("\r\n", self.i):
                self.i += 2
            else:
                break

    def _ml_string(self, quote, escapes):
        """Multiline basic (escapes=True) or multiline literal string."""
        s, n = self.s, self.n
        self.i += 3
        if s.startswith("\r\n", self.i):
            self.i += 2
        elif s.startswith("\n", self.i):
            self.i += 1
        buf = []
        while True:
            j = self.i
            if j >= n:
                self._err_at(n, "unterminated multiline string")
            c = s[j]
            if c == quote:
                count = self._run(j, quote)
                if count >= 3:
                    if count > 5:
                        self._err_at(j, "too many quotation marks before closing delimiter")
                    buf.append(quote * (count - 3))
                    self.i = j + count
                    return "".join(buf)
                buf.append(quote * count)
                self.i = j + count
            elif escapes and c == "\\":
                k = j + 1
                while k < n and (s[k] == " " or s[k] == "\t"):
                    k += 1
                if k < n and (s[k] == "\n" or s[k] == "\r"):
                    self.i = k
                    self._skip_line_ending_whitespace()
                else:
                    buf.append(self._escape())
            elif c == "\r":
                if s.startswith("\r\n", j):
                    buf.append("\n")
                    self.i = j + 2
                else:
                    self._err_at(j, "bare carriage return")
            elif c == "\n":
                buf.append("\n")
                self.i = j + 1
            elif _bad_char(c):
                self._err_at(j, "invalid character in multiline string")
            else:
                buf.append(c)
                self.i = j + 1

    # ----- arrays and inline tables ----------------------------------------

    def _array(self):
        self.i += 1
        items = []
        while True:
            self._skip_ws_nl_comment()
            if self._peek() == "]":
                self.i += 1
                return items
            items.append(self._value())
            self._skip_ws_nl_comment()
            c = self._peek()
            if c == ",":
                self.i += 1
            elif c == "]":
                self.i += 1
                return items
            else:
                self._err("expected ',' or ']' in array")

    def _inline_table(self):
        self.i += 1
        table = {}
        self._skip_ws_nl_comment()
        if self._peek() == "}":
            self.i += 1
        else:
            while True:
                self._keyval(table)
                self._skip_ws_nl_comment()
                c = self._peek()
                if c == ",":
                    self.i += 1
                    self._skip_ws_nl_comment()
                    if self._peek() == "}":  # trailing comma (TOML v1.1.0)
                        self.i += 1
                        break
                elif c == "}":
                    self.i += 1
                    break
                else:
                    self._err("expected ',' or '}' in inline table")
        self.kind[id(table)] = _INLINE
        return table


def parse_document(text, parse_float):
    """Parse ``text`` and return the document mapping."""
    parser = _Parser(text, parse_float)
    try:
        return parser.parse()
    except RecursionError:
        raise TOMLDecodeError("document is nested too deeply", text, parser.i) from None
