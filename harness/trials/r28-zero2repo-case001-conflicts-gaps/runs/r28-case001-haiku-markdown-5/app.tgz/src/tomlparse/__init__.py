"""Tomlparse: a pure-Python parser for TOML v1.1.0 documents.

Public surface: ``loads``, ``load`` and ``TOMLDecodeError``.
"""

from ._errors import TOMLDecodeError
from ._parser import parse_document

__all__ = ["loads", "load", "TOMLDecodeError"]
__version__ = "2.4.0"


def loads(s, *, parse_float=float):
    """Parse a TOML document from a text string and return a ``dict``."""
    if not isinstance(s, str):
        raise TypeError("loads() argument must be str, not %s" % type(s).__name__)
    return parse_document(s, parse_float)


def load(fp, *, parse_float=float):
    """Parse a TOML document read from a binary file object and return a ``dict``."""
    read = getattr(fp, "read", None)
    if read is None:
        raise TypeError("load() argument must be a binary file object")
    data = read()
    if isinstance(data, str):
        raise TypeError("load() requires a file object opened in binary mode")
    if not isinstance(data, (bytes, bytearray)):
        raise TypeError("load() expected bytes from read(), not %s" % type(data).__name__)
    data = bytes(data)
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        doc = data.decode("utf-8", errors="replace")
        pos = len(data[: exc.start].decode("utf-8", errors="replace"))
        raise TOMLDecodeError("invalid UTF-8 in document", doc, pos) from None
    return parse_document(text, parse_float)
