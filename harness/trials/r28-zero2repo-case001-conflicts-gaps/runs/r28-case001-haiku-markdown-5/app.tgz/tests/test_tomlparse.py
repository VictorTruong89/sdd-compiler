import datetime as dt
import io
import unittest

from tomlparse import TOMLDecodeError, load, loads


class ValidDocuments(unittest.TestCase):
    def test_empty_and_comments(self):
        self.assertEqual(loads(""), {})
        self.assertEqual(loads("   \t  "), {})
        self.assertEqual(loads("# only a comment"), {})
        self.assertEqual(loads("# c\n# d\n"), {})

    def test_scalars(self):
        d = loads(
            "b1 = true\nb2 = false\n"
            "i1 = 0\ni2 = -17\ni3 = +99\ni4 = 0xDEAD_beef\ni5 = 0o755\ni6 = 0b1101_0110\n"
            "f1 = 3.14\nf2 = -1e3\nf3 = 1_000.5e+3\nf4 = +inf\nf5 = -inf\n"
        )
        self.assertIs(d["b1"], True)
        self.assertIs(d["b2"], False)
        self.assertEqual(d["i1"], 0)
        self.assertEqual(d["i2"], -17)
        self.assertEqual(d["i3"], 99)
        self.assertEqual(d["i4"], 0xDEADBEEF)
        self.assertEqual(d["i5"], 0o755)
        self.assertEqual(d["i6"], 0b11010110)
        self.assertEqual(d["f1"], 3.14)
        self.assertEqual(d["f2"], -1000.0)
        self.assertEqual(d["f3"], 1000500.0)
        self.assertEqual(d["f4"], float("inf"))
        self.assertEqual(d["f5"], float("-inf"))
        self.assertTrue(loads("n = nan")["n"] != loads("n = nan")["n"])

    def test_strings(self):
        d = loads(
            "a = \"tab\\there\\u00e9\\U0001F600\\e\\x41\"\n"
            "b = 'C:\\path\\n'\n"
            "c = \"\"\"\nline1\n\"\"\"\n"
            "d = '''\nraw \\n\n'''\n"
            "e = \"\"\"one \\\n    two\"\"\"\n"
            "f = \"\"\"a\"\"\"\"\n"
            "g = \"\"\"b\"\"\"\"\"\n"
            "h = \"\"\"\r\nx\r\ny\"\"\"\n"
        )
        self.assertEqual(d["a"], "tab\there\u00e9\U0001F600\x1bA")
        self.assertEqual(d["b"], "C:\\path\\n")
        self.assertEqual(d["c"], "line1\n")
        self.assertEqual(d["d"], "raw \\n\n")
        self.assertEqual(d["e"], "one two")
        self.assertEqual(d["f"], 'a"')
        self.assertEqual(d["g"], 'b""')
        self.assertEqual(d["h"], "x\ny")

    def test_dates(self):
        d = loads(
            "odt = 1979-05-27T07:32:00Z\n"
            "odt2 = 1979-05-27 07:32:00.999999+01:30\n"
            "odt3 = 1979-05-27t07:32Z\n"
            "ldt = 1979-05-27T07:32:00.1234567\n"
            "ld = 1979-02-28\n"
            "lt = 07:32:00\n"
            "lt2 = 07:32\n"
        )
        self.assertEqual(d["odt"], dt.datetime(1979, 5, 27, 7, 32, tzinfo=dt.timezone.utc))
        self.assertEqual(d["odt"].utcoffset(), dt.timedelta(0))
        self.assertEqual(d["odt2"].utcoffset(), dt.timedelta(hours=1, minutes=30))
        self.assertEqual(d["odt2"].microsecond, 999999)
        self.assertEqual(d["odt3"].second, 0)
        self.assertIsNone(d["ldt"].tzinfo)
        self.assertEqual(d["ldt"].microsecond, 123456)  # truncated
        self.assertEqual(d["ld"], dt.date(1979, 2, 28))
        self.assertEqual(d["lt"], dt.time(7, 32, 0))
        self.assertEqual(d["lt2"], dt.time(7, 32, 0))
        self.assertIsNone(d["lt"].tzinfo)
        self.assertEqual(loads("d = 2024-02-29")["d"], dt.date(2024, 2, 29))

    def test_tables_and_dotted_keys(self):
        d = loads(
            "[fruit]\napple.color = \"red\"\napple.taste.sweet = true\n"
            "[fruit.apple.texture]\nsmooth = true\n"
        )
        self.assertEqual(loads("a . b = 1")["a"]["b"], 1)
        self.assertEqual(
            d,
            {"fruit": {"apple": {"color": "red", "taste": {"sweet": True},
                                 "texture": {"smooth": True}}}},
        )
        self.assertEqual(loads('"a.b" = 1\n\'\' = 2')["a.b"], 1)
        self.assertEqual(loads('"" = 2')[""], 2)
        with self.assertRaises(TOMLDecodeError):
            loads('"" = 1\n\'\' = 2')
        self.assertEqual(loads("[a.b.c]\n[a]\nx = 1")["a"]["x"], 1)
        self.assertEqual(loads("a.b.c = 1\na.b.d = 2")["a"]["b"], {"c": 1, "d": 2})
        self.assertEqual(loads("1234 = 5\ntrue = 6")["1234"], 5)

    def test_arrays_of_tables(self):
        d = loads(
            "[[p]]\nname = 'Hammer'\n[[p]]\nname = 'Nail'\n"
            "[p.sub]\nx = 1\n[[p]]\nname = 'Saw'\n"
        )
        self.assertEqual(len(d["p"]), 3)
        self.assertEqual(d["p"][1]["sub"], {"x": 1})
        self.assertNotIn("sub", d["p"][2])
        self.assertEqual(loads("[[a.b]]\nc = 1")["a"]["b"], [{"c": 1}])
        self.assertEqual(loads("[a.b]\n[[a.c]]")["a"]["c"], [{}])

    def test_arrays_and_inline_tables(self):
        d = loads(
            "a = []\nb = [1, \"x\", [true, 1.5], {k = 1}, ]\n"
            "c = [\n  1, # one\n  2,\n]\n"
            "t = {}\n"
            "u = {\n  x = 1, # c\n  y = { z = 2 },\n}\n"
            "v = { a.b = 1, a.c = 2 }\n"
        )
        self.assertEqual(d["a"], [])
        self.assertEqual(d["b"], [1, "x", [True, 1.5], {"k": 1}])
        self.assertEqual(d["c"], [1, 2])
        self.assertEqual(d["t"], {})
        self.assertEqual(d["u"], {"x": 1, "y": {"z": 2}})
        self.assertEqual(d["v"], {"a": {"b": 1, "c": 2}})

    def test_crlf_normalised(self):
        self.assertEqual(loads("a = 1\r\nb = 2\r\n"), {"a": 1, "b": 2})
        self.assertEqual(loads('s = """x\r\ny"""\r\n'), {"s": "x\ny"})

    def test_float_converter(self):
        d = loads("a = 1.5\nb = 2\nc = [3.0, {d = nan}]\n", parse_float=lambda t: "F" + t)
        self.assertEqual(d["a"], "F1.5")
        self.assertEqual(d["b"], 2)
        self.assertEqual(d["c"][0], "F3.0")
        self.assertEqual(d["c"][1]["d"], "Fnan")

    def test_converter_dict_or_list_is_value_error(self):
        for bad in (lambda t: {}, lambda t: [], lambda t: type("D", (dict,), {})()):
            with self.assertRaises(ValueError) as cm:
                loads("a = 1.0", parse_float=bad)
            self.assertNotIsInstance(cm.exception, TOMLDecodeError)

    def test_binary_load(self):
        self.assertEqual(load(io.BytesIO(b"a = 1")), {"a": 1})
        self.assertEqual(load(io.BytesIO(b"")), {})
        self.assertEqual(load(io.BytesIO('"é" = \'x\''.encode("utf-8"))), {"é": "x"})
        with self.assertRaises(TypeError):
            load(io.StringIO("a = 1"))
        with self.assertRaises(TOMLDecodeError) as cm:
            load(io.BytesIO(b"a = 1\nb = "))
        self.assertIsInstance(cm.exception.doc, str)


class InvalidDocuments(unittest.TestCase):
    BAD = [
        "a = 1\na = 2",
        "[t]\n[t]",
        "[a]\nx=1\n[a]",
        "a.b = 1\n[a]",
        "a = {b = 1}\na.c = 2",
        "a = {b = 1}\n[a.c]",
        "a = 1\na.b = 2",
        "a = [1]\n[a.b]",
        "[[a]]\n[a]",
        "[a]\n[[a]]",
        "a = [{b = 1}]\n[[a.c]]\n[a]",
        "x = [1, 2 3]",
        "x = [,]",
        "a = 01",
        "a = +0.5.1",
        "a = 1__0",
        "a = 1_",
        "a = _1",
        "a = 0X1",
        "a = +0x1",
        "a = 0x",
        "a = .5",
        "a = 1.",
        "a = True",
        "a = tru",
        "a = 1979-02-29",
        "a = 1979-13-01",
        "a = 12:60:00",
        "a = 24:00:00",
        "a = 1979-05-27T07:32:60Z",
        "a = \"\\X41\"",
        "a = \"\\x4\"",
        "a = \"\\uD800\"",
        "a = \"\\U00110000\"",
        "a = \"unterminated",
        "a = \"tab\x01\"",
        "a = '''x'''' '''",
        "\"\"\"k\"\"\" = 1",
        "'''k''' = 1",
        "= 1",
        "a =",
        "a = 1 2",
        "[a] b = 1",
        "[a",
        "[[a]",
        "[ [a]]",
        "a = 1 # ok\r",
        "a = {b = 1,, c = 2}",
        "a = { b = 1 } x",
        "a = {}}",
        "a = \"\"\"x\"\"\"\"\"\"\"",
        "a = \"\"\"x\r\"\"\"",
        "a = \"\\  x\"",
        "a = \"\"\"x\\ y\"\"\"",
        "a = +inf1",
        "a = 1e",
        "a = '\u0001'",
        "a=1 #\x7f",
    ]

    def test_bad_documents_raise_decode_error(self):
        for doc in self.BAD:
            with self.subTest(doc=doc):
                with self.assertRaises(TOMLDecodeError):
                    loads(doc)

    def test_decode_error_is_value_error_not_type_or_recursion(self):
        self.assertTrue(issubclass(TOMLDecodeError, ValueError))
        self.assertFalse(issubclass(TOMLDecodeError, TypeError))
        self.assertFalse(issubclass(TOMLDecodeError, RecursionError))

    def test_wrong_input_type(self):
        for bad in (b"a = 1", 1, True, io.BytesIO(b"a = 1"), None):
            with self.subTest(bad=bad):
                with self.assertRaises(TypeError) as cm:
                    loads(bad)
                self.assertNotIsInstance(cm.exception, TOMLDecodeError)

    def test_error_location(self):
        err = None
        try:
            loads("a = 1\nb = 2\nc = 0x")
        except TOMLDecodeError as e:
            err = e
        self.assertIsNotNone(err)
        self.assertEqual(err.doc, "a = 1\nb = 2\nc = 0x")
        self.assertEqual(err.lineno, 3)
        self.assertEqual(err.colno, err.pos - err.doc.rfind("\n", 0, err.pos))
        self.assertIn("line 3", str(err))

    def test_constructed_error(self):
        e = TOMLDecodeError("boom", "ab\ncd", 4)
        self.assertEqual((e.msg, e.doc, e.pos, e.lineno, e.colno), ("boom", "ab\ncd", 4, 2, 2))
        e = TOMLDecodeError("eof", "ab", 2)
        self.assertIn("end of document", str(e))


if __name__ == "__main__":
    unittest.main()
