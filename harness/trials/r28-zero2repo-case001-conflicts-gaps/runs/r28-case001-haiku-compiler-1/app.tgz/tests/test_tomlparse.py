"""Tests for tomlparse, grouped by feature point (FP-01..FP-05) and interface.

Run from /app with: PYTHONPATH=src python -m pytest tests
Each test names the spec ids it covers in its docstring.
"""

import datetime as dt
import io
import pickle
import unittest

import tomlparse
from tomlparse import TOMLDecodeError, load, loads


def nan_safe(value):
    """repr-based comparison helper for documents containing nan."""
    return repr(value)


class Interface(unittest.TestCase):
    """# spec: N-000266 N-000270 N-000271 N-000272 N-000273 N-000307 N-000308 N-000314"""

    def test_public_names(self):
        for name in ("loads", "load", "TOMLDecodeError"):
            self.assertTrue(hasattr(tomlparse, name))
        self.assertTrue(issubclass(TOMLDecodeError, ValueError))
        self.assertFalse(issubclass(TOMLDecodeError, TypeError))
        self.assertFalse(issubclass(TOMLDecodeError, RecursionError))

    def test_no_writer_or_cli(self):
        # spec: N-000259 N-000260 N-000261
        for name in ("dump", "dumps", "main"):
            self.assertFalse(hasattr(tomlparse, name))

    def test_parse_float_is_keyword_only(self):
        # spec: N-000274 N-000275
        with self.assertRaises(TypeError):
            loads("a = 1.0", float)


class Error(unittest.TestCase):
    """FP-04 decode error: attributes, location, formatted report, construction."""

    def test_attributes_and_location(self):
        # spec: N-000203 N-000204 N-000205 N-000206 N-000207 N-000314 N-000315 N-000316 N-000317 N-000318 N-000319
        try:
            loads("a = 1\nb = [1,\n  2 3]\n")
        except TOMLDecodeError as err:
            self.assertIsInstance(err.msg, str)
            self.assertEqual(err.doc, "a = 1\nb = [1,\n  2 3]\n")
            self.assertEqual(err.pos, 18)
            self.assertEqual(err.doc[err.pos], "3")
            self.assertEqual(err.lineno, 3)
            self.assertEqual(err.colno, 5)
            self.assertIn("line 3", str(err))
            self.assertIn("column 5", str(err))
        else:
            self.fail("expected TOMLDecodeError")

    def test_end_of_document_location(self):
        # spec: N-000209 N-000322
        try:
            loads("a = 1\nb = ")
        except TOMLDecodeError as err:
            self.assertEqual(err.pos, len("a = 1\nb = "))
            self.assertIn("end of document", str(err))
        else:
            self.fail("expected TOMLDecodeError")

    def test_constructed_by_caller(self):
        # spec: N-000210 N-000211 N-000212 N-000309 N-000310 N-000311 N-000312 N-000313
        err = TOMLDecodeError("boom", "ab\ncd", 4)
        self.assertEqual((err.msg, err.doc, err.pos), ("boom", "ab\ncd", 4))
        self.assertEqual((err.lineno, err.colno), (2, 2))
        self.assertIn("boom", str(err))
        self.assertIn("line 2", str(err))
        clone = pickle.loads(pickle.dumps(err))
        self.assertEqual((clone.msg, clone.doc, clone.pos), ("boom", "ab\ncd", 4))

    def test_wrong_python_type_is_type_error(self):
        # spec: N-000213 N-000214 N-000215 N-000297 N-000298
        for bad in (b"a = 1", 1, None, True, io.StringIO("a = 1")):
            with self.assertRaises(TypeError) as ctx:
                loads(bad)
            self.assertNotIsInstance(ctx.exception, TOMLDecodeError)

    def test_invalid_document_is_decode_error(self):
        # spec: N-000198 N-000199 N-000200 N-000201 N-000202
        for doc in ("a = 01", "a = 1 b = 2", "[a]\n[a]", 'a = "x'):
            with self.assertRaises(TOMLDecodeError):
                loads(doc)


class FP01Structure(unittest.TestCase):
    """FP-01: document structure from text."""

    def test_empty_documents(self):
        # spec: N-000082
        self.assertEqual(loads(""), {})
        self.assertEqual(loads("   \t \n"), {})
        self.assertEqual(loads("# only a comment"), {})
        self.assertEqual(loads("# only\n# comments\n"), {})

    def test_root_and_table_pairs(self):
        # spec: N-000083 N-000084
        self.assertEqual(
            loads('a = 1\n[t]\nb = 2\n[u]\nc = 3\n'),
            {"a": 1, "t": {"b": 2}, "u": {"c": 3}},
        )

    def test_keys_are_strings(self):
        # spec: N-000085 N-000086 N-000087 N-000088
        self.assertEqual(
            loads('true = 1\nfalse = 2\ninf = 3\nnan = 4\n1979-05-27 = 5\n0x1 = 6\n1e3 = 7\n'),
            {"true": 1, "false": 2, "inf": 3, "nan": 4, "1979-05-27": 5, "0x1": 6, "1e3": 7},
        )
        self.assertEqual(loads("A = 1\na = 2"), {"A": 1, "a": 2})

    def test_quoted_keys(self):
        # spec: N-000089 N-000090 N-000091 N-000092 N-000142
        self.assertEqual(
            loads('"" = 1\n"a.b" = 2\n\'c d\' = 3\n"é #" = 4\n"\\t" = 5\n\'\\t\' = 6\n'),
            {"": 1, "a.b": 2, "c d": 3, "é #": 4, "\t": 5, "\\t": 6},
        )

    def test_dotted_keys_and_headers(self):
        # spec: N-000093 N-000094 N-000095
        self.assertEqual(loads("a . b . c = 1\na.d = 2"), {"a": {"b": {"c": 1}, "d": 2}})
        self.assertEqual(loads("[ x . y ]\nz = 1"), {"x": {"y": {"z": 1}}})

    def test_headers_create_parents(self):
        # spec: N-000096 N-000097
        self.assertEqual(loads("[a.b]\nc = 1\n[a]\nd = 2"), {"a": {"b": {"c": 1}, "d": 2}})

    def test_dotted_table_gets_subtable_by_header(self):
        # spec: N-000098 CF-000012 (reading adopted in NOTES.md)
        doc = (
            "[fruit]\n"
            "apple.color = \"red\"\n"
            "apple.taste.sweet = true\n"
            "[fruit.apple.texture]\n"
            "smooth = true\n"
        )
        self.assertEqual(
            loads(doc),
            {"fruit": {"apple": {"color": "red", "taste": {"sweet": True}, "texture": {"smooth": True}}}},
        )

    def test_array_of_tables(self):
        # spec: N-000099 N-000100 N-000101 N-000102
        self.assertEqual(
            loads("[[x]]\na = 1\n[[x]]\na = 2\n[x.sub]\nq = 3\n"),
            {"x": [{"a": 1}, {"a": 2, "sub": {"q": 3}}]},
        )
        self.assertEqual(
            loads("[[a.b]]\nc = 1\n[a]\nd = 2"),
            {"a": {"b": [{"c": 1}], "d": 2}},
        )

    def test_inline_tables(self):
        # spec: N-000103 N-000104
        self.assertEqual(loads("a = {}"), {"a": {}})
        self.assertEqual(
            loads("a = {\n  x = 1, # c\n  y.z = 2,\n}\n"),
            {"a": {"x": 1, "y": {"z": 2}}},
        )

    def test_arrays(self):
        # spec: N-000105 N-000106 N-000282
        self.assertEqual(loads("a = []"), {"a": []})
        self.assertEqual(
            loads('a = [\n  1, # one\n  "x", [2, 3],\n]\n'),
            {"a": [1, "x", [2, 3]]},
        )
        self.assertEqual(loads("a = [1, 'x', true]"), {"a": [1, "x", True]})

    def test_comments_and_whitespace(self):
        # spec: N-000107 N-000108 N-000109 N-000110
        self.assertEqual(loads("a=1#c\nb\t=\t2 \t# é\n"), {"a": 1, "b": 2})
        self.assertEqual(loads("\t[t]  # x\n\t\tk = 1\n"), {"t": {"k": 1}})

    def test_crlf_is_single_line_feed(self):
        # spec: N-000111 N-000112
        self.assertEqual(loads('a = """x\r\ny"""\r\nb = 1\r\n'), {"a": "x\ny", "b": 1})
        self.assertEqual(loads("a = '''\r\nx\r\n'''"), {"a": "x\n"})

    def test_forbidden_structures(self):
        # spec: N-000113 N-000114 N-000115 N-000116 N-000117 N-000118 N-000119 N-000120 N-000121 N-000122
        bad_docs = [
            "a = 1\na = 2",  # duplicate key
            "[a]\n[a]",  # table defined twice
            "[a]\nb = 1\n[a]",
            "a.b = 1\na.b = 2",
            "[a.b]\n[a]\nb.c = 1",  # dotted keys reopen a header table
            "a = 1\n[a]",  # value replaced by a table
            "a = 1\n[a.b]",
            "a = 1\n[[a]]",
            "a = {x = 1}\na.y = 2",  # adding to inline table
            "a = {x = 1}\n[a.y]",
            "[[x]]\n[x]",  # table where an array of tables is
            "x = [1]\n[[x]]",
            "x = [{a = 1}]\nx.b = 2",  # static array extended by dotted key
            "[t]\n= 1",  # pair with no key
            "[t]\nk =",  # pair with no value
            "[a]\nb = 1 [c]",  # header sharing its line with a pair (after value)
            "[a] b = 1",  # header followed by a pair on the same line
            "[a\n]",  # header not closed on its line
            '"""k""" = 1',  # multi-line string as key
            '[""""a""""]',
        ]
        for doc in bad_docs:
            with self.subTest(doc=doc):
                with self.assertRaises(TOMLDecodeError):
                    loads(doc)

    def test_aot_parent_declared_later(self):
        # spec: N-000102
        self.assertEqual(
            loads("[[a.b]]\nx = 1\n[a]\ny = 2\n[[a.b]]\nx = 3\n"),
            {"a": {"b": [{"x": 1}, {"x": 3}], "y": 2}},
        )

    def test_header_inside_last_array_element(self):
        # spec: N-000100
        self.assertEqual(
            loads("[[fruit]]\nname = 'a'\n[fruit.physical]\ncolor = 'red'\n[[fruit]]\nname = 'b'\n"),
            {"fruit": [{"name": "a", "physical": {"color": "red"}}, {"name": "b"}]},
        )


class FP02Scalars(unittest.TestCase):
    """FP-02: scalar types."""

    def test_booleans(self):
        # spec: N-000124 N-000125 N-000126
        result = loads("a = true\nb = false")
        self.assertIs(result["a"], True)
        self.assertIs(result["b"], False)
        for bad in ("a = True", "a = TRUE", "a = tru"):
            with self.subTest(doc=bad), self.assertRaises(TOMLDecodeError):
                loads(bad)

    def test_basic_string_escapes(self):
        # spec: N-000127 N-000128 N-000137 N-000138 N-000139 N-000140 N-000143 N-000146
        self.assertEqual(
            loads('s = "a\\tb\\n\\u00e9\\U0001F600\\x41\\e\\"\\\\\\b\\f\\r"')["s"],
            "a\tb\n\u00e9\U0001F600A\x1b\"\\\b\f\r",
        )
        self.assertEqual(loads('s = "\\x4A\\u004a"')["s"], "JJ")
        self.assertEqual(loads('s = "\\xfF"')["s"], "\u00ff")

    def test_bad_escapes(self):
        # spec: N-000174 N-000175 N-000176 N-000177
        for doc in ('s = "\\q"', 's = "\\x4"', 's = "\\uD800"', 's = "\\U00110000"', 's = "\\X41"', 's = "\\u00G1"'):
            with self.subTest(doc=doc), self.assertRaises(TOMLDecodeError):
                loads(doc)

    def test_literal_strings(self):
        # spec: N-000129 N-000130 N-000141
        self.assertEqual(loads("s = 'C:\\path\\n'")["s"], "C:\\path\\n")

    def test_multiline_basic(self):
        # spec: N-000131 N-000132 N-000133 N-000134 N-000135 N-000136
        self.assertEqual(loads('s = """\nhello\nworld"""')["s"], "hello\nworld")
        self.assertEqual(loads('s = """a\\\n   b  \n\n  c"""')["s"], "ab  \n\n  c")
        self.assertEqual(loads('s = """x"""""')["s"], 'x""')
        self.assertEqual(loads('s = """x""""')["s"], 'x"')
        self.assertEqual(loads('s = """a"b""c"""')["s"], 'a"b""c')

    def test_multiline_literal(self):
        # spec: N-000130 N-000131 N-000135
        self.assertEqual(loads("s = '''\nfirst\nsecond'''")["s"], "first\nsecond")
        self.assertEqual(loads("s = '''\n\nx'''")["s"], "\nx")
        self.assertEqual(loads("s = '''a\\nb'''")["s"], "a\\nb")
        self.assertEqual(loads("s = ''''x''''")["s"], "'x'")

    def test_bad_strings(self):
        # spec: N-000178
        for doc in ('s = "a\x01b"', 's = "a\nb"', 's = """a\rb"""', "s = 'a\nb'", "s = 'unterminated", 's = """a""""""'):
            with self.subTest(doc=doc), self.assertRaises(TOMLDecodeError):
                loads(doc)

    def test_tab_in_strings(self):
        # spec: N-000108 (control characters other than tab are refused; tab is kept)
        self.assertEqual(loads('s = "a\tb"')["s"], "a\tb")
        self.assertEqual(loads("s = 'a\tb'")["s"], "a\tb")

    def test_integers(self):
        # spec: N-000144 N-000145 N-000146 N-000147
        self.assertEqual(
            loads("a = 0xff\nb = 0o17\nc = 0b1010\nd = 1_000\ne = -0\nf = +0\ng = 0xDEAD_beef\nh = -17\n"),
            {"a": 255, "b": 15, "c": 10, "d": 1000, "e": 0, "f": 0, "g": 0xDEADBEEF, "h": -17},
        )
        self.assertIsInstance(loads("a = 1")["a"], int)

    def test_integers_are_not_bool(self):
        # spec: N-000283 N-000284
        self.assertIs(type(loads("a = 1")["a"]), int)
        self.assertIs(type(loads("a = 0")["a"]), int)

    def test_bad_integers(self):
        # spec: N-000167 N-000168 N-000169 N-000170 N-000171 N-000172
        for doc in (
            "a = 0X1", "a = 0xG", "a = -0x1", "a = +0o7", "a = 01", "a = 00", "a = -01",
            "a = 1__0", "a = 1_", "a = _1", "a = 0b102", "a = 0x_1", "a = 0o8",
        ):
            with self.subTest(doc=doc), self.assertRaises(TOMLDecodeError):
                loads(doc)

    def test_floats(self):
        # spec: N-000148 N-000149 N-000150 N-000173
        result = loads("a = 1e5\nb = 1E-2\nc = -1.5e+3\nd = 6.626_070e-34\ne = 3.0\nf = -0.0\ng = 1e05")
        self.assertEqual(result["a"], 1e5)
        self.assertEqual(result["b"], 1e-2)
        self.assertEqual(result["c"], -1.5e3)
        self.assertEqual(result["d"], 6.626070e-34)
        self.assertEqual(result["e"], 3.0)
        self.assertIsInstance(result["e"], float)
        self.assertEqual(result["g"], 1e5)

    def test_special_floats(self):
        # spec: N-000148 N-000150
        result = loads("a = inf\nb = +inf\nc = -inf\nd = nan\ne = +nan\nf = -nan")
        self.assertEqual(result["a"], float("inf"))
        self.assertEqual(result["b"], float("inf"))
        self.assertEqual(result["c"], float("-inf"))
        for key in ("d", "e", "f"):
            self.assertTrue(result[key] != result[key])

    def test_bad_floats(self):
        # spec: N-000173
        for doc in ("a = 1.", "a = .5", "a = +.5", "a = 1.e5", "a = 0.5.1", "a = 1._5", "a = 1e", "a = 1_.5", "a = 1.5_"):
            with self.subTest(doc=doc), self.assertRaises(TOMLDecodeError):
                loads(doc)

    def test_date_times(self):
        # spec: N-000151 N-000152 N-000153 N-000159 N-000160 N-000161
        result = loads(
            "d = 1979-05-27\n"
            "t = 07:32:00\n"
            "l = 1979-05-27T07:32:00\n"
            "o = 1979-05-27T07:32:00Z\n"
            "p = 1979-05-27t07:32:00z\n"
            "q = 1979-05-27 07:32:00-07:00\n"
            "r = 1979-05-27T00:32:00.5+05:30\n"
            "m = 07:32\n"
        )
        self.assertEqual(result["d"], dt.date(1979, 5, 27))
        self.assertEqual(result["t"], dt.time(7, 32))
        self.assertIsNone(result["l"].tzinfo)
        self.assertEqual(result["l"], dt.datetime(1979, 5, 27, 7, 32))
        self.assertEqual(result["o"], dt.datetime(1979, 5, 27, 7, 32, tzinfo=dt.timezone.utc))
        self.assertEqual(result["o"].utcoffset(), dt.timedelta(0))
        self.assertEqual(result["p"], result["o"])
        self.assertEqual(result["q"].utcoffset(), dt.timedelta(hours=-7))
        self.assertEqual(result["r"].utcoffset(), dt.timedelta(hours=5, minutes=30))
        self.assertEqual(result["r"].microsecond, 500000)
        self.assertEqual(result["m"], dt.time(7, 32))
        self.assertIsNone(result["m"].tzinfo)

    def test_fraction_truncated_to_microseconds(self):
        # spec: N-000155 N-000156 N-000157 N-000158 (CF-000045, CF-000069: truncation adopted)
        result = loads("t = 07:32:00.1234567\nu = 1979-05-27T07:32:00.9999999Z\nv = 00:00:00.0000001")
        self.assertEqual(result["t"].microsecond, 123456)
        self.assertEqual(result["u"].microsecond, 999999)
        self.assertEqual(result["v"].microsecond, 0)
        self.assertEqual(loads("t = 00:00:00.5")["t"].microsecond, 500000)

    def test_leap_day_and_calendar(self):
        # spec: N-000159 N-000179
        self.assertEqual(loads("d = 2024-02-29")["d"], dt.date(2024, 2, 29))
        for doc in ("d = 2023-02-29", "d = 2024-13-01", "t = 24:00:00", "t = 07:60:00",
                    "t = 07:32:60", "t = 7:32:00", "o = 1979-05-27T07:32:00+24:00",
                    "d = 1979-5-27", "d = 1979-05-27T07:32Z x"):
            with self.subTest(doc=doc), self.assertRaises(TOMLDecodeError):
                loads(doc)

    def test_seconds_optional(self):
        # spec: N-000154 CF-000062 (adopted: seconds may be omitted in any time value)
        self.assertEqual(loads("t = 07:32")["t"], dt.time(7, 32))
        self.assertEqual(loads("o = 1979-05-27T07:32Z")["o"], dt.datetime(1979, 5, 27, 7, 32, tzinfo=dt.timezone.utc))

    def test_date_time_copy_and_compare(self):
        # spec: N-000160 N-000161
        import copy
        value = loads("o = 1979-05-27T07:32:00Z")["o"]
        self.assertEqual(copy.deepcopy(value), value)
        self.assertEqual(copy.copy(value), value)


class FP03BinaryFile(unittest.TestCase):
    """FP-03: binary file entry."""

    def test_binary_file_and_buffer(self):
        # spec: N-000181 N-000183 N-000184 N-000189
        self.assertEqual(load(io.BytesIO(b'x = "\xc3\xa9"\n')), {"x": "\u00e9"})
        self.assertEqual(load(io.BytesIO(b"")), {})

    def test_same_result_as_text(self):
        # spec: N-000187 N-000188
        doc = 'a = 1\r\n[t]\r\nb = """x\r\ny"""\r\n'
        self.assertEqual(load(io.BytesIO(doc.encode("utf-8"))), loads(doc))

    def test_text_mode_refused(self):
        # spec: N-000190 N-000191 N-000192 N-000216 N-000304
        with self.assertRaises(TypeError) as ctx:
            load(io.StringIO("a = 1"))
        self.assertNotIsInstance(ctx.exception, TOMLDecodeError)
        with self.assertRaises(TypeError):
            load(io.StringIO(""))
        with self.assertRaises(TypeError):
            load(io.TextIOWrapper(io.BytesIO(b"")))

    def test_decode_error_location_matches_text(self):
        # spec: N-000193 N-000194 N-000195
        with self.assertRaises(TOMLDecodeError) as ctx:
            load(io.BytesIO(b"a = [1,\n 2 3]"))
        self.assertEqual(ctx.exception.doc, "a = [1,\n 2 3]")
        self.assertIsInstance(ctx.exception.doc, str)

    def test_invalid_utf8_is_not_decode_error(self):
        # spec: N-000181 (bytes are interpreted as UTF-8; no decoded text exists to report)
        with self.assertRaises(UnicodeDecodeError):
            load(io.BytesIO(b'a = "\xff"'))

    def test_not_a_file_is_type_error(self):
        with self.assertRaises(TypeError):
            load(42)
        with self.assertRaises(TypeError):
            load(object())


class FP05Converter(unittest.TestCase):
    """FP-05: caller-supplied float converter."""

    def test_converter_gets_text_as_written(self):
        # spec: N-000223 N-000224 N-000225 N-000226 N-000227 N-000275 N-000276 N-000277
        seen = []

        def conv(text):
            seen.append(text)
            return ("F", text)

        result = loads("a = 1_000.5\nb = -1e+3\nc = inf\nd = -nan\ne = 7\n[t]\nf = [2.5]\ng = {h = 3.25}", parse_float=conv)
        self.assertEqual(seen, ["1_000.5", "-1e+3", "inf", "-nan", "2.5", "3.25"])
        self.assertEqual(result["a"], ("F", "1_000.5"))
        self.assertEqual(result["e"], 7)
        self.assertEqual(result["t"]["f"], [("F", "2.5")])
        self.assertEqual(result["t"]["g"]["h"], ("F", "3.25"))

    def test_converter_not_called_for_non_floats(self):
        # spec: N-000228 N-000229
        seen = []
        loads('a = 1\nb = "x"\nc = true\nd = 1979-05-27\n', parse_float=lambda t: seen.append(t))
        self.assertEqual(seen, [])

    def test_underscore_default_float(self):
        # spec: N-000148 N-000275 (the default converter receives text with underscores)
        self.assertEqual(loads("a = 1_0.0_1")["a"], 10.01)

    def test_converter_result_dict_or_list_is_value_error(self):
        # spec: N-000232 N-000233 CF-000023 CF-000032 (subclasses refused)
        class D(dict):
            pass

        class L(list):
            pass

        for bad in ({}, [], D(), L()):
            with self.subTest(result=type(bad).__name__), self.assertRaises(ValueError) as ctx:
                loads("a = 1.5", parse_float=lambda t, bad=bad: bad)
            self.assertNotIsInstance(ctx.exception, TOMLDecodeError)

    def test_converter_may_return_any_other_value(self):
        # spec: N-000230 N-000231
        self.assertEqual(loads("a = 1.5", parse_float=lambda t: "x")["a"], "x")
        self.assertIsNone(loads("a = 1.5", parse_float=lambda t: None)["a"])
        self.assertEqual(loads("a = 1.5", parse_float=str)["a"], "1.5")

    def test_converter_applies_to_load(self):
        # spec: N-000182 N-000220
        self.assertEqual(load(io.BytesIO(b"a = 2.0"), parse_float=lambda t: t)["a"], "2.0")


class Conflicts(unittest.TestCase):
    """Resolved contradictions listed in NOTES.md."""

    def test_cf_000001_quote_before_multiline_closing_delimiter(self):
        self.assertEqual(loads('s = """a""""')["s"], 'a"')

    def test_cf_000008_crlf_multiline_holds_line_feeds(self):
        self.assertEqual(loads('s = """a\r\nb"""')["s"], "a\nb")

    def test_cf_000009_first_line_feed_of_multiline_literal_dropped(self):
        self.assertEqual(loads("s = '''\nx'''")["s"], "x")

    def test_cf_000015_line_ending_backslash_trims_next_line(self):
        self.assertEqual(loads('s = """a\\\n    b"""')["s"], "ab")

    def test_cf_000028_035_raw_tab_in_literal_string(self):
        self.assertEqual(loads("s = 'a\tb'")["s"], "a\tb")

    def test_cf_000037_hex_digits_either_case(self):
        self.assertEqual(loads("a = 0xAbC")["a"], 0xABC)

    def test_cf_000059_trailing_comma_in_array(self):
        self.assertEqual(loads("a = [1, 2,]")["a"], [1, 2])

    def test_cf_000065_signed_zero(self):
        self.assertEqual(loads("a = +0\nb = -0")["a"], 0)

    def test_cf_000068_space_separator_and_offset_separator(self):
        self.assertEqual(
            loads("a = 1979-05-27 07:32:00Z")["a"],
            dt.datetime(1979, 5, 27, 7, 32, tzinfo=dt.timezone.utc),
        )


class Surface(unittest.TestCase):
    """Import contract: PYTHONPATH=src exposes the package."""

    def test_src_layout_import(self):
        # spec: N-000266 N-000267 N-000268
        self.assertTrue(tomlparse.__file__.replace("\\", "/").endswith("src/tomlparse/__init__.py"))


if __name__ == "__main__":
    unittest.main()
