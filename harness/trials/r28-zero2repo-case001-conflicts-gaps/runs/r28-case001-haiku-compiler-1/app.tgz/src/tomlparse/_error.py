"""The decode error. # spec: N-000307 N-000308 N-000309 N-000310 N-000311 N-000312
N-000313 N-000314 N-000315 N-000316 N-000317 N-000318 N-000319 N-000320 N-000321
N-000322 N-000323 N-000203 N-000204 N-000205 N-000206 N-000207 N-000208 N-000209
N-000210 N-000211 N-000212 N-000219 N-000217 N-000198 N-000199 N-000200 N-000201
N-000202
"""


class TOMLDecodeError(ValueError):
    """Raised when a document is not valid TOML v1.1.0.

    Constructor: ``TOMLDecodeError(msg, doc, pos)``. ``msg`` is the unformatted
    reason, ``doc`` the document text, ``pos`` a 0-based character offset into
    ``doc``. ``lineno`` (1-based) and ``colno`` (1-based) are derived from
    ``pos``: the line is 1 plus the number of line feeds before ``pos``; the
    column is 1 plus the characters between the last line feed before ``pos``
    (or the start of ``doc``) and ``pos``.
    """

    def __init__(self, msg, doc, pos):
        self.msg = msg
        self.doc = doc
        self.pos = pos
        self.lineno = doc.count("\n", 0, pos) + 1
        self.colno = pos - doc.rfind("\n", 0, pos)
        if pos >= len(doc):
            location = "at end of document, line %d, column %d" % (self.lineno, self.colno)
        else:
            location = "at line %d, column %d" % (self.lineno, self.colno)
        ValueError.__init__(self, "%s (%s)" % (msg, location))

    def __reduce__(self):
        # Keep the error picklable with its three constructor arguments.
        return (self.__class__, (self.msg, self.doc, self.pos))
