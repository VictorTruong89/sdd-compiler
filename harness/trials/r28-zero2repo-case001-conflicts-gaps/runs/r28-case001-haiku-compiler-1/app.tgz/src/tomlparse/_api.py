"""Public parse entries: ``loads`` (text) and ``load`` (binary file).

# spec: N-000255 N-000256 N-000257 N-000259 N-000260 N-000261 (parse only; no writer,
#   no CLI; entries return or raise, no I/O of their own beyond the given file)
# spec: N-000266 N-000267 N-000268 N-000270 N-000271 N-000272 N-000273 (public names)
# spec: N-000274 N-000275 N-000276 N-000277 N-000278 N-000279 N-000293 N-000294
#   N-000295 N-000296 N-000297 N-000298 (loads signature, failures)
# spec: N-000299 N-000300 N-000301 N-000302 N-000303 N-000304 N-000305 N-000306 (load)
# spec: N-000181 N-000182 N-000183 N-000184 N-000185 N-000186 N-000187 N-000188
#   N-000189 N-000190 N-000191 N-000192 N-000193 N-000194 N-000195 N-000196 (FP-03)
# spec: N-000213 N-000214 N-000215 N-000216 N-000217 (FP-04 type errors)
# spec: N-000034 N-000033 N-000035 N-000036 N-000037 N-000038 N-000031 N-000032 N-000039
# spec: N-000040 N-000043 N-000046 N-000047 N-000048 N-000051 N-000052 N-000243 N-000244
#   (pure Python, stdlib only, CPU, imported from source)
"""

import io

from ._parser import parse as _parse


def loads(s, *, parse_float=float):
    """Parse a TOML v1.1.0 document from a Python text string into a dict.

    ``parse_float`` is called with each float's text as written in the
    document; its result is stored in place of the float. Raises TypeError for
    a non-str argument, TOMLDecodeError for invalid TOML, and ValueError if
    ``parse_float`` returns a dict or list.
    """
    if not isinstance(s, str):
        raise TypeError("loads() expects a str, not %s" % type(s).__name__)
    return _parse(s, parse_float)


def load(fp, *, parse_float=float):
    """Parse TOML from a binary file object (UTF-8 bytes) into a dict.

    Raises TypeError for a text-mode file object or any non-binary read result.
    The bytes are decoded as UTF-8; invalid UTF-8 raises UnicodeDecodeError
    (a ValueError), not TOMLDecodeError, because there is no decoded text to
    report. Other errors are as for ``loads``.
    """
    if isinstance(fp, io.TextIOBase):
        raise TypeError("load() expects a binary file object, not a text-mode file")
    read = getattr(fp, "read", None)
    if not callable(read):
        raise TypeError("load() expects a file object with a read() method")
    data = read()
    if isinstance(data, str):
        raise TypeError("load() expects bytes from the file, not str (text-mode file)")
    if not isinstance(data, (bytes, bytearray, memoryview)):
        raise TypeError("load() expects bytes from the file, not %s" % type(data).__name__)
    text = bytes(data).decode("utf-8")
    return _parse(text, parse_float)
