"""Tomlparse: parse TOML v1.1.0 text into ordinary Python values.

Public names: ``loads``, ``load``, ``TOMLDecodeError``.
# spec: N-000266 N-000270 N-000271 N-000272 N-000273
"""

from ._api import load, loads
from ._error import TOMLDecodeError

__all__ = ["loads", "load", "TOMLDecodeError"]
