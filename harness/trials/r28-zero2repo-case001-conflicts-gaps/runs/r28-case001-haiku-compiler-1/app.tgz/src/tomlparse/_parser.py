"""Hand-written TOML v1.1.0 parser core.

The parser walks the document text once with a cursor (``self.i``). It never
delegates to another TOML parser. Table ownership is tracked per table object
so that headers, dotted keys and inline tables obey the TOML rules about
redefinition (see ``_assign`` and the header helpers).
"""

import datetime as _dt
import re

from ._error import TOMLDecodeError

# Kinds of table, recorded per object. Lists are AOT (array of tables) or,
# when unrecorded, static arrays.
_ROOT = "root"
_HEADER = "header"  # defined by a [table] or [[array]] header element
_DOTTED = "dotted"  # created by dotted keys; may be extended by dotted keys
_IMPLICIT = "implicit"  # created as a missing parent; a header may declare it
_INLINE = "inline"  # written as an inline table; frozen once closed
_AOT = "aot"  # array of tables (list)

_BARE_KEY_CHARS = frozenset(
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-"
)
_HEX_DIGITS = frozenset("0123456789abcdefABCDEF")
_SIMPLE_ESCAPES = {
    "b": "\b",
    "t": "\t",
    "n": "\n",
    "f": "\f",
    "r": "\r",
    "e": "\x1b",
    '"': '"',
    "\\": "\\",
}
_ESCAPE_WIDTHS = {"x": 2, "u": 4, "U": 8}

# Local time: HH:MM with optional :SS and optional .fraction (seconds only).
_LOCAL_TIME_RE = re.compile(r"([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?")
# Date, optionally followed by a time and an optional offset. Groups:
# 1-3 date, 4-5 hour/minute, 6 second, 7 fraction, 8 Z, 9 sign, 10-11 offset.
_DATETIME_RE = re.compile(
    r"([0-9]{4})-([0-9]{2})-([0-9]{2})"
    r"(?:[Tt ]([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?"
    r"(?:([Zz])|([+-])([0-9]{2}):([0-9]{2}))?)?"
)
_SPECIAL_FLOAT_RE = re.compile(r"[+-]?(?:inf|nan)")
_HEX_RE = re.compile(r"0x([0-9A-Fa-f]+(?:_[0-9A-Fa-f]+)*)")
_OCT_RE = re.compile(r"0o([0-7]+(?:_[0-7]+)*)")
_BIN_RE = re.compile(r"0b([01]+(?:_[01]+)*)")
# Decimal integer or float. Groups: 1 sign, 2 integer digits, 3 fraction,
# 4 exponent. A float has a fraction, an exponent, or both.
_DEC_RE = re.compile(
    r"([+-]?)(0|[1-9](?:_?[0-9])*)(\.[0-9](?:_?[0-9])*)?([eE][+-]?[0-9](?:_?[0-9])*)?"
)
_RADIX_RES = {"x": (_HEX_RE, 16), "o": (_OCT_RE, 8), "b": (_BIN_RE, 2)}


def _bad_char(c):
    """True for characters TOML forbids in strings and comments.

    Control characters other than tab, DEL, and lone surrogates are refused.
    Line feed and carriage return are handled by the callers. # spec: N-000178
    N-000108 N-000109 N-000111 N-000112 N-000133
    """
    o = ord(c)
    return (o < 0x20 and c != "\t") or o == 0x7F or 0xD800 <= o <= 0xDFFF


def _decimal_int(text):
    """Convert a signed decimal integer literal (no underscores) to int.

    Long literals are converted in chunks so that CPython's int-string digit
    limit does not reject a valid TOML integer. # spec: N-000144 N-000145 N-000147
    """
    sign = ""
    if text[:1] in ("+", "-"):
        sign, text = text[0], text[1:]
    chunk = 4000
    value = 0
    for start in range(0, len(text), chunk):
        part = text[start : start + chunk]
        value = value * (10 ** len(part)) + int(part)
    return -value if sign == "-" else value


def _micro(frac):
    """Fraction digits to microseconds: pad to six digits, drop the rest (truncate).

    # spec: N-000154 N-000155 N-000156 N-000157 N-000158
    """
    if frac is None:
        return 0
    return int((frac + "000000")[:6])


class _Parser:
    def __init__(self, text, parse_float):
        self.s = text
        self.n = len(text)
        self.i = 0
        self.root = {}
        self._float = parse_float
        self._kinds = {}  # id(obj) -> (kind, obj); holding obj keeps the id valid
        self._mark(self.root, _ROOT)

    # ----- bookkeeping -------------------------------------------------

    def _mark(self, obj, kind):
        self._kinds[id(obj)] = (kind, obj)

    def _kind(self, obj):
        entry = self._kinds.get(id(obj))
        return entry[0] if entry is not None else None

    def _new_table(self, kind):
        t = {}
        self._mark(t, kind)
        return t

    def _err(self, msg, pos):
        return TOMLDecodeError(msg, self.s, pos)

    def _peek(self):
        return self.s[self.i] if self.i < self.n else ""

    def _at_newline(self):
        s, i = self.s, self.i
        return s.startswith("\n", i) or s.startswith("\r\n", i)

    def _newline_len(self):
        return 2 if self.s.startswith("\r\n", self.i) else 1

    # ----- whitespace, comments, end of line ----------------------------

    def _skip_ws(self):
        """Spaces and tabs only. # spec: N-000110"""
        s, n = self.s, self.n
        while self.i < n and s[self.i] in " \t":
            self.i += 1

    def _skip_blank(self):
        """Whitespace, line endings and comments (inside arrays and inline tables).

        # spec: N-000107 N-000110 N-000105 N-000104 N-000112
        """
        while self.i < self.n:
            c = self.s[self.i]
            if c in " \t":
                self.i += 1
            elif self._at_newline():
                self.i += self._newline_len()
            elif c == "#":
                self._comment()
            else:
                break

    def _comment(self):
        """Skip a comment starting at '#'; stops before the line ending. # spec: N-000107 N-000108 N-000109"""
        s, n = self.s, self.n
        i = self.i + 1
        while i < n:
            c = s[i]
            if c == "\n" or (c == "\r" and s.startswith("\n", i + 1)):
                break
            if _bad_char(c):
                raise self._err("control character not allowed in a comment", i)
            i += 1
        self.i = i

    def _expect_eol(self):
        """After a key/value pair or table header: optional comment, then line end or end of text.

        # spec: N-000122 N-000114 N-000115
        """
        self._skip_ws()
        if self.i >= self.n:
            return
        c = self._peek()
        if c == "#":
            self._comment()
            return
        if self._at_newline():
            return
        raise self._err("expected end of line", self.i)

    # ----- document -----------------------------------------------------

    def parse(self):
        """# spec: N-000082 N-000083 N-000084 N-000111 N-000113 N-000121 N-000116"""
        cur = self.root
        while True:
            self._skip_ws()
            if self.i >= self.n:
                break
            if self._at_newline():
                self.i += self._newline_len()
                continue
            c = self._peek()
            if c == "#":
                self._comment()
                continue
            if c == "[":
                cur = self._header()
            else:
                self._keyval(cur)
            self._expect_eol()
        return self.root

    # ----- table headers ------------------------------------------------

    def _header(self):
        """Parse [table] or [[array]] and return the table that following pairs belong to.

        # spec: N-000096 N-000097 N-000098 N-000099 N-000100 N-000101 N-000102
        N-000113 N-000114 N-000115 N-000118
        """
        s = self.s
        start = self.i
        aot = s.startswith("[[", start)
        self.i += 2 if aot else 1
        self._skip_ws()
        keys = self._key()
        self._skip_ws()
        if not s.startswith("]", self.i):
            raise self._err("expected ']' to close table header", self.i)
        self.i += 1
        if aot:
            if not s.startswith("]", self.i):
                raise self._err("expected ']]' to close array of tables header", self.i)
            self.i += 1
        table = self.root
        for k in keys[:-1]:
            table = self._descend(table, k, start)
        last = keys[-1]
        if aot:
            return self._header_aot(table, last, start)
        return self._header_table(table, last, start)

    def _descend(self, table, key, pos):
        """Step into the parent table ``key`` of a header path, creating it as implicit if missing.

        A header path runs through an array of tables into its last element.
        # spec: N-000096 N-000099 N-000100 N-000101 N-000102 N-000098
        """
        if key not in table:
            t = self._new_table(_IMPLICIT)
            table[key] = t
            return t
        v = table[key]
        if isinstance(v, list):
            if self._kind(v) == _AOT:
                return v[-1]
            raise self._err("cannot add a table to a static array", pos)
        if isinstance(v, dict):
            if self._kind(v) == _INLINE:
                raise self._err("cannot add a table to an inline table", pos)
            return v
        raise self._err("cannot add a table to a key that holds a value", pos)

    def _header_table(self, table, key, pos):
        """Final step of [table]. An implicit table may be declared by its own header.

        # spec: N-000096 N-000097 N-000113 N-000114 N-000120 N-000118
        """
        if key in table:
            v = table[key]
            if isinstance(v, dict) and self._kind(v) == _IMPLICIT:
                self._mark(v, _HEADER)
                return v
            raise self._err("table %r is already defined" % key, pos)
        t = self._new_table(_HEADER)
        table[key] = t
        return t

    def _header_aot(self, table, key, pos):
        """Final step of [[array of tables]]: append a new mapping. # spec: N-000099 N-000100 N-000113 N-000119"""
        if key in table:
            v = table[key]
            if isinstance(v, list) and self._kind(v) == _AOT:
                t = self._new_table(_HEADER)
                v.append(t)
                return t
            raise self._err("key %r is already defined as a non-array-of-tables value" % key, pos)
        lst = []
        self._mark(lst, _AOT)
        t = self._new_table(_HEADER)
        lst.append(t)
        table[key] = lst
        return t

    # ----- keys ---------------------------------------------------------

    def _key(self):
        """A dotted key: a list of key parts. # spec: N-000085 N-000086 N-000087 N-000088 N-000089 N-000090 N-000091 N-000093 N-000094"""
        parts = [self._simple_key()]
        while True:
            save = self.i
            self._skip_ws()
            if self._peek() == ".":
                self.i += 1
                self._skip_ws()
                parts.append(self._simple_key())
            else:
                self.i = save
                break
        return parts

    def _simple_key(self):
        s, i = self.s, self.i
        c = self._peek()
        if c == '"':
            if s.startswith('"""', i):
                raise self._err("a multi-line string cannot be a key", i)
            return self._basic_string()
        if c == "'":
            if s.startswith("'''", i):
                raise self._err("a multi-line string cannot be a key", i)
            return self._literal_string()
        start = i
        while i < self.n and s[i] in _BARE_KEY_CHARS:
            i += 1
        if i == start:
            raise self._err("expected a key", start)
        self.i = i
        return s[start:i]

    # ----- key/value pairs and table assignment --------------------------

    def _keyval(self, table):
        """Parse ``key = value`` into ``table``. # spec: N-000083 N-000084 N-000113 N-000116 N-000122 N-000198 N-000202"""
        pos = self.i
        keys = self._key()
        self._skip_ws()
        if self._peek() != "=":
            raise self._err("expected '=' after key", self.i)
        self.i += 1
        self._skip_ws()
        value = self._value()
        self._assign(table, keys, value, pos)

    def _assign(self, table, keys, value, pos):
        """Store ``value`` at the dotted key ``keys`` inside ``table``.

        Dotted keys create implicit-looking nested tables marked DOTTED. They may
        extend a table created by dotted keys or implicitly by a header, but
        must not reopen a header-defined or inline table.
        # spec: N-000093 N-000094 N-000095 N-000113 N-000116 N-000117 N-000119 N-000121
        """
        for k in keys[:-1]:
            if k not in table:
                t = self._new_table(_DOTTED)
                table[k] = t
                table = t
                continue
            v = table[k]
            if isinstance(v, dict):
                kind = self._kind(v)
                if kind == _IMPLICIT:
                    self._mark(v, _DOTTED)
                elif kind != _DOTTED:
                    raise self._err("dotted key %r reopens a defined table" % k, pos)
                table = v
            else:
                raise self._err("dotted key %r extends a value" % k, pos)
        last = keys[-1]
        if last in table:
            raise self._err("duplicate key %r" % last, pos)
        table[last] = value

    # ----- values -------------------------------------------------------

    def _value(self):
        """# spec: N-000123 N-000124 N-000125 N-000126 N-000162 N-000163 N-000164 N-000165"""
        s, i = self.s, self.i
        if i >= self.n:
            raise self._err("expected a value", i)
        c = s[i]
        if c == '"':
            if s.startswith('"""', i):
                return self._ml_basic_string()
            return self._basic_string()
        if c == "'":
            if s.startswith("'''", i):
                return self._ml_literal_string()
            return self._literal_string()
        if c == "[":
            return self._array()
        if c == "{":
            return self._inline_table()
        if s.startswith("true", i):
            self.i += 4
            return True
        if s.startswith("false", i):
            self.i += 5
            return False
        if "0" <= c <= "9":
            # Date-times and local times must be tried before plain numbers.
            m = _DATETIME_RE.match(s, i)
            if m is not None:
                return self._datetime(m)
            lt = _LOCAL_TIME_RE.match(s, i)
            if lt is not None:
                return self._local_time(lt)
        if c in "+-0123456789in":
            return self._number()
        raise self._err("expected a value", i)

    def _datetime(self, m):
        """Date, date-time or offset date-time from a match of _DATETIME_RE.

        # spec: N-000151 N-000152 N-000153 N-000154 N-000155 N-000156 N-000157 N-000158 N-000159 N-000160 N-000161 N-000288 N-000289 N-000290 N-000179 N-000180
        """
        start = self.i
        self.i = m.end()
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        try:
            day = _dt.date(y, mo, d)
        except ValueError:
            raise self._err("invalid date", start)
        if m.group(4) is None:
            return day
        hh, mi = int(m.group(4)), int(m.group(5))
        ss = int(m.group(6)) if m.group(6) is not None else 0
        us = _micro(m.group(7))
        if hh > 23 or mi > 59 or ss > 59:
            raise self._err("invalid time", start)
        tz = None
        if m.group(8) is not None:
            tz = _dt.timezone.utc
        elif m.group(9) is not None:
            oh, om = int(m.group(10)), int(m.group(11))
            if oh > 23 or om > 59:
                raise self._err("invalid UTC offset", start)
            delta = _dt.timedelta(hours=oh, minutes=om)
            tz = _dt.timezone(delta if m.group(9) == "+" else -delta)
        return _dt.datetime(y, mo, d, hh, mi, ss, us, tzinfo=tz)

    def _local_time(self, m):
        """# spec: N-000151 N-000154 N-000155 N-000156 N-000157 N-000158 N-000291 N-000292 N-000179 N-000180"""
        start = self.i
        self.i = m.end()
        hh, mi = int(m.group(1)), int(m.group(2))
        ss = int(m.group(3)) if m.group(3) is not None else 0
        if hh > 23 or mi > 59 or ss > 59:
            raise self._err("invalid time", start)
        return _dt.time(hh, mi, ss, _micro(m.group(4)))

    def _number(self):
        """Integer or float. # spec: N-000144 N-000145 N-000146 N-000147 N-000148 N-000149 N-000150 N-000167 N-000168 N-000169 N-000170 N-000171 N-000172 N-000173 N-000221 N-000223 N-000224 N-000225 N-000226 N-000227 N-000228 N-000229 N-000230 N-000231 N-000232 N-000233 N-000274 N-000275 N-000276 N-000277 N-000283 N-000284 N-000285 N-000286 N-000287"""
        s, i = self.s, self.i
        c = s[i]
        m = _SPECIAL_FLOAT_RE.match(s, i)
        if m is not None:
            self.i = m.end()
            return self._make_float(m.group(0))
        if c == "0" and i + 1 < self.n and s[i + 1] in _RADIX_RES:
            rx, base = _RADIX_RES[s[i + 1]]
            m = rx.match(s, i)
            if m is None:
                raise self._err("invalid integer literal", i)
            self.i = m.end()
            return int(m.group(1).replace("_", ""), base)
        m = _DEC_RE.match(s, i)
        if m is None:
            raise self._err("expected a value", i)
        self.i = m.end()
        text = m.group(0)
        if m.group(3) is None and m.group(4) is None:
            return _decimal_int(text.replace("_", ""))
        return self._make_float(text)

    def _make_float(self, text):
        """Apply the float converter. # spec: N-000275 N-000276 N-000277 N-000221 N-000223 N-000226 N-000232 N-000233"""
        if self._float is float:
            return float(text.replace("_", ""))
        value = self._float(text)
        if isinstance(value, (dict, list)):
            # Not a TOMLDecodeError: the document is valid, the converter is not.
            raise ValueError(
                "parse_float returned a %s, which is not allowed" % type(value).__name__
            )
        return value

    def _array(self):
        """# spec: N-000105 N-000106 N-000282 N-000281 N-000280"""
        self.i += 1
        items = []
        while True:
            self._skip_blank()
            c = self._peek()
            if c == "":
                raise self._err("unterminated array", self.i)
            if c == "]":
                self.i += 1
                return items
            items.append(self._value())
            self._skip_blank()
            c = self._peek()
            if c == ",":
                self.i += 1
            elif c == "]":
                self.i += 1
                return items
            else:
                raise self._err("expected ',' or ']' in array", self.i)

    def _inline_table(self):
        """# spec: N-000103 N-000104 N-000116 N-000117 N-000118"""
        t = self._new_table(_INLINE)
        self.i += 1
        self._skip_blank()
        if self._peek() == "}":
            self.i += 1
            return t
        while True:
            self._keyval(t)
            self._skip_blank()
            c = self._peek()
            if c == ",":
                self.i += 1
                self._skip_blank()
                if self._peek() == "}":
                    self.i += 1
                    return t
            elif c == "}":
                self.i += 1
                return t
            else:
                raise self._err("expected ',' or '}' in inline table", self.i)
            if self._peek() == "":
                raise self._err("unterminated inline table", self.i)

    # ----- strings ------------------------------------------------------

    def _basic_string(self):
        """Single-line basic string (also a quoted key). # spec: N-000127 N-000128 N-000129 N-000130 N-000137 N-000138 N-000139 N-000140 N-000141 N-000142 N-000143 N-000174 N-000175 N-000176 N-000177 N-000178"""
        s, n = self.s, self.n
        i = self.i + 1
        out = []
        while True:
            if i >= n:
                raise self._err("unterminated string", n)
            c = s[i]
            if c == '"':
                self.i = i + 1
                return "".join(out)
            if c == "\\":
                i = self._escape(i + 1, out)
                continue
            if c in "\r\n" or _bad_char(c):
                raise self._err("invalid character in string", i)
            out.append(c)
            i += 1

    def _literal_string(self):
        """Single-line literal string (also a quoted key). No escapes. # spec: N-000127 N-000129 N-000141 N-000178"""
        s, n = self.s, self.n
        i = self.i + 1
        start = i
        while True:
            if i >= n:
                raise self._err("unterminated string", n)
            c = s[i]
            if c == "'":
                self.i = i + 1
                return s[start:i]
            if c in "\r\n" or _bad_char(c):
                raise self._err("invalid character in string", i)
            i += 1

    def _ml_basic_string(self):
        """Multi-line basic string. # spec: N-000127 N-000128 N-000131 N-000132 N-000133 N-000134 N-000135 N-000136 N-000137 N-000138 N-000139 N-000140 N-000141 N-000174 N-000175 N-000176 N-000177 N-000178"""
        s, n = self.s, self.n
        i = self.i + 3
        out = []
        if s.startswith("\r\n", i):
            i += 2
        elif s.startswith("\n", i):
            i += 1
        while True:
            if i >= n:
                raise self._err("unterminated multi-line string", n)
            c = s[i]
            if c == '"':
                k = self._run_length(i, '"')
                if k >= 3:
                    if k > 5:
                        raise self._err("too many quote characters before closing delimiter", i)
                    out.append('"' * (k - 3))
                    self.i = i + k
                    return "".join(out)
                out.append('"' * k)
                i += k
                continue
            if c == "\\":
                j = i + 1
                while j < n and s[j] in " \t":
                    j += 1
                if j < n and (s[j] == "\n" or s.startswith("\r\n", j)):
                    # Line-ending backslash: drop the line ending and all following whitespace.
                    i = j
                    while i < n:
                        if s[i] in " \t\n":
                            i += 1
                        elif s.startswith("\r\n", i):
                            i += 2
                        else:
                            break
                    continue
                i = self._escape(i + 1, out)
                continue
            if c == "\r":
                if s.startswith("\r\n", i):
                    out.append("\n")
                    i += 2
                    continue
                raise self._err("bare carriage return in string", i)
            if c == "\n":
                out.append("\n")
                i += 1
                continue
            if _bad_char(c):
                raise self._err("invalid character in string", i)
            out.append(c)
            i += 1

    def _ml_literal_string(self):
        """Multi-line literal string: no escapes; the first line ending is dropped. # spec: N-000127 N-000129 N-000130 N-000131 N-000132 N-000135 N-000136 N-000178"""
        s, n = self.s, self.n
        i = self.i + 3
        if s.startswith("\r\n", i):
            i += 2
        elif s.startswith("\n", i):
            i += 1
        start = i
        out = []
        while True:
            if i >= n:
                raise self._err("unterminated multi-line string", n)
            c = s[i]
            if c == "'":
                k = self._run_length(i, "'")
                if k >= 3:
                    if k > 5:
                        raise self._err("too many quote characters before closing delimiter", i)
                    # A carriage-return/line-feed pair is one line feed. # spec: N-000111 N-000112
                    out.append(s[start:i].replace("\r\n", "\n"))
                    out.append("'" * (k - 3))
                    self.i = i + k
                    return "".join(out)
                i += k
                continue
            if c == "\r":
                if s.startswith("\r\n", i):
                    i += 2
                    continue
                raise self._err("bare carriage return in string", i)
            if c != "\n" and _bad_char(c):
                raise self._err("invalid character in string", i)
            i += 1

    def _run_length(self, i, ch):
        k = 0
        s, n = self.s, self.n
        while i + k < n and s[i + k] == ch:
            k += 1
        return k

    def _escape(self, i, out):
        """Process the escape whose letter is at ``i`` (just after the backslash).

        Appends the character and returns the index after the escape.
        # spec: N-000137 N-000138 N-000139 N-000140 N-000141 N-000142 N-000143 N-000146 N-000174 N-000175 N-000176 N-000177
        """
        s, n = self.s, self.n
        if i >= n:
            raise self._err("unterminated escape sequence", i - 1)
        c = s[i]
        if c in _SIMPLE_ESCAPES:
            out.append(_SIMPLE_ESCAPES[c])
            return i + 1
        if c in _ESCAPE_WIDTHS:
            width = _ESCAPE_WIDTHS[c]
            digits = s[i + 1 : i + 1 + width]
            if len(digits) != width or any(d not in _HEX_DIGITS for d in digits):
                raise self._err("invalid escape sequence", i - 1)
            cp = int(digits, 16)
            if cp > 0x10FFFF or 0xD800 <= cp <= 0xDFFF:
                raise self._err("escape is not a Unicode scalar value", i - 1)
            out.append(chr(cp))
            return i + 1 + width
        raise self._err("invalid escape sequence", i - 1)


def parse(text, parse_float):
    """Parse a whole document. ``text`` must already be a str."""
    return _Parser(text, parse_float).parse()
