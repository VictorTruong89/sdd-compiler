"""The decode-error exception for Tomlparse."""


class TOMLDecodeError(ValueError):
    """A document is not valid TOML v1.1.0 (or a caller-built error report).

    Constructed as ``TOMLDecodeError(msg, doc, pos)``. ``msg`` is the unformatted
    reason, ``doc`` the document text, and ``pos`` a 0-based character offset
    into ``doc``. ``lineno`` and ``colno`` are 1-based and derived from ``pos``.
    """

    def __init__(self, msg, doc, pos):
        super().__init__(msg, doc, pos)
        self.msg = msg
        self.doc = doc
        self.pos = pos
        # 1 + number of line feeds before the offset.
        self.lineno = doc.count("\n", 0, pos) + 1
        # 1 + characters between the last line feed before the offset (or the
        # start of the document, which rfind reports as -1) and the offset.
        self.colno = pos - doc.rfind("\n", 0, pos)

    def __str__(self):
        location = "line %d, column %d (char %d)" % (self.lineno, self.colno, self.pos)
        if self.pos >= len(self.doc):
            return "%s: at end of document, %s" % (self.msg, location)
        return "%s: %s" % (self.msg, location)
