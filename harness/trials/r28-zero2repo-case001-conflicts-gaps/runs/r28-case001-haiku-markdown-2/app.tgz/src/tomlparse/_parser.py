"""A TOML v1.1.0 parser written from scratch (no delegation to any TOML library).

Structure of the implementation:

* The text is normalised once: every CR/LF pair becomes a single LF. A lone
  carriage return is invalid everywhere, so it is refused up front. Error
  offsets are mapped back to the caller's original text.
* Tables carry a "kind" recorded in a side table keyed by object identity:

  - ``root``      the document mapping;
  - ``header``    defined by a ``[table]`` header;
  - ``implicit``  created as a super-table by a header (may still be defined
                  later by its own header);
  - ``dotted``    created or defined by dotted keys (may not be defined by a
                  header afterwards);
  - ``inline``    an inline table (frozen once written);
  - ``aotitem``   an element of an array of tables.

  Arrays are registered with kind ``aot`` when they are arrays of tables;
  any other list is a static array and cannot be extended by headers or
  dotted keys.
"""

import datetime as _dt
import re

from ._errors import TOMLDecodeError

_WS_RE = re.compile(r"[ \t]*")
_WS_NL_RE = re.compile(r"[ \t\n]*")
_BARE_KEY_RE = re.compile(r"[A-Za-z0-9_-]+")
_CTRL_RE = re.compile(r"[\x00-\x08\x0a-\x1f\x7f]")

# Runs of ordinary characters inside each string form (stop at delimiters,
# backslashes and disallowed control characters).
_BASIC_CHUNK_RE = re.compile(r'[^"\\\x00-\x08\x0a-\x1f\x7f]*')
_ML_BASIC_CHUNK_RE = re.compile(r'[^"\\\x00-\x08\x0b-\x1f\x7f]*')
_LIT_CHUNK_RE = re.compile(r"[^'\x00-\x08\x0a-\x1f\x7f]*")
_ML_LIT_CHUNK_RE = re.compile(r"[^'\x00-\x08\x0b-\x1f\x7f]*")
# A backslash that ends a line (only blanks before the line feed) plus all
# following whitespace, including further line feeds.
_LINE_ENDING_ESC_RE = re.compile(r"\\[ \t]*\n[ \t\n]*")
_HEX_RE = {
    2: re.compile(r"[0-9A-Fa-f]{2}"),
    4: re.compile(r"[0-9A-Fa-f]{4}"),
    8: re.compile(r"[0-9A-Fa-f]{8}"),
}
_ESCAPES = {
    "b": "\b",
    "t": "\t",
    "n": "\n",
    "f": "\f",
    "r": "\r",
    "e": "\x1b",
    '"': '"',
    "\\": "\\",
}

# Date-times. Groups: 1-3 date; 4-7 time (hour, minute, second, fraction);
# 8 offset text, 9-10 offset hours and minutes. The separator may be T, t or
# a space, and the time part (with its digits) must follow it.
_DT_RE = re.compile(
    r"([0-9]{4})-([0-9]{2})-([0-9]{2})"
    r"(?:[Tt ]([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?"
    r"([Zz]|[+-]([0-9]{2}):([0-9]{2}))?)?"
)
# Local time. Groups: 1 hour, 2 minute, 3 second, 4 fraction.
_TIME_RE = re.compile(r"([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?")

# Numbers. Leading zeros are not allowed in the integer part of decimal
# integers and floats; exponents may carry leading zeros.
_SPECIAL_FLOAT_RE = re.compile(r"[+-]?(?:inf|nan)")
_HEX_INT_RE = re.compile(r"0x[0-9A-Fa-f](?:_?[0-9A-Fa-f])*")
_OCT_INT_RE = re.compile(r"0o[0-7](?:_?[0-7])*")
_BIN_INT_RE = re.compile(r"0b[01](?:_?[01])*")
_FLOAT_RE = re.compile(
    r"[+-]?(?:0|[1-9](?:_?[0-9])*)"
    r"(?:\.[0-9](?:_?[0-9])*(?:[eE][+-]?[0-9](?:_?[0-9])*)?"
    r"|[eE][+-]?[0-9](?:_?[0-9])*)"
)
_DEC_INT_RE = re.compile(r"[+-]?(?:0|[1-9](?:_?[0-9])*)")

_KIND_ROOT = "root"
_KIND_HEADER = "header"
_KIND_IMPLICIT = "implicit"
_KIND_DOTTED = "dotted"
_KIND_INLINE = "inline"
_KIND_AOT = "aot"
_KIND_AOT_ITEM = "aotitem"


class _Parser(object):
    def __init__(self, orig, conv):
        self.orig = orig
        self.conv = conv  # None means the builtin float
        self.kinds = {}  # id(obj) -> (obj, kind); holding obj keeps ids stable
        self.idx = None  # normalised index -> original index (only with CRLF)
        if "\r\n" in orig:
            n0 = len(orig)
            self.idx = [
                k
                for k in range(n0)
                if not (orig[k] == "\r" and k + 1 < n0 and orig[k + 1] == "\n")
            ]
            s = orig.replace("\r\n", "\n")
        else:
            s = orig
        self.s = s
        self.n = len(s)
        self.i = 0
        cr = s.find("\r")
        if cr >= 0:
            # Only lone carriage returns remain; they are never valid TOML.
            self._fail("carriage return is not allowed", cr)

    # ----------------------------------------------------------------- helpers

    def _pos(self, k):
        if self.idx is None:
            return k
        if k < len(self.idx):
            return self.idx[k]
        return len(self.orig)

    def _fail(self, msg, k=None):
        if k is None:
            k = self.i
        raise TOMLDecodeError(msg, self.orig, self._pos(k))

    def _register(self, obj, kind):
        self.kinds[id(obj)] = (obj, kind)

    def _set_kind(self, obj, kind):
        self.kinds[id(obj)] = (obj, kind)

    def _kind(self, obj):
        entry = self.kinds.get(id(obj))
        return entry[1] if entry is not None else None

    def _skip_ws(self):
        self.i = _WS_RE.match(self.s, self.i).end()

    def _skip_all(self):
        """Skip spaces, tabs, line feeds and comments."""
        s = self.s
        while True:
            self.i = _WS_NL_RE.match(s, self.i).end()
            if s[self.i : self.i + 1] == "#":
                self._comment()
            else:
                return

    def _comment(self):
        s = self.s
        end = s.find("\n", self.i)
        if end < 0:
            end = self.n
        bad = _CTRL_RE.search(s, self.i, end)
        if bad is not None:
            self._fail("control character is not allowed in a comment", bad.start())
        self.i = end

    def _end_of_line(self):
        self._skip_ws()
        if self.s[self.i : self.i + 1] == "#":
            self._comment()
        if self.i < self.n and self.s[self.i] != "\n":
            self._fail("expected end of line")

    # ------------------------------------------------------------- document

    def parse(self):
        root = {}
        self._register(root, _KIND_ROOT)
        self.root = root
        cur = root
        self._skip_all()
        s = self.s
        while self.i < self.n:
            if s[self.i] == "[":
                if s.startswith("[[", self.i):
                    cur = self._array_table_header()
                else:
                    cur = self._table_header()
            else:
                self._keyval(cur)
            self._end_of_line()
            self._skip_all()
        return root

    def _table_header(self):
        at = self.i
        self.i += 1  # '['
        self._skip_ws()
        keys = self._key()
        self._skip_ws()
        if self.s[self.i : self.i + 1] != "]":
            self._fail("expected ']' to close table header")
        self.i += 1
        return self._walk_table(keys, at)

    def _array_table_header(self):
        at = self.i
        self.i += 2  # '[['
        self._skip_ws()
        keys = self._key()
        self._skip_ws()
        if not self.s.startswith("]]", self.i):
            self._fail("expected ']]' to close array of tables header")
        self.i += 2
        return self._walk_array(keys, at)

    # ------------------------------------------------------- table walking

    def _step_header(self, node, k, at):
        """Descend one key as a header path component (creating implicit tables)."""
        if k not in node:
            table = {}
            self._register(table, _KIND_IMPLICIT)
            node[k] = table
            return table
        v = node[k]
        if isinstance(v, list):
            if self._kind(v) == _KIND_AOT:
                return v[-1]
            self._fail("cannot extend a static array with a table header", at)
        if isinstance(v, dict):
            if self._kind(v) == _KIND_INLINE:
                self._fail("cannot extend an inline table", at)
            return v
        self._fail("cannot define a table inside a non-table value", at)

    def _walk_table(self, keys, at):
        node = self.root
        for k in keys[:-1]:
            node = self._step_header(node, k, at)
        last = keys[-1]
        if last in node:
            v = node[last]
            if isinstance(v, dict) and self._kind(v) == _KIND_IMPLICIT:
                self._set_kind(v, _KIND_HEADER)
                return v
            self._fail("table is already defined", at)
        table = {}
        self._register(table, _KIND_HEADER)
        node[last] = table
        return table

    def _walk_array(self, keys, at):
        node = self.root
        for k in keys[:-1]:
            node = self._step_header(node, k, at)
        last = keys[-1]
        if last not in node:
            arr = []
            self._register(arr, _KIND_AOT)
            node[last] = arr
        else:
            arr = node[last]
            if not (isinstance(arr, list) and self._kind(arr) == _KIND_AOT):
                self._fail("cannot define an array of tables over an existing value", at)
        item = {}
        self._register(item, _KIND_AOT_ITEM)
        arr.append(item)
        return item

    def _step_dotted(self, node, k, at):
        """Descend one key of a dotted key path (creating dotted tables)."""
        if k not in node:
            table = {}
            self._register(table, _KIND_DOTTED)
            node[k] = table
            return table
        v = node[k]
        if isinstance(v, dict):
            kind = self._kind(v)
            if kind == _KIND_IMPLICIT:
                self._set_kind(v, _KIND_DOTTED)
                return v
            if kind == _KIND_DOTTED:
                return v
            self._fail("dotted key cannot extend a table defined by a header or inline table", at)
        if isinstance(v, list):
            self._fail("dotted key cannot extend an array", at)
        self._fail("dotted key cannot extend a value", at)

    # ------------------------------------------------------------- key/value

    def _keyval(self, table):
        at = self.i
        keys = self._key()
        self._skip_ws()
        if self.s[self.i : self.i + 1] != "=":
            self._fail("expected '=' after key")
        self.i += 1
        self._skip_ws()
        value = self._value()
        node = table
        for k in keys[:-1]:
            node = self._step_dotted(node, k, at)
        last = keys[-1]
        if last in node:
            self._fail("duplicate key", at)
        node[last] = value

    def _key(self):
        parts = [self._simple_key()]
        while True:
            self._skip_ws()
            if self.s[self.i : self.i + 1] == ".":
                self.i += 1
                self._skip_ws()
                parts.append(self._simple_key())
            else:
                return parts

    def _simple_key(self):
        s = self.s
        c = s[self.i : self.i + 1]
        if c == '"':
            return self._basic_string()
        if c == "'":
            return self._literal_string()
        m = _BARE_KEY_RE.match(s, self.i)
        if m is None:
            self._fail("expected a key")
        self.i = m.end()
        return m.group()

    # ---------------------------------------------------------------- values

    def _value(self):
        s = self.s
        i = self.i
        c = s[i : i + 1]
        if c == '"':
            if s.startswith('"""', i):
                return self._ml_basic_string()
            return self._basic_string()
        if c == "'":
            if s.startswith("'''", i):
                return self._ml_literal_string()
            return self._literal_string()
        if c == "[":
            return self._array()
        if c == "{":
            return self._inline_table()
        if s.startswith("true", i):
            self.i = i + 4
            return True
        if s.startswith("false", i):
            self.i = i + 5
            return False
        if c and (c in "+-0123456789in"):
            return self._number_or_datetime()
        self._fail("expected a value")

    def _number_or_datetime(self):
        s = self.s
        i = self.i
        m = _DT_RE.match(s, i)
        if m is not None:
            self.i = m.end()
            return self._make_datetime(m, i)
        m = _TIME_RE.match(s, i)
        if m is not None:
            self.i = m.end()
            return self._make_time(m, i)
        for rx, base in ((_HEX_INT_RE, 16), (_OCT_INT_RE, 8), (_BIN_INT_RE, 2)):
            m = rx.match(s, i)
            if m is not None:
                self.i = m.end()
                return int(m.group()[2:].replace("_", ""), base)
        m = _SPECIAL_FLOAT_RE.match(s, i)
        if m is not None:
            self.i = m.end()
            return self._float(m.group())
        m = _FLOAT_RE.match(s, i)
        if m is not None:
            self.i = m.end()
            return self._float(m.group())
        m = _DEC_INT_RE.match(s, i)
        if m is not None:
            self.i = m.end()
            return int(m.group().replace("_", ""))
        self._fail("expected a number, date or time")

    def _float(self, text):
        if self.conv is None:
            return float(text.replace("_", ""))
        value = self.conv(text)
        if isinstance(value, (dict, list)):
            raise ValueError(
                "parse_float must not return a dict or list (got %s)" % type(value).__name__
            )
        return value

    def _time_fields(self, hh, mi, ss, frac, at):
        hour = int(hh)
        minute = int(mi)
        sec = int(ss) if ss is not None else 0
        if hour > 23 or minute > 59 or sec > 59:
            self._fail("time value out of range", at)
        us = int((frac or "0")[:6].ljust(6, "0"))
        return hour, minute, sec, us

    def _make_datetime(self, m, at):
        y, mo, d, hh, mi, ss, frac, off, oh, om = m.groups()
        try:
            day = _dt.date(int(y), int(mo), int(d))
        except ValueError:
            self._fail("date value out of range", at)
        if hh is None:
            return day
        hour, minute, sec, us = self._time_fields(hh, mi, ss, frac, at)
        tz = None
        if off is not None:
            if off in ("Z", "z"):
                tz = _dt.timezone.utc
            else:
                oh_i = int(oh)
                om_i = int(om)
                if oh_i > 23 or om_i > 59:
                    self._fail("UTC offset out of range", at)
                delta = _dt.timedelta(hours=oh_i, minutes=om_i)
                if off[0] == "-":
                    delta = -delta
                tz = _dt.timezone(delta)
        return _dt.datetime(
            day.year, day.month, day.day, hour, minute, sec, us, tzinfo=tz
        )

    def _make_time(self, m, at):
        hh, mi, ss, frac = m.groups()
        hour, minute, sec, us = self._time_fields(hh, mi, ss, frac, at)
        return _dt.time(hour, minute, sec, us)

    def _array(self):
        s = self.s
        self.i += 1  # '['
        items = []
        self._skip_all()
        while True:
            if s[self.i : self.i + 1] == "]":
                self.i += 1
                return items
            items.append(self._value())
            self._skip_all()
            c = s[self.i : self.i + 1]
            if c == ",":
                self.i += 1
                self._skip_all()
            elif c == "]":
                self.i += 1
                return items
            else:
                self._fail("expected ',' or ']' in array")

    def _inline_table(self):
        s = self.s
        self.i += 1  # '{'
        table = {}
        self._skip_all()
        if s[self.i : self.i + 1] == "}":
            self.i += 1
            self._register(table, _KIND_INLINE)
            return table
        while True:
            self._keyval(table)
            self._skip_all()
            c = s[self.i : self.i + 1]
            if c == ",":
                self.i += 1
                self._skip_all()
                if s[self.i : self.i + 1] == "}":  # trailing comma (TOML v1.1.0)
                    self.i += 1
                    break
            elif c == "}":
                self.i += 1
                break
            else:
                self._fail("expected ',' or '}' in inline table")
        self._register(table, _KIND_INLINE)
        return table

    # --------------------------------------------------------------- strings

    def _escape(self, i):
        """Decode the escape starting at the backslash at index ``i``."""
        s = self.s
        c = s[i + 1 : i + 2]
        if c in _ESCAPES:
            return _ESCAPES[c], i + 2
        width = {"x": 2, "u": 4, "U": 8}.get(c)
        if width is None:
            self._fail("invalid escape sequence", i)
        m = _HEX_RE[width].match(s, i + 2)
        if m is None:
            self._fail("invalid hexadecimal escape", i)
        cp = int(m.group(), 16)
        if 0xD800 <= cp <= 0xDFFF or cp > 0x10FFFF:
            self._fail("escape is not a Unicode scalar value", i)
        return chr(cp), m.end()

    def _basic_string(self):
        s = self.s
        start = self.i
        i = start + 1
        parts = []
        while True:
            m = _BASIC_CHUNK_RE.match(s, i)
            parts.append(m.group())
            i = m.end()
            if i >= self.n:
                self._fail("unterminated string", start)
            c = s[i]
            if c == '"':
                self.i = i + 1
                return "".join(parts)
            if c == "\\":
                ch, i = self._escape(i)
                parts.append(ch)
                continue
            self._fail("control character is not allowed in a string", i)

    def _literal_string(self):
        s = self.s
        start = self.i
        i = start + 1
        m = _LIT_CHUNK_RE.match(s, i)
        i = m.end()
        if i >= self.n:
            self._fail("unterminated string", start)
        if s[i] == "'":
            self.i = i + 1
            return m.group()
        self._fail("control character is not allowed in a string", i)

    def _quote_run(self, i, q):
        """Length of the run of quote character ``q`` starting at ``i``."""
        j = i
        while j < self.n and self.s[j] == q:
            j += 1
        return j - i

    def _ml_basic_string(self):
        s = self.s
        start = self.i
        i = start + 3
        if s.startswith("\n", i):
            i += 1
        parts = []
        while True:
            m = _ML_BASIC_CHUNK_RE.match(s, i)
            parts.append(m.group())
            i = m.end()
            if i >= self.n:
                self._fail("unterminated multiline string", start)
            c = s[i]
            if c == '"':
                k = self._quote_run(i, '"')
                if k < 3:
                    parts.append('"' * k)
                    i += k
                    continue
                if k > 5:
                    self._fail("too many quotation marks before closing delimiter", i)
                parts.append('"' * (k - 3))
                self.i = i + k
                return "".join(parts)
            if c == "\\":
                m2 = _LINE_ENDING_ESC_RE.match(s, i)
                if m2 is not None:
                    i = m2.end()
                    continue
                ch, i = self._escape(i)
                parts.append(ch)
                continue
            self._fail("control character is not allowed in a string", i)

    def _ml_literal_string(self):
        s = self.s
        start = self.i
        i = start + 3
        if s.startswith("\n", i):
            i += 1
        parts = []
        while True:
            m = _ML_LIT_CHUNK_RE.match(s, i)
            parts.append(m.group())
            i = m.end()
            if i >= self.n:
                self._fail("unterminated multiline string", start)
            c = s[i]
            if c == "'":
                k = self._quote_run(i, "'")
                if k < 3:
                    parts.append("'" * k)
                    i += k
                    continue
                if k > 5:
                    self._fail("too many apostrophes before closing delimiter", i)
                parts.append("'" * (k - 3))
                self.i = i + k
                return "".join(parts)
            self._fail("control character is not allowed in a string", i)


def parse(text, conv):
    """Parse ``text`` (a str) and return the document mapping.

    ``conv`` is the float converter, or None for the builtin float.
    Raises TOMLDecodeError for invalid TOML and ValueError for an illegal
    converter result.
    """
    parser = _Parser(text, conv)
    try:
        return parser.parse()
    except RecursionError:
        parser._fail("document is nested too deeply")
