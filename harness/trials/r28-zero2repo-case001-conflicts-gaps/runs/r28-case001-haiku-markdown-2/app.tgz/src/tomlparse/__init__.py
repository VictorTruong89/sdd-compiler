"""Tomlparse: a pure-Python parser for TOML v1.1.0 documents.

Public entries: ``loads`` (text string), ``load`` (binary file object) and the
decode error ``TOMLDecodeError``.
"""

import io as _io

from ._errors import TOMLDecodeError
from ._parser import parse as _parse

__version__ = "2.4.0"
__all__ = ["loads", "load", "TOMLDecodeError"]


def _float_converter(parse_float):
    # The builtin float is the default: no converter is needed for it.
    return None if parse_float is float else parse_float


def loads(s, *, parse_float=float):
    """Parse the TOML document ``s`` (a str) and return its document mapping.

    ``parse_float`` is called with the characters of each TOML float and its
    return value is stored instead of the float. A ``dict`` or ``list`` result
    raises ValueError.
    """
    if not isinstance(s, str):
        raise TypeError("loads() expects a str, not %s" % type(s).__name__)
    return _parse(s, _float_converter(parse_float))


def load(fp, *, parse_float=float):
    """Read a binary file object, decode it as UTF-8 and parse it as TOML.

    Text-mode file objects are refused with TypeError.
    """
    if isinstance(fp, _io.TextIOBase) or not hasattr(fp, "read"):
        raise TypeError("load() expects a file object opened for binary reading")
    data = fp.read()
    if isinstance(data, str):
        raise TypeError("load() expects a file object opened for binary reading")
    if not isinstance(data, (bytes, bytearray, memoryview)):
        raise TypeError("load() expects a file object opened for binary reading")
    data = bytes(data)
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        # The document text is the decoded text; the error sits at the first
        # byte that is not valid UTF-8 (the valid prefix decodes unchanged).
        doc = data.decode("utf-8", errors="replace")
        pos = len(data[: exc.start].decode("utf-8"))
        raise TOMLDecodeError("invalid UTF-8 in document", doc, pos)
    return _parse(text, _float_converter(parse_float))
