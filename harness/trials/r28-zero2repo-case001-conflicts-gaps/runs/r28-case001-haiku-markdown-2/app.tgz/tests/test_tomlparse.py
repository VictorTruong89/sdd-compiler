"""Behavioural tests for Tomlparse (run: PYTHONPATH=src python -m unittest discover -s tests)."""

import datetime as dt
import io
import unittest

from tomlparse import TOMLDecodeError, load, loads


class ValidDocuments(unittest.TestCase):
    def test_empty_and_comment_only(self):
        self.assertEqual(loads(""), {})
        self.assertEqual(loads("   \t  "), {})
        self.assertEqual(loads("# c1\n  # c2"), {})
        self.assertEqual(loads("# c1\n"), {})

    def test_root_pairs_and_tables(self):
        doc = loads('a = 1\n[t]\nb = "x" # trailing comment\n[t.u]\nc = true\n')
        self.assertEqual(doc, {"a": 1, "t": {"b": "x", "u": {"c": True}}})

    def test_keys_are_always_strings(self):
        doc = loads('1 = 1\ntrue = 2\ninf = 3\nnan = 4\n"" = 5\n"a.b" = 6\n\'x\' = 7\n')
        self.assertEqual(doc, {"1": 1, "true": 2, "inf": 3, "nan": 4, "": 5, "a.b": 6, "x": 7})

    def test_key_case_is_significant(self):
        self.assertEqual(loads("A = 1\na = 2"), {"A": 1, "a": 2})

    def test_dotted_keys_with_whitespace(self):
        self.assertEqual(loads('a . b . "c d" = 1'), {"a": {"b": {"c d": 1}}})

    def test_basic_vs_literal_quoted_key_escapes(self):
        self.assertEqual(loads('"\\u0041" = 1\n\'\\u0041\' = 2'), {"A": 1, "\\u0041": 2})

    def test_implicit_super_table_declared_later(self):
        self.assertEqual(loads("[a.b.c]\nx = 1\n[a]\ny = 2\n[a.b]\nz = 3"),
                         {"a": {"b": {"c": {"x": 1}, "z": 3}, "y": 2}})

    def test_dotted_table_receives_sub_table_header(self):
        doc = loads('[fruit]\napple.color = "red"\napple.taste.sweet = true\n'
                    "[fruit.apple.texture]\nsmooth = true\n")
        self.assertEqual(doc, {"fruit": {"apple": {"color": "red", "taste": {"sweet": True},
                                                   "texture": {"smooth": True}}}})

    def test_array_of_tables_nesting(self):
        doc = loads('[[fruit]]\nname = "apple"\n[fruit.physical]\ncolor = "red"\n'
                    '[[fruit.variety]]\nname = "red delicious"\n'
                    '[[fruit]]\nname = "banana"\n[[fruit.variety]]\nname = "plantain"\n')
        self.assertEqual(doc, {"fruit": [
            {"name": "apple", "physical": {"color": "red"},
             "variety": [{"name": "red delicious"}]},
            {"name": "banana", "variety": [{"name": "plantain"}]},
        ]})

    def test_array_of_tables_implies_plain_parent(self):
        doc = loads("[[x.y]]\na = 1\n[x]\nb = 2\n")
        self.assertEqual(doc, {"x": {"y": [{"a": 1}], "b": 2}})

    def test_inline_tables(self):
        doc = loads("t = {}\nu = { a = 1, b.c = 2 }\nv = {\n  k = 1, # note\n  j = [\n 2,\n ],\n}\n")
        self.assertEqual(doc, {"t": {}, "u": {"a": 1, "b": {"c": 2}},
                               "v": {"k": 1, "j": [2]}})

    def test_arrays(self):
        doc = loads("a = []\nb = [1, 'two', [3.0], {x = 4}, ]\nc = [\n  1, # one\n  2,\n]\n")
        self.assertEqual(doc, {"a": [], "b": [1, "two", [3.0], {"x": 4}], "c": [1, 2]})

    def test_indentation_insignificant(self):
        self.assertEqual(loads("\t[t]\n\t\tk = 1\n"), {"t": {"k": 1}})

    def test_crlf_is_single_line_feed(self):
        doc = loads('a = """x\r\ny"""\r\nb = 1\r\n')
        self.assertEqual(doc, {"a": "x\ny", "b": 1})

    def test_non_ascii_comment_and_key_in_quotes(self):
        self.assertEqual(loads('# héllo ✓\n"κλειδί" = "τιμή"'), {"κλειδί": "τιμή"})


class ScalarValues(unittest.TestCase):
    def test_booleans(self):
        self.assertIs(loads("a = true")["a"], True)
        self.assertIs(loads("a = false")["a"], False)

    def test_basic_string_escapes(self):
        self.assertEqual(loads(r'a = "\b\t\n\f\r\e\"\\"')["a"], "\b\t\n\f\r\x1b\"\\")
        self.assertEqual(loads(r'a = "\x41\u00e9\U0001F600\u00E9"')["a"], "Aé😀é")

    def test_literal_strings_take_backslashes(self):
        self.assertEqual(loads(r"a = 'C:\path\n'")["a"], "C:\\path\\n")

    def test_multiline_basic_first_newline_and_line_ending_backslash(self):
        doc = loads('a = """\nLine one\n  line two \\\n\n     \tjoined\n"""')
        self.assertEqual(doc["a"], "Line one\n  line two joined\n")

    def test_multiline_literal_keeps_first_newline_when_not_immediate(self):
        self.assertEqual(loads("a = '''\n\nx\\n'''")["a"], "\nx\\n")
        self.assertEqual(loads("a = '''  \nx'''")["a"], "  \nx")

    def test_multiline_quotes_before_closing_delimiter(self):
        self.assertEqual(loads('a = """x""""')["a"], 'x"')
        self.assertEqual(loads('a = """x"""""')["a"], 'x""')
        self.assertEqual(loads('a = """"quoted" x"""')["a"], '"quoted" x')
        self.assertEqual(loads("a = ''''x''''")["a"], "'x'")

    def test_integers(self):
        doc = loads("a = 0\nb = +99\nc = -17\nd = 1_000\ne = 0xDEADbeef\nf = 0o0755\ng = 0b11010110\nh = -0\ni = +0")
        self.assertEqual(doc, {"a": 0, "b": 99, "c": -17, "d": 1000, "e": 0xDEADBEEF,
                               "f": 0o755, "g": 0b11010110, "h": 0, "i": 0})
        self.assertIs(type(doc["a"]), int)

    def test_floats(self):
        doc = loads("a = 3.14\nb = -0.01\nc = 5e+22\nd = 1e06\ne = -2E-2\nf = 6.626e-34\ng = 224_617.445_991_228")
        self.assertEqual(doc["a"], 3.14)
        self.assertEqual(doc["c"], 5e22)
        self.assertEqual(doc["d"], 1e6)
        self.assertEqual(doc["g"], 224617.445991228)

    def test_special_floats(self):
        doc = loads("a = inf\nb = +inf\nc = -inf\nd = nan\ne = +nan\nf = -nan")
        self.assertEqual(doc["a"], float("inf"))
        self.assertEqual(doc["c"], float("-inf"))
        self.assertTrue(doc["d"] != doc["d"])
        self.assertTrue(doc["f"] != doc["f"])
        self.assertIs(type(doc["d"]), float)

    def test_datetimes(self):
        doc = loads(
            "odt1 = 1979-05-27T07:32:00Z\n"
            "odt2 = 1979-05-27 07:32:00.999999-07:00\n"
            "odt3 = 1979-05-27t07:32:00.1234567+01:30\n"
            "odt4 = 1979-05-27T07:32Z\n"
            "ldt1 = 1979-05-27T07:32:00\n"
            "ldt2 = 1979-05-27 07:32\n"
            "ld = 1979-02-28\n"
            "leap = 2024-02-29\n"
            "lt = 07:32:00.5\n"
            "lt2 = 23:59\n"
        )
        self.assertEqual(doc["odt1"], dt.datetime(1979, 5, 27, 7, 32, tzinfo=dt.timezone.utc))
        self.assertEqual(doc["odt1"].utcoffset(), dt.timedelta(0))
        self.assertEqual(doc["odt2"].utcoffset(), dt.timedelta(hours=-7))
        self.assertEqual(doc["odt2"].microsecond, 999999)
        self.assertEqual(doc["odt3"].microsecond, 123456)  # truncated, not rounded
        self.assertEqual(doc["odt3"].utcoffset(), dt.timedelta(hours=1, minutes=30))
        self.assertEqual(doc["odt4"].second, 0)
        self.assertIsNone(doc["ldt1"].tzinfo)
        self.assertIsNone(doc["ldt2"].tzinfo)
        self.assertEqual(doc["ld"], dt.date(1979, 2, 28))
        self.assertEqual(doc["leap"], dt.date(2024, 2, 29))
        self.assertEqual(doc["lt"], dt.time(7, 32, 0, 500000))
        self.assertIsNone(doc["lt"].tzinfo)
        self.assertEqual(doc["lt2"], dt.time(23, 59))

    def test_datetime_space_separator_not_before_comment(self):
        self.assertEqual(loads("d = 1979-05-27 # c"), {"d": dt.date(1979, 5, 27)})


class FloatConverter(unittest.TestCase):
    def test_converter_receives_exact_text(self):
        seen = []

        def conv(text):
            seen.append(text)
            return "F(" + text + ")"

        doc = loads("a = 1_0.5e+1\nb = [-inf, nan]\nc = {x = 2.0}\nd = 3\ne = 's'", parse_float=conv)
        self.assertEqual(doc, {"a": "F(1_0.5e+1)", "b": ["F(-inf)", "F(nan)"],
                               "c": {"x": "F(2.0)"}, "d": 3, "e": "s"})
        self.assertEqual(seen, ["1_0.5e+1", "-inf", "nan", "2.0"])

    def test_converter_result_dict_or_list_refused(self):
        class MyList(list):
            pass

        for bad in ({}, [], MyList(), type("D", (dict,), {})()):
            with self.assertRaises(ValueError) as cm:
                loads("a = 1.5", parse_float=lambda _t, b=bad: b)
            self.assertNotIsInstance(cm.exception, TOMLDecodeError)

    def test_converter_applies_to_binary_entry(self):
        doc = load(io.BytesIO(b"x = 2.5"), parse_float=lambda t: t.upper())
        self.assertEqual(doc, {"x": "2.5"})


class BinaryEntry(unittest.TestCase):
    def test_bytes_buffer(self):
        self.assertEqual(load(io.BytesIO(b'a = "\xc3\xa9"\n')), {"a": "é"})
        self.assertEqual(load(io.BytesIO(b"")), {})

    def test_text_mode_refused(self):
        with self.assertRaises(TypeError) as cm:
            load(io.StringIO('a = 1'))
        self.assertNotIsInstance(cm.exception, TOMLDecodeError)

    def test_invalid_toml_in_file_is_decode_error(self):
        with self.assertRaises(TOMLDecodeError) as cm:
            load(io.BytesIO(b"a = 1\nb = \n"))
        self.assertEqual(cm.exception.doc, "a = 1\nb = \n")
        self.assertEqual(cm.exception.lineno, 2)

    def test_invalid_utf8_is_decode_error(self):
        with self.assertRaises(TOMLDecodeError) as cm:
            load(io.BytesIO(b'a = "x"\nb = "\xff"'))
        self.assertIsInstance(cm.exception.doc, str)
        self.assertEqual(cm.exception.pos, 13)
        self.assertEqual(cm.exception.lineno, 2)

    def test_matches_string_entry(self):
        text = '[t]\nk = [1, 2]\n'
        self.assertEqual(load(io.BytesIO(text.encode("utf-8"))), loads(text))


class Refusals(unittest.TestCase):
    def assertInvalid(self, text):
        with self.assertRaises(TOMLDecodeError, msg=repr(text)):
            loads(text)

    def test_wrong_python_type_is_type_error(self):
        for bad in (b"a = 1", 1, True, io.StringIO("a=1"), None):
            with self.assertRaises(TypeError) as cm:
                loads(bad)
            self.assertNotIsInstance(cm.exception, TOMLDecodeError)

    def test_duplicate_keys_and_tables(self):
        self.assertInvalid("a = 1\na = 2")
        self.assertInvalid("[t]\n[t]")
        self.assertInvalid("[t.u]\n[t]\n[t.u]")
        self.assertInvalid("a = {x = 1, x = 2}")
        self.assertInvalid("a = { b = 1 }\n[a]")

    def test_reopen_table_defined_by_dotted_keys(self):
        self.assertInvalid("[fruit]\napple.color = 'red'\n[fruit.apple]")
        self.assertInvalid("a.b.c = 1\n[a]\nb.d = 2\n[a.b]")

    def test_dotted_keys_into_table_defined_by_header(self):
        self.assertInvalid("[a.b]\nx = 1\n[a]\nb.c = 2")
        self.assertInvalid("[a.b.c]\nz = 9\n[a]\nb.c.t = 1")

    def test_replacing_value_with_table_or_array(self):
        self.assertInvalid("a = 1\n[a]")
        self.assertInvalid("a = 1\n[[a]]")
        self.assertInvalid("a = []\n[[a]]")
        self.assertInvalid("[[a]]\n[a]")
        self.assertInvalid("[a.b.c]\n[[a]]")

    def test_adding_to_inline_table(self):
        self.assertInvalid("a = {}\n[a.b]")
        self.assertInvalid("a = {b = 1}\na.c = 2")
        self.assertInvalid("a = {b = {}}\n[a.b.c]")

    def test_extending_array_of_tables_through_dotted_key(self):
        self.assertInvalid("a = [{}]\n[a.b]")
        self.assertInvalid("a = [1]\na.b = 2")

    def test_structural_syntax(self):
        self.assertInvalid("= 1")
        self.assertInvalid("a =")
        self.assertInvalid("a")
        self.assertInvalid('"""a""" = 1')
        self.assertInvalid("[t\n")
        self.assertInvalid("[t] x = 1")
        self.assertInvalid("[[t]] x = 1")
        self.assertInvalid("a = 1 b = 2")
        self.assertInvalid("a = [1 2]")
        self.assertInvalid("a = [,]")
        self.assertInvalid("a = {,}")
        self.assertInvalid("a = {b = 1,,}")

    def test_scalar_violations(self):
        self.assertInvalid("a = True")
        self.assertInvalid("a = tru")
        self.assertInvalid("a = 01")
        self.assertInvalid("a = 00")
        self.assertInvalid("a = 01.5")
        self.assertInvalid("a = 0x_1")
        self.assertInvalid("a = 0X1")
        self.assertInvalid("a = 0xG")
        self.assertInvalid("a = +0x1")
        self.assertInvalid("a = -0o7")
        self.assertInvalid("a = 1__0")
        self.assertInvalid("a = 1_")
        self.assertInvalid("a = _1")
        self.assertInvalid("a = .5")
        self.assertInvalid("a = 5.")
        self.assertInvalid("a = 1.e5")
        self.assertInvalid("a = infinity")
        self.assertInvalid("a = 1e_5")
        self.assertInvalid("a = 1979-02-29")
        self.assertInvalid("a = 1979-13-01")
        self.assertInvalid("a = 07:60")
        self.assertInvalid("a = 24:00")
        self.assertInvalid("a = 1979-05-27T07:32:60Z")
        self.assertInvalid("a = 1979-05-27T07:32:00+24:00")

    def test_escapes_and_control_characters(self):
        self.assertInvalid(r'a = "\q"')
        self.assertInvalid(r'a = "\x4"')
        self.assertInvalid(r'a = "\xGG"')
        self.assertInvalid(r'a = "\u12"')
        self.assertInvalid(r'a = "\uD800"')
        self.assertInvalid(r'a = "\UDFFF0000"')
        self.assertInvalid(r'a = "\U00110000"')
        self.assertInvalid('a = "tab\x01"')
        self.assertInvalid('a = "x\x7f"')
        self.assertInvalid('a = "line\nbreak"')
        self.assertInvalid("a = 'x\ny'")
        self.assertInvalid('a = "unterminated')
        self.assertInvalid("a = '''unterminated")
        self.assertInvalid('a = """x\ry"""')
        self.assertInvalid('a = """x\\ y"""')
        self.assertInvalid('a = """x\\ """')
        self.assertInvalid("# bad \x01 comment\na = 1")
        self.assertInvalid("a = 1 # bad \r comment")

    def test_quotes_run_beyond_delimiter(self):
        self.assertInvalid('a = """x"""""" ')

    def test_bare_key_chars(self):
        self.assertInvalid("a.b c = 1")
        self.assertInvalid("é = 1")

    def test_header_must_stand_alone(self):
        self.assertInvalid("[a] b = 1")


class ErrorReporting(unittest.TestCase):
    def test_location_fields(self):
        err = TOMLDecodeError("boom", "ab\ncd\nef", 4)
        self.assertEqual(err.msg, "boom")
        self.assertEqual(err.doc, "ab\ncd\nef")
        self.assertEqual(err.pos, 4)
        self.assertEqual(err.lineno, 2)
        self.assertEqual(err.colno, 2)
        self.assertIsInstance(err, ValueError)
        self.assertNotIsInstance(err, TypeError)
        self.assertNotIsInstance(err, RecursionError)
        self.assertIn("2", str(err))

    def test_first_line_column(self):
        err = TOMLDecodeError("boom", "abc", 1)
        self.assertEqual((err.lineno, err.colno), (1, 2))

    def test_end_of_document(self):
        err = TOMLDecodeError("boom", "ab", 2)
        self.assertEqual((err.lineno, err.colno), (1, 3))
        self.assertIn("end of document", str(err))

    def test_parse_failure_position(self):
        with self.assertRaises(TOMLDecodeError) as cm:
            loads("a = 1\nb = 2\nc = @")
        self.assertEqual(cm.exception.doc, "a = 1\nb = 2\nc = @")
        self.assertEqual(cm.exception.pos, 16)
        self.assertEqual((cm.exception.lineno, cm.exception.colno), (3, 5))

    def test_crlf_offsets_refer_to_original_text(self):
        with self.assertRaises(TOMLDecodeError) as cm:
            loads("a = 1\r\nb = @")
        self.assertEqual(cm.exception.pos, 11)
        self.assertEqual((cm.exception.lineno, cm.exception.colno), (2, 5))

    def test_unclosed_string_reports_opening_quote(self):
        with self.assertRaises(TOMLDecodeError) as cm:
            loads('a = "abc')
        self.assertEqual(cm.exception.pos, 4)
        self.assertEqual((cm.exception.lineno, cm.exception.colno), (1, 5))

    def test_pickle_roundtrip(self):
        import pickle

        err = TOMLDecodeError("boom", "x = 1\ny", 6)
        copy = pickle.loads(pickle.dumps(err))
        self.assertEqual((copy.msg, copy.doc, copy.pos, copy.lineno, copy.colno),
                         ("boom", "x = 1\ny", 6, 2, 1))


if __name__ == "__main__":
    unittest.main()
