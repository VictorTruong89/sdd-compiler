"""Tomlparse: a TOML v1.1.0 parser."""
from ._parser import loads, load, TOMLDecodeError

__all__ = ["loads", "load", "TOMLDecodeError"]
