# spec: N-000266 N-000270 N-000271 N-000272 (pure-Python TOML v1.1.0 parser)
import re
from datetime import date, datetime, time, timedelta, timezone


class TOMLDecodeError(ValueError):
    """Raised when a document is not valid TOML. spec: N-000307..N-000323"""

    def __init__(self, msg, doc, pos):
        self.msg = msg
        self.doc = doc
        self.pos = pos
        self.lineno = doc.count("\n", 0, pos) + 1
        last = doc.rfind("\n", 0, pos)
        self.colno = pos - last  # last == -1 -> pos + 1
        if pos >= len(doc):
            where = "at end of document"
        else:
            where = "at line %d, column %d" % (self.lineno, self.colno)
        self.formatted = "%s (%s)" % (msg, where)
        ValueError.__init__(self, self.formatted)

    def __str__(self):
        return self.formatted


_BARE = re.compile(r"[A-Za-z0-9_-]+")
_DT = re.compile(
    r"(\d{4})-(\d{2})-(\d{2})"
    r"(?:[Tt ](\d{2}):(\d{2})(?::(\d{2})(?:\.(\d+))?)?"
    r"(?:([Zz])|([+-])(\d{2}):(\d{2}))?)?"
)
_TIME = re.compile(r"(\d{2}):(\d{2})(?::(\d{2})(?:\.(\d+))?)?")
_DEC = r"(?:0|[1-9](?:_?[0-9])*)"
_FLOAT = re.compile(
    r"[+-]?" + _DEC + r"(?:\.[0-9](?:_?[0-9])*(?:[eE][+-]?[0-9](?:_?[0-9])*)?"
    r"|[eE][+-]?[0-9](?:_?[0-9])*)"
)
_INT = re.compile(
    r"(?:[+-]?" + _DEC + r"|0x[0-9A-Fa-f](?:_?[0-9A-Fa-f])*"
    r"|0o[0-7](?:_?[0-7])*|0b[01](?:_?[01])*)"
)
_SPECIAL = {"inf", "+inf", "-inf", "nan", "+nan", "-nan"}
_TOKEN_END = " \t\r\n#,]}[={"
_ESC = {"b": "\b", "t": "\t", "n": "\n", "f": "\f", "r": "\r", "e": "\x1b",
        '"': '"', "\\": "\\"}
_HEX = "0123456789abcdefABCDEF"


class _Err(Exception):
    def __init__(self, msg, pos):
        self.msg = msg
        self.pos = pos


# table kinds
_H, _I, _D, _L = "header", "implicit", "dotted", "frozen"


class _Parser:
    def __init__(self, s, parse_float):
        self.s = s
        self.n = len(s)
        self.pf = parse_float
        self.kinds = {}
        self.aots = set()
        self.keep = []

    def new(self, kind):
        d = {}
        self.kinds[id(d)] = kind
        self.keep.append(d)
        return d

    # ---- whitespace ----
    def ws(self, p):
        s = self.s
        while p < self.n and s[p] in " \t":
            p += 1
        return p

    def comment(self, p):
        # p at '#'
        s = self.s
        p += 1
        while p < self.n:
            c = s[p]
            if c == "\n":
                break
            if c == "\r":
                if s.startswith("\r\n", p):
                    break
                raise _Err("Illegal character in comment", p)
            if (c < " " and c != "\t") or c == "\x7f":
                raise _Err("Illegal character in comment", p)
            p += 1
        return p

    def nl(self, p):
        """Return position after a newline at p, or -1."""
        if self.s.startswith("\n", p):
            return p + 1
        if self.s.startswith("\r\n", p):
            return p + 2
        return -1

    def skip_all(self, p):
        """skip whitespace, newlines and comments"""
        while True:
            p = self.ws(p)
            if p < self.n and self.s[p] == "#":
                p = self.comment(p)
                continue
            q = self.nl(p)
            if q >= 0:
                p = q
                continue
            return p

    # ---- top level ----
    def parse(self):
        root = self.new(_H)
        cur = root
        p = 0
        s = self.s
        while True:
            p = self.skip_all(p)
            if p >= self.n:
                break
            if s[p] == "[":
                cur, p = self.header(p, root)
            else:
                p = self.keyval(p, cur)
            p = self.ws(p)
            if p < self.n and s[p] == "#":
                p = self.comment(p)
            if p < self.n:
                q = self.nl(p)
                if q < 0:
                    raise _Err("Expected newline or end of document", p)
                p = q
        return root

    def header(self, p, root):
        s = self.s
        aot = s.startswith("[[", p)
        start = p
        p += 2 if aot else 1
        p = self.ws(p)
        parts, p = self.key(p)
        p = self.ws(p)
        close = "]]" if aot else "]"
        if not s.startswith(close, p):
            raise _Err("Expected '%s' at end of table header" % close, p)
        p += len(close)
        cur = root
        for part in parts[:-1]:
            if part not in cur:
                nt = self.new(_I)
                cur[part] = nt
                cur = nt
                continue
            v = cur[part]
            if isinstance(v, list):
                if id(v) not in self.aots:
                    raise _Err("Cannot extend a static array", start)
                v = v[-1]
            if not isinstance(v, dict) or self.kinds.get(id(v)) == _L:
                raise _Err("Cannot declare table: key already defined", start)
            cur = v
        last = parts[-1]
        if aot:
            if last not in cur:
                lst = []
                self.aots.add(id(lst))
                self.keep.append(lst)
                cur[last] = lst
            else:
                lst = cur[last]
                if not isinstance(lst, list) or id(lst) not in self.aots:
                    raise _Err("Cannot define array of tables: key already defined", start)
            nt = self.new(_H)
            lst.append(nt)
            return nt, p
        if last not in cur:
            nt = self.new(_H)
            cur[last] = nt
            return nt, p
        v = cur[last]
        if isinstance(v, dict) and self.kinds.get(id(v)) == _I:
            self.kinds[id(v)] = _H
            return v, p
        raise _Err("Cannot declare table: already defined", start)

    def keyval(self, p, table):
        start = p
        parts, p = self.key(p)
        p = self.ws(p)
        if p >= self.n or self.s[p] != "=":
            raise _Err("Expected '=' after key", p)
        p = self.ws(p + 1)
        if p >= self.n or self.s[p] in "\r\n#":
            raise _Err("Expected a value after '='", p)
        value, p = self.value(p)
        self.assign(table, parts, value, start)
        return p

    def assign(self, table, parts, value, pos):
        cur = table
        for part in parts[:-1]:
            if part not in cur:
                nt = self.new(_D)
                cur[part] = nt
                cur = nt
                continue
            v = cur[part]
            if not isinstance(v, dict) or self.kinds.get(id(v)) != _D:
                raise _Err("Cannot extend existing key with dotted key", pos)
            cur = v
        if parts[-1] in cur:
            raise _Err("Duplicate key", pos)
        cur[parts[-1]] = value

    # ---- keys ----
    def key(self, p):
        parts = []
        while True:
            p = self.ws(p)
            if p >= self.n:
                raise _Err("Expected key", p)
            c = self.s[p]
            if c == '"':
                if self.s.startswith('"""', p):
                    raise _Err("Multiline string cannot be a key", p)
                k, p = self.basic(p)
            elif c == "'":
                if self.s.startswith("'''", p):
                    raise _Err("Multiline string cannot be a key", p)
                k, p = self.literal(p)
            else:
                m = _BARE.match(self.s, p)
                if not m:
                    raise _Err("Invalid key", p)
                k = m.group()
                p = m.end()
            parts.append(k)
            q = self.ws(p)
            if q < self.n and self.s[q] == ".":
                p = q + 1
                continue
            return parts, p

    # ---- strings ----
    def _check_char(self, c, p):
        if (c < " " and c != "\t") or c == "\x7f":
            raise _Err("Illegal control character in string", p)

    def literal(self, p):
        s = self.s
        end = p + 1
        while True:
            if end >= self.n:
                raise _Err("Unterminated string", p)
            c = s[end]
            if c == "'":
                return s[p + 1:end], end + 1
            if c == "\n" or c == "\r":
                raise _Err("Unterminated string", p)
            self._check_char(c, end)
            end += 1

    def escape(self, p):
        """p at the char after backslash. Returns (text, newpos)."""
        s = self.s
        if p >= self.n:
            raise _Err("Unterminated string", p)
        c = s[p]
        if c in _ESC:
            return _ESC[c], p + 1
        size = {"x": 2, "u": 4, "U": 8}.get(c)
        if size is None:
            raise _Err("Invalid escape sequence", p - 1)
        h = s[p + 1:p + 1 + size]
        if len(h) != size or any(ch not in _HEX for ch in h):
            raise _Err("Invalid hex escape", p - 1)
        cp = int(h, 16)
        if cp > 0x10FFFF or 0xD800 <= cp <= 0xDFFF:
            raise _Err("Escaped value is not a Unicode scalar value", p - 1)
        return chr(cp), p + 1 + size

    def basic(self, p):
        s = self.s
        out = []
        q = p + 1
        while True:
            if q >= self.n:
                raise _Err("Unterminated string", p)
            c = s[q]
            if c == '"':
                return "".join(out), q + 1
            if c == "\\":
                t, q = self.escape(q + 1)
                out.append(t)
                continue
            if c == "\n" or c == "\r":
                raise _Err("Unterminated string", p)
            self._check_char(c, q)
            out.append(c)
            q += 1

    def ml_literal(self, p):
        s = self.s
        q = p + 3
        nl = self.nl(q)
        if nl >= 0:
            q = nl
        out = []
        while True:
            if q >= self.n:
                raise _Err("Unterminated string", p)
            if s.startswith("'''", q):
                run = 3
                while q + run < self.n and s[q + run] == "'":
                    run += 1
                if run > 5:
                    raise _Err("Too many quotes", q)
                out.append("'" * (run - 3))
                return "".join(out), q + run
            c = s[q]
            if c == "\r":
                if s.startswith("\r\n", q):
                    out.append("\n")
                    q += 2
                    continue
                raise _Err("Illegal carriage return in string", q)
            self._check_char(c, q)
            out.append(c)
            q += 1

    def ml_basic(self, p):
        s = self.s
        q = p + 3
        nl = self.nl(q)
        if nl >= 0:
            q = nl
        out = []
        while True:
            if q >= self.n:
                raise _Err("Unterminated string", p)
            if s.startswith('"""', q):
                run = 3
                while q + run < self.n and s[q + run] == '"':
                    run += 1
                if run > 5:
                    raise _Err("Too many quotes", q)
                out.append('"' * (run - 3))
                return "".join(out), q + run
            c = s[q]
            if c == "\\":
                # line-ending backslash?
                r = self.ws(q + 1)
                if r < self.n and self.nl(r) >= 0:
                    while r < self.n:
                        if s[r] in " \t\n":
                            r += 1
                        elif s.startswith("\r\n", r):
                            r += 2
                        else:
                            break
                    q = r
                    continue
                t, q = self.escape(q + 1)
                out.append(t)
                continue
            if c == "\r":
                if s.startswith("\r\n", q):
                    out.append("\n")
                    q += 2
                    continue
                raise _Err("Illegal carriage return in string", q)
            self._check_char(c, q)
            out.append(c)
            q += 1

    # ---- values ----
    def value(self, p):
        s = self.s
        if p >= self.n:
            raise _Err("Expected a value", p)
        c = s[p]
        if c == '"':
            if s.startswith('"""', p):
                return self.ml_basic(p)
            return self.basic(p)
        if c == "'":
            if s.startswith("'''", p):
                return self.ml_literal(p)
            return self.literal(p)
        if c == "[":
            return self.array(p)
        if c == "{":
            return self.inline(p)
        if s.startswith("true", p) and self._ends(p + 4):
            return True, p + 4
        if s.startswith("false", p) and self._ends(p + 5):
            return False, p + 5
        m = _DT.match(s, p)
        if m and not (p + 4 < self.n and False):
            return self.datetime(m, p)
        m = _TIME.match(s, p)
        if m:
            return self.localtime(m, p)
        e = p
        while e < self.n and s[e] not in _TOKEN_END:
            e += 1
        tok = s[p:e]
        if _FLOAT.fullmatch(tok) or tok in _SPECIAL:
            r = self.pf(tok)
            if isinstance(r, (dict, list)):
                raise ValueError("parse_float must not return a dict or list")
            return r, e
        if _INT.fullmatch(tok):
            t = tok.replace("_", "")
            if t[:2] in ("0x", "0o", "0b"):
                return int(t, 0), e
            return int(t, 10), e
        raise _Err("Invalid value", p)

    def _ends(self, p):
        return p >= self.n or self.s[p] in _TOKEN_END

    @staticmethod
    def _frac(f):
        return int((f or "0")[:6].ljust(6, "0"))

    def localtime(self, m, p):
        h, mi, sec, f = m.groups()
        try:
            t = time(int(h), int(mi), int(sec or 0), self._frac(f))
        except ValueError:
            raise _Err("Invalid time", p)
        return t, m.end()

    def datetime(self, m, p):
        y, mo, d, h, mi, sec, f, z, sign, oh, om = m.groups()
        try:
            dd = date(int(y), int(mo), int(d))
            if h is None:
                return dd, m.end()
            tz = None
            if z:
                tz = timezone.utc
            elif sign:
                if int(oh) > 23 or int(om) > 59:
                    raise ValueError
                off = timedelta(hours=int(oh), minutes=int(om))
                tz = timezone(-off if sign == "-" else off)
            return datetime(dd.year, dd.month, dd.day, int(h), int(mi),
                            int(sec or 0), self._frac(f), tz), m.end()
        except ValueError:
            raise _Err("Invalid date or time", p)

    def array(self, p):
        out = []
        p += 1
        while True:
            p = self.skip_all(p)
            if p >= self.n:
                raise _Err("Unterminated array", p)
            if self.s[p] == "]":
                return out, p + 1
            v, p = self.value(p)
            out.append(v)
            p = self.skip_all(p)
            if p >= self.n:
                raise _Err("Unterminated array", p)
            c = self.s[p]
            if c == ",":
                p += 1
            elif c != "]":
                raise _Err("Expected ',' or ']' in array", p)

    def inline(self, p):
        t = self.new(_D)
        p += 1
        while True:
            p = self.skip_all(p)
            if p >= self.n:
                raise _Err("Unterminated inline table", p)
            if self.s[p] == "}":
                self.kinds[id(t)] = _L
                return t, p + 1
            p = self.keyval(p, t)
            p = self.skip_all(p)
            if p >= self.n:
                raise _Err("Unterminated inline table", p)
            c = self.s[p]
            if c == ",":
                p += 1
            elif c != "}":
                raise _Err("Expected ',' or '}' in inline table", p)


def loads(s, *, parse_float=float):
    """Parse a TOML document from a str."""
    if not isinstance(s, str):
        raise TypeError("Expected str object, not %r" % type(s).__name__)
    parser = _Parser(s, parse_float)
    try:
        return parser.parse()
    except _Err as e:
        raise TOMLDecodeError(e.msg, s, e.pos) from None


def load(fp, *, parse_float=float):
    """Parse a TOML document from a binary file object."""
    b = fp.read()
    if isinstance(b, str):
        raise TypeError("File must be opened in binary mode, e.g. use `open('foo.toml', 'rb')`")
    if not isinstance(b, (bytes, bytearray, memoryview)):
        raise TypeError("File read did not return bytes")
    return loads(bytes(b).decode(), parse_float=parse_float)
