"""Hand-written TOML v1.1.0 parser (pure Python, no third-party code).

The parser walks the document text once, keeping a record of how each
table came into being so that the structural rules of TOML can be
enforced:

* ``header``  - defined by a ``[table]`` or ``[[array]]`` header
* ``dotted``  - created by dotted keys
* ``implicit`` - created only as a missing parent of a header
* ``inline``  - an inline table; frozen once written

Offsets in errors are character offsets into the original document text.
"""

import datetime
import re

from ._errors import TOMLDecodeError

# spec: N-000255 N-000256 N-000257 N-000258 N-000259 N-000260 N-000261
# spec: N-000262 N-000263 N-000264 N-000265 N-000266 N-000267 N-000268
# spec: N-000269 N-000270 N-000271 N-000272 N-000273

# Control characters that TOML forbids everywhere: all of U+0000-U+001F
# except tab, line feed and the carriage return of a CRLF pair; DEL; and
# surrogate code points (not Unicode scalar values).
_BAD_CHAR = re.compile("[\x00-\x08\x0b\x0c\x0e-\x1f\x7f\ud800-\udfff]|\r(?!\n)")

_DELIMITERS = " \t\r\n,]}#"

_BARE_KEY = re.compile(r"[A-Za-z0-9_-]+")

_DATETIME = re.compile(
    r"([0-9]{4})-([0-9]{2})-([0-9]{2})"
    r"(?:[Tt ]([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?"
    r"([Zz]|[+-][0-9]{2}:[0-9]{2})?)?"
)
_LOCAL_TIME = re.compile(r"([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?")
_HEX_INT = re.compile(r"0x[0-9A-Fa-f]+(?:_[0-9A-Fa-f]+)*")
_OCT_INT = re.compile(r"0o[0-7]+(?:_[0-7]+)*")
_BIN_INT = re.compile(r"0b[01]+(?:_[01]+)*")
_SPECIAL_FLOAT = re.compile(r"[+-]?(?:inf|nan)")
_DEC_NUMBER = re.compile(
    r"[+-]?(?:0|[1-9](?:_?[0-9])*)"
    r"(\.[0-9](?:_?[0-9])*)?"
    r"([eE][+-]?[0-9](?:_?[0-9])*)?"
)

_SIMPLE_ESCAPES = {
    "b": "\b",
    "t": "\t",
    "n": "\n",
    "f": "\f",
    "r": "\r",
    "e": "\x1b",
    '"': '"',
    "\\": "\\",
}
_NUMERIC_ESCAPES = {"x": 2, "u": 4, "U": 8}
_HEX_DIGITS = frozenset("0123456789abcdefABCDEF")


class _Parser(object):
    def __init__(self, doc, parse_float):
        self.doc = doc
        self.n = len(doc)
        self.i = 0
        self.parse_float = parse_float
        # id(obj) -> (obj, kind). The object is kept so ids stay unique.
        self._kinds = {}
        # id(list) -> list, for arrays of tables.
        self._aot = {}

    # ------------------------------------------------------------------
    # helpers

    def error(self, msg, pos=None):
        raise TOMLDecodeError(msg, self.doc, self.i if pos is None else pos)

    def _set_kind(self, obj, kind):
        self._kinds[id(obj)] = (obj, kind)

    def _kind_of(self, obj):
        entry = self._kinds.get(id(obj))
        return entry[1] if entry is not None else None

    def _at_newline(self):
        # spec: N-000111 N-000112
        doc, i = self.doc, self.i
        if i < self.n and doc[i] == "\n":
            return True
        return doc.startswith("\r\n", i)

    def _consume_newline(self):
        self.i += 2 if self.doc.startswith("\r\n", self.i) else 1

    def _skip_ws(self):
        doc, n = self.doc, self.n
        while self.i < n and doc[self.i] in " \t":
            self.i += 1

    def _skip_comment(self):
        # spec: N-000107 N-000108 N-000109
        end = self.doc.find("\n", self.i)
        self.i = self.n if end == -1 else end
        # Stop before the LF; a CR before it belongs to the line ending.
        if self.i > 0 and self.doc[self.i - 1] == "\r":
            self.i -= 1

    def _skip_ws_nl_comments(self):
        # spec: N-000105 N-000106 N-000110 N-000104
        """Skip spaces, tabs, line endings and comments (inside arrays and
        inline tables, where TOML 1.1 allows line breaks)."""
        while True:
            self._skip_ws()
            if self.i >= self.n:
                return
            if self.doc[self.i] == "#":
                self._skip_comment()
            elif self._at_newline():
                self._consume_newline()
            else:
                return

    def _end_of_line(self):
        """After a statement: optional comment, then a line ending or EOF."""
        self._skip_ws()
        if self.i < self.n and self.doc[self.i] == "#":
            self._skip_comment()
        if self.i >= self.n:
            return
        if not self._at_newline():
            self.error("expected end of line")
        self._consume_newline()

    def _delimiter_follows(self, pos):
        return pos >= self.n or self.doc[pos] in _DELIMITERS

    # ------------------------------------------------------------------
    # document

    def parse(self):
        # spec: N-000080 N-000081 N-000082 N-000083 N-000084 N-000085 N-000087 N-000110 N-000113 N-000234
        bad = _BAD_CHAR.search(self.doc)
        if bad is not None:
            self.error("invalid control character or lone carriage return", bad.start())

        root = {}
        self._set_kind(root, "root")
        current = root
        while True:
            self._skip_ws()
            if self.i >= self.n:
                break
            if self._at_newline():
                self._consume_newline()
            elif self.doc[self.i] == "#":
                self._skip_comment()
            elif self.doc[self.i] == "[":
                current = self._header(root)
            else:
                self._keyval(current)
                self._end_of_line()
        return root

    def _header(self, root):
        # spec: N-000096 N-000097 N-000099 N-000100 N-000101 N-000102 N-000114 N-000115 N-000116 N-000117 N-000118 N-000122
        self.i += 1  # first "["
        is_array = self.i < self.n and self.doc[self.i] == "["
        if is_array:
            self.i += 1
        self._skip_ws()
        keys = self._dotted_key()
        self._skip_ws()
        if self.i >= self.n or self.doc[self.i] != "]":
            self.error("expected ']' to close table header")
        self.i += 1
        if is_array:
            if self.i >= self.n or self.doc[self.i] != "]":
                self.error("expected ']]' to close array of tables header")
            self.i += 1
        self._end_of_line()

        parent = self._walk_header(root, keys[:-1])
        last = keys[-1]
        if is_array:
            if last in parent:
                array = parent[last]
                if not (isinstance(array, list) and id(array) in self._aot):
                    self.error("key already defined and is not an array of tables")
            else:
                array = []
                parent[last] = array
                self._aot[id(array)] = array
            table = {}
            self._set_kind(table, "header")
            array.append(table)
            return table

        if last in parent:
            table = parent[last]
            if not isinstance(table, dict) or self._kind_of(table) != "implicit":
                self.error("table already defined")
            self._set_kind(table, "header")
            return table
        table = {}
        self._set_kind(table, "header")
        parent[last] = table
        return table

    def _walk_header(self, root, parts):
        # spec: N-000096 N-000097 N-000098 N-000101 N-000102 N-000116 N-000119
        """Resolve the parent tables of a header, creating missing ones."""
        cur = root
        for part in parts:
            if part in cur:
                nxt = cur[part]
                if isinstance(nxt, list) and id(nxt) in self._aot:
                    nxt = nxt[-1]
                elif not isinstance(nxt, dict):
                    self.error("key already holds a value, not a table")
                if self._kind_of(nxt) == "inline":
                    self.error("cannot add to an inline table")
                cur = nxt
            else:
                nxt = {}
                self._set_kind(nxt, "implicit")
                cur[part] = nxt
                cur = nxt
        return cur

    def _walk_dotted(self, table, parts):
        # spec: N-000093 N-000095 N-000098 N-000117 N-000118 N-000120
        """Resolve the tables a dotted key passes through, creating them."""
        cur = table
        for part in parts:
            if part in cur:
                nxt = cur[part]
                if not isinstance(nxt, dict):
                    self.error("dotted key runs through a value that is not a table")
                if self._kind_of(nxt) in ("header", "inline"):
                    self.error("dotted key cannot extend a table defined elsewhere")
                cur = nxt
            else:
                nxt = {}
                self._set_kind(nxt, "dotted")
                cur[part] = nxt
                cur = nxt
        return cur

    def _keyval(self, table):
        # spec: N-000093 N-000113 N-000121
        """Parse ``key = value`` into ``table``."""
        keys = self._dotted_key()
        self._skip_ws()
        if self.i >= self.n or self.doc[self.i] != "=":
            self.error("expected '=' after key")
        self.i += 1
        self._skip_ws()
        parent = self._walk_dotted(table, keys[:-1])
        if keys[-1] in parent:
            self.error("duplicate key")
        parent[keys[-1]] = self._value()

    def _dotted_key(self):
        # spec: N-000093 N-000094 N-000091
        parts = [self._simple_key()]
        while True:
            self._skip_ws()
            if self.i < self.n and self.doc[self.i] == ".":
                self.i += 1
                self._skip_ws()
                parts.append(self._simple_key())
            else:
                return parts

    def _simple_key(self):
        # spec: N-000085 N-000086 N-000089 N-000090 N-000091 N-000092 N-000121 N-000122
        if self.i >= self.n:
            self.error("expected key")
        c = self.doc[self.i]
        if c == '"':
            if self.doc.startswith('"""', self.i):
                self.error("multiline string cannot be used as a key")
            return self._basic_string()
        if c == "'":
            if self.doc.startswith("'''", self.i):
                self.error("multiline string cannot be used as a key")
            return self._literal_string()
        m = _BARE_KEY.match(self.doc, self.i)
        if m is None:
            self.error("expected key")
        self.i = m.end()
        return m.group()

    # ------------------------------------------------------------------
    # values

    def _value(self):
        # spec: N-000123 N-000124 N-000126 N-000162 N-000163
        if self.i >= self.n:
            self.error("expected value")
        doc, i = self.doc, self.i
        if doc.startswith('"""', i):
            return self._multiline_string('"')
        if doc.startswith("'''", i):
            return self._multiline_string("'")
        c = doc[i]
        if c == '"':
            return self._basic_string()
        if c == "'":
            return self._literal_string()
        if c == "[":
            return self._array()
        if c == "{":
            return self._inline_table()
        if doc.startswith("true", i) and self._delimiter_follows(i + 4):
            self.i = i + 4
            return True
        if doc.startswith("false", i) and self._delimiter_follows(i + 5):
            self.i = i + 5
            return False
        return self._number_or_date()

    def _number_or_date(self):
        # spec: N-000144 N-000145 N-000146 N-000147 N-000148 N-000149 N-000151 N-000164 N-000166 N-000167 N-000168 N-000169 N-000170 N-000171 N-000172 N-000173
        doc, i = self.doc, self.i

        m = _DATETIME.match(doc, i)
        if m is not None:
            return self._finish(m, self._make_datetime(m))
        m = _LOCAL_TIME.match(doc, i)
        if m is not None:
            return self._finish(m, self._make_time(m))
        for pattern, base in ((_HEX_INT, 16), (_OCT_INT, 8), (_BIN_INT, 2)):
            m = pattern.match(doc, i)
            if m is not None:
                return self._finish(m, int(m.group().replace("_", "")[2:], base))
        m = _SPECIAL_FLOAT.match(doc, i)
        if m is not None:
            return self._finish(m, self._float(m.group()))
        m = _DEC_NUMBER.match(doc, i)
        if m is not None:
            text = m.group()
            if m.group(1) is not None or m.group(2) is not None:
                return self._finish(m, self._float(text))
            return self._finish(m, int(text.replace("_", "")))
        self.error("invalid value")

    def _finish(self, match, value):
        if not self._delimiter_follows(match.end()):
            self.error("invalid value")
        self.i = match.end()
        return value

    def _float(self, text):
        # spec: N-000148 N-000149 N-000150 N-000220 N-000223 N-000224 N-000230 N-000231 N-000232 N-000233
        if self.parse_float is float:
            return float(text.replace("_", ""))
        value = self.parse_float(text)
        if isinstance(value, (dict, list)):
            raise ValueError(
                "parse_float returned a dict or list; it must return a float-like value"
            )
        return value

    def _make_datetime(self, m):
        # spec: N-000151 N-000152 N-000153 N-000159 N-000179
        year, month, day, hour, minute, second, frac, offset = m.groups()
        try:
            date = datetime.date(int(year), int(month), int(day))
        except ValueError:
            self.error("invalid calendar date", m.start())
        if hour is None:
            return date
        time_part = self._time_fields(hour, minute, second, frac, m.start())
        if offset is None:
            return datetime.datetime.combine(date, time_part)
        tz = _parse_offset(offset)
        if tz is None:
            self.error("invalid UTC offset", m.start())
        return datetime.datetime.combine(date, time_part.replace(tzinfo=tz))

    def _make_time(self, m):
        hour, minute, second, frac = m.groups()
        return self._time_fields(hour, minute, second, frac, m.start())

    def _time_fields(self, hour, minute, second, frac, pos):
        # spec: N-000154 N-000155 N-000156 N-000157 N-000158 N-000180
        h, mi = int(hour), int(minute)
        s = int(second) if second is not None else 0
        if h > 23 or mi > 59 or s > 59:
            self.error("time out of range", pos)
        micro = int(frac[:6].ljust(6, "0")) if frac else 0
        return datetime.time(h, mi, s, micro)

    def _array(self):
        # spec: N-000105 N-000106 N-000281 N-000282
        self.i += 1  # "["
        items = []
        while True:
            self._skip_ws_nl_comments()
            if self.i >= self.n:
                self.error("unclosed array")
            if self.doc[self.i] == "]":
                self.i += 1
                return items
            items.append(self._value())
            self._skip_ws_nl_comments()
            if self.i >= self.n:
                self.error("unclosed array")
            c = self.doc[self.i]
            if c == ",":
                self.i += 1
            elif c == "]":
                self.i += 1
                return items
            else:
                self.error("expected ',' or ']' in array")

    def _inline_table(self):
        # spec: N-000103 N-000104
        self.i += 1  # "{"
        table = {}
        self._set_kind(table, "inline")
        self._skip_ws_nl_comments()
        if self.i < self.n and self.doc[self.i] == "}":
            self.i += 1
            return table
        while True:
            keys = self._dotted_key()
            self._skip_ws()
            if self.i >= self.n or self.doc[self.i] != "=":
                self.error("expected '=' in inline table")
            self.i += 1
            self._skip_ws()
            parent = self._walk_dotted(table, keys[:-1])
            if keys[-1] in parent:
                self.error("duplicate key")
            parent[keys[-1]] = self._value()
            self._skip_ws_nl_comments()
            if self.i >= self.n:
                self.error("unclosed inline table")
            c = self.doc[self.i]
            if c == "}":
                self.i += 1
                return table
            if c != ",":
                self.error("expected ',' or '}' in inline table")
            self.i += 1
            self._skip_ws_nl_comments()
            if self.i < self.n and self.doc[self.i] == "}":
                # Trailing comma after the last pair (TOML 1.1).
                self.i += 1
                return table

    # ------------------------------------------------------------------
    # strings

    def _basic_string(self):
        # spec: N-000127 N-000128 N-000137 N-000140 N-000174 N-000178
        self.i += 1  # opening quote
        buf = []
        doc = self.doc
        while True:
            if self.i >= self.n or self._at_newline():
                self.error("unclosed string")
            c = doc[self.i]
            if c == '"':
                self.i += 1
                return "".join(buf)
            if c == "\\":
                self.i += 1
                buf.append(self._escape())
            else:
                buf.append(c)
                self.i += 1

    def _literal_string(self):
        # spec: N-000127 N-000128 N-000129 N-000141 N-000178
        self.i += 1  # opening quote
        start = self.i
        end = self.doc.find("'", start)
        stop = end if end != -1 else self.n
        newline = self.doc.find("\n", start, stop)
        if newline != -1:
            self.i = newline
            self.error("unclosed string")
        if end == -1:
            self.i = self.n
            self.error("unclosed string")
        self.i = end + 1
        return self.doc[start:end]

    def _multiline_string(self, quote):
        # spec: N-000127 N-000130 N-000131 N-000132 N-000133 N-000134 N-000135 N-000136 N-000178 N-000179
        delim = quote * 3
        doc = self.doc
        self.i += 3
        # A line ending immediately after the opening delimiter is trimmed.
        if self._at_newline():
            self._consume_newline()
        buf = []
        while True:
            if self.i >= self.n:
                self.error("unclosed multiline string")
            if doc.startswith(delim, self.i):
                run = 0
                while self.i + run < self.n and doc[self.i + run] == quote:
                    run += 1
                if run > 5:
                    self.error("too many quote characters before closing delimiter")
                buf.append(quote * (run - 3))
                self.i += run
                return "".join(buf)
            if self._at_newline():
                buf.append("\n")
                self._consume_newline()
                continue
            c = doc[self.i]
            if quote == '"' and c == "\\":
                j = self.i + 1
                while j < self.n and doc[j] in " \t":
                    j += 1
                if j < self.n and (doc[j] == "\n" or doc.startswith("\r\n", j)):
                    # Line-ending backslash: drop the line ending and all
                    # whitespace up to the next non-whitespace character.
                    self.i = j
                    while self.i < self.n:
                        if doc[self.i] in " \t":
                            self.i += 1
                        elif self._at_newline():
                            self._consume_newline()
                        else:
                            break
                    continue
                self.i += 1
                buf.append(self._escape())
                continue
            buf.append(c)
            self.i += 1

    def _escape(self):
        # spec: N-000137 N-000138 N-000139 N-000142 N-000143 N-000174 N-000175 N-000176 N-000177
        """Decode one escape; ``self.i`` is just past the backslash."""
        if self.i >= self.n:
            self.error("unclosed string")
        c = self.doc[self.i]
        if c in _SIMPLE_ESCAPES:
            self.i += 1
            return _SIMPLE_ESCAPES[c]
        if c in _NUMERIC_ESCAPES:
            width = _NUMERIC_ESCAPES[c]
            digits = self.doc[self.i + 1:self.i + 1 + width]
            if len(digits) != width or not all(d in _HEX_DIGITS for d in digits):
                self.error("invalid hexadecimal escape")
            code = int(digits, 16)
            if code > 0x10FFFF or 0xD800 <= code <= 0xDFFF:
                self.error("escape is not a Unicode scalar value")
            self.i += 1 + width
            return chr(code)
        self.error("invalid escape sequence")


def _parse_offset(text):
    # spec: N-000152 N-000288
    if text in ("Z", "z"):
        return datetime.timezone.utc
    sign = -1 if text[0] == "-" else 1
    hours, minutes = int(text[1:3]), int(text[4:6])
    if hours > 23 or minutes > 59:
        return None
    return datetime.timezone(sign * datetime.timedelta(hours=hours, minutes=minutes))


def parse(doc, parse_float=float):
    # spec: N-000077 N-000078 N-000079 N-000081 N-000082 N-000202 N-000217
    """Parse ``doc`` (a ``str``) into a dict. Raises TOMLDecodeError."""
    parser = _Parser(doc, parse_float)
    return parser.parse()
