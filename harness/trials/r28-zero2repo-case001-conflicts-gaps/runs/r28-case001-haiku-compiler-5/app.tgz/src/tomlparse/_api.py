"""The public entries: ``loads`` (text) and ``load`` (binary file object)."""

import io

from ._errors import TOMLDecodeError
from ._parser import parse

# spec: N-000274 N-000275 N-000276 N-000277 N-000278 N-000279 N-000280
# spec: N-000281 N-000282 N-000283 N-000284 N-000285 N-000286 N-000287
# spec: N-000288 N-000289 N-000290 N-000291 N-000292 N-000293 N-000294
# spec: N-000295 N-000296 N-000297 N-000298
# spec: N-000299 N-000300 N-000301 N-000302 N-000303 N-000304 N-000305 N-000306


def loads(s, *, parse_float=float):
    """Parse the TOML v1.1.0 document ``s`` (a ``str``) into a ``dict``.

    ``parse_float`` is called with the text of every float (as written)
    and its return value is stored instead of the float. A result that is
    a ``dict`` or ``list`` (or a subclass instance) raises ``ValueError``.
    """
    if not isinstance(s, str):
        raise TypeError(
            "loads() argument must be str, not %s" % type(s).__name__
        )
    try:
        return parse(s, parse_float)
    except RecursionError:
        # Nesting deeper than the interpreter's stack allows. Reported as a
        # decode error so that callers never see a RecursionError.
        raise TOMLDecodeError("document is nested too deeply", s, len(s))


def load(fp, *, parse_float=float):
    """Parse TOML from a file object opened for binary reading.

    The bytes are decoded as UTF-8. A text-mode file object raises
    ``TypeError``.
    """
    if isinstance(fp, io.TextIOBase):
        raise TypeError("load() needs a binary file object, not a text-mode file")
    if not callable(getattr(fp, "read", None)):
        # Paths and other non-file values are refused: load() never opens files.
        raise TypeError(
            "load() expects an open binary file object, not %s" % type(fp).__name__
        )
    data = fp.read()
    if isinstance(data, str):
        raise TypeError("load() needs a binary file object, not a text-mode file")
    if not isinstance(data, (bytes, bytearray)):
        raise TypeError(
            "load() expects a binary file object, read() returned %s"
            % type(data).__name__
        )
    data = bytes(data)
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        # The document text is the decoded text; the offset is the
        # character index of the first byte that is not valid UTF-8.
        replaced = data.decode("utf-8", "replace")
        pos = len(data[:exc.start].decode("utf-8"))
        raise TOMLDecodeError("invalid UTF-8 in document", replaced, pos)
    return loads(text, parse_float=parse_float)
