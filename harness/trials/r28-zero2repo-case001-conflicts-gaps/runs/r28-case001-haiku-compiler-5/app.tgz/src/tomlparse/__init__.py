"""Tomlparse: a pure-Python parser for TOML v1.1.0.

Public names: ``loads``, ``load`` and ``TOMLDecodeError``.
"""

# spec: N-000266 N-000270

from ._api import load, loads
from ._errors import TOMLDecodeError

__all__ = ["loads", "load", "TOMLDecodeError"]
__version__ = "2.4.0"
