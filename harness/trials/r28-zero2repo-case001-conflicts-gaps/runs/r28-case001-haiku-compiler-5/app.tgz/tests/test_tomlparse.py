"""Tests for tomlparse, grouped by feature point (FP-01..FP-05) and the
interface contract. Run from /app with PYTHONPATH=src."""

import datetime
import io
import pickle

import pytest

from tomlparse import TOMLDecodeError, load, loads

UTC = datetime.timezone.utc


# ---- FP-01: document structure ------------------------------------------

def test_FP_01_empty_and_comment_only_documents():
    assert loads("") == {}
    assert loads("   \t  ") == {}
    assert loads("# only a comment") == {}
    assert loads("# only a comment\n") == {}


def test_FP_01_root_and_table_pairs():
    assert loads("a = 1\n[t]\nb = 2\n[t.u]\nc = 3\n") == {
        "a": 1, "t": {"b": 2, "u": {"c": 3}}}


def test_FP_01_keys_are_strings_and_case_sensitive():
    assert loads('true = 1\nfalse = 2\ninf = 3\n1 = 4\nA = 5\na = 6\n') == {
        "true": 1, "false": 2, "inf": 3, "1": 4, "A": 5, "a": 6}


def test_FP_01_quoted_keys():
    assert loads('"" = 1\n"a.b" = 2\n\'c#d e\' = 3\n"\\u00e9" = 4\n') == {
        "": 1, "a.b": 2, "c#d e": 3, "\u00e9": 4}


def test_FP_01_dotted_keys_and_headers():
    assert loads('a . b = 1\nc.d.e = 2\n') == {"a": {"b": 1}, "c": {"d": {"e": 2}}}
    assert loads('[a . b]\nc = 1\n') == {"a": {"b": {"c": 1}}}


def test_FP_01_header_creates_missing_parents_and_later_declaration():
    assert loads("[a.b.c]\nx = 1\n[a]\ny = 2\n") == {"a": {"y": 2, "b": {"c": {"x": 1}}}}


def test_FP_01_subtable_of_dotted_table_may_be_declared_by_header():
    assert loads("a.b.c = 1\n[a.d]\ne = 2\n") == {"a": {"b": {"c": 1}, "d": {"e": 2}}}


def test_FP_01_array_of_tables_and_nested_headers():
    doc = "[[fruit]]\nname = 'apple'\n[fruit.physical]\ncolor = 'red'\n[[fruit]]\nname = 'banana'\n"
    assert loads(doc) == {"fruit": [
        {"name": "apple", "physical": {"color": "red"}},
        {"name": "banana"},
    ]}


def test_FP_01_array_of_tables_implies_plain_parent_tables():
    assert loads("[[x.y]]\nk = 1\n[x]\nz = 2\n") == {"x": {"y": [{"k": 1}], "z": 2}}


def test_FP_01_inline_tables_and_arrays_multiline_with_trailing_commas():
    doc = 'a = {x = 1, "y" = [1, 2,], z.w = 3,}\nb = [\n  1, # one\n  "two",\n  [3],\n]\n'
    assert loads(doc) == {"a": {"x": 1, "y": [1, 2], "z": {"w": 3}},
                          "b": [1, "two", [3]]}
    assert loads("a = {\n  x = 1,\n  y = 2\n}\n") == {"a": {"x": 1, "y": 2}}
    assert loads("a = {}\nb = []\n") == {"a": {}, "b": []}


def test_FP_01_comments_and_indentation():
    assert loads("  # c\n\ta=1#c2\n   [t] # hdr\n\tb = 2\t# x\n") == {"a": 1, "t": {"b": 2}}


def test_FP_01_crlf_is_one_line_feed():
    assert loads("a = 1\r\nb = \"\"\"x\r\ny\"\"\"\r\n") == {"a": 1, "b": "x\ny"}


@pytest.mark.parametrize("doc", [
    "a = 1\na = 2",
    "[a]\n[a]",
    "a = 1\n[a]",
    "a.b = 1\n[a]",
    "[a]\nb = 1\n[a.b]",
    "a = {b = 1}\n[a.c]",
    "a = {b = 1}\na.c = 2",
    "[[a]]\n[a]",
    "a = [1]\n[[a]]",
    "[a]\n[[a]]",
    "[x]\na = 1\n[x.a.b]",
    "[[a]]\n[[a.b]]\n[a.b]",
    "a.b = 1\na.b.c = 2",
    "= 1",
    "a",
    "a = ",
    "a = 1 2",
    "[a",
    "[a]x = 1",
    "[a] b = 1",
    "a = {b = 1 c = 2}",
    "a = [1,,2]",
    '"""k""" = 1',
    "a = 1\r\nb",
])
def test_FP_01_structural_violations_are_decode_errors(doc):
    with pytest.raises(TOMLDecodeError):
        loads(doc)


# ---- FP-02: scalars ------------------------------------------------------

def test_FP_02_booleans():
    assert loads("a = true\nb = false\n") == {"a": True, "b": False}
    assert loads("a = true\n")["a"] is True


@pytest.mark.parametrize("doc", ["a = True", "a = TRUE", "a = truex", "a = false1"])
def test_FP_02_bad_booleans(doc):
    with pytest.raises(TOMLDecodeError):
        loads(doc)


def test_FP_02_strings_four_forms():
    assert loads(r'a = "tab\there\e\x41\u00e9\U0001F600\"\\"') == {
        "a": "tab\there\x1bA\u00e9\U0001F600\"\\"}
    assert loads(r"a = 'C:\no\escape'") == {"a": "C:\\no\\escape"}
    assert loads('a = """\nfirst\n  second"""') == {"a": "first\n  second"}
    assert loads("a = '''\nraw \\n\n'''") == {"a": "raw \\n\n"}


def test_FP_02_multiline_first_newline_trimmed_and_quotes_before_delimiter():
    assert loads('a = """"x""""') == {"a": '"x"'}
    assert loads('a = """x"""""') == {"a": 'x""'}
    assert loads("a = '''''''") == {"a": "'"}


def test_FP_02_line_ending_backslash_trims_whitespace():
    assert loads('a = """one \\\n\n   two\\   \n  three"""') == {"a": "one two" + "three"}


def test_FP_02_quoted_key_escape_vs_literal():
    assert loads('"\\u0041" = 1\n\'\\u0041\' = 2\n') == {"A": 1, "\\u0041": 2}


def test_FP_02_integers():
    assert loads("a = 0\nb = +0\nc = -0\nd = -17\ne = 1_000\n") == {
        "a": 0, "b": 0, "c": 0, "d": -17, "e": 1000}
    assert loads("a = 0xdead_BEEF\nb = 0o755\nc = 0b1101\n") == {
        "a": 0xDEADBEEF, "b": 0o755, "c": 0b1101}
    assert type(loads("a = 1")["a"]) is int


@pytest.mark.parametrize("doc", [
    "a = 01", "a = -01", "a = 00", "a = 0X1F", "a = 0O7", "a = 0B1",
    "a = -0x1", "a = +0xff", "a = 0x", "a = 0xG", "a = 1__0", "a = _1",
    "a = 1_", "a = 0o8", "a = 0b2", "a = 0x_1",
])
def test_FP_02_bad_integers(doc):
    with pytest.raises(TOMLDecodeError):
        loads(doc)


def test_FP_02_floats():
    assert loads("a = 3.14\nb = -0.5\nc = 6.626e-34\nd = 1e3\nf = 1_000.5E+0_1\n") == {
        "a": 3.14, "b": -0.5, "c": 6.626e-34, "d": 1000.0, "f": 10005.0}
    assert loads("a = inf\nb = +inf\nc = -inf\n") == {
        "a": float("inf"), "b": float("inf"), "c": float("-inf")}
    result = loads("a = nan\nb = +nan\nc = -nan\n")
    assert all(v != v for v in result.values())


@pytest.mark.parametrize("doc", [
    "a = .5", "a = 5.", "a = 1.e3", "a = 1e", "a = 01.5", "a = 1.0_",
    "a = 1._0", "a = +.5", "a = .", "a = infinity", "a = NaN", "a = Inf",
])
def test_FP_02_bad_floats(doc):
    with pytest.raises(TOMLDecodeError):
        loads(doc)


def test_FP_02_datetimes():
    assert loads("a = 1979-05-27T07:32:00Z")["a"] == datetime.datetime(
        1979, 5, 27, 7, 32, tzinfo=UTC)
    off = loads("a = 1979-05-27 07:32:00-07:00")["a"]
    assert off.utcoffset() == datetime.timedelta(hours=-7)
    assert loads("a = 1979-05-27t07:32:00.5z")["a"].tzinfo is UTC
    local = loads("a = 1979-05-27T07:32:00")["a"]
    assert local == datetime.datetime(1979, 5, 27, 7, 32) and local.tzinfo is None
    assert loads("a = 1979-05-27")["a"] == datetime.date(1979, 5, 27)
    assert loads("a = 07:32:00")["a"] == datetime.time(7, 32)
    assert loads("a = 07:32")["a"] == datetime.time(7, 32, 0)


def test_FP_02_fraction_read_as_microseconds_truncated():
    assert loads("a = 00:00:00.5")["a"].microsecond == 500000
    assert loads("a = 00:00:00.1234567")["a"].microsecond == 123456
    assert loads("a = 00:00:00.9999999")["a"].microsecond == 999999
    assert loads("a = 00:00:00")["a"].microsecond == 0


def test_FP_02_leap_day():
    assert loads("a = 2024-02-29")["a"] == datetime.date(2024, 2, 29)


@pytest.mark.parametrize("doc", [
    "a = 2023-02-29", "a = 1979-13-01", "a = 1979-00-10", "a = 07:60:00",
    "a = 24:00:00", "a = 07:32:60", "a = 1979-05-27T07:32:00+24:00",
    "a = 1979-5-27", "a = 1979-05-27Z", "a = 07:32:00Z",
])
def test_FP_02_bad_date_times(doc):
    with pytest.raises(TOMLDecodeError):
        loads(doc)


def test_FP_02_parsed_values_copy_and_compare():
    import copy
    value = loads("a = 1979-05-27T07:32:00Z")["a"]
    assert copy.deepcopy(value) == value


# ---- FP-04: rejection and the decode error ------------------------------

def test_FP_04_decode_error_is_value_error_not_type_error():
    with pytest.raises(ValueError) as info:
        loads("a = ")
    assert isinstance(info.value, TOMLDecodeError)
    assert not isinstance(info.value, TypeError)
    assert not isinstance(info.value, RecursionError)


@pytest.mark.parametrize("bad", [b"a = 1", 1, None, ["a = 1"], io.StringIO("a = 1")])
def test_FP_04_wrong_python_type_is_type_error(bad):
    with pytest.raises(TypeError) as info:
        loads(bad)
    assert not isinstance(info.value, TOMLDecodeError)


def test_FP_04_location_fields_and_line_column_rule():
    with pytest.raises(TOMLDecodeError) as info:
        loads("a = 1\nb = 2\nc = 3 4\n")
    err = info.value
    assert err.doc == "a = 1\nb = 2\nc = 3 4\n"
    assert err.pos == err.doc.index("4")
    assert (err.lineno, err.colno) == (3, 7)
    assert str(err)


def test_FP_04_constructed_error_carries_values_and_location():
    err = TOMLDecodeError("reason", "ab\ncd", 4)
    assert (err.msg, err.doc, err.pos) == ("reason", "ab\ncd", 4)
    assert (err.lineno, err.colno) == (2, 2)
    assert "reason" in str(err)
    assert "line 2" in str(err)


def test_FP_04_end_of_document_position_is_reported_as_end():
    err = TOMLDecodeError("expected", "ab", 2)
    assert "end of document" in str(err)


def test_FP_04_error_survives_pickling():
    with pytest.raises(TOMLDecodeError) as info:
        loads("x = [")
    clone = pickle.loads(pickle.dumps(info.value))
    assert (clone.msg, clone.doc, clone.pos) == (info.value.msg, info.value.doc, info.value.pos)


def test_FP_04_nesting_too_deep_is_decode_error_not_recursion_error():
    deep = "a = " + "[" * 5000 + "]" * 5000
    with pytest.raises(TOMLDecodeError):
        loads(deep)


# ---- FP-03: binary file entry --------------------------------------------

def test_FP_03_binary_file_matches_string_entry():
    text = 'a = "é"\r\n[t]\r\nb = 1979-05-27\r\n'
    assert load(io.BytesIO(text.encode("utf-8"))) == loads(text)


def test_FP_03_empty_file_is_empty_mapping():
    assert load(io.BytesIO(b"")) == {}


def test_FP_03_text_mode_file_is_type_error():
    with pytest.raises(TypeError):
        load(io.StringIO("a = 1"))


def test_FP_03_invalid_utf8_is_decode_error():
    with pytest.raises(TOMLDecodeError):
        load(io.BytesIO(b"a = 1\xff"))


def test_FP_03_decode_error_document_is_decoded_text():
    with pytest.raises(TOMLDecodeError) as info:
        load(io.BytesIO("a = 1\nb = 2 3\n".encode("utf-8")))
    assert info.value.doc == "a = 1\nb = 2 3\n"
    assert isinstance(info.value.doc, str)


def test_FP_03_load_takes_no_filesystem_path(tmp_path):
    path = tmp_path / "doc.toml"
    path.write_bytes(b"a = 1\n")
    with pytest.raises(TypeError):
        load(str(path))


# ---- FP-05: float converter ----------------------------------------------

def test_FP_05_converter_receives_float_text_everywhere():
    seen = []

    def conv(text):
        seen.append(text)
        return "F(" + text + ")"

    doc = "a = 1.5\nb = 1e1_0\nc = [-inf, +nan]\n[t]\nd = {x = 2.0}\ni = 3\n"
    out = loads(doc, parse_float=conv)
    assert out == {"a": "F(1.5)", "b": "F(1e1_0)", "c": ["F(-inf)", "F(+nan)"],
                   "t": {"d": {"x": "F(2.0)"}, "i": 3}}
    assert seen == ["1.5", "1e1_0", "-inf", "+nan", "2.0"]


def test_FP_05_converter_result_not_checked_for_scalars():
    assert loads("a = 1.0", parse_float=lambda s: None) == {"a": None}
    assert loads("a = 1.0", parse_float=lambda s: "x") == {"a": "x"}


@pytest.mark.parametrize("bad_result", [{}, [], type("D", (dict,), {})(),
                                        type("L", (list,), {})()])
def test_FP_05_dict_or_list_result_is_value_error_not_decode_error(bad_result):
    with pytest.raises(ValueError) as info:
        loads("a = 1.0", parse_float=lambda s: bad_result)
    assert not isinstance(info.value, TOMLDecodeError)


def test_FP_05_binary_entry_applies_converter():
    out = load(io.BytesIO(b"a = 2.5"), parse_float=lambda s: s.upper())
    assert out == {"a": "2.5"}


# ---- interface contract ---------------------------------------------------

def test_IC_public_names_importable_from_root():
    import tomlparse
    assert callable(tomlparse.loads) and callable(tomlparse.load)
    assert issubclass(tomlparse.TOMLDecodeError, ValueError)
    assert not issubclass(tomlparse.TOMLDecodeError, TypeError)


def test_IC_loads_has_keyword_only_parse_float():
    with pytest.raises(TypeError):
        loads("a = 1.0", lambda s: s)


def test_IC_no_tomllib_dependency():
    import sys
    import tomlparse  # noqa: F401
    sources = [m.__file__ for name, m in sys.modules.items()
               if name.startswith("tomlparse") and getattr(m, "__file__", None)]
    for path in sources:
        with open(path, encoding="utf-8") as fh:
            text = fh.read()
        assert "import tomllib" not in text and "from tomllib" not in text
