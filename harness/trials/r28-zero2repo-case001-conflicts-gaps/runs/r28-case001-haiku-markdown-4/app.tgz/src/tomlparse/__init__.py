"""Tomlparse: a pure-Python TOML v1.1.0 parser returning native Python values."""

import io as _io

from ._errors import TOMLDecodeError
from ._parser import parse as _parse

__all__ = ["loads", "load", "TOMLDecodeError"]
__version__ = "2.4.0"


def loads(s, *, parse_float=float):
    """Parse a TOML document from a text string into a dict.

    Raises TypeError if ``s`` is not a str, TOMLDecodeError if the document
    is not valid TOML v1.1.0, and ValueError if ``parse_float`` returns a
    dict or list.
    """
    if not isinstance(s, str):
        raise TypeError("loads() expects a str, not %s" % type(s).__name__)
    return _parse(s, parse_float)


def load(fp, *, parse_float=float):
    """Parse a TOML document from a file object opened for binary reading.

    The bytes are decoded as UTF-8 and parsed as ``loads`` would parse them.
    Raises TypeError for text-mode file objects or objects without ``read``.
    """
    if isinstance(fp, _io.TextIOBase):
        raise TypeError("load() expects a binary file object, not a text-mode file")
    read = getattr(fp, "read", None)
    if read is None:
        raise TypeError("load() expects a binary file object with a read() method")
    data = read()
    if isinstance(data, str):
        raise TypeError("load() expects a binary file object, not a text-mode file")
    if not isinstance(data, (bytes, bytearray, memoryview)):
        raise TypeError("load() read() must return bytes, not %s" % type(data).__name__)
    raw = bytes(data)
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        text = raw.decode("utf-8", "replace")
        pos = len(raw[: exc.start].decode("utf-8"))
        raise TOMLDecodeError("invalid UTF-8 in document", text, pos)
    return loads(text, parse_float=parse_float)
