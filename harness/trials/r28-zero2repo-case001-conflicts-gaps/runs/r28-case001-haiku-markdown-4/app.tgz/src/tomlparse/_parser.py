"""A hand-written TOML v1.1.0 parser.

The parser walks the document text with an index and builds plain
``dict``/``list``/scalar values directly. Structural bookkeeping (which
tables were defined by a header, by dotted keys, implicitly, or inline) is
kept in side tables keyed by ``id()``; every container stays referenced from
the result tree for the whole parse, so those ids remain valid.
"""

import datetime as _dt
import re

from ._errors import TOMLDecodeError

_HEX = frozenset("0123456789abcdefABCDEF")
_SIMPLE_ESCAPES = {
    "b": "\b",
    "t": "\t",
    "n": "\n",
    "f": "\f",
    "r": "\r",
    "e": "\x1b",
    '"': '"',
    "\\": "\\",
}
_HEX_ESCAPE_WIDTH = {"x": 2, "u": 4, "U": 8}
_SPECIAL_FLOATS = frozenset(["inf", "+inf", "-inf", "nan", "+nan", "-nan"])

_BARE_RE = re.compile(r"[A-Za-z0-9_\-]+")
_TOKEN_RE = re.compile(r"[A-Za-z0-9_+.\-]*")
_DATETIME_RE = re.compile(
    r"([0-9]{4})-([0-9]{2})-([0-9]{2})"
    r"(?:[Tt ]([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?"
    r"([Zz]|[+-][0-9]{2}:[0-9]{2})?)?"
)
_TIME_RE = re.compile(r"([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?")
_INT_RE = re.compile(r"[+-]?(?:0|[1-9](?:_?[0-9])*)")
_HEX_RE = re.compile(r"0x[0-9a-fA-F](?:_?[0-9a-fA-F])*")
_OCT_RE = re.compile(r"0o[0-7](?:_?[0-7])*")
_BIN_RE = re.compile(r"0b[01](?:_?[01])*")
_FLOAT_RE = re.compile(
    r"[+-]?(?:0|[1-9](?:_?[0-9])*)"
    r"(?:\.[0-9](?:_?[0-9])*)?"
    r"(?:[eE][+-]?[0-9](?:_?[0-9])*)?"
)


def _bad_ctrl(c):
    """Control characters that TOML forbids raw (tab is checked by callers)."""
    o = ord(c)
    return (o < 0x20 and c != "\t") or o == 0x7F


class Parser(object):
    def __init__(self, text, parse_float):
        self.s = text
        self.n = len(text)
        self.i = 0
        self.parse_float = parse_float
        self.custom_float = parse_float is not float
        self.root = {}
        # id(table) -> "implicit" | "header" | "dotted" | "inline"
        self.kind = {}
        # ids of lists that are arrays of tables (as opposed to static arrays)
        self.aot = set()

    # ------------------------------------------------------------------
    # helpers

    def _err(self, msg, pos=None):
        raise TOMLDecodeError(msg, self.s, self.i if pos is None else pos)

    def _skip_ws(self):
        s, n = self.s, self.n
        while self.i < n and s[self.i] in " \t":
            self.i += 1

    def _skip_newline(self):
        if self.s[self.i] == "\n":
            self.i += 1
        else:
            self.i += 2

    def _at_newline(self, j):
        s = self.s
        return j < self.n and (s[j] == "\n" or s.startswith("\r\n", j))

    def _skip_comment(self):
        s, n = self.s, self.n
        j = self.i + 1
        while j < n:
            c = s[j]
            if c == "\n" or (c == "\r" and j + 1 < n and s[j + 1] == "\n"):
                break
            if _bad_ctrl(c):
                self._err("control character in comment", j)
            j += 1
        self.i = j

    def _skip_ws_nl_comments(self):
        s, n = self.s, self.n
        while self.i < n:
            c = s[self.i]
            if c in " \t":
                self.i += 1
            elif c == "\n" or s.startswith("\r\n", self.i):
                self._skip_newline()
            elif c == "#":
                self._skip_comment()
            else:
                break

    def _end_of_line(self):
        self._skip_ws()
        if self.i < self.n and self.s[self.i] == "#":
            self._skip_comment()
        if self.i >= self.n:
            return
        if self._at_newline(self.i):
            self._skip_newline()
            return
        self._err("expected end of line")

    # ------------------------------------------------------------------
    # document

    def parse(self):
        s = self.s
        cur = self.root
        while True:
            self._skip_ws()
            if self.i >= self.n:
                break
            c = s[self.i]
            if self._at_newline(self.i):
                self._skip_newline()
                continue
            if c == "#":
                self._skip_comment()
                continue
            if c == "[":
                cur = self._header()
            else:
                self._keyval(cur)
            self._end_of_line()
        return self.root

    # ------------------------------------------------------------------
    # keys and tables

    def _key_part(self):
        if self.i >= self.n:
            self._err("expected key")
        c = self.s[self.i]
        if c == '"':
            return self._basic_single()
        if c == "'":
            return self._literal_single()
        m = _BARE_RE.match(self.s, self.i)
        if m is None:
            self._err("expected key")
        self.i = m.end()
        return m.group()

    def _key(self):
        parts = []
        while True:
            self._skip_ws()
            parts.append(self._key_part())
            self._skip_ws()
            if self.i < self.n and self.s[self.i] == ".":
                self.i += 1
                continue
            return parts

    def _keyval(self, table):
        keypos = self.i
        parts = self._key()
        self._skip_ws()
        if self.i >= self.n or self.s[self.i] != "=":
            self._err("expected '=' after key")
        self.i += 1
        self._skip_ws()
        value = self._value()
        self._insert(table, parts, value, keypos)

    def _insert(self, table, parts, value, pos):
        """Store ``value`` at the dotted ``parts`` path inside ``table``."""
        node = table
        for part in parts[:-1]:
            if part in node:
                child = node[part]
                if not isinstance(child, dict):
                    self._err("key %r already holds a value" % (part,), pos)
                k = self.kind.get(id(child))
                if k == "inline" or k == "header":
                    self._err("dotted key cannot extend table %r" % (part,), pos)
                if k == "implicit":
                    self.kind[id(child)] = "dotted"
                node = child
            else:
                child = {}
                self.kind[id(child)] = "dotted"
                node[part] = child
                node = child
        last = parts[-1]
        if last in node:
            self._err("duplicate key %r" % (last,), pos)
        node[last] = value

    def _descend(self, node, part, pos):
        """Step into ``node[part]`` for a table header's parent path."""
        if part in node:
            child = node[part]
            if isinstance(child, list):
                if id(child) not in self.aot:
                    self._err("static array %r cannot be extended" % (part,), pos)
                child = child[-1]
            elif not isinstance(child, dict):
                self._err("key %r already holds a value" % (part,), pos)
            if self.kind.get(id(child)) == "inline":
                self._err("inline table %r is frozen" % (part,), pos)
            return child
        child = {}
        self.kind[id(child)] = "implicit"
        node[part] = child
        return child

    def _header(self):
        s = self.s
        pos = self.i
        is_aot = s.startswith("[[", self.i)
        self.i += 2 if is_aot else 1
        self._skip_ws()
        parts = self._key()
        self._skip_ws()
        close = "]]" if is_aot else "]"
        if not s.startswith(close, self.i):
            self._err("expected %r to close table header" % (close,))
        self.i += len(close)

        node = self.root
        for part in parts[:-1]:
            node = self._descend(node, part, pos)
        last = parts[-1]

        if is_aot:
            if last in node:
                child = node[last]
                if not (isinstance(child, list) and id(child) in self.aot):
                    self._err("%r is not an array of tables" % (last,), pos)
            else:
                child = []
                self.aot.add(id(child))
                node[last] = child
            elem = {}
            self.kind[id(elem)] = "header"
            child.append(elem)
            return elem

        if last in node:
            child = node[last]
            if not isinstance(child, dict) or self.kind.get(id(child)) != "implicit":
                self._err("table %r is already defined" % (last,), pos)
            self.kind[id(child)] = "header"
        else:
            child = {}
            self.kind[id(child)] = "header"
            node[last] = child
        return child

    # ------------------------------------------------------------------
    # strings

    def _escape(self, j):
        """Decode the escape whose backslash is at ``j``; return (text, next)."""
        s, n = self.s, self.n
        k = j + 1
        if k >= n:
            self._err("unterminated escape sequence", k)
        c = s[k]
        if c in _SIMPLE_ESCAPES:
            return _SIMPLE_ESCAPES[c], k + 1
        width = _HEX_ESCAPE_WIDTH.get(c)
        if width is None:
            self._err("invalid escape sequence", k)
        start = k + 1
        for m in range(start, start + width):
            if m >= n or s[m] not in _HEX:
                self._err("invalid hexadecimal escape", m)
        cp = int(s[start:start + width], 16)
        if cp > 0x10FFFF or 0xD800 <= cp <= 0xDFFF:
            self._err("escaped code point is not a Unicode scalar value", k)
        return chr(cp), start + width

    def _basic_single(self):
        s, n = self.s, self.n
        j = self.i + 1
        buf = []
        while True:
            if j >= n:
                self._err("unterminated string", n)
            c = s[j]
            if c == '"':
                self.i = j + 1
                return "".join(buf)
            if c == "\\":
                text, j = self._escape(j)
                buf.append(text)
            elif _bad_ctrl(c) and c != "\t":
                self._err("control character in string", j)
            else:
                buf.append(c)
                j += 1

    def _literal_single(self):
        s, n = self.s, self.n
        j = self.i + 1
        start = j
        while True:
            if j >= n:
                self._err("unterminated string", n)
            c = s[j]
            if c == "'":
                self.i = j + 1
                return s[start:j]
            if _bad_ctrl(c) and c != "\t":
                self._err("control character in string", j)
            j += 1

    def _run(self, q, j):
        s, n = self.s, self.n
        k = j
        while k < n and s[k] == q:
            k += 1
        return k - j

    def _skip_line_ending_ws(self, j):
        s, n = self.s, self.n
        while j < n:
            if s[j] in " \t\n":
                j += 1
            elif s.startswith("\r\n", j):
                j += 2
            else:
                break
        return j

    def _multiline(self, q, basic):
        s, n = self.s, self.n
        j = self.i + 3
        if s.startswith("\r\n", j):
            j += 2
        elif j < n and s[j] == "\n":
            j += 1
        buf = []
        while True:
            if j >= n:
                self._err("unterminated multiline string", n)
            c = s[j]
            if c == q:
                run = self._run(q, j)
                if run >= 3:
                    if run > 5:
                        self._err("too many quote characters before closing delimiter", j + 5)
                    buf.append(q * (run - 3))
                    self.i = j + run
                    return "".join(buf)
                buf.append(q * run)
                j += run
                continue
            if basic and c == "\\":
                m = j + 1
                while m < n and s[m] in " \t":
                    m += 1
                if self._at_newline(m):
                    j = self._skip_line_ending_ws(m)
                    continue
                text, j = self._escape(j)
                buf.append(text)
                continue
            if c == "\r":
                if s.startswith("\r\n", j):
                    buf.append("\n")
                    j += 2
                    continue
                self._err("bare carriage return in multiline string", j)
            if c == "\n":
                buf.append("\n")
                j += 1
                continue
            if _bad_ctrl(c) and c != "\t":
                self._err("control character in string", j)
            buf.append(c)
            j += 1

    # ------------------------------------------------------------------
    # scalars

    def _micro(self, frac):
        if not frac:
            return 0
        return int(frac[:6].ljust(6, "0"))

    def _datetime(self, m):
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        try:
            date = _dt.date(y, mo, d)
        except ValueError:
            self._err("invalid calendar date", m.start())
        self.i = m.end()
        if m.group(4) is None:
            return date
        hh, mi = int(m.group(4)), int(m.group(5))
        ss = int(m.group(6)) if m.group(6) else 0
        us = self._micro(m.group(7))
        if hh > 23 or mi > 59 or ss > 59:
            self._err("time component out of range", m.start())
        tztext = m.group(8)
        tz = None
        if tztext is not None:
            if tztext in ("Z", "z"):
                tz = _dt.timezone.utc
            else:
                oh, om = int(tztext[1:3]), int(tztext[4:6])
                if oh > 23 or om > 59:
                    self._err("UTC offset out of range", m.start())
                delta = _dt.timedelta(hours=oh, minutes=om)
                if tztext[0] == "-":
                    delta = -delta
                tz = _dt.timezone(delta)
        return _dt.datetime(y, mo, d, hh, mi, ss, us, tzinfo=tz)

    def _time(self, m):
        hh, mi = int(m.group(1)), int(m.group(2))
        ss = int(m.group(3)) if m.group(3) else 0
        us = self._micro(m.group(4))
        if hh > 23 or mi > 59 or ss > 59:
            self._err("time component out of range", m.start())
        self.i = m.end()
        return _dt.time(hh, mi, ss, us)

    def _make_float(self, tok):
        if self.custom_float:
            value = self.parse_float(tok)
            if isinstance(value, (dict, list)):
                raise ValueError(
                    "parse_float returned a dict or list for %r; "
                    "only scalar results are allowed" % (tok,)
                )
            return value
        return float(tok.replace("_", ""))

    def _number(self):
        s, i = self.s, self.i
        m = _TOKEN_RE.match(s, i)
        tok = m.group()
        if not tok:
            self._err("expected value")
        self.i = m.end()
        if tok == "true":
            return True
        if tok == "false":
            return False
        if tok in _SPECIAL_FLOATS:
            return self._make_float(tok)
        clean = tok.replace("_", "")
        if _HEX_RE.fullmatch(tok):
            return int(clean[2:], 16)
        if _OCT_RE.fullmatch(tok):
            return int(clean[2:], 8)
        if _BIN_RE.fullmatch(tok):
            return int(clean[2:], 2)
        if _INT_RE.fullmatch(tok):
            return int(clean, 10)
        if _FLOAT_RE.fullmatch(tok) and ("." in tok or "e" in tok or "E" in tok):
            return self._make_float(tok)
        self._err("invalid value %r" % (tok,), i)

    def _value(self):
        s, n = self.s, self.n
        if self.i >= n:
            self._err("expected value")
        c = s[self.i]
        if c == '"':
            if s.startswith('"""', self.i):
                return self._multiline('"', True)
            return self._basic_single()
        if c == "'":
            if s.startswith("'''", self.i):
                return self._multiline("'", False)
            return self._literal_single()
        if c == "[":
            return self._array()
        if c == "{":
            return self._inline()
        m = _DATETIME_RE.match(s, self.i)
        if m is not None:
            return self._datetime(m)
        m = _TIME_RE.match(s, self.i)
        if m is not None:
            return self._time(m)
        return self._number()

    # ------------------------------------------------------------------
    # containers

    def _array(self):
        s = self.s
        self.i += 1
        result = []
        while True:
            self._skip_ws_nl_comments()
            if self.i >= self.n:
                self._err("unterminated array")
            if s[self.i] == "]":
                self.i += 1
                return result
            result.append(self._value())
            self._skip_ws_nl_comments()
            if self.i >= self.n:
                self._err("unterminated array")
            c = s[self.i]
            if c == ",":
                self.i += 1
                continue
            if c == "]":
                self.i += 1
                return result
            self._err("expected ',' or ']' in array")

    def _inline(self):
        s = self.s
        self.i += 1
        table = {}
        self.kind[id(table)] = "inline"
        self._skip_ws_nl_comments()
        if self.i < self.n and s[self.i] == "}":
            self.i += 1
            return table
        while True:
            keypos = self.i
            parts = self._key()
            self._skip_ws()
            if self.i >= self.n or s[self.i] != "=":
                self._err("expected '=' after key")
            self.i += 1
            self._skip_ws()
            value = self._value()
            self._insert(table, parts, value, keypos)
            self._skip_ws_nl_comments()
            if self.i >= self.n:
                self._err("unterminated inline table")
            c = s[self.i]
            if c == ",":
                self.i += 1
                self._skip_ws_nl_comments()
                if self.i < self.n and s[self.i] == "}":
                    self.i += 1
                    return table
                continue
            if c == "}":
                self.i += 1
                return table
            self._err("expected ',' or '}' in inline table")


def parse(text, parse_float):
    """Parse ``text`` (a str) into a document dict."""
    parser = Parser(text, parse_float)
    try:
        return parser.parse()
    except RecursionError:
        raise TOMLDecodeError("document nested too deeply", text, parser.i)
