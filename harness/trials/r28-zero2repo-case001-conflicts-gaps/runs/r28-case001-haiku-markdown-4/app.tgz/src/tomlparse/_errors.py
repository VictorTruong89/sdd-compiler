"""The documented parse-failure exception for Tomlparse."""


class TOMLDecodeError(ValueError):
    """A document is not valid TOML v1.1.0.

    Attributes:
        msg:    the unformatted reason
        doc:    the document text
        pos:    0-based character offset into ``doc``
        lineno: 1-based line of ``pos`` (1 + line feeds before ``pos``)
        colno:  1-based column of ``pos`` (1 + characters since the last
                line feed before ``pos``, or since the start of ``doc``)
    """

    def __init__(self, msg, doc, pos):
        self.msg = msg
        self.doc = doc
        self.pos = pos
        self.lineno = doc.count("\n", 0, pos) + 1
        self.colno = pos - doc.rfind("\n", 0, pos)
        location = "line %d column %d (char %d)" % (self.lineno, self.colno, pos)
        if pos >= len(doc):
            report = "%s: end of document, %s" % (msg, location)
        else:
            report = "%s: %s" % (msg, location)
        super(TOMLDecodeError, self).__init__(report)

    def __reduce__(self):
        # Keep pickling/copying working despite the custom constructor.
        return (self.__class__, (self.msg, self.doc, self.pos))
