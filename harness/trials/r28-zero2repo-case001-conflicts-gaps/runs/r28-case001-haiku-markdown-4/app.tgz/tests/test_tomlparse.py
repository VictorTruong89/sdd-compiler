"""Tests for tomlparse. Run from /app with: PYTHONPATH=src python3 -m unittest discover -s tests"""

import datetime as dt
import io
import pickle
import unittest

import tomlparse
from tomlparse import TOMLDecodeError, load, loads


class ValidDocuments(unittest.TestCase):
    def test_empty_and_comment_only(self):
        self.assertEqual(loads(""), {})
        self.assertEqual(loads("   \t  "), {})
        self.assertEqual(loads("# only a comment"), {})
        self.assertEqual(loads("# only a comment\n"), {})

    def test_root_pairs_and_tables(self):
        doc = 'a = 1\n[t]\nb = "x"  # trailing comment\n[t.u]\nc = true\n'
        self.assertEqual(loads(doc), {"a": 1, "t": {"b": "x", "u": {"c": True}}})

    def test_keys_are_strings(self):
        self.assertEqual(
            loads('1234 = 1\ntrue = 2\ninf = 3\nnan = 4\n"" = 5\n"a.b" = 6\n\'c\' = 7'),
            {"1234": 1, "true": 2, "inf": 3, "nan": 4, "": 5, "a.b": 6, "c": 7},
        )

    def test_dotted_keys_and_whitespace(self):
        self.assertEqual(loads("a . b . c = 1"), {"a": {"b": {"c": 1}}})
        self.assertEqual(loads("a.b = 1\na.c = 2"), {"a": {"b": 1, "c": 2}})

    def test_super_table_declared_later(self):
        self.assertEqual(loads("[x.y.z]\nk = 1\n[x]\nj = 2"), {"x": {"y": {"z": {"k": 1}}, "j": 2}})

    def test_header_after_dotted_subtable(self):
        doc = "[fruit]\napple.color = 'red'\napple.taste.sweet = true\n[fruit.apple.texture]\nsmooth = true\n"
        self.assertEqual(
            loads(doc),
            {"fruit": {"apple": {"color": "red", "taste": {"sweet": True}, "texture": {"smooth": True}}}},
        )

    def test_array_of_tables(self):
        doc = '[[p]]\nname = "a"\n[p.dims]\nx = 1\n[[p]]\nname = "b"\n[[p.parts]]\nid = 1\n[[p.parts]]\nid = 2\n'
        self.assertEqual(
            loads(doc),
            {
                "p": [
                    {"name": "a", "dims": {"x": 1}},
                    {"name": "b", "parts": [{"id": 1}, {"id": 2}]},
                ]
            },
        )

    def test_array_of_tables_implies_plain_parent(self):
        doc = "[[x.y]]\nk = 1\n[x]\nother = 2\n"
        self.assertEqual(loads(doc), {"x": {"y": [{"k": 1}], "other": 2}})

    def test_arrays_trailing_comma_nesting_mixed_multiline(self):
        doc = 'a = [\n  1, # one\n  "two",\n  [3.0, [], ],\n  {x = 1},\n]\n'
        self.assertEqual(loads(doc), {"a": [1, "two", [3.0, []], {"x": 1}]})

    def test_inline_tables(self):
        self.assertEqual(loads("a = {}"), {"a": {}})
        self.assertEqual(loads("a = { b.c = 1, d = [1,], }"), {"a": {"b": {"c": 1}, "d": [1]}})
        self.assertEqual(loads("a = {\n  b = 1, # c\n  c = 2,\n}"), {"a": {"b": 1, "c": 2}})

    def test_crlf_is_single_line_feed(self):
        self.assertEqual(loads("a = 1\r\n[t]\r\nb = 2\r\n"), {"a": 1, "t": {"b": 2}})
        self.assertEqual(loads('s = """x\r\ny"""'), {"s": "x\ny"})


class Scalars(unittest.TestCase):
    def test_booleans(self):
        self.assertIs(loads("a = true")["a"], True)
        self.assertIs(loads("a = false")["a"], False)

    def test_strings(self):
        self.assertEqual(loads(r'a = "tab\there \u00e9 \U0001F600 \x41 \e \""')["a"], "tab\there \u00e9 \U0001F600 A \x1b \"")
        self.assertEqual(loads(r"a = 'C:\no\escape'")["a"], r"C:\no\escape")
        self.assertEqual(loads('a = """\nfirst\nsecond"""')["a"], "first\nsecond")
        self.assertEqual(loads("a = '''\nkeep\\n'''")["a"], "keep\\n")
        self.assertEqual(loads('a = """one \\\n    two\n  three"""')["a"], "one two\n  three")
        self.assertEqual(loads('a = """x""""')["a"], 'x"')
        self.assertEqual(loads('a = """x"""""')["a"], 'x""')
        self.assertEqual(loads("a = ''''''")["a"], "")
        self.assertEqual(loads('a = "tab\tliteral"')["a"], "tab\tliteral")

    def test_quoted_key_escapes(self):
        self.assertEqual(loads(r'"\u0041" = 1'), {"A": 1})
        self.assertEqual(loads(r"'\u0041' = 1"), {"\\u0041": 1})

    def test_integers(self):
        doc = "a = 0\nb = +0\nc = -17\nd = 1_000\ne = 0xDEAD_beef\nf = 0o755\ng = 0b1101\nh = 0xff\n"
        self.assertEqual(
            loads(doc),
            {"a": 0, "b": 0, "c": -17, "d": 1000, "e": 0xDEADBEEF, "f": 0o755, "g": 13, "h": 255},
        )
        self.assertIsInstance(loads("a = 1")["a"], int)
        self.assertNotIsInstance(loads("a = 1")["a"], bool)

    def test_floats(self):
        doc = "a = 1.5\nb = -0.0\nc = 1e6\nd = 6.626e-34\ne = 1_0.5E+1_0\nf = inf\ng = -inf\nh = +inf\n"
        result = loads(doc)
        self.assertEqual(result["a"], 1.5)
        self.assertEqual(result["c"], 1e6)
        self.assertEqual(result["e"], 10.5e10)
        self.assertEqual(result["f"], float("inf"))
        self.assertEqual(result["g"], float("-inf"))
        self.assertEqual(result["h"], float("inf"))
        self.assertTrue(loads("a = nan")["a"] != loads("a = nan")["a"])
        self.assertTrue(loads("a = -nan")["a"] != loads("a = -nan")["a"])

    def test_datetimes(self):
        doc = (
            "odt = 1979-05-27T07:32:00Z\n"
            "odt2 = 1979-05-27 07:32:00.999999-07:30\n"
            "ldt = 1979-05-27T00:32\n"
            "ld = 1979-05-27\n"
            "lt = 07:32:00.1234567\n"
            "leap = 2024-02-29T00:00:00z\n"
        )
        result = loads(doc)
        self.assertEqual(result["odt"], dt.datetime(1979, 5, 27, 7, 32, tzinfo=dt.timezone.utc))
        self.assertEqual(
            result["odt2"].utcoffset(), dt.timedelta(hours=-7, minutes=-30)
        )
        self.assertEqual(result["odt2"].microsecond, 999999)
        self.assertIsNone(result["ldt"].tzinfo)
        self.assertEqual(result["ldt"], dt.datetime(1979, 5, 27, 0, 32))
        self.assertIs(type(result["ld"]), dt.date)
        self.assertEqual(result["lt"], dt.time(7, 32, 0, 123456))
        self.assertIsNone(result["lt"].tzinfo)
        self.assertEqual(result["leap"].day, 29)


class Rejections(unittest.TestCase):
    def assertRejected(self, doc):
        with self.assertRaises(TOMLDecodeError, msg=repr(doc)):
            loads(doc)

    def test_duplicate_and_redefinition(self):
        for doc in [
            "a = 1\na = 2",
            "[a]\n[a]",
            "[a.b]\n[a]\n[a.b]",
            "a.b = 1\n[a]\nb = 2",
            "[a.b]\nc = 1\n[a]\nb.d = 2",
            "a = 1\n[a]",
            "a = {b = 1}\n[a.c]",
            "a = {b = 1}\na.c = 2",
            "a = {b = 1, b = 2}",
            "a = [1]\n[[a]]",
            "[[a]]\n[a]",
            "a = [{b = 1}]\n[a.c]",
            "a.b = 1\n[[a.b]]",
            "[x]\n[[x]]",
            "a = 1\na.b = 2",
        ]:
            self.assertRejected(doc)

    def test_syntax(self):
        for doc in [
            "= 1",
            "a =",
            "a 1",
            "[a",
            "[a] b = 1",
            "a = 1 b = 2",
            '"""k""" = 1',
            '[a."""b"""]',
            "a = [1 2]",
            "a = [,]",
            "a = {,}",
            "a = {b = 1 c = 2}",
            "a = 1 # \x01 control",
            "a = 1\rb = 2",
        ]:
            self.assertRejected(doc)

    def test_scalars(self):
        for doc in [
            "a = True",
            "a = TRUE",
            "a = 01",
            "a = -01",
            "a = 00",
            "a = 0_1",
            "a = 1__0",
            "a = 1_",
            "a = _1",
            "a = 0X1F",
            "a = 0xG",
            "a = -0x1",
            "a = +0o7",
            "a = 0b102",
            "a = .5",
            "a = 1.",
            "a = 1.e5",
            "a = 1e",
            "a = 1.5.6",
            "a = infinity",
            "a = +nan_",
            "a = \"\\q\"",
            "a = \"\\X41\"",
            "a = \"\\x4\"",
            "a = \"\\u00G0\"",
            "a = \"\\uD800\"",
            "a = \"\\U00110000\"",
            "a = \"\\u00E9\\U0000DFFF\"",
            "a = 'unterminated",
            "a = \"unterminated",
            "a = \"line\nbreak\"",
            "a = \"ctrl\x07\"",
            "a = \"\x7f\"",
            "a = \"\"\"x\ry\"\"\"",
            "a = \"\"\"x\\ y\"\"\"",
            "a = \"\"\"x\"\"\"\"\"\"",
            "a = 1979-02-29",
            "a = 2023-13-01",
            "a = 1979-05-27T24:00:00",
            "a = 1979-05-27T07:60:00",
            "a = 1979-05-27T07:32:00+24:00",
            "a = 1979-05-27T",
            "a = 1979-05-27Z",
            "a = 12:60:00",
            "a = 1979-05-27T07:32:00.Z",
        ]:
            self.assertRejected(doc)

    def test_error_location(self):
        with self.assertRaises(TOMLDecodeError) as cm:
            loads("a = 1\nb = 2\nc = x")
        err = cm.exception
        self.assertIsInstance(err, ValueError)
        self.assertEqual(err.doc, "a = 1\nb = 2\nc = x")
        self.assertEqual(err.pos, err.doc.index("x"))
        self.assertEqual((err.lineno, err.colno), (3, 5))
        self.assertIn("line 3", str(err))

    def test_error_at_end_of_document(self):
        with self.assertRaises(TOMLDecodeError) as cm:
            loads("a = [1,")
        self.assertGreaterEqual(cm.exception.pos, len("a = [1,") - 1)
        self.assertIn("end of document", str(cm.exception))

    def test_constructed_error(self):
        err = TOMLDecodeError("bad", "ab\ncd", 4)
        self.assertEqual((err.msg, err.doc, err.pos, err.lineno, err.colno), ("bad", "ab\ncd", 4, 2, 2))
        self.assertIn("bad", str(err))
        self.assertIsInstance(err, ValueError)
        self.assertFalse(isinstance(err, TypeError))
        copied = pickle.loads(pickle.dumps(err))
        self.assertEqual((copied.msg, copied.doc, copied.pos), ("bad", "ab\ncd", 4))


class Types(unittest.TestCase):
    def test_wrong_input_types(self):
        for bad in [b"a = 1", 1, True, io.BytesIO(b"a=1")]:
            with self.assertRaises(TypeError):
                loads(bad)
            self.assertFalse(isinstance(TypeError(), TOMLDecodeError))

    def test_text_mode_file_refused(self):
        with self.assertRaises(TypeError):
            load(io.StringIO("a = 1"))

    def test_load_binary(self):
        self.assertEqual(load(io.BytesIO(b"a = 'caf\xc3\xa9'")), {"a": "caf\u00e9"})
        self.assertEqual(load(io.BytesIO(b"")), {})

    def test_load_invalid_utf8(self):
        with self.assertRaises(TOMLDecodeError):
            load(io.BytesIO(b"a = '\xff'"))

    def test_load_decode_error_doc_is_text(self):
        with self.assertRaises(TOMLDecodeError) as cm:
            load(io.BytesIO(b"a = 1\nb = x"))
        self.assertIsInstance(cm.exception.doc, str)


class Converter(unittest.TestCase):
    def test_called_for_every_float_with_text(self):
        seen = []

        def conv(text):
            seen.append(text)
            return "F(" + text + ")"

        doc = "a = 1.5\nb = 1_0e+2\nc = [inf, -nan, 3]\nd = {e = +inf}\n"
        result = loads(doc, parse_float=conv)
        self.assertEqual(result["a"], "F(1.5)")
        self.assertEqual(result["b"], "F(1_0e+2)")
        self.assertEqual(result["c"], ["F(inf)", "F(-nan)", 3])
        self.assertEqual(result["d"], {"e": "F(+inf)"})
        self.assertEqual(seen, ["1.5", "1_0e+2", "inf", "-nan", "+inf"])

    def test_converter_result_dict_or_list_is_value_error(self):
        for bad in [lambda t: {}, lambda t: [], lambda t: type("D", (dict,), {})()]:
            with self.assertRaises(ValueError) as cm:
                loads("a = 1.0", parse_float=bad)
            self.assertNotIsInstance(cm.exception, TOMLDecodeError)

    def test_converter_scalar_results_allowed(self):
        self.assertEqual(loads("a = 1.5", parse_float=lambda t: None), {"a": None})
        self.assertEqual(loads("a = 1.5", parse_float=lambda t: 0), {"a": 0})

    def test_converter_not_called_for_integers(self):
        def conv(text):
            raise AssertionError("should not be called")

        self.assertEqual(loads("a = 1\nb = 0x10", parse_float=conv), {"a": 1, "b": 16})


class Spec(unittest.TestCase):
    def test_version_and_exports(self):
        self.assertEqual(tomlparse.__version__, "2.4.0")
        self.assertTrue(issubclass(TOMLDecodeError, ValueError))
        self.assertFalse(issubclass(TOMLDecodeError, TypeError))
        self.assertFalse(issubclass(TOMLDecodeError, RecursionError))

    def test_plain_result_types(self):
        result = loads('a = {b = [{c = 1}]}\nd = "x"')
        self.assertIs(type(result), dict)
        self.assertIs(type(result["a"]), dict)
        self.assertIs(type(result["a"]["b"]), list)
        self.assertIs(type(result["a"]["b"][0]), dict)


if __name__ == "__main__":
    unittest.main()
