"""Tests for tomlparse, organised by the spec's feature points and interface contract.

Run from /app with:  PYTHONPATH=src python3 -m pytest tests
"""

import datetime as dt
import io
import os
import pickle
import sys
import copy

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from tomlparse import TOMLDecodeError, load, loads  # noqa: E402


# ------------------------------------------------------------------ interface

def test_public_names_importable_from_root():
    import tomlparse
    assert callable(tomlparse.loads)
    assert callable(tomlparse.load)
    assert issubclass(tomlparse.TOMLDecodeError, ValueError)


def test_empty_and_comment_only_documents():  # FP-01 normal behaviour
    assert loads("") == {}
    assert loads("   \t  ") == {}
    assert loads("# only a comment") == {}
    assert loads("# only a comment\n") == {}
    assert loads("\n\n# a\n\n") == {}


def test_loads_is_keyword_only_for_parse_float():
    with pytest.raises(TypeError):
        loads("a = 1.0", float)  # noqa: E501 positional parse_float is not allowed


def test_loads_refuses_non_str_with_type_error():
    for bad in (b"a = 1", True, 1, None, io.StringIO("a = 1")):
        with pytest.raises(TypeError) as info:
            loads(bad)
        assert not isinstance(info.value, TOMLDecodeError)


def test_load_binary_file_and_bytes_io():  # FP-03
    assert load(io.BytesIO(b"k = true")) == {"k": True}
    assert load(io.BytesIO(b"")) == {}


def test_load_refuses_text_mode_with_type_error():  # FP-03 / FP-04
    with pytest.raises(TypeError) as info:
        load(io.StringIO("k = 1"))
    assert not isinstance(info.value, TOMLDecodeError)


def test_load_result_equals_loads_result():
    text = 'a = "é"\n[t]\nb = 2024-01-02T03:04:05Z\n'
    assert load(io.BytesIO(text.encode("utf-8"))) == loads(text)


def test_load_decodes_crlf_like_loads():
    text = b"s = '''\r\nx\r\ny'''\r\n"
    assert load(io.BytesIO(text)) == {"s": "x\ny"}


# ------------------------------------------------------------- FP-01 structure

def test_root_and_table_pairs():
    doc = 'a = 1\n[t]\nb = 2\n[u.v]\nc = 3\n'
    assert loads(doc) == {"a": 1, "t": {"b": 2}, "u": {"v": {"c": 3}}}


def test_keys_are_strings_and_keep_case():
    assert loads('1 = 1\ntrue = 2\ninf = 3\nnan = 4\nA = 5\na = 6\n') == {
        "1": 1, "true": 2, "inf": 3, "nan": 4, "A": 5, "a": 6}


def test_quoted_keys_escape_rules():
    got = loads('"a.b" = 1\n\'c.d\' = 2\n"\\u00e9" = 3\n\'\\u00e9\' = 4\n"# x" = 5\n')
    assert got == {"a.b": 1, "c.d": 2, "é": 3, "\\u00e9": 4, "# x": 5}


def test_empty_quoted_key_allowed():  # CF-000074: quoted key may be empty
    assert loads('"" = 1') == {"": 1}


def test_dotted_keys_nest_and_allow_spaces():
    assert loads('a . b . c = 1\na.d = 2\n') == {"a": {"b": {"c": 1}, "d": 2}}


def test_dotted_keys_cannot_extend_header_table():
    with pytest.raises(TOMLDecodeError):
        loads("[a.b]\nx = 1\n[a]\nb.y = 2\n")


def test_header_can_add_subtable_of_dotted_table():  # CF-000012 / TOML spec example
    doc = "[fruit]\napple.color = 'red'\napple.taste.sweet = true\n[fruit.apple.texture]\nsmooth = true\n"
    assert loads(doc) == {"fruit": {"apple": {
        "color": "red", "taste": {"sweet": True}, "texture": {"smooth": True}}}}


def test_header_cannot_redefine_dotted_table():
    with pytest.raises(TOMLDecodeError):
        loads("[fruit]\napple.color = 'red'\n[fruit.apple]\n")


def test_super_tables_implicit_then_defined():
    assert loads("[a.b.c]\nx = 1\n[a]\ny = 2\n") == {"a": {"b": {"c": {"x": 1}}, "y": 2}}


def test_super_table_defined_twice_refused():
    with pytest.raises(TOMLDecodeError):
        loads("[a.b]\n[a]\n[a]\n")


def test_array_of_tables_and_nesting():
    doc = (
        "[[fruit]]\nname = 'apple'\n[[fruit.variety]]\nn = 1\n"
        "[[fruit.variety]]\nn = 2\n[[fruit]]\nname = 'banana'\n"
    )
    assert loads(doc) == {"fruit": [
        {"name": "apple", "variety": [{"n": 1}, {"n": 2}]},
        {"name": "banana"},
    ]}


def test_aot_implied_parent_is_plain_table_and_can_be_declared_later():
    doc = "[[a.b]]\nx = 1\n[a]\ny = 2\n"
    assert loads(doc) == {"a": {"b": [{"x": 1}], "y": 2}}


def test_header_for_aot_element_subtable_attaches_to_last_item():
    doc = "[[p]]\n[p.s]\nv = 1\n[[p]]\n[p.s]\nv = 2\n"
    assert loads(doc) == {"p": [{"s": {"v": 1}}, {"s": {"v": 2}}]}


def test_table_and_aot_name_clash_refused():
    with pytest.raises(TOMLDecodeError):
        loads("[[a]]\n[a]\n")
    with pytest.raises(TOMLDecodeError):
        loads("[a]\n[[a]]\n")


def test_value_cannot_be_replaced_by_table():
    with pytest.raises(TOMLDecodeError):
        loads("a = 1\n[a]\n")


def test_static_array_cannot_be_extended_by_aot():
    with pytest.raises(TOMLDecodeError):
        loads("a = [1]\n[[a]]\n")


def test_inline_table_is_frozen():
    with pytest.raises(TOMLDecodeError):
        loads("a = {b = 1}\n[a.c]\n")
    with pytest.raises(TOMLDecodeError):
        loads("a = {b = 1}\na.c = 2\n")


def test_inline_table_multiline_comments_trailing_comma():  # TOML 1.1
    doc = "a = {\n  x = 1, # c\n  y = [1,\n 2,],\n}\n"
    assert loads(doc) == {"a": {"x": 1, "y": [1, 2]}}


def test_inline_table_empty_and_dotted():
    assert loads("a = {}\nb = {c.d = 1, c.e = 2}\n") == {"a": {}, "b": {"c": {"d": 1, "e": 2}}}


def test_arrays_mixed_nested_multiline_comments_trailing_comma():
    assert loads("a = []\nb = [1, 'x', [2, [3]], {k = 1}, ]\nc = [\n  1, # one\n  2,\n]\n") == {
        "a": [], "b": [1, "x", [2, [3]], {"k": 1}], "c": [1, 2]}


def test_pair_without_key_or_value_refused():
    for bad in ("= 1", "a =", "a", "a = \n", "[a]]\n", "[ ]\n"):
        with pytest.raises(TOMLDecodeError):
            loads(bad)


def test_multiline_string_as_key_refused():
    with pytest.raises(TOMLDecodeError):
        loads('"""a""" = 1')
    with pytest.raises(TOMLDecodeError):
        loads("[''' a''']\n")


def test_header_unclosed_or_sharing_line_refused():
    with pytest.raises(TOMLDecodeError):
        loads("[a\nb = 1\n")
    with pytest.raises(TOMLDecodeError):
        loads("[a] b = 1\n")


def test_duplicate_keys_refused():
    with pytest.raises(TOMLDecodeError):
        loads("a = 1\na = 2")
    with pytest.raises(TOMLDecodeError):
        loads("a.b = 1\na.b = 2")


def test_indentation_insignificant_and_comments_anywhere():
    assert loads("  [t]  # c\n\t x = 1 # d\n") == {"t": {"x": 1}}


def test_crlf_treated_as_lf_everywhere():
    assert loads("a = 1\r\nb = '''\r\nx\r\n'''\r\n") == {"a": 1, "b": "x\n"}


def test_comment_text_never_becomes_content():
    assert loads("a = [1 # comment ] text\n, 2]\n") == {"a": [1, 2]}


def test_non_ascii_comments_allowed():
    assert loads("# ünïcode ✓\na = 1 # 日本\n") == {"a": 1}


def test_control_character_in_comment_refused():
    with pytest.raises(TOMLDecodeError):
        loads("a = 1 # bad\x01\n")


# -------------------------------------------------------- FP-02 scalar types

def test_booleans_only_lowercase():
    assert loads("a = true\nb = false\n") == {"a": True, "b": False}
    assert loads("a = true")["a"] is True
    for bad in ("a = True", "a = TRUE", "a = tRue"):
        with pytest.raises(TOMLDecodeError):
            loads(bad)


def test_basic_string_escapes_all_forms():
    doc = 'a = "\\b\\t\\n\\f\\r\\e\\"\\\\"\n'
    assert loads(doc) == {"a": "\b\t\n\f\r\x1b\"\\"}
    assert loads('a = "\\x41\\u00e9\\U0001F600"') == {"a": "A\u00e9\U0001F600"}
    assert loads('a = "\\xff"') == {"a": "\u00ff"}


def test_hex_escape_digits_case_insensitive():  # CF-000072
    assert loads('a = "\\u00E9\\u00e9"') == {"a": "\u00e9\u00e9"}


def test_bad_escapes_refused():
    for bad in ('a = "\\q"', 'a = "\\x4"', 'a = "\\u12"', 'a = "\\uD800"',
                'a = "\\U00110000"', 'a = "\\xGG"'):
        with pytest.raises(TOMLDecodeError):
            loads(bad)


def test_literal_string_has_no_escapes():
    assert loads("a = 'C:\\path\\n'") == {"a": "C:\\path\\n"}


def test_literal_quoted_key_is_unchanged():
    assert loads("'\\t' = 1") == {"\\t": 1}


def test_multiline_basic_trims_first_newline_and_line_ending_backslash():
    doc = 'a = """\nline1\n  line2 \\\n    cont"""\n'
    assert loads(doc) == {"a": "line1\n  line2 cont"}


def test_line_ending_backslash_trims_all_whitespace_incl_newlines():  # CF-000015
    doc = 'a = """x\\   \n\n   \t y"""'
    assert loads(doc) == {"a": "xy"}


def test_multiline_basic_quotes_before_closing_delimiter():  # CF-000001
    assert loads('a = """x""""') == {"a": 'x"'}
    assert loads('a = """x"""""') == {"a": 'x""'}
    assert loads('a = """x"" y"""') == {"a": 'x"" y'}


def test_multiline_literal_quotes_and_first_newline():  # CF-000009
    assert loads("a = '''\nfirst\\n''\n'''") == {"a": "first\\n''\n"}
    assert loads("a = '''\n\n'''") == {"a": "\n"}


def test_multiline_literal_single_line():
    assert loads("a = '''x'''") == {"a": "x"}


def test_multiline_basic_keeps_line_feeds_and_leading_spaces():
    assert loads('a = """\n  x\n\n  y"""') == {"a": "  x\n\n  y"}


def test_multiline_carriage_return_bare_refused():
    with pytest.raises(TOMLDecodeError):
        loads('a = """x\ry"""')


def test_raw_tab_allowed_in_strings():  # CF-000071 / CF-000035 / CF-000028
    assert loads('a = "x\ty"') == {"a": "x\ty"}
    assert loads("a = 'x\ty'") == {"a": "x\ty"}
    assert loads("a = '''x\ty'''") == {"a": "x\ty"}


def test_raw_control_characters_refused_in_strings():
    for bad in ('a = "x\x01"', "a = 'x\x7f'", 'a = """x\x00"""', 'a = "x\ny"'):
        with pytest.raises(TOMLDecodeError):
            loads(bad)


def test_unclosed_strings_refused():
    for bad in ('a = "x', "a = 'x", 'a = """x', "a = '''x", 'a = """x"""""" ' ):
        with pytest.raises(TOMLDecodeError):
            loads(bad)


def test_line_ending_backslash_must_be_followed_by_line_ending():
    with pytest.raises(TOMLDecodeError):
        loads('a = """x\\ y"""')


def test_integers_in_all_bases():
    doc = "a = 0xDEAD_beef\nb = 0o755\nc = 0b1101_0110\nd = +99\ne = -17\nf = 0\ng = +0\nh = -0\n"
    assert loads(doc) == {"a": 0xDEADBEEF, "b": 0o755, "c": 0b11010110,
                          "d": 99, "e": -17, "f": 0, "g": 0, "h": 0}


def test_hex_integers_accept_either_case_digits():  # CF-000037
    assert loads("a = 0xabcDEF") == {"a": 0xABCDEF}


def test_integer_leading_zero_and_bad_underscores_refused():
    for bad in ("a = 01", "a = -01", "a = +0x1", "a = 0X1", "a = 0x", "a = 1__0",
                "a = _1", "a = 1_", "a = 0x_1", "a = 0b2", "a = 0o8", "a = -0x1",
                "a = 1_0_"):
        with pytest.raises(TOMLDecodeError):
            loads(bad)


def test_floats_default_and_special():
    got = loads("a = 3.14\nb = -1e3\nc = 6.626e-34\nd = 224_617.445_991\ne = 1e02\n"
                "f = inf\ng = -inf\nh = +inf\ni = +nan\nj = -nan\n")
    assert got["a"] == 3.14 and got["b"] == -1000.0 and got["c"] == 6.626e-34
    assert got["d"] == 224617.445991 and got["e"] == 100.0
    assert got["f"] == float("inf") and got["g"] == float("-inf") and got["h"] == float("inf")
    assert got["i"] != got["i"] and got["j"] != got["j"]


def test_floats_without_digits_on_both_sides_refused():
    for bad in ("a = 1.", "a = .5", "a = .", "a = 1.e5", "a = 01.5", "a = 1e"):
        with pytest.raises(TOMLDecodeError):
            loads(bad)


def test_offset_datetimes():
    got = loads("a = 1979-05-27T07:32:00Z\nb = 1979-05-27 07:32:00.999999+01:30\n"
                "c = 1979-05-27t07:32:00z\nd = 1979-05-27T07:32Z\n")
    assert got["a"] == dt.datetime(1979, 5, 27, 7, 32, tzinfo=dt.timezone.utc)
    assert got["a"].utcoffset() == dt.timedelta(0)
    assert got["b"].utcoffset() == dt.timedelta(hours=1, minutes=30)
    assert got["b"].microsecond == 999999
    assert got["c"].tzinfo is not None
    assert got["d"].second == 0


def test_local_datetime_date_time():
    got = loads("a = 1979-05-27T07:32:00\nb = 1979-05-27\nc = 07:32:00\nd = 07:32\n")
    assert got["a"] == dt.datetime(1979, 5, 27, 7, 32) and got["a"].tzinfo is None
    assert got["b"] == dt.date(1979, 5, 27) and not isinstance(got["b"], dt.datetime)
    assert got["c"] == dt.time(7, 32, 0) and got["c"].tzinfo is None
    assert got["d"] == dt.time(7, 32, 0)


def test_fraction_truncated_to_microseconds():  # CF-000045 / CF-000069
    assert loads("a = 07:32:00.1234567")["a"] == dt.time(7, 32, 0, 123456)
    assert loads("a = 07:32:00.1234569")["a"] == dt.time(7, 32, 0, 123456)
    assert loads("a = 07:32:00.1")["a"] == dt.time(7, 32, 0, 100000)


def test_invalid_calendar_and_time_values_refused():
    for bad in ("a = 1979-02-29", "a = 2023-02-29T00:00:00Z", "a = 1979-13-01",
                "a = 07:60:00", "a = 24:00:00", "a = 07:32:60", "a = 1979-05-27T07:32:00+24:00"):
        with pytest.raises(TOMLDecodeError):
            loads(bad)


def test_leap_day_accepted():
    assert loads("a = 2024-02-29") == {"a": dt.date(2024, 2, 29)}


def test_seconds_may_be_omitted():  # CF-000062
    assert loads("a = 1979-05-27T07:32Z")["a"].second == 0
    assert loads("a = 07:32")["a"] == dt.time(7, 32, 0)


def test_datetime_values_copy_and_compare():
    v = loads("a = 1979-05-27T07:32:00Z")["a"]
    assert copy.deepcopy(v) == v and copy.copy(v) == v


# -------------------------------------------------------- FP-05 float converter

def test_converter_called_with_text_as_written_everywhere():
    seen = []

    def conv(text):
        seen.append(text)
        return ("F", text)

    doc = "a = -1_0.5e+2\nt = {x = inf}\nl = [+nan, 2.0]\n[h]\nq = 1.0\n"
    got = loads(doc, parse_float=conv)
    assert got == {"a": ("F", "-1_0.5e+2"), "t": {"x": ("F", "inf")},
                   "l": [("F", "+nan"), ("F", "2.0")], "h": {"q": ("F", "1.0")}}
    assert seen == ["-1_0.5e+2", "inf", "+nan", "2.0", "1.0"]


def test_converter_not_called_for_non_floats():
    seen = []
    loads("a = 1\nb = 'x'\nc = true\nd = 1979-05-27\ne = 0x1\n", parse_float=lambda t: seen.append(t))
    assert seen == []


def test_converter_result_dict_or_list_is_value_error_not_decode_error():
    for bad_result in ({}, []):
        with pytest.raises(ValueError) as info:
            loads("a = 1.5", parse_float=lambda t, r=bad_result: r)
        assert not isinstance(info.value, TOMLDecodeError)


def test_converter_subclass_of_dict_or_list_refused():  # CF-000023 / CF-000073
    class D(dict):
        pass

    class L(list):
        pass

    for bad in (D(), L()):
        with pytest.raises(ValueError) as info:
            loads("a = 1.5", parse_float=lambda t, b=bad: b)
        assert not isinstance(info.value, TOMLDecodeError)


def test_converter_returning_any_other_value_is_bound_as_returned():
    sentinel = object()
    assert loads("a = 1.5", parse_float=lambda t: sentinel) == {"a": sentinel}
    assert loads("a = 1.5", parse_float=lambda t: None) == {"a": None}


def test_converter_exceptions_propagate_unchanged():
    class Boom(Exception):
        pass

    def conv(t):
        raise Boom(t)

    with pytest.raises(Boom):
        loads("a = 1.5", parse_float=conv)


# ----------------------------------------------------- FP-04 errors & location

def test_decode_error_is_value_error_not_type_or_recursion():
    with pytest.raises(TOMLDecodeError) as info:
        loads("a = ")
    err = info.value
    assert isinstance(err, ValueError)
    assert not isinstance(err, TypeError)
    assert not isinstance(err, RecursionError)


def test_error_location_attributes_for_interior_offset():
    with pytest.raises(TOMLDecodeError) as info:
        loads("a = 1\nb = @\n")
    err = info.value
    assert err.doc == "a = 1\nb = @\n"
    assert err.pos == 10 and err.doc[err.pos] == "@"
    assert (err.lineno, err.colno) == (2, 5)
    assert "line 2" in str(err) and "column 5" in str(err)


def test_error_at_end_of_document_mentions_end():
    with pytest.raises(TOMLDecodeError) as info:
        loads("a = ")
    err = info.value
    assert err.pos >= len(err.doc)
    assert "end of document" in str(err)


def test_constructed_error_carries_given_values():
    err = TOMLDecodeError("bad thing", "ab\ncd\nef", 4)
    assert err.msg == "bad thing"
    assert err.doc == "ab\ncd\nef"
    assert err.pos == 4
    assert err.lineno == 2
    assert err.colno == 2
    assert "bad thing" in str(err)
    assert "line 2" in str(err) and "column 2" in str(err)


def test_constructed_error_first_column_when_no_newline_before():
    err = TOMLDecodeError("m", "xyz", 0)
    assert (err.lineno, err.colno) == (1, 1)


def test_constructed_error_pickles():
    err = TOMLDecodeError("m", "a\nb", 2)
    again = pickle.loads(pickle.dumps(err))
    assert (again.msg, again.doc, again.pos, again.lineno, again.colno) == (
        "m", "a\nb", 2, 2, 1)


def test_error_offsets_map_back_to_crlf_text():
    with pytest.raises(TOMLDecodeError) as info:
        loads("a = 1\r\nb = @\r\n")
    err = info.value
    assert err.doc[err.pos] == "@"
    assert err.lineno == 2


def test_binary_error_doc_is_decoded_text():
    with pytest.raises(TOMLDecodeError) as info:
        load(io.BytesIO("é = @".encode("utf-8")))
    assert isinstance(info.value.doc, str)
    assert info.value.doc == "é = @"


def test_invalid_utf8_in_load_is_not_silently_accepted():
    with pytest.raises(ValueError):
        load(io.BytesIO(b"a = '\xff'"))


def test_deep_nesting_reports_decode_error_not_recursion_error():
    depth = 20000
    doc = "a = " + "[" * depth + "]" * depth
    with pytest.raises(TOMLDecodeError):
        loads(doc)


def test_moderate_nesting_accepted():
    depth = 100
    doc = "a = " + "[" * depth + "]" * depth
    got = loads(doc)["a"]
    for _ in range(depth - 1):
        got = got[0]
    assert got == []


def test_document_is_unchanged_by_parse_failure_no_partial_mapping():
    with pytest.raises(TOMLDecodeError):
        loads("a = 1\nb = 2\nc = @\n")


# ---------------------------------------------------------------- worked docs

def test_spec_style_example_document():
    doc = """
    # This is a TOML document
    title = "TOML Example"
    [owner]
    name = "Tom Preston-Werner"
    dob = 1979-05-27T07:32:00-08:00
    [database]
    enabled = true
    ports = [ 8000, 8001, 8002 ]
    data = [ ["delta", "phi"], [3.14] ]
    temp_targets = { cpu = 79.5, case = 72.0 }
    [servers]
    [servers.alpha]
    ip = "10.0.0.1"
    [servers.beta]
    ip = "10.0.0.2"
    """
    got = loads(doc)
    assert got["title"] == "TOML Example"
    assert got["owner"]["dob"].utcoffset() == dt.timedelta(hours=-8)
    assert got["database"]["data"] == [["delta", "phi"], [3.14]]
    assert got["servers"] == {"alpha": {"ip": "10.0.0.1"}, "beta": {"ip": "10.0.0.2"}}
