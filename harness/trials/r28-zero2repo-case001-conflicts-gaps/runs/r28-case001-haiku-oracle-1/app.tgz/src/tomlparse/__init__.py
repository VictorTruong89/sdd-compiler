"""Tomlparse: a pure-Python parser for TOML v1.1.0.

Public names::

    from tomlparse import loads, load, TOMLDecodeError
"""

from .errors import TOMLDecodeError
from .parser import load, loads

__version__ = "2.4.0"

__all__ = ["loads", "load", "TOMLDecodeError"]
