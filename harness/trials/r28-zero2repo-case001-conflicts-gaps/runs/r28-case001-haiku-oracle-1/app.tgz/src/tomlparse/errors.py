"""The decode error raised for invalid TOML.

# spec: N-000307 N-000308 N-000309 N-000310 N-000311 N-000312 N-000313
# spec: N-000314 N-000315 N-000316 N-000317 N-000318 N-000319
# spec: N-000320 N-000321 N-000322 N-000323 N-000203 N-000204 N-000205 N-000206
# spec: N-000207 N-000208 N-000209 N-000210 N-000211 N-000212 N-000217 N-000218 N-000219
"""

__all__ = ["TOMLDecodeError"]


class TOMLDecodeError(ValueError):
    """Raised when a TOML document is not valid TOML v1.1.0.

    Attributes:
      msg     -- the unformatted reason (str)
      doc     -- the document text (str)
      pos     -- 0-based character offset into ``doc`` (int)
      lineno  -- 1-based line of ``pos`` in ``doc`` (int)
      colno   -- 1-based column of ``pos`` in ``doc`` (int)

    A caller may construct an instance with ``TOMLDecodeError(msg, doc, pos)``;
    the line and column are derived from ``doc`` and ``pos`` exactly as for a
    raised parse failure.
    """

    def __init__(self, msg, doc, pos):
        self.msg = msg
        self.doc = doc
        self.pos = pos
        # Line is 1 + number of line feeds before pos.
        self.lineno = doc.count("\n", 0, pos) + 1
        # Column is 1 + characters between the last line feed before pos (or the
        # start of the document) and pos. rfind returns -1 when there is none,
        # which makes the formula pos + 1 in that case.
        self.colno = pos - doc.rfind("\n", 0, pos)
        if pos >= len(doc):
            report = "%s at end of document (line %d, column %d)" % (
                msg, self.lineno, self.colno)
        else:
            report = "%s (line %d, column %d)" % (msg, self.lineno, self.colno)
        super().__init__(report)

    def __reduce__(self):
        # Keep copy/pickle working: the constructor takes three arguments, not
        # the single formatted message that ValueError would otherwise store.
        return (self.__class__, (self.msg, self.doc, self.pos))


TOMLDecodeError.__module__ = "tomlparse"
