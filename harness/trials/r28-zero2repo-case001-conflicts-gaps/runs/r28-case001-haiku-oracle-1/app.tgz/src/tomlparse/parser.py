"""A TOML v1.1.0 parser written from the specification in ``spec/``.

The parser is a character-level recursive-descent reader. It does not use the
standard library's TOML module or any other TOML implementation.

Where the specification contradicts itself, the choice made here is listed in
``NOTES.md`` (conflict ids CF-000001 ... CF-000074).
"""

import bisect
import datetime as _dt
import io
import re

from .errors import TOMLDecodeError

__all__ = ["loads", "load"]

# Table-state flags stored per container object (see _Parser._set_flag).
_HEADER = 1   # defined by a [table] header, or created as an [[array]] element
_DOTTED = 2   # created by dotted keys; may be extended by further dotted keys
_INLINE = 4   # an inline table; frozen once written
_AOT = 8      # an array of tables (a list whose elements came from [[headers]])

_BARE_KEY_RE = re.compile(r"[A-Za-z0-9_-]+")
_DT_RE = re.compile(
    r"([0-9]{4})-([0-9]{2})-([0-9]{2})"
    r"(?:[Tt ]([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?"
    r"([Zz]|[+-][0-9]{2}:[0-9]{2})?)?"
)
_TIME_RE = re.compile(r"([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?")
_SPECIAL_FLOAT_RE = re.compile(r"[+-]?(?:inf|nan)")
_HEX_RE = re.compile(r"0x[0-9A-Fa-f]+(?:_[0-9A-Fa-f]+)*")
_OCT_RE = re.compile(r"0o[0-7]+(?:_[0-7]+)*")
_BIN_RE = re.compile(r"0b[01]+(?:_[01]+)*")
# A float needs a fraction, an exponent, or both (digits on both sides of '.').
_FLOAT_RE = re.compile(
    r"[+-]?(?:0|[1-9][0-9]*(?:_[0-9]+)*)"
    r"(?:\.[0-9]+(?:_[0-9]+)*(?:[eE][+-]?[0-9]+(?:_[0-9]+)*)?"
    r"|[eE][+-]?[0-9]+(?:_[0-9]+)*)"
)
_INT_RE = re.compile(r"[+-]?(?:0|[1-9][0-9]*(?:_[0-9]+)*)")

_SIMPLE_ESCAPES = {
    "b": "\b",
    "t": "\t",
    "n": "\n",
    "f": "\f",
    "r": "\r",
    "e": "\x1b",
    '"': '"',
    "\\": "\\",
}
_ESCAPE_WIDTHS = {"x": 2, "u": 4, "U": 8}
_HEXDIGITS = frozenset("0123456789abcdefABCDEF")


def _is_control(c):
    """Control characters are refused in strings and comments, except tab.

    Line feed counts as a control character here; callers that allow it check
    for it first.
    """
    return (c < " " and c != "\t") or c == "\x7f"


def _normalize(text):
    """Replace each CR LF pair with a single LF.

    Returns the normalized text and, for error reporting, the list of
    normalized indexes at which a removed CR sat before an LF. See
    ``_Parser._error``.
    """
    if "\r\n" not in text:
        return text, []
    removed_before = []
    for k, m in enumerate(re.finditer("\r\n", text)):
        removed_before.append(m.start() - k)
    return text.replace("\r\n", "\n"), removed_before


def _micro(fraction):
    """First six digits of a fraction, right-padded with zeros (truncated)."""
    if not fraction:
        return 0
    return int(fraction[:6].ljust(6, "0"))


class _Parser:
    def __init__(self, text, original, parse_float, crlf_marks):
        self.s = text
        self.n = len(text)
        self.i = 0
        self.doc = original
        self.crlf_marks = crlf_marks
        self.parse_float = parse_float
        self.flags = {}

    # ----------------------------------------------------------------- errors

    def _error(self, msg, pos=None):
        """Build (not raise) a TOMLDecodeError located in the original text."""
        p = self.i if pos is None else pos
        if p > self.n:
            p = self.n
        # Map a normalized index back to the caller's text: each CR removed
        # before p shifts the offset by one.
        orig = p + bisect.bisect_right(self.crlf_marks, p)
        return TOMLDecodeError(msg, self.doc, orig)

    def _err(self, msg, pos=None):
        raise self._error(msg, pos)

    # ------------------------------------------------------------------ flags

    def _set_flag(self, obj, bit):
        ent = self.flags.get(id(obj))
        if ent is None:
            # Keep a reference to obj so its id cannot be reused during parsing.
            self.flags[id(obj)] = [obj, bit]
        else:
            ent[1] |= bit

    def _flags_of(self, obj):
        ent = self.flags.get(id(obj))
        return ent[1] if ent is not None else 0

    # ------------------------------------------------------------- whitespace

    def _peek(self):
        return self.s[self.i] if self.i < self.n else ""

    def _ws(self):
        s, n, i = self.s, self.n, self.i
        while i < n and s[i] in " \t":
            i += 1
        self.i = i

    def _comment(self):
        s, n = self.s, self.n
        i = self.i + 1  # skip '#'
        while i < n and s[i] != "\n":
            if _is_control(s[i]):
                self._err("control character not allowed in comment", i)
            i += 1
        self.i = i

    def _wcn(self):
        """Skip whitespace, line feeds and comments (inside arrays and inline tables)."""
        while True:
            self._ws()
            c = self._peek()
            if c == "\n":
                self.i += 1
            elif c == "#":
                self._comment()
            else:
                return

    # ------------------------------------------------------------------- keys

    def _simple_key(self):
        c = self._peek()
        if c == '"':
            if self.s.startswith('"""', self.i):
                self._err("a multiline string cannot be used as a key")
            return self._basic_single()
        if c == "'":
            if self.s.startswith("'''", self.i):
                self._err("a multiline string cannot be used as a key")
            return self._literal_single()
        m = _BARE_KEY_RE.match(self.s, self.i)
        if m is None:
            self._err("expected a key")
        self.i = m.end()
        return m.group(0)

    def _key(self):
        parts = [self._simple_key()]
        while True:
            save = self.i
            self._ws()
            if self._peek() == ".":
                self.i += 1
                self._ws()
                parts.append(self._simple_key())
            else:
                self.i = save
                return parts

    # ---------------------------------------------------------------- strings

    def _basic_single(self):
        s, n = self.s, self.n
        i = self.i + 1
        out = []
        while True:
            if i >= n:
                self._err("unterminated string", n)
            c = s[i]
            if c == '"':
                self.i = i + 1
                return "".join(out)
            if c == "\\":
                self.i = i + 1
                out.append(self._escape())
                i = self.i
                continue
            if c == "\n":
                self._err("unterminated string (a line feed ends a basic string)", i)
            if _is_control(c):
                self._err("control character not allowed in string", i)
            out.append(c)
            i += 1

    def _literal_single(self):
        s, n = self.s, self.n
        i = self.i + 1
        start = i
        while True:
            if i >= n:
                self._err("unterminated string", n)
            c = s[i]
            if c == "'":
                self.i = i + 1
                return s[start:i]
            if c == "\n":
                self._err("unterminated string (a line feed ends a literal string)", i)
            if _is_control(c):
                self._err("control character not allowed in string", i)
            i += 1

    def _escape(self):
        """Decode one escape; self.i is just past the backslash."""
        c = self._peek()
        if c in _SIMPLE_ESCAPES:
            self.i += 1
            return _SIMPLE_ESCAPES[c]
        width = _ESCAPE_WIDTHS.get(c)
        if width is not None:
            digits = self.s[self.i + 1:self.i + 1 + width]
            if len(digits) != width or any(d not in _HEXDIGITS for d in digits):
                self._err("invalid unicode escape")
            cp = int(digits, 16)
            if cp > 0x10FFFF or 0xD800 <= cp <= 0xDFFF:
                self._err("escape does not denote a Unicode scalar value")
            self.i += 1 + width
            return chr(cp)
        self._err("invalid escape sequence")

    def _multiline(self, quote, escapes):
        """Multiline basic (quote '"', escapes True) or literal (quote "'") string."""
        s, n = self.s, self.n
        i = self.i + 3
        if i < n and s[i] == "\n":
            i += 1  # a line feed right after the opening delimiter is dropped
        out = []
        while True:
            if i >= n:
                self._err("unterminated multiline string", n)
            c = s[i]
            if c == quote:
                run = 1
                while i + run < n and s[i + run] == quote:
                    run += 1
                if run >= 3:
                    if run > 5:
                        self._err("too many quotation marks before end of string", i)
                    # Up to two quotes may sit directly before the closing delimiter.
                    out.append(quote * (run - 3))
                    self.i = i + run
                    return "".join(out)
                out.append(quote * run)
                i += run
            elif c == "\\" and escapes:
                j = i + 1
                while j < n and s[j] in " \t":
                    j += 1
                if j < n and s[j] == "\n":
                    # Line-ending backslash: drop the line ending and all
                    # whitespace (including line feeds) up to the next
                    # non-whitespace character or the closing delimiter.
                    j += 1
                    while j < n and s[j] in " \t\n":
                        j += 1
                    i = j
                else:
                    self.i = i + 1
                    out.append(self._escape())
                    i = self.i
            elif c == "\n":
                out.append(c)
                i += 1
            elif _is_control(c):
                self._err("control character not allowed in multiline string", i)
            else:
                out.append(c)
                i += 1

    # ----------------------------------------------------------------- values

    def _value(self):
        s, i = self.s, self.i
        c = self._peek()
        if c == '"':
            if s.startswith('"""', i):
                return self._multiline('"', True)
            return self._basic_single()
        if c == "'":
            if s.startswith("'''", i):
                return self._multiline("'", False)
            return self._literal_single()
        if c == "[":
            return self._array()
        if c == "{":
            return self._inline_table()
        if s.startswith("true", i):
            self.i = i + 4
            return True
        if s.startswith("false", i):
            self.i = i + 5
            return False
        return self._scalar()

    def _scalar(self):
        s, i = self.s, self.i
        m = _DT_RE.match(s, i)
        if m is not None:
            self.i = m.end()
            return self._datetime(m, i)
        m = _TIME_RE.match(s, i)
        if m is not None:
            self.i = m.end()
            return self._local_time(m, i)
        m = _SPECIAL_FLOAT_RE.match(s, i)
        if m is not None:
            self.i = m.end()
            return self._float(m.group(0))
        for pattern, base in ((_HEX_RE, 16), (_OCT_RE, 8), (_BIN_RE, 2)):
            m = pattern.match(s, i)
            if m is not None:
                self.i = m.end()
                return self._int(m.group(0), base, i)
        m = _FLOAT_RE.match(s, i)
        if m is not None:
            self.i = m.end()
            return self._float(m.group(0))
        m = _INT_RE.match(s, i)
        if m is not None:
            self.i = m.end()
            return self._int(m.group(0), 10, i)
        self._err("expected a value")

    def _int(self, text, base, start):
        try:
            return int(text.replace("_", ""), base)
        except ValueError:
            # Python refuses very long decimal strings; report it as a decode error.
            self._err("integer is too large to represent", start)

    def _float(self, text):
        # The converter receives the characters exactly as written.
        value = self.parse_float(text)
        if isinstance(value, (dict, list)):
            raise ValueError(
                "parse_float returned a %s; a float converter must not return a "
                "dict or list" % type(value).__name__)
        return value

    def _time_fields(self, hh, mi, ss, start):
        if int(hh) > 23 or int(mi) > 59:
            self._err("time is out of range", start)
        sec = 0 if ss is None else int(ss)
        if sec > 59:
            self._err("time is out of range", start)
        return int(hh), int(mi), sec

    def _datetime(self, m, start):
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        try:
            day = _dt.date(y, mo, d)
        except ValueError:
            self._err("date is not a valid calendar date", start)
        if m.group(4) is None:
            return day
        hh, mi, sec = self._time_fields(m.group(4), m.group(5), m.group(6), start)
        t = _dt.time(hh, mi, sec, _micro(m.group(7)))
        offset = m.group(8)
        if offset is None:
            return _dt.datetime.combine(day, t)
        if offset in ("Z", "z"):
            tz = _dt.timezone.utc
        else:
            oh, om = int(offset[1:3]), int(offset[4:6])
            if oh > 23 or om > 59:
                self._err("UTC offset is out of range", start)
            sign = -1 if offset[0] == "-" else 1
            tz = _dt.timezone(sign * _dt.timedelta(hours=oh, minutes=om))
        return _dt.datetime.combine(day, t, tzinfo=tz)

    def _local_time(self, m, start):
        hh, mi, sec = self._time_fields(m.group(1), m.group(2), m.group(3), start)
        return _dt.time(hh, mi, sec, _micro(m.group(4)))

    def _array(self):
        arr = []
        self.i += 1  # '['
        self._wcn()
        if self._peek() == "]":
            self.i += 1
            return arr
        while True:
            arr.append(self._value())
            self._wcn()
            c = self._peek()
            if c == ",":
                self.i += 1
                self._wcn()
                if self._peek() == "]":  # trailing comma
                    self.i += 1
                    return arr
            elif c == "]":
                self.i += 1
                return arr
            else:
                self._err("expected ',' or ']' in array")

    def _inline_table(self):
        table = {}
        self._set_flag(table, _INLINE)
        self.i += 1  # '{'
        self._wcn()
        if self._peek() == "}":
            self.i += 1
            return table
        while True:
            self._keyval(table)
            self._wcn()
            c = self._peek()
            if c == ",":
                self.i += 1
                self._wcn()
                if self._peek() == "}":  # trailing comma
                    self.i += 1
                    return table
            elif c == "}":
                self.i += 1
                return table
            else:
                self._err("expected ',' or '}' in inline table")

    # ------------------------------------------------------------- key-values

    def _keyval(self, table):
        key_pos = self.i
        parts = self._key()
        self._ws()
        if self._peek() != "=":
            self._err("expected '=' after key")
        self.i += 1
        self._ws()
        value = self._value()
        self._insert(table, parts, value, key_pos)

    def _insert(self, table, parts, value, key_pos):
        """Store value under the dotted key parts inside table."""
        cur = table
        for k in parts[:-1]:
            if k not in cur:
                nxt = {}
                self._set_flag(nxt, _DOTTED)
                cur[k] = nxt
            else:
                nxt = cur[k]
                if not (isinstance(nxt, dict) and self._flags_of(nxt) & _DOTTED):
                    raise self._error(
                        "dotted key cannot extend a table that was not created by dotted keys",
                        key_pos)
            cur = nxt
        last = parts[-1]
        if last in cur:
            raise self._error("duplicate key '%s'" % last, key_pos)
        cur[last] = value

    # ----------------------------------------------------------------- headers

    def _header(self, root):
        if self.s.startswith("[[", self.i):
            aot = True
            self.i += 2
        else:
            aot = False
            self.i += 1
        self._ws()
        key_pos = self.i
        parts = self._key()
        self._ws()
        if aot:
            if not self.s.startswith("]]", self.i):
                self._err("expected ']]' to close array of tables header")
            self.i += 2
        else:
            if self._peek() != "]":
                self._err("expected ']' to close table header")
            self.i += 1
        return self._open_table(root, parts, aot, key_pos)

    def _open_table(self, root, parts, aot, key_pos):
        """Walk or create the table named by a header; return the table to fill.

        # spec: N-000096 N-000097 N-000098 N-000099 N-000100 N-000101 N-000102
        # spec: N-000113 N-000114 N-000115 N-000116 N-000117 N-000118 N-000119
        """
        cur = root
        for k in parts[:-1]:
            if k not in cur:
                nxt = {}
                cur[k] = nxt  # implicit super-table: no flags
            else:
                nxt = cur[k]
                if isinstance(nxt, list) and (self._flags_of(nxt) & _AOT):
                    nxt = nxt[-1]
                elif isinstance(nxt, dict) and not (self._flags_of(nxt) & _INLINE):
                    pass
                else:
                    raise self._error(
                        "table header path runs through a value that cannot be extended",
                        key_pos)
            cur = nxt

        last = parts[-1]
        if aot:
            if last not in cur:
                elem = {}
                self._set_flag(elem, _HEADER)
                arr = [elem]
                self._set_flag(arr, _AOT)
                cur[last] = arr
                return elem
            arr = cur[last]
            if isinstance(arr, list) and (self._flags_of(arr) & _AOT):
                elem = {}
                self._set_flag(elem, _HEADER)
                arr.append(elem)
                return elem
            raise self._error("'%s' is already defined as a table or value" % last, key_pos)

        if last not in cur:
            tbl = {}
            self._set_flag(tbl, _HEADER)
            cur[last] = tbl
            return tbl
        tbl = cur[last]
        # An implicit super-table (no flags) may be defined now by its own header.
        if isinstance(tbl, dict) and not (self._flags_of(tbl) & (_HEADER | _DOTTED | _INLINE)):
            self._set_flag(tbl, _HEADER)
            return tbl
        raise self._error("table '%s' is already defined" % last, key_pos)

    # ---------------------------------------------------------------- document

    def parse(self):
        root = {}
        cur = root
        s = self.s
        while True:
            self._ws()
            if self.i >= self.n:
                break
            c = s[self.i]
            if c == "\n":
                self.i += 1
                continue
            if c == "#":
                self._comment()
                continue
            if c == "[":
                cur = self._header(root)
            else:
                self._keyval(cur)
            self._ws()
            if self._peek() == "#":
                self._comment()
            c = self._peek()
            if c != "" and c != "\n":
                self._err("expected end of line after key/value pair or table header")
        return root


def loads(s, *, parse_float=float):
    """Parse a TOML v1.1.0 document from a string and return a dict.

    ``parse_float`` is called with each float's characters as written; its
    return value is stored in place of the float. It must not return a dict or
    a list (a ValueError is raised if it does).

    # spec: N-000274 N-000275 N-000276 N-000277 N-000278 N-000279 N-000280
    # spec: N-000281 N-000282 N-000283 N-000284 N-000285 N-000286 N-000287
    # spec: N-000288 N-000289 N-000290 N-000291 N-000292 N-000293 N-000294
    # spec: N-000295 N-000296 N-000297 N-000298 N-000213 N-000214 N-000215
    # spec: N-000266 N-000267 N-000270 N-000271 N-000220 N-000223 N-000232 N-000233
    """
    if not isinstance(s, str):
        raise TypeError("loads() expects a str, not %s" % type(s).__name__)
    normalized, crlf_marks = _normalize(s)
    parser = _Parser(normalized, s, parse_float, crlf_marks)
    try:
        return parser.parse()
    except RecursionError:
        # Deeply nested input exhausts Python's stack. Report it as a decode error
        # rather than letting RecursionError escape.
        raise parser._error("document is nested too deeply") from None


def load(fp, *, parse_float=float):
    """Parse a TOML v1.1.0 document from a binary file object and return a dict.

    The bytes are decoded as UTF-8 and then parsed exactly like ``loads``.
    Text-mode file objects are refused with TypeError.

    # spec: N-000299 N-000300 N-000301 N-000302 N-000303 N-000304 N-000305 N-000306
    # spec: N-000181 N-000182 N-000183 N-000184 N-000187 N-000188 N-000189 N-000190
    # spec: N-000193 N-000194 N-000195 N-000196 N-000197 N-000216
    """
    if isinstance(fp, io.TextIOBase):
        raise TypeError("load() needs a file opened in binary mode, not text mode")
    read = getattr(fp, "read", None)
    if read is None:
        raise TypeError("load() expects a binary file object with a read() method")
    data = read()
    if not isinstance(data, (bytes, bytearray, memoryview)):
        raise TypeError("load() expects a binary file object; read() returned %s"
                        % type(data).__name__)
    text = bytes(data).decode("utf-8")
    return loads(text, parse_float=parse_float)
