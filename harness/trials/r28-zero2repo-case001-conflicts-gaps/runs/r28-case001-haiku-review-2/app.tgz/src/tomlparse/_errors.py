"""The decode-error type raised for invalid TOML documents."""


class TOMLDecodeError(ValueError):
    """Raised when a document is not valid TOML v1.1.0.

    Constructed as ``TOMLDecodeError(msg, doc, pos)``. ``pos`` is a 0-based
    character offset into ``doc``; ``lineno`` and ``colno`` are 1-based and
    derived from it.
    """

    def __init__(self, msg, doc, pos):
        ValueError.__init__(self, msg, doc, pos)
        self.msg = msg
        self.doc = doc
        self.pos = pos
        self.lineno = doc.count("\n", 0, pos) + 1
        self.colno = pos - doc.rfind("\n", 0, pos)

    def __str__(self):
        if self.pos >= len(self.doc):
            return "%s (at end of document)" % (self.msg,)
        return "%s (at line %d, column %d)" % (self.msg, self.lineno, self.colno)
