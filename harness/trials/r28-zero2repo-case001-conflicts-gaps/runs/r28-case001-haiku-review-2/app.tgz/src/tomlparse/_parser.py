"""A TOML v1.1.0 parser written from the specification.

The parser works directly on the document text. Table structure is tracked
with a side table (``_Parser.state``) keyed by ``id()`` of each container; every
container is referenced from the result tree, so the ids stay valid for the
whole parse.
"""

import datetime as _dt
import io
import re

from ._errors import TOMLDecodeError

__all__ = ["loads", "load"]

# --- token patterns -------------------------------------------------------

_BARE_KEY_RE = re.compile(r"[A-Za-z0-9_-]+")
# Runs of ordinary characters in strings: anything except the quote, the
# backslash, line feed / carriage return, other C0 controls, DEL and surrogates.
_BASIC_CHUNK = re.compile(r'[^"\\\x00-\x08\x0a-\x1f\x7f\ud800-\udfff]+')
_LIT_CHUNK = re.compile(r"[^'\x00-\x08\x0a-\x1f\x7f\ud800-\udfff]+")
_DT_RE = re.compile(
    r"([0-9]{4})-([0-9]{2})-([0-9]{2})"
    r"(?:[Tt ]([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?"
    r"(?:([Zz])|([+-])([0-9]{2}):([0-9]{2}))?)?"
)
_LT_RE = re.compile(r"([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?")
_SPECIAL_FLOAT_RE = re.compile(r"[+-]?(?:inf|nan)")
_NONDEC_INT_RE = re.compile(
    r"0x[0-9a-fA-F](?:_?[0-9a-fA-F])*"
    r"|0o[0-7](?:_?[0-7])*"
    r"|0b[01](?:_?[01])*"
)
_FLOAT_RE = re.compile(
    r"[+-]?(?:0|[1-9](?:_?[0-9])*)"
    r"(?:\.[0-9](?:_?[0-9])*(?:[eE][+-]?[0-9](?:_?[0-9])*)?"
    r"|[eE][+-]?[0-9](?:_?[0-9])*)"
)
_DEC_INT_RE = re.compile(r"[+-]?(?:0|[1-9](?:_?[0-9])*)")

_SIMPLE_ESCAPES = {
    "b": "\b",
    "t": "\t",
    "n": "\n",
    "f": "\f",
    "r": "\r",
    "e": "\x1b",
    '"': '"',
    "\\": "\\",
}
_UNICODE_ESCAPE_WIDTH = {"x": 2, "u": 4, "U": 8}
_HEXDIGITS = frozenset("0123456789abcdefABCDEF")
_NONDEC_BASES = {"x": 16, "o": 8, "b": 2}

_ROOT = "root"
_IMPLICIT = "implicit"  # table created as the parent of a header
_HEADER = "header"      # table defined by [header] or an array-of-tables element
_DOTTED = "dotted"      # table created or extended by dotted keys
_INLINE = "inline"      # inline table; frozen once written
_STATIC = "static"      # array written with [ ]
_AOT = "aot"            # array of tables


class _Parser:
    def __init__(self, text, parse_float):
        self.s = text
        self.n = len(text)
        self.pos = 0
        self.root = {}
        self.current = self.root
        self.state = {id(self.root): _ROOT}
        self.parse_float = parse_float

    # --- helpers ----------------------------------------------------------

    def _error(self, msg, pos=None):
        if pos is None:
            pos = self.pos
        raise TOMLDecodeError(msg, self.s, pos)

    def _skip_ws(self):
        s, n = self.s, self.n
        p = self.pos
        while p < n and s[p] in " \t":
            p += 1
        self.pos = p

    def _newline(self):
        s, p = self.s, self.pos
        if s[p] == "\n":
            self.pos = p + 1
        elif s.startswith("\r\n", p):
            self.pos = p + 2
        else:
            self._error("bare carriage return is not allowed", p)

    def _comment(self):
        s, n = self.s, self.n
        p = self.pos + 1
        while p < n:
            c = s[p]
            if c == "\n":
                break
            if c == "\r":
                if s.startswith("\r\n", p):
                    break
                self._error("carriage return must be followed by line feed", p)
            if (c < " " and c != "\t") or c == "\x7f" or "\ud800" <= c <= "\udfff":
                self._error("control character not allowed in comment", p)
            p += 1
        self.pos = p

    def _skip_blank(self):
        """Skip spaces, tabs, line breaks and comments (inside arrays and inline tables)."""
        s, n = self.s, self.n
        while True:
            p = self.pos
            if p >= n:
                return
            c = s[p]
            if c in " \t":
                self.pos = p + 1
            elif c == "\n" or c == "\r":
                self._newline()
            elif c == "#":
                self._comment()
            else:
                return

    def _end_of_line(self):
        self._skip_ws()
        if self.pos < self.n and self.s[self.pos] == "#":
            self._comment()
        if self.pos >= self.n:
            return
        if self.s[self.pos] in "\r\n":
            self._newline()
            return
        self._error("expected end of line")

    def _state(self, obj):
        return self.state.get(id(obj))

    # --- document ---------------------------------------------------------

    def parse(self):
        s, n = self.s, self.n
        while True:
            self._skip_ws()
            if self.pos >= n:
                break
            c = s[self.pos]
            if c == "\n" or c == "\r":
                self._newline()
                continue
            if c == "#":
                self._comment()
                continue
            if c == "[":
                self._header()
            else:
                self._keyval(self.current)
            self._end_of_line()
        return self.root

    # --- keys -------------------------------------------------------------

    def _key(self):
        """Parse a (possibly dotted) key; returns the list of its parts."""
        parts = []
        while True:
            self._skip_ws()
            parts.append(self._simple_key())
            self._skip_ws()
            if self.pos < self.n and self.s[self.pos] == ".":
                self.pos += 1
                continue
            return parts

    def _simple_key(self):
        s, p = self.s, self.pos
        if p < self.n and s[p] == '"':
            return self._basic()
        if p < self.n and s[p] == "'":
            return self._literal()
        m = _BARE_KEY_RE.match(s, p)
        if m is None:
            self._error("expected a key")
        self.pos = m.end()
        return m.group()

    def _keyval(self, table):
        start = self.pos
        keys = self._key()
        self._skip_ws()
        if self.pos >= self.n or self.s[self.pos] != "=":
            self._error("expected '=' after key")
        self.pos += 1
        self._skip_ws()
        value = self._value()
        self._insert(table, keys, value, start)

    def _insert(self, table, keys, value, start):
        """Store ``value`` under the dotted ``keys`` of ``table``, enforcing TOML's rules."""
        cur = table
        for k in keys[:-1]:
            if k not in cur:
                d = {}
                cur[k] = d
                self.state[id(d)] = _DOTTED
                cur = d
                continue
            v = cur[k]
            if isinstance(v, dict):
                st = self._state(v)
                if st == _INLINE:
                    self._error("cannot add keys to an inline table", start)
                if st == _HEADER:
                    self._error("dotted key cannot extend a table defined by a header", start)
                if st == _IMPLICIT:
                    self.state[id(v)] = _DOTTED
                cur = v
            elif isinstance(v, list) and self._state(v) == _AOT:
                self._error("dotted key cannot extend an array of tables", start)
            else:
                self._error("dotted key walks through a non-table value", start)
        last = keys[-1]
        if last in cur:
            self._error("duplicate key %r" % (last,), start)
        cur[last] = value

    # --- table headers ----------------------------------------------------

    def _header(self):
        s = self.s
        start = self.pos
        is_aot = s.startswith("[[", start)
        self.pos = start + (2 if is_aot else 1)
        self._skip_ws()
        keys = self._key()
        self._skip_ws()
        close = "]]" if is_aot else "]"
        if not s.startswith(close, self.pos):
            self._error("expected %r to close table header" % (close,))
        self.pos += len(close)
        self._define_table(keys, is_aot, start)

    def _define_table(self, keys, is_aot, start):
        cur = self.root
        for k in keys[:-1]:
            if k not in cur:
                d = {}
                cur[k] = d
                self.state[id(d)] = _IMPLICIT
                cur = d
                continue
            v = cur[k]
            if isinstance(v, dict):
                if self._state(v) == _INLINE:
                    self._error("cannot extend an inline table", start)
                cur = v
            elif isinstance(v, list) and self._state(v) == _AOT:
                cur = v[-1]
            else:
                self._error("table header walks through a non-table value", start)

        last = keys[-1]
        if not is_aot:
            if last not in cur:
                d = {}
                cur[last] = d
                self.state[id(d)] = _HEADER
                self.current = d
                return
            v = cur[last]
            if isinstance(v, dict) and self._state(v) == _IMPLICIT:
                self.state[id(v)] = _HEADER
                self.current = v
                return
            self._error("table %r is already defined" % (last,), start)

        if last not in cur:
            lst = []
            cur[last] = lst
            self.state[id(lst)] = _AOT
        else:
            lst = cur[last]
            if not (isinstance(lst, list) and self._state(lst) == _AOT):
                self._error("%r is not an array of tables" % (last,), start)
        d = {}
        lst.append(d)
        self.state[id(d)] = _HEADER
        self.current = d

    # --- values -----------------------------------------------------------

    def _value(self):
        s, p = self.s, self.pos
        if p >= self.n:
            self._error("expected a value")
        c = s[p]
        if c == '"':
            if s.startswith('"""', p):
                return self._ml_basic()
            return self._basic()
        if c == "'":
            if s.startswith("'''", p):
                return self._ml_literal()
            return self._literal()
        if c == "[":
            return self._array()
        if c == "{":
            return self._inline()
        if s.startswith("true", p):
            self.pos = p + 4
            return True
        if s.startswith("false", p):
            self.pos = p + 5
            return False

        m = _DT_RE.match(s, p)
        if m is not None:
            return self._datetime(m)
        m = _LT_RE.match(s, p)
        if m is not None:
            return self._localtime(m)
        m = _SPECIAL_FLOAT_RE.match(s, p)
        if m is not None:
            self.pos = m.end()
            return self._float(m.group())
        m = _NONDEC_INT_RE.match(s, p)
        if m is not None:
            self.pos = m.end()
            text = m.group()
            return int(text[2:].replace("_", ""), _NONDEC_BASES[text[1]])
        m = _FLOAT_RE.match(s, p)
        if m is not None:
            self.pos = m.end()
            return self._float(m.group())
        m = _DEC_INT_RE.match(s, p)
        if m is not None:
            self.pos = m.end()
            return int(m.group().replace("_", ""))
        self._error("invalid value")

    def _float(self, text):
        if self.parse_float is float:
            value = float(text.replace("_", ""))
        else:
            value = self.parse_float(text)
        if isinstance(value, (dict, list)):
            raise ValueError(
                "parse_float returned a %s, which is not allowed" % (type(value).__name__,)
            )
        return value

    @staticmethod
    def _fraction_micro(frac):
        return int(frac[:6].ljust(6, "0")) if frac else 0

    def _check_time(self, hour, minute, second, p):
        if int(hour) > 23 or int(minute) > 59 or (second is not None and int(second) > 59):
            self._error("time value out of range", p)

    def _datetime(self, m):
        y, mo, d, hh, mi, ss, frac, z, sign, oh, om = m.groups()
        p = m.start()
        try:
            date = _dt.date(int(y), int(mo), int(d))
        except ValueError:
            self._error("invalid date", p)
        if hh is None:
            self.pos = m.end()
            return date
        self._check_time(hh, mi, ss, p)
        tz = None
        if z is not None:
            tz = _dt.timezone.utc
        elif sign is not None:
            if int(oh) > 23 or int(om) > 59:
                self._error("UTC offset out of range", p)
            delta = _dt.timedelta(hours=int(oh), minutes=int(om))
            tz = _dt.timezone(-delta if sign == "-" else delta)
        try:
            value = _dt.datetime(
                date.year, date.month, date.day,
                int(hh), int(mi), int(ss or 0), self._fraction_micro(frac),
                tzinfo=tz,
            )
        except ValueError:
            self._error("invalid date-time", p)
        self.pos = m.end()
        return value

    def _localtime(self, m):
        hh, mi, ss, frac = m.groups()
        self._check_time(hh, mi, ss, m.start())
        self.pos = m.end()
        return _dt.time(int(hh), int(mi), int(ss or 0), self._fraction_micro(frac))

    # --- strings ----------------------------------------------------------

    def _escape(self, p):
        """Decode the escape starting at the backslash at ``p``; returns (text, next position)."""
        s = self.s
        if p + 1 >= self.n:
            self._error("unterminated escape sequence", p)
        c = s[p + 1]
        simple = _SIMPLE_ESCAPES.get(c)
        if simple is not None:
            return simple, p + 2
        width = _UNICODE_ESCAPE_WIDTH.get(c)
        if width is not None:
            digits = s[p + 2:p + 2 + width]
            if len(digits) == width and all(ch in _HEXDIGITS for ch in digits):
                cp = int(digits, 16)
                if cp <= 0x10FFFF and not (0xD800 <= cp <= 0xDFFF):
                    return chr(cp), p + 2 + width
            self._error("invalid unicode escape", p)
        self._error("invalid escape sequence", p)

    def _basic(self):
        s, n = self.s, self.n
        p = self.pos + 1
        parts = []
        while True:
            m = _BASIC_CHUNK.match(s, p)
            if m is not None:
                parts.append(m.group())
                p = m.end()
            if p >= n:
                self._error("unterminated string", p)
            c = s[p]
            if c == '"':
                self.pos = p + 1
                return "".join(parts)
            if c == "\\":
                text, p = self._escape(p)
                parts.append(text)
                continue
            self._error("invalid character in single-line string", p)

    def _literal(self):
        s, n = self.s, self.n
        p = self.pos + 1
        parts = []
        while True:
            m = _LIT_CHUNK.match(s, p)
            if m is not None:
                parts.append(m.group())
                p = m.end()
            if p >= n:
                self._error("unterminated string", p)
            c = s[p]
            if c == "'":
                self.pos = p + 1
                return "".join(parts)
            self._error("invalid character in single-line string", p)

    def _multiline_start(self, p):
        """Skip the opening delimiter's immediately following line ending, if any."""
        s = self.s
        if s.startswith("\n", p):
            return p + 1
        if s.startswith("\r\n", p):
            return p + 2
        return p

    def _ml_basic(self):
        s, n = self.s, self.n
        p = self._multiline_start(self.pos + 3)
        parts = []
        while True:
            m = _BASIC_CHUNK.match(s, p)
            if m is not None:
                parts.append(m.group())
                p = m.end()
            if p >= n:
                self._error("unterminated multi-line string", p)
            c = s[p]
            if c == '"':
                q = p
                while q < n and s[q] == '"':
                    q += 1
                run = q - p
                if run < 3:
                    parts.append('"' * run)
                    p = q
                    continue
                if run > 5:
                    self._error("too many quotation marks before closing delimiter", p)
                parts.append('"' * (run - 3))
                self.pos = q
                return "".join(parts)
            if c == "\\":
                j = p + 1
                while j < n and s[j] in " \t":
                    j += 1
                if j < n and (s[j] == "\n" or s.startswith("\r\n", j)):
                    # Line-ending backslash: drop it and all following whitespace.
                    p = j
                    while p < n:
                        ch = s[p]
                        if ch in " \t\n":
                            p += 1
                        elif s.startswith("\r\n", p):
                            p += 2
                        else:
                            break
                    continue
                text, p = self._escape(p)
                parts.append(text)
                continue
            if c == "\n":
                parts.append("\n")
                p += 1
                continue
            if c == "\r" and s.startswith("\r\n", p):
                parts.append("\n")
                p += 2
                continue
            self._error("invalid character in multi-line string", p)

    def _ml_literal(self):
        s, n = self.s, self.n
        p = self._multiline_start(self.pos + 3)
        parts = []
        while True:
            m = _LIT_CHUNK.match(s, p)
            if m is not None:
                parts.append(m.group())
                p = m.end()
            if p >= n:
                self._error("unterminated multi-line string", p)
            c = s[p]
            if c == "'":
                q = p
                while q < n and s[q] == "'":
                    q += 1
                run = q - p
                if run < 3:
                    parts.append("'" * run)
                    p = q
                    continue
                if run > 5:
                    self._error("too many apostrophes before closing delimiter", p)
                parts.append("'" * (run - 3))
                self.pos = q
                return "".join(parts)
            if c == "\n":
                parts.append("\n")
                p += 1
                continue
            if c == "\r" and s.startswith("\r\n", p):
                parts.append("\n")
                p += 2
                continue
            self._error("invalid character in multi-line string", p)

    # --- arrays and inline tables ----------------------------------------

    def _array(self):
        s, n = self.s, self.n
        lst = []
        self.state[id(lst)] = _STATIC
        self.pos += 1
        while True:
            self._skip_blank()
            if self.pos >= n:
                self._error("unterminated array")
            if s[self.pos] == "]":
                self.pos += 1
                return lst
            lst.append(self._value())
            self._skip_blank()
            if self.pos >= n:
                self._error("unterminated array")
            c = s[self.pos]
            if c == ",":
                self.pos += 1
            elif c == "]":
                self.pos += 1
                return lst
            else:
                self._error("expected ',' or ']' in array")

    def _inline(self):
        s, n = self.s, self.n
        table = {}
        self.state[id(table)] = _INLINE
        self.pos += 1
        self._skip_blank()
        if self.pos < n and s[self.pos] == "}":
            self.pos += 1
            return table
        while True:
            start = self.pos
            keys = self._key()
            self._skip_ws()
            if self.pos >= n or s[self.pos] != "=":
                self._error("expected '=' after key")
            self.pos += 1
            self._skip_ws()
            value = self._value()
            self._insert(table, keys, value, start)
            self._skip_blank()
            if self.pos >= n:
                self._error("unterminated inline table")
            c = s[self.pos]
            if c == ",":
                self.pos += 1
                self._skip_blank()
                if self.pos < n and s[self.pos] == "}":
                    self.pos += 1
                    return table
            elif c == "}":
                self.pos += 1
                return table
            else:
                self._error("expected ',' or '}' in inline table")


def loads(s, *, parse_float=float):
    """Parse a TOML v1.1.0 document from a text string into a dict."""
    if not isinstance(s, str):
        raise TypeError("loads() argument must be str, not %s" % (type(s).__name__,))
    return _Parser(s, parse_float).parse()


def load(fp, *, parse_float=float):
    """Parse a TOML v1.1.0 document from a file object opened for binary reading."""
    if isinstance(fp, io.TextIOBase):
        raise TypeError("load() needs a binary file object, not a text-mode file")
    read = getattr(fp, "read", None)
    if read is None:
        raise TypeError("load() argument must be a binary file object, not %s" % (type(fp).__name__,))
    data = read()
    if not isinstance(data, (bytes, bytearray, memoryview)):
        raise TypeError("load() needs a binary file object; read() returned %s" % (type(data).__name__,))
    return loads(bytes(data).decode("utf-8"), parse_float=parse_float)
