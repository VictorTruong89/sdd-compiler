"""Tomlparse: a pure-Python TOML v1.1.0 parser.

Public names: ``loads``, ``load`` and ``TOMLDecodeError``.
"""

from ._errors import TOMLDecodeError
from ._parser import load, loads

__all__ = ["loads", "load", "TOMLDecodeError"]
__version__ = "2.4.0"
