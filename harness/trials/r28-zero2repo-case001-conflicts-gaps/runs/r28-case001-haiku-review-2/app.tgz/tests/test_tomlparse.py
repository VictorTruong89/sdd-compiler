import datetime as dt
import io
import unittest

import tomlparse
from tomlparse import TOMLDecodeError, load, loads


class Valid(unittest.TestCase):
    def test_empty_and_comments(self):
        self.assertEqual(loads(""), {})
        self.assertEqual(loads("   \t  "), {})
        self.assertEqual(loads("# only a comment"), {})
        self.assertEqual(loads("# c\n# d\n"), {})

    def test_keys(self):
        self.assertEqual(loads('1 = 2\ntrue = 3\ninf = 4\nnan = 5'),
                         {"1": 2, "true": 3, "inf": 4, "nan": 5})
        self.assertEqual(loads('"a.b" = 1\n\'c d\' = 2\n"" = 3'),
                         {"a.b": 1, "c d": 2, "": 3})
        self.assertEqual(loads('"\\u00e9" = 1\n\'\\u00e9\' = 2'),
                         {"\u00e9": 1, "\\u00e9": 2})
        self.assertEqual(loads('Key = 1\nkey = 2'), {"Key": 1, "key": 2})

    def test_dotted_keys_and_whitespace(self):
        self.assertEqual(loads('a . b . "c.d" = 1'), {"a": {"b": {"c.d": 1}}})

    def test_tables_and_super_tables(self):
        self.assertEqual(loads("[a.b.c]\nx = 1\n[a]\ny = 2"),
                         {"a": {"b": {"c": {"x": 1}}, "y": 2}})

    def test_dotted_then_subtable_header(self):
        self.assertEqual(loads("[fruit]\napple.color = 'red'\n[fruit.apple.texture]\nsmooth = true"),
                         {"fruit": {"apple": {"color": "red", "texture": {"smooth": True}}}})

    def test_array_of_tables(self):
        doc = "[[p]]\nn=1\n[p.sub]\nv=1\n[[p]]\nn=2\n[[p.sub2]]\nq=3\n"
        self.assertEqual(loads(doc), {"p": [
            {"n": 1, "sub": {"v": 1}},
            {"n": 2, "sub2": [{"q": 3}]},
        ]})

    def test_implicit_parent_of_aot_declared_later(self):
        self.assertEqual(loads("[[a.b]]\nx=1\n[a]\ny=2"),
                         {"a": {"b": [{"x": 1}], "y": 2}})

    def test_inline_tables(self):
        self.assertEqual(loads("a = {}"), {"a": {}})
        self.assertEqual(loads("a = {x.y = 1, z = 2}"), {"a": {"x": {"y": 1}, "z": 2}})
        self.assertEqual(loads("a = {\n  x = 1, # c\n  y = 2,\n}"), {"a": {"x": 1, "y": 2}})

    def test_arrays(self):
        self.assertEqual(loads("a = []"), {"a": []})
        self.assertEqual(loads("a = [1, 'x', [2,3],]"), {"a": [1, "x", [2, 3]]})
        self.assertEqual(loads("a = [\n  1, # one\n  2,\n]"), {"a": [1, 2]})
        self.assertEqual(loads("a = [ [], [ ] ]"), {"a": [[], []]})

    def test_booleans(self):
        r = loads("a = true\nb = false")
        self.assertIs(r["a"], True)
        self.assertIs(r["b"], False)

    def test_basic_strings_and_escapes(self):
        self.assertEqual(loads(r'a = "\b\t\n\f\r\e\"\\"')["a"], "\b\t\n\f\r\x1b\"\\")
        self.assertEqual(loads(r'a = "\x41\u00E9\U0001F600"')["a"], "A\u00e9\U0001F600")
        self.assertEqual(loads('a = "tab\there"')["a"], "tab\there")

    def test_literal_strings(self):
        self.assertEqual(loads(r"a = 'C:\path\n'")["a"], r"C:\path\n")

    def test_multiline_basic(self):
        self.assertEqual(loads('a = """\nx\ny"""')["a"], "x\ny")
        self.assertEqual(loads('a = """one \\\n     two"""')["a"], "one two")
        self.assertEqual(loads('a = """a\\\n\n  \t b"""')["a"], "ab")
        self.assertEqual(loads('a = """a""""')["a"], 'a"')
        self.assertEqual(loads('a = """a"""""')["a"], 'a""')
        self.assertEqual(loads('a = """ "x" "" """')["a"], ' "x" "" ')
        self.assertEqual(loads('a = """\\""""')["a"], '"')

    def test_multiline_literal(self):
        self.assertEqual(loads("a = '''\nx\\n'''")["a"], "x\\n")
        self.assertEqual(loads("a = '''it's'''")["a"], "it's")
        self.assertEqual(loads("a = ''''x'''")["a"], "'x")

    def test_crlf_normalised(self):
        doc = 'a = """x\r\ny"""\r\nb = 1\r\n'
        self.assertEqual(loads(doc), {"a": "x\ny", "b": 1})
        self.assertEqual(loads("a = 1 # c\r\nb = 2"), {"a": 1, "b": 2})

    def test_integers(self):
        self.assertEqual(loads("a = 1_000\nb = +99\nc = -17\nd = 0\ne = -0\nf = +0"),
                         {"a": 1000, "b": 99, "c": -17, "d": 0, "e": 0, "f": 0})
        self.assertEqual(loads("a = 0xDEAD_beef\nb = 0o755\nc = 0b1101"),
                         {"a": 0xDEADBEEF, "b": 0o755, "c": 0b1101})
        self.assertIs(type(loads("a = 1")["a"]), int)

    def test_floats(self):
        r = loads("a = 3.14\nb = -1e3\nc = 6.626e-34\nd = 1_0.0_1\ne = +inf\nf = -inf\ng = nan\nh = -nan")
        self.assertEqual(r["a"], 3.14)
        self.assertEqual(r["b"], -1000.0)
        self.assertEqual(r["c"], 6.626e-34)
        self.assertEqual(r["d"], 10.01)
        self.assertEqual(r["e"], float("inf"))
        self.assertEqual(r["f"], float("-inf"))
        self.assertTrue(r["g"] != r["g"])
        self.assertTrue(r["h"] != r["h"])

    def test_datetimes(self):
        r = loads("a = 1979-05-27T07:32:00Z\nb = 1979-05-27 07:32:00-07:00\n"
                  "c = 1979-05-27T00:32:00.999999+01:30\nd = 1979-05-27T07:32Z\n"
                  "e = 1979-05-27T07:32:00\nf = 1979-05-27\ng = 07:32:00.5\nh = 07:32\n"
                  "i = 1979-05-27t07:32:00z\nj = 2024-02-29T00:00:00Z")
        self.assertEqual(r["a"], dt.datetime(1979, 5, 27, 7, 32, tzinfo=dt.timezone.utc))
        self.assertEqual(r["b"].utcoffset(), dt.timedelta(hours=-7))
        self.assertEqual(r["c"].microsecond, 999999)
        self.assertEqual(r["c"].utcoffset(), dt.timedelta(hours=1, minutes=30))
        self.assertEqual(r["d"].second, 0)
        self.assertIsNone(r["e"].tzinfo)
        self.assertEqual(r["e"], dt.datetime(1979, 5, 27, 7, 32))
        self.assertEqual(r["f"], dt.date(1979, 5, 27))
        self.assertEqual(r["g"], dt.time(7, 32, 0, 500000))
        self.assertIsNone(r["g"].tzinfo)
        self.assertEqual(r["h"], dt.time(7, 32))
        self.assertIsNotNone(r["i"].tzinfo)
        self.assertEqual(r["j"].day, 29)

    def test_fraction_truncated(self):
        self.assertEqual(loads("a = 07:00:00.1234567")["a"], dt.time(7, 0, 0, 123456))

    def test_load_binary(self):
        self.assertEqual(load(io.BytesIO("a = 'é'".encode("utf-8"))), {"a": "é"})
        self.assertEqual(load(io.BytesIO(b"")), {})

    def test_parse_float_converter(self):
        seen = []

        def conv(text):
            seen.append(text)
            return ("F", text)

        r = loads("a = 1.5\nb = 2\nc = [-1_0.0e1, inf]\n[t]\nd = {x = +nan}", parse_float=conv)
        self.assertEqual(r["a"], ("F", "1.5"))
        self.assertEqual(r["b"], 2)
        self.assertEqual(r["c"], [("F", "-1_0.0e1"), ("F", "inf")])
        self.assertEqual(r["t"]["d"]["x"], ("F", "+nan"))
        self.assertEqual(seen, ["1.5", "-1_0.0e1", "inf", "+nan"])

    def test_parse_float_result_as_dict_list_refused(self):
        with self.assertRaises(ValueError) as cm:
            loads("a = 1.0", parse_float=lambda t: {})
        self.assertNotIsInstance(cm.exception, TOMLDecodeError)
        with self.assertRaises(ValueError) as cm:
            loads("a = 1.0", parse_float=lambda t: [])
        self.assertNotIsInstance(cm.exception, TOMLDecodeError)

        class D(dict):
            pass

        with self.assertRaises(ValueError) as cm:
            loads("a = 1.0", parse_float=lambda t: D())
        self.assertNotIsInstance(cm.exception, TOMLDecodeError)


class Invalid(unittest.TestCase):
    def bad(self, doc):
        with self.assertRaises(TOMLDecodeError, msg=repr(doc)) as cm:
            loads(doc)
        self.assertIsInstance(cm.exception, ValueError)
        return cm.exception

    def test_duplicate_and_redefinition(self):
        self.bad("a = 1\na = 2")
        self.bad("[a]\n[a]")
        self.bad("[a]\nb = 1\n[a.b]")
        self.bad("a.b = 1\na.c = 2\n[a]")
        self.bad("[a]\nb.c = 1\n[a.b]")
        self.bad("a = 1\n[a]")
        self.bad("a = 1\n[a.b]")
        self.bad("[a.b]\n[a]\nb.c = 1")
        self.bad("[a.b.c]\nz = 9\n[a]\nb.c.t = 1")
        self.bad("[[a]]\n[a]")
        self.bad("[a]\n[[a]]")
        self.bad("a = [1]\n[[a]]")
        self.bad("a = []\n[a]")
        self.bad("a = []\n[a.b]")
        self.bad("[[a]]\nb = 1\nb = 2")

    def test_dotted_key_extends_aot_or_static(self):
        self.bad("[[a]]\n[a]\n")  # header over aot
        self.bad("a = [{x=1}]\nb = 1\na.c = 1")
        self.bad("[[t]]\nx = 1\n[t]")

    def test_inline_table_frozen(self):
        self.bad("a = {b = 1}\n[a.c]")
        self.bad("a = {}\n[a]")
        self.bad("a = {b = 1}\na.c = 2")
        self.bad("a = {b = 1}\na.b.c = 2")
        self.bad("a = {b = {}}\n[a.b]")

    def test_syntax(self):
        self.bad("= 1")
        self.bad("a =")
        self.bad("a = 1 b = 2")
        self.bad("a")
        self.bad("[a] b = 1")
        self.bad("[a")
        self.bad("[[a]")
        self.bad("[]")
        self.bad("a = [1 2]")
        self.bad("a = [,]")
        self.bad("a = [1,,2]")
        self.bad("a = {x=1,,}")
        self.bad("a = {x=1")
        self.bad("a = {,}")
        self.bad("a =\n1")
        self.bad("'''a''' = 1")
        self.bad('"""a""" = 1')
        self.bad("a = 'x")
        self.bad('a = "x')
        self.bad('a = "x\ny"')
        self.bad("a = 1 # c\x01")
        self.bad("a = \"\x7f\"")
        self.bad("a = 1\rb = 2")

    def test_scalars(self):
        self.bad("a = True")
        self.bad("a = TRUE")
        self.bad("a = 01")
        self.bad("a = 00")
        self.bad("a = 1.")
        self.bad("a = .5")
        self.bad("a = 1.e5")
        self.bad("a = 01.5")
        self.bad("a = 1__0")
        self.bad("a = 1_")
        self.bad("a = _1")
        self.bad("a = 0X1F")
        self.bad("a = 0xG")
        self.bad("a = +0x1")
        self.bad("a = -0o7")
        self.bad("a = 0b2")
        self.bad("a = 0x_1")
        self.bad("a = 0o8")
        self.bad("a = 1979-02-29")
        self.bad("a = 1979-02-29T00:00:00Z")
        self.bad("a = 25:00:00")
        self.bad("a = 07:60:00")
        self.bad("a = 07:00:60")
        self.bad("a = 1979-05-27T07:32:00+24:00")
        self.bad("a = 1979-05-27T07:32:00Z+")
        self.bad("a = 07:32Z")
        self.bad("a = infinity")
        self.bad("a = nanx")
        self.bad("a = \"\\x4\"")
        self.bad("a = \"\\X41\"")
        self.bad("a = \"\\u00\"")
        self.bad("a = \"\\uD800\"")
        self.bad("a = \"\\U00110000\"")
        self.bad("a = \"\\q\"")
        self.bad("a = \"\\ \"")
        self.bad('a = """x\\ y\n"""')
        self.bad('a = """x""""""')
        self.bad("a = '''x''''''")
        self.bad('a = """a\rb"""')

    def test_error_location(self):
        e = self.bad("a = 1\nb = 01")
        self.assertEqual((e.lineno, e.colno), (2, 6))
        self.assertEqual(e.pos, 11)
        self.assertEqual(e.doc, "a = 1\nb = 01")
        self.assertIn("line 2", str(e))
        e = self.bad("a = [")
        self.assertIn("end of document", str(e))

    def test_constructor_and_attributes(self):
        e = TOMLDecodeError("boom", "x\nyz", 3)
        self.assertEqual(e.msg, "boom")
        self.assertEqual(e.doc, "x\nyz")
        self.assertEqual(e.pos, 3)
        self.assertEqual((e.lineno, e.colno), (2, 2))
        self.assertIn("boom", str(e))
        self.assertIsInstance(e, ValueError)
        self.assertNotIsInstance(e, TypeError)
        self.assertNotIsInstance(e, RecursionError)

    def test_wrong_types(self):
        for bad in (b"a = 1", 1, True, io.BytesIO(b"a=1"), None):
            with self.assertRaises(TypeError):
                loads(bad)

    def test_load_wrong_types(self):
        with self.assertRaises(TypeError):
            load(io.StringIO("a = 1"))
        with self.assertRaises(TypeError):
            load(object())

    def test_load_invalid_toml_reports_text(self):
        try:
            load(io.BytesIO(b"a = 01"))
        except TOMLDecodeError as e:
            self.assertEqual(e.doc, "a = 01")
        else:
            self.fail("expected TOMLDecodeError")


class Package(unittest.TestCase):
    def test_exports(self):
        self.assertIs(tomlparse.loads, loads)
        self.assertIs(tomlparse.load, load)
        self.assertIs(tomlparse.TOMLDecodeError, TOMLDecodeError)


if __name__ == "__main__":
    unittest.main()
