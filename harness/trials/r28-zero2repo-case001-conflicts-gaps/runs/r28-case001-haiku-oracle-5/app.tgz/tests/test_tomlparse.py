"""Tests for tomlparse, organized by the specification's feature points (FP-01..FP-05)
and interface contract. Test names carry the FP / contract label they exercise.
"""

import datetime as dt
import io
import pickle

import pytest

import tomlparse
from tomlparse import TOMLDecodeError, load, loads


# ---------------------------------------------------------------- package surface

def test_public_surface_names():
    # spec: N-000270 N-000271 N-000272 N-000273
    assert set(tomlparse.__all__) == {"loads", "load", "TOMLDecodeError"}
    assert callable(loads) and callable(load)
    assert issubclass(TOMLDecodeError, ValueError)
    assert not issubclass(TOMLDecodeError, TypeError)
    assert not issubclass(TOMLDecodeError, RecursionError)


def test_no_writer_or_cli_surface():
    # spec: N-000032 N-000260 N-000063 N-000072 N-000075 N-000076
    for name in ("dump", "dumps", "dumpb", "encode", "main"):
        assert not hasattr(tomlparse, name)


def test_pure_python_no_stdlib_toml_delegation():
    # spec: N-000058 N-000060 N-000076 N-000262
    import pathlib

    src = pathlib.Path(tomlparse.__file__).parent
    for path in src.glob("*.py"):
        text = path.read_text(encoding="utf-8")
        assert "import tomllib" not in text
        assert "from tomllib" not in text
        assert "import toml\n" not in text


# ---------------------------------------------------------------- FP-01 structure

@pytest.mark.parametrize("text", ["", "   \t  ", "# only a comment", "# c\n\n  \n"])
def test_FP01_empty_and_comment_only_documents(text):
    assert loads(text) == {}


def test_FP01_root_and_table_pairs():
    doc = 'a = 1\n[t]\nb = "x"\n[t.u]\nc = true\n'
    assert loads(doc) == {"a": 1, "t": {"b": "x", "u": {"c": True}}}


def test_FP01_keys_are_strings_even_when_number_like():
    assert loads("1 = 2\ntrue = 3\ninf = 4\nnan = 5\n'1.5' = 6") == {
        "1": 2, "true": 3, "inf": 4, "nan": 5, "1.5": 6,
    }


def test_FP01_key_case_is_significant():
    assert loads("A = 1\na = 2\n[T]\nx=1\n[t]\ny=2") == {"A": 1, "a": 2, "T": {"x": 1}, "t": {"y": 2}}


def test_FP01_quoted_keys_empty_dotted_and_escaped():
    doc = '"" = 1\n"a.b" = 2\n\'c d#\' = 3\n"\\u00e9" = 4\n\'\\n\' = 5'
    assert loads(doc) == {"": 1, "a.b": 2, "c d#": 3, "é": 4, "\\n": 5}


def test_FP01_dotted_keys_and_whitespace():
    assert loads("a . b . c = 1\nd.e = 2") == {"a": {"b": {"c": 1}}, "d": {"e": 2}}


def test_FP01_dotted_key_then_subtable_header_allowed():
    doc = '[fruit]\napple.color = "red"\napple.taste.sweet = true\n[fruit.apple.texture]\nsmooth = true'
    assert loads(doc) == {
        "fruit": {"apple": {"color": "red", "taste": {"sweet": True}, "texture": {"smooth": True}}}
    }


def test_FP01_implicit_parents_then_declared_later():
    assert loads("[a.b]\nc = 1\n[a]\nd = 2") == {"a": {"b": {"c": 1}, "d": 2}}


def test_FP01_array_of_tables_and_nested_headers():
    doc = "[[a]]\nx = 1\n[a.sub]\ny = 1\n[[a]]\nx = 2\n[a.sub]\ny = 2\n"
    assert loads(doc) == {"a": [{"x": 1, "sub": {"y": 1}}, {"x": 2, "sub": {"y": 2}}]}


def test_FP01_array_of_tables_implies_plain_parent():
    doc = "[[a.b]]\nx = 1\n[a]\ny = 2"
    assert loads(doc) == {"a": {"b": [{"x": 1}], "y": 2}}


def test_FP01_inline_tables_empty_dotted_multiline_trailing_comma():
    assert loads("a = {}") == {"a": {}}
    assert loads("a = { x.y = 1, z = 2 }") == {"a": {"x": {"y": 1}, "z": 2}}
    assert loads("a = {\n  x = 1, # c\n  y = 2,\n}") == {"a": {"x": 1, "y": 2}}


def test_FP01_arrays_mixed_nested_multiline_trailing_comma():
    assert loads("a = [1, 'two', [3.0], {}, ]") == {"a": [1, "two", [3.0], {}]}
    assert loads("a = [\n  1, # one\n  2,\n]") == {"a": [1, 2]}
    assert loads("a = []") == {"a": []}


def test_FP01_comments_and_indentation():
    doc = "\t a = 1 # trailing\n#full\n\t[t] # hdr\n\tb = 'x#y' # c\n"
    assert loads(doc) == {"a": 1, "t": {"b": "x#y"}}


def test_FP01_crlf_is_one_line_feed_everywhere():
    assert loads('a = """x\r\ny"""\r\nb = 1\r\n') == {"a": "x\ny", "b": 1}


# ---------------------------------------------------------------- FP-01/FP-04 structural refusals

@pytest.mark.parametrize(
    "doc",
    [
        "a = 1\na = 2",
        "[t]\n[t]",
        "a = 1\n[a]",
        "a.b = 1\n[a]",
        "[a]\nb.c = 1\n[a.b]",
        "a = {x = 1}\n[a.y]",
        "a = {x = 1}\na.y = 2",
        "[x.a]\n[x]\na.b = 1",
        "a = [1, 2]\n[[a]]",
        "[[a]]\n[a]",
        "a = [{b = 1}]\n[[a.b]]",
        "[[a]]\n[a]",
        "a = 1\n[a.b]",
        "a = 1 b = 2",
        "= 1",
        "a =",
        "a",
        "\"\"\"k\"\"\" = 1",
        "[a] b = 1",
        "[a]]",
        "[[a]",
        "[]",
        "[a..b]",
        "a..b = 1",
        "a = {,}",
        "a = {x=1,,}",
        "a = {x=1 y=2}",
        "a = [1 2]",
        "a = [,]",
        "[ [a] ]",
        "[a\nb = 1]",
    ],
)
def test_FP01_structural_violations_are_refused(doc):
    with pytest.raises(TOMLDecodeError):
        loads(doc)


def test_FP01_inline_table_cannot_be_extended_by_header_or_dotted():
    with pytest.raises(TOMLDecodeError):
        loads("a = {}\n[a.b]")


# ---------------------------------------------------------------- FP-02 scalars

def test_FP02_booleans():
    assert loads("a = true\nb = false") == {"a": True, "b": False}
    assert loads("a = true")["a"] is True


def test_FP02_strings_four_forms_and_escapes():
    doc = (
        'basic = "tab\\there\\n\\"q\\" \\\\ \\b\\f\\r\\e"\n'
        "literal = 'C:\\path\\n'\n"
        'u = "\\u00E9\\U0001F600\\x41"\n'
    )
    got = loads(doc)
    assert got["basic"] == "tab\there\n\"q\" \\ \b\f\r\x1b"
    assert got["literal"] == "C:\\path\\n"
    assert got["u"] == "é😀A"


def test_FP02_multiline_basic_first_newline_and_line_ending_backslash():
    doc = 'a = """\nline1\nline2\\\n   \t \n  end"""'
    assert loads(doc) == {"a": "line1\nline2end"}


def test_FP02_multiline_literal_keeps_backslashes_and_trims_first_newline():
    assert loads("a = '''\nkeep\\n\n'''") == {"a": "keep\\n\n"}


def test_FP02_multiline_quotes_before_closing_delimiter():
    assert loads('a = """x""""') == {"a": 'x"'}
    assert loads('a = """x"""""') == {"a": 'x""'}
    assert loads("a = '''x''''") == {"a": "x'"}
    assert loads('a = """""" ') == {"a": ""}
    assert loads('a = """a"b""c"""') == {"a": 'a"b""c'}


def test_FP02_tab_raw_in_one_line_strings():
    assert loads("a = 'x\ty'") == {"a": "x\ty"}
    assert loads('a = "x\ty"') == {"a": "x\ty"}


def test_FP02_integers_all_bases_and_signs():
    doc = "a = 0xff\nb = 0o17\nc = 0b1010\nd = 1_000\ne = -42\nf = +7\ng = 0\nh = -0\ni = +0"
    assert loads(doc) == {"a": 255, "b": 15, "c": 10, "d": 1000, "e": -42, "f": 7, "g": 0, "h": 0, "i": 0}
    assert type(loads("a = 1")["a"]) is int
    assert type(loads("a = 0xFF")["a"]) is int


def test_FP02_hex_digits_accept_either_case_in_integers_and_escapes():
    assert loads("a = 0xDeAd")["a"] == 0xDEAD
    assert loads('a = "\\u00e9\\u00E9"')["a"] == "éé"


@pytest.mark.parametrize(
    "doc",
    [
        "a = True", "a = TRUE", "a = truex", "a = 01", "a = +01", "a = 00", "a = -01",
        "a = 1__0", "a = 1_", "a = _1", "a = 0x_1", "a = 0X1", "a = 0xG", "a = 0x+1",
        "a = -0x1", "a = 0o8", "a = 0b2", "a = 1.", "a = .5", "a = 1.e5", "a = 1e",
        "a = 1_.5", "a = 1._5", "a = 1.5_", "a = 01.5", "a = .", "a = 1979-02-29",
        "a = 1979-13-01", "a = 1979-02-30", "a = 1979-05-27T25:00:00", "a = 12:60:00",
        "a = 12:00:60", "a = 07:32Z", "a = 1979-05-27T07:32:00+24:00", "a = 1979-05-27T07:32:00+05:60",
        "a = 1979-02-29T00:00:00", "a = 2023-02-29",
    ],
)
def test_FP02_invalid_scalars_are_refused_with_decode_error(doc):
    with pytest.raises(TOMLDecodeError):
        loads(doc)


def test_FP02_floats_default_and_special_spellings():
    got = loads("a = 1e5\nb = -0.5\nc = 6.626e-34\nd = 5e+22\ne = 1_000.5\nf = inf\ng = -inf\nh = +inf\ni = nan\nj = -nan\nk = +nan")
    assert got["a"] == 1e5 and type(got["a"]) is float
    assert got["b"] == -0.5 and got["c"] == 6.626e-34 and got["d"] == 5e22
    assert got["e"] == 1000.5
    assert got["f"] == float("inf") and got["g"] == float("-inf") and got["h"] == float("inf")
    assert got["i"] != got["i"] and got["j"] != got["j"] and got["k"] != got["k"]


def test_FP02_date_times():
    got = loads(
        "a = 1979-05-27T07:32:00Z\n"
        "b = 1979-05-27 07:32:00.5-07:30\n"
        "c = 1979-05-27T07:32:00.123456789+05:30\n"
        "d = 1979-05-27T07:32\n"
        "e = 1979-05-27\n"
        "f = 07:32:00\n"
        "g = 07:32:00.9999999\n"
        "h = 2024-02-29\n"
        "i = 1979-05-27t07:32:00z\n"
    )
    assert got["a"] == dt.datetime(1979, 5, 27, 7, 32, tzinfo=dt.timezone.utc)
    assert got["a"].utcoffset() == dt.timedelta(0)
    assert got["b"].utcoffset() == dt.timedelta(hours=-7, minutes=-30)
    assert got["b"].microsecond == 500000
    assert got["c"].microsecond == 123456 and got["c"].utcoffset() == dt.timedelta(hours=5, minutes=30)
    assert got["d"] == dt.datetime(1979, 5, 27, 7, 32) and got["d"].tzinfo is None
    assert got["e"] == dt.date(1979, 5, 27) and type(got["e"]) is dt.date
    assert got["f"] == dt.time(7, 32, 0) and got["f"].tzinfo is None
    assert got["g"].microsecond == 999999  # truncated, not rounded
    assert got["h"] == dt.date(2024, 2, 29)
    assert got["i"].tzinfo is not None


def test_FP02_datetime_values_copy_and_compare():
    import copy

    v = loads("a = 1979-05-27T07:32:00Z")["a"]
    assert copy.deepcopy(v) == v and copy.copy(v) == v


# ---------------------------------------------------------------- FP-03 binary file

def test_FP03_binary_file_objects_and_empty_file():
    assert load(io.BytesIO(b"a = 1\nb = [1, 2]")) == {"a": 1, "b": [1, 2]}
    assert load(io.BytesIO(b"")) == {}
    assert load(io.BytesIO(b"a = 'caf\xc3\xa9'")) == {"a": "café"}


def test_FP03_crlf_in_binary_matches_text_result():
    data = 'a = """x\r\ny"""\r\n'.encode("utf-8")
    assert load(io.BytesIO(data)) == loads('a = """x\r\ny"""\r\n') == {"a": "x\ny"}


def test_FP03_text_mode_file_is_type_error(tmp_path):
    p = tmp_path / "doc.toml"
    p.write_text("a = 1", encoding="utf-8")
    with open(p, "r", encoding="utf-8") as fh:
        with pytest.raises(TypeError) as info:
            load(fh)
    assert not isinstance(info.value, TOMLDecodeError)
    with open(p, "rb") as fh:
        assert load(fh) == {"a": 1}
    with pytest.raises(TypeError):
        load(io.StringIO("a = 1"))


def test_FP03_invalid_toml_in_binary_is_decode_error_with_text_location():
    with pytest.raises(TOMLDecodeError) as info:
        load(io.BytesIO(b"a = 1\nb = 2 c"))
    err = info.value
    assert err.doc == "a = 1\nb = 2 c"  # decoded text, not bytes
    assert (err.lineno, err.colno) == (2, 7)


def test_FP03_invalid_utf8_is_decode_error():
    with pytest.raises(TOMLDecodeError):
        load(io.BytesIO(b"a = '\xff'"))


# ---------------------------------------------------------------- FP-04 rejection

def test_FP04_type_errors_for_wrong_input():
    for bad in (b"a = 1", bytearray(b"a = 1"), None, 1, io.BytesIO(b"a = 1")):
        with pytest.raises(TypeError) as info:
            loads(bad)
        assert not isinstance(info.value, TOMLDecodeError)


def test_FP04_error_carries_doc_pos_line_column():
    with pytest.raises(TOMLDecodeError) as info:
        loads("a = 1\nb = 0o9")
    err = info.value
    assert err.doc == "a = 1\nb = 0o9"
    # "0" is a valid integer; the parser stops at the "o" that cannot follow it.
    assert isinstance(err.pos, int) and err.doc[err.pos] == "o"
    assert (err.lineno, err.colno) == (2, 6)
    assert "line 2" in str(err) and "column 6" in str(err)


def test_FP04_end_of_document_report():
    with pytest.raises(TOMLDecodeError) as info:
        loads("[x")
    assert "end of document" in str(info.value)


def test_FP04_caller_constructed_error():
    err = TOMLDecodeError("bad thing", "ab\ncd", 4)
    assert (err.msg, err.doc, err.pos) == ("bad thing", "ab\ncd", 4)
    assert (err.lineno, err.colno) == (2, 2)
    assert "bad thing" in str(err) and "line 2" in str(err) and "column 2" in str(err)
    assert isinstance(err, ValueError)


def test_FP04_error_pickles():
    err = TOMLDecodeError("m", "x\ny", 2)
    copy_ = pickle.loads(pickle.dumps(err))
    assert (copy_.msg, copy_.doc, copy_.pos, copy_.lineno, copy_.colno) == ("m", "x\ny", 2, 2, 1)


def test_FP04_failure_yields_no_mapping():
    with pytest.raises(TOMLDecodeError):
        loads("a = 1\nb = [")


# ---------------------------------------------------------------- FP-05 converter

def test_FP05_converter_called_for_every_float_with_text_as_written():
    seen = []

    def conv(text):
        seen.append(text)
        return ("F", text)

    doc = "a = 1.5\nb = [2e3, -1_0.0]\nc = {d = nan}\ne = 7\nf = +inf\ng = '1.5'"
    got = loads(doc, parse_float=conv)
    assert got == {
        "a": ("F", "1.5"),
        "b": [("F", "2e3"), ("F", "-1_0.0")],
        "c": {"d": ("F", "nan")},
        "e": 7,
        "f": ("F", "+inf"),
        "g": "1.5",
    }
    assert seen == ["1.5", "2e3", "-1_0.0", "nan", "+inf"]


def test_FP05_converter_not_called_for_ints_strings_datetimes():
    calls = []
    loads("a = 1\nb = 'x'\nc = 1979-05-27\nd = true", parse_float=lambda t: calls.append(t))
    assert calls == []


@pytest.mark.parametrize("result", [{}, {"x": 1}, [], [1]])
def test_FP05_dict_or_list_result_is_value_error_not_decode_error(result):
    with pytest.raises(ValueError) as info:
        loads("a = 1.0", parse_float=lambda t: result)
    assert not isinstance(info.value, TOMLDecodeError)


class _DictSub(dict):
    pass


class _ListSub(list):
    pass


@pytest.mark.parametrize("result", [_DictSub(), _ListSub()])
def test_FP05_subclass_of_dict_or_list_is_refused(result):
    with pytest.raises(ValueError) as info:
        loads("a = [1.0]", parse_float=lambda t: result)
    assert not isinstance(info.value, TOMLDecodeError)


def test_FP05_converter_result_bound_as_returned():
    sentinel = object()
    assert loads("a = 1.0", parse_float=lambda t: sentinel)["a"] is sentinel
    assert loads("a = 1.0", parse_float=lambda t: "text")["a"] == "text"


def test_FP05_converter_on_binary_entry():
    assert load(io.BytesIO(b"a = 2.5"), parse_float=lambda t: t) == {"a": "2.5"}


def test_FP05_default_is_float_when_omitted_and_when_builtin_passed():
    assert loads("a = 1.5")["a"] == 1.5
    assert loads("a = 1.5", parse_float=float)["a"] == 1.5
    assert loads("a = 1_0.5", parse_float=float)["a"] == 10.5


# ---------------------------------------------------------------- Interface contract

def test_contract_loads_is_keyword_only_for_parse_float():
    with pytest.raises(TypeError):
        loads("a = 1", float)


def test_contract_load_rejects_path_string():
    with pytest.raises(TypeError):
        load("some/path.toml")
