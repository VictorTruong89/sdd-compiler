import os
import sys

# Make the src-layout package importable when pytest runs from the project root
# without PYTHONPATH being set.
_SRC = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src")
if _SRC not in sys.path:
    sys.path.insert(0, _SRC)
