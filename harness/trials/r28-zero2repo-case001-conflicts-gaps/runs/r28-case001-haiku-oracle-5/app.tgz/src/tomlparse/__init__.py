"""tomlparse: a pure-Python TOML v1.1.0 parser.

Public names: ``loads``, ``load``, ``TOMLDecodeError``.
"""

# spec: N-000266 N-000267 N-000268 N-000269 N-000270 N-000273 N-000255
# spec: N-000256 N-000257 N-000258 N-000259 N-000260 N-000261 N-000262
# spec: N-000263 N-000264 N-000265 N-000002 N-000003 N-000040 N-000043
# spec: N-000044 N-000046 N-000047 N-000049 N-000050

from ._api import load, loads
from ._errors import TOMLDecodeError

__version__ = "2.4.0"
__all__ = ["loads", "load", "TOMLDecodeError"]
