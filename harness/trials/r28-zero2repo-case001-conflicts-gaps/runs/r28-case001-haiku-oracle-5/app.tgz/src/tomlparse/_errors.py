"""The decode-error type raised for invalid TOML documents."""

# spec: N-000307 N-000308 N-000309 N-000310 N-000311 N-000312 N-000313
# spec: N-000314 N-000315 N-000316 N-000317 N-000318 N-000319 N-000320
# spec: N-000321 N-000322 N-000323 N-000203 N-000204 N-000205 N-000206
# spec: N-000207 N-000208 N-000209 N-000210 N-000211 N-000212 N-000217
# spec: N-000218 N-000219


class TOMLDecodeError(ValueError):
    """A document is not valid TOML v1.1.0.

    Constructed as ``TOMLDecodeError(msg, doc, pos)``; the parse entries raise
    instances built the same way. ``pos`` is a 0-based character offset into
    ``doc``. ``lineno`` and ``colno`` are 1-based and derived from ``pos``.
    """

    def __init__(self, msg, doc, pos):
        ValueError.__init__(self, msg, doc, pos)
        self.msg = msg
        self.doc = doc
        self.pos = pos

    @property
    def lineno(self):
        # 1 plus the number of line feeds before the offset.
        return self.doc.count("\n", 0, self.pos) + 1

    @property
    def colno(self):
        # 1 plus the characters between the last line feed before the offset
        # (or the start of the document) and the offset.
        start = self.doc.rfind("\n", 0, self.pos) + 1
        return self.pos - start + 1

    def __str__(self):
        if self.pos >= len(self.doc):
            where = "end of document, line %d, column %d" % (self.lineno, self.colno)
        else:
            where = "line %d, column %d (char %d)" % (self.lineno, self.colno, self.pos)
        return "%s (%s)" % (self.msg, where)

    def __reduce__(self):
        return (self.__class__, (self.msg, self.doc, self.pos))
