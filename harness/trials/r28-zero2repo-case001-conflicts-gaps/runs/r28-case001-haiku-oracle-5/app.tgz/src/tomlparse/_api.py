"""The public entries: ``loads`` (text) and ``load`` (binary file object)."""

import io

from ._errors import TOMLDecodeError
from ._parser import parse_document


def loads(s, *, parse_float=float):
    """Parse a TOML v1.1.0 document given as a ``str`` into a dict.

    # spec: N-000274 N-000275 N-000276 N-000277 N-000278 N-000279 N-000280
    # spec: N-000294 N-000295 N-000296 N-000297 N-000298 N-000271 N-000220
    # spec: N-000221 N-000222 N-000232 N-000233 N-000213 N-000214 N-000215
    """
    if not isinstance(s, str):
        raise TypeError("loads() requires a str, not %s" % type(s).__name__)
    return parse_document(s, parse_float)


def load(fp, *, parse_float=float):
    """Parse TOML from a file object opened for binary reading.

    # spec: N-000299 N-000300 N-000301 N-000302 N-000303 N-000304 N-000305
    # spec: N-000306 N-000272 N-000181 N-000182 N-000183 N-000184 N-000185
    # spec: N-000186 N-000187 N-000188 N-000189 N-000190 N-000191 N-000192
    # spec: N-000193 N-000194 N-000195 N-000196 N-000216
    """
    if isinstance(fp, io.TextIOBase):
        raise TypeError("load() requires a file opened in binary mode, not text mode")
    read = getattr(fp, "read", None)
    if read is None:
        raise TypeError("load() requires a binary file object with a read() method")
    data = read()
    if isinstance(data, str):
        raise TypeError("load() requires a file opened in binary mode, not text mode")
    if not isinstance(data, (bytes, bytearray)):
        raise TypeError("load() read() must return bytes, not %s" % type(data).__name__)
    data = bytes(data)
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        # Not specified by the spec; reported as a decode error at the first bad byte.
        prefix = data[: exc.start].decode("utf-8", "replace")
        full = data.decode("utf-8", "replace")
        raise TOMLDecodeError("invalid UTF-8 in document", full, len(prefix))
    return parse_document(text, parse_float)
