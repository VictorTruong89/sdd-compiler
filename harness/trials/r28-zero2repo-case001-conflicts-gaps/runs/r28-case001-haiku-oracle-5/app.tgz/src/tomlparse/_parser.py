"""A TOML v1.1.0 parser written from the specification (no delegation).

Positions are tracked against the normalized text (CR LF pairs folded to a
single LF); errors are reported as offsets into the caller's original text.
"""

import datetime as _dt
import re
import string

from ._errors import TOMLDecodeError

# Resolved contradictions are documented in NOTES.md (CF-000001 ... CF-000074).

_BARE_KEY_RE = re.compile(r"[A-Za-z0-9_-]+")
# Date with optional time; the offset is only allowed after a time part.
_DATETIME_RE = re.compile(
    r"([0-9]{4})-([0-9]{2})-([0-9]{2})"
    r"(?:[Tt ]([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?"
    r"(?:([Zz])|([+-])([0-9]{2}):([0-9]{2}))?)?"
)
_TIME_RE = re.compile(r"([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?")
_PREFIXED_INT_RE = re.compile(
    r"0x[0-9A-Fa-f]+(?:_[0-9A-Fa-f]+)*"
    r"|0o[0-7]+(?:_[0-7]+)*"
    r"|0b[01]+(?:_[01]+)*"
)
# Decimal integer or float; a float has a fraction, an exponent, or both.
_NUMBER_RE = re.compile(
    r"[+-]?(?:0|[1-9][0-9]*(?:_[0-9]+)*)"
    r"(?:\.[0-9]+(?:_[0-9]+)*)?"
    r"(?:[eE][+-]?[0-9]+(?:_[0-9]+)*)?"
)
_SPECIAL_FLOAT_RE = re.compile(r"[+-]?(?:inf|nan)")

_HEX_DIGITS = frozenset(string.hexdigits)
_SIMPLE_ESCAPES = {
    "b": "\b",
    "t": "\t",
    "n": "\n",
    "f": "\f",
    "r": "\r",
    "e": "\x1b",
    '"': '"',
    "\\": "\\",
}
_ESCAPE_DIGITS = {"x": 2, "u": 4, "U": 8}

# Table kinds, recorded per object so header and dotted-key rules can be checked.
_ROOT = "root"
_IMPLICIT = "implicit"  # created as a missing parent of a header
_HEADER = "header"  # defined by a [table] header
_DOTTED = "dotted"  # created by dotted keys
_INLINE = "inline"  # an inline table (frozen once closed)
_AOT = "aot"  # an array of tables, or one of its items


def _is_bad_control(c):
    return (c < " " and c != "\t") or c == "\x7f"


class _Parser:
    def __init__(self, doc, parse_float):
        self.doc = doc
        self.parse_float = parse_float
        self.kinds = {}  # id(obj) -> (kind, obj); obj kept alive by the tree
        if "\r" in doc:
            chars = []
            omap = []
            i = 0
            n = len(doc)
            while i < n:
                c = doc[i]
                if c == "\r" and i + 1 < n and doc[i + 1] == "\n":
                    i += 1
                    continue
                chars.append(c)
                omap.append(i)
                i += 1
            omap.append(n)
            self.s = "".join(chars)
            self.omap = omap
        else:
            self.s = doc
            self.omap = None
        self.n = len(self.s)
        self.i = 0

    # ----- helpers -------------------------------------------------------

    def _orig(self, pos):
        # Map a normalized offset back to the caller's text.
        if self.omap is None:
            return pos
        if pos < len(self.omap):
            return self.omap[pos]
        return len(self.doc) + (pos - (len(self.omap) - 1))

    def _error(self, msg, pos=None):
        if pos is None:
            pos = self.i
        raise TOMLDecodeError(msg, self.doc, self._orig(pos))

    def _peek(self):
        return self.s[self.i] if self.i < self.n else ""

    def _skip_ws(self):
        s, n, i = self.s, self.n, self.i
        while i < n and s[i] in " \t":
            i += 1
        self.i = i

    def _skip_comment(self):
        # spec: N-000107 N-000108 N-000109 N-000110
        # Positioned on '#'; stops before the line feed (or at end of text).
        s, n = self.s, self.n
        i = self.i + 1
        while i < n and s[i] != "\n":
            if _is_bad_control(s[i]):
                self._error("control character not allowed in comment", i)
            i += 1
        self.i = i

    def _skip_blank_lines_and_comments(self):
        # Used inside arrays and inline tables, where newlines are allowed.
        while True:
            self._skip_ws()
            c = self._peek()
            if c == "\n":
                self.i += 1
            elif c == "#":
                self._skip_comment()
            else:
                return

    def _expect_eol(self):
        self._skip_ws()
        if self._peek() == "#":
            self._skip_comment()
        if self.i >= self.n:
            return
        if self.s[self.i] == "\n":
            self.i += 1
            return
        self._error("expected end of line")

    def _new(self, kind, container=None):
        obj = [] if container == "list" else {}
        self.kinds[id(obj)] = (kind, obj)
        return obj

    def _kind(self, obj):
        entry = self.kinds.get(id(obj))
        return entry[0] if entry is not None else None

    # ----- document ------------------------------------------------------

    def parse(self):
        # spec: N-000077 N-000079 N-000080 N-000081 N-000082 N-000083 N-000084
        # spec: N-000113 N-000114 N-000115 N-000116 N-000117 N-000118 N-000119
        # spec: N-000120 N-000121 N-000122
        root = self._new(_ROOT)
        current = root
        s, n = self.s, self.n
        while True:
            self._skip_ws()
            if self.i >= n:
                break
            c = s[self.i]
            if c == "\n":
                self.i += 1
            elif c == "#":
                self._skip_comment()
            elif c == "[":
                current = self._parse_header(root)
            else:
                parts = self._parse_key()
                self._skip_ws()
                if self._peek() != "=":
                    self._error("expected '=' after key")
                self.i += 1
                self._skip_ws()
                value = self._parse_value()
                self._insert(current, parts, value)
                self._expect_eol()
        return root

    def _parse_header(self, root):
        self.i += 1  # first '['
        array = self._peek() == "["
        if array:
            self.i += 1
        self._skip_ws()
        parts = self._parse_key()
        self._skip_ws()
        if self._peek() != "]":
            self._error("expected ']' to close table header")
        self.i += 1
        if array:
            if self._peek() != "]":
                self._error("expected ']]' to close array of tables header")
            self.i += 1
        self._expect_eol()
        return self._open_table(root, parts, array)

    def _open_table(self, root, parts, array):
        # spec: N-000096 N-000097 N-000098 N-000099 N-000100 N-000101 N-000102
        cur = root
        for part in parts[:-1]:
            if part not in cur:
                child = self._new(_IMPLICIT)
                cur[part] = child
                cur = child
                continue
            child = cur[part]
            if isinstance(child, list):
                if self._kind(child) != _AOT or not child:
                    self._error("key %r is a static array, not a table" % (part,))
                cur = child[-1]
            elif isinstance(child, dict) and self._kind(child) in (
                _IMPLICIT,
                _HEADER,
                _DOTTED,
                _AOT,
            ):
                cur = child
            else:
                self._error("key %r is not a table and cannot be extended" % (part,))
        last = parts[-1]
        if array:
            if last not in cur:
                item = self._new(_AOT)
                lst = self._new(_AOT, "list")
                lst.append(item)
                cur[last] = lst
                return item
            lst = cur[last]
            if isinstance(lst, list) and self._kind(lst) == _AOT:
                item = self._new(_AOT)
                lst.append(item)
                return item
            self._error("key %r is already defined and is not an array of tables" % (last,))
        if last not in cur:
            table = self._new(_HEADER)
            cur[last] = table
            return table
        child = cur[last]
        if isinstance(child, dict) and self._kind(child) == _IMPLICIT:
            self.kinds[id(child)] = (_HEADER, child)
            return child
        self._error("table %r is already defined" % (last,))

    def _insert(self, table, parts, value):
        # spec: N-000093 N-000094 N-000095 N-000086 N-000087
        cur = table
        for part in parts[:-1]:
            if part not in cur:
                child = self._new(_DOTTED)
                cur[part] = child
                cur = child
                continue
            child = cur[part]
            if isinstance(child, dict) and self._kind(child) == _DOTTED:
                cur = child
            else:
                self._error("key %r is already defined and cannot be extended by dotted keys" % (part,))
        last = parts[-1]
        if last in cur:
            self._error("duplicate key %r" % (last,))
        cur[last] = value

    # ----- keys ----------------------------------------------------------

    def _parse_key(self):
        # spec: N-000085 N-000086 N-000088 N-000089 N-000090 N-000091 N-000092
        # spec: N-000141 N-000142 N-000164 N-000165
        parts = []
        s = self.s
        while True:
            self._skip_ws()
            c = self._peek()
            if c == '"':
                if s.startswith('"""', self.i):
                    self._error("multiline string cannot be used as a key")
                parts.append(self._basic_one_line())
            elif c == "'":
                if s.startswith("'''", self.i):
                    self._error("multiline string cannot be used as a key")
                parts.append(self._literal_one_line())
            else:
                m = _BARE_KEY_RE.match(s, self.i)
                if m is None:
                    self._error("expected a key")
                parts.append(m.group())
                self.i = m.end()
            self._skip_ws()
            if self._peek() == ".":
                self.i += 1
                continue
            return parts

    # ----- values --------------------------------------------------------

    def _parse_value(self):
        # spec: N-000123 N-000124 N-000125 N-000126 N-000144 N-000145 N-000146
        # spec: N-000147 N-000148 N-000149 N-000150 N-000151 N-000152 N-000153
        # spec: N-000162 N-000163 N-000166 N-000167 N-000168 N-000169 N-000170
        # spec: N-000171 N-000172 N-000173 N-000174 N-000175 N-000176 N-000177
        # spec: N-000179 N-000180 N-000159
        s, i = self.s, self.i
        if i >= self.n:
            self._error("expected a value")
        c = s[i]
        if c == '"':
            if s.startswith('"""', i):
                return self._multiline_basic()
            return self._basic_one_line()
        if c == "'":
            if s.startswith("'''", i):
                return self._multiline_literal()
            return self._literal_one_line()
        if c == "[":
            return self._array()
        if c == "{":
            return self._inline_table()
        if s.startswith("true", i):
            self.i += 4
            return True
        if s.startswith("false", i):
            self.i += 5
            return False
        m = _DATETIME_RE.match(s, i)
        if m is not None:
            self.i = m.end()
            return self._datetime(m, i)
        m = _TIME_RE.match(s, i)
        if m is not None:
            self.i = m.end()
            return self._time(m, i)
        m = _SPECIAL_FLOAT_RE.match(s, i)
        if m is not None:
            self.i = m.end()
            return self._float(m.group(), i)
        m = _PREFIXED_INT_RE.match(s, i)
        if m is not None:
            self.i = m.end()
            text = m.group()
            base = {"x": 16, "o": 8, "b": 2}[text[1]]
            return int(text[2:].replace("_", ""), base)
        m = _NUMBER_RE.match(s, i)
        if m is not None:
            self.i = m.end()
            text = m.group()
            if "." in text or "e" in text or "E" in text:
                return self._float(text, i)
            return int(text.replace("_", ""), 10)
        self._error("expected a value")

    def _float(self, text, start):
        # spec: N-000148 N-000149 N-000150 N-000173 N-000223 N-000224 N-000225
        # spec: N-000226 N-000227 N-000230 N-000231 N-000232 N-000233 N-000275
        # spec: N-000276 N-000277 N-000287 N-000296 N-000301
        if self.parse_float is float:
            return float(text.replace("_", ""))
        value = self.parse_float(text)
        if isinstance(value, (dict, list)):
            raise ValueError(
                "parse_float returned a %s for %r; only scalar results are allowed"
                % (type(value).__name__, text)
            )
        return value

    def _datetime(self, m, start):
        # spec: N-000151 N-000152 N-000153 N-000154 N-000155 N-000156 N-000157
        # spec: N-000158 N-000159 N-000179 N-000180 N-000288 N-000289 N-000290
        try:
            year, month, day = int(m.group(1)), int(m.group(2)), int(m.group(3))
            if m.group(4) is None:
                return _dt.date(year, month, day)
            hour, minute = int(m.group(4)), int(m.group(5))
            second = int(m.group(6) or 0)
            micro = _fraction_micro(m.group(7))
            if m.group(8) is not None:
                tz = _dt.timezone.utc
            elif m.group(9) is not None:
                tz = _offset(m.group(9), int(m.group(10)), int(m.group(11)))
            else:
                tz = None
            return _dt.datetime(year, month, day, hour, minute, second, micro, tzinfo=tz)
        except ValueError:
            self._error("invalid date or time", start)

    def _time(self, m, start):
        try:
            hour, minute = int(m.group(1)), int(m.group(2))
            second = int(m.group(3) or 0)
            return _dt.time(hour, minute, second, _fraction_micro(m.group(4)))
        except ValueError:
            self._error("invalid time", start)

    # ----- strings -------------------------------------------------------

    def _escape(self, i):
        """Decode the escape starting at the backslash at ``i``."""
        s = self.s
        if i + 1 >= self.n:
            self._error("unfinished escape", i)
        e = s[i + 1]
        if e in _SIMPLE_ESCAPES:
            return _SIMPLE_ESCAPES[e], i + 2
        if e in _ESCAPE_DIGITS:
            count = _ESCAPE_DIGITS[e]
            digits = s[i + 2 : i + 2 + count]
            if len(digits) != count or any(d not in _HEX_DIGITS for d in digits):
                self._error("invalid \\%s escape" % e, i)
            code = int(digits, 16)
            if code > 0x10FFFF or 0xD800 <= code <= 0xDFFF:
                self._error("escape is not a Unicode scalar value", i)
            return chr(code), i + 2 + count
        self._error("invalid escape sequence", i)

    def _basic_one_line(self):
        # spec: N-000127 N-000137 N-000138 N-000139 N-000140 N-000143 N-000178
        s, n = self.s, self.n
        start = self.i
        i = start + 1
        buf = []
        while True:
            if i >= n:
                self._error("unterminated string", start)
            c = s[i]
            if c == '"':
                i += 1
                break
            if c == "\\":
                ch, i = self._escape(i)
                buf.append(ch)
                continue
            if c == "\n" or _is_bad_control(c):
                self._error("control character not allowed in string", i)
            buf.append(c)
            i += 1
        self.i = i
        return "".join(buf)

    def _literal_one_line(self):
        s, n = self.s, self.n
        start = self.i
        i = start + 1
        while True:
            if i >= n:
                self._error("unterminated string", start)
            c = s[i]
            if c == "'":
                break
            if c == "\n" or _is_bad_control(c):
                self._error("control character not allowed in string", i)
            i += 1
        self.i = i + 1
        return s[start + 1 : i]

    def _multiline_basic(self):
        # spec: N-000127 N-000131 N-000132 N-000133 N-000134 N-000135 N-000136
        # spec: N-000137 N-000138 N-000139 N-000140 N-000178 N-000111 N-000112
        s, n = self.s, self.n
        start = self.i
        i = start + 3
        if i < n and s[i] == "\n":
            i += 1
        buf = []
        while True:
            if i >= n:
                self._error("unterminated multiline string", start)
            c = s[i]
            if c == '"':
                j = i
                while j < n and s[j] == '"':
                    j += 1
                run = j - i
                if run < 3:
                    buf.append('"' * run)
                    i = j
                    continue
                if run > 5:
                    self._error("too many quotation marks in multiline string", i)
                buf.append('"' * (run - 3))
                i = j
                break
            if c == "\\":
                j = i + 1
                while j < n and s[j] in " \t":
                    j += 1
                if j < n and s[j] == "\n":
                    # Line-ending backslash: drop it and all following whitespace.
                    j += 1
                    while j < n and s[j] in " \t\n":
                        j += 1
                    i = j
                    continue
                ch, i = self._escape(i)
                buf.append(ch)
                continue
            if c != "\n" and _is_bad_control(c):
                self._error("control character not allowed in string", i)
            buf.append(c)
            i += 1
        self.i = i
        return "".join(buf)

    def _multiline_literal(self):
        # spec: N-000127 N-000128 N-000129 N-000130 N-000135 N-000178
        s, n = self.s, self.n
        start = self.i
        i = start + 3
        if i < n and s[i] == "\n":
            i += 1
        buf = []
        while True:
            if i >= n:
                self._error("unterminated multiline string", start)
            c = s[i]
            if c == "'":
                j = i
                while j < n and s[j] == "'":
                    j += 1
                run = j - i
                if run < 3:
                    buf.append("'" * run)
                    i = j
                    continue
                if run > 5:
                    self._error("too many quotation marks in multiline string", i)
                buf.append("'" * (run - 3))
                i = j
                break
            if c != "\n" and _is_bad_control(c):
                self._error("control character not allowed in string", i)
            buf.append(c)
            i += 1
        self.i = i
        return "".join(buf)

    # ----- arrays and inline tables -------------------------------------

    def _array(self):
        # spec: N-000105 N-000106
        self.i += 1
        items = []
        while True:
            self._skip_blank_lines_and_comments()
            if self._peek() == "]":
                self.i += 1
                return items
            items.append(self._parse_value())
            self._skip_blank_lines_and_comments()
            c = self._peek()
            if c == ",":
                self.i += 1
            elif c == "]":
                self.i += 1
                return items
            else:
                self._error("expected ',' or ']' in array")

    def _inline_table(self):
        # spec: N-000103 N-000104
        self.i += 1
        table = self._new(_INLINE)
        self._skip_blank_lines_and_comments()
        if self._peek() == "}":
            self.i += 1
            return table
        while True:
            parts = self._parse_key()
            self._skip_blank_lines_and_comments()
            if self._peek() != "=":
                self._error("expected '=' after key")
            self.i += 1
            self._skip_blank_lines_and_comments()
            value = self._parse_value()
            self._insert(table, parts, value)
            self._skip_blank_lines_and_comments()
            c = self._peek()
            if c == ",":
                self.i += 1
                self._skip_blank_lines_and_comments()
                if self._peek() == "}":
                    self.i += 1
                    return table
            elif c == "}":
                self.i += 1
                return table
            else:
                self._error("expected ',' or '}' in inline table")


def _fraction_micro(frac):
    if not frac:
        return 0
    return int((frac + "000000")[:6])


def _offset(sign, hours, minutes):
    if hours > 23 or minutes > 59:
        raise ValueError("offset out of range")
    delta = _dt.timedelta(hours=hours, minutes=minutes)
    return _dt.timezone(-delta if sign == "-" else delta)


def parse_document(doc, parse_float=float):
    """Parse TOML text (a ``str``) into a dict. Raises TOMLDecodeError."""
    parser = _Parser(doc, parse_float)
    return parser.parse()
