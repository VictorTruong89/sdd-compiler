import re
from datetime import date, datetime, time, timedelta, timezone


class TOMLDecodeError(ValueError):
    def __init__(self, msg, doc, pos):
        self.msg = msg
        self.doc = doc
        self.pos = pos
        self.lineno = doc.count("\n", 0, pos) + 1
        self.colno = pos - doc.rfind("\n", 0, pos)
        if pos >= len(doc):
            where = "at end of document"
        else:
            where = "at line %d, column %d" % (self.lineno, self.colno)
        ValueError.__init__(self, "%s (%s)" % (msg, where))


_DT = re.compile(
    r"([0-9]{4})-([0-9]{2})-([0-9]{2})"
    r"(?:[Tt ]([01][0-9]|2[0-3]):([0-5][0-9])(?::([0-5][0-9])(?:\.([0-9]+))?)?"
    r"(Z|z|[+-](?:[01][0-9]|2[0-3]):[0-5][0-9])?)?")
_TIME = re.compile(
    r"([01][0-9]|2[0-3]):([0-5][0-9])(?::([0-5][0-9])(?:\.([0-9]+))?)?")
_NUM = re.compile(
    r"0(?:x[0-9A-Fa-f](?:_?[0-9A-Fa-f])*|b[01](?:_?[01])*|o[0-7](?:_?[0-7])*)"
    r"|[+-]?(?:0|[1-9](?:_?[0-9])*)"
    r"(?P<frac>\.[0-9](?:_?[0-9])*)?(?P<exp>[eE][+-]?[0-9](?:_?[0-9])*)?")
_BARE = re.compile(r"[A-Za-z0-9_-]+")
_BASIC_CHUNK = re.compile(r'[^"\\\x00-\x08\x0a-\x1f\x7f]*')
_ML_CHUNK = re.compile(r'[^"\\\x00-\x08\x0b-\x1f\x7f]*')
_LIT_CHUNK = re.compile(r"[^'\x00-\x08\x0a-\x1f\x7f]*")
_MLLIT_CHUNK = re.compile(r"[^'\x00-\x08\x0b-\x1f\x7f]*")
_COMMENT = re.compile(r"#[^\x00-\x08\x0a-\x1f\x7f]*")
_LINE_END_BS = re.compile(r"\\[ \t]*\n[ \t\n]*")
_WS = re.compile(r"[ \t]*")
_WSNL = re.compile(r"[ \t\n]*")
_HEX = {"x": 2, "u": 4, "U": 8}
_ESC = {"b": "\b", "t": "\t", "n": "\n", "f": "\f", "r": "\r", "e": "\x1b",
        '"': '"', "\\": "\\"}
_HEXRE = re.compile(r"[0-9a-fA-F]+")
_TERM = frozenset(" \t\n#,]}")
_SPECIAL = ("inf", "+inf", "-inf", "nan", "+nan", "-nan")

FROZEN = 0
EXPLICIT = 1


class _Flags:
    def __init__(self):
        self._f = {}
        self._pending = set()

    def add_pending(self, key, flag):
        self._pending.add((key, flag))

    def finalize_pending(self):
        for key, flag in self._pending:
            self.set(key, flag, False)
        self._pending.clear()

    def unset_all(self, key):
        cont = self._f
        for k in key[:-1]:
            if k not in cont:
                return
            cont = cont[k]["nested"]
        cont.pop(key[-1], None)

    def set(self, key, flag, recursive):
        cont = self._f
        for k in key[:-1]:
            if k not in cont:
                cont[k] = {"flags": set(), "rec": set(), "nested": {}}
            cont = cont[k]["nested"]
        stem = key[-1]
        if stem not in cont:
            cont[stem] = {"flags": set(), "rec": set(), "nested": {}}
        cont[stem]["rec" if recursive else "flags"].add(flag)

    def is_(self, key, flag):
        if not key:
            return False
        cont = self._f
        for k in key[:-1]:
            if k not in cont:
                return False
            inner = cont[k]
            if flag in inner["rec"]:
                return True
            cont = inner["nested"]
        stem = key[-1]
        if stem in cont:
            inner = cont[stem]
            return flag in inner["flags"] or flag in inner["rec"]
        return False


class _Parser:
    def __init__(self, src, parse_float):
        self.src = src
        self.n = len(src)
        self.pf = parse_float

    def err(self, msg, pos):
        return TOMLDecodeError(msg, self.src, pos)

    # ---- helpers
    def skip_ws(self, pos):
        return _WS.match(self.src, pos).end()

    def skip_comment(self, pos):
        if pos < self.n and self.src[pos] == "#":
            pos = _COMMENT.match(self.src, pos).end()
            if pos < self.n and self.src[pos] != "\n":
                raise self.err("Illegal character in comment", pos)
        return pos

    def skip_wsnlc(self, pos):
        while True:
            pos = _WSNL.match(self.src, pos).end()
            if pos < self.n and self.src[pos] == "#":
                pos = self.skip_comment(pos)
            else:
                return pos

    # ---- document
    def parse(self):
        src, n = self.src, self.n
        out = {}
        flags = _Flags()
        header = ()
        pos = 0
        while True:
            pos = self.skip_ws(pos)
            if pos >= n:
                break
            c = src[pos]
            if c == "\n":
                pos += 1
                continue
            if c == "#":
                pos = self.skip_comment(pos)
                continue
            if c == "[":
                flags.finalize_pending()
                if src.startswith("[[", pos):
                    pos, key = self.parse_key(pos + 2)
                    if not src.startswith("]]", pos):
                        raise self.err("Expected ']]'", pos)
                    pos += 2
                    if flags.is_(key, FROZEN):
                        raise self.err("Cannot mutate immutable namespace", pos)
                    flags.unset_all(key)
                    flags.set(key, EXPLICIT, False)
                    try:
                        self.append_nest(out, key)
                    except KeyError:
                        raise self.err("Cannot overwrite a value", pos)
                else:
                    pos, key = self.parse_key(pos + 1)
                    if not src.startswith("]", pos):
                        raise self.err("Expected ']'", pos)
                    pos += 1
                    if flags.is_(key, EXPLICIT) or flags.is_(key, FROZEN):
                        raise self.err("Cannot declare table twice", pos)
                    flags.set(key, EXPLICIT, False)
                    try:
                        self.get_nest(out, key)
                    except KeyError:
                        raise self.err("Cannot overwrite a value", pos)
                header = key
            else:
                pos = self.key_value(pos, out, flags, header)
            pos = self.skip_ws(pos)
            pos = self.skip_comment(pos)
            if pos < n:
                if src[pos] != "\n":
                    raise self.err("Expected newline or end of document", pos)
                pos += 1
        return out

    @staticmethod
    def get_nest(root, key):
        cont = root
        for k in key:
            if k not in cont:
                cont[k] = {}
            cont = cont[k]
            if isinstance(cont, list):
                cont = cont[-1]
            if not isinstance(cont, dict):
                raise KeyError
        return cont

    def append_nest(self, root, key):
        cont = self.get_nest(root, key[:-1])
        k = key[-1]
        if k in cont:
            lst = cont[k]
            if not isinstance(lst, list):
                raise KeyError
            lst.append({})
        else:
            cont[k] = [{}]

    def key_value(self, pos, out, flags, header):
        pos, key = self.parse_key(pos)
        if pos >= self.n or self.src[pos] != "=":
            raise self.err("Expected '=' after key", pos)
        pos = self.skip_ws(pos + 1)
        kpos = pos
        pos, value = self.parse_value(pos)
        stem = key[-1]
        if len(key) > 1:
            for i in range(1, len(key)):
                ck = header + key[:i]
                if flags.is_(ck, EXPLICIT):
                    raise self.err("Cannot redefine namespace", kpos)
                flags.add_pending(ck, EXPLICIT)
        abs_key = header + key
        if flags.is_(abs_key, FROZEN):
            raise self.err("Cannot mutate immutable namespace", kpos)
        try:
            nest = self.get_nest(out, abs_key[:-1])
        except KeyError:
            raise self.err("Cannot overwrite a value", kpos)
        if stem in nest:
            raise self.err("Duplicate key", kpos)
        if isinstance(value, (dict, list)):
            flags.set(abs_key, FROZEN, True)
        nest[stem] = value
        return pos

    # ---- keys
    def parse_key(self, pos):
        parts = []
        while True:
            pos = self.skip_ws(pos)
            if pos >= self.n:
                raise self.err("Expected key", pos)
            c = self.src[pos]
            if c == '"':
                pos, k = self.parse_basic(pos + 1)
            elif c == "'":
                pos, k = self.parse_literal(pos + 1)
            else:
                m = _BARE.match(self.src, pos)
                if not m:
                    raise self.err("Invalid key", pos)
                k = m.group()
                pos = m.end()
            parts.append(k)
            pos = self.skip_ws(pos)
            if pos < self.n and self.src[pos] == ".":
                pos += 1
                continue
            return pos, tuple(parts)

    # ---- strings
    def parse_escape(self, pos):
        """pos at char after backslash. Returns (pos, text)."""
        src = self.src
        if pos >= self.n:
            raise self.err("Unterminated string", pos)
        c = src[pos]
        if c in _ESC:
            return pos + 1, _ESC[c]
        if c in _HEX:
            ln = _HEX[c]
            m = _HEXRE.match(src, pos + 1)
            if not m or m.end() - m.start() < ln:
                raise self.err("Invalid hex escape", pos)
            cp = int(src[pos + 1:pos + 1 + ln], 16)
            if cp > 0x10FFFF or 0xD800 <= cp <= 0xDFFF:
                raise self.err("Invalid Unicode scalar value", pos)
            return pos + 1 + ln, chr(cp)
        raise self.err("Invalid escape sequence", pos)

    def parse_basic(self, pos):
        src = self.src
        buf = []
        while True:
            m = _BASIC_CHUNK.match(src, pos)
            buf.append(m.group())
            pos = m.end()
            if pos >= self.n:
                raise self.err("Unterminated string", pos)
            c = src[pos]
            if c == '"':
                return pos + 1, "".join(buf)
            if c == "\\":
                pos, t = self.parse_escape(pos + 1)
                buf.append(t)
            else:
                raise self.err("Illegal character in string", pos)

    def parse_literal(self, pos):
        src = self.src
        m = _LIT_CHUNK.match(src, pos)
        pos = m.end()
        if pos >= self.n or src[pos] != "'":
            raise self.err("Unterminated or illegal literal string", pos)
        return pos + 1, m.group()

    def parse_ml_basic(self, pos):
        src = self.src
        if src.startswith("\n", pos):
            pos += 1
        buf = []
        while True:
            m = _ML_CHUNK.match(src, pos)
            buf.append(m.group())
            pos = m.end()
            if pos >= self.n:
                raise self.err("Unterminated string", pos)
            c = src[pos]
            if c == '"':
                end = pos
                while end < self.n and src[end] == '"':
                    end += 1
                run = end - pos
                if run >= 3:
                    if run > 5:
                        raise self.err("Too many quotes", pos + 5)
                    buf.append('"' * (run - 3))
                    return end, "".join(buf)
                buf.append('"' * run)
                pos = end
            elif c == "\\":
                m = _LINE_END_BS.match(src, pos)
                if m:
                    pos = m.end()
                else:
                    pos, t = self.parse_escape(pos + 1)
                    buf.append(t)
            else:
                raise self.err("Illegal character in string", pos)

    def parse_ml_literal(self, pos):
        src = self.src
        if src.startswith("\n", pos):
            pos += 1
        buf = []
        while True:
            m = _MLLIT_CHUNK.match(src, pos)
            buf.append(m.group())
            pos = m.end()
            if pos >= self.n:
                raise self.err("Unterminated string", pos)
            if src[pos] != "'":
                raise self.err("Illegal character in string", pos)
            end = pos
            while end < self.n and src[end] == "'":
                end += 1
            run = end - pos
            if run >= 3:
                if run > 5:
                    raise self.err("Too many quotes", pos + 5)
                buf.append("'" * (run - 3))
                return end, "".join(buf)
            buf.append("'" * run)
            pos = end

    # ---- values
    def parse_value(self, pos):
        src = self.src
        if pos >= self.n:
            raise self.err("Expected value", pos)
        c = src[pos]
        if c == '"':
            if src.startswith('"""', pos):
                return self.parse_ml_basic(pos + 3)
            return self.parse_basic(pos + 1)
        if c == "'":
            if src.startswith("'''", pos):
                return self.parse_ml_literal(pos + 3)
            return self.parse_literal(pos + 1)
        if src.startswith("true", pos):
            return self.end_scalar(pos + 4, True)
        if src.startswith("false", pos):
            return self.end_scalar(pos + 5, False)
        if c == "[":
            return self.parse_array(pos + 1)
        if c == "{":
            return self.parse_inline(pos + 1)
        m = _DT.match(src, pos)
        if m:
            return self.end_scalar(m.end(), self.make_dt(m, pos))
        m = _TIME.match(src, pos)
        if m:
            h, mi, s, f = m.groups()
            return self.end_scalar(
                m.end(), time(int(h), int(mi), int(s or 0), self.micro(f)))
        for sp in _SPECIAL:
            if src.startswith(sp, pos):
                return self.end_scalar(pos + len(sp), self.conv_float(sp, pos))
        m = _NUM.match(src, pos)
        if m:
            tok = m.group()
            if m.group("frac") or m.group("exp"):
                return self.end_scalar(m.end(), self.conv_float(tok, pos))
            t = tok.replace("_", "")
            if t[:2] in ("0x", "0o", "0b"):
                v = int(t[2:], {"x": 16, "o": 8, "b": 2}[t[1]])
            else:
                if t in ("+0", "-0"):
                    raise self.err("Invalid integer", pos)
                v = int(t)
            return self.end_scalar(m.end(), v)
        raise self.err("Invalid value", pos)

    def end_scalar(self, pos, v):
        if pos < self.n and self.src[pos] not in _TERM:
            raise self.err("Invalid value", pos)
        return pos, v

    def conv_float(self, tok, pos):
        v = self.pf(tok)
        if isinstance(v, (dict, list)):
            raise ValueError("parse_float must not return dicts or lists")
        return v

    @staticmethod
    def micro(f):
        return int((f or "0")[:6].ljust(6, "0"))

    def make_dt(self, m, pos):
        y, mo, d, h, mi, s, f, off = m.groups()
        try:
            dd = date(int(y), int(mo), int(d))
        except ValueError:
            raise self.err("Invalid date", pos)
        if h is None:
            return dd
        tz = None
        if off:
            if off in ("Z", "z"):
                tz = timezone.utc
            else:
                sign = -1 if off[0] == "-" else 1
                tz = timezone(sign * timedelta(hours=int(off[1:3]),
                                               minutes=int(off[4:6])))
        return datetime(dd.year, dd.month, dd.day, int(h), int(mi), int(s or 0),
                        self.micro(f), tz)

    def parse_array(self, pos):
        arr = []
        while True:
            pos = self.skip_wsnlc(pos)
            if pos >= self.n:
                raise self.err("Unterminated array", pos)
            if self.src[pos] == "]":
                return pos + 1, arr
            pos, v = self.parse_value(pos)
            arr.append(v)
            pos = self.skip_wsnlc(pos)
            if pos >= self.n:
                raise self.err("Unterminated array", pos)
            c = self.src[pos]
            if c == ",":
                pos += 1
            elif c == "]":
                return pos + 1, arr
            else:
                raise self.err("Expected ',' or ']'", pos)

    def parse_inline(self, pos):
        out = {}
        flags = _Flags()
        pos = self.skip_wsnlc(pos)
        if pos < self.n and self.src[pos] == "}":
            return pos + 1, out
        while True:
            pos = self.key_value(pos, out, flags, ())
            pos = self.skip_wsnlc(pos)
            if pos >= self.n:
                raise self.err("Unterminated inline table", pos)
            c = self.src[pos]
            if c == ",":
                pos = self.skip_wsnlc(pos + 1)
                if pos < self.n and self.src[pos] == "}":
                    return pos + 1, out
            elif c == "}":
                return pos + 1, out
            else:
                raise self.err("Expected ',' or '}'", pos)


def loads(s, *, parse_float=float):
    if not isinstance(s, str):
        raise TypeError("Expected str object, not %r" % type(s).__name__)
    src = s.replace("\r\n", "\n")
    try:
        return _Parser(src, parse_float).parse()
    except RecursionError:
        raise TOMLDecodeError("Document nesting too deep", src, 0) from None


def load(fp, *, parse_float=float):
    b = fp.read()
    if isinstance(b, str):
        raise TypeError("File must be opened in binary mode")
    if not isinstance(b, (bytes, bytearray, memoryview)):
        raise TypeError("File must be opened in binary mode")
    try:
        s = bytes(b).decode("utf-8")
    except UnicodeDecodeError as e:
        raise TOMLDecodeError("Invalid UTF-8: %s" % e.reason,
                              bytes(b).decode("utf-8", "replace"), e.start) from None
    return loads(s, parse_float=parse_float)
