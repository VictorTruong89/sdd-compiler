import re
from datetime import date, datetime, time, timedelta, timezone


class TOMLDecodeError(ValueError):
    def __init__(self, msg="", doc="", pos=0):
        if not isinstance(msg, str):
            msg = str(msg)
        self.msg = msg
        self.doc = doc
        self.pos = pos
        if pos >= len(doc):
            self.lineno = doc.count("\n") + 1
            self.colno = len(doc) - (doc.rfind("\n") + 1) + 1
            loc = "at end of document"
        else:
            self.lineno = doc.count("\n", 0, pos) + 1
            self.colno = pos - (doc.rfind("\n", 0, pos) + 1) + 1
            loc = "at line %d, column %d" % (self.lineno, self.colno)
        self.args = ("%s (%s)" % (msg, loc),)
        ValueError.__init__(self, self.args[0])

    def __str__(self):
        return self.args[0]


class _Err(Exception):
    def __init__(self, msg, pos):
        self.msg = msg
        self.pos = pos


BARE = re.compile(r"[A-Za-z0-9_-]+")
COMMENT = re.compile(r"#[^\x00-\x08\x0a-\x1f\x7f]*")
WS = re.compile(r"[ \t]*")
WSNL = re.compile(r"[ \t\n]*")
TIME = r"(\d\d):(\d\d)(?::(\d\d)(?:\.(\d+))?)?"
DATETIME = re.compile(
    r"(\d{4})-(\d\d)-(\d\d)(?:[Tt ]" + TIME + r"([Zz]|[+-]\d\d:\d\d)?)?")
LTIME = re.compile(TIME)
SPECIAL = re.compile(r"[+-]?(?:inf|nan)")
HEX = re.compile(r"0x[0-9A-Fa-f](?:_?[0-9A-Fa-f])*")
OCT = re.compile(r"0o[0-7](?:_?[0-7])*")
BIN = re.compile(r"0b[01](?:_?[01])*")
DEC = re.compile(
    r"[+-]?(?:0|[1-9](?:_?\d)*)((?:\.\d(?:_?\d)*)?)((?:[eE][+-]?\d(?:_?\d)*)?)")
HEXDIG = "0123456789abcdefABCDEF"
ESC = {"b": "\b", "t": "\t", "n": "\n", "f": "\f", "r": "\r", "e": "\x1b",
       '"': '"', "\\": "\\"}


def _bad(c):
    return (c < " " and c != "\t") or c == "\x7f"


class _Parser:
    def __init__(self, s, parse_float):
        self.s = s
        self.n = len(s)
        self.pf = parse_float
        self.i = 0
        self.defined = set()
        self.dotted = set()
        self.frozen = set()
        self.aot = set()

    def err(self, msg, pos=None):
        raise _Err(msg, self.i if pos is None else pos)

    def run(self):
        s, n = self.s, self.n
        root = {}
        cur = root
        while True:
            self.i = WS.match(s, self.i).end()
            if self.i >= n:
                break
            c = s[self.i]
            if c == "#":
                self.comment()
                self.endline()
                continue
            if c == "\n":
                self.i += 1
                continue
            if c == "[":
                cur = self.header(root)
            else:
                self.keyvalue(cur)
            self.i = WS.match(s, self.i).end()
            self.endline()
        return root

    def comment(self):
        m = COMMENT.match(self.s, self.i)
        self.i = m.end()

    def endline(self):
        # after optional ws: optional comment then newline or EOF
        s = self.s
        self.i = WS.match(s, self.i).end()
        if self.i < self.n and s[self.i] == "#":
            self.comment()
        if self.i >= self.n:
            return
        if s[self.i] != "\n":
            self.err("unexpected character")
        self.i += 1

    def skip_ws_nl_comments(self):
        s = self.s
        while True:
            self.i = WSNL.match(s, self.i).end()
            if self.i < self.n and s[self.i] == "#":
                self.comment()
            else:
                return

    # ---- keys
    def key_part(self):
        s = self.s
        if self.i >= self.n:
            self.err("expected key")
        c = s[self.i]
        if c == '"':
            if s.startswith('"""', self.i):
                self.err("multiline string as key")
            return self.basic_string()
        if c == "'":
            if s.startswith("'''", self.i):
                self.err("multiline string as key")
            return self.literal_string()
        m = BARE.match(s, self.i)
        if not m:
            self.err("invalid key")
        self.i = m.end()
        return m.group()

    def key(self):
        parts = []
        s = self.s
        while True:
            self.i = WS.match(s, self.i).end()
            parts.append(self.key_part())
            self.i = WS.match(s, self.i).end()
            if self.i < self.n and s[self.i] == ".":
                self.i += 1
                continue
            return parts

    # ---- structure
    def header(self, root):
        s = self.s
        is_aot = s.startswith("[[", self.i)
        self.i += 2 if is_aot else 1
        start = self.i
        parts = self.key()
        if is_aot:
            if not s.startswith("]]", self.i):
                self.err("expected ']]'")
            self.i += 2
        else:
            if self.i >= self.n or s[self.i] != "]":
                self.err("expected ']'")
            self.i += 1
        t = root
        for p in parts[:-1]:
            if p not in t:
                d = {}
                t[p] = d
                t = d
                continue
            v = t[p]
            if isinstance(v, dict):
                if id(v) in self.frozen:
                    self.err("cannot extend inline table", start)
                t = v
            elif isinstance(v, list) and id(v) in self.aot:
                t = v[-1]
            else:
                self.err("key already used as value", start)
        last = parts[-1]
        if is_aot:
            if last not in t:
                lst = []
                self.aot.add(id(lst))
                t[last] = lst
            else:
                lst = t[last]
                if not (isinstance(lst, list) and id(lst) in self.aot):
                    self.err("cannot define array of tables here", start)
            d = {}
            lst.append(d)
            return d
        if last not in t:
            d = {}
            t[last] = d
            self.defined.add(id(d))
            return d
        d = t[last]
        if (not isinstance(d, dict) or id(d) in self.defined
                or id(d) in self.dotted or id(d) in self.frozen):
            self.err("cannot redefine table", start)
        self.defined.add(id(d))
        return d

    def keyvalue(self, table):
        s = self.s
        kpos = self.i
        parts = self.key()
        if self.i >= self.n or s[self.i] != "=":
            self.err("expected '='")
        self.i += 1
        self.i = WS.match(s, self.i).end()
        t = table
        for p in parts[:-1]:
            if p not in t:
                d = {}
                self.dotted.add(id(d))
                t[p] = d
                t = d
            else:
                v = t[p]
                if (isinstance(v, dict) and id(v) in self.dotted
                        and id(v) not in self.frozen):
                    t = v
                else:
                    self.err("cannot extend existing key", kpos)
        last = parts[-1]
        if last in t:
            self.err("duplicate key", kpos)
        t[last] = self.value()

    # ---- values
    def value(self):
        s = self.s
        if self.i >= self.n:
            self.err("expected value")
        c = s[self.i]
        if c == '"':
            if s.startswith('"""', self.i):
                return self.ml_basic()
            return self.basic_string()
        if c == "'":
            if s.startswith("'''", self.i):
                return self.ml_literal()
            return self.literal_string()
        if c == "[":
            return self.array()
        if c == "{":
            return self.inline_table()
        if s.startswith("true", self.i):
            self.i += 4
            return True
        if s.startswith("false", self.i):
            self.i += 5
            return False
        m = DATETIME.match(s, self.i)
        if m:
            return self.datetime(m)
        m = LTIME.match(s, self.i)
        if m:
            return self.localtime(m)
        m = SPECIAL.match(s, self.i)
        if m:
            self.i = m.end()
            return self.float(m.group())
        for rx, base in ((HEX, 16), (OCT, 8), (BIN, 2)):
            m = rx.match(s, self.i)
            if m:
                self.i = m.end()
                return int(m.group()[2:].replace("_", ""), base)
        m = DEC.match(s, self.i)
        if m:
            self.i = m.end()
            tok = m.group()
            if m.group(1) or m.group(2):
                return self.float(tok)
            if tok[0] in "+-" and tok[1:] == "0" and False:
                pass
            return int(tok.replace("_", ""))
        self.err("invalid value")

    def float(self, tok):
        if self.pf is float:
            return float(tok.replace("_", ""))
        r = self.pf(tok)
        if isinstance(r, (dict, list)):
            raise ValueError("parse_float must not return dicts or lists")
        return r

    def datetime(self, m):
        start = self.i
        self.i = m.end()
        y, mo, d, hh, mm, ss, frac, off = m.groups()
        try:
            dt = date(int(y), int(mo), int(d))
            if hh is None:
                return dt
            t = self.mktime(hh, mm, ss, frac, start)
            if off is None:
                return datetime.combine(dt, t)
            if off in "Zz":
                tz = timezone.utc
            else:
                oh, om = int(off[1:3]), int(off[4:6])
                if oh > 23 or om > 59:
                    self.err("invalid offset", start)
                delta = timedelta(hours=oh, minutes=om)
                tz = timezone(-delta if off[0] == "-" else delta)
            return datetime.combine(dt, t, tzinfo=tz)
        except ValueError:
            self.err("invalid date or time", start)

    def mktime(self, hh, mm, ss, frac, start):
        us = int((frac or "0")[:6].ljust(6, "0"))
        try:
            return time(int(hh), int(mm), int(ss or 0), us)
        except ValueError:
            self.err("invalid time", start)

    def localtime(self, m):
        start = self.i
        self.i = m.end()
        hh, mm, ss, frac = m.groups()
        return self.mktime(hh, mm, ss, frac, start)

    def array(self):
        s = self.s
        self.i += 1
        out = []
        while True:
            self.skip_ws_nl_comments()
            if self.i >= self.n:
                self.err("unterminated array")
            if s[self.i] == "]":
                self.i += 1
                return out
            out.append(self.value())
            self.skip_ws_nl_comments()
            if self.i >= self.n:
                self.err("unterminated array")
            c = s[self.i]
            if c == ",":
                self.i += 1
            elif c == "]":
                self.i += 1
                return out
            else:
                self.err("expected ',' or ']'")

    def inline_table(self):
        s = self.s
        self.i += 1
        t = {}
        self.frozen.add(id(t))
        while True:
            self.skip_ws_nl_comments()
            if self.i >= self.n:
                self.err("unterminated inline table")
            if s[self.i] == "}":
                self.i += 1
                return t
            self.keyvalue(t)
            self.skip_ws_nl_comments()
            if self.i >= self.n:
                self.err("unterminated inline table")
            c = s[self.i]
            if c == ",":
                self.i += 1
            elif c == "}":
                self.i += 1
                return t
            else:
                self.err("expected ',' or '}'")

    # ---- strings
    def literal_string(self):
        s = self.s
        j = self.i + 1
        k = j
        while True:
            if k >= self.n:
                self.err("unterminated string", self.i)
            c = s[k]
            if c == "'":
                break
            if _bad(c):
                self.err("invalid character in string", k)
            k += 1
        self.i = k + 1
        return s[j:k]

    def ml_literal(self):
        s = self.s
        start = self.i
        j = self.i + 3
        if j < self.n and s[j] == "\n":
            j += 1
        k = j
        while True:
            if k >= self.n:
                self.err("unterminated string", start)
            c = s[k]
            if c == "'":
                q = k
                while q < self.n and s[q] == "'":
                    q += 1
                cnt = q - k
                if cnt >= 3:
                    if cnt > 5:
                        self.err("too many quotes", k)
                    self.i = q
                    return s[j:q - 3]
                k = q
                continue
            if _bad(c) and c != "\n":
                self.err("invalid character in string", k)
            k += 1

    def escape(self, k, out):
        """s[k] is the char after backslash (not whitespace-newline case).
        Returns new index."""
        s = self.s
        c = s[k] if k < self.n else ""
        if c in ESC and c:
            out.append(ESC[c])
            return k + 1
        if c in ("x", "u", "U"):
            ln = {"x": 2, "u": 4, "U": 8}[c]
            h = s[k + 1:k + 1 + ln]
            if len(h) != ln or any(ch not in HEXDIG for ch in h):
                self.err("invalid unicode escape", k)
            cp = int(h, 16)
            if cp > 0x10FFFF or 0xD800 <= cp <= 0xDFFF:
                self.err("invalid code point", k)
            out.append(chr(cp))
            return k + 1 + ln
        self.err("invalid escape", k - 1)

    def basic_string(self):
        s = self.s
        start = self.i
        k = start + 1
        out = []
        while True:
            if k >= self.n:
                self.err("unterminated string", start)
            c = s[k]
            if c == '"':
                self.i = k + 1
                return "".join(out)
            if c == "\\":
                k = self.escape(k + 1, out)
                continue
            if _bad(c):
                self.err("invalid character in string", k)
            out.append(c)
            k += 1

    def ml_basic(self):
        s = self.s
        start = self.i
        k = start + 3
        if k < self.n and s[k] == "\n":
            k += 1
        out = []
        while True:
            if k >= self.n:
                self.err("unterminated string", start)
            c = s[k]
            if c == '"':
                q = k
                while q < self.n and s[q] == '"':
                    q += 1
                cnt = q - k
                if cnt >= 3:
                    if cnt > 5:
                        self.err("too many quotes", k)
                    out.append('"' * (cnt - 3))
                    self.i = q
                    return "".join(out)
                out.append('"' * cnt)
                k = q
                continue
            if c == "\\":
                q = k + 1
                while q < self.n and s[q] in " \t":
                    q += 1
                if q < self.n and s[q] == "\n":
                    k = WSNL.match(s, q).end()
                    continue
                if q > k + 1:
                    self.err("invalid escape", k)
                k = self.escape(k + 1, out)
                continue
            if _bad(c) and c != "\n":
                self.err("invalid character in string", k)
            out.append(c)
            k += 1


def _orig_pos(orig, pos):
    # map position in CRLF-normalized text back to the original text
    i = 0
    npos = 0
    while True:
        j = orig.find("\r\n", i)
        if j < 0 or npos + (j - i) >= pos:
            return i + (pos - npos)
        npos += (j - i) + 1
        i = j + 2


def loads(s, *, parse_float=float):
    if not isinstance(s, str):
        raise TypeError("Expected str object, not %r" % type(s).__name__)
    text = s.replace("\r\n", "\n") if "\r\n" in s else s
    p = _Parser(text, parse_float)
    try:
        return p.run()
    except _Err as e:
        pos = e.pos
        if text is not s:
            pos = _orig_pos(s, pos)
        raise TOMLDecodeError(e.msg, s, pos) from None
    except RecursionError:
        pos = p.i
        if text is not s:
            pos = _orig_pos(s, pos)
        raise TOMLDecodeError("document nested too deeply", s, pos) from None


def load(fp, *, parse_float=float):
    b = fp.read()
    if isinstance(b, str):
        raise TypeError("File must be opened in binary mode")
    if not isinstance(b, (bytes, bytearray, memoryview)):
        raise TypeError("File must be opened in binary mode")
    return loads(bytes(b).decode("utf-8"), parse_float=parse_float)
