"""TOML v1.1.0 parser for Tomlparse.

Entries: ``loads`` (text), ``load`` (binary file). Both return a plain ``dict``
or raise. The parser is written from the spec, not from any other TOML library.

Design notes:
  * Each table is tracked by a ``_Table`` node whose ``kind`` records how it was
    created: ``root``, ``header`` (defined by a [table] header), ``implicit``
    (created only as a parent of a header, may still be defined by a header),
    ``dotted`` (created by dotted keys), or ``inline`` (frozen inline table).
    Duplicate and redefinition rules are enforced from these kinds.
  * Arrays of tables are ``_ArrayOfTables`` nodes that hold the item tables.
  * Nested arrays and inline tables are parsed with an explicit stack, so
    deep nesting does not hit Python's recursion limit.
"""

import datetime as _dt
import re

from ._errors import TOMLDecodeError

# --- regular expressions -----------------------------------------------------

# Unquoted key characters: Latin letters, digits, underscore, hyphen.  # spec: N-000086
_BARE_KEY_RE = re.compile(r"[A-Za-z0-9_-]+")
# Runs of ordinary characters inside each string form (controls and the
# delimiters are excluded so the caller can handle them).
_BASIC_CHUNK_RE = re.compile(r'[^"\\\r\n\x00-\x08\x0b-\x1f\x7f]+')
_ML_BASIC_CHUNK_RE = re.compile(r'[^"\\\r\x00-\x08\x0b-\x1f\x7f]+')
_LITERAL_CHUNK_RE = re.compile(r"[^'\r\n\x00-\x08\x0b-\x1f\x7f]+")
_ML_LITERAL_CHUNK_RE = re.compile(r"[^'\r\x00-\x08\x0b-\x1f\x7f]+")
# A comment runs from # to the end of the line (CR LF counts as end of line).
_COMMENT_RE = re.compile(r"#[^\r\n]*")
_CONTROL_RE = re.compile(r"[\x00-\x08\x0b-\x1f\x7f]")
_HEX_DIGITS_RE = re.compile(r"[0-9A-Fa-f]+")

# Date-time, date and time forms.  Digits are [0-9] (not \d) so that Unicode
# digits are not accepted.  # spec: N-000151–N-000153, N-000154
_DATETIME_RE = re.compile(
    r"([0-9]{4})-([0-9]{2})-([0-9]{2})"
    r"(?:[Tt ]([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?"
    r"(?:([Zz])|([+-])([0-9]{2}):([0-9]{2}))?)?"
)
_TIME_RE = re.compile(r"([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?")

# Number token patterns (matched against a whole bare token).
_DEC_INT_RE = re.compile(r"[+-]?(?:0|[1-9](?:_?[0-9])*)")
_HEX_INT_RE = re.compile(r"0x[0-9a-fA-F](?:_?[0-9a-fA-F])*")
_OCT_INT_RE = re.compile(r"0o[0-7](?:_?[0-7])*")
_BIN_INT_RE = re.compile(r"0b[01](?:_?[01])*")
_FLOAT_RE = re.compile(
    r"[+-]?(?:0|[1-9](?:_?[0-9])*)"
    r"(?:\.[0-9](?:_?[0-9])*)?"
    r"(?:[eE][+-]?[0-9](?:_?[0-9])*)?"
)
_SPECIAL_FLOAT_RE = re.compile(r"[+-]?(?:inf|nan)")

# A bare value token ends at whitespace, a comma, a closing bracket or brace,
# or a comment.
_TOKEN_END = " \t\r\n,]}#"

_SIMPLE_ESCAPES = {
    "b": "\b",
    "t": "\t",
    "n": "\n",
    "f": "\f",
    "r": "\r",
    "e": "\x1b",  # spec: N-000137–N-000143 (TOML 1.1 \e)
    '"': '"',
    "\\": "\\",
}
_HEX_ESCAPE_WIDTH = {"x": 2, "u": 4, "U": 8}

_ARRAY = 0
_INLINE = 1


# --- table bookkeeping -------------------------------------------------------


class _Table(object):
    """A table node: the output dict plus how it was created."""

    __slots__ = ("kind", "data", "children")

    def __init__(self, kind):
        self.kind = kind
        self.data = {}
        # key -> _Table or _ArrayOfTables, for keys whose value is a table.
        # A key in ``data`` that is absent here holds a plain value.
        self.children = {}


class _ArrayOfTables(object):
    """An array of tables: the output list plus its item nodes."""

    __slots__ = ("data", "items")

    def __init__(self):
        self.data = []
        self.items = []


def _micro(fraction):
    # spec: N-000156, N-000157 — first six digits, padded on the right, truncated.
    if not fraction:
        return 0
    return int(fraction[:6].ljust(6, "0"))


class _Parser(object):
    def __init__(self, doc, parse_float):
        self.doc = doc
        self.n = len(doc)
        self.parse_float = parse_float

    # --- errors and low-level scanning --------------------------------------

    def error(self, msg, pos):  # spec: N-000198, N-000203
        raise TOMLDecodeError(msg, self.doc, pos)

    def skip_space(self, pos):
        doc = self.doc
        n = self.n
        while pos < n and doc[pos] in " \t":
            pos += 1
        return pos

    def skip_comment(self, pos):  # spec: N-000107–N-000109
        m = _COMMENT_RE.match(self.doc, pos)
        end = m.end()
        bad = _CONTROL_RE.search(self.doc, pos, end)
        if bad is not None:
            self.error("control character not allowed in a comment", bad.start())
        return end

    def skip_blank(self, pos):
        """Skip spaces, tabs, line endings, and comments (whitespace inside
        arrays and inline tables and between document lines)."""  # spec: N-000110, N-000112
        doc = self.doc
        n = self.n
        while pos < n:
            c = doc[pos]
            if c in " \t\n":
                pos += 1
            elif c == "\r":
                if doc.startswith("\n", pos + 1):  # spec: N-000111
                    pos += 2
                else:
                    self.error("bare carriage return", pos)
            elif c == "#":
                pos = self.skip_comment(pos)
            else:
                break
        return pos

    def end_of_line(self, pos):
        """After a key/value pair or a header: optional comment, then a line
        ending or the end of the document. Nothing else may share the line."""
        # spec: N-000122
        pos = self.skip_space(pos)
        if pos < self.n and self.doc[pos] == "#":
            pos = self.skip_comment(pos)
        if pos >= self.n:
            return pos
        c = self.doc[pos]
        if c == "\n":
            return pos + 1
        if c == "\r" and self.doc.startswith("\n", pos + 1):
            return pos + 2
        self.error("expected end of line", pos)

    def expect_equals(self, pos):
        pos = self.skip_space(pos)
        if self.doc[pos : pos + 1] != "=":
            self.error("expected '=' after key", pos)
        return self.skip_space(pos + 1)

    # --- keys ----------------------------------------------------------------

    def parse_key(self, pos):
        """Parse a possibly dotted key. Returns (list_of_parts, pos)."""
        doc = self.doc
        keys = []
        while True:
            pos = self.skip_space(pos)
            if doc.startswith('"""', pos) or doc.startswith("'''", pos):
                self.error("a multiline string cannot be used as a key", pos)  # spec: N-000122
            c = doc[pos : pos + 1]
            if c == '"':
                part, pos = self.basic_string(pos)  # spec: N-000089, N-000091, N-000142
            elif c == "'":
                part, pos = self.literal_string(pos)  # spec: N-000089, N-000090
            else:
                m = _BARE_KEY_RE.match(doc, pos)
                if m is None:
                    self.error("expected a key", pos)  # spec: N-000121
                part = m.group()
                pos = m.end()
            keys.append(part)
            pos = self.skip_space(pos)
            if doc[pos : pos + 1] == ".":  # spec: N-000093, N-000094
                pos += 1
                continue
            return keys, pos

    # --- strings -------------------------------------------------------------

    def escape(self, pos):
        """Read the escape sequence whose backslash is at ``pos``."""  # spec: N-000137–N-000141
        doc = self.doc
        c = doc[pos + 1 : pos + 2]
        simple = _SIMPLE_ESCAPES.get(c)
        if simple is not None:
            return simple, pos + 2
        width = _HEX_ESCAPE_WIDTH.get(c)
        if width is None:
            self.error("invalid escape sequence", pos)
        digits = doc[pos + 2 : pos + 2 + width]
        if len(digits) != width or _HEX_DIGITS_RE.fullmatch(digits) is None:
            self.error("invalid hexadecimal escape", pos)
        code = int(digits, 16)
        if code > 0x10FFFF or 0xD800 <= code <= 0xDFFF:  # spec: N-000177
            self.error("escape is not a Unicode scalar value", pos)
        return chr(code), pos + 2 + width

    def basic_string(self, pos):  # spec: N-000137, N-000138
        doc = self.doc
        n = self.n
        i = pos + 1
        buf = []
        while True:
            m = _BASIC_CHUNK_RE.match(doc, i)
            if m is not None:
                buf.append(m.group())
                i = m.end()
            if i >= n:
                self.error("unterminated string", i)
            c = doc[i]
            if c == '"':
                return "".join(buf), i + 1
            if c == "\\":
                text, i = self.escape(i)
                buf.append(text)
                continue
            # A newline or a control character inside a one-line string.
            self.error("invalid character in single-line string", i)  # spec: N-000178

    def literal_string(self, pos):  # spec: N-000129, N-000130
        doc = self.doc
        n = self.n
        i = pos + 1
        buf = []
        while True:
            m = _LITERAL_CHUNK_RE.match(doc, i)
            if m is not None:
                buf.append(m.group())
                i = m.end()
            if i >= n:
                self.error("unterminated string", i)
            if doc[i] == "'":
                return "".join(buf), i + 1
            self.error("invalid character in single-line string", i)  # spec: N-000178

    def _quote_run(self, i, quote):
        j = i
        doc = self.doc
        n = self.n
        while j < n and doc[j] == quote:
            j += 1
        return j - i

    def _skip_line_ending_ws(self, j):
        """After a line-ending backslash: skip the line ending and all whitespace
        up to the next non-whitespace character."""  # spec: N-000134
        doc = self.doc
        n = self.n
        while j < n:
            c = doc[j]
            if c in " \t\n":
                j += 1
            elif c == "\r" and doc.startswith("\n", j + 1):
                j += 2
            else:
                break
        return j

    def _ml_open(self, pos):
        """Skip the newline immediately after a multiline opening delimiter."""  # spec: N-000131
        if self.doc.startswith("\n", pos):
            return pos + 1
        if self.doc.startswith("\r\n", pos):
            return pos + 2
        return pos

    def ml_basic_string(self, pos):  # spec: N-000131–N-000136
        doc = self.doc
        n = self.n
        i = self._ml_open(pos + 3)
        buf = []
        while True:
            m = _ML_BASIC_CHUNK_RE.match(doc, i)
            if m is not None:
                buf.append(m.group())
                i = m.end()
            if i >= n:
                self.error("unterminated multiline string", i)
            c = doc[i]
            if c == '"':
                run = self._quote_run(i, '"')  # spec: N-000135
                if run < 3:
                    buf.append(c * run)
                    i += run
                    continue
                if run > 5:
                    self.error("too many quotation marks in a multiline string", i)
                buf.append('"' * (run - 3))
                return "".join(buf), i + run
            if c == "\\":
                j = i + 1
                while j < n and doc[j] in " \t":
                    j += 1
                if j < n and doc[j] in "\r\n":  # line-ending backslash
                    i = self._skip_line_ending_ws(j)
                    continue
                text, i = self.escape(i)
                buf.append(text)
                continue
            if c == "\n":
                buf.append("\n")
                i += 1
                continue
            if c == "\r":
                if doc.startswith("\n", i + 1):  # CR LF is one line feed
                    buf.append("\n")
                    i += 2
                    continue
                self.error("bare carriage return in a multiline string", i)  # spec: N-000178
            self.error("control character not allowed in a string", i)  # spec: N-000178

    def ml_literal_string(self, pos):  # spec: N-000129, N-000131
        doc = self.doc
        n = self.n
        i = self._ml_open(pos + 3)
        buf = []
        while True:
            m = _ML_LITERAL_CHUNK_RE.match(doc, i)
            if m is not None:
                buf.append(m.group())
                i = m.end()
            if i >= n:
                self.error("unterminated multiline string", i)
            c = doc[i]
            if c == "'":
                run = self._quote_run(i, "'")
                if run < 3:
                    buf.append(c * run)
                    i += run
                    continue
                if run > 5:
                    self.error("too many quotation marks in a multiline string", i)
                buf.append("'" * (run - 3))
                return "".join(buf), i + run
            if c == "\n":
                buf.append("\n")
                i += 1
                continue
            if c == "\r":
                if doc.startswith("\n", i + 1):
                    buf.append("\n")
                    i += 2
                    continue
                self.error("bare carriage return in a multiline string", i)
            self.error("control character not allowed in a string", i)

    # --- scalars -------------------------------------------------------------

    def _float(self, token, pos):
        # spec: N-000275–N-000277; the converter gets the characters as written.
        result = self.parse_float(token)
        if isinstance(result, (dict, list)):  # spec: N-000232, N-000233
            raise ValueError(
                "parse_float returned a dict or list at offset %d" % pos
            )
        return result

    def _number(self, token, pos):
        if _SPECIAL_FLOAT_RE.fullmatch(token):  # spec: N-000148–N-000150
            return self._float(token, pos)
        if _DEC_INT_RE.fullmatch(token):  # spec: N-000144, N-000145, N-000147
            return int(token.replace("_", ""))
        if _HEX_INT_RE.fullmatch(token):
            return int(token[2:].replace("_", ""), 16)
        if _OCT_INT_RE.fullmatch(token):
            return int(token[2:].replace("_", ""), 8)
        if _BIN_INT_RE.fullmatch(token):
            return int(token[2:].replace("_", ""), 2)
        if _FLOAT_RE.fullmatch(token):  # spec: N-000148
            return self._float(token, pos)
        self.error("invalid value", pos)

    def _datetime(self, m):  # spec: N-000151–N-000161
        year, month, day = int(m.group(1)), int(m.group(2)), int(m.group(3))
        try:
            date = _dt.date(year, month, day)
        except ValueError:
            self.error("invalid date", m.start())  # spec: N-000179
        if m.group(4) is None:
            return date, m.end()
        hour, minute = int(m.group(4)), int(m.group(5))
        second = int(m.group(6)) if m.group(6) is not None else 0
        if hour > 23 or minute > 59 or second > 59:  # spec: N-000180
            self.error("invalid time", m.start())
        micro = _micro(m.group(7))
        if m.group(8) is None and m.group(9) is None:
            return _dt.datetime(year, month, day, hour, minute, second, micro), m.end()
        if m.group(8) is not None:
            tz = _dt.timezone.utc
        else:
            off_h, off_m = int(m.group(10)), int(m.group(11))
            if off_h > 23 or off_m > 59:
                self.error("invalid UTC offset", m.start())
            delta = _dt.timedelta(hours=off_h, minutes=off_m)
            if m.group(9) == "-":
                delta = -delta
            tz = _dt.timezone(delta)
        return _dt.datetime(year, month, day, hour, minute, second, micro, tzinfo=tz), m.end()

    def _time(self, m):  # spec: N-000291, N-000292, N-000154
        hour, minute = int(m.group(1)), int(m.group(2))
        second = int(m.group(3)) if m.group(3) is not None else 0
        if hour > 23 or minute > 59 or second > 59:
            self.error("invalid time", m.start())
        return _dt.time(hour, minute, second, _micro(m.group(4))), m.end()

    def parse_scalar(self, pos):
        """Parse a non-container value at ``pos``. Returns (value, pos)."""
        doc = self.doc
        c = doc[pos : pos + 1]
        if c == '"':
            if doc.startswith('"""', pos):
                return self.ml_basic_string(pos)
            return self.basic_string(pos)
        if c == "'":
            if doc.startswith("'''", pos):
                return self.ml_literal_string(pos)
            return self.literal_string(pos)
        if c and c in "0123456789":
            m = _DATETIME_RE.match(doc, pos)
            if m is not None:
                return self._datetime(m)
            m = _TIME_RE.match(doc, pos)
            if m is not None:
                return self._time(m)
        j = pos
        n = self.n
        while j < n and doc[j] not in _TOKEN_END:
            j += 1
        token = doc[pos:j]
        if not token:
            self.error("expected a value", pos)
        if token == "true":  # spec: N-000124–N-000126
            return True, j
        if token == "false":
            return False, j
        return self._number(token, pos), j

    # --- containers and values ------------------------------------------------

    def parse_value(self, pos):
        """Parse any value at ``pos`` (arrays and inline tables included).

        Returns (value, node, pos). ``node`` is the ``_Table`` of an inline table
        (so the caller can attach it) or None.
        """
        doc = self.doc
        stack = []  # frames: [kind, container, unused, pending_keys]
        while True:
            # --- a value begins at pos ---
            c = doc[pos : pos + 1]
            if c == "[":  # spec: N-000105, N-000106
                arr = []
                pos = self.skip_blank(pos + 1)
                if doc[pos : pos + 1] != "]":
                    stack.append([_ARRAY, arr, None, None])
                    continue
                pos += 1
                value, node = arr, None
            elif c == "{":  # spec: N-000103, N-000104
                tbl = _Table("inline")
                pos = self.skip_blank(pos + 1)
                if doc[pos : pos + 1] != "}":
                    key_pos = pos
                    keys, pos = self.parse_key(pos)
                    pos = self.expect_equals(pos)
                    stack.append([_INLINE, tbl, key_pos, keys])
                    continue
                pos += 1
                value, node = tbl.data, tbl
            else:
                value, pos = self.parse_scalar(pos)
                node = None

            # --- a complete value is at hand: give it to the enclosing container ---
            while True:
                if not stack:
                    return value, node, pos
                frame = stack[-1]
                kind = frame[0]
                container = frame[1]
                if kind == _ARRAY:
                    container.append(value)
                    closer = "]"
                else:
                    self.assign(container, frame[3], value, node, frame[2])
                    closer = "}"
                pos = self.skip_blank(pos)
                c = doc[pos : pos + 1]
                if c == ",":
                    pos = self.skip_blank(pos + 1)
                    if doc[pos : pos + 1] == closer:  # trailing comma
                        pos += 1
                    else:
                        if kind == _INLINE:
                            key_pos = pos
                            keys, pos = self.parse_key(pos)
                            pos = self.expect_equals(pos)
                            frame[2] = key_pos
                            frame[3] = keys
                        break  # a value follows
                elif c == closer:
                    pos += 1
                else:
                    self.error("expected ',' or '%s'" % closer, pos)
                # the container is closed: it becomes a complete value
                stack.pop()
                if kind == _ARRAY:
                    value, node = container, None
                else:
                    value, node = container.data, container

    # --- assignments ---------------------------------------------------------

    def _attach(self, parent, key, child):
        parent.data[key] = child.data
        parent.children[key] = child

    def _descend_header(self, node, key, pos):  # spec: N-000096–N-000102
        child = node.children.get(key)
        if child is None:
            if key in node.data:
                self.error("key already has a value and cannot be a table", pos)  # spec: N-000116
            child = _Table("implicit")
            self._attach(node, key, child)
            return child
        if isinstance(child, _ArrayOfTables):
            return child.items[-1]  # spec: N-000100
        if child.kind == "inline":  # spec: N-000118, N-000120
            self.error("cannot add to an inline table", pos)
        return child

    def _descend_dotted(self, node, key, pos):  # spec: N-000093–N-000095, N-000119
        child = node.children.get(key)
        if child is None:
            if key in node.data:
                self.error("key already has a value", pos)  # spec: N-000114
            child = _Table("dotted")
            self._attach(node, key, child)
            return child
        if isinstance(child, _ArrayOfTables):
            self.error("cannot extend an array of tables with dotted keys", pos)  # spec: N-000122
        if child.kind == "implicit":
            child.kind = "dotted"
            return child
        if child.kind == "dotted":
            return child
        self.error("cannot extend a table already defined with dotted keys or a header", pos)  # spec: N-000115, N-000116

    def assign(self, table, keys, value, node, key_pos):
        """Store a key/value pair (with dotted keys) into ``table``."""
        for key in keys[:-1]:
            table = self._descend_dotted(table, key, key_pos)
        last = keys[-1]
        if last in table.data:  # spec: N-000113
            self.error("duplicate key", key_pos)
        if node is None:
            table.data[last] = value
        else:
            self._attach(table, last, node)

    def table_header(self, root, keys, key_pos):  # spec: N-000113–N-000117
        node = root
        for key in keys[:-1]:
            node = self._descend_header(node, key, key_pos)
        last = keys[-1]
        child = node.children.get(last)
        if child is None:
            if last in node.data:
                self.error("key already has a value", key_pos)
            child = _Table("header")
            self._attach(node, last, child)
            return child
        if isinstance(child, _ArrayOfTables) or child.kind != "implicit":
            self.error("table is already defined", key_pos)  # spec: N-000115
        child.kind = "header"  # a super-table declared later by its own header
        return child

    def aot_header(self, root, keys, key_pos):  # spec: N-000099–N-000102
        node = root
        for key in keys[:-1]:
            node = self._descend_header(node, key, key_pos)
        last = keys[-1]
        aot = node.children.get(last)
        if aot is None:
            if last in node.data:
                self.error("key already has a value", key_pos)
            aot = _ArrayOfTables()
            node.data[last] = aot.data
            node.children[last] = aot
        elif not isinstance(aot, _ArrayOfTables):
            self.error("cannot append to a table as an array of tables", key_pos)  # spec: N-000116
        item = _Table("header")
        aot.data.append(item.data)
        aot.items.append(item)
        return item

    # --- document ------------------------------------------------------------

    def parse_document(self):  # spec: N-000077–N-000122
        doc = self.doc
        n = self.n
        root = _Table("root")
        current = root
        pos = self.skip_blank(0)
        while pos < n:
            if doc[pos] == "[":
                if doc.startswith("[[", pos):
                    key_pos = self.skip_space(pos + 2)
                    keys, pos = self.parse_key(key_pos)
                    pos = self.skip_space(pos)
                    if not doc.startswith("]]", pos):
                        self.error("expected ']]' to close an array of tables", pos)
                    pos += 2
                    current = self.aot_header(root, keys, key_pos)
                else:
                    key_pos = self.skip_space(pos + 1)
                    keys, pos = self.parse_key(key_pos)
                    pos = self.skip_space(pos)
                    if doc[pos : pos + 1] != "]":
                        self.error("expected ']' to close a table header", pos)
                    pos += 1
                    current = self.table_header(root, keys, key_pos)
            else:
                key_pos = pos
                keys, pos = self.parse_key(pos)
                pos = self.expect_equals(pos)
                value, node, pos = self.parse_value(pos)
                self.assign(current, keys, value, node, key_pos)
            pos = self.end_of_line(pos)
            pos = self.skip_blank(pos)
        return root.data


# --- public entries ----------------------------------------------------------


def loads(s, *, parse_float=float):  # spec: N-000274–N-000298
    """Parse a TOML v1.1.0 document from a text string into a dict."""
    if not isinstance(s, str):  # spec: N-000213, N-000215
        raise TypeError("loads() expects a str, not %s" % type(s).__name__)
    return _Parser(s, parse_float).parse_document()


def load(fp, *, parse_float=float):  # spec: N-000299–N-000306
    """Parse a TOML v1.1.0 document from a file object opened in binary mode."""
    read = getattr(fp, "read", None)
    if read is None:  # spec: N-000300 — a path or other non-file is not accepted
        raise TypeError("load() expects a binary file object with read(), not %s" % type(fp).__name__)
    data = read()
    if isinstance(data, str):  # spec: N-000304
        raise TypeError("load() expects a file opened in binary mode, not text")
    if not isinstance(data, (bytes, bytearray, memoryview)):
        raise TypeError("load() expects bytes from fp.read(), not %s" % type(data).__name__)
    raw = bytes(data)
    try:
        text = raw.decode("utf-8")  # spec: N-000183, N-000193
    except UnicodeDecodeError as exc:
        # The spec does not say how undecodable bytes are reported. We use the
        # decode error with the replacement-decoded text as the document.
        doc = raw.decode("utf-8", "replace")
        pos = len(raw[: exc.start].decode("utf-8", "replace"))
        raise TOMLDecodeError("invalid UTF-8 in document", doc, pos)
    return loads(text, parse_float=parse_float)
