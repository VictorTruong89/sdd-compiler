"""The decode-error exception of Tomlparse.

Spec: Interface Contract, `tomlparse.TOMLDecodeError` (pack 05).
"""


class TOMLDecodeError(ValueError):  # spec: N-000307, N-000308
    """A document is not valid TOML v1.1.0.

    Constructed as ``TOMLDecodeError(msg, doc, pos)``. ``pos`` is a 0-based
    character offset into ``doc``. ``lineno`` (1-based) and ``colno``
    (1-based) are derived from ``pos``.
    """

    def __init__(self, msg, doc, pos):  # spec: N-000309, N-000310, N-000311, N-000313
        # Passing all three arguments to ValueError keeps pickling working:
        # the exception is rebuilt as cls(msg, doc, pos).
        ValueError.__init__(self, msg, doc, pos)
        self.msg = msg  # spec: N-000315
        self.doc = doc  # spec: N-000316
        self.pos = pos  # spec: N-000317
        # spec: N-000205, N-000206 — line is 1 + count of LF before pos;
        # column is 1 + characters between the last LF before pos (or the
        # start) and pos. Slicing clamps pos, so offsets at/after the end work.
        self.lineno = doc.count("\n", 0, pos) + 1  # spec: N-000318
        self.colno = pos - doc.rfind("\n", 0, pos)  # spec: N-000319

    def __str__(self):  # spec: N-000320, N-000321, N-000322, N-000323
        # Wording is free (spec: N-000218, N-000323). The location rules are fixed:
        # line/column for an interior offset, end-of-document for an offset at or
        # past the end.
        if self.pos >= len(self.doc):
            return "%s at end of document (line %d, column %d)" % (
                self.msg,
                self.lineno,
                self.colno,
            )
        return "%s (line %d, column %d)" % (self.msg, self.lineno, self.colno)
