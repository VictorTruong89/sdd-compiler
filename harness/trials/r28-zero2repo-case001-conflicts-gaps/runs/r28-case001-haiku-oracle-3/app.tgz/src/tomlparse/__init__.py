"""Tomlparse: a pure-Python parser for TOML v1.1.0.

Public surface (spec: Interface Contract, pack 02): ``loads``, ``load`` and
``TOMLDecodeError``, importable from the package root.  # spec: N-000266–N-000273
"""

from ._errors import TOMLDecodeError
from ._parser import load, loads

__all__ = ["loads", "load", "TOMLDecodeError"]
__version__ = "2.4.0"
