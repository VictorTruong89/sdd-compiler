"""Tests for Tomlparse, organised by the spec's feature points.

Run from /app with:  PYTHONPATH=src python -m pytest tests  (or unittest).
Each test name carries the spec id(s) it covers, e.g. test_N_000113_...
"""

import datetime
import io
import pickle
import unittest

import tomlparse
from tomlparse import TOMLDecodeError, load, loads


def _refused(text, **kw):
    try:
        loads(text, **kw)
    except TOMLDecodeError as exc:
        return exc
    raise AssertionError("document was accepted but should be refused: %r" % (text,))


class Surface(unittest.TestCase):
    # spec: N-000266, N-000270–N-000272
    def test_N_000270_root_names(self):
        self.assertIs(tomlparse.loads, loads)
        self.assertIs(tomlparse.load, load)
        self.assertTrue(issubclass(TOMLDecodeError, ValueError))

    # spec: N-000307, N-000308
    def test_N_000307_decode_error_is_value_error_not_type_error(self):
        self.assertTrue(issubclass(TOMLDecodeError, ValueError))
        self.assertFalse(issubclass(TOMLDecodeError, TypeError))
        self.assertFalse(issubclass(TOMLDecodeError, RecursionError))


class ParseStructure(unittest.TestCase):  # FP-01
    # spec: N-000082
    def test_N_000082_empty_and_comment_only_documents(self):
        self.assertEqual(loads(""), {})
        self.assertEqual(loads("   \t  "), {})
        self.assertEqual(loads("# only a comment"), {})
        self.assertEqual(loads("# only a comment\n"), {})

    # spec: N-000083, N-000084
    def test_N_000083_root_and_table_pairs(self):
        self.assertEqual(loads("a = 1\n[t]\nb = 2\n"), {"a": 1, "t": {"b": 2}})

    # spec: N-000085, N-000086, N-000087, N-000088
    def test_N_000085_keys_are_strings_and_case_sensitive(self):
        doc = "1234 = 1\ntrue = 2\ninf = 3\nnan = 4\nAbc = 5\nabc = 6\n"
        self.assertEqual(
            loads(doc),
            {"1234": 1, "true": 2, "inf": 3, "nan": 4, "Abc": 5, "abc": 6},
        )

    # spec: N-000089, N-000090, N-000091
    def test_N_000089_quoted_keys(self):
        self.assertEqual(loads('"a.b" = 1\n\'c d#\' = 2\n"é" = 3\n'), {"a.b": 1, "c d#": 2, "é": 3})
        self.assertEqual(loads('"" = 1'), {"": 1})

    # spec: N-000142
    def test_N_000142_basic_and_literal_keys_differ(self):
        self.assertEqual(loads('"\\u0041" = 1\n\'\\u0041\' = 2\n'), {"A": 1, "\\u0041": 2})

    # spec: N-000093, N-000094, N-000095
    def test_N_000093_dotted_keys_nest_with_spaces(self):
        self.assertEqual(loads('a . b . "c.d" = 1\na.e = 2\n'), {"a": {"b": {"c.d": 1}, "e": 2}})

    # spec: N-000096, N-000097, N-000098
    def test_N_000096_headers_create_parents_and_super_tables_declared_later(self):
        self.assertEqual(loads("[a.b.c]\nx = 1\n[a]\ny = 2\n"), {"a": {"y": 2, "b": {"c": {"x": 1}}}})

    # spec: N-000098, N-000021 (resolved as N-000098, see NOTES.md)
    def test_N_000098_header_declares_sub_table_of_dotted_table(self):
        doc = 'fruit.apple.color = "red"\n[fruit.apple.texture]\nsmooth = true\n'
        self.assertEqual(
            loads(doc),
            {"fruit": {"apple": {"color": "red", "texture": {"smooth": True}}}},
        )

    # spec: N-000099, N-000100, N-000101, N-000102
    def test_N_000099_array_of_tables_attaches_to_last_item(self):
        doc = "[[fruit]]\nname = 'a'\n[[fruit.variety]]\nx = 1\n[[fruit.variety]]\nx = 2\n[[fruit]]\nname = 'b'\n"
        self.assertEqual(
            loads(doc),
            {
                "fruit": [
                    {"name": "a", "variety": [{"x": 1}, {"x": 2}]},
                    {"name": "b"},
                ]
            },
        )

    # spec: N-000102
    def test_N_000102_aot_implies_plain_parent_tables(self):
        doc = "[[x.y]]\nq = 1\n[x]\nz = 2\n"
        self.assertEqual(loads(doc), {"x": {"y": [{"q": 1}], "z": 2}})

    # spec: N-000103, N-000104
    def test_N_000103_inline_tables(self):
        self.assertEqual(loads("a = {}\nb = {x = 1, y.z = 2}\n"), {"a": {}, "b": {"x": 1, "y": {"z": 2}}})
        self.assertEqual(
            loads("a = {\n  x = 1, # c\n  y = 2,\n}\n"),
            {"a": {"x": 1, "y": 2}},
        )

    # spec: N-000105, N-000106
    def test_N_000105_arrays(self):
        self.assertEqual(loads("a = []\nb = [1, 'x', [2, 3]]\nc = [\n 1, # c\n 2,\n]\n"),
                         {"a": [], "b": [1, "x", [2, 3]], "c": [1, 2]})

    # spec: N-000107, N-000108, N-000109
    def test_N_000107_comments(self):
        self.assertEqual(loads("a = 1 # note é\n# x = 2\n#y\n"), {"a": 1})
        self.assertEqual(loads('a = "x#y" # real comment\n'), {"a": "x#y"})

    # spec: N-000111, N-000112
    def test_N_000111_crlf_is_one_line_feed(self):
        self.assertEqual(loads("a = 1\r\nb = 2\r\n"), {"a": 1, "b": 2})
        self.assertEqual(loads('s = """\r\nx\r\ny"""\r\n'), {"s": "x\ny"})

    # spec: N-000113–N-000122 (refusals)
    def test_N_000113_duplicate_keys_refused(self):
        _refused("a = 1\na = 2\n")
        _refused("[t]\na = 1\na = 2\n")
        _refused("a.b = 1\na.b = 2\n")

    # spec: N-000115, N-000116
    def test_N_000115_table_redefinition_refused(self):
        _refused("[a]\n[a]\n")
        _refused("[a.b]\n[a]\n[a.b]\n")
        _refused("[a]\nb.c = 1\n[a.b]\n")  # b defined by dotted keys
        _refused("a.b = 1\n[a]\n")  # a defined by dotted keys

    # spec: N-000116
    def test_N_000116_value_replaced_by_table_refused(self):
        _refused("a = 1\n[a]\n")
        _refused("a = []\n[[a]]\n")
        _refused("a = {}\n[a.b]\n")
        _refused("a = {}\na.b = 1\n")

    # spec: N-000117, N-000118
    def test_N_000117_inline_tables_are_frozen(self):
        _refused("a = {x = 1}\na.y = 2\n")
        _refused("a = {x = 1}\n[a.y]\n")
        _refused("a = {x = 1, y = 2,,}\n")

    # spec: N-000119
    def test_N_000119_extending_aot_with_dotted_keys_refused(self):
        _refused("[[x.y]]\nq = 1\n[x]\ny.z = 2\n")  # y is an array of tables
        _refused("a = [{b = 1}]\na.c = 2\n")
        self.assertEqual(
            loads("[[a]]\nb.c = 1\n[[a]]\nb.c = 2\n"),
            {"a": [{"b": {"c": 1}}, {"b": {"c": 2}}]},
        )

    # spec: N-000120
    def test_N_000120_pair_without_key_or_value_refused(self):
        _refused(" = 1")
        _refused("a =")
        _refused("a\n")

    # spec: N-000121
    def test_N_000121_multiline_string_key_refused(self):
        _refused('"""a""" = 1')
        _refused("'''a''' = 1")

    # spec: N-000122
    def test_N_000122_header_and_pair_line_rules(self):
        _refused("[a] b = 1")
        _refused("[a\n]")
        _refused("a = 1 b = 2")
        _refused("[a] [b]")

    # spec: N-000110
    def test_N_000110_indentation_is_insignificant(self):
        self.assertEqual(loads("\t[t]\n\t\ta = 1\n"), {"t": {"a": 1}})


class ParseScalars(unittest.TestCase):  # FP-02
    # spec: N-000124, N-000125, N-000126
    def test_N_000124_booleans(self):
        v = loads("a = true\nb = false\n")
        self.assertIs(v["a"], True)
        self.assertIs(v["b"], False)
        _refused("a = True")
        _refused("a = TRUE")

    # spec: N-000127
    def test_N_000127_string_forms(self):
        self.assertEqual(loads("a = 'C:\\Users\\nodejs'\n")["a"], "C:\\Users\\nodejs")
        self.assertEqual(loads('a = "t\\tx"\n')["a"], "t\tx")
        self.assertEqual(loads("a = '''\nfoo'''\n")["a"], "foo")
        self.assertEqual(loads('a = """\nfoo"""\n')["a"], "foo")

    # spec: N-000129, N-000130
    def test_N_000129_literal_strings_have_no_escapes(self):
        self.assertEqual(loads("a = '\\n'\n")["a"], "\\n")
        self.assertEqual(loads("a = '''\\n'''\n")["a"], "\\n")

    # spec: N-000131, N-000132, N-000133
    def test_N_000131_first_newline_trimmed_and_others_kept(self):
        self.assertEqual(loads('a = """\n\nx\n"""\n')["a"], "\nx\n")
        self.assertEqual(loads("a = '''\n\nx\n'''\n")["a"], "\nx\n")

    # spec: N-000134, N-000136
    def test_N_000134_line_ending_backslash_trims_whitespace(self):
        self.assertEqual(loads('a = """one \\\n\n   two"""\n')["a"], "one two")
        self.assertEqual(loads('a = """x\\  \t\n  y\\\n"""\n')["a"], "xy")

    # spec: N-000135
    def test_N_000135_quotes_before_closing_delimiter(self):
        self.assertEqual(loads('a = """x""""\n')["a"], 'x"')
        self.assertEqual(loads('a = """x"""""\n')["a"], 'x""')
        self.assertEqual(loads("a = '''x''''\n")["a"], "x'")
        _refused('a = """x""""""\n')

    # spec: N-000137–N-000143
    def test_N_000137_basic_escapes(self):
        doc = 'a = "\\b\\t\\n\\f\\r\\e\\"\\\\\\x41\\u00e9\\U0001F600"\n'
        self.assertEqual(loads(doc)["a"], "\b\t\n\f\r\x1b\"\\A\u00e9\U0001F600")

    # spec: N-000139, N-000146 (hex digits case-insensitive)
    def test_N_000139_hex_digits_either_case(self):
        self.assertEqual(loads('a = "\\u00E9\\u00e9"\n')["a"], "éé")
        self.assertEqual(loads("a = 0xDEADbeef\n")["a"], 0xDEADBEEF)

    # spec: N-000144, N-000145, N-000147
    def test_N_000144_integers(self):
        self.assertEqual(loads("a = 0\nb = +0\nc = -0\nd = -17\ne = 1_000\n")["e"], 1000)
        self.assertEqual(loads("a = 0\nb = +0\nc = -0\nd = -17\n"), {"a": 0, "b": 0, "c": 0, "d": -17})
        self.assertEqual(loads("a = 0xff_ff\nb = 0o755\nc = 0b1010_1\n"),
                         {"a": 65535, "b": 493, "c": 21})
        self.assertIs(type(loads("a = 1")["a"]), int)

    # spec: N-000148, N-000149, N-000150
    def test_N_000148_floats(self):
        v = loads("a = 1.5\nb = -0.5\nc = 6.6e-34\nd = 1e3\ne = 1_0.0\n")
        self.assertEqual(v, {"a": 1.5, "b": -0.5, "c": 6.6e-34, "d": 1000.0, "e": 10.0})
        for x in v.values():
            self.assertIs(type(x), float)
        special = loads("a = inf\nb = +inf\nc = -inf\nd = nan\ne = +nan\nf = -nan\n")
        self.assertEqual(special["a"], float("inf"))
        self.assertEqual(special["b"], float("inf"))
        self.assertEqual(special["c"], float("-inf"))
        for k in ("d", "e", "f"):
            self.assertTrue(special[k] != special[k])

    # spec: N-000151, N-000152, N-000153
    def test_N_000151_date_times(self):
        v = loads(
            "a = 1979-05-27T07:32:00Z\n"
            "b = 1979-05-27 07:32:00-07:00\n"
            "c = 1979-05-27t07:32:00.5+01:30\n"
            "d = 1979-05-27T07:32:00\n"
            "e = 1979-05-27\n"
            "f = 07:32:00\n"
        )
        self.assertEqual(v["a"], datetime.datetime(1979, 5, 27, 7, 32, tzinfo=datetime.timezone.utc))
        self.assertEqual(v["a"].utcoffset(), datetime.timedelta(0))
        self.assertEqual(v["b"].utcoffset(), datetime.timedelta(hours=-7))
        self.assertEqual(v["c"].utcoffset(), datetime.timedelta(hours=1, minutes=30))
        self.assertEqual(v["c"].microsecond, 500000)
        self.assertIsNone(v["d"].tzinfo)
        self.assertIs(type(v["e"]), datetime.date)
        self.assertEqual(v["f"], datetime.time(7, 32, 0))
        self.assertIsNone(v["f"].tzinfo)

    # spec: N-000154, N-000155 (seconds optional)
    def test_N_000154_seconds_optional(self):
        v = loads("a = 1979-05-27T07:32Z\nb = 07:32\n")
        self.assertEqual(v["a"], datetime.datetime(1979, 5, 27, 7, 32, tzinfo=datetime.timezone.utc))
        self.assertEqual(v["b"], datetime.time(7, 32, 0))

    # spec: N-000156, N-000157 (first six digits, truncated)
    def test_N_000156_fraction_truncated_to_six_digits(self):
        v = loads("a = 00:00:00.9999999\nb = 00:00:00.1\nc = 00:00:00\n")
        self.assertEqual(v["a"].microsecond, 999999)
        self.assertEqual(v["b"].microsecond, 100000)
        self.assertEqual(v["c"].microsecond, 0)

    # spec: N-000159
    def test_N_000159_leap_day(self):
        self.assertEqual(loads("a = 2024-02-29")["a"], datetime.date(2024, 2, 29))

    # spec: N-000162–N-000180 (refusals of scalars)
    def test_N_000162_leading_zero_and_sign_rules(self):
        _refused("a = 01")
        _refused("a = 00")
        _refused("a = 0xG")
        _refused("a = 0X1F")
        _refused("a = +0x1")
        _refused("a = 0o8")
        _refused("a = 0b2")

    def test_N_000168_underscore_rules(self):
        _refused("a = 1__0")
        _refused("a = _1")
        _refused("a = 1_")
        _refused("a = 0x_1")

    def test_N_000173_float_digit_rules(self):
        _refused("a = 1.")
        _refused("a = .5")
        _refused("a = .")
        _refused("a = 01.5")

    def test_N_000174_escape_rules(self):
        _refused('a = "\\q"')
        _refused('a = "\\x4"')
        _refused('a = "\\uD800"')
        _refused('a = "\\U00110000"')
        _refused("a = '\\x41'x")

    def test_N_000178_control_characters(self):
        _refused('a = "\x01"')
        _refused('a = """\x7f"""')
        _refused("a = 'unterminated")
        _refused('a = "x\ny"')
        _refused('a = """a\rb"""')
        _refused('a = """a\\ x\nb"""')

    def test_N_000179_invalid_dates_and_times(self):
        _refused("a = 2023-02-29")
        _refused("a = 1979-13-01")
        _refused("a = 07:60:00")
        _refused("a = 24:00:00")
        _refused("a = 1979-05-27T07:32:00+24:00")

    # spec: N-000178 (tab is not a refused control character inside a string)
    def test_N_000178_tab_inside_string_is_raw_allowed(self):
        self.assertEqual(loads('a = "x\ty"\n')["a"], "x\ty")
        self.assertEqual(loads("a = 'x\ty'\n")["a"], "x\ty")


class ParseFiles(unittest.TestCase):  # FP-03
    # spec: N-000183, N-000184, N-000189
    def test_N_000183_binary_file_matches_text(self):
        doc = 'a = "é"\r\n[t]\r\nb = 1979-05-27\r\n'
        self.assertEqual(load(io.BytesIO(doc.encode("utf-8"))), loads(doc))

    # spec: N-000188
    def test_N_000188_empty_file_is_empty_dict(self):
        self.assertEqual(load(io.BytesIO(b"")), {})

    # spec: N-000190, N-000304
    def test_N_000190_text_mode_file_refused_with_type_error(self):
        with self.assertRaises(TypeError):
            load(io.StringIO("a = 1"))
        with self.assertRaises(TypeError):
            load(io.StringIO(""))
        self.assertFalse(issubclass(TypeError, TOMLDecodeError))

    # spec: N-000193, N-000195
    def test_N_000193_decode_error_from_file_has_decoded_text(self):
        with self.assertRaises(TOMLDecodeError) as cm:
            load(io.BytesIO("a = é\n".encode("utf-8") + b"x = = 1\n"))
        self.assertIsInstance(cm.exception.doc, str)
        self.assertEqual(cm.exception.doc, "a = é\nx = = 1\n")

    # spec: N-000196
    def test_N_000196_loads_refuses_bytes_and_files(self):
        with self.assertRaises(TypeError):
            loads(b"a = 1")
        with self.assertRaises(TypeError):
            loads(io.BytesIO(b"a = 1"))

    # spec: N-000181, N-000182, N-000220 (converter applies to load too)
    def test_N_000182_converter_applies_to_binary_entry(self):
        self.assertEqual(load(io.BytesIO(b"a = 1.5"), parse_float=str), {"a": "1.5"})


class ErrorsAndLocation(unittest.TestCase):  # FP-04, TOMLDecodeError
    # spec: N-000198, N-000201, N-000202
    def test_N_000198_failure_returns_nothing_and_is_value_error(self):
        with self.assertRaises(ValueError) as cm:
            loads("a = 1\nb = \n")
        self.assertIsInstance(cm.exception, TOMLDecodeError)

    # spec: N-000213, N-000214, N-000215
    def test_N_000213_wrong_python_type_is_type_error(self):
        for bad in (b"a = 1", 1, True, None, io.StringIO("a = 1")):
            with self.assertRaises(TypeError) as cm:
                loads(bad)
            self.assertNotIsInstance(cm.exception, TOMLDecodeError)

    # spec: N-000203, N-000204, N-000205, N-000206, N-000207, N-000208, N-000209
    def test_N_000203_location_is_line_and_column_of_offset(self):
        err = _refused("a = 1\nb = = 2\n")
        self.assertEqual(err.doc, "a = 1\nb = = 2\n")
        self.assertEqual(err.pos, 10)  # the second '=' on line 2
        self.assertEqual(err.lineno, 2)
        self.assertEqual(err.colno, 5)
        self.assertIn("line 2", str(err))
        self.assertIn("column 5", str(err))

    # spec: N-000207, N-000209, N-000322
    def test_N_000207_offset_at_end_mentions_end_of_document(self):
        err = _refused("a = ")
        self.assertGreaterEqual(err.pos, len(err.doc))
        self.assertIn("end of document", str(err))

    # spec: N-000210, N-000211, N-000212
    def test_N_000210_caller_can_construct_error(self):
        err = TOMLDecodeError("bad thing", "x = 1\nyy\n", 8)
        self.assertEqual(err.msg, "bad thing")
        self.assertEqual(err.doc, "x = 1\nyy\n")
        self.assertEqual(err.pos, 8)
        self.assertEqual(err.lineno, 2)
        self.assertEqual(err.colno, 3)
        self.assertIn("bad thing", str(err))
        self.assertIn("line 2", str(err))

    # spec: N-000205, N-000206 (first line, first column)
    def test_N_000206_column_on_first_line(self):
        err = TOMLDecodeError("m", "abc", 2)
        self.assertEqual((err.lineno, err.colno), (1, 3))

    # spec: N-000309–N-000313 (pickling keeps the three values)
    def test_N_000313_error_round_trips_through_pickle(self):
        err = TOMLDecodeError("m", "ab\ncd", 4)
        copy = pickle.loads(pickle.dumps(err))
        self.assertEqual((copy.msg, copy.doc, copy.pos), ("m", "ab\ncd", 4))
        self.assertEqual(str(copy), str(err))

    # spec: N-000216 (text-mode refusal is type error, not decode)
    def test_N_000216_text_file_is_not_decode_error(self):
        try:
            load(io.StringIO("a = 1"))
        except TypeError:
            pass
        except TOMLDecodeError:
            self.fail("text-mode refusal raised the decode error")


class FloatConverter(unittest.TestCase):  # FP-05
    # spec: N-000223, N-000224, N-000225, N-000226, N-000227
    def test_N_000223_converter_sees_floats_as_written(self):
        seen = []

        def conv(text):
            seen.append(text)
            return "F:" + text

        doc = "a = 1_0.5e+3\nb = [1.0, inf, -nan]\n[t]\nc = {x = 2.5}\n"
        v = loads(doc, parse_float=conv)
        self.assertEqual(v, {"a": "F:1_0.5e+3", "b": ["F:1.0", "F:inf", "F:-nan"], "t": {"c": {"x": "F:2.5"}}})
        self.assertEqual(seen, ["1_0.5e+3", "1.0", "inf", "-nan", "2.5"])

    # spec: N-000228, N-000229
    def test_N_000228_other_types_not_converted(self):
        calls = []

        def conv(text):
            calls.append(text)
            return text

        v = loads("a = 1\nb = 'x'\nc = true\nd = 1979-05-27\n", parse_float=conv)
        self.assertEqual(calls, [])
        self.assertEqual(v["a"], 1)

    # spec: N-000230, N-000231
    def test_N_000230_any_non_container_result_bound_as_returned(self):
        class Thing(object):
            pass

        marker = Thing()
        self.assertIs(loads("a = 1.0", parse_float=lambda s: marker)["a"], marker)

    # spec: N-000232, N-000233, N-000199
    def test_N_000232_container_result_is_value_error_not_decode(self):
        for result in ({}, [], type("D", (dict,), {})(), type("L", (list,), {})()):
            with self.assertRaises(ValueError) as cm:
                loads("a = 1.0", parse_float=lambda s, r=result: r)
            self.assertNotIsInstance(cm.exception, TOMLDecodeError)

    # spec: N-000222
    def test_N_000222_default_is_builtin_float(self):
        self.assertIs(type(loads("a = 1.0")["a"]), float)


class SetupAndLayout(unittest.TestCase):
    # spec: N-000060 (must not delegate parsing to the stdlib TOML module)
    def test_N_000060_does_not_delegate_to_stdlib_toml(self):
        import os

        src_dir = os.path.join(os.path.dirname(tomlparse.__file__))
        for name in os.listdir(src_dir):
            if name.endswith(".py"):
                with open(os.path.join(src_dir, name), encoding="utf-8") as fh:
                    text = fh.read()
                self.assertNotIn("import tomllib", text)
                self.assertNotIn("from tomllib", text)
                self.assertNotIn("import toml\n", text)

    # spec: N-000267 (imports from the source tree; the package is importable)
    def test_N_000267_package_imports_from_source_tree(self):
        self.assertTrue(tomlparse.__file__.endswith("__init__.py"))


class DeepNesting(unittest.TestCase):
    # spec: N-000081 (every document the spec allows is accepted)
    def test_N_000081_deep_arrays_do_not_hit_recursion_limit(self):
        depth = 5000
        doc = "a = " + "[" * depth + "]" * depth + "\n"
        v = loads(doc)
        cur = v["a"]
        for _ in range(depth - 1):
            self.assertEqual(len(cur), 1)
            cur = cur[0]
        self.assertEqual(cur, [])

    def test_N_000081_deep_inline_tables(self):
        depth = 3000
        doc = "a = " + "{x = " * depth + "1" + "}" * depth + "\n"
        v = loads(doc)
        cur = v["a"]
        for _ in range(depth - 1):
            cur = cur["x"]
        self.assertEqual(cur, {"x": 1})


class SurfaceAndBehaviour(unittest.TestCase):
    """Parser-only product, no writer, no I/O of its own, plain result types."""

    # spec: N-000001, N-000002, N-000003, N-000032, N-000064, N-000260, N-000063
    def test_N_000260_no_writer_or_cli_surface(self):
        for name in ("dump", "dumps", "dumps_toml", "encode", "write", "main"):
            self.assertFalse(hasattr(tomlparse, name), name)
        import os

        pkg = os.path.dirname(tomlparse.__file__)
        self.assertFalse(os.path.exists(os.path.join(pkg, "__main__.py")))

    # spec: N-000039, N-000268, N-000270
    def test_N_000039_public_names_only(self):
        self.assertEqual(sorted(tomlparse.__all__), ["TOMLDecodeError", "load", "loads"])

    # spec: N-000257, N-000065, N-000066
    def test_N_000257_no_comment_or_style_preservation(self):
        self.assertEqual(loads("# note\na = 1 # trailing\n"), {"a": 1})
        self.assertIs(type(loads("a = [1]")["a"]), list)
        self.assertIs(type(loads("[t]\nb=1")["t"]), dict)

    # spec: N-000259, N-000261 (parse entries do not print)
    def test_N_000259_entries_do_not_print(self):
        import contextlib

        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            loads("a = 1")
            load(io.BytesIO(b"a = 1"))
            with self.assertRaises(TOMLDecodeError):
                loads("a =")
        self.assertEqual(buf.getvalue(), "")

    # spec: N-000160, N-000161 (values copy and compare as standard values)
    def test_N_000160_values_copy_and_compare(self):
        import copy

        v = loads("a = 1979-05-27T07:32:00Z\nb = 07:32:00\nc = 1979-05-27\n")
        self.assertEqual(copy.deepcopy(v), v)
        self.assertEqual(v["c"], datetime.date(1979, 5, 27))

    # spec: N-000278, N-000279, N-000280, N-000281, N-000283, N-000286, N-000287
    def test_N_000278_result_shape(self):
        v = loads('a = {b = [ {c = "x"} ]}\n')
        self.assertIs(type(v), dict)
        self.assertTrue(all(type(k) is str for k in v))
        self.assertIs(type(v["a"]), dict)
        self.assertIs(type(v["a"]["b"]), list)
        self.assertIs(type(v["a"]["b"][0]["c"]), str)
        self.assertEqual(loads(""), {})

    # spec: N-000300, N-000302
    def test_N_000300_load_rejects_path_and_non_file(self):
        with self.assertRaises(TypeError):
            load("some_file.toml")
        with self.assertRaises(TypeError):
            load(b"a = 1")

    # spec: N-000065, N-000066
    def test_N_000066_result_is_plain_python(self):
        v = loads("a = 1979-05-27T07:32:00Z")
        self.assertIs(type(v), dict)
        self.assertIs(type(v["a"].tzinfo), datetime.timezone)



if __name__ == "__main__":
    unittest.main()
