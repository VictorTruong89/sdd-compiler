"""Tests for tomlparse, organized by spec feature point (FP-01..FP-05) and contract."""

import copy
import datetime
import io
import pickle
import unittest

import tomlparse
from tomlparse import TOMLDecodeError, load, loads


def bad(text):
    """Assert that ``text`` is refused with the decode error; return the error."""
    with_error = None
    try:
        loads(text)
    except TOMLDecodeError as exc:
        with_error = exc
    if with_error is None:
        raise AssertionError("expected TOMLDecodeError for %r" % text)
    return with_error


class PublicSurface(unittest.TestCase):
    # spec: N-000266 N-000267 N-000268 N-000269 N-000270 N-000271 N-000272 N-000307 N-000308
    def test_names_importable_from_root(self):
        self.assertTrue(callable(tomlparse.loads))
        self.assertTrue(callable(tomlparse.load))
        self.assertTrue(issubclass(tomlparse.TOMLDecodeError, ValueError))
        self.assertFalse(issubclass(tomlparse.TOMLDecodeError, TypeError))
        self.assertFalse(issubclass(tomlparse.TOMLDecodeError, RecursionError))

    # spec: N-000274 N-000278 N-000293
    def test_empty_documents(self):
        for doc in ["", "   \t", "# only a comment", "# c\n", "\n\n"]:
            self.assertEqual(loads(doc), {})
            self.assertIs(type(loads(doc)), dict)

    # spec: N-000297
    def test_wrong_python_type_is_type_error(self):
        for value in [b"a=1", 1, None, io.StringIO("a=1")]:
            with self.assertRaises(TypeError) as ctx:
                loads(value)
            self.assertNotIsInstance(ctx.exception, TOMLDecodeError)


class Structure(unittest.TestCase):
    # spec: N-000083 N-000084 N-000085 N-000086 N-000087 N-000088
    def test_root_pairs_and_tables(self):
        self.assertEqual(loads('a = 1\n[t]\nb = 2\n[u]\nc = 3\n'),
                         {"a": 1, "t": {"b": 2}, "u": {"c": 3}})

    # spec: N-000085 N-000086 N-000087 N-000088
    def test_keys_are_strings_and_case_sensitive(self):
        self.assertEqual(loads('1234 = 1\ntrue = 2\ninf = 3\nnan = 4\nA = 5\na = 6\n'),
                         {"1234": 1, "true": 2, "inf": 3, "nan": 4, "A": 5, "a": 6})

    # spec: N-000089 N-000090 N-000091 N-000092
    def test_quoted_keys(self):
        doc = '"" = 1\n"a.b" = 2\n\'#x y\' = 3\n"caf\\u00e9" = 4\n\'lit\\n\' = 5\n'
        self.assertEqual(loads(doc), {"": 1, "a.b": 2, "#x y": 3, "café": 4, "lit\\n": 5})

    # spec: N-000093 N-000094 N-000095
    def test_dotted_keys_and_headers(self):
        self.assertEqual(loads('a . b . c = 1\na.d = 2\n'),
                         {"a": {"b": {"c": 1}, "d": 2}})
        self.assertEqual(loads('[x . y]\nz = 1\n'), {"x": {"y": {"z": 1}}})

    # spec: N-000096 N-000097 N-000098
    def test_super_tables_and_dotted_subtable_header(self):
        self.assertEqual(loads('[a.b.c]\nv = 1\n[a]\nw = 2\n'),
                         {"a": {"b": {"c": {"v": 1}}, "w": 2}})
        self.assertEqual(loads('[fruit]\napple.color = "red"\n[fruit.apple.texture]\nsmooth = true\n'),
                         {"fruit": {"apple": {"color": "red", "texture": {"smooth": True}}}})

    # spec: N-000099 N-000100 N-000101 N-000102
    def test_arrays_of_tables(self):
        doc = ('[[fruit]]\nname = "apple"\n[fruit.physical]\ncolor = "red"\n'
               '[[fruit.variety]]\nname = "red delicious"\n[[fruit]]\nname = "banana"\n'
               '[[fruit.variety]]\nname = "plantain"\n')
        self.assertEqual(loads(doc), {"fruit": [
            {"name": "apple", "physical": {"color": "red"},
             "variety": [{"name": "red delicious"}]},
            {"name": "banana", "variety": [{"name": "plantain"}]},
        ]})

    # spec: N-000101 N-000102
    def test_aot_implied_parent_is_plain_table_and_later_declarable(self):
        self.assertEqual(loads('[[a.b]]\nx = 1\n[a]\ny = 2\n'),
                         {"a": {"b": [{"x": 1}], "y": 2}})

    # spec: N-000103 N-000104
    def test_inline_tables(self):
        self.assertEqual(loads('t = {}\nu = { a = 1, b.c = 2 }\n'),
                         {"t": {}, "u": {"a": 1, "b": {"c": 2}}})
        self.assertEqual(loads('t = {\n  a = 1, # c\n  b = 2,\n}\n'),
                         {"t": {"a": 1, "b": 2}})

    # spec: N-000105 N-000106
    def test_arrays(self):
        self.assertEqual(loads('a = []\nb = [1, "x", [2.5], {c = 1}]\n'),
                         {"a": [], "b": [1, "x", [2.5], {"c": 1}]})
        self.assertEqual(loads('a = [\n  1, # one\n  2,\n]\n'), {"a": [1, 2]})
        self.assertEqual(loads('a = [[1],[2]]\n'), {"a": [[1], [2]]})

    # spec: N-000107 N-000108 N-000109 N-000110
    def test_comments_and_indentation(self):
        self.assertEqual(loads('# top\n\t a=1#x\n  b = "#not"  # ok ü\n'),
                         {"a": 1, "b": "#not"})

    # spec: N-000111 N-000112
    def test_crlf_is_single_line_feed(self):
        self.assertEqual(loads('a = """x\r\ny"""\r\nb = 1\r\n'), {"a": "x\ny", "b": 1})
        self.assertEqual(loads('a = """\r\nx\r\n"""\r\n'), {"a": "x\n"})

    # spec: N-000113 N-000114 N-000115 N-000116 N-000117 N-000118 N-000119 N-000120 N-000121 N-000122
    def test_structural_conflicts_are_refused(self):
        for doc in [
            "a = 1\na = 2\n",                 # duplicate key
            "[a]\n[a]\n",                     # table defined twice
            "[a]\nb = 1\n[a.b]\n",            # reopening via header a value that exists
            "[a.b]\n[a]\nb.c = 1\n",          # dotted keys into header-defined table
            "a.b = 1\n[a]\n",                 # header reopens dotted-key table
            "a = 1\n[a]\n",                   # replacing a value with a table
            "a = 1\n[[a]]\n",                 # replacing a value with an array of tables
            "a = {b = 1}\na.c = 2\n",         # adding to an inline table
            "a = {b = 1}\n[a.c]\n",           # header into inline table
            "a = [{b = 1}]\n[[a]]\n",         # array of tables onto static array
            "[[x.a]]\n[x]\na.b = 1\n",        # dotted key through an array of tables
            "a = \n",                          # no value
            "= 1\n",                           # no key
            '"""k""" = 1\n',                   # multiline string as key
            "[a] b = 1\n",                     # pair after header on same line
            "[a\n",                            # unclosed header
            "[a]]\n",                          # header with stray bracket
            "a = 1 b = 2\n",                   # two pairs on one line
        ]:
            with self.subTest(doc=doc):
                bad(doc)

    # spec: N-000114 N-000115 N-000116
    def test_dotted_key_into_implicit_table_is_allowed_then_not_headerable(self):
        self.assertEqual(loads('[a.b.c]\nx = 1\n[a]\nb.d = 2\n'),
                         {"a": {"b": {"c": {"x": 1}, "d": 2}}})
        bad('[a.b.c]\nx = 1\n[a]\nb.d = 2\n[a.b]\n')

    # spec: N-000105
    def test_array_trailing_comma_accepted(self):
        self.assertEqual(loads('a = [1, 2,]'), {"a": [1, 2]})


class Scalars(unittest.TestCase):
    # spec: N-000124 N-000125 N-000126 N-000166
    def test_booleans(self):
        result = loads("a = true\nb = false\n")
        self.assertIs(result["a"], True)
        self.assertIs(result["b"], False)
        for doc in ["a = True\n", "a = TRUE\n", "a = truex\n"]:
            bad(doc)

    # spec: N-000127 N-000128 N-000129 N-000130 N-000131 N-000132 N-000133 N-000134 N-000135 N-000136 N-000137 N-000138 N-000139 N-000140 N-000141 N-000142 N-000143
    def test_strings(self):
        self.assertEqual(loads('a = "tab\\there"\n'), {"a": "tab\there"})
        self.assertEqual(loads(r'a = "\b\t\n\f\r\e\"\\"'), {"a": "\b\t\n\f\r\x1b\"\\"})
        self.assertEqual(loads(r'a = "\x41\u00e9\U0001F600"'), {"a": "Aé😀"})
        self.assertEqual(loads(r'a = "\u00E9\U0001f600\x4A"'), {"a": "é😀J"})  # hex either case
        self.assertEqual(loads("a = 'C:\\path\\n'\n"), {"a": "C:\\path\\n"})
        self.assertEqual(loads("a = '''\nkeep\\n\n'''\n"), {"a": "keep\\n\n"})
        self.assertEqual(loads('a = """\nline1\nline2"""\n'), {"a": "line1\nline2"})
        self.assertEqual(loads('a = """one\\\n   two\\\n\n  three"""\n'), {"a": "onetwothree"})
        self.assertEqual(loads('a = """x""""\n'), {"a": 'x"'})
        self.assertEqual(loads('a = """x"""""\n'), {"a": 'x""'})
        self.assertEqual(loads("a = ''''x'''\n"), {"a": "'x"})
        self.assertEqual(loads('a = "é\ttab"\n'), {"a": "é\ttab"})  # raw tab allowed

    # spec: N-000141 N-000178 N-000179
    def test_string_errors(self):
        for doc in [
            'a = "\\q"\n',          # unknown escape
            'a = "\\x4"\n',         # short \x
            'a = "\\xZZ"\n',        # non-hex
            'a = "\\uD800"\n',      # surrogate
            'a = "\\U00110000"\n',  # beyond scalar range
            'a = "unterminated\n',
            "a = 'x\n",
            'a = "bell\x07"\n',     # raw control character
            'a = """x\ry"""\n',     # lone carriage return
            'a = """x\\   y"""\n',  # line-ending backslash without line ending
            'a = """x"""""""\n',    # too many closing quotes
            'a = """unterminated\n',
        ]:
            with self.subTest(doc=doc):
                bad(doc)

    # spec: N-000144 N-000145 N-000146 N-000147
    def test_integers(self):
        self.assertEqual(loads("a = 0\nb = +99\nc = -17\nd = 1_000\ne = +0\nf = -0\n"),
                         {"a": 0, "b": 99, "c": -17, "d": 1000, "e": 0, "f": 0})
        self.assertEqual(loads("a = 0xDEAD_beef\nb = 0o755\nc = 0b1101_0110\n"),
                         {"a": 0xDEADBEEF, "b": 0o755, "c": 0b11010110})
        self.assertEqual(loads("a = 0xFF\n"), {"a": 255})
        self.assertIs(type(loads("a = 1\n")["a"]), int)
        self.assertIsNot(type(loads("a = 1\n")["a"]), bool)

    # spec: N-000167 N-000168 N-000169 N-000170 N-000171 N-000172
    def test_integer_errors(self):
        for doc in ["a = 01\n", "a = -01\n", "a = 0X1F\n", "a = 0O7\n", "a = 0B1\n",
                    "a = 1_\n", "a = _1\n", "a = 1__0\n", "a = +0x1\n", "a = -0o7\n",
                    "a = 0x_1\n", "a = 0b2\n", "a = 0o8\n", "a = 0xG\n"]:
            with self.subTest(doc=doc):
                bad(doc)

    # spec: N-000148 N-000149 N-000150 N-000173 N-000287 N-000289
    def test_floats(self):
        result = loads("a = 3.14\nb = -0.5\nc = 6.626e-34\nd = 1e3\ne = 1_000.0\n"
                       "f = inf\ng = -inf\nh = +inf\ni = nan\nj = +nan\nk = -nan\n")
        self.assertEqual(result["a"], 3.14)
        self.assertEqual(result["b"], -0.5)
        self.assertEqual(result["c"], 6.626e-34)
        self.assertEqual(result["d"], 1000.0)
        self.assertIsInstance(result["d"], float)
        self.assertEqual(result["e"], 1000.0)
        self.assertEqual(result["f"], float("inf"))
        self.assertEqual(result["g"], float("-inf"))
        self.assertEqual(result["h"], float("inf"))
        self.assertNotEqual(result["i"], result["i"])
        self.assertNotEqual(result["j"], result["j"])
        self.assertNotEqual(result["k"], result["k"])

    # spec: N-000173 N-000171
    def test_float_errors(self):
        for doc in ["a = .5\n", "a = 1.\n", "a = .\n", "a = 01.5\n", "a = 1e\n",
                    "a = infinity\n", "a = 1._5\n", "a = 1.5_\n"]:
            with self.subTest(doc=doc):
                bad(doc)

    # spec: N-000220 N-000223 N-000224 N-000225 N-000226 N-000227 N-000229
    def test_parse_float_converter(self):
        seen = []

        def conv(text):
            seen.append(text)
            return ("F", text)

        result = loads('a = 1.5e+3\nb = [-1_0.0, inf]\nc = {d = +nan}\ne = 7\n'
                       'f = 1979-05-27\n', parse_float=conv)
        self.assertEqual(seen, ["1.5e+3", "-1_0.0", "inf", "+nan"])
        self.assertEqual(result["a"], ("F", "1.5e+3"))
        self.assertEqual(result["b"], [("F", "-1_0.0"), ("F", "inf")])
        self.assertEqual(result["c"], {"d": ("F", "+nan")})
        self.assertEqual(result["e"], 7)

    # spec: N-000230 N-000231 N-000232 N-000233
    def test_parse_float_returning_container_is_value_error(self):
        for ret in [{}, [], {"x": 1}, type("D", (dict,), {})(), type("L", (list,), {})()]:
            with self.subTest(ret=ret):
                with self.assertRaises(ValueError) as ctx:
                    loads("a = 1.0\n", parse_float=lambda t, r=ret: r)
                self.assertNotIsInstance(ctx.exception, TOMLDecodeError)

    # spec: N-000230
    def test_parse_float_result_bound_as_returned(self):
        obj = object()
        self.assertIs(loads("a = 1.0\n", parse_float=lambda t: obj)["a"], obj)
        self.assertEqual(loads("a = 1.0\n", parse_float=lambda t: "s")["a"], "s")

    # spec: N-000151 N-000152 N-000153 N-000288
    def test_offset_datetimes(self):
        cases = {
            "a = 1979-05-27T07:32:00Z": (1979, 5, 27, 7, 32, 0, 0, 0),
            "a = 1979-05-27t07:32:00z": (1979, 5, 27, 7, 32, 0, 0, 0),
            "a = 1979-05-27 07:32:00Z": (1979, 5, 27, 7, 32, 0, 0, 0),
            "a = 1979-05-27T00:32:00-07:00": (1979, 5, 27, 0, 32, 0, 0, -7 * 3600),
            "a = 1979-05-27T07:32:00+05:30": (1979, 5, 27, 7, 32, 0, 0, 5.5 * 3600),
        }
        for doc, (y, mo, d, h, mi, s, us, off) in cases.items():
            with self.subTest(doc=doc):
                value = loads(doc)["a"]
                self.assertIsInstance(value, datetime.datetime)
                self.assertEqual(value, datetime.datetime(y, mo, d, h, mi, s, us,
                                                          tzinfo=value.tzinfo))
                self.assertEqual(value.utcoffset(), datetime.timedelta(seconds=off))

    # spec: N-000289 N-000290 N-000291 N-000292 N-000154 N-000155 N-000156 N-000157 N-000158
    def test_local_date_time_date_and_time(self):
        result = loads("a = 1979-05-27T07:32:00\nb = 1979-05-27\nc = 07:32:00\n"
                       "d = 07:32:00.999999\ne = 1979-05-27 07:32\nf = 07:32\n")
        self.assertEqual(result["a"], datetime.datetime(1979, 5, 27, 7, 32, 0))
        self.assertIsNone(result["a"].tzinfo)
        self.assertEqual(result["b"], datetime.date(1979, 5, 27))
        self.assertIs(type(result["b"]), datetime.date)
        self.assertEqual(result["c"], datetime.time(7, 32, 0))
        self.assertIsNone(result["c"].tzinfo)
        self.assertEqual(result["d"], datetime.time(7, 32, 0, 999999))
        self.assertEqual(result["e"], datetime.datetime(1979, 5, 27, 7, 32, 0))
        self.assertEqual(result["f"], datetime.time(7, 32, 0))

    # spec: N-000157 N-000158
    def test_fraction_truncated_to_microseconds(self):
        result = loads("a = 07:32:00.5\nb = 07:32:00.1234567\nc = 07:32:00.1234569\n"
                       "d = 1979-05-27T07:32:00.12Z\n")
        self.assertEqual(result["a"].microsecond, 500000)
        self.assertEqual(result["b"].microsecond, 123456)
        self.assertEqual(result["c"].microsecond, 123456)
        self.assertEqual(result["d"].microsecond, 120000)

    # spec: N-000159
    def test_leap_day(self):
        self.assertEqual(loads("a = 2024-02-29\n")["a"], datetime.date(2024, 2, 29))
        bad("a = 2023-02-29\n")

    # spec: N-000160 N-000161
    def test_values_copy_and_compare(self):
        value = loads("a = 1979-05-27T07:32:00Z\n")["a"]
        self.assertEqual(copy.deepcopy(value), value)

    # spec: N-000179 N-000180
    def test_date_time_range_errors(self):
        for doc in ["a = 1979-13-01\n", "a = 1979-05-32\n", "a = 07:60:00\n",
                    "a = 24:00:00\n", "a = 07:32:60\n", "a = 1979-05-27T07:32:00+24:00\n",
                    "a = 1979-05-27T07:32:00+05:60\n", "a = 1979-05-27T07:32:00X\n",
                    "a = 1979-05-27T\n", "a = 1979-05-27T07:32:00.\n"]:
            with self.subTest(doc=doc):
                bad(doc)

    # spec: N-000162 N-000163 N-000164
    def test_scalar_errors_are_decode_errors(self):
        bad("a = @\n")
        bad("a = \n")


class Errors(unittest.TestCase):
    # spec: N-000203 N-000204 N-000205 N-000206 N-000207 N-000208 N-000209
    def test_location_attributes(self):
        err = bad("a = 1\nb = 2\nc = @\n")
        self.assertEqual(err.doc, "a = 1\nb = 2\nc = @\n")
        self.assertEqual(err.pos, 16)
        self.assertEqual(err.lineno, 3)
        self.assertEqual(err.colno, 5)
        self.assertIn("line 3", str(err))
        self.assertIn("column 5", str(err))

    # spec: N-000209
    def test_end_of_document_report(self):
        err = bad("a = [1,")
        self.assertGreaterEqual(err.pos, len(err.doc))
        self.assertIn("end of document", str(err))

    # spec: N-000210 N-000211 N-000212
    def test_constructed_error(self):
        err = TOMLDecodeError("bad thing", "x = 1\ny = 2", 8)
        self.assertEqual(err.msg, "bad thing")
        self.assertEqual(err.doc, "x = 1\ny = 2")
        self.assertEqual(err.pos, 8)
        self.assertEqual(err.lineno, 2)
        self.assertEqual(err.colno, 3)
        self.assertIn("bad thing", str(err))
        self.assertIn("line 2", str(err))
        self.assertIsInstance(err, ValueError)

    # spec: N-000217 N-000219
    def test_error_pickles(self):
        err = TOMLDecodeError("m", "a\nb", 2)
        again = pickle.loads(pickle.dumps(err))
        self.assertEqual((again.msg, again.doc, again.pos, again.lineno, again.colno),
                         ("m", "a\nb", 2, 2, 1))

    # spec: N-000198 N-000199 N-000200 N-000201 N-000202
    def test_no_mapping_on_failure_and_is_value_error(self):
        with self.assertRaises(ValueError):
            loads("a = 1\nb = [")

    # spec: N-000207 N-000213 N-000215
    def test_location_with_crlf_maps_to_original_text(self):
        err = bad("a = 1\r\nb = @\r\n")
        self.assertEqual(err.doc, "a = 1\r\nb = @\r\n")
        self.assertEqual(err.lineno, 2)
        self.assertEqual(err.colno, 5)


class Load(unittest.TestCase):
    # spec: N-000181 N-000182 N-000183 N-000184 N-000185 N-000187 N-000188 N-000189
    def test_binary_file_objects(self):
        self.assertEqual(load(io.BytesIO(b'a = "\xc3\xa9"\n')), {"a": "é"})
        self.assertEqual(load(io.BytesIO(b"")), {})
        self.assertEqual(load(io.BytesIO(b"a = 1\r\nb = 2")), {"a": 1, "b": 2})

    # spec: N-000190 N-000191 N-000192 N-000216
    def test_text_mode_refused(self):
        with self.assertRaises(TypeError) as ctx:
            load(io.StringIO("a = 1"))
        self.assertNotIsInstance(ctx.exception, TOMLDecodeError)
        with self.assertRaises(TypeError):
            load(io.StringIO(""))

    # spec: N-000193 N-000194 N-000195
    def test_invalid_toml_in_file_is_decode_error_with_text_doc(self):
        with self.assertRaises(TOMLDecodeError) as ctx:
            load(io.BytesIO(b"a = 1\nb = @\n"))
        self.assertIsInstance(ctx.exception.doc, str)
        self.assertEqual(ctx.exception.lineno, 2)

    # spec: N-000193 N-000196
    def test_invalid_utf8_is_decode_error(self):
        with self.assertRaises(TOMLDecodeError):
            load(io.BytesIO(b'a = "\xff"'))

    # spec: N-000220 N-000182
    def test_parse_float_applies_to_file_entry(self):
        self.assertEqual(load(io.BytesIO(b"a = 1.5\n"), parse_float=lambda t: t),
                         {"a": "1.5"})

    # spec: N-000216 N-000299 N-000300
    def test_file_entry_accepts_disk_binary_file(self):
        import os
        import tempfile
        fd, path = tempfile.mkstemp(suffix=".toml")
        os.close(fd)
        try:
            with open(path, "wb") as fh:
                fh.write(b"x = [1, 2]\n")
            with open(path, "rb") as fh:
                self.assertEqual(load(fh), {"x": [1, 2]})
        finally:
            os.remove(path)


class StringEntry(unittest.TestCase):
    # spec: N-000196 N-000213 N-000214
    def test_bytes_and_files_refused_by_loads(self):
        for value in [b"a = 1", io.BytesIO(b"a = 1")]:
            with self.assertRaises(TypeError):
                loads(value)


if __name__ == "__main__":
    unittest.main()
