"""The decode error raised for invalid TOML."""


class TOMLDecodeError(ValueError):
    """Raised when a document is not valid TOML v1.1.0.

    Constructed as ``TOMLDecodeError(msg, doc, pos)``: ``msg`` is the
    unformatted reason, ``doc`` the document text, and ``pos`` a 0-based
    character offset into ``doc``. ``lineno`` (1-based line) and ``colno``
    (1-based column) are derived from ``pos``.
    """

    # spec: N-000307 N-000308 N-000309 N-000310 N-000311 N-000312 N-000313
    # spec: N-000314 N-000315 N-000316 N-000317 N-000318 N-000319
    # spec: N-000198 N-000203 N-000204 N-000205 N-000206 N-000210 N-000211 N-000212
    def __init__(self, msg, doc, pos):
        ValueError.__init__(self, msg, doc, pos)
        self.msg = msg
        self.doc = doc
        self.pos = pos
        # line feeds strictly before pos, plus one
        self.lineno = doc.count("\n", 0, pos) + 1
        # characters between the last line feed before pos (or document start) and pos, plus one
        self.colno = pos - doc.rfind("\n", 0, pos)

    # spec: N-000320 N-000321 N-000322 N-000323 N-000208 N-000209 N-000219 N-000218
    def __str__(self):
        if self.pos >= len(self.doc):
            location = "end of document, line %d, column %d" % (self.lineno, self.colno)
        else:
            location = "line %d, column %d" % (self.lineno, self.colno)
        return "%s (%s)" % (self.msg, location)

    def __reduce__(self):
        return (self.__class__, (self.msg, self.doc, self.pos))
