"""Recursive-descent parser for TOML v1.1.0 text.

The parser builds plain ``dict`` and ``list`` objects directly. Table
bookkeeping (explicitly defined by a header, created by dotted keys,
implicit super-table, frozen inline table, array of tables) is kept in a
side table keyed by ``id()`` of each container; every entry keeps its
container alive, so the ids stay valid for the whole parse.
"""

import bisect
import datetime
import re

from ._errors import TOMLDecodeError


class _ParseError(Exception):
    """Internal failure with an offset into the normalized text."""

    def __init__(self, msg, pos):
        Exception.__init__(self, msg, pos)
        self.msg = msg
        self.pos = pos


class _Meta(object):
    __slots__ = ("obj", "header", "dotted", "implicit", "inline", "aot")

    def __init__(self, obj):
        self.obj = obj
        self.header = False    # defined by a [table] or [[array]] header
        self.dotted = False    # created or extended by dotted keys
        self.implicit = False  # super-table created by a header path; not yet defined
        self.inline = False    # inline table: frozen once written
        self.aot = False       # list is an array of tables


# Runs of characters that need no special handling, per context.
_BASIC_RUN = re.compile(r'[^"\\\x00-\x08\x0a-\x1f\x7f]*')
_MBASIC_RUN = re.compile(r'[^"\\\x00-\x08\x0b-\x1f\x7f]*')
_LIT_RUN = re.compile(r"[^'\x00-\x08\x0a-\x1f\x7f]*")
_MLIT_RUN = re.compile(r"[^'\x00-\x08\x0b-\x1f\x7f]*")
_COMMENT_RUN = re.compile(r"[^\x00-\x08\x0a-\x1f\x7f]*")
_WS_RUN = re.compile(r"[ \t]*")
_WS_NL_RUN = re.compile(r"[ \t\n]*")
_BARE_KEY = re.compile(r"[A-Za-z0-9_-]+")
_FRACTION_DIGITS = 6  # microsecond digits kept from a fraction

_DATETIME = re.compile(
    r"(\d{4})-(\d{2})-(\d{2})"
    r"(?:[Tt ](\d{2}):(\d{2})(?::(\d{2})(?:\.(\d+))?)?"
    r"(?:([Zz])|([+-])(\d{2}):(\d{2}))?)?"
)
_LOCAL_TIME = re.compile(r"(\d{2}):(\d{2})(?::(\d{2})(?:\.(\d+))?)?")
_NUMBER = re.compile(
    r"(?P<hex>0x[0-9A-Fa-f](?:_?[0-9A-Fa-f])*)"
    r"|(?P<oct>0o[0-7](?:_?[0-7])*)"
    r"|(?P<bin>0b[01](?:_?[01])*)"
    r"|(?P<special>[+-]?(?:inf|nan))"
    r"|(?P<dec>[+-]?(?:0|[1-9](?:_?[0-9])*)"
    r"(?P<frac>\.[0-9](?:_?[0-9])*)?"
    r"(?P<exp>[eE][+-]?[0-9](?:_?[0-9])*)?)"
)

_ESCAPES = {
    "b": "\b",
    "t": "\t",
    "n": "\n",
    "f": "\f",
    "r": "\r",
    "e": "\x1b",
    '"': '"',
    "\\": "\\",
}
_ESCAPE_WIDTHS = {"x": 2, "u": 4, "U": 8}
_HEX_DIGITS = frozenset("0123456789abcdefABCDEF")
_VALUE_END = frozenset(" \t\n,]}#")


def _normalize(text):
    """Turn CR LF pairs into LF.

    Returns ``(normalized_text, lf_positions)``; ``lf_positions`` is None when
    nothing changed, otherwise the sorted normalized indices of line feeds that
    came from CR LF pairs, used to map offsets back to the original text.
    """
    if "\r" not in text:
        return text, None
    starts = [m.start() for m in re.finditer("\r\n", text)]
    if not starts:
        return text, None
    lf_positions = [k - idx for idx, k in enumerate(starts)]
    return text.replace("\r\n", "\n"), lf_positions


class _Parser(object):
    def __init__(self, text, parse_float):
        self.s = text
        self.n = len(text)
        self.i = 0
        self.parse_float = parse_float
        self.meta = {}
        self.root = self._new_table()

    # ----------------------------------------------------------- bookkeeping

    def _new_table(self, header=False, dotted=False, implicit=False):
        table = {}
        m = _Meta(table)
        m.header = header
        m.dotted = dotted
        m.implicit = implicit
        self.meta[id(table)] = m
        return table

    def _new_list(self, aot):
        arr = []
        m = _Meta(arr)
        m.aot = aot
        self.meta[id(arr)] = m
        return arr

    def _meta(self, container):
        return self.meta[id(container)]

    # ------------------------------------------------------------- utilities

    def _err(self, msg, pos=None):
        raise _ParseError(msg, self.i if pos is None else pos)

    def _peek(self):
        return self.s[self.i] if self.i < self.n else ""

    def _skip_ws(self):
        self.i = _WS_RUN.match(self.s, self.i).end()

    # spec: N-000107 N-000108 N-000109 N-000111 N-000112
    def _comment_end(self, i):
        """Index just past the comment starting at ``i`` (the ``#``)."""
        end = _COMMENT_RUN.match(self.s, i + 1).end()
        if end < self.n and self.s[end] != "\n":
            self._err("control character not permitted in comment", end)
        return end

    def _skip_ws_nl(self):
        """Skip spaces, tabs, line feeds and comments."""
        s = self.s
        while True:
            self.i = _WS_RUN.match(s, self.i).end()
            if self.i < self.n and s[self.i] == "\n":
                self.i += 1
            elif self.i < self.n and s[self.i] == "#":
                self.i = self._comment_end(self.i)
            else:
                return

    def _expect(self, ch):
        if self._peek() != ch:
            self._err("expected %r" % ch)
        self.i += 1

    def _end_of_line(self):
        """After a header or key/value pair: only a comment, then newline or end."""
        self._skip_ws()
        if self._peek() == "#":
            self.i = self._comment_end(self.i)
        if self.i < self.n:
            if self.s[self.i] != "\n":
                self._err("expected end of line")
            self.i += 1

    def _check_value_end(self, end):
        if end < self.n and self.s[end] not in _VALUE_END:
            self._err("invalid value", end)
        self.i = end

    # ------------------------------------------------------------- document

    # spec: N-000077 N-000080 N-000081 N-000082 N-000083 N-000084 N-000110 N-000111 N-000112
    def parse_document(self):
        root = self.root
        cur = root
        while True:
            self._skip_ws()
            if self.i >= self.n:
                break
            c = self.s[self.i]
            if c == "\n":
                self.i += 1
                continue
            if c == "#":
                self.i = self._comment_end(self.i)
                continue
            if c == "[":
                if self.s.startswith("[[", self.i):
                    cur = self._array_table_header()
                else:
                    cur = self._table_header()
            else:
                keys = self._key()
                self._skip_ws()
                self._expect("=")
                self._skip_ws()
                value = self._value()
                self._assign(cur, keys, value)
            self._end_of_line()
        return root

    # ------------------------------------------------------------ table keys

    # spec: N-000085 N-000086 N-000087 N-000088 N-000089 N-000090 N-000091 N-000092 N-000093 N-000094
    def _key(self):
        parts = [self._simple_key()]
        while True:
            self._skip_ws()
            if self._peek() != ".":
                break
            self.i += 1
            self._skip_ws()
            parts.append(self._simple_key())
        return parts

    def _simple_key(self):
        c = self._peek()
        if c == '"':
            if self.s.startswith('"""', self.i):
                self._err("multiline string cannot be used as a key")
            return self._basic_string()
        if c == "'":
            if self.s.startswith("'''", self.i):
                self._err("multiline string cannot be used as a key")
            return self._literal_string()
        m = _BARE_KEY.match(self.s, self.i)
        if not m:
            self._err("expected a key")
        self.i = m.end()
        return m.group()

    # --------------------------------------------------------- table headers

    # spec: N-000096 N-000097 N-000098 N-000099 N-000100 N-000101 N-000102 N-000113 N-000114 N-000115 N-000116 N-000117 N-000118 N-000119 N-000120 N-000121 N-000122
    def _table_header(self):
        self.i += 1  # '['
        self._skip_ws()
        keys = self._key()
        self._skip_ws()
        self._expect("]")
        t = self._walk_header_parents(keys[:-1])
        last = keys[-1]
        if last in t:
            nxt = t[last]
            if not isinstance(nxt, dict):
                self._err("table header redefines an existing value")
            m = self._meta(nxt)
            if not m.implicit:
                self._err("table %r is already defined" % last)
            m.implicit = False
            m.header = True
            return nxt
        nxt = self._new_table(header=True)
        t[last] = nxt
        return nxt

    def _array_table_header(self):
        self.i += 2  # '[['
        self._skip_ws()
        keys = self._key()
        self._skip_ws()
        if not self.s.startswith("]]", self.i):
            self._err("expected ']]'")
        self.i += 2
        t = self._walk_header_parents(keys[:-1])
        last = keys[-1]
        if last in t:
            arr = t[last]
            if not (isinstance(arr, list) and self._meta(arr).aot):
                self._err("array of tables header conflicts with an existing key")
        else:
            arr = self._new_list(aot=True)
            t[last] = arr
        elem = self._new_table(header=True)
        arr.append(elem)
        return elem

    def _walk_header_parents(self, keys):
        """Descend the parent path of a header, creating implicit super-tables."""
        t = self.root
        for k in keys:
            if k in t:
                nxt = t[k]
                if isinstance(nxt, list):
                    if not self._meta(nxt).aot:
                        self._err("static array cannot be extended by a table header")
                    nxt = nxt[-1]
                elif isinstance(nxt, dict):
                    if self._meta(nxt).inline:
                        self._err("inline table cannot be extended")
                else:
                    self._err("header path runs through a non-table value")
                t = nxt
            else:
                nxt = self._new_table(implicit=True)
                t[k] = nxt
                t = nxt
        return t

    # ---------------------------------------------------------- key/value

    # spec: N-000089 N-000093 N-000094 N-000095 N-000113 N-000114 N-000115 N-000116 N-000117 N-000118 N-000119 N-000120 N-000121 N-000122
    def _assign(self, table, keys, value):
        t = table
        for k in keys[:-1]:
            if k in t:
                nxt = t[k]
                if not isinstance(nxt, dict):
                    self._err("dotted key runs through a non-table value")
                m = self._meta(nxt)
                if m.inline:
                    self._err("inline table cannot be extended")
                if m.header:
                    self._err("dotted key extends a table defined by a header")
                m.implicit = False
                m.dotted = True
                t = nxt
            else:
                nxt = self._new_table(dotted=True)
                t[k] = nxt
                t = nxt
        last = keys[-1]
        if last in t:
            self._err("duplicate key %r" % last)
        t[last] = value

    # -------------------------------------------------------------- values

    # spec: N-000123 N-000124 N-000125 N-000126 N-000144 N-000151 N-000152 N-000153 N-000154 N-000155 N-000156 N-000157 N-000158 N-000159 N-000160 N-000161 N-000162 N-000163 N-000164 N-000165 N-000166
    def _value(self):
        s = self.s
        i = self.i
        if i >= self.n:
            self._err("expected a value")
        c = s[i]
        if c == '"' or c == "'":
            return self._string()
        if c == "[":
            return self._array()
        if c == "{":
            return self._inline_table()
        if s.startswith("true", i):
            self._check_value_end(i + 4)
            return True
        if s.startswith("false", i):
            self._check_value_end(i + 5)
            return False
        m = _DATETIME.match(s, i)
        if m:
            self._check_value_end(m.end())
            return self._datetime(m)
        m = _LOCAL_TIME.match(s, i)
        if m:
            self._check_value_end(m.end())
            return self._local_time(m)
        m = _NUMBER.match(s, i)
        if m:
            self._check_value_end(m.end())
            return self._number(m)
        self._err("expected a value")

    # spec: N-000144 N-000145 N-000146 N-000147 N-000148 N-000149 N-000150 N-000167 N-000168 N-000169 N-000170 N-000171 N-000172 N-000173 N-000220 N-000221 N-000223 N-000224 N-000225 N-000226 N-000227 N-000228 N-000229 N-000230 N-000231 N-000232 N-000233
    def _number(self, m):
        text = m.group()
        if m.group("hex") is not None:
            return int(text[2:].replace("_", ""), 16)
        if m.group("oct") is not None:
            return int(text[2:].replace("_", ""), 8)
        if m.group("bin") is not None:
            return int(text[2:].replace("_", ""), 2)
        if m.group("special") is not None or m.group("frac") or m.group("exp"):
            return self._float(text)
        return int(text.replace("_", ""))

    # spec: N-000232 N-000233 N-000220
    def _float(self, text):
        if self.parse_float is float:
            return float(text.replace("_", ""))
        value = self.parse_float(text)
        if isinstance(value, (dict, list)):
            raise ValueError(
                "parse_float returned a dict or list, which is not allowed "
                "(value for %r)" % text
            )
        return value

    # spec: N-000151 N-000152 N-000153 N-000154 N-000155 N-000156 N-000157 N-000158 N-000159 N-000179 N-000180 N-000288 N-000289 N-000290
    def _datetime(self, m):
        year, month, day = int(m.group(1)), int(m.group(2)), int(m.group(3))
        try:
            d = datetime.date(year, month, day)
        except ValueError:
            self._err("invalid calendar date", m.start())
        if m.group(4) is None:
            return d
        hour, minute, second, micro = self._time_parts(m, 4, m.start())
        tz = None
        if m.group(8) is not None:
            tz = datetime.timezone.utc
        elif m.group(9) is not None:
            oh, om = int(m.group(10)), int(m.group(11))
            if oh > 23 or om > 59:
                self._err("invalid UTC offset", m.start())
            delta = datetime.timedelta(hours=oh, minutes=om)
            if m.group(9) == "-":
                delta = -delta
            tz = datetime.timezone(delta)
        return datetime.datetime(year, month, day, hour, minute, second, micro, tzinfo=tz)

    # spec: N-000291 N-000292 N-000157
    def _local_time(self, m):
        hour, minute, second, micro = self._time_parts(m, 1, m.start())
        return datetime.time(hour, minute, second, micro)

    def _time_parts(self, m, base, pos):
        """Hour, minute, second and microsecond from a time match starting at group ``base``."""
        hour = int(m.group(base))
        minute = int(m.group(base + 1))
        sec_text = m.group(base + 2)
        second = int(sec_text) if sec_text is not None else 0
        frac = m.group(base + 3)
        micro = int((frac + "000000")[:_FRACTION_DIGITS]) if frac is not None else 0
        if hour > 23 or minute > 59 or second > 59:
            self._err("time out of range", pos)
        return hour, minute, second, micro

    # ---------------------------------------------------------------- strings

    # spec: N-000127 N-000128 N-000222
    def _string(self):
        q = self.s[self.i]
        if self.s.startswith(q * 3, self.i):
            return self._multiline_string(q)
        return self._basic_string() if q == '"' else self._literal_string()

    # spec: N-000137 N-000138 N-000139 N-000140 N-000143 N-000174 N-000175 N-000176 N-000177
    def _escape(self, i):
        """Decode the escape whose backslash is at ``i``; return (text, next index)."""
        s = self.s
        if i + 1 >= self.n:
            self._err("unterminated escape sequence", i)
        e = s[i + 1]
        if e in _ESCAPES:
            return _ESCAPES[e], i + 2
        width = _ESCAPE_WIDTHS.get(e)
        if width is not None:
            digits = s[i + 2:i + 2 + width]
            if len(digits) != width or not all(ch in _HEX_DIGITS for ch in digits):
                self._err("invalid %s escape sequence" % ("\\" + e), i)
            cp = int(digits, 16)
            if cp > 0x10FFFF or 0xD800 <= cp <= 0xDFFF:
                self._err("escape is not a Unicode scalar value", i)
            return chr(cp), i + 2 + width
        self._err("invalid escape sequence", i)

    # spec: N-000137 N-000138 N-000140 N-000141 N-000142 N-000143 N-000178
    def _basic_string(self):
        s = self.s
        start = self.i
        i = start + 1
        buf = []
        while True:
            m = _BASIC_RUN.match(s, i)
            buf.append(m.group())
            i = m.end()
            if i >= self.n:
                self._err("unterminated string", start)
            c = s[i]
            if c == '"':
                i += 1
                break
            if c == "\\":
                text, i = self._escape(i)
                buf.append(text)
                continue
            self._err("control character or line break in basic string", i)
        self.i = i
        return "".join(buf)

    # spec: N-000127 N-000128 N-000129 N-000141 N-000143 N-000178
    def _literal_string(self):
        s = self.s
        start = self.i
        i = start + 1
        m = _LIT_RUN.match(s, i)
        i = m.end()
        if i >= self.n:
            self._err("unterminated string", start)
        if s[i] != "'":
            self._err("control character or line break in literal string", i)
        self.i = i + 1
        return m.group()

    # spec: N-000127 N-000130 N-000131 N-000132 N-000133 N-000134 N-000135 N-000136 N-000178
    def _multiline_string(self, q):
        s = self.s
        start = self.i
        i = start + 3
        if s.startswith("\n", i):
            i += 1  # a line feed right after the opening delimiter is dropped
        basic = q == '"'
        run = _MBASIC_RUN if basic else _MLIT_RUN
        buf = []
        while True:
            m = run.match(s, i)
            buf.append(m.group())
            i = m.end()
            if i >= self.n:
                self._err("unterminated multiline string", start)
            c = s[i]
            if c == q:
                k = 1
                while i + k < self.n and s[i + k] == q:
                    k += 1
                if k >= 3:
                    if k > 5:
                        self._err("too many quotes before closing delimiter", i)
                    buf.append(q * (k - 3))
                    i += k
                    break
                buf.append(q * k)
                i += k
                continue
            if basic and c == "\\":
                j = i + 1
                while j < self.n and s[j] in " \t":
                    j += 1
                if j < self.n and s[j] == "\n":
                    # line-ending backslash: drop it and all following whitespace
                    i = _WS_NL_RUN.match(s, j).end()
                    continue
                text, i = self._escape(i)
                buf.append(text)
                continue
            self._err("control character in multiline string", i)
        self.i = i
        return "".join(buf)

    # ------------------------------------------------------------- containers

    # spec: N-000105 N-000106 N-000144
    # spec: N-000281 N-000282 N-000105 N-000106
    def _array(self):
        self.i += 1  # '['
        arr = self._new_list(aot=False)
        self._skip_ws_nl()
        while True:
            if self._peek() == "]":
                self.i += 1
                break
            arr.append(self._value())
            self._skip_ws_nl()
            c = self._peek()
            if c == ",":
                self.i += 1
                self._skip_ws_nl()
                continue
            if c == "]":
                self.i += 1
                break
            self._err("expected ',' or ']' in array")
        return arr

    # spec: N-000103 N-000104 N-000069 N-000070
    def _inline_table(self):
        self.i += 1  # '{'
        table = self._new_table()
        self._skip_ws_nl()
        if self._peek() == "}":
            self.i += 1
        else:
            while True:
                keys = self._key()
                self._skip_ws()
                self._expect("=")
                self._skip_ws()
                value = self._value()
                self._assign(table, keys, value)
                self._skip_ws_nl()
                c = self._peek()
                if c == ",":
                    self.i += 1
                    self._skip_ws_nl()
                    if self._peek() == "}":  # trailing comma after the last pair
                        self.i += 1
                        break
                    continue
                if c == "}":
                    self.i += 1
                    break
                self._err("expected ',' or '}' in inline table")
        self._meta(table).inline = True
        return table


# spec: N-000197 N-000198 N-000199 N-000200 N-000201 N-000202 N-000203 N-000204 N-000207 N-000279 N-000280
def parse(text, parse_float):
    """Parse ``text`` (a ``str``) into a document mapping."""
    norm, lf_positions = _normalize(text)
    parser = _Parser(norm, parse_float)
    try:
        return parser.parse_document()
    except _ParseError as exc:
        pos = exc.pos
        if lf_positions:
            pos += bisect.bisect_right(lf_positions, pos)
        raise TOMLDecodeError(exc.msg, text, pos)
    except RecursionError:
        raise TOMLDecodeError("document is nested too deeply", text, len(text))
