"""Tomlparse: a pure-Python parser for TOML v1.1.0 text.

Public names: ``loads``, ``load`` and ``TOMLDecodeError``.
Importing this package performs no I/O, starts no processes, opens no sockets.
"""

# spec: N-000266 N-000267 N-000268 N-000269 N-000270 N-000262 N-000263 N-000264 N-000265 N-000259 N-000260 N-000261 N-000255 N-000256 N-000257 N-000258

from ._api import load, loads
from ._errors import TOMLDecodeError

__version__ = "2.4.0"
__all__ = ["loads", "load", "TOMLDecodeError"]
