"""The public entry points: ``loads`` (text) and ``load`` (binary file)."""

import io

from ._errors import TOMLDecodeError
from ._parser import parse


# spec: N-000274 N-000275 N-000276 N-000277 N-000278 N-000293 N-000297 N-000298
# spec: N-000266 N-000270 N-000271 N-000273 N-000296 N-000294 N-000295
def loads(s, *, parse_float=float):
    """Parse the TOML document ``s`` (a ``str``) and return a ``dict``.

    ``parse_float`` is called with the text of each float, exactly as written,
    and its result is stored in place of the float.
    """
    if not isinstance(s, str):
        raise TypeError("loads() expects a str, not %s" % type(s).__name__)
    return parse(s, parse_float)


# spec: N-000299 N-000300 N-000301 N-000302 N-000303 N-000304 N-000305 N-000306
# spec: N-000181 N-000182 N-000183 N-000184 N-000185 N-000186 N-000187 N-000188 N-000189
# spec: N-000190 N-000191 N-000192 N-000193 N-000194 N-000195 N-000196 N-000216 N-000272
def load(fp, *, parse_float=float):
    """Read binary file object ``fp``, decode it as UTF-8, and parse it.

    Text-mode file objects are refused with ``TypeError``.
    """
    if isinstance(fp, io.TextIOBase):
        raise TypeError("load() expects a file opened in binary mode, not text mode")
    read = getattr(fp, "read", None)
    if read is None:
        raise TypeError("load() expects a binary file object, not %s" % type(fp).__name__)
    data = read()
    if isinstance(data, str):
        raise TypeError("load() expects a file opened in binary mode, not text mode")
    if isinstance(data, (bytearray, memoryview)):
        data = bytes(data)
    if not isinstance(data, bytes):
        raise TypeError("load() expects bytes from read(), not %s" % type(data).__name__)
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        doc = data.decode("utf-8", "replace")
        pos = len(data[:exc.start].decode("utf-8", "replace"))
        raise TOMLDecodeError("invalid UTF-8 in document", doc, pos)
    return parse(text, parse_float)
