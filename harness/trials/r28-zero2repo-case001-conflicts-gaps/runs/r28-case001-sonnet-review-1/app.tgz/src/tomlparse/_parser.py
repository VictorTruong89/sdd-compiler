import re
from datetime import date, datetime, time, timedelta, timezone

_BARE = frozenset("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-")
_WS = " \t"
_HEX = frozenset("0123456789abcdefABCDEF")
_ESC = {"b": "\b", "t": "\t", "n": "\n", "f": "\f", "r": "\r", "e": "\x1b",
        '"': '"', "\\": "\\"}
_CTRL = frozenset([chr(i) for i in range(0x20) if i != 9] + ["\x7f"])
_CTRL_ML = _CTRL - {"\n"}

_DATE = re.compile(r"(\d{4})-(\d{2})-(\d{2})")
_TIME = re.compile(r"(\d{2}):(\d{2})(?::(\d{2})(?:\.(\d+))?)?")
_OFFSET = re.compile(r"(?:[Zz]|([+-])(\d{2}):(\d{2}))")
_DEC = re.compile(r"[+-]?(?:0|[1-9](?:_?[0-9])*)")
_FLOAT = re.compile(
    r"[+-]?(?:0|[1-9](?:_?[0-9])*)(?:\.[0-9](?:_?[0-9])*)?(?:[eE][+-]?[0-9](?:_?[0-9])*)?")
_BASES = {"x": (16, re.compile(r"0x[0-9a-fA-F](?:_?[0-9a-fA-F])*")),
          "o": (8, re.compile(r"0o[0-7](?:_?[0-7])*")),
          "b": (2, re.compile(r"0b[01](?:_?[01])*"))}
_SPECIAL = {"inf", "+inf", "-inf", "nan", "+nan", "-nan"}


class TOMLDecodeError(ValueError):
    def __init__(self, msg="", doc="", pos=0):
        self.msg = msg
        self.doc = doc
        self.pos = pos
        self.lineno = doc.count("\n", 0, pos) + 1
        self.colno = pos - doc.rfind("\n", 0, pos)
        if pos >= len(doc):
            loc = "end of document"
        else:
            loc = "line %d, column %d" % (self.lineno, self.colno)
        ValueError.__init__(self, "%s (at %s)" % (msg, loc))
        self.args = ("%s (at %s)" % (msg, loc),)


def load(fp, *, parse_float=float):
    b = fp.read()
    if not isinstance(b, (bytes, bytearray)):
        raise TypeError("File must be opened in binary mode, e.g. use open('foo.toml', 'rb')")
    try:
        s = bytes(b).decode("utf-8")
    except UnicodeDecodeError as e:
        raise TOMLDecodeError("Invalid UTF-8: %s" % e, "", 0) from None
    return loads(s, parse_float=parse_float)


class _Flags:
    pass


def loads(s, *, parse_float=float):
    if not isinstance(s, str):
        raise TypeError("Expected str object, not '%s'" % type(s).__name__)
    src = s.replace("\r\n", "\n")
    return _Parser(src, parse_float).parse()


class _Parser:
    def __init__(self, src, pf):
        self.s = src
        self.n = len(src)
        self.pf = pf
        self.out = {}
        # id(dict) -> state; keep dicts alive via self.keep
        self.frozen = set()      # inline tables / static arrays (no extension at all)
        self.dotted = set()      # tables created by dotted keys (or defined by header: 'explicit')
        self.explicit = set()    # tables defined by [header]
        self.aot = set()         # ids of lists that are arrays of tables

    def err(self, msg, pos):
        raise TOMLDecodeError(msg, self.s, pos)

    def skip_ws(self, p):
        s, n = self.s, self.n
        while p < n and s[p] in _WS:
            p += 1
        return p

    def skip_comment(self, p):
        s, n = self.s, self.n
        if p < n and s[p] == "#":
            p += 1
            while p < n and s[p] != "\n":
                if s[p] in _CTRL:
                    self.err("Control character in comment", p)
                p += 1
        return p

    def skip_ws_comment(self, p):
        return self.skip_comment(self.skip_ws(p))

    def end_of_line(self, p):
        p = self.skip_ws_comment(p)
        if p < self.n:
            if self.s[p] != "\n":
                self.err("Expected end of line", p)
            p += 1
        return p

    # ---- top level
    def parse(self):
        s, n = self.s, self.n
        cur = self.out
        cur_path = ()
        p = 0
        while True:
            p = self.skip_ws(p)
            p = self.skip_comment(p)
            if p >= n:
                break
            c = s[p]
            if c == "\n":
                p += 1
                continue
            if c == "[":
                if s.startswith("[[", p):
                    p, cur = self.aot_header(p + 2)
                else:
                    p, cur = self.table_header(p + 1)
                p = self.end_of_line(p)
                continue
            p = self.key_value(p, cur, set_dotted=True)
            p = self.end_of_line(p)
        return self.out

    def parse_key(self, p):
        p = self.skip_ws(p)
        parts = []
        while True:
            p = self.skip_ws(p)
            if p >= self.n:
                self.err("Expected key", p)
            c = self.s[p]
            if c == '"':
                p, k = self.basic_str(p + 1, False)
            elif c == "'":
                p, k = self.lit_str(p + 1, False)
            else:
                st = p
                while p < self.n and self.s[p] in _BARE:
                    p += 1
                if p == st:
                    self.err("Invalid key", p)
                k = self.s[st:p]
            parts.append(k)
            p = self.skip_ws(p)
            if p < self.n and self.s[p] == ".":
                p += 1
                continue
            return p, parts

    def table_header(self, p):
        p, parts = self.parse_key(p)
        if p >= self.n or self.s[p] != "]":
            self.err("Expected ']'", p)
        p += 1
        d = self.out
        for i, k in enumerate(parts[:-1]):
            d = self.descend(d, k, p)
        k = parts[-1]
        if k in d:
            v = d[k]
            if not isinstance(v, dict) or id(v) in self.explicit or id(v) in self.dotted \
                    or id(v) in self.frozen:
                self.err("Cannot redefine table '%s'" % k, p - 1)
            # implicitly created by earlier sub-header: allowed
            self.explicit.add(id(v))
            return p, v
        nd = {}
        d[k] = nd
        self.explicit.add(id(nd))
        return p, nd

    def descend(self, d, k, p):
        """Walk into key k for a header path (creating implicit tables)."""
        if k not in d:
            nd = {}
            d[k] = nd
            return nd
        v = d[k]
        if isinstance(v, list):
            if id(v) not in self.aot or not v:
                self.err("Cannot extend static array", p)
            return v[-1]
        if not isinstance(v, dict) or id(v) in self.frozen:
            self.err("Cannot extend '%s'" % k, p)
        return v

    def aot_header(self, p):
        p, parts = self.parse_key(p)
        if not self.s.startswith("]]", p):
            self.err("Expected ']]'", p)
        p += 2
        d = self.out
        for k in parts[:-1]:
            d = self.descend(d, k, p)
        k = parts[-1]
        nd = {}
        if k in d:
            v = d[k]
            if not isinstance(v, list) or id(v) not in self.aot:
                self.err("Cannot redefine '%s' as array of tables" % k, p - 2)
            v.append(nd)
        else:
            lst = [nd]
            self.aot.add(id(lst))
            d[k] = lst
        self.explicit.add(id(nd))
        return p, nd

    def key_value(self, p, cur, set_dotted=True):
        kp = p
        p, parts = self.parse_key(p)
        p = self.skip_ws(p)
        if p >= self.n or self.s[p] != "=":
            self.err("Expected '='", p)
        p = self.skip_ws(p + 1)
        d = cur
        for k in parts[:-1]:
            if k in d:
                v = d[k]
                if not isinstance(v, dict) or id(v) in self.frozen or id(v) in self.explicit:
                    self.err("Cannot extend '%s' with dotted key" % k, kp)
            else:
                v = {}
                d[k] = v
                self.dotted.add(id(v))
            d = v
        k = parts[-1]
        if k in d:
            self.err("Duplicate key '%s'" % k, kp)
        p, val = self.value(p)
        d[k] = val
        return p

    # ---- values
    def value(self, p):
        s, n = self.s, self.n
        if p >= n:
            self.err("Expected value", p)
        c = s[p]
        if c == '"':
            if s.startswith('"""', p):
                return self.ml_basic(p + 3)
            return self.basic_str(p + 1, True)
        if c == "'":
            if s.startswith("'''", p):
                return self.ml_lit(p + 3)
            return self.lit_str(p + 1, True)
        if c == "[":
            return self.array(p + 1)
        if c == "{":
            return self.inline_table(p + 1)
        if s.startswith("true", p) and not self._tok_cont(p + 4):
            return p + 4, True
        if s.startswith("false", p) and not self._tok_cont(p + 5):
            return p + 5, False
        m = _DATE.match(s, p)
        if m:
            return self.datetime_(p, m)
        m = re.compile(r"\d{2}:").match(s, p)
        if m:
            tm = _TIME.match(s, p)
            if not tm:
                self.err("Invalid time", p)
            t = self.mk_time(tm, p)
            self._end_tok(tm.end(), p)
            return tm.end(), t
        # numbers
        if s.startswith("0", p) and p + 1 < n and s[p + 1] in "xob":
            base, rx = _BASES[s[p + 1]]
            m = rx.match(s, p)
            if not m:
                self.err("Invalid integer", p)
            self._end_tok(m.end(), p)
            return m.end(), int(m.group().replace("_", ""), base)
        for sp in ("+inf", "-inf", "+nan", "-nan", "inf", "nan"):
            if s.startswith(sp, p):
                e = p + len(sp)
                self._end_tok(e, p)
                return e, self.conv(sp, p)
        m = _FLOAT.match(s, p)
        if m and m.group():
            e = m.end()
            self._end_tok(e, p)
            tok = m.group()
            if m.group(0) and _DEC.fullmatch(tok):
                return e, int(tok.replace("_", ""))
            return e, self.conv(tok, p)
        self.err("Invalid value", p)

    def _tok_cont(self, p):
        return p < self.n and (self.s[p] in _BARE or self.s[p] in ".+:")

    def _end_tok(self, e, p):
        if e < self.n and (self.s[e] in _BARE or self.s[e] in ".+:_"):
            self.err("Invalid value", p)

    def conv(self, tok, p):
        r = self.pf(tok)
        if isinstance(r, (dict, list)):
            raise ValueError("parse_float must not return dicts or lists")
        return r

    def mk_time(self, m, p):
        h, mi = int(m.group(1)), int(m.group(2))
        sec = int(m.group(3)) if m.group(3) else 0
        frac = m.group(4)
        us = int((frac + "000000")[:6]) if frac else 0
        if h > 23 or mi > 59 or sec > 59:
            self.err("Invalid time", p)
        return time(h, mi, sec, us)

    def datetime_(self, p, m):
        s = self.s
        try:
            d = date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            self.err("Invalid date", p)
        e = m.end()
        if e < self.n and s[e] in "Tt ":
            tm = _TIME.match(s, e + 1)
            if tm:
                t = self.mk_time(tm, e + 1)
                e = tm.end()
                dt = datetime.combine(d, t)
                om = _OFFSET.match(s, e)
                if om:
                    e = om.end()
                    if om.group(1):
                        oh, omi = int(om.group(2)), int(om.group(3))
                        if oh > 23 or omi > 59:
                            self.err("Invalid offset", e)
                        off = timedelta(hours=oh, minutes=omi)
                        if om.group(1) == "-":
                            off = -off
                        tz = timezone(off)
                    else:
                        tz = timezone.utc
                    dt = dt.replace(tzinfo=tz)
                self._end_tok(e, p)
                return e, dt
            if s[e] != " ":
                self.err("Invalid date-time", e)
        self._end_tok(e, p)
        return e, d

    def array(self, p):
        res = []
        s = self.s
        while True:
            p = self.ws_nl_comments(p)
            if p >= self.n:
                self.err("Unterminated array", p)
            if s[p] == "]":
                return p + 1, res
            p, v = self.value(p)
            res.append(v)
            if isinstance(v, (dict, list)):
                self.freeze(v)
            p = self.ws_nl_comments(p)
            if p >= self.n:
                self.err("Unterminated array", p)
            if s[p] == ",":
                p += 1
            elif s[p] == "]":
                return p + 1, res
            else:
                self.err("Expected ',' or ']'", p)

    def freeze(self, v):
        stack = [v]
        while stack:
            x = stack.pop()
            self.frozen.add(id(x))
            if isinstance(x, dict):
                stack.extend(y for y in x.values() if isinstance(y, (dict, list)))
            else:
                stack.extend(y for y in x if isinstance(y, (dict, list)))

    def ws_nl_comments(self, p):
        s = self.s
        while True:
            p = self.skip_ws_comment(p)
            if p < self.n and s[p] == "\n":
                p += 1
            else:
                return p

    def inline_table(self, p):
        res = {}
        s = self.s
        first = True
        while True:
            p = self.ws_nl_comments(p)
            if p >= self.n:
                self.err("Unterminated inline table", p)
            if s[p] == "}":
                self.freeze(res)
                return p + 1, res
            p = self.key_value(p, res)
            p = self.ws_nl_comments(p)
            if p >= self.n:
                self.err("Unterminated inline table", p)
            if s[p] == ",":
                p += 1
            elif s[p] == "}":
                self.freeze(res)
                return p + 1, res
            else:
                self.err("Expected ',' or '}'", p)

    # ---- strings
    def lit_str(self, p, _):
        s = self.s
        e = s.find("'", p)
        while True:
            if e == -1:
                self.err("Unterminated string", self.n)
            break
        body = s[p:e]
        for i, ch in enumerate(body):
            if ch in _CTRL:
                self.err("Invalid control character in string", p + i)
        return e + 1, body

    def ml_lit(self, p):
        s = self.s
        if p < self.n and s[p] == "\n":
            p += 1
        st = p
        e = s.find("'''", p)
        if e == -1:
            self.err("Unterminated string", self.n)
        extra = 0
        while extra < 2 and e + 3 + extra < self.n and s[e + 3 + extra] == "'":
            extra += 1
        e2 = e + extra
        body = s[st:e2]
        for i, ch in enumerate(body):
            if ch in _CTRL_ML:
                self.err("Invalid control character in string", st + i)
        return e2 + 3, body

    def basic_str(self, p, _):
        s, n = self.s, self.n
        out = []
        while True:
            if p >= n:
                self.err("Unterminated string", n)
            c = s[p]
            if c == '"':
                return p + 1, "".join(out)
            if c == "\\":
                p, ch = self.escape(p)
                out.append(ch)
                continue
            if c in _CTRL:
                self.err("Invalid control character in string", p)
            out.append(c)
            p += 1

    def escape(self, p):
        s = self.s
        if p + 1 >= self.n:
            self.err("Unterminated string", self.n)
        c = s[p + 1]
        if c in _ESC:
            return p + 2, _ESC[c]
        if c in "xuU":
            ln = {"x": 2, "u": 4, "U": 8}[c]
            h = s[p + 2:p + 2 + ln]
            if len(h) != ln or not all(x in _HEX for x in h):
                self.err("Invalid escape", p)
            cp = int(h, 16)
            if cp > 0x10FFFF or 0xD800 <= cp <= 0xDFFF:
                self.err("Invalid Unicode scalar value", p)
            return p + 2 + ln, chr(cp)
        self.err("Invalid escape", p)

    def ml_basic(self, p):
        s, n = self.s, self.n
        if p < n and s[p] == "\n":
            p += 1
        out = []
        while True:
            if p >= n:
                self.err("Unterminated string", n)
            c = s[p]
            if c == '"':
                if s.startswith('"""', p):
                    q = p + 3
                    extra = 0
                    while extra < 2 and q < n and s[q] == '"':
                        q += 1
                        extra += 1
                    out.append('"' * extra)
                    return q, "".join(out)
                out.append('"')
                p += 1
                continue
            if c == "\\":
                q = p + 1
                while q < n and s[q] in _WS:
                    q += 1
                if q < n and s[q] == "\n":
                    while q < n and s[q] in " \t\n":
                        q += 1
                    p = q
                    continue
                if q > p + 1 or q >= n:
                    self.err("Invalid line-ending backslash", p)
                p, ch = self.escape(p)
                out.append(ch)
                continue
            if c in _CTRL_ML:
                self.err("Invalid control character in string", p)
            out.append(c)
            p += 1
