"""Tomlparse: a TOML v1.1.0 parser."""
from ._parser import TOMLDecodeError, load, loads

__all__ = ("loads", "load", "TOMLDecodeError")
