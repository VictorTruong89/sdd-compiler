#!/usr/bin/env python3
"""prosecheck detector: a local, standard-library-only AI-writing pattern scanner.

Usage: detect.py [--clean] [--ci] [--] [FILE]
See spec/Interface_Contract.md (scripts/detect.py) and spec/Full_PRD.md (FP-01..FP-03).
Rulings applied are listed in NOTES.md.
"""
from __future__ import annotations

import io
import json
import math
import os
import posixpath
import random
import re
import sys
import unicodedata
import zipfile
from collections import Counter
from html.parser import HTMLParser
from urllib.parse import unquote
import xml.etree.ElementTree as ET

WINDOW = 262144
KB = 1024
PLAIN_CAP = 512 * KB
ARCHIVE_CAP = 4096 * KB
MAX_MEMBER = 64 * 1024 * 1024

PLAIN_EXTS = frozenset(['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'])
ZIP_EXTS = frozenset(['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'])
NOTEBOOK_EXT = '.ipynb'

USAGE = """usage: detect.py [--clean] [--ci] [--] [FILE]

Scan a prose file, or standard input when no FILE is given, for AI-writing patterns.
  --clean     print the scrubbed text instead of the JSON report
  --ci        add a low/high interval on the score (needs four or more sentences)
  --          end option parsing, so FILE may begin with a dash
  -h, --help  print this usage message and exit 0
Supported: plain text (.md .mdx .markdown .txt .text .rst .tex .org .adoc),
zip documents (.docx .docm .pptx .pptm .xlsx .xlsm .odt .odp .ods .epub), and .ipynb.
With several FILE operands, only the last one is scanned.
"""


class DetectError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status
        self.message = message


# ---------------------------------------------------------------- decoding / extraction

def decode_bytes(data):
    if data[:3] == b'\xef\xbb\xbf':
        return data[3:].decode('utf-8', errors='replace')
    if data[:2] in (b'\xff\xfe', b'\xfe\xff'):
        return data.decode('utf-16', errors='replace')
    return data.decode('utf-8', errors='replace')


def _local(tag):
    if not isinstance(tag, str):
        return ''
    return tag.rsplit('}', 1)[-1]


def _parse_xml(blob):
    if blob is None:
        return None
    try:
        return ET.fromstring(blob)
    except ET.ParseError:
        return None


def _read_member(z, name):
    try:
        info = z.getinfo(name)
    except KeyError:
        return None
    if info.file_size > MAX_MEMBER:
        return None
    return z.read(name)


def _gather(root, *, skip=(), text=None, tabs=(), breaks=(), spaces=(), paras=()):
    """Collect visible text from an XML tree in document order."""
    out = []

    def rec(e):
        tag = _local(e.tag)
        if tag in skip:
            return
        if tag in tabs:
            out.append('\t')
        elif tag in breaks:
            out.append('\n')
        elif tag in spaces:
            count = 1
            for k, v in e.attrib.items():
                if _local(k) == 'c' and v.isdigit():
                    count = int(v)
            out.append(' ' * count)
        if e.text and (text is None or tag in text):
            out.append(e.text)
        for ch in e:
            rec(ch)
            if ch.tail and (text is None or ch.tail.strip()):
                out.append(ch.tail)
        if tag in paras:
            out.append('\n')

    rec(root)
    return ''.join(out)


def _docx_text(z):
    root = _parse_xml(_read_member(z, 'word/document.xml'))
    if root is None:
        return ''
    return _gather(root, skip={'pPr', 'rPr', 'tabs', 'sectPr', 'del', 'instrText'},
                   text={'t'}, tabs={'tab'}, breaks={'br', 'cr'}, paras={'p'})


def _pptx_text(z):
    slides = []
    for n in z.namelist():
        m = re.match(r'ppt/slides/slide(\d+)\.xml$', n)
        if m:
            slides.append((int(m.group(1)), n))
    parts = []
    for _, name in sorted(slides):
        root = _parse_xml(_read_member(z, name))
        if root is not None:
            parts.append(_gather(root, text={'t'}, breaks={'br'}, paras={'p'}))
    return '\n'.join(parts)


def _odf_text(z):
    root = _parse_xml(_read_member(z, 'content.xml'))
    if root is None:
        return ''
    return _gather(root, skip={'annotation', 'desc', 'title', 'script'}, tabs={'tab'},
                   breaks={'line-break'}, spaces={'s'}, paras={'p', 'h', 'page', 'table-cell'})


def _xlsx_text(z):
    sst = []
    root = _parse_xml(_read_member(z, 'xl/sharedStrings.xml'))
    if root is not None:
        for si in root:
            if _local(si.tag) != 'si':
                continue
            buf = []
            for child in si:
                if _local(child.tag) == 't':
                    buf.append(child.text or '')
                elif _local(child.tag) == 'r':
                    for t in child:
                        if _local(t.tag) == 't':
                            buf.append(t.text or '')
            sst.append(''.join(buf))
    targets = {}
    rels = _parse_xml(_read_member(z, 'xl/_rels/workbook.xml.rels'))
    if rels is not None:
        for el in rels.iter():
            if _local(el.tag) == 'Relationship':
                targets[el.get('Id')] = el.get('Target')
    sheet_paths = []
    wb = _parse_xml(_read_member(z, 'xl/workbook.xml'))
    if wb is not None:
        for el in wb.iter():
            if _local(el.tag) != 'sheet':
                continue
            rid = None
            for k, v in el.attrib.items():
                if _local(k) == 'id':
                    rid = v
            tgt = targets.get(rid)
            if tgt:
                if tgt.startswith('/'):
                    sheet_paths.append(tgt.lstrip('/'))
                else:
                    sheet_paths.append(posixpath.normpath(posixpath.join('xl', tgt)))
    if not sheet_paths:
        sheet_paths = sorted(n for n in z.namelist() if re.match(r'xl/worksheets/[^/]+\.xml$', n))
    lines = []
    for path in sheet_paths:
        sheet = _parse_xml(_read_member(z, path))
        if sheet is None:
            continue
        for c in sheet.iter():
            if _local(c.tag) != 'c':
                continue
            kind = c.get('t')
            v_text = None
            for child in c:
                if _local(child.tag) == 'v':
                    v_text = child.text or ''
            if kind == 's':
                if v_text is not None and re.fullmatch(r'\s*\d+\s*', v_text):
                    idx = int(v_text)
                    if idx < len(sst):
                        lines.append(sst[idx])
            elif kind == 'inlineStr':
                lines.append(''.join(x.text or '' for x in c.iter() if _local(x.tag) == 't'))
            elif kind == 'str':
                if v_text:
                    lines.append(v_text)
    return '\n'.join(lines)


class _ChapterText(HTMLParser):
    BLOCK = {'p', 'div', 'br', 'li', 'tr', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'section',
             'article', 'blockquote', 'pre', 'hr', 'dt', 'dd', 'figure', 'figcaption',
             'header', 'footer', 'ul', 'ol', 'table', 'aside', 'body'}
    SKIP = {'nav', 'style', 'script', 'head', 'title', 'svg'}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        elif tag in self.BLOCK:
            self.parts.append('\n')

    def handle_startendtag(self, tag, attrs):
        if tag not in self.SKIP and tag in self.BLOCK:
            self.parts.append('\n')

    def handle_endtag(self, tag):
        if tag in self.SKIP:
            self.skip = max(0, self.skip - 1)
        elif tag in self.BLOCK:
            self.parts.append('\n')

    def handle_data(self, data):
        if not self.skip:
            self.parts.append(data)


def _html_to_text(raw):
    parser = _ChapterText()
    try:
        parser.feed(decode_bytes(raw))
        parser.close()
    except Exception:  # malformed markup: keep what was read
        pass
    lines = []
    for line in ''.join(parser.parts).split('\n'):
        line = re.sub(r'\s+', ' ', line).strip()
        if line:
            lines.append(line)
    return '\n'.join(lines)


def _epub_text(z):
    names = z.namelist()
    order = []
    container = _parse_xml(_read_member(z, 'META-INF/container.xml'))
    opf = None
    if container is not None:
        for el in container.iter():
            if _local(el.tag) == 'rootfile' and el.get('full-path'):
                opf = el.get('full-path')
                break
    if opf and opf in names:
        root = _parse_xml(_read_member(z, opf))
        if root is not None:
            manifest = {}
            spine = []
            for el in root.iter():
                tag = _local(el.tag)
                if tag == 'item' and el.get('id'):
                    manifest[el.get('id')] = (el.get('href') or '', el.get('properties') or '')
            for el in root.iter():
                if _local(el.tag) == 'itemref' and el.get('idref') in manifest:
                    spine.append(manifest[el.get('idref')])
            base = posixpath.dirname(opf)
            for href, props in spine:
                if 'nav' in props.split():
                    continue
                path = posixpath.normpath(posixpath.join(base, unquote(href)))
                if path in names:
                    order.append(path)
    if not order:
        order = sorted(n for n in names if n.lower().endswith(('.xhtml', '.html', '.htm')))
    chapters = []
    for path in order:
        raw = _read_member(z, path)
        if raw is None:
            continue
        text = _html_to_text(raw)
        if text:
            chapters.append(text)
    return '\n'.join(chapters)


def _notebook_text(data):
    try:
        nb = json.loads(decode_bytes(data))
    except ValueError:
        return ''
    cells = nb.get('cells') if isinstance(nb, dict) else None
    if not isinstance(cells, list):
        return ''
    out = []
    for cell in cells:
        if not isinstance(cell, dict):
            return ''
        if cell.get('cell_type') != 'markdown':
            continue
        src = cell.get('source')
        if isinstance(src, str):
            out.append(src)
        elif isinstance(src, list) and all(isinstance(s, str) for s in src):
            out.append(''.join(src))
        else:
            return ''
    return '\n'.join(out)


def load_prose(path):
    """Return extracted prose for a file operand (FP-02)."""
    try:
        with open(path, 'rb') as fh:
            data = fh.read()
    except OSError as exc:
        raise DetectError(1, 'cannot read input: %s: %s' % (path, exc.strerror or exc))
    ext = os.path.splitext(path)[1].lower()
    if ext in ZIP_EXTS:
        try:
            z = zipfile.ZipFile(io.BytesIO(data))
        except (zipfile.BadZipFile, OSError, ValueError):
            raise DetectError(1, 'cannot read input: %s is not a readable zip archive' % path)
        with z:
            try:
                if ext in ('.docx', '.docm'):
                    text = _docx_text(z)
                elif ext in ('.pptx', '.pptm'):
                    text = _pptx_text(z)
                elif ext in ('.xlsx', '.xlsm'):
                    text = _xlsx_text(z)
                elif ext in ('.odt', '.odp', '.ods'):
                    text = _odf_text(z)
                else:
                    text = _epub_text(z)
            except (zipfile.BadZipFile, KeyError, RuntimeError):
                raise DetectError(1, 'cannot read input: %s is not a readable zip archive' % path)
        return text.strip()
    if ext == NOTEBOOK_EXT:
        return _notebook_text(data).strip()
    if ext in ('.pdf', '.rtf'):
        return ''
    return decode_bytes(data)


# ---------------------------------------------------------------- character layer

def _in(o, ranges):
    for lo, hi in ranges:
        if lo <= o <= hi:
            return True
    return False


NOSPACE_SCRIPTS = [(0x0E00, 0x0EFF), (0x1000, 0x109F), (0x1780, 0x17FF), (0x3040, 0x30FF),
                   (0x3400, 0x9FFF), (0xF900, 0xFAFF), (0x20000, 0x3FFFF)]
CJK = [(0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xF900, 0xFAFF), (0x20000, 0x3FFFF)]
JOINING = [(0x0590, 0x08FF), (0x0900, 0x0DFF), (0x1000, 0x109F), (0x1780, 0x17FF),
           (0xFB50, 0xFDFF), (0xFE70, 0xFEFF)]
RTL = [(0x0590, 0x08FF), (0xFB1D, 0xFDFF), (0xFE70, 0xFEFF)]
MONGOLIAN = [(0x1800, 0x18AF)]
KHMER = [(0x1780, 0x17FF)]
BIDI = frozenset([0x200E, 0x200F, 0x061C] + list(range(0x202A, 0x202F)) + list(range(0x2066, 0x206A)))
EXTRA_IGNORABLE = frozenset([0x034F, 0x115F, 0x1160, 0x3164, 0xFFA0, 0x17B4, 0x17B5,
                             0x180B, 0x180C, 0x180D, 0x180F])
RTL_RE = re.compile('[\u0590-\u08ff\ufb1d-\ufdff\ufe70-\ufeff]')
LETTER_RUN = re.compile(r'[^\W\d_]+')
WORD_RE = re.compile(r"(?:[^\W_]|['’\-])+")

_CONF_PAIRS = {
    'а': 'a', 'с': 'c', 'ԁ': 'd', 'е': 'e', 'һ': 'h', 'і': 'i', 'ј': 'j', 'о': 'o',
    'р': 'p', 'ѕ': 's', 'у': 'y', 'х': 'x', 'ѵ': 'v', 'ԝ': 'w',
    'А': 'A', 'В': 'B', 'С': 'C', 'Е': 'E', 'Н': 'H', 'І': 'I', 'Ј': 'J', 'К': 'K',
    'М': 'M', 'О': 'O', 'Р': 'P', 'Ѕ': 'S', 'Т': 'T', 'Х': 'X', 'У': 'Y',
    'Α': 'A', 'Β': 'B', 'Ε': 'E', 'Ζ': 'Z', 'Η': 'H', 'Ι': 'I', 'Κ': 'K', 'Μ': 'M',
    'Ν': 'N', 'Ο': 'O', 'Ρ': 'P', 'Τ': 'T', 'Χ': 'X', 'Υ': 'Y',
    'ο': 'o', 'ρ': 'p', 'ν': 'v', 'ι': 'i', 'υ': 'u',
    'օ': 'o', 'Օ': 'O', 'ս': 'u', 'Ս': 'U', 'ո': 'n',
}
CONF = _CONF_PAIRS
CONF_RE = re.compile('[' + ''.join(CONF.keys()) + ']')


def _is_letter(ch):
    return bool(ch) and unicodedata.category(ch).startswith('L')


def _is_emojiish(ch):
    if not ch:
        return False
    o = ord(ch)
    if o >= 0x1F000:
        return True
    if 0x2300 <= o <= 0x23FF or 0x2600 <= o <= 0x27BF or 0x2B00 <= o <= 0x2BFF:
        return True
    return unicodedata.category(ch) == 'So'


def _is_invisible_nonascii(o, ch):
    if o in EXTRA_IGNORABLE:
        return True
    if 0xFE00 <= o <= 0xFE0F or 0xE0000 <= o <= 0xE0FFF:
        return True
    return unicodedata.category(ch) == 'Cf'


def _kept_invisible(text, i, rtl):
    """True when cleanup keeps this invisible character because it does a job (FP-03)."""
    ch = text[i]
    o = ord(ch)
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    po = ord(prev) if prev else -1
    no = ord(nxt) if nxt else -1
    if 0xE0020 <= o <= 0xE007F:
        return bool(prev) and (_is_emojiish(prev) or 0xE0020 <= po <= 0xE007F)
    if 0xFE00 <= o <= 0xFE0F or 0xE0100 <= o <= 0xE01EF:
        return (bool(prev) and (_is_emojiish(prev) or _in(po, CJK))) or nxt == '⃣'
    if o == 0x200B:
        return _in(po, NOSPACE_SCRIPTS) or _in(no, NOSPACE_SCRIPTS)
    if o == 0xAD:
        return _is_letter(prev) and _is_letter(nxt)
    if o in BIDI:
        return rtl
    if 0x180B <= o <= 0x180D or o == 0x180F:
        return _in(po, MONGOLIAN)
    if o in (0x17B4, 0x17B5):
        return _in(po, KHMER) or _in(no, KHMER)
    if o in (0x200C, 0x200D):
        return ((_is_letter(prev) and _in(po, JOINING)) or (_is_letter(nxt) and _in(no, JOINING))
                or _is_emojiish(prev) or _is_emojiish(nxt))
    return False


def _nbsp_kept(text, i):
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    if prev and unicodedata.category(prev) == 'Nd':
        return True
    if nxt and unicodedata.category(nxt) == 'Nd':
        return True
    if nxt and nxt in ':;!?»›%€':
        return True
    if prev and prev in '«‹':
        return True
    return False


def _layer_positions(text):
    """Return (removed invisible indices, normalised space indices, has_rtl)."""
    rtl = RTL_RE.search(text) is not None
    removed = []
    normed = []
    for i, ch in enumerate(text):
        o = ord(ch)
        if o < 0x7F:
            if o < 0x20 and ch not in '\t\n\r':
                removed.append(i)
            continue
        if 0x7F <= o <= 0x9F:
            removed.append(i)
            continue
        if _is_invisible_nonascii(o, ch):
            if not _kept_invisible(text, i, rtl):
                removed.append(i)
            continue
        if ch != ' ' and unicodedata.category(ch) == 'Zs':
            if ch in '\u00a0\u202f' and _nbsp_kept(text, i):
                continue
            normed.append(i)
    return removed, normed, rtl


def _run_qualifies(run):
    has_ascii = False
    has_conf = False
    for c in run:
        if c < '\x80':
            if c.isalpha():
                has_ascii = True
        elif c in CONF:
            has_conf = True
        else:
            return False
    return has_ascii and has_conf


def _fold_run(run):
    if not _run_qualifies(run):
        return run
    return ''.join(CONF.get(c, c) for c in run)


def _fold_text(s):
    if not CONF_RE.search(s):
        return s
    return LETTER_RUN.sub(lambda m: _fold_run(m.group(0)), s)


def _homoglyph_tokens(window):
    hits = []
    for m in re.finditer(r'\S+', window):
        tok = m.group(0)
        if any(_run_qualifies(r) for r in LETTER_RUN.findall(tok)):
            hits.append(tok)
    return hits


def _trailing_hits(window):
    hits = []
    for i, line in enumerate(window.split('\n')):
        body = line[:-1] if line.endswith('\r') else line
        if body and body[-1] in ' \t':
            hits.append('line %d' % (i + 1))
    if window[:1].isspace():
        hits.append('start of text')
    if re.search(r'(?:\r?\n){2,}\Z', window):
        hits.append('end of text')
    return hits


def cleanup(text):
    """Scrubbed text for the cleanup switch (FP-03)."""
    removed, normed, _ = _layer_positions(text)
    drop = set(removed)
    space = set(normed)
    out = []
    for i, ch in enumerate(text):
        if i in drop:
            continue
        if i in space:
            out.append(' ')
        elif ch in '\u2028\u2029':
            out.append('\n')
        else:
            out.append(ch)
    s = _fold_text(''.join(out))
    ends_lf = s.endswith('\n')
    raw = s.split('\n')
    res = []
    n = len(raw)
    for idx, line in enumerate(raw):
        cr = line.endswith('\r')
        body = line[:-1] if cr else line
        stripped = body.rstrip(' \t')
        keep = ''
        if body.endswith('  ') and stripped.strip() and idx + 1 < n and raw[idx + 1].strip():
            keep = '  '
        res.append(stripped + keep + ('\r' if cr else ''))
    while res and not res[0].strip():
        res.pop(0)
    out_text = '\n'.join(res).rstrip()
    if ends_lf and out_text:
        out_text += '\n'
    return out_text


# ---------------------------------------------------------------- markdown masking

FENCE_OPEN = re.compile(r'^ {0,3}(`{3,}|~{3,})(.*)$')
TABLE_SEP = re.compile(r'^\|?\s*:?-{2,}:?\s*(?:\|\s*:?-{2,}:?\s*)*\|?$')
BADGE_LINE = re.compile(r'^\s*(?:\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)\s*)+$')
INLINE_CODE = re.compile(r'(`+)(?!`)(.+?)(?<!`)\1(?!`)')


def mask_markdown(text):
    """Blank out regions that generate no findings, keeping length and line breaks."""
    lines = text.split('\n')
    n = len(lines)
    mask = [False] * n
    if n and lines[0].rstrip() == '---':
        for j in range(1, n):
            if lines[j].rstrip() in ('---', '...'):
                for k in range(j + 1):
                    mask[k] = True
                break
    i = 0
    while i < n:
        if mask[i]:
            i += 1
            continue
        m = FENCE_OPEN.match(lines[i])
        if m:
            fence = m.group(1)
            close = re.compile(r'^ {0,3}' + re.escape(fence[0]) + '{%d,}\\s*$' % len(fence))
            j = i + 1
            while j < n and not close.match(lines[j]):
                j += 1
            end = min(j, n - 1)
            for k in range(i, end + 1):
                mask[k] = True
            i = end + 1
            continue
        i += 1
    for i, line in enumerate(lines):
        if mask[i]:
            continue
        s = line.strip()
        if '|' in s and s.count('|') >= 2 and (s.startswith('|') or s.endswith('|')):
            mask[i] = True
        elif '|' in s and TABLE_SEP.match(s):
            mask[i] = True
        elif BADGE_LINE.match(line):
            mask[i] = True
    i = 0
    while i < n:
        if not mask[i] and lines[i].strip().startswith('>'):
            j = i
            while j < n and not mask[j] and lines[j].strip().startswith('>'):
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    mask[k] = True
            i = j
        else:
            i += 1
    out = []
    for i, line in enumerate(lines):
        if mask[i]:
            out.append(' ' * len(line))
        else:
            out.append(INLINE_CODE.sub(lambda m: ' ' * len(m.group(0)), line))
    return '\n'.join(out)


# ---------------------------------------------------------------- text structure helpers

def _wc(text):
    return sum(1 for w in WORD_RE.findall(text) if any(c.isalnum() for c in w))


def _sentences_of(text):
    parts = re.split(r'(?<=[.!?])\s+|\n+', text)
    return [p for p in parts if p and _wc(p) > 0]


def _first_words(s, k):
    return [w.lower() for w in re.findall(r"[^\W\d_][\w'’-]*", s)[:k]]


def _blocks(lines):
    blocks = []
    cur = []
    for line in lines:
        if line.strip():
            cur.append(line)
        elif cur:
            blocks.append(cur)
            cur = []
    if cur:
        blocks.append(cur)
    return blocks


def _cv(vals):
    mean = sum(vals) / float(len(vals))
    if mean == 0:
        return float('inf')
    var = sum((v - mean) ** 2 for v in vals) / float(len(vals))
    return math.sqrt(var) / mean


def sample(s):
    t = ' '.join(s.split())
    return t if len(t) <= 100 else t[:97] + '...'


class Ctx(object):
    pass


# ---------------------------------------------------------------- family rules

def _phrase(p):
    """Regex for a literal phrase: spaces match any run of whitespace, apostrophes either form."""
    p = p.replace('’', "'")
    body = r'\s+'.join(re.escape(w).replace("'", "['’]") for w in p.split(' '))
    pre = r'\b' if p[0].isalnum() else ''
    post = r'\b' if p[-1].isalnum() else ''
    return pre + body + post


def _P(*phrases):
    return [_phrase(p) for p in phrases]


def _rx_fn(patterns, flags=re.I):
    comp = [re.compile(p, flags) for p in patterns]

    def run(ctx):
        out = []
        for c in comp:
            out.extend(m.group(0) for m in c.finditer(ctx.masked))
        return out
    return run


def _infl(w):
    if w.endswith('e'):
        return r'\b' + re.escape(w[:-1]) + r'(?:e|es|ed|ing)\b'
    return r'\b' + re.escape(w) + r'(?:s|es|ed|ing)?\b'


VOCAB1_WORDS = ['delve', 'tapestry', 'pivotal', 'vibrant', 'meticulous', 'testament', 'underscore',
                'intricate', 'interplay', 'garner', 'bolster', 'foster', 'showcase', 'emphasize',
                'enduring', 'enhance', 'leverage', 'utilize', 'facilitate', 'encompass', 'harness',
                'holistic', 'paradigm', 'transformative', 'unprecedented', 'myriad', 'plethora',
                'robust', 'seamless', 'navigate', 'embark', 'craft', 'landscape', 'journey', 'realm',
                'multifaceted', 'elevate', 'empower', 'unlock', 'crucial']
VOCAB1 = [_infl(w) for w in VOCAB1_WORDS] + [
    r'\badditionally\b', r'\bintricacies\b', r'\balign(?:s|ed|ing)? with\b',
    r'\bcapture the (?:essence|spirit|imagination|heart|magic)\b']

VOCAB2 = [
    r'\bgenuinely\b', r'\bfascinating\b', r'\bnuanced\b', r'\bthoughtfully\b', r'\brefreshingly\b',
    r'\bstrikingly\b', r'\bcompellingly\b', r'\bquietly (?:powerful|profound|radical)\b',
    r'\bdeeply (?:human|personal|felt|unsettling)\b', r'\bresonates deeply\b',
    r'\bgame[- ]chang(?:er|ers|ing)\b', r'\bsupercharg(?:e|es|ed|ing)\b', r'\bskyrocket(?:s|ed|ing)?\b',
    r'\bturbocharg(?:e|es|ed|ing)\b', r'\brevolutioniz(?:e|es|ed|ing)\b', r'\bdouble down on\b',
    r'\bdive deep(?:er)? into\b', r'\bunlock (?:the )?(?:power|potential|value)\b',
    r'\btake\b[^.!?\n]{0,60}?\bto the next level\b']

PROMO = _P('nestled', 'breathtaking', 'must-visit', 'stunning', 'picturesque', 'charming', 'idyllic',
           'vibrant community', 'rich cultural heritage', 'in the heart of', 'world-class', 'top-tier',
           'unparalleled', 'premier', 'esteemed organization', 'valuable asset', 'passion for excellence',
           'proven track record', 'results-oriented', 'wealth of experience', 'dynamic team',
           'fast-paced environment', 'deeply passionate', 'perfectly situated', 'close-knit team',
           'tight-knit team', 'I am excited to apply', 'I am excited to bring', 'uniquely positioned to') + [
    r'\b(?:the|a|an|our|your) leading\b']
IMPERATIVES = {'install', 'join', 'grab', 'download', 'try', 'discover', 'experience', 'escape',
               'transform', 'reclaim', 'unlock', 'elevate', 'boost', 'say', 'imagine', 'explore', 'meet',
               'introducing', 'upgrade', 'claim', 'unleash', 'supercharge', 'level', 'stop', 'start'}
_promo_fn = _rx_fn(PROMO)


def _fam3(ctx):
    hits = _promo_fn(ctx)
    cnt = 0
    for s in ctx.sentences:
        fw = _first_words(s, 1)
        if fw and fw[0] in IMPERATIVES:
            cnt += 1
    if cnt >= 3:
        hits.extend(['marketing imperative opener'] * cnt)
    return hits


HYPHEN_CLICHES = _P('cutting-edge', 'state-of-the-art', 'best-in-class', 'next-generation',
                    'results-driven', 'data-driven', 'client-centric', 'customer-centric',
                    'forward-thinking', 'high-performing', 'value-added', 'top-notch', 'user-centric')

STOCK_ADJ = {'powerful', 'seamless', 'robust', 'comprehensive', 'innovative', 'cutting-edge', 'elegant',
             'vibrant', 'dynamic', 'reliable', 'scalable', 'intuitive', 'efficient', 'effective',
             'modern', 'premier', 'stunning', 'beautiful', 'breathtaking', 'exceptional', 'sophisticated',
             'transformative', 'holistic', 'unparalleled', 'remarkable', 'intelligent', 'smart', 'fast',
             'secure', 'flexible', 'versatile', 'lightweight', 'high-quality', 'world-class', 'comfortable'}
ADJ_SUFFIX = ('ive', 'ous', 'able', 'ible', 'ical', 'ic', 'ant', 'ent', 'ful', 'less', 'ial', 'al',
              'ary', 'ory', 'ish')
R_CHAIN = re.compile(r"\b(?:[A-Za-z][A-Za-z'’-]*,\s+){3,}(?:(?:and|or)\s+)?[A-Za-z][A-Za-z'’-]*\b")
R_WORD = re.compile(r"[A-Za-z][A-Za-z'’-]*")


def _fam6(ctx):
    hits = []
    for m in R_CHAIN.finditer(ctx.masked):
        ws = R_WORD.findall(m.group(0))
        if any(w.lower() in STOCK_ADJ or w.lower().endswith(ADJ_SUFFIX) for w in ws):
            hits.append(m.group(0))
    return hits


CLUSTERS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]
_CLUSTER_RX = [[(m, re.compile(r'\b' + re.escape(m).replace(r'\ ', r'\s+') + r's?\b', re.I))
                for m in cl] for cl in CLUSTERS]


def _fam8(ctx):
    hits = []
    for cl in _CLUSTER_RX:
        found = []
        for member, rx in cl:
            occ = [m.group(0) for m in rx.finditer(ctx.masked)]
            if occ:
                found.append((member, occ))
        if len(found) >= 3:
            for _, occ in found:
                hits.extend(occ)
    return hits


_F10 = [r'\b(?:stands?|stood|serves?|served) as an? (?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b',
        r'\b(?:underscor|highlight)\w*\s+(?:its|the|their|his|her)\s+(?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b',
        r'\breflects? a broader (?:trend|shift|pattern)\b',
        r'\bmarks? a (?:turning point|milestone|watershed|new chapter|new era)\b',
        r'\bsymbolizes\b', r'\bsets? the stage for\b', r'\bleft an indelible mark\b',
        r'\bplays? a (?:crucial|pivotal|vital|key|central|significant) role\b',
        r'\bhas (?:shaped|sparked)\b', r'\bhas come to (?:define|symbolize)\b']

_F11 = [r'\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased) (?:in|by) (?-i:[A-Z][\w&.\']*(?:\s+[A-Z][\w&.\']*)*)(?:,\s*|\s+and\s+)(?-i:[A-Z][\w&.\']*)',
        r'\b\d[\d,.]*\s*(?:[KMkm]\s+)?(?:followers|subscribers)\b',
        r'\b(?:strong|active) (?:online|digital|social[- ]media) presence\b',
        r'\bwidely covered\b', r'\bindependent coverage\b']

_F12 = [r'\bexperts? (?:argue|believe|say|claim|note|suggest)\b', r'\bindustry (?:reports|observers|analysts)\b',
        r'\bobservers have (?:cited|noted)\b', r'\bsome critics argue\b', r'\bresearchers have found\b',
        r'\bstudies suggest\b', r'\bit is widely believed\b']

_F13 = [r'\bThe (?:List|Index|Compilation|Collection|Catalogue|Guide|Overview) of (?:(?:[A-Z][\w\'’:.-]*|of|the|and|in|on|for|to|a|an)\s+){0,6}[A-Z][\w\'’:.-]*\s+(?:is|are|was|were)\s+(?:a|an|the)\b']

_F14 = _P('conservation efforts are underway', 'conservation efforts are ongoing',
          'conservation efforts are in place', 'serves as an indicator species',
          'contributes to biodiversity') + [r'\bplays? a (?:vital|crucial|key|significant) role in (?:its|the) ecosystem\b']

_F15 = [r'\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?\n]*?\bto (?:the )?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b',
        r'\bfrom (?:the )?humble\b[^.!?\n]*?\bto (?:the )?(?:mighty|towering|grand|sprawling)\b']

_F16 = [r",\s+(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|fostering|cultivating|encompassing|signaling|demonstrating|illustrating|representing|suggesting|indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b"]

_F17P = [r"\bit(?:’|')?s not (?:just|merely) (?:about|a|an)\b",
         r'\bnot only\b(?:(?![.!?]).){0,40}?\bbut\b',
         r"\bdoesn(?:’|')t just\b[^,.]{0,40}?\bit\b"]
_F17T = [r",\s+no (?:guessing|waste|wasted motion|hassle|fluff|stress|jargon)\b"]

_F18 = [r'\b(?:no|not) \w+,\s+(?:just|only|simply)\s+\w+',
        r"\b(?:isn(?:’|')t|aren(?:’|')t|wasn(?:’|')t|weren(?:’|')t|not|is not|are not|was not|were not) (?:just|merely) (?:a |an |the )?[\w-]+\s*(?:,|—|–| -)\s*(?:it(?:’|')?s|it is|it was|they(?:’|')?re|they are|they were|that(?:’|')?s|but)\b"]

_F19 = _P('in order to', 'due to the fact that', 'at this point in time', 'in the event that',
          'has the ability to', 'it is important to note that', 'it should be mentioned that',
          'needless to say')

_F20 = _P("it's worth noting that", "it's worth mentioning that", 'it bears noting that',
          'it bears mentioning that', 'one thing to consider is', 'one thing to keep in mind is',
          'it is interesting to note that', 'a key consideration is', 'a point to highlight is')

_F21 = [r",\s+(?:raising questions about|prompting reflection on|sparking debate about|with broader implications for|reshaping our understanding of|paving the way for|signaling a shift toward)\b"]

_F22 = _P("here's the thing", 'make no mistake', 'the truth is', "let's be honest", 'the simple fact is',
          'at its core', 'what really matters', 'more than anything', 'at the end of the day',
          'the bottom line is', 'in reality', 'fundamentally,', 'the real question is',
          'the heart of the matter', 'the deeper issue', 'when you get down to it',
          'when all is said and done')

_F23 = [r"\bit(?:’|')?s important to (?:remember|note|understand|recognize)\b",
        r'\bit is important to (?:remember|note|understand|recognize)\b',
        r'\bone must note that\b', r'\bit is worth pointing out\b',
        r'\bit cannot be overstated that\b', r'\bit must be emphasized that\b']

_F24 = _P('this comprehensive guide', 'this comprehensive overview', 'this comprehensive analysis',
          'this in-depth analysis', 'this in-depth look', 'this in-depth examination',
          'this complete guide', 'this complete overview', 'a thorough examination of',
          'everything you need to know about')

_F25 = [r"(?:^|(?<=[.!?]\s)|(?<=\n))((?:is|are|was|were|do|does|did|can|could|will|would|should|has|have|had|may|might|must)\b[^.!?\n]{1,80}\?)\s+((?:yes|no|absolutely|never|maybe|probably|always)[.!])"]

_F26 = _P('without concrete evidence', 'do you have concrete evidence', 'absent concrete proof',
          'provide concrete evidence') + [r'\bI (?:would )?need concrete (?:evidence|examples|proof)\b']

_F27 = [r"\bin today(?:’|')?s(?: \w+){0,2}? (?:world|landscape|environment|market)\b"] + _P(
    'in a world where', 'in an era of', 'more than ever before', 'we live in a time when',
    'we live in a world when') + [
    r'\b(?:great|exciting|big) news\s*[!:]',
    r'\bever (?:wanted|wondered|dreamed|wished)\b[^?\n]{0,80}\?',
    r'\bin recent years,',
    r'\bin an increasingly (?:interconnected|digital|competitive|complex) world\b']

_F30 = [r'\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)\b',
        r'\b(?:this|the) (?:(?:latest|new) )?(?:update|release|version|change|patch|design) (?:adds|introduces|brings|delivers|includes|provides|improves)\b',
        r'\b(?:has|have) been (?:updated|refactored|improved|enhanced|changed) to\b',
        r'\bpreviously\b[^.!?\n]{0,80}\bnow\b',
        r"\b(?:wasn|weren)(?:’|')t there before\b",
        r"\bwe(?:’|')ve (?:now )?(?:added|removed|replaced|refactored|migrated)\b",
        r'\bwe have (?:now )?(?:added|removed|replaced|refactored|migrated)\b']

_F31 = [r"\blet(?:’|')?s (?:dive|delve|explore)\b", r"\blet(?:’|')?s break (?:this|it) down\b"] + _P(
    "here's what you need to know", 'without further ado', 'now let us look at', "now let's look at",
    'buckle up', 'stay with me') + [r'\b(?:are you )?ready to dive in\b']

_F32 = [r'\b(?:used|uses|use|employs?|employed|relied on|utilizes?) (?:several|various|a number of|multiple|different|many|numerous) \w+',
        r'(?:^|(?<=[.!?]\s))These(?:\s+\w+)?\s+(?:provide|offer|give|reveal|show|allow|enable|help)\s+(?:\w+\s+)?(?:information|insight|understanding|details|data)\b',
        r'\b(?:is|are|was|were|remains|becomes) (?:the |a )?(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective tissue) of\b']

_F33 = [r'^[ \t]*(?:(?:[-*+]|\d+[.)])[ \t]+)?\*\*[^*\n]{1,80}?:\*\*',
        r'^[ \t]*(?:(?:[-*+]|\d+[.)])[ \t]+)?\*\*[^*\n]{1,80}?\*\*:']

_F36 = [r'\bdespite (?:these|its|the) (?:challenges|obstacles)\b',
        r'\bchallenges and (?:future )?(?:prospects|outlook|legacy)\b',
        r'\bcontinues to thrive\b', r'\btypical of (?:emerging|urban|modern)\b',
        r'\bfaces (?:several|many|numerous) challenges\b']

_F38 = [r'^[ \t]*(?:in conclusion|overall|in summary|to summarize|to conclude|all in all|in essence|ultimately)\b']

_F39 = _P('the future looks bright', 'exciting times lie ahead', 'journey toward excellence',
          'step in the right direction') + [
    r'\b(?:outlook|future)(?: for [\w ]{1,40}?)? (?:is|looks|remains) bright\b',
    r'\bwell[- ]positioned (?:for (?:whatever comes next|the future|the road ahead))\b']

_F47 = [r"\bI hope this helps\b", r'\b(?-i:Certainly|Of course)!', r'\blet me know if you\b',
        r'\bwould you like me to\b', r'\bfeel free to (?:ask|reach out)\b', r'\bhappy to help[.!]',
        r'\b(?:here|below) is (?:a|an|the) (?:overview|summary|rundown|recap|brief)\b',
        r'\bhere(?: are|’s|\'s| is) (?:a few|some|two|three) (?:options|drafts|versions|variations)\b',
        r'\bhere(?: is|’s|\'s) a draft\b', r'\bdepending on the (?:vibe|tone|style)\b',
        r'\bI hope (?:this (?:email |message )?)?finds you well\b',
        r'\bas an? (?:AI|LLM|AI assistant|AI language model|large language model|language model)\b',
        r'\bto (?:answer|address) your question\b', r'\bin (?:response|answer) to your question\b',
        r'\byour question (?:about|regarding|concerning)\b', r'\bas (?:you )?(?:requested|asked), here\b',
        r'\bhere is (?:the )?(?:draft|first pass|revised version (?:of|for your)|version (?:of|for your))\b']

_F48 = [r"\byou(?:’|')?re absolutely right\b", r'\byou are absolutely right\b',
        r'\b(?:great|excellent) (?:question|point)(?=[!.,])',
        r'\bwhat a (?:thoughtful|great|wonderful|fantastic) question\b',
        r"\bthat(?:’|')?s a (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\b"]

_F50 = [r"\bas of my (?:last )?(?:training|knowledge)(?: cutoff)?\b", r'\bup to my (?:last )?(?:training|knowledge)\b',
        r'\bwhile specific details are (?:limited|scarce|not (?:extensively|widely) documented)\b',
        r'\bbased on (?:the )?available information\b', r'\bas of my (?:knowledge )?cutoff\b',
        r'\bmaintains a low profile\b', r'\bkeeps (?:his|her|their) personal life private\b']

_F51 = [r'\b(?:serves|stands|functions|acts) as\b', r'\brepresents (?:a|an|the)\b', r'\bmarks (?:a|an|the)\b',
        r'\bboasts\b', r'\bfeatures (?:an?|the|\d[\d,.]*|several|many|numerous|multiple|various|dozens|hundreds|thousands|millions)\b',
        r'\boffers an? ', r'\brefers to\b']

_F69 = [r'\bunlocking (?:\w+ )?full potential\b', r'\bnavigating the complexities\b',
        r'\ba testament to the (?:power|importance) of\b', r'\bstaying ahead of the curve\b',
        r'\bturning challenges into opportunities\b', r'\btaking \w+ to the next level\b',
        r'\bharnessing the power of\b', r'\bpaving the way for\b', r'\bsaying goodbye to\b',
        r'\bimagining a world where\b']

_F63 = [r'\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\](?![(\[])',
        r'\[(?=[^\]\n]*(?-i:[A-Z]{3}))(?-i:[A-Z][A-Z0-9 _-]*)\](?![(\[])',
        r'\{\{[^}\n]*\}\}', r'(?<![A-Za-z])[xX]{3,}(?![A-Za-z])', r'\blorem ipsum\b']

_F64 = [r'\bcite(?:turn|start|nav)\w*', r'\boai_citation\w*', r'\bcontentReference\w*',
        r'\bnavlist\w*', '【\\d+†[^】\\n]*】']

_F65 = [r'utm_source=(?:chatgpt\.com|chat\.openai\.com|perplexity\.ai|claude\.ai|gemini\.google\.com|copilot\.microsoft\.com|poe\.com)(?![\w-]|\.[\w-])']

_F69_fn = _rx_fn(_F69)

HEDGE_RE = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems? to|seems? like|appears? to|somewhat|relatively|fairly|kind of|sort of)\b")
FP_RE = re.compile(r"\b(?:I|me|my|we|our|us|myself|ourselves)\b", re.I)
FULL_FORM_RE = re.compile(r"\b(?:I am|I have|I will|I would|I had|we are|we have|we will|we would|you are|you will|they are|they will|it is|that is|there is|do not|does not|did not|is not|are not|was not|were not|have not|has not|will not|would not|cannot|should not|could not|must not|let us)\b", re.I)
CONTR_RE = re.compile(r"\b\w+(?:n['’]t|['’](?:re|ve|ll|m|d))\b")
TRANSITIONS = {'additionally', 'furthermore', 'moreover', 'however', 'nevertheless', 'consequently',
               'subsequently', 'notably'}
BULLET_RE = re.compile(r'^\s*(?:[-*+]|\d+[.)])\s+')
HEAD_RE = re.compile(r'^ {0,3}#{1,6}(?:\s+|$)')
HR_RE = re.compile(r'^ {0,3}(?:(?:-[ \t]*){3,}|(?:\*[ \t]*){3,}|(?:_[ \t]*){3,})$')
MINOR_WORDS = {'a', 'an', 'the', 'and', 'but', 'or', 'nor', 'for', 'so', 'yet', 'at', 'by', 'in', 'of',
               'off', 'on', 'to', 'up', 'as', 'from', 'with', 'into', 'over', 'via', 'per', 'out', 'onto', 'vs'}
EMOJI_RE = re.compile('[\U0001F000-\U0001FAFF\u2300-\u23FF\u2600-\u27BF\u2B00-\u2BFF'
                      '\u00A9\u00AE\u203C\u2049\u2122\u2139\u3030\u303D\u3297\u3299\u25AA\u25AB'
                      '\u25B6\u25C0\u25FB-\u25FE\u2194-\u21AA]')


def _fam34(ctx):
    if re.search(r'^ {0,3}#{1,6}\s', ctx.masked, re.M):
        return []
    lists = 0
    prose = 0
    for b in ctx.blocks:
        if all(BULLET_RE.match(line) for line in b):
            lists += 1
        else:
            prose += 1
    return ['bulleted paragraph'] * lists if lists >= 1 and prose >= 2 else []


def _heading_text(line):
    return re.sub(r'^ {0,3}#{1,6}\s*', '', line).rstrip('# \t').strip()


def _fam35(ctx):
    hits = []
    lines = ctx.lines
    for i, line in enumerate(lines):
        if not HEAD_RE.match(line):
            continue
        hwords = {w.lower() for w in re.findall(r"[^\W\d_]{3,}", _heading_text(line))}
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nxt = lines[j].strip()
        if not nxt or re.match(r'^(?:#|[-*+>|]|\d+[.)]\s|```|~~~)', nxt):
            continue
        if len(nxt.split()) > 4 or len(nxt) > 40:
            continue
        nwords = {w.lower() for w in re.findall(r"[^\W\d_]{3,}", nxt)}
        if hwords & nwords:
            hits.append(nxt)
    return hits


def _fam37(ctx):
    hits = []
    for b in ctx.blocks:
        found = []
        for s in _sentences_of('\n'.join(b)):
            fw = _first_words(s, 1)
            if fw and fw[0] in TRANSITIONS:
                found.append(fw[0])
        if len(found) >= 2:
            hits.extend(found)
    return hits


def _fam40(ctx):
    lens = ctx.sent_lens
    if len(lens) >= 3 and _cv(lens) < 0.35:
        return ['sentence lengths nearly constant']
    return []


def _fam41(ctx):
    lens = ctx.sent_lens
    hits = []
    if len(lens) < 6:
        return hits
    diffs = [lens[i + 1] - lens[i] for i in range(len(lens) - 1)]
    cur = 1
    prev = 0
    for d in diffs:
        big = abs(d) >= 4
        if big and abs(prev) >= 4 and (d > 0) != (prev > 0):
            cur += 1
        else:
            cur = 2 if big else 1
        if cur == 6:
            hits.append('alternating sentence lengths')
        prev = d if big else 0
    return hits


def _fam42(ctx):
    hits = []
    for b in ctx.blocks:
        sents = _sentences_of('\n'.join(b))
        if len(sents) < 3:
            continue
        c = Counter(' '.join(_first_words(s, 2)) for s in sents)
        for k, v in c.items():
            if v >= 3 and k.strip():
                hits.append(k)
                break
    return hits


def _fam44(ctx):
    counts = [c for c in (_wc('\n'.join(b)) for b in ctx.blocks) if c > 0]
    if len(counts) >= 4 and _cv(counts) < 0.4:
        return ['uniform paragraph lengths']
    return []


def _fam46(ctx):
    if ctx.nwords < 300:
        return []
    if ';' in ctx.masked or ctx.masked.count('(') > 1:
        return []
    return ['no semicolons and almost no parentheses']


def _fam54(ctx):
    return [s for s in ctx.sentences if len(HEDGE_RE.findall(s)) >= 2]


def _fam55(ctx):
    if ctx.nwords == 0:
        return []
    fp = len(FP_RE.findall(ctx.masked))
    if fp < 3 or fp < 0.03 * ctx.nwords:
        return []
    full = len(FULL_FORM_RE.findall(ctx.masked))
    con = len(CONTR_RE.findall(ctx.masked))
    if full >= 3 and full >= 0.7 * (full + con):
        return ['uncontracted forms: %d' % full]
    return []


def _fam58(ctx):
    return ['paragraph with two or more em dashes' for b in ctx.blocks
            if '—' in '\n'.join(b) and '\n'.join(b).count('—') >= 2]


def _fam59(ctx):
    hits = []
    for line in ctx.lines:
        if not HEAD_RE.match(line):
            continue
        t = _heading_text(line)
        if len(t.split()) < 3 or not t[0].isalpha() or t.isupper():
            continue
        words = re.findall(r"[A-Za-z][A-Za-z'’-]*", t)
        major = [w for w in words if w.lower() not in MINOR_WORDS]
        if len(major) >= 2 and all(w[0].isupper() for w in major):
            hits.append(t)
    return hits


def _fam61(ctx):
    hits = []
    for m in re.finditer(r'\b(\d{4})-(\d{4})\b', ctx.masked):
        a, b = int(m.group(1)), int(m.group(2))
        if 1000 <= a < b <= 2999:
            hits.append(m.group(0))
    return hits


def _fam62(ctx):
    return (len(ctx.removed), [_describe(ctx.window, i) for i in ctx.removed[:3]])


def _fam67(ctx):
    return (len(ctx.normed), [_describe(ctx.window, i) for i in ctx.normed[:3]])


def _describe(text, i):
    ch = text[i]
    return 'U+%04X %s at character %d' % (ord(ch), unicodedata.name(ch, 'CONTROL CHARACTER'), i + 1)


def _fam66(ctx):
    return [t for t in ctx.homoglyph_tokens]


def _fam68(ctx):
    return ctx.trailing


def _fam70(ctx):
    if len(ctx.raw_lines) < 24:
        return []
    n = sum(1 for line in ctx.lines if HR_RE.match(line))
    return ['horizontal rule'] * n if n >= 3 else []


def _fam71(ctx):
    toks = [w.lower() for w in ctx.words]
    n = len(toks)
    if n < 12:
        return []
    grams = [tuple(toks[i:i + 6]) for i in range(n - 5)]
    cnt = Counter(grams)
    rep = [g for g in grams if cnt[g] > 1]
    if rep and len(rep) >= 0.2 * len(grams):
        return [' '.join(g) for g in rep]
    return []


def _fam_bold(ctx):
    return re.findall(r'\*\*[^*\n]+?\*\*', ctx.masked)


def _fam_curly(ctx):
    return re.findall('[“”‘’]', ctx.masked)


def _fam_emoji(ctx):
    return EMOJI_RE.findall(ctx.masked)


# ---------------------------------------------------------------- family table

class Family(object):
    def __init__(self, num, slug, label, fn, score=True, decisive=False, weight=8, min_hits=1):
        self.num = num
        self.key = '%d_%s' % (num, slug)
        self.label = label
        self.fn = fn
        self.score = score
        self.decisive = decisive
        self.weight = weight
        self.min_hits = min_hits


FAMILIES = [
    Family(1, 'ai_vocabulary', 'AI vocabulary', _rx_fn(VOCAB1)),
    Family(2, 'model_dialect_vocabulary', 'model-dialect vocabulary', _rx_fn(VOCAB2), min_hits=2),
    Family(3, 'promotional_language', 'promotional language', _fam3),
    Family(4, 'hyphenated_word_pair', 'hyphenated word-pair cliche', _rx_fn(HYPHEN_CLICHES), score=False),
    Family(5, 'simple_yet', '"simple yet" cliche', _rx_fn([r'\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b'])),
    Family(6, 'stacked_adjectives', 'stacked adjective chain', _fam6),
    Family(8, 'synonym_cycling', 'synonym cycling', _fam8),
    Family(10, 'significance_inflation', 'significance inflation', _rx_fn(_F10)),
    Family(11, 'notability_name_dropping', 'notability name-dropping', _rx_fn(_F11)),
    Family(12, 'vague_attribution', 'vague attribution', _rx_fn(_F12)),
    Family(13, 'article_title_proper_noun', 'article title used as a proper noun', _rx_fn(_F13, flags=0), decisive=True, weight=14),
    Family(14, 'conservation_padding', 'conservation or ecosystem padding', _rx_fn(_F14)),
    Family(15, 'false_range', 'false range', _rx_fn(_F15)),
    Family(16, 'ing_tail', 'superficial -ing tail clause', _rx_fn(_F16)),
    Family(17, 'negative_parallelism', 'negative parallelism', _rx_fn(_F17P), score=False),
    Family(17, 'tailing_negation', 'tailing negation', _rx_fn(_F17T)),
    Family(18, 'not_x_just_y', '"not X, just Y" framing', _rx_fn(_F18)),
    Family(19, 'filler_phrase', 'filler phrase', _rx_fn(_F19), score=False),
    Family(20, 'empty_pivot', 'empty pivot phrase', _rx_fn(_F20)),
    Family(21, 'outcome_speculation_tail', 'outcome-speculation tail', _rx_fn(_F21)),
    Family(22, 'persuasive_authority', 'persuasive authority trope', _rx_fn(_F22), score=False),
    Family(23, 'editorial_interjection', 'editorial interjection', _rx_fn(_F23)),
    Family(24, 'self_thoroughness', 'self-thoroughness phrase', _rx_fn(_F24)),
    Family(25, 'question_answer', 'question-answer rhetorical pattern', _rx_fn(_F25, flags=re.I | re.M)),
    Family(26, 'concrete_evidence', '"concrete evidence" defense phrase', _rx_fn(_F26)),
    Family(27, 'intro_hook', 'compulsive intro hook', _rx_fn(_F27)),
    Family(30, 'diff_anchored', 'diff-anchored writing', _rx_fn(_F30)),
    Family(31, 'signposting', 'signposting or announcement', _rx_fn(_F31)),
    Family(32, 'cataloguing_lead_in', 'cataloguing lead-in', _rx_fn(_F32)),
    Family(33, 'inline_header_list', 'inline-header vertical list', _rx_fn(_F33, flags=re.I | re.M)),
    Family(34, 'mid_essay_bullets', 'mid-essay bullet injection', _fam34),
    Family(35, 'fragmented_header', 'fragmented header', _fam35),
    Family(36, 'formulaic_challenges', 'formulaic challenges section', _rx_fn(_F36)),
    Family(37, 'transition_cluster', 'transition cluster', _fam37),
    Family(38, 'compulsive_conclusion', 'compulsive conclusion opener', _rx_fn(_F38, flags=re.I | re.M)),
    Family(39, 'generic_positive_ending', 'generic positive conclusion', _rx_fn(_F39)),
    Family(40, 'sentence_length_monotony', 'sentence-length monotony', _fam40, weight=5),
    Family(41, 'alternating_lengths', 'mechanical sentence-length alternation', _fam41, score=False),
    Family(42, 'opener_repetition', 'opener repetition', _fam42, score=False),
    Family(44, 'uniform_paragraphs', 'uniform paragraph length', _fam44, weight=5),
    Family(46, 'semicolon_underuse', 'semicolon and parenthesis underuse', _fam46, score=False),
    Family(47, 'chatbot_artifact', 'chatbot artifact', _rx_fn(_F47, flags=re.I), decisive=True, weight=14),
    Family(48, 'sycophantic_tone', 'sycophantic tone', _rx_fn(_F48), decisive=True, weight=14),
    Family(50, 'knowledge_cutoff', 'knowledge-cutoff disclaimer', _rx_fn(_F50), decisive=True, weight=14),
    Family(51, 'copula_avoidance', 'copula avoidance', _rx_fn(_F51)),
    Family(54, 'hedge_stacking', 'hedge stacking', _fam54, score=False),
    Family(55, 'contraction_absence', 'contraction absence', _fam55, score=False),
    Family(56, 'boldface_overuse', 'boldface in prose', _fam_bold, weight=4),
    Family(57, 'emoji', 'emoji', _fam_emoji, weight=6),
    Family(58, 'em_dash_overuse', 'em-dash overuse', _fam58, score=False),
    Family(59, 'title_case_heading', 'title case in a heading', _fam59, weight=5),
    Family(60, 'curly_quotes', 'curly quotation marks', _fam_curly, score=False),
    Family(61, 'hyphen_year_range', 'hyphen used for an en dash in a year range', _fam61, score=False),
    Family(62, 'invisible_characters', 'invisible or zero-width characters', _fam62, decisive=True, weight=14),
    Family(63, 'placeholder_text', 'placeholder text', _rx_fn(_F63, flags=re.I), decisive=True, weight=14),
    Family(64, 'chat_reference_markup', 'chat reference markup', _rx_fn(_F64, flags=re.I), decisive=True, weight=14),
    Family(65, 'ai_tracking_parameter', 'AI tracking parameter', _rx_fn(_F65, flags=re.I), decisive=True, weight=14),
    Family(66, 'mixed_script_homoglyphs', 'mixed-script homoglyphs', _fam66, decisive=True, weight=14),
    Family(67, 'non_standard_spaces', 'non-standard spaces', _fam67, weight=6),
    Family(68, 'trailing_whitespace', 'trailing or stray whitespace', _fam68, score=False),
    Family(69, 'marketing_slop', 'canonical marketing phrase', _rx_fn(_F69)),
    Family(70, 'decorative_rules', 'decorative horizontal rules', _fam70, weight=5),
    Family(71, 'degenerate_repetition', 'degenerate repetition', _fam71),
]

SMALL_DOC_FAMILY_NUMS = set(range(1, 40)) | set(range(47, 52)) | {69}


# ---------------------------------------------------------------- scoring

def band_of(score):
    if score <= 20:
        return 'clean'
    if score <= 40:
        return 'light tells'
    if score <= 60:
        return 'mixed'
    if score <= 80:
        return 'heavy tells'
    return 'pervasive tells'


def _score(fired, nwords):
    score_fams = {f.num for f, _, _ in fired if f.score}
    decisive_fams = {f.num for f, _, _ in fired if f.decisive and f.score}
    total = 0.0
    for f, count, _ in fired:
        if not f.score:
            continue
        e = count * 300.0 / max(nwords, 300)
        total += f.weight * (1.0 - 0.5 ** e)
    score = int(round(100.0 * (1.0 - math.exp(-total / 30.0))))
    nf = len(score_fams)
    if nf == 1:
        score = min(score, 40)
    if score_fams and score_fams <= {40, 44}:
        score = min(score, 40)
    if score_fams == {40}:
        score = min(score, 20)
    if decisive_fams:
        score = max(score, 45)
    if len(decisive_fams) >= 2:
        score = max(score, 65)
    if nwords < 120:
        small = len(score_fams & SMALL_DOC_FAMILY_NUMS)
        if small >= 3:
            score = max(score, 45)
        elif small >= 2:
            score = max(score, 25)
    if nwords >= 400:
        if nf >= 6:
            score = max(score, 45)
        elif nf >= 5:
            score = max(score, 25)
    return max(0, min(100, score)), nf


def _confidence(nwords, nf):
    if nwords < 40:
        return 'none', 'only %d words; fewer than 40 words cannot be scored with confidence' % nwords
    if nwords < 120:
        return 'low', 'fewer than 120 words'
    if nwords < 300 and nf == 1:
        return 'low', 'fewer than 300 words with only one score-moving family'
    if nwords < 300:
        return 'moderate', 'fewer than 300 words'
    return 'high', ''


# ---------------------------------------------------------------- analysis

def _build_ctx(window):
    ctx = Ctx()
    ctx.window = window
    removed, normed, _rtl = _layer_positions(window)
    ctx.removed = removed
    ctx.normed = normed
    ctx.homoglyph_tokens = _homoglyph_tokens(window)
    ctx.trailing = _trailing_hits(window)
    ctx.masked = mask_markdown(window)
    ctx.lines = ctx.masked.split('\n')
    ctx.raw_lines = window.split('\n')
    ctx.words = [w for w in WORD_RE.findall(ctx.masked) if any(c.isalnum() for c in w)]
    ctx.nwords = len(ctx.words)
    ctx.sentences = _sentences_of(ctx.masked)
    ctx.sent_lens = [_wc(s) for s in ctx.sentences]
    ctx.blocks = _blocks(ctx.lines)
    return ctx


def analyse(prose, ci=False):
    truncated = len(prose) > WINDOW
    window = prose[:WINDOW]
    ctx = _build_ctx(window)

    fired = []
    for fam in FAMILIES:
        res = fam.fn(ctx)
        if isinstance(res, tuple):
            count, raw_samples = res
            samples = [sample(s) for s in raw_samples[:3]]
        else:
            count = len(res)
            samples = []
            for h in res:
                s = sample(h)
                if s not in samples:
                    samples.append(s)
                if len(samples) >= 3:
                    break
        if count >= fam.min_hits and count > 0:
            fired.append((fam, count, samples))

    score, nf = _score(fired, ctx.nwords)
    band = band_of(score)
    conf, reason = _confidence(ctx.nwords, nf)
    homoglyphs = len(ctx.homoglyph_tokens)

    report = {}
    for fam, count, samples in fired:
        report[fam.key] = {'label': fam.label, 'count': int(count), 'samples': samples}
    metrics = {
        'scanned_chars': len(window),
        'truncated': truncated,
        'ai_tell_score': score,
        'ai_tell_band': band,
        'confidence': conf,
        'confidence_reason': reason,
        'patterns_flagged': len(fired),
        'invisible_chars': len(ctx.removed),
        'nonstandard_spaces': len(ctx.normed),
        'homoglyphs': homoglyphs,
        'words': ctx.nwords,
        'sentences': len(ctx.sentences),
    }
    if ci:
        interval, note = _interval(ctx, score, window)
        metrics['score_ci'] = interval
        metrics['score_ci_note'] = note
    report['_metrics'] = metrics
    return report


def _interval(ctx, point, window):
    sents = ctx.sentences
    n = len(sents)
    if n < 4:
        return None, 'too few sentences for an interval (%d found; four are needed)' % n
    reps = 12 if len(window) <= 60000 else 4
    rng = random.Random(0)
    vals = []
    for _ in range(reps):
        text = ' '.join(sents[rng.randrange(n)] for _ in range(n))
        vals.append(analyse(text)['_metrics']['ai_tell_score'])
    vals.sort()
    low = min(vals[int(0.1 * (reps - 1))], point)
    high = max(vals[int(round(0.9 * (reps - 1)))], point)
    return [low, high], ('bootstrap over sentences: %d resamples, seed 0; 10th to 90th percentile '
                         'of the resampled scores, widened to include the point score' % reps)


# ---------------------------------------------------------------- command line

def _write_bytes(data):
    sys.stdout.buffer.write(data)
    sys.stdout.flush()


def _write_error(message):
    sys.stderr.write(json.dumps({'error': message}, ensure_ascii=False) + '\n')
    sys.stderr.flush()


def main(argv=None):
    argv = sys.argv[1:] if argv is None else list(argv)
    clean = False
    ci = False
    operands = []
    end = False
    for arg in argv:
        if end:
            operands.append(arg)
        elif arg == '--':
            end = True
        elif arg in ('--help', '-h'):
            _write_bytes(USAGE.encode('utf-8'))
            return 0
        elif arg == '--clean':
            clean = True
        elif arg == '--ci':
            ci = True
        elif arg.startswith('-'):
            _write_error("unknown option '%s'; run detect.py --help for usage" % arg)
            return 2
        else:
            operands.append(arg)
    try:
        if operands:
            path = operands[-1]
            if len(operands) > 1:
                ignored = ', '.join("'%s'" % o for o in operands[:-1])
                sys.stderr.write("detect.py: %d file operands given; scanning only the last one, "
                                 "'%s' (not scanned: %s)\n" % (len(operands), path, ignored))
            prose = load_prose(path)
        else:
            prose = decode_bytes(sys.stdin.buffer.read())
        if not prose.strip():
            raise DetectError(1, 'empty input')
        if clean:
            _write_bytes(cleanup(prose).encode('utf-8'))
            return 0
        report = analyse(prose, ci=ci)
        _write_bytes((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
        return 0
    except DetectError as exc:
        _write_error(exc.message)
        return exc.status
    except Exception as exc:  # no traceback on the error stream
        _write_error('internal error: %s' % exc.__class__.__name__)
        return 1


if __name__ == '__main__':
    try:
        code = main()
    except BrokenPipeError:
        code = 0
    sys.exit(code)
