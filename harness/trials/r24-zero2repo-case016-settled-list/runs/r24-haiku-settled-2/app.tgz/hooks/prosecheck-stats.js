#!/usr/bin/env node
'use strict';
// Stats helper for `/prosecheck stats` (FP-06). Reads the session transcript and reports
// assistant turns, output tokens, cache-read tokens, and a score of the session's own prose.
const fs = require('fs');
const path = require('path');
const c = require('./prosecheck-common.js');

const PROSE_CAP_CHARS = 40000;
const PROSE_MIN_CHARS = 200;

function newestTranscript(dir) {
  let best = null;
  const walk = (d, depth) => {
    if (depth > 6) return;
    let entries = [];
    try { entries = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { return; }
    for (const ent of entries) {
      const full = path.join(d, ent.name);
      if (ent.isDirectory()) walk(full, depth + 1);
      else if (ent.isFile() && ent.name.endsWith('.jsonl')) {
        try {
          const mtime = fs.statSync(full).mtimeMs;
          if (!best || mtime > best.mtime) best = { file: full, mtime };
        } catch (e) { /* skip */ }
      }
    }
  };
  walk(dir, 0);
  return best;
}

function readTranscript(file) {
  let text = '';
  try { text = fs.readFileSync(file, 'utf8'); } catch (e) { return null; }
  const byId = new Map();
  let seq = 0;
  for (const line of text.split('\n')) {
    if (!line.trim()) continue;
    let obj;
    try { obj = JSON.parse(line); } catch (e) { continue; }
    if (!obj || obj.type !== 'assistant' || !obj.message || typeof obj.message !== 'object') continue;
    const m = obj.message;
    const key = typeof m.id === 'string' && m.id ? m.id : 'row-' + (seq++);
    const usage = m.usage && typeof m.usage === 'object' ? m.usage : {};
    const texts = [];
    if (Array.isArray(m.content)) {
      for (const part of m.content) {
        if (part && part.type === 'text' && typeof part.text === 'string') texts.push(part.text);
      }
    }
    byId.set(key, {
      output: Number(usage.output_tokens) || 0,
      cache: Number(usage.cache_read_input_tokens) || 0,
      text: texts.join('\n'),
    });
  }
  let output = 0;
  let cache = 0;
  const parts = [];
  for (const v of byId.values()) {
    output += v.output;
    cache += v.cache;
    if (v.text) parts.push(v.text);
  }
  return { turns: byId.size, output, cache, prose: parts.join('\n') };
}

function statsReply(input, form) {
  const level = c.resolveLevel();
  const lines = [];
  const named = typeof input.transcript_path === 'string' && input.transcript_path ? input.transcript_path : null;
  const newest = newestTranscript(path.join(c.configDir(), 'projects'));
  let chosen = null;
  if (named) {
    const namedStat = (() => { try { return fs.statSync(named).mtimeMs; } catch (e) { return null; } })();
    if (namedStat === null) {
      chosen = null;
    } else if (newest && newest.file !== named && newest.mtime > namedStat) {
      chosen = newest.file;
    } else {
      chosen = named;
    }
  } else if (newest) {
    chosen = newest.file;
  }
  const data = chosen ? readTranscript(chosen) : null;
  lines.push('prosecheck stats (' + (form || '/prosecheck') + ')');
  lines.push('level: ' + level);
  if (!data) {
    lines.push('No readable session transcript was found, so turn and token counts are not available.');
    return lines.join('\n');
  }
  lines.push('assistant turns: ' + data.turns);
  lines.push('output tokens: ' + data.output);
  lines.push('cache-read input tokens: ' + data.cache);
  const prose = data.prose.replace(/```[\s\S]*?(?:```|$)/g, ' ');
  const slice = prose.slice(-PROSE_CAP_CHARS).trim();
  if (slice.length > PROSE_MIN_CHARS) {
    const res = c.runDetector([], { input: slice, timeout: 15000 });
    if (res.kind === 'ok') {
      lines.push('session prose ai_tell_score: ' + res.data._metrics.ai_tell_score);
    } else {
      lines.push('session prose score: not available (the detector did not return a score)');
    }
  } else {
    lines.push('session prose score: not enough assistant prose yet');
  }
  return lines.join('\n');
}

module.exports = { statsReply, readTranscript, newestTranscript };

if (require.main === module) {
  try {
    const input = c.readStdinJson();
    process.stdout.write(c.blockReply(statsReply(input, '/prosecheck stats')));
  } catch (e) {
    /* exit 0 regardless */
  }
  process.exitCode = 0;
}
