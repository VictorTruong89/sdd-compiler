'use strict';
// Shared logic for the prosecheck plugin hooks (Node.js, standard library only).
// See spec/Full_PRD.md (FP-04..FP-06) and spec/Interface_Contract.md (hooks, /prosecheck).

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const LEVELS = ['lite', 'full', 'strict', 'off'];
const SUBCOMMANDS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];
const FULL_THRESHOLD = 40;
const STRICT_THRESHOLD = 20;
const WINDOW_TEXT = '262,144';
const PLAIN_KB = 512;
const ARCHIVE_KB = 4096;
const LEDGER_MAX = 50;
const LEDGER_LABEL_CAP = 5;
const CHECK_TELL_CAP = 8;
const LEDGER_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000;
const PLAIN_EXTS = ['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'];
const ARCHIVE_EXTS = ['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub', '.ipynb'];
const BINARY_EXTS = ['.pdf', '.rtf'];
const PROSE_EXTS = PLAIN_EXTS.concat(ARCHIVE_EXTS.filter((e) => e !== '.ipynb'), ['.ipynb']);
const INSTRUCTION_NAMES = ['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md'];
const INSTRUCTION_STEMS = ['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory'];
const TIMEOUT_PLAIN_MS = 8000;
const TIMEOUT_ARCHIVE_MS = 15000;
const PYTHONS = ['python3', 'python', 'py'];

const BANNED = ['delve', 'tapestry', 'pivotal', 'crucial', 'leverage', 'robust', 'seamless', 'foster',
  'underscore', 'showcase', 'landscape (abstract)', 'journey (abstract)', 'realm', 'multifaceted',
  'holistic', 'testament', 'vibrant', 'comprehensive', 'plethora', 'myriad', 'boast', 'elevate',
  'empower', 'unlock', 'game-changer', 'supercharge', 'genuinely', 'fascinating', 'nuanced'];

const HOOK_PHRASES = {
  'clean': 'reads clean',
  'light tells': 'reads mostly clean',
  'mixed': 'reads with some AI tells',
  'heavy tells': 'reads with heavy AI tells',
  'pervasive tells': 'reads with pervasive AI tells',
};

function bandOf(score) {
  if (score <= 20) return 'clean';
  if (score <= 40) return 'light tells';
  if (score <= 60) return 'mixed';
  if (score <= 80) return 'heavy tells';
  return 'pervasive tells';
}

function phraseOf(band) {
  return HOOK_PHRASES[band] || HOOK_PHRASES['mixed'];
}

function configDir() {
  return process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
}

function pluginRoot() {
  return process.env.CLAUDE_PLUGIN_ROOT || path.resolve(__dirname, '..');
}

function detectorPath() {
  const root = pluginRoot();
  for (const rel of [path.join('scripts', 'detect.py'), path.join('skills', 'prosecheck', 'scripts', 'detect.py')]) {
    const p = path.join(root, rel);
    if (fs.existsSync(p)) return p;
  }
  return path.join(root, 'scripts', 'detect.py');
}

function flagPath() {
  return path.join(configDir(), '.prosecheck-active');
}

function readStoredLevel() {
  try {
    const v = fs.readFileSync(flagPath(), 'utf8').trim().toLowerCase();
    return LEVELS.includes(v) ? v : null;
  } catch (e) {
    return null;
  }
}

// A valid stored level wins; the environment supplies the level only when nothing valid is stored.
function resolveLevel() {
  const stored = readStoredLevel();
  if (stored) return stored;
  const env = (process.env.PROSECHECK_DEFAULT_MODE || '').trim().toLowerCase();
  if (LEVELS.includes(env)) return env;
  return 'full';
}

function writeLevel(level) {
  fs.mkdirSync(configDir(), { recursive: true });
  fs.writeFileSync(flagPath(), level);
}

function thresholdFor(level) {
  return level === 'strict' ? STRICT_THRESHOLD : FULL_THRESHOLD;
}

function readStdinJson() {
  let raw = '';
  try {
    raw = fs.readFileSync(0, 'utf8');
  } catch (e) {
    return {};
  }
  try {
    const v = JSON.parse(raw);
    return v && typeof v === 'object' && !Array.isArray(v) ? v : {};
  } catch (e) {
    return {};
  }
}

// ---------------------------------------------------------------- detector runs

// Runs the bundled detector with the first Python that can be launched.
// Returns { kind, code, stdout, stderr } where kind is one of:
// missing, timeout, failed, empty, text, noscore, ok.
function runDetector(args, options) {
  const opts = options || {};
  const detector = detectorPath();
  let sawLaunch = false;
  for (const py of PYTHONS) {
    const res = spawnSync(py, [detector].concat(args || []), {
      input: opts.input,
      encoding: 'utf8',
      timeout: opts.timeout || TIMEOUT_PLAIN_MS,
      maxBuffer: 64 * 1024 * 1024,
      windowsHide: true,
      env: process.env,
    });
    if (res.error) {
      if (res.error.code === 'ETIMEDOUT') return { kind: 'timeout', code: null, stdout: '', stderr: '' };
      continue;
    }
    sawLaunch = true;
    const stdout = res.stdout || '';
    const stderr = res.stderr || '';
    if (res.status !== 0) return { kind: 'failed', code: res.status, stdout, stderr };
    if (!stdout.trim()) return { kind: 'empty', code: 0, stdout, stderr };
    let data = null;
    try {
      data = JSON.parse(stdout);
    } catch (e) {
      data = null;
    }
    if (!data || typeof data !== 'object' || !data._metrics) {
      return { kind: 'text', code: 0, stdout, stderr };
    }
    if (typeof data._metrics.ai_tell_score !== 'number') {
      return { kind: 'noscore', code: 0, stdout, stderr, data };
    }
    return { kind: 'ok', code: 0, stdout, stderr, data };
  }
  return { kind: sawLaunch ? 'failed' : 'missing', code: null, stdout: '', stderr: '' };
}

function lastErrorLine(stderr) {
  const lines = String(stderr || '').split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  if (!lines.length) return '';
  const last = lines[lines.length - 1];
  try {
    const obj = JSON.parse(last);
    if (obj && typeof obj.error === 'string') return obj.error;
  } catch (e) {
    /* plain text */
  }
  return last;
}

function labelsOf(data) {
  return Object.keys(data).filter((k) => k !== '_metrics').map((k) => ({ key: k, label: data[k].label, count: data[k].count }));
}

// ---------------------------------------------------------------- ledger

function ledgerPath(sessionId) {
  const sid = String(sessionId || '').replace(/[^A-Za-z0-9_-]/g, '_');
  return path.join(configDir(), sid ? '.prosecheck-ledger-' + sid : '.prosecheck-ledger');
}

function readLedgerRaw(sessionId) {
  const file = ledgerPath(sessionId);
  let st;
  try {
    st = fs.statSync(file);
  } catch (e) {
    return [];
  }
  if (Date.now() - st.mtimeMs > LEDGER_MAX_AGE_MS) return [];
  let text = '';
  try {
    text = fs.readFileSync(file, 'utf8');
  } catch (e) {
    return [];
  }
  const out = [];
  for (const line of text.split('\n')) {
    if (!line.trim()) continue;
    try {
      out.push(JSON.parse(line));
    } catch (e) {
      /* skip damaged line */
    }
  }
  return out;
}

function appendLedger(sessionId, rec) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    const recs = readLedgerRaw(sessionId);
    recs.push(Object.assign({ ts: Date.now() }, rec));
    const kept = recs.slice(-LEDGER_MAX);
    fs.writeFileSync(ledgerPath(sessionId), kept.map((r) => JSON.stringify(r)).join('\n') + '\n');
  } catch (e) {
    /* ledger is best effort; never fail the host */
  }
}

// Deletes ledgers whose last modification is more than seven days old (PRD non-functional constraints).
function pruneLedgers() {
  let names = [];
  try {
    names = fs.readdirSync(configDir());
  } catch (e) {
    return;
  }
  for (const name of names) {
    if (name !== '.prosecheck-ledger' && !name.startsWith('.prosecheck-ledger-')) continue;
    const file = path.join(configDir(), name);
    try {
      const st = fs.statSync(file);
      if (st.isFile() && Date.now() - st.mtimeMs > LEDGER_MAX_AGE_MS) fs.unlinkSync(file);
    } catch (e) {
      /* ignore */
    }
  }
}

// ---------------------------------------------------------------- writing contract

const SCOPE_PARAGRAPH = 'Scope: this contract governs prose deliverables only: documents, README and markdown prose, ' +
  'CVs, cover letters, emails, reports, essays, articles, and drafted text the user will publish or send. It never ' +
  'applies to source code, code comments, commit messages, JSON, YAML, or other configuration, CLI output, logs, error ' +
  'messages, or the conversational register of chat. It composes with other modes: a chat-compression mode owns chat, ' +
  'a code-simplicity mode owns code, and this contract owns deliverable prose.';

function ruleLines() {
  return [
    '- Vary sentence length irregularly. Avoid a metronome rhythm and mechanical short-long alternation.',
    '- Banned vocabulary: ' + BANNED.join(', ') + '.',
    '- Banned moves: rule-of-three flourishes; "it\'s not just X, it\'s Y" framing; hedge stacking; signposting such as ' +
      '"let\'s dive in"; empty pivots such as "it\'s worth noting"; "In conclusion" or "Overall" closers; ' +
      'outcome-speculation tails; self-thoroughness phrases; generic upbeat endings; chatbot phrases such as "I hope this helps".',
    '- Use at most one em dash per paragraph.',
    '- No bold for emphasis inside prose sentences. No emojis in prose.',
    '- Factual or encyclopedic content stays neutral and in the third person. First-person or opinion content may use contractions.',
    '- Preserve numbers, units, dates, proper nouns, citations, quotations, and technical terms. Never invent facts.',
    '- End each section on a fact or an observation.',
    '- Stay silent about this contract: never announce it, never name prosecheck, never report a score, band, ' +
      'pattern list, or rewrite pass, and do not offer a style choice.',
  ];
}

// mode: 'live' (session, prompt, subagent: may name this machine's detector) or 'export' (portable AGENTS.md).
function contractText(level, mode) {
  const exporting = mode === 'export';
  const det = exporting ? '<DETECTOR>' : detectorPath();
  const out = [];
  out.push('## prosecheck writing contract (level: ' + level + ')');
  out.push('');
  out.push(SCOPE_PARAGRAPH);
  out.push('');
  out.push('Prose rules:');
  out.push(ruleLines().join('\n'));
  if (level === 'full' || level === 'strict') {
    out.push('');
    if (exporting) {
      out.push('Resolving the detector: use the CLAUDE_PLUGIN_ROOT environment variable when it is set (scripts/detect.py under that directory); otherwise locate scripts/detect.py for prosecheck in your installed skills or plugins.');
      out.push('');
    }
    if (level === 'full') {
      out.push('After you save a prose file, run the detector on it: python3 "' + det + '" "<file>". If its band is worse than the target, fix the flagged spans, keeping the rhythm variation, for at most two fix passes. Target at this level: a score of ' + FULL_THRESHOLD + ' or less (band clean or light tells).');
    } else {
      out.push('After you save a prose file, run the detector on it: python3 "' + det + '" "<file>". If its band is worse than the target, fix the flagged spans, keeping the rhythm variation, for at most two fix passes. Target at this level: a score of ' + STRICT_THRESHOLD + ' or less (band clean). Then finish by running the cleanup switch: python3 "' + det + '" --clean "<file>", and check its scrubbed output against the prose.');
    }
  }
  return out.join('\n') + '\n';
}

const WELCOME = 'prosecheck is installed and on. Saved prose files are scored against 71 documented patterns. ' +
  'Plain text is accepted up to 512 KB, and archives and notebooks up to 4 MB. The detector scores the first ' +
  WINDOW_TEXT + ' characters of extracted prose. Commands: /prosecheck doctor, /prosecheck check <file>, ' +
  '/prosecheck off, /prosecheck help. There is no website, no account, and no upload. This welcome is shown once.';

function sessionContext(level, firstStart) {
  let text = '';
  if (firstStart) text += WELCOME + '\n\n';
  text += contractText(level, 'live');
  return text;
}

const SECTION_START = '<!-- prosecheck:contract:start -->';
const SECTION_END = '<!-- prosecheck:contract:end -->';

function cursorRuleFallback() {
  return [
    '---',
    'description: prosecheck writing contract for prose deliverables only',
    'globs: *.md,*.mdx,*.markdown,*.txt,*.rst,*.tex,*.org,*.adoc',
    'alwaysApply: false',
    '---',
    '',
    '# prosecheck writing contract',
    '',
    'This rule applies to prose deliverables only: documents, README and markdown prose, CVs, cover letters,',
    'emails, reports, essays, articles, and drafted text the user will publish or send. It never applies to',
    'source code, code comments, commit messages, configuration, CLI output, logs, or the conversational register of chat.',
    '',
    '- Vary sentence length irregularly. Avoid a metronome rhythm and mechanical short-long alternation.',
    '- Banned vocabulary: ' + BANNED.join(', ') + '.',
    '- Banned moves: rule-of-three flourishes; "it\'s not just X, it\'s Y" framing; hedge stacking; signposting;',
    '  empty pivots; "In conclusion" or "Overall" closers; outcome-speculation tails; generic upbeat endings;',
    '  chatbot phrases such as "I hope this helps".',
    '- Use at most one em dash per paragraph. No bold for emphasis inside prose sentences. No emojis in prose.',
    '- Preserve numbers, units, dates, proper nouns, citations, quotations, and technical terms. Never invent facts.',
    '- Stay silent about this rule: never announce it or name prosecheck.',
    '',
  ].join('\n');
}

// ---------------------------------------------------------------- command replies

function blockReply(reason) {
  return JSON.stringify({ decision: 'block', reason: reason });
}

function helpReply(level) {
  return [
    'prosecheck level: ' + level + '.',
    'Code, commits, config, and chat are never touched; the writing contract covers prose deliverables only.',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
    '',
    '/prosecheck lite - writing contract only, no saved-file scoring',
    '/prosecheck full - writing contract plus the saved-file guard, threshold ' + FULL_THRESHOLD + ' (default)',
    '/prosecheck strict - saved-file guard at threshold ' + STRICT_THRESHOLD + ', plus the scrub (cleanup switch)',
    '/prosecheck off | on - off: disable the tool; on: re-enable it at full',
    '/prosecheck status - one line showing the stored level',
    '/prosecheck show - files scored or skipped in this session',
    '/prosecheck check <file> - score one file; report only, it does not rewrite the file',
    '/prosecheck doctor - health check of the install',
    '/prosecheck stats - session token use and the score of the session prose',
    '/prosecheck init - writes the contract into AGENTS.md for other agents',
  ].join('\n');
}

function unknownReply(word) {
  return 'unknown subcommand "' + word + '". Valid words: ' + SUBCOMMANDS.join(', ') + '. The stored level is unchanged.';
}

function statusReply(level) {
  return 'prosecheck status: level is ' + level + '.';
}

function cmdLevel(sub) {
  writeLevel(sub);
  if (sub === 'off') {
    return 'prosecheck is now off. Saved files are not scored and no contract is sent. Run /prosecheck on to turn it back on.';
  }
  return 'prosecheck level set to ' + sub + '. Saved prose files are scored as this level directs.';
}

function cmdOn() {
  writeLevel('full');
  return 'prosecheck is on (full). The writing contract is active and saved prose files are scored at threshold ' + FULL_THRESHOLD + '.';
}

function cmdShow(sessionId) {
  const recs = readLedgerRaw(sessionId).map((r, i) => ({ r, i }));
  if (!recs.length) {
    return 'prosecheck show: nothing scored yet in this session. Rows appear after prose files, including .docx and .pdf deliverables, are saved.';
  }
  recs.sort((a, b) => (b.r.ts || 0) - (a.r.ts || 0) || b.i - a.i);
  const rows = ['prosecheck show: files saved in this session, newest first:'];
  for (const { r } of recs) {
    rows.push(r.base + ' - ' + showBody(r));
  }
  return rows.join('\n');
}

function showBody(r) {
  if (r.kind === 'scored') {
    let body = r.phrase + ' (score ' + r.score + '/' + r.band + (r.truncated ? ', first ' + WINDOW_TEXT + ' characters only' : '') + ')';
    if (r.labels && r.labels.length) {
      const state = r.flagged ? 'flagged' : 'under threshold';
      body += ' - ' + state + ': ' + r.labels.slice(0, LEDGER_LABEL_CAP).join('; ');
    }
    return body;
  }
  if (r.kind === 'skip') return 'not scored: over the ' + r.limitKb + ' KB limit';
  if (r.kind === 'binary') return 'not re-scored (binary format)';
  return 'not scored: ' + (r.reason || 'unknown reason');
}

function cleanPathArg(arg) {
  let p = String(arg || '').trim();
  if (p.startsWith('@')) p = p.slice(1);
  if (p.length >= 2 && ((p[0] === '"' && p[p.length - 1] === '"') || (p[0] === "'" && p[p.length - 1] === "'"))) {
    p = p.slice(1, -1);
  }
  return p;
}

function cmdCheck(arg) {
  const typed = cleanPathArg(arg);
  if (!typed) {
    return 'check needs a file path, for example: /prosecheck check notes/essay.md. It reports only; the file is not rewritten.';
  }
  const full = path.resolve(process.cwd(), typed);
  const base = path.basename(full);
  let st;
  try {
    st = fs.statSync(full);
  } catch (e) {
    return 'cannot read ' + typed + ': no such file.';
  }
  if (st.isDirectory() || !st.isFile()) return typed + ' is not a file.';
  const ext = path.extname(full).toLowerCase();
  if (BINARY_EXTS.includes(ext)) return base + ': no readable text in this format (' + ext + ').';
  const archive = ARCHIVE_EXTS.includes(ext);
  const capKb = archive ? ARCHIVE_KB : PLAIN_KB;
  if (st.size > capKb * 1024) return base + ': not scored, over ' + capKb + ' KB.';
  const res = runDetector([full], { timeout: archive ? TIMEOUT_ARCHIVE_MS : TIMEOUT_PLAIN_MS });
  switch (res.kind) {
    case 'missing':
      return base + ': detector unavailable, because Python cannot be launched.';
    case 'timeout':
      return base + ' failed: the detector timed out.';
    case 'failed': {
      const why = lastErrorLine(res.stderr);
      return base + ' failed: ' + (why || 'the detector ended with an error and no message');
    }
    case 'empty':
      return base + ': no report from the detector.';
    case 'text':
    case 'noscore':
      return 'no report: the detector printed text that is not a report.';
    default:
      break;
  }
  const m = res.data._metrics;
  const band = m.ai_tell_band;
  const lines = [];
  lines.push(base + ' - ' + phraseOf(band) + ' (score ' + m.ai_tell_score + '/100, band: ' + band + ')');
  lines.push('confidence: ' + m.confidence + (m.confidence !== 'high' && m.confidence_reason ? ' - ' + m.confidence_reason : ''));
  if (m.truncated) lines.push('coverage: first ' + WINDOW_TEXT + ' characters only');
  const labs = labelsOf(res.data).slice(0, CHECK_TELL_CAP);
  if (labs.length) {
    lines.push('tells: ' + labs.map((l) => l.label + ' (x' + l.count + ')').join('; '));
  } else {
    lines.push('tells: none');
  }
  lines.push('report only: this shows the score and does not rewrite the file.');
  return lines.join('\n');
}

function commandForm(form) {
  return form === '/prosecheck:prosecheck' ? '/prosecheck:prosecheck' : '/prosecheck';
}

function cmdDoctor(form) {
  const level = resolveLevel();
  const f = commandForm(form);
  const lines = [];
  let allOk = true;
  let modeOk = level !== 'off';
  if (modeOk) {
    lines.push('mode: ' + level + ' [OK]');
  } else {
    lines.push('mode: off - not a fault of the install; saving files triggers no scoring until you run /prosecheck on');
  }
  const detectorOk = fs.existsSync(detectorPath());
  if (detectorOk) {
    lines.push('detector: bundled detector found [OK]');
  } else {
    lines.push('detector: bundled detector missing from the plugin tree');
    allOk = false;
  }
  const probe = runDetector([], { input: 'Sample prose for the doctor check. It reads plainly.', timeout: 15000 });
  if (probe.kind === 'missing') {
    lines.push('python not found: saved files will not be re-scored until Python is available, but prose is still shaped by the writing contract.');
    allOk = false;
  } else if (probe.kind === 'ok') {
    lines.push('python ran the bundled detector and produced a numeric score [OK]');
  } else {
    lines.push('python ran but the bundled detector did not return a numeric score.');
    allOk = false;
  }
  let settingsOk = true;
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    const probeFile = path.join(configDir(), '.prosecheck-write-test-' + process.pid);
    fs.writeFileSync(probeFile, 'ok');
    fs.unlinkSync(probeFile);
  } catch (e) {
    settingsOk = false;
  }
  if (settingsOk) {
    lines.push('settings folder writable [OK]');
  } else {
    lines.push('settings folder not writable');
    allOk = false;
  }
  const title = 'prosecheck health check';
  const out = [title].concat(lines);
  if (allOk && modeOk) {
    out.push('All four checks passed: prosecheck is active. Plain text is capped at 512 KB and archives or notebooks at 4 MB; the scan window is the first ' + WINDOW_TEXT + ' characters. Run ' + f + ' show to see files that were only partly scanned or skipped.');
  } else if (!allOk) {
    out.push('Some checks need attention: fix the faulty checks, then run /prosecheck doctor again.');
  } else {
    out.push('The install is healthy. Saving files triggers no scoring while the tool is off; run ' + f + ' on to turn it back on.');
  }
  return out.join('\n');
}

function cmdInit(form) {
  const level = resolveLevel();
  const f = commandForm(form);
  if (level === 'off') {
    return 'prosecheck is switched off, so init wrote no files. Run ' + f + ' on to allow the export.';
  }
  const replies = [];
  const agentsPath = path.join(process.cwd(), 'AGENTS.md');
  let existing = null;
  try {
    existing = fs.readFileSync(agentsPath, 'utf8');
  } catch (e) {
    if (e.code !== 'ENOENT') {
      replies.push('cannot read AGENTS.md: ' + e.code + '; it was not given the contract.');
      existing = undefined;
    }
  }
  if (existing !== undefined) {
    if (existing !== null && (existing.includes(SECTION_START) || existing.includes('## prosecheck writing contract'))) {
      replies.push('AGENTS.md already has the prosecheck contract section; it was left unchanged.');
    } else {
      const section = SECTION_START + '\n' + contractText(level, 'export') + SECTION_END + '\n';
      const prefix = existing ? existing.replace(/\s*$/, '') + '\n\n' : '';
      try {
        fs.writeFileSync(agentsPath, prefix + section);
        replies.push('wrote the prosecheck writing contract into AGENTS.md (level: ' + level + ').');
      } catch (e) {
        replies.push('cannot write AGENTS.md: ' + e.code + '; the file was not given the contract.');
      }
    }
  }
  const ruleDest = path.join(process.cwd(), '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(ruleDest)) {
    replies.push('prosecheck.mdc already exists in .cursor/rules; it was not overwritten.');
  } else {
    let body = null;
    try {
      body = fs.readFileSync(path.join(pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc'), 'utf8');
    } catch (e) {
      body = cursorRuleFallback();
    }
    try {
      fs.mkdirSync(path.dirname(ruleDest), { recursive: true });
      fs.writeFileSync(ruleDest, body);
      replies.push('copied the Cursor rule to .cursor/rules/prosecheck.mdc.');
    } catch (e) {
      replies.push('cannot write .cursor/rules/prosecheck.mdc: ' + e.code + '; the rule was not created.');
    }
  }
  return replies.join('\n');
}

// Parses a `/prosecheck` command prompt. Returns null when the prompt is not a command.
function parseCommand(prompt) {
  const m = /^\s*\/prosecheck(:prosecheck)?(?=\s|$)([\s\S]*)$/i.exec(prompt);
  if (!m) return null;
  const form = m[1] ? '/prosecheck:prosecheck' : '/prosecheck';
  const rest = (m[2] || '').trim();
  const parts = rest ? rest.split(/\s+/) : [];
  const sub = (parts[0] || '').toLowerCase();
  const arg = parts.slice(1).join(' ');
  return { form, sub, arg };
}

module.exports = {
  LEVELS, SUBCOMMANDS, FULL_THRESHOLD, STRICT_THRESHOLD, PLAIN_EXTS, ARCHIVE_EXTS, BINARY_EXTS, PROSE_EXTS,
  INSTRUCTION_NAMES, INSTRUCTION_STEMS, PLAIN_KB, ARCHIVE_KB, LEDGER_LABEL_CAP, TIMEOUT_PLAIN_MS, TIMEOUT_ARCHIVE_MS,
  WINDOW_TEXT, BANNED, configDir, pluginRoot, detectorPath, flagPath, readStoredLevel, resolveLevel, writeLevel,
  thresholdFor, readStdinJson, runDetector, lastErrorLine, labelsOf, ledgerPath, readLedgerRaw, appendLedger,
  pruneLedgers, contractText, sessionContext, cursorRuleFallback, blockReply, helpReply, unknownReply,
  statusReply, cmdLevel, cmdOn, cmdShow, cmdCheck, cmdDoctor, cmdInit, parseCommand, phraseOf, bandOf,
  cleanPathArg, commandForm,
};
