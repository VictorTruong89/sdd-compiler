#!/usr/bin/env node
'use strict';
// Prompt-submit hook and /prosecheck command router (FP-04, FP-06). Always exits 0.
const c = require('./prosecheck-common.js');
const { statsReply } = require('./prosecheck-stats.js');

function reply(obj) {
  process.stdout.write(JSON.stringify(obj));
}

function route(input) {
  const prompt = typeof input.prompt === 'string' ? input.prompt : '';
  const sid = typeof input.session_id === 'string' ? input.session_id : '';

  // "stop prosecheck" anywhere switches the tool off (ruling 8); "prosecheck off" only as the whole prompt.
  if (/stop prosecheck/i.test(prompt) || /^\s*prosecheck off\s*$/i.test(prompt)) {
    c.writeLevel('off');
    return { decision: 'block', reason: c.cmdLevel('off') };
  }

  const cmd = c.parseCommand(prompt);
  if (!cmd) {
    const level = c.resolveLevel();
    if (level === 'off') return null;
    return {
      hookSpecificOutput: {
        hookEventName: 'UserPromptSubmit',
        additionalContext: 'prosecheck level: ' + level + '. Prose deliverables follow the writing contract; code, config, and commits are untouched.',
      },
    };
  }

  const { form, sub, arg } = cmd;
  let text;
  if (sub === '') {
    text = c.helpReply(c.resolveLevel());
  } else if (sub === 'lite' || sub === 'full' || sub === 'strict' || sub === 'off') {
    text = c.cmdLevel(sub);
  } else if (sub === 'on') {
    text = c.cmdOn();
  } else if (sub === 'status') {
    text = c.statusReply(c.resolveLevel());
  } else if (sub === 'show') {
    text = c.cmdShow(sid);
  } else if (sub === 'check') {
    text = c.cmdCheck(arg);
  } else if (sub === 'doctor') {
    text = c.cmdDoctor(form);
  } else if (sub === 'stats') {
    text = statsReply(input, form);
  } else if (sub === 'init') {
    text = c.cmdInit(form);
  } else if (sub === 'help') {
    text = c.helpReply(c.resolveLevel());
  } else {
    text = c.unknownReply(sub);
  }
  return { decision: 'block', reason: text };
}

try {
  const input = c.readStdinJson();
  const out = route(input);
  if (out) reply(out);
} catch (e) {
  /* exit 0 regardless */
}
process.exitCode = 0;
