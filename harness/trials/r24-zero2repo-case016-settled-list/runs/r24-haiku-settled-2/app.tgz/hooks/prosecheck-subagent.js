#!/usr/bin/env node
'use strict';
// Subagent-start hook: returns the same writing contract inside the SubagentStart envelope (FP-04).
const c = require('./prosecheck-common.js');

try {
  c.readStdinJson();
  const level = c.resolveLevel();
  if (level !== 'off') {
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: {
        hookEventName: 'SubagentStart',
        additionalContext: c.contractText(level, 'live'),
      },
    }));
  }
} catch (e) {
  /* exit 0 regardless */
}
process.exitCode = 0;
