#!/usr/bin/env node
'use strict';
// Session-start hook: places the writing contract in context (FP-04). Always exits 0.
const fs = require('fs');
const c = require('./prosecheck-common.js');

function main() {
  c.readStdinJson();
  const firstStart = !fs.existsSync(c.flagPath());
  const level = c.resolveLevel();
  if (firstStart) {
    try { c.writeLevel(level); } catch (e) { /* host session must not fail */ }
  }
  c.pruneLedgers();
  if (level === 'off') return '';
  return c.sessionContext(level, firstStart);
}

try {
  const out = main();
  if (out) process.stdout.write(out);
} catch (e) {
  /* never fail the host session */
}
process.exitCode = 0;
