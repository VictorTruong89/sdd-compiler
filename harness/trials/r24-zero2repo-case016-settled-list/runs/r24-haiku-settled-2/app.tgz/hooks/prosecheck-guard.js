#!/usr/bin/env node
'use strict';
// Post-tool-use saved-file guard (FP-05). Scores just-saved prose files and nudges when flagged.
// Always exits 0; malformed input is treated as an empty object.
const fs = require('fs');
const path = require('path');
const c = require('./prosecheck-common.js');

const MAX_PATCH_PATHS = 16;
const LABEL_CAP = 5;
const ASK = 'Please fix the flagged spans in this file, keeping the rhythm variation.';

function patchPaths(ti) {
  const body = [ti.command, ti.input, ti.patch].find((s) => typeof s === 'string') || '';
  const out = [];
  for (const line of body.split(/\r?\n/)) {
    const m = /^\*\*\* (Add File|Update File|Move to): (.+)$/.exec(line);
    if (m) out.push(m[2].trim());
  }
  return out;
}

function targetPaths(tool, ti) {
  if (/apply_patch/i.test(tool)) return patchPaths(ti);
  const p = typeof ti.file_path === 'string' ? ti.file_path : (typeof ti.notebook_path === 'string' ? ti.notebook_path : '');
  return p ? [p] : [];
}

function isInside(child, parent) {
  const rel = path.relative(parent, child);
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}

function guard(input) {
  const level = c.resolveLevel();
  if (level === 'off' || level === 'lite') return null;
  const tool = typeof input.tool_name === 'string' ? input.tool_name : '';
  const ti = input.tool_input && typeof input.tool_input === 'object' ? input.tool_input : {};
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();
  const sid = typeof input.session_id === 'string' ? input.session_id : '';

  let raw = targetPaths(tool, ti).map((p) => p.trim()).filter(Boolean);
  const seen = new Set();
  raw = raw.filter((p) => (seen.has(p) ? false : (seen.add(p), true))).slice(0, MAX_PATCH_PATHS);

  const lines = [];
  const threshold = c.thresholdFor(level);
  for (const p of raw) {
    const full = path.isAbsolute(p) ? p : path.resolve(cwd, p);
    if (/(^|[\\/])(node_modules|\.git)([\\/]|$)/.test(full)) continue;
    if (isInside(full, c.pluginRoot())) continue;
    const base = path.basename(full);
    const lower = base.toLowerCase();
    const ext = path.extname(lower);
    const stem = ext ? lower.slice(0, -ext.length) : lower;
    if (c.INSTRUCTION_NAMES.includes(lower)) continue;
    if (!c.PROSE_EXTS.includes(ext) && c.INSTRUCTION_STEMS.includes(stem)) continue;
    const archive = c.ARCHIVE_EXTS.includes(ext);
    const plain = c.PLAIN_EXTS.includes(ext);
    const binary = c.BINARY_EXTS.includes(ext);
    if (!archive && !plain && !binary) continue;

    let st = null;
    try { st = fs.statSync(full); } catch (e) { st = null; }
    if (!st) {
      c.appendLedger(sid, { base, kind: 'failed', reason: 'cannot read this file' });
      continue;
    }
    if (!st.isFile()) continue;
    if (binary) {
      c.appendLedger(sid, { base, kind: 'binary' });
      continue;
    }
    const capKb = archive ? c.ARCHIVE_KB : c.PLAIN_KB;
    if (st.size > capKb * 1024) {
      c.appendLedger(sid, { base, kind: 'skip', limitKb: capKb });
      continue;
    }
    const res = c.runDetector([full], { timeout: archive ? c.TIMEOUT_ARCHIVE_MS : c.TIMEOUT_PLAIN_MS });
    const fail = (reason) => c.appendLedger(sid, { base, kind: 'failed', reason });
    if (res.kind === 'missing') { fail('Python cannot be found'); continue; }
    if (res.kind === 'timeout') { fail('the detector timed out'); continue; }
    if (res.kind === 'failed') {
      const why = c.lastErrorLine(res.stderr);
      fail(why ? 'detector error: ' + why : 'the detector produced no usable result');
      continue;
    }
    if (res.kind === 'empty') { fail('the detector produced no output'); continue; }
    if (res.kind === 'text') { fail('the detector output is not a structured report'); continue; }
    if (res.kind === 'noscore') { fail('the report has no numeric score'); continue; }

    const m = res.data._metrics;
    const labels = c.labelsOf(res.data).map((l) => l.label);
    const flagged = m.ai_tell_score > threshold;
    c.appendLedger(sid, {
      base,
      kind: 'scored',
      score: m.ai_tell_score,
      band: m.ai_tell_band,
      phrase: c.phraseOf(m.ai_tell_band),
      labels: labels.slice(0, LABEL_CAP),
      flagged,
      truncated: !!m.truncated,
    });
    if (flagged) {
      const coverage = m.truncated ? ', first ' + c.WINDOW_TEXT + ' characters only' : '';
      const shown = labels.slice(0, LABEL_CAP).join('; ') || 'none listed';
      lines.push('prosecheck: ' + base + ' ' + c.phraseOf(m.ai_tell_band) + ' (score ' + m.ai_tell_score +
        ', band ' + m.ai_tell_band + coverage + '). Flagged: ' + shown + '. ' + ASK);
    }
  }
  if (!lines.length) return null;
  return {
    hookSpecificOutput: {
      hookEventName: 'PostToolUse',
      additionalContext: lines.join('\n'),
    },
  };
}

try {
  const input = c.readStdinJson();
  const out = guard(input);
  if (out) process.stdout.write(JSON.stringify(out));
} catch (e) {
  /* exit 0 regardless */
}
process.exitCode = 0;
