#!/usr/bin/env node
'use strict';
// Prompt-submit hook: /prosecheck command router, stop phrases, and the ordinary-prompt reminder.
const core = require('./lib/core');
const router = require('./lib/router');

try {
  const input = core.readStdinJson();
  const out = router.route(input);
  if (out) process.stdout.write(out + '\n');
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
