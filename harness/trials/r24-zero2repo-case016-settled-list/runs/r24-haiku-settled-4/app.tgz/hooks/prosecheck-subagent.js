#!/usr/bin/env node
'use strict';
// Subagent-start hook: returns the same writing contract inside the subagent envelope.
const core = require('./lib/core');
const router = require('./lib/router');

try {
  core.readStdinJson();
  const level = core.effectiveLevel();
  if (level !== 'off') {
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: { hookEventName: 'SubagentStart', additionalContext: router.liveContract(level) },
    }) + '\n');
  }
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
