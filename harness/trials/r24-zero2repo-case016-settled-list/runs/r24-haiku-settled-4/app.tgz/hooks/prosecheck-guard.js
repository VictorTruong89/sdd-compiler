#!/usr/bin/env node
'use strict';
// Post-tool-use hook: scores just-saved prose files and nudges when flagged.
const core = require('./lib/core');
const { guard } = require('./lib/guard');

try {
  const input = core.readStdinJson();
  const out = guard(input);
  if (out) process.stdout.write(JSON.stringify(out) + '\n');
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
