#!/usr/bin/env node
'use strict';
// Stats hook: prints the session token figures and own-prose score as a block reply.
const core = require('./lib/core');
const cmd = require('./lib/commands');

try {
  const input = core.readStdinJson();
  process.stdout.write(cmd.block(cmd.statsReply(input.prompt, input.transcript_path, core.effectiveLevel())) + '\n');
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
