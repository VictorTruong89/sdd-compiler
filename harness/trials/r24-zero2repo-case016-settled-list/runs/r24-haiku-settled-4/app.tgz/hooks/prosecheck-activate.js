#!/usr/bin/env node
'use strict';
// Session-start hook: places the writing contract (and first-run welcome) in context.
const core = require('./lib/core');
const router = require('./lib/router');

try {
  core.readStdinJson();
  const out = router.sessionContext();
  if (out) process.stdout.write(out + '\n');
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
