#!/usr/bin/env python3
"""prosecheck detector: local AI-writing pattern scanner (Python standard library only)."""
import codecs
import io
import json
import math
import os
import re
import sys
import unicodedata
import xml.etree.ElementTree as ET
import zipfile
from collections import Counter
from html.parser import HTMLParser

WINDOW = 262144
PLAIN_CAP = 512 * 1024
ARCHIVE_CAP = 4 * 1024 * 1024

PLAIN_EXT = {'.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'}
ZIP_EXT = {'.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'}
NB_EXT = {'.ipynb'}

USAGE = """usage: detect.py [--clean] [--ci] [--] [FILE]

Score a prose file, or standard input, for AI-writing patterns.

  FILE        the file to scan; with no FILE, standard input is read
  --clean     print the scrubbed text instead of the JSON report
  --ci        add a low/high interval on the score (needs four or more sentences)
  --          end option parsing so that FILE may begin with a dash
  -h, --help  print this usage message and exit

Plain text (.md .mdx .markdown .txt .text .rst .tex .org .adoc), zip-based
documents (.docx .docm .pptx .pptm .xlsx .xlsm .odt .odp .ods .epub) and
.ipynb notebooks are extracted to prose first. Only the first 262,144
characters of extracted prose are scored.
"""


def fail(msg, code):
    sys.stderr.write(json.dumps({"error": msg}, ensure_ascii=False) + "\n")
    sys.exit(code)


# ---------------------------------------------------------------- extraction

def decode_bytes(b):
    if b.startswith(codecs.BOM_UTF8):
        return b[len(codecs.BOM_UTF8):].decode('utf-8', 'replace')
    if b.startswith(codecs.BOM_UTF16_LE) or b.startswith(codecs.BOM_UTF16_BE):
        return b.decode('utf-16', 'replace')
    return b.decode('utf-8', 'replace')


def _local(tag):
    return tag.rsplit('}', 1)[-1] if '}' in tag else tag


def _parse_xml(data):
    try:
        return ET.fromstring(data)
    except ET.ParseError:
        return None


def extract_docx(z):
    root = _parse_xml(z.read('word/document.xml'))
    if root is None:
        return ''
    paras = []
    for p in root.iter():
        if _local(p.tag) != 'p':
            continue
        parts = []
        for el in p.iter():
            ln = _local(el.tag)
            if ln == 't' and el.text:
                parts.append(el.text)
            elif ln == 'tab':
                parts.append('\t')
            elif ln in ('br', 'cr'):
                parts.append('\n')
        text = ''.join(parts)
        if text.strip():
            paras.append(text)
    return '\n'.join(paras)


def extract_pptx(z):
    slides = []
    for name in z.namelist():
        m = re.fullmatch(r'ppt/slides/slide(\d+)\.xml', name)
        if m:
            slides.append((int(m.group(1)), name))
    out = []
    for _, name in sorted(slides):
        root = _parse_xml(z.read(name))
        if root is None:
            continue
        paras = []
        for p in root.iter():
            if _local(p.tag) != 'p':
                continue
            text = ''.join(el.text or '' for el in p.iter() if _local(el.tag) == 't')
            if text.strip():
                paras.append(text)
        out.append('\n'.join(paras))
    return '\n'.join(out)


def extract_xlsx(z):
    shared = []
    if 'xl/sharedStrings.xml' in z.namelist():
        root = _parse_xml(z.read('xl/sharedStrings.xml'))
        if root is not None:
            for si in root.iter():
                if _local(si.tag) == 'si':
                    shared.append(''.join(el.text or '' for el in si.iter() if _local(el.tag) == 't'))
    sheets = []
    for name in z.namelist():
        m = re.fullmatch(r'xl/worksheets/sheet(\d+)\.xml', name)
        if m:
            sheets.append((int(m.group(1)), name))
    out = []
    for _, name in sorted(sheets):
        root = _parse_xml(z.read(name))
        if root is None:
            continue
        cells = []
        for c in root.iter():
            if _local(c.tag) != 'c':
                continue
            t = c.get('t')
            v = None
            isel = None
            for ch in c:
                if _local(ch.tag) == 'v':
                    v = ch.text or ''
                elif _local(ch.tag) == 'is':
                    isel = ''.join(el.text or '' for el in ch.iter() if _local(el.tag) == 't')
            if t == 's':
                if v is not None and v.strip().isdigit():
                    idx = int(v.strip())
                    if idx < len(shared):
                        cells.append(shared[idx])
            elif t == 'inlineStr':
                if isel:
                    cells.append(isel)
            elif t == 'str':
                if v:
                    cells.append(v)
        out.append('\n'.join(x for x in cells if x.strip()))
    return '\n'.join(x for x in out if x.strip())


ODF_NS_TEXT = 'urn:oasis:names:tc:opendocument:xmlns:text:1.0'


def _odf(el):
    ln = _local(el.tag)
    if ln == 's':
        try:
            n = int(el.get('{%s}c' % ODF_NS_TEXT, '1'))
        except ValueError:
            n = 1
        return ' ' * n
    if ln == 'tab':
        return '\t'
    if ln == 'line-break':
        return '\n'
    if ln in ('annotation', 'note', 'sequence-decls', 'tracked-changes', 'script', 'style'):
        return ''
    body = el.text or ''
    for ch in el:
        body += _odf(ch)
        body += ch.tail or ''
    if ln in ('p', 'h'):
        body += '\n'
    return body


def extract_odf(z):
    root = _parse_xml(z.read('content.xml'))
    if root is None:
        return ''
    body = None
    for el in root.iter():
        if _local(el.tag) == 'body':
            body = el
            break
    if body is None:
        return ''
    text = _odf(body)
    return '\n'.join(line for line in text.split('\n') if line.strip())


class _HTMLText(HTMLParser):
    SKIP = {'script', 'style', 'head', 'nav', 'svg', 'title'}
    BLOCK = {'p', 'div', 'br', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'tr', 'section',
             'article', 'blockquote', 'pre', 'ul', 'ol', 'table', 'header', 'footer', 'hr'}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.out = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        t = tag.lower()
        if t in self.SKIP:
            self.skip += 1
        if t in self.BLOCK:
            self.out.append('\n')

    def handle_endtag(self, tag):
        t = tag.lower()
        if t in self.SKIP and self.skip > 0:
            self.skip -= 1
        if t in self.BLOCK:
            self.out.append('\n')

    def handle_data(self, data):
        if not self.skip:
            self.out.append(data)


def extract_epub(z):
    chapters = []
    for name in sorted(z.namelist()):
        low = name.lower()
        base = os.path.basename(low)
        if not low.endswith(('.xhtml', '.html', '.htm')):
            continue
        if base.startswith('nav') or 'toc' in base:
            continue
        p = _HTMLText()
        try:
            p.feed(z.read(name).decode('utf-8', 'replace'))
            p.close()
        except Exception:
            continue
        lines = []
        for line in ''.join(p.out).split('\n'):
            line = re.sub(r'\s+', ' ', line).strip()
            if line:
                lines.append(line)
        if lines:
            chapters.append('\n'.join(lines))
    return '\n'.join(chapters)


def extract_ipynb(data):
    try:
        obj = json.loads(decode_bytes(data))
    except ValueError:
        return ''
    cells = obj.get('cells') if isinstance(obj, dict) else None
    if not isinstance(cells, list):
        return ''
    out = []
    for c in cells:
        if not isinstance(c, dict) or c.get('cell_type') != 'markdown':
            continue
        src = c.get('source', '')
        if isinstance(src, list) and all(isinstance(x, str) for x in src):
            src = ''.join(src)
        if not isinstance(src, str):
            return ''
        if src.strip():
            out.append(src)
    return '\n'.join(out)


def load_input(path):
    """Return (text, is_document)."""
    if path is None:
        return decode_bytes(sys.stdin.buffer.read()), False
    ext = os.path.splitext(path)[1].lower()
    try:
        with open(path, 'rb') as fh:
            data = fh.read()
    except OSError as exc:
        fail('cannot read input: %s (%s)' % (path, exc.strerror or 'unreadable'), 1)
    if ext in ZIP_EXT:
        try:
            z = zipfile.ZipFile(io.BytesIO(data))
        except zipfile.BadZipFile:
            fail('cannot read input: %s is not a readable zip archive' % path, 1)
        try:
            with z:
                if ext in ('.docx', '.docm'):
                    text = extract_docx(z)
                elif ext in ('.pptx', '.pptm'):
                    text = extract_pptx(z)
                elif ext in ('.xlsx', '.xlsm'):
                    text = extract_xlsx(z)
                elif ext == '.epub':
                    text = extract_epub(z)
                else:
                    text = extract_odf(z)
        except (KeyError, zipfile.BadZipFile, RuntimeError, ValueError):
            text = ''
        return text.strip(), True
    if ext in NB_EXT:
        return extract_ipynb(data).strip(), True
    if ext in ('.pdf', '.rtf'):
        return '', True
    return decode_bytes(data), False


# ------------------------------------------------------- character layer

def _rng(cp, ranges):
    for lo, hi in ranges:
        if lo <= cp <= hi:
            return True
    return False


CJK = [(0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xF900, 0xFAFF), (0x20000, 0x2FA1F),
       (0x3040, 0x30FF), (0x31F0, 0x31FF), (0xFF66, 0xFF9D)]
NOSPACE = CJK + [(0x0E00, 0x0E7F), (0x0E80, 0x0EFF), (0x1780, 0x17FF), (0x1000, 0x109F)]
JOINING = [(0x0590, 0x05FF), (0x0600, 0x06FF), (0x0750, 0x077F), (0x08A0, 0x08FF),
           (0xFB50, 0xFDFF), (0xFE70, 0xFEFF), (0x0900, 0x0DFF), (0x1000, 0x109F), (0x1780, 0x17FF)]
RTL = [(0x0590, 0x05FF), (0x0600, 0x06FF), (0x0750, 0x077F), (0x08A0, 0x08FF),
       (0xFB1D, 0xFDFF), (0xFE70, 0xFEFF)]
KHMER = [(0x1780, 0x17FF)]
MONGOL = [(0x1800, 0x18AF)]
BIDI = {0x200E, 0x200F, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E, 0x2066, 0x2067, 0x2068, 0x2069, 0x061C}

# Latin-looking letters of other scripts -> ASCII letter.
_LOOK_PAIRS = [
    (0x0430, 'a'), (0x0441, 'c'), (0x0501, 'd'), (0x0435, 'e'), (0x04BB, 'h'), (0x0456, 'i'),
    (0x0458, 'j'), (0x043E, 'o'), (0x0440, 'p'), (0x0455, 's'), (0x0445, 'x'), (0x0443, 'y'),
    (0x051D, 'w'), (0x0475, 'v'), (0x03BF, 'o'), (0x03BD, 'v'), (0x03C1, 'p'), (0x03B9, 'i'),
    (0x03C7, 'x'), (0x0585, 'o'), (0x0578, 'n'), (0x057D, 'u'), (0x0581, 'g'), (0x0570, 'h'),
    (0x0410, 'A'), (0x0412, 'B'), (0x0421, 'C'), (0x0415, 'E'), (0x041D, 'H'), (0x0406, 'I'),
    (0x0408, 'J'), (0x041A, 'K'), (0x041C, 'M'), (0x041E, 'O'), (0x0420, 'P'), (0x0405, 'S'),
    (0x0422, 'T'), (0x0425, 'X'), (0x04AE, 'Y'), (0x0391, 'A'), (0x0392, 'B'), (0x0395, 'E'),
    (0x0396, 'Z'), (0x0397, 'H'), (0x0399, 'I'), (0x039A, 'K'), (0x039C, 'M'), (0x039D, 'N'),
    (0x039F, 'O'), (0x03A1, 'P'), (0x03A4, 'T'), (0x03A5, 'Y'), (0x03A7, 'X'), (0x0550, 'A'),
    (0x054D, 'S'), (0x0555, 'O'),
]
LOOK = {chr(cp): ch for cp, ch in _LOOK_PAIRS}
ASCII_LETTERS = set('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ')


def _ch_in(c, s):
    return c != '' and c in s


def _is_symbolish(c):
    return c != '' and (unicodedata.category(c).startswith('S') or _rng(ord(c), [(0x1F000, 0x1FAFF), (0x2600, 0x27BF)]))


def _is_invisible(c, cp, cat):
    if cat in ('Cf', 'Cc'):
        return True
    if (0xFE00 <= cp <= 0xFE0F or 0xE0100 <= cp <= 0xE01EF or 0xE0000 <= cp <= 0xE007F
            or 0x2060 <= cp <= 0x2064 or cp in (0x180B, 0x180C, 0x180D, 0x180F, 0x034F, 0x115F,
                                              0x1160, 0x3164, 0xFFA0, 0x17B4, 0x17B5)):
        return True
    return False


def _kept_invisible(text, i, rtl):
    c = text[i]
    cp = ord(c)
    n = len(text)
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < n else ''
    if cp == 0x200B:
        return (bool(prev) and _rng(ord(prev), NOSPACE)) or (bool(nxt) and _rng(ord(nxt), NOSPACE))
    if cp == 0x00AD:
        return prev.isalpha() and nxt.isalpha()
    if cp in (0x200C, 0x200D):
        for x in (prev, nxt):
            if x and ((x.isalpha() and _rng(ord(x), JOINING)) or _is_symbolish(x)):
                return True
        return False
    if 0xFE00 <= cp <= 0xFE0F:
        return (_is_symbolish(prev) or (bool(prev) and _rng(ord(prev), CJK))) or nxt == '⃣'
    if 0xE0100 <= cp <= 0xE01EF:
        return bool(prev) and _rng(ord(prev), CJK)
    if 0xE0020 <= cp <= 0xE007F:
        return bool(prev) and (ord(prev) == 0x1F3F4 or 0xE0020 <= ord(prev) <= 0xE007F)
    if cp in BIDI:
        return rtl
    if 0x180B <= cp <= 0x180F and cp != 0x180E:
        return bool(prev) and _rng(ord(prev), MONGOL)
    if cp in (0x17B4, 0x17B5):
        return (bool(prev) and _rng(ord(prev), KHMER)) or (bool(nxt) and _rng(ord(nxt), KHMER))
    return False


def _nbsp_kept(text, i):
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    return (bool(prev) and prev.isdigit()) or (bool(nxt) and (nxt.isdigit() or nxt in ':;!?»›%€')) \
        or _ch_in(prev, '«‹')


def char_info(text):
    """Character-layer analysis of text (the window or the full text)."""
    rtl = any(_rng(ord(ch), RTL) for ch in text if ord(ch) > 0x0590)
    inv, ns, nl, fold, homo = [], [], [], {}, []
    hchars = 0
    for i, c in enumerate(text):
        cp = ord(c)
        if cp < 0x80:
            if (cp < 0x20 or cp == 0x7F) and c not in '\t\n\r':
                inv.append(i)
            continue
        if i == 0 and cp == 0xFEFF:
            continue
        cat = unicodedata.category(c)
        if cat == 'Zs':
            if cp in (0xA0, 0x202F) and _nbsp_kept(text, i):
                continue
            ns.append(i)
            continue
        if cat in ('Zl', 'Zp'):
            nl.append(i)
            continue
        if _is_invisible(c, cp, cat):
            if not _kept_invisible(text, i, rtl):
                inv.append(i)
    for m in re.finditer(r'\S+', text):
        tok = m.group(0)
        if tok.isascii():
            continue
        has_latin = any(ch in ASCII_LETTERS for ch in tok)
        has_look = any(ch in LOOK for ch in tok)
        other = any(ch.isalpha() and ord(ch) > 127 and ch not in LOOK for ch in tok)
        if has_latin and has_look and not other:
            homo.append((m.start(), m.end()))
            for j, ch in enumerate(tok):
                if ch in LOOK:
                    fold[m.start() + j] = LOOK[ch]
                    hchars += 1
    return {'inv': inv, 'ns': ns, 'nl': nl, 'fold': fold, 'homo': homo, 'homo_chars': hchars}


def scrub(text):
    info = char_info(text)
    inv, ns, nl, fold = set(info['inv']), set(info['ns']), set(info['nl']), info['fold']
    out = []
    for i, c in enumerate(text):
        if i in inv:
            continue
        if i in ns:
            out.append(' ')
        elif i in nl:
            out.append('\n')
        else:
            out.append(fold.get(i, c))
    s = ''.join(out)
    if s.startswith('﻿'):
        s = s[1:]
    final_lf = s.endswith('\n')
    lines = s.split('\n')
    res = []
    for line in lines:
        cr = ''
        body = line
        if body.endswith('\r'):
            body, cr = body[:-1], '\r'
        if body.strip(' \t') == '':
            res.append(cr)
            continue
        if body.endswith('  ') and not body.endswith('   ') and body.strip():
            res.append(body + cr)
        else:
            res.append(body.rstrip(' \t') + cr)
    # drop leading blank lines
    while res and res[0].strip(' \t\r') == '':
        res.pop(0)
    text2 = '\n'.join(res).rstrip()
    if final_lf and text2:
        text2 += '\n'
    return text2


# ------------------------------------------------------------ scan view

FENCE_OPEN = re.compile(r'^ {0,3}(`{3,}|~{3,})(.*)$')
FENCE_CLOSE = re.compile(r'^ {0,3}(`{3,}|~{3,})[ \t]*$')
QUOTE_LINE = re.compile(r'^ {0,3}>')
BADGE_PART = r'(?:\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)|!\[[^\]]*\]\([^)]*\))'
BADGE_LINE = re.compile(r'\s*(?:' + BADGE_PART + r')(?:\s*' + BADGE_PART + r')*\s*')
INLINE_CODE = re.compile(r'(``).+?\1|`[^`\n]+`')
WORD_RE = re.compile(r"[^\W_]+(?:['’\-][^\W_]+)*")
LIST_LINE = re.compile(r'^\s*(?:[-*+]|\d+[.)])\s+\S')
HEADING_LINE = re.compile(r'^ {0,3}#{1,6}[ \t]+\S', re.M)


def build_view(window):
    """Return (view, masked_lines). view has the same length as window; masked regions become spaces."""
    lines = window.split('\n')
    n = len(lines)
    masked = [False] * n
    if n and lines[0].strip() == '---':
        for j in range(1, n):
            if lines[j].strip() == '---':
                for k in range(j + 1):
                    masked[k] = True
                break
    i = 0
    while i < n:
        if masked[i]:
            i += 1
            continue
        m = FENCE_OPEN.match(lines[i])
        if m and not (m.group(1)[0] == '`' and '`' in m.group(2)):
            fence = m.group(1)
            j = i + 1
            while j < n:
                mc = FENCE_CLOSE.match(lines[j])
                if mc and mc.group(1)[0] == fence[0] and len(mc.group(1)) >= len(fence):
                    break
                j += 1
            end = min(j, n - 1)
            for k in range(i, end + 1):
                masked[k] = True
            i = end + 1
        else:
            i += 1
    i = 0
    while i < n:
        if not masked[i] and QUOTE_LINE.match(lines[i]):
            j = i
            while j < n and not masked[j] and QUOTE_LINE.match(lines[j]):
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    masked[k] = True
            i = j
        else:
            i += 1
    for k in range(n):
        if masked[k]:
            continue
        s = lines[k].strip()
        if s.startswith('|') and s.endswith('|') and s.count('|') >= 2:
            masked[k] = True
        elif s and BADGE_LINE.fullmatch(s):
            masked[k] = True
    out = []
    for k, line in enumerate(lines):
        if masked[k]:
            out.append(' ' * len(line))
        else:
            out.append(INLINE_CODE.sub(lambda m: ' ' * len(m.group(0)), line))
    return '\n'.join(out), masked


def inf(w):
    alts = {w, w + 's', w + 'es', w + 'd', w + 'ed', w + 'ing'}
    if w.endswith('e'):
        alts.add(w[:-1] + 'ing')
    if w.endswith('y'):
        alts |= {w[:-1] + 'ies', w[:-1] + 'ied'}
    return '(?:' + '|'.join(re.escape(a) for a in sorted(alts, key=len, reverse=True)) + ')'


def W(p):
    return r'(?<![A-Za-z0-9])(?:' + p + r')(?![A-Za-z0-9])'


def RX(*pats):
    return [re.compile(p, re.I) for p in pats]


# Each family: dict(num, slug, label, weight, decisive, advice, min_hits, kind, payload)
FAMS = []


def fam(num, slug, label, weight, kind, payload, decisive=False, advice=False, min_hits=1):
    FAMS.append(dict(num=num, slug=slug, label=label, weight=weight, kind=kind, payload=payload,
                     decisive=decisive, advice=advice, min_hits=min_hits))


AI_VOCAB_WORDS = ['additionally', 'crucial', 'delve', 'tapestry', 'pivotal', 'vibrant', 'meticulous',
                  'testament', 'underscore', 'intricate', 'intricacies', 'interplay', 'garner', 'bolster',
                  'foster', 'showcase', 'emphasize', 'enduring', 'enhance', 'leverage', 'utilize',
                  'facilitate', 'encompass', 'harness', 'holistic', 'paradigm', 'transformative',
                  'unprecedented', 'myriad', 'plethora', 'robust', 'seamless', 'navigate', 'embark',
                  'craft', 'landscape', 'journey', 'realm', 'multifaceted', 'elevate', 'empower', 'unlock']
fam(1, 'ai_vocabulary', 'AI vocabulary', 12, 'rx', RX(
    W('|'.join(inf(w) for w in AI_VOCAB_WORDS)),
    W(inf('align') + r'\s+with'),
    W(r'capture\s+the\s+(?:essence|spirit|imagination|heart|magic)')))

fam(2, 'model_dialect', 'model-dialect vocabulary', 10, 'rx', RX(
    W('genuinely|fascinating|nuanced|thoughtfully|refreshingly|strikingly|compellingly'),
    W(r'quietly\s+(?:powerful|profound|radical)'),
    W(r'deeply\s+(?:human|personal|felt|unsettling)'),
    W(r'resonates?\s+deeply'),
    W(r'game[- ]chang(?:er|ers|ing)'),
    W(inf('supercharge') + '|' + inf('skyrocket') + '|' + inf('turbocharge') + '|' + inf('revolutionize')),
    W(r'double\s+down\s+on'),
    W(r'dive\s+deep(?:er)?\s+into'),
    W(r'unlock\s+(?:the\s+)?(?:power|potential|value)'),
    W(r'take\b[^.!?\n]{0,60}?\bto\s+the\s+next\s+level')), min_hits=2)

fam(3, 'promotional', 'promotional language', 10, 'fn', None)  # filled below

fam(4, 'hyphen_pairs', 'hyphenated cliché pairs', 0, 'rx', RX(
    W(r'high-quality|cutting-edge|state-of-the-art|results-driven|results-oriented|data-driven'
      r'|best-in-class|user-friendly|game-changing|fast-paced|detail-oriented|forward-thinking'
      r'|end-to-end|value-driven|customer-centric')), advice=True)

fam(5, 'simple_yet', "'simple yet' cliché", 8, 'rx', RX(
    W(r'simple\s+yet\s+(?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)')))

fam(6, 'adjective_chain', 'stacked adjective chain', 8, 'fn', None)

fam(8, 'synonym_cycling', 'synonym cycling', 8, 'fn', None)

fam(10, 'significance', 'significance inflation', 10, 'rx', RX(
    W(r'(?:stands?|serves?|stood|served)\s+as\s+(?:an?\s+|the\s+)?(?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)'),
    W(r'(?:underscor(?:es?|ing)|highlight(?:s|ed|ing)?)\s+(?:its|the|their|his|her)\s+(?:importance|significance|enduring|central|vital|crucial|pivotal|key)'),
    W(r'reflects?\s+a\s+broader\s+(?:trend|shift|pattern)'),
    W(r'marks?\s+a\s+(?:turning\s+point|milestone|watershed|new\s+chapter|new\s+era)'),
    W(r'symboli[sz](?:e|es|ed|ing)'),
    W(r'sets?\s+the\s+stage\s+for'),
    W(r'left\s+an\s+indelible\s+mark'),
    W(r'plays?\s+a\s+(?:crucial|pivotal|vital|key|central|significant)\s+role'),
    W(r'(?:has|have)\s+(?:shaped|sparked)'),
    W(r'(?:has|have)\s+come\s+to\s+(?:define|symbolize)')))

fam(11, 'notability', 'notability name-dropping', 8, 'rx', RX(
    W(r'(?:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?:in|by)\s+(?-i:[A-Z])[^.!?\n]{0,60}?(?:,|\s+and)\s+(?-i:[A-Z])'),
    W(r'\d[\d,.]*\s*[KkMm]?\s+(?:followers|subscribers)'),
    W(r'strong\s+(?:online|digital|social[- ]media)\s+presence'),
    W(r'active\s+(?:online|digital|social[- ]media)\s+presence'),
    W(r'widely\s+covered'),
    W(r'independent\s+coverage')))

fam(12, 'vague_attribution', 'vague attribution', 10, 'rx', RX(
    W(r'experts\s+(?:argue|believe|say|claim|note|suggest)'),
    W(r'industry\s+(?:reports|observers|analysts)'),
    W(r'observers\s+have\s+(?:cited|noted)'),
    W(r'some\s+critics\s+argue'),
    W(r'researchers\s+have\s+found'),
    W(r'studies\s+suggest'),
    W(r'it\s+is\s+widely\s+believed')))

fam(13, 'title_as_noun', 'article title used as a proper noun', 14, 'rx', RX(
    W(r'(?-i:The)\s+(?-i:List|Index|Compilation|Collection|Catalogue|Guide|Overview)\s+of\s+(?-i:[A-Z])[^.!?\n]{0,80}?\s+is\s+(?:a|an|the)')),
    decisive=True)

fam(14, 'ecosystem_padding', 'conservation or ecosystem padding', 8, 'rx', RX(
    W(r'plays?\s+a\s+(?:vital|crucial|key|significant)\s+role\s+in\s+(?:its|the)\s+ecosystem'),
    W(r'conservation\s+efforts\s+(?:are|is)\s+(?:underway|ongoing|in\s+place)'),
    W(r'serves?\s+as\s+an?\s+indicator\s+species'),
    W(r'contributes?\s+to\s+biodiversity')))

fam(15, 'false_range', 'false range', 8, 'rx', RX(
    W(r'from\s+(?:the\s+)?(?:dawn|birth|earliest\s+days|inception|advent|emergence|humble)\b[^.!?\n]*?\bto\s+(?:the\s+)?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b'),
    W(r'from\s+(?:the\s+)?humble\b[^.!?\n]*?\bto\s+(?:the\s+)?(?:mighty|towering|grand|sprawling)\b')))

fam(16, 'ing_tail', 'superficial -ing tail clause', 10, 'rx', RX(
    r',\s+(?:highlighting|reflecting|symbolizing|symbolising|emphasizing|underscoring|showcasing|fostering|cultivating|encompassing|signaling|demonstrating|illustrating|representing|suggesting|indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b'))

fam(17, 'tailing_negation', 'tailing negation', 8, 'rx', RX(
    r'[^,.!?\n]{3,},\s*no\s+(?:guessing|waste|wasted\s+motion|hassle|fluff|stress|jargon)\b'))

fam(17, 'negative_parallelism', 'negative parallelism', 0, 'rx', RX(
    W(r'it[’\']s\s+not\s+(?:just|merely)\s+(?:about|a|an)'),
    W(r'not\s+only[^.!?\n]{0,40}?\bbut\b'),
    W(r'doesn[’\']t\s+just[^,.\n]{0,40}?\bit\b')), advice=True)

fam(18, 'not_x_just_y', "'Not X, just Y' contrast", 10, 'rx', RX(
    r'(?<![A-Za-z])(?:no|not)\s+[A-Za-z\'’-]+,\s+(?:just|only|simply)\s+[A-Za-z\'’-]+',
    r'(?<![A-Za-z])(?:not|isn[’\']t|aren[’\']t|wasn[’\']t|weren[’\']t)\s+(?:just|merely)\s+(?:a|an|the)\s+[A-Za-z\'’-]+(?:,|\s+—|\s+–|\s+-|—|–)\s*(?:it[’\']s|it\s+is|it\s+was|they[’\']re|they\s+are|they\s+were|that[’\']s|but)\b'))

fam(19, 'filler', 'filler phrase', 0, 'rx', RX(
    W(r'in\s+order\s+to|due\s+to\s+the\s+fact\s+that|at\s+this\s+point\s+in\s+time|in\s+the\s+event\s+that'
      r'|has\s+the\s+ability\s+to|it\s+is\s+important\s+to\s+note\s+that|it\s+should\s+be\s+mentioned\s+that'
      r'|needless\s+to\s+say')), advice=True)

fam(20, 'empty_pivot', 'empty pivot phrase', 8, 'rx', RX(
    W(r"it[’']s\s+worth\s+(?:noting|mentioning)\s+that|it\s+bears\s+(?:noting|mentioning)\s+that"
      r"|one\s+thing\s+to\s+(?:consider|keep\s+in\s+mind)\s+is|it\s+is\s+interesting\s+to\s+note\s+that"
      r"|a\s+key\s+consideration\s+is|a\s+point\s+to\s+highlight\s+is")))

fam(21, 'outcome_tail', 'outcome-speculation tail', 8, 'rx', RX(
    r',\s+(?:raising\s+questions\s+about|prompting\s+reflection\s+on|sparking\s+debate\s+about'
    r'|with\s+broader\s+implications\s+for|reshaping\s+our\s+understanding\s+of|paving\s+the\s+way\s+for'
    r'|signaling\s+a\s+shift\s+toward)'))

fam(22, 'authority_trope', 'persuasive authority trope', 0, 'rx', RX(
    W(r"here[’']s\s+the\s+thing|make\s+no\s+mistake|the\s+truth\s+is|let[’']s\s+be\s+honest|the\s+simple\s+fact\s+is"
      r"|at\s+its\s+core|what\s+really\s+matters|more\s+than\s+anything|at\s+the\s+end\s+of\s+the\s+day"
      r"|the\s+bottom\s+line\s+is|in\s+reality|fundamentally,|the\s+real\s+question\s+is|the\s+heart\s+of\s+the\s+matter"
      r"|the\s+deeper\s+issue|when\s+you\s+get\s+down\s+to\s+it|when\s+all\s+is\s+said\s+and\s+done")), advice=True)

fam(23, 'interjection', 'editorial interjection', 8, 'rx', RX(
    W(r"it(?:[’']s|\s+is)\s+important\s+to\s+(?:remember|note|understand|recognize)|one\s+must\s+note\s+that"
      r"|it\s+is\s+worth\s+pointing\s+out|it\s+cannot\s+be\s+overstated\s+that|it\s+must\s+be\s+emphasized\s+that")))

fam(24, 'self_thorough', 'self-thoroughness phrase', 8, 'rx', RX(
    W(r'this\s+comprehensive\s+(?:guide|overview|analysis)|this\s+in-depth\s+(?:analysis|look|examination)'
      r'|this\s+complete\s+(?:guide|overview)|a\s+thorough\s+examination\s+of|everything\s+you\s+need\s+to\s+know\s+about')))

fam(25, 'qa_rhetorical', 'rhetorical question with one-word answer', 8, 'rx', RX(
    r'(?<![A-Za-z])(?:Is|Are|Was|Were|Do|Does|Did|Can|Could|Will|Would|Should|Has|Have|Had|May|Might|Must|Shall)\s[^.!?\n]{0,60}\?\s+(?:Yes|No|Absolutely|Never|Maybe|Probably|Always)[.!]'))

fam(26, 'concrete_evidence', "'concrete evidence' defence phrase", 8, 'rx', RX(
    W(r'without\s+concrete\s+(?:evidence|proof)|do\s+you\s+have\s+concrete\s+(?:evidence|proof)'
      r'|I\s+(?:would\s+)?need\s+concrete\s+(?:evidence|examples)\s+to|absent\s+concrete\s+proof'
      r'|provide\s+concrete\s+evidence')))

fam(27, 'intro_hook', 'compulsive intro hook', 8, 'rx', RX(
    W(r"in\s+today[’']s(?:\s+[\w-]+){0,2}\s+(?:world|landscape|environment|market)|in\s+a\s+world\s+where"
      r"|in\s+an\s+era\s+of|more\s+than\s+ever\s+before|we\s+live\s+in\s+a\s+(?:time|world)\s+when"
      r"|in\s+an\s+increasingly\s+(?:interconnected|digital|competitive|complex)\s+world"),
    r'in\s+recent\s+years,',
    r'\b(?:great|exciting|big)\s+news\s*[!:]',
    r'\bever\s+(?:wanted|wondered|dreamed|wished)\b[^.?\n]*\?'))

fam(30, 'diff_anchored', 'diff-anchored writing', 8, 'rx', RX(
    W(r'unlike\s+the\s+(?:previous|prior|old|earlier)\s+(?:version|release|implementation|approach)'),
    W(r'(?:the|this)\s+(?:latest\s+|new\s+)?(?:update|release|version|change|patch|design)\s+(?:adds|introduces|brings|delivers|includes|provides|improves)'),
    W(r'(?:has|have)\s+been\s+(?:updated|refactored|improved|enhanced|changed)\s+to'),
    r'\bpreviously\b[^.!?\n]*\bnow\b',
    W(r"(?:wasn[’']t|weren[’']t)\s+there\s+before"),
    W(r"we(?:[’']ve|\s+have)\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)")))

fam(31, 'signposting', 'signposting or announcement', 8, 'rx', RX(
    W(r"let[’']s\s+(?:dive|delve|explore)|let[’']s\s+break\s+(?:this|it)\s+down|here[’']s\s+what\s+you\s+need\s+to\s+know"
      r"|without\s+further\s+ado|now\s+let[’']s\s+look\s+at|buckle\s+up|stay\s+with\s+me"
      r"|(?:are\s+you\s+)?ready\s+to\s+dive\s+in")))

fam(32, 'cataloguing', 'cataloguing lead-in', 8, 'rx', RX(
    W(r'(?:used|uses|employs?|employed|relied\s+on|utilizes?)\s+(?:several|various|a\s+number\s+of|multiple|different|many|numerous)\s+[A-Za-z-]+'),
    r'(?-i:\bThese)\s+(?:[A-Za-z-]+\s+)?(?:provide|offer|give|reveal|show|allow|enable|help)\s+(?:information|insight|understanding|details|data)\b',
    W(r'(?:is|are|was|were|remains|becomes)\s+(?:the\s+|a\s+)?(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective\s+tissue)\s+of')))

fam(33, 'inline_header', 'inline-header vertical list', 8, 'rx', [re.compile(
    r'^[ \t]*(?:(?:[-*+]|\d+[.)])[ \t]+)?\*\*[^*\n]{1,80}?:\*\*|^[ \t]*(?:(?:[-*+]|\d+[.)])[ \t]+)?\*\*[^*\n]{1,80}?\*\*:',
    re.M)])

fam(36, 'formulaic_challenges', 'formulaic challenges section', 8, 'rx', RX(
    W(r'despite\s+(?:these|its|the)\s+(?:challenges|obstacles)|challenges\s+and\s+(?:future\s+)?(?:prospects|outlook|legacy)'
      r'|continues\s+to\s+thrive|typical\s+of\s+(?:emerging|urban|modern)|faces\s+(?:several|many|numerous)\s+challenges')))

fam(38, 'compulsive_conclusion', 'compulsive conclusion opener', 8, 'rx', [re.compile(
    r'^[ \t]*(?:[-*>][ \t]+)?(?:in\s+conclusion|overall|in\s+summary|to\s+summarize|to\s+conclude|all\s+in\s+all|in\s+essence|ultimately)\b',
    re.I | re.M)])

fam(39, 'generic_positive_ending', 'generic positive conclusion', 8, 'rx', RX(
    W(r'the\s+future\s+looks\s+bright|exciting\s+times\s+lie\s+ahead|journey\s+toward\s+excellence'
      r'|step\s+in\s+the\s+right\s+direction|(?:the\s+)?(?:outlook|future)\s+(?:for\s+[\w\s]{1,40}?\s+)?(?:is|looks|remains)\s+bright'
      r'|well[- ]positioned\s+(?:for\s+)?(?:whatever\s+comes\s+next|the\s+future|the\s+road\s+ahead)')))

fam(47, 'chatbot_artifact', 'chatbot artifact', 14, 'rx', RX(
    W(r'I\s+hope\s+this\s+helps|Certainly!|Of\s+course!|let\s+me\s+know\s+if\s+you|would\s+you\s+like\s+me\s+to'
      r'|feel\s+free\s+to\s+(?:ask|reach\s+out)'),
    r'\bhappy\s+to\s+help(?=[.!]|\s*\n|\s*$)',
    W(r'(?:here|below)\s+is\s+(?:an?|the)\s+(?:overview|summary|rundown|recap|brief)'),
    W(r"here\s+(?:are|[’']s)\s+(?:a\s+few|some|two|three)\s+(?:options|drafts|versions|variations)"),
    W(r"here\s+(?:is|[’']s)\s+a\s+draft"),
    W(r'depending\s+on\s+the\s+(?:vibe|tone|style)'),
    W(r'I\s+hope\s+(?:this\s+email\s+)?finds\s+you\s+well'),
    W(r'as\s+an?\s+(?:AI\s+assistant|AI\s+language\s+model|large\s+language\s+model|language\s+model|AI|LLM)'),
    W(r'to\s+(?:answer|address)\s+your\s+question|in\s+(?:response|answer)\s+to\s+your\s+question'
      r'|your\s+question\s+(?:about|regarding|concerning)|as\s+(?:you\s+)?(?:requested|asked),?\s+here'
      r'|here\s+is\s+(?:the\s+)?(?:draft|first\s+pass|revised\s+version)\s+(?:of|for\s+your)')),
    decisive=True)

fam(48, 'sycophancy', 'sycophantic tone', 14, 'rx', RX(
    W(r"you[’']?re\s+absolutely\s+right|you\s+are\s+absolutely\s+right"),
    W(r'(?:great|excellent|wonderful|fantastic|good|thoughtful|brilliant)\s+question\s*[!.,]'),
    W(r"that[’']s\s+(?:a|an)\s+(?:great|wonderful|fantastic|brilliant|excellent)\s+(?:point|question)"),
    W(r'what\s+a\s+(?:thoughtful|great|wonderful|fantastic)\s+question')), decisive=True)

fam(50, 'cutoff_disclaimer', 'knowledge-cutoff disclaimer', 14, 'rx', RX(
    W(r'as\s+of\s+my\s+(?:last\s+)?(?:training|knowledge)|up\s+to\s+my\s+(?:last\s+)?(?:training|knowledge)'
      r'|as\s+of\s+my\s+(?:knowledge\s+)?cutoff'),
    W(r'while\s+specific\s+details\s+are\s+(?:limited|scarce|not\s+(?:extensively\s+|widely\s+)?documented)'),
    W(r'based\s+on\s+(?:the\s+)?available\s+information'),
    W(r'maintains\s+a\s+low\s+profile|keeps?\s+(?:his|her|their)\s+personal\s+life\s+private')), decisive=True)

fam(51, 'copula_avoidance', 'copula avoidance', 6, 'rx', RX(
    W(r'(?:serves?|stands?|functions?|acts?)\s+as'),
    W(r'represents?\s+(?:an?|the)'),
    W(r'marks?\s+(?:an?|the)'),
    W(r'boasts'),
    W(r'features\s+(?:an?|the|\d[\d,.]*|several|many|some|numerous|various|multiple|dozens|hundreds|thousands)'),
    W(r'offers\s+an?'),
    W(r'refers\s+to')))

fam(54, 'hedge_stacking', 'hedge stacking', 0, 'fn', None, advice=True)
fam(55, 'contraction_absence', 'contraction absence', 0, 'fn', None, advice=True)
fam(56, 'boldface', 'boldface overuse', 6, 'rx', [re.compile(r'\*\*[^*\n]+?\*\*')], min_hits=2)
fam(57, 'emoji', 'emoji', 8, 'rx', [re.compile(
    '[\U0001F300-\U0001FAFF\U0001F000-\U0001F2FF\U0001F900-\U0001F9FF\U0001F1E6-\U0001F1FF\u2600-\u27BF]')])
fam(58, 'em_dash', 'em-dash overuse', 0, 'fn', None, advice=True)
fam(59, 'title_case', 'title case in heading', 6, 'fn', None)
fam(60, 'curly_quotes', 'curly quotation marks', 0, 'rx', [re.compile('[“”‘’]')], advice=True)
fam(61, 'year_range', 'hyphen used for en dash in year range', 0, 'fn', None, advice=True)
fam(62, 'invisible', 'invisible or zero-width characters', 14, 'fn', None, decisive=True)
fam(63, 'placeholder', 'placeholder text', 14, 'rx', RX(
    r'\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\](?![\(\[])',
    r'\[(?:name|company|client|place|source|person|organization|org|address)\b[^\]\n]*\](?![\(\[])',
    r'\{\{[^}\n]*\}\}',
    r'(?<![A-Za-z0-9])x{3,}(?![A-Za-z0-9])',
    r'\blorem\s+ipsum\b') + [re.compile(r'\[[A-Z][A-Z _\-]{2,}\](?![\(\[])')], decisive=True)
fam(64, 'reference_markup', 'chat reference markup', 14, 'rx', RX(
    r'\bcite(?:turn|start|nav)\w*', r'\boai_citation\w*', r'contentReference', r'navlist',
    r'【\d+†[^】\n]*】'), decisive=True)
fam(65, 'ai_tracking', 'AI tracking parameter', 14, 'fn', None, decisive=True)
fam(66, 'homoglyph', 'mixed-script homoglyphs', 14, 'fn', None, decisive=True)
fam(67, 'nonstandard_space', 'non-standard spaces', 8, 'fn', None)
fam(68, 'trailing_whitespace', 'trailing or stray whitespace', 0, 'fn', None, advice=True)
fam(69, 'marketing_slop', 'canonical marketing-slop phrase', 10, 'rx', RX(
    r"unlock(?:ing)?\s+(?:your\s+|the\s+)?full\s+potential|navigat(?:e|ing)\s+the\s+complexit(?:y|ies)"
    r"|a\s+testament\s+to\s+the\s+(?:power|importance)\s+of|staying\s+ahead\s+of\s+the\s+curve"
    r"|turning\s+challenges\s+into\s+opportunities|taking\s+\w+(?:\s+\w+)?\s+to\s+the\s+next\s+level"
    r"|harness(?:ing)?\s+the\s+power\s+of|paving\s+the\s+way\s+for|saying\s+goodbye\s+to"
    r"|imagin(?:e|ing)\s+a\s+world\s+where|unleash(?:ing)?\s+the\s+power"))
fam(70, 'hr_rules', 'decorative horizontal rules', 6, 'fn', None)
fam(71, 'degenerate_repetition', 'degenerate repetition', 10, 'fn', None)
fam(40, 'monotony', 'sentence-length monotony', 6, 'fn', None)
fam(41, 'alternation', 'mechanical sentence-length alternation', 0, 'fn', None, advice=True)
fam(42, 'opener_repetition', 'opener repetition', 0, 'fn', None, advice=True)
fam(44, 'uniform_paragraphs', 'uniform paragraph length', 6, 'fn', None)
fam(46, 'semicolon_underuse', 'semicolon and parenthesis underuse', 0, 'fn', None, advice=True)


# ------------------------------------------------------ function families

PROMO_RX = RX(
    W(r'nestled|breathtaking|must-visit|stunning|picturesque|charming|idyllic|vibrant\s+community'
      r'|rich\s+cultural\s+heritage|in\s+the\s+heart\s+of|world-class|top-tier|unparalleled|premier|leading'
      r'|esteemed\s+organization|valuable\s+asset|passion\s+for\s+excellence|proven\s+track\s+record'
      r'|results-oriented|wealth\s+of\s+experience|dynamic\s+team|fast-paced\s+environment'
      r'|deeply\s+passionate|perfectly\s+situated|(?:close|tight)-knit\s+team|uniquely\s+positioned\s+to'),
    r"\bI(?:\s+am|'m|’m)\s+excited\s+to\s+(?:apply|bring)\b")
MARKETING_VERBS = {'install', 'join', 'grab', 'download', 'try', 'discover', 'experience', 'escape',
                   'transform', 'reclaim', 'unlock', 'elevate', 'boost', 'say', 'imagine', 'explore',
                   'meet', 'introducing', 'upgrade', 'claim', 'unleash', 'supercharge', 'level', 'stop', 'start'}
HEDGE_RE = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|somewhat|relatively"
                      r"|fairly|seems?\s+(?:to|like)|appears?\s+to|kind\s+of|sort\s+of)\b")
SYN_CLUSTERS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]
SYN_RX = [[(mem, re.compile(r'(?<![A-Za-z])' + mem.replace(' ', r'\s+') + r'(?:s|es)?(?![A-Za-z])', re.I))
           for mem in cl] for cl in SYN_CLUSTERS]
ITEM = r"[A-Za-z][A-Za-z'\-]*"
CHAIN_SEP = r"\s*,\s*(?:and\s+)?|\s+and\s+"
CHAIN_RX = re.compile(r'\b' + ITEM + r'(?:' + CHAIN_SEP + ITEM + r'){3,}\b')
CHAIN_SPLIT = re.compile(CHAIN_SEP)
STOCK_ADJ = {'powerful', 'elegant', 'robust', 'seamless', 'innovative', 'intuitive', 'scalable', 'reliable',
             'efficient', 'comprehensive', 'modern', 'vibrant', 'dynamic', 'cutting-edge', 'secure', 'fast',
             'simple', 'clear', 'smart', 'flexible', 'versatile', 'premium', 'strong'}
ADJ_SUFFIX = ('ive', 'ous', 'able', 'ible', 'ic', 'ical', 'ant', 'ent', 'ful', 'less', 'al', 'ial', 'ary', 'ory', 'ish')
TRANSITIONS = {'Additionally', 'Furthermore', 'Moreover', 'However', 'Nevertheless', 'Consequently',
               'Subsequently', 'Notably'}
MINOR_WORDS = {'a', 'an', 'the', 'of', 'in', 'on', 'at', 'to', 'for', 'by', 'with', 'from', 'up', 'as',
               'into', 'and', 'or', 'but', 'nor', 'so', 'yet', 'via', 'vs', 'per', 'over', 'off'}
AI_TLD_HOSTS = {'chatgpt.com', 'chat.openai.com', 'perplexity.ai', 'claude.ai', 'gemini.google.com',
                'copilot.microsoft.com', 'poe.com'}
PARA_RX = re.compile(r'\S(?:[^\n]|\n(?!\s*\n))*')
SENT_RX = re.compile(r'[^.!?]+(?:[.!?]+|\Z)')


class Ctx(object):
    def __init__(self, window, view, masked, charinfo):
        self.window = window
        self.view = view
        self.masked = masked
        self.char = charinfo
        self.sents = []
        for m in SENT_RX.finditer(view):
            if m.group(0).strip() and not m.group(0).lstrip().startswith('#'):
                self.sents.append((m.start(), m.end()))
        self.paras = []
        for m in PARA_RX.finditer(view):
            t = m.group(0)
            if not HEADING_LINE.search(t):
                self.paras.append((m.start(), m.end()))
        self.words = [(m.start(), m.end(), m.group(0).lower()) for m in WORD_RE.finditer(view)]

    def wc(self):
        return len(self.words)

    def sent_wc(self):
        out = []
        for s, e in self.sents:
            n = len(WORD_RE.findall(self.view[s:e]))
            if n:
                out.append((s, e, n))
        return out


def _cv(vals):
    mean = sum(vals) / float(len(vals))
    if mean == 0:
        return None
    var = sum((v - mean) ** 2 for v in vals) / float(len(vals))
    return math.sqrt(var) / mean


def f_promotional(c):
    spans = spans_of(PROMO_RX, c.view)
    starts = []
    for s, e in c.sents:
        m = re.match(r'\W*([A-Za-z]+)', c.view[s:e])
        if m and m.group(1).lower() in MARKETING_VERBS:
            starts.append((s, e))
    if len(starts) >= 3:
        spans += starts
    return spans


def f_chains(c):
    out = []
    for m in CHAIN_RX.finditer(c.view):
        items = [x.strip().lower() for x in CHAIN_SPLIT.split(m.group(0)) if x.strip()]
        if any(x in STOCK_ADJ or x.endswith(ADJ_SUFFIX) for x in items):
            out.append((m.start(), m.end()))
    return out


def f_synonyms(c):
    spans = []
    for cluster in SYN_RX:
        found, cs = set(), []
        for mem, rx in cluster:
            for m in rx.finditer(c.view):
                found.add(mem)
                cs.append((m.start(), m.end()))
        if len(found) >= 3:
            spans += cs
    return spans


def f_title_case(c):
    out = []
    for m in re.finditer(r'^[ \t]{0,3}#{1,6}[ \t]+(.+?)[ \t]*#*[ \t]*$', c.view, re.M):
        text = m.group(1).strip()
        toks = text.split()
        if len(toks) < 3 or not text[:1].isalpha() or text == text.upper():
            continue
        major = [t for t in toks if t.lower().strip(':,.!?') not in MINOR_WORDS]
        if len(major) >= 2 and all(t[0].isupper() for t in major if t[0].isalpha()) \
                and all(t[0].isalpha() for t in major):
            out.append((m.start(1), m.end(1)))
    return out


def f_hedges(c):
    out = []
    for s, e in c.sents:
        if len(HEDGE_RE.findall(c.view[s:e])) >= 2:
            out.append((s, e))
    return out


def f_contractions(c):
    text = c.view
    words = len(c.words)
    fp = len(re.findall(r'\b(?:I|me|my|we|our|us)\b', text))
    if fp < 3 or words == 0 or fp / float(words) < 0.02:
        return []
    expanded = len(re.findall(r'(?i)\b(?:do not|does not|did not|is not|are not|was not|were not|cannot|will not'
                              r'|would not|could not|should not|have not|has not|I am|I will|I have|it is'
                              r'|that is|we are|we have|you are|they are|let us)\b', text))
    contracted = len(re.findall(r"(?i)\b\w+n[’']t\b|\bI[’'](?:m|ll|ve|d)\b|\b(?:it|that|we|you|they)[’'](?:s|re|ve)\b", text))
    if expanded >= 3 and expanded >= 0.8 * (expanded + contracted):
        return [(0, len(text))]
    return []


def f_alternation(c):
    sw = c.sent_wc()
    L = [n for _, _, n in sw]
    if len(L) < 6:
        return []
    big = [False] + [abs(L[k] - L[k - 1]) >= 5 for k in range(1, len(L))]
    sign = [0] + [(L[k] > L[k - 1]) - (L[k] < L[k - 1]) for k in range(1, len(L))]
    alt = [False] * len(L)
    for k in range(2, len(L)):
        alt[k] = big[k] and big[k - 1] and sign[k] != 0 and sign[k] == -sign[k - 1]
    out = []
    k = 0
    while k < len(L):
        if alt[k]:
            a = k
            while k < len(L) and alt[k]:
                k += 1
            b = k - 1
            if (b - a + 2) >= 6:
                out.append((sw[a - 1][0], sw[b][1]))
        else:
            k += 1
    return out


def f_monotony(c):
    sw = c.sent_wc()
    if len(sw) < 3:
        return []
    cv = _cv([n for _, _, n in sw])
    if cv is not None and cv < 0.35:
        return [(sw[0][0], sw[-1][1])]
    return []


def f_uniform_paragraphs(c):
    pw = []
    for s, e in c.paras:
        n = len(WORD_RE.findall(c.view[s:e]))
        if n:
            pw.append((s, e, n))
    if len(pw) < 4:
        return []
    cv = _cv([n for _, _, n in pw])
    if cv is not None and cv < 0.4:
        return [(s, e) for s, e, _ in pw]
    return []


def f_openers(c):
    out = []
    for s, e in c.paras:
        text = c.view[s:e]
        sents = re.findall(r'[^.!?]+[.!?]+', text)
        if len(sents) < 3:
            continue
        firsts = Counter()
        for st in sents:
            w = WORD_RE.findall(st)
            if len(w) >= 2:
                firsts[(w[0].lower(), w[1].lower())] += 1
        if firsts and firsts.most_common(1)[0][1] >= 3:
            out.append((s, e))
    return out


def f_em_dash(c):
    out = []
    for s, e in c.paras:
        if c.view[s:e].count('—') >= 2:
            out.append((s, e))
    return out


def f_year_range(c):
    out = []
    for m in re.finditer(r'(?<!\d)(1[5-9]\d\d|20\d\d)-(1[5-9]\d\d|20\d\d)(?!\d)', c.view):
        if int(m.group(1)) < int(m.group(2)):
            out.append((m.start(), m.end()))
    return out


def f_semicolon(c):
    words = c.wc()
    if words < 300:
        return []
    if c.view.count(';') == 0 and (c.view.count('(') <= 1):
        return [(0, len(c.view))]
    return []


def f_invisible(c):
    return [(i, i + 1) for i in c.char['inv']]


def f_homoglyph(c):
    return list(c.char['homo'])


def f_nonstandard(c):
    return [(i, i + 1) for i in c.char['ns']]


def f_ai_tracking(c):
    out = []
    for m in re.finditer(r'utm_source=([A-Za-z0-9.\-]+)', c.view, re.I):
        if m.group(1).rstrip('.').lower() in AI_TLD_HOSTS:
            out.append((m.start(), m.end()))
    return out


def f_trailing(c):
    out = []
    pos = 0
    lines = c.window.split('\n')
    for k, line in enumerate(lines):
        body = line.rstrip('\r')
        if not c.masked[k] and body != body.rstrip(' \t'):
            hard = body.endswith('  ') and not body.endswith('   ') and body.strip() != ''
            if not hard:
                out.append((pos + len(body.rstrip(' \t')), pos + len(body)))
        pos += len(line) + 1
    if c.window[:1] in (' ', '\t', '\n', '\r') and c.window:
        out.append((0, 1))
    if re.search(r'\n\s*\n\Z', c.window):
        out.append((len(c.window) - 1, len(c.window)))
    return out


def f_hr(c):
    lines = c.view.split('\n')
    if len(lines) < 24:
        return []
    out = []
    pos = 0
    for line in lines:
        if re.fullmatch(r'\s{0,3}(?:-[ \t]*){3,}|\s{0,3}(?:\*[ \t]*){3,}|\s{0,3}(?:_[ \t]*){3,}', line):
            out.append((pos, pos + len(line)))
        pos += len(line) + 1
    return out if len(out) >= 3 else []


def f_degenerate(c):
    w = c.words
    if len(w) < 12:
        return []
    grams = [tuple(x[2] for x in w[i:i + 6]) for i in range(len(w) - 5)]
    counts = Counter(grams)
    rep = [i for i, g in enumerate(grams) if counts[g] > 1]
    if not rep or len(rep) / float(len(grams)) < 0.2:
        return []
    return [(w[i][0], w[i + 5][1]) for i in rep]


def f_bullets(c):
    if re.search(r'^ {0,3}#{1,6}[ \t]', c.view, re.M):
        return []
    lists, prose = [], 0
    for s, e in c.paras:
        lines = [l for l in c.view[s:e].split('\n') if l.strip()]
        if lines and all(LIST_LINE.match(l) for l in lines):
            lists.append((s, e))
        else:
            prose += 1
    return lists if (lists and prose >= 2) else []


def f_frag_header(c):
    lines = [(m.start(), m.end(), m.group(0)) for m in re.finditer(r'[^\n]*', c.view)]
    out = []
    for k, (s, e, t) in enumerate(lines):
        if not re.match(r'^ {0,3}#{1,6}[ \t]+\S', t):
            continue
        hw = {w.lower() for w in re.findall(r'[A-Za-z]{3,}', t)}
        j = k + 1
        while j < len(lines) and not lines[j][2].strip():
            j += 1
        if j >= len(lines):
            continue
        s2, e2, t2 = lines[j]
        st = t2.strip()
        if not st or st.startswith(('#', '-', '*', '+', '|', '>')) or re.match(r'\d+[.)]', st):
            continue
        words = re.findall(r"[A-Za-z']+", st)
        if 1 <= len(words) <= 4 and any(w.lower() in hw for w in words):
            out.append((s2, e2))
    return out


def f_transitions(c):
    out = []
    for s, e in c.paras:
        text = c.view[s:e]
        hits = []
        for part in re.split(r'(?<=[.!?])\s+|\n', text):
            m = re.match(r'\s*["“(]?([A-Za-z]+)', part)
            if m and m.group(1) in TRANSITIONS:
                hits.append(m.group(1))
        if len(hits) >= 2:
            out += [(s, e)] * len(hits)
    return out


def f_fn_dispatch():
    return {
        3: f_promotional, 6: f_chains, 8: f_synonyms, 40: f_monotony, 41: f_alternation,
        42: f_openers, 44: f_uniform_paragraphs, 46: f_semicolon, 54: f_hedges, 55: f_contractions,
        58: f_em_dash, 59: f_title_case, 61: f_year_range, 62: f_invisible, 65: f_ai_tracking,
        66: f_homoglyph, 67: f_nonstandard, 68: f_trailing, 70: f_hr, 71: f_degenerate,
        33: None, 35: f_frag_header, 34: f_bullets, 37: f_transitions,
    }


FN = f_fn_dispatch()


def spans_of(regs, text):
    out = []
    for r in regs:
        for m in r.finditer(text):
            out.append((m.start(), m.end()))
    return out


fam(34, 'mid_essay_bullets', 'mid-essay bullet list', 8, 'fn', None)
fam(35, 'fragmented_header', 'fragmented header', 6, 'fn', None)
fam(37, 'transition_cluster', 'transition cluster', 6, 'fn', None)

DECISIVE_NUMS = {13, 47, 48, 50, 62, 63, 64, 65, 66}
SHORT_NUMS = set(range(1, 40)) | set(range(47, 52)) | {69}
FN = f_fn_dispatch()
FN.update({34: f_bullets, 35: f_frag_header, 37: f_transitions})


def compute_spans(fam_def, ctx):
    if fam_def['kind'] == 'rx':
        return spans_of(fam_def['payload'], ctx.view)
    fn = FN.get(fam_def['num'])
    return fn(ctx) if fn else []


def sample_text(window, s, e):
    t = re.sub(r'\s+', ' ', window[s:e]).strip()
    return t[:120] + ('…' if len(t) > 120 else '')


def analyze_core(window):
    charinfo = char_info(window)
    view, masked = build_view(window)
    ctx = Ctx(window, view, masked, charinfo)
    findings = []   # (key, label, count, samples, fam)
    fired = {}      # score-moving number -> count
    decisive = set()
    for fdef in FAMS:
        spans = compute_spans(fdef, ctx)
        if fdef['num'] == 56 and len(spans) < 2:
            spans = []
        if len(spans) < fdef['min_hits'] or not spans:
            continue
        key = '%d_%s' % (fdef['num'], fdef['slug'])
        samples = []
        for s, e in spans[:3]:
            samples.append(sample_text(window, s, e))
        findings.append((key, fdef['label'], len(spans), samples, fdef))
        if not fdef['advice']:
            fired[fdef['num']] = fired.get(fdef['num'], 0) + len(spans)
            if fdef['decisive']:
                decisive.add(fdef['num'])
    wc = ctx.wc()
    n_sent = len(ctx.sents)
    score, raw_dbg = compute_score(fired, decisive, wc)
    conf, reason = confidence(wc, len(fired))
    return {
        'findings': findings, 'score': score, 'wc': wc, 'n_sent': n_sent,
        'fired': fired, 'conf': conf, 'reason': reason, 'char': charinfo,
    }


def compute_score(fired, decisive, wc):
    weights = {f['num']: f['weight'] for f in FAMS if not f['advice']}
    raw = 0.0
    for num, cnt in fired.items():
        raw += max(weights.get(num, 8), 0) * (1 - 0.6 ** min(cnt, 50))
    n_fam = len(fired)
    nums = set(fired)
    if nums and nums <= {40}:
        raw = min(raw, 20.0)
    elif nums and nums <= {40, 44}:
        raw = min(raw, 40.0)
    elif n_fam == 1 and not (nums & DECISIVE_NUMS):
        raw = min(raw, 40.0)
    score = int(round(min(raw, 100.0)))
    if len(decisive) >= 2:
        score = max(score, 65)
    elif len(decisive) == 1:
        score = max(score, 45)
    if wc < 120:
        short = len(nums & SHORT_NUMS)
        if short >= 3:
            score = max(score, 45)
        elif short >= 2:
            score = max(score, 25)
    if wc >= 400:
        if n_fam >= 6:
            score = max(score, 45)
        elif n_fam >= 5:
            score = max(score, 25)
    score = max(0, min(100, score))
    return score, raw


def confidence(wc, n_fam):
    if wc < 40:
        return 'none', 'fewer than 40 words'
    if wc < 120:
        return 'low', 'fewer than 120 words'
    if wc < 300 and n_fam == 1:
        return 'low', 'fewer than 300 words with only one score-moving family'
    if wc < 300:
        return 'moderate', 'fewer than 300 words'
    return 'high', ''


def band_of(score):
    if score <= 20:
        return 'clean'
    if score <= 40:
        return 'light tells'
    if score <= 60:
        return 'mixed'
    if score <= 80:
        return 'heavy tells'
    return 'pervasive tells'


def analyze(text, ci=False):
    truncated = len(text) > WINDOW
    window = text[:WINDOW]
    core = analyze_core(window)
    report = {}
    for key, label, count, samples, _ in core['findings']:
        report[key] = {'label': label, 'count': count, 'samples': samples}
    ch = core['char']
    metrics = {
        'scanned_chars': len(window),
        'truncated': truncated,
        'ai_tell_score': core['score'],
        'ai_tell_band': band_of(core['score']),
        'confidence': core['conf'],
        'confidence_reason': core['reason'] or 'high confidence',
        'patterns_flagged': len(core['findings']),
        'invisible_chars': len(ch['inv']),
        'nonstandard_spaces': len(ch['ns']),
        'homoglyphs': ch['homo_chars'],
        'word_count': core['wc'],
        'sentence_count': core['n_sent'],
    }
    if ci:
        if core['n_sent'] < 4:
            metrics['score_ci'] = None
            metrics['score_ci_note'] = 'too few sentences for an interval (fewer than four)'
        else:
            view, _ = build_view(window)
            bounds = [(m.start(), m.end()) for m in SENT_RX.finditer(view) if m.group(0).strip()]
            k = 4
            per = max(1, len(bounds) // k)
            scores = []
            for b in range(k):
                chunk = bounds[b * per:(b + 1) * per if b < k - 1 else len(bounds)]
                if not chunk:
                    continue
                piece = window[chunk[0][0]:chunk[-1][1]]
                scores.append(analyze_core(piece)['score'])
            lo = min(scores + [core['score']])
            hi = max(scores + [core['score']])
            metrics['score_ci'] = [max(0, lo), min(100, hi)]
            metrics['score_ci_note'] = 'low and high of the score over four contiguous sentence blocks, with the point score included'
    report['_metrics'] = metrics
    return report


# ----------------------------------------------------------------- CLI

def main(argv):
    if '--' in argv:
        pre = argv[:argv.index('--')]
    else:
        pre = argv
    if any(a in ('-h', '--help') for a in pre):
        sys.stdout.write(USAGE)
        return 0
    clean = ci = False
    ops = []
    dash = False
    for a in argv:
        if dash:
            ops.append(a)
        elif a == '--':
            dash = True
        elif a == '--clean':
            clean = True
        elif a == '--ci':
            ci = True
        elif a.startswith('-'):
            fail('unknown option: %s (see --help)' % a, 2)
        else:
            ops.append(a)
    if len(ops) > 1:
        sys.stderr.write('prosecheck: %d file operands given; only the last is scanned: %s (not scanned: %s)\n'
                         % (len(ops), ops[-1], ', '.join(ops[:-1])))
    path = ops[-1] if ops else None
    text, _ = load_input(path)
    if not text.strip():
        fail('empty input', 1)
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except AttributeError:
        pass
    if clean:
        sys.stdout.write(scrub(text))
        return 0
    report = analyze(text, ci=ci)
    sys.stdout.write(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
