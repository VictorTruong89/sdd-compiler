#!/usr/bin/env python3
"""prosecheck detector: local, standard-library-only AI-writing pattern scanner."""
import io
import json
import math
import os
import random
import re
import sys
import time
import unicodedata
import zipfile
from html.parser import HTMLParser

WINDOW = 262144
USAGE = (
    "usage: detect.py [--clean] [--ci] [--] [FILE]\n"
    "\n"
    "Scores prose for AI-writing patterns and prints a JSON report.\n"
    "  --clean   print scrubbed text (invisible characters removed, spaces\n"
    "            normalized, lookalike letters folded) instead of the report\n"
    "  --ci      add a resampled low/high interval on the score\n"
    "  --        stop option parsing so a file name may begin with a dash\n"
    "  FILE      one file to scan; with no file, standard input is read\n"
    "  -h, --help  show this message\n"
)

PLAIN_EXT = {".md", ".mdx", ".markdown", ".txt", ".text", ".rst", ".tex", ".org", ".adoc"}
ZIP_EXT = {".docx", ".docm", ".pptx", ".pptm", ".xlsx", ".xlsm", ".odt", ".odp", ".ods", ".epub"}
NB_EXT = {".ipynb"}


class InputError(Exception):
    pass


# --------------------------------------------------------------------------
# Decoding and extraction
# --------------------------------------------------------------------------

def decode_bytes(b):
    if b.startswith(b"\xff\xfe\x00\x00") or b.startswith(b"\x00\x00\xfe\xff"):
        try:
            return b.decode("utf-32")
        except Exception:
            pass
    if b.startswith(b"\xff\xfe") or b.startswith(b"\xfe\xff"):
        try:
            return b.decode("utf-16")
        except Exception:
            return b.decode("utf-16", errors="replace")
    if b.startswith(b"\xef\xbb\xbf"):
        b = b[3:]
    return b.decode("utf-8", errors="replace")


def lname(tag):
    if not isinstance(tag, str):
        return ""
    return tag.rsplit("}", 1)[-1].rsplit(":", 1)[-1]


def read_member(zf, name, limit=64 * 1024 * 1024):
    try:
        with zf.open(name) as f:
            return f.read(limit)
    except Exception:
        return None


def parse_xml(data):
    import xml.etree.ElementTree as ET
    if data is None:
        return None
    try:
        return ET.fromstring(data)
    except Exception:
        return None


def natkey(s):
    return [int(p) if p.isdigit() else p for p in re.split(r"(\d+)", s)]


def x_docx(zf):
    name = "word/document.xml"
    if name not in zf.namelist():
        c = [n for n in zf.namelist() if n.endswith("document.xml")]
        if not c:
            return ""
        name = c[0]
    root = parse_xml(read_member(zf, name))
    if root is None:
        return ""
    paras = []
    for p in root.iter():
        if lname(p.tag) != "p":
            continue
        buf = []
        for e in p.iter():
            n = lname(e.tag)
            if n == "t" and e.text:
                buf.append(e.text)
            elif n == "tab":
                buf.append("\t")
            elif n in ("br", "cr"):
                buf.append("\n")
        s = "".join(buf)
        if s.strip():
            paras.append(s)
    return "\n".join(paras)


def x_pptx(zf):
    names = [n for n in zf.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)]
    names.sort(key=natkey)
    out = []
    for n in names:
        root = parse_xml(read_member(zf, n))
        if root is None:
            continue
        for p in root.iter():
            if lname(p.tag) != "p":
                continue
            buf = []
            for e in p.iter():
                nm = lname(e.tag)
                if nm == "t" and e.text:
                    buf.append(e.text)
                elif nm == "br":
                    buf.append("\n")
            s = "".join(buf)
            if s.strip():
                out.append(s)
    return "\n".join(out)


def x_xlsx(zf):
    shared = []
    sroot = parse_xml(read_member(zf, "xl/sharedStrings.xml")) if "xl/sharedStrings.xml" in zf.namelist() else None
    if sroot is not None:
        for si in sroot:
            if lname(si.tag) != "si":
                continue
            buf = []

            def walk(e):
                for ch in e:
                    n = lname(ch.tag)
                    if n == "t":
                        buf.append(ch.text or "")
                    elif n == "rPh":
                        continue
                    else:
                        walk(ch)
            walk(si)
            shared.append("".join(buf))
    names = [n for n in zf.namelist() if re.match(r"xl/worksheets/[^/]+\.xml$", n)]
    names.sort(key=natkey)
    out = []
    for n in names:
        root = parse_xml(read_member(zf, n))
        if root is None:
            continue
        for c in root.iter():
            if lname(c.tag) != "c":
                continue
            t = c.get("t")
            val = None
            if t == "s":
                v = None
                for ch in c:
                    if lname(ch.tag) == "v":
                        v = (ch.text or "").strip()
                if v is not None and re.fullmatch(r"[0-9]+", v):
                    i = int(v)
                    if i < len(shared):
                        val = shared[i]
            elif t == "inlineStr":
                buf = []
                for e in c.iter():
                    if lname(e.tag) == "t" and e.text:
                        buf.append(e.text)
                val = "".join(buf)
            elif t == "str":
                for ch in c:
                    if lname(ch.tag) == "v":
                        val = ch.text or ""
            if val is not None and val.strip():
                out.append(val)
    return "\n".join(out)


def x_odf(zf):
    root = parse_xml(read_member(zf, "content.xml")) if "content.xml" in zf.namelist() else None
    if root is None:
        return ""
    out = []

    def text_of(e):
        buf = [e.text or ""]
        for ch in e:
            n = lname(ch.tag)
            if n == "s":
                c = 1
                for k, v in ch.attrib.items():
                    if lname(k) == "c":
                        try:
                            c = max(1, min(int(v), 10000))
                        except Exception:
                            c = 1
                buf.append(" " * c)
            elif n == "tab":
                buf.append("\t")
            elif n == "line-break":
                buf.append("\n")
            elif n in ("note", "annotation"):
                pass
            else:
                buf.append(text_of(ch))
            buf.append(ch.tail or "")
        return "".join(buf)

    def walk(e):
        for ch in e:
            n = lname(ch.tag)
            if n in ("p", "h"):
                s = text_of(ch)
                if s.strip():
                    out.append(s)
            else:
                walk(ch)
    walk(root)
    return "\n".join(out)


class _Html(HTMLParser):
    BLOCK = {"p", "div", "h1", "h2", "h3", "h4", "h5", "h6", "li", "br", "tr", "section",
             "article", "blockquote", "pre", "ul", "ol", "table", "dt", "dd", "figure", "hr", "body"}
    SKIP = {"script", "style", "nav", "head", "title"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = [[]]
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        tag = tag.split(":")[-1].lower()
        if tag in self.SKIP:
            self.skip += 1
        if tag in self.BLOCK:
            self.parts.append([])

    def handle_startendtag(self, tag, attrs):
        tag = tag.split(":")[-1].lower()
        if tag in self.BLOCK:
            self.parts.append([])

    def handle_endtag(self, tag):
        tag = tag.split(":")[-1].lower()
        if tag in self.SKIP and self.skip:
            self.skip -= 1
        if tag in self.BLOCK:
            self.parts.append([])

    def handle_data(self, d):
        if not self.skip:
            self.parts[-1].append(d)


def html_text(data):
    p = _Html()
    try:
        p.feed(decode_bytes(data))
        p.close()
    except Exception:
        pass
    lines = []
    for part in p.parts:
        s = re.sub(r"\s+", " ", "".join(part)).strip()
        if s:
            lines.append(s)
    return "\n".join(lines)


def x_epub(zf):
    names = zf.namelist()
    order = []
    try:
        cont = parse_xml(read_member(zf, "META-INF/container.xml"))
        opf = None
        if cont is not None:
            for e in cont.iter():
                if lname(e.tag) == "rootfile":
                    opf = e.get("full-path")
                    break
        if opf and opf in names:
            root = parse_xml(read_member(zf, opf))
            base = os.path.dirname(opf)
            manifest = {}
            navs = set()
            for e in root.iter():
                if lname(e.tag) == "item":
                    manifest[e.get("id")] = e.get("href")
                    if "nav" in (e.get("properties") or "").split():
                        navs.add(e.get("id"))
            for e in root.iter():
                if lname(e.tag) == "itemref":
                    i = e.get("idref")
                    h = manifest.get(i)
                    if h and i not in navs:
                        from urllib.parse import unquote
                        full = os.path.normpath(os.path.join(base, unquote(h))).replace("\\", "/")
                        if full in names and full not in order:
                            order.append(full)
            if order:
                navfiles = {os.path.normpath(os.path.join(base, manifest[i])).replace("\\", "/") for i in navs}
                order = [o for o in order if o not in navfiles]
    except Exception:
        order = []
    if not order:
        order = sorted([n for n in names if re.search(r"\.(x?html?)$", n, re.I)], key=natkey)
        order = [n for n in order if not re.search(r"(^|/)(nav|toc)\.x?html?$", n, re.I)]
    out = []
    for n in order:
        d = read_member(zf, n)
        if d is None:
            continue
        t = html_text(d)
        if t.strip():
            out.append(t)
    return "\n".join(out)


def x_ipynb(data):
    try:
        nb = json.loads(decode_bytes(data))
    except Exception:
        return ""
    if not isinstance(nb, dict):
        return ""
    cells = nb.get("cells")
    if not isinstance(cells, list):
        return ""
    out = []
    for c in cells:
        if not isinstance(c, dict) or c.get("cell_type") != "markdown":
            continue
        src = c.get("source")
        if isinstance(src, str):
            s = src
        elif isinstance(src, list) and all(isinstance(x, str) for x in src):
            s = "".join(src)
        else:
            continue
        if s.strip():
            out.append(s)
    return "\n\n".join(out)


def extract_path(path):
    ext = os.path.splitext(path)[1].lower()
    try:
        if os.path.isdir(path):
            raise InputError("cannot read input: %s is a directory" % path)
        with open(path, "rb") as f:
            raw = f.read() if ext not in ZIP_EXT else None
    except InputError:
        raise
    except Exception as e:
        raise InputError("cannot read input: %s" % (getattr(e, "strerror", None) or e))
    if ext in ZIP_EXT:
        try:
            zf = zipfile.ZipFile(path)
        except Exception as e:
            raise InputError("cannot read input: not a readable zip archive (%s)" % e)
        try:
            if ext in (".docx", ".docm"):
                t = x_docx(zf)
            elif ext in (".pptx", ".pptm"):
                t = x_pptx(zf)
            elif ext in (".xlsx", ".xlsm"):
                t = x_xlsx(zf)
            elif ext == ".epub":
                t = x_epub(zf)
            else:
                t = x_odf(zf)
        except Exception:
            t = ""
        finally:
            zf.close()
        return t.strip()
    if ext in NB_EXT:
        return x_ipynb(raw).strip()
    if ext in (".pdf", ".rtf"):
        return ""
    return decode_bytes(raw)


# --------------------------------------------------------------------------
# Character layer
# --------------------------------------------------------------------------

VISIBLE_CF = set(list(range(0x600, 0x606)) + [0x6DD, 0x70F, 0x8E2, 0x890, 0x891, 0x110BD, 0x110CD])
def _cls(*ranges):
    parts = []
    for r in ranges:
        a, b = (r, r) if isinstance(r, int) else r
        parts.append(chr(a) + ("-" + chr(b) if b != a else ""))
    return re.compile("[" + "".join(parts).replace("\\", "\\\\").replace("]", "\\]") + "]")


_INV_RE = _cls((0, 8), 0xb, 0xc, (0xe, 0x1f), (0x7f, 0x9f), 0xad, 0x34f, 0x61c, 0x115f, 0x1160, (0x17b4, 0x17b5),
               (0x180b, 0x180f), (0x200b, 0x200f), (0x202a, 0x202e), (0x2060, 0x206f), 0x3164, (0xfe00, 0xfe0f),
               0xfeff, 0xffa0, (0xfff9, 0xfffb), (0xe0000, 0xe0fff), (0xe0100, 0xe01ef), (0x1bca0, 0x1bca3),
               (0x1d173, 0x1d17a))
RTL_RE = _cls((0x590, 0x8ff), (0xfb1d, 0xfdff), (0xfe70, 0xfeff), (0x10800, 0x10fff), (0x1e800, 0x1efff))
_NS = [(0xe00, 0xeff), (0x1000, 0x109f), (0x1780, 0x17ff), (0x19e0, 0x19ff), (0x3040, 0x30ff), (0x31f0, 0x31ff),
       (0x3400, 0x4dbf), (0x4e00, 0x9fff), (0xf900, 0xfaff), (0x20000, 0x3134f)]
NOSPACE_RE = _cls(*_NS)
CJK_RE = _cls((0x3400, 0x4dbf), (0x4e00, 0x9fff), (0xf900, 0xfaff), (0x20000, 0x3134f))
JOIN_RE = _cls((0x590, 0x6ff), (0x750, 0x77f), (0x8a0, 0x8ff), (0xfb50, 0xfdff), (0xfe70, 0xfeff), (0x900, 0xdff),
               (0x1000, 0x109f), (0x1780, 0x17ff))
MONGOL_RE = _cls((0x1800, 0x18af))
KHMER_RE = _cls((0x1780, 0x17ff))
TAGSEQ_RE = re.compile("\U0001f3f4[\U000e0020-\U000e007e]+\U000e007f")
BIDI = set("\u200e\u200f\u061c\u202a\u202b\u202c\u202d\u202e\u2066\u2067\u2068\u2069")


def _is_sym(c):
    if not c:
        return False
    o = ord(c)
    if o >= 0x1f000 or 0x2190 <= o <= 0x2bff or 0x2300 <= o <= 0x23ff:
        return True
    return unicodedata.category(c).startswith("S")


def invisible_indices(text):
    """Indices of invisible characters that cleanup removes."""
    cands = []
    for mo in _INV_RE.finditer(text):
        i = mo.start()
        o = ord(text[i])
        if text[i] in "\t\n\r" or o in VISIBLE_CF:
            continue
        cands.append(i)
    if not cands:
        return []
    n = len(text)
    kept_tags = set()
    if any(0xe0000 <= ord(text[i]) <= 0xe0fff for i in cands):
        for mo in TAGSEQ_RE.finditer(text):
            for k in range(mo.start() + 1, mo.end()):
                kept_tags.add(k)
    has_rtl = None
    out = []
    for i in cands:
        c = text[i]
        o = ord(c)
        p = text[i - 1] if i > 0 else ""
        q = text[i + 1] if i + 1 < n else ""
        keep = False
        if 0xe0000 <= o <= 0xe0fff and not (0xe0100 <= o <= 0xe01ef):
            keep = i in kept_tags
        elif 0xe0100 <= o <= 0xe01ef:
            keep = bool(p) and bool(CJK_RE.match(p))
        elif o == 0x200b:
            keep = (bool(p) and bool(NOSPACE_RE.match(p))) or (bool(q) and bool(NOSPACE_RE.match(q)))
        elif o == 0xad:
            keep = p.isalpha() and q.isalpha()
        elif c in BIDI:
            if has_rtl is None:
                has_rtl = bool(RTL_RE.search(text))
            keep = has_rtl
        elif 0x180b <= o <= 0x180f:
            keep = bool(p) and bool(MONGOL_RE.match(p))
        elif o in (0x17b4, 0x17b5):
            keep = (bool(p) and bool(KHMER_RE.match(p))) or (bool(q) and bool(KHMER_RE.match(q)))
        elif o in (0x200c, 0x200d):
            pp = p
            if p == "\ufe0f" and i > 1:
                pp = text[i - 2]
            keep = (bool(pp) and (bool(JOIN_RE.match(pp)) or _is_sym(pp))) or \
                   (bool(q) and (bool(JOIN_RE.match(q)) or _is_sym(q)))
        elif 0xfe00 <= o <= 0xfe0f:
            keep = (bool(p) and (_is_sym(p) or bool(CJK_RE.match(p)))) or q == "\u20e3"
        if not keep:
            out.append(i)
    return out


def drop_indices(text, idx):
    if not idx:
        return text
    parts = []
    last = 0
    for i in idx:
        parts.append(text[last:i])
        last = i + 1
    parts.append(text[last:])
    return "".join(parts)


_SPACE_RE = re.compile("[\u00a0\u1680\u2000-\u200a\u2028\u2029\u202f\u205f\u3000]")
NBSP_BEFORE = set(":;!?\u00bb\u203a%\u20ac")
NBSP_AFTER = set("\u00ab\u2039")


def _is_digit(c):
    return bool(c) and unicodedata.category(c) == "Nd"


def _nb_keep(text, i):
    c = text[i]
    if c not in "\u00a0\u202f":
        return False
    p = text[i - 1] if i > 0 else ""
    q = text[i + 1] if i + 1 < len(text) else ""
    return _is_digit(p) or _is_digit(q) or q in NBSP_BEFORE and q != "" or p in NBSP_AFTER and p != ""


def nonstandard_space_indices(vis):
    out = []
    for mo in _SPACE_RE.finditer(vis):
        i = mo.start()
        if _nb_keep(vis, i):
            continue
        out.append(i)
    return out


# Homoglyphs ---------------------------------------------------------------
_PAIRS = {
    # Cyrillic lower
    "а": "a", "с": "c", "ԁ": "d", "е": "e", "һ": "h", "і": "i", "ј": "j",
    "о": "o", "р": "p", "ѕ": "s", "ѵ": "v", "ԝ": "w", "х": "x", "у": "y",
    # Cyrillic upper
    "А": "A", "В": "B", "С": "C", "Е": "E", "Н": "H", "І": "I", "Ј": "J",
    "К": "K", "М": "M", "О": "O", "Р": "P", "Ѕ": "S", "Т": "T", "Х": "X",
    "У": "Y",
    # Greek
    "ο": "o", "α": "a", "ι": "i", "ρ": "p", "υ": "u", "ν": "v", "χ": "x",
    "Α": "A", "Β": "B", "Ε": "E", "Ζ": "Z", "Η": "H", "Ι": "I", "Κ": "K",
    "Μ": "M", "Ν": "N", "Ο": "O", "Ρ": "P", "Τ": "T", "Υ": "Y", "Χ": "X",
    # Armenian
    "ո": "n", "ս": "u", "օ": "o", "հ": "h", "ց": "g", "գ": "q",
    "Ս": "U", "Օ": "O", "Տ": "S", "Ո": "N", "Շ": "Z", "Ն": "Y",
    # Arabic presentation-ish lookalikes
    "ه": "o", "ﻭ": "o", "ﻩ": "o", "ﻪ": "o", "٥": "o",
}
HOMO = _PAIRS
_TOK_RE = re.compile(r"\S+")
_RUN_RE = re.compile(r"[^\W\d_]+", re.U)


def _is_ascii_letter(c):
    return ("a" <= c <= "z") or ("A" <= c <= "Z")


def fold_token(tok):
    """Return (folded_token, count_of_lookalikes_folded)."""
    if all(ord(c) < 128 for c in tok):
        return tok, 0
    for c in tok:
        if ord(c) > 127 and c.isalpha() and c not in HOMO:
            return tok, 0
    out = []
    last = 0
    cnt = 0
    for mo in _RUN_RE.finditer(tok):
        run = mo.group()
        has_a = any(_is_ascii_letter(c) for c in run)
        has_h = any(c in HOMO for c in run)
        if has_a and has_h:
            out.append(tok[last:mo.start()])
            r2 = []
            for c in run:
                if c in HOMO:
                    r2.append(HOMO[c])
                    cnt += 1
                else:
                    r2.append(c)
            out.append("".join(r2))
            last = mo.end()
    out.append(tok[last:])
    return "".join(out), cnt


def count_homoglyphs(text):
    n = 0
    for mo in _TOK_RE.finditer(text):
        if not mo.group().isascii():
            n += fold_token(mo.group())[1]
    return n


def fold_homoglyphs(text):
    return _TOK_RE.sub(lambda m: m.group() if m.group().isascii() else fold_token(m.group())[0], text)


def clean_text(text):
    if text.startswith("\ufeff"):
        text = text[1:]
    text = drop_indices(text, invisible_indices(text))

    def sp(mo):
        i = mo.start()
        c = mo.group()
        if c in "\u2028\u2029":
            return "\n"
        if _nb_keep(text, i):
            return c
        return " "
    text = _SPACE_RE.sub(sp, text)
    text = fold_homoglyphs(text)
    ended_lf = text.endswith("\n")
    crlf = text.endswith("\r\n")
    lines = text.split("\n")
    res = []
    for k, ln in enumerate(lines):
        cr = ""
        if ln.endswith("\r"):
            cr = "\r"
            ln = ln[:-1]
        body = ln.rstrip(" \t")
        trailing = ln[len(body):]
        if (trailing == "  " and body.strip() and k + 1 < len(lines) and lines[k + 1].strip()):
            body = ln
        res.append(body + cr)
    text = "\n".join(res)
    # leading blank lines
    text = re.sub(r"\A(?:[ \t]*\r?\n)+", "", text)
    text = text.rstrip(" \t\r\n\f\v")
    if ended_lf:
        text += "\r\n" if crlf else "\n"
    return text


# --------------------------------------------------------------------------
# Masking of regions that generate no findings
# --------------------------------------------------------------------------

_FENCE_OPEN = re.compile(r"^ {0,3}(`{3,}|~{3,})(.*)$")
_BADGE = re.compile(r"^\s*(?:\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)\s*)+$")
_TABLE_SEP = re.compile(r"^\s*\|?\s*:?-{2,}:?\s*(?:\|\s*:?-{2,}:?\s*)+\|?\s*$")
_INLINE_CODE = re.compile(r"(?<!`)(`+)(?!`)((?:(?!\n[ \t\r]*\n)[^\x00]){1,2000}?)(?<!`)\1(?!`)")


def mask_text(t):
    lines = t.split("\n")
    n = len(lines)
    mk = [False] * n
    i = 0
    # front matter
    if n and lines[0].rstrip("\r").strip() == "---" and lines[0].rstrip("\r") == "---":
        for j in range(1, n):
            s = lines[j].rstrip("\r")
            if s in ("---", "..."):
                for k in range(0, j + 1):
                    mk[k] = True
                i = j + 1
                break
    # fences
    k = i
    while k < n:
        mo = _FENCE_OPEN.match(lines[k].rstrip("\r"))
        if mo and not (mo.group(1)[0] == "`" and "`" in mo.group(2)):
            fch = mo.group(1)[0]
            flen = len(mo.group(1))
            start = k
            end = n - 1
            for j in range(k + 1, n):
                cm = re.match(r"^ {0,3}(" + re.escape(fch) + "{" + str(flen) + r",})[ \t]*$", lines[j].rstrip("\r"))
                if cm:
                    end = j
                    break
            for j in range(start, end + 1):
                mk[j] = True
            k = end + 1
        else:
            k += 1
    # blockquote runs
    k = 0
    while k < n:
        if not mk[k] and re.match(r"^ {0,3}>", lines[k]):
            j = k
            while j < n and not mk[j] and re.match(r"^ {0,3}>", lines[j]):
                j += 1
            if j - k >= 2:
                for x in range(k, j):
                    mk[x] = True
            k = j
        else:
            k += 1
    for k in range(n):
        if mk[k]:
            continue
        s = lines[k].rstrip("\r")
        st = s.strip()
        if (st.startswith("|") and st.count("|") >= 2) or _TABLE_SEP.match(s) or _BADGE.match(s):
            mk[k] = True
    out = []
    for k in range(n):
        if mk[k]:
            ln = lines[k]
            out.append(" " * (len(ln) - (1 if ln.endswith("\r") else 0)) + ("\r" if ln.endswith("\r") else ""))
        else:
            out.append(lines[k])
    res = "\n".join(out)
    if "`" in res:
        res = _INLINE_CODE.sub(lambda m: re.sub(r"[^\n\r]", " ", m.group()), res)
    return res


# --------------------------------------------------------------------------
# Pattern checks
# --------------------------------------------------------------------------

def rx(p, flags=re.I):
    return re.compile(p.replace(" ", r"\s+"), flags)


def alt(words):
    return "(?:" + "|".join(words) + ")"


def infl(w):
    f = {w, w + "s", w + "es", w + "ed", w + "d", w + "ing"}
    if w.endswith("e"):
        f |= {w[:-1] + "ing", w[:-1] + "ed"}
    if w.endswith("y"):
        f |= {w[:-1] + "ies", w[:-1] + "ied"}
    return f


def word_alt(words):
    forms = set()
    for w in words:
        forms |= infl(w)
    return r"\b" + alt(sorted(forms, key=len, reverse=True)) + r"\b"


def clip(s, n=100):
    s = " ".join(s.split())
    return s if len(s) <= n else s[:n - 1] + "…"


class Ctx:
    pass


def hits_rx(pattern, text):
    return [(m.start(), m.end()) for m in pattern.finditer(text)]


VOCAB1 = ["additionally", "crucial", "delve", "tapestry", "pivotal", "vibrant", "meticulous", "testament",
          "underscore", "intricate", "interplay", "garner", "bolster", "foster", "showcase", "emphasize",
          "enhance", "leverage", "utilize", "facilitate", "encompass", "harness", "holistic", "paradigm",
          "transformative", "unprecedented", "myriad", "plethora", "robust", "seamless", "navigate", "embark",
          "craft", "landscape", "journey", "realm", "multifaceted", "elevate", "empower", "unlock"]
RX1 = re.compile(
    word_alt(VOCAB1) + r"|\benduring\b|\bintricacies\b|\balign(?:s|ed|ing)? with\b".replace(" ", r"\s+")
    + r"|\bcaptur(?:e|es|ed|ing)\s+the\s+(?:essence|spirit|imagination|heart|magic)\b", re.I)

RX2 = rx(r"\b(?:genuinely|fascinating|nuanced|thoughtfully|refreshingly|strikingly|compellingly)\b"
         r"|\bquietly (?:powerful|profound|radical)\b|\bdeeply (?:human|personal|felt|unsettling)\b"
         r"|\bresonat(?:e|es|ed|ing) deeply\b|\bgame[- ]chang(?:er|ers|ing)\b|\bsupercharg\w*|\bskyrocket\w*"
         r"|\bturbocharg\w*|\brevolutioniz\w*|\bdoubl(?:e|es|ed|ing) down on\b"
         r"|\bdiv(?:e|es|ed|ing) deep(?:er)? into\b|\bunlock(?:s|ed|ing)? (?:the )?(?:power|potential|value)\b"
         r"|\btak(?:e|es|ing|en) [^.!?]{1,40}? to the next level\b")

PROMO_WORDS = ["nestled", "breathtaking", "must-visit", "stunning", "picturesque", "charming", "idyllic",
               "vibrant community", "rich cultural heritage", "in the heart of", "world-class", "top-tier",
               "unparalleled", "premier", "esteemed organization", "valuable asset", "passion for excellence",
               "proven track record", "results-oriented", "wealth of experience", "dynamic team",
               "fast-paced environment", "deeply passionate", "perfectly situated", "close-knit team",
               "tight-knit team", "i am excited to (?:apply|bring)", "uniquely positioned to"]
RX3 = rx(r"\b(?:" + "|".join(PROMO_WORDS) + r")\b|\bleading\b(?! (?:to|up|into)\b)")
RX3_IMP = re.compile(r"(?:install|join|grab|download|try|discover|experience|escape|transform|reclaim|unlock|"
                     r"elevate|boost|say|imagine|explore|meet|introducing|upgrade|claim|unleash|supercharge|level|"
                     r"stop|start)\b", re.I)

HYPH = ["cutting-edge", "state-of-the-art", "best-in-class", "results-driven", "data-driven", "forward-thinking",
        "high-quality", "next-generation", "end-to-end", "cross-functional", "customer-centric",
        "mission-critical", "detail-oriented", "well-rounded", "hands-on", "user-friendly", "thought-provoking",
        "ever-evolving", "ever-changing", "far-reaching", "wide-ranging", "top-notch", "award-winning",
        "time-tested", "game-changing", "world-class", "fast-paced", "results-oriented", "client-focused",
        "value-added", "full-service", "one-stop", "cutting-edge", "ground-breaking", "tech-savvy",
        "self-starter", "team-oriented", "goal-oriented", "fast-growing", "long-term"]
RX4 = rx(r"\b(?:" + "|".join(sorted(set(HYPH), key=len, reverse=True)) + r")\b")

RX5 = rx(r"\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b")

STOCK_ADJ = set("""innovative dynamic powerful sleek modern elegant seamless robust scalable intuitive comprehensive
stunning vibrant cutting-edge cohesive flexible versatile efficient reliable passionate creative strategic
exceptional remarkable incredible amazing wonderful fantastic compelling engaging impactful bold fresh
dedicated skilled seasoned proven agile lean smart rich vital key unique""".split())
ADJ_SUFFIX = ("ive", "ous", "able", "ible", "ic", "ical", "ant", "ent", "ful", "less", "al", "ial", "ary", "ory", "ish")
_RX6a = re.compile(r"(?<![\w,-])((?:[A-Za-z][A-Za-z-]*,[ \t]+){3,12}[A-Za-z][A-Za-z-]*)(?![\w-])")
_RX6b = re.compile(r"(?<![\w,-])((?:[A-Za-z][A-Za-z-]*,[ \t]+){2,12}and[ \t]+[A-Za-z][A-Za-z-]*)(?![\w-])", re.I)


def _adjectival(w):
    w = w.lower()
    if w in STOCK_ADJ:
        return True
    return any(w.endswith(s) and len(w) >= len(s) + 3 for s in ADJ_SUFFIX)


def hits_6(ctx):
    out = []
    for pat in (_RX6b, _RX6a):
        for mo in pat.finditer(ctx.nt):
            words = [w for w in re.split(r"[,\s]+", mo.group(1)) if w and w.lower() != "and"]
            if len(words) >= 4 and any(_adjectival(w) for w in words):
                if not any(s <= mo.start() < e for s, e in out):
                    out.append((mo.start(), mo.end()))
    return out


CLUSTERS = [
    ["protagonist", "main character", "central figure", "hero", "heroine"],
    ["company", "firm", "organization", "enterprise", "business"],
    ["author", "writer", "novelist", "scribe"],
    ["report", "study", "analysis", "investigation", "examination"],
    ["technology", "tool", "system", "platform", "solution"],
    ["technique", "method", "approach", "strategy", "tactic"],
    ["challenge", "obstacle", "difficulty", "hurdle", "barrier"],
    ["benefit", "advantage", "upside", "strength"],
]


def _plural(w):
    if w.endswith("y"):
        return w[:-1] + "ies"
    if w.endswith(("s", "x", "ch", "sh")):
        return w + "es"
    return w + "s"


_CLUSTER_RX = []
for cl in CLUSTERS:
    _CLUSTER_RX.append([(w, re.compile(r"\b(?:" + w.replace(" ", r"\s+") + "|" + _plural(w).replace(" ", r"\s+")
                                       + r")\b", re.I)) for w in cl])


def hits_8(ctx):
    out = []
    for cl in _CLUSTER_RX:
        found = []
        for w, r in cl:
            m = r.search(ctx.nt)
            if m:
                found.append((m.start(), m.end()))
        if len(found) >= 3:
            out.append(found[0])
    return out


RX10 = rx(r"\b(?:stand(?:s|ing)?|stood|serv(?:e|es|ed|ing)) as (?:a |an |the )?(?:testament|reminder|symbol|beacon|"
          r"cornerstone|bridge|gateway|hallmark)\b"
          r"|\b(?:underscor|highlight)(?:e|es|ed|ing|s)? (?:its|the|their|his|her) (?:importance|significance|"
          r"enduring|central|vital|crucial|pivotal|key)\b"
          r"|\breflects? a broader (?:trend|shift|pattern)\b|\bmarks? a (?:turning point|milestone|watershed|new chapter|new era)\b"
          r"|\bsymboliz(?:e|es|ed|ing)\b|\bsets? the stage for\b|\bleft an indelible mark\b"
          r"|\bplays? an? (?:crucial|pivotal|vital|key|central|significant) role\b"
          r"|\bhas (?:shaped|sparked)\b|\bhas come to (?:define|symbolize)\b")

_OUTLET = r"(?-i:[A-Z][\w&.'-]*(?: [A-Z][\w&.'-]*)*)"
RX11 = rx(r"\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased) (?:in|by) (?:the )?" + _OUTLET +
          r"(?:, (?:and )?| and )(?:the )?" + _OUTLET +
          r"|\b\d[\d,.]*\s?[kKmM]?\+? (?:followers|subscribers)\b"
          r"|\b(?:strong|active|significant|notable|growing|solid) (?:online|digital|social[- ]media) presence\b"
          r"|\bwidely covered\b|\bindependent(?:ly)? (?:media )?coverage\b")

RX12 = rx(r"\bexperts (?:argue|believe|say|claim|note|suggest)\b|\bindustry (?:reports|observers|analysts)\b"
          r"|\bobservers have (?:cited|noted)\b|\bsome critics argue\b|\bresearchers have found\b"
          r"|\bstudies suggest\b|\bit is widely believed\b")
RX13 = rx(r"\bthe (?:list|index|compilation|collection|catalogue|catalog|guide|overview) of (?:[\w'-]+ ){1,10}?"
          r"(?:is|are) (?:a|an|the)\b")
RX14 = rx(r"\bplays? an? (?:vital|crucial|key|significant) role in (?:its|the) ecosystem\b"
          r"|\bconservation efforts (?:are|is) (?:underway|ongoing|in place)\b|\bserves as an indicator species\b"
          r"|\bcontributes? to biodiversity\b")
RX15 = rx(r"\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?]{0,120}?"
          r"\bto (?:the )?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering|grand|sprawling)\b")
RX16 = rx(r",\s*(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|fostering|cultivating|"
          r"encompassing|signaling|demonstrating|illustrating|representing|suggesting|indicating|reinforcing|"
          r"leveraging|aligning|embodying|exemplifying|epitomizing)\b")
RX17A = rx(r"\bit's not (?:just|merely) (?:about|a|an)\b|\bnot only\b[^.!?\n]{0,40}\bbut\b"
           r"|\bdoesn't just\b[^,.\n]{0,40}\bit\b")
RX17B = rx(r",\s*no (?:guessing|waste|wasted motion|hassle|fluff|stress|jargon)\b")
RX18 = rx(r"\b(?:no|not) \w+,\s*(?:just|only|simply) \w+"
          r"|\b(?:not|isn't|aren't|wasn't|weren't) (?:just|merely) (?:(?:a|an|the) )?\w+(?:,|\s*[—–-]+)\s*"
          r"(?:it's|it is|it was|they're|they are|they were|that's|but)\b")
RX19 = rx(r"\bin order to\b|\bdue to the fact that\b|\bat this point in time\b|\bin the event that\b"
          r"|\bhas the ability to\b|\bit is important to note that\b|\bit should be mentioned that\b|\bneedless to say\b")
RX20 = rx(r"\bit's worth (?:noting|mentioning) that\b|\bit bears (?:noting|mentioning) that\b"
          r"|\bone thing to (?:consider|keep in mind) is\b|\bit is interesting to note that\b"
          r"|\ba key consideration is\b|\ba point to highlight is\b")
RX21 = rx(r",\s*(?:raising questions about|prompting reflection on|sparking debate about|with broader implications for|"
          r"reshaping our understanding of|paving the way for|signaling a shift toward)\b")
RX22 = rx(r"\bhere's the thing\b|\bmake no mistake\b|\bthe truth is\b|\blet's be honest\b|\bthe simple fact is\b"
          r"|\bat its core\b|\bwhat really matters\b|\bmore than anything\b|\bat the end of the day\b"
          r"|\bthe bottom line is\b|\bin reality\b|\bfundamentally,|\bthe real question is\b"
          r"|\bthe heart of the matter\b|\bthe deeper issue\b|\bwhen you get down to it\b|\bwhen all is said and done\b")
RX23 = rx(r"\bit(?:'s| is) important to (?:remember|note|understand|recognize)\b|\bone must note that\b"
          r"|\bit is worth pointing out\b|\bit cannot be overstated that\b|\bit must be emphasized that\b")
RX24 = rx(r"\bthis (?:comprehensive|complete|in-depth) (?:guide|overview|analysis|look|examination)\b"
          r"|\bthis in-depth (?:analysis|look|examination)\b|\ba thorough examination of\b"
          r"|\beverything you need to know about\b")
AUX = "(?:do|does|did|is|are|can|could|will|would|should|has|have|was|were|may|might|must|shall)"
RX25 = re.compile(r"(?:^|(?<=[.!?])\s+|\n)(" + AUX + r"\b[^.!?\n]{0,80}\?)[ \t]+"
                  r"(?:yes|no|absolutely|never|maybe|probably|always|definitely|certainly|sometimes|rarely)[.!]",
                  re.I)
RX26 = rx(r"\bwithout concrete evidence\b|\bdo you have concrete evidence\b|\bi (?:would )?need concrete "
          r"(?:evidence|examples) to\b|\babsent concrete proof\b|\bprovide concrete evidence\b")
RX27 = rx(r"\bin today's (?:[\w-]+ ){0,2}(?:world|landscape|environment|market)\b|\bin a world where\b"
          r"|\bin an era of\b|\bin recent years,|\bmore than ever before\b|\bwe live in a (?:time|world) when\b"
          r"|\b(?:great|exciting|big) news[!:]|\bever (?:wanted|wondered|dreamed|wished) to\b[^.!?]*\?"
          r"|\bin an increasingly (?:interconnected|digital|competitive|complex) world\b")
RX30 = rx(r"\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)\b"
          r"|\b(?:the|this) (?:(?:latest|new) )?(?:update|release|version|change|patch|design) "
          r"(?:adds|introduces|brings|delivers|includes|provides|improves)\b"
          r"|\b(?:has|have) been (?:updated|refactored|improved|enhanced|changed) to\b"
          r"|\bpreviously\b[^.!?]{0,120}\bnow\b|\b(?:wasn't|weren't) there before\b"
          r"|\bwe(?:'ve| have) (?:now )?(?:added|removed|replaced|refactored|migrated)\b")
RX31 = rx(r"\blet's (?:dive|delve|explore)\b|\blet's break (?:this|it) down\b|\bhere's what you need to know\b"
          r"|\bwithout further ado\b|\bnow let's look at\b|\bbuckle up\b|\bstay with me\b|\bready to dive in\b")
RX32 = rx(r"\b(?:used|uses|employs|employed|relied on|utilizes) (?:several|various|a number of|multiple|different|many|"
          r"numerous) \w+"
          r"|(?:^|[.!?]\s+)these (?:\w+ )?(?:provide|offer|give|reveal|show|allow|enable|help) "
          r"(?:information|insight|understanding|details|data)\b"
          r"|\b(?:is|are|was|were|remains|becomes) (?:the |a )?(?:language|currency|architecture|heartbeat|lifeblood|"
          r"dna|backbone|bedrock|engine|scaffolding|connective tissue) of\b", re.I | re.M)
RX33 = re.compile(r"^[ \t]*(?:[-*+][ \t]+|\d+[.)][ \t]+)?\*\*[^*\n]{1,80}?(?::\*\*|\*\*:)", re.M)
RX36 = rx(r"\bdespite (?:these|its|the) (?:challenges|obstacles)\b|\bchallenges and (?:future )?(?:prospects|outlook|legacy)\b"
          r"|\bcontinues to thrive\b|\btypical of (?:emerging|urban|modern)\b|\bfaces (?:several|many|numerous) challenges\b")
RX37 = re.compile(r"(?:^|(?<=[.!?])[\"')\]]*[ \t]+|(?<=[.!?])[\"')\]]*\n)(?:Additionally|Furthermore|Moreover|However|"
                  r"Nevertheless|Consequently|Subsequently|Notably)\b", re.M)
RX38 = re.compile(r"^[ \t#>*\-]*(?:in conclusion|overall|in summary|to summarize|to conclude|all in all|in essence|"
                  r"ultimately)\b", re.I | re.M)
RX39 = rx(r"\bthe future looks bright\b|\bexciting times lie ahead\b|\bjourney toward excellence\b"
          r"|\bstep in the right direction\b|\b(?:outlook|future)(?: for [\w ]{1,40}?)? (?:is|looks|remains) bright\b"
          r"|\bwell[- ]positioned for (?:whatever comes next|the future|the road ahead)\b")
RX47 = rx(r"\bi hope this helps\b|\b(?:certainly|of course)!|\blet me know if you\b|\bwould you like me to\b"
          r"|\bfeel free to (?:ask|reach out)\b|\bhappy to help\s*(?:[.!?]|$)"
          r"|\b(?:here|below) is (?:a |an |the )?(?:overview|summary|rundown|recap|brief)\b"
          r"|\bhere(?: are|'s) (?:a few|some|two|three) (?:options|drafts|versions|variations)\b"
          r"|\bhere(?: is|'s) a draft\b|\bdepending on the (?:vibe|tone|style)\b|\bi hope (?:this email )?finds you well\b"
          r"|\bas an? (?:ai|llm|ai assistant|ai language model|large language model|language model)\b"
          r"|\bto (?:answer|address) your question\b|\bin (?:response|answer) to your question\b"
          r"|\byour question (?:about|regarding|concerning)\b|\bas (?:you )?(?:requested|asked), here\b"
          r"|\bhere is (?:the )?(?:draft|first pass|revised version of|for your)\b")
RX48 = rx(r"\byou(?:'re| are) absolutely right\b|\b(?:great question|excellent point)[!.,]"
          r"|\bwhat an? (?:thoughtful|great|wonderful|fantastic) question\b|\bwhat a (?:thoughtful|great|wonderful|fantastic) question\b"
          r"|\bthat's an? (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\b")
RX50 = rx(r"\bas of my (?:last )?(?:training|knowledge)\b|\bup to my (?:last )?(?:training|knowledge)\b"
          r"|\bwhile specific details are (?:limited|scarce|not (?:extensively|widely) documented)\b"
          r"|\bbased on (?:the )?available information\b|\bas of my (?:knowledge )?cutoff\b"
          r"|\bmaintains a low profile\b|\bkeeps (?:his|her|their) personal life private\b")
RX51 = rx(r"\b(?:serv(?:e|es|ed|ing)|stand(?:s|ing)?|stood|function(?:s|ed|ing)?|act(?:s|ed|ing)?) as\b"
          r"|\brepresents (?:a|the)\b|\bmarks (?:a|the)\b|\bboasts?\b"
          r"|\bfeatures (?:a|an|the|\d+|several|many|numerous|multiple|various|some|two|three|four|five|over)\b"
          r"|\boffers a\b|\brefers to\b")
RX54 = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|somewhat|relatively|fairly|"
                  r"seems?(?: to| like)|appears? to|kind of|sort of)\b")
RX56 = re.compile(r"\*\*[^*\n]+\*\*")
RX57 = re.compile("[\u231a\u231b\u23e9-\u23f3\u2600-\u27bf\u2b50\u2b55\u2b1b\u2b1c\U0001f000-\U0001faff]")
RX60 = re.compile("[\u2018\u2019\u201c\u201d]")
RX61 = re.compile(r"\b(1[0-9]{3}|20[0-9]{2})-(1[0-9]{3}|20[0-9]{2})\b")
RX63 = [
    re.compile(r"\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\](?![(\[])", re.I),
    re.compile(r"\[(?:[^\]\n]{0,30}\b)?(?:person|company|client|place|source|name|city|location|organization|recipient)"
               r"\b[^\]\n]{0,30}\](?![(\[])", re.I),
    re.compile(r"\[[A-Z][A-Z0-9 _/.'-]{2,}\](?![(\[])"),
    re.compile(r"\{\{[^}\n]*\}\}"),
    re.compile(r"(?<![A-Za-z0-9])[xX]{3,}(?![A-Za-z0-9])"),
    re.compile(r"\blorem ipsum\b", re.I),
]
RX64 = rx(r"\bcite(?:turn|start|nav)\w*|\boai_citation\w*|\bcontentReference\b|\bnavlist\b|【\d+†[^】]*】")
RX65 = re.compile(r"utm_source=([^\s&#)\]>\"'<,;]*)", re.I)
AI_HOSTS = {"chatgpt.com", "chat.openai.com", "perplexity.ai", "claude.ai", "gemini.google.com",
            "copilot.microsoft.com", "poe.com"}
RX69 = rx(r"\bunlock(?:ing|s|ed)? (?:its |the |your |their )?full potential\b|\bnavigat(?:e|es|ed|ing) the complexit(?:y|ies)\b"
          r"|\ba testament to the (?:power|importance)\b|\bstay(?:ing|s)? ahead of the curve\b"
          r"|\bturn(?:ing|s)? challenges into opportunities\b|\btak(?:e|es|ing) (?:your |it |them |things |\w+ )?to the next level\b"
          r"|\bharness(?:es|ed|ing)? the power of\b|\bpav(?:e|es|ed|ing) the way for\b|\bsay(?:ing)? goodbye to\b"
          r"|\bimagin(?:e|ing) a world where\b|\bat the forefront of\b|\bwhere innovation meets\b"
          r"|\bthe ever-evolving (?:world|landscape)\b|\brevolutioniz(?:e|es|ed|ing) the way\b")
RX70 = re.compile(r"^ {0,3}([-*_])(?:[ \t]*\1){2,}[ \t]*\r?$", re.M)


def hits_2(ctx):
    h = hits_rx(RX2, ctx.nt)
    return h if len(h) >= 2 else []


def hits_3(ctx):
    h = hits_rx(RX3, ctx.nt)
    imp = []
    for a, b in ctx.sentence_spans:
        seg = ctx.nt[a:b]
        k = len(seg) - len(seg.lstrip(" \t#>*-\r\n"))
        if RX3_IMP.match(seg, k):
            imp.append((a + k, min(b, a + k + 40)))
    if len(imp) >= 3:
        h += imp
    return h


def hits_63(ctx):
    out = []
    for p in RX63:
        for m in p.finditer(ctx.nt):
            s = m.group()
            if p is RX63[2] and re.fullmatch(r"\[[A-Z]{1,2}\d{0,3}\]", s):
                continue
            out.append((m.start(), m.end()))
    return out


def hits_65(ctx):
    out = []
    for m in RX65.finditer(ctx.nt):
        v = m.group(1).lower()
        mo = re.match(r"[a-z0-9.-]*", v)
        host = mo.group().rstrip(".")
        if host in AI_HOSTS:
            out.append((m.start(), m.end()))
    return out


def hits_70(ctx):
    h = hits_rx(RX70, ctx.nt)
    if len(h) >= 3 and ctx.nt.count("\n") + 1 >= 24:
        return h
    return []


def hits_61(ctx):
    out = []
    for m in RX61.finditer(ctx.nt):
        if int(m.group(2)) > int(m.group(1)):
            out.append((m.start(), m.end()))
    return out


def hits_54(ctx):
    out = []
    for s in ctx.sentence_spans:
        seg = ctx.nt[s[0]:s[1]]
        if len(RX54.findall(seg)) >= 2:
            out.append(s)
    return out


def hits_58(ctx):
    out = []
    for s, e in ctx.para_spans:
        seg = ctx.nt[s:e]
        if seg.count("—") >= 2:
            out.append((s, min(e, s + 80)))
    return out


def hits_37(ctx):
    out = []
    for s, e in ctx.para_spans:
        ms = list(RX37.finditer(ctx.nt, s, e))
        if len(ms) >= 2:
            out.append((ms[0].start(), ms[0].end()))
            out.extend((m.start(), m.end()) for m in ms[1:])
    return out


def hits_33(ctx):
    return hits_rx(RX33, ctx.nt)


def hits_34(ctx):
    if re.search(r"^ {0,3}#{1,6}[ \t]", ctx.nt, re.M):
        return []
    list_paras = 0
    prose = 0
    first = None
    for s, e in ctx.para_spans:
        lines = [l for l in ctx.nt[s:e].split("\n") if l.strip()]
        if not lines:
            continue
        if all(re.match(r"^\s*(?:[-*+]|\d+[.)])\s+\S", l) for l in lines):
            list_paras += 1
            if first is None:
                first = (s, min(e, s + 60))
        else:
            prose += 1
    if list_paras >= 1 and prose >= 2:
        return [first]
    return []


STOP_SHORT = set("a an the and or of in on at to for with by from is are".split())


def hits_35(ctx):
    out = []
    lines = ctx.nt.split("\n")
    pos = 0
    offs = []
    for l in lines:
        offs.append(pos)
        pos += len(l) + 1
    for i, l in enumerate(lines):
        mo = re.match(r"^ {0,3}#{1,6}[ \t]+(.+?)[ \t#]*\r?$", l)
        if not mo:
            continue
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nxt = lines[j].strip()
        if re.match(r"^(?:#|[-*+]\s|\d+[.)]\s|\|)", nxt):
            continue
        w = re.findall(r"[A-Za-z']+", nxt)
        if not w or len(w) > 5:
            continue
        hw = {x.lower() for x in re.findall(r"[A-Za-z']+", mo.group(1)) if x.lower() not in STOP_SHORT and len(x) > 2}
        if any(x.lower() in hw for x in w):
            out.append((offs[i], offs[i] + len(l)))
    return out


MINOR = set("a an the and but or nor for yet so of in on at to by up as per via vs off out".split())


def hits_59(ctx):
    out = []
    for mo in re.finditer(r"^ {0,3}#{1,6}[ \t]+(.+?)[ \t#]*\r?$", ctx.nt, re.M):
        title = mo.group(1).strip()
        if not title or not title[0].isalpha():
            continue
        words = title.split()
        if len(words) < 3:
            continue
        letters = [c for c in title if c.isalpha()]
        if letters and all(c.isupper() for c in letters):
            continue
        major = [w for w in words if w.lower().strip(".,:;!?") not in MINOR]
        if len(major) < 2:
            continue
        if all(w[0].isupper() for w in major if w[0].isalpha()) and all(w[0].isalpha() for w in major):
            out.append((mo.start(), mo.end()))
    return out


def _cv(vals):
    m = sum(vals) / len(vals)
    if m == 0:
        return 0.0
    var = sum((v - m) ** 2 for v in vals) / len(vals)
    return math.sqrt(var) / m


def hits_40(ctx):
    L = ctx.sent_lens
    if len(L) >= 3 and _cv(L) < 0.35:
        return [(0, min(len(ctx.nt), 60))]
    return []


def hits_44(ctx):
    L = [n for n in ctx.para_word_counts if n > 0]
    if len(L) >= 4 and _cv(L) < 0.4:
        return [(0, min(len(ctx.nt), 60))]
    return []


def hits_41(ctx):
    L = ctx.sent_lens
    best = 1
    run = 1
    last_sign = 0
    for i in range(1, len(L)):
        d = L[i] - L[i - 1]
        a, b = L[i], L[i - 1]
        ok = abs(d) >= max(3, 0.4 * max(a, b))
        sign = 1 if d > 0 else -1
        if ok and (last_sign == 0 or sign == -last_sign):
            run += 1
        elif ok:
            run = 2
        else:
            run = 1
            sign = 0
        last_sign = sign if ok else 0
        best = max(best, run)
    if best >= 6:
        return [(0, min(len(ctx.nt), 60))]
    return []


def hits_42(ctx):
    out = []
    for s, e in ctx.para_spans:
        sents = split_sentences(ctx.nt[s:e])
        if len(sents) < 3:
            continue
        cnt = {}
        for x in sents:
            w = re.findall(r"[\w'-]+", x.lower())
            if len(w) >= 2:
                cnt[(w[0], w[1])] = cnt.get((w[0], w[1]), 0) + 1
        if any(v >= 3 for v in cnt.values()):
            out.append((s, min(e, s + 60)))
    return out


def hits_46(ctx):
    if ctx.nwords < 300:
        return []
    if ";" in ctx.nt:
        return []
    if ctx.nt.count("(") > 1:
        return []
    return [(0, min(len(ctx.nt), 40))]


FIRST_P = set("i me my mine myself we us our ours ourselves".split())
_FULL = re.compile(r"\b(?:do not|does not|did not|is not|are not|was not|were not|cannot|can not|will not|would not|"
                   r"should not|could not|have not|has not|had not|i am|i have|i will|i would|we are|we have|"
                   r"we will|you are|you have|they are|that is|it is|there is|let us)\b", re.I)
_CONTR = re.compile(r"\b\w+n't\b|\b(?:i|we|you|they|he|she|it|that|there|who)(?:'m|'re|'ve|'ll|'d)\b|\b(?:it|that|there|he|she|what|let)'s\b", re.I)


def hits_55(ctx):
    w = [x.lower() for x in ctx.words]
    if not w:
        return []
    fp = sum(1 for x in w if x in FIRST_P)
    if fp < 3 or fp / len(w) < 0.02:
        return []
    full = len(_FULL.findall(ctx.nt))
    con = len(_CONTR.findall(ctx.nt))
    if full >= 3 and full > con:
        return [(0, min(len(ctx.nt), 40))]
    return []


def hits_71(ctx):
    w = [x.lower() for x in ctx.words]
    if len(w) < 12:
        return []
    grams = {}
    total = len(w) - 5
    for i in range(total):
        g = tuple(w[i:i + 6])
        grams[g] = grams.get(g, 0) + 1
    rep = sum(v for v in grams.values() if v > 1)
    if rep and rep / total >= 0.2:
        return [(0, min(len(ctx.nt), 60))]
    return []


def hits_62(ctx):
    return [(i, i + 1) for i in ctx.inv_idx]


def hits_66(ctx):
    out = []
    for mo in _TOK_RE.finditer(ctx.m):
        tok = mo.group()
        if not tok.isascii() and fold_token(tok)[1]:
            out.append((mo.start(), mo.end()))
    return out


def hits_67(ctx):
    return [(i, i + 1) for i in ctx.ns_idx]


RX68 = [re.compile(r"[ \t]+(?=\r?\n)"), re.compile(r"[ \t]+\Z"), re.compile(r"(?:\r?\n){2,}\Z"), re.compile(r"\A\s+")]


def hits_68(ctx):
    out = []
    for p in RX68:
        out.extend((m.start(), m.end()) for m in p.finditer(ctx.raw))
    return out


def R(pat):
    return lambda ctx: hits_rx(pat, ctx.nt)


# (num, slug, label, fn)
CHECKS = [
    (1, "ai_vocabulary", "AI vocabulary", R(RX1)),
    (2, "model_dialect_vocabulary", "Model-dialect vocabulary", hits_2),
    (3, "promotional_language", "Promotional language", hits_3),
    (4, "hyphenated_word_pairs", "Hyphenated word-pair overuse", R(RX4)),
    (5, "simple_yet", "\"Simple yet X\" cliché", R(RX5)),
    (6, "stacked_adjectives", "Stacked adjective chains", hits_6),
    (8, "synonym_cycling", "Synonym cycling", hits_8),
    (10, "significance_inflation", "Significance inflation", R(RX10)),
    (11, "notability_name_dropping", "Notability name-dropping", R(RX11)),
    (12, "vague_attributions", "Vague attributions", R(RX12)),
    (13, "article_title_proper_noun", "Article title as proper noun", R(RX13)),
    (14, "conservation_padding", "Conservation / ecosystem padding", R(RX14)),
    (15, "false_ranges", "False ranges", R(RX15)),
    (16, "ing_tail_clauses", "Superficial -ing tail clauses", R(RX16)),
    (17, "negative_parallelism", "Negative parallelism", R(RX17A)),
    (17, "tailing_negation", "Tailing negation", R(RX17B)),
    (18, "not_x_just_y", "\"Not X, just Y\" construction", R(RX18)),
    (19, "filler_phrases", "Filler phrases", R(RX19)),
    (20, "empty_pivot_phrases", "Empty pivot phrases", R(RX20)),
    (21, "outcome_speculation_tails", "Outcome-speculation tails", R(RX21)),
    (22, "persuasive_authority_tropes", "Persuasive authority tropes", R(RX22)),
    (23, "editorial_interjections", "Editorial interjections", R(RX23)),
    (24, "self_thoroughness", "Self-thoroughness phrases", R(RX24)),
    (25, "question_answer_pattern", "Question-answer rhetorical pattern", R(RX25)),
    (26, "concrete_evidence_phrase", "\"Concrete evidence\" defense phrase", R(RX26)),
    (27, "intro_hooks", "Compulsive intro hooks", R(RX27)),
    (30, "diff_anchored_writing", "Diff-anchored writing", R(RX30)),
    (31, "signposting", "Signposting and announcements", R(RX31)),
    (32, "cataloguing_lead_ins", "Cataloguing lead-ins", R(RX32)),
    (33, "inline_header_lists", "Inline-header vertical lists", hits_33),
    (34, "mid_essay_bullets", "Mid-essay bullet injection", hits_34),
    (35, "fragmented_headers", "Fragmented headers", hits_35),
    (36, "formulaic_challenges", "Formulaic challenges section", R(RX36)),
    (37, "transition_clusters", "Transition cluster overuse", hits_37),
    (38, "compulsive_conclusions", "Compulsive conclusion phrases", R(RX38)),
    (39, "generic_positive_conclusions", "Generic positive conclusions", R(RX39)),
    (40, "sentence_length_monotony", "Sentence-length monotony", hits_40),
    (41, "sentence_length_alternation", "Mechanical sentence-length alternation", hits_41),
    (42, "opener_repetition", "Opener repetition", hits_42),
    (44, "uniform_paragraph_length", "Uniform paragraph length", hits_44),
    (46, "semicolon_paren_underuse", "Semicolon and parenthesis underuse", hits_46),
    (47, "chatbot_artifacts", "Chatbot artifacts", R(RX47)),
    (48, "sycophantic_tone", "Sycophantic tone", R(RX48)),
    (50, "knowledge_cutoff_disclaimers", "Knowledge-cutoff disclaimers", R(RX50)),
    (51, "copula_avoidance", "Copula avoidance", R(RX51)),
    (54, "hedge_stacking", "Hedge stacking", hits_54),
    (55, "contraction_absence", "Contraction absence", hits_55),
    (56, "boldface_overuse", "Boldface overuse", R(RX56)),
    (57, "emojis", "Emojis", R(RX57)),
    (58, "em_dash_overuse", "Em-dash overuse", hits_58),
    (59, "title_case_headings", "Title case in headings", hits_59),
    (60, "curly_quotes", "Curly quotation marks", None),
    (61, "hyphen_for_en_dash", "Hyphen-for-en-dash in ranges", hits_61),
    (62, "invisible_characters", "Invisible / zero-width characters", hits_62),
    (63, "placeholder_text", "Placeholder / Mad-Libs text", hits_63),
    (64, "chat_reference_markup", "Chatbot reference-markup leak", R(RX64)),
    (65, "ai_tracking_params", "AI tracking parameters", hits_65),
    (66, "homoglyphs", "Homoglyph / mixed-script confusables", hits_66),
    (67, "nonstandard_spaces", "Non-standard spaces", hits_67),
    (68, "trailing_whitespace", "Trailing / stray whitespace", hits_68),
    (69, "marketing_slop", "Canonical marketing-slop phrases", R(RX69)),
    (70, "decorative_rules", "Decorative horizontal rules", hits_70),
    (71, "degenerate_repetition", "Degenerate repetition", hits_71),
]
CHECKS = [(n, s, l, (lambda ctx: hits_rx(RX60, ctx.m)) if f is None else f) for n, s, l, f in CHECKS]

ADVICE = {4, 17, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68}
DECISIVE = {62, 63, 64, 65, 66, 13, 47, 50, 48}
RHYTHM = {40, 44}
SHORT_SET = set(range(1, 40)) | set(range(47, 52)) | {69}


def weight(n):
    if n in ADVICE:
        return 0
    if n in DECISIVE:
        return 20
    if n in RHYTHM:
        return 5
    return 10


# --------------------------------------------------------------------------
# Analysis
# --------------------------------------------------------------------------

_WORD_RE = re.compile(r"[^\W_][\w'-]*")
_SENT_SPLIT = re.compile(r"(?<=[.!?])[\"')\]]*\s+(?=\S)")


def split_sentences(par):
    lines = []
    for l in par.split("\n"):
        s = l.strip()
        if not s or re.match(r"^#{1,6}\s", s) or re.match(r"^([-*_])(\s*\1){2,}$", s):
            continue
        s = re.sub(r"^(?:[-*+]|\d+[.)])\s+", "", s)
        lines.append(s)
    txt = " ".join(lines)
    return [x for x in _SENT_SPLIT.split(txt) if x.strip()]


def paragraph_spans(t):
    spans = []
    pos = 0
    for mo in re.finditer(r"\n[ \t\r]*\n+", t):
        if mo.start() > pos:
            spans.append((pos, mo.start()))
        pos = mo.end()
    if pos < len(t):
        spans.append((pos, len(t)))
    return [(s, e) for s, e in spans if t[s:e].strip()]


def analyze(window, want_items=False):
    ctx = Ctx()
    ctx.raw = window
    ctx.m = mask_text(window)
    ctx.nt = ctx.m.replace("\u2019", "'").replace("\u2018", "'")
    ctx.words = _WORD_RE.findall(ctx.nt)
    ctx.nwords = len(ctx.words)
    ctx.para_spans = paragraph_spans(ctx.nt)
    ctx.para_word_counts = [len(_WORD_RE.findall(ctx.nt[s:e])) for s, e in ctx.para_spans]
    sent_lens = []
    sent_spans = []
    for s, e in ctx.para_spans:
        seg = ctx.nt[s:e]
        pos = 0
        for mo in _SENT_SPLIT.finditer(seg):
            sent_spans.append((s + pos, s + mo.start() + 1))
            pos = mo.end()
        sent_spans.append((s + pos, e))
        for x in split_sentences(seg):
            wc = len(_WORD_RE.findall(x))
            if wc:
                sent_lens.append(wc)
    ctx.sentence_spans = sent_spans
    ctx.sent_lens = sent_lens
    # character layer on masked text
    ctx.inv_idx = invisible_indices(ctx.m)
    vis = drop_indices(ctx.m, ctx.inv_idx)
    ctx.ns_idx = nonstandard_space_indices(vis)
    findings = []
    for num, slug, label, fn in CHECKS:
        try:
            hits = fn(ctx)
        except Exception:
            hits = []
        if not hits:
            continue
        findings.append((num, slug, label, hits))
    return ctx, findings


def excerpt(raw, s, e, pad=30):
    a = max(0, s - pad)
    b = min(len(raw), e + pad)
    seg = raw[a:b].replace("\r", "").replace("\n", " ")
    return ("…" if a > 0 else "") + seg + ("…" if b < len(raw) else "")


def make_samples(num, ctx, hits):
    out = []
    for s, e in hits:
        if num == 1:
            smp = excerpt(ctx.raw, s, e)
        elif num in (62, 67):
            smp = "U+%04X" % ord(ctx.m[s]) if s < len(ctx.m) else ""
        else:
            smp = clip(ctx.nt[s:e])
        if smp and smp not in out:
            out.append(smp)
        if len(out) >= 3:
            break
    return out


def compute_score(findings, nwords):
    moving = {n for n, s, l, h in findings if weight(n) > 0}
    base = sum(weight(n) for n in moving)
    if len(moving) == 1:
        base = min(base, 40)
    if moving and moving <= RHYTHM:
        base = min(base, 40)
    if moving == {40}:
        base = min(base, 20)
    floor = 0
    d = len(moving & DECISIVE)
    if d >= 2:
        floor = max(floor, 65)
    elif d == 1:
        floor = max(floor, 45)
    if nwords < 120:
        c = len(moving & SHORT_SET)
        if c >= 3:
            floor = max(floor, 45)
        elif c >= 2:
            floor = max(floor, 25)
    if nwords >= 400:
        c = len(moving)
        if c >= 6:
            floor = max(floor, 45)
        elif c >= 5:
            floor = max(floor, 25)
    score = max(base, floor)
    score = max(0, min(100, score))
    if moving == {40}:
        score = min(score, 20)
    return score, len(moving)


def band_of(s):
    if s <= 20:
        return "clean"
    if s <= 40:
        return "light tells"
    if s <= 60:
        return "mixed"
    if s <= 80:
        return "heavy tells"
    return "pervasive tells"


def confidence(nwords, nmoving):
    if nwords < 40:
        return "none", "fewer than 40 words; too short for a meaningful score"
    if nwords < 120:
        return "low", "fewer than 120 words; the score is a weak signal"
    if nwords < 300:
        if nmoving <= 1:
            return "low", "fewer than 300 words with only one score-moving family"
        return "moderate", "fewer than 300 words; more text would firm up the score"
    return "high", ""


def build_report(text, want_ci):
    window = text[:WINDOW]
    truncated = len(text) > WINDOW
    ctx, findings = analyze(window)
    score, nmoving = compute_score(findings, ctx.nwords)
    conf, reason = confidence(ctx.nwords, nmoving)
    report = {}
    for num, slug, label, hits in findings:
        report["%d_%s" % (num, slug)] = {
            "label": label,
            "count": len(hits),
            "samples": make_samples(num, ctx, hits),
        }
    metrics = {
        "scanned_chars": len(window),
        "truncated": truncated,
        "ai_tell_score": score,
        "ai_tell_band": band_of(score),
        "confidence": conf,
        "confidence_reason": reason,
        "patterns_flagged": len(findings),
        "invisible_chars": len(ctx.inv_idx),
        "nonstandard_spaces": len(ctx.ns_idx),
        "homoglyphs": count_homoglyphs(ctx.m),
        "words": ctx.nwords,
    }
    if want_ci:
        sents = []
        for s, e in ctx.para_spans:
            sents.extend(split_sentences(ctx.nt[s:e]))
        if len(sents) < 4:
            metrics["score_ci"] = None
            metrics["score_ci_note"] = "too few sentences for an interval (need at least four)"
        else:
            rnd = random.Random(20240601)
            n = 30 if len(window) <= 30000 else 8
            vals = []
            t0 = time.time()
            for _ in range(n):
                samp = [sents[rnd.randrange(len(sents))] for _ in sents]
                c2, f2 = analyze(" ".join(samp))
                vals.append(compute_score(f2, c2.nwords)[0])
                if time.time() - t0 > 3:
                    break
            vals.sort()
            lo = vals[int(0.05 * (len(vals) - 1))]
            hi = vals[int(math.ceil(0.95 * (len(vals) - 1)))]
            lo = min(lo, score)
            hi = max(hi, score)
            metrics["score_ci"] = [float(max(0, lo)), float(min(100, hi))]
            metrics["score_ci_note"] = "resampled over sentences (%d draws, fixed seed)" % len(vals)
    report["_metrics"] = metrics
    return report


# --------------------------------------------------------------------------
# Command line
# --------------------------------------------------------------------------

def fail(msg, code):
    sys.stderr.write(json.dumps({"error": msg}) + "\n")
    sys.stderr.flush()
    return code


def out_bytes(s):
    sys.stdout.buffer.write(s.encode("utf-8", errors="replace"))
    sys.stdout.buffer.flush()


def main(argv):
    clean = False
    ci = False
    operands = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            out_bytes(USAGE)
            return 0
        if a == "--":
            operands.extend(argv[i + 1:])
            break
        if a == "--clean":
            clean = True
        elif a == "--ci":
            ci = True
        elif a.startswith("-") and a != "-":
            return fail("unknown option %s (see --help)" % a, 2)
        else:
            operands.append(a)
        i += 1
    try:
        if operands:
            target = operands[-1]
            if len(operands) > 1:
                sys.stderr.write("note: %d files given; only the last file was scanned (%s); the first operand %s "
                                 "was not scanned\n" % (len(operands), target, operands[0]))
            text = extract_path(target)
        else:
            raw = sys.stdin.buffer.read()
            text = decode_bytes(raw)
    except InputError as e:
        return fail(str(e), 1)
    except Exception as e:
        return fail("cannot read input: %s" % e, 1)
    if not text.strip():
        return fail("empty input", 1)
    if clean:
        out_bytes(clean_text(text))
        return 0
    rep = build_report(text, ci)
    out_bytes(json.dumps(rep, ensure_ascii=False, indent=2) + "\n")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except BrokenPipeError:
        sys.exit(0)
    except Exception as exc:  # never a traceback
        sys.exit(fail("cannot read input: %s" % exc, 1))
