#!/usr/bin/env node
'use strict';
// Post-tool-use hook: scores a just-saved prose file and nudges when flagged.
const fs = require('fs');
const path = require('path');
const lib = require('./lib');

const TOOLS = new Set(['write', 'edit', 'multiedit', 'notebookedit', 'apply_patch']);
const INSTR = new Set(['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md']);
const INSTR_STEMS = new Set(['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory']);
const MAX_PATHS = 16;

function patchPaths(body) {
  const out = [];
  if (typeof body !== 'string') return out;
  for (const line of body.split(/\r?\n/)) {
    const m = /^\*\*\* (Add File|Update File|Move to):(.*)$/.exec(line);
    if (m) {
      const p = m[2].trim();
      if (p) out.push(p);
    }
  }
  return out;
}

function collectPaths(payload) {
  const ti = payload.tool_input && typeof payload.tool_input === 'object' ? payload.tool_input : {};
  const tool = typeof payload.tool_name === 'string' ? payload.tool_name.toLowerCase() : '';
  if (tool && !TOOLS.has(tool)) return [];
  const out = [];
  const add = (p) => { if (typeof p === 'string' && p.trim()) out.push(p.trim()); };
  add(ti.file_path);
  add(ti.notebook_path);
  if (tool === 'apply_patch' || !tool) {
    for (const k of ['command', 'patch', 'input']) {
      for (const p of patchPaths(ti[k])) add(p);
    }
  }
  const seen = new Set();
  const uniq = [];
  for (const p of out) {
    if (!seen.has(p)) { seen.add(p); uniq.push(p); }
  }
  return uniq.slice(0, MAX_PATHS);
}

function inside(child, parent) {
  const rel = path.relative(parent, child);
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}

function skipPath(abs) {
  const parts = abs.split(path.sep);
  if (parts.includes('node_modules') || parts.includes('.git')) return true;
  const root = path.resolve(lib.pluginRoot());
  if (inside(abs, root)) return true;
  try {
    const rr = fs.realpathSync(root);
    let ra = abs;
    try { ra = fs.realpathSync(abs); } catch (e) { /* keep */ }
    if (inside(ra, rr)) return true;
  } catch (e) { /* ignore */ }
  return false;
}

function instructionFile(base) {
  const b = base.toLowerCase();
  if (INSTR.has(b)) return true;
  const ext = path.extname(b);
  const stem = ext ? b.slice(0, -ext.length) : b;
  if (INSTR_STEMS.has(stem) && !(lib.PLAIN_EXT.has(ext) || lib.ZIP_EXT.has(ext) || lib.NB_EXT.has(ext))) return true;
  if (INSTR_STEMS.has(b)) return true;
  return false;
}

function handle(file, level, sid) {
  const base = path.basename(file);
  if (instructionFile(base)) return null;
  if (skipPath(file)) return null;
  const ext = path.extname(file).toLowerCase();
  const eligible = lib.PLAIN_EXT.has(ext) || lib.ZIP_EXT.has(ext) || lib.NB_EXT.has(ext);
  const binary = ext === '.pdf' || ext === '.rtf';
  if (!eligible && !binary) return null;
  let st;
  try {
    st = fs.statSync(file);
  } catch (e) {
    lib.addLedger(sid, { base, kind: 'failed', reason: 'the file could not be read' });
    return null;
  }
  if (!st.isFile()) return null;
  if (binary) {
    lib.addLedger(sid, { base, kind: 'binary' });
    return null;
  }
  const archive = lib.extKind(file) === 'archive';
  const cap = archive ? lib.ARCHIVE_CAP : lib.PLAIN_CAP;
  if (st.size > cap) {
    lib.addLedger(sid, { base, kind: 'skipped', capKB: cap / 1024 });
    return null;
  }
  const det = lib.detectorPath();
  if (!det) {
    lib.addLedger(sid, { base, kind: 'failed', reason: 'the bundled detector is missing' });
    return null;
  }
  const r = lib.runPython([det, file], { timeout: archive ? 15000 : 8000 });
  const fail = (reason) => { lib.addLedger(sid, { base, kind: 'failed', reason }); return null; };
  if (r.kind === 'nopython') return fail('Python cannot be found');
  if (r.kind === 'timeout') return fail('the detector timed out');
  if (r.kind !== 'ok' || r.status !== 0 || !r.stdout.trim()) {
    return fail('the detector produced no output or exited without a usable result');
  }
  const pr = lib.parseReport(r.stdout);
  if (pr.error === 'text') return fail('the detector printed text that is not a structured report');
  if (pr.error === 'noscore') return fail('the report has no numeric score');
  const rep = pr.report;
  const m = rep._metrics;
  const score = Math.round(m.ai_tell_score);
  const band = String(m.ai_tell_band);
  const threshold = level === 'strict' ? 20 : 40;
  const flagged = score > threshold;
  const truncated = m.truncated === true;
  const fs_ = lib.findings(rep);
  fs_.sort((a, b) => {
    const wa = lib.ADVICE.has(a.num) ? 0 : 1;
    const wb = lib.ADVICE.has(b.num) ? 0 : 1;
    return wb - wa || b.count - a.count;
  });
  const labels = [];
  for (const f of fs_) if (!labels.includes(f.label)) labels.push(f.label);
  const top = labels.slice(0, 5);
  lib.addLedger(sid, { base, kind: 'scored', score, band, labels: top, flagged, truncated });
  if (!flagged) return null;
  const cov = truncated ? ', first ' + lib.WINDOW_STR + ' characters only' : '';
  let line = 'prosecheck: ' + base + ' ' + lib.phrase(band) + ' (score ' + score + ', band ' + band + cov +
    '). Flagged: ' + top.join('; ') + '. Please fix the flagged spans, keeping sentence-length variation.';
  if (truncated) {
    line += ' Only the first ' + lib.WINDOW_STR + ' characters were scanned; text beyond that prefix was not included.';
  }
  return line;
}

function main() {
  try {
    const payload = lib.readPayload();
    const level = lib.getLevel();
    if (level !== 'full' && level !== 'strict') return;
    const sid = typeof payload.session_id === 'string' ? payload.session_id : '';
    const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd();
    const lines = [];
    for (const p of collectPaths(payload)) {
      const abs = path.resolve(cwd, p);
      try {
        const l = handle(abs, level, sid);
        if (l) lines.push(l);
      } catch (e) { /* ignore this file */ }
    }
    if (lines.length) process.stdout.write(lib.hookEnvelope('PostToolUse', lines.join('\n')));
  } catch (e) { /* never fail the host */ }
}
main();
process.exitCode = 0;
