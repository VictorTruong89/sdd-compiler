#!/usr/bin/env node
'use strict';
// Session statistics: token figures and the score of the session's own prose.
const fs = require('fs');
const path = require('path');
const lib = require('./lib');

function newestTranscript(dir) {
  let best = null;
  const walk = (d, depth) => {
    let ents;
    try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { return; }
    for (const e of ents) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) {
        if (depth < 6) walk(p, depth + 1);
      } else if (e.isFile() && e.name.endsWith('.jsonl')) {
        try {
          const st = fs.statSync(p);
          if (!best || st.mtimeMs > best.mtime) best = { file: p, mtime: st.mtimeMs };
        } catch (e2) { /* ignore */ }
      }
    }
  };
  walk(dir, 0);
  return best;
}

function pickTranscript(named) {
  const newest = newestTranscript(path.join(lib.configDir(), 'projects'));
  if (typeof named === 'string' && named) {
    let st = null;
    try { st = fs.statSync(named); } catch (e) { st = null; }
    if (!st || !st.isFile()) return named; // unreadable; reported as missing
    if (newest && newest.mtime > st.mtimeMs) return newest.file;
    return named;
  }
  return newest ? newest.file : null;
}

function stripFences(t) {
  const out = [];
  let fence = null;
  for (const line of t.split('\n')) {
    if (fence) {
      const m = /^ {0,3}(`{3,}|~{3,})[ \t]*$/.exec(line);
      if (m && m[1][0] === fence.ch && m[1].length >= fence.len) fence = null;
      continue;
    }
    const m = /^ {0,3}(`{3,}|~{3,})(.*)$/.exec(line);
    if (m && !(m[1][0] === '`' && m[2].includes('`'))) {
      fence = { ch: m[1][0], len: m[1].length };
      continue;
    }
    out.push(line);
  }
  return out.join('\n');
}

function fmt(n) { return String(n); }

function statsReply(payload) {
  const level = lib.getLevel();
  const file = pickTranscript(payload.transcript_path);
  const missing = 'prosecheck stats: no readable transcript was found, so no session figures are available. ' +
    'Current ' + 'level: ' + level;
  if (!file) return missing;
  let raw;
  try { raw = fs.readFileSync(file, 'utf8'); } catch (e) { return missing; }
  const msgs = new Map();
  let anon = 0;
  const texts = [];
  for (const line of raw.split('\n')) {
    if (!line.trim()) continue;
    let j;
    try { j = JSON.parse(line); } catch (e) { continue; }
    if (!j || typeof j !== 'object' || j.type !== 'assistant') continue;
    const msg = j.message;
    if (!msg || typeof msg !== 'object') continue;
    const id = typeof msg.id === 'string' && msg.id ? msg.id : '#anon' + (anon++);
    const u = msg.usage && typeof msg.usage === 'object' ? msg.usage : {};
    const o = typeof u.output_tokens === 'number' ? u.output_tokens : 0;
    const c = typeof u.cache_read_input_tokens === 'number' ? u.cache_read_input_tokens : 0;
    const prev = msgs.get(id) || { o: 0, c: 0 };
    msgs.set(id, { o: Math.max(prev.o, o), c: Math.max(prev.c, c) });
    if (Array.isArray(msg.content)) {
      for (const b of msg.content) {
        if (b && typeof b === 'object' && b.type === 'text' && typeof b.text === 'string') texts.push(b.text);
      }
    } else if (typeof msg.content === 'string') {
      texts.push(msg.content);
    }
  }
  let out = 0;
  let cache = 0;
  for (const v of msgs.values()) { out += v.o; cache += v.c; }
  const lines = [
    'prosecheck session stats',
    'level: ' + level,
    'assistant turns: ' + fmt(msgs.size),
    'output tokens: ' + fmt(out),
    'cache-read input tokens: ' + fmt(cache),
  ];
  let slice = stripFences(texts.join('\n\n'));
  if (slice.length > 40000) slice = slice.slice(slice.length - 40000);
  if (slice.trim().length > 200) {
    const det = lib.detectorPath();
    if (det) {
      const r = lib.runPython([det], { input: slice, timeout: 15000 });
      if (r.kind === 'ok' && r.status === 0) {
        const pr = lib.parseReport(r.stdout);
        if (pr.report) lines.push('session prose ai_tell_score: ' + Math.round(pr.report._metrics.ai_tell_score));
      }
    }
  }
  return lines.join('\n');
}

module.exports = { statsReply };

if (require.main === module) {
  try {
    const payload = lib.readPayload();
    process.stdout.write(JSON.stringify({ decision: 'block', reason: statsReply(payload) }));
  } catch (e) { /* never fail the host */ }
  process.exitCode = 0;
}
