#!/usr/bin/env node
'use strict';
// Prompt-submit hook: the /prosecheck command router and the per-prompt reminder.
const fs = require('fs');
const path = require('path');
const lib = require('./lib');
const { statsReply } = require('./prosecheck-stats');

const SUBS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];

function block(reason) {
  process.stdout.write(JSON.stringify({ decision: 'block', reason }));
}

function helpReply() {
  const level = lib.getLevel();
  return [
    'prosecheck level: ' + level,
    'Code, commits, config, and chat are never touched; only prose deliverables are shaped and scored.',
    '',
    '/prosecheck lite - turn on the writing contract without scoring saved files',
    '/prosecheck full - writing contract plus the saved-file guard, threshold 40 (default)',
    '/prosecheck strict - guard threshold 20, and adds the cleanup scrub',
    '/prosecheck off - disable prosecheck',
    '/prosecheck on - re-enable prosecheck at the default level',
    '/prosecheck status - show the current level',
    '/prosecheck show - list the files scored in this session',
    '/prosecheck check <file> - score one file (report only, no rewrite)',
    '/prosecheck doctor - health check of the install',
    '/prosecheck stats - session token figures and the score of the session prose',
    '/prosecheck init - export the writing contract to AGENTS.md for other agents',
    '',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
  ].join('\n');
}

function stripPathArg(a) {
  let s = (a || '').trim();
  if (s.startsWith('@')) s = s.slice(1).trim();
  if (s.length >= 2 && (s[0] === '"' || s[0] === "'") && s[s.length - 1] === s[0]) s = s.slice(1, -1);
  if (s.startsWith('@')) s = s.slice(1);
  return s.trim();
}

function checkReply(arg) {
  const p = stripPathArg(arg);
  if (!p) {
    return 'prosecheck check needs a file path, for example: /prosecheck check notes.md. It reports on the file and never changes it.';
  }
  const abs = path.resolve(process.cwd(), p);
  const base = path.basename(abs);
  let st;
  try { st = fs.statSync(abs); } catch (e) { return 'prosecheck: cannot read ' + p; }
  if (!st.isFile()) return 'prosecheck: not a file: ' + p;
  const ext = path.extname(abs).toLowerCase();
  if (ext === '.pdf' || ext === '.rtf') return 'prosecheck: ' + base + ' has no readable text for scoring (pdf and rtf are not scored).';
  const archive = lib.extKind(abs) === 'archive';
  const cap = archive ? lib.ARCHIVE_CAP : lib.PLAIN_CAP;
  if (st.size > cap) {
    return 'prosecheck: ' + base + ' is over ' + (cap / 1024) + ' KB, so it was not scored.';
  }
  const det = lib.detectorPath();
  if (!det) return 'prosecheck: detector unavailable (the bundled detector script is missing).';
  const r = lib.runPython([det, abs], { timeout: archive ? 15000 : 8000 });
  if (r.kind === 'nopython') return 'prosecheck: detector unavailable (Python could not be launched).';
  if (r.kind === 'timeout') return 'prosecheck: ' + base + ' failed: the detector timed out.';
  if (r.kind !== 'ok') return 'prosecheck: ' + base + ' failed: the detector could not run.';
  if (r.status !== 0) {
    const err = (r.stderr || '').trim();
    return 'prosecheck: ' + base + ' failed: ' + (err || 'the detector exited with a failure and gave no message');
  }
  if (!r.stdout.trim()) return 'prosecheck: ' + base + ' - no report was produced by the detector.';
  const pr = lib.parseReport(r.stdout);
  if (!pr.report) return 'prosecheck: no report - the detector printed text that is not a report.';
  const rep = pr.report;
  const m = rep._metrics;
  const score = Math.round(m.ai_tell_score);
  const band = String(m.ai_tell_band);
  const lines = [];
  lines.push(base + ' - ' + lib.phrase(band) + ' (score ' + score + '/100, band: ' + band + ')');
  let conf = 'confidence: ' + m.confidence;
  if (m.confidence !== 'high' && m.confidence_reason) conf += ' - ' + m.confidence_reason;
  lines.push(conf);
  if (m.truncated === true) {
    lines.push('coverage: first ' + lib.WINDOW_STR + ' characters only (text beyond that prefix was not included)');
  }
  const fs_ = lib.findings(rep);
  if (!fs_.length) {
    lines.push('tells: none');
  } else {
    fs_.sort((a, b) => b.count - a.count);
    lines.push('tells: ' + fs_.slice(0, 8).map((f) => f.label + ' (x' + f.count + ')').join('; '));
  }
  lines.push('This is a report only; the file was not changed.');
  return lines.join('\n');
}

function doctorReply(form) {
  const level = lib.getLevel();
  const lines = [];
  const det = lib.detectorPath();
  const checks = [];
  // 1 mode
  if (level === 'off') {
    lines.push('[--] mode: off - prosecheck is switched off; /prosecheck on turns it back on');
  } else {
    lines.push('[OK] mode: ' + level);
    checks.push(true);
  }
  const modeOk = level !== 'off';
  // 2 detector
  const detOk = !!det;
  lines.push(detOk ? '[OK] detector: bundled detector found in the plugin tree'
    : '[!!] detector: bundled detector is missing from the plugin tree');
  // 3 python
  let pyOk = false;
  const probe = lib.runPython(['--version'], { timeout: 10000 });
  if (probe.kind === 'nopython') {
    lines.push('[!!] python not found - the writing contract still applies to new prose, but saved files are not re-scored until Python is available');
  } else if (!det) {
    lines.push('[!!] python runs, but it cannot run the bundled detector because that file is missing');
  } else {
    const sample = 'The committee met on Tuesday to review the budget. Members argued about the roof repair for an hour, ' +
      'and the treasurer produced receipts. By evening they had agreed to postpone the vote until the spring.\n';
    const r = lib.runPython([det], { input: sample, timeout: 15000 });
    const pr = r.kind === 'ok' && r.status === 0 ? lib.parseReport(r.stdout) : { error: 'x' };
    if (pr.report) {
      pyOk = true;
      lines.push('[OK] python ran the bundled detector and got a numeric score');
    } else {
      lines.push('[!!] python ran the bundled detector but the result was not a numeric score');
    }
  }
  // 4 settings
  let setOk = false;
  try {
    const dir = lib.configDir();
    fs.mkdirSync(dir, { recursive: true });
    const probeFile = path.join(dir, '.prosecheck-doctor-probe-' + process.pid);
    fs.writeFileSync(probeFile, 'x');
    fs.unlinkSync(probeFile);
    setOk = true;
  } catch (e) { setOk = false; }
  lines.push(setOk ? '[OK] settings folder is writable' : '[!!] settings folder is not writable');
  let closer;
  const othersOk = detOk && pyOk && setOk;
  if (modeOk && othersOk) {
    closer = 'prosecheck is active. Plain text up to 512 KB and archives up to 4 MB are scored, reading the first ' +
      lib.WINDOW_STR + ' characters. Use ' + form + ' show to see files that were only partly scanned or skipped.';
  } else if (!modeOk && othersOk) {
    closer = 'The install is healthy, but prosecheck is off, so saved files are not scored while it stays off. Use ' + form +
      ' on to turn it back on.';
  } else {
    closer = 'Please fix the faulty checks above, then run /prosecheck doctor again.';
  }
  return ['prosecheck health check', ...lines, closer].join('\n');
}

function showReply(sid) {
  const rows = lib.readLedger(sid);
  if (!rows.length) {
    return 'prosecheck: nothing scored yet in this session. Rows appear after prose files, including .docx and .pdf deliverables, are saved.';
  }
  const out = ['Files in this session, newest first:'];
  for (const r of rows.slice().reverse()) {
    let body;
    if (r.kind === 'scored') {
      body = lib.phrase(r.band) + ' (score ' + r.score + '/' + r.band +
        (r.truncated ? ', first ' + lib.WINDOW_STR + ' characters only' : '') + ')';
      if (Array.isArray(r.labels) && r.labels.length) {
        body += ' - ' + (r.flagged ? 'flagged' : 'under threshold') + ': ' + r.labels.slice(0, 5).join('; ');
      }
    } else if (r.kind === 'skipped') {
      body = 'not scored: larger than the ' + r.capKB + ' KB limit';
    } else if (r.kind === 'binary') {
      body = 'binary file, not re-scored';
    } else {
      body = 'not scored: ' + (r.reason || 'the check failed');
    }
    out.push('  ' + r.base + ' - ' + body);
  }
  return out.join('\n');
}

function initReply(form) {
  const level = lib.getLevel();
  if (level === 'off') {
    return 'prosecheck is switched off, so nothing was exported. Run ' + form + ' on to allow the export.';
  }
  const lines = [];
  const cwd = process.cwd();
  const agents = path.join(cwd, 'AGENTS.md');
  let existing = null;
  let readFail = false;
  try {
    if (fs.existsSync(agents)) existing = fs.readFileSync(agents, 'utf8');
  } catch (e) { readFail = true; }
  if (readFail) {
    lines.push('cannot read AGENTS.md, so the contract was not exported there.');
  } else if (existing !== null && (existing.includes(lib.CONTRACT_BEGIN) || existing.includes('Banned vocabulary: delve, tapestry'))) {
    lines.push('AGENTS.md already contains the prose contract; it was left unchanged.');
  } else {
    let next = existing === null ? '' : existing;
    if (next.length && !next.endsWith('\n')) next += '\n';
    if (next.length) next += '\n';
    next += lib.exportSection(level);
    try {
      fs.writeFileSync(agents, next);
      lines.push('AGENTS.md: wrote the prose contract for level ' + level + '.');
    } catch (e) {
      lines.push('cannot write AGENTS.md, so the contract was not exported there.');
    }
  }
  const dest = path.join(cwd, '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(dest)) {
    lines.push('.cursor/rules/prosecheck.mdc already exists; prosecheck.mdc was left unchanged.');
  } else {
    let text;
    try {
      text = fs.readFileSync(path.join(lib.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc'), 'utf8');
    } catch (e) { text = lib.cursorRuleText(); }
    try {
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.writeFileSync(dest, text);
      lines.push('Cursor rule: copied to .cursor/rules/prosecheck.mdc.');
    } catch (e) {
      lines.push('cannot write .cursor/rules/prosecheck.mdc, so the Cursor rule was not created.');
    }
  }
  return lines.join('\n');
}

function command(form, rest, payload) {
  const trimmed = (rest || '').trim();
  const mo = /^(\S+)\s*([\s\S]*)$/.exec(trimmed);
  const sub = mo ? mo[1].toLowerCase() : 'help';
  const arg = mo ? mo[2] : '';
  switch (sub) {
    case 'help': return helpReply();
    case 'status': return 'prosecheck level: ' + lib.getLevel();
    case 'lite':
      lib.storeLevel('lite');
      return 'prosecheck level set to lite: the writing contract is on and saved files are not scored.';
    case 'full':
      lib.storeLevel('full');
      return 'prosecheck level set to full: the writing contract and the saved-file guard are on.';
    case 'strict':
      lib.storeLevel('strict');
      return 'prosecheck level set to strict: the saved-file guard uses its lowest threshold.';
    case 'off':
      lib.storeLevel('off');
      return 'prosecheck is now off. The contract and the guard are disabled.';
    case 'on':
      lib.storeLevel('full');
      return 'prosecheck is on again, at level full.';
    case 'show': return showReply(typeof payload.session_id === 'string' ? payload.session_id : '');
    case 'check': return checkReply(arg);
    case 'doctor': return doctorReply(form);
    case 'stats': return statsReply(payload);
    case 'init': return initReply(form);
    default:
      return 'prosecheck: unknown subcommand "' + mo[1] + '". Valid subcommands: ' + SUBS.join(', ') + '.';
  }
}

function main() {
  try {
    const payload = lib.readPayload();
    const prompt = typeof payload.prompt === 'string' ? payload.prompt : '';
    const trimmed = prompt.trim();
    const cm = /^(\/prosecheck(?::prosecheck)?)(?=\s|$)([\s\S]*)$/i.exec(trimmed);
    if (cm) {
      const form = cm[1].toLowerCase() === '/prosecheck' ? '/prosecheck' : '/prosecheck:prosecheck';
      block(command(form, cm[2], payload));
      return;
    }
    if (/^prosecheck off$/i.test(trimmed) || /stop prosecheck/i.test(prompt)) {
      lib.storeLevel('off');
      block('prosecheck is now off. Say /prosecheck on to turn it back on.');
      return;
    }
    const level = lib.getLevel();
    if (level === 'off') return;
    process.stdout.write(lib.hookEnvelope('UserPromptSubmit',
      'prosecheck level: ' + level + '. Prose deliverables follow the writing contract; code, config, and commits are untouched.'));
  } catch (e) { /* never fail the host */ }
}
main();
process.exitCode = 0;
