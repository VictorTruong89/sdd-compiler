#!/usr/bin/env node
'use strict';
// Subagent-start hook: the same writing contract inside the subagent envelope.
const lib = require('./lib');

function main() {
  try {
    lib.readPayload();
    const level = lib.getLevel();
    if (level === 'off') return;
    process.stdout.write(lib.hookEnvelope('SubagentStart',
      lib.contractText(level, { detectorPath: lib.detectorPath() })));
  } catch (e) { /* never fail the host */ }
}
main();
process.exitCode = 0;
