#!/usr/bin/env node
'use strict';
// Session-start hook: places the writing contract in the session.
const lib = require('./lib');

function welcome() {
  return 'prosecheck is installed and on. Saved prose is scored against 71 documented patterns; plain text is ' +
    'accepted up to 512 KB and archives up to 4 MB, and the detector scores the first ' + lib.WINDOW_STR +
    ' characters. Try /prosecheck doctor, /prosecheck check <file>, /prosecheck off, or /prosecheck help. ' +
    'There is no website and no upload; nothing leaves this machine. This welcome is shown once.\n\n';
}

function main() {
  try {
    lib.readPayload();
    const first = lib.readFlag() === null;
    const level = lib.getLevel();
    lib.pruneLedgers();
    if (level !== 'off') lib.storeLevel(level);
    if (level === 'off') return;
    const out = (first ? welcome() : '') + lib.contractText(level, { detectorPath: lib.detectorPath() });
    process.stdout.write(out);
  } catch (e) { /* never fail the host */ }
}
main();
process.exitCode = 0;
