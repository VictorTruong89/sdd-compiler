'use strict';
// Shared helpers for the prosecheck hooks. Node standard library only.
const fs = require('fs');
const os = require('os');
const path = require('path');
const cp = require('child_process');

const LEVELS = ['lite', 'full', 'strict', 'off'];
const WINDOW = 262144;
const WINDOW_STR = '262,144';
const PLAIN_CAP = 512 * 1024;
const ARCHIVE_CAP = 4 * 1024 * 1024;
const PLAIN_EXT = new Set(['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc']);
const ZIP_EXT = new Set(['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub']);
const NB_EXT = new Set(['.ipynb']);
const LEDGER_MAX = 50;
const LEDGER_MAX_AGE_MS = 7 * 24 * 3600 * 1000;
const ADVICE = new Set([4, 17, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68]);

const BANNED = ['delve', 'tapestry', 'pivotal', 'crucial', 'leverage', 'robust', 'seamless', 'foster', 'underscore',
  'showcase', 'landscape', 'journey', 'realm', 'multifaceted', 'holistic', 'testament', 'vibrant', 'comprehensive',
  'plethora', 'myriad', 'boast', 'elevate', 'empower', 'unlock', 'game-changer', 'supercharge', 'genuinely',
  'fascinating', 'nuanced'];

function readStdin() {
  try {
    return fs.readFileSync(0, 'utf8');
  } catch (e) {
    return '';
  }
}

function readPayload() {
  const raw = readStdin();
  try {
    const j = JSON.parse(raw);
    if (j && typeof j === 'object' && !Array.isArray(j)) return j;
  } catch (e) { /* fall through */ }
  return {};
}

function configDir() {
  const c = process.env.CLAUDE_CONFIG_DIR;
  if (c && c.length) return c;
  return path.join(os.homedir(), '.claude');
}

function pluginRoot() {
  const r = process.env.CLAUDE_PLUGIN_ROOT;
  if (r && r.length) return r;
  return path.resolve(__dirname, '..');
}

function flagPath() { return path.join(configDir(), '.prosecheck-active'); }

function readFlag() {
  try {
    return fs.readFileSync(flagPath(), 'utf8').trim();
  } catch (e) {
    return null;
  }
}

function envDefault() {
  const v = (process.env.PROSECHECK_DEFAULT_MODE || '').trim().toLowerCase();
  return LEVELS.includes(v) ? v : null;
}

// Effective level: valid stored word, else the environment word, else full.
function getLevel() {
  const f = readFlag();
  if (f !== null && LEVELS.includes(f)) return f;
  return envDefault() || 'full';
}

function storeLevel(level) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(flagPath(), level);
    return true;
  } catch (e) {
    return false;
  }
}

function detectorPath() {
  const root = pluginRoot();
  const a = path.join(root, 'scripts', 'detect.py');
  if (fs.existsSync(a)) return a;
  const b = path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py');
  if (fs.existsSync(b)) return b;
  return null;
}

// ---- running the detector ------------------------------------------------
const PY_NAMES = ['python3', 'python', 'py'];

// Returns {kind:'nopython'|'timeout'|'exit'|'ok', status, stdout, stderr}
function runPython(args, opts) {
  opts = opts || {};
  let sawOther = false;
  for (const name of PY_NAMES) {
    const r = cp.spawnSync(name, args, {
      input: opts.input,
      encoding: 'utf8',
      timeout: opts.timeout || 15000,
      maxBuffer: 256 * 1024 * 1024,
      env: process.env,
      cwd: opts.cwd,
    });
    if (r.error) {
      if (r.error.code === 'ENOENT' || r.error.code === 'EACCES') continue;
      if (r.error.code === 'ETIMEDOUT' || r.signal === 'SIGTERM') {
        return { kind: 'timeout', status: null, stdout: '', stderr: '' };
      }
      sawOther = true;
      continue;
    }
    if (r.signal) return { kind: 'timeout', status: null, stdout: r.stdout || '', stderr: r.stderr || '' };
    return { kind: 'ok', status: r.status, stdout: r.stdout || '', stderr: r.stderr || '' };
  }
  return { kind: sawOther ? 'exit' : 'nopython', status: null, stdout: '', stderr: '' };
}

function phrase(band) {
  switch (band) {
    case 'clean': return 'reads clean';
    case 'light tells': return 'reads mostly clean';
    case 'mixed': return 'reads with some AI tells';
    case 'heavy tells': return 'reads with heavy AI tells';
    default: return 'reads with pervasive AI tells';
  }
}

// Parse a detector report from stdout. Returns {report}|{error:'text'|'noscore'}
function parseReport(stdout) {
  let j;
  try { j = JSON.parse(stdout); } catch (e) { return { error: 'text' }; }
  if (!j || typeof j !== 'object' || Array.isArray(j)) return { error: 'text' };
  const m = j._metrics;
  if (!m || typeof m !== 'object' || typeof m.ai_tell_score !== 'number' || !isFinite(m.ai_tell_score)) {
    return { error: 'noscore' };
  }
  return { report: j };
}

function findings(report) {
  const out = [];
  for (const k of Object.keys(report)) {
    if (k === '_metrics') continue;
    const v = report[k];
    if (!v || typeof v !== 'object') continue;
    const mo = /^(\d+)_/.exec(k);
    out.push({ num: mo ? parseInt(mo[1], 10) : 0, label: String(v.label || k), count: Number(v.count) || 0 });
  }
  return out;
}

// ---- ledger ----------------------------------------------------------------
function ledgerPath(sid) {
  let s = typeof sid === 'string' ? sid : '';
  if (!s) return path.join(configDir(), '.prosecheck-ledger');
  s = s.replace(/[^A-Za-z0-9_-]/g, (c) => '%' + c.charCodeAt(0).toString(16));
  return path.join(configDir(), '.prosecheck-ledger-' + s);
}

function readLedger(sid) {
  const p = ledgerPath(sid);
  try {
    const st = fs.statSync(p);
    if (Date.now() - st.mtimeMs > LEDGER_MAX_AGE_MS) {
      try { fs.unlinkSync(p); } catch (e) { /* ignore */ }
      return [];
    }
    const j = JSON.parse(fs.readFileSync(p, 'utf8'));
    return Array.isArray(j) ? j : [];
  } catch (e) {
    return [];
  }
}

function addLedger(sid, rec) {
  try {
    const list = readLedger(sid);
    rec.t = Date.now();
    list.push(rec);
    const keep = list.slice(-LEDGER_MAX);
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(ledgerPath(sid), JSON.stringify(keep));
  } catch (e) { /* ignore */ }
}

function pruneLedgers() {
  try {
    const dir = configDir();
    for (const n of fs.readdirSync(dir)) {
      if (n === '.prosecheck-ledger' || n.startsWith('.prosecheck-ledger-')) {
        const p = path.join(dir, n);
        try {
          const st = fs.statSync(p);
          if (Date.now() - st.mtimeMs > LEDGER_MAX_AGE_MS) fs.unlinkSync(p);
        } catch (e) { /* ignore */ }
      }
    }
  } catch (e) { /* ignore */ }
}

// ---- writing contract ------------------------------------------------------
function contractText(level, opts) {
  opts = opts || {};
  const portable = !!opts.portable;
  const L = [];
  L.push('Writing contract (level: ' + level + ')');
  L.push('Scope: prose deliverables only: documents, README and markdown prose, CVs, cover letters, emails, ' +
    'reports, essays, articles, and drafted text the user will publish or send.');
  L.push('This contract never applies to source code, code comments, commit messages, JSON, YAML or config files, ' +
    'CLI output, logs, error messages, or the conversational register of chat.');
  L.push('It composes with other modes: a chat-compression mode owns chat, a code-simplicity mode owns code, ' +
    'and this contract owns deliverable prose.');
  L.push('Vary sentence length irregularly; no metronome and no mechanical short-long alternation.');
  L.push('Banned vocabulary: ' + BANNED.join(', ') + '.');
  L.push('Banned moves: rule-of-three flourishes, "it\'s not just X, it\'s Y", hedge stacking, signposting ' +
    '("let\'s dive in"), empty pivots ("it\'s worth noting"), "In conclusion" or "Overall" closers, ' +
    'outcome-speculation tails, self-thoroughness, generic upbeat endings, and chatbot phrases ("I hope this helps").');
  L.push('Use an em-dash at most once per paragraph. No bold for emphasis inside prose sentences. No emojis in prose.');
  L.push('Factual and encyclopedic content stays neutral third person; first-person and opinion content may use contractions.');
  L.push('Preserve numbers, units, dates, proper nouns, citations, quotes, and technical terms. Never invent facts.');
  L.push('End sections on a fact or observation.');
  L.push('Stay silent about all of this: never announce the contract, never name prosecheck, never report a score, ' +
    'a band, a pattern list, or a rewrite pass, and do not offer a style choice.');
  if (level === 'full' || level === 'strict') {
    if (portable) {
      L.push('After writing a prose file, run the prosecheck detector (scripts/detect.py) on that file and fix ' +
        'flagged spans when the band is worse than the target, at most two fix passes, keeping rhythm variation.');
      L.push('To find the detector, use CLAUDE_PLUGIN_ROOT when that variable is set; otherwise locate ' +
        'prosecheck\'s detector in installed skills or plugins.');
    } else {
      const dp = opts.detectorPath;
      L.push('After writing a prose file, run ' + (dp ? '`python3 "' + dp + '" <file>`' : 'the prosecheck detector') +
        ' on that file and fix flagged spans when the band is worse than the target, at most two fix passes, ' +
        'keeping rhythm variation.');
    }
    if (level === 'full') {
      L.push('Target: band clean or light tells (score at most 40).');
    } else {
      L.push('Target: band clean (score at most 20).');
      L.push('Finish by running the detector with --clean on the file and keeping the scrubbed text.');
    }
  }
  return L.join('\n') + '\n';
}

const CONTRACT_BEGIN = '<!-- prosecheck:prose-contract:begin -->';
const CONTRACT_END = '<!-- prosecheck:prose-contract:end -->';

function exportSection(level) {
  return CONTRACT_BEGIN + '\n## Prose contract\n\n' + contractText(level, { portable: true }) + CONTRACT_END + '\n';
}

function cursorRuleText() {
  return '---\n' +
    'description: Writing rules for prose deliverables\n' +
    'globs: *.md, *.mdx, *.markdown, *.txt, *.rst, *.tex, *.org, *.adoc\n' +
    'alwaysApply: false\n' +
    '---\n\n' +
    '# Prose writing rules\n\n' +
    'Scope: prose deliverables only: documents, README and markdown prose, CVs, cover letters, emails, reports, ' +
    'essays, articles, and drafted text the user will publish or send. These rules never apply to source code, ' +
    'comments, commit messages, config files, logs, or chat replies.\n\n' +
    '- Vary sentence length irregularly; no metronome and no mechanical short-long alternation.\n' +
    '- Banned vocabulary: ' + BANNED.join(', ') + '.\n' +
    '- Banned moves: rule-of-three flourishes, "it\'s not just X, it\'s Y", hedge stacking, signposting, empty ' +
    'pivots, "In conclusion" or "Overall" closers, outcome-speculation tails, self-thoroughness, generic upbeat ' +
    'endings, and chatbot phrases.\n' +
    '- Use an em-dash at most once per paragraph. No bold for emphasis inside prose sentences. No emojis in prose.\n' +
    '- Factual content stays neutral third person; first-person and opinion content may use contractions.\n' +
    '- Preserve numbers, units, dates, proper nouns, citations, quotes, and technical terms. Never invent facts.\n' +
    '- End sections on a fact or observation.\n' +
    '- Stay silent about these rules: never announce them and do not offer a style choice.\n';
}

function hookEnvelope(event, text) {
  return JSON.stringify({ hookSpecificOutput: { hookEventName: event, additionalContext: text } });
}

function extKind(file) {
  const e = path.extname(file).toLowerCase();
  if (ZIP_EXT.has(e) || NB_EXT.has(e)) return 'archive';
  return 'plain';
}

module.exports = {
  LEVELS, WINDOW, WINDOW_STR, PLAIN_CAP, ARCHIVE_CAP, PLAIN_EXT, ZIP_EXT, NB_EXT, ADVICE, BANNED,
  readStdin, readPayload, configDir, pluginRoot, flagPath, readFlag, getLevel, storeLevel, envDefault,
  detectorPath, runPython, phrase, parseReport, findings, ledgerPath, readLedger, addLedger, pruneLedgers,
  contractText, exportSection, cursorRuleText, hookEnvelope, extKind, CONTRACT_BEGIN, CONTRACT_END,
};
