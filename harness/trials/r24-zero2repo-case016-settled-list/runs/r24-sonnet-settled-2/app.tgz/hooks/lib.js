'use strict';
// Shared helpers for the prosecheck hooks. Standard library only.
const fs = require('fs');
const os = require('os');
const path = require('path');
const cp = require('child_process');

const WINDOW = 262144;
const WINDOW_TXT = '262,144';
const PLAIN_CAP_KB = 512;
const ARCHIVE_CAP_KB = 4096;
const PLAIN_CAP = PLAIN_CAP_KB * 1024;
const ARCHIVE_CAP = ARCHIVE_CAP_KB * 1024;
const LEVELS = ['lite', 'full', 'strict', 'off'];
const PLAIN_EXT = ['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'];
const ARCHIVE_EXT = ['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub', '.ipynb'];
const LEDGER_MAX = 50;
const LEDGER_AGE_MS = 7 * 24 * 3600 * 1000;

function readStdin() {
  try { return fs.readFileSync(0, 'utf8'); } catch (e) { return ''; }
}
function parseInput() {
  const s = readStdin();
  try {
    const v = JSON.parse(s.replace(/^﻿/, ''));
    return v && typeof v === 'object' && !Array.isArray(v) ? v : {};
  } catch (e) { return {}; }
}
function configDir() {
  const c = process.env.CLAUDE_CONFIG_DIR;
  if (c) return c;
  return path.join(os.homedir(), '.claude');
}
function pluginRoot() {
  const r = process.env.CLAUDE_PLUGIN_ROOT;
  if (r) return r;
  return path.resolve(__dirname, '..');
}
function flagPath() { return path.join(configDir(), '.prosecheck-active'); }
function readStored() {
  try {
    const v = fs.readFileSync(flagPath(), 'utf8').trim();
    return LEVELS.indexOf(v) >= 0 ? v : null;
  } catch (e) { return null; }
}
function flagExists() {
  try { fs.accessSync(flagPath()); return true; } catch (e) { return false; }
}
function envLevel() {
  const v = (process.env.PROSECHECK_DEFAULT_MODE || '').trim();
  return LEVELS.indexOf(v) >= 0 ? v : null;
}
function level() { return readStored() || envLevel() || 'full'; }
function storeLevel(l) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(flagPath(), l);
    return true;
  } catch (e) { return false; }
}
function findDetector() {
  const root = pluginRoot();
  const a = path.join(root, 'scripts', 'detect.py');
  const b = path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py');
  for (const p of [a, b]) {
    try { if (fs.statSync(p).isFile()) return p; } catch (e) { /* next */ }
  }
  return null;
}

// ---- detector runs -------------------------------------------------------
function runPython(args, input, timeoutMs) {
  const names = ['python3', 'python', 'py'];
  let last = null;
  for (const n of names) {
    const opts = { encoding: 'utf8', timeout: timeoutMs, maxBuffer: 64 * 1024 * 1024 };
    if (input !== undefined) opts.input = input;
    const r = cp.spawnSync(n, args, opts);
    if (r.error && (r.error.code === 'ENOENT' || r.error.code === 'EACCES')) { last = r; continue; }
    return r;
  }
  return { error: { code: 'ENOENT' }, status: null, stdout: '', stderr: '', notfound: true, last };
}
// Returns {kind: ok|nopython|timeout|failed|empty|unusable|noscore|nodetector, report, stderr}
function classify(r) {
  if (r.notfound || (r.error && r.error.code === 'ENOENT')) return { kind: 'nopython' };
  if (r.error && (r.error.code === 'ETIMEDOUT' || r.signal === 'SIGTERM')) return { kind: 'timeout' };
  if (r.error) return { kind: 'failed', stderr: String(r.error.message || r.error) };
  if (r.status !== 0) return { kind: 'failed', stderr: (r.stderr || '').trim() };
  const out = (r.stdout || '').trim();
  if (!out) return { kind: 'empty' };
  let rep;
  try { rep = JSON.parse(out); } catch (e) { return { kind: 'unusable' }; }
  if (!rep || typeof rep !== 'object' || !rep._metrics || typeof rep._metrics !== 'object') return { kind: 'unusable' };
  if (typeof rep._metrics.ai_tell_score !== 'number') return { kind: 'noscore', report: rep };
  return { kind: 'ok', report: rep };
}
function runDetectorFile(file, timeoutMs) {
  const det = findDetector();
  if (!det) return { kind: 'nodetector' };
  return classify(runPython([det, file], undefined, timeoutMs));
}
function runDetectorText(text, timeoutMs) {
  const det = findDetector();
  if (!det) return { kind: 'nodetector' };
  return classify(runPython([det], text, timeoutMs));
}
function findings(rep) {
  const out = [];
  for (const k of Object.keys(rep)) {
    if (k === '_metrics') continue;
    const v = rep[k];
    if (v && typeof v === 'object' && typeof v.label === 'string') out.push({ label: v.label, count: Number(v.count) || 0 });
  }
  out.sort((a, b) => b.count - a.count);
  return out;
}

// ---- phrases -------------------------------------------------------------
function phrase(band) {
  switch (band) {
    case 'clean': return 'reads clean';
    case 'light tells': return 'reads mostly clean';
    case 'mixed': return 'reads with some AI tells';
    case 'heavy tells': return 'reads with heavy AI tells';
    default: return 'reads with pervasive AI tells';
  }
}

// ---- ledger --------------------------------------------------------------
function ledgerFile(sessionId) {
  const dir = configDir();
  if (!sessionId || typeof sessionId !== 'string') return path.join(dir, '.prosecheck-ledger');
  let safe = sessionId.replace(/[^A-Za-z0-9_.]/g, '_');
  if (safe !== sessionId || safe.length > 80) {
    safe = safe.slice(0, 60) + '_' + Buffer.from(sessionId).toString('hex').slice(0, 24);
  }
  return path.join(dir, '.prosecheck-ledger-' + safe);
}
function readLedger(sessionId) {
  const f = ledgerFile(sessionId);
  try {
    const st = fs.statSync(f);
    if (Date.now() - st.mtimeMs > LEDGER_AGE_MS) {
      try { fs.unlinkSync(f); } catch (e) { /* ignore */ }
      return [];
    }
    const v = JSON.parse(fs.readFileSync(f, 'utf8'));
    return Array.isArray(v) ? v : [];
  } catch (e) { return []; }
}
function appendLedger(sessionId, rec) {
  try {
    const recs = readLedger(sessionId);
    recs.push(Object.assign({ t: Date.now() }, rec));
    const keep = recs.slice(-LEDGER_MAX);
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(ledgerFile(sessionId), JSON.stringify(keep));
  } catch (e) { /* never fail the host */ }
}
function pruneLedgers() {
  try {
    const dir = configDir();
    for (const n of fs.readdirSync(dir)) {
      if (n === '.prosecheck-ledger' || n.indexOf('.prosecheck-ledger-') === 0) {
        const f = path.join(dir, n);
        try {
          if (Date.now() - fs.statSync(f).mtimeMs > LEDGER_AGE_MS) fs.unlinkSync(f);
        } catch (e) { /* ignore */ }
      }
    }
  } catch (e) { /* ignore */ }
}

// ---- writing contract ----------------------------------------------------
const BANNED = ['delve', 'tapestry', 'pivotal', 'crucial', 'leverage', 'robust', 'seamless', 'foster', 'underscore',
  'showcase', 'landscape', 'journey', 'realm', 'multifaceted', 'holistic', 'testament', 'vibrant', 'comprehensive',
  'plethora', 'myriad', 'boast', 'elevate', 'empower', 'unlock', 'game-changer', 'supercharge', 'genuinely',
  'fascinating', 'nuanced'];

function contract(lvl, opts) {
  opts = opts || {};
  const L = [];
  L.push('# Prose contract (prosecheck, level ' + lvl + ')');
  L.push('');
  L.push('Scope: prose deliverables only (documents, README and markdown prose, CVs, cover letters, emails, reports, essays, articles, and any drafted text the user will publish or send).');
  L.push('This contract never touches code comments, commit messages, JSON, YAML or other config, CLI output, logs, error messages, or the conversational register of chat. A chat-compression mode owns chat, a code-simplicity mode owns code, and this contract owns deliverable prose.');
  L.push('');
  L.push('Rules for prose deliverables:');
  L.push('- Vary sentence length irregularly. No metronome, and no mechanical short-long alternation.');
  L.push('- Banned vocabulary: ' + BANNED.join(', ') + '.');
  L.push('- Banned moves: rule-of-three flourishes, "it\'s not just X, it\'s Y", hedge stacking, signposting ("let\'s dive in"), empty pivots ("it\'s worth noting"), "In conclusion" and "Overall" closers, outcome-speculation tails, self-thoroughness, generic upbeat endings, and chatbot phrases ("I hope this helps").');
  L.push('- Use an em dash at most once per paragraph. No bold for emphasis inside prose sentences. No emojis in prose.');
  L.push('- Factual and encyclopedic content stays neutral third person. First-person and opinion content may use contractions.');
  L.push('- Preserve numbers, units, dates, proper nouns, citations, quotes, and technical terms. Never invent facts.');
  L.push('- End sections on a fact or an observation.');
  L.push('- Stay silent about this contract: never announce it, never name the tool, never report a score, a band, a pattern list, or a rewrite pass, and do not offer a style choice.');
  if (lvl === 'full' || lvl === 'strict') {
    L.push('');
    if (opts.portable) {
      L.push('Detector: use scripts/detect.py under CLAUDE_PLUGIN_ROOT when that variable is set; otherwise locate prosecheck\'s detector in the installed skills and plugins.');
    } else if (opts.detector) {
      L.push('Detector: python3 ' + opts.detector);
    }
    if (lvl === 'full') {
      L.push('After writing a prose file, run the detector on that file. If the score is above 40 (the band is worse than light tells), fix the flagged spans, at most two fix passes, keeping rhythm variation.');
      L.push('Target: band clean or light tells, a score of 40 or less.');
    } else {
      L.push('After writing a prose file, run the detector on that file. If the score is above 20 (the band is worse than clean), fix the flagged spans, at most two fix passes, keeping rhythm variation.');
      L.push('Target: the clean band, a score of 20 or less.');
      L.push('Finish by running the detector with --clean on the file and keeping the scrubbed text.');
    }
  }
  return L.join('\n');
}

function welcome() {
  return [
    'prosecheck is installed and on. This welcome is shown once.',
    'Saved prose is scored against 71 documented AI-writing patterns. Plain text is accepted up to 512 KB and archives (docx, pptx, xlsx, odt, epub, ipynb) up to 4 MB; the detector scores the first 262,144 characters.',
    'There is no website and no upload: everything runs on this machine.',
    'Commands: /prosecheck doctor checks the install, /prosecheck check scores one file, /prosecheck off switches the tool off, /prosecheck help lists everything.',
    ''
  ].join('\n');
}

function cursorRule() {
  return [
    '---',
    'description: Writing rules for prose deliverables',
    'globs: *.md,*.mdx,*.markdown,*.txt,*.rst,*.tex,*.org,*.adoc',
    'alwaysApply: false',
    '---',
    '',
    '# Prose rules',
    '',
    'These rules cover prose deliverables only: documents, README prose, CVs, cover letters, emails, reports, essays, and articles. They never touch code comments, commit messages, config, CLI output, logs, error messages, or chat.',
    '',
    '- Vary sentence length irregularly. No metronome, and no mechanical short-long alternation.',
    '- Banned vocabulary: ' + BANNED.join(', ') + '.',
    '- Banned moves: rule-of-three flourishes, "it\'s not just X, it\'s Y", hedge stacking, signposting, empty pivots, "In conclusion" closers, outcome-speculation tails, self-thoroughness, generic upbeat endings, and chatbot phrases.',
    '- Use an em dash at most once per paragraph. No bold for emphasis inside prose sentences. No emojis in prose.',
    '- Factual content stays neutral third person. First-person and opinion content may use contractions.',
    '- Preserve numbers, units, dates, proper nouns, citations, quotes, and technical terms. Never invent facts.',
    '- End sections on a fact or an observation.',
    '- Stay silent about these rules: never announce them and never report scores.',
    ''
  ].join('\n');
}

function isProseExt(ext) {
  ext = ext.toLowerCase();
  return PLAIN_EXT.indexOf(ext) >= 0 || ARCHIVE_EXT.indexOf(ext) >= 0;
}

module.exports = {
  fs, os, path, cp, WINDOW, WINDOW_TXT, PLAIN_CAP_KB, ARCHIVE_CAP_KB, PLAIN_CAP, ARCHIVE_CAP, LEVELS, PLAIN_EXT, ARCHIVE_EXT,
  readStdin, parseInput, configDir, pluginRoot, flagPath, readStored, flagExists, envLevel, level, storeLevel,
  findDetector, runPython, classify, runDetectorFile, runDetectorText, findings, phrase,
  ledgerFile, readLedger, appendLedger, pruneLedgers, BANNED, contract, welcome, cursorRule, isProseExt
};
