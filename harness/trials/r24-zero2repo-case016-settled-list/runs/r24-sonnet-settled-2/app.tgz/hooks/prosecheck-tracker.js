'use strict';
const L = require('./lib');
const stats = require('./prosecheck-stats');
const { fs, path } = L;

const SUBS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];

function block(reason) {
  process.stdout.write(JSON.stringify({ decision: 'block', reason }));
}

function helpText(lvl) {
  return [
    'prosecheck is at level ' + lvl + '.',
    'It shapes prose deliverables only. It never touches code, commits, config, or chat.',
    '',
    '/prosecheck lite - turn on the writing contract only, with no scoring of saved files',
    '/prosecheck full - the contract plus the saved-file guard, threshold 40 (default)',
    '/prosecheck strict - the contract plus a stricter guard, threshold 20, and a final scrub',
    '/prosecheck off | on - disable the tool, or re-enable it',
    '/prosecheck status - report the current level',
    '/prosecheck show - list the files scored in this session',
    '/prosecheck check <file> - score one file and print a report, no rewrite',
    '/prosecheck doctor - install health check',
    '/prosecheck stats - token use and the prose score of this session',
    '/prosecheck init - export the contract to AGENTS.md for other agents',
    '',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".'
  ].join('\n');
}

function parseCheckPath(rest) {
  let s = rest.trim();
  if (!s) return '';
  if (s[0] === '@') s = s.slice(1).trim();
  const q = s[0];
  if (q === '"' || q === "'") {
    const e = s.indexOf(q, 1);
    if (e > 0) return s.slice(1, e);
    return s.slice(1);
  }
  return s;
}

function noInts(s) { return s; }

function checkReply(rest, cwd) {
  const arg = parseCheckPath(rest);
  if (!arg) return 'check needs a file path. Usage: /prosecheck check <file>. It prints a report only and never rewrites the file.';
  const file = path.isAbsolute(arg) ? arg : path.resolve(cwd, arg);
  const base = path.basename(file);
  let st;
  try { st = fs.statSync(file); } catch (e) { return 'cannot read ' + arg + ' (no such file or no access).'; }
  if (st.isDirectory()) return arg + ' is not a file.';
  if (!st.isFile()) return arg + ' is not a file.';
  const ext = path.extname(base).toLowerCase();
  if (ext === '.pdf' || ext === '.rtf') return base + ' has no readable text: PDF and RTF are not scanned.';
  const archive = L.ARCHIVE_EXT.indexOf(ext) >= 0;
  const cap = archive ? L.ARCHIVE_CAP : L.PLAIN_CAP;
  if (st.size > cap) return base + ' is over ' + (archive ? L.ARCHIVE_CAP_KB : L.PLAIN_CAP_KB) + ' KB, so it was not scored.';
  try { fs.accessSync(file, fs.constants.R_OK); } catch (e) { return 'cannot read ' + arg + ' (no access).'; }
  const det = L.findDetector();
  if (!det) return 'detector unavailable: the bundled detector script was not found.';
  const raw = L.runPython([det, file], undefined, archive ? 15000 : 8000);
  if (raw.notfound || (raw.error && raw.error.code === 'ENOENT')) return 'detector unavailable: Python could not be launched.';
  const r = L.classify(raw);
  if (r.kind === 'timeout') return base + ': detector failed (timed out).';
  if (r.kind === 'failed') {
    let err = r.stderr || '';
    return base + ': detector failed' + (err ? ': ' + err : ' without an error message.');
  }
  if (r.kind === 'empty') return base + ': no report was produced by the detector.';
  if (r.kind === 'unusable' || r.kind === 'noscore') return 'no report: the detector printed text that is not a report.';
  const m = r.report._metrics;
  const score = Math.round(m.ai_tell_score);
  const band = String(m.ai_tell_band);
  const lines = [];
  lines.push(base + ' - ' + L.phrase(band) + ' (score ' + score + '/100, band: ' + band + ')');
  const conf = String(m.confidence);
  lines.push('confidence: ' + conf + (conf !== 'high' && m.confidence_reason ? ' - ' + m.confidence_reason : ''));
  if (m.truncated) lines.push('coverage: first ' + L.WINDOW_TXT + ' characters only');
  const f = L.findings(r.report).slice(0, 8);
  lines.push('tells: ' + (f.length ? f.map(x => x.label + ' (x' + x.count + ')').join('; ') : 'none'));
  lines.push('This is a report only; the file was not changed.');
  return lines.join('\n');
}

function showReply(sid) {
  const recs = L.readLedger(sid);
  if (!recs.length) {
    return 'nothing scored yet: no file has been scored in this session. Rows appear after prose files, including .docx and .pdf deliverables, are saved.';
  }
  const lines = ['Files seen this session, newest first:'];
  const ordered = recs.map((r, i) => ({ r, i })).sort((a, b) => (b.r.t - a.r.t) || (b.i - a.i));
  for (const { r } of ordered) {
    let body;
    if (r.kind === 'scored') {
      body = L.phrase(r.band) + ' (score ' + r.score + '/' + r.band + (r.truncated ? ', first ' + L.WINDOW_TXT + ' characters only' : '') + ')';
      const labs = (r.labels || []).slice(0, 5);
      if (labs.length) body += ' - ' + (r.flagged ? 'flagged' : 'under the threshold') + ': ' + labs.join('; ');
    } else if (r.kind === 'size') {
      body = 'not scored: over the ' + r.capKB + ' KB limit';
    } else if (r.kind === 'binary') {
      body = 'binary file, not re-scored';
    } else {
      body = 'not scored: ' + (r.reason || 'the check failed');
    }
    lines.push('  ' + r.base + ' - ' + body);
  }
  return lines.join('\n');
}

function doctorReply(ns) {
  const lvl = L.level();
  const typed = ns ? '/prosecheck:prosecheck' : '/prosecheck';
  const lines = ['prosecheck install health check'];
  let allOk = true;
  const modeOk = lvl !== 'off';
  lines.push(modeOk ? '[OK] mode: ' + lvl : '[off] mode: off - switched off; run /prosecheck on to turn it back on');
  const det = L.findDetector();
  lines.push(det ? '[OK] detector: bundled detector found in the plugin tree' : '[FAIL] detector: bundled detector not found in the plugin tree');
  if (!det) allOk = false;
  let pyLine;
  let pyOk = false;
  if (!det) {
    pyLine = '[FAIL] python: there is no bundled script to run';
  } else {
    const raw = L.runPython([det], 'Plain sentence for the install check. Short words keep it calm and plain.\n', 15000);
    if (raw.notfound || (raw.error && raw.error.code === 'ENOENT')) {
      pyLine = '[FAIL] python not found: saved files will not be re-scored until it is available, not re-scored; prose is still shaped by the contract';
    } else {
      const r = L.classify(raw);
      if (r.kind === 'ok') { pyOk = true; pyLine = '[OK] python: ran the bundled script and got a numeric score'; }
      else pyLine = '[FAIL] python: it ran, but the result was not a numeric score';
    }
  }
  lines.push(pyLine);
  if (!pyOk) allOk = false;
  let setOk = false;
  try {
    const dir = L.configDir();
    fs.mkdirSync(dir, { recursive: true });
    fs.accessSync(dir, fs.constants.W_OK);
    const t = path.join(dir, '.prosecheck-write-test-' + process.pid);
    fs.writeFileSync(t, 'x');
    fs.unlinkSync(t);
    setOk = true;
  } catch (e) { setOk = false; }
  lines.push(setOk ? '[OK] settings: the settings folder is writable' : '[FAIL] settings: the settings folder is not writable');
  if (!setOk) allOk = false;
  let closer;
  if (!allOk) {
    closer = 'Fix the faulty checks above, then run /prosecheck doctor again.';
  } else if (!modeOk) {
    closer = 'The install is healthy. While off, saved files are not scored. Run ' + typed + ' on to switch it on so saved files are scored again.';
  } else {
    closer = 'prosecheck is active. Plain text is accepted up to ' + L.PLAIN_CAP_KB + ' KB, archives up to 4 MB, and the first ' + L.WINDOW_TXT + ' characters are scanned. Run ' + typed + ' show to see files that were only partly scanned or skipped.';
  }
  lines.push('');
  lines.push(closer);
  return lines.join('\n');
}

function initReply(ns) {
  const lvl = L.level();
  const typed = ns ? '/prosecheck:prosecheck' : '/prosecheck';
  if (lvl === 'off') {
    return 'prosecheck is switched off, so nothing was exported. Run ' + typed + ' on to allow the export.';
  }
  const out = [];
  const cwd = process.cwd();
  const agents = path.join(cwd, 'AGENTS.md');
  const BEGIN = '<!-- prosecheck:begin -->';
  const END = '<!-- prosecheck:end -->';
  let existing = null;
  let readFail = false;
  try { existing = fs.readFileSync(agents, 'utf8'); } catch (e) {
    if (e.code !== 'ENOENT') readFail = true;
  }
  if (readFail) {
    out.push('cannot read AGENTS.md, so the contract was not written.');
  } else {
    const body = L.contract(lvl, { portable: true });
    if (existing !== null && (existing.indexOf(BEGIN) >= 0 || existing.indexOf('# Prose contract (prosecheck') >= 0)) {
      out.push('The contract is already present in AGENTS.md; the file was not changed.');
    } else {
      let add = BEGIN + '\n' + body + '\n' + END + '\n';
      let text;
      if (existing === null || existing === '') text = add;
      else text = existing + (existing.endsWith('\n') ? '' : '\n') + '\n' + add;
      try {
        fs.writeFileSync(agents, text);
        out.push('Wrote the ' + lvl + ' writing contract to AGENTS.md.');
      } catch (e) {
        out.push('cannot write AGENTS.md, so the contract was not written.');
      }
    }
  }
  const rule = path.join(cwd, '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(rule)) {
    out.push('The Cursor rule prosecheck.mdc is already there; it was not overwritten.');
  } else {
    let content;
    try { content = fs.readFileSync(path.join(L.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc'), 'utf8'); } catch (e) { content = L.cursorRule(); }
    try {
      fs.mkdirSync(path.dirname(rule), { recursive: true });
      fs.writeFileSync(rule, content);
      out.push('Copied the Cursor rule to .cursor/rules/prosecheck.mdc.');
    } catch (e) {
      out.push('cannot write .cursor/rules/prosecheck.mdc, so the Cursor rule was not created.');
    }
  }
  return out.join('\n');
}

function handle(inp) {
  const prompt = typeof inp.prompt === 'string' ? inp.prompt : '';
  const t = prompt.trim();
  const low = t.toLowerCase();
  if (low === 'stop prosecheck' || low === 'prosecheck off') {
    L.storeLevel('off');
    return block('prosecheck is now off. Use /prosecheck on to switch it back on.');
  }
  const m = /^\/prosecheck(:prosecheck)?(?:\s+([\s\S]*))?$/i.exec(t);
  if (!m) {
    if (low.indexOf('stop prosecheck') >= 0) { L.storeLevel('off'); return; }
    const lvl = L.level();
    if (lvl === 'off') return;
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: {
        hookEventName: 'UserPromptSubmit',
        additionalContext: 'prosecheck level: ' + lvl + '. Prose deliverables follow the writing contract; code, config, and commits are untouched.'
      }
    }));
    return;
  }
  const ns = !!m[1];
  const typed = ns ? '/prosecheck:prosecheck' : '/prosecheck';
  const restAll = (m[2] || '').trim();
  const sm = /^(\S+)\s*([\s\S]*)$/.exec(restAll);
  const sub = sm ? sm[1].toLowerCase() : '';
  const rest = sm ? sm[2] : '';
  const cwd = typeof inp.cwd === 'string' && inp.cwd ? inp.cwd : process.cwd();
  if (!sub || sub === 'help') return block(helpText(L.level()));
  if (SUBS.indexOf(sub) < 0) {
    return block('unknown subcommand: ' + sm[1] + '. Valid subcommands: ' + SUBS.join(', ') + '.');
  }
  switch (sub) {
    case 'lite': case 'full': case 'strict': case 'off':
      L.storeLevel(sub);
      return block('prosecheck level set to ' + sub + '.');
    case 'on':
      L.storeLevel('full');
      return block('prosecheck is on, at level full.');
    case 'status':
      return block('prosecheck level: ' + L.level());
    case 'show': return block(showReply(typeof inp.session_id === 'string' ? inp.session_id : ''));
    case 'check': return block(checkReply(rest, cwd));
    case 'doctor': return block(doctorReply(ns));
    case 'stats': return block(stats.reply(inp));
    case 'init': return block(initReply(ns));
  }
}

try {
  handle(L.parseInput());
} catch (e) { /* never fail the host */ }
process.exit(0);
