'use strict';
// /prosecheck stats: session token figures and the score of the session's own prose.
const L = require('./lib');
const { fs, path } = L;

function listJsonl(dir, out) {
  let ents;
  try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return out; }
  for (const e of ents) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) listJsonl(p, out);
    else if (e.isFile() && e.name.endsWith('.jsonl')) {
      try { out.push({ p, m: fs.statSync(p).mtimeMs }); } catch (x) { /* skip */ }
    }
  }
  return out;
}

function pickTranscript(named) {
  const all = listJsonl(path.join(L.configDir(), 'projects'), []);
  let newest = null;
  for (const f of all) if (!newest || f.m > newest.m) newest = f;
  if (typeof named === 'string' && named) {
    let nm = null;
    try { nm = fs.statSync(named).mtimeMs; } catch (e) { nm = null; }
    if (nm === null) return newest && false ? newest.p : named;
    if (newest && newest.m > nm && path.resolve(newest.p) !== path.resolve(named)) return newest.p;
    return named;
  }
  return newest ? newest.p : null;
}

function stripFences(t) {
  const lines = t.split('\n');
  const out = [];
  let fence = null;
  for (const ln of lines) {
    const m = /^ {0,3}(`{3,}|~{3,})/.exec(ln);
    if (fence) {
      if (m && m[1][0] === fence[0] && m[1].length >= fence.length && /^ {0,3}[`~]+\s*$/.test(ln)) fence = null;
      continue;
    }
    if (m) { fence = m[1]; continue; }
    out.push(ln);
  }
  return out.join('\n');
}

function reply(input) {
  const file = pickTranscript(input.transcript_path);
  const lvl = L.level();
  let raw;
  try {
    if (!file) throw new Error('none');
    if (!fs.statSync(file).isFile()) throw new Error('not a file');
    raw = fs.readFileSync(file, 'utf8');
  } catch (e) {
    return 'prosecheck stats: no readable transcript was found, so there are no session figures to report.';
  }
  const msgs = [];
  const byId = new Map();
  for (const line of raw.split(/\r?\n/)) {
    if (!line.trim()) continue;
    let o;
    try { o = JSON.parse(line); } catch (e) { continue; }
    if (!o || o.type !== 'assistant' || !o.message || typeof o.message !== 'object') continue;
    const m = o.message;
    const texts = [];
    if (typeof m.content === 'string') texts.push(m.content);
    else if (Array.isArray(m.content)) {
      for (const c of m.content) if (c && c.type === 'text' && typeof c.text === 'string') texts.push(c.text);
    }
    const u = m.usage && typeof m.usage === 'object' ? m.usage : {};
    const entry = { out: Number(u.output_tokens) || 0, cache: Number(u.cache_read_input_tokens) || 0, texts };
    if (typeof m.id === 'string' && m.id) {
      if (byId.has(m.id)) {
        const prev = byId.get(m.id);
        prev.out = entry.out;
        prev.cache = entry.cache;
        prev.texts = prev.texts.concat(texts);
        continue;
      }
      byId.set(m.id, entry);
    }
    msgs.push(entry);
  }
  let out = 0, cache = 0;
  for (const e of msgs) { out += e.out; cache += e.cache; }
  const lines = [
    'prosecheck stats',
    'level: ' + lvl,
    'assistant turns: ' + msgs.length,
    'output tokens: ' + out,
    'cache-read input tokens: ' + cache
  ];
  const prose = stripFences(msgs.map(e => e.texts.join('\n')).filter(Boolean).join('\n\n'));
  let slice = prose.length > 40000 ? prose.slice(prose.length - 40000) : prose;
  slice = slice.trim();
  if (slice.length > 200) {
    const r = L.runDetectorText(slice, 15000);
    if (r.kind === 'ok') lines.push('session prose ai_tell_score: ' + Math.round(r.report._metrics.ai_tell_score));
    else lines.push('session prose score unavailable');
  }
  return lines.join('\n');
}

module.exports = { reply };

if (require.main === module) {
  try {
    const inp = L.parseInput();
    process.stdout.write(JSON.stringify({ decision: 'block', reason: reply(inp) }));
  } catch (e) { /* never fail */ }
  process.exit(0);
}
