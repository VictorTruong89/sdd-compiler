'use strict';
const L = require('./lib');
try {
  L.parseInput();
  const lvl = L.level();
  if (lvl !== 'off') {
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: {
        hookEventName: 'SubagentStart',
        additionalContext: L.contract(lvl, { detector: L.findDetector() })
      }
    }));
  }
} catch (e) { /* never fail the host */ }
process.exit(0);
