'use strict';
const L = require('./lib');
try {
  L.parseInput();
  L.pruneLedgers();
  const first = !L.flagExists();
  const lvl = L.level();
  if (lvl !== 'off') {
    if (first || L.readStored() === null && !L.flagExists()) L.storeLevel(lvl);
    let out = '';
    if (first) out += L.welcome() + '\n';
    out += L.contract(lvl, { detector: L.findDetector() });
    process.stdout.write(out + '\n');
  } else if (first) {
    // nothing is printed while off
  }
} catch (e) { /* never fail the host */ }
process.exit(0);
