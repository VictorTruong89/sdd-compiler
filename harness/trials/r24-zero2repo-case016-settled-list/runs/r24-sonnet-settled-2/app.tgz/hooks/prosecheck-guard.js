'use strict';
const L = require('./lib');
const { fs, path } = L;

const INSTR = ['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md'];
const INSTR_STEMS = ['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory'];

function patchPaths(cmd) {
  const out = [];
  if (typeof cmd !== 'string') return out;
  for (const line of cmd.split(/\r?\n/)) {
    const m = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/.exec(line);
    if (m) {
      const p = m[1].trim();
      if (p && out.indexOf(p) < 0) out.push(p);
    }
  }
  return out.slice(0, 16);
}

function inside(child, parent) {
  const rel = path.relative(path.resolve(parent), path.resolve(child));
  return rel !== '' && !rel.startsWith('..') && !path.isAbsolute(rel);
}

function handle(file, sid, lines) {
  const parts = file.split(/[\\/]+/);
  if (parts.indexOf('node_modules') >= 0 || parts.indexOf('.git') >= 0) return;
  if (inside(file, L.pluginRoot())) return;
  const base = path.basename(file);
  const lower = base.toLowerCase();
  const ext = path.extname(base).toLowerCase();
  if (INSTR.indexOf(lower) >= 0) return;
  const stem = ext ? lower.slice(0, lower.length - ext.length) : lower;
  if (INSTR_STEMS.indexOf(stem) >= 0 && !L.isProseExt(ext)) return;
  const binary = ext === '.pdf' || ext === '.rtf';
  if (!L.isProseExt(ext) && !binary) return;
  let st;
  try { st = fs.statSync(file); } catch (e) {
    L.appendLedger(sid, { base, kind: 'failed', reason: 'file could not be read' });
    return;
  }
  if (!st.isFile()) return;
  if (binary) { L.appendLedger(sid, { base, kind: 'binary' }); return; }
  const plain = L.PLAIN_EXT.indexOf(ext) >= 0;
  const cap = plain ? L.PLAIN_CAP : L.ARCHIVE_CAP;
  if (st.size > cap) {
    L.appendLedger(sid, { base, kind: 'size', capKB: plain ? L.PLAIN_CAP_KB : L.ARCHIVE_CAP_KB });
    return;
  }
  const r = L.runDetectorFile(file, plain ? 8000 : 15000);
  if (r.kind !== 'ok') {
    const reasons = {
      nopython: 'python could not be found',
      nodetector: 'the bundled detector is missing',
      timeout: 'the detector timed out',
      unusable: 'the detector printed text that is not a structured report',
      noscore: 'the report has no numeric score',
      empty: 'the detector produced no result',
      failed: 'the detector produced no result'
    };
    L.appendLedger(sid, { base, kind: 'failed', reason: reasons[r.kind] || 'the detector produced no result' });
    return;
  }
  const m = r.report._metrics;
  const score = Math.round(m.ai_tell_score);
  const band = String(m.ai_tell_band);
  const threshold = L.level() === 'strict' ? 20 : 40;
  const flagged = score > threshold;
  const fl = L.findings(r.report).map(f => f.label);
  L.appendLedger(sid, { base, kind: 'scored', score, band, labels: fl.slice(0, 5), flagged, truncated: !!m.truncated });
  if (flagged) {
    const cov = m.truncated ? ', first ' + L.WINDOW_TXT + ' characters only' : '';
    lines.push('prosecheck: ' + base + ' ' + L.phrase(band) + ' (score ' + score + ', band ' + band + cov + '). Flagged: ' +
      fl.slice(0, 5).join('; ') + '. Please fix the flagged spans and keep the sentence rhythm varied.');
  }
}

try {
  const inp = L.parseInput();
  const lvl = L.level();
  const tool = String(inp.tool_name || '').toLowerCase();
  const ti = inp.tool_input && typeof inp.tool_input === 'object' ? inp.tool_input : null;
  if ((lvl === 'full' || lvl === 'strict') && ti &&
      ['write', 'edit', 'multiedit', 'notebookedit', 'apply_patch'].indexOf(tool) >= 0) {
    const sid = typeof inp.session_id === 'string' ? inp.session_id : '';
    const cwd = typeof inp.cwd === 'string' && inp.cwd ? inp.cwd : process.cwd();
    let paths = [];
    if (tool === 'apply_patch') paths = patchPaths(ti.command);
    else if (tool === 'notebookedit') {
      const p = typeof ti.notebook_path === 'string' && ti.notebook_path.trim() ? ti.notebook_path : ti.file_path;
      if (typeof p === 'string' && p.trim()) paths = [p];
    } else if (typeof ti.file_path === 'string' && ti.file_path.trim()) paths = [ti.file_path];
    const lines = [];
    const seen = new Set();
    for (const p0 of paths) {
      let p = p0.trim();
      p = path.isAbsolute(p) ? p : path.resolve(cwd, p);
      if (seen.has(p)) continue;
      seen.add(p);
      try { handle(p, sid, lines); } catch (e) { /* ignore */ }
    }
    if (lines.length) {
      process.stdout.write(JSON.stringify({
        hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') }
      }));
    }
  }
} catch (e) { /* never fail the host */ }
process.exit(0);
