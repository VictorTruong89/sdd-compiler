#!/usr/bin/env python3
"""prosecheck detector: local, standard-library prose-pattern scanner.

usage: detect.py [--clean] [--ci] [--] [FILE]
"""
import io
import json
import math
import os
import random
import re
import sys
import unicodedata
import zipfile
from html import unescape

WINDOW = 262144
USAGE = (
    "usage: detect.py [--clean] [--ci] [--] [FILE]\n"
    "\n"
    "Scores prose for AI-writing patterns and prints a JSON report.\n"
    "  --clean   print scrubbed text instead of the report\n"
    "  --ci      add a resampled low/high interval on the score\n"
    "  --        stop option parsing (a file name may begin with a dash)\n"
    "  FILE      one file to scan; with no file, standard input is read\n"
    "  -h, --help  print this message\n"
)

PLAIN_EXT = {".md", ".mdx", ".markdown", ".txt", ".text", ".rst", ".tex", ".org", ".adoc"}
ZIP_EXT = {".docx", ".docm", ".pptx", ".pptm", ".xlsx", ".xlsm", ".odt", ".odp", ".ods", ".epub"}
NB_EXT = {".ipynb"}


# --------------------------------------------------------------------------
# errors / io
# --------------------------------------------------------------------------
class Fail(Exception):
    def __init__(self, code, msg):
        Exception.__init__(self, msg)
        self.code = code
        self.msg = msg


def fail(code, msg):
    sys.stderr.write(json.dumps({"error": msg}, ensure_ascii=True) + "\n")
    sys.stderr.flush()
    sys.exit(code)


def decode_bytes(b):
    if b.startswith(b"\xef\xbb\xbf"):
        return b[3:].decode("utf-8", "replace")
    if b.startswith(b"\xff\xfe") or b.startswith(b"\xfe\xff"):
        try:
            return b.decode("utf-16")
        except Exception:
            return b[2:].decode("utf-16-le" if b[:2] == b"\xff\xfe" else "utf-16-be", "replace")
    return b.decode("utf-8", "replace")


# --------------------------------------------------------------------------
# extraction
# --------------------------------------------------------------------------
def _num_key(name):
    m = re.findall(r"\d+", name)
    return (int(m[-1]) if m else 0, name)


def _x(s):
    return unescape(s)


def ex_docx(z):
    names = z.namelist()
    if "word/document.xml" not in names:
        return ""
    xml = z.read("word/document.xml").decode("utf-8", "replace")
    paras = []
    for pm in re.finditer(r"<w:p(?:\s[^>]*[^/>])?>(.*?)</w:p>", xml, re.S):
        parts = []
        for m in re.finditer(r"<w:t(?:\s[^>]*)?>(.*?)</w:t>|<w:tab\s*/>|<w:br\s*/>|<w:cr\s*/>", pm.group(1), re.S):
            tok = m.group(0)
            if tok.startswith("<w:tab"):
                parts.append("\t")
            elif tok.startswith("<w:br") or tok.startswith("<w:cr"):
                parts.append("\n")
            else:
                parts.append(_x(m.group(1)))
        paras.append("".join(parts))
    return "\n".join(p for p in paras if p.strip())


def ex_pptx(z):
    slides = sorted([n for n in z.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)], key=_num_key)
    out = []
    for n in slides:
        xml = z.read(n).decode("utf-8", "replace")
        for pm in re.finditer(r"<a:p(?:\s[^>]*[^/>])?>(.*?)</a:p>", xml, re.S):
            txt = "".join(_x(m.group(1)) for m in re.finditer(r"<a:t(?:\s[^>]*)?>(.*?)</a:t>", pm.group(1), re.S))
            if txt.strip():
                out.append(txt)
    return "\n".join(out)


def _si_text(si):
    si = re.sub(r"<rPh\b.*?</rPh>", "", si, flags=re.S)
    return "".join(_x(m.group(1)) for m in re.finditer(r"<t(?:\s[^>]*)?>(.*?)</t>", si, re.S))


def ex_xlsx(z):
    names = z.namelist()
    shared = []
    if "xl/sharedStrings.xml" in names:
        xml = z.read("xl/sharedStrings.xml").decode("utf-8", "replace")
        for m in re.finditer(r"<si(?:\s[^>]*[^/>])?>(.*?)</si>|<si\s*/>", xml, re.S):
            shared.append(_si_text(m.group(1) or ""))
    sheets = sorted([n for n in names if re.match(r"xl/worksheets/[^/]+\.xml$", n)], key=_num_key)
    out = []
    for n in sheets:
        xml = z.read(n).decode("utf-8", "replace")
        for m in re.finditer(r"<c\b([^>]*?)(?:/>|>(.*?)</c>)", xml, re.S):
            attrs, body = m.group(1), m.group(2) or ""
            tm = re.search(r"""\bt\s*=\s*["']([^"']*)["']""", attrs)
            t = tm.group(1) if tm else ""
            val = ""
            if t == "s":
                vm = re.search(r"<v(?:\s[^>]*)?>(.*?)</v>", body, re.S)
                if vm:
                    s = vm.group(1).strip()
                    if re.fullmatch(r"\d+", s) and int(s) < len(shared):
                        val = shared[int(s)]
            elif t == "inlineStr":
                im = re.search(r"<is(?:\s[^>]*)?>(.*?)</is>", body, re.S)
                if im:
                    val = _si_text(im.group(1))
            elif t == "str":
                vm = re.search(r"<v(?:\s[^>]*)?>(.*?)</v>", body, re.S)
                if vm:
                    val = _x(vm.group(1))
            if val.strip():
                out.append(val)
    return "\n".join(out)


def ex_odf(z):
    if "content.xml" not in z.namelist():
        return ""
    xml = z.read("content.xml").decode("utf-8", "replace")
    xml = re.sub(r"<office:annotation\b.*?</office:annotation>", "", xml, flags=re.S)
    out = []
    for m in re.finditer(r"<text:(p|h)(?:\s[^>]*[^/>])?>(.*?)</text:\1>", xml, re.S):
        s = m.group(2)
        s = re.sub(r"<text:s(?:\s+[^>]*?text:c\s*=\s*[\"'](\d+)[\"'][^>]*)?\s*/>", lambda mm: " " * int(mm.group(1) or 1), s)
        s = re.sub(r"<text:tab\s*/>", "\t", s)
        s = re.sub(r"<text:line-break\s*/>", "\n", s)
        s = re.sub(r"<[^>]*>", "", s)
        s = _x(s)
        if s.strip():
            out.append(s)
    return "\n".join(out)


_BLOCK = re.compile(r"</?(?:p|div|h[1-6]|li|ul|ol|tr|table|blockquote|section|article|pre|br|hr|dd|dt|figure|figcaption|caption)\b[^>]*>", re.I)


def html_text(h):
    h = re.sub(r"<!--.*?-->", " ", h, flags=re.S)
    h = re.sub(r"<head\b.*?</head>", " ", h, flags=re.S | re.I)
    for tag in ("style", "script", "nav"):
        h = re.sub(r"<%s\b.*?</%s\s*>" % (tag, tag), " ", h, flags=re.S | re.I)
    h = re.sub(r"\s+", " ", h)
    h = _BLOCK.sub("\n", h)
    h = re.sub(r"<[^>]*>", "", h)
    h = unescape(h)
    lines = [re.sub(r"[ \t]+", " ", ln).strip() for ln in h.split("\n")]
    return "\n".join(ln for ln in lines if ln)


def ex_epub(z):
    names = z.namelist()
    docs = [n for n in names if n.lower().endswith((".xhtml", ".html", ".htm"))]
    order = []
    try:
        opfs = [n for n in names if n.lower().endswith(".opf")]
        if opfs:
            opf = opfs[0]
            xml = z.read(opf).decode("utf-8", "replace")
            base = opf.rsplit("/", 1)[0] + "/" if "/" in opf else ""
            man = {}
            for m in re.finditer(r"<item\b([^>]*)>", xml):
                a = m.group(1)
                i = re.search(r"""\bid\s*=\s*["']([^"']*)["']""", a)
                hr = re.search(r"""\bhref\s*=\s*["']([^"']*)["']""", a)
                if i and hr:
                    man[i.group(1)] = hr.group(1)
            from urllib.parse import unquote
            for m in re.finditer(r"<itemref\b[^>]*?\bidref\s*=\s*[\"']([^\"']*)[\"']", xml):
                hr = man.get(m.group(1))
                if hr:
                    p = os.path.normpath(base + unquote(hr.split("#")[0])).replace("\\", "/")
                    if p in docs and p not in order:
                        order.append(p)
    except Exception:
        order = []
    for n in sorted(docs):
        if n not in order and not re.search(r"(^|/)(nav|toc)\.(x?html?)$", n.lower()):
            order.append(n)
    out = []
    for n in order:
        t = html_text(z.read(n).decode("utf-8", "replace"))
        if t.strip():
            out.append(t)
    return "\n".join(out)


def ex_ipynb(b):
    try:
        data = json.loads(decode_bytes(b))
        cells = data["cells"]
        if not isinstance(cells, list):
            return ""
        out = []
        for c in cells:
            if not isinstance(c, dict) or c.get("cell_type") != "markdown":
                continue
            s = c.get("source", "")
            if isinstance(s, list):
                if not all(isinstance(x, str) for x in s):
                    continue
                s = "".join(s)
            if not isinstance(s, str):
                continue
            if s.strip():
                out.append(s)
        return "\n".join(out)
    except Exception:
        return ""


def extract_file(path):
    ext = os.path.splitext(path)[1].lower()
    try:
        with open(path, "rb") as f:
            b = f.read()
    except Exception as e:
        raise Fail(1, "cannot read input: %s" % (getattr(e, "strerror", None) or e))
    if ext in ZIP_EXT:
        try:
            z = zipfile.ZipFile(io.BytesIO(b))
        except Exception as e:
            raise Fail(1, "cannot read input: not a readable zip archive (%s)" % path)
        try:
            if ext in (".docx", ".docm"):
                t = ex_docx(z)
            elif ext in (".pptx", ".pptm"):
                t = ex_pptx(z)
            elif ext in (".xlsx", ".xlsm"):
                t = ex_xlsx(z)
            elif ext == ".epub":
                t = ex_epub(z)
            else:
                t = ex_odf(z)
        except Exception:
            t = ""
        return t.strip()
    if ext in NB_EXT:
        return ex_ipynb(b).strip()
    if ext in (".pdf", ".rtf"):
        return ""
    return decode_bytes(b)


# --------------------------------------------------------------------------
# character layer
# --------------------------------------------------------------------------
_CAND = re.compile("[^\t\n\r\x20-\x7e]")
_VISIBLE_CF = set([0x600, 0x601, 0x602, 0x603, 0x604, 0x605, 0x6DD, 0x70F, 0x8E2, 0x110BD, 0x110CD])
_RTL = re.compile("[֐-ࣿיִ-﷿ﹰ-﻿\U00010800-\U00010fff\U0001e800-\U0001efff]")
_BIDI = set([0x200E, 0x200F, 0x061C] + list(range(0x202A, 0x202F)) + list(range(0x2066, 0x206A)))


def _is_cjk(c):
    o = ord(c)
    return (0x4E00 <= o <= 0x9FFF or 0x3400 <= o <= 0x4DBF or 0xF900 <= o <= 0xFAFF or 0x20000 <= o <= 0x323AF
            or o in (0x3005, 0x3007) or 0x2E80 <= o <= 0x2FDF or 0x3021 <= o <= 0x3029)


def _is_nospace(c):
    o = ord(c)
    return (_is_cjk(c) or 0x3040 <= o <= 0x30FF or 0x31F0 <= o <= 0x31FF or 0xFF66 <= o <= 0xFF9F
            or 0x0E00 <= o <= 0x0EFF or 0x1780 <= o <= 0x17FF or 0x19E0 <= o <= 0x19FF
            or 0x1000 <= o <= 0x109F or 0xA9E0 <= o <= 0xA9FF or 0xAA60 <= o <= 0xAA7F)


def _is_joining_letter(c):
    o = ord(c)
    if not c.isalpha():
        return False
    return (0x0590 <= o <= 0x06FF or 0x0700 <= o <= 0x074F or 0x0750 <= o <= 0x077F or 0x08A0 <= o <= 0x08FF
            or 0xFB1D <= o <= 0xFDFF or 0xFE70 <= o <= 0xFEFF or 0x0900 <= o <= 0x0DFF
            or 0x1000 <= o <= 0x109F or 0x1780 <= o <= 0x17FF)


def _is_symbolish(c):
    if not c:
        return False
    o = ord(c)
    if 0x1F000 <= o <= 0x1FAFF or 0x2190 <= o <= 0x2BFF or 0x2600 <= o <= 0x27BF or o in (0x00A9, 0x00AE, 0x203C, 0x2049, 0x2122, 0x2139, 0x3030, 0x303D, 0x3297, 0x3299):
        return True
    return unicodedata.category(c) in ("So", "Sk")


def _is_invisible_char(c):
    o = ord(c)
    if o in (9, 10, 13):
        return False
    if o in _VISIBLE_CF:
        return False
    if o in (0x034F, 0x115F, 0x1160, 0x3164, 0xFFA0, 0x17B4, 0x17B5) or 0x180B <= o <= 0x180F:
        return True
    if 0xFE00 <= o <= 0xFE0F or 0xE0100 <= o <= 0xE01EF or 0xE0000 <= o <= 0xE0FFF:
        return True
    cat = unicodedata.category(c)
    return cat in ("Cf", "Cc")


def _tag_run_ok(text, i):
    s = i
    while s > 0 and 0xE0000 <= ord(text[s - 1]) <= 0xE0FFF:
        s -= 1
    e = i
    n = len(text)
    while e < n and 0xE0000 <= ord(text[e]) <= 0xE0FFF:
        e += 1
    return s > 0 and ord(text[s - 1]) == 0x1F3F4 and ord(text[e - 1]) == 0xE007F


def _keeps_invisible(text, i, rtl):
    c = text[i]
    o = ord(c)
    p = text[i - 1] if i > 0 else ""
    n = text[i + 1] if i + 1 < len(text) else ""
    if 0xE0000 <= o <= 0xE007F:
        return _tag_run_ok(text, i)
    if 0xE0100 <= o <= 0xE01EF:
        return bool(p) and _is_cjk(p)
    if 0xFE00 <= o <= 0xFE0F:
        if n == "⃣":
            return True
        if p and (_is_cjk(p) or _is_symbolish(p)):
            return True
        return False
    if o == 0x200B:
        return (bool(p) and _is_nospace(p)) or (bool(n) and _is_nospace(n))
    if o == 0x00AD:
        return bool(p) and bool(n) and p.isalpha() and n.isalpha()
    if o in _BIDI:
        return rtl
    if 0x180B <= o <= 0x180F:
        return bool(p) and 0x1800 <= ord(p) <= 0x18AF
    if o in (0x17B4, 0x17B5):
        return (bool(p) and 0x1780 <= ord(p) <= 0x17FF) or (bool(n) and 0x1780 <= ord(n) <= 0x17FF)
    if o in (0x200C, 0x200D):
        q = p
        if q and 0xFE00 <= ord(q) <= 0xFE0F and i > 1:
            q = text[i - 2]
        for ch in (q, n):
            if ch and (_is_joining_letter(ch) or _is_symbolish(ch)):
                return True
        return False
    return False


def invisible_positions(text):
    """Return (removable_indexes, kept_count)."""
    rtl = bool(_RTL.search(text))
    rem = []
    for m in _CAND.finditer(text):
        i = m.start()
        c = text[i]
        if not _is_invisible_char(c):
            continue
        if _keeps_invisible(text, i, rtl):
            continue
        rem.append(i)
    return rem


def _nbsp_kept(text, i):
    p = text[i - 1] if i > 0 else ""
    n = text[i + 1] if i + 1 < len(text) else ""
    if p.isdigit() or n.isdigit():
        return True
    if n and n in ":;!?»›%€":
        return True
    if p and p in "«‹":
        return True
    return False


def nonstandard_space_positions(text):
    out = []
    for m in _CAND.finditer(text):
        i = m.start()
        c = text[i]
        if unicodedata.category(c) == "Zs":
            if c in (" ", " ") and _nbsp_kept(text, i):
                continue
            out.append(i)
    return out


_LOOK = {}
for _s, _t in (
    ("а", "a"), ("с", "c"), ("е", "e"), ("о", "o"), ("р", "p"), ("х", "x"),
    ("у", "y"), ("і", "i"), ("ј", "j"), ("ѕ", "s"), ("ԁ", "d"), ("һ", "h"),
    ("ԝ", "w"), ("ԍ", "g"), ("ν", "v"), ("ο", "o"), ("α", "a"), ("ρ", "p"),
    ("υ", "u"), ("ι", "i"), ("χ", "x"), ("օ", "o"), ("ս", "u"), ("ո", "n"),
    ("А", "A"), ("В", "B"), ("С", "C"), ("Е", "E"), ("Н", "H"), ("І", "I"),
    ("Ј", "J"), ("К", "K"), ("М", "M"), ("О", "O"), ("Р", "P"), ("Ѕ", "S"),
    ("Т", "T"), ("Х", "X"), ("Ү", "Y"), ("Α", "A"), ("Β", "B"), ("Ε", "E"),
    ("Ζ", "Z"), ("Η", "H"), ("Ι", "I"), ("Κ", "K"), ("Μ", "M"), ("Ν", "N"),
    ("Ο", "O"), ("Ρ", "P"), ("Τ", "T"), ("Χ", "X"), ("Υ", "Y"), ("Օ", "O"),
    ("Ս", "S"), ("Ձ", "Z"),
):
    _LOOK[_s] = _t

_TOK = re.compile(r"\S+")


def _homoglyph_token_ok(tok):
    has_ascii = False
    has_look = False
    for ch in tok:
        if ch.isalpha():
            if ord(ch) < 128:
                has_ascii = True
            elif ch in _LOOK:
                has_look = True
            else:
                return False
    return has_ascii and has_look


def homoglyph_tokens(text):
    out = []
    if text.isascii():
        return out
    for m in _TOK.finditer(text):
        t = m.group(0)
        if not t.isascii() and _homoglyph_token_ok(t):
            # require an actual run mixing ascii with lookalike
            for r in re.finditer(r"[^\W\d_]+", t):
                run = r.group(0)
                if any(ord(c) < 128 for c in run) and any(c in _LOOK for c in run):
                    out.append(m)
                    break
    return out


def clean_text(text):
    rem = set(invisible_positions(text))
    sp = set(nonstandard_space_positions(text))
    homs = homoglyph_tokens(text)
    fold = {}
    for m in homs:
        for r in re.finditer(r"[^\W\d_]+", m.group(0)):
            run = r.group(0)
            if any(ord(c) < 128 for c in run) and any(c in _LOOK for c in run):
                for k, c in enumerate(run):
                    if c in _LOOK:
                        fold[m.start() + r.start() + k] = _LOOK[c]
    out = []
    for i, c in enumerate(text):
        if i in rem:
            continue
        if i in fold:
            out.append(fold[i])
        elif i in sp:
            out.append(" ")
        elif c in (" ", " "):
            out.append("\n")
        elif c != " " and c != " " and c != " " and unicodedata.category(c) == "Zs" and False:
            out.append(" ")
        else:
            out.append(c)
    t = "".join(out)
    ended_nl = t.endswith("\n") or text.endswith("\n")
    lines = t.split("\n")
    res = []
    n = len(lines)
    for k, ln in enumerate(lines):
        cr = ""
        body = ln
        if body.endswith("\r"):
            cr = "\r"
            body = body[:-1]
        stripped = body.rstrip(" \t")
        trailing = body[len(stripped):]
        if trailing == "  " and stripped.strip() and k + 1 < n and lines[k + 1].strip() and k + 1 < n - 0:
            body = stripped + "  "
        else:
            body = stripped
        res.append(body + cr)
    t = "\n".join(res)
    # leading blank lines
    t = re.sub(r"\A(?:[ \t\r]*\n)+", "", t)
    t = t.rstrip(" \t\r\n\f\v\x1c\x1d\x1e\x1f\x85  ")
    if ended_nl:
        t += "\n"
    return t


# --------------------------------------------------------------------------
# masking
# --------------------------------------------------------------------------
_FENCE_OPEN = re.compile(r"^( {0,3})(`{3,}|~{3,})(.*)$")
_BADGE = re.compile(r"^\s*(?:\[?!\[[^\]\n]*\]\([^)\n]*\)(?:\]\([^)\n]*\))?(?:\]\[[^\]\n]*\])?\s*)+$")
_TSEP = re.compile(r"^\s*\|?\s*:?-{2,}:?\s*(?:\|\s*:?-{2,}:?\s*)*\|?\s*$")


def mask_text(t):
    lines = t.split("\n")
    n = len(lines)
    kill = [False] * n
    # YAML front matter
    if n and lines[0].rstrip() == "---":
        for j in range(1, n):
            if lines[j].rstrip() in ("---", "..."):
                for k in range(j + 1):
                    kill[k] = True
                break
    # fences
    i = 0
    while i < n:
        if kill[i]:
            i += 1
            continue
        m = _FENCE_OPEN.match(lines[i])
        if m and not (m.group(2)[0] == "`" and "`" in m.group(3)):
            ch = m.group(2)[0]
            ln = len(m.group(2))
            kill[i] = True
            j = i + 1
            closed = False
            while j < n:
                kill[j] = True
                cm = re.match(r"^ {0,3}(" + re.escape(ch) + r"{%d,})\s*$" % ln, lines[j])
                if cm:
                    closed = True
                    break
                j += 1
            i = j + 1
            continue
        i += 1
    # blockquote runs
    i = 0
    while i < n:
        if not kill[i] and re.match(r"^\s{0,3}>", lines[i]):
            j = i
            while j + 1 < n and not kill[j + 1] and re.match(r"^\s{0,3}>", lines[j + 1]):
                j += 1
            if j > i:
                for k in range(i, j + 1):
                    kill[k] = True
            i = j + 1
        else:
            i += 1
    # tables and badges
    for i in range(n):
        if kill[i]:
            continue
        s = lines[i].strip()
        if not s:
            continue
        if s.startswith("|") or (_TSEP.match(lines[i]) and "|" in s):
            kill[i] = True
        elif "|" in s and ((i > 0 and "-" in lines[i - 1] and _TSEP.match(lines[i - 1]) and "|" in lines[i - 1])
                           or (i + 1 < n and _TSEP.match(lines[i + 1]) and "|" in lines[i + 1])):
            kill[i] = True
        elif _BADGE.match(lines[i]):
            kill[i] = True
    out = [(" " * len(l) if kill[k] else l) for k, l in enumerate(lines)]
    s = "\n".join(out)
    s = re.sub(r"(?<!`)(`+)(?!`)(.+?)(?<!`)\1(?!`)", lambda m: re.sub(r"[^\n]", " ", m.group(0)), s, flags=re.S)
    return s


# --------------------------------------------------------------------------
# helpers for patterns
# --------------------------------------------------------------------------
def infl(w):
    forms = set([w, w + "s", w + "es", w + "ed", w + "ing"])
    if w.endswith("e"):
        forms |= set([w + "d", w[:-1] + "ing", w[:-1] + "ed"])
    if w.endswith("y"):
        forms |= set([w[:-1] + "ies", w[:-1] + "ied"])
    return "|".join(sorted((re.escape(f) for f in forms), key=len, reverse=True))


def W(*words):
    return r"\b(?:%s)\b" % "|".join(infl(w) for w in words)


def A(*alts):
    return "(?:%s)" % "|".join(alts)


I = re.I
WORD_RE = re.compile(r"[\w'\-]*[^\W_][\w'\-]*")


def C(p, flags=I):
    return re.compile(p, flags)


F1 = C(A(
    W("additionally", "crucial", "delve", "tapestry", "pivotal", "vibrant", "meticulous", "testament", "underscore",
      "intricate", "intricacy", "intricacies", "interplay", "garner", "bolster", "foster", "showcase", "emphasize",
      "enduring", "enhance", "leverage", "utilize", "facilitate", "encompass", "harness", "holistic", "paradigm",
      "transformative", "unprecedented", "myriad", "plethora", "robust", "seamless", "navigate", "embark", "craft",
      "landscape", "journey", "realm", "multifaceted", "elevate", "empower", "unlock"),
    r"\balign(?:s|ed|ing)?\s+with\b",
    r"\bcaptur(?:e|es|ed|ing)\s+the\s+(?:essence|spirit|imagination|heart|magic)\b",
    r"\bseamlessly\b", r"\brobustly\b", r"\bmeticulously\b", r"\bcrucially\b",
))
F2 = C(A(
    W("genuinely", "fascinating", "nuanced", "thoughtfully", "refreshingly", "strikingly", "compellingly"),
    r"\bquietly\s+(?:powerful|profound|radical)\b",
    r"\bdeeply\s+(?:human|personal|felt|unsettling)\b",
    r"\bresonat(?:e|es|ed|ing)\s+deeply\b",
    r"\bgame[\s-]?chang(?:er|ers|ing)\b",
    W("supercharge", "skyrocket", "turbocharge", "revolutionize"),
    r"\bdoubl(?:e|es|ed|ing)\s+down\s+on\b",
    r"\bdiv(?:e|es|ed|ing)\s+deep(?:er)?\s+into\b",
    r"\bunlock(?:s|ed|ing)?\s+(?:the\s+)?(?:power|potential|value)\b",
    r"\btak(?:e|es|ing)\b[^.!?\n]{0,40}?\bto\s+the\s+next\s+level\b",
))
F3 = C(A(
    W("nestled", "breathtaking", "stunning", "picturesque", "charming", "idyllic", "unparalleled", "premier"),
    r"\bmust-visit\b", r"\bvibrant\s+community\b", r"\brich\s+cultural\s+heritage\b", r"\bin\s+the\s+heart\s+of\b",
    r"\bworld-class\b", r"\btop-tier\b", r"\bleading\b", r"\besteemed\s+organi[sz]ation\b", r"\bvaluable\s+asset\b",
    r"\bpassion\s+for\s+excellence\b", r"\bproven\s+track\s+record\b", r"\bresults-oriented\b",
    r"\bwealth\s+of\s+experience\b", r"\bdynamic\s+team\b", r"\bfast-paced\s+environment\b",
    r"\bdeeply\s+passionate\b", r"\bperfectly\s+situated\b", r"\b(?:close|tight)-knit\s+team\b",
    r"\bI\s+am\s+excited\s+to\s+(?:apply|bring)\b", r"\buniquely\s+positioned\s+to\b",
))
IMPER = re.compile(r"(?:^|(?<=[.!?])\s+|\n)\s*(?:install|join|grab|download|try|discover|experience|escape|transform|reclaim|unlock|elevate|boost|say|imagine|explore|meet|introducing|upgrade|claim|unleash|supercharge|level|stop|start)\b", I)
HYPH = C(r"\b(?:state-of-the-art|cutting-edge|best-in-class|results-driven|data-driven|fast-paced|detail-oriented|forward-thinking|customer-centric|user-friendly|end-to-end|mission-critical|next-generation|industry-leading|award-winning|goal-oriented|team-oriented|ever-evolving|ever-changing|cross-functional|value-added|top-notch|world-class|high-impact|game-changing|thought-provoking|well-rounded|self-motivated|results-focused|solution-oriented|client-focused|world-renowned|time-tested|ground-breaking|groundbreaking|hard-working|fast-growing|full-service|high-performing)\b")
F5 = C(r"\bsimple\s+yet\s+(?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b")
ADJ_END = re.compile(r"(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$", I)
STOCK_ADJ = set("innovative powerful seamless robust dynamic cutting-edge comprehensive stunning vibrant sleek modern intuitive scalable reliable secure flexible efficient elegant beautiful rich bold exciting remarkable exceptional unique versatile".split())
CHAIN = re.compile(r"\b((?:[A-Za-z][A-Za-z-]*,\s+){2,}(?:(?:and|or)\s+)?[A-Za-z][A-Za-z-]*)(?:\s+([A-Za-z][A-Za-z-]*))?")
CLUSTERS = [
    ["protagonist", "main character", "central figure", "hero", "heroine"],
    ["company", "firm", "organization", "organisation", "enterprise", "business"],
    ["author", "writer", "novelist", "scribe"],
    ["report", "study", "analysis", "investigation", "examination"],
    ["technology", "tool", "system", "platform", "solution"],
    ["technique", "method", "approach", "strategy", "tactic"],
    ["challenge", "obstacle", "difficulty", "hurdle", "barrier"],
    ["benefit", "advantage", "upside", "strength"],
]
_PL = r"(?:s|es)?"
CLUSTER_RX = []
for _cl in CLUSTERS:
    CLUSTER_RX.append([re.compile(r"\b%s\b" % (m.replace("y", "(?:y|ies)") if m.endswith("y") and " " not in m else re.escape(m) + _PL if not m.endswith("y") else m), I) for m in _cl])
CLUSTER_RX = []
for _cl in CLUSTERS:
    lst = []
    for m in _cl:
        if m.endswith("y"):
            pat = r"\b%s(?:y|ies)\b" % re.escape(m[:-1])
        elif m.endswith("s") or m.endswith("h"):
            pat = r"\b%s(?:es)?\b" % re.escape(m)
        else:
            pat = r"\b%ss?\b" % re.escape(m)
        lst.append(re.compile(pat, I))
    CLUSTER_RX.append(lst)

F10 = C(A(
    r"\b(?:stand|stands|stood|standing|serve|serves|served|serving)\s+as\s+(?:(?:a|an|the)\s+)?(?:\w+\s+)?(?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b",
    r"\bunderscor(?:es|ed|ing|e)\s+(?:its|the|their|his|her)\s+(?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b",
    r"\bhighlight(?:s|ed|ing)?\s+(?:its|the|their|his|her)\s+(?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b",
    r"\breflect(?:s|ed|ing)?\s+a\s+broader\s+(?:trend|shift|pattern)\b",
    r"\bmark(?:s|ed|ing)?\s+a\s+(?:turning\s+point|milestone|watershed|new\s+chapter|new\s+era)\b",
    r"\bsymboli[sz](?:es|ed|ing|e)\b",
    r"\bset(?:s|ting)?\s+the\s+stage\s+for\b",
    r"\bleft\s+an\s+indelible\s+mark\b",
    r"\bplay(?:s|ed|ing)?\s+an?\s+(?:crucial|pivotal|vital|key|central|significant)\s+role\b",
    r"\bha(?:s|ve)\s+(?:shaped|sparked)\b",
    r"\bha(?:s|ve)\s+come\s+to\s+(?:define|symbolize|symbolise)\b",
))
OUTLET = r"[A-Z][\w&.'-]*(?:\s+[A-Z][\w&.'-]*)*"
F11 = C(A(
    r"\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?:in|by)\s+" + OUTLET + r"(?:\s*,\s*(?:and\s+)?|\s+and\s+)" + OUTLET,
    r"\b\d[\d,.]*\s*[kKmM]?\+?\s+(?:followers|subscribers)\b",
    r"\b(?:strong|active|robust|significant|notable)\s+(?:online|digital|social[\s-]media)\s+presence\b",
    r"\bwidely\s+covered\b", r"\bindependent\s+coverage\b",
), 0)
F11 = re.compile(F11.pattern, 0)
F11b = C(r"\b(?:strong|active|robust|significant|notable)\s+(?:online|digital|social[\s-]media)\s+presence\b|\bwidely\s+covered\b|\bindependent\s+coverage\b|\b\d[\d,.]*\s*[kKmM]?\+?\s+(?:followers|subscribers)\b")
F11a = re.compile(r"\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?:in|by)\s+" + OUTLET + r"(?:\s*,\s*(?:and\s+)?|\s+and\s+)" + OUTLET)
F12 = C(A(
    r"\bexperts?\s+(?:argue|believe|say|claim|note|suggest)\b",
    r"\bindustry\s+(?:reports?|observers?|analysts?)\b",
    r"\bobservers\s+have\s+(?:cited|noted)\b",
    r"\bsome\s+critics\s+argue\b", r"\bresearchers\s+have\s+found\b", r"\bstudies\s+suggest\b",
    r"\bit\s+is\s+widely\s+believed\b",
))
F13 = re.compile(r"\bThe (?:List|Index|Compilation|Collection|Catalogue|Catalog|Guide|Overview) of [A-Za-z0-9'’:,&-]+(?: [A-Za-z0-9'’:,&-]+){0,8}? (?:is|are) (?:a|an|the)\b")
F14 = C(A(
    r"\bplay(?:s|ed)?\s+an?\s+(?:vital|crucial|key|significant)\s+role\s+in\s+(?:its|the)\s+ecosystem\b",
    r"\bconservation\s+efforts\s+are\s+(?:underway|ongoing|in\s+place)\b",
    r"\bserves\s+as\s+an\s+indicator\s+species\b", r"\bcontributes?\s+to\s+biodiversity\b",
))
F15 = C(A(
    r"\bfrom\s+(?:the\s+)?(?:dawn|birth|earliest\s+days|inception|advent|emergence|humble)\b[^.!?\n]{0,120}?\bto\s+(?:the\s+)?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b",
    r"\bfrom\s+(?:the\s+)?humble\b[^.!?\n]{0,80}?\bto\s+(?:the\s+)?(?:mighty|towering|grand|sprawling)\b",
))
F16 = C(r",\s+(?:highlighting|reflecting|symbolizing|symbolising|emphasizing|emphasising|underscoring|showcasing|fostering|cultivating|encompassing|signaling|signalling|demonstrating|illustrating|representing|suggesting|indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing|epitomising)\b")
F17A = C(A(
    r"\bit's\s+not\s+(?:just|merely)\s+(?:about|an?)\b",
    r"\bnot\s+only\b[^.!?\n]{0,40}?\bbut\b",
    r"\bdoesn't\s+just\b[^,.\n]{0,40}?\bit\b",
))
F17B = C(r",\s+no\s+(?:guessing|waste|wasted\s+motion|hassle|fluff|stress|jargon)\b")
F18 = C(A(
    r"\b(?:no|not)\s+\w+,\s+(?:just|only|simply)\s+\w+",
    r"\b(?:not|isn't|aren't|wasn't|weren't)\s+(?:just|merely)\s+(?:(?:a|an|the)\s+)?\w+\s*(?:,|—|–|--?)\s*(?:it's|it\s+is|it\s+was|they're|they\s+are|they\s+were|that's|but)\b",
))
F19 = C(r"\b(?:in\s+order\s+to|due\s+to\s+the\s+fact\s+that|at\s+this\s+point\s+in\s+time|in\s+the\s+event\s+that|has\s+the\s+ability\s+to|it\s+is\s+important\s+to\s+note\s+that|it\s+should\s+be\s+mentioned\s+that|needless\s+to\s+say)\b")
F20 = C(A(
    r"\bit(?:'s|\s+is)\s+worth\s+(?:noting|mentioning)\s+that\b", r"\bit\s+bears\s+(?:noting|mentioning)\s+that\b",
    r"\bone\s+thing\s+to\s+(?:consider|keep\s+in\s+mind)\s+is\b", r"\bit\s+is\s+interesting\s+to\s+note\s+that\b",
    r"\ba\s+key\s+consideration\s+is\b", r"\ba\s+point\s+to\s+highlight\s+is\b",
))
F21 = C(r",\s+(?:raising\s+questions\s+about|prompting\s+reflection\s+on|sparking\s+debate\s+about|with\s+broader\s+implications\s+for|reshaping\s+our\s+understanding\s+of|paving\s+the\s+way\s+for|signaling\s+a\s+shift\s+toward|signalling\s+a\s+shift\s+toward)\b")
F22 = C(A(
    r"\bhere's\s+the\s+thing\b", r"\bmake\s+no\s+mistake\b", r"\bthe\s+truth\s+is\b", r"\blet's\s+be\s+honest\b",
    r"\bthe\s+simple\s+fact\s+is\b", r"\bat\s+its\s+core\b", r"\bwhat\s+really\s+matters\b", r"\bmore\s+than\s+anything\b",
    r"\bat\s+the\s+end\s+of\s+the\s+day\b", r"\bthe\s+bottom\s+line\s+is\b", r"\bin\s+reality\b", r"\bfundamentally,",
    r"\bthe\s+real\s+question\s+is\b", r"\bthe\s+heart\s+of\s+the\s+matter\b", r"\bthe\s+deeper\s+issue\b",
    r"\bwhen\s+you\s+get\s+down\s+to\s+it\b", r"\bwhen\s+all\s+is\s+said\s+and\s+done\b",
))
F23 = C(A(
    r"\bit(?:'s|\s+is)\s+important\s+to\s+(?:remember|note|understand|recognize|recognise)\b", r"\bone\s+must\s+note\s+that\b",
    r"\bit\s+is\s+worth\s+pointing\s+out\b", r"\bit\s+cannot\s+be\s+overstated\s+that\b", r"\bit\s+must\s+be\s+emphasi[sz]ed\s+that\b",
))
F24 = C(A(
    r"\bthis\s+comprehensive\s+(?:guide|overview|analysis)\b", r"\bthis\s+in-depth\s+(?:analysis|look|examination)\b",
    r"\bthis\s+complete\s+(?:guide|overview)\b", r"\ba\s+thorough\s+examination\s+of\b", r"\beverything\s+you\s+need\s+to\s+know\s+about\b",
))
F25 = re.compile(r"(?:^|(?<=[.!?]\s)|(?<=\n))(?:Do|Does|Did|Is|Are|Was|Were|Can|Could|Will|Would|Should|Shall|May|Might|Must|Has|Have|Had)\b[^.!?\n]{0,80}\?\s+(?:Yes|No|Absolutely|Never|Maybe|Probably|Always)[.!]")
F26 = C(A(
    r"\bwithout\s+concrete\s+(?:evidence|proof)\b", r"\bdo\s+you\s+have\s+concrete\s+(?:evidence|proof)\b",
    r"\bI\s+(?:would\s+)?need\s+concrete\s+(?:evidence|examples)\s+to\b", r"\babsent\s+concrete\s+(?:proof|evidence)\b",
    r"\bprovide\s+concrete\s+(?:evidence|proof)\b",
))
F27 = C(A(
    r"\bin\s+today's\s+(?:\w+\s+){0,2}(?:world|landscape|environment|market)\b", r"\bin\s+a\s+world\s+where\b", r"\bin\s+an\s+era\s+of\b",
    r"\bin\s+recent\s+years,", r"\bmore\s+than\s+ever\s+before\b", r"\bwe\s+live\s+in\s+a\s+(?:time|world)\s+when\b",
    r"\b(?:great|exciting|big)\s+news\s*[!:]", r"\bever\s+(?:wanted|wondered|dreamed|wished)\s+to\b[^.!?\n]*\?",
    r"\bin\s+an\s+increasingly\s+(?:interconnected|digital|competitive|complex)\s+world\b",
))
F30 = C(A(
    r"\bunlike\s+the\s+(?:previous|prior|old|earlier)\s+(?:version|release|implementation|approach)\b",
    r"\b(?:the|this)\s+(?:(?:latest|new)\s+)?(?:update|release|version|change|patch|design)\s+(?:adds|introduces|brings|delivers|includes|provides|improves)\b",
    r"\bha(?:s|ve)\s+been\s+(?:updated|refactored|improved|enhanced|changed)\s+to\b",
    r"\bpreviously\b[^.!?\n]{0,120}?\bnow\b", r"\b(?:wasn't|weren't)\s+there\s+before\b",
    r"\bwe(?:'ve|\s+have)\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)\b",
))
F31 = C(A(
    r"\blet's\s+(?:dive|delve|explore)\b", r"\blet's\s+break\s+(?:this|it)\s+down\b", r"\bhere's\s+what\s+you\s+need\s+to\s+know\b",
    r"\bwithout\s+further\s+ado\b", r"\bnow\s+let's\s+look\s+at\b", r"\bbuckle\s+up\b", r"\bstay\s+with\s+me\b",
    r"\b(?:are\s+you\s+)?ready\s+to\s+dive\s+in\b",
))
F32 = C(A(
    r"\b(?:used|uses|employs|employed|relied\s+on|utili[sz]es)\s+(?:several|various|a\s+number\s+of|multiple|different|many|numerous)\s+\w+",
    r"(?:^|(?<=[.!?]\s)|(?<=\n))These(?:\s+\w+)?\s+(?:provide|offer|give|reveal|show|allow|enable|help)\s+(?:\w+\s+)?(?:information|insight|insights|understanding|details|data)\b",
    r"\b(?:is|are|was|were|remains|becomes)\s+(?:the|a)\s+(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective\s+tissue)\s+of\b",
))
F36 = C(A(
    r"\bdespite\s+(?:these|its|the)\s+(?:challenges|obstacles)\b", r"\bchallenges\s+and\s+(?:future\s+)?(?:prospects|outlook|legacy)\b",
    r"\bcontinues\s+to\s+thrive\b", r"\btypical\s+of\s+(?:emerging|urban|modern)\b", r"\bfaces\s+(?:several|many|numerous)\s+challenges\b",
))
TRANS = re.compile(r"(?:^|(?<=[.!?]\s)|(?<=[.!?][\"')]\s)|(?<=\n))\s*(?:Additionally|Furthermore|Moreover|However|Nevertheless|Consequently|Subsequently|Notably)\b", re.M)
F38 = re.compile(r"^[ \t#>*_-]*(?:in conclusion|overall|in summary|to summarize|to conclude|all in all|in essence|ultimately)\b", re.I | re.M)
F39 = C(A(
    r"\bthe\s+future\s+looks\s+bright\b", r"\bexciting\s+times\s+lie\s+ahead\b", r"\bjourney\s+toward\s+excellence\b",
    r"\bstep\s+in\s+the\s+right\s+direction\b", r"\b(?:the\s+)?(?:outlook|future)(?:\s+for\s+[^.!?\n]{1,40}?)?\s+(?:is|looks|remains)\s+bright\b",
    r"\bwell[\s-]positioned\s+for\s+(?:whatever\s+comes\s+next|the\s+future|the\s+road\s+ahead)\b",
))
F47 = C(A(
    r"\bI\s+hope\s+this\s+helps\b", r"\bCertainly!", r"\bOf\s+course!", r"\blet\s+me\s+know\s+if\s+you\b", r"\bwould\s+you\s+like\s+me\s+to\b",
    r"\bfeel\s+free\s+to\s+(?:ask|reach\s+out)\b", r"\bhappy\s+to\s+help\s*[.!]",
    r"\b(?:here|below)\s+is\s+(?:an?|the)\s+(?:overview|summary|rundown|recap|brief)\b",
    r"\bhere\s+(?:are|'s)\s+(?:a\s+few|some|two|three)\s+(?:options|drafts|versions|variations)\b", r"\bhere's\s+(?:a\s+few|some|two|three)\s+(?:options|drafts|versions|variations)\b",
    r"\bhere\s+is\s+a\s+draft\b", r"\bhere's\s+a\s+draft\b", r"\bdepending\s+on\s+the\s+(?:vibe|tone|style)\b",
    r"\bI\s+hope\s+(?:this\s+email\s+)?finds\s+you\s+well\b",
    r"\bas\s+an?\s+(?:AI|LLM|AI\s+assistant|AI\s+language\s+model|large\s+language\s+model|language\s+model)\b",
    r"\bto\s+(?:answer|address)\s+your\s+question\b", r"\bin\s+(?:response|answer)\s+to\s+your\s+question\b",
    r"\byour\s+question\s+(?:about|regarding|concerning)\b", r"\bas\s+(?:you\s+)?(?:requested|asked),\s+here\b",
    r"\bhere\s+is\s+(?:the\s+)?(?:draft|first\s+pass|revised\s+version\s+of|for\s+your)\b",
))
F48 = C(A(
    r"\byou(?:'re|\s+are)\s+absolutely\s+right\b",
    r"\b(?:great\s+question|excellent\s+point)\s*[!.,]",
    r"\bwhat\s+an?\s+(?:thoughtful|great|wonderful|fantastic)\s+question\b",
    r"\bthat's\s+an?\s+(?:great|wonderful|fantastic|brilliant|excellent)\s+(?:point|question)\b",
))
F50 = C(A(
    r"\bas\s+of\s+my\s+(?:last\s+)?(?:training|knowledge)\b", r"\bup\s+to\s+my\s+(?:last\s+)?(?:training|knowledge)\b",
    r"\bwhile\s+specific\s+details\s+are\s+(?:limited|scarce|not\s+(?:extensively|widely)\s+documented)\b",
    r"\bbased\s+on\s+(?:the\s+)?available\s+information\b", r"\bas\s+of\s+my\s+(?:knowledge\s+)?cutoff\b",
    r"\bmaintains\s+a\s+low\s+profile\b", r"\bkeeps\s+(?:his|her|their)\s+personal\s+life\s+private\b",
))
F51 = C(A(
    r"\b(?:serves|stands|functions|acts)\s+as\b", r"\brepresents\s+(?:a|the)\b", r"\bmarks\s+(?:a|the)\b", r"\bboasts?\b",
    r"\bfeatures\s+(?:an?|the|\d+|several|many|numerous|multiple|a\s+number\s+of)\b", r"\boffers\s+a\b", r"\brefers\s+to\b",
))
HEDGE = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|somewhat|relatively|fairly)\b|\bseems?\s+(?:to|like)\b|\bappears?\s+to\b|\bkind\s+of\b|\bsort\s+of\b")
F69 = C(A(
    r"\bunlock(?:ing)?\s+(?:your\s+|its\s+|their\s+)?full\s+potential\b", r"\bnavigat(?:e|es|ing)\s+the\s+complexit(?:y|ies)\b",
    r"\ba\s+testament\s+to\s+the\s+(?:power|importance)\b", r"\bstay(?:s|ing)?\s+ahead\s+of\s+the\s+curve\b",
    r"\bturn(?:s|ing)?\s+challenges\s+into\s+opportunities\b", r"\btak(?:e|es|ing)\s+\w+\s+to\s+the\s+next\s+level\b",
    r"\bharness(?:es|ed|ing)?\s+the\s+power\s+of\b", r"\bpav(?:e|es|ed|ing)\s+the\s+way\s+for\b", r"\bsaying\s+goodbye\s+to\b",
    r"\bimagin(?:e|ing)\s+a\s+world\s+where\b", r"\bin\s+today's\s+fast-paced\s+world\b", r"\bthe\s+power\s+of\s+innovation\b",
    r"\bdrive\s+meaningful\s+change\b", r"\bunleash(?:ing)?\s+(?:the\s+)?(?:power|potential)\b",
    r"\bbridge\s+the\s+gap\s+between\b", r"\bone\s+step\s+at\s+a\s+time\s+toward\b",
))
EMOJI = re.compile("[\U0001F000-\U0001FAFF☀-➿⭐⭕⌚⌛⏩-⏳✅✨❤]")
HR = re.compile(r"^ {0,3}(?:-{3,}|\*{3,}|_{3,}|(?:-[ \t]){2,}-|(?:\*[ \t]){2,}\*)[ \t]*$", re.M)
BOLD = re.compile(r"\*\*[^*\n]+?\*\*")
BOLD_HDR = re.compile(r"^[ \t]*(?:[-*+][ \t]+|\d+[.)][ \t]+)?\*\*[^*\n]+?(?::\*\*|\*\*:)", re.M)
HEADING = re.compile(r"^ {0,3}#{1,6}[ \t]+(.+?)[ \t#]*$", re.M)
PH_BRACKET = re.compile(r"\[([^\[\]\n]{1,80})\](?![(\[])")
PH_START = re.compile(r"^\s*(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b", I)
PH_NAMES = re.compile(r"\b(?:person|company|client|place|source|name|city|recipient|organi[sz]ation|address)\b", I)
PH_CAPS = re.compile(r"^[A-Z][A-Z _/\-]{2,}[A-Z0-9]?$")
PH_OTHER = re.compile(r"\{\{[^{}\n]*\}\}|(?<![A-Za-z0-9])[xX]{3,}(?![A-Za-z0-9])|\blorem\s+ipsum\b", I)
F64 = re.compile(r"\bcite(?:turn|start|nav)\w*|\boai_citation\w*|contentReference|\bnavlist\b|【\d+[^】\n]*†[^】\n]*】")
UTM = re.compile(r"utm_source=([A-Za-z0-9.\-]+)", I)
AI_HOSTS = {"chatgpt.com", "chat.openai.com", "perplexity.ai", "claude.ai", "gemini.google.com", "copilot.microsoft.com", "poe.com"}
MINOR = set("a an the and but or nor for so yet of in on at by to up as per via off out from with into onto over than vs".split())
FIRST_P = re.compile(r"\b(?:I|me|my|mine|myself|we|us|our|ours|I'm|I've|I'll|I'd|we're|we've|we'll)\b", re.I)
CONTRACTED = re.compile(r"\b\w+(?:n't|'re|'ve|'ll|'d|'m)\b|\b(?:it|that|he|she|there|here|what|who|let)'s\b", re.I)
EXPANDED = re.compile(r"\b(?:do|does|did|is|are|was|were|have|has|had|will|would|should|could|can|must)\s+not\b|\bcannot\b|\b(?:I|we|you|they)\s+(?:am|are|have|will|would)\b|\b(?:it|that|he|she|there)\s+is\b|\blet\s+us\b", re.I)


# --------------------------------------------------------------------------
# analysis
# --------------------------------------------------------------------------
class Ctx(object):
    pass


def excerpt(raw, s, e, width=24):
    a = max(0, s - width)
    b = min(len(raw), e + width)
    seg = raw[a:b]
    seg = re.sub(r"[\r\n]", " ", seg)
    return ("..." if a > 0 else "") + seg + ("..." if b < len(raw) else "")


def short(s, n=80):
    s = re.sub(r"\s+", " ", s)
    return s if len(s) <= n else s[:n - 3] + "..."


def rx_hits(rx, text):
    return list(rx.finditer(text))


def mk(num, slug, label, kind, hits, raw=None, minc=1, samples=None, count=None):
    if samples is None:
        samples = []
        for h in hits[:3]:
            if raw is not None:
                samples.append(excerpt(raw, h.start(), h.end()))
            else:
                samples.append(short(h.group(0)))
    c = len(hits) if count is None else count
    return {"num": num, "slug": slug, "label": label, "kind": kind, "count": c, "samples": samples[:3]}


def split_sentences(par):
    out = []
    for piece in re.split(r"(?<=[.!?])[\"')\]]*\s+", par):
        piece = piece.strip()
        if piece and WORD_RE.search(piece):
            out.append(piece)
    return out


def paragraphs_of(t):
    return [p for p in re.split(r"\n\s*\n", t) if p.strip()]


def cv(vals):
    m = sum(vals) / float(len(vals))
    if m <= 0:
        return 99.0
    var = sum((v - m) ** 2 for v in vals) / float(len(vals))
    return math.sqrt(var) / m


def count_words(t):
    return len(WORD_RE.findall(t))


ADVICE = {4, 17, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68}
DECISIVE = {62, 63, 64, 65, 66, 13, 47, 50, 48}
RHYTHM = {40, 41, 44, 55}


def analyse(raw, mask=True):
    """Return list of finding dicts plus context info for a window of text."""
    ctx = Ctx()
    base = raw.replace("\r", " ").replace("’", "'").replace("‘", "'")
    prose = mask_text(base) if mask else base
    paras = paragraphs_of(prose)
    body_paras = []
    for p in paras:
        lines = [l for l in p.split("\n") if l.strip() and not re.match(r"^\s{0,3}#{1,6}\s", l)]
        if lines:
            body_paras.append("\n".join(lines))
    sentences = []
    for p in body_paras:
        sentences.extend(split_sentences(p))
    words = count_words(prose)
    F = []
    add = F.append
    H = lambda rx, t=prose: list(rx.finditer(t))

    # --- character layer on raw window
    inv = invisible_positions(raw)
    if inv:
        add({"num": 62, "slug": "invisible_characters", "label": "Invisible or zero-width characters", "kind": "score",
             "count": len(inv), "samples": ["U+%04X at offset %d" % (ord(raw[i]), i) for i in inv[:3]]})
    nss = nonstandard_space_positions(raw)
    if nss:
        add({"num": 67, "slug": "nonstandard_spaces", "label": "Non-standard space characters", "kind": "score",
             "count": len(nss), "samples": ["U+%04X at offset %d" % (ord(raw[i]), i) for i in nss[:3]]})
    hg = homoglyph_tokens(raw)
    if hg:
        add({"num": 66, "slug": "homoglyphs", "label": "Mixed-script homoglyph lookalikes", "kind": "score",
             "count": len(hg), "samples": [short(m.group(0), 40) for m in hg[:3]]})
    tw = 0
    tws = []
    for m in re.finditer(r"[ \t]+(?=\r?\n)", raw):
        tw += 1
        tws.append("trailing whitespace at offset %d" % m.start())
    if raw and raw[-1] in " \t":
        tw += 1
        tws.append("whitespace at end of text")
    if re.search(r"(?:\r?\n){2,}\Z", raw):
        tw += 1
        tws.append("blank lines at end of text")
    if raw and raw[0].isspace():
        tw += 1
        tws.append("whitespace before first character")
    if tw:
        add({"num": 68, "slug": "trailing_whitespace", "label": "Trailing or stray whitespace", "kind": "advice", "count": tw, "samples": tws[:3]})

    # --- lexical families
    h = H(F1)
    if h:
        add(mk(1, "ai_vocabulary", "AI vocabulary", "score", h, raw))
    h = H(F2)
    if len(h) >= 2:
        add(mk(2, "model_dialect_vocabulary", "Model-dialect vocabulary", "score", h, raw))
    h = H(F3)
    imp = H(IMPER)
    n_imp = 0
    for p in body_paras:
        for s in split_sentences(p):
            if re.match(r"(?:install|join|grab|download|try|discover|experience|escape|transform|reclaim|unlock|elevate|boost|say|imagine|explore|meet|introducing|upgrade|claim|unleash|supercharge|level|stop|start)\b", s, I):
                n_imp += 1
    if h or n_imp >= 3:
        hh = h
        add(mk(3, "promotional_language", "Promotional language", "score", hh, raw, count=len(h) + (n_imp if n_imp >= 3 else 0)))
    h = H(HYPH)
    if h:
        add(mk(4, "hyphenated_pairs", "Hyphenated word-pair overuse", "advice", h, raw))
    h = H(F5)
    if h:
        add(mk(5, "simple_yet", "Simple yet X cliche", "score", h, raw))
    # 6 adjective chains
    hits6 = []
    for m in CHAIN.finditer(prose):
        items = [x for x in re.split(r",\s+(?:(?:and|or)\s+)?|\s+(?:and|or)\s+", m.group(1)) if x]
        trailing = m.group(2)
        toks = items + ([trailing] if trailing else [])
        if len(toks) < 4:
            continue

        def adj(w):
            wl = w.lower()
            return wl in STOCK_ADJ or bool(ADJ_END.search(wl))
        if not any(adj(w) for w in items):
            continue
        last = toks[-1]
        if adj(last):
            continue
        hits6.append(m)
    if hits6:
        add(mk(6, "adjective_chains", "Stacked adjective chains", "score", hits6, raw))
    # 8 synonym cycling
    c8 = 0
    s8 = []
    for cl, rxs in zip(CLUSTERS, CLUSTER_RX):
        used = [cl[k] for k, rx in enumerate(rxs) if rx.search(prose)]
        if len(used) >= 3:
            c8 += 1
            s8.append("/".join(used))
    if c8:
        add({"num": 8, "slug": "synonym_cycling", "label": "Synonym cycling", "kind": "score", "count": c8, "samples": s8[:3]})
    h = H(F10)
    if h:
        add(mk(10, "significance_inflation", "Significance inflation", "score", h, raw))
    h = H(F11a, prose) + H(F11b)
    if h:
        add(mk(11, "notability_name_dropping", "Notability name-dropping", "score", h, raw))
    h = H(F12)
    if h:
        add(mk(12, "vague_attributions", "Vague attributions", "score", h, raw))
    h = list(F13.finditer(prose))
    if h:
        add(mk(13, "article_title_proper_noun", "Article title as proper noun", "score", h, raw))
    h = H(F14)
    if h:
        add(mk(14, "conservation_padding", "Conservation and ecosystem padding", "score", h, raw))
    h = H(F15)
    if h:
        add(mk(15, "false_ranges", "False ranges", "score", h, raw))
    h = H(F16)
    if h:
        add(mk(16, "ing_tail_clauses", "Superficial -ing tail clauses", "score", h, raw))
    h = H(F17A)
    if h:
        add(mk(17, "negative_parallelism", "Negative parallelism", "advice", h, raw))
    h = H(F17B)
    if h:
        add(mk(17, "tailing_negation", "Tailing negation", "advice", h, raw))
    h = H(F18)
    if h:
        add(mk(18, "not_x_just_y", "Not X, just Y", "score", h, raw))
    h = H(F19)
    if h:
        add(mk(19, "filler_phrases", "Filler phrases", "advice", h, raw))
    h = H(F20)
    if h:
        add(mk(20, "empty_pivot_phrases", "Empty pivot phrases", "score", h, raw))
    h = H(F21)
    if h:
        add(mk(21, "outcome_speculation_tails", "Outcome speculation tails", "score", h, raw))
    h = H(F22)
    if h:
        add(mk(22, "persuasive_authority_tropes", "Persuasive authority tropes", "advice", h, raw))
    h = H(F23)
    if h:
        add(mk(23, "editorial_interjections", "Editorial interjections", "score", h, raw))
    h = H(F24)
    if h:
        add(mk(24, "self_thoroughness", "Self-thoroughness phrases", "score", h, raw))
    h = H(F25)
    if h:
        add(mk(25, "question_answer_pattern", "Question-answer rhetorical pattern", "score", h, raw))
    h = H(F26)
    if h:
        add(mk(26, "concrete_evidence_defense", "Concrete evidence defense phrase", "score", h, raw))
    h = H(F27)
    if h:
        add(mk(27, "compulsive_intro_hooks", "Compulsive intro hooks", "score", h, raw))
    h = H(F30)
    if h:
        add(mk(30, "diff_anchored_writing", "Diff-anchored writing", "score", h, raw))
    h = H(F31)
    if h:
        add(mk(31, "signposting", "Signposting and announcements", "score", h, raw))
    h = H(F32)
    if h:
        add(mk(32, "cataloguing_lead_ins", "Cataloguing lead-ins", "score", h, raw))
    h = H(BOLD_HDR)
    if h:
        add(mk(33, "inline_header_lists", "Inline-header vertical lists", "score", h, raw))
    # 34 bullet injection
    has_heading = bool(re.search(r"^ {0,3}#{1,6}\s", prose, re.M))
    if not has_heading:
        list_p = 0
        prose_p = 0
        for p in paras:
            ls = [l for l in p.split("\n") if l.strip()]
            if ls and all(re.match(r"^\s*(?:[-*+]|\d+[.)])\s+", l) for l in ls):
                list_p += 1
            elif ls:
                prose_p += 1
        if list_p >= 1 and prose_p >= 2:
            add({"num": 34, "slug": "bullet_injection", "label": "Mid-essay bullet injection", "kind": "score", "count": list_p, "samples": ["bulleted paragraph in a document with no heading"]})
    # 35 fragmented headers
    lines = prose.split("\n")
    c35 = []
    for i, l in enumerate(lines):
        hm = re.match(r"^ {0,3}#{1,6}[ \t]+(.+?)[ \t#]*$", l)
        if not hm:
            continue
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j < len(lines):
            nl = lines[j].strip()
            if nl and not re.match(r"^(?:#|[-*+]\s|\d+[.)]\s|\|)", nl):
                nw = [w.lower() for w in WORD_RE.findall(nl)]
                hw = set(w.lower() for w in WORD_RE.findall(hm.group(1)) if len(w) >= 3)
                if 0 < len(nw) <= 4 and any(w in hw for w in nw):
                    c35.append(hm.group(1))
    if c35:
        add({"num": 35, "slug": "fragmented_headers", "label": "Fragmented headers", "kind": "score", "count": len(c35), "samples": [short(x, 60) for x in c35[:3]]})
    h = H(F36)
    if h:
        add(mk(36, "formulaic_challenges", "Formulaic challenges sections", "score", h, raw))
    # 37 transitions
    c37 = 0
    s37 = []
    for p in paras:
        ms = list(TRANS.finditer(p))
        if len(ms) >= 2:
            c37 += len(ms)
            s37.extend(short(m.group(0).strip(), 40) for m in ms[:2])
    if c37:
        add({"num": 37, "slug": "transition_clusters", "label": "Transition cluster overuse", "kind": "score", "count": c37, "samples": s37[:3]})
    h = H(F38)
    if h:
        add(mk(38, "compulsive_conclusions", "Compulsive conclusion phrases", "score", h, raw))
    h = H(F39)
    if h:
        add(mk(39, "generic_positive_conclusions", "Generic positive conclusions", "score", h, raw))
    # 40 / 41 / 42 / 44
    lens = [count_words(s) for s in sentences]
    if len(lens) >= 3 and cv(lens) < 0.35:
        add({"num": 40, "slug": "sentence_length_monotony", "label": "Sentence-length monotony", "kind": "score", "count": len(lens), "samples": ["sentence lengths vary little (cv %.2f)" % cv(lens)]})
    if len(lens) >= 6:
        run = 1
        best = 1
        for i in range(2, len(lens)):
            d1 = lens[i - 1] - lens[i - 2]
            d2 = lens[i] - lens[i - 1]
            if abs(d1) >= 5 and abs(d2) >= 5 and (d1 > 0) != (d2 > 0):
                run = run + 1 if run > 1 else 3
            else:
                run = 1
            best = max(best, run)
        if best >= 6:
            add({"num": 41, "slug": "mechanical_alternation", "label": "Mechanical sentence-length alternation", "kind": "advice", "count": 1, "samples": ["strict short-long alternation across %d sentences" % best]})
    c42 = 0
    for p in body_paras:
        ss = split_sentences(p)
        if len(ss) >= 3:
            firsts = {}
            for s in ss:
                w = [x.lower() for x in WORD_RE.findall(s)[:2]]
                if len(w) == 2:
                    firsts[tuple(w)] = firsts.get(tuple(w), 0) + 1
            for v in firsts.values():
                if v >= 3:
                    c42 += 1
    if c42:
        add({"num": 42, "slug": "opener_repetition", "label": "Opener repetition", "kind": "advice", "count": c42, "samples": ["three sentences open with the same two words"]})
    pw = [count_words(p) for p in body_paras if count_words(p) > 0]
    if len(pw) >= 4 and cv(pw) < 0.4:
        add({"num": 44, "slug": "uniform_paragraph_length", "label": "Uniform paragraph length", "kind": "score", "count": len(pw), "samples": ["paragraph lengths vary little (cv %.2f)" % cv(pw)]})
    # 46
    if words >= 300 and ";" not in prose and len(re.findall(r"\(", prose)) <= 1:
        add({"num": 46, "slug": "semicolon_parenthesis_underuse", "label": "Semicolon and parenthesis underuse", "kind": "advice", "count": 1, "samples": ["no semicolons and almost no parentheticals"]})
    h = H(F47)
    if h:
        add(mk(47, "chatbot_artifacts", "Chatbot artifacts", "score", h, raw))
    h = H(F48)
    if h:
        add(mk(48, "sycophantic_tone", "Sycophantic tone", "score", h, raw))
    h = H(F50)
    if h:
        add(mk(50, "knowledge_cutoff_disclaimer", "Knowledge-cutoff disclaimers", "score", h, raw))
    h = H(F51)
    if h:
        add(mk(51, "copula_avoidance", "Copula avoidance", "score", h, raw))
    # 54 hedges
    c54 = 0
    s54 = []
    for s in sentences:
        n = len(HEDGE.findall(s))
        if n >= 2:
            c54 += 1
            s54.append(short(s, 70))
    if c54:
        add({"num": 54, "slug": "hedge_stacking", "label": "Excessive hedging", "kind": "advice", "count": c54, "samples": s54[:3]})
    # 55 contractions
    if words:
        fp = len(FIRST_P.findall(prose))
        if fp / float(words) >= 0.03:
            ex = len(EXPANDED.findall(prose))
            co = len(CONTRACTED.findall(prose))
            if ex >= 3 and ex > co:
                add({"num": 55, "slug": "contraction_absence", "label": "Contraction absence", "kind": "advice", "count": ex, "samples": ["%d expandable forms written out, %d contracted" % (ex, co)]})
    h = H(BOLD)
    if h:
        add(mk(56, "boldface_overuse", "Boldface overuse", "score", h, raw))
    h = H(EMOJI)
    if h:
        add(mk(57, "emojis", "Emojis", "score", h, raw))
    c58 = 0
    for p in paras:
        n = p.count("—")
        if n >= 2:
            c58 += n
    if c58:
        add({"num": 58, "slug": "em_dash_overuse", "label": "Em-dash overuse", "kind": "advice", "count": c58, "samples": ["two or more em dashes in one paragraph"]})
    c59 = []
    for m in HEADING.finditer(prose):
        t = m.group(1).strip()
        t = re.sub(r"[*_`]", "", t)
        ws = t.split()
        if len(ws) < 3 or not t[0].isalpha() or (t.isupper()):
            continue
        major = [w for w in ws if w.lower().strip(".,:;!?") not in MINOR]
        if len(major) >= 2 and all(w[0].isupper() for w in major if w[0].isalpha()):
            c59.append(t)
    if c59:
        add({"num": 59, "slug": "title_case_headings", "label": "Title case in headings", "kind": "score", "count": len(c59), "samples": [short(x, 60) for x in c59[:3]]})
    cq = re.findall("[‘’“”]", raw)
    if cq:
        add({"num": 60, "slug": "curly_quotes", "label": "Curly quotation marks", "kind": "advice", "count": len(cq), "samples": ["typographic quotation marks"]})
    c61 = []
    for m in re.finditer(r"(?<![\d-])(1[5-9]\d\d|20\d\d)-(1[5-9]\d\d|20\d\d)(?![\d-])", prose):
        if int(m.group(2)) > int(m.group(1)):
            c61.append(m)
    if c61:
        add(mk(61, "hyphen_year_ranges", "Hyphen in numeric ranges", "advice", c61, raw))
    # 63 placeholders
    ph = []
    for m in PH_BRACKET.finditer(prose):
        inner = m.group(1)
        if PH_START.match(inner) or PH_NAMES.search(inner) and not re.match(r"^\d", inner):
            ph.append(m)
        elif PH_CAPS.match(inner) and len(re.findall(r"[A-Z]", inner)) >= 3:
            ph.append(m)
    ph += list(PH_OTHER.finditer(prose))
    if ph:
        add(mk(63, "placeholder_text", "Placeholder text", "score", ph, raw))
    h = H(F64)
    if h:
        add(mk(64, "chat_reference_markup", "Chatbot reference markup", "score", h, raw))
    c65 = []
    for m in UTM.finditer(prose):
        host = m.group(1).rstrip(".").lower()
        if host in AI_HOSTS:
            c65.append(m)
    if c65:
        add(mk(65, "ai_tracking_params", "AI tracking parameters", "score", c65, raw))
    h = H(F69)
    if h:
        add(mk(69, "marketing_slop", "Canonical marketing-slop phrases", "score", h, raw))
    hr = H(HR)
    if len(hr) >= 3 and len(prose.split("\n")) >= 24:
        add(mk(70, "decorative_rules", "Decorative horizontal rules", "score", hr, raw))
    # 71 repetition
    ws = [w.lower() for w in WORD_RE.findall(prose)]
    if len(ws) >= 12:
        grams = {}
        tot = len(ws) - 5
        for i in range(tot):
            g = tuple(ws[i:i + 6])
            grams[g] = grams.get(g, 0) + 1
        rep = sum(v for v in grams.values() if v > 1)
        if rep and rep / float(tot) >= 0.2:
            add({"num": 71, "slug": "degenerate_repetition", "label": "Degenerate repetition", "kind": "score", "count": rep, "samples": ["%d of %d six-word runs repeat" % (rep, tot)]})

    for f in F:
        if f["num"] in ADVICE:
            f["kind"] = "advice"
        elif f["num"] in DECISIVE:
            f["kind"] = "decisive"
        else:
            f["kind"] = "score"
    ctx.words = words
    ctx.sentences = sentences
    return F, ctx


def score_of(F, words):
    moving = [f for f in F if f["kind"] != "advice"]
    nums = set(f["num"] for f in moving)
    pts = 0.0
    for f in moving:
        w = 20.0 if f["kind"] == "decisive" else (12.0 if f["num"] == 1 else (6.0 if f["num"] in RHYTHM else 10.0))
        pts += w * (1 + 0.5 * min(f["count"] - 1, 4))
    s = int(round(min(100.0, pts)))
    if len(nums) <= 1:
        s = min(s, 40)
    if nums and nums <= RHYTHM:
        s = min(s, 40)
    if nums == {40}:
        s = min(s, 20)
    dec = nums & DECISIVE
    early = set(range(1, 40)) | set(range(47, 52)) | {69}
    if words < 120:
        k = len(nums & early)
        if k >= 3:
            s = max(s, 45)
        elif k >= 2:
            s = max(s, 25)
    if words >= 400:
        if len(nums) >= 6:
            s = max(s, 45)
        elif len(nums) >= 5:
            s = max(s, 25)
    if len(dec) >= 2:
        s = max(s, 65)
    elif len(dec) == 1:
        s = max(s, 45)
    return max(0, min(100, s)), len(nums)


def band_of(s):
    if s <= 20:
        return "clean"
    if s <= 40:
        return "light tells"
    if s <= 60:
        return "mixed"
    if s <= 80:
        return "heavy tells"
    return "pervasive tells"


def confidence_of(words, fams):
    if words < 40:
        return "none", "fewer than 40 words, too little text to score reliably"
    if words < 120:
        return "low", "fewer than 120 words, so the score is a rough guide"
    if words < 300 and fams == 1:
        return "low", "fewer than 300 words and only one scoring pattern family fired"
    if words < 300:
        return "moderate", "fewer than 300 words"
    return "high", ""


def build_report(raw_full, want_ci=False):
    truncated = len(raw_full) > WINDOW
    raw = raw_full[:WINDOW]
    F, ctx = analyse(raw)
    sc, fams = score_of(F, ctx.words)
    conf, reason = confidence_of(ctx.words, fams)
    rep = {}
    seen = {}
    for f in F:
        key = "%d_%s" % (f["num"], f["slug"])
        rep[key] = {"label": f["label"], "count": f["count"], "samples": f["samples"]}
    inv = next((f["count"] for f in F if f["num"] == 62), 0)
    nss = next((f["count"] for f in F if f["num"] == 67), 0)
    hg = next((f["count"] for f in F if f["num"] == 66), 0)
    met = {
        "scanned_chars": len(raw),
        "truncated": truncated,
        "ai_tell_score": sc,
        "ai_tell_band": band_of(sc),
        "confidence": conf,
        "confidence_reason": reason,
        "patterns_flagged": len(rep),
        "invisible_chars": inv,
        "nonstandard_spaces": nss,
        "homoglyphs": hg,
        "word_count": ctx.words,
        "score_families": fams,
    }
    if want_ci:
        sents = ctx.sentences
        if len(sents) >= 4:
            rnd = random.Random(20240601)
            nb = 20 if len(raw) < 40000 else (10 if len(raw) < 120000 else 5)
            vals = []
            for _ in range(nb):
                pick = [sents[rnd.randrange(len(sents))] for _ in sents]
                txt = "\n\n".join(pick) if False else " ".join(pick)
                F2_, c2 = analyse(txt, mask=False)
                vals.append(score_of(F2_, c2.words)[0])
            vals.sort()
            lo = vals[int(0.05 * (len(vals) - 1))]
            hi = vals[int(math.ceil(0.95 * (len(vals) - 1)))]
            lo = min(lo, sc)
            hi = max(hi, sc)
            met["score_ci"] = [float(lo), float(hi)]
            met["score_ci_note"] = "resampled over %d draws of the document's sentences" % nb
        else:
            met["score_ci"] = None
            met["score_ci_note"] = "too few sentences for an interval (at least 4 needed)"
    rep["_metrics"] = met
    return rep


# --------------------------------------------------------------------------
# main
# --------------------------------------------------------------------------
def main(argv):
    clean = False
    ci = False
    operands = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            operands.extend(argv[i + 1:])
            break
        if a in ("-h", "--help"):
            sys.stdout.write(USAGE)
            sys.stdout.flush()
            return 0
        if a == "--clean":
            clean = True
        elif a == "--ci":
            ci = True
        elif a.startswith("-") and a != "":
            fail(2, "unknown option: %s (try --help)" % a)
        else:
            operands.append(a)
        i += 1
    if len(operands) >= 2:
        sys.stderr.write("prosecheck: several files given (%s); scanning only the last one, %s\n" % (", ".join(operands), operands[-1]))
    if operands:
        path = operands[-1]
        try:
            text = extract_file(path)
        except Fail as e:
            fail(e.code, e.msg)
    else:
        b = sys.stdin.buffer.read()
        text = decode_bytes(b)
    if not text.strip():
        fail(1, "empty input")
    if clean:
        out = clean_text(text)
        sys.stdout.buffer.write(out.encode("utf-8", "replace"))
        sys.stdout.flush()
        return 0
    rep = build_report(text, ci)
    sys.stdout.buffer.write((json.dumps(rep, indent=2, ensure_ascii=False) + "\n").encode("utf-8", "replace"))
    sys.stdout.flush()
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except SystemExit:
        raise
    except BrokenPipeError:
        sys.exit(0)
    except RecursionError:
        fail(1, "cannot read input: input too deeply nested")
    except Exception as e:  # never a traceback
        fail(1, "cannot read input: %s" % e)
