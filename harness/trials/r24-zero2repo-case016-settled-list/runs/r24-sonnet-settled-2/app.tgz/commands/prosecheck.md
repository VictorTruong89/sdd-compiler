---
description: prosecheck - control the prose writing contract and saved-file guard
argument-hint: [lite|full|strict|off|on|status|show|check|doctor|stats|init|help]
---
/prosecheck $ARGUMENTS
