#!/usr/bin/env python3
"""prosecheck detector: local, standard-library-only prose-pattern scanner.

usage: detect.py [--clean] [--ci] [--] [FILE]
"""
import sys
import os
import re
import json
import math
import random
import time
import html
import zipfile
import unicodedata
from collections import Counter

WINDOW = 262144
USAGE = (
    "usage: detect.py [--clean] [--ci] [--] [FILE]\n"
    "\n"
    "Score prose for AI-writing patterns (catalogue of 71). Reads FILE or standard input.\n"
    "  --clean   print scrubbed text (invisible characters, odd spaces, lookalikes) instead of the report\n"
    "  --ci      add a resampled low/high interval on the score\n"
    "  --        stop option parsing (a file name may begin with a dash)\n"
    "  -h, --help  print this message\n"
)

PLAIN_EXT = {'.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'}
ZIP_EXT = {'.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'}
NOTEBOOK_EXT = {'.ipynb'}
NO_PROSE_EXT = {'.pdf', '.rtf'}
MEMBER_LIMIT = 64 * 1024 * 1024


class InputError(Exception):
    pass


# ---------------------------------------------------------------- character layer

VISIBLE_CF = set([0x600, 0x601, 0x602, 0x603, 0x604, 0x605, 0x6DD, 0x70F, 0x8E2, 0x110BD, 0x110CD])
DI_EXTRA = set([0x34F, 0x115F, 0x1160, 0x17B4, 0x17B5, 0x180B, 0x180C, 0x180D, 0x180E, 0x180F,
                0x2065, 0x3164, 0xFFA0])
for _c in range(0xFE00, 0xFE10):
    DI_EXTRA.add(_c)
for _c in range(0xFFF0, 0xFFF9):
    DI_EXTRA.add(_c)

CAND_RE = re.compile(r'[^\x00-\x7f]|[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]')
EMOJI_TAG_RE = re.compile('\U0001F3F4[\U000E0020-\U000E007E]+\U000E007F')
RTL_RE = re.compile('[֐-ࣿיִ-﷿ﹰ-ﻼ\U00010800-\U00010fff\U0001e800-\U0001efff]')

BIDI = set([0x200E, 0x200F, 0x061C, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E,
            0x2066, 0x2067, 0x2068, 0x2069])


def is_invisible(cp):
    if cp in (9, 10, 13):
        return False
    if cp < 0x20 or cp == 0x7F:
        return True
    if cp < 0x80:
        return False
    if 0xE0000 <= cp <= 0xE0FFF:
        return True
    ch = chr(cp)
    cat = unicodedata.category(ch)
    if cat == 'Cc':
        return True
    if cat == 'Cf':
        return cp not in VISIBLE_CF
    return cp in DI_EXTRA


def in_ranges(cp, ranges):
    for a, b in ranges:
        if a <= cp <= b:
            return True
    return False


CJK = [(0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xF900, 0xFAFF), (0x20000, 0x2FA1F), (0x3005, 0x3007),
       (0x2E80, 0x2FDF), (0x3021, 0x3029), (0x30000, 0x3134F)]
NOSPACE = CJK + [(0x0E00, 0x0EFF), (0x1780, 0x17FF), (0x1000, 0x109F), (0x3040, 0x30FF), (0x31F0, 0x31FF)]
JOINING = [(0x0590, 0x05FF), (0x0600, 0x06FF), (0x0750, 0x077F), (0x08A0, 0x08FF), (0xFB1D, 0xFDFF),
           (0xFE70, 0xFEFF), (0x0900, 0x0DFF), (0x1000, 0x109F), (0x1780, 0x17FF)]
KHMER = [(0x1780, 0x17FF)]
MONGOLIAN = [(0x1800, 0x18AF)]


def is_symbolic(cp):
    if cp >= 0x1F000 or 0x2600 <= cp <= 0x27BF or 0x2190 <= cp <= 0x21FF or 0x2B00 <= cp <= 0x2BFF:
        return True
    try:
        return unicodedata.category(chr(cp))[0] == 'S'
    except ValueError:
        return False


def is_vs(cp):
    return 0xFE00 <= cp <= 0xFE0F or 0xE0100 <= cp <= 0xE01EF


class CharInfo(object):
    pass


def keep_space(text, i, cp):
    """No-break space that holds something together."""
    if cp not in (0xA0, 0x202F):
        return False
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    if prev and prev.isdigit():
        return True
    if nxt and nxt.isdigit():
        return True
    if nxt and nxt in ':;!?»›%€':
        return True
    if prev and prev in '«‹':
        return True
    return False


def scan_chars(text):
    """Return (remove_set, space_idx_list, kept_tags...) describing the character layer.

    remove: set of indexes of invisible characters that do no job.
    spaces: list of indexes of non-standard spaces that get normalized.
    """
    n = len(text)
    remove = set()
    spaces = []
    keep_tag = set()
    for m in EMOJI_TAG_RE.finditer(text):
        for k in range(m.start() + 1, m.end()):
            keep_tag.add(k)
    rtl = None

    def prev_base(i):
        j = i - 1
        while j >= 0 and 0xFE00 <= ord(text[j]) <= 0xFE0F:
            j -= 1
        return ord(text[j]) if j >= 0 else None

    def next_base(i):
        j = i + 1
        while j < n and 0xFE00 <= ord(text[j]) <= 0xFE0F:
            j += 1
        return ord(text[j]) if j < n else None

    for m in CAND_RE.finditer(text):
        i = m.start()
        ch = text[i]
        cp = ord(ch)
        if cp >= 0x80 and not is_invisible(cp):
            if cp != 0x20 and cp != 0x85 and unicodedata.category(ch) == 'Zs':
                if not keep_space(text, i, cp):
                    spaces.append(i)
            continue
        if not is_invisible(cp):
            continue
        keep = False
        p = ord(text[i - 1]) if i > 0 else None
        q = ord(text[i + 1]) if i + 1 < n else None
        if 0xE0000 <= cp <= 0xE0FFF:
            keep = i in keep_tag
        elif cp in BIDI:
            if rtl is None:
                rtl = RTL_RE.search(text) is not None
            keep = rtl
        elif cp == 0x200B:
            keep = (p is not None and in_ranges(p, NOSPACE)) or (q is not None and in_ranges(q, NOSPACE))
        elif cp in (0x200C, 0x200D):
            pb = prev_base(i)
            nb = next_base(i)
            for b in (pb, nb):
                if b is not None and (in_ranges(b, JOINING) or is_symbolic(b)):
                    keep = True
        elif cp == 0xAD:
            keep = (i > 0 and text[i - 1].isalpha() and i + 1 < n and text[i + 1].isalpha())
        elif cp in (0x17B4, 0x17B5):
            keep = (p is not None and in_ranges(p, KHMER)) or (q is not None and in_ranges(q, KHMER))
        elif 0x180B <= cp <= 0x180F:
            keep = p is not None and in_ranges(p, MONGOLIAN)
        elif is_vs(cp):
            pb = prev_base(i) if cp >= 0xE0100 else (ord(text[i - 1]) if i > 0 else None)
            if pb is not None and (is_symbolic(pb) or in_ranges(pb, CJK)):
                keep = True
            elif i > 0 and 0xFE00 <= p <= 0xFE0F:
                keep = False
            if not keep and q == 0x20E3:
                keep = True
        if not keep:
            remove.add(i)
    return remove, spaces


# Latin lookalikes: Cyrillic, Greek, Armenian
HOMO = {
    'а': 'a', 'с': 'c', 'ԁ': 'd', 'е': 'e', 'һ': 'h', 'і': 'i',
    'ј': 'j', 'о': 'o', 'р': 'p', 'ѕ': 's', 'ѵ': 'v', 'ԝ': 'w',
    'х': 'x', 'у': 'y', 'ɡ': 'g',
    'А': 'A', 'В': 'B', 'С': 'C', 'Е': 'E', 'Н': 'H', 'І': 'I',
    'Ј': 'J', 'К': 'K', 'М': 'M', 'О': 'O', 'Р': 'P', 'Ѕ': 'S',
    'Т': 'T', 'Х': 'X', 'У': 'Y',
    'ο': 'o', 'ν': 'v', 'ρ': 'p', 'υ': 'u', 'ι': 'i', 'α': 'a',
    'χ': 'x',
    'Α': 'A', 'Β': 'B', 'Ε': 'E', 'Ζ': 'Z', 'Η': 'H', 'Ι': 'I',
    'Κ': 'K', 'Μ': 'M', 'Ν': 'N', 'Ο': 'O', 'Ρ': 'P', 'Τ': 'T',
    'Υ': 'Y', 'Χ': 'X',
    'օ': 'o', 'ո': 'n', 'ս': 'u', 'ց': 'g', 'հ': 'h', 'Օ': 'O',
    'Ս': 'S', 'Ն': 'N',
}
LETTER_RUN_RE = re.compile(r'[^\W\d_]+')
TOKEN_RE = re.compile(r'\S+')


def homoglyph_runs(text):
    """Return list of (index, ascii_replacement) for lookalike letters in matching tokens."""
    out = []
    for tm in TOKEN_RE.finditer(text):
        tok = tm.group(0)
        if tok.isascii():
            continue
        # any other non-ASCII letter makes the whole token ineligible
        bad = False
        for c in tok:
            if ord(c) > 127 and c not in HOMO and c.isalpha():
                bad = True
                break
        if bad:
            continue
        base = tm.start()
        for rm in LETTER_RUN_RE.finditer(tok):
            run = rm.group(0)
            if run.isascii():
                continue
            has_ascii = False
            has_look = False
            for c in run:
                if ord(c) < 128:
                    has_ascii = True
                elif c in HOMO:
                    has_look = True
            if has_ascii and has_look:
                for k, c in enumerate(run):
                    if c in HOMO:
                        out.append((base + rm.start() + k, HOMO[c]))
    return out


def clean_text(text):
    remove, spaces = scan_chars(text)
    homo = dict(homoglyph_runs(text))
    spaceset = set(spaces)
    out = []
    for i, ch in enumerate(text):
        if i in remove:
            continue
        if i in spaceset:
            out.append(' ')
        elif i in homo:
            out.append(homo[i])
        elif ch in '  ':
            out.append('\n')
        else:
            out.append(ch)
    s = ''.join(out)
    ended_nl = text.endswith('\n')
    ended_crlf = text.endswith('\r\n')
    # trim trailing whitespace on lines
    lines = re.split(r'(\r?\n)', s)
    res = []
    for k in range(0, len(lines), 2):
        line = lines[k]
        sep = lines[k + 1] if k + 1 < len(lines) else ''
        stripped = line.rstrip(' \t')
        trail = line[len(stripped):]
        if trail == '  ' and stripped.strip() and sep:
            stripped = line  # markdown hard break kept
        res.append(stripped)
        res.append(sep)
    s = ''.join(res)
    # leading blank lines
    s = re.sub(r'\A(?:[ \t]*\r?\n)+', '', s)
    s = s.rstrip(' \t\r\n\f\v')
    if ended_nl and s:
        s += '\r\n' if ended_crlf else '\n'
    return s


# ---------------------------------------------------------------- extraction

def decode_bytes(b):
    if b.startswith(b'\xef\xbb\xbf'):
        return b[3:].decode('utf-8', 'replace')
    if b.startswith(b'\xff\xfe') or b.startswith(b'\xfe\xff'):
        try:
            return b.decode('utf-16')
        except UnicodeDecodeError:
            return b.decode('utf-16', 'replace')
    t = b.decode('utf-8', 'replace')
    return t


def zread(z, name):
    info = z.getinfo(name)
    if info.file_size > MEMBER_LIMIT:
        return b''
    return z.read(name)


def natkey(s):
    return [int(p) if p.isdigit() else p for p in re.split(r'(\d+)', s)]


def xml_text(s):
    return html.unescape(s)


def extract_docx(z):
    names = [n for n in z.namelist() if n == 'word/document.xml']
    if not names:
        names = [n for n in z.namelist() if re.match(r'word/document\d*\.xml$', n)]
    paras = []
    for nm in names[:1]:
        x = zread(z, nm).decode('utf-8', 'replace')
        for pm in re.finditer(r'<w:p\b[^>]*?(?:/>|>(.*?)</w:p>)', x, re.S):
            body = pm.group(1) or ''
            parts = []
            for tm in re.finditer(r'<w:t\b[^>]*?(?:/>|>(.*?)</w:t>)|<w:tab\b[^>]*/>|<w:br\b[^>]*/>|<w:cr\b[^>]*/>',
                                  body, re.S):
                g = tm.group(0)
                if g.startswith('<w:tab'):
                    parts.append('\t')
                elif g.startswith('<w:br') or g.startswith('<w:cr'):
                    parts.append('\n')
                else:
                    parts.append(xml_text(tm.group(1) or ''))
            t = ''.join(parts)
            if t.strip():
                paras.append(t)
    return '\n\n'.join(paras)


def extract_pptx(z):
    slides = sorted([n for n in z.namelist() if re.match(r'ppt/slides/slide\d+\.xml$', n)], key=natkey)
    out = []
    for nm in slides:
        x = zread(z, nm).decode('utf-8', 'replace')
        paras = []
        for pm in re.finditer(r'<a:p\b[^>]*?(?:/>|>(.*?)</a:p>)', x, re.S):
            body = pm.group(1) or ''
            parts = []
            for tm in re.finditer(r'<a:t\b[^>]*?(?:/>|>(.*?)</a:t>)|<a:br\b[^>]*/>', body, re.S):
                g = tm.group(0)
                if g.startswith('<a:br'):
                    parts.append('\n')
                else:
                    parts.append(xml_text(tm.group(1) or ''))
            t = ''.join(parts)
            if t.strip():
                paras.append(t)
        if paras:
            out.append('\n'.join(paras))
    return '\n\n'.join(out)


def si_text(body):
    body = re.sub(r'<rPh\b.*?</rPh>', '', body, flags=re.S)
    return xml_text(''.join(m.group(1) or '' for m in re.finditer(r'<t\b[^>]*?(?:/>|>(.*?)</t>)', body, re.S)))


def extract_xlsx(z):
    shared = []
    if 'xl/sharedStrings.xml' in z.namelist():
        x = zread(z, 'xl/sharedStrings.xml').decode('utf-8', 'replace')
        for m in re.finditer(r'<si\b[^>]*?(?:/>|>(.*?)</si>)', x, re.S):
            shared.append(si_text(m.group(1) or ''))
    sheets = sorted([n for n in z.namelist() if re.match(r'xl/worksheets/[^/]+\.xml$', n)], key=natkey)
    out = []
    for nm in sheets:
        x = zread(z, nm).decode('utf-8', 'replace')
        cells = []
        for m in re.finditer(r'<c\b([^>]*?)(?:/>|>(.*?)</c>)', x, re.S):
            attrs = m.group(1)
            body = m.group(2) or ''
            tm = re.search(r'(?:^|\s)t="([^"]*)"', attrs)
            t = tm.group(1) if tm else 'n'
            val = None
            if t == 's':
                vm = re.search(r'<v>(.*?)</v>', body, re.S)
                if vm:
                    v = vm.group(1).strip()
                    if re.match(r'^\d+$', v) and int(v) < len(shared):
                        val = shared[int(v)]
            elif t == 'inlineStr':
                im = re.search(r'<is\b[^>]*>(.*?)</is>', body, re.S)
                if im:
                    val = si_text(im.group(1))
            elif t == 'str':
                vm = re.search(r'<v>(.*?)</v>', body, re.S)
                if vm:
                    val = xml_text(vm.group(1))
            if val is not None and val.strip():
                cells.append(val)
        if cells:
            out.append('\n'.join(cells))
    return '\n\n'.join(out)


def extract_odf(z):
    if 'content.xml' not in z.namelist():
        return ''
    x = zread(z, 'content.xml').decode('utf-8', 'replace')
    x = re.sub(r'<office:automatic-styles\b.*?</office:automatic-styles>', '', x, flags=re.S)
    x = re.sub(r'<office:font-face-decls\b.*?</office:font-face-decls>', '', x, flags=re.S)
    x = re.sub(r'<text:tracked-changes\b.*?</text:tracked-changes>', '', x, flags=re.S)
    x = re.sub(r'<text:s\b[^>]*?text:c="(\d+)"[^>]*/>', lambda m: ' ' * min(int(m.group(1)), 1000), x)
    x = re.sub(r'<text:s\b[^>]*/>', ' ', x)
    x = re.sub(r'<text:tab\b[^>]*/>', '\t', x)
    x = re.sub(r'<text:line-break\b[^>]*/>', '\n', x)
    x = re.sub(r'</text:(?:p|h)>', '\x00', x)
    x = re.sub(r'<[^>]+>', '', x)
    paras = [xml_text(p) for p in x.split('\x00')]
    paras = [p for p in paras if p.strip()]
    return '\n\n'.join(paras)


BLOCK_RE = re.compile(r'</?(?:p|div|h[1-6]|li|ul|ol|tr|table|blockquote|section|article|pre|hr|dd|dt|dl|figure|figcaption|aside|header|footer)\b[^>]*>', re.I)


def html_to_text(x):
    x = re.sub(r'<!--.*?-->', '', x, flags=re.S)
    x = re.sub(r'<(script|style|nav|head)\b.*?</\1\s*>', '', x, flags=re.S | re.I)
    x = re.sub(r'<br\b[^>]*>', '\n', x, flags=re.I)
    x = BLOCK_RE.sub('\x00', x)
    x = re.sub(r'<[^>]+>', '', x)
    x = html.unescape(x)
    paras = []
    for p in x.split('\x00'):
        p = re.sub(r'[ \t\r\f\v]+', ' ', p)
        p = re.sub(r' ?\n ?', '\n', p).strip()
        if p:
            paras.append(p)
    return '\n\n'.join(paras)


def extract_epub(z):
    names = z.namelist()
    docs = [n for n in names if re.search(r'\.(?:xhtml|html|htm)$', n, re.I)]
    order = []
    opf = [n for n in names if n.lower().endswith('.opf')]
    if opf:
        try:
            x = zread(z, opf[0]).decode('utf-8', 'replace')
            manifest = {}
            for m in re.finditer(r'<item\b([^>]*)/?>', x):
                a = m.group(1)
                i = re.search(r'\bid="([^"]*)"', a)
                h = re.search(r'\bhref="([^"]*)"', a)
                if i and h:
                    manifest[i.group(1)] = h.group(1)
            base = opf[0].rsplit('/', 1)[0] + '/' if '/' in opf[0] else ''
            from urllib.parse import unquote
            for m in re.finditer(r'<itemref\b[^>]*\bidref="([^"]*)"', x):
                h = manifest.get(m.group(1))
                if h:
                    p = base + unquote(h.split('#')[0])
                    if p in docs and p not in order:
                        order.append(p)
        except Exception:
            order = []
    for d in sorted(docs, key=natkey):
        if d not in order:
            order.append(d)
    out = []
    for nm in order:
        t = html_to_text(zread(z, nm).decode('utf-8', 'replace'))
        if t.strip():
            out.append(t)
    return '\n\n'.join(out)


def extract_notebook(b):
    try:
        data = json.loads(decode_bytes(b))
    except Exception:
        return ''
    if not isinstance(data, dict):
        return ''
    cells = data.get('cells')
    if not isinstance(cells, list):
        return ''
    out = []
    for c in cells:
        if not isinstance(c, dict) or c.get('cell_type') != 'markdown':
            continue
        src = c.get('source')
        if isinstance(src, list) and all(isinstance(s, str) for s in src):
            src = ''.join(src)
        if not isinstance(src, str):
            continue
        if src.strip():
            out.append(src.strip('\n'))
    return '\n\n'.join(out)


def extract_file(path):
    ext = os.path.splitext(path)[1].lower()
    try:
        with open(path, 'rb') as f:
            b = f.read()
    except (OSError, IOError) as e:
        raise InputError('cannot read input: %s' % (e.strerror or str(e)))
    if ext in NO_PROSE_EXT:
        return ''
    if ext in ZIP_EXT:
        import io
        try:
            z = zipfile.ZipFile(io.BytesIO(b))
        except (zipfile.BadZipFile, Exception) as e:
            raise InputError('cannot read input: not a readable zip archive (%s)' % path)
        try:
            if ext in ('.docx', '.docm'):
                t = extract_docx(z)
            elif ext in ('.pptx', '.pptm'):
                t = extract_pptx(z)
            elif ext in ('.xlsx', '.xlsm'):
                t = extract_xlsx(z)
            elif ext in ('.odt', '.odp', '.ods'):
                t = extract_odf(z)
            else:
                t = extract_epub(z)
        except (zipfile.BadZipFile, KeyError, RuntimeError, NotImplementedError, OSError, EOFError):
            raise InputError('cannot read input: not a readable zip archive (%s)' % path)
        return t.strip()
    if ext in NOTEBOOK_EXT:
        return extract_notebook(b).strip()
    return decode_bytes(b)


# ---------------------------------------------------------------- analysis helpers

WORD_RE = re.compile(r"(?:[^\W_]|['’\-])+")
APOS_TABLE = {0x2019: ord("'"), 0x2018: ord("'"), 0x201C: ord('"'), 0x201D: ord('"')}
FENCE_OPEN = re.compile(r'^( {0,3})(`{3,}|~{3,})(.*)$')
BADGE_RE = re.compile(r'^\s*(?:\[?!\[[^\]]*\]\([^)]*\)\]?(?:\([^)]*\))?\s*)+$')


def mask_text(t):
    lines = t.split('\n')
    n = len(lines)
    mask = [False] * n
    start = 0
    if n and lines[0].rstrip() == '---':
        for j in range(1, n):
            if lines[j].rstrip() in ('---', '...'):
                for k in range(j + 1):
                    mask[k] = True
                start = j + 1
                break
    fence = None
    for i in range(start, n):
        line = lines[i]
        if fence is None:
            m = FENCE_OPEN.match(line)
            if m:
                ch = m.group(2)[0]
                if ch == '`' and '`' in m.group(3):
                    pass
                else:
                    fence = (ch, len(m.group(2)))
                    mask[i] = True
                    continue
        else:
            mask[i] = True
            m = re.match(r'^ {0,3}(`+|~+)\s*$', line)
            if m and m.group(1)[0] == fence[0] and len(m.group(1)) >= fence[1]:
                fence = None
            continue
    # blockquote runs
    i = start
    while i < n:
        if not mask[i] and re.match(r'^ {0,3}>', lines[i]):
            j = i
            while j < n and not mask[j] and re.match(r'^ {0,3}>', lines[j]):
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    mask[k] = True
            i = j
        else:
            i += 1
    for i in range(start, n):
        if mask[i]:
            continue
        s = lines[i]
        if re.match(r'^\s*\|.*\|\s*$', s) or re.match(r'^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$', s):
            mask[i] = True
        elif BADGE_RE.match(s) and '![' in s:
            mask[i] = True
    out = [' ' * len(l) if mask[i] else l for i, l in enumerate(lines)]
    s = '\n'.join(out)

    def blank(m):
        return re.sub(r'[^\n]', ' ', m.group(0))
    s = re.sub(r'(?<!`)(`+)(?!`)((?:(?!\n[ \t]*\n).){1,2000}?)(?<!`)\1(?!`)', blank, s, flags=re.S)
    return s


def count_words(s):
    return len(WORD_RE.findall(s))


def split_paragraphs(m):
    return [p for p in re.split(r'\n[ \t]*\n', m) if p.strip()]


HEADING_LINE = re.compile(r'^\s{0,3}#{1,6}(?:\s|$)')
LIST_LINE = re.compile(r'^\s*(?:[-*+]|\d+[.)])\s+')
SENT_SPLIT = re.compile(r'(?<=[.!?])[\"\')\]”]*\s+(?=\S)')


def prose_paragraphs(m):
    """Paragraphs with heading lines dropped."""
    out = []
    for p in split_paragraphs(m):
        lines = [l for l in p.split('\n') if not HEADING_LINE.match(l) and not re.match(r'^\s*([-*_])(?:\s*\1){2,}\s*$', l)]
        t = '\n'.join(lines).strip()
        if t:
            out.append(t)
    return out


def sentences_of(par):
    par = re.sub(r'^\s*(?:[-*+]|\d+[.)])\s+', '', par, flags=re.M)
    par = re.sub(r'^\s*>\s?', '', par, flags=re.M)
    flat = re.sub(r'\s+', ' ', par).strip()
    return [s for s in SENT_SPLIT.split(flat) if count_words(s) > 0]


def cv(vals):
    mean = sum(vals) / float(len(vals))
    if mean == 0:
        return 99
    var = sum((v - mean) ** 2 for v in vals) / float(len(vals))
    return math.sqrt(var) / mean


def infl(w):
    w = w.strip()
    if ' ' in w:
        first, rest = w.split(' ', 1)
        return infl(first) + ' ' + rest
    if w.endswith('e'):
        b = w[:-1]
        return '%s(?:e|es|ed|ing|d)' % b
    if w.endswith('y'):
        return '(?:%s(?:s|ing)?|%s(?:ies|ied))' % (w, w[:-1])
    return '%s(?:s|es|ed|ing)?' % w


def vocab(words):
    return r"\b(?:%s)\b" % '|'.join(infl(w) for w in words)


def R(p, flags=re.I):
    return re.compile(p, flags)


AI_WORDS = ['additionally', 'align with', 'crucial', 'delve', 'tapestry', 'pivotal', 'vibrant', 'meticulous',
            'testament', 'underscore', 'intricate', 'intricacies', 'interplay', 'garner', 'bolster', 'foster',
            'showcase', 'emphasize', 'enduring', 'enhance', 'leverage', 'utilize', 'facilitate', 'encompass',
            'harness', 'holistic', 'paradigm', 'transformative', 'unprecedented', 'myriad', 'plethora', 'robust',
            'seamless', 'navigate', 'embark', 'craft', 'landscape', 'journey', 'realm', 'multifaceted', 'elevate',
            'empower', 'unlock']
RX_AI = [R(vocab(AI_WORDS)),
         R(r"\bcaptur(?:e|es|ed|ing) the (?:essence|spirit|imagination|heart|magic)\b")]

SPEC = []  # (num, slug, label, [regex], min_hits)


def add(num, slug, label, pats, min_hits=1, flags=re.I):
    SPEC.append((num, slug, label, [p if hasattr(p, 'finditer') else re.compile(p, flags) for p in pats], min_hits))


add(2, 'model_dialect', 'Model-dialect vocabulary', [
    r"\b(?:genuinely|fascinating|nuanced|thoughtfully|refreshingly|strikingly|compellingly)\b",
    r"\bquietly (?:powerful|profound|radical)\b",
    r"\bdeeply (?:human|personal|felt|unsettling)\b",
    r"\bresonat(?:e|es|ed|ing) deeply\b",
    r"\bgame[- ]chang(?:er|ers|ing)\b",
    r"\bsupercharg(?:e|es|ed|ing)\b", r"\bskyrocket(?:s|ed|ing)?\b", r"\bturbocharg(?:e|es|ed|ing)\b",
    r"\brevolutioniz(?:e|es|ed|ing)\b",
    r"\bdoubl(?:e|es|ed|ing) down on\b",
    r"\bdiv(?:e|es|ed|ing) deep(?:er)? into\b",
    r"\bunlock(?:s|ed|ing)? (?:the )?(?:power|potential|value)\b",
    r"\btak(?:e|es|ing|en)\b[^.!?\n]{0,40}\bto the next level\b",
], min_hits=2)
add(3, 'promotional', 'Promotional language', [
    r"\b(?:nestled|breathtaking|must-visit|stunning|picturesque|charming|idyllic|world-class|top-tier|unparalleled|"
    r"premier|esteemed organization|valuable asset|passion for excellence|proven track record|results-oriented|"
    r"wealth of experience|dynamic team|fast-paced environment|deeply passionate|perfectly situated|"
    r"(?:close|tight)-knit team|uniquely positioned to)\b",
    r"\bvibrant community\b", r"\brich cultural heritage\b", r"\bin the heart of\b",
    r"\bleading (?:provider|company|organization|expert|manufacturer|firm)\b",
    r"\bI am excited to (?:apply|bring)\b",
])
add(5, 'simple_yet', '"Simple yet X" cliche', [
    r"\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b"])
add(10, 'significance_inflation', 'Significance inflation', [
    r"\b(?:stands?|serves?|stood|served) as an? (?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b",
    r"\b(?:stands?|serves?|stood|served) as the (?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b",
    r"\b(?:underscor|highlight)(?:es|ed|ing)? (?:its|the|their|his|her) (?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b",
    r"\breflect(?:s|ed|ing)? a broader (?:trend|shift|pattern)\b",
    r"\bmark(?:s|ed|ing)? a (?:turning point|milestone|watershed|new chapter|new era)\b",
    r"\bsymbolizes\b", r"\bsets? the stage for\b", r"\bleft an indelible mark\b",
    r"\bplays? an? (?:crucial|pivotal|vital|key|central|significant) role\b",
    r"\bhas (?:shaped|sparked)\b", r"\bhas come to (?:define|symbolize)\b",
])
add(12, 'vague_attributions', 'Vague attributions', [
    r"\bexperts (?:argue|believe|say|claim|note|suggest)\b",
    r"\bindustry (?:reports|observers|analysts)\b", r"\bobservers have (?:cited|noted)\b",
    r"\bsome critics argue\b", r"\bresearchers have found\b", r"\bstudies suggest\b",
    r"\bit is widely believed\b"])
add(13, 'article_title_proper_noun', 'Article title as proper noun', [
    re.compile(r"\bThe (?:List|Index|Compilation|Collection|Catalogue|Guide|Overview) of [^.!?\n]{1,80}? (?:is|are) (?:a|an|the)\b")])
add(14, 'conservation_padding', 'Conservation / ecosystem padding', [
    r"\bplays? an? (?:vital|crucial|key|significant) role in (?:its|the) ecosystem\b",
    r"\bconservation efforts are (?:underway|ongoing|in place)\b",
    r"\bserves as an indicator species\b", r"\bcontributes to biodiversity\b"])
add(15, 'false_ranges', 'False ranges', [
    r"\bfrom the (?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?\n]{0,120}?\bto the (?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b",
    r"\bfrom (?:the )?humble\b[^.!?\n]{0,120}?\bto (?:the )?(?:mighty|towering|grand|sprawling)\b"])
add(16, 'ing_tails', 'Superficial -ing tail clauses', [
    r",\s+(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|fostering|cultivating|"
    r"encompassing|signaling|demonstrating|illustrating|representing|suggesting|indicating|reinforcing|"
    r"leveraging|aligning|embodying|exemplifying|epitomizing)\b"])
add(18, 'not_x_just_y', '"Not X, just Y"', [
    r"\b(?:no|not) (?:a |an |the )?\w+, (?:just|only|simply) \w+",
    r"\b(?:not|isn't|aren't|wasn't|weren't) (?:just|merely)(?: (?:a|an|the))? \w+\s*(?:,|—|–|--)\s*(?:it's|it is|it was|they're|they are|they were|that's|but)\b"])
add(20, 'empty_pivots', 'Empty pivot phrases', [
    r"\bit's (?:worth|bears) (?:noting|mentioning) that\b", r"\bit is worth (?:noting|mentioning) that\b",
    r"\bit bears (?:noting|mentioning) that\b",
    r"\bone thing to (?:consider|keep in mind) is\b", r"\bit is interesting to note that\b",
    r"\ba key consideration is\b", r"\ba point to highlight is\b"])
add(21, 'outcome_speculation', 'Outcome-speculation tails', [
    r",\s+(?:raising questions about|prompting reflection on|sparking debate about|with broader implications for|"
    r"reshaping our understanding of|paving the way for|signaling a shift toward)\b"])
add(23, 'editorial_interjections', 'Editorial interjections', [
    r"\bit(?:'s| is) important to (?:remember|note|understand|recognize)\b", r"\bone must note that\b",
    r"\bit is worth pointing out\b", r"\bit cannot be overstated that\b", r"\bit must be emphasized that\b"])
add(24, 'self_thoroughness', 'Self-thoroughness phrases', [
    r"\bthis (?:comprehensive|complete) (?:guide|overview|analysis)\b",
    r"\bthis in-depth (?:analysis|look|examination)\b", r"\bthis comprehensive (?:guide|overview|analysis)\b",
    r"\ba thorough examination of\b", r"\beverything you need to know about\b"])
add(25, 'question_answer', 'Question-answer rhetorical pattern', [
    r"\b(?:Is|Are|Do|Does|Did|Can|Could|Will|Would|Should|Has|Have|Was|Were|Might|May|Must)\b[^.?!\n]{0,80}\?\s+"
    r"(?:Yes|No|Absolutely|Never|Maybe|Probably|Always)[.!](?=\s|$)"])
add(26, 'concrete_evidence', '"Concrete evidence" defense phrase', [
    r"\bwithout concrete evidence\b", r"\bdo you have concrete evidence\b",
    r"\bI (?:would )?need concrete (?:evidence|examples) to\b", r"\babsent concrete proof\b",
    r"\bprovide concrete evidence\b"])
add(27, 'intro_hooks', 'Compulsive intro hooks', [
    r"\bin today's (?:\w+ ){0,2}(?:world|landscape|environment|market)\b", r"\bin a world where\b",
    r"\bin an era of\b", r"\bin recent years,", r"\bmore than ever before\b",
    r"\bwe live in a (?:time|world) (?:when|where)\b", r"\b(?:great|exciting|big) news[!:]",
    r"\bever (?:wanted|wondered|dreamed|wished) to\b[^.?!\n]*\?",
    r"\bin an increasingly (?:interconnected|digital|competitive|complex) world\b"])
add(30, 'diff_anchored', 'Diff-anchored writing', [
    r"\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)\b",
    r"\b(?:the|this) (?:(?:latest|new) )?(?:update|release|version|change|patch|design) (?:adds|introduces|brings|delivers|includes|provides|improves)\b",
    r"\b(?:has|have) been (?:updated|refactored|improved|enhanced|changed) to\b",
    r"\bpreviously\b[^.!?\n]{0,100}\bnow\b", r"\b(?:wasn't|weren't) there before\b",
    r"\bwe(?:'ve| have) (?:now )?(?:added|removed|replaced|refactored|migrated)\b"])
add(31, 'signposting', 'Signposting and announcements', [
    r"\blet's (?:dive|delve|explore)\b", r"\blet's break (?:this|it) down\b", r"\bhere's what you need to know\b",
    r"\bwithout further ado\b", r"\bnow let's look at\b", r"\bbuckle up\b", r"\bstay with me\b",
    r"\b(?:are you )?ready to dive in\b"])
add(32, 'cataloguing_leadins', 'Cataloguing lead-ins', [
    r"\b(?:used|uses|employs|employed|relied on|utilizes) (?:several|various|a number of|multiple|different|many|numerous) \w+",
    r"(?:^|(?<=[.!?]\s))These(?: \w+)? (?:provide|offer|give|reveal|show|allow|enable|help) (?:information|insight|insights|understanding|details|data)\b",
    r"\b(?:is|are|was|were|remains|becomes) (?:the|a) (?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective tissue) of\b"], flags=re.I | re.M)
add(36, 'formulaic_challenges', 'Formulaic challenges section', [
    r"\bdespite (?:these|its|the) (?:challenges|obstacles)\b", r"\bchallenges and (?:future )?(?:prospects|outlook|legacy)\b",
    r"\bcontinues to thrive\b", r"\btypical of (?:emerging|urban|modern)\b",
    r"\bfaces (?:several|many|numerous) challenges\b"])
add(39, 'generic_positive_conclusions', 'Generic positive conclusions', [
    r"\bthe future looks bright\b", r"\bexciting times lie ahead\b", r"\bjourney toward excellence\b",
    r"\bstep in the right direction\b", r"\b(?:the )?(?:outlook|future)(?: for [^.!?\n]{1,40})? (?:is|looks|remains) bright\b",
    r"\bwell[- ]positioned for (?:whatever comes next|the future|the road ahead)\b"])
add(47, 'chatbot_artifacts', 'Chatbot artifacts', [
    r"\bI hope this helps\b", r"\b(?:Certainly|Of course)!", r"\blet me know if you\b", r"\bwould you like me to\b",
    r"\bfeel free to (?:ask|reach out)\b", r"\bhappy to help\s*(?:[.!]|$)",
    r"\b(?:here|below) is (?:a|an|the) (?:overview|summary|rundown|recap|brief)\b",
    r"\bhere (?:are|is)(?: a few| some| two| three)? (?:options|drafts|versions|variations)\b",
    r"\bhere's (?:a few|some|two|three) (?:options|drafts|versions|variations)\b",
    r"\bhere(?: is|'s) a draft\b", r"\bdepending on the (?:vibe|tone|style)\b",
    r"\bI hope (?:this email )?finds you well\b",
    r"\bas an? (?:AI|LLM|AI assistant|AI language model|large language model|language model)\b",
    r"\bto (?:answer|address) your question\b", r"\bin (?:response|answer) to your question\b",
    r"\byour question (?:about|regarding|concerning)\b", r"\bas (?:you )?(?:requested|asked), here\b",
    r"\bhere is (?:the )?(?:draft|first pass|revised version of|for your)\b"])
add(48, 'sycophantic_tone', 'Sycophantic tone', [
    r"\byou(?:'re| are) absolutely right\b",
    r"\b(?:great question|excellent point)\s*[!.,]",
    r"\bwhat an? (?:thoughtful|great|wonderful|fantastic) question\s*[!.,]",
    r"\bthat's an? (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\s*[!.,]"])
add(50, 'knowledge_cutoff', 'Knowledge-cutoff disclaimers', [
    r"\bas of my (?:last )?(?:training|knowledge)\b", r"\bup to my (?:last )?(?:training|knowledge)\b",
    r"\bwhile specific details are (?:limited|scarce|not (?:extensively|widely) documented)\b",
    r"\bbased on (?:the )?available information\b", r"\bas of my (?:knowledge )?cutoff\b",
    r"\bmaintains a low profile\b", r"\bkeeps (?:his|her|their) personal life private\b"])
add(51, 'copula_avoidance', 'Copula avoidance', [
    r"\b(?:serves|stands|functions|acts) as\b", r"\brepresents (?:a|the)\b", r"\bmarks (?:a|the)\b",
    r"\bboast(?:s|ed|ing)?\b",
    r"\bfeatures (?:a|an|the|\d+|several|many|numerous|multiple|various|some|two|three|four|five)\b",
    r"\boffers a\b", r"\brefers to\b"])
add(63, 'placeholder', 'Placeholder text', [
    re.compile(r"\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]{0,60}\](?![(\[])", re.I),
    re.compile(r"\[[^\]\n]{0,30}\b(?:person|company|client|place|source|city|location|name)\b[^\]\n]{0,30}\](?![(\[])", re.I),
    re.compile(r"\[(?=[A-Z0-9 _\-]*[A-Z]{3})[A-Z][A-Z0-9 _\-]{2,40}\](?![(\[])"),
    re.compile(r"\{\{[^}\n]{0,80}\}\}"),
    re.compile(r"(?<![A-Za-z])[xX]{3,}(?![A-Za-z])"),
    re.compile(r"lorem ipsum", re.I)])
add(64, 'chat_reference_markup', 'Chatbot reference-markup leak', [
    re.compile(r"\bcite(?:turn|start|nav)\w*"), re.compile(r"\boai_citation\w*"), re.compile(r"contentReference"),
    re.compile(r"navlist"), re.compile(u"【\\d+†[^】]*】")])
add(69, 'marketing_slop', 'Canonical marketing-slop phrases', [
    r"\bunlock(?:ing|s|ed)? (?:its |their |your |the )?full potential\b",
    r"\bnavigat(?:e|es|ed|ing) the complexities\b",
    r"\ba testament to the (?:power|importance)\b", r"\bstaying ahead of the curve\b",
    r"\bturning challenges into opportunities\b", r"\btak(?:e|es|ing) (?:\w+ ){1,3}to the next level\b",
    r"\bharness(?:es|ed|ing)? the power of\b", r"\bpav(?:e|es|ed|ing) the way for\b",
    r"\bsaying goodbye to\b", r"\bimagin(?:e|ing) a world where\b",
    r"\bgame-changing solutions?\b", r"\bseamless(?:ly)? integrat", r"\bone-stop shop\b",
    r"\bcutting-edge solutions?\b", r"\bempower(?:s|ing)? (?:businesses|teams|organizations|users)\b"])
add(4, 'hyphenated_pairs', 'Hyphenated word-pair overuse', [
    r"\b(?:cutting-edge|state-of-the-art|best-in-class|results-driven|data-driven|detail-oriented|forward-thinking|"
    r"game-changing|mission-critical|next-generation|end-to-end|full-service|high-performance|customer-centric|"
    r"cross-functional|value-added|well-rounded|thought-provoking|ever-evolving|ever-changing|far-reaching|"
    r"top-notch|tried-and-true|user-friendly|fast-growing|all-in-one|innovative-minded|self-starter|"
    r"results-focused|goal-oriented|team-oriented|highly-motivated|hard-working|world-leading)\b"])
add(19, 'filler_phrases', 'Filler phrases', [
    r"\bin order to\b", r"\bdue to the fact that\b", r"\bat this point in time\b", r"\bin the event that\b",
    r"\bhas the ability to\b", r"\bit is important to note that\b", r"\bit should be mentioned that\b",
    r"\bneedless to say\b"])
add(22, 'authority_tropes', 'Persuasive authority tropes', [
    r"\bhere's the thing\b", r"\bmake no mistake\b", r"\bthe truth is\b", r"\blet's be honest\b",
    r"\bthe simple fact is\b", r"\bat its core\b", r"\bwhat really matters\b", r"\bmore than anything\b",
    r"\bat the end of the day\b", r"\bthe bottom line is\b", r"\bin reality\b", r"\bfundamentally,",
    r"\bthe real question is\b", r"\bthe heart of the matter\b", r"\bthe deeper issue\b",
    r"\bwhen you get down to it\b", r"\bwhen all is said and done\b"])
add(17, 'negative_parallelism', 'Negative parallelism', [
    r"\bit's not (?:just|merely) (?:about|an?)\b",
    r"\bnot only\b[^.!?\n]{0,40}\bbut\b",
    r"\bdoesn't just\b[^,.\n]{0,40}\bit\b"])
add(11, 'notability_name_dropping', 'Notability name-dropping', [
    r"\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased) (?:in|by) [A-Z][\w.&'-]*(?: [A-Z][\w.&'-]*)*(?:,| and) (?:and )?[A-Z][\w.&'-]*",
    r"\b[\d,.]+[kKmM]? (?:followers|subscribers)\b",
    r"\b(?:strong|active) (?:online|digital|social[- ]media) presence\b",
    r"\bwidely covered\b", r"\bindependent coverage\b"], flags=0)


def spec_fix_case():
    pass


SPEC_TAIL = ('17_tail', 'negative_parallelism_tail', 'Tailing negation')
RX_TAIL = re.compile(r"[^.!?\n]{3,},\s+no (?:guessing|waste|wasted motion|hassle|fluff|stress|jargon)\b", re.I)

TRANSITIONS = r"(?:Additionally|Furthermore|Moreover|However|Nevertheless|Consequently|Subsequently|Notably)"
RX_TRANS = re.compile(r"(?:^|(?<=[.!?])[ \t]+)(" + TRANSITIONS + r")\b", re.M)
RX_CONCL = re.compile(r"^[ \t]*(?:[-*>][ \t]*)?(?:in conclusion|overall|in summary|to summarize|to conclude|all in all|in essence|ultimately)\b", re.I | re.M)

SYN_CLUSTERS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]


def plural_rx(w):
    if w.endswith('y'):
        return r"(?:%s|%sies)" % (w, w[:-1])
    if w.endswith('is') or w.endswith('s'):
        return r"%s(?:es)?" % w
    return r"%ss?" % w


SYN_RX = [[(w, re.compile(r"\b" + plural_rx(w) + r"\b", re.I)) for w in c] for c in SYN_CLUSTERS]
# analysis -> 'analyses'
SYN_RX[3][3] = ('analysis', re.compile(r"\b(?:analysis|analyses)\b", re.I))

HEDGES = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|somewhat|relatively|fairly)\b|"
                    r"\b(?:seems?|appears?)(?: to| like)\b|\bkind of\b|\bsort of\b")
IMPERATIVES = set(['install', 'join', 'grab', 'download', 'try', 'discover', 'experience', 'escape', 'transform',
                   'reclaim', 'unlock', 'elevate', 'boost', 'say', 'imagine', 'explore', 'meet', 'introducing',
                   'upgrade', 'claim', 'unleash', 'supercharge', 'level', 'stop', 'start'])
ADJ_SUFFIX = ('ive', 'ous', 'able', 'ible', 'ic', 'ical', 'ant', 'ent', 'ful', 'less', 'al', 'ial', 'ary', 'ory', 'ish')
STOCK_ADJ = set(['innovative', 'powerful', 'seamless', 'robust', 'dynamic', 'cutting-edge', 'modern', 'bold',
                 'elegant', 'sleek', 'stunning', 'exciting', 'vibrant', 'rich', 'compelling', 'comprehensive',
                 'scalable', 'reliable', 'fast', 'intuitive', 'flexible', 'efficient', 'smart', 'simple',
                 'secure', 'beautiful', 'unique', 'versatile', 'engaging', 'transformative'])
CHAIN_RX = re.compile(r"\b((?:[A-Za-z][A-Za-z-]*,\s+){2,}(?:and\s+)?[A-Za-z][A-Za-z-]*(?:\s+[A-Za-z][A-Za-z-]*)?)")
FIRST_PERSON = re.compile(r"\b(?:I|me|my|mine|myself|we|our|ours|us|ourselves)\b", re.I)
UNCONTRACTED = re.compile(r"\b(?:do not|does not|did not|is not|are not|was not|were not|cannot|can not|will not|would not|"
                          r"should not|could not|have not|has not|had not|it is|that is|there is|I am|I will|I have|I would|"
                          r"we are|we will|we have|they are|you are|let us)\b", re.I)
CONTRACTED = re.compile(r"\b\w+(?:n't|'re|'ve|'ll|'d|'m|'s)\b|\b(?:can't|won't)\b", re.I)
EMOJI_RX = re.compile('[\U0001F300-\U0001FAFF\U0001F000-\U0001F2FF☀-➿⭐⭕⌚⌛⏩-⏳✅❌❤]')
HR_RX = re.compile(r"^ {0,3}([-*_])(?:[ \t]*\1){2,}[ \t]*$")


def band_of(score):
    if score <= 20:
        return 'clean'
    if score <= 40:
        return 'light tells'
    if score <= 60:
        return 'mixed'
    if score <= 80:
        return 'heavy tells'
    return 'pervasive tells'


DECISIVE = set([62, 63, 64, 65, 66, 13, 47, 50, 48])
ADVICE = set([4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68, 17])
WEIGHTS = {1: 14, 40: 6, 44: 8, 37: 8, 51: 6, 56: 6, 57: 6, 59: 6, 70: 6, 6: 8, 8: 8, 15: 8, 33: 8, 34: 8, 35: 8,
           67: 8}
SHORT_GROUP = set(list(range(1, 40)) + [47, 48, 49, 50, 51, 69])
RHYTHM = set([40, 44])


def short_sample(s, n=80):
    s = re.sub(r'\s+', ' ', s).strip()
    return s if len(s) <= n else s[:n - 1] + '…'


def excerpt(raw, a, b, ctx=40):
    s = max(0, a - ctx)
    e = min(len(raw), b + ctx)
    t = raw[s:e].replace('\r', ' ').replace('\n', ' ')
    if s > 0:
        t = '...' + t
    if e < len(raw):
        t = t + '...'
    return t


def analyze(window, raw_chars=None):
    """Return (findings, metrics) for a window of text."""
    findings = {}   # key -> dict
    order = []

    def put(num, slug, label, count, samples):
        if count <= 0:
            return
        key = '%d_%s' % (num, slug)
        findings[key] = {'label': label, 'count': count, 'samples': samples[:3]}

    norm = window.replace('\r\n', '\n').replace('\r', '\n')
    # ---- character layer (on raw window)
    remove, spaces = scan_chars(window)
    homo = homoglyph_runs(window)
    n_inv = len(remove)
    n_sp = len(spaces)
    n_homo = len(homo)
    if n_inv:
        cps = Counter('U+%04X' % ord(window[i]) for i in sorted(remove)[:2000])
        put(62, 'invisible_chars', 'Invisible / zero-width characters', n_inv,
            ['%s x%d' % (k, v) for k, v in cps.most_common(3)])
    if n_homo:
        samples = []
        for tm in TOKEN_RE.finditer(window):
            tk = tm.group(0)
            if not tk.isascii() and any(c in HOMO for c in tk):
                if any(tm.start() <= i < tm.end() for i, _ in homo[:200]):
                    samples.append(short_sample(tk))
                    if len(samples) >= 3:
                        break
        put(66, 'homoglyphs', 'Homoglyph / mixed-script confusables', n_homo, samples)
    if n_sp:
        cps = Counter('U+%04X' % ord(window[i]) for i in spaces[:2000])
        put(67, 'nonstandard_spaces', 'Non-standard spaces', n_sp, ['%s x%d' % (k, v) for k, v in cps.most_common(3)])
    # 68 trailing whitespace
    tw = len(re.findall(r'[ \t]+(?=\r?\n)', window))
    if re.search(r'[ \t]\Z', window):
        tw += 1
    if re.search(r'(?:\r?\n){2,}\Z', window):
        tw += 1
    if re.match(r'\s', window):
        tw += 1
    put(68, 'trailing_whitespace', 'Trailing / stray whitespace', tw, ['trailing or stray whitespace'])

    # ---- masked text for lexical rules
    m = mask_text(norm).translate(APOS_TABLE)
    # curly quotes counted from raw
    cq = len(re.findall('[‘’“”]', norm))
    put(60, 'curly_quotes', 'Curly quotation marks', cq, ['curly quotation marks'])

    words = WORD_RE.findall(m)
    nwords = len(words)

    # 1 AI vocabulary
    ms = []
    for rx in RX_AI:
        ms.extend(rx.finditer(m))
    ms.sort(key=lambda x: x.start())
    if ms:
        samples = []
        last = -1
        for x in ms:
            if x.start() > last and len(samples) < 3:
                samples.append(excerpt(norm, x.start(), x.end()))
                last = x.end() + 40
        put(1, 'ai_vocabulary', 'AI vocabulary', len(ms), samples)

    for num, slug, label, pats, min_hits in SPEC:
        if num == 17:
            continue
        if num in (62, 66, 67, 68):
            continue
        hits = []
        for rx in pats:
            hits.extend(rx.finditer(m))
        if num == 63:
            # exclude short scientific labels already excluded by regex
            pass
        if len(hits) >= min_hits:
            put(num, slug, label, len(hits), [short_sample(h.group(0)) for h in hits[:3]])

    # 17 forms
    h = []
    for rx in SPEC:
        if rx[0] == 17:
            for p in rx[3]:
                h.extend(p.finditer(m))
    put(17, 'negative_parallelism', 'Negative parallelism', len(h), [short_sample(x.group(0)) for x in h[:3]])
    t = list(RX_TAIL.finditer(m))
    put(17, 'tailing_negation', 'Tailing negation', len(t), [short_sample(x.group(0)) for x in t[:3]])

    # 65 tracking params
    AI_HOSTS = set(['chatgpt.com', 'chat.openai.com', 'perplexity.ai', 'claude.ai', 'gemini.google.com',
                    'copilot.microsoft.com', 'poe.com'])
    cnt = 0
    smp = []
    for x in re.finditer(r"utm_source=([A-Za-z0-9.\-]+)", norm):
        host = x.group(1).rstrip('.').lower()
        if host in AI_HOSTS:
            cnt += 1
            smp.append(short_sample(x.group(0)))
    put(65, 'ai_tracking_params', 'AI tracking parameters', cnt, smp)

    # paragraphs / sentences
    pparas = prose_paragraphs(m)
    sent_by_par = [sentences_of(p) for p in pparas]
    all_sents = [s for ss in sent_by_par for s in ss]

    # 3 imperatives
    imp = [s for s in all_sents if re.match(r"\W*([A-Za-z]+)", s) and re.match(r"\W*([A-Za-z]+)", s).group(1).lower() in IMPERATIVES]
    if len(imp) >= 3:
        if '3_promotional' in findings:
            findings['3_promotional']['count'] += len(imp)
        else:
            put(3, 'promotional', 'Promotional language', len(imp), [short_sample(s) for s in imp[:3]])

    # 6 adjective chains
    c6 = []
    for x in CHAIN_RX.finditer(m):
        ws = [w for w in re.split(r"[\s,]+", x.group(1)) if w and w.lower() != 'and']
        if len(ws) < 4:
            continue
        low = [w.lower() for w in ws]
        adj = [w for w in low if w in STOCK_ADJ or w.endswith(ADJ_SUFFIX)]
        if adj and not (low[-1] in STOCK_ADJ or low[-1].endswith(ADJ_SUFFIX)):
            c6.append(x.group(1))
    put(6, 'adjective_chains', 'Stacked adjective chains', len(c6), [short_sample(s) for s in c6[:3]])

    # 8 synonym cycling
    c8 = 0
    smp8 = []
    for cl in SYN_RX:
        used = []
        total = 0
        for w, rx in cl:
            k = len(rx.findall(m))
            if k:
                used.append(w)
                total += k
        if len(used) >= 3:
            c8 += total
            smp8.append('/'.join(used))
    put(8, 'synonym_cycling', 'Synonym cycling', c8, smp8)

    # 33 inline-header lists, 56 bold
    c33 = re.findall(r"^[ \t]*(?:[-*+][ \t]+|\d+[.)][ \t]+)?\*\*[^*\n]+?:\*\*|^[ \t]*(?:[-*+][ \t]+|\d+[.)][ \t]+)?\*\*[^*\n]+\*\*:", m, re.M)
    put(33, 'inline_header_lists', 'Inline-header vertical lists', len(c33), [short_sample(s) for s in c33[:3]])
    c56 = re.findall(r"\*\*[^*\n]+\*\*", m)
    put(56, 'boldface', 'Boldface overuse', len(c56), [short_sample(s) for s in c56[:3]])
    # 57 emoji
    c57 = EMOJI_RX.findall(m)
    put(57, 'emojis', 'Emojis', len(c57), c57[:3])

    # headings
    lines = m.split('\n')
    heads = []
    for i, l in enumerate(lines):
        hm = re.match(r"^ {0,3}#{1,6}[ \t]+(.+?)[ \t]*#*[ \t]*$", l)
        if hm:
            heads.append((i, hm.group(1).strip()))
    # 59 title case
    MINOR = set(['a', 'an', 'the', 'and', 'but', 'or', 'nor', 'for', 'so', 'yet', 'of', 'in', 'on', 'at', 'to', 'by',
                 'up', 'as', 'with', 'from', 'into', 'over', 'per', 'via', 'off', 'out', 'vs', 'if', 'is'])
    c59 = []
    for i, h in heads:
        ws = h.split()
        if len(ws) < 3 or not h[0].isalpha() or h == h.upper():
            continue
        major = [w for w in ws if w.lower().strip('.,:;!?') not in MINOR]
        if len(major) >= 2 and all(w[0].isupper() for w in major):
            c59.append(h)
    put(59, 'title_case_headings', 'Title case in headings', len(c59), c59[:3])
    # 35 fragmented headers
    c35 = []
    for i, h in heads:
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j < len(lines):
            nl = lines[j].strip()
            if nl and not HEADING_LINE.match(lines[j]) and not LIST_LINE.match(lines[j]) and not nl.startswith('|'):
                nw = [w.lower().strip('.,:;!?"\'') for w in nl.split()]
                if 0 < len(nw) <= 4:
                    hw = set(w.lower().strip('.,:;!?"\'') for w in h.split())
                    if any(w and w in hw and len(w) > 2 for w in nw):
                        c35.append(h)
    put(35, 'fragmented_headers', 'Fragmented headers', len(c35), c35[:3])

    # 34 bullet injection
    if not heads:
        blocks = split_paragraphs(m)
        listy = 0
        prosey = 0
        for p in blocks:
            ls = [l for l in p.split('\n') if l.strip()]
            if ls and all(LIST_LINE.match(l) for l in ls):
                listy += 1
            else:
                prosey += 1
        if listy >= 1 and prosey >= 2:
            put(34, 'bullet_injection', 'Mid-essay bullet injection', listy, ['bulleted paragraph in prose'])

    # 37 transitions per paragraph
    c37 = 0
    smp37 = []
    for p in split_paragraphs(m):
        tr = RX_TRANS.findall(p)
        if len(tr) >= 2:
            c37 += len(tr)
            smp37.append(', '.join(tr[:3]))
    put(37, 'transition_clusters', 'Transition cluster overuse', c37, smp37)
    # 38
    c38 = RX_CONCL.findall(m)
    put(38, 'compulsive_conclusions', 'Compulsive conclusion phrases', len(c38), [short_sample(s) for s in c38[:3]])

    # 40 monotony
    if len(all_sents) >= 3:
        lens = [count_words(s) for s in all_sents]
        if cv(lens) < 0.35:
            put(40, 'sentence_length_monotony', 'Sentence-length monotony', len(lens), ['uniform sentence lengths'])
    # 41 alternation
    lens = [count_words(s) for s in all_sents]
    c41 = 0
    if len(lens) >= 6:
        diffs = [lens[i + 1] - lens[i] for i in range(len(lens) - 1)]
        i = 0
        while i < len(diffs):
            j = i
            while j + 1 < len(diffs) and diffs[j] != 0 and diffs[j + 1] != 0 and (diffs[j] > 0) != (diffs[j + 1] > 0):
                j += 1
            run = j - i + 1
            if diffs[i] != 0 and run >= 5:
                seg = diffs[i:j + 1]
                if sum(abs(d) for d in seg) / float(len(seg)) >= 5:
                    c41 += 1
            i = j + 1
    put(41, 'sentence_alternation', 'Mechanical sentence-length alternation', c41, ['alternating sentence lengths'])
    # 42 opener repetition
    c42 = 0
    for ss in sent_by_par:
        if len(ss) >= 3:
            op = Counter(' '.join(w.lower() for w in WORD_RE.findall(s)[:2]) for s in ss)
            for k, v in op.items():
                if v >= 3 and k.count(' ') >= 1:
                    c42 += 1
    put(42, 'opener_repetition', 'Opener repetition', c42, ['repeated sentence openers'])
    # 44 uniform paragraph length
    pw = [count_words(p) for p in pparas]
    if len(pw) >= 4 and cv(pw) < 0.4:
        put(44, 'uniform_paragraphs', 'Uniform paragraph length', len(pw), ['uniform paragraph lengths'])
    # 46
    if nwords >= 300:
        parens = len(re.findall(r"\([^)\n]{1,200}\)", m))
        if ';' not in m and parens <= 1:
            put(46, 'semicolon_paren_underuse', 'Semicolon and parenthesis underuse', 1, ['no semicolons or parentheticals'])
    # 54
    c54 = 0
    for s in all_sents:
        if len(HEDGES.findall(s)) >= 2:
            c54 += 1
    put(54, 'hedge_stacking', 'Excessive hedging', c54, ['stacked hedges'])
    # 55
    fp = len(FIRST_PERSON.findall(m))
    if nwords and fp / float(nwords) >= 0.02 and fp >= 3:
        un = len(UNCONTRACTED.findall(m))
        co = len([x for x in CONTRACTED.findall(m) if not re.search(r"'s$", x, re.I)])
        if un >= 3 and un > co:
            put(55, 'contraction_absence', 'Contraction absence', un, ['forms written out in full'])
    # 58 em dash
    c58 = 0
    for p in split_paragraphs(norm):
        if p.count('—') >= 2:
            c58 += 1
    put(58, 'em_dash_overuse', 'Em-dash overuse', c58, ['two or more em dashes in a paragraph'])
    # 61 year ranges
    c61 = 0
    for x in re.finditer(r"\b(1[0-9]{3}|20[0-9]{2})-(1[0-9]{3}|20[0-9]{2})\b", m):
        if int(x.group(2)) > int(x.group(1)):
            c61 += 1
    put(61, 'hyphen_year_range', 'Hyphen for en dash in numeric ranges', c61, ['year range with hyphen'])
    # 70 hr
    nlines = m.count('\n') + 1
    if nlines >= 24:
        c70 = 0
        for i, l in enumerate(lines):
            if HR_RX.match(l) and (i == 0 or not lines[i - 1].strip()):
                c70 += 1
        if c70 >= 3:
            put(70, 'horizontal_rules', 'Decorative horizontal rules', c70, ['horizontal rules'])
    # 71 degenerate repetition
    lw = [w.lower() for w in words]
    if len(lw) >= 12:
        grams = [tuple(lw[i:i + 6]) for i in range(len(lw) - 5)]
        cnts = Counter(grams)
        dup = sum(1 for g in grams if cnts[g] > 1)
        if dup and dup / float(len(grams)) >= 0.2:
            put(71, 'degenerate_repetition', 'Degenerate repetition', dup, [' '.join(grams[0])])

    # ---- scoring
    nums = {}
    for key, f in findings.items():
        num = int(key.split('_', 1)[0])
        nums[num] = nums.get(num, 0) + f['count']
    moving = dict((n, c) for n, c in nums.items() if n not in ADVICE)
    total = 0
    for n, c in moving.items():
        w = 18 if n in DECISIVE else WEIGHTS.get(n, 12)
        total += w + min(c - 1, 4) * 2
    score = total
    if len(moving) == 1:
        score = min(score, 40)
    if moving and set(moving) <= RHYTHM:
        score = min(score, 40)
    if moving and set(moving) - set([40]) == set():
        score = min(score, 20)
    dec = [n for n in moving if n in DECISIVE]
    if len(dec) >= 2:
        score = max(score, 65)
    elif len(dec) == 1:
        score = max(score, 45)
    if nwords < 120:
        k = len([n for n in moving if n in SHORT_GROUP])
        if k >= 3:
            score = max(score, 45)
        elif k >= 2:
            score = max(score, 25)
    if nwords >= 400:
        k = len(moving)
        if k >= 6:
            score = max(score, 45)
        elif k >= 5:
            score = max(score, 25)
    score = max(0, min(100, int(score)))

    if nwords < 40:
        conf, reason = 'none', 'fewer than 40 words; too short for a meaningful score'
    elif nwords < 120:
        conf, reason = 'low', 'fewer than 120 words'
    elif nwords < 300 and len(moving) == 1:
        conf, reason = 'low', 'fewer than 300 words with only one score-moving pattern family'
    elif nwords < 300:
        conf, reason = 'moderate', 'fewer than 300 words'
    else:
        conf, reason = 'high', ''

    metrics = {
        'scanned_chars': len(window),
        'truncated': False,
        'ai_tell_score': score,
        'ai_tell_band': band_of(score),
        'confidence': conf,
        'confidence_reason': reason,
        'patterns_flagged': len(findings),
        'invisible_chars': n_inv,
        'nonstandard_spaces': n_sp,
        'homoglyphs': n_homo,
        'word_count': nwords,
        'families_moving': len(moving),
    }
    return findings, metrics, all_sents


def score_ci(sents, deadline_s=4.0):
    rng = random.Random(20240501)
    n = len(sents)
    scores = []
    t0 = time.time()
    tot = sum(len(s) for s in sents)
    rounds = 30 if tot < 50000 else 8
    for _ in range(rounds):
        if time.time() - t0 > deadline_s:
            break
        pick = [sents[rng.randrange(n)] for _ in range(n)]
        _, mt, _ = analyze(' '.join(pick))
        scores.append(mt['ai_tell_score'])
    return scores


def scan(text, want_ci=False):
    truncated = len(text) > WINDOW
    window = text[:WINDOW]
    findings, metrics, sents = analyze(window)
    metrics['truncated'] = truncated
    if want_ci:
        if len(sents) >= 4:
            sc = score_ci(sents)
            sc.append(metrics['ai_tell_score'])
            sc.sort()
            lo = sc[int(0.05 * (len(sc) - 1))]
            hi = sc[int(math.ceil(0.95 * (len(sc) - 1)))]
            lo = min(lo, metrics['ai_tell_score'])
            hi = max(hi, metrics['ai_tell_score'])
            metrics['score_ci'] = [lo, hi]
            metrics['score_ci_note'] = 'sentence-level resampling interval'
        else:
            metrics['score_ci'] = None
            metrics['score_ci_note'] = 'too few sentences for an interval (need at least four)'
    report = dict(findings)
    report['_metrics'] = metrics
    return report


# ---------------------------------------------------------------- main

def fail(msg, code):
    sys.stderr.write(json.dumps({'error': msg}, ensure_ascii=False) + '\n')
    sys.stderr.flush()
    sys.exit(code)


def main(argv):
    do_clean = False
    do_ci = False
    operands = []
    opts_done = False
    for a in argv:
        if opts_done:
            operands.append(a)
        elif a == '--':
            opts_done = True
        elif a in ('--help', '-h'):
            sys.stdout.buffer.write(USAGE.encode('utf-8'))
            sys.stdout.flush()
            return 0
        elif a == '--clean':
            do_clean = True
        elif a == '--ci':
            do_ci = True
        elif a.startswith('-'):
            fail('unknown option: %s (see --help)' % a, 2)
        else:
            operands.append(a)
    if len(operands) >= 2:
        sys.stderr.write('prosecheck: %d file operands given; only the last was scanned: %s (first operand: %s)\n'
                         % (len(operands), operands[-1], operands[0]))
    try:
        if operands:
            text = extract_file(operands[-1])
        else:
            data = sys.stdin.buffer.read()
            text = decode_bytes(data)
    except InputError as e:
        fail(str(e), 1)
    except Exception as e:
        fail('cannot read input: %s' % e, 1)
    if not text.strip():
        fail('empty input', 1)
    if do_clean:
        out = clean_text(text)
        sys.stdout.buffer.write(out.encode('utf-8', 'replace'))
        sys.stdout.flush()
        return 0
    report = scan(text, do_ci)
    sys.stdout.buffer.write((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode('utf-8', 'replace'))
    sys.stdout.flush()
    return 0


if __name__ == '__main__':
    try:
        code = main(sys.argv[1:])
    except SystemExit:
        raise
    except BrokenPipeError:
        code = 0
    except Exception as e:  # never print a traceback
        sys.stderr.write(json.dumps({'error': 'cannot read input: internal error: %s' % e}) + '\n')
        code = 1
    sys.exit(code)
