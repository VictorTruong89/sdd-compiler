#!/usr/bin/env node
'use strict';
// Prompt-submit hook: the /prosecheck command router and the per-prompt reminder.
const fs = require('fs');
const path = require('path');

const SUBS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];

function block(reason) {
  process.stdout.write(JSON.stringify({ decision: 'block', reason }));
}

function helpText(lib) {
  const lv = lib.effectiveLevel();
  return [
    'prosecheck level: ' + lv,
    'Commands:',
    '/prosecheck lite - turn on the writing contract, no scoring of saved files',
    '/prosecheck full - contract plus saved-file guard, threshold 40 (default)',
    '/prosecheck strict - guard threshold 20, adds the cleanup scrub',
    '/prosecheck off | on - disable the tool / re-enable it',
    '/prosecheck status - report the current level',
    '/prosecheck show - list the files scored in this session',
    '/prosecheck check <file> - score one file, report only, never rewrite it',
    '/prosecheck doctor - install health check',
    '/prosecheck stats - session token figures and the prose score of this session',
    '/prosecheck init - export the contract to AGENTS.md for other agents',
    'Code, commits, config, and chat are never touched.',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
  ].join('\n');
}

function stripPath(arg) {
  let p = (arg || '').trim();
  if (p.startsWith('@')) p = p.slice(1);
  if (p.length >= 2 && ((p[0] === '"' && p[p.length - 1] === '"') || (p[0] === "'" && p[p.length - 1] === "'"))) {
    p = p.slice(1, -1);
  }
  if (p.startsWith('@')) p = p.slice(1);
  return p;
}

function checkReply(lib, arg, cwd) {
  const p = stripPath(arg);
  if (!p) return 'Usage: /prosecheck check <path-to-prose-file>. Give the path of one file to score; nothing is rewritten.';
  const full = path.resolve(cwd, p);
  const base = path.basename(full);
  let st;
  try { st = fs.statSync(full); } catch (e) { return 'prosecheck: cannot read ' + p + ' (no such file).'; }
  if (st.isDirectory()) return 'prosecheck: ' + p + ' is not a file (it is a directory).';
  if (!st.isFile()) return 'prosecheck: ' + p + ' is not a file.';
  const ext = lib.extOf(full);
  if (ext === '.pdf' || ext === '.rtf') return 'prosecheck: ' + base + ' has no readable text for the detector.';
  const cap = lib.capFor(ext);
  if (st.size > cap.bytes) return 'prosecheck: ' + base + ' is over ' + cap.kb + ' KB and was not scored.';
  const r = lib.scoreFile(full, lib.PLAIN_EXT.indexOf(ext) >= 0 || lib.PROSE_EXT.indexOf(ext) < 0 ? 8000 : 15000);
  if (!r.ok) {
    switch (r.kind) {
      case 'nodetector':
      case 'nopython': return 'prosecheck: detector unavailable, so nothing was scored.';
      case 'timeout': return 'prosecheck: the check of ' + base + ' failed: the detector timed out.';
      case 'empty': return 'prosecheck: ' + base + ' - the detector returned no report.';
      case 'exit': return 'prosecheck: the check of ' + base + ' failed. ' + (r.stderr || 'The detector exited with an error.');
      default: return 'prosecheck: the detector returned no report.';
    }
  }
  const m = r.report._metrics;
  const out = [];
  out.push(base + ' - ' + lib.hookPhrase(m.ai_tell_band) + ' (score ' + m.ai_tell_score + '/100, band: ' + m.ai_tell_band + ')');
  let conf = 'confidence: ' + m.confidence;
  if (m.confidence !== 'high' && m.confidence_reason) conf += ' - ' + m.confidence_reason;
  out.push(conf);
  if (m.truncated) out.push('coverage: first ' + lib.WINDOW_STR + ' characters only');
  const items = lib.findingsList(r.report).slice(0, 8);
  out.push('tells: ' + (items.length ? items.map((i) => i.label + ' (x' + i.count + ')').join('; ') : 'none'));
  out.push('This is a report only; the file was not rewritten.');
  return out.join('\n');
}

function showReply(lib, sid) {
  const rows = lib.readLedger(sid);
  if (!rows.length) {
    return 'prosecheck: nothing scored yet in this session. Rows appear after prose files, including .docx and .pdf deliverables, are saved.';
  }
  const out = ['Files in this session, newest first:'];
  const sorted = rows.map((r, i) => [r, i]).sort((a, b) => ((b[0].t || 0) - (a[0].t || 0)) || (b[1] - a[1]));
  for (const [r] of sorted) {
    const base = r.base || 'file';
    if (r.kind === 'scored') {
      let body = r.phrase + ' (score ' + r.score + '/' + r.band + (r.truncated ? ', first ' + lib.WINDOW_STR + ' characters only' : '') + ')';
      if (r.labels && r.labels.length) {
        body += ' - ' + (r.flagged ? 'flagged' : 'under threshold') + ': ' + r.labels.slice(0, 5).join('; ');
      }
      out.push('  ' + base + ' - ' + body);
    } else if (r.kind === 'skipped') {
      out.push('  ' + base + ' - not scored: larger than the ' + r.capKB + ' KB limit');
    } else if (r.kind === 'binary') {
      out.push('  ' + base + ' - binary file, not re-scored');
    } else {
      out.push('  ' + base + ' - not scored: ' + (r.reason || 'the check failed'));
    }
  }
  return out.join('\n');
}

function doctorReply(lib, form) {
  const level = lib.effectiveLevel();
  const lines = ['prosecheck doctor'];
  let faults = 0;
  const modeOk = level !== 'off';
  lines.push(modeOk ? '[OK] mode: ' + level : '[--] mode: off (run /prosecheck on to turn it back on)');
  const det = lib.detectorPath();
  if (det) lines.push('[OK] detector: bundled detector found in the plugin tree');
  else { lines.push('[!!] detector: bundled detector not found in the plugin tree'); faults++; }
  // python
  let pyOk = false;
  const sample = 'The quick brown fox jumps over the lazy dog. Then it sat down and rested for a while near the river.';
  const r = det ? lib.runPython([det], sample, 15000) : lib.runPython(['-c', 'pass'], undefined, 15000);
  if (!r.launched) {
    lines.push('[!!] python not found - prose is still shaped by the writing contract, but saved files are not re-scored until Python is available');
    faults++;
  } else if (!det) {
    lines.push('[!!] python: runs, but the bundled scorer is missing so no run was possible');
    faults++;
  } else {
    const res = lib.interpretRun(r);
    if (res.ok) { pyOk = true; lines.push('[OK] python: ran the bundled scorer and got a numeric score'); }
    else { lines.push('[!!] python: ran, but the result was not a numeric score'); faults++; }
  }
  // settings
  let writable = false;
  try {
    const dir = lib.configDir();
    fs.mkdirSync(dir, { recursive: true });
    const t = path.join(dir, '.prosecheck-doctor-' + process.pid);
    fs.writeFileSync(t, 'x');
    fs.unlinkSync(t);
    writable = true;
  } catch (e) { writable = false; }
  if (writable) lines.push('[OK] settings: folder is writable');
  else { lines.push('[!!] settings: folder is not writable'); faults++; }
  if (faults > 0) {
    lines.push('Please fix the faulty checks above, then run /prosecheck doctor again.');
  } else if (!modeOk) {
    lines.push('The install is healthy. In this mode saving files triggers no scoring - nothing is scored. Run ' + form + ' on to switch it back on.');
  } else {
    lines.push('prosecheck is active. Plain text is accepted up to ' + lib.PLAIN_CAP_KB + ' KB and archives up to 4 MB; the first ' + lib.WINDOW_STR
      + ' characters are scanned. Use ' + form + ' show to see files that were only partly scanned or skipped.');
  }
  return lines.join('\n');
}

function initReply(lib, form) {
  const level = lib.effectiveLevel();
  if (level === 'off') {
    return 'prosecheck is switched off, so nothing was exported. Run ' + form + ' on to allow the export.';
  }
  const cwd = process.cwd();
  const out = [];
  const agents = path.join(cwd, 'AGENTS.md');
  const BEGIN = '<!-- prosecheck:begin -->';
  const END = '<!-- prosecheck:end -->';
  const body = lib.contractText(level, { portable: true });
  const section = BEGIN + '\n' + body + END + '\n';
  let existing = null;
  let readFailed = false;
  try { existing = fs.readFileSync(agents, 'utf8'); } catch (e) { if (e.code !== 'ENOENT') readFailed = true; }
  if (readFailed) {
    out.push('prosecheck: cannot read AGENTS.md, so the contract was not written.');
  } else if (existing !== null && (existing.indexOf(BEGIN) >= 0 || existing.indexOf('# Writing contract (prose deliverables only)') >= 0)) {
    out.push('AGENTS.md already contains the prose contract; it was left unchanged.');
  } else {
    try {
      let prefix = '';
      if (existing !== null && existing.length) prefix = existing.endsWith('\n') ? '\n' : '\n\n';
      fs.appendFileSync(agents, prefix + section);
      out.push('AGENTS.md: wrote the prose contract section.');
    } catch (e) {
      out.push('prosecheck: cannot write AGENTS.md, so the contract was not written.');
    }
  }
  const rule = path.join(cwd, '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(rule)) {
    out.push('.cursor/rules/prosecheck.mdc already exists; it was not overwritten.');
  } else {
    try {
      const src = path.join(lib.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc');
      const data = fs.readFileSync(src);
      fs.mkdirSync(path.dirname(rule), { recursive: true });
      fs.writeFileSync(rule, data);
      out.push('.cursor/rules/prosecheck.mdc: copied the Cursor rule.');
    } catch (e) {
      out.push('prosecheck: cannot write .cursor/rules/prosecheck.mdc, so the Cursor rule was not created.');
    }
  }
  return out.join('\n');
}

function main() {
  const lib = require('./lib');
  const input = lib.readStdinJson();
  const prompt = typeof input.prompt === 'string' ? input.prompt : '';
  const sid = typeof input.session_id === 'string' ? input.session_id : '';
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();
  const m = /^\s*(\/prosecheck(?::prosecheck)?)(?=\s|$)([\s\S]*)$/.exec(prompt);
  if (m) {
    const form = m[1];
    const rest = m[2].trim();
    let sub = '';
    let arg = '';
    if (rest) {
      const mm = /^(\S+)\s*([\s\S]*)$/.exec(rest);
      sub = mm[1].toLowerCase();
      arg = mm[2].trim();
    }
    if (!sub) sub = 'help';
    if (SUBS.indexOf(sub) < 0) {
      block('prosecheck: unknown subcommand "' + mm0(rest) + '". Valid subcommands: ' + SUBS.join(', ') + '.');
      return;
    }
    switch (sub) {
      case 'help': block(helpText(lib)); break;
      case 'status': block('prosecheck level: ' + lib.effectiveLevel()); break;
      case 'lite': case 'full': case 'strict': case 'off':
        lib.writeLevel(sub);
        block(sub === 'off' ? 'prosecheck is now off.' : 'prosecheck level set to ' + sub + '.');
        break;
      case 'on':
        lib.writeLevel('full');
        block('prosecheck is on (level: full).');
        break;
      case 'check': block(checkReply(lib, arg, cwd)); break;
      case 'doctor': block(doctorReply(lib, form)); break;
      case 'show': block(showReply(lib, sid)); break;
      case 'init': block(initReply(lib, form)); break;
      case 'stats': block(require('./prosecheck-stats').statsReply(input)); break;
      default: block(helpText(lib));
    }
    return;
  }
  if (/stop prosecheck/i.test(prompt) || /^\s*prosecheck off\s*$/i.test(prompt)) {
    lib.writeLevel('off');
    block('prosecheck is now off.');
    return;
  }
  const level = lib.effectiveLevel();
  if (level === 'off') return;
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: {
      hookEventName: 'UserPromptSubmit',
      additionalContext: 'prosecheck level: ' + level + '. Prose deliverables follow the writing contract; code, config, and commits are untouched.',
    },
  }));
}

function mm0(rest) { return rest.split(/\s+/)[0]; }

try { main(); } catch (e) { /* never fail the host */ }
process.exit(0);
