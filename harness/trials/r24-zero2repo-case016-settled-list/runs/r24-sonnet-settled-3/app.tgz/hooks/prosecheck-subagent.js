#!/usr/bin/env node
'use strict';
// Subagent-start hook: the same contract inside the SubagentStart envelope.
try {
  const lib = require('./lib');
  lib.readStdinJson();
  const level = lib.effectiveLevel();
  if (level !== 'off') {
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: { hookEventName: 'SubagentStart', additionalContext: lib.contractText(level) },
    }));
  }
} catch (e) { /* never fail the host */ }
process.exit(0);
