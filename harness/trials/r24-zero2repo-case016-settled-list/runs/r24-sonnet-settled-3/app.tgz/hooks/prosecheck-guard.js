#!/usr/bin/env node
'use strict';
// Post-tool-use hook: scores a just-saved prose file and nudges when flagged.
const fs = require('fs');
const path = require('path');

const INSTR_STEMS = ['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory'];

function patchPaths(cmd) {
  const out = [];
  if (typeof cmd !== 'string') return out;
  for (const line of cmd.split(/\r?\n/)) {
    const m = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/.exec(line);
    if (m) {
      const p = m[1].trim();
      if (p && out.indexOf(p) < 0) out.push(p);
    }
  }
  return out.slice(0, 16);
}

function isInstructionFile(base, lib) {
  const lower = base.toLowerCase();
  const ext = path.extname(lower);
  const stem = ext ? lower.slice(0, -ext.length) : lower;
  if (INSTR_STEMS.indexOf(stem) >= 0 && ext === '.md') return true;
  // stems without a prose extension
  if (INSTR_STEMS.indexOf(stem) >= 0 && lib.PROSE_EXT.indexOf(ext) < 0) return true;
  if (INSTR_STEMS.indexOf(lower) >= 0) return true;
  return false;
}

function main() {
  const lib = require('./lib');
  const input = lib.readStdinJson();
  const level = lib.effectiveLevel();
  if (level !== 'full' && level !== 'strict') return;
  const ti = input.tool_input && typeof input.tool_input === 'object' ? input.tool_input : {};
  let paths = [];
  const direct = [ti.file_path, ti.notebook_path, ti.path];
  for (const d of direct) if (typeof d === 'string' && d.trim()) { paths.push(d.trim()); break; }
  const patch = [ti.command, ti.patch, ti.input].find((v) => typeof v === 'string' && /\*\*\* (Add|Update) File:|\*\*\* Move to:/.test(v));
  if (patch) paths = paths.concat(patchPaths(patch));
  paths = paths.filter((p, i) => paths.indexOf(p) === i).slice(0, 16);
  if (!paths.length) return;
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();
  const sid = typeof input.session_id === 'string' ? input.session_id : '';
  const threshold = level === 'strict' ? 20 : 40;
  const root = path.resolve(lib.pluginRoot());
  const lines = [];
  for (const raw of paths) {
    try {
      const full = path.resolve(cwd, raw);
      const base = path.basename(full);
      const segs = full.split(/[\\/]+/);
      if (segs.indexOf('node_modules') >= 0 || segs.indexOf('.git') >= 0) continue;
      if (full === root || full.indexOf(root + path.sep) === 0) continue;
      if (isInstructionFile(base, lib)) continue;
      const ext = lib.extOf(full);
      if (ext === '.pdf' || ext === '.rtf') {
        lib.appendLedger(sid, { kind: 'binary', base });
        continue;
      }
      if (lib.PROSE_EXT.indexOf(ext) < 0) continue;
      let st;
      try { st = fs.statSync(full); } catch (e) {
        lib.appendLedger(sid, { kind: 'failed', base, reason: 'the file could not be read' });
        continue;
      }
      if (!st.isFile()) continue;
      const cap = lib.capFor(ext);
      if (st.size > cap.bytes) {
        lib.appendLedger(sid, { kind: 'skipped', base, capKB: cap.kb });
        continue;
      }
      const timeout = lib.PLAIN_EXT.indexOf(ext) >= 0 ? 8000 : 15000;
      const r = lib.scoreFile(full, timeout);
      if (!r.ok) {
        lib.appendLedger(sid, { kind: 'failed', base, reason: r.reason });
        continue;
      }
      const m = r.report._metrics;
      const items = lib.findingsList(r.report);
      const labels = items.slice(0, 5).map((i) => i.label);
      const flagged = m.ai_tell_score > threshold;
      const phrase = lib.hookPhrase(m.ai_tell_band);
      lib.appendLedger(sid, {
        kind: 'scored', base, score: m.ai_tell_score, band: m.ai_tell_band, phrase,
        labels, flagged, truncated: !!m.truncated, threshold,
      });
      if (flagged) {
        const cov = m.truncated ? ', first ' + lib.WINDOW_STR + ' characters only' : '';
        lines.push('prosecheck: ' + base + ' ' + phrase + ' (score ' + m.ai_tell_score + ', band ' + m.ai_tell_band + cov + '). Flagged: '
          + (labels.join('; ') || 'none listed') + '. Please fix the flagged spans, keeping sentence length varied.');
      }
    } catch (e) { /* continue with next path */ }
  }
  if (lines.length) {
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') },
    }));
  }
}

try { main(); } catch (e) { /* never fail the host */ }
process.exit(0);
