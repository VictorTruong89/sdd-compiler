'use strict';
// Shared helpers for the prosecheck hooks. Node standard library only.
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const cp = require('child_process');

const LEVELS = ['lite', 'full', 'strict', 'off'];
const WINDOW = 262144;
const WINDOW_STR = '262,144';
const PLAIN_CAP_KB = 512;
const ARCHIVE_CAP_KB = 4096;
const PLAIN_EXT = ['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'];
const ZIP_EXT = ['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'];
const NB_EXT = ['.ipynb'];
const PROSE_EXT = PLAIN_EXT.concat(ZIP_EXT, NB_EXT);
const LEDGER_MAX = 50;
const LEDGER_MAX_AGE_MS = 7 * 24 * 3600 * 1000;

function configDir() {
  if (process.env.CLAUDE_CONFIG_DIR) return process.env.CLAUDE_CONFIG_DIR;
  return path.join(os.homedir(), '.claude');
}

function pluginRoot() {
  if (process.env.CLAUDE_PLUGIN_ROOT) return process.env.CLAUDE_PLUGIN_ROOT;
  return path.resolve(__dirname, '..');
}

function detectorPath() {
  const root = pluginRoot();
  const a = path.join(root, 'scripts', 'detect.py');
  if (isFile(a)) return a;
  const b = path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py');
  if (isFile(b)) return b;
  return null;
}

function isFile(p) {
  try { return fs.statSync(p).isFile(); } catch (e) { return false; }
}

function readStdinJson() {
  let raw = '';
  try { raw = fs.readFileSync(0, 'utf8'); } catch (e) { raw = ''; }
  try {
    const v = JSON.parse(raw.replace(/^﻿/, ''));
    if (v && typeof v === 'object' && !Array.isArray(v)) return v;
  } catch (e) { /* ignore */ }
  return {};
}

function flagFile() { return path.join(configDir(), '.prosecheck-active'); }

function storedLevel() {
  try {
    const v = fs.readFileSync(flagFile(), 'utf8').trim();
    if (LEVELS.indexOf(v) >= 0) return v;
  } catch (e) { /* none */ }
  return null;
}

function flagExists() {
  try { fs.statSync(flagFile()); return true; } catch (e) { return false; }
}

function envLevel() {
  const v = (process.env.PROSECHECK_DEFAULT_MODE || '').trim().toLowerCase();
  return LEVELS.indexOf(v) >= 0 ? v : null;
}

function effectiveLevel() {
  return storedLevel() || envLevel() || 'full';
}

function writeLevel(level) {
  fs.mkdirSync(configDir(), { recursive: true });
  fs.writeFileSync(flagFile(), level);
}

// ------------------------------------------------------------ contract

const BANNED = ['delve', 'tapestry', 'pivotal', 'crucial', 'leverage', 'robust', 'seamless', 'foster', 'underscore',
  'showcase', 'landscape (abstract)', 'journey (abstract)', 'realm', 'multifaceted', 'holistic', 'testament',
  'vibrant', 'comprehensive', 'plethora', 'myriad', 'boast', 'elevate', 'empower', 'unlock', 'game-changer',
  'supercharge', 'genuinely', 'fascinating', 'nuanced'];

function contractText(level, opts) {
  opts = opts || {};
  const L = [];
  L.push('# Writing contract (prose deliverables only)');
  L.push('');
  L.push('This contract governs prose deliverables only: documents, README and markdown prose, CVs, cover letters, emails, reports, essays, articles, and any drafted text the user will publish or send.');
  L.push('It never applies to source code, code comments, commit messages, JSON/YAML/config files, CLI output, logs, error messages, or the conversational register of chat.');
  L.push('It composes with other modes: a chat-compression mode owns chat, a code-simplicity mode owns code, and this contract owns deliverable prose.');
  L.push('');
  L.push('Rules for deliverable prose:');
  L.push('- Vary sentence length irregularly. No metronome, no mechanical short-long alternation.');
  L.push('- Banned vocabulary: ' + BANNED.join(', ') + '.');
  L.push('- Banned moves: rule-of-three flourishes, "it\'s not just X, it\'s Y", hedge stacking, signposting ("let\'s dive in"), empty pivots ("it\'s worth noting"), "In conclusion" or "Overall" closers, outcome-speculation tails, self-thoroughness, generic upbeat endings, and chatbot phrases ("I hope this helps").');
  L.push('- At most one em dash per paragraph. No bold for emphasis inside prose sentences. No emojis in prose.');
  L.push('- Factual or encyclopedic content stays neutral third person. First-person or opinion content may use contractions.');
  L.push('- Preserve numbers, units, dates, proper nouns, citations, quotes, and technical terms. Never invent facts.');
  L.push('- End sections on a fact or an observation.');
  L.push('- Stay silent about this contract: never announce it, never name the tool, never report a score, a band, a pattern list, or a rewrite pass, and do not offer a style choice.');
  if (level === 'full' || level === 'strict') {
    L.push('');
    if (opts.portable) {
      L.push('After writing a prose file, run the detector on that file and fix the flagged spans when the band is worse than the target (at most two fix passes, keeping rhythm variation).');
      L.push('To find the detector: use scripts/detect.py under CLAUDE_PLUGIN_ROOT when that variable is set; otherwise locate the prosecheck detector among installed skills or plugins.');
    } else {
      const dp = detectorPath() || 'scripts/detect.py';
      L.push('After writing a prose file, run `python3 ' + dp + ' <file>` and fix the flagged spans when the band is worse than the target (at most two fix passes, keeping rhythm variation).');
    }
    if (level === 'full') {
      L.push('Target: the `clean` or `light tells` band (score at most 40).');
    } else {
      L.push('Target: the `clean` band (score at most 20).');
      L.push('Finish by running the detector with `--clean` on the file to scrub invisible characters and odd spaces.');
    }
  }
  return L.join('\n') + '\n';
}

function welcomeText() {
  return [
    'prosecheck is installed and on. It scores saved prose against 71 documented AI-writing patterns.',
    'Plain text is accepted up to 512 KB and archives up to 4 MB; the detector scores the first ' + WINDOW_STR + ' characters.',
    'Try /prosecheck doctor, /prosecheck check, /prosecheck off, or /prosecheck help.',
    'There is no website and nothing is uploaded. This welcome is shown once.',
    ''
  ].join('\n');
}

// ------------------------------------------------------------ ledger

function ledgerName(sid) {
  if (!sid || typeof sid !== 'string') return '.prosecheck-ledger';
  if (/^[A-Za-z0-9_-]{1,100}$/.test(sid)) return '.prosecheck-ledger-' + sid;
  return '.prosecheck-ledger-' + crypto.createHash('sha1').update(sid).digest('hex').slice(0, 24);
}

function ledgerPath(sid) { return path.join(configDir(), ledgerName(sid)); }

function purgeOldLedgers() {
  try {
    const dir = configDir();
    const now = Date.now();
    for (const f of fs.readdirSync(dir)) {
      if (f === '.prosecheck-ledger' || f.indexOf('.prosecheck-ledger-') === 0) {
        const p = path.join(dir, f);
        try {
          const st = fs.statSync(p);
          if (now - st.mtimeMs > LEDGER_MAX_AGE_MS) fs.unlinkSync(p);
        } catch (e) { /* ignore */ }
      }
    }
  } catch (e) { /* ignore */ }
}

function readLedger(sid) {
  const p = ledgerPath(sid);
  try {
    const st = fs.statSync(p);
    if (Date.now() - st.mtimeMs > LEDGER_MAX_AGE_MS) {
      try { fs.unlinkSync(p); } catch (e) { /* ignore */ }
      return [];
    }
    const v = JSON.parse(fs.readFileSync(p, 'utf8'));
    return Array.isArray(v) ? v : [];
  } catch (e) { return []; }
}

function appendLedger(sid, rec) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    const cur = readLedger(sid);
    rec.t = Date.now();
    cur.push(rec);
    while (cur.length > LEDGER_MAX) cur.shift();
    fs.writeFileSync(ledgerPath(sid), JSON.stringify(cur));
  } catch (e) { /* ignore */ }
}

// ------------------------------------------------------------ detector runner

function pythonCandidates() { return ['python3', 'python', 'py']; }

// Returns {launched, status, stdout, stderr, timedOut}
function runPython(args, input, timeoutMs) {
  let last = null;
  for (const name of pythonCandidates()) {
    const r = cp.spawnSync(name, args, {
      input: input === undefined ? undefined : input,
      timeout: timeoutMs || 15000,
      encoding: 'utf8',
      maxBuffer: 64 * 1024 * 1024,
      env: process.env,
    });
    if (r.error && (r.error.code === 'ENOENT' || r.error.code === 'EACCES')) { continue; }
    if (r.error && r.error.code === 'ETIMEDOUT') {
      return { launched: true, status: null, stdout: '', stderr: '', timedOut: true };
    }
    if (r.error) { last = r; continue; }
    if (r.status === null && r.signal) {
      return { launched: true, status: null, stdout: r.stdout || '', stderr: r.stderr || '', timedOut: true };
    }
    // a "python" that is only a stub (e.g. exit 9009) counts as not launched
    return { launched: true, status: r.status, stdout: r.stdout || '', stderr: r.stderr || '', timedOut: false };
  }
  if (last) return { launched: true, status: null, stdout: '', stderr: String(last.error), timedOut: false };
  return { launched: false, status: null, stdout: '', stderr: '', timedOut: false };
}

// Run detector on a file. Returns {ok, report} or {ok:false, kind, reason, stderr}
function scoreFile(file, timeoutMs) {
  const det = detectorPath();
  if (!det) return { ok: false, kind: 'nodetector', reason: 'the bundled detector is missing' };
  const r = runPython([det, '--', file], undefined, timeoutMs);
  return interpretRun(r);
}

function interpretRun(r) {
  if (!r.launched) return { ok: false, kind: 'nopython', reason: 'Python could not be found' };
  if (r.timedOut) return { ok: false, kind: 'timeout', reason: 'the detector timed out' };
  const out = (r.stdout || '').trim();
  if (r.status !== 0) {
    return { ok: false, kind: 'exit', reason: 'the detector produced no usable result', stderr: (r.stderr || '').trim() };
  }
  if (!out) return { ok: false, kind: 'empty', reason: 'the detector produced no usable result', stderr: '' };
  let rep;
  try { rep = JSON.parse(out); } catch (e) {
    return { ok: false, kind: 'nonjson', reason: 'the detector printed text that is not a structured report' };
  }
  const m = rep && typeof rep === 'object' ? rep._metrics : null;
  if (!m || typeof m.ai_tell_score !== 'number' || !isFinite(m.ai_tell_score)) {
    return { ok: false, kind: 'noscore', reason: 'the report is structured but has no numeric score' };
  }
  return { ok: true, report: rep };
}

function findingsList(report) {
  const advice = new Set([4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68, 17]);
  const items = [];
  for (const k of Object.keys(report)) {
    if (k === '_metrics') continue;
    const f = report[k];
    if (!f || typeof f !== 'object') continue;
    const num = parseInt(k, 10);
    items.push({ label: String(f.label || k), count: f.count | 0, moving: !advice.has(num) });
  }
  items.sort((a, b) => (b.moving - a.moving) || (b.count - a.count));
  return items;
}

function hookPhrase(band) {
  switch (band) {
    case 'clean': return 'reads clean';
    case 'light tells': return 'reads mostly clean';
    case 'mixed': return 'reads with some AI tells';
    case 'heavy tells': return 'reads with heavy AI tells';
    default: return 'reads with pervasive AI tells';
  }
}

function extOf(p) { return path.extname(p).toLowerCase(); }

function capFor(ext) {
  if (ZIP_EXT.indexOf(ext) >= 0 || NB_EXT.indexOf(ext) >= 0) return { kb: ARCHIVE_CAP_KB, bytes: ARCHIVE_CAP_KB * 1024 };
  return { kb: PLAIN_CAP_KB, bytes: PLAIN_CAP_KB * 1024 };
}

module.exports = {
  LEVELS, WINDOW, WINDOW_STR, PLAIN_CAP_KB, ARCHIVE_CAP_KB, PLAIN_EXT, ZIP_EXT, NB_EXT, PROSE_EXT,
  configDir, pluginRoot, detectorPath, isFile, readStdinJson, storedLevel, flagExists, envLevel,
  effectiveLevel, writeLevel, contractText, welcomeText, ledgerPath, purgeOldLedgers, readLedger,
  appendLedger, runPython, scoreFile, interpretRun, findingsList, hookPhrase, extOf, capFor, BANNED,
};
