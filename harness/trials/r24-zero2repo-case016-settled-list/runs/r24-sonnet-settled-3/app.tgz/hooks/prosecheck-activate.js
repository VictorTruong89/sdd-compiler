#!/usr/bin/env node
'use strict';
// Session-start hook: places the writing contract in the session.
try {
  const lib = require('./lib');
  lib.readStdinJson();
  lib.purgeOldLedgers();
  const first = !lib.flagExists();
  const level = lib.effectiveLevel();
  if (level !== 'off') {
    let out = '';
    if (first) out += lib.welcomeText() + '\n';
    out += lib.contractText(level);
    if (first || !lib.storedLevel()) {
      try { lib.writeLevel(level); } catch (e) { /* ignore */ }
    }
    process.stdout.write(out);
  }
} catch (e) { /* never fail the host */ }
process.exit(0);
