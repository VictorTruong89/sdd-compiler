#!/usr/bin/env node
'use strict';
// `/prosecheck stats`: session token figures and the score of the session's own prose.
const fs = require('fs');
const path = require('path');

function newestTranscript(dir) {
  let best = null;
  const walk = (d, depth) => {
    let ents = [];
    try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { return; }
    for (const e of ents) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) { if (depth < 6) walk(p, depth + 1); }
      else if (e.isFile() && e.name.endsWith('.jsonl')) {
        try {
          const st = fs.statSync(p);
          if (!best || st.mtimeMs > best.mtimeMs) best = { p, mtimeMs: st.mtimeMs };
        } catch (x) { /* ignore */ }
      }
    }
  };
  walk(dir, 0);
  return best;
}

function statsReply(input) {
  const lib = require('./lib');
  input = input || {};
  const level = lib.effectiveLevel();
  let file = null;
  const named = typeof input.transcript_path === 'string' && input.transcript_path ? input.transcript_path : null;
  const newest = newestTranscript(path.join(lib.configDir(), 'projects'));
  if (named) {
    let st = null;
    try { st = fs.statSync(named); } catch (e) { st = null; }
    if (st && st.isFile()) {
      file = named;
      if (newest && newest.mtimeMs > st.mtimeMs) file = newest.p;
    }
  } else if (newest) {
    file = newest.p;
  }
  let raw = null;
  if (file) { try { raw = fs.readFileSync(file, 'utf8'); } catch (e) { raw = null; } }
  if (raw === null) {
    return 'prosecheck stats: no readable transcript was found for this session.\nlevel: ' + level;
  }
  const byId = new Map();
  let anon = 0;
  let text = '';
  for (const line of raw.split(/\r?\n/)) {
    if (!line.trim()) continue;
    let row;
    try { row = JSON.parse(line); } catch (e) { continue; }
    if (!row || row.type !== 'assistant' || !row.message || typeof row.message !== 'object') continue;
    const msg = row.message;
    const id = typeof msg.id === 'string' && msg.id ? msg.id : '#anon' + (anon++);
    const u = msg.usage && typeof msg.usage === 'object' ? msg.usage : {};
    const out = Number(u.output_tokens);
    const cr = Number(u.cache_read_input_tokens);
    byId.set(id, { out: isFinite(out) ? out : 0, cr: isFinite(cr) ? cr : 0 });
    if (Array.isArray(msg.content)) {
      for (const c of msg.content) {
        if (c && c.type === 'text' && typeof c.text === 'string') text += c.text + '\n\n';
      }
    } else if (typeof msg.content === 'string') {
      text += msg.content + '\n\n';
    }
  }
  let turns = 0; let outTok = 0; let crTok = 0;
  for (const v of byId.values()) { turns++; outTok += v.out; crTok += v.cr; }
  const lines = [];
  lines.push('prosecheck session stats');
  lines.push('level: ' + level);
  lines.push('assistant turns: ' + turns);
  lines.push('output tokens: ' + outTok);
  lines.push('cache-read input tokens: ' + crTok);
  let slice = text.replace(/^[ \t]{0,3}(`{3,}|~{3,})[^\n]*\n[\s\S]*?(?:\n[ \t]{0,3}\1[`~]*[ \t]*(?:\n|$)|$)/gm, '');
  slice = slice.slice(-40000);
  const trimmed = slice.trim();
  if (trimmed.length > 200) {
    const r = lib.runPython([lib.detectorPath() || path.join(lib.pluginRoot(), 'scripts', 'detect.py')], trimmed, 15000);
    const res = lib.interpretRun(r);
    if (res.ok) lines.push('session prose ai_tell_score: ' + res.report._metrics.ai_tell_score);
  }
  return lines.join('\n');
}

module.exports = { statsReply };

if (require.main === module) {
  try {
    const lib = require('./lib');
    const input = lib.readStdinJson();
    process.stdout.write(JSON.stringify({ decision: 'block', reason: statsReply(input) }));
  } catch (e) { /* never fail */ }
  process.exit(0);
}
