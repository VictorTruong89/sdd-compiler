#!/usr/bin/env node
'use strict';
// Prompt-submit hook: the /prosecheck command router, the stop phrases, and the ordinary-prompt reminder (FP-04, FP-06).
const fs = require('fs');
const path = require('path');
const core = require('./lib/core');
const contract = require('./lib/contract');
const { statsReply } = require('./prosecheck-stats');

const CMD_RX = /^\/prosecheck(?::prosecheck)?(?=\s|$)/i;
const SUB_LIST = core.SUBCOMMANDS.join(', ');

// ---------------------------------------------------------------- helpers

function formOf(prompt) {
  return /^\/prosecheck:prosecheck/i.test(prompt) ? '/prosecheck:prosecheck' : '/prosecheck';
}

function unquote(arg) {
  // One pair of quotes and one leading @ (in either order) are shell artifacts, not part of the path.
  let s = String(arg || '').trim();
  const quoted = (t) => t.length >= 2 && ((t.startsWith('"') && t.endsWith('"')) || (t.startsWith("'") && t.endsWith("'")));
  if (quoted(s)) s = s.slice(1, -1).trim();
  if (s.startsWith('@')) s = s.slice(1).trim();
  if (quoted(s)) s = s.slice(1, -1).trim();
  return s;
}

function fmtKB(bytes) {
  return Math.round(bytes / 1024);
}

// ---------------------------------------------------------------- replies

function helpReply() {
  const level = core.currentLevel();
  const lines = [
    'prosecheck level: ' + level + ' (live)',
    '',
    'Writing contract for deliverable prose. Code, commits, config, and chat are always left alone; the tool never touches them.',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
    '',
    '/prosecheck lite - turns on the writing contract without scoring saved files.',
    '/prosecheck full - the default: writing contract plus the saved-file guard, which flags files scoring above ' + core.FULL_THRESHOLD + '. (default)',
    '/prosecheck strict - the guard threshold drops to ' + core.STRICT_THRESHOLD + ' and the cleanup scrub is added.',
    '/prosecheck off | on - off switches the tool off (disable); on switches it back on (re-enable), at the full level.',
    '/prosecheck status - shows the live level in one line.',
    '/prosecheck show - lists the scored, skipped, and failed files of this session, newest first.',
    '/prosecheck check <file> - scores one file and gives a report only; it does not rewrite the file.',
    '/prosecheck doctor - a health check of the install.',
    '/prosecheck stats - token totals for this session and the score of its own prose.',
    '/prosecheck init - writes the contract into AGENTS.md for agents other than Claude Code.',
  ];
  return lines.join('\n');
}

function setLevelReply(level) {
  core.writeLevel(level);
  if (level === 'off') {
    return 'prosecheck is off. Saved files are not scored, and the writing contract is not placed in new sessions. Turn it back on with /prosecheck on.';
  }
  return 'prosecheck level set to ' + level + '. The writing contract applies to prose deliverables; code, commits, config, and chat are left alone.';
}

function onReply() {
  core.writeLevel('full');
  return 'prosecheck is on. The stored level is full, which adds the saved-file guard with its threshold of ' + core.FULL_THRESHOLD + '.';
}

function statusReply() {
  return 'prosecheck level: ' + core.currentLevel();
}

function showReply(sessionId) {
  core.pruneLedgers();
  const rows = core.readLedger(sessionId);
  if (!rows.length) {
    return 'nothing scored yet in this session. Rows appear after prose files, including .docx and .pdf deliverables, are saved.';
  }
  const out = ['Session ledger, newest first:'];
  for (const r of rows.slice().reverse()) {
    const base = String(r.base || '?');
    if (r.kind === 'scored') {
      const cov = r.truncated ? ', first 262,144 characters only' : '';
      let body = r.phrase + ' (score ' + r.score + '/' + r.band + cov + ')';
      const labels = Array.isArray(r.labels) ? r.labels.slice(0, 5) : [];
      if (labels.length) {
        body += ' - ' + (r.flagged ? 'flagged' : 'under threshold') + ': ' + labels.join('; ');
      }
      out.push(base + ' - ' + body);
    } else if (r.kind === 'skipped') {
      out.push(base + ' - not scored: over ' + r.cap + ' KB');
    } else if (r.kind === 'binary') {
      out.push(base + ' - not re-scored (binary file)');
    } else {
      out.push(base + ' - not scored: ' + String(r.reason || 'unknown failure').replace(/\d+/g, '#'));
    }
  }
  return out.join('\n');
}

function checkReply(arg) {
  const p = unquote(arg);
  if (!p) {
    return 'usage: /prosecheck check <file>. Give the path of one prose file; it is scored and not changed.';
  }
  const abs = path.isAbsolute(p) ? p : path.resolve(process.cwd(), p);
  const base = path.basename(abs);
  let st;
  try {
    st = fs.statSync(abs);
  } catch (e) {
    return 'cannot read ' + p + ': no such file.';
  }
  if (!st.isFile()) return p + ' is not a file.';
  const ext = path.extname(base).toLowerCase();
  if (core.BINARY_EXT.has(ext)) return base + ': no readable text.';
  const isArchive = core.ARCHIVE_EXT.has(ext);
  const cap = isArchive ? core.ARCHIVE_CAP : core.PLAIN_CAP;
  if (st.size > cap) {
    return base + ': over ' + fmtKB(cap) + ' KB.';
  }
  const r = core.runDetector([abs], null, isArchive ? 15000 : 8000);
  if (r.missingDetector) return 'detector unavailable: the bundled detector is missing, so ' + base + ' was not scored.';
  if (r.unavailable) return 'detector unavailable: Python cannot be launched, so ' + base + ' was not scored.';
  if (r.timeout) return base + ' failed: the detector timed out.';
  if (r.status !== 0) {
    const err = core.parseErrorObject(r.stderr) || core.lastNonEmptyLine(r.stderr) || 'the detector exited without a usable result';
    return base + ' failed: ' + err + '.';
  }
  if (!r.stdout.trim()) return base + ': no report (the detector printed nothing).';
  let rep;
  try {
    rep = JSON.parse(r.stdout);
  } catch (e) {
    return 'no report: the detector output was not a report.';
  }
  const m = rep && rep._metrics;
  if (!m || typeof m !== 'object' || typeof m.ai_tell_score !== 'number') {
    return 'no report: the detector output was not a report.';
  }
  const band = String(m.ai_tell_band);
  const phrase = core.phraseFor(band);
  const labels = core.labelsOf(rep).slice(0, core.LABEL_CAP_CHECK);
  const lines = [
    base + ' - ' + phrase + ' (score ' + m.ai_tell_score + '/100, band: ' + band + ')',
    'confidence: ' + String(m.confidence) + (m.confidence !== 'high' && m.confidence_reason ? ' - ' + m.confidence_reason : ''),
  ];
  if (m.truncated === true) lines.push('coverage: first 262,144 characters only');
  if (labels.length) {
    lines.push('tells: ' + labels.map((l) => l.label + ' (x' + l.count + ')').join('; '));
  } else {
    lines.push('tells: none');
  }
  lines.push('This is a report only; the file was not changed.');
  return lines.join('\n');
}

function doctorReply(form) {
  const level = core.currentLevel();
  const lines = ['prosecheck doctor'];
  const results = [];

  // mode
  if (level === 'off') {
    lines.push('mode: off - the tool is off, which is not a fault of the install; run /prosecheck on to turn it back on.');
    results.push(false);
  } else {
    lines.push('mode: ' + level + ' [OK]');
    results.push(true);
  }

  // detector
  const det = core.detectorPath();
  if (det) {
    lines.push('detector: bundled detector present [OK]');
    results.push(true);
  } else {
    lines.push('detector: bundled detector missing from the plugin tree');
    results.push(false);
  }

  // python
  const r = core.runDetector([], 'Doctor check. This sentence is a short sample for the install check.', 8000);
  let pyOk = false;
  if (r.unavailable) {
    lines.push('python: python not found; saved files will not be re-scored until Python is available, although the writing contract still applies to new prose.');
  } else if (r.missingDetector) {
    lines.push('python: the bundled detector could not be run, so no numeric score was produced.');
  } else if (r.timeout) {
    lines.push('python: the bundled detector timed out and returned no numeric score.');
  } else {
    let numeric = false;
    try {
      const rep = JSON.parse(r.stdout);
      numeric = rep && rep._metrics && typeof rep._metrics.ai_tell_score === 'number';
    } catch (e) {
      numeric = false;
    }
    if (r.status === 0 && numeric) {
      pyOk = true;
      lines.push('python: ran the bundled detector and got a numeric score [OK]');
    } else {
      lines.push('python: ran the bundled detector, but the result is not a numeric score.');
    }
  }
  results.push(pyOk);

  // settings folder
  let writable = false;
  try {
    fs.mkdirSync(core.configDir(), { recursive: true });
    fs.accessSync(core.configDir(), fs.constants.W_OK);
    writable = true;
  } catch (e) {
    writable = false;
  }
  if (writable) {
    lines.push('settings: settings folder is writable [OK]');
  } else {
    lines.push('settings: settings folder is not writable');
  }
  results.push(writable);

  const allOk = results.every(Boolean);
  const modeOffOnly = level === 'off' && results.slice(1).every(Boolean);
  if (allOk) {
    lines.push('The tool is active. Plain text is scored up to 512 KB, zip documents and notebooks up to 4 MB, and the first 262,144 characters are scanned. Run ' + form + ' show to see files that were only partly scanned or skipped.');
  } else if (modeOffOnly) {
    lines.push('The install is healthy. Saved files are not scored while the tool is off, so saving triggers no scoring; run ' + form + ' on to turn it back on.');
  } else {
    lines.push('Some checks are faulty. Fix the faulty checks above, then run /prosecheck doctor again.');
  }
  return lines.join('\n');
}

function initReply(form) {
  const level = core.currentLevel();
  if (level === 'off') {
    return 'prosecheck is switched off, so no files were written. Run ' + form + ' on to allow the export.';
  }
  const out = [];
  const agents = path.join(process.cwd(), 'AGENTS.md');
  let existing = null;
  let agentsReadErr = null;
  try {
    existing = fs.readFileSync(agents, 'utf8');
  } catch (e) {
    if (e.code === 'ENOENT') existing = '';
    else agentsReadErr = e;
  }
  if (agentsReadErr) {
    out.push('cannot read AGENTS.md: ' + (agentsReadErr.code || 'read error') + '; the contract was not written.');
  } else if (existing.includes(contract.EXPORT_START) || existing.includes(contract.EXPORT_HEADING)) {
    out.push('AGENTS.md already has the prosecheck contract section; AGENTS.md was left unchanged.');
  } else {
    const section = contract.exportSection(level);
    let text;
    if (!existing) text = section;
    else text = existing + (existing.endsWith('\n') ? '\n' : '\n\n') + section;
    try {
      fs.writeFileSync(agents, text);
      out.push('wrote the writing contract to AGENTS.md (' + level + ' level).');
    } catch (e) {
      out.push('cannot write AGENTS.md: ' + (e.code || 'write error') + '; the contract was not written.');
    }
  }

  const ruleDst = path.join(process.cwd(), '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(ruleDst)) {
    out.push('prosecheck.mdc already exists in .cursor/rules; it was left unchanged.');
  } else {
    let ruleText;
    try {
      ruleText = fs.readFileSync(path.join(core.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc'), 'utf8');
    } catch (e) {
      ruleText = contract.cursorRuleText();
    }
    try {
      fs.mkdirSync(path.dirname(ruleDst), { recursive: true });
      fs.writeFileSync(ruleDst, ruleText);
      out.push('wrote .cursor/rules/prosecheck.mdc.');
    } catch (e) {
      out.push('cannot write .cursor/rules/prosecheck.mdc: ' + (e.code || 'write error') + '.');
    }
  }
  return out.join('\n');
}

// ---------------------------------------------------------------- router

function route(payload) {
  const prompt = typeof payload.prompt === 'string' ? payload.prompt : '';
  const sessionId = core.sessionOf(payload);
  const trimmed = prompt.trim();
  const lower = trimmed.toLowerCase();

  // Stop phrases: "stop prosecheck" anywhere switches the tool off (ruling 8).
  if (/stop prosecheck/i.test(prompt)) {
    core.writeLevel('off');
  }
  if (lower === 'stop prosecheck' || lower === 'prosecheck off') {
    core.emit({ decision: 'block', reason: 'prosecheck is off (stop phrase). Turn it back on with /prosecheck on.' });
    return;
  }

  if (CMD_RX.test(trimmed)) {
    const form = formOf(trimmed);
    const rest = trimmed.replace(CMD_RX, '').trim();
    const word = rest.split(/\s+/)[0] || '';
    const sub = word.toLowerCase();
    const arg = rest.slice(word.length).trim();
    let reply;
    switch (sub) {
      case '':
      case 'help':
        reply = helpReply();
        break;
      case 'lite':
      case 'full':
      case 'strict':
      case 'off':
        reply = setLevelReply(sub);
        break;
      case 'on':
        reply = onReply();
        break;
      case 'status':
        reply = statusReply();
        break;
      case 'show':
        reply = showReply(sessionId);
        break;
      case 'check':
        reply = checkReply(arg);
        break;
      case 'doctor':
        reply = doctorReply(form);
        break;
      case 'stats':
        reply = statsReply(payload);
        break;
      case 'init':
        reply = initReply(form);
        break;
      default:
        reply = 'unknown subcommand "' + word + '". Valid subcommands are: ' + SUB_LIST + '. The stored level is unchanged.';
    }
    core.emit({ decision: 'block', reason: reply });
    return;
  }

  // Ordinary prompt: reminder when the tool is on.
  const level = core.currentLevel();
  if (level === 'off') return;
  core.emit(core.hookContext('UserPromptSubmit',
    'prosecheck level: ' + level + '. Prose deliverables follow the writing contract; code, config, and commits are untouched.'));
}

function main() {
  const payload = core.readStdinJson();
  try {
    route(payload);
  } catch (e) {
    // never fail the host
  }
}

main();
process.exitCode = 0;
