#!/usr/bin/env node
'use strict';
// stats: session token totals from the transcript, plus the score of the session's own prose (FP-06).
// Used by the prompt router; also runs as a hook (reads the prompt object on stdin, prints a block decision).
const fs = require('fs');
const path = require('path');
const core = require('./lib/core');

const PROSE_MIN = 200;          // print the prose score only above this many characters (ruling 17)
const PROSE_SLICE = 40000;      // keep the last 40,000 characters of assistant text

function safeStat(p) {
  try {
    return fs.statSync(p);
  } catch (e) {
    return null;
  }
}

function newestProjectTranscript() {
  const root = path.join(core.configDir(), 'projects');
  let best = null;
  const walk = (dir, depth) => {
    if (depth > 6) return;
    let entries;
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch (e) {
      return;
    }
    for (const ent of entries) {
      const full = path.join(dir, ent.name);
      if (ent.isDirectory()) {
        walk(full, depth + 1);
      } else if (ent.isFile() && ent.name.endsWith('.jsonl')) {
        const st = safeStat(full);
        if (st && (!best || st.mtimeMs > best.mtime)) best = { path: full, mtime: st.mtimeMs };
      }
    }
  };
  walk(root, 0);
  return best;
}

function readAssistant(file) {
  let raw;
  try {
    raw = fs.readFileSync(file, 'utf8');
  } catch (e) {
    return null;
  }
  const byId = new Map();
  let anon = 0;
  const texts = [];
  for (const line of raw.split(/\r?\n/)) {
    if (!line.trim()) continue;
    let row;
    try {
      row = JSON.parse(line);
    } catch (e) {
      continue;
    }
    if (!row || row.type !== 'assistant' || !row.message || typeof row.message !== 'object') continue;
    const msg = row.message;
    const usage = msg.usage && typeof msg.usage === 'object' ? msg.usage : {};
    const entry = {
      out: Number(usage.output_tokens) || 0,
      cache: Number(usage.cache_read_input_tokens) || 0,
    };
    if (typeof msg.id === 'string' && msg.id) {
      byId.set(msg.id, entry);
    } else {
      anon += 1;
      byId.set('anon-' + anon, entry);
    }
    if (Array.isArray(msg.content)) {
      for (const c of msg.content) {
        if (c && c.type === 'text' && typeof c.text === 'string') texts.push(c.text);
      }
    }
  }
  let out = 0;
  let cache = 0;
  for (const v of byId.values()) {
    out += v.out;
    cache += v.cache;
  }
  return { turns: byId.size, out, cache, texts };
}

function proseSlice(texts) {
  let joined = texts.join('\n\n');
  joined = joined.replace(/```[\s\S]*?(?:```|$)/g, '\n').replace(/~~~[\s\S]*?(?:~~~|$)/g, '\n');
  return joined.slice(-PROSE_SLICE).trim();
}

function statsReply(payload) {
  const level = core.currentLevel();
  const named = typeof payload.transcript_path === 'string' && payload.transcript_path ? payload.transcript_path : null;
  let chosen = null;
  if (named) {
    const st = safeStat(named);
    if (st && st.isFile()) chosen = { path: named, mtime: st.mtimeMs };
  } else {
    chosen = newestProjectTranscript();
  }
  if (named && chosen) {
    const newest = newestProjectTranscript();
    if (newest && newest.mtime > chosen.mtime) chosen = newest;
  }
  const data = chosen ? readAssistant(chosen.path) : null;
  if (!data) {
    return 'stats: no readable session transcript was found, so there are no turn or token totals.\nlevel: ' + level;
  }
  const lines = [
    'stats for this session',
    'level: ' + level,
    'assistant turns: ' + data.turns,
    'output tokens: ' + data.out,
    'cache-read input tokens: ' + data.cache,
  ];
  const slice = proseSlice(data.texts);
  if (slice.length > PROSE_MIN) {
    const r = core.runDetector([], slice, 8000);
    if (r && r.status === 0 && r.stdout) {
      try {
        const rep = JSON.parse(r.stdout);
        const score = rep && rep._metrics && rep._metrics.ai_tell_score;
        if (typeof score === 'number') lines.push('session prose ai_tell_score: ' + score);
      } catch (e) {
        // no score line
      }
    }
  }
  return lines.join('\n');
}

module.exports = { statsReply };

if (require.main === module) {
  const payload = core.readStdinJson();
  try {
    core.block(statsReply(payload));
  } catch (e) {
    // never fail the host
  }
  process.exitCode = 0;
}
