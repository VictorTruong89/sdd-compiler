#!/usr/bin/env node
'use strict';
// Subagent-start hook: returns the same writing contract inside the SubagentStart envelope.
const core = require('./lib/core');
const contract = require('./lib/contract');

function main() {
  core.readStdinJson();
  try {
    const level = core.currentLevel();
    if (level === 'off') return;
    const text = contract.liveContract(level, core.detectorPath());
    core.emit({
      hookSpecificOutput: {
        hookEventName: 'SubagentStart',
        additionalContext: text,
      },
    });
  } catch (e) {
    // never fail the host
  }
}

main();
process.exitCode = 0;
