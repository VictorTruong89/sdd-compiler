#!/usr/bin/env node
'use strict';
// Session-start hook: places the writing contract (and, on a fresh install, the welcome).
const core = require('./lib/core');
const contract = require('./lib/contract');

function main() {
  core.readStdinJson();
  try {
    core.pruneLedgers();
    const fresh = !core.flagExists();
    const level = core.currentLevel();
    if (level === 'off') return;
    if (fresh) core.writeLevel(level);
    let out = '';
    if (fresh) out += contract.welcomeBlock() + '\n';
    out += contract.liveContract(level, core.detectorPath());
    process.stdout.write(out);
  } catch (e) {
    // never fail the host session
  }
}

main();
process.exitCode = 0;
