#!/usr/bin/env node
'use strict';
// Post-tool-use hook: scores a just-saved prose file and nudges when it is flagged (FP-05).
const fs = require('fs');
const path = require('path');
const core = require('./lib/core');

const PATCH_LIMIT = 16;
const PLAIN_CAP_KB = core.PLAIN_CAP / 1024;
const ARCHIVE_CAP_KB = core.ARCHIVE_CAP / 1024;

function targetsFromPayload(payload) {
  const tool = typeof payload.tool_name === 'string' ? payload.tool_name : '';
  const input = payload.tool_input && typeof payload.tool_input === 'object' ? payload.tool_input : {};
  const patchBody = typeof input.command === 'string' ? input.command : null;
  if (tool === 'apply_patch' || (patchBody && /^\*\*\* /m.test(patchBody))) {
    const out = [];
    const seen = new Set();
    const re = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/gm;
    let m;
    while ((m = re.exec(patchBody || '')) !== null) {
      const p = m[1].trim();
      if (!p || seen.has(p)) continue;
      seen.add(p);
      out.push(p);
      if (out.length >= PATCH_LIMIT) break;
    }
    return out;
  }
  if (tool === 'Write' || tool === 'Edit' || tool === 'MultiEdit') {
    return typeof input.file_path === 'string' ? [input.file_path.trim()] : [];
  }
  if (tool === 'NotebookEdit') {
    const p = typeof input.notebook_path === 'string' ? input.notebook_path : input.file_path;
    return typeof p === 'string' ? [p.trim()] : [];
  }
  return [];
}

function isSkippedPath(abs) {
  const segments = abs.split(/[\\/]+/);
  if (segments.includes('node_modules') || segments.includes('.git')) return true;
  const root = path.resolve(core.pluginRoot());
  const rel = path.relative(root, abs);
  if (rel && !rel.startsWith('..') && !path.isAbsolute(rel)) return true;
  return false;
}

function isInstructionFile(base) {
  const lower = base.toLowerCase();
  if (core.INSTR_NAMES.has(lower)) return true;
  const ext = path.extname(lower);
  const stem = ext ? lower.slice(0, -ext.length) : lower;
  return core.INSTR_STEMS.has(stem) && !core.PROSE_EXT.has(ext);
}

function nudgeFor(base, result, threshold) {
  const cov = result.truncated ? ', first 262,144 characters only' : '';
  const labels = result.labels.slice(0, core.LABEL_CAP_GUARD).map((l) => l.label);
  const flagged = labels.length ? labels.join('; ') : 'none';
  return 'prosecheck: ' + base + ' ' + result.phrase + ' (score ' + result.score + ', band ' + result.band + cov +
    '). Flagged: ' + flagged + '. Fix the flagged spans and keep sentence rhythm varied; leave the rest of the file as it is.';
}

function processTarget(rawPath, cwd, sessionId, level, nudges) {
  if (!rawPath) return;
  const abs = path.isAbsolute(rawPath) ? rawPath : path.resolve(cwd, rawPath);
  const base = path.basename(abs);
  if (isSkippedPath(abs)) return;
  if (isInstructionFile(base)) return;
  const ext = path.extname(base).toLowerCase();
  const binary = core.BINARY_EXT.has(ext);
  if (!binary && !core.PROSE_EXT.has(ext)) return;

  let st;
  try {
    st = fs.statSync(abs);
  } catch (e) {
    core.appendLedger(sessionId, { base, kind: 'failed', reason: 'cannot read the file' });
    return;
  }
  if (!st.isFile()) return;

  if (binary) {
    core.appendLedger(sessionId, { base, kind: 'binary' });
    return;
  }
  const isArchive = core.ARCHIVE_EXT.has(ext);
  const cap = isArchive ? core.ARCHIVE_CAP : core.PLAIN_CAP;
  if (st.size > cap) {
    core.appendLedger(sessionId, { base, kind: 'skipped', cap: isArchive ? ARCHIVE_CAP_KB : PLAIN_CAP_KB });
    return;
  }

  const result = core.scoreFile(abs, isArchive);
  if (result.kind !== 'scored') {
    core.appendLedger(sessionId, { base, kind: 'failed', reason: result.reason });
    return;
  }
  const threshold = core.thresholdFor(level);
  const flagged = result.score > threshold;
  core.appendLedger(sessionId, {
    base,
    kind: 'scored',
    score: result.score,
    band: result.band,
    phrase: result.phrase,
    labels: result.labels.slice(0, core.LABEL_CAP_GUARD).map((l) => l.label),
    flagged,
    truncated: result.truncated,
  });
  if (flagged) nudges.push(nudgeFor(base, result, threshold));
}

function main() {
  const payload = core.readStdinJson();
  try {
    const level = core.currentLevel();
    if (level === 'off' || level === 'lite') return;
    const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd();
    const sessionId = core.sessionOf(payload);
    const targets = targetsFromPayload(payload);
    const nudges = [];
    for (const t of targets) {
      try {
        processTarget(t, cwd, sessionId, level, nudges);
      } catch (e) {
        // one bad target must not stop the others
      }
    }
    if (nudges.length) {
      core.emit({
        hookSpecificOutput: {
          hookEventName: 'PostToolUse',
          additionalContext: nudges.join('\n'),
        },
      });
    }
  } catch (e) {
    // never fail the host
  }
}

main();
process.exitCode = 0;
