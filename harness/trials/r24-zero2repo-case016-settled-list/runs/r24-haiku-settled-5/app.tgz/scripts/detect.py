#!/usr/bin/env python3
"""prosecheck detector: a local, standard-library scanner for AI-writing patterns.

Usage:
    detect.py [--clean] [--ci] [--] [FILE]
    detect.py --help | -h

With no FILE the text is read from standard input. The report is one JSON
object on standard output; --clean prints the scrubbed text instead. Errors
are one JSON object {"error": ...} as the last line of standard error.
No network, no model, no third-party packages.
"""
from __future__ import annotations

import io
import json
import math
import os
import re
import sys
import unicodedata
import zipfile
from collections import Counter
from html.parser import HTMLParser
import xml.etree.ElementTree as ET

WINDOW = 262144                 # scan window, in characters
PLAIN_CAP = 512 * 1024          # plain-text cap on disk (plugin-enforced)
ARCHIVE_CAP = 4 * 1024 * 1024   # zip-document / notebook cap on disk
MEMBER_CAP = 64 * 1024 * 1024   # largest archive member we will decompress

PLAIN_EXT = frozenset(['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'])
ZIP_EXT = frozenset(['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'])
NB_EXT = frozenset(['.ipynb'])
BINARY_EXT = frozenset(['.pdf', '.rtf'])
PROSE_EXT = PLAIN_EXT | ZIP_EXT | NB_EXT

USAGE_FIRST = "usage: detect.py [--clean] [--ci] [--] [FILE]"
USAGE = USAGE_FIRST + """

Scores prose for AI-writing patterns. Reads FILE, or standard input when no
FILE is given. Prints a JSON report (findings and _metrics).

  --clean     print the cleaned text (invisible characters removed, spaces
              normalized, homoglyphs folded, trailing whitespace trimmed)
              instead of the report
  --ci        add a low/high interval on the score (needs at least 4 sentences)
  --          end option parsing, so FILE may begin with a dash
  -h, --help  print this usage message and exit 0

Supported files: plain text (.md .mdx .markdown .txt .text .rst .tex .org .adoc),
zip-based documents (.docx .docm .pptx .pptm .xlsx .xlsm .odt .odp .ods .epub)
and notebooks (.ipynb). Only the first 262,144 characters are scanned.
When several FILE operands are given, only the last one is scanned.
"""


class InputError(Exception):
    """The input cannot be read."""


# ---------------------------------------------------------------------------
# Extraction (FP-02)
# ---------------------------------------------------------------------------

def decode_text(data: bytes) -> str:
    if data[:3] == b'\xef\xbb\xbf':
        return data[3:].decode('utf-8', errors='replace')
    if data[:2] in (b'\xff\xfe', b'\xfe\xff'):
        return data.decode('utf-16', errors='replace')
    return data.decode('utf-8', errors='replace')


def _local(name) -> str:
    return name.rsplit('}', 1)[-1] if isinstance(name, str) else ''


def _parse_xml(data: bytes):
    try:
        return ET.fromstring(data)
    except ET.ParseError:
        return None


def _para_text(el) -> str:
    out = []
    for d in el.iter():
        n = _local(d.tag)
        if n == 't' and d.text:
            out.append(d.text)
        elif n == 'tab':
            out.append('\t')
        elif n == 'br':
            out.append('\n')
    return ''.join(out)


def _num_key(name: str):
    m = re.search(r'(\d+)', name)
    return int(m.group(1)) if m else 0


def _docx_text(zf) -> str:
    root = _parse_xml(zf.read('word/document.xml'))
    if root is None:
        return ''
    return '\n'.join(_para_text(el) for el in root.iter() if _local(el.tag) == 'p')


def _pptx_text(zf) -> str:
    names = sorted((n for n in zf.namelist() if re.fullmatch(r'ppt/slides/slide\d+\.xml', n)), key=_num_key)
    slides = []
    for n in names:
        root = _parse_xml(zf.read(n))
        if root is None:
            continue
        paras = [_para_text(el) for el in root.iter() if _local(el.tag) == 'p']
        slides.append('\n'.join(p for p in paras if p))
    return '\n'.join(s for s in slides if s)


def _xlsx_text(zf) -> str:
    shared = []
    if 'xl/sharedStrings.xml' in zf.namelist():
        root = _parse_xml(zf.read('xl/sharedStrings.xml'))
        if root is not None:
            for si in root:
                if _local(si.tag) == 'si':
                    shared.append(''.join(d.text or '' for d in si.iter() if _local(d.tag) == 't'))
    sheets = sorted((n for n in zf.namelist() if re.fullmatch(r'xl/worksheets/sheet\d+\.xml', n)), key=_num_key)
    out_sheets = []
    for n in sheets:
        root = _parse_xml(zf.read(n))
        if root is None:
            continue
        cells = []
        for c in root.iter():
            if _local(c.tag) != 'c':
                continue
            t = c.get('t')
            val = None
            v = next((ch for ch in c if _local(ch.tag) == 'v'), None)
            if t == 's':
                if v is not None and v.text and v.text.strip().isdigit():
                    idx = int(v.text.strip())
                    if idx < len(shared):
                        val = shared[idx]
            elif t == 'inlineStr':
                val = ''.join(d.text or '' for d in c.iter() if _local(d.tag) == 't')
            elif t == 'str':
                val = v.text if v is not None else None
            if val and val.strip():
                cells.append(val)
        out_sheets.append('\n'.join(cells))
    return '\n'.join(s for s in out_sheets if s)


_ODF_SKIP = ('annotation', 'annotation-end')


def _odf_inline(el, buf):
    if el.text:
        buf.append(el.text)
    for ch in el:
        n = _local(ch.tag)
        if n in _ODF_SKIP:
            pass
        elif n == 's':
            count = 1
            for k, v in ch.attrib.items():
                if _local(k) == 'c':
                    try:
                        count = int(v)
                    except ValueError:
                        pass
            buf.append(' ' * count)
        elif n == 'tab':
            buf.append('\t')
        elif n == 'line-break':
            buf.append('\n')
        else:
            _odf_inline(ch, buf)
        if ch.tail:
            buf.append(ch.tail)


def _odf_walk(el, paras):
    n = _local(el.tag)
    if n in _ODF_SKIP:
        return
    if n in ('p', 'h'):
        buf = []
        _odf_inline(el, buf)
        paras.append(''.join(buf))
        return
    for ch in el:
        _odf_walk(ch, paras)


def _odf_text(zf) -> str:
    root = _parse_xml(zf.read('content.xml'))
    if root is None:
        return ''
    paras = []
    _odf_walk(root, paras)
    return '\n'.join(p for p in paras if p.strip())


class _HTMLText(HTMLParser):
    BLOCK = {'p', 'div', 'br', 'li', 'ul', 'ol', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'tr', 'table',
             'section', 'article', 'blockquote', 'pre', 'hr', 'dt', 'dd', 'header', 'footer',
             'figure', 'figcaption', 'aside', 'main', 'body'}
    SKIP = {'script', 'style', 'head', 'nav', 'title', 'svg', 'math'}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.out = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        if tag in self.SKIP:
            self.skip += 1
        elif tag in self.BLOCK:
            self.out.append('\n')

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag in self.SKIP:
            if self.skip:
                self.skip -= 1
        elif tag in self.BLOCK:
            self.out.append('\n')

    def handle_startendtag(self, tag, attrs):
        if tag.lower() in self.SKIP:
            return
        self.handle_starttag(tag, attrs)
        self.handle_endtag(tag)

    def handle_data(self, data):
        if not self.skip:
            self.out.append(re.sub(r'\s+', ' ', data))


def _epub_text(zf) -> str:
    chapters = []
    for n in sorted(zf.namelist()):
        low = n.lower()
        if not low.endswith(('.xhtml', '.html', '.htm')) or 'meta-inf' in low:
            continue
        base = low.rsplit('/', 1)[-1]
        if base in ('nav.xhtml', 'nav.html', 'nav.htm', 'toc.xhtml', 'toc.html', 'toc.htm') or 'navigation' in base:
            continue
        try:
            raw = zf.read(n)
        except KeyError:
            continue
        p = _HTMLText()
        p.feed(decode_text(raw))
        p.close()
        lines = [ln.strip() for ln in ''.join(p.out).split('\n')]
        body = '\n'.join(ln for ln in lines if ln)
        if body:
            chapters.append(body)
    return '\n'.join(chapters)


def _ipynb_text(data: bytes) -> str:
    try:
        nb = json.loads(decode_text(data))
    except ValueError:
        return ''
    cells = nb.get('cells') if isinstance(nb, dict) else None
    if not isinstance(cells, list):
        return ''
    parts = []
    for c in cells:
        if not isinstance(c, dict):
            return ''
        if c.get('cell_type') != 'markdown':
            continue
        src = c.get('source', '')
        if isinstance(src, list):
            if not all(isinstance(s, str) for s in src):
                return ''
            src = ''.join(src)
        elif not isinstance(src, str):
            return ''
        if src.strip():
            parts.append(src)
    return '\n'.join(parts).strip()


def extract_bytes(data: bytes, ext: str, label: str) -> str:
    if ext in BINARY_EXT:
        return ''
    if ext in NB_EXT:
        return _ipynb_text(data)
    if ext in ZIP_EXT:
        try:
            zf = zipfile.ZipFile(io.BytesIO(data))
        except (zipfile.BadZipFile, OSError):
            raise InputError('cannot read input: %s: not a readable zip archive' % label)
        with zf:
            def read_member_ok(name):
                try:
                    if zf.getinfo(name).file_size > MEMBER_CAP:
                        return False
                except KeyError:
                    return False
                return True
            try:
                if ext in ('.docx', '.docm'):
                    if not read_member_ok('word/document.xml'):
                        return ''
                    text = _docx_text(zf)
                elif ext in ('.pptx', '.pptm'):
                    text = _pptx_text(zf)
                elif ext in ('.xlsx', '.xlsm'):
                    text = _xlsx_text(zf)
                elif ext in ('.odt', '.odp', '.ods'):
                    if not read_member_ok('content.xml'):
                        return ''
                    text = _odf_text(zf)
                else:
                    text = _epub_text(zf)
            except Exception:
                return ''
        return text.strip()
    return decode_text(data)


def extract_path(path: str) -> str:
    if os.path.isdir(path):
        raise InputError('cannot read input: %s: is a directory' % path)
    try:
        with open(path, 'rb') as fh:
            data = fh.read()
    except OSError as exc:
        raise InputError('cannot read input: %s: %s' % (path, exc.strerror or exc))
    ext = os.path.splitext(path)[1].lower()
    return extract_bytes(data, ext, path)


# ---------------------------------------------------------------------------
# Character layer (FP-01 62/66/67, FP-03)
# ---------------------------------------------------------------------------

_EXPLICIT_IGNORABLE = frozenset([0x034F, 0x115F, 0x1160, 0x17B4, 0x17B5, 0x3164, 0xFFA0])
_BIDI_CONTROLS = frozenset([0x200E, 0x200F, 0x061C, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E,
                            0x2066, 0x2067, 0x2068, 0x2069])
_RTL_RX = re.compile('[֐-ࣿיִ-﷿ﹰ-﻿]')
_WORD_RX = re.compile(r"(?:[^\W_]|['’\-])+")
_LETTER_RUN_RX = re.compile(r'[^\W\d_]+')


def _is_invisible(cp: int, ch: str) -> bool:
    if cp in (9, 10, 13):
        return False
    if cp < 32 or 127 <= cp < 160:
        return True
    if cp < 0x80:
        return False
    if 0xFE00 <= cp <= 0xFE0F or 0xE0000 <= cp <= 0xE0FFF:
        return True
    if 0x180B <= cp <= 0x180F:
        return True
    if cp in _EXPLICIT_IGNORABLE:
        return True
    if unicodedata.category(ch) == 'Cf':
        if 0x0600 <= cp <= 0x0605 or cp in (0x06DD, 0x070F, 0x08E2):
            return False
        return True
    return False


def _emojiish(cp: int) -> bool:
    return cp >= 0x1F000 or 0x2600 <= cp <= 0x27BF


def _symbolish(cp: int) -> bool:
    if cp < 0:
        return False
    if _emojiish(cp):
        return True
    try:
        return unicodedata.category(chr(cp)).startswith('S')
    except (ValueError, OverflowError):
        return False


def _cjk(cp: int) -> bool:
    return 0x3400 <= cp <= 0x4DBF or 0x4E00 <= cp <= 0x9FFF or 0xF900 <= cp <= 0xFAFF or 0x20000 <= cp <= 0x2FFFF


def _spaceless(cp: int) -> bool:
    return (0x0E00 <= cp <= 0x0EFF or 0x1000 <= cp <= 0x109F or 0x1780 <= cp <= 0x17FF
            or 0x3040 <= cp <= 0x30FF or _cjk(cp))


def _joining(cp: int) -> bool:
    return (0x0590 <= cp <= 0x06FF or 0x0900 <= cp <= 0x0DFF or 0x1000 <= cp <= 0x109F
            or 0x1780 <= cp <= 0x17FF or 0xFB1D <= cp <= 0xFDFF or 0xFE70 <= cp <= 0xFEFF)


def _keep_invisible(text: str, i: int, cp: int, rtl: bool) -> bool:
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    pcp = ord(prev) if prev else -1
    ncp = ord(nxt) if nxt else -1
    if 0xE0020 <= cp <= 0xE007F:
        return _emojiish(pcp) or (0xE0020 <= pcp <= 0xE007F)
    if 0xFE00 <= cp <= 0xFE0F or 0xE0100 <= cp <= 0xE01EF:
        return _cjk(pcp) or _symbolish(pcp) or ncp == 0x20E3
    if 0x180B <= cp <= 0x180F:
        return 0x1800 <= pcp <= 0x18AF
    if cp == 0x200B:
        return _spaceless(pcp) or _spaceless(ncp)
    if cp == 0x00AD:
        return prev.isalpha() and nxt.isalpha()
    if cp in _BIDI_CONTROLS:
        return rtl
    if cp in (0x200C, 0x200D):
        return _joining(pcp) or _joining(ncp) or _symbolish(pcp) or _symbolish(ncp)
    if cp in (0x17B4, 0x17B5):
        return 0x1780 <= pcp <= 0x17FF or 0x1780 <= ncp <= 0x17FF
    return False


def _nbsp_kept(text: str, i: int) -> bool:
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    if prev.isdecimal() or nxt.isdecimal():
        return True
    if nxt and nxt in ':;!?»›%€':
        return True
    if prev and prev in '«‹':
        return True
    return False


def char_layer(text: str):
    """Return (invisible_indices, nonstandard_space_indices) for text."""
    rtl = bool(_RTL_RX.search(text))
    inv = []
    ns = []
    for i, ch in enumerate(text):
        cp = ord(ch)
        if cp < 0x80:
            if cp < 32 and cp not in (9, 10, 13) or cp == 127:
                inv.append(i)
            continue
        if _is_invisible(cp, ch):
            if not _keep_invisible(text, i, cp, rtl):
                inv.append(i)
            continue
        if cp in (0x2028, 0x2029):
            ns.append(i)
        elif cp != 0x20 and unicodedata.category(ch) == 'Zs':
            if cp in (0xA0, 0x202F) and _nbsp_kept(text, i):
                continue
            ns.append(i)
    return inv, ns


_LOOKALIKE = {
    'а': 'a', 'с': 'c', 'ԁ': 'd', 'е': 'e', 'ɡ': 'g', 'һ': 'h',
    'і': 'i', 'ј': 'j', 'ո': 'n', 'о': 'o', 'р': 'p', 'ѕ': 's',
    'ս': 'u', 'υ': 'u', 'ѵ': 'v', 'ν': 'v', 'ԝ': 'w', 'х': 'x',
    'у': 'y', 'ο': 'o', 'ρ': 'p',
    'А': 'A', 'В': 'B', 'С': 'C', 'Е': 'E', 'Н': 'H', 'І': 'I',
    'Ј': 'J', 'К': 'K', 'М': 'M', 'Ν': 'N', 'О': 'O', 'Ο': 'O',
    'Р': 'P', 'Ѕ': 'S', 'Т': 'T', 'Х': 'X', 'Υ': 'Y', 'Ζ': 'Z',
    'Α': 'A', 'Β': 'B', 'Ε': 'E', 'Η': 'H', 'Ι': 'I', 'Κ': 'K',
    'Μ': 'M', 'Ρ': 'P', 'Τ': 'T', 'Χ': 'X',
}
_LATIN_OK = set('acdeghijnopsuvwxyACEHIJKMNOPSTXYZ')


def homoglyph_runs(text: str):
    """Qualifying mixed-script letter runs: list of (start, end, lookalike_count)."""
    out = []
    for m in _LETTER_RUN_RX.finditer(text):
        run = m.group()
        look = sum(1 for c in run if c in _LOOKALIKE)
        if not look or not re.search('[A-Za-z]', run):
            continue
        if not all(c.isascii() or c in _LOOKALIKE for c in run):
            continue
        if not all((not c.isascii()) or c in _LOOKALIKE for c in run):
            continue
        out.append((m.start(), m.end(), look))
    return out


def fold_homoglyphs(text: str) -> str:
    runs = homoglyph_runs(text)
    if not runs:
        return text
    pieces = []
    last = 0
    for s, e, _ in runs:
        pieces.append(text[last:s])
        pieces.append(''.join(_LOOKALIKE.get(c, c) for c in text[s:e]))
        last = e
    pieces.append(text[last:])
    return ''.join(pieces)


def cleanup_text(text: str) -> str:
    """Scrub text as --clean does (FP-03)."""
    t = text.replace('\r\n', '\n').replace('\r', '\n')
    inv, ns = char_layer(t)
    inv_set = set(inv)
    ns_set = set(ns)
    pieces = []
    for i, ch in enumerate(t):
        if i in inv_set:
            continue
        if i in ns_set:
            pieces.append('\n' if ord(ch) in (0x2028, 0x2029) else ' ')
        else:
            pieces.append(ch)
    s = fold_homoglyphs(''.join(pieces))
    lines = []
    for ln in s.split('\n'):
        stripped = ln.rstrip(' \t')
        trailing = ln[len(stripped):]
        if trailing == '  ' and stripped.strip():
            lines.append(stripped + '  ')
        else:
            lines.append(stripped)
    while lines and not lines[0].strip():
        lines.pop(0)
    result = '\n'.join(lines).rstrip()
    if s.endswith('\n') and result:
        result += '\n'
    return result


# ---------------------------------------------------------------------------
# Masking and structure
# ---------------------------------------------------------------------------

PUA = '\ue000'   # private-use placeholder for masked (non-prose) regions
_FENCE_OPEN = re.compile(r'^ {0,3}(`{3,}|~{3,})')
_FENCE_CLOSE = re.compile(r'^ {0,3}(`{3,}|~{3,})[ \t]*$')
_BADGE_RX = re.compile(r'^\s*(?:\[!\[[^\]\n]*\]\([^)\n]*\)\]\([^)\n]*\)\s*)+$')
_INLINE_CODE_RX = re.compile(r'`[^`\n]+`')
_QUOTE_RX = re.compile(r'^\s*>')
_HEADING_RX = re.compile(r'^\s{0,3}#{1,6}\s+(.+?)\s*#*\s*$')
_LIST_RX = re.compile(r'^\s*(?:[-*+]|\d+[.)])\s+')
_SENT_RX = re.compile(r'[^.!?]+[.!?]*')


def mask_text(W: str) -> str:
    """Blank non-prose regions with PUA characters, keeping offsets and newlines."""
    lines = W.split('\n')
    n = len(lines)
    masked = [False] * n
    start = 0
    if n > 1 and lines[0].strip() == '---':
        for j in range(1, n):
            if lines[j].strip() in ('---', '...'):
                for k in range(j + 1):
                    masked[k] = True
                start = j + 1
                break
    fence = None
    for j in range(start, n):
        ln = lines[j]
        if fence is None:
            m = _FENCE_OPEN.match(ln)
            if m:
                fence = (m.group(1)[0], len(m.group(1)))
                masked[j] = True
        else:
            masked[j] = True
            m = _FENCE_CLOSE.match(ln)
            if m and m.group(1)[0] == fence[0] and len(m.group(1)) >= fence[1]:
                fence = None
    j = 0
    while j < n:
        if not masked[j] and _QUOTE_RX.match(lines[j]):
            k = j
            while k < n and not masked[k] and _QUOTE_RX.match(lines[k]):
                k += 1
            if k - j >= 2:
                for q in range(j, k):
                    masked[q] = True
            j = k
        else:
            j += 1
    for j in range(n):
        if masked[j]:
            continue
        ln = lines[j]
        st = ln.strip()
        if st.startswith('|') and st.count('|') >= 2:
            masked[j] = True
        elif _BADGE_RX.match(ln):
            masked[j] = True
    out = []
    for j, ln in enumerate(lines):
        if masked[j]:
            out.append(PUA * len(ln))
        else:
            out.append(_INLINE_CODE_RX.sub(lambda m: PUA * len(m.group()), ln))
    return '\n'.join(out)


def _words(s: str):
    return [w for w in _WORD_RX.findall(s) if any(c.isalnum() for c in w)]


def _lines_offsets(A: str):
    pos = 0
    for line in A.split('\n'):
        yield pos, line
        pos += len(line) + 1


def _sents(A: str):
    """Sentence spans (start, end) in A, skipping headings."""
    out = []
    for base, line in _lines_offsets(A):
        if line.lstrip().startswith('#'):
            continue
        for m in _SENT_RX.finditer(line):
            seg = m.group()
            t = seg.strip()
            if not t or not any(c.isalnum() for c in t):
                continue
            s = base + m.start() + (len(seg) - len(seg.lstrip()))
            out.append((s, s + len(t)))
    return out


def _paras(A: str):
    """Blank-line-separated paragraph texts, headings removed."""
    spans = []
    start = 0
    for m in re.finditer(r'\n[ \t]*\n', A):
        spans.append((start, m.start()))
        start = m.end()
    spans.append((start, len(A)))
    out = []
    for s, e in spans:
        lines = [ln for ln in A[s:e].split('\n') if ln.strip() and not ln.lstrip().startswith('#')]
        if lines:
            out.append('\n'.join(lines))
    return out


def _split_sentences(text: str):
    return [t.strip() for t in re.split(r'(?<=[.!?])\s+|\n', text) if t.strip()]


def _cv(xs):
    if not xs:
        return float('inf')
    mean = sum(xs) / len(xs)
    if mean == 0:
        return float('inf')
    var = sum((x - mean) ** 2 for x in xs) / len(xs)
    return math.sqrt(var) / mean


# ---------------------------------------------------------------------------
# Catalogue families (FP-01)
# ---------------------------------------------------------------------------

def _inflect(word: str) -> str:
    head, *rest = word.split(' ')
    if head.endswith('y') and len(head) > 2:
        p = re.escape(head[:-1]) + r'(?:y|ies|ys)'
    elif head.endswith('e'):
        p = re.escape(head[:-1]) + r'(?:e|es|ed|ing)?'
    else:
        p = re.escape(head) + r'(?:s|es|ed|ing)?'
    for w in rest:
        p += r'\s+' + re.escape(w)
    return p


def _phrase(p: str) -> str:
    return r'\s+'.join(re.escape(w) for w in p.split(' '))


def _rx_fn(patterns, flags=re.I, min_hits=1):
    clean = []
    for p in patterns:
        if p.startswith('(?m)'):
            p = p[4:]
            flags = flags | re.M
        clean.append(p)
    rx = re.compile('|'.join('(?:%s)' % p for p in clean), flags)

    def fn(ctx):
        hits = [m.span() for m in rx.finditer(ctx['A'])]
        return hits if len(hits) >= min_hits else []
    return fn


_AI_VOCAB = ['additionally', 'align with', 'crucial', 'delve', 'tapestry', 'pivotal', 'vibrant',
             'meticulous', 'testament', 'underscore', 'intricate', 'intricacies', 'interplay',
             'garner', 'bolster', 'foster', 'showcase', 'emphasize', 'enduring', 'enhance',
             'leverage', 'utilize', 'facilitate', 'encompass', 'harness', 'holistic', 'paradigm',
             'transformative', 'unprecedented', 'myriad', 'plethora', 'robust', 'seamless',
             'navigate', 'embark', 'craft', 'landscape', 'journey', 'realm', 'multifaceted',
             'elevate', 'empower', 'unlock']
_F1 = [r'\b(?:%s)\b' % '|'.join(_inflect(w) for w in _AI_VOCAB),
       r'\bcapture\s+the\s+(?:essence|spirit|imagination|heart|magic)\b']

_DIALECT = [
    r'\b(?:genuinely|fascinating|nuanced|thoughtfully|refreshingly|strikingly|compellingly)\b',
    r'\bquietly\s+(?:powerful|profound|radical)\b',
    r'\bdeeply\s+(?:human|personal|felt|unsettling)\b',
    r'\bresonates\s+deeply\b',
    r'\bgame[- ]chang(?:er|ers|ing)\b',
    r'\b(?:supercharg|skyrocket|turbocharg|revolutioniz)(?:e|es|ed|ing)?\b',
    r'\bdouble\s+down\s+on\b',
    r'\bdive\s+deep(?:er)?\s+into\b',
    r'\bunlock\s+(?:the\s+)?(?:power|potential|value)\b',
    r'\btake\b[^.!?\n]{0,60}?\bto\s+the\s+next\s+level\b',
]

_PROMO = ['nestled', 'breathtaking', 'must-visit', 'stunning', 'picturesque', 'charming', 'idyllic',
          'vibrant community', 'rich cultural heritage', 'in the heart of', 'world-class', 'top-tier',
          'unparalleled', 'premier', 'leading', 'esteemed organization', 'valuable asset',
          'passion for excellence', 'proven track record', 'results-oriented', 'wealth of experience',
          'dynamic team', 'fast-paced environment', 'deeply passionate', 'perfectly situated',
          'uniquely positioned to']
_PROMO_RX = re.compile(r'\b(?:%s)\b|\b(?:close|tight)-knit\s+team\b|\bI\s+am\s+excited\s+to\s+(?:apply|bring)\b'
                       % '|'.join(_phrase(p) for p in _PROMO), re.I)
_MARKET_VERBS = {'install', 'join', 'grab', 'download', 'try', 'discover', 'experience', 'escape',
                 'transform', 'reclaim', 'unlock', 'elevate', 'boost', 'say', 'imagine', 'explore',
                 'meet', 'introducing', 'upgrade', 'claim', 'unleash', 'supercharge', 'level', 'stop',
                 'start'}


def fam_promo(ctx):
    A = ctx['A']
    hits = [m.span() for m in _PROMO_RX.finditer(A)]
    imp = []
    for s, e in ctx['sents']:
        m = re.match(r'[A-Za-z]+', A[s:e])
        if m and m.group().lower() in _MARKET_VERBS:
            imp.append((s, e))
    if len(imp) >= 3:
        hits += imp
    return hits


_SIMPLE_YET = r'\bsimple\s+yet\s+(?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b'

_STOCK_ADJ = {'robust', 'seamless', 'comprehensive', 'powerful', 'elegant', 'vibrant', 'dynamic',
              'innovative', 'intuitive', 'cutting-edge', 'scalable', 'efficient', 'reliable', 'modern',
              'rich', 'bold', 'sleek', 'lean', 'fresh', 'crisp', 'stunning', 'beautiful', 'exciting',
              'inspiring', 'transformative', 'unparalleled', 'premier', 'world-class', 'top-tier',
              'passionate', 'thoughtful', 'meticulous', 'nuanced', 'breathtaking', 'charming'}
_ADJ_SUFFIX = ('ive', 'ous', 'able', 'ible', 'ic', 'ical', 'ant', 'ent', 'ful', 'less', 'al', 'ial',
               'ary', 'ory', 'ish')
_STACK_RX = re.compile(r"\b[A-Za-z][A-Za-z'\-]*(?:(?:,\s*(?:and\s+|or\s+)?|\s+and\s+)[A-Za-z][A-Za-z'\-]*){3,}")


def fam_stack(ctx):
    out = []
    for m in _STACK_RX.finditer(ctx['A']):
        text = m.group()
        if ',' not in text:
            continue
        words = re.findall(r"[A-Za-z][A-Za-z'\-]*", text)
        if any(w.lower() in _STOCK_ADJ or w.lower().endswith(_ADJ_SUFFIX) for w in words):
            out.append(m.span())
    return out


_CLUSTERS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]


def _member_rx(m):
    if m.endswith('y'):
        return re.escape(m[:-1]) + r'(?:y|ies)'
    return re.escape(m) + r'(?:s|es)?'


_CLUSTER_RX = [(c, re.compile(r'\b(?:%s)\b' % '|'.join(_member_rx(m) for m in c), re.I)) for c in _CLUSTERS]


def fam_synonym(ctx):
    out = []
    for members, rx in _CLUSTER_RX:
        found = set()
        spans = []
        for m in rx.finditer(ctx['A']):
            spans.append(m.span())
            text = m.group().lower()
            for mem in members:
                stem = mem[:-1] if mem.endswith('y') else mem
                if text.startswith(stem):
                    found.add(mem)
                    break
        if len(found) >= 3:
            out += spans
    return out


_FAM11 = re.compile(
    r"(?i:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?i:in|by)\s+"
    r"[A-Z][\w&.\-]*(?:\s+[A-Z][\w&.\-]*)*\s*(?:,|\s+and)\s+[A-Z]"
    r"|\b\d[\d,.]*\s*[KkMm]?\s+(?:followers|subscribers)\b"
    r"|(?i:(?:strong|active)\s+(?:online|digital|social[- ]media)\s+presence)"
    r"|(?i:widely\s+covered|independent\s+coverage)")


def fam_notability(ctx):
    return [m.span() for m in _FAM11.finditer(ctx['A'])]


_FAM13 = re.compile(r"The (?:List|Index|Compilation|Collection|Catalogue|Guide|Overview) of "
                    r"(?:(?:[A-Z][\w'’\-]*|of|the|and|a|an|in|on|for|to)\s+){0,6}[A-Z][\w'’\-]*\s+is\s+(?:a|an|the)\b")


def fam_article_title(ctx):
    return [m.span() for m in _FAM13.finditer(ctx['A'])]


_FAM25 = re.compile(r"(?:^|(?<=[.!?]\s)|(?<=\n))(?:Is|Are|Was|Were|Do|Does|Did|Can|Could|Will|Would|Should|"
                    r"Has|Have|Had|May|Might|Must)\b[^?.!\n]{0,60}\?[ \t]*"
                    r"(?i:yes|no|absolutely|never|maybe|probably|always)[.!]", re.M)


def fam_qa(ctx):
    return [m.span() for m in _FAM25.finditer(ctx['A'])]


def fam_17_parallel(ctx):
    rx = re.compile(r"\bit[’']s\s+not\s+(?:just|merely)\s+(?:about|an?)\b"
                    r"|\bnot\s+only\b[^.!?\n]{0,40}?\bbut\b"
                    r"|\bdoesn[’']t\s+just\b[^,.\n]{0,40}?\bit\b", re.I)
    return [m.span() for m in rx.finditer(ctx['A'])]


def fam_17_tailing(ctx):
    rx = re.compile(r",\s*no\s+(?:guessing|waste|wasted\s+motion|hassle|fluff|stress|jargon)\b", re.I)
    return [m.span() for m in rx.finditer(ctx['A'])]


_FAM18 = re.compile(
    r"\b(?:no|not)\s+\w+,\s+(?:just|only|simply)\s+\w+"
    r"|\b(?:not|isn[’']t|aren[’']t|wasn[’']t|weren[’']t)\s+(?:just|merely)\s+(?:a|an|the)\s+\w+"
    r"(?:,|\s*[—–-])\s*(?:it[’']s|it\s+is|it\s+was|they[’']re|they\s+are|they\s+were|that[’']s|but)\b",
    re.I)


def fam_18(ctx):
    return [m.span() for m in _FAM18.finditer(ctx['A'])]


_TRANSITIONS = {'additionally', 'furthermore', 'moreover', 'however', 'nevertheless', 'consequently',
                'subsequently', 'notably'}


def fam_transitions(ctx):
    out = []
    for para in ctx['paras']:
        sents = _split_sentences(para)
        opened = []
        for s in sents:
            m = re.match(r'[A-Za-z]+', s)
            if m and m.group().lower() in _TRANSITIONS:
                opened.append(s)
        if len(opened) >= 2:
            out += opened
    return out


def fam_opener(ctx):
    out = []
    for para in ctx['paras']:
        sents = _split_sentences(para)
        if len(sents) < 3:
            continue
        groups = {}
        for s in sents:
            words = re.findall(r"[A-Za-z0-9']+", s)
            if len(words) >= 2:
                groups.setdefault(tuple(w.lower() for w in words[:2]), []).append(s)
        for key, items in groups.items():
            if len(items) >= 3:
                out += items
    return out


def fam_sentence_monotony(ctx):
    lens = [len(_words(ctx['A'][s:e])) for s, e in ctx['sents']]
    lens = [x for x in lens if x > 0]
    if len(lens) >= 3 and _cv(lens) < 0.35:
        return ['%d sentences with similar word counts' % len(lens)]
    return []


def fam_uniform_paragraphs(ctx):
    lens = [len(_words(p)) for p in ctx['paras']]
    lens = [x for x in lens if x > 0]
    if len(lens) >= 4 and _cv(lens) < 0.4:
        return ['%d paragraphs with similar word counts' % len(lens)]
    return []


def fam_alternation(ctx):
    lens = [len(_words(ctx['A'][s:e])) for s, e in ctx['sents']]
    lens = [x for x in lens if x > 0]
    if len(lens) < 6:
        return []
    best = 1
    run = 1
    lastd = 0
    for k in range(1, len(lens)):
        d = lens[k] - lens[k - 1]
        big = abs(d) >= max(3, 0.5 * min(lens[k], lens[k - 1]))
        if big and (lastd == 0 or d * lastd < 0):
            run += 1
        elif big:
            run = 2
        else:
            run = 1
        lastd = d if big else 0
        best = max(best, run)
    if best >= 6:
        return ['%d sentences alternate in length' % best]
    return []


def fam_chatbot_hedge(ctx):
    rx = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|somewhat|relatively|fairly|"
                    r"kind of|sort of|seems? to|seems? like|appears? to)\b")
    out = []
    for s, e in ctx['sents']:
        if len(rx.findall(ctx['A'][s:e])) >= 2:
            out.append(ctx['A'][s:e])
    return out


def fam_contraction(ctx):
    words = ctx['words']
    if not words:
        return []
    A = ctx['A']
    fp = len(re.findall(r"\b(?:I|me|my|we|our|us)\b", A))
    if fp / len(words) < 0.03:
        return []
    contr = len(re.findall(r"\b\w+(?:n[’']t|[’'](?:re|m|ve|ll|d))\b", A))
    full = len(re.findall(r"\b(?:do not|does not|did not|it is|that is|I am|we are|they are|cannot|is not|"
                          r"are not|will not|I have|we have|you are|I will|we will|there is)\b", A, re.I))
    if full >= 3 and full > contr:
        return ['%d expanded forms, %d contractions' % (full, contr)]
    return []


def fam_paragraph_dashes(ctx):
    return [p[:120] for p in ctx['paras'] if p.count('—') >= 2]


def fam_curly(ctx):
    return [m.span() for m in re.finditer('[‘’“”]', ctx['A'])]


def fam_year_ranges(ctx):
    out = []
    for m in re.finditer(r'\b(1[5-9]\d\d|20\d\d)-(1[5-9]\d\d|20\d\d)\b', ctx['A']):
        if int(m.group(1)) < int(m.group(2)):
            out.append(m.span())
    return out


def fam_bullets(ctx):
    A = ctx['A']
    if re.search(r'(?m)^#{1,6}\s', A):
        return []
    blocks = []
    start = 0
    for m in re.finditer(r'\n[ \t]*\n', A):
        blocks.append(A[start:m.start()])
        start = m.end()
    blocks.append(A[start:])
    listp, prose = [], []
    for b in blocks:
        lines = [ln for ln in b.split('\n') if ln.strip()]
        if not lines or not _words(b):
            continue
        if all(_LIST_RX.match(ln) for ln in lines):
            listp.append(b)
        elif not any(_LIST_RX.match(ln) for ln in lines):
            prose.append(b)
    if listp and len(prose) >= 2:
        return listp[:1]
    return []


def fam_fragmented_headers(ctx):
    lines = ctx['A'].split('\n')
    out = []
    for i, ln in enumerate(lines):
        m = _HEADING_RX.match(ln)
        if not m:
            continue
        hw = set(re.findall(r'[a-z]{3,}', m.group(1).lower()))
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nxt = lines[j].strip()
        if not nxt or nxt.startswith(('#', '|')) or _LIST_RX.match(nxt) or len(nxt.split()) > 4:
            continue
        if hw & set(re.findall(r'[a-z]{3,}', nxt.lower())):
            out.append(nxt)
    return out


_MINOR = {'a', 'an', 'the', 'and', 'but', 'or', 'nor', 'for', 'so', 'yet', 'of', 'in', 'on', 'at', 'to',
          'by', 'with', 'from', 'as', 'up', 'off', 'per', 'vs', 'via', 'into', 'onto', 'over', 'is'}


def fam_title_case(ctx):
    out = []
    for ln in ctx['A'].split('\n'):
        m = _HEADING_RX.match(ln)
        if not m:
            continue
        text = m.group(1).strip()
        words = text.split()
        if len(words) < 3 or text.isupper() or not text[0].isalpha():
            continue
        major = []
        for w in words:
            core = re.sub(r'[^A-Za-z]', '', w)
            if core and core.lower() not in _MINOR:
                major.append(core)
        if len(major) >= 2 and all(c[0].isupper() for c in major):
            out.append(text)
    return out


_HR_RX = re.compile(r'(?m)^[ \t]{0,3}(?:(?:-[ \t]*){3,}|(?:\*[ \t]*){3,}|(?:_[ \t]*){3,})$')


def fam_hr(ctx):
    A = ctx['A']
    if len(A.split('\n')) < 24:
        return []
    hits = [m.span() for m in _HR_RX.finditer(A)]
    return hits if len(hits) >= 3 else []


def fam_degenerate(ctx):
    words = [w.lower() for w in re.findall(r'[^\W_]+', ctx['A'])]
    n = len(words)
    if n < 12:
        return []
    grams = [tuple(words[i:i + 6]) for i in range(n - 5)]
    cnt = Counter(grams)
    repeated = sum(c for c in cnt.values() if c > 1)
    if repeated / len(grams) >= 0.2:
        return [' '.join(g) for g, c in cnt.most_common() if c > 1]
    return []


def fam_trailing_ws(ctx):
    A = ctx['A']
    out = [m.span() for m in re.finditer(r'[ \t]+(?=\n)', A)]
    if A and A[-1] in ' \t':
        out.append((len(A) - 1, len(A)))
    if A.endswith('\n\n'):
        out.append((len(A) - 2, len(A)))
    if A and A[0].isspace():
        out.append((0, 1))
    return out


_UTM_RX = re.compile(r'utm_source=([A-Za-z0-9.\-]+)', re.I)
_AI_HOSTS = {'chatgpt.com', 'chat.openai.com', 'perplexity.ai', 'claude.ai', 'gemini.google.com',
             'copilot.microsoft.com', 'poe.com'}


def fam_utm(ctx):
    out = []
    for m in _UTM_RX.finditer(ctx['A']):
        if m.group(1).rstrip('.').lower() in _AI_HOSTS:
            out.append(m.span())
    return out


def _fam_layer_invisible(ctx):
    return ['U+%04X at offset %d' % (ord(ctx['A'][i]), i) for i in ctx['inv']]


def _fam_layer_homoglyph(ctx):
    return [(s, e) for s, e, _ in ctx['hg']]


def _fam_layer_nbsp(ctx):
    return ['U+%04X at offset %d' % (ord(ctx['A'][i]), i) for i in ctx['ns']]


# Families: (number, label, function). Keys are "<N>_<slug>".
FAMILIES = []


def _add(num, label, fn, key=None):
    FAMILIES.append((num, key or '%d_%s' % (num, re.sub(r'[^a-z0-9]+', '_', label.lower()).strip('_')), label, fn))


_add(1, 'AI vocabulary', _rx_fn(_F1))
_add(2, 'model-dialect vocabulary', _rx_fn(_DIALECT, min_hits=2))
_add(3, 'promotional language', fam_promo)
_add(5, 'simple-yet cliche', _rx_fn([_SIMPLE_YET]))
_add(6, 'stacked adjective chains', fam_stack)
_add(8, 'synonym cycling', fam_synonym)
_add(10, 'significance inflation', _rx_fn([
    r'\b(?:stands?|stood|serves?|served)\s+as\s+(?:an?\s+|the\s+)?(?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b',
    r'\b(?:underscores?|underscored|underscoring|highlights?|highlighted|highlighting)\s+(?:its|the|their|his|her)\s+(?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b',
    r'\breflects?\s+a\s+broader\s+(?:trend|shift|pattern)\b',
    r'\bmarks?\s+a\s+(?:turning\s+point|milestone|watershed|new\s+chapter|new\s+era)\b',
    r'\bsymbolizes\b',
    r'\bsets?\s+the\s+stage\s+for\b',
    r'\bleft\s+an\s+indelible\s+mark\b',
    r'\bplays?\s+an?\s+(?:crucial|pivotal|vital|key|central|significant)\s+role\b',
    r'\bhas\s+(?:shaped|sparked)\b',
    r'\bhas\s+come\s+to\s+(?:define|symbolize)\b']))
_add(11, 'notability name-dropping', fam_notability)
_add(12, 'vague attributions', _rx_fn([
    r'\bexperts\s+(?:argue|believe|say|claim|note|suggest)\b',
    r'\bindustry\s+(?:reports|observers|analysts)\b',
    r'\bobservers\s+(?:have\s+)?(?:cited|noted)\b',
    r'\bsome\s+critics\s+argue\b',
    r'\bresearchers\s+have\s+found\b',
    r'\bstudies\s+suggest\b',
    r'\bit\s+is\s+widely\s+believed\b']))
_add(13, 'article title as proper noun', fam_article_title, None)
_add(14, 'conservation padding', _rx_fn([
    r'\bplays?\s+an?\s+(?:vital|crucial|key|significant)\s+role\s+in\s+(?:its|the)\s+ecosystem\b',
    r'\bconservation\s+efforts\s+(?:are|is)\s+(?:underway|ongoing|in\s+place)\b',
    r'\bserves\s+as\s+an?\s+indicator\s+species\b',
    r'\bcontributes?\s+to\s+biodiversity\b']))
_add(15, 'false range', _rx_fn([
    r'\bfrom\s+(?:the\s+)?(?:dawn|birth|earliest\s+days|inception|advent|emergence|humble)\b[^.!?\n]*?\bto\s+(?:the\s+)?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b',
    r'\bfrom\s+(?:the\s+)?humble\b[^.!?\n]*?\bto\s+(?:the\s+)?(?:mighty|towering|grand|sprawling)\b']))
_add(16, 'superficial -ing tail clause', _rx_fn([
    r',\s*(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|fostering|cultivating|'
    r'encompassing|signaling|demonstrating|illustrating|representing|suggesting|indicating|reinforcing|'
    r'leveraging|aligning|embodying|exemplifying|epitomizing)\b']))
_add(17, 'negative parallelism', fam_17_parallel, '17_negative_parallelism')
_add(17, 'tailing negation', fam_17_tailing, '17_tailing_negation')
_add(18, 'not X, just Y framing', fam_18)
_add(19, 'filler phrase', _rx_fn([
    r'\bin\s+order\s+to\b', r'\bdue\s+to\s+the\s+fact\s+that\b', r'\bat\s+this\s+point\s+in\s+time\b',
    r'\bin\s+the\s+event\s+that\b', r'\bhas\s+the\s+ability\s+to\b', r'\bit\s+is\s+important\s+to\s+note\s+that\b',
    r'\bit\s+should\s+be\s+mentioned\s+that\b', r'\bneedless\s+to\s+say\b']))
_add(20, 'empty pivot phrase', _rx_fn([
    r"\bit[’']s\s+worth\s+(?:noting|mentioning)(?:\s+that)?\b",
    r'\bit\s+bears\s+(?:noting|mentioning)(?:\s+that)?\b',
    r'\bone\s+thing\s+to\s+(?:consider|keep\s+in\s+mind)\s+is\b',
    r'\bit\s+is\s+interesting\s+to\s+note\s+that\b',
    r'\ba\s+key\s+consideration\s+is\b',
    r'\ba\s+point\s+to\s+highlight\s+is\b']))
_add(21, 'outcome-speculation tail', _rx_fn([
    r',\s*(?:raising\s+questions\s+about|prompting\s+reflection\s+on|sparking\s+debate\s+about|'
    r'with\s+broader\s+implications\s+for|reshaping\s+our\s+understanding\s+of|paving\s+the\s+way\s+for|'
    r'signaling\s+a\s+shift\s+toward)\b']))
_add(22, 'persuasive authority trope', _rx_fn([
    r"here[’']s\s+the\s+thing", r'\bmake\s+no\s+mistake\b', r'\bthe\s+truth\s+is\b',
    r"\blet[’']s\s+be\s+honest\b", r'\bthe\s+simple\s+fact\s+is\b', r'\bat\s+its\s+core\b',
    r'\bwhat\s+really\s+matters\b', r'\bmore\s+than\s+anything\b', r'\bat\s+the\s+end\s+of\s+the\s+day\b',
    r'\bthe\s+bottom\s+line\s+is\b', r'\bin\s+reality\b', r'\bfundamentally,', r'\bthe\s+real\s+question\s+is\b',
    r'\bthe\s+heart\s+of\s+the\s+matter\b', r'\bthe\s+deeper\s+issue\b', r'\bwhen\s+you\s+get\s+down\s+to\s+it\b',
    r'\bwhen\s+all\s+is\s+said\s+and\s+done\b']))
_add(23, 'editorial interjection', _rx_fn([
    r"\bit(?:[’']s|\s+is)\s+important\s+to\s+(?:remember|note|understand|recognize)\b",
    r'\bone\s+must\s+note\s+that\b', r'\bit\s+is\s+worth\s+pointing\s+out\b',
    r'\bit\s+cannot\s+be\s+overstated\s+that\b', r'\bit\s+must\s+be\s+emphasized\s+that\b']))
_add(24, 'self-thoroughness phrase', _rx_fn([
    r'\bthis\s+comprehensive\s+(?:guide|overview|analysis)\b',
    r'\bthis\s+in-depth\s+(?:analysis|look|examination)\b',
    r'\bthis\s+complete\s+(?:guide|overview)\b',
    r'\ba\s+thorough\s+examination\s+of\b',
    r'\beverything\s+you\s+need\s+to\s+know\s+about\b']))
_add(25, 'question-answer rhetorical pattern', fam_qa)
_add(26, 'concrete-evidence defense phrase', _rx_fn([
    r'\bwithout\s+concrete\s+(?:evidence|proof)\b', r'\bdo\s+you\s+have\s+concrete\s+evidence\b',
    r'\bI\s+(?:would\s+)?need\s+concrete\s+(?:evidence|examples|proof)\s+to\b',
    r'\babsent\s+concrete\s+proof\b', r'\bprovide\s+concrete\s+evidence\b']))
_add(27, 'compulsive intro hook', _rx_fn([
    r"\bin\s+today[’']s\s+(?:[\w-]+\s+){0,2}?(?:world|landscape|environment|market)\b",
    r'\bin\s+a\s+world\s+where\b', r'\bin\s+an\s+era\s+of\b', r'\bin\s+recent\s+years,',
    r'\bmore\s+than\s+ever\s+before\b', r'\bwe\s+live\s+in\s+a\s+(?:time|world)\s+when\b',
    r'\b(?:great|exciting|big)\s+news\s*[!:]', r'\bever\s+(?:wanted|wondered|dreamed|wished)\b[^?\n]{0,80}\?',
    r'\bin\s+an\s+increasingly\s+(?:interconnected|digital|competitive|complex)\s+world\b']))
_add(30, 'diff-anchored writing', _rx_fn([
    r'\bunlike\s+the\s+(?:previous|prior|old|earlier)\s+(?:version|release|implementation|approach)\b',
    r'\bthe\s+(?:latest\s+|new\s+)?(?:update|release|version|change|patch|design)\s+(?:adds|introduces|brings|delivers|includes|provides|improves)\b',
    r'\bthis\s+(?:latest\s+|new\s+)?(?:update|release|version|change|patch|design)\s+(?:adds|introduces|brings|delivers|includes|provides|improves)\b',
    r'\bhas\s+been\s+(?:updated|refactored|improved|enhanced|changed\s+to)\b',
    r'\bhave\s+been\s+(?:updated|refactored|improved|enhanced|changed\s+to)\b',
    r'\bpreviously\b[^.!?\n]{0,200}?\bnow\b',
    r"\bwasn[’']t\s+there\s+before\b|\bweren[’']t\s+there\s+before\b",
    r"\bwe(?:[’']ve|\s+have)\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)\b"]))
_add(31, 'signposting announcement', _rx_fn([
    r"\blet[’']s\s+(?:dive|delve|explore)\b", r"\blet[’']s\s+break\s+(?:this|it)\s+down\b",
    r"\bhere[’']s\s+what\s+you\s+need\s+to\s+know\b", r'\bwithout\s+further\s+ado\b',
    r"\bnow\s+let[’']s\s+look\s+at\b", r'\bbuckle\s+up\b', r'\bstay\s+with\s+me\b',
    r'\b(?:are\s+you\s+)?ready\s+to\s+dive\s+in\b']))
_add(32, 'cataloguing lead-in', _rx_fn([
    r'\b(?:used|uses|employs?|employed|relied\s+on|utilizes)\s+(?:several|various|a\s+number\s+of|multiple|different|many|numerous)\s+\w+',
    r'(?:^|(?<=[.!?]\s)|(?<=\n))These(?:\s+\w+)?\s+(?:provide|offer|give|reveal|show|allow|enable|help)\s+(?:information|insight|understanding|details|data)\b',
    r'\b(?:is|are|was|were|remains|becomes)\s+(?:the\s+|a\s+)?(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective\s+tissue)\s+of\b']))
_add(33, 'inline-header vertical list', _rx_fn([
    r'(?m)^[ \t]*(?:[-*+][ \t]+|\d+[.)][ \t]+)?\*\*[^*\n]+:\*\*',
    r'(?m)^[ \t]*(?:[-*+][ \t]+|\d+[.)][ \t]+)?\*\*[^*\n]+\*\*:']))
_add(34, 'mid-essay bullet injection', fam_bullets)
_add(35, 'fragmented header', fam_fragmented_headers)
_add(36, 'formulaic challenges section', _rx_fn([
    r'\bdespite\s+(?:these|its|the)\s+(?:challenges|obstacles)\b',
    r'\bchallenges\s+and\s+(?:future\s+)?(?:prospects|outlook|legacy)\b',
    r'\bcontinues\s+to\s+thrive\b', r'\btypical\s+of\s+(?:emerging|urban|modern)\b',
    r'\bfaces\s+(?:several|many|numerous)\s+challenges\b']))
_add(37, 'transition cluster', fam_transitions)
_add(38, 'compulsive conclusion phrase', _rx_fn([
    r'^[ \t]*(?:in\s+conclusion|overall|in\s+summary|to\s+summarize|to\s+conclude|all\s+in\s+all|in\s+essence|ultimately)\b'],
    flags=re.I | re.M))
_add(39, 'generic positive conclusion', _rx_fn([
    r'\bthe\s+future\s+looks\s+bright\b', r'\bexciting\s+times\s+lie\s+ahead\b',
    r'\bjourney\s+toward\s+excellence\b', r'\bstep\s+in\s+the\s+right\s+direction\b',
    r'\b(?:outlook|future)\b(?:\s+for\s+[^.!?\n]{1,40}?)?\s+(?:is|looks|remains)\s+bright\b',
    r'\bwell[- ]positioned\s+(?:for\s+)?(?:whatever\s+comes\s+next|the\s+future|the\s+road\s+ahead)\b']))
_add(40, 'sentence-length monotony', fam_sentence_monotony)
_add(41, 'mechanical sentence-length alternation', fam_alternation)
_add(42, 'opener repetition', fam_opener)
_add(44, 'uniform paragraph length', fam_uniform_paragraphs)
_add(46, 'semicolon and parenthesis underuse', lambda ctx: (['long text without semicolons or parentheses']
                                                             if len(ctx['words']) >= 300 and ';' not in ctx['A']
                                                             and len(re.findall(r'\([^()\n]{1,200}\)', ctx['A'])) <= 1
                                                             else []))
_add(47, 'chatbot artifact', _rx_fn([
    r'\bI\s+hope\s+this\s+helps\b', r'\bCertainly!', r'\bOf\s+course!', r'\blet\s+me\s+know\s+if\s+you\b',
    r'\bwould\s+you\s+like\s+me\s+to\b', r'\bfeel\s+free\s+to\s+(?:ask|reach\s+out)\b', r'\bhappy\s+to\s+help\.',
    r'\b(?:here|below)\s+is\s+(?:a|an|the)\s+(?:overview|summary|rundown|recap|brief)\b',
    r"\bhere\s+(?:are|[’']s|is)\s+(?:a\s+few\s+|some\s+|two\s+|three\s+)?(?:options|drafts|versions|variations)\b",
    r"\bhere\s+(?:is|[’']s)\s+a\s+draft\b",
    r"\bdepending\s+on\s+the\s+(?:vibe|tone|style)\b",
    r'\bI\s+hope\s+(?:this\s+email\s+)?finds\s+you\s+well\b',
    r'\bas\s+an?\s+(?:AI|LLM|AI\s+assistant|AI\s+language\s+model|large\s+language\s+model|language\s+model)\b',
    r'\bto\s+(?:answer|address)\s+your\s+question\b', r'\bin\s+(?:response|answer)\s+to\s+your\s+question\b',
    r'\byour\s+question\s+(?:about|regarding|concerning)\b', r'\bas\s+(?:you\s+)?(?:requested|asked),?\s+here\b',
    r'\bhere\s+is\s+(?:the\s+)?(?:draft|first\s+pass|revised\s+version\s+of|for\s+your)\b']))
_add(48, 'sycophantic tone', _rx_fn([
    r"\byou(?:[’']re|\s+are)\s+absolutely\s+right\b",
    r'\b(?:great|excellent|good|fantastic|wonderful|insightful|thoughtful|brilliant)\s+(?:question|point)[!.,]',
    r'\bwhat\s+a\s+(?:thoughtful|great|wonderful|fantastic)\s+question\b',
    r"\bthat[’']s\s+a\s+(?:great|wonderful|fantastic|brilliant|excellent)\s+(?:point|question)\b"]))
_add(50, 'knowledge-cutoff disclaimer', _rx_fn([
    r'\b(?:as\s+of|up\s+to)\s+my\s+(?:last\s+)?(?:training|knowledge)(?:\s+cutoff)?\b',
    r'\bas\s+of\s+my\s+(?:knowledge\s+)?cutoff\b',
    r'\bwhile\s+specific\s+details\s+are\s+(?:limited|scarce|not\s+(?:extensively\s+|widely\s+)?documented)\b',
    r'\bbased\s+on\s+(?:the\s+)?available\s+information\b',
    r'\bmaintains\s+a\s+low\s+profile\b', r'\bkeeps\s+(?:his|her|their)\s+personal\s+life\s+private\b']))
_add(51, 'copula avoidance', _rx_fn([
    r'\b(?:serves?|served|stands?|stood|functions?|functioned|acts?|acted)\s+as\b',
    r'\brepresents\s+(?:a|the)\b', r'\bmarks\s+(?:a|the)\b', r'\bboasts\b',
    r'\bfeatures\s+(?:an?|the|\d+|several|many|numerous|multiple|various|a\s+number\s+of)\b',
    r'\boffers\s+an?\b', r'\brefers\s+to\b']))
_add(54, 'hedge stacking', fam_chatbot_hedge)
_add(55, 'contraction absence', fam_contraction)
_add(56, 'boldface overuse', _rx_fn([r'\*\*[^*\n]+?\*\*'], flags=0))
_add(57, 'emoji', _rx_fn(['[\U0001F000-\U0001FAFF☀-➿⭐⭕⬅-⬇〰〽㊗㊙]'],
                         flags=0))
_add(58, 'em-dash overuse', fam_paragraph_dashes)
_add(59, 'title case in heading', fam_title_case)
_add(60, 'curly quotation marks', fam_curly)
_add(61, 'hyphen-for-en-dash year range', fam_year_ranges)
_add(62, 'invisible characters', _fam_layer_invisible)
_add(63, 'placeholder text', _rx_fn([
    r'\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\](?![(\[])',
    r'\[(?:name|company|client|place|source|person)\b[^\]\n]*\](?![(\[])',
    r'\[(?=[A-Z0-9 _\-]*[A-Z]{2})[A-Z][A-Z0-9 _\-]*\](?![(\[])',
    r'\{\{[^{}\n]*\}\}', r'\b[xX]{3,}\b', r'\blorem\s+ipsum\b'], flags=re.I))
_add(64, 'chat reference markup', _rx_fn([
    r'\bcite(?:turn|start|nav)\w*', r'\boai_citation\w*', r'contentReference', r'\bnavlist\b',
    '【\\d+†[^】\\n]*】'], flags=re.I))
_add(65, 'AI tracking parameter', fam_utm)
_add(66, 'mixed-script homoglyphs', _fam_layer_homoglyph)
_add(67, 'non-standard spaces', _fam_layer_nbsp)
_add(68, 'trailing whitespace', fam_trailing_ws)
_add(69, 'marketing-slop phrase', _rx_fn([
    r'\bunlock(?:ing)?\s+(?:the\s+|your\s+|its\s+|their\s+)?full\s+potential\b',
    r'\bnavigat(?:e|ing)\s+the\s+complexities\b', r'\ba\s+testament\s+to\s+the\s+(?:power|importance)\s+of\b',
    r'\bstaying\s+ahead\s+of\s+the\s+curve\b', r'\bturning\s+challenges\s+into\s+opportunities\b',
    r'\btaking\s+\w+\s+to\s+the\s+next\s+level\b', r'\bharnessing\s+the\s+power\s+of\b',
    r'\bpaving\s+the\s+way\s+for\b', r'\bsaying\s+goodbye\s+to\b', r'\bimagining\s+a\s+world\s+where\b']))
_add(70, 'decorative horizontal rules', fam_hr)
_add(71, 'degenerate repetition', fam_degenerate)
_add(4, 'hyphenated word-pair overuse', _rx_fn([
    r'\bcutting-edge\b', r'\bstate-of-the-art\b', r'\bbest-in-class\b', r'\bnext-generation\b',
    r'\bresults-driven\b', r'\bdata-driven\b', r'\bindustry-leading\b', r'\bever-evolving\b',
    r'\btime-tested\b', r'\bfast-paced\b', r'\bwell-established\b', r'\bgame-changing\b', r'\btop-notch\b']))

ADVICE = frozenset([4, 17, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68])
DECISIVE = frozenset([13, 47, 48, 50, 62, 63, 64, 65, 66])
RHYTHM = frozenset([40, 44])
SHORT_FAMILIES = frozenset(list(range(1, 40)) + list(range(47, 52)) + [69])

FAMILIES.sort(key=lambda f: (f[0], f[1]))


# ---------------------------------------------------------------------------
# Analysis and scoring (FP-01)
# ---------------------------------------------------------------------------

def _excerpt(W: str, s: int, e: int) -> str:
    a = max(0, s - 30)
    b = min(len(W), e + 30)
    frag = W[a:b].replace('\r', ' ').replace('\n', ' ')
    return ('...' if a > 0 else '') + frag + ('...' if b < len(W) else '')


def _band(score: int) -> str:
    if score <= 20:
        return 'clean'
    if score <= 40:
        return 'light tells'
    if score <= 60:
        return 'mixed'
    if score <= 80:
        return 'heavy tells'
    return 'pervasive tells'


def analyze(full: str, ci: bool = False) -> dict:
    truncated = len(full) > WINDOW
    scanned = min(len(full), WINDOW)
    W = full[:WINDOW].replace('\r\n', '\n')
    A = mask_text(W)
    inv, ns = char_layer(A)
    hg = homoglyph_runs(A)
    words = _words(A)
    sents = _sents(A)
    ctx = {'A': A, 'W': W, 'inv': inv, 'ns': ns, 'hg': hg, 'words': words,
           'sents': sents, 'paras': _paras(A)}

    fired = []
    hits = Counter()
    for num, key, label, fn in FAMILIES:
        items = fn(ctx) or []
        if items:
            fired.append((num, key, label, items))
            hits[(num)] += len(items)

    findings = {}
    for num, key, label, items in fired:
        strs = []
        for it in items[:3]:
            if isinstance(it, tuple):
                strs.append(_excerpt(W, it[0], it[1]))
            else:
                strs.append(it)
        if num == 66:
            count = len(hg)
        else:
            count = len(items)
        findings[key] = {'label': label, 'count': count, 'samples': strs}

    S = {n for n in hits if n not in ADVICE and n in {f[0] for f in FAMILIES} and hits[n] > 0}
    # Families are the score-moving numbers that fired. Rhythm numbers count as families here.
    D = {n for n in S if n in DECISIVE}
    n_words = len(words)

    raw = 0.0
    for n in S:
        h = hits[n]
        w = 25.0 if n in DECISIVE else (8.0 if n in RHYTHM else 15.0)
        raw += w * (1.0 - 0.5 ** min(h, 10))
    score = raw
    if not D:
        if S <= {40}:
            score = min(score, 20.0)
        elif len(S) == 1 or S <= {40, 44}:
            score = min(score, 40.0)
    floor = 0.0
    if D:
        floor = max(floor, 45.0)
    if len(D) >= 2:
        floor = max(floor, 65.0)
    short_hits = S & SHORT_FAMILIES
    if n_words < 120:
        if len(short_hits) >= 3:
            floor = max(floor, 45.0)
        elif len(short_hits) >= 2:
            floor = max(floor, 25.0)
    if n_words >= 400:
        if len(S) >= 6:
            floor = max(floor, 45.0)
        elif len(S) >= 5:
            floor = max(floor, 25.0)
    final = int(round(min(100.0, max(score, floor))))
    final = max(0, final)

    if n_words < 40:
        conf, reason = 'none', 'fewer than 40 words, so no confidence in the score'
    elif n_words < 120 or (n_words < 300 and len(S) == 1):
        conf = 'low'
        reason = ('only %d words' % n_words) if n_words < 120 else 'only one score-moving pattern family in under 300 words'
    elif n_words < 300:
        conf, reason = 'moderate', 'between 120 and 300 words'
    else:
        conf, reason = 'high', ''

    metrics = {
        'scanned_chars': scanned,
        'truncated': truncated,
        'ai_tell_score': final,
        'ai_tell_band': _band(final),
        'confidence': conf,
        'confidence_reason': reason,
        'patterns_flagged': len(findings),
        'invisible_chars': len(inv),
        'nonstandard_spaces': len(ns),
        'homoglyphs': sum(look for _, _, look in hg),
        'words': n_words,
        'sentences': len(sents),
    }
    if ci:
        n_sent = len(sents)
        if n_sent >= 4:
            delta = max(2, int(round(20.0 / math.sqrt(n_sent))))
            metrics['score_ci'] = [max(0, final - delta), min(100, final + delta)]
            metrics['score_ci_note'] = ('interval of +/-%d around the score, derived from %d sentences '
                                        '(not resampled)' % (delta, n_sent))
        else:
            metrics['score_ci'] = None
            metrics['score_ci_note'] = 'too few sentences for an interval (%d; need at least 4)' % n_sent

    report = {}
    for key in sorted(findings, key=lambda k: (int(k.split('_', 1)[0]), k)):
        report[key] = findings[key]
    report['_metrics'] = metrics
    return report


# ---------------------------------------------------------------------------
# Command line
# ---------------------------------------------------------------------------

def _error(message: str, code: int) -> int:
    sys.stderr.buffer.write((json.dumps({'error': message}, ensure_ascii=False) + '\n').encode('utf-8'))
    return code


def _write_out(data: str) -> None:
    sys.stdout.buffer.write(data.encode('utf-8'))
    sys.stdout.buffer.flush()


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    clean = False
    ci = False
    operands = []
    end = False
    for arg in argv:
        if end:
            operands.append(arg)
        elif arg == '--':
            end = True
        elif arg in ('--help', '-h'):
            _write_out(USAGE + '\n')
            return 0
        elif arg == '--clean':
            clean = True
        elif arg == '--ci':
            ci = True
        elif arg.startswith('-'):
            return _error('unknown option %s (see --help)' % arg, 2)
        else:
            operands.append(arg)

    if len(operands) >= 2:
        sys.stderr.buffer.write(
            ('prosecheck: only the last file operand is scanned: %s (ignored: %s)\n'
             % (operands[-1], ', '.join(operands[:-1]))).encode('utf-8'))

    try:
        if operands:
            text = extract_path(operands[-1])
        else:
            text = decode_text(sys.stdin.buffer.read())
    except InputError as exc:
        return _error(str(exc), 1)

    if not text.strip():
        return _error('empty input', 1)

    if clean:
        _write_out(cleanup_text(text))
        return 0

    report = analyze(text, ci=ci)
    _write_out(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    return 0


if __name__ == '__main__':
    sys.exit(main())
