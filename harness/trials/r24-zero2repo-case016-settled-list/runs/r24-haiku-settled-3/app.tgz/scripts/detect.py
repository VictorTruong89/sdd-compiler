#!/usr/bin/env python3
"""prosecheck detector: local, Python standard library only, deterministic.

Usage: detect.py [--clean] [--ci] [--] [FILE]
"""
from __future__ import annotations

import io
import json
import math
import os
import posixpath
import random
import re
import sys
import unicodedata
import zipfile
import xml.etree.ElementTree as ET
from collections import Counter
from html.parser import HTMLParser

WINDOW = 262144
PLAIN_CAP = 512 * 1024
ARCHIVE_CAP = 4 * 1024 * 1024
ZIP_EXTS = {'.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'}
NOTEBOOK_EXTS = {'.ipynb'}
BINARY_EXTS = {'.pdf', '.rtf'}

USAGE = """usage: detect.py [--clean] [--ci] [--] [FILE]

Scan FILE, or standard input when no FILE is given, for AI-writing patterns.
Prints one JSON report on standard output (exit 0).

  --clean   print the scrubbed text instead of the report
  --ci      add a low/high interval on the score (needs at least four sentences)
  --        end option parsing, so FILE may begin with a dash
  -h, --help
            print this message and exit 0

Plain text (.md .mdx .markdown .txt .text .rst .tex .org .adoc) is read as UTF-8 or UTF-16.
Zip documents (.docx .docm .pptx .pptm .xlsx .xlsm .odt .odp .ods .epub) and notebooks
(.ipynb, markdown cells only) are extracted to visible text. Other files are read as plain text.
Only the first 262,144 characters of extracted prose are scored.
"""


class Fatal(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code
        self.message = message


def _write_bytes(stream, data):
    stream.buffer.write(data)
    stream.flush()


def _err_line(message):
    _write_bytes(sys.stderr, (json.dumps({"error": message}, ensure_ascii=False) + "\n").encode("utf-8", "replace"))


def _local(tag):
    return tag.rsplit('}', 1)[-1] if '}' in tag else tag


# ---------------------------------------------------------------- extraction

def decode_plain(data):
    if data.startswith(b'\xff\xfe') or data.startswith(b'\xfe\xff'):
        text = data.decode('utf-16', errors='replace')
    else:
        if data.startswith(b'\xef\xbb\xbf'):
            data = data[3:]
        text = data.decode('utf-8', errors='replace')
    if text.startswith('﻿'):
        text = text[1:]
    return text.replace('\r\n', '\n').replace('\r', '\n')


def _docx_text(zf):
    try:
        root = ET.fromstring(zf.read('word/document.xml'))
    except (KeyError, ET.ParseError):
        return ''
    paras = []
    for p in root.iter():
        if _local(p.tag) != 'p':
            continue
        parts = []
        for e in p.iter():
            ln = _local(e.tag)
            if ln == 't' and e.text:
                parts.append(e.text)
            elif ln == 'tab':
                parts.append('\t')
            elif ln in ('br', 'cr'):
                parts.append('\n')
        paras.append(''.join(parts))
    return '\n'.join(x for x in paras if x.strip())


def _pptx_text(zf):
    names = [n for n in zf.namelist() if re.match(r'ppt/slides/slide\d+\.xml$', n)]
    names.sort(key=lambda n: int(re.search(r'(\d+)\.xml$', n).group(1)))
    slides = []
    for n in names:
        try:
            root = ET.fromstring(zf.read(n))
        except ET.ParseError:
            continue
        lines = []
        for p in root.iter():
            if _local(p.tag) == 'p':
                t = ''.join(e.text or '' for e in p.iter() if _local(e.tag) == 't')
                if t.strip():
                    lines.append(t)
        slides.append('\n'.join(lines))
    return '\n'.join(s for s in slides if s.strip())


def _xlsx_text(zf):
    shared = []
    if 'xl/sharedStrings.xml' in zf.namelist():
        try:
            root = ET.fromstring(zf.read('xl/sharedStrings.xml'))
            for si in root.iter():
                if _local(si.tag) == 'si':
                    shared.append(''.join(e.text or '' for e in si.iter() if _local(e.tag) == 't'))
        except ET.ParseError:
            shared = []
    names = [n for n in zf.namelist() if re.match(r'xl/worksheets/sheet\d+\.xml$', n)]
    names.sort(key=lambda n: int(re.search(r'(\d+)\.xml$', n).group(1)))
    sheets = []
    for n in names:
        try:
            root = ET.fromstring(zf.read(n))
        except ET.ParseError:
            continue
        cells = []
        for c in root.iter():
            if _local(c.tag) != 'c':
                continue
            t = c.get('t')
            v = None
            for ch in c:
                if _local(ch.tag) == 'v':
                    v = ch.text
            if t == 's':
                if v is not None and v.strip().isdigit():
                    idx = int(v.strip())
                    if idx < len(shared):
                        cells.append(shared[idx])
            elif t == 'inlineStr':
                cells.append(''.join(e.text or '' for e in c.iter() if _local(e.tag) == 't'))
            elif t == 'str':
                if v:
                    cells.append(v)
        sheets.append('\n'.join(x for x in cells if x.strip()))
    return '\n'.join(s for s in sheets if s.strip())


def _odf_walk(el, out):
    ln = _local(el.tag)
    if ln in ('annotation', 'annotation-end'):
        return
    if ln == 's':
        cnt = 1
        for k, v in el.attrib.items():
            if _local(k) == 'c' and v.isdigit():
                cnt = int(v)
        out.append(' ' * max(1, cnt))
    elif ln == 'tab':
        out.append('\t')
    elif ln == 'line-break':
        out.append('\n')
    elif el.text:
        out.append(el.text)
    for c in el:
        _odf_walk(c, out)
        if c.tail:
            out.append(c.tail)
    if ln in ('p', 'h'):
        out.append('\n')


def _odf_text(zf):
    try:
        root = ET.fromstring(zf.read('content.xml'))
    except (KeyError, ET.ParseError):
        return ''
    out = []
    for body in root.iter():
        if _local(body.tag) == 'body':
            _odf_walk(body, out)
            break
    lines = [ln.rstrip() for ln in ''.join(out).split('\n')]
    return '\n'.join(ln for ln in lines if ln.strip())


SKIP_TAGS = {'script', 'style', 'head', 'nav', 'title'}
BLOCK_TAGS = {'p', 'div', 'br', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'tr', 'section',
              'article', 'blockquote', 'pre', 'hr', 'header', 'footer', 'figure', 'figcaption',
              'dt', 'dd', 'ul', 'ol', 'table', 'body'}


class _HTMLText(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.out = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        if tag in SKIP_TAGS:
            self.skip += 1
        elif tag in BLOCK_TAGS:
            self.out.append('\n')

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag in SKIP_TAGS:
            if self.skip:
                self.skip -= 1
        elif tag in BLOCK_TAGS:
            self.out.append('\n')

    def handle_data(self, data):
        if not self.skip:
            self.out.append(re.sub(r'\s+', ' ', data))

    def text(self):
        t = ''.join(self.out)
        t = re.sub(r' *\n *', '\n', t)
        t = re.sub(r'\n{2,}', '\n', t)
        return t.strip()


def html_to_text(raw):
    p = _HTMLText()
    try:
        p.feed(raw.decode('utf-8', errors='replace'))
        p.close()
    except Exception:
        pass
    return p.text()


def _epub_text(zf):
    names = set(zf.namelist())
    docs = []
    try:
        container = ET.fromstring(zf.read('META-INF/container.xml'))
        opf_path = None
        for el in container.iter():
            if _local(el.tag) == 'rootfile' and el.get('full-path'):
                opf_path = el.get('full-path')
                break
        if opf_path is None or opf_path not in names:
            raise KeyError(opf_path)
        opf = ET.fromstring(zf.read(opf_path))
        base = posixpath.dirname(opf_path)
        manifest = {}
        spine = []
        for el in opf.iter():
            ln = _local(el.tag)
            if ln == 'item':
                manifest[el.get('id')] = (el.get('href'), el.get('properties') or '')
            elif ln == 'itemref':
                spine.append(el.get('idref'))
        for idref in spine:
            if idref not in manifest:
                continue
            href, props = manifest[idref]
            if not href or 'nav' in props.split():
                continue
            path = posixpath.normpath(posixpath.join(base, href)) if base else posixpath.normpath(href)
            if path in names:
                docs.append(path)
    except Exception:
        docs = []
    if not docs:
        docs = sorted(n for n in names if n.lower().endswith(('.xhtml', '.html', '.htm')))
    chapters = []
    for n in docs:
        try:
            raw = zf.read(n)
        except KeyError:
            continue
        t = html_to_text(raw)
        if t:
            chapters.append(t)
    return '\n'.join(chapters)


def _notebook_text(data):
    try:
        obj = json.loads(data.decode('utf-8-sig', errors='replace'))
    except (ValueError, UnicodeDecodeError):
        return ''
    if not isinstance(obj, dict):
        return ''
    cells = obj.get('cells')
    if not isinstance(cells, list):
        return ''
    parts = []
    for cell in cells:
        if not isinstance(cell, dict):
            return ''
        if cell.get('cell_type') != 'markdown':
            continue
        src = cell.get('source', '')
        if isinstance(src, list):
            if not all(isinstance(x, str) for x in src):
                return ''
            src = ''.join(src)
        elif not isinstance(src, str):
            return ''
        src = src.rstrip()
        if src.strip():
            parts.append(src)
    return '\n'.join(parts).strip()


def extract_zip(data, ext, path):
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except (zipfile.BadZipFile, OSError, ValueError):
        raise Fatal(1, "cannot read input: %s is not a readable zip archive" % path)
    try:
        if ext in ('.docx', '.docm'):
            text = _docx_text(zf)
        elif ext in ('.pptx', '.pptm'):
            text = _pptx_text(zf)
        elif ext in ('.xlsx', '.xlsm'):
            text = _xlsx_text(zf)
        elif ext in ('.odt', '.odp', '.ods'):
            text = _odf_text(zf)
        else:
            text = _epub_text(zf)
    except (zipfile.BadZipFile, OSError, ValueError, KeyError):
        raise Fatal(1, "cannot read input: %s is not a readable zip archive" % path)
    finally:
        zf.close()
    return text.strip()


def load_text(path):
    """Return the extracted prose for a path, or for standard input when path is None."""
    if path is None:
        return decode_plain(sys.stdin.buffer.read())
    try:
        with open(path, 'rb') as fh:
            data = fh.read()
    except OSError as exc:
        raise Fatal(1, "cannot read input: %s: %s" % (path, exc.strerror or exc))
    ext = os.path.splitext(path)[1].lower()
    if ext in ZIP_EXTS:
        return extract_zip(data, ext, path)
    if ext in NOTEBOOK_EXTS:
        return _notebook_text(data)
    if ext in BINARY_EXTS:
        return ''
    return decode_plain(data)


# ---------------------------------------------------------- character layer

_EXTRA_INV = {0x034F, 0x115F, 0x1160, 0x3164, 0xFFA0, 0x17B4, 0x17B5}
_SPACELESS = re.compile('[฀-໿က-႟ក-៿　-〿぀-ヿ'
                        '㐀-䶿一-鿿豈-﫿]')
_CJK = re.compile('[㐀-䶿一-鿿豈-﫿\U00020000-\U0002ffff]')
_JOINING = re.compile('[֐-ۿݐ-ݿࢠ-ࣿऀ-෿က-႟'
                      'ក-៿יִ-﷿ﹰ-﻾]')
_RTL = re.compile('[֐-ࣿיִ-﷿ﹰ-﻾]')
_KHMER = re.compile('[ក-៿]')
_MONGOL = re.compile('[᠀-᢯]')

# Lookalike letters (Cyrillic, Greek, Armenian) drawn like an ASCII Latin letter.
LOOKALIKES = {
    'а': 'a', 'с': 'c', 'ԁ': 'd', 'е': 'e', 'һ': 'h', 'і': 'i',
    'ј': 'j', 'о': 'o', 'р': 'p', 'ѕ': 's', 'у': 'y', 'х': 'x',
    'ѵ': 'v', 'ѡ': 'w', 'ո': 'n', 'օ': 'o', 'ս': 'u', 'ο': 'o',
    'ι': 'i', 'ν': 'v', 'ϲ': 'c', 'ρ': 'p',
    'А': 'A', 'В': 'B', 'С': 'C', 'Е': 'E', 'Н': 'H', 'І': 'I',
    'Ј': 'J', 'К': 'K', 'М': 'M', 'Ν': 'N', 'О': 'O', 'Р': 'P',
    'Ѕ': 'S', 'Т': 'T', 'Х': 'X', 'У': 'Y', 'Ү': 'Y', 'Α': 'A',
    'Β': 'B', 'Ε': 'E', 'Ζ': 'Z', 'Η': 'H', 'Ι': 'I', 'Κ': 'K',
    'Μ': 'M', 'Ο': 'O', 'Ρ': 'P', 'Τ': 'T', 'Χ': 'X', 'Υ': 'Y',
}
_DOMAIN_LIKE = re.compile(r'(?:://|www\.|/|@|\.(?:com|org|net|io|dev|ai|edu|gov|co|info)\b)', re.I)


def _is_invisible(ch):
    cp = ord(ch)
    if cp in (9, 10, 13):
        return False
    if cp < 0x20 or 0x7F <= cp <= 0x9F:
        return True
    if cp in _EXTRA_INV or 0x180B <= cp <= 0x180F:
        return True
    if 0xFE00 <= cp <= 0xFE0F or 0xE0000 <= cp <= 0xE0FFF:
        return True
    return unicodedata.category(ch) == 'Cf'


def _isletter(ch):
    return bool(ch) and ch.isalpha()


def _emojiish(ch):
    if not ch:
        return False
    cp = ord(ch)
    return cp >= 0x1F000 or unicodedata.category(ch).startswith('S') or 0x2600 <= cp <= 0x27BF


def _keep_invisible(W, i, has_rtl, kept):
    cp = ord(W[i])
    p = W[i - 1] if i > 0 else ''
    n = W[i + 1] if i + 1 < len(W) else ''
    if cp == 0xAD:
        return _isletter(p) and _isletter(n)
    if cp == 0x200B:
        return bool(p and _SPACELESS.match(p)) or bool(n and _SPACELESS.match(n))
    if cp in (0x200C, 0x200D):
        for c in (p, n):
            if c and ((_isletter(c) and _JOINING.match(c)) or _emojiish(c)):
                return True
        return False
    if cp in (0x200E, 0x200F, 0x061C) or 0x202A <= cp <= 0x202E or 0x2066 <= cp <= 0x2069:
        return has_rtl
    if 0x180B <= cp <= 0x180F:
        return bool(p and _MONGOL.match(p))
    if cp in (0x17B4, 0x17B5):
        return bool((p and _KHMER.match(p)) or (n and _KHMER.match(n)))
    if 0xFE00 <= cp <= 0xFE0F or 0xE0100 <= cp <= 0xE01EF:
        return _emojiish(p) or bool(p and _CJK.match(p)) or n == '⃣'
    if 0xE0020 <= cp <= 0xE007F:
        if p == '\U0001F3F4':
            return True
        return bool(p) and 0xE0020 <= ord(p) <= 0xE007F and kept[i - 1]
    return False


def _nbsp_kept(W, i):
    p = W[i - 1] if i > 0 else ''
    n = W[i + 1] if i + 1 < len(W) else ''
    if (p and p.isdigit()) or (n and n.isdigit()):
        return True
    if n and n in ':;!?»›%€':
        return True
    if p and p in '«‹':
        return True
    return False


def _fold_homoglyphs(text):
    stats = {'n': 0, 'samples': []}

    def repl(m):
        tok = m.group(0)
        if _DOMAIN_LIKE.search(tok):
            return tok
        lk = [c for c in tok if c in LOOKALIKES]
        if not lk or not any(c.isascii() and c.isalpha() for c in tok):
            return tok
        for c in tok:
            if c.isalpha() and not c.isascii() and c not in LOOKALIKES:
                return tok
        stats['n'] += len(lk)
        if len(stats['samples']) < 3:
            stats['samples'].append(tok[:40])
        return ''.join(LOOKALIKES.get(c, c) for c in tok)

    out = re.sub(r'\S+', repl, text)
    return out, stats['n'], stats['samples']


def char_layer(W):
    """Apply the deterministic character layer. Returns normalized text and counts."""
    has_rtl = bool(_RTL.search(W))
    kept = [False] * len(W)
    out = []
    inv = nonstd = 0
    inv_s, nonstd_s = [], []
    for i, c in enumerate(W):
        if c == ' ' or c == '\n' or c == '\t':
            out.append(c)
            continue
        if c in (' ', ' '):
            out.append('\n')
            nonstd += 1
            if len(nonstd_s) < 3:
                nonstd_s.append('U+%04X' % ord(c))
            continue
        if _is_invisible(c):
            if _keep_invisible(W, i, has_rtl, kept):
                kept[i] = True
                out.append(c)
            else:
                inv += 1
                if len(inv_s) < 3:
                    inv_s.append('U+%04X' % ord(c))
            continue
        if unicodedata.category(c) == 'Zs':
            if c in '  ' and _nbsp_kept(W, i):
                out.append(c)
            else:
                out.append(' ')
                nonstd += 1
                if len(nonstd_s) < 3:
                    nonstd_s.append('U+%04X' % ord(c))
            continue
        out.append(c)
    text = ''.join(out)
    text, homo, homo_s = _fold_homoglyphs(text)
    return {'text': text, 'inv': inv, 'inv_s': inv_s, 'nonstd': nonstd, 'nonstd_s': nonstd_s,
            'homo': homo, 'homo_s': homo_s}


_TRAIL_RE = re.compile(r'[ \t]+(?=\n|\Z)')


def trailing_hits(N):
    samples = []
    count = 0
    for _ in _TRAIL_RE.finditer(N):
        count += 1
    if N.endswith('\n\n'):
        count += 1
    if N[:1].isspace():
        count += 1
    if count:
        samples.append('trailing or stray whitespace')
    return count, samples


# ------------------------------------------------------------- masking

_FENCE_OPEN = re.compile(r'^ {0,3}(`{3,}|~{3,})(.*)$')
_FENCE_CLOSE = re.compile(r'^ {0,3}(`{3,}|~{3,})[ \t]*$')
_INLINE_CODE = re.compile(r'(`+)(?!`)(.+?)(?<!`)\1(?!`)')
_BADGE = re.compile(r'^\s*(?:\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)\s*)+$')


def mask_markdown(N):
    """Blank (to spaces, keeping newlines and offsets) regions that generate no findings."""
    lines = N.split('\n')
    n = len(lines)
    masked = [False] * n
    if n and lines[0].rstrip() == '---':
        for j in range(1, n):
            if lines[j].rstrip() in ('---', '...'):
                for k in range(j + 1):
                    masked[k] = True
                break
    i = 0
    while i < n:
        if masked[i]:
            i += 1
            continue
        m = _FENCE_OPEN.match(lines[i])
        if m and not (m.group(1)[0] == '`' and '`' in m.group(2)):
            fence = m.group(1)
            ch, flen = fence[0], len(fence)
            end = n - 1
            for j in range(i + 1, n):
                mc = _FENCE_CLOSE.match(lines[j])
                if mc and mc.group(1)[0] == ch and len(mc.group(1)) >= flen:
                    end = j
                    break
            for k in range(i, end + 1):
                masked[k] = True
            i = end + 1
        else:
            i += 1
    # runs of two or more blockquote lines
    i = 0
    while i < n:
        if not masked[i] and re.match(r'^ {0,3}>', lines[i]):
            j = i
            while j < n and not masked[j] and re.match(r'^ {0,3}>', lines[j]):
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    masked[k] = True
            i = j
        else:
            i += 1
    for k in range(n):
        if masked[k]:
            continue
        ln = lines[k]
        if ln.count('|') >= 2 and ln.strip():
            masked[k] = True
        elif _BADGE.match(ln) and '[![' in ln:
            masked[k] = True
    out = []
    for k, ln in enumerate(lines):
        if masked[k]:
            out.append(' ' * len(ln))
        else:
            out.append(_INLINE_CODE.sub(lambda m: ' ' * len(m.group(0)), ln))
    return '\n'.join(out)


def _sent_spans(M):
    spans = []
    pos = 0
    for line in M.split('\n'):
        for m in _SENT_RE.finditer(line):
            s, e = pos + m.start(), pos + m.end()
            if _WORD_RE.search(M, s, e):
                spans.append((s, e))
        pos += len(line) + 1
    return spans


_SENT_RE = re.compile(r'\S.*?(?:[.!?]+(?=\s|$)|$)')
_WORD_RE = re.compile(r"[^\W_]+(?:['’\-]+[^\W_]+)*")


def words_of(s):
    return _WORD_RE.findall(s)


def _para_spans(M):
    spans = []
    pos = 0
    for m in re.finditer(r'\n[ \t]*\n', M):
        spans.append((pos, m.start()))
        pos = m.end()
    spans.append((pos, len(M)))
    return [(s, e) for s, e in spans if M[s:e].strip()]


# ------------------------------------------------------------------ rules

LABELS = {
    1: 'AI vocabulary', 2: 'Model-dialect vocabulary', 3: 'Promotional language',
    4: 'Hyphenated word-pair overuse', 5: 'Simple yet X cliche', 6: 'Stacked adjective chains',
    7: 'Rule of three overuse', 8: 'Synonym cycling', 9: 'Generic character naming',
    10: 'Significance inflation', 11: 'Notability name-dropping', 12: 'Vague attributions',
    13: 'Article title as proper noun', 14: 'Conservation padding', 15: 'False ranges',
    16: 'Superficial -ing tail clause', 17: 'Negative parallelism', 18: 'Not X, just Y',
    19: 'Filler phrases', 20: 'Empty pivot phrase', 21: 'Outcome speculation tail',
    22: 'Persuasive authority trope', 23: 'Editorial interjection', 24: 'Self-thoroughness phrase',
    25: 'Question-answer rhetorical pattern', 26: 'Concrete-evidence defense phrase',
    27: 'Compulsive intro hook', 28: 'Meandering intro', 29: 'Prompt echo',
    30: 'Diff-anchored writing', 31: 'Signposting and announcement', 32: 'Cataloguing lead-in',
    33: 'Inline-header vertical list', 34: 'Mid-essay bullet injection', 35: 'Fragmented header',
    36: 'Formulaic challenges section', 37: 'Transition cluster', 38: 'Compulsive conclusion phrase',
    39: 'Generic positive conclusion', 40: 'Sentence-length monotony',
    41: 'Mechanical sentence-length alternation', 42: 'Opener repetition',
    43: 'Fragment and run-on avoidance', 44: 'Uniform paragraph length',
    45: 'Identical paragraph structure', 46: 'Semicolon and parenthesis underuse',
    47: 'Chatbot artifact', 48: 'Sycophantic tone', 49: 'Helpful-assistant register',
    50: 'Knowledge-cutoff disclaimer', 51: 'Copula avoidance',
    52: 'Passive voice and subjectless fragments', 53: 'Two-way passive-voice drift',
    54: 'Hedge stacking', 55: 'Contraction absence', 56: 'Boldface overuse', 57: 'Emoji',
    58: 'Em-dash overuse', 59: 'Title case in heading', 60: 'Curly quotation marks',
    61: 'Hyphen for en dash in ranges', 62: 'Invisible or zero-width character',
    63: 'Placeholder text', 64: 'Chat reference-markup leak', 65: 'AI tracking parameter',
    66: 'Mixed-script homoglyph', 67: 'Non-standard space', 68: 'Trailing or stray whitespace',
    69: 'Canonical marketing phrase', 70: 'Decorative horizontal rule', 71: 'Degenerate repetition',
}
# Writing advice: never moves the score (PRD list of 12, plus both forms of 17 per RULINGS 4).
ADVICE = {4, 17, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68}
DECISIVE = {13, 47, 48, 50, 62, 63, 64, 65, 66}
SHORT_SET = set(range(1, 40)) | set(range(47, 52)) | {69}
AI_HOSTS = {'chatgpt.com', 'chat.openai.com', 'perplexity.ai', 'claude.ai',
            'gemini.google.com', 'copilot.microsoft.com', 'poe.com'}


def _forms(w):
    f = {w, w + 's', w + 'es', w + 'ed', w + 'ing'}
    if w.endswith('e'):
        f |= {w + 'd', w[:-1] + 'ing', w + 's'}
    if w.endswith('y'):
        f |= {w[:-1] + 'ies', w[:-1] + 'ied'}
    return f


AI_WORDS = ['additionally', 'crucial', 'delve', 'tapestry', 'pivotal', 'vibrant', 'meticulous',
            'testament', 'underscore', 'intricate', 'intricacies', 'interplay', 'garner', 'bolster',
            'foster', 'showcase', 'emphasize', 'enduring', 'enhance', 'leverage', 'utilize',
            'facilitate', 'encompass', 'harness', 'holistic', 'paradigm', 'transformative',
            'unprecedented', 'myriad', 'plethora', 'robust', 'seamless', 'navigate', 'embark',
            'craft', 'landscape', 'journey', 'realm', 'multifaceted', 'elevate', 'empower', 'unlock']

ADV_ALL = None


def _rx_fn(pattern, flags=re.I):
    cre = re.compile(pattern, flags)

    def fn(c):
        ms = list(cre.finditer(c.M))
        return len(ms), [c.N[m.start():m.end()] for m in ms]
    return fn


def _combine(*fns):
    def fn(c):
        tot, smp = 0, []
        for f in fns:
            k, s = f(c)
            tot += k
            smp.extend(s)
        return tot, smp
    return fn


def _cv(xs):
    m = sum(xs) / len(xs)
    if m == 0:
        return None
    sd = math.sqrt(sum((x - m) ** 2 for x in xs) / len(xs))
    return sd / m


def _fn_imperative(c):
    verbs = (r'(?:install|join|grab|download|try|discover|experience|escape|transform|reclaim|'
             r'unlock|elevate|boost|say|imagine|explore|meet|introducing|upgrade|claim|unleash|'
             r'supercharge|level|stop|start)\b')
    hits = [(s, e) for s, e in c.sents if re.match(verbs, c.M[s:e].lstrip(), re.I)]
    if len(hits) >= 3:
        return len(hits), [c.N[s:e] for s, e in hits[:3]]
    return 0, []


_CHAIN = re.compile(r"\b[A-Za-z][A-Za-z\-]*(?:[ \t]*,[ \t]*[A-Za-z][A-Za-z\-]*)+"
                    r"(?:[ \t]*,?[ \t]+and[ \t]+[A-Za-z][A-Za-z\-]*)?\b")
_ADJ_SUFFIX = re.compile(r'(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$')
_STOCK_ADJ = {'robust', 'seamless', 'vibrant', 'dynamic', 'powerful', 'modern', 'innovative',
              'cutting-edge', 'elegant', 'fast', 'secure', 'reliable', 'scalable', 'intuitive',
              'bold', 'smart', 'premium', 'stunning', 'exceptional', 'unparalleled'}


def _fn_chains(c):
    tot, smp = 0, []
    for m in _CHAIN.finditer(c.M):
        words = re.findall(r'[A-Za-z][A-Za-z\-]*', m.group(0))
        if len(words) < 4:
            continue
        if any(_ADJ_SUFFIX.search(w.lower()) or w.lower() in _STOCK_ADJ for w in words):
            tot += 1
            smp.append(c.N[m.start():m.end()])
    return tot, smp[:3]


_CLUSTERS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]


def _fn_synonyms(c):
    tot, smp = 0, []
    for cluster in _CLUSTERS:
        present = [w for w in cluster if re.search(r'\b' + re.escape(w) + r'(?:s|es)?\b', c.M, re.I)]
        if len(present) < 3:
            continue
        rx = re.compile(r'\b(?:' + '|'.join(re.escape(w) + r'(?:s|es)?' for w in cluster) + r')\b', re.I)
        ms = list(rx.finditer(c.M))
        tot += len(ms)
        smp.extend(c.N[m.start():m.end()] for m in ms[:1])
    return tot, smp[:3]


def _fn_headings_titlecase(c):
    small = {'a', 'an', 'the', 'and', 'but', 'or', 'nor', 'for', 'so', 'yet', 'at', 'by', 'in',
             'of', 'on', 'to', 'up', 'as', 'from', 'with', 'into', 'over', 'via', 'per', 'off'}
    tot, smp = 0, []
    for line in c.M.split('\n'):
        m = re.match(r'^#{1,6}[ \t]+(.+?)[ \t]*#*[ \t]*$', line)
        if not m:
            continue
        t = m.group(1)
        if not t or not t[0].isalpha():
            continue
        words = re.findall(r"[^\W\d_][^\W_]*(?:['’-][^\W_]+)*", t)
        if len(words) < 3 or t.upper() == t:
            continue
        majors = [w for w in words if w.lower() not in small]
        if len(majors) < 2:
            continue
        if all(w[0].isupper() for w in majors):
            tot += 1
            smp.append(t)
    return tot, smp[:3]


def _fn_mid_bullets(c):
    if re.search(r'(?m)^#{1,6}[ \t]', c.M):
        return 0, []
    lists, prose, smp = 0, 0, []
    for s, e in c.paras:
        ls = [ln for ln in c.M[s:e].split('\n') if ln.strip()]
        if ls and all(re.match(r'^\s*(?:[-*+]|\d+[.)])\s+', ln) for ln in ls):
            lists += 1
            smp.append(ls[0].strip()[:60])
        else:
            prose += 1
    if lists >= 1 and prose >= 2:
        return lists, smp[:3]
    return 0, []


def _fn_fragmented_headers(c):
    lines = c.M.split('\n')
    hits, smp = 0, []
    for i, ln in enumerate(lines):
        m = re.match(r'^#{1,6}[ \t]+(.+?)[ \t]*#*[ \t]*$', ln)
        if not m:
            continue
        head = {w.lower() for w in re.findall(r'[^\W\d_]{3,}', m.group(1))}
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nxt = lines[j].strip()
        if re.match(r'^(#|[-*+>|`]|\d+[.)]\s|\*\*)', nxt):
            continue
        if len(nxt.split()) > 4:
            continue
        if head & {w.lower() for w in re.findall(r'[^\W\d_]{3,}', nxt)}:
            hits += 1
            smp.append(ln.strip() + ' / ' + nxt)
    return hits, smp[:3]


_TRANS = {'Additionally', 'Furthermore', 'Moreover', 'However', 'Nevertheless', 'Consequently',
          'Subsequently', 'Notably'}


def _fn_transitions(c):
    tot, smp = 0, []
    for s, e in c.paras:
        text = c.M[s:e]
        k = 0
        for a, b in _sent_spans(text):
            m = re.match(r'\s*([A-Za-z]+)', text[a:b])
            if m and m.group(1) in _TRANS:
                k += 1
        if k >= 2:
            tot += k
            smp.append(text.strip()[:60])
    return tot, smp[:3]


def _fn_opener_repetition(c):
    tot, smp = 0, []
    for s, e in c.paras:
        text = c.M[s:e]
        sp = _sent_spans(text)
        if len(sp) < 3:
            continue
        opens = []
        for a, b in sp:
            w = words_of(text[a:b])[:2]
            if len(w) == 2:
                opens.append(' '.join(w).lower())
        for k, v in Counter(opens).items():
            if v >= 3:
                tot += v
                smp.append(k)
    return tot, smp[:3]


def _fn_monotony(c):
    xs = [n for n in c.sent_counts if n > 0]
    if len(xs) >= 3:
        cv = _cv(xs)
        if cv is not None and cv < 0.35:
            return 1, ['sentence lengths nearly uniform']
    return 0, []


def _fn_uniform_paras(c):
    xs = [len(words_of(c.M[s:e])) for s, e in c.paras]
    xs = [x for x in xs if x > 0]
    if len(xs) >= 4:
        cv = _cv(xs)
        if cv is not None and cv < 0.4:
            return 1, ['paragraph lengths nearly uniform']
    return 0, []


def _fn_alternation(c):
    L = [n for n in c.sent_counts if n > 0]
    hits, i = 0, 0
    while i + 6 <= len(L):
        w = L[i:i + 6]
        d = [w[k + 1] - w[k] for k in range(5)]
        if all(d[k] * d[k + 1] < 0 for k in range(4)) and min(abs(x) for x in d) >= 6:
            hits += 1
            i += 6
        else:
            i += 1
    return hits, (['alternating sentence lengths'] if hits else [])


_HEDGE = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems? to|"
                    r"seems? like|appears? to|somewhat|relatively|fairly|kind of|sort of)\b")


def _fn_hedges(c):
    tot, smp = 0, []
    for s, e in c.sents:
        if len(_HEDGE.findall(c.M[s:e])) >= 2:
            tot += 1
            smp.append(c.N[s:e][:80])
    return tot, smp[:3]


_FIRST = re.compile(r"\bI\b|\b(?i:me|my|we|us|our)\b")
_WRITTEN = re.compile(r"\b(?i:it is|that is|do not|does not|did not|is not|are not|was not|were not|"
                      r"will not|would not|have not|has not|I am|I will|I have|I would|we are|"
                      r"we have|we will|you are|they are|let us)\b")
_CONTR = re.compile(r"[’'](?:s|t|m|re|ve|ll|d)\b")


def _fn_contractions(c):
    nw = c.nwords
    fp = len(_FIRST.findall(c.M))
    if nw == 0 or fp < 5 or fp / nw < 0.03:
        return 0, []
    w = len(_WRITTEN.findall(c.M))
    k = len(_CONTR.findall(c.M))
    if w >= 3 and w >= 0.8 * (w + k):
        return 1, ['few contractions in first-person prose']
    return 0, []


_BOLD = re.compile(r"\*\*[^*\n]+?\*\*")


def _fn_bold(c):
    ms = list(_BOLD.finditer(c.M))
    if len(ms) >= 2:
        return len(ms), [c.N[m.start():m.end()] for m in ms[:3]]
    return 0, []


def _fn_em_dash(c):
    tot, smp = 0, []
    for s, e in c.paras:
        k = c.M.count('\u2014', s, e)
        if k >= 2:
            tot += k
            smp.append('%d em dashes in one paragraph' % k)
    return tot, smp[:3]


_CURLY = re.compile('[\u2018\u2019\u201c\u201d]')


def _fn_curly(c):
    ms = list(_CURLY.finditer(c.M))
    return len(ms), [c.N[max(0, m.start() - 15):m.end() + 15] for m in ms[:3]]


_YR = re.compile(r"\b(1[5-9]\d\d|20\d\d)-(1[5-9]\d\d|20\d\d)\b")


def _fn_year_ranges(c):
    ms = [m for m in _YR.finditer(c.M) if int(m.group(1)) < int(m.group(2))]
    return len(ms), [m.group(0) for m in ms[:3]]


_UTM = re.compile(r"utm_source=([^&\s#)\"'<>\]]*)", re.I)


def _fn_utm(c):
    tot, smp = 0, []
    for m in _UTM.finditer(c.M):
        host = re.match(r"[A-Za-z0-9.\-]*", m.group(1)).group(0).rstrip('.')
        if host.lower() in AI_HOSTS:
            tot += 1
            smp.append(c.N[m.start():m.end()])
    return tot, smp[:3]


_HR = re.compile(r"^[ \t]*(?:-{3,}|\*{3,}|_{3,})[ \t]*$", re.M)


def _fn_hr(c):
    nonblank = sum(1 for ln in c.M.split('\n') if ln.strip())
    k = len(_HR.findall(c.M))
    if nonblank >= 24 and k >= 3:
        return k, ['horizontal rules used as dividers']
    return 0, []


def _fn_repetition(c):
    toks = [w.lower() for w in words_of(c.M)]
    if len(toks) < 12:
        return 0, []
    grams = [tuple(toks[i:i + 6]) for i in range(len(toks) - 5)]
    cnt = Counter(grams)
    rep = sum(v for v in cnt.values() if v >= 2)
    if rep / len(grams) >= 0.2:
        return rep, [' '.join(g) for g, v in cnt.most_common(3) if v >= 2]
    return 0, []


def _fn_char(key):
    def fn(c):
        ch = c.char
        if key == 'inv':
            return ch['inv'], ch['inv_s']
        if key == 'homo':
            return ch['homo'], ch['homo_s']
        if key == 'nonstd':
            return ch['nonstd'], ch['nonstd_s']
        return c.trail, c.trail_s
    return fn


_PLACEHOLDER = _combine(
    _rx_fn(r"\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\](?![(\[])"),
    _rx_fn(r"\[[A-Z]{3,}(?:[ _-][A-Z]+)*\](?![(\[])", 0),
    _rx_fn(r"\{\{[^{}\n]*\}\}"),
    _rx_fn(r"\b[xX]{3,}\b", 0),
    _rx_fn(r"\blorem ipsum\b"),
)


def _rules():
    R = _rx_fn
    return [
        (1, 'ai_vocabulary', _combine(
            R(r"\b(?:" + '|'.join(sorted({f for w in AI_WORDS for f in _forms(w)}, key=len, reverse=True)) + r")\b"),
            R(r"\balign(?:s|ed|ing)? with\b"),
            R(r"\bcapture[sd]? the (?:essence|spirit|imagination|heart|magic)\b"))),
        (2, 'model_dialect_vocabulary', _combine(
            R(r"\b(?:genuinely|fascinating|nuanced|thoughtfully|refreshingly|strikingly|compellingly)\b"),
            R(r"\bquietly (?:powerful|profound|radical)\b"),
            R(r"\bdeeply (?:human|personal|felt|unsettling)\b"),
            R(r"\bresonates? deeply\b"),
            R(r"\bgame[- ]chang(?:er|ers|ing)\b"),
            R(r"\b(?:supercharg|turbocharg|skyrocket|revolutioniz)(?:e|es|ed|ing)\b"),
            R(r"\bdouble down on\b"),
            R(r"\bdive deep(?:er)? into\b"),
            R(r"\bunlock(?:s|ed|ing)? (?:the )?(?:power|potential|value)\b"),
            R(r"\btake\b[^.!?\n]{0,60}?\bto the next level\b"))),
        (3, 'promotional_language', _combine(
            R(r"\b(?:nestled|breathtaking|must-visit|stunning|picturesque|charming|idyllic|vibrant community|"
              r"rich cultural heritage|in the heart of|world-class|top-tier|unparalleled|premier|leading|"
              r"esteemed organization|valuable asset|passion for excellence|proven track record|"
              r"results-oriented|wealth of experience|dynamic team|fast-paced environment|deeply passionate|"
              r"perfectly situated|close-knit team|tight-knit team|uniquely positioned to)\b"),
            R(r"\bI am excited to (?:apply|bring)\b"),
            _fn_imperative)),
        (4, 'hyphenated_pairs', R(r"\b(?:cutting-edge|best-in-class|next-generation|state-of-the-art|"
                                  r"game-changing|results-driven|user-friendly|top-notch|world-leading|"
                                  r"forward-thinking|high-impact|value-driven|customer-centric|"
                                  r"mission-critical)\b")),
        (5, 'simple_yet', R(r"\bsimple yet (?:effective|powerful|profound|elegant|transformative|"
                            r"sophisticated|beautiful)\b")),
        (6, 'adjective_chains', _fn_chains),
        (8, 'synonym_cycling', _fn_synonyms),
        (10, 'significance_inflation', _combine(
            R(r"\b(?:stands?|serves?|stood|served) as an? (?:testament|reminder|symbol|beacon|cornerstone|"
              r"bridge|gateway|hallmark)\b"),
            R(r"\b(?:underscor|highlight)(?:es|ed|ing|s)? (?:its|the|their|his|her) "
              r"(?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b"),
            R(r"\breflects? a broader (?:trend|shift|pattern)\b"),
            R(r"\bmarks? an? (?:turning point|milestone|watershed|new chapter|new era)\b"),
            R(r"\bsymboli[sz]es\b"),
            R(r"\bsets? the stage for\b"),
            R(r"\bleft an indelible mark\b"),
            R(r"\bplays? an? (?:crucial|pivotal|vital|key|central|significant) role\b"),
            R(r"\bhas (?:shaped|sparked)\b"),
            R(r"\bhas come to (?:define|symbolize)\b"))),
        (11, 'notability_name_dropping', _combine(
            R(r"(?i:\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased) (?:in|by)) "
              r"[A-Z][\w&.'’-]*(?:,? (?:and |or )?[A-Z][\w&.'’-]*)+", 0),
            R(r"\b\d[\d,.]*\s*(?:[KkMm]\s*)?(?:followers|subscribers)\b"),
            R(r"\bstrong (?:online|digital|social[- ]media) presence\b|\bactive (?:online|digital|social[- ]media) "
              r"presence\b|\bwidely covered\b|\bindependent coverage\b"))),
        (12, 'vague_attributions', R(r"\bexperts? (?:argue|believe|say|claim|note|suggest)\b|"
                                     r"\bindustry (?:reports|observers|analysts)\b|"
                                     r"\bobservers have (?:cited|noted)\b|\bsome critics argue\b|"
                                     r"\bresearchers have found\b|\bstudies suggest\b|"
                                     r"\bit is widely believed\b")),
        (13, 'article_title_proper_noun', R(r"\bThe (?:List|Index|Compilation|Collection|Catalogue|Guide|"
                                            r"Overview) of (?:(?:[A-Z][\w'’-]*|of|the|and|in|for|a|an|to|on|at)\s+)"
                                            r"{1,10}?(?:is|are) (?:a|an|the)\b", 0)),
        (14, 'conservation_padding', R(r"\bplays? an? (?:vital|crucial|key|significant) role in (?:its|the) "
                                       r"ecosystem\b|\bconservation efforts are (?:underway|ongoing|in place)\b|"
                                       r"\bserves? as an indicator species\b|\bcontributes? to biodiversity\b")),
        (15, 'false_ranges', R(r"\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b"
                               r"[^.!?\n]*?\bto (?:the )?(?:modern|present|current|contemporary|digital|future|"
                               r"mighty|vanished|towering)\b|\bfrom (?:the )?humble\b[^.!?\n]*?\bto (?:the )?"
                               r"(?:mighty|towering|grand|sprawling)\b")),
        (16, 'ing_tail', R(r",\s*(?:highlighting|reflecting|symbol(?:i[sz])ing|emphasi[sz]ing|underscoring|"
                           r"showcasing|fostering|cultivating|encompassing|signal(?:l?)ing|demonstrating|"
                           r"illustrating|representing|suggesting|indicating|reinforcing|leveraging|aligning|"
                           r"embodying|exemplifying|epitomizing)\b")),
        (17, 'negative_parallelism', R(r"\bit[’']s not (?:just|merely) (?:about|a|an)\b|"
                                       r"\bnot only\b[^.!?\n]{0,40}?\bbut\b|"
                                       r"\bdoesn[’']t just\b[^,.\n]{0,40}?\bit\b")),
        (17, 'tailing_negation', R(r",\s*no (?:guessing|waste|wasted motion|hassle|fluff|stress|jargon)\b")),
        (18, 'not_x_just_y', _combine(
            R(r"\b(?:no|not) [\w'’-]+,\s*(?:just|only|simply)\s+[\w'’-]+"),
            R(r"\b(?:not|isn[’']t|aren[’']t|wasn[’']t|weren[’']t) (?:just|merely) (?:(?:a|an|the) )?"
              r"[\w'’-]+\s*(?:,|—|–|-)\s*(?:it[’']s|it is|it was|they[’']re|they are|they were|"
              r"that[’']s|but)\b"))),
        (19, 'filler_phrases', R(r"\bin order to\b|\bdue to the fact that\b|\bat this point in time\b|"
                                 r"\bin the event that\b|\bhas the ability to\b|"
                                 r"\bit is important to note that\b|\bit should be mentioned that\b|"
                                 r"\bneedless to say\b")),
        (20, 'empty_pivot', R(r"\bit(?:’|')?s worth (?:noting|mentioning) that\b|\bit bears (?:noting|mentioning) that\b|"
                              r"\bone thing to (?:consider|keep in mind) is\b|\bit is interesting to note that\b|"
                              r"\ba key consideration is\b|\ba point to highlight is\b")),
        (21, 'outcome_tail', R(r",\s*(?:raising questions about|prompting reflection on|sparking debate about|"
                               r"with broader implications for|reshaping our understanding of|paving the way for|"
                               r"signaling a shift toward)\b")),
        (22, 'persuasive_trope', R(r"\bhere(?:’|')?s the thing\b|\bmake no mistake\b|\bthe truth is\b|"
                                   r"\blet(?:’|')?s be honest\b|\bthe simple fact is\b|\bat its core\b|"
                                   r"\bwhat really matters\b|\bmore than anything\b|\bat the end of the day\b|"
                                   r"\bthe bottom line is\b|\bin reality\b|\bfundamentally,|\bthe real question is\b|"
                                   r"\bthe heart of the matter\b|\bthe deeper issue\b|"
                                   r"\bwhen you get down to it\b|\bwhen all is said and done\b")),
        (23, 'editorial_interjection', R(r"\bit(?:’|')?s important to (?:remember|note|understand|recognize)\b|"
                                         r"\bit is important to (?:remember|note|understand|recognize)\b|"
                                         r"\bone must note that\b|\bit is worth pointing out\b|"
                                         r"\bit cannot be overstated that\b|\bit must be emphasi[sz]ed that\b")),
        (24, 'self_thoroughness', R(r"\bthis (?:comprehensive (?:guide|overview|analysis)|"
                                    r"in-depth (?:analysis|look|examination)|complete (?:guide|overview))\b|"
                                    r"\ba thorough examination of\b|\beverything you need to know about\b")),
        (25, 'question_answer_rhetorical', R(r"(?<![\w'’])(?:[Ii]s|[Aa]re|[Ww]as|[Ww]ere|[Dd]o|[Dd]oes|[Dd]id|"
                                             r"[Cc]an|[Cc]ould|[Ww]ill|[Ww]ould|[Ss]hould|[Hh]as|[Hh]ave|[Hh]ad|"
                                             r"[Mm]ay|[Mm]ight|[Mm]ust)\b[^?.!\n]{0,80}\?\s+(?:[Yy]es|[Nn]o|"
                                             r"[Aa]bsolutely|[Nn]ever|[Mm]aybe|[Pp]robably|[Aa]lways)[.!]", 0)),
        (26, 'concrete_evidence_defense', R(r"\bwithout concrete (?:evidence|proof)\b|"
                                            r"\bdo you have concrete (?:evidence|proof)\b|"
                                            r"\bI (?:would )?need concrete (?:evidence|examples) to\b|"
                                            r"\babsent concrete proof\b|\bprovide concrete (?:evidence|proof)\b")),
        (27, 'compulsive_intro_hook', R(r"\bin today(?:’|')?s (?:[\w-]+ ){0,2}?(?:world|landscape|environment|market)\b|"
                                        r"\bin a world where\b|\bin an era of\b|\bin recent years,|"
                                        r"\bmore than ever before\b|\bwe live in a (?:time|world) when\b|"
                                        r"\b(?:great|exciting|big) news\s*[!:]|"
                                        r"\bever (?:wanted|wondered|dreamed|wished)\b[^?\n]{0,80}\?|"
                                        r"\bin an increasingly (?:interconnected|digital|competitive|complex) world\b")),
        (30, 'diff_anchored', R(r"\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)\b|"
                                r"\bthe (?:latest |new )?(?:update|release|version|change|patch|design) "
                                r"(?:adds|introduces|brings|delivers|includes|provides|improves)\b|"
                                r"\bthis (?:latest |new )?(?:update|release|version|change|patch|design) "
                                r"(?:adds|introduces|brings|delivers|includes|provides|improves)\b|"
                                r"\b(?:has|have) been (?:updated|refactored|improved|enhanced|changed) to\b|"
                                r"\bpreviously\b[^.!?\n]{0,80}\bnow\b|\bwasn(?:’|')t there before\b|"
                                r"\bweren(?:’|')t there before\b|"
                                r"\bwe(?:’|')ve (?:now )?(?:added|removed|replaced|refactored|migrated)\b|"
                                r"\bwe have (?:now )?(?:added|removed|replaced|refactored|migrated)\b")),
        (31, 'signposting', R(r"\blet(?:’|')?s (?:dive|delve|explore)\b|\blet(?:’|')?s break (?:this|it) down\b|"
                              r"\bhere(?:’|')?s what you need to know\b|\bwithout further ado\b|"
                              r"\bnow let(?:’|')?s look at\b|\bbuckle up\b|\bstay with me\b|"
                              r"\bready to dive in\b")),
        (32, 'cataloguing_leadin', _combine(
            R(r"\b(?:used|uses|employs?|employed|relied on|utili[sz]es) (?:several|various|a number of|multiple|"
              r"different|many|numerous) \w+"),
            R(r"(?:^|[.!?]\s+|\n\s*)These(?: \w+)? (?:provide|offer|give|reveal|show|allow|enable|help) "
              r"(?:information|insight|understanding|details|data)\b", re.M | re.I),
            R(r"\b(?:is|are|was|were|remains|becomes) (?:the |a )?(?:language|currency|architecture|heartbeat|"
              r"lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective tissue) of\b"))),
        (33, 'inline_header_list', R(r"^[ \t]*(?:[-*+][ \t]+|\d+[.)][ \t]+)?\*\*[^*\n]+?(?::\*\*|\*\*:)", re.M)),
        (34, 'mid_essay_bullets', _fn_mid_bullets),
        (35, 'fragmented_header', _fn_fragmented_headers),
        (36, 'formulaic_challenges', R(r"\bdespite (?:these|its|the) (?:challenges|obstacles)\b|"
                                       r"\bchallenges and (?:future )?(?:prospects|outlook|legacy)\b|"
                                       r"\bcontinues to thrive\b|\btypical of (?:emerging|urban|modern)\b|"
                                       r"\bfaces (?:several|many|numerous) challenges\b")),
        (37, 'transition_cluster', _fn_transitions),
        (38, 'compulsive_conclusion', R(r"^[ \t]*(?:in conclusion|overall|in summary|to summari[sz]e|to conclude|"
                                        r"all in all|in essence|ultimately)\b", re.I | re.M)),
        (39, 'generic_positive_conclusion', R(r"\bthe future looks bright\b|\bexciting times lie ahead\b|"
                                              r"\bjourney toward excellence\b|\bstep in the right direction\b|"
                                              r"\bthe (?:outlook|future)(?: for [\w\s]+?)? (?:is|looks|remains) bright\b|"
                                              r"\bwell[- ]positioned for (?:whatever comes next|the future|the road ahead)\b")),
        (40, 'sentence_length_monotony', _fn_monotony),
        (41, 'mechanical_alternation', _fn_alternation),
        (42, 'opener_repetition', _fn_opener_repetition),
        (44, 'uniform_paragraph_length', _fn_uniform_paras),
        (46, 'semicolon_underuse', lambda c: (1, ['no semicolons, almost no parentheses'])
         if c.nwords >= 300 and ';' not in c.M and c.M.count('(') <= 1 else (0, [])),
        (47, 'chatbot_artifact', R(r"\bI hope this helps\b|\bCertainly!|\bOf course!|\blet me know if you\b|"
                                   r"\bwould you like me to\b|\bfeel free to (?:ask|reach out)\b|"
                                   r"\bhappy to help[.!]|\b(?:here|below) is (?:a |an |the )?"
                                   r"(?:overview|summary|rundown|recap|brief)\b|"
                                   r"\bhere(?:’|')?(?:s| are) (?:a few|some|two|three)? ?"
                                   r"(?:options|drafts|versions|variations)\b|"
                                   r"\bhere(?:’|')?s a draft\b|\bhere is (?:a |the )?draft\b|"
                                   r"\bdepending on the (?:vibe|tone|style)\b|"
                                   r"\bI hope (?:this (?:email |message )?)?finds you well\b|"
                                   r"\bas an? (?:AI|LLM|AI assistant|AI language model|large language model|"
                                   r"language model)\b|\bto (?:answer|address) your question\b|"
                                   r"\bin (?:response|answer) to your question\b|"
                                   r"\byour question (?:about|regarding|concerning)\b|"
                                   r"\bas (?:you )?(?:requested|asked),? here\b|"
                                   r"\bhere is (?:the )?(?:draft|first pass|revised version (?:of|for your))\b")),
        (48, 'sycophantic_tone', R(r"\byou(?:’|')?re absolutely right\b|\byou are absolutely right\b|"
                                   r"\bgreat question[!.,]|\bexcellent point[!.,]|"
                                   r"\bwhat a (?:thoughtful|great|wonderful|fantastic) question[!.,]|"
                                   r"\bthat(?:’|')?s a (?:great|wonderful|fantastic|brilliant|excellent) "
                                   r"(?:point|question)[!.,]")),
        (50, 'knowledge_cutoff_disclaimer', R(r"\bas of my (?:last )?(?:training|knowledge)\b|"
                                              r"\bup to my (?:last )?(?:training|knowledge)\b|"
                                              r"\bwhile (?:specific )?details are (?:limited|scarce|"
                                              r"not (?:extensively |widely )?documented)\b|"
                                              r"\bbased on (?:the )?available information\b|"
                                              r"\bas of my (?:knowledge )?cutoff\b|"
                                              r"\bmaintains a low profile\b|"
                                              r"\bkeeps (?:his|her|their) personal life private\b")),
        (51, 'copula_avoidance', R(r"\b(?:serves|stands|functions|acts) as\b|\brepresents (?:a|the)\b|"
                                   r"\bmarks (?:a|the)\b|\bboasts\b|"
                                   r"\bfeatures (?:a|an|the|\d+|several|many|numerous|various|multiple|some)\b|"
                                   r"\boffers an?\b|\brefers to\b")),
        (54, 'hedge_stacking', _fn_hedges),
        (55, 'contraction_absence', _fn_contractions),
        (56, 'boldface_overuse', _fn_bold),
        (57, 'emoji', R(r"[\U0001F000-\U0001FAFF\u2600-\u27BF\u2B50\u2B55]", 0)),
        (58, 'em_dash_overuse', _fn_em_dash),
        (59, 'title_case_heading', _fn_headings_titlecase),
        (60, 'curly_quotes', _fn_curly),
        (61, 'hyphen_for_en_dash', _fn_year_ranges),
        (62, 'invisible_character', _fn_char('inv')),
        (63, 'placeholder_text', _PLACEHOLDER),
        (64, 'chat_reference_markup', R(r"\bcite(?:turn|start|nav)\w*|\boai_citation\w*|\bcontentReference\b|"
                                        r"\bnavlist\b|【\d+†[^】\n]*】")),
        (65, 'ai_tracking_parameter', _fn_utm),
        (66, 'mixed_script_homoglyph', _fn_char('homo')),
        (67, 'non_standard_space', _fn_char('nonstd')),
        (68, 'trailing_whitespace', _fn_char('trail')),
        (69, 'canonical_marketing_phrase', R(r"\bunlocking (?:the )?(?:full )?potential\b|"
                                             r"\bnavigat(?:e|ing) the complexities\b|"
                                             r"\ba testament to the (?:power|importance) of\b|"
                                             r"\bstaying ahead of the curve\b|"
                                             r"\bturning challenges into opportunities\b|"
                                             r"\btaking \w+ to the next level\b|"
                                             r"\bharnessing the power of\b|\bpaving the way for\b|"
                                             r"\bsaying goodbye to\b|\bimagining a world where\b|"
                                             r"\bthe sky is the limit\b|\bthe world is your oyster\b")),
        (70, 'decorative_rule', _fn_hr),
        (71, 'degenerate_repetition', _fn_repetition),
    ]


# ------------------------------------------------------- analysis and scoring

class _Ctx(object):
    pass


def _clip(s, n=120):
    s = re.sub(r'\s+', ' ', s).strip()
    return s if len(s) <= n else s[:n - 3] + '...'


def analyze(text):
    """Score extracted prose. Returns a dict with findings, score, and metrics."""
    W = text[:WINDOW]
    truncated = len(text) > WINDOW
    cl = char_layer(W)
    N = cl['text']
    c = _Ctx()
    c.N = N
    c.char = cl
    c.trail, c.trail_s = trailing_hits(N)
    c.M = mask_markdown(N)
    c.sents = _sent_spans(c.M)
    c.sent_counts = [len(words_of(c.M[s:e])) for s, e in c.sents]
    c.paras = _para_spans(c.M)
    c.words = words_of(c.M)
    c.nwords = len(c.words)

    found = {}
    for num, slug, fn in ((r[0], r[1], r[2]) for r in _rules()):
        count, samples = fn(c)
        if count <= 0:
            continue
        key = (num, slug)
        f = found.setdefault(key, {'num': num, 'slug': slug, 'label': LABELS[num], 'count': 0, 'samples': []})
        f['count'] += count
        for s in samples:
            if len(f['samples']) < 3 and s:
                f['samples'].append(_clip(s))
    # the two-hit requirement for the model-dialect family
    for key in list(found):
        if key[0] == 2 and found[key]['count'] < 2:
            del found[key]

    fams = {}
    for (num, slug), f in found.items():
        if num in ADVICE:
            continue
        fams[num] = fams.get(num, 0) + f['count']
    F = set(fams)
    raw = 0.0
    for num, h in fams.items():
        raw += min(20.0, 10.0 + 2.5 * (min(h, 5) - 1))
    raw = int(round(raw))
    if len(F) == 1:
        raw = min(raw, 40)
    if F and F <= {40, 44}:
        raw = min(raw, 40)
    if F == {40}:
        raw = min(raw, 20)
    D = F & DECISIVE
    floor = 0
    if len(D) >= 2:
        floor = 65
    elif len(D) == 1:
        floor = 45
    if c.nwords < 120:
        k = len(F & SHORT_SET)
        if k >= 3:
            floor = max(floor, 45)
        elif k >= 2:
            floor = max(floor, 25)
    if c.nwords >= 400:
        if len(F) >= 6:
            floor = max(floor, 45)
        elif len(F) >= 5:
            floor = max(floor, 25)
    score = max(0, min(100, max(raw, floor)))

    nf = len(F)
    if c.nwords < 40:
        conf, reason = 'none', 'fewer than 40 words, so the score is not meaningful'
    elif c.nwords < 120:
        conf, reason = 'low', 'fewer than 120 words'
    elif c.nwords < 300 and nf == 1:
        conf, reason = 'low', 'under 300 words with only one score-moving pattern family'
    elif c.nwords < 300:
        conf, reason = 'moderate', 'under 300 words'
    else:
        conf, reason = 'high', ''

    return {
        'findings': found, 'score': score, 'band': band_of(score), 'confidence': conf,
        'confidence_reason': reason, 'nwords': c.nwords, 'sentences': c.sents, 'N': N,
        'W_len': len(W), 'truncated': truncated, 'char': cl, 'nfam': nf,
    }


def band_of(score):
    if score <= 20:
        return 'clean'
    if score <= 40:
        return 'light tells'
    if score <= 60:
        return 'mixed'
    if score <= 80:
        return 'heavy tells'
    return 'pervasive tells'


def interval(a, seed=20240601):
    """Deterministic low/high interval from sentence resampling."""
    sents = [a['N'][s:e] for s, e in a['sentences']]
    if len(sents) < 4:
        return None, 'too few sentences (fewer than four) for an interval'
    rng = random.Random(seed)
    runs = 24 if len(a['N']) < 60000 else 6
    scores = []
    for _ in range(runs):
        keep = [s for s in sents if rng.random() < 0.75]
        if len(keep) < 3:
            keep = sents[:3]
        scores.append(analyze('\n'.join(keep))['score'])
    scores.sort()
    lo = scores[int(0.1 * (len(scores) - 1))]
    hi = scores[int(round(0.9 * (len(scores) - 1)))]
    return [min(lo, hi), max(lo, hi)], 'resampled sentence subsets (%d runs, fixed seed)' % runs


def build_report(text, want_ci=False):
    a = analyze(text)
    report = {}
    items = sorted(a['findings'].values(), key=lambda f: (f['num'], f['slug']))
    for f in items:
        report['%d_%s' % (f['num'], f['slug'])] = {
            'label': f['label'], 'count': int(f['count']), 'samples': f['samples'][:3]}
    cl = a['char']
    metrics = {
        'scanned_chars': a['W_len'],
        'truncated': a['truncated'],
        'ai_tell_score': a['score'],
        'ai_tell_band': a['band'],
        'confidence': a['confidence'],
        'confidence_reason': a['confidence_reason'],
        'patterns_flagged': len(items),
        'invisible_chars': cl['inv'],
        'nonstandard_spaces': cl['nonstd'],
        'homoglyphs': cl['homo'],
        'words': a['nwords'],
        'sentences': len(a['sentences']),
    }
    if want_ci:
        ci, note = interval(a)
        metrics['score_ci'] = ci
        metrics['score_ci_note'] = note
    report['_metrics'] = metrics
    return report


def clean_text(text):
    """Scrubbed text for the cleanup switch (full extracted prose, not just the window)."""
    cl = char_layer(text)
    lines = cl['text'].split('\n')
    out = []
    for ln in lines:
        body = ln.rstrip(' \t')
        tail = ln[len(body):]
        if body.strip() and tail.startswith('  ') and '\t' not in tail:
            out.append(body + '  ')
        else:
            out.append(body)
    while out and not out[0].strip():
        out.pop(0)
    joined = '\n'.join(out)
    ended_lf = text.endswith('\n')
    joined = joined.rstrip()
    if ended_lf and joined:
        joined += '\n'
    return joined


USAGE_BYTES = USAGE


def main(argv):
    clean = False
    ci = False
    operands = []
    end = False
    for a in argv:
        if end:
            operands.append(a)
            continue
        if a == '--':
            end = True
        elif a in ('-h', '--help'):
            _write_bytes(sys.stdout, USAGE.encode('utf-8'))
            return 0
        elif a == '--clean':
            clean = True
        elif a == '--ci':
            ci = True
        elif a.startswith('-'):
            _err_line("unknown option '%s': see --help for usage" % a)
            return 2
        else:
            operands.append(a)
    path = None
    if len(operands) >= 2:
        last = operands[-1]
        ignored = operands[:-1]
        _write_bytes(sys.stderr, ("detect.py: note: %d files given; only the last one is scanned: %s "
                                  "(not scanned: %s)\n" % (len(operands), last, ', '.join(ignored)))
                     .encode('utf-8', 'replace'))
        path = last
    elif operands:
        path = operands[0]
    try:
        text = load_text(path)
        if not text.strip():
            raise Fatal(1, 'empty input')
        if clean:
            out = clean_text(text)
            _write_bytes(sys.stdout, out.encode('utf-8', 'replace'))
            return 0
        report = build_report(text, want_ci=ci)
    except Fatal as exc:
        _err_line(exc.message)
        return exc.code
    _write_bytes(sys.stdout, (json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode('utf-8', 'replace'))
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv[1:]))
    except BrokenPipeError:
        sys.exit(0)
