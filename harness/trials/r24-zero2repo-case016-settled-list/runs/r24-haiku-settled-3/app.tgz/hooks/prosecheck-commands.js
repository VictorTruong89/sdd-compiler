'use strict';
// Operator commands: check, doctor, show, init.
const fs = require('fs');
const path = require('path');
const C = require('./prosecheck-common.js');
const K = require('./prosecheck-contract.js');

const WINDOW_TEXT = '262,144';

function stripPath(arg) {
  let s = String(arg || '').trim();
  if (s.startsWith('@')) s = s.slice(1);
  if (s.length >= 2 && (s[0] === '"' || s[0] === "'") && s[s.length - 1] === s[0]) s = s.slice(1, -1);
  return s;
}

function checkReply(arg, payload) {
  const typed = stripPath(arg);
  if (!typed) {
    return 'prosecheck check needs a file path: /prosecheck check <path>. Nothing was scored.';
  }
  const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd();
  const abs = path.resolve(cwd, typed);
  const base = path.basename(abs);
  const ext = path.extname(abs).toLowerCase();
  let st;
  try {
    st = fs.statSync(abs);
  } catch (e) {
    return 'cannot read ' + typed + ': no such file.';
  }
  if (st.isDirectory() || !st.isFile()) return typed + ' is not a file.';
  if (C.BINARY_EXTS.has(ext)) {
    return base + ': no readable text (' + ext + ' is not scored).';
  }
  const archive = C.ARCHIVE_EXTS.has(ext);
  const capKb = archive ? C.ARCHIVE_CAP_KB : C.PLAIN_CAP_KB;
  if (st.size > capKb * 1024) {
    return base + ' is over ' + capKb + ' KB and was not scored.';
  }
  const res = C.runDetector([abs], archive ? 15000 : 8000);
  switch (res.kind) {
    case 'python-missing':
      return 'detector unavailable: Python was not found, so ' + base + ' was not scored.';
    case 'timeout':
      return base + ' failed: the detector timed out.';
    case 'failed':
      return base + ' failed: ' + (res.detail || 'the detector exited with an error') + '.';
    case 'no-output':
      return base + ': no report (the detector printed nothing).';
    case 'ok':
      break;
    default:
      return 'no report from the detector for this file.';
  }
  const r = res.report;
  const m = r._metrics;
  const lines = [];
  lines.push(base + ' - ' + C.hookPhrase(m.ai_tell_band) + ' (score ' + m.ai_tell_score + '/100, band: ' + m.ai_tell_band + ')');
  let conf = 'confidence: ' + m.confidence;
  if (m.confidence !== 'high' && m.confidence_reason) conf += ' - ' + m.confidence_reason;
  lines.push(conf);
  if (m.truncated) lines.push('coverage: first ' + WINDOW_TEXT + ' characters only');
  const tells = [];
  for (const [k, v] of Object.entries(r)) {
    if (k === '_metrics' || !v || typeof v !== 'object') continue;
    tells.push(v.label + ' (x' + v.count + ')');
  }
  lines.push(tells.length ? 'tells: ' + tells.slice(0, 8).join('; ') : 'tells: none');
  lines.push('This is a report only: the file was not changed.');
  return lines.join('\n');
}

function doctorReply(form) {
  const level = C.currentLevel();
  const rows = [];
  const faults = [];
  // mode
  if (level !== 'off') {
    rows.push('mode: ' + level + ' [OK]');
  } else {
    rows.push('mode: off - this is not a fault of the install; saved files are not scored while off. Run /prosecheck on to turn it back on.');
  }
  // detector
  const det = C.detectorPath();
  if (fs.existsSync(det)) {
    rows.push('detector: bundled detector found at ' + det + ' [OK]');
  } else {
    rows.push('detector: bundled detector missing (expected scripts/detect.py under the plugin root)');
    faults.push('detector');
  }
  // python
  const probe = 'This is a short probe sentence. It checks that the bundled detector runs.';
  const res = C.runDetector([], 8000, probe);
  if (res.kind === 'ok') {
    rows.push('python: Python ran the bundled detector and produced a numeric score [OK]');
  } else if (res.kind === 'python-missing') {
    rows.push('python: python not found; saved files are not re-scored until Python is available, but new prose is still shaped by the writing contract.');
    faults.push('python');
  } else {
    rows.push('python: Python ran the bundled detector but the result is not a numeric score');
    faults.push('python');
  }
  // settings
  let writable = true;
  const dir = C.configDir();
  try {
    fs.mkdirSync(dir, { recursive: true });
    const probeFile = path.join(dir, '.prosecheck-write-test-' + process.pid);
    fs.writeFileSync(probeFile, 'ok');
    fs.unlinkSync(probeFile);
  } catch (e) {
    writable = false;
  }
  if (writable) {
    rows.push('settings: settings folder ' + dir + ' is writable [OK]');
  } else {
    rows.push('settings: settings folder ' + dir + ' is not writable');
    faults.push('settings');
  }
  let closer;
  if (faults.length) {
    closer = 'Please fix the faulty checks above, then run /prosecheck doctor again.';
  } else if (level === 'off') {
    closer = 'Healthy install. Saved files are not scored in this mode. Run ' + form + ' on to turn it back on.';
  } else {
    closer = 'Active. Plain text is capped at 512 KB and archives at 4 MB, and the first ' + WINDOW_TEXT +
      ' characters are scanned. Use ' + form + ' show to see files that were only partly scanned or skipped.';
  }
  return ['prosecheck doctor', ...rows, closer].join('\n');
}

function showReply(sid) {
  const records = C.readLedger(sid);
  if (!records.length) {
    return 'prosecheck show: nothing scored yet in this session. Rows appear after prose files, including .docx and .pdf deliverables, are saved.';
  }
  const lines = ['prosecheck show - this session, newest first:'];
  for (const r of records.slice().reverse()) {
    const base = String(r.base || '?');
    if (r.kind === 'scored') {
      let body = r.phrase + ' (score ' + r.score + '/' + r.band + (r.truncated ? ', first ' + WINDOW_TEXT + ' characters only' : '') + ')';
      const labels = Array.isArray(r.labels) ? r.labels.slice(0, 5) : [];
      if (labels.length) body += ' - ' + (r.flagged ? 'flagged' : 'under threshold') + ': ' + labels.join('; ');
      lines.push('  ' + base + ' - ' + body);
    } else if (r.kind === 'skip') {
      lines.push('  ' + base + ' - not scored: over the ' + r.limitKb + ' KB limit');
    } else if (r.kind === 'binary') {
      lines.push('  ' + base + ' - not re-scored (binary format)');
    } else {
      const reason = String(r.reason || 'failed').replace(/\d+/g, '');
      lines.push('  ' + base + ' - not scored: ' + reason);
    }
  }
  return lines.join('\n');
}

function initReply(form, payload) {
  const level = C.currentLevel();
  if (level === 'off') {
    return 'prosecheck is switched off, so no files were written. Run ' + form + ' on to allow the export.';
  }
  const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd();
  const out = [];
  const agents = path.join(cwd, 'AGENTS.md');
  const section = K.exportSection(level);
  let existing = null;
  let readable = true;
  try {
    existing = fs.readFileSync(agents, 'utf8');
  } catch (e) {
    if (e.code !== 'ENOENT') readable = false;
  }
  if (!readable) {
    out.push('cannot read AGENTS.md, so the writing contract was not written there.');
  } else if (existing !== null && existing.includes(K.MARKER)) {
    out.push('AGENTS.md already contains the writing contract; left unchanged.');
  } else {
    let next;
    if (existing === null || existing === '') next = section;
    else next = (existing.endsWith('\n') ? existing : existing + '\n') + '\n' + section;
    try {
      fs.writeFileSync(agents, next, 'utf8');
      out.push('AGENTS.md: writing contract added.');
    } catch (e) {
      out.push('cannot write AGENTS.md; the writing contract was not added.');
    }
  }
  // Cursor rule
  const dest = path.join(cwd, '.cursor', 'rules', 'prosecheck.mdc');
  const src = path.join(C.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(dest)) {
    out.push('.cursor/rules/prosecheck.mdc already exists; left unchanged.');
  } else {
    try {
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.copyFileSync(src, dest);
      out.push('.cursor/rules/prosecheck.mdc: Cursor rule copied.');
    } catch (e) {
      out.push('cannot write .cursor/rules/prosecheck.mdc.');
    }
  }
  return out.join('\n');
}

module.exports = { checkReply, doctorReply, showReply, initReply };
