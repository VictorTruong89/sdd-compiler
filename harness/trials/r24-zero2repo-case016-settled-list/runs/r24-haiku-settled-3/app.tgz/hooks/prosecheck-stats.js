'use strict';
// stats: token totals from a session transcript, plus a score of the session's own prose.
const fs = require('fs');
const path = require('path');
const C = require('./prosecheck-common.js');

function newestTranscript(root) {
  let best = null;
  const walk = (dir, depth) => {
    if (depth > 6) return;
    let entries = [];
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return; }
    for (const ent of entries) {
      const p = path.join(dir, ent.name);
      if (ent.isDirectory()) walk(p, depth + 1);
      else if (ent.isFile() && ent.name.endsWith('.jsonl')) {
        try {
          const m = fs.statSync(p).mtimeMs;
          if (!best || m > best.m) best = { p, m };
        } catch (e) { /* ignore */ }
      }
    }
  };
  walk(root, 0);
  return best;
}

function chooseTranscript(named) {
  const projects = path.join(C.configDir(), 'projects');
  if (named) {
    let namedM = null;
    try {
      if (!fs.statSync(named).isFile()) return null;
      fs.accessSync(named, fs.constants.R_OK);
      namedM = fs.statSync(named).mtimeMs;
    } catch (e) {
      return null;
    }
    const newest = newestTranscript(projects);
    if (newest && newest.m > namedM) return newest.p;
    return named;
  }
  const newest = newestTranscript(projects);
  return newest ? newest.p : null;
}

function stripFences(text) {
  return text.replace(/```[\s\S]*?(?:```|$)/g, '');
}

function statsReply(payload) {
  const level = C.currentLevel();
  const named = typeof payload.transcript_path === 'string' && payload.transcript_path.trim()
    ? path.resolve(payload.transcript_path.trim()) : null;
  const file = chooseTranscript(named);
  if (!file) {
    if (named) {
      return 'prosecheck stats: no readable transcript at that path. level: ' + level + '.';
    }
    return 'prosecheck stats: no readable transcript found for this session. level: ' + level + '.';
  }
  let raw;
  try { raw = fs.readFileSync(file, 'utf8'); } catch (e) {
    return 'prosecheck stats: no readable transcript at that path. level: ' + level + '.';
  }
  const messages = new Map();
  let anon = 0;
  for (const line of raw.split('\n')) {
    if (!line.trim()) continue;
    let row;
    try { row = JSON.parse(line); } catch (e) { continue; }
    if (!row || row.type !== 'assistant' || !row.message || typeof row.message !== 'object') continue;
    const msg = row.message;
    const id = typeof msg.id === 'string' ? msg.id : ('anon-' + (anon++));
    if (!messages.has(id)) messages.set(id, { usage: null, texts: [] });
    const rec = messages.get(id);
    if (msg.usage && typeof msg.usage === 'object') rec.usage = msg.usage;
    if (Array.isArray(msg.content)) {
      for (const part of msg.content) {
        if (part && part.type === 'text' && typeof part.text === 'string') {
          if (!rec.texts.includes(part.text)) rec.texts.push(part.text);
        }
      }
    }
  }
  let turns = 0;
  let outTok = 0;
  let cacheTok = 0;
  const texts = [];
  for (const rec of messages.values()) {
    turns += 1;
    if (rec.usage) {
      outTok += Number(rec.usage.output_tokens) || 0;
      cacheTok += Number(rec.usage.cache_read_input_tokens) || 0;
    }
    texts.push(...rec.texts);
  }
  const lines = [
    'prosecheck stats',
    '  assistant turns: ' + turns,
    '  output tokens: ' + outTok,
    '  cache-read input tokens: ' + cacheTok,
    '  level: ' + level,
  ];
  let slice = stripFences(texts.join('\n'));
  if (slice.length > 40000) slice = slice.slice(slice.length - 40000);
  slice = slice.trim();
  if (slice.length > 200) {
    const res = C.runDetector([], 8000, slice);
    if (res.kind === 'ok') {
      lines.push('  session prose ai_tell_score: ' + res.report._metrics.ai_tell_score);
    }
  }
  return lines.join('\n');
}

module.exports = { statsReply };
