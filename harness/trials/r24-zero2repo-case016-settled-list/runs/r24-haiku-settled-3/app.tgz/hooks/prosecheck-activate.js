#!/usr/bin/env node
'use strict';
// Session-start hook: prints the welcome (first run only) and the writing contract.
const C = require('./prosecheck-common.js');
const K = require('./prosecheck-contract.js');

try {
  C.readStdinJson();
  const firstRun = C.storedLevel() === null && !require('fs').existsSync(C.flagPath());
  const level = C.currentLevel();
  C.pruneLedgers();
  // Store the effective level so later hooks on this install see it.
  if (C.storedLevel() === null && level !== 'off') C.writeLevel(level);
  if (level !== 'off') {
    const parts = [];
    if (firstRun) parts.push(K.welcome());
    parts.push(K.liveContract(level, C.detectorPath()));
    C.emit(parts.join('\n\n') + '\n');
  }
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
