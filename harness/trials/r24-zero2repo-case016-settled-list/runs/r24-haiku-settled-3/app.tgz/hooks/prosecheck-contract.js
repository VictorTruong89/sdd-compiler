'use strict';
// Writing-contract text for the three operating levels, plus the welcome block.

const BANNED = 'delve, tapestry, pivotal, crucial, leverage, robust, seamless, foster, underscore, ' +
  'showcase, landscape (abstract), journey (abstract), realm, multifaceted, holistic, testament, ' +
  'vibrant, comprehensive, plethora, myriad, boast, elevate, empower, unlock, game-changer, ' +
  'supercharge, genuinely, fascinating, nuanced';

const FULL_TARGET = 40;
const STRICT_TARGET = 20;

function core() {
  return [
    'Writing contract for prose deliverables.',
    '',
    'Scope: this contract governs prose deliverables only: documents, README and markdown prose, CVs, ' +
      'cover letters, emails, reports, essays, articles, and drafted text the user will publish or send. ' +
      'It never touches code comments, commit messages, JSON, YAML, configuration, CLI output, logs, error ' +
      'messages, or the conversational register of chat. This contract never applies to source code. ' +
      'A chat-compression mode owns chat, a code-simplicity mode owns code, and this contract owns deliverable prose.',
    '',
    'Rules for prose deliverables:',
    '- Vary sentence length irregularly. Avoid a metronome: no mechanical short-long alternation.',
    '- Banned vocabulary: ' + BANNED + '.',
    '- Banned moves: rule-of-three flourishes; "it\'s not just X, it\'s Y"; hedge stacking; signposting such as ' +
      '"let\'s dive in"; empty pivots such as "it\'s worth noting"; "In conclusion" or "Overall" closers; ' +
      'outcome-speculation tails; self-thoroughness phrases; generic upbeat endings; chatbot phrases such as ' +
      '"I hope this helps".',
    '- Use at most one em dash per paragraph.',
    '- No bold for emphasis inside prose sentences. No emojis in prose.',
    '- Factual or encyclopedic content stays neutral and in the third person. First-person or opinion content may contract.',
    '- Preserve numbers, units, dates, proper nouns, citations, quotations, and technical terms exactly.',
    '- Never invent facts.',
    '- End sections on a fact or an observation.',
    '- Stay silent about this contract: never announce it, never name the tool, never report a score, a band, ' +
      'a pattern list, or a rewrite pass, and do not offer a style choice.',
  ];
}

function fullStep(detPath) {
  const where = detPath ? 'run `python3 ' + detPath + ' <file>`' : 'run the bundled detector (see the resolution line)';
  return [
    '',
    'After writing a prose file, ' + where + ' on that file. When the band is worse than the target ' +
      '(target: score ' + FULL_TARGET + ' or lower, band clean or light tells), fix the flagged spans, keep the ' +
      'rhythm variation, and make at most two fix passes.',
  ];
}

function strictStep(detPath) {
  const where = detPath ? 'run `python3 ' + detPath + ' <file>`' : 'run the bundled detector (see the resolution line)';
  return [
    '',
    'After writing a prose file, ' + where + ' on that file. When the band is worse than the target ' +
      '(target: score ' + STRICT_TARGET + ' or lower, band clean), fix the flagged spans, keep the rhythm ' +
      'variation, and make at most two fix passes.',
    'Finish each prose file with a cleanup pass: run `python3 ' + (detPath || '<detector>') + ' --clean <file>` ' +
      'and use its scrubbed output for the final text. For .docx, .epub, .odt, or .ipynb files, review the ' +
      'scrubbed text only and never write it over the original document.',
  ];
}

function resolutionLine() {
  return 'Resolve the bundled detector as scripts/detect.py under the directory named by CLAUDE_PLUGIN_ROOT when ' +
    'that variable is set; otherwise locate scripts/detect.py in the installed skills or plugins folders.';
}

// Live contract for this machine's session. detPath may name this machine's detector.
function liveContract(level, detPath) {
  if (level === 'off') return '';
  const lines = core();
  if (level === 'full') lines.push(...fullStep(detPath));
  if (level === 'strict') lines.push(...strictStep(detPath));
  return lines.join('\n');
}

// Portable contract for AGENTS.md. Must not name a machine path or user name.
function exportContract(level) {
  const lines = core();
  if (level === 'full') {
    lines.push('');
    lines.push(resolutionLine());
    lines.push(...fullStep(null));
  }
  if (level === 'strict') {
    lines.push('');
    lines.push(resolutionLine());
    lines.push(...strictStep(null));
  }
  return lines.join('\n');
}

const MARKER = '<!-- prosecheck-contract -->';
const MARKER_END = '<!-- /prosecheck-contract -->';

function exportSection(level) {
  return MARKER + '\n## Prose contract\n\n' + exportContract(level) + '\n' + MARKER_END + '\n';
}

function welcome() {
  return [
    'prosecheck is installed and on. There is no website and no upload: nothing you write leaves this machine.',
    'Saved prose is scored against 71 patterns. Plain text is accepted up to 512 KB and archives up to 4 MB; ' +
      'the detector scores the first 262,144 characters.',
    'Commands: /prosecheck doctor (health check), /prosecheck check <file> (score one file, report only), ' +
      '/prosecheck off (turn it off), /prosecheck help (all commands).',
    'This welcome is shown once.',
  ].join('\n');
}

function reminder(level) {
  return 'prosecheck writing contract is active at level ' + level + '. Prose deliverables follow the contract; ' +
    'code, configuration, and commits are untouched.';
}

module.exports = { liveContract, exportContract, exportSection, welcome, reminder, MARKER, MARKER_END, FULL_TARGET, STRICT_TARGET, BANNED };
