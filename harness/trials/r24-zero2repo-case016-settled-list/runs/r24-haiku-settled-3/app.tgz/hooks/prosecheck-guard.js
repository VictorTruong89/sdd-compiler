#!/usr/bin/env node
'use strict';
// Post-tool-use hook: scores a just-saved prose file and nudges when it is flagged.
const fs = require('fs');
const path = require('path');
const C = require('./prosecheck-common.js');

const EDIT_TOOLS = new Set(['Write', 'Edit', 'MultiEdit', 'NotebookEdit', 'apply_patch']);
const MAX_PATCH_PATHS = 16;

function patchPaths(body) {
  const out = [];
  const seen = new Set();
  const re = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/gm;
  let m;
  while ((m = re.exec(body)) !== null) {
    const p = m[1].trim();
    if (p && !seen.has(p)) { seen.add(p); out.push(p); }
    if (out.length >= MAX_PATCH_PATHS) break;
  }
  return out;
}

function stripPathQuotes(p) {
  return p.trim();
}

function pathsFor(payload) {
  const ti = payload.tool_input && typeof payload.tool_input === 'object' ? payload.tool_input : {};
  const tool = payload.tool_name;
  if (tool === 'apply_patch') {
    const body = typeof ti.command === 'string' ? ti.command : (typeof ti.input === 'string' ? ti.input : '');
    return patchPaths(body);
  }
  const p = ti.file_path || ti.notebook_path;
  return typeof p === 'string' && p.trim() ? [stripPathQuotes(p)] : [];
}

function skipReason(abs, base, ext) {
  const parts = abs.split(path.sep);
  if (parts.includes('node_modules') || parts.includes('.git')) return 'skipped';
  const root = path.resolve(C.pluginRoot());
  if (abs === root || abs.startsWith(root + path.sep)) return 'skipped';
  const lower = base.toLowerCase();
  if (C.INSTRUCTION_NAMES.has(lower)) return 'skipped';
  const stem = lower.endsWith(ext) ? lower.slice(0, lower.length - ext.length) : lower;
  if (C.INSTRUCTION_STEMS.has(stem) && !C.PROSE_EXTS.has(ext)) return 'skipped';
  return null;
}

function labelsOf(report) {
  const labels = [];
  for (const [k, v] of Object.entries(report)) {
    if (k === '_metrics' || !v || typeof v !== 'object') continue;
    labels.push(v.label);
  }
  return labels;
}

function scoreOne(sid, abs, base, ext, cwdBased) {
  void cwdBased;
  const archive = C.ARCHIVE_EXTS.has(ext);
  const capKb = archive ? C.ARCHIVE_CAP_KB : C.PLAIN_CAP_KB;
  let size;
  try {
    const st = fs.statSync(abs);
    if (!st.isFile()) return null;
    size = st.size;
  } catch (e) {
    C.appendLedger(sid, { base, kind: 'failed', reason: 'file cannot be read', time: Date.now() });
    return null;
  }
  if (size > capKb * 1024) {
    C.appendLedger(sid, { base, kind: 'skip', limitKb: capKb, time: Date.now() });
    return null;
  }
  const res = C.runDetector([abs], archive ? 15000 : 8000);
  if (res.kind !== 'ok') {
    const reasons = {
      'python-missing': 'python not found',
      timeout: 'detector timed out',
      'no-output': 'detector produced no output',
      'not-report': 'detector output is not a report',
      'no-score': 'report has no numeric score',
      failed: 'detector failed' + (res.detail ? ': ' + res.detail : ''),
    };
    C.appendLedger(sid, { base, kind: 'failed', reason: reasons[res.kind] || 'detector failed', time: Date.now() });
    return null;
  }
  const m = res.report._metrics;
  const score = m.ai_tell_score;
  const band = m.ai_tell_band;
  const level = C.currentLevel();
  const threshold = level === 'strict' ? 20 : 40;
  const flagged = score > threshold;
  const labels = labelsOf(res.report).slice(0, 5);
  const truncated = !!m.truncated;
  C.appendLedger(sid, {
    base, kind: 'scored', score, band, phrase: C.hookPhrase(band), labels,
    flagged, truncated, time: Date.now(),
  });
  if (!flagged) return null;
  const coverage = truncated ? ', first ' + C.WINDOW_TEXT + ' characters only' : '';
  return 'prosecheck: ' + base + ' ' + C.hookPhrase(band) + ' (score ' + score + ', band ' + band + coverage +
    '). Flagged: ' + (labels.join('; ') || 'pattern') + '. Please fix the flagged spans in this file, ' +
    'keeping the rhythm variation.';
}

function main() {
  const payload = C.readStdinJson();
  const level = C.currentLevel();
  if (level === 'off' || level === 'lite') return;
  const tool = payload.tool_name;
  if (tool !== undefined && !EDIT_TOOLS.has(tool)) return;
  const sid = payload.session_id;
  const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd();
  const lines = [];
  for (const raw of pathsFor(payload)) {
    const abs = path.resolve(cwd, raw);
    const ext = path.extname(abs).toLowerCase();
    const base = path.basename(abs);
    if (!C.PROSE_EXTS.has(ext) && !C.BINARY_EXTS.has(ext)) {
      // instruction-file stems with non-prose extensions are skipped; other extensions are not eligible
      continue;
    }
    if (skipReason(abs, base, ext)) continue;
    if (C.BINARY_EXTS.has(ext)) {
      C.appendLedger(sid, { base, kind: 'binary', time: Date.now() });
      continue;
    }
    try {
      if (!fs.statSync(abs).isFile()) continue;
    } catch (e) {
      C.appendLedger(sid, { base, kind: 'failed', reason: 'file cannot be read', time: Date.now() });
      continue;
    }
    const line = scoreOne(sid, abs, base, ext, true);
    if (line) lines.push(line);
  }
  if (lines.length) {
    C.emit({ hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') } });
  }
}

try {
  main();
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
