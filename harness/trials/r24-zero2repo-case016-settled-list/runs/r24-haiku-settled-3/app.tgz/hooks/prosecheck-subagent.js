#!/usr/bin/env node
'use strict';
// Subagent-start hook: returns the same writing contract inside the hook envelope.
const C = require('./prosecheck-common.js');
const K = require('./prosecheck-contract.js');

try {
  C.readStdinJson();
  const level = C.currentLevel();
  if (level !== 'off') {
    C.emit({
      hookSpecificOutput: {
        hookEventName: 'SubagentStart',
        additionalContext: K.liveContract(level, C.detectorPath()),
      },
    });
  }
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
