'use strict';
// Shared helpers for the prosecheck hooks: paths, mode flag, ledgers, detector runs.

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const LEVELS = ['lite', 'full', 'strict', 'off'];
const PLAIN_CAP_KB = 512;
const ARCHIVE_CAP_KB = 4096;
const WINDOW = 262144;
const WINDOW_TEXT = '262,144';
const PROSE_EXTS = new Set(['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc',
  '.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub', '.ipynb']);
const ARCHIVE_EXTS = new Set(['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub', '.ipynb']);
const BINARY_EXTS = new Set(['.pdf', '.rtf']);
const INSTRUCTION_NAMES = new Set(['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md']);
const INSTRUCTION_STEMS = new Set(['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory']);
const LEDGER_MAX = 50;
const LEDGER_AGE_MS = 7 * 24 * 60 * 60 * 1000;

const PHRASES = {
  'reads clean': 'clean', 'reads mostly clean': 'light tells', 'reads with some AI tells': 'mixed',
  'reads with heavy AI tells': 'heavy tells', 'reads with pervasive AI tells': 'pervasive tells',
};

function hookPhrase(band) {
  for (const [phrase, b] of Object.entries(PHRASES)) if (b === band) return phrase;
  return 'reads with some AI tells';
}

function pluginRoot() {
  if (process.env.CLAUDE_PLUGIN_ROOT) return path.resolve(process.env.CLAUDE_PLUGIN_ROOT);
  return path.resolve(__dirname, '..');
}

function detectorPath() {
  const root = pluginRoot();
  const primary = path.join(root, 'scripts', 'detect.py');
  if (fs.existsSync(primary)) return primary;
  return path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py');
}

function configDir() {
  if (process.env.CLAUDE_CONFIG_DIR) return path.resolve(process.env.CLAUDE_CONFIG_DIR);
  return path.join(os.homedir(), '.claude');
}

function flagPath() {
  return path.join(configDir(), '.prosecheck-active');
}

// Returns the stored valid level, or null when no valid level is stored.
function storedLevel() {
  try {
    const v = fs.readFileSync(flagPath(), 'utf8').trim().toLowerCase();
    return LEVELS.includes(v) ? v : null;
  } catch (e) {
    return null;
  }
}

function envLevel() {
  const v = (process.env.PROSECHECK_DEFAULT_MODE || '').trim().toLowerCase();
  return LEVELS.includes(v) ? v : null;
}

// Stored valid level wins; then the environment; then the default full.
function currentLevel() {
  return storedLevel() || envLevel() || 'full';
}

function writeLevel(level) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(flagPath(), level + '\n', 'utf8');
    return true;
  } catch (e) {
    return false;
  }
}

function readStdinJson() {
  let raw = '';
  try {
    raw = fs.readFileSync(0, 'utf8');
  } catch (e) {
    raw = '';
  }
  try {
    const v = JSON.parse(raw);
    return v && typeof v === 'object' && !Array.isArray(v) ? v : {};
  } catch (e) {
    return {};
  }
}

function safeSessionId(sid) {
  const s = String(sid || '').replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 120);
  return s || 'none';
}

function ledgerPath(sid) {
  return path.join(configDir(), '.prosecheck-ledger-' + safeSessionId(sid));
}

function readLedger(sid) {
  const p = ledgerPath(sid);
  try {
    const st = fs.statSync(p);
    if (Date.now() - st.mtimeMs > LEDGER_AGE_MS) return [];
    const arr = JSON.parse(fs.readFileSync(p, 'utf8'));
    return Array.isArray(arr) ? arr : [];
  } catch (e) {
    return [];
  }
}

function appendLedger(sid, record) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    let arr = [];
    try {
      arr = JSON.parse(fs.readFileSync(ledgerPath(sid), 'utf8'));
      if (!Array.isArray(arr)) arr = [];
    } catch (e) {
      arr = [];
    }
    arr.push(record);
    if (arr.length > LEDGER_MAX) arr = arr.slice(arr.length - LEDGER_MAX);
    fs.writeFileSync(ledgerPath(sid), JSON.stringify(arr), 'utf8');
  } catch (e) {
    // a ledger that cannot be written must not fail the host
  }
}

// Delete ledgers untouched for more than seven days.
function pruneLedgers() {
  try {
    for (const name of fs.readdirSync(configDir())) {
      if (name !== '.prosecheck-ledger' && !name.startsWith('.prosecheck-ledger-')) continue;
      const p = path.join(configDir(), name);
      try {
        if (Date.now() - fs.statSync(p).mtimeMs > LEDGER_AGE_MS) fs.unlinkSync(p);
      } catch (e) { /* ignore */ }
    }
  } catch (e) { /* no config dir yet */ }
}

function pythonCandidates() {
  return process.platform === 'win32' ? ['python3', 'python', 'py'] : ['python3', 'python', 'py'];
}

// Run the bundled detector on a file (or stdin text when input is given).
// Returns { kind, report?, detail? } where kind is one of:
// ok | python-missing | timeout | no-output | not-report | no-score | failed
function runDetector(args, timeoutMs, input) {
  const det = detectorPath();
  let sawMissing = false;
  for (const py of pythonCandidates()) {
    const extra = py === 'py' ? ['-3'] : [];
    const res = spawnSync(py, extra.concat([det], args), {
      input: input === undefined ? undefined : input,
      encoding: 'utf8',
      timeout: timeoutMs,
      maxBuffer: 64 * 1024 * 1024,
      windowsHide: true,
    });
    if (res.error) {
      if (res.error.code === 'ENOENT') { sawMissing = true; continue; }
      if (res.error.code === 'ETIMEDOUT') return { kind: 'timeout' };
      return { kind: 'failed', detail: String(res.error.message || 'could not start') };
    }
    if (res.signal === 'SIGTERM' && timeoutMs) return { kind: 'timeout' };
    const stdout = (res.stdout || '').trim();
    const stderrLines = (res.stderr || '').split('\n').map((s) => s.trim()).filter(Boolean);
    if (res.status !== 0) {
      let detail = '';
      if (stderrLines.length) {
        try { detail = JSON.parse(stderrLines[stderrLines.length - 1]).error || stderrLines[stderrLines.length - 1]; }
        catch (e) { detail = stderrLines[stderrLines.length - 1]; }
      }
      return { kind: 'failed', detail };
    }
    if (!stdout) return { kind: 'no-output' };
    let report;
    try { report = JSON.parse(stdout); } catch (e) { return { kind: 'not-report' }; }
    if (!report || typeof report !== 'object' || !report._metrics) return { kind: 'not-report' };
    if (typeof report._metrics.ai_tell_score !== 'number') return { kind: 'no-score' };
    return { kind: 'ok', report };
  }
  return { kind: 'python-missing', sawMissing };
}

function emit(obj) {
  process.stdout.write(typeof obj === 'string' ? obj : JSON.stringify(obj));
}

module.exports = {
  LEVELS, PLAIN_CAP_KB, ARCHIVE_CAP_KB, WINDOW, WINDOW_TEXT, PROSE_EXTS, ARCHIVE_EXTS, BINARY_EXTS,
  INSTRUCTION_NAMES, INSTRUCTION_STEMS, hookPhrase, pluginRoot, detectorPath, configDir, flagPath,
  storedLevel, envLevel, currentLevel, writeLevel, readStdinJson, ledgerPath, readLedger, appendLedger,
  pruneLedgers, runDetector, emit,
};
