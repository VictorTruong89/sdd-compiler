#!/usr/bin/env node
'use strict';
// Prompt-submit hook and /prosecheck command router.
const fs = require('fs');
const path = require('path');
const C = require('./prosecheck-common.js');
const K = require('./prosecheck-contract.js');
const { statsReply } = require('./prosecheck-stats.js');
const { checkReply, doctorReply, showReply, initReply } = require('./prosecheck-commands.js');

const SUBS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];

function helpReply(level) {
  const lines = [
    level === 'off' ? 'prosecheck is off (level off).' : 'prosecheck is on at level ' + level + '.',
    'Code, commits, config, and chat are always left alone: this tool never changes them.',
    'Commands (non-namespaced spelling):',
    '/prosecheck lite - writing contract only; saved files get no scoring.',
    '/prosecheck full - writing contract plus the saved-file guard, threshold 40 (default).',
    '/prosecheck strict - writing contract plus the saved-file guard, threshold 20, with the cleanup scrub.',
    '/prosecheck off - disable prosecheck; no contract and no scoring.',
    '/prosecheck on - re-enable prosecheck at full.',
    '/prosecheck status - show the stored level in one line.',
    '/prosecheck show - list the files scored or skipped in this session.',
    '/prosecheck check <file> - score one file (score, band, tells); report only, it does not rewrite the file.',
    '/prosecheck doctor - health check of the install.',
    '/prosecheck stats - session token use and the score of the session\'s own prose.',
    '/prosecheck init - export the writing contract to ./AGENTS.md for agents other than Claude Code.',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
  ];
  return lines.join('\n');
}

function block(reason) {
  C.emit({ decision: 'block', reason });
}

function parseCommand(prompt) {
  const m = /^\/prosecheck(?::prosecheck)?(?=\s|$)/i.exec(prompt);
  if (!m) return null;
  const form = m[0];
  const rest = prompt.slice(m[0].length).trim();
  const sp = rest.search(/\s/);
  const sub = (sp === -1 ? rest : rest.slice(0, sp)).toLowerCase();
  const arg = sp === -1 ? '' : rest.slice(sp).trim();
  return { form, sub, arg };
}

function setLevel(level, form) {
  if (!C.writeLevel(level)) {
    return 'prosecheck could not save the level in the settings folder, so nothing changed.';
  }
  if (level === 'off') return 'prosecheck is off. Run ' + form + ' on to turn it back on.';
  return 'prosecheck level set to ' + level + '.';
}

function route(payload) {
  const prompt = typeof payload.prompt === 'string' ? payload.prompt : '';
  const trimmed = prompt.trim();
  const sid = payload.session_id;
  const cmd = parseCommand(trimmed);

  if (!cmd) {
    if (/^(stop prosecheck|prosecheck off)$/i.test(trimmed)) {
      C.writeLevel('off');
      block('prosecheck is off. Run /prosecheck on to turn it back on.');
      return;
    }
    if (/stop prosecheck/i.test(prompt)) {
      // Anywhere in an ordinary prompt the tool is switched off; the prompt goes through.
      C.writeLevel('off');
      return;
    }
    const level = C.currentLevel();
    if (level === 'off') return;
    C.emit({ hookSpecificOutput: { hookEventName: 'UserPromptSubmit', additionalContext: K.reminder(level) } });
    return;
  }

  const { form, sub, arg } = cmd;
  const level = C.currentLevel();
  if (sub === '' || sub === 'help') return block(helpReply(level));
  if (['lite', 'full', 'strict', 'off'].includes(sub)) return block(setLevel(sub, form));
  if (sub === 'on') return block(setLevelOn(form));
  if (sub === 'status') return block('prosecheck status: level ' + level + '.');
  if (sub === 'show') return block(showReply(sid));
  if (sub === 'check') return block(checkReply(arg, payload));
  if (sub === 'doctor') return block(doctorReply(form));
  if (sub === 'stats') return block(statsReply(payload));
  if (sub === 'init') return block(initReply(form, payload));
  return block('prosecheck: unknown subcommand "' + sub + '". Valid subcommands: ' + SUBS.join(', ') + '.');
}

function setLevelOn(form) {
  if (!C.writeLevel('full')) return 'prosecheck could not save the level in the settings folder, so nothing changed.';
  return 'prosecheck is on (full). Use ' + form + ' off to switch it off again.';
}

try {
  route(C.readStdinJson());
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
