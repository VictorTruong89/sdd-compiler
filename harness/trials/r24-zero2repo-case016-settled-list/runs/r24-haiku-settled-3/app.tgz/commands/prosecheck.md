---
description: prosecheck operator command (levels, check, doctor, show, stats, init, help)
argument-hint: [subcommand] [argument]
---

/prosecheck $ARGUMENTS
