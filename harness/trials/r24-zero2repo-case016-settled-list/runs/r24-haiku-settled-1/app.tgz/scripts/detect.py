#!/usr/bin/env python3
"""prosecheck detector: a local, standard-library-only scanner for AI-writing patterns.

Usage:
    python3 scripts/detect.py [--clean] [--ci] [--] [FILE]
    python3 scripts/detect.py --help | -h

With no FILE, standard input is read. Output is one JSON report on standard
output (exit 0), or scrubbed text with --clean. Failures print one JSON error
object as the last line of standard error (exit 1 for input problems, 2 for an
unknown option). No traceback is printed on any failure path.
"""
from __future__ import annotations

import codecs
import io
import json
import math
import os
import posixpath
import re
import sys
import unicodedata
import zipfile
import xml.etree.ElementTree as ET
from collections import Counter
from html.parser import HTMLParser
from urllib.parse import unquote

WINDOW = 262144                      # scan window, in characters
TEXT_CAP_BYTES = 512 * 1024          # plain-text cap (enforced by the plugin)
ARCHIVE_CAP_BYTES = 4 * 1024 * 1024  # zip-based and notebook cap (enforced by the plugin)
MEMBER_LIMIT = 64 * 1024 * 1024      # largest archive member the extractor will read

PLAIN_EXTS = {".md", ".mdx", ".markdown", ".txt", ".text", ".rst", ".tex", ".org", ".adoc"}
ZIP_EXTS = {".docx", ".docm", ".pptx", ".pptm", ".xlsx", ".xlsm", ".odt", ".odp", ".ods", ".epub"}
NOTEBOOK_EXT = ".ipynb"
BINARY_EXTS = {".pdf", ".rtf"}

USAGE = """usage: detect.py [--clean] [--ci] [--] [FILE]

Scores AI-writing patterns in prose. FILE is one path; with no FILE, standard
input is read. Two or more FILE operands: only the last one is scanned.

  --clean      print the scrubbed text (invisible characters removed, non-standard
               spaces normalized, lookalike letters folded) instead of the report
  --ci         add a low/high interval on the score when there are enough sentences
  --           end option parsing, so FILE may begin with a dash
  -h, --help   print this usage message and exit

Supported files: .md .mdx .markdown .txt .text .rst .tex .org .adoc
                 .docx .docm .pptx .pptm .xlsx .xlsm .odt .odp .ods .epub .ipynb
"""

BANDS = [(20, "clean"), (40, "light tells"), (60, "mixed"), (80, "heavy tells"), (100, "pervasive tells")]
HOOK_PHRASES = {
    "clean": "reads clean",
    "light tells": "reads mostly clean",
    "mixed": "reads with some AI tells",
    "heavy tells": "reads with heavy AI tells",
    "pervasive tells": "reads with pervasive AI tells",
}


class InputProblem(Exception):
    """Raised for empty input (kind='empty') or unreadable input (kind='read')."""

    def __init__(self, kind: str, message: str):
        super().__init__(message)
        self.kind = kind
        self.message = message


# ---------------------------------------------------------------------------
# Decoding and extraction
# ---------------------------------------------------------------------------

def decode_bytes(data: bytes) -> str:
    if data.startswith(codecs.BOM_UTF8):
        return data[len(codecs.BOM_UTF8):].decode("utf-8", errors="replace")
    if data.startswith((codecs.BOM_UTF16_LE, codecs.BOM_UTF16_BE)):
        return data.decode("utf-16", errors="replace")
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("utf-8", errors="replace")


def _local(tag) -> str:
    if not isinstance(tag, str):
        return ""
    return tag.rsplit("}", 1)[-1]


def _xml_root(data: bytes):
    try:
        return ET.fromstring(data)
    except ET.ParseError as exc:
        raise InputProblem("read", f"cannot read input: malformed XML ({exc})")


def _member(zf: zipfile.ZipFile, name: str):
    try:
        info = zf.getinfo(name)
    except KeyError:
        return None
    if info.file_size > MEMBER_LIMIT:
        return None
    return zf.read(name)


def _docx_text(zf):
    data = _member(zf, "word/document.xml")
    if data is None:
        return ""
    root = _xml_root(data)
    paras = []
    for p in root.iter():
        if _local(p.tag) != "p":
            continue
        parts = []
        for node in p.iter():
            ln = _local(node.tag)
            if ln == "t":
                parts.append(node.text or "")
            elif ln == "tab":
                parts.append("\t")
            elif ln in ("br", "cr"):
                parts.append("\n")
        paras.append("".join(parts))
    return "\n".join(paras)


def _pptx_text(zf):
    slides = []
    for name in zf.namelist():
        m = re.fullmatch(r"ppt/slides/slide(\d+)\.xml", name)
        if m:
            slides.append((int(m.group(1)), name))
    out = []
    for _, name in sorted(slides):
        root = _xml_root(_member(zf, name) or b"<x/>")
        paras = []
        for p in root.iter():
            if _local(p.tag) != "p":
                continue
            parts = []
            for node in p.iter():
                ln = _local(node.tag)
                if ln == "t":
                    parts.append(node.text or "")
                elif ln == "br":
                    parts.append("\n")
            paras.append("".join(parts))
        out.append("\n".join(paras))
    return "\n".join(out)


def _xlsx_text(zf):
    shared = []
    sst = _member(zf, "xl/sharedStrings.xml")
    if sst is not None:
        for si in _xml_root(sst).iter():
            if _local(si.tag) == "si":
                shared.append("".join((t.text or "") for t in si.iter() if _local(t.tag) == "t"))
    sheets = []
    for name in zf.namelist():
        m = re.fullmatch(r"xl/worksheets/sheet(\d+)\.xml", name)
        if m:
            sheets.append((int(m.group(1)), name))
    out = []
    for _, name in sorted(sheets):
        root = _xml_root(_member(zf, name) or b"<x/>")
        cells = []
        for c in root.iter():
            if _local(c.tag) != "c":
                continue
            ctype = c.get("t")
            v = None
            inline = []
            for child in c:
                lc = _local(child.tag)
                if lc == "v":
                    v = child.text or ""
                elif lc == "is":
                    inline.append("".join((t.text or "") for t in child.iter() if _local(t.tag) == "t"))
            if ctype == "s" and v is not None:
                try:
                    idx = int(v)
                except ValueError:
                    continue
                if 0 <= idx < len(shared):
                    cells.append(shared[idx])
            elif ctype == "inlineStr":
                cells.append("".join(inline))
            elif ctype == "str" and v is not None:
                cells.append(v)
        out.append("\n".join(c for c in cells if c))
    return "\n".join(out)


def _odf_walk(el, out):
    ln = _local(el.tag)
    if ln in ("annotation", "note", "sequence-decls", "variable-decls", "user-field-decls", "tracked-changes"):
        return
    if ln == "s":
        count = 1
        for key, val in el.attrib.items():
            if key.rsplit("}", 1)[-1] == "c":
                try:
                    count = int(val)
                except ValueError:
                    count = 1
        out.append(" " * max(0, count))
        return
    if ln == "tab":
        out.append("\t")
        return
    if ln == "line-break":
        out.append("\n")
        return
    if el.text:
        out.append(el.text)
    for child in el:
        _odf_walk(child, out)
        if child.tail:
            out.append(child.tail)
    if ln in ("p", "h"):
        out.append("\n")


def _odf_text(zf):
    data = _member(zf, "content.xml")
    if data is None:
        return ""
    root = _xml_root(data)
    body = None
    for el in root.iter():
        if _local(el.tag) == "body":
            body = el
            break
    if body is None:
        return ""
    out = []
    _odf_walk(body, out)
    return "".join(out)


_BLOCK_TAGS = {"p", "div", "h1", "h2", "h3", "h4", "h5", "h6", "li", "br", "tr", "section", "article",
               "blockquote", "pre", "figure", "figcaption", "dt", "dd", "header", "footer", "hr", "ul", "ol"}
_SKIP_TAGS = {"script", "style", "head", "nav", "title"}


class _HTMLText(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.out = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in _SKIP_TAGS:
            self.skip += 1
        elif tag in _BLOCK_TAGS:
            self.out.append("\u0001")

    def handle_endtag(self, tag):
        if tag in _SKIP_TAGS:
            self.skip = max(0, self.skip - 1)
        elif tag in _BLOCK_TAGS:
            self.out.append("\u0001")

    def handle_data(self, data):
        if self.skip == 0:
            self.out.append(data)


def _html_to_text(data: bytes) -> str:
    parser = _HTMLText()
    try:
        parser.feed(decode_bytes(data))
        parser.close()
    except Exception:  # tolerant: keep whatever text was collected
        pass
    text = "".join(parser.out)
    text = re.sub(r"[ \t\r\n]+", " ", text)
    lines = [ln.strip() for ln in text.split("\u0001")]
    return "\n".join(ln for ln in lines if ln)


def _epub_text(zf):
    names = zf.namelist()
    docs = []
    opf_path = None
    container = _member(zf, "META-INF/container.xml")
    if container is not None:
        try:
            for el in _xml_root(container).iter():
                if _local(el.tag) == "rootfile" and el.get("full-path"):
                    opf_path = el.get("full-path")
                    break
        except InputProblem:
            opf_path = None
    if opf_path and opf_path in names:
        opf = _xml_root(_member(zf, opf_path) or b"<x/>")
        base = posixpath.dirname(opf_path)
        manifest = {}
        spine = []
        for el in opf.iter():
            ln = _local(el.tag)
            if ln == "item":
                manifest[el.get("id")] = (el.get("href") or "", el.get("properties") or "")
            elif ln == "itemref":
                spine.append(el.get("idref"))
        for idref in spine:
            if idref not in manifest:
                continue
            href, props = manifest[idref]
            if "nav" in props.split():
                continue
            full = posixpath.normpath(posixpath.join(base, unquote(href)))
            docs.append(full)
    if not docs:
        docs = sorted(n for n in names
                      if n.lower().endswith((".xhtml", ".html", ".htm")) and "nav" not in n.lower())
    parts = []
    for name in docs:
        data = _member(zf, name)
        if data is None:
            continue
        parts.append(_html_to_text(data))
    return "\n".join(p for p in parts if p)


def extract_zip(path: str, ext: str) -> str:
    try:
        zf = zipfile.ZipFile(path)
    except (zipfile.BadZipFile, OSError, ValueError) as exc:
        raise InputProblem("read", f"cannot read input: {path}: not a readable zip archive ({exc})")
    with zf:
        try:
            if ext in (".docx", ".docm"):
                return _docx_text(zf)
            if ext in (".pptx", ".pptm"):
                return _pptx_text(zf)
            if ext in (".xlsx", ".xlsm"):
                return _xlsx_text(zf)
            if ext in (".odt", ".odp", ".ods"):
                return _odf_text(zf)
            if ext == ".epub":
                return _epub_text(zf)
        except zipfile.BadZipFile as exc:
            raise InputProblem("read", f"cannot read input: {path}: damaged archive ({exc})")
        except (KeyError, OSError, RuntimeError) as exc:
            raise InputProblem("read", f"cannot read input: {path}: {exc}")
    return ""


def extract_notebook(data: bytes) -> str:
    try:
        nb = json.loads(decode_bytes(data))
    except (ValueError, RecursionError):
        return ""
    if not isinstance(nb, dict) or not isinstance(nb.get("cells"), list):
        return ""
    parts = []
    for cell in nb["cells"]:
        if not isinstance(cell, dict):
            return ""
        if cell.get("cell_type") != "markdown":
            continue
        src = cell.get("source", "")
        if isinstance(src, list):
            if not all(isinstance(s, str) for s in src):
                return ""
            src = "".join(src)
        elif not isinstance(src, str):
            return ""
        parts.append(src)
    return "\n".join(parts)


def load_text(path):
    """Return the extracted prose for a file path, or for standard input when path is None."""
    if path is None:
        data = sys.stdin.buffer.read()
        text = decode_bytes(data)
        if not text.strip():
            raise InputProblem("empty", "empty input")
        return text

    ext = os.path.splitext(path)[1].lower()
    if ext in BINARY_EXTS:
        raise InputProblem("empty", "empty input")
    if os.path.isdir(path):
        raise InputProblem("read", f"cannot read input: {path}: is a directory")
    try:
        with open(path, "rb") as fh:
            data = fh.read()
    except OSError as exc:
        raise InputProblem("read", f"cannot read input: {path}: {exc.strerror or exc}")

    if ext in ZIP_EXTS:
        text = extract_zip(path, ext).strip()
    elif ext == NOTEBOOK_EXT:
        text = extract_notebook(data).strip()
    else:
        text = decode_bytes(data)
    if not text.strip():
        raise InputProblem("empty", "empty input")
    return text


# ---------------------------------------------------------------------------
# Character layer: invisible characters, non-standard spaces, lookalikes
# ---------------------------------------------------------------------------

_EXTRA_FILLERS = {0x034F, 0x115F, 0x3164, 0xFFA0, 0x180B, 0x180C, 0x180D, 0x180F, 0x17B4, 0x17B5}
_BIDI_CONTROLS = {0x200E, 0x200F, 0x061C, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E,
                  0x2066, 0x2067, 0x2068, 0x2069}
_TAG_RANGE = (0xE0020, 0xE007F)
_EMOJI_RANGES = ((0x1F000, 0x1FAFF), (0x2600, 0x27BF))
_CONF_MAP = {}
for _src, _dst in [
    # Cyrillic
    ("а", "a"), ("с", "c"), ("ԁ", "d"), ("е", "e"), ("ɡ", "g"), ("ԍ", "g"), ("һ", "h"), ("і", "i"), ("ј", "j"),
    ("о", "o"), ("р", "p"), ("ѕ", "s"), ("ԛ", "q"), ("ԝ", "w"), ("х", "x"), ("у", "y"),
    ("А", "A"), ("В", "B"), ("С", "C"), ("Е", "E"), ("Н", "H"), ("І", "I"), ("Ј", "J"), ("К", "K"),
    ("М", "M"), ("О", "O"), ("Р", "P"), ("Ѕ", "S"), ("Т", "T"), ("Х", "X"), ("У", "Y"),
    # Greek
    ("ο", "o"), ("ν", "v"), ("ι", "i"), ("α", "a"),
    ("Α", "A"), ("Β", "B"), ("Ε", "E"), ("Ζ", "Z"), ("Η", "H"), ("Ι", "I"), ("Κ", "K"), ("Μ", "M"),
    ("Ν", "N"), ("Ο", "O"), ("Ρ", "P"), ("Τ", "T"), ("Υ", "Y"), ("Χ", "X"),
    # Armenian
    ("օ", "o"), ("ո", "n"), ("ս", "u"), ("ց", "g"),
]:
    _CONF_MAP[_src] = _dst
_ASCII_LETTERS = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")


def _cp(ch: str) -> int:
    return ord(ch) if ch else -1


def _in(ch: str, chars: str) -> bool:
    return bool(ch) and ch in chars


def _is_cjk(ch: str) -> bool:
    c = _cp(ch)
    return 0x4E00 <= c <= 0x9FFF or 0x3400 <= c <= 0x4DBF or 0xF900 <= c <= 0xFAFF or 0x20000 <= c <= 0x2FFFF


def _is_emojiish(ch: str) -> bool:
    if not ch:
        return False
    c = ord(ch)
    if any(lo <= c <= hi for lo, hi in _EMOJI_RANGES):
        return True
    return unicodedata.category(ch).startswith("S")


def _is_spaceless_script(ch: str) -> bool:
    if not ch:
        return False
    c = ord(ch)
    return (0x0E00 <= c <= 0x0EFF or 0x1000 <= c <= 0x109F or 0x1780 <= c <= 0x17FF
            or 0x3040 <= c <= 0x30FF or _is_cjk(ch))


def _is_joining_letter(ch: str) -> bool:
    if not ch or not ch.isalpha():
        return False
    c = ord(ch)
    return (0x0590 <= c <= 0x06FF or 0x0750 <= c <= 0x077F or 0x0900 <= c <= 0x0DFF
            or 0x1000 <= c <= 0x109F or 0x1780 <= c <= 0x17FF or 0xFB1D <= c <= 0xFDFF
            or 0xFE70 <= c <= 0xFEFF)


def _is_mongolian(ch: str) -> bool:
    return bool(ch) and 0x1800 <= ord(ch) <= 0x18AF


def _is_khmer(ch: str) -> bool:
    return bool(ch) and 0x1780 <= ord(ch) <= 0x17FF


def _is_invisible_candidate(ch: str) -> bool:
    cp = ord(ch)
    if cp in (9, 10, 13):
        return False
    if 0xFE00 <= cp <= 0xFE0F or 0xE0100 <= cp <= 0xE01EF or 0x1160 <= cp <= 0x11FF:
        return True
    if cp in _EXTRA_FILLERS:
        return True
    cat = unicodedata.category(ch)
    return cat in ("Cf", "Cc")


def _keep_invisible(cp: int, ch: str, prev: str, nxt: str, rtl: bool) -> bool:
    if 0xFE00 <= cp <= 0xFE0F or 0xE0100 <= cp <= 0xE01EF:
        if _is_emojiish(prev) or _is_cjk(prev):
            return True
        return cp <= 0xFE0F and nxt == "\u20e3"
    if cp == 0x200B:
        return _is_spaceless_script(prev) or _is_spaceless_script(nxt)
    if cp == 0x00AD:
        return bool(prev) and bool(nxt) and prev.isalpha() and nxt.isalpha()
    if cp in _BIDI_CONTROLS:
        return rtl
    if 0x180B <= cp <= 0x180D or cp == 0x180F:
        return _is_mongolian(prev)
    if cp in (0x17B4, 0x17B5):
        return _is_khmer(prev) or _is_khmer(nxt)
    if cp in (0x200C, 0x200D):
        return (_is_joining_letter(prev) or _is_joining_letter(nxt)
                or _is_emojiish(prev) or _is_emojiish(nxt))
    return False


def char_layer(text: str):
    """Return (invisible_positions, nonstandard_space_positions, separator_positions).

    Positions that a cleanup keeps are not reported. The same rules serve the
    counts (on the scan window) and the cleanup (on the full text).
    """
    rtl = any(unicodedata.bidirectional(c) in ("R", "AL") for c in text)
    inv, spc, sep = [], [], []
    tag_base = ""
    n = len(text)
    for i, ch in enumerate(text):
        cp = ord(ch)
        if _TAG_RANGE[0] <= cp <= _TAG_RANGE[1]:
            # TAG characters survive only inside a black-flag tag sequence.
            if tag_base != "\U0001F3F4":
                inv.append(i)
            continue
        prev = text[i - 1] if i > 0 else ""
        nxt = text[i + 1] if i + 1 < n else ""
        if _is_invisible_candidate(ch):
            if not _keep_invisible(cp, ch, prev, nxt, rtl):
                inv.append(i)
        elif unicodedata.category(ch) == "Zs" and ch != " ":
            if ch in ("\u00a0", "\u202f") and (
                    (prev and prev.isdecimal()) or (nxt and nxt.isdecimal())
                    or _in(nxt, ":;!?»›%€") or _in(prev, "«‹")):
                pass
            else:
                spc.append(i)
        elif unicodedata.category(ch) in ("Zl", "Zp"):
            sep.append(i)
        tag_base = ch
    return inv, spc, sep


_TOKEN_RE = re.compile(r"\S+")


def _fold_token(tok: str):
    """Return (folded_token, is_homoglyph_hit) for one whitespace-delimited token."""
    letters = [c for c in tok if c.isalpha()]
    if not letters:
        return tok, False
    has_ascii = any(c in _ASCII_LETTERS for c in letters)
    has_conf = any(c in _CONF_MAP for c in letters)
    other = any(ord(c) > 127 and c not in _CONF_MAP for c in letters)
    if has_ascii and has_conf and not other:
        return "".join(_CONF_MAP.get(c, c) for c in tok), True
    return tok, False


def homoglyph_spans(text: str):
    spans = []
    for m in _TOKEN_RE.finditer(text):
        _, hit = _fold_token(m.group())
        if hit:
            spans.append(m.span())
    return spans


def trailing_spans(text: str):
    """Catalogue 68 hits: trailing spaces or tabs, double newline at end, leading whitespace."""
    spans = []
    pos = 0
    for line in text.split("\n"):
        body = line[:-1] if line.endswith("\r") else line
        stripped = body.rstrip(" \t")
        trail = body[len(stripped):]
        if trail:
            # Two trailing spaces that end a line of prose are a markdown hard break, kept.
            if not (trail == "  " and stripped.strip()):
                spans.append((pos + len(stripped), pos + len(body)))
        pos += len(line) + 1
    if re.search(r"(?:\r?\n[ \t]*){2,}\Z", text):
        m = re.search(r"(?:\r?\n[ \t]*){2,}\Z", text)
        spans.append(m.span())
    if text[:1].isspace():
        spans.append((0, 1))
    return spans


# ---------------------------------------------------------------------------
# Cleanup
# ---------------------------------------------------------------------------

def cleanup_text(text: str) -> str:
    inv, spc, sep = char_layer(text)
    chars = list(text)
    for i in inv:
        chars[i] = ""
    for i in spc:
        chars[i] = " "
    for i in sep:
        chars[i] = "\n"
    body = "".join(chars)
    body = _TOKEN_RE.sub(lambda m: _fold_token(m.group())[0], body)

    out = []
    for line in body.split("\n"):
        cr = line.endswith("\r")
        core = line[:-1] if cr else line
        stripped = core.rstrip(" \t")
        trail = core[len(stripped):]
        keep = "  " if (trail == "  " and stripped.strip()) else ""
        out.append(stripped + keep + ("\r" if cr else ""))
    while out and not out[0].strip():
        out.pop(0)
    result = "\n".join(out).rstrip(" \t\r\n")
    if result and text.endswith("\n"):
        result += "\n"
    return result


# ---------------------------------------------------------------------------
# Markdown masking: fenced code, inline code, blockquotes, tables, badges, front matter
# ---------------------------------------------------------------------------

_FENCE_OPEN = re.compile(r"^ {0,3}(`{3,}|~{3,})(.*)$")
_FENCE_CLOSE = re.compile(r"^ {0,3}(`{3,}|~{3,})[ \t]*$")
_BADGE_LINE = re.compile(r"^\s*(?:\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)\s*)+$")
_INLINE_CODE = re.compile(r"(`+)(?!`)(.+?)(?<!`)\1(?!`)")


def _blank(s: str) -> str:
    return "".join(c if c == "\n" else " " for c in s)


def mask_markdown(text: str) -> str:
    lines = text.split("\n")
    n = len(lines)
    skip = [False] * n
    stripped = [ln.rstrip("\r") for ln in lines]

    if n and stripped[0] == "---":
        for j in range(1, n):
            if stripped[j] in ("---", "..."):
                for k in range(j + 1):
                    skip[k] = True
                break

    i = 0
    while i < n:
        if skip[i]:
            i += 1
            continue
        m = _FENCE_OPEN.match(stripped[i])
        if m and not (m.group(1)[0] == "`" and "`" in m.group(2)):
            fence, ch, size = m.group(1), m.group(1)[0], len(m.group(1))
            skip[i] = True
            k = i + 1
            while k < n:
                skip[k] = True
                mc = _FENCE_CLOSE.match(stripped[k])
                if mc and mc.group(1)[0] == ch and len(mc.group(1)) >= size:
                    break
                k += 1
            i = k + 1
            continue
        i += 1

    i = 0
    while i < n:
        if skip[i]:
            i += 1
            continue
        if re.match(r"^ {0,3}>", stripped[i]):
            j = i
            while j < n and not skip[j] and re.match(r"^ {0,3}>", stripped[j]):
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    skip[k] = True
            i = j
            continue
        s = stripped[i]
        if s.lstrip().startswith("|") and s.count("|") >= 2:
            skip[i] = True
        elif _BADGE_LINE.match(s):
            skip[i] = True
        i += 1

    out = []
    for idx, line in enumerate(lines):
        if skip[idx]:
            out.append(_blank(line))
        else:
            out.append(_INLINE_CODE.sub(lambda m: _blank(m.group(0)), line))
    return "\n".join(out)


# ---------------------------------------------------------------------------
# Text structure helpers
# ---------------------------------------------------------------------------

_WORD_RE = re.compile(r"(?:[^\W_]|['’\-])+")


def count_words(seg: str) -> int:
    return sum(1 for w in _WORD_RE.findall(seg) if any(c.isalnum() for c in w))


def sentence_spans(masked: str):
    out = []
    for m in re.finditer(r"[^\n.!?…]*[.!?…]+|[^\n.!?…]+", masked):
        s, e = m.span()
        nw = count_words(masked[s:e])
        if nw:
            out.append((s, e, nw))
    return out


def paragraph_spans(masked: str):
    out = []
    pos = 0

    def add(a, b):
        seg = masked[a:b]
        lead = len(seg) - len(seg.lstrip())
        trail = len(seg) - len(seg.rstrip())
        s2, e2 = a + lead, b - trail
        if e2 > s2 and count_words(masked[s2:e2]):
            out.append((s2, e2))

    for m in re.finditer(r"\n[ \t\r]*\n+", masked):
        add(pos, m.start())
        pos = m.end()
    add(pos, len(masked))
    return out


def lines_with_spans(text: str):
    out = []
    pos = 0
    for line in text.split("\n"):
        out.append((pos, pos + len(line), line))
        pos += len(line) + 1
    return out


def excerpt(window: str, s: int, e: int) -> str:
    a = max(0, s - 30)
    b = min(len(window), max(e, s) + 30)
    seg = window[a:b].replace("\r", " ").replace("\n", " ").strip()
    pre = "…" if a > 0 else ""
    post = "…" if b < len(window) else ""
    return f"{pre}{seg}{post}"


def _cv(values):
    mean = sum(values) / len(values)
    if mean <= 0:
        return None
    var = sum((x - mean) ** 2 for x in values) / len(values)
    return math.sqrt(var) / mean


# ---------------------------------------------------------------------------
# Catalogue patterns
# ---------------------------------------------------------------------------

def _wf(word: str) -> str:
    if " " in word or "-" in word:
        return re.escape(word).replace(r"\ ", r"\s+")
    if word.endswith("e"):
        return re.escape(word[:-1]) + "(?:e|es|ed|ing)?"
    return re.escape(word) + "(?:s|es|ed|ing)?"


def _lex(words):
    return r"\b(?:" + "|".join(_wf(w) for w in words) + r")\b"


def _phr(phrases):
    return r"\b(?:" + "|".join(re.escape(p).replace(r"\ ", r"\s+") for p in phrases) + r")\b"


def C(pattern, flags=re.I):
    return re.compile(pattern, flags)


def rx_spans(ctx, regexes):
    spans = []
    for r in regexes:
        for m in r.finditer(ctx.masked):
            spans.append(m.span())
    spans.sort()
    return spans


STOCK_ADJ = {"robust", "seamless", "vibrant", "innovative", "powerful", "elegant", "comprehensive", "dynamic",
             "scalable", "efficient", "intuitive", "cutting-edge", "reliable", "versatile", "flexible",
             "transformative", "sophisticated", "stunning", "breathtaking", "exceptional", "remarkable",
             "thriving", "bold", "modern", "holistic", "meticulous", "nuanced", "polished", "compelling",
             "fresh", "warm", "cozy", "rich", "clean"}
_ADJ_SUFFIX = re.compile(r"(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$")
_CHAIN = C(r"\b[A-Za-z][\w'’-]*(?:,\s*(?:and\s+|or\s+)?|\s+and\s+)[A-Za-z][\w'’-]*"
           r"(?:(?:,\s*(?:and\s+|or\s+)?|\s+and\s+)[A-Za-z][\w'’-]*){2,}\b", 0)

SYNONYM_CLUSTERS = [
    ["protagonist", "main character", "central figure", "hero", "heroine"],
    ["company", "firm", "organization", "enterprise", "business"],
    ["author", "writer", "novelist", "scribe"],
    ["report", "study", "analysis", "investigation", "examination"],
    ["technology", "tool", "system", "platform", "solution"],
    ["technique", "method", "approach", "strategy", "tactic"],
    ["challenge", "obstacle", "difficulty", "hurdle", "barrier"],
    ["benefit", "advantage", "upside", "strength"],
]

HEDGES = ["may", "might", "could", "possibly", "potentially", "arguably", "perhaps", "seems", "seem",
          "seems to", "seems like", "appears to", "appear to", "somewhat", "relatively", "fairly",
          "kind of", "sort of"]
_HEDGE_RE = C(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems?(?:\s+(?:to|like))?|"
              r"appears?\s+to|somewhat|relatively|fairly|kind of|sort of)\b", 0)
_FULL_FORMS = C(r"\b(?:I am|I have|I will|I would|I had|we are|we have|we will|we would|they are|you are|"
                r"it is|that is|do not|does not|did not|is not|are not|was not|will not|could not|"
                r"would not|should not|have not|has not)\b", 0)
_CONTRACTED = C(r"\b(?:I|we|you|they|it|that|don|doesn|didn|isn|aren|wasn|weren|won|wouldn|couldn|"
                r"shouldn|haven|hasn|hadn)['’](?:m|re|ve|ll|d|t|s)\b", 0)
_FIRST_PERSON = re.compile(r"\b(?:I|we|me|my|our|us)\b")

_MINOR_WORDS = {"a", "an", "the", "of", "in", "on", "at", "to", "for", "by", "with", "from", "up", "as",
                "into", "onto", "over", "and", "but", "or", "nor", "so", "yet", "via", "per", "off"}
_PROMO_VERBS = ("install|join|grab|download|try|discover|experience|escape|transform|reclaim|unlock|elevate|"
                "boost|say|imagine|explore|meet|introducing|upgrade|claim|unleash|supercharge|level|stop|start")
_QA_RE = C(r"(?:^|(?<=[.!?]\s)|(?<=\n))(?:Is|Are|Can|Do|Does|Did|Will|Would|Should|Could|Has|Have|Was|"
           r"Were|May|Might)\b[^.!?\n]{0,80}\?\s*(?:Yes|No|Absolutely|Never|Maybe|Probably|Always)[.!]", re.M)
_TRANSITION_RE = re.compile(r"(?:^|(?<=[.!?]\s)|(?<=[.!?]\n)|(?<=\n))"
                            r"(Additionally|Furthermore|Moreover|However|Nevertheless|Consequently|Subsequently|Notably)\b",
                            re.M)
_YEAR_RANGE = re.compile(r"(?<!\d)(1\d{3}|2\d{3})-(1\d{3}|2\d{3})(?!\d)")
_EMOJI_RE = C(r"[\U0001F000-\U0001FAFF☀-➿]", 0)
_CURLY_RE = re.compile("[“”‘’]")
_HOSTS = {"chatgpt.com", "chat.openai.com", "perplexity.ai", "claude.ai", "gemini.google.com",
          "copilot.microsoft.com", "poe.com"}
_UTM_RE = C(r"utm_source=([A-Za-z0-9.\-]+)", re.I)
_TABLE_SEP = re.compile(r"^\s*\|?\s*:?-{2,}")
_HEADING_RE = re.compile(r"^ {0,3}(#{1,6})[ \t]+(.*?)[ \t]*#*[ \t]*$")
_RULE_RE = re.compile(r"^ {0,3}(?:(?:-[ \t]*){3,}|(?:\*[ \t]*){3,}|(?:_[ \t]*){3,})$")


def _detect_transition_clusters(ctx):
    spans = []
    for ps, pe in ctx.paras:
        seg = ctx.masked[ps:pe]
        hits = [(ps + m.start(), ps + m.end()) for m in _TRANSITION_RE.finditer(seg)]
        if len(hits) >= 2:
            spans.extend(hits)
    return spans


def _detect_synonyms(ctx):
    spans = []
    used = 0
    clusters_hit = []
    for cluster in SYNONYM_CLUSTERS:
        found = []
        for member in cluster:
            r = C(r"\b" + re.escape(member).replace(r"\ ", r"\s+") + r"(?:s|es)?\b")
            ms = list(r.finditer(ctx.masked))
            if ms:
                found.append(member)
                spans.extend(m.span() for m in ms)
        if len(found) >= 3:
            used += 1
            clusters_hit.append(found)
    return spans if used else []


def _detect_chain(ctx):
    spans = []
    for m in _CHAIN.finditer(ctx.masked):
        words = [w.lower() for w in re.findall(r"[A-Za-z][\w'’-]*", m.group())]
        if len(words) < 4:
            continue
        if any(w in STOCK_ADJ or _ADJ_SUFFIX.search(w) for w in words):
            spans.append(m.span())
    return spans


def _detect_promo_imperatives(ctx):
    r = C(r"^\s*(?:" + _PROMO_VERBS + r")\b")
    hits = []
    for s, e, _ in ctx.sents:
        if r.match(ctx.masked[s:e]):
            hits.append((s, e))
    return hits if len(hits) >= 3 else []


def _detect_notability(ctx):
    return rx_spans(ctx, [
        C(r"(?i:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?i:in|by)\s+"
          r"[A-Z][\w&.]*(?:,\s*|\s+and\s+)[A-Z][\w&.]*", 0),
        C(r"\b\d[\d,.]*\s*[kKmM]?\s+followers\b", re.I),
        C(r"\b(?:strong|active|significant|robust)\s+(?:online|digital|social[- ]media)\s+presence\b"),
        C(r"\bwidely covered\b"),
        C(r"\bindependent coverage\b"),
    ])


def _detect_monotony(ctx):
    if len(ctx.sents) < 3:
        return []
    cv = _cv([nw for _, _, nw in ctx.sents])
    if cv is None or cv >= 0.35:
        return []
    return [(ctx.sents[0][0], ctx.sents[-1][1])]


def _detect_alternation(ctx):
    spans = []
    lens = [nw for _, _, nw in ctx.sents]
    i = 0
    while i + 6 <= len(lens):
        seg = lens[i:i + 6]
        diffs = [seg[k + 1] - seg[k] for k in range(5)]
        ok = all(diffs[k] * diffs[k + 1] < 0 for k in range(4)) and all(abs(d) >= 4 for d in diffs)
        if ok:
            spans.append((ctx.sents[i][0], ctx.sents[i + 5][1]))
            i += 6
        else:
            i += 1
    return spans


def _detect_uniform_paragraphs(ctx):
    if len(ctx.paras) < 4:
        return []
    counts = [count_words(ctx.masked[s:e]) for s, e in ctx.paras]
    cv = _cv(counts)
    if cv is None or cv >= 0.4:
        return []
    return list(ctx.paras)


def _sentences_in(ctx, ps, pe):
    return [(s, e, nw) for s, e, nw in ctx.sents if ps <= s and e <= pe]


def _detect_opener_repetition(ctx):
    spans = []
    for ps, pe in ctx.paras:
        sents = _sentences_in(ctx, ps, pe)
        if len(sents) < 3:
            continue
        openers = {}
        for s, e, _ in sents:
            words = re.findall(r"[\w'’-]+", ctx.masked[s:e].lower())
            if len(words) >= 2:
                openers.setdefault(tuple(words[:2]), []).append((s, e))
        for group in openers.values():
            if len(group) >= 3:
                spans.extend(group)
    return spans


def _detect_semicolons(ctx):
    if ctx.words < 300:
        return []
    if ";" in ctx.masked or ctx.masked.count("(") > 1:
        return []
    return [(0, min(len(ctx.masked), 80))]


def _detect_hedge_stacking(ctx):
    spans = []
    for s, e, _ in ctx.sents:
        seg = ctx.masked[s:e]
        hits = {m.group() for m in _HEDGE_RE.finditer(seg)}
        if len(hits) >= 2:
            spans.append((s, e))
    return spans


def _detect_contraction_absence(ctx):
    words = len(re.findall(r"\b\w+\b", ctx.masked))
    if words == 0:
        return []
    first = len(_FIRST_PERSON.findall(ctx.masked))
    if first < 3 or first / words < 0.03:
        return []
    full = list(_FULL_FORMS.finditer(ctx.masked))
    contracted = len(_CONTRACTED.findall(ctx.masked))
    if len(full) < 3 or len(full) / (len(full) + contracted) < 0.8:
        return []
    return [m.span() for m in full]


def _detect_em_dash_paragraphs(ctx):
    spans = []
    for ps, pe in ctx.paras:
        if ctx.masked[ps:pe].count("—") >= 2:
            spans.append((ps, pe))
    return spans


def _detect_title_case(ctx):
    spans = []
    for s, e, line in lines_with_spans(ctx.masked):
        m = _HEADING_RE.match(line)
        if not m:
            continue
        text = m.group(2).strip()
        words = re.findall(r"[A-Za-z][A-Za-z'’\-]*|[0-9]+", text)
        if len(words) < 3 or not text[:1].isalpha() or text.upper() == text:
            continue
        major = [w for w in words if w.lower() not in _MINOR_WORDS and w[0].isalpha()]
        if len(major) >= 2 and all(w[0].isupper() for w in major):
            spans.append((s, e))
    return spans


def _detect_years(ctx):
    spans = []
    for m in _YEAR_RANGE.finditer(ctx.masked):
        if int(m.group(1)) < int(m.group(2)):
            spans.append(m.span())
    return spans


def _detect_utm(ctx):
    spans = []
    for m in _UTM_RE.finditer(ctx.masked):
        if m.group(1).rstrip(".").lower() in _HOSTS:
            spans.append(m.span())
    return spans


def _detect_horizontal_rules(ctx):
    lines = lines_with_spans(ctx.masked)
    rules = [(s, e) for s, e, line in lines if _RULE_RE.match(line)]
    if len(lines) >= 24 and len(rules) >= 3:
        return rules
    return []


def _detect_fragmented_headers(ctx):
    spans = []
    lines = lines_with_spans(ctx.masked)
    for idx, (s, e, line) in enumerate(lines):
        m = _HEADING_RE.match(line)
        if not m:
            continue
        head_words = {w.lower() for w in re.findall(r"[A-Za-z]{3,}", m.group(2))}
        j = idx + 1
        while j < len(lines) and not lines[j][2].strip():
            j += 1
        if j >= len(lines):
            continue
        js, je, nxt = lines[j]
        plain = nxt.strip()
        if not plain or re.match(r"^\s*(?:[#>\-*+|]|\d+[.)])", nxt):
            continue
        words = plain.split()
        if len(words) > 4:
            continue
        nxt_words = {w.lower() for w in re.findall(r"[A-Za-z]{3,}", plain)}
        if head_words & nxt_words:
            spans.append((js, je))
    return spans


def _detect_mid_essay_bullets(ctx):
    if re.search(r"(?m)^ {0,3}#{1,6}[ \t]", ctx.masked):
        return []
    list_paras = []
    prose = 0
    for ps, pe in ctx.paras:
        block = ctx.masked[ps:pe].split("\n")
        if all(re.match(r"^\s*(?:[-*+]|\d+[.)])\s+", ln) for ln in block if ln.strip()):
            list_paras.append((ps, pe))
        else:
            prose += 1
    return list_paras if list_paras and prose >= 2 else []


def _detect_comma_ing_tails(ctx):
    return rx_spans(ctx, [C(r",\s+(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|"
                            r"fostering|cultivating|encompassing|signaling|demonstrating|illustrating|"
                            r"representing|suggesting|indicating|reinforcing|leveraging|aligning|embodying|"
                            r"exemplifying|epitomizing)\b")])


def _detect_degenerate(ctx):
    toks = [(m.start(), m.end(), m.group().lower()) for m in re.finditer(r"\w+", ctx.masked)]
    n = len(toks) - 5
    if n < 10:
        return []
    grams = [tuple(t[2] for t in toks[i:i + 6]) for i in range(n)]
    counts = Counter(grams)
    dup = [i for i, g in enumerate(grams) if counts[g] > 1]
    if len(dup) / n < 0.2:
        return []
    return [(toks[i][0], toks[i + 5][1]) for i in dup]


# Lexical families and phrase lists.  Each entry: (number, label, fn(ctx) -> spans).
def _rx_fn(regexes):
    return lambda ctx: rx_spans(ctx, regexes)


_FAMILIES = []


def _add(num, label, fn):
    _FAMILIES.append((num, label, fn))


_add(1, "AI vocabulary", _rx_fn([
    C(_lex(["additionally", "align with", "crucial", "delve", "tapestry", "pivotal", "vibrant", "meticulous",
            "testament", "underscore", "intricate", "intricacies", "interplay", "garner", "bolster", "foster",
            "showcase", "emphasize", "enduring", "enhance", "leverage", "utilize", "facilitate", "encompass",
            "harness", "holistic", "paradigm", "transformative", "unprecedented", "myriad", "plethora", "robust",
            "seamless", "navigate", "embark", "craft", "landscape", "journey", "realm", "multifaceted",
            "elevate", "empower", "unlock"])),
    C(r"\bcapture the (?:essence|spirit|imagination|heart|magic)\b"),
]))

_add(2, "Model-dialect vocabulary", None)  # set below; needs two hits

_add(3, "Promotional language", lambda ctx: rx_spans(ctx, [
    C(_phr(["nestled", "breathtaking", "must-visit", "stunning", "picturesque", "charming", "idyllic",
            "vibrant community", "rich cultural heritage", "in the heart of", "world-class", "top-tier",
            "unparalleled", "premier", "esteemed organization", "valuable asset", "passion for excellence",
            "proven track record", "results-oriented", "wealth of experience", "dynamic team",
            "fast-paced environment", "deeply passionate", "perfectly situated", "close-knit team",
            "tight-knit team", "uniquely positioned to"])),
    C(r"\bI am excited to (?:apply|bring)\b"),
    C(r"\bleading (?:provider|brand|company|firm|platform|name)\b"),
]) + _detect_promo_imperatives(ctx))

_add(4, "Hyphenated word-pair overuse", _rx_fn([C(_phr([
    "cutting-edge", "best-in-class", "next-generation", "state-of-the-art", "results-driven",
    "detail-oriented", "forward-thinking", "data-driven", "high-performing", "top-notch", "well-rounded",
    "fast-growing"]))]))

_add(5, "\"Simple yet\" cliche", _rx_fn([C(
    r"\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b")]))

_add(6, "Stacked adjective chains", _detect_chain)

_add(8, "Synonym cycling", _detect_synonyms)

_add(10, "Significance inflation", _rx_fn([
    C(r"\b(?:stands?|stood|serves?|served) as an? (?:testament|reminder|symbol|beacon|cornerstone|bridge|"
      r"gateway|hallmark)\b"),
    C(r"\b(?:underscor|highlight)\w*\s+(?:its|the|their|his|her)\s+(?:importance|significance|enduring|central|"
      r"vital|crucial|pivotal|key)\b"),
    C(r"\breflects? a broader (?:trend|shift|pattern)\b"),
    C(r"\bmarks? a (?:turning point|milestone|watershed|new chapter|new era)\b"),
    C(r"\bsymbolizes\b"),
    C(r"\bsets? the stage for\b"),
    C(r"\bleft an indelible mark\b"),
    C(r"\bplays? a (?:crucial|pivotal|vital|key|central|significant) role\b"),
    C(r"\bhas (?:shaped|sparked)\b"),
    C(r"\bhas come to (?:define|symbolize)\b"),
]))

_add(11, "Notability name-dropping", _detect_notability)

_add(12, "Vague attributions", _rx_fn([C(_phr([
    "experts argue", "experts believe", "experts say", "experts claim", "experts note", "experts suggest",
    "expert argues", "industry reports", "industry observers", "industry analysts", "observers have cited",
    "observers have noted", "some critics argue", "researchers have found", "studies suggest",
    "it is widely believed"]))]))

_add(13, "Article title used as proper noun", _rx_fn([re.compile(
    r"\bThe (?:List|Index|Compilation|Collection|Catalogue|Guide|Overview) of [^\n.!?]{2,120}? is (?:a|an|the)\b")]))

_add(14, "Conservation or ecosystem padding", _rx_fn([
    C(r"\bplays? a (?:vital|crucial|key|significant) role in (?:its|the) ecosystem\b"),
    C(r"\bconservation efforts (?:are|is) (?:underway|ongoing|in place)\b"),
    C(r"\bserves? as an indicator species\b"),
    C(r"\bcontributes? to biodiversity\b"),
]))

_add(15, "False range", _rx_fn([
    C(r"\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?\n]*?"
      r"\bto (?:the )?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b"),
    C(r"\bfrom (?:the )?humble\b[^.!?\n]*?\bto (?:the )?(?:mighty|towering|grand|sprawling)\b"),
]))

_add(16, "Superficial -ing tail clause", _detect_comma_ing_tails)

# 17: two forms, both weight zero. Keys are assigned in the registry below.
_add(17, "Negative parallelism (weight zero)", _rx_fn([
    C(r"\bit[’']s not (?:just|merely) (?:about|a|an)\b"),
    C(r"\bnot only[^.!?\n]{0,40}?\bbut\b"),
    C(r"\bdoesn[’']t just[^,.\n]{0,40}?\bit\b"),
]))
_add(17, "Tailing negation (weight zero)", _rx_fn([
    C(r",\s*no (?:guessing|waste|wasted motion|hassle|fluff|stress|jargon)\b"),
]))

_add(18, "\"Not X, just Y\" framing", _rx_fn([
    C(r"\b(?:no|not)\s+\w+,\s*(?:just|only|simply)\s+\w+"),
    C(r"\b(?:not|isn[’']t|aren[’']t|wasn[’']t|weren[’']t)\s+(?:just|merely)\s+"
      r"(?:a |an |the )?\w+(?:,|\s+—|\s+–|\s+-)\s*(?:it[’']s|it is|it was|they[’']re|"
      r"they are|they were|that[’']s|but)\b"),
]))

_add(19, "Filler phrases", _rx_fn([C(_phr([
    "in order to", "due to the fact that", "at this point in time", "in the event that", "has the ability to",
    "it is important to note that", "it should be mentioned that", "needless to say"]))]))

_add(20, "Empty pivot phrase", _rx_fn([
    C(r"\bit[’']s worth (?:noting|mentioning) that\b"),
    C(r"\bit bears (?:noting|mentioning) that\b"),
    C(r"\bone thing to (?:consider|keep in mind) is\b"),
    C(r"\bit is interesting to note that\b"),
    C(r"\ba key consideration is\b"),
    C(r"\ba point to highlight is\b"),
]))

_add(21, "Outcome speculation tail", _rx_fn([C(
    r",\s+(?:raising questions about|prompting reflection on|sparking debate about|with broader implications for|"
    r"reshaping our understanding of|paving the way for|signaling a shift toward)\b")]))

_add(22, "Persuasive authority trope", _rx_fn([C(_phr([
    "here’s the thing", "here's the thing", "make no mistake", "the truth is", "let’s be honest",
    "let's be honest", "the simple fact is", "at its core", "what really matters", "more than anything",
    "at the end of the day", "the bottom line is", "in reality", "the real question is",
    "the heart of the matter", "the deeper issue", "when you get down to it", "when all is said and done"]))]))

_add(23, "Editorial interjection", _rx_fn([
    C(r"\bit(?:[’']s| is) important to (?:remember|note|understand|recognize)\b"),
    C(r"\bone must note that\b"),
    C(r"\bit is worth pointing out\b"),
    C(r"\bit cannot be overstated that\b"),
    C(r"\bit must be emphasized that\b"),
]))

_add(24, "Self-thoroughness phrase", _rx_fn([
    C(r"\bthis comprehensive (?:guide|overview|analysis)\b"),
    C(r"\bthis in-depth (?:analysis|look|examination)\b"),
    C(r"\bthis complete (?:guide|overview)\b"),
    C(r"\ba thorough examination of\b"),
    C(r"\beverything you need to know about\b"),
]))

_add(25, "Question-answer rhetorical pattern", _rx_fn([_QA_RE]))

_add(26, "\"Concrete evidence\" defense phrase", _rx_fn([
    C(r"\bwithout concrete (?:evidence|proof)\b"),
    C(r"\bdo you have concrete (?:evidence|proof)\b"),
    C(r"\bI (?:would )?need concrete (?:evidence|examples|proof) to\b"),
    C(r"\babsent concrete proof\b"),
    C(r"\bprovide concrete evidence\b"),
]))

_add(27, "Compulsive intro hook", _rx_fn([
    C(r"\bin today[’']s(?: \w+){0,2} (?:world|landscape|environment|market)\b"),
    C(r"\bin a world where\b"),
    C(r"\bin an era of\b"),
    C(r"\bin recent years,"),
    C(r"\bmore than ever before\b"),
    C(r"\bwe live in a (?:time|world) when\b"),
    C(r"\b(?:great|exciting|big) news\s*[!:]"),
    C(r"\bever (?:wanted|wondered|dreamed|wished)\b[^?\n]{0,80}\?"),
    C(r"\bin an increasingly (?:interconnected|digital|competitive|complex) world\b"),
]))

_add(30, "Diff-anchored writing", _rx_fn([
    C(r"\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)\b"),
    C(r"\b(?:the|this) (?:latest |new )?(?:update|release|version|change|patch|design) "
      r"(?:adds|introduces|brings|delivers|includes|provides|improves)\b"),
    C(r"\b(?:has|have) been (?:updated|refactored|improved|enhanced|changed) to\b"),
    C(r"\bpreviously\b[^.!?\n]*\bnow\b"),
    C(r"\b(?:wasn[’']t|weren[’']t) there before\b"),
    C(r"\bwe[’']ve (?:now )?(?:added|removed|replaced|refactored|migrated)\b"),
    C(r"\bwe have (?:now )?(?:added|removed|replaced|refactored|migrated)\b"),
]))

_add(31, "Signposting or announcement", _rx_fn([
    C(r"\blet[’']s (?:dive|delve|explore)\b"),
    C(r"\blet[’']s break (?:this|it) down\b"),
    C(r"\bhere[’']s what you need to know\b"),
    C(r"\bwithout further ado\b"),
    C(r"\bnow let[’']s look at\b"),
    C(r"\bbuckle up\b"),
    C(r"\bstay with me\b"),
    C(r"\b(?:are you )?ready to dive in\b"),
]))

_add(32, "Cataloguing lead-in", _rx_fn([
    C(r"\b(?:used|uses|use|employs?|employed|relied on|utilizes|utilized)\s+(?:several|various|a number of|"
      r"multiple|different|many|numerous)\s+\w+"),
    C(r"(?:^|(?<=[.!?]\s)|(?<=\n))These\s+(?:\w+\s+)?(?:provide|offer|give|reveal|show|allow|enable|help)\s+"
      r"(?:information|insight|understanding|details|data)\b", re.I | re.M),
    C(r"\b(?:is|are|was|were|remains|becomes)\s+(?:the |a )?(?:language|currency|architecture|heartbeat|"
      r"lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective tissue)\s+of\b"),
]))

_add(33, "Inline-header vertical list", _rx_fn([re.compile(
    r"^[ \t]*(?:[-*+][ \t]+|\d+[.)][ \t]+)?\*\*[^*\n]+?(?::\*\*|\*\*:)", re.M)]))

_add(34, "Mid-essay bullet injection", _detect_mid_essay_bullets)

_add(35, "Fragmented header", _detect_fragmented_headers)

_add(36, "Formulaic challenges section", _rx_fn([
    C(r"\bdespite (?:these|its|the) (?:challenges|obstacles)\b"),
    C(r"\bchallenges and (?:future )?(?:prospects|outlook|legacy)\b"),
    C(r"\bcontinues to thrive\b"),
    C(r"\btypical of (?:emerging|urban|modern)\b"),
    C(r"\bfaces (?:several|many|numerous) challenges\b"),
]))

_add(37, "Transition cluster", _detect_transition_clusters)

_add(38, "Compulsive conclusion opener", _rx_fn([C(
    r"^\s*(?:in conclusion|overall|in summary|to summarize|to conclude|all in all|in essence|ultimately)\b",
    re.I | re.M)]))

_add(39, "Generic positive conclusion", _rx_fn([
    C(r"\bthe future looks bright\b"),
    C(r"\bexciting times lie ahead\b"),
    C(r"\bjourney toward excellence\b"),
    C(r"\bstep in the right direction\b"),
    C(r"\b(?:the )?(?:outlook|future)(?: for [^.!?\n]{1,40})? (?:is|looks|remains) bright\b"),
    C(r"\bwell[- ]positioned for (?:whatever comes next|the future|the road ahead)\b"),
]))

_add(40, "Sentence-length monotony", _detect_monotony)
_add(41, "Mechanical sentence-length alternation", _detect_alternation)
_add(42, "Opener repetition", _detect_opener_repetition)
_add(44, "Uniform paragraph length", _detect_uniform_paragraphs)
_add(46, "Semicolon and parenthesis underuse", _detect_semicolons)

_add(47, "Chatbot artifact", _rx_fn([
    C(r"\bI hope this helps\b"),
    C(r"\bCertainly!"),
    C(r"\bOf course!"),
    C(r"\blet me know if you\b"),
    C(r"\bwould you like me to\b"),
    C(r"\bfeel free to (?:ask|reach out)\b"),
    C(r"\bhappy to help[.!]"),
    C(r"\b(?:here|below) is (?:a|an|the) (?:overview|summary|rundown|recap|brief)\b"),
    C(r"\bhere (?:are|[’']s) (?:a few|some|two|three) (?:options|drafts|versions|variations)\b"),
    C(r"\bhere (?:is|[’']s) (?:a )?draft\b"),
    C(r"\bdepending on the (?:vibe|tone|style)\b"),
    C(r"\bI hope (?:this email )?finds you well\b"),
    C(r"\bas an? (?:AI|LLM|AI assistant|AI language model|large language model|language model)\b"),
    C(r"\bto (?:answer|address) your question\b"),
    C(r"\bin (?:response|answer) to your question\b"),
    C(r"\byour question (?:about|regarding|concerning)\b"),
    C(r"\bas (?:you )?(?:requested|asked), here\b"),
    C(r"\bhere is (?:the )?(?:draft|first pass|revised version (?:of|for))\b"),
]))

_add(48, "Sycophantic tone", _rx_fn([
    C(r"\byou[’']?(?:re| are) absolutely right\b"),
    C(r"\b(?:great|excellent) (?:question|point)\s*[!.,]"),
    C(r"\bwhat a (?:thoughtful|great|wonderful|fantastic) question\b"),
    C(r"\bthat[’']s a (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\b"),
]))

_add(50, "Knowledge-cutoff disclaimer", _rx_fn([
    C(r"\bas of my (?:last )?(?:training|knowledge)\b"),
    C(r"\bup to my (?:last )?(?:training|knowledge)\b"),
    C(r"\bwhile specific details are (?:limited|scarce|not (?:extensively|widely) documented)\b"),
    C(r"\bbased on (?:the )?available information\b"),
    C(r"\bas of my (?:knowledge )?cutoff\b"),
    C(r"\bmaintains a low profile\b"),
    C(r"\bkeeps (?:his|her|their) personal life private\b"),
]))

_add(51, "Copula avoidance", _rx_fn([
    C(r"\b(?:serves|stands|functions|acts) as\b"),
    C(r"\brepresents (?:a|the)\b"),
    C(r"\bmarks (?:a|the)\b"),
    C(r"\bboasts\b"),
    C(r"\bfeatures (?:a|an|the|\d|several|many|numerous|multiple|various)\b"),
    C(r"\boffers a\b"),
    C(r"\brefers to\b"),
]))

_add(54, "Hedge stacking", _detect_hedge_stacking)
_add(55, "Contraction absence", _detect_contraction_absence)
_add(56, "Boldface overuse", _rx_fn([re.compile(r"\*\*[^*\n]+?\*\*")]))
_add(57, "Emoji", _rx_fn([_EMOJI_RE]))
_add(58, "Em-dash overuse", _detect_em_dash_paragraphs)
_add(59, "Title case in heading", _detect_title_case)
_add(60, "Curly quotation marks", lambda ctx: [m.span() for m in _CURLY_RE.finditer(ctx.masked)])
_add(61, "Hyphen for en dash in year range", _detect_years)

_add(63, "Placeholder text", _rx_fn([
    C(r"\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\](?![(\[])"),
    C(r"\[(?:person|company|client|place|source|name|product|city|country)\b[^\]\n]*\](?![(\[])"),
    re.compile(r"\[[A-Z][A-Z _]{2,}\](?![(\[])"),
    re.compile(r"\{\{[^{}\n]*\}\}"),
    re.compile(r"(?<![A-Za-z])[xX]{3,}(?![A-Za-z])"),
    C(r"lorem ipsum"),
]))

_add(64, "Chat reference-markup leak", _rx_fn([
    re.compile(r"\bcite(?:turn|start|nav)\w*"),
    re.compile(r"\boai_citation\w*"),
    re.compile(r"contentReference"),
    re.compile(r"navlist"),
    re.compile(r"【\d+†[^】\n]*】"),
]))

_add(65, "AI tracking parameter", _detect_utm)

_add(69, "Canonical marketing phrase", _rx_fn([
    C(r"\bunlocking (?:its |your |their |the )?full potential\b"),
    C(r"\bnavigating the complexities\b"),
    C(r"\ba testament to the (?:power|importance) of\b"),
    C(r"\bstaying ahead of the curve\b"),
    C(r"\bturning challenges into opportunities\b"),
    C(r"\btaking (?:\w+ )?to the next level\b"),
    C(r"\bharnessing the power of\b"),
    C(r"\bpaving the way for\b"),
    C(r"\bsaying goodbye to\b"),
    C(r"\bimagining a world where\b"),
]))

_add(70, "Decorative horizontal rules", _detect_horizontal_rules)
_add(71, "Degenerate repetition", _detect_degenerate)


def _dialect_fn(ctx):
    spans = rx_spans(ctx, [
        C(_lex(["genuinely", "fascinating", "nuanced", "thoughtfully", "refreshingly", "strikingly",
                "compellingly"])),
        C(r"\bquietly (?:powerful|profound|radical)\b"),
        C(r"\bdeeply (?:human|personal|felt|unsettling)\b"),
        C(r"\bresonates? deeply\b"),
        C(r"\bgame-chang\w*"),
        C(r"\bsupercharg\w*"),
        C(r"\bskyrocket\w*"),
        C(r"\bturbocharg\w*"),
        C(r"\brevolutioniz\w*"),
        C(r"\bdouble down on\b"),
        C(r"\bdive deep(?:er)? into\b"),
        C(r"\bunlock(?:s|ed|ing)? (?:the )?(?:power|potential|value)\b"),
        C(r"\btake\b[^.!?\n]{1,40}?\bto the next level\b"),
    ])
    return spans if len(spans) >= 2 else []


for _i, _entry in enumerate(_FAMILIES):
    if _entry[0] == 2:
        _FAMILIES[_i] = (2, "Model-dialect vocabulary", _dialect_fn)

_add(62, "Invisible or zero-width characters", None)  # character layer
_add(66, "Mixed-script homoglyphs", None)
_add(67, "Non-standard spaces", None)
_add(68, "Trailing or stray whitespace", None)

ADVICE = {4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68, 17}
DECISIVE = {13, 47, 48, 50, 62, 63, 64, 65, 66}
RHYTHM = {40, 44}
SHORT_FAMILIES = set(range(1, 40)) | set(range(47, 52)) | {69}
MACHINE_NUMBERS = {1, 2, 3, 4, 5, 6, 8, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26,
                   27, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 44, 46, 47, 48, 50, 51, 54, 55,
                   56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71}
SCORE_MOVING = MACHINE_NUMBERS - ADVICE

WEIGHT_DECISIVE = 16
WEIGHT_NORMAL = 10
WEIGHT_RHYTHM = 6


class Ctx:
    def __init__(self, window: str, masked: str):
        self.window = window
        self.masked = masked
        self.sents = sentence_spans(masked)
        self.paras = paragraph_spans(masked)
        self.words = sum(nw for _, _, nw in self.sents)


def band_for(score: int) -> str:
    for upper, name in BANDS:
        if score <= upper:
            return name
    return BANDS[-1][1]


def _slug(label: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", label.lower()).strip("_")


def run_patterns(window: str):
    """Return (ctx, findings) where findings is a list of dicts keyed by catalogue number."""
    masked = mask_markdown(window)
    ctx = Ctx(window, masked)
    findings = []

    for num, label, fn in _FAMILIES:
        if fn is None:
            continue
        spans = fn(ctx)
        spans = [sp for sp in spans if sp[1] > sp[0]]
        if spans:
            key = f"{num}_{_slug(label)}"
            if num == 17:
                key = "17_negative_parallelism" if label.startswith("Negative") else "17_tailing_negation"
            findings.append({"num": num, "key": key, "label": label, "spans": spans})

    # Character layer, computed on the window. Markdown regions that generate no findings
    # (code, quotes, tables, front matter) are excluded: masked positions differ from the window.
    def live(span):
        return masked[span[0]] == window[span[0]]

    inv, spc, _sep = char_layer(window)
    inv = [i for i in inv if live((i, i + 1))]
    spc = [i for i in spc if live((i, i + 1))]
    if inv:
        findings.append({"num": 62, "key": "62_invisible_or_zero_width_characters",
                         "label": "Invisible or zero-width characters", "spans": [(i, i + 1) for i in inv]})
    hg = [sp for sp in homoglyph_spans(window) if live(sp)]
    if hg:
        findings.append({"num": 66, "key": "66_mixed_script_homoglyphs",
                         "label": "Mixed-script homoglyphs", "spans": hg})
    if spc:
        findings.append({"num": 67, "key": "67_non_standard_spaces",
                         "label": "Non-standard spaces", "spans": [(i, i + 1) for i in spc]})
    tr = [sp for sp in trailing_spans(window) if live(sp)]
    if tr:
        findings.append({"num": 68, "key": "68_trailing_or_stray_whitespace",
                         "label": "Trailing or stray whitespace", "spans": tr})

    findings.sort(key=lambda f: f["num"])
    counts = {"invisible": len(inv), "nonstandard": len(spc), "homoglyph": len(hg)}
    return ctx, findings, counts


def score_from_findings(findings, words: int):
    fam = {f["num"] for f in findings if f["num"] in SCORE_MOVING}
    decisive = fam & DECISIVE
    raw = 0
    for n in fam:
        if n in DECISIVE:
            raw += WEIGHT_DECISIVE
        elif n in RHYTHM:
            raw += WEIGHT_RHYTHM
        else:
            raw += WEIGHT_NORMAL
    score = min(100, raw)

    # Caps.
    if fam and fam <= {40}:
        score = min(score, 20)
    elif fam and fam <= RHYTHM:
        score = min(score, 40)
    elif len(fam) == 1 and not decisive:
        score = min(score, 40)

    # Floors.
    if len(decisive) >= 2:
        score = max(score, 65)
    elif len(decisive) == 1:
        score = max(score, 45)
    if words < 120:
        k = len(fam & SHORT_FAMILIES)
        if k >= 3:
            score = max(score, 45)
        elif k >= 2:
            score = max(score, 25)
    if words >= 400:
        if len(fam) >= 6:
            score = max(score, 45)
        elif len(fam) >= 5:
            score = max(score, 25)
    return max(0, min(100, score)), fam


def confidence_for(words: int, fam_count: int):
    if words < 40:
        return "none", f"only {words} words; at least 40 are needed for a reading"
    if words < 120:
        return "low", f"only {words} words; under 120 words is a weak basis"
    if words < 300 and fam_count == 1:
        return "low", "under 300 words with only one pattern family fired"
    if words < 300:
        return "moderate", f"{words} words; 300 or more give a firmer reading"
    return "high", ""


def build_report(text: str, ci: bool):
    window = text[:WINDOW]
    truncated = len(text) > WINDOW
    ctx, findings, counts = run_patterns(window)
    score, fam = score_from_findings(findings, ctx.words)
    conf, reason = confidence_for(ctx.words, len(fam))

    report = {}
    for f in findings:
        samples = [excerpt(window, s, e) for s, e in f["spans"][:3]]
        report[f["key"]] = {"label": f["label"], "count": len(f["spans"]), "samples": samples}

    metrics = {
        "scanned_chars": len(window),
        "truncated": truncated,
        "ai_tell_score": score,
        "ai_tell_band": band_for(score),
        "confidence": conf,
        "confidence_reason": reason,
        "patterns_flagged": len(findings),
        "invisible_chars": counts["invisible"],
        "nonstandard_spaces": counts["nonstandard"],
        "homoglyphs": counts["homoglyph"],
        "word_count": ctx.words,
        "sentence_count": len(ctx.sents),
    }
    if ci:
        if len(ctx.sents) < 4:
            metrics["score_ci"] = None
            metrics["score_ci_note"] = "too few sentences (fewer than four) for an interval"
        else:
            spread = {"none": 15, "low": 12, "moderate": 8, "high": 5}[conf]
            low = max(0, score - spread)
            high = min(100, score + spread)
            metrics["score_ci"] = [low, high]
            metrics["score_ci_note"] = ("interval from the confidence level (plus or minus "
                                        f"{spread}), not a resampling; it is a rough guide")
    report["_metrics"] = metrics
    return report


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _err(message: str, code: int) -> int:
    sys.stderr.write(json.dumps({"error": message}, ensure_ascii=False) + "\n")
    return code


def _write_out(data: str) -> None:
    sys.stdout.buffer.write(data.encode("utf-8"))
    sys.stdout.flush()


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    clean = False
    ci = False
    operands = []
    end_of_options = False
    for arg in argv:
        if end_of_options:
            operands.append(arg)
            continue
        if arg == "--":
            end_of_options = True
            continue
        if arg in ("-h", "--help"):
            _write_out(USAGE)
            return 0
        if arg == "--clean":
            clean = True
            continue
        if arg == "--ci":
            ci = True
            continue
        if arg.startswith("-"):
            return _err(f"unknown option '{arg}'; see --help", 2)
        operands.append(arg)

    if len(operands) >= 2:
        sys.stderr.write(f"detect.py: note: several files given; only the last one is scanned "
                         f"({operands[-1]}). Not scanned: {', '.join(operands[:-1])}\n")
    path = operands[-1] if operands else None

    try:
        text = load_text(path)
    except InputProblem as exc:
        return _err(exc.message if exc.kind == "read" else "empty input", 1)

    if clean:
        _write_out(cleanup_text(text))
        return 0

    report = build_report(text, ci)
    _write_out(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except SystemExit:
        raise
    except BaseException:  # never print a traceback
        sys.stderr.write(json.dumps({"error": "cannot read input: internal error"}) + "\n")
        sys.exit(1)
