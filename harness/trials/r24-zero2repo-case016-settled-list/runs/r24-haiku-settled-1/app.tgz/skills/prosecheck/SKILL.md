---
name: prosecheck
description: Rewrite prose flagged by prosecheck, or humanize a draft, when the user asks in plain language ("prosecheck this", "humanize this").
---

# prosecheck rewrite guidance

Use this only when the user asks for a deep rewrite of prose. The detector reports patterns; the rewrite is done by you.

1. Run the bundled detector on the file: `python3 scripts/detect.py <file>` from the plugin root.
2. Fix only the flagged spans. Keep the author's meaning, numbers, dates, names, quotations, and citations.
3. Vary sentence length. Do not replace one banned word with another stock phrase.
4. Do not touch code, configuration, commit messages, or chat replies.
5. Do not mention the score, the band, or the tool in the rewritten text.
