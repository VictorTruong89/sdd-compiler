#!/usr/bin/env node
'use strict';
// Session-start hook: places the writing contract (and a first-run welcome) into the session.
const c = require('./lib/prosecheck-common.js');

function main() {
  c.readStdinJSON();
  const existed = c.flagExists();
  if (!existed) {
    // Fresh install: store the effective level so later hooks see it, and show the welcome once.
    c.writeLevel(c.effectiveLevel());
  }
  c.pruneLedgers();
  const level = c.effectiveLevel();
  if (level === 'off') return;
  const parts = [];
  if (!existed) parts.push(c.welcomeText());
  parts.push(c.contractForSession(level));
  process.stdout.write(parts.join('\n\n') + '\n');
}

try {
  main();
} catch (_) {
  /* never fail the host session */
}
process.exitCode = 0;
