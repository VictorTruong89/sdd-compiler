#!/usr/bin/env node
'use strict';
// Post-tool-use hook: scores a just-saved prose file and nudges when it is flagged.
const fs = require('fs');
const path = require('path');
const c = require('./lib/prosecheck-common.js');

const SKIP_SEGMENTS = new Set(['node_modules', '.git']);

function collectPaths(payload) {
  const ti = payload.tool_input && typeof payload.tool_input === 'object' ? payload.tool_input : {};
  const tool = String(payload.tool_name || '');
  const body = typeof ti.command === 'string' ? ti.command : (typeof ti.input === 'string' ? ti.input : '');
  let found = [];
  if (tool === 'apply_patch' || /^\*\*\* /m.test(body)) {
    const re = /^\*\*\*\s+(?:Add File|Update File|Move to)\s*:\s*(.+?)\s*$/gm;
    let m;
    while ((m = re.exec(body)) !== null) found.push(m[1]);
  } else {
    for (const key of ['notebook_path', 'file_path']) {
      if (typeof ti[key] === 'string' && ti[key].trim()) {
        found.push(ti[key]);
        break;
      }
    }
  }
  const seen = new Set();
  const out = [];
  for (const p of found) {
    const t = p.trim();
    if (!t || seen.has(t)) continue;
    seen.add(t);
    out.push(t);
    if (out.length >= c.PATCH_MAX_PATHS) break;
  }
  return out;
}

function isSkipped(abs, root) {
  const parts = abs.split(/[\\/]+/);
  if (parts.some((p) => SKIP_SEGMENTS.has(p))) return true;
  const rootWithSep = root.endsWith(path.sep) ? root : root + path.sep;
  if (abs === root || abs.startsWith(rootWithSep)) return true;
  const base = path.basename(abs).toLowerCase();
  const ext = path.extname(base);
  if (c.INSTRUCTION_NAMES.has(base)) return true;
  const stem = ext ? base.slice(0, -ext.length) : base;
  if (c.INSTRUCTION_STEMS.has(stem) && !c.PLAIN_EXTS.has(ext) && !c.ZIP_EXTS.has(ext) && ext !== c.NOTEBOOK_EXT) {
    return true;
  }
  return false;
}

function scoreFile(abs, level, python, det) {
  const base = path.basename(abs);
  const ext = path.extname(abs).toLowerCase();
  const { cap, kb, timeout } = c.capFor(ext);
  if (c.BINARY_EXTS.has(ext)) {
    return { record: { base, state: 'binary' } };
  }
  let st;
  try {
    st = fs.statSync(abs);
  } catch (_) {
    return { record: { base, state: 'failed', reason: 'unreadable: no file at that path' } };
  }
  if (!st.isFile()) return null;
  if (st.size > cap) {
    return { record: { base, state: 'skipped', reason: `over ${kb} KB`, cap: kb } };
  }
  if (!python) {
    return { record: { base, state: 'failed', reason: 'Python not found' } };
  }
  if (!det) {
    return { record: { base, state: 'failed', reason: 'bundled detector not found' } };
  }
  const r = c.runDetector(python, det, ['--', abs], '', timeout);
  if (r.timedOut) {
    return { record: { base, state: 'failed', reason: `detector timed out after ${timeout / 1000} seconds` } };
  }
  if (r.status !== 0) {
    const err = c.lastErrorText(r.stderr);
    return { record: { base, state: 'failed', reason: `no usable result (exit ${r.status}${err ? ': ' + err : ''})` } };
  }
  const out = r.stdout.trim();
  if (!out) {
    return { record: { base, state: 'failed', reason: 'no output from the detector' } };
  }
  let report;
  try {
    report = JSON.parse(out);
  } catch (_) {
    return { record: { base, state: 'failed', reason: 'detector output is not a structured report' } };
  }
  const metrics = report && report._metrics;
  if (!metrics || typeof metrics.ai_tell_score !== 'number') {
    return { record: { base, state: 'failed', reason: 'report has no numeric score' } };
  }
  const labels = c.orderedLabels(report).slice(0, c.LABEL_CAP);
  const score = metrics.ai_tell_score;
  const band = String(metrics.ai_tell_band || 'clean');
  const phrase = c.hookPhrase(band);
  const truncated = !!metrics.truncated;
  const flagged = score > c.THRESHOLD[level];
  const record = { base, state: 'scored', score, band, phrase, labels, flagged, truncated };
  let nudge = null;
  if (flagged) {
    const coverage = truncated ? `, first ${c.WINDOW_TEXT} characters only` : '';
    const labelText = labels.length ? labels.join('; ') : 'none';
    nudge = `prosecheck: ${base} ${phrase} (score ${score}, band ${band}${coverage}). ` +
      `Flagged: ${labelText}. Please fix the flagged spans in this file.`;
  }
  return { record, nudge };
}

function main() {
  const payload = c.readStdinJSON();
  const level = c.effectiveLevel();
  if (level === 'off' || level === 'lite') return;
  const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd();
  const root = path.resolve(c.pluginRoot());
  const sid = typeof payload.session_id === 'string' ? payload.session_id : '';
  const paths = collectPaths(payload);
  if (!paths.length) return;

  const python = c.findPython();
  const det = c.detectorPath();
  const nudges = [];
  for (const typed of paths) {
    const abs = path.resolve(cwd, typed);
    const ext = path.extname(abs).toLowerCase();
    const eligible = c.PLAIN_EXTS.has(ext) || c.ZIP_EXTS.has(ext) || ext === c.NOTEBOOK_EXT || c.BINARY_EXTS.has(ext);
    if (!eligible) continue;
    if (isSkipped(abs, root)) continue;
    const result = scoreFile(abs, level, python, det);
    if (!result) continue;
    c.appendLedger(sid, result.record);
    if (result.nudge) nudges.push(result.nudge);
  }
  if (nudges.length) {
    c.emitJSON({
      hookSpecificOutput: {
        hookEventName: 'PostToolUse',
        additionalContext: nudges.join('\n'),
      },
    });
  }
}

module.exports = { collectPaths, isSkipped };

if (require.main === module) {
  try {
    main();
  } catch (_) {
    /* never fail the host */
  }
  process.exitCode = 0;
}
