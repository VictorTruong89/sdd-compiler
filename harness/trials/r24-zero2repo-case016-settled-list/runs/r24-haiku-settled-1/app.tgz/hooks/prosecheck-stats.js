#!/usr/bin/env node
'use strict';
// Stats hook: token figures and the session-prose score for the session transcript.
// The router in prosecheck-tracker.js calls statsReply(); run directly, this reads a prompt payload.
const fs = require('fs');
const path = require('path');
const c = require('./lib/prosecheck-common.js');

const PROSE_MIN = 200;   // the session-prose score is printed only above this many characters (PRD FP-06)
const PROSE_MAX = 40000; // the slice keeps the last 40,000 characters

function newestTranscript(root) {
  let best = null;
  const stack = [{ dir: root, depth: 0 }];
  let seen = 0;
  while (stack.length && seen < 5000) {
    const { dir, depth } = stack.pop();
    let entries = [];
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch (_) {
      continue;
    }
    for (const ent of entries) {
      const full = path.join(dir, ent.name);
      if (ent.isDirectory() && depth < 4) {
        stack.push({ dir: full, depth: depth + 1 });
      } else if (ent.isFile() && ent.name.endsWith('.jsonl')) {
        seen++;
        try {
          const mtime = fs.statSync(full).mtimeMs;
          if (!best || mtime > best.mtime) best = { file: full, mtime };
        } catch (_) { /* skip */ }
      }
    }
  }
  return best;
}

function parseTranscript(file) {
  const raw = fs.readFileSync(file, 'utf8');
  const ids = new Set();
  const usageById = new Map();
  let turns = 0;
  let outTokens = 0;
  let cacheTokens = 0;
  const texts = [];
  const seenText = new Set();
  for (const line of raw.split('\n')) {
    if (!line.trim()) continue;
    let row;
    try { row = JSON.parse(line); } catch (_) { continue; }
    if (!row || row.type !== 'assistant' || !row.message || typeof row.message !== 'object') continue;
    const msg = row.message;
    const id = typeof msg.id === 'string' && msg.id ? msg.id : null;
    if (id) {
      if (ids.has(id)) {
        // Same message seen again (one row per content block): take its usage once.
        if (!usageById.get(id) && msg.usage) usageById.set(id, msg.usage);
      } else {
        ids.add(id);
        turns++;
        usageById.set(id, msg.usage || null);
      }
    } else {
      turns++;
      const u = msg.usage || null;
      if (u) {
        outTokens += Number(u.output_tokens) || 0;
        cacheTokens += Number(u.cache_read_input_tokens) || 0;
      }
    }
    if (Array.isArray(msg.content)) {
      for (const block of msg.content) {
        if (block && block.type === 'text' && typeof block.text === 'string') {
          const key = (id || '') + '\u0000' + block.text;
          if (!seenText.has(key)) {
            seenText.add(key);
            texts.push(block.text);
          }
        }
      }
    }
  }
  for (const u of usageById.values()) {
    if (!u) continue;
    outTokens += Number(u.output_tokens) || 0;
    cacheTokens += Number(u.cache_read_input_tokens) || 0;
  }
  return { turns, outTokens, cacheTokens, texts };
}

function proseSlice(texts) {
  let joined = texts.join('\n\n');
  joined = joined.replace(/```[\s\S]*?(?:```|$)/g, '\n').replace(/~~~[\s\S]*?(?:~~~|$)/g, '\n');
  const trimmed = joined.trim();
  return trimmed.length > PROSE_MAX ? trimmed.slice(-PROSE_MAX).trim() : trimmed;
}

function scoreProse(text) {
  const python = c.findPython();
  const det = c.detectorPath();
  if (!python || !det) return null;
  const r = c.runDetector(python, det, [], text, 30000);
  if (r.status !== 0) return null;
  try {
    const obj = JSON.parse(r.stdout);
    const s = obj && obj._metrics && obj._metrics.ai_tell_score;
    return typeof s === 'number' ? s : null;
  } catch (_) {
    return null;
  }
}

function statsReply(payload) {
  const level = c.effectiveLevel();
  const named = typeof payload.transcript_path === 'string' && payload.transcript_path.trim()
    ? payload.transcript_path.trim() : null;
  const projects = path.join(c.configDir(), 'projects');

  let chosen = null;
  if (named) {
    if (!c.isReadableFile(named)) {
      return `level: ${level}\nThe session transcript at ${named} could not be read, so no turn or token totals are available.`;
    }
    chosen = named;
    const newest = newestTranscript(projects);
    try {
      const namedMtime = fs.statSync(named).mtimeMs;
      if (newest && newest.mtime > namedMtime) chosen = newest.file;
    } catch (_) { /* keep named */ }
  } else {
    const newest = newestTranscript(projects);
    if (newest) chosen = newest.file;
  }
  if (!chosen) {
    return `level: ${level}\nNo session transcript was found, so no turn or token totals are available.`;
  }

  let parsed;
  try {
    parsed = parseTranscript(chosen);
  } catch (_) {
    return `level: ${level}\nThe session transcript could not be read, so no turn or token totals are available.`;
  }
  const lines = [
    `level: ${level}`,
    `assistant turns: ${parsed.turns}`,
    `output tokens: ${parsed.outTokens}`,
    `cache-read input tokens: ${parsed.cacheTokens}`,
  ];
  const slice = proseSlice(parsed.texts);
  if (slice.length > PROSE_MIN) {
    const score = scoreProse(slice);
    if (score !== null) lines.push(`session prose ai_tell_score: ${score}`);
  }
  return lines.join('\n');
}

module.exports = { statsReply, parseTranscript, proseSlice, newestTranscript };

if (require.main === module) {
  try {
    const payload = c.readStdinJSON();
    c.emitJSON(c.blockDecision(statsReply(payload)));
  } catch (_) {
    /* never fail the host */
  }
  process.exitCode = 0;
}
