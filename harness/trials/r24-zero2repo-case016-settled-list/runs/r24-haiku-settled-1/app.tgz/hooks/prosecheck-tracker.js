#!/usr/bin/env node
'use strict';
// Prompt-submit hook: routes /prosecheck commands, handles the stop phrases, and adds the
// per-prompt reminder for ordinary prompts.
const fs = require('fs');
const path = require('path');
const c = require('./lib/prosecheck-common.js');
const stats = require('./prosecheck-stats.js');

const SUBCOMMANDS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];

function helpReply(level) {
  return [
    `prosecheck level: ${level}`,
    'Only prose deliverables follow the writing contract: code, commits, config, and chat are never touched.',
    'Commands (type each after the slash command):',
    '/prosecheck lite - turns on the writing contract without scoring saved files.',
    '/prosecheck full - the writing contract plus the saved-file guard, threshold 40 (default).',
    '/prosecheck strict - lowers the guard threshold to 20 and adds the cleanup scrub.',
    '/prosecheck off - disable scoring and the contract until you switch back on.',
    '/prosecheck on - re-enable the tool at the full level.',
    '/prosecheck status - the current level in one line.',
    '/prosecheck show - the files scored or skipped in this session, newest first.',
    '/prosecheck check <file> - score one file (a report only; it never rewrites the file).',
    '/prosecheck doctor - a health check of the install.',
    '/prosecheck stats - session token use and the score of the session prose.',
    '/prosecheck init - export the writing contract to ./AGENTS.md for agents other than Claude Code.',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
  ].join('\n');
}

function unquotePath(arg) {
  let s = String(arg || '').trim();
  if (s.startsWith('@')) s = s.slice(1).trim();
  if (s.length >= 2 && (s[0] === '"' || s[0] === "'") && s[s.length - 1] === s[0]) {
    s = s.slice(1, -1);
  }
  return s.trim();
}

function ledgerRows(sid) {
  const file = c.ledgerPath(sid);
  if (!fs.existsSync(file) || !c.ledgerIsFresh(file)) return [];
  return c.readLedger(file);
}

function showReply(sid) {
  const rows = ledgerRows(sid);
  if (!rows.length) {
    return 'nothing scored yet in this session. Rows appear after prose files, including .docx and .pdf deliverables, are saved.';
  }
  const lines = ['Files in this session, newest first:'];
  for (const r of rows.slice().reverse()) {
    let body;
    if (r.state === 'scored') {
      const cov = r.truncated ? `, first ${c.WINDOW_TEXT} characters only` : '';
      body = `${r.phrase} (score ${r.score}/${r.band}${cov})`;
      if (Array.isArray(r.labels) && r.labels.length) {
        const state = r.flagged ? 'flagged' : 'under threshold';
        body += ` - ${state}: ${r.labels.slice(0, c.LABEL_CAP).join('; ')}`;
      }
    } else if (r.state === 'skipped') {
      body = `not scored: over ${r.cap || 512} KB`;
    } else if (r.state === 'binary') {
      body = 'not re-scored (binary file)';
    } else {
      body = `not scored: ${r.reason || 'unknown reason'}`;
    }
    lines.push(`  ${r.base} - ${body}`);
  }
  return lines.join('\n');
}

function checkReply(arg, payload) {
  const typed = unquotePath(arg);
  if (!typed) {
    return 'usage: /prosecheck check <file>. Give the path of one prose file to score; the file is not changed.';
  }
  const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd();
  const abs = path.resolve(cwd, typed);
  const base = path.basename(abs);
  const ext = path.extname(abs).toLowerCase();
  let st;
  try {
    st = fs.statSync(abs);
  } catch (_) {
    return `cannot read ${typed}: no file at that path.`;
  }
  if (st.isDirectory()) return `${typed} is not a file.`;
  if (!st.isFile()) return `${typed} is not a file.`;
  if (c.BINARY_EXTS.has(ext)) {
    return `${base}: no readable text (${ext} files are not scored).`;
  }
  const { cap, kb, timeout } = c.capFor(ext);
  if (st.size > cap) {
    return `${base} is over ${kb} KB, so it was not scored.`;
  }
  const python = c.findPython();
  const det = c.detectorPath();
  if (!python || !det) {
    return `${base}: detector unavailable (python not found), so nothing was scored.`;
  }
  const r = c.runDetector(python, det, ['--', abs], '', timeout);
  if (r.timedOut) return `${base}: failed (the detector timed out).`;
  if (r.status !== 0) {
    const err = c.lastErrorText(r.stderr);
    return `${base}: failed (exit ${r.status})${err ? '. ' + err : '.'}`;
  }
  const out = r.stdout.trim();
  if (!out) return `${base}: no report (the detector printed nothing).`;
  let report;
  try {
    report = JSON.parse(out);
  } catch (_) {
    return 'no report: the detector printed text that is not a report.';
  }
  const m = report && report._metrics;
  if (!m || typeof m.ai_tell_score !== 'number') {
    return 'no report: the detector printed text that is not a report.';
  }
  const band = String(m.ai_tell_band);
  const lines = [`${base} - ${c.hookPhrase(band)} (score ${m.ai_tell_score}/100, band: ${band})`];
  const conf = String(m.confidence || 'none');
  let confLine = `confidence: ${conf}`;
  if (conf !== 'high' && m.confidence_reason) confLine += ` - ${m.confidence_reason}`;
  lines.push(confLine);
  if (m.truncated) lines.push(`coverage: first ${c.WINDOW_TEXT} characters only`);
  const countByLabel = {};
  for (const k of Object.keys(report)) {
    if (k !== '_metrics' && report[k] && typeof report[k].label === 'string') countByLabel[report[k].label] = report[k].count;
  }
  const tells = c.orderedLabels(report).slice(0, c.CHECK_LABEL_CAP)
    .map((label) => `${label} (x${countByLabel[label]})`);
  lines.push(`tells: ${tells.length ? tells.join('; ') : 'none'}`);
  lines.push('This is a report only; the file was not changed.');
  return lines.join('\n');
}

function doctorReply(form, level) {
  const lines = ['prosecheck doctor'];
  const modeOk = level !== 'off';
  lines.push(modeOk
    ? `mode: ${level} [OK]`
    : 'mode: off (not a fault of the install; saved files are not scored in this mode. Run /prosecheck on to turn it back on)');

  const det = c.detectorPath();
  lines.push(det ? `detector: bundled detector found at ${det} [OK]` : 'detector: bundled detector missing from the plugin tree');

  let pyOk = false;
  const python = c.findPython();
  let pyLine;
  if (!python) {
    pyLine = 'python not found: saved files are not re-scored until Python is available; the writing contract still applies to new prose.';
  } else if (!det) {
    pyLine = 'python: no bundled scorer to run, so no numeric score was produced';
  } else {
    const r = c.runDetector(python, det, [], 'This is a short check sentence. It only confirms that the scorer runs.', 30000);
    let numeric = false;
    try {
      const obj = JSON.parse(r.stdout);
      numeric = !!(obj && obj._metrics && typeof obj._metrics.ai_tell_score === 'number');
    } catch (_) { numeric = false; }
    if (numeric && r.status === 0) {
      pyOk = true;
      pyLine = 'python: ran the bundled scorer and got a numeric score [OK]';
    } else {
      pyLine = 'python: the bundled scorer returned no numeric score';
    }
  }
  lines.push(pyLine);

  const dir = c.configDir();
  let settingsOk = false;
  try {
    fs.mkdirSync(dir, { recursive: true });
    fs.accessSync(dir, fs.constants.W_OK);
    settingsOk = true;
  } catch (_) { settingsOk = false; }
  lines.push(settingsOk ? `settings: ${dir} is writable [OK]` : `settings: ${dir} is not writable`);

  const detOk = !!det;
  if (modeOk && detOk && pyOk && settingsOk) {
    lines.push(`prosecheck is active. Plain text up to 512 KB and archives up to 4 MB are scored, and the first ${c.WINDOW_TEXT} characters are read. Run ${form} show to see files that were only partly scanned or skipped.`);
  } else if (!modeOk && detOk && pyOk && settingsOk) {
    lines.push(`prosecheck is switched off. The install is healthy, but saved files are not scored in this mode. Run ${form} on to turn scoring back on.`);
  } else {
    lines.push('Some checks need attention. Fix the items above that are not marked [OK], then run /prosecheck doctor again.');
  }
  return lines.join('\n');
}

function initReply(form, level, payload) {
  const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd();
  if (level === 'off') {
    return `prosecheck is switched off, so nothing was written: no AGENTS.md and no Cursor rule. Run ${form} on to allow the export.`;
  }
  const out = [];
  const marker = '<!-- prosecheck:contract:start -->';
  const endMarker = '<!-- prosecheck:contract:end -->';
  const section = `${marker}\n## Prose contract (prosecheck)\n\n${c.contractBody(level, { exportMode: true })}\n${endMarker}\n`;
  const agents = path.join(cwd, 'AGENTS.md');
  let existing = null;
  let readFailed = false;
  try {
    existing = fs.readFileSync(agents, 'utf8');
  } catch (e) {
    if (e.code !== 'ENOENT') readFailed = true;
  }
  if (readFailed) {
    out.push('AGENTS.md: cannot read AGENTS.md, so the contract was not written.');
  } else if (existing !== null && (existing.includes(marker) || existing.includes('## Prose contract (prosecheck)'))) {
    out.push('AGENTS.md already contains the prosecheck contract; it was left unchanged.');
  } else {
    try {
      let next;
      if (existing === null) next = section;
      else next = existing + (existing.endsWith('\n') || existing === '' ? '' : '\n') + '\n' + section;
      fs.writeFileSync(agents, next);
      out.push('AGENTS.md: the prosecheck writing contract was written to AGENTS.md.');
    } catch (_) {
      out.push('AGENTS.md: cannot write AGENTS.md, so the contract was not written.');
    }
  }

  const ruleDst = path.join(cwd, '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(ruleDst)) {
    out.push('The Cursor rule prosecheck.mdc already exists; it was left unchanged.');
  } else {
    const ruleSrc = path.join(c.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc');
    try {
      const data = fs.readFileSync(ruleSrc);
      fs.mkdirSync(path.dirname(ruleDst), { recursive: true });
      fs.writeFileSync(ruleDst, data);
      out.push('The Cursor rule was copied to .cursor/rules/prosecheck.mdc.');
    } catch (_) {
      out.push('Cannot write .cursor/rules/prosecheck.mdc: the Cursor rule could not be written.');
    }
  }
  return out.join('\n');
}

function route(arg, form, payload) {
  const tokens = String(arg || '').trim().split(/\s+/).filter(Boolean);
  const sub = (tokens[0] || '').toLowerCase();
  const rest = tokens.slice(1).join(' ');
  const level = c.effectiveLevel();
  if (!sub || sub === 'help') return helpReply(level);
  if (sub === 'lite' || sub === 'full' || sub === 'strict') {
    c.writeLevel(sub);
    return `prosecheck level set to ${sub}.`;
  }
  if (sub === 'off') {
    c.writeLevel('off');
    return `prosecheck is now off. Saved files are not scored and the contract is not sent until you run ${form} on.`;
  }
  if (sub === 'on') {
    c.writeLevel('full');
    return 'prosecheck is on (full): the writing contract is sent and saved prose files are scored.';
  }
  if (sub === 'status') {
    return `prosecheck level: ${level}.`;
  }
  if (sub === 'show') return showReply(payload.session_id);
  if (sub === 'check') return checkReply(rest, payload);
  if (sub === 'doctor') return doctorReply(form, level);
  if (sub === 'stats') return stats.statsReply(payload);
  if (sub === 'init') return initReply(form, level, payload);
  return `unknown subcommand "${tokens[0]}". Valid subcommands: ${SUBCOMMANDS.join(', ')}. The stored level is unchanged.`;
}

function handle(payload) {
  const prompt = typeof payload.prompt === 'string' ? payload.prompt : '';
  const trimmed = prompt.trim();
  const cmd = /^\/prosecheck(?::prosecheck)?(?=\s|$)/i.exec(trimmed);
  if (cmd) {
    const form = cmd[0];
    const reply = route(trimmed.slice(form.length), form, payload);
    return c.blockDecision(reply);
  }
  const lower = trimmed.toLowerCase();
  if (lower === 'stop prosecheck' || lower === 'prosecheck off') {
    c.writeLevel('off');
    return c.blockDecision('prosecheck is now off. Saved files are not scored and the contract is not sent until you run /prosecheck on.');
  }
  if (lower.includes('stop prosecheck')) {
    c.writeLevel('off');
  }
  const level = c.effectiveLevel();
  if (level === 'off') return null;
  return {
    hookSpecificOutput: {
      hookEventName: 'UserPromptSubmit',
      additionalContext: `prosecheck level: ${level}. Prose deliverables follow the writing contract; code, config, and commits are untouched.`,
    },
  };
}

module.exports = { handle, route, helpReply, checkReply, doctorReply, showReply, initReply };

if (require.main === module) {
  try {
    const out = handle(c.readStdinJSON());
    if (out) c.emitJSON(out);
  } catch (_) {
    /* never fail the host */
  }
  process.exitCode = 0;
}
