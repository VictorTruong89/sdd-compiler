#!/usr/bin/env node
'use strict';
// Subagent-start hook: returns the same writing contract inside the subagent-start envelope.
const c = require('./lib/prosecheck-common.js');

function main() {
  c.readStdinJSON();
  const level = c.effectiveLevel();
  if (level === 'off') return;
  const out = {
    hookSpecificOutput: {
      hookEventName: 'SubagentStart',
      additionalContext: c.contractForSession(level),
    },
  };
  c.emitJSON(out);
}

try {
  main();
} catch (_) {
  /* never fail the host */
}
process.exitCode = 0;
