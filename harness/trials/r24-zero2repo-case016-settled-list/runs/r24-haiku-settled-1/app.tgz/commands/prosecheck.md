---
description: prosecheck controls - levels, status, show, check, doctor, stats, init, help
argument-hint: [lite|full|strict|off|on|status|show|check <file>|doctor|stats|init|help]
---
/prosecheck $ARGUMENTS
