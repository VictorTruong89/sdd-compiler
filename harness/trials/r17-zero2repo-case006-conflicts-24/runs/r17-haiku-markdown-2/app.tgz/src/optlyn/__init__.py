"""Optlyn: a minimal command line composition kit (core subset)."""

import sys

__all__ = [
    "Command", "Group", "Context", "Option", "Argument", "BadParameter",
    "Abort", "command", "group", "option", "argument",
]


class UsageError(Exception):
    exit_code = 2


class BadParameter(UsageError):
    def __init__(self, message, param=None):
        super().__init__(message)
        self.param = param


class Abort(Exception):
    exit_code = 1


class Context:
    def __init__(self, command, parent=None, prog_name=None, obj=None):
        self.command = command
        self.parent = parent
        self.prog_name = prog_name or command.name
        self.obj = obj if obj is not None else (parent.obj if parent else None)
        self.params = {}
        self.invoked_subcommand = None


class Option:
    def __init__(self, decls, type=str, default=None, required=False,
                 is_flag=False, flag_value=True, multiple=False, help=None):
        self.decls = list(decls)
        self.type = type
        self.default = default
        self.required = required
        self.is_flag = is_flag
        self.flag_value = flag_value
        self.multiple = multiple
        self.help = help
        self.names = [d for d in self.decls if d.startswith("-")]
        dest = next((d for d in self.decls if not d.startswith("-")), None)
        if dest is None:
            long_names = [n for n in self.names if n.startswith("--")]
            pick = (long_names or self.names)[0]
            dest = pick.lstrip("-").replace("-", "_")
        self.name = dest

    def convert(self, value):
        try:
            return self.type(value)
        except (ValueError, TypeError):
            raise BadParameter(
                f"Invalid value for '{'/'.join(self.names)}': {value!r}", self)

    def usage_name(self):
        return "/".join(self.names)


class Argument:
    def __init__(self, name, type=str, default=None, required=None, nargs=1,
                 help=None, metavar=None):
        self.name = name
        self.type = type
        self.default = default
        self.required = (default is None) if required is None else required
        self.nargs = nargs
        self.help = help
        self.metavar = metavar or name.upper()

    def convert(self, value):
        try:
            return self.type(value)
        except (ValueError, TypeError):
            raise BadParameter(f"Invalid value for '{self.name}': {value!r}", self)


def _key(name):
    name = name.lower()
    for suffix in ("_command", "_cmd", "_group", "_grp"):
        if name.endswith(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


class Command:
    def __init__(self, name=None, callback=None, help=None, short_help=None,
                 params=None, add_help_option=True, no_args_is_help=False,
                 deprecated=False, hidden=False, epilog=None):
        self.callback = callback
        self.name = name or (_key(callback.__name__) if callback else None)
        self.help = help if help is not None else (
            (callback.__doc__ or "").split("\f")[0].strip() if callback else "")
        self.short_help = short_help
        self.params = list(params or [])
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.deprecated = deprecated
        self.hidden = hidden
        self.epilog = epilog

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    def get_help(self, prog):
        opts = [p for p in self.params if isinstance(p, Option)]
        args = [p for p in self.params if isinstance(p, Argument)]
        usage = f"Usage: {prog} [OPTIONS]"
        for a in args:
            usage += f" {a.metavar}" if a.required else f" [{a.metavar}]"
        lines = [usage, ""]
        if self.help:
            lines += [self.help, ""]
        if args and any(a.help for a in args):
            lines.append("Positional arguments:")
            for a in args:
                if a.help:
                    lines.append(f"  {a.metavar}  {a.help}")
            lines.append("")
        lines.append("Options:")
        if self.add_help_option:
            lines.append("  --help  Show this message and exit.")
        for o in opts:
            entry = f"  {o.usage_name()}"
            if o.help:
                entry += f"  {o.help}"
            lines.append(entry)
        if isinstance(self, Group) and self.commands:
            lines += ["", "Commands:"]
            for n, c in sorted(self.commands.items()):
                if not c.hidden:
                    lines.append(f"  {n}  {c.short_help or _first_sentence(c.help)}")
        if self.epilog:
            lines += ["", self.epilog]
        return "\n".join(lines) + "\n"

    def main(self, args=None, prog_name=None, standalone_mode=True, obj=None, **extra):
        if args is None:
            args = sys.argv[1:]
        prog = prog_name or (sys.argv[0].split("/")[-1] if sys.argv else "cli")
        try:
            ctx = Context(self, prog_name=prog, obj=obj)
            rv = self._run(ctx, list(args))
        except _Exit as exc:
            if not standalone_mode:
                return None
            sys.exit(exc.code)
        except (UsageError, Abort) as exc:
            if not standalone_mode:
                raise
            msg = str(exc)
            if isinstance(exc, UsageError):
                sys.stderr.write(f"Usage error: {msg}\n")
            else:
                sys.stderr.write(f"Aborted: {msg}\n")
            sys.exit(exc.exit_code)
        if standalone_mode:
            sys.exit(0)
        return rv

    def _parse_params(self, ctx, tokens, stop_at_positional=False):
        """Parse options and arguments for this command; returns leftover tokens."""
        opts = [p for p in self.params if isinstance(p, Option)]
        arguments = [p for p in self.params if isinstance(p, Argument)]
        by_name = {n: o for o in opts for n in o.names}
        values = {}
        positional = []
        i = 0
        while i < len(tokens):
            tok = tokens[i]
            if tok == "--":
                positional.extend(tokens[i + 1:])
                break
            if stop_at_positional and not (tok.startswith("-") and tok != "-"):
                # Groups: the first positional token names the subcommand.
                positional.extend(tokens[i:])
                break
            if tok in ("--help", "-h") and self.add_help_option:
                sys.stdout.write(self.get_help(ctx.prog_name))
                raise _Exit(0)
            if tok.startswith("-") and tok != "-":
                if "=" in tok and tok.startswith("--"):
                    name, val = tok.split("=", 1)
                else:
                    name, val = tok, None
                opt = by_name.get(name)
                if opt is None:
                    raise UsageError(f"No such option: {name}")
                if opt.is_flag:
                    values[opt.name] = opt.flag_value
                else:
                    if val is None:
                        i += 1
                        if i >= len(tokens):
                            raise UsageError(f"Option {name} requires an argument.")
                        val = tokens[i]
                    conv = opt.convert(val)
                    if opt.multiple:
                        values.setdefault(opt.name, []).append(conv)
                    else:
                        values[opt.name] = conv
            else:
                positional.append(tok)
            i += 1
        for opt in opts:
            if opt.name not in values:
                if opt.required:
                    raise UsageError(f"Missing option '{opt.usage_name()}'.")
                d = opt.default
                if opt.multiple and d is None:
                    d = ()
                values[opt.name] = d() if callable(d) else d
            elif opt.multiple:
                values[opt.name] = tuple(values[opt.name])
        leftover = []
        for arg in arguments:
            if arg.nargs == -1:
                vals = [arg.convert(t) for t in positional]
                positional = []
                values[arg.name] = tuple(vals)
                continue
            if not positional:
                if arg.required:
                    raise UsageError(f"Missing argument '{arg.name}'.")
                values[arg.name] = arg.default
                continue
            values[arg.name] = arg.convert(positional.pop(0))
        leftover = positional
        ctx.params.update(values)
        return leftover

    def _run(self, ctx, tokens):
        if not tokens and self.no_args_is_help:
            sys.stderr.write(self.get_help(ctx.prog_name))
            raise UsageError("Missing arguments.")
        leftover = self._parse_params(ctx, tokens)
        if leftover:
            raise UsageError(f"Got unexpected extra argument(s): {' '.join(leftover)}")
        if self.deprecated:
            sys.stderr.write(f"DeprecationWarning: The command '{self.name}' is deprecated.\n")
        kwargs = {p.name: ctx.params.get(p.name) for p in self.params
                  if isinstance(p, (Option, Argument))}
        return self.callback(**kwargs)


class _Exit(Exception):
    def __init__(self, code):
        self.code = code


def _first_sentence(text):
    text = text.strip()
    if not text:
        return ""
    return text.split(".")[0] + ("." if "." in text else "")


class Group(Command):
    def __init__(self, name=None, callback=None, chain=False,
                 invoke_without_command=False, **kwargs):
        super().__init__(name=name, callback=callback, **kwargs)
        self.commands = {}
        self.chain = chain
        self.invoke_without_command = invoke_without_command
        self.no_args_is_help = kwargs.get("no_args_is_help",
                                          not invoke_without_command)

    def add_command(self, cmd, name=None):
        if self.chain and isinstance(cmd, Group):
            raise TypeError("Cannot nest a group under a chaining group.")
        self.commands[name or cmd.name] = cmd

    def command(self, name=None, **kwargs):
        def deco(f):
            cmd = command(name, **kwargs)(f)
            self.add_command(cmd)
            return cmd
        return deco

    def group(self, name=None, **kwargs):
        def deco(f):
            cmd = group(name, **kwargs)(f)
            self.add_command(cmd)
            return cmd
        return deco

    def get_command(self, ctx, name):
        return self.commands.get(name)

    def list_commands(self, ctx):
        return sorted(self.commands)

    def _run(self, ctx, tokens):
        if not tokens and self.no_args_is_help:
            sys.stderr.write(self.get_help(ctx.prog_name))
            raise UsageError("Missing command.")
        leftover = self._parse_params(ctx, tokens, stop_at_positional=True)
        # The first leftover token that is not an option names the subcommand.
        if not leftover:
            if self.invoke_without_command:
                return self._invoke_group_callback(ctx, None)
            raise UsageError("Missing command.")
        name, rest = leftover[0], leftover[1:]
        cmd = self.get_command(ctx, name)
        if cmd is None:
            raise UsageError(f"No such command '{name}'.")
        ctx.invoked_subcommand = name
        self._invoke_group_callback(ctx, name)
        child_ctx = Context(cmd, parent=ctx, prog_name=ctx.prog_name, obj=ctx.obj)
        return cmd._run(child_ctx, rest)

    def _invoke_group_callback(self, ctx, sub):
        kwargs = {p.name: ctx.params.get(p.name) for p in self.params
                  if isinstance(p, (Option, Argument))}
        if self.callback is None:
            return None
        return self.callback(**kwargs)


class CommandCollection(Group):
    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name=name, **kwargs)
        for src in sources or []:
            for n, c in src.commands.items():
                self.commands[n] = c


def _wrap_callback_params(f):
    params = getattr(f, "__optlyn_params__", [])
    if hasattr(f, "__optlyn_params__"):
        del f.__optlyn_params__
    return params


def _attach(f, param):
    if not hasattr(f, "__optlyn_params__"):
        f.__optlyn_params__ = []
    f.__optlyn_params__.insert(0, param)
    return f


def option(*decls, cls=None, **attrs):
    def deco(f):
        return _attach(f, (cls or Option)(decls, **attrs))
    return deco


def argument(name, cls=None, **attrs):
    def deco(f):
        return _attach(f, (cls or Argument)(name, **attrs))
    return deco


def command(name=None, cls=None, **attrs):
    def deco(f):
        params = _wrap_callback_params(f)
        cmd_name = name if isinstance(name, str) else None
        return (cls or Command)(name=cmd_name, callback=f, params=params, **attrs)
    if callable(name) and not isinstance(name, str):
        f, name = name, None
        return deco(f)
    return deco


def group(name=None, cls=None, **attrs):
    def deco(f):
        params = _wrap_callback_params(f)
        grp_name = name if isinstance(name, str) else None
        return (cls or Group)(name=grp_name, callback=f, params=params, **attrs)
    if callable(name) and not isinstance(name, str):
        f, name = name, None
        return deco(f)
    return deco
