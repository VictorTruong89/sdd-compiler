import os

import pytest

from optlyn import (
    Abort,
    Choice,
    IntRange,
    argument,
    command,
    group,
    option,
)
from optlyn.testing import CliRunner


@pytest.fixture
def runner():
    return CliRunner()


def test_command_name_derivation():
    @command()
    def hello_world_command():
        pass

    assert hello_world_command.name == "hello-world"


def test_options_arguments_and_nargs(runner):
    @command()
    @option("-n", "--count", type=int, default=1)
    @option("--shout/--quiet", default=False)
    @option("-v", count=True)
    @argument("name")
    @argument("extra", nargs=-1)
    def hello(count, shout, v, name, extra):
        print(count, shout, v, name, extra)

    res = runner.invoke(hello, ["-n", "3", "--shout", "-vv", "bob", "x"])
    assert res.exit_code == 0
    assert res.output == "3 True 2 bob ('x',)\n"


def test_help_exit_zero_and_usage_error_two(runner):
    @command()
    @option("--a")
    def cmd(a):
        print("ran")

    help_res = runner.invoke(cmd, ["--help"])
    assert help_res.exit_code == 0
    assert "Usage:" in help_res.output
    assert "ran" not in help_res.output

    bad = runner.invoke(cmd, ["--nope"])
    assert bad.exit_code == 2
    assert "No such option" in bad.output


def test_group_dispatch_and_missing_command(runner):
    @group()
    @option("--debug", is_flag=True)
    def cli(debug):
        print("group", debug)

    @cli.command("sub")
    @option("--mode", type=Choice(["a", "b"]))
    def sub(mode):
        print("sub", mode)

    res = runner.invoke(cli, ["--debug", "sub", "--mode", "a"])
    assert res.exit_code == 0
    assert res.output == "group True\nsub a\n"

    empty = runner.invoke(cli, [])
    assert empty.exit_code == 2


def test_abort_is_exit_one(runner):
    @command()
    def boom():
        raise Abort()

    res = runner.invoke(boom, [])
    assert res.exit_code == 1
    assert "Aborted!" in res.output


def test_int_range_clamp(runner):
    @command()
    @option("--ic", type=IntRange(1, 5, max_open=True, clamp=True))
    def cmd(ic):
        print(ic)

    res = runner.invoke(cmd, ["--ic", "5"])
    assert res.output == "4\n"


def test_environment_and_auto_prefix(runner):
    @command()
    @option("--one")
    def cmd(one):
        print(one)

    res = runner.invoke(cmd, [], env={"TOOL_ONE": "x"}, auto_envvar_prefix="TOOL")
    assert res.output == "x\n"


def test_feature_switch_winner(runner):
    @command()
    @option("--a", "feature", is_flag=True, flag_value="A")
    @option("--b", "feature", is_flag=True, flag_value="B", default=False)
    def cmd(feature):
        print(feature)

    assert runner.invoke(cmd, ["--a"]).output == "A\n"


def test_chain_results(runner):
    @group(chain=True)
    def pipe():
        pass

    @pipe.command()
    @argument("v")
    def add(v):
        return ("add", v)

    @pipe.command()
    @argument("v")
    def mul(v):
        return ("mul", v)

    @pipe.result_callback()
    def results(values, **kwargs):
        print(values)

    res = runner.invoke(pipe, ["add", "1", "mul", "2"])
    assert res.output == "[('add', '1'), ('mul', '2')]\n"


def test_isolated_filesystem_removes_directory(runner):
    with runner.isolated_filesystem() as path:
        assert os.path.isdir(path)
    assert not os.path.exists(path)
