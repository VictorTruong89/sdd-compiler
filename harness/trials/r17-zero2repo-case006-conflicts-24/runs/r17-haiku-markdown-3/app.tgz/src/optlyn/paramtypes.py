"""Parameter types and conversion (FP-05, FP-09)."""

import datetime as _dt
import enum
import os
import pathlib
import uuid as _uuid

from .exceptions import BadParameter


class ParamType:
    """Base class for parameter types."""

    name = "text"
    is_composite = False
    envvar_list_splitter = None

    def __call__(self, value, param=None, ctx=None):
        if value is None:
            return None
        return self.convert(value, param, ctx)

    def convert(self, value, param, ctx):
        return value

    def get_metavar(self, param):
        return None

    def get_missing_message(self, param):
        return None

    def shell_complete(self, ctx, param, incomplete):
        return []

    def split_envvar_value(self, rv):
        return rv.split()

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def __repr__(self):
        return self.name.upper()


class _StringType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        return str(value)


class _IntType(ParamType):
    name = "integer"

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            return int(str(value).strip(), 10)
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class _FloatType(ParamType):
    name = "float"

    def convert(self, value, param, ctx):
        if isinstance(value, float):
            return value
        try:
            return float(value)
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class _BoolType(ParamType):
    name = "boolean"

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class _UUIDType(ParamType):
    name = "uuid"

    def convert(self, value, param, ctx):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value).strip())
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


class _UnprocessedType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        return value


STRING = _StringType()
INT = _IntType()
FLOAT = _FloatType()
BOOL = _BoolType()
UUID = _UUIDType()
UNPROCESSED = _UnprocessedType()


class FuncParamType(ParamType):
    """Wraps a plain conversion function ``f(token) -> value``."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text").lower()

    def convert(self, value, param, ctx):
        if not isinstance(value, str):
            return value
        try:
            return self.func(value)
        except ValueError as exc:
            self.fail(str(exc) or f"{value!r} is not valid.", param, ctx)


def convert_type(ty, default=None):
    """Turn whatever the author passed as ``type`` into a ParamType.

    When ``ty`` is None, the type is inferred from ``default``.
    """
    if ty is None and default is not None and not callable(default):
        guessed = default
        if isinstance(guessed, (tuple, list)):
            if guessed:
                guessed = guessed[0]
        if isinstance(guessed, bool):
            return BOOL
        if isinstance(guessed, int):
            return INT
        if isinstance(guessed, float):
            return FLOAT
        return STRING
    if ty is None:
        return STRING
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    if ty is str:
        return STRING
    if ty is int:
        return INT
    if ty is float:
        return FLOAT
    if ty is bool:
        return BOOL
    if isinstance(ty, type) and ty is _uuid.UUID:
        return UUID
    if isinstance(ty, (tuple, list)):
        return Tuple(ty)
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"Unsupported type: {ty!r}")


class Choice(ParamType):
    name = "choice"

    def __init__(self, choices, case_sensitive=None):
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.enum = choices
            self.choices = list(choices.__members__.values())
            self._names = list(choices.__members__.keys())
            # Enumeration members match ignoring case unless the author says otherwise.
            self.case_sensitive = False if case_sensitive is None else case_sensitive
        else:
            self.enum = None
            self.choices = list(choices)
            self._names = [str(c) for c in self.choices]
            self.case_sensitive = True if case_sensitive is None else case_sensitive

    def get_metavar(self, param):
        return "[" + "|".join(str(n) for n in self._names) + "]"

    def _normalize(self, text):
        return text if self.case_sensitive else text.casefold()

    def convert(self, value, param, ctx):
        if self.enum is not None and isinstance(value, self.enum):
            return value
        if not isinstance(value, str):
            for original in self.choices:
                if original == value:
                    return original
            self.fail(f"{value!r} is not one of {', '.join(map(str, self._names))}.", param, ctx)
        normed = self._normalize(_normalize_token(value, ctx))
        for name, original in zip(self._names, self.choices):
            if self._normalize(name) == normed:
                return original
        choices_str = ", ".join(repr(n) for n in self._names)
        self.fail(f"{value!r} is not {choices_str}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        from .completion import CompletionItem

        out = []
        for name in self._names:
            cmp_name = self._normalize(name)
            cmp_inc = self._normalize(incomplete)
            if cmp_name.startswith(cmp_inc):
                out.append(CompletionItem(name))
        return out


def _normalize_token(value, ctx):
    if ctx is not None:
        func = ctx.token_normalize_func
        if func is not None:
            return func(value)
    return value


DEFAULT_DATETIME_FORMATS = [
    "%Y-%m-%d",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M:%S",
]


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(DEFAULT_DATETIME_FORMATS)

    def get_metavar(self, param):
        return None

    def convert(self, value, param, ctx):
        if isinstance(value, _dt.datetime):
            return value
        matched = None
        for fmt in self.formats:
            try:
                matched = _dt.datetime.strptime(str(value).strip(), fmt)
            except ValueError:
                continue
        if matched is None:
            self.fail(f"{value!r} does not match the formats {', '.join(self.formats)}.", param, ctx)
        return matched


class _RangeMixin:
    def _check(self, rv, param, ctx):
        if self.min is not None:
            if self.min_open:
                if not rv > self.min:
                    if self.clamp:
                        return self.min + self._step
                    self.fail(f"{rv} is not in the range {self._range_text()}.", param, ctx)
            elif rv < self.min:
                if self.clamp:
                    return self.min
                self.fail(f"{rv} is not in the range {self._range_text()}.", param, ctx)
        if self.max is not None:
            if self.max_open:
                if not rv < self.max:
                    if self.clamp:
                        return self.max - self._step
                    self.fail(f"{rv} is not in the range {self._range_text()}.", param, ctx)
            elif rv > self.max:
                if self.clamp:
                    return self.max
                self.fail(f"{rv} is not in the range {self._range_text()}.", param, ctx)
        return rv

    def _range_text(self):
        lo = "" if self.min is None else (f"{'>' if self.min_open else '>='}{self.min}")
        hi = "" if self.max is None else (f"{'<' if self.max_open else '<='}{self.max}")
        return " and ".join(x for x in (lo, hi) if x) or "any"


class IntRange(_RangeMixin, _IntType):
    name = "integer range"
    _step = 1

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param, ctx):
        rv = _IntType.convert(self, value, param, ctx)
        return self._check(rv, param, ctx)


class FloatRange(_RangeMixin, _FloatType):
    name = "float range"
    _step = 0.0

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min_open or max_open):
            raise ValueError("Clamping is not supported for open bounds.")
        if min is not None and max is not None and min > max:
            raise ValueError("min bound must not exceed max bound.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param, ctx):
        rv = _FloatType.convert(self, value, param, ctx)
        return self._check(rv, param, ctx)


class Tuple(ParamType):
    name = "tuple"
    is_composite = True

    def __init__(self, types):
        self.types = [convert_type(t) for t in types]

    @property
    def arity(self):
        return len(self.types)

    def get_metavar(self, param):
        return " ".join(t.name.upper() for t in self.types)

    def convert(self, value, param, ctx):
        if not isinstance(value, (tuple, list)) or len(value) != len(self.types):
            self.fail(f"{value!r} must have {len(self.types)} items.", param, ctx)
        return tuple(t(v, param, ctx) for t, v in zip(self.types, value))


class File(ParamType):
    name = "filename"
    envvar_list_splitter = os.pathsep

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"Invalid file mode {mode!r}.")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def shell_complete(self, ctx, param, incomplete):
        from .completion import CompletionItem

        return [CompletionItem(incomplete, type="file")]

    def convert(self, value, param, ctx):
        from .termui import open_file

        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        lazy = self.lazy
        if lazy is None:
            lazy = self.mode not in ("r", "rb")
        try:
            return open_file(
                value,
                self.mode,
                self.encoding,
                self.errors,
                lazy=lazy,
                atomic=self.atomic,
            )
        except OSError as exc:
            self.fail(f"'{value}': {exc.strerror or exc}", param, ctx)

    def __repr__(self):
        return "FILENAME"


class Path(ParamType):
    name = "path"
    envvar_list_splitter = os.pathsep

    def __init__(
        self,
        exists=False,
        file_okay=True,
        dir_okay=True,
        writable=False,
        readable=True,
        resolve_path=False,
        allow_dash=False,
        path_type=None,
        executable=False,
    ):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def convert(self, value, param, ctx):
        rv = value
        is_dash = self.file_okay and self.allow_dash and rv in (b"-", "-")
        if not is_dash:
            if self.resolve_path:
                rv = os.path.realpath(os.path.expanduser(rv))
            try:
                os.stat(rv)
            except OSError:
                if not self.exists:
                    return self._result(rv)
                self.fail(f"{value!r} does not exist.", param, ctx)
            if not self.file_okay and not os.path.isdir(rv):
                self.fail(f"{value!r} is a file.", param, ctx)
            if not self.dir_okay and os.path.isdir(rv):
                self.fail(f"{value!r} is a directory.", param, ctx)
            if self.readable and not os.access(rv, os.R_OK):
                self.fail(f"{value!r} is not readable.", param, ctx)
            if self.writable and not os.access(rv, os.W_OK):
                self.fail(f"{value!r} is not writable.", param, ctx)
            if self.executable and not os.access(rv, os.X_OK):
                self.fail(f"{value!r} is not executable.", param, ctx)
        return self._result(rv)

    def shell_complete(self, ctx, param, incomplete):
        from .completion import CompletionItem

        if self.dir_okay and not self.file_okay:
            return [CompletionItem(incomplete, type="dir")]
        return [CompletionItem(incomplete, type="file")]

    def _result(self, rv):
        if self.path_type is pathlib.Path:
            return pathlib.Path(rv)
        return rv

    def __repr__(self):
        return "PATH"
