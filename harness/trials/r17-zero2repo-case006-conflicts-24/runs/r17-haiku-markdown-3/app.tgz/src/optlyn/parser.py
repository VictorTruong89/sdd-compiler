"""Token scanner for options and positional arguments (FP-01, FP-03, FP-04, FP-06)."""

from .exceptions import BadOptionUsage, NoSuchOption

PREFIX_CHARS = ("-", "/", "+")


def is_option_shaped(token, prefixes):
    return len(token) > 1 and token[0] in prefixes


class ScanResult:
    """Output of :func:`scan`."""

    def __init__(self):
        # list of (option, tokens, is_secondary); tokens are raw value strings
        self.hits = []
        # positional tokens in order
        self.positionals = []
        # group mode: name of the subcommand token and the tokens after it
        self.sub_name = None
        self.sub_rest = []


class OptionTable:
    """Maps option names (normalized when needed) to ``(option, is_secondary)``."""

    def __init__(self, normalize=None):
        self.normalize = normalize or (lambda s: s)
        self._map = {}
        # "-" is always a prefix; others are added only when an author declares them.
        self.prefixes = {"-"}

    def add(self, name, option, secondary=False):
        self._map[self.normalize(name)] = (option, secondary)
        self.prefixes.add(name[0])

    def get(self, name):
        return self._map.get(self.normalize(name))

    def __contains__(self, name):
        return self.get(name) is not None


def _takes_value(option):
    return not option.is_flag and not option.count


def _take_values(option, attached, tokens, pos, prefixes, ctx):
    """Collect the value tokens for one occurrence of ``option``.

    ``attached`` is a value already present in the same token (or None). Returns
    ``(values, new_pos)``.
    """
    if option.is_optional_value:
        if attached is not None:
            return [attached], pos
        if pos < len(tokens) and not is_option_shaped(tokens[pos], prefixes) and tokens[pos] != "--":
            return [tokens[pos]], pos + 1
        return [], pos

    needed = option.nargs
    values = []
    if attached is not None:
        values.append(attached)
    elif option.prompt and (pos >= len(tokens) or is_option_shaped(tokens[pos], prefixes)):
        # A prompting option given without a value asks the user instead.
        return [], pos
    while len(values) < needed:
        if pos >= len(tokens):
            raise BadOptionUsage(
                f"Option {option.opts_text()} requires an argument.", ctx=ctx
            )
        values.append(tokens[pos])
        pos += 1
    return values, pos


def scan(
    tokens,
    table,
    *,
    interspersed=True,
    ignore_unknown=False,
    sub_after=None,
    ctx=None,
):
    """Scan ``tokens`` against ``table``.

    * ``interspersed`` - options may appear after positional tokens.
    * ``sub_after`` - group mode: the number of positional tokens that fill the group's
      own arguments; the next positional token is the subcommand name.
    """
    result = ScanResult()
    prefixes = table.prefixes
    i = 0
    n = len(tokens)
    stop_opts = False  # set by "--" or by a non-interspersed positional
    in_sub = False  # group mode: subcommand name has been seen

    def handle_option(tok, pos):
        """Handle one option-shaped token at ``pos``; return the new position."""
        # Full-token match, with optional "=value" for long names.
        if "=" in tok and table.get(tok.split("=", 1)[0]) is not None:
            name, attached = tok.split("=", 1)
            option, secondary = table.get(name)
            if not _takes_value(option) and not option.is_optional_value:
                raise BadOptionUsage(f"Option {name} does not take a value.", ctx=ctx)
            vals, pos = _take_values(option, attached, tokens, pos, prefixes, ctx)
            result.hits.append((option, vals, secondary))
            return pos
        found = table.get(tok)
        if found is not None:
            option, secondary = found
            if _takes_value(option) or option.is_optional_value:
                vals, pos = _take_values(option, None, tokens, pos, prefixes, ctx)
            else:
                vals = []
            result.hits.append((option, vals, secondary))
            return pos

        sink = result.sub_rest if in_sub else result.positionals

        # Long option that is not known.
        if len(tok) > 2 and tok[0] in prefixes and tok[1] in prefixes:
            if ignore_unknown or in_sub:
                sink.append(tok)
                return pos
            raise NoSuchOption(tok.split("=", 1)[0], ctx=ctx)

        # Short option stack.
        p = tok[0]
        j = 1
        while j < len(tok):
            key = p + tok[j]
            found = table.get(key)
            if found is None:
                if ignore_unknown or in_sub:
                    sink.append(p + tok[j:])
                    return pos
                raise NoSuchOption(key, ctx=ctx)
            option, secondary = found
            if _takes_value(option) or option.is_optional_value:
                attached = tok[j + 1:] or None
                vals, pos = _take_values(option, attached, tokens, pos, prefixes, ctx)
                result.hits.append((option, vals, secondary))
                return pos
            result.hits.append((option, [], secondary))
            j += 1
        return pos

    while i < n:
        tok = tokens[i]

        if in_sub:
            # Group mode after the subcommand name: only the group's own options are
            # taken when mixing is enabled; everything else belongs to the subcommand.
            if interspersed and is_option_shaped(tok, prefixes) and _is_known(tok, table):
                i = handle_option(tok, i + 1)
                continue
            result.sub_rest.append(tok)
            i += 1
            continue

        if stop_opts:
            result.positionals.append(tok)
            i += 1
            continue

        if tok == "--":
            stop_opts = True
            i += 1
            continue

        if not is_option_shaped(tok, prefixes):
            if sub_after is not None and len(result.positionals) >= sub_after:
                result.sub_name = tok
                in_sub = True
                i += 1
                continue
            result.positionals.append(tok)
            if not interspersed and sub_after is None:
                stop_opts = True
            i += 1
            continue

        i = handle_option(tok, i + 1)

    return result


def _is_known(tok, table):
    """True when ``tok`` names a declared option (whole token, long name or first short flag)."""
    if table.get(tok.split("=", 1)[0]) is not None:
        return True
    if len(tok) > 2 and tok[1] in table.prefixes:
        return False
    return table.get(tok[:2]) is not None
