"""Text wrapping and help-page layout helpers (FP-02, FP-11)."""

import shutil
import textwrap

FORM_FEED = "\f"
BACKSPACE = "\b"


def wrap_text(
    text,
    width=100,
    initial_indent="",
    subsequent_indent="",
    preserve_paragraphs=False,
):
    """Wrap ``text`` to ``width`` columns.

    Single newlines inside a paragraph are not kept as hard breaks. A paragraph
    whose first line is only a backspace is not rewrapped; its line breaks are kept
    and the backspace line is removed.
    """
    if text is None:
        return ""
    text = str(text)
    paragraphs = _split_paragraphs(text)
    out = []
    for para in paragraphs:
        lines = para.split("\n")
        if lines and lines[0].strip() == BACKSPACE:
            kept = [ln for ln in lines[1:]]
            body = "\n".join(kept)
            out.append(_indent_lines(body, initial_indent, subsequent_indent))
            continue
        flat = " ".join(ln.strip() for ln in lines if ln.strip())
        if not flat:
            out.append("")
            continue
        wrapped = textwrap.fill(
            flat,
            width=max(width, 10),
            initial_indent=initial_indent,
            subsequent_indent=subsequent_indent,
            break_long_words=False,
            break_on_hyphens=False,
        )
        out.append(wrapped)
    return "\n\n".join(out) if preserve_paragraphs else "\n".join(out)


def _split_paragraphs(text):
    paragraphs = []
    current = []
    for line in text.split("\n"):
        if line.strip() == "":
            if current:
                paragraphs.append("\n".join(current))
                current = []
        else:
            current.append(line)
    if current:
        paragraphs.append("\n".join(current))
    return paragraphs


def _indent_lines(body, initial_indent, subsequent_indent):
    lines = body.split("\n")
    result = []
    for i, ln in enumerate(lines):
        prefix = initial_indent if i == 0 else subsequent_indent
        result.append(prefix + ln if ln else "")
    return "\n".join(result)


def clean_help_text(text):
    """Drop everything after a form feed (the form feed itself is removed)."""
    if text is None:
        return None
    if FORM_FEED in text:
        text = text.split(FORM_FEED, 1)[0]
    return text


def get_width(terminal_width=None, max_content_width=80):
    """Wrap width: an explicit terminal width is used as-is; otherwise detected, capped."""
    if terminal_width is not None:
        return terminal_width
    detected = shutil.get_terminal_size(fallback=(80, 24)).columns
    return min(detected, max_content_width) - 2


def truncate(text, limit=45):
    """Cut ``text`` to ``limit`` characters and ellipsize with ``...``."""
    if len(text) <= limit:
        return text
    return text[: max(limit - 3, 0)].rstrip() + "..."


class HelpFormatter:
    """Builds a help page as a list of lines."""

    def __init__(self, width=78, indent=2, col_max=30):
        self.width = width
        self.indent = indent
        self.col_max = col_max
        self.lines = []

    def write(self, text=""):
        self.lines.append(text)

    def write_paragraph(self, text, indent=0):
        pad = " " * indent
        self.lines.append(wrap_text(text, width=self.width, initial_indent=pad, subsequent_indent=pad))

    def write_section(self, heading, rows):
        """Write ``heading`` and aligned ``(first, second)`` rows."""
        self.lines.append(heading + ":")
        if not rows:
            return
        first_col = min(max(len(r[0]) for r in rows), self.col_max)
        pad = " " * self.indent
        for first, second in rows:
            if second and len(first) <= first_col:
                entry = f"{pad}{first.ljust(first_col)}  "
                body_width = max(self.width - len(entry) - 0, 20)
                wrapped = wrap_text(second, width=body_width).split("\n")
                self.lines.append(entry + wrapped[0])
                for extra in wrapped[1:]:
                    self.lines.append(" " * len(entry) + extra)
            elif second:
                self.lines.append(f"{pad}{first}")
                for ln in wrap_text(second, width=self.width - self.indent * 3).split("\n"):
                    self.lines.append(" " * (self.indent * 2) + ln)
            else:
                self.lines.append(f"{pad}{first}")
        self.lines.append("")

    def getvalue(self):
        text = "\n".join(self.lines).rstrip() + "\n"
        return text
