"""In-process runner for commands (FP-14): ``optlyn.testing.CliRunner``."""

import contextlib
import io
import os
import shutil
import sys
import tempfile


class _Recorder:
    """Shared, ordered log of everything written to stdout and stderr."""

    def __init__(self):
        self.parts = []


class _CaptureStream(io.TextIOBase):
    def __init__(self, recorder, kind, charset):
        self._recorder = recorder
        self._kind = kind
        self._charset = charset
        self._bytes = bytearray()

    def writable(self):
        return True

    @property
    def encoding(self):
        return self._charset

    def write(self, text):
        if isinstance(text, (bytes, bytearray)):
            data = bytes(text)
            self._recorder.parts.append((self._kind, data))
            return len(data)
        data = text.encode(self._charset, "backslashreplace")
        self._recorder.parts.append((self._kind, data))
        return len(text)

    def flush(self):
        return None

    @property
    def buffer(self):
        return _BufferView(self)

    def isatty(self):
        return False


class _BufferView(io.RawIOBase):
    def __init__(self, stream):
        self._stream = stream

    def writable(self):
        return True

    def write(self, data):
        self._stream._recorder.parts.append((self._stream._kind, bytes(data)))
        return len(data)


class _Input(io.TextIOBase):
    """Standard input fed from the runner's ``input`` argument."""

    def __init__(self, data, charset, echo_stdin, out_stream):
        self._data = data
        self._pos = 0
        self._charset = charset
        self.echo_stdin = echo_stdin
        self.echo_visible = True
        self._out = out_stream

    def readable(self):
        return True

    @property
    def encoding(self):
        return self._charset

    def isatty(self):
        return False

    def _take(self, n):
        chunk = self._data[self._pos:self._pos + n]
        self._pos += len(chunk)
        return chunk

    def read(self, size=-1):
        if size is None or size < 0:
            rest = self._data[self._pos:]
            self._pos = len(self._data)
        else:
            rest = self._take(size)
        if self.echo_stdin and rest:
            self._out.write(rest)
        return rest.decode(self._charset, "replace")

    def readline(self, size=-1):
        if self._pos >= len(self._data):
            return ""
        end = self._data.find(b"\n", self._pos)
        end = len(self._data) if end == -1 else end + 1
        line = self._data[self._pos:end]
        self._pos = end
        text = line.decode(self._charset, "replace")
        if self.echo_stdin:
            self._out.write(line)
        return text

    def buffer_read(self):
        return self


class Result:
    """Outcome of :meth:`CliRunner.invoke`."""

    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value, exit_code, exception, exc_info):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self):
        return self.output_bytes.decode(self.runner.charset, "replace")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    """Invokes a command in-process and captures its output and status."""

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        data = input or b""
        if isinstance(data, str):
            data = data.encode(self.charset)
        recorder = _Recorder()
        out = _CaptureStream(recorder, "stdout", self.charset)
        err = _CaptureStream(recorder, "stderr", self.charset)
        stdin = _Input(data, self.charset, self.echo_stdin, out)

        merged = dict(self.env)
        merged.update(env or {})
        saved_env = {}
        for key, value in merged.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)

        saved = (sys.stdin, sys.stdout, sys.stderr)
        sys.stdin, sys.stdout, sys.stderr = stdin, out, err
        try:
            yield recorder, out, err
        finally:
            sys.stdin, sys.stdout, sys.stderr = saved
            for key, value in saved_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if args is None:
            args = []
        if isinstance(args, str):
            import shlex

            args = shlex.split(args)
        extra.setdefault("color", color)
        prog_name = extra.pop("prog_name", "cli")
        extra.setdefault("standalone_mode", True)
        standalone = extra.pop("standalone_mode")

        exit_code = 0
        exception = None
        exc_info = None
        return_value = None
        with self.isolation(input=input, env=env, color=color) as (recorder, out, err):
            try:
                return_value = cli.main(
                    args=list(args),
                    prog_name=prog_name,
                    standalone_mode=standalone,
                    **extra,
                )
                if not standalone:
                    exit_code = 0
            except SystemExit as e:
                exit_code = _code_of(e.code)
            except Exception as e:  # noqa: BLE001
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()

        stdout_bytes = b"".join(d for k, d in recorder.parts if k == "stdout")
        stderr_bytes = b"".join(d for k, d in recorder.parts if k == "stderr")
        output_bytes = b"".join(d for _, d in recorder.parts)
        return Result(
            self,
            stdout_bytes,
            stderr_bytes,
            output_bytes,
            return_value,
            exit_code,
            exception,
            exc_info,
        )

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        if temp_dir is None:
            path = tempfile.mkdtemp()
            remove = True
        else:
            path = tempfile.mkdtemp(dir=os.fspath(temp_dir))
            remove = False
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if remove:
                shutil.rmtree(path, ignore_errors=True)


def _code_of(code):
    if code is None:
        return 0
    if isinstance(code, int):
        return code
    print(code, file=sys.stderr)
    return 1
