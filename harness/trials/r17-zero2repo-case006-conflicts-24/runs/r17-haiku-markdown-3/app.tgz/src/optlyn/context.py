"""Invocation context and the per-thread context stack (FP-07)."""

import contextlib
import enum
import threading

from .exceptions import Abort, Exit


class ParameterSource(enum.Enum):
    """Where a parameter's value came from. Ordered from most to least explicit."""

    PROMPT = "prompt"
    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"


_local = threading.local()


def _stack():
    stack = getattr(_local, "stack", None)
    if stack is None:
        stack = []
        _local.stack = stack
    return stack


def get_current_context(silent=False):
    """Return the context current on this thread (raise if none unless silent)."""
    stack = _stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")


# Settings that a child context inherits from its parent when not given.
_INHERITED = (
    "auto_envvar_prefix",
    "terminal_width",
    "max_content_width",
    "help_option_names",
    "token_normalize_func",
    "color",
    "show_default",
    "allow_extra_args",
    "ignore_unknown_options",
)

_DEFAULTS = {
    "auto_envvar_prefix": None,
    "terminal_width": None,
    "max_content_width": None,
    "help_option_names": None,
    "token_normalize_func": None,
    "color": None,
    "show_default": None,
    "allow_extra_args": None,
    "ignore_unknown_options": None,
    "allow_interspersed_args": None,
}


class Context:
    """State for one invocation of a command."""

    def __init__(
        self,
        command,
        parent=None,
        info_name=None,
        obj=None,
        default_map=None,
        **settings,
    ):
        self.command = command
        self.parent = parent
        self.info_name = info_name
        self.params = {}
        self.args = []
        self.invoked_subcommand = None
        self._sources = {}
        self._exit_stack = contextlib.ExitStack()
        self._depth = 0

        unknown = set(settings) - set(_DEFAULTS)
        if unknown:
            raise TypeError(f"Unknown context setting: {sorted(unknown)[0]}")

        cs = dict(getattr(command, "context_settings", None) or {})
        for key in _DEFAULTS:
            if key in settings:
                value = settings[key]
            elif key in cs:
                value = cs[key]
            elif parent is not None and key in _INHERITED:
                value = getattr(parent, key)
            else:
                value = None
            setattr(self, key, value)

        if self.help_option_names is None:
            self.help_option_names = ["--help"]
        if self.max_content_width is None:
            self.max_content_width = 80
        if self.show_default is None:
            self.show_default = False
        if self.allow_extra_args is None:
            self.allow_extra_args = False
        if self.ignore_unknown_options is None:
            self.ignore_unknown_options = False
        if self.allow_interspersed_args is None:
            self.allow_interspersed_args = bool(getattr(command, "allow_interspersed_args", True))

        if obj is None and parent is not None:
            obj = parent.obj
        self.obj = obj

        if default_map is None:
            default_map = cs.get("default_map")
        if default_map is None and parent is not None and isinstance(parent.default_map, dict):
            # A group's map nests a dict under each child name.
            nested = parent.default_map.get(info_name)
            if isinstance(nested, dict):
                default_map = nested
        self.default_map = default_map

        if info_name is None and command is not None:
            self.info_name = command.name
        self.command_path = self._build_command_path()

    # --- thread stack ---------------------------------------------------------

    def push(self):
        """Make this context current on this thread without closing it later."""
        self._depth += 1
        _stack().append(self)

    def pop(self):
        self._depth -= 1
        stack = _stack()
        if stack and stack[-1] is self:
            stack.pop()

    def __enter__(self):
        self.push()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.pop()
        if self._depth == 0:
            self.close()
        return False

    def close(self):
        self._exit_stack.close()

    # --- helpers --------------------------------------------------------------

    def _build_command_path(self):
        names = []
        ctx = self
        while ctx is not None:
            if ctx.info_name:
                names.append(ctx.info_name)
            ctx = ctx.parent
        return " ".join(reversed(names))

    def get_help_option_hint(self):
        names = [n for n in self.help_option_names]
        if not names:
            return None
        return f"Try '{self.command_path} {names[0]}' for help."

    def get_parameter_source(self, name):
        """Return the source of parameter ``name``, or None if not declared."""
        return self._sources.get(name)

    def _set_source(self, name, source):
        self._sources[name] = source

    def with_resource(self, cm):
        """Enter ``cm``, keep it open until the invocation ends, and return its value."""
        return self._exit_stack.enter_context(cm)

    def call_on_close(self, f):
        return self._exit_stack.callback(f)

    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type):
        node = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
        return found

    def invoke(self, other, **kwargs):
        """Run ``other`` with exactly the values in ``kwargs``."""
        return _invoke_nested(self, other, kwargs, forward=False)

    def forward(self, other, **kwargs):
        """Run ``other`` with this context's parameters, overridden by ``kwargs``."""
        return _invoke_nested(self, other, kwargs, forward=True)


def _invoke_nested(ctx, other, kwargs, forward):
    cmd = other
    values = dict(ctx.params) if forward else {}
    values.update(kwargs)
    sub = Context(cmd, parent=ctx, info_name=cmd.name, obj=ctx.obj)
    with sub:
        sub.params.update(values)
        return cmd.invoke_callback(sub, values)
