"""Declaration decorators: command, group, option, argument, pass-through helpers (FP-01, FP-02, FP-08)."""

import functools
import importlib.metadata

from .context import get_current_context
from .core import Command, CommandCollection, Group, _help_callback
from .exceptions import Exit
from .params import Argument, Option
from .termui import confirm, echo

_ATTR = "__optlyn_params__"
_NAME_SUFFIXES = ("_command", "_cmd", "_group", "_grp")


def _attach(f, param):
    params = f.__dict__.setdefault(_ATTR, [])
    params.insert(0, param)


def _pop_params(f):
    return f.__dict__.pop(_ATTR, [])


def _default_name(func_name):
    name = func_name.lower()
    for suffix in _NAME_SUFFIXES:
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def _make(f, cls, name, attrs):
    params = _pop_params(f)
    if name is None:
        name = _default_name(f.__name__)
    if "help" not in attrs and f.__doc__:
        attrs["help"] = f.__doc__
    return cls(name=name, callback=f, params=params, **attrs)


def command(name=None, cls=None, **attrs):
    """Turn a function into a :class:`Command`."""
    if callable(name) and not isinstance(name, str):
        return command()(name)
    cls = cls or Command

    def decorator(f):
        return _make(f, cls, name, dict(attrs))

    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a :class:`Group` (or ``cls``)."""
    if callable(name) and not isinstance(name, str):
        return group()(name)
    cls = cls or Group

    def decorator(f):
        if issubclass(cls, CommandCollection):
            sources = attrs.pop("sources", None)
            return _make(f, cls, name, dict(attrs, sources=sources))
        return _make(f, cls, name, dict(attrs))

    return decorator


def option(*param_decls, cls=None, **attrs):
    """Attach an option to the function being decorated."""
    cls = cls or Option

    def decorator(f):
        _attach(f, cls(param_decls, **attrs))
        return f

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach a positional argument to the function being decorated."""
    cls = cls or Argument

    def decorator(f):
        _attach(f, cls(param_decls, **attrs))
        return f

    return decorator


def help_option(*param_decls, **kwargs):
    """Attach an extra eager help flag that prints help and exits."""
    decls = list(param_decls) or ["--help"]
    kwargs.setdefault("help", "Show this message and exit.")

    def decorator(f):
        _attach(f, Option(
            decls,
            is_flag=True,
            is_eager=True,
            expose_value=False,
            callback=_help_callback,
            **kwargs,
        ))
        return f

    return decorator


def _detect_version(name):
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        pass
    mapping = importlib.metadata.packages_distributions()
    dists = mapping.get(name)
    if not dists:
        raise RuntimeError(f"{name!r} is not an installed distribution or import name.")
    return importlib.metadata.version(dists[0])


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    """Eager ``--version`` flag printing a version identity."""
    decls = list(param_decls) or ["--version"]
    kwargs.setdefault("help", "Show the version and exit.")

    def callback(ctx, param, value):
        if not value:
            return value
        ident = version
        if ident is None:
            if package_name is None:
                raise RuntimeError("version_option needs a version or a package_name.")
            ident = _detect_version(package_name)
        name = prog_name or ctx.find_root().info_name or ctx.command_path
        text = message if message is not None else "%(prog)s, version %(version)s"
        echo(text % {"prog": name, "version": ident})
        raise Exit(0)

    def decorator(f):
        _attach(f, Option(
            decls,
            is_flag=True,
            is_eager=True,
            expose_value=False,
            callback=callback,
            **kwargs,
        ))
        return f

    return decorator


def custom_version_option(callback, *param_decls, **kwargs):
    """Eager ``--version`` flag whose identity is the string returned by ``callback(ctx)``."""
    decls = list(param_decls) or ["--version"]
    kwargs.setdefault("help", "Show the version and exit.")

    def handler(ctx, param, value):
        if not value:
            return value
        echo(callback(ctx))
        raise Exit(0)

    def decorator(f):
        _attach(f, Option(
            decls,
            is_flag=True,
            is_eager=True,
            expose_value=False,
            callback=handler,
            **kwargs,
        ))
        return f

    return decorator


def password_option(*param_decls, **kwargs):
    """Prompting, hidden, confirmed option (default ``--password``)."""
    decls = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)

    def decorator(f):
        _attach(f, Option(decls, **kwargs))
        return f

    return decorator


def confirmation_option(*param_decls, **kwargs):
    """Yes-flag that asks for confirmation when omitted and aborts on refusal (default ``--yes``)."""
    decls = list(param_decls) or ["--yes"]
    question = kwargs.pop("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")

    def callback(ctx, param, value):
        if not value:
            confirm(question, default=False, abort=True)
        return value

    def decorator(f):
        _attach(f, Option(
            decls,
            is_flag=True,
            expose_value=False,
            callback=callback,
            **kwargs,
        ))
        return f

    return decorator


def pass_context(f):
    """Pass the current :class:`Context` as the first argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(f):
    """Pass the current context's ``obj`` as the first argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type, ensure=False):
    """Build a decorator that passes the nearest object of ``object_type``."""

    def decorator(f):
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            return f(obj, *args, **kwargs)

        return new_func

    return decorator
