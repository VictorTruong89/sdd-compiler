"""Parameters (options and arguments) and value resolution (FP-03 to FP-05, FP-07, FP-08)."""

import os

from .context import ParameterSource
from .exceptions import BadParameter, MissingParameter
from .paramtypes import BOOL, Tuple, convert_type

PREFIX_CHARS = "-/+"
_TRUE_ENV = {"true", "1", "yes", "on", "t", "y"}
_FALSE_ENV = {"false", "0", "no", "off", "f", "n", ""}


class Parameter:
    """Base class for options and arguments."""

    def __init__(
        self,
        param_decls=None,
        type=None,
        required=False,
        default=None,
        callback=None,
        nargs=None,
        multiple=False,
        metavar=None,
        expose_value=True,
        is_eager=False,
        envvar=None,
        shell_complete=None,
        deprecated=False,
        help=None,
        hidden=False,
        show_default=None,
        show_envvar=False,
        allow_from_autoenv=True,
        prompt=None,
        prompt_required=True,
        hide_input=False,
        confirmation_prompt=False,
    ):
        self.param_decls = list(param_decls or [])
        self.name = None
        self.default = default
        self.callback = callback
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        self.envvar = envvar
        self.shell_complete_func = shell_complete
        self.deprecated = bool(deprecated)
        self.help = help
        self.hidden = hidden
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.allow_from_autoenv = allow_from_autoenv
        self.prompt = prompt
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.multiple = bool(multiple)
        self.nargs = 1 if nargs is None else nargs
        self.required = bool(required)
        self.type = convert_type(type, default)
        if isinstance(self.type, Tuple):
            self.nargs = self.type.arity

    @property
    def is_unary(self):
        return self.nargs == 1 and not self.multiple and not isinstance(self.type, Tuple)

    def get_default(self):
        """Return the declared default, invoking it when callable."""
        if callable(self.default):
            return self.default()
        return self.default

    def _split_string(self, text):
        """Split an environment or default-map string into tokens."""
        splitter = self.type.envvar_list_splitter
        if splitter is not None:
            return [p for p in text.split(splitter) if p != ""]
        return text.split()

    def _convert_tokens(self, ctx, tokens):
        """Convert the tokens of one occurrence (length equals nargs)."""
        if isinstance(self.type, Tuple):
            return self.type.convert(tuple(tokens), self, ctx)
        if self.nargs == 1:
            return self.type(tokens[0], self, ctx)
        return tuple(self.type(t, self, ctx) for t in tokens)

    def _env_names(self):
        names = []
        if self.envvar:
            names = [self.envvar] if isinstance(self.envvar, str) else list(self.envvar)
        return names

    def _env_raw(self, ctx):
        """First set environment value (FP-03), or None."""
        names = self._env_names()
        if self.allow_from_autoenv and ctx.auto_envvar_prefix and self.name:
            names.append(_auto_env_name(ctx, self.name))
        for name in names:
            raw = os.environ.get(name)
            if raw is not None and raw.strip() != "":
                return raw
        return None

    def _map_value(self, ctx):
        dm = ctx.default_map
        if not dm or self.name not in dm:
            return None
        return dm[self.name]

    def get_error_hint(self):
        return self.name

    def process_value(self, ctx, value):
        """Run the parameter callback and return the value it leaves in place."""
        if self.callback is not None:
            return self.callback(ctx, self, value)
        return value

    def shell_complete(self, ctx, incomplete):
        if self.shell_complete_func is not None:
            return self.shell_complete_func(ctx, self, incomplete)
        return self.type.shell_complete(ctx, self, incomplete)

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"


def _auto_env_name(ctx, dest):
    """Build ``PREFIX_SUB_..._DEST`` (FP-07); the top-level command name is skipped."""
    chain = []
    node = ctx
    while node is not None:
        chain.append(node)
        node = node.parent
    parts = [ctx.auto_envvar_prefix]
    for node in reversed(chain[:-1]):
        parts.append(node.info_name or "")
    parts.append(dest)
    return "_".join(p.replace("-", "_").upper() for p in parts if p)


class Option(Parameter):
    """A named parameter introduced by a prefix character."""

    def __init__(self, param_decls=None, is_flag=None, flag_value=None, count=False, **attrs):
        self.opts = []
        self.secondary_opts = []
        super().__init__(param_decls=param_decls, **attrs)
        self._parse_decls()

        self.count = bool(count)
        if is_flag is None:
            is_flag = bool(self.secondary_opts) or flag_value is not None
        if self.count:
            is_flag = True
        self.is_flag = bool(is_flag)
        self.is_optional_value = (is_flag is False and flag_value is not None)
        if self.is_flag:
            if self.nargs != 1:
                raise ValueError("A flag cannot take multiple values.")
            if attrs.get("type") is None and not self.count:
                self.type = BOOL
            if flag_value is None:
                flag_value = True
        self.flag_value = flag_value
        self._check_declaration()

    def _check_declaration(self):
        if self.deprecated and self.required:
            raise ValueError(f"{self.name}: a deprecated option cannot be required.")
        if self.deprecated and self.prompt:
            raise ValueError(f"{self.name}: a deprecated option cannot use a prompt.")
        if self.count and self.multiple:
            raise ValueError("A counting option cannot be repeatable.")

    def _parse_decls(self):
        names = []
        for decl in self.param_decls:
            if decl and decl[0] in PREFIX_CHARS:
                if "/" in decl[1:]:
                    on, off = decl.split("/", 1)
                    if off and off[0] in PREFIX_CHARS:
                        self.opts.append(on)
                        self.secondary_opts.append(off)
                        continue
                self.opts.append(decl)
            else:
                names.append(decl)
        if len(names) > 1:
            raise TypeError(f"Only one destination name is allowed, got {names!r}.")
        if names:
            self.name = names[0]
        else:
            if not self.opts and not self.secondary_opts:
                raise TypeError("Could not determine a name for the option.")
            self.name = self._infer_name()

    def _infer_name(self):
        """Destination from the first long name, else the first short name."""
        all_names = self.opts + self.secondary_opts
        long_names = [n for n in all_names if n[:2] in ("--", "//", "++")]
        chosen = long_names[0] if long_names else all_names[0]
        return chosen.lstrip(PREFIX_CHARS).replace("-", "_")

    @property
    def all_names(self):
        return self.opts + self.secondary_opts

    def opts_text(self):
        return " / ".join(self.all_names)

    def get_error_hint(self):
        return self.opts_text() or self.name

    def get_metavar_text(self):
        if self.metavar is not None:
            return self.metavar
        if self.is_flag or self.count:
            return None
        meta = self.type.get_metavar(self)
        return meta if meta is not None else self.type.name.upper()

    # --- command-line values ------------------------------------------------

    def _cmdline_value(self, ctx, hits):
        """``hits`` is a list of ``(tokens, secondary)`` in command-line order."""
        if self.count:
            return len(hits)
        if self.is_flag:
            values = [self._flag_result(h) for h in hits]
            return tuple(values) if self.multiple else values[-1]
        if self.is_optional_value:
            values = [
                self.type(tokens[0], self, ctx) if tokens else self.flag_value
                for tokens, _ in hits
            ]
            return tuple(values) if self.multiple else values[-1]
        values = [self._convert_tokens(ctx, tokens) for tokens, _ in hits]
        return tuple(values) if self.multiple else values[-1]

    def _flag_result(self, hit):
        _tokens, secondary = hit
        if secondary:
            return False
        return self.flag_value

    def _has_valueless_hit(self, hits):
        return any(not tokens for tokens, _ in hits)

    # --- other sources -----------------------------------------------------

    def _env_value(self, ctx):
        raw = self._env_raw(ctx)
        if raw is None:
            return None
        if self.is_flag:
            return self._env_flag(ctx, raw)
        if self.count:
            return None
        if self.multiple:
            parts = self._split_string(raw)
            groups = [parts[i:i + self.nargs] for i in range(0, len(parts), self.nargs)]
            return tuple(self._convert_tokens(ctx, g) for g in groups if g)
        if self.nargs != 1 or isinstance(self.type, Tuple):
            return self._convert_tokens(ctx, self._split_string(raw))
        return self.type(raw, self, ctx)

    def _env_flag(self, ctx, raw):
        text = raw.strip().lower()
        if self.flag_value is not True and raw == str(self.flag_value):
            return self.flag_value
        if text in _TRUE_ENV:
            return self.flag_value
        if text in _FALSE_ENV:
            return False
        if self.flag_value is not True:
            return None
        self.type.fail(f"{raw!r} is not a valid boolean.", self, ctx)

    def _convert_default(self, ctx, value):
        if self.nargs != 1 or isinstance(self.type, Tuple):
            if isinstance(value, str):
                value = self._split_string(value)
            if isinstance(self.type, Tuple):
                return self.type.convert(tuple(value), self, ctx)
            return tuple(self.type(v, self, ctx) for v in value)
        return self.type(value, self, ctx)

    def _default_value(self, ctx):
        default = self.get_default()
        if self.count:
            return default
        if self.is_flag:
            return False if default is None else bool(default)
        if self.multiple:
            if default is None:
                return ()
            if isinstance(default, str) or not isinstance(default, (list, tuple)):
                raise BadParameter(
                    f"The default for {self.opts_text() or self.name} needs an iterable (sequence) default.",
                    ctx=ctx,
                    param=self,
                )
            return tuple(self._convert_one_occurrence(ctx, d) for d in default)
        if default is None:
            return None
        return self._convert_default(ctx, default)

    def _convert_one_occurrence(self, ctx, value):
        if self.nargs != 1 or isinstance(self.type, Tuple):
            return self._convert_default(ctx, value)
        return self.type(value, self, ctx)

    def _prompt_text(self):
        if isinstance(self.prompt, str):
            return self.prompt
        return self.name.replace("_", " ").capitalize()

    def _prompt_default(self):
        return self.get_default()

    def _ask(self, ctx):
        from .termui import prompt

        return prompt(
            self._prompt_text(),
            default=self._prompt_default(),
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            type=self.type,
        )

    def resolve(self, ctx, hits):
        """Return ``(value, source, explicit_default)`` for this option.

        Order: command line, prompt for an option without value, environment,
        prompt for a required prompting option, default map, declared default.
        """
        if hits:
            if self.prompt and not self.is_flag and not self.count and self._has_valueless_hit(hits):
                return self._ask(ctx), ParameterSource.PROMPT, False
            return self._cmdline_value(ctx, hits), ParameterSource.COMMANDLINE, False

        env = self._env_value(ctx)
        if env is not None:
            return env, ParameterSource.ENVIRONMENT, False

        if self.prompt and self.prompt_required and not self.is_flag and not self.count:
            return self._ask(ctx), ParameterSource.PROMPT, False

        raw = self._map_value(ctx)
        if raw is not None:
            if self.multiple and isinstance(raw, str):
                raise BadParameter(
                    f"The default map value for {self.opts_text() or self.name} needs an iterable (sequence) default.",
                    ctx=ctx,
                    param=self,
                )
            if isinstance(raw, str) and not self.is_flag:
                raw = self._split_string(raw) if (self.nargs != 1 or isinstance(self.type, Tuple)) else raw
            if self.nargs != 1 and not isinstance(raw, (list, tuple, str)):
                raw = list(raw)
            if self.multiple:
                return tuple(self._convert_one_occurrence(ctx, d) for d in raw), ParameterSource.DEFAULT_MAP, False
            if self.nargs != 1 or isinstance(self.type, Tuple):
                return self._convert_default(ctx, raw), ParameterSource.DEFAULT_MAP, False
            return self.type(raw, self, ctx), ParameterSource.DEFAULT_MAP, False

        return self._default_value(ctx), ParameterSource.DEFAULT, self.default is not None


class Argument(Parameter):
    """A positional parameter."""

    def __init__(self, param_decls=None, **attrs):
        nargs = attrs.get("nargs")
        default = attrs.get("default")
        if attrs.get("required") is None:
            attrs["required"] = default is None and nargs != -1
        attrs["required"] = attrs["required"] and default is None
        super().__init__(param_decls=param_decls, **attrs)
        if len(self.param_decls) != 1 or self.param_decls[0].startswith(tuple(PREFIX_CHARS)):
            raise TypeError("An argument takes exactly one destination name.")
        self.name = self.param_decls[0]
        if self.nargs == 0 or self.nargs < -1:
            raise ValueError("nargs must be a positive integer or -1.")
        if self.deprecated and self.required:
            raise ValueError(f"{self.name}: a deprecated argument cannot be required.")
        if self.prompt:
            raise ValueError(f"{self.name}: an argument cannot prompt.")

    @property
    def variadic(self):
        return self.nargs == -1

    def get_metavar_text(self):
        return self.metavar if self.metavar is not None else self.name.upper()

    def get_error_hint(self):
        return self.name

    def _from_tokens(self, ctx, tokens):
        if self.variadic or self.multiple:
            return tuple(self.type(t, self, ctx) for t in tokens)
        if isinstance(self.type, Tuple):
            return self.type.convert(tuple(tokens), self, ctx)
        if self.nargs == 1:
            return self.type(tokens[0], self, ctx)
        return tuple(self.type(t, self, ctx) for t in tokens)

    def _default_value(self, ctx):
        default = self.get_default()
        if default is None:
            return () if self.variadic else None
        if self.is_unary:
            return self.type(default, self, ctx)
        if isinstance(default, str):
            default = self._split_string(default)
        return self._from_tokens(ctx, list(default))

    def resolve(self, ctx, tokens):
        """Return ``(value, source)`` given the tokens that filled this argument."""
        if tokens:
            return self._from_tokens(ctx, tokens), ParameterSource.COMMANDLINE
        raw = None
        for name in self._env_names():
            value = os.environ.get(name)
            if value is not None and value.strip() != "":
                raw = value
                break
        if raw is not None:
            if self.is_unary:
                return self.type(raw, self, ctx), ParameterSource.ENVIRONMENT
            return self._from_tokens(ctx, self._split_string(raw)), ParameterSource.ENVIRONMENT
        found = self._map_value(ctx)
        if found is not None:
            if self.is_unary:
                return self.type(found, self, ctx), ParameterSource.DEFAULT_MAP
            seq = self._split_string(found) if isinstance(found, str) else list(found)
            return self._from_tokens(ctx, seq), ParameterSource.DEFAULT_MAP
        if self.required:
            raise MissingParameter(ctx=ctx, param=self)
        return self._default_value(ctx), ParameterSource.DEFAULT

    @property
    def is_unary(self):
        return self.nargs == 1 and not self.multiple and not isinstance(self.type, Tuple)


__all__ = ["Parameter", "Option", "Argument"]
