"""Terminal helpers: echo, styling, prompts, progress, files (FP-08, FP-09, FP-11)."""

import codecs
import contextlib
import io
import os
import re
import subprocess
import sys
import tempfile
import time

from .context import get_current_context
from .exceptions import Abort, BadParameter

_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")

_COLOR_NAMES = [
    "black", "red", "green", "yellow", "blue", "magenta", "cyan", "white",
]
_BRIGHT_NAMES = ["bright_" + n for n in _COLOR_NAMES]
_COLOR_CODES = {n: 30 + i for i, n in enumerate(_COLOR_NAMES)}
_COLOR_CODES.update({n: 90 + i for i, n in enumerate(_BRIGHT_NAMES)})

_SWITCH_CODES = {
    "bold": 1,
    "dim": 2,
    "italic": 3,
    "underline": 4,
    "blink": 5,
    "reverse": 7,
    "strikethrough": 9,
    "overline": 53,
}


def _color_codes(color, background):
    base = 40 if background else 30
    if isinstance(color, str):
        if color == "reset":
            return [str(49 if background else 39)]
        if color not in _COLOR_CODES:
            raise ValueError(f"Unknown color {color!r}.")
        code = _COLOR_CODES[color]
        return [str(code + 10 if background else code)]
    if isinstance(color, bool):
        raise TypeError(f"Invalid color {color!r}.")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise ValueError(f"Color number {color} out of range 0-255.")
        return [str(base + 8), "5", str(color)]
    if isinstance(color, (tuple, list)):
        if len(color) != 3 or not all(isinstance(c, int) and not isinstance(c, bool) for c in color):
            raise TypeError(f"Invalid RGB color {color!r}.")
        if not all(0 <= c <= 255 for c in color):
            raise ValueError(f"RGB color {color!r} out of range 0-255.")
        return [str(base + 8), "2"] + [str(c) for c in color]
    raise TypeError(f"Invalid color {color!r}.")


def style(
    text,
    fg=None,
    bg=None,
    bold=None,
    dim=None,
    underline=None,
    overline=None,
    italic=None,
    blink=None,
    reverse=None,
    strikethrough=None,
    reset=True,
):
    """Wrap ``text`` in ANSI SGR sequences."""
    bits = []
    if fg is not None:
        bits += _color_codes(fg, False)
    if bg is not None:
        bits += _color_codes(bg, True)
    switches = {
        "bold": bold,
        "dim": dim,
        "underline": underline,
        "overline": overline,
        "italic": italic,
        "blink": blink,
        "reverse": reverse,
        "strikethrough": strikethrough,
    }
    for name, on in switches.items():
        if on:
            bits.append(str(_SWITCH_CODES[name]))
    if not bits:
        return text
    prefix = "\x1b[" + ";".join(bits) + "m"
    return prefix + text + ("\x1b[0m" if reset else "")


def unstyle(text):
    """Remove ANSI sequences from ``text``."""
    return _ANSI_RE.sub("", text)


def _isatty(stream):
    try:
        return bool(stream and stream.isatty())
    except (AttributeError, ValueError):
        return False


def is_interactive():
    """A session is interactive when stdin is a terminal, or stdin/stdout is a TTY."""
    return _isatty(sys.stdin) or _isatty(sys.stdout)


def _stream_encoding_is_ascii(file):
    enc = getattr(file, "encoding", None) or "ascii"
    try:
        return codecs.lookup(enc).name == "ascii"
    except LookupError:
        return True


def _write_text(file, text):
    try:
        file.write(text)
    except UnicodeEncodeError:
        buf = getattr(file, "buffer", None)
        if buf is None:
            file.write(text.encode("ascii", "replace").decode("ascii"))
        else:
            file.flush()
            buf.write(text.encode("utf-8"))
            buf.flush()


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write ``message`` to stdout (or stderr with ``err=True``)."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if color is None:
        ctx = get_current_context(silent=True)
        if ctx is not None:
            color = ctx.color
    if message is None:
        message = ""

    buf = getattr(file, "buffer", None)
    if isinstance(message, (bytes, bytearray)):
        data = bytes(message) + (b"\n" if nl else b"")
        if buf is not None:
            file.flush()
            buf.write(data)
            buf.flush()
        else:
            file.write(data.decode("utf-8", "replace"))
        return

    text = str(message)
    if color is None:
        if not _isatty(file):
            text = unstyle(text)
    elif color is False:
        text = unstyle(text)
    if nl:
        text += "\n"

    if buf is not None and _stream_encoding_is_ascii(file):
        file.flush()
        buf.write(text.encode("utf-8"))
        buf.flush()
    else:
        _write_text(file, text)
    file.flush()


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    """Echo styled text in one step."""
    if message is not None:
        message = style(str(message), **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)





def _read_line(prompt_text):
    """Read one line from stdin, raising Abort at end of file."""
    sys.stdout.write(prompt_text)
    sys.stdout.flush()
    line = sys.stdin.readline()
    if line == "":
        sys.stdout.write("\n")
        sys.stdout.flush()
        raise Abort()
    if getattr(sys.stdin, "echo_visible", False):
        sys.stdout.write(line if line.endswith("\n") else line + "\n")
    return line.rstrip("\r\n")


def _read_hidden(prompt_text):
    try:
        import getpass

        if _isatty(sys.stdin):
            return getpass.getpass(prompt_text)
    except (EOFError, KeyboardInterrupt):
        raise Abort()
    sys.stdout.write(prompt_text)
    sys.stdout.flush()
    line = sys.stdin.readline()
    if line == "":
        sys.stdout.write("\n")
        raise Abort()
    sys.stdout.write("\n")
    return line.rstrip("\r\n")


def prompt(
    text,
    default=None,
    hide_input=False,
    confirmation_prompt=False,
    type=None,
    value_proc=None,
    prompt_suffix=": ",
    show_default=True,
    err=False,
    show_choices=True,
):
    """Ask for a value, convert it, and return it. Re-asks on conversion failure."""
    from .paramtypes import convert_type

    ty = convert_type(type, default)
    while True:
        current = default() if callable(default) else default
        shown = ""
        if current is not None and show_default:
            shown = f" [{current}]"
        question = f"{text}{shown}{prompt_suffix}"
        value = _read_hidden(question) if hide_input else _read_line(question)
        if value == "":
            if current is None:
                continue
            value = current
        else:
            if confirmation_prompt:
                repeat = f"Repeat for confirmation{prompt_suffix}"
                second = _read_hidden(repeat) if hide_input else _read_line(repeat)
                if second != value:
                    echo("Error: the two entered values do not match", err=True)
                    continue
        try:
            if value_proc is not None:
                return value_proc(value)
            return ty(value, None, None)
        except BadParameter as exc:
            echo(f"Error: {exc.message}", err=True)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    """Ask a yes/no question and return a boolean."""
    if default is True:
        shown = " [Y/n]"
    elif default is False:
        shown = " [y/N]"
    else:
        shown = " [y/n]"
    if not show_default:
        shown = ""
    while True:
        answer = _read_line(f"{text}{shown}{prompt_suffix}").strip().lower()
        if answer in ("y", "yes"):
            result = True
            break
        if answer in ("n", "no"):
            result = False
            break
        if answer == "" and default is not None:
            result = default
            break
    if not result and abort:
        raise Abort()
    return result


def _terminal_fd():
    try:
        if _isatty(sys.stdin):
            return sys.stdin.fileno(), False
        return os.open("/dev/tty", os.O_RDONLY), True
    except (OSError, ValueError, io.UnsupportedOperation):
        return None, False


def getchar(echo=False):
    """Read one character from the terminal (not from a pipe)."""
    fd, opened = _terminal_fd()
    ch = None
    if fd is not None:
        try:
            import termios
            import tty

            old = termios.tcgetattr(fd)
            try:
                tty.setraw(fd)
                data = os.read(fd, 1)
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
            ch = data.decode("utf-8", "replace")
        except (ImportError, OSError, ValueError):
            ch = None
        finally:
            if opened:
                os.close(fd)
    if ch is None:
        ch = sys.stdin.read(1)
    if ch == "":
        raise EOFError()
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    if echo:
        sys.stdout.write(ch)
        sys.stdout.flush()
    return ch





def pause(info=None, err=False):
    """Print a message and wait for a key when interactive; do nothing otherwise."""
    if not is_interactive():
        return
    if info is None:
        info = "Press any key to continue..."
    echo(info, err=err, nl=False)
    try:
        getchar()
    except (EOFError, KeyboardInterrupt):
        pass
    echo(err=err)


def clear():
    """Clear the terminal screen when connected to one."""
    if _isatty(sys.stdout):
        sys.stdout.write("\033[2J\033[H")
        sys.stdout.flush()


# --- pager -------------------------------------------------------------------

def _pager_command():
    return os.environ.get("PAGER") or "less"


class _PagerWriter(io.TextIOBase):
    """Writes text to a pager process's stdin, flushing every chunk."""

    def __init__(self, proc, color):
        self.proc = proc
        self.color = color

    def writable(self):
        return True

    def write(self, text):
        if not self.color:
            text = unstyle(text)
        data = text.encode("utf-8", "replace")
        self.proc.stdin.write(data)
        self.proc.stdin.flush()
        return len(text)


@contextlib.contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream that feeds the pager (or stdout when not interactive)."""
    if not is_interactive():
        yield sys.stdout
        return
    cmd = _pager_command()
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE)
    writer = _PagerWriter(proc, color if color is not None else False)
    try:
        yield writer
    finally:
        try:
            proc.stdin.close()
        except BrokenPipeError:
            pass
        proc.wait()


def echo_via_pager(text_or_generator, color=None):
    """Write long text through a pager when interactive."""
    if callable(text_or_generator) and not isinstance(text_or_generator, str):
        chunks = text_or_generator()
    else:
        chunks = text_or_generator
    if isinstance(chunks, str):
        chunks = [chunks]
    with get_pager_file(color=color) as f:
        for chunk in chunks:
            if isinstance(f, _PagerWriter):
                f.write(chunk)
            else:
                f.write(chunk if color is not False else unstyle(chunk))
                f.flush()


# --- progress bars -----------------------------------------------------------

class ProgressBar:
    """Progress bar wrapping an iterable and/or a known length."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, **options):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label or ""
        self.pos = 0
        self.explicit_hidden = bool(hidden)
        self.hidden = self.explicit_hidden or not _isatty(sys.stdout)
        self.start = time.time()
        self._printed_label = False
        self.options = options

    def _render(self):
        if self.hidden:
            return
        if self.length:
            pct = min(self.pos / self.length, 1.0)
            filled = int(pct * 30)
            bar = "#" * filled + "-" * (30 - filled)
            elapsed = time.time() - self.start
            if self.pos > 0:
                eta = elapsed / self.pos * (self.length - self.pos)
            else:
                eta = 0
            line = f"\r{self.label} [{bar}] {self.pos}/{self.length} eta {int(eta)}s"
        else:
            line = f"\r{self.label} {self.pos}"
        sys.stdout.write(line)
        sys.stdout.flush()

    def update(self, n_steps):
        self.pos += n_steps
        self._render()

    def __iter__(self):
        if self.iterable is None:
            raise TypeError("No iterable was given.")
        for item in self.iterable:
            yield item
            self.update(1)

    def __enter__(self):
        if not _isatty(sys.stdout) and self.label and not self.explicit_hidden:
            sys.stdout.write(self.label + "\n")
            self._printed_label = True
        return self

    def __exit__(self, exc_type, exc, tb):
        if not self.hidden and _isatty(sys.stdout):
            sys.stdout.write("\n")
            sys.stdout.flush()
        return False


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    """Return a progress bar context manager."""
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)


# --- editor / launch ---------------------------------------------------------

def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Open an editor; return the saved text, or None when not saved / filename given."""
    editor = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR") or "vi"
    if filename is not None:
        path = os.fspath(filename)
        subprocess.call(_editor_argv(editor, path), env=env)
        return None
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(text or "")
        mtime = os.path.getmtime(path)
        subprocess.call(_editor_argv(editor, path), env=env)
        with open(path, encoding="utf-8", newline="") as f:
            result = f.read()
        if require_save and os.path.getmtime(path) == mtime:
            return None
        return result
    finally:
        os.unlink(path)


def _editor_argv(editor, path):
    import shlex

    return shlex.split(editor) + [path]


def launch(url, wait=False, locate=False):
    """Open ``url`` or a path with the default application."""
    if sys.platform == "darwin":
        argv = ["open"]
    elif sys.platform == "win32":
        os.startfile(url)  # noqa: S606
        return 0
    else:
        argv = ["xdg-open"]
    if locate and sys.platform == "darwin":
        argv.append("-R")
    argv.append(url)
    proc = subprocess.Popen(argv)
    if wait:
        return proc.wait()
    return 0


# --- app directories and filenames -------------------------------------------

def get_app_dir(app_name, roaming=True, force_posix=False):
    """Return the per-user config directory for ``app_name``."""
    if sys.platform == "darwin" and not force_posix:
        return os.path.join(os.path.expanduser("~/Library/Application Support"), app_name)
    if sys.platform == "win32" and not force_posix:
        base = os.environ.get("APPDATA") or os.path.expanduser("~")
        return os.path.join(base, app_name)
    if force_posix:
        return os.path.join(os.path.expanduser("~"), "." + _posix_name(app_name))
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
    return os.path.join(base, _posix_name(app_name))


def _posix_name(app_name):
    return re.sub(r"\s+", "-", app_name.lower())


def format_filename(filename, shorten=False):
    """Return a printable text form of ``filename``."""
    if isinstance(filename, (bytes, bytearray)):
        text = os.fsdecode(bytes(filename))
    else:
        text = os.fspath(filename)
    if shorten:
        text = os.path.basename(text)
    return text.encode("utf-8", "surrogateescape").decode("utf-8", "replace")


# --- file opening ------------------------------------------------------------

class LazyFile:
    """Opens the real file on first I/O (for write modes by default)."""

    def __init__(self, filename, mode, encoding, errors, atomic=False):
        self.name = filename
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self._tmp = None

    def _open(self):
        if self._f is not None:
            return self._f
        try:
            if self.atomic and "w" in self.mode:
                directory = os.path.dirname(os.path.abspath(self.name))
                fd, self._tmp = tempfile.mkstemp(dir=directory, prefix=".__atomic-write")
                os.close(fd)
                target = self._tmp
            else:
                target = self.name
            self._f = _open_real(target, self.mode, self.encoding, self.errors)
        except OSError as exc:
            from .exceptions import FileError

            raise FileError(self.name, f"Could not open file {self.name}: {exc.strerror or exc}")
        return self._f

    def __getattr__(self, name):
        return getattr(self._open(), name)

    def __iter__(self):
        return iter(self._open())

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    def close(self):
        if self._f is not None:
            self._f.close()
            if self._tmp is not None:
                os.replace(self._tmp, self.name)
                self._tmp = None
        elif self._tmp is not None:
            os.unlink(self._tmp)
            self._tmp = None


def _open_real(path, mode, encoding, errors):
    if "b" in mode:
        return open(path, mode)
    return open(path, mode, encoding=encoding, errors=errors)


class _StdStream:
    """Standard stream that is not closed when the caller's block ends."""

    def __init__(self, stream):
        self._s = stream

    def __getattr__(self, name):
        return getattr(self._s, name)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self._s.flush()
        return False

    def __iter__(self):
        return iter(self._s)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file, or a standard stream when ``filename`` is ``-``."""
    filename = os.fspath(filename) if not isinstance(filename, str) else filename
    if filename == "-":
        reading = "r" in mode
        if reading:
            stream = sys.stdin.buffer if "b" in mode else sys.stdin
        else:
            stream = sys.stdout.buffer if "b" in mode else sys.stdout
        return _StdStream(stream)
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    try:
        if atomic and "w" in mode:
            lf = LazyFile(filename, mode, encoding, errors, atomic=True)
            lf._open()
            return lf
        return _open_real(filename, mode, encoding, errors)
    except OSError as exc:
        from .exceptions import FileError

        raise FileError(filename, f"Could not open file {filename}: {exc.strerror or exc}")


def get_binary_stdin():
    return sys.stdin.buffer


def get_binary_stdout():
    return sys.stdout.buffer


def get_binary_stderr():
    return sys.stderr.buffer


def get_text_stdin(encoding=None, errors=None):
    return sys.stdin


def get_text_stdout(encoding=None, errors=None):
    return sys.stdout


def get_text_stderr(encoding=None, errors=None):
    return sys.stderr
