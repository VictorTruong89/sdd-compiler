"""Shell completion (FP-12): registration scripts and suggestion streams."""

import os
import sys

from .context import Context
from .params import Argument, Option

SHELLS = ("bash", "zsh", "fish", "powershell")
PATH_DIR = "_path:dir:"
PATH_FILE = "_path:file:"


class CompletionItem:
    """A suggestion with optional help and a type (``plain`` for ordinary values)."""

    def __init__(self, value, help=None, type="plain"):
        self.value = value
        self.help = help
        self.type = type


def complete_var_name(prog_name):
    return "_" + prog_name.replace("-", "_").upper() + "_COMPLETE"


def maybe_complete(cli, prog_name, complete_var, args):
    """Handle completion mode. Return None when not in completion mode, else an exit code."""
    var = complete_var or complete_var_name(os.path.basename(prog_name))
    value = os.environ.get(var)
    if not value:
        return None
    if value.endswith("_source"):
        shell = value[: -len("_source")]
        if shell not in SHELLS:
            return 1
        sys.stdout.write(_source_script(shell, var, prog_name))
        sys.stdout.flush()
        return 0
    if value.endswith("_complete"):
        shell = value[: -len("_complete")]
        if shell not in SHELLS:
            return 1
        for line in _suggestions(cli, prog_name, shell):
            sys.stdout.write(line + "\n")
        sys.stdout.flush()
        return 0
    return 1


def _read_words(shell):
    line = os.environ.get("COMP_WORDS", "")
    words = line.split(" ")
    if shell == "fish":
        incomplete = os.environ.get("COMP_CWORD", "")
        while words and words[-1] == "":
            words.pop()
        if incomplete and words and words[-1] == incomplete:
            words.pop()
        return words, incomplete
    try:
        cword = int(os.environ.get("COMP_CWORD", str(len(words))))
    except ValueError:
        cword = len(words)
    incomplete = words[cword] if 0 <= cword < len(words) else ""
    return words[:cword], incomplete


def _suggestions(cli, prog_name, shell):
    words, incomplete = _read_words(shell)
    args = words[1:]
    cmd = cli
    ctx = Context(cli, info_name=prog_name)
    # Walk down through subcommands already named on the line.
    idx = 0
    while idx < len(args):
        tok = args[idx]
        if isinstance(cmd, _group_type()) and not tok.startswith("-"):
            child = cmd.get_command(ctx, tok)
            if child is not None:
                ctx = Context(child, parent=ctx, info_name=tok)
                cmd = child
                args = args[idx + 1:]
                idx = 0
                continue
        idx += 1

    pending = None
    if args and args[-1].startswith("-") and not incomplete.startswith("-"):
        pending = _option_by_name(cmd, ctx, args[-1])
        if pending is not None and (pending.is_flag or pending.count):
            pending = None

    if pending is not None:
        items = _value_items(ctx, pending, incomplete)
    else:
        items = []
        if incomplete.startswith("-"):
            items.extend(_option_items(cmd, ctx, incomplete))
        elif isinstance(cmd, _group_type()):
            for name in cmd.list_commands(ctx):
                child = cmd.get_command(ctx, name)
                if child is None or child.hidden or not name.startswith(incomplete):
                    continue
                items.append(CompletionItem(name, help=child.get_short_help_str(45)))
        else:
            items.extend(_argument_items(cmd, ctx, incomplete))

    return [_format(item, shell) for item in items]


def _group_type():
    from .core import Group

    return Group


def _visible_options(cmd, ctx):
    return [p for p in cmd.get_params(ctx) if isinstance(p, Option) and not p.hidden]


def _option_by_name(cmd, ctx, token):
    for opt in _visible_options(cmd, ctx) + [p for p in cmd.get_params(ctx) if isinstance(p, Option)]:
        if token in opt.all_names:
            return opt
    return None


def _option_items(cmd, ctx, incomplete):
    items = []
    for opt in _visible_options(cmd, ctx):
        for name in opt.opts + opt.secondary_opts:
            if name.startswith(incomplete) and not _is_hidden(opt):
                items.append(CompletionItem(name, help=opt.help))
    return items


def _is_hidden(opt):
    return bool(opt.hidden)


def _value_items(ctx, opt, incomplete):
    result = opt.shell_complete(ctx, incomplete)
    return _normalize(result, incomplete)


def _argument_items(cmd, ctx, incomplete):
    items = []
    for arg in cmd.get_params(ctx):
        if isinstance(arg, Argument) and arg.expose_value:
            result = arg.shell_complete(ctx, incomplete)
            items.extend(_normalize(result, incomplete))
            break
    return items


def _normalize(result, incomplete):
    out = []
    for item in result or []:
        if isinstance(item, CompletionItem):
            out.append(item)
        elif hasattr(item, "value"):
            out.append(CompletionItem(item.value, help=getattr(item, "help", None),
                                      type=getattr(item, "type", "plain")))
        else:
            out.append(CompletionItem(str(item)))
    return out


def _format(item, shell):
    if item.type == "dir":
        return PATH_DIR + item.value
    if item.type == "file":
        return PATH_FILE + item.value
    if item.help and shell in ("zsh", "fish"):
        return f"{item.value}\t{item.help}"
    return item.value


def _source_script(shell, var, prog_name):
    fn = "_" + prog_name.replace("-", "_").replace(".", "_") + "_completion"
    if shell == "bash":
        return (
            f"{fn}() {{\n"
            "    local IFS=$'\\n'\n"
            "    local response completion\n"
            f"    response=$(env COMP_WORDS=\"${{COMP_WORDS[*]}}\" COMP_CWORD=$COMP_CWORD "
            f"{var}=bash_complete {prog_name} 2>/dev/null)\n"
            "    COMPREPLY=()\n"
            "    for completion in $response; do\n"
            f"        case $completion in\n"
            f"            {PATH_DIR}*) COMPREPLY+=($(compgen -d -- \"${{COMP_WORDS[COMP_CWORD]}}\"));;\n"
            f"            {PATH_FILE}*) COMPREPLY+=($(compgen -f -- \"${{COMP_WORDS[COMP_CWORD]}}\"));;\n"
            "            *) COMPREPLY+=(\"$completion\");;\n"
            "        esac\n"
            "    done\n"
            "}\n"
            f"complete -o default -F {fn} {prog_name}\n"
        )
    if shell == "zsh":
        return (
            f"#compdef {prog_name}\n"
            f"{fn}() {{\n"
            "    local -a completions\n"
            f"    completions=(\"${{(@f)$(env COMP_WORDS=\"${{words[*]}}\" COMP_CWORD=$((CURRENT-1)) "
            f"{var}=zsh_complete {prog_name} 2>/dev/null)}}\")\n"
            "    _describe 'values' completions\n"
            "}\n"
            f"compdef {fn} {prog_name}\n"
        )
    if shell == "fish":
        return (
            f"function {fn}\n"
            f"    set -l response (env {var}=fish_complete COMP_WORDS=\"(commandline -cp)\" "
            f"COMP_CWORD=\"(commandline -ct)\" {prog_name} 2>/dev/null)\n"
            "    for completion in $response\n"
            "        echo $completion\n"
            "    end\n"
            "end\n"
            f"complete -c {prog_name} -f -a '({fn})'\n"
        )
    return (
        f"Register-ArgumentCompleter -Native -CommandName {prog_name} -ScriptBlock {{\n"
        "    param($wordToComplete, $commandAst, $cursorPosition)\n"
        f"    $env:{var} = 'powershell_complete'\n"
        "    $env:COMP_WORDS = $commandAst.ToString()\n"
        "    $env:COMP_CWORD = $commandAst.CommandElements.Count\n"
        f"    & {prog_name} | ForEach-Object {{ [System.Management.Automation.CompletionResult]::new($_, $_, 'ParameterValue', $_) }}\n"
        "    Remove-Item Env:\\" + var + "\n"
        "}\n"
    )
