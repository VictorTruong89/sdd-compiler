"""Commands, groups, command collections, parsing and dispatch (FP-01, FP-06, FP-10, FP-13)."""

import os
import sys

from .context import Context, ParameterSource
from .exceptions import (
    Abort,
    BadOptionUsage,
    Exit,
    MissingParameter,
    NoSuchCommand,
    OptlynError,
    UsageError,
)
from .formatting import HelpFormatter, clean_help_text, get_width, truncate
from .params import Argument, Option
from .parser import OptionTable, scan
from .termui import echo

CHAIN_MARKER = "*"
_RANK = {
    ParameterSource.PROMPT: 5,
    ParameterSource.COMMANDLINE: 4,
    ParameterSource.ENVIRONMENT: 3,
    ParameterSource.DEFAULT_MAP: 2,
    ParameterSource.DEFAULT: 1,
}


class NoArgsHelp(UsageError):
    """Usage failure raised after the help page was shown on stderr."""

    def show(self, file=None):
        return None


def _help_callback(ctx, param, value):
    if not value:
        return value
    ctx.command.format_help(ctx, sys.stdout)
    raise Exit(0)


class Command:
    """A leaf command: parses its options and arguments and runs a callback."""

    allow_interspersed_args = True

    def __init__(
        self,
        name,
        callback=None,
        params=None,
        help=None,
        epilog=None,
        short_help=None,
        options_metavar="[OPTIONS]",
        add_help_option=True,
        no_args_is_help=False,
        hidden=False,
        deprecated=False,
        context_settings=None,
        allow_interspersed_args=None,
        **extra,
    ):
        self.name = name
        if allow_interspersed_args is not None:
            self.allow_interspersed_args = allow_interspersed_args
        self.callback = callback
        self.params = list(params or [])
        self.help = clean_help_text(help)
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = deprecated
        self.context_settings = dict(context_settings or {})

    # --- deprecation text -----------------------------------------------------

    @property
    def deprecated_note(self):
        if isinstance(self.deprecated, str):
            return self.deprecated
        return None

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    # --- parameters -----------------------------------------------------------

    def get_params(self, ctx):
        params = list(self.params)
        if self.add_help_option:
            own = set()
            for p in self.params:
                if isinstance(p, Option):
                    own.update(p.all_names)
            names = [n for n in ctx.help_option_names if n not in own]
            if names:
                params.append(Option(
                    names,
                    is_flag=True,
                    is_eager=True,
                    expose_value=False,
                    callback=_help_callback,
                    help="Show this message and exit.",
                ))
        return params

    def _expose_names(self, ctx):
        return [p.name for p in self.get_params(ctx) if p.expose_value and p.name]

    # --- parsing --------------------------------------------------------------

    def make_context(self, info_name, args, parent=None, chain=False, **extra):
        ctx = Context(self, parent=parent, info_name=info_name, **extra)
        ctx.push()
        try:
            leftover = self.parse_args(ctx, args, chain=chain)
        except BaseException:
            ctx.pop()
            ctx.close()
            raise
        ctx.pop()
        ctx.args = leftover
        return ctx

    def parse_args(self, ctx, args, chain=False):
        """Bind this command's parameters from ``args``; return the leftover tokens."""
        params = self.get_params(ctx)
        opts = [p for p in params if isinstance(p, Option)]
        arguments = [p for p in params if isinstance(p, Argument)]

        table = OptionTable(normalize=ctx.token_normalize_func)
        for opt in opts:
            for n in opt.opts:
                table.add(n, opt)
            for n in opt.secondary_opts:
                table.add(n, opt, secondary=True)

        interspersed = ctx.allow_interspersed_args and not chain
        sub_after = self._sub_after(arguments)
        result = scan(
            list(args),
            table,
            interspersed=interspersed,
            ignore_unknown=ctx.ignore_unknown_options,
            sub_after=sub_after,
            ctx=ctx,
        )

        hits = {}
        order = []
        for opt, tokens, secondary in result.hits:
            if id(opt) not in hits:
                hits[id(opt)] = []
                order.append(opt)
            hits[id(opt)].append((tokens, secondary))

        # Eager parameters take effect in the order the user typed them.
        for opt in order:
            if opt.is_eager:
                self._bind_options(ctx, [opt], hits)

        arg_tokens = self._assign_arguments(ctx, arguments, result.positionals)

        self._bind_options(ctx, [o for o in opts if not o.is_eager], hits)
        for arg in arguments:
            tokens = arg_tokens.get(id(arg), [])
            if tokens and arg.deprecated:
                echo(f"DeprecationWarning: The argument '{arg.name}' is deprecated.", err=True)
            value, source = arg.resolve(ctx, tokens)
            value = arg.process_value(ctx, value)
            self._store(ctx, arg, value, source)

        if isinstance(self, Group):
            return self._group_leftover(ctx, result, arg_tokens, arguments, chain)

        leftover = result.positionals[self._consumed_count(arguments, arg_tokens):]
        if leftover:
            if chain or ctx.allow_extra_args:
                return leftover
            raise UsageError(
                f"Got unexpected extra argument{'s' if len(leftover) > 1 else ''} "
                f"({' '.join(leftover)})",
                ctx=ctx,
            )
        return []

    def _sub_after(self, arguments):
        return None

    def _consumed_count(self, arguments, arg_tokens):
        return sum(len(arg_tokens.get(id(a), [])) for a in arguments)

    def _assign_arguments(self, ctx, arguments, tokens):
        """Split positional tokens among the arguments by arity."""
        out = {}
        pos = 0
        for i, arg in enumerate(arguments):
            if arg.variadic:
                following = 0
                for later in arguments[i + 1:]:
                    if not later.variadic:
                        following += later.nargs
                take = max(len(tokens) - pos - following, 0)
                out[id(arg)] = tokens[pos:pos + take]
                pos += take
                continue
            need = arg.nargs
            available = tokens[pos:pos + need]
            if 0 < len(available) < need:
                raise BadOptionUsage(f"Argument '{arg.name}' takes {need} values.", ctx=ctx)
            out[id(arg)] = available
            pos += len(available)
        return out

    def _group_leftover(self, ctx, result, arg_tokens, arguments, chain):
        leftover = result.positionals[self._consumed_count(arguments, arg_tokens):]
        if chain:
            return leftover
        if result.sub_name is not None:
            return [result.sub_name] + result.sub_rest
        return []

    def _bind_options(self, ctx, opts, hits):
        """Resolve options; options sharing a destination (feature switches) pick one winner."""
        by_name = {}
        for index, opt in enumerate(opts):
            by_name.setdefault(opt.name, []).append((index, opt))
        for members in by_name.values():
            candidates = []
            for index, opt in members:
                value, source, explicit = self._resolve_option(ctx, opt, hits.get(id(opt), []))
                value = opt.process_value(ctx, value)
                candidates.append((_RANK[source], explicit, index, opt, value, source))
            winner = max(candidates, key=lambda c: c[:3])
            for _rank, _explicit, _index, opt, value, source in candidates:
                if opt is winner[3]:
                    self._store(ctx, opt, value, source)

    def _resolve_option(self, ctx, opt, hits):
        if opt.deprecated and hits:
            echo(f"DeprecationWarning: The option '{opt.opts_text()}' is deprecated.", err=True)
        value, source, explicit = opt.resolve(ctx, hits)
        if opt.required and source is ParameterSource.DEFAULT and value is None \
                and not opt.is_flag and not opt.count:
            raise MissingParameter(ctx=ctx, param=opt)
        return value, source, explicit

    def _store(self, ctx, param, value, source):
        if param.expose_value and param.name:
            ctx.params[param.name] = value
            ctx._set_source(param.name, source)

    # --- invocation -----------------------------------------------------------

    def invoke(self, ctx):
        if self.deprecated:
            note = self.deprecated_note
            msg = f"DeprecationWarning: The command '{self.name}' is deprecated."
            if note:
                msg += f" {note}"
            echo(msg, err=True)
        return self.invoke_callback(ctx, ctx.params)

    def invoke_callback(self, ctx, values):
        if self.callback is None:
            return None
        kwargs = {}
        for name in self._expose_names(ctx):
            kwargs[name] = values.get(name)
        return self.callback(**kwargs)

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True, **extra):
        if args is None:
            args = sys.argv[1:]
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else "cli"

        from .completion import maybe_complete

        completion_status = maybe_complete(self, prog_name, complete_var, list(args))
        if completion_status is not None:
            if standalone_mode:
                sys.exit(completion_status)
            return completion_status

        try:
            ctx = self.make_context(prog_name, list(args), **extra)
            with ctx:
                rv = self.invoke(ctx)
                if not standalone_mode:
                    return rv
                raise Exit(0)
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return e.exit_code
        except OptlynError as e:
            if not standalone_mode:
                raise
            e.show()
            sys.exit(e.exit_code)
        except (KeyboardInterrupt, EOFError):
            if not standalone_mode:
                raise
            Abort().show()
            sys.exit(1)

    # --- help -----------------------------------------------------------------

    def get_short_help_str(self, limit=45):
        if self.short_help:
            return self.short_help
        if not self.help:
            return ""
        first = self.help.strip().split("\n\n", 1)[0]
        text = " ".join(first.split())
        return truncate(text, limit)

    def get_usage(self, ctx):
        pieces = [ctx.command_path]
        params = self.get_params(ctx)
        if any(isinstance(p, Option) and p.name for p in params):
            pieces.append(self.options_metavar)
        for arg in (p for p in params if isinstance(p, Argument)):
            pieces.append(_argument_usage(arg))
        return "Usage: " + " ".join(pieces)

    def format_help(self, ctx, file=None):
        file = file or sys.stdout
        echo(self.get_help(ctx), file=file, nl=False)

    def get_help(self, ctx):
        width = get_width(ctx.terminal_width, ctx.max_content_width)
        fmt = HelpFormatter(width=width)
        fmt.write(self.get_usage(ctx))
        fmt.write("")
        if self.deprecated:
            fmt.write("DEPRECATED" + (f": {self.deprecated_note}" if self.deprecated_note else ""))
            fmt.write("")
        if self.help:
            fmt.write_paragraph(self.help)
            fmt.write("")
        params = self.get_params(ctx)
        args = [p for p in params if isinstance(p, Argument) and p.help]
        if args:
            fmt.write_section("Positional arguments", [(_arg_placeholder(a), a.help) for a in args])
        opts = [p for p in params if isinstance(p, Option) and not p.hidden]
        rows = [(_option_head(p), _option_help(ctx, p)) for p in opts]
        if rows:
            fmt.write_section("Options", rows)
        self.format_extra_sections(ctx, fmt)
        if self.epilog:
            fmt.write_paragraph(self.epilog)
            fmt.write("")
        return fmt.getvalue()

    def format_extra_sections(self, ctx, fmt):
        return None


def _arg_placeholder(arg):
    return arg.get_metavar_text()


def _argument_usage(arg):
    name = arg.get_metavar_text()
    if arg.variadic:
        text = f"[{name}]..." if not arg.required else f"{name}..."
    else:
        text = name if arg.required else f"[{name}]"
    return text


def _option_head(opt):
    names = ", ".join(opt.opts + opt.secondary_opts) if opt.secondary_opts else ", ".join(opt.opts)
    meta = opt.get_metavar_text()
    if meta:
        names = f"{names} {meta}"
    return names


def _option_help(ctx, opt):
    parts = []
    if opt.help:
        parts.append(opt.help)
    from .paramtypes import Choice

    if isinstance(opt.type, Choice):
        parts.append("[" + "|".join(str(n) for n in opt.type._names) + "]")
    show = opt.show_default if opt.show_default is not None else ctx.show_default
    if show and opt.default is not None and not (opt.is_flag and opt.default is False):
        if isinstance(show, str):
            parts.append(f"[default: {show}]")
        else:
            default = opt.default() if callable(opt.default) else opt.default
            parts.append(f"[default: {default}]")
    if opt.show_envvar and opt.envvar:
        names = [opt.envvar] if isinstance(opt.envvar, str) else list(opt.envvar)
        parts.append(f"[env var: {names[0]}]")
    if opt.deprecated:
        parts.append("(DEPRECATED)")
    return " ".join(parts)


class Group(Command):
    """A command that dispatches to named subcommands."""

    allow_interspersed_args = False

    def __init__(
        self,
        name=None,
        commands=None,
        invoke_without_command=False,
        no_args_is_help=None,
        subcommand_metavar=None,
        chain=False,
        result_callback=None,
        **kwargs,
    ):
        super().__init__(name, **kwargs)
        self.commands = dict(commands or {})
        self.invoke_without_command = invoke_without_command
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        self.no_args_is_help = no_args_is_help
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback

    def add_command(self, cmd, name=None):
        name = name or cmd.name
        if self.chain and isinstance(cmd, Group):
            raise TypeError("Groups cannot be attached beneath a chaining group.")
        self.commands[name] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command

        def decorator(f):
            cmd = command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        if args and callable(args[0]) and len(args) == 1 and not kwargs:
            return decorator(args[0])
        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group

        def decorator(f):
            cmd = group(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        if args and callable(args[0]) and len(args) == 1 and not kwargs:
            return decorator(args[0])
        return decorator

    def result_callback(self, f=None):
        """Register the result callback; ``@group.result_callback()`` returns a decorator."""
        def decorator(func):
            self._result_callback = func
            return func

        if f is not None:
            return decorator(f)
        return decorator

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        if ctx.token_normalize_func is not None:
            norm = ctx.token_normalize_func(cmd_name)
            for name, cmd in self.commands.items():
                if ctx.token_normalize_func(name) == norm:
                    return cmd
            return None
        return self.commands.get(cmd_name)

    def _sub_after(self, arguments):
        if self.chain:
            return None
        if any(a.variadic for a in arguments):
            return None
        return sum(a.nargs for a in arguments)

    def _consumed_count(self, arguments, arg_tokens):
        return sum(len(arg_tokens.get(id(a), [])) for a in arguments)

    def parse_args(self, ctx, args, chain=False):
        if not args and self.no_args_is_help and not self.invoke_without_command:
            self.format_help(ctx, sys.stderr)
            raise NoArgsHelp("")
        leftover = super().parse_args(ctx, args, chain=chain or self.chain)
        if self.chain:
            ctx.invoked_subcommand = CHAIN_MARKER
        if not leftover and not self.invoke_without_command:
            raise UsageError("Missing command.", ctx=ctx)
        return leftover

    def format_extra_sections(self, ctx, fmt):
        commands = self._visible_commands(ctx)
        if commands:
            fmt.write_section("Commands", commands)

    def _visible_commands(self, ctx):
        rows = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            rows.append((name, cmd.get_short_help_str(45)))
        return rows

    def get_usage(self, ctx):
        base = super().get_usage(ctx)
        if self.chain:
            return base + " COMMAND [ARGS]... [COMMAND [ARGS]...]..."
        if self.invoke_without_command:
            return base + " [COMMAND] [ARGS]..."
        return base + " COMMAND [ARGS]..."

    def invoke(self, ctx):
        if self.chain:
            return self._invoke_chain(ctx)
        if not ctx.args:
            return self.invoke_callback(ctx, ctx.params)

        name = ctx.args[0]
        cmd = self.get_command(ctx, name)
        if cmd is None:
            raise NoSuchCommand(name, ctx=ctx)

        ctx.invoked_subcommand = cmd.name
        if self.deprecated:
            echo(f"DeprecationWarning: The command '{self.name}' is deprecated.", err=True)
        self.invoke_callback(ctx, ctx.params)

        sub_ctx = cmd.make_context(name, ctx.args[1:], parent=ctx)
        with sub_ctx:
            value = cmd.invoke(sub_ctx)
        if self._result_callback is not None:
            return self._result_callback(value, **ctx.params)
        return value

    def _invoke_chain(self, ctx):
        self.invoke_callback(ctx, ctx.params)
        values = []
        rest = list(ctx.args)
        while rest:
            name = rest[0]
            cmd = self.get_command(ctx, name)
            if cmd is None:
                raise NoSuchCommand(name, ctx=ctx)
            sub_ctx = cmd.make_context(name, rest[1:], parent=ctx, chain=True)
            with sub_ctx:
                values.append(cmd.invoke(sub_ctx))
            rest = list(sub_ctx.args)
        if self._result_callback is not None:
            return self._result_callback(values, **ctx.params)
        return values


class CommandCollection(Group):
    """Presents the subcommands of several groups under one dispatch surface."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = set()
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None


__all__ = ["Command", "Group", "CommandCollection", "CHAIN_MARKER"]
