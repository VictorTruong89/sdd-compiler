"""Exception classes used by Optlyn.

Exit-status classes (see the interface contract, section 2):

* ``UsageError`` (and subclasses) -> status 2
* ``Abort`` and ``FileError`` -> status 1
* ``Exit`` -> the author's status (default 0)
"""


class OptlynError(Exception):
    """Base class for every error raised by Optlyn."""

    exit_code = 1

    def __init__(self, message=None):
        super().__init__(message)
        self.message = message

    def format_message(self):
        return "" if self.message is None else str(self.message)

    def show(self, file=None):
        import sys

        from .termui import echo

        echo(self.format_message(), file=file or sys.stderr, err=True)


class UsageError(OptlynError):
    """Incorrect command-line usage (exit status 2)."""

    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.ctx = ctx

    def format_message(self):
        return f"Error: {self.message}"

    def show(self, file=None):
        import sys

        from .termui import echo

        echo(self.format_message(), file=file or sys.stderr, err=True)
        if self.ctx is not None and self.ctx.command is not None:
            hint = self.ctx.get_help_option_hint()
            if hint:
                echo(hint, file=file or sys.stderr, err=True)


class BadParameter(UsageError):
    """A value was refused. Raised from callbacks, types and conversion functions."""

    def __init__(self, message=None, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx=ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint()
        if hint:
            return f"Invalid value for {hint}: {self.message}"
        return f"Invalid value: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter was not supplied."""

    def format_message(self):
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint()
        return f"Missing parameter {hint}" if hint else "Missing parameter"


class NoSuchOption(UsageError):
    """An unknown option token."""

    def __init__(self, option_name, message=None, ctx=None):
        super().__init__(message or f"No such option: {option_name}", ctx=ctx)
        self.option_name = option_name


class BadOptionUsage(UsageError):
    """Usage problem with an option that is not a value conversion problem."""


class BadArgumentUsage(UsageError):
    """Usage problem with an argument that is not a value conversion problem."""


class UsageMissingCommand(UsageError):
    """A group was invoked without a subcommand name."""


class NoSuchCommand(UsageError):
    """An unknown subcommand name."""

    def __init__(self, name, ctx=None):
        super().__init__(f"No such command {name!r}.", ctx=ctx)
        self.name = name


class Abort(OptlynError):
    """Abort indication (exit status 1)."""

    exit_code = 1

    def format_message(self):
        return "Aborted!"


class FileError(OptlynError):
    """A file could not be opened at first I/O (general error, exit status 1)."""

    exit_code = 1

    def __init__(self, filename, message=None):
        super().__init__(message or f"Could not open file {filename}")
        self.filename = filename


class Exit(Exception):
    """Author clean stop with a status (``ctx.exit``)."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code


class Interrupted(Abort):
    """Keyboard interrupt translated into an abort."""
