import re
import sys

_ansi_re = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")


def strip_ansi(value):
    return _ansi_re.sub("", value)


def isatty(stream):
    try:
        return stream.isatty()
    except Exception:
        return False


def should_strip_ansi(stream=None, color=None):
    if color is None:
        if stream is None:
            stream = sys.stdin
        return not isatty(stream)
    return not color


def is_interactive():
    return isatty(sys.stdin) or isatty(sys.stdout)


def is_ascii_encoding(stream):
    enc = (getattr(stream, "encoding", None) or "").lower().replace("_", "-")
    return enc in ("ascii", "us-ascii", "ansi-x3.4-1968", "646")


def find_binary_writer(stream):
    buf = getattr(stream, "buffer", None)
    if buf is not None:
        return buf
    import io

    if isinstance(stream, (io.RawIOBase, io.BufferedIOBase)):
        return stream
    return None
