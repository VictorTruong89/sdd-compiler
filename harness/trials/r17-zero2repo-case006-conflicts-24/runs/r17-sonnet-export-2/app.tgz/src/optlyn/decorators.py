import inspect
from functools import update_wrapper

from .core import Argument, Command, Group, Option
from .globals import get_current_context
from .utils import echo

_SUFFIXES = ("_command", "_cmd", "_group", "_grp")


def pass_context(f):
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return update_wrapper(new_func, f)


def pass_obj(f):
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return update_wrapper(new_func, f)


def make_pass_decorator(object_type, ensure=False):
    def decorator(f):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            obj = ctx.ensure_object(object_type) if ensure else ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(
                    f"Managed to invoke callback without a context object of type "
                    f"{object_type.__name__!r} existing.")
            return f(obj, *args, **kwargs)

        return update_wrapper(new_func, f)

    return decorator


def _param_memo(f, param):
    if isinstance(f, Command):
        f.params.append(param)
    else:
        if not hasattr(f, "__optlyn_params__"):
            f.__optlyn_params__ = []
        f.__optlyn_params__.append(param)


def _derive_name(f):
    name = f.__name__.lower().replace("_", "-")
    for suffix in _SUFFIXES:
        s = suffix.replace("_", "-")
        if name.endswith(s) and len(name) > len(s):
            return name[: -len(s)]
    return name


def _make(default_cls, name, cls, attrs):
    func = None
    if callable(name) and not isinstance(name, str):
        func = name
        name = None
    if cls is None:
        cls = default_cls

    def decorator(f):
        if isinstance(f, Command):
            raise TypeError("Attempted to convert a callback into a command twice.")
        a = dict(attrs)
        params = list(a.pop("params", None) or [])
        decl = getattr(f, "__optlyn_params__", None)
        if decl is not None:
            del f.__optlyn_params__
            params.extend(reversed(decl))
        if a.get("help") is None:
            a["help"] = inspect.getdoc(f)
        cmd = cls(name=name or _derive_name(f), callback=f, params=params, **a)
        cmd.__doc__ = f.__doc__
        return cmd

    if func is not None:
        return decorator(func)
    return decorator


def command(name=None, cls=None, **attrs):
    return _make(Command, name, cls, attrs)


def group(name=None, cls=None, **attrs):
    return _make(Group, name, cls, attrs)


def option(*param_decls, cls=None, **attrs):
    def decorator(f):
        _param_memo(f, (cls or Option)(param_decls, **attrs))
        return f

    return decorator


def argument(*param_decls, cls=None, **attrs):
    def decorator(f):
        _param_memo(f, (cls or Argument)(param_decls, **attrs))
        return f

    return decorator


def help_option(*param_decls, **kwargs):
    def show_help(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(ctx.get_help(), color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", show_help)
    return option(*param_decls, **kwargs)


def version_option(version=None, *param_decls, package_name=None, prog_name=None,
                   message=None, **kwargs):
    if message is None:
        message = "%(prog)s, version %(version)s"
    if version is None and package_name is None:
        frame = inspect.currentframe()
        f_back = frame.f_back if frame else None
        f_globals = f_back.f_globals if f_back else None
        del frame
        if f_globals is not None:
            package_name = f_globals.get("__name__")
            if package_name == "__main__":
                package_name = f_globals.get("__package__")
            if package_name:
                package_name = package_name.partition(".")[0]

    def callback(ctx, param, value):
        nonlocal prog_name, version
        if not value or ctx.resilient_parsing:
            return
        if prog_name is None:
            prog_name = ctx.find_root().info_name
        if version is None and package_name is not None:
            import importlib.metadata as md

            try:
                version = md.version(package_name)
            except md.PackageNotFoundError:
                dists = md.packages_distributions().get(package_name)
                if not dists:
                    raise RuntimeError(
                        f"{package_name!r} is not installed. Try passing 'package_name' "
                        "instead.") from None
                version = md.version(dists[0])
        if version is None:
            raise RuntimeError(
                f"Could not determine the version for {package_name!r} automatically.")
        echo(message % {"prog": prog_name, "package": package_name, "version": version},
             color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*param_decls, **kwargs)


def custom_version_option(callback, *param_decls, **kwargs):
    def cb(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(callback(ctx), color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = cb
    return option(*param_decls, **kwargs)


def password_option(*param_decls, **kwargs):
    if not param_decls:
        param_decls = ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("hide_input", True)
    return option(*param_decls, **kwargs)


def confirmation_option(*param_decls, **kwargs):
    def callback(ctx, param, value):
        if not value:
            ctx.abort()

    if not param_decls:
        param_decls = ("--yes",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("callback", callback)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")
    return option(*param_decls, **kwargs)
