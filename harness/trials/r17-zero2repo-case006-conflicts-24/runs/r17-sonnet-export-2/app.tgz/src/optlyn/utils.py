import io
import os
import sys

from . import _compat
from .exceptions import FileError
from .globals import resolve_color_default

_ansi_colors = {
    "black": 30, "red": 31, "green": 32, "yellow": 33, "blue": 34,
    "magenta": 35, "cyan": 36, "white": 37, "reset": 39,
    "bright_black": 90, "bright_red": 91, "bright_green": 92,
    "bright_yellow": 93, "bright_blue": 94, "bright_magenta": 95,
    "bright_cyan": 96, "bright_white": 97,
}
_ansi_reset_all = "\033[0m"


class ColorError(TypeError, ValueError):
    pass


def _interpret_color(color, offset=0):
    if isinstance(color, bool):
        raise ColorError(f"Unknown color {color!r}")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise ColorError(f"Unknown color {color!r}")
        return f"{38 + offset};5;{color}"
    if isinstance(color, (tuple, list)):
        if len(color) != 3 or not all(
            isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
        ):
            raise ColorError(f"Unknown color {color!r}")
        r, g, b = color
        return f"{38 + offset};2;{r};{g};{b}"
    if isinstance(color, str) and color in _ansi_colors:
        return str(_ansi_colors[color] + offset)
    raise ColorError(f"Unknown color {color!r}")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None,
          overline=None, italic=None, blink=None, reverse=None,
          strikethrough=None, reset=True):
    if not isinstance(text, str):
        text = str(text)
    bits = []
    if fg is not None:
        bits.append(_interpret_color(fg))
    if bg is not None:
        bits.append(_interpret_color(bg, 10))
    for flag, on, off in (
        (bold, 1, 22), (dim, 2, 22), (underline, 4, 24), (overline, 53, 55),
        (italic, 3, 23), (blink, 5, 25), (reverse, 7, 27), (strikethrough, 9, 29),
    ):
        if flag is not None:
            bits.append(str(on if flag else off))
    out = "".join(f"\033[{b}m" for b in bits) + text
    if reset:
        out += _ansi_reset_all
    return out


def unstyle(text):
    return _compat.strip_ansi(text)


def _write_text(file, out):
    if not out.isascii() and _compat.is_ascii_encoding(file):
        buf = getattr(file, "buffer", None)
        if buf is not None:
            file.flush()
            buf.write(out.encode("utf-8"))
            buf.flush()
            return
    try:
        file.write(out)
    except UnicodeEncodeError:
        buf = getattr(file, "buffer", None)
        if buf is None:
            file.write(out.encode("ascii", "replace").decode("ascii"))
        else:
            file.flush()
            buf.write(out.encode("utf-8"))
            buf.flush()
    file.flush()


def echo(message=None, file=None, nl=True, err=False, color=None):
    if file is None:
        file = sys.stderr if err else sys.stdout
    if file is None:
        return
    if message is not None and not isinstance(message, (str, bytes, bytearray)):
        out = str(message)
    else:
        out = message
    if nl:
        out = out or ""
        out += b"\n" if isinstance(out, (bytes, bytearray)) else "\n"
    if not out:
        file.flush()
        return
    if isinstance(out, (bytes, bytearray)):
        binary = _compat.find_binary_writer(file)
        if binary is not None:
            file.flush()
            binary.write(out)
            binary.flush()
            return
        out = bytes(out).decode("utf-8", "replace")
    color = resolve_color_default(color)
    if _compat.should_strip_ansi(file, color):
        out = _compat.strip_ansi(out)
    _write_text(file, out)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None and not isinstance(message, (bytes, bytearray)):
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def format_filename(filename, shorten=False):
    if shorten:
        filename = os.path.basename(os.fspath(filename) if not isinstance(filename, bytes) else filename)
    else:
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        return filename.decode(sys.getfilesystemencoding() or "utf-8", "replace")
    return filename.encode("utf-8", "surrogateescape").decode("utf-8", "replace")


def get_app_dir(app_name, roaming=True, force_posix=False):
    def posixify(name):
        return "-".join(name.split()).lower()

    if sys.platform.startswith("win"):
        key = "APPDATA" if roaming else "LOCALAPPDATA"
        folder = os.environ.get(key) or os.path.expanduser("~")
        return os.path.join(folder, app_name)
    if force_posix:
        return os.path.join(os.path.expanduser("~"), "." + posixify(app_name))
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~/Library/Application Support"), app_name)
    return os.path.join(
        os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config"),
        posixify(app_name),
    )


class KeepOpenFile:
    def __init__(self, file):
        self._file = file

    def __getattr__(self, name):
        return getattr(self._file, name)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        pass

    def __repr__(self):
        return repr(self._file)

    def __iter__(self):
        return iter(self._file)

    def close(self):
        try:
            self._file.flush()
        except Exception:
            pass


class _NonClosingWrapper(io.TextIOWrapper):
    def close(self):
        try:
            self.flush()
        except Exception:
            pass


def _std_text(name, encoding, errors):
    stream = getattr(sys, name)
    if encoding is None or (getattr(stream, "encoding", None) or "").lower() == encoding.lower():
        return KeepOpenFile(stream)
    buf = _compat.find_binary_writer(stream)
    if buf is None:
        return KeepOpenFile(stream)
    try:
        stream.flush()
    except Exception:
        pass
    return KeepOpenFile(_NonClosingWrapper(buf, encoding=encoding, errors=errors or "strict",
                                           write_through=True))


def _std_binary(name):
    stream = getattr(sys, name)
    buf = _compat.find_binary_writer(stream)
    try:
        stream.flush()
    except Exception:
        pass
    return KeepOpenFile(buf if buf is not None else stream)


class _AtomicFile:
    def __init__(self, f, tmp_filename, real_filename):
        self._f = f
        self._tmp = tmp_filename
        self._real = real_filename
        self.closed = False

    @property
    def name(self):
        return self._real

    def close(self, delete=False):
        if self.closed:
            return
        self._f.close()
        os.replace(self._tmp, self._real)
        self.closed = True

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, *a):
        self.close(delete=exc_type is not None)

    def __iter__(self):
        return iter(self._f)


def open_stream(filename, mode="r", encoding=None, errors="strict", atomic=False):
    binary = "b" in mode
    filename = os.fspath(filename)
    if filename in ("-", b"-"):
        if any(m in mode for m in ("w", "a", "x")):
            if binary:
                return _std_binary("stdout"), False
            return _std_text("stdout", encoding, errors), False
        if binary:
            return _std_binary("stdin"), False
        return _std_text("stdin", encoding, errors), False
    if not atomic:
        return open(filename, mode, encoding=None if binary else encoding,
                    errors=None if binary else errors), True
    if "w" not in mode:
        raise ValueError("Atomic writes only make sense with 'w' mode.")
    import random

    directory = os.path.dirname(os.path.abspath(filename))
    base = os.path.basename(filename)
    tmp = os.path.join(directory, f".__atomic-write{random.randrange(1 << 24):06x}-{base}")
    f = open(tmp, mode, encoding=None if binary else encoding,
             errors=None if binary else errors)
    return _AtomicFile(f, tmp, os.path.abspath(filename)), True


class LazyFile:
    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False):
        self.name = os.fspath(filename)
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self.should_close = True
        if self.name == "-":
            self._f, self.should_close = open_stream(filename, mode, encoding, errors)
            self.should_close = False

    def __getattr__(self, name):
        return getattr(self.open(), name)

    def __repr__(self):
        if self._f is not None:
            return repr(self._f)
        return f"<unopened file '{format_filename(self.name)}' {self.mode}>"

    def open(self):
        if self._f is not None:
            return self._f
        try:
            self._f, self.should_close = open_stream(
                self.name, self.mode, self.encoding, self.errors, atomic=self.atomic)
        except OSError as e:
            raise FileError(self.name, hint=e.strerror) from e
        return self._f

    def close(self):
        if self._f is not None:
            self._f.close()

    def close_intelligently(self):
        if self.should_close:
            self.close()
        elif self._f is not None:
            try:
                self._f.flush()
            except Exception:
                pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close_intelligently()

    def __iter__(self):
        self.open()
        return iter(self._f)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    f, should_close = open_stream(filename, mode, encoding, errors, atomic=atomic)
    if not should_close:
        f = KeepOpenFile(f) if not isinstance(f, KeepOpenFile) else f
    return f


def safecall(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception:
            pass

    return wrapper
