import contextlib
import os
import shutil
import subprocess
import sys
import tempfile
import time

from . import _compat
from .exceptions import Abort, UsageError
from .globals import resolve_color_default
from .types import Choice, convert_type
from .utils import echo, style, unstyle  # noqa: F401

visible_prompt_func = input
hidden_prompt_func = None  # set lazily to getpass
_getchar = None


def _hidden(prompt=""):
    import getpass

    return getpass.getpass(prompt)


def _format_default(default):
    if hasattr(default, "name"):
        return default.name
    return default


def _build_prompt(text, suffix, show_default=False, default=None, show_choices=True, type=None):
    prompt = text
    if type is not None and show_choices and isinstance(type, Choice):
        prompt += f" ({', '.join(map(str, type.choices))})"
    if default is not None and show_default:
        prompt = f"{prompt} [{_format_default(default)}]"
    return f"{prompt}{suffix}"


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False, show_choices=True):
    def prompt_func(text):
        f = (hidden_prompt_func or _hidden) if hide_input else visible_prompt_func
        try:
            echo(text.rstrip(" "), nl=False, err=err)
            return f(" ")
        except (KeyboardInterrupt, EOFError):
            if hide_input:
                echo(None, err=err)
            raise Abort() from None

    if value_proc is None:
        value_proc = convert_type(type, default)
    full = _build_prompt(text, prompt_suffix, show_default, default, show_choices, type)
    if confirmation_prompt:
        if confirmation_prompt is True:
            confirmation_prompt = "Repeat for confirmation"
        confirmation_prompt = _build_prompt(confirmation_prompt, prompt_suffix)
    while True:
        while True:
            value = prompt_func(full)
            if value:
                break
            elif default is not None:
                value = default
                break
        try:
            result = value_proc(value)
        except UsageError as e:
            if hide_input:
                echo("Error: The value you entered was invalid.", err=err)
            else:
                echo(f"Error: {e.message}", err=err)
            continue
        if not confirmation_prompt:
            return result
        while True:
            value2 = prompt_func(confirmation_prompt)
            is_empty = not value and not value2
            if value2 or is_empty:
                break
        if value == value2:
            return result
        echo("Error: The two entered values do not match.", err=err)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    full = _build_prompt(text, prompt_suffix, show_default,
                         "y/n" if default is None else ("Y/n" if default else "y/N"))
    while True:
        try:
            echo(full.rstrip(" "), nl=False, err=err)
            rv = visible_prompt_func(" ").lower().strip()
        except (KeyboardInterrupt, EOFError):
            raise Abort() from None
        if rv in ("y", "yes"):
            rv = True
        elif rv in ("n", "no"):
            rv = False
        elif default is not None and rv == "":
            rv = default
        else:
            echo("Error: invalid input", err=err)
            continue
        break
    if abort and not rv:
        raise Abort()
    return rv


def getchar(echo=False):
    f = _getchar
    if f is None:
        f = _unix_getchar
    return f(echo)


def _unix_getchar(echo_):
    import termios
    import tty

    opened = False
    if _compat.isatty(sys.stdin):
        fd = sys.stdin.fileno()
    else:
        fd = os.open("/dev/tty", os.O_RDONLY)
        opened = True
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 32).decode("utf-8", "replace")
            if echo_ and _compat.isatty(sys.stdout):
                sys.stdout.write(ch)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
            sys.stdout.flush()
    finally:
        if opened:
            os.close(fd)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch in ("\x04", "\x1a"):
        raise EOFError()
    return ch


def pause(info=None, err=False):
    if info is None:
        info = "Press any key to continue..."
    if _compat.is_interactive():
        try:
            echo(info, nl=False, err=err)
            try:
                getchar()
            except (KeyboardInterrupt, EOFError):
                pass
        finally:
            echo(err=err)
    else:
        echo(info, err=err)


def clear():
    if _compat.isatty(sys.stdout):
        echo("\033[2J\033[1;1H", nl=False)


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    if editor is None:
        editor = os.environ.get("VISUAL") or os.environ.get("EDITOR") or "vi"
    environ = None
    if env:
        environ = os.environ.copy()
        environ.update(env)

    def run(path):
        try:
            rv = subprocess.call(f'{editor} "{path}"', shell=True, env=environ)
        except OSError as e:
            from .exceptions import OptlynException

            raise OptlynException(f"{editor}: Editing failed: {e}") from e
        if rv != 0:
            from .exceptions import OptlynException

            raise OptlynException(f"{editor}: Editing failed")

    if filename is not None:
        run(filename)
        return None
    if extension and not extension.startswith("."):
        extension = "." + extension
    fd, name = tempfile.mkstemp(prefix="optlyn-edit-", suffix=extension or "")
    try:
        with os.fdopen(fd, "wb") as f:
            if text is not None:
                f.write(text.encode("utf-8"))
        os.utime(name, (1, 1))
        before = os.path.getmtime(name)
        run(name)
        if require_save and os.path.getmtime(name) == before:
            return None
        with open(name, "rb") as f:
            return f.read().decode("utf-8")
    finally:
        try:
            os.unlink(name)
        except OSError:
            pass


def launch(url, wait=False, locate=False):
    args = ["xdg-open", os.path.dirname(url) or "." if locate and os.path.exists(url) else url]
    try:
        if wait:
            return subprocess.call(args)
        subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return 0
    except OSError:
        return 127


class _PagerWriter:
    def __init__(self, write, flush=None, close=None):
        self._w = write
        self._f = flush
        self._c = close

    def write(self, text):
        if isinstance(text, bytes):
            text = text.decode("utf-8", "replace")
        self._w(text)
        if self._f:
            self._f()
        return len(text)

    def flush(self):
        if self._f:
            self._f()

    def writelines(self, lines):
        for line in lines:
            self.write(line)

    def isatty(self):
        return False


@contextlib.contextmanager
def get_pager_file(color=None):
    pager_cmd = os.environ.get("PAGER")
    color = resolve_color_default(color)
    if not _compat.is_interactive() or not pager_cmd:
        yield _PagerWriter(lambda t: echo(t, nl=False, color=color), sys.stdout.flush)
        return
    keep = color if color is not None else _compat.isatty(sys.stdout)
    env = dict(os.environ)
    if keep:
        env.setdefault("LESS", "-R")
    proc = subprocess.Popen(pager_cmd, shell=True, stdin=subprocess.PIPE, env=env)
    broken = []

    def w(text):
        if broken:
            return
        if not keep:
            text = _compat.strip_ansi(text)
        try:
            proc.stdin.write(text.encode("utf-8"))
            proc.stdin.flush()
        except (BrokenPipeError, OSError):
            broken.append(1)

    try:
        yield _PagerWriter(w)
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        while True:
            try:
                proc.wait()
                break
            except KeyboardInterrupt:
                pass


def echo_via_pager(text_or_generator, color=None):
    if callable(text_or_generator):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, (str, bytes)):
        chunks = [text_or_generator]
    else:
        chunks = text_or_generator
    with get_pager_file(color=color) as f:
        for chunk in chunks:
            if not isinstance(chunk, (str, bytes)):
                chunk = str(chunk)
            f.write(chunk)


class ProgressBar:
    def __init__(self, iterable=None, length=None, label=None, hidden=False, fill_char="#",
                 empty_char="-", show_eta=True, show_percent=None, show_pos=False,
                 item_show_func=None, file=None, color=None, width=36, info_sep="  ",
                 **_ignored):
        if iterable is None:
            if length is None:
                raise TypeError("iterable or length is required")
            iterable = range(length)
        if length is None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.iter = iter(iterable)
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.fill_char = fill_char
        self.empty_char = empty_char
        self.show_eta = show_eta
        self.show_percent = length is not None if show_percent is None else show_percent
        self.show_pos = show_pos
        self.item_show_func = item_show_func
        self.file = file
        self.color = color
        self.width = width
        self.info_sep = info_sep
        self.pos = 0
        self.finished = False
        self.start = time.time()
        self.current_item = None
        self._last = None
        self._label_done = False
        self._drawn = False

    def __enter__(self):
        self.render_progress()
        return self

    def __exit__(self, *a):
        self.render_finish()

    def __iter__(self):
        return self._gen()

    def _gen(self):
        self.render_progress()
        try:
            for rv in self.iter:
                self.current_item = rv
                yield rv
                self.update(1)
        finally:
            self.render_finish()

    def __next__(self):
        rv = next(self.iter)
        self.current_item = rv
        self.update(1)
        return rv

    @property
    def pct(self):
        if self.finished:
            return 1.0
        if not self.length:
            return 0.0
        return min(self.pos / self.length, 1.0)

    @property
    def eta(self):
        if self.length is None or self.finished or self.pos <= 0:
            return None
        elapsed = time.time() - self.start
        return (elapsed / self.pos) * (self.length - self.pos)

    def format_eta(self):
        eta = self.eta
        if eta is None:
            return ""
        eta = int(eta)
        s, m, h = eta % 60, (eta // 60) % 60, eta // 3600
        return f"{h}:{m:02}:{s:02}"

    def update(self, n_steps=1, current_item=None):
        if current_item is not None:
            self.current_item = current_item
        self.pos += n_steps
        if self.length is not None and self.pos >= self.length:
            self.finished = True
        self.render_progress()

    def finish(self):
        self.finished = True
        if self.length is not None:
            self.pos = self.length

    def _stream(self):
        return self.file if self.file is not None else sys.stdout

    def format_bar(self):
        if self.length is not None:
            n = int(self.pct * self.width)
            return self.fill_char * n + self.empty_char * (self.width - n)
        return self.empty_char * self.width

    def render_progress(self):
        if self.hidden:
            return
        f = self._stream()
        if not _compat.isatty(f):
            if self.label and not self._label_done:
                self._label_done = True
                echo(self.label, file=f, color=self.color)
            return
        parts = []
        if self.show_pos:
            parts.append(f"{self.pos}/{self.length}" if self.length is not None else str(self.pos))
        if self.show_percent:
            parts.append(f"{int(self.pct * 100):3}%")
        if self.show_eta and self.eta is not None:
            parts.append(self.format_eta())
        if self.item_show_func and self.current_item is not None:
            parts.append(str(self.item_show_func(self.current_item)))
        line = f"{self.label}  [{self.format_bar()}]  {self.info_sep.join(parts)}".rstrip()
        if line != self._last:
            self._last = line
            self._drawn = True
            echo("\r" + line, file=f, nl=False, color=self.color)

    def render_finish(self):
        if self.hidden:
            return
        f = self._stream()
        if _compat.isatty(f) and self._drawn:
            echo(file=f)
            self._drawn = False


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    return ProgressBar(iterable, length=length, label=label, hidden=hidden, **options)
