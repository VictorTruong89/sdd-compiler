import os
import re
import shlex
import sys

from .core import Argument, Command, Group, Option, ParameterSource
from .types import CompletionItem
from .utils import echo


def _split_args(s):
    try:
        return shlex.split(s)
    except ValueError:
        return s.split()


def _safe_name(prog_name):
    return re.sub(r"\W*", "", prog_name.replace("-", "_"), flags=re.ASCII)


_BASH = """\
%(func)s() {
    local IFS=$'\\n'
    local response
    response=$(env COMP_WORDS="${COMP_WORDS[*]}" COMP_CWORD=$COMP_CWORD %(var)s=bash_complete $1)
    for completion in $response; do
        IFS=',' read type value <<< "$completion"
        if [[ $type == 'dir' ]]; then
            COMPREPLY=()
            compopt -o dirnames
        elif [[ $type == 'file' ]]; then
            COMPREPLY=()
            compopt -o default
        elif [[ $type == 'plain' ]]; then
            COMPREPLY+=($value)
        fi
    done
    return 0
}

%(func)s_setup() {
    complete -o nosort -F %(func)s %(prog)s
}

%(func)s_setup;
"""

_ZSH = """\
#compdef %(prog)s

%(func)s() {
    local -a completions
    local -a completions_with_descriptions
    local -a response
    (( ! $+commands[%(prog)s] )) && return 1

    response=("${(@f)$(env COMP_WORDS="${words[*]}" COMP_CWORD=$((CURRENT-1)) %(var)s=zsh_complete %(prog)s)}")

    for type key descr in ${response}; do
        if [[ "$type" == "plain" ]]; then
            if [[ "$descr" == "_" ]]; then
                completions+=("$key")
            else
                completions_with_descriptions+=("$key":"$descr")
            fi
        elif [[ "$type" == "dir" ]]; then
            _path_files -/
        elif [[ "$type" == "file" ]]; then
            _path_files -f
        fi
    done

    if [ -n "$completions_with_descriptions" ]; then
        _describe -V unsorted completions_with_descriptions -U
    fi

    if [ -n "$completions" ]; then
        compadd -U -V unsorted -a completions
    fi
}

if [[ $zsh_eval_context[-1] == loadautofunc ]]; then
    %(func)s "$@"
else
    compdef %(func)s %(prog)s
fi
"""

_FISH = """\
function %(func)s;
    set -l response (env %(var)s=fish_complete COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -t) %(prog)s);

    for completion in $response;
        set -l metadata (string split "," $completion);

        if test $metadata[1] = "dir";
            __fish_complete_directories $metadata[2];
        else if test $metadata[1] = "file";
            __fish_complete_path $metadata[2];
        else if test $metadata[1] = "plain";
            echo $metadata[2];
        end;
    end;
end;

complete --no-files --command %(prog)s --arguments "(%(func)s)";
"""

_POWERSHELL = """\
Register-ArgumentCompleter -Native -CommandName %(prog)s -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)
    $words = $commandAst.ToString()
    $cword = $commandAst.CommandElements.Count - 1
    if ($wordToComplete -eq '') { $cword = $cword + 1 }
    $env:COMP_WORDS = $words
    $env:COMP_CWORD = $cword
    $env:%(var)s = "powershell_complete"
    $response = & %(prog)s
    Remove-Item Env:%(var)s
    $response -split "`n" | ForEach-Object {
        $parts = $_ -split ",", 3
        if ($parts[0] -eq "plain") {
            [System.Management.Automation.CompletionResult]::new($parts[1], $parts[1], 'ParameterValue', $parts[1])
        }
    }
}
"""


class ShellComplete:
    name = ""
    source_template = ""

    def __init__(self, cli, ctx_args, prog_name, complete_var):
        self.cli = cli
        self.ctx_args = ctx_args
        self.prog_name = prog_name
        self.complete_var = complete_var

    @property
    def func_name(self):
        return f"_{_safe_name(self.prog_name)}_completion"

    def source_vars(self):
        return {"func": self.func_name, "var": self.complete_var, "prog": self.prog_name}

    def source(self):
        return self.source_template % self.source_vars()

    def get_completion_args(self):
        raise NotImplementedError

    def get_completions(self, args, incomplete):
        ctx = _resolve_context(self.cli, dict(self.ctx_args), self.prog_name, args)
        obj, incomplete = _resolve_incomplete(ctx, args, incomplete)
        return obj.shell_complete(ctx, incomplete)

    def format_completion(self, item):
        raise NotImplementedError

    def complete(self):
        args, incomplete = self.get_completion_args()
        completions = self.get_completions(args, incomplete)
        return "\n".join(self.format_completion(i) for i in completions)


class BashComplete(ShellComplete):
    name = "bash"
    source_template = _BASH

    def get_completion_args(self):
        cwords = _split_args(os.environ["COMP_WORDS"])
        cword = int(os.environ["COMP_CWORD"])
        args = cwords[1:cword]
        incomplete = cwords[cword] if cword < len(cwords) else ""
        return args, incomplete

    def format_completion(self, item):
        return f"{item.type},{item.value}"


class ZshComplete(BashComplete):
    name = "zsh"
    source_template = _ZSH

    def format_completion(self, item):
        return f"{item.type}\n{item.value}\n{item.help if item.help else '_'}"


class PowerShellComplete(BashComplete):
    name = "powershell"
    source_template = _POWERSHELL

    def format_completion(self, item):
        return f"{item.type},{item.value},{item.help if item.help else ''}"


class FishComplete(ShellComplete):
    name = "fish"
    source_template = _FISH

    def get_completion_args(self):
        cwords = _split_args(os.environ["COMP_WORDS"])
        incomplete = os.environ["COMP_CWORD"]
        args = cwords[1:]
        if incomplete and args and args[-1] == incomplete:
            args.pop()
        return args, incomplete

    def format_completion(self, item):
        if item.help:
            return f"{item.type},{item.value}\t{item.help}"
        return f"{item.type},{item.value}"


_REGISTRY = {c.name: c for c in (BashComplete, ZshComplete, FishComplete, PowerShellComplete)}


def shell_complete(cli, ctx_args, prog_name, complete_var, instruction):
    shell, _, action = instruction.partition("_")
    cls = _REGISTRY.get(shell)
    if cls is None or action not in ("source", "complete"):
        return 1
    comp = cls(cli, ctx_args, prog_name, complete_var)
    if action == "source":
        echo(comp.source())
        return 0
    echo(comp.complete())
    return 0


def _resolve_context(cli, ctx_args, prog_name, args):
    ctx_args["resilient_parsing"] = True
    ctx = cli.make_context(prog_name, list(args), **ctx_args)
    args = ctx.protected_args + ctx.args
    while args:
        command = ctx.command
        if isinstance(command, Group):
            if not command.chain:
                name, cmd, args = command.resolve_command(ctx, args)
                if cmd is None:
                    return ctx
                ctx = cmd.make_context(name, args, parent=ctx, resilient_parsing=True)
                args = ctx.protected_args + ctx.args
            else:
                sub_ctx = ctx
                while args:
                    name, cmd, args = command.resolve_command(ctx, args)
                    if cmd is None:
                        return ctx
                    sub_ctx = cmd.make_context(name, args, parent=ctx, allow_extra_args=True,
                                               allow_interspersed_args=False,
                                               resilient_parsing=True)
                    args = sub_ctx.args
                ctx = sub_ctx
                args = [*sub_ctx.protected_args, *sub_ctx.args]
        else:
            break
    return ctx


def _is_incomplete_option(ctx, args, incomplete):
    if not incomplete.startswith("-") and args:
        last = args[-1]
    else:
        return None
    return None


def _resolve_incomplete(ctx, args, incomplete):
    if "--" in args:
        return _next_argument(ctx), incomplete
    # an option expecting a value is the last complete word
    if args and not incomplete.startswith("-") or (args and incomplete == ""):
        last = args[-1]
        if last.startswith(tuple(ctx._opt_prefixes or {"-"})) and len(last) > 1:
            for param in ctx.command.get_params(ctx):
                if (isinstance(param, Option) and not param.is_flag and not param.count
                        and last in [*param.opts, *param.secondary_opts]):
                    if param.nargs == 1 or True:
                        return param, incomplete
    if "=" in incomplete and incomplete.startswith("-"):
        name, _, value = incomplete.partition("=")
        for param in ctx.command.get_params(ctx):
            if isinstance(param, Option) and not param.is_flag and name in param.opts:
                return param, value
    if not incomplete.startswith("-"):
        param = _next_argument(ctx)
        if param is not ctx.command:
            return param, incomplete
    return ctx.command, incomplete


def _next_argument(ctx):
    for param in ctx.command.get_params(ctx):
        if isinstance(param, Argument):
            if (ctx.get_parameter_source(param.name) is not ParameterSource.COMMANDLINE
                    or param.nargs == -1):
                return param
    return ctx.command
