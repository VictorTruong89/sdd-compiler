import enum
import inspect
import os
import sys
from contextlib import ExitStack, contextmanager

from . import termui
from .exceptions import (Abort, BadParameter, DeclarationError, Exit, MissingParameter,
                         NoArgsIsHelpError, OptlynException, UsageError)
from .formatting import HelpFormatter, join_options, make_default_short_help, split_opt
from .globals import get_current_context, pop_context, push_context
from .parser import FLAG_NEEDS_VALUE, OptionParser
from .types import BOOL, INT, STRING, ParamType, Tuple, IntRange, convert_type, CompletionItem
from .utils import echo

_UNSET = object()


class ParameterSource(enum.Enum):
    COMMANDLINE = 1
    ENVIRONMENT = 2
    DEFAULT = 3
    DEFAULT_MAP = 4
    PROMPT = 5


_RANK = {ParameterSource.PROMPT: 5, ParameterSource.COMMANDLINE: 4,
         ParameterSource.ENVIRONMENT: 3, ParameterSource.DEFAULT_MAP: 2,
         ParameterSource.DEFAULT: 1}


@contextmanager
def augment_usage_errors(ctx, param=None):
    try:
        yield
    except BadParameter as e:
        if e.ctx is None:
            e.ctx = ctx
        if param is not None and e.param is None:
            e.param = param
        raise
    except UsageError as e:
        if e.ctx is None:
            e.ctx = ctx
        raise


def iter_params_for_processing(invocation_order, declaration_order):
    def sort_key(item):
        try:
            idx = invocation_order.index(item)
        except ValueError:
            idx = float("inf")
        return (not item.is_eager, idx)

    return sorted(declaration_order, key=sort_key)


class Context:
    def __init__(self, command, parent=None, info_name=None, obj=None, auto_envvar_prefix=None,
                 default_map=None, terminal_width=None, max_content_width=None,
                 resilient_parsing=False, allow_extra_args=None, allow_interspersed_args=None,
                 ignore_unknown_options=None, help_option_names=None, token_normalize_func=None,
                 color=None, show_default=None):
        self.parent = parent
        self.command = command
        self.info_name = info_name
        self.params = {}
        self.args = []
        self.protected_args = []
        self._opt_prefixes = set(parent._opt_prefixes) if parent else set()
        if obj is None and parent is not None:
            obj = parent.obj
        self.obj = obj
        self._meta = getattr(parent, "meta", {})
        if default_map is None and info_name is not None and parent is not None \
                and parent.default_map is not None:
            default_map = parent.default_map.get(info_name)
        self.default_map = default_map
        self.invoked_subcommand = None
        if terminal_width is None and parent is not None:
            terminal_width = parent.terminal_width
        self.terminal_width = terminal_width
        if max_content_width is None and parent is not None:
            max_content_width = parent.max_content_width
        self.max_content_width = max_content_width
        if allow_extra_args is None:
            allow_extra_args = command.allow_extra_args
        self.allow_extra_args = allow_extra_args
        if allow_interspersed_args is None:
            allow_interspersed_args = command.allow_interspersed_args
        self.allow_interspersed_args = allow_interspersed_args
        if ignore_unknown_options is None:
            ignore_unknown_options = command.ignore_unknown_options
        self.ignore_unknown_options = ignore_unknown_options
        if help_option_names is None:
            help_option_names = parent.help_option_names if parent is not None else ["--help"]
        self.help_option_names = help_option_names
        if token_normalize_func is None and parent is not None:
            token_normalize_func = parent.token_normalize_func
        self.token_normalize_func = token_normalize_func
        self.resilient_parsing = resilient_parsing
        if auto_envvar_prefix is None:
            if parent is not None and parent.auto_envvar_prefix is not None \
                    and self.info_name is not None:
                auto_envvar_prefix = f"{parent.auto_envvar_prefix}_{self.info_name.upper()}"
        else:
            auto_envvar_prefix = auto_envvar_prefix.upper()
        if auto_envvar_prefix is not None:
            auto_envvar_prefix = auto_envvar_prefix.replace("-", "_")
        self.auto_envvar_prefix = auto_envvar_prefix
        if color is None and parent is not None:
            color = parent.color
        self.color = color
        if show_default is None and parent is not None:
            show_default = parent.show_default
        self.show_default = show_default
        self._close_callbacks = []
        self._depth = 0
        self._parameter_source = {}
        self._param_best = {}
        self._exit_stack = ExitStack()

    @property
    def meta(self):
        return self._meta

    def __enter__(self):
        self._depth += 1
        push_context(self)
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self._depth -= 1
        if self._depth == 0:
            self.close()
        pop_context()

    @contextmanager
    def scope(self, cleanup=True):
        if not cleanup:
            self._depth += 1
        try:
            with self as rv:
                yield rv
        finally:
            if not cleanup:
                self._depth -= 1

    def with_resource(self, context_manager):
        return self._exit_stack.enter_context(context_manager)

    def call_on_close(self, f):
        return self._exit_stack.callback(f)

    def close(self):
        self._exit_stack.close()
        self._exit_stack = ExitStack()

    @property
    def command_path(self):
        rv = ""
        if self.info_name is not None:
            rv = self.info_name
        if self.parent is not None:
            parts = [self.parent.command_path]
            if self.info_name is not None:
                parts.append(self.info_name)
            rv = " ".join(p for p in parts if p)
        return rv

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type):
        node = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        rv = self.find_object(object_type)
        if rv is None:
            self.obj = rv = object_type()
        return rv

    def lookup_default(self, name, call=True):
        if self.default_map is not None:
            value = self.default_map.get(name)
            if call and callable(value):
                return value()
            return value
        return None

    def fail(self, message):
        raise UsageError(message, self)

    def abort(self):
        raise Abort()

    def exit(self, code=0):
        raise Exit(code)

    def make_formatter(self):
        return HelpFormatter(width=self.terminal_width, max_width=self.max_content_width)

    def get_usage(self):
        return self.command.get_usage(self)

    def get_help(self):
        return self.command.get_help(self)

    def get_parameter_source(self, name):
        return self._parameter_source.get(name)

    def set_parameter_source(self, name, source):
        self._parameter_source[name] = source

    def _make_sub_context(self, command):
        return Context(command, info_name=command.name, parent=self)

    def invoke(__self, __callback, *args, **kwargs):
        if isinstance(__callback, Command):
            other_cmd = __callback
            if other_cmd.callback is None:
                raise TypeError("The given command does not have a callback that can be invoked.")
            __callback = other_cmd.callback
            ctx = __self._make_sub_context(other_cmd)
            for param in other_cmd.get_params(ctx):
                if param.name not in kwargs and param.expose_value:
                    kwargs[param.name] = param.type_cast_value(ctx, param.get_default(ctx))
            ctx.params.update(kwargs)
        else:
            ctx = __self
        with augment_usage_errors(__self):
            with ctx:
                return __callback(*args, **kwargs)

    def forward(__self, __cmd, **kwargs):
        if not isinstance(__cmd, Command):
            raise TypeError("Callback is not a command.")
        for key, value in __self.params.items():
            kwargs.setdefault(key, value)
        return __self.invoke(__cmd, **kwargs)


# ---------------------------------------------------------------- parameters

class Parameter:
    param_type_name = "parameter"

    def __init__(self, param_decls=None, type=None, required=False, default=_UNSET,
                 callback=None, nargs=None, multiple=False, metavar=None, expose_value=True,
                 is_eager=False, envvar=None, shell_complete=None, deprecated=False,
                 help=None):
        self.name, self.opts, self.secondary_opts = self._parse_decls(
            param_decls or (), expose_value)
        self.type = convert_type(type, None if default is _UNSET else default)
        if nargs is None:
            nargs = self.type.arity if self.type.is_composite else 1
        self.required = required
        self.callback = callback
        self.nargs = nargs
        self.multiple = multiple
        self._default_given = default is not _UNSET
        self.default = None if default is _UNSET else default
        self.expose_value = expose_value
        self.metavar = metavar
        self.envvar = envvar
        self._custom_shell_complete = shell_complete
        self.is_eager = is_eager
        self.deprecated = deprecated
        self.help = help
        self._decl_index = 0
        if self.type.is_composite and nargs != self.type.arity:
            raise DeclarationError(
                f"'nargs' must be {self.type.arity} (or None) for type {self.type!r}, "
                f"but it was {nargs}.")
        if self.nargs == -1 and self.multiple:
            raise DeclarationError("'nargs=-1' is not valid with 'multiple'.")
        if self.nargs == 0 or (self.nargs is not None and self.nargs < -1):
            raise DeclarationError("'nargs' must be positive or -1.")

    @property
    def hidden(self):
        return False

    def _parse_decls(self, decls, expose_value):
        raise NotImplementedError

    def get_error_hint(self, ctx):
        names = [*self.opts, *self.secondary_opts] if (self.opts or self.secondary_opts) \
            else [self.make_metavar()]
        return " / ".join(f"'{x}'" for x in names)

    def make_metavar(self):
        if self.metavar is not None:
            return self.metavar
        return self.name.upper()

    def get_default(self, ctx, call=True):
        value = ctx.lookup_default(self.name, call=False)
        if value is None:
            value = self.default
        if call and callable(value):
            value = value()
        return value

    def add_to_parser(self, parser, ctx):
        raise NotImplementedError

    def _is_split(self):
        return self.nargs != 1 or self.multiple

    def _split_value(self, rv):
        value_depth = (self.nargs != 1) + bool(self.multiple)
        if value_depth > 0:
            rv = self.type.split_envvar_value(rv)
            if self.multiple and self.nargs != 1:
                n = self.nargs
                rv = [tuple(rv[i:i + n]) for i in range(0, len(rv), n)]
        return rv

    def resolve_envvar_value(self, ctx):
        if self.envvar is None:
            return None
        if isinstance(self.envvar, str):
            rv = os.environ.get(self.envvar)
            return rv if rv else None
        found = None
        for name in self.envvar:
            rv = os.environ.get(name)
            if rv:
                found = rv
                break
        return found

    def value_from_envvar(self, ctx):
        rv = self.resolve_envvar_value(ctx)
        if rv is None:
            return None
        return self._split_value(rv)

    def _arity(self):
        return self.type.arity if self.type.is_composite else self.nargs

    def consume_value(self, ctx, opts):
        value = opts.get(self.name)
        source = ParameterSource.COMMANDLINE
        if value is None:
            value = self.value_from_envvar(ctx)
            source = ParameterSource.ENVIRONMENT
        if value is None:
            value = ctx.lookup_default(self.name)
            source = ParameterSource.DEFAULT_MAP
            if isinstance(value, str) and self._arity() != 1:
                value = self._split_value(value) if not self.multiple else \
                    self.type.split_envvar_value(value)
                if self.multiple and self.nargs != 1:
                    n = self.nargs
                    value = [tuple(value[i:i + n]) for i in range(0, len(value), n)]
        if value is None:
            value = self.get_default(ctx)
            source = ParameterSource.DEFAULT
        return value, source

    def type_cast_value(self, ctx, value):
        if value is None:
            return () if (self.multiple or self.nargs == -1) else None

        def check_iter(value):
            if isinstance(value, (str, bytes)):
                raise BadParameter("Value must be an iterable (a sequence); "
                                   "got a plain string.", ctx=ctx, param=self)
            try:
                return iter(value)
            except TypeError:
                raise BadParameter("Value must be an iterable (a sequence).",
                                   ctx=ctx, param=self) from None

        if self.nargs == 1 or self.type.is_composite:
            def convert(value):
                return self.type(value, param=self, ctx=ctx)
        elif self.nargs == -1:
            def convert(value):
                return tuple(self.type(x, self, ctx) for x in check_iter(value))
        else:
            def convert(value):
                value = tuple(check_iter(value))
                if len(value) != self.nargs:
                    raise BadParameter(
                        f"Takes {self.nargs} values but {len(value)} were given.",
                        ctx=ctx, param=self)
                return tuple(self.type(x, self, ctx) for x in value)

        if self.multiple:
            return tuple(convert(x) for x in check_iter(value))
        return convert(value)

    def value_is_missing(self, value):
        if value is None:
            return True
        if (self.nargs != 1 or self.multiple) and value == ():
            return True
        return False

    def process_value(self, ctx, value):
        value = self.type_cast_value(ctx, value)
        if self.required and self.value_is_missing(value):
            raise MissingParameter(ctx=ctx, param=self)
        if self.callback is not None:
            value = self.callback(ctx, self, value)
        return value

    def handle_parse_result(self, ctx, opts, args):
        with augment_usage_errors(ctx, param=self):
            value, source = self.consume_value(ctx, opts)
            ctx.set_parameter_source(self.name, source)
            try:
                value = self.process_value(ctx, value)
            except Exception:
                if not ctx.resilient_parsing:
                    raise
                value = None
            if (self.deprecated and value is not None
                    and source not in (ParameterSource.DEFAULT, ParameterSource.DEFAULT_MAP)
                    and not ctx.resilient_parsing):
                self._warn_deprecated(ctx)
        if self.expose_value:
            explicit = 1 if (source is ParameterSource.DEFAULT and self._default_given) else 0
            key = (_RANK[source], explicit, self._decl_index)
            best = ctx._param_best.get(self.name)
            if best is None or key >= best:
                ctx._param_best[self.name] = key
                ctx.params[self.name] = value
                ctx._parameter_source[self.name] = source
            elif self.name not in ctx.params:
                ctx.params[self.name] = value
        return value, args

    def _warn_deprecated(self, ctx):
        note = self.deprecated if isinstance(self.deprecated, str) else ""
        echo(f"DeprecationWarning: The {self.param_type_name} {self.name!r} is deprecated."
             + (f" {note}" if note else ""), err=True)

    def shell_complete(self, ctx, param, incomplete):
        if self._custom_shell_complete is not None:
            results = self._custom_shell_complete(ctx, self, incomplete)
            return [CompletionItem(r) if isinstance(r, str) else r for r in results]
        return self.type.shell_complete(ctx, self, incomplete)


class Option(Parameter):
    param_type_name = "option"

    def __init__(self, param_decls=None, show_default=None, prompt=False,
                 confirmation_prompt=False, prompt_required=True, hide_input=False,
                 is_flag=None, flag_value=_UNSET, multiple=False, count=False,
                 allow_from_autoenv=True, type=None, help=None, hidden=False,
                 show_choices=True, show_envvar=False, **attrs):
        if prompt is True:
            if attrs.get("deprecated"):
                raise DeclarationError("An option that is deprecated cannot use a prompt.")
            prompt_text = None
        elif prompt is False:
            prompt_text = None
        else:
            prompt_text = prompt
        default_given = "default" in attrs
        super().__init__(param_decls, type=type, multiple=multiple, help=help, **attrs)
        self.prompt = prompt_text
        self._prompt_on = bool(prompt)
        if self._prompt_on and self.prompt is None:
            self.prompt = self.name.replace("_", " ").capitalize()
        if self._prompt_on and self.deprecated:
            raise DeclarationError("An option that is deprecated cannot use a prompt.")
        if self.deprecated and self.required:
            raise DeclarationError("A deprecated option cannot be required.")
        self.confirmation_prompt = confirmation_prompt
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.hidden_flag = hidden
        self.show_default = show_default
        self.show_choices = show_choices
        self.show_envvar = show_envvar
        self.allow_from_autoenv = allow_from_autoenv
        self.count = count
        flag_given = flag_value is not _UNSET
        self._flag_needs_value = self.prompt is not None and not prompt_required
        if is_flag is None:
            if flag_given and not self._flag_needs_value:
                is_flag = True
            elif self._flag_needs_value:
                is_flag = False
            else:
                is_flag = bool(self.secondary_opts)
        elif is_flag is False and not self._flag_needs_value:
            self._flag_needs_value = flag_given
        self.is_flag = is_flag
        if is_flag and not flag_given:
            flag_value = True
        self.flag_value = None if flag_value is _UNSET else flag_value
        self._flag_given = flag_given
        if is_flag and type is None:
            self.type = convert_type(None, self.flag_value)
        if count and type is None:
            self.type = IntRange(min=0)
        self.is_bool_flag = bool(is_flag and self.type is BOOL) or (
            bool(is_flag) and type is None and isinstance(self.flag_value, bool))
        if self.is_bool_flag:
            self.type = BOOL if type is None else self.type
        if self.count and not default_given:
            self.default = 0
        if self.is_flag and not default_given and not self.required:
            if self.is_bool_flag:
                self.default = () if multiple else False
        if self.multiple and self.is_flag:
            raise DeclarationError("'multiple' is not valid with 'is_flag', use 'count' instead.")
        if self.count:
            if self.multiple:
                raise DeclarationError("'count' is not valid with 'multiple'.")
            if self.is_flag:
                raise DeclarationError("'count' is not valid with 'is_flag'.")
        if self.secondary_opts and not self.is_bool_flag:
            raise DeclarationError("secondary option names are only valid for boolean flags.")
        if self.nargs == -1:
            raise DeclarationError("nargs=-1 is not supported for options.")
        if self._prompt_on and self.is_flag and not self.is_bool_flag:
            raise DeclarationError("'prompt' is not valid for non-boolean flag.")
        if self.is_bool_flag and self.hide_input and self.prompt is not None:
            raise DeclarationError("'prompt' with 'hide_input' is not valid for boolean flag.")
        if self.is_flag and self.nargs != 1:
            raise DeclarationError("'nargs' must be 1 for flags.")
        if self.deprecated and self.required:
            raise DeclarationError("A deprecated option cannot be required.")

    @property
    def hidden(self):
        return self.hidden_flag

    def _parse_decls(self, decls, expose_value):
        opts = []
        secondary_opts = []
        name = None
        possible_names = []
        for decl in decls:
            if decl.isidentifier():
                if name is not None:
                    raise DeclarationError(f"Name '{name}' defined twice")
                name = decl
            else:
                split_char = ";" if decl[:1] == "/" else "/"
                if split_char in decl:
                    first, second = decl.split(split_char, 1)
                    first = first.rstrip()
                    if first:
                        possible_names.append(split_opt(first))
                        opts.append(first)
                    second = second.lstrip()
                    if second:
                        secondary_opts.append(second)
                    if first == second:
                        raise DeclarationError(
                            f"Boolean option {decl!r} cannot use the same flag for true/false.")
                else:
                    possible_names.append(split_opt(decl))
                    opts.append(decl)
        if name is None and possible_names:
            possible_names.sort(key=lambda x: -len(x[0]))
            name = possible_names[0][1].replace("-", "_").lower()
            if not name.isidentifier():
                name = None
        if name is None:
            if not expose_value:
                return None, opts, secondary_opts
            raise DeclarationError("Could not determine name for option")
        if not opts and not secondary_opts:
            raise DeclarationError(f"No options defined but a name was passed ({name}).")
        return name, opts, secondary_opts

    def add_to_parser(self, parser, ctx):
        if self.multiple:
            action = "append"
        elif self.count:
            action = "count"
        else:
            action = "store"
        if self.is_flag:
            action = f"{action}_const"
            if self.is_bool_flag and self.secondary_opts:
                parser.add_option(self, self.opts, self.name, action, const=True)
                parser.add_option(self, self.secondary_opts, self.name, action, const=False)
            else:
                parser.add_option(self, self.opts, self.name, action, const=self.flag_value)
        else:
            parser.add_option(self, self.opts, self.name, action, nargs=self.nargs)

    def get_default(self, ctx, call=True):
        value = ctx.lookup_default(self.name, call=False)
        if value is None:
            value = self.default
        if call and callable(value):
            value = value()
        if self.is_flag and not self.is_bool_flag and value is True:
            return self.flag_value
        return value

    def make_metavar(self):
        if self.metavar is not None:
            return self.metavar
        metavar = self.type.get_metavar(self)
        if metavar is None:
            metavar = self.type.name.upper()
        if self.nargs != 1:
            metavar += "..."
        return metavar

    def resolve_envvar_value(self, ctx):
        rv = super().resolve_envvar_value(ctx)
        if rv is not None:
            return rv
        if self.allow_from_autoenv and ctx.auto_envvar_prefix is not None and self.name:
            rv = os.environ.get(f"{ctx.auto_envvar_prefix}_{self.name.upper()}")
            if rv:
                return rv
        return None

    def value_from_envvar(self, ctx):
        rv = self.resolve_envvar_value(ctx)
        if rv is None:
            return None
        if self.is_flag and not self.multiple:
            norm = rv.strip().lower()
            if self.is_bool_flag:
                if norm == "":
                    return False
                return rv
            if rv == str(self.flag_value) or norm in BOOL.TRUE:
                return self.flag_value
            return None
        return self._split_value(rv)

    def consume_value(self, ctx, opts):
        value, source = super().consume_value(ctx, opts)
        if value is FLAG_NEEDS_VALUE:
            if self.prompt is not None and not ctx.resilient_parsing:
                value = self.prompt_for_value(ctx)
                source = ParameterSource.PROMPT
            else:
                value = self.flag_value
                source = ParameterSource.COMMANDLINE
        elif (self.prompt is not None and (self.prompt_required or self.required)
              and (value is None or source in (ParameterSource.DEFAULT,
                                               ParameterSource.DEFAULT_MAP))
              and not ctx.resilient_parsing):
            value = self.prompt_for_value(ctx)
            source = ParameterSource.PROMPT
        return value, source

    def prompt_for_value(self, ctx):
        default = self.get_default(ctx)
        if self.is_bool_flag:
            return termui.confirm(self.prompt, default)
        return termui.prompt(
            self.prompt, default=default, type=self.type, hide_input=self.hide_input,
            show_choices=self.show_choices, confirmation_prompt=self.confirmation_prompt,
            value_proc=lambda x: self.type_cast_value(ctx, x))

    def get_help_record(self, ctx):
        if self.hidden:
            return None
        any_slash = False

        def _write_opts(opts):
            nonlocal any_slash
            rv, slashes = join_options(opts)
            if slashes:
                any_slash = True
            if not self.is_flag and not self.count:
                rv += f" {self.make_metavar()}"
            return rv

        rv = [_write_opts(self.opts)]
        if self.secondary_opts:
            rv.append(_write_opts(self.secondary_opts))
        help = self.help or ""
        extra = []
        if self.show_envvar:
            envvar = self.envvar
            if envvar is None and self.allow_from_autoenv and ctx.auto_envvar_prefix is not None \
                    and self.name:
                envvar = f"{ctx.auto_envvar_prefix}_{self.name.upper()}"
            if envvar is not None:
                extra.append("env var: " + (envvar if isinstance(envvar, str)
                                            else ", ".join(envvar)))
        show_default = self.show_default
        if show_default is None and ctx.show_default is not None:
            show_default = ctx.show_default
        default_value = self.get_default(ctx, call=False)
        show_default_is_str = isinstance(show_default, str)
        if show_default_is_str or (show_default and default_value is not None):
            if show_default_is_str:
                default_string = f"({show_default})"
            elif callable(default_value):
                default_string = "(dynamic)"
            elif self.is_bool_flag and self.secondary_opts:
                default_string = split_opt((self.opts if default_value else
                                            self.secondary_opts)[0])[1]
            elif self.is_bool_flag and not default_value:
                default_string = None
            elif isinstance(default_value, (list, tuple)):
                default_string = ", ".join(str(getattr(d, "name", d)) for d in default_value)
            else:
                default_string = str(getattr(default_value, "name", default_value))
            if default_string is not None:
                extra.append(f"default: {default_string}")
        if self.required:
            extra.append("required")
        if extra:
            extra_str = "; ".join(extra)
            help = f"{help}  [{extra_str}]" if help else f"[{extra_str}]"
        if self.deprecated:
            help = f"(DEPRECATED) {help}".rstrip()
        return ("; " if any_slash else " / ").join(rv), help


class Argument(Parameter):
    param_type_name = "argument"

    def __init__(self, param_decls, required=None, **attrs):
        if required is None:
            if attrs.get("default") is not None:
                required = False
            else:
                required = attrs.get("nargs", 1) > 0
        if attrs.get("deprecated") and required:
            raise DeclarationError("A deprecated argument cannot be required.")
        super().__init__(param_decls, required=required, **attrs)
        if self.default is not None and self.nargs < 0:
            raise DeclarationError("'default' is not supported for nargs=-1.")
        if self.deprecated and self.required:
            raise DeclarationError("A deprecated argument cannot be required.")

    def _parse_decls(self, decls, expose_value):
        if not decls:
            if not expose_value:
                return None, [], []
            raise DeclarationError("Could not determine name for argument")
        if len(decls) == 1:
            name = arg = decls[0]
            name = name.replace("-", "_").lower()
        else:
            raise DeclarationError(
                f"Arguments take exactly one parameter declaration, got {len(decls)}.")
        return name, [arg], []

    def get_error_hint(self, ctx):
        return f"'{self.make_metavar()}'"

    def make_metavar(self):
        if self.metavar is not None:
            return self.metavar
        return self.name.upper()

    def usage_piece(self):
        if self.metavar is not None:
            return self.metavar
        var = self.name.upper()
        if not self.required:
            var = f"[{var}]"
        if self.nargs != 1:
            var += "..."
        return var

    def add_to_parser(self, parser, ctx):
        parser.add_argument(self, dest=self.name, nargs=self.nargs)

    def get_help_record(self, ctx):
        if not self.help:
            return None
        help = self.help
        if self.deprecated:
            help = f"(DEPRECATED) {help}"
        return self.make_metavar(), help


# ------------------------------------------------------------------ commands

def _clean_help(text):
    if not text:
        return ""
    text = inspect.cleandoc(text)
    return text


class Command:
    context_class = Context
    allow_extra_args = False
    allow_interspersed_args = True
    ignore_unknown_options = False

    def __init__(self, name, context_settings=None, callback=None, params=None, help=None,
                 epilog=None, short_help=None, options_metavar="[OPTIONS]",
                 add_help_option=True, no_args_is_help=False, hidden=False, deprecated=False):
        self.name = name
        if context_settings is None:
            context_settings = {}
        self.context_settings = context_settings
        self.callback = callback
        self.params = list(params or [])
        for i, p in enumerate(self.params):
            p._decl_index = i
        self.help = help
        self.epilog = epilog
        self.options_metavar = options_metavar
        self.short_help = short_help
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = deprecated

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"

    # help
    def get_help_option_names(self, ctx):
        all_names = list(ctx.help_option_names)
        for param in self.params:
            for n in [*param.opts, *param.secondary_opts]:
                if n in all_names:
                    all_names.remove(n)
        return all_names

    def get_help_option(self, ctx):
        names = self.get_help_option_names(ctx)
        if not names or not self.add_help_option:
            return None

        def show_help(ctx, param, value):
            if not value or ctx.resilient_parsing:
                return
            echo(ctx.get_help(), color=ctx.color)
            ctx.exit()

        return Option(names, is_flag=True, is_eager=True, expose_value=False,
                      callback=show_help, help="Show this message and exit.")

    def get_params(self, ctx):
        rv = list(self.params)
        help_option = self.get_help_option(ctx)
        if help_option is not None:
            help_option._decl_index = len(rv)
            rv.append(help_option)
        return rv

    def make_parser(self, ctx):
        parser = OptionParser(ctx)
        for param in self.get_params(ctx):
            param.add_to_parser(parser, ctx)
        return parser

    def collect_usage_pieces(self, ctx):
        rv = [self.options_metavar] if self.options_metavar else []
        for param in self.get_params(ctx):
            if isinstance(param, Argument):
                rv.append(param.usage_piece())
        return rv

    def get_usage(self, ctx):
        formatter = ctx.make_formatter()
        formatter.write_usage(ctx.command_path, " ".join(self.collect_usage_pieces(ctx)))
        return formatter.getvalue().rstrip("\n")

    def _description(self):
        return _clean_help(self.help).partition("\f")[0].rstrip()

    def get_short_help_str(self, limit=45):
        if self.short_help:
            text = inspect.cleandoc(self.short_help)
        elif self.help:
            text = make_default_short_help(self._description(), limit)
        else:
            text = ""
        if self.deprecated:
            text = f"(DEPRECATED) {text}".rstrip()
        return text.strip()

    def format_help_text(self, ctx, formatter):
        text = self._description()
        if self.deprecated:
            text = f"(DEPRECATED) {text}".rstrip()
        if text:
            formatter.write_paragraph()
            with formatter.indentation():
                formatter.write_text(text)

    def format_positional(self, ctx, formatter):
        rows = []
        for p in self.get_params(ctx):
            if isinstance(p, Argument):
                rec = p.get_help_record(ctx)
                if rec:
                    rows.append(rec)
        if rows:
            with formatter.section("Positional arguments"):
                formatter.write_dl(rows)

    def format_options(self, ctx, formatter):
        opts = []
        for param in self.get_params(ctx):
            if isinstance(param, Option):
                rv = param.get_help_record(ctx)
                if rv is not None:
                    opts.append(rv)
        if opts:
            with formatter.section("Options"):
                formatter.write_dl(opts)

    def format_epilog(self, ctx, formatter):
        if self.epilog:
            epilog = inspect.cleandoc(self.epilog)
            formatter.write_paragraph()
            with formatter.indentation():
                formatter.write_text(epilog)

    def format_help(self, ctx, formatter):
        formatter.write_usage(ctx.command_path, " ".join(self.collect_usage_pieces(ctx)))
        self.format_help_text(ctx, formatter)
        self.format_positional(ctx, formatter)
        self.format_options(ctx, formatter)
        self.format_commands(ctx, formatter)
        self.format_epilog(ctx, formatter)

    def format_commands(self, ctx, formatter):
        pass

    def get_help(self, ctx):
        formatter = ctx.make_formatter()
        self.format_help(ctx, formatter)
        return formatter.getvalue().rstrip("\n")

    # parse/invoke
    def make_context(self, info_name, args, parent=None, **extra):
        for key, value in self.context_settings.items():
            if key not in extra:
                extra[key] = value
        ctx = self.context_class(self, info_name=info_name, parent=parent, **extra)
        with ctx.scope(cleanup=False):
            self.parse_args(ctx, args)
        return ctx

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsIsHelpError(ctx)
        parser = self.make_parser(ctx)
        opts, args, param_order = parser.parse_args(args=args)
        for param in iter_params_for_processing(param_order, self.get_params(ctx)):
            value, args = param.handle_parse_result(ctx, opts, args)
        if args and not ctx.allow_extra_args and not ctx.resilient_parsing:
            ctx.fail("Got unexpected extra argument" + ("s" if len(args) != 1 else "")
                     + f" ({' '.join(map(str, args))})")
        ctx.args = args
        ctx._opt_prefixes.update(parser._opt_prefixes)
        return args

    def invoke(self, ctx):
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else ""
            echo(f"DeprecationWarning: The command {self.name!r} is deprecated."
                 + (f" {note}" if note else ""), err=True)
        if self.callback is not None:
            return ctx.invoke(self.callback, **ctx.params)

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True, **extra):
        if args is None:
            args = sys.argv[1:]
        else:
            args = list(args)
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0] if sys.argv else "") or self.name
        self._main_shell_completion(extra, prog_name, complete_var)
        try:
            try:
                with self.make_context(prog_name, args, **extra) as ctx:
                    rv = self.invoke(ctx)
                    if not standalone_mode:
                        return rv
                    ctx.exit()
            except (EOFError, KeyboardInterrupt) as e:
                echo(file=sys.stderr)
                raise Abort() from e
            except OptlynException as e:
                if not standalone_mode:
                    raise
                e.show()
                sys.exit(e.exit_code)
            except OSError as e:
                if e.errno == 32:
                    sys.stdout = open(os.devnull, "w")
                    sys.exit(1)
                raise
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return e.exit_code
        except Abort:
            if not standalone_mode:
                raise
            echo("Aborted!", file=sys.stderr)
            sys.exit(1)

    def _main_shell_completion(self, ctx_args, prog_name, complete_var=None):
        if complete_var is None:
            complete_var = f"_{prog_name.replace('-', '_')}_COMPLETE".upper()
        instruction = os.environ.get(complete_var)
        if not instruction:
            return
        from .shell_completion import shell_complete

        sys.exit(shell_complete(self, ctx_args, prog_name, complete_var, instruction))

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    def shell_complete(self, ctx, incomplete):
        results = []
        if not incomplete or not incomplete[0].isalnum():
            for param in self.get_params(ctx):
                if (not isinstance(param, Option) or param.hidden
                        or (not param.multiple and not param.count
                            and ctx.get_parameter_source(param.name)
                            is ParameterSource.COMMANDLINE)):
                    continue
                results.extend(CompletionItem(name, help=param.help)
                               for name in [*param.opts, *param.secondary_opts]
                               if name.startswith(incomplete))
        return results


class Group(Command):
    allow_extra_args = True
    allow_interspersed_args = False
    command_class = None
    group_class = None

    def __init__(self, name=None, commands=None, invoke_without_command=False,
                 no_args_is_help=None, subcommand_metavar=None, chain=False,
                 result_callback=None, **kwargs):
        super().__init__(name, **kwargs)
        if commands is None:
            commands = {}
        elif isinstance(commands, (list, tuple)):
            commands = {c.name: c for c in commands}
        self.commands = dict(commands)
        self.no_args_is_help = (not invoke_without_command) if no_args_is_help is None \
            else no_args_is_help
        self.invoke_without_command = invoke_without_command
        if subcommand_metavar is None:
            if chain:
                subcommand_metavar = ("[COMMAND1] [ARGS]..." if invoke_without_command
                                      else "COMMAND1 [ARGS]...") + " [COMMAND2 [ARGS]...]..."
            else:
                subcommand_metavar = ("[COMMAND] [ARGS]..." if invoke_without_command
                                      else "COMMAND [ARGS]...")
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback

    def add_command(self, cmd, name=None):
        name = name or cmd.name
        if name is None:
            raise TypeError("Command has no name.")
        if self.chain and isinstance(cmd, Group):
            raise DeclarationError(
                "It is not possible to add a group as a child of a group in chain mode.")
        self.commands[name] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as _command

        if self.command_class and kwargs.get("cls") is None:
            kwargs["cls"] = self.command_class
        func = None
        if args and callable(args[0]):
            func = args[0]
            args = args[1:]

        def decorator(f):
            cmd = _command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        if func is not None:
            return decorator(func)
        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as _group

        if self.group_class is not None and kwargs.get("cls") is None:
            kwargs["cls"] = self.group_class
        func = None
        if args and callable(args[0]):
            func = args[0]
            args = args[1:]

        def decorator(f):
            cmd = _group(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        if func is not None:
            return decorator(func)
        return decorator

    def result_callback(self, replace=False):
        def decorator(f):
            old_callback = self._result_callback
            if old_callback is None or replace:
                self._result_callback = f
                return f

            def function(value, /, *args, **kwargs):
                inner = old_callback(value, *args, **kwargs)
                return f(inner, *args, **kwargs)

            self._result_callback = rv = function
            return rv

        return decorator

    def get_command(self, ctx, cmd_name):
        return self.commands.get(cmd_name)

    def list_commands(self, ctx):
        return sorted(self.commands)

    def collect_usage_pieces(self, ctx):
        rv = super().collect_usage_pieces(ctx)
        rv.append(self.subcommand_metavar)
        return rv

    def format_commands(self, ctx, formatter):
        commands = []
        for subcommand in self.list_commands(ctx):
            cmd = self.get_command(ctx, subcommand)
            if cmd is None or cmd.hidden:
                continue
            commands.append((subcommand, cmd))
        if commands:
            rows = [(sub, cmd.get_short_help_str(45)) for sub, cmd in commands]
            with formatter.section("Commands"):
                formatter.write_dl(rows)

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsIsHelpError(ctx)
        rest = super().parse_args(ctx, args)
        if self.chain:
            ctx.protected_args = rest
            ctx.args = []
        elif rest:
            ctx.protected_args, ctx.args = rest[:1], rest[1:]
        return ctx.args

    def invoke(self, ctx):
        def _process_result(value):
            if self._result_callback is not None:
                value = ctx.invoke(self._result_callback, value, **ctx.params)
            return value

        if not ctx.protected_args:
            if self.invoke_without_command:
                with ctx:
                    rv = super().invoke(ctx)
                    return _process_result([] if self.chain else rv)
            ctx.fail("Missing command.")
        args = [*ctx.protected_args, *ctx.args]
        ctx.args = []
        ctx.protected_args = []
        if not self.chain:
            with ctx:
                cmd_name, cmd, args = self.resolve_command(ctx, args)
                ctx.invoked_subcommand = cmd_name
                super().invoke(ctx)
                sub_ctx = cmd.make_context(cmd_name, args, parent=ctx)
                with sub_ctx:
                    return _process_result(sub_ctx.command.invoke(sub_ctx))
        with ctx:
            ctx.invoked_subcommand = "*" if args else None
            super().invoke(ctx)
            contexts = []
            while args:
                cmd_name, cmd, args = self.resolve_command(ctx, args)
                sub_ctx = cmd.make_context(cmd_name, args, parent=ctx, allow_extra_args=True,
                                           allow_interspersed_args=False)
                contexts.append(sub_ctx)
                args, sub_ctx.args = sub_ctx.args, []
            rv = []
            for sub_ctx in contexts:
                with sub_ctx:
                    rv.append(sub_ctx.command.invoke(sub_ctx))
            return _process_result(rv)

    def resolve_command(self, ctx, args):
        cmd_name = str(args[0])
        original = cmd_name
        cmd = self.get_command(ctx, cmd_name)
        if cmd is None and ctx.token_normalize_func is not None:
            cmd_name = ctx.token_normalize_func(cmd_name)
            cmd = self.get_command(ctx, cmd_name)
            if cmd is None:
                for c in self.list_commands(ctx):
                    if ctx.token_normalize_func(c) == cmd_name:
                        cmd_name = c
                        cmd = self.get_command(ctx, c)
                        break
        if cmd is None and not ctx.resilient_parsing:
            if split_opt(cmd_name)[0]:
                self.parse_args(ctx, ctx.args)
            ctx.fail(f"No such command {original!r}.")
        return (cmd_name if cmd else None), cmd, args[1:]

    def shell_complete(self, ctx, incomplete):
        results = [
            CompletionItem(name, help=cmd.get_short_help_str())
            for name, cmd in _iter_commands(self, ctx)
            if name.startswith(incomplete)
        ]
        results.extend(super().shell_complete(ctx, incomplete))
        return results


def _iter_commands(group, ctx):
    for name in group.list_commands(ctx):
        cmd = group.get_command(ctx, name)
        if cmd is None or cmd.hidden:
            continue
        yield name, cmd


class CommandCollection(Group):
    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources) if sources is not None else []

    def add_source(self, group):
        self.sources.append(group)

    def get_command(self, ctx, cmd_name):
        rv = super().get_command(ctx, cmd_name)
        if rv is not None:
            return rv
        for source in self.sources:
            rv = source.get_command(ctx, cmd_name)
            if rv is not None:
                if self.chain and isinstance(rv, Group):
                    raise DeclarationError("Groups cannot be chained children.")
                return rv
        return None

    def list_commands(self, ctx):
        rv = set(super().list_commands(ctx))
        for source in self.sources:
            rv.update(source.list_commands(ctx))
        return sorted(rv)
