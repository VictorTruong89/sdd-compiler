import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile

from . import _compat, formatting, termui, utils
from .core import Command


class _Tee(io.BytesIO):
    def __init__(self, also):
        super().__init__()
        self._also = also

    def write(self, b):
        self._also.write(bytes(b))
        return super().write(bytes(b))


class _Stream(io.TextIOWrapper):
    def __init__(self, buf, charset, name, fileno=None):
        super().__init__(buf, encoding=charset, errors="strict", write_through=True,
                         newline="")
        self._name = name
        self._fileno = fileno

    @property
    def name(self):
        return self._name

    def fileno(self):
        if self._fileno is None:
            raise io.UnsupportedOperation("fileno")
        return self._fileno

    def close(self):
        pass


class _EchoingStdin:
    def __init__(self, input, output):
        self._input = input
        self._output = output

    def __getattr__(self, x):
        return getattr(self._input, x)

    def _echo(self, rv):
        self._output.write(rv)
        return rv

    def read(self, n=-1):
        return self._echo(self._input.read(n))

    def readline(self, n=-1):
        return self._echo(self._input.readline(n))

    def readlines(self):
        return [self._echo(x) for x in self._input.readlines()]

    def __iter__(self):
        return iter(self._echo(x) for x in self._input)


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value,
                 exit_code, exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    def _dec(self, b):
        return b.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def output(self):
        return self._dec(self.output_bytes)

    @property
    def stdout(self):
        return self._dec(self.stdout_bytes)

    @property
    def stderr(self):
        return self._dec(self.stderr_bytes)

    def __repr__(self):
        name = type(self.exception).__name__ if self.exception else "okay"
        return f"<Result {name}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        self.charset = charset
        self.env = env or {}
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def make_env(self, overrides=None):
        rv = dict(self.env)
        if overrides:
            rv.update(overrides)
        return rv

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        else:
            data = bytes(input)
        env = self.make_env(env)
        old = (sys.stdin, sys.stdout, sys.stderr, termui.visible_prompt_func,
               termui.hidden_prompt_func, termui._getchar, _compat.should_strip_ansi,
               formatting.FORCED_WIDTH)
        out_b = io.BytesIO()
        combined = io.BytesIO()
        err_b = None
        fd_state = None
        in_buf = io.BytesIO(data)
        in_text = io.TextIOWrapper(in_buf, encoding=self.charset, newline="")
        in_text.mode = "r"
        if self.capture == "fd":
            import tempfile as tf

            f_out = tf.TemporaryFile()
            f_err = tf.TemporaryFile()
            sys.stdout.flush()
            sys.stderr.flush()
            saved = (os.dup(1), os.dup(2))
            os.dup2(f_out.fileno(), 1)
            os.dup2(f_err.fileno(), 2)
            fd_state = (f_out, f_err, saved)
            out_stream = _Stream(io.FileIO(1, "w", closefd=False), self.charset, "<stdout>", 1)
            err_stream = _Stream(io.FileIO(2, "w", closefd=False), self.charset, "<stderr>", 2)
        else:
            out_b = _Tee(combined)
            err_b = _Tee(combined)
            out_stream = _Stream(out_b, self.charset, "<stdout>")
            err_stream = _Stream(err_b, self.charset, "<stderr>")
        stdin = _EchoingStdin(in_text, out_stream) if self.echo_stdin else in_text
        sys.stdin = stdin
        sys.stdout = out_stream
        sys.stderr = err_stream

        def visible_input(prompt=None):
            sys.stdout.write(prompt or "")
            line = in_text.readline()
            if line == "":
                raise EOFError()
            val = line.rstrip("\r\n")
            sys.stdout.write(f"{val}\n")
            sys.stdout.flush()
            return val

        def hidden_input(prompt=None):
            sys.stdout.write(f"{prompt or ''}\n")
            sys.stdout.flush()
            line = in_text.readline()
            if line == "":
                raise EOFError()
            return line.rstrip("\r\n")

        def _getchar(echo):
            ch = in_text.read(1)
            if ch == "":
                raise EOFError()
            if echo:
                sys.stdout.write(ch)
                sys.stdout.flush()
            if ch == "\x03":
                raise KeyboardInterrupt()
            return ch

        termui.visible_prompt_func = visible_input
        termui.hidden_prompt_func = hidden_input
        termui._getchar = _getchar
        _compat.should_strip_ansi = lambda stream=None, color_=None: (
            not color if color_ is None else not color_)
        formatting.FORCED_WIDTH = 80
        old_env = {}
        try:
            for key, value in env.items():
                old_env[key] = os.environ.get(key)
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            holder = {}
            yield holder
        finally:
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            try:
                out_stream.flush()
                err_stream.flush()
            except Exception:
                pass
            if fd_state is not None:
                f_out, f_err, saved = fd_state
                os.dup2(saved[0], 1)
                os.dup2(saved[1], 2)
                os.close(saved[0])
                os.close(saved[1])
                f_out.seek(0)
                f_err.seek(0)
                ob, eb = f_out.read(), f_err.read()
                f_out.close()
                f_err.close()
                holder["out"], holder["err"], holder["all"] = ob, eb, ob + eb
            else:
                holder["out"] = out_b.getvalue()
                holder["err"] = err_b.getvalue()
                holder["all"] = combined.getvalue()
            (sys.stdin, sys.stdout, sys.stderr, termui.visible_prompt_func,
             termui.hidden_prompt_func, termui._getchar, _compat.should_strip_ansi,
             formatting.FORCED_WIDTH) = old

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None,
               color=False, **extra):
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        exc_info = None
        return_value = None
        exception = None
        exit_code = 0
        with self.isolation(input=input, env=env, color=color) as holder:
            if isinstance(args, str):
                args = shlex.split(args)
            prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
            try:
                return_value = cli.main(args=args or [], prog_name=prog_name, **extra)
            except SystemExit as e:
                exc_info = sys.exc_info()
                code = e.code
                if code is None:
                    code = 0
                if code != 0:
                    exception = e
                if not isinstance(code, int):
                    sys.stdout.write(str(code))
                    sys.stdout.write("\n")
                    code = 1
                exit_code = code
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                sys.stdout.flush()
                sys.stderr.flush()
        return Result(self, holder["out"], holder["err"], holder["all"], return_value,
                      exit_code, exception, exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass
