from optlyn import argument, command, echo, group, option
from optlyn.testing import CliRunner


def test_basic_group():
    @group()
    def cli():
        pass

    @cli.command()
    @option("--n", type=int, default=1)
    @argument("name")
    def hi(n, name):
        echo(f"{name}{n}")

    r = CliRunner().invoke(cli, ["hi", "x", "--n", "2"])
    assert r.exit_code == 0 and r.output == "x2\n"
    assert CliRunner().invoke(cli, []).exit_code == 2
