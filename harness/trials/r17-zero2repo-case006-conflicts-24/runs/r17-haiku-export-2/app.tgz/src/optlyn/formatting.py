"""Text wrapping and definition-list layout used by help pages."""

from __future__ import annotations

import re
import textwrap

MAX_CONTENT_WIDTH = 80
TEXT_WRAP_DEFAULT = 78
_PARAGRAPH_SPLIT = re.compile(r"\n\s*\n")


def wrap_text(text, width=TEXT_WRAP_DEFAULT, initial_indent="", subsequent_indent="",
              preserve_paragraphs=False):
    """Rewrap ``text`` to ``width`` columns. Accepts any string.

    Single newlines inside a paragraph are not kept as hard breaks. A paragraph
    whose first line is only a backspace character is left unwrapped, keeps its
    line breaks, and the backspace line is removed.
    """
    width = max(int(width), 1)
    out = []
    text = str(text).strip("\n")
    for paragraph in _PARAGRAPH_SPLIT.split(text):
        if not paragraph.strip():
            continue
        lines = paragraph.splitlines()
        if lines and lines[0].strip() == "\b":
            kept = [line for line in lines[1:]]
            rendered = []
            for index, line in enumerate(kept):
                indent = initial_indent if (not out and not rendered and index == 0) else subsequent_indent
                rendered.append(indent + line.rstrip())
            out.append("\n".join(rendered))
            continue
        flowed = " ".join(line.strip() for line in lines if line.strip())
        first_indent = initial_indent if not out else subsequent_indent
        wrapped = textwrap.fill(
            flowed,
            width=width,
            initial_indent=first_indent,
            subsequent_indent=subsequent_indent,
            break_long_words=False,
            break_on_hyphens=False,
        )
        out.append(wrapped)
    return "\n\n".join(out)


def format_definition_list(rows, width, col_max=30, col_spacing=2, indent=2):
    """Lay out ``(first, second)`` rows as an aligned two-column block."""
    if not rows:
        return []
    first_width = min(max(len(first) for first, _ in rows), col_max)
    pad = " " * indent
    gap = " " * col_spacing
    lines = []
    for first, second in rows:
        if not second:
            lines.append(pad + first)
            continue
        text_width = max(width - indent - first_width - col_spacing, 10)
        wrapped = wrap_text(second, width=text_width).splitlines() or [""]
        continuation = pad + " " * (first_width + col_spacing)
        if len(first) > first_width:
            lines.append(pad + first)
            lines.extend(continuation + line for line in wrapped)
        else:
            lines.append(pad + first.ljust(first_width) + gap + wrapped[0])
            lines.extend(continuation + line for line in wrapped[1:])
    return lines
