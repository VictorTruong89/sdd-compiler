"""File opening, standard-stream accessors, application directories, and filenames."""

from __future__ import annotations

import io
import os
import re
import sys
import tempfile

from .exceptions import FileError

DASH = "-"


class NonClosingStream:
    """Proxy for a standard stream: ``close()`` flushes instead of closing."""

    def __init__(self, stream):
        self._stream = stream

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __iter__(self):
        return iter(self._stream)

    def close(self):
        try:
            self._stream.flush()
        except (OSError, ValueError):
            pass

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()


class AtomicFile:
    """Writes to a sibling temporary file; the target is replaced on close."""

    def __init__(self, handle, tmp_path, target):
        self._handle = handle
        self._tmp = tmp_path
        self._target = target
        self._closed = False

    def __getattr__(self, name):
        return getattr(self._handle, name)

    def __iter__(self):
        return iter(self._handle)

    def close(self):
        if self._closed:
            return
        self._closed = True
        self._handle.close()
        os.replace(self._tmp, self._target)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()


class LazyFile:
    """Opens its file on first use; a failure there is a general file error."""

    def __init__(self, filename, mode, encoding, errors, atomic):
        self.name = filename
        self.mode = mode
        self._open_args = (encoding, errors, atomic)
        self._handle = None
        self._closed = False

    def _open(self):
        if self._handle is None:
            if self._closed:
                raise ValueError("I/O operation on closed file.")
            encoding, errors, atomic = self._open_args
            try:
                self._handle = _open_real(self.name, self.mode, encoding, errors, atomic)
            except OSError as exc:
                raise FileError(self.name, exc.strerror or str(exc)) from exc
        return self._handle

    def __getattr__(self, name):
        return getattr(self._open(), name)

    def __iter__(self):
        return iter(self._open())

    def close(self):
        if self._handle is not None:
            self._handle.close()
        self._closed = True

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()


def _open_real(filename, mode, encoding, errors, atomic):
    if "b" in mode:
        handle_mode = mode
        encoding = errors = None
    else:
        handle_mode = mode
    writing = "w" in mode
    if atomic and writing:
        directory = os.path.dirname(os.path.abspath(filename))
        fd, tmp_path = tempfile.mkstemp(dir=directory, prefix=".optlyn-", suffix=".tmp")
        try:
            handle = os.fdopen(fd, handle_mode, encoding=encoding, errors=errors)
        except BaseException:
            os.close(fd)
            raise
        return AtomicFile(handle, tmp_path, filename)
    return open(filename, handle_mode, encoding=encoding, errors=errors)


def get_binary_stdin():
    return getattr(sys.stdin, "buffer", sys.stdin)


def get_binary_stdout():
    return getattr(sys.stdout, "buffer", sys.stdout)


def get_binary_stderr():
    return getattr(sys.stderr, "buffer", sys.stderr)


def get_text_stdin(encoding=None, errors=None):
    return sys.stdin


def get_text_stdout(encoding=None, errors=None):
    return sys.stdout


def get_text_stderr(encoding=None, errors=None):
    return sys.stderr


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file, or a standard stream for ``-``. Returns a file-like object."""
    filename = os.fspath(filename) if not isinstance(filename, bytes) else os.fsdecode(filename)
    if filename == DASH:
        writing = "w" in mode or "a" in mode
        if "b" in mode:
            raw = get_binary_stdout() if writing else get_binary_stdin()
            return NonClosingStream(raw)
        base = sys.stdout if writing else sys.stdin
        if encoding:
            buffer = getattr(base, "buffer", None)
            if buffer is not None:
                wrapper = io.TextIOWrapper(buffer, encoding=encoding, errors=errors, line_buffering=True)
                return NonClosingStream(wrapper)
        return NonClosingStream(base)
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    try:
        return _open_real(filename, mode, encoding, errors, atomic)
    except OSError as exc:
        raise FileError(filename, exc.strerror or str(exc)) from exc


def format_filename(filename, shorten=False):
    """Return a printable text form of a filename. Never fails; keeps names distinct."""
    if isinstance(filename, bytes):
        text = os.fsdecode(filename)
    else:
        text = os.fspath(filename)
    if shorten:
        text = os.path.basename(text)
    return text.encode("utf-8", "surrogateescape").decode("utf-8", "backslashreplace")


def get_app_dir(app_name, roaming=True, force_posix=False):
    """Return the per-user configuration directory for ``app_name``."""
    home = os.path.expanduser("~")
    if force_posix:
        folder = re.sub(r"\s+", "-", app_name.lower())
        return os.path.join(home, "." + folder)
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    if sys.platform.startswith("win"):
        base = os.environ.get("APPDATA") if roaming else os.environ.get("LOCALAPPDATA")
        base = base or os.path.join(home, "AppData", "Roaming" if roaming else "Local")
        return os.path.join(base, app_name)
    folder = re.sub(r"\s+", "-", app_name.lower())
    config_home = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(config_home, folder)
