"""Shell completion: registration scripts and suggestion output for bash, zsh, fish and PowerShell."""

from __future__ import annotations

import os
import re

from . import termui
from .core import Argument, Group, Option
from .paramtypes import File, Path


SHELLS = ("bash", "zsh", "fish", "powershell")
ACTIONS = ("source", "complete")


class CompletionItem:
    """A suggestion with an optional help string and a type (``"plain"`` for an ordinary value)."""

    def __init__(self, value, help=None, type="plain"):
        self.value = str(value)
        self.help = help
        self.type = type


def _as_item(entry):
    if isinstance(entry, CompletionItem):
        return entry
    if hasattr(entry, "value"):
        return CompletionItem(entry.value, getattr(entry, "help", None), getattr(entry, "type", "plain"))
    return CompletionItem(entry)


def _visible_options(params):
    return [p for p in params if isinstance(p, Option) and not p.hidden]


def _option_names(option):
    return option.opts + option.secondary_opts


def _find_option(params, token):
    for param in params:
        if isinstance(param, Option) and token in _option_names(param):
            return param
    return None


def _path_request(param):
    kind = "file"
    if isinstance(param.type, Path) and not param.type.file_okay and param.type.dir_okay:
        kind = "dir"
    return kind


def _param_suggestions(ctx, param, incomplete):
    """Suggestions for the value of ``param`` (a value-taking option or an argument)."""
    if param.shell_complete is not None:
        return [_as_item(e) for e in param.shell_complete(ctx, param, incomplete)], None
    if isinstance(param.type, (File, Path)):
        return [], _path_request(param)
    return [_as_item(e) for e in param.type.shell_complete(ctx, param, incomplete)], None


def _walk(command, args, root_ctx):
    """Resolve the command the completion applies to, skipping option tokens and their values."""
    from .core import Context

    node, node_ctx = command, root_ctx
    positional = []
    index = 0
    while index < len(args):
        token = args[index]
        index += 1
        if token == "--":
            positional.extend(args[index:])
            break
        if len(token) > 1 and token[0] in "-+/":
            if "=" not in token:
                option = _find_option(node_ctx.command_params, token)
                if option is not None and option.takes_value and not option.optional_value:
                    index += option.nargs
            continue
        if isinstance(node, Group):
            sub = node.get_command(node_ctx, token)
            if sub is not None:
                node = sub
                node_ctx = Context(sub, info_name=token, parent=node_ctx)
                node_ctx.command_params = sub.get_params(node_ctx)
                continue
        positional.append(token)
    return node, node_ctx, positional


def suggestions(command, prog_name, words, incomplete, shell):
    """Return ``(items, path_kind)`` for a completion request at the current word."""
    from .core import Context

    root_ctx = Context(command, info_name=prog_name)
    root_ctx.command_params = command.get_params(root_ctx)
    node, node_ctx, positional = _walk(command, words, root_ctx)
    params = node_ctx.command_params
    previous = words[-1] if words else None
    prev_option = _find_option(params, previous) if previous else None
    if prev_option is not None and prev_option.takes_value and not prev_option.optional_value:
        return _param_suggestions(node_ctx, prev_option, incomplete)
    if incomplete[:1] in ("-", "+", "/") and incomplete:
        # Options are listed only once a dash (or other prefix) has been typed.
        items = [CompletionItem(name, help=p.help) for p in _visible_options(params)
                 for name in _option_names(p) if name.startswith(incomplete)]
        return items, None
    if isinstance(node, Group):
        items = []
        for name in node.list_commands(node_ctx):
            sub = node.get_command(node_ctx, name)
            if sub is None or sub.hidden or not name.startswith(incomplete):
                continue
            items.append(CompletionItem(name, help=sub.get_short_help_str()))
        return items, None
    arguments = [p for p in params if isinstance(p, Argument)]
    if not arguments:
        return [], None
    target = arguments[min(len(positional), len(arguments) - 1)]
    items, kind = _param_suggestions(node_ctx, target, incomplete)
    return [item for item in items if item.value.startswith(incomplete)], kind


def _format_line(item, shell):
    if item.type != "plain":
        return f"@{item.type}:{item.value}"
    if shell in ("zsh", "fish") and item.help:
        return f"{item.value}\t{' '.join(str(item.help).split())}"
    return item.value


def _emit(items, path_kind, incomplete, shell):
    lines = []
    if path_kind is not None:
        lines.append(f"@path:{path_kind}:{incomplete}")
    for item in items:
        lines.append(_format_line(item, shell))
    for line in lines:
        termui.echo(line)


def _script(shell, prog_name, variable):
    safe = re.sub(r"\W", "_", prog_name)
    if shell == "bash":
        return (
            f"_{safe}_completion() {{\n"
            "    local IFS=$'\\n'\n"
            "    local response\n"
            f"    response=$(env COMP_WORDS=\"${{COMP_WORDS[*]}}\" COMP_CWORD=$COMP_CWORD {variable}=bash_complete {prog_name} 2>/dev/null)\n"
            "    COMPREPLY=()\n"
            "    for completion in $response; do\n"
            "        COMPREPLY+=(\"$completion\")\n"
            "    done\n"
            "    return 0\n"
            "}\n"
            f"complete -o default -F _{safe}_completion {prog_name}\n"
        )
    if shell == "zsh":
        return (
            f"#compdef {prog_name}\n"
            f"_{safe}_completion() {{\n"
            "    local -a completions\n"
            "    local line\n"
            f"    local response=(\"${{(@f)$(env COMP_WORDS=\"${{words[*]}}\" COMP_CWORD=$((CURRENT-1)) {variable}=zsh_complete {prog_name})}}\")\n"
            "    for line in $response; do\n"
            "        completions+=(\"${line%%$'\\t'*}\")\n"
            "    done\n"
            "    compadd -- $completions\n"
            "}\n"
            f"compdef _{safe}_completion {prog_name}\n"
        )
    if shell == "fish":
        return (
            f"complete --no-files --command {prog_name} --arguments "
            f"'(env COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -ct) {variable}=fish_complete {prog_name})'\n"
        )
    return (
        f"Register-ArgumentCompleter -Native -CommandName {prog_name} -ScriptBlock {{\n"
        "    param($wordToComplete, $commandAst, $cursorPosition)\n"
        f"    $env:COMP_WORDS = $commandAst.ToString()\n"
        f"    $env:COMP_CWORD = $wordToComplete\n"
        f"    $env:{variable} = 'powershell_complete'\n"
        f"    & {prog_name} | ForEach-Object {{\n"
        "        [System.Management.Automation.CompletionResult]::new($_, $_, 'ParameterValue', $_)\n"
        "    }\n"
        "    Remove-Item Env:\\$env:COMP_WORDS -ErrorAction SilentlyContinue\n"
        "}\n"
    )


def run(command, prog_name, instruction):
    """Handle a completion instruction such as ``bash_source``; returns the exit status."""
    shell, _, action = instruction.rpartition("_")
    variable = "_" + re.sub(r"[-\s]", "_", prog_name).upper() + "_COMPLETE"
    if shell not in SHELLS or action not in ACTIONS:
        termui.echo(f"Error: unknown completion instruction {instruction!r}.", err=True)
        return 2
    if action == "source":
        termui.echo(_script(shell, prog_name, variable))
        return 0
    raw_words = os.environ.get("COMP_WORDS", "")
    words = raw_words.split(" ")
    if shell == "fish":
        incomplete = os.environ.get("COMP_CWORD", "")
        args = words[1:]
        if args and args[-1] == incomplete:
            args = args[:-1]
    else:
        try:
            cword = int(os.environ.get("COMP_CWORD", str(len(words))))
        except ValueError:
            cword = len(words)
        args = words[1:cword]
        incomplete = words[cword] if cword < len(words) else ""
    items, kind = suggestions(command, prog_name, args, incomplete, shell)
    _emit(items, kind, incomplete, shell)
    return 0
