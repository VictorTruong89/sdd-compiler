"""Exception classes used by Optlyn.

Exit statuses (standalone mode): usage errors exit with 2, aborts and other
library-signalled errors exit with 1, and an author clean stop exits with the
status the author supplied.
"""

from __future__ import annotations

EXIT_SUCCESS = 0
EXIT_USAGE = 2
EXIT_ERROR = 1


class OptlynException(Exception):
    """Base class for errors the library reports to the user."""

    exit_code = EXIT_ERROR

    def format_message(self) -> str:
        return str(self.args[0]) if self.args else ""


class UsageError(OptlynException):
    """The command line was used incorrectly (usage-error exit class)."""

    exit_code = EXIT_USAGE

    def __init__(self, message=None, ctx=None, show_help=False):
        super().__init__(message)
        self.message = message
        self.ctx = ctx
        self.show_help = show_help

    def format_message(self) -> str:
        return self.message or ""

    def show(self, file=None) -> None:
        """Write the usage report (and help page when asked) to standard error."""
        from .termui import echo

        ctx = self.ctx
        if ctx is not None and self.show_help:
            echo(ctx.get_help(), file=file, err=True)
            if self.message:
                echo(file=file, err=True)
        elif ctx is not None:
            echo(ctx.get_usage(), file=file, err=True)
            help_names = ctx.help_option_names or ["--help"]
            echo(f"Try '{ctx.command_path} {help_names[0]}' for help.", file=file, err=True)
            echo(file=file, err=True)
        text = self.format_message()
        if text:
            echo(f"Error: {text}", file=file, err=True)


class BadParameter(UsageError):
    """A value was refused by a type, a callback, or a conversion function."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self) -> str:
        if self.param_hint is not None:
            hint = self.param_hint
        elif self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        else:
            return self.message or ""
        return f"Invalid value for {hint}: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter received no value from any source."""

    def __init__(self, message=None, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx, param, param_hint)

    def format_message(self) -> str:
        if self.message:
            return self.message
        if self.param is None:
            return "Missing parameter."
        kind = "argument" if self.param.is_argument else "option"
        return f"Missing {kind} {self.param.get_error_hint(self.ctx)}."


class NoSuchOption(UsageError):
    """An option token matched no declared flag name."""

    def __init__(self, option_name, ctx=None):
        super().__init__(f"No such option: {option_name}", ctx)
        self.option_name = option_name


class BadArgumentUsage(UsageError):
    """An argument was given the wrong number of tokens."""


class BadOptionUsage(UsageError):
    """An option was used incorrectly (for example, a missing value)."""


class FileError(OptlynException):
    """A file could not be opened or used when I/O started (general error class)."""

    exit_code = EXIT_ERROR

    def __init__(self, filename, hint):
        super().__init__(f"Could not open file '{filename}': {hint}")
        self.filename = filename
        self.hint = hint


class Abort(RuntimeError):
    """The user declined, typed end-of-file, interrupted, or the author aborted."""

    exit_code = EXIT_ERROR


class Exit(RuntimeError):
    """An author clean stop, or an intentional help/version exit."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code
