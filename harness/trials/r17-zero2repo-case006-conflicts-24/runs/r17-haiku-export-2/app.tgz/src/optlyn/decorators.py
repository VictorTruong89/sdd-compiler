"""Declaration decorators: command, group, option, argument, and ready-made options."""

from __future__ import annotations

import functools
import importlib.metadata
import inspect
import sys

from . import termui
from ._globals import get_current_context
from .core import Argument, Command, CommandCollection, Group, Option, _help_callback



def _attach_param(func, param):
    if isinstance(func, Command):
        func.params.insert(0, param)
    else:
        func.__dict__.setdefault("__optlyn_params__", []).append(param)
    return func


def _take_params(func):
    """Return the declarations attached to ``func``, top-down, and clear them from the function."""
    attached = func.__dict__.pop("__optlyn_params__", [])
    return list(reversed(attached))


def _derive_name(func_name):
    name = func_name.lower()
    for suffix in ("_command", "_cmd", "_group", "_grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def _doc_help(func, attrs):
    if "help" not in attrs and func.__doc__:
        attrs["help"] = inspect.cleandoc(func.__doc__)


def command(name=None, cls=None, **attrs):
    """Turn a function into a ``Command`` (``@command()`` or ``@command``)."""
    if callable(name) and not isinstance(name, type) and cls is None and not attrs:
        return command()(name)

    def decorator(func):
        params = _take_params(func)
        cmd_name = name if name is not None else _derive_name(func.__name__)
        options = dict(attrs)
        _doc_help(func, options)
        cmd_cls = cls or Command
        return cmd_cls(cmd_name, callback=func, params=params, **options)

    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a ``Group`` (``@group()`` or ``@group``)."""
    if callable(name) and not isinstance(name, type) and cls is None and not attrs:
        return group()(name)

    def decorator(func):
        params = _take_params(func)
        grp_name = name if name is not None else _derive_name(func.__name__)
        options = dict(attrs)
        _doc_help(func, options)
        grp_cls = cls or Group
        if grp_cls is CommandCollection or (isinstance(grp_cls, type) and issubclass(grp_cls, CommandCollection)):
            return grp_cls(grp_name, callback=func, params=params, **options)
        return grp_cls(grp_name, callback=func, params=params, **options)

    return decorator


def option(*param_decls, cls=None, **attrs):
    """Attach an option to the decorated function (or command)."""
    def decorator(func):
        param_cls = cls or Option
        return _attach_param(func, param_cls(list(param_decls), **attrs))

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach a positional argument to the decorated function (or command)."""
    def decorator(func):
        param_cls = cls or Argument
        return _attach_param(func, param_cls(list(param_decls), **attrs))

    return decorator


def help_option(*param_decls, **kwargs):
    """An extra eager help flag that prints the help page and exits."""
    if not param_decls:
        param_decls = ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _help_callback)
    return option(*param_decls, **kwargs)


def _caller_package():
    frame = sys._getframe(2)
    module = frame.f_globals.get("__name__", "")
    return module.partition(".")[0] or None


def _detect_version(package_name):
    """Version of an installed distribution named ``package_name`` (or providing that import)."""
    try:
        return importlib.metadata.version(package_name)
    except importlib.metadata.PackageNotFoundError:
        pass
    top = package_name.partition(".")[0]
    providers = importlib.metadata.packages_distributions().get(top, [])
    for dist in providers:
        try:
            return importlib.metadata.version(dist)
        except importlib.metadata.PackageNotFoundError:
            continue
    raise RuntimeError(f"Could not determine the version for {package_name!r}.")


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    """An eager ``--version`` flag that prints a version identity and exits."""
    if not param_decls:
        param_decls = ("--version",)
    if version is None and package_name is None:
        package_name = _caller_package()

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        identity = version if version is not None else _detect_version(package_name)
        program = prog_name or ctx.find_root().info_name
        template = message or "%(prog)s, version %(version)s"
        termui.echo(template % {"prog": program, "version": identity}, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*param_decls, **kwargs)


def custom_version_option(callback, *param_decls, **kwargs):
    """An eager version flag whose whole identity is the string returned by ``callback(ctx)``."""
    if not param_decls:
        param_decls = ("--version",)

    def handler(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        termui.echo(callback(ctx), color=True)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = handler
    return option(*param_decls, **kwargs)


def password_option(*param_decls, **kwargs):
    """A prompting, hidden, confirmed option (``--password`` by default)."""
    if not param_decls:
        param_decls = ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    return option(*param_decls, **kwargs)


def confirmation_option(*param_decls, **kwargs):
    """A yes-flag that is not passed to the callback; asks when omitted and aborts on no."""
    if not param_decls:
        param_decls = ("--yes",)
    question = kwargs.pop("prompt", "Do you want to continue?")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", question)
    kwargs.setdefault("_confirm_text", True)
    return option(*param_decls, **kwargs)


def pass_context(func):
    """Pass the current ``Context`` as the first positional argument."""
    @functools.wraps(func)
    def new_func(*args, **kwargs):
        return func(get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(func):
    """Pass the current context's author object as the first positional argument."""
    @functools.wraps(func)
    def new_func(*args, **kwargs):
        return func(get_current_context().obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type, ensure=False):
    """Build a decorator that passes the nearest object of ``object_type``."""
    def decorator(func):
        @functools.wraps(func)
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            return func(obj, *args, **kwargs)

        return new_func

    return decorator
