"""Parameter types: built-in conversions and the ``ParamType`` base class."""

from __future__ import annotations

import datetime as _dt
import enum
import os
import pathlib
import uuid

from . import utils
from .exceptions import BadParameter, FileError

TRUE_WORDS = ("1", "true", "t", "yes", "y", "on")
FALSE_WORDS = ("0", "false", "f", "no", "n", "off")


class ParamType:
    """Base class for parameter types.

    Subclasses set ``name`` (shown upper-cased as the default metavar) and
    implement ``convert(value, param, ctx)``. ``convert`` refuses a value by
    raising ``BadParameter``.
    """

    name = "text"
    is_composite = False

    def __call__(self, value, param=None, ctx=None):
        if value is None:
            return None
        return self.convert(value, param, ctx)

    def convert(self, value, param=None, ctx=None):
        return value

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def get_metavar(self, param=None):
        return None

    def shell_complete(self, ctx, param, incomplete):
        return []

    def split_envvar_value(self, rv):
        """Split a non-empty environment string for repeatable and multi-value parameters."""
        return rv.split()

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        return str(value)


class UnprocessedParamType(ParamType):
    """Delivers the raw token without conversion."""

    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, int) and not isinstance(value, bool):
            return value
        try:
            return int(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        try:
            return float(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid float.", param, ctx)


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in TRUE_WORDS:
            return True
        if text in FALSE_WORDS:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID value.", param, ctx)


class Choice(ParamType):
    """A closed list of allowed values, or the member names of an enumeration."""

    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.choices = list(choices)
            self._keys = [member.name for member in self.choices]
        else:
            self.choices = list(choices)
            self._keys = [str(choice) for choice in self.choices]
        self.case_sensitive = case_sensitive

    def get_metavar(self, param=None):
        return "[" + "|".join(self._keys) + "]"

    def convert(self, value, param=None, ctx=None):
        for choice in self.choices:
            if value is choice:
                return choice
        normed = value
        if ctx is not None and ctx.token_normalize_func is not None and isinstance(value, str):
            normed = ctx.token_normalize_func(value)
        for choice, key in zip(self.choices, self._keys):
            candidate = key
            if ctx is not None and ctx.token_normalize_func is not None:
                candidate = ctx.token_normalize_func(key)
            if self.case_sensitive:
                if normed == candidate:
                    return choice
            elif str(normed).casefold() == str(candidate).casefold():
                return choice
        options = ", ".join(repr(key) for key in self._keys)
        self.fail(f"{value!r} is not one of {options}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        return [key for key in self._keys if key.startswith(incomplete)]


class DateTime(ParamType):
    """Parses a date and time with the first matching strptime format."""

    name = "datetime"
    DEFAULT_FORMATS = ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S")

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(self.DEFAULT_FORMATS)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        text = str(value).strip()
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(text, fmt)
            except ValueError:
                continue
        formats = ", ".join(repr(fmt) for fmt in self.formats)
        self.fail(f"{value!r} does not match the formats {formats}.", param, ctx)


def _range_text(lo, hi, lo_open, hi_open):
    left = "" if lo is None else f"{lo}{'<' if lo_open else '<='}"
    right = "" if hi is None else f"{'<' if hi_open else '<='}{hi}"
    return f"{left}x{right}"


class IntRange(ParamType):
    """An integer within optional bounds; ``clamp`` replaces an out-of-range value."""

    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min, self.max = min, max
        self.min_open, self.max_open = min_open, max_open
        self.clamp = clamp
        self._int = IntParamType()

    def get_metavar(self, param=None):
        return None

    def convert(self, value, param=None, ctx=None):
        number = self._int.convert(value, param, ctx)
        if self.min is not None:
            below = number <= self.min if self.min_open else number < self.min
            if below:
                if self.clamp:
                    return self.min + 1 if self.min_open else self.min
                self.fail(f"{number} is not in the range {_range_text(self.min, self.max, self.min_open, self.max_open)}.", param, ctx)
        if self.max is not None:
            above = number >= self.max if self.max_open else number > self.max
            if above:
                if self.clamp:
                    return self.max - 1 if self.max_open else self.max
                self.fail(f"{number} is not in the range {_range_text(self.min, self.max, self.min_open, self.max_open)}.", param, ctx)
        return number


class FloatRange(ParamType):
    """A float within optional bounds. Clamp with an open bound is refused at construction."""

    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min_open or max_open):
            raise ValueError("Clamping is not supported for open bounds.")
        if min is not None and max is not None and min > max:
            raise ValueError("The minimum bound is greater than the maximum bound.")
        self.min, self.max = min, max
        self.min_open, self.max_open = min_open, max_open
        self.clamp = clamp
        self._float = FloatParamType()

    def convert(self, value, param=None, ctx=None):
        number = self._float.convert(value, param, ctx)
        if self.min is not None:
            below = number <= self.min if self.min_open else number < self.min
            if below:
                if self.clamp:
                    return float(self.min)
                self.fail(f"{number} is not in the range {_range_text(self.min, self.max, self.min_open, self.max_open)}.", param, ctx)
        if self.max is not None:
            above = number >= self.max if self.max_open else number > self.max
            if above:
                if self.clamp:
                    return float(self.max)
                self.fail(f"{number} is not in the range {_range_text(self.min, self.max, self.min_open, self.max_open)}.", param, ctx)
        return number


class Tuple(ParamType):
    """A fixed-length product of inner types, one converted value per position."""

    name = "tuple"
    is_composite = True

    def __init__(self, types):
        self.types = [convert_type(ty) for ty in types]

    def get_metavar(self, param=None):
        return "<" + " ".join(ty.name.upper().replace(" ", "_") for ty in self.types) + ">"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, str) or not isinstance(value, (list, tuple)):
            self.fail(f"{value!r} is not a sequence of {len(self.types)} values.", param, ctx)
        if len(value) != len(self.types):
            self.fail(f"Expected {len(self.types)} values, got {len(value)}.", param, ctx)
        return tuple(ty(item, param, ctx) for ty, item in zip(self.types, value))


class _PathLike(ParamType):
    def split_envvar_value(self, rv):
        return rv.split(os.pathsep)


class File(_PathLike):
    """Opens a file; the token ``-`` means standard input or output."""

    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"Unsupported file mode {mode!r}.")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        is_write = "w" in self.mode
        lazy = self.lazy if self.lazy is not None else is_write
        filename = str(value)
        try:
            return utils.open_file(filename, self.mode, self.encoding, self.errors,
                                   lazy=lazy, atomic=self.atomic)
        except FileError as exc:
            self.fail(f"'{filename}': {exc.hint}", param, ctx)


class Path(_PathLike):
    """A filesystem path, validated by the requested checks; not an open file."""

    name = "path"

    def __init__(self, exists=False, file_okay=True, dir_okay=True, writable=False, readable=True,
                 resolve_path=False, allow_dash=False, path_type=None, executable=False):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def convert(self, value, param=None, ctx=None):
        raw = os.fsdecode(value) if isinstance(value, bytes) else str(value)
        if self.allow_dash and raw == "-":
            return self._deliver("-")
        path = raw
        if self.resolve_path:
            path = os.path.realpath(path)
        if not os.path.exists(path):
            if self.exists:
                self.fail(f"{raw!r} does not exist.", param, ctx)
            return self._deliver(path)
        if os.path.isdir(path):
            if not self.dir_okay:
                self.fail(f"{raw!r} is a directory.", param, ctx)
        elif not self.file_okay:
            self.fail(f"{raw!r} is a file.", param, ctx)
        checks = [(self.readable, os.R_OK, "readable"), (self.writable, os.W_OK, "writable"),
                  (self.executable, os.X_OK, "executable")]
        for wanted, flag, label in checks:
            if wanted and not os.access(path, flag):
                self.fail(f"{raw!r} is not {label}.", param, ctx)
        return self._deliver(path)

    def _deliver(self, path):
        if self.path_type is None or self.path_type is str:
            return path
        if self.path_type is pathlib.Path:
            return pathlib.Path(path)
        return self.path_type(path)


class FuncParamType(ParamType):
    """Wraps a conversion function ``f(token) -> value`` that refuses with ValueError."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text") or "text"

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except ValueError as exc:
            self.fail(str(exc) or f"{value!r} is not valid.", param, ctx)


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()

_BUILTIN_BY_PYTYPE = {str: STRING, int: INT, float: FLOAT, bool: BOOL, uuid.UUID: UUID}


def convert_type(ty=None, default=None):
    """Turn a declared type (or a default's type) into a ``ParamType`` instance."""
    if ty is None:
        if default is None:
            return STRING
        if isinstance(default, (list, tuple)):
            if not default:
                return STRING
            return convert_type(None, default[0])
        if isinstance(default, bool):
            return BOOL
        if isinstance(default, int):
            return INT
        if isinstance(default, float):
            return FLOAT
        return STRING
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    if isinstance(ty, type) and ty in _BUILTIN_BY_PYTYPE:
        return _BUILTIN_BY_PYTYPE[ty]
    if isinstance(ty, (list, tuple)):
        return Tuple(ty)
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"Unsupported parameter type: {ty!r}")
