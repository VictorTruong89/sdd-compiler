"""Parameters, invocation context, commands and groups: parsing, dispatch, and help."""

from __future__ import annotations

import os
import re
import shutil
import sys
from contextlib import contextmanager
from enum import Enum

from . import termui
from ._globals import pop_context, push_context
from .exceptions import (Abort, BadArgumentUsage, BadParameter, Exit, MissingParameter,
                         OptlynException, UsageError)
from .formatting import MAX_CONTENT_WIDTH, format_definition_list, wrap_text
from .paramtypes import BOOL, FALSE_WORDS, INT, TRUE_WORDS, Tuple, convert_type
from .parser import BARE, COUNT, OptionParser


_PREFIX_CHARS = ("-", "/", "+")


class ParameterSource(Enum):
    """Where a parameter's value came from (for ``Context.get_parameter_source``)."""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


# Lower rank is more explicit; feature-switch groups keep the most explicit value.
_SOURCE_RANK = {
    ParameterSource.PROMPT: 0,
    ParameterSource.COMMANDLINE: 1,
    ParameterSource.ENVIRONMENT: 2,
    ParameterSource.DEFAULT_MAP: 3,
    ParameterSource.DEFAULT: 4,
}


def _is_sequence(value):
    return isinstance(value, (list, tuple))


class Parameter:
    """Common behaviour of options and arguments."""

    is_argument = False

    def _init_common(self, name, type_, default, required, callback, nargs, multiple, metavar,
                     expose_value, is_eager, envvar, shell_complete, deprecated, allow_from_autoenv):
        self.name = name
        self.default = default
        self.required = required
        self.callback = callback
        self.multiple = multiple
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        self.envvar = envvar
        self.shell_complete = shell_complete
        self.deprecated = deprecated
        self.allow_from_autoenv = allow_from_autoenv
        if type_ is not None and isinstance(type_, Tuple) and nargs is None:
            nargs = len(type_.types)
        self.nargs = 1 if nargs is None else nargs
        self.type = type_

    @property
    def is_variadic(self):
        return self.nargs == -1

    def get_error_hint(self, ctx):
        return f"'{self.name}'"

    def get_default(self, ctx=None):
        value = self.default
        if callable(value):
            value = value()
        if value is None and getattr(self, "is_flag", False):
            return False
        return value

    def empty_value(self):
        if getattr(self, "count", False):
            return 0
        if self.multiple or self.is_variadic:
            return ()
        return None

    def convert_value(self, ctx, raw):
        if raw is None:
            return None
        try:
            return self.type(raw, self, ctx)
        except BadParameter as exc:
            if exc.param is None:
                exc.param = self
            if exc.ctx is None:
                exc.ctx = ctx
            raise

    def convert_tokens(self, ctx, tokens):
        if isinstance(self.type, Tuple):
            return self.convert_value(ctx, list(tokens))
        if self.nargs == 1 and not self.is_variadic:
            return self.convert_value(ctx, tokens[0])
        return tuple(self.convert_value(ctx, token) for token in tokens)

    def value_from_default(self, ctx, raw):
        if getattr(self, "is_flag", False) and not getattr(self, "count", False):
            return raw
        if self.multiple or self.is_variadic:
            if isinstance(raw, (str, bytes)) or not _is_sequence(raw):
                raise self._usage_error(ctx, f"{self.get_error_hint(ctx)} needs an iterable (sequence) default.")
            if self.nargs != 1:
                return tuple(self.convert_tokens(ctx, list(item) if _is_sequence(item) else [item]) for item in raw)
            return tuple(self.convert_value(ctx, item) for item in raw)
        if self.nargs != 1:
            if isinstance(raw, str):
                raw = self.type.split_envvar_value(raw)
            return self.convert_tokens(ctx, list(raw))
        return self.convert_value(ctx, raw)

    def _usage_error(self, ctx, message):
        return UsageError(message, ctx)

    def value_from_occurrences(self, ctx, occs):
        """Convert the command-line occurrences of this parameter into its delivered value."""
        if getattr(self, "count", False):
            return sum(1 for occ in occs if occ is COUNT)
        if getattr(self, "is_flag", False):
            last = occs[-1]
            if isinstance(last, bool):
                return self.flag_value if last else (not self.flag_value)
        if self.is_variadic:
            flat = [token for occ in occs for token in occ]
            return self.convert_tokens(ctx, flat)
        if self.multiple:
            return tuple(self._occurrence_value(ctx, occ) for occ in occs)
        return self._occurrence_value(ctx, occs[-1])

    def _occurrence_value(self, ctx, occ):
        if occ is BARE:
            return self.convert_value(ctx, self.flag_value)
        if isinstance(occ, bool):
            return self.flag_value if occ else (not self.flag_value)
        return self.convert_tokens(ctx, occ)

    def envvar_names(self, ctx):
        names = []
        if isinstance(self.envvar, str):
            names.append(self.envvar)
        elif self.envvar:
            names.extend(self.envvar)
        if not self.is_argument and self.allow_from_autoenv and ctx.auto_envvar_prefix:
            parts = [ctx.auto_envvar_prefix] + ctx.path_names() + [self.name]
            names.append("_".join(parts).upper().replace("-", "_"))
        return names

    def env_occurrences(self, ctx):
        """Occurrences supplied by the first set environment variable, or None."""
        for name in self.envvar_names(ctx):
            raw = os.environ.get(name)
            if raw is None or raw == "":
                continue
            if getattr(self, "is_flag", False):
                payload = self._flag_env(raw)
                if payload is None:
                    continue
                return [payload]
            if getattr(self, "count", False):
                continue
            if self.nargs == 1 and not self.multiple and not self.is_variadic:
                return [[raw]]
            tokens = self.type.split_envvar_value(raw)
            if not tokens:
                continue
            if self.is_variadic:
                return [tokens]
            if self.nargs == 1:
                return [[token] for token in tokens]
            chunks = [tokens[i:i + self.nargs] for i in range(0, len(tokens), self.nargs)]
            return chunks if self.multiple else chunks[:1]
        return None

    def _flag_env(self, raw):
        text = raw.strip().lower()
        if text in TRUE_WORDS:
            return True
        if text in FALSE_WORDS or text == "":
            return False if isinstance(self.flag_value, bool) or text else None
        if not isinstance(self.flag_value, bool):
            return True if raw == str(self.flag_value) else None
        raise BadParameter(f"{raw!r} is not a valid boolean.", param=self)

    def process_value(self, ctx, value):
        if self.callback is None:
            return value
        try:
            return self.callback(ctx, self, value)
        except BadParameter as exc:
            if exc.param is None:
                exc.param = self
            if exc.ctx is None:
                exc.ctx = ctx
            raise

    def resolve(self, ctx, occs):
        """Return ``(value, source)`` for this parameter, following the value sources in order."""
        supplied = list(occs)
        bare_only = bool(supplied) and all(occ is BARE for occ in supplied)
        if supplied and not (bare_only and self.prompt):
            if self.deprecated:
                _warn_deprecated(ctx, self)
            return self.value_from_occurrences(ctx, supplied), ParameterSource.COMMANDLINE
        env = self.env_occurrences(ctx)
        if env is not None:
            return self.value_from_occurrences(ctx, env), ParameterSource.ENVIRONMENT
        map_value = ctx.lookup_default(self.name)
        default_obj = self.get_default(ctx)
        shown = map_value if map_value is not None else default_obj
        if getattr(self, "prompt", False) and (bare_only or (not supplied and (self.prompt_required or self.required))):
            return self._prompt(ctx, shown, map_value, default_obj)
        if map_value is not None:
            return self.value_from_default(ctx, map_value), ParameterSource.DEFAULT_MAP
        if default_obj is not None:
            return self.value_from_default(ctx, default_obj), ParameterSource.DEFAULT
        if self.required:
            raise MissingParameter(ctx=ctx, param=self)
        return self.empty_value(), ParameterSource.DEFAULT

    def _prompt(self, ctx, shown, map_value, default_obj):
        text = self.prompt_text or self.name.replace("_", " ").capitalize()
        if self.is_flag:
            if getattr(self, "confirm_text", None):
                termui.confirm(text, default=False, abort=True)
                return True, ParameterSource.PROMPT
            answer = termui.confirm(text, default=bool(shown) if shown is not None else False)
            return answer, ParameterSource.PROMPT
        used_default = []

        def proc(raw):
            if shown is not None and raw is shown:
                used_default.append(True)
                return self.value_from_default(ctx, raw)
            if self.multiple:
                return (self.convert_value(ctx, raw),)
            if self.nargs != 1:
                return self.convert_tokens(ctx, str(raw).split())
            return self.convert_value(ctx, raw)

        value = termui.prompt(text, default=shown, hide_input=self.hide_input,
                              confirmation_prompt=self.confirmation_prompt, value_proc=proc)
        if used_default:
            source = ParameterSource.DEFAULT_MAP if map_value is not None else ParameterSource.DEFAULT
        else:
            source = ParameterSource.PROMPT
        return value, source


def _warn_deprecated(ctx, param):
    kind = "argument" if param.is_argument else "option"
    note = param.deprecated if isinstance(param.deprecated, str) else ""
    message = f"DeprecationWarning: The {kind} {param.get_error_hint(ctx)} is deprecated."
    if note:
        message += f" {note}"
    termui.echo(message, err=True)


class Option(Parameter):
    """A named parameter introduced by a flag name such as ``--count``."""

    is_argument = False

    def __init__(self, param_decls=None, **attrs):
        decls = list(param_decls or [])
        opts, secondary, dest = [], [], None
        for decl in decls:
            if decl[:1] in _PREFIX_CHARS:
                if "/" in decl[1:]:
                    first, second = decl.split("/", 1)
                    opts.append(first)
                    secondary.append(second)
                else:
                    opts.append(decl)
            else:
                dest = decl
        if not opts and dest is None:
            raise TypeError("An option needs a flag name or a destination name.")
        self.opts = opts
        self.secondary_opts = secondary
        if dest is None:
            longs = [o for o in opts if o.startswith("--")]
            source = (longs or opts)[0]
            dest = source.lstrip("".join(_PREFIX_CHARS)).replace("-", "_")

        default = attrs.pop("default", None)
        type_ = attrs.pop("type", None)
        is_flag = attrs.pop("is_flag", None)
        count = attrs.pop("count", False)
        flag_value = attrs.pop("flag_value", None)
        prompt = attrs.pop("prompt", False)
        confirm_text = attrs.pop("_confirm_text", None)
        nargs = attrs.pop("nargs", None)
        if nargs is not None and (not isinstance(nargs, int) or nargs < 1):
            raise TypeError("Option nargs must be a positive integer.")
        if is_flag is None:
            is_flag = bool(secondary) or isinstance(default, bool) or type_ is BOOL
            if flag_value is not None and not isinstance(flag_value, bool):
                is_flag = False
        self.is_flag = bool(is_flag) and not count
        self.count = bool(count)
        if self.is_flag:
            self.flag_value = True if flag_value is None else flag_value
            self.optional_value = False
        elif self.count:
            self.flag_value = None
            self.optional_value = False
        else:
            self.flag_value = flag_value
            self.optional_value = flag_value is not None
        if self.is_flag and nargs not in (None, 1):
            raise TypeError("A flag takes no value.")
        if self.is_flag:
            effective_type = type_ if type_ is not None else BOOL
        elif self.count:
            effective_type = type_ if type_ is not None else INT
        else:
            effective_type = convert_type(type_, default if not callable(default) else None)

        self.prompt = bool(prompt)
        self.prompt_text = prompt if isinstance(prompt, str) and prompt else None
        self.prompt_required = bool(attrs.pop("prompt_required", True))
        self.hide_input = bool(attrs.pop("hide_input", False))
        self.confirmation_prompt = bool(attrs.pop("confirmation_prompt", False))
        self.confirm_text = confirm_text
        self.help = attrs.pop("help", None)
        self.hidden = bool(attrs.pop("hidden", False))
        self.show_default = attrs.pop("show_default", None)
        self.show_envvar = bool(attrs.pop("show_envvar", False))
        required = bool(attrs.pop("required", False))
        deprecated = attrs.pop("deprecated", False)
        if deprecated and required:
            raise TypeError("A deprecated option cannot also be required.")
        if deprecated and self.prompt:
            raise TypeError("A deprecated option cannot use a prompt.")
        envvar = _envvar_names(attrs.pop("envvar", None))
        self._init_common(
            name=dest,
            type_=effective_type,
            default=default,
            required=required,
            callback=attrs.pop("callback", None),
            nargs=1 if self.is_flag or self.count else (nargs if nargs is not None else None),
            multiple=bool(attrs.pop("multiple", False)),
            metavar=attrs.pop("metavar", None),
            expose_value=bool(attrs.pop("expose_value", True)),
            is_eager=bool(attrs.pop("is_eager", False)),
            envvar=envvar,
            shell_complete=attrs.pop("shell_complete", None),
            deprecated=deprecated,
            allow_from_autoenv=bool(attrs.pop("allow_from_autoenv", True)),
        )
        if self.nargs < 1 and not self.is_flag:
            raise TypeError("Option nargs must be a positive integer.")
        if attrs:
            raise TypeError(f"Unsupported option keyword(s): {', '.join(sorted(attrs))}")

    @property
    def takes_value(self):
        return not (self.is_flag or self.count)

    def opts_text(self):
        return "/".join(self.opts + self.secondary_opts)

    def get_error_hint(self, ctx):
        return f"'{self.opts_text()}'"

    def declared_names(self):
        if self.secondary_opts:
            return "/".join(self.opts + self.secondary_opts)
        return ", ".join(self.opts)

    def metavar_text(self):
        if not self.takes_value:
            return None
        if self.metavar:
            return self.metavar
        placeholder = self.type.get_metavar(self)
        return placeholder or self.type.name.upper()


class Argument(Parameter):
    """A positional parameter."""

    is_argument = True
    is_flag = False
    count = False
    multiple = False
    prompt = False
    prompt_required = False
    flag_value = None

    def __init__(self, param_decls=None, **attrs):
        decls = list(param_decls or [])
        if len(decls) != 1:
            raise TypeError("An argument takes exactly one destination name.")
        name = decls[0]
        default = attrs.pop("default", None)
        type_ = attrs.pop("type", None)
        nargs = attrs.pop("nargs", 1)
        if nargs != -1 and (not isinstance(nargs, int) or nargs < 1):
            raise TypeError("Argument nargs must be a positive integer or -1.")
        required = attrs.pop("required", None)
        if required is None:
            required = default is None and nargs != -1
        deprecated = attrs.pop("deprecated", False)
        if deprecated and required:
            raise TypeError("A deprecated argument cannot be required.")
        self.help = attrs.pop("help", None)
        self.hidden = bool(attrs.pop("hidden", False))
        envvar = _envvar_names(attrs.pop("envvar", None))
        self._init_common(
            name=name,
            type_=convert_type(type_, default if not callable(default) else None),
            default=default,
            required=bool(required),
            callback=attrs.pop("callback", None),
            nargs=nargs,
            multiple=False,
            metavar=attrs.pop("metavar", None),
            expose_value=bool(attrs.pop("expose_value", True)),
            is_eager=False,
            envvar=envvar,
            shell_complete=attrs.pop("shell_complete", None),
            deprecated=deprecated,
            allow_from_autoenv=False,
        )
        if attrs:
            raise TypeError(f"Unsupported argument keyword(s): {', '.join(sorted(attrs))}")

    @property
    def takes_value(self):
        return True

    def get_error_hint(self, ctx):
        return f"'{self.name}'"

    def placeholder(self):
        return self.metavar or self.name.upper()

    def usage_text(self):
        core = self.placeholder() + ("..." if self.is_variadic else "")
        return core if self.required else f"[{core}]"

    def metavar_text(self):
        return self.placeholder()


def _envvar_names(envvar):
    if not envvar:
        return None
    return [envvar] if isinstance(envvar, str) else list(envvar)


def _clean_help(text):
    if text is None:
        return None
    # A form feed ends the help text; the rest is not shown.
    return text.split("\f", 1)[0]


def _help_callback(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    termui.echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


def _make_help_option(names):
    return Option(names, is_flag=True, expose_value=False, is_eager=True,
                  help="Show this message and exit.", callback=_help_callback)


def bind_arguments(arguments, tokens):
    """Split positional tokens across arguments in declaration order.

    Returns ``(values, leftover)`` where ``values`` maps each argument to the
    tokens it received (possibly an empty list) and ``leftover`` is what remains.
    """
    values = {}
    index = 0
    total = len(tokens)
    for position, arg in enumerate(arguments):
        if arg.is_variadic:
            reserve = sum(later.nargs for later in arguments[position + 1:]
                          if later.required and not later.is_variadic)
            take = max(0, total - index - reserve)
            values[arg] = list(tokens[index:index + take])
            index += take
            continue
        available = total - index
        if available >= arg.nargs:
            values[arg] = list(tokens[index:index + arg.nargs])
            index += arg.nargs
        elif available == 0:
            values[arg] = []
        else:
            raise BadArgumentUsage(f"Argument '{arg.name}' takes {arg.nargs} values.")
    return values, list(tokens[index:])


class Context:
    """The state of one invocation. Built by the library, one per command run."""

    _INHERITED = ("terminal_width", "max_content_width", "help_option_names", "token_normalize_func",
                  "color", "show_default", "auto_envvar_prefix")

    def __init__(self, command, parent=None, info_name=None, obj=None, default_map=None,
                 terminal_width=None, max_content_width=None, help_option_names=None,
                 token_normalize_func=None, color=None, show_default=None, allow_extra_args=None,
                 ignore_unknown_options=None, allow_interspersed_args=None, auto_envvar_prefix=None,
                 resilient_parsing=False, **extra):
        self.command = command
        self.parent = parent
        self.info_name = info_name if info_name is not None else command.name
        self._obj = obj
        self.default_map = default_map
        values = {
            "terminal_width": terminal_width,
            "max_content_width": max_content_width,
            "help_option_names": help_option_names,
            "token_normalize_func": token_normalize_func,
            "color": color,
            "show_default": show_default,
            "auto_envvar_prefix": auto_envvar_prefix,
        }
        for key, value in values.items():
            if value is None and parent is not None and key in self._INHERITED:
                value = getattr(parent, key)
            setattr(self, key, value)
        if self.max_content_width is None:
            self.max_content_width = MAX_CONTENT_WIDTH
        if self.help_option_names is None:
            self.help_option_names = ["--help"]
        if self.show_default is None:
            self.show_default = False
        self.allow_extra_args = command.allow_extra_args if allow_extra_args is None else allow_extra_args
        self.ignore_unknown_options = (command.ignore_unknown_options if ignore_unknown_options is None
                                       else ignore_unknown_options)
        self.allow_interspersed_args = (command.allow_interspersed_args if allow_interspersed_args is None
                                        else allow_interspersed_args)
        self.resilient_parsing = resilient_parsing
        self.extra = extra
        self.params = {}
        self.args = []
        self.invoked_subcommand = None
        self.command_params = []
        self._sources = {}
        self._param_rank = {}
        self._close_callbacks = []
        self._depth = 0

    @property
    def obj(self):
        if self._obj is None and self.parent is not None:
            return self.parent.obj
        return self._obj

    @obj.setter
    def obj(self, value):
        self._obj = value

    @property
    def command_path(self):
        if self.parent is not None:
            return f"{self.parent.command_path} {self.info_name}"
        return self.info_name

    def path_names(self):
        names = []
        node = self
        while node is not None and node.parent is not None:
            names.append(node.info_name)
            node = node.parent
        return list(reversed(names))

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type):
        node = self
        while node is not None:
            if node.obj is not None and type(node.obj) is object_type:
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

    def lookup_default(self, name):
        dm = self.default_map
        if isinstance(dm, dict):
            return dm.get(name)
        return None

    def get_parameter_source(self, name):
        if not any(param.name == name for param in self.command_params):
            return None
        return self._sources.get(name, ParameterSource.DEFAULT)

    def _store(self, param, value, source):
        rank = _SOURCE_RANK[source]
        if source is ParameterSource.DEFAULT and getattr(param, "is_flag", False):
            rank += 0.5
        previous = self._param_rank.get(param.name)
        if previous is not None and previous < rank:
            return
        self._param_rank[param.name] = rank
        self._sources[param.name] = source
        if param.expose_value:
            self.params[param.name] = value

    def call_on_close(self, func):
        self._close_callbacks.append(func)

    def with_resource(self, context_manager):
        value = context_manager.__enter__()
        self.call_on_close(lambda: context_manager.__exit__(None, None, None))
        return value

    def close(self):
        callbacks, self._close_callbacks = self._close_callbacks, []
        for callback in reversed(callbacks):
            callback()

    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def get_help(self):
        return self.command.get_help(self)

    def get_usage(self):
        return self.command.get_usage(self)

    def invoke(self, callback, *args, **kwargs):
        """Run a command (filling its defaults) or a plain callback inside this context."""
        if isinstance(callback, Command):
            other = callback
            func = other.callback
            ctx = Context(other, info_name=other.name, parent=self)
            for param in other.params:
                if param.name not in kwargs and param.expose_value:
                    kwargs[param.name] = param.empty_value() if param.default is None else param.default
            callback = func
        else:
            ctx = self
        with ctx:
            return callback(*args, **kwargs)

    def forward(self, callback, **kwargs):
        values = dict(self.params)
        values.update(kwargs)
        return self.invoke(callback, **values)

    @contextmanager
    def scope(self, cleanup=True):
        """Make this context current; resources close on exit only when ``cleanup`` is true."""
        self._depth += 1
        push_context(self)
        try:
            yield self
        finally:
            pop_context()
            self._depth -= 1
            if self._depth == 0 and cleanup:
                self.close()

    def __enter__(self):
        self._depth += 1
        push_context(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        pop_context()
        self._depth -= 1
        if self._depth == 0:
            self.close()


class Command:
    """A leaf command: parses its own parameters and runs an author callback."""

    allow_extra_args = False
    allow_interspersed_args = True
    ignore_unknown_options = False

    def __init__(self, name, callback=None, params=None, context_settings=None, help=None, epilog=None,
                 short_help=None, options_metavar="[OPTIONS]", add_help_option=True, no_args_is_help=False,
                 hidden=False, deprecated=False, **kwargs):
        self.name = name
        self.callback = callback
        self.params = list(params or [])
        self.context_settings = dict(context_settings or {})
        self.help = _clean_help(help)
        self.epilog = _clean_help(epilog)
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = deprecated
        self.extra = kwargs
        if sum(1 for p in self.params if isinstance(p, Argument) and p.is_variadic) > 1:
            raise TypeError("A command may use a variadic argument at most once.")

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    def get_params(self, ctx):
        params = list(self.params)
        if self.add_help_option:
            declared = set()
            for param in params:
                if isinstance(param, Option):
                    declared.update(param.opts + param.secondary_opts)
            names = [name for name in ctx.help_option_names if name not in declared]
            if names:
                params.append(_make_help_option(names))
        return params

    def make_context(self, info_name, args, parent=None, **extra):
        settings = dict(self.context_settings)
        if parent is not None and isinstance(parent.default_map, dict) and info_name in parent.default_map \
                and "default_map" not in extra:
            settings["default_map"] = parent.default_map[info_name]
        settings.update(extra)
        ctx = Context(self, info_name=info_name, parent=parent, **settings)
        try:
            with ctx.scope(cleanup=False):
                self.parse_args(ctx, args)
        except BaseException:
            ctx.close()
            raise
        return ctx

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise UsageError(None, ctx, show_help=True)
        params = self.get_params(ctx)
        ctx.command_params = params
        options = [p for p in params if isinstance(p, Option)]
        arguments = [p for p in params if isinstance(p, Argument)]
        parser = OptionParser(options, allow_interspersed_args=ctx.allow_interspersed_args,
                              ignore_unknown_options=ctx.ignore_unknown_options,
                              normalize=ctx.token_normalize_func)
        events, positional = parser.parse(args)
        arg_values, leftover = bind_arguments(arguments, positional)
        if leftover and not ctx.allow_extra_args:
            raise UsageError("Got unexpected extra argument(s) ("
                             + ", ".join(repr(token) for token in leftover) + ")", ctx)
        ctx.args = leftover
        self._process_params(ctx, params, events, arg_values)

    def _process_params(self, ctx, params, events, arg_values):
        occurrences = {}
        for option, payload in events:
            occurrences.setdefault(option, []).append(payload)

        def occs_of(param):
            if param.is_argument:
                tokens = arg_values.get(param) or []
                return [tokens] if tokens else []
            return occurrences.get(param, [])

        eager_given = []
        for option, _ in events:
            if option.is_eager and option not in eager_given:
                eager_given.append(option)
        done = set()
        for param in eager_given:
            self._process_one(ctx, param, occs_of(param))
            done.add(param)
        for param in params:
            if param in done:
                continue
            self._process_one(ctx, param, occs_of(param))

    def _process_one(self, ctx, param, occs):
        value, source = param.resolve(ctx, occs)
        value = param.process_value(ctx, value)
        ctx._store(param, value, source)

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True, **extra):
        """Run this command as a program. Failures exit (standalone) or propagate."""
        if args is None:
            args = sys.argv[1:]
        args = list(args)
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else "root"
        from . import shell_completion

        variable = complete_var or "_" + re.sub(r"[-\s]", "_", prog_name).upper() + "_COMPLETE"
        instruction = os.environ.get(variable)
        if instruction:
            code = shell_completion.run(self, prog_name, instruction)
            if standalone_mode:
                sys.exit(code)
            return None
        try:
            ctx = self.make_context(prog_name, args, **extra)
            try:
                with ctx:
                    rv = self.invoke(ctx)
            finally:
                ctx.close()
            if not standalone_mode:
                return rv
            sys.exit(0)
        except Exit as exc:
            if standalone_mode:
                sys.exit(exc.exit_code)
            return None
        except Abort:
            if not standalone_mode:
                raise
            termui.echo("Aborted!", err=True)
            sys.exit(1)
        except UsageError as exc:
            if not standalone_mode:
                raise
            exc.show()
            sys.exit(exc.exit_code)
        except OptlynException as exc:
            if not standalone_mode:
                raise
            termui.echo(f"Error: {exc.format_message()}", err=True)
            sys.exit(exc.exit_code)
        except (EOFError, KeyboardInterrupt):
            if not standalone_mode:
                raise
            termui.echo("\nAborted!", err=True)
            sys.exit(1)

    def invoke(self, ctx):
        """Run the callback for an already-parsed context."""
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else ""
            message = f"DeprecationWarning: The command '{self.name}' is deprecated."
            termui.echo(f"{message} {note}".rstrip(), err=True)
        if self.callback is None:
            return None
        return ctx.invoke(self.callback, **ctx.params)

    def _help_width(self, ctx):
        if ctx.terminal_width is not None:
            return ctx.terminal_width
        detected = shutil.get_terminal_size((80, 24)).columns
        return max(min(detected, ctx.max_content_width), 10)

    def get_usage(self, ctx):
        pieces = [ctx.command_path]
        if self.options_metavar:
            pieces.append(self.options_metavar)
        for param in self.params:
            if isinstance(param, Argument):
                pieces.append(param.usage_text())
        if isinstance(self, Group):
            pieces.append(self._subcommand_usage())
        return "Usage: " + " ".join(piece for piece in pieces if piece)

    def get_help(self, ctx):
        width = self._help_width(ctx)
        params = ctx.command_params or self.get_params(ctx)
        lines = [self.get_usage(ctx), ""]
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else ""
            lines.extend(["(Deprecated) " + note if note else "(Deprecated)", ""])
        if self.help:
            lines.extend([wrap_text(self.help, width=width), ""])
        arg_rows = [(p.placeholder(), p.help) for p in params if isinstance(p, Argument) and p.help]
        if arg_rows:
            lines.append("Positional arguments:")
            lines.extend(format_definition_list(arg_rows, width))
            lines.append("")
        option_rows = []
        for param in params:
            if isinstance(param, Option) and not param.hidden:
                option_rows.append(self._option_row(ctx, param))
        if option_rows:
            lines.append("Options:")
            lines.extend(format_definition_list(option_rows, width))
            lines.append("")
        if isinstance(self, Group):
            command_rows = []
            for name in self.list_commands(ctx):
                cmd = self.get_command(ctx, name)
                if cmd is None or cmd.hidden:
                    continue
                command_rows.append((name, cmd.get_short_help_str()))
            if command_rows:
                lines.append("Commands:")
                lines.extend(format_definition_list(command_rows, width))
                lines.append("")
        if self.epilog:
            lines.extend([wrap_text(self.epilog, width=width), ""])
        return "\n".join(lines).rstrip("\n")

    def _option_row(self, ctx, param):
        names = param.declared_names()
        metavar = param.metavar_text()
        first = f"{names} {metavar}" if metavar else names
        parts = []
        if param.help:
            parts.append(param.help)
        show = param.show_default if param.show_default is not None else ctx.show_default
        if show:
            if isinstance(show, str):
                parts.append(f"[default: {show}]")
            else:
                default = param.default
                if default is not None and not callable(default) and not (param.is_flag and default is False):
                    display = ", ".join(str(v) for v in default) if _is_sequence(default) else str(default)
                    parts.append(f"[default: {display}]")
        if param.show_envvar and param.envvar:
            names_env = [param.envvar] if isinstance(param.envvar, str) else list(param.envvar)
            parts.append(f"[env var: {', '.join(names_env)}]")
        if param.deprecated:
            parts.append("(deprecated)")
        return (first, " ".join(parts))

    def get_short_help_str(self, limit=45):
        """The first sentence of the help text, cut with ``...`` at ``limit`` characters."""
        if self.short_help:
            text = self.short_help
        else:
            text = " ".join((self.help or "").split())
            match = re.match(r"(.+?[.!?])(?:\s|$)", text)
            if match:
                text = match.group(1)
        if len(text) > limit:
            text = text[: limit - 3].rstrip() + "..."
        return text


class Group(Command):
    """A command that dispatches to named subcommands."""

    allow_extra_args = True
    allow_interspersed_args = False

    def __init__(self, name=None, commands=None, invoke_without_command=False, no_args_is_help=None,
                 subcommand_metavar=None, chain=False, result_callback=None, **kwargs):
        super().__init__(name, **kwargs)
        self.invoke_without_command = invoke_without_command
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        self.no_args_is_help = no_args_is_help
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback
        self.commands = {}
        for name_, cmd in (commands or {}).items():
            self.add_command(cmd, name_)

    def add_command(self, cmd, name=None):
        name = name or cmd.name
        if self.chain and isinstance(cmd, Group):
            raise RuntimeError("Groups cannot be attached beneath a chaining group.")
        self.commands[name] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as command_decorator

        def decorator(func):
            cmd = command_decorator(*args, **kwargs)(func)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as group_decorator

        def decorator(func):
            cmd = group_decorator(*args, **kwargs)(func)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self):
        def decorator(func):
            self._result_callback = func
            return func

        return decorator

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        return self.commands.get(cmd_name)

    def _subcommand_usage(self):
        if self.subcommand_metavar:
            base = self.subcommand_metavar
        else:
            base = "COMMAND"
        if self.chain:
            return f"{base} [ARGS]... [{base} [ARGS]...]..."
        if self.invoke_without_command:
            return f"[{base}] [ARGS]..."
        return f"{base} [ARGS]..."

    def resolve_command(self, ctx, args):
        name = args[0]
        cmd = self.get_command(ctx, name)
        normalize = ctx.token_normalize_func
        if cmd is None and normalize is not None:
            for listed in self.list_commands(ctx):
                if normalize(listed) == normalize(name):
                    cmd = self.get_command(ctx, listed)
                    break
        if cmd is None:
            raise UsageError(f"No such command '{name}'.", ctx)
        return name, cmd, list(args[1:])

    def _run_result(self, ctx, value, default):
        if self._result_callback is None:
            return default
        return self._result_callback(value, **ctx.params)

    def invoke(self, ctx):
        args = ctx.args
        if not args:
            if not self.invoke_without_command:
                raise UsageError("Missing command.", ctx)
            with ctx:
                rv = Command.invoke(self, ctx)
                if self.chain:
                    self._run_result(ctx, [], [])
                    return []
                return self._run_result(ctx, rv, rv)
        if self.chain:
            return self._invoke_chain(ctx, args)
        name, cmd, rest = self.resolve_command(ctx, args)
        with ctx:
            ctx.invoked_subcommand = name
            Command.invoke(self, ctx)
        sub_ctx = cmd.make_context(name, rest, parent=ctx)
        with sub_ctx:
            rv = cmd.invoke(sub_ctx)
        with ctx:
            return self._run_result(ctx, rv, rv)

    def _invoke_chain(self, ctx, args):
        contexts = []
        remaining = list(args)
        while remaining:
            name, cmd, after = self.resolve_command(ctx, remaining)
            sub_ctx = cmd.make_context(name, after, parent=ctx, allow_extra_args=True,
                                       allow_interspersed_args=False)
            contexts.append(sub_ctx)
            remaining = sub_ctx.args
        with ctx:
            ctx.invoked_subcommand = _CHAINED
            Command.invoke(self, ctx)
        values = []
        for sub_ctx in contexts:
            with sub_ctx:
                values.append(sub_ctx.command.invoke(sub_ctx))
        if self._result_callback is not None:
            with ctx:
                self._result_callback(values, **ctx.params)
        return values


class _Chained:
    def __repr__(self):
        return "<chained subcommands>"


# A value of ``invoked_subcommand`` that is neither None nor a child name.
_CHAINED = _Chained()


class CommandCollection(Group):
    """A group whose subcommands are the union of several source groups."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = set()
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None
