"""Tokenizer and option matcher for Optlyn command lines (POSIX-style)."""

from __future__ import annotations

from collections import deque

from .exceptions import BadOptionUsage, NoSuchOption

BASE_PREFIX_CHARS = "-"


class Bare:
    """Marks an option given with its flag but no value (optional-value options)."""

    def __repr__(self):
        return "BARE"


class Count:
    """Marks one occurrence of a counting option."""

    def __repr__(self):
        return "COUNT"


BARE = Bare()
COUNT = Count()


class OptionParser:
    """Matches option tokens against declared flag names.

    ``parse`` returns ``(events, positional)``: ``events`` is a list of
    ``(option, payload)`` in command-line order and ``positional`` the tokens
    that are not options. Payloads: ``bool`` for flags (True for the on-flag),
    ``COUNT`` for counting options, ``BARE`` for an optional-value option given
    without a value, or a list of tokens for value options.
    """

    def __init__(self, options, allow_interspersed_args=True, ignore_unknown_options=False,
                 normalize=None):
        self.allow_interspersed_args = allow_interspersed_args
        self.ignore_unknown_options = ignore_unknown_options
        self.normalize = normalize or (lambda token: token)
        self.lookup = {}
        self.prefixes = {BASE_PREFIX_CHARS}
        for option in options:
            for name in option.opts:
                self._register(name, option, False)
            for name in option.secondary_opts:
                self._register(name, option, True)

    def _register(self, name, option, secondary):
        self.prefixes.add(name[0])
        self.lookup[self.normalize(name)] = (option, secondary)

    def _is_option(self, token):
        return len(token) > 1 and token[0] in self.prefixes

    def parse(self, args):
        self.events = []
        positional = []
        rargs = deque(args)
        while rargs:
            token = rargs.popleft()
            if token == "--":
                positional.extend(rargs)
                rargs.clear()
                break
            if self._is_option(token):
                self._process_token(token, rargs, positional)
                continue
            positional.append(token)
            if not self.allow_interspersed_args:
                positional.extend(rargs)
                rargs.clear()
                break
        return self.events, positional

    def _process_token(self, token, rargs, positional):
        name, has_eq, inline = token.partition("=")
        key = self.normalize(name)
        if key in self.lookup:
            option, secondary = self.lookup[key]
            self._match(option, secondary, inline if has_eq else None, rargs, token)
            return
        if token[1] == token[0]:
            # An unknown long option (for example ``--nope``).
            if self.ignore_unknown_options:
                positional.append(token)
                return
            raise NoSuchOption(name)
        self._process_stack(token, rargs, positional)

    def _process_stack(self, token, rargs, positional):
        prefix = token[0]
        chars = token[1:]
        for index, char in enumerate(chars):
            key = self.normalize(prefix + char)
            if key not in self.lookup:
                if self.ignore_unknown_options:
                    positional.append(prefix + chars[index:])
                    return
                raise NoSuchOption(prefix + char)
            option, secondary = self.lookup[key]
            if not option.takes_value:
                self._match(option, secondary, None, rargs, token)
                continue
            rest = chars[index + 1:]
            self._match(option, secondary, rest if rest else None, rargs, token)
            return

    def _match(self, option, secondary, inline, rargs, token):
        if not option.takes_value:
            if inline is not None:
                raise BadOptionUsage(f"Option '{option.opts_text()}' does not take a value.")
            if option.count:
                self.events.append((option, COUNT))
            else:
                self.events.append((option, not secondary))
            return
        if option.optional_value:
            if inline is not None:
                self.events.append((option, [inline]))
            elif rargs and not self._is_option(rargs[0]):
                self.events.append((option, [rargs.popleft()]))
            else:
                self.events.append((option, BARE))
            return
        tokens = [] if inline is None else [inline]
        while len(tokens) < option.nargs:
            if not rargs:
                raise BadOptionUsage(f"Option '{option.opts_text()}' requires an argument.")
            tokens.append(rargs.popleft())
        self.events.append((option, tokens))
