"""Thread-local stack of the invocation contexts that are currently entered."""

import threading

_local = threading.local()


def _stack():
    try:
        return _local.stack
    except AttributeError:
        _local.stack = []
        return _local.stack


def push_context(ctx):
    _stack().append(ctx)


def pop_context():
    _stack().pop()


def get_current_context(silent=False):
    """Return the context current on this thread.

    Raises ``RuntimeError`` when there is none, unless ``silent`` is true, in
    which case ``None`` is returned.
    """
    stack = _stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")
