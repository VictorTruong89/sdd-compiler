"""In-process runner for invoking a command with argument tokens and capturing output."""

from __future__ import annotations

import io
import os
import sys
import tempfile
from contextlib import contextmanager



class _Buffer:
    """Stands in for the ``buffer`` attribute of a captured text stream."""

    def __init__(self, owner):
        self._owner = owner

    def write(self, data):
        self._owner._write_bytes(bytes(data))
        return len(data)

    def flush(self):
        pass


class _Capture:
    """A writable text stream that records bytes into its own buffer and a combined log."""

    def __init__(self, charset, combined):
        self.encoding = charset
        self.errors = "strict"
        self._charset = charset
        self._own = io.BytesIO()
        self._combined = combined
        self.buffer = _Buffer(self)

    def _write_bytes(self, data):
        self._own.write(data)
        self._combined.write(data)

    def write(self, text):
        if isinstance(text, bytes):
            self._write_bytes(text)
            return len(text)
        self._write_bytes(str(text).encode(self._charset, "backslashreplace"))
        return len(text)

    def flush(self):
        pass

    def isatty(self):
        return False

    def writable(self):
        return True

    def getvalue(self):
        return self._own.getvalue()


class Result:
    """What an invocation produced: exit status, captured output, and any exception."""

    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value, exit_code,
                 exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info
        self._output_bytes = output_bytes
        self._charset = runner.charset

    @property
    def output(self):
        return self._output_bytes.decode(self._charset, "replace")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self._charset, "replace")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self._charset, "replace")

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    """Invokes commands in-process, capturing standard streams and the exit status."""

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        """Run ``cli`` with the token list ``args`` and return a ``Result``."""
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        prog_name = extra.pop("prog_name", None) or getattr(cli, "name", None) or "root"
        standalone_mode = extra.pop("standalone_mode", True)
        extra.setdefault("color", color)
        if isinstance(input, str):
            input_bytes = input.encode(self.charset)
        else:
            input_bytes = input or b""

        combined = io.BytesIO()
        stdout_capture = _Capture(self.charset, combined)
        stderr_capture = _Capture(self.charset, combined)
        stdin_stream = io.TextIOWrapper(io.BytesIO(input_bytes), encoding=self.charset)

        merged_env = dict(self.env)
        merged_env.update(env or {})
        saved_env = {key: os.environ.get(key) for key in merged_env}
        for key, value in merged_env.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)

        saved_streams = (sys.stdin, sys.stdout, sys.stderr)
        exception = None
        exc_info = None
        exit_code = 0
        return_value = None
        try:
            sys.stdin = stdin_stream
            sys.stdout = stdout_capture
            sys.stderr = stderr_capture
            try:
                return_value = cli.main(args=list(args or []), prog_name=prog_name,
                                        standalone_mode=standalone_mode, **extra)
            except SystemExit as exc:
                code = exc.code
                if code is None:
                    exit_code = 0
                elif isinstance(code, int):
                    exit_code = code
                else:
                    sys.stderr.write(str(code) + "\n")
                    exit_code = 1
            except Exception as exc:
                if not catch_exceptions:
                    raise
                exception = exc
                exc_info = sys.exc_info()
                exit_code = 1
        finally:
            sys.stdin, sys.stdout, sys.stderr = saved_streams
            for key, previous in saved_env.items():
                if previous is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = previous
        return Result(self, stdout_capture.getvalue(), stderr_capture.getvalue(), combined.getvalue(),
                      return_value, exit_code, exception, exc_info)

    @contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Change into a new empty directory for the block and yield its path.

        The directory is left in place after the block so its files can be inspected.
        """
        cwd = os.getcwd()
        path = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
