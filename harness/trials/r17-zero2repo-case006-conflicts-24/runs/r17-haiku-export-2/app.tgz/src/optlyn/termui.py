"""Terminal helpers: output, styling, prompts, pagers, progress bars, and launchers."""

from __future__ import annotations

import getpass
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import time
from contextlib import contextmanager

from ._globals import get_current_context
from .exceptions import Abort, BadParameter


_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")

_NAMED_FG = {
    "black": 30, "red": 31, "green": 32, "yellow": 33, "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93, "bright_blue": 94,
    "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97, "reset": 39,
}
_SWITCHES = [("bold", 1, 22), ("dim", 2, 22), ("italic", 3, 23), ("underline", 4, 24), ("blink", 5, 25),
             ("reverse", 7, 27), ("strikethrough", 9, 29), ("overline", 53, 55)]


def _is_tty(stream):
    try:
        return bool(stream.isatty())
    except (AttributeError, ValueError):
        return False


def is_interactive():
    """A session is interactive when stdin or stdout is a terminal."""
    return _is_tty(sys.stdin) or _is_tty(sys.stdout)


def _context_color():
    ctx = get_current_context(silent=True)
    return None if ctx is None else ctx.color


def _write_text(stream, text):
    try:
        stream.write(text)
    except UnicodeEncodeError:
        buffer = getattr(stream, "buffer", None)
        if buffer is None:
            raise
        stream.flush()
        buffer.write(text.encode("utf-8"))
        buffer.flush()
        return
    try:
        stream.flush()
    except (AttributeError, ValueError):
        pass


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write text or bytes to standard output (or error), optionally keeping styles."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        data = message + (b"\n" if nl else b"")
        buffer = getattr(file, "buffer", None)
        if buffer is not None:
            file.flush()
            buffer.write(data)
            buffer.flush()
        else:
            file.write(data.decode("utf-8", "replace"))
        return
    text = str(message) + ("\n" if nl else "")
    if color is None:
        color = _context_color()
    if color is None:
        color = _is_tty(file)
    if not color:
        text = unstyle(text)
    _write_text(file, text)


def _color_codes(color, background):
    if isinstance(color, bool):
        raise TypeError("Invalid color value.")
    if isinstance(color, str):
        key = color.lower()
        if key not in _NAMED_FG:
            raise ValueError(f"Unknown color {color!r}.")
        code = _NAMED_FG[key]
        if background:
            if key == "reset":
                return ["49"]
            code += 10
        return [str(code)]
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise ValueError("Color numbers must be between 0 and 255.")
        return [("48" if background else "38"), "5", str(color)]
    try:
        parts = list(color)
    except TypeError:
        raise TypeError(f"Invalid color value {color!r}.") from None
    if len(parts) != 3 or not all(isinstance(p, int) and not isinstance(p, bool) and 0 <= p <= 255 for p in parts):
        raise ValueError("RGB colors must be three integers between 0 and 255.")
    return [("48" if background else "38"), "2"] + [str(p) for p in parts]


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None, italic=None,
          blink=None, reverse=None, strikethrough=None, reset=True):
    """Wrap ``text`` in ANSI SGR sequences. Invalid colors raise."""
    bits = []
    if fg is not None:
        bits += _color_codes(fg, background=False)
    if bg is not None:
        bits += _color_codes(bg, background=True)
    flags = {"bold": bold, "dim": dim, "italic": italic, "underline": underline, "blink": blink,
             "reverse": reverse, "strikethrough": strikethrough, "overline": overline}
    for name, on_code, off_code in _SWITCHES:
        value = flags[name]
        if value is None:
            continue
        bits.append(str(on_code if value else off_code))
    if not bits:
        return str(text)
    prefix = "\x1b[" + ";".join(bits) + "m"
    suffix = "\x1b[0m" if reset else ""
    return prefix + str(text) + suffix


def unstyle(text):
    """Remove ANSI escape sequences, leaving all other text."""
    return _ANSI_RE.sub("", str(text))


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    """``echo`` of ``style(message, **styles)`` in one step."""
    if message is not None:
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


def clear():
    """Clear the visible terminal; does nothing when standard output is not a terminal."""
    if _is_tty(sys.stdout):
        sys.stdout.write("\x1b[2J\x1b[H")
        sys.stdout.flush()


def _pager_command():
    return os.environ.get("PAGER")


def echo_via_pager(text_or_generator, color=None):
    """Write text through the pager when interactive; otherwise to standard output."""
    value = text_or_generator() if callable(text_or_generator) else text_or_generator
    if isinstance(value, str):
        chunks = [value]
    else:
        chunks = value
    with get_pager_file(color=color) as pager:
        for chunk in chunks:
            pager.write(str(chunk))
            pager.flush()


@contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream that feeds the pager (or standard output)."""
    command = _pager_command()
    if not (is_interactive() and command):
        stream = sys.stdout
        if color is False:
            yield _Unstyled(stream)
        else:
            yield stream
        return
    proc = subprocess.Popen(shlex.split(command), stdin=subprocess.PIPE, text=True)
    try:
        yield proc.stdin
    finally:
        try:
            proc.stdin.close()
        except (BrokenPipeError, OSError):
            pass
        proc.wait()


class _Unstyled:
    def __init__(self, stream):
        self._stream = stream

    def write(self, text):
        self._stream.write(unstyle(text))

    def flush(self):
        self._stream.flush()


class ProgressBar:
    """Iterable progress indicator returned by ``progressbar``."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, **options):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.pos = 0
        self._start = time.time()
        self._tty = _is_tty(sys.stdout) and not hidden
        self._drawn = False
        self._options = options
        if not hidden and not self._tty and self.label:
            sys.stdout.write(self.label + "\n")

    def __iter__(self):
        if self.iterable is None:
            return
        for item in self.iterable:
            yield item
            self.update(1)

    def update(self, n_steps, current_item=None):
        self.pos += n_steps
        if self._tty:
            self._draw()

    def _draw(self):
        if self.length:
            fraction = min(self.pos / self.length, 1.0)
            filled = int(fraction * 30)
            bar = "#" * filled + "-" * (30 - filled)
            elapsed = time.time() - self._start
            remaining = (elapsed / self.pos * (self.length - self.pos)) if self.pos else 0
            text = f"{self.label} [{bar}] {self.pos}/{self.length} eta {int(remaining)}s"
        else:
            text = f"{self.label} {self.pos}"
        sys.stdout.write("\r" + text)
        sys.stdout.flush()
        self._drawn = True

    def finish(self):
        if self._tty and self._drawn:
            sys.stdout.write("\n")
            sys.stdout.flush()


@contextmanager
def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    """Context manager yielding a progress bar."""
    bar = ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)
    try:
        yield bar
    finally:
        bar.finish()


def _read_line(hide_input=False, stream=None):
    stream = stream or sys.stdin
    if hide_input and _is_tty(stream):
        # Hidden input on a real terminal: getpass turns echo off while the line is read.
        try:
            return getpass.getpass("")
        except (EOFError, KeyboardInterrupt):
            raise Abort() from None
    line = stream.readline()
    if line == "":
        raise Abort()
    line = line.rstrip("\r\n")
    if not hide_input and not _is_tty(stream):
        echo(line, nl=True)
    return line


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False):
    """Ask for a value. Re-asks on conversion failure and on a mismatched confirmation."""
    if value_proc is None and type is not None:
        from .paramtypes import convert_type

        declared = convert_type(type)
        value_proc = lambda raw: declared.convert(raw)  # noqa: E731
    while True:
        shown = ""
        if default is not None and show_default:
            shown = f" [{default}]"
        echo(f"{text}{shown}{prompt_suffix}", nl=False, err=err)
        value = _read_line(hide_input)
        if value == "" and default is not None:
            value = default
        if confirmation_prompt:
            echo("Repeat for confirmation" + prompt_suffix, nl=False, err=err)
            again = _read_line(hide_input)
            if again != value and str(again) != str(value):
                echo("Error: the two entered values do not match", err=True)
                continue
        if value_proc is None:
            return value
        try:
            return value_proc(value)
        except BadParameter as exc:
            echo(f"Error: {exc.message}", err=True)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    """Ask a yes/no question. ``y``/``yes`` and ``n``/``no`` in any case; empty takes the default."""
    suffix = " [Y/n]" if default else " [y/N]"
    if not show_default:
        suffix = ""
    while True:
        echo(f"{text}{suffix}{prompt_suffix}", nl=False, err=err)
        answer = _read_line().strip().lower()
        if answer == "":
            value = bool(default)
        elif answer in ("y", "yes"):
            value = True
        elif answer in ("n", "no"):
            value = False
        else:
            continue
        if not value and abort:
            raise Abort()
        return value


def getchar(echo=False):
    """Read one character; the interrupt key raises KeyboardInterrupt, end-of-file raises EOFError."""
    stream = sys.stdin
    char = stream.read(1)
    if char == "":
        raise EOFError()
    if char == "\x03":
        raise KeyboardInterrupt()
    if char == "\x04":
        raise EOFError()
    if echo:
        _write_text(sys.stdout, char)
    return char


def pause(info=None, err=False):
    """Print a message and wait for a key when interactive; otherwise return immediately."""
    message = info if info is not None else "Press any key to continue..."
    echo(message, err=err, nl=False if info is None else True)
    if is_interactive():
        try:
            getchar()
        except EOFError:
            pass
        echo("", err=err)


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Open an editor on text (returns the saved text) or on a file (returns None)."""
    command = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR") or (
        "notepad" if sys.platform.startswith("win") else "vi")
    run_env = dict(os.environ)
    if env:
        run_env.update(env)
    if filename is not None:
        subprocess.call(shlex.split(command) + [str(filename)], env=run_env)
        return None
    original = text or ""
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(original)
        subprocess.call(shlex.split(command) + [path], env=run_env)
        with open(path, encoding="utf-8", newline="") as handle:
            result = handle.read()
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
    if require_save and result == original:
        return None
    return result


def launch(url, wait=False, locate=False):
    """Open ``url`` or a path with the default associated application."""
    if sys.platform.startswith("win"):
        os.startfile(url)  # noqa: S606 (Windows only)
        return 0
    opener = "open" if sys.platform == "darwin" else "xdg-open"
    if shutil.which(opener) is None:
        return 127
    process = subprocess.Popen([opener, url])
    if wait:
        return process.wait()
    return 0


