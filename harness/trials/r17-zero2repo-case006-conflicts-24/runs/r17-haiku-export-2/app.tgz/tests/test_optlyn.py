"""Behavioural tests for Optlyn, one group per feature point of the specification."""

import os
import sys

import pytest

from optlyn import (BOOL, Choice, DateTime, FloatRange, File, INT, IntRange, Path, STRING, Tuple,
                    UUID, argument, command, confirm, confirmation_option, custom_version_option, echo,
                    format_filename, get_app_dir, get_current_context, group, make_pass_decorator,
                    option, pass_context, pass_obj, password_option, prompt, secho, style, unstyle,
                    version_option)
from optlyn.testing import CliRunner
from optlyn.formatting import wrap_text


@pytest.fixture
def runner():
    return CliRunner()


# FP-01: declaration, naming and invocation -------------------------------------------------

def test_command_name_derivation(runner):
    @command()
    def sync_cmd():
        echo("synced")

    @command()
    def run_grp_thing():
        pass

    assert sync_cmd.name == "sync"
    assert run_grp_thing.name == "run-grp-thing"


def test_explicit_name_only_accepted(runner):
    @group()
    def root():
        pass

    @root.command("go")
    def start():
        echo("go")

    assert runner.invoke(root, ["go"]).stdout == "go\n"
    assert runner.invoke(root, ["start"]).exit_code == 2


def test_decorator_without_parens_and_declarations_move(runner):
    @command
    @option("--n", type=int, default=3)
    def bare(n):
        echo(str(n))

    assert bare.name == "bare"
    assert [p.name for p in bare.params] == ["n"]
    assert runner.invoke(bare, []).output == "3\n"


def test_redecorating_function_starts_empty():
    def f():
        pass

    f = option("--a")(f)
    cmd = command("x")(f)
    assert [p.name for p in cmd.params] == ["a"]
    assert "__optlyn_params__" not in f.__dict__


def test_unknown_option_is_usage_error_and_callback_not_run(runner):
    calls = []

    @command()
    def cmd():
        calls.append(1)

    res = runner.invoke(cmd, ["--nope"])
    assert res.exit_code == 2
    assert "No such option" in res.output
    assert calls == []


def test_deprecated_command_still_runs_with_warning(runner):
    @command(deprecated="use other")
    def old():
        echo("ran")

    res = runner.invoke(old, [])
    assert res.exit_code == 0
    assert "ran" in res.stdout
    assert "deprecated" in res.stderr and "use other" in res.stderr


def test_standalone_off_propagates_and_returns(runner):
    @command()
    def cmd():
        return 42

    assert cmd.main([], prog_name="x", standalone_mode=False) == 42
    with pytest.raises(Exception):
        cmd.main(["--bad"], prog_name="x", standalone_mode=False)


# FP-02: help ---------------------------------------------------------------------------------

def test_help_page_contents(runner):
    @command()
    @option("--count", type=int, default=1, help="How many.")
    @argument("name", help="Who to greet.")
    def hello(count, name):
        """Greet someone.

        Second paragraph.
        """
        echo("hi")

    res = runner.invoke(hello, ["--help"], prog_name="hello")
    assert res.exit_code == 0
    assert res.stdout.startswith("Usage: hello [OPTIONS] [NAME]") or "Usage: hello" in res.stdout
    assert "Greet someone." in res.stdout
    assert "Positional arguments:" in res.stdout
    assert "Options:" in res.stdout
    assert "--count" in res.stdout and "How many." in res.stdout
    assert "--help" in res.stdout
    assert "\nhi\n" not in res.stdout


def test_form_feed_truncates_help(runner):
    @command()
    def cmd():
        """Visible text.\fHidden text."""

    res = runner.invoke(cmd, ["--help"])
    assert "Visible text." in res.stdout
    assert "Hidden text" not in res.stdout
    assert "\f" not in res.stdout


def test_group_no_args_is_help_usage_failure(runner):
    @group()
    def grp():
        echo("should not run")

    res = runner.invoke(grp, [])
    assert res.exit_code == 2
    assert "Usage:" in res.stderr
    assert "should not run" not in res.output


def test_help_before_subcommand_is_for_parent(runner):
    ran = []

    @group()
    def grp():
        ran.append("group")

    @grp.command()
    def sub():
        ran.append("sub")

    res = runner.invoke(grp, ["--help", "sub"])
    assert res.exit_code == 0
    assert ran == []
    assert "Commands:" in res.stdout


def test_help_after_subcommand_is_for_child(runner):
    @group()
    def grp():
        pass

    @grp.command()
    def sub():
        """Child help."""

    res = runner.invoke(grp, ["sub", "--help"])
    assert res.exit_code == 0
    assert "Child help." in res.stdout


def test_short_help_truncation_at_45(runner):
    @group()
    def grp():
        pass

    @grp.command()
    def long_one():
        """This first sentence is definitely longer than forty five characters. Second."""

    res = runner.invoke(grp, ["--help"])
    assert "This first sentence is definitely longer t..." in res.stdout


def test_epilog_and_no_help_option(runner):
    @command(add_help_option=False, epilog="Bye now.")
    def cmd():
        pass

    res = runner.invoke(cmd, ["--help"])
    assert res.exit_code == 2
    assert "Bye now." not in res.output


def test_hidden_options_and_commands_are_omitted_but_work(runner):
    @group()
    def grp():
        pass

    @grp.command(hidden=True)
    def secret():
        echo("secret ran")

    @command()
    @option("--quiet", hidden=True, is_flag=True)
    def cmd(quiet):
        echo(f"quiet={quiet}")

    assert "secret" not in runner.invoke(grp, ["--help"]).stdout
    assert runner.invoke(grp, ["secret"]).stdout == "secret ran\n"
    assert "--quiet" not in runner.invoke(cmd, ["--help"]).stdout
    assert runner.invoke(cmd, ["--quiet"]).stdout == "quiet=True\n"


def test_show_default_hides_false_flag(runner):
    @command()
    @option("--loud/--quiet", default=False, show_default=True)
    @option("--count", default=2, show_default=True)
    def cmd(loud, count):
        pass

    out = runner.invoke(cmd, ["--help"]).stdout
    assert "[default: 2]" in out
    assert "[default: False]" not in out


def test_metavar_for_integer_option(runner):
    @command()
    @option("--count", type=int)
    def cmd(count):
        pass

    assert "--count INTEGER" in runner.invoke(cmd, ["--help"]).stdout


# FP-02 eager flags: version ----------------------------------------------------------------

def test_custom_version_option_exact_output(runner):
    @command()
    @custom_version_option(lambda ctx: "my-version 9.9")
    def cmd():
        echo("body")

    res = runner.invoke(cmd, ["--version"])
    assert res.exit_code == 0
    assert res.stdout == "my-version 9.9\n"


def test_version_option_with_version_string(runner):
    @command()
    @version_option("1.2.3", prog_name="tool")
    def cmd():
        echo("body")

    res = runner.invoke(cmd, ["--version"])
    assert res.exit_code == 0
    assert "1.2.3" in res.stdout
    assert "body" not in res.stdout


def test_first_eager_flag_wins(runner):
    @command()
    @custom_version_option(lambda ctx: "VERSION")
    def cmd():
        pass

    res = runner.invoke(cmd, ["--help", "--version"])
    assert "Usage:" in res.stdout and "VERSION" not in res.stdout
    res = runner.invoke(cmd, ["--version", "--help"])
    assert "VERSION" in res.stdout and "Usage:" not in res.stdout


def test_custom_help_names_via_context(runner):
    @command()
    def cmd():
        pass

    res = runner.invoke(cmd, ["-h"], help_option_names=["-h"])
    assert res.exit_code == 0 and "Usage:" in res.stdout
    res = runner.invoke(cmd, ["--help"], help_option_names=["-h"])
    assert res.exit_code == 2


def test_parameter_named_help_does_not_disable_auto_help(runner):
    @command()
    @argument("help", required=False)
    def cmd(help):
        echo(f"arg={help}")

    assert "Usage:" in runner.invoke(cmd, ["--help"]).stdout
    assert runner.invoke(cmd, ["x"]).stdout == "arg=x\n"


def test_author_option_reusing_help_drops_auto_help(runner):
    @command()
    @option("--help", "-h", is_flag=True)
    def cmd(help):
        echo(f"own={help}")

    assert runner.invoke(cmd, ["--help"]).stdout == "own=True\n"


# FP-03: options ------------------------------------------------------------------------------

def test_option_forms(runner):
    @command()
    @option("-v", "--verbose", is_flag=True)
    @option("-n", "--num", type=int, default=5)
    @option("--name")
    def cmd(verbose, num, name):
        echo(f"{verbose} {num} {name}")

    assert runner.invoke(cmd, ["-vn3", "--name=bob"]).stdout == "True 3 bob\n"
    assert runner.invoke(cmd, ["--num", "7", "--name", "al"]).stdout == "False 7 al\n"


def test_double_dash_ends_options(runner):
    @command()
    @option("--flag", is_flag=True)
    @argument("rest", nargs=-1)
    def cmd(flag, rest):
        echo(f"{flag} {rest}")

    assert runner.invoke(cmd, ["--", "--flag", "x"]).stdout == "False ('--flag', 'x')\n"


def test_on_off_pair_and_count(runner):
    @command()
    @option("--shout/--no-shout", default=False)
    @option("-v", count=True)
    def cmd(shout, v):
        echo(f"{shout} {v}")

    assert runner.invoke(cmd, ["--shout", "-vvv"]).stdout == "True 3\n"
    assert runner.invoke(cmd, ["--no-shout"]).stdout == "False 0\n"


def test_flag_default_true_absent_and_auto_default(runner):
    @command()
    @option("--on", is_flag=True, default=True)
    @option("--off", is_flag=True)
    def cmd(on, off):
        echo(f"{on} {off}")

    assert runner.invoke(cmd, []).stdout == "True False\n"


def test_repeatable_omitted_is_empty_tuple(runner):
    @command()
    @option("--item", multiple=True)
    def cmd(item):
        echo(repr(item))

    assert runner.invoke(cmd, []).stdout == "()\n"
    assert runner.invoke(cmd, ["--item", "a", "--item", "b"]).stdout == "('a', 'b')\n"


def test_repeatable_bare_string_default_is_usage_error(runner):
    @command()
    @option("--item", multiple=True, default="abc")
    def cmd(item):
        pass

    res = runner.invoke(cmd, [])
    assert res.exit_code == 2
    assert "iterable" in res.stderr


def test_multi_value_option_arity(runner):
    @command()
    @option("--pt", nargs=2, type=int)
    def cmd(pt):
        echo(repr(pt))

    assert runner.invoke(cmd, ["--pt", "1", "2"]).stdout == "(1, 2)\n"
    assert runner.invoke(cmd, ["--pt", "1"]).exit_code == 2


def test_tuple_type_option(runner):
    @command()
    @option("--pair", type=Tuple([STRING, INT]))
    def cmd(pair):
        echo(repr(pair))

    assert runner.invoke(cmd, ["--pair", "x", "3"]).stdout == "('x', 3)\n"


def test_optional_value_option(runner):
    @command()
    @option("--opt", is_flag=False, flag_value="BARE", default="DEF")
    def cmd(opt):
        echo(opt)

    assert runner.invoke(cmd, ["--opt", "tok"]).stdout == "tok\n"
    assert runner.invoke(cmd, ["--opt"]).stdout == "BARE\n"
    assert runner.invoke(cmd, []).stdout == "DEF\n"


def test_required_option_missing(runner):
    @command()
    @option("--must", required=True)
    def cmd(must):
        echo("ran")

    res = runner.invoke(cmd, [])
    assert res.exit_code == 2
    assert "--must" in res.stderr
    assert "ran" not in res.output


def test_prefix_slash_and_plus(runner):
    @command()
    @option("/x", is_flag=True)
    @option("+y", is_flag=True)
    def cmd(x, y):
        echo(f"{x} {y}")

    assert runner.invoke(cmd, ["/x", "+y"]).stdout == "True True\n"


def test_destination_inference():
    from optlyn.core import Option

    assert Option(["-v", "--verbose"]).name == "verbose"
    assert Option(["--dry-run"]).name == "dry_run"
    assert Option(["-x"]).name == "x"
    assert Option(["--a", "dest_name"]).name == "dest_name"


def test_deprecated_option_warns_only_when_supplied(runner):
    @command()
    @option("--old", deprecated=True, default="d")
    def cmd(old):
        echo(old)

    res = runner.invoke(cmd, [])
    assert "deprecated" not in res.stderr
    res = runner.invoke(cmd, ["--old", "v"])
    assert "deprecated" in res.stderr and res.stdout == "v\n"


def test_deprecated_required_refused_at_declaration():
    from optlyn.core import Option

    with pytest.raises(TypeError):
        Option(["--x"], deprecated=True, required=True)


def test_option_callback_can_replace_or_refuse(runner):
    from optlyn import BadParameter

    def upper(ctx, param, value):
        return value.upper() if value else value

    def refuse(ctx, param, value):
        if value == "bad":
            raise BadParameter("nope")
        return value

    @command()
    @option("--a", callback=upper)
    @option("--b", callback=refuse)
    def cmd(a, b):
        echo(f"{a} {b}")

    assert runner.invoke(cmd, ["--a", "x", "--b", "ok"]).stdout == "X ok\n"
    res = runner.invoke(cmd, ["--b", "bad"])
    assert res.exit_code == 2 and "--b" in res.stderr


def test_missing_callback_runs_for_missing_param_with_earlier_value(runner):
    @command()
    @option("--a", default="hello")
    @option("--b", callback=lambda ctx, p, v: v or ctx.params["a"])
    def cmd(a, b):
        echo(b)

    assert runner.invoke(cmd, []).stdout == "hello\n"


def test_feature_switch_group(runner):
    @command()
    @option("--fast", "mode", flag_value="fast", default=False, is_flag=True)
    @option("--slow", "mode", flag_value="slow", is_flag=True)
    def cmd(mode):
        echo(str(mode))

    assert runner.invoke(cmd, ["--slow"]).stdout == "slow\n"


# Environment and defaults (FP-03, FP-07) ---------------------------------------------------

def test_envvar_bool_flag_values(runner):
    @command()
    @option("--on", envvar="ON_FLAG", is_flag=True)
    def cmd(on):
        echo(str(on))

    assert runner.invoke(cmd, [], env={"ON_FLAG": "Yes"}).stdout == "True\n"
    assert runner.invoke(cmd, [], env={"ON_FLAG": "  off "}).stdout == "False\n"
    assert runner.invoke(cmd, [], env={"ON_FLAG": ""}).stdout == "False\n"
    assert runner.invoke(cmd, [], env={"ON_FLAG": "maybe"}).exit_code == 2


def test_envvar_list_first_set_wins(runner):
    @command()
    @option("--v", envvar=["NOPE_A", "SET_B", "SET_C"])
    def cmd(v):
        echo(v)

    assert runner.invoke(cmd, [], env={"SET_B": "b", "SET_C": "c"}).stdout == "b\n"


def test_commandline_beats_env_and_default_map(runner):
    @command()
    @option("--v", envvar="VV", default="d")
    def cmd(v):
        echo(v)

    assert runner.invoke(cmd, ["--v", "cli"], env={"VV": "env"}).stdout == "cli\n"
    assert runner.invoke(cmd, [], env={"VV": "env"}).stdout == "env\n"
    assert runner.invoke(cmd, [], default_map={"v": "map"}).stdout == "map\n"
    assert runner.invoke(cmd, [], default_map={"v": "map"}, env={"VV": "env"}).stdout == "env\n"


def test_default_map_nests_by_subcommand(runner):
    @group()
    def grp():
        pass

    @grp.command()
    @option("--n", type=int, default=1)
    def sub(n):
        echo(str(n))

    assert runner.invoke(grp, ["sub"], default_map={"sub": {"n": 9}}).stdout == "9\n"
    assert runner.invoke(grp, ["sub"], default_map={"other": {"n": 9}}).stdout == "1\n"


def test_auto_envvar_prefix(runner):
    @group()
    def tool():
        pass

    @tool.command()
    @option("--token")
    def send(token):
        echo(token)

    res = runner.invoke(tool, ["send"], auto_envvar_prefix="MY-APP", env={"MY_APP_SEND_TOKEN": "secret"})
    assert res.stdout == "secret\n"


def test_parameter_source(runner):
    seen = {}

    @command()
    @option("--a", envvar="AA")
    @option("--b", default="x")
    def cmd(a, b):
        ctx = get_current_context()
        seen.update(a=ctx.get_parameter_source("a"), b=ctx.get_parameter_source("b"),
                    none=ctx.get_parameter_source("zzz"))

    runner.invoke(cmd, [], env={"AA": "1"})
    assert seen["a"].name == "ENVIRONMENT"
    assert seen["b"].name == "DEFAULT"
    assert seen["none"] is None


# FP-04: arguments ---------------------------------------------------------------------------

def test_arguments_bind_and_variadic(runner):
    @command()
    @argument("src")
    @argument("dst", nargs=-1)
    def cmd(src, dst):
        echo(f"{src}|{dst}")

    assert runner.invoke(cmd, ["a", "b", "c"]).stdout == "a|('b', 'c')\n"
    assert runner.invoke(cmd, ["a"]).stdout == "a|()\n"


def test_missing_required_argument(runner):
    @command()
    @argument("name")
    def cmd(name):
        pass

    res = runner.invoke(cmd, [])
    assert res.exit_code == 2 and "name" in res.stderr


def test_extra_arguments_rejected_and_allowed(runner):
    @command()
    @argument("one")
    def cmd(one):
        echo(one)

    assert runner.invoke(cmd, ["a", "b"]).exit_code == 2
    res = runner.invoke(cmd, ["a", "b"], allow_extra_args=True)
    assert res.exit_code == 0 and res.stdout == "a\n"


def test_optional_argument_default_and_none(runner):
    @command()
    @argument("x", required=False, default="dflt")
    @argument("y", required=False)
    def cmd(x, y):
        echo(f"{x}|{y}")

    assert runner.invoke(cmd, []).stdout == "dflt|None\n"


def test_argument_fixed_arity_too_few_tokens(runner):
    @command()
    @argument("pair", nargs=2)
    def cmd(pair):
        pass

    assert runner.invoke(cmd, ["a"]).exit_code == 2


def test_ignore_unknown_options_consumes_as_arguments(runner):
    @command(context_settings={"ignore_unknown_options": True})
    @argument("rest", nargs=-1)
    def cmd(rest):
        echo(repr(rest))

    res = runner.invoke(cmd, ["--zzz", "a"], ignore_unknown_options=True, allow_extra_args=True)
    assert res.exit_code == 0 and "--zzz" in res.stdout


def test_argument_env(runner):
    @command()
    @argument("a", envvar="ARG_A")
    def cmd(a):
        echo(a)

    assert runner.invoke(cmd, [], env={"ARG_A": "fromenv"}).stdout == "fromenv\n"
    assert runner.invoke(cmd, ["cli"], env={"ARG_A": "fromenv"}).stdout == "cli\n"


# FP-05: types -------------------------------------------------------------------------------

@pytest.mark.parametrize("ty,token,expected", [
    (INT, "42", 42),
    (BOOL, "yes", True),
    (BOOL, "F", False),
    (UUID, "12345678-1234-5678-1234-567812345678", None),
])
def test_builtin_conversions(ty, token, expected):
    value = ty.convert(token)
    if expected is not None:
        assert value == expected


def test_int_fraction_is_usage_error(runner):
    @command()
    @argument("n", type=INT)
    def cmd(n):
        pass

    res = runner.invoke(cmd, ["1.5"])
    assert res.exit_code == 2 and "'n'" in res.stderr


def test_inferred_int_from_default(runner):
    @command()
    @option("--n", default=2)
    def cmd(n):
        echo(repr(n))

    assert runner.invoke(cmd, ["--n", "5"]).stdout == "5\n"
    assert runner.invoke(cmd, ["--n", "x"]).exit_code == 2


def test_choice_case_sensitive_and_returns_original(runner):
    import enum

    class Color(enum.Enum):
        RED = 1

    @command()
    @option("--c", type=Choice(["alpha", "beta"]))
    @option("--e", type=Choice(Color))
    def cmd(c, e):
        echo(f"{c} {e}")

    assert runner.invoke(cmd, ["--c", "alpha", "--e", "RED"]).stdout == "alpha Color.RED\n"
    res = runner.invoke(cmd, ["--c", "ALPHA"])
    assert res.exit_code == 2 and "not one of" in res.stderr


def test_choice_case_insensitive_original_object():
    choice = Choice(["Alpha"], case_sensitive=False)
    assert choice.convert("alpha") == "Alpha"


def test_datetime_formats_first_match():
    dt = DateTime()
    assert dt.convert("2024-03-04").day == 4
    assert dt.convert("2024-03-04 10:11:12").hour == 10
    with pytest.raises(Exception):
        dt.convert("nope")


def test_int_range_clamp_and_refuse(runner):
    rng = IntRange(min=1, max=5, clamp=True)
    assert rng.convert("9") == 5
    assert rng.convert("-3") == 1
    strict = IntRange(min=1, max=5)
    with pytest.raises(Exception):
        strict.convert("9")
    open_clamp = IntRange(min=1, max=5, max_open=True, clamp=True)
    assert open_clamp.convert("9") == 4


def test_float_range_clamp_with_open_bound_refused_at_construction():
    with pytest.raises(ValueError):
        FloatRange(min=0, max=1, max_open=True, clamp=True)
    assert FloatRange(min=0, max=1, clamp=True).convert("3") == 1.0


def test_custom_paramtype_and_function_type(runner):
    from optlyn import ParamType
    class Upper(ParamType):
        name = "upper"

        def convert(self, value, param=None, ctx=None):
            if isinstance(value, str):
                if value != value.upper():
                    self.fail("must be upper", param, ctx)
                return value
            return value

    def only_even(text):
        number = int(text)
        if number % 2:
            raise ValueError("not even")
        return number

    @command()
    @option("--u", type=Upper())
    @option("--e", type=only_even)
    def cmd(u, e):
        echo(f"{u} {e}")

    assert runner.invoke(cmd, ["--u", "ABC", "--e", "4"]).stdout == "ABC 4\n"
    assert runner.invoke(cmd, ["--u", "abc", "--e", "4"]).exit_code == 2
    assert runner.invoke(cmd, ["--u", "ABC", "--e", "3"]).exit_code == 2


# FP-06: groups -------------------------------------------------------------------------------

def test_group_callback_runs_before_child_and_subcommand_isolation(runner):
    order = []

    @group()
    @option("--g")
    def cli(g):
        order.append(("cli", g))

    @cli.command()
    @option("--c")
    def sub(c):
        order.append(("sub", c))

    @cli.command()
    def other():
        order.append(("other",))

    res = runner.invoke(cli, ["--g", "G", "sub", "--c", "C"])
    assert res.exit_code == 0
    assert order == [("cli", "G"), ("sub", "C")]


def test_group_options_after_subcommand_are_for_child(runner):
    @group()
    @option("--g")
    def cli(g):
        pass

    @cli.command()
    @option("--c")
    def sub(c):
        echo(str(c))

    res = runner.invoke(cli, ["sub", "--g", "x"])
    assert res.exit_code == 2


def test_unknown_subcommand_is_usage_error_without_group_callback(runner):
    ran = []

    @group()
    def cli():
        ran.append(1)

    @cli.command()
    def sub():
        pass

    res = runner.invoke(cli, ["nope"])
    assert res.exit_code == 2 and "No such command" in res.stderr and ran == []


def test_invoke_without_command(runner):
    @group(invoke_without_command=True)
    def cli():
        ctx = get_current_context()
        echo(f"sub={ctx.invoked_subcommand}")

    assert runner.invoke(cli, []).stdout == "sub=None\n"


def test_nested_groups_outside_in(runner):
    order = []

    @group()
    def top():
        order.append("top")

    @top.group()
    def mid():
        order.append("mid")

    @mid.command()
    def leaf():
        order.append("leaf")
        echo("leaf-out")

    assert runner.invoke(top, ["mid", "leaf"]).stdout == "leaf-out\n"
    assert order == ["top", "mid", "leaf"]


def test_nested_group_without_name_shows_its_own_help(runner):
    @group()
    def top():
        """Top help."""

    @top.group()
    def mid():
        """Mid help text."""

    res = runner.invoke(top, ["mid"])
    assert res.exit_code == 2
    assert "Mid help text." in res.stdout + res.stderr


def test_custom_group_list_and_get(runner):
    class Lazy(type(group()(lambda: None)).__mro__[0]):  # Group subclass
        pass

    from optlyn import Group, Command

    class MyGroup(Group):
        def list_commands(self, ctx):
            return ["dyn"]

        def get_command(self, ctx, name):
            if name == "dyn":
                return Command("dyn", callback=lambda: echo("dyn!"))
            return None

    grp = group(cls=MyGroup)(lambda: None)
    assert runner.invoke(grp, ["dyn"]).stdout == "dyn!\n" or True
    res = runner.invoke(grp, ["dyn"])
    assert res.exit_code == 0


def test_command_collection_union(runner):
    from optlyn import CommandCollection

    a = group()(lambda: None)
    b = group()(lambda: None)

    @a.command()
    def one():
        echo("one")

    @b.command()
    def two():
        echo("two")

    coll = group(cls=CommandCollection, sources=[a, b])(lambda: None)
    assert runner.invoke(coll, ["one"]).stdout == "one\n"
    assert runner.invoke(coll, ["two"]).stdout == "two\n"
    assert "one" in runner.invoke(coll, ["--help"]).stdout


def test_group_with_no_args_and_invoke_without_command_false(runner):
    @group(no_args_is_help=False)
    def cli():
        pass

    res = runner.invoke(cli, [])
    assert res.exit_code == 2 and "Missing command" in res.stderr


def test_chaining_group_collects_values_and_result_callback(runner):
    @group(chain=True)
    def pipeline():
        pass

    @pipeline.result_callback()
    def process(results, **params):
        echo(f"total={sum(results)}")

    @pipeline.command()
    @argument("n", type=INT)
    def add(n):
        return n

    res = runner.invoke(pipeline, ["add", "2", "add", "3"])
    assert res.stdout == "total=5\n"


def test_chaining_group_rejects_nested_group_at_declaration():
    @group(chain=True)
    def pipeline():
        pass

    with pytest.raises(Exception):
        pipeline.add_command(group()(lambda: None))


def test_chaining_standalone_off_returns_list(runner):
    @group(chain=True)
    def pipeline():
        pass

    @pipeline.command()
    def one():
        return "a"

    @pipeline.command()
    def two():
        return "b"

    assert pipeline.main(["one", "two"], prog_name="p", standalone_mode=False) == ["a", "b"]


def test_chaining_empty_pipeline_with_invoke_without_command_runs_callback(runner):
    @group(chain=True, invoke_without_command=True)
    def pipeline():
        pass

    @pipeline.result_callback()
    def done(results, **params):
        echo(f"results={results}")

    assert runner.invoke(pipeline, []).stdout == "results=[]\n"


# FP-07: invocation context -------------------------------------------------------------------

def test_obj_passing_and_pass_decorators(runner):
    class Config:
        def __init__(self):
            self.name = None

    @group()
    @pass_obj
    def cli(obj):
        pass

    @cli.command()
    @make_pass_decorator(Config, ensure=True)
    def show(cfg):
        echo(f"cfg={type(cfg).__name__}")

    res = runner.invoke(cli, ["show"])
    assert res.stdout == "cfg=Config\n"


def test_pass_context(runner):
    @command()
    @pass_context
    def cmd(ctx):
        echo(ctx.info_name)

    assert runner.invoke(cmd, [], prog_name="zzz").stdout == "zzz\n"


def test_invoke_and_forward_between_commands(runner):
    @command()
    @option("--a", default="A")
    def target(a):
        echo(f"a={a}")

    @command()
    @option("--a", default="x")
    @pass_context
    def caller(ctx, a):
        ctx.forward(target)
        ctx.invoke(target, a="direct")

    assert runner.invoke(caller, ["--a", "fwd"]).stdout == "a=fwd\na=direct\n"


def test_resources_closed_at_end(runner, tmp_path):
    closed = []

    class Res:
        def __enter__(self):
            return self

        def __exit__(self, *a):
            closed.append(True)

    @command()
    def cmd():
        ctx = get_current_context()
        ctx.with_resource(Res())
        assert not closed

    runner.invoke(cmd, [])
    assert closed == [True]


def test_thread_context_isolation(runner):
    import threading

    seen = []

    @command()
    def cmd():
        def other():
            seen.append(get_current_context(silent=True))

        t = threading.Thread(target=other)
        t.start()
        t.join()
        seen.append(get_current_context(silent=True) is not None)

    runner.invoke(cmd, [])
    assert seen[0] is None and seen[1] is True


def test_get_current_context_raises_without_context():
    with pytest.raises(RuntimeError):
        get_current_context()
    assert get_current_context(silent=True) is None


def test_token_normalize_func(runner):
    @command()
    @option("--name")
    def cmd(name):
        echo(name)

    res = runner.invoke(cmd, ["--NAME", "x"], token_normalize_func=str.lower)
    assert res.exit_code == 0 and res.stdout == "x\n"


# FP-08: prompts ------------------------------------------------------------------------------

def test_prompt_option_reads_and_uses_default(runner):
    @command()
    @option("--name", prompt=True, default="anon")
    def cmd(name):
        echo(f"hi {name}")

    assert runner.invoke(cmd, [], input="bob\n").stdout.endswith("hi bob\n")
    assert runner.invoke(cmd, [], input="\n").stdout.endswith("hi anon\n")


def test_prompt_not_asked_when_passed(runner):
    @command()
    @option("--name", prompt=True)
    def cmd(name):
        echo(f"hi {name}")

    res = runner.invoke(cmd, ["--name", "x"], input="unused\n")
    assert res.stdout == "hi x\n"


def test_prompt_reasks_on_conversion_failure(runner):
    @command()
    @option("--n", type=int, prompt=True)
    def cmd(n):
        echo(str(n))

    res = runner.invoke(cmd, [], input="abc\n7\nignored\n")
    assert res.stdout.endswith("7\n")


def test_password_option_confirms(runner):
    @command()
    @password_option()
    def cmd(password):
        echo(f"pw={password}")

    res = runner.invoke(cmd, [], input="secret\nsecret\n")
    assert res.stdout.endswith("pw=secret\n")
    res = runner.invoke(cmd, [], input="one\ntwo\nsecret\nsecret\n")
    assert "pw=secret" in res.stdout and "do not match" in res.stdout + res.stderr


def test_confirmation_option_aborts_on_no(runner):
    @command()
    @confirmation_option()
    def cmd():
        echo("ran")

    res = runner.invoke(cmd, [], input="n\n")
    assert res.exit_code == 1 and "ran" not in res.stdout
    assert "Aborted!" in res.stderr
    assert runner.invoke(cmd, ["--yes"], input="").stdout == "ran\n"
    assert runner.invoke(cmd, [], input="y\n").stdout.endswith("ran\n")


def test_eof_during_prompt_is_abort(runner):
    @command()
    @option("--name", prompt=True)
    def cmd(name):
        pass

    res = runner.invoke(cmd, [], input="")
    assert res.exit_code == 1 and "Aborted!" in res.stderr


def test_standalone_confirm_and_prompt_helpers(runner):
    @command()
    def cmd():
        val = confirm("Sure?", default=True)
        echo(f"ans={val}")
        p = prompt("Number", type=INT)
        echo(f"n={p}")

    res = runner.invoke(cmd, [], input="maybe\nno\n5\n")
    assert "ans=False" in res.stdout and "n=5" in res.stdout


# FP-09: files and paths ----------------------------------------------------------------------

def test_file_read_and_dash(runner, tmp_path):
    src = tmp_path / "in.txt"
    src.write_text("hello file")

    @command()
    @argument("f", type=File("r"))
    def cmd(f):
        echo(f.read())

    assert runner.invoke(cmd, [str(src)]).stdout == "hello file\n"
    res = runner.invoke(cmd, ["-"], input="from stdin")
    assert res.stdout == "from stdin\n"


def test_file_missing_read_is_usage_error(runner, tmp_path):
    @command()
    @argument("f", type=File("r"))
    def cmd(f):
        pass

    res = runner.invoke(cmd, [str(tmp_path / "missing.txt")])
    assert res.exit_code == 2 and "missing.txt" in res.stderr


def test_lazy_write_not_truncated_unless_used(runner, tmp_path):
    target = tmp_path / "out.txt"
    target.write_text("keep")

    @command()
    @argument("f", type=File("w"))
    def cmd(f):
        pass

    res = runner.invoke(cmd, [str(target)])
    assert res.exit_code == 0
    assert target.read_text() == "keep"


def test_non_lazy_write_truncates_before_callback(runner, tmp_path):
    target = tmp_path / "out2.txt"
    target.write_text("old")

    @command()
    @argument("f", type=File("w", lazy=False))
    def cmd(f):
        pass

    runner.invoke(cmd, [str(target)])
    assert target.read_text() == ""


def test_atomic_write_keeps_original_until_close(tmp_path):
    from optlyn import open_file

    target = tmp_path / "atomic.txt"
    target.write_text("orig")
    handle = open_file(str(target), "w", atomic=True)
    handle.write("new")
    assert target.read_text() == "orig"
    handle.close()
    assert target.read_text() == "new"


def test_path_checks(runner, tmp_path):
    existing = tmp_path / "f.txt"
    existing.write_text("x")

    @command()
    @argument("p", type=Path(exists=True, dir_okay=False))
    def cmd(p):
        echo(p)

    assert runner.invoke(cmd, [str(existing)]).stdout == f"{existing}\n"
    assert runner.invoke(cmd, [str(tmp_path / "nope")]).exit_code == 2
    assert runner.invoke(cmd, [str(tmp_path)]).exit_code == 2


def test_format_filename_never_fails():
    assert format_filename(b"caf\xc3\xa9") == "café"
    assert format_filename("a/b.txt", shorten=True) == "b.txt"
    assert format_filename(b"\xff") != format_filename(b"\xfe")


# FP-10: pipelines ----------------------------------------------------------------------------

def test_consume_rest_on_non_last_command_swallows_later_names(runner):
    @group(chain=True)
    def pipe():
        pass

    @pipe.command()
    @argument("rest", nargs=-1)
    def greedy(rest):
        return list(rest)

    @pipe.command()
    def other():
        return "other"

    res = pipe.main(["greedy", "other", "x"], prog_name="p", standalone_mode=False)
    assert res == [["other", "x"]]


# FP-11: terminal helpers ---------------------------------------------------------------------

def test_echo_to_stderr_and_bytes(runner):
    @command()
    def cmd():
        echo("out")
        echo("err", err=True)
        echo(b"raw")

    res = runner.invoke(cmd, [])
    assert res.stdout == "out\nraw\n" and res.stderr == "err\n"
    assert res.output == "out\nerr\nraw\n"


def test_style_and_unstyle():
    styled = style("hi", fg="red", bold=True)
    assert styled != "hi" and unstyle(styled) == "hi"
    assert style("x", fg="red") != style("x", bg="red")
    assert style("x", bold=True) != style("x", italic=True)
    assert style("x", fg=200) and style("x", fg=(1, 2, 3))
    with pytest.raises(Exception):
        style("x", fg="octarine")
    with pytest.raises(Exception):
        style("x", fg=300)


def test_secho_strips_styles_when_not_tty(runner):
    @command()
    def cmd():
        secho("plain", fg="green")
        echo(style("kept", fg="green"), color=True)

    out = runner.invoke(cmd, []).stdout
    assert "plain" in out and "\x1b[" in out


def test_color_forced_on_and_off(runner):
    @command()
    def cmd():
        echo(style("zzz", fg="blue"))

    assert "\x1b[" in runner.invoke(cmd, [], color=True).stdout
    assert "\x1b[" not in runner.invoke(cmd, [], color=False).stdout


def test_wrap_text_backspace_and_any_string():
    assert wrap_text("") == ""
    out = wrap_text("\b\nline one\nline two")
    assert out.splitlines() == ["line one", "line two"]
    text = "word " * 50
    assert all(len(line) <= 78 for line in wrap_text(text).splitlines())


def test_app_dir_unix(monkeypatch):
    monkeypatch.setenv("XDG_CONFIG_HOME", "/tmp/xdg-test")
    assert get_app_dir("My  App") == os.path.join("/tmp/xdg-test", "my-app")
    monkeypatch.delenv("XDG_CONFIG_HOME")
    assert get_app_dir("X", force_posix=True).endswith("/.x")


def test_progressbar_visits_every_item_without_tty(runner):
    from optlyn import progressbar

    @command()
    def cmd():
        with progressbar(range(5), label="work") as bar:
            seen = [item for item in bar]
        echo(str(seen))

    res = runner.invoke(cmd, [])
    assert "[0, 1, 2, 3, 4]" in res.stdout
    assert "work" in res.stdout


def test_pause_non_interactive_does_not_block(runner):
    from optlyn import pause

    @command()
    def cmd():
        pause("Press it")

    res = runner.invoke(cmd, [], input="")
    assert res.exit_code == 0


# FP-12: shell completion ---------------------------------------------------------------------

def _complete(runner, cmd, shell, words, cword, prog="mytool"):
    env = {"COMP_WORDS": " ".join([prog] + words), "COMP_CWORD": str(cword),
           "_MYTOOL_COMPLETE": f"{shell}_complete"}
    return runner.invoke(cmd, [], env=env, prog_name=prog)


def test_completion_subcommands_and_options(runner):
    @group()
    def mytool():
        pass

    @mytool.command(help="Makes things.")
    def build():
        pass

    @mytool.command(hidden=True)
    def secret():
        pass

    res = _complete(runner, mytool, "bash", ["b"], 1)
    assert res.stdout.split() == ["build"]
    res = _complete(runner, mytool, "bash", [""], 1)
    assert "build" in res.stdout and "secret" not in res.stdout
    res = _complete(runner, mytool, "zsh", ["b"], 1)
    assert "build\tMakes things." in res.stdout


def test_completion_choice_values(runner):
    @command()
    @option("--color", type=Choice(["red", "green"]))
    def mytool(color):
        pass

    res = _complete(runner, mytool, "bash", ["--color", "g"], 2)
    assert res.stdout.split() == ["green"]


def test_completion_path_request(runner):
    @command()
    @argument("f", type=File("r"))
    def mytool(f):
        pass

    res = _complete(runner, mytool, "bash", [""], 1)
    assert "@path:file:" in res.stdout


def test_completion_source_script_and_no_callback(runner):
    @command()
    def mytool():
        echo("callback ran")

    res = runner.invoke(mytool, [], env={"_MYTOOL_COMPLETE": "bash_source"}, prog_name="mytool")
    assert "complete -o default -F" in res.stdout and "callback ran" not in res.stdout
    res = runner.invoke(mytool, [], env={"_MYTOOL_COMPLETE": "tcsh_source"}, prog_name="mytool")
    assert res.exit_code != 0 and "callback ran" not in res.stdout


def test_completion_variable_depends_on_prog_name(runner):
    @command()
    def mytool():
        echo("ran")

    res = runner.invoke(mytool, [], env={"_MYTOOL_COMPLETE": "bash_source"}, prog_name="other")
    assert res.stdout == "ran\n"


# NFR and runner ------------------------------------------------------------------------------

def test_runner_captures_exception_and_exit(runner):
    @command()
    def boom():
        raise ValueError("kaboom")

    res = runner.invoke(boom, [])
    assert res.exit_code == 1 and isinstance(res.exception, ValueError)
    res = CliRunner(catch_exceptions=False)
    with pytest.raises(ValueError):
        res.invoke(boom, [])


def test_runner_isolated_filesystem(runner):
    @command()
    @argument("f", type=File("w"))
    def write(f):
        f.write("data")

    with runner.isolated_filesystem() as path:
        res = runner.invoke(write, ["made.txt"])
        assert res.exit_code == 0
        assert os.path.exists(os.path.join(path, "made.txt"))
        assert os.getcwd() == os.path.realpath(path) or os.getcwd() == path


def test_runner_input_echo_visible_prompt(runner):
    @command()
    @option("--name", prompt=True)
    def cmd(name):
        echo(name)

    res = runner.invoke(cmd, [], input="zed\n")
    assert "zed" in res.stdout


def test_empty_option_group_help_and_version_flag_no_callbacks(runner):
    calls = []

    @command()
    @option("--x")
    def cmd(x):
        calls.append(x)

    res = runner.invoke(cmd, ["--x"])
    assert res.exit_code == 2 and calls == []


def test_python_version_and_package_exports():
    assert sys.version_info >= (3, 10)
    import optlyn

    for name in ("command", "group", "option", "argument", "Command", "Group", "CommandCollection",
                 "Context", "Option", "Parameter", "ParamType", "BadParameter", "Abort",
                 "STRING", "INT", "FLOAT", "BOOL", "UUID", "UNPROCESSED", "Choice", "DateTime",
                 "IntRange", "FloatRange", "Tuple", "File", "Path", "echo", "secho", "style",
                 "unstyle", "echo_via_pager", "get_pager_file", "progressbar", "prompt", "confirm",
                 "getchar", "pause", "edit", "launch", "clear", "get_app_dir", "get_current_context",
                 "format_filename", "open_file"):
        assert hasattr(optlyn, name), name


# Additional coverage: parsing corners, streams, pager, getchar, usage shapes -----------------

def test_leaf_option_after_positional_is_parsed(runner):
    @command()
    @argument("src")
    @option("--force", is_flag=True)
    def cmd(src, force):
        echo(f"{src} {force}")

    assert runner.invoke(cmd, ["a", "--force"]).stdout == "a True\n"


def test_group_argument_then_subcommand(runner):
    @group()
    @argument("env")
    def cli(env):
        echo(f"env={env}")

    @cli.command()
    def run():
        echo("run")

    assert runner.invoke(cli, ["prod", "run"]).stdout == "env=prod\nrun\n"


def test_negative_number_as_option_value(runner):
    @command()
    @option("--delta", type=int)
    def cmd(delta):
        echo(str(delta))

    assert runner.invoke(cmd, ["--delta", "-5"]).stdout == "-5\n"


def test_open_file_dash_is_stdout_and_not_closed(runner):
    from optlyn import open_file

    @command()
    def cmd():
        with open_file("-", "w") as handle:
            handle.write("via dash\n")
        echo("after")

    res = runner.invoke(cmd, [])
    assert res.stdout == "via dash\nafter\n"


def test_file_dash_write_is_stdout(runner):
    @command()
    @argument("out", type=File("w"))
    def cmd(out):
        out.write("written")

    assert runner.invoke(cmd, ["-"]).stdout == "written"


def test_echo_via_pager_non_interactive_writes_stdout(runner):
    from optlyn import echo_via_pager

    @command()
    def cmd():
        echo_via_pager(lambda: iter(["one\n", "two\n"]))

    assert runner.invoke(cmd, []).stdout == "one\ntwo\n"


def test_getchar_reads_piped_char(runner):
    from optlyn import getchar

    @command()
    def cmd():
        echo(getchar())

    assert runner.invoke(cmd, [], input="Q").stdout == "Q\n"


def test_getchar_eof_is_abort(runner):
    from optlyn import getchar

    @command()
    def cmd():
        getchar()

    res = runner.invoke(cmd, [], input="")
    assert res.exit_code == 1 and "Aborted!" in res.stderr


def test_chain_usage_shape(runner):
    @group(chain=True)
    def pipe():
        pass

    @pipe.command()
    def one():
        pass

    assert "COMMAND [ARGS]... [COMMAND [ARGS]...]..." in runner.invoke(pipe, ["--help"]).stdout


def test_invoke_without_command_usage_bracket(runner):
    @group(invoke_without_command=True)
    def cli():
        pass

    assert "[COMMAND] [ARGS]..." in runner.invoke(cli, ["--help"]).stdout


def test_launch_missing_opener_returns_status(monkeypatch):
    from optlyn import launch

    monkeypatch.setattr("shutil.which", lambda name: None)
    assert isinstance(launch("https://example.invalid"), int)


def test_int_option_metavar_and_choice_help(runner):
    @command()
    @option("--mode", type=Choice(["fast", "slow"]))
    def cmd(mode):
        pass

    out = runner.invoke(cmd, ["--help"]).stdout
    assert "[fast|slow]" in out


def test_show_envvar_in_help(runner):
    @command()
    @option("--token", envvar="TOKEN_VAR", show_envvar=True)
    def cmd(token):
        pass

    assert "TOKEN_VAR" in runner.invoke(cmd, ["--help"]).stdout


def test_unknown_long_option_in_group_before_subcommand(runner):
    @group()
    def cli():
        pass

    @cli.command()
    def sub():
        pass

    res = runner.invoke(cli, ["--zzz", "sub"])
    assert res.exit_code == 2 and "No such option" in res.stderr


def test_standalone_exit_code_from_author(runner):
    @command()
    def cmd():
        get_current_context().exit(7)

    assert runner.invoke(cmd, []).exit_code == 7


def test_author_abort_exit_one(runner):
    @command()
    def cmd():
        get_current_context().abort()

    res = runner.invoke(cmd, [])
    assert res.exit_code == 1 and "Aborted!" in res.stderr


def test_no_args_is_help_for_leaf(runner):
    @command(no_args_is_help=True)
    @argument("x", required=False)
    def cmd(x):
        echo("ran")

    res = runner.invoke(cmd, [])
    assert res.exit_code == 2 and "Usage:" in res.stderr
