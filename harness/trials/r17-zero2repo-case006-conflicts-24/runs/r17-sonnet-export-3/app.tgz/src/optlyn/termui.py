"""Terminal interaction helpers."""
from __future__ import annotations

import getpass
import inspect
import itertools
import math
import os
import shlex
import subprocess
import sys
import tempfile
import time
from contextlib import contextmanager

from . import _compat
from .exceptions import Abort, OptlynException, UsageError
from .globals import resolve_color_default
from .types import Choice, convert_type
from .utils import echo, format_filename

visible_prompt_func = input
hidden_prompt_func = getpass.getpass


def _build_prompt(text, suffix, show_default=False, default=None, show_choices=True, type=None):
    prompt = text
    if type is not None and show_choices and isinstance(type, Choice):
        prompt += f" ({', '.join(str(t) for t, _ in type._pairs)})"
    if default is not None and show_default:
        prompt = f"{prompt} [{default}]"
    return f"{prompt}{suffix}"


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None, value_proc=None,
           prompt_suffix=": ", show_default=True, err=False, show_choices=True):
    def prompt_func(text):
        f = hidden_prompt_func if hide_input else visible_prompt_func
        try:
            echo(text.rstrip(" "), nl=False, err=err)
            return f(" ")
        except (KeyboardInterrupt, EOFError):
            if hide_input:
                echo(None, err=err)
            raise Abort() from None

    if value_proc is None:
        value_proc = convert_type(type, default)
    prompt_text = _build_prompt(text, prompt_suffix, show_default, default, show_choices, type)
    if confirmation_prompt:
        if confirmation_prompt is True:
            confirmation_prompt = "Repeat for confirmation"
        confirmation_prompt = _build_prompt(confirmation_prompt, prompt_suffix)
    while True:
        while True:
            value = prompt_func(prompt_text)
            if value:
                break
            elif default is not None:
                value = default
                break
        try:
            result = value_proc(value)
        except UsageError as e:
            if hide_input:
                echo("Error: The value you entered was invalid.", err=err)
            else:
                echo(f"Error: {e.message}", err=err)
            continue
        if not confirmation_prompt:
            return result
        while True:
            value2 = prompt_func(confirmation_prompt)
            is_empty = not value and not value2
            if value2 or is_empty:
                break
        if value == value2:
            return result
        echo("Error: The two entered values do not match.", err=err)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    prompt_text = _build_prompt(text, prompt_suffix, show_default,
                                "y/n" if default is None else ("Y/n" if default else "y/N"))
    while True:
        try:
            echo(prompt_text.rstrip(" "), nl=False, err=err)
            value = visible_prompt_func(" ").lower().strip()
        except (KeyboardInterrupt, EOFError):
            raise Abort() from None
        if value in ("y", "yes"):
            rv = True
        elif value in ("n", "no"):
            rv = False
        elif default is not None and value == "":
            rv = default
        else:
            echo("Error: invalid input", err=err)
            continue
        break
    if abort and not rv:
        raise Abort()
    return rv


# --- pager ------------------------------------------------------------

def _to_generator(text_or_generator):
    if inspect.isgeneratorfunction(text_or_generator):
        text_or_generator = text_or_generator()
    elif callable(text_or_generator):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        return iter((text_or_generator,))
    try:
        return (x if isinstance(x, str) else str(x) for x in iter(text_or_generator))
    except TypeError:
        return iter((str(text_or_generator),))


def _pager_command():
    return (os.environ.get("PAGER") or "").strip()


@contextmanager
def get_pager_file(color=None):
    stdout = sys.stdout
    cmd = _pager_command()
    if not _compat.is_interactive() or not cmd:
        yield _StreamProxy(stdout, color)
        return
    color = resolve_color_default(color)
    if color is None:
        color = "less" in os.path.basename(cmd.split()[0]) if cmd.split() else False
    env = dict(os.environ)
    if "less" in cmd and "LESS" not in env:
        env["LESS"] = "-R"
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, env=env)
    encoding = getattr(stdout, "encoding", None) or "utf-8"
    try:
        yield _PipeWriter(proc.stdin, encoding, color)
    finally:
        try:
            proc.stdin.close()
        except (OSError, BrokenPipeError):
            pass
        while True:
            try:
                proc.wait()
                break
            except KeyboardInterrupt:
                pass


class _StreamProxy:
    def __init__(self, stream, color):
        self._stream = stream
        self._color = color

    def write(self, text):
        echo(text, file=self._stream, nl=False, color=self._color)
        return len(text)

    def flush(self):
        self._stream.flush()

    def writelines(self, lines):
        for line in lines:
            self.write(line)

    def isatty(self):
        return _compat.isatty(self._stream)


class _PipeWriter:
    def __init__(self, pipe, encoding, color):
        self._pipe = pipe
        self._encoding = encoding
        self._color = color

    def write(self, text):
        if not self._color:
            text = _compat.strip_ansi(text)
        try:
            self._pipe.write(text.encode(self._encoding, "replace"))
            self._pipe.flush()
        except (OSError, BrokenPipeError):
            pass
        return len(text)

    def flush(self):
        try:
            self._pipe.flush()
        except (OSError, BrokenPipeError):
            pass

    def writelines(self, lines):
        for line in lines:
            self.write(line)

    def isatty(self):
        return False


def echo_via_pager(text_or_generator, color=None):
    gen = itertools.chain(_to_generator(text_or_generator), "\n")
    with get_pager_file(color) as f:
        for chunk in gen:
            f.write(chunk)
            f.flush()


# --- progress bar -----------------------------------------------------

class ProgressBar:
    def __init__(self, iterable, length=None, fill_char="#", empty_char="-",
                 bar_template="%(label)s  [%(bar)s]  %(info)s", info_sep="  ", show_eta=True,
                 show_percent=None, show_pos=False, item_show_func=None, label=None, file=None,
                 color=None, update_min_steps=1, width=36, hidden=False):
        self.fill_char = fill_char
        self.empty_char = empty_char
        self.bar_template = bar_template
        self.info_sep = info_sep
        self.show_eta = show_eta
        self.show_percent = show_percent
        self.show_pos = show_pos
        self.item_show_func = item_show_func
        self.label = label or ""
        self.hidden = hidden
        if file is None:
            file = sys.stdout
        self.file = file
        self.color = color
        self.update_min_steps = update_min_steps
        self._completed_intervals = 0
        self.width = width
        self.autowidth = width == 0
        if length is None:
            try:
                length = len(iterable)
            except (TypeError, AttributeError):
                length = None
        if iterable is None:
            if length is None:
                raise TypeError("iterable or length is required")
            iterable = range(length)
        self.iter = iter(iterable)
        self.length = length
        self.pos = 0
        self.avg = []
        self.last_eta = 0.0
        self.start = self.last_eta = time.time()
        self.eta_known = False
        self.finished = False
        self.max_width = None
        self.entered = False
        self.current_item = None
        self._last_line = None
        self.is_hidden = bool(hidden) or not _compat.isatty(self.file)

    def __enter__(self):
        self.entered = True
        self.render_progress()
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.render_finish()

    def __iter__(self):
        if not self.entered:
            raise RuntimeError("You need to use progress bars in a with block.")
        self.render_progress()
        return self.generator()

    def __next__(self):
        return next(iter(self))

    @property
    def pct(self):
        if self.finished:
            return 1.0
        if not self.length:
            return 0.0
        return min(self.pos / self.length, 1.0)

    @property
    def percent(self):
        return int(self.pct * 100)

    @property
    def time_per_iteration(self):
        if not self.avg:
            return 0.0
        return sum(self.avg) / float(len(self.avg))

    @property
    def eta(self):
        if self.length is not None and not self.finished and self.pos > 0:
            return (time.time() - self.start) / self.pos * (self.length - self.pos)
        return 0.0

    def format_eta(self):
        if self.eta_known:
            t = int(self.eta)
            seconds = t % 60
            t //= 60
            minutes = t % 60
            t //= 60
            hours = t % 24
            t //= 24
            if t > 0:
                return f"{t}d {hours:02}:{minutes:02}:{seconds:02}"
            return f"{hours:02}:{minutes:02}:{seconds:02}"
        return ""

    def format_pos(self):
        pos = str(self.pos)
        if self.length is not None:
            pos += f"/{self.length}"
        return pos

    def format_pct(self):
        return f"{int(self.pct * 100): 4}%"[1:]

    def format_bar(self):
        if self.length is not None:
            bar_length = int(self.pct * self.width)
            bar = self.fill_char * bar_length
            bar += self.empty_char * (self.width - bar_length)
        elif self.finished:
            bar = self.fill_char * self.width
        else:
            chars = list(self.empty_char * (self.width or 1))
            if self.time_per_iteration != 0:
                chars[int((math.cos(self.pos * self.time_per_iteration) / 2.0 + 0.5) * self.width)] = \
                    self.fill_char
            bar = "".join(chars)
        return bar

    def format_progress_line(self):
        show_percent = self.show_percent
        info_bits = []
        if self.length is not None and show_percent is None:
            show_percent = not self.show_pos
        if self.show_pos:
            info_bits.append(self.format_pos())
        if show_percent:
            info_bits.append(self.format_pct())
        if self.show_eta and self.eta_known and not self.finished:
            info_bits.append(self.format_eta())
        if self.item_show_func is not None:
            item_info = self.item_show_func(self.current_item)
            if item_info is not None:
                info_bits.append(item_info)
        return (self.bar_template % {
            "label": self.label,
            "bar": self.format_bar(),
            "info": self.info_sep.join(info_bits),
        }).rstrip()

    def render_progress(self):
        if self.hidden:
            return
        if self.is_hidden:
            if self._last_line != self.label:
                self._last_line = self.label
                echo(self.label, file=self.file, color=self.color)
            return
        line = self.format_progress_line()
        if line == self._last_line:
            return
        self._last_line = line
        echo("\r" + line, file=self.file, nl=False, color=self.color)

    def render_finish(self):
        if self.hidden or self.is_hidden:
            return
        echo(file=self.file)

    def make_step(self, n_steps):
        self.pos += n_steps
        if self.length is not None and self.pos >= self.length:
            self.finished = True
        self.eta_known = self.length is not None and self.pos > 0

    def update(self, n_steps=1, current_item=None):
        if current_item is not None:
            self.current_item = current_item
        self._completed_intervals += n_steps
        self.make_step(n_steps)
        self.render_progress()

    def finish(self):
        self.eta_known = False
        self.current_item = None
        self.finished = True

    def generator(self):
        if not self.entered:
            raise RuntimeError("You need to use progress bars in a with block.")
        for rv in self.iter:
            self.current_item = rv
            yield rv
            self.update(1)
        self.finish()
        self.render_progress()


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)


# --- single char / pause ---------------------------------------------

def _getchar(echo_=False):
    import termios
    import tty
    f = None
    if not _compat.isatty(sys.stdin):
        f = open("/dev/tty")
        fd = f.fileno()
    else:
        fd = sys.stdin.fileno()
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 32).decode(getattr(sys.stdin, "encoding", None) or "utf-8", "replace")
            if echo_ and _compat.isatty(sys.stdout):
                sys.stdout.write(ch)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
            sys.stdout.flush()
    finally:
        if f is not None:
            f.close()
    return ch


def getchar(echo=False):
    ch = _getchar(echo)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    return ch


def pause(info=None, err=False):
    if info is None:
        info = "Press any key to continue..."
    if _compat.is_interactive():
        try:
            echo(info, nl=False, err=err)
            try:
                getchar()
            except (KeyboardInterrupt, EOFError):
                pass
        finally:
            echo(err=err)
    else:
        echo(info, err=err)


def clear():
    if not _compat.isatty(sys.stdout):
        return
    echo("\033[2J\033[1;1H", nl=False)


# --- editor / launch ---------------------------------------------------

def _get_editor(editor=None):
    if editor is not None:
        return editor
    for key in ("VISUAL", "EDITOR"):
        rv = os.environ.get(key)
        if rv:
            return rv
    import shutil
    for ed in ("sensible-editor", "vim", "nano"):
        if shutil.which(ed):
            return ed
    return "vi"


def _edit_file(editor, filename, env=None):
    environ = None
    if env:
        environ = os.environ.copy()
        environ.update(env)
    try:
        c = subprocess.Popen(f'{editor} "{filename}"', env=environ, shell=True)
        exit_code = c.wait()
        if exit_code != 0:
            raise OptlynException(f"{editor}: Editing failed")
    except OSError as e:
        raise OptlynException(f"{editor}: Editing failed: {e}") from e


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    editor = _get_editor(editor)
    if filename is not None:
        _edit_file(editor, filename, env)
        return None
    if text is None:
        text = ""
    data = text.encode("utf-8") if isinstance(text, str) else text
    fd, name = tempfile.mkstemp(prefix="edit-", suffix=extension)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        past = time.time() - 10
        os.utime(name, (past, past))
        timestamp = os.path.getmtime(name)
        _edit_file(editor, name, env)
        if require_save and os.path.getmtime(name) == timestamp:
            return None
        with open(name, "rb") as f:
            rv = f.read()
        return rv.decode("utf-8-sig").replace("\r\n", "\n")
    finally:
        try:
            os.unlink(name)
        except OSError:
            pass


def launch(url, wait=False, locate=False):
    if locate:
        url = os.path.dirname(os.fspath(url)) or "."
    args = ["xdg-open", os.fspath(url)]
    try:
        return subprocess.call(args)
    except OSError:
        return 127
