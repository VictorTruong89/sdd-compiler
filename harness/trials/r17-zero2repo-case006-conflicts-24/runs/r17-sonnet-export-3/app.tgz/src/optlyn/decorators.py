"""Declaration decorators."""
from __future__ import annotations

import inspect
import sys
from functools import update_wrapper

from . import core
from .core import Argument, Command, Group, Option
from .exceptions import DeclarationError
from .globals import get_current_context
from .utils import echo

_ATTR = "__optlyn_params__"


def pass_context(f):
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return update_wrapper(new_func, f)


def pass_obj(f):
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return update_wrapper(new_func, f)


def make_pass_decorator(object_type, ensure=False):
    def decorator(f):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            obj = ctx.ensure_object(object_type) if ensure else ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(f"Managed to invoke callback without a context object of type "
                                   f"{object_type.__name__!r} existing.")
            return f(obj, *args, **kwargs)

        return update_wrapper(new_func, f)

    return decorator


def _param_memo(f, param):
    if isinstance(f, Command):
        f.params.append(param)
    else:
        if not hasattr(f, _ATTR):
            setattr(f, _ATTR, [])
        getattr(f, _ATTR).append(param)


def _make_command(f, name, attrs, cls):
    if isinstance(f, Command):
        raise TypeError("Attempted to convert a callback into a command twice.")
    attr_params = attrs.pop("params", None)
    params = list(attr_params) if attr_params is not None else []
    try:
        decorator_params = getattr(f, _ATTR)
    except AttributeError:
        pass
    else:
        delattr(f, _ATTR)
        params.extend(reversed(decorator_params))
    if attrs.get("help") is None:
        attrs["help"] = f.__doc__
    if name is None:
        name = f.__name__.lower()
        for suffix in ("_command", "_cmd", "_group", "_grp"):
            if name.endswith(suffix):
                name = name[: -len(suffix)]
                break
        name = name.replace("_", "-")
    cmd = cls(name=name, callback=f, params=params, **attrs)
    cmd.__doc__ = f.__doc__
    return cmd


def command(name=None, cls=None, **attrs):
    if cls is None:
        cls = Command
    if callable(name) and not isinstance(name, str):
        f, name = name, None
        return _make_command(f, None, attrs, cls)

    def decorator(f):
        return _make_command(f, name, dict(attrs), cls)

    return decorator


def group(name=None, cls=None, **attrs):
    if cls is None:
        cls = Group
    if callable(name) and not isinstance(name, str):
        f, name = name, None
        return _make_command(f, None, attrs, cls)

    def decorator(f):
        return _make_command(f, name, dict(attrs), cls)

    return decorator


def option(*param_decls, cls=None, **attrs):
    if cls is None:
        cls = Option

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f

    return decorator


def argument(*param_decls, cls=None, **attrs):
    if cls is None:
        cls = Argument

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f

    return decorator


def help_option(*param_decls, **kwargs):
    def show_help(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(ctx.get_help(), color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", show_help)
    return option(*param_decls, **kwargs)


def _detect_version(package_name):
    import importlib.metadata as md
    try:
        return md.version(package_name)
    except md.PackageNotFoundError:
        pass
    try:
        dists = md.packages_distributions().get(package_name.replace("-", "_"))
    except Exception:
        dists = None
    if dists:
        return md.version(dists[0])
    raise RuntimeError(f"{package_name!r} is not installed. Try passing 'package_name' instead.")


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    if message is None:
        message = "%(prog)s, version %(version)s"
    if version is None and package_name is None:
        frame = inspect.currentframe()
        f_back = frame.f_back if frame is not None else None
        f_globals = f_back.f_globals if f_back is not None else None
        del frame
        if f_globals is not None:
            package_name = f_globals.get("__name__")
            if package_name == "__main__":
                package_name = f_globals.get("__package__")
            if package_name:
                package_name = package_name.partition(".")[0]

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        prog = prog_name
        if prog is None:
            prog = ctx.find_root().info_name
        ver = version
        if ver is None:
            if package_name is None:
                raise RuntimeError("Could not determine the package to detect the version from.")
            ver = _detect_version(package_name)
        echo(message % {"prog": prog, "package": package_name, "version": ver}, color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*param_decls, **kwargs)


def custom_version_option(callback, *param_decls, **kwargs):
    def cb(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(callback(ctx), color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = cb
    return option(*param_decls, **kwargs)


def password_option(*param_decls, **kwargs):
    if not param_decls:
        param_decls = ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("hide_input", True)
    return option(*param_decls, **kwargs)


def confirmation_option(*param_decls, **kwargs):
    def callback(ctx, param, value):
        if not value:
            ctx.abort()

    if not param_decls:
        param_decls = ("--yes",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("callback", callback)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")
    return option(*param_decls, **kwargs)
