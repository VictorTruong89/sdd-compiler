"""Exception classes."""
from __future__ import annotations

import sys


class DeclarationError(ValueError, TypeError):
    """Raised at declaration time for an invalid keyword combination."""


class OptlynException(Exception):
    exit_code = 1

    def __init__(self, message=""):
        super().__init__(message)
        self.message = message

    def format_message(self):
        return self.message

    def show(self, file=None):
        from .utils import echo
        if file is None:
            file = sys.stderr
        echo(f"Error: {self.format_message()}", file=file)


class UsageError(OptlynException):
    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.ctx = ctx
        self.cmd = self.ctx.command if self.ctx else None

    def show(self, file=None):
        from .utils import echo
        if file is None:
            file = sys.stderr
        color = None
        hint = ""
        if self.ctx is not None and self.ctx.command.get_help_option(self.ctx) is not None:
            names = self.ctx.command.get_help_option_names(self.ctx)
            hint = f"Try '{self.ctx.command_path} {names[0]}' for help.\n"
        if self.ctx is not None:
            color = self.ctx.color
            echo(f"{self.ctx.get_usage()}\n{hint}", file=file, color=color)
        echo(f"Error: {self.format_message()}", file=file, color=color)


class NoArgsIsHelpError(UsageError):
    def __init__(self, ctx):
        super().__init__(ctx.get_help(), ctx=ctx)

    def show(self, file=None):
        from .utils import echo
        if file is None:
            file = sys.stderr
        echo(self.format_message(), file=file, color=self.ctx.color if self.ctx else None)


class BadParameter(UsageError):
    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        if self.param_hint is not None:
            hint = self.param_hint
            if not isinstance(hint, str):
                hint = " / ".join(repr(x) for x in hint)
        elif self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        else:
            return f"Invalid value: {self.message}"
        return f"Invalid value for {hint}: {self.message}"


class MissingParameter(BadParameter):
    def __init__(self, message=None, ctx=None, param=None, param_hint=None, param_type=None):
        super().__init__(message or "", ctx, param, param_hint)
        self.param_type = param_type

    def format_message(self):
        if self.param_hint is not None:
            hint = self.param_hint
            if not isinstance(hint, str):
                hint = " / ".join(repr(x) for x in hint)
        elif self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        else:
            hint = None
        ptype = self.param_type
        if ptype is None and self.param is not None:
            ptype = self.param.param_type_name
        msg = self.message
        if self.param is not None:
            extra = self.param.type.get_missing_message(self.param)
            if extra:
                msg = f"{msg} {extra}" if msg else extra
        out = f"Missing {ptype}" if ptype else "Missing parameter"
        if hint:
            out += f" {hint}"
        out += "."
        if msg:
            out += f" {msg}"
        return out


class NoSuchOption(UsageError):
    def __init__(self, option_name, message=None, possibilities=None, ctx=None):
        if message is None:
            message = f"No such option: {option_name}"
        super().__init__(message, ctx)
        self.option_name = option_name
        self.possibilities = possibilities

    def format_message(self):
        if not self.possibilities:
            return self.message
        poss = sorted(self.possibilities)
        if len(poss) == 1:
            return f"{self.message} Did you mean {poss[0]}?"
        return f"{self.message} (Possible options: {', '.join(poss)})"


class BadOptionUsage(UsageError):
    def __init__(self, option_name, message, ctx=None):
        super().__init__(message, ctx)
        self.option_name = option_name


class BadArgumentUsage(UsageError):
    pass


class FileError(OptlynException):
    def __init__(self, filename, hint=None):
        from .utils import format_filename
        if hint is None:
            hint = "unknown error"
        super().__init__(hint)
        self.ui_filename = format_filename(filename)
        self.filename = filename

    def format_message(self):
        return f"Could not open file {self.ui_filename!r}: {self.message}"


class Abort(RuntimeError):
    """Abort the program (exit status 1)."""


class Exit(RuntimeError):
    __slots__ = ("exit_code",)

    def __init__(self, code=0):
        self.exit_code = code
