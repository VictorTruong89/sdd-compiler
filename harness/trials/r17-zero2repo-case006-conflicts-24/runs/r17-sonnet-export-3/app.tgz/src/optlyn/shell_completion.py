"""Shell completion."""
from __future__ import annotations

import os
import re
import shlex

from .core import Argument, Group, Option, Parameter


class CompletionItem:
    __slots__ = ("value", "type", "help", "_info")

    def __init__(self, value, type="plain", help=None, **kwargs):
        self.value = value
        self.type = type
        self.help = help
        self._info = kwargs

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return self._info.get(name)


_SOURCE = {}

_SOURCE["bash"] = r"""%(complete_func)s() {
    local IFS=$'\n'
    local response

    response=$(env COMP_WORDS="${COMP_WORDS[*]}" COMP_CWORD=$COMP_CWORD %(complete_var)s=bash_complete $1)

    for completion in $response; do
        IFS=',' read type value <<< "$completion"

        if [[ $type == 'dir' ]]; then
            COMPREPLY=()
            compopt -o dirnames
        elif [[ $type == 'file' ]]; then
            COMPREPLY=()
            compopt -o default
        elif [[ $type == 'plain' ]]; then
            COMPREPLY+=($value)
        fi
    done

    return 0
}

%(complete_func)s_setup() {
    complete -o nosort -F %(complete_func)s %(prog_name)s
}

%(complete_func)s_setup;
"""

_SOURCE["zsh"] = r"""#compdef %(prog_name)s

%(complete_func)s() {
    local -a completions
    local -a completions_with_descriptions
    local -a response
    (( ! $+commands[%(prog_name)s] )) && return 1

    response=("${(@f)$(env COMP_WORDS="${words[*]}" COMP_CWORD=$((CURRENT-1)) %(complete_var)s=zsh_complete %(prog_name)s)}")

    for type key descr in ${response}; do
        if [[ "$type" == "plain" ]]; then
            if [[ "$descr" == "_" ]]; then
                completions+=("$key")
            else
                completions_with_descriptions+=("$key":"$descr")
            fi
        elif [[ "$type" == "dir" ]]; then
            _path_files -/
        elif [[ "$type" == "file" ]]; then
            _path_files -f
        fi
    done

    if [ -n "$completions_with_descriptions" ]; then
        _describe -V unsorted completions_with_descriptions -U
    fi

    if [ -n "$completions" ]; then
        compadd -U -V unsorted -a completions
    fi
}

if [[ $zsh_eval_context[-1] == loadautofunc ]]; then
    %(complete_func)s "$@"
else
    compdef %(complete_func)s %(prog_name)s
fi
"""

_SOURCE["fish"] = r"""function %(complete_func)s;
    set -l response (env %(complete_var)s=fish_complete COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -t) %(prog_name)s);

    for completion in $response;
        set -l metadata (string split "," $completion);

        if test $metadata[1] = "dir";
            __fish_complete_directories $metadata[2];
        else if test $metadata[1] = "file";
            __fish_complete_path $metadata[2];
        else if test $metadata[1] = "plain";
            echo $metadata[2];
        end;
    end;
end;

complete --no-files --command %(prog_name)s --arguments "(%(complete_func)s)";
"""

_SOURCE["powershell"] = r"""Register-ArgumentCompleter -Native -CommandName %(prog_name)s -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)
    $env:COMP_WORDS = $commandAst
    $env:COMP_WORDS = $env:COMP_WORDS.replace('\\', '/')
    $incompleteCommand = $commandAst.ToString()
    $myCursorPosition = $cursorPosition
    if ($myCursorPosition -gt $incompleteCommand.Length) {
        $myCursorPosition = $incompleteCommand.Length
    }
    $env:COMP_CWORD = @($incompleteCommand.substring(0, $myCursorPosition).Split(" ") | Where-Object { $_ -ne "" }).Count
    if ($wordToComplete.Length -gt 0) { $env:COMP_CWORD = $env:COMP_CWORD - 1 }
    $env:%(complete_var)s = "powershell_complete"
    %(prog_name)s | ForEach-Object {
        $type, $value, $help = $_.Split(",", 3)
        [System.Management.Automation.CompletionResult]::new($value, $value, "ParameterValue", $value)
    }
    $env:%(complete_var)s = ""
}
"""


def split_arg_string(string):
    lex = shlex.shlex(string, posix=True)
    lex.whitespace_split = True
    lex.commenters = ""
    out = []
    try:
        for token in lex:
            out.append(token)
    except ValueError:
        out.extend(lex.token.split() if lex.token else [])
    return out


class ShellComplete:
    name = ""

    def __init__(self, cli, ctx_args, prog_name, complete_var):
        self.cli = cli
        self.ctx_args = ctx_args
        self.prog_name = prog_name
        self.complete_var = complete_var

    @property
    def func_name(self):
        safe = re.sub(r"\W*", "", self.prog_name.replace("-", "_"), flags=re.ASCII)
        return f"_{safe}_completion"

    def source(self):
        return _SOURCE[self.name] % {
            "complete_func": self.func_name,
            "complete_var": self.complete_var,
            "prog_name": self.prog_name,
        }

    def get_completion_args(self):
        raise NotImplementedError

    def get_completions(self, args, incomplete):
        ctx = _resolve_context(self.cli, dict(self.ctx_args), self.prog_name, args)
        obj, incomplete = _resolve_incomplete(ctx, args, incomplete)
        return obj.shell_complete(ctx, incomplete)

    def format_completion(self, item):
        raise NotImplementedError

    def complete(self):
        args, incomplete = self.get_completion_args()
        completions = self.get_completions(args, incomplete)
        return "\n".join(self.format_completion(item) for item in completions)


class BashComplete(ShellComplete):
    name = "bash"

    def get_completion_args(self):
        cwords = split_arg_string(os.environ.get("COMP_WORDS", ""))
        cword = int(os.environ.get("COMP_CWORD", len(cwords)))
        args = cwords[1:cword]
        try:
            incomplete = cwords[cword]
        except IndexError:
            incomplete = ""
        return args, incomplete

    def format_completion(self, item):
        return f"{item.type},{item.value}"


class ZshComplete(BashComplete):
    name = "zsh"

    def format_completion(self, item):
        return f"{item.type}\n{item.value}\n{item.help if item.help else '_'}"


class PowerShellComplete(BashComplete):
    name = "powershell"


class FishComplete(ShellComplete):
    name = "fish"

    def get_completion_args(self):
        cwords = split_arg_string(os.environ.get("COMP_WORDS", ""))
        incomplete = os.environ.get("COMP_CWORD", "")
        args = cwords[1:]
        if incomplete and args and args[-1] == incomplete:
            args.pop()
        return args, incomplete

    def format_completion(self, item):
        if item.help:
            return f"{item.type},{item.value}\t{item.help}"
        return f"{item.type},{item.value}"


_REGISTRY = {"bash": BashComplete, "zsh": ZshComplete, "fish": FishComplete,
             "powershell": PowerShellComplete}


def shell_complete(cli, ctx_args, prog_name, complete_var, instruction):
    from .utils import echo
    shell, _, instr = instruction.partition("_")
    cls = _REGISTRY.get(shell)
    if cls is None:
        return 1
    comp = cls(cli, ctx_args, prog_name, complete_var)
    if instr == "source":
        echo(comp.source())
        return 0
    if instr == "complete":
        echo(comp.complete())
        return 0
    return 1


def _is_incomplete_argument(current_params, param):
    if not isinstance(param, Argument):
        return False
    value = current_params.get(param.name)
    if value is None:
        return True
    if param.nargs == -1:
        return True
    if isinstance(value, (list, tuple)) and param.nargs != 1 and len(value) < param.nargs:
        return True
    return False


def _start_of_option(ctx, value):
    if not value:
        return False
    return value[0] in (ctx._opt_prefixes | {"-"}) and len(value) > 1 or value.startswith("-")


def _is_incomplete_option(ctx, args, param):
    if not isinstance(param, Option):
        return False
    if param.is_flag or param.count:
        return False
    last_option = None
    for index, arg in enumerate(reversed(args)):
        if index + 1 > param.nargs:
            break
        if _start_of_option(ctx, arg):
            last_option = arg
    return last_option is not None and last_option in param.opts


def _resolve_context(cli, ctx_args, prog_name, args):
    ctx_args["resilient_parsing"] = True
    ctx = cli.make_context(prog_name, list(args), **ctx_args)
    args = ctx.protected_args + ctx.args
    while args:
        command = ctx.command
        if isinstance(command, Group):
            if not command.chain:
                name, cmd, args = command.resolve_command(ctx, args)
                if cmd is None:
                    return ctx
                ctx = cmd.make_context(name, args, parent=ctx, resilient_parsing=True)
                args = ctx.protected_args + ctx.args
            else:
                sub_ctx = ctx
                while args:
                    name, cmd, args = command.resolve_command(ctx, args)
                    if cmd is None:
                        return ctx
                    sub_ctx = cmd.make_context(name, args, parent=ctx, allow_extra_args=True,
                                               allow_interspersed_args=False, resilient_parsing=True)
                    args = sub_ctx.args
                ctx = sub_ctx
                args = [*sub_ctx.protected_args, *sub_ctx.args]
        else:
            break
    return ctx


def _resolve_incomplete(ctx, args, incomplete):
    if "=" in incomplete and incomplete[:1] in ("-", "+", "/"):
        pass
    for param in ctx.command.get_params(ctx):
        if _is_incomplete_option(ctx, args, param):
            return param, incomplete
    for param in ctx.command.get_params(ctx):
        if _is_incomplete_argument(ctx.params, param) and not incomplete[:1] in ("-",):
            return param, incomplete
    return ctx.command, incomplete
