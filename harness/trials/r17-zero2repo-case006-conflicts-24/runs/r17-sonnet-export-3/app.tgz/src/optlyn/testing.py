"""In-process runner."""
from __future__ import annotations

import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile

from . import _compat, formatting, termui


class _Sink(io.BytesIO):
    """Captures bytes for one stream and mirrors them into a shared buffer."""

    def __init__(self, shared, fileno=None):
        super().__init__()
        self._shared = shared
        self._fileno = fileno

    def write(self, b):
        n = super().write(b)
        self._shared.write(bytes(b))
        return n

    def fileno(self):
        if self._fileno is None:
            raise io.UnsupportedOperation("fileno")
        return self._fileno


class _EchoingStdin:
    def __init__(self, input, output):
        self._input = input
        self._output = output

    def __getattr__(self, x):
        return getattr(self._input, x)

    def _echo(self, rv):
        self._output.write(rv)
        return rv

    def read(self, n=-1):
        return self._echo(self._input.read(n))

    def readline(self, n=-1):
        return self._echo(self._input.readline(n))

    def readlines(self):
        return [self._echo(x) for x in self._input.readlines()]

    def __iter__(self):
        return iter(self._echo(x) for x in self._input)


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value, exit_code,
                 exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    def _dec(self, b):
        return b.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def output(self):
        return self._dec(self.output_bytes)

    @property
    def stdout(self):
        return self._dec(self.stdout_bytes)

    @property
    def stderr(self):
        return self._dec(self.stderr_bytes)

    def __repr__(self):
        name = type(self.exception).__name__ if self.exception else "okay"
        return f"<Result {name}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        self.charset = charset
        self.env = dict(env) if env else {}
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def make_env(self, overrides=None):
        rv = dict(self.env)
        if overrides:
            rv.update(overrides)
        return rv

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        else:
            data = bytes(input)
        env = self.make_env(env)
        fd_mode = self.capture == "fd"

        shared = io.BytesIO()
        out_sink = _Sink(shared, 1 if fd_mode else None)
        err_sink = _Sink(shared, 2 if fd_mode else None)
        stdout = io.TextIOWrapper(out_sink, encoding=self.charset, write_through=True,
                                  errors="backslashreplace")
        stderr = io.TextIOWrapper(err_sink, encoding=self.charset, write_through=True,
                                  errors="backslashreplace")
        out_sink._keep = stdout
        err_sink._keep = stderr
        in_buf = io.BytesIO(data)
        text_in = io.TextIOWrapper(in_buf, encoding=self.charset)
        stdin = _EchoingStdin(text_in, shared) if False else text_in
        if self.echo_stdin:
            stdin = _EchoingTextStdin(in_buf, text_in, out_sink, shared, self.charset)

        old = (sys.stdin, sys.stdout, sys.stderr)
        old_vis, old_hid, old_getchar = termui.visible_prompt_func, termui.hidden_prompt_func, termui._getchar
        old_strip = _compat.should_strip_ansi
        old_width = formatting.FORCED_WIDTH
        formatting.FORCED_WIDTH = 80
        echo_in = self.echo_stdin

        def visible_input(prompt=None):
            sys.stdout.write(prompt or "")
            val = sys.stdin.readline()
            if val == "":
                raise EOFError()
            val = val.rstrip("\r\n")
            if not echo_in:
                sys.stdout.write(f"{val}\n")
            sys.stdout.flush()
            return val

        def hidden_input(prompt=None):
            sys.stdout.write(f"{prompt or ''}\n")
            sys.stdout.flush()
            val = sys.stdin.readline()
            if val == "":
                raise EOFError()
            return val.rstrip("\r\n")

        def _getchar(echo):
            char = sys.stdin.read(1)
            if char == "":
                raise EOFError()
            if echo:
                sys.stdout.write(char)
            sys.stdout.flush()
            return char

        def should_strip_ansi(stream=None, color_=None):
            if color_ is None:
                return not color
            return not color_

        old_env = {}
        saved_fds = None
        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
        termui.visible_prompt_func = visible_input
        termui.hidden_prompt_func = hidden_input
        termui._getchar = _getchar
        _compat.should_strip_ansi = should_strip_ansi
        fd_files = None
        try:
            for key, value in env.items():
                old_env[key] = os.environ.get(key)
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            if fd_mode:
                try:
                    old[1].flush()
                    old[2].flush()
                except Exception:
                    pass
                fd_files = (tempfile.TemporaryFile(), tempfile.TemporaryFile())
                saved_fds = (os.dup(1), os.dup(2))
                os.dup2(fd_files[0].fileno(), 1)
                os.dup2(fd_files[1].fileno(), 2)
            try:
                yield (out_sink, err_sink, shared)
            finally:
                if fd_mode:
                    os.dup2(saved_fds[0], 1)
                    os.dup2(saved_fds[1], 2)
                    os.close(saved_fds[0])
                    os.close(saved_fds[1])
                    for sink, f in zip((out_sink, err_sink), fd_files):
                        f.seek(0)
                        sink.write(f.read())
                        f.close()
        finally:
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            sys.stdin, sys.stdout, sys.stderr = old
            termui.visible_prompt_func = old_vis
            termui.hidden_prompt_func = old_hid
            termui._getchar = old_getchar
            _compat.should_strip_ansi = old_strip
            formatting.FORCED_WIDTH = old_width

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        exc_info = None
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        return_value = None
        exception = None
        exit_code = 0
        with self.isolation(input=input, env=env, color=color) as (out_sink, err_sink, shared):
            if isinstance(args, str):
                args = shlex.split(args)
            prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
            try:
                return_value = cli.main(args=args or [], prog_name=prog_name, **extra)
            except SystemExit as e:
                exc_info = sys.exc_info()
                e_code = e.code
                if e_code is None:
                    e_code = 0
                if e_code != 0:
                    exception = e
                if not isinstance(e_code, int):
                    sys.stdout.write(str(e_code))
                    sys.stdout.write("\n")
                    e_code = 1
                exit_code = e_code
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                try:
                    sys.stdout.flush()
                    sys.stderr.flush()
                except Exception:
                    pass
        # sinks stay readable after isolation ends (fd data merged on exit)
        return Result(self, out_sink.getvalue(), err_sink.getvalue(), shared.getvalue(), return_value,
                      exit_code, exception, exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass


class _EchoingTextStdin:
    """Text stdin that echoes exactly what was read into the captured output."""

    def __init__(self, buf, text, out_sink, shared, charset):
        self._text = text
        self._out = out_sink
        self._charset = charset

    def _echo(self, s):
        if s:
            self._out.write(s.encode(self._charset))
        return s

    def read(self, n=-1):
        return self._echo(self._text.read(n))

    def readline(self, n=-1):
        return self._echo(self._text.readline(n))

    def readlines(self):
        return [self._echo(x) for x in self._text.readlines()]

    def __iter__(self):
        return iter(self.readline, "")

    def __getattr__(self, name):
        return getattr(self._text, name)
