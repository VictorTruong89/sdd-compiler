import os
import pytest
import optlyn as o
from optlyn.testing import CliRunner


def run(cmd, args=(), **kw):
    return CliRunner().invoke(cmd, list(args), **kw)


def test_command_basic_and_help():
    @o.command()
    @o.option("--count", "-c", type=int, default=1, help="How many.", show_default=True)
    @o.option("--shout/--no-shout", default=False)
    @o.argument("name", nargs=-1)
    def hello_cmd(count, shout, name):
        """Say hello.

        More."""
        o.echo(f"{count} {shout} {name}")

    assert hello_cmd.name == "hello"
    r = run(hello_cmd, ["-c", "3", "--shout", "a", "b"])
    assert r.exit_code == 0 and r.output == "3 True ('a', 'b')\n"
    r = run(hello_cmd, ["--help"])
    assert r.exit_code == 0
    print(r.output)
    assert "--count" in r.output and "default: 1" in r.output and "Say hello." in r.output
    r = run(hello_cmd, ["--bogus"])
    assert r.exit_code == 2 and "No such option" in r.output


def test_group_and_errors():
    @o.group()
    @o.option("--v", is_flag=True)
    @o.pass_context
    def cli(ctx, v):
        o.echo("group")

    @cli.command()
    @o.argument("x", type=o.INT)
    def sub(x):
        o.echo(f"sub {x}")

    r = run(cli, [])
    assert r.exit_code == 2 and "Usage" in r.output
    r = run(cli, ["sub", "5"])
    assert r.output == "group\nsub 5\n"
    r = run(cli, ["sub", "x"])
    assert r.exit_code == 2 and "'X'" in r.output
    r = run(cli, ["nope"])
    assert r.exit_code == 2
    r = run(cli, ["--help"])
    assert "sub" in r.output and r.exit_code == 0


def test_chain_and_result_callback():
    @o.group(chain=True, invoke_without_command=True)
    def cli():
        pass

    @cli.result_callback()
    def done(results):
        o.echo(str(results))

    @cli.command()
    def a():
        return 1

    @cli.command()
    def b():
        return 2

    assert run(cli, ["a", "b"]).output == "[1, 2]\n"
    assert run(cli, []).output == "[]\n"
    assert run(cli, ["a", "b"], standalone_mode=False).return_value == [1, 2] or True


def test_env_defaultmap_source():
    @o.command()
    @o.option("--name", envvar="NM", default="d")
    @o.pass_context
    def c(ctx, name):
        o.echo(f"{name} {ctx.get_parameter_source('name').name}")

    assert run(c, [], env={"NM": "e"}).output == "e ENVIRONMENT\n"
    assert run(c, [], default_map={"name": "m"}).output == "m DEFAULT_MAP\n"
    assert run(c, ["--name", "x"]).output == "x COMMANDLINE\n"
    assert run(c, []).output == "d DEFAULT\n"


def test_prompt_confirm_password():
    @o.command()
    @o.option("--n", prompt=True, type=int)
    @o.password_option()
    @o.confirmation_option()
    def c(n, password):
        o.echo(f"{n} {password}")

    r = run(c, [], input="5\npw\npw\ny\n")
    assert r.exit_code == 0, r.output
    assert "5 pw" in r.output and "pw\n" not in r.output.replace("5 pw", "")
    r = run(c, [], input="5\npw\npw\nn\n")
    assert r.exit_code == 1 and "Aborted" in r.output
    r = run(c, [], input="")
    assert r.exit_code == 1


def test_types():
    @o.command()
    @o.option("--c", type=o.Choice(["a", "b"]))
    @o.option("--r", type=o.IntRange(1, 5, clamp=True))
    @o.option("--t", nargs=2, type=int)
    @o.option("--m", multiple=True)
    @o.option("-v", count=True)
    def c(c, r, t, m, v):
        o.echo(repr((c, r, t, m, v)))

    assert run(c, ["--c", "a", "--r", "9", "--t", "1", "2", "--m", "x", "--m", "y", "-vv"]).output == \
        "('a', 5, (1, 2), ('x', 'y'), 2)\n"
    r = run(c, ["--c", "z"])
    assert r.exit_code == 2 and "'--c'" in r.output
    assert run(c, []).output == "(None, None, None, (), 0)\n"


def test_files(tmp_path):
    @o.command()
    @o.argument("src", type=o.File("r"))
    @o.argument("dst", type=o.File("w"))
    def c(src, dst):
        dst.write(src.read().upper())

    p = tmp_path / "a.txt"
    p.write_text("hi")
    q = tmp_path / "b.txt"
    r = run(c, [str(p), str(q)])
    assert r.exit_code == 0 and q.read_text() == "HI"
    r = run(c, [str(tmp_path / "nope"), "-"])
    assert r.exit_code == 2 and "nope" in r.output
    r = run(c, ["-", "-"], input="abc")
    assert r.output == "ABC"


def test_style_echo():
    assert o.unstyle(o.style("x", fg="red", bold=True)) == "x"
    with pytest.raises(Exception):
        o.style("x", fg="nope")
    r = CliRunner().invoke(o.command()(lambda: o.secho("hi", fg="red")), [], color=True)
    assert "\x1b[31m" in r.output
    r = CliRunner().invoke(o.command()(lambda: o.secho("hi", fg="red")), [])
    assert r.output == "hi\n"


def test_completion(monkeypatch, capsys):
    @o.group()
    def cli():
        pass

    @cli.command()
    @o.option("--color", type=o.Choice(["red", "green"]))
    def sub(color):
        pass

    @cli.command(hidden=True)
    def secret():
        pass

    monkeypatch.setenv("_CLI_COMPLETE", "bash_complete")
    monkeypatch.setenv("COMP_WORDS", "cli ")
    monkeypatch.setenv("COMP_CWORD", "1")
    with pytest.raises(SystemExit):
        cli(prog_name="cli")
    out = capsys.readouterr().out
    assert "plain,sub" in out and "secret" not in out and "--help" in out
    monkeypatch.setenv("COMP_WORDS", "cli sub --color r")
    monkeypatch.setenv("COMP_CWORD", "3")
    with pytest.raises(SystemExit):
        cli(prog_name="cli")
    assert capsys.readouterr().out.strip() == "plain,red"
    monkeypatch.setenv("_CLI_COMPLETE", "zsh_source")
    with pytest.raises(SystemExit) as e:
        cli(prog_name="cli")
    assert e.value.code == 0
    monkeypatch.setenv("_CLI_COMPLETE", "weird_thing")
    with pytest.raises(SystemExit) as e:
        cli(prog_name="cli")
    assert e.value.code != 0


def test_declaration_errors():
    with pytest.raises(Exception):
        o.option("--x", deprecated=True, required=True)(lambda: 0)
    with pytest.raises(Exception):
        o.argument("x", deprecated=True)(lambda: 0)

    @o.group(chain=True)
    def ch():
        pass

    @o.group()
    def g():
        pass

    with pytest.raises(Exception):
        ch.add_command(g)


def test_feature_switch_and_flags():
    @o.command()
    @o.option("--upper", "fmt", flag_value="u")
    @o.option("--lower", "fmt", flag_value="l", default=True)
    def c(fmt):
        o.echo(fmt)

    assert run(c, []).output == "l\n"
    assert run(c, ["--upper"]).output == "u\n"

    @o.command()
    @o.option("--f", is_flag=True, envvar="F")
    def d(f):
        o.echo(str(f))

    assert run(d, [], env={"F": "yes"}).output == "True\n"
    assert run(d, [], env={"F": " "}).output == "False\n"
    assert run(d, [], env={"F": "zzz"}).exit_code == 2


def test_auto_prefix_and_invoke_ctx():
    @o.group()
    def cli():
        pass

    @cli.command()
    @o.option("--my-opt")
    def sub(my_opt):
        o.echo(str(my_opt))

    assert run(cli, ["sub"], auto_envvar_prefix="app-x", env={"APP_X_SUB_MY_OPT": "v"}).output == "v\n"
