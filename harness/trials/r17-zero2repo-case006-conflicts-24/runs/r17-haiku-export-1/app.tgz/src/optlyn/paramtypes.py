"""Parameter types: built-in conversions and the base class for custom types."""

import datetime as _dt
import enum
import os
import pathlib
import stat
import uuid

from .exceptions import BadParameter, DeclarationError
from .utils import open_file

TRUE_VALUES = frozenset({"1", "true", "t", "yes", "y", "on"})
FALSE_VALUES = frozenset({"0", "false", "f", "no", "n", "off"})


class CompletionItem:
    """A suggestion for shell completion. ``type`` is ``"plain"`` for an ordinary value."""

    def __init__(self, value, help=None, type="plain"):
        self.value = str(value)
        self.help = help
        self.type = type

    def __repr__(self):
        return f"CompletionItem({self.value!r}, help={self.help!r}, type={self.type!r})"


# spec: N-000949
class ParamType:
    """Base class for parameter types.

    A subclass sets ``name`` and implements ``convert(value, param, ctx)``, which refuses a value by
    raising ``BadParameter``.
    """

    name = "text"
    envvar_list_splitter = None

    def convert(self, value, param=None, ctx=None):
        return value

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def get_metavar(self, param=None):
        return None

    def shell_complete(self, ctx, param, incomplete):
        return []

    def split_envvar_value(self, rv):
        return rv.split()

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, str):
            return value
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        return str(value)


class _IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, int) and not isinstance(value, bool):
            return value
        try:
            return int(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class _FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        try:
            return float(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid float.", param, ctx)


class _BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in TRUE_VALUES:
            return True
        if text in FALSE_VALUES:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class _UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID value.", param, ctx)


class _UnprocessedParamType(ParamType):
    name = "text"


STRING = StringParamType()
INT = _IntParamType()
FLOAT = _FloatParamType()
BOOL = _BoolParamType()
UUID = _UUIDParamType()
UNPROCESSED = _UnprocessedParamType()


def _normalize(value, ctx):
    func = getattr(ctx, "token_normalize_func", None) if ctx is not None else None
    return func(value) if func is not None else value


# spec: N-000937
class Choice(ParamType):
    """A closed list of allowed values, or the member names of an enumeration."""

    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        self.case_sensitive = case_sensitive
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self._enum = choices
            self.choices = list(choices)
            self._names = [m.name for m in choices]
        else:
            self._enum = None
            self.choices = list(choices)
            self._names = [str(c) for c in self.choices]

    def _key(self, text, ctx):
        text = _normalize(str(text), ctx)
        return text if self.case_sensitive else text.casefold()

    def convert(self, value, param=None, ctx=None):
        if self._enum is not None:
            if isinstance(value, self._enum):
                return value
            for member in self.choices:
                if self._key(member.name, ctx) == self._key(value, ctx):
                    return member
        else:
            for choice in self.choices:
                if self._key(choice, ctx) == self._key(value, ctx):
                    return choice
        shown = ", ".join(repr(n) for n in self._names)
        self.fail(f"{value!r} is not one of {shown}.", param, ctx)

    def get_metavar(self, param=None):
        return "[" + "|".join(self._names) + "]"

    def shell_complete(self, ctx, param, incomplete):
        return [
            CompletionItem(name) for name in self._names
            if self._key(name, ctx).startswith(self._key(incomplete, ctx))
        ]


_DEFAULT_DATETIME_FORMATS = ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S")


# spec: N-000938 N-000939 N-000940
class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(_DEFAULT_DATETIME_FORMATS)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        text = str(value).strip()
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(text, fmt)
            except ValueError:
                continue
        shown = ", ".join(repr(f) for f in self.formats)
        self.fail(f"{value!r} does not match the formats {shown}.", param, ctx)

    def get_metavar(self, param=None):
        return "[" + "|".join(self.formats) + "]"


# spec: N-000941
class IntRange(_IntParamType):
    """An integer that must lie in an optional range; ``clamp`` replaces out-of-range values."""

    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        rv = super().convert(value, param, ctx)
        if self.min is not None and (rv < self.min or (self.min_open and rv == self.min)):
            if self.clamp:
                rv = self.min + 1 if self.min_open else self.min
            else:
                self.fail(f"{rv} is not in the range {self._describe()}.", param, ctx)
        if self.max is not None and (rv > self.max or (self.max_open and rv == self.max)):
            if self.clamp:
                rv = self.max - 1 if self.max_open else self.max
            else:
                self.fail(f"{rv} is not in the range {self._describe()}.", param, ctx)
        return rv

    def _describe(self):
        lo = "" if self.min is None else f"{self.min}{'<' if self.min_open else '<='}"
        hi = "" if self.max is None else f"{'<' if self.max_open else '<='}{self.max}"
        return f"{lo}x{hi}" if lo or hi else "x"

    def get_metavar(self, param=None):
        return "INTEGER RANGE"


# spec: N-000942 N-000943
class FloatRange(_FloatParamType):
    """A float that must lie in an optional range. Clamping needs both bounds closed."""

    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min_open or max_open):
            raise DeclarationError("FloatRange cannot clamp when a bound is open.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        rv = super().convert(value, param, ctx)
        if self.min is not None and (rv < self.min or (self.min_open and rv == self.min)):
            if self.clamp:
                rv = float(self.min)
            else:
                self.fail(f"{rv} is not in the range {self._describe()}.", param, ctx)
        if self.max is not None and (rv > self.max or (self.max_open and rv == self.max)):
            if self.clamp:
                rv = float(self.max)
            else:
                self.fail(f"{rv} is not in the range {self._describe()}.", param, ctx)
        return rv

    def _describe(self):
        lo = "" if self.min is None else f"{self.min}{'<' if self.min_open else '<='}"
        hi = "" if self.max is None else f"{'<' if self.max_open else '<='}{self.max}"
        return f"{lo}x{hi}" if lo or hi else "x"

    def get_metavar(self, param=None):
        return "FLOAT RANGE"


# spec: N-000944
class Tuple(ParamType):
    """A fixed-length product of inner types, one converted value per position."""

    name = "tuple"

    def __init__(self, types):
        self.types = [resolve_type(t) for t in types]

    def convert(self, value, param=None, ctx=None):
        values = list(value)
        if len(values) != len(self.types):
            self.fail(f"Expected {len(self.types)} values, got {len(values)}.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, values))

    def get_metavar(self, param=None):
        return " ".join(t.get_metavar(param) or t.name.upper() for t in self.types)


# spec: N-000945
class File(ParamType):
    """An open file. ``-`` is the standard input for reading and standard output for writing."""

    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise DeclarationError(f"Unsupported file mode {mode!r}.")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        writing = "w" in self.mode
        lazy = self.lazy if self.lazy is not None else writing
        try:
            f = open_file(
                value,
                self.mode,
                self.encoding,
                self.errors,
                lazy=lazy,
                atomic=self.atomic,
            )
        except OSError as e:
            self.fail(f"'{value}' could not be opened: {e.strerror}.", param, ctx)
        if ctx is not None and value != "-":
            ctx.call_on_close(f.close)
        return f

    def split_envvar_value(self, rv):
        return rv.split(os.pathsep)

    def get_metavar(self, param=None):
        return "FILENAME"

    def shell_complete(self, ctx, param, incomplete):
        return [CompletionItem(incomplete, type="file")]


# spec: N-000946 N-000947 N-000948
class Path(ParamType):
    """A filesystem path, checked against the requested properties. Delivers a path, not a file."""

    name = "path"

    def __init__(self, exists=False, file_okay=True, dir_okay=True, writable=False, readable=True,
                 resolve_path=False, allow_dash=False, path_type=None, executable=False):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def convert(self, value, param=None, ctx=None):
        text = os.fspath(value) if hasattr(value, "__fspath__") else value
        if isinstance(text, bytes):
            text = os.fsdecode(text)
        if text == "-" and self.allow_dash:
            return self._result("-")
        rv = os.path.realpath(text) if self.resolve_path else text
        try:
            st = os.stat(rv)
        except OSError:
            st = None
        if st is None:
            if self.exists:
                self.fail(f"'{text}' does not exist.", param, ctx)
        else:
            if not self.file_okay and stat.S_ISREG(st.st_mode):
                self.fail(f"'{text}' is a file.", param, ctx)
            if not self.dir_okay and stat.S_ISDIR(st.st_mode):
                self.fail(f"'{text}' is a directory.", param, ctx)
            if self.readable and not os.access(rv, os.R_OK):
                self.fail(f"'{text}' is not readable.", param, ctx)
            if self.writable and not os.access(rv, os.W_OK):
                self.fail(f"'{text}' is not writable.", param, ctx)
            if self.executable and not os.access(rv, os.X_OK):
                self.fail(f"'{text}' is not executable.", param, ctx)
        return self._result(rv)

    def _result(self, rv):
        if self.path_type is pathlib.Path:
            return pathlib.Path(rv)
        return rv

    def split_envvar_value(self, rv):
        return rv.split(os.pathsep)

    def get_metavar(self, param=None):
        return "PATH"

    def shell_complete(self, ctx, param, incomplete):
        kind = "file" if self.file_okay else "dir"
        return [CompletionItem(incomplete, type=kind)]


class FuncParamType(ParamType):
    """Adapts a conversion function ``f(token) -> value`` that refuses by raising ValueError."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text") or "text"

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except ValueError as e:
            self.fail(str(e) or f"{value!r} is not a valid value.", param, ctx)


_BUILTIN_TYPES = {str: STRING, int: INT, float: FLOAT, bool: BOOL}


def resolve_type(ty, default=None):
    """Turn a ``type=`` keyword (or a default, when there is no keyword) into a ParamType."""
    if ty is None:
        if isinstance(default, bool):
            return BOOL
        if isinstance(default, int):
            return INT
        if isinstance(default, float):
            return FLOAT
        if isinstance(default, (list, tuple)) and default:
            return resolve_type(None, default[0])
        return STRING
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, type) and ty in _BUILTIN_TYPES:
        return _BUILTIN_TYPES[ty]
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    if callable(ty):
        return FuncParamType(ty)
    raise DeclarationError(f"Unsupported parameter type: {ty!r}.")
