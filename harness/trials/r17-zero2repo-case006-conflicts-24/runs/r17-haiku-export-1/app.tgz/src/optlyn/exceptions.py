"""Exceptions Optlyn raises, and how standalone mode reports them."""


class OptlynError(Exception):
    """An error Optlyn reports to the user that is not a usage error.

    In standalone mode it is shown on standard error and the process exits with status 1.
    """

    exit_code = 1

    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def format_message(self):
        return self.message

    def show(self):
        from .termui import echo

        echo(f"Error: {self.format_message()}", err=True)


# spec: N-000819
class FileError(OptlynError):
    """A file could not be opened at first I/O (general error, not a usage error)."""

    def __init__(self, filename, hint=None):
        super().__init__(f"Could not open file '{filename}'" + (f": {hint}" if hint else "."))
        self.filename = filename


# spec: N-000804
class UsageError(OptlynError):
    """Incorrect command line usage. Standalone exit status is 2."""

    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.ctx = ctx

    def show(self):
        from .termui import echo

        if self.ctx is not None:
            echo(self.ctx.get_usage(), err=True)
            echo(
                f"Try '{self.ctx.command_path} {self.ctx.help_option_names[0]}' for help.",
                err=True,
            )
        echo(f"Error: {self.format_message()}", err=True)


class BadParameter(UsageError):
    """A value was refused: conversion failed or a parameter callback refused it."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        if self.param_hint is not None:
            hint = self.param_hint
        elif self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        else:
            return f"Invalid value: {self.message}"
        return f"Invalid value for {hint}: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter received no value."""

    def __init__(self, message=None, ctx=None, param=None):
        super().__init__(message or "", ctx=ctx, param=param)

    def format_message(self):
        if self.param is None:
            return self.message or "Missing parameter."
        kind = "option" if self.param.kind == "option" else "argument"
        return f"Missing {kind} {self.param.get_error_hint(self.ctx)}."


class NoSuchOption(UsageError):
    """An option token matches no declared option."""

    def __init__(self, option_name, message=None, ctx=None):
        super().__init__(message or f"No such option: {option_name}", ctx)
        self.option_name = option_name


class BadOptionUsage(UsageError):
    """An option was used incorrectly (for example it is missing its value)."""


class BadArgumentUsage(UsageError):
    """An argument was used incorrectly."""


class NoArgsIsHelpError(UsageError):
    """A group or command was run with no arguments and shows help as a usage failure.

    The help page goes to standard error and the exit status is 2.
    """

    def __init__(self, ctx):
        super().__init__("No arguments given.", ctx)

    def show(self):
        from .termui import echo

        echo(self.ctx.get_help(), err=True)


class DeclarationError(TypeError, ValueError):
    """An invalid combination of declaration keywords, refused when declared."""


# spec: N-000805
class Abort(RuntimeError):
    """The user or the author aborted the run. Standalone exit status is 1."""


# spec: N-000803 N-000806
class Exit(RuntimeError):
    """An author clean stop, or intentional help/version. Carries the exit status."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code
