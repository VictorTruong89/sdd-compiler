"""Commands, groups, parameters, invocation contexts, parsing and help pages."""

import contextlib
import enum
import os
import re
import shutil
import sys

from . import paramtypes as pt
from ._state import get_current_context, pop_context, push_context
from .exceptions import (
    Abort,
    OptlynError,
    BadArgumentUsage,
    BadOptionUsage,
    BadParameter,
    DeclarationError,
    Exit,
    MissingParameter,
    NoArgsIsHelpError,
    NoSuchOption,
    UsageError,
)
from .formatting import format_dl, wrap_text
from .termui import confirm, echo, _prompt_loop

DEFAULT_MAX_CONTENT_WIDTH = 80
SHORT_HELP_LIMIT = 45

_IDENT_PREFIX = re.compile(r"^[^A-Za-z0-9_]+")


# spec: N-000969
class ParameterSource(enum.Enum):
    """Where a parameter's value came from."""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


class _ChainMarker:
    """``invoked_subcommand`` value on a chaining group: neither None nor a child's name."""

    def __repr__(self):
        return "<chain>"


CHAIN_SUBCOMMAND = _ChainMarker()


class _Literal:
    """A parsed occurrence whose value is already known (a flag, a counted flag)."""

    __slots__ = ("value",)

    def __init__(self, value):
        self.value = value


class _PromptMarker:
    def __repr__(self):
        return "<prompt>"


_PROMPT = _PromptMarker()
_UNSET = object()


def _is_prefixed(decl):
    return bool(decl) and not decl[0].isalnum() and decl[0] != "_"


def _strip_prefix(name):
    return _IDENT_PREFIX.sub("", name)


def _wrap_width(ctx):
    if ctx.terminal_width is not None:
        return ctx.terminal_width
    columns = shutil.get_terminal_size((80, 24)).columns
    return min(columns, ctx.max_content_width)


def _show_help_callback(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.get_help(), color=ctx.color)
    raise Exit(0)


# spec: N-000950 N-000951 N-000952 N-000953 N-000954 N-000968
class Context:
    """The state of one invocation of a command. Built by the library, one per invocation."""

    def __init__(self, command, parent=None, info_name=None, obj=None, auto_envvar_prefix=None,
                 default_map=None, terminal_width=None, max_content_width=None,
                 help_option_names=None, token_normalize_func=None, color=None, show_default=None,
                 allow_extra_args=None, allow_interspersed_args=None,
                 ignore_unknown_options=None, resilient_parsing=False):
        self.command = command
        self.parent = parent
        self.info_name = info_name
        if parent is not None:
            if obj is None:
                obj = parent.obj
            if auto_envvar_prefix is None:
                auto_envvar_prefix = parent.auto_envvar_prefix
            if default_map is None and isinstance(parent.default_map, dict) and info_name is not None:
                default_map = parent.default_map.get(info_name)
            if terminal_width is None:
                terminal_width = parent.terminal_width
            if max_content_width is None:
                max_content_width = parent.max_content_width
            if help_option_names is None:
                help_option_names = parent.help_option_names
            if token_normalize_func is None:
                token_normalize_func = parent.token_normalize_func
            if color is None:
                color = parent.color
            if show_default is None:
                show_default = parent.show_default
        self.obj = obj
        self.auto_envvar_prefix = auto_envvar_prefix
        self.default_map = default_map
        self.terminal_width = terminal_width
        self.max_content_width = (
            DEFAULT_MAX_CONTENT_WIDTH if max_content_width is None else max_content_width
        )
        self.help_option_names = list(help_option_names) if help_option_names else ["--help"]
        self.token_normalize_func = token_normalize_func
        self.color = color
        self.show_default = bool(show_default)
        self.allow_extra_args = (
            command.allow_extra_args if allow_extra_args is None else allow_extra_args
        )
        self.allow_interspersed_args = (
            command.allow_interspersed_args if allow_interspersed_args is None
            else allow_interspersed_args
        )
        self.ignore_unknown_options = (
            command.ignore_unknown_options if ignore_unknown_options is None
            else ignore_unknown_options
        )
        self.resilient_parsing = resilient_parsing
        self.params = {}
        self.args = []
        self.invoked_subcommand = None
        self._param_sources = {}
        self._close_callbacks = []
        self._depth = 0

    # -- with-statement support -------------------------------------------------------------

    def __enter__(self):
        self._depth += 1
        push_context(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        self._depth -= 1
        pop_context()
        if self._depth == 0:
            self.close()

    @contextlib.contextmanager
    def scope(self, cleanup=True):
        self._depth += 1
        push_context(self)
        try:
            yield self
        finally:
            self._depth -= 1
            pop_context()
            if cleanup and self._depth == 0:
                self.close()

    # -- resources --------------------------------------------------------------------------

    def call_on_close(self, func):
        self._close_callbacks.append(func)

    def with_resource(self, cm):
        value = cm.__enter__()
        self.call_on_close(lambda: cm.__exit__(None, None, None))
        return value

    def close(self):
        callbacks, self._close_callbacks = self._close_callbacks, []
        for func in reversed(callbacks):
            with contextlib.suppress(Exception):
                func()

    # -- tree navigation --------------------------------------------------------------------

    @property
    def command_path(self):
        names = []
        node = self
        while node is not None:
            if node.info_name:
                names.append(node.info_name)
            node = node.parent
        return " ".join(reversed(names))

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    # spec: N-000975 N-000976 N-000977
    def find_object(self, object_type):
        node = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        rv = self.find_object(object_type)
        if rv is None:
            self.obj = rv = object_type()
        return rv

    # spec: N-000969
    def get_parameter_source(self, name):
        return self._param_sources.get(name)

    def auto_envvar_name(self, dest):
        """The automatic environment variable name for ``dest``, or None without a prefix."""
        root = self.find_root()
        if root.auto_envvar_prefix is None:
            return None
        path = []
        node = self
        while node.parent is not None:
            path.append(node.info_name or "")
            node = node.parent
        parts = [root.auto_envvar_prefix] + list(reversed(path)) + [dest]
        return "_".join(part.replace("-", "_").upper() for part in parts)

    # -- control ----------------------------------------------------------------------------

    # spec: N-000972
    def exit(self, code=0):
        raise Exit(code)

    # spec: N-000973
    def abort(self):
        raise Abort()

    # spec: N-000971
    def invoke(self, callback, /, *args, **kwargs):
        """Call a function, or run another command with the given values."""
        if isinstance(callback, Command):
            other = callback
            sub = Context(other, info_name=other.name, parent=self)
            values = {}
            for p in other.params:
                if p.expose_value:
                    values[p.name] = p.get_default(sub)
            values.update(kwargs)
            sub.params = dict(values)
            with sub:
                if other.callback is None:
                    return None
                return other.callback(*args, **values)
        push_context(self)
        try:
            return callback(*args, **kwargs)
        finally:
            pop_context()

    def forward(self, cmd, /, **kwargs):
        values = dict(self.params)
        values.update(kwargs)
        return self.invoke(cmd, **values)

    def get_usage(self):
        return self.command.get_usage(self)

    def get_help(self):
        return self.command.get_help(self)


class Parameter:
    """Common behaviour of options and arguments."""

    kind = "parameter"
    is_flag = False
    count = False
    optional_value = False
    flag_value = None
    prompt = None
    prompt_required = True
    hide_input = False
    confirmation_prompt = False
    show_default = None
    show_envvar = False
    default_is_auto = False
    opts = ()
    secondary_opts = ()

    def _init_common(self, *, name, type, default, required, callback, nargs, multiple, metavar,
                     expose_value, is_eager, envvar, shell_complete, deprecated, hidden, help,
                     allow_from_autoenv):
        self.name = name
        self.type = type
        self.default = default
        self.required = required
        self.callback = callback
        self.nargs = nargs
        self.multiple = multiple
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        if envvar is None:
            self.envvar = None
        elif isinstance(envvar, str):
            self.envvar = [envvar]
        else:
            self.envvar = list(envvar)
        self._complete_func = shell_complete
        self.deprecated = deprecated
        self.hidden = hidden
        self.help = help
        self.allow_from_autoenv = allow_from_autoenv

    @property
    def _splits_values(self):
        return self.multiple or self.nargs != 1 or isinstance(self.type, pt.Tuple)

    # -- naming -----------------------------------------------------------------------------

    def get_error_hint(self, ctx=None):
        if self.kind == "option":
            return " / ".join(f"'{n}'" for n in list(self.opts) + list(self.secondary_opts))
        return f"'{self.name}'"

    def make_metavar(self):
        if self.metavar is not None:
            return self.metavar
        rv = self.type.get_metavar(self)
        if rv:
            return rv
        if self.kind == "argument":
            return self.name.upper()
        return self.type.name.upper()

    def _deprecation_warning(self):
        if not self.deprecated:
            return
        if self.kind == "option":
            what = f"The '{self.opts[0] if self.opts else self.name}' option"
        else:
            what = f"The '{self.name}' argument"
        note = self.deprecated if isinstance(self.deprecated, str) else ""
        echo(f"DeprecationWarning: {what} is deprecated." + (f" {note}" if note else ""), err=True)

    # -- values from sources ----------------------------------------------------------------

    def get_default(self, ctx, call=True):
        if callable(self.default) and call:
            return self.default()
        return self.default

    def envvar_names(self, ctx):
        names = list(self.envvar or [])
        if self.kind == "option" and self.allow_from_autoenv and ctx is not None:
            auto = ctx.auto_envvar_name(self.name)
            if auto and auto not in names:
                names.append(auto)
        return names

    def value_from_envvar(self, ctx):
        """Return ``(True, value)`` when a non-empty environment variable supplies a value."""
        for name in self.envvar_names(ctx):
            raw = os.environ.get(name)
            if not raw:
                continue
            if self.count:
                return True, self._convert_item(ctx, raw)
            if self.is_flag:
                value = self._flag_env_value(raw, name)
                if value is _UNSET:
                    continue
                return True, value
            tokens = self.type.split_envvar_value(raw) if self._splits_values else [raw]
            if not tokens:
                continue
            return True, self._value_from_occurrences(ctx, self._env_occurrences(tokens))
        return False, None

    def _flag_env_value(self, raw, name):
        text = raw.strip().lower()
        bool_flag = isinstance(self.flag_value, bool)
        if not bool_flag and raw == str(self.flag_value):
            return self.flag_value
        if text in pt.TRUE_VALUES:
            return self.flag_value
        if text in pt.FALSE_VALUES or text == "":
            return False
        if bool_flag:
            raise BadParameter(
                f"{raw!r} is not a valid boolean for environment variable '{name}'.",
                param=self,
            )
        return _UNSET

    def _env_occurrences(self, tokens):
        if self.nargs == -1:
            return [tuple(tokens)]
        if self.multiple:
            return self._group_tokens(tokens)
        if self.nargs == 1 and not isinstance(self.type, pt.Tuple):
            return [tokens[0]]
        return [tuple(tokens)]

    def _group_tokens(self, tokens):
        if self.nargs == 1 and not isinstance(self.type, pt.Tuple):
            return list(tokens)
        k = self.nargs
        return [tuple(tokens[i:i + k]) for i in range(0, len(tokens), k)]

    def _lookup_default_map(self, ctx):
        dm = ctx.default_map
        if isinstance(dm, dict) and dm.get(self.name) is not None:
            return True, dm[self.name]
        return False, None

    # -- conversion -------------------------------------------------------------------------

    def _convert_token(self, ctx, token):
        return self.type.convert(token, self, ctx)

    def _convert_item(self, ctx, item):
        """Convert one occurrence: a scalar token for a unary parameter, else a sequence."""
        if isinstance(self.type, pt.Tuple):
            return self.type.convert(tuple(item) if not isinstance(item, str) else (item,),
                                     self, ctx)
        if self.nargs == 1:
            return self._convert_token(ctx, item)
        return tuple(self._convert_token(ctx, t) for t in item)

    def _convert_occurrence(self, ctx, occ):
        if isinstance(occ, _Literal):
            return occ.value
        return self._convert_item(ctx, occ)

    def _value_from_occurrences(self, ctx, occs):
        if self.count:
            return sum(o.value for o in occs)
        if self.is_flag:
            return occs[-1].value
        if self.multiple:
            return tuple(self._convert_occurrence(ctx, o) for o in occs)
        return self._convert_occurrence(ctx, occs[-1])

    def _convert_default(self, ctx, raw):
        if raw is None:
            return () if (self.multiple or self.nargs == -1) else None
        if self.is_flag:
            return raw
        if self.multiple:
            if isinstance(raw, (str, bytes)):
                if self.nargs == 1 and not isinstance(self.type, pt.Tuple):
                    raise BadParameter(
                        f"The default for {self.get_error_hint(ctx)} must be an iterable "
                        "(sequence) of values, not a single string.",
                        ctx=ctx, param=self,
                    )
                items = self._group_tokens(self.type.split_envvar_value(raw))
            else:
                try:
                    items = list(raw)
                except TypeError:
                    raise BadParameter(
                        f"The default for {self.get_error_hint(ctx)} must be an iterable "
                        "(sequence) of values.",
                        ctx=ctx, param=self,
                    ) from None
            return tuple(self._convert_item(ctx, it) for it in items)
        if isinstance(raw, str) and self._splits_values:
            raw = self.type.split_envvar_value(raw)
        if self._splits_values:
            return self._convert_item(ctx, tuple(raw) if not isinstance(raw, str) else raw)
        return self._convert_item(ctx, raw)

    # -- prompting --------------------------------------------------------------------------

    def _prompt_for_value(self, ctx, raw_default):
        """Return ``(answered, value)`` for a prompt on this parameter."""
        if self.is_flag:
            return True, confirm(self._prompt_text(), default=bool(raw_default))
        answered, value = _prompt_loop(
            self._prompt_text(),
            default=raw_default,
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            type=self.type,
        )
        if answered and self.multiple:
            value = (value,)
        return answered, value

    def _prompt_text(self):
        if isinstance(self.prompt, str):
            return self.prompt
        return self.name.replace("_", " ").capitalize()

    # -- the value pipeline -----------------------------------------------------------------

    def _is_missing(self, value):
        if value is None:
            return True
        return (self.multiple or self.nargs == -1) and value == ()

    # spec: N-000921 N-000922 N-000923
    def handle_parse(self, ctx, occs):
        """Resolve this parameter's value from every source, check it, and run its callback.

        Returns ``(value, source)``. ``source`` is None when no source produced a value.
        """
        try:
            occs = occs or []
            cl = [o for o in occs if o is not _PROMPT]
            prompt_flag = len(cl) != len(occs)
            source = None
            value = None
            if cl:
                value = self._value_from_occurrences(ctx, cl)
                source = ParameterSource.COMMANDLINE
                self._deprecation_warning()
            else:
                found, value = self.value_from_envvar(ctx)
                if found:
                    source = ParameterSource.ENVIRONMENT
                else:
                    dm_found, dm_raw = self._lookup_default_map(ctx)
                    raw_default = dm_raw if dm_found else self.get_default(ctx)
                    fallback = ParameterSource.DEFAULT_MAP if dm_found else ParameterSource.DEFAULT
                    if self.prompt is not None and (prompt_flag or self.prompt_required):
                        answered, value = self._prompt_for_value(ctx, raw_default)
                        if answered:
                            source = ParameterSource.PROMPT
                    if source is None:
                        value = self._convert_default(ctx, raw_default)
                        source = fallback
            missing = self._is_missing(value) or (
                self.is_flag and source is ParameterSource.DEFAULT and not value
            )
            if self.required and missing:
                raise MissingParameter(ctx=ctx, param=self)
            if self.callback is not None:
                value = self.callback(ctx, self, value)
            return value, source
        except BadParameter as e:
            if e.param is None:
                e.param = self
            if e.ctx is None:
                e.ctx = ctx
            raise

    def complete(self, ctx, incomplete):
        if self._complete_func is not None:
            return self._complete_func(ctx, self, incomplete)
        return self.type.shell_complete(ctx, self, incomplete)

    def get_help_record(self, ctx):
        return None


# spec: N-000881 N-000884 N-000885
class Option(Parameter):
    """A named parameter introduced by a prefix character, such as ``--verbose``."""

    kind = "option"

    def __init__(self, param_decls=None, *, type=None, default=None, required=False,
                 is_flag=None, flag_value=None, count=False, multiple=False, nargs=1,
                 envvar=None, allow_from_autoenv=True, prompt=False, prompt_required=True,
                 hide_input=False, confirmation_prompt=False, callback=None, is_eager=False,
                 expose_value=True, hidden=False, deprecated=False, help=None, metavar=None,
                 show_default=None, show_envvar=False, shell_complete=None):
        opts, secondary, dest = _parse_option_decls(param_decls or ())
        self.opts = opts
        self.secondary_opts = secondary

        if count:
            if is_flag:
                raise DeclarationError("A counting option cannot also be a flag.")
            is_flag = False
            if default is None:
                default = 0
            flag_value = 1
        elif is_flag is None:
            is_flag = bool(secondary) or isinstance(default, bool)
        self.is_flag = bool(is_flag)
        self.count = bool(count)
        if self.is_flag:
            if flag_value is None:
                flag_value = True
            if default is None and isinstance(flag_value, bool):
                default = False
                self.default_is_auto = True
        self.flag_value = flag_value
        self.optional_value = (not self.is_flag and not self.count and flag_value is not None)

        if isinstance(type, pt.Tuple):
            nargs = len(type.types)
        if nargs < 1:
            raise DeclarationError("An option takes a positive number of values.")
        if isinstance(type, pt.Tuple) and nargs not in (1, len(type.types)):
            raise DeclarationError("nargs does not match the length of the tuple type.")
        if self.count:
            resolved = pt.INT
        elif self.is_flag and type is None:
            resolved = pt.BOOL
        else:
            resolved = pt.resolve_type(type, default)
        if isinstance(resolved, pt.Tuple):
            nargs = len(resolved.types)
        if deprecated and required:
            raise DeclarationError("A deprecated option cannot be required.")
        if deprecated and prompt:
            raise DeclarationError("A deprecated option cannot use a prompt.")

        self.prompt = None if not prompt else prompt
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.show_default = show_default
        self.show_envvar = show_envvar
        self._init_common(
            name=dest, type=resolved, default=default, required=bool(required), callback=callback,
            nargs=nargs, multiple=bool(multiple), metavar=metavar, expose_value=expose_value,
            is_eager=is_eager, envvar=envvar, shell_complete=shell_complete,
            deprecated=deprecated, hidden=hidden, help=help,
            allow_from_autoenv=allow_from_autoenv,
        )

    def get_help_record(self, ctx):
        if self.hidden:
            return None
        names = ", ".join(self.opts)
        if self.secondary_opts:
            names += " / " + ", ".join(self.secondary_opts)
        if not self.is_flag and not self.count:
            names += " " + self.make_metavar()
        help_text = self.help or ""
        if self.deprecated:
            help_text = (help_text + " " if help_text else "") + "(Deprecated)"
        extras = []
        show_default = self.show_default if self.show_default is not None else ctx.show_default
        if show_default:
            if isinstance(show_default, str):
                extras.append(f"default: {show_default}")
            elif self.default is not None and not (self.is_flag and self.default is False):
                if callable(self.default):
                    extras.append("default: (dynamic)")
                elif isinstance(self.default, (list, tuple)):
                    extras.append("default: " + ", ".join(str(v) for v in self.default))
                else:
                    extras.append(f"default: {self.default}")
        envvars = self.envvar_names(None) if self.envvar else []
        if self.show_envvar and envvars:
            extras.append("env var: " + ", ".join(envvars))
        if extras:
            help_text = (help_text + " " if help_text else "") + " ".join(f"[{e}]" for e in extras)
        return names, help_text


def _parse_option_decls(decls):
    opts = []
    secondary = []
    explicit = None
    for decl in decls:
        if not decl:
            raise DeclarationError("An empty parameter declaration is not allowed.")
        if _is_prefixed(decl):
            if "/" in decl[1:]:
                idx = decl.index("/", 1)
                first, second = decl[:idx], decl[idx + 1:]
                if not _is_prefixed(second):
                    second = decl[0] + second
                opts.append(first)
                secondary.append(second)
            else:
                opts.append(decl)
        else:
            if explicit is not None:
                raise DeclarationError("Only one destination name may be given.")
            explicit = decl
    if explicit is not None:
        dest = explicit
    elif opts:
        longs = [o for o in opts if len(_strip_prefix(o)) > 1]
        chosen = longs[0] if longs else opts[0]
        dest = _strip_prefix(chosen).replace("-", "_")
    else:
        raise DeclarationError("A parameter needs a flag name or a destination name.")
    return opts, secondary, dest


# spec: N-000910 N-000911 N-000912
class Argument(Parameter):
    """A positional parameter."""

    kind = "argument"

    def __init__(self, param_decls, *, type=None, default=None, required=None, nargs=1,
                 envvar=None, deprecated=False, help=None, metavar=None, callback=None,
                 expose_value=True, shell_complete=None):
        decls = list(param_decls or ())
        if len(decls) != 1 or _is_prefixed(decls[0]):
            raise DeclarationError("An argument takes exactly one destination name.")
        name = decls[0]
        if nargs == 0 or nargs < -1:
            raise DeclarationError("An argument takes a positive number of values, or -1.")
        if required is None:
            required = default is None and nargs != -1
        if deprecated and required:
            raise DeclarationError("A deprecated argument cannot be required.")
        resolved = pt.resolve_type(type, default)
        if isinstance(resolved, pt.Tuple):
            nargs = len(resolved.types)
        self._init_common(
            name=name, type=resolved, default=default, required=bool(required), callback=callback,
            nargs=nargs, multiple=False, metavar=metavar, expose_value=expose_value,
            is_eager=False, envvar=envvar, shell_complete=shell_complete,
            deprecated=deprecated, hidden=False, help=help, allow_from_autoenv=False,
        )

    def make_usage_metavar(self):
        mv = self.make_metavar()
        if self.nargs == -1:
            return mv + "..." if self.required else f"[{mv}]..."
        if self.nargs > 1:
            joined = " ".join([mv] * self.nargs)
            return joined if self.required else f"[{joined}]"
        return mv if self.required else f"[{mv}]"


class _OptionParser:
    """Splits an argument list into option occurrences and positional tokens."""

    def __init__(self, ctx, params):
        self.ctx = ctx
        self.normalize = ctx.token_normalize_func or (lambda s: s)
        self.interspersed = ctx.allow_interspersed_args
        self.ignore_unknown = ctx.ignore_unknown_options
        self.occurrences = {}
        self.order = []
        self._map = {}
        self._prefixes = {"-"}
        for p in params:
            if p.kind != "option":
                continue
            for name in p.opts:
                self._register(name, p, "on")
            for name in p.secondary_opts:
                self._register(name, p, "off")

    def _register(self, name, p, kind):
        self._prefixes.add(name[0])
        self._map.setdefault(self.normalize(name), (p, kind))

    def _is_option(self, tok):
        return len(tok) > 1 and tok[0] in self._prefixes

    def parse(self, args):
        positional = []
        i = 0
        while i < len(args):
            tok = args[i]
            if tok == "--":
                positional.extend(args[i + 1:])
                break
            if not self._is_option(tok):
                positional.append(tok)
                if not self.interspersed:
                    positional.extend(args[i + 1:])
                    break
                i += 1
                continue
            i = self._parse_option(tok, args, i, positional)
        return positional

    def _record(self, p, occ):
        if p not in self.occurrences:
            self.occurrences[p] = []
            self.order.append(p)
        self.occurrences[p].append(occ)

    def _tokens_occurrence(self, p, tokens):
        if p.nargs == 1 and not isinstance(p.type, pt.Tuple):
            return tokens[0]
        return tuple(tokens)

    def _parse_option(self, tok, args, i, positional):
        key, eq, inline = tok.partition("=")
        nkey = self.normalize(key)
        if nkey in self._map:
            p, kind = self._map[nkey]
            return self._apply(p, kind, key, inline if eq else None, args, i)
        is_long = len(key) > 2 and key[0] in self._prefixes and key[1] in self._prefixes
        if is_long:
            if self.ignore_unknown:
                positional.append(tok)
                return i + 1
            raise NoSuchOption(key, ctx=self.ctx)
        return self._short_stack(tok, args, i, positional)

    def _apply(self, p, kind, label, inline, args, i):
        if kind == "off" or p.is_flag or p.count:
            if inline is not None:
                raise BadOptionUsage(f"Option '{label}' does not take a value.", ctx=self.ctx)
            if p.count:
                self._record(p, _Literal(1))
            elif kind == "off":
                self._record(p, _Literal(False))
            else:
                self._record(p, _Literal(p.flag_value))
            return i + 1
        return self._take_value(p, label, inline, args, i)

    def _take_value(self, p, label, inline, args, i):
        if p.optional_value:
            if inline is not None:
                self._record(p, self._tokens_occurrence(p, [inline]))
                return i + 1
            nxt = i + 1
            if nxt < len(args) and not self._is_option(args[nxt]):
                self._record(p, self._tokens_occurrence(p, [args[nxt]]))
                return nxt + 1
            self._record(p, _Literal(p.flag_value))
            return i + 1
        tokens = [] if inline is None else [inline]
        idx = i + 1
        while len(tokens) < p.nargs:
            if idx >= len(args):
                if p.prompt is not None:
                    self._record(p, _PROMPT)
                    return i + 1
                raise BadOptionUsage(f"Option '{label}' requires an argument.", ctx=self.ctx)
            tokens.append(args[idx])
            idx += 1
        self._record(p, self._tokens_occurrence(p, tokens))
        return idx

    def _short_stack(self, tok, args, i, positional):
        prefix = tok[0]
        stack = tok[1:]
        j = 0
        while j < len(stack):
            key = prefix + stack[j]
            nkey = self.normalize(key)
            if nkey not in self._map:
                if self.ignore_unknown:
                    positional.append(prefix + stack[j:])
                    return i + 1
                raise NoSuchOption(key, ctx=self.ctx)
            p, kind = self._map[nkey]
            if p.is_flag or p.count or kind == "off":
                self._apply(p, kind, key, None, args, i)
                j += 1
                continue
            rest = stack[j + 1:]
            return self._take_value(p, key, rest if rest else None, args, i)
        return i + 1


# spec: N-000914 N-000915 N-000916 N-000917
def _bind_arguments(arguments, tokens, occurrences, order, ctx):
    """Bind positional tokens to declared arguments in order. Returns the leftover tokens."""
    i = 0
    n = len(tokens)
    for idx, arg in enumerate(arguments):
        later = sum(a.nargs for a in arguments[idx + 1:] if a.nargs > 0)
        available = n - i
        if available <= 0:
            continue
        if arg.nargs == -1:
            take = max(available - later, 0)
            if take == 0:
                continue
            occ = tuple(tokens[i:i + take])
        else:
            if available < arg.nargs:
                raise BadArgumentUsage(
                    f"Argument '{arg.name}' takes {arg.nargs} values.", ctx=ctx
                )
            take = arg.nargs
            occ = tokens[i] if arg.nargs == 1 and not isinstance(arg.type, pt.Tuple) else (
                tuple(tokens[i:i + take]))
        occurrences[arg] = [occ]
        order.append(arg)
        i += take
    return tokens[i:]


def _processing_order(params, order):
    invocation = {p: idx for idx, p in enumerate(order)}
    declared = {p: idx for idx, p in enumerate(params)}
    absent = len(order)
    return sorted(
        params,
        key=lambda p: (not p.is_eager, invocation.get(p, absent), declared[p]),
    )


_RANK = {
    ParameterSource.PROMPT: 0,
    ParameterSource.COMMANDLINE: 1,
    ParameterSource.ENVIRONMENT: 2,
    ParameterSource.DEFAULT_MAP: 3,
    ParameterSource.DEFAULT: 4,
}


def _pick_feature_switch(items):
    """Choose the winning value among options that share one destination."""

    def key(item):
        index, p, _value, source = item
        auto_penalty = 1 if (source is ParameterSource.DEFAULT and p.default_is_auto) else 0
        return (_RANK[source], auto_penalty, -index)

    return min(items, key=key)


# spec: N-000850 N-000853 N-000854
class Command:
    """A leaf command: parses a slice of the command line and runs a callback."""

    allow_extra_args = False
    allow_interspersed_args = True
    ignore_unknown_options = False

    def __init__(self, name, callback=None, params=None, help=None, epilog=None, short_help=None,
                 options_metavar="[OPTIONS]", context_settings=None, add_help_option=True,
                 no_args_is_help=False, hidden=False, deprecated=False):
        self.name = name
        self.callback = callback
        self.params = list(params or [])
        self.help = help.replace("\f", "") if help else help
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.context_settings = dict(context_settings or {})
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = deprecated

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    # -- running ----------------------------------------------------------------------------

    def _derive_prog_name(self):
        if sys.argv and sys.argv[0]:
            return os.path.basename(sys.argv[0])
        return self.name or "root"

    # spec: N-000854 N-000855 N-000856 N-000857 N-001014
    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True, **extra):
        """Run this command on ``args`` (default ``sys.argv[1:]``).

        In standalone mode the process exits with the status of the run. Otherwise the return value
        of the callback is returned, and failures are raised to the caller.
        """
        args = list(sys.argv[1:] if args is None else args)
        if prog_name is None:
            prog_name = self._derive_prog_name()
        if complete_var is None:
            complete_var = "_" + prog_name.upper().replace("-", "_") + "_COMPLETE"
        if complete_var in os.environ:
            from .shell_completion import run_completion

            status = run_completion(self, prog_name, complete_var, os.environ[complete_var])
            if standalone_mode:
                sys.exit(status)
            return status

        try:
            with self.make_context(prog_name, args, **extra) as ctx:
                rv = self.invoke(ctx)
                if not standalone_mode:
                    return rv
                ctx.exit()
        except (EOFError, KeyboardInterrupt) as e:
            echo(file=sys.stderr)
            if not standalone_mode:
                raise Abort() from e
            echo("Aborted!", err=True)
            sys.exit(1)
        except UsageError as e:
            if not standalone_mode:
                raise
            e.show()
            sys.exit(e.exit_code)
        except OptlynError as e:
            if not standalone_mode:
                raise
            e.show()
            sys.exit(e.exit_code)
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return e.exit_code
        except Abort:
            if not standalone_mode:
                raise
            echo("Aborted!", err=True)
            sys.exit(1)
        return None

    def make_context(self, info_name, args, parent=None, **extra):
        settings = dict(self.context_settings)
        settings.update(extra)
        ctx = Context(self, info_name=info_name, parent=parent, **settings)
        with ctx.scope(cleanup=False):
            self.parse_args(ctx, args)
        return ctx

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsIsHelpError(ctx)
        params = self.get_params(ctx)
        parser = _OptionParser(ctx, params)
        positional = parser.parse(args)
        occurrences = parser.occurrences
        order = list(parser.order)
        arguments = [p for p in params if p.kind == "argument"]
        leftover = _bind_arguments(arguments, positional, occurrences, order, ctx)
        if leftover and not ctx.allow_extra_args:
            noun = "argument" if len(leftover) == 1 else "arguments"
            raise UsageError(
                f"Got unexpected extra {noun} ({' '.join(leftover)})", ctx=ctx
            )
        ctx.args = leftover

        resolved = {}
        for index, p in enumerate(_processing_order(params, order)):
            value, source = p.handle_parse(ctx, occurrences.get(p))
            if not p.expose_value:
                continue
            ctx.params[p.name] = value
            ctx._param_sources[p.name] = source
            resolved.setdefault(p.name, []).append((index, p, value, source))
        for dest, items in resolved.items():
            if len(items) > 1:
                _index, _p, value, source = _pick_feature_switch(items)
                ctx.params[dest] = value
                ctx._param_sources[dest] = source

    def get_params(self, ctx):
        params = list(self.params)
        help_option = self.get_help_option(ctx)
        if help_option is not None:
            params.append(help_option)
        return params

    def get_help_option(self, ctx):
        if not self.add_help_option:
            return None
        author_names = set()
        for p in self.params:
            if p.kind == "option":
                author_names.update(p.opts)
                author_names.update(p.secondary_opts)
        names = [n for n in ctx.help_option_names if n not in author_names]
        if not names:
            return None
        return Option(
            names, is_flag=True, is_eager=True, expose_value=False,
            callback=_show_help_callback, help="Show this message and exit.",
        )

    def invoke(self, ctx):
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else ""
            echo(
                f"DeprecationWarning: The command '{self.name}' is deprecated."
                + (f" {note}" if note else ""),
                err=True,
            )
        if self.callback is None:
            return None
        return ctx.invoke(self.callback, **ctx.params)

    # -- help -------------------------------------------------------------------------------

    def collect_usage_pieces(self, ctx):
        pieces = []
        if any(p.kind == "option" and not p.hidden for p in self.get_params(ctx)):
            pieces.append(self.options_metavar)
        for p in self.get_params(ctx):
            if p.kind == "argument":
                pieces.append(p.make_usage_metavar())
        return pieces

    def get_usage(self, ctx):
        pieces = self.collect_usage_pieces(ctx)
        return " ".join(["Usage: " + ctx.command_path] + [x for x in pieces if x])

    def get_short_help_str(self, limit=SHORT_HELP_LIMIT):
        if self.short_help:
            return self.short_help
        if not self.help:
            return ""
        paragraph = re.split(r"\n\s*\n", self.help.strip("\n"))[0]
        paragraph = " ".join(line.strip() for line in paragraph.split("\n"))
        match = re.search(r"[.!?](\s|$)", paragraph)
        text = paragraph[:match.start() + 1] if match else paragraph
        if len(text) > limit:
            text = text[:limit - 3].rstrip() + "..."
        return text

    def _help_body(self, ctx, width):
        body = self.help or ""
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else ""
            mark = "(Deprecated)" + (f" {note}" if note else "")
            body = mark + ("\n\n" + body if body else "")
        return wrap_text(body, width=width) if body else ""

    # spec: N-000827 N-000828 N-000837 N-000842 N-000844
    def get_help(self, ctx):
        width = _wrap_width(ctx)
        sections = [self.get_usage(ctx)]
        body = self._help_body(ctx, width)
        if body:
            sections.append(body)
        sections.extend(self._argument_section(ctx, width))
        sections.extend(self._option_section(ctx, width))
        sections.extend(self._command_section(ctx, width))
        if self.epilog:
            sections.append(wrap_text(self.epilog, width=width))
        return "\n\n".join(sections)

    def _argument_section(self, ctx, width):
        rows = [(p.make_usage_metavar(), p.help) for p in self.get_params(ctx)
                if p.kind == "argument" and p.help]
        if not rows:
            return []
        return ["Positional arguments:\n" + "\n".join(format_dl(rows, width))]

    def _option_section(self, ctx, width):
        rows = []
        for p in self.get_params(ctx):
            if p.kind != "option":
                continue
            record = p.get_help_record(ctx)
            if record is not None:
                rows.append(record)
        if not rows:
            return []
        return ["Options:\n" + "\n".join(format_dl(rows, width))]

    def _command_section(self, ctx, width):
        return []


# spec: N-000862 N-000864 N-000865 N-000869 N-000871
class Group(Command):
    """A command that dispatches to named subcommands."""

    allow_extra_args = True
    allow_interspersed_args = False

    def __init__(self, name=None, commands=None, invoke_without_command=False,
                 no_args_is_help=None, subcommand_metavar=None, chain=False,
                 result_callback=None, **kwargs):
        super().__init__(name, **kwargs)
        self.commands = {}
        if commands:
            items = commands.items() if isinstance(commands, dict) else (
                (c.name, c) for c in commands)
            for cname, cmd in items:
                self.add_command(cmd, cname)
        self.invoke_without_command = invoke_without_command
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        self.no_args_is_help = no_args_is_help
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback

    # -- subcommands ------------------------------------------------------------------------

    def add_command(self, cmd, name=None):
        name = name or cmd.name
        if self.chain and isinstance(cmd, Group):
            raise DeclarationError("A group cannot be attached beneath a chaining group.")
        self.commands[name] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as command_decorator

        def decorator(f):
            cmd = command_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as group_decorator

        def decorator(f):
            cmd = group_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self):
        """Return a decorator that registers the function run on the subcommand return values."""

        def decorator(f):
            self._result_callback = f
            return f

        return decorator

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        return self.commands.get(cmd_name)

    def resolve_command(self, ctx, name):
        cmd = self.get_command(ctx, name)
        if cmd is None and ctx.token_normalize_func is not None:
            wanted = ctx.token_normalize_func(name)
            for candidate in self.list_commands(ctx):
                if ctx.token_normalize_func(candidate) == wanted:
                    name = candidate
                    cmd = self.get_command(ctx, candidate)
                    break
        if cmd is None:
            raise UsageError(f"No such command {name!r}.", ctx)
        return name, cmd

    # -- running ----------------------------------------------------------------------------

    def _process_result(self, ctx, value):
        if self._result_callback is None:
            return value
        return ctx.invoke(self._result_callback, value, **ctx.params)

    def invoke(self, ctx):
        if self.chain:
            return self._invoke_chain(ctx)
        args = list(ctx.args)
        if not args:
            if not self.invoke_without_command:
                raise UsageError("Missing command.", ctx)
            ctx.invoked_subcommand = None
            rv = Command.invoke(self, ctx)
            return self._process_result(ctx, rv)
        cmd_name, cmd = self.resolve_command(ctx, args[0])
        ctx.invoked_subcommand = cmd_name
        Command.invoke(self, ctx)
        sub = cmd.make_context(cmd_name, args[1:], parent=ctx)
        with sub:
            rv = cmd.invoke(sub)
        return self._process_result(ctx, rv)

    # spec: N-000873 N-000874
    def _invoke_chain(self, ctx):
        args = list(ctx.args)
        if not args and not self.invoke_without_command:
            raise UsageError("Missing command.", ctx)
        ctx.invoked_subcommand = CHAIN_SUBCOMMAND if args else None
        Command.invoke(self, ctx)
        results = []
        while args:
            cmd_name, cmd = self.resolve_command(ctx, args[0])
            sub = cmd.make_context(
                cmd_name, args[1:], parent=ctx,
                allow_extra_args=True, allow_interspersed_args=False,
            )
            with sub:
                results.append(cmd.invoke(sub))
            args = list(sub.args)
        self._process_result(ctx, results)
        return results

    # -- help -------------------------------------------------------------------------------

    def collect_usage_pieces(self, ctx):
        rv = super().collect_usage_pieces(ctx)
        cmd_word = self.subcommand_metavar or "COMMAND"
        if self.chain:
            rv.append(f"{cmd_word}1 [ARGS]... [{cmd_word}2 [ARGS]...]...")
        elif self.invoke_without_command:
            rv.append(f"[{cmd_word}] [ARGS]...")
        else:
            rv.append(f"{cmd_word} [ARGS]...")
        return rv

    def _command_section(self, ctx, width):
        rows = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            rows.append((name, cmd.get_short_help_str()))
        if not rows:
            return []
        return ["Commands:\n" + "\n".join(format_dl(rows, width))]


# spec: N-000878 N-000879
class CommandCollection(Group):
    """A group that presents the subcommands of several source groups under one dispatch surface."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources) if sources is not None else []

    def list_commands(self, ctx):
        names = set()
        for source in self.sources:
            names.update(source.list_commands(ctx))
        names.update(self.commands)
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None


__all__ = [
    "Abort",
    "CHAIN_SUBCOMMAND",
    "Argument",
    "BadParameter",
    "Command",
    "CommandCollection",
    "Context",
    "Group",
    "Option",
    "Parameter",
    "ParameterSource",
    "get_current_context",
]
