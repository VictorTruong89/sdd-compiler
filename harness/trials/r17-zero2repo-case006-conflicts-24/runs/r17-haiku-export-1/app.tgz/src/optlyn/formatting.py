"""Text wrapping and two-column layout used by help pages."""

import re
import textwrap

_PARAGRAPH_SPLIT = re.compile(r"\n\s*\n")


# spec: N-001009
def wrap_text(text, width=78, initial_indent="", subsequent_indent="", preserve_paragraphs=False):
    """Rewrap ``text`` to ``width`` columns.

    Single newlines inside a paragraph are not kept as hard breaks. A paragraph whose first line is
    only a backspace character is not rewrapped: its line breaks are kept and the backspace line is
    dropped.
    """
    if not text:
        return ""
    width = max(width, 1)
    out = []
    for paragraph in _PARAGRAPH_SPLIT.split(text.strip("\n")):
        lines = paragraph.split("\n")
        if lines and lines[0].strip("\b") == "" and lines[0] != "":
            kept = [(initial_indent if i == 0 else subsequent_indent) + line.rstrip()
                    for i, line in enumerate(lines[1:])]
            out.append("\n".join(kept))
            continue
        flat = " ".join(line.strip() for line in lines if line.strip())
        if not flat:
            continue
        out.append(
            textwrap.fill(
                flat,
                width=width,
                initial_indent=initial_indent,
                subsequent_indent=subsequent_indent,
                break_on_hyphens=False,
                break_long_words=False,
            )
        )
    return "\n\n".join(out)


def format_dl(rows, width, indent=2, col_max=30, col_spacing=2):
    """Lay out ``(term, description)`` rows as an indented two-column list.

    Returns a list of lines. A row with an empty description is printed as the bare term.
    """
    if not rows:
        return []
    first_col = min(max(len(term) for term, _ in rows), col_max) + col_spacing
    text_width = max(width - first_col - indent, 20)
    pad = " " * indent
    lines = []
    for term, desc in rows:
        if not desc:
            lines.append(pad + term)
            continue
        wrapped = wrap_text(desc, width=text_width).split("\n")
        if len(term) <= first_col - col_spacing:
            lines.append(pad + term.ljust(first_col) + wrapped[0])
            rest = wrapped[1:]
        else:
            lines.append(pad + term)
            rest = wrapped
        for line in rest:
            lines.append(pad + " " * first_col + line)
    return lines
