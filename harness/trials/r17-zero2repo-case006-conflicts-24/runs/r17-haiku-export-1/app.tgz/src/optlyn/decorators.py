"""Declaration decorators: command, group, option, argument and the ready-made parameters."""

import inspect
import sys
from functools import update_wrapper
from importlib import metadata

from ._state import get_current_context
from .core import Argument, Command, Group, Option, _show_help_callback
from .termui import echo


def _attach_param(f, param):
    params = f.__dict__.setdefault("__optlyn_params__", [])
    params.append(param)


def _pop_params(f):
    """Take the declarations attached to ``f``; they are returned in top-down order."""
    attached = f.__dict__.pop("__optlyn_params__", [])
    return list(reversed(attached))


def _default_name(f):
    name = f.__name__.lower()
    for suffix in ("_command", "_cmd", "_group", "_grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def _docstring_help(f):
    doc = f.__doc__
    if not doc:
        return None
    return inspect.cleandoc(doc.split("\f")[0])


# spec: N-000850 N-000851 N-000852
def command(name=None, cls=None, **attrs):
    """Turn a function into a Command. Used as ``@command()`` or ``@command``."""
    if callable(name) and not isinstance(name, str):
        return command(cls=cls, **attrs)(name)

    def decorator(f):
        params = _pop_params(f)
        if attrs.get("help") is None:
            attrs["help"] = _docstring_help(f)
        klass = cls or Command
        return klass(
            name=name if name is not None else _default_name(f),
            callback=f,
            params=params,
            **attrs,
        )

    return decorator


# spec: N-000862 N-000863
def group(name=None, cls=None, **attrs):
    """Turn a function into a Group. Used as ``@group()`` or ``@group``."""
    if callable(name) and not isinstance(name, str):
        return group(cls=cls, **attrs)(name)

    def decorator(f):
        params = _pop_params(f)
        if attrs.get("help") is None:
            attrs["help"] = _docstring_help(f)
        klass = cls or Group
        return klass(
            name=name if name is not None else _default_name(f),
            callback=f,
            params=params,
            **attrs,
        )

    return decorator


def option(*param_decls, cls=None, **attrs):
    """Attach an option to the function it decorates."""

    def decorator(f):
        klass = cls or Option
        _attach_param(f, klass(list(param_decls), **attrs))
        return f

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach a positional argument to the function it decorates."""

    def decorator(f):
        klass = cls or Argument
        _attach_param(f, klass(list(param_decls), **attrs))
        return f

    return decorator


def help_option(*param_decls, **kwargs):
    """Attach an extra eager help flag that prints the help page and exits."""
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _show_help_callback)
    return option(*(param_decls or ("--help",)), **kwargs)


def _caller_package(depth):
    frame = sys._getframe(depth + 1)
    module = frame.f_globals.get("__name__", "") or ""
    return module.partition(".")[0] or None


def _detect_version(package_name):
    try:
        return metadata.version(package_name)
    except metadata.PackageNotFoundError:
        pass
    for dist in metadata.packages_distributions().get(package_name, []):
        try:
            return metadata.version(dist)
        except metadata.PackageNotFoundError:
            continue
    raise RuntimeError(f"Could not detect the version of {package_name!r}; pass version=.")


# spec: N-000930 N-000931
def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None,
                   **kwargs):
    """Attach an eager ``--version`` flag that prints the version identity and exits."""
    if version is None and package_name is None:
        package_name = _caller_package(1)

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        ver = version if version is not None else _detect_version(package_name)
        prog = prog_name or ctx.find_root().info_name
        text = (message or "%(prog)s, version %(version)s") % {"prog": prog, "version": ver}
        echo(text, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*(param_decls or ("--version",)), **kwargs)


# spec: N-000932
def custom_version_option(callback, *param_decls, **kwargs):
    """Attach an eager version flag whose identity is the string ``callback(ctx)`` returns."""

    def version_callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(callback(ctx), color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = version_callback
    return option(*(param_decls or ("--version",)), **kwargs)


def password_option(*param_decls, **kwargs):
    """A prompting, hidden-input option that asks twice."""
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    return option(*(param_decls or ("--password",)), **kwargs)


def confirmation_option(*param_decls, **kwargs):
    """A yes flag that asks when omitted and aborts when the answer is no."""

    def callback(ctx, param, value):
        if not value:
            ctx.abort()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")
    kwargs["callback"] = callback
    return option(*(param_decls or ("--yes",)), **kwargs)


# spec: N-000975
def pass_context(f):
    """Pass the current Context as the first positional argument."""

    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return update_wrapper(new_func, f)


# spec: N-000976
def pass_obj(f):
    """Pass the current context's ``obj`` as the first positional argument."""

    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return update_wrapper(new_func, f)


# spec: N-000977
def make_pass_decorator(object_type, ensure=False):
    """Build a decorator that passes the nearest object of ``object_type`` from the context chain."""

    def decorator(f):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            return ctx.invoke(f, obj, *args, **kwargs)

        return update_wrapper(new_func, f)

    return decorator


__all__ = [
    "argument",
    "command",
    "confirmation_option",
    "custom_version_option",
    "group",
    "help_option",
    "make_pass_decorator",
    "option",
    "pass_context",
    "pass_obj",
    "password_option",
    "version_option",
]
