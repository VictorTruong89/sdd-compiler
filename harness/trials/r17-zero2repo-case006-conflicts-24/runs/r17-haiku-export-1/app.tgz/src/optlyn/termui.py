"""Terminal helpers: echo, styling, prompts, pager, progress, editor and launch."""

import contextlib
import getpass
import io
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import time

from ._state import get_current_context
from .exceptions import Abort, BadParameter
from .paramtypes import resolve_type

_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]")

_COLORS = {
    "black": 0, "red": 1, "green": 2, "yellow": 3, "blue": 4, "magenta": 5, "cyan": 6, "white": 7,
    "bright_black": 60, "bright_red": 61, "bright_green": 62, "bright_yellow": 63,
    "bright_blue": 64, "bright_magenta": 65, "bright_cyan": 66, "bright_white": 67,
}

_SWITCHES = (
    ("bold", "1"), ("dim", "2"), ("italic", "3"), ("underline", "4"), ("blink", "5"),
    ("reverse", "7"), ("strikethrough", "9"), ("overline", "53"),
)


def strip_ansi(text):
    return _ANSI_RE.sub("", text)


def unstyle(text):
    return strip_ansi(text)


def _isatty(stream):
    try:
        return bool(stream.isatty())
    except (AttributeError, ValueError):
        return False


def is_interactive():
    """A session is interactive when standard input or standard output is a terminal."""
    return _isatty(sys.stdin) or _isatty(sys.stdout)


def _context_color():
    ctx = get_current_context(silent=True)
    return None if ctx is None else ctx.color


def _should_keep_style(stream, color):
    if color is None:
        color = _context_color()
    if color is None:
        return _isatty(stream)
    return bool(color)


def _color_code(color, base):
    """Return the SGR parameters for a color; ``base`` is 30 for foreground and 40 for background."""
    if isinstance(color, bool):
        raise ValueError(f"Invalid color {color!r}.")
    if isinstance(color, str):
        if color == "reset":
            return str(base + 9)
        if color in _COLORS:
            return str(base + _COLORS[color])
        raise ValueError(f"Invalid color {color!r}.")
    if isinstance(color, int):
        if 0 <= color <= 255:
            return f"{base + 8};5;{color}"
        raise ValueError(f"Invalid color {color!r}.")
    if isinstance(color, (tuple, list)) and len(color) == 3 and all(
        isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
    ):
        return f"{base + 8};2;{color[0]};{color[1]};{color[2]}"
    raise ValueError(f"Invalid color {color!r}.")


# spec: N-000984 N-000985 N-000986
def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None, italic=None,
          blink=None, reverse=None, strikethrough=None, reset=True):
    """Wrap ``text`` in ANSI SGR sequences. An invalid color raises ValueError."""
    codes = []
    if fg is not None:
        codes.append(_color_code(fg, 30))
    if bg is not None:
        codes.append(_color_code(bg, 40))
    flags = {
        "bold": bold, "dim": dim, "underline": underline, "overline": overline, "italic": italic,
        "blink": blink, "reverse": reverse, "strikethrough": strikethrough,
    }
    for name, code in _SWITCHES:
        if flags.get(name):
            codes.append(code)
    if not codes:
        return text
    prefix = f"\x1b[{';'.join(codes)}m"
    return prefix + text + ("\x1b[0m" if reset else "")


# spec: N-000982 N-000983 N-000981
def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write ``message`` (str or bytes) to stdout, stderr, or ``file``.

    Styles are stripped unless the stream is a terminal or color is forced on.
    """
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        data = message + (b"\n" if nl else b"")
        buffer = getattr(file, "buffer", None)
        if buffer is not None:
            file.flush()
            buffer.write(data)
            buffer.flush()
        else:
            file.write(data.decode("utf-8", "replace"))
        return
    text = str(message) + ("\n" if nl else "")
    if not _should_keep_style(file, color):
        text = strip_ansi(text)
    encoding = (getattr(file, "encoding", None) or "").lower()
    if encoding in ("ascii", "us-ascii") and getattr(file, "buffer", None) is not None:
        file.flush()
        file.buffer.write(text.encode("utf-8"))
        file.buffer.flush()
        return
    file.write(text)
    file.flush()


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None:
        message = style(str(message), **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


class _StripWriter:
    """Text stream wrapper that removes ANSI styles before writing."""

    def __init__(self, stream):
        self._stream = stream

    def write(self, text):
        return self._stream.write(strip_ansi(text))

    def flush(self):
        self._stream.flush()

    def __getattr__(self, name):
        return getattr(self._stream, name)


def _pager_command():
    cmd = os.environ.get("PAGER")
    if cmd:
        return shlex.split(cmd)
    for candidate in ("less", "more"):
        if shutil.which(candidate):
            return [candidate]
    return None


@contextlib.contextmanager
# spec: N-000988
def get_pager_file(color=None):
    """Yield a writable text stream that goes through the pager when the session is interactive."""
    keep = bool(color) if color is not None else False
    command = _pager_command() if is_interactive() else None
    if command is None:
        stream = sys.stdout
        yield stream if keep else _StripWriter(stream)
        return
    proc = subprocess.Popen(command, stdin=subprocess.PIPE, text=True, encoding="utf-8")
    try:
        yield proc.stdin if keep else _StripWriter(proc.stdin)
    finally:
        with contextlib.suppress(BrokenPipeError):
            proc.stdin.close()
        proc.wait()


# spec: N-000987
def echo_via_pager(text_or_generator, color=None):
    """Write text, or chunks of text, through the pager when the session is interactive."""
    value = text_or_generator() if callable(text_or_generator) else text_or_generator
    chunks = [value] if isinstance(value, str) else value
    with get_pager_file(color=color) as stream:
        for chunk in chunks:
            stream.write(chunk)
            stream.flush()


class ProgressBar:
    """Iterates over ``iterable`` while showing progress when attached to a terminal."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, width=36, **options):
        self.iterable = iterable
        if length is None and iterable is not None and hasattr(iterable, "__len__"):
            length = len(iterable)
        self.length = length
        self.label = label or ""
        self.pos = 0
        self.width = width
        self.start = time.time()
        self.visible = not hidden and _isatty(sys.stdout)
        self.hidden = hidden
        self._finished = False
        self._printed_label = False

    def _announce(self):
        if self.label and not self.hidden and not self._printed_label:
            self._printed_label = True
            echo(self.label)

    def _render(self):
        if not self.visible or self.length in (None, 0):
            return
        frac = min(self.pos / self.length, 1.0)
        filled = int(self.width * frac)
        elapsed = time.time() - self.start
        eta = (elapsed / self.pos * (self.length - self.pos)) if self.pos else 0
        bar = "#" * filled + "-" * (self.width - filled)
        echo(f"\r{self.label} [{bar}] {self.pos}/{self.length} eta {int(eta)}s", nl=False)

    def update(self, n_steps):
        self.pos += n_steps
        self._render()

    def __iter__(self):
        if self.iterable is None:
            return
        self._announce()
        for item in self.iterable:
            yield item
            self.update(1)

    def finish(self):
        if self._finished:
            return
        self._finished = True
        if self.visible:
            echo("")

    def __enter__(self):
        self._announce()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.finish()


# spec: N-000989 N-000990 N-000991 N-000992
def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)


def _read_line(hide_input=False):
    stream = sys.stdin
    if hide_input and _isatty(stream):
        return getpass.getpass("")
    line = stream.readline()
    if isinstance(line, bytes):
        line = line.decode("utf-8", "replace")
    if line == "":
        raise Abort()
    line = line.rstrip("\r\n")
    if getattr(stream, "_optlyn_runner", False) and not hide_input and not getattr(
            stream, "_optlyn_echo_stdin", False):
        echo(line)
    return line


def _prompt_loop(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
                 show_default=True):
    """Ask until a valid value is given. Returns ``(answered, converted_value)``.

    When the answer is empty and a default is set, returns ``(False, None)`` so the caller uses the
    default.
    """
    param_type = resolve_type(type, default)
    shown = ""
    if show_default and default is not None and not hide_input:
        shown = f" [{default}]"
    while True:
        echo(f"{text}{shown}: ", nl=False)
        answer = _read_line(hide_input)
        if confirmation_prompt:
            echo("Repeat for confirmation: ", nl=False)
            again = _read_line(hide_input)
            if again != answer:
                echo("Error: The two entered values do not match.", err=True)
                continue
        if answer == "":
            if default is not None:
                return False, None
            continue
        try:
            return True, param_type.convert(answer, None, None)
        except BadParameter as e:
            echo(f"Error: {e.message}", err=True)


# spec: N-000993
def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False):
    """Ask for a value and return it converted to ``type`` (or the type of ``default``)."""
    answered, value = _prompt_loop(
        text, default=default, hide_input=hide_input,
        confirmation_prompt=confirmation_prompt, type=type, show_default=show_default,
    )
    if answered:
        return value
    return resolve_type(type, default).convert(default, None, None)


_YES = {"y", "yes"}
_NO = {"n", "no"}


# spec: N-000994
def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    """Ask a yes/no question. Returns a bool; ``abort=True`` aborts on a no."""
    suffix = " [Y/n]" if default else " [y/N]"
    while True:
        echo(f"{text}{suffix}{prompt_suffix}", nl=False)
        answer = _read_line().strip().lower()
        if answer == "":
            value = bool(default)
            break
        if answer in _YES:
            value = True
            break
        if answer in _NO:
            value = False
            break
    if abort and not value:
        raise Abort()
    return value


# spec: N-000995
def getchar(echo=False):
    """Read one character from the controlling terminal (or standard input without one).

    An interrupt key raises KeyboardInterrupt and an end-of-file key raises EOFError.
    """
    char = None
    try:
        import termios
        import tty

        with open("/dev/tty", "rb", buffering=0) as tty_in:
            fd = tty_in.fileno()
            old = termios.tcgetattr(fd)
            try:
                tty.setraw(fd)
                data = os.read(fd, 1)
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
        char = data.decode("utf-8", "replace")
    except (OSError, ImportError, ValueError):
        char = sys.stdin.read(1)
        if isinstance(char, bytes):
            char = char.decode("utf-8", "replace")
    if char == "":
        raise EOFError()
    if char == "\x03":
        raise KeyboardInterrupt()
    if char == "\x04":
        raise EOFError()
    if echo:
        globals()["echo"](char, nl=False)
    return char


# spec: N-000996
def pause(info=None, err=False):
    """Print a message and wait for a key press when interactive; never block otherwise."""
    if info is None:
        info = "Press any key to continue..."
    echo(info, err=err)
    if is_interactive():
        getchar()
        echo("", err=err)


# spec: N-000997 N-000998 N-000999
def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Open an editor on ``text`` (or on ``filename``) and return the saved text.

    Returns None when the text is unchanged and ``require_save`` is set, and always None when
    ``filename`` is given.
    """
    if editor is None:
        editor = (
            os.environ.get("VISUAL") or os.environ.get("EDITOR")
            or ("notepad" if os.name == "nt" else "vi")
        )
    run_env = dict(os.environ)
    if env:
        run_env.update(env)
    if filename is not None:
        subprocess.call(shlex.split(editor) + [os.fspath(filename)], env=run_env)
        return None
    original = text or ""
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(original.replace("\r\n", "\n").encode("utf-8"))
        subprocess.call(shlex.split(editor) + [path], env=run_env)
        with open(path, "rb") as f:
            result = f.read().decode("utf-8", "replace").replace("\r\n", "\n")
    finally:
        os.remove(path)
    if require_save and result == original:
        return None
    return result


# spec: N-001000 N-001001
def launch(url, wait=False, locate=False):
    """Open ``url`` or a path with the default application. Returns the opener's status."""
    if sys.platform.startswith("win"):
        os.startfile(url)  # noqa: S606 - platform-specific opener
        return 0
    opener = "open" if sys.platform == "darwin" else "xdg-open"
    args = [opener]
    if locate and sys.platform == "darwin":
        args.append("-R")
    args.append(url)
    try:
        proc = subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0


# spec: N-001002
def clear():
    """Clear the terminal screen. Does nothing when standard output is not a terminal."""
    if _isatty(sys.stdout):
        sys.stdout.write("\x1b[2J\x1b[H")
        sys.stdout.flush()
