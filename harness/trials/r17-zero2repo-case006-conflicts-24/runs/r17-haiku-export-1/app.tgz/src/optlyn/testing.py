"""In-process runner: invoke a command with tokens and capture its output and status."""

import contextlib
import io
import os
import sys
import tempfile


# spec: N-001039 N-001040 N-001041
class Result:
    """What a run produced: exit status, captured output, and any exception."""

    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value, exit_code,
                 exception):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception

    @property
    def output(self):
        return self.output_bytes.decode(self.runner.charset, "replace")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    def __repr__(self):
        return f"<Result exit_code={self.exit_code!r}>"


class _Sink(io.RawIOBase):
    """A write-only stream that records each write, tagged with its stream name, in a shared log."""

    def __init__(self, name, log):
        self.name = name
        self._log = log
        self.data = bytearray()

    def writable(self):
        return True

    def write(self, b):
        chunk = bytes(b)
        self.data.extend(chunk)
        self._log.append((self.name, chunk))
        return len(chunk)


class _RunnerInput(io.TextIOWrapper):
    """Standard input for a run. Marks itself so prompts know input is simulated."""

    _optlyn_runner = True

    def __init__(self, data, encoding):
        super().__init__(io.BytesIO(data), encoding=encoding)
        self._optlyn_echo_stdin = False
        self._echo_fn = None

    def readline(self, *args):
        line = super().readline(*args)
        if line and self._optlyn_echo_stdin and self._echo_fn is not None:
            self._echo_fn(line)
        return line


# spec: N-001038 N-001042 N-001043 N-001044
class CliRunner:
    """Invokes a command in-process with argument tokens and captures what it writes.

    The runner changes interpreter state and is not thread-safe.
    """

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        """Swap the standard streams for captured ones for the duration of the block."""
        log = []
        out = _Sink("stdout", log)
        err = _Sink("stderr", log)
        stdout = io.TextIOWrapper(out, encoding=self.charset, errors="replace", write_through=True)
        stderr = io.TextIOWrapper(err, encoding=self.charset, errors="replace", write_through=True)
        if isinstance(input, str):
            data = input.encode(self.charset)
        elif isinstance(input, bytes):
            data = input
        else:
            data = b""
        stdin = _RunnerInput(data, self.charset)
        stdin._optlyn_echo_stdin = self.echo_stdin
        stdin._echo_fn = lambda text: stdout.write(text)

        saved_env = {}
        merged = dict(self.env)
        merged.update(env or {})
        for key, value in merged.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)

        saved_streams = (sys.stdin, sys.stdout, sys.stderr)
        fd_files = None
        if self.capture == "fd":
            fd_files = self._redirect_fds()
            sys.stdout = io.TextIOWrapper(io.FileIO(1, "w", closefd=False),
                                          encoding=self.charset, write_through=True)
            sys.stderr = io.TextIOWrapper(io.FileIO(2, "w", closefd=False),
                                          encoding=self.charset, write_through=True)
        else:
            sys.stdout = stdout
            sys.stderr = stderr
        sys.stdin = stdin
        try:
            yield log
        finally:
            for stream in (sys.stdout, sys.stderr):
                with contextlib.suppress(Exception):
                    stream.flush()
            if fd_files is not None:
                self._restore_fds(fd_files, log)
            sys.stdin, sys.stdout, sys.stderr = saved_streams
            for key, value in saved_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def _redirect_fds(self):
        import tempfile as _tmp

        saved = (os.dup(1), os.dup(2))
        out_file = _tmp.TemporaryFile()
        err_file = _tmp.TemporaryFile()
        sys.stdout.flush()
        sys.stderr.flush()
        os.dup2(out_file.fileno(), 1)
        os.dup2(err_file.fileno(), 2)
        return saved, out_file, err_file

    def _restore_fds(self, fd_files, log):
        saved, out_file, err_file = fd_files
        for stream in (sys.stdout, sys.stderr):
            with contextlib.suppress(Exception):
                stream.flush()
        os.dup2(saved[0], 1)
        os.dup2(saved[1], 2)
        os.close(saved[0])
        os.close(saved[1])
        out_file.seek(0)
        err_file.seek(0)
        log.append(("stdout", out_file.read()))
        log.append(("stderr", err_file.read()))
        out_file.close()
        err_file.close()

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False,
               **extra):
        """Run ``cli`` with ``args`` (a list of tokens) and return a Result."""
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        prog_name = extra.pop("prog_name", None) or cli.name or "root"
        standalone = extra.pop("standalone_mode", True)
        extra.setdefault("color", color)

        exit_code = 0
        exception = None
        return_value = None
        with self.isolation(input=input, env=env) as log:
            try:
                return_value = cli.main(
                    args=list(args or []),
                    prog_name=prog_name,
                    standalone_mode=standalone,
                    **extra,
                )
            except SystemExit as e:
                if e.code is None:
                    exit_code = 0
                elif isinstance(e.code, int):
                    exit_code = e.code
                else:
                    sys.stderr.write(str(e.code) + "\n")
                    exit_code = 1
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
        stdout_bytes = b"".join(chunk for name, chunk in log if name == "stdout")
        stderr_bytes = b"".join(chunk for name, chunk in log if name == "stderr")
        output_bytes = b"".join(chunk for _name, chunk in log)
        return Result(
            self,
            stdout_bytes=stdout_bytes,
            stderr_bytes=stderr_bytes,
            output_bytes=output_bytes,
            return_value=return_value,
            exit_code=exit_code,
            exception=exception,
        )

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Change into a new empty directory for the block and yield its path.

        The directory is left in place after the block, so its files can be inspected.
        """
        cwd = os.getcwd()
        path = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
