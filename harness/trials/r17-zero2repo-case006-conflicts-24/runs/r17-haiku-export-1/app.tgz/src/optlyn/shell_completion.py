"""Shell completion for bash, zsh, fish and PowerShell.

Completion mode is selected by an environment variable named after the program. Its value is
``<shell>_source`` (print the registration script) or ``<shell>_complete`` (print suggestions).

Suggestion stream format: one suggestion per line. Zsh and fish lines carry ``value<TAB>help`` when
help is set. A path request is a line ``@@file:<token>`` or ``@@dir:<token>``, which the registration
script turns into a filesystem completion.
"""

import os
import sys

from .core import Context, Group
from .paramtypes import CompletionItem

SHELLS = ("bash", "zsh", "fish", "powershell")
INSTRUCTIONS = ("source", "complete")


def _script_name(prog_name):
    return "_" + "".join(c if c.isalnum() else "_" for c in prog_name) + "_completion"


def _bash_script(prog_name, complete_var):
    func = _script_name(prog_name)
    return f"""{func}() {{
    local response line
    local IFS=$'\\n'
    response=$(env COMP_WORDS="${{COMP_WORDS[*]}}" COMP_CWORD=$COMP_CWORD {complete_var}=bash_complete "$1")
    COMPREPLY=()
    for line in $response; do
        case "$line" in
            @@file:*) COMPREPLY+=($(compgen -f -- "${{line#@@file:}}")) ;;
            @@dir:*) COMPREPLY+=($(compgen -d -- "${{line#@@dir:}}")) ;;
            *) COMPREPLY+=("$line") ;;
        esac
    done
}}
complete -o default -F {func} {prog_name}
"""


def _zsh_script(prog_name, complete_var):
    func = _script_name(prog_name)
    return f"""#compdef {prog_name}
{func}() {{
    local -a response plain
    local line value help
    response=("${{(@f)$(env COMP_WORDS="${{words[*]}}" COMP_CWORD=$((CURRENT-1)) {complete_var}=zsh_complete "${{words[1]}}")}}")
    for line in $response; do
        case "$line" in
            @@file:*) _files ;;
            @@dir:*) _files -/ ;;
            *) value="${{line%%$'\\t'*}}"; help="${{line#*$'\\t'}}"
               if [[ "$line" == *$'\\t'* ]]; then plain+=("$value:$help"); else plain+=("$value"); fi ;;
        esac
    done
    _describe 'values' plain
}}
compdef {func} {prog_name}
"""


def _fish_script(prog_name, complete_var):
    return (
        f"complete --command {prog_name} --no-files --arguments "
        f"'(env COMP_WORDS=\"(commandline -cp)\" COMP_CWORD=\"(commandline -ct)\" "
        f"{complete_var}=fish_complete {prog_name})'\n"
    )


def _powershell_script(prog_name, complete_var):
    return f"""Register-ArgumentCompleter -Native -CommandName '{prog_name}' -ScriptBlock {{
    param($wordToComplete, $commandAst, $cursorPosition)
    $words = $commandAst.ToString()
    $env:COMP_WORDS = $words
    $env:COMP_CWORD = $wordToComplete.Length
    $env:{complete_var} = 'powershell_complete'
    & '{prog_name}' | Out-Null
    Remove-Item Env:\\{complete_var}
}}
"""


_SCRIPTS = {
    "bash": _bash_script,
    "zsh": _zsh_script,
    "fish": _fish_script,
    "powershell": _powershell_script,
}


def registration_script(shell, prog_name, complete_var):
    return _SCRIPTS[shell](prog_name, complete_var)


def _option_at(params, token, normalize):
    for p in params:
        if p.kind != "option":
            continue
        if normalize(token) in {normalize(n) for n in list(p.opts) + list(p.secondary_opts)}:
            return p
    return None


def _takes_value(p):
    return not (p.is_flag or p.count)


def get_completions(cli, prog_name, args, incomplete):
    """Return the CompletionItems for ``incomplete`` after the tokens ``args``."""
    normalize = (lambda s: s)
    ctx = Context(cli, info_name=prog_name)
    current = cli
    current_ctx = ctx
    pending = None
    positional_count = 0
    options_done = False
    for tok in args:
        if pending is not None:
            pending = None
            continue
        if tok == "--" and not options_done:
            options_done = True
            continue
        if not options_done and len(tok) > 1 and tok[0] in "-/+":
            opt = _option_at(current.get_params(current_ctx), tok.partition("=")[0], normalize)
            if opt is not None and _takes_value(opt) and "=" not in tok:
                pending = opt
            continue
        if isinstance(current, Group):
            sub = current.get_command(current_ctx, tok)
            if sub is not None:
                current_ctx = Context(sub, info_name=tok, parent=current_ctx)
                current = sub
                positional_count = 0
                continue
        positional_count += 1

    if pending is not None:
        return [_as_item(i) for i in pending.complete(current_ctx, incomplete)]

    items = []
    params = current.get_params(current_ctx)
    if incomplete.startswith("-"):
        for p in params:
            if p.kind != "option" or p.hidden:
                continue
            for name in list(p.opts) + list(p.secondary_opts):
                if name.startswith(incomplete):
                    items.append(CompletionItem(name, help=p.help))
        return items

    if isinstance(current, Group):
        for name in current.list_commands(current_ctx):
            sub = current.get_command(current_ctx, name)
            if sub is None or sub.hidden or not name.startswith(incomplete):
                continue
            items.append(CompletionItem(name, help=sub.get_short_help_str() or None))

    arguments = [p for p in params if p.kind == "argument"]
    if not isinstance(current, Group) and positional_count < len(arguments):
        items.extend(arguments[positional_count].complete(current_ctx, incomplete))
    return [_as_item(i) for i in items]


def _as_item(item):
    if isinstance(item, CompletionItem):
        return item
    if hasattr(item, "value"):
        return CompletionItem(item.value, help=getattr(item, "help", None),
                              type=getattr(item, "type", "plain"))
    return CompletionItem(item)


def _format_items(shell, items):
    lines = []
    for item in items:
        if item.type in ("file", "dir"):
            lines.append(f"@@{item.type}:{item.value}")
        elif shell in ("zsh", "fish") and item.help:
            lines.append(f"{item.value}\t{item.help}")
        else:
            lines.append(item.value)
    return lines


# spec: N-001015 N-001021 N-001023 N-001030
def run_completion(cli, prog_name, complete_var, value):
    """Handle a completion request. Returns the process exit status."""
    shell, _, instruction = value.rpartition("_")
    if shell not in SHELLS or instruction not in INSTRUCTIONS:
        sys.stderr.write(f"Unsupported completion instruction: {value}\n")
        return 1
    if instruction == "source":
        sys.stdout.write(registration_script(shell, prog_name, complete_var))
        sys.stdout.flush()
        return 0

    raw_words = os.environ.get("COMP_WORDS", "")
    words = raw_words.split(" ") if raw_words else []
    if shell == "fish":
        incomplete = os.environ.get("COMP_CWORD", "")
        if words and words[-1] == incomplete:
            words = words[:-1]
        tokens = words[1:]
    else:
        try:
            cword = int(os.environ.get("COMP_CWORD", str(len(words))))
        except ValueError:
            cword = len(words)
        tokens = words[1:cword]
        incomplete = words[cword] if cword < len(words) else ""
    items = get_completions(cli, prog_name, tokens, incomplete)
    for line in _format_items(shell, items):
        sys.stdout.write(line + "\n")
    sys.stdout.flush()
    return 0


__all__ = ["get_completions", "registration_script", "run_completion"]
