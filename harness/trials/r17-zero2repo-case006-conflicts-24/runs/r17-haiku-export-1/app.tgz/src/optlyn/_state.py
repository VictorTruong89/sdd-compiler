"""Per-thread stack of the invocation contexts that are currently entered."""

import threading

_local = threading.local()


def _stack():
    stack = getattr(_local, "stack", None)
    if stack is None:
        stack = _local.stack = []
    return stack


def push_context(ctx):
    _stack().append(ctx)


def pop_context():
    _stack().pop()


# spec: N-000978 N-000979 N-000980
def get_current_context(silent=False):
    """Return the context current on this thread.

    Raises RuntimeError when there is none, unless ``silent`` is true, in which case it returns None.
    """
    stack = _stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")
