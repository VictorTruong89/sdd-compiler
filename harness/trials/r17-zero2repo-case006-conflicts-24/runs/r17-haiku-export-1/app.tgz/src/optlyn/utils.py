"""File opening, file naming and per-user application directory helpers."""

import os
import re
import sys
import tempfile

from .exceptions import FileError

_WHITESPACE_RUN = re.compile(r"\s+")


class _StdStream:
    """Proxy over a standard stream whose ``close`` does nothing.

    Standard streams stay open when a caller's ``with`` block ends.
    """

    def __init__(self, stream):
        self._stream = stream

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __iter__(self):
        return iter(self._stream)

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self._stream.flush()


def _dash_stream(mode):
    write = any(c in mode for c in "wax")
    stream = sys.stdout if write else sys.stdin
    if "b" in mode:
        stream = getattr(stream, "buffer", stream)
    return _StdStream(stream)


def _real_open(filename, mode, encoding, errors):
    if "b" in mode:
        return open(filename, mode)
    return open(filename, mode, encoding=encoding, errors=errors)


class LazyFile:
    """A file that is opened on its first I/O rather than when created."""

    def __init__(self, filename, mode, encoding=None, errors="strict"):
        self.name = filename
        self.mode = mode
        self._encoding = encoding
        self._errors = errors
        self._file = None

    def _open(self):
        if self._file is None:
            try:
                self._file = _real_open(self.name, self.mode, self._encoding, self._errors)
            except OSError as e:
                raise FileError(self.name, e.strerror) from e
        return self._file

    def __getattr__(self, name):
        return getattr(self._open(), name)

    def __iter__(self):
        return iter(self._open())

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def close(self):
        if self._file is not None:
            self._file.close()


class AtomicFile:
    """Writes to a sibling temporary file that replaces the target when closed."""

    def __init__(self, filename, mode, encoding=None, errors="strict"):
        self.name = filename
        self._target = filename
        directory = os.path.dirname(os.path.abspath(filename))
        fd, self._tmp = tempfile.mkstemp(dir=directory, prefix=".optlyn-", suffix=".tmp")
        if "b" in mode:
            self._file = os.fdopen(fd, mode)
        else:
            self._file = os.fdopen(fd, mode, encoding=encoding, errors=errors)
        self._closed = False

    def __getattr__(self, name):
        return getattr(self._file, name)

    def __iter__(self):
        return iter(self._file)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def close(self):
        if self._closed:
            return
        self._closed = True
        self._file.close()
        os.replace(self._tmp, self._target)


# spec: N-001007 N-001008
def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open ``filename``; ``-`` is the standard input (read) or output (write) stream."""
    if filename == "-":
        return _dash_stream(mode)
    if atomic and any(c in mode for c in "wax"):
        return AtomicFile(filename, mode, encoding, errors)
    if lazy:
        return LazyFile(filename, mode, encoding, errors)
    return _real_open(filename, mode, encoding, errors)


# spec: N-001006
def format_filename(filename, shorten=False):
    """Return ``filename`` as printable text that encodes as strict UTF-8.

    Undecodable bytes are escaped, so different names stay different.
    """
    if hasattr(filename, "__fspath__"):
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        text = os.fsdecode(filename)
    else:
        text = str(filename)
    if shorten:
        text = os.path.basename(text)
    return text.encode("utf-8", "backslashreplace").decode("utf-8")


# spec: N-001003 N-001004 N-001005
def get_app_dir(app_name, roaming=True, force_posix=False):
    """Return the per-user configuration directory for ``app_name``.

    ``roaming`` is accepted; it has no effect on POSIX platforms.
    """
    home = os.path.expanduser("~")
    folder = _WHITESPACE_RUN.sub("-", app_name.lower())
    if force_posix:
        return os.path.join(home, "." + folder)
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    if sys.platform.startswith("win"):
        base = os.environ.get("APPDATA") or home
        return os.path.join(base, app_name)
    config_home = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(config_home, folder)
