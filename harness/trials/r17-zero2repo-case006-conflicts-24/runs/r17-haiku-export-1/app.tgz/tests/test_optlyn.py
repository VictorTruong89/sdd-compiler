"""Behaviour tests for Optlyn, organised by feature point of the specification."""

import enum
import os
import pathlib

import pytest

import optlyn
from optlyn import (
    Abort,
    BadParameter,
    Choice,
    Context,
    DateTime,
    File,
    FloatRange,
    IntRange,
    Path,
    Tuple,
    argument,
    command,
    confirmation_option,
    custom_version_option,
    echo,
    group,
    make_pass_decorator,
    option,
    pass_context,
    pass_obj,
    password_option,
    version_option,
)
from optlyn.decorators import help_option
from optlyn.formatting import wrap_text
from optlyn.testing import CliRunner
from optlyn.utils import format_filename, get_app_dir


@pytest.fixture
def runner():
    return CliRunner()


# -- FP-01: declaration, naming and invocation ---------------------------------------------------

@pytest.mark.parametrize(
    "func_name, expected",
    [
        ("hello_world", "hello-world"),
        ("sync_cmd", "sync"),
        ("build_group", "build"),
        ("deploy_grp", "deploy"),
        ("status", "status"),
    ],
)
def test_default_command_names_strip_suffixes(func_name, expected):
    def placeholder():
        pass

    placeholder.__name__ = func_name
    cmd = command()(placeholder)
    assert cmd.name == expected


def test_explicit_name_is_used_alone(runner):
    @command("run-it")
    def whatever():
        echo("ran")

    assert runner.invoke(whatever, []).exit_code == 0
    assert whatever.name == "run-it"


def test_success_exit_status_and_output(runner):
    @command()
    def ok():
        echo("done")

    res = runner.invoke(ok, [])
    assert res.exit_code == 0
    assert res.output == "done\n"


def test_deprecated_command_runs_and_warns(runner):
    @command(deprecated="Use something else.")
    def old():
        echo("ran")

    res = runner.invoke(old, [])
    assert res.exit_code == 0
    assert "ran" in res.stdout
    assert "DeprecationWarning" in res.stderr
    assert "Use something else." in res.stderr


def test_unknown_option_is_usage_error_and_callback_not_run(runner):
    ran = []

    @command()
    def cmd():
        ran.append(True)

    res = runner.invoke(cmd, ["--nope"])
    assert res.exit_code == 2
    assert ran == []


def test_declarations_move_from_function_to_command():
    def body(a):
        pass

    body = option("--a")(body)
    cmd = command()(body)
    assert [p.name for p in cmd.params] == ["a"]
    assert "__optlyn_params__" not in body.__dict__


def test_standalone_off_returns_callback_value_and_raises_failures():
    @command()
    @option("--n", type=int)
    def double(n):
        return n * 2

    assert double.main(["--n", "4"], standalone_mode=False) == 8
    with pytest.raises(BadParameter):
        double.main(["--n", "x"], standalone_mode=False)


# -- FP-02: help and version --------------------------------------------------------------------

def test_help_prints_page_and_skips_callback(runner):
    ran = []

    @command()
    @option("--count", type=int, help="How many.")
    def cmd(count):
        """Do the thing.

        Long description.
        """
        ran.append(True)

    res = runner.invoke(cmd, ["--help"])
    assert res.exit_code == 0
    assert ran == []
    assert res.stdout.startswith("Usage:")
    assert "Do the thing." in res.stdout
    assert "--count INTEGER" in res.stdout
    assert "How many." in res.stdout


def test_form_feed_truncates_docstring_help(runner):
    @command()
    def cmd():
        """Visible.\f hidden part"""

    res = runner.invoke(cmd, ["--help"])
    assert "Visible." in res.stdout
    assert "hidden part" not in res.stdout


def test_group_without_subcommand_is_usage_failure(runner):
    @group()
    def cli():
        """Root."""

    res = runner.invoke(cli, [])
    assert res.exit_code == 2
    assert "Usage:" in res.stderr or "Usage:" in res.output


def test_help_before_subcommand_is_help_for_group(runner):
    @group()
    def cli():
        pass

    @cli.command()
    def sub():
        echo("sub ran")

    res = runner.invoke(cli, ["--help", "sub"])
    assert res.exit_code == 0
    assert "sub ran" not in res.output


def test_version_option_prints_identity_and_exits(runner):
    @command()
    @version_option("1.2.3", prog_name="tool")
    def cmd():
        echo("ran")

    res = runner.invoke(cmd, ["--version"])
    assert res.exit_code == 0
    assert "1.2.3" in res.stdout
    assert "ran" not in res.stdout


def test_custom_version_option_prints_callback_string_exactly(runner):
    @command()
    @custom_version_option(lambda ctx: "custom identity")
    def cmd():
        pass

    res = runner.invoke(cmd, ["--version"])
    assert res.stdout == "custom identity\n"


def test_first_eager_flag_typed_wins(runner):
    @command()
    @version_option("9.9", prog_name="tool")
    def cmd():
        pass

    res = runner.invoke(cmd, ["--version", "--help"])
    assert "9.9" in res.stdout
    assert "Show this message" not in res.stdout


def test_help_option_names_can_be_replaced_through_context(runner):
    @command(context_settings={"help_option_names": ["-h"]})
    def cmd():
        echo("ran")

    assert runner.invoke(cmd, ["-h"]).exit_code == 0
    assert runner.invoke(cmd, ["--help"]).exit_code == 2


def test_author_option_reusing_help_name_drops_automatic_help(runner):
    @command()
    @option("--help", is_flag=True)
    def cmd(help):
        echo(f"help={help}")

    res = runner.invoke(cmd, ["--help"])
    assert res.stdout == "help=True\n"


def test_show_default_hides_false_flag_default(runner):
    @command(context_settings={"show_default": True})
    @option("--on", is_flag=True)
    @option("--count", type=int, default=3)
    def cmd(on, count):
        pass

    res = runner.invoke(cmd, ["--help"])
    assert "[default: 3]" in res.stdout
    assert "[default: False]" not in res.stdout


# -- FP-03: options -----------------------------------------------------------------------------

def test_short_flags_stack_and_value_attaches(runner):
    @command()
    @option("-a", is_flag=True)
    @option("-b", is_flag=True)
    @option("-c")
    def cmd(a, b, c):
        echo(f"{a} {b} {c}")

    res = runner.invoke(cmd, ["-abcVALUE"])
    assert res.stdout == "True True VALUE\n"


def test_double_dash_ends_option_parsing(runner):
    @command()
    @option("--flag", is_flag=True)
    @argument("rest", nargs=-1)
    def cmd(flag, rest):
        echo(f"{flag} {rest}")

    res = runner.invoke(cmd, ["--", "--flag", "x"])
    assert res.stdout == "False ('--flag', 'x')\n"


def test_multiple_option_collects_in_order(runner):
    @command()
    @option("-i", "--item", multiple=True)
    def cmd(item):
        echo(repr(item))

    assert runner.invoke(cmd, ["-i", "a", "--item=b"]).stdout == "('a', 'b')\n"
    assert runner.invoke(cmd, []).stdout == "()\n"


def test_nargs_option_takes_fixed_tokens(runner):
    @command()
    @option("--pair", nargs=2, type=int)
    def cmd(pair):
        echo(repr(pair))

    assert runner.invoke(cmd, ["--pair", "1", "2"]).stdout == "(1, 2)\n"
    assert runner.invoke(cmd, ["--pair", "1"]).exit_code == 2


def test_count_option(runner):
    @command()
    @option("-v", count=True)
    def cmd(v):
        echo(str(v))

    assert runner.invoke(cmd, ["-vvv"]).stdout == "3\n"
    assert runner.invoke(cmd, []).stdout == "0\n"


def test_feature_switch_pair_on_off(runner):
    @command()
    @option("--shout/--quiet", default=False)
    def cmd(shout):
        echo(str(shout))

    assert runner.invoke(cmd, ["--shout"]).stdout == "True\n"
    assert runner.invoke(cmd, ["--quiet"]).stdout == "False\n"


def test_feature_switch_shared_destination(runner):
    @command()
    @option("--upper", "mode", flag_value="upper")
    @option("--lower", "mode", flag_value="lower")
    def cmd(mode):
        echo(str(mode))

    assert runner.invoke(cmd, ["--lower"]).stdout == "lower\n"
    assert runner.invoke(cmd, []).stdout == "None\n"


def test_required_option_missing_is_usage_error(runner):
    @command()
    @option("--name", required=True)
    def cmd(name):
        pass

    res = runner.invoke(cmd, [])
    assert res.exit_code == 2
    assert "--name" in res.stderr


def test_repeatable_option_requires_iterable_default(runner):
    @command()
    @option("--item", multiple=True, default="abc")
    def cmd(item):
        pass

    res = runner.invoke(cmd, [])
    assert res.exit_code == 2
    assert "iterable" in res.output


def test_deprecated_required_option_refused_at_declaration():
    with pytest.raises(Exception):
        @command()
        @option("--old", deprecated=True, required=True)
        def cmd(old):
            pass


def test_option_callback_refusal_is_usage_error(runner):
    def refuse(ctx, param, value):
        raise BadParameter("nope", ctx=ctx, param=param)

    @command()
    @option("--x", callback=refuse)
    def cmd(x):
        pass

    res = runner.invoke(cmd, ["--x", "1"])
    assert res.exit_code == 2
    assert "--x" in res.stderr


# -- FP-04: positional arguments --------------------------------------------------------------

def test_argument_binding_and_variadic(runner):
    @command()
    @argument("src")
    @argument("dst", nargs=-1)
    def cmd(src, dst):
        echo(f"{src} {dst}")

    assert runner.invoke(cmd, ["a", "b", "c"]).stdout == "a ('b', 'c')\n"


def test_missing_required_argument_names_it(runner):
    @command()
    @argument("name")
    def cmd(name):
        pass

    res = runner.invoke(cmd, [])
    assert res.exit_code == 2
    assert "name" in res.stderr


def test_extra_argument_is_usage_error_unless_allowed(runner):
    @command()
    @argument("a")
    def cmd(a):
        pass

    assert runner.invoke(cmd, ["x", "y"]).exit_code == 2


# -- FP-05: parameter types ----------------------------------------------------------------------

class Color(enum.Enum):
    red = 1
    blue = 2


def test_choice_is_case_sensitive_by_default(runner):
    @command()
    @option("--c", type=Choice(["red", "blue"]))
    def cmd(c):
        echo(c)

    assert runner.invoke(cmd, ["--c", "red"]).stdout == "red\n"
    assert runner.invoke(cmd, ["--c", "RED"]).exit_code == 2


def test_choice_enum_delivers_member(runner):
    @command()
    @option("--c", type=Choice(Color, case_sensitive=False))
    def cmd(c):
        echo(repr(c))

    assert runner.invoke(cmd, ["--c", "BLUE"]).stdout == "<Color.blue: 2>\n"


def test_int_range_clamps_closed_and_open_bounds(runner):
    @command()
    @option("--r", type=IntRange(0, 10, clamp=True))
    @option("--o", type=IntRange(0, 10, min_open=True, clamp=True))
    def cmd(r, o):
        echo(f"{r} {o}")

    assert runner.invoke(cmd, ["--r", "99", "--o", "0"]).stdout == "10 1\n"


def test_int_range_refuses_out_of_range_without_clamp(runner):
    @command()
    @option("--r", type=IntRange(0, 10))
    def cmd(r):
        pass

    assert runner.invoke(cmd, ["--r", "11"]).exit_code == 2


def test_float_range_refuses_clamp_with_open_bound():
    with pytest.raises(Exception):
        FloatRange(0, 1, min_open=True, clamp=True)


def test_datetime_default_formats_and_replacement(runner):
    @command()
    @option("--d", type=DateTime())
    def cmd(d):
        echo(d.isoformat(sep=" "))

    assert runner.invoke(cmd, ["--d", "2020-01-02T03:04:05"]).stdout == "2020-01-02 03:04:05\n"
    assert runner.invoke(cmd, ["--d", "02/01/2020"]).exit_code == 2


def test_tuple_type_converts_each_position(runner):
    @command()
    @option("--t", type=Tuple([str, int]))
    def cmd(t):
        echo(repr(t))

    assert runner.invoke(cmd, ["--t", "a", "3"]).stdout == "('a', 3)\n"
    assert runner.invoke(cmd, ["--t", "a", "x"]).exit_code == 2


def test_custom_conversion_function_refusal(runner):
    def positive(value):
        number = int(value)
        if number <= 0:
            raise ValueError("must be positive")
        return number

    @command()
    @option("--n", type=positive)
    def cmd(n):
        echo(str(n))

    assert runner.invoke(cmd, ["--n", "4"]).stdout == "4\n"
    assert runner.invoke(cmd, ["--n", "-1"]).exit_code == 2


# -- FP-06: groups ----------------------------------------------------------------------------

def test_group_callback_runs_before_child(runner):
    @group()
    def cli():
        echo("group")

    @cli.command()
    def sub():
        echo("child")

    res = runner.invoke(cli, ["sub"])
    assert res.stdout == "group\nchild\n"


def test_unknown_subcommand_does_not_run_group_callback(runner):
    @group()
    def cli():
        echo("group")

    res = runner.invoke(cli, ["nope"])
    assert res.exit_code == 2
    assert "group" not in res.output


def test_nested_groups_dispatch_outside_in(runner):
    @group()
    def outer():
        echo("outer")

    @outer.group()
    def inner():
        echo("inner")

    @inner.command()
    def leaf():
        echo("leaf")

    assert runner.invoke(outer, ["inner", "leaf"]).stdout == "outer\ninner\nleaf\n"


def test_hidden_command_dispatches_but_not_listed(runner):
    @group()
    def cli():
        pass

    @cli.command(hidden=True)
    def secret():
        echo("secret")

    assert runner.invoke(cli, ["secret"]).stdout == "secret\n"
    assert "secret" not in runner.invoke(cli, ["--help"]).stdout


def test_group_attached_beneath_chain_group_is_refused():
    @group(chain=True)
    def chained():
        pass

    @group()
    def nested():
        pass

    with pytest.raises(Exception):
        chained.add_command(nested)


def test_command_collection_unions_sources(runner):
    @group()
    def one():
        pass

    @one.command()
    def alpha():
        echo("alpha")

    @group()
    def two():
        pass

    @two.command()
    def beta():
        echo("beta")

    collection = group(cls=optlyn.CommandCollection, sources=[one, two])(lambda: None)
    assert runner.invoke(collection, ["alpha"]).stdout == "alpha\n"
    assert runner.invoke(collection, ["beta"]).stdout == "beta\n"


def test_no_args_is_help_for_leaf_when_configured(runner):
    @command(no_args_is_help=True)
    @argument("x", required=False)
    def cmd(x):
        echo("ran")

    res = runner.invoke(cmd, [])
    assert res.exit_code == 2
    assert "ran" not in res.output


# -- FP-07: context, defaults, environment ---------------------------------------------------

def test_default_map_applies_to_leaf_and_nested(runner):
    @group()
    @option("--g", default="g0")
    def cli(g):
        echo(f"g={g}")

    @cli.command()
    @option("--x", default=1)
    def sub(x):
        echo(f"x={x}")

    cli.add_command(sub)
    res = runner.invoke(cli, ["sub"], default_map={"sub": {"x": 5}})
    assert res.stdout == "g=g0\nx=5\n"


def test_environment_variable_fills_option_and_command_line_wins(runner):
    @command()
    @option("--port", type=int, envvar="OPTLYN_TEST_PORT")
    def cmd(port):
        echo(str(port))

    assert runner.invoke(cmd, [], env={"OPTLYN_TEST_PORT": "80"}).stdout == "80\n"
    assert runner.invoke(cmd, ["--port", "1"], env={"OPTLYN_TEST_PORT": "80"}).stdout == "1\n"


def test_empty_environment_value_is_not_supplied(runner):
    @command()
    @option("--port", type=int, envvar="OPTLYN_TEST_PORT", default=7)
    def cmd(port):
        echo(str(port))

    assert runner.invoke(cmd, [], env={"OPTLYN_TEST_PORT": ""}).stdout == "7\n"


def test_auto_envvar_prefix_is_built_from_path(runner):
    @group()
    def cli():
        pass

    @cli.command("sub-cmd")
    @option("--my-opt")
    def sub(my_opt):
        echo(str(my_opt))

    cli.add_command(sub)
    res = runner.invoke(
        cli, ["sub-cmd"], auto_envvar_prefix="app", env={"APP_SUB_CMD_MY_OPT": "v"}
    )
    assert res.stdout == "v\n"


def test_parameter_source_is_reported(runner):
    seen = {}

    @command()
    @option("--x", default=2)
    @pass_context
    def cmd(ctx, x):
        seen["x"] = ctx.get_parameter_source("x")
        seen["undeclared"] = ctx.get_parameter_source("nope")

    runner.invoke(cmd, ["--x", "3"])
    assert seen == {"x": optlyn.core.ParameterSource.COMMANDLINE, "undeclared": None}
    runner.invoke(cmd, [])
    assert seen["x"] is optlyn.core.ParameterSource.DEFAULT


def test_pass_obj_and_make_pass_decorator(runner):
    class Settings:
        pass

    pass_settings = make_pass_decorator(Settings, ensure=True)

    @group()
    @pass_context
    def cli(ctx):
        ctx.obj = {"k": "v"}

    @cli.command()
    @pass_obj
    def show(obj):
        echo(repr(obj))

    @cli.command()
    @pass_settings
    def typed(settings):
        echo(type(settings).__name__)

    cli.add_command(show)
    cli.add_command(typed)
    assert runner.invoke(cli, ["show"]).stdout == "{'k': 'v'}\n"
    assert runner.invoke(cli, ["typed"]).stdout == "Settings\n"


def test_forward_and_invoke_between_commands(runner):
    @command()
    @option("--who", default="x")
    def target(who):
        echo(f"target {who}")

    @command()
    @option("--who", default="me")
    @pass_context
    def caller(ctx, who):
        ctx.invoke(target, who="direct")
        ctx.forward(target)

    assert runner.invoke(caller, []).stdout == "target direct\ntarget me\n"


# -- FP-08: prompts and confirmation ----------------------------------------------------------

def test_prompt_option_reads_value_and_echoes_in_runner(runner):
    @command()
    @option("--name", prompt=True)
    def cmd(name):
        echo(f"hi {name}")

    res = runner.invoke(cmd, [], input="bob\n")
    assert res.exit_code == 0
    assert "Name: bob" in res.output
    assert res.stdout.endswith("hi bob\n")


def test_prompt_not_shown_when_value_given(runner):
    @command()
    @option("--name", prompt=True)
    def cmd(name):
        echo(name)

    res = runner.invoke(cmd, ["--name", "x"], input="ignored\n")
    assert res.stdout == "x\n"


def test_prompt_empty_answer_uses_default(runner):
    @command()
    @option("--age", type=int, prompt=True, default=3)
    def cmd(age):
        echo(str(age))

    assert runner.invoke(cmd, [], input="\n").stdout.endswith("3\n")


def test_prompt_reasks_on_conversion_failure(runner):
    @command()
    @option("--age", type=int, prompt=True)
    def cmd(age):
        echo(str(age))

    res = runner.invoke(cmd, [], input="x\n4\n")
    assert res.stdout.endswith("4\n")
    assert "Error" in res.stderr


def test_eof_during_prompt_aborts(runner):
    @command()
    @option("--name", prompt=True)
    def cmd(name):
        pass

    res = runner.invoke(cmd, [], input="")
    assert res.exit_code == 1
    assert "Aborted!" in res.stderr


def test_password_option_confirms_matching_values(runner):
    @command()
    @password_option()
    def cmd(password):
        echo(password)

    res = runner.invoke(cmd, [], input="pw\npw\n")
    assert res.stdout.endswith("pw\n")
    assert "Repeat for confirmation" in res.output


def test_password_mismatch_asks_again(runner):
    @command()
    @password_option()
    def cmd(password):
        echo(password)

    res = runner.invoke(cmd, [], input="a\nb\nc\nc\n")
    assert res.stdout.endswith("c\n")
    assert "do not match" in res.output


def test_confirmation_option_declined_aborts(runner):
    @command()
    @confirmation_option()
    def cmd():
        echo("ran")

    res = runner.invoke(cmd, [], input="n\n")
    assert res.exit_code == 1
    assert "ran" not in res.output


def test_confirmation_option_flag_skips_question(runner):
    @command()
    @confirmation_option()
    def cmd():
        echo("ran")

    res = runner.invoke(cmd, ["--yes"], input="")
    assert res.stdout == "ran\n"


# -- FP-09: files and paths --------------------------------------------------------------------

def test_file_write_is_lazy_and_read_works(runner):
    with runner.isolated_filesystem() as tmp:
        @command()
        @argument("out", type=File("w"))
        def write(out):
            out.write("hello")

        assert runner.invoke(write, ["data.txt"]).exit_code == 0
        assert pathlib.Path(tmp, "data.txt").read_text() == "hello"


def test_file_read_missing_is_usage_error_naming_path(runner):
    with runner.isolated_filesystem():
        @command()
        @argument("src", type=File("r"))
        def read(src):
            pass

        res = runner.invoke(read, ["missing.txt"])
        assert res.exit_code == 2
        assert "missing.txt" in res.output


def test_dash_file_is_stdin_for_reading(runner):
    @command()
    @argument("src", type=File("r"))
    def read(src):
        echo(src.read().upper())

    assert runner.invoke(read, ["-"], input="abc").stdout == "ABC\n"


def test_path_checks(runner):
    with runner.isolated_filesystem():
        pathlib.Path("f.txt").write_text("x")
        os.mkdir("d")

        @command()
        @argument("p", type=Path(exists=True, dir_okay=False))
        def cmd(p):
            echo(p)

        assert runner.invoke(cmd, ["f.txt"]).stdout == "f.txt\n"
        assert runner.invoke(cmd, ["d"]).exit_code == 2
        assert runner.invoke(cmd, ["zzz"]).exit_code == 2


def test_path_as_pathlib_object(runner):
    @command()
    @argument("p", type=Path(path_type=pathlib.Path))
    def cmd(p):
        echo(type(p).__name__)

    assert runner.invoke(cmd, ["a/b"]).stdout == "PosixPath\n"


# -- FP-10: chaining ---------------------------------------------------------------------------

def test_chain_runs_each_subcommand_and_result_callback(runner):
    @group(chain=True)
    def cli():
        pass

    @cli.command()
    @argument("a")
    def one(a):
        return f"one:{a}"

    @cli.command()
    @argument("b")
    def two(b):
        return f"two:{b}"

    @cli.result_callback()
    def done(results):
        echo(repr(results))

    cli.add_command(one)
    cli.add_command(two)
    assert runner.invoke(cli, ["one", "1", "two", "2"]).stdout == "['one:1', 'two:2']\n"


def test_chain_standalone_off_returns_list(runner):
    @group(chain=True)
    def cli():
        pass

    @cli.command()
    def a():
        return 1

    cli.add_command(a)
    assert cli.main(["a", "a"], standalone_mode=False) == [1, 1]


def test_chain_empty_with_invoke_without_command_runs_result_callback(runner):
    @group(chain=True, invoke_without_command=True)
    def cli():
        pass

    @cli.result_callback()
    def done(results):
        echo(f"results={results}")

    assert runner.invoke(cli, []).stdout == "results=[]\n"


# -- FP-11: terminal helpers -------------------------------------------------------------------

def test_style_and_unstyle_round_trip():
    styled = optlyn.style("x", fg="red", bold=True)
    assert styled != "x"
    assert optlyn.unstyle(styled) == "x"


def test_invalid_color_raises():
    with pytest.raises(ValueError):
        optlyn.style("x", fg="not-a-color")


def test_echo_strips_styles_when_not_a_terminal(runner):
    @command()
    def cmd():
        optlyn.secho("colored", fg="green")

    res = runner.invoke(cmd, [])
    assert res.stdout == "colored\n"


def test_forced_color_keeps_styles(runner):
    @command()
    def cmd():
        optlyn.secho("colored", fg="green")

    res = runner.invoke(cmd, [], color=True)
    assert "\x1b[" in res.stdout


def test_pause_does_not_block_when_not_interactive(runner):
    @command()
    def cmd():
        optlyn.pause("wait here")

    res = runner.invoke(cmd, [])
    assert res.exit_code == 0
    assert "wait here" in res.output


def test_wrap_text_rewraps_and_keeps_backspace_paragraphs():
    assert wrap_text("a b c " * 30, width=20).split("\n")[0] == "a b c a b c a b c a"
    assert wrap_text("\b\nline one\nline two", width=5) == "line one\nline two"


def test_format_filename_is_utf8_encodable():
    name = format_filename(b"\xff.txt")
    name.encode("utf-8")
    assert format_filename("a/b.txt", shorten=True) == "b.txt"


def test_get_app_dir_posix_forced(monkeypatch):
    home = os.path.expanduser("~")
    assert get_app_dir("My App", force_posix=True) == os.path.join(home, ".my-app")


def test_xdg_config_home_is_honoured(monkeypatch, tmp_path):
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    assert get_app_dir("My App") == os.path.join(str(tmp_path), "my-app")


# -- FP-12: shell completion ------------------------------------------------------------------

def _completion(runner, cli, words, cword, shell="bash", prog="cli"):
    env = {
        f"_{prog.upper()}_COMPLETE": f"{shell}_complete",
        "COMP_WORDS": " ".join(words),
        "COMP_CWORD": str(cword),
    }
    return runner.invoke(cli, [], env=env, prog_name=prog).stdout


def _cli():
    @group()
    def cli():
        pass

    @cli.command()
    @option("--color", type=Choice(["red", "green"]))
    @option("--secret", hidden=True)
    def build():
        pass

    @cli.command(hidden=True)
    def hidden_cmd():
        pass

    cli.add_command(build)
    cli.add_command(hidden_cmd)
    return cli


def test_registration_script_for_each_shell(runner):
    cli = _cli()
    for shell in ("bash", "zsh", "fish", "powershell"):
        res = runner.invoke(cli, [], env={"_CLI_COMPLETE": f"{shell}_source"}, prog_name="cli")
        assert res.exit_code == 0
        assert "_CLI_COMPLETE" in res.stdout or "COMPLETE" in res.stdout


def test_unknown_completion_instruction_runs_nothing(runner):
    res = runner.invoke(_cli(), [], env={"_CLI_COMPLETE": "bash_bogus"}, prog_name="cli")
    assert res.exit_code != 0
    assert res.stdout == ""


def test_complete_suggests_subcommands_and_options(runner):
    cli = _cli()
    assert _completion(runner, cli, ["cli", ""], 1) == "build\n"
    assert _completion(runner, cli, ["cli", "build", "--"], 2) == "--color\n--help\n"


def test_complete_choice_values_and_hidden_omitted(runner):
    cli = _cli()
    assert _completion(runner, cli, ["cli", "build", "--color", "g"], 3) == "green\n"
    assert "secret" not in _completion(runner, cli, ["cli", "build", "--"], 2)


def test_complete_path_request_carries_token(runner):
    @command()
    @argument("p", type=Path())
    def cmd(p):
        pass

    out = _completion(runner, cmd, ["cli", "fo"], 1, prog="cli")
    assert out == "@@file:fo\n"


# -- FP-13: exit statuses ---------------------------------------------------------------------

def test_abort_exit_status_and_indication(runner):
    @command()
    def cmd():
        raise Abort()

    res = runner.invoke(cmd, [])
    assert res.exit_code == 1
    assert "Aborted!" in res.stderr


def test_author_clean_stop_status(runner):
    @command()
    def cmd():
        optlyn.get_current_context().exit(7)

    assert runner.invoke(cmd, []).exit_code == 7


def test_bad_parameter_is_usage_exit_status(runner):
    @command()
    @option("--n", type=int)
    def cmd(n):
        pass

    assert runner.invoke(cmd, ["--n", "x"]).exit_code == 2


# -- FP-14: in-process runner -------------------------------------------------------------------

def test_runner_result_fields_and_exception_capture(runner):
    @command()
    def cmd():
        echo("out")
        raise RuntimeError("boom")

    res = runner.invoke(cmd, [])
    assert res.exit_code == 1
    assert isinstance(res.exception, RuntimeError)
    assert res.stdout == "out\n"
    assert res.stdout_bytes == b"out\n"


def test_runner_propagates_when_not_catching(runner):
    strict = CliRunner(catch_exceptions=False)

    @command()
    def cmd():
        raise RuntimeError("boom")

    with pytest.raises(RuntimeError):
        strict.invoke(cmd, [])


def test_runner_env_none_unsets_variable(runner):
    os.environ["OPTLYN_TEST_UNSET"] = "1"

    @command()
    def cmd():
        echo(str(os.environ.get("OPTLYN_TEST_UNSET")))

    try:
        assert runner.invoke(cmd, [], env={"OPTLYN_TEST_UNSET": None}).stdout == "None\n"
    finally:
        os.environ.pop("OPTLYN_TEST_UNSET", None)


def test_runner_isolated_filesystem_leaves_directory(runner):
    with runner.isolated_filesystem() as path:
        assert os.path.isdir(path)
        assert os.path.samefile(os.getcwd(), path)
    assert os.path.isdir(path)


def test_runner_fd_capture_separates_streams():
    fd_runner = CliRunner(capture="fd")

    @command()
    def cmd():
        os.write(1, b"fd-one\n")
        os.write(2, b"fd-two\n")

    res = fd_runner.invoke(cmd, [])
    assert "fd-one" in res.stdout
    assert "fd-two" in res.stderr


# -- Declaration errors and package surface -----------------------------------------------------

def test_public_surface_exports():
    for name in ("command", "group", "option", "argument", "help_option", "version_option",
                 "custom_version_option", "password_option", "confirmation_option",
                 "pass_context", "pass_obj", "make_pass_decorator", "Command", "Group",
                 "CommandCollection", "Context", "Option", "Parameter", "ParamType",
                 "BadParameter", "Abort", "STRING", "INT", "FLOAT", "BOOL", "UUID",
                 "UNPROCESSED", "Choice", "DateTime", "IntRange", "FloatRange", "Tuple",
                 "File", "Path", "echo", "secho", "style", "unstyle", "echo_via_pager",
                 "get_pager_file", "progressbar", "prompt", "confirm", "getchar", "pause",
                 "edit", "launch", "clear", "get_app_dir", "get_current_context",
                 "format_filename", "open_file"):
        assert hasattr(optlyn, name), name
    from optlyn.formatting import wrap_text

    assert callable(wrap_text)
    assert callable(optlyn.testing.CliRunner)


def test_argument_invalid_combinations_refused():
    with pytest.raises(Exception):
        @command()
        @argument("x", deprecated="old", required=True)
        def cmd(x):
            pass
