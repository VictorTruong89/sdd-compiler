import codecs
import io
import os
import sys


def get_best_encoding(stream):
    rv = getattr(stream, "encoding", None) or sys.getdefaultencoding()
    if is_ascii_encoding(rv):
        return "utf-8"
    return rv


def is_ascii_encoding(encoding):
    try:
        return codecs.lookup(encoding).name == "ascii"
    except LookupError:
        return False


class _NonClosingTextIOWrapper(io.TextIOWrapper):
    def __del__(self):
        try:
            self.flush()
            self.detach()
        except Exception:
            pass


def is_binary_writer(stream, default=False):
    try:
        stream.write(b"")
    except Exception:
        try:
            stream.write("")
            return False
        except Exception:
            pass
        return default
    return True


def is_binary_reader(stream, default=False):
    try:
        return isinstance(stream.read(0), bytes)
    except Exception:
        return default


def find_binary_reader(stream):
    if is_binary_reader(stream, False):
        return stream
    buf = getattr(stream, "buffer", None)
    if buf is not None and is_binary_reader(buf, True):
        return buf
    return None


def find_binary_writer(stream):
    if is_binary_writer(stream, False):
        return stream
    buf = getattr(stream, "buffer", None)
    if buf is not None and is_binary_writer(buf, True):
        return buf
    return None


def make_text_stream(stream, binary, encoding, errors):
    if encoding is None:
        encoding = get_best_encoding(stream)
    if errors is None:
        errors = "replace"
    return _NonClosingTextIOWrapper(binary, encoding, errors, line_buffering=True)


def get_binary_stdin():
    r = find_binary_reader(sys.stdin)
    if r is None:
        raise RuntimeError("Was not able to determine binary stream for sys.stdin.")
    return r


def get_binary_stdout():
    w = find_binary_writer(sys.stdout)
    if w is None:
        raise RuntimeError("Was not able to determine binary stream for sys.stdout.")
    return w


def get_binary_stderr():
    w = find_binary_writer(sys.stderr)
    if w is None:
        raise RuntimeError("Was not able to determine binary stream for sys.stderr.")
    return w


def _text_stream(stream, binary_getter, encoding, errors, writer):
    finder = find_binary_writer if writer else find_binary_reader
    if encoding is None and errors is None:
        return stream
    binary = finder(stream)
    if binary is None:
        return stream
    return make_text_stream(stream, binary, encoding, errors)


def get_text_stdin(encoding=None, errors=None):
    return _text_stream(sys.stdin, get_binary_stdin, encoding, errors, False)


def get_text_stdout(encoding=None, errors=None):
    return _text_stream(sys.stdout, get_binary_stdout, encoding, errors, True)


def get_text_stderr(encoding=None, errors=None):
    return _text_stream(sys.stderr, get_binary_stderr, encoding, errors, True)


def isatty(stream):
    try:
        return stream.isatty()
    except Exception:
        return False


def is_interactive():
    return isatty(sys.stdin) or isatty(sys.stdout)


def should_strip_ansi(stream=None, color=None):
    if color is None:
        if stream is None:
            stream = sys.stdin
        return not isatty(stream)
    return not color


def open_stream(filename, mode="r", encoding=None, errors="strict", atomic=False):
    binary = "b" in mode
    filename = os.fspath(filename)
    if filename == "-":
        if any(m in mode for m in ("w", "a", "x")):
            if binary:
                return get_binary_stdout(), False
            return get_text_stdout(encoding=encoding, errors=errors), False
        if binary:
            return get_binary_stdin(), False
        return get_text_stdin(encoding=encoding, errors=errors), False
    if not atomic:
        kw = {} if binary else {"encoding": encoding, "errors": errors}
        return open(filename, mode, **kw), True
    if "x" in mode:
        raise ValueError("Use the `overwrite`-parameter instead.")
    if "r" in mode:
        raise ValueError("Atomic writes only make sense with `w`-mode.")
    import random
    flags = os.O_RDWR | os.O_CREAT | os.O_EXCL
    if binary:
        flags |= getattr(os, "O_BINARY", 0)
    perm = 0o666
    if os.path.exists(filename):
        perm = os.stat(filename).st_mode
    while True:
        tmp = os.path.join(os.path.dirname(filename),
                           f".__atomic-write{random.randrange(1 << 32):08x}")
        try:
            fd = os.open(tmp, flags, perm)
            break
        except FileExistsError:
            continue
    kw = {} if binary else {"encoding": encoding, "errors": errors}
    f = open(fd, mode, **kw)
    return _AtomicFile(f, tmp, os.path.realpath(filename)), True


class _AtomicFile:
    def __init__(self, f, tmp_filename, real_filename):
        self._f = f
        self._tmp_filename = tmp_filename
        self._real_filename = real_filename
        self.closed = False

    @property
    def name(self):
        return self._real_filename

    def close(self, delete=False):
        if self.closed:
            return
        self._f.close()
        if delete:
            try:
                os.unlink(self._tmp_filename)
            except OSError:
                pass
        else:
            os.replace(self._tmp_filename, self._real_filename)
        self.closed = True

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.close(delete=exc_type is not None)

    def __iter__(self):
        return iter(self._f)

    def __repr__(self):
        return repr(self._f)


class KeepOpenFile:
    def __init__(self, file):
        self._file = file

    def __getattr__(self, name):
        return getattr(self._file, name)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        pass

    def __repr__(self):
        return repr(self._file)

    def __iter__(self):
        return iter(self._file)


class LazyFile:
    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False):
        self.name = os.fspath(filename)
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self.should_close = True
        if self.name == "-":
            self._f, self.should_close = open_stream(filename, mode, encoding, errors)
        elif "r" in mode:
            open(filename, mode).close()

    def __getattr__(self, name):
        return getattr(self.open(), name)

    def __repr__(self):
        if self._f is not None:
            return repr(self._f)
        return f"<unopened file '{self.name}' {self.mode}>"

    def open(self):
        if self._f is not None:
            return self._f
        try:
            rv, self.should_close = open_stream(self.name, self.mode, self.encoding,
                                                self.errors, atomic=self.atomic)
        except OSError as e:
            from .exceptions import FileError
            raise FileError(self.name, hint=e.strerror) from e
        self._f = rv
        return rv

    def close(self):
        if self._f is not None:
            self._f.close()

    def close_intelligently(self):
        if self.should_close:
            self.close()

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close_intelligently()

    def __iter__(self):
        self.open()
        return iter(self._f)
