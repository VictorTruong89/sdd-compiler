import enum
import os
import stat
import uuid
from datetime import datetime

from ._compat import LazyFile, open_stream
from .exceptions import BadParameter
from .utils import format_filename, safecall


class CompletionItem:
    __slots__ = ("value", "type", "help", "_info")

    def __init__(self, value, type="plain", help=None, **kwargs):
        self.value = value
        self.type = type
        self.help = help
        self._info = kwargs

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        return self._info.get(name)


class ParamType:
    is_composite = False
    arity = 1
    name = ""
    envvar_list_splitter = None

    def __call__(self, value, param=None, ctx=None):
        if value is not None:
            return self.convert(value, param, ctx)

    def get_metavar(self, param):
        return None

    def get_missing_message(self, param):
        return None

    def convert(self, value, param=None, ctx=None):
        return value

    def split_envvar_value(self, rv):
        return (rv or "").split(self.envvar_list_splitter)

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def shell_complete(self, ctx, param, incomplete):
        return []


class FuncParamType(ParamType):
    def __init__(self, func):
        self.name = getattr(func, "__name__", "value")
        self.func = func

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except ValueError as e:
            try:
                value = str(value)
            except UnicodeError:
                value = value.decode("utf-8", "replace")
            self.fail(str(e) or value, param, ctx)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value

    def __repr__(self):
        return "UNPROCESSED"


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            try:
                return value.decode("utf-8")
            except UnicodeError:
                return value.decode("utf-8", "replace")
        return str(value)

    def __repr__(self):
        return "STRING"


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            return int(value)
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)

    def __repr__(self):
        return "INT"


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        try:
            return float(value)
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid float.", param, ctx)

    def __repr__(self):
        return "FLOAT"


TRUE_TOKENS = ("1", "true", "t", "yes", "y", "on")
FALSE_TOKENS = ("0", "false", "f", "no", "n", "off")


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if value in {False, True}:
            return bool(value)
        norm = str(value).strip().lower()
        if norm in TRUE_TOKENS:
            return True
        if norm in FALSE_TOKENS:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)

    def __repr__(self):
        return "BOOL"


class UUIDParameterType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)

    def __repr__(self):
        return "UUID"


def _normalizer(ctx, case_sensitive):
    def norm(x):
        if ctx is not None and ctx.token_normalize_func is not None:
            x = ctx.token_normalize_func(x)
        if not case_sensitive:
            x = x.casefold()
        return x
    return norm


class Choice(ParamType):
    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            choices = list(choices)
        self.choices = tuple(choices)
        self.case_sensitive = case_sensitive

    def _str(self, c):
        if isinstance(c, enum.Enum):
            return c.name
        return str(c)

    def get_metavar(self, param):
        return f"[{'|'.join(self._str(c) for c in self.choices)}]"

    def get_missing_message(self, param):
        return "Choose from:\n\t" + ",\n\t".join(self._str(c) for c in self.choices)

    def convert(self, value, param=None, ctx=None):
        for c in self.choices:
            if value is c or (not isinstance(value, str) and type(value) is type(c) and value == c):
                return c
        norm = _normalizer(ctx, self.case_sensitive)
        table = {}
        for c in self.choices:
            table.setdefault(norm(self._str(c)), c)
        try:
            key = norm(value if isinstance(value, str) else str(value))
        except Exception:
            key = value
        if key in table:
            return table[key]
        self.fail("{} is not one of {}.".format(
            repr(value), ", ".join(repr(self._str(c)) for c in self.choices)), param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        norm = _normalizer(ctx, self.case_sensitive)
        inc = norm(incomplete)
        return [CompletionItem(self._str(c)) for c in self.choices
                if norm(self._str(c)).startswith(inc)]

    def __repr__(self):
        return f"Choice({list(self.choices)})"


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else [
            "%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]

    def get_metavar(self, param):
        return f"[{'|'.join(self.formats)}]"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, datetime):
            return value
        for fmt in self.formats:
            try:
                return datetime.strptime(value, fmt)
            except (ValueError, TypeError):
                continue
        self.fail("{} does not match the format{} {}.".format(
            repr(value), "s" if len(self.formats) > 1 else "",
            ", ".join(repr(f) for f in self.formats)), param, ctx)


class _NumberRange(ParamType):
    _int = False

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def _clamp(self, bound, direction, open_):
        raise NotImplementedError

    def convert(self, value, param=None, ctx=None):
        import operator
        rv = self._convert(value, param, ctx)
        lt_min = self.min is not None and (operator.le if self.min_open else operator.lt)(rv, self.min)
        gt_max = self.max is not None and (operator.ge if self.max_open else operator.gt)(rv, self.max)
        if self.clamp:
            if lt_min:
                return self._clamp(self.min, 1, self.min_open)
            if gt_max:
                return self._clamp(self.max, -1, self.max_open)
        if lt_min or gt_max:
            self.fail(f"{rv} is not in the range {self._describe_range()}.", param, ctx)
        return rv

    def _describe_range(self):
        if self.min is None:
            op = "<" if self.max_open else "<="
            return f"x{op}{self.max}"
        if self.max is None:
            op = ">" if self.min_open else ">="
            return f"x{op}{self.min}"
        lop = "<" if self.min_open else "<="
        rop = "<" if self.max_open else "<="
        return f"{self.min}{lop}x{rop}{self.max}"

    def __repr__(self):
        return f"{type(self).__name__}({self.min}, {self.max})"


class IntRange(_NumberRange):
    name = "integer range"

    def _convert(self, value, param, ctx):
        return IntParamType().convert(value, param, ctx)

    def _clamp(self, bound, direction, open_):
        if not open_:
            return bound
        return bound + direction


class FloatRange(_NumberRange):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        super().__init__(min, max, min_open, max_open, clamp)
        if (min_open or max_open) and clamp:
            raise TypeError("Clamping is not supported for open bounds.")

    def _convert(self, value, param, ctx):
        return FloatParamType().convert(value, param, ctx)

    def _clamp(self, bound, direction, open_):
        return bound


class File(ParamType):
    name = "filename"
    envvar_list_splitter = os.path.pathsep

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def resolve_lazy_flag(self, value):
        if self.lazy is not None:
            return self.lazy
        if os.fspath(value) == "-":
            return False
        if "w" in self.mode:
            return True
        return False

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        try:
            lazy = self.resolve_lazy_flag(value)
            if lazy:
                lf = LazyFile(value, self.mode, self.encoding, self.errors, atomic=self.atomic)
                if ctx is not None:
                    ctx.call_on_close(lf.close_intelligently)
                return lf
            f, should_close = open_stream(value, self.mode, self.encoding, self.errors,
                                          atomic=self.atomic)
            if ctx is not None:
                ctx.call_on_close(safecall(f.close if should_close else f.flush))
            return f
        except OSError as e:
            self.fail(f"'{format_filename(value)}': {e.strerror}", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        return [CompletionItem(incomplete, type="file")]


class Path(ParamType):
    envvar_list_splitter = os.path.pathsep

    def __init__(self, exists=False, file_okay=True, dir_okay=True, writable=False,
                 readable=True, resolve_path=False, allow_dash=False, path_type=None,
                 executable=False):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.readable = readable
        self.writable = writable
        self.executable = executable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.type = path_type
        if self.file_okay and not self.dir_okay:
            self.name = "file"
        elif self.dir_okay and not self.file_okay:
            self.name = "directory"
        else:
            self.name = "path"

    def coerce_path_result(self, rv):
        if self.type is not None and not isinstance(rv, self.type):
            if self.type is str:
                rv = os.fsdecode(rv)
            elif self.type is bytes:
                rv = os.fsencode(rv)
            else:
                rv = self.type(rv)
        return rv

    def convert(self, value, param=None, ctx=None):
        rv = value
        is_dash = self.file_okay and self.allow_dash and rv in (b"-", "-")
        if not is_dash:
            if self.resolve_path:
                rv = os.path.realpath(rv)
            try:
                st = os.stat(rv)
            except OSError:
                if not self.exists:
                    return self.coerce_path_result(rv)
                self.fail(f"{self.name.capitalize()} '{format_filename(value)}' does not exist.",
                          param, ctx)
            if not self.file_okay and stat.S_ISREG(st.st_mode):
                self.fail(f"{self.name.capitalize()} '{format_filename(value)}' is a file.",
                          param, ctx)
            if not self.dir_okay and stat.S_ISDIR(st.st_mode):
                self.fail(f"{self.name.capitalize()} '{format_filename(value)}' is a directory.",
                          param, ctx)
            if self.readable and not os.access(rv, os.R_OK):
                self.fail(f"{self.name.capitalize()} '{format_filename(value)}' is not readable.",
                          param, ctx)
            if self.writable and not os.access(rv, os.W_OK):
                self.fail(f"{self.name.capitalize()} '{format_filename(value)}' is not writable.",
                          param, ctx)
            if self.executable and not os.access(rv, os.X_OK):
                self.fail(f"{self.name.capitalize()} '{format_filename(value)}' is not executable.",
                          param, ctx)
        return self.coerce_path_result(rv)

    def shell_complete(self, ctx, param, incomplete):
        t = "dir" if self.dir_okay and not self.file_okay else "file"
        return [CompletionItem(incomplete, type=t)]


class Tuple(ParamType):
    is_composite = True

    def __init__(self, types):
        self.types = [convert_type(ty) for ty in types]

    @property
    def name(self):
        return "<{}>".format(" ".join(ty.name for ty in self.types))

    @property
    def arity(self):
        return len(self.types)

    def convert(self, value, param=None, ctx=None):
        len_type = len(self.types)
        len_value = len(value)
        if len_value != len_type:
            self.fail(f"{len_type} values are required, but {len_value} were given.", param, ctx)
        return tuple(ty(x, param, ctx) for ty, x in zip(self.types, value))


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParameterType()
UNPROCESSED = UnprocessedParamType()


def convert_type(ty, default=None, multiple=False):
    guessed = False
    if ty is None and default is not None:
        if isinstance(default, (tuple, list)):
            if multiple:
                if default:
                    item = default[0]
                    ty = tuple(map(type, item)) if isinstance(item, (tuple, list)) else type(item)
            else:
                ty = tuple(map(type, default)) if default else None
        elif not isinstance(default, str) and callable(default) and not isinstance(default, type):
            ty = None
        else:
            ty = type(default)
        guessed = ty is not None
    if isinstance(ty, tuple):
        return Tuple(ty)
    if isinstance(ty, ParamType):
        return ty
    if ty is str or ty is None:
        return STRING
    if ty is int:
        return INT
    if ty is float:
        return FLOAT
    if ty is bool:
        return BOOL
    if guessed:
        return STRING
    if isinstance(ty, type) and issubclass(ty, ParamType):
        raise AssertionError("Attempted to use an uninstantiated parameter type.")
    return FuncParamType(ty)
