import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile

from . import formatting, termui, utils, _compat


class EchoingStdin:
    def __init__(self, input, output):
        self._input = input
        self._output = output
        self._paused = False

    def __getattr__(self, x):
        return getattr(self._input, x)

    def _echo(self, rv):
        if not self._paused:
            self._output.write(rv)
        return rv

    def read(self, n=-1):
        return self._echo(self._input.read(n))

    def read1(self, n=-1):
        return self._echo(self._input.read1(n))

    def readline(self, n=-1):
        return self._echo(self._input.readline(n))

    def readlines(self):
        return [self._echo(x) for x in self._input.readlines()]

    def __iter__(self):
        return iter(self._echo(x) for x in self._input)


def _pause_echo(stream):
    @contextlib.contextmanager
    def cm():
        if stream is None:
            yield
            return
        stream._paused = True
        try:
            yield
        finally:
            stream._paused = False
    return cm()


class BytesIOCopy(io.BytesIO):
    def __init__(self, copy_to):
        super().__init__()
        self.copy_to = copy_to

    def flush(self):
        super().flush()
        self.copy_to.flush()

    def write(self, b):
        self.copy_to.write(b)
        return super().write(b)


class _FdBuffer(BytesIOCopy):
    def __init__(self, copy_to, fd, drain):
        super().__init__(copy_to)
        self._fd = fd
        self._drain = drain

    def fileno(self):
        return self._fd

    def write(self, b):
        self._drain()
        return super().write(b)


class _NamedTextIOWrapper(io.TextIOWrapper):
    def __init__(self, buffer, name=None, mode=None, **kwargs):
        super().__init__(buffer, **kwargs)
        self._name = name
        self._mode = mode

    @property
    def name(self):
        return self._name

    @property
    def mode(self):
        return self._mode


def make_input_stream(input, charset):
    if hasattr(input, "read"):
        rv = _compat.find_binary_reader(input)
        if rv is not None:
            return rv
        raise TypeError("Could not find binary reader for input stream.")
    if input is None:
        input = b""
    elif isinstance(input, str):
        input = input.encode(charset)
    return io.BytesIO(input)


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value,
                 exit_code, exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    def _dec(self, b):
        return b.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def output(self):
        return self._dec(self.output_bytes)

    @property
    def stdout(self):
        return self._dec(self.stdout_bytes)

    @property
    def stderr(self):
        return self._dec(self.stderr_bytes)

    def __repr__(self):
        exc = repr(self.exception) if self.exception else "okay"
        return f"<Result {exc}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.charset = charset
        self.env = env or {}
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def make_env(self, overrides=None):
        rv = dict(self.env)
        if overrides:
            rv.update(overrides)
        return rv

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        bytes_input = make_input_stream(input, self.charset)
        echo_input = None
        old_stdin, old_stdout, old_stderr = sys.stdin, sys.stdout, sys.stderr
        old_forced_width = formatting.FORCED_WIDTH
        formatting.FORCED_WIDTH = 80
        env = self.make_env(env)
        mixed = io.BytesIO()
        fd_state = None
        if self.capture == "fd":
            fd_state = _FdCapture()
            out_buf = _FdBuffer(mixed, 1, fd_state.drain)
            err_buf = _FdBuffer(mixed, 2, fd_state.drain)
            fd_state.bind(out_buf, err_buf, mixed)
            fd_state.start()
        else:
            out_buf = BytesIOCopy(mixed)
            err_buf = BytesIOCopy(mixed)
        if self.echo_stdin:
            bytes_input = echo_input = EchoingStdin(bytes_input, out_buf)
        sys.stdin = text_input = _NamedTextIOWrapper(bytes_input, encoding=self.charset,
                                                     name="<stdin>", mode="r")
        if self.echo_stdin:
            text_input._CHUNK_SIZE = 1
        sys.stdout = _NamedTextIOWrapper(out_buf, encoding=self.charset, name="<stdout>",
                                         mode="w", write_through=True)
        sys.stderr = _NamedTextIOWrapper(err_buf, encoding=self.charset, name="<stderr>",
                                         mode="w", errors="backslashreplace",
                                         write_through=True)

        def visible_input(prompt=None):
            with _pause_echo(echo_input):
                sys.stdout.write(prompt or "")
                line = text_input.readline()
                if line == "":
                    raise EOFError()
                val = line.rstrip("\r\n")
                sys.stdout.write(f"{val}\n")
                sys.stdout.flush()
                return val

        def hidden_input(prompt=None):
            with _pause_echo(echo_input):
                sys.stdout.write(f"{prompt or ''}\n")
                sys.stdout.flush()
                line = text_input.readline()
                if line == "":
                    raise EOFError()
                return line.rstrip("\r\n")

        def _getchar(echo):
            char = sys.stdin.read(1)
            if echo:
                sys.stdout.write(char)
            sys.stdout.flush()
            return char

        default_color = color

        def should_strip_ansi(stream=None, color=None):
            if color is None:
                return not default_color
            return not color

        old = (termui.visible_prompt_func, termui.hidden_prompt_func, termui._getchar,
               utils.should_strip_ansi, _compat.should_strip_ansi)
        termui.visible_prompt_func = visible_input
        termui.hidden_prompt_func = hidden_input
        termui._getchar = _getchar
        utils.should_strip_ansi = should_strip_ansi
        _compat.should_strip_ansi = should_strip_ansi
        old_env = {}
        try:
            for key, value in env.items():
                old_env[key] = os.environ.get(key)
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            yield (out_buf, err_buf, mixed, fd_state)
        finally:
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            if fd_state is not None:
                try:
                    sys.stdout.flush()
                    sys.stderr.flush()
                except Exception:
                    pass
                fd_state.stop()
            sys.stdout, sys.stderr, sys.stdin = old_stdout, old_stderr, old_stdin
            (termui.visible_prompt_func, termui.hidden_prompt_func, termui._getchar,
             utils.should_strip_ansi, _compat.should_strip_ansi) = old
            formatting.FORCED_WIDTH = old_forced_width

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False,
               **extra):
        exc_info = None
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        with self.isolation(input=input, env=env, color=color) as streams:
            return_value = None
            exception = None
            exit_code = 0
            if isinstance(args, str):
                args = shlex.split(args)
            try:
                prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
                return_value = cli.main(args=args or (), prog_name=prog_name, **extra)
            except SystemExit as e:
                exc_info = sys.exc_info()
                code = e.code
                if code is None:
                    code = 0
                if code != 0:
                    exception = e
                if not isinstance(code, int):
                    sys.stdout.write(str(code))
                    sys.stdout.write("\n")
                    code = 1
                exit_code = code
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                try:
                    sys.stdout.flush()
                    sys.stderr.flush()
                except Exception:
                    pass
                if streams[3] is not None:
                    streams[3].drain()
                stdout = streams[0].getvalue()
                stderr = streams[1].getvalue()
                output = streams[2].getvalue()
        return Result(self, stdout, stderr, output, return_value, exit_code, exception, exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass


class _FdCapture:
    """Redirect OS file descriptors 1 and 2 to temporary files."""

    def __init__(self):
        self.out_buf = self.err_buf = self.mixed = None
        self._saved = {}
        self._files = {}
        self._pos = {1: 0, 2: 0}

    def bind(self, out_buf, err_buf, mixed):
        self.out_buf, self.err_buf, self.mixed = out_buf, err_buf, mixed

    def start(self):
        for fd in (1, 2):
            try:
                sys.__stdout__.flush()
                sys.__stderr__.flush()
            except Exception:
                pass
            self._saved[fd] = os.dup(fd)
            tmp = tempfile.TemporaryFile()
            self._files[fd] = tmp
            os.dup2(tmp.fileno(), fd)

    def drain(self):
        for fd, buf in ((1, self.out_buf), (2, self.err_buf)):
            tmp = self._files.get(fd)
            if tmp is None:
                continue
            size = os.fstat(tmp.fileno()).st_size
            if size > self._pos[fd]:
                data = os.pread(tmp.fileno(), size - self._pos[fd], self._pos[fd])
                self._pos[fd] = size
                io.BytesIO.write(buf, data)
                self.mixed.write(data)

    def stop(self):
        self.drain()
        for fd, saved in self._saved.items():
            os.dup2(saved, fd)
            os.close(saved)
        for tmp in self._files.values():
            tmp.close()
        self._files = {}
