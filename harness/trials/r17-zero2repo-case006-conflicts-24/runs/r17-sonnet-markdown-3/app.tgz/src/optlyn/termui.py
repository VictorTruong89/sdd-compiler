import contextlib
import getpass
import inspect
import io
import itertools
import math
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
import time

from ._compat import isatty, is_interactive, should_strip_ansi
from .exceptions import Abort, OptlynException, UsageError
from .formatting import strip_ansi, term_len
from .globals_ import resolve_color_default
from .types import Choice, convert_type
from .utils import echo, make_str, safecall

visible_prompt_func = input
hidden_prompt_func = getpass.getpass
_getchar = None


def _build_prompt(text, suffix, show_default=False, default=None, show_choices=True, type=None):
    prompt = text
    if type is not None and show_choices and isinstance(type, Choice):
        prompt += f" ({', '.join(map(str, type.choices))})"
    if default is not None and show_default:
        prompt = f"{prompt} [{_format_default(default)}]"
    return f"{prompt}{suffix}"


def _format_default(default):
    if hasattr(default, "name") and hasattr(default, "read"):
        return default.name
    return default


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False, show_choices=True):
    def prompt_func(text):
        f = hidden_prompt_func if hide_input else visible_prompt_func
        try:
            echo(text.rstrip(" "), nl=False, err=err)
            return f(" ")
        except (KeyboardInterrupt, EOFError):
            if hide_input:
                echo(None, err=err)
            raise Abort() from None

    if value_proc is None:
        value_proc = convert_type(type, default)
    prompt_text = _build_prompt(text, prompt_suffix, show_default, default, show_choices, type)
    if confirmation_prompt:
        if confirmation_prompt is True:
            confirmation_prompt = "Repeat for confirmation"
        confirmation_prompt = _build_prompt(confirmation_prompt, prompt_suffix)
    while True:
        while True:
            value = prompt_func(prompt_text)
            if value:
                break
            elif default is not None:
                value = default
                break
        try:
            result = value_proc(value)
        except UsageError as e:
            if hide_input:
                echo("Error: The value you entered was invalid.", err=err)
            else:
                echo(f"Error: {e.message}", err=err)
            continue
        if not confirmation_prompt:
            return result
        while True:
            value2 = prompt_func(confirmation_prompt)
            is_empty = not value and not value2
            if value2 or is_empty:
                break
        if value == value2:
            return result
        echo("Error: The two entered values do not match.", err=err)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    prompt_text = _build_prompt(text, prompt_suffix, show_default,
                                "y/n" if default is None else ("Y/n" if default else "y/N"))
    while True:
        try:
            echo(prompt_text.rstrip(" "), nl=False, err=err)
            value = visible_prompt_func(" ").lower().strip()
        except (KeyboardInterrupt, EOFError):
            raise Abort() from None
        if value in ("y", "yes"):
            rv = True
        elif value in ("n", "no"):
            rv = False
        elif default is not None and value == "":
            rv = default
        else:
            echo("Error: invalid input", err=err)
            continue
        break
    if abort and not rv:
        raise Abort()
    return rv


# ---- pager -----------------------------------------------------------------

class _PagerStream:
    def __init__(self, target, color, proc=None):
        self.target = target
        self.color = color
        self.proc = proc
        self.closed = False

    def write(self, text):
        if not isinstance(text, str):
            text = str(text)
        if self.proc is None:
            if should_strip_ansi(self.target, self.color):
                text = strip_ansi(text)
        elif not self.color:
            text = strip_ansi(text)
        try:
            self.target.write(text)
            self.target.flush()
        except (OSError, ValueError):
            pass
        return len(text)

    def writelines(self, lines):
        for line in lines:
            self.write(line)

    def flush(self):
        try:
            self.target.flush()
        except (OSError, ValueError):
            pass

    def isatty(self):
        return False

    def writable(self):
        return True


@contextlib.contextmanager
def get_pager_file(color=None):
    color = resolve_color_default(color)
    stdout = sys.stdout if sys.stdout is not None else io.StringIO()
    cmd = (os.environ.get("PAGER", None) or "").strip()
    if not is_interactive():
        yield _PagerStream(stdout, color)
        return
    if not cmd:
        for cand in ("less", "more"):
            if shutil.which(cand):
                cmd = cand
                break
    if not cmd:
        yield _PagerStream(stdout, color)
        return
    env = dict(os.environ)
    detail = cmd.rsplit("/", 1)[-1].split()
    if color is None and detail[0] == "less":
        flags = f"{os.environ.get('LESS', '')}{' '.join(detail[1:])}"
        if not flags:
            env["LESS"] = "-R"
            color = True
        elif "r" in flags or "R" in flags:
            color = True
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, env=env,
                            errors="replace", text=True)
    stream = _PagerStream(proc.stdin, color, proc)
    try:
        yield stream
    finally:
        try:
            proc.stdin.close()
        except (OSError, ValueError):
            pass
        while True:
            try:
                proc.wait()
            except KeyboardInterrupt:
                pass
            else:
                break


def echo_via_pager(text_or_generator, color=None):
    color = resolve_color_default(color)
    if inspect.isclass(text_or_generator) or (
            callable(text_or_generator) and not isinstance(text_or_generator, str)):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        items = [text_or_generator]
    else:
        items = iter(text_or_generator)
    with get_pager_file(color) as f:
        for el in itertools.chain((el if isinstance(el, str) else str(el) for el in items), "\n"):
            f.write(el)


# ---- progress bar ----------------------------------------------------------

class ProgressBar:
    def __init__(self, iterable, length=None, fill_char="#", empty_char="-",
                 bar_template="%(label)s  [%(bar)s]  %(info)s", info_sep="  ", show_eta=True,
                 show_percent=None, show_pos=False, item_show_func=None, label=None, file=None,
                 color=None, update_min_steps=1, width=36, hidden=False):
        self.fill_char = fill_char
        self.empty_char = empty_char
        self.bar_template = bar_template
        self.info_sep = info_sep
        self.show_eta = show_eta
        self.show_percent = show_percent
        self.show_pos = show_pos
        self.item_show_func = item_show_func
        self.label = label or ""
        if file is None:
            file = sys.stdout
        self.file = file
        self.color = color
        self.update_min_steps = update_min_steps
        self._completed_intervals = 0
        self.width = width
        self.autowidth = width == 0
        self.hidden = hidden
        if length is None:
            try:
                length = len(iterable)
            except (TypeError, AttributeError):
                length = None
        if iterable is None:
            if length is None:
                raise TypeError("iterable or length is required")
            iterable = range(length)
        self.iter = iter(iterable)
        self.length = length
        self.pos = 0
        self.avg = []
        self.last_eta = time.time()
        self.start = self.last_eta
        self.eta_known = False
        self.finished = False
        self.max_width = None
        self.entered = False
        self.current_item = None
        self._last_line = None

    @property
    def is_hidden(self):
        return not isatty(self.file)

    def __enter__(self):
        self.entered = True
        self.render_progress()
        return self

    def __exit__(self, *a):
        self.render_finish()

    def __iter__(self):
        if not self.entered:
            raise RuntimeError("You need to use progress bars in a with block.")
        self.render_progress()
        return self.generator()

    def __next__(self):
        return next(iter(self))

    def render_finish(self):
        if self.hidden or self.is_hidden:
            return
        echo(file=self.file)

    @property
    def pct(self):
        if self.finished:
            return 1.0
        if not self.length:
            return 0.0
        return min(self.pos / self.length, 1.0)

    @property
    def time_per_iteration(self):
        if not self.avg:
            return 0.0
        return sum(self.avg) / float(len(self.avg))

    @property
    def eta(self):
        if self.length is not None and not self.finished:
            return self.time_per_iteration * (self.length - self.pos)
        return 0.0

    def format_eta(self):
        if self.eta_known:
            t = int(self.eta)
            seconds = t % 60
            t //= 60
            minutes = t % 60
            t //= 60
            hours = t % 24
            t //= 24
            if t > 0:
                return f"{t}d {hours:02}:{minutes:02}:{seconds:02}"
            return f"{hours:02}:{minutes:02}:{seconds:02}"
        return ""

    def format_pos(self):
        pos = str(self.pos)
        if self.length is not None:
            pos += f"/{self.length}"
        return pos

    def format_pct(self):
        return f"{int(self.pct * 100): 4}%"[1:]

    def format_bar(self):
        if self.length is not None:
            bar_length = int(self.pct * self.width)
            bar = self.fill_char * bar_length
            bar += self.empty_char * (self.width - bar_length)
        elif self.finished:
            bar = self.fill_char * self.width
        else:
            chars = list(self.empty_char * (self.width or 1))
            if self.time_per_iteration != 0:
                chars[int((math.cos(self.pos * self.time_per_iteration) / 2.0 + 0.5)
                          * self.width)] = self.fill_char
            bar = "".join(chars)
        return bar

    def format_progress_line(self):
        show_percent = self.show_percent
        info_bits = []
        if self.length is not None and show_percent is None:
            show_percent = not self.show_pos
        if self.show_pos:
            info_bits.append(self.format_pos())
        if show_percent:
            info_bits.append(self.format_pct())
        if self.show_eta and self.eta_known and not self.finished:
            info_bits.append(self.format_eta())
        if self.item_show_func is not None:
            item_info = self.item_show_func(self.current_item)
            if item_info is not None:
                info_bits.append(item_info)
        return (self.bar_template % {
            "label": self.label, "bar": self.format_bar(),
            "info": self.info_sep.join(info_bits)}).rstrip()

    def render_progress(self):
        if self.hidden:
            return
        if self.is_hidden:
            if self._last_line != self.label:
                self._last_line = self.label
                echo(self.label, file=self.file, color=self.color)
            return
        clear_width = self.width
        if self.max_width is not None:
            clear_width = self.max_width
        line = self.format_progress_line()
        line_len = term_len(line)
        if self.max_width is None or self.max_width < line_len:
            self.max_width = line_len
        out = "\r" + line + " " * max(clear_width - line_len, 0)
        if out != self._last_line:
            self._last_line = out
            echo(out, file=self.file, color=self.color, nl=False)
            self.file.flush()

    def make_step(self, n_steps):
        self.pos += n_steps
        if self.length is not None and self.pos >= self.length:
            self.finished = True
        now = time.time()
        if (now - self.last_eta) < 1.0 and not self.finished:
            return
        self.last_eta = now
        if self.pos:
            step = (now - self.start) / self.pos
        else:
            step = now - self.start
        self.avg = self.avg[-6:] + [step]
        self.eta_known = self.length is not None

    def update(self, n_steps, current_item=None):
        if current_item is not None:
            self.current_item = current_item
        self._completed_intervals += n_steps
        if self._completed_intervals >= self.update_min_steps:
            self.make_step(self._completed_intervals)
            self.render_progress()
            self._completed_intervals = 0

    def finish(self):
        self.eta_known = False
        self.current_item = None
        self.finished = True

    def generator(self):
        if not self.entered:
            raise RuntimeError("You need to use progress bars in a with block.")
        if self.hidden or self.is_hidden:
            if self.is_hidden and not self.hidden:
                self.render_progress()
            yield from self.iter
        else:
            for rv in self.iter:
                self.current_item = rv
                if self._completed_intervals == 0:
                    self.render_progress()
                yield rv
                self.update(1)
            self.finish()
            self.render_progress()


def progressbar(iterable=None, length=None, label=None, hidden=False, show_eta=True,
                show_percent=None, show_pos=False, item_show_func=None, fill_char="#",
                empty_char="-", bar_template="%(label)s  [%(bar)s]  %(info)s", info_sep="  ",
                width=36, file=None, color=None, update_min_steps=1):
    color = resolve_color_default(color)
    return ProgressBar(iterable=iterable, length=length, hidden=hidden, show_eta=show_eta,
                       show_percent=show_percent, show_pos=show_pos,
                       item_show_func=item_show_func, fill_char=fill_char,
                       empty_char=empty_char, bar_template=bar_template, info_sep=info_sep,
                       file=file, label=label, width=width, color=color,
                       update_min_steps=update_min_steps)


# ---- misc helpers ----------------------------------------------------------

def clear():
    if not isatty(sys.stdout):
        return
    echo("\033[2J\033[1;1H", nl=False)


def _translate_ch_to_exc(ch):
    if ch in ("\x03", b"\x03"):
        raise KeyboardInterrupt()
    if ch in ("\x04", b"\x04", "\x1a", b"\x1a"):
        raise EOFError()


def _unix_getchar(echo_=False):
    import termios
    import tty
    f = None
    if not isatty(sys.stdin):
        try:
            f = open("/dev/tty")
            fd = f.fileno()
        except OSError:
            f = None
            fd = sys.stdin.fileno()
    else:
        fd = sys.stdin.fileno()
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            raw = os.read(fd, 32)
            if echo_ and isatty(sys.stdout):
                sys.stdout.write(raw.decode("utf-8", "replace"))
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
            sys.stdout.flush()
    finally:
        if f is not None:
            f.close()
    ch = raw.decode(getattr(sys.stdin, "encoding", None) or "utf-8", "replace")
    _translate_ch_to_exc(ch)
    return ch


def getchar(echo=False):
    f = _getchar
    if f is None:
        f = _unix_getchar
    return f(echo)


def pause(info=None, err=False):
    if info is None:
        info = "Press any key to continue..."
    if not is_interactive():
        if info:
            echo(info, err=err)
        return
    try:
        if info:
            echo(info, nl=False, err=err)
        try:
            getchar()
        except (KeyboardInterrupt, EOFError):
            pass
    finally:
        if info:
            echo(err=err)


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    def get_editor():
        if editor is not None:
            return editor
        for key in ("VISUAL", "EDITOR"):
            rv = os.environ.get(key)
            if rv:
                return rv
        for cand in ("sensible-editor", "vim", "nano"):
            if shutil.which(cand):
                return cand
        return "vi"

    def edit_file(path):
        ed = get_editor()
        environ = None
        if env:
            environ = os.environ.copy()
            environ.update(env)
        try:
            c = subprocess.Popen(f"{ed} {shlex.quote(str(path))}", env=environ, shell=True)
            code = c.wait()
            if code != 0:
                raise OptlynException(f"{ed}: Editing failed")
        except OSError as e:
            raise OptlynException(f"{ed}: Editing failed: {e}") from e

    if filename is not None:
        edit_file(filename)
        return None
    if text is None:
        data = b""
    elif isinstance(text, (bytes, bytearray)):
        data = bytes(text)
    else:
        if text and not text.endswith("\n"):
            text += "\n"
        data = text.encode("utf-8")
    fd, name = tempfile.mkstemp(prefix="editor-", suffix=extension)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        old = time.time() - 5
        os.utime(name, (old, old))
        stamp = os.stat(name).st_mtime_ns
        edit_file(name)
        if require_save and os.stat(name).st_mtime_ns == stamp:
            return None
        with open(name, "rb") as f:
            rv = f.read()
        if isinstance(text, (bytes, bytearray)):
            return rv
        return rv.decode("utf-8-sig").replace("\r\n", "\n")
    finally:
        os.unlink(name)


def launch(url, wait=False, locate=False):
    from urllib.parse import unquote

    def unq(u):
        if u.startswith("file://"):
            u = unquote(u[7:])
        return u

    if sys.platform == "darwin":
        args = ["open"]
        if wait:
            args.append("-W")
        if locate:
            args.append("-R")
        args.append(unq(url))
        with open(os.devnull, "w") as null:
            return subprocess.Popen(args, stderr=null).wait()
    try:
        if locate:
            target = os.path.dirname(unq(url)) or "."
        else:
            target = unq(url)
        c = subprocess.Popen(["xdg-open", target])
        if wait:
            return c.wait()
        return 0
    except OSError:
        if url.startswith(("http://", "https://")) and not locate and not wait:
            import webbrowser
            webbrowser.open(url)
            return 0
        return 1
