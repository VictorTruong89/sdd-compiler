import inspect
from functools import update_wrapper

from .core import Argument, Command, Group, Option
from .globals_ import get_current_context
from .utils import echo


def pass_context(f):
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)
    return update_wrapper(new_func, f)


def pass_obj(f):
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)
    return update_wrapper(new_func, f)


def make_pass_decorator(object_type, ensure=False):
    def decorator(f):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            obj = ctx.ensure_object(object_type) if ensure else ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError("Managed to invoke callback without a context object of "
                                   f"type {object_type.__name__!r} existing.")
            return ctx.invoke(f, obj, *args, **kwargs)
        return update_wrapper(new_func, f)
    return decorator


def _param_memo(f, param):
    if isinstance(f, Command):
        f.params.append(param)
    else:
        if not hasattr(f, "__optlyn_params__"):
            f.__optlyn_params__ = []
        f.__optlyn_params__.append(param)


def _derive_name(f):
    name = f.__name__.lower().replace("_", "-")
    left, sep, suffix = name.rpartition("-")
    if sep and suffix in {"command", "cmd", "group", "grp"}:
        name = left
    return name


def command(name=None, cls=None, **attrs):
    func = None
    if callable(name):
        func = name
        name = None
    if cls is None:
        cls = Command

    def decorator(f):
        if isinstance(f, Command):
            raise TypeError("Attempted to convert a callback into a command twice.")
        kw = dict(attrs)
        params = list(kw.pop("params", None) or [])
        decorated = getattr(f, "__optlyn_params__", None)
        if decorated is not None:
            del f.__optlyn_params__
            params.extend(reversed(decorated))
        if kw.get("help") is None:
            kw["help"] = inspect.getdoc(f)
        else:
            kw["help"] = inspect.cleandoc(kw["help"])
        cmd = cls(name=name or _derive_name(f), callback=f, params=params, **kw)
        cmd.__doc__ = f.__doc__
        return cmd

    if func is not None:
        return decorator(func)
    return decorator


def group(name=None, cls=None, **attrs):
    if cls is None:
        cls = Group
    if callable(name):
        return command(cls=cls, **attrs)(name)
    return command(name, cls, **attrs)


def argument(*param_decls, cls=None, **attrs):
    if cls is None:
        cls = Argument

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f
    return decorator


def option(*param_decls, cls=None, **attrs):
    if cls is None:
        cls = Option

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f
    return decorator


def confirmation_option(*param_decls, **kwargs):
    def callback(ctx, param, value):
        if not value:
            ctx.abort()

    if not param_decls:
        param_decls = ("--yes",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("callback", callback)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")
    return option(*param_decls, **kwargs)


def password_option(*param_decls, **kwargs):
    if not param_decls:
        param_decls = ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("hide_input", True)
    return option(*param_decls, **kwargs)


def version_option(version=None, *param_decls, package_name=None, prog_name=None,
                   message=None, **kwargs):
    if message is None:
        message = "%(prog)s, version %(version)s"
    if version is None and package_name is None:
        frame = inspect.currentframe()
        f_back = frame.f_back if frame else None
        f_globals = f_back.f_globals if f_back else None
        del frame
        if f_globals is not None:
            package_name = f_globals.get("__name__")
            if package_name == "__main__":
                package_name = f_globals.get("__package__")
            if package_name:
                package_name = package_name.partition(".")[0]

    def callback(ctx, param, value):
        nonlocal prog_name, version
        if not value or ctx.resilient_parsing:
            return
        if prog_name is None:
            prog_name = ctx.find_root().info_name
        if version is None and package_name is not None:
            import importlib.metadata
            try:
                version = importlib.metadata.version(package_name)
            except importlib.metadata.PackageNotFoundError:
                dist_names = importlib.metadata.packages_distributions().get(package_name)
                if dist_names is None:
                    raise RuntimeError(f"{package_name!r} is not installed. Try passing "
                                       "'package_name' instead.") from None
                if len(dist_names) > 1:
                    raise RuntimeError(f"Multiple distributions found for package "
                                       f"{package_name}. Pass 'package_name' instead.") from None
                version = importlib.metadata.version(dist_names[0])
            if version is None:
                raise RuntimeError(f"Could not determine the version for {package_name!r} "
                                   "automatically.")
        echo(message % {"prog": prog_name, "package": package_name, "version": version},
             color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*param_decls, **kwargs)


def custom_version_option(callback, *param_decls, **kwargs):
    def cb(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(callback(ctx), color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = cb
    return option(*param_decls, **kwargs)


def help_option(*param_decls, **kwargs):
    def show_help(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(ctx.get_help(), color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", show_help)
    return option(*param_decls, **kwargs)
