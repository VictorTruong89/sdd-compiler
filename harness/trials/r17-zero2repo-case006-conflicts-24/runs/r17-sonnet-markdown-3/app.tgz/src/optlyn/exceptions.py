import os


def _join_hints(hint):
    if isinstance(hint, (list, tuple)):
        return " / ".join(repr(str(h)) for h in hint)
    return hint


class OptlynException(Exception):
    exit_code = 1

    def __init__(self, message=""):
        super().__init__(message)
        self.message = message

    def format_message(self):
        return self.message

    def __str__(self):
        return self.message

    def show(self, file=None):
        from .utils import echo
        echo(f"Error: {self.format_message()}", file=file, err=file is None)


class UsageError(OptlynException):
    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.ctx = ctx
        self.cmd = self.ctx.command if self.ctx else None

    def show(self, file=None):
        from .utils import echo
        color = None
        hint = ""
        err = file is None
        if self.ctx is not None:
            color = self.ctx.color
            if self.cmd is not None and self.cmd.get_help_option(self.ctx) is not None:
                hint = (f"Try '{self.ctx.command_path} "
                        f"{self.ctx.help_option_names[0]}' for help.\n")
            echo(f"{self.ctx.get_usage()}\n{hint}", file=file, err=err, color=color)
        echo(f"Error: {self.format_message()}", file=file, err=err, color=color)


class BadParameter(UsageError):
    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        if self.param_hint is not None:
            hint = self.param_hint
        elif self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        else:
            return f"Invalid value: {self.message}"
        return f"Invalid value for {_join_hints(hint)}: {self.message}"


class MissingParameter(BadParameter):
    def __init__(self, message=None, ctx=None, param=None, param_hint=None, param_type=None):
        super().__init__(message or "", ctx, param, param_hint)
        self.param_type = param_type

    def format_message(self):
        if self.param_hint is not None:
            hint = self.param_hint
        elif self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        else:
            hint = None
        hint = _join_hints(hint)
        hint = f" {hint}" if hint else ""
        ptype = self.param_type
        if ptype is None and self.param is not None:
            ptype = self.param.param_type_name
        msg = self.message
        if self.param is not None:
            extra = self.param.type.get_missing_message(self.param)
            if extra:
                msg = f"{msg}. {extra}" if msg else extra
        msg = f" {msg}" if msg else ""
        return f"Missing {ptype or 'parameter'}{hint}.{msg}"

    def __str__(self):
        if not self.message:
            return f"Missing {self.param_type or 'parameter'}"
        return self.message


class NoSuchOption(UsageError):
    def __init__(self, option_name, message=None, possibilities=None, ctx=None):
        if message is None:
            message = f"No such option: {option_name}"
        super().__init__(message, ctx)
        self.option_name = option_name
        self.possibilities = possibilities

    def format_message(self):
        if not self.possibilities:
            return self.message
        return f"{self.message} (Possible options: {', '.join(sorted(self.possibilities))})"


class BadOptionUsage(UsageError):
    def __init__(self, option_name, message, ctx=None):
        super().__init__(message, ctx)
        self.option_name = option_name


class BadArgumentUsage(UsageError):
    pass


class NoArgsIsHelpError(UsageError):
    def __init__(self, ctx):
        self.ctx = ctx
        super().__init__(ctx.get_help(), ctx=ctx)

    def show(self, file=None):
        from .utils import echo
        echo(self.format_message(), file=file, err=file is None, color=self.ctx.color)


class FileError(OptlynException):
    def __init__(self, filename, hint=None):
        if hint is None:
            hint = "unknown error"
        super().__init__(hint)
        self.ui_filename = _fmt(filename)
        self.filename = filename

    def format_message(self):
        return f"Could not open file {self.ui_filename!r}: {self.message}"


def _fmt(filename):
    from .utils import format_filename
    return format_filename(filename)


class Abort(RuntimeError):
    pass


class Exit(RuntimeError):
    __slots__ = ("exit_code",)

    def __init__(self, code=0):
        self.exit_code = code
