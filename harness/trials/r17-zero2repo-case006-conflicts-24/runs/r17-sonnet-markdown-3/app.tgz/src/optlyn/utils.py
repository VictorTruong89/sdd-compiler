import os
import sys

from . import _compat
from ._compat import (KeepOpenFile, LazyFile, find_binary_writer, is_ascii_encoding,
                      open_stream, should_strip_ansi)
from .formatting import strip_ansi
from .globals_ import resolve_color_default


def safecall(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception:
            pass
    return wrapper


def make_str(value):
    if isinstance(value, bytes):
        try:
            return value.decode(sys.getfilesystemencoding())
        except UnicodeError:
            return value.decode("utf-8", "replace")
    return str(value)


def echo(message=None, file=None, nl=True, err=False, color=None):
    if file is None:
        file = sys.stderr if err else sys.stdout
    if file is None:
        return
    if message is not None and not isinstance(message, (str, bytes, bytearray)):
        out = str(message)
    else:
        out = message
    if nl:
        out = out or ""
        out += b"\n" if isinstance(out, (bytes, bytearray)) else "\n"
    if not out:
        _flush(file)
        return
    if isinstance(out, (bytes, bytearray)):
        binary = find_binary_writer(file)
        if binary is not None:
            _flush(file)
            binary.write(out)
            binary.flush()
            return
        out = out.decode("utf-8", "replace")
    color = resolve_color_default(color)
    if should_strip_ansi(file, color):
        out = strip_ansi(out)
    enc = getattr(file, "encoding", None)
    if enc and is_ascii_encoding(enc):
        binary = find_binary_writer(file)
        if binary is not None:
            _flush(file)
            binary.write(out.encode("utf-8"))
            binary.flush()
            return
    try:
        file.write(out)
    except UnicodeEncodeError:
        binary = find_binary_writer(file)
        if binary is None:
            file.write(out.encode("ascii", "replace").decode("ascii"))
        else:
            _flush(file)
            binary.write(out.encode("utf-8"))
            binary.flush()
            return
    _flush(file)


def _flush(file):
    try:
        file.flush()
    except Exception:
        pass


class StyleError(TypeError, ValueError):
    pass


_ansi_colors = {
    "black": 30, "red": 31, "green": 32, "yellow": 33, "blue": 34, "magenta": 35,
    "cyan": 36, "white": 37, "reset": 39,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
}
_ansi_reset_all = "\033[0m"


def _color_code(color, offset):
    if isinstance(color, bool):
        raise StyleError(f"Unknown color {color!r}")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise StyleError(f"Unknown color {color!r}")
        return f"\033[{38 + offset};5;{color}m"
    if isinstance(color, str):
        if color not in _ansi_colors:
            raise StyleError(f"Unknown color {color!r}")
        return f"\033[{_ansi_colors[color] + offset}m"
    if isinstance(color, (tuple, list)):
        if (len(color) != 3 or not all(isinstance(c, int) and not isinstance(c, bool)
                                       and 0 <= c <= 255 for c in color)):
            raise StyleError(f"Unknown color {color!r}")
        r, g, b = color
        return f"\033[{38 + offset};2;{r};{g};{b}m"
    raise StyleError(f"Unknown color {color!r}")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True):
    if not isinstance(text, str):
        text = str(text)
    bits = []
    if fg is not None:
        bits.append(_color_code(fg, 0))
    if bg is not None:
        bits.append(_color_code(bg, 10))
    for val, on, off in ((bold, 1, 22), (dim, 2, 22), (underline, 4, 24), (overline, 53, 55),
                         (italic, 3, 23), (blink, 5, 25), (reverse, 7, 27),
                         (strikethrough, 9, 29)):
        if val is not None:
            bits.append(f"\033[{on if val else off}m")
    bits.append(text)
    if reset:
        bits.append(_ansi_reset_all)
    return "".join(bits)


def unstyle(text):
    return strip_ansi(text)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None and not isinstance(message, (bytes, bytearray)):
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def format_filename(filename, shorten=False):
    if shorten:
        filename = os.path.basename(filename)
    filename = os.fspath(filename)
    if isinstance(filename, bytes):
        filename = os.fsdecode(filename)
    return filename.encode("utf-8", "backslashreplace").decode("utf-8")


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    f, should_close = open_stream(filename, mode, encoding, errors, atomic=atomic)
    if not should_close:
        f = KeepOpenFile(f)
    return f


def get_app_dir(app_name, roaming=True, force_posix=False):
    def posixify(name):
        return "-".join(name.split()).lower()

    if sys.platform.startswith("win"):
        key = "APPDATA" if roaming else "LOCALAPPDATA"
        folder = os.environ.get(key) or os.path.expanduser("~")
        return os.path.join(folder, app_name)
    if force_posix:
        return os.path.join(os.path.expanduser("~"), "." + posixify(app_name))
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~/Library/Application Support"), app_name)
    return os.path.join(os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")),
                        posixify(app_name))


def get_binary_stream(name):
    return {"stdin": _compat.get_binary_stdin, "stdout": _compat.get_binary_stdout,
            "stderr": _compat.get_binary_stderr}[name]()


def get_text_stream(name, encoding=None, errors="strict"):
    return {"stdin": _compat.get_text_stdin, "stdout": _compat.get_text_stdout,
            "stderr": _compat.get_text_stderr}[name](encoding, errors)
