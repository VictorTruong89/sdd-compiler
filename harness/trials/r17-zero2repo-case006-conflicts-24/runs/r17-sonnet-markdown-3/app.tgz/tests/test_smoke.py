import os
import optlyn as o
from optlyn.testing import CliRunner
import pytest

R = CliRunner()


def run(cmd, args=(), **kw):
    return R.invoke(cmd, list(args), **kw)


def test_basic_options():
    @o.command()
    @o.option("-v", "--verbose", count=True)
    @o.option("--name", multiple=True)
    @o.option("--pair", nargs=2, type=int)
    @o.option("--on/--off", default=True)
    @o.argument("rest", nargs=-1)
    def c(verbose, name, pair, on, rest):
        o.echo(repr((verbose, name, pair, on, rest)))
    r = run(c, ["-vvv", "--name", "a", "--name=b", "--pair", "1", "2", "x", "--off", "y"])
    assert r.output.strip() == "(3, ('a', 'b'), (1, 2), False, ('x', 'y'))"
    r = run(c, [])
    assert r.output.strip() == "(0, (), None, True, ())"


def test_env_default_map_source():
    @o.command()
    @o.option("--a", envvar="AA")
    @o.option("--b")
    @o.pass_context
    def c(ctx, a, b):
        o.echo(f"{a} {b} {ctx.get_parameter_source('a').name} {ctx.get_parameter_source('b').name}")
    r = run(c, [], env={"AA": "1"}, default_map={"b": "2"})
    assert r.output.strip() == "1 2 ENVIRONMENT DEFAULT_MAP"


def test_auto_envvar():
    @o.group()
    def g():
        pass

    @g.command()
    @o.option("--my-opt", required=True)
    def sub(my_opt):
        o.echo(my_opt)
    r = run(g, ["sub"], env={"APP_X_SUB_MY_OPT": "v"}, auto_envvar_prefix="app-x")
    assert r.output.strip() == "v", r.output


def test_prompt_and_password():
    @o.command()
    @o.option("--name", prompt=True)
    @o.password_option()
    def c(name, password):
        o.echo(f"{name}:{password}")
    r = run(c, [], input="bob\nsecret\nsecret\n")
    assert r.exit_code == 0, r.output
    assert "bob:secret" in r.output and "secret\n" not in r.output.replace("bob:secret", "")
    r = run(c, [], input="bob\na\nb\n")
    assert r.exit_code == 1


def test_confirmation():
    @o.command()
    @o.confirmation_option()
    def c():
        o.echo("ran")
    assert run(c, ["--yes"]).output.strip() == "ran"
    assert run(c, [], input="y\n").output.endswith("ran\n")
    r = run(c, [], input="n\n")
    assert r.exit_code == 1 and "Aborted" in r.output
    assert run(c, []).exit_code == 1


def test_version_and_help_order():
    @o.command()
    @o.version_option("1.2.3", prog_name="p")
    @o.option("--x", required=True)
    def c(x):
        pass
    r = run(c, ["--version"])
    assert r.exit_code == 0 and "1.2.3" in r.output
    r = run(c, ["--help", "--version"])
    assert "Usage" in r.output and "1.2.3" not in r.output
    r = run(c, ["--version", "--help"])
    assert "1.2.3" in r.output and "Usage" not in r.output


def test_custom_version():
    @o.command()
    @o.custom_version_option(lambda ctx: "hi there")
    def c():
        pass
    assert run(c, ["--version"]).output == "hi there\n"


def test_chain():
    @o.group(chain=True)
    def g():
        pass

    @g.command()
    def a():
        return 1

    @g.command()
    @o.argument("x")
    def b(x):
        return x

    @g.result_callback()
    def done(vals):
        o.echo(str(vals))
        return vals
    r = run(g, ["a", "b", "z", "a"])
    assert r.output.strip() == "[1, 'z', 1]"
    r = run(g, ["a", "b", "z"], standalone_mode=False)
    assert r.return_value == [1, "z"]


def test_collection_and_lazy():
    @o.group()
    def g1():
        pass

    @g1.command()
    def one():
        o.echo("one")

    @g1.command()
    def two():
        o.echo("two")

    @o.group()
    def g2():
        pass

    @g2.command()
    def three():
        o.echo("three")
    cc = o.group(cls=o.CommandCollection, sources=[g1, g2])(lambda: None)
    assert run(cc, ["three"]).output.strip() == "three"
    assert "one" in run(cc, ["--help"]).output


def test_files(tmp_path):
    p = tmp_path / "f.txt"

    @o.command()
    @o.argument("src", type=o.File("r"))
    @o.argument("dst", type=o.File("w"))
    def c(src, dst):
        dst.write(src.read().upper())
    p.write_text("abc")
    r = run(c, [str(p), str(tmp_path / "out")])
    assert r.exit_code == 0
    assert (tmp_path / "out").read_text() == "ABC"
    r = run(c, [str(tmp_path / "nope"), "-"])
    assert r.exit_code == 2 and "nope" in r.output
    r = run(c, ["-", "-"], input="xyz")
    assert r.output == "XYZ"


def test_path_checks(tmp_path):
    @o.command()
    @o.argument("p", type=o.Path(exists=True, file_okay=False))
    def c(p):
        o.echo(p)
    assert run(c, [str(tmp_path)]).exit_code == 0
    r = run(c, [str(tmp_path / "x")])
    assert r.exit_code == 2 and str(tmp_path / "x") in r.output


def test_types():
    import enum

    class E(enum.Enum):
        A = 1
        B = 2

    @o.command()
    @o.option("--e", type=o.Choice(E))
    @o.option("--r", type=o.IntRange(0, 10, clamp=True))
    @o.option("--d", type=o.DateTime())
    @o.option("--t", type=o.Tuple([str, int]))
    def c(e, r, d, t):
        o.echo(repr((e, r, d, t)))
    r = run(c, ["--e", "A", "--r", "50", "--d", "2020-01-02", "--t", "a", "3"])
    assert r.output.strip() == "(<E.A: 1>, 10, datetime.datetime(2020, 1, 2, 0, 0), ('a', 3))", r.output
    assert run(c, ["--e", "C"]).exit_code == 2


def test_deprecated():
    @o.command(deprecated="use other")
    @o.option("--x", deprecated=True)
    def c(x):
        o.echo("ok")
    r = run(c, [])
    assert r.exit_code == 0 and "use other" in r.stderr and "--x" not in r.stderr
    r = run(c, ["--x", "1"])
    assert "option" in r.stderr
    with pytest.raises(TypeError):
        o.option("--y", deprecated=True, required=True)(lambda: 0)


def test_style_echo():
    assert o.unstyle(o.style("hi", fg="red", bold=True)) == "hi"
    with pytest.raises(Exception):
        o.style("x", fg="nope")

    @o.command()
    def c():
        o.secho("x", fg="green")
    assert run(c).output == "x\n"
    assert "\x1b[" in run(c, color=True).output


def test_completion(monkeypatch):
    @o.group()
    def cli():
        pass

    @cli.command()
    @o.option("--color", type=o.Choice(["red", "green"]))
    def sub(color):
        pass

    @cli.command(hidden=True)
    def secret():
        pass
    env = {"_CLI_COMPLETE": "bash_complete", "COMP_WORDS": "cli ", "COMP_CWORD": "1"}
    r = run(cli, [], env=env, prog_name="cli")
    assert r.output.strip() == "plain,sub", r.output
    env = {"_CLI_COMPLETE": "bash_complete", "COMP_WORDS": "cli sub --color ", "COMP_CWORD": "3"}
    assert run(cli, [], env=env, prog_name="cli").output.split() == ["plain,red", "plain,green"]
    env = {"_CLI_COMPLETE": "bash_source"}
    assert "complete" in run(cli, [], env=env, prog_name="cli").output
    env = {"_CLI_COMPLETE": "weird_x"}
    r = run(cli, [], env=env, prog_name="cli")
    assert r.output == "" and r.exit_code == 1


def test_progressbar():
    @o.command()
    def c():
        with o.progressbar([1, 2, 3], label="lbl") as bar:
            o.echo(str(list(bar)))
    r = run(c)
    assert "lbl" in r.output and "[1, 2, 3]" in r.output


def test_fd_capture():
    r = CliRunner(capture="fd")

    @o.command()
    def c():
        os.write(1, b"raw\n")
        o.echo("py")
    res = r.invoke(c, [])
    assert "raw" in res.stdout and "py" in res.stdout


def test_app_dir(monkeypatch):
    monkeypatch.setenv("XDG_CONFIG_HOME", "/x")
    assert o.get_app_dir("My App") == "/x/my-app"
    assert o.get_app_dir("My App", force_posix=True).endswith("/.my-app")


def test_help_extras():
    @o.command(epilog="EPI", context_settings={"show_default": True})
    @o.option("--a", default=3, help="aa", envvar="AENV", show_envvar=True)
    @o.option("--c", type=o.Choice(["x", "y"]))
    @o.argument("f", help="ffile")
    def c(a, c, f):
        """Desc."""
    out = run(c, ["--help"]).output
    assert "Positional arguments" in out and "FFILE".lower() in out
    assert "default: 3" in out and "AENV" in out and out.strip().endswith("EPI")
    assert "[x|y]" in out
