import os, sys, stat
import optlyn as o
from optlyn.testing import CliRunner

R = CliRunner()


def run(cmd, args=(), **kw):
    return R.invoke(cmd, list(args), **kw)


def test_feature_switch():
    @o.command()
    @o.option("--upper", "t", flag_value="upper")
    @o.option("--lower", "t", flag_value="lower", default=True)
    def c(t):
        o.echo(t)
    assert run(c).output.strip() == "lower"
    assert run(c, ["--upper"]).output.strip() == "upper"
    assert run(c, ["--upper", "--lower"]).output.strip() == "lower"


def test_flag_env():
    @o.command()
    @o.option("--f", is_flag=True, envvar="F")
    def c(f):
        o.echo(str(f))
    assert run(c, env={"F": "YES"}).output.strip() == "True"
    assert run(c, env={"F": "  "}).output.strip() == "False"
    assert run(c, env={"F": "maybe"}).exit_code == 2


def test_optional_value():
    @o.command()
    @o.option("--x", is_flag=False, flag_value="FV", default="D")
    def c(x):
        o.echo(x)
    assert run(c).output.strip() == "D"
    assert run(c, ["--x"]).output.strip() == "FV"
    assert run(c, ["--x", "v"]).output.strip() == "v"


def test_group_noargs_nested():
    @o.group()
    def g():
        o.echo("g")

    @g.group()
    def inner():
        o.echo("inner")

    @inner.command()
    def leaf():
        pass
    r = run(g, ["inner"])
    assert r.exit_code == 2 and r.output.startswith("g\n") and "Usage: g inner" in r.output


def test_ignore_unknown_and_dashdash():
    @o.command(context_settings={"ignore_unknown_options": True})
    @o.argument("a", nargs=-1)
    def c(a):
        o.echo(repr(a))
    assert run(c, ["--foo", "-xy", "z"]).output.strip() == "('--foo', '-xy', 'z')"

    @o.command()
    @o.option("--f", is_flag=True)
    @o.argument("a", nargs=-1)
    def d(f, a):
        o.echo(repr((f, a)))
    assert run(d, ["--", "--f"]).output.strip() == "(False, ('--f',))"
    assert run(d, ["--bad"]).exit_code == 2


def test_extra_args():
    @o.command(context_settings={"allow_extra_args": True})
    @o.argument("a", required=False)
    def c(a):
        o.echo(str(a))
    assert run(c, ["1", "2"]).output.strip() == "1"
    assert run(c, ["1", "-x"]).exit_code == 2


def test_normalize():
    @o.command(context_settings={"token_normalize_func": str.lower})
    @o.option("--Name")
    @o.option("--c", type=o.Choice(["A"]))
    def c(name, c):
        o.echo(f"{name} {c}")
    assert run(c, ["--NAME", "x", "--c", "a"]).output.strip() == "x A"


def test_help_names():
    @o.command(context_settings={"help_option_names": ["-h"]})
    def c():
        pass
    assert run(c, ["-h"]).exit_code == 0
    assert run(c, ["--help"]).exit_code == 2

    @o.command()
    @o.argument("help")
    def d(help):
        o.echo(help)
    assert run(d, ["--help"]).exit_code == 0 and run(d, ["x"]).output == "x\n"

    @o.command(add_help_option=False)
    def e():
        pass
    assert run(e, ["--help"]).exit_code == 2


def test_lazy_write_error(tmp_path):
    @o.command()
    @o.argument("f", type=o.File("w"))
    def c(f):
        f.write("x")
        o.echo("after")
    r = run(c, [str(tmp_path / "no" / "f")])
    assert r.exit_code == 1 and "after" not in r.output and "no" in r.output


def test_default_multiple_str():
    @o.command()
    @o.option("--x", multiple=True, default="abc")
    def c(x):
        pass
    r = run(c)
    assert r.exit_code == 2 and "--x" in r.output and "iterable" in r.output


def test_no_args_is_help_leaf_and_contextual():
    @o.command(no_args_is_help=True)
    def c():
        pass
    r = run(c)
    assert r.exit_code == 2 and "Usage" in r.stderr


def test_invoke_forward_obj():
    @o.command()
    @o.option("--n", default=2)
    def other(n):
        o.echo(f"other {n}")

    @o.command()
    @o.option("--n", default=5)
    @o.pass_context
    def main(ctx, n):
        ctx.forward(other)
        ctx.invoke(other, n=9)
    assert run(main).output == "other 5\nother 9\n"


def test_pass_decorators():
    class T: pass

    @o.group()
    @o.pass_context
    def g(ctx):
        ctx.obj = T()

    @g.command()
    @o.make_pass_decorator(T)
    def s(t):
        o.echo(type(t).__name__)

    @g.command()
    @o.make_pass_decorator(dict, ensure=True)
    def s2(d):
        o.echo(str(d))
    assert run(g, ["s"]).output == "T\n"
    assert run(g, ["s2"]).output == "{}\n"


def test_resources_closed():
    log = []

    class CM:
        def __enter__(self): log.append("in"); return 1
        def __exit__(self, *a): log.append("out")

    @o.group()
    @o.pass_context
    def g(ctx):
        ctx.with_resource(CM())

    @g.command()
    def s():
        log.append("sub")
        raise SystemExit(3)
    r = run(g, ["s"])
    assert r.exit_code == 3 and log == ["in", "sub", "out"]


def test_confirm_prompt_funcs():
    @o.command()
    def c():
        v = o.prompt("N", type=int, default=3)
        o.echo(str(v))
        o.echo(str(o.confirm("ok?", default=True)))
    r = run(c, input="x\n\n\n")
    assert r.output.splitlines()[-1] == "True" and "3" in r.output
    r = run(c, input="")
    assert r.exit_code == 1


def test_edit_launch(tmp_path, monkeypatch):
    ed = tmp_path / "ed.sh"
    ed.write_text("#!/bin/sh\necho edited >> \"$1\"\n")
    ed.chmod(0o755)
    assert o.edit("hi", editor=str(ed)) == "hi\nedited\n"
    noop = tmp_path / "noop.sh"
    noop.write_text("#!/bin/sh\ntrue\n"); noop.chmod(0o755)
    assert o.edit("hi", editor=str(noop)) is None


def test_pager_noninteractive():
    @o.command()
    def c():
        o.echo_via_pager(["a\n", "b\n"])
        with o.get_pager_file() as f:
            f.write("zz\n")
    assert run(c).output == "a\nb\n\nzz\n"


def test_format_filename():
    assert o.format_filename(b"a\xffb") != o.format_filename(b"a\xfeb")
    o.format_filename(b"a\xffb").encode("utf-8")


def test_isolated_fs():
    with R.isolated_filesystem() as d:
        assert os.getcwd() == os.path.realpath(d) or os.getcwd() == d


def test_ascii_stdout():
    import io
    buf = io.BytesIO()
    w = io.TextIOWrapper(buf, encoding="ascii")
    o.echo("héllo", file=w)
    assert buf.getvalue() == "héllo\n".encode()


def test_hidden_in_help_but_callable():
    @o.group()
    def g():
        pass

    @g.command(hidden=True)
    def sec():
        o.echo("s")

    @g.command()
    @o.option("--h", hidden=True)
    def vis(h):
        pass
    r = run(g, ["--help"])
    assert "sec" not in r.output and "vis" in r.output
    assert run(g, ["sec"]).output == "s\n"
    assert "--h " not in run(g, ["vis", "--help"]).output
