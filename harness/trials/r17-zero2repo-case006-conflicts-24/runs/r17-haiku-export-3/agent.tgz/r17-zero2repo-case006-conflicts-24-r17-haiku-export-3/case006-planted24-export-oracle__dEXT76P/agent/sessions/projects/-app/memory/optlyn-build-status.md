---
name: optlyn-build-status
description: "State of the Optlyn library built from /app/spec — layout, test command, and where the spec-conflict decisions live"
metadata:
  node_type: memory
  type: project
  originSessionId: 9eec5d86-1757-474f-91eb-7d12328f90c1
  modified: 2026-11-02T02:46:31.789Z
---

The Optlyn CLI-composition library is built in /app/src/optlyn (src layout, zero deps, Python >=3.10). 128 tests in /app/tests pass with `PYTHONPATH=src python3 -m pytest tests`.

**Why:** the user asked for a from-scratch build of the spec in /app; the spec has 28 unsettled contradictions (`--allow-open` export), so the choices were made and recorded.

**How to apply:**
- Spec conflicts and the chosen resolution are in /app/NOTES.md. Don't re-derive them; reuse that table if the user asks.
- Do not edit /app/spec (including CHECKLIST.md). Checklist accounting lives in NOTES.md instead.
- The module is `paramtypes.py`, not `types.py`: a `types.py` inside the package shadows the stdlib `types` module when Python runs from that directory.
- Windows, macOS, interactive-TTY and non-bash shell paths are not exercised by tests (listed in NOTES.md).
