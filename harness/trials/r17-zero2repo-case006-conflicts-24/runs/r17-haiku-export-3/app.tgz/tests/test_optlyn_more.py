import pathlib
import threading

import pytest

import optlyn
from optlyn import (
    Choice,
    ParamType,
    argument,
    command,
    echo,
    group,
    option,
    pass_context,
    progressbar,
)
from optlyn.termui import echo_via_pager, get_pager_file, getchar, edit
from optlyn.testing import CliRunner


@pytest.fixture
def runner():
    return CliRunner()


def test_optional_value_option(runner):
    @command()
    @option("--color", is_flag=False, flag_value="auto", default="never")
    def cmd(color):
        echo(color)

    assert runner.invoke(cmd, []).output == "never\n"
    assert runner.invoke(cmd, ["--color"]).output == "auto\n"
    assert runner.invoke(cmd, ["--color", "always"]).output == "always\n"


def test_prompt_reasks_on_conversion_failure(runner):
    @command()
    @option("--n", type=int, prompt=True)
    def cmd(n):
        echo(str(n))

    res = runner.invoke(cmd, [], input="abc\n12\n")
    assert res.exit_code == 0
    assert res.stdout.rstrip().endswith("12")
    assert "not a valid integer" in res.stderr


def test_flag_given_without_value_prompts(runner):
    @command()
    @option("--name", prompt="Name")
    def cmd(name):
        echo(name)

    res = runner.invoke(cmd, ["--name"], input="zed\n")
    assert res.exit_code == 0 and res.stdout.rstrip().endswith("zed")


def test_prompt_not_required_omitted_uses_default(runner):
    @command()
    @option("--name", prompt=True, prompt_required=False, default="d")
    def cmd(name):
        echo(name)

    res = runner.invoke(cmd, [], input="ignored\n")
    assert res.output == "d\n"


def test_token_normalize_func(runner):
    @command(context_settings={"token_normalize_func": lambda s: s.lower()})
    @option("--Name", "name")
    @argument("pick", type=Choice(["alpha"]))
    def cmd(name, pick):
        echo(f"{name} {pick}")

    assert runner.invoke(cmd, ["--NAME", "x", "ALPHA"]).output == "x alpha\n"


def test_custom_param_type(runner):
    class Upper(ParamType):
        name = "upper"

        def convert(self, value, param=None, ctx=None):
            if isinstance(value, str):
                if not value.isalpha():
                    self.fail("letters only", param, ctx)
                return value.upper()
            return value

    @command()
    @option("--u", type=Upper())
    def cmd(u):
        echo(u)

    assert runner.invoke(cmd, ["--u", "abc"]).output == "ABC\n"
    res = runner.invoke(cmd, ["--u", "a1"])
    assert res.exit_code == 2 and "--u" in res.stderr


def test_function_type_refusal(runner):
    def positive(text):
        value = int(text)
        if value <= 0:
            raise ValueError("must be positive")
        return value

    @command()
    @option("--p", type=positive)
    def cmd(p):
        echo(str(p))

    assert runner.invoke(cmd, ["--p", "3"]).output == "3\n"
    res = runner.invoke(cmd, ["--p", "-1"])
    assert res.exit_code == 2 and "positive" in res.stderr or "must be" in res.stderr


def test_deprecated_option_warns_only_when_supplied(runner):
    @command()
    @option("--old", deprecated="use --new")
    @option("--x", default="1")
    def cmd(old, x):
        echo(f"{old}{x}")

    assert "deprecated" not in runner.invoke(cmd, []).stderr
    res = runner.invoke(cmd, ["--old", "a"])
    assert "deprecated" in res.stderr and "use --new" in res.stderr
    assert res.stdout == "a1\n"


def test_ignore_unknown_options(runner):
    @command(context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
    @argument("rest", nargs=-1)
    def cmd(rest):
        echo(repr(rest))

    res = runner.invoke(cmd, ["--zzz", "a"])
    assert res.exit_code == 0
    assert res.stdout == "('--zzz', 'a')\n"


def test_unknown_short_in_stack_splits(runner):
    @command(context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
    @option("-v", is_flag=True)
    @argument("rest", nargs=-1)
    def cmd(v, rest):
        echo(f"{v} {list(rest)}")

    res = runner.invoke(cmd, ["-vx"])
    assert res.stdout == "True ['-x']\n"


def test_chained_child_options_before_args(runner):
    @group(chain=True)
    def cli():
        pass

    @cli.command()
    @option("--k")
    @argument("a")
    def one(k, a):
        echo(f"one {k} {a}")

    @cli.command()
    def two():
        echo("two")

    res = runner.invoke(cli, ["one", "--k", "v", "x", "two"])
    assert res.stdout == "one v x\ntwo\n"


def test_chain_no_subcommand_with_invoke_without_command_runs_result_callback(runner):
    @group(chain=True, invoke_without_command=True)
    def cli():
        pass

    @cli.result_callback()
    def done(results):
        echo(f"results={results}")

    assert runner.invoke(cli, []).stdout == "results=[]\n"


def test_non_chain_result_callback_gets_single_value(runner):
    @group(invoke_without_command=False)
    def cli():
        pass

    @cli.command()
    def sub():
        return 5

    @cli.result_callback()
    def done(value):
        echo(f"value={value}")

    assert runner.invoke(cli, ["sub"]).stdout == "value=5\n"


def test_nested_group_no_args_shows_its_help(runner):
    @group()
    def cli():
        pass

    @cli.group()
    def inner():
        """Inner help text."""

    @inner.command()
    def leaf():
        pass

    res = runner.invoke(cli, ["inner"])
    assert res.exit_code == 2
    assert "Inner help text." in res.stderr


def test_auto_env_not_used_when_opted_out(runner):
    @command()
    @option("--sec", allow_from_autoenv=False)
    def cmd(sec):
        echo(str(sec))

    res = runner.invoke(cmd, [], auto_envvar_prefix="APP", env={"APP_SEC": "x"})
    assert res.stdout == "None\n"


def test_auto_env_used_by_default(runner):
    @command()
    @option("--sec")
    def cmd(sec):
        echo(str(sec))

    res = runner.invoke(cmd, [], auto_envvar_prefix="APP", env={"APP_SEC": "x"})
    assert res.stdout == "x\n"


def test_hidden_option_not_in_help(runner):
    @command()
    @option("--shh", hidden=True)
    @option("--seen")
    def cmd(shh, seen):
        pass

    out = runner.invoke(cmd, ["--help"]).stdout
    assert "--shh" not in out and "--seen" in out


def test_show_default_and_envvar_in_help(runner):
    @command()
    @option("--n", type=int, default=3, show_default=True)
    @option("--e", envvar="E_VAR", show_envvar=True)
    def cmd(n, e):
        pass

    out = runner.invoke(cmd, ["--help"]).stdout
    assert "[default: 3" in out and "E_VAR" in out


def test_flag_default_true_shows_default_false_hidden(runner):
    @command(context_settings={"show_default": True})
    @option("--on", is_flag=True, default=True)
    @option("--off", is_flag=True, default=False)
    def cmd(on, off):
        pass

    out = runner.invoke(cmd, ["--help"]).stdout
    on_line = [line for line in out.splitlines() if "--on" in line][0]
    off_line = [line for line in out.splitlines() if "--off" in line][0]
    assert "default" in on_line and "default" not in off_line


def test_version_option_detects_package(runner):
    @command()
    @optlyn.version_option(version="1.2.3", prog_name="tool")
    def cmd():
        pass

    res = runner.invoke(cmd, ["--version"])
    assert res.stdout == "tool, version 1.2.3\n"


def test_help_option_custom_names(runner):
    @command(context_settings={"help_option_names": ["-h", "--help"]})
    def cmd():
        """Desc."""

    assert runner.invoke(cmd, ["-h"]).exit_code == 0
    assert "Desc." in runner.invoke(cmd, ["-h"]).stdout


def test_author_option_reusing_help_name_drops_auto_help(runner):
    @command()
    @option("--help", is_flag=True)
    def cmd(help):
        echo(f"help={help}")

    assert runner.invoke(cmd, ["--help"]).stdout == "help=True\n"


def test_file_atomic_write(runner, tmp_path):
    @command()
    @option("--out", type=optlyn.File("w", atomic=True, lazy=False))
    def cmd(out):
        out.write("new")
        assert pathlib.Path(out.name).read_text() == "old"

    with runner.isolated_filesystem():
        pathlib.Path("t.txt").write_text("old")
        res = runner.invoke(cmd, ["--out", "t.txt"])
        assert res.exit_code == 0, res.output
        assert pathlib.Path("t.txt").read_text() == "new"


def test_path_resolve_and_allow_dash(runner):
    @command()
    @argument("p", type=optlyn.Path(allow_dash=True))
    def cmd(p):
        echo(p)

    assert runner.invoke(cmd, ["-"]).stdout == "-\n"


def test_dash_file_write_does_not_close_stdout(runner):
    @group(chain=True)
    def cli():
        pass

    @cli.command()
    @option("--out", type=optlyn.File("w"))
    def write(out):
        out.write("first\n")

    @cli.command()
    def after():
        echo("after")

    res = runner.invoke(cli, ["write", "--out", "-", "after"])
    assert res.exit_code == 0, res.output
    assert res.stdout == "first\nafter\n"


def test_progressbar_no_tty_visits_all_items_and_label_once(runner):
    @command()
    def cmd():
        items = list(progressbar(range(4), label="Work"))
        echo(str(items))

    res = runner.invoke(cmd, [])
    assert res.stdout == "Work\n[0, 1, 2, 3]\n"


def test_progressbar_hidden_prints_nothing(runner):
    @command()
    def cmd():
        with progressbar(length=3, label="Hidden", hidden=True) as bar:
            bar.update(3)
        echo("done")

    assert runner.invoke(cmd, []).stdout == "done\n"


def test_echo_via_pager_non_interactive(runner):
    @command()
    def cmd():
        echo_via_pager(["a\n", "b\n"])
        with get_pager_file() as f:
            f.write("c\n")

    assert runner.invoke(cmd, []).stdout == "a\nb\nc\n"


def test_launch_and_clear_and_edit_filename(runner, tmp_path):
    from optlyn.termui import clear as clear_fn

    clear_fn()  # no terminal: does nothing
    target = tmp_path / "f.txt"
    target.write_text("x")
    # editor that appends a line, using a Python one-liner as the editor
    import sys as _sys
    editor = f'"{_sys.executable}" -c "import sys; open(sys.argv[-1],\'a\').write(\'y\')"'
    assert edit(editor=editor, filename=str(target)) is None
    assert target.read_text() == "xy"
    text = edit("hi", editor=editor, require_save=True)
    assert text == "hiy"


def test_getchar_eof_on_pipe_raises(runner):
    @command()
    def cmd():
        try:
            getchar()
        except EOFError:
            echo("eof")

    res = runner.invoke(cmd, [], input="")
    assert res.stdout.strip() in ("eof",) or res.exit_code in (0, 1)


def test_thread_does_not_see_context_unless_entered(runner):
    seen = []

    @command()
    @pass_context
    def cmd(ctx):
        def worker():
            seen.append(optlyn.get_current_context(silent=True))

        t = threading.Thread(target=worker)
        t.start()
        t.join()
        echo("ok")

    res = runner.invoke(cmd, [])
    assert res.stdout == "ok\n" and seen == [None]


def test_user_context_manager_protocol(runner):
    ctx = optlyn.Context(optlyn.Command("c"))
    with ctx:
        assert optlyn.get_current_context() is ctx
    assert optlyn.get_current_context(silent=True) is None
    with pytest.raises(RuntimeError):
        optlyn.get_current_context()


def test_option_callback_can_replace_value(runner):
    @command()
    @option("--x", type=int, default=1, callback=lambda ctx, p, v: v * 10)
    def cmd(x):
        echo(str(x))

    assert runner.invoke(cmd, []).stdout == "10\n"


def test_argument_envvar(runner):
    @command()
    @argument("who", envvar="WHO_ENV")
    def cmd(who):
        echo(who)

    assert runner.invoke(cmd, [], env={"WHO_ENV": "env-val"}).stdout == "env-val\n"
    assert runner.invoke(cmd, ["cli"], env={"WHO_ENV": "env-val"}).stdout == "cli\n"


def test_required_argument_satisfied_by_envvar_not_by_name(runner):
    @command()
    @argument("who")
    def cmd(who):
        echo(who)

    assert runner.invoke(cmd, [], env={"WHO": "nope"}).exit_code == 2


def test_required_option_satisfied_by_default_map(runner):
    @command()
    @option("--must", required=True)
    def cmd(must):
        echo(must)

    assert runner.invoke(cmd, [], default_map={"must": "dm"}).stdout == "dm\n"


def test_variadic_twice_refused_at_declaration():
    with pytest.raises(TypeError):
        @command()
        @argument("a", nargs=-1)
        @argument("b", nargs=-1)
        def cmd(a, b):
            pass


def test_echo_stdin_mode_echoes_reads():
    r = CliRunner(echo_stdin=True)

    @command()
    def cmd():
        echo(input_line())

    def input_line():
        import sys as _s
        return _s.stdin.readline().strip()

    res = r.invoke(cmd, [], input="typed\n")
    assert res.stdout == "typed\ntyped\n"
