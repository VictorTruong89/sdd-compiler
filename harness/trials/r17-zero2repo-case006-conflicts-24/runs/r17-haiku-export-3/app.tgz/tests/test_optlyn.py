import os
import pathlib
import uuid

import pytest

import optlyn
from optlyn import (
    Choice,
    FloatRange,
    IntRange,
    argument,
    command,
    confirmation_option,
    custom_version_option,
    echo,
    group,
    make_pass_decorator,
    option,
    pass_context,
    pass_obj,
    password_option,
)
from optlyn.formatting import wrap_text
from optlyn.termui import get_app_dir, format_filename, style, unstyle, secho
from optlyn.testing import CliRunner


@pytest.fixture
def runner():
    return CliRunner()


# --- FP-01 naming and invocation -------------------------------------------

def test_default_name_strips_suffix_and_dashes(runner):
    @command()
    def init_db_cmd():
        echo("ran")

    assert init_db_cmd.name == "init-db"
    res = runner.invoke(init_db_cmd, [])
    assert res.exit_code == 0 and res.output == "ran\n"


def test_explicit_name_replaces_derived(runner):
    @command("go")
    def something():
        echo("x")

    assert something.name == "go"
    assert runner.invoke(something, []).exit_code == 0


def test_declarations_move_off_the_function():
    @command()
    @option("--a")
    def f(a):
        pass

    assert f.params[0].name == "a"
    assert not hasattr(f, "__optlyn_params__")


def test_unknown_option_is_usage_error_and_callback_not_run(runner):
    calls = []

    @command()
    def cmd():
        calls.append(1)

    res = runner.invoke(cmd, ["--nope"])
    assert res.exit_code == 2
    assert calls == []
    assert "No such option" in res.stderr


def test_extra_args_rejected_then_allowed(runner):
    @command()
    @argument("a")
    def cmd(a):
        echo(a)

    assert runner.invoke(cmd, ["x", "y"]).exit_code == 2
    res = runner.invoke(cmd, ["x", "y"], )
    assert res.exit_code == 2


def test_allow_extra_args_setting(runner):
    @command(context_settings={"allow_extra_args": True})
    @argument("a")
    def cmd(a):
        echo(a)

    res = runner.invoke(cmd, ["x", "y"])
    assert res.exit_code == 0 and res.output == "x\n"


def test_deprecated_command_still_runs(runner):
    @command(deprecated="use other")
    def old():
        echo("ran")

    res = runner.invoke(old, [])
    assert res.exit_code == 0
    assert "ran" in res.stdout
    assert "deprecated" in res.stderr and "use other" in res.stderr


# --- FP-02 help ----------------------------------------------------------------

def test_help_is_success_and_skips_callback(runner):
    calls = []

    @command(help="Does things.\fsecret")
    @option("--n", type=int, help="A number.")
    def cmd(n):
        calls.append(n)

    res = runner.invoke(cmd, ["--help"])
    assert res.exit_code == 0
    assert calls == []
    assert "Usage:" in res.stdout and "Does things." in res.stdout
    assert "secret" not in res.stdout
    assert "--n INTEGER" in res.stdout and "A number." in res.stdout


def test_group_without_subcommand_is_usage_failure_with_help(runner):
    @group()
    def cli():
        """Top."""

    @cli.command()
    def sub():
        echo("sub")

    res = runner.invoke(cli, [])
    assert res.exit_code == 2
    assert "Usage:" in res.stderr and "Commands:" in res.stderr
    assert "sub" in res.stderr


def test_help_option_before_group_subcommand_is_group_help(runner):
    @group()
    def cli():
        echo("group-ran")

    @cli.command()
    def sub():
        echo("sub")

    res = runner.invoke(cli, ["--help", "sub"])
    assert res.exit_code == 0
    assert "group-ran" not in res.stdout


def test_no_help_option_when_disabled(runner):
    @command(add_help_option=False)
    def cmd():
        pass

    assert runner.invoke(cmd, ["--help"]).exit_code == 2


def test_hidden_command_omitted_from_help_but_invocable(runner):
    @group()
    def cli():
        pass

    @cli.command(hidden=True)
    def secret():
        echo("secret-ran")

    assert "secret" not in runner.invoke(cli, ["--help"]).stdout
    assert runner.invoke(cli, ["secret"]).output == "secret-ran\n"


def test_short_help_and_metavars(runner):
    @group()
    def cli():
        pass

    @cli.command()
    def first():
        """First sentence here. And more text."""

    res = runner.invoke(cli, ["--help"])
    assert "First sentence here." in res.stdout
    assert "And more" not in res.stdout


def test_version_option_prints_and_exits(runner):
    @command()
    @custom_version_option(lambda ctx: "custom-1.2")
    def cmd():
        echo("ran")

    res = runner.invoke(cmd, ["--version"])
    assert res.exit_code == 0
    assert res.stdout == "custom-1.2\n"


def test_eager_first_typed_wins(runner):
    @command()
    @custom_version_option(lambda ctx: "v9")
    @option("--req", required=True)
    def cmd(req):
        echo("ran")

    res = runner.invoke(cmd, ["--version"])
    assert res.exit_code == 0 and res.stdout == "v9\n"


# --- FP-03 options -------------------------------------------------------------

def test_flag_stacking_and_counting(runner):
    @command()
    @option("-v", "--verbose", count=True)
    @option("-q", is_flag=True)
    def cmd(verbose, q):
        echo(f"{verbose} {q}")

    assert runner.invoke(cmd, ["-vvv", "-q"]).output == "3 True\n"
    assert runner.invoke(cmd, []).output == "0 False\n"


def test_value_attached_and_separate(runner):
    @command()
    @option("-n", type=int)
    @option("--name")
    def cmd(n, name):
        echo(f"{n}|{name}")

    assert runner.invoke(cmd, ["-n5", "--name=bob"]).output == "5|bob\n"
    assert runner.invoke(cmd, ["-n", "7", "--name", "al"]).output == "7|al\n"


def test_double_dash_ends_options(runner):
    @command()
    @option("--x", is_flag=True)
    @argument("rest", nargs=-1)
    def cmd(x, rest):
        echo(f"{x} {list(rest)}")

    res = runner.invoke(cmd, ["--", "--x", "y"])
    assert res.output == "False ['--x', 'y']\n"


def test_multiple_option(runner):
    @command()
    @option("--item", multiple=True)
    def cmd(item):
        echo(repr(item))

    assert runner.invoke(cmd, ["--item", "a", "--item", "b"]).output == "('a', 'b')\n"
    assert runner.invoke(cmd, []).output == "()\n"


def test_multiple_bare_string_default_is_usage_error(runner):
    @command()
    @option("--item", multiple=True, default="abc")
    def cmd(item):
        echo("ran")

    res = runner.invoke(cmd, [])
    assert res.exit_code == 2
    assert "iterable" in res.stderr


def test_required_option_missing(runner):
    @command()
    @option("--must", required=True)
    def cmd(must):
        echo("ran")

    res = runner.invoke(cmd, [])
    assert res.exit_code == 2
    assert "--must" in res.stderr


def test_on_off_pair(runner):
    @command()
    @option("--shout/--quiet", default=False)
    def cmd(shout):
        echo(str(shout))

    assert runner.invoke(cmd, ["--shout"]).output == "True\n"
    assert runner.invoke(cmd, ["--quiet"]).output == "False\n"


def test_tuple_option_arity(runner):
    @command()
    @option("--pt", type=(int, str))
    def cmd(pt):
        echo(repr(pt))

    assert runner.invoke(cmd, ["--pt", "3", "x"]).output == "(3, 'x')\n"


def test_nargs_option(runner):
    @command()
    @option("--pair", nargs=2)
    def cmd(pair):
        echo(repr(pair))

    assert runner.invoke(cmd, ["--pair", "a", "b"]).output == "('a', 'b')\n"
    assert runner.invoke(cmd, ["--pair", "a"]).exit_code == 2


def test_callback_refusal_is_usage_error(runner):
    def check(ctx, param, value):
        raise optlyn.BadParameter("nope")

    @command()
    @option("--x", callback=check)
    def cmd(x):
        echo("ran")

    res = runner.invoke(cmd, ["--x", "1"])
    assert res.exit_code == 2 and "--x" in res.stderr


# --- FP-04 positional arguments -----------------------------------------------

def test_arguments_fill_in_order(runner):
    @command()
    @argument("src")
    @argument("dst", required=False, default="out")
    def cmd(src, dst):
        echo(f"{src}->{dst}")

    assert runner.invoke(cmd, ["a"]).output == "a->out\n"
    assert runner.invoke(cmd, ["a", "b"]).output == "a->b\n"


def test_variadic_argument_and_dd(runner):
    @command()
    @argument("files", nargs=-1)
    def cmd(files):
        echo(repr(files))

    assert runner.invoke(cmd, ["a", "b"]).output == "('a', 'b')\n"
    assert runner.invoke(cmd, []).output == "()\n"


# --- FP-05 types ----------------------------------------------------------------

@pytest.mark.parametrize("ptype,token,expected", [
    (optlyn.INT, "3", 3),
    (optlyn.FLOAT, "1.5", 1.5),
    (optlyn.BOOL, "yes", True),
    (optlyn.UUID, "12345678-1234-5678-1234-567812345678", uuid.UUID("12345678-1234-5678-1234-567812345678")),
])
def test_builtin_types(runner, ptype, token, expected):
    @command()
    @option("--v", type=ptype)
    def cmd(v):
        echo(repr(v))

    assert runner.invoke(cmd, ["--v", token]).output == repr(expected) + "\n"


def test_int_refuses_fraction(runner):
    @command()
    @option("--v", type=int)
    def cmd(v):
        pass

    assert runner.invoke(cmd, ["--v", "1.5"]).exit_code == 2


def test_choice_delivers_original_and_case_rules(runner):
    import enum

    class Color(enum.Enum):
        red = 1
        blue = 2

    @command()
    @option("--c", type=Choice(Color, case_sensitive=False))
    def cmd(c):
        echo(repr(c))

    assert runner.invoke(cmd, ["--c", "RED"]).output == "<Color.red: 1>\n"
    assert runner.invoke(cmd, ["--c", "green"]).exit_code == 2


def test_choice_case_sensitive_default(runner):
    @command()
    @option("--c", type=Choice(["a", "b"]))
    def cmd(c):
        echo(c)

    assert runner.invoke(cmd, ["--c", "a"]).output == "a\n"
    assert runner.invoke(cmd, ["--c", "A"]).exit_code == 2


def test_intrange_clamp_open_bound():
    t = IntRange(min=0, max=10, min_open=True, clamp=True)
    assert t.convert("0") == 1
    assert t.convert("50") == 10


def test_floatrange_clamp_with_open_bound_refused():
    with pytest.raises(TypeError):
        FloatRange(min=0, min_open=True, clamp=True)


def test_datetime_default_and_custom_formats(runner):
    @command()
    @option("--d", type=optlyn.DateTime(["%d/%m/%Y"]))
    def cmd(d):
        echo(d.isoformat())

    assert runner.invoke(cmd, ["--d", "02/03/2020"]).output == "2020-03-02T00:00:00\n"
    assert runner.invoke(cmd, ["--d", "2020-03-02"]).exit_code == 2


# --- FP-06 groups ----------------------------------------------------------------

def test_nested_groups_run_outside_in(runner):
    trace = []

    @group()
    @option("--outer")
    def cli(outer):
        trace.append(("cli", outer))

    @cli.group()
    def inner():
        trace.append("inner")

    @inner.command()
    @option("--leaf")
    def leaf(leaf):
        trace.append(("leaf", leaf))

    res = runner.invoke(cli, ["--outer", "o", "inner", "leaf", "--leaf", "l"])
    assert res.exit_code == 0, res.output
    assert trace == [("cli", "o"), "inner", ("leaf", "l")]


def test_skipping_middle_name_is_unknown_command(runner):
    @group()
    def cli():
        pass

    @cli.group()
    def inner():
        pass

    @inner.command()
    def leaf():
        pass

    assert runner.invoke(cli, ["leaf"]).exit_code == 2


def test_group_options_after_subcommand_belong_to_sub(runner):
    @group()
    @option("--g")
    def cli(g):
        pass

    @cli.command()
    @option("--s")
    def sub(s):
        echo(str(s))

    assert runner.invoke(cli, ["--g", "1", "sub", "--s", "2"]).output == "2\n"


def test_group_callback_runs_before_child(runner):
    trace = []

    @group()
    def cli():
        trace.append("group")

    @cli.command()
    def sub():
        trace.append("sub")

    runner.invoke(cli, ["sub"])
    assert trace == ["group", "sub"]


def test_unknown_subcommand_skips_group_callback(runner):
    trace = []

    @group()
    def cli():
        trace.append("group")

    res = runner.invoke(cli, ["nope"])
    assert res.exit_code == 2 and trace == []


def test_invoke_without_command(runner):
    @group(invoke_without_command=True)
    @pass_context
    def cli(ctx):
        echo(f"sub={ctx.invoked_subcommand}")

    assert runner.invoke(cli, []).output == "sub=None\n"


def test_command_collection_union(runner):
    @group()
    def a():
        pass

    @a.command()
    def one():
        echo("one")

    @group()
    def b():
        pass

    @b.command()
    def two():
        echo("two")

    coll = optlyn.CommandCollection(sources=[a, b])
    assert runner.invoke(coll, ["one"]).output == "one\n"
    assert runner.invoke(coll, ["two"]).output == "two\n"


def test_custom_group_lazy_lookup(runner):
    class Lazy(optlyn.Group):
        def list_commands(self, ctx):
            return ["hello-there"]

        def get_command(self, ctx, name):
            if name == "hello-there":
                @command("hello-there")
                def hello():
                    echo("lazy-hi")

                return hello
            return None

    cli = Lazy(name="cli")
    res = runner.invoke(cli, ["hello-there"])
    assert res.output == "lazy-hi\n"


def test_add_group_under_chain_refused():
    @group(chain=True)
    def cli():
        pass

    with pytest.raises(TypeError):
        @group()
        def child():
            pass

        cli.add_command(child)


# --- FP-07 context, defaults, env ---------------------------------------------

def test_default_map_applies_and_loses_to_command_line(runner):
    @command()
    @option("--n", type=int, default=1)
    def cmd(n):
        echo(str(n))

    assert runner.invoke(cmd, [], default_map={"n": 5}).output == "5\n"
    assert runner.invoke(cmd, ["--n", "9"], default_map={"n": 5}).output == "9\n"


def test_default_map_nested_by_subcommand(runner):
    @group()
    def cli():
        pass

    @cli.command()
    @option("--n", type=int, default=1)
    def sub(n):
        echo(str(n))

    assert runner.invoke(cli, ["sub"], default_map={"sub": {"n": 7}}).output == "7\n"


def test_envvar_and_sources(runner):
    @command()
    @option("--n", envvar="OPTLYN_TEST_N", type=int, default=1)
    def cmd(n):
        ctx = optlyn.get_current_context()
        echo(f"{n} {ctx.get_parameter_source('n').name}")

    res = runner.invoke(cmd, [], env={"OPTLYN_TEST_N": "4"})
    assert res.output == "4 ENVIRONMENT\n"
    res = runner.invoke(cmd, ["--n", "2"], env={"OPTLYN_TEST_N": "4"})
    assert res.output == "2 COMMANDLINE\n"


def test_auto_envvar_prefix(runner):
    @group()
    @optlyn.option("--tok")
    def cli(tok):
        pass

    @cli.command()
    @option("--name")
    def sub(name):
        echo(str(name))

    res = runner.invoke(cli, ["sub"], auto_envvar_prefix="MYAPP", env={"MYAPP_SUB_NAME": "zed"})
    assert res.output == "zed\n"


def test_boolean_env_unrecognized_is_usage_error(runner):
    @command()
    @option("--flag", envvar="OPTLYN_TEST_FLAG", is_flag=True)
    def cmd(flag):
        echo(str(flag))

    assert runner.invoke(cmd, [], env={"OPTLYN_TEST_FLAG": "true"}).output == "True\n"
    assert runner.invoke(cmd, [], env={"OPTLYN_TEST_FLAG": "maybe"}).exit_code == 2


def test_pass_obj_and_ensure(runner):
    class Config:
        pass

    @group(context_settings={"obj": None})
    @pass_obj
    def cli(obj):
        pass

    @command()
    @make_pass_decorator(Config, ensure=True)
    def cmd(cfg):
        echo(type(cfg).__name__)

    assert runner.invoke(cmd, []).output == "Config\n"


def test_invoke_from_callback(runner):
    @command()
    @option("--x", default=3)
    def target(x):
        echo(f"target {x}")

    @command()
    @pass_context
    def driver(ctx):
        ctx.invoke(target, x=9)
        ctx.forward(target)

    assert runner.invoke(driver, []).output == "target 9\ntarget 3\n"


def test_with_resource_closed_at_end(runner):
    closed = []

    class CM:
        def __enter__(self):
            return "res"

        def __exit__(self, *exc):
            closed.append(True)

    @command()
    @pass_context
    def cmd(ctx):
        echo(ctx.with_resource(CM()))

    res = runner.invoke(cmd, [])
    assert res.output == "res\n" and closed == [True]


# --- FP-08 prompts --------------------------------------------------------------

def test_prompt_when_omitted_and_empty_uses_default(runner):
    @command()
    @option("--name", prompt=True, default="anon")
    def cmd(name):
        echo(f"hi {name}")

    res = runner.invoke(cmd, [], input="\n")
    assert res.exit_code == 0
    assert res.output.endswith("hi anon\n")


def test_prompt_value_supplied(runner):
    @command()
    @option("--name", prompt="Who")
    def cmd(name):
        echo(f"hi {name}")

    res = runner.invoke(cmd, [], input="bob\n")
    assert "Who" in res.output and res.output.endswith("hi bob\n")


def test_prompt_not_read_when_supplied(runner):
    @command()
    @option("--name", prompt=True)
    def cmd(name):
        echo(name)

    res = runner.invoke(cmd, ["--name", "x"], input="zzz\n")
    assert res.output == "x\n"


def test_prompt_eof_is_abort(runner):
    @command()
    @option("--name", prompt=True, prompt_required=True)
    def cmd(name):
        echo(name)

    res = runner.invoke(cmd, [], input="")
    assert res.exit_code == 1
    assert "Aborted!" in res.stderr


def test_password_confirm_mismatch_reasks(runner):
    @command()
    @password_option()
    def cmd(password):
        echo(password)

    res = runner.invoke(cmd, [], input="a\nb\na\na\n")
    assert res.exit_code == 0
    assert res.output.strip().splitlines()[-1] == "a"


def test_confirmation_option_declined_aborts(runner):
    @command()
    @confirmation_option()
    def cmd():
        echo("ran")

    res = runner.invoke(cmd, [], input="n\n")
    assert res.exit_code == 1 and "ran" not in res.stdout
    assert runner.invoke(cmd, ["--yes"]).output == "ran\n"


def test_confirmation_option_yes_runs(runner):
    @command()
    @confirmation_option("--force")
    def cmd():
        echo("ran")

    assert runner.invoke(cmd, [], input="y\n").output.endswith("ran\n")


# --- FP-09 files and paths -------------------------------------------------------

def test_file_read_and_dash_stdin(runner, tmp_path):
    @command()
    @argument("f", type=optlyn.File("r"))
    def cmd(f):
        echo(f.read().upper(), nl=False)

    with runner.isolated_filesystem():
        pathlib.Path("in.txt").write_text("hello\n")
        assert runner.invoke(cmd, ["in.txt"]).output == "HELLO\n"
        assert runner.invoke(cmd, ["-"], input="piped\n").output == "PIPED\n"
        assert runner.invoke(cmd, ["missing.txt"]).exit_code == 2


def test_file_write_lazy_not_truncated_when_unused(runner):
    @command()
    @option("--out", type=optlyn.File("w"))
    def cmd(out):
        echo("nothing written")

    with runner.isolated_filesystem():
        pathlib.Path("keep.txt").write_text("orig")
        res = runner.invoke(cmd, ["--out", "keep.txt"])
        assert res.exit_code == 0
        assert pathlib.Path("keep.txt").read_text() == "orig"


def test_path_checks(runner):
    @command()
    @argument("p", type=optlyn.Path(exists=True, dir_okay=False))
    def cmd(p):
        echo(p)

    with runner.isolated_filesystem():
        pathlib.Path("a.txt").write_text("x")
        assert runner.invoke(cmd, ["a.txt"]).output == "a.txt\n"
        assert runner.invoke(cmd, ["nope"]).exit_code == 2


def test_path_pathlib_type(runner):
    @command()
    @argument("p", type=optlyn.Path(path_type=pathlib.Path))
    def cmd(p):
        echo(type(p).__name__)

    assert runner.invoke(cmd, ["x"]).output == "PosixPath\n"


# --- FP-10 chaining -----------------------------------------------------------------

def test_chain_runs_in_order_and_results(runner):
    @group(chain=True)
    def cli():
        pass

    @cli.command()
    @argument("a")
    def one(a):
        echo(f"one {a}")
        return a

    @cli.command()
    @argument("b")
    def two(b):
        echo(f"two {b}")
        return b

    @cli.result_callback()
    def done(results):
        echo(repr(results))

    res = runner.invoke(cli, ["one", "x", "two", "y"])
    assert res.exit_code == 0, res.output
    assert res.stdout == "one x\ntwo y\n['x', 'y']\n"


def test_chain_with_standalone_off_returns_list(runner):
    @group(chain=True)
    def cli():
        pass

    @cli.command()
    def a():
        return 1

    @cli.command()
    def b():
        return 2

    rv = cli.main(["a", "b"], standalone_mode=False, prog_name="cli")
    assert rv == [1, 2]


# --- FP-11 terminal helpers ------------------------------------------------------------

def test_style_and_unstyle():
    s = style("hi", fg="red", bold=True)
    assert s.startswith("\x1b[") and unstyle(s) == "hi"
    assert style("x", fg=(1, 2, 3)).startswith("\x1b[38;2;1;2;3m")
    with pytest.raises(TypeError):
        style("x", fg="pink")
    with pytest.raises(TypeError):
        style("x", fg=300)


def test_echo_strips_styles_off_terminal(runner):
    @command()
    def cmd():
        secho("colored", fg="green")

    assert runner.invoke(cmd, []).output == "colored\n"
    assert "\x1b[" in runner.invoke(cmd, [], color=True).output


def test_echo_ascii_stream_writes_utf8(runner):
    @command()
    def cmd():
        echo("héllo ✓")

    res = runner.invoke(cmd, [])
    assert res.stdout == "héllo ✓\n"


def test_wrap_text_accepts_any_string():
    assert wrap_text("a " * 200, width=20).count("\n") > 1
    assert wrap_text("") == ""


def test_app_dir_xdg(monkeypatch, tmp_path):
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    import sys as _sys
    if _sys.platform.startswith(("linux", "freebsd")):
        assert get_app_dir("My App") == os.path.join(str(tmp_path), "my-app")


def test_format_filename_bytes_safe():
    assert format_filename(b"abc.txt") == "abc.txt"
    assert format_filename("x/y.txt", shorten=True) == "y.txt"


def test_pause_non_interactive_does_not_block(runner):
    from optlyn import pause

    @command()
    def cmd():
        pause("press")

    res = runner.invoke(cmd, [], input="")
    assert res.exit_code == 0 and "press" in res.output


# --- FP-12 completion ----------------------------------------------------------------

def test_completion_source_script(runner, monkeypatch):
    @group()
    def cli():
        pass

    @cli.command()
    def sub():
        pass

    monkeypatch.setenv("_DEMO_COMPLETE", "bash_source")
    res = runner.invoke(cli, [], prog_name="demo")
    assert res.exit_code == 0
    assert "complete" in res.stdout and "bash_complete" in res.stdout
    assert "sub" not in res.stdout.split("\n")[0]


def test_completion_suggests_subcommands_and_options(runner, monkeypatch):
    @group()
    def cli():
        pass

    @cli.command()
    @option("--alpha")
    def sub():
        pass

    @cli.command(hidden=True)
    def hidden_one():
        pass

    monkeypatch.setenv("_DEMO_COMPLETE", "bash_complete")
    monkeypatch.setenv("COMP_WORDS", "demo ")
    monkeypatch.setenv("COMP_CWORD", "1")
    res = runner.invoke(cli, [], prog_name="demo")
    assert res.stdout.split() == ["sub"]

    monkeypatch.setenv("COMP_WORDS", "demo sub --")
    monkeypatch.setenv("COMP_CWORD", "2")
    res = runner.invoke(cli, [], prog_name="demo")
    assert "--alpha" in res.stdout.split()


def test_completion_choice_values(runner, monkeypatch):
    @command()
    @option("--c", type=Choice(["one", "two"]))
    def cmd(c):
        pass

    monkeypatch.setenv("_DEMO_COMPLETE", "zsh_complete")
    monkeypatch.setenv("COMP_WORDS", "demo --c o")
    monkeypatch.setenv("COMP_CWORD", "2")
    res = runner.invoke(cmd, [], prog_name="demo")
    assert res.stdout.split() == ["one"]


def test_unknown_completion_instruction_runs_nothing(runner, monkeypatch):
    calls = []

    @command()
    def cmd():
        calls.append(1)

    monkeypatch.setenv("_DEMO_COMPLETE", "tcsh_source")
    res = runner.invoke(cmd, [], prog_name="demo")
    assert res.exit_code != 0 and calls == [] and res.stdout == ""


# --- FP-13 exit statuses -----------------------------------------------------------

def test_clean_stop_with_status(runner):
    @command()
    @pass_context
    def cmd(ctx):
        ctx.exit(7)
        echo("never")

    res = runner.invoke(cmd, [])
    assert res.exit_code == 7 and "never" not in res.stdout


def test_author_abort_status_one(runner):
    @command()
    @pass_context
    def cmd(ctx):
        ctx.abort()

    res = runner.invoke(cmd, [])
    assert res.exit_code == 1 and "Aborted!" in res.stderr


def test_non_standalone_raises(runner):
    @command()
    @option("--x", type=int)
    def cmd(x):
        pass

    with pytest.raises(optlyn.BadParameter):
        cmd.main(["--x", "bad"], standalone_mode=False, prog_name="cmd")


def test_non_standalone_returns_callback_value():
    @command()
    def cmd():
        return 42

    assert cmd.main([], standalone_mode=False, prog_name="cmd") == 42


# --- FP-14 runner -------------------------------------------------------------------

def test_runner_captures_exception_and_status(runner):
    @command()
    def cmd():
        raise ValueError("boom")

    res = runner.invoke(cmd, [])
    assert res.exit_code == 1
    assert isinstance(res.exception, ValueError)


def test_runner_no_catch_propagates():
    r = CliRunner(catch_exceptions=False)

    @command()
    def cmd():
        raise ValueError("boom")

    with pytest.raises(ValueError):
        r.invoke(cmd, [])


def test_runner_env_is_scoped(runner):
    @command()
    def cmd():
        echo(os.environ.get("OPTLYN_SCOPED", "unset"))

    assert runner.invoke(cmd, [], env={"OPTLYN_SCOPED": "yes"}).output == "yes\n"
    assert "OPTLYN_SCOPED" not in os.environ
    assert runner.invoke(cmd, []).output == "unset\n"


def test_isolated_filesystem_removed_without_parent(runner):
    with runner.isolated_filesystem() as path:
        assert os.path.isdir(path)
        cwd = os.getcwd()
    assert not os.path.exists(path)
    assert os.getcwd() != cwd


def test_isolated_filesystem_with_parent_kept(runner, tmp_path):
    with runner.isolated_filesystem(temp_dir=str(tmp_path)) as path:
        pass
    assert os.path.isdir(path)


# --- declaration-time refusals ---------------------------------------------------------

def test_deprecated_required_option_refused():
    with pytest.raises(TypeError):
        option("--x", deprecated=True, required=True)(lambda x: None)


def test_deprecated_argument_required_refused():
    with pytest.raises(TypeError):
        argument("x", deprecated=True)(lambda x: None)


def test_public_exports_present():
    for name in ["command", "group", "option", "argument", "Command", "Group", "CommandCollection",
                 "Context", "Option", "Parameter", "ParamType", "BadParameter", "Abort", "STRING",
                 "INT", "FLOAT", "BOOL", "UUID", "UNPROCESSED", "Choice", "DateTime", "IntRange",
                 "FloatRange", "Tuple", "File", "Path", "echo", "secho", "style", "unstyle",
                 "echo_via_pager", "get_pager_file", "progressbar", "prompt", "confirm", "getchar",
                 "pause", "edit", "launch", "clear", "get_app_dir", "get_current_context",
                 "format_filename", "open_file", "help_option", "version_option",
                 "custom_version_option", "password_option", "confirmation_option", "pass_context",
                 "pass_obj", "make_pass_decorator"]:
        assert hasattr(optlyn, name), name
    from optlyn.testing import CliRunner as R
    from optlyn.formatting import wrap_text as W
    assert R and W
