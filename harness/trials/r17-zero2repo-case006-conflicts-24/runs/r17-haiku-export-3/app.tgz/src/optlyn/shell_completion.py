"""Shell completion: registration scripts and suggestion output (FP-12, §8)."""

from __future__ import annotations

import os
import sys

from .core import Argument, Context, Group, Option
from .paramtypes import File, Path

__all__ = ["run_completion", "get_suggestions", "complete_variable_name"]

SHELLS = ("bash", "zsh", "fish", "powershell")
_PATH_FILE = "__optlyn_path_file__"
_PATH_DIR = "__optlyn_path_dir__"


def complete_variable_name(prog_name: str) -> str:
    return "_" + prog_name.upper().replace("-", "_") + "_COMPLETE"


# spec: N-000692
def run_completion(cmd, prog_name, argv, complete_var=None):
    """Handle completion mode. Returns None when not in completion mode, else an exit status."""
    var = complete_var or complete_variable_name(prog_name)
    instruction = os.environ.get(var)
    if not instruction:
        return None
    shell, _, mode = instruction.rpartition("_")
    if shell not in SHELLS or mode not in ("source", "complete"):
        return 1
    if mode == "source":
        sys.stdout.write(_source_script(shell, prog_name, var))
        sys.stdout.flush()
        return 0
    words = os.environ.get("COMP_WORDS", "").split(" ")
    if shell == "fish":
        incomplete = os.environ.get("COMP_CWORD", "")
        args = words[1:]
        if args and args[-1] == incomplete:
            args = args[:-1]
    else:
        try:
            cword = int(os.environ.get("COMP_CWORD", str(len(words))))
        except ValueError:
            cword = len(words)
        incomplete = words[cword] if 0 <= cword < len(words) else ""
        args = words[1:cword]
    rows = get_suggestions(cmd, prog_name, args, incomplete)
    lines = []
    for value, help_text in rows:
        if shell in ("zsh", "fish") and help_text:
            lines.append(f"{value}\t{help_text}")
        else:
            lines.append(value)
    sys.stdout.write("".join(line + "\n" for line in lines))
    sys.stdout.flush()
    return 0


def get_suggestions(cmd, prog_name, args, incomplete):
    """Return (value, help) pairs for ``incomplete`` after ``args``."""
    ctx = Context(cmd, info_name=prog_name)
    current = cmd
    pending = None
    positional_seen = 0
    for token in args:
        if pending is not None:
            pending = None
            continue
        if token.startswith("-") and len(token) > 1:
            name, _, attached = token.partition("=")
            option = _find_option(ctx, current, name)
            if option is not None and not option.is_flag and not attached:
                pending = option
            continue
        if isinstance(current, Group):
            key, sub = current._lookup(ctx, token)
            if sub is not None:
                current = sub
                ctx = Context(sub, parent=ctx, info_name=key)
                continue
        positional_seen += 1

    if pending is not None:
        return _value_suggestions(ctx, pending, incomplete)

    if incomplete.startswith("-"):
        rows = []
        for param in current.get_params(ctx):
            if isinstance(param, Option) and not param.hidden:
                for name in param.all_names():
                    if name.startswith(incomplete):
                        rows.append((name, param.help or ""))
        return rows

    rows = []
    if isinstance(current, Group):
        for name, sub in current._visible_commands(ctx):
            if name.startswith(incomplete):
                rows.append((name, sub.get_short_help_str()))
        return rows

    arguments = [p for p in current.get_params(ctx) if isinstance(p, Argument)]
    if positional_seen < len(arguments):
        return _value_suggestions(ctx, arguments[positional_seen], incomplete)
    return rows


def _find_option(ctx, command, name):
    for param in command.get_params(ctx):
        if isinstance(param, Option) and name in param.all_names():
            return param
    return None


def _value_suggestions(ctx, param, incomplete):
    """Suggestions for an option's or argument's value (completion function, type, or path)."""
    if isinstance(param.type, (File, Path)) and param.shell_complete is None:
        kind = _PATH_FILE
        if isinstance(param.type, Path) and not param.type.file_okay and param.type.dir_okay:
            kind = _PATH_DIR
        return [(f"{kind}\t{incomplete}", "")]
    if param.shell_complete is not None:
        items = param.shell_complete(ctx, param, incomplete)
    else:
        items = param.type.shell_complete(ctx, param, incomplete)
    rows = []
    for item in items:
        if isinstance(item, str):
            rows.append((item, ""))
        elif getattr(item, "type", "plain") == "plain":
            rows.append((str(item.value), getattr(item, "help", None) or ""))
        else:
            rows.append((str(item.value), ""))
    return rows


def _source_script(shell: str, prog_name: str, var: str) -> str:
    name = prog_name
    if shell == "bash":
        return (
            f"_{name.replace('-', '_')}_completion() {{\n"
            "    local IFS=$'\\n'\n"
            f"    COMPREPLY=( $( env COMP_WORDS=\"${{COMP_WORDS[*]}}\" COMP_CWORD=$COMP_CWORD "
            f"{var}=bash_complete {name} ) )\n"
            "    return 0\n"
            "}\n"
            f"complete -o default -F _{name.replace('-', '_')}_completion {name}\n"
        )
    if shell == "zsh":
        return (
            f"#compdef {name}\n"
            f"_{name.replace('-', '_')}_completion() {{\n"
            "    local -a response\n"
            "    response=(\"${(@f)$(env COMP_WORDS=\"${words[*]}\" COMP_CWORD=$((CURRENT-1)) "
            f"{var}=zsh_complete {name})" + "}\")\n"
            "    compadd -a response\n"
            "}\n"
            f"compdef _{name.replace('-', '_')}_completion {name}\n"
        )
    if shell == "fish":
        return (
            f"complete --no-files --command {name} --arguments "
            f"'(env COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -ct) "
            f"{var}=fish_complete {name})'\n"
        )
    return (
        f"Register-ArgumentCompleter -Native -CommandName '{name}' -ScriptBlock {{\n"
        "    param($wordToComplete, $commandAst, $cursorPosition)\n"
        f"    $env:COMP_WORDS = $commandAst.ToString()\n"
        f"    $env:COMP_CWORD = $wordToComplete\n"
        f"    $env:{var} = 'powershell_complete'\n"
        f"    & {name} | ForEach-Object {{ [System.Management.Automation.CompletionResult]::new($_, $_, 'ParameterValue', $_) }}\n"
        "}\n"
    )
