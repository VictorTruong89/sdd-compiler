"""Text wrapping and help-page layout helpers (FP-02, FP-11, §7)."""

from __future__ import annotations

import re
import textwrap

__all__ = ["wrap_text"]

DEFAULT_WRAP_WIDTH = 100
_SENTENCE_END = re.compile(r"(?<=[.!?])\s")


# spec: N-000764
def wrap_text(
    text,
    width: int = DEFAULT_WRAP_WIDTH,
    initial_indent: str = "",
    subsequent_indent: str = "",
    preserve_paragraphs: bool = False,
) -> str:
    """Wrap ``text`` to ``width`` columns. Accepts any string."""
    text = str(text)
    width = max(int(width), 1)
    if not preserve_paragraphs:
        return textwrap.fill(
            " ".join(text.split()),
            width=width,
            initial_indent=initial_indent,
            subsequent_indent=subsequent_indent,
        )
    blocks = []
    for paragraph in re.split(r"\n\s*\n", text):
        if not paragraph.strip():
            continue
        blocks.append(
            textwrap.fill(
                " ".join(paragraph.split()),
                width=width,
                initial_indent=initial_indent,
                subsequent_indent=subsequent_indent,
            )
        )
    return "\n\n".join(blocks)


def wrap_help_text(text: str, width: int, indent: str = "") -> list:
    """Rewrap help text paragraph by paragraph.

    A paragraph whose first line is only a backspace is kept as written (its
    line breaks survive); that backspace line is removed from the output.
    """
    lines: list = []
    paragraphs = re.split(r"\n\s*\n", text.strip("\n"))
    for index, paragraph in enumerate(paragraphs):
        if not paragraph.strip():
            continue
        if index and lines:
            lines.append("")
        raw_lines = paragraph.split("\n")
        if raw_lines[0].strip() == "\b":
            for raw in raw_lines[1:]:
                lines.append(indent + raw.rstrip())
            continue
        flat = " ".join(line.strip() for line in raw_lines if line.strip())
        lines.extend(
            textwrap.wrap(
                flat,
                width=max(width - len(indent), 10),
                initial_indent=indent,
                subsequent_indent=indent,
            )
        )
    return lines


def make_default_short_help(text: str, max_length: int = 45) -> str:
    """First sentence of the first paragraph, cut to ``max_length`` with ``...``."""
    if not text:
        return ""
    first_paragraph = re.split(r"\n\s*\n", text.strip())[0]
    flat = " ".join(first_paragraph.split())
    sentence = _SENTENCE_END.split(flat, maxsplit=1)[0]
    if len(sentence) > max_length:
        cut = sentence[: max(max_length - 3, 0)].rstrip()
        return cut + "..."
    return sentence


def definition_list(rows, width: int, indent: int = 2, max_first: int = 30, gap: int = 2) -> list:
    """Two-column layout: each row is (first, second). The first column is capped."""
    if not rows:
        return []
    first_width = min(max(len(first) for first, _ in rows), max_first)
    pad = " " * indent
    second_width = max(width - indent - first_width - gap, 20)
    out: list = []
    for first, second in rows:
        second_lines = textwrap.wrap(second, width=second_width) if second else []
        if len(first) > first_width or not second_lines:
            out.append(pad + first)
            out.extend(" " * (indent + first_width + gap) + line for line in second_lines)
            continue
        out.append(pad + first.ljust(first_width) + " " * gap + second_lines[0])
        out.extend(" " * (indent + first_width + gap) + line for line in second_lines[1:])
    return out
