"""Parameter types and value conversion (FP-05, FP-09, Interface Contract §5)."""

from __future__ import annotations

import datetime as _dt
import enum
import io
import os
import pathlib
import sys
import tempfile
import uuid as _uuid

from .exceptions import BadParameter, FileError


class ParamType:
    """Base class for parameter types.

    A subclass sets ``name`` and implements ``convert(value, param, ctx)``.
    ``convert`` must accept ``param=None, ctx=None`` and refuses by raising
    :class:`BadParameter`.
    """

    name = "text"
    is_composite = False
    envvar_list_splitter = None  # None: split on whitespace

    def convert(self, value, param=None, ctx=None):
        return value

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def get_metavar(self, param=None):
        return None

    def get_choices_text(self):
        return None

    def split_envvar(self, value: str):
        if self.envvar_list_splitter is None:
            return value.split()
        return [part for part in value.split(self.envvar_list_splitter) if part != ""]

    def shell_complete(self, ctx, param, incomplete):
        return []

    def __repr__(self) -> str:
        return f"<{type(self).__name__} {self.name}>"


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, str):
            return value
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        return str(value)


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, int) and not isinstance(value, bool):
            return value
        try:
            return int(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        try:
            return float(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParameterType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid UUID value.", param, ctx)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


# spec: N-000330
class Choice(ParamType):
    """A closed list of allowed values, or the member names of an enumeration."""

    name = "choice"

    def __init__(self, choices, case_sensitive: bool = True) -> None:
        self.case_sensitive = case_sensitive
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            pairs = [(member.name, member) for member in choices]
        else:
            pairs = [(str(choice), choice) for choice in choices]
        self._pairs = []
        seen = set()
        for token, original in pairs:
            key = token if case_sensitive else token.casefold()
            if key in seen:
                continue  # the first registered original wins
            seen.add(key)
            self._pairs.append((token, original))
        self.choices = [original for _, original in self._pairs]

    def get_metavar(self, param=None):
        return "[" + "|".join(token for token, _ in self._pairs) + "]"

    def get_choices_text(self):
        return ", ".join(token for token, _ in self._pairs)

    def convert(self, value, param=None, ctx=None):
        for _, original in self._pairs:
            if value is original:
                return original
        text = value if isinstance(value, str) else str(value)
        normalize = getattr(ctx, "token_normalize_func", None) or (lambda s: s)
        for token, original in self._pairs:
            if self.case_sensitive:
                if text == token or normalize(text) == normalize(token):
                    return original
            elif text.casefold() == token.casefold() or normalize(text) == normalize(token):
                return original
        self.fail(f"{value!r} is not one of {self.get_choices_text()}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        return [token for token, _ in self._pairs if token.startswith(incomplete)]


DEFAULT_DATETIME_FORMATS = (
    "%Y-%m-%d",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M:%S",
)


# spec: N-000353
class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None) -> None:
        self.formats = list(formats) if formats is not None else list(DEFAULT_DATETIME_FORMATS)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        text = str(value).strip()
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(text, fmt)
            except ValueError:
                continue
        self.fail(
            f"{value!r} does not match the formats {', '.join(repr(f) for f in self.formats)}.",
            param,
            ctx,
        )


class IntRange(IntParamType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False) -> None:
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp
        if min is not None and max is not None and min > max:
            raise TypeError("IntRange min must not be greater than max.")

    def _range_text(self):
        lo = "" if self.min is None else f"{'>' if self.min_open else '>='}{self.min}"
        hi = "" if self.max is None else f"{'<' if self.max_open else '<='}{self.max}"
        return " and ".join(part for part in (lo, hi) if part) or "any integer"

    def convert(self, value, param=None, ctx=None):
        number = super().convert(value, param, ctx)
        if self.min is not None:
            if number < self.min or (self.min_open and number == self.min):
                if self.clamp:
                    return self.min + 1 if self.min_open else self.min
                self.fail(f"{number} is not in the range {self._range_text()}.", param, ctx)
        if self.max is not None:
            if number > self.max or (self.max_open and number == self.max):
                if self.clamp:
                    return self.max - 1 if self.max_open else self.max
                self.fail(f"{number} is not in the range {self._range_text()}.", param, ctx)
        return number


class FloatRange(FloatParamType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False) -> None:
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp
        if clamp and (min_open or max_open):
            raise TypeError("FloatRange clamp is only allowed when both bounds are closed.")
        if min is not None and max is not None and min > max:
            raise TypeError("FloatRange min must not be greater than max.")

    def _range_text(self):
        lo = "" if self.min is None else f"{'>' if self.min_open else '>='}{self.min}"
        hi = "" if self.max is None else f"{'<' if self.max_open else '<='}{self.max}"
        return " and ".join(part for part in (lo, hi) if part) or "any number"

    def convert(self, value, param=None, ctx=None):
        number = super().convert(value, param, ctx)
        if self.clamp:
            if self.min is not None and number < self.min:
                return float(self.min)
            if self.max is not None and number > self.max:
                return float(self.max)
            return number
        if self.min is not None and (number < self.min or (self.min_open and number == self.min)):
            self.fail(f"{number} is not in the range {self._range_text()}.", param, ctx)
        if self.max is not None and (number > self.max or (self.max_open and number == self.max)):
            self.fail(f"{number} is not in the range {self._range_text()}.", param, ctx)
        return number


class Tuple(ParamType):
    """A fixed-length product of inner types, one converted value per position."""

    name = "tuple"
    is_composite = True

    def __init__(self, types) -> None:
        self.types = [convert_type(t) for t in types]

    @property
    def arity(self) -> int:
        return len(self.types)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, (list, tuple)) and len(value) == len(self.types):
            return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))
        self.fail(f"{value!r} must be a sequence of {len(self.types)} values.", param, ctx)

    def get_metavar(self, param=None):
        return " ".join((t.get_metavar(param) or t.name.upper()) for t in self.types)


class _FuncType(ParamType):
    """Adapter for a conversion function ``f(token) -> value`` that raises ValueError to refuse."""

    def __init__(self, func) -> None:
        self.func = func
        self.name = getattr(func, "__name__", "text").lower()

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except ValueError as e:
            self.fail(str(e) or f"{value!r} is not valid.", param, ctx)


class _StdNonClosing:
    """Wrapper for a standard stream: closing it only flushes the stream."""

    def __init__(self, stream) -> None:
        self._stream = stream

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __iter__(self):
        return iter(self._stream)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def close(self) -> None:
        try:
            self._stream.flush()
        except (OSError, ValueError):
            pass


class _DeferredFile:
    """A file that opens on first I/O (lazy write) and may write atomically."""

    def __init__(self, filename, mode, encoding=None, errors="strict", atomic=False, lazy=False):
        self._filename = filename
        self._mode = mode
        self._encoding = encoding
        self._errors = errors
        self._atomic = atomic
        self._file = None
        self._tmp = None
        self._closed = False
        if not lazy:
            self._ensure()

    @property
    def name(self):
        return self._filename

    @property
    def mode(self):
        return self._mode

    def _ensure(self):
        if self._file is None:
            self._file, self._tmp = _open_real(
                self._filename, self._mode, self._encoding, self._errors, self._atomic
            )
        return self._file

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        return getattr(self._ensure(), name)

    def __iter__(self):
        return iter(self._ensure())

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        if self._file is not None:
            self._file.close()
            if self._tmp is not None:
                os.replace(self._tmp, self._filename)


def _open_real(filename, mode, encoding, errors, atomic):
    """Open a real file; returns (file, temp_path_or_None)."""
    writing = any(c in mode for c in "wa+")
    binary = "b" in mode
    try:
        if writing and atomic:
            directory = os.path.dirname(os.path.abspath(filename))
            fd, tmp = tempfile.mkstemp(dir=directory, prefix=".optlyn-", suffix=".tmp")
            handle = os.fdopen(
                fd, mode, **({} if binary else {"encoding": encoding, "errors": errors})
            )
            return handle, tmp
        handle = open(
            filename,
            mode,
            **({} if binary else {"encoding": encoding, "errors": errors}),
        )
        return handle, None
    except OSError as e:
        raise FileError(filename, e.strerror or str(e)) from e


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file, or a standard stream for ``-`` (FP-09, FP-11).

    Reads open immediately. Writes open on first I/O when ``lazy`` is true.
    Standard streams are never closed by the returned object.
    """
    filename = os.fspath(filename)
    if mode not in ("r", "w", "rb", "wb"):
        raise ValueError(f"Invalid file mode {mode!r}.")
    if filename == "-":
        binary = "b" in mode
        if mode.startswith("r"):
            stream = sys.stdin.buffer if binary else sys.stdin
        else:
            stream = sys.stdout.buffer if binary else sys.stdout
        if not binary and encoding is not None:
            stream = io.TextIOWrapper(
                stream.buffer if hasattr(stream, "buffer") else stream,
                encoding=encoding,
                errors=errors,
                write_through=True,
            )
        return _StdNonClosing(stream)
    if mode.startswith("r"):
        handle, _ = _open_real(filename, mode, encoding, errors, False)
        return handle
    return _DeferredFile(
        filename, mode, encoding=encoding, errors=errors, atomic=atomic, lazy=lazy
    )


# spec: N-000532
class File(ParamType):
    """Opens a file; the value is an open file object (FP-09)."""

    name = "filename"
    envvar_list_splitter = os.pathsep

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False) -> None:
        if mode not in ("r", "w", "rb", "wb"):
            raise TypeError(f"File mode must be one of r, w, rb, wb (got {mode!r}).")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def get_metavar(self, param=None):
        return "FILENAME"

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        lazy = self.lazy if self.lazy is not None else self.mode.startswith("w")
        filename = os.fspath(value)
        try:
            handle = open_file(
                filename,
                self.mode,
                encoding=self.encoding,
                errors=self.errors,
                lazy=lazy,
                atomic=self.atomic,
            )
        except FileError as e:
            self.fail(f"'{filename}': {e.message}", param, ctx)
        except OSError as e:
            self.fail(f"'{filename}': {e.strerror or e}", param, ctx)
        if ctx is not None and hasattr(handle, "close"):
            ctx.call_on_close(handle.close)
        return handle


# spec: N-000548
class Path(ParamType):
    """Validates a filesystem path and returns it (FP-09)."""

    name = "path"
    envvar_list_splitter = os.pathsep

    def __init__(
        self,
        exists=False,
        file_okay=True,
        dir_okay=True,
        writable=False,
        readable=True,
        resolve_path=False,
        allow_dash=False,
        path_type=None,
        executable=False,
    ) -> None:
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def get_metavar(self, param=None):
        return "PATH"

    def convert(self, value, param=None, ctx=None):
        rv = os.fspath(value)
        is_dash = self.allow_dash and rv == "-"
        if not is_dash:
            if self.resolve_path:
                rv = os.path.realpath(os.path.abspath(rv))
            exists = os.path.exists(rv)
            if not exists:
                if self.exists:
                    self.fail(f"{value!r} does not exist.", param, ctx)
            else:
                if not self.file_okay and os.path.isfile(rv):
                    self.fail(f"{value!r} is a file.", param, ctx)
                if not self.dir_okay and os.path.isdir(rv):
                    self.fail(f"{value!r} is a directory.", param, ctx)
                if self.readable and not os.access(rv, os.R_OK):
                    self.fail(f"{value!r} is not readable.", param, ctx)
                if self.writable and not os.access(rv, os.W_OK):
                    self.fail(f"{value!r} is not writable.", param, ctx)
                if self.executable and not os.access(rv, os.X_OK):
                    self.fail(f"{value!r} is not executable.", param, ctx)
        if self.path_type is pathlib.Path:
            return pathlib.Path(rv)
        return rv


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParameterType()
UNPROCESSED = UnprocessedParamType()

_PY_TYPE_MAP = {
    str: STRING,
    int: INT,
    float: FLOAT,
    bool: BOOL,
    _uuid.UUID: UUID,
}


def convert_type(ty, default=None) -> ParamType:
    """Turn an author type (instance, class, function, or None) into a ParamType."""
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    if isinstance(ty, (tuple, list)):
        return Tuple(ty)
    if ty is None:
        if default is not None and not callable(default):
            if isinstance(default, (list, tuple)) and default:
                return convert_type(None, default[0])
            if isinstance(default, (list, tuple)):
                return STRING
            if isinstance(default, bool):
                return BOOL
            if type(default) in _PY_TYPE_MAP:
                return _PY_TYPE_MAP[type(default)]
        return STRING
    if ty in _PY_TYPE_MAP:
        return _PY_TYPE_MAP[ty]
    if callable(ty):
        return _FuncType(ty)
    raise TypeError(f"Unsupported parameter type: {ty!r}")
