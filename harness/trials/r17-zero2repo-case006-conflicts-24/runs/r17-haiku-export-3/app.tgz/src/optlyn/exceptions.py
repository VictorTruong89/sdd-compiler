"""Exception classes and their exit statuses (FP-13)."""

from __future__ import annotations

from ._utils import echo_err


class OptlynError(Exception):
    """Base class for Optlyn-signalled errors.

    In standalone mode the process exits with ``exit_code`` after
    ``show()`` writes the message to standard error.
    """

    exit_code = 1

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message = message

    def format_message(self) -> str:
        return self.message

    def show(self, file=None) -> None:
        echo_err(f"Error: {self.format_message()}")


# spec: N-000719
class UsageError(OptlynError):
    """Incorrect command line usage. Exit status 2."""

    exit_code = 2

    def __init__(self, message: str, ctx=None) -> None:
        super().__init__(message)
        self.ctx = ctx

    def show(self, file=None) -> None:
        ctx = self.ctx
        if ctx is not None:
            usage = ctx.get_usage()
            echo_err(usage)
            hint = ctx.help_hint()
            if hint:
                echo_err(f"Try '{ctx.command_path} {hint}' for help.")
            echo_err("")
        echo_err(f"Error: {self.format_message()}")


class BadParameter(UsageError):
    """A value was refused by a type or a parameter callback."""

    def __init__(self, message: str, ctx=None, param=None, param_hint=None) -> None:
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self) -> str:
        if self.param_hint:
            return f"Invalid value for {self.param_hint}: {self.message}"
        if self.param is not None:
            return f"Invalid value for {self.param.describe()}: {self.message}"
        return f"Invalid value: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter received no value from any source."""

    def format_message(self) -> str:
        if self.param is not None:
            return f"Missing {self.param.kind_word()} {self.param.describe()}."
        return self.message


class NoSuchOption(UsageError):
    """An option token that the command does not declare."""

    def __init__(self, option_name: str, ctx=None, message=None) -> None:
        super().__init__(message or f"No such option: {option_name}", ctx)
        self.option_name = option_name


class BadOptionUsage(UsageError):
    """A usage error about an option whose report names that option."""


class BadArgumentUsage(UsageError):
    """A usage error about an argument whose report names that argument."""


class NoArgsIsHelpError(UsageError):
    """No arguments were given and the command shows help instead.

    The help page has already been printed; only the usage exit status is
    reported, so no message is written.
    """

    def show(self, file=None) -> None:
        return None


class FileError(OptlynError):
    """A file could not be opened at first I/O (general error, exit 1)."""

    def __init__(self, filename: str, hint: str) -> None:
        super().__init__(f"Could not open file {filename!r}: {hint}")
        self.ui_filename = filename


class Abort(RuntimeError):
    """Abort the program. Exit status 1 in standalone mode."""


class Exit(RuntimeError):
    """An author clean stop with the given status."""

    def __init__(self, code: int = 0) -> None:
        super().__init__(code)
        self.exit_code = code
