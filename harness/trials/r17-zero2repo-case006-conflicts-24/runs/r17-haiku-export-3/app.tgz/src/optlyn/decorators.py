"""Declaration decorators: command, group, option, argument and the ready-made options (§3–§4, §6)."""

from __future__ import annotations

import functools
import importlib.metadata
import inspect
import sys

from .core import Argument, Command, Group, Option, _help_callback
from .termui import echo, get_current_context

__all__ = [
    "command",
    "group",
    "option",
    "argument",
    "help_option",
    "version_option",
    "custom_version_option",
    "password_option",
    "confirmation_option",
    "pass_context",
    "pass_obj",
    "make_pass_decorator",
]

_SUFFIXES = ("_command", "_cmd", "_group", "_grp")


def _default_name(f) -> str:
    name = f.__name__.lower()
    for suffix in _SUFFIXES:
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def _attach(f, param) -> None:
    if not hasattr(f, "__optlyn_params__"):
        f.__optlyn_params__ = []
    f.__optlyn_params__.append(param)


def _take_params(f) -> list:
    """Move declarations off the function and return them in declaration order."""
    params = list(reversed(getattr(f, "__optlyn_params__", [])))
    if hasattr(f, "__optlyn_params__"):
        del f.__optlyn_params__
    return params


def _doc(f):
    doc = inspect.getdoc(f)
    return doc


# spec: N-000079
def command(name=None, cls=None, **attrs):
    """Turn a function into a :class:`Command` (FP-01)."""
    if callable(name) and not isinstance(name, str):
        return command()(name)
    cls = cls or Command

    def decorator(f):
        cmd_name = name if name is not None else _default_name(f)
        params = _take_params(f)
        opts = dict(attrs)
        if opts.get("help") is None:
            opts["help"] = _doc(f)
        return cls(name=cmd_name, callback=f, params=params, **opts)

    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a :class:`Group` (FP-06)."""
    if callable(name) and not isinstance(name, str):
        return group()(name)
    cls = cls or Group

    def decorator(f):
        cmd_name = name if name is not None else _default_name(f)
        params = _take_params(f)
        opts = dict(attrs)
        if opts.get("help") is None:
            opts["help"] = _doc(f)
        return cls(name=cmd_name, callback=f, params=params, **opts)

    return decorator


def option(*param_decls, cls=None, **attrs):
    """Attach an option to a command or group (FP-03)."""
    cls = cls or Option

    def decorator(f):
        _attach(f, cls(param_decls, **attrs))
        return f

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach a positional argument to a command or group (FP-04)."""
    cls = cls or Argument

    def decorator(f):
        _attach(f, cls(param_decls, **attrs))
        return f

    return decorator


def help_option(*param_decls, **kwargs):
    """An extra eager help flag that prints help and exits (FP-02)."""
    decls = param_decls or ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("callback", _help_callback)
    kwargs.setdefault("help", "Show this message and exit.")
    return option(*decls, **kwargs)


def _detect_version(package_name: str) -> str:
    try:
        return importlib.metadata.version(package_name)
    except importlib.metadata.PackageNotFoundError:
        pass
    providers = importlib.metadata.packages_distributions().get(package_name, [])
    if providers:
        return importlib.metadata.version(providers[0])
    raise RuntimeError(f"Could not determine the version for {package_name!r}.")


# spec: N-000162
def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    """An eager flag that prints the version identity and exits (FP-02)."""
    decls = param_decls or ("--version",)
    if version is None and package_name is None:
        caller = sys._getframe(1).f_globals.get("__name__", "")
        package_name = caller.partition(".")[0] or None
    template = message or "%(prog)s, version %(version)s"

    def callback(ctx, param, value):
        if not value:
            return
        ident = version if version is not None else _detect_version(package_name)
        text = template % {
            "prog": prog_name or ctx.root_info_name,
            "package": package_name,
            "version": ident,
        }
        echo(text, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*decls, **kwargs)


def custom_version_option(callback, *param_decls, **kwargs):
    """An eager flag whose identity is exactly what ``callback(ctx)`` returns (FP-02)."""
    decls = param_decls or ("--version",)

    def handler(ctx, param, value):
        if not value:
            return
        echo(callback(ctx), color=True)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = handler
    return option(*decls, **kwargs)


# spec: N-000484
def password_option(*param_decls, **kwargs):
    """A prompting, hidden, confirmed option (FP-08)."""
    decls = param_decls or ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    return option(*decls, **kwargs)


def _confirm_callback(ctx, param, value):
    if not value:
        ctx.abort()
    return value


def confirmation_option(*param_decls, **kwargs):
    """A yes-flag that asks when omitted and aborts when declined (FP-08)."""
    decls = param_decls or ("--yes",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("callback", _confirm_callback)
    kwargs.setdefault("help", "Confirm the action without prompting.")
    return option(*decls, **kwargs)


def pass_context(f):
    """Pass the current :class:`Context` as the first argument (FP-07)."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(f):
    """Pass the current context's ``obj`` as the first argument (FP-07)."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type, ensure=False):
    """Pass the nearest object of ``object_type`` (created when ``ensure``) (FP-07)."""

    def decorator(f):
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(
                    f"Managed to invoke callback without a context object of type "
                    f"{object_type.__name__!r} existing."
                )
            return f(obj, *args, **kwargs)

        return new_func

    return decorator
