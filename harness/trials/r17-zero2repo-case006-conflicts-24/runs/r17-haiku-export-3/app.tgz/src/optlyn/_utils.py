"""Small helpers shared by the package: streams, ANSI sequences, thread state."""

from __future__ import annotations

import re
import sys
import threading

_ANSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")

_local = threading.local()


def strip_ansi(text: str) -> str:
    return _ANSI_RE.sub("", text)


def stream_isatty(stream) -> bool:
    try:
        return bool(stream is not None and stream.isatty())
    except (AttributeError, ValueError):
        return False


def stdout_is_tty() -> bool:
    return stream_isatty(sys.stdout)


def stdin_is_tty() -> bool:
    return stream_isatty(sys.stdin)


def is_interactive() -> bool:
    """A session is interactive when stdin is a terminal or stdout is one."""
    return stdin_is_tty() or stdout_is_tty()


def echo_err(text: str) -> None:
    """Write one line to standard error (used for reports)."""
    from .termui import echo

    echo(text, err=True)


def context_stack() -> list:
    stack = getattr(_local, "stack", None)
    if stack is None:
        stack = _local.stack = []
    return stack


def current_context_or_none():
    stack = context_stack()
    return stack[-1] if stack else None
