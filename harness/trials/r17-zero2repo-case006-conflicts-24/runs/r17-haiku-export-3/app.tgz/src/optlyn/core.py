"""Core model: parameters, the parser, invocation contexts, commands and groups.

Behaviour follows the Full PRD (FP-01 … FP-13); public shapes follow the
Interface Contract. Where the two disagree the choice is recorded in NOTES.md.
"""

from __future__ import annotations

import enum
import os
import re
import shutil
import sys

from . import formatting as _fmt
from ._utils import context_stack
from .exceptions import (
    Abort,
    BadOptionUsage,
    BadParameter,
    Exit,
    MissingParameter,
    NoArgsIsHelpError,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .paramtypes import BOOL, Tuple as TupleType, convert_type
from .termui import confirm, echo, prompt

__all__ = [
    "Context",
    "Command",
    "Group",
    "CommandCollection",
    "Parameter",
    "Option",
    "Argument",
    "ParameterSource",
]

_PREFIX_CHARS = ("-", "+", "/")
_TRUE_TOKENS = {"1", "true", "t", "yes", "y", "on"}
_FALSE_TOKENS = {"0", "false", "f", "no", "n", "off"}
_NEG_NUMBER = re.compile(r"^-\d")
_FLAG_ALONE = object()  # an option given with no value (prompting options)
_UNSET = object()  # an environment value that does not supply anything


class ParameterSource(enum.Enum):
    """Where a parameter's value came from (FP-07)."""

    PROMPT = "prompt"
    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"


def _is_flag_name(name: str) -> bool:
    return bool(name) and name[0] in _PREFIX_CHARS


# ---------------------------------------------------------------------------
# Parameters
# ---------------------------------------------------------------------------


class Parameter:
    """Common base of options and arguments."""

    kind = "parameter"

    def __init__(self, param_decls=(), type=None, required=False, default=None, callback=None,
                 nargs=1, multiple=False, metavar=None, expose_value=True, is_eager=False,
                 envvar=None, shell_complete=None, deprecated=False, hidden=False, help=None,
                 show_default=None, show_envvar=False, allow_from_autoenv=True, **_ignored):
        self.param_decls = tuple(param_decls)
        self.type = convert_type(type, default)
        self.nargs = len(self.type.types) if isinstance(self.type, TupleType) else nargs
        self.callback = callback
        self.expose_value = expose_value
        self.is_eager = is_eager
        self.deprecated = deprecated
        self.hidden = hidden
        self.help = help
        self.metavar = metavar
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.allow_from_autoenv = allow_from_autoenv
        self.shell_complete = shell_complete
        self.multiple = bool(multiple)
        self.required = bool(required)
        self.default = default
        if isinstance(envvar, str):
            envvar = [envvar]
        self.envvar = list(envvar) if envvar else []
        self.opts = []
        self.secondary_opts = []
        self.name = None

    # --- shared helpers -------------------------------------------------

    @property
    def is_tuple_type(self) -> bool:
        return isinstance(self.type, TupleType)

    @property
    def deprecated_note(self):
        return self.deprecated if isinstance(self.deprecated, str) else None

    def describe(self) -> str:
        raise NotImplementedError

    def kind_word(self) -> str:
        return self.kind

    def _conv(self, value, ctx):
        return self.type.convert(value, self, ctx)

    def _occurrence(self, ctx, item):
        """Convert one occurrence (a scalar for unary, a sequence for multi-value)."""
        if self.nargs == 1 and not self.is_tuple_type:
            return self._conv(item, ctx)
        seq = list(item) if isinstance(item, (list, tuple)) else None
        if seq is None or len(seq) != self.nargs:
            raise BadParameter(
                f"takes {self.nargs} values.", ctx=ctx, param=self
            )
        if self.is_tuple_type:
            return tuple(t.convert(v, self, ctx) for t, v in zip(self.type.types, seq))
        return tuple(self._conv(v, ctx) for v in seq)

    def _from_items(self, ctx, items):
        """Build the delivered value from already-split items."""
        if self.multiple:
            if not isinstance(items, (list, tuple)):
                raise BadOptionUsage(
                    f"Invalid default for {self.describe()}: it needs an iterable (sequence) default.",
                    ctx,
                )
            return tuple(self._occurrence(ctx, item) for item in items)
        return self._occurrence(ctx, items)

    def _split_text(self, text: str):
        return self.type.split_envvar(text)

    def _chunk(self, tokens):
        n = self.nargs
        return [list(tokens[i:i + n]) for i in range(0, len(tokens), n)]

    def _coerce_text(self, ctx, text: str, from_env: bool):
        """A string from the environment or a default map."""
        if not (self.multiple or self.nargs != 1 or self.is_tuple_type):
            return self._conv(text, ctx)
        if self.multiple and self.nargs == 1 and not self.is_tuple_type and not from_env:
            raise BadOptionUsage(
                f"Invalid default for {self.describe()}: it needs an iterable (sequence) default.",
                ctx,
            )
        tokens = self._split_text(text)
        if self.multiple:
            items = tokens if self.nargs == 1 and not self.is_tuple_type else self._chunk(tokens)
        else:
            items = tokens
        return self._from_items(ctx, items)

    def _default_value(self, ctx):
        value = self.default
        if callable(value):
            value = value()
        if value is None:
            return None
        if isinstance(value, str):
            return self._coerce_text(ctx, value, from_env=False)
        return self._from_items(ctx, value)

    def invoke_default(self, ctx):
        """The value a callback gets for this parameter when the caller supplies none."""
        if self.default is None:
            return () if self.multiple or (isinstance(self, Argument) and self.is_variadic) else None
        return self._default_value(ctx)

    def _env_names(self, ctx):
        names = list(self.envvar)
        if self.allow_from_autoenv and ctx.auto_envvar_prefix:
            names.append(ctx.auto_envvar_name(self))
        return names

    def _env_raw(self, ctx):
        for name in self._env_names(ctx):
            raw = os.environ.get(name)
            if raw:
                return raw
        return None

    def _default_map_value(self, ctx):
        mapping = ctx.default_map or {}
        if self.name in mapping:
            return True, mapping[self.name]
        return False, None

    def _map_value(self, ctx, raw):
        if isinstance(raw, str):
            return self._coerce_text(ctx, raw, from_env=False)
        return self._from_items(ctx, raw)

    def _missing(self, ctx):
        raise MissingParameter(
            f"Missing {self.kind_word()} {self.describe()}.", ctx=ctx, param=self
        )


class Option(Parameter):
    """A named parameter introduced by a prefix character."""

    kind = "option"

    def __init__(self, param_decls=(), is_flag=None, flag_value=None, count=False, prompt=None,
                 prompt_required=True, hide_input=False, confirmation_prompt=False,
                 allow_from_autoenv=True, **attrs):
        decls = list(param_decls)
        if not decls:
            raise TypeError("An option needs at least one name.")
        flag_names = [d for d in decls if _is_flag_name(d)]
        dests = [d for d in decls if not _is_flag_name(d)]
        if len(dests) > 1:
            raise TypeError("An option declares at most one destination name.")
        super().__init__(param_decls=decls, allow_from_autoenv=allow_from_autoenv, **attrs)
        for decl in flag_names:
            on, off = self._split_pair(decl)
            self.opts.append(on)
            if off is not None:
                self.secondary_opts.append(off)
        if not self.opts:
            raise TypeError("An option needs a flag name such as '--name'.")
        self.name = dests[0] if dests else self._infer_name()
        self.count = bool(count)
        self.prompt = prompt
        self.prompt_required = bool(prompt_required)
        self.hide_input = bool(hide_input)
        self.confirmation_prompt = bool(confirmation_prompt)

        if self.count and is_flag is False:
            raise TypeError("A counting option cannot be declared with is_flag=False.")
        if is_flag is None:
            is_flag = bool(
                self.secondary_opts
                or self.count
                or flag_value is not None
                or isinstance(self.default, bool)
            )
        if self.count:
            is_flag = True
        self.is_flag = bool(is_flag)
        self.is_optional_value = (not self.is_flag) and flag_value is not None
        if self.is_flag and flag_value is None:
            flag_value = True
        self.flag_value = flag_value
        if self.is_flag and attrs.get("type") is None:
            self.type = BOOL
        if self.count:
            self.type = convert_type(attrs.get("type"), self.default) if attrs.get("type") is not None else convert_type(int)
        if self.nargs < 1:
            raise TypeError("nargs must be a positive integer for an option.")
        if self.deprecated and self.required:
            raise TypeError("A deprecated option cannot also be required.")
        if self.deprecated and self.prompt:
            raise TypeError("A deprecated option cannot use a prompt.")

    # --- declaration helpers ---------------------------------------------

    @staticmethod
    def _split_pair(decl: str):
        idx = decl.find("/", 1)
        if idx < 0:
            return decl, None
        on = decl[:idx]
        off = decl[idx + 1:]
        if not _is_flag_name(off):
            off = ("--" if on.startswith("--") else on[0]) + off
        return on, off

    def _infer_name(self) -> str:
        def clean(name):
            return name.lstrip("-+/").replace("-", "_")

        longs = [n for n in self.opts if len(n) > 2 and n[1] in _PREFIX_CHARS]
        for name in longs + self.opts:
            if clean(name).isidentifier():
                return clean(name)
        return clean(longs[0] if longs else self.opts[0])

    def describe(self) -> str:
        return "'" + " / ".join(self.opts) + "'"

    def all_names(self):
        return self.opts + self.secondary_opts

    def get_metavar(self) -> str | None:
        if self.is_flag:
            return None
        if self.metavar is not None:
            return self.metavar
        if self.count:
            return None
        if self.is_tuple_type:
            return self.type.get_metavar(self)
        return self.type.get_metavar(self) or self.type.name.upper()

    # --- value sources ---------------------------------------------------

    def _flag_from_env(self, ctx, raw: str):
        """Interpret an environment string for a flag; returns payload or _UNSET."""
        text = raw.strip()
        if self.flag_value is not True and text == str(self.flag_value):
            return self.flag_value
        lowered = text.lower()
        if lowered in _TRUE_TOKENS:
            return True if self.flag_value is True else self.flag_value
        if lowered in _FALSE_TOKENS or text == "":
            return False
        if not isinstance(self.flag_value, bool):
            return _UNSET
        raise BadParameter(f"{raw!r} is not a valid boolean.", ctx=ctx, param=self)

    def _prompt_text(self) -> str:
        if isinstance(self.prompt, str):
            return self.prompt
        return self.name.replace("_", " ").capitalize()

    def _prompt_once(self, ctx, default):
        return prompt(
            self._prompt_text(),
            default=default,
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            type=self.type,
        )

    def resolve(self, ctx, hits):
        """Return (value, source) for this option from all sources (FP-03, FP-07, FP-08)."""
        if self.count:
            if hits:
                return len(hits), ParameterSource.COMMANDLINE
            if self.default is not None:
                return self._default_value(ctx), ParameterSource.DEFAULT
            return 0, None
        if self.is_flag:
            return self._resolve_flag(ctx, hits)
        return self._resolve_value(ctx, hits)

    def _resolve_flag(self, ctx, hits):
        if hits:
            return hits[-1][1], ParameterSource.COMMANDLINE
        raw = self._env_raw(ctx)
        if raw is not None:
            payload = self._flag_from_env(ctx, raw)
            if payload is not _UNSET:
                return payload, ParameterSource.ENVIRONMENT
        found, mapped = self._default_map_value(ctx)
        if found:
            if isinstance(mapped, str):
                return self._coerce_text(ctx, mapped, from_env=False), ParameterSource.DEFAULT_MAP
            return bool(mapped), ParameterSource.DEFAULT_MAP
        if self.prompt and self.prompt_required:
            question = self._prompt_text() if isinstance(self.prompt, str) else "Do you want to continue?"
            return confirm(question, default=False), ParameterSource.PROMPT
        if self.default is not None:
            return (self.default() if callable(self.default) else self.default), ParameterSource.DEFAULT
        return False, ParameterSource.DEFAULT

    def _resolve_value(self, ctx, hits):
        if hits:
            if self.multiple:
                items = []
                prompted = False
                for _, payload, _ in hits:
                    if payload is _FLAG_ALONE:
                        items.append(self._prompt_once(ctx, None))
                        prompted = True
                    else:
                        items.append(self._payload_item(payload))
                source = ParameterSource.PROMPT if prompted else ParameterSource.COMMANDLINE
                return self._from_items(ctx, items), source
            payload = hits[-1][1]
            if payload is _FLAG_ALONE:
                return self._prompt_one(ctx), ParameterSource.PROMPT
            return self._occurrence(ctx, self._payload_item(payload)), ParameterSource.COMMANDLINE
        raw = self._env_raw(ctx)
        if raw is not None:
            return self._coerce_text(ctx, raw, from_env=True), ParameterSource.ENVIRONMENT
        found, mapped = self._default_map_value(ctx)
        if self.prompt and self.prompt_required:
            shown = mapped if found else self.default
            if callable(shown):
                shown = shown()
            return self._prompt_one(ctx, shown), ParameterSource.PROMPT
        if found:
            return self._map_value(ctx, mapped), ParameterSource.DEFAULT_MAP
        if self.default is not None:
            return self._default_value(ctx), ParameterSource.DEFAULT
        return (() if self.multiple else None), None

    def _payload_item(self, payload):
        if self.nargs == 1 and not self.is_tuple_type:
            return payload[0]
        return payload

    def _prompt_one(self, ctx, default=None):
        value = self._prompt_once(ctx, default)
        return (value,) if self.multiple else value


class Argument(Parameter):
    """A positional parameter."""

    kind = "argument"

    def __init__(self, param_decls=(), required=None, **attrs):
        decls = list(param_decls)
        if len(decls) != 1 or _is_flag_name(decls[0]):
            raise TypeError("An argument takes exactly one destination name.")
        super().__init__(param_decls=decls, **attrs)
        self.name = decls[0]
        if self.nargs == 0 or (self.nargs != -1 and self.nargs < 1):
            raise TypeError("nargs must be a positive integer or -1 for an argument.")
        if required is None:
            required = self.default is None and self.nargs != -1
        self.required = bool(required)
        if self.deprecated and self.required:
            raise TypeError("A deprecated argument cannot be required.")
        self.prompt = None

    def describe(self) -> str:
        return "'" + self.name.upper() + "'"

    @property
    def is_variadic(self) -> bool:
        return self.nargs == -1

    def get_metavar(self):
        if self.metavar is not None:
            return self.metavar
        return self.name.upper()

    def placeholder(self) -> str:
        text = self.get_metavar()
        if not self.required:
            text = f"[{text}]"
        if self.is_variadic:
            text += "..."
        return text

    def resolve(self, ctx, tokens):
        if tokens:
            if self.is_variadic:
                return tuple(self._conv(t, ctx) for t in tokens), ParameterSource.COMMANDLINE
            if self.nargs == 1 and not self.is_tuple_type:
                return self._conv(tokens[0], ctx), ParameterSource.COMMANDLINE
            return self._occurrence(ctx, list(tokens)), ParameterSource.COMMANDLINE
        raw = self._env_raw(ctx)
        if raw is not None:
            if self.nargs == 1 and not self.is_tuple_type and not self.is_variadic:
                return self._conv(raw, ctx), ParameterSource.ENVIRONMENT
            return self._coerce_text(ctx, raw, from_env=True), ParameterSource.ENVIRONMENT
        found, mapped = self._default_map_value(ctx)
        if found:
            return self._map_value(ctx, mapped), ParameterSource.DEFAULT_MAP
        if self.default is not None:
            return self._default_value(ctx), ParameterSource.DEFAULT
        if self.is_variadic:
            return (), None
        return None, None


# ---------------------------------------------------------------------------
# The parser (FP-01, FP-03, FP-04)
# ---------------------------------------------------------------------------


# spec: N-000202
class _OptionParser:
    def __init__(self, ctx, options):
        self.ctx = ctx
        self.options = options
        self.prefixes = {"-"}
        self.table = {}
        for option in options:
            for name in option.opts + option.secondary_opts:
                if name:
                    self.prefixes.add(name[0])
        for option in options:
            if option.count:
                mode = "count"
            elif option.is_flag:
                mode = "flag"
            elif option.is_optional_value:
                mode = "optional"
            else:
                mode = "value"
            for name in option.opts:
                self.table[self._norm(name)] = (option, mode, option.flag_value if option.is_flag else None)
            for name in option.secondary_opts:
                self.table[self._norm(name)] = (option, mode, False)

    def _norm(self, name: str) -> str:
        func = self.ctx.token_normalize_func
        return func(name) if func else name

    def _optionish(self, token: str) -> bool:
        return len(token) > 1 and token[0] in self.prefixes

    def parse(self, args, limit, interspersed):
        hits = []
        pos = []
        dd = False
        allow_opts = True
        i = 0
        n = len(args)
        while i < n:
            token = args[i]
            if not dd and allow_opts and token == "--":
                dd = True
                i += 1
                continue
            if dd or not allow_opts or not self._optionish(token):
                if not dd and limit is not None and len(pos) >= limit:
                    break
                pos.append(token)
                if not interspersed and not dd:
                    allow_opts = False
                i += 1
                continue
            i = self._option(args, i, hits, pos)
        return hits, pos, i

    def _option(self, args, i, hits, pos):
        token = args[i]
        name, eq, attached = token.partition("=")
        key = self._norm(name)
        if key in self.table:
            return self._take(args, i, self.table[key], attached if eq else None, name, hits)
        if token[1:2] in self.prefixes:  # long-style unknown
            if self.ctx.ignore_unknown_options:
                pos.append(token)
                return i + 1
            raise NoSuchOption(name, ctx=self.ctx)
        j = 1
        while j < len(token):
            short = token[0] + token[j]
            entry = self.table.get(self._norm(short))
            if entry is None:
                if self.ctx.ignore_unknown_options:
                    pos.append(token[0] + token[j:])
                    return i + 1
                raise NoSuchOption(short, ctx=self.ctx)
            option, mode, _ = entry
            if mode in ("value", "optional"):
                rest = token[j + 1:]
                return self._take(args, i, entry, rest if rest else None, short, hits)
            if mode == "count":
                hits.append((option, 1, i))
            else:
                hits.append((option, entry[2], i))
            j += 1
        return i + 1

    def _take(self, args, i, entry, attached, display, hits):
        option, mode, payload = entry
        if mode == "flag":
            if attached is not None:
                raise BadOptionUsage(f"Option {display!r} does not take a value.", self.ctx)
            hits.append((option, payload, i))
            return i + 1
        if mode == "count":
            if attached is not None:
                raise BadOptionUsage(f"Option {display!r} does not take a value.", self.ctx)
            hits.append((option, 1, i))
            return i + 1
        values = []
        if attached is not None:
            values.append(attached)
        j = i + 1
        n = len(args)
        while len(values) < option.nargs and j < n:
            nxt = args[j]
            if self._optionish(nxt) and not _NEG_NUMBER.match(nxt):
                break
            values.append(nxt)
            j += 1
        if len(values) < option.nargs:
            if mode == "optional":
                hits.append((option, (option.flag_value,), i))
                return j
            if option.prompt:
                hits.append((option, _FLAG_ALONE, i))
                return j
            raise BadOptionUsage(f"Option {display!r} requires an argument.", self.ctx)
        hits.append((option, tuple(values), i))
        return j


# spec: N-000285
def _distribute_arguments(arguments, tokens):
    """Give each argument its tokens in declaration order; returns (map, surplus)."""
    result = {}
    i = 0
    for index, argument in enumerate(arguments):
        if argument.is_variadic:
            reserved = sum(a.nargs for a in arguments[index + 1:] if a.required and a.nargs > 0)
            take = tokens[i:max(i, len(tokens) - reserved)]
        else:
            take = tokens[i:i + argument.nargs]
        i += len(take)
        result[argument.name] = take
    return result, tokens[i:]


# ---------------------------------------------------------------------------
# Contexts
# ---------------------------------------------------------------------------


# spec: N-000950
class Context:
    """The state of one invocation (FP-07, Interface Contract §6)."""

    def __init__(self, command, parent=None, info_name=None, obj=None, default_map=None, **settings):
        self.command = command
        self.parent = parent
        self.info_name = info_name
        self.params = {}
        self.args = []
        self.protected_args = []
        self.invoked_subcommand = None
        self._sources = {}
        self._close_callbacks = []
        self._chained = False

        def inherit(key, fallback):
            if key in settings:
                return settings[key]
            if parent is not None:
                return getattr(parent, key)
            return fallback

        self.obj = obj if obj is not None else inherit("obj", None)
        self.auto_envvar_prefix = inherit("auto_envvar_prefix", None)
        self.terminal_width = inherit("terminal_width", None)
        self.max_content_width = inherit("max_content_width", 80)
        self.help_option_names = list(inherit("help_option_names", ["--help"]))
        self.token_normalize_func = inherit("token_normalize_func", None)
        self.color = inherit("color", None)
        self.show_default = inherit("show_default", False)
        self.allow_extra_args = settings.get("allow_extra_args", bool(getattr(command, "allow_extra_args", False)))
        self.ignore_unknown_options = settings.get("ignore_unknown_options", False)
        default_interspersed = not command._is_group
        self.allow_interspersed_args = settings.get("allow_interspersed_args", default_interspersed)

        if default_map is None:
            default_map = settings.get("default_map")
        if default_map is None and parent is not None and isinstance(parent.default_map, dict):
            child = parent.default_map.get(info_name)
            default_map = child if isinstance(child, dict) else None
        self.default_map = default_map

    # --- scope ---------------------------------------------------------

    def __enter__(self):
        context_stack().append(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        stack = context_stack()
        if stack and stack[-1] is self:
            stack.pop()
        elif self in stack:
            stack.remove(self)

    def call_on_close(self, func):
        self._close_callbacks.append(func)
        return func

    def with_resource(self, cm):
        value = cm.__enter__()
        self._close_callbacks.append(lambda: cm.__exit__(None, None, None))
        return value

    def close(self) -> None:
        callbacks, self._close_callbacks = self._close_callbacks, []
        error = None
        for func in reversed(callbacks):
            try:
                func()
            except Exception as e:  # keep closing the rest
                error = error or e
        if error is not None:
            raise error

    # --- navigation ----------------------------------------------------

    @property
    def root(self):
        ctx = self
        while ctx.parent is not None:
            ctx = ctx.parent
        return ctx

    @property
    def root_info_name(self):
        return self.root.info_name or self.root.command.name

    @property
    def command_path(self) -> str:
        if self.parent is None:
            return self.info_name or self.command.name or ""
        return f"{self.parent.command_path} {self.info_name or self.command.name}"

    def find_root(self):
        return self.root

    def find_object(self, object_type):
        ctx = self
        while ctx is not None:
            if isinstance(ctx.obj, object_type):
                return ctx.obj
            ctx = ctx.parent
        return None

    def ensure_object(self, object_type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

    def auto_envvar_name(self, param) -> str:
        parts = []
        ctx = self
        while ctx.parent is not None:
            parts.append(ctx.info_name or ctx.command.name)
            ctx = ctx.parent
        parts.reverse()
        pieces = [self.auto_envvar_prefix, *parts, param.name]
        return "_".join(str(p) for p in pieces).upper().replace("-", "_")

    def get_parameter_source(self, name):
        declared = {p.name for p in self.command.get_params(self)}
        if name not in declared:
            return None
        return self._sources.get(name, ParameterSource.DEFAULT)

    # --- control -------------------------------------------------------

    def exit(self, code: int = 0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def help_hint(self):
        return self.help_option_names[0] if self.help_option_names else None

    def get_help(self) -> str:
        return self.command.format_help(self)

    def get_usage(self) -> str:
        return "Usage: " + self.command.usage_line(self)

    def invoke(self, other, *args, **kwargs):
        """Run a command or callback from inside a callback (FP-07)."""
        if isinstance(other, Command):
            sub = Context(other, parent=self, info_name=other.name)
            with sub:
                try:
                    for param in other.params:
                        if param.expose_value and param.name not in kwargs:
                            kwargs[param.name] = param.invoke_default(sub)
                    return other._call_callback(kwargs)
                finally:
                    sub.close()
        with self:
            return other(*args, **kwargs)

    def forward(self, other, *args, **kwargs):
        merged = dict(self.params)
        merged.update(kwargs)
        return self.invoke(other, *args, **merged)


# ---------------------------------------------------------------------------
# Commands and groups
# ---------------------------------------------------------------------------


# spec: N-000850
class Command:
    """A leaf command: parameters and a callback (FP-01)."""

    allow_extra_args = False
    _is_group = False

    def __init__(self, name=None, callback=None, params=None, context_settings=None, help=None,
                 epilog=None, short_help=None, options_metavar="[OPTIONS]", add_help_option=True,
                 no_args_is_help=False, deprecated=False, hidden=False, **_ignored):
        self.name = name
        self.callback = callback
        self.params = list(params or [])
        if sum(1 for p in self.params if isinstance(p, Argument) and p.is_variadic) > 1:
            raise TypeError("Only one variadic argument may be declared on a command.")
        self.context_settings = dict(context_settings or {})
        if help is not None:
            help = help.split("\f", 1)[0]
        self.help = help
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = bool(no_args_is_help)
        self.deprecated = deprecated
        self.hidden = hidden

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"

    # --- parameters ------------------------------------------------------

    def get_params(self, ctx):
        params = list(self.params)
        declared = {n for p in params if isinstance(p, Option) for n in p.opts + p.secondary_opts}
        if self.add_help_option:
            names = [n for n in ctx.help_option_names if n not in declared]
            if names:
                params.append(_auto_help_option(names))
        return params

    def _exposed_params(self):
        return [p for p in self.params if p.expose_value]

    # --- help ------------------------------------------------------------

    def get_short_help_str(self) -> str:
        if self.short_help:
            return self.short_help
        return _fmt.make_default_short_help(self.help or "")

    def _width(self, ctx) -> int:
        if ctx.terminal_width:
            return ctx.terminal_width
        return min(shutil.get_terminal_size(fallback=(80, 24)).columns, ctx.max_content_width)

    def usage_pieces(self, ctx):
        pieces = []
        params = self.get_params(ctx)
        if any(not isinstance(p, Argument) and not p.hidden for p in params):
            pieces.append(self.options_metavar)
        for p in params:
            if isinstance(p, Argument):
                pieces.append(p.placeholder())
        return pieces

    def usage_line(self, ctx) -> str:
        return " ".join([ctx.command_path, *self.usage_pieces(ctx)])

    # spec: N-000827
    def format_help(self, ctx) -> str:
        width = self._width(ctx)
        lines = ["Usage: " + self.usage_line(ctx), ""]
        if self.help:
            lines.extend(_fmt.wrap_help_text(self.help, width))
            lines.append("")
        if self.deprecated:
            lines.append("(Deprecated)" + (f" {self.deprecated}" if isinstance(self.deprecated, str) else ""))
            lines.append("")
        params = self.get_params(ctx)
        arg_rows = []
        for p in params:
            if isinstance(p, Argument) and p.help and not p.hidden:
                arg_rows.append((p.placeholder(), p.help))
        if arg_rows:
            lines.append("Positional arguments:")
            lines.extend(_fmt.definition_list(arg_rows, width))
            lines.append("")
        option_rows = []
        for p in params:
            if isinstance(p, Option) and not p.hidden:
                option_rows.append(self._option_row(ctx, p))
        if option_rows:
            lines.append("Options:")
            lines.extend(_fmt.definition_list(option_rows, width))
            lines.append("")
        extra = self.format_extra_sections(ctx, width)
        if extra:
            lines.extend(extra)
            lines.append("")
        if self.epilog:
            lines.extend(_fmt.wrap_help_text(self.epilog, width))
            lines.append("")
        while lines and lines[-1] == "":
            lines.pop()
        return "\n".join(lines) + "\n"

    def format_extra_sections(self, ctx, width):
        return []

    # spec: N-000146
    def _option_row(self, ctx, option):
        names = " / ".join(option.all_names())
        metavar = option.get_metavar()
        first = f"{names} {metavar}" if metavar else names
        parts = []
        if option.help:
            parts.append(option.help)
        extras = []
        show = option.show_default if option.show_default is not None else ctx.show_default
        if show and option.default is not None and not (option.is_flag and option.default is False):
            if isinstance(show, str):
                extras.append(f"default: {show}")
            elif callable(option.default):
                extras.append("default: (dynamic)")
            elif isinstance(option.default, (list, tuple)):
                extras.append("default: " + ", ".join(str(v) for v in option.default))
            else:
                extras.append(f"default: {option.default}")
        if option.show_envvar and option.envvar:
            extras.append("env var: " + ", ".join(option.envvar))
        choices = option.type.get_choices_text()
        if choices:
            extras.append(f"choices: {choices}")
        if option.deprecated:
            extras.append("DEPRECATED" + (f": {option.deprecated}" if isinstance(option.deprecated, str) else ""))
        if extras:
            parts.append("[" + "; ".join(extras) + "]")
        return (first, " ".join(parts))

    # --- parsing ---------------------------------------------------------

    def make_context(self, info_name, args, parent=None, chained=False, **extra):
        settings = dict(self.context_settings)
        settings.update(extra)
        ctx = Context(self, parent=parent, info_name=info_name, **settings)
        ctx._chained = chained
        with ctx:
            try:
                self.parse_args(ctx, list(args))
            except BaseException:
                ctx.close()
                raise
        return ctx

    def parse_args(self, ctx, args):
        params = self.get_params(ctx)
        arguments = [p for p in params if isinstance(p, Argument)]
        options = [p for p in params if isinstance(p, Option)]
        if not args and self.no_args_is_help:
            echo(ctx.get_help(), err=True, color=ctx.color)
            raise NoArgsIsHelpError("Missing command." if self._is_group else "No arguments given.", ctx)

        limit = None
        if self._is_group or ctx._chained:
            limit = _slot_count(arguments)
        parser = _OptionParser(ctx, options)
        hits, tokens, index = parser.parse(args, limit, ctx.allow_interspersed_args)

        arg_tokens, surplus = _distribute_arguments(arguments, tokens)
        if self._is_group or ctx._chained:
            rest = args[index:]
            if self._is_group:
                ctx.protected_args = rest[:1]
                ctx.args = rest[1:]
            else:
                ctx.args = rest
        else:
            if surplus and not ctx.allow_extra_args:
                raise UsageError(
                    f"Got unexpected extra argument{'s' if len(surplus) != 1 else ''} "
                    f"({' '.join(surplus)})",
                    ctx,
                )
            ctx.args = list(surplus)

        self._process(ctx, params, hits, arg_tokens)

    # spec: N-000243
    def _process(self, ctx, params, hits, arg_tokens):
        by_param = {}
        for param, payload, position in hits:
            by_param.setdefault(id(param), (param, []))[1].append((param, payload, position))

        def first_position(param):
            entries = by_param.get(id(param))
            return entries[1][0][2] if entries else None

        eager = [p for p in params if p.is_eager and id(p) in by_param]
        eager.sort(key=first_position)
        ordered = eager + [p for p in params if p.is_eager and id(p) not in by_param]
        ordered += [p for p in params if not p.is_eager]

        for param in ordered:
            entries = by_param.get(id(param), (param, []))[1]
            if isinstance(param, Argument):
                if param.deprecated and arg_tokens.get(param.name):
                    _warn_deprecated(param.describe() + " argument", param.deprecated_note)
            elif entries and param.deprecated:
                _warn_deprecated(param.describe() + " option", param.deprecated_note)
            try:
                value, source = self._resolve_param(ctx, param, entries, arg_tokens)
                if param.callback is not None:
                    value = param.callback(ctx, param, value)
            except BadParameter as e:
                if e.param is None:
                    e.param = param
                raise
            if source is None and not (isinstance(param, Argument) and param.is_variadic):
                source = ParameterSource.DEFAULT
            if param.expose_value:
                ctx.params[param.name] = value
            ctx._sources[param.name] = source

    @staticmethod
    def _resolve_param(ctx, param, entries, arg_tokens):
        if isinstance(param, Argument):
            value, source = param.resolve(ctx, arg_tokens.get(param.name, []))
        else:
            value, source = param.resolve(ctx, entries)
        if source is None and param.required:
            param._missing(ctx)
        return value, source

    # --- invocation ------------------------------------------------------

    def _call_callback(self, kwargs):
        if self.callback is None:
            return None
        return self.callback(**kwargs)

    def _callback_kwargs(self, ctx):
        return {p.name: ctx.params[p.name] for p in self.params if p.expose_value and p.name in ctx.params}

    def invoke(self, ctx):
        if self.deprecated:
            _warn_deprecated(f"The command {self.name!r}", self.deprecated_note)
        try:
            with ctx:
                return self._call_callback(self._callback_kwargs(ctx))
        finally:
            ctx.close()

    @property
    def deprecated_note(self):
        return self.deprecated if isinstance(self.deprecated, str) else None

    # spec: N-000716
    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True,
             windows_expand_args=True, **extra):
        """Run this command as a program (FP-01, FP-13)."""
        if args is None:
            argv = list(sys.argv[1:])
            if windows_expand_args and sys.platform.startswith("win"):
                argv = _expand_windows_args(argv)
        else:
            argv = list(args)
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else (self.name or "")

        from .shell_completion import run_completion

        handled = run_completion(self, prog_name, argv, complete_var)
        if handled is not None:
            if standalone_mode:
                sys.exit(handled)
            return handled

        try:
            ctx = self.make_context(prog_name, argv, **extra)
            rv = self.invoke(ctx)
            if not standalone_mode:
                return rv
            sys.exit(0)
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return e.exit_code
        except OptlynError as e:
            if not standalone_mode:
                raise
            e.show()
            sys.exit(e.exit_code)
        except (Abort, EOFError, KeyboardInterrupt) as e:
            if not standalone_mode:
                raise Abort() from e
            echo("Aborted!", err=True)
            sys.exit(1)


# spec: N-000850
class Group(Command):
    """A command that dispatches to named subcommands (FP-06, FP-10)."""

    _is_group = True

    def __init__(self, name=None, commands=None, invoke_without_command=False, no_args_is_help=None,
                 subcommand_metavar=None, chain=False, result_callback=None, **kwargs):
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        super().__init__(name=name, no_args_is_help=no_args_is_help, **kwargs)
        self.commands = {}
        self.invoke_without_command = bool(invoke_without_command)
        self.subcommand_metavar = subcommand_metavar
        self.chain = bool(chain)
        self._result_callback = result_callback
        if commands is not None:
            items = commands.items() if isinstance(commands, dict) else [(c.name, c) for c in commands]
            for cmd_name, cmd in items:
                self.add_command(cmd, cmd_name)

    # --- registration ----------------------------------------------------

    def add_command(self, cmd, name=None):
        if self.chain and isinstance(cmd, Group):
            raise TypeError("Groups cannot be nested under a chaining group.")
        key = name or cmd.name
        if not key:
            raise TypeError("A command needs a name to be added to a group.")
        self.commands[key] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as _command

        def decorator(f):
            cmd = _command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as _group

        def decorator(f):
            cmd = _group(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self):
        def decorator(f):
            self._result_callback = f
            return f

        return decorator

    # --- lookup (override points for lazy loading) ------------------------

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        return self.commands.get(cmd_name)

    def _lookup(self, ctx, token):
        cmd = self.get_command(ctx, token)
        if cmd is not None:
            return token, cmd
        func = ctx.token_normalize_func
        if func:
            wanted = func(token)
            for candidate in self.list_commands(ctx):
                if func(candidate) == wanted:
                    found = self.get_command(ctx, candidate)
                    if found is not None:
                        return candidate, found
        return None, None

    def resolve_command(self, ctx, token):
        key, cmd = self._lookup(ctx, token)
        if cmd is None:
            raise UsageError(f"No such command {token!r}.", ctx)
        return key, cmd

    def _visible_commands(self, ctx):
        out = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is not None and not cmd.hidden:
                out.append((name, cmd))
        return out

    # --- help ------------------------------------------------------------

    def usage_pieces(self, ctx):
        pieces = super().usage_pieces(ctx)
        meta = self.subcommand_metavar or "COMMAND"
        if self.chain:
            pieces.append(f"{meta} [ARGS]...")
            pieces.append(f"[{meta} [ARGS]...]...")
        elif self.invoke_without_command:
            pieces.append(f"[{meta}] [ARGS]...")
        else:
            pieces.append(f"{meta} [ARGS]...")
        return pieces

    def format_extra_sections(self, ctx, width):
        rows = []
        for name, cmd in self._visible_commands(ctx):
            short = cmd.get_short_help_str()
            if cmd.deprecated:
                short = (short + " " if short else "") + "(Deprecated)"
            rows.append((name, short))
        if not rows:
            return []
        return ["Commands:", *_fmt.definition_list(rows, width)]

    # --- invocation ------------------------------------------------------

    def invoke(self, ctx):
        if self.deprecated:
            _warn_deprecated(f"The command {self.name!r}", self.deprecated_note)
        if self.chain:
            return self._invoke_chain(ctx)
        if not ctx.protected_args:
            if self.invoke_without_command:
                try:
                    with ctx:
                        return self._call_callback(self._callback_kwargs(ctx))
                finally:
                    ctx.close()
            ctx.close()
            raise UsageError("Missing command.", ctx)

        token = ctx.protected_args[0]
        try:
            key, cmd = self.resolve_command(ctx, token)
            ctx.invoked_subcommand = key
            with ctx:
                self._call_callback(self._callback_kwargs(ctx))
                sub = cmd.make_context(key, ctx.args, parent=ctx)
            rv = sub.command.invoke(sub)
            if self._result_callback is not None:
                with ctx:
                    rv = self._result_callback(rv, **self._callback_kwargs(ctx))
            return rv
        finally:
            ctx.close()

    # spec: N-000593
    def _invoke_chain(self, ctx):
        contexts = []
        try:
            rest = ctx.protected_args + ctx.args
            with ctx:
                while rest:
                    key, cmd = self.resolve_command(ctx, rest[0])
                    sub = cmd.make_context(key, rest[1:], parent=ctx, chained=True, allow_extra_args=True,
                                           allow_interspersed_args=False)
                    contexts.append(sub)
                    rest = sub.args
                if not contexts and not self.invoke_without_command:
                    raise UsageError("Missing command.", ctx)
                ctx.invoked_subcommand = "*" if contexts else None
                self._call_callback(self._callback_kwargs(ctx))
            results = []
            while contexts:
                sub = contexts.pop(0)
                results.append(sub.command.invoke(sub))
            if self._result_callback is not None:
                with ctx:
                    return self._result_callback(results, **self._callback_kwargs(ctx))
            return results
        finally:
            for sub in contexts:
                sub.close()
            ctx.close()


class CommandCollection(Group):
    """A group that presents the union of subcommands from several source groups."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name=name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = set()
        for source in self.sources:
            names.update(source.list_commands(ctx))
        names.update(self.commands)
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        for source in self.sources:
            found = source.get_command(ctx, cmd_name)
            if found is not None:
                return found
        return None


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------


def _slot_count(arguments):
    if any(a.is_variadic for a in arguments):
        return None
    return sum(a.nargs for a in arguments)


def _warn_deprecated(subject: str, note) -> None:
    text = f"DeprecationWarning: {subject} is deprecated."
    if note:
        text += f" {note}"
    echo(text, err=True)


def _expand_windows_args(args):
    """Expand globs, a leading ``~`` and %VAR% tokens (Windows shells do not)."""
    import glob

    out = []
    for token in args:
        expanded = os.path.expandvars(os.path.expanduser(token))
        if any(c in expanded for c in "*?["):
            out.extend(sorted(glob.glob(expanded)) or [expanded])
        else:
            out.append(expanded)
    return out


def _help_callback(ctx, param, value):
    if not value:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


def _auto_help_option(names):
    return Option(
        tuple(names),
        is_flag=True,
        is_eager=True,
        expose_value=False,
        callback=_help_callback,
        help="Show this message and exit.",
    )
