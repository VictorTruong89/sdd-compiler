"""In-process runner: ``CliRunner`` and ``Result`` (FP-14, §9)."""

from __future__ import annotations

import contextlib
import io
import os
import shutil
import sys
import tempfile

__all__ = ["CliRunner", "Result"]


class _Sink:
    """A byte sink that records its writes into the shared, ordered log."""

    def __init__(self, log, name):
        self._log = log
        self._name = name
        self.data = bytearray()

    def write(self, data):
        data = bytes(data)
        self.data.extend(data)
        self._log.append((self._name, data))
        return len(data)

    def flush(self):
        pass


class _CaptureStream(io.TextIOBase):
    """Text stream used by ``capture="sys"``; writes go to a sink in write order."""

    def __init__(self, sink, charset, errors="strict"):
        super().__init__()
        self.buffer = sink
        self._charset = charset
        self._errors = errors

    @property
    def encoding(self):
        return self._charset

    @property
    def errors(self):
        return self._errors

    def writable(self):
        return True

    def isatty(self):
        return False

    def fileno(self):
        raise io.UnsupportedOperation("fileno")

    def write(self, text):
        if not isinstance(text, str):
            raise TypeError("write() argument must be str")
        self.buffer.write(text.encode(self._charset, self._errors))
        return len(text)

    def flush(self):
        pass


class _InputStream(io.TextIOBase):
    """Standard input fed from the ``input`` argument of ``invoke``."""

    def __init__(self, data: bytes, charset, on_read=None):
        super().__init__()
        self._bytes = io.BytesIO(data)
        self.buffer = self._bytes
        self._charset = charset
        self._on_read = on_read

    @property
    def encoding(self):
        return self._charset

    def readable(self):
        return True

    def isatty(self):
        return False

    def fileno(self):
        raise io.UnsupportedOperation("fileno")

    def readline(self, size=-1):
        line = self._bytes.readline(size if size >= 0 else -1)
        text = line.decode(self._charset)
        if self._on_read is not None and text:
            self._on_read(text)
        return text

    def read(self, size=-1):
        text = self._bytes.read(size if size >= 0 else -1).decode(self._charset)
        if self._on_read is not None and text:
            self._on_read(text)
        return text


class Result:
    """What a run produced: status, captured output and any exception."""

    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value,
                 exit_code, exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self) -> str:
        return self.output_bytes.decode(self.runner.charset, "replace")

    @property
    def stdout(self) -> str:
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self) -> str:
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


# spec: N-000739
class CliRunner:
    """Invoke a command in-process with argument tokens and capture its output."""

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        log = []
        stdout_sink = _Sink(log, "stdout")
        stderr_sink = _Sink(log, "stderr")
        data = input.encode(self.charset) if isinstance(input, str) else (input or b"")
        echo_read = None
        if self.echo_stdin:
            echo_read = lambda text: stdout_sink.write(text.encode(self.charset))  # noqa: E731
        streams = {
            "stdin": _InputStream(data, self.charset, echo_read),
            "stdout": _CaptureStream(stdout_sink, self.charset),
            "stderr": _CaptureStream(stderr_sink, self.charset, "backslashreplace"),
        }
        merged = dict(self.env)
        merged.update(env or {})
        saved_env = {}
        for key, value in merged.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)
        saved = (sys.stdin, sys.stdout, sys.stderr)
        if self.capture == "fd":
            fd_streams = self._fd_capture(streams["stdin"])
        try:
            if self.capture == "fd":
                yield fd_streams.sinks + (fd_streams.log,)
            else:
                sys.stdin, sys.stdout, sys.stderr = streams["stdin"], streams["stdout"], streams["stderr"]
                yield stdout_sink, stderr_sink, log
        finally:
            if self.capture == "fd":
                fd_streams.restore()
            sys.stdin, sys.stdout, sys.stderr = saved
            for key, value in saved_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def _fd_capture(self, stdin):
        """Redirect OS descriptors 1 and 2 to temporary files (capture="fd")."""
        sys.stdout.flush()
        sys.stderr.flush()
        out_file = tempfile.TemporaryFile()
        err_file = tempfile.TemporaryFile()
        saved_fds = (os.dup(1), os.dup(2))
        os.dup2(out_file.fileno(), 1)
        os.dup2(err_file.fileno(), 2)
        sys.stdin = stdin
        sys.stdout = io.TextIOWrapper(io.FileIO(1, "w", closefd=False), encoding=self.charset,
                                      write_through=True)
        sys.stderr = io.TextIOWrapper(io.FileIO(2, "w", closefd=False), encoding=self.charset,
                                      errors="backslashreplace", write_through=True)
        class _FdCapture:
            sinks = None
            log = None

            def restore(self):
                for stream in (sys.stdout, sys.stderr):
                    try:
                        stream.flush()
                    except (OSError, ValueError):
                        pass
                os.dup2(saved_fds[0], 1)
                os.dup2(saved_fds[1], 2)
                for fd in saved_fds:
                    os.close(fd)
                out_file.seek(0)
                err_file.seek(0)
                out_bytes, err_bytes = out_file.read(), err_file.read()
                out_file.close()
                err_file.close()
                self.log.extend([("stdout", out_bytes), ("stderr", err_bytes)])
                self.sinks[0].data.extend(out_bytes)
                self.sinks[1].data.extend(err_bytes)

        capture = _FdCapture()
        capture.log = []
        capture.sinks = (_Sink(capture.log, "stdout"), _Sink(capture.log, "stderr"))
        return capture

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False,
               **extra) -> Result:
        """Run ``cli`` with ``args`` (a list of tokens) and capture the result."""
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if isinstance(args, str):
            import shlex

            args = shlex.split(args)
        args = list(args or [])
        prog_name = extra.pop("prog_name", None) or cli.name or "root"
        standalone = extra.pop("standalone_mode", True)
        extra.setdefault("color", color)

        exit_code = 0
        exception = None
        exc_info = None
        return_value = None
        with self.isolation(input=input, env=env, color=color) as (out, err, log):
            try:
                return_value = cli.main(
                    args=args,
                    prog_name=prog_name,
                    standalone_mode=standalone,
                    **extra,
                )
                if not standalone:
                    exit_code = return_value if isinstance(return_value, int) else 0
            except SystemExit as e:
                if isinstance(e.code, int) or e.code is None:
                    exit_code = e.code or 0
                else:
                    sys.stderr.write(str(e.code) + "\n")
                    exit_code = 1
                if exit_code:
                    exception = e
                    exc_info = sys.exc_info()
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
        output_bytes = b"".join(chunk for _, chunk in log)
        return Result(
            self,
            bytes(out.data),
            bytes(err.data),
            output_bytes,
            return_value,
            exit_code,
            exception,
            exc_info,
        )

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Run inside a new empty directory; yields its path.

        Without ``temp_dir`` the directory is removed on exit; with it the
        directory is created under ``temp_dir`` and left in place.
        """
        cwd = os.getcwd()
        path = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                shutil.rmtree(path, ignore_errors=True)
