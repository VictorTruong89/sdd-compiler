"""Terminal helpers: echo, styling, prompts, pager, editor, launch (FP-08, FP-11, §7)."""

from __future__ import annotations

import contextlib
import os
import re
import shlex
import subprocess
import sys
import tempfile
import time

from ._utils import (
    current_context_or_none,
    is_interactive,
    stdin_is_tty,
    stream_isatty,
    strip_ansi,
)
from .exceptions import Abort, BadParameter
from .paramtypes import _StdNonClosing, convert_type, open_file  # noqa: F401

__all__ = [
    "echo",
    "secho",
    "style",
    "unstyle",
    "echo_via_pager",
    "get_pager_file",
    "progressbar",
    "prompt",
    "confirm",
    "getchar",
    "pause",
    "edit",
    "launch",
    "clear",
    "get_app_dir",
    "format_filename",
    "open_file",
    "get_current_context",
]


def get_current_context(silent: bool = False):
    """Return the context current on this thread (raises if none and not silent)."""
    ctx = current_context_or_none()
    if ctx is None and not silent:
        raise RuntimeError("There is no active Optlyn context.")
    return ctx


def _write_text(file, text: str) -> None:
    encoding = (getattr(file, "encoding", None) or "utf-8").lower()
    if "ascii" in encoding and hasattr(file, "buffer"):
        file.flush()
        file.buffer.write(text.encode("utf-8", "replace"))
        file.buffer.flush()
        return
    try:
        file.write(text)
    except UnicodeEncodeError:
        file.flush()
        file.buffer.write(text.encode("utf-8", "replace"))
        file.buffer.flush()


# spec: N-000619
def echo(message=None, file=None, nl: bool = True, err: bool = False, color=None) -> None:
    """Write text or bytes to standard output (or standard error, or ``file``)."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if color is None:
        ctx = current_context_or_none()
        color = ctx.color if ctx is not None else None
    if color is None:
        color = stream_isatty(file)
    if isinstance(message, bytes):
        data = message + (b"\n" if nl else b"")
        target = getattr(file, "buffer", None)
        if target is None:
            file.write(data.decode("utf-8", "replace"))
        else:
            file.flush()
            target.write(data)
            target.flush()
        return
    text = str(message)
    if not color:
        text = strip_ansi(text)
    if nl:
        text += "\n"
    _write_text(file, text)
    try:
        file.flush()
    except (OSError, ValueError):
        pass


_COLORS = {
    "black": 30,
    "red": 31,
    "green": 32,
    "yellow": 33,
    "blue": 34,
    "magenta": 35,
    "cyan": 36,
    "white": 37,
    "reset": 39,
    "bright_black": 90,
    "bright_red": 91,
    "bright_green": 92,
    "bright_yellow": 93,
    "bright_blue": 94,
    "bright_magenta": 95,
    "bright_cyan": 96,
    "bright_white": 97,
}

# (on, off) SGR codes for each style switch.
_STYLES = {
    "bold": (1, 22),
    "dim": (2, 22),
    "italic": (3, 23),
    "underline": (4, 24),
    "blink": (5, 25),
    "reverse": (7, 27),
    "strikethrough": (9, 29),
    "overline": (53, 55),
}


def _color_codes(color, background: bool) -> list:
    if isinstance(color, str):
        if color not in _COLORS:
            raise TypeError(f"Unknown color {color!r}.")
        code = _COLORS[color]
        if background:
            return [49] if code == 39 else [code + 10]
        return [code]
    if isinstance(color, int) and not isinstance(color, bool):
        if not 0 <= color <= 255:
            raise TypeError(f"Color number {color} is out of range 0-255.")
        return [48 if background else 38, 5, color]
    if isinstance(color, (list, tuple)) and len(color) == 3 and all(
        isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
    ):
        return [48 if background else 38, 2, *color]
    raise TypeError(f"Invalid color {color!r}.")


def style(
    text,
    fg=None,
    bg=None,
    bold=None,
    dim=None,
    underline=None,
    overline=None,
    italic=None,
    blink=None,
    reverse=None,
    strikethrough=None,
    reset: bool = True,
) -> str:
    """Wrap ``text`` in ANSI SGR sequences."""
    codes: list = []
    if fg is not None:
        codes.extend(_color_codes(fg, False))
    if bg is not None:
        codes.extend(_color_codes(bg, True))
    switches = {
        "bold": bold,
        "dim": dim,
        "underline": underline,
        "overline": overline,
        "italic": italic,
        "blink": blink,
        "reverse": reverse,
        "strikethrough": strikethrough,
    }
    for name, value in switches.items():
        if value is None:
            continue
        on, off = _STYLES[name]
        codes.append(on if value else off)
    text = str(text)
    if not codes:
        return text
    prefix = "\x1b[" + ";".join(str(c) for c in codes) + "m"
    return prefix + text + ("\x1b[0m" if reset else "")


def unstyle(text) -> str:
    """Remove ANSI sequences, leaving the other text unchanged."""
    return strip_ansi(str(text))


def secho(message=None, file=None, nl: bool = True, err: bool = False, color=None, **styles) -> None:
    """Echo with styling applied in one step."""
    if message is not None:
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


def _pager_command():
    cmd = os.environ.get("PAGER")
    return shlex.split(cmd) if cmd else None


def echo_via_pager(text_or_generator, color=None) -> None:
    """Write long text through the pager when the session is interactive."""
    value = text_or_generator() if callable(text_or_generator) else text_or_generator
    chunks = [value] if isinstance(value, str) else iter(value)
    cmd = _pager_command()
    if is_interactive() and cmd:
        proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, text=True)
        try:
            for chunk in chunks:
                text = str(chunk)
                if color is False:
                    text = strip_ansi(text)
                proc.stdin.write(text)
                proc.stdin.flush()
        finally:
            if proc.stdin:
                proc.stdin.close()
            proc.wait()
        return
    for chunk in chunks:
        echo(chunk, nl=False, color=color)


@contextlib.contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream that goes through the pager when interactive."""
    cmd = _pager_command()
    if is_interactive() and cmd:
        proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, text=True)
        try:
            yield proc.stdin
        finally:
            proc.stdin.close()
            proc.wait()
        return
    yield _StdNonClosing(sys.stdout)


class ProgressBar:
    """Iterates a sequence while showing progress when attached to a terminal."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, **options) -> None:
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.pos = 0
        self.options = options
        self.visible = (not hidden) and stream_isatty(sys.stdout)
        self._start = time.time()
        self._entered = False
        self._announced = False

    def _announce(self) -> None:
        if not self._announced and not self.hidden and not self.visible and self.label:
            echo(self.label)
        self._announced = True

    def __enter__(self):
        self._start = time.time()
        self._announce()
        self._entered = True
        return self

    def __exit__(self, *exc) -> None:
        if self.visible:
            echo("", nl=True)
        self._entered = False

    def _eta_text(self) -> str:
        if not self.length or self.pos <= 0:
            return ""
        elapsed = time.time() - self._start
        remaining = elapsed / self.pos * max(self.length - self.pos, 0)
        return f" eta {int(remaining)}s"

    def render_progress(self) -> None:
        if not self.visible:
            return
        width = 30
        if self.length:
            filled = int(width * min(self.pos, self.length) / self.length)
            count = f" {self.pos}/{self.length}"
        else:
            filled = width if self.pos else 0
            count = f" {self.pos}"
        bar = "#" * filled + "-" * (width - filled)
        echo(f"\r{self.label} [{bar}]{count}{self._eta_text()}", nl=False)

    def update(self, n_steps: int, current_item=None) -> None:
        self.pos += n_steps
        self.render_progress()

    def __iter__(self):
        if self.iterable is None:
            raise TypeError("This progress bar has no iterable.")
        self._announce()
        for item in self.iterable:
            yield item
            self.update(1)


def progressbar(iterable=None, length=None, label=None, hidden=False, **options) -> ProgressBar:
    """Return a progress bar context manager that wraps ``iterable``."""
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)


def _read_line(hide_input: bool) -> str:
    if hide_input and stdin_is_tty():
        import getpass

        try:
            return getpass.getpass("")
        except EOFError as e:
            raise EOFError from e
    line = sys.stdin.readline()
    if line == "":
        raise EOFError()
    return line.rstrip("\r\n")


def _ask(text: str, hide_input: bool = False, err: bool = False) -> str:
    echo(text, nl=False, err=err)
    value = _read_line(hide_input)
    if not stdin_is_tty():
        echo(value if not hide_input else "", err=err)
    return value


# spec: N-000501
def prompt(
    text,
    default=None,
    hide_input: bool = False,
    confirmation_prompt: bool = False,
    type=None,
    value_proc=None,
    prompt_suffix: str = ": ",
    show_default: bool = True,
    err: bool = False,
):
    """Ask for a value, convert it, and re-ask on conversion failure.

    End of input raises ``EOFError``; the caller turns that into an abort.
    """
    ptype = convert_type(type, default)
    text_out = str(text)
    if default is not None and show_default and not hide_input:
        shown = default() if callable(default) else default
        text_out += f" [{shown}]"
    while True:
        try:
            value = _ask(text_out + prompt_suffix, hide_input, err)
        except EOFError as e:
            raise Abort() from e
        if value == "" and default is not None:
            value = default() if callable(default) else default
            if confirmation_prompt and not _confirm_pair(hide_input, err, value):
                continue
            return value
        try:
            if value_proc is not None:
                result = value_proc(value)
            else:
                result = ptype.convert(value)
        except BadParameter as e:
            echo(f"Error: {e.format_message()}", err=True)
            continue
        if confirmation_prompt and not _confirm_pair(hide_input, err, result):
            continue
        return result


def _confirm_pair(hide_input: bool, err: bool, expected) -> bool:
    try:
        second = _ask("Repeat for confirmation: ", hide_input, err)
    except EOFError as e:
        raise Abort() from e
    if second == str(expected):
        return True
    echo("Error: The two entered values do not match.", err=True)
    return False


def confirm(text, default: bool = False, abort: bool = False, prompt_suffix: str = ": ", show_default: bool = True, err: bool = False) -> bool:
    """Ask a yes/no question. ``y``/``yes`` and ``n``/``no`` are the answers."""
    if show_default:
        suffix = " [Y/n]" if default else " [y/N]"
    else:
        suffix = ""
    while True:
        try:
            answer = _ask(f"{text}{suffix}{prompt_suffix}", False, err).strip().lower()
        except EOFError as e:
            raise Abort() from e
        if answer == "":
            result = default
            break
        if answer in ("y", "yes"):
            result = True
            break
        if answer in ("n", "no"):
            result = False
            break
        echo("Error: invalid input", err=True)
    if abort and not result:
        raise Abort()
    return result


def getchar(echo: bool = False) -> str:
    """Read one character from the terminal, even when stdin is a pipe."""
    char = None
    try:
        import termios
        import tty

        fd = os.open("/dev/tty", os.O_RDONLY)
    except (ImportError, OSError):
        fd = None
    if fd is not None:
        try:
            old = termios.tcgetattr(fd)
            try:
                tty.setraw(fd)
                char = os.read(fd, 1).decode("utf-8", "replace")
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
        except (termios.error, OSError):
            char = None
        finally:
            os.close(fd)
    if char is None:
        char = sys.stdin.read(1)
        if char == "":
            raise EOFError()
    if char == "\x03":
        raise KeyboardInterrupt()
    if char == "\x04":
        raise EOFError()
    if echo:
        sys.stdout.write(char)
        sys.stdout.flush()
    return char


def pause(info=None, err: bool = False) -> None:
    """Print a message and wait for a key press when the session is interactive."""
    if info is None:
        info = "Press any key to continue..."
    echo(info, err=err, nl=True)
    if is_interactive():
        with contextlib.suppress(EOFError, OSError):
            getchar(echo=False)


def edit(text=None, editor=None, env=None, require_save: bool = True, extension: str = ".txt", filename=None):
    """Open an editor on text or a file. Returns the saved text, or None."""
    if editor is None:
        editor = (
            (env or {}).get("VISUAL")
            or (env or {}).get("EDITOR")
            or os.environ.get("VISUAL")
            or os.environ.get("EDITOR")
            or ("notepad" if sys.platform.startswith("win") else "vi")
        )
    run_env = dict(os.environ)
    run_env.update(env or {})
    command = shlex.split(editor) if isinstance(editor, str) else list(editor)
    if filename is not None:
        subprocess.call(command + [os.fspath(filename)], env=run_env)
        return None
    original = "" if text is None else str(text).replace("\r\n", "\n")
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(original)
        subprocess.call(command + [path], env=run_env)
        with open(path, encoding="utf-8", newline="") as handle:
            result = handle.read().replace("\r\n", "\n")
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
    if require_save and result == original:
        return None
    return result


def launch(url, wait: bool = False, locate: bool = False) -> int:
    """Open a URL or file with the default application."""
    target = os.fspath(url)
    if sys.platform.startswith("win"):
        os.startfile(target)  # noqa: S606
        return 0
    if sys.platform == "darwin":
        command = ["open"] + (["-R"] if locate else []) + [target]
    else:
        command = ["xdg-open", target]
    try:
        proc = subprocess.Popen(command)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0


def clear() -> None:
    """Clear the visible terminal; does nothing when not connected to one."""
    if stream_isatty(sys.stdout):
        sys.stdout.write("\x1b[2J\x1b[H")
        sys.stdout.flush()


_WS_RE = re.compile(r"\s+")


# spec: N-000674
def get_app_dir(app_name: str, roaming: bool = True, force_posix: bool = False) -> str:
    """Return the per-user configuration directory for ``app_name``."""
    home = os.path.expanduser("~")
    if sys.platform.startswith("win") and not force_posix:
        base = os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming")
        return os.path.join(base, app_name)
    unix_name = _WS_RE.sub("-", app_name.lower())
    if force_posix:
        return os.path.join(home, "." + unix_name)
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    config_home = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(config_home, unix_name)


def format_filename(filename, shorten: bool = False) -> str:
    """Return a printable text form of a file name, safe for strict UTF-8."""
    if isinstance(filename, bytes):
        text = os.fsdecode(filename)
    else:
        text = os.fspath(filename)
    if shorten:
        text = os.path.basename(text)
    return text.encode("utf-8", "backslashreplace").decode("utf-8")
