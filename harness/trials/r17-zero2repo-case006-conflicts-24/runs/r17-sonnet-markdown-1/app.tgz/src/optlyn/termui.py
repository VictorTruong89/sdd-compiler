import contextlib
import getpass
import inspect
import io
import itertools
import math
import os
import shutil
import subprocess
import sys
import time
from gettext import gettext as _

from . import types
from ._globals import get_current_context
from .exceptions import Abort, OptlynException, UsageError
from .utils import (echo, isatty, resolve_color_default, should_strip_ansi, strip_ansi, style)

visible_prompt_func = input
hidden_prompt_func = getpass.getpass

_getchar_override = None


def is_interactive():
    return isatty(sys.stdin) or isatty(sys.stdout)


def _build_prompt(text, suffix, show_default=False, default=None, show_choices=True, type=None):
    prompt = text
    if type is not None and show_choices and isinstance(type, types.Choice):
        prompt += " ({})".format(", ".join(type._name_of(c) for c in type.choices))
    if default is not None and show_default:
        if hasattr(default, "name") and hasattr(default, "read"):
            default = default.name
        elif hasattr(default, "name") and hasattr(default, "open"):
            default = default.name
        prompt = f"{prompt} [{default}]"
    return f"{prompt}{suffix}"


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False, show_choices=True):
    def prompt_func(text):
        f = hidden_prompt_func if hide_input else visible_prompt_func
        try:
            echo(text.rstrip(" "), nl=False, err=err)
            return f(" ")
        except (KeyboardInterrupt, EOFError):
            if hide_input:
                echo(None, err=err)
            raise Abort() from None

    if value_proc is None:
        value_proc = types.convert_type(type, default)
    prompt_text = _build_prompt(text, prompt_suffix, show_default, default, show_choices, type)
    if confirmation_prompt:
        if confirmation_prompt is True:
            confirmation_prompt = "Repeat for confirmation"
        confirmation_prompt = _build_prompt(confirmation_prompt, prompt_suffix)
    while True:
        while True:
            value = prompt_func(prompt_text)
            if value:
                break
            elif default is not None:
                value = default
                break
        try:
            result = value_proc(value)
        except UsageError as e:
            if hide_input:
                echo("Error: The value you entered was invalid.", err=err)
            else:
                echo(f"Error: {e.message}", err=err)
            continue
        if not confirmation_prompt:
            return result
        while True:
            value2 = prompt_func(confirmation_prompt)
            is_empty = not value and not value2
            if value2 or is_empty:
                break
        if value == value2:
            return result
        echo("Error: The two entered values do not match.", err=err)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    prompt_text = _build_prompt(
        text, prompt_suffix, show_default, "y/n" if default is None else ("Y/n" if default else "y/N")
    )
    while True:
        try:
            echo(prompt_text.rstrip(" "), nl=False, err=err)
            value = visible_prompt_func(" ").lower().strip()
        except (KeyboardInterrupt, EOFError):
            raise Abort() from None
        if value in ("y", "yes"):
            rv = True
        elif value in ("n", "no"):
            rv = False
        elif default is not None and value == "":
            rv = default
        else:
            echo("Error: invalid input", err=err)
            continue
        break
    if abort and not rv:
        raise Abort()
    return rv


# ------------------------------------------------------------------ pager


class _PagerStream:
    def __init__(self, stream, strip, close=False):
        self._stream = stream
        self._strip = strip
        self._close = close

    def write(self, text):
        if not isinstance(text, str):
            text = str(text)
        if self._strip:
            text = strip_ansi(text)
        n = self._stream.write(text)
        try:
            self._stream.flush()
        except Exception:
            pass
        return len(text) if n is None else n

    def writelines(self, lines):
        for line in lines:
            self.write(line)

    def flush(self):
        try:
            self._stream.flush()
        except Exception:
            pass

    def isatty(self):
        return False

    def __getattr__(self, name):
        return getattr(self._stream, name)


@contextlib.contextmanager
def get_pager_file(color=None):
    color = resolve_color_default(color)
    stdout = sys.stdout
    if stdout is None:
        stdout = io.StringIO()
    if not is_interactive():
        yield _PagerStream(stdout, should_strip_ansi(stdout, color))
        return
    pager_cmd = (os.environ.get("PAGER", None) or "").strip()
    if not pager_cmd:
        for cand in ("less", "more"):
            if shutil.which(cand):
                pager_cmd = cand
                break
    if not pager_cmd:
        yield _PagerStream(stdout, should_strip_ansi(stdout, color))
        return
    env = dict(os.environ)
    cmd_detail = pager_cmd.rsplit("/", 1)[-1].split()
    if color is None and cmd_detail and cmd_detail[0] == "less":
        less_flags = f"{os.environ.get('LESS', '')}{' '.join(cmd_detail[1:])}"
        if not less_flags:
            env["LESS"] = "-R"
            color = True
        elif "r" in less_flags or "R" in less_flags:
            color = True
    c = subprocess.Popen(pager_cmd, shell=True, stdin=subprocess.PIPE, env=env,
                         errors="replace", text=True)
    try:
        yield _PagerStream(c.stdin, not color)
    except (OSError, KeyboardInterrupt):
        pass
    finally:
        try:
            c.stdin.close()
        except OSError:
            pass
        while True:
            try:
                c.wait()
            except KeyboardInterrupt:
                pass
            else:
                break


def echo_via_pager(text_or_generator, color=None):
    if callable(text_or_generator):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        chunks = [text_or_generator]
    else:
        chunks = text_or_generator
    with get_pager_file(color) as f:
        for el in itertools.chain((el if isinstance(el, str) else str(el) for el in chunks), ["\n"]):
            f.write(el)
            f.flush()


# ------------------------------------------------------------------ progress


class ProgressBar:
    def __init__(self, iterable, length=None, fill_char="#", empty_char="-",
                 bar_template="%(label)s  [%(bar)s]  %(info)s", info_sep="  ", show_eta=True,
                 show_percent=None, show_pos=False, item_show_func=None, label=None, file=None,
                 color=None, update_min_steps=1, width=36, hidden=False):
        if file is None:
            file = sys.stdout
        self.file = file
        self.fill_char = fill_char
        self.empty_char = empty_char
        self.bar_template = bar_template
        self.info_sep = info_sep
        self.show_eta = show_eta
        self.show_percent = show_percent
        self.show_pos = show_pos
        self.item_show_func = item_show_func
        self.label = label or ""
        self.color = color
        self.update_min_steps = update_min_steps
        self._completed_intervals = 0
        self.width = width
        self.hidden = hidden
        self.autowidth = width == 0
        if length is None:
            try:
                length = operator_length_hint(iterable)
            except Exception:
                length = None
        if iterable is None:
            if length is None:
                raise TypeError("iterable or length is required")
            iterable = range(length)
        self.iter = iter(iterable)
        self.length = length
        self.pos = 0
        self.avg = []
        self.last_eta = self.start = time.time()
        self.eta_known = False
        self.finished = False
        self.max_width = None
        self.entered = False
        self.current_item = None
        self.is_hidden = hidden or not isatty(self.file)
        self._last_line = None

    def __enter__(self):
        self.entered = True
        self.render_progress()
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.render_finish()

    def __iter__(self):
        if not self.entered:
            raise RuntimeError("You need to use progress bars in a with block.")
        self.render_progress()
        return self.generator()

    def __next__(self):
        return next(iter(self))

    def render_finish(self):
        if self.is_hidden:
            return
        self.file.write("\n")
        self.file.flush()

    @property
    def pct(self):
        if self.finished:
            return 1.0
        return min(self.pos / ((float(self.length or 1)) or 1), 1.0)

    @property
    def time_per_iteration(self):
        if not self.avg:
            return 0.0
        return sum(self.avg) / float(len(self.avg))

    @property
    def eta(self):
        if self.length is not None and not self.finished:
            return self.time_per_iteration * (self.length - self.pos)
        return 0.0

    def format_eta(self):
        if self.eta_known:
            t = int(self.eta)
            seconds = t % 60
            t //= 60
            minutes = t % 60
            t //= 60
            hours = t % 24
            t //= 24
            if t > 0:
                return f"{t}d {hours:02}:{minutes:02}:{seconds:02}"
            return f"{hours:02}:{minutes:02}:{seconds:02}"
        return ""

    def format_pos(self):
        pos = str(self.pos)
        if self.length is not None:
            pos += f"/{self.length}"
        return pos

    def format_pct(self):
        return f"{int(self.pct * 100): 4}%"[1:]

    def format_bar(self):
        if self.length is not None:
            bar_length = int(self.pct * self.width)
            bar = self.fill_char * bar_length
            bar += self.empty_char * (self.width - bar_length)
        elif self.finished:
            bar = self.fill_char * self.width
        else:
            chars = list(self.empty_char * (self.width or 1))
            if self.time_per_iteration != 0:
                chars[int((math.cos(self.pos * self.time_per_iteration) / 2.0 + 0.5) * self.width)] = self.fill_char
            bar = "".join(chars)
        return bar

    def format_progress_line(self):
        show_percent = self.show_percent
        info_bits = []
        if self.length is not None and show_percent is None:
            show_percent = not self.show_pos
        if self.show_pos:
            info_bits.append(self.format_pos())
        if show_percent:
            info_bits.append(self.format_pct())
        if self.show_eta and self.eta_known and not self.finished:
            info_bits.append(self.format_eta())
        if self.item_show_func is not None:
            item_info = self.item_show_func(self.current_item)
            if item_info is not None:
                info_bits.append(item_info)
        return (self.bar_template % {
            "label": self.label, "bar": self.format_bar(),
            "info": self.info_sep.join(info_bits)}).rstrip()

    def render_progress(self):
        if self.hidden:
            return
        if self.is_hidden:
            if self.label and self._last_line != self.label:
                self._last_line = self.label
                echo(self.label, file=self.file, color=self.color)
            return
        buf = []
        line = self.format_progress_line()
        buf.append("\r")
        buf.append(line)
        clear_width = self.max_width or 0
        self.max_width = max(clear_width, len(strip_ansi(line)))
        pad = clear_width - len(strip_ansi(line))
        if pad > 0:
            buf.append(" " * pad)
        line = "".join(buf)
        if line != self._last_line:
            self._last_line = line
            echo(line, file=self.file, color=self.color, nl=False)
            self.file.flush()

    def make_step(self, n_steps):
        self.pos += n_steps
        if self.length is not None and self.pos >= self.length:
            self.finished = True
        if (time.time() - self.last_eta) < 1.0:
            return
        self.last_eta = time.time()
        if self.pos:
            step = (time.time() - self.start) / self.pos
        else:
            step = time.time() - self.start
        self.avg = self.avg[-6:] + [step]
        self.eta_known = self.length is not None

    def update(self, n_steps, current_item=None):
        self._completed_intervals += n_steps
        if current_item is not None:
            self.current_item = current_item
        if self._completed_intervals >= self.update_min_steps:
            self.make_step(self._completed_intervals)
            self.render_progress()
            self._completed_intervals = 0

    def finish(self):
        self.eta_known = False
        self.current_item = None
        self.finished = True

    def generator(self):
        if not self.entered:
            raise RuntimeError("You need to use progress bars in a with block.")
        if self.is_hidden:
            yield from self.iter
        else:
            for rv in self.iter:
                self.current_item = rv
                if self._completed_intervals == 0:
                    self.render_progress()
                yield rv
                self.update(1)
            self.finish()
            self.render_progress()


def operator_length_hint(iterable):
    import operator

    if iterable is None:
        return None
    n = operator.length_hint(iterable, -1)
    return None if n == -1 else n


def progressbar(iterable=None, length=None, label=None, hidden=False, show_eta=True,
                show_percent=None, show_pos=False, item_show_func=None, fill_char="#",
                empty_char="-", bar_template="%(label)s  [%(bar)s]  %(info)s", info_sep="  ",
                width=36, file=None, color=None, update_min_steps=1):
    color = resolve_color_default(color)
    return ProgressBar(
        iterable=iterable, length=length, show_eta=show_eta, show_percent=show_percent,
        show_pos=show_pos, item_show_func=item_show_func, fill_char=fill_char,
        empty_char=empty_char, bar_template=bar_template, info_sep=info_sep, file=file,
        label=label, width=width, color=color, update_min_steps=update_min_steps, hidden=hidden,
    )


# ------------------------------------------------------------------ misc


def _getchar_unix(echo_flag):
    import termios
    import tty

    if not isatty(sys.stdin):
        f = open("/dev/tty")
        fd = f.fileno()
    else:
        fd = sys.stdin.fileno()
        f = None
    ch = ""
    try:
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 32).decode(getattr(sys.stdin, "encoding", None) or "utf-8", "replace")
            if echo_flag and isatty(sys.stdout):
                sys.stdout.write(ch)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
            sys.stdout.flush()
            if f is not None:
                f.close()
    except termios.error:
        pass
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    return ch


def getchar(echo=False):
    if _getchar_override is not None:
        return _getchar_override(echo)
    sys.stdout.flush()
    return _getchar_unix(echo)


def pause(info=None, err=False):
    if info is None:
        info = "Press any key to continue..."
    if not is_interactive():
        if info:
            echo(info, err=err)
        return
    try:
        if info:
            echo(info, nl=False, err=err)
        try:
            getchar()
        except (KeyboardInterrupt, EOFError):
            pass
    finally:
        if info:
            echo(err=err)


def clear():
    if not isatty(sys.stdout):
        return
    echo("\033[2J\033[1;1H", nl=False)


class _Editor:
    def __init__(self, editor=None, env=None, require_save=True, extension=".txt"):
        self.editor = editor
        self.env = env
        self.require_save = require_save
        self.extension = extension

    def get_editor(self):
        if self.editor is not None:
            return self.editor
        for key in "VISUAL", "EDITOR":
            rv = os.environ.get(key)
            if rv:
                return rv
        for editor in "sensible-editor", "vim", "nano":
            if shutil.which(editor):
                return editor
        return "vi"

    def edit_file(self, filename):
        editor = self.get_editor()
        environ = None
        if self.env:
            environ = os.environ.copy()
            environ.update(self.env)
        try:
            c = subprocess.Popen(f'{editor} "{filename}"', env=environ, shell=True)
            exit_code = c.wait()
            if exit_code != 0:
                raise OptlynException(f"{editor}: Editing failed")
        except OSError as e:
            raise OptlynException(f"{editor}: Editing failed: {e}") from e

    def edit(self, text):
        import tempfile

        if not text:
            data = b""
        elif isinstance(text, (bytes, bytearray)):
            data = bytes(text)
        else:
            if text and not text.endswith("\n"):
                text += "\n"
            data = text.encode("utf-8")
        fd, name = tempfile.mkstemp(prefix="editor-", suffix=self.extension)
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(data)
            t = time.time() - 5
            os.utime(name, (t, t))
            timestamp = os.path.getmtime(name)
            self.edit_file(name)
            if self.require_save and os.path.getmtime(name) == timestamp:
                return None
            with open(name, "rb") as f:
                rv = f.read()
            if isinstance(text, (bytes, bytearray)):
                return rv
            return rv.decode("utf-8-sig").replace("\r\n", "\n")
        finally:
            os.unlink(name)


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    ed = _Editor(editor=editor, env=env, require_save=require_save, extension=extension)
    if filename is None:
        return ed.edit(text)
    ed.edit_file(filename)
    return None


def launch(url, wait=False, locate=False):
    from urllib.parse import unquote

    def _unquote_file(u):
        if u.startswith("file://"):
            u = unquote(u[7:])
        return u

    url = os.fspath(url)
    try:
        if locate:
            url = os.path.dirname(_unquote_file(url)) or "."
        else:
            url = _unquote_file(url)
        c = subprocess.Popen(["xdg-open", url])
        if wait:
            return c.wait()
        return 0
    except OSError:
        if url.startswith(("http://", "https://")) and not locate and not wait:
            import webbrowser

            webbrowser.open(url)
            return 0
        return 1
