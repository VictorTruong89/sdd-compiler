import threading

_local = threading.local()


def push_context(ctx):
    _local.__dict__.setdefault("stack", []).append(ctx)


def pop_context():
    _local.stack.pop()


def get_current_context(silent=False):
    """Return the context current on this thread."""
    try:
        return _local.stack[-1]
    except (AttributeError, IndexError):
        if not silent:
            raise RuntimeError("There is no active optlyn context.") from None
    return None
