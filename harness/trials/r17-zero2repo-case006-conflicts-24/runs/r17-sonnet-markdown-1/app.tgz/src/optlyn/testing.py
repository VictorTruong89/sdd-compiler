import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile
import threading

from . import formatting, termui, utils


class EchoingStdin:
    def __init__(self, input, output):
        self._input = input
        self._output = output
        self._paused = False

    def __getattr__(self, x):
        return getattr(self._input, x)

    def _echo(self, rv):
        if not self._paused:
            self._output.write(rv)
        return rv

    def read(self, n=-1):
        return self._echo(self._input.read(n))

    def read1(self, n=-1):
        return self._echo(self._input.read1(n))

    def readline(self, n=-1):
        return self._echo(self._input.readline(n))

    def readlines(self):
        return [self._echo(x) for x in self._input.readlines()]

    def __iter__(self):
        return iter(self._echo(x) for x in self._input)

    def __repr__(self):
        return repr(self._input)


@contextlib.contextmanager
def _pause_echo(stream):
    if stream is None:
        yield
    else:
        stream._paused = True
        yield
        stream._paused = False


class _NamedTextIOWrapper(io.TextIOWrapper):
    def __init__(self, buffer, name=None, mode=None, **kwargs):
        super().__init__(buffer, **kwargs)
        self._name = name
        self._mode = mode

    @property
    def name(self):
        return self._name

    @property
    def mode(self):
        return self._mode


class _Tee(io.BytesIO):
    """Bytes sink that also copies every write to a shared buffer (write order)."""

    def __init__(self, copy_to):
        super().__init__()
        self._copy_to = copy_to

    def write(self, b):
        self._copy_to.write(b)
        return super().write(b)


def make_input_stream(input, charset):
    if hasattr(input, "read"):
        rv = getattr(input, "buffer", None)
        if rv is None:
            rv = input.read()
            if isinstance(rv, str):
                rv = rv.encode(charset)
            return io.BytesIO(rv)
        return rv
    if input is None:
        input = b""
    elif isinstance(input, str):
        input = input.encode(charset)
    return io.BytesIO(input)


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value,
                 exit_code, exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    def _dec(self, b):
        return b.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def output(self):
        return self._dec(self.output_bytes)

    @property
    def stdout(self):
        return self._dec(self.stdout_bytes)

    @property
    def stderr(self):
        return self._dec(self.stderr_bytes)

    def __repr__(self):
        exc = repr(self.exception) if self.exception else "okay"
        return f"<Result {exc}>"


class _FdCapture:
    """Redirect OS level descriptors 1 and 2 into pipes drained by threads."""

    def __init__(self, combined):
        self.combined = combined
        self.lock = threading.Lock()
        self.bufs = {1: bytearray(), 2: bytearray()}
        self.saved = {}
        self.readers = {}
        self.threads = []

    def _drain(self, fd, r):
        while True:
            try:
                chunk = os.read(r, 65536)
            except OSError:
                break
            if not chunk:
                break
            with self.lock:
                self.bufs[fd] += chunk
                self.combined.write(chunk)
        os.close(r)

    def start(self):
        for fd in (1, 2):
            self.saved[fd] = os.dup(fd)
            r, w = os.pipe()
            os.dup2(w, fd)
            os.close(w)
            t = threading.Thread(target=self._drain, args=(fd, r), daemon=True)
            t.start()
            self.threads.append(t)

    def stop(self):
        for fd in (1, 2):
            os.dup2(self.saved[fd], fd)
            os.close(self.saved[fd])
        for t in self.threads:
            t.join(timeout=5)


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        self.charset = charset
        self.env = env or {}
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def make_env(self, overrides=None):
        rv = dict(self.env)
        if overrides:
            rv.update(overrides)
        return rv

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        bytes_input = make_input_stream(input, self.charset)
        echo_input = None
        old_stdin, old_stdout, old_stderr = sys.stdin, sys.stdout, sys.stderr
        old_forced_width = formatting.FORCED_WIDTH
        old_color = utils._isolation_color
        old_visible, old_hidden = termui.visible_prompt_func, termui.hidden_prompt_func
        old_getchar = termui._getchar_override
        formatting.FORCED_WIDTH = 80
        env = self.make_env(env)
        output = io.BytesIO()
        bytes_out = _Tee(output)
        bytes_err = _Tee(output)
        if self.echo_stdin:
            bytes_input = echo_input = EchoingStdin(bytes_input, bytes_out)
        sys.stdin = text_input = _NamedTextIOWrapper(
            bytes_input, encoding=self.charset, name="<stdin>", mode="r")
        if self.echo_stdin:
            text_input._CHUNK_SIZE = 1
        fdcap = None
        if self.capture == "fd":
            for s in (old_stdout, old_stderr):
                try:
                    s.flush()
                except Exception:
                    pass
            fdcap = _FdCapture(output)
            fdcap.start()
            sys.stdout = _NamedTextIOWrapper(
                open(1, "wb", buffering=0, closefd=False), encoding=self.charset,
                name="<stdout>", mode="w", write_through=True)
            sys.stderr = _NamedTextIOWrapper(
                open(2, "wb", buffering=0, closefd=False), encoding=self.charset,
                name="<stderr>", mode="w", errors="backslashreplace", write_through=True)
        else:
            sys.stdout = _NamedTextIOWrapper(bytes_out, encoding=self.charset, name="<stdout>", mode="w")
            sys.stderr = _NamedTextIOWrapper(bytes_err, encoding=self.charset, name="<stderr>",
                                             mode="w", errors="backslashreplace")

        @_pause_echo_deco(echo_input)
        def visible_input(prompt=None):
            sys.stdout.write(prompt or "")
            line = text_input.readline()
            if line == "":
                raise EOFError()
            val = line.rstrip("\r\n")
            sys.stdout.write(f"{val}\n")
            sys.stdout.flush()
            return val

        @_pause_echo_deco(echo_input)
        def hidden_input(prompt=None):
            sys.stdout.write(f"{prompt or ''}\n")
            sys.stdout.flush()
            line = text_input.readline()
            if line == "":
                raise EOFError()
            return line.rstrip("\r\n")

        @_pause_echo_deco(echo_input)
        def _getchar(echo):
            char = sys.stdin.read(1)
            if echo:
                sys.stdout.write(char)
            sys.stdout.flush()
            return char

        termui.visible_prompt_func = visible_input
        termui.hidden_prompt_func = hidden_input
        termui._getchar_override = _getchar
        utils._isolation_color = bool(color) if color is not None else None
        old_env = {}
        try:
            for key, value in env.items():
                old_env[key] = os.environ.get(key)
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            yield (bytes_out, bytes_err, output, fdcap)
        finally:
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            try:
                sys.stdout.flush()
                sys.stderr.flush()
            except Exception:
                pass
            if fdcap is not None:
                fdcap.stop()
            sys.stdout, sys.stderr, sys.stdin = old_stdout, old_stderr, old_stdin
            termui.visible_prompt_func = old_visible
            termui.hidden_prompt_func = old_hidden
            termui._getchar_override = old_getchar
            utils._isolation_color = old_color
            formatting.FORCED_WIDTH = old_forced_width

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False,
               **extra):
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        exc_info = None
        return_value = None
        exception = None
        exit_code = 0
        with self.isolation(input=input, env=env, color=color) as outstreams:
            if isinstance(args, str):
                args = shlex.split(args)
            try:
                prog_name = extra.pop("prog_name")
            except KeyError:
                prog_name = self.get_default_prog_name(cli)
            try:
                return_value = cli.main(args=args or (), prog_name=prog_name, **extra)
            except SystemExit as e:
                exc_info = sys.exc_info()
                e_code = e.code
                if e_code is None:
                    e_code = 0
                if e_code != 0:
                    exception = e
                if not isinstance(e_code, int):
                    sys.stdout.write(str(e_code))
                    sys.stdout.write("\n")
                    e_code = 1
                exit_code = e_code
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                try:
                    sys.stdout.flush()
                    sys.stderr.flush()
                except Exception:
                    pass
                bytes_out, bytes_err, output, fdcap = outstreams
                if fdcap is not None:
                    # let pipe drainers catch up
                    import time

                    time.sleep(0.02)
                    stdout = bytes(fdcap.bufs[1])
                    stderr = bytes(fdcap.bufs[2])
                else:
                    stdout = bytes_out.getvalue()
                    stderr = bytes_err.getvalue()
                output_bytes = output.getvalue()
        return Result(self, stdout, stderr, output_bytes, return_value, exit_code, exception,
                      exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass


def _pause_echo_deco(stream):
    def deco(f):
        def wrapper(*args, **kwargs):
            with _pause_echo(stream):
                return f(*args, **kwargs)

        return wrapper

    return deco
