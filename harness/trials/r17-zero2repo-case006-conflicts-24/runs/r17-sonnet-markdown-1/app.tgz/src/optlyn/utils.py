import codecs
import errno
import io
import os
import re
import sys

from ._globals import get_current_context
from .exceptions import DeclarationError, FileError

# Set by the test runner while isolated: True / False forces color; None autodetects.
_isolation_color = None

_ansi_re = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")


def strip_ansi(value):
    return _ansi_re.sub("", value)


def unstyle(text):
    return strip_ansi(text)


def isatty(stream):
    try:
        return stream.isatty()
    except Exception:
        return False


def is_ascii_encoding(encoding):
    try:
        return codecs.lookup(encoding).name == "ascii"
    except LookupError:
        return False


def resolve_color_default(color=None):
    if color is not None:
        return color
    ctx = get_current_context(silent=True)
    if ctx is not None:
        return ctx.color
    return None


def should_strip_ansi(stream=None, color=None):
    if color is None:
        if _isolation_color is not None:
            return not _isolation_color
        if stream is None:
            stream = sys.stdin
        return not isatty(stream)
    return not color


# ---------------------------------------------------------------- streams


def _find_binary_writer(stream):
    if isinstance(stream, (io.RawIOBase, io.BufferedIOBase)):
        return stream
    buf = getattr(stream, "buffer", None)
    if buf is not None and isinstance(buf, (io.RawIOBase, io.BufferedIOBase)):
        return buf
    return None


class _FlushingBinary:
    """Binary view of a text standard stream which keeps write order."""

    def __init__(self, text, binary):
        self._text = text
        self._binary = binary

    def write(self, data):
        try:
            self._text.flush()
        except Exception:
            pass
        n = self._binary.write(data)
        try:
            self._binary.flush()
        except Exception:
            pass
        return n

    def close(self):
        pass

    def __getattr__(self, name):
        return getattr(self._binary, name)


class _NonClosingTextIOWrapper(io.TextIOWrapper):
    def __del__(self):
        try:
            self.flush()
            self.detach()
        except Exception:
            pass

    def close(self):
        try:
            self.flush()
        except Exception:
            pass


def get_binary_stdout():
    stream = sys.stdout
    w = _find_binary_writer(stream)
    if w is None:
        raise RuntimeError("Was not able to determine binary stream for sys.stdout.")
    return _FlushingBinary(stream, w)


def get_binary_stderr():
    stream = sys.stderr
    w = _find_binary_writer(stream)
    if w is None:
        raise RuntimeError("Was not able to determine binary stream for sys.stderr.")
    return _FlushingBinary(stream, w)


def get_binary_stdin():
    buf = getattr(sys.stdin, "buffer", None)
    if buf is None:
        raise RuntimeError("Was not able to determine binary stream for sys.stdin.")
    return buf


def _text_out(stream, encoding, errors):
    if encoding is None and errors in (None, "strict"):
        return stream
    w = _find_binary_writer(stream)
    if w is None:
        return stream
    enc = encoding or getattr(stream, "encoding", None) or "utf-8"
    return _NonClosingTextIOWrapper(
        _FlushingBinary(stream, w), enc, errors or "strict", write_through=True
    )


def get_text_stdout(encoding=None, errors=None):
    return _text_out(sys.stdout, encoding, errors)


def get_text_stderr(encoding=None, errors=None):
    return _text_out(sys.stderr, encoding, errors)


def get_text_stdin(encoding=None, errors=None):
    if encoding is None and errors in (None, "strict"):
        return sys.stdin
    buf = getattr(sys.stdin, "buffer", None)
    if buf is None:
        return sys.stdin
    enc = encoding or getattr(sys.stdin, "encoding", None) or "utf-8"
    return _NonClosingTextIOWrapper(buf, enc, errors or "strict")


def get_text_stream(name, encoding=None, errors="strict"):
    return {"stdin": get_text_stdin, "stdout": get_text_stdout, "stderr": get_text_stderr}[name](
        encoding, errors
    )


def get_binary_stream(name):
    return {"stdin": get_binary_stdin, "stdout": get_binary_stdout, "stderr": get_binary_stderr}[name]()


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Print text or bytes with ANSI handling and robust encoding."""
    if file is None:
        file = sys.stderr if err else sys.stdout
        if file is None:
            return
    if message is not None and not isinstance(message, (str, bytes, bytearray)):
        out = str(message)
    else:
        out = message
    if nl:
        out = out or ""
        out = out + ("\n" if isinstance(out, str) else b"\n")
    if not out:
        try:
            file.flush()
        except Exception:
            pass
        return
    if isinstance(out, (bytes, bytearray)):
        binary = _find_binary_writer(file)
        if binary is not None:
            file.flush()
            binary.write(bytes(out))
            binary.flush()
            return
        out = bytes(out).decode(getattr(file, "encoding", None) or "utf-8", "replace")
    else:
        color = resolve_color_default(color)
        if should_strip_ansi(file, color):
            out = strip_ansi(out)
    enc = getattr(file, "encoding", None)
    if enc is not None and is_ascii_encoding(enc):
        binary = _find_binary_writer(file)
        if binary is not None:
            file.flush()
            binary.write(out.encode("utf-8"))
            binary.flush()
            return
    file.write(out)
    file.flush()


_ansi_colors = {
    "black": 30, "red": 31, "green": 32, "yellow": 33, "blue": 34, "magenta": 35,
    "cyan": 36, "white": 37, "reset": 39,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
}
_ansi_reset_all = "\033[0m"


def _interpret_color(color, offset=0):
    if isinstance(color, bool):
        raise DeclarationError(f"Unknown color {color!r}")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise DeclarationError(f"Unknown color {color!r}")
        return f"{38 + offset};5;{color:d}"
    if isinstance(color, (tuple, list)):
        if len(color) != 3 or not all(
            isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
        ):
            raise DeclarationError(f"Unknown color {color!r}")
        r, g, b = color
        return f"{38 + offset};2;{r:d};{g:d};{b:d}"
    if isinstance(color, str) and color in _ansi_colors:
        return str(_ansi_colors[color] + offset)
    raise DeclarationError(f"Unknown color {color!r}")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True):
    if not isinstance(text, str):
        text = str(text)
    bits = []
    if fg is not None:
        bits.append(f"\033[{_interpret_color(fg)}m")
    if bg is not None:
        bits.append(f"\033[{_interpret_color(bg, 10)}m")
    for val, on, off in (
        (bold, 1, 22), (dim, 2, 22), (underline, 4, 24), (overline, 53, 55),
        (italic, 3, 23), (blink, 5, 25), (reverse, 7, 27), (strikethrough, 9, 29),
    ):
        if val is not None:
            bits.append(f"\033[{on if val else off}m")
    bits.append(text)
    if reset:
        bits.append(_ansi_reset_all)
    return "".join(bits)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None and not isinstance(message, (bytes, bytearray)):
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


# ---------------------------------------------------------------- files


def format_filename(filename, shorten=False):
    if shorten:
        filename = os.path.basename(filename)
    else:
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        return filename.decode(sys.getfilesystemencoding() or "utf-8", "backslashreplace")
    return filename.encode("utf-8", "surrogateescape").decode("utf-8", "backslashreplace")


class _AtomicFile:
    def __init__(self, f, tmp_filename, real_filename):
        self._f = f
        self._tmp_filename = tmp_filename
        self._real_filename = real_filename
        self.closed = False

    @property
    def name(self):
        return self._real_filename

    def close(self, delete=False):
        if self.closed:
            return
        self._f.close()
        os.replace(self._tmp_filename, self._real_filename)
        self.closed = True
        if delete:
            pass

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.close(delete=exc_type is not None)

    def __repr__(self):
        return repr(self._f)

    def __iter__(self):
        return iter(self._f)


def open_stream(filename, mode="r", encoding=None, errors="strict", atomic=False):
    binary = "b" in mode
    filename = os.fspath(filename)
    if filename == "-" or filename == b"-":
        if any(m in mode for m in ("w", "a", "x")):
            if binary:
                return get_binary_stdout(), False
            return get_text_stdout(encoding=encoding, errors=errors), False
        if binary:
            return get_binary_stdin(), False
        return get_text_stdin(encoding=encoding, errors=errors), False
    if not atomic:
        if binary:
            return open(filename, mode), True
        return open(filename, mode, encoding=encoding, errors=errors), True
    if "a" in mode:
        raise ValueError("Appending to an existing file is not supported with atomic writes.")
    if "x" in mode:
        raise ValueError("Exclusive creation is not supported with atomic writes.")
    if "w" not in mode:
        raise ValueError("Atomic writes only make sense with `w`-mode.")
    import random

    try:
        perm = os.stat(filename).st_mode
    except OSError:
        perm = None
    flags = os.O_RDWR | os.O_CREAT | os.O_EXCL
    while True:
        tmp = os.path.join(
            os.path.dirname(filename), f".__atomic-write{random.randrange(1 << 32):08x}"
        )
        try:
            fd = os.open(tmp, flags, 0o666 if perm is None else perm)
            break
        except OSError as e:
            if e.errno == errno.EEXIST:
                continue
            raise
    if perm is not None:
        os.chmod(tmp, perm)
    if binary:
        f = open(fd, mode, closefd=True)
    else:
        f = open(fd, mode, encoding=encoding, errors=errors, closefd=True)
    return _AtomicFile(f, tmp, os.path.realpath(filename)), True


class LazyFile:
    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False):
        self.name = os.fspath(filename)
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self.should_close = True
        if self.name == "-":
            self._f, self.should_close = open_stream(filename, mode, encoding, errors)
        elif "r" in mode:
            open(filename, mode).close()

    def __getattr__(self, name):
        return getattr(self.open(), name)

    def __repr__(self):
        if self._f is not None:
            return repr(self._f)
        return f"<unopened file '{format_filename(self.name)}' {self.mode}>"

    def open(self):
        if self._f is not None:
            return self._f
        try:
            rv, self.should_close = open_stream(
                self.name, self.mode, self.encoding, self.errors, atomic=self.atomic
            )
        except OSError as e:
            raise FileError(self.name, hint=e.strerror) from e
        self._f = rv
        return rv

    def close(self):
        if self._f is not None:
            self._f.close()

    def close_intelligently(self):
        if self.should_close:
            self.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.close_intelligently()

    def __iter__(self):
        self.open()
        return iter(self._f)


class KeepOpenFile:
    def __init__(self, file):
        self._file = file

    def __getattr__(self, name):
        return getattr(self._file, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        pass

    def __repr__(self):
        return repr(self._file)

    def __iter__(self):
        return iter(self._file)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    f, should_close = open_stream(filename, mode, encoding, errors, atomic=atomic)
    if not should_close:
        f = KeepOpenFile(f)
    return f


def safecall(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception:
            pass

    return wrapper


def make_str(value):
    if isinstance(value, bytes):
        try:
            return value.decode(sys.getfilesystemencoding())
        except UnicodeError:
            return value.decode("utf-8", "replace")
    return str(value)


def _posixify(name):
    return "-".join(name.split()).lower()


def get_app_dir(app_name, roaming=True, force_posix=False):
    if sys.platform.startswith("win"):
        key = "APPDATA" if roaming else "LOCALAPPDATA"
        folder = os.environ.get(key)
        if folder is None:
            folder = os.path.expanduser("~")
        return os.path.join(folder, app_name)
    if force_posix:
        return os.path.join(os.path.expanduser("~"), "." + _posixify(app_name))
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~/Library/Application Support"), app_name)
    return os.path.join(os.path.expanduser("~/.config"), _posixify(app_name))
