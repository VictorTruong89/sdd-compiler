import enum
import os
import stat
import sys
import uuid
from datetime import datetime

from .exceptions import BadParameter, DeclarationError
from .utils import (LazyFile, format_filename, open_stream, safecall)


class ParamType:
    is_composite = False
    arity = 1
    name = ""
    envvar_list_splitter = None

    def __call__(self, value, param=None, ctx=None):
        if value is not None:
            return self.convert(value, param, ctx)

    def get_metavar(self, param):
        return None

    def get_missing_message(self, param):
        return None

    def convert(self, value, param, ctx):
        return value

    def split_envvar_value(self, rv):
        return (rv or "").split(self.envvar_list_splitter)

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def shell_complete(self, ctx, param, incomplete):
        return []


class FuncParamType(ParamType):
    def __init__(self, func):
        self.name = getattr(func, "__name__", None) or type(func).__name__
        self.func = func

    def convert(self, value, param, ctx):
        try:
            return self.func(value)
        except ValueError:
            try:
                value = str(value)
            except UnicodeError:
                value = value.decode("utf-8", "replace")
            self.fail(value, param, ctx)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        return value

    def __repr__(self):
        return "UNPROCESSED"


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        if isinstance(value, bytes):
            enc = sys.getfilesystemencoding() or "utf-8"
            try:
                return value.decode(enc)
            except UnicodeError:
                return value.decode("utf-8", "replace")
        return str(value)

    def __repr__(self):
        return "STRING"


class Choice(ParamType):
    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        self._enum = None
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self._enum = choices
            choices = list(choices)
        self.choices = tuple(choices)
        self.case_sensitive = case_sensitive

    def _name_of(self, c):
        if isinstance(c, enum.Enum):
            return c.name
        return str(c)

    def _normalize(self, s, ctx):
        if ctx is not None and ctx.token_normalize_func is not None:
            s = ctx.token_normalize_func(s)
        if not self.case_sensitive:
            s = s.casefold()
        return s

    def get_metavar(self, param):
        return "[{}]".format("|".join(self._name_of(c) for c in self.choices))

    def get_missing_message(self, param):
        return "Choose from:\n\t{}".format(",\n\t".join(self._name_of(c) for c in self.choices))

    def convert(self, value, param, ctx):
        if isinstance(value, enum.Enum) and value in self.choices:
            return value
        if not isinstance(value, str):
            for c in self.choices:
                if c == value and not isinstance(c, str):
                    return c
            value = str(value)
        mapping = {}
        for c in self.choices:
            mapping.setdefault(self._normalize(self._name_of(c), ctx), c)
        normed = self._normalize(value, ctx)
        if normed in mapping:
            return mapping[normed]
        if self._enum is not None and self.case_sensitive:
            # enumeration members are matched by name, ignoring letter case
            folded = {}
            for c in self.choices:
                folded.setdefault(self._name_of(c).casefold(), c)
            if normed.casefold() in folded:
                return folded[normed.casefold()]
        choices_str = ", ".join(map(repr, (self._name_of(c) for c in self.choices)))
        self.fail(f"{value!r} is not one of {choices_str}.", param, ctx)

    def __repr__(self):
        return f"Choice({list(self.choices)})"

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        names = [self._name_of(c) for c in self.choices]
        if not self.case_sensitive:
            inc = incomplete.casefold()
            return [CompletionItem(n) for n in names if n.casefold().startswith(inc)]
        return [CompletionItem(n) for n in names if n.startswith(incomplete)]


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else [
            "%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S",
        ]

    def get_metavar(self, param):
        return "[{}]".format("|".join(self.formats))

    def convert(self, value, param, ctx):
        if isinstance(value, datetime):
            return value
        result = None
        for fmt in self.formats:
            try:
                result = datetime.strptime(value, fmt)
            except (ValueError, TypeError):
                continue
        if result is not None:
            return result
        self.fail(
            "{!r} does not match the format{} {}.".format(
                value, "s" if len(self.formats) > 1 else "", ", ".join(repr(f) for f in self.formats)
            ),
            param, ctx,
        )

    def __repr__(self):
        return "DateTime"


class _NumberParamTypeBase(ParamType):
    _number_class = None

    def convert(self, value, param, ctx):
        try:
            return self._number_class(value)
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid {self.name}.", param, ctx)


class IntParamType(_NumberParamTypeBase):
    name = "integer"
    _number_class = int

    def __repr__(self):
        return "INT"


class FloatParamType(_NumberParamTypeBase):
    name = "float"
    _number_class = float

    def __repr__(self):
        return "FLOAT"


class _NumberRangeBase(_NumberParamTypeBase):
    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param, ctx):
        import operator

        rv = super().convert(value, param, ctx)
        lt_min = self.min is not None and (operator.le if self.min_open else operator.lt)(rv, self.min)
        gt_max = self.max is not None and (operator.ge if self.max_open else operator.gt)(rv, self.max)
        if self.clamp:
            if lt_min:
                return self._clamp(self.min, 1, self.min_open)
            if gt_max:
                return self._clamp(self.max, -1, self.max_open)
        if lt_min or gt_max:
            self.fail(f"{rv} is not in the range {self._describe_range()}.", param, ctx)
        return rv

    def _describe_range(self):
        if self.min is None:
            op = "<" if self.max_open else "<="
            return f"x{op}{self.max}"
        if self.max is None:
            op = ">" if self.min_open else ">="
            return f"x{op}{self.min}"
        lop = "<" if self.min_open else "<="
        rop = "<" if self.max_open else "<="
        return f"{self.min}{lop}x{rop}{self.max}"

    def __repr__(self):
        clamp = " clamped" if self.clamp else ""
        return f"<{type(self).__name__} {self._describe_range()}{clamp}>"


class IntRange(_NumberRangeBase, IntParamType):
    name = "integer range"

    def _clamp(self, bound, dir, open):
        if not open:
            return bound
        return bound + dir


class FloatRange(_NumberRangeBase, FloatParamType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        super().__init__(min=min, max=max, min_open=min_open, max_open=max_open, clamp=clamp)
        if (min_open or max_open) and clamp:
            raise DeclarationError("Clamping is not supported for open bounds.")

    def _clamp(self, bound, dir, open):
        if not open:
            return bound
        raise RuntimeError("Clamping is not supported for open bounds.")


class BoolParamType(ParamType):
    name = "boolean"
    TRUE = {"1", "true", "t", "yes", "y", "on"}
    FALSE = {"0", "false", "f", "no", "n", "off"}

    def convert(self, value, param, ctx):
        if value in {False, True} and isinstance(value, bool):
            return bool(value)
        norm = str(value).strip().lower()
        if norm in self.TRUE:
            return True
        if norm in self.FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)

    def __repr__(self):
        return "BOOL"


class UUIDParameterType(ParamType):
    name = "uuid"

    def convert(self, value, param, ctx):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)

    def __repr__(self):
        return "UUID"


class File(ParamType):
    name = "filename"
    envvar_list_splitter = os.path.pathsep

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def resolve_lazy_flag(self, value):
        if self.lazy is not None:
            return self.lazy
        if os.fspath(value) == "-":
            return False
        if "w" in self.mode:
            return True
        return False

    def convert(self, value, param, ctx):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        try:
            lazy = self.resolve_lazy_flag(value)
            if lazy:
                lf = LazyFile(value, self.mode, self.encoding, self.errors, atomic=self.atomic)
                if ctx is not None:
                    ctx.call_on_close(lf.close_intelligently)
                return lf
            f, should_close = open_stream(value, self.mode, self.encoding, self.errors, atomic=self.atomic)
            if ctx is not None:
                if should_close:
                    ctx.call_on_close(safecall(f.close))
                else:
                    ctx.call_on_close(safecall(f.flush))
            return f
        except OSError as e:
            self.fail(f"'{format_filename(value)}': {e.strerror}", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        return [CompletionItem(incomplete, type="file")]


class Path(ParamType):
    envvar_list_splitter = os.path.pathsep

    def __init__(self, exists=False, file_okay=True, dir_okay=True, writable=False,
                 readable=True, resolve_path=False, allow_dash=False, path_type=None,
                 executable=False):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.readable = readable
        self.writable = writable
        self.executable = executable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.type = path_type
        if self.file_okay and not self.dir_okay:
            self.name = "file"
        elif self.dir_okay and not self.file_okay:
            self.name = "directory"
        else:
            self.name = "path"

    def coerce_path_result(self, rv):
        if self.type is not None and not isinstance(rv, self.type):
            if self.type is str:
                rv = os.fsdecode(rv)
            elif self.type is bytes:
                rv = os.fsencode(rv)
            else:
                rv = self.type(rv)
        return rv

    def convert(self, value, param, ctx):
        rv = value
        is_dash = self.file_okay and self.allow_dash and rv in (b"-", "-")
        if not is_dash:
            if self.resolve_path:
                rv = os.path.realpath(os.path.expanduser(rv))
            try:
                st = os.stat(rv)
            except OSError:
                if not self.exists:
                    return self.coerce_path_result(rv)
                self.fail(f"{self.name.title()} {format_filename(value)!r} does not exist.", param, ctx)
            shown = format_filename(value)
            if not self.file_okay and stat.S_ISREG(st.st_mode):
                self.fail(f"{self.name.title()} {shown!r} is a file.", param, ctx)
            if not self.dir_okay and stat.S_ISDIR(st.st_mode):
                self.fail(f"{self.name.title()} {shown!r} is a directory.", param, ctx)
            if self.readable and not os.access(rv, os.R_OK):
                self.fail(f"{self.name.title()} {shown!r} is not readable.", param, ctx)
            if self.writable and not os.access(rv, os.W_OK):
                self.fail(f"{self.name.title()} {shown!r} is not writable.", param, ctx)
            if self.executable and not os.access(rv, os.X_OK):
                self.fail(f"{self.name.title()} {shown!r} is not executable.", param, ctx)
        return self.coerce_path_result(rv)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        type = "dir" if self.dir_okay and not self.file_okay else "file"
        return [CompletionItem(incomplete, type=type)]


class Tuple(ParamType):
    is_composite = True

    def __init__(self, types):
        self.types = [convert_type(ty) for ty in types]

    @property
    def name(self):
        return "<{}>".format(" ".join(ty.name for ty in self.types))

    @property
    def arity(self):
        return len(self.types)

    def convert(self, value, param, ctx):
        len_type = len(self.types)
        len_value = len(value)
        if len_value != len_type:
            self.fail(f"{len_type} values are required, but {len_value} were given.", param, ctx)
        return tuple(ty(x, param, ctx) for ty, x in zip(self.types, value))


def convert_type(ty, default=None):
    guessed_type = False
    if ty is None and default is not None:
        if isinstance(default, (tuple, list)):
            if default:
                item = default[0]
                if isinstance(item, (tuple, list)):
                    ty = tuple(map(type, item))
                else:
                    ty = type(item)
        else:
            ty = type(default)
        guessed_type = True
    if isinstance(ty, tuple):
        return Tuple(ty)
    if isinstance(ty, ParamType):
        return ty
    if ty is str or ty is None:
        return STRING
    if ty is int:
        return INT
    if ty is float:
        return FLOAT
    if ty is bool:
        return BOOL
    if guessed_type:
        return STRING
    return FuncParamType(ty)


UNPROCESSED = UnprocessedParamType()
STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParameterType()
