"""Shell completion: registration scripts and suggestion output.

Completion mode is selected by the environment variable named after the
program (``_<PROG>_COMPLETE``). ``<shell>_source`` prints the registration
script; ``<shell>_complete`` prints one suggestion per line as
``plain,<value>`` (with ``\\t<help>`` for zsh and fish), or as ``file,<token>``
or ``dir,<token>`` for a path request.
"""

import os
import sys
import typing as t

from .core import Argument, Command, Context, Group, Option
from .exceptions import OptlynError
from .param_types import File, Path

SHELLS = ("bash", "zsh", "fish", "powershell")


def complete_variable_name(prog_name: str) -> str:
    return "_" + prog_name.replace("-", "_").upper() + "_COMPLETE"


def run_completion(cmd: Command, prog_name: str, instruction: str, args: t.List[str]) -> bool:
    """Handle one completion instruction. Returns False for an unknown instruction."""
    if "_" not in instruction:
        return False
    shell, action = instruction.split("_", 1)
    if shell not in SHELLS or action not in ("source", "complete"):
        return False
    if action == "source":
        sys.stdout.write(_script(shell, prog_name, complete_variable_name(prog_name)))
        return True
    words, incomplete = _read_completion_env(shell)
    items = get_suggestions(cmd, prog_name, words, incomplete)
    lines = []
    for kind, value, help_text in items:
        if kind == "plain":
            if help_text and shell in ("zsh", "fish"):
                lines.append(f"plain,{value}\t{help_text}")
            else:
                lines.append(f"plain,{value}")
        else:
            lines.append(f"{kind},{value}")
    if lines:
        sys.stdout.write("\n".join(lines) + "\n")
    return True


def _read_completion_env(shell: str) -> t.Tuple[t.List[str], str]:
    words = os.environ.get("COMP_WORDS", "").split()
    if shell == "fish":
        incomplete = os.environ.get("COMP_CWORD", "")
        args = words[1:]
        if incomplete and args and args[-1] == incomplete:
            args = args[:-1]
        return args, incomplete
    try:
        index = int(os.environ.get("COMP_CWORD", str(len(words))))
    except ValueError:
        index = len(words)
    incomplete = words[index] if 0 <= index < len(words) else ""
    return words[1:index], incomplete


def _path_kind(ty: t.Any) -> str:
    if isinstance(ty, Path) and ty.dir_okay and not ty.file_okay:
        return "dir"
    return "file"


def _param_items(ctx: Context, param: t.Any, incomplete: str) -> t.List[t.Tuple[str, str, t.Optional[str]]]:
    """Suggestions for a value of one parameter."""
    if param._shell_complete is not None:
        raw = param._shell_complete(ctx, param, incomplete) or []
    elif isinstance(param.type, (File, Path)):
        return [(_path_kind(param.type), incomplete, None)]
    else:
        raw = param.type.shell_complete(ctx, param, incomplete)
    items: t.List[t.Tuple[str, str, t.Optional[str]]] = []
    for entry in raw:
        if isinstance(entry, str):
            items.append(("plain", entry, None))
            continue
        kind = getattr(entry, "type", "plain") or "plain"
        if kind != "plain":
            items.append((kind, getattr(entry, "value", ""), None))
        else:
            items.append(("plain", entry.value, getattr(entry, "help", None)))
    return items


def _resolve_node(
    cmd: Command, prog_name: str, args: t.List[str]
) -> t.Tuple[Command, Context, t.List[str]]:
    """Walk the groups named on the line; return the node the cursor is in."""
    node = cmd
    parent: t.Optional[Context] = None
    info = prog_name
    tokens = list(args)
    while True:
        ctx = Context(node, info_name=info, parent=parent, resilient_parsing=True)
        try:
            rest = node.parse_args(ctx, tokens)
        except OptlynError:
            rest = []
        if isinstance(node, Group) and rest:
            sub = node.resolve_command(ctx, rest[0])
            if sub is not None:
                parent = ctx
                node = sub
                info = rest[0]
                tokens = rest[1:]
                continue
        return node, ctx, tokens


def get_suggestions(
    cmd: Command, prog_name: str, args: t.List[str], incomplete: str
) -> t.List[t.Tuple[str, str, t.Optional[str]]]:
    node, ctx, tokens = _resolve_node(cmd, prog_name, args)
    mapping_params = node.get_params(ctx)
    items: t.List[t.Tuple[str, str, t.Optional[str]]] = []

    if incomplete.startswith("-"):
        for param in mapping_params:
            if not isinstance(param, Option) or param.hidden:
                continue
            for flag in param.opts + param.secondary_opts:
                if flag.startswith(incomplete):
                    items.append(("plain", flag, None))
        return items

    previous = tokens[-1] if tokens else None
    if previous is not None:
        for param in mapping_params:
            if isinstance(param, Option) and not param.is_flag and previous in param.opts:
                return _param_items(ctx, param, incomplete)

    if isinstance(node, Group) and not tokens:
        for name in node.list_commands(ctx):
            sub = node.get_command(ctx, name)
            if sub is None or sub.hidden or not name.startswith(incomplete):
                continue
            items.append(("plain", name, sub.get_short_help_str()))
        return items

    positional = [tok for tok in tokens if not tok.startswith("-")]
    arguments = [a for a in node.arguments]
    if len(positional) < len(arguments):
        arg: Argument = arguments[len(positional)]
        return [item for item in _param_items(ctx, arg, incomplete) if item[1].startswith(incomplete) or item[0] != "plain"]
    return items


def _script(shell: str, prog_name: str, complete_var: str) -> str:
    func = "_" + prog_name.replace("-", "_").replace(".", "_") + "_completion"
    if shell == "bash":
        return (
            f"{func}() {{\n"
            "    local IFS=$'\\n'\n"
            "    local item\n"
            "    COMPREPLY=()\n"
            f"    for item in $(env COMP_WORDS=\"${{COMP_WORDS[*]}}\" COMP_CWORD=$COMP_CWORD "
            f"{complete_var}=bash_complete {prog_name}); do\n"
            "        case \"$item\" in\n"
            "            plain,*) COMPREPLY+=(\"${item#plain,}\") ;;\n"
            "            file,*|dir,*) compopt -o default; COMPREPLY=(); break ;;\n"
            "        esac\n"
            "    done\n"
            "    return 0\n"
            "}\n"
            f"complete -F {func} {prog_name}\n"
        )
    if shell == "zsh":
        return (
            f"#compdef {prog_name}\n"
            f"{func}() {{\n"
            "    local item value\n"
            "    local -a values\n"
            f"    for item in \"${{(@f)$(env COMP_WORDS=\"${{words[*]}}\" COMP_CWORD=$((CURRENT-1)) "
            f"{complete_var}=zsh_complete {prog_name})}}\"; do\n"
            "        case \"$item\" in\n"
            "            plain,*) values+=(\"${item#plain,}\") ;;\n"
            "            file,*|dir,*) _files; return ;;\n"
            "        esac\n"
            "    done\n"
            "    compadd -a values\n"
            "}\n"
            f"compdef {func} {prog_name}\n"
        )
    if shell == "fish":
        return (
            f"complete --command {prog_name} --no-files --arguments "
            f"'(env COMP_WORDS=(commandline -opc) COMP_CWORD=(commandline -ct) "
            f"{complete_var}=fish_complete {prog_name} | string replace -r \"^plain,\" \"\")'\n"
        )
    if shell == "powershell":
        return (
            f"Register-ArgumentCompleter -Native -CommandName {prog_name} -ScriptBlock {{\n"
            "    param($wordToComplete, $commandAst, $cursorPosition)\n"
            "    $env:COMP_WORDS = $commandAst.ToString()\n"
            "    $env:COMP_CWORD = $commandAst.CommandElements.Count\n"
            f"    $env:{complete_var} = 'powershell_complete'\n"
            f"    & {prog_name} | ForEach-Object {{\n"
            "        if ($_ -like 'plain,*') { $v = $_.Substring(6); [System.Management.Automation.CompletionResult]::new($v, $v, 'ParameterValue', $v) }\n"
            "    }\n"
            f"    Remove-Item Env:{complete_var}\n"
            "}\n"
        )
    raise ValueError(f"Unknown shell {shell!r}.")
