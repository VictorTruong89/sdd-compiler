"""Small helpers shared by the terminal helpers, parameter types and help."""

import os
import re
import sys
import tempfile
import typing as t

from .exceptions import FileError

_ansi_re = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")


def strip_ansi(text: str) -> str:
    """Remove ANSI escape sequences and leave all other text alone."""
    return _ansi_re.sub("", text)


def is_interactive() -> bool:
    """A session is interactive when stdin or stdout is a terminal."""
    try:
        return bool(sys.stdin.isatty() or sys.stdout.isatty())
    except (AttributeError, ValueError):
        return False


def stream_isatty(stream: t.Any) -> bool:
    try:
        return bool(stream.isatty())
    except (AttributeError, ValueError):
        return False


def format_filename(filename: t.Any, shorten: bool = False) -> str:
    """Return printable, strict-UTF-8-encodable text for a file name.

    Undecodable bytes and lone surrogates become backslash escapes, so
    different names keep producing different text.
    """
    if hasattr(filename, "__fspath__"):
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        filename = os.fsdecode(filename)
    if shorten:
        filename = os.path.basename(filename)
    out = []
    for ch in filename:
        code = ord(ch)
        if 0xDC80 <= code <= 0xDCFF:
            out.append(f"\\x{code - 0xDC00:02x}")
        elif 0xD800 <= code <= 0xDFFF:
            out.append(f"\\u{code:04x}")
        else:
            out.append(ch)
    return "".join(out)


def get_app_dir(app_name: str, roaming: bool = True, force_posix: bool = False) -> str:
    """Return the per-user configuration directory for an application."""
    home = os.path.expanduser("~")
    if force_posix:
        folder = re.sub(r"\s+", "-", app_name.lower())
        return os.path.join(home, "." + folder)
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    if sys.platform == "win32":
        base = os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming")
        return os.path.join(base, app_name)
    folder = re.sub(r"\s+", "-", app_name.lower())
    xdg = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(xdg, folder)


class _KeepOpen:
    """Wraps a standard stream so that leaving a ``with`` block keeps it open."""

    def __init__(self, stream: t.Any) -> None:
        self._stream = stream

    def __getattr__(self, name: str) -> t.Any:
        return getattr(self._stream, name)

    def __iter__(self) -> t.Iterator[t.Any]:
        return iter(self._stream)

    def __next__(self) -> t.Any:
        return next(self._stream)

    def __enter__(self) -> "_KeepOpen":
        return self

    def __exit__(self, *exc: t.Any) -> None:
        pass

    def close(self) -> None:
        pass


class AtomicFile:
    """Writes to a sibling temporary file and replaces the target on close."""

    def __init__(self, filename: str, mode: str, encoding: t.Optional[str], errors: str) -> None:
        self._target = filename
        directory = os.path.dirname(os.path.abspath(filename))
        fd, self._tmp = tempfile.mkstemp(dir=directory, prefix=".__atomic-write")
        os.close(fd)
        umask = os.umask(0)
        os.umask(umask)
        os.chmod(self._tmp, 0o666 & ~umask)
        self._f = open(self._tmp, mode, **_text_kwargs(mode, encoding, errors))

    def __getattr__(self, name: str) -> t.Any:
        return getattr(self._f, name)

    def __enter__(self) -> "AtomicFile":
        return self

    def __exit__(self, *exc: t.Any) -> None:
        self.close()

    def close(self) -> None:
        if self._f.closed:
            return
        self._f.close()
        os.replace(self._tmp, self._target)


def _text_kwargs(mode: str, encoding: t.Optional[str], errors: str) -> t.Dict[str, t.Any]:
    """Binary modes take no encoding or error handler; text modes take both."""
    if "b" in mode:
        return {}
    return {"encoding": encoding, "errors": errors}


def _open_now(filename: str, mode: str, encoding: t.Optional[str], errors: str, atomic: bool) -> t.Any:
    if atomic:
        return AtomicFile(filename, mode, encoding, errors)
    return open(filename, mode, **_text_kwargs(mode, encoding, errors))


class LazyFile:
    """Opens its file on first use, so an unused write file is never truncated."""

    def __init__(
        self,
        filename: str,
        mode: str = "r",
        encoding: t.Optional[str] = None,
        errors: str = "strict",
        atomic: bool = False,
    ) -> None:
        self.name = filename
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f: t.Any = None

    def _open(self) -> t.Any:
        if self._f is None:
            try:
                self._f = _open_now(self.name, self.mode, self.encoding, self.errors, self.atomic)
            except OSError as e:
                raise FileError(
                    f"Could not open file '{format_filename(self.name)}': {e.strerror}",
                    filename=self.name,
                ) from e
        return self._f

    def __getattr__(self, name: str) -> t.Any:
        return getattr(self._open(), name)

    def __iter__(self) -> t.Iterator[t.Any]:
        return iter(self._open())

    def __next__(self) -> t.Any:
        return next(self._open())

    def __enter__(self) -> "LazyFile":
        return self

    def __exit__(self, *exc: t.Any) -> None:
        self.close()

    def close(self) -> None:
        if self._f is not None:
            self._f.close()


def open_file(
    filename: str,
    mode: str = "r",
    encoding: t.Optional[str] = None,
    errors: str = "strict",
    lazy: bool = False,
    atomic: bool = False,
) -> t.Any:
    """Open a file, or a standard stream for ``-``.

    ``-`` is stdin for reading and stdout for writing, and it is never closed
    by leaving a ``with`` block.
    """
    if filename == "-":
        binary = "b" in mode
        stream: t.Any = sys.stdout if "w" in mode or "a" in mode else sys.stdin
        if binary:
            stream = stream.buffer
        return _KeepOpen(stream)
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    return _open_now(filename, mode, encoding, errors, atomic)
