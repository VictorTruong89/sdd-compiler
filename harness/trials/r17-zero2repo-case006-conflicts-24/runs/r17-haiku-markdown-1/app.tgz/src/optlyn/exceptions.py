"""Exceptions used by Optlyn.

Errors that carry an exit status (``OptlynError`` and its subclasses) are
rendered by ``Command.main`` in standalone mode. ``Exit`` and ``Abort`` are
control-flow signals raised by callbacks.
"""

import sys
import typing as t


class OptlynError(Exception):
    """Base class for errors that the library reports with an exit status."""

    exit_code = 1

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message = message

    def format_message(self) -> str:
        return self.message

    def show(self, file: t.Optional[t.TextIO] = None) -> None:
        if file is None:
            file = sys.stderr
        file.write(f"Error: {self.format_message()}\n")


class UsageError(OptlynError):
    """An invocation that does not match the command definition (exit 2)."""

    exit_code = 2

    def __init__(self, message: str, ctx: t.Optional[t.Any] = None) -> None:
        super().__init__(message)
        self.ctx = ctx

    def show(self, file: t.Optional[t.TextIO] = None) -> None:
        if file is None:
            file = sys.stderr
        if self.ctx is not None:
            file.write(self.ctx.get_usage() + "\n")
            names = self.ctx.help_option_names
            if names:
                file.write(f"Try '{self.ctx.command_path} {names[0]}' for help.\n")
            file.write("\n")
        file.write(f"Error: {self.format_message()}\n")


class BadParameter(UsageError):
    """A value that cannot be used for a parameter.

    The report names the parameter, so that it is distinct from a failure
    about the command as a whole.
    """

    def __init__(
        self,
        message: str,
        ctx: t.Optional[t.Any] = None,
        param: t.Optional[t.Any] = None,
        param_hint: t.Optional[str] = None,
    ) -> None:
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self) -> str:
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        if hint:
            return f"Invalid value for {hint}: {self.message}"
        return self.message


class MissingParameter(BadParameter):
    """A required parameter that received no value."""

    def format_message(self) -> str:
        return self.message


class BadOptionUsage(UsageError):
    """An option was used incorrectly, for example without its value."""


class BadArgumentUsage(UsageError):
    """An argument was used incorrectly."""


class NoSuchOption(UsageError):
    """An option token that the command does not declare."""

    def __init__(self, option_name: str, ctx: t.Optional[t.Any] = None) -> None:
        super().__init__(f"No such option: {option_name}", ctx)
        self.option_name = option_name


class NoSuchCommand(UsageError):
    """A subcommand name that the group does not resolve."""

    def __init__(self, name: str, ctx: t.Optional[t.Any] = None) -> None:
        super().__init__(f"No such command '{name}'.", ctx)
        self.command_name = name


class MissingCommand(UsageError):
    """A group was invoked without the subcommand it requires."""

    def __init__(self, ctx: t.Optional[t.Any] = None) -> None:
        super().__init__("Missing command.", ctx)


class NoArgsIsHelp(UsageError):
    """No arguments were given where help is shown as a usage failure.

    The help page is the report, so it is printed to standard error.
    """

    def __init__(self, ctx: t.Any) -> None:
        super().__init__("", ctx)

    def show(self, file: t.Optional[t.TextIO] = None) -> None:
        if file is None:
            file = sys.stderr
        file.write(self.ctx.get_help() + "\n")


class FileError(OptlynError):
    """A file that could not be opened or used at the time I/O started."""

    exit_code = 1

    def __init__(self, message: str, filename: t.Optional[str] = None) -> None:
        super().__init__(message)
        self.filename = filename


class Abort(RuntimeError):
    """The user or the author aborted the invocation (exit 1)."""


class Exit(RuntimeError):
    """An author clean stop, or an intentional help/version exit."""

    def __init__(self, code: int = 0) -> None:
        super().__init__(code)
        self.exit_code = code
