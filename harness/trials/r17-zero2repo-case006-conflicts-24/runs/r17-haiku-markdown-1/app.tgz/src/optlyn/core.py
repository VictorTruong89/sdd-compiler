"""Commands, groups, parameters, invocation contexts and the parser."""

import enum
import os
import re
import sys
import threading
import typing as t
from contextlib import ExitStack
from functools import update_wrapper

from .exceptions import (
    Abort,
    BadOptionUsage,
    BadParameter,
    Exit,
    FileError,
    MissingCommand,
    MissingParameter,
    NoArgsIsHelp,
    NoSuchCommand,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .termui import confirm as _confirm
from .termui import echo
from .termui import prompt as _prompt
from .param_types import BOOL, FALSE_STRINGS, TRUE_STRINGS, ParamType, Tuple, convert_type

PREFIX_CHARS = "-+/"
FLAG_PREFIX_CHARS = PREFIX_CHARS


class ParameterSource(enum.Enum):
    """Where the value of a parameter came from, most explicit first."""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


_RANK = {
    ParameterSource.PROMPT: 5,
    ParameterSource.COMMANDLINE: 4,
    ParameterSource.ENVIRONMENT: 3,
    ParameterSource.DEFAULT_MAP: 2,
    ParameterSource.DEFAULT: 1,
}

_VALUE = object()  # flag-table marker: the option takes a value
_MISSING = object()  # no value from this source
_PROMPT_MARK = object()  # the option was present without a value

_local = threading.local()


def _context_stack() -> t.List["Context"]:
    stack = getattr(_local, "stack", None)
    if stack is None:
        stack = _local.stack = []
    return stack


def get_current_context(silent: bool = False) -> t.Optional["Context"]:
    """Return the context that is current on this thread."""
    stack = _context_stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active click context.")


class Context:
    """The state of one invocation of one command."""

    def __init__(
        self,
        command: "Command",
        parent: t.Optional["Context"] = None,
        info_name: t.Optional[str] = None,
        obj: t.Any = None,
        auto_envvar_prefix: t.Optional[str] = None,
        default_map: t.Optional[t.Dict[str, t.Any]] = None,
        terminal_width: t.Optional[int] = None,
        max_content_width: t.Optional[int] = None,
        help_option_names: t.Optional[t.List[str]] = None,
        token_normalize_func: t.Optional[t.Callable[[str], str]] = None,
        color: t.Optional[bool] = None,
        show_default: t.Optional[bool] = None,
        allow_extra_args: t.Optional[bool] = None,
        allow_interspersed_args: t.Optional[bool] = None,
        ignore_unknown_options: t.Optional[bool] = None,
        resilient_parsing: bool = False,
    ) -> None:
        self.command = command
        self.parent = parent
        self.info_name = info_name

        def inherit(attr: str, value: t.Any) -> t.Any:
            if value is None and parent is not None:
                return getattr(parent, attr)
            return value

        self.obj = inherit("obj", obj)
        self.auto_envvar_prefix = inherit("auto_envvar_prefix", auto_envvar_prefix)
        if default_map is None and parent is not None and isinstance(parent.default_map, dict):
            default_map = parent.default_map.get(info_name)
        self.default_map = default_map
        self.terminal_width = inherit("terminal_width", terminal_width)
        self.max_content_width = inherit("max_content_width", max_content_width)
        self.help_option_names = inherit("help_option_names", help_option_names) or ["--help"]
        self.token_normalize_func = inherit("token_normalize_func", token_normalize_func)
        self.color = inherit("color", color)
        self.show_default = inherit("show_default", show_default)
        self.allow_extra_args = (
            command.allow_extra_args if allow_extra_args is None else allow_extra_args
        )
        self.allow_interspersed_args = (
            command.allow_interspersed_args
            if allow_interspersed_args is None
            else allow_interspersed_args
        )
        self.ignore_unknown_options = (
            command.ignore_unknown_options
            if ignore_unknown_options is None
            else ignore_unknown_options
        )
        self.resilient_parsing = resilient_parsing

        self.params: t.Dict[str, t.Any] = {}
        self.args: t.List[str] = []
        self.invoked_subcommand: t.Optional[str] = None
        self._raw: t.Dict[str, t.List[t.Any]] = {}
        self._sources: t.Dict[str, ParameterSource] = {}
        self._eager_done: t.Dict[str, t.Any] = {}
        self._subcommand: t.Optional[t.Tuple["Command", t.List[str]]] = None
        self._rest: t.List[str] = []
        self._exit_stack = ExitStack()

    @property
    def command_path(self) -> str:
        names = []
        ctx: t.Optional[Context] = self
        while ctx is not None:
            names.append(ctx.info_name or ctx.command.name or "")
            ctx = ctx.parent
        return " ".join(reversed(names))

    def __enter__(self) -> "Context":
        _context_stack().append(self)
        return self

    def __exit__(self, *exc_info: t.Any) -> None:
        stack = _context_stack()
        if stack and stack[-1] is self:
            stack.pop()

    def find_root(self) -> "Context":
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type: t.Type[t.Any]) -> t.Any:
        node: t.Optional[Context] = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type: t.Type[t.Any]) -> t.Any:
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

    def call_on_close(self, func: t.Callable[[], t.Any]) -> None:
        self._exit_stack.callback(func)

    def with_resource(self, cm: t.ContextManager[t.Any]) -> t.Any:
        return self._exit_stack.enter_context(cm)

    def close(self) -> None:
        self._exit_stack.close()

    def exit(self, code: int = 0) -> t.NoReturn:
        raise Exit(code)

    def abort(self) -> t.NoReturn:
        raise Abort()

    def get_parameter_source(self, name: str) -> t.Optional[ParameterSource]:
        declared = {p.name for p in self.command.params}
        if name not in declared:
            return None
        return self._sources.get(name, ParameterSource.DEFAULT)

    def get_help(self) -> str:
        from .formatting import format_help

        return format_help(self)

    def get_usage(self) -> str:
        from .formatting import format_usage

        return format_usage(self)

    def invoke(self, callback: t.Any, *args: t.Any, **kwargs: t.Any) -> t.Any:
        """Run a command or a plain callable from inside a callback."""
        if isinstance(callback, Command):
            other = callback
            ctx = Context(other, info_name=other.name, parent=self)
            values: t.Dict[str, t.Any] = {}
            with ctx:
                try:
                    for param in other.params:
                        if not param.expose_value:
                            continue
                        if param.name in kwargs:
                            values[param.name] = kwargs.pop(param.name)
                        else:
                            values[param.name] = param.get_default(ctx)
                    values.update(kwargs)
                    if other.callback is None:
                        return None
                    return other.callback(*args, **values)
                finally:
                    ctx.close()
        with self:
            return callback(*args, **kwargs)

    def forward(self, cmd: t.Any, *args: t.Any, **kwargs: t.Any) -> t.Any:
        """Run another command with this command's current values as defaults."""
        values = dict(self.params)
        values.update(kwargs)
        return self.invoke(cmd, *args, **values)


def _help_callback(ctx: Context, param: "Parameter", value: t.Any) -> None:
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


def _warn_deprecated(kind: str, hint: str, note: t.Any) -> None:
    message = f"DeprecationWarning: The {kind} {hint} is deprecated."
    if isinstance(note, str) and note:
        message = f"{message} {note}"
    echo(message, err=True)


def _parse_decls(decls: t.Sequence[str]) -> t.Tuple[t.List[str], t.List[str], t.Optional[str]]:
    opts: t.List[str] = []
    secondary: t.List[str] = []
    dest: t.Optional[str] = None
    for decl in decls:
        if not decl:
            continue
        if decl[0] not in PREFIX_CHARS:
            dest = decl
            continue
        parts = decl.split("/")
        if len(parts) == 2 and parts[0] and parts[1]:
            opts.append(parts[0])
            secondary.append(parts[1])
        else:
            opts.append(decl)
    return opts, secondary, dest


def _infer_name(opts: t.Sequence[str]) -> str:
    long_names = [o for o in opts if len(o) > 1 and o[0] == o[1]]
    pick = long_names[0] if long_names else opts[0]
    return pick.lstrip(PREFIX_CHARS).replace("-", "_")


class Parameter:
    """Common behaviour of options and arguments."""

    param_type_name = "parameter"

    def __init__(
        self,
        name: str,
        type: t.Any = None,
        default: t.Any = None,
        required: bool = False,
        callback: t.Optional[t.Callable[..., t.Any]] = None,
        nargs: int = 1,
        multiple: bool = False,
        metavar: t.Optional[str] = None,
        expose_value: bool = True,
        is_eager: bool = False,
        envvar: t.Any = None,
        shell_complete: t.Optional[t.Callable[..., t.Any]] = None,
        deprecated: t.Any = False,
        hidden: bool = False,
        help: t.Optional[str] = None,
        allow_from_autoenv: bool = True,
        auto_default: bool = False,
    ) -> None:
        self.name = name
        self.type: ParamType = convert_type(type, default)
        if isinstance(self.type, Tuple):
            nargs = len(self.type.types)
        if nargs == 0 or nargs < -1:
            raise TypeError("nargs must be a positive integer or -1.")
        if multiple and nargs == -1:
            raise TypeError("A variadic parameter cannot also be repeatable.")
        if deprecated and required:
            raise TypeError(f"Parameter {name!r} cannot be deprecated and required.")
        self.nargs = nargs
        self.multiple = multiple
        self.default = default
        self.required = required
        self.callback = callback
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        if isinstance(envvar, str):
            self.envvar = [envvar]
        else:
            self.envvar = list(envvar or [])
        self._shell_complete = shell_complete
        self.deprecated = deprecated
        self.hidden = hidden
        self.help = help
        self.allow_from_autoenv = allow_from_autoenv
        self.auto_default = auto_default

    # -- hooks that subclasses refine -------------------------------------

    def get_error_hint(self, ctx: t.Optional[Context]) -> str:
        return f"'{self.name}'"

    def _missing_error(self, ctx: Context) -> MissingParameter:
        return MissingParameter(f"Missing {self.param_type_name} {self.get_error_hint(ctx)}.", ctx, self)

    def _wants_prompt(self, flag_without_value: bool) -> bool:
        return False

    def _prompt_value(self, ctx: Context, default: t.Any) -> t.Any:
        raise NotImplementedError

    def _map_lookup(self, ctx: Context) -> t.Any:
        if isinstance(ctx.default_map, dict) and self.name in ctx.default_map:
            return ctx.default_map[self.name]
        return _MISSING

    def _find_envvar(self, ctx: Context) -> t.Optional[t.Tuple[str, str]]:
        names = list(self.envvar)
        if isinstance(self, Option) and self.allow_from_autoenv and ctx.auto_envvar_prefix:
            parts = [ctx.auto_envvar_prefix]
            node: t.Optional[Context] = ctx
            chain = []
            while node is not None and node.parent is not None:
                chain.append(node.info_name or "")
                node = node.parent
            parts.extend(reversed(chain))
            parts.append(self.name)
            names.append("_".join(p.replace("-", "_").upper() for p in parts if p))
        for env_name in names:
            value = os.environ.get(env_name)
            if value:
                return env_name, value
        return None

    def _env_value(self, ctx: Context) -> t.Any:
        found = self._find_envvar(ctx)
        if found is None:
            return _MISSING
        occs = self._occs_from_string(found[1])
        if not occs:
            return _MISSING
        return self._deliver(ctx, occs)

    # -- value shaping ----------------------------------------------------

    def get_default(self, ctx: t.Optional[Context] = None) -> t.Any:
        if callable(self.default):
            return self.default()
        return self.default

    def _conv(self, ctx: t.Optional[Context], value: t.Any) -> t.Any:
        return self.type.convert(value, self, ctx)

    def _convert_occ(self, ctx: Context, occ: t.Any) -> t.Any:
        if isinstance(self.type, Tuple):
            return self.type.convert(occ, self, ctx)
        if self.nargs == 1:
            return self._conv(ctx, occ)
        return tuple(self._conv(ctx, x) for x in occ)

    def _deliver(self, ctx: Context, occs: t.List[t.Any]) -> t.Any:
        if self.multiple:
            return tuple(self._convert_occ(ctx, occ) for occ in occs)
        return self._convert_occ(ctx, occs[-1])

    def _occs_from_string(self, s: str) -> t.List[t.Any]:
        if self.nargs == 1 and not self.multiple:
            return [s]
        parts = self.type.split_envvar_value(s)
        if not parts:
            return []
        if self.nargs == 1:
            return parts
        if self.nargs == -1 or not self.multiple:
            return [tuple(parts)]
        size = self.nargs
        return [tuple(parts[i : i + size]) for i in range(0, len(parts), size)]

    def _occs_from_default(self, value: t.Any) -> t.List[t.Any]:
        if value is None:
            return []
        if isinstance(value, str):
            if self.multiple and self.nargs == 1:
                raise BadParameter(
                    "A bare string default needs an iterable (sequence) default.",
                    param=self,
                )
            if self.nargs == 1:
                return [value]
            return self._occs_from_string(value)
        if self.multiple:
            if not isinstance(value, (list, tuple)):
                raise BadParameter("The default needs an iterable (sequence) default.", param=self)
            if self.nargs == 1:
                return list(value)
            return [tuple(v) for v in value]
        if self.nargs != 1 or isinstance(self.type, Tuple):
            if not isinstance(value, (list, tuple)):
                return [value]
            return [tuple(value)] if value else []
        return [value]

    def _missing_value(self) -> t.Any:
        if self.multiple or self.nargs == -1:
            return ()
        return None

    # -- the value pipeline ------------------------------------------------

    def process(self, ctx: Context) -> t.Tuple[t.Any, ParameterSource]:
        """Resolve this parameter from its sources, convert it and run its callback."""
        raw = ctx._raw.get(self.name, [])
        cmdline = [occ for occ in raw if occ is not _PROMPT_MARK]
        flag_without_value = len(cmdline) != len(raw)
        value: t.Any = _MISSING
        source: t.Optional[ParameterSource] = None
        eager = self.name in ctx._eager_done

        if eager:
            value = ctx._eager_done[self.name]
            source = ParameterSource.COMMANDLINE
        elif cmdline:
            value = self._deliver(ctx, cmdline)
            source = ParameterSource.COMMANDLINE

        if source is None:
            env_value = self._env_value(ctx)
            if env_value is not _MISSING:
                value = env_value
                source = ParameterSource.ENVIRONMENT

        if source is None and self._wants_prompt(flag_without_value):
            mapped = self._map_lookup(ctx)
            default = mapped if mapped is not _MISSING else self.get_default(ctx)
            value = self._prompt_value(ctx, default)
            source = ParameterSource.PROMPT

        if source is None:
            mapped = self._map_lookup(ctx)
            if mapped is not _MISSING and mapped is not None:
                occs = self._occs_from_default(mapped)
                if occs:
                    value = self._deliver(ctx, occs)
                    source = ParameterSource.DEFAULT_MAP
            if source is None and self.default is not None:
                occs = self._occs_from_default(self.get_default(ctx))
                if occs:
                    value = self._deliver(ctx, occs)
                    source = ParameterSource.DEFAULT

        if value is _MISSING:
            if self.required:
                raise self._missing_error(ctx)
            value = self._missing_value()
            source = ParameterSource.DEFAULT

        if source is ParameterSource.COMMANDLINE and self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else None
            _warn_deprecated(self.param_type_name, self.get_error_hint(ctx), note)

        if self.callback is not None and not eager:
            try:
                value = self.callback(ctx, self, value)
            except BadParameter as e:
                if e.ctx is None:
                    e.ctx = ctx
                if e.param is None:
                    e.param = self
                raise
        return value, source


class Option(Parameter):
    """A named parameter, introduced by a prefix such as ``-`` or ``--``."""

    param_type_name = "option"

    def __init__(
        self,
        param_decls: t.Optional[t.Sequence[str]] = None,
        show_default: t.Any = None,
        prompt: t.Any = False,
        prompt_required: bool = True,
        hide_input: bool = False,
        confirmation_prompt: bool = False,
        is_flag: t.Optional[bool] = None,
        flag_value: t.Any = None,
        count: bool = False,
        allow_from_autoenv: bool = True,
        type: t.Any = None,
        help: t.Optional[str] = None,
        hidden: bool = False,
        show_choices: bool = True,
        show_envvar: bool = False,
        deprecated: t.Any = False,
        default: t.Any = None,
        required: bool = False,
        callback: t.Optional[t.Callable[..., t.Any]] = None,
        nargs: t.Optional[int] = None,
        multiple: bool = False,
        metavar: t.Optional[str] = None,
        expose_value: bool = True,
        is_eager: bool = False,
        envvar: t.Any = None,
        shell_complete: t.Optional[t.Callable[..., t.Any]] = None,
    ) -> None:
        self.opts, self.secondary_opts, dest = _parse_decls(list(param_decls or ()))
        if not self.opts and not self.secondary_opts:
            raise TypeError("An option needs at least one flag name.")
        if dest is None:
            dest = _infer_name(self.opts)
        if prompt and deprecated:
            raise TypeError("A deprecated option cannot use a prompt.")
        if count:
            is_flag = True
        if is_flag is None:
            is_flag = bool(self.secondary_opts) or isinstance(default, bool)
        auto_default = False
        if is_flag:
            if count:
                if default is None:
                    default = 0
                if flag_value is None:
                    flag_value = True
            else:
                if flag_value is None:
                    flag_value = True if self.secondary_opts else not bool(default)
                if default is None:
                    default = False
                    auto_default = True
        self.is_flag = bool(is_flag)
        self.count = count
        self.flag_value = flag_value
        self._optional_value = not self.is_flag and flag_value is not None
        self.prompt = prompt
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.show_choices = show_choices
        super().__init__(
            dest,
            type=type,
            default=default,
            required=required,
            callback=callback,
            nargs=1 if nargs is None else nargs,
            multiple=multiple,
            metavar=metavar,
            expose_value=expose_value,
            is_eager=is_eager,
            envvar=envvar,
            shell_complete=shell_complete,
            deprecated=deprecated,
            hidden=hidden,
            help=help,
            allow_from_autoenv=allow_from_autoenv,
            auto_default=auto_default,
        )
        if self.is_flag and self.nargs != 1:
            raise TypeError("A flag takes no more than one token.")

    def get_error_hint(self, ctx: t.Optional[Context]) -> str:
        return " / ".join(f"'{x}'" for x in self.opts + self.secondary_opts)

    def _missing_error(self, ctx: Context) -> MissingParameter:
        return MissingParameter(f"Missing option {self.get_error_hint(ctx)}.", ctx, self)

    def _flag_entries(self) -> t.List[t.Tuple[str, t.Any]]:
        if self.is_flag:
            if self.secondary_opts:
                return [(o, True) for o in self.opts] + [(s, False) for s in self.secondary_opts]
            return [(o, self.flag_value) for o in self.opts]
        return [(o, _VALUE) for o in self.opts]

    def get_opts_string(self) -> str:
        if self.secondary_opts:
            text = ", ".join(self.opts) + "/" + ", ".join(self.secondary_opts)
        else:
            text = ", ".join(self.opts)
        if not self.is_flag:
            text += " " + self.make_metavar()
        return text

    def make_metavar(self) -> str:
        if self.metavar is not None:
            return self.metavar
        base = self.type.get_metavar(self) or self.type.name.upper()
        if self.nargs > 1 and not isinstance(self.type, Tuple):
            return " ".join([base] * self.nargs)
        return base

    def _convert_occ(self, ctx: Context, occ: t.Any) -> t.Any:
        if self.is_flag:
            return occ
        return super()._convert_occ(ctx, occ)

    def _deliver(self, ctx: Context, occs: t.List[t.Any]) -> t.Any:
        if self.count:
            return len(occs)
        if self.is_flag:
            return occs[-1]
        return super()._deliver(ctx, occs)

    def _occs_from_default(self, value: t.Any) -> t.List[t.Any]:
        if self.count:
            return []
        return super()._occs_from_default(value)

    def _missing_value(self) -> t.Any:
        if self.count:
            return self.default if isinstance(self.default, int) else 0
        return super()._missing_value()

    def _env_value(self, ctx: Context) -> t.Any:
        if not self.is_flag:
            return super()._env_value(ctx)
        found = self._find_envvar(ctx)
        if found is None:
            return _MISSING
        name, text = found
        stripped = text.strip().lower()
        if isinstance(self.flag_value, bool) or self.flag_value is None:
            if stripped in TRUE_STRINGS:
                return True
            if stripped in FALSE_STRINGS or stripped == "":
                return False
            raise BadParameter(
                f"Environment variable {name!r} holds {text!r}, which is not a valid boolean.",
                ctx,
                self,
            )
        if text == str(self.flag_value):
            return self.flag_value
        if stripped in TRUE_STRINGS:
            return self.flag_value
        return _MISSING

    def _wants_prompt(self, flag_without_value: bool) -> bool:
        if not self.prompt:
            return False
        return flag_without_value or self.prompt_required

    def _prompt_value(self, ctx: Context, default: t.Any) -> t.Any:
        if isinstance(self.prompt, str):
            text = self.prompt
        else:
            text = self.name.replace("_", " ").capitalize()
        if callable(default):
            default = default()
        if self.is_flag:
            return _confirm(text, default=bool(default))
        return _prompt(
            text,
            default=None if default is _MISSING else default,
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            value_proc=lambda v: self._conv(ctx, v),
        )


class Argument(Parameter):
    """A positional parameter, bound in declaration order."""

    param_type_name = "argument"

    def __init__(
        self,
        param_decls: t.Optional[t.Sequence[str]] = None,
        required: t.Optional[bool] = None,
        type: t.Any = None,
        default: t.Any = None,
        nargs: t.Optional[int] = None,
        envvar: t.Any = None,
        deprecated: t.Any = False,
        help: t.Optional[str] = None,
        metavar: t.Optional[str] = None,
        callback: t.Optional[t.Callable[..., t.Any]] = None,
        expose_value: bool = True,
        is_eager: bool = False,
        hidden: bool = False,
        shell_complete: t.Optional[t.Callable[..., t.Any]] = None,
    ) -> None:
        decls = list(param_decls or ())
        if len(decls) != 1 or not decls[0] or decls[0][0] in PREFIX_CHARS:
            raise TypeError("An argument needs exactly one destination name.")
        nargs = 1 if nargs is None else nargs
        if required is None:
            required = False if nargs == -1 else default is None
        super().__init__(
            decls[0],
            type=type,
            default=default,
            required=required,
            callback=callback,
            nargs=nargs,
            metavar=metavar,
            expose_value=expose_value,
            is_eager=is_eager,
            envvar=envvar,
            shell_complete=shell_complete,
            deprecated=deprecated,
            hidden=hidden,
            help=help,
            allow_from_autoenv=False,
        )

    def get_error_hint(self, ctx: t.Optional[Context]) -> str:
        return f"'{self.name.upper()}'"

    def _missing_error(self, ctx: Context) -> MissingParameter:
        return MissingParameter(f"Missing argument {self.get_error_hint(ctx)}.", ctx, self)

    def make_metavar(self) -> str:
        if self.metavar is not None:
            return self.metavar
        base = self.name.upper()
        if self.nargs > 1:
            return " ".join([base] * self.nargs)
        return base

    def _min_tokens(self) -> int:
        if self.required and self.nargs > 0:
            return self.nargs
        return 0


class Command:
    """A callable unit that parses a slice of the command line."""

    allow_extra_args = False
    allow_interspersed_args = True
    ignore_unknown_options = False

    def __init__(
        self,
        name: t.Optional[str] = None,
        context_settings: t.Optional[t.Dict[str, t.Any]] = None,
        callback: t.Optional[t.Callable[..., t.Any]] = None,
        params: t.Optional[t.List[Parameter]] = None,
        help: t.Optional[str] = None,
        epilog: t.Optional[str] = None,
        short_help: t.Optional[str] = None,
        options_metavar: t.Optional[str] = "[OPTIONS]",
        add_help_option: bool = True,
        no_args_is_help: bool = False,
        hidden: bool = False,
        deprecated: t.Any = False,
    ) -> None:
        if name is None and callback is not None:
            name = _derive_name(getattr(callback, "__name__", "command"))
        self.name = name
        self.context_settings = dict(context_settings or {})
        self.callback = callback
        self.params: t.List[Parameter] = list(params or [])
        self.help = help
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = deprecated

    @property
    def arguments(self) -> t.List[Argument]:
        return [p for p in self.params if isinstance(p, Argument)]

    def __call__(self, *args: t.Any, **kwargs: t.Any) -> t.Any:
        return self.main(*args, **kwargs)

    # -- parameters and flags -----------------------------------------------

    def _help_param(self, ctx: Context) -> t.Optional[Option]:
        if not self.add_help_option:
            return None
        taken = {f for p in self.params if isinstance(p, Option) for f, _ in p._flag_entries()}
        names = [n for n in ctx.help_option_names if n not in taken]
        if not names:
            return None
        return Option(
            names,
            is_flag=True,
            is_eager=True,
            expose_value=False,
            callback=_help_callback,
            help="Show this message and exit.",
        )

    def get_params(self, ctx: Context) -> t.List[Parameter]:
        params = list(self.params)
        help_param = self._help_param(ctx)
        if help_param is not None:
            params.append(help_param)
        return params

    def _flag_map(self, ctx: Context) -> t.Dict[str, t.Tuple[Parameter, t.Any]]:
        mapping: t.Dict[str, t.Tuple[Parameter, t.Any]] = {}
        help_param = self._help_param(ctx)
        if help_param is not None:
            for flag, value in help_param._flag_entries():
                mapping[flag] = (help_param, value)
        for p in self.params:
            if isinstance(p, Option):
                for flag, value in p._flag_entries():
                    mapping[flag] = (p, value)
        return mapping

    # -- parsing -------------------------------------------------------------

    def _record(self, ctx: Context, param: Parameter, occ: t.Any) -> None:
        if param.is_eager:
            value = occ
            if param.callback is not None and not ctx.resilient_parsing:
                value = param.callback(ctx, param, occ)
            ctx._eager_done[param.name] = value
            return
        ctx._raw.setdefault(param.name, []).append(occ)

    def _lookup(
        self,
        ctx: Context,
        mapping: t.Dict[str, t.Tuple[Parameter, t.Any]],
        name: str,
    ) -> t.Optional[t.Tuple[Parameter, t.Any]]:
        if name in mapping:
            return mapping[name]
        normalize = ctx.token_normalize_func
        if normalize is not None:
            wanted = normalize(name)
            for key, entry in mapping.items():
                if normalize(key) == wanted:
                    return entry
        return None

    def _option_value(
        self,
        ctx: Context,
        param: Option,
        name: str,
        args: t.List[str],
        j: int,
        inline: t.Optional[str],
    ) -> t.Tuple[t.Any, int]:
        if inline is None and param._optional_value:
            if j < len(args) and not _looks_like_option(args[j]) and args[j] != "--":
                inline = args[j]
                j += 1
            else:
                return param.flag_value, j
        values: t.List[str] = []
        if inline is not None:
            values.append(inline)
        while len(values) < param.nargs and j < len(args):
            values.append(args[j])
            j += 1
        if len(values) < param.nargs:
            if param.prompt:
                return _PROMPT_MARK, j
            raise BadOptionUsage(f"Option '{name}' requires an argument.", ctx)
        occ = values[0] if param.nargs == 1 else tuple(values)
        return occ, j

    def _consume_option(
        self,
        ctx: Context,
        args: t.List[str],
        i: int,
        pos: t.List[t.Tuple[str, bool]],
        mapping: t.Dict[str, t.Tuple[Parameter, t.Any]],
    ) -> int:
        tok = args[i]
        whole_name = tok.partition("=")[0]
        if (len(tok) > 2 and tok[0] == tok[1]) or self._lookup(ctx, mapping, whole_name) is not None:
            name, eq, inline = tok.partition("=")
            entry = self._lookup(ctx, mapping, name)
            if entry is None:
                if ctx.ignore_unknown_options:
                    pos.append((tok, False))
                    return i + 1
                raise NoSuchOption(name, ctx=ctx)
            param, flag_value = entry
            if flag_value is not _VALUE:
                if eq:
                    raise BadOptionUsage(f"Option '{name}' does not take a value.", ctx)
                self._record(ctx, param, flag_value)
                return i + 1
            occ, nxt = self._option_value(ctx, param, name, args, i + 1, inline if eq else None)
            self._record(ctx, param, occ)
            return nxt

        prefix = tok[0]
        chars = tok[1:]
        k = 0
        while k < len(chars):
            flag = prefix + chars[k]
            entry = self._lookup(ctx, mapping, flag)
            if entry is None:
                if ctx.ignore_unknown_options:
                    pos.append((tok if k == 0 else prefix + chars[k:], False))
                    return i + 1
                raise NoSuchOption(flag, ctx=ctx)
            param, flag_value = entry
            if flag_value is not _VALUE:
                self._record(ctx, param, flag_value)
                k += 1
                continue
            inline = chars[k + 1 :] or None
            occ, nxt = self._option_value(ctx, param, flag, args, i + 1, inline)
            self._record(ctx, param, occ)
            return nxt
        return i + 1

    def _parse_loop(
        self, ctx: Context, args: t.List[str], chained: bool
    ) -> t.Tuple[t.List[t.Tuple[str, bool]], t.List[str]]:
        mapping = self._flag_map(ctx)
        pos: t.List[t.Tuple[str, bool]] = []
        rest: t.List[str] = []
        arguments = self.arguments
        fixed = sum(a.nargs for a in arguments if a.nargs != -1)
        variadic = any(a.nargs == -1 for a in arguments)
        stops_at_positional = isinstance(self, Group) or chained
        stop_opts = False
        literal_after_dd = False
        i = 0
        n = len(args)
        while i < n:
            tok = args[i]
            if not stop_opts and tok == "--":
                stop_opts = True
                literal_after_dd = True
                i += 1
                continue
            if not stop_opts and len(tok) > 1 and tok[0] in _prefix_chars(mapping):
                i = self._consume_option(ctx, args, i, pos, mapping)
                continue
            if stops_at_positional and not variadic and len(pos) >= fixed:
                rest = args[i:]
                break
            if not ctx.allow_interspersed_args:
                stop_opts = True
            pos.append((tok, literal_after_dd))
            i += 1
        return pos, rest

    def _bind_arguments(self, ctx: Context, pos: t.List[t.Tuple[str, bool]]) -> None:
        arguments = self.arguments
        idx = 0
        for k, arg in enumerate(arguments):
            later = sum(a._min_tokens() for a in arguments[k + 1 :])
            avail = len(pos) - idx - later
            take = max(avail, 0) if arg.nargs == -1 else min(arg.nargs, max(avail, 0))
            if take:
                chunk = [tok for tok, _ in pos[idx : idx + take]]
                idx += take
                occ = chunk[0] if arg.nargs == 1 else tuple(chunk)
                ctx._raw.setdefault(arg.name, []).append(occ)
        leftover = [tok for tok, _ in pos[idx:]]
        if leftover:
            if ctx.allow_extra_args:
                ctx.args = leftover
            else:
                noun = "argument" if len(leftover) == 1 else "arguments"
                raise UsageError(
                    f"Got unexpected extra {noun} ({' '.join(leftover)})",
                    ctx,
                )

    def parse_args(self, ctx: Context, args: t.List[str], chained: bool = False) -> t.List[str]:
        """Parse tokens into raw values; return the tokens this command did not take."""
        pos, rest = self._parse_loop(ctx, args, chained)
        self._bind_arguments(ctx, pos)
        return rest

    # -- processing and contexts ---------------------------------------------

    def _process_params(self, ctx: Context) -> None:
        best: t.Dict[str, t.Tuple[int, t.Any, ParameterSource]] = {}
        for p in self.params:
            value, source = p.process(ctx)
            ctx.params[p.name] = value
            ctx._sources[p.name] = source
            rank = _RANK[source]
            if source is ParameterSource.DEFAULT and p.auto_default:
                rank = 0
            if p.name not in best or rank >= best[p.name][0]:
                best[p.name] = (rank, value, source)
        for name, (_, value, source) in best.items():
            ctx.params[name] = value
            ctx._sources[name] = source

    def make_context(
        self,
        info_name: t.Optional[str],
        args: t.List[str],
        parent: t.Optional[Context] = None,
        chained: bool = False,
        **extra: t.Any,
    ) -> Context:
        settings = dict(self.context_settings)
        settings.update(extra)
        ctx = Context(self, info_name=info_name, parent=parent, **settings)
        try:
            if not args and self.no_args_is_help and not ctx.resilient_parsing:
                raise NoArgsIsHelp(ctx)
            ctx._rest = self.parse_args(ctx, list(args), chained)
            if ctx._rest and ctx.allow_interspersed_args and isinstance(self, Group):
                ctx._rest = self._absorb_trailing_options(ctx, ctx._rest)
            self._process_params(ctx)
        except BaseException:
            ctx.close()
            raise
        return ctx

    def _callback_kwargs(self, ctx: Context) -> t.Dict[str, t.Any]:
        return {p.name: ctx.params.get(p.name) for p in self.params if p.expose_value}

    def invoke(self, ctx: Context) -> t.Any:
        try:
            if self.deprecated:
                note = self.deprecated if isinstance(self.deprecated, str) else None
                _warn_deprecated("command", f"'{ctx.command_path}'", note)
            with ctx:
                if self.callback is None:
                    return None
                return self.callback(**self._callback_kwargs(ctx))
        finally:
            ctx.close()

    def get_short_help_str(self, limit: int = 45) -> str:
        if self.short_help:
            text = self.short_help
        else:
            from .formatting import first_sentence, clean_help

            text = first_sentence(clean_help(self.help))
        text = " ".join(text.split())
        if len(text) > limit:
            cut = text[: limit - 3]
            if " " in cut:
                cut = cut.rsplit(" ", 1)[0]
            text = cut + "..."
        return text

    def main(
        self,
        args: t.Optional[t.Sequence[str]] = None,
        prog_name: t.Optional[str] = None,
        complete_var: t.Optional[str] = None,
        standalone_mode: bool = True,
        **extra: t.Any,
    ) -> t.Any:
        """Run the command on a token list, handling failures as the process would."""
        argv = list(args) if args is not None else sys.argv[1:]
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else "main"
        if complete_var is None:
            complete_var = "_" + prog_name.replace("-", "_").upper() + "_COMPLETE"
        instruction = os.environ.get(complete_var)
        if instruction:
            from .shell_completion import run_completion

            ok = run_completion(self, prog_name, instruction, argv)
            if not ok:
                sys.stderr.write(f"Unknown completion instruction: {instruction!r}\n")
                if standalone_mode:
                    sys.exit(1)
                return None
            if standalone_mode:
                sys.exit(0)
            return None

        try:
            ctx = self.make_context(prog_name, argv, **extra)
            rv = self.invoke(ctx)
        except (EOFError, KeyboardInterrupt) as e:
            if standalone_mode:
                echo("Aborted!", err=True)
                sys.exit(1)
            raise Abort() from e
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return e.exit_code
        except Abort:
            if standalone_mode:
                echo("Aborted!", err=True)
                sys.exit(1)
            raise
        except FileError as e:
            if standalone_mode:
                e.show()
                sys.exit(e.exit_code)
            raise
        except OptlynError as e:
            if standalone_mode:
                e.show()
                sys.exit(e.exit_code)
            raise
        if standalone_mode:
            sys.exit(0)
        return rv


def _looks_like_option(tok: str) -> bool:
    return len(tok) > 1 and tok[0] in PREFIX_CHARS


def _prefix_chars(mapping: t.Dict[str, t.Any]) -> t.Set[str]:
    chars = {"-"}
    for flag in mapping:
        if flag:
            chars.add(flag[0])
    return chars


def _derive_name(func_name: str) -> str:
    name = func_name.lower().replace("_", "-")
    for suffix in ("command", "cmd", "group", "grp"):
        if name.endswith("-" + suffix) and len(name) > len(suffix) + 1:
            return name[: -len(suffix) - 1]
    return name


class Group(Command):
    """A command that dispatches to named subcommands."""

    allow_interspersed_args = False

    def __init__(
        self,
        name: t.Optional[str] = None,
        commands: t.Optional[t.Dict[str, Command]] = None,
        invoke_without_command: bool = False,
        no_args_is_help: t.Optional[bool] = None,
        subcommand_metavar: t.Optional[str] = None,
        chain: bool = False,
        result_callback: t.Optional[t.Callable[..., t.Any]] = None,
        **kwargs: t.Any,
    ) -> None:
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        super().__init__(name=name, no_args_is_help=no_args_is_help, **kwargs)
        self.commands: t.Dict[str, Command] = dict(commands or {})
        self.invoke_without_command = invoke_without_command
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback

    def add_command(self, cmd: Command, name: t.Optional[str] = None) -> None:
        name = name or cmd.name
        if name is None:
            raise TypeError("A command needs a name to be added to a group.")
        if self.chain and isinstance(cmd, Group):
            raise TypeError("Groups cannot be nested under a chaining group.")
        self.commands[name] = cmd

    def command(self, *args: t.Any, **kwargs: t.Any) -> t.Callable[[t.Callable[..., t.Any]], Command]:
        def decorator(f: t.Callable[..., t.Any]) -> Command:
            cmd = command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args: t.Any, **kwargs: t.Any) -> t.Callable[[t.Callable[..., t.Any]], "Group"]:
        def decorator(f: t.Callable[..., t.Any]) -> "Group":
            cmd = group(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self) -> t.Callable[[t.Callable[..., t.Any]], t.Callable[..., t.Any]]:
        def decorator(f: t.Callable[..., t.Any]) -> t.Callable[..., t.Any]:
            self._result_callback = f
            return f

        return decorator

    def list_commands(self, ctx: Context) -> t.List[str]:
        return sorted(self.commands)

    def get_command(self, ctx: Context, cmd_name: str) -> t.Optional[Command]:
        return self.commands.get(cmd_name)

    def resolve_command(self, ctx: Context, name: str) -> t.Optional[Command]:
        cmd = self.get_command(ctx, name)
        normalize = ctx.token_normalize_func
        if cmd is None and normalize is not None:
            wanted = normalize(name)
            for candidate in self.list_commands(ctx):
                if normalize(candidate) == wanted:
                    return self.get_command(ctx, candidate)
        return cmd

    def make_context(
        self,
        info_name: t.Optional[str],
        args: t.List[str],
        parent: t.Optional[Context] = None,
        chained: bool = False,
        **extra: t.Any,
    ) -> Context:
        ctx = super().make_context(info_name, args, parent, chained, **extra)
        try:
            rest = ctx._rest
            if rest:
                cmd = self.resolve_command(ctx, rest[0])
                if cmd is None:
                    raise NoSuchCommand(rest[0], ctx=ctx)
                ctx.invoked_subcommand = "*" if self.chain else cmd.name
                ctx._subcommand = (cmd, rest)
            elif not self.invoke_without_command:
                raise MissingCommand(ctx)
        except BaseException:
            ctx.close()
            raise
        return ctx

    def _absorb_trailing_options(self, ctx: Context, rest: t.List[str]) -> t.List[str]:
        """With interspersed args, group options after the subcommand name belong to the group."""
        mapping = self._flag_map(ctx)
        head, tail = rest[:1], rest[1:]
        kept: t.List[str] = []
        pos: t.List[t.Tuple[str, bool]] = []
        i = 0
        while i < len(tail):
            tok = tail[i]
            if tok == "--":
                kept.extend(tail[i:])
                break
            if len(tok) > 1 and tok[0] in _prefix_chars(mapping):
                if len(tok) > 2 and tok[0] == tok[1]:
                    known = self._lookup(ctx, mapping, tok.partition("=")[0]) is not None
                else:
                    known = self._lookup(ctx, mapping, tok[:2]) is not None
                if known:
                    i = self._consume_option(ctx, tail, i, pos, mapping)
                    continue
            kept.append(tok)
            i += 1
        return head + kept

    def _run_callback(self, ctx: Context) -> t.Any:
        if self.callback is None:
            return None
        return self.callback(**self._callback_kwargs(ctx))

    def _finish(self, ctx: Context, value: t.Any) -> t.Any:
        if self._result_callback is None:
            return value
        return self._result_callback(value, **self._callback_kwargs(ctx))

    def invoke(self, ctx: Context) -> t.Any:
        try:
            if self.deprecated:
                note = self.deprecated if isinstance(self.deprecated, str) else None
                _warn_deprecated("command", f"'{ctx.command_path}'", note)
            with ctx:
                if self.chain:
                    self._run_callback(ctx)
                    values: t.List[t.Any] = []
                    tokens = ctx._subcommand[1] if ctx._subcommand else []
                    while tokens:
                        cmd = self.resolve_command(ctx, tokens[0])
                        if cmd is None:
                            raise NoSuchCommand(tokens[0], ctx=ctx)
                        sub_ctx = cmd.make_context(tokens[0], tokens[1:], parent=ctx, chained=True)
                        tokens = sub_ctx._rest
                        values.append(cmd.invoke(sub_ctx))
                    return self._finish(ctx, values)

                rv = self._run_callback(ctx)
                if ctx._subcommand is None:
                    return self._finish(ctx, rv)
                cmd, tokens = ctx._subcommand
                sub_ctx = cmd.make_context(tokens[0], tokens[1:], parent=ctx)
                return self._finish(ctx, cmd.invoke(sub_ctx))
        finally:
            ctx.close()


class CommandCollection(Group):
    """A group whose subcommands are the union of several source groups."""

    def __init__(
        self,
        name: t.Optional[str] = None,
        sources: t.Optional[t.List[Group]] = None,
        **kwargs: t.Any,
    ) -> None:
        super().__init__(name, **kwargs)
        self.sources: t.List[Group] = list(sources or [])

    def list_commands(self, ctx: Context) -> t.List[str]:
        names: t.Set[str] = set(self.commands)
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx: Context, cmd_name: str) -> t.Optional[Command]:
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None


# -- declaration decorators ---------------------------------------------------


def _param_memo(f: t.Any, param: Parameter) -> None:
    params = getattr(f, "__optlyn_params__", None)
    if params is None:
        params = []
        f.__optlyn_params__ = params
    params.append(param)


def _pop_params(f: t.Any) -> t.List[Parameter]:
    params = getattr(f, "__optlyn_params__", None)
    if params is None:
        return []
    del f.__optlyn_params__
    return list(reversed(params))


def command(
    name: t.Any = None,
    cls: t.Optional[t.Type[Command]] = None,
    **attrs: t.Any,
) -> t.Any:
    """Turn a function into a ``Command``; usable as ``@command`` or ``@command()``."""
    if callable(name) and not isinstance(name, str):
        return command(None, cls, **attrs)(name)

    def decorator(f: t.Callable[..., t.Any]) -> Command:
        params = _pop_params(f)
        cls_ = cls or Command
        if attrs.get("help") is None:
            attrs["help"] = f.__doc__
        cmd_name = name or _derive_name(f.__name__)
        return cls_(name=cmd_name, callback=f, params=params, **attrs)

    return decorator


def group(
    name: t.Any = None,
    cls: t.Optional[t.Type[Group]] = None,
    **attrs: t.Any,
) -> t.Any:
    """Turn a function into a ``Group``; usable as ``@group`` or ``@group()``."""
    if callable(name) and not isinstance(name, str):
        return group(None, cls, **attrs)(name)

    def decorator(f: t.Callable[..., t.Any]) -> Group:
        params = _pop_params(f)
        cls_ = cls or Group
        if attrs.get("help") is None:
            attrs["help"] = f.__doc__
        cmd_name = name or _derive_name(f.__name__)
        return cls_(name=cmd_name, callback=f, params=params, **attrs)

    return decorator


def option(*param_decls: str, cls: t.Optional[t.Type[Option]] = None, **attrs: t.Any) -> t.Callable[[t.Any], t.Any]:
    """Attach an option to a function (applied before ``command``/``group``)."""
    klass = cls or Option

    def decorator(f: t.Any) -> t.Any:
        _param_memo(f, klass(list(param_decls), **attrs))
        return f

    return decorator


def argument(*param_decls: str, cls: t.Optional[t.Type[Argument]] = None, **attrs: t.Any) -> t.Callable[[t.Any], t.Any]:
    """Attach a positional argument to a function."""
    klass = cls or Argument

    def decorator(f: t.Any) -> t.Any:
        _param_memo(f, klass(list(param_decls), **attrs))
        return f

    return decorator


def help_option(*param_decls: str, **kwargs: t.Any) -> t.Callable[[t.Any], t.Any]:
    """Attach an extra eager help flag; it prints help and exits like the automatic one."""
    names = list(param_decls) or ["--help"]
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("callback", _help_callback)
    return option(*names, **kwargs)


def _detect_version(package_name: str) -> str:
    from importlib import metadata

    try:
        return metadata.version(package_name)
    except metadata.PackageNotFoundError:
        pass
    try:
        providers = metadata.packages_distributions().get(package_name, [])
    except Exception:
        providers = []
    for dist_name in providers:
        try:
            return metadata.version(dist_name)
        except metadata.PackageNotFoundError:
            continue
    raise RuntimeError(f"{package_name!r} is not an installed distribution or import name.")


def version_option(
    version: t.Optional[str] = None,
    *param_decls: str,
    package_name: t.Optional[str] = None,
    prog_name: t.Optional[str] = None,
    message: t.Optional[str] = None,
    **kwargs: t.Any,
) -> t.Callable[[t.Any], t.Any]:
    """Attach an eager ``--version`` flag that prints the identity and exits."""
    names = list(param_decls) or ["--version"]

    def callback(ctx: Context, param: Parameter, value: t.Any) -> None:
        if not value or ctx.resilient_parsing:
            return
        ver = version
        if ver is None:
            if package_name is None:
                ver = "unknown"
            else:
                ver = _detect_version(package_name)
        prog = prog_name or ctx.find_root().info_name
        template = message or "%(prog)s, version %(version)s"
        echo(template % {"prog": prog, "version": ver}, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("help", "Show the version and exit.")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs["callback"] = callback
    return option(*names, **kwargs)


def custom_version_option(
    callback_func: t.Callable[[Context], str],
    *param_decls: str,
    **kwargs: t.Any,
) -> t.Callable[[t.Any], t.Any]:
    """Attach an eager version flag whose whole identity is ``callback_func(ctx)``."""
    names = list(param_decls) or ["--version"]

    def callback(ctx: Context, param: Parameter, value: t.Any) -> None:
        if not value or ctx.resilient_parsing:
            return
        echo(callback_func(ctx), color=ctx.color)
        ctx.exit()

    kwargs.setdefault("help", "Show the version and exit.")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs["callback"] = callback
    return option(*names, **kwargs)


def password_option(*param_decls: str, **kwargs: t.Any) -> t.Callable[[t.Any], t.Any]:
    """A hidden, confirmed prompt option (default flag ``--password``)."""
    names = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    return option(*names, **kwargs)


def confirmation_option(*param_decls: str, **kwargs: t.Any) -> t.Callable[[t.Any], t.Any]:
    """A yes-flag that asks when omitted and aborts when the user declines."""
    names = list(param_decls) or ["--yes"]
    question = kwargs.pop("prompt", "Do you want to continue?")

    def callback(ctx: Context, param: Parameter, value: t.Any) -> t.Any:
        if ctx.resilient_parsing or value:
            return value
        _confirm(question, default=False, abort=True)
        return True

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs["callback"] = callback
    return option(*names, **kwargs)


def pass_context(f: t.Callable[..., t.Any]) -> t.Callable[..., t.Any]:
    """Pass the current context as the first argument."""

    def new_func(*args: t.Any, **kwargs: t.Any) -> t.Any:
        return f(get_current_context(), *args, **kwargs)

    return update_wrapper(new_func, f)


def pass_obj(f: t.Callable[..., t.Any]) -> t.Callable[..., t.Any]:
    """Pass the current context's author object as the first argument."""

    def new_func(*args: t.Any, **kwargs: t.Any) -> t.Any:
        return f(get_current_context().obj, *args, **kwargs)

    return update_wrapper(new_func, f)


def make_pass_decorator(object_type: t.Type[t.Any], ensure: bool = False) -> t.Callable[[t.Any], t.Any]:
    """Pass the nearest author object of ``object_type`` (created if ``ensure``)."""

    def decorator(f: t.Callable[..., t.Any]) -> t.Callable[..., t.Any]:
        def new_func(*args: t.Any, **kwargs: t.Any) -> t.Any:
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            return f(obj, *args, **kwargs)

        return update_wrapper(new_func, f)

    return decorator
