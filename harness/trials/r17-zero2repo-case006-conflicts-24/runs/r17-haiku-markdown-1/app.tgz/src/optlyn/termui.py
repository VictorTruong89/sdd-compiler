"""Terminal helpers: echo, styling, prompts, pager, progress, and launching."""

import contextlib
import getpass
import io
import os
import shlex
import subprocess
import sys
import tempfile
import time
import typing as t

from .exceptions import Abort, BadParameter
from .utils import format_filename, is_interactive, stream_isatty, strip_ansi

_COLOR_CODES = {
    "black": 30,
    "red": 31,
    "green": 32,
    "yellow": 33,
    "blue": 34,
    "magenta": 35,
    "cyan": 36,
    "white": 37,
    "reset": 39,
    "bright_black": 90,
    "bright_red": 91,
    "bright_green": 92,
    "bright_yellow": 93,
    "bright_blue": 94,
    "bright_magenta": 95,
    "bright_cyan": 96,
    "bright_white": 97,
}

_STYLE_CODES = {
    "bold": 1,
    "dim": 2,
    "italic": 3,
    "underline": 4,
    "blink": 5,
    "reverse": 7,
    "strikethrough": 9,
    "overline": 53,
}


def _current_color() -> t.Optional[bool]:
    from .core import get_current_context

    ctx = get_current_context(silent=True)
    return None if ctx is None else ctx.color


def echo(
    message: t.Any = None,
    file: t.Optional[t.IO[t.Any]] = None,
    nl: bool = True,
    err: bool = False,
    color: t.Optional[bool] = None,
) -> None:
    """Write text or bytes, stripping styles when the stream is not a terminal."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if color is None:
        color = _current_color()
    if message is None:
        message = ""
    if isinstance(message, (bytes, bytearray)):
        data = bytes(message) + (b"\n" if nl else b"")
        buffer = getattr(file, "buffer", None)
        if buffer is None:
            file.write(data.decode("utf-8", "replace"))
            file.flush()
            return
        file.flush()
        buffer.write(data)
        buffer.flush()
        return
    text = str(message)
    if nl:
        text += "\n"
    keep_styles = color if color is not None else stream_isatty(file)
    if not keep_styles:
        text = strip_ansi(text)
    try:
        file.write(text)
    except UnicodeEncodeError:
        buffer = getattr(file, "buffer", None)
        if buffer is None:
            raise
        file.flush()
        buffer.write(text.encode("utf-8"))
        buffer.flush()
        return
    file.flush()


_echo = echo


def _ansi_color(color: t.Any, background: bool) -> str:
    offset = 10 if background else 0
    if isinstance(color, bool):
        raise TypeError(f"Invalid color {color!r}.")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise TypeError(f"Invalid color {color!r}.")
        return f"{48 if background else 38};5;{color}"
    if isinstance(color, str):
        if color not in _COLOR_CODES:
            raise TypeError(f"Unknown color {color!r}.")
        code = _COLOR_CODES[color]
        if color == "reset":
            return str(49 if background else 39)
        return str(code + offset)
    if isinstance(color, (list, tuple)) and len(color) == 3:
        for part in color:
            if not isinstance(part, int) or isinstance(part, bool) or not 0 <= part <= 255:
                raise TypeError(f"Invalid color {color!r}.")
        return f"{48 if background else 38};2;{color[0]};{color[1]};{color[2]}"
    raise TypeError(f"Invalid color {color!r}.")


def style(
    text: t.Any,
    fg: t.Any = None,
    bg: t.Any = None,
    bold: t.Optional[bool] = None,
    dim: t.Optional[bool] = None,
    underline: t.Optional[bool] = None,
    overline: t.Optional[bool] = None,
    italic: t.Optional[bool] = None,
    blink: t.Optional[bool] = None,
    reverse: t.Optional[bool] = None,
    strikethrough: t.Optional[bool] = None,
    reset: bool = True,
) -> str:
    """Wrap text in ANSI SGR sequences. Invalid colors raise TypeError."""
    codes: t.List[str] = []
    if fg is not None:
        codes.append(_ansi_color(fg, background=False))
    if bg is not None:
        codes.append(_ansi_color(bg, background=True))
    switches = {
        "bold": bold,
        "dim": dim,
        "underline": underline,
        "overline": overline,
        "italic": italic,
        "blink": blink,
        "reverse": reverse,
        "strikethrough": strikethrough,
    }
    for name, enabled in switches.items():
        if enabled is not None and enabled is not False:
            codes.append(str(_STYLE_CODES[name]))
    text = str(text)
    if not codes:
        return text
    prefix = "\033[" + ";".join(codes) + "m"
    return prefix + text + ("\033[0m" if reset else "")


def secho(
    message: t.Any = None,
    file: t.Optional[t.IO[t.Any]] = None,
    nl: bool = True,
    err: bool = False,
    color: t.Optional[bool] = None,
    **styles: t.Any,
) -> None:
    """Style the message and echo it in one step."""
    if message is not None and styles:
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


def unstyle(text: str) -> str:
    return strip_ansi(text)


def _read_line(hide_input: bool) -> str:
    stream = sys.stdin
    if hide_input and stream_isatty(stream):
        try:
            return getpass.getpass("")
        except EOFError as e:
            raise Abort() from e
    line = stream.readline()
    if not line:
        raise Abort()
    value = line.rstrip("\r\n")
    if not hide_input and getattr(stream, "_optlyn_testing", False) and not getattr(stream, "echo_stdin", False):
        echo(value)
    return value


def prompt(
    text: str,
    default: t.Any = None,
    hide_input: bool = False,
    confirmation_prompt: bool = False,
    type: t.Any = None,
    value_proc: t.Optional[t.Callable[[t.Any], t.Any]] = None,
    prompt_suffix: str = ": ",
    show_default: bool = True,
    err: bool = False,
    show_choices: bool = True,
) -> t.Any:
    """Ask for a value and convert it; invalid answers are asked again."""
    from .param_types import convert_type

    if value_proc is None:
        ty = convert_type(type, default if not callable(default) else None)
        value_proc = lambda v: ty.convert(v, None, None)  # noqa: E731
    shown = text
    if default is not None and show_default:
        shown_default = default() if callable(default) else default
        shown = f"{text} [{shown_default}]"
    while True:
        echo(shown + prompt_suffix, nl=False, err=err)
        value: t.Any = _read_line(hide_input)
        if value == "":
            if default is None:
                continue
            value = default() if callable(default) else default
        elif confirmation_prompt:
            echo("Repeat for confirmation" + prompt_suffix, nl=False, err=err)
            second = _read_line(hide_input)
            if second != value:
                echo("Error: the two entered values do not match", err=True)
                continue
        try:
            return value_proc(value)
        except BadParameter as e:
            echo(f"Error: {e.format_message()}", err=True)


def confirm(
    text: str,
    default: bool = False,
    abort: bool = False,
    prompt_suffix: str = ": ",
    show_default: bool = True,
    err: bool = False,
) -> bool:
    """Ask a yes/no question. ``abort=True`` raises Abort on a no."""
    if show_default:
        choices = "[Y/n]" if default else "[y/N]"
        question = f"{text} {choices}{prompt_suffix}"
    else:
        question = text + prompt_suffix
    while True:
        echo(question, nl=False, err=err)
        answer = _read_line(False).strip().lower()
        if answer == "":
            result = default
            break
        if answer in ("y", "yes"):
            result = True
            break
        if answer in ("n", "no"):
            result = False
            break
        echo("Error: invalid input", err=True)
    if abort and not result:
        raise Abort()
    return result


def getchar(echo: bool = False) -> str:
    """Read one character from the controlling terminal, not from a pipe."""
    ch = ""
    fd = None
    try:
        fd = os.open("/dev/tty", os.O_RDONLY)
    except OSError:
        fd = None
    if fd is None:
        ch = sys.stdin.read(1)
    else:
        try:
            import termios
            import tty

            old = termios.tcgetattr(fd)
            try:
                tty.setraw(fd)
                ch = os.read(fd, 1).decode("utf-8", "replace")
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
        finally:
            os.close(fd)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch in ("\x04", "\x1a", ""):
        raise EOFError()
    if echo:
        _echo(ch, nl=False)
    return ch


def pause(info: t.Optional[str] = None, err: bool = False) -> None:
    """Print a message and wait for a key when the session is interactive."""
    if info is None:
        info = "Press any key to continue..."
    echo(info, nl=False, err=err)
    if is_interactive():
        try:
            getchar()
        except (KeyboardInterrupt, EOFError):
            pass
    echo("", err=err)


def edit(
    text: t.Optional[t.AnyStr] = None,
    editor: t.Optional[str] = None,
    env: t.Optional[t.Mapping[str, str]] = None,
    require_save: bool = True,
    extension: str = ".txt",
    filename: t.Optional[str] = None,
) -> t.Optional[str]:
    """Open an editor on text, or on a file; returns the saved text when editing a string."""
    command = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR")
    if not command:
        command = "notepad" if sys.platform == "win32" else "vi"
    args = shlex.split(command)
    run_env = None
    if env:
        run_env = dict(os.environ)
        run_env.update(env)
    if filename is not None:
        subprocess.call(args + [filename], env=run_env)
        return None
    content = text or ""
    if isinstance(content, bytes):
        content = content.decode("utf-8")
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(content)
        subprocess.call(args + [path], env=run_env)
        with open(path, encoding="utf-8", newline="") as f:
            new_content = f.read()
    finally:
        os.remove(path)
    if require_save and new_content == content:
        return None
    return new_content


def launch(url: str, wait: bool = False, locate: bool = False) -> int:
    """Open a URL or file with the default application."""
    if sys.platform == "win32":
        os.startfile(url)  # type: ignore[attr-defined]
        return 0
    if sys.platform == "darwin":
        command = ["open"]
        if locate:
            command.append("-R")
    else:
        command = ["xdg-open"]
        if locate:
            url = os.path.dirname(url) or "."
    command.append(url)
    try:
        proc = subprocess.Popen(command)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0


def clear() -> None:
    """Clear the visible terminal; does nothing when not on a terminal."""
    if not stream_isatty(sys.stdout):
        return
    echo("\033[2J\033[H", nl=False)


def _default_pager() -> str:
    command = os.environ.get("PAGER")
    if command:
        return command
    for candidate in ("less", "more"):
        if _which(candidate):
            return candidate
    return ""


def _which(name: str) -> t.Optional[str]:
    import shutil

    return shutil.which(name)


def echo_via_pager(text_or_generator: t.Any, color: t.Optional[bool] = None) -> None:
    """Write long text through a pager when the session is interactive."""
    if callable(text_or_generator):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        chunks: t.Iterable[str] = [text_or_generator]
    else:
        chunks = text_or_generator
    if not is_interactive():
        for chunk in chunks:
            echo(chunk, nl=False, color=bool(color))
        return
    command = _default_pager()
    if not command:
        for chunk in chunks:
            echo(chunk, nl=False, color=True if color is None else color)
        return
    proc = subprocess.Popen(shlex.split(command), stdin=subprocess.PIPE)
    try:
        for chunk in chunks:
            data = chunk if color else strip_ansi(chunk)
            proc.stdin.write(data.encode("utf-8", "replace"))
            proc.stdin.flush()
    except BrokenPipeError:
        pass
    finally:
        try:
            proc.stdin.close()
        except BrokenPipeError:
            pass
        proc.wait()


@contextlib.contextmanager
def get_pager_file(color: t.Optional[bool] = None) -> t.Iterator[t.TextIO]:
    """Yield a writable text stream that goes through the pager when interactive."""
    if not is_interactive() or not _default_pager():
        yield _NonClosing(sys.stdout)
        return
    proc = subprocess.Popen(shlex.split(_default_pager()), stdin=subprocess.PIPE)
    stream = io.TextIOWrapper(proc.stdin, encoding="utf-8", errors="replace", write_through=True)
    try:
        yield stream
    finally:
        try:
            stream.close()
        except BrokenPipeError:
            pass
        proc.wait()


class _NonClosing:
    def __init__(self, stream: t.Any) -> None:
        self._stream = stream

    def __getattr__(self, name: str) -> t.Any:
        return getattr(self._stream, name)

    def close(self) -> None:
        pass


class ProgressBar:
    """Shows progress for an iterable or an explicit length; always visits every item."""

    def __init__(
        self,
        iterable: t.Optional[t.Iterable[t.Any]],
        length: t.Optional[int],
        label: t.Optional[str],
        hidden: bool,
    ) -> None:
        self.iterable = iterable
        if length is None and iterable is not None and hasattr(iterable, "__len__"):
            length = len(iterable)  # type: ignore[arg-type]
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.pos = 0
        self.start = time.monotonic()
        self.is_tty = stream_isatty(sys.stdout)
        self._width = 30

    def _eta_text(self) -> str:
        if not self.length or self.pos <= 0:
            return ""
        elapsed = time.monotonic() - self.start
        remaining = elapsed / self.pos * max(self.length - self.pos, 0)
        return f" eta {int(remaining)}s"

    def render(self) -> None:
        if self.hidden or not self.is_tty:
            return
        if self.length:
            filled = int(self._width * min(self.pos, self.length) / self.length)
            bar = "#" * filled + "-" * (self._width - filled)
            line = f"\r{self.label} [{bar}] {self.pos}/{self.length}{self._eta_text()}"
        else:
            line = f"\r{self.label} {self.pos}"
        sys.stdout.write(line)
        sys.stdout.flush()

    def update(self, n_steps: int) -> None:
        self.pos += n_steps
        self.render()

    def __iter__(self) -> t.Iterator[t.Any]:
        if self.iterable is None:
            raise TypeError("A progress bar without an iterable cannot be iterated.")
        self.render()
        for item in self.iterable:
            yield item
            self.update(1)

    def _enter(self) -> None:
        if not self.hidden and not self.is_tty and self.label:
            echo(self.label)

    def _finish(self) -> None:
        if self.hidden or not self.is_tty:
            return
        echo("")


@contextlib.contextmanager
def progressbar(
    iterable: t.Optional[t.Iterable[t.Any]] = None,
    length: t.Optional[int] = None,
    label: t.Optional[str] = None,
    hidden: bool = False,
    **options: t.Any,
) -> t.Iterator[ProgressBar]:
    bar = ProgressBar(iterable, length, label, hidden)
    bar._enter()
    try:
        yield bar
    finally:
        bar._finish()
