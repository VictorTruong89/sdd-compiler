"""Parameter types: conversion of command-line tokens into Python values."""

import datetime as dt
import enum
import os
import pathlib
import stat
import typing as t
import uuid

from .exceptions import BadParameter
from .utils import format_filename, open_file

TRUE_STRINGS = frozenset(("1", "true", "t", "yes", "y", "on"))
FALSE_STRINGS = frozenset(("0", "false", "f", "no", "n", "off"))


class ParamType:
    """Base class for parameter types.

    Subclasses set ``name`` and implement ``convert(value, param, ctx)``,
    which refuses invalid input by raising ``BadParameter``.
    """

    name = "text"
    envvar_list_splitter: t.Optional[str] = None

    def __call__(self, value: t.Any, param: t.Any = None, ctx: t.Any = None) -> t.Any:
        return self.convert(value, param, ctx)

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> t.Any:
        return value

    def get_metavar(self, param: t.Any) -> t.Optional[str]:
        return None

    def shell_complete(self, ctx: t.Any, param: t.Any, incomplete: str) -> t.List[t.Any]:
        return []

    def split_envvar_value(self, rv: str) -> t.List[str]:
        if self.envvar_list_splitter is not None:
            return rv.split(self.envvar_list_splitter)
        return rv.split()

    def fail(self, message: str, param: t.Any = None, ctx: t.Any = None) -> t.NoReturn:
        raise BadParameter(message, ctx=ctx, param=param)

    def __repr__(self) -> str:
        return self.name.upper()


class FuncParamType(ParamType):
    """Adapts a conversion function ``f(token) -> value`` that raises ValueError."""

    def __init__(self, func: t.Callable[[t.Any], t.Any]) -> None:
        self.func = func
        self.name = getattr(func, "__name__", "text")

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> t.Any:
        try:
            return self.func(value)
        except ValueError as e:
            message = str(e) or f"{value!r} is not a valid {self.name}."
            self.fail(message, param, ctx)


class StringParamType(ParamType):
    name = "text"

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> str:
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        return str(value)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> t.Any:
        return value


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> int:
        if isinstance(value, int) and not isinstance(value, bool):
            return value
        try:
            return int(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> float:
        if isinstance(value, float):
            return value
        try:
            return float(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> bool:
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in TRUE_STRINGS:
            return True
        if text in FALSE_STRINGS:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> uuid.UUID:
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value))
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


class Choice(ParamType):
    """A closed list of allowed values, or the members of an enumeration."""

    name = "choice"

    def __init__(self, choices: t.Iterable[t.Any], case_sensitive: bool = True) -> None:
        self.choices = list(choices)
        self.case_sensitive = case_sensitive

    def _key(self, choice: t.Any) -> str:
        if isinstance(choice, enum.Enum):
            return choice.name
        return str(choice)

    def get_metavar(self, param: t.Any) -> str:
        return "[" + "|".join(self._key(c) for c in self.choices) + "]"

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> t.Any:
        for choice in self.choices:
            if value is choice:
                return choice
        normalize = getattr(ctx, "token_normalize_func", None)
        token = self._key(value) if isinstance(value, enum.Enum) else str(value)
        for choice in self.choices:
            candidate = self._key(choice)
            left, right = candidate, token
            if normalize is not None:
                left, right = normalize(left), normalize(right)
            if not self.case_sensitive:
                left, right = left.casefold(), right.casefold()
            if left == right:
                return choice
        options = ", ".join(repr(self._key(c)) for c in self.choices)
        self.fail(f"{value!r} is not one of {options}.", param, ctx)

    def shell_complete(self, ctx: t.Any, param: t.Any, incomplete: str) -> t.List[t.Any]:
        return [self._key(c) for c in self.choices if self._key(c).startswith(incomplete)]


class DateTime(ParamType):
    """Parses text into a naive ``datetime``; the first matching format wins."""

    name = "datetime"
    DEFAULT_FORMATS: t.Tuple[str, ...] = (
        "%Y-%m-%d",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
    )

    def __init__(self, formats: t.Optional[t.Sequence[str]] = None) -> None:
        self.formats = list(formats) if formats is not None else list(self.DEFAULT_FORMATS)

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> dt.datetime:
        if isinstance(value, dt.datetime):
            return value
        for fmt in self.formats:
            try:
                return dt.datetime.strptime(str(value).strip(), fmt)
            except ValueError:
                continue
        formats = ", ".join(repr(f) for f in self.formats)
        self.fail(f"{value!r} does not match the formats {formats}.", param, ctx)


class IntRange(IntParamType):
    """An integer inside an optional range; clamping moves to the nearest included integer."""

    name = "integer range"

    def __init__(
        self,
        min: t.Optional[int] = None,
        max: t.Optional[int] = None,
        min_open: bool = False,
        max_open: bool = False,
        clamp: bool = False,
    ) -> None:
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> int:
        rv = super().convert(value, param, ctx)
        if self.min is not None:
            below = rv <= self.min if self.min_open else rv < self.min
            if below:
                if self.clamp:
                    return self.min + 1 if self.min_open else self.min
                self._range_fail(rv, param, ctx)
        if self.max is not None:
            above = rv >= self.max if self.max_open else rv > self.max
            if above:
                if self.clamp:
                    return self.max - 1 if self.max_open else self.max
                self._range_fail(rv, param, ctx)
        return rv

    def _range_fail(self, rv: t.Any, param: t.Any, ctx: t.Any) -> t.NoReturn:
        self.fail(f"{rv} is not in the range {self._range_text()}.", param, ctx)

    def _range_text(self) -> str:
        low = "" if self.min is None else f"{'>' if self.min_open else '>='}{self.min}"
        high = "" if self.max is None else f"{'<' if self.max_open else '<='}{self.max}"
        return " and ".join(x for x in (low, high) if x) or "any"


class FloatRange(FloatParamType):
    """A float inside an optional range. Clamping requires both bounds closed."""

    name = "float range"

    def __init__(
        self,
        min: t.Optional[float] = None,
        max: t.Optional[float] = None,
        min_open: bool = False,
        max_open: bool = False,
        clamp: bool = False,
    ) -> None:
        if clamp and (min_open or max_open):
            raise ValueError("FloatRange cannot clamp when a bound is open.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> float:
        rv = super().convert(value, param, ctx)
        if self.min is not None:
            below = rv <= self.min if self.min_open else rv < self.min
            if below:
                if self.clamp:
                    return float(self.min)
                self.fail(f"{rv} is not in the range {self._range_text()}.", param, ctx)
        if self.max is not None:
            above = rv >= self.max if self.max_open else rv > self.max
            if above:
                if self.clamp:
                    return float(self.max)
                self.fail(f"{rv} is not in the range {self._range_text()}.", param, ctx)
        return rv

    def _range_text(self) -> str:
        low = "" if self.min is None else f"{'>' if self.min_open else '>='}{self.min}"
        high = "" if self.max is None else f"{'<' if self.max_open else '<='}{self.max}"
        return " and ".join(x for x in (low, high) if x) or "any"


def _guess_type(default: t.Any) -> ParamType:
    if isinstance(default, bool):
        return BOOL
    if isinstance(default, int):
        return INT
    if isinstance(default, float):
        return FLOAT
    if isinstance(default, (list, tuple)) and default:
        return _guess_type(default[0])
    return STRING


class Tuple(ParamType):
    """A fixed-length product of inner types."""

    name = "tuple"

    def __init__(self, types: t.Sequence[t.Any]) -> None:
        self.types = [convert_type(ty) for ty in types]

    def get_metavar(self, param: t.Any) -> str:
        return " ".join(ty.get_metavar(param) or ty.name.upper() for ty in self.types)

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> t.Tuple[t.Any, ...]:
        if isinstance(value, (str, bytes)) or not hasattr(value, "__len__"):
            self.fail(f"{value!r} is not a sequence of {len(self.types)} values.", param, ctx)
        if len(value) != len(self.types):
            self.fail(f"{value!r} must have exactly {len(self.types)} items.", param, ctx)
        return tuple(ty.convert(item, param, ctx) for ty, item in zip(self.types, value))


class File(ParamType):
    """An open file object. ``-`` is stdin when reading and stdout when writing."""

    name = "filename"
    envvar_list_splitter = os.pathsep

    def __init__(
        self,
        mode: str = "r",
        encoding: t.Optional[str] = None,
        errors: str = "strict",
        lazy: t.Optional[bool] = None,
        atomic: bool = False,
    ) -> None:
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = ("w" in mode) if lazy is None else lazy
        self.atomic = atomic

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> t.Any:
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        if value == "-":
            return open_file("-", self.mode, self.encoding, self.errors)
        try:
            f = open_file(
                value,
                self.mode,
                self.encoding,
                self.errors,
                lazy=self.lazy,
                atomic=self.atomic,
            )
        except OSError as e:
            self.fail(f"'{format_filename(value)}': {e.strerror}", param, ctx)
        if ctx is not None and hasattr(ctx, "call_on_close"):
            ctx.call_on_close(f.close)
        return f


class Path(ParamType):
    """A filesystem path, with optional existence and permission checks."""

    name = "path"
    envvar_list_splitter = os.pathsep

    def __init__(
        self,
        exists: bool = False,
        file_okay: bool = True,
        dir_okay: bool = True,
        writable: bool = False,
        readable: bool = True,
        resolve_path: bool = False,
        allow_dash: bool = False,
        path_type: t.Any = None,
        executable: bool = False,
    ) -> None:
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def _out(self, rv: str) -> t.Any:
        if self.path_type is pathlib.Path:
            return pathlib.Path(rv)
        if self.path_type is str or self.path_type is None:
            return rv
        return self.path_type(rv)

    def convert(self, value: t.Any, param: t.Any, ctx: t.Any) -> t.Any:
        rv = os.fspath(value)
        if self.allow_dash and rv == "-":
            return self._out(rv)
        if self.resolve_path:
            rv = os.path.realpath(rv)
        try:
            st = os.stat(rv)
        except OSError:
            if not self.exists:
                return self._out(rv)
            self.fail(f"{format_filename(rv)!r} does not exist.", param, ctx)
        is_dir = stat.S_ISDIR(st.st_mode)
        if not is_dir and not self.file_okay:
            self.fail(f"{format_filename(rv)!r} is a file.", param, ctx)
        if is_dir and not self.dir_okay:
            self.fail(f"{format_filename(rv)!r} is a directory.", param, ctx)
        if self.readable and not os.access(rv, os.R_OK):
            self.fail(f"{format_filename(rv)!r} is not readable.", param, ctx)
        if self.writable and not os.access(rv, os.W_OK):
            self.fail(f"{format_filename(rv)!r} is not writable.", param, ctx)
        if self.executable and not os.access(rv, os.X_OK):
            self.fail(f"{format_filename(rv)!r} is not executable.", param, ctx)
        return self._out(rv)

    def shell_complete(self, ctx: t.Any, param: t.Any, incomplete: str) -> t.List[t.Any]:
        return []


def convert_type(ty: t.Any, default: t.Any = None) -> ParamType:
    """Turn a declared type (or a type inferred from a default) into a ParamType."""
    if ty is None:
        if default is None:
            return STRING
        return _guess_type(default)
    if isinstance(ty, ParamType):
        return ty
    if ty is str:
        return STRING
    if ty is bool:
        return BOOL
    if ty is int:
        return INT
    if ty is float:
        return FLOAT
    if ty is uuid.UUID:
        return UUID
    if isinstance(ty, (list, tuple)):
        return Tuple(ty)
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"Unknown parameter type {ty!r}.")


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()
