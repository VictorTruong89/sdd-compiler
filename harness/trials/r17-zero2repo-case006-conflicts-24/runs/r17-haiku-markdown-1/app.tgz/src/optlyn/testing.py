"""In-process runner: invoke a command with tokens and capture its output."""

import atexit
import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile
import typing as t


class _Sink:
    """Records every captured write, tagged with its stream, in write order."""

    def __init__(self) -> None:
        self.chunks: t.List[t.Tuple[str, bytes]] = []

    def add(self, name: str, data: bytes) -> None:
        self.chunks.append((name, data))

    def joined(self, name: t.Optional[str] = None) -> bytes:
        return b"".join(data for n, data in self.chunks if name is None or n == name)


class _FdSink:
    """Descriptor capture: fds 1 and 2 point at temporary files for the run."""

    def __init__(self) -> None:
        self._files = {"stdout": tempfile.TemporaryFile(), "stderr": tempfile.TemporaryFile()}
        self._saved: t.Optional[t.Tuple[int, int]] = None
        self._results: t.Dict[str, bytes] = {}

    def add(self, name: str, data: bytes) -> None:
        os.write(self._files[name].fileno(), data)

    def install(self, charset: str) -> t.Tuple[t.TextIO, t.TextIO]:
        sys.stdout.flush()
        sys.stderr.flush()
        self._saved = (os.dup(1), os.dup(2))
        os.dup2(self._files["stdout"].fileno(), 1)
        os.dup2(self._files["stderr"].fileno(), 2)
        out = io.TextIOWrapper(io.FileIO(1, "w", closefd=False), encoding=charset, write_through=True)
        err = io.TextIOWrapper(io.FileIO(2, "w", closefd=False), encoding=charset, write_through=True)
        return out, err

    def finish(self, out: t.TextIO, err: t.TextIO) -> None:
        out.flush()
        err.flush()
        if self._saved is not None:
            os.dup2(self._saved[0], 1)
            os.dup2(self._saved[1], 2)
            os.close(self._saved[0])
            os.close(self._saved[1])
        for name, handle in self._files.items():
            handle.seek(0)
            self._results[name] = handle.read()
            handle.close()

    def joined(self, name: t.Optional[str] = None) -> bytes:
        if name is None:
            return self._results.get("stdout", b"") + self._results.get("stderr", b"")
        return self._results.get(name, b"")


class _CaptureBuffer(io.BufferedIOBase):
    def __init__(self, sink: _Sink, name: str) -> None:
        self._sink = sink
        self._name = name

    def writable(self) -> bool:
        return True

    def write(self, data: t.Any) -> int:
        raw = bytes(data)
        self._sink.add(self._name, raw)
        return len(raw)

    def flush(self) -> None:
        pass


class _CaptureText(io.TextIOBase):
    def __init__(self, sink: _Sink, name: str, charset: str) -> None:
        self._sink = sink
        self._name = name
        self._charset = charset
        self.buffer = _CaptureBuffer(sink, name)

    @property
    def encoding(self) -> str:
        return self._charset

    def writable(self) -> bool:
        return True

    def isatty(self) -> bool:
        return False

    def write(self, text: str) -> int:
        self._sink.add(self._name, text.encode(self._charset))
        return len(text)

    def flush(self) -> None:
        pass


class _InputStream(io.TextIOBase):
    """Standard input for one invocation; echoes what it read when asked."""

    _optlyn_testing = True

    def __init__(self, text: str, echo_stdin: bool, sink: _Sink, charset: str) -> None:
        self._text = text
        self._pos = 0
        self.echo_stdin = echo_stdin
        self._sink = sink
        self._charset = charset

    @property
    def encoding(self) -> str:
        return self._charset

    def readable(self) -> bool:
        return True

    def isatty(self) -> bool:
        return False

    def readline(self, size: int = -1) -> str:
        if self._pos >= len(self._text):
            return ""
        idx = self._text.find("\n", self._pos)
        end = len(self._text) if idx < 0 else idx + 1
        line = self._text[self._pos : end]
        self._pos = end
        if self.echo_stdin:
            self._sink.add("stdout", line.encode(self._charset))
        return line

    def read(self, size: int = -1) -> str:
        if size is None or size < 0:
            size = len(self._text) - self._pos
        chunk = self._text[self._pos : self._pos + size]
        self._pos += len(chunk)
        if self.echo_stdin and chunk:
            self._sink.add("stdout", chunk.encode(self._charset))
        return chunk

    def __iter__(self) -> t.Iterator[str]:
        while True:
            line = self.readline()
            if not line:
                return
            yield line


class Result:
    """What one ``CliRunner.invoke`` produced."""

    def __init__(
        self,
        charset: str,
        output_bytes: bytes,
        stdout_bytes: bytes,
        stderr_bytes: bytes,
        return_value: t.Any,
        exit_code: int,
        exception: t.Optional[BaseException],
        exc_info: t.Any = None,
    ) -> None:
        self._charset = charset
        self.output_bytes = output_bytes
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self) -> str:
        return self.output_bytes.decode("utf-8", "replace")

    @property
    def stdout(self) -> str:
        return self.stdout_bytes.decode("utf-8", "replace")

    @property
    def stderr(self) -> str:
        return self.stderr_bytes.decode("utf-8", "replace")

    def __repr__(self) -> str:
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    """Invokes a command with a token list and captures its output and status."""

    def __init__(
        self,
        charset: str = "utf-8",
        env: t.Optional[t.Mapping[str, t.Optional[str]]] = None,
        echo_stdin: bool = False,
        catch_exceptions: bool = True,
        capture: str = "sys",
    ) -> None:
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli: t.Any) -> str:
        return cli.name or "root"

    @contextlib.contextmanager
    def isolation(
        self,
        input: t.Any = None,
        env: t.Optional[t.Mapping[str, t.Optional[str]]] = None,
    ) -> t.Iterator[t.Tuple[_Sink, t.Any]]:
        sink: t.Any = _FdSink() if self.capture == "fd" else _Sink()
        text = input.decode(self.charset) if isinstance(input, bytes) else (input or "")
        stdin = _InputStream(text, self.echo_stdin, sink, self.charset)
        if isinstance(sink, _FdSink):
            stdout, stderr = sink.install(self.charset)
        else:
            stdout = _CaptureText(sink, "stdout", self.charset)
            stderr = _CaptureText(sink, "stderr", self.charset)
        merged = dict(self.env)
        merged.update(env or {})
        saved_env = {}
        for key, value in merged.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)
        saved_streams = sys.stdin, sys.stdout, sys.stderr
        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
        try:
            yield sink, None
        finally:
            sys.stdin, sys.stdout, sys.stderr = saved_streams
            if isinstance(sink, _FdSink):
                sink.finish(stdout, stderr)
            for key, value in saved_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def invoke(
        self,
        cli: t.Any,
        args: t.Any = None,
        input: t.Any = None,
        env: t.Optional[t.Mapping[str, t.Optional[str]]] = None,
        catch_exceptions: t.Optional[bool] = None,
        color: bool = False,
        **extra: t.Any,
    ) -> Result:
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if args is None:
            tokens: t.List[str] = []
        elif isinstance(args, str):
            tokens = shlex.split(args)
        else:
            tokens = list(args)
        prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
        standalone = extra.pop("standalone_mode", True)

        exit_code = 0
        exception: t.Optional[BaseException] = None
        exc_info: t.Any = None
        return_value: t.Any = None
        with self.isolation(input=input, env=env) as (sink, _):
            try:
                return_value = cli.main(
                    args=tokens,
                    prog_name=prog_name,
                    standalone_mode=standalone,
                    color=color,
                    **extra,
                )
            except SystemExit as e:
                if e.code is None:
                    exit_code = 0
                elif isinstance(e.code, int):
                    exit_code = e.code
                else:
                    sys.stderr.write(str(e.code) + "\n")
                    exit_code = 1
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exc_info = sys.exc_info()
                exit_code = 1
        return Result(
            self.charset,
            sink.joined(),
            sink.joined("stdout"),
            sink.joined("stderr"),
            return_value,
            exit_code,
            exception,
            exc_info,
        )

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir: t.Optional[str] = None) -> t.Iterator[str]:
        """Change into a new empty directory; the directory is kept after the block.

        Without ``temp_dir`` the directory lives in the system temp area and is
        removed when the interpreter exits. With ``temp_dir`` it is created
        inside that parent and left in place.
        """
        cwd = os.getcwd()
        if temp_dir is None:
            path = tempfile.mkdtemp()
            atexit.register(shutil.rmtree, path, True)
        else:
            path = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
