"""Usage lines, help pages and text wrapping."""

import enum
import inspect
import re
import shutil
import textwrap
import typing as t

from .core import Argument, Command, Context, Group, Option
from .param_types import Choice

BACKSPACE = "\x08"
SHORT_HELP_LIMIT = 45


def wrap_text(
    text: str,
    width: int = 78,
    initial_indent: str = "",
    subsequent_indent: str = "",
    preserve_paragraphs: bool = False,
) -> str:
    """Rewrap text to ``width``. Never fails, whatever the string holds."""
    text = "" if text is None else str(text)
    if not preserve_paragraphs:
        flat = " ".join(text.split())
        if not flat:
            return ""
        return textwrap.fill(
            flat,
            width=max(width, 1),
            initial_indent=initial_indent,
            subsequent_indent=subsequent_indent,
            break_long_words=False,
            break_on_hyphens=False,
        )
    blocks = []
    for para in re.split(r"\n\s*\n", text.strip("\n")):
        lines = para.split("\n")
        if BACKSPACE in lines[0] and lines[0].replace(BACKSPACE, "").strip() == "":
            kept = [subsequent_indent + line for line in lines[1:]]
            blocks.append("\n".join(kept))
            continue
        flat = " ".join(line.strip() for line in lines)
        blocks.append(
            textwrap.fill(
                flat,
                width=max(width, 1),
                initial_indent=initial_indent,
                subsequent_indent=subsequent_indent,
                break_long_words=False,
                break_on_hyphens=False,
            )
        )
    return "\n\n".join(blocks)


def clean_help(text: t.Optional[str]) -> str:
    """The help text as shown: truncated at a form feed and de-indented."""
    if not text:
        return ""
    text = text.split("\f", 1)[0]
    return inspect.cleandoc(text)


def first_sentence(text: str) -> str:
    """The first sentence of the first paragraph, used as short help."""
    if not text:
        return ""
    paragraph = text.strip().split("\n\n")[0]
    flat = " ".join(paragraph.split())
    match = re.search(r"(?<=[.!?])\s", flat)
    if match:
        return flat[: match.start()]
    return flat


def _render_text(text: str, width: int) -> str:
    return wrap_text(text, width=width, preserve_paragraphs=True)


def _wrap_width(ctx: Context) -> int:
    if ctx.terminal_width is not None:
        return ctx.terminal_width
    limit = ctx.max_content_width or 80
    detected = shutil.get_terminal_size(fallback=(80, 24)).columns
    return max(min(detected, limit), 20)


def _rows(rows: t.List[t.Tuple[str, str]], width: int) -> str:
    if not rows:
        return ""
    col = min(max(len(first) for first, _ in rows), 30)
    help_width = max(width - col - 6, 20)
    lines: t.List[str] = []
    for first, text in rows:
        wrapped = wrap_text(text, width=help_width) if text else ""
        help_lines = wrapped.split("\n") if wrapped else []
        if not help_lines:
            lines.append("  " + first)
            continue
        if len(first) <= col:
            lines.append("  " + first.ljust(col) + "  " + help_lines[0])
            rest = help_lines[1:]
        else:
            lines.append("  " + first)
            rest = help_lines
        for line in rest:
            lines.append(" " * (col + 4) + line)
    return "\n".join(lines)


def _default_text(value: t.Any) -> str:
    if isinstance(value, enum.Enum):
        return value.name
    if isinstance(value, (list, tuple)):
        return ", ".join(str(v) for v in value)
    return str(value)


def _option_help(ctx: Context, param: Option) -> str:
    parts: t.List[str] = []
    if param.help:
        parts.append(param.help)
    if param.deprecated:
        parts.append("(DEPRECATED)")
    show = param.show_default if param.show_default is not None else ctx.show_default
    if show and not (param.is_flag and not param.default):
        if isinstance(show, str):
            parts.append(f"[default: {show}]")
        elif callable(param.default):
            parts.append("[default: (dynamic)]")
        elif param.default is not None:
            parts.append(f"[default: {_default_text(param.default)}]")
    if param.show_envvar and param.envvar:
        parts.append(f"[env var: {', '.join(param.envvar)}]")
    if isinstance(param.type, Choice) and param.show_choices:
        keys = [c.name if isinstance(c, enum.Enum) else str(c) for c in param.type.choices]
        parts.append(f"[choices: {', '.join(keys)}]")
    return " ".join(parts)


def format_usage(ctx: Context) -> str:
    """The ``Usage:`` line for a command or group."""
    cmd: Command = ctx.command
    pieces = [ctx.command_path]
    params = cmd.get_params(ctx)
    if cmd.options_metavar and any(isinstance(p, Option) and not p.hidden for p in params):
        pieces.append(cmd.options_metavar)
    for arg in cmd.arguments:
        meta = arg.make_metavar()
        if arg.nargs == -1:
            meta += "..."
        if not arg.required:
            meta = f"[{meta}]"
        pieces.append(meta)
    if isinstance(cmd, Group):
        if cmd.chain:
            default = "COMMAND [ARGS]... [COMMAND [ARGS]...]..."
        elif cmd.invoke_without_command:
            default = "[COMMAND [ARGS]...]"
        else:
            default = "COMMAND [ARGS]..."
        pieces.append(cmd.subcommand_metavar or default)
    return "Usage: " + " ".join(p for p in pieces if p)


def format_help(ctx: Context) -> str:
    """The full help page: usage, description, sections, and epilog."""
    cmd: Command = ctx.command
    width = _wrap_width(ctx)
    blocks = [format_usage(ctx)]

    description_parts: t.List[str] = []
    if cmd.deprecated:
        mark = "(Deprecated)"
        if isinstance(cmd.deprecated, str):
            mark = f"(Deprecated) {cmd.deprecated}"
        description_parts.append(mark)
    text = clean_help(cmd.help)
    if text:
        description_parts.append(_render_text(text, width))
    if description_parts:
        blocks.append("\n".join(description_parts))

    params = cmd.get_params(ctx)
    arg_rows = [
        (arg.make_metavar(), arg.help or "")
        for arg in cmd.arguments
        if arg.help and not arg.hidden
    ]
    if arg_rows:
        blocks.append("Positional arguments:\n" + _rows(arg_rows, width))

    opt_rows = [
        (p.get_opts_string(), _option_help(ctx, p))
        for p in params
        if isinstance(p, Option) and not p.hidden
    ]
    if opt_rows:
        blocks.append("Options:\n" + _rows(opt_rows, width))

    if isinstance(cmd, Group):
        command_rows: t.List[t.Tuple[str, str]] = []
        for name in cmd.list_commands(ctx):
            sub = cmd.get_command(ctx, name)
            if sub is None or sub.hidden:
                continue
            command_rows.append((name, sub.get_short_help_str(SHORT_HELP_LIMIT)))
        if command_rows:
            blocks.append("Commands:\n" + _rows(command_rows, width))

    if cmd.epilog:
        blocks.append(_render_text(cmd.epilog, width))
    return "\n\n".join(blocks) + "\n"
