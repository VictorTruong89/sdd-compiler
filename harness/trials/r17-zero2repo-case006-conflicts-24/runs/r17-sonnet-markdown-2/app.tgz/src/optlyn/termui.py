"""Terminal interaction helpers."""
from __future__ import annotations

import contextlib
import getpass
import inspect
import itertools
import math
import os
import shlex
import subprocess
import sys
import tempfile
import time
import typing as t

from . import types
from .exceptions import Abort, OptlynException, UsageError
from .formatting import strip_ansi, term_len
from .globals import resolve_color_default
from .utils import echo, isatty

visible_prompt_func: t.Callable = input
hidden_prompt_func: t.Callable = getpass.getpass
_getchar: t.Optional[t.Callable] = None

# ---------------------------------------------------------------- styling

_ansi_colors = {
    "black": 30,
    "red": 31,
    "green": 32,
    "yellow": 33,
    "blue": 34,
    "magenta": 35,
    "cyan": 36,
    "white": 37,
    "reset": 39,
    "bright_black": 90,
    "bright_red": 91,
    "bright_green": 92,
    "bright_yellow": 93,
    "bright_blue": 94,
    "bright_magenta": 95,
    "bright_cyan": 96,
    "bright_white": 97,
}
_ansi_reset_all = "\033[0m"


class ColorError(TypeError, ValueError):
    """Raised for an invalid color."""


def _interpret_color(color, offset: int = 0) -> str:
    if isinstance(color, bool):
        raise ColorError(f"Unknown color {color!r}")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise ColorError(f"Color index out of range: {color!r}")
        return f"{38 + offset};5;{color:d}"
    if isinstance(color, (tuple, list)):
        if len(color) != 3 or not all(isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color):
            raise ColorError(f"Invalid RGB color: {color!r}")
        r, g, b = color
        return f"{38 + offset};2;{r:d};{g:d};{b:d}"
    if isinstance(color, str) and color in _ansi_colors:
        return str(_ansi_colors[color] + offset)
    raise ColorError(f"Unknown color {color!r}")


def style(
    text,
    fg=None,
    bg=None,
    bold=None,
    dim=None,
    underline=None,
    overline=None,
    italic=None,
    blink=None,
    reverse=None,
    strikethrough=None,
    reset: bool = True,
) -> str:
    if not isinstance(text, str):
        text = str(text)
    bits = []
    if fg is not None:
        bits.append(f"\033[{_interpret_color(fg)}m")
    if bg is not None:
        bits.append(f"\033[{_interpret_color(bg, 10)}m")
    for val, on, off in (
        (bold, 1, 22),
        (dim, 2, 22),
        (underline, 4, 24),
        (overline, 53, 55),
        (italic, 3, 23),
        (blink, 5, 25),
        (reverse, 7, 27),
        (strikethrough, 9, 29),
    ):
        if val is not None:
            bits.append(f"\033[{on if val else off}m")
    bits.append(text)
    if reset:
        bits.append(_ansi_reset_all)
    return "".join(bits)


def unstyle(text: str) -> str:
    return strip_ansi(text)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles) -> None:
    if message is not None and not isinstance(message, (bytes, bytearray)):
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


# ---------------------------------------------------------------- prompts


def _build_prompt(text, suffix, show_default=False, default=None, show_choices=True, type=None):
    prompt = text
    if type is not None and show_choices and isinstance(type, types.Choice):
        prompt += f" ({', '.join(map(str, type.choices))})"
    if default is not None and show_default:
        prompt = f"{prompt} [{_format_default(default)}]"
    return f"{prompt}{suffix}"


def _format_default(default):
    import io

    if isinstance(default, io.IOBase) and hasattr(default, "name"):
        return default.name
    return default


def prompt(
    text,
    default=None,
    hide_input=False,
    confirmation_prompt=False,
    type=None,
    value_proc=None,
    prompt_suffix=": ",
    show_default=True,
    err=False,
    show_choices=True,
):
    def prompt_func(text):
        f = hidden_prompt_func if hide_input else visible_prompt_func
        try:
            echo(text.rstrip(" "), nl=False, err=err)
            return f(" ")
        except (KeyboardInterrupt, EOFError):
            if hide_input:
                echo(None, err=err)
            raise Abort() from None

    if value_proc is None:
        value_proc = types.convert_type(type, default)

    full = _build_prompt(text, prompt_suffix, show_default, default, show_choices, type)
    if confirmation_prompt:
        if confirmation_prompt is True:
            confirmation_prompt = "Repeat for confirmation"
        confirmation_prompt = _build_prompt(confirmation_prompt, prompt_suffix)

    while True:
        while True:
            value = prompt_func(full)
            if value:
                break
            elif default is not None:
                value = default
                break
        try:
            result = value_proc(value)
        except UsageError as e:
            if hide_input:
                echo("Error: The value you entered was invalid.", err=err)
            else:
                echo(f"Error: {e.message}", err=err)
            continue
        if not confirmation_prompt:
            return result
        while True:
            value2 = prompt_func(confirmation_prompt)
            is_empty = not value and not value2
            if value2 or is_empty:
                break
        if value == value2:
            return result
        echo("Error: The two entered values do not match.", err=err)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False) -> bool:
    full = _build_prompt(
        text, prompt_suffix, show_default, "y/n" if default is None else ("Y/n" if default else "y/N")
    )
    while True:
        try:
            echo(full.rstrip(" "), nl=False, err=err)
            value = visible_prompt_func(" ").lower().strip()
        except (KeyboardInterrupt, EOFError):
            raise Abort() from None
        if value in ("y", "yes"):
            rv = True
        elif value in ("n", "no"):
            rv = False
        elif default is not None and value == "":
            rv = default
        else:
            echo("Error: invalid input", err=err)
            continue
        break
    if abort and not rv:
        raise Abort()
    return rv


# ---------------------------------------------------------------- keys


def _real_getchar(echo_: bool) -> str:
    import termios
    import tty

    if not isatty(sys.stdin):
        f = open("/dev/tty")
        fd = f.fileno()
    else:
        fd = sys.stdin.fileno()
        f = None
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 32)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
            sys.stdout.flush()
    finally:
        if f is not None:
            f.close()
    rv = ch.decode(getattr(sys.stdin, "encoding", None) or "utf-8", "replace")
    if echo_ and isatty(sys.stdout):
        sys.stdout.write(rv)
        sys.stdout.flush()
    if rv == "\x03":
        raise KeyboardInterrupt()
    if rv == "\x04":
        raise EOFError()
    return rv


def getchar(echo: bool = False) -> str:
    f = _getchar if _getchar is not None else _real_getchar
    return f(echo)


def pause(info=None, err: bool = False) -> None:
    if info is None:
        info = "Press any key to continue..."
    interactive = isatty(sys.stdin) or isatty(sys.stdout)
    if not interactive:
        echo(info, err=err)
        return
    try:
        echo(info, nl=False, err=err)
        try:
            getchar()
        except (KeyboardInterrupt, EOFError):
            pass
    finally:
        echo(err=err)


def clear() -> None:
    if not isatty(sys.stdout):
        return
    echo("\033[2J\033[1;1H", nl=False)


# ---------------------------------------------------------------- pager


def _interactive() -> bool:
    return isatty(sys.stdin) or isatty(sys.stdout)


class _StripWriter:
    def __init__(self, stream, strip: bool) -> None:
        self._stream = stream
        self._strip = strip

    def write(self, text):
        if self._strip:
            text = strip_ansi(text)
        n = self._stream.write(text)
        try:
            self._stream.flush()
        except Exception:
            pass
        return n

    def flush(self):
        try:
            self._stream.flush()
        except Exception:
            pass

    def writelines(self, lines):
        for line in lines:
            self.write(line)

    def __getattr__(self, name):
        return getattr(self._stream, name)


@contextlib.contextmanager
def get_pager_file(color=None):
    color = resolve_color_default(color)
    pager_cmd = (os.environ.get("PAGER", None) or "").strip()
    if not _interactive() or not pager_cmd:
        stream = sys.stdout
        from . import utils

        strip = utils.should_strip_ansi(stream, color)
        w = _StripWriter(stream, strip)
        try:
            yield w
        finally:
            w.flush()
        return
    env = dict(os.environ)
    cmd_detail = pager_cmd.rsplit("/", 1)[-1].split()
    if color is None and cmd_detail[0] == "less":
        less_flags = f"{os.environ.get('LESS', '')}{' '.join(cmd_detail[1:])}"
        if not less_flags:
            env["LESS"] = "-R"
            color = True
        elif "r" in less_flags or "R" in less_flags:
            color = True
    c = subprocess.Popen(pager_cmd, shell=True, stdin=subprocess.PIPE, env=env, text=True, errors="replace")
    stdin = c.stdin
    w = _StripWriter(stdin, not color)
    try:
        yield w
    except (OSError, KeyboardInterrupt):
        pass
    finally:
        try:
            stdin.close()
        except OSError:
            pass
        while True:
            try:
                c.wait()
            except KeyboardInterrupt:
                pass
            else:
                break


def echo_via_pager(text_or_generator, color=None) -> None:
    color = resolve_color_default(color)
    if callable(text_or_generator):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        i: t.Iterable = [text_or_generator]
    else:
        i = iter(text_or_generator)
    gen = (el if isinstance(el, str) else str(el) for el in i)
    with get_pager_file(color=color) as f:
        for chunk in itertools.chain(gen, "\n"):
            f.write(chunk)


# ---------------------------------------------------------------- progress


def _length_hint(obj):
    try:
        return len(obj)
    except (AttributeError, TypeError):
        try:
            get_hint = type(obj).__length_hint__
        except AttributeError:
            return None
        try:
            hint = get_hint(obj)
        except TypeError:
            return None
        if hint is NotImplemented or not isinstance(hint, int) or hint < 0:
            return None
        return hint


class ProgressBar:
    def __init__(
        self,
        iterable,
        length=None,
        fill_char="#",
        empty_char="-",
        bar_template="%(label)s  [%(bar)s]  %(info)s",
        info_sep="  ",
        hidden=False,
        show_eta=True,
        show_percent=None,
        show_pos=False,
        item_show_func=None,
        label=None,
        file=None,
        color=None,
        update_min_steps=1,
        width=36,
    ) -> None:
        self.fill_char = fill_char
        self.empty_char = empty_char
        self.bar_template = bar_template
        self.info_sep = info_sep
        self.hidden = hidden
        self.show_eta = show_eta
        self.show_percent = show_percent
        self.show_pos = show_pos
        self.item_show_func = item_show_func
        self.label = label or ""
        if file is None:
            file = sys.stdout
        self.file = file
        self.color = color
        self.update_min_steps = update_min_steps
        self._completed_intervals = 0
        self.width = width
        self.autowidth = width == 0
        if length is None:
            length = _length_hint(iterable)
        if iterable is None:
            if length is None:
                raise TypeError("iterable or length is required")
            iterable = range(length)
        self.iter = iter(iterable)
        self.length = length
        self.pos = 0
        self.avg: list = []
        self.last_eta = time.time()
        self.start = self.last_eta
        self.eta_known = False
        self.finished = False
        self.max_width: t.Optional[int] = None
        self.entered = False
        self.current_item = None
        self._is_atty = isatty(self.file)
        self._last_line: t.Optional[str] = None

    def __enter__(self):
        self.entered = True
        self.render_progress()
        return self

    def __exit__(self, *a):
        self.render_finish()

    def __iter__(self):
        if not self.entered:
            raise RuntimeError("You need to use progress bars in a with block.")
        self.render_progress()
        return self.generator()

    def __next__(self):
        return next(iter(self))

    def render_finish(self) -> None:
        if self.hidden or not self._is_atty:
            return
        self.file.write("\n")
        self.file.flush()

    @property
    def pct(self) -> float:
        if self.finished:
            return 1.0
        if not self.length:
            return 0.0
        return min(self.pos / self.length, 1.0)

    @property
    def time_per_iteration(self) -> float:
        if not self.avg:
            return 0.0
        return sum(self.avg) / float(len(self.avg))

    @property
    def eta(self) -> float:
        if self.length is not None and not self.finished:
            return self.time_per_iteration * (self.length - self.pos)
        return 0.0

    def format_eta(self) -> str:
        if self.eta_known:
            tt = int(self.eta)
            seconds = tt % 60
            tt //= 60
            minutes = tt % 60
            tt //= 60
            hours = tt % 24
            tt //= 24
            if tt > 0:
                return f"{tt}d {hours:02}:{minutes:02}:{seconds:02}"
            return f"{hours:02}:{minutes:02}:{seconds:02}"
        return ""

    def format_pos(self) -> str:
        pos = str(self.pos)
        if self.length is not None:
            pos += f"/{self.length}"
        return pos

    def format_pct(self) -> str:
        return f"{int(self.pct * 100): 4}%"[1:]

    def format_bar(self) -> str:
        if self.length is not None:
            bar_length = int(self.pct * self.width)
            bar = self.fill_char * bar_length
            bar += self.empty_char * (self.width - bar_length)
        elif self.finished:
            bar = self.fill_char * self.width
        else:
            chars = list(self.empty_char * (self.width or 1))
            if self.time_per_iteration != 0:
                chars[
                    int((math.cos(self.pos * self.time_per_iteration) / 2.0 + 0.5) * self.width)
                    % len(chars)
                ] = self.fill_char
            bar = "".join(chars)
        return bar

    def format_progress_line(self) -> str:
        show_percent = self.show_percent
        info_bits = []
        if self.length is not None and show_percent is None:
            show_percent = not self.show_pos
        if self.show_pos:
            info_bits.append(self.format_pos())
        if show_percent:
            info_bits.append(self.format_pct())
        if self.show_eta and self.eta_known and not self.finished:
            info_bits.append(self.format_eta())
        if self.item_show_func is not None:
            item_info = self.item_show_func(self.current_item)
            if item_info is not None:
                info_bits.append(item_info)
        return (
            self.bar_template
            % {"label": self.label, "bar": self.format_bar(), "info": self.info_sep.join(info_bits)}
        ).rstrip()

    def render_progress(self) -> None:
        if self.hidden:
            return
        if not self._is_atty:
            if self.label and self._last_line != self.label:
                self._last_line = self.label
                echo(self.label, file=self.file, color=self.color)
            return
        line = self.format_progress_line()
        line_len = term_len(line)
        if self.max_width is None or self.max_width < line_len:
            self.max_width = line_len
        line = line + " " * (self.max_width - line_len)
        if line != self._last_line:
            self._last_line = line
            echo("\r" + line, file=self.file, color=self.color, nl=False)
            self.file.flush()

    def make_step(self, n_steps: int) -> None:
        self.pos += n_steps
        if self.length is not None and self.pos >= self.length:
            self.finished = True
        if (time.time() - self.last_eta) < 1.0 and not self.finished:
            return
        self.last_eta = time.time()
        if self.pos:
            step = (time.time() - self.start) / self.pos
        else:
            step = time.time() - self.start
        self.avg = self.avg[-6:] + [step]
        self.eta_known = self.length is not None

    def update(self, n_steps: int, current_item=None) -> None:
        if current_item is not None:
            self.current_item = current_item
        self.make_step(n_steps)
        self.render_progress()

    def finish(self) -> None:
        self.eta_known = False
        self.current_item = None
        self.finished = True

    def generator(self):
        if not self.entered:
            raise RuntimeError("You need to use progress bars in a with block.")
        for rv in self.iter:
            self.current_item = rv
            yield rv
            self.update(1)
        self.finish()
        self.render_progress()


def progressbar(iterable=None, length=None, label=None, hidden=False, **options) -> ProgressBar:
    return ProgressBar(iterable, length=length, label=label, hidden=hidden, **options)


# ---------------------------------------------------------------- editor/launch


def _get_editor() -> str:
    for key in "VISUAL", "EDITOR":
        rv = os.environ.get(key)
        if rv:
            return rv
    for editor in "editor", "vim", "nano", "vi":
        import shutil

        if shutil.which(editor):
            return editor
    return "vi"


def _edit_file(filename, editor, env):
    environ = None
    if env:
        environ = os.environ.copy()
        environ.update(env)
    try:
        c = subprocess.Popen(f"{editor} {shlex.quote(os.fspath(filename))}", env=environ, shell=True)
        exit_code = c.wait()
        if exit_code != 0:
            raise OptlynException(f"{editor}: Editing failed")
    except OSError as e:
        raise OptlynException(f"{editor}: Editing failed: {e}") from e


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    if editor is None:
        editor = _get_editor()
    if filename is not None:
        _edit_file(filename, editor, env)
        return None
    text = text or ""
    binary_data = isinstance(text, bytes)
    if not binary_data:
        if text and not text.endswith("\n"):
            text += "\n"
        data = text.encode("utf-8")
    else:
        data = text
    fd, name = tempfile.mkstemp(prefix="editor-", suffix=extension)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        st = os.stat(name)
        _edit_file(name, editor, env)
        st2 = os.stat(name)
        with open(name, "rb") as f:
            rv = f.read()
        if require_save and st2.st_mtime_ns == st.st_mtime_ns and rv == data:
            return None
        if binary_data:
            return rv
        return rv.decode("utf-8-sig").replace("\r\n", "\n")
    finally:
        try:
            os.unlink(name)
        except OSError:
            pass


def launch(url, wait: bool = False, locate: bool = False) -> int:
    from urllib.parse import unquote

    def _unquote_file(u: str) -> str:
        if u.startswith("file://"):
            u = unquote(u[7:])
        return u

    if locate:
        url = os.path.dirname(_unquote_file(url)) or "."
    else:
        url = _unquote_file(url)
    try:
        return subprocess.call(["xdg-open", url])
    except OSError:
        return 127
