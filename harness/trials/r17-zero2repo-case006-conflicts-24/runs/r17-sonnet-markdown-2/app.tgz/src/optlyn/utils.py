"""Output helpers, file helpers and misc utilities."""
from __future__ import annotations

import codecs
import errno
import io
import os
import random
import sys
import typing as t

from .formatting import strip_ansi
from .globals import resolve_color_default


def isatty(stream) -> bool:
    try:
        return stream.isatty()
    except Exception:
        return False


def should_strip_ansi(stream=None, color=None) -> bool:
    if color is None:
        if stream is None:
            stream = sys.stdin
        return not isatty(stream)
    return not color


def _is_binary_writer(stream, default=False):
    try:
        stream.write(b"")
    except Exception:
        try:
            stream.write("")
            return False
        except Exception:
            pass
        return default
    return True


def _find_binary_writer(stream):
    if _is_binary_writer(stream, False):
        return stream
    buf = getattr(stream, "buffer", None)
    if buf is not None and _is_binary_writer(buf, True):
        return buf
    return None


def _is_ascii_encoding(encoding: str) -> bool:
    try:
        return codecs.lookup(encoding).name == "ascii"
    except LookupError:
        return False


def echo(message=None, file=None, nl: bool = True, err: bool = False, color=None) -> None:
    """Print a message with Unicode-safe, ANSI-aware output."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if file is None:
        return
    if message is not None and not isinstance(message, (str, bytes, bytearray)):
        out: t.Any = str(message)
    else:
        out = message
    if nl:
        out = out or ""
        if isinstance(out, str):
            out += "\n"
        else:
            out += b"\n"
    if not out:
        file.flush()
        return
    if isinstance(out, (bytes, bytearray)):
        binary_file = _find_binary_writer(file)
        if binary_file is not None:
            file.flush()
            binary_file.write(out)
            binary_file.flush()
            return
        out = bytes(out).decode(getattr(file, "encoding", None) or "utf-8", "replace")
    color = resolve_color_default(color)
    if should_strip_ansi(file, color):
        out = strip_ansi(out)
    enc = getattr(file, "encoding", None)
    binary = _find_binary_writer(file)
    if enc and binary is not None and _is_ascii_encoding(enc):
        try:
            out.encode("ascii")
        except UnicodeEncodeError:
            file.flush()
            binary.write(out.encode("utf-8"))
            binary.flush()
            return
    try:
        file.write(out)
    except UnicodeEncodeError:
        if binary is not None:
            file.flush()
            binary.write(out.encode("utf-8"))
            binary.flush()
            return
        file.write(out.encode(enc or "ascii", "replace").decode(enc or "ascii"))
    file.flush()


# ---------------------------------------------------------------- files


class KeepOpenFile:
    """Proxy that refuses to close the wrapped stream."""

    def __init__(self, file) -> None:
        self._file = file

    def __getattr__(self, name):
        return getattr(self._file, name)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        pass

    def close(self):
        try:
            self._file.flush()
        except Exception:
            pass

    def __repr__(self) -> str:
        return repr(self._file)

    def __iter__(self):
        return iter(self._file)


class _NonClosingTextIOWrapper(io.TextIOWrapper):
    def __del__(self):  # never close the underlying stream
        pass


class _AtomicFile:
    def __init__(self, f, tmp_filename, real_filename) -> None:
        self._f = f
        self._tmp_filename = tmp_filename
        self._real_filename = real_filename
        self.closed = False

    @property
    def name(self):
        return self._real_filename

    def close(self, delete: bool = False) -> None:
        if self.closed:
            return
        self._f.close()
        os.replace(self._tmp_filename, self._real_filename)
        self.closed = True
        if delete:
            try:
                os.unlink(self._real_filename)
            except OSError:
                pass

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, *a):
        self.close(delete=exc_type is not None)

    def __repr__(self) -> str:
        return repr(self._f)

    def __iter__(self):
        return iter(self._f)


def _stdout_text(encoding, errors):
    buf = getattr(sys.stdout, "buffer", None)
    if encoding is None or buf is None:
        return sys.stdout
    sys.stdout.flush()
    return _NonClosingTextIOWrapper(buf, encoding=encoding, errors=errors, write_through=True)


def _stdin_text(encoding, errors):
    buf = getattr(sys.stdin, "buffer", None)
    if encoding is None or buf is None:
        return sys.stdin
    return _NonClosingTextIOWrapper(buf, encoding=encoding, errors=errors)


def open_stream(filename, mode: str = "r", encoding=None, errors: str = "strict", atomic: bool = False):
    binary = "b" in mode
    filename = os.fspath(filename)
    if filename == "-":
        if any(m in mode for m in ("w", "a", "x")):
            if binary:
                return KeepOpenFile(getattr(sys.stdout, "buffer", sys.stdout)), False
            return KeepOpenFile(_stdout_text(encoding, errors)), False
        if binary:
            return KeepOpenFile(getattr(sys.stdin, "buffer", sys.stdin)), False
        return KeepOpenFile(_stdin_text(encoding, errors)), False
    if not atomic:
        if binary:
            return open(filename, mode), True
        return open(filename, mode, encoding=encoding, errors=errors), True
    if "x" in mode:
        raise ValueError("Use the exclusive mode only without atomic.")
    if "r" in mode or "a" in mode:
        raise ValueError("Atomic writes only make sense with `w`-mode.")
    try:
        perm: t.Optional[int] = os.stat(filename).st_mode
    except OSError:
        perm = None
    flags = os.O_RDWR | os.O_CREAT | os.O_EXCL
    while True:
        tmp = os.path.join(os.path.dirname(filename), f".__atomic-write{random.randrange(1 << 32):08x}")
        try:
            fd = os.open(tmp, flags, 0o666 if perm is None else perm)
            break
        except OSError as e:
            if e.errno == errno.EEXIST:
                continue
            raise
    if binary:
        f = open(fd, mode)
    else:
        f = open(fd, mode, encoding=encoding, errors=errors)
    return _AtomicFile(f, tmp, os.path.realpath(filename)), True


class LazyFile:
    """A file that opens on first access."""

    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False) -> None:
        self.name = os.fspath(filename)
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self.should_close = True
        if self.name == "-":
            self._f, self.should_close = open_stream(filename, mode, encoding, errors)

    def __getattr__(self, name):
        if name.startswith("__") or name in ("_f", "should_close"):
            raise AttributeError(name)
        return getattr(self.open(), name)

    def __repr__(self) -> str:
        if self._f is not None:
            return repr(self._f)
        return f"<unopened file '{self.name}' {self.mode}>"

    def open(self):
        if self._f is not None:
            return self._f
        from .exceptions import FileError

        try:
            rv, self.should_close = open_stream(self.name, self.mode, self.encoding, self.errors, atomic=self.atomic)
        except OSError as e:
            raise FileError(self.name, hint=e.strerror) from e
        self._f = rv
        return rv

    def close(self) -> None:
        if self._f is not None:
            self._f.close()

    def close_intelligently(self) -> None:
        if self.should_close:
            self.close()

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close_intelligently()

    def __iter__(self):
        self.open()
        return iter(self._f)


def open_file(filename, mode: str = "r", encoding=None, errors: str = "strict", lazy: bool = False, atomic: bool = False):
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    f, should_close = open_stream(filename, mode, encoding, errors, atomic=atomic)
    if not should_close:
        f = KeepOpenFile(f)
    return f


def format_filename(filename, shorten: bool = False) -> str:
    if shorten:
        filename = os.path.basename(filename)
    else:
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        return filename.decode("utf-8", "backslashreplace")
    return filename.encode("utf-8", "surrogateescape").decode("utf-8", "backslashreplace")


def _posixify(name: str) -> str:
    return "-".join(name.split()).lower()


def get_app_dir(app_name: str, roaming: bool = True, force_posix: bool = False) -> str:
    if sys.platform.startswith("win"):
        key = "APPDATA" if roaming else "LOCALAPPDATA"
        folder = os.environ.get(key)
        if folder is None:
            folder = os.path.expanduser("~")
        return os.path.join(folder, app_name)
    if force_posix:
        return os.path.join(os.path.expanduser(f"~/.{_posixify(app_name)}"))
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~/Library/Application Support"), app_name)
    return os.path.join(os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")), _posixify(app_name))


def get_binary_stream(name: str):
    stream = getattr(sys, name)
    return getattr(stream, "buffer", stream)


def get_text_stream(name: str, encoding=None, errors: str = "strict"):
    stream = getattr(sys, name)
    buf = getattr(stream, "buffer", None)
    if encoding is None or buf is None:
        return stream
    return _NonClosingTextIOWrapper(buf, encoding=encoding, errors=errors)


def get_binary_stdin():
    return get_binary_stream("stdin")


def get_binary_stdout():
    return get_binary_stream("stdout")


def get_binary_stderr():
    return get_binary_stream("stderr")


def get_text_stdin(encoding=None, errors="strict"):
    return get_text_stream("stdin", encoding, errors)


def get_text_stdout(encoding=None, errors="strict"):
    return get_text_stream("stdout", encoding, errors)


def get_text_stderr(encoding=None, errors="strict"):
    return get_text_stream("stderr", encoding, errors)


def split_arg_string(string: str) -> list:
    import shlex

    lex = shlex.shlex(string, posix=True)
    lex.whitespace_split = True
    lex.commenters = ""
    out: list = []
    try:
        for token in lex:
            out.append(token)
    except ValueError:
        out.append(lex.token)
    return out
