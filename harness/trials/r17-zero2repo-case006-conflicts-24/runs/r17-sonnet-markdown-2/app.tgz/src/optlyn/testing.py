"""In-process runner."""
from __future__ import annotations

import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile
import typing as t

from . import formatting, termui, utils


class EchoingStdin:
    def __init__(self, input, output) -> None:
        self._input = input
        self._output = output
        self._paused = False

    def __getattr__(self, x):
        return getattr(self._input, x)

    def _echo(self, rv):
        if not self._paused:
            self._output.write(rv)
        return rv

    def read(self, n=-1):
        return self._echo(self._input.read(n))

    def read1(self, n=-1):
        return self._echo(self._input.read1(n))

    def readline(self, n=-1):
        return self._echo(self._input.readline(n))

    def readlines(self):
        return [self._echo(x) for x in self._input.readlines()]

    def __iter__(self):
        return iter(self._echo(x) for x in self._input)

    def __repr__(self) -> str:
        return repr(self._input)


@contextlib.contextmanager
def _pause_echo(stream):
    if stream is None:
        yield
    else:
        stream._paused = True
        yield
        stream._paused = False


class _NamedTextIOWrapper(io.TextIOWrapper):
    def __init__(self, buffer, name=None, mode=None, **kwargs) -> None:
        super().__init__(buffer, **kwargs)
        self._name = name
        self._mode = mode

    @property
    def name(self):
        return self._name

    @property
    def mode(self):
        return self._mode


class _BytesIOCopy(io.BytesIO):
    def __init__(self, copy_to) -> None:
        super().__init__()
        self.copy_to = copy_to

    def flush(self) -> None:
        super().flush()
        self.copy_to.flush()

    def write(self, b):
        self.copy_to.write(b)
        return super().write(b)


class _FdRaw(io.RawIOBase):
    """Raw writer onto a real descriptor that also records ordered output."""

    def __init__(self, fd: int, combined) -> None:
        self._fd = fd
        self._combined = combined
        self.written = 0

    def writable(self):
        return True

    def fileno(self):
        return self._fd

    def write(self, b):
        b = bytes(b)
        n = 0
        while n < len(b):
            n += os.write(self._fd, b[n:])
        self._combined.write(b)
        self.written += len(b)
        return len(b)


def make_input_stream(input, charset):
    if hasattr(input, "read"):
        rv = getattr(input, "buffer", None)
        if rv is None:
            rv = input.read()
            if isinstance(rv, str):
                rv = rv.encode(charset)
            return io.BytesIO(rv)
        return rv
    if input is None:
        input = b""
    elif isinstance(input, str):
        input = input.encode(charset)
    return io.BytesIO(input)


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value, exit_code, exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    def _dec(self, b: bytes) -> str:
        return b.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def output(self) -> str:
        return self._dec(self.output_bytes)

    @property
    def stdout(self) -> str:
        return self._dec(self.stdout_bytes)

    @property
    def stderr(self) -> str:
        return self._dec(self.stderr_bytes)

    def __repr__(self) -> str:
        exc_str = repr(self.exception) if self.exception else "okay"
        return f"<{type(self).__name__} {exc_str}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys") -> None:
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.charset = charset
        self.env = env or {}
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli) -> str:
        return cli.name or "root"

    def make_env(self, overrides=None) -> dict:
        rv = dict(self.env)
        if overrides:
            rv.update(overrides)
        return rv

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        bytes_input = make_input_stream(input, self.charset)
        echo_input = None
        old_stdin, old_stdout, old_stderr = sys.stdin, sys.stdout, sys.stderr
        old_forced_width = formatting.FORCED_WIDTH
        formatting.FORCED_WIDTH = 80
        env = self.make_env(env)
        bytes_output = io.BytesIO()
        if self.echo_stdin:
            bytes_input = echo_input = EchoingStdin(bytes_input, bytes_output)
        sys.stdin = text_input = _NamedTextIOWrapper(bytes_input, encoding=self.charset, name="<stdin>", mode="r")
        if self.echo_stdin:
            text_input._CHUNK_SIZE = 1  # type: ignore
        fd_state = None
        if self.capture == "fd":
            sys.stdout.flush()
            sys.stderr.flush()
            saved = (os.dup(1), os.dup(2))
            tf_out = tempfile.TemporaryFile()
            tf_err = tempfile.TemporaryFile()
            os.dup2(tf_out.fileno(), 1)
            os.dup2(tf_err.fileno(), 2)
            raw_out = _FdRaw(1, bytes_output)
            raw_err = _FdRaw(2, bytes_output)
            sys.stdout = _NamedTextIOWrapper(
                io.BufferedWriter(raw_out), encoding=self.charset, name="<stdout>", mode="w", write_through=True
            )
            sys.stderr = _NamedTextIOWrapper(
                io.BufferedWriter(raw_err), encoding=self.charset, name="<stderr>", mode="w", write_through=True,
                errors="backslashreplace",
            )
            fd_state = (saved, tf_out, tf_err, raw_out, raw_err)
            stdout_buf = stderr_buf = None
        else:
            stdout_buf = _BytesIOCopy(copy_to=bytes_output)
            stderr_buf = _BytesIOCopy(copy_to=bytes_output)
            sys.stdout = _NamedTextIOWrapper(stdout_buf, encoding=self.charset, name="<stdout>", mode="w", write_through=True)
            sys.stderr = _NamedTextIOWrapper(
                stderr_buf, encoding=self.charset, name="<stderr>", mode="w", errors="backslashreplace", write_through=True
            )

        def visible_input(prompt=None):
            sys.stdout.write(prompt or "")
            try:
                with _pause_echo(echo_input):
                    val = next(text_input).rstrip("\r\n")
            except StopIteration as e:
                raise EOFError() from e
            sys.stdout.write(f"{val}\n")
            sys.stdout.flush()
            return val

        def hidden_input(prompt=None):
            sys.stdout.write(f"{prompt or ''}\n")
            sys.stdout.flush()
            try:
                with _pause_echo(echo_input):
                    return next(text_input).rstrip("\r\n")
            except StopIteration as e:
                raise EOFError() from e

        def _getchar(echo):
            char = sys.stdin.read(1)
            if echo:
                sys.stdout.write(char)
            sys.stdout.flush()
            return char

        default_color = color

        def should_strip_ansi(stream=None, color=None):
            if color is None:
                return not default_color
            return not color

        old_visible = termui.visible_prompt_func
        old_hidden = termui.hidden_prompt_func
        old_getchar = termui._getchar
        old_strip = utils.should_strip_ansi
        termui.visible_prompt_func = visible_input
        termui.hidden_prompt_func = hidden_input
        termui._getchar = _getchar
        utils.should_strip_ansi = should_strip_ansi

        old_env = {}
        try:
            for key, value in env.items():
                old_env[key] = os.environ.get(key)
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            yield (stdout_buf, stderr_buf, bytes_output, fd_state)
        finally:
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            try:
                sys.stdout.flush()
                sys.stderr.flush()
            except Exception:
                pass
            sys.stdout, sys.stderr, sys.stdin = old_stdout, old_stderr, old_stdin
            termui.visible_prompt_func = old_visible
            termui.hidden_prompt_func = old_hidden
            termui._getchar = old_getchar
            utils.should_strip_ansi = old_strip
            formatting.FORCED_WIDTH = old_forced_width

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra) -> Result:
        exc_info = None
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        with self.isolation(input=input, env=env, color=color) as outstreams:
            return_value = None
            exception = None
            exit_code = 0
            if isinstance(args, str):
                args = shlex.split(args)
            try:
                prog_name = extra.pop("prog_name")
            except KeyError:
                prog_name = self.get_default_prog_name(cli)
            try:
                return_value = cli.main(args=args or (), prog_name=prog_name, **extra)
            except SystemExit as e:
                exc_info = sys.exc_info()
                e_code = e.code
                if e_code is None:
                    e_code = 0
                if e_code != 0:
                    exception = e
                if not isinstance(e_code, int):
                    sys.stdout.write(str(e_code))
                    sys.stdout.write("\n")
                    e_code = 1
                exit_code = e_code
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                sys.stdout.flush()
                sys.stderr.flush()
                stdout_buf, stderr_buf, bytes_output, fd_state = outstreams
                if fd_state is None:
                    stdout = stdout_buf.getvalue()
                    stderr = stderr_buf.getvalue()
                    output = bytes_output.getvalue()
                else:
                    saved, tf_out, tf_err, raw_out, raw_err = fd_state
                    os.dup2(saved[0], 1)
                    os.dup2(saved[1], 2)
                    os.close(saved[0])
                    os.close(saved[1])
                    tf_out.seek(0)
                    tf_err.seek(0)
                    stdout = tf_out.read()
                    stderr = tf_err.read()
                    tf_out.close()
                    tf_err.close()
                    if len(stdout) == raw_out.written and len(stderr) == raw_err.written:
                        output = bytes_output.getvalue()
                    else:
                        output = stdout + stderr
        return Result(
            runner=self,
            stdout_bytes=stdout,
            stderr_bytes=stderr,
            output_bytes=output,
            return_value=return_value,
            exit_code=exit_code,
            exception=exception,
            exc_info=exc_info,
        )

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass
