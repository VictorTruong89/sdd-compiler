"""Thread-local stack of invocation contexts."""
from __future__ import annotations

import threading
import typing as t

_local = threading.local()


def get_current_context(silent: bool = False):
    """Return the context current on this thread."""
    try:
        return _local.stack[-1]
    except (AttributeError, IndexError):
        if not silent:
            raise RuntimeError("There is no active context.") from None
    return None


def push_context(ctx) -> None:
    _local.__dict__.setdefault("stack", []).append(ctx)


def pop_context() -> None:
    _local.stack.pop()


def resolve_color_default(color: t.Optional[bool] = None) -> t.Optional[bool]:
    if color is not None:
        return color
    ctx = get_current_context(silent=True)
    if ctx is not None:
        return ctx.color
    return None
