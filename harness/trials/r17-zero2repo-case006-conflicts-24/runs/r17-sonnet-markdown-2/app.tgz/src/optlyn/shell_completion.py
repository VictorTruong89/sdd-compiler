"""Shell completion support."""
from __future__ import annotations

import os
import re
import typing as t

from .core import Argument, Command, Group, Option, ParameterSource
from .utils import echo, split_arg_string


class CompletionItem:
    def __init__(self, value, type: str = "plain", help=None, **kwargs) -> None:
        self.value = value
        self.type = type
        self.help = help
        self._info = kwargs

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        return self._info.get(name)

    def __repr__(self) -> str:
        return f"CompletionItem({self.value!r}, {self.type!r}, {self.help!r})"


_SOURCE_BASH = """\
%(complete_func)s() {
    local IFS=$'\\n'
    local response

    response=$(env COMP_WORDS="${COMP_WORDS[*]}" COMP_CWORD=$COMP_CWORD %(complete_var)s=bash_complete $1)

    for completion in $response; do
        IFS=',' read type value <<< "$completion"

        if [[ $type == 'dir' ]]; then
            COMPREPLY=()
            compopt -o dirnames
        elif [[ $type == 'file' ]]; then
            COMPREPLY=()
            compopt -o default
        elif [[ $type == 'plain' ]]; then
            COMPREPLY+=($value)
        fi
    done

    return 0
}

%(complete_func)s_setup() {
    complete -o nosort -F %(complete_func)s %(prog_name)s
}

%(complete_func)s_setup;
"""

_SOURCE_ZSH = """\
#compdef %(prog_name)s

%(complete_func)s() {
    local -a completions
    local -a completions_with_descriptions
    local -a response
    (( ! $+commands[%(prog_name)s] )) && return 1

    response=("${(@f)$(env COMP_WORDS="${words[*]}" COMP_CWORD=$((CURRENT-1)) %(complete_var)s=zsh_complete %(prog_name)s)}")

    for type key descr in ${response}; do
        if [[ "$type" == "plain" ]]; then
            if [[ "$descr" == "_" ]]; then
                completions+=("$key")
            else
                completions_with_descriptions+=("$key":"$descr")
            fi
        elif [[ "$type" == "dir" ]]; then
            _path_files -/
        elif [[ "$type" == "file" ]]; then
            _path_files -f
        fi
    done

    if [ -n "$completions_with_descriptions" ]; then
        _describe -V unsorted completions_with_descriptions -U
    fi

    if [ -n "$completions" ]; then
        compadd -U -V unsorted -a completions
    fi
}

if [[ $zsh_eval_context[-1] == loadautofunc ]]; then
    %(complete_func)s "$@"
else
    compdef %(complete_func)s %(prog_name)s
fi
"""

_SOURCE_FISH = """\
function %(complete_func)s;
    set -l response (env %(complete_var)s=fish_complete COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -t) %(prog_name)s);

    for completion in $response;
        set -l metadata (string split "," $completion);

        if test $metadata[1] = "dir";
            __fish_complete_directories $metadata[2];
        else if test $metadata[1] = "file";
            __fish_complete_path $metadata[2];
        else if test $metadata[1] = "plain";
            echo $metadata[2];
        end;
    end;
end;

complete --no-files --command %(prog_name)s --arguments "(%(complete_func)s)";
"""

_SOURCE_POWERSHELL = """\
Register-ArgumentCompleter -Native -CommandName %(prog_name)s -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)
    $env:COMP_WORDS = $commandAst
    $env:COMP_CWORD = $commandAst.CommandElements.Count - 1
    if ($wordToComplete -eq "") { $env:COMP_CWORD = $commandAst.CommandElements.Count }
    $env:%(complete_var)s = "powershell_complete"
    %(prog_name)s | ForEach-Object {
        $type, $value, $help = $_.Split(":", 3)
        if ($type -eq "plain") {
            [System.Management.Automation.CompletionResult]::new($value, $value, "ParameterValue", $(if ($help.Trim()) { $help } else { $value }))
        } elseif ($type -eq "file" -or $type -eq "dir") {
            Get-ChildItem -Path "$value*" | ForEach-Object { [System.Management.Automation.CompletionResult]::new($_.Name, $_.Name, "ParameterValue", $_.Name) }
        }
    }
    Remove-Item Env:%(complete_var)s
}
"""


def _start_of_option(ctx, value: str) -> bool:
    if not value:
        return False
    return value[0] in ctx._opt_prefixes


def _is_incomplete_argument(ctx, param) -> bool:
    if not isinstance(param, Argument):
        return False
    value = ctx.params.get(param.name)
    return bool(
        param.nargs == -1
        or ctx.get_parameter_source(param.name) is not ParameterSource.COMMANDLINE
        or (param.nargs > 1 and isinstance(value, (tuple, list)) and len(value) < param.nargs)
    )


def _is_incomplete_option(ctx, args, param) -> bool:
    if not isinstance(param, Option):
        return False
    if param.is_flag or param.count:
        return False
    last_option = None
    for index, arg in enumerate(reversed(args)):
        if index + 1 > param.nargs:
            break
        if _start_of_option(ctx, arg):
            last_option = arg
    return last_option is not None and last_option in param.opts


def _resolve_context(cli, ctx_args, prog_name, args):
    ctx_args = dict(ctx_args)
    ctx_args["resilient_parsing"] = True
    ctx = cli.make_context(prog_name, list(args), **ctx_args)
    args = ctx.protected_args + ctx.args
    while args:
        command = ctx.command
        if isinstance(command, Group):
            if not command.chain:
                name, cmd, args = command.resolve_command(ctx, args)
                if cmd is None:
                    return ctx
                ctx = cmd.make_context(name, args, parent=ctx, resilient_parsing=True)
                args = ctx.protected_args + ctx.args
            else:
                while args:
                    name, cmd, args = command.resolve_command(ctx, args)
                    if cmd is None:
                        return ctx
                    sub_ctx = cmd.make_context(
                        name, args, parent=ctx, allow_extra_args=True, allow_interspersed_args=False, resilient_parsing=True
                    )
                    args = sub_ctx.args
                ctx = sub_ctx
                args = [*sub_ctx.protected_args, *sub_ctx.args]
        else:
            break
    return ctx


def _resolve_incomplete(ctx, args, incomplete):
    if "--" in args:
        return ctx.command, incomplete
    params = ctx.command.get_params(ctx)
    if incomplete and _start_of_option(ctx, incomplete):
        return ctx.command, incomplete
    for param in params:
        if _is_incomplete_option(ctx, args, param):
            return param, incomplete
    for param in params:
        if _is_incomplete_argument(ctx, param):
            return param, incomplete
    return ctx.command, incomplete


class ShellComplete:
    name: t.ClassVar[str]
    source_template: t.ClassVar[str]

    def __init__(self, cli, ctx_args, prog_name, complete_var) -> None:
        self.cli = cli
        self.ctx_args = ctx_args
        self.prog_name = prog_name
        self.complete_var = complete_var

    @property
    def func_name(self) -> str:
        safe_name = re.sub(r"\W*", "", self.prog_name.replace("-", "_"), flags=re.ASCII)
        return f"_{safe_name}_completion"

    def source_vars(self) -> dict:
        return {
            "complete_func": self.func_name,
            "complete_var": self.complete_var,
            "prog_name": self.prog_name,
        }

    def source(self) -> str:
        return self.source_template % self.source_vars()

    def get_completion_args(self):
        raise NotImplementedError

    def get_completions(self, args, incomplete):
        ctx = _resolve_context(self.cli, self.ctx_args, self.prog_name, args)
        obj, incomplete = _resolve_incomplete(ctx, args, incomplete)
        return obj.shell_complete(ctx, incomplete)

    def format_completion(self, item) -> str:
        raise NotImplementedError

    def complete(self) -> str:
        args, incomplete = self.get_completion_args()
        completions = self.get_completions(args, incomplete)
        out = [self.format_completion(item) for item in completions]
        return "\n".join(out)


class BashComplete(ShellComplete):
    name = "bash"
    source_template = _SOURCE_BASH

    def get_completion_args(self):
        cwords = split_arg_string(os.environ["COMP_WORDS"])
        cword = int(os.environ["COMP_CWORD"])
        args = cwords[1:cword]
        try:
            incomplete = cwords[cword]
        except IndexError:
            incomplete = ""
        return args, incomplete

    def format_completion(self, item) -> str:
        return f"{item.type},{item.value}"


class ZshComplete(BashComplete):
    name = "zsh"
    source_template = _SOURCE_ZSH

    def format_completion(self, item) -> str:
        return f"{item.type}\n{item.value}\n{item.help if item.help else '_'}"


class FishComplete(ShellComplete):
    name = "fish"
    source_template = _SOURCE_FISH

    def get_completion_args(self):
        cwords = split_arg_string(os.environ["COMP_WORDS"])
        incomplete = os.environ["COMP_CWORD"]
        args = cwords[1:]
        if incomplete and args and args[-1] == incomplete:
            args.pop()
        return args, incomplete

    def format_completion(self, item) -> str:
        if item.help:
            return f"{item.type},{item.value}\t{item.help}"
        return f"{item.type},{item.value}"


class PowerShellComplete(BashComplete):
    name = "powershell"
    source_template = _SOURCE_POWERSHELL

    def format_completion(self, item) -> str:
        return f"{item.type}:{item.value}:{item.help or ' '}"


_registry = {c.name: c for c in (BashComplete, ZshComplete, FishComplete, PowerShellComplete)}


def get_completion_class(shell: str):
    return _registry.get(shell)


def shell_complete(cli, ctx_args, prog_name, complete_var, instruction) -> int:
    shell, _, instr = instruction.partition("_")
    comp_cls = get_completion_class(shell)
    if comp_cls is None:
        return 1
    comp = comp_cls(cli, ctx_args, prog_name, complete_var)
    if instr == "source":
        echo(comp.source())
        return 0
    if instr == "complete":
        echo(comp.complete())
        return 0
    return 1
