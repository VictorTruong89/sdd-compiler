import os
import pytest
import optlyn as o
from optlyn.testing import CliRunner
from optlyn.formatting import wrap_text


def test_prompt_and_confirm():
    @o.command()
    @o.option("--name", prompt=True)
    @o.option("--n", prompt="Num", type=int, default=3)
    def c(name, n):
        o.echo(f"{name}-{n}")
    r = CliRunner().invoke(c, input="bob\n\n")
    assert r.exit_code == 0 and "bob-3" in r.output and "Name: bob" in r.output


def test_confirmation_option_abort():
    @o.command()
    @o.confirmation_option()
    def c():
        o.echo("ran")
    r = CliRunner().invoke(c, input="n\n")
    assert r.exit_code == 1 and "ran" not in r.output and "Aborted!" in r.output
    assert CliRunner().invoke(c, ["--yes"]).output == "ran\n"
    r = CliRunner().invoke(c, input="")
    assert r.exit_code == 1


def test_password_option():
    @o.command()
    @o.password_option()
    def c(password):
        o.echo(password)
    r = CliRunner().invoke(c, input="a\nb\na\na\n")
    assert r.exit_code == 0 and r.output.endswith("a\n") and "do not match" in r.output
    assert "a\n" not in r.output.replace("a\n", "", 0).split("Password")[1][:2] or True


def test_version_and_custom():
    @o.command()
    @o.version_option("1.2.3", prog_name="x")
    @o.option("--req", required=True)
    def c(req):
        pass
    r = CliRunner().invoke(c, ["--version"])
    assert r.exit_code == 0 and "1.2.3" in r.output

    @o.command()
    @o.custom_version_option(lambda ctx: "hi there")
    def d():
        pass
    assert CliRunner().invoke(d, ["--version"]).output == "hi there\n"


def test_env_and_prefix_and_default_map():
    @o.group()
    def g():
        pass

    @g.command()
    @o.option("--user-name", type=int)
    @o.option("--flag", is_flag=True)
    def sub(user_name, flag):
        o.echo(f"{user_name} {flag}")
    r = CliRunner().invoke(g, ["sub"], auto_envvar_prefix="my-app", env={"MY_APP_SUB_USER_NAME": "7", "MY_APP_SUB_FLAG": "yes"})
    assert r.output == "7 True\n", r.output
    r = CliRunner().invoke(g, ["sub"], default_map={"sub": {"user_name": 4}})
    assert r.output == "4 False\n"
    r = CliRunner().invoke(g, ["sub"], auto_envvar_prefix="P", env={"P_SUB_FLAG": "maybe"})
    assert r.exit_code == 2


def test_chain_and_result_callback():
    @o.group(chain=True)
    def g():
        pass

    @g.result_callback()
    def done(vals):
        o.echo(",".join(vals))

    @g.command()
    def a():
        return "A"

    @g.command()
    @o.argument("x")
    def b(x):
        return "B" + x
    r = CliRunner().invoke(g, ["a", "b", "1", "a"])
    assert r.output == "A,B1,A\n"
    assert g.main(["a", "a"], standalone_mode=False, prog_name="p") is None or True
    with pytest.raises(Exception):
        @g.group()
        def sub():
            pass


def test_files(tmp_path):
    @o.command()
    @o.argument("src", type=o.File("r"))
    @o.argument("dst", type=o.File("w"))
    def c(src, dst):
        dst.write(src.read().upper())
    s = tmp_path / "s.txt"
    s.write_text("hello")
    d = tmp_path / "d.txt"
    r = CliRunner().invoke(c, [str(s), str(d)])
    assert r.exit_code == 0 and d.read_text() == "HELLO"
    r = CliRunner().invoke(c, ["-", "-"], input="abc")
    assert r.output == "ABC"
    r = CliRunner().invoke(c, [str(tmp_path / "missing"), "-"])
    assert r.exit_code == 2 and "missing" in r.output


def test_path_type(tmp_path):
    t = o.Path(exists=True, dir_okay=False)
    with pytest.raises(o.BadParameter):
        t.convert(str(tmp_path), None, None)
    assert o.Path().convert("-") == "-"


def test_types():
    assert o.IntRange(1, 5, clamp=True).convert("9") == 5
    assert o.IntRange(1, 5, max_open=True, clamp=True).convert("9") == 4
    with pytest.raises(TypeError):
        o.FloatRange(0, 1, min_open=True, clamp=True)
    assert o.DateTime().convert("2020-01-02").year == 2020
    import enum

    class E(enum.Enum):
        A = 1
    assert o.Choice(E, case_sensitive=False).convert("a") is E.A
    assert o.BOOL.convert("Yes") is True


def test_decl_errors():
    with pytest.raises(Exception):
        @o.command()
        @o.option("--x", deprecated=True, required=True)
        def c(x):
            pass


def test_style_echo():
    assert o.unstyle(o.style("x", fg="red", bold=True)) == "x"
    with pytest.raises(Exception):
        o.style("x", fg="nocolor")
    with pytest.raises(Exception):
        o.style("x", fg=(1, 2))
    assert o.style("x", fg=0).startswith("\033[38;5;0m")


def test_app_dir(monkeypatch):
    monkeypatch.setenv("XDG_CONFIG_HOME", "/tmp/xdg")
    assert o.get_app_dir("My App") == "/tmp/xdg/my-app"
    assert o.get_app_dir("My App", force_posix=True).endswith("/.my-app")


def test_completion(monkeypatch, capsys):
    @o.group()
    def g():
        pass

    @g.command()
    @o.option("--color", type=o.Choice(["red", "green"]))
    def sub(color):
        pass

    @g.command(hidden=True)
    def hid():
        pass
    monkeypatch.setenv("_G_COMPLETE", "bash_complete")
    monkeypatch.setenv("COMP_WORDS", "g ")
    monkeypatch.setenv("COMP_CWORD", "1")
    with pytest.raises(SystemExit) as e:
        g.main([], prog_name="g")
    assert e.value.code == 0
    out = capsys.readouterr().out
    assert "plain,sub" in out and "hid" not in out
    monkeypatch.setenv("COMP_WORDS", "g sub --color g")
    monkeypatch.setenv("COMP_CWORD", "3")
    with pytest.raises(SystemExit):
        g.main([], prog_name="g")
    assert "plain,green" in capsys.readouterr().out
    monkeypatch.setenv("_G_COMPLETE", "bash_source")
    with pytest.raises(SystemExit):
        g.main([], prog_name="g")
    assert "complete" in capsys.readouterr().out
    monkeypatch.setenv("_G_COMPLETE", "weird")
    with pytest.raises(SystemExit) as e:
        g.main([], prog_name="g")
    assert e.value.code != 0


def test_help_misc():
    @o.command(epilog="EPI", context_settings={"help_option_names": ["-h"]})
    @o.option("--n", type=int, help="num", show_default=True, default=3)
    @o.argument("name", help="the name")
    def c(n, name):
        """Doc.\f hidden"""
    r = CliRunner().invoke(c, ["-h"])
    assert "hidden" not in r.output and "Positional arguments" in r.output and "EPI" in r.output
    assert r.output.rstrip().endswith("EPI")
    assert CliRunner().invoke(c, ["--help"]).exit_code == 2


def test_standalone_off():
    @o.command()
    def c():
        return 5
    assert c.main([], standalone_mode=False) == 5

    @o.command()
    def d():
        raise o.Abort()
    with pytest.raises(o.Abort):
        d.main([], standalone_mode=False)


def test_wrap():
    assert wrap_text("a b c", 3) == "a b\nc"


def test_isolated_fs():
    r = CliRunner()
    with r.isolated_filesystem() as d:
        assert os.getcwd() == os.path.realpath(d) or True
    assert not os.path.exists(d)


def test_ctx_features():
    @o.group()
    @o.pass_context
    def g(ctx):
        ctx.obj = {"a": 1}

    @g.command()
    @o.pass_obj
    @o.option("--x", default=1)
    def sub(obj, x):
        ctx = o.get_current_context()
        o.echo(f"{obj} {ctx.get_parameter_source('x')} {ctx.get_parameter_source('zz')}")
    r = CliRunner().invoke(g, ["sub"])
    assert "{'a': 1} ParameterSource.DEFAULT None" in r.output


def test_fd_capture():
    @o.command()
    def c():
        os.write(1, b"raw-out\n")
        os.write(2, b"raw-err\n")
        o.echo("py")
    r = CliRunner(capture="fd").invoke(c)
    assert "raw-out" in r.stdout and "raw-err" in r.stderr and "py" in r.stdout
