"""In-process runner."""
from __future__ import annotations

import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile

from . import formatting, termui, utils
from .utils import _find_binary_writer  # noqa: F401


class EchoingStdin:
    def __init__(self, input, output):
        self._input = input
        self._output = output
        self._paused = False

    def __getattr__(self, x):
        return getattr(self._input, x)

    def _echo(self, rv):
        if not self._paused:
            self._output.write(rv)
        return rv

    def read(self, n=-1):
        return self._echo(self._input.read(n))

    def read1(self, n=-1):
        return self._echo(self._input.read1(n))

    def readline(self, n=-1):
        return self._echo(self._input.readline(n))

    def readlines(self):
        return [self._echo(x) for x in self._input.readlines()]

    def __iter__(self):
        return iter(self._echo(x) for x in self._input)

    def __repr__(self):
        return repr(self._input)


@contextlib.contextmanager
def _pause_echo(stream):
    if stream is None:
        yield
    else:
        stream._paused = True
        try:
            yield
        finally:
            stream._paused = False


class BytesIOCopy(io.BytesIO):
    def __init__(self, copy_to, fileno=None):
        super().__init__()
        self.copy_to = copy_to
        self._fileno = fileno

    def flush(self):
        super().flush()
        self.copy_to.flush()

    def write(self, b):
        self.copy_to.write(b)
        return super().write(b)

    def fileno(self):
        if self._fileno is None:
            raise io.UnsupportedOperation("fileno")
        return self._fileno


class _NamedTextIOWrapper(io.TextIOWrapper):
    def __init__(self, buffer, name=None, mode=None, **kwargs):
        super().__init__(buffer, **kwargs)
        self._name = name
        self._mode = mode

    @property
    def name(self):
        return self._name

    @property
    def mode(self):
        return self._mode


def make_input_stream(input, charset):
    if hasattr(input, "read"):
        rv = input
        if not isinstance(rv.read(0), bytes):
            return io.BytesIO(rv.read().encode(charset))
        return rv
    if input is None:
        input = b""
    elif isinstance(input, str):
        input = input.encode(charset)
    return io.BytesIO(input)


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value, exit_code,
                 exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self):
        return self.output_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    def __repr__(self):
        exc = repr(self.exception) if self.exception else "okay"
        return f"<{type(self).__name__} {exc}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        self.charset = charset
        self.env = env or {}
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def make_env(self, overrides=None):
        rv = dict(self.env)
        if overrides:
            rv.update(overrides)
        return rv

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        bytes_input = make_input_stream(input, self.charset)
        echo_input = None
        old_stdin, old_stdout, old_stderr = sys.stdin, sys.stdout, sys.stderr
        old_forced_width = formatting.FORCED_WIDTH
        formatting.FORCED_WIDTH = 80
        env = self.make_env(env)

        bytes_output = io.BytesIO()
        if self.echo_stdin:
            bytes_input = echo_input = EchoingStdin(bytes_input, bytes_output)
        sys.stdin = text_input = _NamedTextIOWrapper(bytes_input, encoding=self.charset,
                                                     name="<stdin>", mode="r")
        if self.echo_stdin:
            text_input._CHUNK_SIZE = 1

        fd_files = []
        saved_fds = None
        out_fileno = err_fileno = None
        if self.capture == "fd":
            out_tmp = tempfile.TemporaryFile()
            err_tmp = tempfile.TemporaryFile()
            fd_files = [out_tmp, err_tmp]
            for s in (old_stdout, old_stderr):
                try:
                    s.flush()
                except Exception:
                    pass
            saved_fds = (os.dup(1), os.dup(2))
            os.dup2(out_tmp.fileno(), 1)
            os.dup2(err_tmp.fileno(), 2)
            out_fileno, err_fileno = 1, 2

        bytes_stdout = BytesIOCopy(copy_to=bytes_output, fileno=out_fileno)
        bytes_stderr = BytesIOCopy(copy_to=bytes_output, fileno=err_fileno)
        sys.stdout = _NamedTextIOWrapper(bytes_stdout, encoding=self.charset, name="<stdout>",
                                         mode="w")
        sys.stderr = _NamedTextIOWrapper(bytes_stderr, encoding=self.charset, name="<stderr>",
                                         mode="w", errors="backslashreplace")

        @_pause_wrap(echo_input)
        def visible_input(prompt=None):
            sys.stdout.write(prompt or "")
            line = text_input.readline()
            if line == "":
                raise EOFError()
            val = line.rstrip("\r\n")
            sys.stdout.write(f"{val}\n")
            sys.stdout.flush()
            return val

        @_pause_wrap(echo_input)
        def hidden_input(prompt=None):
            sys.stdout.write(f"{prompt or ''}\n")
            sys.stdout.flush()
            line = text_input.readline()
            if line == "":
                raise EOFError()
            return line.rstrip("\r\n")

        def _getchar(echo):
            char = sys.stdin.read(1)
            if echo:
                sys.stdout.write(char)
            return char

        default_color = color

        def should_strip_ansi(stream=None, color=None):
            if color is None:
                return not default_color
            return not color

        old_visible = termui.visible_prompt_func
        old_hidden = termui.hidden_prompt_func
        old_getchar = termui._getchar
        old_strip = utils.should_strip_ansi
        termui.visible_prompt_func = visible_input
        termui.hidden_prompt_func = hidden_input
        termui._getchar = _getchar
        utils.should_strip_ansi = should_strip_ansi

        old_env = {}
        try:
            for key, value in env.items():
                old_env[key] = os.environ.get(key)
                if value is None:
                    try:
                        del os.environ[key]
                    except Exception:
                        pass
                else:
                    os.environ[key] = value
            yield (bytes_output, bytes_stdout, bytes_stderr, fd_files)
        finally:
            for key, value in old_env.items():
                if value is None:
                    try:
                        del os.environ[key]
                    except Exception:
                        pass
                else:
                    os.environ[key] = value
            try:
                sys.stdout.flush()
                sys.stderr.flush()
            except Exception:
                pass
            if saved_fds is not None:
                os.dup2(saved_fds[0], 1)
                os.dup2(saved_fds[1], 2)
                os.close(saved_fds[0])
                os.close(saved_fds[1])
            sys.stdout, sys.stderr, sys.stdin = old_stdout, old_stderr, old_stdin
            termui.visible_prompt_func = old_visible
            termui.hidden_prompt_func = old_hidden
            termui._getchar = old_getchar
            utils.should_strip_ansi = old_strip
            formatting.FORCED_WIDTH = old_forced_width

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False,
               **extra):
        exc_info = None
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        with self.isolation(input=input, env=env, color=color) as streams:
            bytes_output, bytes_stdout, bytes_stderr, fd_files = streams
            return_value = None
            exception = None
            exit_code = 0
            if isinstance(args, str):
                args = shlex.split(args)
            prog_name = extra.pop("prog_name", None)
            if prog_name is None:
                prog_name = self.get_default_prog_name(cli)
            try:
                return_value = cli.main(args=args or (), prog_name=prog_name, **extra)
            except SystemExit as e:
                exc_info = sys.exc_info()
                e_code = e.code
                if e_code is None:
                    e_code = 0
                if e_code != 0:
                    exception = e
                if not isinstance(e_code, int):
                    sys.stdout.write(str(e_code))
                    sys.stdout.write("\n")
                    e_code = 1
                exit_code = e_code
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                sys.stdout.flush()
                sys.stderr.flush()
                stdout = bytes_stdout.getvalue()
                stderr = bytes_stderr.getvalue()
                output = bytes_output.getvalue()
                if fd_files:
                    for i, f in enumerate(fd_files):
                        f.flush()
                        f.seek(0)
                        data = f.read()
                        if i == 0:
                            stdout += data
                        else:
                            stderr += data
                        output += data
        return Result(runner=self, stdout_bytes=stdout, stderr_bytes=stderr,
                      output_bytes=output, return_value=return_value, exit_code=exit_code,
                      exception=exception, exc_info=exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass


def _pause_wrap(echo_input):
    def deco(f):
        def wrapper(prompt=None):
            if echo_input is None:
                return f(prompt)
            with _pause_echo(echo_input):
                return f(prompt)
        return wrapper
    return deco
