"""Optlyn: a command line interface composition kit."""
from .core import (Argument, Command, CommandCollection, Context, Group, Option, Parameter,
                   ParameterSource)
from .decorators import (argument, command, confirmation_option, custom_version_option, group,
                         help_option, make_pass_decorator, option, pass_context, pass_obj,
                         password_option, version_option)
from .exceptions import (Abort, BadArgumentUsage, BadOptionUsage, BadParameter, Exit, FileError,
                         MissingParameter, NoSuchOption, OptlynException, UsageError)
from .globals import get_current_context
from .termui import (clear, confirm, edit, getchar, launch, pause, progressbar, prompt)
from .termui import echo_via_pager, get_pager_file
from .types import (BOOL, FLOAT, INT, STRING, UNPROCESSED, UUID, Choice, DateTime, File,
                    FloatRange, IntRange, ParamType, Path, Tuple)
from .utils import (echo, format_filename, get_app_dir, get_binary_stream, get_text_stream,
                    open_file, secho, style, unstyle)

__version__ = "0.1.0"
