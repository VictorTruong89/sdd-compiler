"""Terminal interaction helpers."""
from __future__ import annotations

import contextlib
import inspect
import io
import itertools
import math
import os
import shutil
import subprocess
import sys
import time

from .exceptions import Abort, UsageError, OptlynException
from .globals import resolve_color_default
from .types import convert_type, Choice, File
from .utils import echo, isatty, strip_ansi, term_len, style, unstyle, secho  # noqa: F401
from . import utils as _utils


def _default_prompt_input(prompt=" "):
    return input(prompt)


def _default_hidden_input(prompt=" "):
    import getpass
    return getpass.getpass(prompt)


visible_prompt_func = _default_prompt_input
hidden_prompt_func = _default_hidden_input


def _build_prompt(text, suffix, show_default=False, default=None, show_choices=True, type=None):
    prompt = text
    if type is not None and show_choices and isinstance(type, Choice):
        prompt += f" ({', '.join(map(str, type.choices_as_str))})"
    if default is not None and show_default:
        d = default.name if isinstance(default, File) else default
        prompt = f"{prompt} [{d}]"
    return f"{prompt}{suffix}"


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False, show_choices=True):
    def prompt_func(text):
        f = hidden_prompt_func if hide_input else visible_prompt_func
        try:
            echo(text.rstrip(" "), nl=False, err=err)
            return f(" ")
        except (KeyboardInterrupt, EOFError):
            if hide_input:
                echo(None, err=err)
            raise Abort() from None

    if value_proc is None:
        value_proc = convert_type(type, default)
    ptext = _build_prompt(text, prompt_suffix, show_default, default, show_choices, type)
    if confirmation_prompt:
        if confirmation_prompt is True:
            confirmation_prompt = "Repeat for confirmation"
        confirmation_prompt = _build_prompt(confirmation_prompt, prompt_suffix)
    while True:
        while True:
            value = prompt_func(ptext)
            if value:
                break
            elif default is not None:
                value = default
                break
        try:
            result = value_proc(value)
        except UsageError as e:
            if hide_input:
                echo("Error: The value you entered was invalid.", err=err)
            else:
                echo(f"Error: {e.message}", err=err)
            continue
        if not confirmation_prompt:
            return result
        while True:
            value2 = prompt_func(confirmation_prompt)
            is_empty = not value and not value2
            if value2 or is_empty:
                break
        if value == value2:
            return result
        echo("Error: The two entered values do not match.", err=err)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    ptext = _build_prompt(text, prompt_suffix, show_default,
                          "y/n" if default is None else ("Y/n" if default else "y/N"))
    while True:
        try:
            echo(ptext.rstrip(" "), nl=False, err=err)
            value = visible_prompt_func(" ").lower().strip()
        except (KeyboardInterrupt, EOFError):
            raise Abort() from None
        if value in ("y", "yes"):
            rv = True
        elif value in ("n", "no"):
            rv = False
        elif default is not None and value == "":
            rv = default
        else:
            echo("Error: invalid input", err=err)
            continue
        break
    if abort and not rv:
        raise Abort()
    return rv


# ---- pager -------------------------------------------------------------------

def _interactive():
    return isatty(sys.stdin) or isatty(sys.stdout)


def _chunks(text_or_generator):
    if inspect.isclass(text_or_generator):
        text_or_generator = text_or_generator()
    if callable(text_or_generator):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, (str, bytes)):
        text_or_generator = [text_or_generator]
    for c in text_or_generator:
        yield c if isinstance(c, str) else c.decode("utf-8", "replace") if isinstance(
            c, bytes) else str(c)


class _PagerFile:
    def __init__(self, write, close, strip):
        self._write = write
        self._close = close
        self._strip = strip
        self.closed = False

    def write(self, text):
        if not isinstance(text, str):
            text = str(text)
        if self._strip:
            text = strip_ansi(text)
        self._write(text)
        return len(text)

    def flush(self):
        pass

    def writable(self):
        return True

    def isatty(self):
        return False

    def close(self):
        if not self.closed:
            self.closed = True
            self._close()


@contextlib.contextmanager
def get_pager_file(color=None):
    color = resolve_color_default(color)
    stdout = sys.stdout
    pager_cmd = (os.environ.get("PAGER") or "").strip()
    if not _interactive():
        strip = _utils.should_strip_ansi(stdout, color)

        def w(t):
            stdout.write(t)
            stdout.flush()
        f = _PagerFile(w, lambda: None, strip)
        yield f
        return
    if not pager_cmd:
        for cand in ("less", "more"):
            if shutil.which(cand):
                pager_cmd = cand
                break
    if not pager_cmd:
        strip = _utils.should_strip_ansi(stdout, color)

        def w(t):
            stdout.write(t)
            stdout.flush()
        yield _PagerFile(w, lambda: None, strip)
        return
    env = os.environ.copy()
    if "less" in pager_cmd and "LESS" not in env and color:
        env["LESS"] = "-R"
    proc = subprocess.Popen(pager_cmd, shell=True, stdin=subprocess.PIPE, env=env)
    enc = getattr(stdout, "encoding", None) or "utf-8"

    def w(t):
        try:
            proc.stdin.write(t.encode(enc, "replace"))
            proc.stdin.flush()
        except (OSError, ValueError):
            pass

    def close():
        try:
            proc.stdin.close()
        except Exception:
            pass
        while True:
            try:
                proc.wait()
                break
            except KeyboardInterrupt:
                pass

    f = _PagerFile(w, close, strip=not color)
    try:
        yield f
    finally:
        f.close()


def echo_via_pager(text_or_generator, color=None):
    with get_pager_file(color=color) as f:
        for chunk in _chunks(text_or_generator):
            f.write(chunk)
        f.write("\n")


# ---- progress bar ------------------------------------------------------------

def _format_eta(seconds):
    seconds = int(seconds)
    if seconds <= 0:
        return "00:00:00"
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    if h:
        return f"{h}:{m:02d}:{s:02d}"
    return f"{m:02d}:{s:02d}"


class ProgressBar:
    def __init__(self, iterable=None, length=None, label=None, hidden=False, show_eta=True,
                 show_percent=None, show_pos=False, item_show_func=None, fill_char="#",
                 empty_char="-", bar_template="%(label)s  [%(bar)s]  %(info)s", info_sep="  ",
                 width=36, file=None, color=None, update_min_steps=1):
        if iterable is None:
            if length is None:
                raise TypeError("iterable or length is required")
            iterable = range(length)
        self.iter = iter(iterable)
        if length is None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.show_eta = show_eta
        self.show_percent = show_percent if show_percent is not None else (length is not None)
        self.show_pos = show_pos
        self.item_show_func = item_show_func
        self.fill_char = fill_char
        self.empty_char = empty_char
        self.bar_template = bar_template
        self.info_sep = info_sep
        self.width = width
        self.file = file
        self.color = color
        self.pos = 0
        self.finished = False
        self.current_item = None
        self.start = self.last_eta = time.time()
        self._last_line = None
        self._is_atty = None
        self._label_done = False

    def _stream(self):
        return self.file if self.file is not None else sys.stdout

    def __enter__(self):
        self._is_atty = isatty(self._stream())
        self.render_progress()
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.render_finish()

    def __iter__(self):
        if self._is_atty is None:
            self._is_atty = isatty(self._stream())
            self.render_progress()
        return self.generator()

    def __next__(self):
        return next(iter(self))

    def generator(self):
        try:
            for rv in self.iter:
                self.current_item = rv
                yield rv
                self.update(1)
        finally:
            self.finish()
            self.render_progress()

    def update(self, n_steps=1, current_item=None):
        self.pos += n_steps
        if self.length is not None and self.pos >= self.length:
            self.finished = True
        if current_item is not None:
            self.current_item = current_item
        self.render_progress()

    def finish(self):
        self.finished = True

    @property
    def pct(self):
        if self.finished:
            return 1.0
        if not self.length:
            return 0.0
        return min(self.pos / self.length, 1.0)

    @property
    def eta(self):
        if self.length is None or self.finished or self.pos <= 0:
            return 0.0
        elapsed = time.time() - self.start
        return elapsed / self.pos * (self.length - self.pos)

    def format_bar(self):
        if self.length is not None:
            bar_length = int(self.pct * self.width)
            return self.fill_char * bar_length + self.empty_char * (self.width - bar_length)
        return self.empty_char * self.width

    def format_line(self):
        parts = []
        if self.show_pos:
            parts.append(f"{self.pos}/{self.length}" if self.length is not None else str(self.pos))
        if self.show_percent:
            parts.append(f"{int(self.pct * 100): 4}%")
        if self.show_eta and self.length is not None and not self.finished:
            parts.append(_format_eta(math.ceil(self.eta)))
        if self.item_show_func is not None and self.current_item is not None:
            s = self.item_show_func(self.current_item)
            if s:
                parts.append(s)
        info = self.info_sep.join(parts)
        return (self.bar_template % {"label": self.label, "bar": self.format_bar(),
                                     "info": info}).rstrip()

    def render_progress(self):
        if self.hidden:
            return
        stream = self._stream()
        if not self._is_atty:
            if self.label and not self._label_done:
                self._label_done = True
                echo(self.label, file=stream, color=self.color)
            return
        line = self.format_line()
        if line == self._last_line:
            return
        self._last_line = line
        echo("\r" + line, file=stream, nl=False, color=self.color)

    def render_finish(self):
        if self.hidden or not self._is_atty:
            return
        echo(file=self._stream(), color=self.color)


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)


# ---- single char, pause, editor, launch, clear ------------------------------

def _translate_ch_to_exc(ch):
    if ch in ("\x03", b"\x03"):
        raise KeyboardInterrupt()
    if ch in ("\x04", b"\x04", "\x1a", b"\x1a"):
        raise EOFError()


def _unix_getchar(echo_=False):
    import termios
    import tty
    f = None
    if not isatty(sys.stdin):
        f = open("/dev/tty")
        fd = f.fileno()
    else:
        fd = sys.stdin.fileno()
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 32)
            if echo_ and isatty(sys.stdout):
                sys.stdout.write(ch.decode("utf-8", "replace"))
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
            sys.stdout.flush()
    finally:
        if f is not None:
            f.close()
    _translate_ch_to_exc(ch)
    return ch.decode("utf-8", "replace")


_getchar = None


def getchar(echo=False):
    f = _getchar if _getchar is not None else _unix_getchar
    return f(echo)


def pause(info=None, err=False):
    if not isatty(sys.stdin) or not isatty(sys.stdout):
        return
    try:
        if info is None:
            info = "Press any key to continue..."
        if info:
            echo(info, nl=False, err=err)
        try:
            getchar()
        except (KeyboardInterrupt, EOFError):
            pass
    finally:
        if info:
            echo(err=err)


class Editor:
    def __init__(self, editor=None, env=None, require_save=True, extension=".txt"):
        self.editor = editor
        self.env = env
        self.require_save = require_save
        self.extension = extension

    def get_editor(self):
        if self.editor is not None:
            return self.editor
        for key in "VISUAL", "EDITOR":
            rv = os.environ.get(key)
            if rv:
                return rv
        for ed in "sensible-editor", "vim", "nano":
            if shutil.which(ed):
                return ed
        return "vi"

    def edit_file(self, filename):
        editor = self.get_editor()
        environ = None
        if self.env:
            environ = os.environ.copy()
            environ.update(self.env)
        try:
            c = subprocess.Popen(f'{editor} "{filename}"', env=environ, shell=True)
            exit_code = c.wait()
            if exit_code != 0:
                raise OptlynException(f"{editor}: Editing failed")
        except OSError as e:
            raise OptlynException(f"{editor}: Editing failed: {e}") from e

    def edit(self, text):
        import tempfile
        if not text:
            data = b""
        elif isinstance(text, (bytes, bytearray)):
            data = bytes(text)
        else:
            data = text.encode("utf-8")
        fd, name = tempfile.mkstemp(prefix="editor-", suffix=self.extension)
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(data)
            before = os.stat(name).st_mtime_ns
            self.edit_file(name)
            if self.require_save and os.stat(name).st_mtime_ns == before:
                return None
            with open(name, "rb") as f:
                rv = f.read()
            return rv.decode("utf-8-sig").replace("\r\n", "\n")
        finally:
            try:
                os.unlink(name)
            except OSError:
                pass


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    ed = Editor(editor=editor, env=env, require_save=require_save, extension=extension)
    if filename is None:
        return ed.edit(text)
    ed.edit_file(filename)


def _unquote_file(url):
    from urllib.parse import unquote
    if url.startswith("file://"):
        url = unquote(url[7:])
    return url


def launch(url, wait=False, locate=False):
    url = os.fspath(url) if not isinstance(url, str) else url
    if locate:
        url = os.path.dirname(_unquote_file(url)) or "."
    else:
        url = _unquote_file(url)
    try:
        c = subprocess.Popen(["xdg-open", url])
        if wait:
            return c.wait()
        return 0
    except OSError:
        return 127


def clear():
    if not isatty(sys.stdout):
        return
    echo("\033[2J\033[1;1H", nl=False)
