"""Stream helpers, echo, styling, file helpers."""
from __future__ import annotations

import codecs
import io
import os
import re
import sys

from .globals import resolve_color_default

_ansi_re = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")


class InvalidColor(TypeError, ValueError):
    """Raised by ``style`` for a colour that is not valid."""


def strip_ansi(value):
    return _ansi_re.sub("", value)


def term_len(x):
    return len(strip_ansi(x))


def isatty(stream):
    try:
        return stream.isatty()
    except Exception:
        return False


def make_str(value):
    if isinstance(value, bytes):
        try:
            return value.decode(sys.getfilesystemencoding())
        except UnicodeError:
            return value.decode("utf-8", "replace")
    return str(value)


def should_strip_ansi(stream=None, color=None):
    if color is None:
        if stream is None:
            stream = sys.stdin
        return not isatty(stream)
    return not color


def _find_binary_writer(stream):
    if isinstance(stream, (io.RawIOBase, io.BufferedIOBase)):
        return stream
    buf = getattr(stream, "buffer", None)
    if buf is not None:
        return buf
    return None


def _is_ascii_encoding(stream):
    enc = getattr(stream, "encoding", None)
    if not enc:
        return False
    try:
        return codecs.lookup(enc).name == "ascii"
    except LookupError:
        return False


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write text or bytes to stdout/stderr/file, stripping styles when needed."""
    if file is None:
        file = sys.stderr if err else sys.stdout
        if file is None:
            return
    if message is not None and not isinstance(message, (str, bytes, bytearray)):
        out = str(message)
    else:
        out = message
    if nl:
        out = out or ""
        out += b"\n" if isinstance(out, (bytes, bytearray)) else "\n"
    if not out:
        try:
            file.flush()
        except Exception:
            pass
        return
    if isinstance(out, (bytes, bytearray)):
        binary = _find_binary_writer(file)
        if binary is not None:
            file.flush()
            binary.write(bytes(out))
            binary.flush()
            return
        out = bytes(out).decode("utf-8", "replace")
    else:
        color = resolve_color_default(color)
        if should_strip_ansi(file, color):
            out = strip_ansi(out)
    if _is_ascii_encoding(file):
        buf = _find_binary_writer(file)
        if buf is not None and buf is not file:
            file.flush()
            buf.write(out.encode("utf-8"))
            buf.flush()
            return
    try:
        file.write(out)
    except UnicodeEncodeError:
        buf = _find_binary_writer(file)
        if buf is None or buf is file:
            file.write(out.encode("ascii", "replace").decode("ascii"))
        else:
            file.flush()
            buf.write(out.encode("utf-8"))
            buf.flush()
            return
    file.flush()


_ansi_colors = {
    "black": 30, "red": 31, "green": 32, "yellow": 33, "blue": 34, "magenta": 35,
    "cyan": 36, "white": 37, "reset": 39,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
}


def _interpret_color(color, offset=0):
    if isinstance(color, bool):
        raise InvalidColor(f"Unknown color {color!r}")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise InvalidColor(f"Color out of range {color!r}")
        return f"{38 + offset};5;{color:d}"
    if isinstance(color, (tuple, list)):
        if len(color) != 3 or not all(
            isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
        ):
            raise InvalidColor(f"Invalid color {color!r}")
        r, g, b = color
        return f"{38 + offset};2;{r:d};{g:d};{b:d}"
    if isinstance(color, str) and color in _ansi_colors:
        return str(_ansi_colors[color] + offset)
    raise InvalidColor(f"Unknown color {color!r}")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True):
    if not isinstance(text, str):
        text = str(text)
    bits = []
    if fg is not None:
        bits.append(f"\033[{_interpret_color(fg)}m")
    if bg is not None:
        bits.append(f"\033[{_interpret_color(bg, 10)}m")
    for val, on, off in ((bold, 1, 22), (dim, 2, 22), (underline, 4, 24), (overline, 53, 55),
                         (italic, 3, 23), (blink, 5, 25), (reverse, 7, 27),
                         (strikethrough, 9, 29)):
        if val is not None:
            bits.append(f"\033[{on if val else off}m")
    bits.append(text)
    if reset:
        bits.append("\033[0m")
    return "".join(bits)


def unstyle(text):
    return strip_ansi(text)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None and not isinstance(message, (bytes, bytearray)):
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def format_filename(filename, shorten=False):
    if shorten:
        filename = os.path.basename(filename)
    else:
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        filename = filename.decode(sys.getfilesystemencoding(), "replace")
    else:
        filename = filename.encode("utf-8", "surrogateescape").decode("utf-8", "replace")
    return filename


def _posixify(name):
    return "-".join(name.split()).lower()


def get_app_dir(app_name, roaming=True, force_posix=False):
    if sys.platform.startswith("win"):
        key = "APPDATA" if roaming else "LOCALAPPDATA"
        folder = os.environ.get(key) or os.path.expanduser("~")
        return os.path.join(folder, app_name)
    if force_posix:
        return os.path.join(os.path.expanduser(f"~/.{_posixify(app_name)}"))
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~/Library/Application Support"), app_name)
    return os.path.join(
        os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config"),
        _posixify(app_name),
    )


def safecall(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception:
            pass
    return wrapper


# ---- standard streams -------------------------------------------------------

class _NonClosingTextIOWrapper(io.TextIOWrapper):
    def __del__(self):
        try:
            self.detach()
        except Exception:
            pass

    def close(self):
        try:
            self.flush()
        except Exception:
            pass


def _stream_for(stream, encoding, errors, writable):
    if encoding is None and errors in (None, "strict"):
        return stream
    cur = getattr(stream, "encoding", None)
    buf = getattr(stream, "buffer", None)
    if buf is None:
        return stream
    if encoding is not None and cur and codecs.lookup(cur).name == codecs.lookup(encoding).name \
            and errors in (None, "strict", getattr(stream, "errors", None)):
        return stream
    return _NonClosingTextIOWrapper(buf, encoding=encoding or cur or "utf-8",
                                    errors=errors or "strict", line_buffering=True)


def get_text_stdout(encoding=None, errors=None):
    return _stream_for(sys.stdout, encoding, errors, True)


def get_text_stderr(encoding=None, errors=None):
    return _stream_for(sys.stderr, encoding, errors, True)


def get_text_stdin(encoding=None, errors=None):
    return _stream_for(sys.stdin, encoding, errors, False)


def get_binary_stdout():
    return getattr(sys.stdout, "buffer", sys.stdout)


def get_binary_stderr():
    return getattr(sys.stderr, "buffer", sys.stderr)


def get_binary_stdin():
    return getattr(sys.stdin, "buffer", sys.stdin)


def get_text_stream(name, encoding=None, errors="strict"):
    return {"stdin": get_text_stdin, "stdout": get_text_stdout, "stderr": get_text_stderr}[name](
        encoding, errors)


def get_binary_stream(name):
    return {"stdin": get_binary_stdin, "stdout": get_binary_stdout,
            "stderr": get_binary_stderr}[name]()


# ---- files -------------------------------------------------------------------

class _AtomicFile:
    def __init__(self, f, tmp_filename, real_filename):
        self._f = f
        self._tmp_filename = tmp_filename
        self._real_filename = real_filename
        self.closed = False

    @property
    def name(self):
        return self._real_filename

    def close(self, delete=False):
        if self.closed:
            return
        self._f.close()
        os.replace(self._tmp_filename, self._real_filename)
        self.closed = True
        if delete:
            pass

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.close(delete=exc_type is not None)

    def __repr__(self):
        return repr(self._f)

    def __iter__(self):
        return iter(self._f)


def open_stream(filename, mode="r", encoding=None, errors="strict", atomic=False):
    binary = "b" in mode
    filename = os.fspath(filename)
    if filename == "-" or filename == b"-":
        if any(m in mode for m in ("w", "a", "x")):
            if binary:
                return get_binary_stdout(), False
            return get_text_stdout(encoding=encoding, errors=errors), False
        if binary:
            return get_binary_stdin(), False
        return get_text_stdin(encoding=encoding, errors=errors), False
    if not atomic:
        return open(filename, mode, encoding=encoding, errors=errors), True
    if "x" in mode:
        raise ValueError("Use the 'overwrite'-parameter instead.")
    if "r" in mode or "+" in mode:
        raise ValueError("Atomic writes only make sense with 'w'-mode.")
    import random
    flags = os.O_RDWR | os.O_CREAT | os.O_EXCL
    perm = 0o666
    try:
        perm = os.stat(filename).st_mode & 0o777
    except OSError:
        pass
    while True:
        tmp = os.path.join(os.path.dirname(filename) or ".",
                           f".__atomic-write{random.randrange(1 << 32):08x}")
        try:
            fd = os.open(tmp, flags, perm)
            break
        except FileExistsError:
            continue
    f = open(fd, mode, encoding=encoding, errors=errors)
    return _AtomicFile(f, tmp, os.path.realpath(filename)), True


class LazyFile:
    """A file that opens on first I/O."""

    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False):
        self.name = os.fspath(filename)
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self.should_close = True
        if self.name == "-":
            self._f, self.should_close = open_stream(filename, mode, encoding, errors)
        elif "r" in mode:
            try:
                open(filename, mode).close()
            except OSError as e:
                from .exceptions import FileError
                raise FileError(self.name, hint=e.strerror) from e

    def __getattr__(self, name):
        return getattr(self.open(), name)

    def __repr__(self):
        if self._f is not None:
            return repr(self._f)
        return f"<unopened file '{format_filename(self.name)}' {self.mode}>"

    def open(self):
        if self._f is not None:
            return self._f
        try:
            rv, self.should_close = open_stream(self.name, self.mode, self.encoding,
                                                self.errors, atomic=self.atomic)
        except OSError as e:
            from .exceptions import FileError
            raise FileError(self.name, hint=e.strerror) from e
        self._f = rv
        return rv

    def close(self):
        if self._f is not None:
            self._f.close()

    def close_intelligently(self):
        if self.should_close:
            self.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.close_intelligently()

    def __iter__(self):
        self.open()
        return iter(self._f)


class KeepOpenFile:
    def __init__(self, file):
        self._file = file

    def __getattr__(self, name):
        return getattr(self._file, name)

    def close(self):
        try:
            self._file.flush()
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        pass

    def __repr__(self):
        return repr(self._file)

    def __iter__(self):
        return iter(self._file)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    f, should_close = open_stream(filename, mode, encoding, errors, atomic=atomic)
    if not should_close:
        f = KeepOpenFile(f)
    return f
