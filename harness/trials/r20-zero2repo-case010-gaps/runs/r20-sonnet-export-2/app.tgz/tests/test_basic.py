import pytest
from lingora.metrics import edit_distance, accuracy, precision, f_measure, jaccard_distance
from lingora.translate import bleu
from lingora.classify import NaiveBayesClassifier, DecisionTreeClassifier, accuracy as cacc
from lingora.tree import Tree
from lingora.tokenize import wordpunct_tokenize, RegexpTokenizer


def test_edit_distance():
    assert edit_distance("rain", "shine") == 3
    assert edit_distance("abc", "ca", transpositions=True) == 2
    assert edit_distance("", "") == 0


def test_metrics():
    assert precision({1, 2}, set()) is None
    with pytest.raises(TypeError):
        precision([1], {1})
    with pytest.raises(ValueError):
        accuracy([1], [1, 2])
    assert f_measure({1, 2}, {1}) == pytest.approx(2 / 3)
    assert jaccard_distance({1, 2}, {2, 3}) == pytest.approx(2 / 3)


def test_bleu():
    ref = "the cat is on the mat".split()
    assert bleu([ref], ref) == pytest.approx(1.0)
    assert bleu([ref], ["x"]) == 0


def test_classifiers():
    data = [({"a": 1}, "x"), ({"a": 2}, "y")] * 3
    nb = NaiveBayesClassifier.train(data)
    assert nb.classify({"a": 1}) == "x"
    assert sum(nb.prob_classify({"a": 1}).prob(l) for l in nb.labels()) == pytest.approx(1)
    dt = DecisionTreeClassifier.train(data)
    assert cacc(dt, data) == 1.0


def test_tree():
    t = Tree.fromstring("(S (NP I) (VP (V saw)))")
    assert t == Tree("S", [Tree("NP", ["I"]), Tree("VP", [Tree("V", ["saw"])])])
    assert t.leaves() == ["I", "saw"]
    with pytest.raises(TypeError):
        Tree("S", "abc")
    with pytest.raises(TypeError):
        Tree("S")
    assert len(Tree("S", [])) == 0


def test_tokenizers():
    assert wordpunct_tokenize("Hi, you!") == ["Hi", ",", "you", "!"]
    assert wordpunct_tokenize("  ") == []
    assert RegexpTokenizer(",", gaps=True).tokenize("a,,b") == ["a", "b"]
