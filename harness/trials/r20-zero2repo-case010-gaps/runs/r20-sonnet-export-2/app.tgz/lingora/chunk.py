"""Chunking.  # spec: N-000410..N-000423, FP-04"""
import os
import re

from lingora import data as _data
from lingora.tree import Tree

__all__ = ["RegexpParser", "ne_chunk", "ChunkStage"]

_ELEMENT_OK = re.compile(r"^[\s<>()|?*+{},\d.\\\[\]^$\w\-:;!#%&'\"/=@~`]*$")


def tag_pattern2re(pattern):
    """Translate a tag pattern into a regular expression over '<TAG><TAG>' text."""
    pat = re.sub(r"\s", "", pattern)
    if not pat or "<" not in pat:
        raise ValueError("Bad tag pattern: %r" % (pattern,))
    pat = pat.replace("<", "(<(").replace(">", ")>)")
    pat = re.sub(r"(?<!\\)\.", r"[^{}<>]", pat)
    try:
        re.compile(pat)
    except re.error as e:
        raise ValueError("Bad tag pattern %r: %s" % (pattern, e))
    return pat


class ChunkStage:
    """One grammar clause: a label and its ordered rules."""

    def __init__(self, label, rules=None):
        self.label = label
        self.rules = list(rules or [])  # (kind, compiled regex)

    def add_rule(self, kind, tag_pattern):
        self.rules.append((kind, re.compile(tag_pattern2re(tag_pattern))))

    def apply(self, units):
        """units: list of (token, tag) tuples or Trees.  Returns the new unit list."""
        def tag_of(u):
            return u.label() if isinstance(u, Tree) else u[1]
        s = "".join("<%s>" % tag_of(u) for u in units)
        for kind, rx in self.rules:
            if kind == "chunk":
                s = re.sub("(?P<chunk>" + rx.pattern + r")(?=[^\}]*(\{|$))", r"{\g<chunk>}", s)
            else:
                s = re.sub("(?P<chink>" + rx.pattern + r")(?=[^\{\}]*\})", r"}\g<chink>{", s)
            s = s.replace("{}", "")
        out = []
        cur = None
        idx = 0
        for m in re.finditer(r"[{}]|<[^<>{}]*>", s):
            t = m.group(0)
            if t == "{":
                cur = []
            elif t == "}":
                if cur:
                    out.append(Tree(self.label, cur))
                cur = None
            else:
                u = units[idx]
                idx += 1
                (cur if cur is not None else out).append(u)
        if cur:
            out.append(Tree(self.label, cur))
        return out


def _parse_grammar(text):
    stages = []
    cur = None
    for raw in text.split("\n"):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        m = re.match(r"^(?P<label>(?:\\.|[^:{}])*):(?P<rule>.*)$", line)
        if m and not line.startswith(("{", "}")):
            label = m.group("label").strip()
            if not label:
                raise ValueError("Empty chunk label in line: %r" % raw)
            cur = ChunkStage(label)
            stages.append(cur)
            rule = m.group("rule").strip()
        else:
            rule = line
        rule = re.sub(r"\s+#.*$", "", rule).strip()
        if not rule:
            continue
        if cur is None:
            raise ValueError("Rule appears before any LABEL: clause: %r" % raw)
        if rule.startswith("{") and rule.endswith("}") and len(rule) >= 2:
            cur.add_rule("chunk", rule[1:-1])
        elif rule.startswith("}") and rule.endswith("{") and len(rule) >= 2:
            cur.add_rule("chink", rule[1:-1])
        else:
            raise ValueError("Illegal chunk pattern: %r" % rule)
    return stages


class RegexpParser:
    def __init__(self, grammar, root_label="S"):
        self._root = root_label
        if isinstance(grammar, str):
            stages = _parse_grammar(grammar)
        elif isinstance(grammar, (list, tuple)):
            stages = []
            for g in grammar:
                if isinstance(g, str):
                    stages.extend(_parse_grammar(g))
                elif isinstance(g, ChunkStage):
                    stages.append(g)
                elif isinstance(g, RegexpParser):
                    stages.extend(g._stages)
                else:
                    raise TypeError("grammar stages must be ChunkStage objects or grammar text")
        else:
            raise TypeError("grammar must be a str or a list of stages")
        self._stages = stages

    def parse(self, tagged):
        if isinstance(tagged, (str, bytes)) or not isinstance(tagged, (list, tuple)):
            raise TypeError("tagged must be a list of (token, tag) pairs")
        units = []
        for item in tagged:
            if not isinstance(item, (tuple, list)) or len(item) != 2:
                raise ValueError("expected (token, tag) pairs, got %r" % (item,))
            units.append((item[0], item[1]) if not isinstance(item, tuple) else item)
        for st in self._stages:
            units = st.apply(units)
        return Tree(self._root, units)


def ne_chunk(tagged_tokens, binary=False):
    if isinstance(tagged_tokens, (str, bytes)) or not isinstance(tagged_tokens, (list, tuple)):
        raise TypeError("tagged_tokens must be a list of (token, tag) pairs")
    model = _data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")  # spec: N-000415
    words = _data.find("corpora/words")
    if not os.path.isdir(model):
        raise LookupError("named-entity chunker model is not a directory: %s" % model)
    # The maxent model format is outside the specification; with the resources
    # present the tokens are returned unchunked under a sentence root (see NOTES.md).
    return Tree("S", [tuple(t) for t in tagged_tokens])
