"""Stemmers and lemmatizer.  # spec: N-000389..N-000396, FP-02"""
import os
import re

from lingora import data as _data

__all__ = ["ARLSTem", "ARLSTem2", "LancasterStemmer", "PorterStemmer", "RegexpStemmer",
           "SnowballStemmer", "WordNetLemmatizer"]


def _check_word(word):
    if not isinstance(word, str):
        raise TypeError("word must be a str, not %s" % type(word).__name__)


# ------------------------------------------------------------------ Porter
class PorterStemmer:
    ORIGINAL_ALGORITHM = "ORIGINAL_ALGORITHM"
    MARTIN_EXTENSIONS = "MARTIN_EXTENSIONS"
    NLTK_EXTENSIONS = "NLTK_EXTENSIONS"  # the LINGORA extensions (default)

    def __init__(self, mode=NLTK_EXTENSIONS):
        if mode not in (self.ORIGINAL_ALGORITHM, self.MARTIN_EXTENSIONS, self.NLTK_EXTENSIONS):
            raise ValueError("Mode must be one of ORIGINAL_ALGORITHM, MARTIN_EXTENSIONS, NLTK_EXTENSIONS")
        self.mode = mode
        irregular = {
            "sky": ["sky", "skies"], "die": ["dying"], "lie": ["lying"], "tie": ["tying"],
            "news": ["news"], "inning": ["innings", "inning"], "outing": ["outings", "outing"],
            "canning": ["cannings", "canning"], "howe": ["howe"], "proceed": ["proceed"],
            "exceed": ["exceed"], "succeed": ["succeed"],
        }
        self.pool = {f: stem for stem, forms in irregular.items() for f in forms}
        self.vowels = frozenset("aeiou")

    def _is_consonant(self, word, i):
        if word[i] in self.vowels:
            return False
        if word[i] == "y":
            if i == 0:
                return True
            return not self._is_consonant(word, i - 1)
        return True

    def _measure(self, stem):
        cv = "".join("c" if self._is_consonant(stem, i) else "v" for i in range(len(stem)))
        return cv.count("vc")

    def _has_positive_measure(self, stem):
        return self._measure(stem) > 0

    def _contains_vowel(self, stem):
        return any(not self._is_consonant(stem, i) for i in range(len(stem)))

    def _ends_double_consonant(self, word):
        return len(word) >= 2 and word[-1] == word[-2] and self._is_consonant(word, len(word) - 1)

    def _ends_cvc(self, word):
        return (
            len(word) >= 3
            and self._is_consonant(word, len(word) - 3)
            and not self._is_consonant(word, len(word) - 2)
            and self._is_consonant(word, len(word) - 1)
            and word[-1] not in ("w", "x", "y")
        ) or (
            self.mode == self.NLTK_EXTENSIONS
            and len(word) == 2
            and not self._is_consonant(word, 0)
            and self._is_consonant(word, 1)
        )

    @staticmethod
    def _replace_suffix(word, suffix, replacement):
        if suffix == "":
            return word + replacement
        return word[:-len(suffix)] + replacement

    def _apply_rule_list(self, word, rules):
        for suffix, replacement, condition in rules:
            if suffix == "*d" and self._ends_double_consonant(word):
                stem = word[:-2]
                if condition is None or condition(stem):
                    return stem + replacement
                return word
            if word.endswith(suffix):
                stem = self._replace_suffix(word, suffix, "")
                if condition is None or condition(stem):
                    return stem + replacement
                return word
        return word

    def _step1a(self, word):
        if self.mode == self.NLTK_EXTENSIONS:
            if word.endswith("ies") and len(word) == 4:
                return self._replace_suffix(word, "ies", "ie")
        return self._apply_rule_list(word, [("sses", "ss", None), ("ies", "i", None),
                                            ("ss", "ss", None), ("s", "", None)])

    def _step1b(self, word):
        if self.mode == self.NLTK_EXTENSIONS:
            if word.endswith("ied"):
                if len(word) == 4:
                    return self._replace_suffix(word, "ied", "ie")
                return self._replace_suffix(word, "ied", "i")
        if word.endswith("eed"):
            stem = self._replace_suffix(word, "eed", "")
            if self._measure(stem) > 0:
                return stem + "ee"
            return word
        ok = False
        inter = word
        for suffix in ["ed", "ing"]:
            if word.endswith(suffix):
                inter = self._replace_suffix(word, suffix, "")
                if self._contains_vowel(inter):
                    ok = True
                    break
        if not ok:
            return word
        return self._apply_rule_list(inter, [
            ("at", "ate", None), ("bl", "ble", None), ("iz", "ize", None),
            ("*d", inter[-1], lambda stem: inter[-1] not in ("l", "s", "z")),
            ("", "e", lambda stem: self._measure(stem) == 1 and self._ends_cvc(stem)),
        ])

    def _step1c(self, word):
        def nltk_cond(stem):
            return len(stem) > 1 and self._is_consonant(stem, len(stem) - 1)
        cond = nltk_cond if self.mode == self.NLTK_EXTENSIONS else self._contains_vowel
        return self._apply_rule_list(word, [("y", "i", cond)])

    def _step2(self, word):
        if self.mode == self.NLTK_EXTENSIONS:
            if word.endswith("alli") and self._has_positive_measure(self._replace_suffix(word, "alli", "")):
                return self._step2(self._replace_suffix(word, "alli", "al"))
        pm = self._has_positive_measure
        bli = ("bli", "ble", pm)
        abli = ("abli", "able", pm)
        rules = [
            ("ational", "ate", pm), ("tional", "tion", pm), ("enci", "ence", pm), ("anci", "ance", pm),
            ("izer", "ize", pm), abli if self.mode == self.ORIGINAL_ALGORITHM else bli,
            ("alli", "al", pm), ("entli", "ent", pm), ("eli", "e", pm), ("ousli", "ous", pm),
            ("ization", "ize", pm), ("ation", "ate", pm), ("ator", "ate", pm), ("alism", "al", pm),
            ("iveness", "ive", pm), ("fulness", "ful", pm), ("ousness", "ous", pm),
            ("aliti", "al", pm), ("iviti", "ive", pm), ("biliti", "ble", pm),
        ]
        if self.mode == self.NLTK_EXTENSIONS:
            rules.append(("fulli", "ful", pm))
            rules.append(("logi", "log", lambda stem: pm(word[:-len("ogi")])))
        if self.mode == self.MARTIN_EXTENSIONS:
            rules.append(("logi", "log", pm))
        return self._apply_rule_list(word, rules)

    def _step3(self, word):
        pm = self._has_positive_measure
        return self._apply_rule_list(word, [
            ("icate", "ic", pm), ("ative", "", pm), ("alize", "al", pm), ("iciti", "ic", pm),
            ("ical", "ic", pm), ("ful", "", pm), ("ness", "", pm)])

    def _step4(self, word):
        gt1 = lambda stem: self._measure(stem) > 1
        return self._apply_rule_list(word, [
            ("al", "", gt1), ("ance", "", gt1), ("ence", "", gt1), ("er", "", gt1), ("ic", "", gt1),
            ("able", "", gt1), ("ible", "", gt1), ("ant", "", gt1), ("ement", "", gt1),
            ("ment", "", gt1), ("ent", "", gt1),
            ("ion", "", lambda stem: self._measure(stem) > 1 and stem[-1:] in ("s", "t")),
            ("ou", "", gt1), ("ism", "", gt1), ("ate", "", gt1), ("iti", "", gt1), ("ous", "", gt1),
            ("ive", "", gt1), ("ize", "", gt1)])

    def _step5a(self, word):
        if word.endswith("e"):
            stem = self._replace_suffix(word, "e", "")
            if self._measure(stem) > 1:
                return stem
            if self._measure(stem) == 1 and not self._ends_cvc(stem):
                return stem
        return word

    def _step5b(self, word):
        return self._apply_rule_list(word, [("ll", "l", lambda stem: self._measure(word[:-1]) > 1)])

    def stem(self, word, to_lowercase=True):
        _check_word(word)
        stem = word.lower() if to_lowercase else word
        if self.mode == self.NLTK_EXTENSIONS and stem in self.pool:
            return self.pool[stem]
        if self.mode != self.ORIGINAL_ALGORITHM and len(word) <= 2:
            return stem
        stem = self._step1a(stem)
        stem = self._step1b(stem)
        stem = self._step1c(stem)
        stem = self._step2(stem)
        stem = self._step3(stem)
        stem = self._step4(stem)
        stem = self._step5a(stem)
        stem = self._step5b(stem)
        return stem

    def __repr__(self):
        return "<PorterStemmer>"


# --------------------------------------------------------------- Lancaster
_LANCASTER_RULES = (
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>", "cn1t>", "dd1.", "dei3y>", "deec2ss.", "dee1.",
    "de2>", "dooh4>", "e1>", "feil1v.", "fi2>", "gni3>", "gai3y.", "ga2>", "gg1.", "ht*2.",
    "hsiug5ct.", "hsi3>", "i*1.", "i1y>", "ji1d.", "juf1s.", "ju1d.", "jo1d.", "jeh1r.", "jrev1t.",
    "jsim2t.", "jn1d.", "j1s.", "lbaifi6.", "lbai4y.", "lba3>", "lbi3.", "lib2l>", "lc1.",
    "lufi4y.", "luf3>", "lu2.", "lai3>", "lau3>", "la2>", "ll1.", "mui3.", "mu*2.", "msi3>",
    "mm1.", "nois4j>", "noix4ct.", "noi3>", "nai3>", "na2>", "nee0.", "ne2>", "nn1.", "pihs4>",
    "pp1.", "re2>", "rae0.", "ra2.", "ro2>", "ru2>", "rr1.", "rt1>", "rei3y>", "sei3y>", "sis2.",
    "si2>", "ssen4>", "ss0.", "suo3>", "su*2.", "s*1>", "s0.", "tacilp4y.", "ta2>", "tnem4>",
    "tne3>", "tna3>", "tpir2b.", "tpro2b.", "tcud1.", "tpmus2.", "tpec2iv.", "tulo2v.", "tsis0.",
    "tsi3>", "tt1.", "uqi3.", "ugo1.", "vis3j>", "vie0.", "vi2>", "ylb1>", "yli3y>", "ylp0.",
    "yl2>", "ygo1.", "yhp1.", "ymo1.", "ypo1.", "yti3>", "yte3>", "ytl2.", "yrtsi5.", "yra3>",
    "yro3>", "yfi3.", "ycn2t>", "yca3>", "zi2>", "zy1s.",
)
_LANC_VALID = re.compile(r"^([a-z]+)(\*?)(\d)([a-z]*)([>\.]?)$")


class LancasterStemmer:
    def __init__(self, rule_tuple=None, strip_prefix_flag=False):
        self.rule_dictionary = {}
        self._strip_prefix = strip_prefix_flag
        for rule in (rule_tuple or _LANCASTER_RULES):
            self.rule_dictionary.setdefault(rule[0], []).append(rule)

    @staticmethod
    def _last_letter(word):
        last = -1
        for pos, ch in enumerate(word):
            if ch.isalpha():
                last = pos
            else:
                break
        return last

    @staticmethod
    def _acceptable(word, remove_total):
        if word[0] in "aeiouy":
            return len(word) - remove_total >= 2
        if len(word) - remove_total >= 3:
            return word[1] in "aeiouy" or word[2] in "aeiouy"
        return False

    def stem(self, word):
        _check_word(word)
        word = word.lower()
        intact_word = word
        proceed = True
        while proceed:
            last = self._last_letter(word)
            if last < 0 or word[last] not in self.rule_dictionary:
                break
            applied = False
            for rule in self.rule_dictionary[word[last]]:
                m = _LANC_VALID.match(rule)
                if not m:
                    continue
                ending, intact_flag, remove_total, append, cont = m.groups()
                remove_total = int(remove_total)
                if word.endswith(ending[::-1]):
                    if intact_flag:
                        if word == intact_word and self._acceptable(word, remove_total):
                            word = word[:len(word) - remove_total] + append
                            applied = True
                            if cont == ".":
                                proceed = False
                            break
                    elif self._acceptable(word, remove_total):
                        word = word[:len(word) - remove_total] + append
                        applied = True
                        if cont == ".":
                            proceed = False
                        break
            if not applied:
                proceed = False
        return word


# ------------------------------------------------------------------ Regexp
class RegexpStemmer:
    def __init__(self, regexp, min=0):
        if isinstance(regexp, str):
            regexp = re.compile(regexp)
        self._regexp = regexp
        self._min = min

    def stem(self, word):
        _check_word(word)
        if len(word) < self._min:
            return word
        return self._regexp.sub("", word)


# ---------------------------------------------------------------- Snowball
_SB_LANGUAGES = ("arabic", "danish", "dutch", "english", "finnish", "french", "german",
                 "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
                 "russian", "spanish", "swedish")


class _EnglishSnowball:
    """Porter2 (English) algorithm, Snowball 2.2."""
    vowels = "aeiouy"
    double = ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")
    li_ending = "cdeghkmnrt"
    special = {"skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
               "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli",
               "only": "onli", "singly": "singl", "sky": "sky", "news": "news", "howe": "howe",
               "atlas": "atlas", "cosmos": "cosmos", "bias": "bias", "andes": "andes"}
    keep_after_1a = ("inning", "outing", "canning", "herring", "earring", "proceed", "exceed",
                     "succeed")
    step2 = (("ization", "ize"), ("ational", "ate"), ("fulness", "ful"), ("ousness", "ous"),
             ("iveness", "ive"), ("tional", "tion"), ("biliti", "ble"), ("lessli", "less"),
             ("entli", "ent"), ("ation", "ate"), ("alism", "al"), ("aliti", "al"), ("ousli", "ous"),
             ("iviti", "ive"), ("fulli", "ful"), ("enci", "ence"), ("anci", "ance"), ("abli", "able"),
             ("izer", "ize"), ("ator", "ate"), ("alli", "al"), ("bli", "ble"), ("ogi", "og"),
             ("li", ""))
    step3 = (("ational", "ate"), ("tional", "tion"), ("alize", "al"), ("icate", "ic"),
             ("iciti", "ic"), ("ative", ""), ("ical", "ic"), ("ness", ""), ("ful", ""))
    step4 = ("ement", "ance", "ence", "able", "ible", "ment", "ant", "ent", "ism", "ate", "iti",
             "ous", "ive", "ize", "ion", "al", "er", "ic")

    def _regions(self, w):
        v = self.vowels
        if w.startswith(("gener", "arsen")):
            r1 = 5
        elif w.startswith("commun"):
            r1 = 6
        else:
            r1 = len(w)
            for i in range(1, len(w)):
                if w[i] not in v and w[i - 1] in v:
                    r1 = i + 1
                    break
        r2 = len(w)
        for i in range(r1 + 1, len(w)):
            if w[i] not in v and w[i - 1] in v:
                r2 = i + 1
                break
        return r1, r2

    def _short_syllable_end(self, w):
        v = self.vowels
        if len(w) == 2:
            return w[0] in v and w[1] not in v
        if len(w) >= 3:
            return (w[-1] not in v and w[-1] not in "wxY" and w[-2] in v and w[-3] not in v)
        return False

    def stem(self, word):
        w = word.lower()
        if len(w) <= 2:
            return w
        if w in self.special:
            return self.special[w]
        w = w.replace("’", "'").replace("‘", "'").replace("‛", "'")
        if w.startswith("'"):
            w = w[1:]
        if w.startswith("y"):
            w = "Y" + w[1:]
        v = self.vowels
        chars = list(w)
        for i in range(1, len(chars)):
            if chars[i - 1] in v and chars[i] == "y":
                chars[i] = "Y"
        w = "".join(chars)
        r1, r2 = self._regions(w)
        # step 0
        for suf in ("'s'", "'s", "'"):
            if w.endswith(suf):
                w = w[:-len(suf)]
                break
        # step 1a
        if w.endswith("sses"):
            w = w[:-2]
        elif w.endswith(("ied", "ies")):
            w = w[:-2] if len(w) - 3 > 1 else w[:-1]
        elif w.endswith(("us", "ss")):
            pass
        elif w.endswith("s"):
            if any(c in v for c in w[:-2]):
                w = w[:-1]
        if w in self.keep_after_1a:
            return w
        r1 = min(r1, len(w))
        r2 = min(r2, len(w))
        # step 1b
        for suf in ("eedly", "ingly", "edly", "eed", "ing", "ed"):
            if w.endswith(suf):
                if suf in ("eed", "eedly"):
                    if len(w) - len(suf) >= r1:
                        w = w[:-len(suf)] + "ee"
                else:
                    base = w[:-len(suf)]
                    if any(c in v for c in base):
                        w = base
                        if w.endswith(("at", "bl", "iz")):
                            w += "e"
                        elif w.endswith(self.double):
                            w = w[:-1]
                        elif r1 >= len(w) and self._short_syllable_end(w):
                            w += "e"
                break
        r1 = min(r1, len(w))
        r2 = min(r2, len(w))
        # step 1c
        if len(w) > 2 and w[-1] in "yY" and w[-2] not in v:
            w = w[:-1] + "i"
        # step 2
        for suf, rep in self.step2:
            if w.endswith(suf):
                pos = len(w) - len(suf)
                if pos >= r1:
                    if suf == "ogi":
                        if w[pos - 1:pos] == "l":
                            w = w[:pos] + rep
                    elif suf == "li":
                        if w[pos - 1:pos] != "" and w[pos - 1] in self.li_ending:
                            w = w[:pos]
                    else:
                        w = w[:pos] + rep
                break
        # step 3
        for suf, rep in self.step3:
            if w.endswith(suf):
                pos = len(w) - len(suf)
                if pos >= r1:
                    if suf == "ative":
                        if pos >= r2:
                            w = w[:pos]
                    else:
                        w = w[:pos] + rep
                break
        # step 4
        for suf in self.step4:
            if w.endswith(suf):
                pos = len(w) - len(suf)
                if pos >= r2:
                    if suf == "ion":
                        if w[pos - 1:pos] in ("s", "t") and pos >= 1:
                            w = w[:pos]
                    else:
                        w = w[:pos]
                break
        # step 5
        if w.endswith("e"):
            pos = len(w) - 1
            if pos >= r2 or (pos >= r1 and not self._short_syllable_end(w[:-1])):
                w = w[:-1]
        elif w.endswith("l"):
            pos = len(w) - 1
            if pos >= r2 and w[-2:-1] == "l":
                w = w[:-1]
        return w.replace("Y", "y")


class _PorterSnowball:
    def __init__(self):
        self._p = PorterStemmer(PorterStemmer.ORIGINAL_ALGORITHM)

    def stem(self, word):
        return self._p.stem(word.lower())


class _GenericSnowball:
    """Light suffix stripper used for the languages whose full Snowball
    algorithm is not implemented (see NOTES.md)."""
    _SUFFIXES = {
        "danish": ("erendes", "erende", "hedens", "ethed", "heden", "heder", "endes", "ernes", "erede", "erens", "eres", "ende", "ene", "ens", "ers", "ede", "es", "er", "et", "en", "e", "s"),
        "dutch": ("heden", "ende", "ingen", "heid", "en", "je", "e", "s"),
        "finnish": ("ssa", "ssä", "sta", "stä", "lla", "llä", "lta", "ltä", "lle", "ksi", "ine", "n", "a", "ä", "t"),
        "french": ("issements", "issement", "ements", "ement", "ations", "ation", "ités", "ité", "euses", "euse", "eux", "es", "s", "e"),
        "german": ("ungen", "ung", "heit", "keit", "ern", "em", "en", "er", "es", "e", "s"),
        "hungarian": ("ban", "ben", "nak", "nek", "val", "vel", "ok", "ek", "ak", "k"),
        "italian": ("amente", "azione", "azioni", "mente", "ità", "are", "ere", "ire", "i", "e", "a", "o"),
        "norwegian": ("hetenes", "hetene", "heten", "heter", "endes", "ende", "ene", "ers", "ets", "er", "et", "en", "e", "s"),
        "portuguese": ("amente", "mente", "ações", "ação", "idades", "idade", "es", "s", "a", "o"),
        "romanian": ("ilor", "ului", "ele", "ul", "le", "i", "a", "e"),
        "russian": ("ившись", "ывшись", "ого", "его", "ами", "ями", "ый", "ий", "ой", "ая", "яя", "ов", "ев", "ам", "ям", "ах", "ях", "ом", "ем", "а", "я", "ы", "и", "о", "е", "у", "ю", "ь"),
        "spanish": ("amente", "aciones", "ación", "mente", "idades", "idad", "es", "s", "a", "o"),
        "swedish": ("heterna", "heten", "heter", "arna", "erna", "orna", "ande", "ade", "are", "ar", "er", "or", "en", "et", "a", "e", "s"),
        "arabic": ("ات", "ون", "ين", "ان", "ة", "ه", "ها"),
    }

    def __init__(self, language):
        self._suf = self._SUFFIXES.get(language, ())

    def stem(self, word):
        w = word.lower()
        for s in self._suf:
            if w.endswith(s) and len(w) - len(s) >= 3:
                return w[:-len(s)]
        return w


class SnowballStemmer:
    languages = _SB_LANGUAGES

    def __init__(self, language, ignore_stopwords=False):
        if language not in self.languages:  # spec: N-000394
            raise ValueError("The language %r is not supported." % (language,))
        self.language = language
        self.stopwords = set()
        if ignore_stopwords:  # spec: N-000395
            try:
                f = _data.find("corpora/stopwords/%s" % language)
                lines = _data.read_lines(f)
            except (LookupError, OSError) as e:
                raise ValueError("%r has no list of stopwords. Please set 'ignore_stopwords' to "
                                 "'False'." % language) from e
            self.stopwords = {l.strip() for l in lines if l.strip()}
        if language == "english":
            self.stemmer = _EnglishSnowball()
        elif language == "porter":
            self.stemmer = _PorterSnowball()
        else:
            self.stemmer = _GenericSnowball(language)

    def stem(self, word):
        _check_word(word)
        w = word.lower()
        if w in self.stopwords:
            return w
        return self.stemmer.stem(w)


# ------------------------------------------------------------------ Arabic
class ARLSTem:
    """Light Arabic stemmer (simplified; results are outside the specification)."""
    _PRE = ("وال", "بال", "كال", "فال", "لل", "ال", "وب", "ول", "و")
    _SUF = ("ات", "ون", "ين", "ان", "ها", "ة", "ه", "ي")
    _DIAC = re.compile("[ً-ْـ]")

    def stem(self, word):
        _check_word(word)
        w = self._DIAC.sub("", word)
        w = re.sub("[إأآ]", "ا", w)
        for p in self._PRE:
            if w.startswith(p) and len(w) - len(p) >= 3:
                w = w[len(p):]
                break
        for s in self._SUF:
            if w.endswith(s) and len(w) - len(s) >= 3:
                w = w[:-len(s)]
                break
        return w


class ARLSTem2(ARLSTem):
    pass


# ------------------------------------------------------------- Lemmatizer
_MORPH = {
    "n": [("s", ""), ("ses", "s"), ("ves", "f"), ("xes", "x"), ("zes", "z"), ("ches", "ch"),
          ("shes", "sh"), ("men", "man"), ("ies", "y")],
    "v": [("s", ""), ("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"), ("ed", ""),
          ("ing", "e"), ("ing", "")],
    "a": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
    "r": [],
}
_WN_FILES = {"n": "noun", "v": "verb", "a": "adj", "r": "adv"}


class WordNetLemmatizer:
    def __init__(self):
        self._dir = _data.find("corpora/wordnet")  # spec: N-000396
        if not os.path.isdir(self._dir):
            raise LookupError("WordNet is not available")
        self._lemmas = {}
        self._exc = {}

    def _load(self, pos):
        if pos in self._lemmas:
            return
        name = _WN_FILES[pos]
        lemmas = set()
        idx = os.path.join(self._dir, "index." + name)
        if not os.path.isfile(idx):
            raise LookupError("WordNet file missing: %s" % idx)
        for line in _data.read_lines(idx):
            if line and not line.startswith(" "):
                lemmas.add(line.split(" ", 1)[0])
        exc = {}
        ef = os.path.join(self._dir, name + ".exc")
        if os.path.isfile(ef):
            for line in _data.read_lines(ef):
                parts = line.split()
                if len(parts) >= 2:
                    exc[parts[0]] = parts[1:]
        self._lemmas[pos] = lemmas
        self._exc[pos] = exc

    def _morphy(self, form, pos):
        self._load(pos)
        lemmas, exc = self._lemmas[pos], self._exc[pos]
        subs = _MORPH[pos]

        def apply_rules(forms):
            return [f[:-len(old)] + new for f in forms for old, new in subs if f.endswith(old)]

        def filt(forms):
            out, seen = [], set()
            for f in forms:
                if f in lemmas and f not in seen:
                    out.append(f)
                    seen.add(f)
            return out

        if form in exc:
            return filt([form] + exc[form])
        forms = apply_rules([form])
        res = filt([form] + forms)
        if res:
            return res
        while forms:
            forms = apply_rules(forms)
            res = filt(forms)
            if res:
                return res
        return []

    def lemmatize(self, word, pos="n"):
        _check_word(word)
        pos = {"s": "a"}.get(pos, pos)
        if pos not in _WN_FILES:
            raise ValueError("pos must be one of n, v, a, r")
        lemmas = self._morphy(word, pos)
        return min(lemmas, key=len) if lemmas else word
