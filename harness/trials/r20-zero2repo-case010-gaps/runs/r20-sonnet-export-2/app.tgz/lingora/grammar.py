"""Context-free grammars.  # spec: N-000424..N-000434, FP-05 grammar reader"""
import re


class Nonterminal:
    """A nonterminal symbol; not a str, but str() gives its name."""

    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and self._symbol == other._symbol

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return hash(("NT", self._symbol))

    def __str__(self):
        return str(self._symbol)

    def __repr__(self):
        return "%s" % (self._symbol,)


class Production:
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def is_lexical(self):
        return all(isinstance(s, str) for s in self._rhs)

    def is_nonlexical(self):
        return not self.is_lexical()

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return isinstance(other, Production) and self._lhs == other._lhs and self._rhs == other._rhs

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        parts = [repr(s) if isinstance(s, str) else str(s) for s in self._rhs]
        return "%s -> %s" % (self._lhs, " ".join(parts))

    __repr__ = __str__


_TOKEN_RE = re.compile(r'''"[^"]*"|'[^']*'|\||[^\s|'"]+|['"]''')


def _parse_rhs(text, line):
    alternatives = [[]]
    for tok in _TOKEN_RE.findall(text):
        if tok == "|":
            alternatives.append([])
        elif tok[0] in "'\"":
            if len(tok) < 2 or tok[-1] != tok[0]:
                raise ValueError("Unterminated quote in grammar line: %r" % line)
            alternatives[-1].append(tok[1:-1])
        else:
            alternatives[-1].append(Nonterminal(tok))
    return alternatives


class CFG:
    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)
        self._by_lhs = {}
        for p in self._productions:
            self._by_lhs.setdefault(p.lhs(), []).append(p)

    @classmethod
    def fromstring(cls, input):  # spec: N-000427, N-000428
        if not isinstance(input, str):
            raise TypeError("grammar text must be a str")
        start = None
        prods = []
        lhs = None
        for raw in input.splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("%start"):
                start = Nonterminal(line.split(None, 1)[1].strip())
                continue
            if line.startswith("|"):
                if lhs is None:
                    raise ValueError("Unable to parse line: %r" % raw)
                rhs_text = line[1:]
                rhs_text = "|" + rhs_text
                alts = _parse_rhs(rhs_text, raw)[1:]
            else:
                m = re.match(r"^\s*([^\s|'\"]+)\s*(?:->|→)(.*)$", line)
                if not m:
                    raise ValueError("Unable to parse line: %r" % raw)
                lhs = Nonterminal(m.group(1))
                alts = _parse_rhs(m.group(2), raw)
            for rhs in alts:
                prods.append(Production(lhs, rhs))
        if not prods:
            raise ValueError("No productions found in grammar text")
        if start is None:
            start = prods[0].lhs()
        return cls(start, prods)

    def start(self):
        return self._start

    def productions(self, lhs=None, rhs=None):
        if lhs is None:
            return list(self._productions)
        if isinstance(lhs, str):
            lhs = Nonterminal(lhs)
        return list(self._by_lhs.get(lhs, []))

    def terminals(self):
        return {s for p in self._productions for s in p.rhs() if isinstance(s, str)}

    def covers(self, tokens):
        known = self.terminals()
        return [t for t in tokens if t not in known]

    def __str__(self):
        return "Grammar with %d productions (start state = %s)\n%s" % (
            len(self._productions), self._start,
            "\n".join("    " + str(p) for p in self._productions))

    __repr__ = __str__
