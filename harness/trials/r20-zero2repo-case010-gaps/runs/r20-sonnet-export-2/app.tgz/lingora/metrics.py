"""Evaluation metrics.  # spec: N-000461..N-000472"""


def accuracy(reference, test):  # spec: N-000464, N-000465, N-000310
    if not isinstance(reference, (list, tuple)) or not isinstance(test, (list, tuple)):
        raise TypeError("accuracy needs two lists")
    if len(reference) != len(test):
        raise ValueError("Lists must have the same length.")
    if not reference:
        return 0.0
    return sum(1 for x, y in zip(reference, test) if x == y) / len(test)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):  # spec: N-000466..N-000468
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("edit_distance needs two strings")
    len1, len2 = len(s1), len(s2)
    lev = [[0] * (len2 + 1) for _ in range(len1 + 1)]
    for i in range(len1 + 1):
        lev[i][0] = i
    for j in range(len2 + 1):
        lev[0][j] = j
    last_left_t = {}
    for i in range(1, len1 + 1):
        last_right = 0
        c1 = s1[i - 1]
        for j in range(1, len2 + 1):
            c2 = s2[j - 1]
            last_left = last_left_t.get(c2, 0)
            a = lev[i - 1][j] + 1
            b = lev[i][j - 1] + 1
            c = lev[i - 1][j - 1] + (substitution_cost if c1 != c2 else 0)
            d = c + 1
            if transpositions and last_left > 0 and last_right > 0:
                d = lev[last_left - 1][last_right - 1] + i - last_left + j - last_right - 1
            lev[i][j] = min(a, b, c, d)
            if c1 == c2:
                last_right = j
        last_left_t[c1] = i
    return lev[len1][len2]


def jaccard_distance(label1, label2):  # spec: N-000469
    if not isinstance(label1, (set, frozenset)) or not isinstance(label2, (set, frozenset)):
        raise TypeError("jaccard_distance needs two sets")
    union = len(label1 | label2)
    if union == 0:
        return 0.0
    return (union - len(label1 & label2)) / union


def _check_sets(reference, test):  # spec: N-000470, N-000471
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        raise TypeError("reference and test must be sets")


def precision(reference, test):
    _check_sets(reference, test)
    if len(test) == 0:
        return None  # spec: N-000472
    return len(reference & test) / len(test)


def recall(reference, test):
    _check_sets(reference, test)
    if len(reference) == 0:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    p = precision(reference, test)
    r = recall(reference, test)
    if p is None or r is None:
        return None
    if p == 0 or r == 0:
        return 0.0
    return 1.0 / (alpha / p + (1 - alpha) / r)
