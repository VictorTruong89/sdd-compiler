"""Classifiers.  # spec: N-000455..N-000460"""
import math
from collections import Counter, defaultdict


class ProbDist:
    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, sample):
        return float(self._probs.get(sample, 0.0))

    def logprob(self, sample):
        p = self.prob(sample)
        return math.log(p) if p > 0 else float("-inf")

    def samples(self):
        return list(self._probs)

    def max(self):
        return max(self._probs, key=lambda k: self._probs[k])


def _check_featuresets(data):
    if not isinstance(data, (list, tuple)):
        raise TypeError("expected a list of (featureset, label) pairs")
    for item in data:
        if not isinstance(item, (tuple, list)) or len(item) != 2 or not isinstance(item[0], dict):
            raise TypeError("expected (featureset, label) pairs with dict featuresets")


class NaiveBayesClassifier:
    def __init__(self, label_probdist, feature_probdist):
        self._label_probdist = label_probdist
        self._feature_probdist = feature_probdist
        self._labels = list(label_probdist)

    @classmethod
    def train(cls, labeled_featuresets):
        _check_featuresets(labeled_featuresets)
        if not labeled_featuresets:
            raise ValueError("cannot train on an empty list")
        label_freq = Counter()
        feature_freq = defaultdict(Counter)
        feature_values = defaultdict(set)
        fnames = []
        fname_set = set()
        for featureset, label in labeled_featuresets:
            label_freq[label] += 1
            for fname, fval in featureset.items():
                feature_freq[label, fname][fval] += 1
                feature_values[fname].add(fval)
                if fname not in fname_set:
                    fname_set.add(fname)
                    fnames.append(fname)
        for label in label_freq:
            n = label_freq[label]
            for fname in fnames:
                count = sum(feature_freq[label, fname].values())
                if n - count > 0:
                    feature_freq[label, fname][None] += n - count
                    feature_values[fname].add(None)
        # Expected-likelihood (+0.5) estimates: no value gets probability zero.
        nl = sum(label_freq.values())
        bl = len(label_freq)
        label_probdist = {l: (c + 0.5) / (nl + bl * 0.5) for l, c in label_freq.items()}
        feature_probdist = {}
        for (label, fname), fd in feature_freq.items():
            bins = len(feature_values[fname])
            total = sum(fd.values())
            feature_probdist[label, fname] = (dict(fd), total, bins)
        return cls(label_probdist, feature_probdist)

    def labels(self):
        return list(self._labels)

    def _fprob(self, label, fname, fval):
        fd, total, bins = self._feature_probdist[label, fname]
        return (fd.get(fval, 0) + 0.5) / (total + bins * 0.5)

    def prob_classify(self, featureset):
        fs = {k: v for k, v in featureset.items()
              if any((l, k) in self._feature_probdist for l in self._labels)}
        logprob = {}
        for label in self._labels:
            lp = math.log(self._label_probdist[label])
            for fname, fval in fs.items():
                if (label, fname) in self._feature_probdist:
                    lp += math.log(self._fprob(label, fname, fval))
                else:
                    lp = float("-inf")
            logprob[label] = lp
        m = max(logprob.values())
        if m == float("-inf"):
            return ProbDist({l: 1.0 / len(logprob) for l in logprob})
        exps = {l: math.exp(v - m) for l, v in logprob.items()}
        tot = sum(exps.values())
        return ProbDist({l: v / tot for l, v in exps.items()})

    def classify(self, featureset):
        return self.prob_classify(featureset).max()

    def classify_many(self, featuresets):
        return [self.classify(fs) for fs in featuresets]


def _entropy(labels):
    c = Counter(labels)
    n = sum(c.values())
    return -sum((v / n) * math.log2(v / n) for v in c.values()) if n else 0.0


def _majority(labels):
    return Counter(labels).most_common(1)[0][0]


class DecisionTreeClassifier:
    def __init__(self, label, feature_name=None, decisions=None, default=None):
        self._label = label
        self._fname = feature_name
        self._decisions = decisions
        self._default = default

    def classify(self, featureset):
        if self._fname is None:
            return self._label
        fval = featureset.get(self._fname)
        try:
            if fval in self._decisions:
                return self._decisions[fval].classify(featureset)
        except TypeError:
            pass
        if self._default is not None:
            return self._default.classify(featureset)
        return self._label

    def classify_many(self, featuresets):
        return [self.classify(fs) for fs in featuresets]

    def error(self, labeled):
        return sum(1 for fs, l in labeled if self.classify(fs) != l) / len(labeled)

    @staticmethod
    def leaf(labeled):
        return DecisionTreeClassifier(_majority([l for _, l in labeled]))

    @staticmethod
    def stump(fname, labeled):
        label = _majority([l for _, l in labeled])
        groups = {}
        for fs, l in labeled:
            groups.setdefault(fs.get(fname), []).append(l)
        decisions = {v: DecisionTreeClassifier(_majority(ls)) for v, ls in groups.items()}
        return DecisionTreeClassifier(label, fname, decisions, DecisionTreeClassifier(label))

    @staticmethod
    def best_stump(fnames, labeled):
        best = DecisionTreeClassifier.leaf(labeled)
        best_err = best.error(labeled)
        for fname in fnames:
            st = DecisionTreeClassifier.stump(fname, labeled)
            err = st.error(labeled)
            if err < best_err:
                best, best_err = st, err
        return best

    def refine(self, labeled, entropy_cutoff, depth_cutoff, support_cutoff):
        if len(labeled) <= support_cutoff or self._fname is None or depth_cutoff <= 0:
            return
        for fval in list(self._decisions):
            sub = [(fs, l) for fs, l in labeled if fs.get(self._fname) == fval]
            if sub and _entropy([l for _, l in sub]) > entropy_cutoff:
                self._decisions[fval] = DecisionTreeClassifier.train(
                    sub, entropy_cutoff, depth_cutoff, support_cutoff)
        if self._default is not None:
            sub = [(fs, l) for fs, l in labeled if fs.get(self._fname) not in self._decisions]
            if sub and _entropy([l for _, l in sub]) > entropy_cutoff:
                self._default = DecisionTreeClassifier.train(
                    sub, entropy_cutoff, depth_cutoff, support_cutoff)

    @classmethod
    def train(cls, labeled_featuresets, entropy_cutoff=0.05, depth_cutoff=100, support_cutoff=10):
        _check_featuresets(labeled_featuresets)
        if not labeled_featuresets:
            raise ValueError("cannot train on an empty list")
        fnames = []
        seen = set()
        for fs, _ in labeled_featuresets:
            for k in fs:
                if k not in seen:
                    seen.add(k)
                    fnames.append(k)
        tree = cls.best_stump(fnames, labeled_featuresets)
        tree.refine(labeled_featuresets, entropy_cutoff, depth_cutoff - 1, support_cutoff)
        return tree


def accuracy(classifier, gold):
    if not isinstance(gold, (list, tuple)):
        raise TypeError("gold must be a list of (featureset, label) pairs")
    if not gold:
        return 0.0
    results = [classifier.classify(fs) for fs, _ in gold]
    return sum(1 for r, (_, l) in zip(results, gold) if r == l) / len(gold)
