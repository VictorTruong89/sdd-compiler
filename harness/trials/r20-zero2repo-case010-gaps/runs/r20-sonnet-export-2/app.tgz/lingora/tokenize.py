"""Tokenizers.  # spec: N-000371..N-000381, FP-01"""
import html
import re
import os

from lingora import data as _data

__all__ = ["RegexpTokenizer", "TreebankWordTokenizer", "TweetTokenizer", "WhitespaceTokenizer",
           "WordPunctTokenizer", "BlanklineTokenizer", "blankline_tokenize", "sent_tokenize",
           "word_tokenize", "wordpunct_tokenize", "PunktSentenceTokenizer", "NLTKWordTokenizer"]

_FLAGS = re.UNICODE | re.MULTILINE | re.DOTALL


def _check_text(text):
    if not isinstance(text, str):
        raise TypeError("text must be a str, not %s" % type(text).__name__)


class RegexpTokenizer:
    def __init__(self, pattern, gaps=False, discard_empty=True, flags=_FLAGS):
        if isinstance(pattern, str):
            self._pattern = pattern
            self._regexp = re.compile(pattern, flags)
        else:
            self._pattern = pattern.pattern
            self._regexp = pattern
        self._gaps = gaps
        self._discard_empty = discard_empty

    def span_tokenize(self, text):
        _check_text(text)
        if self._gaps:
            left = 0
            for m in self._regexp.finditer(text):
                right, nxt = m.span()
                if not (self._discard_empty and left == right):
                    yield (left, right)
                left = nxt
            if not (self._discard_empty and left == len(text)):
                yield (left, len(text))
        else:
            for m in self._regexp.finditer(text):
                yield m.span()

    def tokenize(self, text):
        _check_text(text)
        return [text[a:b] for a, b in self.span_tokenize(text)]

    def __repr__(self):
        return "%s(pattern=%r, gaps=%r, discard_empty=%r)" % (
            type(self).__name__, self._pattern, self._gaps, self._discard_empty)


class WordPunctTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\w+|[^\w\s]+")


class WhitespaceTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s+", gaps=True)


class BlanklineTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s*\n\s*\n\s*", gaps=True)

    def span_tokenize(self, text):
        _check_text(text)
        if not text.strip():
            return iter(())
        return RegexpTokenizer.span_tokenize(self, text)


_wordpunct = WordPunctTokenizer()
_blankline = BlanklineTokenizer()


def wordpunct_tokenize(text):
    return _wordpunct.tokenize(text)


def blankline_tokenize(text):
    return _blankline.tokenize(text)


# ---------------------------------------------------------------- Treebank
class TreebankWordTokenizer:
    STARTING_QUOTES = [
        (re.compile(r"^\""), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
    ]
    PUNCTUATION = [
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.\.\."), r" ... "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\']*)\s*$'), r"\1 \2\3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
    ]
    PARENS_BRACKETS = (re.compile(r"[\]\[\(\)\{\}\<\>]"), r" \g<0> ")
    DOUBLE_DASHES = (re.compile(r"--"), r" -- ")
    ENDING_QUOTES = [
        (re.compile(r'"'), " '' "),
        (re.compile(r"(\S)(\'\')"), r"\1 \2 "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    CONTRACTIONS2 = [re.compile(r) for r in (
        r"(?i)\b(can)(?#X)(not)\b", r"(?i)\b(d)(?#X)('ye)\b", r"(?i)\b(gim)(?#X)(me)\b",
        r"(?i)\b(gon)(?#X)(na)\b", r"(?i)\b(got)(?#X)(ta)\b", r"(?i)\b(lem)(?#X)(me)\b",
        r"(?i)\b(more)(?#X)('n)\b", r"(?i)\b(wan)(?#X)(na)(?=\s)")]
    CONTRACTIONS3 = [re.compile(r) for r in (r"(?i) ('t)(?#X)(is)\b", r"(?i) ('t)(?#X)(was)\b")]

    def tokenize(self, text):
        _check_text(text)
        for rx, sub in self.STARTING_QUOTES:
            text = rx.sub(sub, text)
        for rx, sub in self.PUNCTUATION:
            text = rx.sub(sub, text)
        rx, sub = self.PARENS_BRACKETS
        text = rx.sub(sub, text)
        rx, sub = self.DOUBLE_DASHES
        text = rx.sub(sub, text)
        text = " " + text + " "
        for rx, sub in self.ENDING_QUOTES:
            text = rx.sub(sub, text)
        for rx in self.CONTRACTIONS2:
            text = rx.sub(r" \1 \2 ", text)
        for rx in self.CONTRACTIONS3:
            text = rx.sub(r" \1 \2 ", text)
        return text.split()


class NLTKWordTokenizer(TreebankWordTokenizer):
    """The recommended word tokenizer: Treebank conventions plus improvements."""
    STARTING_QUOTES = [
        (re.compile("([«“‘„]|[`]+)", re.U), r" \1 "),
        (re.compile(r"^\""), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
        (re.compile(r"(?i)(\')(?!re|ve|ll|m|t|s|d|n)(\w)\b", re.U), r"\1 \2"),
    ]
    PUNCTUATION = [
        (re.compile(r"([^\.])(\.)([\]\)}>\"\'»”’ ]*)\s*$", re.U), r"\1 \2 \3 "),
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.{2,}", re.U), r" \g<0> "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
        (re.compile(r"[*]", re.U), r" \g<0> "),
        (re.compile("[‒-―]"), r" \g<0> "),
    ]
    ENDING_QUOTES = [
        (re.compile("([»”’])", re.U), r" \1 "),
        (re.compile(r"''"), " '' "),
        (re.compile(r'"'), " '' "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]


_treebank = NLTKWordTokenizer()


# ------------------------------------------------------------------- Tweet
_EMOTICONS = r"""
    (?:
      [<>]?
      [:;=8]
      [\-o\*\']?
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      |
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      [\-o\*\']?
      [:;=8]
      [<>]?
      |
      </?3
    )"""
_URLS = r"""
  (?:
  https?:
    (?:
      /{1,3}
      |
      [a-z0-9%]
    )
    |
    [a-z0-9.\-]+[.]
    (?:[a-z]{2,13})
    /
  )
  (?:
    [^\s()<>{}\[\]]+
    |
    \([^\s()]*?\([^\s()]+\)[^\s()]*?\)
    |
    \([^\s]+?\)
  )+
  (?:
    \([^\s()]*?\([^\s()]+\)[^\s()]*?\)
    |
    \([^\s]+?\)
    |
    [^\s`!()\[\]{};:'".,<>?«»“”‘’]
  )
  |
  (?:
    (?<!@)
    [a-z0-9]+
    (?:[.\-][a-z0-9]+)*
    [.]
    (?:[a-z]{2,13})
    \b
    /?
    (?!@)
  )
"""
_PHONE = r"""
    (?:
      (?:
        \+?[01]
        [ *\-.\)]*
      )?
      (?:
        [\(]?
        \d{3}
        [ *\-.\)]*
      )?
      \d{3}
      [ *\-.\)]*
      \d{4}
    )"""
_HTML_TAG = r"""<[^>\s]+>"""
_ARROWS = r"""[\-]+>|<[\-]+"""
_USER = r"""(?:@[\w_]+)"""
_HASHTAG = r"""(?:\#+[\w_]+[\w\'_\-]*[\w_]+)"""
_EMAIL = r"""[\w.+-]+@[\w-]+\.(?:[\w-]\.?)+[\w-]"""
_WORDS = r"""
    (?:[^\W\d_](?:[^\W\d_]|['\-_])+[^\W\d_])
    |
    (?:[+\-]?\d+[,/.:-]\d+[+\-]?)
    |
    (?:[\w_]+)
    |
    (?:\.(?:\s*\.){1,})
    |
    (?:\S)
"""


def _word_re(phone=True):
    parts = [_URLS] + ([_PHONE] if phone else []) + [_EMOTICONS, _HTML_TAG, _ARROWS, _USER,
                                                       _HASHTAG, _EMAIL, _WORDS]
    return re.compile("(%s)" % "|".join(parts), re.VERBOSE | re.I | re.UNICODE)


_WORD_RE = _word_re(True)
_WORD_RE_NOPHONE = _word_re(False)
_HANG_RE = re.compile(r"([^a-zA-Z0-9])\1{3,}")
_EMOTICON_RE = re.compile(_EMOTICONS, re.VERBOSE | re.I | re.UNICODE)
_LENGTHENING_RE = re.compile(r"(.)\1{2,}", re.DOTALL)
_HANDLES_RE = re.compile(
    r"(?<![A-Za-z0-9_!@#\$%&*])@(([A-Za-z0-9_]){15}(?!@)|([A-Za-z0-9_]){1,14}(?![A-Za-z0-9_]*@))")
_ENT_RE = re.compile(r"&(#?(x?))([^&;\s]+);")


def _replace_entities(text):
    def sub(m):
        body = m.group(0)
        if m.group(1):
            try:
                num = int(m.group(3), 16 if m.group(2) else 10)
                return chr(num)
            except (ValueError, OverflowError):
                return body
        un = html.unescape(body)
        return un
    return _ENT_RE.sub(sub, text)


class TweetTokenizer:
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False,
                 match_phone_numbers=True):
        self.preserve_case = preserve_case
        self.reduce_len = reduce_len
        self.strip_handles = strip_handles
        self.match_phone_numbers = match_phone_numbers

    def tokenize(self, text):
        _check_text(text)
        text = _replace_entities(text)
        if self.strip_handles:
            text = _HANDLES_RE.sub(" ", text)
        if self.reduce_len:
            text = _LENGTHENING_RE.sub(r"\1\1\1", text)
        safe = _HANG_RE.sub(r"\1\1\1", text)
        rx = _WORD_RE if self.match_phone_numbers else _WORD_RE_NOPHONE
        words = [m.group(0) for m in rx.finditer(safe)]
        if not self.preserve_case:
            words = [w if _EMOTICON_RE.search(w) else w.lower() for w in words]
        return words


# ------------------------------------------------------------------- Punkt
_ORTHO_BEG_UC, _ORTHO_MID_UC, _ORTHO_UNK_UC = 2, 4, 8
_ORTHO_UC = 14
_ORTHO_BEG_LC = 16
_ORTHO_LC = 112


class _LangVars:
    sent_end_chars = (".", "?", "!")
    re_boundary_realignment = re.compile(r'["\')\]}]+?(?:\s+|(?=--)|$)', re.MULTILINE)
    _re_sent_end = r"[.?!]"
    _re_word_start = r"[^\(\"\`{\[:;&\#\*@\)}\]\-,]"
    _re_non_word = r"(?:[)\";}\]\*:@\'\({\[?!])"
    _re_multi = r"(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"
    _word_fmt = r"""(
        %(MultiChar)s
        |
        (?=%(WordStart)s)\S+?
        (?=
            \s|
            $|
            %(NonWord)s|%(MultiChar)s|
            ,(?=$|\s|%(NonWord)s|%(MultiChar)s)
        )
        |
        \S
    )"""
    _period_fmt = r"""
        %(SentEndChars)s
        (?=(?P<after_tok>
            %(NonWord)s
            |
            \s+(?P<next_tok>\S+)
        ))"""

    def __init__(self):
        d = {"NonWord": self._re_non_word, "MultiChar": self._re_multi,
             "WordStart": self._re_word_start, "SentEndChars": self._re_sent_end}
        self.word_re = re.compile(self._word_fmt % d, re.UNICODE | re.VERBOSE)
        self.period_re = re.compile(self._period_fmt % d, re.UNICODE | re.VERBOSE)

    def word_tokenize(self, s):
        return self.word_re.findall(s)


_lang_vars = _LangVars()
_RE_ELLIPSIS = re.compile(r"\.\.+$")
_RE_NUMERIC = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_RE_INITIAL = re.compile(r"[^\W\d]\.$", re.UNICODE)
_RE_ALPHA = re.compile(r"[^\W\d]+$", re.UNICODE)
_RE_NON_PUNCT = re.compile(r"[^\W\d]", re.UNICODE)
_PUNCT = tuple(";:,.!?")


class _Token:
    def __init__(self, tok, parastart=False, linestart=False):
        self.tok = tok
        self.parastart = parastart
        self.linestart = linestart
        self.sentbreak = False
        self.abbr = False
        self.ellipsis = False
        self.type = _RE_NUMERIC.sub("##number##", tok.lower())
        self.period_final = tok.endswith(".")
        self.first_upper = tok[0].isupper()
        self.first_lower = tok[0].islower()
        self.is_ellipsis = bool(_RE_ELLIPSIS.match(tok))
        self.is_initial = bool(_RE_INITIAL.match(tok))

    @property
    def type_no_period(self):
        if len(self.type) > 1 and self.type[-1] == ".":
            return self.type[:-1]
        return self.type

    @property
    def type_no_sentperiod(self):
        return self.type if not self.sentbreak else self.type_no_period


class PunktParameters:
    def __init__(self):
        self.abbrev_types = set()
        self.collocations = set()
        self.sent_starters = set()
        self.ortho_context = {}

    @classmethod
    def load(cls, directory):  # spec: N-000367
        p = cls()
        def lines(name):
            return _data.read_lines(os.path.join(directory, name))
        p.abbrev_types = {l for l in lines("abbrev_types.txt") if l != ""}
        p.sent_starters = {l for l in lines("sent_starters.txt") if l != ""}
        for l in lines("collocations.tab"):
            if not l.strip():
                continue
            a, _, b = l.partition("\t")
            p.collocations.add((a, b))
        for l in lines("ortho_context.tab"):
            if not l.strip():
                continue
            a, _, b = l.rpartition("\t")
            p.ortho_context[a] = int(b)
        return p


class PunktSentenceTokenizer:
    def __init__(self, params=None):
        if isinstance(params, str):
            params = PunktParameters.load(params)
        self._params = params or PunktParameters()

    # --- word tokens
    def _tokenize_words(self, text):
        parastart = False
        for line in text.split("\n"):
            if line.strip():
                toks = iter(_lang_vars.word_tokenize(line))
                try:
                    tok = next(toks)
                except StopIteration:
                    continue
                yield _Token(tok, parastart=parastart, linestart=True)
                parastart = False
                for tok in toks:
                    yield _Token(tok)
            else:
                parastart = True

    def _first_pass(self, tok):
        t = tok.tok
        if t in _lang_vars.sent_end_chars:
            tok.sentbreak = True
        elif tok.is_ellipsis:
            tok.ellipsis = True
        elif tok.period_final and not t.endswith(".."):
            low = t[:-1].lower()
            if low in self._params.abbrev_types or low.split("-")[-1] in self._params.abbrev_types:
                tok.abbr = True
            else:
                tok.sentbreak = True

    def _ortho_heuristic(self, tok):
        if tok.tok in _PUNCT:
            return False
        oc = self._params.ortho_context.get(tok.type_no_sentperiod, 0)
        if tok.first_upper and (oc & _ORTHO_LC) and not (oc & _ORTHO_MID_UC):
            return True
        if tok.first_lower and ((oc & _ORTHO_UC) or not (oc & _ORTHO_BEG_LC)):
            return False
        return "unknown"

    def _second_pass(self, t1, t2):
        if t2 is None or not t1.period_final:
            return
        typ = t1.type_no_period
        next_typ = t2.type_no_sentperiod
        initial = t1.is_initial
        if (typ, next_typ) in self._params.collocations:
            t1.sentbreak = False
            t1.abbr = True
            return
        if (t1.abbr or t1.ellipsis) and not initial:
            st = self._ortho_heuristic(t2)
            if st is True:
                t1.sentbreak = True
                return
            if t2.first_upper and next_typ in self._params.sent_starters:
                t1.sentbreak = True
                return
        if initial or typ == "##number##":
            st = self._ortho_heuristic(t2)
            if st is False:
                t1.sentbreak = False
                t1.abbr = True
                return
            if (st == "unknown" and initial and t2.first_upper
                    and not (self._params.ortho_context.get(next_typ, 0) & _ORTHO_LC)):
                t1.sentbreak = False
                t1.abbr = True
                return

    def _annotate(self, tokens):
        toks = list(tokens)
        for t in toks:
            self._first_pass(t)
        for i, t in enumerate(toks):
            self._second_pass(t, toks[i + 1] if i + 1 < len(toks) else None)
        return toks

    def _contains_sentbreak(self, text):
        found = False
        for tok in self._annotate(self._tokenize_words(text)):
            if found:
                return True
            if tok.sentbreak:
                found = True
        return False

    @staticmethod
    def _last_ws_index(s):
        for i in range(len(s) - 1, -1, -1):
            if s[i].isspace():
                return i
        return None

    def _potential_ends(self, text):
        prev_slice = (0, 0)
        prev_match = None
        for match in _lang_vars.period_re.finditer(text):
            before = text[prev_slice[1]:match.start()]
            idx = self._last_ws_index(before)
            if idx:
                idx += prev_slice[1] + 1
            else:
                idx = prev_slice[0]
            cur = (idx, match.start())
            if prev_match is not None and prev_slice[1] <= cur[0]:
                yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + prev_match.group("after_tok")
            prev_match = match
            prev_slice = cur
        if prev_match is not None:
            yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + prev_match.group("after_tok")

    def _slices(self, text):
        last = 0
        for match, context in self._potential_ends(text):
            if self._contains_sentbreak(context):
                yield (last, match.end())
                if match.group("next_tok"):
                    last = match.start("next_tok")
                else:
                    last = match.end()
        yield (last, len(text.rstrip()))

    def _realign(self, text, slices):
        realign = 0
        slices = list(slices)
        for i, s1 in enumerate(slices):
            s2 = slices[i + 1] if i + 1 < len(slices) else None
            s1 = (s1[0] + realign, s1[1])
            if s2 is None:
                if text[s1[0]:s1[1]]:
                    yield s1
                continue
            m = _lang_vars.re_boundary_realignment.match(text[s2[0]:s2[1]])
            if m:
                yield (s1[0], s2[0] + len(m.group(0).rstrip()))
                realign = m.end()
            else:
                realign = 0
                if text[s1[0]:s1[1]]:
                    yield s1

    def span_tokenize(self, text):
        return list(self._realign(text, self._slices(text)))

    def tokenize(self, text):
        _check_text(text)
        return [text[a:b] for a, b in self.span_tokenize(text)]


_punkt_cache = {}


def _load_punkt(language):
    if not isinstance(language, str) or not language or "/" in language or "\\" in language \
            or language in (".", ".."):
        raise ValueError("invalid language %r" % (language,))
    d = _data.find("tokenizers/punkt_tab/%s" % language)  # LookupError if missing
    if not os.path.isdir(d):
        raise LookupError("Punkt model for %r is not a directory" % language)
    stamp = []
    for name in ("abbrev_types.txt", "sent_starters.txt", "collocations.tab", "ortho_context.tab"):
        f = os.path.join(d, name)
        if not os.path.isfile(f):
            raise LookupError("Punkt model file missing: %s" % f)
        st = os.stat(f)
        stamp.append((st.st_mtime_ns, st.st_size))
    key = (d, tuple(stamp))
    tok = _punkt_cache.get(key)
    if tok is None:
        tok = PunktSentenceTokenizer(PunktParameters.load(d))
        _punkt_cache[key] = tok
    return tok


def sent_tokenize(text, language="english"):
    _check_text(text)
    return _load_punkt(language).tokenize(text)


def word_tokenize(text, language="english", preserve_line=False):
    _check_text(text)
    sentences = [text] if preserve_line else sent_tokenize(text, language)
    return [tok for sent in sentences for tok in _treebank.tokenize(sent)]
