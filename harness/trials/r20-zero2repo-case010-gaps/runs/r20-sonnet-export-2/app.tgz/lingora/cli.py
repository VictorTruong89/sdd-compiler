"""Command line.  # spec: N-000382..N-000388"""
import sys


class _UsageError(Exception):
    pass


def _read_stdin(encoding):
    stream = sys.stdin
    buf = getattr(stream, "buffer", None)
    if buf is not None:
        return buf.read().decode(encoding)
    return stream.read()


def _tokenize_command(args):
    language, delimiter, encoding = "english", " ", "utf-8"
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--help"):
            print("Usage: lingora tokenize [-l LANGUAGE] [-d DELIMITER] [-e ENCODING]\n\n"
                  "  Tokenize each line of standard input.")
            return 0
        opt, eq, val = a.partition("=")
        if opt in ("-l", "--language", "-d", "--delimiter", "-e", "--encoding"):
            if not eq:
                i += 1
                if i >= len(args):
                    raise _UsageError("Option %s requires an argument." % opt)
                val = args[i]
            if opt in ("-l", "--language"):
                language = val
            elif opt in ("-d", "--delimiter"):
                delimiter = val
            else:
                encoding = val
        else:
            raise _UsageError("No such option: %s" % a)
        i += 1
    from lingora.tokenize import _load_punkt, word_tokenize
    _load_punkt(language)  # fail before any output when the model is missing
    text = _read_stdin(encoding)
    lines = text.replace("\r\n", "\n").split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    out = [delimiter.join(word_tokenize(line, language=language)) + "\n" for line in lines]
    sys.stdout.write("".join(out))
    sys.stdout.flush()
    return 0


class Group:
    def __init__(self, commands):
        self.commands = commands

    def main(self, args=None, prog_name=None, standalone_mode=True, **extra):
        if args is None:
            args = sys.argv[1:]
        args = list(args)
        try:
            if not args or args[0] in ("-h", "--help"):
                print("Usage: lingora [OPTIONS] COMMAND [ARGS]...\n\nCommands:\n  tokenize  "
                      "Tokenize each line of standard input.")
                rv = 0
            elif args[0] in self.commands:
                rv = self.commands[args[0]](args[1:])
            else:
                raise _UsageError("No such command %r." % args[0])
        except _UsageError as e:
            if not standalone_mode:
                raise
            sys.stderr.write("Error: %s\n" % e)
            sys.exit(2)
        except SystemExit:
            raise
        except Exception as e:  # any failure: non-zero status, nothing written
            if not standalone_mode:
                raise
            sys.stderr.write("Error: %s\n" % (e,))
            sys.exit(1)
        if standalone_mode:
            sys.exit(rv or 0)
        return rv

    __call__ = main


cli = Group({"tokenize": _tokenize_command})

if __name__ == "__main__":
    cli.main()
