"""BLEU.  # spec: N-000473..N-000477"""
import math
import sys
from collections import Counter
from fractions import Fraction


class SmoothingFunction:
    """A few smoothing functions; pass e.g. SmoothingFunction().method1."""

    def __init__(self, epsilon=0.1):
        self.epsilon = epsilon

    def method1(self, p_n, references, hypothesis, hyp_len):
        return [(p.numerator + self.epsilon) / p.denominator if p.numerator == 0 else p for p in p_n]

    def method2(self, p_n, references, hypothesis, hyp_len):
        return [Fraction(p.numerator + 1, p.denominator + 1) for p in p_n]


def _ngrams(seq, n):
    return [tuple(seq[i:i + n]) for i in range(len(seq) - n + 1)]


def _modified_precision(references, hypothesis, n):
    counts = Counter(_ngrams(hypothesis, n)) if len(hypothesis) >= n else Counter()
    max_counts = {}
    for ref in references:
        rc = Counter(_ngrams(ref, n)) if len(ref) >= n else Counter()
        for g in counts:
            max_counts[g] = max(max_counts.get(g, 0), rc[g])
    clipped = {g: min(c, max_counts.get(g, 0)) for g, c in counts.items()}
    num = sum(clipped.values())
    den = max(1, sum(counts.values()))
    return num, den


def bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):
    if not isinstance(references, (list, tuple)) or not isinstance(hypothesis, (list, tuple)):
        raise TypeError("references and hypothesis must be lists")
    if isinstance(hypothesis, str) or any(not isinstance(r, (list, tuple)) for r in references):
        raise TypeError("each reference must be a token list")
    if not references:
        raise ValueError("at least one reference is required")
    weights = list(weights)
    if not weights:
        raise ValueError("weights must not be empty")
    nums, dens = [], []
    for i in range(1, len(weights) + 1):
        a, b = _modified_precision(references, hypothesis, i)
        nums.append(a)
        dens.append(b)
    hyp_len = len(hypothesis)
    ref_len = min((len(r) for r in references), key=lambda l: (abs(l - hyp_len), l))
    if hyp_len > ref_len:
        bp = 1.0
    elif hyp_len == 0:
        bp = 0.0
    else:
        bp = math.exp(1 - ref_len / hyp_len)
    if nums[0] == 0:
        return 0.0
    p_n = [Fraction(a, b, _normalize=False) if sys.version_info < (3, 12) else Fraction(a, b)
           for a, b in zip(nums, dens)]
    if smoothing_function is None:
        p_n = [p if p.numerator != 0 else sys.float_info.min for p in p_n]
    else:
        p_n = smoothing_function(p_n, references, hypothesis, hyp_len)
    s = math.fsum(w * math.log(float(p)) for w, p in zip(weights, p_n))
    return float(bp * math.exp(s))
