"""Part-of-speech taggers.  # spec: N-000397..N-000409, FP-03"""
import json
import os
import re
from collections import Counter, defaultdict

from lingora import data as _data

__all__ = ["DefaultTagger", "RegexpTagger", "UnigramTagger", "BigramTagger", "TrigramTagger",
           "AffixTagger", "PerceptronTagger", "pos_tag"]


def _check_tokens(tokens):
    if isinstance(tokens, (str, bytes)) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str, not %s" % type(tokens).__name__)


class SequentialBackoffTagger:
    def __init__(self, backoff=None):
        if backoff is not None and not hasattr(backoff, "tag_one"):
            raise TypeError("backoff must be a tagger or None")
        self._taggers = [self] + (backoff._taggers if backoff is not None else [])
        self.backoff = backoff

    def tag(self, tokens):
        _check_tokens(tokens)
        tags = []
        for i in range(len(tokens)):
            tags.append(self.tag_one(tokens, i, tags))
        return list(zip(tokens, tags))

    def tag_one(self, tokens, index, history):
        tag = None
        for tagger in self._taggers:
            tag = tagger.choose_tag(tokens, index, history)
            if tag is not None:
                break
        return tag

    def choose_tag(self, tokens, index, history):
        raise NotImplementedError


class DefaultTagger(SequentialBackoffTagger):
    def __init__(self, tag):
        SequentialBackoffTagger.__init__(self, None)
        self._tag = tag

    def choose_tag(self, tokens, index, history):
        return self._tag


class RegexpTagger(SequentialBackoffTagger):
    def __init__(self, regexps, backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        self._regexps = [(re.compile(p), t) for p, t in regexps]

    def choose_tag(self, tokens, index, history):
        for rx, tag in self._regexps:
            if rx.match(tokens[index]):
                return tag
        return None


class NgramTagger(SequentialBackoffTagger):
    _n = 1

    def __init__(self, train=None, backoff=None, cutoff=0):
        SequentialBackoffTagger.__init__(self, backoff)
        self._context_to_tag = {}
        if train:
            self._train(train, cutoff)

    def _train(self, sents, cutoff):
        counts = defaultdict(Counter)
        for sent in sents:
            tokens = [w for w, _ in sent]
            history = []
            for i, (w, t) in enumerate(sent):
                ctx = self.context(tokens, i, history)
                if ctx is not None:
                    counts[ctx][t] += 1
                history.append(t)
        for ctx, c in counts.items():
            tag, n = c.most_common(1)[0]
            if n > cutoff:
                self._context_to_tag[ctx] = tag

    def context(self, tokens, index, history):
        n = self._n
        prev = tuple(history[max(0, index - n + 1):index]) if n > 1 else ()
        return prev + (tokens[index],)

    def choose_tag(self, tokens, index, history):
        return self._context_to_tag.get(self.context(tokens, index, history))


class UnigramTagger(NgramTagger):
    _n = 1


class BigramTagger(NgramTagger):
    _n = 2


class TrigramTagger(NgramTagger):
    _n = 3


class AffixTagger(NgramTagger):
    def __init__(self, train=None, affix_length=-3, min_stem_length=2, backoff=None, cutoff=0):
        self._affix_length = affix_length
        self._min_word_length = min_stem_length + abs(affix_length)
        NgramTagger.__init__(self, train, backoff, cutoff)

    def context(self, tokens, index, history):
        token = tokens[index]
        if len(token) < self._min_word_length:
            return None
        if self._affix_length > 0:
            return token[:self._affix_length]
        return token[self._affix_length:]


# --------------------------------------------------- averaged perceptron
class PerceptronTagger:
    START = ["-START-", "-START2-"]
    END = ["-END-", "-END2-"]

    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = list(classes)

    @staticmethod
    def normalize(word):
        if "-" in word and word[0] != "-":
            return "!HYPHEN"
        if word.isdigit() and len(word) == 4:
            return "!YEAR"
        if word and word[0].isdigit():
            return "!DIGITS"
        return word.lower()

    def _features(self, i, word, context, prev, prev2):
        feats = defaultdict(int)

        def add(name, *args):
            feats[" ".join((name,) + tuple(args))] += 1

        i += len(self.START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return feats

    def _predict(self, feats):
        scores = defaultdict(float)
        for feat, value in feats.items():
            w = self.weights.get(feat)
            if w is None or value == 0:
                continue
            for label, weight in w.items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))

    def tag(self, tokens):
        prev, prev2 = self.START
        out = []
        context = self.START + [self.normalize(w) for w in tokens] + self.END
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                tag = self._predict(self._features(i, word, context, prev, prev2))
            out.append((word, tag))
            prev2 = prev
            prev = tag
        return out


_model_cache = {}


def _load_perceptron(lang):
    d = _data.find("taggers/averaged_perceptron_tagger_%s" % lang)
    base = os.path.join(d, "averaged_perceptron_tagger_%s" % lang)
    files = [base + ".weights.json", base + ".tagdict.json", base + ".classes.json"]
    stamp = []
    for f in files:
        if not os.path.isfile(f):
            raise LookupError("tagger model file missing: %s" % f)
        st = os.stat(f)
        stamp.append((f, st.st_mtime_ns, st.st_size))
    key = tuple(stamp)
    m = _model_cache.get(key)
    if m is None:
        loaded = []
        for f in files:
            with open(f, encoding="utf-8") as fh:
                loaded.append(json.load(fh))
        m = PerceptronTagger(*loaded)
        _model_cache.clear()
        _model_cache[key] = m
    return m


_RUS_UNIVERSAL = {
    "A": "ADJ", "A-PRO": "PRON", "ADV": "ADV", "ADV-PRO": "PRON", "ANUM": "ADJ", "CONJ": "CONJ",
    "INTJ": "X", "NONLEX": ".", "NUM": "NUM", "PARENTH": "PRT", "PART": "PRT", "PR": "ADP",
    "PRAEDIC": "PRT", "PRAEDIC-PRO": "PRON", "S": "NOUN", "S-PRO": "PRON", "V": "VERB",
    "COM": "X", "APRO": "PRON", "SPRO": "PRON",
}


def _load_ptb_map():
    d = _data.find("taggers/universal_tagset")
    f = os.path.join(d, "en-ptb.map")
    if not os.path.isfile(f):
        raise LookupError("universal tagset table en-ptb.map not found")
    m = {}
    for line in _data.read_lines(f):
        if not line.strip():
            continue
        a, _, b = line.partition("\t")
        m[a] = b.strip()
    return m


def pos_tag(tokens, tagset=None, lang="eng"):
    _check_tokens(tokens)  # spec: N-000406
    if lang not in ("eng", "rus"):  # spec: N-000407
        raise ValueError("Unsupported language %r: supported languages are 'eng' and 'rus'" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("tagset must be None or 'universal'")
    model = _load_perceptron(lang)
    tagged = model.tag(list(tokens))
    if tagset == "universal":
        if lang == "eng":
            table = _load_ptb_map()
            tagged = [(w, table.get(t, "X")) for w, t in tagged]
        else:
            tagged = [(w, _RUS_UNIVERSAL.get(t.split("=")[0], "X")) for w, t in tagged]
    return tagged
