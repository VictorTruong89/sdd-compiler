"""Lingora: a pure-Python natural-language processing toolkit."""
import importlib as _importlib

from . import data  # spec: N-000353

__version__ = "0.1.0"

_SUBMODULES = ("tokenize", "stem", "tag", "chunk", "grammar", "parse", "tree",
               "classify", "metrics", "translate", "cli")


def __getattr__(name):
    if name in _SUBMODULES:
        return _importlib.import_module("." + name, __name__)
    raise AttributeError(name)
