"""Packaged resource lookup.  # spec: N-000353..N-000370"""
import os

# spec: N-000353 -- the initial contents are the implementer's choice.
path = [p for p in os.environ.get("LINGORA_DATA", "").split(os.pathsep) if p]
path += [
    os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "lingora_data"),
    os.path.expanduser("~/lingora_data"),
    "/usr/share/lingora_data",
    "/usr/local/share/lingora_data",
]


def find(resource):
    """Return the filesystem path of `resource` found on `data.path`.

    Only the directories currently listed in `path` are searched (N-000354,
    N-000355).  Raises LookupError when it is not visible.
    """
    if not isinstance(resource, str) or not resource:
        raise ValueError("resource name must be a non-empty string")
    parts = resource.replace("\\", "/").strip("/").split("/")
    if any(p in ("", "..", ".") for p in parts):
        raise ValueError("invalid resource name: %r" % (resource,))
    for d in list(path):
        cand = os.path.join(str(d), *parts)
        if os.path.exists(cand):
            return cand
    raise LookupError("Resource %r not found on lingora.data.path" % (resource,))


def read_lines(filename):
    """UTF-8 lines of a file, each without its line terminator (N-000366)."""
    with open(filename, encoding="utf-8", newline="") as f:
        text = f.read()
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    return lines
