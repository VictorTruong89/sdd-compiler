"""Constituent trees.  # spec: N-000444..N-000454"""
import re


class Tree(list):
    def __init__(self, label, children):  # spec: N-000449..N-000451
        if isinstance(children, (str, bytes)) or not isinstance(children, (list, tuple)):
            raise TypeError("children must be a list of children, not %s" % type(children).__name__)
        list.__init__(self, children)
        self._label = label

    __hash__ = None

    def label(self):
        return self._label

    def set_label(self, label):
        self._label = label

    def leaves(self):
        out = []
        for child in self:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def __eq__(self, other):
        if not isinstance(other, Tree):
            return False
        return self._label == other._label and list.__eq__(self, other)

    def __ne__(self, other):
        return not self == other

    def __lt__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return (str(self._label), list(self)) < (str(other._label), list(other))

    def copy(self, deep=False):
        import copy
        return copy.deepcopy(self) if deep else Tree(self._label, list(self))

    def _flat(self):
        parts = []
        for child in self:
            if isinstance(child, Tree):
                parts.append(child._flat())
            elif isinstance(child, tuple):
                parts.append("/".join(str(c) for c in child))
            else:
                parts.append(str(child))
        return "(%s %s)" % (self._label, " ".join(parts))

    def pformat(self, margin=70, indent=0):  # spec: N-000453
        s = self._flat()
        if len(s) + indent < margin:
            return s
        s = "(%s" % (self._label,)
        for child in self:
            if isinstance(child, Tree):
                s += "\n" + " " * (indent + 2) + child.pformat(margin, indent + 2)
            elif isinstance(child, tuple):
                s += "\n" + " " * (indent + 2) + "/".join(str(c) for c in child)
            else:
                s += "\n" + " " * (indent + 2) + str(child)
        return s + ")"

    def pprint(self, **kw):
        print(self.pformat(**kw))

    def __str__(self):
        return self.pformat()

    def __repr__(self):
        return "Tree(%r, [%s])" % (self._label, ", ".join(repr(c) for c in self))

    @classmethod
    def fromstring(cls, s):  # spec: N-000452
        if not isinstance(s, str):
            raise TypeError("bracketed tree text must be a str")
        toks = re.findall(r"\(|\)|[^\s()]+", s)
        if not toks:
            raise ValueError("empty tree text")
        pos = 0

        def parse():
            nonlocal pos
            if toks[pos] != "(":
                raise ValueError("expected '(' at token %d of %r" % (pos, s))
            pos += 1
            label = ""
            if pos < len(toks) and toks[pos] not in ("(", ")"):
                label = toks[pos]
                pos += 1
            children = []
            while True:
                if pos >= len(toks):
                    raise ValueError("unbalanced parentheses in %r" % (s,))
                t = toks[pos]
                if t == ")":
                    pos += 1
                    return cls(label, children)
                if t == "(":
                    children.append(parse())
                else:
                    children.append(t)
                    pos += 1

        tree = parse()
        if pos != len(toks):
            raise ValueError("unexpected text after the end of the tree in %r" % (s,))
        return tree
