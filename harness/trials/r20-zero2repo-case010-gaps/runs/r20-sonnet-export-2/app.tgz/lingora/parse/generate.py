"""Sentence generation from a CFG.  # spec: N-000440..N-000443"""
import itertools
import sys

from lingora.grammar import Nonterminal


def generate(grammar, start=None, depth=None, n=None):
    if start is None:
        start = grammar.start()
    elif isinstance(start, str):
        start = Nonterminal(start)
    if depth is None:
        depth = sys.maxsize
    it = _generate_all(grammar, [start], depth)
    if n is not None:
        it = itertools.islice(it, n)
    return _guard(it)


def _guard(it):
    try:
        yield from it
    except RecursionError:
        raise RuntimeError("The grammar has rule(s) that yield infinite recursion!")


def _generate_all(grammar, items, depth):
    if items:
        for frag1 in _generate_one(grammar, items[0], depth):
            for frag2 in _generate_all(grammar, items[1:], depth):
                yield frag1 + frag2
    else:
        yield []


def _generate_one(grammar, lhs, depth):
    if depth > 0:
        if isinstance(lhs, Nonterminal):
            for prod in grammar.productions(lhs):
                yield from _generate_all(grammar, prod.rhs(), depth - 1)
        else:
            yield [lhs]
