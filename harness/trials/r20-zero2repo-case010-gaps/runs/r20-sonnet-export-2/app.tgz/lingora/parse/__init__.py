"""Parsers.  # spec: N-000424..N-000443, FP-05"""
from lingora.grammar import CFG, Nonterminal
from lingora.tree import Tree


def _check_tokens(grammar, tokens):  # spec: N-000435, N-000438, N-000439
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")
    missing = grammar.covers(tokens)
    if missing:
        raise ValueError("Grammar does not cover some of the input words: %r" % (sorted(set(missing)),))


class ChartParser:
    """Exhaustive parser returning every tree for the token list."""

    def __init__(self, grammar):
        if not isinstance(grammar, CFG):
            raise TypeError("grammar must be a CFG")
        self._grammar = grammar

    def grammar(self):
        return self._grammar

    def parse(self, tokens):
        _check_tokens(self._grammar, tokens)
        return self._parse(list(tokens))

    def _parse(self, tokens):
        g = self._grammar
        n = len(tokens)
        prods = g.productions()
        ends = {}  # (sym, start) -> set(end)

        def reach(rhs, i):
            positions = {i}
            for sym in rhs:
                new = set()
                for p in positions:
                    if isinstance(sym, str):
                        if p < n and tokens[p] == sym:
                            new.add(p + 1)
                    else:
                        new |= ends.get((sym, p), set())
                positions = new
                if not positions:
                    break
            return positions

        changed = True
        while changed:
            changed = False
            for pr in prods:
                for i in range(n + 1):
                    for j in reach(pr.rhs(), i):
                        s = ends.setdefault((pr.lhs(), i), set())
                        if j not in s:
                            s.add(j)
                            changed = True
        start = g.start()
        if n not in ends.get((start, 0), set()):
            return iter(())
        return self._trees(tokens, ends)

    def _trees(self, tokens, ends):
        g = self._grammar
        start = g.start()
        n = len(tokens)

        def build(sym, i, j, stack):
            key = (sym, i, j)
            if key in stack:
                return
            stack = stack | {key}
            for pr in g.productions(sym):
                for kids in expand(pr.rhs(), 0, i, j, stack):
                    yield Tree(str(sym), kids)

        def expand(rhs, k, pos, j, stack):
            if k == len(rhs):
                if pos == j:
                    yield []
                return
            item = rhs[k]
            if isinstance(item, str):
                if pos < j and tokens[pos] == item:
                    for rest in expand(rhs, k + 1, pos + 1, j, stack):
                        yield [item] + rest
                return
            for q in sorted(ends.get((item, pos), ())):
                if q > j:
                    continue
                for sub in build(item, pos, q, stack):
                    for rest in expand(rhs, k + 1, q, j, stack):
                        yield [sub] + rest

        yield from build(start, 0, n, frozenset())


class RecursiveDescentParser(ChartParser):
    """Results are outside the specification; shares the chart parser's output."""


class ShiftReduceParser:
    def __init__(self, grammar):
        if not isinstance(grammar, CFG):
            raise TypeError("grammar must be a CFG")
        self._grammar = grammar

    def grammar(self):
        return self._grammar

    def parse(self, tokens):
        _check_tokens(self._grammar, tokens)
        return self._parse(list(tokens))

    def _match(self, rhs, stack_tail):
        for r, s in zip(rhs, stack_tail):
            if isinstance(r, str):
                if isinstance(s, Tree) or r != s:
                    return False
            else:
                if not isinstance(s, Tree) or s.label() != str(r):
                    return False
        return True

    def _reduce(self, stack):
        for pr in self._grammar.productions():
            rhs = pr.rhs()
            k = len(rhs)
            if k == 0 or k > len(stack):
                continue
            if self._match(rhs, stack[-k:]):
                kids = stack[-k:]
                del stack[-k:]
                stack.append(Tree(str(pr.lhs()), kids))
                return True
        return False

    def _parse(self, tokens):
        stack = []
        remaining = list(tokens)
        while remaining:
            stack.append(remaining.pop(0))
            while self._reduce(stack):
                pass
        if len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == str(self._grammar.start()):
            yield stack[0]
