"""BLEU — `lingora.translate`.

Sentence-level BLEU (Papineni et al., 2002) over token lists.  Unsmoothed by
default; pass a `smoothing_function` (a callable taking the list of
(numerator, denominator) pairs and returning the list of adjusted precisions)
to change that.  `method1` is provided as one such function.
"""

import math
from collections import Counter

__all__ = ["bleu", "method1"]


def method1(p_numerators_denominators, epsilon=0.1):
    """Add `epsilon` to zero numerators (smoothing method 1 of Chen and Cherry, 2014)."""
    out = []
    for num, den in p_numerators_denominators:
        out.append((num if num else epsilon) / den)
    return out


def _check_token_list(tokens, name):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("%s must be a list of str" % name)
    for tok in tokens:
        if not isinstance(tok, str):
            raise TypeError("%s must be a list of str" % name)
    return list(tokens)


def _ngrams(tokens, n):
    return Counter(tuple(tokens[i : i + n]) for i in range(len(tokens) - n + 1))


# spec: N-000289, N-000302, N-000303, N-000304, N-000305, N-000306, N-000307, N-000308, N-000309, N-000475, N-000476, N-000477
def bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):
    """BLEU score of `hypothesis` (token list) against `references` (list of token lists)."""
    if isinstance(references, str) or not isinstance(references, (list, tuple)):
        raise TypeError("references must be a list of token lists")
    refs = [_check_token_list(r, "each reference") for r in references]
    hyp = _check_token_list(hypothesis, "hypothesis")
    if not refs:
        raise ValueError("bleu needs at least one reference")
    try:
        ws = [float(w) for w in weights]
    except (TypeError, ValueError):
        raise TypeError("weights must be a sequence of numbers")
    if not ws:
        raise ValueError("weights must not be empty")

    pairs = []
    for n in range(1, len(ws) + 1):
        hyp_counts = _ngrams(hyp, n)
        total = max(1, sum(hyp_counts.values()))
        max_ref = Counter()
        for ref in refs:
            for gram, count in _ngrams(ref, n).items():
                if count > max_ref[gram]:
                    max_ref[gram] = count
        clipped = sum(min(count, max_ref[gram]) for gram, count in hyp_counts.items())
        pairs.append((clipped, total))

    if smoothing_function is None:
        precisions = [num / den for num, den in pairs]
    else:
        precisions = list(smoothing_function(pairs))

    if not hyp:
        return 0.0
    log_sum = 0.0
    for w, p in zip(ws, precisions):
        if w == 0:
            continue
        if p <= 0:
            return 0.0
        log_sum += w * math.log(p)

    ref_lens = [len(r) for r in refs]
    c = len(hyp)
    r = min(ref_lens, key=lambda rl: (abs(rl - c), rl))
    bp = 1.0 if c > r else math.exp(1 - r / c)
    return bp * math.exp(log_sum)
