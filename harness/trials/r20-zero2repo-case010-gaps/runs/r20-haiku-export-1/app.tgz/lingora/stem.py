"""Stemmers — `lingora.stem`.

Porter (default LINGORA-extended mode, plus the original and Martin modes),
Lancaster (Paice/Husk rule engine), Snowball (English = Porter2 here), a
regular-expression stemmer, and a WordNet lemmatizer that needs the packaged
WordNet resource.  Snowball languages other than English are not implemented;
see NOTES.md.
"""

import os
import re

from . import data

__all__ = [
    "ARLSTem",
    "ARLSTem2",
    "LancasterStemmer",
    "PorterStemmer",
    "RegexpStemmer",
    "SnowballStemmer",
    "WordNetLemmatizer",
]

_SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german",
    "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
    "russian", "spanish", "swedish",
)


def _check_word(word):
    if not isinstance(word, str):
        raise TypeError("word must be a str")


# ================================================================= Porter
# A small table of irregular forms (contents are outside the specification).
_PORTER_IRREGULAR = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie",
    "tying": "tie", "idly": "idl", "gently": "gentl", "ugly": "ugli",
    "early": "earli", "only": "onli", "singly": "singl", "sky": "sky",
    "news": "news", "howe": "howe", "atlas": "atlas", "cosmos": "cosmos",
    "bias": "bias", "andes": "andes",
}

_VOWELS = "aeiou"
# Step 2 suffix -> replacement, LINGORA extensions included
_STEP2_LINGORA = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("bli", "ble"), ("alli", "al"), ("entli", "ent"),
    ("eli", "e"), ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"),
    ("ator", "ate"), ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"),
    ("ousness", "ous"), ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"),
    ("fulli", "ful"), ("logi", "log"),
]
_STEP2_ORIGINAL = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("abli", "able"), ("alli", "al"), ("entli", "ent"),
    ("eli", "e"), ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"),
    ("ator", "ate"), ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"),
    ("ousness", "ous"), ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"),
]
_STEP3 = [
    ("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"),
    ("ical", "ic"), ("ful", ""), ("ness", ""),
]
_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement",
    "ment", "ent", "ion", "ou", "ism", "ate", "iti", "ous", "ive", "ize",
]


def _porter_cons(w, i):
    ch = w[i]
    if ch in _VOWELS:
        return False
    if ch == "y":
        return i == 0 or not _porter_cons(w, i - 1)
    return True


def _porter_measure(stem):
    """Number of VC sequences in the form [C](VC)^m[V]."""
    m = 0
    prev_vowel = False
    seen_vowel = False
    for i in range(len(stem)):
        is_cons = _porter_cons(stem, i)
        if not is_cons:
            seen_vowel = True
            prev_vowel = True
        else:
            if prev_vowel and seen_vowel:
                m += 1
            prev_vowel = False
    return m


def _porter_has_vowel(stem):
    return any(not _porter_cons(stem, i) for i in range(len(stem)))


def _porter_ends_cvc(stem, extension):
    if extension and len(stem) == 2 and not _porter_cons(stem, 0) and _porter_cons(stem, 1):
        return True
    if len(stem) < 3:
        return False
    return (
        _porter_cons(stem, len(stem) - 3)
        and not _porter_cons(stem, len(stem) - 2)
        and _porter_cons(stem, len(stem) - 1)
        and stem[-1] not in "wxy"
    )


def _porter_step2(word, rules, extension):
    if extension and word.endswith("alli") and _porter_measure(word[:-4]) > 0:
        return _porter_step2(word[:-2], rules, extension)
    best = None
    for suffix, repl in rules:
        if word.endswith(suffix) and (best is None or len(suffix) > len(best[0])):
            best = (suffix, repl)
    if best is None:
        return word
    suffix, repl = best
    stem = word[: -len(suffix)]
    if suffix == "bli" and extension:
        # LINGORA: -bli -> -ble, measure taken on the part before -bli
        return stem + repl if _porter_measure(stem) > 0 else word
    if suffix == "logi" and extension:
        # LINGORA: -logi -> -log when the part before -ogi has positive measure
        return stem + "log" if _porter_measure(word[:-3]) > 0 else word
    if _porter_measure(stem) > 0:
        return stem + repl
    return word


class PorterStemmer:
    """Porter stemmer. Modes: NLTK_EXTENSIONS (LINGORA default), ORIGINAL_ALGORITHM, MARTIN_EXTENSIONS."""

    NLTK_EXTENSIONS = "NLTK_EXTENSIONS"
    ORIGINAL_ALGORITHM = "ORIGINAL_ALGORITHM"
    MARTIN_EXTENSIONS = "MARTIN_EXTENSIONS"

    # spec: N-000142, N-000143, N-000144, N-000145, N-000146, N-000147, N-000148, N-000149, N-000150, N-000151, N-000152, N-000153, N-000154, N-000155, N-000156, N-000157, N-000158, N-000159, N-000160
    def __init__(self, mode=NLTK_EXTENSIONS):
        if mode not in (self.NLTK_EXTENSIONS, self.ORIGINAL_ALGORITHM, self.MARTIN_EXTENSIONS):
            raise ValueError("unknown Porter mode %r" % (mode,))
        self.mode = mode

    def stem(self, word, to_lowercase=True):
        _check_word(word)
        ext = self.mode == self.NLTK_EXTENSIONS
        w = word.lower() if to_lowercase else word
        if ext and w in _PORTER_IRREGULAR:
            return _PORTER_IRREGULAR[w]
        if len(w) <= 2:
            return w
        if self.mode == self.ORIGINAL_ALGORITHM:
            rules2 = _STEP2_ORIGINAL
        else:
            rules2 = _STEP2_LINGORA
        ext_steps = ext or self.mode == self.MARTIN_EXTENSIONS

        # Step 1a
        if w.endswith("sses"):
            w = w[:-2]
        elif w.endswith("ies"):
            w = w[:-2] if len(w) == 3 else (w[:-1] if (ext and len(w) == 4) else w[:-2])
        elif w.endswith("ss"):
            pass
        elif w.endswith("s"):
            if _porter_has_vowel(w[:-2]):
                w = w[:-1]

        # Step 1b
        step1b_done = False
        if ext and w.endswith("ied"):
            w = w[:-1] if len(w) == 4 else w[:-2]
            step1b_done = True
        if not step1b_done:
            if w.endswith("eed"):
                if _porter_measure(w[:-3]) > 0:
                    w = w[:-1]
            elif (w.endswith("ed") and _porter_has_vowel(w[:-2])) or (
                w.endswith("ing") and _porter_has_vowel(w[:-3])
            ):
                w = w[:-2] if w.endswith("ed") else w[:-3]
                if w.endswith(("at", "bl", "iz")):
                    w += "e"
                elif len(w) >= 2 and w[-1] == w[-2] and _porter_cons(w, len(w) - 1) and w[-1] not in "lsz":
                    w = w[:-1]
                elif _porter_measure(w) == 1 and _porter_ends_cvc(w, ext_steps):
                    w += "e"

        # Step 1c
        if w.endswith("y"):
            if ext:
                if len(w) >= 3 and _porter_cons(w, len(w) - 2):
                    w = w[:-1] + "i"
            elif _porter_has_vowel(w[:-1]):
                w = w[:-1] + "i"

        # Step 2
        w = _porter_step2(w, rules2, ext_steps)

        # Step 3
        best = None
        for suffix, repl in _STEP3:
            if w.endswith(suffix) and (best is None or len(suffix) > len(best[0])):
                best = (suffix, repl)
        if best is not None and _porter_measure(w[: -len(best[0])]) > 0:
            w = w[: -len(best[0])] + best[1]

        # Step 4
        best = None
        for suffix in _STEP4:
            if w.endswith(suffix) and (best is None or len(suffix) > len(best)):
                best = suffix
        if best is not None:
            stem = w[: -len(best)]
            if _porter_measure(stem) > 1 and (best != "ion" or (stem and stem[-1] in "st")):
                w = stem

        # Step 5a
        if w.endswith("e"):
            stem = w[:-1]
            m = _porter_measure(stem)
            if m > 1 or (m == 1 and not _porter_ends_cvc(stem, ext_steps)):
                w = stem

        # Step 5b
        if _porter_measure(w) > 1 and w.endswith("ll"):
            w = w[:-1]
        return w


# ================================================================= Lancaster
# Paice/Husk rules.  Each rule is `<letters><digit><append>(.|>)` where the
# letters are the suffix written backwards (`de2>` is "-ed > -"); `*` means the
# rule applies only to an intact word, the digit is the number of letters
# removed, `.` stops the process and `>` continues it.
# PARTIAL: this is not the full published table (see NOTES.md).
_LANCASTER_RULES = [
    "ai*2.",     # -ia > -
    "a*1.",      # -a > -
    "bb1.",      # -bb > -b
    "city3s.",   # -ytic > -ys
    "ci2>",      # -ic > -
    "cn1t>",     # -nc > -nt
    "dd1.",      # -dd > -d
    "dei3y>",    # -ied > -y
    "deec2ss.",  # -ceed > -cess
    "dee1.",     # -eed > -ee
    "de2>",      # -ed > -
    "dooh4>",    # -hood > -
    "e1>",       # -e > -
    "feil1v.",   # -lief > -liev
    "fi2>",      # -if > -
    "gi3>",      # -ing > -
    "i1y>",      # -i > -y
    "mu*2.",     # -um > -
    "ll1.",      # -ll > -l
    "mm1.",      # -mm > -m
    "nn1.",      # -nn > -n
    "pp1.",      # -pp > -p
    "rr1.",      # -rr > -r
    "tt1.",      # -tt > -t
    "ss0.",      # -ss > -ss (stop)
]
_LANCASTER_RE = re.compile(r"^([a-z]+)(\*?)(\d)([a-z]*)([.>])$")


def _parse_lancaster(rule):
    m = _LANCASTER_RE.match(rule)
    if not m:
        raise ValueError("bad Lancaster rule %r" % rule)
    letters, intact, remove, append, cont = m.groups()
    return letters[::-1], intact == "*", int(remove), append, cont == "."


_LANCASTER_PARSED = [_parse_lancaster(r) for r in _LANCASTER_RULES]


class LancasterStemmer:
    # spec: N-000161, N-000162
    def stem(self, word):
        _check_word(word)
        w = word.lower()
        intact = True
        for _ in range(1000):
            applied = False
            for suffix, needs_intact, remove, append, stop in _LANCASTER_PARSED:
                if needs_intact and not intact:
                    continue
                if not w.endswith(suffix):
                    continue
                base = w[: len(w) - remove] if remove else w
                if len(base) < 2 or (base[0] not in "aeiou" and len(base) < 3):
                    continue
                w = base + append
                intact = False
                applied = True
                if stop:
                    return w
                break
            if not applied:
                return w
        return w


# ================================================================= Snowball
_PORTER2_EXC1 = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli",
    "only": "onli", "singly": "singl", "sky": "sky", "news": "news",
    "howe": "howe", "atlas": "atlas", "cosmos": "cosmos", "bias": "bias",
    "andes": "andes",
}
_PORTER2_EXC2 = {"inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed"}
_P2_VOWELS = "aeiouy"


def _p2_regions(w):
    """R1 and R2 start indices (len(w) when the region is empty)."""

    def region(start_at):
        for i in range(start_at + 1, len(w)):
            if w[i] not in _P2_VOWELS and w[i - 1] in _P2_VOWELS:
                return i + 1
        return len(w)

    if w.startswith(("gener", "commun", "arsen")):
        r1 = 6 if w.startswith("commun") else 5
    else:
        r1 = region(0)
    r2 = region(r1 - 1) if r1 < len(w) else len(w)
    return min(r1, len(w)), min(r2, len(w))


def _p2_short_syllable_end(w):
    if len(w) >= 3:
        return (
            w[-3] not in _P2_VOWELS
            and w[-2] in _P2_VOWELS
            and w[-1] not in _P2_VOWELS
            and w[-1] not in "wxY"
        )
    if len(w) == 2:
        return w[0] in _P2_VOWELS and w[1] not in _P2_VOWELS
    return False


def _p2_is_short(w, r1):
    return _p2_short_syllable_end(w) and r1 >= len(w)


def _porter2(word):
    if len(word) <= 2:
        return word
    if word in _PORTER2_EXC1:
        return _PORTER2_EXC1[word]
    w = word[1:] if word.startswith("'") else word
    chars = list(w)
    if chars and chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in _P2_VOWELS:
            chars[i] = "Y"
    w = "".join(chars)

    # Step 0
    for suffix in ("'s'", "'s", "'"):
        if w.endswith(suffix):
            w = w[: -len(suffix)]
            break

    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith(("ied", "ies")):
        w = w[:-2] if len(w) > 4 else w[:-1]
    elif w.endswith("us") or w.endswith("ss"):
        pass
    elif w.endswith("s"):
        if any(c in _P2_VOWELS for c in w[:-2]):
            w = w[:-1]
    if w in _PORTER2_EXC2:
        return w.replace("Y", "y")

    r1, r2 = _p2_regions(w)

    # Step 1b
    if w.endswith(("eed", "eedly")):
        suffix = "eedly" if w.endswith("eedly") else "eed"
        if len(w) - len(suffix) >= r1:
            w = w[: -len(suffix)] + "ee"
    else:
        for suffix in ("ingly", "edly", "ing", "ed"):
            if w.endswith(suffix):
                stem = w[: -len(suffix)]
                if any(c in _P2_VOWELS for c in stem):
                    w = stem
                    if w.endswith(("at", "bl", "iz")):
                        w += "e"
                    elif len(w) >= 2 and w[-1] == w[-2] and w[-1] in "bdfgmnprt":
                        w = w[:-1]
                    elif _p2_is_short(w, _p2_regions(w)[0]):
                        w += "e"
                break

    # Step 1c
    if len(w) > 2 and w[-1] in "yY" and w[-2] not in _P2_VOWELS:
        w = w[:-1] + "i"

    r1, r2 = _p2_regions(w)

    # Step 2
    step2 = [
        ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
        ("abli", "able"), ("entli", "ent"), ("izer", "ize"), ("ization", "ize"),
        ("ation", "ate"), ("ator", "ate"), ("alism", "al"), ("aliti", "al"),
        ("alli", "al"), ("fulness", "ful"), ("ousli", "ous"), ("ousness", "ous"),
        ("iveness", "ive"), ("iviti", "ive"), ("biliti", "ble"), ("fulli", "ful"),
        ("lessli", "less"), ("bli", "ble"), ("logi", "log"),
    ]
    for suffix, repl in sorted(step2, key=lambda s: -len(s[0])):
        if w.endswith(suffix):
            if len(w) - len(suffix) >= r1:
                w = w[: -len(suffix)] + repl
            break
    else:
        if w.endswith("li") and len(w) - 2 >= r1 and len(w) >= 3 and w[-3] in "cdeghkmnrt":
            w = w[:-2]

    r1, r2 = _p2_regions(w)

    # Step 3
    for suffix, repl in (("ational", "ate"), ("tional", "tion"), ("alize", "al"),
                         ("icate", "ic"), ("iciti", "ic"), ("ical", "ic"),
                         ("ful", ""), ("ness", "")):
        if w.endswith(suffix):
            if len(w) - len(suffix) >= r1:
                w = w[: -len(suffix)] + repl
            break
    else:
        if w.endswith("ative") and len(w) - 5 >= r2:
            w = w[:-5]

    r1, r2 = _p2_regions(w)

    # Step 4
    for suffix in ("ement", "ance", "ence", "able", "ible", "ment", "ant", "ent",
                   "ism", "ate", "iti", "ous", "ive", "ize", "ion", "al", "er", "ic"):
        if w.endswith(suffix):
            if len(w) - len(suffix) >= r2:
                if suffix == "ion" and not (len(w) >= 4 and w[-4] in "st"):
                    break
                w = w[: -len(suffix)]
            break

    # Step 5
    if w.endswith("e"):
        if len(w) - 1 >= r2 or (len(w) - 1 >= r1 and not _p2_short_syllable_end(w[:-1])):
            w = w[:-1]
    elif w.endswith("l"):
        if len(w) - 1 >= r2 and w[-2:-1] == "l":
            w = w[:-1]

    return w.replace("Y", "y")


# spec: N-000163, N-000164, N-000165, N-000166, N-000167, N-000171, N-000172, N-000173, N-000394, N-000395
class SnowballStemmer:
    """Snowball stemmer. Implemented languages: 'english' (Porter2) and 'porter'."""

    def __init__(self, language, ignore_stopwords=False):
        if not isinstance(language, str) or language not in _SNOWBALL_LANGUAGES:
            raise ValueError("unsupported Snowball language: %r" % (language,))
        if language not in ("english", "porter"):
            raise NotImplementedError(
                "Snowball stemmer for %r is not implemented in this build (see NOTES.md)" % language
            )
        self.language = language
        self.ignore_stopwords = bool(ignore_stopwords)
        self._stopwords = None
        if self.ignore_stopwords:
            rel = os.path.join("corpora", "stopwords", language)
            path = data.find(rel)
            with open(path, encoding="utf-8") as fh:
                self._stopwords = {line.strip() for line in fh if line.strip()}

    def stem(self, word):
        _check_word(word)
        w = word.lower()
        if self._stopwords is not None and w in self._stopwords:
            return w
        if self.language == "porter":
            return PorterStemmer(PorterStemmer.ORIGINAL_ALGORITHM).stem(w, to_lowercase=False)
        return _porter2(w)


# ================================================================= regexp
# spec: N-000168, N-000169, N-000170
class RegexpStemmer:
    def __init__(self, regexp):
        if not isinstance(regexp, str):
            raise TypeError("regexp must be a str")
        self._regexp = re.compile(regexp)

    def stem(self, word):
        _check_word(word)
        return self._regexp.sub("", word)


# ================================================================= not implemented here
class ARLSTem:
    """Arabic light stemmer. Exists in the surface; its results are outside the specification."""

    def stem(self, word):
        raise NotImplementedError("ARLSTem stemming is not implemented in this build (see NOTES.md)")


class ARLSTem2(ARLSTem):
    """Second Arabic light stemmer. Exists in the surface; results outside the specification."""


# ================================================================= WordNet
_WORDNET_SUFFIXES = {
    "n": [("s", ""), ("ses", "s"), ("xes", "x"), ("zes", "z"), ("ches", "ch"),
          ("shes", "sh"), ("men", "man"), ("ies", "y")],
    "v": [("s", ""), ("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"), ("ed", ""),
          ("ing", "e"), ("ing", "")],
    "a": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
    "r": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
}


# spec: N-000396
class WordNetLemmatizer:
    """WordNet lemmatizer; requires the packaged WordNet resource (`corpora/wordnet`)."""

    def __init__(self):
        self._dir = data.find(os.path.join("corpora", "wordnet"))
        self._lemmas = {}

    def _index(self, pos):
        pos = {"s": "a"}.get(pos, pos)
        if pos not in self._lemmas:
            lemmas = set()
            name = {"n": "noun", "v": "verb", "a": "adj", "r": "adv"}[pos]
            path = os.path.join(self._dir, "index." + name)
            if os.path.exists(path):
                with open(path, encoding="utf-8", errors="replace") as fh:
                    for line in fh:
                        if line.startswith(" ") or not line.strip():
                            continue
                        lemmas.add(line.split(" ", 1)[0])
            self._lemmas[pos] = lemmas
        return self._lemmas[pos]

    def lemmatize(self, word, pos="n"):
        _check_word(word)
        if pos not in _WORDNET_SUFFIXES:
            raise ValueError("unknown WordNet part of speech %r" % (pos,))
        lemmas = self._index(pos)
        if word in lemmas:
            return word
        for suffix, repl in _WORDNET_SUFFIXES[pos]:
            if word.endswith(suffix) and len(word) > len(suffix):
                cand = word[: -len(suffix)] + repl
                if cand in lemmas:
                    return cand
        return word
