"""String generation from a grammar — `lingora.parse.generate.generate`.

Enumerates the sentences a grammar derives from `start`.  The leftmost
nonterminal is expanded first and productions are tried in their written
order.  Expansion is breadth-first (by number of expansion steps), so a
recursive grammar yields sentences lazily even without a depth bound.

`depth` bounds the derivation depth: a nonterminal at depth `depth` is not
expanded, so only sentences derivable within that depth are produced.
`n` is the maximum number of sentences.
"""

import itertools
from collections import deque

from ..grammar import CFG, Nonterminal

__all__ = ["generate"]


def generate(grammar, start=None, depth=None, n=None):
    # spec: N-000251, N-000252, N-000253, N-000254, N-000255, N-000440, N-000441, N-000442, N-000443
    if not isinstance(grammar, CFG):
        raise TypeError("generate needs a CFG")
    if start is None:
        start = grammar.start()
    elif isinstance(start, str):
        start = Nonterminal(start)
    if depth is not None and depth < 0:
        raise ValueError("depth must be non-negative")
    if n is not None and n < 0:
        raise ValueError("n must be non-negative")
    sentences = _enumerate(grammar, start, depth)
    if n is None:
        return sentences
    return itertools.islice(sentences, n)


def _enumerate(grammar, start, depth):
    # queue items: (pending symbols as (symbol, level) pairs, tokens so far)
    queue = deque([([(start, 0)], [])])
    while queue:
        pending, out = queue.popleft()
        # emit leading terminals, then expand the leftmost nonterminal
        i = 0
        out = list(out)
        while i < len(pending) and isinstance(pending[i][0], str):
            out.append(pending[i][0])
            i += 1
        pending = pending[i:]
        if not pending:
            yield out
            continue
        sym, level = pending[0]
        if depth is not None and level >= depth:
            continue
        rest = pending[1:]
        for prod in grammar.productions(sym):
            new_pending = [(s, level + 1) for s in prod.rhs()] + rest
            queue.append((new_pending, out))
