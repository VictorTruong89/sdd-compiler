"""Shift-reduce parser — `lingora.parse.ShiftReduceParser`.

A single left-to-right pass without backtracking: whenever the top of the
stack matches the right-hand side of a production it reduces (the longest
matching production wins, then grammar order); otherwise it shifts the next
token.  Empty productions are not used for reduction, since they would reduce
forever.  The result is the one tree the pass completes, or no tree.
"""

from ..tree import Tree
from .chart import _check_tokens


class ShiftReduceParser:
    # spec: N-000247, N-000248, N-000249, N-000250, N-000438, N-000439, N-000266
    def __init__(self, grammar):
        self._grammar = grammar

    def grammar(self):
        return self._grammar

    def parse(self, tokens):
        """Return an iterator over the (zero or one) tree the pass completes."""
        tokens = _check_tokens(self._grammar, tokens)
        return iter(_shift_reduce(self._grammar, tokens))


def _shift_reduce(grammar, tokens):
    start = grammar.start()
    prods = [p for p in grammar.productions() if len(p.rhs()) > 0]
    stack = []  # list of (symbol, node); symbol is a token str or a Nonterminal
    idx = 0
    tried = set()  # (input position, stack symbols, production index) already reduced
    while True:
        candidates = []
        for pi, prod in enumerate(prods):
            rhs = prod.rhs()
            k = len(rhs)
            if k > len(stack):
                continue
            base = len(stack) - k
            if all(stack[base + pos][0] == rhs[pos] for pos in range(k)):
                candidates.append((k, pi, prod))
        # longest right-hand side first, then grammar order
        candidates.sort(key=lambda c: (-c[0], c[1]))
        reduced = False
        for k, pi, prod in candidates:
            key = (idx, tuple(_sym_key(s) for s, _ in stack), pi)
            if key in tried:
                continue
            tried.add(key)
            children = [node for _, node in stack[len(stack) - k :]]
            del stack[len(stack) - k :]
            stack.append((prod.lhs(), Tree(str(prod.lhs()), children)))
            reduced = True
            break
        if reduced:
            continue
        if idx < len(tokens):
            stack.append((tokens[idx], tokens[idx]))
            idx += 1
            continue
        break
    if len(stack) == 1 and not isinstance(stack[0][0], str) and stack[0][0] == start:
        return [stack[0][1]]
    return []


def _sym_key(sym):
    return ("T", sym) if isinstance(sym, str) else ("N", str(sym))
