"""Exhaustive chart parser — `lingora.parse.ChartParser`.

The parser first computes, for every production and start position, the set
of end positions the right-hand side can reach (a fixed point over spans,
which handles empty and unit productions).  It then enumerates every parse
tree for the whole token list, guarding against cyclic re-derivation of the
same (symbol, span) on the current path so the number of trees is finite.
"""

from ..tree import Tree


class ChartParser:
    # spec: N-000242, N-000243, N-000244, N-000245, N-000246, N-000438, N-000439, N-000266, N-000268
    def __init__(self, grammar):
        self._grammar = grammar

    def grammar(self):
        return self._grammar

    def parse(self, tokens):
        """Return an iterator over every parse tree of `tokens`.

        Raises ValueError (eagerly) when a token is produced by no production.
        """
        tokens = _check_tokens(self._grammar, tokens)
        return iter(_all_parses(self._grammar, tokens))


def _check_tokens(grammar, tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")
    terminals = grammar.terminals()
    out = []
    for tok in tokens:
        if not isinstance(tok, str):
            raise TypeError("tokens must be a list of str")
        if tok not in terminals:
            raise ValueError("token %r is produced by no production of the grammar" % tok)
        out.append(tok)
    return out


def _all_parses(grammar, tokens):
    n = len(tokens)
    prods = grammar.productions()
    start = grammar.start()
    # ends[p][i] = set of j such that rhs(p) derives tokens[i:j]
    derive = {}  # (symbol-name, i) -> set of j  for nonterminals

    def sym_ends(sym, i):
        if isinstance(sym, str):
            if i < n and tokens[i] == sym:
                return {i + 1}
            return set()
        return derive.get((str(sym), i), set())

    def seq_ends(rhs, i):
        positions = {i}
        for sym in rhs:
            nxt = set()
            for p in positions:
                nxt |= sym_ends(sym, p)
            positions = nxt
            if not positions:
                break
        return positions

    changed = True
    while changed:
        changed = False
        for prod in prods:
            lhs_key = str(prod.lhs())
            for i in range(n + 1):
                ends = seq_ends(prod.rhs(), i)
                if not ends:
                    continue
                known = derive.setdefault((lhs_key, i), set())
                if not ends <= known:
                    known |= ends
                    changed = True

    if not derive or (str(start), 0) not in derive or n not in derive.get((str(start), 0), set()):
        return []

    def trees_for_symbol(sym, i, j, active):
        if isinstance(sym, str):
            if j == i + 1 and tokens[i] == sym:
                yield sym
            return
        key = (str(sym), i, j)
        if key in active or j not in derive.get((str(sym), i), set()):
            return
        active = active | {key}
        for prod in grammar.productions(sym):
            if j not in seq_ends(prod.rhs(), i):
                continue
            for children in _trees_for_seq(prod.rhs(), 0, i, j, active):
                yield Tree(str(sym), children)

    def _trees_for_seq(rhs, idx, i, j, active):
        if idx == len(rhs):
            if i == j:
                yield []
            return
        sym = rhs[idx]
        for k in range(i, j + 1):
            if isinstance(sym, str):
                if not (k == i + 1 and i < n and tokens[i] == sym):
                    continue
                child_iter = [sym]
            else:
                if k not in derive.get((str(sym), i), set()):
                    continue
                child_iter = trees_for_symbol(sym, i, k, active)
            # the remainder must derive tokens[k:j]
            if not _rest_ok(rhs, idx + 1, k, j):
                continue
            for child in child_iter:
                for rest in _trees_for_seq(rhs, idx + 1, k, j, active):
                    yield [child] + rest

    def _rest_ok(rhs, idx, i, j):
        positions = {i}
        for sym in rhs[idx:]:
            nxt = set()
            for p in positions:
                nxt |= sym_ends(sym, p)
            positions = nxt
            if not positions:
                return False
        return j in positions

    return list(trees_for_symbol(start, 0, n, frozenset()))
