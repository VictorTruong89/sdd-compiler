"""LINGORA — a Python natural-language processing library.

Importing the package downloads nothing.  Submodules: data, tokenize, stem,
tag, chunk, grammar, parse, parse.generate, tree, classify, metrics,
translate, cli.
"""

__version__ = "0.1.0"

from . import data  # noqa: E402
from . import tokenize  # noqa: E402,F401
from . import stem  # noqa: E402,F401
from . import tag  # noqa: E402,F401
from . import chunk  # noqa: E402,F401
from . import grammar  # noqa: E402,F401
from . import parse  # noqa: E402,F401
from . import tree  # noqa: E402,F401
from . import classify  # noqa: E402,F401
from . import metrics  # noqa: E402,F401
from . import translate  # noqa: E402,F401
from . import cli  # noqa: E402,F401

__all__ = [
    "data", "tokenize", "stem", "tag", "chunk", "grammar", "parse",
    "tree", "classify", "metrics", "translate", "cli",
]
