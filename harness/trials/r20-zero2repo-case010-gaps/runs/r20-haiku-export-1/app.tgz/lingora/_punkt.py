"""Punkt unsupervised sentence-boundary detection (Kiss and Strunk, 2006).

Parameters come from the packaged Punkt model for a language directory
(`tokenizers/punkt_tab/<language>/`): abbreviation types, sentence starters,
collocations and orthographic context.  Text is cut into whitespace-delimited
chunks; each chunk is annotated (sentence-final period, abbreviation,
ellipsis, initial, number) and a second pass uses collocations and the
orthographic heuristic to decide the boundaries.
"""

import os
import re

from . import data

__all__ = ["PunktParameters", "load_parameters", "sentence_spans"]

_ORTHO_BEG_UC = 1 << 1
_ORTHO_MID_UC = 1 << 2
_ORTHO_UNK_UC = 1 << 3
_ORTHO_BEG_LC = 1 << 4
_ORTHO_MID_LC = 1 << 5
_ORTHO_UNK_LC = 1 << 6
_ORTHO_UC = _ORTHO_BEG_UC | _ORTHO_MID_UC | _ORTHO_UNK_UC
_ORTHO_LC = _ORTHO_BEG_LC | _ORTHO_MID_LC | _ORTHO_UNK_LC

_LEADING = "\"'`([{¿¡“‘„«"
_TRAILING = "\"')]}>*”’»"
_REALIGN = "\"')]}"
_NUMBER_RE = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")

_cache = {}


class PunktParameters:
    def __init__(self, abbrev_types, sent_starters, collocations, ortho_context):
        self.abbrev_types = set(abbrev_types)
        self.sent_starters = set(sent_starters)
        self.collocations = set(collocations)
        self.ortho_context = dict(ortho_context)


def _read_lines(path):
    with open(path, encoding="utf-8") as fh:
        return [line.rstrip("\r\n") for line in fh]


def load_parameters(language):
    """Load the packaged Punkt parameters for `language` (a directory name).

    Raises LookupError when the model directory is not visible on data.path.
    """
    rel = os.path.join("tokenizers", "punkt_tab", language)
    directory = data.find(rel)
    if not os.path.isdir(directory):
        raise LookupError("Punkt model for %r is not a directory: %s" % (language, directory))
    key = (directory, os.path.getmtime(directory))
    if key in _cache:
        return _cache[key]

    def need(name):
        path = os.path.join(directory, name)
        if not os.path.exists(path):
            raise LookupError("Punkt model file missing: %s" % path)
        return path

    abbrev = {ln.strip().lower() for ln in _read_lines(need("abbrev_types.txt")) if ln.strip()}
    starters = {ln.strip().lower() for ln in _read_lines(need("sent_starters.txt")) if ln.strip()}
    colloc = set()
    for ln in _read_lines(need("collocations.tab")):
        if not ln.strip():
            continue
        parts = ln.split("\t")
        if len(parts) != 2:
            raise ValueError("bad collocations.tab line: %r" % ln)
        colloc.add((parts[0], parts[1]))
    ortho = {}
    for ln in _read_lines(need("ortho_context.tab")):
        if not ln.strip():
            continue
        parts = ln.split("\t")
        if len(parts) != 2:
            raise ValueError("bad ortho_context.tab line: %r" % ln)
        ortho[parts[0]] = int(parts[1])
    params = PunktParameters(abbrev, starters, colloc, ortho)
    _cache[key] = params
    return params


class _Tok:
    __slots__ = (
        "start", "end", "core", "word", "period_final", "ellipsis", "typ",
        "first_upper", "first_lower", "is_initial", "sentbreak", "abbr",
    )


def _make_type(base):
    if _NUMBER_RE.match(base):
        return "##number##"
    return base.lower()


def _annotate(text):
    toks = []
    for m in re.finditer(r"\S+", text):
        chunk = m.group(0)
        t = _Tok()
        t.start, t.end = m.start(), m.end()
        core = chunk.rstrip(_TRAILING) or chunk
        t.core = core
        word = core.lstrip(_LEADING) or core
        t.word = word
        t.ellipsis = core.endswith("..")
        t.period_final = core.endswith(".") and not t.ellipsis
        base = word[:-1] if t.period_final else word
        t.typ = _make_type(base) if base else ""
        first = next((c for c in word if c.isalpha()), word[:1])
        t.first_upper = first.isupper()
        t.first_lower = first.islower()
        t.is_initial = bool(t.period_final and len(base) == 1 and base.isalpha() and base.isupper())
        t.sentbreak = False
        t.abbr = False
        toks.append(t)
    return toks


def _ortho_heuristic(params, t):
    """True: likely sentence starter; False: not one; None: no evidence."""
    ctx = params.ortho_context.get(t.typ, 0)
    if t.first_upper and (ctx & _ORTHO_LC) and not (ctx & _ORTHO_MID_UC):
        return True
    if t.first_lower and ((ctx & _ORTHO_UC) or not (ctx & _ORTHO_BEG_LC)):
        return False
    return None


def sentence_spans(text, language):
    """Return (start, end) character spans of the sentences of `text`."""
    params = load_parameters(language)
    toks = _annotate(text)
    if not toks:
        return []

    # first pass: annotate every chunk on its own
    for t in toks:
        if t.core.endswith("?") or t.core.endswith("!"):
            t.sentbreak = True
        elif t.ellipsis:
            t.abbr = True
        elif t.period_final:
            last_part = t.typ.split("-")[-1]
            if t.typ in params.abbrev_types or last_part in params.abbrev_types:
                t.abbr = True
            else:
                t.sentbreak = True

    # second pass: use the following chunk as evidence
    for i in range(len(toks) - 1):
        t1, t2 = toks[i], toks[i + 1]
        if not (t1.period_final or t1.ellipsis):
            continue
        if (t1.typ, t2.typ) in params.collocations:
            t1.sentbreak = False
            t1.abbr = True
            continue
        if t1.abbr or t1.ellipsis:
            ortho = _ortho_heuristic(params, t2)
            if ortho is True:
                t1.sentbreak = True
                continue
            if t1.first_upper and t2.typ in params.sent_starters:
                t1.sentbreak = True
                continue
        if t1.is_initial or t1.typ == "##number##":
            if _ortho_heuristic(params, t2) is False:
                t1.sentbreak = False
                t1.abbr = True

    # cut the text at the sentence breaks, realigning closing quotes/brackets
    spans = []
    cur = toks[0].start
    for idx in range(len(toks) - 1):
        t = toks[idx]
        if not t.sentbreak:
            continue
        nxt = toks[idx + 1]
        j = nxt.start
        while j < nxt.end and text[j] in _REALIGN:
            j += 1
        if j > nxt.start and j < nxt.end:
            spans.append((cur, j))
            cur = j
        else:
            spans.append((cur, t.end))
            cur = nxt.start
    spans.append((cur, toks[-1].end))
    return [(s, e) for s, e in spans if text[s:e].strip()]
