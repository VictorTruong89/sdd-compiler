"""Classifiers — `lingora.classify`: Naive Bayes, decision tree, and accuracy.

A featureset is a dict from feature names to values; a label is any hashable value.
"""

import math
from collections import Counter, defaultdict

__all__ = ["DecisionTreeClassifier", "NaiveBayesClassifier", "ProbDist", "accuracy"]


def _check_labeled(labeled):
    if isinstance(labeled, (str, bytes)) or not hasattr(labeled, "__iter__"):
        raise TypeError("labeled featuresets must be a list of (featureset, label) pairs")
    out = []
    for pair in labeled:
        if not (isinstance(pair, tuple) and len(pair) == 2):
            raise TypeError("labeled featuresets must be a list of (featureset, label) pairs")
        fs, label = pair
        if not isinstance(fs, dict):
            raise TypeError("a featureset is a dict")
        out.append((fs, label))
    return out


class ProbDist:
    # spec: N-000459, N-000460
    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def samples(self):
        return list(self._probs.keys())

    def max(self):
        return max(self._probs, key=lambda label: self._probs[label])

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._probs)


class NaiveBayesClassifier:
    # spec: N-000455, N-000457, N-000458, N-000277, N-000278, N-000279, N-000280, N-000281, N-000282
    def __init__(self, label_counts, feature_counts, feature_values, total):
        self._label_counts = label_counts  # Counter label -> examples
        self._feature_counts = feature_counts  # (label, fname) -> Counter(value -> count)
        self._feature_values = feature_values  # fname -> set of seen values
        self._total = total
        self._labels = list(label_counts.keys())

    @classmethod
    def train(cls, labeled_featuresets):
        labeled = _check_labeled(labeled_featuresets)
        label_counts = Counter()
        feature_counts = defaultdict(Counter)
        feature_values = defaultdict(set)
        for fs, label in labeled:
            label_counts[label] += 1
            for fname, value in fs.items():
                feature_counts[(label, fname)][value] += 1
                feature_values[fname].add(value)
        return cls(label_counts, feature_counts, feature_values, len(labeled))

    def labels(self):
        return list(self._labels)

    def _log_scores(self, featureset):
        if not self._labels:
            raise ValueError("classifier was trained on no examples")
        scores = {}
        for label in self._labels:
            score = math.log(self._label_counts[label] / self._total)
            for fname, value in featureset.items():
                if fname not in self._feature_values:
                    continue
                counts = self._feature_counts.get((label, fname), Counter())
                n = sum(counts.values())
                k = len(self._feature_values[fname])
                # Laplace-smoothed: an unseen value keeps a non-zero probability
                p = (counts.get(value, 0) + 1) / (n + k + 1)
                score += math.log(p)
            scores[label] = score
        return scores

    def classify(self, featureset):
        scores = self._log_scores(featureset)
        best = None
        for label in self._labels:
            if best is None or scores[label] > scores[best]:
                best = label
        return best

    def prob_classify(self, featureset):
        scores = self._log_scores(featureset)
        top = max(scores.values())
        weights = {label: math.exp(s - top) for label, s in scores.items()}
        total = sum(weights.values())
        return ProbDist({label: w / total for label, w in weights.items()})


class _Node:
    __slots__ = ("feature", "branches", "default", "label")

    def __init__(self, feature=None, branches=None, default=None, label=None):
        self.feature = feature
        self.branches = branches or {}
        self.default = default
        self.label = label


def _majority(labels):
    counts = Counter(labels)
    best = None
    for label in labels:  # first seen wins ties
        if best is None or counts[label] > counts[best]:
            best = label
    return best


def _build_tree(examples, features):
    labels = [label for _, label in examples]
    majority = _majority(labels)
    if len(set(labels)) == 1:
        return _Node(label=majority)
    if not features:
        return _Node(label=majority)
    best_feature = None
    best_correct = -1
    best_groups = None
    for fname in sorted(features, key=str):
        groups = defaultdict(list)
        for fs, label in examples:
            groups[fs.get(fname)].append(label)
        correct = sum(Counter(ls).most_common(1)[0][1] for ls in groups.values())
        if correct > best_correct:
            best_correct = correct
            best_feature = fname
            best_groups = groups
    base = Counter(labels).most_common(1)[0][1]
    if best_correct <= base:
        return _Node(label=majority)
    node = _Node(feature=best_feature, default=majority)
    subsets = defaultdict(list)
    for fs, label in examples:
        subsets[fs.get(best_feature)].append((fs, label))
    for value, subset in subsets.items():
        node.branches[value] = _build_tree(subset, features - {best_feature})
    return node


class DecisionTreeClassifier:
    # spec: N-000283, N-000284, N-000285, N-000286, N-000287, N-000456, N-000457, N-000458
    def __init__(self, root, labels):
        self._root = root
        self._labels = labels

    @classmethod
    def train(cls, labeled_featuresets):
        labeled = _check_labeled(labeled_featuresets)
        features = set()
        for fs, _ in labeled:
            features.update(fs.keys())
        root = _build_tree(labeled, features) if labeled else _Node(label=None)
        labels = []
        for _, label in labeled:
            if label not in labels:
                labels.append(label)
        return cls(root, labels)

    def labels(self):
        return list(self._labels)

    def classify(self, featureset):
        if not self._labels:
            raise ValueError("classifier was trained on no examples")
        node = self._root
        while node.label is None:
            value = featureset.get(node.feature)
            if value in node.branches:
                node = node.branches[value]
            else:
                return node.default
        return node.label


# spec: N-000269, N-000270, N-000271, N-000273, N-000274, N-000276
def accuracy(classifier, gold):
    """Fraction of gold (featureset, label) pairs the classifier labels correctly."""
    pairs = _check_labeled(gold)
    if not pairs:
        raise ValueError("accuracy over no examples is undefined")
    correct = sum(1 for fs, label in pairs if classifier.classify(fs) == label)
    return correct / len(pairs)
