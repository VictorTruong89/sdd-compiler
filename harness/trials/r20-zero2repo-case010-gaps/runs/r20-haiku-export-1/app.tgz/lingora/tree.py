"""Constituent trees — `lingora.tree`.

A Tree has a label and an ordered list of children. A child is a leaf (a
string, or for chunk structures a `(token, tag)` pair) or another Tree.
"""

__all__ = ["Tree"]


class Tree:
    # spec: N-000444, N-000445, N-000446, N-000447, N-000448, N-000449, N-000450, N-000451
    def __init__(self, label, children):
        if isinstance(children, (str, bytes)):
            raise TypeError("Tree children must be a list, not a string")
        if not isinstance(children, list):
            raise TypeError("Tree children must be a list of children")
        self._label = label
        self._children = list(children)

    @classmethod
    def fromstring(cls, s):
        """Build a tree from bracketed tree text `(<label> <child> ...)`.  # spec: N-000452"""
        tokens = _tokenize_bracketed(s)
        pos = 0

        def parse_node():
            nonlocal pos
            if pos >= len(tokens) or tokens[pos] != "(":
                raise ValueError("expected '(' in bracketed tree text")
            pos += 1
            if pos >= len(tokens) or tokens[pos] in ("(", ")"):
                raise ValueError("missing label in bracketed tree text")
            label = tokens[pos]
            pos += 1
            children = []
            while pos < len(tokens) and tokens[pos] != ")":
                if tokens[pos] == "(":
                    children.append(parse_node())
                else:
                    children.append(tokens[pos])
                    pos += 1
            if pos >= len(tokens):
                raise ValueError("unbalanced parentheses in bracketed tree text")
            pos += 1  # consume ')'
            return cls(label, children)

        tree = parse_node()
        if pos != len(tokens):
            raise ValueError("trailing text after bracketed tree")
        return tree

    def label(self):
        return self._label

    def leaves(self):
        out = []
        for child in self._children:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def pformat(self):
        """Pretty-printed form; labels and leaves appear in pre-order.  # spec: N-000453, N-000454, N-000261"""
        lines = []
        self._pformat_into(lines, 0)
        return "\n".join(lines)

    def _pformat_into(self, lines, indent):
        if all(not isinstance(c, Tree) for c in self._children):
            parts = [str(self._label)] + [_leaf_text(c) for c in self._children]
            lines.append(" " * indent + "(" + " ".join(parts) + ")")
            return
        lines.append(" " * indent + "(" + str(self._label))
        for child in self._children:
            if isinstance(child, Tree):
                child._pformat_into(lines, indent + 2)
            else:
                lines.append(" " * (indent + 2) + _leaf_text(child))
        lines[-1] += ")"

    def __iter__(self):
        return iter(self._children)

    def __len__(self):
        return len(self._children)

    def __getitem__(self, index):
        return self._children[index]

    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    def __hash__(self):
        return hash((self._label, tuple(self._children)))

    def __repr__(self):
        return "Tree(%r, %r)" % (self._label, self._children)

    def __str__(self):
        return self.pformat()


def _leaf_text(leaf):
    if isinstance(leaf, tuple):
        return "/".join(str(x) for x in leaf)
    return str(leaf)


def _tokenize_bracketed(s):
    if not isinstance(s, str):
        raise TypeError("bracketed tree text must be a str")
    tokens = []
    buf = []
    for ch in s:
        if ch in "()" or ch.isspace():
            if buf:
                tokens.append("".join(buf))
                buf = []
            if ch in "()":
                tokens.append(ch)
        else:
            buf.append(ch)
    if buf:
        tokens.append("".join(buf))
    return tokens
