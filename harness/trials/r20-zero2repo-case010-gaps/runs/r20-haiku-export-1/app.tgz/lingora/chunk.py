"""Chunking — `lingora.chunk`.

`RegexpParser` applies a chunk grammar to a list of (token, tag) pairs.  A
clause is `LABEL: pattern ...`; `{...}` is a chunk rule and `}...{` a chink
rule.  Patterns are tag patterns: `<regex>` elements over the tag, with an
optional quantifier (`?`, `*`, `+`, `{m}`, `{m,}`, `{m,n}`).

Model of one clause (see NOTES.md):
- a top-level leaf is a (token, tag) pair; its tag is what patterns match;
- a chunk built by an earlier clause is a unit whose tag is its label and
  which later clauses may match (cascading);
- a chunk rule matches runs of top-level leaves and units, never chunks made
  by the same clause; a chink rule removes matches from the same clause's
  chunks.
"""

import os
import re

from . import data
from .tree import Tree

__all__ = ["RegexpParser", "ne_chunk"]

ROOT_LABEL = "SENT"  # default sentence label; differs from ordinary clause labels
_QUANT_RE = re.compile(r"\{\d*,?\d*\}")


class _Rule:
    __slots__ = ("kind", "regexp")

    def __init__(self, kind, regexp):
        self.kind = kind  # "chunk" or "chink"
        self.regexp = regexp


class _Clause:
    __slots__ = ("label", "rules")

    def __init__(self, label, rules):
        self.label = label
        self.rules = rules


def _element_regex(content):
    out = []
    i = 0
    while i < len(content):
        ch = content[i]
        if ch == "\\" and i + 1 < len(content):
            out.append(content[i : i + 2])
            i += 2
            continue
        out.append("[^<>]" if ch == "." else ch)
        i += 1
    return "".join(out)


def _tag_pattern_regex(text):
    """Translate a tag pattern into a regular expression over the tag string `<t1><t2>...`."""
    out = []
    i = 0
    n = len(text)
    while i < n:
        ch = text[i]
        if ch.isspace():
            i += 1
            continue
        if ch != "<":
            raise ValueError("bad tag pattern near %r in %r" % (text[i:], text))
        j = text.find(">", i)
        if j < 0:
            raise ValueError("unterminated element in tag pattern %r" % text)
        content = text[i + 1 : j]
        if not content:
            raise ValueError("empty element in tag pattern %r" % text)
        elem = "(?:<(?:" + _element_regex(content) + ")>)"
        i = j + 1
        quant = ""
        if i < n and text[i] in "?*+":
            quant = text[i]
            i += 1
        elif i < n and text[i] == "{":
            k = text.find("}", i)
            if k < 0:
                raise ValueError("unterminated quantifier in tag pattern %r" % text)
            quant = text[i : k + 1]
            if not re.match(r"^\{\d*,?\d*\}$", quant):
                raise ValueError("bad quantifier %r in tag pattern" % quant)
            i = k + 1
        out.append(elem + quant)
    return "".join(out)


def _scan_rules(body):
    """Split a pattern line into rules: `{...}` chunk rules and `}...{` chink rules."""
    rules = []
    i = 0
    n = len(body)
    while i < n:
        ch = body[i]
        if ch.isspace():
            i += 1
            continue
        if ch == "{":
            kind, close = "chunk", "}"
        elif ch == "}":
            kind, close = "chink", "{"
        else:
            raise ValueError("bad chunk rule near %r" % body[i:])
        j = i + 1
        while True:
            if j >= n:
                raise ValueError("unterminated chunk rule in %r" % body)
            c = body[j]
            if c == "<":
                k = body.find(">", j)
                if k < 0:
                    raise ValueError("unterminated element in %r" % body)
                j = k + 1
            elif c == "{" and _QUANT_RE.match(body, j):
                j = _QUANT_RE.match(body, j).end()
            elif c == close:
                break
            else:
                j += 1
        rules.append((kind, body[i + 1 : j]))
        i = j + 1
    return rules


def _parse_grammar(grammar):
    if isinstance(grammar, (list, tuple)):
        clauses = []
        for stage in grammar:
            if not isinstance(stage, str):
                raise TypeError("chunk grammar stages must be grammar strings")
            clauses.extend(_parse_grammar(stage))
        return clauses
    if not isinstance(grammar, str):
        raise TypeError("grammar must be a str or a list of stages")
    clauses = []
    current = None
    for raw in grammar.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        m = re.match(r"^([A-Za-z_][\w\-]*)\s*:\s*(.*)$", line)
        if m:
            current = _Clause(m.group(1), [])
            clauses.append(current)
            body = m.group(2)
        else:
            if current is None:
                raise ValueError("pattern line before any clause label: %r" % raw)
            body = line
        for kind, inner in _scan_rules(body):
            current.rules.append(_Rule(kind, re.compile(_tag_pattern_regex(inner))))
    return clauses


def _leaf_tag(item):
    if item[0] == "leaf":
        return item[1][1]
    return item[1].label()  # unit (earlier-clause chunk)


def _to_string(items):
    """Tag string for a run of items; chunks of the current clause are sentinels."""
    parts = []
    starts = []
    pos = 0
    for item in items:
        starts.append(pos)
        if item[0] == "chunk":
            parts.append("\x00")
            pos += 1
        else:
            s = "<" + _leaf_tag(item) + ">"
            parts.append(s)
            pos += len(s)
    return "".join(parts), starts


def _apply_chunk(items, label, regexp):
    s, starts = _to_string(items)
    out = []
    cursor = 0  # index into items
    for m in regexp.finditer(s):
        if m.end() == m.start():
            continue
        covered = [k for k, st in enumerate(starts) if m.start() <= st < m.end()]
        if not covered:
            continue
        first, last = covered[0], covered[-1]
        out.extend(items[cursor:first])
        out.append(("chunk", label, list(items[first : last + 1])))
        cursor = last + 1
    out.extend(items[cursor:])
    return out


def _apply_chink(items, regexp):
    out = []
    for item in items:
        if item[0] != "chunk":
            out.append(item)
            continue
        label, children = item[1], item[2]
        s, starts = _to_string(children)
        cuts = []
        for m in regexp.finditer(s):
            if m.end() > m.start():
                cuts.append((m.start(), m.end()))
        if not cuts:
            out.append(item)
            continue
        covered = [False] * len(children)
        for k, st in enumerate(starts):
            for cs, ce in cuts:
                if cs <= st < ce:
                    covered[k] = True
        pieces = []
        run = []
        for k, child in enumerate(children):
            if covered[k]:
                if run:
                    pieces.append(("chunk", label, run))
                    run = []
                pieces.append(child)
            else:
                run.append(child)
        if run:
            pieces.append(("chunk", label, run))
        out.extend(pieces)
    return out


def _to_tree(item):
    if item[0] == "leaf":
        return item[1]
    if item[0] == "unit":
        return item[1]
    return Tree(item[1], [_to_tree(child) for child in item[2]])


class RegexpParser:
    # spec: N-000410, N-000411, N-000412, N-000413, N-000414, N-000416, N-000417, N-000418, N-000419, N-000420, N-000421, N-000422, N-000423
    def __init__(self, grammar):
        self._clauses = _parse_grammar(grammar)

    def parse(self, tagged):
        if isinstance(tagged, str) or not isinstance(tagged, (list, tuple)):
            raise TypeError("tagged must be a list of (token, tag) pairs")
        items = []
        for pair in tagged:
            if not (isinstance(pair, tuple) and len(pair) == 2):
                raise TypeError("tagged must be a list of (token, tag) pairs")
            items.append(("leaf", (pair[0], pair[1])))
        for clause in self._clauses:
            for rule in clause.rules:
                if rule.kind == "chunk":
                    items = _apply_chunk(items, clause.label, rule.regexp)
                else:
                    items = _apply_chink(items, rule.regexp)
            # the clause's chunks become units for later clauses
            items = [("unit", _to_tree(it)) if it[0] == "chunk" else it for it in items]
        return Tree(ROOT_LABEL, [it[1] for it in items])


def ne_chunk(tagged_tokens):
    """Named-entity chunker. Requires the packaged chunker model and the English wordlist.

    Raises LookupError when either resource is not visible. The model file
    format is not part of the specification, so the chunking itself is not
    implemented (see NOTES.md).
    """
    if isinstance(tagged_tokens, str) or not isinstance(tagged_tokens, (list, tuple)):
        raise TypeError("tagged_tokens must be a list of (token, tag) pairs")
    for rel in (os.path.join("chunkers", "maxent_ne_chunker_tab", "english_ace_multiclass"),
                os.path.join("corpora", "words")):
        data.find(rel)
    raise NotImplementedError("named-entity chunking is not implemented in this build (see NOTES.md)")
