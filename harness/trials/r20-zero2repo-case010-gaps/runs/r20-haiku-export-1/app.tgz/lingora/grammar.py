"""Context-free grammars — `lingora.grammar`.

Grammar text has one production per line, written `<LHS> -> <RHS>`.  The RHS is
a sequence of unquoted nonterminals and single- or double-quoted terminals;
`|` separates alternatives, and each alternative is a production of its own.
"""

__all__ = ["CFG", "Production", "Nonterminal", "fromstring"]


class Nonterminal:
    """A nonterminal symbol. `str()` gives its name; it is not a `str` itself."""

    # spec: N-000429, N-000430, N-000431, N-000433
    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __str__(self):
        return self._name

    def __repr__(self):
        return self._name

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and other._name == self._name

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash(("Nonterminal", self._name))


class Production:
    # spec: N-000434
    __slots__ = ("_lhs", "_rhs")

    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        """Terminals appear as `str` (quotes removed); nonterminals as Nonterminal.  # spec: N-000432, N-000433"""
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return (
            isinstance(other, Production)
            and self._lhs == other._lhs
            and self._rhs == other._rhs
        )

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __repr__(self):
        return "%s -> %s" % (self._lhs, " ".join(_sym_text(s) for s in self._rhs))


def _sym_text(sym):
    if isinstance(sym, str):
        return '"%s"' % sym
    return str(sym)


class CFG:
    # spec: N-000424, N-000425, N-000426, N-000427, N-000428
    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)
        self._by_lhs = {}
        for prod in self._productions:
            self._by_lhs.setdefault(prod.lhs(), []).append(prod)

    @classmethod
    def fromstring(cls, input):
        """Read a grammar text; the start symbol is the LHS of the first production."""
        return fromstring(input)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        return list(self._by_lhs.get(lhs, []))

    def is_terminal(self, sym):
        return isinstance(sym, str)

    def terminals(self):
        out = set()
        for prod in self._productions:
            for sym in prod.rhs():
                if isinstance(sym, str):
                    out.add(sym)
        return out

    def __repr__(self):
        return "<CFG with %d productions>" % len(self._productions)


def _split_alternatives(rhs_text):
    """Split an RHS on unquoted `|` into alternatives (each a list of raw items)."""
    alts = [[]]
    i = 0
    n = len(rhs_text)
    while i < n:
        ch = rhs_text[i]
        if ch.isspace():
            i += 1
        elif ch == "|":
            alts.append([])
            i += 1
        elif ch in "'\"":
            end = rhs_text.find(ch, i + 1)
            if end < 0:
                raise ValueError("unterminated quoted terminal in %r" % rhs_text)
            alts[-1].append(("T", rhs_text[i + 1 : end]))
            i = end + 1
        else:
            j = i
            while j < n and not rhs_text[j].isspace() and rhs_text[j] not in "|'\"":
                j += 1
            alts[-1].append(("N", rhs_text[i:j]))
            i = j
    return alts


def fromstring(input):
    """Build a CFG from grammar text.  # spec: N-000427, N-000428"""
    if not isinstance(input, str):
        raise TypeError("grammar text must be a str")
    productions = []
    start = None
    for raw_line in input.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if "->" not in line:
            raise ValueError("production line lacks '->': %r" % raw_line)
        lhs_text, rhs_text = line.split("->", 1)
        lhs_text = lhs_text.strip()
        if not lhs_text or any(c in lhs_text for c in "'\"|") or len(lhs_text.split()) != 1:
            raise ValueError("bad left-hand side in production: %r" % raw_line)
        lhs = Nonterminal(lhs_text)
        if start is None:
            start = lhs
        for alt in _split_alternatives(rhs_text):
            rhs = []
            for kind, text in alt:
                rhs.append(text if kind == "T" else Nonterminal(text))
            productions.append(Production(lhs, rhs))
    if start is None:
        raise ValueError("grammar has no productions")
    return CFG(start, productions)
