"""Command line — `lingora.cli`.

    cli.main(args=['tokenize'], standalone_mode=True)

`tokenize` reads UTF-8 text from standard input and writes, for every input
line, the recommended word tokenizer's tokens (with sentence splitting, which
needs the Punkt model for the language) joined by the delimiter, then a newline.
Options: --language/-l (default english), --delimiter/-d (default one space).
"""

import sys

from .tokenize import word_tokenize

__all__ = ["cli"]

_USAGE = "usage: lingora tokenize [--language LANG] [--delimiter DELIM]\n"


class _Group:
    # spec: N-000382, N-000383, N-000384, N-000385, N-000386, N-000387, N-000388
    def main(self, args=None, standalone_mode=True):
        if args is None:
            args = sys.argv[1:]
        code = self._run(list(args))
        if standalone_mode:
            sys.stdout.flush()
            sys.exit(code)
        return code

    def _run(self, args):
        if not args or args[0] != "tokenize":
            sys.stderr.write(_USAGE)
            return 2
        language = "english"
        delimiter = " "
        i = 1
        while i < len(args):
            opt = args[i]
            if opt in ("--language", "-l", "--delimiter", "-d") and i + 1 < len(args):
                value = args[i + 1]
                if opt in ("--language", "-l"):
                    language = value
                else:
                    delimiter = value
                i += 2
            elif opt.startswith("--language=") or opt.startswith("--delimiter="):
                key, value = opt.split("=", 1)
                if key == "--language":
                    language = value
                else:
                    delimiter = value
                i += 1
            else:
                sys.stderr.write("lingora: unknown option %r\n" % opt)
                sys.stderr.write(_USAGE)
                return 2
        for raw in sys.stdin:
            line = raw.rstrip("\r\n")
            try:
                tokens = word_tokenize(line, language=language, preserve_line=False)
            except Exception as exc:  # the command does not succeed; no token line is written
                sys.stderr.write("lingora: tokenize failed: %s\n" % exc)
                return 1
            sys.stdout.write(delimiter.join(tokens) + "\n")
        return 0


cli = _Group()
