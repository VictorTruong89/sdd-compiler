"""Packaged resource finder — `lingora.data`.

`path` is a mutable list of directories searched for packaged resources.
The library never downloads anything; a resource is either present under one
of the listed directories or it is not.
"""

import os
import sys

__all__ = ["path", "find", "is_visible", "default_path"]


def default_path():
    """Initial contents of `path` (implementer's choice).

    Order: the `LINGORA_DATA` environment variable (os.pathsep-separated),
    then `~/lingora_data`, then the usual system share directories.
    """
    dirs = []
    env = os.environ.get("LINGORA_DATA")
    if env:
        dirs.extend(p for p in env.split(os.pathsep) if p)
    dirs.append(os.path.join(os.path.expanduser("~"), "lingora_data"))
    dirs.append(os.path.join(sys.prefix, "share", "lingora"))
    dirs.append("/usr/local/share/lingora")
    dirs.append("/usr/share/lingora")
    unique = []
    for d in dirs:
        if d not in unique:
            unique.append(d)
    return unique


# spec: N-000353, N-000354, N-000355, N-000356
path = default_path()


def find(relpath):
    """Return the absolute path of the first visible resource `relpath`.

    Raises LookupError when no listed directory holds it.  # spec: N-000354, N-000355
    """
    for directory in list(path):
        candidate = os.path.join(directory, relpath)
        if os.path.exists(candidate):
            return os.path.abspath(candidate)
    raise LookupError(
        "packaged resource %r is not visible in data.path %r" % (relpath, list(path))
    )


def is_visible(relpath):
    """True when the packaged resource `relpath` is visible on `data.path`."""
    try:
        find(relpath)
    except LookupError:
        return False
    return True
