"""Tokenizers — `lingora.tokenize`.

Word/punctuation, Penn Treebank, LINGORA's recommended word tokenizer,
recommended sentence tokenizer (Punkt), whitespace, blank-line, regular
expression and tweet tokenizers, plus span extraction where a tokenizer
supports it.
"""

import re

from ._punkt import sentence_spans

__all__ = [
    "RegexpTokenizer",
    "TreebankWordTokenizer",
    "TweetTokenizer",
    "WhitespaceTokenizer",
    "WordPunctTokenizer",
    "blankline_tokenize",
    "sent_tokenize",
    "word_tokenize",
    "wordpunct_tokenize",
]


def _check_text(text):
    if not isinstance(text, str):
        raise TypeError("text must be a str")


# ---------------------------------------------------------------- word/punct
_WORDPUNCT_RE = re.compile(r"\w+|[^\w\s]+")


# spec: N-000085, N-000086, N-000087
def wordpunct_tokenize(text):
    """Word/punctuation tokenizer: maximal word runs and maximal punctuation runs."""
    _check_text(text)
    return _WORDPUNCT_RE.findall(text)


class WordPunctTokenizer:
    # spec: N-000085, N-000119, N-000120, N-000121
    def tokenize(self, text):
        return wordpunct_tokenize(text)

    def span_tokenize(self, text):
        _check_text(text)
        return [(m.start(), m.end()) for m in _WORDPUNCT_RE.finditer(text)]


# ------------------------------------------------------------------ Treebank
# spec: N-000088, N-000089, N-000090, N-000091, N-000092, N-000093, N-000094, N-000095, N-000096, N-000097, N-000098
_FUSED = [
    (re.compile(r"(?i)\b(can)(not)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(d')(ye)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(gim)(me)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(gon)(na)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(got)(ta)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(lem)(me)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(more)('n)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(wan)(na)(?=\s)"), r"\1 \2"),
    (re.compile(r"(?i)(?<!\w)'(t)(is|was)\b"), r"'\1 \2"),
]
_CLITICS = [
    re.compile(r"(?i)([^\s])(n't)(?=\s)"),
    re.compile(r"(?i)([^\s'])('(?:s|m|d|ll|re|ve))(?=\s)"),
]
_STARTING_DQ = re.compile(r'(^|[ (\[{<])"')
_TYPO_QUOTES = re.compile("([“”„‘’«»])")
_EXT_DASH_STAR = re.compile("([\u2012-\u2015*])")
_BRACKETS = re.compile(r"([\[\](){}<>])")
_PUNCT_CHARS = re.compile(r"([;@#$%&?!])")
_COMMA_COLON = re.compile(r"(?<!\d)([,:])|([,:])(?!\d)")
_FINAL_PERIOD = re.compile(r"(?<=[^.])\.(?=(?:\s*[\"')\]}>])*\s*$)")
_BARE_APOS = re.compile(r"([^'\s])'(?=\s)")


def _pad_match(m):
    return " " + m.group(0) + " "


def _recommended_or_treebank(text, extended):
    s = text
    # starting quotes: a straight double quote at the start, or after space/opening bracket
    s = _STARTING_DQ.sub(lambda m: m.group(1) + " `` ", s)
    # every other straight double quote is a closing quote
    s = s.replace('"', " '' ")
    if extended:
        s = _TYPO_QUOTES.sub(_pad_match, s)
        s = _EXT_DASH_STAR.sub(_pad_match, s)
        s = re.sub(r"\.{2,}", _pad_match, s)
        s = s.replace("--", " -- ")
    else:
        s = re.sub(r"\.\.\.", _pad_match, s)
    s = _PUNCT_CHARS.sub(_pad_match, s)
    s = _BRACKETS.sub(_pad_match, s)
    s = _COMMA_COLON.sub(lambda m: " " + m.group(0) + " ", s)
    s = _FINAL_PERIOD.sub(" . ", s)
    s = " " + s + " "
    for pat, repl in _FUSED:
        s = pat.sub(repl, s)
    for pat in _CLITICS:
        s = pat.sub(r"\1 \2", s)
    s = _BARE_APOS.sub(r"\1 '", s)
    return s.split()


class TreebankWordTokenizer:
    # spec: N-000088, N-000089, N-000090, N-000091, N-000092, N-000093, N-000094, N-000095, N-000096, N-000097, N-000098
    def tokenize(self, text):
        _check_text(text)
        return _recommended_or_treebank(text, extended=False)

    def span_tokenize(self, text):
        _check_text(text)
        return _align(text, self.tokenize(text))


def _align(text, tokens):
    spans = []
    pos = 0
    for tok in tokens:
        idx = text.find(tok, pos)
        width = len(tok)
        if idx < 0 and tok in ("``", "''"):
            idx = text.find('"', pos)
            width = 1
        if idx < 0:
            raise ValueError("token %r cannot be aligned to the text" % tok)
        spans.append((idx, idx + width))
        pos = idx + width
    return spans


def _recommended_word_tokens(sentence):
    """Recommended word tokenizer applied to one already-delimited sentence."""
    return _recommended_or_treebank(sentence, extended=True)


# ---------------------------------------------------------------- whitespace
class WhitespaceTokenizer:
    # spec: N-000106
    def tokenize(self, text):
        _check_text(text)
        return text.split()

    def span_tokenize(self, text):
        _check_text(text)
        return [(m.start(), m.end()) for m in re.finditer(r"\S+", text)]


# spec: N-000107, N-000108
_BLANKLINE_RE = re.compile(r"\s*\n\s*\n\s*")


def blankline_tokenize(text):
    """Segments of text separated by blank lines; empty pieces dropped."""
    _check_text(text)
    return [piece for piece in _BLANKLINE_RE.split(text) if piece]


# ---------------------------------------------------------------- regexp
class RegexpTokenizer:
    # spec: N-000109, N-000110, N-000111
    def __init__(self, pattern, gaps=False, discard_empty=True):
        if not isinstance(pattern, str):
            raise TypeError("pattern must be a str")
        self._regexp = re.compile(pattern)
        self._gaps = bool(gaps)
        self._discard_empty = bool(discard_empty)

    def _spans(self, text):
        spans = []
        if self._gaps:
            last = 0
            for m in self._regexp.finditer(text):
                spans.append((last, m.start()))
                last = m.end()
            spans.append((last, len(text)))
        else:
            spans = [(m.start(), m.end()) for m in self._regexp.finditer(text)]
        if self._discard_empty:
            spans = [(s, e) for s, e in spans if e > s]
        return spans

    def tokenize(self, text):
        _check_text(text)
        return [text[s:e] for s, e in self._spans(text)]

    def span_tokenize(self, text):
        _check_text(text)
        return self._spans(text)


# ---------------------------------------------------------------- tweets
_EMOTICON = (
    r"(?:[<>]?[:;=8][\-o\*\']?[\)\]\(\[dDpP/\:\}\{@\|\\]"
    r"|[\)\]\(\[dDpP/\:\}\{@\|\\][\-o\*\']?[:;=8][<>]?"
    r"|<3)"
)
_TWEET_RE = re.compile(
    r"(?P<url>(?:https?://|www\.)\S+)"
    r"|(?P<emo>" + _EMOTICON + r")"
    r"|(?P<handle>@\w+)"
    r"|(?P<hashtag>\#\w+)"
    r"|(?P<num>[+-]?\d+(?:[.,]\d+)+)"
    r"|(?P<word>\w+(?:'\w+)*)"
    r"|(?P<punct>(?P<pc>[^\w\s])(?P=pc)*)"
)
_HANDLE_RE = re.compile(r"(?<!\w)@[A-Za-z0-9_]{1,15}(?![A-Za-z0-9_])")


class TweetTokenizer:
    # spec: N-000112, N-000113, N-000114, N-000115, N-000116, N-000117, N-000118
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self._preserve_case = bool(preserve_case)
        self._reduce_len = bool(reduce_len)
        self._strip_handles = bool(strip_handles)

    def tokenize(self, text):
        _check_text(text)
        s = text
        if self._strip_handles:
            s = _HANDLE_RE.sub(" ", s)
        if self._reduce_len:
            s = re.sub(r"(.)\1{2,}", r"\1\1\1", s, flags=re.DOTALL)
        out = []
        for m in _TWEET_RE.finditer(s):
            tok = m.group(0)
            if m.lastgroup != "emo" and not self._preserve_case:
                tok = tok.lower()
            out.append(tok)
        return out


# ---------------------------------------------------------------- sentences
def sent_tokenize(text, language="english"):
    """Recommended sentence tokenizer (Punkt). Requires the Punkt model for `language`."""
    _check_text(text)
    return [text[s:e] for s, e in sentence_spans(text, language)]


def word_tokenize(text, language="english", preserve_line=False):
    """Recommended word tokenizer.

    With `preserve_line=False` the text is first split into sentences (which
    requires the Punkt model for `language`); with `preserve_line=True` the text
    is one already-delimited line.
    """
    _check_text(text)
    if preserve_line:
        return _recommended_word_tokens(text)
    tokens = []
    for sentence in sent_tokenize(text, language):
        tokens.extend(_recommended_word_tokens(sentence))
    return tokens
