"""Evaluation metrics — `lingora.metrics`.

Edit distance (Levenshtein, optional unrestricted Damerau–Levenshtein), Jaccard
distance, accuracy, precision, recall and f-measure.  All are pure functions of
their arguments.
"""

__all__ = ["accuracy", "edit_distance", "f_measure", "jaccard_distance", "precision", "recall"]


def _as_number(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError("%s must be a number" % name)
    return value


def _check_sets(reference, test):
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        raise TypeError("reference and test must be sets")


# spec: N-000292, N-000293, N-000294, N-000295, N-000296, N-000297, N-000298, N-000299, N-000315
def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Minimum total cost of edits turning s1 into s2.

    Insertion and deletion cost 1; substitution costs `substitution_cost`; with
    `transpositions=True` an adjacent transposition costs 1 (unrestricted
    Damerau–Levenshtein, Lowrance and Wagner 1975).
    """
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("edit_distance takes two str arguments")
    sub = _as_number(substitution_cost, "substitution_cost")
    if transpositions:
        return _damerau_unrestricted(s1, s2, sub)
    n, m = len(s1), len(s2)
    prev = [j for j in range(m + 1)]
    for i in range(1, n + 1):
        cur = [i] + [0] * m
        for j in range(1, m + 1):
            cost = 0 if s1[i - 1] == s2[j - 1] else sub
            cur[j] = min(prev[j - 1] + cost, prev[j] + 1, cur[j - 1] + 1)
        prev = cur
    return prev[m]


def _damerau_unrestricted(s1, s2, sub):
    n, m = len(s1), len(s2)
    inf = (n + m + 1) * max(abs(sub), 2) + 1
    d = {(-1, -1): inf}
    for i in range(n + 1):
        d[i, -1] = inf
        d[i, 0] = i
    for j in range(m + 1):
        d[-1, j] = inf
        d[0, j] = j
    last_row = {}  # char -> last row in s1 where it occurred
    for i in range(1, n + 1):
        last_col = 0  # last column in s2 that matched s1[i-1]
        for j in range(1, m + 1):
            i1 = last_row.get(s2[j - 1], 0)
            j1 = last_col
            if s1[i - 1] == s2[j - 1]:
                cost = 0
                last_col = j
            else:
                cost = sub
            d[i, j] = min(
                d[i - 1, j - 1] + cost,
                d[i, j - 1] + 1,
                d[i - 1, j] + 1,
                d[i1 - 1, j1 - 1] + (i - i1 - 1) + 1 + (j - j1 - 1),
            )
        last_row[s1[i - 1]] = i
    return d[n, m]


# spec: N-000469
def jaccard_distance(label1, label2):
    """1 - |A ∩ B| / |A ∪ B| (0.0 when both sets are empty; implementer's choice)."""
    _check_sets(label1, label2)
    union = len(label1 | label2)
    if union == 0:
        return 0.0
    inter = len(label1 & label2)
    return (union - inter) / union


# spec: N-000310, N-000464, N-000465, N-000471
def accuracy(reference, test):
    """Fraction of positions at which the two equal-length lists hold equal values."""
    if not isinstance(reference, (list, tuple)) or not isinstance(test, (list, tuple)):
        raise TypeError("accuracy takes two lists")
    if len(reference) != len(test):
        raise ValueError("accuracy needs lists of equal length")
    if not reference:
        raise ValueError("accuracy over no positions is undefined")
    same = sum(1 for x, y in zip(reference, test) if x == y)
    return same / len(reference)


# spec: N-000300, N-000301
def precision(reference, test):
    """|reference ∩ test| / |test|; None when test is empty."""
    _check_sets(reference, test)
    if not test:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    """|reference ∩ test| / |reference|; None when reference is empty."""
    _check_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    """Weighted harmonic mean 1 / (alpha/precision + (1-alpha)/recall); None if either set is empty."""
    _check_sets(reference, test)
    alpha = _as_number(alpha, "alpha")
    p = precision(reference, test)
    r = recall(reference, test)
    if p is None or r is None:
        return None
    if p == 0 or r == 0:
        return 0.0
    return 1 / (alpha / p + (1 - alpha) / r)
