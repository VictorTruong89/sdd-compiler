"""Part-of-speech taggers — `lingora.tag`.

Trainable sequential taggers (default, unigram, regular-expression) with
optional backoff, and LINGORA's recommended greedy averaged perceptron tagger
for English and Russian, which reads a packaged model.
"""

import json
import os
import re
from collections import Counter, defaultdict

from . import data

__all__ = ["DefaultTagger", "RegexpTagger", "UnigramTagger", "pos_tag"]


def _check_tokens(tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")
    for tok in tokens:
        if not isinstance(tok, str):
            raise TypeError("tokens must be a list of str")
    return list(tokens)


class _SequentialTagger:
    backoff = None

    def _raw_tags(self, tokens):
        raise NotImplementedError

    # spec: N-000185, N-000186, N-000194, N-000195
    def tag(self, tokens):
        """Return a list of (token, tag) pairs; `tag` is None when no tag is assigned."""
        tokens = _check_tokens(tokens)
        if not tokens:
            return []
        tags = self._raw_tags(tokens)
        if self.backoff is not None:
            # a backoff tagger is consulted only for tokens left without a tag
            fallback = self.backoff.tag(tokens)
            tags = [t if t is not None else fallback[i][1] for i, t in enumerate(tags)]
        return list(zip(tokens, tags))


class DefaultTagger(_SequentialTagger):
    # spec: N-000187
    def __init__(self, tag):
        self._tag = tag

    def _raw_tags(self, tokens):
        return [self._tag] * len(tokens)


class UnigramTagger(_SequentialTagger):
    # spec: N-000188, N-000189, N-000190
    def __init__(self, train=None, backoff=None):
        self.backoff = backoff
        counts = defaultdict(Counter)
        for sentence in train or []:
            for pair in sentence:
                word, tag = pair
                if tag is not None:
                    counts[word][tag] += 1
        self._model = {}
        for word, tagcounts in counts.items():
            # most frequent tag; ties broken by tag string order (implementer's choice)
            self._model[word] = sorted(tagcounts.items(), key=lambda kv: (-kv[1], str(kv[0])))[0][0]

    def _raw_tags(self, tokens):
        return [self._model.get(tok) for tok in tokens]


class RegexpTagger(_SequentialTagger):
    # spec: N-000191, N-000192, N-000193
    def __init__(self, regexps, backoff=None):
        self.backoff = backoff
        self._rules = [(re.compile(pat), tag) for pat, tag in regexps]

    def _raw_tags(self, tokens):
        out = []
        for tok in tokens:
            tag = None
            for regexp, rule_tag in self._rules:
                if regexp.match(tok):
                    tag = rule_tag
                    break
            out.append(tag)
        return out


# ------------------------------------------------- averaged perceptron (recommended)
_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]


def _normalize(word):
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word and word[0].isdigit():
        return "!DIGITS"
    return word.lower()


class _Perceptron:
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = classes

    def predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            if value == 0 or feat not in self.weights:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))

    def tag_tokens(self, tokens):
        prev, prev2 = _START
        output = []
        context = _START + [_normalize(w) for w in tokens] + _END
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if tag is None:
                features = _features(i, word, context, prev, prev2)
                tag = self.predict(features)
            output.append((word, tag))
            prev2, prev = prev, tag
        return output


def _features(i, word, context, prev, prev2):
    """Feature templates of the averaged perceptron tagger.

    `context` is padded with two start and two end symbols, so the current
    word is `context[i + 2]`.
    """
    features = defaultdict(int)

    def add(name, *args):
        features[" ".join((name,) + tuple(args))] += 1

    j = i + 2
    add("bias")
    add("i suffix", word[-3:])
    add("i pref1", word[0] if word else "")
    add("i-1 tag", prev)
    add("i-2 tag", prev2)
    add("i tag+i-2 tag", prev, prev2)
    add("i word", context[j])
    add("i-1 tag+i word", prev, context[j])
    add("i-1 word", context[j - 1])
    add("i-1 suffix", context[j - 1][-3:])
    add("i-2 word", context[j - 2])
    add("i+1 word", context[j + 1])
    add("i+1 suffix", context[j + 1][-3:])
    add("i+2 word", context[j + 2])
    return features


_model_cache = {}


def _load_model(lang):
    name = "averaged_perceptron_tagger_%s" % lang
    rel = os.path.join("taggers", name)
    directory = data.find(rel)
    key = (directory, os.path.getmtime(directory))
    if key in _model_cache:
        return _model_cache[key]

    def load(suffix):
        path = os.path.join(directory, name + suffix)
        if not os.path.exists(path):
            raise LookupError("averaged perceptron tagger file missing: %s" % path)
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)

    model = _Perceptron(
        load(".weights.json"), load(".tagdict.json"), list(load(".classes.json"))
    )
    _model_cache[key] = model
    return model


# Russian National Corpus part-of-speech category -> universal category
# (exact table is the implementer's choice; mapping is by the part before '=').
_RUS_TO_UNIVERSAL = {
    "S": "NOUN",
    "A": "ADJ",
    "A-PRO": "DET",
    "A-NUM": "ADJ",
    "ANUM": "ADJ",
    "NUM": "NUM",
    "V": "VERB",
    "ADV": "ADV",
    "ADV-PRO": "ADV",
    "ADVPRO": "ADV",
    "PRAEDIC": "ADV",
    "PRAEDIC-PRO": "PRON",
    "PARENTH": "ADV",
    "PRED": "ADV",
    "PR": "ADP",
    "CONJ": "CCONJ",
    "PART": "PART",
    "INTJ": "INTJ",
    "SPRO": "PRON",
}


def _load_en_ptb_map():
    rel = os.path.join("taggers", "universal_tagset", "en-ptb.map")
    path = data.find(rel)
    mapping = {}
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            parts = line.split()
            if len(parts) == 2:
                mapping[parts[0]] = parts[1]
    return mapping


def _to_universal(lang, tagged):
    if lang == "eng":
        mapping = _load_en_ptb_map()
        out = []
        for tok, tag in tagged:
            if tag not in mapping:
                raise LookupError("no universal mapping for English tag %r" % tag)
            out.append((tok, mapping[tag]))
        return out
    out = []
    for tok, tag in tagged:
        if tag is None:
            out.append((tok, None))
            continue
        part = tag.split("=", 1)[0]
        out.append((tok, _RUS_TO_UNIVERSAL.get(part, "X")))
    return out


# spec: N-000397, N-000398, N-000404, N-000405, N-000406, N-000407, N-000408, N-000409
def pos_tag(tokens, tagset=None, lang="eng"):
    """LINGORA's recommended tagger: English ('eng') or Russian ('rus').

    Returns one (token, tag) pair per input token.  Raises for a raw string,
    an unsupported language, a missing model, or an unknown tagset.
    """
    tokens = _check_tokens(tokens)
    if lang not in ("eng", "rus"):
        raise ValueError("unsupported language for pos_tag: %r" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("tagset must be None or 'universal'")
    model = _load_model(lang)
    if not tokens:
        tagged = []
    else:
        tagged = model.tag_tokens(tokens)
    if tagset == "universal":
        tagged = _to_universal(lang, tagged)
    return tagged
