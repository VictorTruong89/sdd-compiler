"""Grammars, parsers, generator and trees (FP-05, lingora.grammar/parse/tree)."""

import pytest

from lingora.grammar import CFG
from lingora.parse import ChartParser, ShiftReduceParser
from lingora.parse.generate import generate
from lingora.tree import Tree

GRAMMAR = """
S -> NP VP
NP -> Det N | NP PP | 'I'
VP -> V NP | VP PP
PP -> P NP
Det -> 'the' | 'a'
N -> 'man' | 'dog' | 'telescope'
V -> 'saw'
P -> 'with' | 'in'
"""


# spec: N-000424, N-000427, N-000428, N-000429, N-000432, N-000433, N-000434
def test_N_000424_grammar_reader():
    g = CFG.fromstring(GRAMMAR)
    assert str(g.start()) == "S"
    assert g.start() != "S"  # nonterminals are not str
    prods = g.productions()
    assert len(prods) == 15  # one production per alternative
    np_alt = [p for p in prods if str(p.lhs()) == "NP"][2]
    assert np_alt.rhs() == ("I",)
    assert isinstance(np_alt.rhs()[0], str)
    assert not isinstance(g.productions()[0].rhs()[0], str)


def test_N_000238_empty_production_and_quoted_empty_terminal():
    g = CFG.fromstring("S -> A 'x'\nA ->\nB -> ''")
    assert g.productions()[1].rhs() == ()
    assert g.productions()[2].rhs() == ("",)


# spec: N-000242, N-000243, N-000244, N-000245, N-000246
def test_N_000242_chart_parser_all_trees():
    g = CFG.fromstring(GRAMMAR)
    trees = list(ChartParser(g).parse("I saw the man with the telescope".split()))
    assert len(trees) == 2
    for t in trees:
        assert t.label() == "S"
        assert t.leaves() == "I saw the man with the telescope".split()


def test_N_000268_chart_parser_no_parse_is_empty():
    g = CFG.fromstring(GRAMMAR)
    assert list(ChartParser(g).parse("the dog saw the".split())) == []


def test_N_000266_unknown_token_refused():
    g = CFG.fromstring(GRAMMAR)
    with pytest.raises(ValueError):
        ChartParser(g).parse(["zebra"])


# spec: N-000247, N-000248, N-000249, N-000250
def test_N_000247_shift_reduce_matches_chart_when_unambiguous():
    g = CFG.fromstring("S -> NP VP\nNP -> 'dogs'\nVP -> 'bark'")
    sr = list(ShiftReduceParser(g).parse(["dogs", "bark"]))
    ch = list(ChartParser(g).parse(["dogs", "bark"]))
    assert sr == ch and len(sr) == 1


# spec: N-000251, N-000252, N-000253, N-000254, N-000440, N-000441, N-000443
def test_N_000251_generator_order_depth_and_count():
    g = CFG.fromstring("S -> 'a' S | 'b' | ''")
    # breadth-first by expansion steps; productions in written order
    assert list(generate(g, depth=3, n=5)) == [
        ["b"], [""], ["a", "b"], ["a", ""], ["a", "a", "b"],
    ]
    # left recursion with no depth bound still yields lazily
    assert list(generate(g, n=2)) == [["b"], [""]]


# spec: N-000444, N-000446, N-000447, N-000448, N-000449, N-000450, N-000451, N-000452, N-000453
def test_N_000444_tree_construction_and_refusals():
    t = Tree.fromstring("(S (NP the dog) (VP barks))")
    assert t.label() == "S"
    assert len(t) == 2
    assert t[0] == Tree("NP", ["the", "dog"])
    assert t.leaves() == ["the", "dog", "barks"]
    with pytest.raises(TypeError):
        Tree("X", "abc")
    with pytest.raises(TypeError):
        Tree("X")
    assert Tree("X", []).leaves() == []
    assert "NP" in t.pformat() and "barks" in t.pformat()
