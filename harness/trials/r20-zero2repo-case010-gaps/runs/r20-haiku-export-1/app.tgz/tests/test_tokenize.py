"""Tokenizers (FP-01, lingora.tokenize)."""

import pytest

from lingora.tokenize import (
    RegexpTokenizer,
    TreebankWordTokenizer,
    TweetTokenizer,
    WhitespaceTokenizer,
    WordPunctTokenizer,
    blankline_tokenize,
    sent_tokenize,
    word_tokenize,
    wordpunct_tokenize,
)


# spec: N-000085, N-000086, N-000087, N-000119
def test_N_000085_wordpunct_runs():
    assert wordpunct_tokenize("Hello, world! It costs $3.50...") == [
        "Hello", ",", "world", "!", "It", "costs", "$", "3", ".", "50", "...",
    ]


def test_N_000119_wordpunct_spans_are_ordered():
    text = "a  bb c"
    spans = WordPunctTokenizer().span_tokenize(text)
    assert spans == [(0, 1), (3, 5), (6, 7)]
    assert all(spans[i][1] <= spans[i + 1][0] for i in range(len(spans) - 1))


# spec: N-000088, N-000090, N-000091, N-000092, N-000093, N-000095, N-000096, N-000097
def test_N_000088_treebank_conventions():
    tok = TreebankWordTokenizer().tokenize
    assert tok('"Hi," she said. "Bye."') == [
        "``", "Hi", ",", "''", "she", "said.", "``", "Bye", ".", "''",
    ]
    assert tok("I can't, gonna go") == ["I", "ca", "n't", ",", "gon", "na", "go"]
    assert tok("cannot") == ["can", "not"]
    assert tok("dogs' bowls") == ["dogs", "'", "bowls"]


def test_N_000096_treebank_clitics():
    assert TreebankWordTokenizer().tokenize("They'll save John's") == ["They", "'ll", "save", "John", "'s"]


def test_N_000099_recommended_word_tokenizer_improvements(packaged):
    # one already-delimited line: no sentence splitting, no model needed
    assert word_tokenize("He said “hi” -- fine ** ok..", preserve_line=True) == [
        "He", "said", "“", "hi", "”", "--", "fine", "*", "*", "ok", "..",
    ]


# spec: N-000106, N-000107, N-000108
def test_N_000106_whitespace_and_blankline():
    assert WhitespaceTokenizer().tokenize(" a\tb\n c ") == ["a", "b", "c"]
    assert blankline_tokenize("a b\n\n\n c\nd \n \n e") == ["a b", "c\nd", "e"]


# spec: N-000109, N-000110, N-000111
def test_N_000109_regexp_token_and_gap_modes():
    assert RegexpTokenizer(r"\w+").tokenize("ab, cd") == ["ab", "cd"]
    assert RegexpTokenizer(r",\s*", gaps=True).tokenize("ab, cd,") == ["ab", "cd"]
    assert RegexpTokenizer(r",\s*", gaps=True, discard_empty=False).tokenize("ab, cd,") == ["ab", "cd", ""]


# spec: N-000112, N-000113, N-000114, N-000116, N-000117, N-000118
def test_N_000112_tweet_tokenizer():
    assert TweetTokenizer().tokenize("Don't stop @bob :) #fun http://x.co/a") == [
        "Don't", "stop", "@bob", ":)", "#fun", "http://x.co/a",
    ]
    assert TweetTokenizer(strip_handles=True).tokenize("hi @bob there") == ["hi", "there"]
    assert TweetTokenizer(preserve_case=False).tokenize("HELLO :D") == ["hello", ":D"]
    assert TweetTokenizer(reduce_len=True).tokenize("sooooo") == ["sooo"]
    assert TweetTokenizer().tokenize("café") == ["café"]


# spec: N-000122, N-000124, N-000125, N-000126, N-000381
def test_N_000122_sent_tokenize_with_punkt(packaged):
    sents = sent_tokenize("Mr. Smith went home. The dog barked! It was late.")
    assert sents == ["Mr. Smith went home.", "The dog barked!", "It was late."]


def test_N_000381_sent_tokenize_needs_model(no_packaged):
    with pytest.raises(LookupError):
        sent_tokenize("A sentence. Another one.")


# spec: N-000129, N-000130, N-000131
def test_N_000129_empty_input_yields_empty_list(packaged):
    assert wordpunct_tokenize("") == []
    assert WhitespaceTokenizer().tokenize("   ") == []
    assert word_tokenize("", preserve_line=True) == []
    assert word_tokenize("   ", preserve_line=True) == []


def test_N_000131_word_tokenize_needs_punkt_when_splitting(no_packaged):
    with pytest.raises(LookupError):
        word_tokenize("Hello there.")
    assert word_tokenize("Hello there.", preserve_line=True) == ["Hello", "there", "."]


# spec: N-000325, N-000330, N-000329
def test_N_000325_cpu_baseline_tokenizes_with_no_model(no_packaged):
    import lingora
    assert lingora.tokenize.wordpunct_tokenize("A real baseline run.") == ["A", "real", "baseline", "run", "."]
