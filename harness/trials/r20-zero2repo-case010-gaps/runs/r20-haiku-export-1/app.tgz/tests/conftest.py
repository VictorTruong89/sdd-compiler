"""Shared fixtures: a small packaged-data tree built in a temp dir.

The real packaged models are not in this repository; these fixtures stand in
for them so the model-reading code paths can be exercised.
"""

import json
import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from lingora import data  # noqa: E402


def _write(base, rel, text):
    path = os.path.join(base, rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)


@pytest.fixture
def packaged(tmp_path, monkeypatch):
    """Point data.path at a fixture tree and return its root."""
    base = str(tmp_path / "data")
    _write(base, "tokenizers/punkt_tab/english/abbrev_types.txt", "mr\ndr\nst\n")
    _write(base, "tokenizers/punkt_tab/english/sent_starters.txt", "the\nit\n")
    _write(base, "tokenizers/punkt_tab/english/collocations.tab", "New\tYork\n")
    _write(
        base,
        "tokenizers/punkt_tab/english/ortho_context.tab",
        "the\t2\nit\t2\nhe\t2\nsmith\t4\nSmith\t4\nwent\t32\nhere\t32\nwho\t4\nwashington\t4\n",
    )
    tagdir = "taggers/averaged_perceptron_tagger_eng"
    weights = {
        "bias": {"NN": 1.0},
        "i word the": {"DT": 5.0},
        "i word dog": {"NN": 3.0},
        "i word barked": {"VBD": 4.0},
        "i suffix ked": {"VBD": 2.0},
    }
    _write(base, tagdir + "/averaged_perceptron_tagger_eng.weights.json", json.dumps(weights))
    _write(base, tagdir + "/averaged_perceptron_tagger_eng.tagdict.json", json.dumps({"the": "DT"}))
    _write(base, tagdir + "/averaged_perceptron_tagger_eng.classes.json", json.dumps(["DT", "NN", "VBD"]))
    _write(base, "taggers/universal_tagset/en-ptb.map", "DT\tDET\nNN\tNOUN\nVBD\tVERB\n")
    _write(base, "corpora/stopwords/english", "the\na\nof\n")
    _write(base, "corpora/wordnet/index.noun", "dog  n 1 0 1 1 00001 0 1 00002\n")
    _write(base, "corpora/words", "dog\ncat\n")
    monkeypatch.setattr(data, "path", [base])
    return base


@pytest.fixture
def no_packaged(tmp_path, monkeypatch):
    """data.path with nothing visible."""
    monkeypatch.setattr(data, "path", [str(tmp_path / "empty")])
    return str(tmp_path / "empty")
