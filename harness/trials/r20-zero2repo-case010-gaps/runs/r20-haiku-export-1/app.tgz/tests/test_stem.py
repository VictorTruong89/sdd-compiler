"""Stemmers (FP-02, lingora.stem)."""

import pytest

from lingora.stem import LancasterStemmer, PorterStemmer, RegexpStemmer, SnowballStemmer, WordNetLemmatizer


# spec: N-000142, N-000145, N-000150, N-000151
def test_N_000145_porter_default_mode():
    p = PorterStemmer()
    assert p.stem("caresses") == "caress"
    assert p.stem("ponies") == "poni"
    assert p.stem("ties") == "tie"
    assert p.stem("motoring") == "motor"
    assert p.stem("relational") == "relat"
    assert p.stem("generalizations") == "gener"


# spec: N-000146, N-000148, N-000149
def test_N_000146_lowercasing_and_short_words():
    p = PorterStemmer()
    assert p.stem("RUNNING") == "run"
    assert p.stem("Is") == "is"
    assert p.stem("Is", to_lowercase=False) == "Is"


# spec: N-000158, N-000157
def test_N_000157_porter_bli_and_fulli_extensions():
    p = PorterStemmer()
    assert p.stem("radicalli") == "radic"
    assert p.stem("differentli") == "differ"
    assert p.stem("conformabli") == "conform"


# spec: N-000152, N-000153
def test_N_000153_star_o_two_letter_stem():
    assert PorterStemmer().stem("vileli") == "vile"


# spec: N-000161, N-000162
def test_N_000161_lancaster_partial_table():
    l = LancasterStemmer()
    assert l.stem("maximum") == "maxim"
    assert l.stem("owed") == "ow"


# spec: N-000168, N-000169, N-000170
def test_N_000168_regexp_stemmer():
    assert RegexpStemmer("ing$").stem("sing") == "s"
    assert RegexpStemmer("ing$").stem("cars") == "cars"


# spec: N-000163, N-000165, N-000166, N-000167, N-000173
def test_N_000163_snowball_english_porter2():
    s = SnowballStemmer("english")
    assert s.stem("consistency") == "consist"
    assert s.stem("generously") == "generous"
    assert s.stem("skies") == "sky"
    assert s.stem("exceed") == "exceed"
    assert s.stem("GENERATION") == "generat"


def test_N_000167_snowball_stopwords(packaged):
    s = SnowballStemmer("english", ignore_stopwords=True)
    assert s.stem("The") == "the"
    assert s.stem("running") == "run"


# spec: N-000171, N-000172, N-000394, N-000395
def test_N_000171_snowball_bad_language_and_missing_stopwords(no_packaged):
    with pytest.raises(ValueError):
        SnowballStemmer("klingon")
    with pytest.raises(LookupError):
        SnowballStemmer("english", ignore_stopwords=True)


# spec: N-000174, N-000175, N-000396
def test_N_000174_wordnet_requires_resource(no_packaged):
    with pytest.raises(LookupError):
        WordNetLemmatizer()
