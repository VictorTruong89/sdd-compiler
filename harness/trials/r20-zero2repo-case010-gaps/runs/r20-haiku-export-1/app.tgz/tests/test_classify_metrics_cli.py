"""Classifiers (FP-06), metrics and BLEU (FP-07), and the command line."""

import io
import sys

import pytest

from lingora.classify import DecisionTreeClassifier, NaiveBayesClassifier, accuracy
from lingora.cli import cli
from lingora.metrics import accuracy as list_accuracy
from lingora.metrics import edit_distance, f_measure, jaccard_distance, precision, recall
from lingora.translate import bleu, method1

TRAIN = [
    ({"w": "good", "len": 1}, "pos"),
    ({"w": "great", "len": 2}, "pos"),
    ({"w": "bad", "len": 1}, "neg"),
    ({"w": "awful", "len": 2}, "neg"),
]


# spec: N-000277, N-000279, N-000280, N-000281, N-000282, N-000455
def test_N_000277_naive_bayes_classify_and_distribution():
    nb = NaiveBayesClassifier.train(TRAIN)
    assert nb.classify({"w": "good", "len": 1}) == "pos"
    assert nb.classify({"w": "awful", "len": 2}) == "neg"
    dist = nb.prob_classify({"w": "good", "len": 1})
    assert sorted(dist.samples()) == ["neg", "pos"]
    assert abs(sum(dist.prob(l) for l in nb.labels()) - 1.0) < 1e-9
    assert sorted(nb.labels()) == ["neg", "pos"]


def test_N_000283_decision_tree_fits_separable_data():
    dt = DecisionTreeClassifier.train(TRAIN)
    assert [dt.classify(fs) for fs, _ in TRAIN] == [label for _, label in TRAIN]


# spec: N-000269, N-000274, N-000288
def test_N_000274_accuracy_helper():
    nb = NaiveBayesClassifier.train(TRAIN)
    assert accuracy(nb, TRAIN) == 1.0
    assert accuracy(nb, [({"w": "good", "len": 1}, "neg")]) == 0.0


# spec: N-000292, N-000293, N-000294, N-000295, N-000298, N-000299, N-000315
def test_N_000292_edit_distance():
    assert edit_distance("kitten", "sitting") == 3
    assert edit_distance("", "") == 0
    assert edit_distance("abc", "abc") == 0
    assert edit_distance("a", "b", substitution_cost=2) == 2
    assert edit_distance("ca", "abc") == 3
    assert edit_distance("ca", "abc", transpositions=True) == 2
    assert edit_distance("ab", "ba", transpositions=True) == 1


def test_N_000469_jaccard():
    assert jaccard_distance({"a", "b"}, {"b", "c"}) == pytest.approx(2 / 3)


# spec: N-000300, N-000301, N-000311, N-000312, N-000313, N-000314
def test_N_000300_precision_recall_f():
    ref, test = {"a", "b"}, {"a", "c"}
    assert precision(ref, test) == 0.5
    assert recall(ref, test) == 0.5
    assert f_measure(ref, test) == 0.5
    assert precision(ref, set()) is None
    assert f_measure(set(), test) is None
    assert f_measure({"a"}, {"b"}) == 0.0
    with pytest.raises(TypeError):
        precision(["a"], {"a"})


# spec: N-000464, N-000465, N-000310
def test_N_000464_list_accuracy():
    assert list_accuracy([1, 2, 3], [1, 0, 3]) == pytest.approx(2 / 3)
    with pytest.raises(ValueError):
        list_accuracy([1], [1, 2])


# spec: N-000302, N-000304, N-000307, N-000308, N-000476
def test_N_000302_bleu():
    ref = "the cat sat on the mat".split()
    assert bleu([ref], "the cat sat on the mat".split()) == pytest.approx(1.0)
    assert bleu([ref], "the cat is on the mat".split()) == 0.0  # unsmoothed
    assert bleu([ref], "the cat is on the mat".split(), smoothing_function=method1) > 0.0
    assert bleu([["a", "b", "c", "d"]], ["x", "y", "z", "w"]) == 0.0


# spec: N-000382, N-000383, N-000384, N-000385, N-000386
def test_N_000382_cli_tokenize(packaged, monkeypatch, capsys):
    monkeypatch.setattr(sys, "stdin", io.StringIO("Mr. Smith went. Hello, world!\n\nLast line.\n"))
    with pytest.raises(SystemExit) as exc:
        cli.main(args=["tokenize"], standalone_mode=True)
    assert exc.value.code == 0
    out = capsys.readouterr().out.split("\n")
    assert out[0] == "Mr. Smith went . Hello , world !"
    assert out[1] == ""
    assert out[2] == "Last line ."
    assert out[3] == ""


def test_N_000387_cli_failure_writes_no_token_line(no_packaged, monkeypatch, capsys):
    monkeypatch.setattr(sys, "stdin", io.StringIO("Some text. More text.\n"))
    code = cli.main(args=["tokenize"], standalone_mode=False)
    assert code != 0
    assert capsys.readouterr().out == ""
