"""Taggers (FP-03, lingora.tag) and chunking (FP-04, lingora.chunk)."""

import pytest

from lingora.chunk import RegexpParser, ne_chunk
from lingora.tag import DefaultTagger, RegexpTagger, UnigramTagger, pos_tag
from lingora.tree import Tree


# spec: N-000187
def test_N_000187_default_tagger():
    assert DefaultTagger("NN").tag(["a", "b"]) == [("a", "NN"), ("b", "NN")]


# spec: N-000188, N-000189, N-000190
def test_N_000188_unigram_tagger_most_frequent_and_unseen():
    train = [[("the", "DT"), ("dog", "NN")], [("dog", "NN")], [("dog", "VB")]]
    tagger = UnigramTagger(train)
    assert tagger.tag(["dog", "zebra"]) == [("dog", "NN"), ("zebra", None)]


# spec: N-000194, N-000195
def test_N_000194_backoff_only_for_untagged():
    tagger = UnigramTagger([[("dog", "NN")]], backoff=DefaultTagger("X"))
    assert tagger.tag(["dog", "cat"]) == [("dog", "NN"), ("cat", "X")]


# spec: N-000191, N-000192, N-000193
def test_N_000191_regexp_tagger_first_rule_wins():
    tagger = RegexpTagger([(r".*ing$", "VBG"), (r"\d+", "CD"), (r".*", "NN")])
    assert tagger.tag(["running", "3", "dog"]) == [("running", "VBG"), ("3", "CD"), ("dog", "NN")]


# spec: N-000185, N-000186, N-000399
def test_N_000185_tagger_empty_and_raw_string_refused():
    assert DefaultTagger("NN").tag([]) == []
    with pytest.raises(TypeError):
        DefaultTagger("NN").tag("a raw string")


# spec: N-000397, N-000398, N-000404, N-000406, N-000408
def test_N_000397_pos_tag_english(packaged):
    assert pos_tag("the dog barked".split()) == [("the", "DT"), ("dog", "NN"), ("barked", "VBD")]
    assert pos_tag("the dog barked".split(), tagset="universal") == [
        ("the", "DET"), ("dog", "NOUN"), ("barked", "VERB"),
    ]


def test_N_000406_pos_tag_refuses_string(packaged):
    with pytest.raises(TypeError):
        pos_tag("the dog")


# spec: N-000207, N-000211, N-000212, N-000213, N-000214
def test_N_000211_pos_tag_language_checks(packaged, no_packaged):
    with pytest.raises(ValueError):
        pos_tag(["x"], lang="fra")
    with pytest.raises(LookupError):
        pos_tag(["x"], lang="rus")


def test_N_000215_universal_mapping_needs_tables(packaged, tmp_path):
    # remove the English universal table from the visible tree
    import os
    os.remove(os.path.join(packaged, "taggers", "universal_tagset", "en-ptb.map"))
    with pytest.raises(LookupError):
        pos_tag(["the"], tagset="universal")


# spec: N-000410, N-000412, N-000418, N-000419, N-000421, N-000423
def test_N_000410_chunk_rules_and_root_label():
    tagged = [("the", "DT"), ("big", "JJ"), ("dog", "NN"), ("barked", "VBD"), ("today", "NN")]
    tree = RegexpParser("NP: {<DT>?<JJ>*<NN>}").parse(tagged)
    assert tree.label() == "SENT"
    assert tree[0] == Tree("NP", [("the", "DT"), ("big", "JJ"), ("dog", "NN")])
    assert tree[1] == ("barked", "VBD")
    assert tree.leaves() == [("the", "DT"), ("big", "JJ"), ("dog", "NN"), ("barked", "VBD"), ("today", "NN")]


def test_N_000416_quantifier_and_quantifier_braces():
    tagged = [("a", "A"), ("b", "A"), ("c", "B")]
    tree = RegexpParser("X: {<A>{2}<B>}").parse(tagged)
    assert tree[0] == Tree("X", [("a", "A"), ("b", "A"), ("c", "B")])


def test_N_000422_chink_splits_chunk():
    tagged = [("the", "DT"), ("dog", "NN"), ("and", "CC"), ("cat", "NN")]
    tree = RegexpParser("NP: {<DT|NN|CC>+}\n}<CC>{").parse(tagged)
    labels = [c.label() if isinstance(c, Tree) else c for c in tree]
    assert labels == ["NP", ("and", "CC"), "NP"] or labels == [Tree("NP", []).label(), ("and", "CC"), "NP"]
    assert tree[0] == Tree("NP", [("the", "DT"), ("dog", "NN")])
    assert tree[1] == ("and", "CC")
    assert tree[2] == Tree("NP", [("cat", "NN")])


def test_N_000230_cascade_units_visible():
    tagged = [("the", "DT"), ("dog", "NN"), ("barked", "VBD")]
    tree = RegexpParser("NP: {<DT><NN>}\nVP: {<NP><VBD>}").parse(tagged)
    assert tree.label() == "SENT"
    assert tree[0] == Tree("VP", [Tree("NP", [("the", "DT"), ("dog", "NN")]), ("barked", "VBD")])


def test_N_000236_ne_chunk_needs_resources(no_packaged):
    with pytest.raises(LookupError):
        ne_chunk([("John", "NNP")])
