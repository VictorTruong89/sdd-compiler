"""Packaged resource finder (lingora.data)."""

from lingora import data


# spec: N-000353, N-000354, N-000355
def test_N_000354_path_is_mutable_and_empty_means_nothing_visible(tmp_path, monkeypatch):
    monkeypatch.setattr(data, "path", [])
    assert not data.is_visible("corpora/words")
    (tmp_path / "corpora").mkdir()
    (tmp_path / "corpora" / "words").write_text("x")
    data.path[:] = [str(tmp_path)]
    assert data.is_visible("corpora/words")


def test_N_000353_import_downloads_nothing():
    assert isinstance(data.path, list)
