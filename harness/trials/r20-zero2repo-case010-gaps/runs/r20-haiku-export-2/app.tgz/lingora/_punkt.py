"""Punkt unsupervised sentence-boundary detection (Kiss and Strunk, 2006).

The parameters (abbreviation types, collocations, sentence starters and
orthographic context) come from the packaged Punkt model directory
``tokenizers/punkt_tab/<language>/`` found through :mod:`lingora.data`.
"""

import os
import re
from collections import defaultdict

from lingora import data

__all__ = ["PunktParameters", "PunktSentenceTokenizer", "load_language"]

SENT_END_CHARS = (".", "?", "!")

# Orthographic context bits (see lingora.data, Punkt files).
_ORTHO_BEG_UC = 1 << 1
_ORTHO_MID_UC = 1 << 2
_ORTHO_UNK_UC = 1 << 3
_ORTHO_BEG_LC = 1 << 4
_ORTHO_MID_LC = 1 << 5
_ORTHO_UNK_LC = 1 << 6
_ORTHO_UC = _ORTHO_BEG_UC | _ORTHO_MID_UC | _ORTHO_UNK_UC
_ORTHO_LC = _ORTHO_BEG_LC | _ORTHO_MID_LC | _ORTHO_UNK_LC

_NON_WORD = r"(?:[?!)\";}\]\*:@\'\({\[])"
_MULTI_CHAR = r"(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"
_WORD_START = r"[^\(\"\`{\[:;&\#\*@\)}\]\-,]"

# Word tokenization used inside the sentence splitter.
_WORD_TOKENIZE_RE = re.compile(
    r"""(
        %(multi)s
        |
        (?=%(start)s)\S+?
        (?=
            \s|$|%(nonword)s|%(multi)s|
            ,(?=$|\s|%(nonword)s|%(multi)s)
        )
        |
        \S
    )"""
    % {"multi": _MULTI_CHAR, "start": _WORD_START, "nonword": _NON_WORD},
    re.UNICODE | re.VERBOSE,
)

# A potential sentence end: some word material, a sentence-ending character,
# then either punctuation or whitespace and another token.
_PERIOD_CONTEXT_RE = re.compile(
    r"""
    \S*                          # some word material
    [.?!]                        # a potential sentence ending
    (?=(?P<after_tok>
        %(nonword)s              # either other punctuation
        |
        \s+(?P<next_tok>\S+)     # or whitespace and some other token
    ))"""
    % {"nonword": _NON_WORD},
    re.UNICODE | re.VERBOSE,
)

_RE_BOUNDARY_REALIGNMENT = re.compile(r'["\')\]}]+?(?:\s+|(?=--)|$)', re.MULTILINE)
_RE_NUMBER_TYPE = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_RE_ELLIPSIS = re.compile(r"\.\.+$")
_RE_INITIAL = re.compile(r"[^\W\d]\.$", re.UNICODE)


class _Tok(object):
    """One word token of the text being split, with Punkt annotations."""

    __slots__ = (
        "tok",
        "type",
        "period_final",
        "parastart",
        "linestart",
        "sentbreak",
        "abbr",
        "ellipsis",
    )

    def __init__(self, tok, parastart=False, linestart=False):
        self.tok = tok
        lowered = tok.lower()
        self.type = "##number##" if _RE_NUMBER_TYPE.match(lowered) else lowered
        self.period_final = tok.endswith(".")
        self.parastart = parastart
        self.linestart = linestart
        self.sentbreak = False
        self.abbr = False
        self.ellipsis = False

    @property
    def type_no_period(self):
        if len(self.type) > 1 and self.type[-1] == ".":
            return self.type[:-1]
        return self.type

    @property
    def type_no_sentperiod(self):
        if self.sentbreak:
            return self.type_no_period
        return self.type

    @property
    def first_upper(self):
        return self.tok[0].isupper()

    @property
    def first_lower(self):
        return self.tok[0].islower()

    @property
    def is_ellipsis(self):
        return bool(_RE_ELLIPSIS.match(self.tok))

    @property
    def is_number(self):
        return self.type.startswith("##number##")

    @property
    def is_initial(self):
        return bool(_RE_INITIAL.match(self.tok))


class PunktParameters(object):
    """Trained Punkt parameters for one language."""

    def __init__(self):
        self.abbrev_types = set()
        self.collocations = set()
        self.sent_starters = set()
        self.ortho_context = defaultdict(int)

    @classmethod
    def from_directory(cls, directory):
        params = cls()
        params.abbrev_types = set(_read_lines(os.path.join(directory, "abbrev_types.txt")))
        params.sent_starters = set(_read_lines(os.path.join(directory, "sent_starters.txt")))
        for line in _read_lines(os.path.join(directory, "collocations.tab")):
            fields = line.split("\t")
            if len(fields) == 2:
                params.collocations.add((fields[0], fields[1]))
        for line in _read_lines(os.path.join(directory, "ortho_context.tab")):
            fields = line.split("\t")
            if len(fields) == 2:
                params.ortho_context[fields[0]] = int(fields[1])
        return params


def _read_lines(filename):
    """Each line without its line terminator is one entry; missing file -> none."""
    if not os.path.isfile(filename):
        return []
    with open(filename, encoding="utf-8") as handle:
        lines = [line.rstrip("\r\n") for line in handle]
    return [line for line in lines if line != ""]


_LANGUAGE_CACHE = {}


def load_language(language):
    """Return the Punkt parameters for ``language`` (a Punkt directory name).

    Raises :class:`lingora.data.ResourceNotFound` when the model is not visible.
    """
    directory = data.find("tokenizers/punkt_tab/%s" % language)
    if not os.path.isdir(directory):
        raise data.ResourceNotFound(
            "Punkt model for %r is not visible on lingora.data.path" % language
        )
    key = os.path.abspath(directory)
    if key not in _LANGUAGE_CACHE:
        _LANGUAGE_CACHE[key] = PunktParameters.from_directory(directory)
    return _LANGUAGE_CACHE[key]


class PunktSentenceTokenizer(object):
    """Sentence splitter driven by a :class:`PunktParameters` object."""

    def __init__(self, params):
        self._params = params

    # -- public -------------------------------------------------------------

    def sentences(self, text, realign_boundaries=True):
        return [text[s:e] for s, e in self.span_tokenize(text, realign_boundaries)]

    def span_tokenize(self, text, realign_boundaries=True):
        slices = list(self._slices_from_text(text))
        if realign_boundaries:
            slices = list(self._realign_boundaries(text, slices))
        spans = []
        for sl in slices:
            piece = text[sl.start:sl.stop]
            stripped = piece.strip()
            if not stripped:
                continue
            start = sl.start + (len(piece) - len(piece.lstrip()))
            spans.append((start, start + len(stripped)))
        return spans

    # -- internals ----------------------------------------------------------

    def _slices_from_text(self, text):
        last_break = 0
        for match in _PERIOD_CONTEXT_RE.finditer(text):
            if match.group("next_tok") is not None:
                context_end = match.end("next_tok")
            else:
                context_end = match.end() + 1
            context = text[match.start():context_end]
            if self._text_contains_sentbreak(context):
                yield slice(last_break, match.end())
                if match.group("next_tok") is not None:
                    last_break = match.start("next_tok")
                else:
                    last_break = match.end()
        yield slice(last_break, len(text))

    def _realign_boundaries(self, text, slices):
        realign = 0
        count = len(slices)
        for index, sl1 in enumerate(slices):
            sl1 = slice(sl1.start + realign, sl1.stop)
            if index + 1 >= count:
                if text[sl1]:
                    yield sl1
                continue
            sl2 = slices[index + 1]
            match = _RE_BOUNDARY_REALIGNMENT.match(text[sl2.start:])
            if match:
                yield slice(sl1.start, sl2.start + len(match.group(0).rstrip()))
                realign = match.end()
            else:
                realign = 0
                if text[sl1]:
                    yield sl1

    def _text_contains_sentbreak(self, text):
        found = False
        for tok in self._annotate_tokens(self._tokenize_words(text)):
            if found:
                return True
            if tok.sentbreak:
                found = True
        return False

    def _tokenize_words(self, plaintext):
        parastart = False
        for line in plaintext.split("\n"):
            if line.strip():
                line_toks = _WORD_TOKENIZE_RE.findall(line)
                if not line_toks:
                    continue
                yield _Tok(line_toks[0], parastart=parastart, linestart=True)
                parastart = False
                for word in line_toks[1:]:
                    yield _Tok(word)
            else:
                parastart = True

    def _annotate_tokens(self, tokens):
        tokens = list(tokens)
        for tok in tokens:
            self._first_pass(tok)
        for index, tok in enumerate(tokens):
            nxt = tokens[index + 1] if index + 1 < len(tokens) else None
            self._second_pass(tok, nxt)
        return tokens

    def _first_pass(self, aug_tok):
        tok = aug_tok.tok
        if tok in SENT_END_CHARS:
            aug_tok.sentbreak = True
        elif aug_tok.is_ellipsis:
            aug_tok.ellipsis = True
        elif aug_tok.period_final and not tok.endswith(".."):
            stem = tok[:-1].lower()
            if stem in self._params.abbrev_types or stem.split("-")[-1] in self._params.abbrev_types:
                aug_tok.abbr = True
            else:
                aug_tok.sentbreak = True

    def _second_pass(self, aug_tok1, aug_tok2):
        if aug_tok2 is None or not aug_tok1.period_final:
            return
        typ = aug_tok1.type_no_period
        next_typ = aug_tok2.type_no_sentperiod
        tok_is_initial = aug_tok1.is_initial

        # Collocation heuristic: a collocation across the period means the
        # period belongs to an abbreviation, not a sentence break.
        if (typ, next_typ) in self._params.collocations:
            aug_tok1.sentbreak = False
            aug_tok1.abbr = True
            return

        # Token-based reclassification of abbreviations and ellipses.
        if aug_tok1.abbr or aug_tok1.ellipsis:
            is_sent_starter = self._ortho_heuristic(aug_tok2)
            if is_sent_starter is True:
                aug_tok1.sentbreak = True
                return
            if aug_tok2.first_upper and next_typ in self._params.sent_starters:
                aug_tok1.sentbreak = True
                return

        # Initials and ordinals.
        if tok_is_initial or typ == "##number##":
            is_sent_starter = self._ortho_heuristic(aug_tok2)
            if is_sent_starter is False:
                aug_tok1.sentbreak = False
                aug_tok1.abbr = True
                return
            if (
                is_sent_starter == "unknown"
                and tok_is_initial
                and aug_tok2.first_upper
                and not (self._params.ortho_context[next_typ] & _ORTHO_LC)
            ):
                aug_tok1.sentbreak = False
                aug_tok1.abbr = True
                return

    def _ortho_heuristic(self, aug_tok):
        """Return True / False for sentence-starter evidence, else "unknown"."""
        if aug_tok.tok in SENT_END_CHARS:
            return False
        ortho = self._params.ortho_context[aug_tok.type_no_sentperiod]
        # Capitalised, seen lower-case at a sentence start, never capitalised mid-sentence.
        if aug_tok.first_upper and (ortho & _ORTHO_LC) and not (ortho & _ORTHO_MID_UC):
            return True
        # Lower-case, seen capitalised, never lower-case mid-sentence.
        if aug_tok.first_lower and (ortho & _ORTHO_UC) and not (ortho & _ORTHO_MID_LC):
            return False
        return "unknown"
