"""Command line — ``lingora.cli`` (FP-01).

``cli.main(args=['tokenize'], standalone_mode=True)`` runs the tokenize
command: it reads UTF-8 text from standard input and, for every input line,
writes one output line with that line's recommended-word-tokenizer tokens
(with sentence splitting), joined by the delimiter (a single space by default).

Options (implementer's choice): ``--language NAME`` (default ``english``),
``--delimiter TEXT`` (default a single space), ``--encoding NAME`` (default
``utf-8``, used for standard input and output).

Exit status: 0 on success; 1 on failure (for example a missing Punkt model),
in which case no token line is written. In standalone mode the process exits
with that status; otherwise ``main`` returns it.
"""

import sys

from lingora import data
from lingora import tokenize as _tokenize

__all__ = ["cli", "main"]

_USAGE = "usage: lingora tokenize [--language NAME] [--delimiter TEXT] [--encoding NAME]"


class _UsageError(Exception):
    pass


def _parse_options(args):
    if not args:
        raise _UsageError("missing command")
    command = args[0]
    if command != "tokenize":
        raise _UsageError("unknown command %r" % command)
    options = {"language": "english", "delimiter": " ", "encoding": "utf-8"}
    index = 1
    while index < len(args):
        arg = args[index]
        if arg in ("--language", "--delimiter", "--encoding"):
            if index + 1 >= len(args):
                raise _UsageError("option %s needs a value" % arg)
            options[arg[2:]] = args[index + 1]
            index += 2
        else:
            raise _UsageError("unexpected argument %r" % arg)
    return options


def _tokenize_command(options):  # spec: N-000127, N-000128, N-000132
    language = options["language"]
    delimiter = options["delimiter"]
    encoding = options["encoding"]

    # A missing Punkt model fails the whole command before any token line is written.
    try:
        from lingora import _punkt
        _punkt.load_language(language)
    except data.ResourceNotFound as error:
        sys.stderr.write("lingora: %s\n" % error)
        return 1

    stdin = sys.stdin
    stdout = sys.stdout
    for raw in _read_lines(stdin, encoding):
        tokens = _tokenize.word_tokenize(raw, language=language)
        stdout.write(delimiter.join(tokens) + "\n")
    stdout.flush()
    return 0


def _read_lines(stream, encoding):
    buffer = getattr(stream, "buffer", None)
    if buffer is not None:
        text = buffer.read().decode(encoding)
    else:
        text = stream.read()
    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    return [line[:-1] if line.endswith("\r") else line for line in lines]


def main(args=None, standalone_mode=True):  # spec: N-000382, N-000383, N-000384, N-000385, N-000386, N-000387, N-000388
    """Run the command line. See the module docstring for the contract."""
    if args is None:
        args = sys.argv[1:]
    args = list(args)
    try:
        options = _parse_options(args)
    except _UsageError as error:
        sys.stderr.write("lingora: %s\n%s\n" % (error, _USAGE))
        status = 2
    else:
        try:
            status = _tokenize_command(options)
        except UnicodeDecodeError as error:
            sys.stderr.write("lingora: input is not valid %s: %s\n" % (options["encoding"], error))
            status = 1
        except LookupError as error:
            sys.stderr.write("lingora: %s\n" % error)
            status = 1
    if standalone_mode:
        sys.exit(status)
    return status


class _CommandGroup(object):
    """The ``lingora`` command group object: ``cli.main(args=..., standalone_mode=...)``."""

    def main(self, args=None, standalone_mode=True):
        return main(args=args, standalone_mode=standalone_mode)


cli = _CommandGroup()
