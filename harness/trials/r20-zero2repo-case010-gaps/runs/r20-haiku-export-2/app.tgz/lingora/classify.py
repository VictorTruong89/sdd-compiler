"""Classifiers — ``lingora.classify`` (FP-06).

``NaiveBayesClassifier`` and ``DecisionTreeClassifier`` are trained on lists of
``(featureset, label)`` pairs, where a featureset is a ``dict`` from feature
names to values. ``accuracy`` compares a classifier's labels with gold labels.
"""

import math
from collections import Counter, defaultdict

__all__ = ["DecisionTreeClassifier", "NaiveBayesClassifier", "ProbDist", "accuracy"]

_GAMMA = 0.5  # expected-likelihood estimation: add-gamma smoothing


def _check_labeled(labeled_featuresets):
    if not isinstance(labeled_featuresets, (list, tuple)):
        raise TypeError("training data must be a list of (featureset, label) pairs")
    if not labeled_featuresets:
        raise ValueError("training data is empty")
    for pair in labeled_featuresets:
        if not (isinstance(pair, tuple) and len(pair) == 2):
            raise TypeError("each training item must be a (featureset, label) pair")
        if not isinstance(pair[0], dict):
            raise TypeError("a featureset must be a dict")
        hash(pair[1])


class ProbDist(object):
    """A probability distribution over labels."""

    def __init__(self, probabilities):
        self._probabilities = dict(probabilities)

    def prob(self, label):  # spec: N-000459
        return float(self._probabilities.get(label, 0.0))

    def samples(self):  # spec: N-000460
        return list(self._probabilities)

    def max(self):
        return max(self._probabilities, key=lambda label: self._probabilities[label])

    def __repr__(self):
        return "<ProbDist with %d labels>" % len(self._probabilities)


class NaiveBayesClassifier(object):  # spec: N-000269, N-000270, N-000271, N-000272, N-000273, N-000274, N-000275, N-000276
    """Naive Bayes over featuresets, with expected-likelihood smoothing."""

    def __init__(self, labels, priors, feature_stats, feature_bins, known_features):
        self._labels = labels
        self._priors = priors
        self._feature_stats = feature_stats
        self._feature_bins = feature_bins
        self._known_features = known_features

    @classmethod
    def train(cls, labeled_featuresets):  # spec: N-000455, N-000456, N-000457, N-000458, N-000277, N-000278, N-000282
        _check_labeled(labeled_featuresets)
        label_counts = Counter()
        label_order = []
        value_counts = defaultdict(Counter)   # (label, fname) -> Counter of values
        feature_present = Counter()           # (label, fname) -> examples with the feature
        feature_values = defaultdict(set)     # fname -> all values seen
        for featureset, label in labeled_featuresets:
            if label not in label_counts:
                label_order.append(label)
            label_counts[label] += 1
            for fname, fval in featureset.items():
                value_counts[(label, fname)][fval] += 1
                feature_present[(label, fname)] += 1
                feature_values[fname].add(fval)
        total = len(labeled_featuresets)
        priors = {label: label_counts[label] / total for label in label_order}
        feature_stats = {}
        for key, counter in value_counts.items():
            feature_stats[key] = (counter, feature_present[key])
        feature_bins = {fname: len(values) for fname, values in feature_values.items()}
        return cls(label_order, priors, feature_stats, feature_bins, set(feature_values))

    def labels(self):  # spec: N-000460
        return list(self._labels)

    def prob_classify(self, featureset):  # spec: N-000279, N-000280, N-000281
        if not isinstance(featureset, dict):
            raise TypeError("a featureset must be a dict")
        log_scores = {}
        for label in self._labels:
            score = math.log(self._priors[label])
            for fname, fval in featureset.items():
                if fname not in self._known_features:
                    continue
                counter, present = self._feature_stats.get((label, fname), (Counter(), 0))
                bins = self._feature_bins[fname]
                numerator = counter.get(fval, 0) + _GAMMA
                denominator = present + bins * _GAMMA
                score += math.log(numerator / denominator)
            log_scores[label] = score
        top = max(log_scores.values())
        exps = {label: math.exp(value - top) for label, value in log_scores.items()}
        norm = sum(exps.values())
        return ProbDist({label: value / norm for label, value in exps.items()})

    def classify(self, featureset):  # spec: N-000279
        return self.prob_classify(featureset).max()


class _Leaf(object):
    __slots__ = ("label",)

    def __init__(self, label):
        self.label = label


class _Split(object):
    __slots__ = ("feature", "children", "default")

    def __init__(self, feature, children, default):
        self.feature = feature
        self.children = children
        self.default = default


def _majority(labels):
    counts = Counter()
    for label in labels:
        counts[label] += 1
    best = None
    for label in labels:  # first-seen label wins ties
        if best is None or counts[label] > counts[best]:
            best = label
    return best


def _build_tree(examples, features):
    labels = [label for _, label in examples]
    majority = _majority(labels)
    if len(set(labels)) == 1 or not features:
        return _Leaf(majority)
    leaf_errors = len(labels) - Counter(labels)[majority]
    best_feature = None
    best_errors = None
    for fname in features:
        groups = defaultdict(list)
        for featureset, label in examples:
            groups[featureset.get(fname)].append(label)
        errors = sum(len(group) - Counter(group)[_majority(group)] for group in groups.values())
        if best_errors is None or errors < best_errors:
            best_feature, best_errors = fname, errors
    if best_errors >= leaf_errors:  # no test on any feature improves on the majority
        return _Leaf(majority)
    partitions = defaultdict(list)
    for featureset, label in examples:
        partitions[featureset.get(best_feature)].append((featureset, label))
    remaining = [f for f in features if f != best_feature]
    children = {value: _build_tree(part, remaining) for value, part in partitions.items()}
    return _Split(best_feature, children, majority)


class DecisionTreeClassifier(object):
    """Decision tree that tests, at each node, the feature that best separates the labels."""

    def __init__(self, root):
        self._root = root

    @classmethod
    def train(cls, labeled_featuresets):  # spec: N-000283, N-000284, N-000285, N-000286, N-000287
        _check_labeled(labeled_featuresets)
        examples = [(dict(fs), label) for fs, label in labeled_featuresets]
        features = []
        seen = set()
        for featureset, _ in examples:
            for fname in featureset:
                if fname not in seen:
                    seen.add(fname)
                    features.append(fname)
        return cls(_build_tree(examples, features))

    def classify(self, featureset):  # spec: N-000287
        if not isinstance(featureset, dict):
            raise TypeError("a featureset must be a dict")
        node = self._root
        while isinstance(node, _Split):
            value = featureset.get(node.feature)
            if value in node.children:
                node = node.children[value]
            else:
                return node.default
        return node.label


def accuracy(classifier, gold):  # spec: N-000288
    """Fraction of gold ``(featureset, label)`` pairs the classifier labels correctly."""
    if not isinstance(gold, (list, tuple)):
        raise TypeError("gold must be a list of (featureset, label) pairs")
    if not gold:
        raise ValueError("accuracy of an empty gold list is undefined")
    correct = sum(1 for featureset, label in gold if classifier.classify(featureset) == label)
    return correct / len(gold)
