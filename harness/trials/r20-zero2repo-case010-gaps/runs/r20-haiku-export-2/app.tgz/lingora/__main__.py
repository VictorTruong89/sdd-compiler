"""Allow ``python -m lingora tokenize`` as a command line."""

from lingora.cli import main

if __name__ == "__main__":
    main()
