"""Context-free grammars — ``lingora.grammar`` (FP-05).

Grammar text has one production per line, written ``<LHS> -> <RHS>``.
``<RHS>`` is a space-separated sequence of nonterminals (unquoted identifiers)
and terminals (single- or double-quoted text); ``|`` separates alternatives.
Each alternative is a production of its own. Blank lines are ignored.
"""

import re

__all__ = ["CFG", "Nonterminal", "Production"]

_RHS_TOKEN_RE = re.compile(r"'[^']*'|\"[^\"]*\"|\||[^\s|'\"]+")


class Nonterminal(object):  # spec: N-000429, N-000430, N-000431
    """A nonterminal symbol. ``str()`` gives its name; it is not a ``str``."""

    __slots__ = ("_symbol",)

    def __init__(self, symbol):
        self._symbol = str(symbol)

    def __str__(self):
        return self._symbol

    def __repr__(self):
        return "Nonterminal(%r)" % self._symbol

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and other._symbol == self._symbol

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash(("Nonterminal", self._symbol))


class Production(object):
    """One alternative: a left-hand nonterminal and a right-hand sequence."""

    __slots__ = ("_lhs", "_rhs")

    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):  # spec: N-000432, N-000433
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def __str__(self):
        right = " ".join(
            str(sym) if isinstance(sym, Nonterminal) else repr(sym) for sym in self._rhs
        )
        return "%s -> %s" % (self._lhs, right)

    def __repr__(self):
        return "Production(%r, %r)" % (self._lhs, self._rhs)

    def __eq__(self, other):
        return (
            isinstance(other, Production)
            and other._lhs == self._lhs
            and other._rhs == self._rhs
        )

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash((self._lhs, self._rhs))


def _parse_production_lines(text):
    productions = []
    for line_number, raw in enumerate(text.splitlines(), start=1):
        line = raw.strip()
        if not line:  # spec: N-000427
            continue
        if "->" not in line:
            raise ValueError("line %d: expected '<LHS> -> <RHS>'" % line_number)
        lhs_text, rhs_text = line.split("->", 1)
        lhs_text = lhs_text.strip()
        if not lhs_text or re.search(r"\s|['\"|]", lhs_text):
            raise ValueError("line %d: bad left-hand side %r" % (line_number, lhs_text))
        lhs = Nonterminal(lhs_text)
        alternatives = [[]]
        for token in _RHS_TOKEN_RE.findall(rhs_text):
            if token == "|":
                alternatives.append([])
            elif token[0] in "'\"" and len(token) >= 2:
                alternatives[-1].append(token[1:-1])  # terminal: text inside the quotes
            else:
                alternatives[-1].append(Nonterminal(token))
        for alternative in alternatives:  # spec: N-000240, N-000434
            productions.append(Production(lhs, alternative))
    return productions


class CFG(object):  # spec: N-000237, N-000238, N-000239, N-000256
    """A context-free grammar. The start symbol is the first production's LHS."""

    def __init__(self, productions):
        self._productions = list(productions)
        self._start = self._productions[0].lhs() if self._productions else None

    @classmethod
    def fromstring(cls, input):  # spec: N-000424, N-000425, N-000426
        if not isinstance(input, str):
            raise TypeError("grammar text must be a str")
        productions = _parse_production_lines(input)
        if not productions:
            raise ValueError("grammar has no productions")
        return cls(productions)

    def extend(self, text):  # spec: N-000241
        """Append the productions of further grammar text; returns ``self``."""
        added = _parse_production_lines(text)
        self._productions.extend(added)
        if self._start is None and added:
            self._start = added[0].lhs()
        return self

    def start(self):  # spec: N-000430
        return self._start

    def productions(self, lhs=None):  # spec: N-000434
        if lhs is None:
            return list(self._productions)
        if isinstance(lhs, str):
            lhs = Nonterminal(lhs)
        return [prod for prod in self._productions if prod.lhs() == lhs]

    def nonterminals(self):
        return {prod.lhs() for prod in self._productions}

    def terminals(self):
        """Every quoted terminal that appears on some right-hand side."""
        found = set()
        for prod in self._productions:
            for sym in prod.rhs():
                if not isinstance(sym, Nonterminal):
                    found.add(sym)
        return found

    def __repr__(self):
        return "<CFG with %d productions>" % len(self._productions)
