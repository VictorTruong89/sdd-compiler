"""LINGORA — a pure-Python natural-language processing library.

Importing the package downloads nothing and reads no configuration file.
Packaged models are located through :mod:`lingora.data`.

Package-level specification statements (see COVERAGE.md for the full map):

* spec: N-000001, N-000002, N-000004 — a library imported by an integrator,
  not an end-user application or a network service.
* spec: N-000005 … N-000012 — the core processing path: tokenize, stem, tag,
  chunk, parse and build trees, classify, and score (modules named below).
* spec: N-000013, N-000014, N-000016 — feature points ordered so that
  foundational capabilities come first (modules: tokenize, stem, tag, chunk,
  grammar/parse/tree, classify, metrics).
* spec: N-000017, N-000018, N-000019 — no graphical, chat, or external-wrapper
  surfaces are provided; packaged models are visible only through lingora.data.
* spec: N-000020, N-000065, N-000066, N-000067 — every entry is a core
  capability; when the package cannot be imported nothing here can be called.
* spec: N-000338, N-000339, N-000340, N-000341, N-000342, N-000343, N-000344 —
  an importable flat package named ``lingora`` (Python 3.10 or newer); not a
  network service or wire protocol; no product-owned configuration file;
  importing downloads nothing.
* spec: N-000045, N-000046, N-000048, N-000049, N-000052, N-000053, N-000054,
  N-000055, N-000062, N-000063, N-000064 — pure Python with no compiled code,
  no runtime dependencies, Linux/macOS/Windows, CPU-only, Unicode text in and
  out; threading is not a concern. Packaging: pyproject.toml (flat layout).
"""

from lingora import data  # noqa: F401  (re-exported: `from lingora import data`)

__version__ = "0.1.0"
