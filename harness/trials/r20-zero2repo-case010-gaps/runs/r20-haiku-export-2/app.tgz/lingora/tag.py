"""Part-of-speech taggers — ``lingora.tag`` (FP-03).

Sequential taggers the caller trains or configures (default, unigram,
regular-expression) with optional backoff, and the recommended averaged
perceptron tagger for English (``eng``) and Russian (``rus``) through
:func:`pos_tag`.
"""

import re
from collections import Counter

from lingora import _perceptron

__all__ = ["DefaultTagger", "RegexpTagger", "UnigramTagger", "pos_tag"]


def _check_tokens(tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")
    for token in tokens:
        if not isinstance(token, str):
            raise TypeError("tokens must be a list of str")
    return list(tokens)


def _check_backoff(backoff):
    if backoff is not None and not hasattr(backoff, "tag"):
        raise TypeError("backoff must be a tagger or None")


class _SequentialTagger(object):
    """Base class: primary assignment, then backoff for tokens left without a tag."""

    def __init__(self, backoff=None):
        _check_backoff(backoff)
        self._backoff = backoff

    def _assign(self, tokens):  # returns list of tags or None
        raise NotImplementedError

    def tag(self, tokens):  # spec: N-000185, N-000186, N-000194, N-000195, N-000399, N-000408, N-000409
        tokens = _check_tokens(tokens)
        tags = self._assign(tokens)
        if self._backoff is not None:
            missing = [i for i, tag in enumerate(tags) if tag is None]
            if missing:
                backed = self._backoff.tag([tokens[i] for i in missing])
                for i, (_, tag) in zip(missing, backed):
                    tags[i] = tag
        return list(zip(tokens, tags))


class DefaultTagger(_SequentialTagger):
    """Assigns one configured tag to every token."""

    def __init__(self, tag, backoff=None):  # spec: N-000187
        super().__init__(backoff)
        self._tag = tag

    def _assign(self, tokens):
        return [self._tag for _ in tokens]


class UnigramTagger(_SequentialTagger):
    """Each word gets the tag it most often had in training (ties: first seen)."""

    def __init__(self, train=None, backoff=None):  # spec: N-000188, N-000189, N-000190, N-000400, N-000401, N-000403
        super().__init__(backoff)
        counts = {}
        if train is not None:
            if not isinstance(train, (list, tuple)):
                raise TypeError("train must be a list of tagged sentences")
            for sentence in train:
                for pair in sentence:
                    if not (isinstance(pair, tuple) and len(pair) == 2):
                        raise TypeError("each training item must be a (token, tag) pair")
                    word, tag = pair
                    counts.setdefault(word, Counter())[tag] += 1
        self._model = {}
        for word, tag_counts in counts.items():
            best = None
            for tag in tag_counts:  # insertion order breaks ties
                if best is None or tag_counts[tag] > tag_counts[best]:
                    best = tag
            self._model[word] = best

    def _assign(self, tokens):
        return [self._model.get(token) for token in tokens]


class RegexpTagger(_SequentialTagger):
    """Rules tried in order; a token takes the tag of the first pattern matching at its start."""

    def __init__(self, regexps, backoff=None):  # spec: N-000191, N-000192, N-000193, N-000402
        super().__init__(backoff)
        if not isinstance(regexps, (list, tuple)):
            raise TypeError("regexps must be a list of (pattern, tag) pairs")
        self._rules = []
        for pair in regexps:
            if not (isinstance(pair, tuple) and len(pair) == 2):
                raise TypeError("each rule must be a (pattern, tag) pair")
            pattern, tag = pair
            self._rules.append((re.compile(pattern), tag))

    def _assign(self, tokens):
        tags = []
        for token in tokens:
            tag = None
            for pattern, candidate in self._rules:
                if pattern.match(token):
                    tag = candidate
                    break
            tags.append(tag)
        return tags


_RECOMMENDED_LANGS = ("eng", "rus")  # spec: N-000179, N-000180, N-000181, N-000182, N-000183, N-000184, N-000196, N-000202, N-000203, N-000204, N-000205, N-000206, N-000207


def pos_tag(tokens, tagset=None, lang="eng"):  # spec: N-000197, N-000198, N-000199, N-000200, N-000201, N-000202, N-000203, N-000204, N-000205, N-000206, N-000207, N-000208, N-000209, N-000210, N-000211, N-000212, N-000213, N-000214, N-000215, N-000216, N-000404, N-000405, N-000406, N-000407
    """LINGORA's recommended tagger for English (``eng``) or Russian (``rus``).

    ``tokens`` must be a list of str. ``tagset`` is ``None`` (native tags) or
    ``"universal"``. Returns ``[(token, tag), ...]``.
    """
    tokens = _check_tokens(tokens)
    if lang not in _RECOMMENDED_LANGS:
        raise ValueError("pos_tag supports only 'eng' and 'rus', not %r" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("tagset must be None or 'universal'")
    tagger = _perceptron.AveragedPerceptronTagger.from_resource(lang)
    tagged = tagger.tag(tokens)
    if tagset == "universal":
        if lang == "eng":
            mapping = _perceptron.load_universal_map(lang)
            tagged = [(word, mapping.get(tag, "X")) for word, tag in tagged]
        else:
            tagged = [(word, _perceptron.map_russian(tag)) for word, tag in tagged]
    return tagged
