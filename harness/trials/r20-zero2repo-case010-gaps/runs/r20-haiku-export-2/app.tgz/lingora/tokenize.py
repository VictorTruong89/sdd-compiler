"""Tokenizers — ``lingora.tokenize`` (FP-01).

Entries that need a packaged Punkt model (``sent_tokenize`` and
``word_tokenize`` with sentence splitting) raise
:class:`lingora.data.ResourceNotFound` when the model is not visible.
"""

import re

from lingora import _punkt

__all__ = [
    "RegexpTokenizer",
    "TreebankWordTokenizer",
    "TweetTokenizer",
    "WhitespaceTokenizer",
    "WordPunctTokenizer",
    "blankline_tokenize",
    "sent_tokenize",
    "word_tokenize",
    "wordpunct_tokenize",
]


def _check_text(text):
    if not isinstance(text, str):
        raise TypeError("text must be a str, not %s" % type(text).__name__)


# ---------------------------------------------------------------------------
# Word / punctuation tokenizer
# ---------------------------------------------------------------------------

_WORDPUNCT_RE = re.compile(r"\w+|[^\w\s]+")  # spec: N-000085, N-000086, N-000087


class WordPunctTokenizer(object):
    """Splits on the boundary between word and non-word characters."""

    def tokenize(self, text):  # spec: N-000085, N-000086, N-000087, N-000129
        _check_text(text)
        return _WORDPUNCT_RE.findall(text)

    def span_tokenize(self, text):  # spec: N-000119, N-000120, N-000121, N-000380
        _check_text(text)
        return [(m.start(), m.end()) for m in _WORDPUNCT_RE.finditer(text)]


def wordpunct_tokenize(text):
    """Word/punctuation tokenizer entry (same as ``WordPunctTokenizer().tokenize``)."""
    return WordPunctTokenizer().tokenize(text)


# ---------------------------------------------------------------------------
# Penn Treebank conventions (and LINGORA's recommended variant)
# ---------------------------------------------------------------------------

# Typographic quotation marks (recommended variant only).
_TYPOGRAPHIC_QUOTES = "“”„‟‘’‚‛«»‹›"
_TYPOGRAPHIC_QUOTE_RE = re.compile("[" + _TYPOGRAPHIC_QUOTES + "]")
_DASH_RE = re.compile("[‒-―]")  # dashes U+2012..U+2015

# Fused forms split into two parts (case-insensitive, whole words).
_FUSED_FORMS = [
    (re.compile(r"(?<!\w)(can)(not)(?!\w)", re.I), r"\1 \2"),
    (re.compile(r"(?<!\w)(d')(ye)(?!\w)", re.I), r"\1 \2"),
    (re.compile(r"(?<!\w)(gim)(me)(?!\w)", re.I), r"\1 \2"),
    (re.compile(r"(?<!\w)(gon)(na)(?!\w)", re.I), r"\1 \2"),
    (re.compile(r"(?<!\w)(got)(ta)(?!\w)", re.I), r"\1 \2"),
    (re.compile(r"(?<!\w)(lem)(me)(?!\w)", re.I), r"\1 \2"),
    (re.compile(r"(?<!\w)(more)('n)(?!\w)", re.I), r"\1 \2"),
    (re.compile(r"(?<!\w)(wan)(na)(?!\w)", re.I), r"\1 \2"),
    (re.compile(r"(?<!\w)('t)(is)(?!\w)", re.I), r"\1 \2"),
    (re.compile(r"(?<!\w)('t)(was)(?!\w)", re.I), r"\1 \2"),
]

# Clitics split from the word they follow (either letter case).
_CLITIC_NT_RE = re.compile(r"(?<=\w)(?=n't(?!\w))", re.I)
_CLITIC_RE = re.compile(r"(?<=\w)(?='(?:s|m|d|ll|re|ve)(?!\w))", re.I)
# A bare apostrophe ending a word.
_BARE_APOSTROPHE_RE = re.compile(r"(?<=\w)(?=')(?!'\w)")

_OPEN_QUOTE_RE = re.compile(r'(?:^|(?<=[\s(\[{<]))"')
_BRACKET_RE = re.compile(r"[\[\](){}<>]")
_SINGLE_PUNCT_RE = re.compile(r"[;@#$%&?!]")
_COMMA_COLON_RE = re.compile(r"([:,])(?!\d)")
_FINAL_POINT_RE = re.compile(r"(?<=[^\s.])\.(?=[\]\)}>\"'\s]*$)")
_ELLIPSIS_RE = re.compile(r"\.\.\.")
_MULTI_POINT_RE = re.compile(r"\.{2,}")
_DOUBLE_HYPHEN_RE = re.compile(r"--")


def _penn_tokenize(text, recommended):  # spec: N-000089, N-000090, N-000091, N-000092, N-000093, N-000094, N-000095, N-000096, N-000097, N-000098
    """Shared implementation of the Penn Treebank conventions."""
    # Straight double quotes: opening after start/space/opening bracket, else closing.
    text = _OPEN_QUOTE_RE.sub(" `` ", text)
    text = text.replace('"', " '' ")

    if recommended:
        text = _TYPOGRAPHIC_QUOTE_RE.sub(lambda m: " %s " % m.group(0), text)
        text = _DASH_RE.sub(lambda m: " %s " % m.group(0), text)
        text = text.replace("*", " * ")
        text = _MULTI_POINT_RE.sub(lambda m: " %s " % m.group(0), text)
    else:
        text = _ELLIPSIS_RE.sub(lambda m: " ... ", text)

    text = _SINGLE_PUNCT_RE.sub(lambda m: " %s " % m.group(0), text)
    text = _BRACKET_RE.sub(lambda m: " %s " % m.group(0), text)
    text = _COMMA_COLON_RE.sub(lambda m: " %s " % m.group(1), text)
    text = _FINAL_POINT_RE.sub(" .", text)

    if recommended:
        text = _DOUBLE_HYPHEN_RE.sub(" -- ", text)

    text = _CLITIC_NT_RE.sub(" ", text)
    text = _CLITIC_RE.sub(" ", text)
    text = _BARE_APOSTROPHE_RE.sub(" ", text)
    # fused forms last, so that e.g. "d'ye" keeps its apostrophe with "d"
    for pattern, repl in _FUSED_FORMS:
        text = pattern.sub(repl, text)
    return text.split()


class TreebankWordTokenizer(object):
    """Penn Treebank word tokenizer (FP-01)."""

    def tokenize(self, text):  # spec: N-000088, N-000089, N-000090, N-000093, N-000094, N-000095, N-000096, N-000097, N-000098
        _check_text(text)
        return _penn_tokenize(text, recommended=False)


def _recommended_tokenize_sentence(text):
    return _penn_tokenize(text, recommended=True)


def word_tokenize(text, language="english", preserve_line=False):  # spec: N-000082, N-000083, N-000084, N-000377, N-000378
    """LINGORA's recommended word tokenizer.

    ``preserve_line=True`` treats ``text`` as one already-delimited line.
    Otherwise the text is first split into sentences with Punkt for ``language``
    (default ``english``); a missing Punkt model raises.
    """
    _check_text(text)
    if preserve_line:
        return _recommended_tokenize_sentence(text)  # spec: N-000099, N-000100, N-000101, N-000102, N-000103
    tokens = []
    for sentence in sent_tokenize(text, language=language):
        tokens.extend(_recommended_tokenize_sentence(sentence))  # spec: N-000104, N-000105
    return tokens


# ---------------------------------------------------------------------------
# Sentence tokenizer (Punkt)
# ---------------------------------------------------------------------------

def sent_tokenize(text, language="english"):  # spec: N-000381, N-000130, N-000131
    """Split ``text`` into sentences with the Punkt model for ``language``."""
    _check_text(text)
    params = _punkt.load_language(language)  # raises ResourceNotFound when missing
    return _punkt.PunktSentenceTokenizer(params).sentences(text)  # spec: N-000122, N-000123, N-000124, N-000125, N-000126


# ---------------------------------------------------------------------------
# Whitespace, blank-line and regular-expression tokenizers
# ---------------------------------------------------------------------------

_WHITESPACE_RE = re.compile(r"\S+")  # spec: N-000106
_BLANKLINE_SEP_RE = re.compile(r"\s*\n[^\S\n]*\n\s*")  # spec: N-000107


class WhitespaceTokenizer(object):
    def tokenize(self, text):
        _check_text(text)
        return _WHITESPACE_RE.findall(text)

    def span_tokenize(self, text):
        _check_text(text)
        return [(m.start(), m.end()) for m in _WHITESPACE_RE.finditer(text)]


def blankline_tokenize(text):  # spec: N-000108, N-000379
    """Segments of ``text`` separated by blank lines (empty pieces dropped)."""
    _check_text(text)
    pieces = _BLANKLINE_SEP_RE.split(text)  # spec: N-000107, N-000108
    return [piece for piece in pieces if piece.strip()]


class RegexpTokenizer(object):
    """Tokenizer driven by a caller-supplied regular expression (FP-01)."""

    def __init__(self, pattern, gaps=False, discard_empty=True):
        if not isinstance(pattern, str):
            raise TypeError("pattern must be a str")
        self._pattern = re.compile(pattern)
        self._gaps = bool(gaps)
        self._discard_empty = bool(discard_empty)

    def tokenize(self, text):  # spec: N-000109, N-000110, N-000111
        _check_text(text)
        return [text[s:e] for s, e in self.span_tokenize(text)]

    def span_tokenize(self, text):
        _check_text(text)
        spans = []
        if self._gaps:
            position = 0
            for match in self._pattern.finditer(text):
                spans.append((position, match.start()))
                position = match.end()
            spans.append((position, len(text)))
        else:
            for match in self._pattern.finditer(text):
                spans.append((match.start(), match.end()))
        if self._discard_empty:
            spans = [(s, e) for s, e in spans if e > s]
        return spans


# ---------------------------------------------------------------------------
# Tweet tokenizer
# ---------------------------------------------------------------------------

_EMOTICON = r"(?:[<>]?[:;=8][\-o\*']?[\)\]\(\[dDpP/\:\}\{@\|\\]|[\)\]\(\[dDpP/\:\}\{@\|\\][\-o\*']?[:;=8][<>]?|<3)"
_TWEET_TOKEN_RE = re.compile(
    "|".join(
        [
            _EMOTICON,
            r"https?://\S+|www\.\S+",            # URLs
            r"[#]\w+",                           # hashtags
            r"[@]\w+",                           # @-handles (kept when not stripped)
            r"\w+(?:['’]\w+)*",             # words, internal apostrophes stay inside
            r"\.{2,}",                           # ellipsis
            r"[^\w\s]",                          # other punctuation, one per token
        ]
    )
)
_HANDLE_RE = re.compile(r"(?<!\w)@[A-Za-z0-9_]{1,15}(?![A-Za-z0-9_])")  # spec: N-000116
_LONG_RUN_RE = re.compile(r"(.)\1{2,}", re.DOTALL)  # spec: N-000117
_EMOTICON_RE = re.compile(_EMOTICON + "$")


class TweetTokenizer(object):
    """Tweet-style tokenizer (FP-01)."""

    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self._preserve_case = bool(preserve_case)
        self._reduce_len = bool(reduce_len)
        self._strip_handles = bool(strip_handles)

    def tokenize(self, text):  # spec: N-000112, N-000113, N-000114, N-000115, N-000118
        _check_text(text)
        if self._strip_handles:
            text = _HANDLE_RE.sub(" ", text)
        if self._reduce_len:
            text = _LONG_RUN_RE.sub(lambda m: m.group(1) * 3, text)
        tokens = _TWEET_TOKEN_RE.findall(text)
        if not self._preserve_case:
            tokens = [
                tok if _EMOTICON_RE.match(tok) else tok.lower() for tok in tokens
            ]
        return tokens
