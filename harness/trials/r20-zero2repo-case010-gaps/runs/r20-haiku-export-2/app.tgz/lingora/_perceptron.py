"""Greedy averaged perceptron part-of-speech tagger (textblob-aptagger, Honnibal 2013).

The weights, tag dictionary and classes are read from the packaged resource
``taggers/averaged_perceptron_tagger_<lang>/`` (files
``averaged_perceptron_tagger_<lang>.weights.json``, ``.tagdict.json`` and
``.classes.json``) found through :mod:`lingora.data`.
"""

import json
import os
from collections import defaultdict

from lingora import data

START = ["-START-", "-START2-"]
END = ["-END-", "-END2-"]

_CACHE = {}


def normalize(word):
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word and word[0].isdigit():
        return "!DIGITS"
    return word.lower()


class AveragedPerceptronTagger(object):
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = list(classes)

    @classmethod
    def from_resource(cls, lang):
        """Load the packaged tagger for ``lang`` (``eng`` or ``rus``)."""
        if lang not in ("eng", "rus"):
            raise ValueError("unsupported tagger language %r" % (lang,))
        directory = data.find("taggers/averaged_perceptron_tagger_%s" % lang)
        key = os.path.abspath(directory)
        if key not in _CACHE:
            stem = os.path.join(directory, "averaged_perceptron_tagger_%s" % lang)
            with open(stem + ".weights.json", encoding="utf-8") as handle:
                weights = json.load(handle)
            with open(stem + ".tagdict.json", encoding="utf-8") as handle:
                tagdict = json.load(handle)
            with open(stem + ".classes.json", encoding="utf-8") as handle:
                classes = json.load(handle)
            _CACHE[key] = cls(weights, tagdict, classes)
        return _CACHE[key]

    def _features(self, i, word, context, prev, prev2):
        features = defaultdict(int)

        def add(name, *args):
            features[" ".join((name,) + tuple(args))] += 1

        i += len(START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return features

    def _predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            if feat not in self.weights or value == 0:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))

    def tag(self, tokens):
        """Return ``[(token, tag), ...]`` for the token list, tagged left to right."""
        prev, prev2 = START
        output = []
        context = START + [normalize(w) for w in tokens] + END
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                features = self._features(i, word, context, prev, prev2)
                tag = self._predict(features)
            output.append((word, tag))
            prev2 = prev
            prev = tag
        return output


def load_universal_map(lang):
    """Mapping from the native tag to the universal tag (English table is packaged)."""
    if lang == "eng":
        filename = data.find("taggers/universal_tagset/en-ptb.map")
        mapping = {}
        with open(filename, encoding="utf-8") as handle:
            for line in handle:
                fields = line.rstrip("\r\n").split("\t")
                if len(fields) == 2:
                    mapping[fields[0]] = fields[1]
        return mapping
    raise ValueError("no packaged universal table for %r" % (lang,))


# Russian National Corpus part-of-speech categories -> universal categories
# (implementer's choice; the table is built in).
RUSSIAN_TO_UNIVERSAL = {
    "S": "NOUN",
    "A": "ADJ",
    "ANUM": "ADJ",
    "NUM": "NUM",
    "V": "VERB",
    "ADV": "ADV",
    "PRAEDIC": "ADV",
    "PARENTH": "ADV",
    "A-PRO": "PRON",
    "S-PRO": "PRON",
    "PRAEDIC-PRO": "PRON",
    "PR": "ADP",
    "CONJ": "CONJ",
    "PART": "PRT",
    "INTJ": "X",
}


def map_russian(tag):
    """Map an RNC tag by the part before any ``=``."""
    return RUSSIAN_TO_UNIVERSAL.get(tag.split("=", 1)[0], "X")
