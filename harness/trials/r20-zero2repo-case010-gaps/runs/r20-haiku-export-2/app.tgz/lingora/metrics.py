"""Evaluation metrics — ``lingora.metrics`` (FP-07).

Pure functions of their arguments. Booleans are never accepted as numbers.
"""

__all__ = [
    "accuracy",
    "edit_distance",
    "f_measure",
    "jaccard_distance",
    "precision",
    "recall",
]


def _is_number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def _require_sets(*values):
    for value in values:
        if not isinstance(value, (set, frozenset)):
            raise TypeError("arguments must be sets, not %s" % type(value).__name__)


def accuracy(reference, test):  # spec: N-000461  # spec: N-000310, N-000464, N-000465, N-000471
    """Fraction of positions at which the two equal-length lists agree."""
    if not isinstance(reference, (list, tuple)) or not isinstance(test, (list, tuple)):
        raise TypeError("accuracy arguments must be lists")
    if len(reference) != len(test):
        raise ValueError("accuracy needs lists of equal length")
    if not reference:
        raise ValueError("accuracy of two empty lists is undefined")
    equal = sum(1 for x, y in zip(reference, test) if x == y)
    return equal / len(reference)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):  # spec: N-000292, N-000293, N-000294, N-000295, N-000296, N-000297, N-000298, N-000299, N-000315, N-000466, N-000467, N-000468
    """Minimum total cost of edits turning ``s1`` into ``s2``.

    Insertion and deletion cost 1; substitution costs ``substitution_cost``.
    With ``transpositions=True`` this is the unrestricted Damerau–Levenshtein
    distance (Lowrance and Wagner, 1975): an adjacent transposition costs 1.
    """
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("edit_distance arguments must be str")
    if not _is_number(substitution_cost):
        raise TypeError("substitution_cost must be a number")
    if transpositions:
        return _damerau_levenshtein(s1, s2, substitution_cost)
    return _levenshtein(s1, s2, substitution_cost)


def _levenshtein(a, b, sub):
    previous = [j for j in range(len(b) + 1)]
    for i in range(1, len(a) + 1):
        current = [i] + [0] * len(b)
        for j in range(1, len(b) + 1):
            cost = 0 if a[i - 1] == b[j - 1] else sub
            current[j] = min(
                previous[j] + 1,          # deletion
                current[j - 1] + 1,       # insertion
                previous[j - 1] + cost,   # substitution / match
            )
        previous = current
    return previous[len(b)]


def _damerau_levenshtein(a, b, sub):
    """Unrestricted Damerau–Levenshtein (Lowrance and Wagner)."""
    maxdist = len(a) + len(b)
    last_row = {}
    # table with a sentinel row/column, index shifted by one
    d = [[0] * (len(b) + 2) for _ in range(len(a) + 2)]
    d[0][0] = maxdist
    for i in range(len(a) + 1):
        d[i + 1][0] = maxdist
        d[i + 1][1] = i
    for j in range(len(b) + 1):
        d[0][j + 1] = maxdist
        d[1][j + 1] = j
    for i in range(1, len(a) + 1):
        last_match_col = 0
        for j in range(1, len(b) + 1):
            i1 = last_row.get(b[j - 1], 0)
            j1 = last_match_col
            if a[i - 1] == b[j - 1]:
                cost = 0
                last_match_col = j
            else:
                cost = sub
            d[i + 1][j + 1] = min(
                d[i][j] + cost,                                   # match / substitution
                d[i + 1][j] + 1,                                  # insertion
                d[i][j + 1] + 1,                                  # deletion
                d[i1][j1] + (i - i1 - 1) + 1 + (j - j1 - 1),      # transposition
            )
        last_row[a[i - 1]] = i
    return d[len(a) + 1][len(b) + 1]


def jaccard_distance(label1, label2):  # spec: N-000469
    """1 minus the size of the intersection over the size of the union."""
    _require_sets(label1, label2)
    union = label1 | label2
    if not union:
        return 0.0
    return 1 - len(label1 & label2) / len(union)


def precision(reference, test):  # spec: N-000311, N-000312, N-000313, N-000314, N-000470, N-000471, N-000472
    """|reference ∩ test| / |test|; None when ``test`` is empty."""
    _require_sets(reference, test)
    if not test:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):  # spec: N-000470, N-000471, N-000472
    """|reference ∩ test| / |reference|; None when ``reference`` is empty."""
    _require_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):  # spec: N-000300, N-000301, N-000470, N-000471, N-000472
    """Weighted harmonic mean of precision and recall; None if either set is empty."""
    _require_sets(reference, test)
    if not _is_number(alpha):
        raise TypeError("alpha must be a number")
    p = precision(reference, test)
    r = recall(reference, test)
    if p is None or r is None:
        return None
    if p == 0 or r == 0:
        return 0.0
    return 1 / (alpha / p + (1 - alpha) / r)
