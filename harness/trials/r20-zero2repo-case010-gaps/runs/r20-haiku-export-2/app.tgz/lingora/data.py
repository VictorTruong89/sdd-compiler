"""Packaged resources — ``lingora.data``.

``path`` is a mutable list of directory strings searched for packaged
resources. A caller may replace its contents in place; calls that need a
resource then find it only in the listed directories. An empty list means no
packaged resource is visible.

Initial contents (implementer's choice): the entries of the ``LINGORA_DATA``
environment variable (split with ``os.pathsep``), then ``~/.lingora``.
"""

import os

__all__ = ["path", "find", "is_visible", "ResourceNotFound"]


class ResourceNotFound(LookupError):
    """Raised when a packaged resource is not visible on ``path``."""


def _initial_path():
    entries = []
    env = os.environ.get("LINGORA_DATA", "")
    for part in env.split(os.pathsep):
        if part:
            entries.append(part)
    entries.append(os.path.join(os.path.expanduser("~"), ".lingora"))
    return entries


# spec: N-000353, N-000355, N-000356
path = _initial_path()


def find(relpath):
    """Return the first existing location of ``relpath`` on ``path``.

    ``relpath`` is a resource name relative to a directory on ``path``
    (for example ``"tokenizers/punkt_tab/english"``). Raises
    :class:`ResourceNotFound` (a ``LookupError``) when none is visible.
    """
    # spec: N-000354
    for directory in list(path):
        candidate = os.path.join(directory, *relpath.split("/"))
        if os.path.exists(candidate):
            return candidate
    raise ResourceNotFound(
        "packaged resource %r is not visible on lingora.data.path" % relpath
    )


def is_visible(relpath):
    """Return True when ``relpath`` can be found on ``path``."""
    try:
        find(relpath)
    except ResourceNotFound:
        return False
    return True
