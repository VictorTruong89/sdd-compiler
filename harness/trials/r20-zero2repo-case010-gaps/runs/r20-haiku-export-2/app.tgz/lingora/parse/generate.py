"""Sentence generation from a grammar — ``lingora.parse.generate`` (FP-05).

``generate(grammar, start=None, depth=None, n=None)`` enumerates the token
lists the grammar derives from ``start`` (default: the grammar's start symbol),
expanding productions in their written order.

* ``depth``: derivation depth bound. A nonterminal is expanded only while the
  remaining depth is positive; terminals are always emitted. ``None`` means no
  bound.
* ``n``: maximum number of sentences; ``None`` means no limit.

A quoted empty string contributes an empty-string token; an empty production
contributes no token.
"""

import itertools
import sys

from lingora.grammar import Nonterminal

__all__ = ["generate"]


def generate(grammar, start=None, depth=None, n=None):  # spec: N-000251, N-000252, N-000253, N-000254, N-000255, N-000440, N-000441, N-000442, N-000443
    if start is None:
        start = grammar.start()
    elif isinstance(start, str):
        start = Nonterminal(start)
    if start is None:
        return iter([])
    if depth is None:
        depth = sys.maxsize
    if not isinstance(depth, int) or isinstance(depth, bool):
        raise TypeError("depth must be an int or None")
    sentences = _generate_all(grammar, [start], depth)
    if n is not None:
        if not isinstance(n, int) or isinstance(n, bool):
            raise TypeError("n must be an int or None")
        sentences = itertools.islice(sentences, n)
    return sentences


def _generate_all(grammar, items, depth):
    if not items:
        yield []
        return
    for head_fragment in _generate_one(grammar, items[0], depth):
        for rest_fragment in _generate_all(grammar, items[1:], depth):
            yield head_fragment + rest_fragment


def _generate_one(grammar, item, depth):
    if isinstance(item, Nonterminal):
        if depth > 0:
            for production in grammar.productions(lhs=item):
                yield from _generate_all(grammar, list(production.rhs()), depth - 1)
    else:
        yield [item]
