"""Parsers — ``lingora.parse`` (FP-05).

``ChartParser`` is exhaustive: it returns every tree the grammar assigns to
the token list. ``ShiftReduceParser`` is a single left-to-right pass without
backtracking. Both raise ``ValueError`` when a token is produced by no
production of the grammar; a token list the grammar does not derive gives an
empty iterator.
"""

from lingora.grammar import CFG, Nonterminal
from lingora.tree import Tree

__all__ = ["ChartParser", "ShiftReduceParser"]


def _check_tokens(grammar, tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")
    for token in tokens:
        if not isinstance(token, str):
            raise TypeError("tokens must be a list of str")
    if not isinstance(grammar, CFG):
        raise TypeError("grammar must be a CFG")
    known = grammar.terminals()
    for token in tokens:
        if token not in known:
            # spec: N-000438, N-000439
            raise ValueError("token %r is produced by no production of the grammar" % token)
    return list(tokens)


class ChartParser(object):
    """Exhaustive chart parser: every parse tree for the tokens."""

    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):  # spec: N-000242, N-000243, N-000244, N-000245, N-000246, N-000436, N-000437
        tokens = _check_tokens(self._grammar, tokens)
        start = self._grammar.start()
        if start is None:
            return iter([])
        trees = _all_trees(self._grammar, tokens, start)
        return iter(trees)


def _all_trees(grammar, tokens, start):
    """Every tree for ``start`` over ``tokens`` (memoised over spans)."""
    n = len(tokens)
    memo = {}
    active = set()

    def trees(symbol, i, j):
        key = (symbol, i, j)
        if key in memo:
            return memo[key]
        if key in active:  # a derivation that cycles back on its own span
            return []
        active.add(key)
        result = []
        for production in grammar.productions(symbol):
            for children in match(production.rhs(), i, j):
                result.append(Tree(str(symbol), children))
        active.discard(key)
        memo[key] = result
        return result

    def match(rhs, i, j):
        if not rhs:
            if i == j:
                yield []
            return
        head, rest = rhs[0], rhs[1:]
        if isinstance(head, Nonterminal):
            for k in range(i, j + 1):
                subtrees = trees(head, i, k)
                if not subtrees:
                    continue
                tails = list(match(rest, k, j))
                for subtree in subtrees:
                    for tail in tails:
                        yield [subtree] + tail
        else:
            if i < j and tokens[i] == head:
                for tail in match(rest, i + 1, j):
                    yield [tokens[i]] + tail

    return trees(start, 0, n)


class ShiftReduceParser(object):
    """Single left-to-right shift-reduce pass, without backtracking."""

    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):  # spec: N-000247, N-000248, N-000249, N-000250, N-000438, N-000439
        tokens = _check_tokens(self._grammar, tokens)
        start = self._grammar.start()
        if start is None:
            return iter([])
        productions = [p for p in self._grammar.productions() if len(p) > 0]
        remaining = list(tokens)
        stack = []
        reductions_since_shift = 0
        while True:
            reduced = False
            # a cycle of unit productions could reduce forever; cap reductions between shifts
            if reductions_since_shift <= len(productions):
                for production in productions:
                    if _matches_top(stack, production.rhs()):
                        width = len(production.rhs())
                        children = stack[len(stack) - width:]
                        del stack[len(stack) - width:]
                        stack.append(Tree(str(production.lhs()), children))
                        reduced = True
                        break
            if reduced:
                reductions_since_shift += 1
                continue
            reductions_since_shift = 0
            if remaining:
                stack.append(remaining.pop(0))
                continue
            break
        if len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == str(start):
            return iter([stack[0]])
        return iter([])


def _matches_top(stack, rhs):
    width = len(rhs)
    if width == 0 or len(stack) < width:
        return False
    top = stack[len(stack) - width:]
    for item, sym in zip(top, rhs):
        if isinstance(sym, Nonterminal):
            if not (isinstance(item, Tree) and item.label() == str(sym)):
                return False
        else:
            if not (isinstance(item, str) and item == sym):
                return False
    return True
