"""Chunking — ``lingora.chunk`` (FP-04).

``RegexpParser(grammar)`` reads a chunk grammar: one or more clauses, each
``<LABEL>: <pattern>`` followed by indented continuation patterns. A pattern
``{<tag pattern>}`` is a chunk rule; ``}<tag pattern>{`` is a chink rule. A tag
pattern is a sequence of ``<regex>`` elements, each optionally followed by
``?``, ``*``, ``+``, ``{m,n}`` or ``{m,}``; each element must match a whole tag.

``ne_chunk`` needs the packaged named-entity chunker and English wordlist; it
raises when they are not visible. Lines whose first character is ``#`` are
comments.
"""

import re

from lingora import data
from lingora.tree import Tree

__all__ = ["RegexpParser", "ne_chunk"]

ROOT_LABEL = "S"  # spec: N-000217, N-000420 (default sentence label; spelling is the implementer's choice)

_QUANT_RE = re.compile(r"\{(\d*)(,?)(\d*)\}")


class _Element(object):
    __slots__ = ("pattern", "low", "high")

    def __init__(self, regex, low, high):
        self.pattern = re.compile(regex)
        self.low = low
        self.high = high  # None means unbounded


class _Rule(object):
    __slots__ = ("kind", "elements")

    def __init__(self, kind, elements):
        self.kind = kind          # "chunk" or "chink"
        self.elements = elements


class _Clause(object):
    __slots__ = ("label", "rules")

    def __init__(self, label, rules):
        self.label = label
        self.rules = rules


class _Chunk(object):
    """A chunk built while parsing; ``clause`` is the index of the clause that built it."""

    __slots__ = ("label", "children", "clause")

    def __init__(self, label, children, clause):
        self.label = label
        self.children = children
        self.clause = clause


def _parse_tag_pattern(text, pos, closer):
    """Parse elements from ``pos`` up to ``closer``; return (elements, position after closer)."""
    elements = []
    n = len(text)
    while True:
        while pos < n and text[pos].isspace():
            pos += 1
        if pos >= n:
            raise ValueError("unterminated pattern %r" % text)
        ch = text[pos]
        if ch == closer:
            return elements, pos + 1
        if ch != "<":
            raise ValueError("expected '<' in tag pattern %r" % text)
        end = text.find(">", pos + 1)
        if end < 0:
            raise ValueError("unterminated '<' in tag pattern %r" % text)
        regex = text[pos + 1:end]
        pos = end + 1
        low, high = 1, 1
        if pos < n and text[pos] in "?*+":
            low, high = {"?": (0, 1), "*": (0, None), "+": (1, None)}[text[pos]]
            pos += 1
        else:
            match = _QUANT_RE.match(text, pos)
            if match and (match.group(1) or match.group(3)):
                first, comma, second = match.group(1), match.group(2), match.group(3)
                low = int(first) if first else 0
                if comma:
                    high = int(second) if second else None
                else:
                    high = low
                pos = match.end()
        elements.append(_Element(regex, low, high))


def _parse_pattern_line(text):
    """Parse a line of patterns: ``{...}`` chunk rules and ``}...{`` chink rules."""
    rules = []
    pos = 0
    n = len(text)
    while pos < n:
        ch = text[pos]
        if ch.isspace():
            pos += 1
        elif ch == "{":
            elements, pos = _parse_tag_pattern(text, pos + 1, "}")
            rules.append(_Rule("chunk", elements))
        elif ch == "}":
            elements, pos = _parse_tag_pattern(text, pos + 1, "{")
            rules.append(_Rule("chink", elements))
        else:
            raise ValueError("unexpected %r in chunk grammar pattern %r" % (ch, text))
    return rules


def _parse_grammar(grammar):
    clauses = []
    for raw in grammar.splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        if raw[0].isspace():
            if not clauses:
                raise ValueError("pattern line before any clause label")
            clauses[-1].rules.extend(_parse_pattern_line(raw.strip()))
            continue
        match = re.match(r"^(\S+?):\s*(.*)$", raw.strip())
        if not match:
            raise ValueError("clause line must be '<LABEL>: <pattern>': %r" % raw)
        label, rest = match.group(1), match.group(2)
        clauses.append(_Clause(label, _parse_pattern_line(rest) if rest else []))
    if not clauses:
        raise ValueError("chunk grammar has no clauses")
    return clauses


def _unit_tag(unit):
    if isinstance(unit, _Chunk):
        return unit.label
    return unit[1]


def _match_longest(elements, units, start, clause_index):
    """Longest end index of an element sequence matched from ``start``, or None."""
    positions = {start}
    for element in elements:
        next_positions = set()
        for begin in positions:
            count = 0
            position = begin
            if count >= element.low:
                next_positions.add(position)
            while (element.high is None or count < element.high) and position < len(units):
                unit = units[position]
                if isinstance(unit, _Chunk) and unit.clause == clause_index:
                    break  # chunks of the same clause are not matchable units
                if not element.pattern.fullmatch(_unit_tag(unit)):
                    break
                position += 1
                count += 1
                if count >= element.low:
                    next_positions.add(position)
        positions = next_positions
        if not positions:
            return None
    end = max(positions)
    return end if end > start else None


def _apply_chunk_rule(units, rule, label, clause_index):
    result = []
    index = 0
    while index < len(units):
        end = _match_longest(rule.elements, units, index, clause_index)
        if end is not None:
            result.append(_Chunk(label, units[index:end], clause_index))
            index = end
        else:
            result.append(units[index])
            index += 1
    return result


def _apply_chink_rule(units, rule, clause_index):
    result = []
    for unit in units:
        if not (isinstance(unit, _Chunk) and unit.clause == clause_index):
            result.append(unit)
            continue
        pieces = []  # alternating: list of kept children, or a chinked leaf
        kept = []
        index = 0
        children = unit.children
        while index < len(children):
            matched_end = _chink_match(rule.elements, children, index)
            if matched_end is not None:
                if kept:
                    pieces.append(_Chunk(unit.label, kept, clause_index))
                    kept = []
                pieces.extend(children[index:matched_end])
                index = matched_end
            else:
                kept.append(children[index])
                index += 1
        if kept:
            pieces.append(_Chunk(unit.label, kept, clause_index))
        result.extend(pieces)
    return result


def _chink_match(elements, children, start):
    """Longest chink match inside a chunk's leaves; only leaves may be chinked."""
    positions = {start}
    for element in elements:
        next_positions = set()
        for begin in positions:
            count = 0
            position = begin
            if count >= element.low:
                next_positions.add(position)
            while (element.high is None or count < element.high) and position < len(children):
                child = children[position]
                if isinstance(child, _Chunk) or not element.pattern.fullmatch(child[1]):
                    break
                position += 1
                count += 1
                if count >= element.low:
                    next_positions.add(position)
        positions = next_positions
        if not positions:
            return None
    end = max(positions)
    return end if end > start else None


def _to_tree(unit):
    if isinstance(unit, _Chunk):
        return Tree(unit.label, [_to_tree(child) for child in unit.children])
    return unit


class RegexpParser(object):
    """Chunk parser driven by a chunk grammar text."""

    def __init__(self, grammar):  # spec: N-000413, N-000416, N-000417
        if not isinstance(grammar, str):
            raise TypeError("grammar must be a str")
        self._clauses = _parse_grammar(grammar)

    def parse(self, tagged):  # spec: N-000218, N-000221, N-000222, N-000223, N-000224, N-000225, N-000226, N-000227, N-000228, N-000229, N-000230, N-000231, N-000233, N-000234, N-000235, N-000412, N-000418, N-000419, N-000421, N-000422, N-000423
        if isinstance(tagged, str) or not isinstance(tagged, (list, tuple)):
            raise TypeError("tagged must be a list of (token, tag) pairs")
        units = []
        for pair in tagged:
            if not (isinstance(pair, tuple) and len(pair) == 2):
                raise TypeError("tagged must be a list of (token, tag) pairs")
            units.append((pair[0], pair[1]))
        for clause_index, clause in enumerate(self._clauses):
            for rule in clause.rules:
                if rule.kind == "chunk":
                    units = _apply_chunk_rule(units, rule, clause.label, clause_index)
                else:
                    units = _apply_chink_rule(units, rule, clause_index)
        return Tree(ROOT_LABEL, [_to_tree(unit) for unit in units])


def ne_chunk(tagged_tokens):  # spec: N-000219, N-000236, N-000415
    """Named-entity chunking. Requires the packaged NE chunker model and English wordlist."""
    if isinstance(tagged_tokens, str) or not isinstance(tagged_tokens, (list, tuple)):
        raise TypeError("tagged_tokens must be a list of (token, tag) pairs")
    data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    data.find("corpora/words")
    raise NotImplementedError(
        "the packaged named-entity chunker model format is outside this specification"
    )
