"""Constituent trees — ``lingora.tree`` (FP-05).

A tree has a label and an ordered list of immediate children. A child is a
leaf (a token string; chunk trees may also carry ``(token, tag)`` pairs) or a
nested :class:`Tree`.
"""

import re

__all__ = ["Tree"]

_BRACKET_TOKEN_RE = re.compile(r"\(|\)|[^\s()]+")


class Tree(object):  # spec: N-000444, N-000445, N-000447, N-000257, N-000259
    """A labelled ordered tree."""

    def __init__(self, label, children):
        # spec: N-000446, N-000449, N-000450, N-000451
        if not isinstance(children, list):
            raise TypeError(
                "children must be a list of children, not %s" % type(children).__name__
            )
        self._label = str(label)
        self._children = list(children)

    # -- access -------------------------------------------------------------

    def label(self):  # spec: N-000453
        return self._label

    def __len__(self):  # spec: N-000446, N-000447
        return len(self._children)

    def __iter__(self):
        return iter(self._children)

    def __getitem__(self, index):
        if isinstance(index, slice):
            return list(self._children[index])
        return self._children[index]

    def leaves(self):
        """Leaves under this tree, in left-to-right order."""
        result = []
        for child in self._children:
            if isinstance(child, Tree):
                result.extend(child.leaves())
            else:
                result.append(child)
        return result

    # -- comparison ---------------------------------------------------------

    def __eq__(self, other):  # spec: N-000260
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    def __hash__(self):
        return hash((self._label, tuple(self._children)))

    # -- text ---------------------------------------------------------------

    def __repr__(self):
        return "Tree(%r, %r)" % (self._label, self._children)

    def __str__(self):
        return self.pformat()

    def _flat(self):
        parts = ["(" + self._label]
        for child in self._children:
            if isinstance(child, Tree):
                parts.append(child._flat())
            else:
                parts.append(str(child))
        return " ".join(parts) + ")"

    def _pformat_lines(self, indent, margin):
        flat = " " * indent + self._flat()
        if len(flat) <= margin or not any(isinstance(c, Tree) for c in self._children):
            return [flat]
        lines = [" " * indent + "(" + self._label]
        for child in self._children:
            if isinstance(child, Tree):
                lines.extend(child._pformat_lines(indent + 2, margin))
            else:
                lines.append(" " * (indent + 2) + str(child))
        lines[-1] += ")"
        return lines

    def pformat(self, margin=70):  # spec: N-000261, N-000453, N-000454
        """Pretty-printed bracketed text (every label and leaf, pre-order)."""
        return "\n".join(self._pformat_lines(0, margin))

    @classmethod
    def fromstring(cls, s):  # spec: N-000452
        """Build a tree from bracketed tree text ``(<label> <child> ...)``."""
        if not isinstance(s, str):
            raise TypeError("bracketed tree text must be a str")
        tokens = _BRACKET_TOKEN_RE.findall(s)
        if not tokens:
            raise ValueError("empty bracketed tree text")
        tree, position = _parse_node(tokens, 0)
        if position != len(tokens):
            raise ValueError("bracketed tree text has more than one top-level node")
        return tree


def _parse_node(tokens, position):
    if tokens[position] != "(":
        raise ValueError("expected '(' in bracketed tree text, got %r" % tokens[position])
    position += 1
    if position >= len(tokens) or tokens[position] in ("(", ")"):
        raise ValueError("missing label in bracketed tree text")
    label = tokens[position]
    position += 1
    children = []
    while True:
        if position >= len(tokens):
            raise ValueError("unbalanced brackets in bracketed tree text")
        token = tokens[position]
        if token == ")":
            return Tree(label, children), position + 1
        if token == "(":
            child, position = _parse_node(tokens, position)
            children.append(child)
        else:
            children.append(token)
            position += 1
