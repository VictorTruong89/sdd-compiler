"""BLEU — ``lingora.translate`` (FP-07).

Sentence-level BLEU (Papineni et al., 2002). Unsmoothed by default; pass
``smoothing_function`` to smooth zero counts. The smoothing argument is a
callable taking the list of ``(numerator, denominator)`` pairs, one per n-gram
order, and returning the list of precisions (floats);
:class:`SmoothingFunction` provides ready-made ones.
"""

import math
from collections import Counter

__all__ = ["SmoothingFunction", "bleu"]


class SmoothingFunction(object):
    """Ready-made smoothing functions for :func:`bleu`."""

    def __init__(self, epsilon=0.1):
        self.epsilon = epsilon

    def method0(self, pairs):
        """No smoothing."""
        return [num / den for num, den in pairs]

    def method1(self, pairs):
        """Replace every zero numerator by ``epsilon``."""
        return [
            (self.epsilon if num == 0 else num) / den for num, den in pairs
        ]


def _ngrams(tokens, n):
    return Counter(tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1))


def _is_number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):  # spec: N-000302, N-000303, N-000304, N-000305, N-000306, N-000307, N-000308, N-000309, N-000473, N-000474, N-000475, N-000476, N-000477
    """Sentence BLEU of ``hypothesis`` against one or more ``references``.

    ``references`` is a list of token lists; ``hypothesis`` is a token list.
    ``weights`` gives one weight per n-gram order, starting from unigrams.
    """
    if not isinstance(references, (list, tuple)):
        raise TypeError("references must be a list of token lists")
    for reference in references:
        if not isinstance(reference, (list, tuple)):
            raise TypeError("each reference must be a token list")
    if not isinstance(hypothesis, (list, tuple)):
        raise TypeError("hypothesis must be a token list")
    if not all(_is_number(w) for w in weights):
        raise TypeError("weights must be numbers")
    if smoothing_function is not None and not callable(smoothing_function):
        raise TypeError("smoothing_function must be callable")

    if not references:
        raise ValueError("bleu needs at least one reference")
    hypothesis = list(hypothesis)
    if not hypothesis:
        return 0.0

    pairs = []
    for n in range(1, len(weights) + 1):
        candidate = _ngrams(hypothesis, n)
        max_reference = Counter()
        for reference in references:
            for gram, count in _ngrams(list(reference), n).items():
                if count > max_reference[gram]:
                    max_reference[gram] = count
        clipped = sum(min(count, max_reference[gram]) for gram, count in candidate.items())
        total = max(1, sum(candidate.values()))
        pairs.append((clipped, total))

    if smoothing_function is not None:
        precisions = list(smoothing_function(pairs))
    else:
        if pairs[0][0] == 0:  # no unigram match: score 0
            return 0.0
        precisions = [num / den for num, den in pairs]

    score = 0.0
    for weight, precision in zip(weights, precisions):
        if precision <= 0:
            return 0.0
        score += weight * math.log(precision)

    # brevity penalty against the reference length closest to the candidate's
    # (the shorter one when two are equally close)
    c = len(hypothesis)
    r = min((len(ref) for ref in references), key=lambda length: (abs(length - c), length))
    if c > r:
        penalty = 1.0
    else:
        penalty = math.exp(1 - r / c)
    return penalty * math.exp(score)
