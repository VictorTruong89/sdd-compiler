"""Stemmers — ``lingora.stem`` (FP-02).

Implemented here: Porter (LINGORA mode by default, and the original published
algorithm), Lancaster (Paice/Husk), Snowball for ``english`` (Porter2) and
``porter``, the regular-expression stemmer, and a WordNet lemmatizer that
needs the packaged WordNet directory.

Snowball languages other than ``english`` and ``porter`` are accepted by the
constructor and raise ``NotImplementedError`` when used. ``ARLSTem`` and
``ARLSTem2`` raise ``NotImplementedError`` (their results are outside the
specification).
"""

import os
import re

from lingora import data

__all__ = [
    "ARLSTem",
    "ARLSTem2",
    "LancasterStemmer",
    "PorterStemmer",
    "RegexpStemmer",
    "SnowballStemmer",
    "WordNetLemmatizer",
]

SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german",
    "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
    "russian", "spanish", "swedish",
)  # spec: N-000140, N-000393


def _check_word(word):
    if not isinstance(word, str):
        raise TypeError("word must be a str")


def _longest_suffix(word, table):
    """Return the (suffix, replacement) pair with the longest matching suffix."""
    best = None
    for suffix, replacement in table:
        if word.endswith(suffix) and (best is None or len(suffix) > len(best[0])):
            best = (suffix, replacement)
    return best


# ---------------------------------------------------------------------------
# Porter
# ---------------------------------------------------------------------------

# Built-in table of irregular forms (small; its entries are the implementer's choice).
_PORTER_IRREGULAR = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli",
    "only": "onli", "singly": "singl", "sky": "sky", "news": "news",
    "howe": "howe", "atlas": "atlas", "cosmos": "cosmos", "bias": "bias",
    "andes": "andes",
}

_PORTER_STEP2_ORIGINAL = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("abli", "able"), ("alli", "al"), ("entli", "ent"),
    ("eli", "e"), ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"),
    ("ator", "ate"), ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"),
    ("ousness", "ous"), ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"),
]
_PORTER_STEP2_LINGORA = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("bli", "ble"), ("alli", "al"), ("entli", "ent"),
    ("eli", "e"), ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"),
    ("ator", "ate"), ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"),
    ("ousness", "ous"), ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"),
    ("fulli", "ful"),
]
_PORTER_STEP3 = [
    ("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"),
    ("ical", "ic"), ("ful", ""), ("ness", ""),
]
_PORTER_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment",
    "ent", "ion", "ou", "ism", "ate", "iti", "ous", "ive", "ize",
]


def _porter_is_consonant(word, i):
    ch = word[i]
    if ch in "aeiou":
        return False
    if ch == "y":
        return i == 0 or not _porter_is_consonant(word, i - 1)
    return True


def _porter_has_vowel(stem):
    return any(not _porter_is_consonant(stem, i) for i in range(len(stem)))


def _porter_measure(stem):
    """m in [C](VC)^m[V]."""
    n = len(stem)
    i = 0
    m = 0
    while i < n and _porter_is_consonant(stem, i):
        i += 1
    while i < n:
        while i < n and not _porter_is_consonant(stem, i):
            i += 1
        if i < n:
            while i < n and _porter_is_consonant(stem, i):
                i += 1
            m += 1
    return m


def _porter_star_o(stem, lingora):
    """The *o condition: consonant-vowel-consonant, final not w, x or y.

    LINGORA extension: a two-letter stem of a vowel followed by a consonant also holds.
    """
    n = len(stem)
    if n >= 3:
        return (
            _porter_is_consonant(stem, n - 3)
            and not _porter_is_consonant(stem, n - 2)
            and _porter_is_consonant(stem, n - 1)
            and stem[-1] not in "wxy"
        )
    if lingora and n == 2:
        return (
            not _porter_is_consonant(stem, 0)
            and _porter_is_consonant(stem, 1)
            and stem[1] not in "wxy"
        )
    return False


def _porter_double_consonant(word):
    return len(word) >= 2 and word[-1] == word[-2] and _porter_is_consonant(word, len(word) - 1)


def _porter_step1b_tail(stem, lingora):
    if stem.endswith(("at", "bl", "iz")):
        return stem + "e"
    if _porter_double_consonant(stem) and stem[-1] not in "lsz":
        return stem[:-1]
    if _porter_measure(stem) == 1 and _porter_star_o(stem, lingora):
        return stem + "e"
    return stem


def _porter_step2(word, lingora):
    if lingora:
        if word.endswith("alli") and _porter_measure(word[:-4]) > 0:
            # -alli becomes -al, and the result goes through Step 2 again
            return _porter_step2(word[:-4] + "al", lingora)
        if word.endswith("logi"):
            # -logi becomes -log when the part before -ogi has positive measure
            return word[:-1] if _porter_measure(word[:-3]) > 0 else word
        table = _PORTER_STEP2_LINGORA
    else:
        table = _PORTER_STEP2_ORIGINAL
    return _apply_measured_suffix(word, table, 0)


def _apply_measured_suffix(word, table, min_measure):
    best = _longest_suffix(word, table)
    if best is None:
        return word
    suffix, replacement = best
    stem = word[: len(word) - len(suffix)]
    if _porter_measure(stem) > min_measure:
        return stem + replacement
    return word


def _porter_stem_word(word, lingora):
    """Porter stemming of an already-lowercased word."""
    if len(word) <= 2:
        return word

    # Step 1a
    if word.endswith("sses"):
        word = word[:-2]
    elif word.endswith("ies"):
        if lingora and len(word) == 4:
            word = word[:-1]          # four-letter -ies becomes -ie
        else:
            word = word[:-2]          # -ies becomes -i
    elif word.endswith("ss"):
        pass
    elif word.endswith("s"):
        if _porter_has_vowel(word[:-1]):
            word = word[:-1]

    # Step 1b (LINGORA: -ied is handled first and skips the rest of Step 1b)
    if lingora and word.endswith("ied"):
        word = word[:-1] if len(word) == 4 else word[:-2] + "i"
    elif word.endswith("eed"):
        if _porter_measure(word[:-3]) > 0:
            word = word[:-3] + "ee"
    elif word.endswith("ed") and _porter_has_vowel(word[:-2]):
        word = _porter_step1b_tail(word[:-2], lingora)
    elif word.endswith("ing") and _porter_has_vowel(word[:-3]):
        word = _porter_step1b_tail(word[:-3], lingora)

    # Step 1c
    if lingora:
        # y becomes i only after a consonant that is not the first letter of the stem
        if word.endswith("y") and len(word) >= 3 and _porter_is_consonant(word, len(word) - 2):
            word = word[:-1] + "i"
    elif word.endswith("y") and _porter_has_vowel(word[:-1]):
        word = word[:-1] + "i"

    # Step 2
    word = _porter_step2(word, lingora)

    # Step 3
    word = _apply_measured_suffix(word, _PORTER_STEP3, 0)

    # Step 4
    best = _longest_suffix(word, [(suffix, "") for suffix in _PORTER_STEP4])
    if best is not None:
        suffix = best[0]
        stem = word[: len(word) - len(suffix)]
        if suffix == "ion":
            if stem[-1:] in ("s", "t") and _porter_measure(stem) > 1:
                word = stem
        elif _porter_measure(stem) > 1:
            word = stem

    # Step 5
    if word.endswith("e"):
        stem = word[:-1]
        m = _porter_measure(stem)
        if m > 1 or (m == 1 and not _porter_star_o(stem, lingora)):
            word = stem
    if word.endswith("ll") and _porter_measure(word[:-1]) > 1:
        word = word[:-1]
    return word


class PorterStemmer(object):  # spec: N-000142, N-000144
    """Porter stemmer.

    ``mode`` is ``"lingora"`` (the default LINGORA extensions), ``"original"``
    (Porter's published algorithm) or ``"martin"``. ``"martin"`` is accepted and
    uses the original rules; the separate Martin Porter extensions are not
    implemented (outside the specification).
    """

    MODES = ("lingora", "original", "martin")

    def __init__(self, mode="lingora"):
        if mode not in self.MODES:
            raise ValueError("unknown Porter mode %r" % (mode,))
        self._mode = mode

    def stem(self, word, to_lowercase=True):  # spec: N-000142, N-000143, N-000145, N-000146, N-000147, N-000148, N-000149, N-000150, N-000151, N-000152, N-000153, N-000154, N-000155, N-000156, N-000157, N-000158, N-000159, N-000160
        _check_word(word)
        lowered = word.lower() if to_lowercase else word
        if lowered in _PORTER_IRREGULAR:
            return _PORTER_IRREGULAR[lowered]
        if len(lowered) <= 2:
            return lowered
        return _porter_stem_word(lowered, lingora=(self._mode == "lingora"))


# ---------------------------------------------------------------------------
# Lancaster (Paice/Husk)
# ---------------------------------------------------------------------------

# Rule table of the Paice/Husk stemmer: reversed suffix letters, optional '*'
# (rule applies only to an intact word), digit = number of letters removed,
# letters to append, then '.' (stop) or '>' (continue).
# Reconstructed from the published table; see NOTES.md.
_LANCASTER_RULES = [
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>", "cn1t>", "dd1.", "dei3y>",
    "deec2ss.", "dee1.", "de2>", "dooh4>", "e1>", "feil1v.", "fi2>", "gni3>",
    "gai3y.", "ga2>", "gg1.", "ht*2.", "hsiug5ct.", "hsi3>", "i*1.", "i1y>",
    "ji1d.", "juf1s.", "ju1d.", "jo1d.", "jeh1r.", "jrev1t.", "jsim2t.",
    "jn1d.", "j1s.", "lbaifi6.", "lbai4y.", "lba3y.", "lbi3.", "lib2l>",
    "lc1.", "lufi4y.", "luf3y.", "lo2l>", "lii1y.", "mi2>", "mm1.", "mu*2.",
    "nois4j>", "noix4ct.", "nt1.", "rpi2>", "sis2.", "sei3y>", "si2>",
    "ssen4>", "ss0.", "suo3>", "su*2.", "s*1>", "tacilp4y.", "ta2>",
    "tnem4>", "tne3>", "tna3>", "tpir2b.", "tpro2b.", "tpec2iv.", "tulo2v.",
    "tsis0.", "tsi3>", "tt1.", "uqi3.", "vis3j>", "zi2>", "zy1s.",
]
_LANCASTER_RULE_RE = re.compile(r"([a-z]+)(\*?)(\d)([a-z]*)([.>])")
_LANCASTER_PARSED = [_LANCASTER_RULE_RE.fullmatch(rule).groups() for rule in _LANCASTER_RULES]


def _lancaster_acceptable(stem):
    """A remaining stem must have 2+ letters if it starts with a vowel, else 3+ letters with a vowel."""
    if not stem:
        return False
    if stem[0] in "aeiou":
        return len(stem) >= 2
    return len(stem) >= 3 and any(ch in "aeiouy" for ch in stem)


class LancasterStemmer(object):  # spec: N-000161, N-000162
    """Paice/Husk stemmer."""

    def stem(self, word):  # spec: N-000161, N-000162
        _check_word(word)
        word = word.lower()
        intact = True
        while True:
            applied = False
            for letters, star, digit, replacement, action in _LANCASTER_PARSED:
                suffix = letters[::-1]
                if not word.endswith(suffix):
                    continue
                if star and not intact:
                    continue
                remove = int(digit)
                stem = word[: len(word) - remove] if remove <= len(word) else None
                if stem is None or not _lancaster_acceptable(stem):
                    continue
                word = stem + replacement
                intact = False
                applied = True
                if action == ".":
                    return word
                break
            if not applied:
                return word


# ---------------------------------------------------------------------------
# Snowball (english = Porter2; porter = original Porter)
# ---------------------------------------------------------------------------

_P2_VOWELS = "aeiouy"
_P2_SPECIAL = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli",
    "only": "onli", "singly": "singl",
}
_P2_INVARIANT = {"sky", "news", "howe", "atlas", "cosmos", "bias", "andes"}
_P2_POST_1A = {"inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed"}
_P2_STEP2 = [
    ("tional", "tion"), ("enci", "ence"), ("anci", "ance"), ("abli", "able"),
    ("entli", "ent"), ("izer", "ize"), ("ization", "ize"), ("ational", "ate"),
    ("ation", "ate"), ("ator", "ate"), ("alism", "al"), ("aliti", "al"),
    ("alli", "al"), ("fulness", "ful"), ("ousli", "ous"), ("ousness", "ous"),
    ("iveness", "ive"), ("iviti", "ive"), ("biliti", "ble"), ("bliti", "ble"),
    ("ogi", "og"), ("fulli", "ful"), ("lessli", "less"), ("li", ""),
]
_P2_STEP3 = [
    ("ational", "ate"), ("tional", "tion"), ("alize", "al"), ("icate", "ic"),
    ("iciti", "ic"), ("ical", "ic"), ("ful", ""), ("ness", ""),
]
_P2_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment",
    "ent", "ism", "ate", "iti", "ous", "ive", "ize", "ion",
]


def _p2_region(word, start):
    for i in range(start + 1, len(word)):
        if word[i - 1] in _P2_VOWELS and word[i] not in _P2_VOWELS:
            return i + 1
    return len(word)


def _p2_regions(word):
    """R1 and R2 start indexes."""
    if word.startswith("gener") or word.startswith("arsen"):
        r1 = 5
    elif word.startswith("commun"):
        r1 = 6
    else:
        r1 = _p2_region(word, 0)
    r1 = min(r1, len(word))
    r2 = min(_p2_region(word, r1), len(word))
    return r1, r2


def _p2_ends_short_syllable(word):
    if len(word) == 2:
        return word[0] in _P2_VOWELS and word[1] not in _P2_VOWELS
    if len(word) >= 3:
        return (
            word[-3] not in _P2_VOWELS
            and word[-2] in _P2_VOWELS
            and word[-1] not in _P2_VOWELS
            and word[-1] not in "wxY"
        )
    return False


def _p2_is_short(word):
    r1, _ = _p2_regions(word)
    return _p2_ends_short_syllable(word) and r1 >= len(word)


def _p2_step0(word):
    for suffix in ("'s'", "'s", "'"):
        if word.endswith(suffix):
            return word[: -len(suffix)]
    return word


def _p2_step1a(word):
    if word.endswith("sses"):
        return word[:-2]
    if word.endswith(("ied", "ies")):
        # -ied/-ies become -i when preceded by more than one letter, else -ie
        return word[:-3] + ("i" if len(word) > 4 else "ie")
    if word.endswith(("us", "ss")):
        return word
    if word.endswith("s") and any(ch in _P2_VOWELS for ch in word[:-2]):
        return word[:-1]
    return word


def _p2_step1b(word):
    r1, _ = _p2_regions(word)
    if word.endswith(("eed", "eedly")):
        suffix = "eedly" if word.endswith("eedly") else "eed"
        if len(word) - len(suffix) >= r1:
            return word[: -len(suffix)] + "ee"
        return word
    for suffix in ("ingly", "edly", "ing", "ed"):
        if word.endswith(suffix):
            stem = word[: -len(suffix)]
            if not any(ch in _P2_VOWELS for ch in stem):
                return word
            if stem.endswith(("at", "bl", "iz")):
                return stem + "e"
            if len(stem) >= 2 and stem[-1] == stem[-2] and stem[-1] in "bdfgmnprt":
                return stem[:-1]
            if _p2_is_short(stem):
                return stem + "e"
            return stem
    return word


def _p2_step1c(word):
    if len(word) > 2 and word[-1] in "yY" and word[-2] not in _P2_VOWELS:
        return word[:-1] + "i"
    return word


def _p2_step2(word):
    r1, _ = _p2_regions(word)
    best = _longest_suffix(word, _P2_STEP2)
    if best is None:
        return word
    suffix, replacement = best
    if len(word) - len(suffix) < r1:
        return word
    if suffix == "ogi":
        if len(word) >= 4 and word[-4] == "l":
            return word[: -len(suffix)] + replacement
        return word
    if suffix == "li":
        if len(word) >= 3 and word[-3] in "cdeghkmnrt":
            return word[: -len(suffix)]
        return word
    return word[: -len(suffix)] + replacement


def _p2_step3(word):
    r1, r2 = _p2_regions(word)
    best = _longest_suffix(word, _P2_STEP3)
    if best is not None:
        suffix, replacement = best
        if len(word) - len(suffix) >= r1:
            return word[: -len(suffix)] + replacement
        return word
    if word.endswith("ative") and len(word) - 5 >= r2:
        return word[:-5]
    return word


def _p2_step4(word):
    _, r2 = _p2_regions(word)
    best = None
    for suffix in _P2_STEP4:
        if word.endswith(suffix) and (best is None or len(suffix) > len(best)):
            best = suffix
    if best is None or len(word) - len(best) < r2:
        return word
    if best == "ion":
        if len(word) >= 4 and word[-4] in "st":
            return word[:-3]
        return word
    return word[: -len(best)]


def _p2_step5(word):
    r1, r2 = _p2_regions(word)
    if word.endswith("e"):
        stem = word[:-1]
        if len(stem) >= r2 or (len(stem) >= r1 and not _p2_ends_short_syllable(stem)):
            return stem
        return word
    if word.endswith("ll") and len(word) - 1 >= r2:
        return word[:-1]
    return word


def _porter2(word):
    if len(word) <= 2 or word in _P2_INVARIANT:
        return word
    if word in _P2_SPECIAL:
        return _P2_SPECIAL[word]
    if word.startswith("'"):
        word = word[1:]
    # mark consonantal y as Y: initial y, and y after a vowel
    chars = list(word)
    if chars and chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in _P2_VOWELS:
            chars[i] = "Y"
    word = "".join(chars)

    word = _p2_step0(word)
    word = _p2_step1a(word)
    if word in _P2_POST_1A:
        return word.replace("Y", "y")
    word = _p2_step1b(word)
    word = _p2_step1c(word)
    word = _p2_step2(word)
    word = _p2_step3(word)
    word = _p2_step4(word)
    word = _p2_step5(word)
    return word.replace("Y", "y")


class ARLSTem(object):
    """Arabic light stemmer. Its stemming results are outside the specification."""

    def stem(self, word):
        raise NotImplementedError("ARLSTem stemming is outside this specification")


class ARLSTem2(object):
    """Arabic light stemmer, second variant. Outside the specification."""

    def stem(self, word):
        raise NotImplementedError("ARLSTem2 stemming is outside this specification")


class SnowballStemmer(object):  # spec: N-000141, N-000163, N-000164, N-000165, N-000137
    """Snowball stemmer. ``english`` is Porter2; ``porter`` is the original Porter algorithm."""

    LANGUAGES = SNOWBALL_LANGUAGES

    def __init__(self, language, ignore_stopwords=False):  # spec: N-000394, N-000395, N-000171, N-000172, N-000173
        if language not in SNOWBALL_LANGUAGES:
            raise ValueError("unsupported Snowball language %r" % (language,))
        self._language = language
        self._stopwords = None
        if ignore_stopwords:
            filename = data.find("corpora/stopwords/%s" % language)
            with open(filename, encoding="utf-8") as handle:
                self._stopwords = {line.strip() for line in handle if line.strip()}

    def stem(self, word):  # spec: N-000390, N-000391, N-000166, N-000167
        _check_word(word)
        lowered = word.lower()
        if self._stopwords is not None and lowered in self._stopwords:
            return lowered
        if self._language == "english":
            return _porter2(lowered)
        if self._language == "porter":
            return _porter_stem_word(lowered, lingora=False) if len(lowered) > 2 else lowered
        raise NotImplementedError(
            "Snowball stemming for %r is not implemented in this release" % self._language
        )


# ---------------------------------------------------------------------------
# Regular-expression stemmer
# ---------------------------------------------------------------------------

class RegexpStemmer(object):
    """Removes every match of the caller's pattern from the word."""

    def __init__(self, regexp):  # spec: N-000392
        if not isinstance(regexp, str):
            raise TypeError("regexp must be a str")
        self._pattern = re.compile(regexp)

    def stem(self, word):  # spec: N-000168, N-000169, N-000170
        _check_word(word)
        return self._pattern.sub("", word)


# ---------------------------------------------------------------------------
# WordNet lemmatizer (requires the packaged WordNet resource)
# ---------------------------------------------------------------------------

class WordNetLemmatizer(object):
    """Lemmatizer over the packaged WordNet exception lists.

    Construction raises :class:`lingora.data.ResourceNotFound` when WordNet is
    not visible. Only exception-list lookup is implemented; the other morphy
    rules are outside the specification.
    """

    def __init__(self):  # spec: N-000174, N-000175, N-000396
        self._directory = data.find("corpora/wordnet")
        self._exceptions = {}
        for pos in ("noun", "verb", "adj", "adv"):
            filename = os.path.join(self._directory, "%s.exc" % pos)
            if not os.path.isfile(filename):
                continue
            with open(filename, encoding="utf-8") as handle:
                for line in handle:
                    fields = line.split()
                    if len(fields) >= 2:
                        self._exceptions.setdefault(fields[0], fields[1])

    def lemmatize(self, word):  # spec: N-000396
        _check_word(word)
        return self._exceptions.get(word, word)
