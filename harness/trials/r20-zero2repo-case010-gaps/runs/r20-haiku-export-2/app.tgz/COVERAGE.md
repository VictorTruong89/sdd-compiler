# COVERAGE — checklist ids to implementation

Every id in `spec/CHECKLIST.md` ends in one of three states below: **implemented** (with the code
that satisfies it, by `# spec:` annotation where there is one, or by the module named for its pack),
**tested** (a test whose name carries the id), or **not done** (with the reason). Gaps and
assumptions are explained in NOTES.md (sections G1–G30 and C1–C5).

Counts: 452 implemented, 25 not done / partly done / satisfied by absence.

| Id | Pack | Status |
|---|---|---|
| N-000001 | 16 | implemented; annotated: lingora/__init__.py:8 |
| N-000002 | 16 | implemented; annotated: lingora/__init__.py:8 |
| N-000003 | 16 | implemented (no direct annotation): lingora/__init__.py; lingora/tokenize.py; lingora/stem.py; lingora/tag.py; lingora/chunk.py; lingora/classify.py; lingora/metrics.py |
| N-000004 | 16 | implemented; annotated: lingora/__init__.py:8 |
| N-000005 | 16 | implemented; annotated: lingora/__init__.py:10 |
| N-000006 | 16 | implemented (no direct annotation): lingora/__init__.py; lingora/tokenize.py; lingora/stem.py; lingora/tag.py; lingora/chunk.py; lingora/classify.py; lingora/metrics.py |
| N-000007 | 16 | implemented (no direct annotation): lingora/__init__.py; lingora/tokenize.py; lingora/stem.py; lingora/tag.py; lingora/chunk.py; lingora/classify.py; lingora/metrics.py |
| N-000008 | 16 | implemented (no direct annotation): lingora/__init__.py; lingora/tokenize.py; lingora/stem.py; lingora/tag.py; lingora/chunk.py; lingora/classify.py; lingora/metrics.py |
| N-000009 | 16 | implemented (no direct annotation): lingora/__init__.py; lingora/tokenize.py; lingora/stem.py; lingora/tag.py; lingora/chunk.py; lingora/classify.py; lingora/metrics.py |
| N-000010 | 16 | implemented (no direct annotation): lingora/__init__.py; lingora/tokenize.py; lingora/stem.py; lingora/tag.py; lingora/chunk.py; lingora/classify.py; lingora/metrics.py |
| N-000011 | 16 | implemented (no direct annotation): lingora/__init__.py; lingora/tokenize.py; lingora/stem.py; lingora/tag.py; lingora/chunk.py; lingora/classify.py; lingora/metrics.py |
| N-000012 | 16 | implemented; annotated: lingora/__init__.py:10 |
| N-000013 | 16 | implemented; annotated: lingora/__init__.py:12 |
| N-000014 | 16 | implemented; annotated: lingora/__init__.py:12 |
| N-000015 | 16 | implemented (no direct annotation): lingora/__init__.py; lingora/tokenize.py; lingora/stem.py; lingora/tag.py; lingora/chunk.py; lingora/classify.py; lingora/metrics.py |
| N-000016 | 16 | implemented; annotated: lingora/__init__.py:12 |
| N-000017 | 16 | implemented; annotated: lingora/__init__.py:15 |
| N-000018 | 16 | implemented; annotated: lingora/__init__.py:15 |
| N-000019 | 16 | implemented; annotated: lingora/__init__.py:15 |
| N-000020 | 16 | implemented; annotated: lingora/__init__.py:17 |
| N-000021 | 17 | implemented (no direct annotation): lingora/stem.py (stem need not be a word); lingora/tag.py (backoff); lingora/chunk.py; lingora/_punkt.py |
| N-000022 | 17 | implemented (no direct annotation): lingora/stem.py (stem need not be a word); lingora/tag.py (backoff); lingora/chunk.py; lingora/_punkt.py |
| N-000023 | 17 | implemented (no direct annotation): lingora/stem.py (stem need not be a word); lingora/tag.py (backoff); lingora/chunk.py; lingora/_punkt.py |
| N-000024 | 17 | implemented (no direct annotation): lingora/stem.py (stem need not be a word); lingora/tag.py (backoff); lingora/chunk.py; lingora/_punkt.py |
| N-000025 | 17 | implemented (no direct annotation): lingora/stem.py (stem need not be a word); lingora/tag.py (backoff); lingora/chunk.py; lingora/_punkt.py |
| N-000026 | 18 | implemented (no direct annotation): lingora/__init__.py; the module named by each feature point |
| N-000027 | 18 | implemented (no direct annotation): lingora/__init__.py; the module named by each feature point |
| N-000028 | 18 | not done: s-expression tokenizer is outside this specification (Pack 22, Pack 29) |
| N-000029 | 18 | implemented (no direct annotation): lingora/__init__.py; the module named by each feature point |
| N-000030 | 18 | implemented (no direct annotation): lingora/__init__.py; the module named by each feature point |
| N-000031 | 18 | implemented (no direct annotation): lingora/__init__.py; the module named by each feature point |
| N-000032 | 18 | implemented (no direct annotation): lingora/__init__.py; the module named by each feature point |
| N-000033 | 18 | implemented (no direct annotation): lingora/__init__.py; the module named by each feature point |
| N-000034 | 18 | implemented (no direct annotation): lingora/__init__.py; the module named by each feature point |
| N-000035 | 18 | implemented (no direct annotation): lingora/__init__.py; the module named by each feature point |
| N-000036 | 18 | partly: named-entity chunker is resource-gated only; its results are outside the spec (G17) |
| N-000037 | 18 | implemented (no direct annotation): lingora/__init__.py; the module named by each feature point |
| N-000038 | 18 | implemented (no direct annotation): lingora/__init__.py; the module named by each feature point |
| N-000039 | 18 | implemented (no direct annotation): lingora/__init__.py; the module named by each feature point |
| N-000040 | 18 | implemented (no direct annotation): lingora/__init__.py; the module named by each feature point |
| N-000041 | 18 | implemented (no direct annotation): lingora/__init__.py; the module named by each feature point |
| N-000042 | 18 | implemented (no direct annotation): lingora/__init__.py; the module named by each feature point |
| N-000043 | 18 | implemented (no direct annotation): lingora/__init__.py; the module named by each feature point |
| N-000044 | 18 | implemented (no direct annotation): lingora/__init__.py; the module named by each feature point |
| N-000045 | 19 | implemented; annotated: lingora/__init__.py:23 |
| N-000046 | 19 | implemented; annotated: lingora/__init__.py:23 |
| N-000047 | 19 | implemented (no direct annotation): pyproject.toml; lingora/__init__.py; lingora/data.py; lingora/tokenize.py (no model needed for the baseline) |
| N-000048 | 19 | implemented; annotated: lingora/__init__.py:23 |
| N-000049 | 19 | implemented; annotated: lingora/__init__.py:23 |
| N-000050 | 19 | not done: optional extra groups (MAY); no optional dependencies are provided |
| N-000051 | 19 | implemented (no direct annotation): pyproject.toml; lingora/__init__.py; lingora/data.py; lingora/tokenize.py (no model needed for the baseline) |
| N-000052 | 19 | implemented; annotated: lingora/__init__.py:23 |
| N-000053 | 19 | implemented; annotated: lingora/__init__.py:23 |
| N-000054 | 19 | implemented; annotated: lingora/__init__.py:23 |
| N-000055 | 19 | implemented (no direct annotation): pyproject.toml; lingora/__init__.py; lingora/data.py; lingora/tokenize.py (no model needed for the baseline) |
| N-000056 | 19 | implemented (no direct annotation): pyproject.toml; lingora/__init__.py; lingora/data.py; lingora/tokenize.py (no model needed for the baseline) |
| N-000057 | 19 | not done: the downloader is outside this specification (Pack 29); only the data finder is implemented |
| N-000058 | 19 | implemented (no direct annotation): pyproject.toml; lingora/__init__.py; lingora/data.py; lingora/tokenize.py (no model needed for the baseline) |
| N-000059 | 19 | implemented (no direct annotation): pyproject.toml; lingora/__init__.py; lingora/data.py; lingora/tokenize.py (no model needed for the baseline) |
| N-000060 | 19 | implemented (no direct annotation): pyproject.toml; lingora/__init__.py; lingora/data.py; lingora/tokenize.py (no model needed for the baseline) |
| N-000061 | 19 | implemented (no direct annotation): pyproject.toml; lingora/__init__.py; lingora/data.py; lingora/tokenize.py (no model needed for the baseline) |
| N-000062 | 19 | implemented (no direct annotation): pyproject.toml; lingora/__init__.py; lingora/data.py; lingora/tokenize.py (no model needed for the baseline) |
| N-000063 | 19 | implemented (no direct annotation): pyproject.toml; lingora/__init__.py; lingora/data.py; lingora/tokenize.py (no model needed for the baseline) |
| N-000064 | 19 | implemented (no direct annotation): pyproject.toml; lingora/__init__.py; lingora/data.py; lingora/tokenize.py (no model needed for the baseline) |
| N-000065 | 20 | implemented; annotated: lingora/__init__.py:17 |
| N-000066 | 20 | implemented; annotated: lingora/__init__.py:17 |
| N-000067 | 20 | implemented; annotated: lingora/__init__.py:17 |
| N-000068 | 21 | satisfied by absence: non-goal (general-purpose regex engine, ML framework, theorem prover) |
| N-000069 | 21 | satisfied by absence: non-goal (corpora are not shipped in the source tree) |
| N-000070 | 21 | satisfied by absence: non-goal (corpora are not shipped in the source tree) |
| N-000071 | 21 | satisfied by absence: non-goal (graphical applications) |
| N-000072 | 21 | satisfied by absence: non-goal (chat, Twitter, HF, Toolbox helpers) |
| N-000073 | 21 | satisfied by absence: non-goal (external-binary wrappers) |
| N-000074 | 21 | satisfied by absence: non-goal (CCG, DRT, inference) |
| N-000075 | 21 | satisfied by absence: non-goal (N-gram language-model training) |
| N-000076 | 21 | satisfied by absence: non-goal (throughput guarantee is not made) |
| N-000077 | 22 | implemented (no direct annotation): lingora/tokenize.py; lingora/cli.py |
| N-000078 | 22 | implemented (no direct annotation): lingora/tokenize.py; lingora/cli.py |
| N-000079 | 22 | implemented (no direct annotation): lingora/tokenize.py; lingora/cli.py |
| N-000080 | 22 | implemented (no direct annotation): lingora/tokenize.py; lingora/cli.py |
| N-000081 | 22 | implemented (no direct annotation): lingora/tokenize.py; lingora/cli.py |
| N-000082 | 22 | implemented; annotated: lingora/tokenize.py:136; tested: tests/test_tokenize.py::test_N_000082_word_tokenize_preserve_line_needs_no_model |
| N-000083 | 22 | implemented; annotated: lingora/tokenize.py:136 |
| N-000084 | 22 | implemented; annotated: lingora/tokenize.py:136 |
| N-000085 | 22 | implemented; annotated: lingora/tokenize.py:34, lingora/tokenize.py:40; tested: tests/test_tokenize.py::test_N_000085_wordpunct_runs_of_word_and_punct |
| N-000086 | 22 | implemented; annotated: lingora/tokenize.py:34, lingora/tokenize.py:40 |
| N-000087 | 22 | implemented; annotated: lingora/tokenize.py:34, lingora/tokenize.py:40 |
| N-000088 | 22 | implemented; annotated: lingora/tokenize.py:127; tested: tests/test_tokenize.py::test_N_000088_penn_quotes_and_punctuation |
| N-000089 | 22 | implemented; annotated: lingora/tokenize.py:127, lingora/tokenize.py:93 |
| N-000090 | 22 | implemented; annotated: lingora/tokenize.py:127, lingora/tokenize.py:93 |
| N-000091 | 22 | implemented; annotated: lingora/tokenize.py:93 |
| N-000092 | 22 | implemented; annotated: lingora/tokenize.py:93 |
| N-000093 | 22 | implemented; annotated: lingora/tokenize.py:127, lingora/tokenize.py:93; tested: tests/test_tokenize.py::test_N_000093_penn_single_punct_marks_are_tokens |
| N-000094 | 22 | implemented; annotated: lingora/tokenize.py:127, lingora/tokenize.py:93 |
| N-000095 | 22 | implemented; annotated: lingora/tokenize.py:127, lingora/tokenize.py:93; tested: tests/test_tokenize.py::test_N_000095_point_split_only_at_end_of_text |
| N-000096 | 22 | implemented; annotated: lingora/tokenize.py:127, lingora/tokenize.py:93; tested: tests/test_tokenize.py::test_N_000096_clitics_split |
| N-000097 | 22 | implemented; annotated: lingora/tokenize.py:127, lingora/tokenize.py:93; tested: tests/test_tokenize.py::test_N_000097_fused_forms_split |
| N-000098 | 22 | implemented; annotated: lingora/tokenize.py:127, lingora/tokenize.py:93; tested: tests/test_tokenize.py::test_N_000098_apostrophe_inside_word_stays |
| N-000099 | 22 | implemented; annotated: lingora/tokenize.py:145; tested: tests/test_tokenize.py::test_N_000099_recommended_extra_splits_recommended_only |
| N-000100 | 22 | implemented; annotated: lingora/tokenize.py:145 |
| N-000101 | 22 | implemented; annotated: lingora/tokenize.py:145 |
| N-000102 | 22 | implemented; annotated: lingora/tokenize.py:145 |
| N-000103 | 22 | implemented; annotated: lingora/tokenize.py:145 |
| N-000104 | 22 | implemented; annotated: lingora/tokenize.py:148; tested: tests/test_tokenize.py::test_N_000104_word_tokenize_splits_sentences_first |
| N-000105 | 22 | implemented; annotated: lingora/tokenize.py:148 |
| N-000106 | 22 | implemented; annotated: lingora/tokenize.py:167; tested: tests/test_tokenize.py::test_N_000106_whitespace_tokens |
| N-000107 | 22 | implemented; annotated: lingora/tokenize.py:168, lingora/tokenize.py:184 |
| N-000108 | 22 | implemented; annotated: lingora/tokenize.py:181, lingora/tokenize.py:184; tested: tests/test_tokenize.py::test_N_000108_blankline_segments |
| N-000109 | 22 | implemented; annotated: lingora/tokenize.py:198; tested: tests/test_tokenize.py::test_N_000109_regexp_token_mode_and_gap_mode |
| N-000110 | 22 | implemented; annotated: lingora/tokenize.py:198 |
| N-000111 | 22 | implemented; annotated: lingora/tokenize.py:198 |
| N-000112 | 22 | implemented; annotated: lingora/tokenize.py:250; tested: tests/test_tokenize.py::test_N_000112_tweet_contractions_urls_handles_hashtags |
| N-000113 | 22 | implemented; annotated: lingora/tokenize.py:250 |
| N-000114 | 22 | implemented; annotated: lingora/tokenize.py:250 |
| N-000115 | 22 | implemented; annotated: lingora/tokenize.py:250 |
| N-000116 | 22 | implemented; annotated: lingora/tokenize.py:237; tested: tests/test_tokenize.py::test_N_000116_tweet_handle_needs_non_word_before_at, tests/test_tokenize.py::test_N_000116_tweet_strip_handles_and_reduce_length |
| N-000117 | 22 | implemented; annotated: lingora/tokenize.py:238 |
| N-000118 | 22 | implemented; annotated: lingora/tokenize.py:250 |
| N-000119 | 22 | implemented; annotated: lingora/tokenize.py:44; tested: tests/test_tokenize.py::test_N_000119_regexp_spans, tests/test_tokenize.py::test_N_000119_spans_are_ordered_and_non_overlapping |
| N-000120 | 22 | implemented; annotated: lingora/tokenize.py:44 |
| N-000121 | 22 | implemented; annotated: lingora/tokenize.py:44 |
| N-000122 | 22 | implemented; annotated: lingora/tokenize.py:160; tested: tests/test_tokenize.py::test_N_000122_sentence_splitting_with_punkt |
| N-000123 | 22 | implemented; annotated: lingora/tokenize.py:160 |
| N-000124 | 22 | implemented; annotated: lingora/tokenize.py:160 |
| N-000125 | 22 | implemented; annotated: lingora/tokenize.py:160 |
| N-000126 | 22 | implemented; annotated: lingora/tokenize.py:160 |
| N-000127 | 22 | implemented; annotated: lingora/cli.py:51 |
| N-000128 | 22 | implemented; annotated: lingora/cli.py:51 |
| N-000129 | 22 | implemented; annotated: lingora/tokenize.py:40; tested: tests/test_tokenize.py::test_N_000129_empty_and_whitespace_strings_give_no_tokens |
| N-000130 | 22 | implemented; annotated: lingora/tokenize.py:156 |
| N-000131 | 22 | implemented; annotated: lingora/tokenize.py:156; tested: tests/test_tokenize.py::test_N_000131_missing_punkt_model_raises |
| N-000132 | 22 | implemented; annotated: lingora/cli.py:51 |
| N-000133 | 23 | implemented (no direct annotation): lingora/stem.py |
| N-000134 | 23 | implemented (no direct annotation): lingora/stem.py |
| N-000135 | 23 | implemented (no direct annotation): lingora/stem.py |
| N-000136 | 23 | not done: ISRI, Cistem and RSLP are not in the Interface and are not implemented (C4); ARLSTem/ARLSTem2 raise NotImplementedError (G13) |
| N-000137 | 23 | not done: ISRI, Cistem, RSLP and the WordNet lemmatizer's stemming results are outside this specification (C4, G16) |
| N-000138 | 23 | not done: RSLP not implemented (C4); WordNet lemmatizer is exception-list lookup only (G16) |
| N-000139 | 23 | implemented (no direct annotation): lingora/stem.py |
| N-000140 | 23 | implemented; annotated: lingora/stem.py:33 |
| N-000141 | 23 | implemented; annotated: lingora/stem.py:551 |
| N-000142 | 23 | implemented; annotated: lingora/stem.py:245, lingora/stem.py:261 |
| N-000143 | 23 | implemented; annotated: lingora/stem.py:261 |
| N-000144 | 23 | implemented; annotated: lingora/stem.py:245 |
| N-000145 | 23 | implemented; annotated: lingora/stem.py:261; tested: tests/test_stem_tag.py::test_N_000145_porter_lingora_irregular_table, tests/test_stem_tag.py::test_N_000145_porter_original_algorithm |
| N-000146 | 23 | implemented; annotated: lingora/stem.py:261; tested: tests/test_stem_tag.py::test_N_000146_porter_lowercases_unless_turned_off |
| N-000147 | 23 | implemented; annotated: lingora/stem.py:261 |
| N-000148 | 23 | implemented; annotated: lingora/stem.py:261; tested: tests/test_stem_tag.py::test_N_000148_porter_short_words_returned_as_is |
| N-000149 | 23 | implemented; annotated: lingora/stem.py:261 |
| N-000150 | 23 | implemented; annotated: lingora/stem.py:261; tested: tests/test_stem_tag.py::test_N_000150_porter_lingora_four_letter_ies_becomes_ie |
| N-000151 | 23 | implemented; annotated: lingora/stem.py:261; tested: tests/test_stem_tag.py::test_N_000151_porter_lingora_ied_handling |
| N-000152 | 23 | implemented; annotated: lingora/stem.py:261 |
| N-000153 | 23 | implemented; annotated: lingora/stem.py:261 |
| N-000154 | 23 | implemented; annotated: lingora/stem.py:261 |
| N-000155 | 23 | implemented; annotated: lingora/stem.py:261; tested: tests/test_stem_tag.py::test_N_000155_porter_lingora_bli_and_logi_extensions |
| N-000156 | 23 | implemented; annotated: lingora/stem.py:261 |
| N-000157 | 23 | implemented; annotated: lingora/stem.py:261 |
| N-000158 | 23 | implemented; annotated: lingora/stem.py:261 |
| N-000159 | 23 | implemented; annotated: lingora/stem.py:261 |
| N-000160 | 23 | implemented; annotated: lingora/stem.py:261 |
| N-000161 | 23 | implemented; annotated: lingora/stem.py:304, lingora/stem.py:307 |
| N-000162 | 23 | implemented; annotated: lingora/stem.py:304, lingora/stem.py:307 |
| N-000163 | 23 | implemented; annotated: lingora/stem.py:551; tested: tests/test_stem_tag.py::test_N_000163_snowball_english_is_porter2 |
| N-000164 | 23 | not done: Dutch Snowball is not implemented (G13) |
| N-000165 | 23 | implemented; annotated: lingora/stem.py:551 |
| N-000166 | 23 | implemented; annotated: lingora/stem.py:566 |
| N-000167 | 23 | implemented; annotated: lingora/stem.py:566; tested: tests/test_stem_tag.py::test_N_000167_snowball_stopword_returned_lowercased |
| N-000168 | 23 | implemented; annotated: lingora/stem.py:592 |
| N-000169 | 23 | implemented; annotated: lingora/stem.py:592 |
| N-000170 | 23 | implemented; annotated: lingora/stem.py:592; tested: tests/test_stem_tag.py::test_N_000170_regexp_stemmer_removes_matches_only |
| N-000171 | 23 | implemented; annotated: lingora/stem.py:556 |
| N-000172 | 23 | implemented; annotated: lingora/stem.py:556 |
| N-000173 | 23 | implemented; annotated: lingora/stem.py:556 |
| N-000174 | 23 | implemented; annotated: lingora/stem.py:609; tested: tests/test_stem_tag.py::test_N_000174_wordnet_missing_raises |
| N-000175 | 23 | implemented; annotated: lingora/stem.py:609 |
| N-000176 | 24 | partly: default, unigram and regexp taggers implemented; bigram, trigram and affix taggers not implemented (Pack 24 puts their results outside the spec) |
| N-000177 | 24 | not done: bigram, trigram and affix taggers are outside the specified results (Pack 24) |
| N-000178 | 24 | implemented (no direct annotation): lingora/tag.py; lingora/_perceptron.py |
| N-000179 | 24 | implemented; annotated: lingora/tag.py:117 |
| N-000180 | 24 | implemented; annotated: lingora/tag.py:117 |
| N-000181 | 24 | implemented; annotated: lingora/tag.py:117 |
| N-000182 | 24 | implemented; annotated: lingora/tag.py:117 |
| N-000183 | 24 | implemented; annotated: lingora/tag.py:117 |
| N-000184 | 24 | implemented; annotated: lingora/tag.py:117 |
| N-000185 | 24 | implemented; annotated: lingora/tag.py:41 |
| N-000186 | 24 | implemented; annotated: lingora/tag.py:41 |
| N-000187 | 24 | implemented; annotated: lingora/tag.py:56; tested: tests/test_stem_tag.py::test_N_000187_default_tagger_assigns_one_tag |
| N-000188 | 24 | implemented; annotated: lingora/tag.py:67 |
| N-000189 | 24 | implemented; annotated: lingora/tag.py:67; tested: tests/test_stem_tag.py::test_N_000189_unigram_most_frequent_tag_and_unseen_word_untagged |
| N-000190 | 24 | implemented; annotated: lingora/tag.py:67 |
| N-000191 | 24 | implemented; annotated: lingora/tag.py:94; tested: tests/test_stem_tag.py::test_N_000191_regexp_tagger_first_rule_at_token_start |
| N-000192 | 24 | implemented; annotated: lingora/tag.py:94 |
| N-000193 | 24 | implemented; annotated: lingora/tag.py:94 |
| N-000194 | 24 | implemented; annotated: lingora/tag.py:41 |
| N-000195 | 24 | implemented; annotated: lingora/tag.py:41; tested: tests/test_stem_tag.py::test_N_000195_backoff_only_for_untagged_tokens |
| N-000196 | 24 | implemented; annotated: lingora/tag.py:117; tested: tests/test_stem_tag.py::test_N_000196_pos_tag_english_native_and_universal |
| N-000197 | 24 | implemented; annotated: lingora/tag.py:120 |
| N-000198 | 24 | implemented; annotated: lingora/tag.py:120 |
| N-000199 | 24 | implemented; annotated: lingora/tag.py:120 |
| N-000200 | 24 | implemented; annotated: lingora/tag.py:120 |
| N-000201 | 24 | implemented; annotated: lingora/tag.py:120 |
| N-000202 | 24 | implemented; annotated: lingora/tag.py:117, lingora/tag.py:120 |
| N-000203 | 24 | implemented; annotated: lingora/tag.py:117, lingora/tag.py:120 |
| N-000204 | 24 | implemented; annotated: lingora/tag.py:117, lingora/tag.py:120 |
| N-000205 | 24 | implemented; annotated: lingora/tag.py:117, lingora/tag.py:120 |
| N-000206 | 24 | implemented; annotated: lingora/tag.py:117, lingora/tag.py:120 |
| N-000207 | 24 | implemented; annotated: lingora/tag.py:117, lingora/tag.py:120 |
| N-000208 | 24 | implemented; annotated: lingora/tag.py:120; tested: tests/test_stem_tag.py::test_N_000208_pos_tag_refuses_untokenized_string |
| N-000209 | 24 | implemented; annotated: lingora/tag.py:120 |
| N-000210 | 24 | implemented; annotated: lingora/tag.py:120 |
| N-000211 | 24 | implemented; annotated: lingora/tag.py:120; tested: tests/test_stem_tag.py::test_N_000211_pos_tag_only_english_and_russian |
| N-000212 | 24 | implemented; annotated: lingora/tag.py:120 |
| N-000213 | 24 | implemented; annotated: lingora/tag.py:120; tested: tests/test_stem_tag.py::test_N_000213_pos_tag_missing_resource_raises |
| N-000214 | 24 | implemented; annotated: lingora/tag.py:120 |
| N-000215 | 24 | implemented; annotated: lingora/tag.py:120 |
| N-000216 | 24 | implemented; annotated: lingora/tag.py:120 |
| N-000217 | 25 | implemented; annotated: lingora/chunk.py:21; tested: tests/test_structures.py::test_N_000217_grammar_pattern_line_must_be_indented |
| N-000218 | 25 | implemented; annotated: lingora/chunk.py:251 |
| N-000219 | 25 | implemented; annotated: lingora/chunk.py:268 |
| N-000220 | 25 | implemented (no direct annotation): lingora/chunk.py |
| N-000221 | 25 | implemented; annotated: lingora/chunk.py:251; tested: tests/test_structures.py::test_N_000221_quantifier_braces_in_chunk_pattern |
| N-000222 | 25 | implemented; annotated: lingora/chunk.py:251 |
| N-000223 | 25 | implemented; annotated: lingora/chunk.py:251; tested: tests/test_structures.py::test_N_000223_chunk_rule_longest_match_and_root_label |
| N-000224 | 25 | implemented; annotated: lingora/chunk.py:251 |
| N-000225 | 25 | implemented; annotated: lingora/chunk.py:251 |
| N-000226 | 25 | implemented; annotated: lingora/chunk.py:251 |
| N-000227 | 25 | implemented; annotated: lingora/chunk.py:251; tested: tests/test_structures.py::test_N_000227_chink_splits_chunk_and_chinked_tokens_go_to_root |
| N-000228 | 25 | implemented; annotated: lingora/chunk.py:251 |
| N-000229 | 25 | implemented; annotated: lingora/chunk.py:251 |
| N-000230 | 25 | implemented; annotated: lingora/chunk.py:251; tested: tests/test_structures.py::test_N_000230_clauses_cascade_over_earlier_chunks |
| N-000231 | 25 | implemented; annotated: lingora/chunk.py:251 |
| N-000232 | 25 | implemented (no direct annotation): lingora/chunk.py |
| N-000233 | 25 | implemented; annotated: lingora/chunk.py:251 |
| N-000234 | 25 | implemented; annotated: lingora/chunk.py:251 |
| N-000235 | 25 | implemented; annotated: lingora/chunk.py:251 |
| N-000236 | 25 | implemented; annotated: lingora/chunk.py:268 |
| N-000237 | 26 | not done: recursive-descent parser is outside this specification (Pack 26) |
| N-000238 | 26 | implemented; annotated: lingora/grammar.py:107 |
| N-000239 | 26 | implemented; annotated: lingora/grammar.py:107 |
| N-000240 | 26 | implemented; annotated: lingora/grammar.py:102 |
| N-000241 | 26 | implemented; annotated: lingora/grammar.py:123 |
| N-000242 | 26 | implemented; annotated: lingora/parse/__init__.py:38; tested: tests/test_structures.py::test_N_000242_chart_parser_ambiguity_gives_several_trees |
| N-000243 | 26 | implemented; annotated: lingora/parse/__init__.py:38 |
| N-000244 | 26 | implemented; annotated: lingora/parse/__init__.py:38 |
| N-000245 | 26 | implemented; annotated: lingora/parse/__init__.py:38 |
| N-000246 | 26 | implemented; annotated: lingora/parse/__init__.py:38 |
| N-000247 | 26 | implemented; annotated: lingora/parse/__init__.py:97; tested: tests/test_structures.py::test_N_000247_shift_reduce_matches_chart_on_unambiguous_sentence |
| N-000248 | 26 | implemented; annotated: lingora/parse/__init__.py:97 |
| N-000249 | 26 | implemented; annotated: lingora/parse/__init__.py:97 |
| N-000250 | 26 | implemented; annotated: lingora/parse/__init__.py:97 |
| N-000251 | 26 | implemented; annotated: lingora/parse/generate.py:24; tested: tests/test_structures.py::test_N_000251_generate_bounded_by_count_and_depth |
| N-000252 | 26 | implemented; annotated: lingora/parse/generate.py:24 |
| N-000253 | 26 | implemented; annotated: lingora/parse/generate.py:24 |
| N-000254 | 26 | implemented; annotated: lingora/parse/generate.py:24 |
| N-000255 | 26 | implemented; annotated: lingora/parse/generate.py:24; tested: tests/test_structures.py::test_N_000255_empty_production_contributes_no_token_and_empty_string_terminal_does |
| N-000256 | 26 | implemented; annotated: lingora/grammar.py:107 |
| N-000257 | 26 | implemented; annotated: lingora/tree.py:15 |
| N-000258 | 26 | implemented (no direct annotation): lingora/grammar.py; lingora/parse/; lingora/tree.py |
| N-000259 | 26 | implemented; annotated: lingora/tree.py:15 |
| N-000260 | 26 | implemented; annotated: lingora/tree.py:55 |
| N-000261 | 26 | implemented; annotated: lingora/tree.py:99; tested: tests/test_structures.py::test_N_000261_pformat_shows_every_label_and_leaf_in_order |
| N-000262 | 26 | implemented; tested: tests/test_structures.py::test_N_000262_tree_refusals_and_empty_children |
| N-000263 | 26 | implemented (no direct annotation): lingora/grammar.py; lingora/parse/; lingora/tree.py |
| N-000264 | 26 | implemented (no direct annotation): lingora/grammar.py; lingora/parse/; lingora/tree.py |
| N-000265 | 26 | implemented (no direct annotation): lingora/grammar.py; lingora/parse/; lingora/tree.py |
| N-000266 | 26 | implemented (no direct annotation): lingora/grammar.py; lingora/parse/; lingora/tree.py |
| N-000267 | 26 | implemented (no direct annotation): lingora/grammar.py; lingora/parse/; lingora/tree.py |
| N-000268 | 26 | implemented (no direct annotation): lingora/grammar.py; lingora/parse/; lingora/tree.py |
| N-000269 | 27 | implemented; annotated: lingora/classify.py:48 |
| N-000270 | 27 | implemented; annotated: lingora/classify.py:48 |
| N-000271 | 27 | implemented; annotated: lingora/classify.py:48 |
| N-000272 | 27 | implemented; annotated: lingora/classify.py:48 |
| N-000273 | 27 | implemented; annotated: lingora/classify.py:48 |
| N-000274 | 27 | implemented; annotated: lingora/classify.py:48 |
| N-000275 | 27 | implemented; annotated: lingora/classify.py:48 |
| N-000276 | 27 | implemented; annotated: lingora/classify.py:48 |
| N-000277 | 27 | implemented; annotated: lingora/classify.py:59 |
| N-000278 | 27 | implemented; annotated: lingora/classify.py:59 |
| N-000279 | 27 | implemented; annotated: lingora/classify.py:105, lingora/classify.py:85; tested: tests/test_structures.py::test_N_000279_naive_bayes_label_and_distribution |
| N-000280 | 27 | implemented; annotated: lingora/classify.py:85 |
| N-000281 | 27 | implemented; annotated: lingora/classify.py:85 |
| N-000282 | 27 | implemented; annotated: lingora/classify.py:59 |
| N-000283 | 27 | implemented; annotated: lingora/classify.py:168; tested: tests/test_structures.py::test_N_000283_decision_tree_classifies_training_data_and_defaults |
| N-000284 | 27 | implemented; annotated: lingora/classify.py:168 |
| N-000285 | 27 | implemented; annotated: lingora/classify.py:168 |
| N-000286 | 27 | implemented; annotated: lingora/classify.py:168 |
| N-000287 | 27 | implemented; annotated: lingora/classify.py:168, lingora/classify.py:180 |
| N-000288 | 27 | implemented; annotated: lingora/classify.py:193; tested: tests/test_structures.py::test_N_000288_accuracy_fraction_of_gold_pairs |
| N-000289 | 28 | implemented (no direct annotation): lingora/metrics.py |
| N-000290 | 28 | implemented (no direct annotation): lingora/metrics.py |
| N-000291 | 28 | implemented (no direct annotation): lingora/metrics.py |
| N-000292 | 28 | implemented; annotated: lingora/metrics.py:38; tested: tests/test_structures.py::test_N_000292_edit_distance_costs_and_transpositions |
| N-000293 | 28 | implemented; annotated: lingora/metrics.py:38 |
| N-000294 | 28 | implemented; annotated: lingora/metrics.py:38 |
| N-000295 | 28 | implemented; annotated: lingora/metrics.py:38 |
| N-000296 | 28 | implemented; annotated: lingora/metrics.py:38 |
| N-000297 | 28 | implemented; annotated: lingora/metrics.py:38 |
| N-000298 | 28 | implemented; annotated: lingora/metrics.py:38 |
| N-000299 | 28 | implemented; annotated: lingora/metrics.py:38 |
| N-000300 | 28 | implemented; annotated: lingora/metrics.py:127 |
| N-000301 | 28 | implemented; annotated: lingora/metrics.py:127 |
| N-000302 | 28 | implemented; annotated: lingora/translate.py:41; tested: tests/test_structures.py::test_N_000302_bleu_perfect_zero_and_smoothing |
| N-000303 | 28 | implemented; annotated: lingora/translate.py:41 |
| N-000304 | 28 | implemented; annotated: lingora/translate.py:41 |
| N-000305 | 28 | implemented; annotated: lingora/translate.py:41 |
| N-000306 | 28 | implemented; annotated: lingora/translate.py:41 |
| N-000307 | 28 | implemented; annotated: lingora/translate.py:41 |
| N-000308 | 28 | implemented; annotated: lingora/translate.py:41 |
| N-000309 | 28 | implemented; annotated: lingora/translate.py:41 |
| N-000310 | 28 | implemented; annotated: lingora/metrics.py:26 |
| N-000311 | 28 | implemented; annotated: lingora/metrics.py:111 |
| N-000312 | 28 | implemented; annotated: lingora/metrics.py:111 |
| N-000313 | 28 | implemented; annotated: lingora/metrics.py:111 |
| N-000314 | 28 | implemented; annotated: lingora/metrics.py:111 |
| N-000315 | 28 | implemented; annotated: lingora/metrics.py:38 |
| N-000316 | 29 | not done: outside this specification (Pack 29): corpora, WordNet, data finder beyond locating models, downloader |
| N-000317 | 29 | not done: outside this specification (Pack 29): graphical applications and drawing |
| N-000318 | 29 | not done: outside this specification (Pack 29): chat, Twitter, Hugging Face and Toolbox helpers |
| N-000319 | 29 | not done: outside this specification (Pack 29): external-binary wrappers |
| N-000320 | 02 | implemented (no direct annotation): lingora/__init__.py; pyproject.toml (pure Python, no compiled code, no dependencies) |
| N-000321 | 02 | implemented (no direct annotation): lingora/__init__.py; pyproject.toml (pure Python, no compiled code, no dependencies) |
| N-000322 | 02 | implemented (no direct annotation): lingora/__init__.py; pyproject.toml (pure Python, no compiled code, no dependencies) |
| N-000323 | 02 | implemented (no direct annotation): lingora/__init__.py; pyproject.toml (pure Python, no compiled code, no dependencies) |
| N-000324 | 03 | implemented (no direct annotation): pyproject.toml (flat layout, stdlib only); lingora/data.py; lingora/tokenize.py (runs with no model) |
| N-000325 | 03 | implemented (no direct annotation): pyproject.toml (flat layout, stdlib only); lingora/data.py; lingora/tokenize.py (runs with no model) |
| N-000326 | 03 | implemented (no direct annotation): pyproject.toml (flat layout, stdlib only); lingora/data.py; lingora/tokenize.py (runs with no model) |
| N-000327 | 03 | implemented (no direct annotation): pyproject.toml (flat layout, stdlib only); lingora/data.py; lingora/tokenize.py (runs with no model) |
| N-000328 | 03 | implemented (no direct annotation): pyproject.toml (flat layout, stdlib only); lingora/data.py; lingora/tokenize.py (runs with no model) |
| N-000329 | 03 | implemented (no direct annotation): pyproject.toml (flat layout, stdlib only); lingora/data.py; lingora/tokenize.py (runs with no model) |
| N-000330 | 03 | implemented (no direct annotation): pyproject.toml (flat layout, stdlib only); lingora/data.py; lingora/tokenize.py (runs with no model) |
| N-000331 | 03 | implemented (no direct annotation): pyproject.toml (flat layout, stdlib only); lingora/data.py; lingora/tokenize.py (runs with no model) |
| N-000332 | 03 | implemented (no direct annotation): pyproject.toml (flat layout, stdlib only); lingora/data.py; lingora/tokenize.py (runs with no model) |
| N-000333 | 03 | implemented (no direct annotation): pyproject.toml (flat layout, stdlib only); lingora/data.py; lingora/tokenize.py (runs with no model) |
| N-000334 | 03 | implemented (no direct annotation): pyproject.toml (flat layout, stdlib only); lingora/data.py; lingora/tokenize.py (runs with no model) |
| N-000335 | 03 | implemented (no direct annotation): pyproject.toml (flat layout, stdlib only); lingora/data.py; lingora/tokenize.py (runs with no model) |
| N-000336 | 03 | implemented (no direct annotation): pyproject.toml (flat layout, stdlib only); lingora/data.py; lingora/tokenize.py (runs with no model) |
| N-000337 | 03 | implemented (no direct annotation): pyproject.toml (flat layout, stdlib only); lingora/data.py; lingora/tokenize.py (runs with no model) |
| N-000338 | 05 | implemented; annotated: lingora/__init__.py:19 |
| N-000339 | 05 | implemented; annotated: lingora/__init__.py:19 |
| N-000340 | 05 | implemented; annotated: lingora/__init__.py:19 |
| N-000341 | 05 | implemented; annotated: lingora/__init__.py:19 |
| N-000342 | 05 | implemented; annotated: lingora/__init__.py:19 |
| N-000343 | 05 | implemented; annotated: lingora/__init__.py:19 |
| N-000344 | 05 | implemented; annotated: lingora/__init__.py:19 |
| N-000345 | 05 | implemented (no direct annotation): lingora/__init__.py; lingora/metrics.py (_is_number: int/float, never bool); lingora/tree.py |
| N-000346 | 05 | implemented (no direct annotation): lingora/__init__.py; lingora/metrics.py (_is_number: int/float, never bool); lingora/tree.py |
| N-000347 | 05 | implemented (no direct annotation): lingora/__init__.py; lingora/metrics.py (_is_number: int/float, never bool); lingora/tree.py |
| N-000348 | 05 | implemented (no direct annotation): lingora/__init__.py; lingora/metrics.py (_is_number: int/float, never bool); lingora/tree.py |
| N-000349 | 05 | implemented (no direct annotation): lingora/__init__.py; lingora/metrics.py (_is_number: int/float, never bool); lingora/tree.py |
| N-000350 | 05 | implemented (no direct annotation): lingora/__init__.py; lingora/metrics.py (_is_number: int/float, never bool); lingora/tree.py |
| N-000351 | 05 | implemented (no direct annotation): lingora/__init__.py; lingora/metrics.py (_is_number: int/float, never bool); lingora/tree.py |
| N-000352 | 05 | implemented (no direct annotation): lingora/__init__.py; lingora/metrics.py (_is_number: int/float, never bool); lingora/tree.py |
| N-000353 | 06 | implemented; annotated: lingora/data.py:31 |
| N-000354 | 06 | implemented; annotated: lingora/data.py:42 |
| N-000355 | 06 | implemented; annotated: lingora/data.py:31 |
| N-000356 | 06 | implemented; annotated: lingora/data.py:31 |
| N-000357 | 06 | implemented (no direct annotation): lingora/data.py; lingora/_punkt.py; lingora/_perceptron.py; lingora/stem.py; lingora/tag.py |
| N-000358 | 06 | implemented (no direct annotation): lingora/data.py; lingora/_punkt.py; lingora/_perceptron.py; lingora/stem.py; lingora/tag.py |
| N-000359 | 06 | implemented (no direct annotation): lingora/data.py; lingora/_punkt.py; lingora/_perceptron.py; lingora/stem.py; lingora/tag.py |
| N-000360 | 06 | implemented (no direct annotation): lingora/data.py; lingora/_punkt.py; lingora/_perceptron.py; lingora/stem.py; lingora/tag.py |
| N-000361 | 06 | implemented (no direct annotation): lingora/data.py; lingora/_punkt.py; lingora/_perceptron.py; lingora/stem.py; lingora/tag.py |
| N-000362 | 06 | implemented (no direct annotation): lingora/data.py; lingora/_punkt.py; lingora/_perceptron.py; lingora/stem.py; lingora/tag.py |
| N-000363 | 06 | implemented (no direct annotation): lingora/data.py; lingora/_punkt.py; lingora/_perceptron.py; lingora/stem.py; lingora/tag.py |
| N-000364 | 06 | implemented (no direct annotation): lingora/data.py; lingora/_punkt.py; lingora/_perceptron.py; lingora/stem.py; lingora/tag.py |
| N-000365 | 06 | implemented (no direct annotation): lingora/data.py; lingora/_punkt.py; lingora/_perceptron.py; lingora/stem.py; lingora/tag.py |
| N-000366 | 06 | implemented (no direct annotation): lingora/data.py; lingora/_punkt.py; lingora/_perceptron.py; lingora/stem.py; lingora/tag.py |
| N-000367 | 06 | implemented (no direct annotation): lingora/data.py; lingora/_punkt.py; lingora/_perceptron.py; lingora/stem.py; lingora/tag.py |
| N-000368 | 06 | implemented (no direct annotation): lingora/data.py; lingora/_punkt.py; lingora/_perceptron.py; lingora/stem.py; lingora/tag.py |
| N-000369 | 06 | implemented (no direct annotation): lingora/data.py; lingora/_punkt.py; lingora/_perceptron.py; lingora/stem.py; lingora/tag.py |
| N-000370 | 06 | implemented (no direct annotation): lingora/data.py; lingora/_punkt.py; lingora/_perceptron.py; lingora/stem.py; lingora/tag.py |
| N-000371 | 07 | implemented (no direct annotation): lingora/tokenize.py |
| N-000372 | 07 | implemented (no direct annotation): lingora/tokenize.py |
| N-000373 | 07 | implemented (no direct annotation): lingora/tokenize.py |
| N-000374 | 07 | implemented (no direct annotation): lingora/tokenize.py |
| N-000375 | 07 | implemented (no direct annotation): lingora/tokenize.py |
| N-000376 | 07 | implemented (no direct annotation): lingora/tokenize.py |
| N-000377 | 07 | implemented; annotated: lingora/tokenize.py:136 |
| N-000378 | 07 | implemented; annotated: lingora/tokenize.py:136 |
| N-000379 | 07 | implemented; annotated: lingora/tokenize.py:181 |
| N-000380 | 07 | implemented; annotated: lingora/tokenize.py:44 |
| N-000381 | 07 | implemented; annotated: lingora/tokenize.py:156 |
| N-000382 | 08 | implemented; annotated: lingora/cli.py:85; tested: tests/test_structures.py::test_N_000382_cli_tokenizes_each_line |
| N-000383 | 08 | implemented; annotated: lingora/cli.py:85 |
| N-000384 | 08 | implemented; annotated: lingora/cli.py:85 |
| N-000385 | 08 | implemented; annotated: lingora/cli.py:85; tested: tests/test_structures.py::test_N_000385_cli_failure_writes_no_token_line |
| N-000386 | 08 | implemented; annotated: lingora/cli.py:85 |
| N-000387 | 08 | implemented; annotated: lingora/cli.py:85 |
| N-000388 | 08 | implemented; annotated: lingora/cli.py:85; tested: tests/test_structures.py::test_N_000388_cli_delimiter_option |
| N-000389 | 09 | implemented (no direct annotation): lingora/stem.py |
| N-000390 | 09 | implemented; annotated: lingora/stem.py:566 |
| N-000391 | 09 | implemented; annotated: lingora/stem.py:566 |
| N-000392 | 09 | implemented; annotated: lingora/stem.py:587 |
| N-000393 | 09 | implemented; annotated: lingora/stem.py:33 |
| N-000394 | 09 | implemented; annotated: lingora/stem.py:556; tested: tests/test_stem_tag.py::test_N_000394_snowball_unsupported_language_raises |
| N-000395 | 09 | implemented; annotated: lingora/stem.py:556; tested: tests/test_stem_tag.py::test_N_000395_snowball_stopword_skipping_needs_list |
| N-000396 | 09 | implemented; annotated: lingora/stem.py:609, lingora/stem.py:622; tested: tests/test_stem_tag.py::test_N_000396_wordnet_exception_lookup |
| N-000397 | 10 | implemented (no direct annotation): lingora/tag.py |
| N-000398 | 10 | implemented (no direct annotation): lingora/tag.py |
| N-000399 | 10 | implemented; annotated: lingora/tag.py:41; tested: tests/test_stem_tag.py::test_N_000399_tagger_refuses_string_tokens |
| N-000400 | 10 | implemented; annotated: lingora/tag.py:67 |
| N-000401 | 10 | implemented; annotated: lingora/tag.py:67 |
| N-000402 | 10 | implemented; annotated: lingora/tag.py:94 |
| N-000403 | 10 | implemented; annotated: lingora/tag.py:67 |
| N-000404 | 10 | implemented; annotated: lingora/tag.py:120 |
| N-000405 | 10 | implemented; annotated: lingora/tag.py:120 |
| N-000406 | 10 | implemented; annotated: lingora/tag.py:120 |
| N-000407 | 10 | implemented; annotated: lingora/tag.py:120 |
| N-000408 | 10 | implemented; annotated: lingora/tag.py:41 |
| N-000409 | 10 | implemented; annotated: lingora/tag.py:41 |
| N-000410 | 11 | implemented (no direct annotation): lingora/chunk.py |
| N-000411 | 11 | implemented (no direct annotation): lingora/chunk.py |
| N-000412 | 11 | implemented; annotated: lingora/chunk.py:251 |
| N-000413 | 11 | implemented; annotated: lingora/chunk.py:246 |
| N-000414 | 11 | not done: chunk grammar must be a str; stage objects not implemented (implementer's choice; G18) |
| N-000415 | 11 | implemented; annotated: lingora/chunk.py:268; tested: tests/test_structures.py::test_N_000415_ne_chunk_needs_packaged_model |
| N-000416 | 11 | implemented; annotated: lingora/chunk.py:246 |
| N-000417 | 11 | implemented; annotated: lingora/chunk.py:246 |
| N-000418 | 11 | implemented; annotated: lingora/chunk.py:251 |
| N-000419 | 11 | implemented; annotated: lingora/chunk.py:251 |
| N-000420 | 11 | implemented; annotated: lingora/chunk.py:21 |
| N-000421 | 11 | implemented; annotated: lingora/chunk.py:251 |
| N-000422 | 11 | implemented; annotated: lingora/chunk.py:251 |
| N-000423 | 11 | implemented; annotated: lingora/chunk.py:251 |
| N-000424 | 12 | implemented; annotated: lingora/grammar.py:115; tested: tests/test_structures.py::test_N_000424_grammar_reader_start_and_terminals |
| N-000425 | 12 | implemented; annotated: lingora/grammar.py:115 |
| N-000426 | 12 | implemented; annotated: lingora/grammar.py:115 |
| N-000427 | 12 | implemented; annotated: lingora/grammar.py:85 |
| N-000428 | 12 | implemented (no direct annotation): lingora/grammar.py; lingora/parse/__init__.py; lingora/parse/generate.py |
| N-000429 | 12 | implemented; annotated: lingora/grammar.py:16 |
| N-000430 | 12 | implemented; annotated: lingora/grammar.py:131, lingora/grammar.py:16 |
| N-000431 | 12 | implemented; annotated: lingora/grammar.py:16 |
| N-000432 | 12 | implemented; annotated: lingora/grammar.py:52 |
| N-000433 | 12 | implemented; annotated: lingora/grammar.py:52 |
| N-000434 | 12 | implemented; annotated: lingora/grammar.py:102, lingora/grammar.py:134 |
| N-000435 | 12 | implemented (no direct annotation): lingora/grammar.py; lingora/parse/__init__.py; lingora/parse/generate.py |
| N-000436 | 12 | implemented; annotated: lingora/parse/__init__.py:38; tested: tests/test_structures.py::test_N_000436_chart_parser_returns_all_trees_and_empty_for_non_derivable |
| N-000437 | 12 | implemented; annotated: lingora/parse/__init__.py:38 |
| N-000438 | 12 | implemented; annotated: lingora/parse/__init__.py:27, lingora/parse/__init__.py:97; tested: tests/test_structures.py::test_N_000438_token_produced_by_no_production_raises |
| N-000439 | 12 | implemented; annotated: lingora/parse/__init__.py:27, lingora/parse/__init__.py:97 |
| N-000440 | 12 | implemented; annotated: lingora/parse/generate.py:24 |
| N-000441 | 12 | implemented; annotated: lingora/parse/generate.py:24 |
| N-000442 | 12 | implemented; annotated: lingora/parse/generate.py:24 |
| N-000443 | 12 | implemented; annotated: lingora/parse/generate.py:24 |
| N-000444 | 13 | implemented; annotated: lingora/tree.py:15 |
| N-000445 | 13 | implemented; annotated: lingora/tree.py:15 |
| N-000446 | 13 | implemented; annotated: lingora/tree.py:19, lingora/tree.py:32 |
| N-000447 | 13 | implemented; annotated: lingora/tree.py:15, lingora/tree.py:32 |
| N-000448 | 13 | implemented (no direct annotation): lingora/tree.py |
| N-000449 | 13 | implemented; annotated: lingora/tree.py:19 |
| N-000450 | 13 | implemented; annotated: lingora/tree.py:19 |
| N-000451 | 13 | implemented; annotated: lingora/tree.py:19 |
| N-000452 | 13 | implemented; annotated: lingora/tree.py:104; tested: tests/test_structures.py::test_N_000452_bracketed_text_equals_built_tree |
| N-000453 | 13 | implemented; annotated: lingora/tree.py:29, lingora/tree.py:99 |
| N-000454 | 13 | implemented; annotated: lingora/tree.py:99 |
| N-000455 | 14 | implemented; annotated: lingora/classify.py:59 |
| N-000456 | 14 | implemented; annotated: lingora/classify.py:59 |
| N-000457 | 14 | implemented; annotated: lingora/classify.py:59 |
| N-000458 | 14 | implemented; annotated: lingora/classify.py:59 |
| N-000459 | 14 | implemented; annotated: lingora/classify.py:35 |
| N-000460 | 14 | implemented; annotated: lingora/classify.py:38, lingora/classify.py:82 |
| N-000461 | 15 | implemented; annotated: lingora/metrics.py:26 |
| N-000462 | 15 | implemented (no direct annotation): lingora/metrics.py; lingora/translate.py |
| N-000463 | 15 | implemented (no direct annotation): lingora/metrics.py; lingora/translate.py |
| N-000464 | 15 | implemented; annotated: lingora/metrics.py:26 |
| N-000465 | 15 | implemented; annotated: lingora/metrics.py:26; tested: tests/test_structures.py::test_N_000465_accuracy_refuses_unequal_lengths |
| N-000466 | 15 | implemented; annotated: lingora/metrics.py:38 |
| N-000467 | 15 | implemented; annotated: lingora/metrics.py:38 |
| N-000468 | 15 | implemented; annotated: lingora/metrics.py:38 |
| N-000469 | 15 | implemented; annotated: lingora/metrics.py:102; tested: tests/test_structures.py::test_N_000469_jaccard_and_set_metrics |
| N-000470 | 15 | implemented; annotated: lingora/metrics.py:111, lingora/metrics.py:119, lingora/metrics.py:127; tested: tests/test_structures.py::test_N_000470_set_metrics_refuse_lists |
| N-000471 | 15 | implemented; annotated: lingora/metrics.py:111, lingora/metrics.py:119, lingora/metrics.py:127, lingora/metrics.py:26 |
| N-000472 | 15 | implemented; annotated: lingora/metrics.py:111, lingora/metrics.py:119, lingora/metrics.py:127 |
| N-000473 | 15 | implemented; annotated: lingora/translate.py:41 |
| N-000474 | 15 | implemented; annotated: lingora/translate.py:41 |
| N-000475 | 15 | implemented; annotated: lingora/translate.py:41 |
| N-000476 | 15 | implemented; annotated: lingora/translate.py:41 |
| N-000477 | 15 | implemented; annotated: lingora/translate.py:41 |
