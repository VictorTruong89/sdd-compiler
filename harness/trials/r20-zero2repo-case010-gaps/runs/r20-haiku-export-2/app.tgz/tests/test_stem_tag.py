"""Stemmers (FP-02) and taggers (FP-03)."""

import pytest

from lingora.data import ResourceNotFound
from lingora.stem import (
    PorterStemmer,
    RegexpStemmer,
    SnowballStemmer,
    WordNetLemmatizer,
)
from lingora.tag import DefaultTagger, RegexpTagger, UnigramTagger, pos_tag


# -- Porter ------------------------------------------------------------------

@pytest.mark.parametrize(
    "word, expected",
    [
        ("caresses", "caress"), ("cats", "cat"), ("feed", "feed"), ("agreed", "agre"),
        ("plastered", "plaster"), ("motoring", "motor"), ("sized", "size"),
        ("hopping", "hop"), ("happy", "happi"), ("relational", "relat"),
        ("conditional", "condit"), ("rational", "ration"), ("hopefulness", "hope"),
        ("formaliti", "formal"), ("electriciti", "electr"), ("triplicate", "triplic"),
        ("formative", "form"), ("effective", "effect"), ("probate", "probat"),
    ],
)
def test_N_000145_porter_original_algorithm(word, expected):
    assert PorterStemmer(mode="original").stem(word) == expected


def test_N_000148_porter_short_words_returned_as_is():
    assert PorterStemmer().stem("Is") == "is"
    assert PorterStemmer().stem("AB") == "ab"


def test_N_000146_porter_lowercases_unless_turned_off():
    assert PorterStemmer().stem("Cats") == "cat"
    assert PorterStemmer().stem("Cats", to_lowercase=False) == "Cat"


def test_N_000150_porter_lingora_four_letter_ies_becomes_ie():
    assert PorterStemmer().stem("ties") == "tie"
    assert PorterStemmer(mode="original").stem("ties") == "ti"


def test_N_000151_porter_lingora_ied_handling():
    assert PorterStemmer().stem("tied") == "tie"


def test_N_000155_porter_lingora_bli_and_logi_extensions():
    assert PorterStemmer().stem("conformabli") == "conform"
    assert PorterStemmer().stem("biologi") == "biolog"


def test_N_000145_porter_lingora_irregular_table():
    assert PorterStemmer().stem("dying") == "die"


# -- Snowball ----------------------------------------------------------------

@pytest.mark.parametrize(
    "word, expected",
    [
        ("generously", "generous"), ("consign", "consign"), ("happiness", "happi"),
        ("relational", "relat"), ("running", "run"), ("cats", "cat"),
        ("skies", "sky"), ("dying", "die"), ("gently", "gentl"),
        ("generalization", "general"), ("communism", "communism"), ("fairly", "fair"),
    ],
)
def test_N_000163_snowball_english_is_porter2(word, expected):
    assert SnowballStemmer("english").stem(word) == expected


def test_N_000394_snowball_unsupported_language_raises():
    with pytest.raises(ValueError):
        SnowballStemmer("klingon")


def test_N_000395_snowball_stopword_skipping_needs_list(data_path):
    data_path[:] = []
    with pytest.raises(LookupError):
        SnowballStemmer("english", ignore_stopwords=True)


def test_N_000167_snowball_stopword_returned_lowercased(stopwords_root, data_path):
    data_path[:] = [stopwords_root]
    stemmer = SnowballStemmer("english", ignore_stopwords=True)
    assert stemmer.stem("The") == "the"
    assert stemmer.stem("Running") == "run"


def test_N_000170_regexp_stemmer_removes_matches_only():
    assert RegexpStemmer("ing$").stem("running") == "runn"
    assert RegexpStemmer("ing$").stem("runs") == "runs"


def test_N_000174_wordnet_missing_raises(data_path):
    data_path[:] = []
    with pytest.raises(ResourceNotFound):
        WordNetLemmatizer()


def test_N_000396_wordnet_exception_lookup(wordnet_root, data_path):
    data_path[:] = [wordnet_root]
    lemmatizer = WordNetLemmatizer()
    assert lemmatizer.lemmatize("dogs") == "dog"
    assert lemmatizer.lemmatize("cat") == "cat"


# -- sequential taggers ------------------------------------------------------

def test_N_000187_default_tagger_assigns_one_tag():
    assert DefaultTagger("NN").tag(["a", "b"]) == [("a", "NN"), ("b", "NN")]
    assert DefaultTagger("NN").tag([]) == []


def test_N_000189_unigram_most_frequent_tag_and_unseen_word_untagged():
    train = [[("a", "X"), ("b", "Y")], [("a", "X"), ("a", "Y")]]
    assert UnigramTagger(train=train).tag(["a", "b", "c"]) == [("a", "X"), ("b", "Y"), ("c", None)]


def test_N_000195_backoff_only_for_untagged_tokens():
    train = [[("a", "X")]]
    tagger = UnigramTagger(train=train, backoff=DefaultTagger("Z"))
    assert tagger.tag(["a", "c"]) == [("a", "X"), ("c", "Z")]


def test_N_000191_regexp_tagger_first_rule_at_token_start():
    tagger = RegexpTagger([(r".*ing$", "VBG"), (r"\d+", "CD")])
    assert tagger.tag(["running", "12", "x"]) == [("running", "VBG"), ("12", "CD"), ("x", None)]


def test_N_000399_tagger_refuses_string_tokens():
    with pytest.raises(TypeError):
        DefaultTagger("NN").tag("a b")


# -- recommended perceptron tagger -------------------------------------------

def test_N_000196_pos_tag_english_native_and_universal(tagger_root, data_path):
    data_path[:] = [tagger_root]
    assert pos_tag(["the", "dog", "runs"]) == [("the", "DT"), ("dog", "NN"), ("runs", "VBZ")]
    assert pos_tag(["the", "dog", "runs"], tagset="universal") == [
        ("the", "DETERMINER"), ("dog", "NOUN"), ("runs", "VERB"),
    ]
    assert pos_tag([]) == []


def test_N_000208_pos_tag_refuses_untokenized_string(tagger_root, data_path):
    data_path[:] = [tagger_root]
    with pytest.raises(TypeError):
        pos_tag("the dog runs")


def test_N_000211_pos_tag_only_english_and_russian(tagger_root, data_path):
    data_path[:] = [tagger_root]
    with pytest.raises(ValueError):
        pos_tag(["x"], lang="fra")


def test_N_000213_pos_tag_missing_resource_raises(tagger_root, data_path):
    data_path[:] = [tagger_root]
    with pytest.raises(ResourceNotFound):
        pos_tag(["x"], lang="rus")
