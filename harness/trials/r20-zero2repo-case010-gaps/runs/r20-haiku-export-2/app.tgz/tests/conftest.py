"""Shared fixtures: small packaged-resource trees built under pytest's tmp_path.

Nothing here is shipped with the library; each test that needs a packaged
model builds one in a temporary directory and points ``lingora.data.path`` at it.
"""

import json
import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from lingora import data  # noqa: E402


@pytest.fixture
def data_path():
    """Yield the (mutable) ``lingora.data.path`` list and restore it afterwards."""
    saved = list(data.path)
    try:
        yield data.path
    finally:
        data.path[:] = saved


def _write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)


@pytest.fixture
def punkt_root(tmp_path):
    """A resource root holding a tiny English Punkt model."""
    root = tmp_path / "res"
    base = root / "tokenizers" / "punkt_tab" / "english"
    _write(str(base / "abbrev_types.txt"), "mr\ndr\netc\nst\nvs\n")
    _write(str(base / "sent_starters.txt"), "said\nthe\nhe\nshe\nit\n")
    _write(str(base / "collocations.tab"), "Mr\tSmith\n")
    _write(
        str(base / "ortho_context.tab"),
        "the\t32\nDr\t2\nIt\t4\nthe\t16\nHe\t4\nhe\t32\nSaid\t4\nsaid\t32\n",
    )
    return str(root)


@pytest.fixture
def tagger_root(tmp_path):
    """A resource root holding a tiny English perceptron tagger and universal map."""
    root = tmp_path / "res"
    tdir = root / "taggers" / "averaged_perceptron_tagger_eng"
    stem = str(tdir / "averaged_perceptron_tagger_eng")
    weights = {
        "bias": {"NN": 1.0},
        "i word the": {"DT": 2.0},
        "i word dog": {"NN": 2.0},
        "i word runs": {"VBZ": 2.0},
        "i-1 tag DT": {"NN": 1.0},
    }
    _write(stem + ".weights.json", json.dumps(weights))
    _write(stem + ".tagdict.json", json.dumps({"the": "DT"}))
    _write(stem + ".classes.json", json.dumps(["DT", "NN", "VBZ", "JJ"]))
    _write(
        str(root / "taggers" / "universal_tagset" / "en-ptb.map"),
        "DT\tDETERMINER\nNN\tNOUN\nVBZ\tVERB\n",
    )
    return str(root)


@pytest.fixture
def stopwords_root(tmp_path):
    root = tmp_path / "res"
    _write(str(root / "corpora" / "stopwords" / "english"), "the\na\nof\n")
    return str(root)


@pytest.fixture
def wordnet_root(tmp_path):
    root = tmp_path / "res"
    _write(str(root / "corpora" / "wordnet" / "noun.exc"), "dogs dog\nmice mouse\n")
    return str(root)
