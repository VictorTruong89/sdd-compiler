"""Chunking (FP-04), grammars and trees (FP-05), classifiers (FP-06), metrics (FP-07), CLI."""

import io
import sys

import pytest

from lingora.chunk import RegexpParser, ne_chunk
from lingora.classify import DecisionTreeClassifier, NaiveBayesClassifier, accuracy
from lingora.data import ResourceNotFound
from lingora.grammar import CFG, Nonterminal
from lingora.metrics import (
    accuracy as list_accuracy,
    edit_distance,
    f_measure,
    jaccard_distance,
    precision,
    recall,
)
from lingora.parse import ChartParser, ShiftReduceParser
from lingora.parse.generate import generate
from lingora.translate import SmoothingFunction, bleu
from lingora.tree import Tree
from lingora import cli as cli_module


# -- chunking ----------------------------------------------------------------

TAGGED = [
    ("the", "DT"), ("little", "JJ"), ("yellow", "JJ"), ("dog", "NN"),
    ("barked", "VBD"), ("at", "IN"), ("the", "DT"), ("cat", "NN"),
]


def test_N_000223_chunk_rule_longest_match_and_root_label():
    tree = RegexpParser("NP: {<DT>?<JJ>*<NN>}").parse(TAGGED)
    assert tree.label() == "S"
    assert [c.label() for c in tree if isinstance(c, Tree)] == ["NP", "NP"]
    assert tree.leaves() == TAGGED  # chunking never drops, reorders or retags


def test_N_000227_chink_splits_chunk_and_chinked_tokens_go_to_root():
    tree = RegexpParser("NP: {<.*>+}\n    }<VBD>{").parse([("a", "DT"), ("ran", "VBD"), ("b", "NN")])
    assert tree == Tree("S", [Tree("NP", [("a", "DT")]), ("ran", "VBD"), Tree("NP", [("b", "NN")])])


def test_N_000230_clauses_cascade_over_earlier_chunks():
    tagged = [("the", "DT"), ("big", "JJ"), ("dog", "NN")]
    tree = RegexpParser("NP: {<DT|JJ>+}\nS2: {<NP><NN>}").parse(tagged)
    assert tree == Tree("S", [Tree("S2", [Tree("NP", [("the", "DT"), ("big", "JJ")]), ("dog", "NN")])])


def test_N_000221_quantifier_braces_in_chunk_pattern():
    tree = RegexpParser("NP: {<NN>{2,}}").parse([("a", "NN"), ("b", "NN"), ("c", "DT")])
    assert tree == Tree("S", [Tree("NP", [("a", "NN"), ("b", "NN")]), ("c", "DT")])


def test_N_000415_ne_chunk_needs_packaged_model(data_path):
    data_path[:] = []
    with pytest.raises(ResourceNotFound):
        ne_chunk(TAGGED)


def test_N_000217_grammar_pattern_line_must_be_indented():
    with pytest.raises(ValueError):
        RegexpParser("NP: {<DT>}\n}<VBD>{")


# -- grammar, parsing, generation --------------------------------------------

GRAMMAR_TEXT = """
S -> NP VP
NP -> 'the' N | N
VP -> V NP | V
N -> 'dog' | 'cat'
V -> 'saw' | 'sleeps'
"""


def test_N_000424_grammar_reader_start_and_terminals():
    grammar = CFG.fromstring(GRAMMAR_TEXT)
    assert str(grammar.start()) == "S"
    np_alternatives = grammar.productions(lhs="NP")
    assert len(np_alternatives) == 2  # one production per alternative
    first_rhs = np_alternatives[0].rhs()
    assert first_rhs[0] == "the" and isinstance(first_rhs[0], str)
    assert isinstance(first_rhs[1], Nonterminal) and not isinstance(first_rhs[1], str)


def test_N_000436_chart_parser_returns_all_trees_and_empty_for_non_derivable():
    grammar = CFG.fromstring(GRAMMAR_TEXT)
    trees = list(ChartParser(grammar).parse(["the", "dog", "saw", "cat"]))
    assert len(trees) == 1 and trees[0].label() == "S"
    assert trees[0].leaves() == ["the", "dog", "saw", "cat"]
    assert list(ChartParser(grammar).parse(["dog", "dog"])) == []


def test_N_000242_chart_parser_ambiguity_gives_several_trees():
    grammar = CFG.fromstring('S -> S S | "a"')
    assert len(list(ChartParser(grammar).parse(["a", "a", "a"]))) == 2


def test_N_000247_shift_reduce_matches_chart_on_unambiguous_sentence():
    grammar = CFG.fromstring(GRAMMAR_TEXT)
    chart = list(ChartParser(grammar).parse(["the", "dog", "sleeps"]))
    shift = list(ShiftReduceParser(grammar).parse(["the", "dog", "sleeps"]))
    assert shift == chart


def test_N_000438_token_produced_by_no_production_raises():
    grammar = CFG.fromstring(GRAMMAR_TEXT)
    with pytest.raises(ValueError):
        ChartParser(grammar).parse(["zebra"])
    with pytest.raises(ValueError):
        ShiftReduceParser(grammar).parse(["zebra"])


def test_N_000251_generate_bounded_by_count_and_depth():
    grammar = CFG.fromstring(GRAMMAR_TEXT)
    sentences = list(generate(grammar, n=3))
    assert len(sentences) == 3
    assert all(isinstance(tok, str) for sent in sentences for tok in sent)
    assert list(generate(CFG.fromstring('S -> "x" S | "y"'), depth=2)) == [["x", "y"], ["y"]]


def test_N_000255_empty_production_contributes_no_token_and_empty_string_terminal_does():
    assert list(generate(CFG.fromstring('S -> A "b"\nA -> '))) == [["b"]]
    assert list(generate(CFG.fromstring('S -> ""'))) == [[""]]


# -- trees -------------------------------------------------------------------

def test_N_000452_bracketed_text_equals_built_tree():
    parsed = Tree.fromstring("(S (NP the dog) (VP barks))")
    built = Tree("S", [Tree("NP", ["the", "dog"]), Tree("VP", ["barks"])])
    assert parsed == built
    assert parsed.leaves() == ["the", "dog", "barks"]
    assert len(parsed) == 2 and parsed[0] == built[0]


def test_N_000262_tree_refusals_and_empty_children():
    with pytest.raises(TypeError):
        Tree("S", "ab")
    with pytest.raises(TypeError):
        Tree("S")
    empty = Tree("S", [])
    assert len(empty) == 0 and empty.leaves() == []


def test_N_000261_pformat_shows_every_label_and_leaf_in_order():
    text = Tree.fromstring("(S (NP the dog) (VP barks))").pformat()
    for token in ("S", "NP", "the", "dog", "VP", "barks"):
        assert token in text
    assert text.index("NP") < text.index("VP")


# -- classifiers -------------------------------------------------------------

LABELED = [
    ({"w": "free", "x": 1}, "spam"),
    ({"w": "money", "x": 2}, "spam"),
    ({"w": "hello", "x": 3}, "ham"),
    ({"w": "meeting", "x": 4}, "ham"),
]


def test_N_000279_naive_bayes_label_and_distribution():
    nb = NaiveBayesClassifier.train(LABELED)
    assert nb.labels() == ["spam", "ham"]
    assert nb.classify({"w": "free"}) == "spam"
    dist = nb.prob_classify({"w": "free"})
    assert abs(sum(dist.prob(label) for label in dist.samples()) - 1.0) < 1e-9
    assert dist.prob("spam") == pytest.approx(0.75)
    assert dist.prob("ham") > 0  # smoothed: unseen under ham is still nonzero


def test_N_000283_decision_tree_classifies_training_data_and_defaults():
    dt = DecisionTreeClassifier.train(LABELED)
    assert accuracy(dt, LABELED) == 1.0
    assert dt.classify({"w": "hello"}) == "ham"


def test_N_000288_accuracy_fraction_of_gold_pairs():
    nb = NaiveBayesClassifier.train(LABELED)
    assert accuracy(nb, LABELED) == 1.0


# -- metrics and BLEU --------------------------------------------------------

def test_N_000292_edit_distance_costs_and_transpositions():
    assert edit_distance("kitten", "sitting") == 3
    assert edit_distance("ab", "ba") == 2
    assert edit_distance("ab", "ba", transpositions=True) == 1
    assert edit_distance("ca", "abc", transpositions=True) == 2
    assert edit_distance("", "") == 0
    assert edit_distance("abc", "xbc", substitution_cost=0.5) == 0.5


def test_N_000469_jaccard_and_set_metrics():
    assert jaccard_distance({"a", "b"}, {"b", "c"}) == pytest.approx(2 / 3)
    assert precision({"a", "b"}, {"b", "c"}) == 0.5
    assert precision({"a"}, set()) is None
    assert recall({"a"}, set()) == 0.0
    assert recall(set(), {"a"}) is None
    assert f_measure({"a"}, {"a", "b"}) == pytest.approx(2 / 3)
    assert f_measure({"a"}, set()) is None


def test_N_000470_set_metrics_refuse_lists():
    with pytest.raises(TypeError):
        precision(["a"], {"a"})


def test_N_000465_accuracy_refuses_unequal_lengths():
    assert list_accuracy([1, 2, 3], [1, 2, 4]) == pytest.approx(2 / 3)
    with pytest.raises(ValueError):
        list_accuracy([1], [1, 2])


def test_N_000302_bleu_perfect_zero_and_smoothing():
    reference = ["the", "cat", "is", "on", "the", "mat"]
    assert bleu([reference], reference) == pytest.approx(1.0)
    assert bleu([reference], ["a", "b", "c", "d"]) == 0.0
    smoothed = bleu([reference], ["the", "cat", "sat", "on", "the", "mat"],
                    smoothing_function=SmoothingFunction().method1)
    assert 0 < smoothed < 1


# -- command line ------------------------------------------------------------

class _Stdin(io.StringIO):
    pass


def test_N_000382_cli_tokenizes_each_line(punkt_root, data_path, monkeypatch, capsys):
    data_path[:] = [punkt_root]
    monkeypatch.setattr(sys, "stdin", _Stdin("Mr. Smith went home.\n\nHe said hi.\n"))
    status = cli_module.cli.main(args=["tokenize"], standalone_mode=False)
    out = capsys.readouterr().out
    assert status == 0
    assert out == "Mr. Smith went home .\n\nHe said hi .\n"


def test_N_000385_cli_failure_writes_no_token_line(data_path, monkeypatch, capsys):
    data_path[:] = []
    monkeypatch.setattr(sys, "stdin", _Stdin("some text.\n"))
    with pytest.raises(SystemExit) as excinfo:
        cli_module.cli.main(args=["tokenize"], standalone_mode=True)
    assert excinfo.value.code != 0
    assert capsys.readouterr().out == ""


def test_N_000388_cli_delimiter_option(punkt_root, data_path, monkeypatch, capsys):
    data_path[:] = [punkt_root]
    monkeypatch.setattr(sys, "stdin", _Stdin("a b\n"))
    assert cli_module.cli.main(args=["tokenize", "--delimiter", "|"], standalone_mode=False) == 0
    assert capsys.readouterr().out == "a|b\n"
