"""Tokenizers (FP-01). Test names carry the checklist id they check (N-000xxx)."""

import pytest

from lingora.data import ResourceNotFound
from lingora.tokenize import (
    RegexpTokenizer,
    TreebankWordTokenizer,
    TweetTokenizer,
    WhitespaceTokenizer,
    WordPunctTokenizer,
    blankline_tokenize,
    sent_tokenize,
    word_tokenize,
    wordpunct_tokenize,
)


def test_N_000085_wordpunct_runs_of_word_and_punct():
    assert wordpunct_tokenize("Hello, world! It costs $3.50.") == [
        "Hello", ",", "world", "!", "It", "costs", "$", "3", ".", "50", ".",
    ]


def test_N_000129_empty_and_whitespace_strings_give_no_tokens():
    for tokenizer in (WordPunctTokenizer(), WhitespaceTokenizer(), TreebankWordTokenizer(), TweetTokenizer()):
        assert tokenizer.tokenize("") == []
        assert tokenizer.tokenize("  \n\t ") == []


def test_N_000119_spans_are_ordered_and_non_overlapping():
    spans = WordPunctTokenizer().span_tokenize("ab, cd!")
    assert spans == [(0, 2), (2, 3), (4, 6), (6, 7)]
    assert all(spans[i][1] <= spans[i + 1][0] for i in range(len(spans) - 1))


def test_N_000106_whitespace_tokens():
    assert WhitespaceTokenizer().tokenize(" a\tb\nc ") == ["a", "b", "c"]


def test_N_000088_penn_quotes_and_punctuation():
    tokens = TreebankWordTokenizer().tokenize('"Hello," she said.')
    assert tokens == ["``", "Hello", ",", "''", "she", "said", "."]


def test_N_000093_penn_single_punct_marks_are_tokens():
    assert TreebankWordTokenizer().tokenize("a;b @c #d $e %f &g ?h !i") == [
        "a", ";", "b", "@", "c", "#", "d", "$", "e", "%", "f", "&", "g", "?", "h", "!", "i",
    ]


def test_N_000095_point_split_only_at_end_of_text():
    assert TreebankWordTokenizer().tokenize("I live in the U.S.") == ["I", "live", "in", "the", "U.S", "."]
    assert TreebankWordTokenizer().tokenize("U.S. is big") == ["U.S.", "is", "big"]


def test_N_000096_clitics_split():
    assert TreebankWordTokenizer().tokenize("John's book isn't here") == [
        "John", "'s", "book", "is", "n't", "here",
    ]
    assert TreebankWordTokenizer().tokenize("They'll") == ["They", "'ll"]


def test_N_000097_fused_forms_split():
    assert TreebankWordTokenizer().tokenize("cannot") == ["can", "not"]
    assert TreebankWordTokenizer().tokenize("gonna") == ["gon", "na"]
    assert TreebankWordTokenizer().tokenize("d'ye") == ["d'", "ye"]


def test_N_000098_apostrophe_inside_word_stays():
    assert TreebankWordTokenizer().tokenize("rock'n") == ["rock'n"]


def test_N_000099_recommended_extra_splits_recommended_only():
    from lingora.tokenize import _recommended_tokenize_sentence as rec

    assert rec("wait -- what") == ["wait", "--", "what"]
    assert rec("a—b") == ["a", "—", "b"]
    assert rec("“quoted”") == ["“", "quoted", "”"]
    assert rec("the * star") == ["the", "*", "star"]
    assert rec("Hmm.... yes") == ["Hmm", "....", "yes"]
    # the plain Penn tokenizer does not split a double hyphen
    assert TreebankWordTokenizer().tokenize("wait -- what") == ["wait", "--", "what"]


def test_N_000108_blankline_segments():
    assert blankline_tokenize("a b\nc\n\n  \nd") == ["a b\nc", "d"]
    assert blankline_tokenize("   ") == []


def test_N_000109_regexp_token_mode_and_gap_mode():
    assert RegexpTokenizer(r"\w+").tokenize("a, bc!") == ["a", "bc"]
    assert RegexpTokenizer(r"\s+", gaps=True).tokenize(" a  b ") == ["a", "b"]
    assert RegexpTokenizer(r"\s+", gaps=True, discard_empty=False).tokenize(" a b") == ["", "a", "b"]


def test_N_000119_regexp_spans():
    assert RegexpTokenizer(r"\w+").span_tokenize("ab cd") == [(0, 2), (3, 5)]


def test_N_000112_tweet_contractions_urls_handles_hashtags():
    tokens = TweetTokenizer().tokenize("@ahmed loved it!!! :) #yay http://x.co/a Don't")
    assert tokens[0] == "@ahmed"
    assert tokens[1:3] == ["loved", "it"]
    assert tokens[3:6] == ["!", "!", "!"]
    assert ":)" in tokens and "#yay" in tokens and "http://x.co/a" in tokens and "Don't" in tokens


def test_N_000116_tweet_strip_handles_and_reduce_length():
    tokens = TweetTokenizer(strip_handles=True, reduce_len=True, preserve_case=False).tokenize(
        "@ahmed LOOOOOVE it :D"
    )
    assert tokens == ["looove", "it", ":D"]


def test_N_000116_tweet_handle_needs_non_word_before_at():
    tokens = TweetTokenizer(strip_handles=True).tokenize("mail a@b.com")
    assert "a@b" not in tokens and "com" in tokens


def test_N_000122_sentence_splitting_with_punkt(punkt_root, data_path):
    data_path[:] = [punkt_root]
    assert sent_tokenize("Mr. Smith went home. He said hello! Did he? Yes.") == [
        "Mr. Smith went home.", "He said hello!", "Did he?", "Yes.",
    ]


def test_N_000131_missing_punkt_model_raises(data_path):
    data_path[:] = []
    with pytest.raises(LookupError):
        sent_tokenize("x. y.")
    with pytest.raises(ResourceNotFound):
        word_tokenize("x. y.")


def test_N_000082_word_tokenize_preserve_line_needs_no_model(data_path):
    data_path[:] = []
    assert word_tokenize("He said hello!", preserve_line=True) == ["He", "said", "hello", "!"]


def test_N_000104_word_tokenize_splits_sentences_first(punkt_root, data_path):
    data_path[:] = [punkt_root]
    assert word_tokenize("Mr. Smith went home. He said hello!") == [
        "Mr.", "Smith", "went", "home", ".", "He", "said", "hello", "!",
    ]
    assert wordpunct_tokenize("Mr. Smith") == ["Mr", ".", "Smith"]
