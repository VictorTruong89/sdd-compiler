"""Put the project root on ``sys.path`` so the flat ``lingora`` package imports from tests."""
