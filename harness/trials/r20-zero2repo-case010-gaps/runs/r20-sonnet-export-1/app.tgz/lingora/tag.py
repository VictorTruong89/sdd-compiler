"""Taggers. # spec: N-000397 N-000398"""
import json
import os
import re
from collections import Counter, defaultdict

from lingora import data

__all__ = ["DefaultTagger", "RegexpTagger", "UnigramTagger", "BigramTagger",
           "TrigramTagger", "AffixTagger", "PerceptronTagger", "pos_tag"]


def _check_tokens(tokens):
    if isinstance(tokens, (str, bytes)) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str, not %s" % type(tokens).__name__)


class SequentialTagger:
    backoff = None

    def __init__(self, backoff=None):
        if backoff is not None and not hasattr(backoff, "tag"):
            raise TypeError("backoff must be a tagger or None")
        self.backoff = backoff

    def choose_tag(self, tokens, index, history):
        raise NotImplementedError

    def tag_one(self, tokens, index, history):
        # spec: N-000194 N-000195
        tag = self.choose_tag(tokens, index, history)
        if tag is None and self.backoff is not None:
            tag = self.backoff.tag_one(tokens, index, history)
        return tag

    def tag(self, tokens):
        # spec: N-000185 N-000186 N-000408 N-000409
        _check_tokens(tokens)
        tags = []
        for i in range(len(tokens)):
            tags.append(self.tag_one(tokens, i, tags))
        return list(zip(tokens, tags))

    def tag_sents(self, sents):
        return [self.tag(s) for s in sents]


class DefaultTagger(SequentialTagger):
    # spec: N-000187
    def __init__(self, tag):
        SequentialTagger.__init__(self, None)
        self._tag = tag

    def tag_one(self, tokens, index, history):
        return self._tag

    choose_tag = tag_one


class ContextTagger(SequentialTagger):
    def __init__(self, train=None, backoff=None, cutoff=0):
        SequentialTagger.__init__(self, backoff)
        self._context_to_tag = {}
        if train is not None:
            self._train(train, cutoff)

    def context(self, tokens, index, history):
        raise NotImplementedError

    def _train(self, train, cutoff):
        counts = defaultdict(Counter)
        for sent in train:
            tokens = [w for w, _ in sent]
            history = []
            for i, (w, t) in enumerate(sent):
                c = self.context(tokens, i, history)
                if c is not None:
                    counts[c][t] += 1
                history.append(t)
        for c, ctr in counts.items():
            tag, n = ctr.most_common(1)[0]  # ties: first seen
            if n > cutoff:
                self._context_to_tag[c] = tag

    def choose_tag(self, tokens, index, history):
        c = self.context(tokens, index, history)
        return self._context_to_tag.get(c) if c is not None else None


class UnigramTagger(ContextTagger):
    # spec: N-000188 N-000189 N-000190
    def __init__(self, train=None, model=None, backoff=None, cutoff=0):
        ContextTagger.__init__(self, train, backoff, cutoff)
        if model:
            self._context_to_tag.update(model)

    def context(self, tokens, index, history):
        return tokens[index]


class BigramTagger(ContextTagger):
    def context(self, tokens, index, history):
        prev = history[index - 1] if index >= 1 else None
        return (prev, tokens[index])


class TrigramTagger(ContextTagger):
    def context(self, tokens, index, history):
        p1 = history[index - 1] if index >= 1 else None
        p2 = history[index - 2] if index >= 2 else None
        return (p2, p1, tokens[index])


class AffixTagger(ContextTagger):
    def __init__(self, train=None, affix_length=-3, min_stem_length=2, backoff=None, cutoff=0):
        self._affix_length = affix_length
        self._min_word_length = min_stem_length + abs(affix_length)
        ContextTagger.__init__(self, train, backoff, cutoff)

    def context(self, tokens, index, history):
        token = tokens[index]
        if len(token) < self._min_word_length:
            return None
        if self._affix_length > 0:
            return token[: self._affix_length]
        return token[self._affix_length:]


class RegexpTagger(SequentialTagger):
    # spec: N-000191 N-000192 N-000193
    def __init__(self, regexps, backoff=None):
        SequentialTagger.__init__(self, backoff)
        self._regexps = [(re.compile(p), t) for p, t in regexps]

    def choose_tag(self, tokens, index, history):
        for rx, tag in self._regexps:
            if rx.match(tokens[index]):
                return tag
        return None


# --------------------------------------------------------------------------
# Averaged perceptron tagger (textblob-aptagger)
# --------------------------------------------------------------------------
class PerceptronTagger:
    # spec: N-000196 .. N-000203
    START = ["-START-", "-START2-"]
    END = ["-END-", "-END2-"]

    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = list(classes)

    @classmethod
    def load(cls, lang):
        d = data.find("taggers/averaged_perceptron_tagger_" + lang)
        base = os.path.join(d, "averaged_perceptron_tagger_%s" % lang)
        try:
            with open(base + ".weights.json", encoding="utf-8") as f:
                weights = json.load(f)
            with open(base + ".tagdict.json", encoding="utf-8") as f:
                tagdict = json.load(f)
            with open(base + ".classes.json", encoding="utf-8") as f:
                classes = json.load(f)
        except OSError as e:
            raise LookupError("tagger model for %r is incomplete: %s" % (lang, e))
        return cls(weights, tagdict, classes)

    @staticmethod
    def normalize(word):
        if "-" in word and word[0] != "-":
            return "!HYPHEN"
        if word.isdigit() and len(word) == 4:
            return "!YEAR"
        if word and word[0].isdigit():
            return "!DIGITS"
        return word.lower()

    def _features(self, i, word, context, prev, prev2):
        feats = defaultdict(int)

        def add(name, *args):
            feats[" ".join((name,) + tuple(args))] += 1

        i += len(self.START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return feats

    def _predict(self, feats):
        scores = defaultdict(float)
        for feat, value in feats.items():
            w = self.weights.get(feat)
            if w is None or value == 0:
                continue
            for label, weight in w.items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))

    def tag(self, tokens):
        _check_tokens(tokens)
        prev, prev2 = self.START
        out = []
        context = self.START + [self.normalize(w) for w in tokens] + self.END
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                tag = self._predict(self._features(i, word, context, prev, prev2))
            out.append((word, tag))
            prev2 = prev
            prev = tag
        return out


_RNC_TO_UNIVERSAL = {
    "S": "NOUN", "V": "VERB", "A": "ADJ", "ADV": "ADV", "SPRO": "PRON", "APRO": "DET",
    "ADVPRO": "ADV", "NUM": "NUM", "ANUM": "ADJ", "PR": "ADP", "CONJ": "CONJ",
    "PART": "PRT", "INTJ": "PRT", "COM": "X", "NONLEX": ".",
}


def pos_tag(tokens, tagset=None, lang="eng"):
    # spec: N-000404 .. N-000407 N-000208 .. N-000216
    _check_tokens(tokens)  # spec: N-000406
    if lang not in ("eng", "rus"):
        raise ValueError("unsupported language %r (use 'eng' or 'rus')" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("unsupported tagset %r" % (tagset,))
    tagger = PerceptronTagger.load(lang)  # spec: N-000213 N-000214
    tagged = tagger.tag(list(tokens))
    if tagset == "universal":
        if lang == "eng":
            table = _load_ptb_map()  # raises LookupError if the tables are absent
            return [(w, table.get(t, "X")) for w, t in tagged]
        return [(w, _RNC_TO_UNIVERSAL.get(t.partition("=")[0], "X")) for w, t in tagged]
    return tagged


def _load_ptb_map():
    d = data.find("taggers/universal_tagset")
    f = os.path.join(d, "en-ptb.map")
    if not os.path.isfile(f):
        raise LookupError("universal tagset table en-ptb.map not found")
    table = {}
    for line in data.read_lines(f):
        if "\t" in line:
            a, b = line.split("\t")[:2]
            table[a] = b
    return table
