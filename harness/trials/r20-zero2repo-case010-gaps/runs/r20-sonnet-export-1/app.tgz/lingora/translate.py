"""BLEU. # spec: N-000473 .. N-000477"""
import math
import sys
from collections import Counter
from fractions import Fraction

__all__ = ["bleu"]


def _ngrams(seq, n):
    return [tuple(seq[i:i + n]) for i in range(len(seq) - n + 1)]


def _modified_precision(references, hypothesis, n):
    counts = Counter(_ngrams(hypothesis, n))
    max_counts = {}
    for ref in references:
        rc = Counter(_ngrams(ref, n))
        for ng in counts:
            max_counts[ng] = max(max_counts.get(ng, 0), rc[ng])
    clipped = {ng: min(c, max_counts.get(ng, 0)) for ng, c in counts.items()}
    return Fraction(sum(clipped.values()), max(1, sum(counts.values())))


def bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):
    # spec: N-000473 .. N-000477 N-000302 .. N-000309
    if isinstance(hypothesis, str) or not isinstance(hypothesis, (list, tuple)):
        raise TypeError("hypothesis must be a token list")
    if not isinstance(references, (list, tuple)) or any(
            isinstance(r, str) or not isinstance(r, (list, tuple)) for r in references):
        raise TypeError("references must be a list of token lists")
    if not references:
        raise ValueError("at least one reference is required")
    hyp_len = len(hypothesis)
    if hyp_len == 0:
        return 0
    p_n = []
    for i in range(1, len(weights) + 1):
        p_n.append(_modified_precision(references, hypothesis, i))
    if p_n[0].numerator == 0:
        return 0
    ref_len = min((len(r) for r in references), key=lambda l: (abs(l - hyp_len), l))
    if hyp_len > ref_len:
        bp = 1.0
    else:
        bp = math.exp(1 - ref_len / hyp_len)
    if smoothing_function is not None:
        p_n = smoothing_function(p_n, references=references, hypothesis=hypothesis,
                                 hyp_len=hyp_len)
    vals = []
    for w, p in zip(weights, p_n):
        p = float(p)
        if p <= 0:
            p = sys.float_info.min
        vals.append(w * math.log(p))
    return bp * math.exp(math.fsum(vals))
