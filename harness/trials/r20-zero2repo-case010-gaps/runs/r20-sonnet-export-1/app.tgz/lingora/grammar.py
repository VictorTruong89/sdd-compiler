"""Context-free grammars. # spec: N-000424 .. N-000434"""
import re

__all__ = ["CFG", "Nonterminal", "Production"]


class Nonterminal:
    """A grammar nonterminal; not a ``str`` but ``str()`` gives its name."""
    # spec: N-000429 N-000430 N-000431
    __slots__ = ("_symbol",)

    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __eq__(self, other):
        if isinstance(other, Nonterminal):
            return self._symbol == other._symbol
        if isinstance(other, str):
            return self._symbol == other
        return NotImplemented

    def __hash__(self):
        return hash(self._symbol)

    def __str__(self):
        return self._symbol

    def __repr__(self):
        return "Nonterminal(%r)" % self._symbol


class Production:
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        # spec: N-000432 N-000433
        return self._rhs

    def is_lexical(self):
        return all(isinstance(r, str) for r in self._rhs)

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return (isinstance(other, Production) and self._lhs == other._lhs
                and self._rhs == other._rhs)

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        parts = [repr(r) if isinstance(r, str) else str(r) for r in self._rhs]
        return "%s -> %s" % (self._lhs, " ".join(parts))

    __repr__ = __str__


_RHS_TOKEN = re.compile(r"""\s*(?:"([^"]*)"|'([^']*)'|(\|)|([^\s|"']+))""")


def _parse_rhs(text):
    """Return a list of alternatives; each a list of symbols."""
    alts = [[]]
    pos = 0
    text = text.rstrip()
    while pos < len(text):
        if text[pos:].strip() == "":
            break
        m = _RHS_TOKEN.match(text, pos)
        if not m or m.end() == pos:
            raise ValueError("cannot parse right-hand side: %r" % text)
        pos = m.end()
        if m.group(1) is not None:
            alts[-1].append(m.group(1))
        elif m.group(2) is not None:
            alts[-1].append(m.group(2))
        elif m.group(3):
            alts.append([])
        else:
            alts[-1].append(Nonterminal(m.group(4)))
    return alts


class CFG:
    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)
        self._terminals = set()
        for p in self._productions:
            for r in p.rhs():
                if isinstance(r, str):
                    self._terminals.add(r)

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            raise TypeError("grammar text must be str")
        productions = []
        start = None
        lhs = None
        for line in input.split("\n"):
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("|") and lhs is not None:
                rhs_text = line
            else:
                if "->" not in line:
                    raise ValueError("bad production line (no '->'): %r" % line)
                left, rhs_text = line.split("->", 1)
                left = left.strip()
                if not left or re.search(r"\s", left) or left[0] in "'\"|":
                    raise ValueError("bad left-hand side: %r" % left)
                lhs = Nonterminal(left)
                if start is None:
                    start = lhs
            for alt in _parse_rhs(rhs_text):
                productions.append(Production(lhs, alt))
        if start is None:
            raise ValueError("grammar has no productions")
        return cls(start, productions)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        return [p for p in self._productions if p.lhs() == lhs]

    def terminals(self):
        return set(self._terminals)

    def check_coverage(self, tokens):
        missing = [t for t in tokens if t not in self._terminals]
        if missing:
            raise ValueError("Grammar does not cover some of the input words: %r"
                             % sorted(set(missing)))

    def __str__(self):
        return "Grammar with %d productions (start state = %s)\n%s" % (
            len(self._productions), self._start,
            "\n".join("    " + str(p) for p in self._productions))

    __repr__ = __str__
