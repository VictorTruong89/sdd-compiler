"""Command line group (self-contained, no third-party dependency).
# spec: N-000382 .. N-000388"""
import sys

__all__ = ["cli"]


class _UsageError(Exception):
    pass


class _Group:
    def __init__(self):
        self.commands = {"tokenize": self._tokenize}

    # ---- tokenize command ------------------------------------------------
    def _tokenize(self, args):
        language = "english"
        delimiter = " "
        encoding = "utf-8"
        it = iter(args)
        for a in it:
            if a in ("-l", "--language"):
                language = next(it, None)
            elif a in ("-d", "--delimiter"):
                delimiter = next(it, None)
            elif a in ("-e", "--encoding"):
                encoding = next(it, None)
            elif a.startswith("--language="):
                language = a.split("=", 1)[1]
            elif a.startswith("--delimiter="):
                delimiter = a.split("=", 1)[1]
            elif a.startswith("--encoding="):
                encoding = a.split("=", 1)[1]
            else:
                raise _UsageError("unexpected argument %r" % a)
            if language is None or delimiter is None or encoding is None:
                raise _UsageError("option requires a value")
        from lingora.tokenize import word_tokenize
        stdin = sys.stdin
        buf = getattr(stdin, "buffer", None)
        text = buf.read().decode(encoding) if buf is not None else stdin.read()
        lines = text.split("\n")
        if lines and lines[-1] == "":
            lines.pop()
        out = sys.stdout
        for line in lines:
            line = line[:-1] if line.endswith("\r") else line
            toks = word_tokenize(line, language=language)  # may raise: no line written
            out.write(delimiter.join(toks) + "\n")
        out.flush()

    # ---- entry -------------------------------------------------------------
    def main(self, args=None, prog_name=None, standalone_mode=True, **extra):
        if args is None:
            args = sys.argv[1:]
        args = list(args)
        try:
            if not args or args[0] in ("-h", "--help"):
                sys.stdout.write("Usage: lingora [OPTIONS] COMMAND [ARGS]...\n\n"
                                 "Commands:\n  tokenize  Tokenize standard input line by line.\n")
                code = 0
            elif args[0] not in self.commands:
                raise _UsageError("No such command %r." % args[0])
            else:
                if len(args) > 1 and args[1] in ("-h", "--help"):
                    sys.stdout.write("Usage: lingora tokenize [-l LANGUAGE] [-d DELIMITER] "
                                     "[-e ENCODING]\n")
                else:
                    self.commands[args[0]](args[1:])
                code = 0
        except _UsageError as e:
            if not standalone_mode:
                raise
            sys.stderr.write("Error: %s\n" % e)
            sys.exit(2)
        except SystemExit:
            raise
        except BaseException as e:  # failure: non-zero status, nothing more on stdout
            if not standalone_mode:
                raise
            sys.stderr.write("Error: %s: %s\n" % (type(e).__name__, e))
            sys.exit(1)
        if standalone_mode:
            sys.exit(code)
        return code

    def __call__(self, *args, **kw):
        return self.main(*args, **kw)


cli = _Group()

if __name__ == "__main__":
    cli()
