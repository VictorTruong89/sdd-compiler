"""Stemmers. # spec: N-000389"""
import os
import re

from lingora import data

__all__ = ["ARLSTem", "ARLSTem2", "LancasterStemmer", "PorterStemmer",
           "RegexpStemmer", "SnowballStemmer", "WordNetLemmatizer"]


def _check_word(word):
    if not isinstance(word, str):
        raise TypeError("word must be str")


# --------------------------------------------------------------------------
# Porter
# --------------------------------------------------------------------------
class PorterStemmer:
    # spec: N-000142 .. N-000160
    NLTK_EXTENSIONS = "NLTK_EXTENSIONS"
    MARTIN_EXTENSIONS = "MARTIN_EXTENSIONS"
    ORIGINAL_ALGORITHM = "ORIGINAL_ALGORITHM"

    def __init__(self, mode=NLTK_EXTENSIONS):
        if mode not in (self.NLTK_EXTENSIONS, self.MARTIN_EXTENSIONS, self.ORIGINAL_ALGORITHM):
            raise ValueError("Mode must be one of the three Porter modes")
        self.mode = mode
        self.pool = {}
        if mode == self.NLTK_EXTENSIONS:
            irregular = {
                "sky": ["sky", "skies"], "die": ["dying"], "lie": ["lying"],
                "tie": ["tying"], "news": ["news"], "inning": ["innings", "inning"],
                "outing": ["outings", "outing"], "canning": ["cannings", "canning"],
                "howe": ["howe"], "proceed": ["proceed"], "exceed": ["exceed"],
                "succeed": ["succeed"],
            }
            for key, forms in irregular.items():
                for f in forms:
                    self.pool[f] = key
        self.vowels = frozenset("aeiou")

    def _is_consonant(self, word, i):
        if word[i] in self.vowels:
            return False
        if word[i] == "y":
            if i == 0:
                return True
            return not self._is_consonant(word, i - 1)
        return True

    def _measure(self, stem):
        cv = "".join("c" if self._is_consonant(stem, i) else "v" for i in range(len(stem)))
        return cv.count("vc")

    def _has_positive_measure(self, stem):
        return self._measure(stem) > 0

    def _contains_vowel(self, stem):
        return any(not self._is_consonant(stem, i) for i in range(len(stem)))

    def _ends_double_consonant(self, word):
        return (len(word) >= 2 and word[-1] == word[-2]
                and self._is_consonant(word, len(word) - 1))

    def _ends_cvc(self, word):
        return (
            len(word) >= 3
            and self._is_consonant(word, len(word) - 3)
            and not self._is_consonant(word, len(word) - 2)
            and self._is_consonant(word, len(word) - 1)
            and word[-1] not in ("w", "x", "y")
        ) or (
            self.mode == self.NLTK_EXTENSIONS
            and len(word) == 2
            and not self._is_consonant(word, 0)
            and self._is_consonant(word, 1)
        )

    @staticmethod
    def _replace_suffix(word, suffix, replacement):
        if suffix == "":
            return word + replacement
        return word[: -len(suffix)] + replacement

    def _apply_rule_list(self, word, rules):
        for suffix, replacement, condition in rules:
            if suffix == "*d" and self._ends_double_consonant(word):
                stem = word[:-2]
                if condition is None or condition(stem):
                    return stem + replacement
                return word
            if word.endswith(suffix):
                stem = self._replace_suffix(word, suffix, "")
                if condition is None or condition(stem):
                    return stem + replacement
                return word
        return word

    def _step1a(self, word):
        if self.mode == self.NLTK_EXTENSIONS:
            if word.endswith("ies") and len(word) == 4:
                return self._replace_suffix(word, "ies", "ie")
        return self._apply_rule_list(word, [
            ("sses", "ss", None), ("ies", "i", None), ("ss", "ss", None), ("s", "", None)])

    def _step1b(self, word):
        if self.mode == self.NLTK_EXTENSIONS:
            if word.endswith("ied"):
                if len(word) == 4:
                    return self._replace_suffix(word, "ied", "ie")
                return self._replace_suffix(word, "ied", "i")
        if word.endswith("eed"):
            stem = self._replace_suffix(word, "eed", "")
            if self._measure(stem) > 0:
                return stem + "ee"
            return word
        ok = False
        inter = word
        for suffix in ("ed", "ing"):
            if word.endswith(suffix):
                inter = self._replace_suffix(word, suffix, "")
                if self._contains_vowel(inter):
                    ok = True
                    break
        if not ok:
            return word
        return self._apply_rule_list(inter, [
            ("at", "ate", None), ("bl", "ble", None), ("iz", "ize", None),
            ("*d", inter[-1], lambda stem: inter[-1] not in ("l", "s", "z")),
            ("", "e", lambda stem: self._measure(stem) == 1 and self._ends_cvc(stem)),
        ])

    def _step1c(self, word):
        def original(stem):
            return self._contains_vowel(stem)

        def nltk(stem):
            return len(stem) > 1 and self._is_consonant(stem, len(stem) - 1)

        return self._apply_rule_list(word, [
            ("y", "i", nltk if self.mode == self.NLTK_EXTENSIONS else original)])

    def _step2(self, word):
        pm = self._has_positive_measure
        if self.mode == self.NLTK_EXTENSIONS:
            if word.endswith("alli") and pm(self._replace_suffix(word, "alli", "")):
                return self._step2(self._replace_suffix(word, "alli", "al"))
        bli = ("bli", "ble", pm)
        abli = ("abli", "able", pm)
        rules = [
            ("ational", "ate", pm), ("tional", "tion", pm), ("enci", "ence", pm),
            ("anci", "ance", pm), ("izer", "ize", pm),
            abli if self.mode == self.ORIGINAL_ALGORITHM else bli,
            ("alli", "al", pm), ("entli", "ent", pm), ("eli", "e", pm),
            ("ousli", "ous", pm), ("ization", "ize", pm), ("ation", "ate", pm),
            ("ator", "ate", pm), ("alism", "al", pm), ("iveness", "ive", pm),
            ("fulness", "ful", pm), ("ousness", "ous", pm), ("aliti", "al", pm),
            ("iviti", "ive", pm), ("biliti", "ble", pm),
        ]
        if self.mode == self.NLTK_EXTENSIONS:
            rules.append(("fulli", "ful", pm))
            rules.append(("logi", "log", lambda stem: pm(word[:-3])))
        if self.mode == self.MARTIN_EXTENSIONS:
            rules.append(("logi", "log", pm))
        return self._apply_rule_list(word, rules)

    def _step3(self, word):
        pm = self._has_positive_measure
        return self._apply_rule_list(word, [
            ("icate", "ic", pm), ("ative", "", pm), ("alize", "al", pm),
            ("iciti", "ic", pm), ("ical", "ic", pm), ("ful", "", pm), ("ness", "", pm)])

    def _step4(self, word):
        gt1 = lambda stem: self._measure(stem) > 1  # noqa: E731
        sufs = ["al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement",
                "ment", "ent"]
        rules = [(s, "", gt1) for s in sufs]
        rules.append(("ion", "", lambda stem: self._measure(stem) > 1 and stem[-1:] in ("s", "t")))
        rules += [(s, "", gt1) for s in ("ou", "ism", "ate", "iti", "ous", "ive", "ize")]
        return self._apply_rule_list(word, rules)

    def _step5a(self, word):
        if word.endswith("e"):
            stem = self._replace_suffix(word, "e", "")
            if self._measure(stem) > 1:
                return stem
            if self._measure(stem) == 1 and not self._ends_cvc(stem):
                return stem
        return word

    def _step5b(self, word):
        return self._apply_rule_list(word, [
            ("ll", "l", lambda stem: self._measure(word[:-1]) > 1)])

    def stem(self, word, to_lowercase=True):
        _check_word(word)
        stem = word.lower() if to_lowercase else word
        if self.mode == self.NLTK_EXTENSIONS and stem in self.pool:
            return self.pool[stem]
        if self.mode != self.ORIGINAL_ALGORITHM and len(word) <= 2:
            return stem
        for step in (self._step1a, self._step1b, self._step1c, self._step2,
                     self._step3, self._step4, self._step5a, self._step5b):
            stem = step(stem)
        return stem

    def __repr__(self):
        return "<PorterStemmer>"


# --------------------------------------------------------------------------
# Lancaster
# --------------------------------------------------------------------------
_LANCASTER_RULES = (
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>", "cn1>", "dd1.", "dei3y>", "deec2ss.",
    "dee1.", "de2>", "dooh4>", "e1>", "feil1v.", "fi2>", "gni3>", "gai3y.", "ga2>",
    "gg1.", "ht*2.", "hsiug5ct.", "hsi3>", "i*1.", "i1y>", "ji1d.", "juf1s.", "ju1d.",
    "jo1d.", "jeh1r.", "jrev1t.", "jsim2t.", "jn1d.", "j1s.", "lbaifi6.", "lbai4y.",
    "lba3>", "lbi3.", "lib2l>", "lc1.", "lufi4y.", "luf3>", "lu2.", "lai3>", "lau3>",
    "la2>", "ll1.", "mui3.", "mu*2.", "msi3>", "mm1.", "nois4j>", "noix4ct.", "noi3>",
    "nai3>", "na2>", "nee0.", "ne2>", "nn1.", "pihs4>", "pp1.", "re2>", "rae0.", "ra2.",
    "ro2>", "ru2>", "rr1.", "rt1>", "rei3y>", "sei3y>", "sis2.", "si2>", "ssen4>",
    "ss0.", "suo3>", "su*2.", "s*1>", "s0.", "tacilp4y.", "ta2>", "tnem4>", "tne3>",
    "tna3>", "tpir2b.", "tpro2b.", "tcud1.", "tpmus2.", "tpec2iv.", "tulo2v.", "tsis0.",
    "tsi3>", "tt1.", "uqi3.", "ugo1.", "vis3j>", "vie0.", "vi2>", "ylb1>", "yli3y>",
    "ylp0.", "yl2>", "ygo1.", "yhp1.", "ymo1.", "ypo1.", "yti3>", "yte3>", "ytl2.",
    "yrtsi5.", "yra3>", "yro3>", "yfi3.", "ycn2t>", "yca3>", "zi2>", "zy1s.",
)


class LancasterStemmer:
    # spec: N-000161 N-000162
    def __init__(self, rule_tuple=None, strip_prefix_flag=False):
        self.rule_dictionary = {}
        self._strip_prefix = strip_prefix_flag
        for rule in (rule_tuple or _LANCASTER_RULES):
            self.rule_dictionary.setdefault(rule[0], []).append(rule)

    _valid = re.compile(r"^([a-z]+)(\*?)(\d)([a-z]*)([>\.]?)$")

    def stem(self, word):
        _check_word(word)
        word = word.lower()
        if self._strip_prefix:
            for prefix in ("kilo", "micro", "milli", "intra", "ultra", "mega", "nano",
                           "pico", "pseudo"):
                if word.startswith(prefix):
                    word = word[len(prefix):]
                    break
        intact = word
        return self._do(word, intact)

    @staticmethod
    def _last_letter(word):
        for pos in range(len(word)):
            if not word[pos].isalpha():
                return pos - 1
        return len(word) - 1

    @staticmethod
    def _acceptable(word, remove_total):
        if word[0] in "aeiouy":
            return len(word) - remove_total >= 2
        if len(word) - remove_total >= 3:
            return word[1] in "aeiouy" or word[2] in "aeiouy"
        return False

    def _do(self, word, intact_word):
        proceed = True
        while proceed:
            if not word:
                break
            pos = self._last_letter(word)
            if pos < 0 or word[pos] not in self.rule_dictionary:
                proceed = False
                continue
            applied = False
            for rule in self.rule_dictionary[word[pos]]:
                m = self._valid.match(rule)
                if not m:
                    continue
                ending, intact_flag, remove, append, cont = m.groups()
                remove = int(remove)
                if not word.endswith(ending[::-1]):
                    continue
                if intact_flag:
                    if word != intact_word or not self._acceptable(word, remove):
                        continue
                elif not self._acceptable(word, remove):
                    continue
                word = word[: len(word) - remove] + (append or "")
                applied = True
                if cont == ".":
                    proceed = False
                break
            if not applied:
                proceed = False
        return word


# --------------------------------------------------------------------------
# Regexp
# --------------------------------------------------------------------------
class RegexpStemmer:
    # spec: N-000168 N-000169 N-000170
    def __init__(self, regexp, min=0):
        if not hasattr(regexp, "pattern"):
            regexp = re.compile(regexp)
        self._regexp = regexp
        self._min = min

    def stem(self, word):
        _check_word(word)
        if len(word) < self._min:
            return word
        return self._regexp.sub("", word)


# --------------------------------------------------------------------------
# Snowball
# --------------------------------------------------------------------------
_LANGUAGES = ("arabic", "danish", "dutch", "english", "finnish", "french", "german",
              "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
              "russian", "spanish", "swedish")


class _EnglishStemmer:
    """Porter2 (Snowball English). # spec: N-000165"""
    VOWELS = "aeiouy"
    DOUBLES = ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")
    LI_END = "cdeghkmnrt"
    SPECIAL = {"skis": "ski", "skies": "sky", "dying": "die", "lying": "lie",
               "tying": "tie", "idly": "idl", "gently": "gentl", "ugly": "ugli",
               "early": "earli", "only": "onli", "singly": "singl",
               "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas",
               "cosmos": "cosmos", "bias": "bias", "andes": "andes"}
    EXC2 = {"inning", "outing", "canning", "herring", "earring", "proceed",
            "exceed", "succeed"}
    STEP2 = [("ization", "ize"), ("ational", "ate"), ("fulness", "ful"),
             ("ousness", "ous"), ("iveness", "ive"), ("tional", "tion"),
             ("biliti", "ble"), ("lessli", "less"), ("entli", "ent"),
             ("ation", "ate"), ("alism", "al"), ("aliti", "al"), ("ousli", "ous"),
             ("iviti", "ive"), ("fulli", "ful"), ("enci", "ence"), ("anci", "ance"),
             ("abli", "able"), ("izer", "ize"), ("ator", "ate"), ("alli", "al"),
             ("bli", "ble"), ("ogi", "og"), ("li", "")]
    STEP3 = [("ational", "ate"), ("tional", "tion"), ("alize", "al"),
             ("icate", "ic"), ("iciti", "ic"), ("ative", ""), ("ical", "ic"),
             ("ness", ""), ("ful", "")]
    STEP4 = ["ement", "ance", "ence", "able", "ible", "ment", "ant", "ent", "ism",
             "ate", "iti", "ous", "ive", "ize", "ion", "al", "er", "ic", "ou"]

    def _regions(self, w):
        def after(start):
            for i in range(start, len(w) - 1):
                if w[i] not in self.VOWELS and w[i - 1] in self.VOWELS:
                    return i + 1
            return len(w)
        r1 = None
        for p in ("gener", "commun", "arsen"):
            if w.startswith(p):
                r1 = len(p)
                break
        if r1 is None:
            r1 = after(1)
        r2 = after(r1 + 1) if r1 < len(w) else len(w)
        return r1, r2

    def _short_syll_end(self, w):
        n = len(w)
        if n == 2:
            return w[0] in self.VOWELS and w[1] not in self.VOWELS
        if n >= 3:
            return (w[-2] in self.VOWELS and w[-1] not in self.VOWELS
                    and w[-1] not in "wxY" and w[-3] not in self.VOWELS)
        return False

    def stem(self, word):
        w = word.lower()
        if len(w) <= 2:
            return w
        if w in self.SPECIAL:
            return self.SPECIAL[w]
        if w.startswith("'"):
            w = w[1:]
            if len(w) <= 2:
                return w
        if w.startswith("y"):
            w = "Y" + w[1:]
        w = re.sub(r"([aeiouy])y", r"\1Y", w)
        r1, r2 = self._regions(w)
        # step 0
        for s in ("'s'", "'s", "'"):
            if w.endswith(s):
                w = w[: -len(s)]
                break
        # step 1a
        if w.endswith("sses"):
            w = w[:-2]
        elif w.endswith("ied") or w.endswith("ies"):
            w = w[:-3] + ("i" if len(w) > 4 else "ie")
        elif w.endswith("us") or w.endswith("ss"):
            pass
        elif w.endswith("s"):
            if any(c in self.VOWELS for c in w[:-2]):
                w = w[:-1]
        if w in self.EXC2:
            return w.replace("Y", "y")
        r1 = min(r1, len(w)); r2 = min(r2, len(w))
        # step 1b
        m = None
        for s in ("eedly", "ingly", "edly", "eed", "ing", "ed"):
            if w.endswith(s):
                m = s
                break
        if m in ("eed", "eedly"):
            if len(w) - len(m) >= r1:
                w = w[: -len(m)] + "ee"
        elif m:
            base = w[: -len(m)]
            if any(c in self.VOWELS for c in base):
                w = base
                if w.endswith(("at", "bl", "iz")):
                    w += "e"
                elif w.endswith(self.DOUBLES):
                    w = w[:-1]
                elif r1 >= len(w) and self._short_syll_end(w):
                    w += "e"
        # step 1c
        if len(w) > 2 and w[-1] in "yY" and w[-2] not in self.VOWELS:
            w = w[:-1] + "i"
        # step 2
        for s, rep in self.STEP2:
            if w.endswith(s):
                if len(w) - len(s) >= r1:
                    if s == "ogi":
                        if w[:-3].endswith("l"):
                            w = w[:-3] + rep
                    elif s == "li":
                        if len(w) >= 3 and w[-3] in self.LI_END:
                            w = w[:-2]
                    else:
                        w = w[: -len(s)] + rep
                break
        # step 3
        for s, rep in self.STEP3:
            if w.endswith(s):
                if len(w) - len(s) >= r1:
                    if s == "ative":
                        if len(w) - len(s) >= r2:
                            w = w[:-5]
                    else:
                        w = w[: -len(s)] + rep
                break
        # step 4
        for s in self.STEP4:
            if w.endswith(s):
                if len(w) - len(s) >= r2:
                    if s == "ion":
                        if w[:-3].endswith(("s", "t")):
                            w = w[:-3]
                    else:
                        w = w[: -len(s)]
                break
        # step 5
        if w.endswith("e"):
            if len(w) - 1 >= r2 or (len(w) - 1 >= r1 and not self._short_syll_end(w[:-1])):
                w = w[:-1]
        elif w.endswith("l"):
            if len(w) - 1 >= r2 and w.endswith("ll"):
                w = w[:-1]
        return w.replace("Y", "y")


class _SuffixStemmer:
    """Approximate stemmer for languages without a full Snowball port."""
    SUFFIXES = {
        "danish": ["erendes", "erende", "hedens", "ethed", "heden", "erede", "ende", "ered", "erne", "enes", "heds", "heder", "ede", "ene", "ens", "ers", "ets", "het", "ast", "en", "er", "es", "et", "e", "s"],
        "dutch": ["heden", "ingen", "ing", "en", "e", "s"],
        "finnish": ["ssa", "ssä", "sta", "stä", "lla", "llä", "lta", "ltä", "lle", "ksi", "n", "a", "ä"],
        "french": ["issement", "ements", "ement", "ations", "ation", "ités", "ité", "euses", "euse", "eux", "es", "e", "s"],
        "german": ["ungen", "ung", "heit", "keit", "ern", "en", "er", "es", "e", "s", "n"],
        "hungarian": ["ok", "ek", "ak", "k", "t"],
        "italian": ["amente", "azione", "azioni", "mente", "are", "ere", "ire", "i", "e", "a", "o"],
        "norwegian": ["hetene", "heten", "heter", "ene", "ende", "ede", "er", "en", "et", "a", "e", "s"],
        "portuguese": ["amente", "mente", "ações", "ação", "es", "as", "os", "s", "a", "o", "e"],
        "romanian": ["ilor", "ului", "ele", "ea", "ii", "le", "ul", "i", "e", "a"],
        "russian": ["ами", "ями", "ов", "ев", "ий", "ый", "ая", "ое", "ей", "ом", "ах", "ях", "а", "я", "ы", "и", "у", "ю", "е", "о"],
        "spanish": ["amente", "aciones", "ación", "mente", "es", "as", "os", "s", "a", "o", "e"],
        "swedish": ["heterna", "heten", "heter", "arna", "erna", "orna", "ande", "ade", "are", "ar", "er", "or", "en", "et", "a", "e"],
        "arabic": ["ات", "ون", "ين", "ان", "ها", "ة", "ه"],
    }

    def __init__(self, language):
        self.language = language
        self.suffixes = sorted(self.SUFFIXES.get(language, []), key=len, reverse=True)

    def stem(self, word):
        w = word.lower()
        for s in self.suffixes:
            if w.endswith(s) and len(w) - len(s) >= 3:
                return w[: -len(s)]
        return w


class SnowballStemmer:
    # spec: N-000163 .. N-000167 N-000393 N-000394 N-000395
    languages = _LANGUAGES

    def __init__(self, language, ignore_stopwords=False):
        if language not in _LANGUAGES:
            raise ValueError("The language %r is not supported." % (language,))
        self.language = language
        self.stopwords = set()
        if ignore_stopwords:
            # spec: N-000172 N-000173 -- only this language's list counts
            f = data.find("corpora/stopwords/" + language)
            if os.path.isdir(f):
                raise LookupError("stopwords for %r not found" % language)
            self.stopwords = set(w.strip() for w in data.read_lines(f))
        if language == "english":
            self.stemmer = _EnglishStemmer()
        elif language == "porter":
            self.stemmer = PorterStemmer(PorterStemmer.ORIGINAL_ALGORITHM)
        else:
            self.stemmer = _SuffixStemmer(language)

    def stem(self, word):
        _check_word(word)
        w = word.lower()
        if w in self.stopwords:
            return w
        return self.stemmer.stem(w)


# --------------------------------------------------------------------------
# Arabic light stemmers (outside the specified behaviour)
# --------------------------------------------------------------------------
class ARLSTem:
    PREFIXES = ["وال", "بال", "كال", "فال", "ال", "لل", "و", "ف", "ب", "ك", "ل"]
    SUFFIXES = ["ات", "ون", "ين", "ان", "ها", "ة", "ه", "ي"]

    def stem(self, word):
        _check_word(word)
        for p in self.PREFIXES:
            if word.startswith(p) and len(word) - len(p) >= 3:
                word = word[len(p):]
                break
        for s in self.SUFFIXES:
            if word.endswith(s) and len(word) - len(s) >= 3:
                word = word[: -len(s)]
                break
        return word


class ARLSTem2(ARLSTem):
    pass


# --------------------------------------------------------------------------
# WordNet lemmatizer
# --------------------------------------------------------------------------
class WordNetLemmatizer:
    # spec: N-000396 N-000174
    _SUBS = {
        "n": [("s", ""), ("ses", "s"), ("ves", "f"), ("xes", "x"), ("zes", "z"),
              ("ches", "ch"), ("shes", "sh"), ("men", "man"), ("ies", "y")],
        "v": [("s", ""), ("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"),
              ("ed", ""), ("ing", "e"), ("ing", "")],
        "a": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
        "r": [],
    }
    _FILES = {"n": "noun", "v": "verb", "a": "adj", "r": "adv"}

    def __init__(self):
        self._dir = data.find("corpora/wordnet")
        self._index = {}

    def _words(self, pos):
        if pos not in self._index:
            words = set()
            p = os.path.join(self._dir, "index." + self._FILES[pos])
            if os.path.exists(p):
                for line in data.read_lines(p):
                    if line and not line.startswith(" "):
                        words.add(line.split(" ")[0])
            exc = {}
            p = os.path.join(self._dir, self._FILES[pos] + ".exc")
            if os.path.exists(p):
                for line in data.read_lines(p):
                    parts = line.split()
                    if len(parts) >= 2:
                        exc.setdefault(parts[0], parts[1])
            self._index[pos] = (words, exc)
        return self._index[pos]

    def lemmatize(self, word, pos="n"):
        _check_word(word)
        data.find("corpora/wordnet")
        if pos not in self._FILES:
            pos = "n"
        words, exc = self._words(pos)
        if word in exc:
            return exc[word]
        cands = [word]
        for suf, rep in self._SUBS[pos]:
            if word.endswith(suf):
                cands.append(word[: len(word) - len(suf)] + rep)
        found = [c for c in cands if c in words]
        return min(found, key=len) if found else word
