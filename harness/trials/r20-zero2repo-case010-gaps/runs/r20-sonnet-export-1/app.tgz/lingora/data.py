"""Packaged-resource lookup. # spec: N-000353 N-000354 N-000355 N-000356"""
import os

# spec: N-000356 initial contents are the implementer's choice
path = [p for p in os.environ.get("LINGORA_DATA", "").split(os.pathsep) if p]
path += [os.path.join(os.path.expanduser("~"), "lingora_data")]


def find(resource):
    """Return the first existing location of *resource* on ``path``.

    Raises LookupError when the resource is not visible."""
    # spec: N-000354 N-000355: only the listed directories are searched
    rel = resource.replace("\\", "/")
    parts = [p for p in rel.split("/") if p]
    if not parts or any(p in ("..", ".") for p in parts):
        raise LookupError("invalid resource name: %r" % (resource,))
    for d in list(path):
        cand = os.path.join(str(d), *parts)
        if os.path.exists(cand):
            return cand
    raise LookupError("resource %r not found in data.path" % (resource,))


def read_lines(filename):
    """Lines of a UTF-8 text file without line terminators. # spec: N-000366"""
    with open(filename, encoding="utf-8", newline="") as f:
        text = f.read()
    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    return [ln[:-1] if ln.endswith("\r") else ln for ln in lines]
