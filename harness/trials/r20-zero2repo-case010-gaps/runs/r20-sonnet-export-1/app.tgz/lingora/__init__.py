"""lingora: a pure-Python natural-language processing library."""
# spec: N-000338
__version__ = "0.1.0"
