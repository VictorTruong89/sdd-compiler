"""Chunking. # spec: N-000410 N-000411"""
import re

from lingora import data
from lingora.tree import Tree

__all__ = ["RegexpParser", "ne_chunk"]

ROOT_LABEL = "S"  # spec: N-000419 N-000420 (implementer's choice)


def _tag_pattern_to_re(pat):
    pat = re.sub(r"\s", "", pat)
    if not re.fullmatch(r"(<[^<>{}]*>(\?|\*|\+|\{\d+(,\d*)?\})?)+", pat) and \
            not re.fullmatch(r"(?:\(*<[^<>{}]*>(?:\?|\*|\+|\{\d+(?:,\d*)?\})?\)*(?:\|)?)+", pat):
        raise ValueError("Bad tag pattern: %r" % pat)
    pat = pat.replace("<", "(?:<(?:").replace(">", ")>)")
    pat = re.sub(r"(?<!\\)\.", r"[^\\{\\}<>]", pat)
    return pat


def _tag_of(tok):
    if isinstance(tok, Tree):
        return str(tok.label())
    return tok[1]


class _Rule:
    def __init__(self, kind, pattern):
        self.kind = kind
        body = _tag_pattern_to_re(pattern)
        if kind == "chunk":
            self.regexp = re.compile("(?P<chunk>%s)(?=[^\\}]*(\\{|$))" % body)
            self.repl = r"{\g<chunk>}"
        else:
            self.regexp = re.compile("(?P<chink>%s)(?=[^\\{]*\\})" % body)
            self.repl = r"}\g<chink>{"

    def apply(self, s):
        s = self.regexp.sub(self.repl, s)
        while "{}" in s:
            s = s.replace("{}", "")
        return s


class _Stage:
    def __init__(self, label, rules):
        self.label = label
        self.rules = rules

    def parse(self, tree):
        pieces = list(tree)
        for p in pieces:
            t = _tag_of(p)
            if re.search(r"[<>{}]", t):
                raise ValueError("tag contains reserved character: %r" % t)
        s = "".join("<%s>" % _tag_of(p) for p in pieces)
        for rule in self.rules:
            s = rule.apply(s)
        out = []
        index = 0
        in_chunk = False
        for piece in re.split("[{}]", s):
            n = piece.count("<")
            sub = pieces[index:index + n]
            if in_chunk:
                out.append(Tree(self.label, sub))
            else:
                out.extend(sub)
            index += n
            in_chunk = not in_chunk
        return Tree(tree.label(), out)


_CLAUSE = re.compile(r"^([^\s:{}][^:{}]*?)\s*:(.*)$")


class RegexpParser:
    # spec: N-000413 N-000414 N-000416 N-000417 N-000220 .. N-000235
    def __init__(self, grammar, root_label=ROOT_LABEL, loop=1):
        self._root_label = root_label
        self._loop = loop
        if isinstance(grammar, str):
            self._stages = self._parse_grammar(grammar)
        else:
            stages = list(grammar)
            if not all(isinstance(s, _Stage) for s in stages):
                raise TypeError("grammar must be a str or a list of chunk-parser stages")
            self._stages = stages

    @staticmethod
    def _parse_grammar(text):
        stages = []
        label = None
        rules = []

        def add_rule(line):
            line = re.sub(r"\s+#.*$", "", line.strip()) if "#" in line else line.strip()
            if not line:
                return
            if line.startswith("{") and line.endswith("}"):
                rules.append(_Rule("chunk", line[1:-1]))
            elif line.startswith("}") and line.endswith("{"):
                rules.append(_Rule("chink", line[1:-1]))
            else:
                raise ValueError("Illegal chunk pattern: %r" % line)

        for raw in text.split("\n"):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            m = _CLAUSE.match(line)
            if m:
                if label is not None:
                    stages.append(_Stage(label, rules))
                label, rules = m.group(1).strip(), []
                add_rule(m.group(2))
            elif label is not None:
                add_rule(line)
            else:
                raise ValueError("Illegal grammar line: %r" % raw)
        if label is not None:
            stages.append(_Stage(label, rules))
        if not stages:
            raise ValueError("grammar has no clauses")
        return stages

    def parse(self, tagged):
        if isinstance(tagged, (str, bytes)) or not isinstance(tagged, (list, tuple)):
            raise TypeError("expected a list of (token, tag) pairs")
        for p in tagged:
            if not isinstance(p, tuple) and not isinstance(p, list) or len(p) != 2:
                raise ValueError("expected (token, tag) pairs")
        tree = Tree(self._root_label, [tuple(p) for p in tagged])
        for _ in range(self._loop):
            for stage in self._stages:
                tree = stage.parse(tree)
        return tree


def ne_chunk(tagged_tokens, binary=False):
    # spec: N-000415 N-000219 N-000236
    if isinstance(tagged_tokens, (str, bytes)) or not isinstance(tagged_tokens, (list, tuple)):
        raise TypeError("expected a list of (token, tag) pairs")
    data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    data.find("corpora/words")
    # The model format is not specified; no entities are grouped.
    return Tree("S", [tuple(p) for p in tagged_tokens])
