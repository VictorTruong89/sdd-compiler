"""Classifiers. # spec: N-000455 N-000456"""
import math
from collections import Counter, OrderedDict

from lingora import metrics as _metrics  # noqa: F401

__all__ = ["NaiveBayesClassifier", "DecisionTreeClassifier", "accuracy", "DictionaryProbDist"]


class DictionaryProbDist:
    # spec: N-000459 N-000460
    def __init__(self, logprobs):
        m = max(logprobs.values()) if logprobs else 0.0
        if m == float("-inf"):
            self._p = {k: 1.0 / len(logprobs) for k in logprobs}
        else:
            exps = {k: math.exp(v - m) for k, v in logprobs.items()}
            z = sum(exps.values())
            self._p = {k: v / z for k, v in exps.items()}

    def prob(self, sample):
        return float(self._p.get(sample, 0.0))

    def samples(self):
        return list(self._p.keys())

    def max(self):
        return max(self._p, key=self._p.get)


class NaiveBayesClassifier:
    # spec: N-000277 .. N-000282
    def __init__(self, label_counts, feature_counts, feature_values):
        self._label_counts = label_counts
        self._feature_counts = feature_counts
        self._feature_values = feature_values
        self._labels = list(label_counts)

    @classmethod
    def train(cls, labeled_featuresets):
        label_counts = OrderedDict()
        fcounts = {}
        fvalues = {}
        fnames = []
        for fs, label in labeled_featuresets:
            label_counts[label] = label_counts.get(label, 0) + 1
            for fname, fval in fs.items():
                fcounts.setdefault((label, fname), Counter())[fval] += 1
                fvalues.setdefault(fname, set()).add(fval)
                if fname not in fnames:
                    fnames.append(fname)
        for label, n in label_counts.items():
            for fname in fnames:
                c = fcounts.setdefault((label, fname), Counter())
                missing = n - sum(c.values())
                if missing > 0:
                    c[None] += missing
                    fvalues[fname].add(None)
        return cls(label_counts, fcounts, fvalues)

    def labels(self):
        return list(self._labels)

    def _logprob_feature(self, label, fname, fval):
        c = self._feature_counts[(label, fname)]
        bins = len(self._feature_values[fname])
        n = sum(c.values())
        return math.log((c.get(fval, 0) + 0.5) / (n + 0.5 * bins))

    def prob_classify(self, featureset):
        total = sum(self._label_counts.values())
        fs = {k: v for k, v in featureset.items()
              if any((l, k) in self._feature_counts for l in self._labels)}
        logprob = {}
        for label in self._labels:
            lp = math.log((self._label_counts[label] + 0.5) / (total + 0.5 * len(self._labels)))
            for fname, fval in fs.items():
                if (label, fname) in self._feature_counts:
                    lp += self._logprob_feature(label, fname, fval)
            logprob[label] = lp
        return DictionaryProbDist(logprob)

    def classify(self, featureset):
        return self.prob_classify(featureset).max()


def _entropy(labels):
    c = Counter(labels)
    n = sum(c.values())
    return -sum(v / n * math.log2(v / n) for v in c.values()) if n else 0.0


class DecisionTreeClassifier:
    # spec: N-000283 .. N-000287
    def __init__(self, label, feature_name=None, decisions=None, default=None):
        self._label = label
        self._fname = feature_name
        self._decisions = decisions
        self._default = default

    def classify(self, featureset):
        if self._fname is None:
            return self._label
        fval = featureset.get(self._fname)
        try:
            if fval in self._decisions:
                return self._decisions[fval].classify(featureset)
        except TypeError:
            pass
        if self._default is not None:
            return self._default.classify(featureset)
        return self._label

    def error(self, labeled):
        errors = sum(1 for fs, l in labeled if self.classify(fs) != l)
        return errors / len(labeled) if labeled else 0.0

    @staticmethod
    def leaf(labeled):
        return DecisionTreeClassifier(Counter(l for _, l in labeled).most_common(1)[0][0])

    @staticmethod
    def stump(fname, labeled):
        label = Counter(l for _, l in labeled).most_common(1)[0][0]
        freqs = {}
        for fs, l in labeled:
            freqs.setdefault(fs.get(fname), Counter())[l] += 1
        decisions = {v: DecisionTreeClassifier(c.most_common(1)[0][0]) for v, c in freqs.items()}
        return DecisionTreeClassifier(label, fname, decisions, DecisionTreeClassifier(label))

    @staticmethod
    def best_stump(fnames, labeled):
        best = DecisionTreeClassifier.leaf(labeled)
        best_err = best.error(labeled)
        for fname in fnames:
            st = DecisionTreeClassifier.stump(fname, labeled)
            err = st.error(labeled)
            if err < best_err:
                best, best_err = st, err
        return best

    def refine(self, labeled, entropy_cutoff, depth_cutoff, support_cutoff):
        if len(labeled) <= support_cutoff or self._fname is None or depth_cutoff <= 0:
            return
        for fval in list(self._decisions):
            sub = [(fs, l) for fs, l in labeled if fs.get(self._fname) == fval]
            if sub and _entropy([l for _, l in sub]) > entropy_cutoff:
                self._decisions[fval] = DecisionTreeClassifier.train(
                    sub, entropy_cutoff, depth_cutoff, support_cutoff)
        if self._default is not None:
            sub = [(fs, l) for fs, l in labeled if fs.get(self._fname) not in self._decisions]
            if sub and _entropy([l for _, l in sub]) > entropy_cutoff:
                self._default = DecisionTreeClassifier.train(
                    sub, entropy_cutoff, depth_cutoff, support_cutoff)

    @classmethod
    def train(cls, labeled_featuresets, entropy_cutoff=0.05, depth_cutoff=100,
              support_cutoff=10):
        labeled = list(labeled_featuresets)
        if not labeled:
            raise ValueError("cannot train on an empty list")
        fnames = []
        for fs, _ in labeled:
            for k in fs:
                if k not in fnames:
                    fnames.append(k)
        tree = cls.best_stump(fnames, labeled)
        tree.refine(labeled, entropy_cutoff, depth_cutoff - 1, support_cutoff)
        return tree


def accuracy(classifier, gold):
    gold = list(gold)
    if not gold:
        return 0.0
    correct = sum(1 for fs, l in gold if classifier.classify(fs) == l)
    return correct / len(gold)
