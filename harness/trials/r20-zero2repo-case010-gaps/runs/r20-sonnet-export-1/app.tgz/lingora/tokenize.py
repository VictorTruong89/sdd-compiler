"""Tokenizers. # spec: N-000371 N-000372"""
import html
import os
import re
import string

from lingora import data

__all__ = ["RegexpTokenizer", "TreebankWordTokenizer", "TweetTokenizer",
           "WhitespaceTokenizer", "WordPunctTokenizer", "blankline_tokenize",
           "sent_tokenize", "word_tokenize", "wordpunct_tokenize"]


def _check_text(text):
    if not isinstance(text, str):
        raise TypeError("expected str, got %s" % type(text).__name__)


# --------------------------------------------------------------------------
# Regexp family
# --------------------------------------------------------------------------
class RegexpTokenizer:
    # spec: N-000109 N-000110 N-000111
    def __init__(self, pattern, gaps=False, discard_empty=True,
                 flags=re.UNICODE | re.MULTILINE | re.DOTALL):
        self._pattern = pattern
        self._gaps = gaps
        self._discard_empty = discard_empty
        self._regexp = re.compile(pattern, flags)

    def tokenize(self, text):
        _check_text(text)
        if self._gaps:
            toks = self._regexp.split(text)
            # re.split may inject groups; keep behaviour of pieces only
            if self._regexp.groups:
                toks = [text[a:b] for a, b in self.span_tokenize(text, _keep_empty=True)]
        else:
            toks = [m.group(0) for m in self._regexp.finditer(text)]
        if self._discard_empty:
            toks = [t for t in toks if t]
        return toks

    def span_tokenize(self, text, _keep_empty=False):
        # spec: N-000119 N-000120 N-000121
        _check_text(text)
        out = []
        if self._gaps:
            last = 0
            for m in self._regexp.finditer(text):
                out.append((last, m.start()))
                last = m.end()
            out.append((last, len(text)))
        else:
            out = [m.span() for m in self._regexp.finditer(text)]
        if self._discard_empty and not _keep_empty:
            out = [(a, b) for a, b in out if a != b]
        return iter(out) if not _keep_empty else out

    def __repr__(self):
        return "%s(pattern=%r, gaps=%r, discard_empty=%r)" % (
            type(self).__name__, self._pattern, self._gaps, self._discard_empty)


class WhitespaceTokenizer(RegexpTokenizer):
    # spec: N-000106
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s+", gaps=True)


class BlanklineTokenizer(RegexpTokenizer):
    # spec: N-000107 N-000108
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s*\n\s*\n\s*", gaps=True)


class WordPunctTokenizer(RegexpTokenizer):
    # spec: N-000085 N-000086 N-000087
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\w+|[^\w\s]+")


_wordpunct = WordPunctTokenizer()
_blankline = BlanklineTokenizer()


def wordpunct_tokenize(text):
    return _wordpunct.tokenize(text)


def blankline_tokenize(text):
    return _blankline.tokenize(text)


# --------------------------------------------------------------------------
# Penn Treebank tokenizers
# --------------------------------------------------------------------------
class TreebankWordTokenizer:
    # spec: N-000088 .. N-000098
    STARTING_QUOTES = [
        (re.compile(r'^\"'), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
    ]
    PUNCTUATION = [
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.\.\."), r" ... "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\']*)\s*$'), r"\1 \2\3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
    ]
    PARENS_BRACKETS = (re.compile(r"[\]\[\(\)\{\}\<\>]"), r" \g<0> ")
    DOUBLE_DASHES = (re.compile(r"--"), r" -- ")
    ENDING_QUOTES = [
        (re.compile(r'"'), " '' "),
        (re.compile(r"(\S)(\'\')"), r"\1 \2 "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    CONTRACTIONS2 = [re.compile(r) for r in (
        r"(?i)\b(can)(?#X)(not)\b", r"(?i)\b(d)(?#X)('ye)\b",
        r"(?i)\b(gim)(?#X)(me)\b", r"(?i)\b(gon)(?#X)(na)\b",
        r"(?i)\b(got)(?#X)(ta)\b", r"(?i)\b(lem)(?#X)(me)\b",
        r"(?i)\b(more)(?#X)('n)\b", r"(?i)\b(wan)(?#X)(na)(?=\s)")]
    CONTRACTIONS3 = [re.compile(r) for r in (
        r"(?i) ('t)(?#X)(is)\b", r"(?i) ('t)(?#X)(was)\b")]

    def tokenize(self, text):
        _check_text(text)
        for regexp, sub in self.STARTING_QUOTES:
            text = regexp.sub(sub, text)
        for regexp, sub in self.PUNCTUATION:
            text = regexp.sub(sub, text)
        regexp, sub = self.PARENS_BRACKETS
        text = regexp.sub(sub, text)
        regexp, sub = self.DOUBLE_DASHES
        text = regexp.sub(sub, text)
        text = " " + text + " "
        for regexp, sub in self.ENDING_QUOTES:
            text = regexp.sub(sub, text)
        for regexp in self.CONTRACTIONS2:
            text = regexp.sub(r" \1 \2 ", text)
        for regexp in self.CONTRACTIONS3:
            text = regexp.sub(r" \1 \2 ", text)
        return text.split()

    def span_tokenize(self, text):
        # spec: N-000119 .. N-000121
        _check_text(text)
        raw = self.tokenize(text)
        pos = 0
        for tok in raw:
            if tok in ("``", "''"):
                cands = [m for m in (text.find('"', pos), text.find(tok, pos)) if m >= 0]
                start = min(cands) if cands else -1
                length = 1 if (start >= 0 and text[start] == '"') else 2
            else:
                start = text.find(tok, pos)
                length = len(tok)
            if start < 0:
                raise ValueError("cannot align token %r" % tok)
            yield (start, start + length)
            pos = start + length


class NLTKWordTokenizer(TreebankWordTokenizer):
    """The recommended (improved Penn Treebank) word tokenizer."""
    # spec: N-000099 .. N-000103
    STARTING_QUOTES = [
        (re.compile(r"([«“‘„]|[`]+)", re.U), r" \1 "),
        (re.compile(r"^\""), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
        (re.compile(r"(?i)(\')(?!re|ve|ll|m|t|s|d|n)(\w)\b", re.U), r"\1 \2"),
    ]
    PUNCTUATION = [
        (re.compile(r'([^\.])(\.)([\]\)}>"\'»”’ ]*)\s*$', re.U), r"\1 \2 \3 "),
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.{2,}", re.U), r" \g<0> "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
        (re.compile(r"[*]", re.U), r" \g<0> "),
        (re.compile("[‒-―]"), r" \g<0> "),
    ]
    ENDING_QUOTES = [
        (re.compile(r"([»”’])", re.U), r" \1 "),
        (re.compile(r"''"), " '' "),
        (re.compile(r'"'), " '' "),
        (re.compile(r"\s+"), " "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]


_improved = NLTKWordTokenizer()
_treebank = TreebankWordTokenizer()


# --------------------------------------------------------------------------
# Punkt
# --------------------------------------------------------------------------
_ORTHO_BEG_UC = 2
_ORTHO_MID_UC = 4
_ORTHO_UNK_UC = 8
_ORTHO_BEG_LC = 16
_ORTHO_MID_LC = 32
_ORTHO_UNK_LC = 64
_ORTHO_UC = _ORTHO_BEG_UC + _ORTHO_MID_UC + _ORTHO_UNK_UC
_ORTHO_LC = _ORTHO_BEG_LC + _ORTHO_MID_LC + _ORTHO_UNK_LC

_RE_NUMERIC = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_RE_ELLIPSIS = re.compile(r"\.\.+$")
_RE_INITIAL = re.compile(r"[^\W\d]\.$", re.UNICODE)
_RE_ALPHA = re.compile(r"[^\W\d]+$", re.UNICODE)
_RE_NON_PUNCT = re.compile(r"[^\W\d]", re.UNICODE)

_SENT_END = ".?!"
_RE_WORD_START = r"[^\(\"\`{\[:;&\#\*@\)}\]\-,]"
_RE_NON_WORD = r"(?:[?!)\";}\]\*:@\'\({\[])"
_RE_MULTI = r"(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"
_WORD_TOKENIZE = re.compile(r"""(
        %(MultiChar)s
        |
        (?=%(WordStart)s)\S+?
        (?=
            \s|
            $|
            %(NonWord)s|%(MultiChar)s|
            ,(?=$|\s|%(NonWord)s|%(MultiChar)s)
        )
        |
        \S
    )""" % {"MultiChar": _RE_MULTI, "WordStart": _RE_WORD_START, "NonWord": _RE_NON_WORD},
    re.UNICODE | re.VERBOSE)
_PERIOD_CONTEXT = re.compile(r"""
        [.?!]
        (?=(?P<after_tok>
            %(NonWord)s
            |
            \s+(?P<next_tok>\S+)
        ))""" % {"NonWord": _RE_NON_WORD}, re.UNICODE | re.VERBOSE)
_BOUNDARY_REALIGN = re.compile(r'["\')\]}]+?(?:\s+|(?=--)|$)', re.MULTILINE)


class _PunktToken:
    __slots__ = ("tok", "type", "period_final", "parastart", "linestart", "sentbreak",
                 "abbr", "ellipsis", "first_upper", "first_lower", "is_initial",
                 "is_number")

    def __init__(self, tok, parastart=False, linestart=False):
        self.tok = tok
        self.type = _RE_NUMERIC.sub("##number##", tok.lower())
        self.period_final = tok.endswith(".")
        self.parastart = parastart
        self.linestart = linestart
        self.sentbreak = False
        self.abbr = False
        self.ellipsis = False
        self.first_upper = tok[0].isupper() if tok else False
        self.first_lower = tok[0].islower() if tok else False
        self.is_initial = bool(_RE_INITIAL.match(tok))
        self.is_number = self.type.startswith("##number##")

    @property
    def type_no_period(self):
        if len(self.type) > 1 and self.type[-1] == ".":
            return self.type[:-1]
        return self.type

    @property
    def type_no_sentperiod(self):
        return self.type_no_period if self.sentbreak else self.type


class PunktParameters:
    def __init__(self):
        self.abbrev_types = set()
        self.collocations = set()
        self.sent_starters = set()
        self.ortho_context = {}


def _load_punkt(language):
    # spec: N-000357 N-000367 N-000370 N-000381
    if not isinstance(language, str) or not language:
        raise ValueError("invalid language")
    d = data.find("tokenizers/punkt_tab/" + language)
    params = PunktParameters()
    try:
        params.abbrev_types = set(data.read_lines(os.path.join(d, "abbrev_types.txt")))
        params.sent_starters = set(data.read_lines(os.path.join(d, "sent_starters.txt")))
        for line in data.read_lines(os.path.join(d, "collocations.tab")):
            if not line.strip():
                continue
            a, b = line.split("\t")[:2]
            params.collocations.add((a, b))
        for line in data.read_lines(os.path.join(d, "ortho_context.tab")):
            if not line.strip():
                continue
            t, n = line.split("\t")[:2]
            params.ortho_context[t] = int(n)
    except OSError as e:
        raise LookupError("Punkt model for %r is incomplete: %s" % (language, e))
    return params


class PunktSentenceTokenizer:
    def __init__(self, params):
        self._params = params

    def _tokenize_words(self, plaintext):
        parastart = False
        for line in plaintext.split("\n"):
            if line.strip():
                line_toks = _WORD_TOKENIZE.findall(line)
                if not line_toks:
                    continue
                yield _PunktToken(line_toks[0], parastart=parastart, linestart=True)
                for t in line_toks[1:]:
                    yield _PunktToken(t)
                parastart = False
            else:
                parastart = True

    def _first_pass(self, aug):
        tok = aug.tok
        if tok in _SENT_END:
            aug.sentbreak = True
        elif _RE_ELLIPSIS.match(tok):
            aug.ellipsis = True
        elif aug.period_final and not tok.endswith(".."):
            base = tok[:-1].lower()
            if base in self._params.abbrev_types or base.split("-")[-1] in self._params.abbrev_types:
                aug.abbr = True
            else:
                aug.sentbreak = True

    def _ortho_heuristic(self, tok):
        if tok.tok in tuple(";:,.!?"):
            return False
        oc = self._params.ortho_context.get(tok.type_no_sentperiod, 0)
        if tok.first_upper and (oc & _ORTHO_LC) and not (oc & _ORTHO_MID_UC):
            return True
        if tok.first_lower and ((oc & _ORTHO_UC) or not (oc & _ORTHO_BEG_LC)):
            return False
        return "unknown"

    def _second_pass(self, t1, t2):
        if t2 is None or not t1.period_final:
            return
        typ = t1.type_no_period
        next_typ = t2.type_no_sentperiod
        initial = t1.is_initial
        if (typ, next_typ) in self._params.collocations:
            t1.sentbreak = False
            t1.abbr = True
            return
        if (t1.abbr or t1.ellipsis) and not initial:
            starter = self._ortho_heuristic(t2)
            if starter is True:
                t1.sentbreak = True
                return
            if t2.first_upper and next_typ in self._params.sent_starters:
                t1.sentbreak = True
                return
        if initial or typ == "##number##":
            starter = self._ortho_heuristic(t2)
            if starter is False:
                t1.sentbreak = False
                t1.abbr = True
                return
            if (starter == "unknown" and initial and t2.first_upper
                    and not (self._params.ortho_context.get(next_typ, 0) & _ORTHO_LC)):
                t1.sentbreak = False
                t1.abbr = True
                return

    def _annotate(self, text):
        toks = list(self._tokenize_words(text))
        for t in toks:
            self._first_pass(t)
        for i, t in enumerate(toks):
            self._second_pass(t, toks[i + 1] if i + 1 < len(toks) else None)
        return toks

    def _contains_break(self, text):
        found = False
        for tok in self._annotate(text):
            if found:
                return True
            if tok.sentbreak:
                found = True
        return False

    @staticmethod
    def _last_ws(text):
        for i in range(len(text) - 1, -1, -1):
            if text[i] in string.whitespace:
                return i
        return 0

    def _potential_ends(self, text):
        prev_slice = slice(0, 0)
        prev_match = None
        for match in _PERIOD_CONTEXT.finditer(text):
            before = text[prev_slice.stop:match.start()]
            idx = self._last_ws(before)
            if idx:
                idx += prev_slice.stop + 1
            else:
                idx = prev_slice.start
            cur = slice(idx, match.start())
            if prev_match and prev_slice.stop <= cur.start:
                yield prev_match, text[prev_slice] + prev_match.group() + prev_match.group("after_tok")
            prev_match = match
            prev_slice = cur
        if prev_match:
            yield prev_match, text[prev_slice] + prev_match.group() + prev_match.group("after_tok")

    def _slices(self, text):
        last = 0
        for match, context in self._potential_ends(text):
            if self._contains_break(context):
                yield slice(last, match.end())
                if match.group("next_tok"):
                    last = match.start("next_tok")
                else:
                    last = match.end()
        yield slice(last, len(text.rstrip()))

    def _realign(self, text, slices):
        slices = list(slices)
        realign = 0
        for i, s1 in enumerate(slices):
            s2 = slices[i + 1] if i + 1 < len(slices) else None
            s1 = slice(s1.start + realign, s1.stop)
            if s2 is None:
                if text[s1]:
                    yield s1
                continue
            m = _BOUNDARY_REALIGN.match(text[s2])
            if m:
                yield slice(s1.start, s2.start + len(m.group(0).rstrip()))
                realign = m.end()
            else:
                realign = 0
                if text[s1]:
                    yield s1

    def span_tokenize(self, text):
        return [(s.start, s.stop) for s in self._realign(text, self._slices(text))]

    def tokenize(self, text):
        # spec: N-000122 .. N-000126
        return [text[a:b] for a, b in self.span_tokenize(text)]


def sent_tokenize(text, language="english"):
    """Sentences of *text* using the packaged Punkt model. # spec: N-000122"""
    # model first, so a missing model fails even for empty text (N-000130)
    tok = PunktSentenceTokenizer(_load_punkt(language))
    _check_text(text)
    return tok.tokenize(text)


def word_tokenize(text, language="english", preserve_line=False):
    # spec: N-000104 N-000105 N-000377 N-000378
    _check_text(text)
    sentences = [text] if preserve_line else sent_tokenize(text, language)
    return [t for s in sentences for t in _improved.tokenize(s)]


# --------------------------------------------------------------------------
# Tweet tokenizer
# --------------------------------------------------------------------------
_EMOTICONS = r"""
    (?:
      [<>]?
      [:;=8]
      [\-o\*\']?
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      |
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      [\-o\*\']?
      [:;=8]
      [<>]?
      |
      </?3
    )"""
_URLS = r"""
    (?:
      https?:
        (?:/{1,3}|[a-z0-9%])
      |
      [a-z0-9.\-]+[.][a-z]{2,4}/
    )
    (?:[^\s()<>]+|\([^\s()<>]+\))+
    (?:\([^\s()<>]+\)|[^\s`!()\[\]{};:'".,<>?«»“”‘’])
    """
_PHONE = r"""
    (?:
      (?:\+?[01][ *\-.\)]*)?
      (?:[\(]?\d{3}[ *\-.\)]*)?
      \d{3}[ *\-.\)]*
      \d{4}
    )"""
_HANDLE = r"(?<![A-Za-z0-9_!@#\$%&*])@(?:[A-Za-z0-9_]{1,15})(?![A-Za-z0-9_@])"
_HASHTAG = r"(?:\#+[\w_]+[\w\'_\-]*[\w_]+)"
_TOKEN_PARTS = [
    _PHONE, _URLS, _EMOTICONS,
    r"(?:<[^>\s]+>)",
    r"(?:[\-]+>|<[\-]+)",
    r"(?:<[^>\s]+>)",
    _HANDLE, _HASHTAG,
    r"(?:[^\W\d_](?:[^\W\d_]|['\-_])+[^\W\d_])",
    r"(?:[+\-]?\d+[,/.:-]\d+[+\-]?)",
    r"(?:[\w_]+)",
    r"(?:\.(?:\s*\.){1,})",
    r"(?:\S)",
]
_WORD_RE = re.compile("(%s)" % "|".join(_TOKEN_PARTS), re.VERBOSE | re.I | re.UNICODE)
_EMOTICON_RE = re.compile(_EMOTICONS, re.VERBOSE | re.I | re.UNICODE)
_HANG_RE = re.compile(r"([^a-zA-Z0-9])\1{3,}")
_HANDLES_RE = re.compile(_HANDLE)
_LENGTHEN_RE = re.compile(r"(.)\1{2,}", re.DOTALL)


class TweetTokenizer:
    # spec: N-000112 .. N-000118
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self.preserve_case = preserve_case
        self.reduce_len = reduce_len
        self.strip_handles = strip_handles

    def tokenize(self, text):
        _check_text(text)
        if self.strip_handles:
            text = _HANDLES_RE.sub(" ", text)
        if self.reduce_len:
            text = _LENGTHEN_RE.sub(r"\1\1\1", text)
        safe = _HANG_RE.sub(r"\1\1\1", text)
        words = [m.group(0) for m in _WORD_RE.finditer(safe)]
        if not self.preserve_case:
            words = [w if _EMOTICON_RE.fullmatch(w) else w.lower() for w in words]
        return words
