"""Parsers. # spec: N-000424 N-000425 N-000426"""
from lingora.grammar import CFG, Nonterminal
from lingora.tree import Tree

__all__ = ["ChartParser", "ShiftReduceParser", "RecursiveDescentParser"]


def _check(grammar, tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")  # spec: N-000435
    for t in tokens:
        if not isinstance(t, str):
            raise TypeError("tokens must be a list of str")
    grammar.check_coverage(tokens)  # spec: N-000438 N-000439


class ChartParser:
    """Exhaustive parser. # spec: N-000242 .. N-000246"""

    def __init__(self, grammar, **kw):
        self._grammar = grammar
        self._by_lhs = {}
        for p in grammar.productions():
            self._by_lhs.setdefault(p.lhs(), []).append(p)

    def parse(self, tokens):
        tokens = list(tokens) if isinstance(tokens, tuple) else tokens
        _check(self._grammar, tokens)
        return iter(self._parse(tokens))

    def _parse(self, tokens):
        n = len(tokens)
        memo = {}
        active = set()

        def sym_trees(sym, i, j):
            """All trees for nonterminal sym over [i, j); returns (trees, tainted)."""
            key = (sym, i, j)
            if key in memo:
                return memo[key], False
            if key in active:
                return [], True
            active.add(key)
            trees = []
            tainted = False
            for prod in self._by_lhs.get(sym, []):
                for children, t in seq(prod.rhs(), 0, i, j):
                    tainted = tainted or t
                    trees.append(Tree(str(sym), children))
            active.discard(key)
            if not tainted:
                memo[key] = trees
            return trees, tainted

        def seq(rhs, k, i, j):
            """Yield (children list, tainted) for rhs[k:] spanning [i, j)."""
            if k == len(rhs):
                if i == j:
                    yield [], False
                return
            item = rhs[k]
            if isinstance(item, str):
                if item == "":
                    for ch, t in seq(rhs, k + 1, i, j):
                        yield ch, t
                elif i < j and tokens[i] == item:
                    for ch, t in seq(rhs, k + 1, i + 1, j):
                        yield [item] + ch, t
                return
            for m in range(i, j + 1):
                sub, t1 = sym_trees(item, i, m)
                if not sub:
                    continue
                for ch, t2 in seq(rhs, k + 1, m, j):
                    for s in sub:
                        yield [s] + ch, t1 or t2

        trees, _ = sym_trees(self._grammar.start(), 0, n)
        return trees


class RecursiveDescentParser(ChartParser):
    pass


class ShiftReduceParser:
    """Single left-to-right pass without backtracking. # spec: N-000247 .. N-000250"""

    def __init__(self, grammar, **kw):
        self._grammar = grammar
        self._prods = [p for p in grammar.productions() if len(p.rhs()) > 0]

    def parse(self, tokens):
        tokens = list(tokens) if isinstance(tokens, tuple) else tokens
        _check(self._grammar, tokens)
        return iter(self._parse(tokens))

    @staticmethod
    def _match(item, sym):
        if isinstance(sym, str):
            return isinstance(item, str) and item == sym
        return isinstance(item, Tree) and item.label() == str(sym)

    def _reduce(self, stack):
        for p in self._prods:
            rhs = p.rhs()
            n = len(rhs)
            if n <= len(stack) and all(self._match(stack[len(stack) - n + i], rhs[i])
                                       for i in range(n)):
                tree = Tree(str(p.lhs()), stack[-n:])
                stack[-n:] = [tree]
                return True
        return False

    def _parse(self, tokens):
        stack = []
        remaining = list(tokens)
        while remaining:
            stack.append(remaining.pop(0))
            while self._reduce(stack):
                pass
        if len(stack) == 1 and isinstance(stack[0], Tree) \
                and stack[0].label() == str(self._grammar.start()):
            return [stack[0]]
        return []
