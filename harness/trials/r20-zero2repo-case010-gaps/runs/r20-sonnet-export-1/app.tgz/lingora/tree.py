"""Constituent trees. # spec: N-000444 N-000445"""
import re

__all__ = ["Tree"]


class Tree(list):
    # spec: N-000446 .. N-000454
    def __init__(self, label, children):
        # spec: N-000449 N-000450 N-000451
        if children is None or isinstance(children, (str, bytes)):
            raise TypeError("%s: Expected a label and a list of children, not %r"
                            % (type(self).__name__, type(children).__name__))
        list.__init__(self, children)
        self._label = label

    # equality -----------------------------------------------------------
    def __eq__(self, other):
        return (isinstance(other, Tree) and self._label == other._label
                and list.__eq__(self, other))

    def __ne__(self, other):
        return not self == other

    __hash__ = None

    def __lt__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return (str(self._label), list(self)) < (str(other._label), list(other))

    def label(self):
        return self._label

    def set_label(self, label):
        self._label = label

    def leaves(self):
        out = []
        for child in self:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def height(self):
        h = 1
        for c in self:
            if isinstance(c, Tree):
                h = max(h, c.height() + 1)
            else:
                h = max(h, 2)
        return h

    def subtrees(self, filter=None):
        if not filter or filter(self):
            yield self
        for c in self:
            if isinstance(c, Tree):
                yield from c.subtrees(filter)

    def copy(self, deep=False):
        import copy
        return copy.deepcopy(self) if deep else Tree(self._label, list(self))

    def pos(self):
        out = []
        for c in self:
            if isinstance(c, Tree):
                out.extend(c.pos())
            else:
                out.append((c, self._label))
        return out

    def flatten(self):
        return Tree(self._label, self.leaves())

    # text ---------------------------------------------------------------
    def pformat(self, margin=70, indent=0, **kw):
        s = self._oneline()
        if len(s) + indent < margin:
            return s
        parts = ["(%s" % (self._label,)]
        for c in self:
            if isinstance(c, Tree):
                parts.append("\n" + " " * (indent + 2) + c.pformat(margin, indent + 2))
            else:
                parts.append("\n" + " " * (indent + 2) + str(c))
        return "".join(parts) + ")"

    def _oneline(self):
        inner = " ".join(c._oneline() if isinstance(c, Tree) else str(c) for c in self)
        return "(%s %s)" % (self._label, inner) if inner else "(%s )" % (self._label,)

    def __str__(self):
        return self.pformat()

    def __repr__(self):
        return "Tree(%r, %s)" % (self._label, list.__repr__(self))

    # parsing ------------------------------------------------------------
    @classmethod
    def fromstring(cls, s, brackets="()"):
        if not isinstance(s, str):
            raise TypeError("expected str")
        toks = re.findall(r"\(|\)|[^\s()]+", s)
        if not toks:
            raise ValueError("empty tree text")
        pos = 0

        def node():
            nonlocal pos
            if toks[pos] != "(":
                raise ValueError("expected '(' at token %d" % pos)
            pos += 1
            label = ""
            if pos < len(toks) and toks[pos] not in "()":
                label = toks[pos]
                pos += 1
            children = []
            while True:
                if pos >= len(toks):
                    raise ValueError("unbalanced brackets: missing ')'")
                t = toks[pos]
                if t == ")":
                    pos += 1
                    return cls(label, children)
                if t == "(":
                    children.append(node())
                else:
                    children.append(t)
                    pos += 1

        tree = node()
        if pos != len(toks):
            raise ValueError("unbalanced brackets: extra text after tree")
        return tree
