from lingora.tokenize import wordpunct_tokenize, TreebankWordTokenizer
from lingora.stem import PorterStemmer
from lingora.metrics import edit_distance, precision
from lingora.tree import Tree


def test_wordpunct():
    assert wordpunct_tokenize("Hi, you!") == ["Hi", ",", "you", "!"]


def test_treebank():
    assert TreebankWordTokenizer().tokenize("I cannot go.") == ["I", "can", "not", "go", "."]


def test_porter():
    assert PorterStemmer().stem("ponies") == "poni"


def test_metrics():
    assert edit_distance("", "") == 0
    assert precision({1}, set()) is None


def test_tree():
    assert Tree.fromstring("(S (NP I))") == Tree("S", [Tree("NP", ["I"])])
