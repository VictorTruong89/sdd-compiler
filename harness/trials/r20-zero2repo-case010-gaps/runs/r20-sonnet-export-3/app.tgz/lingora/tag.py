"""Taggers. spec: N-000397..N-000409, FP-03"""
import json
import os
import re
from collections import defaultdict, Counter

from . import data


class TaggerI:
    def tag(self, tokens):
        raise NotImplementedError


def _check_tokens(tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str, not a string")


class SequentialBackoffTagger(TaggerI):
    def __init__(self, backoff=None):
        self._backoff = backoff

    def tag(self, tokens):
        _check_tokens(tokens)
        history = []
        for i in range(len(tokens)):
            t = self.tag_one(tokens, i, history)
            history.append(t)
        return list(zip(tokens, history))

    def tag_one(self, tokens, index, history):
        tag = self.choose_tag(tokens, index, history)
        if tag is None and self._backoff is not None:
            tag = self._backoff.tag_one(tokens, index, history)
        return tag


class DefaultTagger(SequentialBackoffTagger):
    def __init__(self, tag):
        super().__init__(None)
        self._tag = tag

    def choose_tag(self, tokens, index, history):
        return self._tag


class RegexpTagger(SequentialBackoffTagger):
    def __init__(self, regexps, backoff=None):
        super().__init__(backoff)
        self._regexps = [(re.compile(r), t) for r, t in regexps]

    def choose_tag(self, tokens, index, history):
        for rx, t in self._regexps:
            if rx.match(tokens[index]):
                return t
        return None


class ContextTagger(SequentialBackoffTagger):
    def __init__(self, context_to_tag, backoff=None):
        super().__init__(backoff)
        self._context_to_tag = context_to_tag or {}

    def context(self, tokens, index, history):
        raise NotImplementedError

    def choose_tag(self, tokens, index, history):
        c = self.context(tokens, index, history)
        return self._context_to_tag.get(c)

    def _train(self, train):
        counts = defaultdict(Counter)
        for sent in train:
            tokens = [w for w, _ in sent]
            history = []
            for i, (w, t) in enumerate(sent):
                c = self.context(tokens, i, history)
                if c is not None:
                    counts[c][t] += 1
                history.append(t)
        # most frequent tag; ties: first seen (N-000189 implementer's choice)
        self._context_to_tag = {c: cnt.most_common(1)[0][0] for c, cnt in counts.items()}


class NgramTagger(ContextTagger):
    _n = 1

    def __init__(self, train=None, model=None, backoff=None, cutoff=0):
        super().__init__(model, backoff)
        if train is not None:
            self._train(train)

    def context(self, tokens, index, history):
        n = self._n
        if n == 1:
            return tokens[index]
        tags = tuple(history[max(0, index - n + 1):index])
        if len(tags) < n - 1:
            tags = (None,) * (n - 1 - len(tags)) + tags
        return tags, tokens[index]


class UnigramTagger(NgramTagger):
    _n = 1


class BigramTagger(NgramTagger):
    _n = 2


class TrigramTagger(NgramTagger):
    _n = 3


class AffixTagger(ContextTagger):
    def __init__(self, train=None, model=None, affix_length=-3, min_stem_length=2, backoff=None):
        super().__init__(model, backoff)
        self._affix_length = affix_length
        self._min_word_length = min_stem_length + abs(affix_length)
        if train is not None:
            self._train(train)

    def context(self, tokens, index, history):
        w = tokens[index]
        if len(w) < self._min_word_length:
            return None
        return w[self._affix_length:] if self._affix_length > 0 else w[self._affix_length:]


# ---------------------------------------------------------------- perceptron
_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]
_cache = {}


class _Perceptron:
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = classes

    @staticmethod
    def normalize(word):
        if "-" in word and word[0] != "-":
            return "!HYPHEN"
        if word.isdigit() and len(word) == 4:
            return "!YEAR"
        if word and word[0].isdigit():
            return "!DIGITS"
        return word.lower()

    def _features(self, i, word, context, prev, prev2):
        feats = defaultdict(int)

        def add(name, *args):
            feats[" ".join((name,) + tuple(args))] += 1

        i += len(_START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return feats

    def predict(self, feats):
        scores = defaultdict(float)
        for f, v in feats.items():
            w = self.weights.get(f)
            if w is None or v == 0:
                continue
            for label, weight in w.items():
                scores[label] += v * weight
        return max(self.classes, key=lambda l: (scores[l], l))

    def tag(self, tokens):
        prev, prev2 = _START
        out = []
        context = _START + [self.normalize(w) for w in tokens] + _END
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                tag = self.predict(self._features(i, word, context, prev, prev2))
            out.append((word, tag))
            prev2 = prev
            prev = tag
        return out


def _load_model(lang):
    d = data.find("taggers/averaged_perceptron_tagger_%s" % lang)
    base = os.path.join(d, "averaged_perceptron_tagger_%s" % lang)
    paths = [base + s for s in (".weights.json", ".tagdict.json", ".classes.json")]
    key = tuple((p, os.stat(p).st_mtime_ns) for p in paths)  # raises OSError if missing
    if key in _cache:
        return _cache[key]
    loaded = []
    for p in paths:
        with open(p, encoding="utf-8") as f:
            loaded.append(json.load(f))
    m = _Perceptron(loaded[0], loaded[1], loaded[2])
    _cache.clear()
    _cache[key] = m
    return m


_RU_UNIVERSAL = {
    "A": "ADJ", "A-PRO": "DET", "ADV": "ADV", "ADV-PRO": "ADV", "ANUM": "ADJ", "CONJ": "CONJ",
    "INTJ": "X", "NONLEX": ".", "NUM": "NUM", "PARENTH": "PRT", "PART": "PRT", "PR": "ADP",
    "PRAEDIC": "PRT", "PRAEDIC-PRO": "PRON", "S": "NOUN", "S-PRO": "PRON", "V": "VERB",
    "COM": "X",
}


def _load_ptb_map():
    d = data.find("taggers/universal_tagset")
    p = os.path.join(d, "en-ptb.map")
    m = {}
    for line in data.read_lines(p):
        if not line.strip():
            continue
        parts = line.split("\t")
        if len(parts) >= 2:
            m[parts[0]] = parts[1].strip()
    return m


def pos_tag(tokens, tagset=None, lang="eng"):
    _check_tokens(tokens)
    if lang not in ("eng", "rus"):
        raise NotImplementedError("Currently, lingora pos_tag only supports English and Russian (lang='eng' or 'rus')")
    if tagset not in (None, "universal"):
        raise ValueError("unsupported tagset %r" % (tagset,))
    model = _load_model(lang)
    tagged = model.tag(list(tokens))
    if tagset == "universal":
        if lang == "rus":
            return [(w, _RU_UNIVERSAL.get(t.partition("=")[0], "X")) for w, t in tagged]
        mp = _load_ptb_map()
        return [(w, mp.get(t, "X")) for w, t in tagged]
    return tagged
