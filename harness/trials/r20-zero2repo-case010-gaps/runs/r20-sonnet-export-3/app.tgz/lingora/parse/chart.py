"""Chart, shift-reduce and recursive-descent parsers. spec: N-000435..N-000439, FP-05"""
from ..grammar import Nonterminal
from ..tree import Tree


def _check_tokens(tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")


class ChartParser:
    def __init__(self, grammar, **kwargs):
        self._grammar = grammar

    def grammar(self):
        return self._grammar

    def parse(self, tokens, tree_class=Tree):
        _check_tokens(tokens)
        tokens = list(tokens)
        self._grammar.check_coverage(tokens)  # raises on uncovered token (N-000438)
        return iter(self._parse_all(tokens, tree_class))

    def _parse_all(self, tokens, tree_class):
        g = self._grammar
        n = len(tokens)
        memo = {}
        active = set()
        tripped = [False]

        def derive(sym, i, j):
            """All trees for nonterminal sym over tokens[i:j]."""
            key = (sym, i, j)
            if key in memo:
                return memo[key]
            if key in active:
                tripped[0] = True
                return []
            active.add(key)
            before = tripped[0]
            tripped[0] = False
            out = []
            for prod in g.productions(sym):
                for kids in seq(list(prod.rhs()), i, j):
                    out.append(tree_class(str(sym), kids))
            active.discard(key)
            if not tripped[0]:
                memo[key] = out
            tripped[0] = tripped[0] or before
            return out

        def seq(rhs, i, j):
            """Lists of children deriving tokens[i:j]."""
            if not rhs:
                if i == j:
                    yield []
                return
            first, rest = rhs[0], rhs[1:]
            if isinstance(first, Nonterminal):
                for k in range(i, j + 1):
                    for t in derive(first, i, k):
                        for r in seq(rest, k, j):
                            yield [t] + r
            else:
                if first == "" :
                    for r in seq(rest, i, j):
                        yield [""] + r
                elif i < j and tokens[i] == first:
                    for r in seq(rest, i + 1, j):
                        yield [first] + r

        return derive(g.start(), 0, n)


class ShiftReduceParser:
    def __init__(self, grammar, trace=0):
        self._grammar = grammar

    def grammar(self):
        return self._grammar

    def parse(self, tokens):
        _check_tokens(tokens)
        tokens = list(tokens)
        self._grammar.check_coverage(tokens)
        stack = []
        remaining = list(tokens)
        prods = [p for p in self._grammar.productions() if len(p.rhs()) > 0]
        while True:
            while self._reduce(stack, prods):
                pass
            if remaining:
                stack.append(remaining.pop(0))
            else:
                break
        if len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == str(self._grammar.start()):
            return iter([stack[0]])
        return iter([])

    @staticmethod
    def _match(rhs, stack_tail):
        for sym, el in zip(rhs, stack_tail):
            if isinstance(sym, Nonterminal):
                if not (isinstance(el, Tree) and el.label() == str(sym)):
                    return False
            else:
                if not (isinstance(el, str) and el == sym):
                    return False
        return True

    def _reduce(self, stack, prods):
        for p in prods:
            rhs = p.rhs()
            if len(stack) >= len(rhs) and self._match(rhs, stack[len(stack) - len(rhs):]):
                kids = stack[len(stack) - len(rhs):]
                del stack[len(stack) - len(rhs):]
                stack.append(Tree(str(p.lhs()), kids))
                return True
        return False


class RecursiveDescentParser(ChartParser):
    """Exhaustive parser; same results as the chart parser."""
