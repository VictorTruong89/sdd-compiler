"""Snowball stemming algorithms (re-implemented from the published algorithm descriptions)."""
import re


def get(language):
    return _REGISTRY[language]


def _r1r2(word, vowels):
    r1 = ""
    for i in range(1, len(word)):
        if word[i] not in vowels and word[i - 1] in vowels:
            r1 = word[i + 1:]
            break
    r2 = ""
    for i in range(1, len(r1)):
        if r1[i] not in vowels and r1[i - 1] in vowels:
            r2 = r1[i + 1:]
            break
    return r1, r2


def _r1_only(word, vowels):
    r1 = ""
    for i in range(1, len(word)):
        if word[i] not in vowels and word[i - 1] in vowels:
            r1 = word[i + 1:]
            break
    return r1


def _longest(word, suffixes):
    best = ""
    for s in suffixes:
        if len(s) > len(best) and word.endswith(s):
            best = s
    return best


# ====================================================================== English (Porter2)
_EN_V = "aeiouy"
_EN_SPECIAL = {"skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
               "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli",
               "singly": "singl", "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas",
               "cosmos": "cosmos", "bias": "bias", "andes": "andes"}
_EN_STEP2 = [("ization", "ize"), ("ational", "ate"), ("fulness", "ful"), ("ousness", "ous"), ("iveness", "ive"),
             ("tional", "tion"), ("biliti", "ble"), ("lessli", "less"), ("entli", "ent"), ("ation", "ate"),
             ("alism", "al"), ("aliti", "al"), ("ousli", "ous"), ("iviti", "ive"), ("fulli", "ful"),
             ("enci", "ence"), ("anci", "ance"), ("abli", "able"), ("izer", "ize"), ("ator", "ate"),
             ("alli", "al"), ("bli", "ble"), ("ogi", "og"), ("li", "")]
_EN_STEP3 = [("ational", "ate"), ("tional", "tion"), ("alize", "al"), ("icate", "ic"), ("iciti", "ic"),
             ("ative", ""), ("ical", "ic"), ("ness", ""), ("ful", "")]
_EN_STEP4 = ["ement", "ance", "ence", "able", "ible", "ment", "ant", "ent", "ism", "ate", "iti", "ous", "ive",
             "ize", "ion", "al", "er", "ic"]


def _en_short_syllable_end(w):
    if len(w) == 2:
        return w[0] in _EN_V and w[1] not in _EN_V
    if len(w) >= 3:
        return (w[-3] not in _EN_V and w[-2] in _EN_V and w[-1] not in _EN_V and w[-1] not in "wxY")
    return False


def _p1p2(word, vowels, special=()):
    p1 = len(word)
    for pre in special:
        if word.startswith(pre):
            p1 = len(pre)
            break
    else:
        for i in range(1, len(word)):
            if word[i] not in vowels and word[i - 1] in vowels:
                p1 = i + 1
                break
    p2 = len(word)
    for i in range(p1 + 1, len(word)):
        if word[i] not in vowels and word[i - 1] in vowels:
            p2 = i + 1
            break
    return p1, p2


def english(word):
    if len(word) <= 2:
        return word
    if word in _EN_SPECIAL:
        return _EN_SPECIAL[word]
    word = word.replace("\u2019", "'").replace("\u2018", "'").replace("\u201b", "'")
    if word.startswith("'"):
        word = word[1:]
    if word.startswith("y"):
        word = "Y" + word[1:]
    chars = list(word)
    for i in range(1, len(chars)):
        if chars[i - 1] in _EN_V and chars[i] == "y":
            chars[i] = "Y"
    word = "".join(chars)
    vow = _EN_V
    p1, p2 = _p1p2(word, vow, ("gener", "commun", "arsen"))

    def in1(suf):
        return len(word) - len(suf) >= p1

    def in2(suf):
        return len(word) - len(suf) >= p2

    def short_word():
        return p1 >= len(word) and _en_short_syllable_end(word)

    # step 0
    s = _longest(word, ["'s'", "'s", "'"])
    if s:
        word = word[:-len(s)]
    # step 1a
    if word.endswith("sses"):
        word = word[:-2]
    elif word.endswith(("ied", "ies")):
        word = word[:-2] if len(word) > 4 else word[:-1]
    elif word.endswith(("us", "ss")):
        pass
    elif word.endswith("s"):
        if any(c in vow for c in word[:-2]):
            word = word[:-1]
    if word in ("inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed"):
        return word
    # step 1b
    s = _longest(word, ["eedly", "ingly", "edly", "eed", "ing", "ed"])
    if s in ("eed", "eedly"):
        if in1(s):
            word = word[:-len(s)] + "ee"
    elif s:
        pre = word[:-len(s)]
        if any(c in vow for c in pre):
            word = pre
            if word.endswith(("at", "bl", "iz")):
                word += "e"
            elif word.endswith(("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")):
                word = word[:-1]
            elif short_word():
                word += "e"
    # step 1c
    if len(word) > 2 and word[-1] in "yY" and word[-2] not in vow:
        word = word[:-1] + "i"
    # step 2
    for suf, rep in _EN_STEP2:
        if word.endswith(suf):
            if in1(suf):
                if suf == "ogi":
                    if word[:-3].endswith("l"):
                        word = word[:-3] + rep
                elif suf == "li":
                    if len(word) >= 3 and word[-3] in "cdeghkmnrt":
                        word = word[:-2]
                else:
                    word = word[:-len(suf)] + rep
            break
    # step 3
    for suf, rep in _EN_STEP3:
        if word.endswith(suf):
            if suf == "ative":
                if in2(suf):
                    word = word[:-5]
            elif in1(suf):
                word = word[:-len(suf)] + rep
            break
    # step 4
    best = _longest(word, _EN_STEP4)
    if best and in2(best):
        if best == "ion":
            if len(word) >= 4 and word[-4] in "st":
                word = word[:-3]
        else:
            word = word[:-len(best)]
    # step 5
    if word.endswith("e"):
        if in2("e") or (in1("e") and not _en_short_syllable_end(word[:-1])):
            word = word[:-1]
    elif word.endswith("l"):
        if in2("l") and word[-2:-1] == "l":
            word = word[:-1]
    return word.replace("Y", "y")


# ====================================================================== Porter (original)
def porter(word):
    from .stem import PorterStemmer
    global _porter_inst
    try:
        _porter_inst
    except NameError:
        _porter_inst = PorterStemmer(PorterStemmer.ORIGINAL_ALGORITHM)
    return _porter_inst.stem(word)


# ====================================================================== German
_DE_V = "aeiouyäöü"


def german(word):
    word = word.replace("ß", "ss")
    if len(word) < 1:
        return word
    chars = list(word)
    for i in range(1, len(chars) - 1):
        if chars[i - 1] in _DE_V and chars[i + 1] in _DE_V:
            if chars[i] == "u":
                chars[i] = "U"
            elif chars[i] == "y":
                chars[i] = "Y"
    word = "".join(chars)
    vow = _DE_V
    vowels_all = _DE_V

    def regions(w):
        r1, r2 = _r1r2(w, vowels_all)
        # r1 must start at least 3 letters in
        if len(w) - len(r1) < 3:
            r1 = w[3:] if len(w) > 3 else ""
            if len(w) - len(r1) < 3:
                r1 = ""
            r2 = ""
            for i in range(1, len(r1)):
                if r1[i] not in vowels_all and r1[i - 1] in vowels_all:
                    r2 = r1[i + 1:]
                    break
        return r1, r2

    r1, r2 = regions(word)
    # step 1
    s = _longest(word, ["ern", "em", "er", "en", "es", "e", "s"])
    if s and r1.endswith(s) and len(r1) >= len(s):
        if s in ("em", "ern", "er"):
            word = word[:-len(s)]
        elif s in ("e", "en", "es"):
            word = word[:-len(s)]
            if word.endswith("niss"):
                word = word[:-1]
        elif s == "s":
            if len(word) >= 2 and word[-2] in "bdfghklmnrt":
                word = word[:-1]
    r1, r2 = regions(word)
    # step 2
    s = _longest(word, ["est", "en", "er", "st"])
    if s and len(r1) >= len(s):
        if s in ("en", "er", "est"):
            word = word[:-len(s)]
        elif s == "st":
            if len(word) >= 6 and word[-3] in "bdfghklmnt":
                word = word[:-2]
    r1, r2 = regions(word)
    # step 3
    s = _longest(word, ["keit", "heit", "lich", "end", "ung", "isch", "ig", "ik"])
    if s and len(r2) >= len(s):
        base = word[:-len(s)]
        if s in ("end", "ung"):
            word = base
            if word.endswith("ig") and len(r2) >= len(s) + 2 and not word[:-2].endswith("e"):
                word = word[:-2]
        elif s in ("ig", "ik", "isch"):
            if not base.endswith("e"):
                word = base
        elif s in ("lich", "heit"):
            word = base
            if word.endswith(("er", "en")) and len(r1) >= len(s) + 2:
                word = word[:-2]
        elif s == "keit":
            word = base
            if word.endswith("lich") and len(r2) >= len(s) + 4:
                word = word[:-4]
            elif word.endswith("ig") and len(r2) >= len(s) + 2:
                word = word[:-2]
    word = word.replace("U", "u").replace("Y", "y")
    return word.replace("ä", "a").replace("ö", "o").replace("ü", "u")


# ====================================================================== Swedish
_SV_V = "aeiouyäåö"
_SV_S1 = ["heterna", "hetens", "anden", "andes", "andet", "arens", "arnas", "ernas", "ornas", "ades", "arne",
          "aste", "aren", "heten", "heter", "erns", "arna", "erna", "orna", "ande", "ade", "are", "ast", "het",
          "ern", "ens", "ar", "er", "or", "as", "es", "at", "en", "a", "e", "ad"]


def _min3_r1(word, vowels):
    r1 = _r1_only(word, vowels)
    if len(word) - len(r1) < 3:
        r1 = word[3:] if len(word) > 3 else ""
    return r1


def swedish(word):
    r1 = _min3_r1(word, _SV_V)
    s = _longest(word, _SV_S1 + ["s"])
    if s and len(r1) >= len(s):
        if s == "s":
            if len(word) >= 2 and word[-2] in "bcdfghjklmnoprtvy":
                word = word[:-1]
        else:
            word = word[:-len(s)]
    r1 = r1[:len(r1) - 0] if False else _min3_r1(word, _SV_V)
    s = _longest(word, ["dd", "gd", "nn", "dt", "gt", "kt", "tt"])
    if s and len(r1) >= len(s):
        word = word[:-1]
    r1 = _min3_r1(word, _SV_V)
    s = _longest(word, ["fullt", "löst", "lig", "els", "ig"])
    if s and len(r1) >= len(s):
        if s == "löst":
            word = word[:-1]
        elif s == "fullt":
            word = word[:-1]
        else:
            word = word[:-len(s)]
    return word


# ====================================================================== Norwegian
_NO_V = "aeiouyæåø"
_NO_S1 = ["hetenes", "hetens", "heten", "heter", "endes", "edes", "enes", "ende", "ande", "ede", "ane", "ene",
          "ens", "ers", "ets", "het", "ast", "ar", "er", "as", "es", "en", "et", "a", "e"]


def norwegian(word):
    r1 = _min3_r1(word, _NO_V)
    cands = _NO_S1 + ["s", "erte", "ert"]
    s = _longest(word, cands)
    if s and len(r1) >= len(s):
        if s == "s":
            pre = word[:-1]
            if pre and (pre[-1] in "bcdfghjlmnoprtvyz" or (pre[-1] == "k" and len(pre) > 1 and pre[-2] not in _NO_V)):
                word = pre
        elif s in ("erte", "ert"):
            word = word[:-len(s)] + "er"
        else:
            word = word[:-len(s)]
    r1 = _min3_r1(word, _NO_V)
    s = _longest(word, ["dt", "vt"])
    if s and len(r1) >= 2:
        word = word[:-1]
    r1 = _min3_r1(word, _NO_V)
    s = _longest(word, ["hetslov", "eleg", "elig", "elov", "slov", "leg", "eig", "lig", "els", "lov", "ig"])
    if s and len(r1) >= len(s):
        word = word[:-len(s)]
    return word


# ====================================================================== Danish
_DA_V = "aeiouyæåø"
_DA_S1 = ["erendes", "hedens", "erens", "erets", "heden", "heder", "endes", "ernes", "erende", "erede", "ethed",
          "erer", "eres", "enes", "erne", "eren", "eret", "heds", "ende", "ered", "ene", "ere", "ens", "ers",
          "ets", "hed", "es", "en", "er", "et", "e"]


def _da_cons_pair(word, r1):
    s = _longest(word, ["gd", "dt", "gt", "kt"])
    if s and len(r1) >= 2:
        return word[:-1]
    return word


def danish(word):
    r1 = _min3_r1(word, _DA_V)
    s = _longest(word, _DA_S1 + ["s"])
    if s and len(r1) >= len(s):
        if s == "s":
            if len(word) >= 2 and word[-2] in "abcdfghjklmnoprtvyzå":
                word = word[:-1]
        else:
            word = word[:-len(s)]
    r1 = _min3_r1(word, _DA_V)
    word = _da_cons_pair(word, r1)
    r1 = _min3_r1(word, _DA_V)
    if word.endswith("igst") and len(r1) >= 4:
        word = word[:-2]
    r1 = _min3_r1(word, _DA_V)
    s = _longest(word, ["elig", "lig", "els", "ig", "løst"])
    if s and len(r1) >= len(s):
        if s == "løst":
            word = word[:-1]
        else:
            word = word[:-len(s)]
            r1 = _min3_r1(word, _DA_V)
            word = _da_cons_pair(word, r1)
    r1 = _min3_r1(word, _DA_V)
    if len(word) >= 2 and word[-1] == word[-2] and word[-1] not in _DA_V and len(r1) >= 1:
        word = word[:-1]
    return word


# ====================================================================== Dutch
_NL_V = "aeiouyè"


def _nl_undouble(w):
    if w.endswith(("kk", "dd", "tt")):
        return w[:-1]
    return w


def dutch(word):
    for a, b in (("ä", "a"), ("ë", "e"), ("ï", "i"), ("ö", "o"), ("ü", "u"),
                 ("á", "a"), ("é", "e"), ("í", "i"), ("ó", "o"), ("ú", "u")):
        word = word.replace(a, b)
    if word.startswith("y"):
        word = "Y" + word[1:]
    chars = list(word)
    for i in range(1, len(chars)):
        if chars[i - 1] in _NL_V and chars[i] == "y":
            chars[i] = "Y"
    for i in range(1, len(chars) - 1):
        if chars[i - 1] in _NL_V and chars[i] == "i" and chars[i + 1] in _NL_V:
            chars[i] = "I"
    word = "".join(chars)

    def regions(w):
        r1, r2 = _r1r2(w, _NL_V)
        if len(w) - len(r1) < 3:
            r1 = w[3:] if len(w) > 3 else ""
            r2 = ""
            for i in range(1, len(r1)):
                if r1[i] not in _NL_V and r1[i - 1] in _NL_V:
                    r2 = r1[i + 1:]
                    break
        return r1, r2

    def en_ending(w, r1):
        # delete 'en' if preceded by valid en-ending (non-vowel, not 'gem')
        if w.endswith("en") and len(r1) >= 2:
            pre = w[:-2]
            if pre and pre[-1] not in _NL_V and not pre.endswith("gem"):
                return _nl_undouble(pre), True
        return w, False

    r1, r2 = regions(word)
    # step 1
    s = _longest(word, ["heden", "ene", "en", "se", "s"])
    if s and len(r1) >= len(s):
        if s == "heden":
            word = word[:-5] + "heid"
        elif s in ("en", "ene"):
            pre = word[:-len(s)]
            if pre and pre[-1] not in _NL_V and not pre.endswith("gem"):
                word = _nl_undouble(pre)
        else:
            pre = word[:-len(s)]
            if pre and pre[-1] not in _NL_V and pre[-1] != "j":
                word = pre
    r1, r2 = regions(word)
    # step 2
    e_removed = False
    if word.endswith("e") and len(r1) >= 1 and len(word) >= 2 and word[-2] not in _NL_V:
        word = _nl_undouble(word[:-1])
        e_removed = True
    r1, r2 = regions(word)
    # step 3a
    if word.endswith("heid") and len(r2) >= 4 and not word[:-4].endswith("c"):
        word = word[:-4]
        r1, r2 = regions(word)
        word, _ = en_ending(word, r1)
    r1, r2 = regions(word)
    # step 3b
    s = _longest(word, ["baar", "lijk", "end", "ing", "bar", "ig"])
    if s and len(r2) >= len(s):
        base = word[:-len(s)]
        if s in ("end", "ing"):
            word = base
            if word.endswith("ig") and len(r2) >= len(s) + 2 and not word[:-2].endswith("e"):
                word = word[:-2]
            else:
                word = _nl_undouble(word)
        elif s == "ig":
            if not base.endswith("e"):
                word = base
        elif s == "lijk":
            word = base
            r1, r2 = regions(word)
            if word.endswith("e") and len(r1) >= 1 and len(word) >= 2 and word[-2] not in _NL_V:
                word = _nl_undouble(word[:-1])
        elif s == "baar":
            word = base
        elif s == "bar":
            if e_removed:
                word = base
    # step 4
    if len(word) >= 4 and word[-1] not in _NL_V and word[-1] != "I" and word[-2] == word[-3] \
            and word[-2] in "aeou" and word[-4] not in _NL_V:
        word = word[:-2] + word[-1]
    return word.replace("Y", "y").replace("I", "i")



# ====================================================================== Romance helpers
def _rv(word, vowels):
    n = len(word)
    if n < 2:
        return n
    if word[1] not in vowels:
        for i in range(2, n):
            if word[i] in vowels:
                return i + 1
        return n
    if word[0] in vowels and word[1] in vowels:
        for i in range(2, n):
            if word[i] not in vowels:
                return i + 1
        return n
    return 3 if n >= 3 else n


def _regions(word, vowels):
    """Return integer start positions (p1, p2) for R1 and R2."""
    p1 = len(word)
    for i in range(1, len(word)):
        if word[i] not in vowels and word[i - 1] in vowels:
            p1 = i + 1
            break
    p2 = len(word)
    for i in range(p1 + 1, len(word)):
        if word[i] not in vowels and word[i - 1] in vowels:
            p2 = i + 1
            break
    return p1, p2


class _W:
    """Mutable word with region helpers (positions are fixed once computed)."""

    def __init__(self, word, p1, p2, rv):
        self.w = word
        self.p1, self.p2, self.rv = p1, p2, rv

    def longest(self, suffixes):
        return _longest(self.w, suffixes)

    def in_(self, region, suf):
        return len(self.w) - len(suf) >= region

    def r1(self, s): return self.in_(self.p1, s)
    def r2(self, s): return self.in_(self.p2, s)
    def rvq(self, s): return self.in_(self.rv, s)

    def cut(self, n):
        self.w = self.w[:len(self.w) - n]

    def ends(self, s): return self.w.endswith(s)


# ====================================================================== Spanish
_ES_V = "aeiouáéíóúü"
_ES_STEP0 = ["selas", "selos", "sela", "selo", "las", "les", "los", "nos", "me", "se", "la", "le", "lo"]
_ES_STEP0_PRE = ["iéndo", "ándo", "ár", "ér", "ír", "ando", "iendo", "ar", "er", "ir", "yendo"]
_ES_2B = ("arían arías arán arás aríais aría aréis aríamos aremos ará aré erían erías erán erás eríais ería eréis "
          "eríamos eremos erá eré irían irías irán irás iríais iría iréis iríamos iremos irá iré aba ada ida ía ara "
          "iera ad ed id ase iese aste iste an aban ían aran ieran asen iesen aron ieron ado ido ando iendo ió ar er "
          "ir as abas adas idas ías aras ieras ases ieses ís áis abais íais arais ierais aseis ieseis asteis isteis "
          "ados idos amos ábamos íamos imos áramos iéramos iésemos ásemos").split()


def spanish(word):
    p1, p2 = _regions(word, _ES_V)
    w = _W(word, p1, p2, _rv(word, _ES_V))
    # step 0
    s = w.longest(_ES_STEP0)
    if s and w.rvq(s):
        pre = w.w[:-len(s)]
        pp = _longest(pre, _ES_STEP0_PRE)
        if pp and len(pre) - len(pp) >= w.rv:
            if pp in ("iéndo", "ándo", "ár", "ér", "ír"):
                base = pre[:-len(pp)]
                acc = {"iéndo": "iendo", "ándo": "ando", "ár": "ar", "ér": "er", "ír": "ir"}[pp]
                w.w = base + acc
            elif pp == "yendo":
                if pre[:-5].endswith("u"):
                    w.w = pre
            else:
                w.w = pre
    # step 1
    done = False
    G = w
    s = G.longest(["anzas", "anza", "icos", "icas", "ico", "ica", "ismos", "ismo", "ables", "able", "ibles", "ible",
                   "istas", "ista", "osos", "osas", "oso", "osa", "amientos", "amiento", "imientos", "imiento",
                   "adoras", "adores", "adora", "ador", "aciones", "ación", "antes", "ante", "ancias", "ancia",
                   "logías", "logía", "uciones", "ución", "encias", "encia", "amente", "mente", "idades", "idad",
                   "ivas", "ivos", "iva", "ivo"])
    if s:
        if s in ("anzas", "anza", "icos", "icas", "ico", "ica", "ismos", "ismo", "ables", "able", "ibles", "ible",
                 "istas", "ista", "osos", "osas", "oso", "osa", "amientos", "amiento", "imientos", "imiento"):
            if G.r2(s):
                G.cut(len(s)); done = True
        elif s in ("adoras", "adores", "adora", "ador", "aciones", "ación", "antes", "ante", "ancias", "ancia"):
            if G.r2(s):
                G.cut(len(s)); done = True
                if G.ends("ic") and G.r2("ic"):
                    G.cut(2)
        elif s in ("logías", "logía"):
            if G.r2(s):
                G.w = G.w[:-len(s)] + "log"; done = True
        elif s in ("uciones", "ución"):
            if G.r2(s):
                G.w = G.w[:-len(s)] + "u"; done = True
        elif s in ("encias", "encia"):
            if G.r2(s):
                G.w = G.w[:-len(s)] + "ente"; done = True
        elif s == "amente":
            if G.r1(s):
                G.cut(6); done = True
                if G.ends("iv") and G.r2("iv"):
                    G.cut(2)
                    if G.ends("at") and G.r2("at"):
                        G.cut(2)
                elif G.ends(("os")) and G.r2("os"):
                    G.cut(2)
                elif G.ends("ic") and G.r2("ic"):
                    G.cut(2)
                elif G.ends("ad") and G.r2("ad"):
                    G.cut(2)
        elif s == "mente":
            if G.r2(s):
                G.cut(5); done = True
                for t in ("ante", "able", "ible"):
                    if G.ends(t) and G.r2(t):
                        G.cut(len(t))
                        break
        elif s in ("idades", "idad"):
            if G.r2(s):
                G.cut(len(s)); done = True
                for t in ("abil", "ic", "iv"):
                    if G.ends(t) and G.r2(t):
                        G.cut(len(t))
                        break
        elif s in ("ivas", "ivos", "iva", "ivo"):
            if G.r2(s):
                G.cut(len(s)); done = True
                if G.ends("at") and G.r2("at"):
                    G.cut(2)
    if not done:
        # step 2a
        s = w.longest(["yeron", "yendo", "yamos", "yais", "yan", "yen", "yas", "yes", "ya", "ye", "yo", "yó"])
        ok2a = False
        if s and w.rvq(s) and w.w[:-len(s)].endswith("u"):
            w.cut(len(s)); ok2a = True
        if not ok2a:
            s = w.longest(["en", "es", "éis", "emos"] + _ES_2B)
            if s and w.rvq(s):
                if s in ("en", "es", "éis", "emos"):
                    w.cut(len(s))
                    if w.ends("gu") and len(w.w) - 1 >= w.rv:
                        w.cut(1)
                else:
                    w.cut(len(s))
    # step 3
    s = w.longest(["os", "a", "o", "á", "í", "ó", "e", "é"])
    if s and w.rvq(s):
        if s in ("e", "é"):
            w.cut(1)
            if w.ends("gu") and len(w.w) - 1 >= w.rv:
                w.cut(1)
        else:
            w.cut(len(s))
    out = w.w
    for a, b in (("á", "a"), ("é", "e"), ("í", "i"), ("ó", "o"), ("ú", "u")):
        out = out.replace(a, b)
    return out


# ====================================================================== Italian
_IT_V = "aeiouàèìòù"
_IT_PRON = ["gliela", "gliele", "glieli", "glielo", "gliene", "sene", "mela", "mele", "meli", "melo", "mene", "tela",
            "tele", "teli", "telo", "tene", "cela", "cele", "celi", "celo", "cene", "vela", "vele", "veli", "velo",
            "vene", "ci", "gli", "la", "le", "li", "lo", "mi", "ne", "si", "ti", "vi"]
_IT_VERB = ("ammo ando ano are arono asse assero assi assimo ata ate ati ato ente erà erai eranno ere erebbe erebbero "
            "erei eremmo eremo ereste eresti erete erò erono essero ete eva evano evate evi evo Yamo iamo immo irà "
            "irai iranno ire irebbe irebbero irei iremmo iremo ireste iresti irete irò irono isca iscano isci isco "
            "iscono issero ita ite iti ito iva ivano ivate ivi ivo ono uta ute uti uto ar ir").split()


def italian(word):
    for a, b in (("á", "à"), ("é", "è"), ("í", "ì"), ("ó", "ò"), ("ú", "ù")):
        word = word.replace(a, b)
    word = word.replace("qu", "qU")
    chars = list(word)
    for i in range(1, len(chars) - 1):
        if chars[i - 1] in _IT_V and chars[i + 1] in _IT_V:
            if chars[i] == "u":
                chars[i] = "U"
            elif chars[i] == "i":
                chars[i] = "I"
    word = "".join(chars)
    p1, p2 = _regions(word, _IT_V)
    w = _W(word, p1, p2, _rv(word, _IT_V))
    # step 0
    s = w.longest(_IT_PRON)
    if s:
        pre = w.w[:-len(s)]
        pp = _longest(pre, ["ando", "endo", "ar", "er", "ir"])
        if pp and len(pre) - len(pp) >= w.rv:
            if pp in ("ando", "endo"):
                w.w = pre
            else:
                w.w = pre[:-len(pp)] + pp[:-1] + "e"
    # step 1
    done = False
    s = w.longest(["anza", "anze", "iche", "ichi", "ismo", "ismi", "ista", "iste", "isti", "istà", "istè", "istì",
                   "ico", "ici", "ica", "ice", "oso", "osi", "osa", "ose", "mente", "atrice", "atrici", "abile",
                   "abili", "ibile", "ibili", "azione", "azioni", "atore", "atori", "logia", "logie", "uzione",
                   "uzioni", "usione", "usioni", "enza", "enze", "amento", "amenti", "imento", "imenti", "amente",
                   "ità", "ivo", "ivi", "iva", "ive"])
    if s:
        if s in ("anza", "anze", "iche", "ichi", "ismo", "ismi", "ista", "iste", "isti", "istà", "istè", "istì", "ico",
                 "ici", "ica", "ice", "oso", "osi", "osa", "ose", "mente", "atrice", "atrici", "abile", "abili",
                 "ibile", "ibili"):
            if w.r2(s):
                w.cut(len(s)); done = True
        elif s in ("azione", "azioni", "atore", "atori"):
            if w.r2(s):
                w.cut(len(s)); done = True
                if w.ends("ic") and w.r2("ic"):
                    w.cut(2)
        elif s in ("logia", "logie"):
            if w.r2(s):
                w.w = w.w[:-len(s)] + "log"; done = True
        elif s in ("uzione", "uzioni", "usione", "usioni"):
            if w.r2(s):
                w.w = w.w[:-len(s)] + "u"; done = True
        elif s in ("enza", "enze"):
            if w.r2(s):
                w.w = w.w[:-len(s)] + "ente"; done = True
        elif s in ("amento", "amenti", "imento", "imenti"):
            if w.rvq(s):
                w.cut(len(s)); done = True
        elif s == "amente":
            if w.r1(s):
                w.cut(6); done = True
                if w.ends("iv") and w.r2("iv"):
                    w.cut(2)
                    if w.ends("at") and w.r2("at"):
                        w.cut(2)
                else:
                    for t in ("os", "ic", "abil"):
                        if w.ends(t) and w.r2(t):
                            w.cut(len(t))
                            break
        elif s == "ità":
            if w.r2(s):
                w.cut(3); done = True
                for t in ("abil", "ic", "iv"):
                    if w.ends(t) and w.r2(t):
                        w.cut(len(t))
                        break
        else:
            if w.r2(s):
                w.cut(len(s)); done = True
                if w.ends("at") and w.r2("at"):
                    w.cut(2)
                    if w.ends("ic") and w.r2("ic"):
                        w.cut(2)
    if not done:
        s = w.longest(_IT_VERB)
        if s and w.rvq(s):
            w.cut(len(s))
    # step 3a
    s = w.longest(["a", "e", "i", "o", "à", "è", "ì", "ò"])
    if s and w.rvq(s):
        w.cut(1)
        if w.ends("i") and len(w.w) - 1 >= w.rv:
            w.cut(1)
    # step 3b
    if w.ends("ch") and len(w.w) - 2 >= w.rv:
        w.w = w.w[:-1] + ""
        w.w = w.w[:-1] + "c"
    elif w.ends("gh") and len(w.w) - 2 >= w.rv:
        w.w = w.w[:-2] + "g"
    return w.w.replace("I", "i").replace("U", "u")


# ====================================================================== Portuguese
_PT_V = "aeiouáéíóúâêô"
_PT_VERB = ("ada ida ia aria eria iria ará ara erá era irá ava asse esse isse aste este iste ei arei erei irei am "
            "iam ariam eriam iriam aram eram iram avam em arem erem irem assem essem issem ado ido ando endo indo "
            "ara~o era~o ira~o ar er ir as adas idas ias arias erias irias arás aras erás eras irás avas es ardes "
            "erdes irdes ares eres ires asses esses isses astes estes istes is ais eis íeis aríeis eríeis iríeis "
            "áreis areis éreis ereis íreis ireis ásseis ésseis ísseis áveis ados idos ámos amos íamos aríamos "
            "eríamos iríamos áramos éramos íramos ávamos emos aremos eremos iremos ássemos êssemos íssemos imos "
            "armos ermos irmos eu iu ou ira iras").split()


def portuguese(word):
    word = word.replace("ã", "a~").replace("õ", "o~")
    p1, p2 = _regions(word, _PT_V)
    w = _W(word, p1, p2, _rv(word, _PT_V))
    done = False
    s = w.longest(["eza", "ezas", "ico", "ica", "icos", "icas", "ismo", "ismos", "ável", "ível", "ista", "istas",
                   "oso", "osa", "osos", "osas", "amento", "amentos", "imento", "imentos", "adora", "ador", "aça~o",
                   "adoras", "adores", "aço~es", "ante", "antes", "ância", "logia", "logias", "uça~o", "uço~es",
                   "ência", "ências", "amente", "mente", "idade", "idades", "iva", "ivo", "ivas", "ivos", "ira", "iras"])
    if s:
        simple = ("eza", "ezas", "ico", "ica", "icos", "icas", "ismo", "ismos", "ável", "ível", "ista", "istas", "oso",
                  "osa", "osos", "osas", "amento", "amentos", "imento", "imentos")
        if s in simple:
            if w.r2(s):
                w.cut(len(s)); done = True
        elif s in ("adora", "ador", "aça~o", "adoras", "adores", "aço~es", "ante", "antes", "ância"):
            if w.r2(s):
                w.cut(len(s)); done = True
                if w.ends("ic") and w.r2("ic"):
                    w.cut(2)
        elif s in ("logia", "logias"):
            if w.r2(s):
                w.w = w.w[:-len(s)] + "log"; done = True
        elif s in ("uça~o", "uço~es"):
            if w.r2(s):
                w.w = w.w[:-len(s)] + "u"; done = True
        elif s in ("ência", "ências"):
            if w.r2(s):
                w.w = w.w[:-len(s)] + "ente"; done = True
        elif s == "amente":
            if w.r1(s):
                w.cut(6); done = True
                if w.ends("iv") and w.r2("iv"):
                    w.cut(2)
                    if w.ends("at") and w.r2("at"):
                        w.cut(2)
                else:
                    for t in ("os", "ic", "ad"):
                        if w.ends(t) and w.r2(t):
                            w.cut(2)
                            break
        elif s == "mente":
            if w.r2(s):
                w.cut(5); done = True
                for t in ("ante", "avel", "ível"):
                    if w.ends(t) and w.r2(t):
                        w.cut(len(t))
                        break
        elif s in ("idade", "idades"):
            if w.r2(s):
                w.cut(len(s)); done = True
                for t in ("abil", "ic", "iv"):
                    if w.ends(t) and w.r2(t):
                        w.cut(len(t))
                        break
        elif s in ("iva", "ivo", "ivas", "ivos"):
            if w.r2(s):
                w.cut(len(s)); done = True
                if w.ends("at") and w.r2("at"):
                    w.cut(2)
        elif s in ("ira", "iras"):
            if w.rvq(s) and w.w[:-len(s)].endswith("e"):
                w.w = w.w[:-len(s)] + "ir"; done = True
    step2 = False
    if not done:
        s = w.longest(_PT_VERB)
        if s and w.rvq(s):
            w.cut(len(s)); step2 = True
    if done or step2:
        if w.ends("i") and len(w.w) - 1 >= w.rv and w.w[:-1].endswith("c"):
            w.cut(1)
    else:
        s = w.longest(["os", "a", "i", "o", "á", "í", "ó"])
        if s and w.rvq(s):
            w.cut(len(s))
    if done or step2:
        s = w.longest(["os", "a", "i", "o", "á", "í", "ó"])
        if s and w.rvq(s) and not (done or step2):
            w.cut(len(s))
    s = w.longest(["e", "é", "ê"])
    if s and w.rvq(s):
        w.cut(1)
        if (w.ends("gu") or w.ends("ci")) and len(w.w) - 1 >= w.rv:
            w.cut(1)
    elif w.ends("ç"):
        w.w = w.w[:-1] + "c"
    return w.w.replace("a~", "ã").replace("o~", "õ")


# ====================================================================== French
_FR_V = "aeiouyâàëéêèïîôûù"


def french(word):
    chars = list(word)
    for i in range(len(chars)):
        c = chars[i]
        prev = chars[i - 1] if i > 0 else ""
        nxt = chars[i + 1] if i + 1 < len(chars) else ""
        if c == "u" and prev in _FR_V and prev and nxt in _FR_V and nxt:
            chars[i] = "U"
        elif c == "i" and prev and prev in _FR_V and nxt and nxt in _FR_V:
            chars[i] = "I"
        elif c == "y" and ((prev and prev in _FR_V) or (nxt and nxt in _FR_V)):
            chars[i] = "Y"
    word = "".join(chars)
    word = word.replace("qu", "qU")
    word = word.replace("ë", "He").replace("ï", "Hi")
    V = _FR_V
    p1, p2 = _regions(word, V)
    if word.startswith(("par", "col", "tap")):
        rv = 3
    elif len(word) >= 2 and word[0] in V and word[1] in V:
        rv = 3
    else:
        rv = len(word)
        for i in range(1, len(word)):
            if word[i] in V:
                rv = i + 1
                break
    w = _W(word, p1, p2, rv)
    orig = w.w
    changed = False
    step1_done = False
    step2a_flag = False

    def rep_or_del(suf, rep_r2_del=True):
        pass

    s = w.longest(["ances", "iqUes", "ismes", "ables", "istes", "ance", "iqUe", "isme", "able", "iste", "eux",
                   "atrices", "ateurs", "ations", "atrice", "ateur", "ation", "logies", "logie", "usions", "utions",
                   "usion", "ution", "ences", "ence", "issements", "issement", "ements", "ement", "ités", "ité",
                   "ives", "ifs", "ive", "if", "eaux", "aux", "euses", "euse", "amment", "emment", "ments", "ment"])
    if s:
        if s in ("ances", "iqUes", "ismes", "ables", "istes", "ance", "iqUe", "isme", "able", "iste", "eux"):
            if w.r2(s):
                w.cut(len(s)); step1_done = True
        elif s in ("atrices", "ateurs", "ations", "atrice", "ateur", "ation"):
            if w.r2(s):
                w.cut(len(s)); step1_done = True
                if w.ends("ic"):
                    if w.r2("ic"):
                        w.cut(2)
                    else:
                        w.w = w.w[:-2] + "iqU"
        elif s in ("logies", "logie"):
            if w.r2(s):
                w.w = w.w[:-len(s)] + "log"; step1_done = True
        elif s in ("usions", "utions", "usion", "ution"):
            if w.r2(s):
                w.w = w.w[:-len(s)] + "u"; step1_done = True
        elif s in ("ences", "ence"):
            if w.r2(s):
                w.w = w.w[:-len(s)] + "ent"; step1_done = True
        elif s in ("issements", "issement"):
            if w.r1(s) and len(w.w) > len(s) and w.w[-len(s) - 1] not in V:
                w.cut(len(s)); step1_done = True
        elif s in ("ements", "ement"):
            if w.rvq(s):
                w.cut(len(s)); step1_done = True
                if w.ends("iv"):
                    if w.r2("iv"):
                        w.cut(2)
                        if w.ends("at") and w.r2("at"):
                            w.cut(2)
                elif w.ends("eus"):
                    if w.r2("eus"):
                        w.cut(3)
                    elif w.r1("eus"):
                        w.w = w.w[:-3] + "eux"
                elif w.ends("abl") or w.ends("iqU"):
                    if w.r2("abl"):
                        w.cut(3)
                elif w.ends("ièr") or w.ends("Ièr"):
                    if w.rvq("ièr"):
                        w.w = w.w[:-3] + "i"
        elif s in ("ités", "ité"):
            if w.r2(s):
                w.cut(len(s)); step1_done = True
                if w.ends("abil"):
                    if w.r2("abil"):
                        w.cut(4)
                    else:
                        w.w = w.w[:-2] + "l" if False else w.w[:-4] + "abl" if w.r1("abil") else w.w
                elif w.ends("ic"):
                    if w.r2("ic"):
                        w.cut(2)
                    else:
                        w.w = w.w[:-2] + "iqU"
                elif w.ends("iv") and w.r2("iv"):
                    w.cut(2)
        elif s in ("ives", "ifs", "ive", "if"):
            if w.r2(s):
                w.cut(len(s)); step1_done = True
                if w.ends("at") and w.r2("at"):
                    w.cut(2)
                    if w.ends("ic"):
                        if w.r2("ic"):
                            w.cut(2)
                        else:
                            w.w = w.w[:-2] + "iqU"
        elif s == "eaux":
            w.w = w.w[:-1]; step1_done = True
        elif s == "aux":
            if w.r1(s):
                w.w = w.w[:-3] + "al"; step1_done = True
        elif s in ("euses", "euse"):
            if w.r2(s):
                w.cut(len(s)); step1_done = True
            elif w.r1(s):
                w.w = w.w[:-len(s)] + "eux"; step1_done = True
        elif s == "amment":
            if w.rvq(s):
                w.w = w.w[:-6] + "ant"; step1_done = True; step2a_flag = True
        elif s == "emment":
            if w.rvq(s):
                w.w = w.w[:-6] + "ent"; step1_done = True; step2a_flag = True
        elif s in ("ments", "ment"):
            if w.rvq(s) and len(w.w) > len(s) and w.w[-len(s) - 1] in V and len(w.w) - len(s) - 1 >= w.rv:
                w.cut(len(s)); step1_done = True; step2a_flag = True
    step2a_done = False
    if (not step1_done) or step2a_flag:
        s = w.longest("îmes ît îtes i ie Ie ies ir ira irai iraIent irais irait iras irent irez iriez irions irons iront is issaIent issais issait issant issante issantes issants isse issent isses issez issiez issions issons it".split())
        if s and w.rvq(s) and len(w.w) > len(s) and w.w[-len(s) - 1] not in V and w.w[-len(s) - 1] != "H":
            w.cut(len(s)); step2a_done = True
        if not step2a_done:
            s = w.longest("ions é ée ées és èrent er era erai eraIent erais erait eras erez eriez erions erons eront ez iez âmes ât âtes a ai aIent ais ait ant ante antes ants as asse assent asses assiez assions".split())
            if s:
                if s == "ions":
                    if w.r2(s):
                        w.cut(4); step2a_done = True
                elif s in ("é", "ée", "ées", "és", "èrent", "er", "era", "erai", "eraIent", "erais", "erait", "eras",
                           "erez", "eriez", "erions", "erons", "eront", "ez", "iez"):
                    if w.rvq(s):
                        w.cut(len(s)); step2a_done = True
                else:
                    if w.rvq(s):
                        w.cut(len(s)); step2a_done = True
                        if w.ends("e") and len(w.w) - 1 >= w.rv:
                            w.cut(1)
    if step1_done or step2a_done:
        w.w = w.w.replace("Y", "i").replace("ç", "c")
    else:
        # step 4
        if w.ends("s") and len(w.w) >= 2 and w.w[-2] not in "aiouès" + "è":
            w.cut(1)
        s = w.longest(["ion", "ier", "ière", "Ier", "Ière", "e", "ë"])
        if s:
            if s == "ion":
                if w.r2(s) and w.rvq(s) and len(w.w) > 3 and w.w[-4] in "st":
                    w.cut(3)
            elif s in ("ier", "ière", "Ier", "Ière"):
                if w.rvq(s):
                    w.w = w.w[:-len(s)] + "i"
            elif s == "e":
                if w.rvq(s):
                    w.cut(1)
        if w.ends("gu") is False and w.ends("He") and False:
            pass
    # step 5 undouble
    for t in ("enn", "onn", "ett", "ell", "eill"):
        if w.ends(t):
            w.cut(1)
            break
    # step 6 unaccent
    for i in range(len(w.w) - 1, -1, -1):
        if w.w[i] in "éè":
            if all(c not in V for c in w.w[i + 1:]) and i + 1 < len(w.w):
                w.w = w.w[:i] + "e" + w.w[i + 1:]
            break
        if w.w[i] in V:
            break
    return w.w.replace("I", "i").replace("U", "u").replace("Y", "y").replace("He", "ë").replace("Hi", "ï")


# ====================================================================== Russian
_RU_V = "аеиоуыэюя"


def russian(word):
    word = word.replace("ё", "е")
    rv = len(word)
    for i, c in enumerate(word):
        if c in _RU_V:
            rv = i + 1
            break
    # R2
    p1 = len(word)
    for i in range(1, len(word)):
        if word[i] not in _RU_V and word[i - 1] in _RU_V:
            p1 = i + 1
            break
    p2 = len(word)
    for i in range(p1 + 1, len(word)):
        if word[i] not in _RU_V and word[i - 1] in _RU_V:
            p2 = i + 1
            break
    pre, w = word[:rv], word[rv:]

    def strip_group(w, g1, g2):
        s = _longest(w, g1 + g2)
        if not s:
            return None
        if s in g1:
            if w[:-len(s)].endswith(("а", "я")):
                return w[:-len(s)]
            # fall back to a shorter group-2 suffix match
            g = [x for x in g2 if w.endswith(x)]
            return w[:-len(max(g, key=len))] if g else None
        return w[:-len(s)]

    PERF_G1 = ["вшись", "вши", "в"]
    PERF_G2 = ["ившись", "ывшись", "ивши", "ывши", "ив", "ыв"]
    REFL = ["ся", "сь"]
    ADJ = ["его", "ого", "ему", "ому", "ими", "ыми", "ее", "ие", "ые", "ое", "ей", "ий", "ый", "ой", "ем", "им",
           "ым", "ом", "их", "ых", "ую", "юю", "ая", "яя", "ою", "ею"]
    PART_G1 = ["ем", "нн", "вш", "ющ", "щ"]
    PART_G2 = ["ивш", "ывш", "ующ"]
    VERB_G1 = ["ете", "йте", "нно", "ешь", "ла", "на", "ли", "ем", "ло", "но", "ет", "ют", "ны", "ть", "й", "л", "н"]
    VERB_G2 = ["ейте", "уйте", "ила", "ыла", "ена", "ите", "или", "ыли", "ило", "ыло", "ено", "ует", "уют", "ены",
               "ить", "ыть", "ишь", "ей", "уй", "ил", "ыл", "им", "ым", "ен", "ят", "ит", "ыт", "ую", "ю"]
    NOUN = ["иями", "ями", "ами", "ией", "иям", "ием", "иях", "ев", "ов", "ие", "ье", "еи", "ии", "ей", "ой", "ий",
            "ям", "ем", "ам", "ом", "ах", "ях", "ию", "ью", "ия", "ья", "а", "е", "и", "й", "о", "у", "ы", "ь", "ю", "я"]

    def adjectival(w):
        s = _longest(w, ADJ)
        if not s:
            return None
        base = w[:-len(s)]
        p = strip_group(base, PART_G1, PART_G2)
        return p if p is not None else base

    r = strip_group(w, PERF_G1, PERF_G2)
    if r is not None:
        w = r
    else:
        s = _longest(w, REFL)
        if s:
            w = w[:-len(s)]
        a = adjectival(w)
        if a is not None:
            w = a
        else:
            v = strip_group(w, VERB_G1, VERB_G2)
            if v is not None:
                w = v
            else:
                s = _longest(w, NOUN)
                if s:
                    w = w[:-len(s)]
    if w.endswith("и"):
        w = w[:-1]
    # derivational (in R2)
    full = pre + w
    if full.endswith("ость") and len(full) - 4 >= p2:
        full = full[:-4]
    elif full.endswith("ост") and len(full) - 3 >= p2:
        full = full[:-3]
    # tidy up
    if full.endswith("ейше") and len(full) >= rv:
        full = full[:-4]
        if full.endswith("нн"):
            full = full[:-1]
    elif full.endswith("ейш"):
        full = full[:-3]
        if full.endswith("нн"):
            full = full[:-1]
    elif full.endswith("нн"):
        full = full[:-1]
    elif full.endswith("ь"):
        full = full[:-1]
    return full


# ====================================================================== simplified fallbacks
def _suffix_stripper(vowels, suffixes, min_stem=3):
    suffixes = sorted(suffixes, key=len, reverse=True)

    def stem(word):
        for _ in range(2):
            for s in suffixes:
                if word.endswith(s) and len(word) - len(s) >= min_stem:
                    word = word[:-len(s)]
                    break
            else:
                break
        return word
    return stem


_FI_SUFFIXES = ["kaan", "kään", "kin", "han", "hän", "ssa", "ssä", "sta", "stä", "lla", "llä", "lta", "ltä", "lle",
                "ksi", "tta", "ttä", "na", "nä", "ta", "tä", "ien", "jen", "den", "tten", "iden", "itten", "t", "a",
                "ä", "n", "i"]
_HU_SUFFIXES = ["okat", "eket", "okkal", "ekkel", "ban", "ben", "ból", "ből", "hoz", "hez", "höz", "nak", "nek",
                "val", "vel", "tól", "től", "ról", "ről", "ok", "ek", "ök", "at", "et", "ot", "ön", "on", "en",
                "ra", "re", "ba", "be", "ig", "k", "t", "n"]
_RO_SUFFIXES = ["urilor", "ilor", "elor", "ului", "ările", "area", "ește", "ează", "uri", "ile", "ele", "ul",
                "ii", "ei", "ea", "le", "ă", "e", "i", "a", "u"]
_AR_SUFFIXES = ["ات", "ان", "ين", "ون", "ها", "هم", "ية", "ة", "ي", "ه", "ا"]


def arabic(word):
    w = re.sub("[ً-ْـ]", "", word)
    for p in ("وال", "بال", "كال", "فال", "ال", "لل"):
        if w.startswith(p) and len(w) - len(p) >= 3:
            w = w[len(p):]
            break
    return _suffix_stripper("", _AR_SUFFIXES, 2)(w)


_REGISTRY = {"english": english, "porter": porter, "german": german, "swedish": swedish,
             "norwegian": norwegian, "danish": danish, "dutch": dutch, "spanish": spanish, "italian": italian,
             "portuguese": portuguese, "french": french, "russian": russian, "arabic": arabic,
             "finnish": _suffix_stripper("", _FI_SUFFIXES), "hungarian": _suffix_stripper("", _HU_SUFFIXES),
             "romanian": _suffix_stripper("", _RO_SUFFIXES)}
