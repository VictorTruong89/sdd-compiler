"""Command line. spec: N-000382..N-000388 (a small click-like command group, no third-party dependency)."""
import sys

from . import tokenize as _tok


class UsageError(Exception):
    exit_code = 2


class Group:
    def __init__(self, name):
        self.name = name
        self.commands = {}

    def command(self, name):
        def deco(fn):
            self.commands[name] = fn
            return fn
        return deco

    def main(self, args=None, prog_name=None, standalone_mode=True, **extra):
        args = list(sys.argv[1:] if args is None else args)
        try:
            if not args or args[0] not in self.commands:
                if args and args[0] in ("-h", "--help"):
                    sys.stdout.write("Usage: %s [OPTIONS] COMMAND [ARGS]...\n\nCommands:\n%s" % (
                        self.name, "".join("  %s\n" % c for c in self.commands)))
                    rv = None
                else:
                    raise UsageError("Missing or unknown command. Available: %s" % ", ".join(self.commands))
            else:
                rv = self.commands[args[0]](args[1:])
        except SystemExit:
            raise
        except BaseException as e:  # noqa: BLE001
            if not standalone_mode:
                raise
            if isinstance(e, KeyboardInterrupt):
                code = 130
            else:
                code = getattr(e, "exit_code", 1)
            sys.stderr.write("Error: %s\n" % (e,))
            raise SystemExit(code)
        if standalone_mode:
            raise SystemExit(0)
        return rv

    __call__ = main


cli = Group("lingora")


def _read_stdin(encoding):
    buf = getattr(sys.stdin, "buffer", None)
    if buf is not None:
        return buf.read().decode(encoding)
    return sys.stdin.read()


@cli.command("tokenize")
def tokenize_cmd(argv):
    language = "english"
    delimiter = " "
    encoding = "utf-8"
    it = iter(argv)
    for a in it:
        if a in ("-l", "--language"):
            language = next(it, None)
        elif a in ("-d", "--delimiter"):
            delimiter = next(it, None)
        elif a in ("-e", "--encoding"):
            encoding = next(it, None)
        elif a.startswith("--language="):
            language = a.split("=", 1)[1]
        elif a.startswith("--delimiter="):
            delimiter = a.split("=", 1)[1]
        elif a.startswith("--encoding="):
            encoding = a.split("=", 1)[1]
        else:
            raise UsageError("unknown option %r" % a)
        if language is None or delimiter is None or encoding is None:
            raise UsageError("option requires a value")
    # fail before writing anything when the Punkt model is not visible
    _tok._load_punkt(language)
    text = _read_stdin(encoding)
    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    out = []
    for line in lines:
        line = line.rstrip("\r")
        out.append(delimiter.join(_tok.word_tokenize(line, language)) + "\n")
    sys.stdout.write("".join(out))
    sys.stdout.flush()
