"""Packaged-resource lookup. spec: N-000353..N-000370"""
import os

# spec: N-000353 mutable list of directory strings; initial contents are implementer's choice
path = []
_env = os.environ.get("LINGORA_DATA")
if _env:
    path.extend(p for p in _env.split(os.pathsep) if p)
for _p in (os.path.expanduser("~/lingora_data"), os.path.expanduser("~/nltk_data"),
           "/usr/share/nltk_data", "/usr/local/share/nltk_data", "/usr/lib/nltk_data"):
    if os.path.isdir(_p):
        path.append(_p)


def find(resource):
    """Return the filesystem path of `resource` found in `data.path`, else raise LookupError.
    Only the directories currently in `path` are searched (N-000354)."""
    for d in list(path):
        p = os.path.join(str(d), *resource.split("/"))
        if os.path.exists(p):
            return p
    raise LookupError("resource %r not found in data.path" % resource)


def available(resource):
    try:
        find(resource)
        return True
    except LookupError:
        return False


def read_lines(filepath):
    """Each line without its terminator is one entry (N-000366)."""
    with open(filepath, encoding="utf-8", newline="") as f:
        text = f.read()
    return text.splitlines() if text else []
