"""Classifiers. spec: N-000455..N-000460, FP-06"""
import math
from collections import defaultdict, Counter

from .metrics import accuracy as _list_accuracy


def accuracy(classifier, gold):
    gold = list(gold)
    if not gold:
        raise ValueError("gold must not be empty")
    results = [classifier.classify(fs) for fs, _ in gold]
    return _list_accuracy([l for _, l in gold], results)


class DictProbDist:
    def __init__(self, probs):
        self._p = dict(probs)

    def prob(self, sample):
        return float(self._p.get(sample, 0.0))

    def samples(self):
        return list(self._p.keys())

    def max(self):
        return max(self._p, key=lambda k: self._p[k])

    def logprob(self, sample):
        p = self.prob(sample)
        return math.log(p, 2) if p > 0 else float("-inf")

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._p)


class NaiveBayesClassifier:
    def __init__(self, label_prior, feature_probdist, labels):
        self._label_prior = label_prior      # label -> prob
        self._fprob = feature_probdist       # (label, fname) -> (counts dict value->n, total samples N, bins)
        self._labels = list(labels)

    @classmethod
    def train(cls, labeled_featuresets):
        label_freq = Counter()
        fcount = defaultdict(Counter)
        fnames = set()
        fvalues = defaultdict(set)
        feature_freqdist = defaultdict(Counter)
        train = list(labeled_featuresets)
        for fs, label in train:
            label_freq[label] += 1
            for fname, fval in fs.items():
                feature_freqdist[label, fname][fval] += 1
                fnames.add(fname)
                fvalues[fname].add(fval)
        # features missing from an example count as None
        for label in label_freq:
            n = label_freq[label]
            for fname in fnames:
                c = feature_freqdist[label, fname]
                num_seen = sum(c.values())
                if num_seen < n:
                    c[None] += n - num_seen
                    fvalues[fname].add(None)
        total = sum(label_freq.values())
        nlabels = len(label_freq)
        prior = {l: (c + 0.5) / (total + 0.5 * nlabels) for l, c in label_freq.items()}  # Lidstone-smoothed (0.5)
        fprob = {}
        for (label, fname), c in feature_freqdist.items():
            fprob[label, fname] = (dict(c), sum(c.values()), len(fvalues[fname]))
        return cls(prior, fprob, list(label_freq.keys()))

    def labels(self):
        return list(self._labels)

    def _fp(self, label, fname, fval):
        counts, n, bins = self._fprob[label, fname]
        return (counts.get(fval, 0) + 0.5) / (n + 0.5 * bins)

    def prob_classify(self, featureset):
        featureset = dict(featureset)
        # drop features never seen in training
        known = {f for (_, f) in self._fprob}
        featureset = {f: v for f, v in featureset.items() if f in known}
        logp = {}
        for label in self._labels:
            logp[label] = math.log(self._label_prior[label])
        for label in self._labels:
            for fname in known:
                fval = featureset.get(fname)
                if (label, fname) in self._fprob:
                    logp[label] += math.log(self._fp(label, fname, fval))
        m = max(logp.values())
        exps = {l: math.exp(v - m) for l, v in logp.items()}
        z = sum(exps.values())
        return DictProbDist({l: v / z for l, v in exps.items()})

    def classify(self, featureset):
        return self.prob_classify(featureset).max()


class DecisionTreeClassifier:
    def __init__(self, label, feature_name=None, decisions=None, default=None):
        self._label = label
        self._fname = feature_name
        self._decisions = decisions
        self._default = default

    def classify(self, featureset):
        if self._fname is None:
            return self._label
        fval = featureset.get(self._fname)
        if fval in self._decisions:
            return self._decisions[fval].classify(featureset)
        if self._default is not None:
            return self._default.classify(featureset)
        return self._label

    @classmethod
    def train(cls, labeled_featuresets, entropy_cutoff=0.05, depth_cutoff=100, support_cutoff=10, binary=False):
        data = list(labeled_featuresets)
        if not data:
            raise ValueError("no training data")
        fnames = set()
        for fs, _ in data:
            fnames.update(fs.keys())
        return cls._build(data, sorted(fnames, key=str), depth_cutoff)

    @staticmethod
    def _majority(data):
        c = Counter(l for _, l in data)
        best = max(c.values())
        for _, l in data:  # first-seen among ties
            if c[l] == best:
                return l

    @classmethod
    def _build(cls, data, fnames, depth):
        label = cls._majority(data)
        if len({l for _, l in data}) <= 1 or depth <= 0 or not fnames:
            return cls(label)
        # choose feature with the highest accuracy of stump (ties: first in sorted order)
        best, best_err = None, None
        for f in fnames:
            groups = defaultdict(list)
            for fs, l in data:
                groups[fs.get(f)].append(l)
            if len(groups) < 2:
                continue
            err = 0
            for ls in groups.values():
                c = Counter(ls)
                err += len(ls) - max(c.values())
            if best_err is None or err < best_err:
                best, best_err = f, err
        if best is None:
            return cls(label)
        groups = defaultdict(list)
        for ex in data:
            groups[ex[0].get(best)].append(ex)
        rest = [f for f in fnames if f != best]
        decisions = {v: cls._build(exs, rest, depth - 1) for v, exs in groups.items()}
        return cls(label, best, decisions, cls(label))

    def pretty_format(self, width=70, prefix="", depth=4):
        if self._fname is None:
            return "%s%s\n" % (prefix, self._label)
        s = ""
        for v, t in self._decisions.items():
            s += "%s%s=%r? %s" % (prefix, self._fname, v, t.pretty_format(width, prefix + "  ", depth))
        return s

    def __str__(self):
        return self.pretty_format()
