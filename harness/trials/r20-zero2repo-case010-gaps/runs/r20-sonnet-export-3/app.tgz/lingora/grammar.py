"""Context-free grammars. spec: N-000424..N-000434, FP-05"""
import re


class Nonterminal:
    """A nonterminal symbol; str() is its name (N-000429)."""

    __slots__ = ("_symbol",)

    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and self._symbol == other._symbol

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return hash(("NT", self._symbol))

    def __str__(self):
        return str(self._symbol)

    def __repr__(self):
        return "Nonterminal(%r)" % (self._symbol,)

    def __lt__(self, other):
        return str(self) < str(other)


class Production:
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def is_lexical(self):
        return all(not isinstance(s, Nonterminal) for s in self._rhs)

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return isinstance(other, Production) and self._lhs == other._lhs and self._rhs == other._rhs

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        parts = [str(s) if isinstance(s, Nonterminal) else repr(s) for s in self._rhs]
        return "%s -> %s" % (self._lhs, " ".join(parts))

    def __repr__(self):
        return str(self)


_TOKEN = re.compile(r"""'[^']*'|"[^"]*"|\||[^\s|'"]+""")


class CFG:
    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)
        self._lhs_index = {}
        for p in self._productions:
            self._lhs_index.setdefault(p.lhs(), []).append(p)
        self._terminals = set()
        for p in self._productions:
            for s in p.rhs():
                if not isinstance(s, Nonterminal):
                    self._terminals.add(s)

    def start(self):
        return self._start

    def productions(self, lhs=None, rhs=None):
        ps = self._productions
        if lhs is not None:
            if isinstance(lhs, str):
                lhs = Nonterminal(lhs)
            ps = [p for p in ps if p.lhs() == lhs]
        if rhs is not None:
            ps = [p for p in ps if p.rhs() and p.rhs()[0] == rhs]
        return list(ps)

    def check_coverage(self, tokens):
        missing = [t for t in tokens if t not in self._terminals]
        if missing:
            raise ValueError("Grammar does not cover some of the input words: %r." % (missing,))

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            raise TypeError("grammar text must be a str")
        productions = []
        for lineno, raw in enumerate(input.splitlines(), 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "->" in line:
                lhs_s, rhs_s = line.split("->", 1)
            elif "→" in line:
                lhs_s, rhs_s = line.split("→", 1)
            else:
                raise ValueError("Unable to parse line %d: %s" % (lineno, raw))
            lhs_s = lhs_s.strip()
            if not lhs_s or re.search(r"\s", lhs_s):
                raise ValueError("Bad left-hand side on line %d: %s" % (lineno, raw))
            lhs = Nonterminal(lhs_s)
            alt = []
            alts = []
            for tok in _TOKEN.findall(rhs_s):
                if tok == "|":
                    alts.append(alt)
                    alt = []
                elif tok[0] in "'\"":
                    if len(tok) < 2 or tok[-1] != tok[0]:
                        raise ValueError("Unterminated quote on line %d" % lineno)
                    alt.append(tok[1:-1])
                else:
                    alt.append(Nonterminal(tok))
            alts.append(alt)
            for a in alts:
                productions.append(Production(lhs, a))
        if not productions:
            raise ValueError("No productions found")
        return cls(productions[0].lhs(), productions)

    def __str__(self):
        return "Grammar with %d productions (start state = %s)\n" % (len(self._productions), self._start) + \
            "".join("    %s\n" % p for p in self._productions)

    __repr__ = __str__
