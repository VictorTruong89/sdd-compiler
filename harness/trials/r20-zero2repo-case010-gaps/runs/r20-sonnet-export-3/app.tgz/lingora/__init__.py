"""lingora: a pure-Python natural-language processing library (spec: N-000338..N-000344)."""
from . import data  # noqa: F401
from . import tokenize, stem, tag, chunk, grammar, parse, tree, classify, metrics, translate  # noqa: F401

__version__ = "0.1.0"
