"""Constituent trees. spec: N-000444..N-000454"""
import re


class Tree:
    def __init__(self, label, children):
        if isinstance(children, str) or children is None or not isinstance(children, (list, tuple)):
            raise TypeError("Tree children must be a list of children, not %r" % type(children).__name__)
        self._label = label
        self._children = list(children)

    def label(self):
        return self._label

    def set_label(self, label):
        self._label = label

    def leaves(self):
        out = []
        for c in self._children:
            if isinstance(c, Tree):
                out.extend(c.leaves())
            else:
                out.append(c)
        return out

    def __iter__(self):
        return iter(self._children)

    def __len__(self):
        return len(self._children)

    def __getitem__(self, i):
        return self._children[i]

    def __eq__(self, other):
        return isinstance(other, Tree) and self._label == other._label and self._children == other._children

    def __ne__(self, other):
        return not self == other

    __hash__ = None

    def append(self, c):
        self._children.append(c)

    def copy(self):
        return Tree(self._label, [c.copy() if isinstance(c, Tree) else c for c in self._children])

    def pos(self):
        out = []
        for c in self._children:
            if isinstance(c, Tree):
                out.extend(c.pos())
            else:
                out.append((c, self._label))
        return out

    def height(self):
        h = 1
        for c in self._children:
            if isinstance(c, Tree):
                h = max(h, c.height() + 1)
            else:
                h = max(h, 2)
        return h

    def productions(self):
        from .grammar import Production, Nonterminal
        rhs = [Nonterminal(c._label) if isinstance(c, Tree) else c for c in self._children]
        out = [Production(Nonterminal(self._label), rhs)]
        for c in self._children:
            if isinstance(c, Tree):
                out.extend(c.productions())
        return out

    def subtrees(self):
        yield self
        for c in self._children:
            if isinstance(c, Tree):
                yield from c.subtrees()

    def __repr__(self):
        return "Tree(%r, %r)" % (self._label, self._children)

    def __str__(self):
        return self.pformat()

    def _flat(self):
        parts = []
        for c in self._children:
            parts.append(c._flat() if isinstance(c, Tree) else str(c))
        return "(%s%s)" % (self._label, "".join(" " + p for p in parts))

    def pformat(self, margin=70, indent=0):
        s = self._flat()
        if len(s) + indent <= margin or not any(isinstance(c, Tree) for c in self._children):
            return s
        out = "(%s" % (self._label,)
        for c in self._children:
            out += "\n" + " " * (indent + 2)
            out += c.pformat(margin, indent + 2) if isinstance(c, Tree) else str(c)
        return out + ")"

    @classmethod
    def fromstring(cls, s, brackets="()"):
        open_b, close_b = brackets
        tok = re.compile(r"\%s|\%s|[^\s\%s\%s]+" % (open_b, close_b, open_b, close_b))
        tokens = tok.findall(s)
        pos = 0

        def parse():
            nonlocal pos
            if tokens[pos] != open_b:
                raise ValueError("expected %r" % open_b)
            pos += 1
            label = ""
            if pos < len(tokens) and tokens[pos] not in (open_b, close_b):
                label = tokens[pos]
                pos += 1
            children = []
            while True:
                if pos >= len(tokens):
                    raise ValueError("unbalanced brackets in tree text")
                t = tokens[pos]
                if t == close_b:
                    pos += 1
                    return cls(label, children)
                if t == open_b:
                    children.append(parse())
                else:
                    children.append(t)
                    pos += 1

        if not tokens:
            raise ValueError("empty tree text")
        if tokens[0] != open_b:
            # bare leaf: treat as label-less
            raise ValueError("tree text must start with %r" % open_b)
        t = parse()
        if pos != len(tokens):
            raise ValueError("extra text after tree")
        return t
