"""Tokenizers. spec: pack 07 / FP-01"""
import html
import os
import re
import string
from collections import defaultdict

from . import data

# ------------------------------------------------------------------ regexp-based


class TokenizerI:
    def tokenize(self, text):
        raise NotImplementedError

    def span_tokenize(self, text):
        raise NotImplementedError


class RegexpTokenizer(TokenizerI):
    def __init__(self, pattern, gaps=False, discard_empty=True, flags=re.UNICODE | re.MULTILINE | re.DOTALL):
        self._pattern = pattern
        self._gaps = gaps
        self._discard_empty = discard_empty
        self._flags = flags
        self._regexp = re.compile(pattern, flags)

    def span_tokenize(self, text):
        if self._gaps:
            pos = 0
            for m in self._regexp.finditer(text):
                s, e = m.span()
                if e == s and (s == 0 or s == len(text)):
                    continue
                if not (self._discard_empty and s == pos):
                    yield (pos, s)
                pos = e
            if not (self._discard_empty and pos == len(text)):
                yield (pos, len(text))
        else:
            for m in self._regexp.finditer(text):
                if self._discard_empty and m.end() == m.start():
                    continue
                yield m.span()

    def tokenize(self, text):
        if not isinstance(text, str):
            raise TypeError("text must be a str")
        return [text[s:e] for s, e in self.span_tokenize(text)]


class WhitespaceTokenizer(RegexpTokenizer):
    def __init__(self):
        super().__init__(r"\s+", gaps=True)


class WordPunctTokenizer(RegexpTokenizer):
    def __init__(self):
        super().__init__(r"\w+|[^\w\s]+")


class BlanklineTokenizer(RegexpTokenizer):
    def __init__(self):
        super().__init__(r"\s*\n\s*\n\s*", gaps=True)

    def span_tokenize(self, text):
        if not text.strip():
            return iter(())
        return super().span_tokenize(text)


_wordpunct = WordPunctTokenizer()


def wordpunct_tokenize(text):
    return _wordpunct.tokenize(text)


def blankline_tokenize(text):
    return BlanklineTokenizer().tokenize(text)


# ------------------------------------------------------------------ Penn Treebank


class TreebankWordTokenizer(TokenizerI):
    STARTING_QUOTES = [
        (re.compile(r"^\""), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
    ]
    PUNCTUATION = [
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.\.\."), r" ... "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\']*)\s*$'), r"\1 \2\3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
    ]
    PARENS_BRACKETS = (re.compile(r"[\]\[\(\)\{\}\<\>]"), r" \g<0> ")
    DOUBLE_DASHES = (re.compile(r"--"), r" -- ")
    ENDING_QUOTES = [
        (re.compile(r'"'), " '' "),
        (re.compile(r"(\S)(\'\')"), r"\1 \2 "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    CONTRACTIONS2 = [re.compile(r) for r in (
        r"(?i)\b(can)(?#X)(not)\b", r"(?i)\b(d)(?#X)('ye)\b", r"(?i)\b(gim)(?#X)(me)\b",
        r"(?i)\b(gon)(?#X)(na)\b", r"(?i)\b(got)(?#X)(ta)\b", r"(?i)\b(lem)(?#X)(me)\b",
        r"(?i)\b(more)(?#X)('n)\b", r"(?i)\b(wan)(?#X)(na)(?=\s)")]
    CONTRACTIONS3 = [re.compile(r) for r in (r"(?i) ('t)(?#X)(is)\b", r"(?i) ('t)(?#X)(was)\b")]

    def tokenize(self, text, convert_parentheses=False, return_str=False):
        if not isinstance(text, str):
            raise TypeError("text must be a str")
        for rx, sub in self.STARTING_QUOTES:
            text = rx.sub(sub, text)
        for rx, sub in self.PUNCTUATION:
            text = rx.sub(sub, text)
        rx, sub = self.PARENS_BRACKETS
        text = rx.sub(sub, text)
        rx, sub = self.DOUBLE_DASHES
        text = rx.sub(sub, text)
        text = " " + text + " "
        for rx, sub in self.ENDING_QUOTES:
            text = rx.sub(sub, text)
        for rx in self.CONTRACTIONS2:
            text = rx.sub(r" \1 \2 ", text)
        for rx in self.CONTRACTIONS3:
            text = rx.sub(r" \1 \2 ", text)
        text = re.sub(r"  +", " ", text)
        return text.strip() if return_str else text.split()


class NLTKLikeWordTokenizer(TreebankWordTokenizer):
    """Recommended word tokenizer: Treebank conventions plus improvements."""
    STARTING_QUOTES = [
        (re.compile("([«“‘„]|[`]+)"), r" \1 "),
        (re.compile(r"^\""), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
    ]
    ENDING_QUOTES = [
        (re.compile("([»”’])"), r" \1 "),
        (re.compile(r"''"), " '' "),
        (re.compile(r'"'), " '' "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    PUNCTUATION = [
        (re.compile(r"([^\.])(\.)([\]\)}>\"'»”’ ]*)\s*$"), r"\1 \2 \3 "),
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.{2,}"), r" \g<0> "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
        (re.compile(r"[*]"), r" \g<0> "),
        (re.compile("[‒–—―]"), r" \g<0> "),
    ]


_treebank = TreebankWordTokenizer()
_nltk_like = NLTKLikeWordTokenizer()


# ------------------------------------------------------------------ Punkt


_ORTHO_BEG_UC = 1 << 1
_ORTHO_MID_UC = 1 << 2
_ORTHO_UNK_UC = 1 << 3
_ORTHO_UC = _ORTHO_BEG_UC | _ORTHO_MID_UC | _ORTHO_UNK_UC
_ORTHO_BEG_LC = 1 << 4
_ORTHO_MID_LC = 1 << 5
_ORTHO_UNK_LC = 1 << 6
_ORTHO_LC = _ORTHO_BEG_LC | _ORTHO_MID_LC | _ORTHO_UNK_LC

_SENT_END = ".?!"
_NON_WORD = r"(?:[?!)\";}\]\*:@\'\({\[])"
_WORD_START = r"[^\(\"\`{\[:;&\#\*@\)}\]\-,]"
_MULTI = r"(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"
_WORD_TOK_RE = re.compile(
    r"(%(M)s|(?=%(W)s)\S+?(?=\s|$|%(N)s|%(M)s|,(?=$|\s|%(N)s|%(M)s))|\S)" % {"M": _MULTI, "W": _WORD_START, "N": _NON_WORD},
    re.UNICODE)
_PERIOD_CTX_RE = re.compile(
    r"\S*[%s](?=(?P<after_tok>%s|\s+(?P<next_tok>\S+)))" % (re.escape(_SENT_END), _NON_WORD), re.UNICODE)
_REALIGN_RE = re.compile(r'["\')\]}]+?(?:\s+|(?=--)|$)', re.MULTILINE)
_RE_NUMERIC = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_RE_ELLIPSIS = re.compile(r"\.\.+$")
_RE_INITIAL = re.compile(r"[^\W\d]\.$")
_RE_NON_PUNCT = re.compile(r"[^\W\d]")
_PUNCT = tuple(";:,.!?")


class _Token:
    __slots__ = ("tok", "type", "period_final", "abbr", "ellipsis", "sentbreak")

    def __init__(self, tok):
        self.tok = tok
        self.type = _RE_NUMERIC.sub("##number##", tok.lower())
        self.period_final = tok.endswith(".")
        self.abbr = False
        self.ellipsis = False
        self.sentbreak = False

    @property
    def type_no_period(self):
        if len(self.type) > 1 and self.type[-1] == ".":
            return self.type[:-1]
        return self.type

    @property
    def type_no_sentperiod(self):
        return self.type_no_period if self.sentbreak else self.type

    @property
    def first_upper(self):
        return self.tok[0].isupper()

    @property
    def first_lower(self):
        return self.tok[0].islower()

    @property
    def is_initial(self):
        return bool(_RE_INITIAL.match(self.tok))


class PunktParameters:
    def __init__(self):
        self.abbrev_types = set()
        self.collocations = set()
        self.sent_starters = set()
        self.ortho_context = defaultdict(int)


_punkt_cache = {}


def _load_punkt(language):
    if not isinstance(language, str) or not language or "/" in language or "\\" in language or language.startswith("."):
        raise ValueError("bad language name %r" % (language,))
    d = data.find("tokenizers/punkt_tab/%s" % language)
    names = ("abbrev_types.txt", "sent_starters.txt", "collocations.tab", "ortho_context.tab")
    paths = [os.path.join(d, n) for n in names]
    key = tuple((p, os.stat(p).st_mtime_ns) for p in paths)
    if key in _punkt_cache:
        return _punkt_cache[key]
    params = PunktParameters()
    for line in data.read_lines(paths[0]):
        if line.strip():
            params.abbrev_types.add(line.strip())
    for line in data.read_lines(paths[1]):
        if line.strip():
            params.sent_starters.add(line.strip())
    for line in data.read_lines(paths[2]):
        parts = line.split("\t")
        if len(parts) >= 2:
            params.collocations.add((parts[0], parts[1]))
    for line in data.read_lines(paths[3]):
        parts = line.split("\t")
        if len(parts) >= 2:
            params.ortho_context[parts[0]] |= int(parts[1])
    _punkt_cache.clear()
    _punkt_cache[key] = params
    return params


class PunktSentenceTokenizer(TokenizerI):
    def __init__(self, params):
        self._params = params

    # --- annotation
    def _tokenize_words(self, plaintext):
        for line in plaintext.split("\n"):
            if line.strip():
                for tok in _WORD_TOK_RE.findall(line):
                    yield _Token(tok)

    def _first_pass(self, t):
        tok = t.tok
        p = self._params
        if tok in _SENT_END:
            t.sentbreak = True
        elif _RE_ELLIPSIS.match(tok):
            t.ellipsis = True
        elif t.period_final and not tok.endswith(".."):
            low = tok[:-1].lower()
            if low in p.abbrev_types or low.split("-")[-1] in p.abbrev_types:
                t.abbr = True
            else:
                t.sentbreak = True

    def _ortho(self, t):
        if t.tok in _PUNCT:
            return False
        oc = self._params.ortho_context[t.type_no_sentperiod]
        if t.first_upper and (oc & _ORTHO_LC) and not (oc & _ORTHO_MID_UC):
            return True
        if t.first_lower and ((oc & _ORTHO_UC) or not (oc & _ORTHO_BEG_LC)):
            return False
        return "unknown"

    def _second_pass(self, t1, t2):
        if t2 is None or not t1.period_final:
            return
        p = self._params
        typ = t1.type_no_period
        next_typ = t2.type_no_sentperiod
        initial = t1.is_initial
        if (typ, next_typ) in p.collocations:
            t1.sentbreak = False
            t1.abbr = True
            return
        if (t1.abbr or t1.ellipsis) and not initial:
            if self._ortho(t2) is True:
                t1.sentbreak = True
                return
            if t2.first_upper and next_typ in p.sent_starters:
                t1.sentbreak = True
                return
        if initial or typ == "##number##":
            s = self._ortho(t2)
            if s is False:
                t1.sentbreak = False
                t1.abbr = True
                return
            if s == "unknown" and initial and t2.first_upper and not (p.ortho_context[next_typ] & _ORTHO_LC):
                t1.sentbreak = False
                t1.abbr = True
                return

    def _contains_sentbreak(self, context):
        toks = list(self._tokenize_words(context))
        for t in toks:
            self._first_pass(t)
        for i, t in enumerate(toks):
            self._second_pass(t, toks[i + 1] if i + 1 < len(toks) else None)
        found = False
        for t in toks:
            if found:
                return True
            if t.sentbreak:
                found = True
        return False

    # --- slicing
    @staticmethod
    def _last_ws(text):
        for i in range(len(text) - 1, -1, -1):
            if text[i] in string.whitespace:
                return i
        return 0

    def _contexts(self, text):
        prev_slice = (0, 0)
        prev_match = None
        for m in _PERIOD_CTX_RE.finditer(text):
            before = text[prev_slice[1]:m.start()]
            idx = self._last_ws(before)
            if idx:
                idx += prev_slice[1] + 1
            else:
                idx = prev_slice[0]
            cur = (idx, m.start())
            if prev_match is not None and prev_slice[1] <= cur[0]:
                yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + prev_match.group("after_tok")
            prev_match = m
            prev_slice = cur
        if prev_match is not None:
            yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + prev_match.group("after_tok")

    def _slices(self, text):
        last = 0
        for m, ctx in self._contexts(text):
            if self._contains_sentbreak(ctx):
                yield (last, m.end())
                if m.group("next_tok"):
                    last = m.start("next_tok")
                else:
                    last = m.end()
        yield (last, len(text.rstrip()))

    def _realign(self, text, slices):
        slices = list(slices)
        realign = 0
        for i, s1 in enumerate(slices):
            s2 = slices[i + 1] if i + 1 < len(slices) else None
            s1 = (s1[0] + realign, s1[1])
            if s2 is None:
                if text[s1[0]:s1[1]]:
                    yield s1
                continue
            m = _REALIGN_RE.match(text[s2[0]:s2[1]])
            if m:
                yield (s1[0], s2[0] + len(m.group(0).rstrip()))
                realign = m.end()
            else:
                realign = 0
                if text[s1[0]:s1[1]]:
                    yield s1

    def span_tokenize(self, text, realign_boundaries=True):
        sl = self._slices(text)
        if realign_boundaries:
            sl = self._realign(text, sl)
        return iter(list(sl))

    def tokenize(self, text, realign_boundaries=True):
        if not isinstance(text, str):
            raise TypeError("text must be a str")
        return [text[s:e] for s, e in self.span_tokenize(text, realign_boundaries)]


def sent_tokenize(text, language="english"):
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    params = _load_punkt(language)  # raises when the model is not visible
    return PunktSentenceTokenizer(params).tokenize(text)


def word_tokenize(text, language="english", preserve_line=False):
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    sentences = [text] if preserve_line else sent_tokenize(text, language)
    return [tok for sent in sentences for tok in _nltk_like.tokenize(sent)]


# ------------------------------------------------------------------ Tweets

_EMOTICONS = r"""
    (?:
      [<>]?
      [:;=8]
      [\-o\*\']?
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      |
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      [\-o\*\']?
      [:;=8]
      [<>]?
      |
      </?3
    )"""
_URLS = r"""
  (?:
  https?:
    (?:
      /{1,3}
      |
      [a-z0-9%]
    )
    |
    [a-z0-9.\-]+[.]
    (?:[a-z]{2,13})
    /
  )
  (?:
    [^\s()<>{}\[\]]+
    |
    \([^\s()]*?\([^\s()]+\)[^\s()]*?\)
    |
    \([^\s]+?\)
  )+
  (?:
    \([^\s()]*?\([^\s()]+\)[^\s()]*?\)
    |
    \([^\s]+?\)
    |
    [^\s`!()\[\]{};:'".,<>?«»“”‘’]
  )
  |
  (?:
    (?<!@)
    [a-z0-9]+
    (?:[.\-][a-z0-9]+)*
    [.]
    (?:[a-z]{2,13})
    \b
    /?
    (?!@)
  )
"""
_PHONE = r"""
    (?:
      (?:
        \+?[01]
        [ *\-.\)]*
      )?
      (?:
        [\(]?
        \d{3}
        [ *\-.\)]*
      )?
      \d{3}
      [ *\-.\)]*
      \d{4}
    )"""
_HTML_TAGS = r"""<[^>\s]+>"""
_ARROWS = r"""[\-]+>|<[\-]+"""
_USERNAME = r"""(?:@[\w_]+)"""
_HASHTAG = r"""(?:\#+[\w_]+[\w\'_\-]*[\w_]+)"""
_EMAIL = r"""[\w.+-]+@[\w-]+\.(?:[\w-]\.?)+[\w-]"""
_WORDS = r"""
    (?:[^\W\d_](?:[^\W\d_]|['\-_])+[^\W\d_])
    |
    (?:[+\-]?\d+[,/.:-]\d+[+\-]?)
    |
    (?:[\w_]+)
    |
    (?:\.(?:\s*\.){1,})
    |
    (?:\S)
"""
_WORD_RE = re.compile("(%s)" % "|".join((_URLS, _PHONE, _EMOTICONS, _HTML_TAGS, _ARROWS, _USERNAME,
                                          _HASHTAG, _EMAIL, _WORDS)), re.VERBOSE | re.I | re.UNICODE)
_EMOTICON_RE = re.compile(_EMOTICONS, re.VERBOSE | re.I | re.UNICODE)
_HANG_RE = re.compile(r"([^a-zA-Z0-9])\1{3,}")
_LEN_RE = re.compile(r"(.)\1{2,}", re.DOTALL)
_HANDLES_RE = re.compile(
    r"(?<![A-Za-z0-9_!@#\$%&*])@(([A-Za-z0-9_]){15}(?!@)|([A-Za-z0-9_]){1,14}(?![A-Za-z0-9_]*@))")
_ENT_RE = re.compile(r"&(#?(x?))([^&;\s]+);")


def _replace_entities(text):
    def rep(m):
        ent = m.group(0)
        try:
            if m.group(1):
                num = int(m.group(3), 16 if m.group(2) else 10)
                return chr(num)
            u = html.unescape(ent)
            return u
        except (ValueError, OverflowError):
            return ent
    return _ENT_RE.sub(rep, text)


class TweetTokenizer(TokenizerI):
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False, match_phone_numbers=True):
        self.preserve_case = preserve_case
        self.reduce_len = reduce_len
        self.strip_handles = strip_handles

    def tokenize(self, text):
        if not isinstance(text, str):
            raise TypeError("text must be a str")
        text = _replace_entities(text)
        if self.strip_handles:
            text = _HANDLES_RE.sub(" ", text)
        if self.reduce_len:
            text = _LEN_RE.sub(r"\1\1\1", text)
        safe = _HANG_RE.sub(r"\1\1\1", text)
        words = _WORD_RE.findall(safe)
        words = [w[0] if isinstance(w, tuple) else w for w in words]
        if not self.preserve_case:
            words = [w if _EMOTICON_RE.search(w) else w.lower() for w in words]
        return words
