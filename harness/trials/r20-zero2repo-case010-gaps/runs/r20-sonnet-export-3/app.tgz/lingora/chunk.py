"""Regular-expression chunking. spec: N-000410..N-000423, FP-04"""
import re

from .tree import Tree
from . import data

ROOT = "S"  # spec: N-000419/N-000420 default sentence label (implementer's choice)


def tag_pattern2re_pattern(tag_pattern):
    p = re.sub(r"\s", "", tag_pattern)
    p = re.sub(r"(?<!\\)\.", r"[^\\{\\}<>]", p)
    p = p.replace("<", "(?:<(?:").replace(">", ")>)")
    return p


_IN_CHUNK = r"(?=[^\{]*\})"
_IN_STRIP = r"(?=[^\}]*(?:\{|$))"


class _Rule:
    def __init__(self, kind, pattern):
        self.kind = kind
        self.pattern = pattern
        core = tag_pattern2re_pattern(pattern)
        try:
            if kind == "chunk":
                self.regexp = re.compile("(?P<chunk>%s)%s" % (core, _IN_STRIP))
                self.repl = r"{\g<chunk>}"
            else:
                self.regexp = re.compile("(?P<chink>%s)%s" % (core, _IN_CHUNK))
                self.repl = r"}\g<chink>{"
        except re.error as e:
            raise ValueError("Bad tag pattern %r: %s" % (pattern, e))

    def apply(self, s):
        s = self.regexp.sub(self.repl, s)
        return s.replace("{}", "")


def _tag_of(item):
    if isinstance(item, Tree):
        return item.label()
    return item[1]


class _Stage:
    def __init__(self, label, rules):
        self.label = label
        self.rules = rules

    def run(self, items):
        s = "".join("<%s>" % _tag_of(it) for it in items)
        for r in self.rules:
            s = r.apply(s)
        pieces = re.split(r"[{}]", s)
        out = []
        pos = 0
        for i, piece in enumerate(pieces):
            cnt = piece.count("<")
            seg = items[pos:pos + cnt]
            pos += cnt
            if i % 2 == 1:
                if seg:
                    out.append(Tree(self.label, list(seg)))
            else:
                out.extend(seg)
        return out


_CLAUSE = re.compile(r"^(\S+?)\s*:\s*(.*)$")


def _parse_rule(text):
    text = text.strip()
    # strip trailing comment
    text = re.sub(r"\s*#.*$", "", text)
    if not text:
        return None
    if text.startswith("{") and text.endswith("}"):
        return _Rule("chunk", text[1:-1])
    if text.startswith("}") and text.endswith("{"):
        return _Rule("chink", text[1:-1])
    raise ValueError("Illegal chunk pattern: %r" % text)


def _parse_grammar(grammar):
    stages = []
    cur = None
    for line in grammar.split("\n"):
        if not line.strip() or line.strip().startswith("#"):
            continue
        if line[0] in " \t":
            if cur is None:
                raise ValueError("Pattern line before any clause: %r" % line)
            r = _parse_rule(line)
            if r:
                cur[1].append(r)
            continue
        m = _CLAUSE.match(line.strip())
        if not m:
            raise ValueError("Illegal clause: %r" % line)
        cur = (m.group(1), [])
        stages.append(cur)
        r = _parse_rule(m.group(2))
        if r:
            cur[1].append(r)
    if not stages:
        raise ValueError("Grammar has no clauses")
    return [_Stage(l, rs) for l, rs in stages]


class RegexpParser:
    def __init__(self, grammar, root_label=ROOT, loop=1):
        if isinstance(grammar, str):
            self._stages = _parse_grammar(grammar)
        else:
            self._stages = list(grammar)
        self._root = root_label
        self._loop = loop

    def parse(self, tagged):
        if isinstance(tagged, str):
            raise TypeError("tagged tokens must be a list of (token, tag) pairs")
        items = [tuple(t) for t in tagged]
        for _ in range(self._loop):
            for st in self._stages:
                items = st.run(items)
        return Tree(self._root, items)


def ne_chunk(tagged_tokens, binary=False):
    """Named-entity chunker; needs the packaged model and the English wordlist."""
    data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    data.find("corpora/words")
    if isinstance(tagged_tokens, str):
        raise TypeError("tagged_tokens must be a list of (token, tag) pairs")
    # spec: results with the resource present are outside the specification (N-000219);
    # this build returns the tagged tokens without entity grouping.
    return Tree("S", [tuple(t) for t in tagged_tokens])
