"""Stemmers. spec: pack 09 / FP-02"""
import os
import re

from . import data


class StemmerI:
    def stem(self, token):
        raise NotImplementedError


# ------------------------------------------------------------------ Porter
class PorterStemmer(StemmerI):
    NLTK_EXTENSIONS = "NLTK_EXTENSIONS"
    MARTIN_EXTENSIONS = "MARTIN_EXTENSIONS"
    ORIGINAL_ALGORITHM = "ORIGINAL_ALGORITHM"

    def __init__(self, mode="NLTK_EXTENSIONS"):
        if mode not in (self.NLTK_EXTENSIONS, self.MARTIN_EXTENSIONS, self.ORIGINAL_ALGORITHM):
            raise ValueError("Mode must be one of NLTK_EXTENSIONS, MARTIN_EXTENSIONS, ORIGINAL_ALGORITHM")
        self.mode = mode
        self.pool = {}
        if mode == self.NLTK_EXTENSIONS:
            irregular = {
                "sky": ["sky", "skies"], "die": ["dying"], "lie": ["lying"], "tie": ["tying"],
                "news": ["news"], "inning": ["innings", "inning"], "outing": ["outings", "outing"],
                "canning": ["cannings", "canning"], "howe": ["howe"], "proceed": ["proceed"],
                "exceed": ["exceed"], "succeed": ["succeed"],
            }
            for key, vals in irregular.items():
                for v in vals:
                    self.pool[v] = key

    vowels = frozenset(["a", "e", "i", "o", "u"])

    def _is_consonant(self, word, i):
        if word[i] in self.vowels:
            return False
        if word[i] == "y":
            if i == 0:
                return True
            return not self._is_consonant(word, i - 1)
        return True

    def _measure(self, stem):
        cv = "".join("c" if self._is_consonant(stem, i) else "v" for i in range(len(stem)))
        return cv.count("vc")

    def _has_positive_measure(self, stem):
        return self._measure(stem) > 0

    def _contains_vowel(self, stem):
        return any(not self._is_consonant(stem, i) for i in range(len(stem)))

    def _ends_double_consonant(self, word):
        return len(word) >= 2 and word[-1] == word[-2] and self._is_consonant(word, len(word) - 1)

    def _ends_cvc(self, word):
        return (
            len(word) >= 3 and self._is_consonant(word, len(word) - 3)
            and not self._is_consonant(word, len(word) - 2)
            and self._is_consonant(word, len(word) - 1) and word[-1] not in ("w", "x", "y")
        ) or (
            self.mode == self.NLTK_EXTENSIONS and len(word) == 2
            and not self._is_consonant(word, 0) and self._is_consonant(word, 1)
        )

    @staticmethod
    def _replace_suffix(word, suffix, replacement):
        if suffix == "":
            return word + replacement
        return word[:-len(suffix)] + replacement

    def _apply_rule_list(self, word, rules):
        for suffix, replacement, condition in rules:
            if suffix == "*d" and self._ends_double_consonant(word):
                stem = word[:-2]
                if condition is None or condition(stem):
                    return stem + replacement
                return word
            if word.endswith(suffix):
                stem = self._replace_suffix(word, suffix, "")
                if condition is None or condition(stem):
                    return stem + replacement
                return word
        return word

    def _step1a(self, word):
        if self.mode == self.NLTK_EXTENSIONS:
            if word.endswith("ies") and len(word) == 4:
                return self._replace_suffix(word, "ies", "ie")
        return self._apply_rule_list(word, [("sses", "ss", None), ("ies", "i", None), ("ss", "ss", None), ("s", "", None)])

    def _step1b(self, word):
        if self.mode == self.NLTK_EXTENSIONS:
            if word.endswith("ied"):
                if len(word) == 4:
                    return self._replace_suffix(word, "ied", "ie")
                return self._replace_suffix(word, "ied", "i")
        if word.endswith("eed"):
            stem = self._replace_suffix(word, "eed", "")
            if self._measure(stem) > 0:
                return stem + "ee"
            return word
        ok = False
        inter = word
        for suffix in ["ed", "ing"]:
            if word.endswith(suffix):
                inter = self._replace_suffix(word, suffix, "")
                if self._contains_vowel(inter):
                    ok = True
                    break
        if not ok:
            return word
        return self._apply_rule_list(inter, [
            ("at", "ate", None), ("bl", "ble", None), ("iz", "ize", None),
            ("*d", inter[-1], lambda stem: inter[-1] not in ("l", "s", "z")),
            ("", "e", lambda stem: self._measure(stem) == 1 and self._ends_cvc(stem)),
        ])

    def _step1c(self, word):
        def cond(stem):
            return len(stem) > 1 and self._is_consonant(stem, len(stem) - 1)

        def cond_orig(stem):
            return self._contains_vowel(stem)
        if self.mode == self.NLTK_EXTENSIONS:
            return self._apply_rule_list(word, [("y", "i", cond)])
        return self._apply_rule_list(word, [("y", "i", cond_orig)])

    def _step2(self, word):
        pm = self._has_positive_measure
        if self.mode == self.NLTK_EXTENSIONS:
            if word.endswith("alli") and pm(self._replace_suffix(word, "alli", "")):
                return self._step2(self._replace_suffix(word, "alli", "al"))
        bli = ("bli", "ble", pm)
        abli = ("abli", "able", pm)
        rules = [
            ("ational", "ate", pm), ("tional", "tion", pm), ("enci", "ence", pm), ("anci", "ance", pm),
            ("izer", "ize", pm), abli if self.mode == self.ORIGINAL_ALGORITHM else bli,
            ("alli", "al", pm), ("entli", "ent", pm), ("eli", "e", pm), ("ousli", "ous", pm),
            ("ization", "ize", pm), ("ation", "ate", pm), ("ator", "ate", pm), ("alism", "al", pm),
            ("iveness", "ive", pm), ("fulness", "ful", pm), ("ousness", "ous", pm), ("aliti", "al", pm),
            ("iviti", "ive", pm), ("biliti", "ble", pm),
        ]
        if self.mode == self.NLTK_EXTENSIONS:
            rules.append(("fulli", "ful", pm))
            rules.append(("logi", "log", lambda stem: pm(word[:-3])))
        if self.mode == self.MARTIN_EXTENSIONS:
            rules.append(("logi", "log", pm))
        return self._apply_rule_list(word, rules)

    def _step3(self, word):
        pm = self._has_positive_measure
        return self._apply_rule_list(word, [
            ("icate", "ic", pm), ("ative", "", pm), ("alize", "al", pm), ("iciti", "ic", pm),
            ("ical", "ic", pm), ("ful", "", pm), ("ness", "", pm)])

    def _step4(self, word):
        m1 = lambda stem: self._measure(stem) > 1  # noqa: E731
        return self._apply_rule_list(word, [
            ("al", "", m1), ("ance", "", m1), ("ence", "", m1), ("er", "", m1), ("ic", "", m1),
            ("able", "", m1), ("ible", "", m1), ("ant", "", m1), ("ement", "", m1), ("ment", "", m1),
            ("ent", "", m1),
            ("ion", "", lambda stem: self._measure(stem) > 1 and stem[-1] in ("s", "t")),
            ("ou", "", m1), ("ism", "", m1), ("ate", "", m1), ("iti", "", m1), ("ous", "", m1),
            ("ive", "", m1), ("ize", "", m1)])

    def _step5a(self, word):
        if word.endswith("e"):
            stem = self._replace_suffix(word, "e", "")
            if self._measure(stem) > 1:
                return stem
            if self._measure(stem) == 1 and not self._ends_cvc(stem):
                return stem
        return word

    def _step5b(self, word):
        return self._apply_rule_list(word, [("ll", "l", lambda stem: self._measure(word[:-1]) > 1)])

    def stem(self, word, to_lowercase=True):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        stem = word.lower() if to_lowercase else word
        if self.mode == self.NLTK_EXTENSIONS and stem in self.pool:
            return self.pool[stem]
        if self.mode != self.ORIGINAL_ALGORITHM and len(word) <= 2:
            return stem
        stem = self._step1a(stem)
        stem = self._step1b(stem)
        stem = self._step1c(stem)
        stem = self._step2(stem)
        stem = self._step3(stem)
        stem = self._step4(stem)
        stem = self._step5a(stem)
        stem = self._step5b(stem)
        return stem


# ------------------------------------------------------------------ Lancaster
_LANCASTER_RULES = (
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>", "cn1t>", "dd1.", "dei3y>", "deec2ss.", "dee1.", "de2>",
    "dooh4>", "e1>", "feil1v.", "fi2>", "gni3>", "gai3y.", "ga2>", "gg1.", "ht*2.", "hsiug5ct.", "hsi3>",
    "i*1.", "i1y>", "ji1d.", "juf1s.", "ju1d.", "jo1d.", "jeh1r.", "jrev1t.", "jsim2t.", "jn1d.", "j1s.",
    "lbaifi6.", "lbai4y.", "lba3>", "lbi3.", "lib2l>", "lc1.", "lufi4y.", "luf3>", "lu2.", "lai3>", "lau3>",
    "la2>", "ll1.", "mui3.", "mu*2.", "msi3>", "mm1.", "nois4j>", "noix4ct.", "noi3>", "nai3>", "na2>",
    "nee0.", "ne2>", "nn1.", "pihs4>", "pp1.", "re2>", "rae0.", "ra2.", "ro2>", "ru2>", "rr1.", "rt1>",
    "rei3y>", "sei3y>", "sis2.", "si2>", "ssen4>", "ss0.", "suo3>", "su*2.", "s*1>", "s0.", "tacilp4y.",
    "ta2>", "tnem4>", "tne3>", "tna3>", "tpir2b.", "tpro2b.", "tcud1.", "tpmus2.", "tpec2iv.", "tulo2v.",
    "tsis0.", "tsi3>", "tt1.", "uqi3.", "ugo1.", "vis3j>", "vie0.", "vi2>", "ylb1>", "yli3y>", "ylp0.",
    "yl2>", "ygo1.", "yhp1.", "ymo1.", "ypo1.", "yti3>", "yte3>", "ytl2.", "yrtsi5.", "yra3>", "yro3>",
    "yfi3.", "ycn2t>", "yca3>", "zi2>", "zy1s.",
)
_LRULE = re.compile(r"^([a-z]+)(\*?)(\d)([a-z]*)([.>])$")


class LancasterStemmer(StemmerI):
    def __init__(self, rule_tuple=None, strip_prefix_flag=False):
        self.rule_dictionary = {}
        self._strip_prefix = strip_prefix_flag
        for rule in (rule_tuple or _LANCASTER_RULES):
            m = _LRULE.match(rule)
            if not m:
                continue
            self.rule_dictionary.setdefault(m.group(1)[0], []).append(m.groups())

    @staticmethod
    def _acceptable(word, remove_total):
        if word[0] in "aeiouy":
            return len(word) - remove_total >= 2
        if len(word) - remove_total >= 3:
            return word[1] in "aeiouy" or word[2] in "aeiouy"
        return False

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        word = word.lower()
        intact = True
        while word:
            applied = False
            stop = False
            for ending, star, rem, append, cont in self.rule_dictionary.get(word[-1], []):
                if not word.endswith(ending[::-1]):
                    continue
                if star and not intact:
                    continue
                rem = int(rem)
                if not self._acceptable(word, rem):
                    continue
                if rem > 0:
                    word = word[:-rem]
                word = word + append
                intact = False
                applied = True
                stop = cont == "."
                break
            if not applied or stop:
                break
        return word


# ------------------------------------------------------------------ Regexp
class RegexpStemmer(StemmerI):
    def __init__(self, regexp, min=0):
        if not hasattr(regexp, "pattern"):
            regexp = re.compile(regexp)
        self._regexp = regexp
        self._min = min

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        if len(word) < self._min:
            return word
        return self._regexp.sub("", word)


# ------------------------------------------------------------------ Snowball
SNOWBALL_LANGUAGES = ("arabic", "danish", "dutch", "english", "finnish", "french", "german", "hungarian",
                      "italian", "norwegian", "porter", "portuguese", "romanian", "russian", "spanish", "swedish")


def _stopwords(language):
    p = data.find("corpora/stopwords/%s" % language)
    if os.path.isdir(p):
        raise LookupError("stopwords resource is a directory: %s" % p)
    return set(w.strip() for w in data.read_lines(p) if w.strip())


class SnowballStemmer(StemmerI):
    languages = SNOWBALL_LANGUAGES

    def __init__(self, language, ignore_stopwords=False):
        if language not in self.languages:
            raise ValueError("The language '%s' is not supported." % (language,))
        self.language = language
        self.stopwords = _stopwords(language) if ignore_stopwords else set()
        from . import _snowball
        self.stemmer = _snowball.get(language)

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        w = word.lower()
        if w in self.stopwords:
            return w
        return self.stemmer(w)


# ------------------------------------------------------------------ Arabic light stemmers
class ARLSTem(StemmerI):
    _pre = ["وال", "بال", "كال", "فال", "لل", "ال", "و", "ب", "ك", "ف", "ل"]
    _suf = ["ات", "ان", "ين", "ون", "ها", "هم", "كم", "نا", "ية", "ة", "ي", "ه", "ا"]

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        w = re.sub("[ً-ْـ]", "", word)
        for p in self._pre:
            if w.startswith(p) and len(w) - len(p) >= 3:
                w = w[len(p):]
                break
        for s in self._suf:
            if w.endswith(s) and len(w) - len(s) >= 2:
                w = w[:-len(s)]
                break
        return w


class ARLSTem2(ARLSTem):
    pass


# ------------------------------------------------------------------ WordNet lemmatizer
_MORPH = {
    "n": [("s", ""), ("ses", "s"), ("ves", "f"), ("xes", "x"), ("zes", "z"), ("ches", "ch"), ("shes", "sh"),
          ("men", "man"), ("ies", "y")],
    "v": [("s", ""), ("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"), ("ed", ""), ("ing", "e"), ("ing", "")],
    "a": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
    "r": [],
}
_POSFILE = {"n": "noun", "v": "verb", "a": "adj", "r": "adv"}


class WordNetLemmatizer:
    def __init__(self):
        self._dir = data.find("corpora/wordnet")  # raises LookupError when WordNet is not visible
        self._lemmas = {}
        self._exc = {}

    def _load(self, pos):
        if pos in self._lemmas:
            return
        name = _POSFILE[pos]
        lemmas = set()
        with open(os.path.join(self._dir, "index." + name), encoding="utf-8") as f:
            for line in f:
                if line.startswith(" ") or not line.strip():
                    continue
                lemmas.add(line.split(" ", 1)[0])
        exc = {}
        ep = os.path.join(self._dir, name + ".exc")
        if os.path.exists(ep):
            with open(ep, encoding="utf-8") as f:
                for line in f:
                    parts = line.split()
                    if len(parts) >= 2:
                        exc.setdefault(parts[0], []).extend(parts[1:])
        self._lemmas[pos] = lemmas
        self._exc[pos] = exc

    def _morphy(self, form, pos):
        if pos == "s":
            pos = "a"
        self._load(pos)
        lem = self._lemmas[pos]
        exc = self._exc[pos]
        subs = _MORPH[pos]

        def filt(forms):
            out = []
            for f in forms:
                if f in lem and f not in out:
                    out.append(f)
            return out

        def apply(forms):
            return [f[:-len(o)] + n for f in forms for o, n in subs if f.endswith(o)]

        if form in exc:
            return filt([form] + exc[form])
        forms = apply([form])
        res = filt([form] + forms)
        if res:
            return res
        while forms:
            forms = apply(forms)
            res = filt(forms)
            if res:
                return res
        return []

    def lemmatize(self, word, pos="n"):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        if pos not in ("n", "v", "a", "r", "s"):
            raise ValueError("bad pos %r" % (pos,))
        self._dir = data.find("corpora/wordnet")
        lemmas = self._morphy(word, pos)
        return min(lemmas, key=len) if lemmas else word
