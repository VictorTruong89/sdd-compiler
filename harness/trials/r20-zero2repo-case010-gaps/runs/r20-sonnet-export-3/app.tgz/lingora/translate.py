"""BLEU. spec: N-000473..N-000477, FP-07"""
import math
import sys
from collections import Counter
from fractions import Fraction


def _ngrams(seq, n):
    return [tuple(seq[i:i + n]) for i in range(len(seq) - n + 1)]


def modified_precision(references, hypothesis, n):
    counts = Counter(_ngrams(hypothesis, n)) if len(hypothesis) >= n else Counter()
    max_counts = {}
    for ref in references:
        rc = Counter(_ngrams(ref, n)) if len(ref) >= n else Counter()
        for ng in counts:
            max_counts[ng] = max(max_counts.get(ng, 0), rc[ng])
    clipped = {ng: min(c, max_counts.get(ng, 0)) for ng, c in counts.items()}
    numerator = sum(clipped.values())
    denominator = max(1, sum(counts.values()))
    return Fraction(numerator, denominator)


def closest_ref_length(references, hyp_len):
    lens = (len(r) for r in references)
    return min(lens, key=lambda rl: (abs(rl - hyp_len), rl))


def brevity_penalty(closest_ref_len, hyp_len):
    if hyp_len > closest_ref_len:
        return 1
    if hyp_len == 0:
        return 0
    return math.exp(1 - closest_ref_len / hyp_len)


class SmoothingFunction:
    """Subset of the standard smoothing methods."""

    def __init__(self, epsilon=0.1, alpha=5, k=5):
        self.epsilon = epsilon
        self.alpha = alpha
        self.k = k

    def method0(self, p_n, *a, **k):
        out = []
        for p in p_n:
            out.append(p if p.numerator != 0 else sys.float_info.min)
        return out

    def method1(self, p_n, references, hypothesis, hyp_len=None, *a, **k):
        return [(p.numerator + self.epsilon) / p.denominator if p.numerator == 0 else p for p in p_n]

    def method2(self, p_n, references, hypothesis, hyp_len=None, *a, **k):
        return [Fraction(p.numerator + 1, p.denominator + 1) for p in p_n]


def sentence_bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):
    p_numerators = Counter()
    p_denominators = Counter()
    hyp_len = len(hypothesis)
    for i in range(1, len(weights) + 1):
        p = modified_precision(references, hypothesis, i)
        p_numerators[i] = p.numerator
        p_denominators[i] = p.denominator
    ref_len = closest_ref_length(references, hyp_len)
    bp = brevity_penalty(ref_len, hyp_len)
    if p_numerators[1] == 0:
        return 0
    p_n = [Fraction(p_numerators[i], p_denominators[i]) for i in range(1, len(weights) + 1)]
    if smoothing_function is None:
        smoothing_function = SmoothingFunction().method0
    p_n = smoothing_function(p_n, references=references, hypothesis=hypothesis, hyp_len=hyp_len)
    s = (w_i * math.log(p_i) for w_i, p_i in zip(weights, p_n))
    return bp * math.exp(math.fsum(s))


def bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):
    return sentence_bleu(references, hypothesis, weights, smoothing_function)
