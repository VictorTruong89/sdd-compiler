import pytest
from lingora import data
from lingora.tokenize import wordpunct_tokenize, TreebankWordTokenizer, RegexpTokenizer, blankline_tokenize
from lingora.stem import PorterStemmer, LancasterStemmer, SnowballStemmer
from lingora.metrics import edit_distance, precision, accuracy
from lingora.tree import Tree
from lingora.grammar import CFG
from lingora.parse import ChartParser


def test_wordpunct():  # spec: N-000085
    assert wordpunct_tokenize("Hi, you_1!") == ["Hi", ",", "you_1", "!"]


def test_treebank():  # spec: N-000088
    assert TreebankWordTokenizer().tokenize("I can't go.") == ["I", "ca", "n't", "go", "."]


def test_regexp_gaps():  # spec: N-000110
    assert RegexpTokenizer(",", gaps=True).tokenize(",a,,b,") == ["a", "b"]


def test_blankline():  # spec: N-000107
    assert blankline_tokenize("a\nb\n\nc") == ["a\nb", "c"]


def test_porter_lancaster_snowball():  # spec: N-000145
    assert PorterStemmer().stem("ponies") == "poni"
    assert LancasterStemmer().stem("maximum") == "maxim"
    assert SnowballStemmer("english").stem("generously") == "generous"


def test_edit_distance():  # spec: N-000295
    assert edit_distance("ca", "abc", transpositions=True) == 2
    assert edit_distance("", "") == 0


def test_metrics_errors():  # spec: N-000311
    with pytest.raises(TypeError):
        precision([1], {1})
    assert precision({1}, set()) is None
    with pytest.raises(ValueError):
        accuracy([1], [1, 2])


def test_tree_and_parse():  # spec: N-000262
    with pytest.raises(TypeError):
        Tree("S", "abc")
    g = CFG.fromstring("S -> 'a' S | 'a'")
    assert len(list(ChartParser(g).parse(["a", "a"]))) == 1
    with pytest.raises(ValueError):
        ChartParser(g).parse(["b"])


def test_punkt_missing():  # spec: N-000130
    from lingora.tokenize import sent_tokenize
    old = list(data.path)
    data.path[:] = []
    try:
        with pytest.raises(Exception):
            sent_tokenize("Hello.")
    finally:
        data.path[:] = old
