"""Packaged-resource finder for LINGORA.

``path`` is a mutable list of directories searched, in order, for packaged
resources. Callers may replace its contents in place. Importing this module
downloads nothing.
"""

import os

__all__ = ["path", "find", "exists", "ResourceNotFound"]


class ResourceNotFound(LookupError):
    """Raised when a packaged resource is not visible on ``path``."""


def _initial_path():
    entries = []
    env = os.environ.get("LINGORA_DATA", "")
    for part in env.split(os.pathsep):
        if part:
            entries.append(part)
    entries.append(os.path.join(os.path.expanduser("~"), "lingora_data"))
    return entries


#: Directories searched for packaged resources. Mutable; callers may edit it.
path = _initial_path()


def find(relpath, directory=False):
    """Return the absolute path of a packaged resource.

    ``relpath`` is relative to a directory on ``path`` (for example
    ``"tokenizers/punkt_tab/english"``). When ``directory`` is true only a
    directory match counts; otherwise any existing entry counts.
    Raises :class:`ResourceNotFound` when no listed directory holds it.
    """
    for base in list(path):
        candidate = os.path.join(base, *relpath.split("/"))
        if directory:
            if os.path.isdir(candidate):
                return candidate
        elif os.path.exists(candidate):
            return candidate
    raise ResourceNotFound(
        "packaged resource %r not found in data.path %r" % (relpath, list(path))
    )


def exists(relpath, directory=False):
    """Return True when :func:`find` would succeed."""
    try:
        find(relpath, directory=directory)
    except ResourceNotFound:
        return False
    return True
