"""Chunk parsing with chunk grammars (FP-04)."""

import re

from lingora import data
from lingora.tree import Tree

__all__ = ["RegexpParser", "ne_chunk"]

ROOT_LABEL = "S"


class _Chunk:
    """A chunk under construction. ``clause`` is the index of the clause that built it."""

    __slots__ = ("label", "children", "clause")

    def __init__(self, label, children, clause):
        self.label = label
        self.children = children
        self.clause = clause


class _Rule:
    __slots__ = ("kind", "elements")

    def __init__(self, kind, elements):
        self.kind = kind  # "chunk" or "chink"
        self.elements = elements  # list of (compiled regex, min, max or None)


_QUANT_RE = re.compile(r"\{(\d*)(,?)(\d*)\}")


def _parse_tag_pattern(text):
    elements = []
    i = 0
    n = len(text)
    while i < n:
        ch = text[i]
        if ch.isspace():
            i += 1
            continue
        if ch != "<":
            raise ValueError("expected '<' in tag pattern %r at position %d" % (text, i))
        end = text.find(">", i + 1)
        if end < 0:
            raise ValueError("unterminated '<' in tag pattern %r" % (text,))
        body = text[i + 1:end]
        try:
            regex = re.compile(body)
        except re.error as exc:
            raise ValueError("bad tag regular expression %r: %s" % (body, exc)) from None
        i = end + 1
        lo, hi = 1, 1
        if i < n and text[i] in "?*+":
            q = text[i]
            lo, hi = {"?": (0, 1), "*": (0, None), "+": (1, None)}[q]
            i += 1
        elif i < n and text[i] == "{":
            m = _QUANT_RE.match(text, i)
            if not m:
                raise ValueError("bad quantifier in tag pattern %r" % (text,))
            lo_s, comma, hi_s = m.groups()
            lo = int(lo_s) if lo_s else 0
            if comma:
                hi = int(hi_s) if hi_s else None
            else:
                hi = lo
            i = m.end()
        elements.append((regex, lo, hi))
    if not elements:
        raise ValueError("empty tag pattern")
    return elements


def _find_close(text, start, close):
    """Index of the ``close`` delimiter that ends a rule body starting at ``start``.

    Skips ``<...>`` elements and quantifier braces (a ``{`` right after an element
    or quantifier), so ``{<NN>{2}}`` closes at its last brace.
    """
    i = start
    prev = ""
    while i < len(text):
        c = text[i]
        if c == "<":
            j = text.find(">", i + 1)
            if j < 0:
                return -1
            i = j + 1
            prev = ">"
            continue
        if c == "{" and prev in (">", "?", "*", "+", "}"):
            m = _QUANT_RE.match(text, i)
            if m:
                i = m.end()
                prev = "}"
                continue
        if c == close:
            return i
        if not c.isspace():
            prev = c
        i += 1
    return -1


def _parse_pattern_line(text):
    """Parse one pattern line into rules: ``{...}`` chunk rules and ``}...{`` chink rules."""
    rules = []
    i = 0
    n = len(text)
    while i < n:
        ch = text[i]
        if ch.isspace():
            i += 1
            continue
        if ch == "{":
            end = _find_close(text, i + 1, "}")
            if end < 0:
                raise ValueError("unterminated '{' in chunk pattern %r" % (text,))
            rules.append(_Rule("chunk", _parse_tag_pattern(text[i + 1:end])))
            i = end + 1
        elif ch == "}":
            end = _find_close(text, i + 1, "{")
            if end < 0:
                raise ValueError("unterminated '}' in chink pattern %r" % (text,))
            rules.append(_Rule("chink", _parse_tag_pattern(text[i + 1:end])))
            i = end + 1
        else:
            raise ValueError("unexpected text %r in chunk pattern" % (text[i:],))
    return rules


def _parse_grammar(grammar):
    clauses = []  # list of (label, [rules])
    for lineno, raw in enumerate(grammar.splitlines(), 1):
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        indented = raw[0] in " \t"
        if not indented:
            if ":" not in raw:
                raise ValueError("grammar line %d: expected '<LABEL>: <pattern>'" % lineno)
            label, rest = raw.split(":", 1)
            label = label.strip()
            if not label:
                raise ValueError("grammar line %d: empty chunk label" % lineno)
            clauses.append((label, []))
            pattern = rest.strip()
        else:
            if not clauses:
                raise ValueError("grammar line %d: pattern before any clause label" % lineno)
            pattern = raw.strip()
        if pattern:
            clauses[-1][1].extend(_parse_pattern_line(pattern))
    return clauses


def _ends(elements, tags, start):
    """Return the set of end positions of matches of ``elements`` starting at ``start``."""
    current = {start}
    for regex, lo, hi in elements:
        nxt = set()
        for p in current:
            k = 0
            q = p
            if lo == 0:
                nxt.add(q)
            while (hi is None or k < hi) and q < len(tags) and regex.fullmatch(tags[q]):
                q += 1
                k += 1
                if k >= lo:
                    nxt.add(q)
        current = nxt
        if not current:
            break
    return current


def _unit_tag(unit):
    if isinstance(unit, _Chunk):
        return unit.label
    tag = unit[1]
    return tag if tag is not None else ""


def _apply_chunk(root, rule, label, clause):
    def eligible(unit):
        return not (isinstance(unit, _Chunk) and unit.clause == clause)

    result = []
    i = 0
    n = len(root)
    while i < n:
        if not eligible(root[i]):
            result.append(root[i])
            i += 1
            continue
        j = i
        while j < n and eligible(root[j]):
            j += 1
        run = root[i:j]
        tags = [_unit_tag(u) for u in run]
        k = 0
        while k < len(run):
            ends = [e for e in _ends(rule.elements, tags, k) if e > k]
            if not ends:
                result.append(run[k])
                k += 1
            else:
                e = max(ends)
                result.append(_Chunk(label, run[k:e], clause))
                k = e
        i = j
    root[:] = result


def _apply_chink(root, rule, label, clause):
    result = []
    for unit in root:
        if not (isinstance(unit, _Chunk) and unit.clause == clause):
            result.append(unit)
            continue
        children = unit.children
        tags = [_unit_tag(c) for c in children]
        removed = [False] * len(children)
        k = 0
        while k < len(children):
            ends = [e for e in _ends(rule.elements, tags, k) if e > k]
            if ends:
                e = max(ends)
                for x in range(k, e):
                    removed[x] = True
                k = e
            else:
                k += 1
        piece = []
        for idx, child in enumerate(children):
            if removed[idx]:
                if piece:
                    result.append(_Chunk(unit.label, piece, clause))
                    piece = []
                result.append(child)
            else:
                piece.append(child)
        if piece:
            result.append(_Chunk(unit.label, piece, clause))
    root[:] = result


def _to_tree(unit):
    if isinstance(unit, _Chunk):
        return Tree(unit.label, [_to_tree(c) for c in unit.children])
    return unit


class RegexpParser:
    """Chunk parser driven by a chunk grammar (see the Interface Contract)."""

    def __init__(self, grammar):
        if not isinstance(grammar, str):
            raise TypeError("grammar must be a str")
        self._clauses = _parse_grammar(grammar)

    def parse(self, tagged):
        if isinstance(tagged, (str, bytes)):
            raise TypeError("parse expects a list of (token, tag) pairs")
        root = []
        for pair in tagged:
            if not (isinstance(pair, (tuple, list)) and len(pair) == 2):
                raise TypeError("parse expects a list of (token, tag) pairs")
            root.append((pair[0], pair[1]))
        for clause_index, (label, rules) in enumerate(self._clauses):
            for rule in rules:
                if rule.kind == "chunk":
                    _apply_chunk(root, rule, label, clause_index)
                else:
                    _apply_chink(root, rule, label, clause_index)
        return Tree(ROOT_LABEL, [_to_tree(u) for u in root])


def ne_chunk(tagged_tokens):
    """Named-entity chunker. Requires the packaged NE model and the English wordlist.

    Raises ``LookupError`` when either resource is not visible. Applying the
    packaged model is not implemented in this build, so with both resources
    present the call raises ``NotImplementedError``.
    """
    if isinstance(tagged_tokens, (str, bytes)):
        raise TypeError("ne_chunk expects a list of (token, tag) pairs")
    if not data.exists("chunkers/maxent_ne_chunker_tab/english_ace_multiclass", directory=True):
        raise LookupError("named-entity chunker model is not installed")
    if not data.exists("corpora/words"):
        raise LookupError("English wordlist corpora/words is not installed")
    raise NotImplementedError("the packaged named-entity model format is not implemented in this build")
