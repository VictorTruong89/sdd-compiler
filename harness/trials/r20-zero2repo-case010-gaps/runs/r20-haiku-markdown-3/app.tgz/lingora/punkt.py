"""Punkt sentence-boundary tokenizer (Kiss and Strunk, 2006).

The packaged Punkt model for a language is a directory
``tokenizers/punkt_tab/<language>/`` holding ``abbrev_types.txt``,
``sent_starters.txt``, ``collocations.tab`` and ``ortho_context.tab``.
Sentence boundaries are decided per candidate period from the abbreviation,
collocation, sentence-starter and orthographic-context parameters.
"""

import os
import re
import threading

from lingora import data

__all__ = ["PunktModelNotFound", "load_params", "sent_tokenize", "PunktParameters"]

# Orthographic context bits (see the Interface Contract).
_ORTHO_BEG_UC = 2
_ORTHO_MID_UC = 4
_ORTHO_UNK_UC = 8
_ORTHO_BEG_LC = 16
_ORTHO_MID_LC = 32
_ORTHO_UNK_LC = 64
_ORTHO_UC = _ORTHO_BEG_UC | _ORTHO_MID_UC | _ORTHO_UNK_UC
_ORTHO_LC = _ORTHO_BEG_LC | _ORTHO_MID_LC | _ORTHO_UNK_LC

_NUMBER_RE = re.compile(r"-?[.,]?\d[\d,.\-]*")
_OPEN_CHARS = "\"'([{<`“‘„‚"
_CLOSE_CHARS = "\"')]}>`”’»"
_TOKEN_RE = re.compile(r"\S+")

_lock = threading.Lock()
_cache = {}


class PunktModelNotFound(LookupError):
    """Raised when the Punkt model for the requested language is not visible."""


class PunktParameters:
    """Parameters of one Punkt model."""

    def __init__(self, abbrev_types, sent_starters, collocations, ortho_context):
        self.abbrev_types = abbrev_types
        self.sent_starters = sent_starters
        self.collocations = collocations
        self.ortho_context = ortho_context


def _read_lines(filepath):
    if not os.path.isfile(filepath):
        return []
    lines = []
    with open(filepath, encoding="utf-8") as fh:
        for line in fh:
            line = line.rstrip("\r\n")
            if line:
                lines.append(line)
    return lines


def load_params(language="english"):
    """Load the packaged Punkt parameters for ``language``.

    Raises :class:`PunktModelNotFound` when the model directory is not visible
    on ``data.path``.
    """
    if not isinstance(language, str) or not language or "/" in language or "\\" in language:
        raise PunktModelNotFound("invalid Punkt language name %r" % (language,))
    rel = "tokenizers/punkt_tab/" + language
    try:
        base = data.find(rel, directory=True)
    except data.ResourceNotFound:
        raise PunktModelNotFound(
            "Punkt model for %r is not installed (looked for %s on data.path)" % (language, rel)
        ) from None
    with _lock:
        cached = _cache.get(base)
        if cached is not None:
            return cached
        abbrev = set(t.lower() for t in _read_lines(os.path.join(base, "abbrev_types.txt")))
        starters = set(t.lower() for t in _read_lines(os.path.join(base, "sent_starters.txt")))
        colloc = set()
        for line in _read_lines(os.path.join(base, "collocations.tab")):
            parts = line.split("\t")
            if len(parts) == 2:
                colloc.add((parts[0], parts[1]))
        ortho = {}
        for line in _read_lines(os.path.join(base, "ortho_context.tab")):
            parts = line.split("\t")
            if len(parts) == 2:
                try:
                    ortho[parts[0]] = ortho.get(parts[0], 0) | int(parts[1])
                except ValueError:
                    continue
        params = PunktParameters(abbrev, starters, colloc, ortho)
        _cache[base] = params
        return params


class _Tok:
    __slots__ = ("start", "end", "core", "period_final", "sent_end", "typ",
                 "abbr", "initial", "number", "ellipsis", "first_upper", "first_lower")


def _strip_open(text):
    i = 0
    while i < len(text) and text[i] in _OPEN_CHARS:
        i += 1
    return text[i:]


def _describe(start, end, raw, params):
    tok = _Tok()
    tok.start, tok.end = start, end
    core = raw
    while core and core[-1] in _CLOSE_CHARS:
        core = core[:-1]
    tok.core = core
    body = _strip_open(core)
    tok.first_upper = bool(body) and body[0].isupper()
    tok.first_lower = bool(body) and body[0].islower()
    tok.period_final = core.endswith(".")
    tok.sent_end = core.endswith("?") or core.endswith("!")
    tok.ellipsis = core.endswith("...")
    tok.typ = ""
    tok.abbr = False
    tok.initial = False
    tok.number = False
    if tok.period_final:
        word = _strip_open(core).rstrip(".")
        tok.typ = word.lower()
        tok.initial = len(word) == 1 and word.isalpha()
        if _NUMBER_RE.fullmatch(word):
            tok.number = True
            tok.typ = "##number##"
        tok.abbr = tok.typ in params.abbrev_types or tok.initial
    else:
        tok.typ = _strip_open(core).rstrip(".").lower()
    return tok


def _ortho_heuristic(tok, params):
    """True: likely a sentence starter. False: not one. None: no evidence."""
    ortho = params.ortho_context.get(tok.typ, 0)
    if tok.first_upper and (ortho & _ORTHO_LC) and not (ortho & _ORTHO_MID_UC):
        return False
    if tok.first_lower and ((ortho & _ORTHO_UC) or not (ortho & _ORTHO_BEG_LC)):
        return True
    return None


def _is_boundary(t1, t2, params):
    """Decide whether the period-final token ``t1`` ends a sentence before ``t2``."""
    if t2 is None:
        return True
    if (t1.typ, t2.typ) in params.collocations:
        return False
    h = _ortho_heuristic(t2, params)
    if t1.initial or t1.abbr or t1.ellipsis or t1.number:
        if h is True:
            return True
        return t2.first_upper and t2.typ in params.sent_starters
    # Ordinary period: a sentence boundary by default; a lowercase next word
    # is a continuation unless the heuristic says it is a sentence starter.
    if t2.first_lower and h is not True:
        return False
    return True


def sent_tokenize(text, language="english"):
    """Split ``text`` into sentences with the packaged Punkt model for ``language``.

    Each sentence is its original text, without the whitespace separating it
    from the next sentence. Raises :class:`PunktModelNotFound` when the model is
    missing.
    """
    if not isinstance(text, str):
        raise TypeError("sent_tokenize expects a str")
    params = load_params(language)
    matches = list(_TOKEN_RE.finditer(text))
    if not matches:
        return []
    toks = [_describe(m.start(), m.end(), m.group(), params) for m in matches]
    sentences = []
    group_start = toks[0].start
    for k, tok in enumerate(toks):
        last = k == len(toks) - 1
        if last:
            boundary = True
        elif tok.sent_end:
            boundary = True
        elif tok.period_final:
            boundary = _is_boundary(tok, toks[k + 1], params)
        else:
            boundary = False
        if boundary or last:
            sentences.append(text[group_start:tok.end])
            if not last:
                group_start = toks[k + 1].start
    return sentences
