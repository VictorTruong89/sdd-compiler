"""Command line for LINGORA.

``cli`` is a command group with the shape of a click group: ``cli.main(args=[...],
standalone_mode=True)``. It is self-contained (no third-party dependency).
"""

import sys

from lingora.punkt import PunktModelNotFound, load_params
from lingora.tokenize import word_tokenize

__all__ = ["cli", "main_entry"]


class UsageError(Exception):
    pass


class _Command:
    def __init__(self, name, callback, help_text):
        self.name = name
        self.callback = callback
        self.help = help_text


class Group:
    """A minimal command group."""

    def __init__(self, name="lingora"):
        self.name = name
        self.commands = {}

    def command(self, name=None, help=None):
        def register(func):
            cmd_name = name or func.__name__.replace("_", "-")
            self.commands[cmd_name] = _Command(cmd_name, func, help or (func.__doc__ or "").strip())
            return func
        return register

    def _help_text(self):
        lines = ["Usage: %s COMMAND [ARGS]..." % self.name, "", "Commands:"]
        for name in sorted(self.commands):
            lines.append("  %-12s %s" % (name, self.commands[name].help))
        return "\n".join(lines) + "\n"

    def main(self, args=None, standalone_mode=True, prog_name=None):
        argv = list(sys.argv[1:] if args is None else args)
        try:
            code = self._run(argv)
        except UsageError as exc:
            sys.stderr.write("Error: %s\n" % exc)
            code = 2
        if standalone_mode:
            sys.exit(code)
        return code

    def _run(self, argv):
        if not argv or argv[0] in ("-h", "--help"):
            sys.stdout.write(self._help_text())
            return 0
        name = argv[0]
        if name not in self.commands:
            raise UsageError("no such command %r" % name)
        cmd = self.commands[name]
        options = {}
        rest = argv[1:]
        i = 0
        while i < len(rest):
            arg = rest[i]
            if arg in ("-h", "--help"):
                sys.stdout.write("Usage: %s %s [OPTIONS]\n\n%s\n" % (self.name, name, cmd.help))
                return 0
            if arg.startswith("--") and "=" in arg:
                key, value = arg[2:].split("=", 1)
            elif arg.startswith("--"):
                key = arg[2:]
                if i + 1 >= len(rest):
                    raise UsageError("option --%s needs a value" % key)
                i += 1
                value = rest[i]
            else:
                raise UsageError("unexpected argument %r" % arg)
            options[key.replace("-", "_")] = value
            i += 1
        return cmd.callback(**options) or 0


cli = Group("lingora")


def _input_lines(encoding):
    """Yield decoded input lines (without line terminators) from standard input."""
    buffer = getattr(sys.stdin, "buffer", None)
    if buffer is not None:
        for raw in buffer:
            yield raw.decode(encoding).rstrip("\r\n")
    else:
        for raw in sys.stdin:
            yield raw.rstrip("\r\n")


@cli.command("tokenize")
def tokenize(language="english", delimiter=" ", encoding="utf-8"):
    """Tokenize each input line with the recommended word tokenizer (sentence-split first)."""
    try:
        load_params(language)
    except PunktModelNotFound as exc:
        sys.stderr.write("error: %s\n" % exc)
        return 1
    out = sys.stdout
    for line in _input_lines(encoding):
        try:
            tokens = word_tokenize(line, language=language, preserve_line=False)
        except PunktModelNotFound as exc:
            sys.stderr.write("error: %s\n" % exc)
            return 1
        out.write(delimiter.join(tokens) + "\n")
        out.flush()
    return 0


def main_entry():
    cli.main()


if __name__ == "__main__":
    main_entry()
