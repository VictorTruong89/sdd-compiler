"""Word, punctuation and sentence tokenizers (FP-01)."""

import re

from lingora.punkt import sent_tokenize as _punkt_sent_tokenize

__all__ = [
    "TokenizerI",
    "WordPunctTokenizer",
    "TreebankWordTokenizer",
    "WhitespaceTokenizer",
    "RegexpTokenizer",
    "TweetTokenizer",
    "wordpunct_tokenize",
    "word_tokenize",
    "sent_tokenize",
    "blankline_tokenize",
]


class TokenizerI:
    """Base class: subclasses implement ``tokenize``; span tokenizers add ``span_tokenize``."""

    def tokenize(self, text):
        raise NotImplementedError

    def span_tokenize(self, text):
        raise NotImplementedError("this tokenizer does not report spans")

    def tokenize_sents(self, strings):
        return [self.tokenize(s) for s in strings]


def _check_str(text, name="text"):
    if not isinstance(text, str):
        raise TypeError("%s must be a str, not %s" % (name, type(text).__name__))


def _spans_from_tokens(text, tokens):
    """Align tokens to ``text`` in order, returning (start, end) pairs."""
    spans = []
    pos = 0
    for tok in tokens:
        probe = tok
        if tok in ("``", "''"):
            probe = '"'
        idx = text.find(probe, pos)
        if idx < 0:
            idx = pos
        end = idx + len(probe)
        spans.append((idx, end))
        pos = end
    return spans


# ---------------------------------------------------------------------------
# Word/punctuation tokenizer
# ---------------------------------------------------------------------------

_WORDPUNCT_RE = re.compile(r"\w+|[^\w\s]+")


def wordpunct_tokenize(text):
    """Split ``text`` into maximal word runs and maximal punctuation runs."""
    _check_str(text)
    return _WORDPUNCT_RE.findall(text)


class WordPunctTokenizer(TokenizerI):
    def tokenize(self, text):
        return wordpunct_tokenize(text)

    def span_tokenize(self, text):
        _check_str(text)
        for m in _WORDPUNCT_RE.finditer(text):
            yield (m.start(), m.end())


# ---------------------------------------------------------------------------
# Penn Treebank word tokenizer and LINGORA's recommended word tokenizer
# ---------------------------------------------------------------------------

_OPEN_CONTEXT_QUOTE = re.compile(r'(?<=[\s(\[{<])"')
_ELLIPSIS_RE = re.compile(r"\.\.\.")
_POINTS_RE = re.compile(r"\.{2,}")
_PUNCT_RE = re.compile(r"[;@#$%&?!]")
_BRACKET_RE = re.compile(r"[\[\](){}<>]")
_COMMA_COLON_RE = re.compile(r"([,:])(?!\d)")
_FINAL_PERIOD_RE = re.compile(r"([^.])(\.)([\]\)}>\"']*)\s*$")
_TYPO_QUOTE_RE = re.compile("[‘-‟]")
_DASH_STAR_RE = re.compile("[‒-―*]")
_DOUBLE_HYPHEN_RE = re.compile(r"--")

_FUSED = [
    (re.compile(r"(?i)\b(can)(not)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(d)('ye)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(gim)(me)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(gon)(na)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(got)(ta)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(lem)(me)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(more)('n)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(wan)(na)\b"), r"\1 \2"),
    (re.compile(r"(?i)(?<=\s)('t)(is)\b"), r"\1 \2"),
    (re.compile(r"(?i)(?<=\s)('t)(was)\b"), r"\1 \2"),
]

_CLITIC_RE = re.compile(r"([^\s'])('[sSmMdD]|'(?:ll|LL|re|RE|ve|VE)|[nN]'[tT])(?=\s)")
_BARE_APOS_RE = re.compile(r"([^\s'])(')(?=\s)")


def _treebank_tokenize(text, improved):
    """Shared implementation of the Penn Treebank conventions.

    ``improved`` adds the recommended-tokenizer rules: typographic quotes,
    dashes U+2012..U+2015, asterisks, runs of two or more points, and the
    double hyphen.
    """
    s = " " + text + " "
    # The final period is split first, so it is seen before closing quotes are rewritten.
    s = _FINAL_PERIOD_RE.sub(lambda m: m.group(1) + " " + m.group(2) + m.group(3) + " ", s)
    # Opening quotes after start, whitespace or an opening bracket; closing elsewhere.
    s = _OPEN_CONTEXT_QUOTE.sub(" `` ", s)
    s = s.replace('"', " '' ")
    if improved:
        s = _POINTS_RE.sub(lambda m: " " + m.group(0) + " ", s)
        s = _TYPO_QUOTE_RE.sub(lambda m: " " + m.group(0) + " ", s)
        s = _DASH_STAR_RE.sub(lambda m: " " + m.group(0) + " ", s)
        s = _DOUBLE_HYPHEN_RE.sub(" -- ", s)
    else:
        s = _ELLIPSIS_RE.sub(" ... ", s)
    s = _PUNCT_RE.sub(lambda m: " " + m.group(0) + " ", s)
    s = _BRACKET_RE.sub(lambda m: " " + m.group(0) + " ", s)
    s = _COMMA_COLON_RE.sub(lambda m: " " + m.group(1) + " ", s)
    for pattern, repl in _FUSED:
        s = pattern.sub(repl, s)
    s = _CLITIC_RE.sub(lambda m: m.group(1) + " " + m.group(2) + " ", s)
    s = _BARE_APOS_RE.sub(lambda m: m.group(1) + " " + m.group(2) + " ", s)
    return s.split()


class TreebankWordTokenizer(TokenizerI):
    """Penn Treebank word tokenizer (FP-01)."""

    def tokenize(self, text):
        _check_str(text)
        return _treebank_tokenize(text, improved=False)

    def span_tokenize(self, text):
        _check_str(text)
        return _spans_from_tokens(text, self.tokenize(text))


def _sentence_split_tokens(text, language):
    sentences = _punkt_sent_tokenize(text, language)
    tokens = []
    for sent in sentences:
        tokens.extend(_treebank_tokenize(sent, improved=True))
    return tokens


def word_tokenize(text, language="english", preserve_line=False):
    """LINGORA's recommended word tokenizer.

    With ``preserve_line=False`` the text is first split into sentences with
    the Punkt model for ``language``; with ``preserve_line=True`` it is one
    already-delimited line and no model is needed.
    """
    _check_str(text)
    if preserve_line:
        return _treebank_tokenize(text, improved=True)
    return _sentence_split_tokens(text, language)


def sent_tokenize(text, language="english"):
    """Recommended sentence tokenizer (Punkt). Requires the model for ``language``."""
    _check_str(text)
    return _punkt_sent_tokenize(text, language)


# ---------------------------------------------------------------------------
# Whitespace, blank-line and regular-expression tokenizers
# ---------------------------------------------------------------------------

_NONSPACE_RE = re.compile(r"\S+")


class WhitespaceTokenizer(TokenizerI):
    def tokenize(self, text):
        _check_str(text)
        return text.split()

    def span_tokenize(self, text):
        _check_str(text)
        for m in _NONSPACE_RE.finditer(text):
            yield (m.start(), m.end())


_BLANKLINE_SEP_RE = re.compile(r"\s*\n\s*\n\s*")


def blankline_tokenize(text):
    """Split ``text`` into segments separated by blank lines (non-empty pieces only)."""
    _check_str(text)
    return [piece for piece in _BLANKLINE_SEP_RE.split(text) if piece]


class RegexpTokenizer(TokenizerI):
    """Regular-expression tokenizer.

    ``gaps=False`` (default): tokens are the successive matches of ``pattern``.
    ``gaps=True``: the pattern matches separators; tokens are the pieces between.
    ``discard_empty`` (default True) drops empty tokens.
    """

    def __init__(self, pattern, gaps=False, discard_empty=True, flags=0):
        if not isinstance(pattern, str):
            raise TypeError("pattern must be a str")
        self._pattern = pattern
        self._regexp = re.compile(pattern, flags)
        self._gaps = bool(gaps)
        self._discard_empty = bool(discard_empty)

    def _pieces(self, text):
        if not self._gaps:
            return [(m.start(), m.end()) for m in self._regexp.finditer(text)]
        spans = []
        prev = 0
        for m in self._regexp.finditer(text):
            spans.append((prev, m.start()))
            prev = m.end()
        spans.append((prev, len(text)))
        return spans

    def tokenize(self, text):
        _check_str(text)
        out = []
        for start, end in self._pieces(text):
            tok = text[start:end]
            if self._discard_empty and tok == "":
                continue
            out.append(tok)
        return out

    def span_tokenize(self, text):
        _check_str(text)
        for start, end in self._pieces(text):
            if self._discard_empty and start == end:
                continue
            yield (start, end)


# ---------------------------------------------------------------------------
# Tweet tokenizer
# ---------------------------------------------------------------------------

_EMOTICON = r"""
(?:
  [<>]?
  [:;=8]
  [\-o\*\']?
  [\)\]\(\[dDpP/\:\}\{@\|\\]
|
  [\)\]\(\[dDpP/\:\}\{@\|\\]
  [\-o\*\']?
  [:;=8]
  [<>]?
|
  <3
|
  </?3
)"""

_TWEET_TOKEN_RE = re.compile(
    "(?:"
    + _EMOTICON
    + r")"
    + r"|(?:(?:https?://|www\.)\S+)"
    + r"|(?:\#\w+)"
    + r"|(?:@\w+)"
    + r"|(?:[+-]?\d+(?:[.,]\d+)+)"
    + r"|(?:\w+(?:'\w+)*)"
    + r"|(?:\.{2,})"
    + r"|(?:[^\w\s])",
    re.VERBOSE,
)
_EMOTICON_FULL_RE = re.compile(_EMOTICON, re.VERBOSE)
_HANDLE_RE = re.compile(r"(?<!\w)@[A-Za-z0-9_]{1,15}(?![A-Za-z0-9_])")
_REDUCE_RE = re.compile(r"(.)\1{2,}", re.DOTALL)


class TweetTokenizer(TokenizerI):
    """Tokenizer for short social-media text."""

    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self.preserve_case = bool(preserve_case)
        self.reduce_len = bool(reduce_len)
        self.strip_handles = bool(strip_handles)

    def tokenize(self, text):
        _check_str(text)
        if self.strip_handles:
            text = _HANDLE_RE.sub(" ", text)
        if self.reduce_len:
            text = _REDUCE_RE.sub(lambda m: m.group(1) * 3, text)
        tokens = _TWEET_TOKEN_RE.findall(text)
        if not self.preserve_case:
            tokens = [t if _EMOTICON_FULL_RE.fullmatch(t) else t.lower() for t in tokens]
        return tokens
