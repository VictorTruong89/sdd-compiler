"""Evaluation metrics (FP-07)."""

__all__ = [
    "accuracy",
    "edit_distance",
    "jaccard_distance",
    "precision",
    "recall",
    "f_measure",
]


def _require_sets(*args):
    for arg in args:
        if not isinstance(arg, (set, frozenset)):
            raise TypeError("precision, recall and f-measure require sets, not %s"
                            % type(arg).__name__)


def accuracy(reference, test):
    """Fraction of positions at which two equal-length lists hold equal values."""
    if isinstance(reference, (str, bytes)) or isinstance(test, (str, bytes)):
        raise TypeError("accuracy expects two lists")
    reference = list(reference)
    test = list(test)
    if len(reference) != len(test):
        raise ValueError("accuracy needs lists of equal length (%d != %d)"
                         % (len(reference), len(test)))
    if not reference:
        raise ValueError("accuracy needs at least one position")
    same = sum(1 for a, b in zip(reference, test) if a == b)
    return same / len(reference)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Levenshtein distance; with ``transpositions`` the unrestricted Damerau–Levenshtein
    distance (Lowrance and Wagner, 1975), where a transposition costs 1."""
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("edit_distance expects two strings")
    len1, len2 = len(s1), len(s2)
    if not transpositions:
        prev = [j for j in range(len2 + 1)]
        for i in range(1, len1 + 1):
            cur = [i] + [0] * len2
            for j in range(1, len2 + 1):
                cost = 0 if s1[i - 1] == s2[j - 1] else substitution_cost
                cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
            prev = cur
        return prev[len2]

    maxdist = len1 + len2
    d = [[0] * (len2 + 2) for _ in range(len1 + 2)]
    d[0][0] = maxdist
    for i in range(len1 + 1):
        d[i + 1][0] = maxdist
        d[i + 1][1] = i
    for j in range(len2 + 1):
        d[0][j + 1] = maxdist
        d[1][j + 1] = j
    last_row = {}
    for i in range(1, len1 + 1):
        last_col = 0
        for j in range(1, len2 + 1):
            i1 = last_row.get(s2[j - 1], 0)
            j1 = last_col
            if s1[i - 1] == s2[j - 1]:
                cost = 0
                last_col = j
            else:
                cost = substitution_cost
            d[i + 1][j + 1] = min(
                d[i][j] + cost,
                d[i + 1][j] + 1,
                d[i][j + 1] + 1,
                d[i1][j1] + (i - i1 - 1) + 1 + (j - j1 - 1),
            )
        last_row[s1[i - 1]] = i
    return d[len1 + 1][len2 + 1]


def jaccard_distance(label1, label2):
    """1 - |A ∩ B| / |A ∪ B| for two sets; 0.0 when both are empty."""
    _require_sets(label1, label2)
    union = len(label1 | label2)
    if union == 0:
        return 0.0
    inter = len(label1 & label2)
    return (union - inter) / union


def precision(reference, test):
    """|reference ∩ test| / |test|; ``None`` when ``test`` is empty."""
    _require_sets(reference, test)
    if not test:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    """|reference ∩ test| / |reference|; ``None`` when ``reference`` is empty."""
    _require_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    """Weighted harmonic mean of precision and recall; ``None`` if either set is empty."""
    _require_sets(reference, test)
    if not reference or not test:
        return None
    p = precision(reference, test)
    r = recall(reference, test)
    if p == 0 or r == 0:
        return 0.0
    if alpha == 1:
        return p
    if alpha == 0:
        return r
    return 1.0 / (alpha / p + (1.0 - alpha) / r)
