"""Stemmers (FP-02)."""

import re

from lingora import data

__all__ = [
    "PorterStemmer",
    "LancasterStemmer",
    "SnowballStemmer",
    "RegexpStemmer",
    "ARLSTem",
    "ARLSTem2",
    "WordNetLemmatizer",
    "SNOWBALL_LANGUAGES",
]

SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german",
    "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
    "russian", "spanish", "swedish",
)

_VOWELS = "aeiou"


# ===========================================================================
# Porter stemmer
# ===========================================================================

_PORTER_IRREGULAR = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli",
    "singly": "singl", "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas",
    "cosmos": "cosmos", "bias": "bias", "andes": "andes", "inning": "inning",
    "innings": "inning", "outing": "outing", "outings": "outing", "canning": "can",
    "cannings": "can", "herring": "herring", "herrings": "herring", "earring": "earring",
    "earrings": "earring", "proceed": "proceed", "exceed": "exceed", "succeed": "succeed",
}


def _porter_cons(word, i):
    ch = word[i]
    if ch in _VOWELS:
        return False
    if ch == "y":
        return i == 0 or not _porter_cons(word, i - 1)
    return True


def _porter_measure(stem):
    m = 0
    seen_vowel = False
    for i in range(len(stem)):
        if _porter_cons(stem, i):
            if seen_vowel:
                m += 1
                seen_vowel = False
        else:
            seen_vowel = True
    return m


def _porter_has_vowel(stem):
    return any(not _porter_cons(stem, i) for i in range(len(stem)))


def _porter_double_cons(word):
    return len(word) >= 2 and word[-1] == word[-2] and _porter_cons(word, len(word) - 1)


def _porter_cvc(stem, two_letter_rule):
    n = len(stem)
    if n >= 3:
        return (_porter_cons(stem, n - 3) and not _porter_cons(stem, n - 2)
                and _porter_cons(stem, n - 1) and stem[-1] not in "wxy")
    if n == 2 and two_letter_rule:
        return (not _porter_cons(stem, 0) and _porter_cons(stem, 1)
                and stem[1] not in "wxy")
    return False


_PORTER_STEP2_ORIGINAL = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("abli", "able"), ("alli", "al"), ("entli", "ent"), ("eli", "e"),
    ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"), ("ator", "ate"),
    ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"), ("ousness", "ous"),
    ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"),
]

_PORTER_STEP2_EXT = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("bli", "ble"), ("entli", "ent"), ("eli", "e"),
    ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"), ("ator", "ate"),
    ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"), ("ousness", "ous"),
    ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"), ("fulli", "ful"),
    ("alli", "al"),
]

_PORTER_STEP3 = [
    ("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"),
    ("ical", "ic"), ("ful", ""), ("ness", ""),
]

_PORTER_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment",
    "ent", "ion", "ou", "ism", "ate", "iti", "ous", "ive", "ize",
]


class PorterStemmer:
    """Porter stemmer.

    The default mode is LINGORA's extended Porter algorithm. ``ORIGINAL_ALGORITHM``
    is Porter's 1980 algorithm; ``MARTIN_EXTENSIONS`` adds the ``bli``, ``fulli`` and
    ``logi`` rules without LINGORA's other changes.
    """

    LINGORA_EXTENSIONS = "LINGORA_EXTENSIONS"
    MARTIN_EXTENSIONS = "MARTIN_EXTENSIONS"
    ORIGINAL_ALGORITHM = "ORIGINAL_ALGORITHM"

    _MODES = (LINGORA_EXTENSIONS, MARTIN_EXTENSIONS, ORIGINAL_ALGORITHM)

    def __init__(self, mode=LINGORA_EXTENSIONS):
        if mode not in self._MODES:
            raise ValueError("unknown Porter mode %r" % (mode,))
        self.mode = mode

    def stem(self, word, to_lowercase=True):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        if to_lowercase:
            word = word.lower()
        if self.mode == self.LINGORA_EXTENSIONS and word in _PORTER_IRREGULAR:
            return _PORTER_IRREGULAR[word]
        if len(word) <= 2:
            return word
        ext = self.mode == self.LINGORA_EXTENSIONS
        martin = self.mode != self.ORIGINAL_ALGORITHM
        w = self._step1a(word, ext)
        w = self._step1b(w, ext)
        w = self._step1c(w, ext)
        w = self._step2(w, ext, martin)
        w = self._step3(w)
        w = self._step4(w)
        w = self._step5(w, ext)
        return w

    @staticmethod
    def _step1a(w, ext):
        if w.endswith("sses"):
            return w[:-2]
        if w.endswith("ies"):
            if ext and len(w) == 4:
                return w[:-1]
            return w[:-2]
        if w.endswith("ss"):
            return w
        if w.endswith("s") and _porter_has_vowel(w[:-1]):
            return w[:-1]
        return w

    @staticmethod
    def _step1b(w, ext):
        if ext and w.endswith("ied"):
            return w[:-3] + ("ie" if len(w) == 4 else "i")
        if w.endswith("eed"):
            stem = w[:-3]
            if _porter_measure(stem) > 0:
                return stem + "ee"
            return w
        if w.endswith("ed") and _porter_has_vowel(w[:-2]):
            stem = w[:-2]
        elif w.endswith("ing") and _porter_has_vowel(w[:-3]):
            stem = w[:-3]
        else:
            return w
        if stem.endswith(("at", "bl", "iz")):
            return stem + "e"
        if _porter_double_cons(stem) and stem[-1] not in "lsz":
            return stem[:-1]
        if _porter_measure(stem) == 1 and _porter_cvc(stem, two_letter_rule=ext):
            return stem + "e"
        return stem

    @staticmethod
    def _step1c(w, ext):
        if not w.endswith("y"):
            return w
        stem = w[:-1]
        if ext:
            n = len(w)
            if n >= 3 and _porter_cons(w, n - 2):
                return stem + "i"
            return w
        if _porter_has_vowel(stem):
            return stem + "i"
        return w

    def _step2(self, w, ext, martin):
        if ext and w.endswith("alli") and _porter_measure(w[:-4]) > 0:
            return self._step2(w[:-4] + "al", ext, martin)
        table = _PORTER_STEP2_EXT if martin else _PORTER_STEP2_ORIGINAL
        for suffix, repl in sorted(table, key=lambda sr: -len(sr[0])):
            if w.endswith(suffix):
                stem = w[: -len(suffix)]
                if _porter_measure(stem) > 0:
                    return stem + repl
                return w
        if martin and w.endswith("logi") and _porter_measure(w[:-3]) > 0:
            return w[:-1]
        return w

    @staticmethod
    def _step3(w):
        for suffix, repl in _PORTER_STEP3:
            if w.endswith(suffix):
                stem = w[: -len(suffix)]
                if _porter_measure(stem) > 0:
                    return stem + repl
                return w
        return w

    @staticmethod
    def _step4(w):
        for suffix in _PORTER_STEP4:
            if w.endswith(suffix):
                stem = w[: -len(suffix)]
                if suffix == "ion":
                    if _porter_measure(stem) > 1 and stem[-1:] in ("s", "t"):
                        return stem
                    return w
                if _porter_measure(stem) > 1:
                    return stem
                return w
        return w

    @staticmethod
    def _step5(w, ext):
        if w.endswith("e"):
            stem = w[:-1]
            m = _porter_measure(stem)
            if m > 1 or (m == 1 and not _porter_cvc(stem, two_letter_rule=ext)):
                w = stem
        if _porter_measure(w) > 1 and _porter_double_cons(w) and w.endswith("l"):
            w = w[:-1]
        return w


# ===========================================================================
# Lancaster (Paice/Husk) stemmer
# ===========================================================================

_LANCASTER_RULES = [
    "ai*2.", "a*1.", "bb1.", "city3s.", "cn1t>", "dd1.", "dei3y>",
    "deec2ss.", "dee1.", "de2>", "dooh4>", "e1>", "feil1v.", "fi2>", "gni3>",
    "gai3y.", "ga2>", "gg1.", "ht*2.", "hsiug5ct.", "hsi3>", "i*1.", "i1y>",
    "ji1d.", "juf1s.", "ju1d.", "jo1d.", "jeh1r.", "jrev1t.", "jsim2t.", "jn1d.",
    "j1s.", "lbaifi6.", "lbai4y.", "lba3.", "lbi3.", "lib2l>", "lc1.", "lufi4y.",
    "luf3y.", "lu2.", "lai3y.", "la2.", "ll1.", "mui3.", "mu*2.", "msi3>", "mm1.",
    "nois4j>", "noix4ct.", "noi3>", "nai3>", "na2>", "nee0.", "ne2>", "nn1.",
    "pihs4>", "pp1.", "re2>", "rae0.", "ra2.", "ro2>", "ru2>", "rr1.", "rt1>",
    "rei3y>", "sei3y>", "sis2.", "si2>", "ssen4>", "ss0.", "suo3>", "su*2.",
    "s*1>", "s0.", "tacilp4y.", "ct2s.", "ct2>", "tu2.", "tu*2.", "tnem4>",
    "tneg3>", "ey2>", "yli3y>", "ylb1>", "yl2>", "ygo1.", "yhp1.", "ymo1.",
    "ypo1.", "yti3>", "yte3>", "ytl2.", "vis3j>", "zi2>", "zy1s.",
]

_LANCASTER_RE = re.compile(r"^([a-z]+)(\*?)([0-9]?)([a-z]*)([.>])$")


def _parse_lancaster_rule(rule):
    m = _LANCASTER_RE.match(rule)
    if not m:
        raise ValueError("bad Lancaster rule %r" % (rule,))
    letters, star, digit, append, action = m.groups()
    return {
        "suffix": letters[::-1],
        "intact_only": star == "*",
        "remove": int(digit) if digit else 0,
        "append": append,
        "terminal": action == ".",
    }


_LANCASTER_PARSED = [_parse_lancaster_rule(r) for r in _LANCASTER_RULES]


def _lancaster_acceptable(word):
    if not word:
        return False
    if word[0] in "aeiou":
        return len(word) >= 2
    return len(word) >= 3 and any(c in "aeiouy" for c in word)


class LancasterStemmer:
    """Paice/Husk Lancaster stemmer with its rule table."""

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        word = word.lower()
        intact = True
        for _ in range(1000):  # safety bound; each applied rule must change the word
            applied = False
            for rule in _LANCASTER_PARSED:
                if rule["intact_only"] and not intact:
                    continue
                suffix = rule["suffix"]
                if not word.endswith(suffix) or rule["remove"] > len(word):
                    continue
                new = word[: len(word) - rule["remove"]] + rule["append"]
                if new == word or not _lancaster_acceptable(new):
                    continue
                word = new
                intact = False
                applied = True
                if rule["terminal"]:
                    return word
                break
            if not applied:
                return word
        return word


# ===========================================================================
# Snowball stemmers
# ===========================================================================

_P2_EXCEPTIONAL = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli",
    "singly": "singl", "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas",
    "cosmos": "cosmos", "bias": "bias", "andes": "andes",
}
_P2_EXCEPTIONAL_AFTER_1A = {
    "inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed",
}
_P2_VOWELS = "aeiouy"
_P2_STEP2 = [
    ("ization", "ize"), ("ational", "ate"), ("fulness", "ful"), ("ousness", "ous"),
    ("iveness", "ive"), ("tional", "tion"), ("biliti", "ble"), ("lessli", "less"),
    ("entli", "ent"), ("ation", "ate"), ("alism", "al"), ("aliti", "al"), ("ousli", "ous"),
    ("iviti", "ive"), ("fulli", "ful"), ("enci", "ence"), ("anci", "ance"),
    ("abli", "able"), ("izer", "ize"), ("ator", "ate"), ("alli", "al"), ("bli", "ble"),
    ("ogi", "og"), ("li", ""),
]
_P2_STEP3 = [
    ("ational", "ate"), ("tional", "tion"), ("alize", "al"), ("icate", "ic"),
    ("iciti", "ic"), ("ical", "ic"), ("ative", ""), ("ful", ""), ("ness", ""),
]
_P2_STEP4 = [
    "ement", "ance", "ence", "able", "ible", "ment", "ant", "ent", "ism", "ate",
    "iti", "ous", "ive", "ize", "ion", "al", "er", "ic",
]
_P2_DOUBLES = ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")
_P2_LI_ENDINGS = "cdeghkmnrt"


def _p2_regions(word):
    """Return (R1, R2) start indices of a Porter2 word."""

    def region(w, start_hint=0):
        for prefix in ("gener", "commun", "arsen"):
            if w.startswith(prefix):
                return len(prefix)
        for i in range(1, len(w)):
            if w[i] not in _P2_VOWELS and w[i - 1] in _P2_VOWELS:
                return i + 1
        return len(w)

    r1 = region(word)
    r2 = r1 + region(word[r1:])
    return r1, min(r2, len(word))


def _p2_short_syllable(w):
    if len(w) == 2:
        return w[0] in _P2_VOWELS and w[1] not in _P2_VOWELS
    if len(w) >= 3:
        return (w[-3] not in _P2_VOWELS and w[-2] in _P2_VOWELS
                and w[-1] not in _P2_VOWELS and w[-1] not in "wxY")
    return False


def _p2_has_vowel(w):
    return any(c in _P2_VOWELS for c in w)


def _snowball_english(word):
    """Porter2 (Snowball English) stemmer. The word must already be lowercased."""
    if len(word) <= 2:
        return word
    if word in _P2_EXCEPTIONAL:
        return _P2_EXCEPTIONAL[word]
    w = word[1:] if word.startswith("'") else word
    if not w:
        return w
    chars = list(w)
    if chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in _P2_VOWELS:
            chars[i] = "Y"
    w = "".join(chars)
    r1, r2 = _p2_regions(w)

    # Step 0
    for suffix in ("'s'", "'s", "'"):
        if w.endswith(suffix):
            w = w[: -len(suffix)]
            break

    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith("ied") or w.endswith("ies"):
        w = w[:-2] if len(w) > 4 else w[:-1]
    elif w.endswith("us") or w.endswith("ss"):
        pass
    elif w.endswith("s"):
        if _p2_has_vowel(w[:-2]):
            w = w[:-1]

    if w in _P2_EXCEPTIONAL_AFTER_1A:
        return w.replace("Y", "y")

    # Step 1b
    if w.endswith("eedly") or w.endswith("eed"):
        suffix = "eedly" if w.endswith("eedly") else "eed"
        if len(w) - len(suffix) >= r1:
            w = w[: -len(suffix)] + "ee"
    else:
        for suffix in ("ingly", "edly", "ing", "ed"):
            if w.endswith(suffix):
                pre = w[: -len(suffix)]
                if _p2_has_vowel(pre):
                    w = pre
                    if w.endswith(("at", "bl", "iz")):
                        w += "e"
                    elif w[-2:] in _P2_DOUBLES:
                        w = w[:-1]
                    elif _p2_short_syllable(w) and r1 >= len(w):
                        w += "e"
                break

    # Step 1c
    if len(w) > 2 and w[-1] in "yY" and w[-2] not in _P2_VOWELS:
        w = w[:-1] + "i"

    # Recompute regions after Step 1 changes would differ from Snowball's
    # fixed regions only in the rare case where step 0/1 shrink the word
    # below R1; the regions were fixed from the word before step 0.
    # Step 2
    for suffix, repl in _P2_STEP2:
        if w.endswith(suffix):
            if len(w) - len(suffix) >= r1:
                if suffix == "ogi":
                    if w[-4:-3] == "l":
                        w = w[: -len(suffix)] + repl
                elif suffix == "li":
                    if len(w) > 2 and w[-3] in _P2_LI_ENDINGS:
                        w = w[:-2]
                else:
                    w = w[: -len(suffix)] + repl
            break

    # Step 3
    for suffix, repl in _P2_STEP3:
        if w.endswith(suffix):
            base = len(w) - len(suffix)
            if suffix == "ative":
                if base >= r2:
                    w = w[:base] + repl
            elif base >= r1:
                w = w[:base] + repl
            break

    # Step 4
    for suffix in _P2_STEP4:
        if w.endswith(suffix):
            base = len(w) - len(suffix)
            if base >= r2:
                if suffix == "ion":
                    if w[base - 1:base] in ("s", "t") and base >= 1:
                        w = w[:base]
                else:
                    w = w[:base]
            break

    # Step 5
    if w.endswith("e"):
        base = len(w) - 1
        if base >= r2 or (base >= r1 and not _p2_short_syllable(w[:base])):
            w = w[:base]
    elif w.endswith("l"):
        base = len(w) - 1
        if base >= r2 and w[base - 1:base] == "l":
            w = w[:base]

    return w.replace("Y", "y")


def _snowball_porter(word):
    return PorterStemmer(PorterStemmer.ORIGINAL_ALGORITHM).stem(word, to_lowercase=False)


_IMPLEMENTED_LANGUAGES = {
    "english": _snowball_english,
    "porter": _snowball_porter,
}


def _stopwords_for(language):
    relpath = "corpora/stopwords/" + language
    try:
        filepath = data.find(relpath)
    except data.ResourceNotFound:
        raise LookupError(
            "stopwords list for %r is not installed (looked for %s on data.path)"
            % (language, relpath)
        ) from None
    words = set()
    with open(filepath, encoding="utf-8") as fh:
        for line in fh:
            line = line.rstrip("\r\n")
            if line:
                words.add(line)
    return words


class SnowballStemmer:
    """Snowball stemmer for the languages listed in the Interface Contract.

    Only the English (Porter2) and ``porter`` (original Porter) algorithms are
    implemented in this build; constructing a stemmer for any other listed
    language raises ``NotImplementedError``.
    """

    languages = SNOWBALL_LANGUAGES

    def __init__(self, language, ignore_stopwords=False):
        if not isinstance(language, str) or language not in SNOWBALL_LANGUAGES:
            raise ValueError("unsupported Snowball language %r" % (language,))
        if language not in _IMPLEMENTED_LANGUAGES:
            raise NotImplementedError(
                "Snowball algorithm for %r is not implemented in this build" % (language,)
            )
        self.language = language
        self.ignore_stopwords = bool(ignore_stopwords)
        self._stopwords = _stopwords_for(language) if self.ignore_stopwords else frozenset()
        self._algorithm = _IMPLEMENTED_LANGUAGES[language]

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        word = word.lower()
        if self.ignore_stopwords and word in self._stopwords:
            return word
        return self._algorithm(word)


# ===========================================================================
# Regular-expression stemmer
# ===========================================================================


class RegexpStemmer:
    """Removes every match of ``regexp`` from the word; nothing else changes."""

    def __init__(self, regexp, flags=0):
        if not isinstance(regexp, str):
            raise TypeError("regexp must be a str")
        self._regexp = re.compile(regexp, flags)

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        return self._regexp.sub("", word)


# ===========================================================================
# Families named by the spec whose stemming results are outside it
# ===========================================================================


class ARLSTem:
    """ARLSTem (Arabic). Present in the product; its algorithm is not implemented here."""

    def __init__(self, *args, **kwargs):
        pass

    def stem(self, word):
        raise NotImplementedError("ARLSTem is not implemented in this build")


class ARLSTem2(ARLSTem):
    """ARLSTem2 (Arabic). Present in the product; its algorithm is not implemented here."""


class WordNetLemmatizer:
    """WordNet lemmatizer. Requires the packaged WordNet resource."""

    def __init__(self):
        try:
            data.find("corpora/wordnet", directory=True)
        except data.ResourceNotFound:
            raise LookupError(
                "WordNet is not installed (looked for corpora/wordnet on data.path)"
            ) from None

    def lemmatize(self, word):
        raise NotImplementedError("WordNet lemmatization is not implemented in this build")
