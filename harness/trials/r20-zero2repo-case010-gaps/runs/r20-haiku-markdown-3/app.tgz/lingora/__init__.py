"""LINGORA: a Python natural-language processing library.

Importing the package downloads nothing and needs no packaged model.
"""

from lingora import data
from lingora import tree
from lingora import tokenize
from lingora import stem
from lingora import tag
from lingora import chunk
from lingora import grammar
from lingora import parse
from lingora import classify
from lingora import metrics
from lingora import translate

__version__ = "0.1.0"

__all__ = [
    "data", "tree", "tokenize", "stem", "tag", "chunk", "grammar", "parse",
    "classify", "metrics", "translate", "__version__",
]
