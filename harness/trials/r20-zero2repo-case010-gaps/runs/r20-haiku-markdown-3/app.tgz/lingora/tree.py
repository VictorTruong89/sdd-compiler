"""Constituent trees, built from a label and children or from bracketed text."""

import re

__all__ = ["Tree"]

_TOKEN_RE = re.compile(r"\(|\)|[^\s()]+")


class Tree:
    """A labelled node whose children are leaves or other trees.

    A leaf is any non-``Tree`` child: a token string, or a ``(token, tag)``
    pair in chunk structures.
    """

    __slots__ = ("_label", "_children")

    def __init__(self, label, children):
        if isinstance(children, (str, bytes)):
            raise TypeError("Tree children must be a list, not a string")
        if not isinstance(children, (list, tuple)):
            raise TypeError("Tree children must be a list of children")
        self._label = label
        self._children = list(children)

    # -- construction -------------------------------------------------------

    @classmethod
    def fromstring(cls, s):
        """Build a tree from bracketed tree text ``(label child ...)``."""
        if not isinstance(s, str):
            raise TypeError("Tree.fromstring expects a str")
        tokens = _TOKEN_RE.findall(s)
        if not tokens:
            raise ValueError("empty bracketed tree text")
        pos = [0]

        def parse_node():
            if tokens[pos[0]] != "(":
                raise ValueError("expected '(' in bracketed tree text")
            pos[0] += 1
            if pos[0] >= len(tokens) or tokens[pos[0]] in ("(", ")"):
                raise ValueError("node without a label in bracketed tree text")
            label = tokens[pos[0]]
            pos[0] += 1
            children = []
            while True:
                if pos[0] >= len(tokens):
                    raise ValueError("unbalanced parentheses in tree text")
                tok = tokens[pos[0]]
                if tok == ")":
                    pos[0] += 1
                    return cls(label, children)
                if tok == "(":
                    children.append(parse_node())
                else:
                    children.append(tok)
                    pos[0] += 1

        tree = parse_node()
        if pos[0] != len(tokens):
            raise ValueError("extra text after the tree in bracketed tree text")
        return tree

    # -- accessors ----------------------------------------------------------

    def label(self):
        return self._label

    def leaves(self):
        out = []
        for child in self._children:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def __iter__(self):
        return iter(self._children)

    def __len__(self):
        return len(self._children)

    def __getitem__(self, index):
        return self._children[index]

    # -- comparison and display --------------------------------------------

    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    __hash__ = None  # mutable container

    def __repr__(self):
        return "Tree(%r, %r)" % (self._label, self._children)

    def __str__(self):
        return self.pformat()

    def _flat(self):
        parts = []
        for child in self._children:
            if isinstance(child, Tree):
                parts.append(child._flat())
            else:
                parts.append(_leaf_text(child))
        return "(%s %s)" % (self._label, " ".join(parts)) if parts else "(%s)" % self._label

    def pformat(self, margin=70, indent=2):
        """Return the pretty-printed text; every label and leaf appears in pre-order."""
        return self._pformat(0, margin, indent)

    def _pformat(self, level, margin, indent):
        flat = self._flat()
        if level * indent + len(flat) <= margin or not self._children:
            return flat
        pad = " " * ((level + 1) * indent)
        lines = ["(%s" % self._label]
        for child in self._children:
            if isinstance(child, Tree):
                text = child._pformat(level + 1, margin, indent)
            else:
                text = _leaf_text(child)
            lines.append(pad + text)
        return "\n".join(lines) + ")"


def _leaf_text(leaf):
    if isinstance(leaf, tuple) and len(leaf) == 2:
        return "%s/%s" % (leaf[0], leaf[1])
    return str(leaf)
