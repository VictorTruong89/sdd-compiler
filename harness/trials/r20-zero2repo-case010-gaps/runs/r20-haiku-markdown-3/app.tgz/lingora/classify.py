"""Text classifiers (FP-06): Naive Bayes and decision tree."""

import math
from collections import Counter, defaultdict

__all__ = ["NaiveBayesClassifier", "DecisionTreeClassifier", "ProbDist", "accuracy"]


def _check_labeled(labeled_featuresets):
    pairs = []
    for item in labeled_featuresets:
        if not (isinstance(item, (tuple, list)) and len(item) == 2):
            raise TypeError("training data must be (featureset, label) pairs")
        fs, label = item
        if not isinstance(fs, dict):
            raise TypeError("a featureset must be a dict")
        pairs.append((fs, label))
    return pairs


class ProbDist:
    """A probability distribution over labels."""

    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def logprob(self, label):
        p = self.prob(label)
        return math.log(p) if p > 0 else float("-inf")

    def samples(self):
        return list(self._probs)

    def max(self):
        return max(self._probs, key=lambda lab: self._probs[lab])

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._probs)


class NaiveBayesClassifier:
    """Naive Bayes with Laplace-smoothed feature-value estimates.

    P(value | label) = (count(feature=value, label) + 1)
                       / (examples of label with the feature + distinct values of the feature + 1)
    so a value seen under one label never gets probability zero under another.
    Features absent from a featureset, and features never seen in training, are ignored.
    """

    def __init__(self, label_counts, feature_counts, feature_totals, feature_values, total):
        self._label_counts = label_counts          # label -> number of examples
        self._feature_counts = feature_counts      # feature -> label -> value -> count
        self._feature_totals = feature_totals      # feature -> label -> examples having it
        self._feature_values = feature_values      # feature -> set of values seen
        self._total = total
        self._labels = list(label_counts)

    @classmethod
    def train(cls, labeled_featuresets):
        pairs = _check_labeled(labeled_featuresets)
        label_counts = Counter()
        feature_counts = defaultdict(lambda: defaultdict(Counter))
        feature_totals = defaultdict(Counter)
        feature_values = defaultdict(set)
        for fs, label in pairs:
            label_counts[label] += 1
            for feat, value in fs.items():
                feature_counts[feat][label][value] += 1
                feature_totals[feat][label] += 1
                feature_values[feat].add(value)
        return cls(label_counts, feature_counts, feature_totals, feature_values, len(pairs))

    def labels(self):
        return list(self._labels)

    def _log_joint(self, featureset):
        scores = {}
        for label in self._labels:
            logp = math.log(self._label_counts[label] / self._total)
            for feat, value in featureset.items():
                if feat not in self._feature_values:
                    continue
                distinct = len(self._feature_values[feat]) + 1
                count = self._feature_counts[feat][label].get(value, 0)
                denom = self._feature_totals[feat].get(label, 0) + distinct
                logp += math.log((count + 1) / denom)
            scores[label] = logp
        return scores

    def classify(self, featureset):
        if not self._labels:
            raise ValueError("the classifier has not been trained on any labels")
        scores = self._log_joint(featureset)
        best = self._labels[0]
        for label in self._labels[1:]:
            if scores[label] > scores[best]:
                best = label
        return best

    def prob_classify(self, featureset):
        scores = self._log_joint(featureset)
        top = max(scores.values())
        weights = {lab: math.exp(s - top) for lab, s in scores.items()}
        norm = sum(weights.values())
        return ProbDist({lab: w / norm for lab, w in weights.items()})


def _entropy(counter, total):
    h = 0.0
    for c in counter.values():
        if c:
            p = c / total
            h -= p * math.log2(p)
    return h


class _Leaf:
    __slots__ = ("label",)

    def __init__(self, label):
        self.label = label


class _Node:
    __slots__ = ("feature", "branches", "default")

    def __init__(self, feature, branches, default):
        self.feature = feature
        self.branches = branches
        self.default = default


def _majority(labels_in_order, counts):
    best = None
    for label in labels_in_order:
        if best is None or counts[label] > counts[best]:
            best = label
    return best


def _build_tree(examples, features):
    labels_in_order = []
    seen = set()
    for _, label in examples:
        if label not in seen:
            seen.add(label)
            labels_in_order.append(label)
    counts = Counter(label for _, label in examples)
    majority = _majority(labels_in_order, counts)
    if len(counts) == 1 or not features:
        return _Leaf(majority)
    total = len(examples)
    base = _entropy(counts, total)
    best_feat = None
    best_gain = 0.0
    best_groups = None
    for feat in features:
        groups = defaultdict(list)
        for fs, label in examples:
            groups[fs.get(feat)].append((fs, label))
        if len(groups) < 2:
            continue
        remainder = 0.0
        for group in groups.values():
            gcounts = Counter(label for _, label in group)
            remainder += len(group) / total * _entropy(gcounts, len(group))
        gain = base - remainder
        if gain > best_gain + 1e-12:
            best_feat, best_gain, best_groups = feat, gain, groups
    if best_feat is None:
        return _Leaf(majority)
    remaining = [f for f in features if f != best_feat]
    branches = {value: _build_tree(group, remaining) for value, group in best_groups.items()}
    return _Node(best_feat, branches, majority)


class DecisionTreeClassifier:
    """ID3 decision tree: at each node the feature with the greatest information gain."""

    def __init__(self, root):
        self._root = root

    @classmethod
    def train(cls, labeled_featuresets):
        pairs = _check_labeled(labeled_featuresets)
        if not pairs:
            raise ValueError("cannot train a decision tree on no examples")
        feats = set()
        for fs, _ in pairs:
            feats.update(fs.keys())
        features = sorted(feats, key=lambda f: (str(type(f)), str(f)))
        return cls(_build_tree(pairs, features))

    def classify(self, featureset):
        node = self._root
        while isinstance(node, _Node):
            value = featureset.get(node.feature)
            child = node.branches.get(value)
            if child is None:
                return node.default
            node = child
        return node.label


def accuracy(classifier, gold):
    """Fraction of ``(featureset, label)`` pairs in ``gold`` that ``classifier`` labels correctly."""
    gold = list(gold)
    if not gold:
        raise ValueError("accuracy needs at least one gold example")
    correct = sum(1 for fs, label in gold if classifier.classify(fs) == label)
    return correct / len(gold)
