"""Part-of-speech taggers (FP-03)."""

import json
import os
import re
import threading
from collections import Counter, defaultdict

from lingora import data

__all__ = [
    "TaggerI",
    "DefaultTagger",
    "UnigramTagger",
    "RegexpTagger",
    "PerceptronTagger",
    "pos_tag",
    "map_tagset",
]


def _check_tokens(tokens):
    if isinstance(tokens, (str, bytes)):
        raise TypeError("tokens must be a list of str, not a string")
    tokens = list(tokens)
    for tok in tokens:
        if not isinstance(tok, str):
            raise TypeError("every token must be a str")
    return tokens


class TaggerI:
    """Base class for sequential taggers with optional backoff."""

    def __init__(self, backoff=None):
        if backoff is not None and not isinstance(backoff, TaggerI):
            raise TypeError("backoff must be a tagger or None")
        self._backoff = backoff

    def _tag_primary(self, tokens):
        """Return one tag or None per token."""
        raise NotImplementedError

    def tag(self, tokens):
        tokens = _check_tokens(tokens)
        if not tokens:
            return []
        tags = list(self._tag_primary(tokens))
        if self._backoff is not None:
            missing = [i for i, t in enumerate(tags) if t is None]
            if missing:
                fallback = self._backoff.tag([tokens[i] for i in missing])
                for i, (_, tag) in zip(missing, fallback):
                    tags[i] = tag
        return list(zip(tokens, tags))


class DefaultTagger(TaggerI):
    """Assigns one configured tag to every token."""

    def __init__(self, tag, backoff=None):
        super().__init__(backoff)
        self._tag = tag

    def _tag_primary(self, tokens):
        return [self._tag] * len(tokens)


class UnigramTagger(TaggerI):
    """Tags each word with the tag it was most often seen with in training.

    Ties are broken by the lexicographically smallest tag. Unseen words get no
    tag (``None``) unless a backoff tagger is given.
    """

    def __init__(self, train=None, backoff=None):
        super().__init__(backoff)
        counts = defaultdict(Counter)
        for sentence in train or []:
            for pair in sentence:
                if not (isinstance(pair, (tuple, list)) and len(pair) == 2):
                    raise TypeError("training sentences must be lists of (token, tag) pairs")
                word, tag = pair
                if tag is None:
                    continue
                counts[word][tag] += 1
        self._model = {}
        for word, tagcount in counts.items():
            best = min(tagcount.items(), key=lambda kv: (-kv[1], kv[0]))
            self._model[word] = best[0]

    def _tag_primary(self, tokens):
        return [self._model.get(tok) for tok in tokens]


class RegexpTagger(TaggerI):
    """Tags tokens with the first rule whose pattern matches at the token's start."""

    def __init__(self, regexps, backoff=None):
        super().__init__(backoff)
        self._rules = []
        for pattern, tag in regexps:
            self._rules.append((re.compile(pattern), tag))

    def _tag_primary(self, tokens):
        out = []
        for tok in tokens:
            tag = None
            for regexp, rule_tag in self._rules:
                if regexp.match(tok):
                    tag = rule_tag
                    break
            out.append(tag)
        return out


# ===========================================================================
# Averaged perceptron tagger (recommended English and Russian taggers)
# ===========================================================================

_LANG_RESOURCE = {"eng": "taggers/averaged_perceptron_tagger_eng",
                  "rus": "taggers/averaged_perceptron_tagger_rus"}
_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]

_model_lock = threading.Lock()
_model_cache = {}


class PerceptronTagger:
    """Greedy averaged perceptron tagger with the packaged model for ``lang``."""

    def __init__(self, lang="eng"):
        if lang not in _LANG_RESOURCE:
            raise ValueError("the recommended tagger supports only 'eng' and 'rus', not %r" % (lang,))
        self.lang = lang
        try:
            base = data.find(_LANG_RESOURCE[lang], directory=True)
        except data.ResourceNotFound:
            raise LookupError("averaged perceptron tagger for %r is not installed" % (lang,)) from None
        self.base = base
        with _model_lock:
            cached = _model_cache.get(base)
            if cached is None:
                cached = _load_model(base, lang)
                _model_cache[base] = cached
        self.weights, self.tagdict, self.classes = cached

    def tag(self, tokens):
        tokens = _check_tokens(tokens)
        if not tokens:
            return []
        context = _START + [_normalise(w) for w in tokens] + _END
        prev, prev2 = _START[0], _START[1]
        output = []
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                features = _features(i, word, context, prev, prev2)
                tag = self._predict(features)
            output.append((word, tag))
            prev2 = prev
            prev = tag
        return output

    def _predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            if value == 0 or feat not in self.weights:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))


def _load_model(base, lang):
    prefix = "averaged_perceptron_tagger_%s" % lang
    with open(os.path.join(base, prefix + ".weights.json"), encoding="utf-8") as fh:
        weights = json.load(fh)
    with open(os.path.join(base, prefix + ".tagdict.json"), encoding="utf-8") as fh:
        tagdict = json.load(fh)
    with open(os.path.join(base, prefix + ".classes.json"), encoding="utf-8") as fh:
        classes = json.load(fh)
    return weights, tagdict, list(classes)


def _normalise(word):
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word and word[0].isdigit():
        return "!DIGITS"
    return word.lower()


def _features(i, word, context, prev, prev2):
    features = defaultdict(int)

    def add(name, *args):
        features[" ".join((name,) + tuple(args))] += 1

    i += len(_START)
    add("bias")
    add("i suffix", word[-3:])
    add("i pref1", word[0] if word else "")
    add("i-1 tag", prev)
    add("i-2 tag", prev2)
    add("i tag+i-2 tag", prev, prev2)
    add("i word", context[i])
    add("i-1 tag+i word", prev, context[i])
    add("i-1 word", context[i - 1])
    add("i-1 suffix", context[i - 1][-3:])
    add("i-2 word", context[i - 2])
    add("i+1 word", context[i + 1])
    add("i+1 suffix", context[i + 1][-3:])
    add("i+2 word", context[i + 2])
    return features


# ===========================================================================
# Universal tagset mapping
# ===========================================================================

_RUS_TO_UNIVERSAL = {
    "S": "NOUN", "A": "ADJ", "A-NUM": "ADJ", "NUM": "NUM", "V": "VERB",
    "ADV": "ADV", "PRAEDIC": "ADV", "PARENTH": "X", "SPRO": "PRON", "APRO": "DET",
    "ADVPRO": "ADV", "PR": "ADP", "CONJ": "CONJ", "PART": "PRT", "INTJ": "X",
}


def _load_en_map():
    base = data.find("taggers/universal_tagset", directory=True)
    mapping = {}
    with open(os.path.join(base, "en-ptb.map"), encoding="utf-8") as fh:
        for line in fh:
            line = line.rstrip("\r\n")
            parts = line.split("\t")
            if len(parts) == 2:
                mapping[parts[0]] = parts[1]
    return mapping


def map_tagset(tagged, lang):
    """Map native tags to the universal tagset.

    English uses the packaged ``en-ptb.map``; Russian maps the part before any
    ``=`` through the table in ``_RUS_TO_UNIVERSAL``.
    """
    if lang == "eng":
        mapping = _load_en_map()
        return [(w, mapping.get(t, "X") if t is not None else None) for w, t in tagged]
    if lang == "rus":
        out = []
        for w, t in tagged:
            if t is None:
                out.append((w, None))
            else:
                pos = t.split("=")[0]
                out.append((w, _RUS_TO_UNIVERSAL.get(pos, "X")))
        return out
    raise ValueError("unsupported language %r" % (lang,))


def pos_tag(tokens, tagset=None, lang="eng"):
    """Tag a token list with the recommended tagger for ``lang`` (``'eng'`` or ``'rus'``).

    ``tagset`` is ``None`` for native tags or ``'universal'``.
    """
    if isinstance(tokens, (str, bytes)):
        raise TypeError("pos_tag expects a list of tokens, not a string")
    if lang not in _LANG_RESOURCE:
        raise ValueError("unsupported language %r for pos_tag" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("tagset must be None or 'universal'")
    tagger = PerceptronTagger(lang)
    tagged = tagger.tag(tokens)
    if tagset == "universal":
        tagged = map_tagset(tagged, lang)
    return tagged
