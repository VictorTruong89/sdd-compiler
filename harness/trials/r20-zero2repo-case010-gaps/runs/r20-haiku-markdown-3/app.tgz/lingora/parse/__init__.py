"""Grammar-based parsers (FP-05): chart and shift-reduce parsers."""

from lingora.grammar import Nonterminal
from lingora.tree import Tree

__all__ = ["ChartParser", "ShiftReduceParser"]


def _check_tokens(grammar, tokens):
    if isinstance(tokens, (str, bytes)):
        raise TypeError("tokens must be a list of str, not a string")
    tokens = list(tokens)
    terminals = grammar.terminals()
    for tok in tokens:
        if not isinstance(tok, str):
            raise TypeError("every token must be a str")
        if tok not in terminals:
            raise ValueError("token %r is not produced by any production of the grammar" % (tok,))
    return tokens


class ChartParser:
    """Exhaustive chart parser: yields every parse tree the grammar assigns to the tokens.

    Trees are built over spans with a cycle guard, so a unit-production cycle does
    not produce infinitely many trees.
    """

    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):
        grammar = self._grammar
        tokens = _check_tokens(grammar, tokens)
        n = len(tokens)
        prods = {}
        for prod in grammar.productions():
            prods.setdefault(prod.lhs().symbol(), []).append(prod)
        ok = _recognise(prods, tokens)
        start = grammar.start().symbol()

        def seqs(rhs, i, j, path):
            if not rhs:
                if i == j:
                    yield []
                return
            sym = rhs[0]
            rest = rhs[1:]
            if isinstance(sym, Nonterminal):
                for q in range(i, j + 1):
                    if not ok.get((sym.symbol(), i, q)):
                        continue
                    if not _span_derives(rest, q, j, ok, tokens):
                        continue
                    for sub in trees(sym.symbol(), i, q, path):
                        for kids in seqs(rest, q, j, path):
                            yield [sub] + kids
            else:
                if i < j and tokens[i] == sym:
                    for kids in seqs(rest, i + 1, j, path):
                        yield [sym] + kids

        def trees(name, i, j, path):
            key = (name, i, j)
            if not ok.get(key) or key in path:
                return
            path = path | {key}
            for prod in prods.get(name, []):
                for kids in seqs(prod.rhs(), i, j, path):
                    yield Tree(name, kids)

        return trees(start, 0, n, frozenset())


def _recognise(prods, tokens):
    """Return a dict (name, i, j) -> True for every span a nonterminal derives."""
    n = len(tokens)
    ok = {}
    changed = True
    while changed:
        changed = False
        for length in range(0, n + 1):
            for i in range(0, n - length + 1):
                j = i + length
                for name, plist in prods.items():
                    if ok.get((name, i, j)):
                        continue
                    for prod in plist:
                        if _span_derives(prod.rhs(), i, j, ok, tokens):
                            ok[(name, i, j)] = True
                            changed = True
                            break
    return ok


def _span_derives(rhs, i, j, ok, tokens):
    """Whether the symbol sequence ``rhs`` derives ``tokens[i:j]``."""
    reach = {i}
    for sym in rhs:
        nxt = set()
        for p in reach:
            if isinstance(sym, Nonterminal):
                for q in range(p, j + 1):
                    if ok.get((sym.symbol(), p, q)):
                        nxt.add(q)
            elif p < j and tokens[p] == sym:
                nxt.add(p + 1)
        reach = nxt
        if not reach:
            return False
    return j in reach


class ShiftReduceParser:
    """Single left-to-right shift-reduce pass without backtracking.

    Reduces whenever the top of the stack matches a production's right-hand side
    (productions tried in written order), otherwise shifts the next token.
    Returns the one tree the pass completes, or nothing.
    """

    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):
        grammar = self._grammar
        tokens = _check_tokens(grammar, tokens)
        prods = grammar.productions()
        start = grammar.start().symbol()
        stack = []
        idx = 0
        n = len(tokens)
        budget = 20 * (n + 1) * (len(prods) + 1) + 100
        while budget > 0:
            budget -= 1
            reduced = False
            for prod in prods:
                rhs = prod.rhs()
                size = len(rhs)
                # Empty productions never match a stack top, so they are not reduced
                # in this pass (the chart parser handles epsilon derivations).
                if size == 0 or len(stack) < size:
                    continue
                top = stack[-size:]
                if _matches(top, rhs):
                    del stack[-size:]
                    stack.append(Tree(prod.lhs().symbol(), list(top)))
                    reduced = True
                    break
            if reduced:
                continue
            if idx < n:
                stack.append(tokens[idx])
                idx += 1
                continue
            break
        if idx == n and len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == start:
            return iter([stack[0]])
        return iter([])


def _matches(items, rhs):
    for item, sym in zip(items, rhs):
        if isinstance(sym, Nonterminal):
            if not (isinstance(item, Tree) and item.label() == sym.symbol()):
                return False
        else:
            if not (isinstance(item, str) and item == sym):
                return False
    return True
