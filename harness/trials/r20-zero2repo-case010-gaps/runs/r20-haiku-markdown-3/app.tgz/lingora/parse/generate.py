"""Sentence generation from a context-free grammar (FP-05)."""

import itertools
import sys

from lingora.grammar import Nonterminal

__all__ = ["generate"]


def _gen_all(grammar, items, depth):
    if not items:
        yield []
        return
    for frag1 in _gen_one(grammar, items[0], depth):
        for frag2 in _gen_all(grammar, items[1:], depth):
            yield frag1 + frag2


def _gen_one(grammar, item, depth):
    if depth <= 0:
        return
    if isinstance(item, Nonterminal):
        for prod in grammar.productions(lhs=item):
            yield from _gen_all(grammar, list(prod.rhs()), depth - 1)
    else:
        yield [item]


def generate(grammar, start=None, depth=None, n=None):
    """Enumerate sentences derived from ``start`` (default: the grammar's start symbol).

    Productions are expanded in their written order. ``depth`` bounds the
    derivation depth (``None`` for no bound); ``n`` bounds the number of sentences
    (``None`` for no bound). Each sentence is a list of terminal strings.
    """
    if start is None:
        start = grammar.start()
    elif isinstance(start, str):
        start = Nonterminal(start)
    elif not isinstance(start, Nonterminal):
        raise TypeError("start must be a symbol, a str, or None")
    if depth is None:
        depth = sys.maxsize
    gen = _gen_all(grammar, [start], depth)
    if n is None:
        return gen
    return itertools.islice(gen, n)
