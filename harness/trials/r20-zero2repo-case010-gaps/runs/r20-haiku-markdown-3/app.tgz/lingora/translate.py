"""Translation-quality scores (FP-07): sentence-level BLEU."""

import math
from collections import Counter

__all__ = ["bleu", "SmoothingFunction"]


def _ngrams(tokens, n):
    return Counter(tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1))


class SmoothingFunction:
    """Smoothing functions. Each maps a list of ``(numerator, denominator)`` pairs
    (one per n-gram order) to adjusted pairs, and is passed to :func:`bleu`."""

    @staticmethod
    def method0(pairs):
        return list(pairs)

    @staticmethod
    def method1(pairs, epsilon=0.1):
        """Replace zero numerators with ``epsilon``."""
        return [(epsilon if num == 0 and den > 0 else num, den) for num, den in pairs]

    @staticmethod
    def method2(pairs):
        """Add one to numerator and denominator for orders above unigrams."""
        out = []
        for order, (num, den) in enumerate(pairs, 1):
            if order == 1:
                out.append((num, den))
            else:
                out.append((num + 1, den + 1))
        return out


def bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):
    """Sentence-level BLEU (Papineni et al., 2002).

    ``references`` is a list of reference token lists; ``hypothesis`` a token list;
    ``weights`` one weight per n-gram order starting from unigrams. Without a
    smoothing function a zero n-gram match in any weighted order scores 0.
    """
    if isinstance(hypothesis, (str, bytes)):
        raise TypeError("hypothesis must be a token list")
    hyp = list(hypothesis)
    refs = []
    for ref in references:
        if isinstance(ref, (str, bytes)):
            raise TypeError("each reference must be a token list")
        refs.append(list(ref))
    if not refs:
        raise ValueError("bleu needs at least one reference")
    weights = list(weights)
    for w in weights:
        if isinstance(w, bool) or not isinstance(w, (int, float)):
            raise TypeError("weights must be numbers")

    pairs = []
    for n in range(1, len(weights) + 1):
        hyp_counts = _ngrams(hyp, n)
        max_ref = Counter()
        for ref in refs:
            for gram, count in _ngrams(ref, n).items():
                if count > max_ref[gram]:
                    max_ref[gram] = count
        clipped = sum(min(count, max_ref[gram]) for gram, count in hyp_counts.items())
        total = max(len(hyp) - n + 1, 0)
        pairs.append((clipped, total))

    if smoothing_function is not None:
        pairs = list(smoothing_function(pairs))

    hyp_len = len(hyp)
    if hyp_len == 0:
        return 0.0
    ref_len = min((len(r) for r in refs), key=lambda rl: (abs(rl - hyp_len), rl))
    if hyp_len > ref_len:
        brevity = 1.0
    else:
        brevity = math.exp(1 - ref_len / hyp_len)

    log_sum = 0.0
    for w, (num, den) in zip(weights, pairs):
        if w == 0:
            continue
        if num <= 0 or den <= 0:
            return 0.0
        log_sum += w * math.log(num / den)
    return brevity * math.exp(log_sum)
