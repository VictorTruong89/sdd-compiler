"""Context-free grammars read from text (FP-05)."""

__all__ = ["Nonterminal", "Production", "CFG"]


class Nonterminal:
    """A nonterminal symbol. ``str()`` is its name; it is not a ``str`` itself."""

    __slots__ = ("_symbol",)

    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __str__(self):
        return self._symbol

    def __repr__(self):
        return "Nonterminal(%r)" % (self._symbol,)

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and other._symbol == self._symbol

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash(("Nonterminal", self._symbol))


class Production:
    """One alternative: ``lhs -> rhs``. ``rhs`` holds Nonterminals and ``str`` terminals."""

    __slots__ = ("_lhs", "_rhs")

    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return (isinstance(other, Production) and other._lhs == self._lhs
                and other._rhs == self._rhs)

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __repr__(self):
        return "%s" % self

    def __str__(self):
        parts = []
        for sym in self._rhs:
            parts.append(_show(sym))
        return "%s -> %s" % (self._lhs, " ".join(parts))


def _show(sym):
    if isinstance(sym, Nonterminal):
        return str(sym)
    return '"%s"' % sym


def _split_alternatives(rhs_text):
    """Split on ``|`` that is outside quotes."""
    alternatives = []
    current = []
    quote = None
    for ch in rhs_text:
        if quote:
            current.append(ch)
            if ch == quote:
                quote = None
        elif ch in ("'", '"'):
            quote = ch
            current.append(ch)
        elif ch == "|":
            alternatives.append("".join(current))
            current = []
        else:
            current.append(ch)
    if quote:
        raise ValueError("unterminated quote in production %r" % (rhs_text,))
    alternatives.append("".join(current))
    return alternatives


def _parse_symbols(text):
    symbols = []
    i = 0
    n = len(text)
    while i < n:
        ch = text[i]
        if ch.isspace():
            i += 1
        elif ch in ("'", '"'):
            end = text.find(ch, i + 1)
            if end < 0:
                raise ValueError("unterminated quote in %r" % (text,))
            symbols.append(text[i + 1:end])
            i = end + 1
        else:
            j = i
            while j < n and not text[j].isspace() and text[j] not in ("'", '"'):
                j += 1
            symbols.append(Nonterminal(text[i:j]))
            i = j
    return symbols


class CFG:
    """A context-free grammar: a start symbol and its productions."""

    def __init__(self, start, productions):
        if not productions:
            raise ValueError("a grammar needs at least one production")
        self._start = start
        self._productions = list(productions)

    @classmethod
    def fromstring(cls, input):
        """Read productions from text, one ``LHS -> RHS`` per line.

        The start symbol is the left-hand side of the first production.
        """
        if not isinstance(input, str):
            raise TypeError("CFG.fromstring expects a str")
        productions = []
        start = None
        for lineno, raw in enumerate(input.splitlines(), 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "->" not in line:
                raise ValueError("grammar line %d: expected 'LHS -> RHS'" % lineno)
            lhs_text, rhs_text = line.split("->", 1)
            lhs_text = lhs_text.strip()
            if not lhs_text or any(c.isspace() for c in lhs_text) or lhs_text[0] in "'\"":
                raise ValueError("grammar line %d: bad left-hand side" % lineno)
            lhs = Nonterminal(lhs_text)
            if start is None:
                start = lhs
            for alt in _split_alternatives(rhs_text):
                productions.append(Production(lhs, _parse_symbols(alt)))
        if start is None:
            raise ValueError("grammar text has no productions")
        return cls(start, productions)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        if isinstance(lhs, str):
            lhs = Nonterminal(lhs)
        return [p for p in self._productions if p.lhs() == lhs]

    def terminals(self):
        out = set()
        for prod in self._productions:
            for sym in prod.rhs():
                if isinstance(sym, str):
                    out.add(sym)
        return out

    def __repr__(self):
        return "<CFG with %d productions>" % len(self._productions)
