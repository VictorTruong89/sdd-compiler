# Keeps the project root on sys.path so `import lingora` works from /app under pytest.
