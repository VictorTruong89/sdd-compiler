"""Smoke tests for the core LINGORA paths that need no packaged model."""

import pytest

from lingora.chunk import RegexpParser
from lingora.classify import DecisionTreeClassifier, NaiveBayesClassifier
from lingora.grammar import CFG
from lingora.metrics import edit_distance, f_measure, precision
from lingora.parse import ChartParser
from lingora.stem import LancasterStemmer, PorterStemmer, RegexpStemmer, SnowballStemmer
from lingora.tokenize import TreebankWordTokenizer, TweetTokenizer, blankline_tokenize, wordpunct_tokenize
from lingora.translate import bleu
from lingora.tree import Tree


def test_wordpunct():
    assert wordpunct_tokenize("Hello, world!") == ["Hello", ",", "world", "!"]
    assert wordpunct_tokenize("") == []


def test_treebank_clitics_and_fused():
    tb = TreebankWordTokenizer()
    assert tb.tokenize("I can't go") == ["I", "ca", "n't", "go"]
    assert tb.tokenize("I cannot") == ["I", "can", "not"]
    assert tb.tokenize('"Hi," she said.') == ["``", "Hi", ",", "''", "she", "said", "."]


def test_tweet_and_blankline():
    assert TweetTokenizer().tokenize("don't :-) #yes") == ["don't", ":-)", "#yes"]
    assert blankline_tokenize("a\nb\n\n  c") == ["a\nb", "c"]


def test_stemmers():
    assert PorterStemmer().stem("running") == "run"
    assert PorterStemmer().stem("ponies") == "poni"
    assert PorterStemmer().stem("ties") == "tie"
    assert SnowballStemmer("english").stem("generously") == "generous"
    assert LancasterStemmer().stem("maximum") == "maxim"
    assert RegexpStemmer("ing$").stem("walking") == "walk"
    with pytest.raises(ValueError):
        SnowballStemmer("klingon")


def test_chunk_and_tree():
    tagged = [("the", "DT"), ("dog", "NN"), ("ran", "VBD")]
    tree = RegexpParser("NP: {<DT>?<NN>}").parse(tagged)
    assert tree.pformat().startswith("(S")
    assert tree[0].label() == "NP"
    assert Tree.fromstring("(S (NP (DT the)) (VP ran))").leaves() == ["the", "ran"]
    with pytest.raises(TypeError):
        Tree("X", "ab")


def test_parsing():
    g = CFG.fromstring("S -> NP VP\nNP -> 'dogs'\nVP -> 'bark'\n")
    trees = list(ChartParser(g).parse(["dogs", "bark"]))
    assert len(trees) == 1 and trees[0].leaves() == ["dogs", "bark"]
    assert list(ChartParser(g).parse(["bark", "dogs"])) == []
    with pytest.raises(ValueError):
        ChartParser(g).parse(["cats"])


def test_classifiers():
    train = [({"w": "good"}, "pos"), ({"w": "bad"}, "neg")]
    assert NaiveBayesClassifier.train(train).classify({"w": "good"}) == "pos"
    assert DecisionTreeClassifier.train(train).classify({"w": "bad"}) == "neg"


def test_metrics_and_bleu():
    assert edit_distance("ab", "ba", transpositions=True) == 1
    assert edit_distance("ab", "ba") == 2
    assert precision({1, 2}, {2, 3}) == 0.5
    assert precision({1}, set()) is None
    assert f_measure({1}, {2}) == 0.0
    assert bleu([["a", "b", "c", "d"]], ["a", "b", "c", "d"]) == pytest.approx(1.0)
    assert bleu([["a", "b", "c", "d"]], ["x"]) == 0.0
