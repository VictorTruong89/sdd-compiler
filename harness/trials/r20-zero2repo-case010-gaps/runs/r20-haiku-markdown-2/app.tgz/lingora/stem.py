"""Stemmers: Porter (LINGORA extensions by default), Lancaster, Snowball, regular-expression.

Stemmer families named by the PRD but outside the specified results (ISRI, ARLSTem,
ARLSTem2, Cistem, RSLP, WordNet lemmatizer) exist as names and raise when used.
"""

import os
import re

from lingora import data

# ---------------------------------------------------------------------------
# Porter


_IRREGULAR_FORMS = {
    "sky": "sky", "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie",
    "tying": "tie", "idly": "idl", "gently": "gentl", "ugly": "ugli",
    "early": "earli", "only": "onli", "singly": "singl", "news": "news",
    "howe": "howe", "atlas": "atlas", "cosmos": "cosmos", "bias": "bias",
    "andes": "andes",
}

_STEP2_EXT = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("bli", "ble"), ("entli", "ent"), ("eli", "e"),
    ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"), ("ator", "ate"),
    ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"), ("ousness", "ous"),
    ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"), ("logi", "log"),
    ("fulli", "ful"),
]
_STEP2_ORIG = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("abli", "able"), ("alli", "al"), ("entli", "ent"),
    ("eli", "e"), ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"),
    ("ator", "ate"), ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"),
    ("ousness", "ous"), ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"),
]
_STEP2_MARTIN = _STEP2_ORIG + [("logi", "log")]
_STEP3 = [("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"),
          ("ical", "ic"), ("ful", ""), ("ness", "")]
_STEP4 = ["al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement",
          "ment", "ent", "ion", "ou", "ism", "ate", "iti", "ous", "ive", "ize"]


class PorterStemmer:
    """Porter's algorithm (1980).

    Modes: NLTK_EXTENSIONS (default, the LINGORA extensions), MARTIN_EXTENSIONS and
    ORIGINAL_ALGORITHM.
    """

    NLTK_EXTENSIONS = "NLTK_EXTENSIONS"
    MARTIN_EXTENSIONS = "MARTIN_EXTENSIONS"
    ORIGINAL_ALGORITHM = "ORIGINAL_ALGORITHM"

    def __init__(self, mode=NLTK_EXTENSIONS):
        if mode not in (self.NLTK_EXTENSIONS, self.MARTIN_EXTENSIONS, self.ORIGINAL_ALGORITHM):
            raise ValueError("unknown Porter mode %r" % (mode,))
        self.mode = mode
        self._ext = mode == self.NLTK_EXTENSIONS

    def stem(self, word, to_lowercase=True):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        w = word.lower() if to_lowercase else word
        if self._ext and w in _IRREGULAR_FORMS:
            return _IRREGULAR_FORMS[w]
        if len(w) <= 2:
            return w
        w = self._step1a(w)
        w = self._step1b(w)
        w = self._step1c(w)
        w = self._step2(w)
        w = self._step3(w)
        w = self._step4(w)
        w = self._step5a(w)
        w = self._step5b(w)
        return w

    # --- helpers -----------------------------------------------------------

    @staticmethod
    def _is_cons(w, i):
        c = w[i]
        if c in "aeiou":
            return False
        if c == "y":
            return True if i == 0 else not PorterStemmer._is_cons(w, i - 1)
        return True

    @classmethod
    def _measure(cls, stem):
        m = 0
        prev_vowel = False
        for i in range(len(stem)):
            if cls._is_cons(stem, i):
                if prev_vowel:
                    m += 1
                prev_vowel = False
            else:
                prev_vowel = True
        return m

    @classmethod
    def _contains_vowel(cls, stem):
        return any(not cls._is_cons(stem, i) for i in range(len(stem)))

    @classmethod
    def _ends_double_cons(cls, w):
        return len(w) >= 2 and w[-1] == w[-2] and cls._is_cons(w, len(w) - 1)

    def _ends_cvc(self, w):
        if len(w) >= 3:
            if (self._is_cons(w, len(w) - 3) and not self._is_cons(w, len(w) - 2)
                    and self._is_cons(w, len(w) - 1) and w[-1] not in "wxy"):
                return True
        if self._ext and len(w) == 2:
            if (not self._is_cons(w, 0) and self._is_cons(w, 1) and w[-1] not in "wxy"):
                return True
        return False

    # --- steps -------------------------------------------------------------

    def _step1a(self, w):
        if w.endswith("sses"):
            return w[:-2]
        if w.endswith("ies"):
            if self._ext and len(w) == 4:
                return w[:-1]
            return w[:-2]
        if w.endswith("ss"):
            return w
        if w.endswith("s"):
            return w[:-1]
        return w

    def _step1b(self, w):
        if self._ext and w.endswith("ied"):
            return w[:-1] if len(w) == 4 else w[:-2]
        if w.endswith("eed"):
            if self._measure(w[:-3]) > 0:
                return w[:-1]
            return w
        for suffix in ("ed", "ing"):
            if w.endswith(suffix):
                stem = w[:-len(suffix)]
                if not self._contains_vowel(stem):
                    return w
                w = stem
                if w.endswith(("at", "bl", "iz")):
                    return w + "e"
                if self._ends_double_cons(w) and w[-1] not in "lsz":
                    return w[:-1]
                if self._measure(w) == 1 and self._ends_cvc(w):
                    return w + "e"
                return w
        return w

    def _step1c(self, w):
        if w.endswith("y"):
            if self._ext:
                if len(w) > 2 and self._is_cons(w, len(w) - 2):
                    return w[:-1] + "i"
            elif self._contains_vowel(w[:-1]):
                return w[:-1] + "i"
        return w

    def _step2(self, w):
        if self._ext and w.endswith("alli") and self._measure(w[:-4]) > 0:
            return self._step2(w[:-2])
        if self._ext:
            table = _STEP2_EXT
        elif self.mode == self.MARTIN_EXTENSIONS:
            table = _STEP2_MARTIN
        else:
            table = _STEP2_ORIG
        if self._ext and w.endswith("alli"):
            table = table + [("alli", "al")]
        for suffix, repl in table:
            if w.endswith(suffix):
                stem = w[:-len(suffix)]
                if self._measure(stem) > 0:
                    return stem + repl
                return w
        return w

    def _step3(self, w):
        for suffix, repl in _STEP3:
            if w.endswith(suffix):
                stem = w[:-len(suffix)]
                if self._measure(stem) > 0:
                    return stem + repl
                return w
        return w

    def _step4(self, w):
        for suffix in _STEP4:
            if w.endswith(suffix):
                stem = w[:-len(suffix)]
                if suffix == "ion" and not (stem and stem[-1] in "st"):
                    return w
                if self._measure(stem) > 1:
                    return stem
                return w
        return w

    def _step5a(self, w):
        if w.endswith("e"):
            stem = w[:-1]
            m = self._measure(stem)
            if m > 1 or (m == 1 and not self._ends_cvc(stem)):
                return stem
        return w

    def _step5b(self, w):
        if self._measure(w) > 1 and self._ends_double_cons(w) and w.endswith("l"):
            return w[:-1]
        return w


# ---------------------------------------------------------------------------
# Lancaster (Paice/Husk)

# Rule format: reversed suffix letters, optional '*' (rule needs an intact word),
# a digit (letters removed from the end), appended letters, and '>' (continue) or '.' (stop).
_LANCASTER_RULES = (
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>", "cn1t>", "dd1.", "dei3y>",
    "deec2ss.", "dee1.", "de2>", "dooh4>", "e1>", "feil1v.", "fi2>", "gni3>",
    "gai3y.", "ga2>", "gg1.", "ht*2.", "hsiug5ct.", "hsi3>", "i*1.", "i1y>",
    "ji1d.", "juf1s.", "ju1d.", "jo1d.", "jeh1r.", "jrev1t.", "jsim2t.", "jn1d.",
    "j1s.", "lbaifi6.", "lbai4y.", "lba3.", "lbi3.", "lib2l>", "lc1.", "lufi4y.",
    "luf3y.", "lu2.", "lai3y>", "lau3>", "la2.", "ll1.", "mui3.", "mu*2.",
    "msi3>", "mm1.", "nois4j>", "noix4ct.", "noi3>", "nai3y>", "na2>", "nee0.",
    "ne2>", "nn1.", "pihs4>", "pp1.", "re2>", "rae0.", "ra2.", "ro2>", "ru2>",
    "rr1.", "rt1>", "rei3y>", "sei3y>", "sis2.", "si2>", "ssen4>", "ss0.",
    "suo3>", "su*2.", "s*1>", "s0.", "tacilp4y.", "ta2>", "tne3>",
    "tpir2b.", "tpro2b.", "tcud1.", "tpmus2.", "tpec2iv.", "tulo2v.", "tsis0.",
    "tsi3>", "tt1.", "uqi3.", "ugo1.", "vis3j>", "vie0.", "vi2>", "ylb1>",
    "yli3y>", "ylp0.", "yl2>", "ygo1.", "yhp1.", "ymo1.", "ypo1.", "yti3>",
    "yte3>", "ytl2.", "vid3s.", "zi2>", "zy1s.",
)
_LANCASTER_PARSED = []
for _rule in _LANCASTER_RULES:
    _m = re.fullmatch(r"([a-z]+)(\*?)(\d)([a-z]*)([.>])", _rule)
    _LANCASTER_PARSED.append(
        (_m.group(1)[::-1], bool(_m.group(2)), int(_m.group(3)), _m.group(4), _m.group(5) == ">")
    )


class LancasterStemmer:
    """Paice/Husk stemmer: rules applied repeatedly; no prefix stripping."""

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        w = word.lower()
        intact = True
        while True:
            applied = False
            for suffix, needs_intact, remove, append, cont in _LANCASTER_PARSED:
                if not w.endswith(suffix):
                    continue
                if needs_intact and not intact:
                    continue
                stem = w[:-remove] if remove else w
                if len(stem) < 2 or not any(c in "aeiouy" for c in stem):
                    continue
                w = stem + append
                applied = True
                if cont:
                    intact = False
                    break
                return w
            if not applied:
                return w


# ---------------------------------------------------------------------------
# Snowball

SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german",
    "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
    "russian", "spanish", "swedish",
)
_SNOWBALL_IMPLEMENTED = ("english", "porter")

_VOWELS = "aeiouy"


def _porter2_r1(word):
    for prefix in ("gener", "commun", "arsen"):
        if word.startswith(prefix):
            return len(prefix)
    for i in range(1, len(word)):
        if word[i] not in _VOWELS and word[i - 1] in _VOWELS:
            return i + 1
    return len(word)


def _porter2_r2(word, r1):
    for i in range(r1 + 1, len(word)):
        if word[i] not in _VOWELS and word[i - 1] in _VOWELS:
            return i + 1
    return len(word)


def _porter2_short_syllable_end(word):
    """True if word ends in a short syllable."""
    n = len(word)
    if n == 2:
        return word[0] in _VOWELS and word[1] not in _VOWELS
    if n >= 3:
        return (word[-3] not in _VOWELS and word[-2] in _VOWELS
                and word[-1] not in _VOWELS and word[-1] not in "wxY")
    return False


class _Porter2:
    """Snowball English (Porter2) stemmer."""

    EXCEPTIONAL = {
        "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
        "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli",
        "only": "onli", "singly": "singl",
    }
    INVARIANT = {"sky", "news", "howe", "atlas", "cosmos", "bias", "andes"}

    def stem(self, word):
        w = word
        if len(w) <= 2:
            return w
        if w in self.EXCEPTIONAL:
            return self.EXCEPTIONAL[w]
        if w in self.INVARIANT:
            return w
        if w.startswith("'"):
            w = w[1:]
        # mark y as consonant when initial or after a vowel
        chars = list(w)
        if chars and chars[0] == "y":
            chars[0] = "Y"
        for i in range(1, len(chars)):
            if chars[i] == "y" and chars[i - 1] in _VOWELS:
                chars[i] = "Y"
        w = "".join(chars)

        r1 = _porter2_r1(w)
        r2 = _porter2_r2(w, r1)

        # Step 0
        for suf in ("'s'", "'s", "'"):
            if w.endswith(suf):
                w = w[:-len(suf)]
                break

        # Step 1a
        if w.endswith("sses"):
            w = w[:-2]
        elif w.endswith(("ied", "ies")):
            # replace by "i" when preceded by more than one letter, otherwise by "ie"
            w = w[:-2] if len(w) > 4 else w[:-1]
        elif w.endswith(("us", "ss")):
            pass
        elif w.endswith("s"):
            if any(c in _VOWELS for c in w[:-2]):
                w = w[:-1]

        # Step 1b
        exceptional_after_1a = False
        if w.endswith(("eedly", "eed")):
            suf = "eedly" if w.endswith("eedly") else "eed"
            if len(w) - len(suf) >= r1:
                w = w[:-len(suf)] + "ee"
        else:
            for suf in ("ingly", "edly", "ing", "ed"):
                if w.endswith(suf):
                    stem = w[:-len(suf)]
                    if any(c in _VOWELS for c in stem):
                        w = stem
                        exceptional_after_1a = True
                    break
            if exceptional_after_1a:
                if w.endswith(("at", "bl", "iz")):
                    w = w + "e"
                elif self._ends_double(w):
                    w = w[:-1]
                elif _porter2_r1(w) == len(w) and _porter2_short_syllable_end(w):
                    w = w + "e"

        # Recompute regions after step 1a/1b
        r1 = _porter2_r1(w)
        r2 = _porter2_r2(w, r1)

        # Step 1c
        if len(w) > 2 and w[-1] in "yY" and w[-2] not in _VOWELS:
            w = w[:-1] + "i"

        # Step 2
        step2 = [
            ("tional", "tion"), ("enci", "ence"), ("anci", "ance"), ("abli", "able"),
            ("entli", "ent"), ("izer", "ize"), ("ization", "ize"), ("ational", "ate"),
            ("ation", "ate"), ("ator", "ate"), ("alism", "al"), ("aliti", "al"),
            ("alli", "al"), ("fulness", "ful"), ("ousli", "ous"), ("ousness", "ous"),
            ("iveness", "ive"), ("iviti", "ive"), ("biliti", "ble"), ("bli", "ble"),
            ("ogi", "og"), ("fulli", "ful"), ("lessli", "less"), ("li", ""),
        ]
        for suf, rep in step2:
            if w.endswith(suf):
                if len(w) - len(suf) >= r1:
                    if suf == "ogi":
                        if w[-4:-3] == "l":
                            w = w[:-3] + rep
                        break
                    if suf == "li":
                        if len(w) >= 3 and w[-3] in "cdeghkmnrt":
                            w = w[:-2]
                        break
                    w = w[:-len(suf)] + rep
                break

        # Step 3
        step3 = [
            ("tional", "tion"), ("ational", "ate"), ("alize", "al"), ("icate", "ic"),
            ("iciti", "ic"), ("ical", "ic"), ("ful", ""), ("ness", ""), ("ative", ""),
        ]
        for suf, rep in step3:
            if w.endswith(suf):
                if len(w) - len(suf) >= r1:
                    if suf == "ative" and len(w) - len(suf) < r2:
                        break
                    w = w[:-len(suf)] + rep
                break

        # Step 4
        step4 = [
            "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment",
            "ent", "ism", "ate", "iti", "ous", "ive", "ize", "ion",
        ]
        for suf in step4:
            if w.endswith(suf):
                if len(w) - len(suf) >= r2:
                    if suf == "ion" and not (len(w) > 3 and w[-4] in "st"):
                        break
                    w = w[:-len(suf)]
                break

        # Step 5
        if w.endswith("e"):
            if len(w) - 1 >= r2 or (len(w) - 1 >= r1 and not _porter2_short_syllable_end(w[:-1])):
                w = w[:-1]
        elif w.endswith("l"):
            if len(w) - 1 >= r2 and w[-2:-1] == "l":
                w = w[:-1]

        return w.replace("Y", "y")

    @staticmethod
    def _ends_double(w):
        return len(w) >= 2 and w[-1] == w[-2] and w[-1] in "bdfgmnprt"


class SnowballStemmer:
    """Snowball stemmer for ``language``. Implemented here: 'english' (Porter2) and 'porter'."""

    def __init__(self, language, ignore_stopwords=False):
        if not isinstance(language, str) or language not in SNOWBALL_LANGUAGES:
            raise ValueError("unsupported Snowball language %r" % (language,))
        if language not in _SNOWBALL_IMPLEMENTED:
            raise NotImplementedError("Snowball stemmer for %r is not implemented in this build" % language)
        self.language = language
        self.ignore_stopwords = bool(ignore_stopwords)
        self._stopwords = frozenset()
        if self.ignore_stopwords:
            path = data.find(os.path.join("corpora", "stopwords", language))
            if not os.path.isfile(path):
                raise LookupError("stopwords list for %r is not a file: %s" % (language, path))
            with open(path, encoding="utf-8") as fh:
                self._stopwords = frozenset(line.strip().lower() for line in fh if line.strip())
        if language == "english":
            self._impl = _Porter2()
        else:
            self._impl = PorterStemmer(PorterStemmer.ORIGINAL_ALGORITHM)

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        w = word.lower()
        if self.ignore_stopwords and w in self._stopwords:
            return w
        if self.language == "english":
            return self._impl.stem(w)
        return self._impl.stem(w, to_lowercase=False)


# ---------------------------------------------------------------------------
# Regular-expression stemmer

class RegexpStemmer:
    """Removes every match of the pattern from the word; nothing else changes."""

    def __init__(self, regexp):
        if not isinstance(regexp, str):
            raise TypeError("regexp must be a str")
        self._re = re.compile(regexp)

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        return self._re.sub("", word)


# ---------------------------------------------------------------------------
# Families named by the PRD whose results are outside this specification.

class _UnimplementedStemmer:
    name = "stemmer"

    def __init__(self, *args, **kwargs):
        pass

    def stem(self, word):
        raise NotImplementedError("%s is not implemented in this build" % self.name)


class ISRIStemmer(_UnimplementedStemmer):
    name = "ISRI stemmer"


class ARLSTem(_UnimplementedStemmer):
    name = "ARLSTem stemmer"


class ARLSTem2(_UnimplementedStemmer):
    name = "ARLSTem2 stemmer"


class Cistem(_UnimplementedStemmer):
    name = "Cistem stemmer"


class RSLPStemmer(_UnimplementedStemmer):
    name = "RSLP stemmer"


class WordNetLemmatizer:
    """Requires the WordNet resource; raises when it is not visible. Lemmatization itself is not implemented."""

    def __init__(self):
        if not data.exists(os.path.join("corpora", "wordnet")):
            raise LookupError("WordNet resource corpora/wordnet is not visible")
        raise NotImplementedError("WordNet lemmatization is not implemented in this build")

    def lemmatize(self, word):
        raise NotImplementedError("WordNet lemmatization is not implemented in this build")
