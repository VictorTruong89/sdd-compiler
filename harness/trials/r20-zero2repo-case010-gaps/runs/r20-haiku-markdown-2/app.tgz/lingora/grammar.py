"""Context-free grammars read from text such as ``S -> NP VP`` and ``NP -> "the" N``."""

import re


class Nonterminal:
    """A nonterminal symbol. ``str()`` gives its name."""

    __slots__ = ("_symbol",)

    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __str__(self):
        return self._symbol

    def __repr__(self):
        return "Nonterminal(%r)" % self._symbol

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and other._symbol == self._symbol

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash(("Nonterminal", self._symbol))


class Production:
    """One alternative: a left-hand nonterminal and a right-hand sequence of Nonterminal or str terminals."""

    __slots__ = ("_lhs", "_rhs")

    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return isinstance(other, Production) and (self._lhs, self._rhs) == (other._lhs, other._rhs)

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __repr__(self):
        return "%s -> %s" % (self._lhs, " ".join(_show(x) for x in self._rhs))


def _show(sym):
    if isinstance(sym, Nonterminal):
        return str(sym)
    return '"%s"' % sym


class CFG:
    """A context-free grammar; the start symbol is the left-hand side of the first production."""

    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            raise TypeError("grammar text must be a str")
        productions = []
        start = None
        for lineno, raw in enumerate(input.splitlines(), 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "->" not in line:
                raise ValueError("line %d has no '->': %r" % (lineno, raw))
            lhs_text, rhs_text = line.split("->", 1)
            lhs_name = lhs_text.strip()
            if not re.fullmatch(r"[A-Za-z_][\w\-']*", lhs_name):
                raise ValueError("line %d: bad left-hand side %r" % (lineno, lhs_name))
            lhs = Nonterminal(lhs_name)
            if start is None:
                start = lhs
            for alt in _split_alternatives(rhs_text, lineno):
                productions.append(Production(lhs, alt))
        if start is None:
            raise ValueError("grammar has no productions")
        return cls(start, productions)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        return [p for p in self._productions if p.lhs() == lhs]

    def is_nonterminal(self, sym):
        return isinstance(sym, Nonterminal)

    def terminals(self):
        out = set()
        for p in self._productions:
            for sym in p.rhs():
                if not isinstance(sym, Nonterminal):
                    out.add(sym)
        return out

    def __repr__(self):
        return "<CFG with %d productions>" % len(self._productions)


_TOKEN_RE = re.compile(r"""\s*(?:"([^"]*)"|'([^']*)'|([^\s"'|]+)|(\|))""")


def _split_alternatives(rhs_text, lineno):
    """Split the right-hand side on '|' into alternatives, each a list of symbols."""
    alts = [[]]
    pos = 0
    text = rhs_text
    while True:
        m = _TOKEN_RE.match(text, pos)
        if not m:
            if text[pos:].strip() == "":
                break
            raise ValueError("line %d: cannot read right-hand side %r" % (lineno, rhs_text))
        pos = m.end()
        dq, sq, bare, bar = m.groups()
        if bar is not None:
            alts.append([])
        elif dq is not None:
            alts[-1].append(dq)
        elif sq is not None:
            alts[-1].append(sq)
        else:
            alts[-1].append(Nonterminal(bare))
    # An empty right-hand side (or an empty alternative) is an empty production.
    return [alt for alt in alts]
