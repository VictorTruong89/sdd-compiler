"""Single-pass shift-reduce parser without backtracking."""

from lingora.grammar import CFG, Nonterminal
from lingora.parse.chart import _check_tokens
from lingora.tree import Tree


def _matches_top(stack, rhs):
    n = len(rhs)
    if len(stack) < n:
        return False
    top = stack[len(stack) - n:]
    for sym, item in zip(rhs, top):
        if isinstance(sym, Nonterminal):
            if not (isinstance(item, Tree) and item.label() == str(sym)):
                return False
        else:
            if isinstance(item, Tree) or item != sym:
                return False
    return True


class ShiftReduceParser:
    """Reduces whenever the stack top matches a production's right-hand side, otherwise shifts."""

    def __init__(self, grammar):
        if not isinstance(grammar, CFG):
            raise TypeError("grammar must be a CFG")
        self._grammar = grammar

    def parse(self, tokens):
        tokens = _check_tokens(self._grammar, tokens)
        return iter(self._parse_all(tokens))

    def _parse_all(self, tokens):
        grammar = self._grammar
        # Empty productions would reduce forever on an empty stack, so they are not used for reduction.
        productions = [p for p in grammar.productions() if len(p.rhs()) > 0]
        stack = []
        pos = 0
        while True:
            reduced = True
            while reduced:
                reduced = False
                for prod in productions:
                    rhs = prod.rhs()
                    if _matches_top(stack, rhs):
                        n = len(rhs)
                        children = stack[len(stack) - n:]
                        del stack[len(stack) - n:]
                        stack.append(Tree(str(prod.lhs()), list(children)))
                        reduced = True
                        break
            if pos < len(tokens):
                stack.append(tokens[pos])
                pos += 1
            else:
                break
        start = str(grammar.start())
        if len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == start:
            return [stack[0]]
        return []
