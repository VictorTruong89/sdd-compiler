"""Exhaustive chart parser: returns every parse tree the grammar assigns to a token list."""

from lingora.grammar import CFG, Nonterminal
from lingora.tree import Tree


def _check_tokens(grammar, tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")
    known = grammar.terminals()
    for tok in tokens:
        if not isinstance(tok, str):
            raise TypeError("tokens must be str, got %r" % (tok,))
        if tok not in known:
            raise ValueError("token %r is not produced by any production of the grammar" % tok)
    return list(tokens)


class ChartParser:
    """Returns all trees (possibly none) for a token list; each tree root is the start symbol."""

    def __init__(self, grammar):
        if not isinstance(grammar, CFG):
            raise TypeError("grammar must be a CFG")
        self._grammar = grammar

    def parse(self, tokens):
        tokens = _check_tokens(self._grammar, tokens)
        return iter(self._parse_all(tokens))

    def _parse_all(self, tokens):
        grammar = self._grammar
        n = len(tokens)
        memo = {}
        in_progress = set()

        def trees(sym, i, j):
            key = (str(sym), i, j)
            if key in memo:
                return memo[key]
            if key in in_progress:
                return []  # cut cycles so that the enumeration terminates
            in_progress.add(key)
            result = []
            for prod in grammar.productions(lhs=sym):
                for children in match(prod.rhs(), 0, i, j):
                    result.append(Tree(str(sym), children))
            in_progress.discard(key)
            memo[key] = result
            return result

        def match(rhs, k, pos, end):
            if k == len(rhs):
                return [[]] if pos == end else []
            sym = rhs[k]
            out = []
            if isinstance(sym, Nonterminal):
                for mid in range(pos, end + 1):
                    subs = trees(sym, pos, mid)
                    if not subs:
                        continue
                    rests = match(rhs, k + 1, mid, end)
                    for sub in subs:
                        for rest in rests:
                            out.append([sub] + rest)
            else:
                if pos < end and tokens[pos] == sym:
                    for rest in match(rhs, k + 1, pos + 1, end):
                        out.append([tokens[pos]] + rest)
            return out

        return trees(grammar.start(), 0, n)
