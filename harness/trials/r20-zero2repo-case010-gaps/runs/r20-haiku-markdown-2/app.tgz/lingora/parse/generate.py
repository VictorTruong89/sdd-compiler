"""Enumerate the sentences a grammar derives, in production order, with optional bounds."""

from lingora.grammar import CFG, Nonterminal


def _generate_all(grammar, items, depth):
    if items:
        first, rest = items[0], items[1:]
        for frag1 in _generate_one(grammar, first, depth):
            for frag2 in _generate_all(grammar, rest, depth):
                yield frag1 + frag2
    else:
        yield []


def _generate_one(grammar, item, depth):
    if depth > 0:
        if isinstance(item, Nonterminal):
            for prod in grammar.productions(lhs=item):
                for frag in _generate_all(grammar, tuple(prod.rhs()), depth - 1):
                    yield frag
        else:
            yield [item]


def generate(grammar, start=None, depth=None, n=None):
    """Yield sentences (lists of str tokens) derived from ``start`` (default: the grammar's start symbol)."""
    if not isinstance(grammar, CFG):
        raise TypeError("grammar must be a CFG")
    if start is None:
        start = grammar.start()
    elif isinstance(start, str):
        start = Nonterminal(start)
    if depth is None:
        depth = float("inf")
    iterator = _generate_all(grammar, (start,), depth)
    if n is not None:
        return _take(iterator, n)
    return iterator


def _take(iterator, n):
    count = 0
    if n <= 0:
        return
    for item in iterator:
        yield item
        count += 1
        if count >= n:
            return
