"""Evaluation metrics: edit distance, Jaccard distance, accuracy, precision, recall, f-measure."""


def accuracy(reference, test):
    """Fraction of equal positions in two equal-length lists."""
    if isinstance(reference, str) or isinstance(test, str):
        raise TypeError("accuracy takes lists, not str")
    reference = list(reference)
    test = list(test)
    if len(reference) != len(test):
        raise ValueError("accuracy needs lists of equal length (%d != %d)" % (len(reference), len(test)))
    if not reference:
        raise ValueError("accuracy of two empty lists is undefined")
    return sum(1 for a, b in zip(reference, test) if a == b) / len(reference)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Levenshtein distance; with transpositions=True the unrestricted Damerau-Levenshtein distance."""
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("edit_distance takes two str arguments")
    if isinstance(substitution_cost, bool) or not isinstance(substitution_cost, (int, float)):
        raise TypeError("substitution_cost must be a number")
    if transpositions:
        return _damerau(s1, s2, substitution_cost)
    prev = [j for j in range(len(s2) + 1)]
    for i in range(1, len(s1) + 1):
        cur = [i] + [0] * len(s2)
        for j in range(1, len(s2) + 1):
            if s1[i - 1] == s2[j - 1]:
                sub = prev[j - 1]
            else:
                sub = prev[j - 1] + substitution_cost
            cur[j] = min(sub, prev[j] + 1, cur[j - 1] + 1)
        prev = cur
    return prev[len(s2)]


def _damerau(a, b, sub):
    inf = len(a) + len(b)
    da = {}
    d = [[0] * (len(b) + 2) for _ in range(len(a) + 2)]
    d[0][0] = inf
    for i in range(len(a) + 1):
        d[i + 1][0] = inf
        d[i + 1][1] = i
    for j in range(len(b) + 1):
        d[0][j + 1] = inf
        d[1][j + 1] = j
    for i in range(1, len(a) + 1):
        db = 0
        for j in range(1, len(b) + 1):
            i1 = da.get(b[j - 1], 0)
            j1 = db
            if a[i - 1] == b[j - 1]:
                cost = 0
                db = j
            else:
                cost = sub
            d[i + 1][j + 1] = min(
                d[i][j] + cost,
                d[i + 1][j] + 1,
                d[i][j + 1] + 1,
                d[i1][j1] + (i - i1 - 1) + 1 + (j - j1 - 1),
            )
        da[a[i - 1]] = i
    return d[len(a) + 1][len(b) + 1]


def jaccard_distance(label1, label2):
    """1 - |intersection| / |union|; two empty sets are at distance 0."""
    s1 = set(label1)
    s2 = set(label2)
    union = s1 | s2
    if not union:
        return 0.0
    return (len(union) - len(s1 & s2)) / len(union)


def _check_sets(reference, test):
    for name, value in (("reference", reference), ("test", test)):
        if not isinstance(value, (set, frozenset)):
            raise TypeError("%s must be a set or frozenset, not %s" % (name, type(value).__name__))


def precision(reference, test):
    """|reference & test| / |test|; None when test is empty."""
    _check_sets(reference, test)
    if not test:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    """|reference & test| / |reference|; None when reference is empty."""
    _check_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    """Weighted harmonic mean of precision and recall; None when either set is empty; 0 if either is 0."""
    _check_sets(reference, test)
    if not reference or not test:
        return None
    p = precision(reference, test)
    r = recall(reference, test)
    if p == 0 or r == 0:
        return 0.0
    return 1.0 / (alpha / p + (1 - alpha) / r)
