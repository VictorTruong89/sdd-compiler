"""Tweet-aware tokenizer: emoticons, URLs, hashtags and @-handles stay whole."""

import re

from lingora.tokenize.simple import _check_str

EMOTICON_PATTERN = (
    r"(?:[<>]?[:;=8][\-o\*\']?[\)\]\(\[dDpP/\:\}\{@\|\\]"
    r"|[\)\]\(\[dDpP/\:\}\{@\|\\][\-o\*\']?[:;=8][<>]?"
    r"|<3)"
)
EMOTICON_RE = re.compile(EMOTICON_PATTERN)

_HANDLE_RE = re.compile(r"(?<!\w)@[A-Za-z0-9_]{1,15}(?![A-Za-z0-9_])")
_LENGTH_RE = re.compile(r"([\s\S])\1{2,}")

_TOKEN_RE = re.compile(
    "|".join(
        [
            r"(?:%s)" % EMOTICON_PATTERN,
            r"""<[^>\s]+>""",
            r"""[\-]+>|<[\-]+""",
            r"""(?:https?://|www\.)\S+""",
            r"""(?:@[\w_]+)""",
            r"""(?:\#+[\w_]+[\w'_\-]*[\w_]+)""",
            r"""[\w.+\-]+@[\w\-]+\.(?:[\w\-]\.?)+[\w\-]""",
            r"""(?:[^\W\d_](?:[^\W\d_]|['\-_])+[^\W\d_])""",
            r"""(?:[+\-]?\d+[,/.:\-]\d+[+\-]?)""",
            r"""(?:[\w_]+)""",
            r"""(?:\.(?:\s*\.){1,})""",
            r"""(?:\S)""",
        ]
    ),
    re.UNICODE,
)


class TweetTokenizer:
    """Tokenizer for tweet-like text.

    preserve_case: keep case (default True); when False tokens are lowercased except emoticons.
    reduce_len: shorten runs of 3+ identical characters to exactly three (default False).
    strip_handles: remove @-handles before tokenizing (default False).
    """

    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self.preserve_case = bool(preserve_case)
        self.reduce_len = bool(reduce_len)
        self.strip_handles = bool(strip_handles)

    def tokenize(self, text):
        _check_str(text)
        if self.strip_handles:
            text = _HANDLE_RE.sub(" ", text)
        if self.reduce_len:
            text = _LENGTH_RE.sub(lambda m: m.group(1) * 3, text)
        words = _TOKEN_RE.findall(text)
        if not self.preserve_case:
            words = [w if EMOTICON_RE.fullmatch(w) else w.lower() for w in words]
        return words


def tweet_tokenize(text, **kwargs):
    return TweetTokenizer(**kwargs).tokenize(text)
