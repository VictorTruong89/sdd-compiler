"""Penn Treebank word tokenizer and LINGORA's recommended word tokenizer.

The Treebank rules implemented here follow the conventions listed in the
PRD (FP-01). The recommended tokenizer adds typographic quotes, dashes,
asterisks, runs of points and double hyphens on top of them.
"""

import re

from lingora.tokenize.simple import _check_str

_OPEN_QUOTE_CTX = r"(^|(?<=[\s(\[{<]))"

# Clitics and fused forms, applied on the raw (unpadded) text, case-insensitively.
_CLITIC_RES = [
    (re.compile(r"(?i)(\w)(n't)(?!\w)"), r"\1 \2"),
    (re.compile(r"(?i)(\w)('s|'m|'d|'ll|'re|'ve)(?!\w)"), r"\1 \2"),
]
_FUSED_RES = [
    (re.compile(r"(?i)\b(can)(not)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(d)('ye)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(gim)(me)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(gon)(na)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(got)(ta)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(lem)(me)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(more)('n)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(wan)(na)\b"), r"\1 \2"),
    (re.compile(r"(?i)(?<!\w)('t)(is|was)\b"), r"\1 \2"),
]
_BARE_APOS_RE = re.compile(r"(\w)'(?!\w)")

# Final point: split off only when it ends the text, optionally followed by closing quotes/brackets.
_FINAL_POINT_RE = re.compile(r"([^\s.])\.((?:[\"')\]}>])*)\s*$")
_ELLIPSIS_TREEBANK_RE = re.compile(r"\.\.\.")
_PUNCT_RE = re.compile(r"[;@#$%&?!()\[\]{}<>]")

_REC_UNICODE_QUOTES_RE = re.compile("[“”„‘’«»]")
_REC_DASH_STAR_RE = re.compile("[‒-―*]")
_REC_RUN_POINTS_RE = re.compile(r"\.{2,}")
_REC_DOUBLE_HYPHEN_RE = re.compile(r"--")

_DOUBLE_QUOTE_RE = re.compile('"')
_OPEN_DQ_RE = re.compile(_OPEN_QUOTE_CTX + '"')


def _treebank_core(text, recommended):
    # Final point first, on the raw text, so that closing quotes and brackets follow it.
    text = _FINAL_POINT_RE.sub(r"\1 . \2 ", text)

    if recommended:
        text = _REC_RUN_POINTS_RE.sub(lambda m: " %s " % m.group(0), text)
    else:
        text = _ELLIPSIS_TREEBANK_RE.sub(lambda m: " %s " % m.group(0), text)

    # Quotes: opening (start, after whitespace or an opening bracket) and closing.
    text = _OPEN_DQ_RE.sub(lambda m: m.group(1) + " `` ", text)
    text = _DOUBLE_QUOTE_RE.sub(" '' ", text)

    if recommended:
        text = _REC_UNICODE_QUOTES_RE.sub(lambda m: " %s " % m.group(0), text)
        text = _REC_DASH_STAR_RE.sub(lambda m: " %s " % m.group(0), text)

    for regex, repl in _CLITIC_RES:
        text = regex.sub(repl, text)
    for regex, repl in _FUSED_RES:
        text = regex.sub(repl, text)
    text = _BARE_APOS_RE.sub(r"\1 '", text)

    text = _PUNCT_RE.sub(lambda m: " %s " % m.group(0), text)

    if recommended:
        text = _REC_DOUBLE_HYPHEN_RE.sub(" -- ", text)

    return text.split()


class TreebankWordTokenizer:
    """Penn Treebank word tokenizer (FP-01)."""

    def tokenize(self, text):
        _check_str(text)
        return _treebank_core(text, recommended=False)


def treebank_tokenize(text):
    return TreebankWordTokenizer().tokenize(text)


def recommended_word_tokenize_line(text):
    """Recommended word tokenizer applied to one already-delimited line (no sentence split)."""
    _check_str(text)
    return _treebank_core(text, recommended=True)
