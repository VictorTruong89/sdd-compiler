"""Word/punctuation, whitespace, blank-line and regular-expression tokenizers."""

import re

_WORDPUNCT_RE = re.compile(r"\w+|[^\w\s]+")
_WHITESPACE_RE = re.compile(r"\S+")
_BLANKLINE_SEP_RE = re.compile(r"\s*\n\s*\n\s*")


class WordPunctTokenizer:
    """Maximal runs of word characters, or of non-word non-space characters."""

    def tokenize(self, text):
        return _check_str(text) and _WORDPUNCT_RE.findall(text)

    def span_tokenize(self, text):
        _check_str(text)
        for m in _WORDPUNCT_RE.finditer(text):
            yield (m.start(), m.end())


def wordpunct_tokenize(text):
    return WordPunctTokenizer().tokenize(text)


class WhitespaceTokenizer:
    """Maximal runs of non-whitespace characters."""

    def tokenize(self, text):
        _check_str(text)
        return text.split()

    def span_tokenize(self, text):
        _check_str(text)
        for m in _WHITESPACE_RE.finditer(text):
            yield (m.start(), m.end())


def blankline_tokenize(text):
    """Split text into segments separated by blank lines."""
    _check_str(text)
    return [seg for seg in _BLANKLINE_SEP_RE.split(text) if seg]


class RegexpTokenizer:
    """Token mode (default) returns the matches; gap mode returns the pieces between matches."""

    def __init__(self, pattern, gaps=False, discard_empty=True, flags=0):
        if not isinstance(pattern, str):
            raise TypeError("pattern must be a str")
        self.pattern = pattern
        self._re = re.compile(pattern, flags)
        self.gaps = bool(gaps)
        self.discard_empty = bool(discard_empty)

    def tokenize(self, text):
        _check_str(text)
        if self.gaps:
            pieces = []
            pos = 0
            for m in self._re.finditer(text):
                pieces.append(text[pos:m.start()])
                pos = m.end()
            pieces.append(text[pos:])
        else:
            pieces = [m.group(0) for m in self._re.finditer(text)]
        if self.discard_empty:
            pieces = [p for p in pieces if p]
        return pieces

    def span_tokenize(self, text):
        _check_str(text)
        if self.gaps:
            pos = 0
            spans = []
            for m in self._re.finditer(text):
                spans.append((pos, m.start()))
                pos = m.end()
            spans.append((pos, len(text)))
        else:
            spans = [(m.start(), m.end()) for m in self._re.finditer(text)]
        for s, e in spans:
            if self.discard_empty and s == e:
                continue
            yield (s, e)


def _check_str(text):
    if not isinstance(text, str):
        raise TypeError("text must be a str, not %s" % type(text).__name__)
    return True
