"""Tokenizers: words, punctuation, sentences, spans, whitespace, blank lines, regexps, tweets."""

from lingora.tokenize.simple import (
    RegexpTokenizer,
    WhitespaceTokenizer,
    WordPunctTokenizer,
    blankline_tokenize,
    wordpunct_tokenize,
)
from lingora.tokenize.treebank import (
    TreebankWordTokenizer,
    recommended_word_tokenize_line,
    treebank_tokenize,
)
from lingora.tokenize.punkt import load_parameters, sent_tokenize
from lingora.tokenize.tweet import TweetTokenizer, tweet_tokenize
from lingora.tokenize.simple import _check_str


def word_tokenize(text, language="english", preserve_line=False):
    """LINGORA's recommended word tokenizer.

    With preserve_line=False the text is first split into sentences with the
    Punkt model for ``language`` (raises LookupError when it is not visible).
    """
    _check_str(text)
    if preserve_line:
        return recommended_word_tokenize_line(text)
    sentences = sent_tokenize(text, language=language)
    tokens = []
    for sentence in sentences:
        tokens.extend(recommended_word_tokenize_line(sentence))
    return tokens


__all__ = [
    "RegexpTokenizer",
    "TreebankWordTokenizer",
    "TweetTokenizer",
    "WhitespaceTokenizer",
    "WordPunctTokenizer",
    "blankline_tokenize",
    "load_parameters",
    "sent_tokenize",
    "tweet_tokenize",
    "treebank_tokenize",
    "word_tokenize",
    "wordpunct_tokenize",
]
