"""Punkt sentence-boundary detection (Kiss and Strunk, 2006) driven by packaged parameters.

Parameters live in ``tokenizers/punkt_tab/<language>/`` on ``lingora.data.path``:
abbrev_types.txt, sent_starters.txt, collocations.tab and ortho_context.tab.
"""

import os
import re

from lingora import data
from lingora.tokenize.simple import _check_str

_ORTHO_UC_SENT = 2
_ORTHO_UC_INSIDE = 4
_ORTHO_UC_UNK = 8
_ORTHO_LC_SENT = 16
_ORTHO_LC_INSIDE = 32
_ORTHO_LC_UNK = 64

_NUMBER_TYPE_RE = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_LEAD_RE = re.compile(r"^[\"'(\[{<“‘«]+")
_TRAIL_RE = re.compile(r"[\"')\]}>»”’]+$")
_TOKEN_RE = re.compile(r"\S+")
_PARA_RE = re.compile(r"\n\s*\n")


class PunktParameters:
    """The packaged parameters of one language."""

    def __init__(self, abbrev_types, collocations, sent_starters, ortho_context):
        self.abbrev_types = set(abbrev_types)
        self.collocations = set(collocations)
        self.sent_starters = set(sent_starters)
        self.ortho_context = dict(ortho_context)


_CACHE = {}


def _read_lines(path):
    if not os.path.isfile(path):
        return []
    with open(path, encoding="utf-8") as fh:
        return [line.rstrip("\r\n") for line in fh if line.strip("\r\n") != ""]


def _model_dir(language):
    _check_str(language)
    return data.find(os.path.join("tokenizers", "punkt_tab", language))


def load_parameters(language="english"):
    """Load Punkt parameters; raises LookupError when the model is not visible."""
    directory = _model_dir(language)
    if not os.path.isdir(directory):
        raise LookupError("Punkt model %r is not a directory: %s" % (language, directory))
    if directory in _CACHE:
        return _CACHE[directory]
    abbrev = [line.strip() for line in _read_lines(os.path.join(directory, "abbrev_types.txt"))]
    starters = [line.strip() for line in _read_lines(os.path.join(directory, "sent_starters.txt"))]
    colloc = []
    for line in _read_lines(os.path.join(directory, "collocations.tab")):
        parts = line.split("\t")
        if len(parts) == 2:
            colloc.append((parts[0].strip(), parts[1].strip()))
    ortho = {}
    for line in _read_lines(os.path.join(directory, "ortho_context.tab")):
        parts = line.split("\t")
        if len(parts) == 2:
            try:
                ortho[parts[0].strip()] = int(parts[1].strip())
            except ValueError:
                continue
    params = PunktParameters(abbrev, colloc, starters, ortho)
    _CACHE[directory] = params
    return params


def _get_type(word):
    return _NUMBER_TYPE_RE.sub("##number##", word.lower()) if _NUMBER_TYPE_RE.match(word) else word.lower()


class _Tok:
    __slots__ = ("start", "end", "raw", "type", "period_final", "ellipsis",
                 "sent_end_punct", "abbr", "first_upper", "first_lower", "parastart")


def _annotate(text):
    """Return token records with offsets and punctuation / case features."""
    toks = []
    prev_end = 0
    for m in _TOKEN_RE.finditer(text):
        tok = _Tok()
        tok.start, tok.end, tok.raw = m.start(), m.end(), m.group(0)
        gap = text[prev_end:m.start()]
        tok.parastart = bool(_PARA_RE.search(gap)) if toks else False
        prev_end = m.end()

        core = _LEAD_RE.sub("", tok.raw)
        core = _TRAIL_RE.sub("", core)
        tok.sent_end_punct = core.endswith("?") or core.endswith("!")
        tok.period_final = core.endswith(".")
        tok.ellipsis = core.endswith("..")
        word = core.rstrip(".?!")
        tok.type = _get_type(word)
        is_initial = len(word) == 1 and word.isalpha()
        tok.abbr = is_initial
        letters = [c for c in word if c.isalpha()]
        tok.first_upper = bool(letters) and word[:1].isupper() if word else False
        tok.first_lower = bool(word) and word[:1].islower()
        toks.append(tok)
    return toks


def _ortho_break(params, nxt):
    """Second-pass decision for an abbreviation followed by token ``nxt``."""
    orth = params.ortho_context.get(nxt.type, 0)
    if orth & _ORTHO_UC_SENT:
        return True
    if nxt.type in params.sent_starters:
        return True
    if orth & _ORTHO_UC_INSIDE:
        return False
    if orth & (_ORTHO_LC_SENT | _ORTHO_LC_INSIDE | _ORTHO_LC_UNK):
        return False
    return True


def _sentence_breaks(text, params):
    """Return the list of token indexes after which a sentence ends."""
    toks = _annotate(text)
    n = len(toks)
    breaks = []
    for i, tok in enumerate(toks):
        nxt = toks[i + 1] if i + 1 < n else None
        if i == n - 1:
            breaks.append(i)
            break
        if tok.sent_end_punct and not tok.period_final:
            breaks.append(i)
            continue
        if not tok.period_final:
            continue
        if nxt is not None and nxt.parastart:
            breaks.append(i)
            continue
        if not (tok.abbr or tok.ellipsis or tok.type in params.abbrev_types):
            breaks.append(i)
            continue
        # Second pass for abbreviations and ellipses.
        base = tok.type
        if tok.type in params.abbrev_types or tok.abbr:
            if nxt is not None and (base, nxt.type) in params.collocations:
                continue
        if nxt is None:
            breaks.append(i)
            continue
        if nxt.first_lower:
            continue
        if not nxt.first_upper and not nxt.first_lower:
            # Non-alphabetic start (digits, symbols): treat as a sentence start.
            breaks.append(i)
            continue
        if _ortho_break(params, nxt):
            breaks.append(i)
    return toks, breaks


def sent_tokenize(text, language="english"):
    """Split ``text`` into sentences; each sentence is its original text without the trailing whitespace."""
    _check_str(text)
    params = load_parameters(language)
    if not text.strip():
        return []
    toks, breaks = _sentence_breaks(text, params)
    sentences = []
    first = 0
    for idx in breaks:
        if idx < first:
            continue
        start = toks[first].start
        end = toks[idx].end
        sentences.append(text[start:end])
        first = idx + 1
    return sentences
