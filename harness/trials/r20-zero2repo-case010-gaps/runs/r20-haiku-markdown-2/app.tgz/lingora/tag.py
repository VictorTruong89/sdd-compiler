"""Part-of-speech taggers: sequential taggers (default, unigram, regexp) with backoff,
and the recommended averaged-perceptron tagger ``pos_tag`` (English and Russian)."""

import json
import os
import re
from collections import Counter, defaultdict

from lingora import data


def _check_token_list(tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str, not %s" % type(tokens).__name__)
    for tok in tokens:
        if not isinstance(tok, str):
            raise TypeError("tokens must be str, got %r" % (tok,))
    return list(tokens)


class TaggerI:
    """Base class: ``tag(tokens)`` returns a list of ``(token, tag-or-None)`` pairs."""

    def __init__(self, backoff=None):
        if backoff is not None and not isinstance(backoff, TaggerI):
            raise TypeError("backoff must be a tagger or None")
        self._backoff = backoff

    def backoff(self):
        return self._backoff

    def choose_tag(self, tokens, index):
        raise NotImplementedError

    def tag(self, tokens):
        tokens = _check_token_list(tokens)
        tags = [self.choose_tag(tokens, i) for i in range(len(tokens))]
        if self._backoff is not None:
            fallback = self._backoff.tag(tokens)
            tags = [t if t is not None else fb[1] for t, fb in zip(tags, fallback)]
        return list(zip(tokens, tags))


class DefaultTagger(TaggerI):
    """Assigns the same tag to every token."""

    def __init__(self, tag):
        super().__init__(None)
        self._tag = tag

    def choose_tag(self, tokens, index):
        return self._tag


class UnigramTagger(TaggerI):
    """Each word gets the tag it most often had in training; unseen words get no tag."""

    def __init__(self, train=None, model=None, backoff=None):
        super().__init__(backoff)
        self._model = {}
        if model is not None:
            self._model = dict(model)
        if train is not None:
            counts = defaultdict(Counter)
            for sentence in train:
                for pair in sentence:
                    word, tag = pair
                    counts[word][tag] += 1
            for word, tagcounts in counts.items():
                best = sorted(tagcounts.items(), key=lambda kv: (-kv[1], str(kv[0])))[0][0]
                self._model[word] = best

    def choose_tag(self, tokens, index):
        return self._model.get(tokens[index])


class RegexpTagger(TaggerI):
    """Rules are tried in order; the first pattern that matches at the token's first character gives the tag."""

    def __init__(self, regexps, backoff=None):
        super().__init__(backoff)
        self._rules = []
        for pattern, tag in regexps:
            self._rules.append((re.compile(pattern), tag))

    def choose_tag(self, tokens, index):
        token = tokens[index]
        for regex, tag in self._rules:
            if regex.match(token):
                return tag
        return None


# ---------------------------------------------------------------------------
# Recommended averaged-perceptron tagger (textblob-aptagger algorithm).

_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]

_RUS_TO_UNIVERSAL = {
    "S": "NOUN",
    "A": "ADJ",
    "ANUM": "ADJ",
    "NUM": "NUM",
    "V": "VERB",
    "ADV": "ADV",
    "ADVPRO": "ADV",
    "PR": "ADP",
    "CONJ": "CCONJ",
    "PART": "PART",
    "INTJ": "INTJ",
    "SPRO": "PRON",
    "APRO": "DET",
    "PRO": "PRON",
}


class _Perceptron:
    def __init__(self, weights, classes):
        self.weights = weights
        self.classes = classes

    def predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            if value == 0 or feat not in self.weights:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        if not self.classes:
            raise LookupError("perceptron model has no classes")
        return max(self.classes, key=lambda label: (scores[label], label))


class _AveragedPerceptronModel:
    def __init__(self, weights, tagdict, classes):
        self.model = _Perceptron(weights, classes)
        self.tagdict = tagdict

    @staticmethod
    def normalize(word):
        if "-" in word and word[0] != "-":
            return "!HYPHEN"
        if word.isdigit() and len(word) == 4:
            return "!YEAR"
        if word and word[0].isdigit():
            return "!DIGITS"
        return word.lower()

    @staticmethod
    def _features(i, word, context, prev, prev2):
        feats = defaultdict(int)

        def add(name, *args):
            feats[" ".join((name,) + tuple(args))] += 1

        i += len(_START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return feats

    def tag(self, tokens):
        prev, prev2 = _START
        output = []
        context = _START + [self.normalize(w) for w in tokens] + _END
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                features = self._features(i, word, context, prev, prev2)
                tag = self.model.predict(features)
            output.append((word, tag))
            prev2 = prev
            prev = tag
        return output


_MODEL_CACHE = {}


def _load_perceptron(lang):
    resource = os.path.join("taggers", "averaged_perceptron_tagger_%s" % lang)
    directory = data.find(resource)
    if not os.path.isdir(directory):
        raise LookupError("averaged perceptron tagger resource is not a directory: %s" % directory)
    if directory in _MODEL_CACHE:
        return _MODEL_CACHE[directory]
    base = os.path.join(directory, "averaged_perceptron_tagger_%s" % lang)
    try:
        with open(base + ".weights.json", encoding="utf-8") as fh:
            weights = json.load(fh)
        with open(base + ".tagdict.json", encoding="utf-8") as fh:
            tagdict = json.load(fh)
        with open(base + ".classes.json", encoding="utf-8") as fh:
            classes = json.load(fh)
    except FileNotFoundError as exc:
        raise LookupError("averaged perceptron tagger files missing: %s" % exc)
    model = _AveragedPerceptronModel(weights, tagdict, classes)
    _MODEL_CACHE[directory] = model
    return model


def _load_universal_map():
    directory = data.find(os.path.join("taggers", "universal_tagset"))
    path = os.path.join(directory, "en-ptb.map")
    if not os.path.isfile(path):
        raise LookupError("universal tagset table en-ptb.map not found")
    mapping = {}
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.rstrip("\r\n")
            if not line:
                continue
            parts = line.split("\t")
            if len(parts) >= 2:
                mapping[parts[0]] = parts[1]
    return mapping


def _map_russian(tag):
    if tag is None:
        return None
    part = tag.split("=", 1)[0]
    return _RUS_TO_UNIVERSAL.get(part, "X")


def pos_tag(tokens, tagset=None, lang="eng"):
    """Tag a token list with the recommended averaged-perceptron tagger.

    lang: 'eng' (Penn Treebank tags) or 'rus' (RNC tags). tagset: None (native) or 'universal'.
    Raises when the tokens are not a list of str, the language is unsupported, the
    resource is missing, or the universal table is needed but not visible.
    """
    tokens = _check_token_list(tokens)
    if lang not in ("eng", "rus"):
        raise ValueError("unsupported language for pos_tag: %r" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("tagset must be None or 'universal', not %r" % (tagset,))
    model = _load_perceptron(lang)
    universal = None
    if tagset == "universal" and lang == "eng":
        universal = _load_universal_map()
    tagged = model.tag(tokens)
    if tagset == "universal":
        if lang == "eng":
            tagged = [(w, universal.get(t, "X")) for w, t in tagged]
        else:
            tagged = [(w, _map_russian(t)) for w, t in tagged]
    return tagged
