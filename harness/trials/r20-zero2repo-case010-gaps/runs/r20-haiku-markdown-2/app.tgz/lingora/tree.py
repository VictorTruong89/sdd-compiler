"""Constituent trees: a label plus an ordered list of children (subtrees or leaves)."""

import re


class Tree:
    """A labelled ordered tree. Children are subtrees or leaves (str, or tuples such as (token, tag))."""

    __slots__ = ("_label", "_children")

    def __init__(self, label, children):
        if isinstance(children, str):
            raise TypeError("Tree children must be a list, not a str")
        if not isinstance(children, list):
            raise TypeError("Tree children must be a list, not %s" % type(children).__name__)
        self._label = label
        self._children = list(children)

    @classmethod
    def fromstring(cls, s):
        """Build a tree from bracketed tree text such as ``(S (NP the dog) (VP barks))``."""
        if not isinstance(s, str):
            raise TypeError("bracketed tree text must be a str")
        tokens = re.findall(r"\(|\)|[^\s()]+", s)
        pos = [0]

        def parse_node():
            if pos[0] >= len(tokens) or tokens[pos[0]] != "(":
                raise ValueError("expected '(' in bracketed tree text: %r" % s)
            pos[0] += 1
            if pos[0] >= len(tokens) or tokens[pos[0]] in ("(", ")"):
                raise ValueError("missing label in bracketed tree text: %r" % s)
            label = tokens[pos[0]]
            pos[0] += 1
            children = []
            while pos[0] < len(tokens) and tokens[pos[0]] != ")":
                if tokens[pos[0]] == "(":
                    children.append(parse_node())
                else:
                    children.append(tokens[pos[0]])
                    pos[0] += 1
            if pos[0] >= len(tokens):
                raise ValueError("unbalanced parentheses in bracketed tree text: %r" % s)
            pos[0] += 1  # consume ')'
            return cls(label, children)

        tree = parse_node()
        if pos[0] != len(tokens):
            raise ValueError("trailing text after tree in: %r" % s)
        return tree

    def label(self):
        return self._label

    def leaves(self):
        out = []
        for child in self._children:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def __iter__(self):
        return iter(self._children)

    def __len__(self):
        return len(self._children)

    def __getitem__(self, index):
        return self._children[index]

    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __ne__(self, other):
        result = self.__eq__(other)
        return result if result is NotImplemented else not result

    def __hash__(self):
        return hash((self._label, tuple(self._children)))

    def __repr__(self):
        return "Tree(%r, %r)" % (self._label, self._children)

    def __str__(self):
        return self.pformat(margin=10**9)

    def _leaf_text(self, leaf):
        if isinstance(leaf, tuple):
            return "/".join(str(x) for x in leaf)
        return str(leaf)

    def _flat(self):
        parts = []
        for child in self._children:
            if isinstance(child, Tree):
                parts.append(child._flat())
            else:
                parts.append(self._leaf_text(child))
        return "(%s%s)" % (self._label, "".join(" " + p for p in parts))

    def pformat(self, margin=70):
        """Pretty-printed text: every label and leaf, in pre-order. Lines are broken past ``margin``."""
        flat = self._flat()
        if len(flat) <= margin:
            return flat
        return self._pformat_indented(0, margin)

    def _pformat_indented(self, indent, margin):
        pad = " " * indent
        flat = self._flat()
        if len(flat) + indent <= margin or all(not isinstance(c, Tree) for c in self._children):
            return pad + flat
        lines = [pad + "(" + str(self._label)]
        for child in self._children:
            if isinstance(child, Tree):
                lines.append(child._pformat_indented(indent + 2, margin))
            else:
                lines.append(" " * (indent + 2) + self._leaf_text(child))
        lines[-1] += ")"
        return "\n".join(lines)
