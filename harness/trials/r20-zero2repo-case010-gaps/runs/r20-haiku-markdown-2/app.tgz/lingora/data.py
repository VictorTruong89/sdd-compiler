"""Locate packaged resources (Punkt models, taggers, stopwords, ...).

``path`` is a mutable list of directories searched in order. Its initial
contents come from the ``LINGORA_DATA`` environment variable (os.pathsep
separated) and the conventional per-user and system locations below.
"""

import os

_DEFAULT_DIRS = [
    os.path.join(os.path.expanduser("~"), "lingora_data"),
    os.path.join(os.path.expanduser("~"), ".lingora", "data"),
    os.path.join(os.sep, "usr", "local", "share", "lingora"),
    os.path.join(os.sep, "usr", "share", "lingora"),
]


def _initial_paths():
    env = os.environ.get("LINGORA_DATA", "")
    dirs = [d for d in env.split(os.pathsep) if d]
    dirs.extend(_DEFAULT_DIRS)
    return dirs


path = _initial_paths()


def find(resource):
    """Return the absolute location of ``resource`` inside a directory on ``path``.

    Raises LookupError when no listed directory holds the resource.
    """
    for directory in list(path):
        candidate = os.path.join(directory, resource)
        if os.path.exists(candidate):
            return candidate
    raise LookupError(
        "resource %r not found in data.path %r" % (resource, list(path))
    )


def exists(resource):
    """True when ``resource`` can be found on ``path``."""
    try:
        find(resource)
    except LookupError:
        return False
    return True
