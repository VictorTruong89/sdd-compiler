"""Naive Bayes and decision-tree classifiers over labelled featuresets, and an accuracy helper."""

import math
from collections import Counter, defaultdict


def _check_labeled(labeled):
    if isinstance(labeled, (str, bytes)) or not isinstance(labeled, (list, tuple)):
        raise TypeError("labeled featuresets must be a list of (featureset, label) pairs")
    out = []
    for pair in labeled:
        if not (isinstance(pair, tuple) and len(pair) == 2):
            raise TypeError("each item must be a (featureset, label) pair")
        fs, label = pair
        if not isinstance(fs, dict):
            raise TypeError("a featureset must be a dict")
        out.append((fs, label))
    return out


class ProbDist:
    """A probability distribution over labels."""

    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def samples(self):
        return list(self._probs.keys())

    def max(self):
        return max(self._probs, key=lambda k: self._probs[k])

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._probs)


class NaiveBayesClassifier:
    """Naive Bayes with ELE-style smoothing so unseen value/label combinations get non-zero probability."""

    SMOOTH = 0.5

    def __init__(self, label_order, prior, feature_counts, feature_values, label_feature_totals):
        self._labels = list(label_order)
        self._prior = prior  # label -> prob
        self._counts = feature_counts  # (label, fname) -> Counter(value -> count)
        self._values = feature_values  # fname -> set of values
        self._totals = label_feature_totals  # (label, fname) -> count of examples having fname

    @classmethod
    def train(cls, labeled_featuresets):
        data = _check_labeled(labeled_featuresets)
        if not data:
            raise ValueError("cannot train a Naive Bayes classifier on an empty list")
        label_order = []
        label_counts = Counter()
        feature_values = defaultdict(set)
        feature_counts = defaultdict(Counter)
        totals = Counter()
        for fs, label in data:
            if label not in label_counts:
                label_order.append(label)
            label_counts[label] += 1
            for fname, value in fs.items():
                feature_values[fname].add(value)
                feature_counts[(label, fname)][value] += 1
                totals[(label, fname)] += 1
        n = len(data)
        k = len(label_order)
        s = cls.SMOOTH
        prior = {lab: (label_counts[lab] + s) / (n + s * k) for lab in label_order}
        return cls(label_order, prior, feature_counts, feature_values, totals)

    def labels(self):
        return list(self._labels)

    def _log_scores(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("a featureset must be a dict")
        s = self.SMOOTH
        scores = {}
        for lab in self._labels:
            total = math.log(self._prior[lab])
            for fname, value in featureset.items():
                values = self._values.get(fname)
                if not values or value not in values:
                    continue  # a value never seen in training carries no evidence
                nvals = len(values) + 1
                count = self._counts[(lab, fname)].get(value, 0) if (lab, fname) in self._counts else 0
                denom_total = self._totals.get((lab, fname), 0)
                p = (count + s) / (denom_total + s * nvals)
                total += math.log(p)
            scores[lab] = total
        return scores

    def prob_classify(self, featureset):
        scores = self._log_scores(featureset)
        top = max(scores.values())
        exps = {lab: math.exp(v - top) for lab, v in scores.items()}
        z = sum(exps.values())
        return ProbDist({lab: exps[lab] / z for lab in self._labels})

    def classify(self, featureset):
        scores = self._log_scores(featureset)
        best = None
        for lab in self._labels:
            if best is None or scores[lab] > scores[best]:
                best = lab
        return best


class _Leaf:
    __slots__ = ("label",)

    def __init__(self, label):
        self.label = label


class _Node:
    __slots__ = ("feature", "children", "default")

    def __init__(self, feature, children, default):
        self.feature = feature
        self.children = children
        self.default = default


def _entropy(counter, total):
    h = 0.0
    for c in counter.values():
        if c:
            p = c / total
            h -= p * math.log2(p)
    return h


def _majority(examples):
    counts = Counter()
    first = {}
    for i, (_, lab) in enumerate(examples):
        counts[lab] += 1
        first.setdefault(lab, i)
    return max(counts, key=lambda lab: (counts[lab], -first[lab]))


def _build_tree(examples, features):
    labels = Counter(lab for _, lab in examples)
    majority = _majority(examples)
    if len(labels) == 1:
        return _Leaf(majority)
    if not features:
        return _Leaf(majority)
    n = len(examples)
    base = _entropy(labels, n)
    best_feature = None
    best_gain = 1e-12
    best_groups = None
    for f in features:
        groups = defaultdict(list)
        for fs, lab in examples:
            groups[fs.get(f)].append((fs, lab))
        if len(groups) < 2:
            continue
        cond = 0.0
        for g in groups.values():
            gl = Counter(lab for _, lab in g)
            cond += len(g) / n * _entropy(gl, len(g))
        gain = base - cond
        if gain > best_gain:
            best_gain = gain
            best_feature = f
            best_groups = groups
    if best_feature is None:
        return _Leaf(majority)
    rest = [f for f in features if f != best_feature]
    children = {v: _build_tree(g, rest) for v, g in best_groups.items()}
    return _Node(best_feature, children, majority)


class DecisionTreeClassifier:
    """Tree of feature tests chosen by information gain; leaves hold the majority training label."""

    def __init__(self, root):
        self._root = root

    @classmethod
    def train(cls, labeled_featuresets):
        data = _check_labeled(labeled_featuresets)
        if not data:
            raise ValueError("cannot train a decision tree on an empty list")
        features = []
        seen = set()
        for fs, _ in data:
            for f in fs:
                if f not in seen:
                    seen.add(f)
                    features.append(f)
        return cls(_build_tree(data, features))

    def classify(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("a featureset must be a dict")
        node = self._root
        while isinstance(node, _Node):
            value = featureset.get(node.feature)
            if value in node.children:
                node = node.children[value]
            else:
                return node.default
        return node.label


def accuracy(classifier, gold):
    """Fraction of (featureset, label) pairs whose label the classifier gets right."""
    data = _check_labeled(gold)
    if not data:
        raise ValueError("accuracy of an empty gold list is undefined")
    correct = sum(1 for fs, lab in data if classifier.classify(fs) == lab)
    return correct / len(data)
