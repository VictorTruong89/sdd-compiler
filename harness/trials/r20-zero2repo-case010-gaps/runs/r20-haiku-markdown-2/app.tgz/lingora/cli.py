"""Command-line group. ``tokenize`` applies the recommended word tokenizer to each stdin line.

Usage: ``python -m lingora tokenize [--language LANG] [--delimiter DELIM]``
The tokenize command needs the Punkt model for the requested language; without it the
command writes an error to standard error, writes no token line, and exits with status 1.
"""

import sys

from lingora.tokenize import word_tokenize

USAGE = """Usage: lingora tokenize [--language LANG] [--delimiter DELIM]

Reads UTF-8 text from standard input and writes one line per input line:
the recommended word tokenizer's tokens (with sentence splitting), joined by DELIM.
Options:
  --language LANG    Punkt model language directory name (default: english)
  --delimiter DELIM  token separator (default: a single space)
"""


class _Group:
    """Minimal command group with a ``main(args=..., standalone_mode=...)`` entry."""

    commands = ("tokenize",)

    def main(self, args=None, standalone_mode=True):
        if args is None:
            args = sys.argv[1:]
        code = self._run(list(args))
        if standalone_mode:
            raise SystemExit(code)
        return code

    def _run(self, args):
        if not args or args[0] in ("-h", "--help", "help"):
            sys.stdout.write(USAGE)
            return 0
        command = args[0]
        if command not in self.commands:
            sys.stderr.write("lingora: unknown command %r\n" % command)
            return 2
        if command == "tokenize":
            return self._tokenize(args[1:])
        return 2

    @staticmethod
    def _parse_options(args, names):
        values = {}
        i = 0
        while i < len(args):
            arg = args[i]
            if "=" in arg and arg.split("=", 1)[0] in names:
                key, val = arg.split("=", 1)
                values[names[key]] = val
                i += 1
                continue
            if arg in names:
                if i + 1 >= len(args):
                    raise ValueError("option %s needs a value" % arg)
                values[names[arg]] = args[i + 1]
                i += 2
                continue
            raise ValueError("unexpected argument %r" % arg)
        return values

    def _tokenize(self, args):
        names = {"--language": "language", "--delimiter": "delimiter", "-l": "language", "-d": "delimiter"}
        try:
            opts = self._parse_options(args, names)
        except ValueError as exc:
            sys.stderr.write("lingora tokenize: %s\n" % exc)
            return 2
        language = opts.get("language", "english")
        delimiter = opts.get("delimiter", " ")
        text = sys.stdin.read()
        for line in text.splitlines():
            try:
                tokens = word_tokenize(line, language=language, preserve_line=False)
            except Exception as exc:  # noqa: BLE001 - reported as a failure status
                sys.stderr.write("lingora tokenize: %s\n" % exc)
                return 1
            sys.stdout.write(delimiter.join(tokens) + "\n")
        sys.stdout.flush()
        return 0


cli = _Group()


def main(argv=None):
    return cli.main(args=argv if argv is not None else sys.argv[1:], standalone_mode=True)
