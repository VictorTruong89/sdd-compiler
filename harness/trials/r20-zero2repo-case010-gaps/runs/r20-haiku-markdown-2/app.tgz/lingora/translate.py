"""Sentence-level BLEU (Papineni et al., 2002) over token lists."""

import math
from collections import Counter


class SmoothingFunction:
    """Smoothing functions for bleu(). Each takes the list of (numerator, denominator) per order and
    returns a list of smoothed precisions."""

    @staticmethod
    def method0(pairs):
        return [(num / den if den else 0.0) for num, den in pairs]

    @staticmethod
    def method1(pairs, epsilon=0.1):
        out = []
        for num, den in pairs:
            if num == 0:
                out.append(epsilon / den if den else 0.0)
            else:
                out.append(num / den)
        return out

    @staticmethod
    def method2(pairs):
        return [(num + 1) / (den + 1) for num, den in pairs]

    def __call__(self, pairs):
        return self.method0(pairs)


def _ngrams(tokens, n):
    return Counter(tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1))


def _check_tokens(seq, what):
    if isinstance(seq, str) or not isinstance(seq, (list, tuple)):
        raise TypeError("%s must be a token list" % what)
    for tok in seq:
        if not isinstance(tok, str):
            raise TypeError("tokens in %s must be str" % what)
    return list(seq)


def bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):
    """Sentence BLEU of ``hypothesis`` against one or more ``references`` (token lists).

    weights: one weight per n-gram order, starting from unigrams.
    smoothing_function: None (default, unsmoothed) or a callable such as
    ``SmoothingFunction().method1`` (see SmoothingFunction).
    """
    if isinstance(references, str) or not isinstance(references, (list, tuple)):
        raise TypeError("references must be a list of token lists")
    refs = [_check_tokens(r, "references") for r in references]
    hyp = _check_tokens(hypothesis, "hypothesis")
    if not refs:
        raise ValueError("at least one reference is required")
    weights = list(weights)
    for w in weights:
        if isinstance(w, bool) or not isinstance(w, (int, float)):
            raise TypeError("weights must be numbers")
    if not weights:
        raise ValueError("at least one weight is required")

    pairs = []
    for n in range(1, len(weights) + 1):
        cand = _ngrams(hyp, n)
        total = sum(cand.values())
        max_ref = Counter()
        for r in refs:
            for gram, count in _ngrams(r, n).items():
                if count > max_ref[gram]:
                    max_ref[gram] = count
        clipped = sum(min(count, max_ref[gram]) for gram, count in cand.items())
        pairs.append((clipped, max(1, total)))

    if smoothing_function is None:
        precisions = SmoothingFunction.method0(pairs)
    else:
        precisions = list(smoothing_function(pairs))

    hyp_len = len(hyp)
    if hyp_len == 0:
        return 0.0
    for w, p in zip(weights, precisions):
        if w > 0 and p <= 0:
            return 0.0

    ref_len = min((len(r) for r in refs), key=lambda rl: (abs(rl - hyp_len), rl))
    if hyp_len > ref_len:
        bp = 1.0
    else:
        bp = math.exp(1 - ref_len / hyp_len)

    log_sum = math.fsum(w * math.log(p) for w, p in zip(weights, precisions) if w > 0)
    return bp * math.exp(log_sum)
