"""Regular-expression chunk parser over tagged tokens (chunk and chink rules, cascading clauses)."""

import os
import re

from lingora import data
from lingora.tree import Tree

SENTENCE_LABEL = "S"

_CLAUSE_RE = re.compile(r"^([A-Za-z_][\w\-.]*)\s*:\s*(.*)$")


def _strip_comment(line):
    """Remove a '#' comment that is not inside angle brackets or braces."""
    depth = 0
    for i, ch in enumerate(line):
        if ch == "<":
            depth += 1
        elif ch == ">":
            depth = max(0, depth - 1)
        elif ch == "#" and depth == 0:
            return line[:i]
    return line


def _tag_pattern_to_regex(tag_pattern):
    """Turn a tag pattern such as ``<DT>?<JJ>*<NN.*>+`` into a regex over ``<tag>`` strings."""
    out = []
    i = 0
    n = len(tag_pattern)
    while i < n:
        ch = tag_pattern[i]
        if ch.isspace():
            i += 1
            continue
        if ch != "<":
            raise ValueError("expected '<' in tag pattern at %r" % tag_pattern[i:])
        j = tag_pattern.find(">", i + 1)
        if j < 0:
            raise ValueError("unclosed '<' in tag pattern %r" % tag_pattern)
        content = tag_pattern[i + 1:j]
        content_re = _content_to_regex(content)
        i = j + 1
        quant = ""
        if i < n and tag_pattern[i] in "?*+":
            quant = tag_pattern[i]
            i += 1
        elif i < n and tag_pattern[i] == "{":
            k = tag_pattern.find("}", i)
            if k < 0:
                raise ValueError("unclosed '{' in tag pattern %r" % tag_pattern)
            body = tag_pattern[i + 1:k]
            if not re.fullmatch(r"\d*,?\d*", body) or body in ("", ","):
                raise ValueError("bad repeat count {%s} in tag pattern" % body)
            if "," in body:
                lo, hi = body.split(",", 1)
                quant = "{%s,%s}" % (lo or "0", hi)
            else:
                quant = "{%s}" % body
            i = k + 1
        out.append("(?:<(?:%s)>)%s" % (content_re, quant))
    return "".join(out)


def _content_to_regex(content):
    res = []
    i = 0
    while i < len(content):
        ch = content[i]
        if ch == "\\" and i + 1 < len(content):
            res.append(content[i:i + 2])
            i += 2
            continue
        if ch == ".":
            res.append("[^<>]")
        elif ch in "<>":
            raise ValueError("'<' and '>' are not allowed inside a tag element")
        else:
            res.append(ch)
        i += 1
    return "".join(res)


class _Clause:
    def __init__(self, label):
        self.label = label
        self.rules = []  # list of (kind, compiled regex) with kind in ('chunk', 'chink')


def _parse_grammar(grammar):
    clauses = []
    current = None
    for raw in grammar.splitlines():
        line = _strip_comment(raw).strip()
        if not line:
            continue
        m = _CLAUSE_RE.match(line)
        if m and not line.startswith("{") and not line.startswith("}"):
            current = _Clause(m.group(1))
            clauses.append(current)
            rest = m.group(2).strip()
        else:
            if current is None:
                raise ValueError("chunk grammar pattern before any clause label: %r" % raw)
            rest = line
        for kind, body in _split_rules(rest):
            current.rules.append((kind, re.compile(_tag_pattern_to_regex(body))))
    if not clauses:
        raise ValueError("chunk grammar has no clauses")
    for clause in clauses:
        if not clause.rules:
            raise ValueError("clause %r has no patterns" % clause.label)
    return clauses


def _split_rules(text):
    rules = []
    i = 0
    n = len(text)
    while i < n:
        ch = text[i]
        if ch.isspace():
            i += 1
        elif ch == "{":
            j = text.find("}", i + 1)
            if j < 0:
                raise ValueError("unclosed '{' in chunk grammar: %r" % text)
            rules.append(("chunk", text[i + 1:j]))
            i = j + 1
        elif ch == "}":
            j = text.find("{", i + 1)
            if j < 0:
                raise ValueError("unclosed '}' in chink rule: %r" % text)
            rules.append(("chink", text[i + 1:j]))
            i = j + 1
        else:
            raise ValueError("unexpected text in chunk grammar: %r" % text[i:])
    return rules


def _unit_tag(item):
    if isinstance(item, Tree):
        return item.label()
    tag = item[1]
    return "" if tag is None else str(tag)


def _find_matches(regex, tags):
    """Non-overlapping, left-to-right matches over unit tags; returns (start, end) unit index pairs."""
    text = "".join("<%s>" % t for t in tags)
    starts = {}
    pos = 0
    for idx, t in enumerate(tags):
        starts[pos] = idx
        pos += len(t) + 2
    ends = {}
    pos = 0
    for idx, t in enumerate(tags):
        pos += len(t) + 2
        ends[pos] = idx + 1
    spans = []
    for m in regex.finditer(text):
        s, e = m.start(), m.end()
        if e == s:
            continue
        if s in starts and e in ends:
            spans.append((starts[s], ends[e]))
    return spans


class RegexpParser:
    """Chunk parser built from a chunk grammar text."""

    def __init__(self, grammar):
        if not isinstance(grammar, str):
            raise TypeError("grammar must be a str")
        self._clauses = _parse_grammar(grammar)

    def parse(self, tagged):
        if isinstance(tagged, str) or not isinstance(tagged, (list, tuple)):
            raise TypeError("tagged must be a list of (token, tag) pairs")
        items = []
        for pair in tagged:
            if not (isinstance(pair, tuple) and len(pair) == 2):
                raise TypeError("tagged must hold (token, tag) pairs, got %r" % (pair,))
            items.append(pair)
        for clause in self._clauses:
            items = self._apply_clause(clause, items)
        return Tree(SENTENCE_LABEL, items)

    def _apply_clause(self, clause, items):
        own = set()  # ids of chunks built during this clause
        for kind, regex in clause.rules:
            if kind == "chunk":
                items = self._apply_chunk(clause.label, regex, items, own)
            else:
                items = self._apply_chink(clause.label, regex, items, own)
        return items

    def _apply_chunk(self, label, regex, items, own):
        # Runs of matchable units: tokens and earlier-clause chunks; this clause's chunks are blocking.
        new_items = []
        run = []  # list of indexes into items
        result_runs = []

        def flush():
            if run:
                tags = [_unit_tag(items[k]) for k in run]
                for s, e in _find_matches(regex, tags):
                    result_runs.append((run[s], run[e - 1] + 1))

        for idx, item in enumerate(items):
            if isinstance(item, Tree) and id(item) in own:
                flush()
                run = []
            else:
                run.append(idx)
        flush()
        if not result_runs:
            return items
        # Build the new root sequence.
        chunked_starts = {s: e for s, e in result_runs}
        idx = 0
        while idx < len(items):
            if idx in chunked_starts:
                end = chunked_starts[idx]
                children = list(items[idx:end])
                chunk = Tree(label, children)
                own.add(id(chunk))
                new_items.append(chunk)
                idx = end
            else:
                new_items.append(items[idx])
                idx += 1
        return new_items

    def _apply_chink(self, label, regex, items, own):
        new_items = []
        for item in items:
            if isinstance(item, Tree) and id(item) in own:
                children = list(item)
                tags = [_unit_tag(c) for c in children]
                spans = _find_matches(regex, tags)
                if not spans:
                    new_items.append(item)
                    continue
                cut = []
                pos = 0
                for s, e in spans:
                    cut.append((pos, s, False))
                    cut.append((s, e, True))
                    pos = e
                cut.append((pos, len(children), False))
                for s, e, is_chink in cut:
                    if s >= e:
                        continue
                    piece = children[s:e]
                    if is_chink:
                        new_items.extend(piece)
                    else:
                        chunk = Tree(item.label(), piece)
                        own.add(id(chunk))
                        new_items.append(chunk)
            else:
                new_items.append(item)
        return new_items


def ne_chunk(tagged_tokens):
    """Named-entity chunker. Requires the packaged NE model and the English wordlist."""
    for resource in (
        os.path.join("chunkers", "maxent_ne_chunker_tab", "english_ace_multiclass"),
        os.path.join("corpora", "words"),
    ):
        if not data.exists(resource):
            raise LookupError("named-entity chunker resource not visible: %s" % resource)
    raise NotImplementedError("the packaged named-entity model format is not implemented")
