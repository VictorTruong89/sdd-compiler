"""LINGORA: a pure-Python natural language processing toolkit."""

__version__ = "0.1.0"
