---
name: lingora-build-status
description: "State of the LINGORA NLP library build in /app (what exists, what is stubbed, where the decisions are recorded)"
metadata:
  node_type: memory
  type: project
  originSessionId: f03d0dd6-a8ba-400b-a7b3-3947c2b5a8b5
  modified: 2026-11-05T06:10:35.040Z
---

LINGORA (pure-Python NLP library) was built from `spec/` into `/app/lingora/` on 2026-11-05.
Decisions and every spec gap are recorded in `/app/NOTES.md`; read it before changing behaviour.

**Why:** the hidden acceptance tests run against `/app` as-is, so the build must import with no install step.

**How to apply:**
- Implemented: tokenizers (incl. Punkt), Porter (LINGORA ext), Lancaster (reconstructed rule table), Snowball english + porter only, regex stemmer, default/unigram/regexp taggers, averaged-perceptron `pos_tag`, chunk/chink parser, CFG + chart/shift-reduce parsers, generator, trees, Naive Bayes, decision tree, metrics, BLEU, dependency-free CLI.
- Stubbed (name exists, raises): ISRI, ARLSTem(2), Cistem, RSLP, WordNet lemmatizer, ne_chunk model path.
- Not implemented: 14 of 16 Snowball languages, bigram/trigram/affix taggers.
- Spec conflicts chosen: commas/colons not split by Treebank (explicit list wins); chunk tree leaves are (token, tag) tuples.
- Model-dependent paths were only tested with synthetic model files; no real Punkt or perceptron resources exist here.
