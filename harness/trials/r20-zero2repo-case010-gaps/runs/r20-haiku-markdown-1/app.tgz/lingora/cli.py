"""Command line: ``lingora tokenize`` reads text lines and writes one token line per input line.

Implemented without third-party packages.  ``cli`` is a command group object with
``cli.main(args=[...], standalone_mode=True)``.
"""

import sys

from lingora import punkt as _punkt
from lingora.data import ResourceNotFoundError
from lingora.tokenize import word_tokenize

__all__ = ["cli"]

USAGE = "usage: lingora tokenize [--language LANG] [--delimiter TEXT] [--encoding NAME]"


class _UsageError(Exception):
    pass


def _read_lines(stream, encoding):
    buffer = getattr(stream, "buffer", None)
    if buffer is not None:
        for raw in buffer:
            yield raw.decode(encoding).rstrip("\r\n")
    else:
        for line in stream:
            yield line.rstrip("\r\n")


def _tokenize_command(options, stdin, stdout, stderr):
    language = options["language"]
    delimiter = options["delimiter"]
    encoding = options["encoding"]
    try:
        _punkt.load_parameters(language)
    except ResourceNotFoundError as error:
        stderr.write("lingora: sentence-splitting model for %r is missing: %s\n" % (language, error))
        return 1
    for line in _read_lines(stdin, encoding):
        tokens = word_tokenize(line, language=language, preserve_line=False)
        stdout.write(delimiter.join(tokens) + "\n")
    stdout.flush()
    return 0


class _CommandGroup:
    def __init__(self):
        self.commands = {"tokenize": _tokenize_command}

    def _parse_options(self, args):
        options = {"language": "english", "delimiter": " ", "encoding": "utf-8"}
        names = {"--language": "language", "--delimiter": "delimiter", "--encoding": "encoding"}
        i = 0
        while i < len(args):
            arg = args[i]
            if "=" in arg and arg.split("=", 1)[0] in names:
                key, value = arg.split("=", 1)
                options[names[key]] = value
                i += 1
                continue
            if arg in names:
                if i + 1 >= len(args):
                    raise _UsageError("option %s needs a value" % arg)
                options[names[arg]] = args[i + 1]
                i += 2
                continue
            raise _UsageError("unexpected argument %r" % arg)
        return options

    def run(self, args, stdin=None, stdout=None, stderr=None):
        """Run the command named by args[0]; returns the exit status."""
        stdin = stdin if stdin is not None else sys.stdin
        stdout = stdout if stdout is not None else sys.stdout
        stderr = stderr if stderr is not None else sys.stderr
        if not args:
            stderr.write(USAGE + "\n")
            return 2
        name, rest = args[0], list(args[1:])
        if name not in self.commands:
            stderr.write("lingora: no such command %r\n%s\n" % (name, USAGE))
            return 2
        try:
            options = self._parse_options(rest)
        except _UsageError as error:
            stderr.write("lingora: %s\n%s\n" % (error, USAGE))
            return 2
        return self.commands[name](options, stdin, stdout, stderr)

    def main(self, args=None, standalone_mode=True):
        if args is None:
            args = sys.argv[1:]
        status = self.run(list(args))
        if standalone_mode:
            sys.exit(status)
        return status


cli = _CommandGroup()
