"""Punkt unsupervised sentence-boundary detection (Kiss and Strunk, 2006).

The packaged parameters for a language live in the directory
``tokenizers/punkt_tab/<language>/`` on ``lingora.data.path``:

* ``abbrev_types.txt``   one abbreviation type per line
* ``sent_starters.txt``  one sentence-starter type per line
* ``collocations.tab``   ``type1<TAB>type2`` per line
* ``ortho_context.tab``  ``type<TAB>integer`` per line (orthographic bit set)
"""

import os
import re

from lingora import data

_ORTHO_BEG_UC = 2
_ORTHO_MID_UC = 4
_ORTHO_UNK_UC = 8
_ORTHO_BEG_LC = 16
_ORTHO_MID_LC = 32
_ORTHO_UNK_LC = 64
_ORTHO_LC = _ORTHO_BEG_LC | _ORTHO_MID_LC | _ORTHO_UNK_LC
_ORTHO_UC = _ORTHO_BEG_UC | _ORTHO_MID_UC | _ORTHO_UNK_UC

_NUMBER_TYPE = "##number##"
_TRAILING_CLOSERS = "\"')]}>*"
_SENT_END = ".?!"


class PunktParameters:
    """The packaged Punkt model for one language."""

    def __init__(self, abbrev_types, sent_starters, collocations, ortho_context):
        self.abbrev_types = abbrev_types
        self.sent_starters = sent_starters
        self.collocations = collocations
        self.ortho_context = ortho_context


def _read_lines(filename):
    with open(filename, encoding="utf-8") as handle:
        return [line.rstrip("\r\n") for line in handle]


_CACHE = {}


def load_parameters(language="english"):
    """Load the Punkt parameters for ``language``.

    Raises ``lingora.data.ResourceNotFoundError`` when the model is not visible.
    """
    relpath = os.path.join("tokenizers", "punkt_tab", language)
    location = data.find(relpath)
    key = os.path.abspath(location)
    if key in _CACHE:
        return _CACHE[key]
    abbrev = set()
    starters = set()
    collocations = set()
    ortho = {}
    for line in _read_lines(os.path.join(location, "abbrev_types.txt")):
        if line.strip():
            abbrev.add(line.strip())
    for line in _read_lines(os.path.join(location, "sent_starters.txt")):
        if line.strip():
            starters.add(line.strip())
    for line in _read_lines(os.path.join(location, "collocations.tab")):
        parts = line.split("\t")
        if len(parts) == 2:
            collocations.add((parts[0], parts[1]))
    for line in _read_lines(os.path.join(location, "ortho_context.tab")):
        parts = line.split("\t")
        if len(parts) == 2 and parts[1].strip().lstrip("-").isdigit():
            ortho[parts[0]] = int(parts[1])
    params = PunktParameters(abbrev, starters, collocations, ortho)
    _CACHE[key] = params
    return params


def _type_of(core):
    """Punkt type of a word: lowercased, leading punctuation and final period removed."""
    word = core.rstrip(".")
    word = re.sub(r"^\W+", "", word)
    word = word.lower()
    if word and re.fullmatch(r"-?[.,\d]+", word):
        return _NUMBER_TYPE
    return word


class PunktSentenceTokenizer:
    """Sentence splitter driven by a ``PunktParameters`` model."""

    def __init__(self, params):
        self.params = params

    def _ortho_heuristic(self, word):
        """Return True (sentence starter), False (not one), or None (unsure)."""
        if word is None:
            return None
        first = next((c for c in word if c.isalpha()), "")
        if not first:
            return None
        ortho = self.params.ortho_context.get(_type_of(word), 0)
        first_upper = first.isupper()
        first_lower = first.islower()
        if first_upper and (ortho & _ORTHO_LC) and not (ortho & _ORTHO_MID_UC):
            return True
        if first_lower and ((ortho & _ORTHO_UC) or not (ortho & _ORTHO_LC)):
            return False
        return None

    def span_tokenize(self, text):
        """Yield ``(start, end)`` character spans of the sentences of ``text``."""
        words = [(m.start(), m.end(), m.group()) for m in re.finditer(r"\S+", text)]
        if not words:
            return
        start_index = 0
        for i, (_, end, word) in enumerate(words):
            core = word.rstrip(_TRAILING_CLOSERS)
            if not core or core[-1] not in _SENT_END:
                continue
            next_word = words[i + 1][2] if i + 1 < len(words) else None
            if self._is_break(core, next_word):
                yield (words[start_index][0], end)
                start_index = i + 1
        if start_index < len(words):
            yield (words[start_index][0], words[-1][1])

    def tokenize(self, text):
        """Return the sentences of ``text`` in order, without separating whitespace."""
        return [text[s:e] for s, e in self.span_tokenize(text)]

    def _is_break(self, core, next_word):
        if core[-1] in "?!":
            return True
        ellipsis = core.endswith("..")
        word_type = _type_of(core)
        abbrev = (
            word_type in self.params.abbrev_types
            or (len(word_type) == 1 and word_type.isalpha())
        )
        if next_word is None:
            return True
        next_type = _type_of(next_word)
        next_first = next((c for c in next_word if c.isalpha()), "")
        if (word_type, next_type) in self.params.collocations:
            return False
        if abbrev or ellipsis:
            if next_type in self.params.sent_starters and next_first.isupper():
                return True
            ortho = self._ortho_heuristic(next_word)
            if ortho is not None:
                return ortho
            if ellipsis and not abbrev:
                return next_first.isupper()
            return False
        ortho = self._ortho_heuristic(next_word)
        return ortho is not False
