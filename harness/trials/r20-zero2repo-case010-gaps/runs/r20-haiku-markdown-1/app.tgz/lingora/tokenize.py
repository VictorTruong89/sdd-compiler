"""Tokenizers: word/punctuation, Penn Treebank, recommended word and sentence
tokenizers, whitespace, blank-line, regular-expression, and tweet tokenizers."""

import re

from lingora import punkt as _punkt

__all__ = [
    "RegexpTokenizer",
    "TreebankWordTokenizer",
    "TweetTokenizer",
    "WhitespaceTokenizer",
    "WordPunctTokenizer",
    "blankline_tokenize",
    "sent_tokenize",
    "word_tokenize",
    "wordpunct_tokenize",
]


def _require_str(text, name="text"):
    if not isinstance(text, str):
        raise TypeError("%s must be a str, not %s" % (name, type(text).__name__))


# ---------------------------------------------------------------------------
# Word / punctuation and whitespace tokenizers
# ---------------------------------------------------------------------------

_WORDPUNCT_RE = re.compile(r"\w+|[^\w\s]+")


class WordPunctTokenizer:
    """Maximal runs of word characters, and maximal runs of other non-space characters."""

    def tokenize(self, text):
        _require_str(text)
        return _WORDPUNCT_RE.findall(text)

    def span_tokenize(self, text):
        _require_str(text)
        for match in _WORDPUNCT_RE.finditer(text):
            yield match.start(), match.end()


def wordpunct_tokenize(text):
    """Word/punctuation tokenization of ``text``."""
    return WordPunctTokenizer().tokenize(text)


class WhitespaceTokenizer:
    """Maximal runs of non-whitespace characters."""

    _RE = re.compile(r"\S+")

    def tokenize(self, text):
        _require_str(text)
        return self._RE.findall(text)

    def span_tokenize(self, text):
        _require_str(text)
        for match in self._RE.finditer(text):
            yield match.start(), match.end()


_BLANKLINE_SEP = re.compile(r"\s*\n\s*\n\s*")


def blankline_tokenize(text):
    """Split ``text`` into segments separated by blank lines (empty pieces dropped)."""
    _require_str(text)
    return [piece for piece in _BLANKLINE_SEP.split(text) if piece]


class RegexpTokenizer:
    """Tokenize with a caller-supplied regular expression.

    In token mode (default) the tokens are the non-overlapping matches.  In gap
    mode (``gaps=True``) the matches are separators and the tokens are the gaps.
    Empty tokens are dropped unless ``discard_empty=False``.
    """

    def __init__(self, pattern, gaps=False, discard_empty=True, flags=0):
        self.pattern = pattern
        self._regexp = re.compile(pattern, flags)
        self.gaps = bool(gaps)
        self.discard_empty = bool(discard_empty)

    def _spans(self, text):
        if self.gaps:
            pos = 0
            for match in self._regexp.finditer(text):
                yield pos, match.start()
                pos = match.end()
            yield pos, len(text)
        else:
            for match in self._regexp.finditer(text):
                yield match.start(), match.end()

    def span_tokenize(self, text):
        _require_str(text)
        for start, end in self._spans(text):
            if self.discard_empty and start == end:
                continue
            yield start, end

    def tokenize(self, text):
        _require_str(text)
        return [text[s:e] for s, e in self.span_tokenize(text)]


# ---------------------------------------------------------------------------
# Penn Treebank tokenizer and the recommended word tokenizer
# ---------------------------------------------------------------------------

_STARTING_QUOTES = [
    (re.compile(r'^"'), "``"),
    (re.compile(r"(``)"), r" \1 "),
    (re.compile(r'([ (\[{<])("|\'{2})'), r"\1 `` "),
]

_PUNCTUATION = [
    (re.compile(r"([:,])([^\d])"), r" \1 \2"),
    (re.compile(r"([:,])$"), r" \1 "),
    (re.compile(r"\.\.\."), " ... "),
    (re.compile(r"[;@#$%&]"), r" \g<0> "),
    (re.compile(r"([^\.])(\.)([\]\)}>\"']*)\s*$"), r"\1 \2\3 "),
    (re.compile(r"[?!]"), r" \g<0> "),
    (re.compile(r"([^'])' "), r"\1 ' "),
]

_PARENS_BRACKETS = [(re.compile(r"[\]\[\(\)\{\}<>]"), r" \g<0> ")]

_ENDING_QUOTES = [
    (re.compile(r"''"), " '' "),
    (re.compile(r'"'), " '' "),
    (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
    (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
]

_CONTRACTIONS2 = [
    re.compile(r"\b(can)(not)\b", re.IGNORECASE),
    re.compile(r"\b(d)('ye)\b", re.IGNORECASE),
    re.compile(r"\b(gim)(me)\b", re.IGNORECASE),
    re.compile(r"\b(gon)(na)\b", re.IGNORECASE),
    re.compile(r"\b(got)(ta)\b", re.IGNORECASE),
    re.compile(r"\b(lem)(me)\b", re.IGNORECASE),
    re.compile(r"\b(more)('n)\b", re.IGNORECASE),
    re.compile(r"\b(wan)(na)\b", re.IGNORECASE),
]

_CONTRACTIONS3 = [
    re.compile(r"(?<=\s)('t)(is)\b", re.IGNORECASE),
    re.compile(r"(?<=\s)('t)(was)\b", re.IGNORECASE),
]


def _treebank_tokens(text):
    for regexp, substitution in _STARTING_QUOTES:
        text = regexp.sub(substitution, text)
    for regexp, substitution in _PUNCTUATION:
        text = regexp.sub(substitution, text)
    for regexp, substitution in _PARENS_BRACKETS:
        text = regexp.sub(substitution, text)
    text = " " + text + " "
    for regexp, substitution in _ENDING_QUOTES:
        text = regexp.sub(substitution, text)
    for regexp in _CONTRACTIONS2 + _CONTRACTIONS3:
        text = regexp.sub(r" \1 \2 ", text)
    return text.split()


class TreebankWordTokenizer:
    """Penn Treebank word tokenizer (operates on one string; no sentence splitting)."""

    def tokenize(self, text):
        _require_str(text)
        return _treebank_tokens(text)


# Tokens the recommended tokenizer splits off before applying Treebank rules:
# runs of two or more points, a double hyphen, dashes U+2012-U+2015, typographic
# quotation marks U+2018-U+201F, and asterisks.
_RECOMMENDED_SPECIAL = re.compile(r"\.{2,}|--|[\u2012-\u2015\u2018-\u201f*]")


def _recommended_line(line):
    tokens = []
    pos = 0
    for match in _RECOMMENDED_SPECIAL.finditer(line):
        tokens.extend(_treebank_tokens(line[pos:match.start()]))
        tokens.append(match.group())
        pos = match.end()
    tokens.extend(_treebank_tokens(line[pos:]))
    return tokens


def word_tokenize(text, language="english", preserve_line=False):
    """LINGORA's recommended word tokenizer.

    With ``preserve_line=False`` the text is first split into sentences with
    ``sent_tokenize`` (which needs the Punkt model for ``language``).
    """
    _require_str(text)
    if preserve_line:
        return _recommended_line(text)
    tokens = []
    for sentence in sent_tokenize(text, language=language):
        tokens.extend(_recommended_line(sentence))
    return tokens


def sent_tokenize(text, language="english"):
    """Split ``text`` into sentences with the Punkt model for ``language``.

    Raises ``lingora.data.ResourceNotFoundError`` when the model is not visible.
    """
    _require_str(text)
    params = _punkt.load_parameters(language)
    return _punkt.PunktSentenceTokenizer(params).tokenize(text)


# ---------------------------------------------------------------------------
# Tweet tokenizer
# ---------------------------------------------------------------------------

_EMOTICON_BODY = (
    r"(?:[<>]?[:;=8][\-o\*\']?[\)\]\(\[dDpP/\:\}\{@\|\\]"
    r"|[\)\]\(\[dDpP/\:\}\{@\|\\][\-o\*\']?[:;=8][<>]?"
    r"|<3)"
)
_EMOTICON_RE = re.compile(_EMOTICON_BODY)
_TWEET_TOKEN_RE = re.compile(
    "|".join(
        [
            _EMOTICON_BODY,
            r"https?://\S+|www\.\S+",
            r"@\w+",
            r"#\w+",
            r"[+-]?\d+(?:[.,:]\d+)*(?!\w)",
            r"\w+(?:['\u2019\-]\w+)*",
            r"\.{2,}",
            r"\S",
        ]
    )
)
_TWEET_HANDLE_RE = re.compile(r"(?<!\w)@[A-Za-z0-9_]{1,15}")
_TWEET_REPEAT_RE = re.compile(r"(.)\1{2,}", re.DOTALL)


class TweetTokenizer:
    """Tokenizer for short social-media text."""

    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self.preserve_case = bool(preserve_case)
        self.reduce_len = bool(reduce_len)
        self.strip_handles = bool(strip_handles)

    def tokenize(self, text):
        _require_str(text)
        if self.strip_handles:
            text = _TWEET_HANDLE_RE.sub(" ", text)
        if self.reduce_len:
            text = _TWEET_REPEAT_RE.sub(r"\1\1\1", text)
        tokens = []
        for token in _TWEET_TOKEN_RE.findall(text):
            if _EMOTICON_RE.fullmatch(token) or self.preserve_case:
                tokens.append(token)
            else:
                tokens.append(token.lower())
        return tokens
