"""Context-free grammars: reading productions from text."""

import re

__all__ = ["CFG", "Nonterminal", "Production"]


class Nonterminal:
    """A grammar nonterminal.  Compares equal only to other nonterminals of the same name."""

    __slots__ = ("_symbol",)

    def __init__(self, symbol):
        self._symbol = str(symbol)

    def symbol(self):
        return self._symbol

    def __str__(self):
        return self._symbol

    def __repr__(self):
        return self._symbol

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and other._symbol == self._symbol

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash(("Nonterminal", self._symbol))


class Production:
    """``lhs -> rhs``: ``lhs`` is a Nonterminal; ``rhs`` items are Nonterminals or str terminals."""

    __slots__ = ("_lhs", "_rhs")

    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return isinstance(other, Production) and (self._lhs, self._rhs) == (other._lhs, other._rhs)

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        parts = []
        for item in self._rhs:
            parts.append(repr(item) if isinstance(item, str) and not isinstance(item, Nonterminal) else str(item))
        return "%s -> %s" % (self._lhs, " ".join(parts))

    def __repr__(self):
        return "Production(%s)" % self


_IDENT = re.compile(r"[^\s'\"|]+")


def _parse_alternatives(text, lineno):
    """Parse the right-hand side text into a list of alternatives (lists of symbols)."""
    alternatives = [[]]
    pos = 0
    text = text.strip()
    while pos < len(text):
        ch = text[pos]
        if ch.isspace():
            pos += 1
        elif ch == "|":
            alternatives.append([])
            pos += 1
        elif ch in "'\"":
            end = text.find(ch, pos + 1)
            if end < 0:
                raise ValueError("line %d: unterminated quoted terminal" % lineno)
            alternatives[-1].append(text[pos + 1:end])
            pos = end + 1
        else:
            match = _IDENT.match(text, pos)
            alternatives[-1].append(Nonterminal(match.group()))
            pos = match.end()
    return alternatives


class CFG:
    """A context-free grammar.  The start symbol is the left-hand side of the first production."""

    def __init__(self, start, productions):
        self._start = start if isinstance(start, Nonterminal) else Nonterminal(start)
        self._productions = list(productions)
        self._by_lhs = {}
        self._terminals = set()
        for production in self._productions:
            self._by_lhs.setdefault(production.lhs(), []).append(production)
            for item in production.rhs():
                if isinstance(item, str):
                    self._terminals.add(item)

    @classmethod
    def fromstring(cls, input):
        """Read productions, one ``LHS -> RHS`` per line; ``|`` separates alternatives."""
        if not isinstance(input, str):
            raise TypeError("grammar text must be a str")
        productions = []
        start = None
        for lineno, raw in enumerate(input.splitlines(), start=1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "->" not in line:
                raise ValueError("line %d: expected 'LHS -> RHS'" % lineno)
            lhs_text, rhs_text = line.split("->", 1)
            lhs_text = lhs_text.strip()
            if not lhs_text or _IDENT.fullmatch(lhs_text) is None:
                raise ValueError("line %d: bad left-hand side %r" % (lineno, lhs_text))
            lhs = Nonterminal(lhs_text)
            if start is None:
                start = lhs
            for alternative in _parse_alternatives(rhs_text, lineno):
                productions.append(Production(lhs, alternative))
        if start is None:
            raise ValueError("grammar has no productions")
        return cls(start, productions)

    def start(self):
        return self._start

    def productions(self, lhs=None, rhs=None):
        """All productions, or those whose left-hand side is ``lhs`` (name or symbol)."""
        if lhs is None:
            selected = list(self._productions)
        else:
            key = lhs if isinstance(lhs, Nonterminal) else Nonterminal(lhs)
            selected = list(self._by_lhs.get(key, []))
        if rhs is not None:
            selected = [p for p in selected if p.rhs() and p.rhs()[0] == rhs]
        return selected

    def terminals(self):
        return set(self._terminals)

    def nonterminals(self):
        return set(self._by_lhs.keys())

    def __repr__(self):
        return "<CFG with %d productions, start %s>" % (len(self._productions), self._start)

    def __str__(self):
        return "\n".join(str(p) for p in self._productions)
