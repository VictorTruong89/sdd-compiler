"""Classifiers: Naive Bayes and decision tree, and the classifier accuracy helper."""

import math
from collections import Counter, defaultdict

__all__ = ["NaiveBayesClassifier", "DecisionTreeClassifier", "ProbDist", "accuracy"]


class ProbDist:
    """A probability distribution over labels."""

    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def samples(self):
        return list(self._probs.keys())

    def max(self):
        return max(self._probs, key=lambda label: self._probs[label])

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._probs)


def _check_training(labeled_featuresets):
    if isinstance(labeled_featuresets, (str, bytes)):
        raise TypeError("training data must be a list of (featureset, label) pairs")
    data = list(labeled_featuresets)
    if not data:
        raise ValueError("cannot train a classifier on an empty training list")
    for featureset, _ in data:
        if not isinstance(featureset, dict):
            raise TypeError("a featureset must be a dict")
    return data


class NaiveBayesClassifier:
    """Multinomial-style Naive Bayes over (feature, value) pairs with add-one smoothing.

    P(value | label) = (count(label, feature, value) + 1) / (N(label) + |values of feature|),
    where |values of feature| counts the distinct values of that feature in training,
    so no value seen with some label gets probability zero under another label.
    Features not present in a featureset, and (feature, value) pairs never seen in
    training, contribute nothing.
    """

    def __init__(self, label_probdist, feature_counts, value_sets, label_counts, labels):
        self._label_prior = label_probdist
        self._feature_counts = feature_counts
        self._value_sets = value_sets
        self._label_counts = label_counts
        self._labels = labels

    @classmethod
    def train(cls, labeled_featuresets):
        data = _check_training(labeled_featuresets)
        label_counts = Counter()
        feature_counts = defaultdict(Counter)  # (label, feature) -> Counter(value)
        value_sets = defaultdict(set)
        labels = []
        for featureset, label in data:
            if label not in label_counts:
                labels.append(label)
            label_counts[label] += 1
            for feature, value in featureset.items():
                feature_counts[(label, feature)][value] += 1
                value_sets[feature].add(value)
        total = sum(label_counts.values())
        prior = {label: label_counts[label] / total for label in labels}
        return cls(prior, dict(feature_counts), dict(value_sets), label_counts, labels)

    def labels(self):
        return list(self._labels)

    def _log_scores(self, featureset):
        scores = {}
        for label in self._labels:
            log_score = math.log(self._label_prior[label])
            n_label = self._label_counts[label]
            for feature, value in featureset.items():
                values = self._value_sets.get(feature)
                if values is None or value not in values:
                    continue
                count = self._feature_counts.get((label, feature), Counter()).get(value, 0)
                probability = (count + 1) / (n_label + len(values))
                log_score += math.log(probability)
            scores[label] = log_score
        return scores

    def classify(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("a featureset must be a dict")
        scores = self._log_scores(featureset)
        return max(self._labels, key=lambda label: scores[label])

    def prob_classify(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("a featureset must be a dict")
        scores = self._log_scores(featureset)
        top = max(scores.values())
        exps = {label: math.exp(score - top) for label, score in scores.items()}
        total = sum(exps.values())
        return ProbDist({label: value / total for label, value in exps.items()})


_MISSING = object()


class DecisionTreeClassifier:
    """ID3-style decision tree: at each node the feature with the highest information gain.

    A feature absent from a featureset counts as having no value (a separate branch).
    A leaf returns the majority training label of the examples that reach it.
    """

    def __init__(self, tree):
        self._tree = tree

    @classmethod
    def train(cls, labeled_featuresets):
        data = _check_training(labeled_featuresets)
        return cls(_build(data, set(f for fs, _ in data for f in fs)))

    def classify(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("a featureset must be a dict")
        node = self._tree
        while node[0] == "split":
            _, feature, branches, majority = node
            value = featureset.get(feature, _MISSING)
            key = None if value is _MISSING else value
            if key not in branches:
                return majority
            node = branches[key]
        return node[1]


def _entropy(labels):
    counts = Counter(labels)
    total = len(labels)
    return -sum((c / total) * math.log2(c / total) for c in counts.values())


def _majority(labels):
    counts = Counter(labels)
    best_count = max(counts.values())
    for label in labels:  # first-seen among the most frequent
        if counts[label] == best_count:
            return label


def _build(data, features):
    labels = [label for _, label in data]
    if len(set(labels)) == 1:
        return ("leaf", labels[0])
    majority = _majority(labels)
    base = _entropy(labels)
    best_feature = None
    best_gain = 0.0
    for feature in sorted(features, key=str):
        groups = defaultdict(list)
        for featureset, label in data:
            key = featureset.get(feature, None)
            groups[key].append(label)
        if len(groups) < 2:
            continue
        remainder = sum(len(g) / len(data) * _entropy(g) for g in groups.values())
        gain = base - remainder
        if gain > best_gain + 1e-12:
            best_gain = gain
            best_feature = feature
    if best_feature is None:
        return ("leaf", majority)
    partitions = defaultdict(list)
    for featureset, label in data:
        partitions[featureset.get(best_feature, None)].append((featureset, label))
    remaining = features - {best_feature}
    branches = {key: _build(part, remaining) for key, part in partitions.items()}
    return ("split", best_feature, branches, majority)


def accuracy(classifier, gold):
    """Fraction of ``(featureset, label)`` pairs in ``gold`` that ``classifier`` labels correctly."""
    gold = list(gold)
    if not gold:
        raise ValueError("accuracy of an empty gold list is undefined")
    correct = sum(1 for featureset, label in gold if classifier.classify(featureset) == label)
    return correct / len(gold)
