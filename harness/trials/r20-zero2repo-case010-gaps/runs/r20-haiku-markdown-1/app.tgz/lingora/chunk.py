"""Shallow chunk parsing with a chunk grammar (regular-expression chunking).

Grammar text: clauses ``LABEL: pattern`` followed by optional indented patterns.
A pattern ``{...}`` is a chunk rule; ``}...{`` is a chink rule.  The body is a
sequence of elements ``<regex>`` each optionally followed by ``?``, ``*``, ``+``
or ``{m,n}``; ``.`` in an element matches any character of a tag.
"""

import re

from lingora import data
from lingora.tree import Tree

__all__ = ["RegexpParser", "ne_chunk"]

ROOT_LABEL = "SENT"
_QUANTIFIER_BRACES = re.compile(r"\{\d*,?\d*\}")
_CLAUSE_HEADER = re.compile(r"^\s*([A-Za-z_][\w.\-]*)\s*:\s*(.*)$")


def _tag_regex(content):
    """Translate an element's regular expression over tags into Python syntax."""
    out = []
    i = 0
    while i < len(content):
        ch = content[i]
        if ch == "\\" and i + 1 < len(content):
            out.append(content[i:i + 2])
            i += 2
            continue
        out.append("[^<>]" if ch == "." else ch)
        i += 1
    return "".join(out)


class _Rule:
    def __init__(self, kind, elements):
        self.kind = kind  # "chunk" or "chink"
        self.regexp = re.compile("".join(
            "(?:<(?:%s)>)%s" % (_tag_regex(content), quant) for content, quant in elements
        ))


def _parse_rules(text, label):
    """Parse all rules written on one grammar line (after the clause label)."""
    rules = []
    i = 0
    n = len(text)
    while True:
        while i < n and text[i].isspace():
            i += 1
        if i >= n or text[i] == "#":
            break
        if text[i] == "{":
            kind, close = "chunk", "}"
        elif text[i] == "}":
            kind, close = "chink", "{"
        else:
            raise ValueError("clause %s: unexpected text %r in grammar" % (label, text[i:]))
        i += 1
        elements = []
        while True:
            while i < n and text[i].isspace():
                i += 1
            if i >= n:
                raise ValueError("clause %s: unterminated rule in grammar" % label)
            ch = text[i]
            if ch == "<":
                end = text.find(">", i + 1)
                if end < 0:
                    raise ValueError("clause %s: unterminated tag pattern" % label)
                content = text[i + 1:end]
                i = end + 1
                quant = ""
                if i < n and text[i] in "?*+":
                    quant = text[i]
                    i += 1
                elif i < n and text[i] == "{":
                    match = _QUANTIFIER_BRACES.match(text, i)
                    if match:
                        quant = match.group()
                        i = match.end()
                elements.append((content, quant))
            elif ch == close:
                i += 1
                break
            else:
                raise ValueError("clause %s: unexpected character %r in pattern" % (label, ch))
        if not elements:
            raise ValueError("clause %s: empty pattern" % label)
        rules.append(_Rule(kind, elements))
    return rules


def _parse_grammar(grammar):
    clauses = []
    for raw in grammar.splitlines():
        stripped = raw.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped[0] in "{}":
            if not clauses:
                raise ValueError("grammar rule appears before any clause label")
            clauses[-1][1].extend(_parse_rules(stripped, clauses[-1][0]))
            continue
        match = _CLAUSE_HEADER.match(raw)
        if match is None:
            raise ValueError("bad grammar line %r" % raw)
        label, rest = match.group(1), match.group(2)
        clauses.append((label, _parse_rules(rest, label)))
    if not clauses:
        raise ValueError("empty chunk grammar")
    return clauses


def _encode(units, barrier):
    """Encode units as a string of ``<tag>`` items; barriers encode to ``{}``.

    Returns (text, start_index, end_index) where the maps give the unit index at each
    token boundary.
    """
    parts = []
    starts = {}
    ends = {}
    pos = 0
    for index, (kind, tag) in enumerate(units):
        if barrier[index]:
            piece = "{}"
        else:
            piece = "<" + tag + ">"
        starts[pos] = index
        pos += len(piece)
        ends[pos] = index
        parts.append(piece)
    return "".join(parts), starts, ends


class RegexpParser:
    """Chunk parser built from a chunk grammar text."""

    def __init__(self, grammar):
        if not isinstance(grammar, str):
            raise TypeError("grammar must be a str")
        self._clauses = _parse_grammar(grammar)
        for label, _ in self._clauses:
            if label == ROOT_LABEL:
                raise ValueError("clause label %r is reserved for the root" % ROOT_LABEL)

    def parse(self, tagged):
        if isinstance(tagged, str) or not isinstance(tagged, (list, tuple)):
            raise TypeError("tagged must be a list of (token, tag) pairs")
        children = []
        for pair in tagged:
            token, tag = pair
            children.append((token, "" if tag is None else str(tag)))
        for label, rules in self._clauses:
            own = set()  # ids of chunks built by this clause
            for rule in rules:
                if rule.kind == "chunk":
                    children = self._apply_chunk(children, label, rule, own)
                else:
                    children = self._apply_chink(children, label, rule, own)
        return Tree(ROOT_LABEL, children)

    @staticmethod
    def _unit_tag(unit, own):
        if isinstance(unit, Tree):
            return unit.label()
        return unit[1]

    def _apply_chunk(self, children, label, rule, own):
        units = [(None, self._unit_tag(c, own)) for c in children]
        barrier = [isinstance(c, Tree) and id(c) in own for c in children]
        text, starts, ends = _encode(units, barrier)
        result = []
        pos = 0
        for match in rule.regexp.finditer(text):
            if match.start() == match.end():
                continue
            if match.start() not in starts or match.end() not in ends:
                continue
            first = starts[match.start()]
            last = ends[match.end()]
            if first < pos:
                continue
            result.extend(children[pos:first])
            chunk = Tree(label, children[first:last + 1])
            own.add(id(chunk))
            result.append(chunk)
            pos = last + 1
        result.extend(children[pos:])
        return result

    def _apply_chink(self, children, label, rule, own):
        result = []
        for child in children:
            if not (isinstance(child, Tree) and id(child) in own):
                result.append(child)
                continue
            leaves = list(child)
            units = [(None, self._unit_tag(c, own)) for c in leaves]
            barrier = [isinstance(c, Tree) for c in leaves]
            text, starts, ends = _encode(units, barrier)
            pieces = []
            pos = 0
            for match in rule.regexp.finditer(text):
                if match.start() == match.end():
                    continue
                if match.start() not in starts or match.end() not in ends:
                    continue
                first = starts[match.start()]
                last = ends[match.end()]
                if first < pos:
                    continue
                if first > pos:
                    pieces.append(("chunk", leaves[pos:first]))
                pieces.append(("leaves", leaves[first:last + 1]))
                pos = last + 1
            if pos < len(leaves):
                pieces.append(("chunk", leaves[pos:]))
            if all(kind == "chunk" for kind, _ in pieces) and not any(
                kind == "leaves" for kind, _ in pieces
            ):
                result.append(child)
                continue
            for kind, items in pieces:
                if kind == "leaves":
                    result.extend(items)
                else:
                    piece_tree = Tree(label, items)
                    own.add(id(piece_tree))
                    result.append(piece_tree)
        return result


def ne_chunk(tagged_tokens):
    """Named-entity chunking.  Requires the named-entity model and the English wordlist.

    Raises ``lingora.data.ResourceNotFoundError`` when either resource is not visible.
    Loading and applying the maximum-entropy model is not implemented in this build.
    """
    data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    data.find("corpora/words")
    raise NotImplementedError("named-entity chunking is not implemented in this build")
