"""LINGORA: a Python natural-language processing library.

Importing the package downloads nothing and needs no packaged data.
Submodules are imported on demand, e.g. ``from lingora.tokenize import wordpunct_tokenize``.
"""

__version__ = "0.1.0"

from lingora import data  # noqa: E402  (re-exported resource finder)

__all__ = ["data", "__version__"]
