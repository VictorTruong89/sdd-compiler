"""BLEU score (Papineni et al., 2002) over token lists."""

import math
from collections import Counter

__all__ = ["bleu"]

_DEFAULT_WEIGHTS = (0.25, 0.25, 0.25, 0.25)


def _ngrams(tokens, n):
    return Counter(tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1))


def bleu(references, hypothesis, weights=_DEFAULT_WEIGHTS, smoothing_function=None):
    """Sentence-level BLEU of ``hypothesis`` against one or more ``references``.

    ``weights`` gives one weight per n-gram order starting from unigrams.  Without a
    ``smoothing_function`` a zero modified precision for a weighted order gives 0.
    A callable ``smoothing_function`` receives and returns the list of
    ``(numerator, denominator)`` pairs, one per order.
    """
    references = [list(r) for r in references]
    hypothesis = list(hypothesis)
    weights = [float(w) for w in weights]
    if not references:
        raise ValueError("bleu needs at least one reference")
    if not weights:
        raise ValueError("bleu needs at least one weight")
    if not hypothesis:
        return 0.0

    pairs = []
    for n in range(1, len(weights) + 1):
        hyp_counts = _ngrams(hypothesis, n)
        total = sum(hyp_counts.values())
        max_ref = Counter()
        for ref in references:
            for gram, count in _ngrams(ref, n).items():
                if count > max_ref[gram]:
                    max_ref[gram] = count
        clipped = sum(min(count, max_ref[gram]) for gram, count in hyp_counts.items())
        pairs.append((clipped, total))

    if smoothing_function is not None:
        pairs = list(smoothing_function(pairs))

    log_sum = 0.0
    for weight, (numerator, denominator) in zip(weights, pairs):
        if weight == 0:
            continue
        if numerator <= 0 or denominator <= 0:
            return 0.0
        log_sum += weight * math.log(numerator / denominator)

    hyp_len = len(hypothesis)
    ref_len = min((len(r) for r in references), key=lambda length: (abs(length - hyp_len), length))
    if hyp_len > ref_len:
        brevity = 1.0
    else:
        brevity = math.exp(1 - ref_len / hyp_len)
    return brevity * math.exp(log_sum)
