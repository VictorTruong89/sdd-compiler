"""Constituent trees: a label plus an ordered list of children (strings or trees)."""

__all__ = ["Tree"]

_PFORMAT_WIDTH = 70


class Tree:
    """A labelled ordered tree.

    ``children`` must be a list (or tuple) of children; a ``str`` or a missing
    argument is refused.  ``Tree(label, [])`` is a valid tree with no children.
    """

    __slots__ = ("_label", "_children")

    def __init__(self, label, children):
        if isinstance(children, (str, bytes)) or not isinstance(children, (list, tuple)):
            raise TypeError("Tree children must be a list, not %s" % type(children).__name__)
        self._label = label
        self._children = list(children)

    # -- construction -----------------------------------------------------
    @classmethod
    def fromstring(cls, s):
        """Build a tree from bracketed tree text ``(label child ...)``."""
        if not isinstance(s, str):
            raise TypeError("bracketed tree text must be a str")
        tokens = _lex_bracketed(s)
        node, pos = _parse_node(tokens, 0)
        if pos != len(tokens):
            raise ValueError("unexpected text after the tree in %r" % s)
        return node

    # -- accessors --------------------------------------------------------
    def label(self):
        return self._label

    def leaves(self):
        out = []
        for child in self._children:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def pformat(self):
        flat = _flat(self)
        if len(flat) <= _PFORMAT_WIDTH or not any(isinstance(c, Tree) for c in self._children):
            return flat
        return _multiline(self, 0)

    # -- sequence protocol -----------------------------------------------
    def __len__(self):
        return len(self._children)

    def __getitem__(self, index):
        return self._children[index]

    def __iter__(self):
        return iter(self._children)

    # -- comparison / display --------------------------------------------
    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    def __hash__(self):
        return hash((self._label, tuple(self._children)))

    def __repr__(self):
        return "Tree(%r, %r)" % (self._label, self._children)

    def __str__(self):
        return _flat(self)


def _flat(node):
    parts = [str(node._label)]
    for child in node._children:
        parts.append(_flat(child) if isinstance(child, Tree) else str(child))
    return "(" + " ".join(parts) + ")"


def _multiline(node, indent):
    pad = " " * indent
    head = "(" + str(node._label)
    lines = []
    leaf_parts = []
    for child in node._children:
        if isinstance(child, Tree):
            if leaf_parts:
                lines.append(pad + "  " + " ".join(leaf_parts))
                leaf_parts = []
            lines.append(_multiline(child, indent + 2))
        else:
            leaf_parts.append(str(child))
    if leaf_parts:
        lines.append(pad + "  " + " ".join(leaf_parts))
    return "\n".join([pad + head] + lines) + ")"


def _lex_bracketed(s):
    tokens = []
    i = 0
    while i < len(s):
        ch = s[i]
        if ch.isspace():
            i += 1
        elif ch in "()":
            tokens.append(ch)
            i += 1
        else:
            j = i
            while j < len(s) and not s[j].isspace() and s[j] not in "()":
                j += 1
            tokens.append(s[i:j])
            i = j
    return tokens


def _parse_node(tokens, pos):
    if pos >= len(tokens) or tokens[pos] != "(":
        raise ValueError("expected '(' in bracketed tree text")
    pos += 1
    if pos >= len(tokens) or tokens[pos] in "()":
        raise ValueError("expected a label after '(' in bracketed tree text")
    label = tokens[pos]
    pos += 1
    children = []
    while True:
        if pos >= len(tokens):
            raise ValueError("unbalanced parentheses in bracketed tree text")
        tok = tokens[pos]
        if tok == ")":
            return Tree(label, children), pos + 1
        if tok == "(":
            child, pos = _parse_node(tokens, pos)
            children.append(child)
        else:
            children.append(tok)
            pos += 1
