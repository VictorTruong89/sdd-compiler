"""Grammar-based parsers: the exhaustive chart parser and the shift-reduce parser."""

from lingora.grammar import Nonterminal
from lingora.tree import Tree

__all__ = ["ChartParser", "ShiftReduceParser"]


def _check_tokens(grammar, tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")
    terminals = grammar.terminals()
    for token in tokens:
        if not isinstance(token, str):
            raise TypeError("tokens must be a list of str")
        if token not in terminals:
            raise ValueError("token %r is not produced by any production of the grammar" % token)


class ChartParser:
    """Exhaustive parser: yields every tree the grammar assigns to the tokens.

    Derivations that revisit the same symbol over the same span (cyclic unit
    productions) are cut off, so the number of trees is finite.
    """

    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):
        _check_tokens(self._grammar, tokens)
        tokens = list(tokens)
        n = len(tokens)
        memo = {}
        active = set()

        def parse_symbol(symbol, i, j):
            """Return (trees, cut): the trees for symbol over tokens[i:j]."""
            key = (symbol, i, j)
            if key in memo:
                return memo[key], False
            if key in active:
                return [], True
            active.add(key)
            cut = False
            trees = []
            for production in self._grammar.productions(lhs=symbol):
                sequences, seq_cut = parse_sequence(production.rhs(), 0, i, j)
                cut = cut or seq_cut
                for children in sequences:
                    trees.append(Tree(str(symbol), children))
            active.discard(key)
            if not cut:
                memo[key] = trees
            return trees, cut

        def parse_sequence(rhs, k, i, j):
            """Return (children_lists, cut) for rhs[k:] over tokens[i:j]."""
            if k == len(rhs):
                return ([[]] if i == j else []), False
            item = rhs[k]
            if not isinstance(item, Nonterminal):
                if i < j and tokens[i] == item:
                    rest, cut = parse_sequence(rhs, k + 1, i + 1, j)
                    return [[item] + r for r in rest], cut
                return [], False
            results = []
            cut = False
            for mid in range(i, j + 1):
                subtrees, sub_cut = parse_symbol(item, i, mid)
                cut = cut or sub_cut
                if not subtrees:
                    continue
                rest, rest_cut = parse_sequence(rhs, k + 1, mid, j)
                cut = cut or rest_cut
                for tree in subtrees:
                    for r in rest:
                        results.append([tree] + r)
            return results, cut

        trees, _ = parse_symbol(self._grammar.start(), 0, n)
        for tree in trees:
            yield tree


class ShiftReduceParser:
    """Single left-to-right shift-reduce pass without backtracking.

    Whenever the top of the stack matches the right-hand side of a production
    (productions are tried in their written order), it reduces; otherwise it
    shifts the next token.  Productions with an empty right-hand side are not
    used for reduction, which would otherwise never terminate.
    """

    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):
        _check_tokens(self._grammar, tokens)
        tokens = list(tokens)
        productions = [p for p in self._grammar.productions() if len(p.rhs()) > 0]
        start_label = str(self._grammar.start())
        stack = []
        pos = 0
        while True:
            reduced = False
            for production in productions:
                rhs = production.rhs()
                n = len(rhs)
                if n > len(stack):
                    continue
                top = stack[-n:]
                if all(_matches(sym, item) for sym, item in zip(rhs, top)):
                    del stack[-n:]
                    stack.append(Tree(str(production.lhs()), list(top)))
                    reduced = True
                    break
            if reduced:
                continue
            if pos < len(tokens):
                stack.append(tokens[pos])
                pos += 1
                continue
            break
        if len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == start_label:
            yield stack[0]


def _matches(symbol, item):
    if isinstance(symbol, Nonterminal):
        return isinstance(item, Tree) and item.label() == str(symbol)
    return isinstance(item, str) and item == symbol
