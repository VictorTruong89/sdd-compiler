"""Enumerate the sentences a context-free grammar derives."""

from lingora.grammar import Nonterminal

__all__ = ["generate"]


def _derive_symbol(grammar, symbol, depth):
    """Yield (tokens, height) for derivations of ``symbol`` of height at most ``depth``.

    A nonterminal node has height 1 + the largest height of its children; terminals
    have height 0.  Productions are expanded in their written order.
    """
    if depth < 1:
        return
    for production in grammar.productions(lhs=symbol):
        for tokens, height in _derive_sequence(grammar, production.rhs(), depth - 1):
            yield tokens, height + 1


def _derive_sequence(grammar, items, depth):
    if not items:
        yield [], 0
        return
    head, rest = items[0], items[1:]
    if isinstance(head, Nonterminal):
        head_derivations = _derive_symbol(grammar, head, depth)
    else:
        head_derivations = [([head], 0)]
    for head_tokens, head_height in head_derivations:
        for rest_tokens, rest_height in _derive_sequence(grammar, rest, depth):
            yield head_tokens + rest_tokens, max(head_height, rest_height)


def generate(grammar, start=None, depth=None, n=None):
    """Yield sentences (lists of terminal strings) derived from ``start``.

    ``start`` defaults to the grammar's start symbol.  ``depth`` bounds the height of
    the derivation trees; ``None`` means unbounded, in which case sentences are
    produced in increasing order of derivation height, so recursive grammars can
    be sampled with ``n``.  Stops after ``n`` sentences when ``n`` is given.
    """
    if n is not None and n <= 0:
        return
    if start is None:
        start = grammar.start()
    elif not isinstance(start, Nonterminal):
        start = Nonterminal(start)
    produced = 0
    if depth is not None:
        for tokens, _ in _derive_symbol(grammar, start, int(depth)):
            yield list(tokens)
            produced += 1
            if n is not None and produced >= n:
                return
        return
    bound = len(grammar.nonterminals()) + 1
    level = 1
    highest_seen = 0
    while level <= highest_seen + bound:
        for tokens, height in _derive_symbol(grammar, start, level):
            if height != level:
                continue
            highest_seen = level
            yield list(tokens)
            produced += 1
            if n is not None and produced >= n:
                return
        level += 1
