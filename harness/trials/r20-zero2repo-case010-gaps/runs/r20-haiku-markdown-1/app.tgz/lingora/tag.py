"""Part-of-speech taggers.

Sequential taggers (trainable without a model): DefaultTagger, UnigramTagger,
BigramTagger, TrigramTagger, AffixTagger, RegexpTagger; all accept ``backoff=``.

Recommended tagger: ``pos_tag`` uses the averaged perceptron tagger packaged for
English (``taggers/averaged_perceptron_tagger_eng/``) or Russian
(``taggers/averaged_perceptron_tagger_rus/``); the universal tagset mapping for
English needs ``taggers/universal_tagset/en-ptb.map``.
"""

import json
import os
import re
from collections import Counter, defaultdict

from lingora import data

__all__ = [
    "AffixTagger",
    "BigramTagger",
    "DefaultTagger",
    "RegexpTagger",
    "TrigramTagger",
    "UnigramTagger",
    "pos_tag",
]


class SequentialTagger:
    """Base class: ``tag(tokens)`` returns ``(token, tag-or-None)`` pairs."""

    def __init__(self, backoff=None):
        if backoff is not None and not isinstance(backoff, SequentialTagger):
            raise TypeError("backoff must be a tagger or None")
        self._backoff = backoff

    def _choose(self, tokens):
        """Return one tag-or-None per token from this tagger alone."""
        raise NotImplementedError

    def tag(self, tokens):
        if isinstance(tokens, str):
            raise TypeError("tokens must be a list of str, not a str")
        tokens = list(tokens)
        tags = self._choose(tokens)
        if self._backoff is not None:
            missing = [i for i, t in enumerate(tags) if t is None]
            if missing:
                fallback = self._backoff.tag([tokens[i] for i in missing])
                for i, (_, t) in zip(missing, fallback):
                    tags[i] = t
        return list(zip(tokens, tags))


class DefaultTagger(SequentialTagger):
    """Assigns one configured tag to every token."""

    def __init__(self, tag, backoff=None):
        super().__init__(backoff)
        self._tag = tag

    def _choose(self, tokens):
        return [self._tag] * len(tokens)


class RegexpTagger(SequentialTagger):
    """Tags a token with the first rule whose pattern matches at its start."""

    def __init__(self, regexps, backoff=None):
        super().__init__(backoff)
        self._rules = [(re.compile(pattern), tag) for pattern, tag in regexps]

    def _choose(self, tokens):
        result = []
        for token in tokens:
            tag = None
            for regexp, candidate in self._rules:
                if regexp.match(token):
                    tag = candidate
                    break
            result.append(tag)
        return result


class NgramTagger(SequentialTagger):
    """Base for unigram/bigram/trigram taggers trained on tagged sentences.

    Each context maps to its most frequent tag in training; ties are broken by
    the lexicographically smallest tag.  Unseen contexts get no tag.
    """

    ORDER = 1

    def __init__(self, train=None, backoff=None):
        super().__init__(backoff)
        self._model = {}
        if train is not None:
            self.train(train)

    def _contexts(self, tokens, tags_so_far):
        raise NotImplementedError

    def train(self, train):
        counts = defaultdict(Counter)
        for sentence in train:
            tokens = [token for token, _ in sentence]
            gold = [tag for _, tag in sentence]
            history = []
            for i, token in enumerate(tokens):
                context = self._context(tokens, i, history)
                counts[context][gold[i]] += 1
                history.append(gold[i])
        self._model = {}
        for context, counter in counts.items():
            best = sorted(counter.items(), key=lambda kv: (-kv[1], kv[0]))[0][0]
            self._model[context] = best
        return self

    def _context(self, tokens, i, history):
        raise NotImplementedError

    def _choose(self, tokens):
        result = []
        history = []
        for i in range(len(tokens)):
            context = self._context(tokens, i, history)
            tag = self._model.get(context)
            result.append(tag)
            history.append(tag)
        return result


class UnigramTagger(NgramTagger):
    """Tags each token with the tag it most often had in training."""

    def _context(self, tokens, i, history):
        return tokens[i]


class BigramTagger(NgramTagger):
    """Context: the current token and the previous tag."""

    def _context(self, tokens, i, history):
        previous = history[i - 1] if i > 0 else None
        return (tokens[i], previous)

    def _choose(self, tokens):
        result = []
        for i in range(len(tokens)):
            previous = result[i - 1] if i > 0 else None
            result.append(self._model.get((tokens[i], previous)))
        return result


class TrigramTagger(NgramTagger):
    """Context: the current token and the two previous tags."""

    def _context(self, tokens, i, history):
        previous = history[i - 1] if i > 0 else None
        before = history[i - 2] if i > 1 else None
        return (tokens[i], previous, before)

    def _choose(self, tokens):
        result = []
        for i in range(len(tokens)):
            previous = result[i - 1] if i > 0 else None
            before = result[i - 2] if i > 1 else None
            result.append(self._model.get((tokens[i], previous, before)))
        return result


class AffixTagger(SequentialTagger):
    """Tags by the fixed-length prefix or suffix of the token (``affix_length``)."""

    def __init__(self, train=None, affix_length=-3, min_stem_length=2, backoff=None):
        super().__init__(backoff)
        self.affix_length = int(affix_length)
        self.min_stem_length = int(min_stem_length)
        self._model = {}
        if train is not None:
            self.train(train)

    def _affix(self, token):
        if self.affix_length > 0:
            affix = token[: self.affix_length]
        else:
            affix = token[self.affix_length:]
        if len(token) < abs(self.affix_length) + self.min_stem_length:
            return None
        return affix

    def train(self, train):
        counts = defaultdict(Counter)
        for sentence in train:
            for token, tag in sentence:
                affix = self._affix(token)
                if affix is not None:
                    counts[affix][tag] += 1
        self._model = {
            affix: sorted(counter.items(), key=lambda kv: (-kv[1], kv[0]))[0][0]
            for affix, counter in counts.items()
        }
        return self

    def _choose(self, tokens):
        result = []
        for token in tokens:
            affix = self._affix(token)
            result.append(self._model.get(affix) if affix is not None else None)
        return result


# ---------------------------------------------------------------------------
# Averaged perceptron tagger (recommended English / Russian tagger)
# ---------------------------------------------------------------------------

_LANG_RESOURCE = {"eng": "averaged_perceptron_tagger_eng", "rus": "averaged_perceptron_tagger_rus"}
_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]
_PERCEPTRON_CACHE = {}


class _PerceptronModel:
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = set(classes)

    def predict(self, features):
        scores = defaultdict(float)
        for feature, value in features.items():
            if value == 0 or feature not in self.weights:
                continue
            for label, weight in self.weights[feature].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))


def _load_perceptron(lang):
    if lang not in _LANG_RESOURCE:
        raise ValueError("pos_tag supports only 'eng' and 'rus', not %r" % (lang,))
    relative = os.path.join("taggers", _LANG_RESOURCE[lang])
    location = data.find(relative)
    key = os.path.abspath(location)
    if key in _PERCEPTRON_CACHE:
        return _PERCEPTRON_CACHE[key]
    base = "averaged_perceptron_tagger_" + lang
    with open(os.path.join(location, base + ".weights.json"), encoding="utf-8") as handle:
        weights = json.load(handle)
    with open(os.path.join(location, base + ".tagdict.json"), encoding="utf-8") as handle:
        tagdict = json.load(handle)
    with open(os.path.join(location, base + ".classes.json"), encoding="utf-8") as handle:
        classes = json.load(handle)
    model = _PerceptronModel(weights, tagdict, classes)
    _PERCEPTRON_CACHE[key] = model
    return model


def _normalize(word):
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word and word[0].isdigit():
        return "!DIGITS"
    return word.lower()


def _features(i, word, context, prev, prev2):
    features = defaultdict(int)

    def add(name, *args):
        features[" ".join((name,) + tuple(args))] += 1

    i += len(_START)
    add("bias")
    add("i suffix", word[-3:])
    add("i pref1", word[0] if word else "")
    add("i-1 tag", prev)
    add("i-2 tag", prev2)
    add("i tag+i-2 tag", prev, prev2)
    add("i word", context[i])
    add("i-1 tag+i word", prev, context[i])
    add("i-1 word", context[i - 1])
    add("i-1 suffix", context[i - 1][-3:])
    add("i-2 word", context[i - 2])
    add("i+1 word", context[i + 1])
    add("i+1 suffix", context[i + 1][-3:])
    add("i+2 word", context[i + 2])
    return features


def _perceptron_tag(model, tokens):
    context = _START + [_normalize(w) for w in tokens] + _END
    tags = []
    prev, prev2 = _START[0], _START[1]
    for i, word in enumerate(tokens):
        tag = model.tagdict.get(word)
        if tag is None:
            features = _features(i, word, context, prev, prev2)
            tag = model.predict(features)
        tags.append(tag)
        prev2 = prev
        prev = tag
    return tags


# Penn Treebank -> universal mapping is read from en-ptb.map; Russian National
# Corpus part-of-speech categories (the part before "=") map as below.
_RUSSIAN_TO_UNIVERSAL = {
    "S": "NOUN", "A": "ADJ", "NUM": "NUM", "V": "VERB", "ADV": "ADV",
    "PRAEDIC": "ADV", "PARENTH": "X", "PR": "ADP", "CONJ": "CONJ", "PART": "PRT",
    "INTJ": "X", "SPRO": "PRON", "ANUM": "ADJ", "APRO": "DET",
}

_UNIVERSAL_CACHE = {}


def _load_english_universal_map():
    location = data.find(os.path.join("taggers", "universal_tagset", "en-ptb.map"))
    if location in _UNIVERSAL_CACHE:
        return _UNIVERSAL_CACHE[location]
    mapping = {}
    with open(location, encoding="utf-8") as handle:
        for line in handle:
            parts = line.rstrip("\r\n").split("\t")
            if len(parts) == 2:
                mapping[parts[0]] = parts[1]
    _UNIVERSAL_CACHE[location] = mapping
    return mapping


def pos_tag(tokens, tagset=None, lang="eng"):
    """Tag ``tokens`` (a list of str) with the recommended averaged perceptron tagger.

    ``lang`` is ``'eng'`` or ``'rus'``.  ``tagset`` is ``None`` (native tags) or
    ``'universal'``.  Raises when the input is not a token list, the language is
    unsupported, or the required resource is not installed.
    """
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")
    if not all(isinstance(t, str) for t in tokens):
        raise TypeError("tokens must be a list of str")
    if tagset not in (None, "universal"):
        raise ValueError("tagset must be None or 'universal'")
    model = _load_perceptron(lang)
    tags = _perceptron_tag(model, list(tokens))
    if tagset == "universal":
        if lang == "eng":
            mapping = _load_english_universal_map()
            tags = [mapping.get(t, t) for t in tags]
        else:
            tags = [_RUSSIAN_TO_UNIVERSAL.get(t.split("=")[0], "X") for t in tags]
    return list(zip(tokens, tags))
