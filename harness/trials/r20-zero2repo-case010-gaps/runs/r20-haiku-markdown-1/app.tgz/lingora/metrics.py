"""Evaluation metrics: edit distance, Jaccard distance, accuracy, precision, recall, f-measure."""

__all__ = ["accuracy", "edit_distance", "f_measure", "jaccard_distance", "precision", "recall"]


def accuracy(reference, test):
    """Fraction of positions at which two equal-length lists hold equal values."""
    reference = list(reference)
    test = list(test)
    if len(reference) != len(test):
        raise ValueError("accuracy needs lists of equal length (%d != %d)" % (len(reference), len(test)))
    if not reference:
        raise ValueError("accuracy of two empty lists is undefined")
    return sum(1 for a, b in zip(reference, test) if a == b) / len(reference)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Levenshtein distance; with ``transpositions`` the unrestricted Damerau-Levenshtein distance."""
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("edit_distance arguments must be str")
    if isinstance(substitution_cost, bool) or not isinstance(substitution_cost, (int, float)):
        raise TypeError("substitution_cost must be a number")
    if not transpositions:
        return _levenshtein(s1, s2, substitution_cost)
    return _damerau(s1, s2, substitution_cost)


def _levenshtein(a, b, sub):
    previous = [j for j in range(len(b) + 1)]
    for i in range(1, len(a) + 1):
        current = [i] + [0] * len(b)
        for j in range(1, len(b) + 1):
            cost = 0 if a[i - 1] == b[j - 1] else sub
            current[j] = min(previous[j] + 1, current[j - 1] + 1, previous[j - 1] + cost)
        previous = current
    return previous[len(b)]


def _damerau(a, b, sub):
    """Unrestricted Damerau-Levenshtein distance (Lowrance and Wagner, 1975)."""
    maxdist = len(a) + len(b)
    last_row = {}
    d = [[0] * (len(b) + 2) for _ in range(len(a) + 2)]
    d[0][0] = maxdist
    for i in range(len(a) + 1):
        d[i + 1][0] = maxdist
        d[i + 1][1] = i
    for j in range(len(b) + 1):
        d[0][j + 1] = maxdist
        d[1][j + 1] = j
    for i in range(1, len(a) + 1):
        last_match_col = 0
        for j in range(1, len(b) + 1):
            i1 = last_row.get(b[j - 1], 0)
            j1 = last_match_col
            cost = 0 if a[i - 1] == b[j - 1] else sub
            if cost == 0:
                last_match_col = j
            d[i + 1][j + 1] = min(
                d[i][j] + cost,
                d[i + 1][j] + 1,
                d[i][j + 1] + 1,
                d[i1][j1] + (i - i1 - 1) + 1 + (j - j1 - 1),
            )
        last_row[a[i - 1]] = i
    result = d[len(a) + 1][len(b) + 1]
    return int(result) if float(result).is_integer() and isinstance(sub, int) else result


def jaccard_distance(label1, label2):
    """1 - |A intersect B| / |A union B|; two empty sets have distance 0."""
    if not isinstance(label1, (set, frozenset)) or not isinstance(label2, (set, frozenset)):
        raise TypeError("jaccard_distance arguments must be sets")
    union = len(label1 | label2)
    if union == 0:
        return 0.0
    return (union - len(label1 & label2)) / union


def _check_sets(reference, test):
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        raise TypeError("precision, recall and f_measure need set or frozenset arguments")


def precision(reference, test):
    """|reference ∩ test| / |test|; None when ``test`` is empty."""
    _check_sets(reference, test)
    if not test:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    """|reference ∩ test| / |reference|; None when ``reference`` is empty."""
    _check_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    """Weighted harmonic mean of precision and recall; None when either set is empty."""
    _check_sets(reference, test)
    if not reference or not test:
        return None
    p = precision(reference, test)
    r = recall(reference, test)
    if p == 0 or r == 0:
        return 0.0
    return 1.0 / (alpha / p + (1 - alpha) / r)
