"""Stemmers: Porter (three modes), Lancaster (Paice/Husk), Snowball, a
regular-expression stemmer, and the resource-gated ISRI/ARLSTem/WordNet entries."""

import re

from lingora import data

__all__ = [
    "ARLSTem",
    "ARLSTem2",
    "LancasterStemmer",
    "PorterStemmer",
    "RegexpStemmer",
    "SnowballStemmer",
    "WordNetLemmatizer",
]

SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german",
    "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
    "russian", "spanish", "swedish",
)

_VOWELS = "aeiou"


# ---------------------------------------------------------------------------
# Porter
# ---------------------------------------------------------------------------

_PORTER_IRREGULAR = {
    "sky": "sky", "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie",
    "tying": "tie", "idly": "idl", "gently": "gentl", "ugly": "ugli",
    "early": "earli", "only": "onli", "singly": "singl", "news": "news",
    "innings": "inning", "inning": "inning", "outings": "outing",
    "outing": "outing", "cannings": "can", "canning": "can",
    "herring": "herring", "herrings": "herring", "earring": "earring",
    "earrings": "earring", "proceed": "proceed", "exceed": "exceed",
    "succeed": "succeed",
}

_STEP2_ORIGINAL = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("abli", "able"), ("alli", "al"), ("entli", "ent"),
    ("eli", "e"), ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"),
    ("ator", "ate"), ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"),
    ("ousness", "ous"), ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"),
]

# LINGORA: -abli -> -able is replaced by -bli -> -ble, and -fulli and -logi are added.
_STEP2_LINGORA = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("bli", "ble"), ("alli", "al"), ("fulli", "ful"),
    ("entli", "ent"), ("eli", "e"), ("ousli", "ous"), ("ization", "ize"),
    ("ation", "ate"), ("ator", "ate"), ("alism", "al"), ("iveness", "ive"),
    ("fulness", "ful"), ("ousness", "ous"), ("aliti", "al"), ("iviti", "ive"),
    ("biliti", "ble"), ("logi", "log"),
]

_STEP3 = [
    ("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"),
    ("ical", "ic"), ("ful", ""), ("ness", ""),
]

_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment",
    "ent", "ion", "ou", "ism", "ate", "iti", "ous", "ive", "ize",
]


def _is_consonant(word, i):
    ch = word[i]
    if ch in "aeiou":
        return False
    if ch == "y":
        return i == 0 or not _is_consonant(word, i - 1)
    return True


def _measure(stem):
    """Porter's m: the number of VC sequences in the stem."""
    m = 0
    i = 0
    n = len(stem)
    while i < n and _is_consonant(stem, i):
        i += 1
    while i < n:
        while i < n and not _is_consonant(stem, i):
            i += 1
        if i >= n:
            break
        m += 1
        while i < n and _is_consonant(stem, i):
            i += 1
    return m


def _contains_vowel(stem):
    return any(not _is_consonant(stem, i) for i in range(len(stem)))


def _ends_double_consonant(word):
    return len(word) >= 2 and word[-1] == word[-2] and _is_consonant(word, len(word) - 1)


def _ends_cvc(word):
    """*o: stem ends consonant-vowel-consonant, final consonant not w, x or y."""
    n = len(word)
    if n == 2:
        return (not _is_consonant(word, 0)) and _is_consonant(word, 1) and word[1] not in "wxy"
    if n < 3:
        return False
    return (
        _is_consonant(word, n - 3)
        and not _is_consonant(word, n - 2)
        and _is_consonant(word, n - 1)
        and word[-1] not in "wxy"
    )


class PorterStemmer:
    """Porter's suffix-stripping algorithm.

    ``mode`` is ``"lingora"`` (default), ``"original"`` (Porter 1980) or
    ``"martin"`` (original plus the Martin extensions, approximated here).
    """

    ORIGINAL = "original"
    MARTIN = "martin"
    LINGORA = "lingora"

    def __init__(self, mode=LINGORA):
        if mode not in (self.ORIGINAL, self.MARTIN, self.LINGORA):
            raise ValueError("unknown Porter mode %r" % (mode,))
        self.mode = mode

    def stem(self, word, to_lowercase=True):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        lingora = self.mode == self.LINGORA
        if to_lowercase:
            word = word.lower()
        if lingora and word in _PORTER_IRREGULAR:
            return _PORTER_IRREGULAR[word]
        if len(word) <= 2:
            return word
        word = self._step1a(word, lingora)
        word = self._step1b(word, lingora)
        word = self._step1c(word, lingora)
        word = self._step2(word, lingora)
        word = self._step3(word)
        word = self._step4(word)
        word = self._step5(word)
        return word

    # Step 1a
    def _step1a(self, w, lingora):
        if w.endswith("sses"):
            return w[:-2]
        if w.endswith("ies"):
            if lingora and len(w) == 4:
                return w[:-1]
            return w[:-2]
        if w.endswith("ss"):
            return w
        if w.endswith("s"):
            return w[:-1]
        return w

    # Step 1b
    def _step1b(self, w, lingora):
        if lingora and w.endswith("ied"):
            return w[:-1] if len(w) == 4 else w[:-2]
        if w.endswith("eed"):
            if _measure(w[:-3]) > 0:
                return w[:-1]
            return w
        for suffix in ("ed", "ing"):
            if w.endswith(suffix):
                stem = w[: -len(suffix)]
                if not _contains_vowel(stem):
                    return w
                return self._step1b_fix(stem)
        return w

    def _step1b_fix(self, w):
        if w.endswith(("at", "bl", "iz")):
            return w + "e"
        if _ends_double_consonant(w) and w[-1] not in "lsz":
            return w[:-1]
        if _measure(w) == 1 and _ends_cvc(w):
            return w + "e"
        return w

    # Step 1c
    def _step1c(self, w, lingora):
        if not w.endswith("y"):
            return w
        stem = w[:-1]
        if lingora:
            if len(stem) >= 2 and _is_consonant(stem, len(stem) - 1):
                return stem + "i"
            return w
        if _contains_vowel(stem):
            return stem + "i"
        return w

    # Step 2
    def _step2(self, w, lingora):
        if lingora and w.endswith("alli") and _measure(w[:-4]) > 0:
            return self._step2(w[:-4] + "al", lingora)
        table = _STEP2_LINGORA if lingora else _STEP2_ORIGINAL
        for suffix, replacement in table:
            if w.endswith(suffix):
                stem = w[: -len(suffix)]
                if _measure(stem) > 0:
                    return stem + replacement
                return w
        return w

    # Step 3
    def _step3(self, w):
        for suffix, replacement in _STEP3:
            if w.endswith(suffix):
                stem = w[: -len(suffix)]
                if _measure(stem) > 0:
                    return stem + replacement
                return w
        return w

    # Step 4
    def _step4(self, w):
        for suffix in _STEP4:
            if w.endswith(suffix):
                stem = w[: -len(suffix)]
                if suffix == "ion":
                    if _measure(stem) > 1 and stem[-1:] in ("s", "t"):
                        return stem
                    return w
                if _measure(stem) > 1:
                    return stem
                return w
        return w

    # Step 5
    def _step5(self, w):
        if w.endswith("e"):
            stem = w[:-1]
            m = _measure(stem)
            if m > 1 or (m == 1 and not _ends_cvc(stem)):
                w = stem
        if w.endswith("ll") and _measure(w) > 1:
            w = w[:-1]
        return w


# ---------------------------------------------------------------------------
# Lancaster (Paice/Husk)
# ---------------------------------------------------------------------------

# Each rule: reversed suffix letters, optional "*" (word must be intact), a digit
# (letters removed from the end), appended letters, and a terminator:
# "." stops the algorithm after the rule, ">" continues with the rules again.
_LANCASTER_RULES = [
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>", "cn1t>", "dd1.", "dei3y>",
    "deec2ss.", "dee1.", "de2>", "dooh4>", "e1>", "feil1v.", "fi2>", "gni3>",
    "gai3y.", "ga2>", "gg1.", "ht*2.", "hsiug5ct.", "hsi3>", "i*1.", "i1y>",
    "ji1d.", "juf1s.", "ju1d.", "jo1d.", "jeh1r.", "jrev1t.", "jsim2t.", "jn1d.",
    "j1s.", "lbaifi6.", "lbai4y.", "lba3.", "lbi3.", "lib2l>", "lc1.", "lufi4y.",
    "lu2.", "lai3y>", "lau3.", "la2>", "ll1.", "mui3.", "mu*2.", "msi3.", "mm1.",
    "nois4j>", "noix4ct.", "noi3>", "nai3>", "na2>", "nee0.", "ne2+", "nn1.",
    "pihs4>", "pp1.", "re2>", "rae0.", "ra2.", "ro2q>", "ru2>", "rr1.", "rt1>",
    "rei3y>", "sei3y>", "sis2.", "si2>", "ssen4>", "ss0.", "suo3>", "su*2.",
    "s*1>", "s0.", "tacilp4y.", "ta2>", "tnem4>", "tne3>", "tna3>", "tpir2b.",
    "tpro2b.", "tcud1.", "tpmus2.", "tpec2iv.", "tulo2v.", "tsis0.", "tsi3>",
    "tt1.", "uqi3.", "ugo1.", "vis3j>", "vie5.", "vi2>", "ylb1>", "yli3y>",
    "ylp0.", "yl2>", "ygo1.", "yhp1.", "ymo1.", "ypo1.", "yti3>", "yte3>",
    "ytl2.", "yrtsi5.", "yra3>", "yro3>", "yfi3.", "ycn2t>", "yca3>", "zi2>",
    "zy1s.",
]


def _parse_lancaster_rule(text):
    match = re.fullmatch(r"([a-z]+)(\*?)(\d)([a-z]*)([.>+])", text)
    if match is None:
        raise ValueError("bad Lancaster rule %r" % text)
    letters, intact, digit, append, terminator = match.groups()
    return {
        "suffix": letters[::-1],
        "intact": intact == "*",
        "remove": int(digit),
        "append": append,
        "continue": terminator == ">" or terminator == "+",
    }


_LANCASTER_PARSED = [_parse_lancaster_rule(rule) for rule in _LANCASTER_RULES]


def _lancaster_acceptable(word):
    if word and word[0] in "aeiouy":
        return len(word) >= 2
    return len(word) >= 3 and re.search("[aeiouy]", word) is not None


class LancasterStemmer:
    """Paice/Husk stemmer with the standard rule table."""

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        word = word.lower()
        intact = True
        while True:
            for rule in _LANCASTER_PARSED:
                if not word.endswith(rule["suffix"]):
                    continue
                if rule["intact"] and not intact:
                    continue
                keep = len(word) - rule["remove"]
                if keep < 0:
                    continue
                candidate = word[:keep] + rule["append"]
                if not _lancaster_acceptable(candidate):
                    continue
                word = candidate
                intact = False
                if rule["continue"]:
                    break
                return word
            else:
                return word


# ---------------------------------------------------------------------------
# Snowball (English = Porter2; porter = original Porter)
# ---------------------------------------------------------------------------

_E2_EXCEPTION1 = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli",
    "only": "onli", "singly": "singl", "sky": "sky", "news": "news",
    "howe": "howe", "atlas": "atlas", "cosmos": "cosmos", "bias": "bias",
    "andes": "andes",
}
_E2_EXCEPTION2 = {
    "inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed",
}
_E2_VOWELS = "aeiouy"
_E2_LI_ENDINGS = "cdeghkmnrt"


def _e2_regions(w):
    """Return (R1, R2) start indices of a Porter2 word."""
    r1 = None
    for prefix in ("gener", "commun", "arsen"):
        if w.startswith(prefix):
            r1 = len(prefix)
            break
    if r1 is None:
        r1 = len(w)
        for i in range(1, len(w)):
            if w[i] not in _E2_VOWELS and w[i - 1] in _E2_VOWELS:
                r1 = i + 1
                break
    r2 = len(w)
    for i in range(r1 + 1, len(w)):
        if w[i] not in _E2_VOWELS and w[i - 1] in _E2_VOWELS:
            r2 = i + 1
            break
    return r1, r2


def _e2_ends_short(w):
    if len(w) >= 3:
        if w[-3] not in _E2_VOWELS and w[-2] in _E2_VOWELS and w[-1] not in _E2_VOWELS and w[-1] not in "wxY":
            return True
    if len(w) == 2 and w[0] in _E2_VOWELS and w[1] not in _E2_VOWELS:
        return True
    return False


def _snowball_english(word):
    if word in _E2_EXCEPTION1:
        return _E2_EXCEPTION1[word]
    if len(word) <= 2:
        return word
    w = word[1:] if word.startswith("'") else word
    chars = list(w)
    for i, ch in enumerate(chars):
        if ch == "y" and (i == 0 or chars[i - 1] in _E2_VOWELS):
            chars[i] = "Y"
    w = "".join(chars)
    r1, r2 = _e2_regions(w)

    # Step 0
    for suffix in ("'s'", "'s", "'"):
        if w.endswith(suffix):
            w = w[: -len(suffix)]
            break

    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith("ied") or w.endswith("ies"):
        w = w[:-3] + ("i" if len(w) > 4 else "ie")
    elif w.endswith(("us", "ss")):
        pass
    elif w.endswith("s"):
        if any(c in _E2_VOWELS for c in w[:-2]):
            w = w[:-1]

    if w in _E2_EXCEPTION2:
        return w.replace("Y", "y")

    # Step 1b
    if w.endswith(("eed", "eedly")):
        suffix = "eedly" if w.endswith("eedly") else "eed"
        if len(w) - len(suffix) >= r1:
            w = w[: -len(suffix)] + "ee"
    else:
        for suffix in ("ingly", "edly", "ing", "ed"):
            if w.endswith(suffix):
                stem = w[: -len(suffix)]
                if any(c in _E2_VOWELS for c in stem):
                    w = stem
                    if w.endswith(("at", "bl", "iz")):
                        w += "e"
                    elif w[-2:] in ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt"):
                        w = w[:-1]
                    elif len(w) <= r1 and _e2_ends_short(w):
                        w += "e"
                break

    # Step 1c
    if len(w) > 2 and w[-1] in "yY" and w[-2] not in _E2_VOWELS:
        w = w[:-1] + "i"

    # Step 2 (in R1)
    step2 = [
        ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
        ("abli", "able"), ("entli", "ent"), ("izer", "ize"), ("ization", "ize"),
        ("ation", "ate"), ("ator", "ate"), ("alism", "al"), ("aliti", "al"),
        ("alli", "al"), ("fulness", "ful"), ("ousli", "ous"), ("ousness", "ous"),
        ("iveness", "ive"), ("iviti", "ive"), ("biliti", "ble"), ("logi", "log"),
        ("fulli", "ful"), ("lessli", "less"),
    ]
    for suffix, replacement in step2:
        if w.endswith(suffix):
            if len(w) - len(suffix) >= r1:
                w = w[: -len(suffix)] + replacement
            break
    else:
        if w.endswith("li") and len(w) - 2 >= r1 and len(w) >= 3 and w[-3] in _E2_LI_ENDINGS:
            w = w[:-2]

    # Step 3 (R1; ative in R2)
    step3 = [("tional", "tion"), ("ational", "ate"), ("alize", "al"), ("icate", "ic"),
             ("iciti", "ic"), ("ical", "ic"), ("ative", ""), ("ful", ""), ("ness", "")]
    for suffix, replacement in step3:
        if w.endswith(suffix):
            region = r2 if suffix == "ative" else r1
            if len(w) - len(suffix) >= region:
                w = w[: -len(suffix)] + replacement
            break

    # Step 4 (R2)
    step4 = ["al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment",
             "ent", "ism", "ate", "iti", "ous", "ive", "ize", "ion"]
    for suffix in step4:
        if w.endswith(suffix):
            if len(w) - len(suffix) >= r2:
                if suffix == "ion":
                    if w[-4:-3] in ("s", "t"):
                        w = w[:-3]
                else:
                    w = w[: -len(suffix)]
            break

    # Step 5
    if w.endswith("e"):
        base = len(w) - 1
        if base >= r2 or (base >= r1 and not _e2_ends_short(w[:-1])):
            w = w[:-1]
    elif w.endswith("l") and len(w) - 1 >= r2 and w[-2:-1] == "l":
        w = w[:-1]

    return w.replace("Y", "y")


class SnowballStemmer:
    """Snowball stemmers.  Supported here: ``english`` (Porter2) and ``porter``
    (original Porter).  The other language names of the Snowball list are
    accepted but their algorithms are not implemented in this build."""

    IMPLEMENTED = ("english", "porter")

    def __init__(self, language, ignore_stopwords=False):
        if language not in SNOWBALL_LANGUAGES:
            raise ValueError("unsupported Snowball language %r" % (language,))
        if language not in self.IMPLEMENTED:
            raise NotImplementedError(
                "Snowball algorithm for %r is not implemented in this build" % language
            )
        self.language = language
        self.ignore_stopwords = bool(ignore_stopwords)
        self._stopwords = None
        if self.ignore_stopwords:
            location = data.find("corpora/stopwords/" + language)
            with open(location, encoding="utf-8") as handle:
                self._stopwords = {line.strip() for line in handle if line.strip()}

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        word = word.lower()
        if self._stopwords is not None and word in self._stopwords:
            return word
        if self.language == "porter":
            return PorterStemmer(PorterStemmer.ORIGINAL).stem(word, to_lowercase=False)
        return _snowball_english(word)


# ---------------------------------------------------------------------------
# Regular-expression stemmer
# ---------------------------------------------------------------------------

class RegexpStemmer:
    """Removes every match of ``regexp`` from the word and changes nothing else."""

    def __init__(self, regexp):
        self.pattern = regexp
        self._regexp = re.compile(regexp)

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("word must be a str")
        return self._regexp.sub("", word)


# ---------------------------------------------------------------------------
# Resource-gated and out-of-specification entries
# ---------------------------------------------------------------------------

class WordNetLemmatizer:
    """Requires the WordNet resource.  Lemmatization itself is not implemented here."""

    def __init__(self):
        data.find("corpora/wordnet")
        raise NotImplementedError("WordNet lemmatization is not implemented in this build")

    def lemmatize(self, word):  # pragma: no cover - construction always fails
        raise NotImplementedError("WordNet lemmatization is not implemented in this build")


class ARLSTem:
    """Arabic light stemmer.  Exists in the product; its algorithm is not implemented here."""

    def __init__(self, *args, **kwargs):
        pass

    def stem(self, word):
        raise NotImplementedError("ARLSTem is not implemented in this build")


class ARLSTem2(ARLSTem):
    """Second Arabic light stemmer.  Not implemented in this build."""
