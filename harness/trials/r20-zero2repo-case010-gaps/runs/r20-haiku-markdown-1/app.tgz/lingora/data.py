"""Packaged-resource finder.

``path`` is the list of directories searched for packaged resources
(Punkt models, averaged perceptron taggers, stopword lists, ...).  Callers
may replace its contents in place; the module never rebinds it.

Initial contents: the entries of the ``LINGORA_DATA`` environment variable
(separated by ``os.pathsep``), or an empty list when that variable is unset.
An empty list means no packaged resource is visible.
"""

import os

__all__ = ["path", "ResourceNotFoundError", "find", "find_or_none", "exists"]


class ResourceNotFoundError(LookupError):
    """A packaged resource is not visible on ``data.path``."""


def _initial_path():
    value = os.environ.get("LINGORA_DATA", "")
    return [entry for entry in value.split(os.pathsep) if entry]


path = _initial_path()


def find_or_none(relpath):
    """Return the first existing ``<dir>/<relpath>`` on ``path``, or None."""
    for directory in list(path):
        candidate = os.path.join(directory, relpath)
        if os.path.exists(candidate):
            return candidate
    return None


def exists(relpath):
    """True when the packaged resource ``relpath`` is visible."""
    return find_or_none(relpath) is not None


def find(relpath):
    """Return the location of the packaged resource ``relpath``.

    Raises ``ResourceNotFoundError`` when no directory on ``path`` holds it.
    """
    location = find_or_none(relpath)
    if location is None:
        raise ResourceNotFoundError(
            "packaged resource %r is not installed in any directory of lingora.data.path"
            % relpath
        )
    return location
