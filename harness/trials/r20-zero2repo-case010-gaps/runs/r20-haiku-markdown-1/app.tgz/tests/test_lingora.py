"""Regression checks for LINGORA. Run from /app with: python -m pytest tests"""

import io
import sys

import pytest

from lingora import data
from lingora.classify import DecisionTreeClassifier, NaiveBayesClassifier
from lingora.chunk import RegexpParser
from lingora.grammar import CFG
from lingora.metrics import accuracy, edit_distance, f_measure, jaccard_distance, precision, recall
from lingora.parse import ChartParser, ShiftReduceParser
from lingora.parse.generate import generate
from lingora.stem import LancasterStemmer, PorterStemmer, RegexpStemmer, SnowballStemmer
from lingora.tag import DefaultTagger, RegexpTagger, UnigramTagger
from lingora.tokenize import (
    RegexpTokenizer, TreebankWordTokenizer, TweetTokenizer, WhitespaceTokenizer,
    WordPunctTokenizer, blankline_tokenize, sent_tokenize, word_tokenize, wordpunct_tokenize,
)
from lingora.translate import bleu
from lingora.tree import Tree
from lingora.cli import cli


def test_wordpunct_and_treebank():
    assert wordpunct_tokenize("Hello, world! $3.50") == ["Hello", ",", "world", "!", "$", "3", ".", "50"]
    assert TreebankWordTokenizer().tokenize("I can't go, gonna") == ["I", "ca", "n't", "go", ",", "gon", "na"]
    assert TreebankWordTokenizer().tokenize('He said "hi".') == ["He", "said", "``", "hi", "''", "."]
    assert wordpunct_tokenize("") == [] and TreebankWordTokenizer().tokenize("   ") == []


def test_other_tokenizers():
    assert WhitespaceTokenizer().tokenize(" a  b\tc ") == ["a", "b", "c"]
    assert blankline_tokenize("a b\n\n\n c\nd") == ["a b", "c\nd"]
    assert RegexpTokenizer(r"\d+", gaps=True).tokenize("a1b22c") == ["a", "b", "c"]
    assert RegexpTokenizer(r"\w+").tokenize("a b") == ["a", "b"]
    assert TweetTokenizer().tokenize("Café can't :)") == ["Café", "can't", ":)"]
    assert TweetTokenizer(preserve_case=False).tokenize("Café :D") == ["café", ":D"]
    assert TweetTokenizer(strip_handles=True).tokenize("hi @bob") == ["hi"]
    assert TweetTokenizer(reduce_len=True).tokenize("wooooow") == ["wooow"]
    assert list(WordPunctTokenizer().span_tokenize("ab c")) == [(0, 2), (3, 4)]


def test_missing_punkt_raises(monkeypatch):
    monkeypatch.setattr(data, "path", [])
    with pytest.raises(LookupError):
        sent_tokenize("A sentence.")
    with pytest.raises(LookupError):
        word_tokenize("A sentence.")
    assert word_tokenize("A sentence.", preserve_line=True) == ["A", "sentence", "."]


def test_missing_punkt_cli_fails(monkeypatch, capsys):
    monkeypatch.setattr(data, "path", [])
    monkeypatch.setattr(sys, "stdin", io.StringIO("text\n"))
    status = cli.main(args=["tokenize"], standalone_mode=False)
    assert status != 0
    assert capsys.readouterr().out == ""


def test_stemmers():
    porter = PorterStemmer()
    assert porter.stem("caresses") == "caress"
    assert porter.stem("ponies") == "poni"
    assert porter.stem("generalization") == "gener"
    assert porter.stem("is") == "is"
    assert LancasterStemmer().stem("maximum") == "maxim"
    assert LancasterStemmer().stem("presumably") == "presum"
    english = SnowballStemmer("english")
    assert english.stem("generously") == "generous"
    assert english.stem("running") == "run"
    assert english.stem("ties") == "tie"
    assert RegexpStemmer("ing$").stem("running") == "runn"
    with pytest.raises(ValueError):
        SnowballStemmer("klingon")


def test_snowball_stopwords_need_list(monkeypatch):
    monkeypatch.setattr(data, "path", [])
    with pytest.raises(LookupError):
        SnowballStemmer("english", ignore_stopwords=True)


def test_taggers():
    assert DefaultTagger("NN").tag(["a", "b"]) == [("a", "NN"), ("b", "NN")]
    unigram = UnigramTagger([[("a", "DT"), ("b", "NN")], [("a", "DT")]], backoff=DefaultTagger("X"))
    assert unigram.tag(["a", "b", "c"]) == [("a", "DT"), ("b", "NN"), ("c", "X")]
    assert RegexpTagger([(r"\d+", "CD")]).tag(["12", "x"]) == [("12", "CD"), ("x", None)]


def test_chunking_cascade_and_chink():
    tagged = [("the", "DT"), ("dog", "NN"), ("barked", "VBD"), ("at", "IN"), ("the", "DT"), ("cat", "NN")]
    tree = RegexpParser("NP: {<DT><NN>}\nVP: {<VBD><IN><NP>}").parse(tagged)
    assert [c.label() for c in tree if isinstance(c, Tree)] == ["NP", "VP"]
    assert tree.leaves() == tagged
    chunked = RegexpParser("NP: {<.*>+}\n}<VBD|IN>{").parse(tagged)
    assert [c.label() for c in chunked if isinstance(c, Tree)] == ["NP", "NP"]


def test_trees():
    t = Tree.fromstring("(S (NP (D the) (N dog)) (VP barks))")
    assert t.label() == "S" and len(t) == 2 and t.leaves() == ["the", "dog", "barks"]
    assert t == Tree("S", [Tree("NP", [Tree("D", ["the"]), Tree("N", ["dog"])]), Tree("VP", ["barks"])])
    assert Tree("X", []) == Tree("X", []) and len(Tree("X", [])) == 0
    with pytest.raises(TypeError):
        Tree("X", "abc")
    with pytest.raises(TypeError):
        Tree("X")


def test_parsers_and_generator():
    grammar = CFG.fromstring("S -> S S | 'a'")
    assert len(list(ChartParser(grammar).parse(["a", "a", "a"]))) == 2
    assert list(ChartParser(grammar).parse([])) == []
    with pytest.raises(ValueError):
        list(ChartParser(grammar).parse(["zzz"]))
    simple = CFG.fromstring("S -> NP VP\nNP -> 'John'\nVP -> 'runs'")
    assert list(ShiftReduceParser(simple).parse(["John", "runs"])) == list(ChartParser(simple).parse(["John", "runs"]))
    assert list(generate(CFG.fromstring("S -> 'a' S | 'b'"), depth=3)) == [["a", "a", "b"], ["a", "b"], ["b"]]
    assert len(list(generate(CFG.fromstring("S -> 'a' S | 'b'"), n=4))) == 4


def test_classifiers():
    nb = NaiveBayesClassifier.train([({"w": "good"}, "pos"), ({"w": "bad"}, "neg")])
    assert nb.classify({"w": "good"}) == "pos"
    probs = nb.prob_classify({"w": "bad"})
    assert abs(sum(probs.prob(label) for label in probs.samples()) - 1.0) < 1e-9
    dt = DecisionTreeClassifier.train([({"a": 1}, "x"), ({"a": 0}, "y")])
    assert dt.classify({"a": 1}) == "x" and dt.classify({"a": 0}) == "y"
    assert accuracy([1, 2, 3], [1, 0, 3]) == pytest.approx(2 / 3)
    with pytest.raises(ValueError):
        accuracy([1], [1, 2])


def test_metrics_and_bleu():
    assert edit_distance("kitten", "sitting") == 3
    assert edit_distance("ca", "abc", transpositions=True) == 2
    assert edit_distance("", "") == 0
    assert jaccard_distance({1, 2}, {2, 3}) == pytest.approx(2 / 3)
    assert precision({1, 2}, set()) is None
    assert recall({1, 2}, {2, 3}) == 0.5
    assert f_measure({1, 2}, set()) is None
    with pytest.raises(TypeError):
        precision([1], {1})
    ref = ["the", "cat", "is", "on", "the", "mat"]
    assert bleu([ref], ref) == pytest.approx(1.0)
    assert bleu([["x", "y"]], ["a", "b"]) == 0.0
