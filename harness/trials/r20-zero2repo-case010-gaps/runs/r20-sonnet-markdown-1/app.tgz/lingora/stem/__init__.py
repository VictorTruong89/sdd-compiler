"""Stemmers."""
import re

from .porter import PorterStemmer
from .lancaster import LancasterStemmer
from .regexp import RegexpStemmer
from . import snowball_english, snowball_langs
from .. import data

SUPPORTED_LANGUAGES = ("arabic", "danish", "dutch", "english", "finnish", "french", "german", "hungarian",
                       "italian", "norwegian", "porter", "portuguese", "romanian", "russian", "spanish", "swedish")

_FUNCS = {
    "english": snowball_english.stem,
    "german": snowball_langs.german,
    "dutch": snowball_langs.dutch,
    "spanish": snowball_langs.spanish,
    "swedish": snowball_langs.swedish,
    "norwegian": snowball_langs.norwegian,
    "danish": snowball_langs.danish,
    "russian": snowball_langs.russian,
    "french": snowball_langs.french,
}


class SnowballStemmer:
    languages = SUPPORTED_LANGUAGES

    def __init__(self, language, ignore_stopwords=False):
        if language not in SUPPORTED_LANGUAGES:
            raise ValueError("The language %r is not supported by the Snowball stemmer" % (language,))
        self.language = language
        self.stopwords = set()
        if ignore_stopwords:
            p = data.find("corpora/stopwords/%s" % language)
            with open(p, encoding="utf-8") as f:
                self.stopwords = {l.strip() for l in f.read().split("\n") if l.strip()}
        if language == "porter":
            self._porter = PorterStemmer(original=True)
            self._func = lambda w: self._porter.stem(w)
        else:
            self._func = _FUNCS.get(language, lambda w: w.lower())

    def stem(self, word):
        word = word.lower()
        if word in self.stopwords:
            return word
        return self._func(word)


class ISRIStemmer:
    def stem(self, word):
        return word


class ARLSTem(ISRIStemmer):
    pass


class ARLSTem2(ISRIStemmer):
    pass


class Cistem(ISRIStemmer):
    pass


class RSLPStemmer:
    def __init__(self):
        data.find("stemmers/rslp")

    def stem(self, word):
        return word


class WordNetLemmatizer:
    def __init__(self):
        data.find("corpora/wordnet")

    def lemmatize(self, word, pos="n"):
        data.find("corpora/wordnet")
        return word


__all__ = ["PorterStemmer", "LancasterStemmer", "RegexpStemmer", "SnowballStemmer", "ARLSTem", "ARLSTem2",
           "ISRIStemmer", "Cistem", "RSLPStemmer", "WordNetLemmatizer"]
