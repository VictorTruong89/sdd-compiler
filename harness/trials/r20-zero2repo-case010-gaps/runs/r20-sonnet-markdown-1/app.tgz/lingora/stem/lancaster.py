import re

_RULES = ("ai*2.", "a*1.", "bb1.", "city3s.", "ci2>", "cn1t>", "dd1.", "dei3y>", "deec2ss.", "dee1.", "de2>",
          "dooh4>", "e1>", "feil1v.", "fi2>", "gni3>", "gai3y.", "ga2>", "gg1.", "ht*2.", "hsiug5ct.", "hsi3>",
          "i*1.", "i1y>", "ji1d.", "juf1s.", "ju1d.", "jo1d.", "jeh1r.", "jrev1t.", "jsim2t.", "jn1d.", "j1s.",
          "lbaifi6.", "lbai4y.", "lba3>", "lbi3.", "lib2l>", "lc1.", "lufi4y.", "luf3>", "lu2.", "lai3>", "lau3>",
          "la2>", "ll1.", "mui3.", "mu*2.", "msi3>", "mm1.", "nois4j>", "noix4ct.", "noi3>", "nai3>", "na2>",
          "nee0.", "ne2>", "nn1.", "pihs4>", "pp1.", "re2>", "rae0.", "ra2.", "ro2>", "ru2>", "rr1.", "rt1>",
          "rei3y>", "sei3y>", "sis2.", "si2>", "ssen4>", "ss0.", "suo3>", "su*2.", "s*1>", "s0.", "tacilp4y.",
          "ta2>", "tnem4>", "tne3>", "tna3>", "tpir2b.", "tpro2b.", "tcud1.", "tpmus2.", "tpec2iv.", "tulo2v.",
          "tsis0.", "tsi3>", "tt1.", "uqi3.", "ugo1.", "vis3j>", "vie0.", "vi2>", "ylb1>", "yli3y>", "ylp0.",
          "yl2>", "ygo1.", "yhp1.", "ymo1.", "ypo1.", "yti3>", "yte3>", "ytl2.", "yrtsi5.", "yra3>", "yro3>",
          "yfi3.", "ycn2t>", "yca3>", "zi2>", "zy1s.")
_RULE_RE = re.compile(r"^([a-z]+)(\*?)(\d)([a-z]*)([>.])$")


class LancasterStemmer:
    def __init__(self):
        self.rules = {}
        for r in _RULES:
            m = _RULE_RE.match(r)
            ending, intact, remove, append, cont = m.groups()
            self.rules.setdefault(ending[0], []).append((ending[::-1], bool(intact), int(remove), append, cont == ">"))

    @staticmethod
    def _acceptable(word, remove):
        if word[0] in "aeiouy":
            return len(word) - remove >= 2
        return len(word) - remove >= 3 and (word[1] in "aeiouy" or word[2] in "aeiouy")

    def stem(self, word):
        word = word.lower()
        if not word:
            return word
        intact = True
        proceed = True
        while proceed:
            proceed = False
            for ending, need_intact, remove, append, cont in self.rules.get(word[-1], ()):
                if not word.endswith(ending):
                    continue
                if need_intact and not intact:
                    continue
                if not self._acceptable(word, remove):
                    continue
                word = word[:len(word) - remove] + append
                intact = False
                proceed = cont and len(word) > 0
                break
            if not word:
                break
        return word

    def __repr__(self):
        return "<LancasterStemmer>"
