"""Snowball stemmers for non-English languages (compact implementations)."""


def _longest(word, sufs, start=0):
    best = None
    for s in sufs:
        if word.endswith(s) and len(word) - len(s) >= start and (best is None or len(s) > len(best)):
            best = s
    return best


def _r1r2(word, vowels, min_r1=0):
    n = len(word)

    def r_from(start):
        i = start
        while i < n and word[i] not in vowels:
            i += 1
        while i < n and word[i] in vowels:
            i += 1
        return min(i + 1, n) if i < n else n
    r1 = r_from(0)
    r2 = r_from(r1)
    if r1 < min_r1:
        r1 = min(min_r1, n)
    return r1, r2


# ---------------------------------------------------------------- German
def german(word):
    v = "aeiouyäöü"
    word = word.lower().replace("ß", "ss")
    chars = list(word)
    for i in range(1, len(chars) - 1):
        if chars[i] in "uy" and word[i - 1] in v and word[i + 1] in v:
            chars[i] = chars[i].upper()
    word = "".join(chars)
    r1, r2 = _r1r2(word, v, 3)
    # step 1
    cands = ["em", "ern", "er", "e", "en", "es"]
    if word.endswith("s") and len(word) > 1 and word[-2] in "bdfghklmnrt":
        cands.append("s")
    suf = _longest(word, cands, r1)
    if suf:
        word = word[:-len(suf)]
        if suf in ("e", "en", "es") and word.endswith("niss"):
            word = word[:-1]
    # step 2
    cands = ["en", "er", "est"]
    if word.endswith("st") and len(word) >= 6 and word[-3] in "bdfghklmnt":
        cands.append("st")
    suf = _longest(word, cands, r1)
    if suf:
        word = word[:-len(suf)]
    # step 3
    suf = _longest(word, ["end", "ung", "ig", "ik", "isch", "lich", "heit", "keit"], r2)
    if suf:
        base = word[:-len(suf)]
        if suf in ("end", "ung"):
            word = base
            if word.endswith("ig") and len(word) - 2 >= r2 and not word[:-2].endswith("e"):
                word = word[:-2]
        elif suf in ("ig", "ik", "isch"):
            if not base.endswith("e"):
                word = base
        elif suf in ("lich", "heit"):
            word = base
            s2 = _longest(word, ["er", "en"], r1)
            if s2:
                word = word[:-len(s2)]
        else:  # keit
            word = base
            s2 = _longest(word, ["lich", "ig"], r2)
            if s2:
                word = word[:-len(s2)]
    word = word.replace("U", "u").replace("Y", "y")
    return word.translate(str.maketrans("äöü", "aou"))


# ----------------------------------------------------------------- Dutch
def dutch(word):
    v = "aeiouyè"
    word = word.lower()
    word = word.translate(str.maketrans("äëïöüáéíóú", "aeiouaeiou"))
    chars = list(word)
    if chars and chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in v:
            chars[i] = "Y"
    for i in range(1, len(chars) - 1):
        if chars[i] == "i" and chars[i - 1] in v and chars[i + 1] in v:
            chars[i] = "I"
    word = "".join(chars)
    r1, r2 = _r1r2(word, v, 3)

    def undouble(w):
        return w[:-1] if w.endswith(("kk", "dd", "tt")) else w

    def valid_en(base):
        return bool(base) and base[-1] not in v and not base.endswith("gem")

    # step 1
    suf = _longest(word, ["heden", "ene", "en", "se", "s"], r1)
    if suf == "heden":
        word = word[:-5] + "heid"
    elif suf in ("en", "ene"):
        base = word[:-len(suf)]
        if valid_en(base):
            word = undouble(base)
    elif suf in ("se", "s"):
        base = word[:-len(suf)]
        if base and base[-1] not in v and base[-1] != "j":
            word = base
    # step 2
    e_found = False

    def step2(w):
        if w.endswith("e") and len(w) - 1 >= r1 and len(w) > 1 and w[-2] not in v:
            return undouble(w[:-1]), True
        return w, False
    word, e_found = step2(word)
    # step 3a
    if word.endswith("heid") and len(word) - 4 >= r2 and not word.endswith("cheid"):
        word = word[:-4]
        if word.endswith("en") and len(word) - 2 >= r1 and valid_en(word[:-2]):
            word = undouble(word[:-2])
    # step 3b
    suf = _longest(word, ["end", "ing", "ig", "lijk", "baar", "bar"], r2)
    if suf:
        base = word[:-len(suf)]
        if suf in ("end", "ing"):
            word = base
            if word.endswith("ig") and len(word) - 2 >= r2 and not word[:-2].endswith("e"):
                word = word[:-2]
            else:
                word = undouble(word)
        elif suf == "ig":
            if not base.endswith("e"):
                word = base
        elif suf == "lijk":
            word = base
            word, _ = step2(word)
        elif suf == "baar":
            word = base
        elif suf == "bar" and e_found:
            word = base
    # step 4
    if len(word) >= 4 and word[-1] not in v and word[-1] != "I" and word[-2] == word[-3] \
            and word[-2] in "aeou" and word[-4] not in v:
        word = word[:-2] + word[-1]
    return word.replace("I", "i").replace("Y", "y")


# --------------------------------------------------------------- Spanish
def spanish(word):
    v = "aeiouáéíóúü"
    word = word.lower()
    n = len(word)
    # RV
    def rv_of(w):
        if len(w) < 2:
            return len(w)
        if w[1] not in v:
            i = 2
            while i < len(w) and w[i] not in v:
                i += 1
            return min(i + 1, len(w))
        if w[0] in v and w[1] in v:
            i = 2
            while i < len(w) and w[i] in v:
                i += 1
            return min(i + 1, len(w))
        return min(3, len(w))
    rv = rv_of(word)
    r1, r2 = _r1r2(word, v)
    # step 0
    suf = _longest(word, ["selas", "selos", "sela", "selo", "las", "les", "los", "nos", "me", "se", "la", "le", "lo"], rv)
    if suf:
        base = word[:-len(suf)]
        for pre, rep in (("iéndo", "iendo"), ("ándo", "ando"), ("ár", "ar"), ("ér", "er"), ("ír", "ir")):
            if base.endswith(pre) and len(base) - len(pre) >= rv - 0 - 0 and len(base) - len(pre) + 0 >= 0:
                word = base[:-len(pre)] + rep
                break
        else:
            for pre in ("iendo", "ando", "ar", "er", "ir"):
                if base.endswith(pre) and len(base) - len(pre) >= rv:
                    word = base
                    break
            else:
                if base.endswith("yendo") and base[:-5].endswith("u") and len(base) - 5 >= rv:
                    word = base
    # step 1
    orig = word
    def endr(w, s, r):
        return w.endswith(s) and len(w) - len(s) >= r
    s1 = ["anza", "anzas", "ico", "ica", "icos", "icas", "ismo", "ismos", "able", "ables", "ible", "ibles",
          "ista", "istas", "oso", "osa", "osos", "osas", "amiento", "amientos", "imiento", "imientos",
          "adora", "ador", "ación", "adoras", "adores", "aciones", "ante", "antes", "ancia", "ancias",
          "logía", "logías", "ución", "uciones", "encia", "encias", "amente", "mente", "idad", "idades",
          "iva", "ivo", "ivas", "ivos"]
    suf = _longest(word, s1)
    done = False
    if suf:
        base = word[:-len(suf)]
        ok2 = len(word) - len(suf) >= r2
        if suf in ("anza", "anzas", "ico", "ica", "icos", "icas", "ismo", "ismos", "able", "ables", "ible", "ibles",
                   "ista", "istas", "oso", "osa", "osos", "osas", "amiento", "amientos", "imiento", "imientos"):
            if ok2:
                word, done = base, True
        elif suf in ("adora", "ador", "ación", "adoras", "adores", "aciones", "ante", "antes", "ancia", "ancias"):
            if ok2:
                word, done = base, True
                if endr(word, "ic", r2):
                    word = word[:-2]
        elif suf in ("logía", "logías"):
            if ok2:
                word, done = base + "log", True
        elif suf in ("ución", "uciones"):
            if ok2:
                word, done = base + "u", True
        elif suf in ("encia", "encias"):
            if ok2:
                word, done = base + "ente", True
        elif suf == "amente":
            if len(word) - len(suf) >= r1:
                word, done = base, True
                if endr(word, "iv", r2):
                    word = word[:-2]
                    if endr(word, "at", r2):
                        word = word[:-2]
                else:
                    for s in ("os", "ic", "ad"):
                        if endr(word, s, r2):
                            word = word[:-2]
                            break
        elif suf == "mente":
            if ok2:
                word, done = base, True
                for s in ("ante", "able", "ible"):
                    if endr(word, s, r2):
                        word = word[:-4]
                        break
        elif suf in ("idad", "idades"):
            if ok2:
                word, done = base, True
                for s in ("abil", "ic", "iv"):
                    if endr(word, s, r2):
                        word = word[:-len(s)]
                        break
        else:
            if ok2:
                word, done = base, True
                if endr(word, "at", r2):
                    word = word[:-2]
    if not done:
        # step 2a
        suf = _longest(word, ["yeron", "yendo", "yamos", "yais", "yan", "yen", "yas", "yes", "ya", "ye", "yo", "yó"], rv)
        if suf and word[:-len(suf)].endswith("u") and len(word) - len(suf) - 1 >= rv - 1 and len(word) - len(suf) >= rv:
            word = word[:-len(suf)]
        else:
            s2b = ["arían", "arías", "arán", "arás", "aríais", "aría", "aréis", "aríamos", "aremos", "ará", "aré",
                   "erían", "erías", "erán", "erás", "eríais", "ería", "eréis", "eríamos", "eremos", "erá", "eré",
                   "irían", "irías", "irán", "irás", "iríais", "iría", "iréis", "iríamos", "iremos", "irá", "iré",
                   "aba", "ada", "ida", "ía", "ara", "iera", "ad", "ed", "id", "ase", "iese", "aste", "iste", "an",
                   "aban", "ían", "aran", "ieran", "asen", "iesen", "aron", "ieron", "ado", "ido", "ando", "iendo",
                   "ió", "ar", "er", "ir", "as", "abas", "adas", "idas", "ías", "aras", "ieras", "ases", "ieses",
                   "ís", "áis", "abais", "íais", "arais", "ierais", "aseis", "ieseis", "asteis", "isteis", "ados",
                   "idos", "amos", "ábamos", "íamos", "imos", "áramos", "iéramos", "iésemos", "ásemos",
                   "en", "es", "éis", "emos"]
            suf = _longest(word, s2b, rv)
            if suf:
                word = word[:-len(suf)]
                if suf in ("en", "es", "éis", "emos") and word.endswith("gu") and len(word) - 1 >= rv:
                    word = word[:-1]
    # step 3
    suf = _longest(word, ["os", "a", "o", "á", "í", "ó", "e", "é"], rv)
    if suf:
        base = word[:-len(suf)]
        if suf in ("e", "é"):
            word = base
            if word.endswith("gu") and len(word) - 1 >= rv:
                word = word[:-1]
        else:
            word = base
    return word.translate(str.maketrans("áéíóú", "aeiou"))


# --------------------------------------------------------- Scandinavian
def swedish(word):
    v = "aeiouyäåö"
    word = word.lower()
    r1, _ = _r1r2(word, v, 3)
    suf = _longest(word, ["heterna", "hetens", "anden", "andes", "andet", "arens", "arnas", "ernas", "ornas", "ades",
                          "arna", "erna", "orna", "heten", "heter", "arne", "aste", "aren", "ande", "ade", "erns",
                          "arne", "ern", "het", "ast", "ens", "ar", "er", "or", "as", "es", "at", "ad", "en", "a", "e"] + ["s"], r1)
    if suf == "s":
        if len(word) > 1 and word[-2] in "bcdfghjklmnoprtvy":
            word = word[:-1]
    elif suf:
        word = word[:-len(suf)]
    if len(word) - 1 >= r1 and word.endswith(("dd", "gd", "nn", "dt", "gt", "kt", "tt")):
        word = word[:-1]
    suf = _longest(word, ["lig", "ig", "els", "löst", "fullt"], r1)
    if suf == "löst":
        word = word[:-1]
    elif suf == "fullt":
        word = word[:-1]
    elif suf:
        word = word[:-len(suf)]
    return word


def norwegian(word):
    v = "aeiouyæåø"
    word = word.lower()
    r1, _ = _r1r2(word, v, 3)
    suf = _longest(word, ["hetenes", "hetene", "hetens", "ande", "ende", "ede", "ane", "ene", "ens", "ers", "ets",
                          "het", "ast", "erte", "ert", "en", "et", "a", "e", "s"], r1)
    if suf == "s":
        if len(word) > 1 and (word[-2] in "bcdfghjlmnoprtvyz" or (word[-2] == "k" and len(word) > 2 and word[-3] not in v)):
            word = word[:-1]
    elif suf in ("erte", "ert"):
        word = word[:-len(suf)] + "er"
    elif suf:
        word = word[:-len(suf)]
    if len(word) - 1 >= r1 and word.endswith(("dt", "vt")):
        word = word[:-1]
    suf = _longest(word, ["hetslov", "eleg", "elig", "elov", "slov", "leg", "eig", "lig", "els", "lov", "ig"], r1)
    if suf:
        word = word[:-len(suf)]
    return word


def danish(word):
    v = "aeiouyæåø"
    word = word.lower()
    r1, _ = _r1r2(word, v, 3)

    def step2(w):
        return w[:-1] if len(w) - 1 >= r1 and w.endswith(("gd", "dt", "gt", "kt")) else w
    suf = _longest(word, ["erendes", "erende", "hedens", "ethed", "erede", "heden", "heder", "endes", "ernes", "erens",
                          "erets", "ered", "ende", "erne", "eren", "erer", "heds", "enes", "eres", "eret", "hed",
                          "ene", "ere", "ens", "ers", "ets", "en", "er", "es", "et", "e"], r1)
    if suf:
        word = word[:-len(suf)]
    elif word.endswith("s") and len(word) - 1 >= r1 and len(word) > 1 and word[-2] in "abcdfghjklmnoprtvyzå":
        word = word[:-1]
    word = step2(word)
    if word.endswith("igst") and len(word) - 4 >= r1 - 0:
        word = word[:-2]
    suf = _longest(word, ["elig", "lig", "els", "ig"], r1)
    if suf:
        word = word[:-len(suf)]
        word = step2(word)
    elif word.endswith("løst") and len(word) - 4 >= r1:
        word = word[:-1]
    if len(word) - 1 >= r1 and len(word) >= 2 and word[-1] == word[-2] and word[-1] not in v:
        word = word[:-1]
    return word


# --------------------------------------------------------------- Russian
_RV = "аеиоуыэюя"


def russian(word):
    word = word.lower().replace("ё", "е")
    m = 0
    for i, c in enumerate(word):
        if c in _RV:
            m = i + 1
            break
    else:
        return word
    pre, rv = word[:m], word[m:]
    r1 = 0
    n = len(word)
    i = 0
    while i < n and word[i] not in _RV:
        i += 1
    while i < n and word[i] in _RV:
        i += 1
    r1 = min(i + 1, n) if i < n else n
    i = r1
    while i < n and word[i] not in _RV:
        i += 1
    while i < n and word[i] in _RV:
        i += 1
    r2 = min(i + 1, n) if i < n else n

    def strip(w, g1, g2=()):
        """Return stripped RV, or None if nothing matched. g1 needs preceding а/я."""
        best = None
        for s in sorted(list(g1) + list(g2), key=len, reverse=True):
            if w.endswith(s):
                base = w[:-len(s)]
                if s in g1 and s not in g2:
                    if base[-1:] in ("а", "я"):
                        return base
                    continue
                return base
        return None
    pg1 = ["в", "вши", "вшись"]
    pg2 = ["ив", "ивши", "ившись", "ыв", "ывши", "ывшись"]
    def pg(w):
        for s in sorted(pg1 + pg2, key=len, reverse=True):
            if w.endswith(s):
                base = w[:-len(s)]
                if s in pg1 and s not in pg2:
                    if base[-1:] in ("а", "я"):
                        return base
                    continue
                return base
        return None
    adj = ["ее", "ие", "ые", "ое", "ими", "ыми", "ей", "ий", "ый", "ой", "ем", "им", "ым", "ом", "его", "ого",
           "ему", "ому", "их", "ых", "ую", "юю", "ая", "яя", "ою", "ею"]
    part1 = ["ем", "нн", "вш", "ющ", "щ"]
    part2 = ["ивш", "ывш", "ующ"]
    verb1 = ["ла", "на", "ете", "йте", "ли", "й", "л", "ем", "н", "ло", "но", "ет", "ют", "ны", "ть", "ешь", "нно"]
    verb2 = ["ила", "ыла", "ена", "ейте", "уйте", "ите", "или", "ыли", "ей", "уй", "ил", "ыл", "им", "ым", "ен", "ило",
             "ыло", "ено", "ят", "ует", "уют", "ит", "ыт", "ены", "ить", "ыть", "ишь", "ую", "ю"]
    noun = ["а", "ев", "ов", "ие", "ье", "е", "иями", "ями", "ами", "еи", "ии", "и", "ией", "ей", "ой", "ий", "й",
            "иям", "ям", "ием", "ем", "ам", "ом", "о", "у", "ах", "иях", "ях", "ы", "ь", "ию", "ью", "ю", "ия", "ья", "я"]

    def generic(w, g1, g2):
        for s in sorted(g1 + g2, key=len, reverse=True):
            if w.endswith(s):
                base = w[:-len(s)]
                if s in g2:
                    return base
                if base[-1:] in ("а", "я"):
                    return base
        return None

    def adjectival(w):
        for s in sorted(adj, key=len, reverse=True):
            if w.endswith(s):
                base = w[:-len(s)]
                p = generic(base, part1, part2)
                return base if p is None else p
        return None

    r = pg(rv)
    if r is None:
        refl = rv
        for s in ("ся", "сь"):
            if rv.endswith(s):
                refl = rv[:-2]
                break
        r = adjectival(refl)
        if r is None:
            r = generic(refl, verb1, verb2)
        if r is None:
            for s in sorted(noun, key=len, reverse=True):
                if refl.endswith(s):
                    r = refl[:-len(s)]
                    break
        if r is None:
            r = refl
    rv = r
    if rv.endswith("и"):
        rv = rv[:-1]
    # step 3 derivational in R2
    full = pre + rv
    for s in ("ость", "ост"):
        if full.endswith(s) and len(full) - len(s) >= r2:
            full = full[:-len(s)]
            break
    rv = full[len(pre):] if full.startswith(pre) else full
    # step 4
    if full.endswith("ь"):
        full = full[:-1]
    elif full.endswith(("ейше", "ейш")):
        full = full[:-4] if full.endswith("ейше") else full[:-3]
        if full.endswith("нн"):
            full = full[:-1]
    elif full.endswith("нн"):
        full = full[:-1]
    return full


# ---------------------------------------------------------------- French
def french(word):
    v = "aeiouyâàëéêèïîôûù"
    word = word.lower()
    ch = list(word)
    for i in range(len(ch)):
        c = ch[i]
        prev = word[i - 1] if i > 0 else ""
        nxt = word[i + 1] if i + 1 < len(word) else ""
        if c == "u" and prev == "q":
            ch[i] = "U"
        elif c in "ui" and prev in v and prev != "" and nxt in v and nxt != "":
            ch[i] = c.upper()
        elif c == "y" and ((prev and prev in v) or (nxt and nxt in v)):
            ch[i] = "Y"
        elif c in "ëï":
            ch[i] = "He" if c == "ë" else "Hi"
    word = "".join(ch)
    n = len(word)
    if word.startswith(("par", "col", "tap")):
        rv = 3
    elif n >= 2 and word[0] in v and word[1] in v:
        rv = 3
    else:
        rv = n
        for i in range(1, n):
            if word[i] in v:
                rv = i + 1
                break
    rv = min(rv, n)
    r1, r2 = _r1r2(word, v)
    low = lambda w: w

    def isv(c):
        return c != "" and c in v

    def endr(w, s, r):
        return w.endswith(s) and len(w) - len(s) >= r

    changed = False
    force2a = False
    sufs = ["issements", "issement", "atrices", "atrice", "ateurs", "ateur", "ations", "ation", "usions", "usion",
            "utions", "ution", "uctions", "uction", "logies", "logie", "ements", "ement", "ences", "ence", "ances",
            "ance", "iqUes", "iqUe", "ismes", "isme", "ables", "able", "istes", "iste", "eux", "ités", "ité",
            "ives", "ive", "ifs", "if", "euses", "euse", "eaux", "aux", "amment", "emment", "ments", "ment"]
    suf = _longest(word, sufs)
    w = word
    if suf:
        base = w[:-len(suf)]
        pos = len(base)
        if suf in ("ance", "ances", "iqUe", "iqUes", "isme", "ismes", "able", "ables", "iste", "istes", "eux"):
            if pos >= r2:
                w, changed = base, True
        elif suf in ("atrice", "atrices", "ateur", "ateurs", "ation", "ations"):
            if pos >= r2:
                w, changed = base, True
                if endr(w, "ic", r2):
                    w = w[:-2]
                elif w.endswith("ic"):
                    w = w[:-2] + "iqU"
        elif suf in ("logie", "logies"):
            if pos >= r2:
                w, changed = base + "log", True
        elif suf in ("usion", "usions", "ution", "utions", "uction", "uctions"):
            if pos >= r2:
                w, changed = base + "u", True
        elif suf in ("ence", "ences"):
            if pos >= r2:
                w, changed = base + "ent", True
        elif suf in ("ement", "ements"):
            if pos >= rv:
                w, changed = base, True
                if endr(w, "iv", r2):
                    w = w[:-2]
                    if endr(w, "at", r2):
                        w = w[:-2]
                elif w.endswith("eus"):
                    if len(w) - 3 >= r2:
                        w = w[:-3]
                    elif len(w) - 3 >= r1:
                        w = w[:-3] + "eux"
                elif endr(w, "abl", r2) or endr(w, "iqU", r2):
                    w = w[:-3]
                elif w.endswith(("ièr", "Ièr")) and len(w) - 3 >= rv:
                    w = w[:-3] + "i"
        elif suf in ("ité", "ités"):
            if pos >= r2:
                w, changed = base, True
                if w.endswith("abil"):
                    w = w[:-4] if len(w) - 4 >= r2 else w[:-4] + "abl"
                elif w.endswith("ic"):
                    w = w[:-2] if len(w) - 2 >= r2 else w[:-2] + "iqU"
                elif endr(w, "iv", r2):
                    w = w[:-2]
        elif suf in ("if", "ifs", "ive", "ives"):
            if pos >= r2:
                w, changed = base, True
                if endr(w, "at", r2):
                    w = w[:-2]
                    if endr(w, "ic", r2):
                        w = w[:-2]
                    elif w.endswith("ic"):
                        w = w[:-2] + "iqU"
        elif suf in ("euse", "euses"):
            if pos >= r2:
                w, changed = base, True
            elif pos >= r1:
                w, changed = base + "eux", True
        elif suf == "eaux":
            w, changed = base + "eau", True
        elif suf == "aux":
            if pos >= r1:
                w, changed = base + "al", True
        elif suf in ("issement", "issements"):
            if pos >= r1 and base and not isv(base[-1]):
                w, changed = base, True
        elif suf == "amment":
            if pos >= rv:
                w, changed, force2a = base + "ant", True, True
        elif suf == "emment":
            if pos >= rv:
                w, changed, force2a = base + "ent", True, True
        elif suf in ("ment", "ments"):
            if pos >= rv and base and isv(base[-1]) and pos - 1 >= rv:
                w, changed, force2a = base, True, True
    word = w
    if not changed or force2a:
        i_sufs = ["îmes", "îtes", "ît", "ies", "ie", "ir", "is", "it", "i"]
        # full list of i-suffixes
        i_sufs = ["issaIent", "issantes", "issante", "issants", "issant", "issions", "issiez", "issent", "isses",
                  "isse", "irions", "iriez", "irent", "irons", "iront", "iras", "irai", "ira", "irais", "irait",
                  "îmes", "îtes", "ît", "ies", "ie", "ir", "is", "it", "i"]
        suf = _longest(word, i_sufs)
        fired = False
        if suf:
            base = word[:-len(suf)]
            if len(base) >= rv and base and not isv(base[-1]) and base[-1] != "H":
                word, fired = base, True
        if not fired:
            e_sufs = ["assions", "assiez", "assent", "asses", "asse", "erions", "eriez", "erons", "eront", "erais",
                      "erait", "erai", "era", "erez", "erent", "èrent", "âmes", "âtes", "ées", "ée", "és", "ez",
                      "er", "ât", "ants", "ante", "antes", "ant", "ais", "ait", "aIent", "ai", "as", "a", "é"]
            suf = _longest(word, e_sufs + ["ions"])
            if suf == "ions":
                if len(word) - 4 >= r2:
                    word = word[:-4]
            elif suf:
                base = word[:-len(suf)]
                if len(base) >= rv:
                    word = base
                    if suf in ("âmes", "âtes", "ât", "a", "ai", "ais", "ait", "aIent", "as", "ant", "ante", "antes",
                               "ants", "assions", "assiez", "assent", "asses", "asse") and word.endswith("e") and len(word) - 1 >= rv:
                        word = word[:-1]
    elif changed:
        pass
    if changed or True:
        pass
    # step 3
    if word.endswith("Y"):
        word = word[:-1] + "i"
    elif word.endswith("ç"):
        word = word[:-1] + "c"
    # step 4 residual
    if len(word) > 1 and word.endswith("s") and word[-2] not in "aiouès":
        word = word[:-1]
    suf = _longest(word, ["ion", "ier", "ière", "Ier", "Ière", "e", "ë"])
    if suf == "ion":
        if len(word) - 3 >= r2 and len(word) - 3 >= rv and word[:-3][-1:] in ("s", "t"):
            word = word[:-3]
    elif suf in ("ier", "ière", "Ier", "Ière"):
        if len(word) - len(suf) >= rv:
            word = word[:-len(suf)] + "i"
    elif suf in ("e",):
        if len(word) - 1 >= rv:
            word = word[:-1]
    if word.endswith("gu") and len(word) - 1 >= rv and False:
        word = word[:-1]
    # step 5 undouble
    for s in ("enn", "onn", "ett", "ell", "eill"):
        if word.endswith(s):
            word = word[:-1]
            break
    # step 6 unaccent
    for i in range(len(word) - 1, -1, -1):
        if word[i] in "éè":
            if all(not isv(c) for c in word[i + 1:]) and i < len(word) - 1:
                word = word[:i] + "e" + word[i + 1:]
            break
        if isv(word[i]):
            break
    return word.replace("I", "i").replace("U", "u").replace("Y", "y").replace("He", "ë").replace("Hi", "ï")
