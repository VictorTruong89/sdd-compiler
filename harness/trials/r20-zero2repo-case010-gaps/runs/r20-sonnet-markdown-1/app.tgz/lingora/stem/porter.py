class PorterStemmer:
    """Porter stemmer, default (LINGORA extensions) mode."""

    def __init__(self, original=False):
        self.original = original
        self.pool = {}
        irregular = {
            "sky": ["sky", "skies"], "die": ["dying"], "lie": ["lying"], "tie": ["tying"],
            "news": ["news"], "inning": ["innings", "inning"], "outing": ["outings", "outing"],
            "canning": ["cannings", "canning"], "howe": ["howe"], "proceed": ["proceed"],
            "exceed": ["exceed"], "succeed": ["succeed"],
        }
        for key, vals in irregular.items():
            for v in vals:
                self.pool[v] = key

    def _is_consonant(self, word, i):
        if word[i] in "aeiou":
            return False
        if word[i] == "y":
            if i == 0:
                return True
            return not self._is_consonant(word, i - 1)
        return True

    def _measure(self, stem):
        seq = "".join("c" if self._is_consonant(stem, i) else "v" for i in range(len(stem)))
        return seq.count("vc")

    def _has_positive_measure(self, stem):
        return self._measure(stem) > 0

    def _contains_vowel(self, stem):
        return any(not self._is_consonant(stem, i) for i in range(len(stem)))

    def _ends_double_consonant(self, word):
        return len(word) >= 2 and word[-1] == word[-2] and self._is_consonant(word, len(word) - 1)

    def _ends_cvc(self, word):
        c = self._is_consonant
        return (len(word) >= 3 and c(word, len(word) - 3) and not c(word, len(word) - 2)
                and c(word, len(word) - 1) and word[-1] not in "wxy") or \
               (not self.original and len(word) == 2 and not c(word, 0) and c(word, 1))

    @staticmethod
    def _replace_suffix(word, suffix, replacement):
        if suffix == "":
            return word + replacement
        return word[:-len(suffix)] + replacement

    def _apply_rule_list(self, word, rules):
        for suffix, replacement, condition in rules:
            if suffix == "*d" and self._ends_double_consonant(word):
                stem = word[:-2]
                if condition is None or condition(stem):
                    return stem + replacement
                return word
            if word.endswith(suffix):
                stem = self._replace_suffix(word, suffix, "")
                if condition is None or condition(stem):
                    return stem + replacement
                return word
        return word

    def _step1a(self, word):
        if not self.original and word.endswith("ies") and len(word) == 4:
            return self._replace_suffix(word, "ies", "ie")
        return self._apply_rule_list(word, [("sses", "ss", None), ("ies", "i", None), ("ss", "ss", None), ("s", "", None)])

    def _step1b(self, word):
        if not self.original and word.endswith("ied"):
            return self._replace_suffix(word, "ied", "ie" if len(word) == 4 else "i")
        if word.endswith("eed"):
            stem = self._replace_suffix(word, "eed", "")
            return stem + "ee" if self._measure(stem) > 0 else word
        inter = None
        for suffix in ("ed", "ing"):
            if word.endswith(suffix):
                cand = self._replace_suffix(word, suffix, "")
                if self._contains_vowel(cand):
                    inter = cand
                    break
        if inter is None:
            return word
        last = inter[-1] if inter else ""
        return self._apply_rule_list(inter, [
            ("at", "ate", None), ("bl", "ble", None), ("iz", "ize", None),
            ("*d", last, lambda stem: last not in ("l", "s", "z")),
            ("", "e", lambda stem: self._measure(stem) == 1 and self._ends_cvc(stem)),
        ])

    def _step1c(self, word):
        if self.original:
            return self._apply_rule_list(word, [("y", "i", self._contains_vowel)])
        return self._apply_rule_list(word, [("y", "i", lambda stem: len(stem) > 1 and self._is_consonant(stem, len(stem) - 1))])

    def _step2(self, word):
        pm = self._has_positive_measure
        if not self.original and word.endswith("alli") and pm(self._replace_suffix(word, "alli", "")):
            return self._step2(self._replace_suffix(word, "alli", "al"))
        rules = [
            ("ational", "ate", pm), ("tional", "tion", pm), ("enci", "ence", pm), ("anci", "ance", pm),
            ("izer", "ize", pm), ("abli", "able", pm) if self.original else ("bli", "ble", pm), ("alli", "al", pm), ("entli", "ent", pm),
            ("eli", "e", pm), ("ousli", "ous", pm), ("ization", "ize", pm), ("ation", "ate", pm),
            ("ator", "ate", pm), ("alism", "al", pm), ("iveness", "ive", pm), ("fulness", "ful", pm),
            ("ousness", "ous", pm), ("aliti", "al", pm), ("iviti", "ive", pm), ("biliti", "ble", pm),
        ]
        if not self.original:
            rules += [("fulli", "ful", pm), ("logi", "log", lambda stem: pm(word[:-3]))]
        return self._apply_rule_list(word, rules)

    def _step3(self, word):
        pm = self._has_positive_measure
        return self._apply_rule_list(word, [
            ("icate", "ic", pm), ("ative", "", pm), ("alize", "al", pm), ("iciti", "ic", pm),
            ("ical", "ic", pm), ("ful", "", pm), ("ness", "", pm)])

    def _step4(self, word):
        gt1 = lambda stem: self._measure(stem) > 1
        rules = [(s, "", gt1) for s in ("al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent")]
        rules.append(("ion", "", lambda stem: self._measure(stem) > 1 and stem[-1:] in ("s", "t")))
        rules += [(s, "", gt1) for s in ("ou", "ism", "ate", "iti", "ous", "ive", "ize")]
        return self._apply_rule_list(word, rules)

    def _step5a(self, word):
        if word.endswith("e"):
            stem = self._replace_suffix(word, "e", "")
            if self._measure(stem) > 1:
                return stem
            if self._measure(stem) == 1 and not self._ends_cvc(stem):
                return stem
        return word

    def _step5b(self, word):
        return self._apply_rule_list(word, [("ll", "l", lambda stem: self._measure(word[:-1]) > 1)])

    def stem(self, word, to_lowercase=True):
        if to_lowercase:
            word = word.lower()
        if not self.original and word in self.pool:
            return self.pool[word]
        if len(word) <= 2:
            return word
        for step in (self._step1a, self._step1b, self._step1c, self._step2, self._step3,
                     self._step4, self._step5a, self._step5b):
            word = step(word)
        return word

    def __repr__(self):
        return "<PorterStemmer>"
