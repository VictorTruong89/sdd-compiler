"""Snowball English (Porter2) stemmer."""
_V = "aeiouy"
_EXC1 = {"skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
         "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli", "singly": "singl",
         "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas", "cosmos": "cosmos",
         "bias": "bias", "andes": "andes"}
_EXC2 = {"inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed"}
_STEP2 = {"tional": "tion", "enci": "ence", "anci": "ance", "abli": "able", "entli": "ent", "izer": "ize",
          "ization": "ize", "ational": "ate", "ation": "ate", "ator": "ate", "alism": "al", "aliti": "al",
          "alli": "al", "fulness": "ful", "ousli": "ous", "ousness": "ous", "iveness": "ive", "iviti": "ive",
          "biliti": "ble", "bli": "ble", "fulli": "ful", "lessli": "less"}
_STEP3 = {"tional": "tion", "ational": "ate", "alize": "al", "icate": "ic", "iciti": "ic", "ical": "ic"}
_STEP4 = ("al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent", "ism", "ate",
          "iti", "ous", "ive", "ize")


def _regions(word):
    def after_nonvowel(w, start):
        i = start
        n = len(w)
        while i < n and w[i] not in _V:
            i += 1
        while i < n and w[i] in _V:
            i += 1
        # i is at first non-vowel after a vowel
        return i + 1 if i < n else n
    return after_nonvowel


def _find_r(word):
    n = len(word)

    def r_from(start):
        i = start
        while i < n and word[i] not in _V:
            i += 1
        while i < n and word[i] in _V:
            i += 1
        # now i is first non-vowel following a vowel (if any)
        return min(i + 1, n) if i < n else n
    if word.startswith(("gener", "arsen")):
        r1 = 5
    elif word.startswith("commun"):
        r1 = 6
    else:
        r1 = r_from(0)
    r2 = r_from(r1)
    return r1, r2


def _short_syllable(w):
    if len(w) == 2:
        return w[0] in _V and w[1] not in _V
    if len(w) >= 3:
        return w[-3] not in _V and w[-2] in _V and w[-1] not in _V and w[-1] not in "wxY"
    return False


def _longest(word, sufs):
    best = None
    for s in sufs:
        if word.endswith(s) and (best is None or len(s) > len(best)):
            best = s
    return best


def stem(word):
    word = word.lower()
    if len(word) <= 2:
        return word
    if word in _EXC1:
        return _EXC1[word]
    if word.startswith("'"):
        word = word[1:]
    if word.startswith("y"):
        word = "Y" + word[1:]
    word = "".join("Y" if (c == "y" and i > 0 and word[i - 1] in _V) else c for i, c in enumerate(word))
    # (a Y produced above is treated as a consonant; lowercase vowels only)
    r1, r2 = _find_r(word)
    # step 0
    suf = _longest(word, ("'s'", "'s", "'"))
    if suf:
        word = word[:-len(suf)]
    # step 1a
    suf = _longest(word, ("sses", "ied", "ies", "s", "us", "ss"))
    if suf == "sses":
        word = word[:-2]
    elif suf in ("ied", "ies"):
        word = word[:-3] + ("i" if len(word) > 4 else "ie")
    elif suf == "s":
        if any(c in _V for c in word[:-2]):
            word = word[:-1]
    if word in _EXC2:
        return word
    # step 1b
    suf = _longest(word, ("eedly", "eed", "ingly", "edly", "ing", "ed"))
    if suf in ("eed", "eedly"):
        if len(word) - len(suf) >= r1:
            word = word[:-len(suf)] + "ee"
    elif suf:
        base = word[:-len(suf)]
        if any(c in _V for c in base):
            word = base
            if word.endswith(("at", "bl", "iz")):
                word += "e"
            elif word.endswith(("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")):
                word = word[:-1]
            elif r1 >= len(word) and _short_syllable(word):
                word += "e"
    # step 1c
    if len(word) > 2 and word[-1] in "yY" and word[-2] not in _V:
        word = word[:-1] + "i"
    # step 2
    suf = _longest(word, list(_STEP2) + ["ogi", "li"])
    if suf and len(word) - len(suf) >= r1:
        base = word[:-len(suf)]
        if suf in _STEP2:
            word = base + _STEP2[suf]
        elif suf == "ogi":
            if base.endswith("l"):
                word = base + "og"
        elif suf == "li":
            if base and base[-1] in "cdeghkmnrt":
                word = base
    # step 3
    suf = _longest(word, list(_STEP3) + ["ative", "ful", "ness"])
    if suf and len(word) - len(suf) >= r1:
        base = word[:-len(suf)]
        if suf in _STEP3:
            word = base + _STEP3[suf]
        elif suf == "ative":
            if len(word) - len(suf) >= r2:
                word = base
        else:
            word = base
    # step 4
    suf = _longest(word, _STEP4 + ("ion",))
    if suf and len(word) - len(suf) >= r2:
        base = word[:-len(suf)]
        if suf == "ion":
            if base[-1:] in ("s", "t"):
                word = base
        else:
            word = base
    # step 5
    if word.endswith("e"):
        if len(word) - 1 >= r2 or (len(word) - 1 >= r1 and not _short_syllable(word[:-1])):
            word = word[:-1]
    elif word.endswith("ll"):
        if len(word) - 1 >= r2:
            word = word[:-1]
    return word.replace("Y", "y")
