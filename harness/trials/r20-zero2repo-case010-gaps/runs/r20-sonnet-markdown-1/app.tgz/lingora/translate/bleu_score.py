import math
import sys
from collections import Counter
from fractions import Fraction


def _ngrams(seq, n):
    return [tuple(seq[i:i + n]) for i in range(len(seq) - n + 1)]


def modified_precision(references, hypothesis, n):
    counts = Counter(_ngrams(hypothesis, n)) if len(hypothesis) >= n else Counter()
    max_counts = {}
    for ref in references:
        rc = Counter(_ngrams(ref, n)) if len(ref) >= n else Counter()
        for g in counts:
            max_counts[g] = max(max_counts.get(g, 0), rc[g])
    clipped = {g: min(c, max_counts.get(g, 0)) for g, c in counts.items()}
    return Fraction(sum(clipped.values()), max(1, sum(counts.values())))


def closest_ref_length(references, hyp_len):
    return min((len(r) for r in references), key=lambda l: (abs(l - hyp_len), l))


def brevity_penalty(closest, hyp_len):
    if hyp_len > closest:
        return 1
    if hyp_len == 0:
        return 0
    return math.exp(1 - closest / hyp_len)


class SmoothingFunction:
    def __init__(self, epsilon=0.1):
        self.epsilon = epsilon

    def method0(self, p_n, references, hypothesis, hyp_len):
        return [p if p.numerator != 0 else sys.float_info.min for p in p_n]

    def method1(self, p_n, references, hypothesis, hyp_len):
        return [(p.numerator + self.epsilon) / p.denominator if p.numerator == 0 else p for p in p_n]

    def method2(self, p_n, references, hypothesis, hyp_len):
        return [Fraction(p.numerator + 1, p.denominator + 1) if i != 0 else p for i, p in enumerate(p_n)]


def sentence_bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):
    references = [list(r) for r in references]
    hypothesis = list(hypothesis)
    if not references:
        raise ValueError("at least one reference is required")
    weights = list(weights)
    p_n = [modified_precision(references, hypothesis, i) for i in range(1, len(weights) + 1)]
    hyp_len = len(hypothesis)
    if not p_n or p_n[0].numerator == 0:
        return 0
    bp = brevity_penalty(closest_ref_length(references, hyp_len), hyp_len)
    if smoothing_function is None:
        smoothing_function = SmoothingFunction().method0
    p_n = smoothing_function(p_n, references, hypothesis, hyp_len)
    s = math.fsum(w * math.log(p) for w, p in zip(weights, p_n))
    return bp * math.exp(s)


bleu = sentence_bleu
