"""Constituent trees."""
import re


class Tree(list):
    def __init__(self, label, children):
        if isinstance(children, (str, bytes)) or children is None or not isinstance(children, (list, tuple)):
            raise TypeError("Tree children must be a list of children, not %r" % (type(children).__name__,))
        list.__init__(self, children)
        self._label = label

    def label(self):
        return self._label

    def set_label(self, label):
        self._label = label

    def leaves(self):
        out = []
        for c in self:
            if isinstance(c, Tree):
                out.extend(c.leaves())
            else:
                out.append(c)
        return out

    def height(self):
        h = 0
        for c in self:
            h = max(h, c.height() if isinstance(c, Tree) else 1)
        return h + 1

    def subtrees(self):
        yield self
        for c in self:
            if isinstance(c, Tree):
                yield from c.subtrees()

    def productions(self):
        from .grammar import Production, Nonterminal
        rhs = [Nonterminal(c.label()) if isinstance(c, Tree) else c for c in self]
        out = [Production(Nonterminal(self._label), rhs)]
        for c in self:
            if isinstance(c, Tree):
                out.extend(c.productions())
        return out

    def copy(self, deep=False):
        import copy
        return copy.deepcopy(self) if deep else Tree(self._label, list(self))

    def __eq__(self, other):
        return isinstance(other, Tree) and self._label == other._label and list.__eq__(self, other)

    def __ne__(self, other):
        return not self == other

    __hash__ = None

    def __repr__(self):
        return "Tree(%r, %s)" % (self._label, list.__repr__(self))

    def __str__(self):
        return self.pformat()

    @staticmethod
    def _flat_child(c):
        if isinstance(c, Tree):
            return c._pformat_flat()
        if isinstance(c, tuple):
            return "/".join(str(x) for x in c)
        return str(c)

    def _pformat_flat(self):
        return "(%s %s)" % (self._label, " ".join(self._flat_child(c) for c in self)) if len(self) else "(%s )" % (self._label,)

    def pformat(self, margin=70, indent=0):
        s = self._pformat_flat()
        if len(s) + indent < margin:
            return s
        s = "(%s" % (self._label,)
        for c in self:
            if isinstance(c, Tree):
                s += "\n" + " " * (indent + 2) + c.pformat(margin, indent + 2)
            else:
                s += "\n" + " " * (indent + 2) + self._flat_child(c)
        return s + ")"

    def pprint(self, **kw):
        print(self.pformat(**kw))

    @classmethod
    def fromstring(cls, s, brackets="()"):
        open_b, close_b = brackets
        tok_re = re.compile(r"\%s\s*([^\s\%s\%s]*)|\%s|([^\s\%s\%s]+)" % (open_b, open_b, close_b, close_b, open_b, close_b))
        stack = [(None, [])]
        for m in tok_re.finditer(s):
            tok = m.group()
            if tok[0] == open_b:
                stack.append((m.group(1) or "", []))
            elif tok == close_b:
                if len(stack) == 1:
                    raise ValueError("Tree.fromstring: unbalanced %r" % close_b)
                label, kids = stack.pop()
                stack[-1][1].append(cls(label, kids))
            else:
                if len(stack) == 1:
                    raise ValueError("Tree.fromstring: expected %r at top level" % open_b)
                stack[-1][1].append(tok)
        if len(stack) != 1:
            raise ValueError("Tree.fromstring: unbalanced %r" % open_b)
        top = stack[0][1]
        if len(top) != 1:
            raise ValueError("Tree.fromstring: expected exactly one tree")
        return top[0]
