"""Parsers for context-free grammars."""
from ..tree import Tree
from ..grammar import Nonterminal


def _check_coverage(grammar, tokens):
    if isinstance(tokens, (str, bytes)):
        raise TypeError("tokens must be a list of strings")
    terms = grammar.terminals()
    missing = [t for t in tokens if t not in terms]
    if missing:
        raise ValueError("Grammar does not cover some of the input words: %r" % (missing,))


class ChartParser:
    def __init__(self, grammar):
        self._grammar = grammar
        self._by_lhs = {}
        for p in grammar.productions():
            self._by_lhs.setdefault(p.lhs(), []).append(p)

    def grammar(self):
        return self._grammar

    def parse(self, tokens):
        tokens = list(tokens)
        _check_coverage(self._grammar, tokens)
        n = len(tokens)
        memo = {}
        active = set()
        state = {"cut": 0}

        def sym_parses(sym, i, j):
            """Yield (tree-or-leaf-list) alternatives for sym over tokens[i:j]."""
            if isinstance(sym, str):
                if sym == "":
                    return [[]] if i == j else []
                return [[sym]] if j == i + 1 and tokens[i] == sym else []
            key = (sym, i, j)
            if key in memo:
                return memo[key]
            if key in active:
                state["cut"] += 1
                return []
            active.add(key)
            before = state["cut"]
            res = []
            for p in self._by_lhs.get(sym, ()):
                for kids in seq(p.rhs(), 0, i, j):
                    res.append([Tree(str(sym), kids)])
            active.discard(key)
            if state["cut"] == before:
                memo[key] = res
            return res

        def seq(rhs, k, i, j):
            if k == len(rhs):
                return [[]] if i == j else []
            out = []
            last = k == len(rhs) - 1
            ends = [j] if last else range(i, j + 1)
            for m in ends:
                for first in sym_parses(rhs[k], i, m):
                    for rest in seq(rhs, k + 1, m, j):
                        out.append(first + rest)
            return out

        trees = [alt[0] for alt in sym_parses(self._grammar.start(), 0, n)]
        return iter(trees)


class ShiftReduceParser:
    def __init__(self, grammar, trace=0):
        self._grammar = grammar
        self._prods = [p for p in grammar.productions() if len(p.rhs()) > 0]

    def grammar(self):
        return self._grammar

    def _match(self, rhs, stack):
        if len(stack) < len(rhs):
            return False
        top = stack[len(stack) - len(rhs):]
        for r, e in zip(rhs, top):
            if isinstance(r, str):
                if not (isinstance(e, str) and e == r):
                    return False
            else:
                if not (isinstance(e, Tree) and e.label() == str(r)):
                    return False
        return True

    def parse(self, tokens):
        tokens = list(tokens)
        _check_coverage(self._grammar, tokens)
        stack = []
        remaining = list(tokens)
        while True:
            reduced = True
            while reduced:
                reduced = False
                for p in self._prods:
                    if self._match(p.rhs(), stack):
                        k = len(p.rhs())
                        kids = stack[len(stack) - k:]
                        del stack[len(stack) - k:]
                        stack.append(Tree(str(p.lhs()), kids))
                        reduced = True
                        break
            if remaining:
                stack.append(remaining.pop(0))
            else:
                break
        if len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == str(self._grammar.start()):
            return iter([stack[0]])
        return iter([])


class RecursiveDescentParser(ChartParser):
    pass
