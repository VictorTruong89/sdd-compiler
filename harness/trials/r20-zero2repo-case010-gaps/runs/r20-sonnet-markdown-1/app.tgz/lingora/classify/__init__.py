"""Classifiers."""
import math
from collections import Counter, OrderedDict


class DictionaryProbDist:
    def __init__(self, logprobs):
        m = max(logprobs.values()) if logprobs else 0.0
        if m == -math.inf:
            tot = 0.0
            self._p = {k: 1.0 / len(logprobs) for k in logprobs}
        else:
            tot = sum(math.exp(v - m) for v in logprobs.values())
            self._p = {k: math.exp(v - m) / tot for k, v in logprobs.items()}

    def prob(self, sample):
        return float(self._p.get(sample, 0.0))

    def logprob(self, sample):
        p = self.prob(sample)
        return math.log(p) if p > 0 else -math.inf

    def samples(self):
        return list(self._p)

    def max(self):
        best, bp = None, -1.0
        for k, p in self._p.items():
            if p > bp:
                best, bp = k, p
        return best


class ClassifierI:
    def classify(self, featureset):
        raise NotImplementedError

    def classify_many(self, featuresets):
        return [self.classify(fs) for fs in featuresets]


class NaiveBayesClassifier(ClassifierI):
    def __init__(self, label_probdist, feature_probdist):
        self._label_probdist = label_probdist      # {label: prob}
        self._feature_probdist = feature_probdist  # {(label, fname): (counts, N, bins)}
        self._labels = list(label_probdist)

    @classmethod
    def train(cls, labeled_featuresets):
        label_freq = Counter()
        order = []
        feat = {}
        values = {}
        fnames = OrderedDict()
        for fs, label in labeled_featuresets:
            if label not in label_freq:
                order.append(label)
            label_freq[label] += 1
            for fname, fval in fs.items():
                feat.setdefault((label, fname), Counter())[fval] += 1
                values.setdefault(fname, set()).add(fval)
                fnames[fname] = True
        if not label_freq:
            raise ValueError("cannot train on an empty training set")
        for label in order:
            for fname in fnames:
                c = feat.setdefault((label, fname), Counter())
                missing = label_freq[label] - sum(c.values())
                if missing > 0:
                    c[None] += missing
                    values[fname].add(None)
        B = len(label_freq)
        N = sum(label_freq.values())
        label_probs = OrderedDict((l, (label_freq[l] + 0.5) / (N + 0.5 * B)) for l in order)
        fp = {}
        for (label, fname), c in feat.items():
            fp[(label, fname)] = (c, sum(c.values()), len(values[fname]))
        return cls(label_probs, fp)

    def labels(self):
        return list(self._labels)

    def prob_classify(self, featureset):
        fs = {k: v for k, v in featureset.items() if any((l, k) in self._feature_probdist for l in self._labels)}
        logp = {}
        for label in self._labels:
            lp = math.log(self._label_probdist[label])
            for fname, fval in fs.items():
                entry = self._feature_probdist.get((label, fname))
                if entry is None:
                    lp += -math.inf
                else:
                    c, N, bins = entry
                    lp += math.log((c.get(fval, 0) + 0.5) / (N + 0.5 * bins))
            logp[label] = lp
        return DictionaryProbDist(logp)

    def classify(self, featureset):
        return self.prob_classify(featureset).max()


def _entropy(counter):
    n = sum(counter.values())
    return -sum((c / n) * math.log2(c / n) for c in counter.values() if c) if n else 0.0


def _majority(counter):
    best, bc = None, -1
    for k, c in counter.items():
        if c > bc:
            best, bc = k, c
    return best


class DecisionTreeClassifier(ClassifierI):
    def __init__(self, label, fname=None, decisions=None, default=None):
        self._label = label
        self._fname = fname
        self._decisions = decisions or {}
        self._default = default

    def classify(self, featureset):
        if self._fname is None:
            return self._label
        fval = featureset.get(self._fname)
        if fval in self._decisions:
            return self._decisions[fval].classify(featureset)
        if self._default is not None:
            return self._default.classify(featureset)
        return self._label

    @staticmethod
    def _stump(fname, labeled):
        label_freqs = Counter(l for _, l in labeled)
        freqs = {}
        for fs, l in labeled:
            freqs.setdefault(fs.get(fname), Counter())[l] += 1
        decisions = {v: DecisionTreeClassifier(_majority(c)) for v, c in freqs.items()}
        return DecisionTreeClassifier(_majority(label_freqs), fname, decisions)

    def _error(self, labeled):
        return sum(1 for fs, l in labeled if self.classify(fs) != l) / len(labeled)

    @classmethod
    def train(cls, labeled_featuresets, entropy_cutoff=0.05, depth_cutoff=100, support_cutoff=10, binary=False,
              feature_values=None, verbose=False):
        labeled = list(labeled_featuresets)
        if not labeled:
            raise ValueError("cannot train on an empty training set")
        return cls._train(labeled, entropy_cutoff, depth_cutoff, support_cutoff, top=True)

    @classmethod
    def _train(cls, labeled, ent_cut, depth_cut, sup_cut, top=False):
        label_freqs = Counter(l for _, l in labeled)
        if not top:
            if _entropy(label_freqs) < ent_cut or depth_cut <= 0 or len(labeled) <= sup_cut:
                return cls(_majority(label_freqs))
        names = OrderedDict()
        for fs, _ in labeled:
            for k in fs:
                names[k] = True
        best, best_err = None, 2.0
        for fname in names:
            if len({fs.get(fname) for fs, _ in labeled}) < 2:
                continue
            st = cls._stump(fname, labeled)
            err = st._error(labeled)
            if err < best_err:
                best, best_err = st, err
        if best is None:
            return cls(_majority(label_freqs))
        if len(labeled) > sup_cut and depth_cut - 1 > 0:
            for fval in list(best._decisions):
                sub = [(fs, l) for fs, l in labeled if fs.get(best._fname) == fval]
                if _entropy(Counter(l for _, l in sub)) > ent_cut:
                    best._decisions[fval] = cls._train(sub, ent_cut, depth_cut - 1, sup_cut)
        return best


def accuracy(classifier, gold):
    gold = list(gold)
    results = classifier.classify_many([fs for fs, _ in gold])
    correct = [l == r for (_, l), r in zip(gold, results)]
    if not correct:
        raise ZeroDivisionError("accuracy of an empty gold list is undefined")
    return sum(correct) / len(correct)
