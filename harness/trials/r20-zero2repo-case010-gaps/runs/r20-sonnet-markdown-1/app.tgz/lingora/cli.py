"""Command line group (minimal, dependency-free)."""
import sys


class _Group:
    def __init__(self):
        self.commands = {"tokenize": self._tokenize}

    @staticmethod
    def _parse_opts(args):
        opts = {"language": "english", "delimiter": " "}
        i = 0
        while i < len(args):
            a = args[i]
            key = None
            for name in ("language", "delimiter", "encoding"):
                if a in ("--" + name,) + (("-l",) if name == "language" else ()) + (("-d",) if name == "delimiter" else ()):
                    key = name
                    if i + 1 >= len(args):
                        raise ValueError("option %s requires a value" % a)
                    opts[key] = args[i + 1]
                    i += 1
                    break
                if a.startswith("--" + name + "="):
                    opts[name] = a.split("=", 1)[1]
                    key = name
                    break
            if key is None:
                raise ValueError("unknown argument %r" % a)
            i += 1
        return opts

    def _tokenize(self, args):
        from .tokenize import word_tokenize, PunktSentenceTokenizer
        opts = self._parse_opts(args)
        lang = opts["language"]
        PunktSentenceTokenizer.for_language(lang)  # fail early if model missing
        stream = sys.stdin
        text = stream.buffer.read().decode(opts.get("encoding", "utf-8")) if hasattr(stream, "buffer") else stream.read()
        lines = text.split("\n")
        if lines and lines[-1] == "":
            lines.pop()
        out = []
        for line in lines:
            line = line.rstrip("\r")
            out.append(opts["delimiter"].join(word_tokenize(line, language=lang)) + "\n")
        data = "".join(out)
        buf = getattr(sys.stdout, "buffer", None)
        if buf is not None:
            sys.stdout.flush()
            buf.write(data.encode("utf-8"))
            buf.flush()
        else:
            sys.stdout.write(data)

    def main(self, args=None, standalone_mode=True, **kwargs):
        args = list(sys.argv[1:] if args is None else args)
        try:
            if not args or args[0] not in self.commands:
                raise ValueError("usage: tokenize [--language L] [--delimiter D]")
            self.commands[args[0]](args[1:])
        except SystemExit:
            raise
        except BaseException as e:
            if not standalone_mode:
                raise
            sys.stderr.write("Error: %s\n" % (e,))
            sys.exit(1)
        if standalone_mode:
            sys.exit(0)
        return None

    __call__ = main


cli = _Group()
