"""Context-free grammars."""
import re


class Nonterminal:
    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and self._symbol == other._symbol

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return hash(("NT", self._symbol))

    def __str__(self):
        return str(self._symbol)

    def __repr__(self):
        return "%s" % (self._symbol,)


class Production:
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def is_lexical(self):
        return all(isinstance(s, str) for s in self._rhs)

    def is_nonlexical(self):
        return all(isinstance(s, Nonterminal) for s in self._rhs)

    def __eq__(self, other):
        return isinstance(other, Production) and self._lhs == other._lhs and self._rhs == other._rhs

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        return "%s -> %s" % (self._lhs, " ".join(repr(s) if isinstance(s, str) else str(s) for s in self._rhs))

    __repr__ = __str__


class CFG:
    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)

    def start(self):
        return self._start

    def productions(self, lhs=None, rhs=None):
        ps = self._productions
        if lhs is not None:
            if isinstance(lhs, str):
                lhs = Nonterminal(lhs)
            ps = [p for p in ps if p.lhs() == lhs]
        return list(ps)

    def terminals(self):
        return {s for p in self._productions for s in p.rhs() if isinstance(s, str)}

    def __str__(self):
        return "Grammar with %d productions (start state = %s)\n" % (len(self._productions), self._start) + \
            "\n".join("    %s" % p for p in self._productions)

    __repr__ = __str__

    @classmethod
    def fromstring(cls, input):
        if isinstance(input, (list, tuple)):
            input = "\n".join(input)
        start = None
        prods = []
        lines = []
        for raw in input.split("\n"):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("%start"):
                start = Nonterminal(line.split()[1])
                continue
            if line.startswith("|") and lines:
                lines[-1] += " " + line
                continue
            lines.append(line)
        tok_re = re.compile(r"\"[^\"]*\"|'[^']*'|\||[^\s|]+")
        for line in lines:
            if "->" not in line:
                raise ValueError("Unable to parse production: %r" % line)
            lhs_s, rhs_s = line.split("->", 1)
            lhs_s = lhs_s.strip()
            if not lhs_s or re.search(r"\s", lhs_s):
                raise ValueError("Bad left-hand side in production: %r" % line)
            lhs = Nonterminal(lhs_s)
            alts = [[]]
            for t in tok_re.findall(rhs_s):
                if t == "|":
                    alts.append([])
                elif len(t) >= 2 and t[0] in "\"'" and t[-1] == t[0]:
                    alts[-1].append(t[1:-1])
                else:
                    alts[-1].append(Nonterminal(t))
            for alt in alts:
                prods.append(Production(lhs, alt))
        if not prods:
            raise ValueError("Grammar has no productions")
        return cls(start or prods[0].lhs(), prods)


