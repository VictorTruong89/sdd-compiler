"""Regular-expression chunking."""
import re

from ..tree import Tree
from .. import data

ROOT = "S"


def _tag_pattern_to_re(tp):
    tp = re.sub(r"\s", "", tp)
    out = []
    i = 0
    in_class = False
    while i < len(tp):
        c = tp[i]
        if c == "\\" and i + 1 < len(tp):
            out.append(tp[i:i + 2])
            i += 2
            continue
        if c == "<":
            out.append("(<(")
        elif c == ">":
            out.append(")>)")
        elif c == "[":
            in_class = True
            out.append(c)
        elif c == "]":
            in_class = False
            out.append(c)
        elif c == "." and not in_class:
            out.append(r"[^\{\}<>]")
        else:
            out.append(c)
        i += 1
    return "".join(out)


_IN_CHINK = r"(?=[^\{\}]*(\{|$))"
_IN_CHUNK = r"(?=[^\{\}]*\})"


class _Rule:
    def __init__(self, kind, pattern):
        self.kind = kind
        self.src = pattern
        try:
            body = _tag_pattern_to_re(pattern)
            if kind == "chunk":
                self.rx = re.compile("(?P<chunk>%s)%s" % (body, _IN_CHINK))
                self.repl = r"{\g<chunk>}"
            else:
                self.rx = re.compile("(?P<chink>%s)%s" % (body, _IN_CHUNK))
                self.repl = r"}\g<chink>{"
        except re.error as e:
            raise ValueError("bad tag pattern %r: %s" % (pattern, e))

    def apply(self, s):
        s = self.rx.sub(self.repl, s)
        return s.replace("{}", "")


class _Stage:
    def __init__(self, label, rules):
        self.label = label
        self.rules = rules

    def parse_items(self, items):
        s = "".join("<%s>" % (it.label() if isinstance(it, Tree) else it[1]) for it in items)
        for r in self.rules:
            s = r.apply(s)
        out = []
        idx = 0
        cur = None
        pos = 0
        for m in re.finditer(r"\{|\}|<[^<>{}]*>", s):
            t = m.group()
            if t == "{":
                cur = []
            elif t == "}":
                if cur:
                    out.append(Tree(self.label, cur))
                cur = None
            else:
                item = items[idx]
                idx += 1
                (cur if cur is not None else out).append(item)
        if cur:
            out.append(Tree(self.label, cur))
        return out


def _parse_grammar(text):
    stages = []
    label = None
    rules = []
    for raw in text.split("\n"):
        line = raw.split("#")[0].rstrip()
        if not line.strip():
            continue
        m = re.match(r"^\s*([^\s:{}<>]+)\s*:(.*)$", line)
        rest = line
        if m and not line[0].isspace() or (m and label is None):
            if label is not None:
                stages.append(_Stage(label, rules))
            label, rest, rules = m.group(1), m.group(2).strip(), []
        elif label is None:
            raise ValueError("chunk grammar line without a label: %r" % raw)
        rest = rest.strip()
        if not rest:
            continue
        if rest.startswith("{") and rest.endswith("}"):
            rules.append(_Rule("chunk", rest[1:-1]))
        elif rest.startswith("}") and rest.endswith("{"):
            rules.append(_Rule("chink", rest[1:-1]))
        else:
            raise ValueError("unrecognised chunk rule: %r" % rest)
    if label is not None:
        stages.append(_Stage(label, rules))
    if not stages:
        raise ValueError("empty chunk grammar")
    return stages


class RegexpParser:
    def __init__(self, grammar, root_label=ROOT):
        self._root = root_label
        if isinstance(grammar, str):
            self._stages = _parse_grammar(grammar)
        else:
            self._stages = list(grammar)

    def parse(self, tagged):
        items = [tuple(t) for t in tagged]
        for st in self._stages:
            items = st.parse_items(items)
        return Tree(self._root, items)


def ne_chunk(tagged_tokens, binary=False):
    data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    data.find("corpora/words")
    raise NotImplementedError("named-entity chunker model evaluation is not supported")
