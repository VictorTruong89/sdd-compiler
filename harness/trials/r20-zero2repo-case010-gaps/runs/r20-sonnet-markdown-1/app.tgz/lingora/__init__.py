"""Lingora Language Toolkit: a pure-Python NLP library."""
from . import data

__version__ = "0.1.0"
