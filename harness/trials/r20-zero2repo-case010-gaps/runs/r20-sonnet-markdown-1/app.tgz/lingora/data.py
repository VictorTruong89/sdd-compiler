"""Packaged-resource finder. ``path`` is a mutable list of search directories."""
import os

path = []
for _p in os.environ.get("LINGORA_DATA", "").split(os.pathsep):
    if _p:
        path.append(_p)
path.extend([
    os.path.join(os.path.expanduser("~"), "lingora_data"),
    "/usr/share/lingora_data",
    "/usr/local/share/lingora_data",
    "/app/lingora_data",
])


def find(resource):
    """Return the full path of ``resource`` (relative name) in the first
    directory on ``path`` that holds it; raise LookupError otherwise."""
    for base in list(path):
        full = os.path.join(str(base), *resource.strip("/").split("/"))
        if os.path.exists(full):
            return full
    raise LookupError("Resource %r not found in data.path %r" % (resource, list(path)))
