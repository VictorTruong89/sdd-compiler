"""Punkt sentence-boundary detection (Kiss & Strunk 2006) using packaged parameters."""
import os
import re

from .. import data

_BEG_UC, _MID_UC, _UNK_UC = 2, 4, 8
_UC = _BEG_UC | _MID_UC | _UNK_UC
_BEG_LC, _MID_LC, _UNK_LC = 16, 32, 64
_LC = _BEG_LC | _MID_LC | _UNK_LC

_NONWORD = r"(?:[?!)\";}\]\*:@\'\({\[])"
_MULTI = r"(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"
_WORD_START = r"[^\(\"\`{\[:;&\#\*@\)}\]\-,]"
_WORD_RE = re.compile(
    r"(%(M)s|(?=%(WS)s)\S+?(?=\s|$|%(NW)s|%(M)s|,(?=$|\s|(%(NW)s|%(M)s)))|\S)"
    % {"M": _MULTI, "WS": _WORD_START, "NW": _NONWORD}, re.UNICODE | re.VERBOSE)
_PERIOD_RE = re.compile(
    r"[.?!](?=(?P<after_tok>%s|\s+(?P<next_tok>\S+)))" % _NONWORD, re.UNICODE | re.VERBOSE)
_REALIGN_RE = re.compile(r"[\"')\]}]+?(?:\s+|(?=--)|$)", re.UNICODE)
_NUMERIC = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_ELLIPSIS = re.compile(r"^\.\.+$")
_INITIAL = re.compile(r"^[^\W\d]\.$", re.UNICODE)


class _Params:
    def __init__(self, abbrevs, starters, collocations, ortho):
        self.abbrev_types = abbrevs
        self.sent_starters = starters
        self.collocations = collocations
        self.ortho_context = ortho


class _Tok:
    __slots__ = ("tok", "sentbreak", "abbr", "ellipsis", "type", "period_final")

    def __init__(self, tok):
        self.tok = tok
        self.sentbreak = self.abbr = self.ellipsis = False
        self.type = "##number##" if _NUMERIC.match(tok) else tok.lower()
        self.period_final = tok.endswith(".")

    @property
    def type_no_period(self):
        return self.type[:-1] if len(self.type) > 1 and self.type[-1] == "." else self.type

    @property
    def type_no_sentperiod(self):
        return self.type_no_period if self.sentbreak else self.type

    @property
    def first_upper(self):
        return self.tok[:1].isupper()

    @property
    def first_lower(self):
        return self.tok[:1].islower()

    @property
    def is_initial(self):
        return bool(_INITIAL.match(self.tok))


def _read_lines(path):
    with open(path, encoding="utf-8") as f:
        return f.read().split("\n")


_cache = {}


def _load(language):
    d = data.find("tokenizers/punkt_tab/%s" % language)
    files = {n: os.path.join(d, n) for n in
             ("abbrev_types.txt", "sent_starters.txt", "collocations.tab", "ortho_context.tab")}
    for p in files.values():
        if not os.path.isfile(p):
            raise LookupError("Punkt model file missing: %s" % p)
    key = (d, tuple(os.stat(p).st_mtime_ns for p in files.values()))
    if key in _cache:
        return _cache[key]
    abbrevs = {l for l in _read_lines(files["abbrev_types.txt"]) if l}
    starters = {l for l in _read_lines(files["sent_starters.txt"]) if l}
    colls = set()
    for l in _read_lines(files["collocations.tab"]):
        parts = l.split("\t")
        if len(parts) >= 2:
            colls.add((parts[0], parts[1]))
    ortho = {}
    for l in _read_lines(files["ortho_context.tab"]):
        parts = l.split("\t")
        if len(parts) >= 2:
            ortho[parts[0]] = int(parts[1])
    params = _Params(abbrevs, starters, colls, ortho)
    _cache.clear()
    _cache[key] = params
    return params


class PunktSentenceTokenizer:
    def __init__(self, params=None, language="english"):
        self._params = params if params is not None else _load(language)

    @classmethod
    def for_language(cls, language="english"):
        return cls(_load(language))

    # -- annotation -------------------------------------------------------
    def _annotate(self, text):
        toks = [_Tok(t) for t in _WORD_RE.findall(text) if False] if False else \
            [_Tok(m.group()) for m in _WORD_RE.finditer(text)]
        p = self._params
        for t in toks:
            if t.tok in (".", "?", "!"):
                t.sentbreak = True
            elif _ELLIPSIS.match(t.tok):
                t.ellipsis = True
            elif t.period_final and not t.tok.endswith(".."):
                base = t.tok[:-1].lower()
                if base in p.abbrev_types or base.split("-")[-1] in p.abbrev_types:
                    t.abbr = True
                else:
                    t.sentbreak = True
        for a, b in zip(toks, toks[1:]):
            self._second_pass(a, b)
        return toks

    def _ortho(self, tok):
        if tok.tok in (";", ":", ",", ".", "!", "?"):
            return False
        oc = self._params.ortho_context.get(tok.type_no_sentperiod, 0)
        if tok.first_upper and (oc & _LC) and not (oc & _MID_UC):
            return True
        if tok.first_lower and ((oc & _UC) or not (oc & _BEG_LC)):
            return False
        return "unknown"

    def _second_pass(self, tok1, tok2):
        if not tok1.period_final:
            return
        p = self._params
        typ = tok1.type_no_period
        next_typ = tok2.type_no_sentperiod
        initial = tok1.is_initial
        if (typ, next_typ) in p.collocations:
            tok1.sentbreak = False
            tok1.abbr = True
            return
        if (tok1.abbr or tok1.ellipsis) and not initial:
            if self._ortho(tok2) is True:
                tok1.sentbreak = True
                return
            if tok2.first_upper and next_typ in p.sent_starters:
                tok1.sentbreak = True
                return
        if initial or typ == "##number##":
            h = self._ortho(tok2)
            if h is False:
                tok1.sentbreak = False
                tok1.abbr = True
                return
            if (h == "unknown" and initial and tok2.first_upper
                    and not (p.ortho_context.get(next_typ, 0) & _LC)):
                tok1.sentbreak = False
                tok1.abbr = True
                return

    def _contains_break(self, context):
        found = False
        for t in self._annotate(context):
            if found:
                return True
            if t.sentbreak:
                found = True
        return False

    # -- slicing ----------------------------------------------------------
    def _contexts(self, text):
        prev_slice = (0, 0)
        prev_match = None
        for m in _PERIOD_RE.finditer(text):
            before = text[prev_slice[1]:m.start()]
            idx = max(before.rfind(c) for c in " \t\n\r\f\v") if before else -1
            ws = max([before.rfind(c) for c in (" ", "\t", "\n", "\r", "\f", "\v")] + [-1])
            if ws >= 0:
                ws += prev_slice[1] + 1
            else:
                ws = prev_slice[0]
            cur = (ws, m.start())
            if prev_match is not None and prev_slice[1] <= cur[0]:
                yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + prev_match.group("after_tok")
            prev_match, prev_slice = m, cur
        if prev_match is not None:
            yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + prev_match.group("after_tok")

    def _slices(self, text):
        last = 0
        out = []
        for m, ctx in self._contexts(text):
            if self._contains_break(ctx):
                out.append((last, m.end()))
                last = m.start("next_tok") if m.group("next_tok") else m.end()
        out.append((last, len(text.rstrip())))
        return out

    def span_tokenize(self, text):
        slices = self._slices(text)
        realign = 0
        for i, (s1, e1) in enumerate(slices):
            s1 += realign
            if i + 1 == len(slices):
                if text[s1:e1]:
                    yield (s1, e1)
                continue
            s2, e2 = slices[i + 1]
            m = _REALIGN_RE.match(text[s2:e2])
            if m:
                yield (s1, s2 + len(m.group(0).rstrip()))
                realign = m.end()
            else:
                realign = 0
                if text[s1:e1]:
                    yield (s1, e1)

    def tokenize(self, text):
        return [text[s:e] for s, e in self.span_tokenize(text)]
