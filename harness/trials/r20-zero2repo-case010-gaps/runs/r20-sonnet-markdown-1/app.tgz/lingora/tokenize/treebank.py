import re


def _c(p, flags=0):
    return re.compile(p, flags | re.UNICODE)


class TreebankWordTokenizer:
    STARTING_QUOTES = [
        (_c(r"([«“‘„]|[`]+)"), r" \1 "),
        (_c(r"^\""), r"``"),
        (_c(r"(``)"), r" \1 "),
        (_c(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
        (_c(r"(?i)(\')(?!re|ve|ll|m|t|s|d|n)(\w)\b"), r"\1 \2"),
    ]
    PUNCTUATION = [
        (_c(r"([^\.])(\.)([\]\)}>\"\']*)\s*$"), r"\1 \2 \3 "),
        (_c(r"([:,])([^\d])"), r" \1 \2"),
        (_c(r"([:,])$"), r" \1 "),
        (_c(r"\.{2,}"), r" \g<0> "),
        (_c(r"[;@#$%&]"), r" \g<0> "),
        (_c(r"[?!]"), r" \g<0> "),
        (_c(r"([^'])' "), r"\1 ' "),
    ]
    PARENS_BRACKETS = (_c(r"[\]\[\(\)\{\}\<\>]"), r" \g<0> ")
    DOUBLE_DASHES = (_c(r"--"), r" -- ")
    ENDING_QUOTES = [
        (_c(r'"'), " '' "),
        (_c(r"(\S)(\'\')"), r"\1 \2 "),
        (_c(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (_c(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    CONTRACTIONS2 = [_c(p) for p in (
        r"(?i)\b(can)(?#X)(not)\b", r"(?i)\b(d)(?#X)('ye)\b", r"(?i)\b(gim)(?#X)(me)\b",
        r"(?i)\b(gon)(?#X)(na)\b", r"(?i)\b(got)(?#X)(ta)\b", r"(?i)\b(lem)(?#X)(me)\b",
        r"(?i)\b(more)(?#X)('n)\b", r"(?i)\b(wan)(?#X)(na)(?=\s)")]
    CONTRACTIONS3 = [_c(p) for p in (r"(?i) ('t)(?#X)(is)\b", r"(?i) ('t)(?#X)(was)\b")]

    def tokenize(self, text):
        for regexp, sub in self.STARTING_QUOTES:
            text = regexp.sub(sub, text)
        for regexp, sub in self.PUNCTUATION:
            text = regexp.sub(sub, text)
        regexp, sub = self.PARENS_BRACKETS
        text = regexp.sub(sub, text)
        regexp, sub = self.DOUBLE_DASHES
        text = regexp.sub(sub, text)
        text = " " + text + " "
        for regexp, sub in self.ENDING_QUOTES:
            text = regexp.sub(sub, text)
        for regexp in self.CONTRACTIONS2:
            text = regexp.sub(r" \1 \2 ", text)
        for regexp in self.CONTRACTIONS3:
            text = regexp.sub(r" \1 \2 ", text)
        return text.split()


class LingoraWordTokenizer(TreebankWordTokenizer):
    """Improved Penn Treebank tokenizer (the recommended word tokenizer)."""
    STARTING_QUOTES = TreebankWordTokenizer.STARTING_QUOTES
    ENDING_QUOTES = [(_c(r"([»”’])"), r" \1 "), (_c(r"''"), " '' ")] + TreebankWordTokenizer.ENDING_QUOTES
    PUNCTUATION = [
        (_c(r"([^\.])(\.)([\]\)}>\"\']*)\s*$"), r"\1 \2 \3 "),
        (_c(r"([:,])([^\d])"), r" \1 \2"),
        (_c(r"([:,])$"), r" \1 "),
        (_c(r"\.{2,}"), r" \g<0> "),
        (_c(r"[;@#$%&]"), r" \g<0> "),
        (_c(r"[?!]"), r" \g<0> "),
        (_c(r"([^'])' "), r"\1 ' "),
        (_c(r"[*]"), r" \g<0> "),
        (_c(r"[‒-―]"), r" \g<0> "),
    ]
