import re


class RegexpTokenizer:
    def __init__(self, pattern, gaps=False, discard_empty=True, flags=re.UNICODE | re.MULTILINE | re.DOTALL):
        self._pattern = pattern
        self._gaps = gaps
        self._discard_empty = discard_empty
        self._flags = flags
        self._regexp = re.compile(pattern, flags)

    def tokenize(self, text):
        if self._gaps:
            if self._discard_empty:
                return [t for t in self._regexp.split(text) if t]
            return self._regexp.split(text)
        toks = [m.group() for m in self._regexp.finditer(text)]
        if self._discard_empty:
            toks = [t for t in toks if t]
        return toks

    def span_tokenize(self, text):
        if self._gaps:
            last = 0
            for m in self._regexp.finditer(text):
                if m.end() == m.start() and False:
                    continue
                span = (last, m.start())
                last = m.end()
                if not (self._discard_empty and span[0] == span[1]):
                    yield span
            span = (last, len(text))
            if not (self._discard_empty and span[0] == span[1]):
                yield span
        else:
            for m in self._regexp.finditer(text):
                if self._discard_empty and m.start() == m.end():
                    continue
                yield m.span()

    def __repr__(self):
        return "RegexpTokenizer(pattern=%r, gaps=%r, discard_empty=%r)" % (self._pattern, self._gaps, self._discard_empty)


class WordPunctTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\w+|[^\w\s]+")


class WhitespaceTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s+", gaps=True)


class BlanklineTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s*\n\s*\n\s*", gaps=True)


_wp = WordPunctTokenizer()
_bl = BlanklineTokenizer()


def wordpunct_tokenize(text):
    return _wp.tokenize(text)


def blankline_tokenize(text):
    return _bl.tokenize(text)
