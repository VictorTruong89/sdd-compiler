import re

_EMOTICONS = r"""
    (?:
      [<>]?
      [:;=8]
      [\-o\*\']?
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      |
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      [\-o\*\']?
      [:;=8]
      [<>]?
      |
      </?3
    )"""
_URLS = r"""
  (?:
  https?:
    (?:
      /{1,3}
      |
      [a-z0-9%]
    )
    |
    [a-z0-9.\-]+[.]
    (?:[a-z]{2,13})
    /
  )
  (?:
    [^\s()<>{}\[\]]+
    |
    \([^\s()]*?\([^\s()]+\)[^\s()]*?\)
    |
    \([^\s]+?\)
  )+
  (?:
    \([^\s()]*?\([^\s()]+\)[^\s()]*?\)
    |
    \([^\s]+?\)
    |
    [^\s`!()\[\]{};:'".,<>?«»“”‘’]
  )
  |
  (?:
    (?<!@)
    [a-z0-9]+
    (?:[.\-][a-z0-9]+)*
    [.]
    (?:[a-z]{2,13})
    \b
    /?
    (?!@)
  )
"""
_PHONE = r"""
    (?:
      (?:
        \+?[01]
        [ *\-.\)]*
      )?
      (?:
        [\(]?
        \d{3}
        [ *\-.\)]*
      )?
      \d{3}
      [ *\-.\)]*
      \d{4}
    )"""
_WORD_RE = re.compile(
    "(%s)" % "|".join([
        _URLS, _PHONE, _EMOTICONS,
        r"<[^>\s]+>",
        r"[\-]+>|<[\-]+",
        r"(?:@[\w_]+)",
        r"(?:\#+[\w_]+[\w\'_\-]*[\w_]+)",
        r"[\w.+-]+@[\w-]+\.(?:[\w-]\.?)+[\w-]",
        r"(?:[^\W\d_](?:[^\W\d_]|['\-_])+[^\W\d_])",
        r"(?:[+\-]?\d+[,/.:-]\d+[+\-]?)",
        r"(?:[\w_]+)",
        r"(?:\.(?:\s*\.){1,})",
        r"(?:\S)",
    ]), re.VERBOSE | re.IGNORECASE | re.UNICODE)
_EMOTICON_RE = re.compile("^" + _EMOTICONS + "$", re.VERBOSE | re.IGNORECASE | re.UNICODE)
_HANDLES_RE = re.compile(r"(?<![A-Za-z0-9_!@#\$%&*])@[A-Za-z0-9_]{1,15}")
_LEN_RE = re.compile(r"(.)\1{2,}", re.DOTALL)


class TweetTokenizer:
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self.preserve_case = preserve_case
        self.reduce_len = reduce_len
        self.strip_handles = strip_handles

    def tokenize(self, text):
        if self.strip_handles:
            text = _HANDLES_RE.sub(" ", text)
        if self.reduce_len:
            text = _LEN_RE.sub(r"\1\1\1", text)
        words = [m.group() for m in _WORD_RE.finditer(text)]
        if not self.preserve_case:
            words = [w if _EMOTICON_RE.match(w) else w.lower() for w in words]
        return words
