"""Tokenizers."""
from .simple import (RegexpTokenizer, WordPunctTokenizer, WhitespaceTokenizer,
                     BlanklineTokenizer, wordpunct_tokenize, blankline_tokenize)
from .treebank import TreebankWordTokenizer, LingoraWordTokenizer
from .punkt import PunktSentenceTokenizer
from .casual import TweetTokenizer

__all__ = ["RegexpTokenizer", "WordPunctTokenizer", "WhitespaceTokenizer", "BlanklineTokenizer",
           "TreebankWordTokenizer", "TweetTokenizer", "PunktSentenceTokenizer",
           "wordpunct_tokenize", "blankline_tokenize", "sent_tokenize", "word_tokenize"]

_word_tokenizer = LingoraWordTokenizer()


def sent_tokenize(text, language="english"):
    """Split text into sentences with the packaged Punkt model (raises if missing)."""
    return PunktSentenceTokenizer.for_language(language).tokenize(text)


def word_tokenize(text, language="english", preserve_line=False):
    """Recommended word tokenizer; splits sentences first unless preserve_line."""
    sentences = [text] if preserve_line else sent_tokenize(text, language)
    return [tok for sent in sentences for tok in _word_tokenizer.tokenize(sent)]
