"""Part-of-speech taggers."""
import json
import os
import re
from collections import Counter, defaultdict

from .. import data


class TaggerI:
    backoff = None

    def tag(self, tokens):
        _check_tokens(tokens)
        out = []
        for i in range(len(tokens)):
            tag = self.choose_tag(tokens, i, out)
            if tag is None and self.backoff is not None:
                tag = self.backoff.choose_tag(tokens, i, out)
            out.append(tag)
        return list(zip(tokens, out))

    def tag_sents(self, sents):
        return [self.tag(s) for s in sents]

    def choose_tag(self, tokens, index, history):
        raise NotImplementedError


def _check_tokens(tokens):
    if isinstance(tokens, (str, bytes)) or not hasattr(tokens, "__iter__"):
        raise TypeError("tokens must be a list of strings, not %s" % type(tokens).__name__)


class DefaultTagger(TaggerI):
    def __init__(self, tag):
        self._tag = tag

    def choose_tag(self, tokens, index, history):
        return self._tag


class ContextTagger(TaggerI):
    def __init__(self, train=None, backoff=None, model=None):
        self.backoff = backoff
        self._context_to_tag = dict(model) if model else {}
        if train:
            self._train(train)

    def context(self, tokens, index, history):
        raise NotImplementedError

    def choose_tag(self, tokens, index, history):
        return self._context_to_tag.get(self.context(tokens, index, history))

    def _train(self, sents):
        counts = defaultdict(Counter)
        for sent in sents:
            tokens = [w for w, _ in sent]
            history = []
            for i, (w, t) in enumerate(sent):
                c = self.context(tokens, i, history)
                if c is not None:
                    counts[c][t] += 1
                history.append(t)
        for c, cnt in counts.items():
            best = max(cnt.items(), key=lambda kv: kv[1])[0]
            self._context_to_tag[c] = best


class UnigramTagger(ContextTagger):
    def context(self, tokens, index, history):
        return tokens[index]


class BigramTagger(ContextTagger):
    def context(self, tokens, index, history):
        return (tuple(history[-1:]), tokens[index])


class TrigramTagger(ContextTagger):
    def context(self, tokens, index, history):
        return (tuple(history[-2:]), tokens[index])


class AffixTagger(ContextTagger):
    def __init__(self, train=None, affix_length=-3, min_stem_length=2, backoff=None):
        self._affix_length = affix_length
        self._min_word_length = min_stem_length + abs(affix_length)
        ContextTagger.__init__(self, train, backoff)

    def context(self, tokens, index, history):
        token = tokens[index]
        if len(token) < self._min_word_length:
            return None
        return token[self._affix_length:] if self._affix_length > 0 else token[self._affix_length:]


class RegexpTagger(TaggerI):
    def __init__(self, regexps, backoff=None):
        self.backoff = backoff
        self._regexps = [(re.compile(p), t) for p, t in regexps]

    def choose_tag(self, tokens, index, history):
        for rx, tag in self._regexps:
            if rx.match(tokens[index]):
                return tag
        return None


# ---------------------------------------------------------- perceptron
_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]


def _normalize(word):
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word and word[0].isdigit():
        return "!DIGITS"
    return word.lower()


class PerceptronTagger:
    def __init__(self, lang="eng"):
        d = data.find("taggers/averaged_perceptron_tagger_%s" % lang)
        base = os.path.join(d, "averaged_perceptron_tagger_%s" % lang)
        try:
            with open(base + ".weights.json", encoding="utf-8") as f:
                self.weights = json.load(f)
            with open(base + ".tagdict.json", encoding="utf-8") as f:
                self.tagdict = json.load(f)
            with open(base + ".classes.json", encoding="utf-8") as f:
                self.classes = set(json.load(f))
        except OSError as e:
            raise LookupError("averaged perceptron tagger files missing: %s" % e)

    def _features(self, i, word, context, prev, prev2):
        feats = defaultdict(int)

        def add(name, *args):
            feats[" ".join((name,) + tuple(args))] += 1
        i += len(_START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return feats

    def predict(self, feats):
        scores = defaultdict(float)
        for feat, value in feats.items():
            if feat not in self.weights or value == 0:
                continue
            for label, w in self.weights[feat].items():
                scores[label] += value * w
        return max(self.classes, key=lambda label: (scores[label], label))

    def tag(self, tokens):
        prev, prev2 = _START
        out = []
        context = _START + [_normalize(w) for w in tokens] + _END
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                tag = self.predict(self._features(i, word, context, prev, prev2))
            out.append((word, tag))
            prev2 = prev
            prev = tag
        return out


_RUS_UNIVERSAL = {"S": "NOUN", "V": "VERB", "A": "ADJ", "ADV": "ADV", "NUM": "NUM", "ANUM": "ADJ",
                  "SPRO": "PRON", "APRO": "DET", "ADVPRO": "ADV", "PR": "ADP", "CONJ": "CONJ", "PART": "PRT",
                  "INTJ": "X", "COM": "X", "NONLEX": "X"}


def _map_english(tagged):
    d = data.find("taggers/universal_tagset")
    p = os.path.join(d, "en-ptb.map")
    if not os.path.isfile(p):
        raise LookupError("universal tagset table en-ptb.map missing")
    table = {}
    with open(p, encoding="utf-8") as f:
        for line in f.read().split("\n"):
            parts = line.split("\t")
            if len(parts) >= 2:
                table[parts[0]] = parts[1]
    return [(w, table.get(t, "X")) for w, t in tagged]


def _map_russian(tagged):
    out = []
    for w, t in tagged:
        key = t.split("=")[0]
        out.append((w, _RUS_UNIVERSAL.get(key, "X")))
    return out


def pos_tag(tokens, tagset=None, lang="eng"):
    _check_tokens(tokens)
    if not isinstance(tokens, (list, tuple)):
        tokens = list(tokens)
    if lang not in ("eng", "rus"):
        raise NotImplementedError("pos_tag supports only 'eng' and 'rus', not %r" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("unsupported tagset %r" % (tagset,))
    tagger = PerceptronTagger(lang)
    tagged = tagger.tag(list(tokens))
    if tagset == "universal":
        tagged = _map_english(tagged) if lang == "eng" else _map_russian(tagged)
    return tagged
