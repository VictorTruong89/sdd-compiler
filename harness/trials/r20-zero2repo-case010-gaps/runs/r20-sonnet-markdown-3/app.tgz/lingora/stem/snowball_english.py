"""Snowball Porter2 English stemmer."""

V = "aeiouy"
DOUBLES = ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")
LI_END = "cdeghkmnrt"
SPECIAL = {"skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
           "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli",
           "singly": "singl", "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas",
           "cosmos": "cosmos", "bias": "bias", "andes": "andes"}
POST1A = {"inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed"}


def _r1r2(w):
    r1 = len(w)
    for pre in ("gener", "commun", "arsen"):
        if w.startswith(pre):
            r1 = len(pre)
            break
    else:
        for i in range(1, len(w)):
            if w[i] not in V and w[i - 1] in V:
                r1 = i + 1
                break
    r2 = len(w)
    for i in range(r1 + 1, len(w)):
        if w[i] not in V and w[i - 1] in V:
            r2 = i + 1
            break
    return r1, r2


def _short_syll(w, end=None):
    if end is None:
        end = len(w)
    w = w[:end]
    if len(w) == 2:
        return w[0] in V and w[1] not in V
    if len(w) >= 3:
        return (w[-2] in V and w[-1] not in V and w[-1] not in "wxY" and w[-3] not in V)
    return False


def _is_short(w, r1):
    return r1 >= len(w) and _short_syll(w)


def _longest(w, sufs):
    best = None
    for s in sufs:
        if w.endswith(s) and (best is None or len(s) > len(best)):
            best = s
    return best


def stem_english(word):
    w = word.lower()
    if len(w) <= 2:
        return w
    if w in SPECIAL:
        return SPECIAL[w]
    if w.startswith("'"):
        w = w[1:]
    if w.startswith("y"):
        w = "Y" + w[1:]
    chars = list(w)
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in V:
            chars[i] = "Y"
    w = "".join(chars)
    r1, r2 = _r1r2(w)
    # step 0
    s = _longest(w, ("'s'", "'s", "'"))
    if s:
        w = w[:-len(s)]
    # step 1a
    s = _longest(w, ("sses", "ied", "ies", "us", "ss", "s"))
    if s == "sses":
        w = w[:-2]
    elif s in ("ied", "ies"):
        w = w[:-2] if len(w) > 4 else w[:-1]
    elif s == "s":
        if any(c in V for c in w[:-2]):
            w = w[:-1]
    if w in POST1A:
        return w.replace("Y", "y")
    # step 1b
    s = _longest(w, ("eedly", "ingly", "edly", "eed", "ing", "ed"))
    if s in ("eed", "eedly"):
        if len(w) - len(s) >= r1:
            w = w[:-len(s)] + "ee"
    elif s:
        base = w[:-len(s)]
        if any(c in V for c in base):
            w = base
            if w.endswith(("at", "bl", "iz")):
                w += "e"
            elif w.endswith(DOUBLES):
                w = w[:-1]
            elif _is_short(w, r1):
                w += "e"
    # step 1c
    if len(w) > 2 and w[-1] in "yY" and w[-2] not in V:
        w = w[:-1] + "i"
    # step 2
    S2 = {"tional": "tion", "enci": "ence", "anci": "ance", "abli": "able", "entli": "ent",
          "izer": "ize", "ization": "ize", "ational": "ate", "ation": "ate", "ator": "ate",
          "alism": "al", "aliti": "al", "alli": "al", "fulness": "ful", "ousli": "ous",
          "ousness": "ous", "iveness": "ive", "iviti": "ive", "biliti": "ble", "bli": "ble",
          "ogi": "og", "fulli": "ful", "lessli": "less", "li": ""}
    s = _longest(w, S2)
    if s and len(w) - len(s) >= r1:
        base = w[:-len(s)]
        if s == "ogi":
            if base.endswith("l"):
                w = base + "og"
        elif s == "li":
            if base and base[-1] in LI_END:
                w = base
        else:
            w = base + S2[s]
    # step 3
    S3 = {"tional": "tion", "ational": "ate", "alize": "al", "icate": "ic", "iciti": "ic",
          "ical": "ic", "ful": "", "ness": "", "ative": ""}
    s = _longest(w, S3)
    if s and len(w) - len(s) >= r1:
        if s == "ative":
            if len(w) - len(s) >= r2:
                w = w[:-len(s)]
        else:
            w = w[:-len(s)] + S3[s]
    # step 4
    S4 = ("al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent",
          "ism", "ate", "iti", "ous", "ive", "ize", "ion")
    s = _longest(w, S4)
    if s and len(w) - len(s) >= r2:
        base = w[:-len(s)]
        if s == "ion":
            if base.endswith(("s", "t")):
                w = base
        else:
            w = base
    # step 5
    if w.endswith("e"):
        base = w[:-1]
        if len(base) >= r2 or (len(base) >= r1 and not _short_syll(base)):
            w = base
    elif w.endswith("l"):
        if len(w) - 1 >= r2 and w.endswith("ll"):
            w = w[:-1]
    return w.replace("Y", "y")
