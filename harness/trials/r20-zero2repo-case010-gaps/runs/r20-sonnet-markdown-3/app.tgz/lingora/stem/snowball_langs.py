"""Snowball stemmers for non-English languages (functions word -> stem)."""


def _longest(w, sufs, end=None):
    if end is None:
        end = len(w)
    best = None
    for s in sufs:
        if w.endswith(s, 0, end) and (best is None or len(s) > len(best)):
            best = s
    return best


def _regions(w, vowels, min_r1=0):
    r1 = len(w)
    for i in range(1, len(w)):
        if w[i] not in vowels and w[i - 1] in vowels:
            r1 = i + 1
            break
    r1 = max(r1, min_r1) if r1 < len(w) or min_r1 else r1
    r1 = min(max(r1, min_r1), len(w)) if min_r1 else r1
    r2 = len(w)
    for i in range(r1 + 1, len(w)):
        if w[i] not in vowels and w[i - 1] in vowels:
            r2 = i + 1
            break
    return r1, r2


# ----------------------------------------------------------------- German
def german(word):
    V = "aeiouyäöü"
    w = word.lower().replace("ß", "ss")
    if len(w) == 0:
        return w
    chars = list(w)
    for i in range(1, len(chars) - 1):
        if chars[i - 1] in V and chars[i + 1] in V:
            if chars[i] == "u":
                chars[i] = "U"
            elif chars[i] == "y":
                chars[i] = "Y"
    w = "".join(chars)
    r1, r2 = _regions(w, V, 3)
    # step 1
    s = _longest(w, ("em", "ern", "er", "e", "en", "es", "s"))
    if s in ("em", "ern", "er") and len(w) - len(s) >= r1:
        w = w[:-len(s)]
    elif s in ("e", "en", "es") and len(w) - len(s) >= r1:
        w = w[:-len(s)]
        if w.endswith("niss"):
            w = w[:-1]
    elif s == "s" and len(w) - 1 >= r1 and len(w) >= 2 and w[-2] in "bdfghklmnrt":
        w = w[:-1]
    # step 2
    s = _longest(w, ("en", "er", "est", "st"))
    if s in ("en", "er", "est") and len(w) - len(s) >= r1:
        w = w[:-len(s)]
    elif s == "st" and len(w) - 2 >= r1 and len(w) >= 6 and w[-3] in "bdfghklmnt":
        w = w[:-2]
    # step 3
    s = _longest(w, ("end", "ung", "ig", "ik", "isch", "lich", "heit", "keit"))
    if s:
        pos = len(w) - len(s)
        if s in ("end", "ung"):
            if pos >= r2:
                w = w[:-len(s)]
                if w.endswith("ig") and len(w) - 2 >= r2 and not w[:-2].endswith("e"):
                    w = w[:-2]
        elif s in ("ig", "ik", "isch"):
            if pos >= r2 and not w[:pos].endswith("e"):
                w = w[:-len(s)]
        elif s in ("lich", "heit"):
            if pos >= r2:
                w = w[:-len(s)]
                t = _longest(w, ("er", "en"))
                if t and len(w) - len(t) >= r1:
                    w = w[:-len(t)]
        elif s == "keit":
            if pos >= r2:
                w = w[:-4]
                t = _longest(w, ("lich", "ig"))
                if t and len(w) - len(t) >= r2:
                    w = w[:-len(t)]
    return w.replace("U", "u").replace("Y", "y").replace("ä", "a").replace("ö", "o").replace("ü", "u")


# ------------------------------------------------------------------ Dutch
def dutch(word):
    V = "aeiouyè"
    w = word.lower()
    for a, b in zip("äëïöüáéíóú", "aeiouaeiou"):
        w = w.replace(a, b)
    if not w:
        return w
    if w[0] == "y":
        w = "Y" + w[1:]
    chars = list(w)
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in V:
            chars[i] = "Y"
    for i in range(1, len(chars) - 1):
        if chars[i] == "i" and chars[i - 1] in V and chars[i + 1] in V:
            chars[i] = "I"
    w = "".join(chars)
    r1, r2 = _regions(w, V, 3)

    def undouble(x):
        return x[:-1] if x.endswith(("kk", "dd", "tt")) else x

    # step 1
    s = _longest(w, ("heden", "ene", "en", "se", "s"))
    if s == "heden":
        if len(w) - 5 >= r1:
            w = w[:-5] + "heid"
    elif s in ("en", "ene"):
        pos = len(w) - len(s)
        if pos >= r1 and pos > 0 and w[pos - 1] not in V and not w[:pos].endswith("gem"):
            w = undouble(w[:pos])
    elif s in ("se", "s"):
        pos = len(w) - len(s)
        if pos >= r1 and pos > 0 and w[pos - 1] not in V and w[pos - 1] != "j":
            w = w[:pos]
    # step 2
    e_found = False
    if w.endswith("e") and len(w) - 1 >= r1 and len(w) >= 2 and w[-2] not in V:
        w = undouble(w[:-1])
        e_found = True
    # step 3a
    if w.endswith("heid") and len(w) - 4 >= r2 and not w[:-4].endswith("c"):
        w = w[:-4]
        if w.endswith("en") and len(w) - 2 >= r1 and len(w) >= 3 and w[-3] not in V \
                and not w[:-2].endswith("gem"):
            w = undouble(w[:-2])
    # step 3b
    s = _longest(w, ("end", "ing", "ig", "lijk", "baar", "bar"))
    if s:
        pos = len(w) - len(s)
        if s in ("end", "ing"):
            if pos >= r2:
                w = w[:pos]
                if w.endswith("ig") and len(w) - 2 >= r2 and not w[:-2].endswith("e"):
                    w = w[:-2]
                else:
                    w = undouble(w)
        elif s == "ig":
            if pos >= r2 and not w[:pos].endswith("e"):
                w = w[:pos]
        elif s == "lijk":
            if pos >= r2:
                w = w[:pos]
                if w.endswith("e") and len(w) - 1 >= r1 and len(w) >= 2 and w[-2] not in V:
                    w = undouble(w[:-1])
        elif s == "baar":
            if pos >= r2:
                w = w[:pos]
        elif s == "bar":
            if pos >= r2 and e_found:
                w = w[:pos]
    # step 4
    if len(w) >= 4 and w[-1] not in V and w[-1] != "I" and w[-2] == w[-3] and w[-2] in "aeou" \
            and w[-4] not in V:
        w = w[:-2] + w[-1]
    return w.replace("Y", "y").replace("I", "i")


# ---------------------------------------------------------------- Swedish
def swedish(word):
    V = "aeiouyäåö"
    w = word.lower()
    r1, _ = _regions(w, V, 3)
    s = _longest(w, ("a", "arna", "erna", "heterna", "orna", "ad", "e", "ade", "ande", "arne", "are",
                     "aste", "en", "anden", "aren", "heten", "ern", "ar", "er", "heter", "or", "s", "as",
                     "arnas", "ernas", "ornas", "es", "ades", "andes", "ens", "arens", "hetens", "erns",
                     "at", "andet", "het", "ast"))
    if s and len(w) - len(s) >= r1:
        if s == "s":
            if len(w) >= 2 and w[-2] in "bcdfghjklmnoprtvy":
                w = w[:-1]
        else:
            w = w[:-len(s)]
    s = _longest(w, ("dd", "gd", "nn", "dt", "gt", "kt", "tt"))
    if s and len(w) - len(s) >= r1:
        w = w[:-1]
    s = _longest(w, ("lig", "ig", "els", "löst", "fullt"))
    if s and len(w) - len(s) >= r1:
        if s == "löst":
            w = w[:-1]
        elif s == "fullt":
            w = w[:-1]
        else:
            w = w[:-len(s)]
    return w


# -------------------------------------------------------------- Norwegian
def norwegian(word):
    V = "aeiouyæåø"
    w = word.lower()
    r1, _ = _regions(w, V, 3)
    s = _longest(w, ("a", "e", "ede", "ande", "ende", "ane", "ene", "hetene", "en", "heten", "ar", "er",
                     "heter", "as", "es", "edes", "endes", "enes", "hetenes", "ens", "hetens", "ers",
                     "ets", "et", "het", "ast", "s", "erte", "ert"))
    if s and len(w) - len(s) >= r1:
        if s == "s":
            if len(w) >= 2 and (w[-2] in "bcdfghjlmnoprtvyz" or (w[-2] == "k" and len(w) >= 3 and w[-3] not in V)):
                w = w[:-1]
        elif s in ("erte", "ert"):
            w = w[:-len(s)] + "er"
        else:
            w = w[:-len(s)]
    if len(w) - 2 >= r1 and w.endswith(("dt", "vt")):
        w = w[:-1]
    s = _longest(w, ("leg", "eleg", "ig", "eig", "lig", "elig", "els", "lov", "elov", "slov", "hetslov"))
    if s and len(w) - len(s) >= r1:
        w = w[:-len(s)]
    return w


# ----------------------------------------------------------------- Danish
def danish(word):
    V = "aeiouyæåø"
    w = word.lower()
    r1, _ = _regions(w, V, 3)
    s = _longest(w, ("hed", "ethed", "ered", "e", "erede", "ende", "erende", "ene", "erne", "ere", "en",
                     "heden", "eren", "er", "heder", "erer", "heds", "es", "endes", "erendes", "enes",
                     "ernes", "eres", "ens", "hedens", "erens", "ers", "ets", "erets", "et", "eret", "s"))
    if s and len(w) - len(s) >= r1:
        if s == "s":
            if len(w) >= 2 and w[-2] in "abcdfghjklmnoprtvyzå":
                w = w[:-1]
        else:
            w = w[:-len(s)]

    def step2(x):
        t = _longest(x, ("gd", "dt", "gt", "kt"))
        if t and len(x) - len(t) >= r1:
            return x[:-1]
        return x
    w = step2(w)
    if w.endswith("igst") and len(w) - 4 >= r1:
        w = w[:-2]
    s = _longest(w, ("elig", "lig", "ig", "els", "løst"))
    if s and len(w) - len(s) >= r1:
        if s == "løst":
            w = w[:-1]
        else:
            w = step2(w[:-len(s)])
    if len(w) >= 2 and len(w) - 1 > r1 and w[-1] == w[-2] and w[-1] not in V:
        w = w[:-1]
    return w


# ---------------------------------------------------------------- Spanish
def spanish(word):
    V = "aeiouáéíóúü"
    w = word.lower()
    n = len(w)
    if n == 0:
        return w
    r1, r2 = _regions(w, V)
    rv = n
    if n >= 2:
        if w[1] not in V:
            for i in range(2, n):
                if w[i] in V:
                    rv = i + 1
                    break
        elif w[0] in V and w[1] in V:
            for i in range(2, n):
                if w[i] not in V:
                    rv = i + 1
                    break
        else:
            rv = 3 if n >= 3 else n
    # step 0
    s = _longest(w, ("me", "se", "sela", "selo", "selas", "selos", "la", "le", "lo", "las", "les", "los", "nos"))
    if s and len(w) - len(s) >= rv:
        base = w[:-len(s)]
        t = _longest(base, ("iéndo", "ándo", "ár", "ér", "ír", "ando", "iendo", "ar", "er", "ir", "yendo"))
        if t:
            if t in ("iéndo", "ándo", "ár", "ér", "ír"):
                w = base[:-len(t)] + t.replace("é", "e").replace("á", "a").replace("í", "i")
            elif t == "yendo":
                if base[:-5].endswith("u"):
                    w = base
            else:
                w = base
    # step 1
    done = False
    s = _longest(w, ("anza", "anzas", "ico", "ica", "icos", "icas", "ismo", "ismos", "able", "ables",
                     "ible", "ibles", "ista", "istas", "oso", "osa", "osos", "osas", "amiento",
                     "amientos", "imiento", "imientos", "adora", "ador", "ación", "adoras", "adores",
                     "aciones", "ante", "antes", "ancia", "ancias", "logía", "logías", "ución",
                     "uciones", "encia", "encias", "amente", "mente", "idad", "idades", "iva", "ivo",
                     "ivas", "ivos"))
    if s:
        pos = len(w) - len(s)
        base = w[:pos]
        g1 = ("anza", "anzas", "ico", "ica", "icos", "icas", "ismo", "ismos", "able", "ables", "ible",
              "ibles", "ista", "istas", "oso", "osa", "osos", "osas", "amiento", "amientos",
              "imiento", "imientos")
        g2 = ("adora", "ador", "ación", "adoras", "adores", "aciones", "ante", "antes", "ancia", "ancias")
        if s in g1:
            if pos >= r2:
                w = base
                done = True
        elif s in g2:
            if pos >= r2:
                w = base
                done = True
                if w.endswith("ic") and len(w) - 2 >= r2:
                    w = w[:-2]
        elif s in ("logía", "logías"):
            if pos >= r2:
                w = base + "log"
                done = True
        elif s in ("ución", "uciones"):
            if pos >= r2:
                w = base + "u"
                done = True
        elif s in ("encia", "encias"):
            if pos >= r2:
                w = base + "ente"
                done = True
        elif s == "amente":
            if pos >= r1:
                w = base
                done = True
                t = _longest(w, ("iv", "os", "ic", "ad"))
                if t and len(w) - len(t) >= r2:
                    w = w[:-len(t)]
                    if t == "iv" and w.endswith("at") and len(w) - 2 >= r2:
                        w = w[:-2]
        elif s == "mente":
            if pos >= r2:
                w = base
                done = True
                t = _longest(w, ("ante", "able", "ible"))
                if t and len(w) - len(t) >= r2:
                    w = w[:-len(t)]
        elif s in ("idad", "idades"):
            if pos >= r2:
                w = base
                done = True
                t = _longest(w, ("abil", "ic", "iv"))
                if t and len(w) - len(t) >= r2:
                    w = w[:-len(t)]
        else:
            if pos >= r2:
                w = base
                done = True
                if w.endswith("at") and len(w) - 2 >= r2:
                    w = w[:-2]
    if not done:
        s = _longest(w, ("ya", "ye", "yan", "yen", "yeron", "yendo", "yo", "yó", "yas", "yes", "yais", "yamos"))
        did = False
        if s and len(w) - len(s) >= rv and w[:-len(s)].endswith("u"):
            w = w[:-len(s)]
            did = True
        if not did:
            s = _longest(w, (
                "en", "es", "éis", "emos", "arían", "arías", "arán", "arás", "aríais", "aría", "aréis",
                "aríamos", "aremos", "ará", "aré", "erían", "erías", "erán", "erás", "eríais", "ería",
                "eréis", "eríamos", "eremos", "erá", "eré", "irían", "irías", "irán", "irás", "iríais",
                "iría", "iréis", "iríamos", "iremos", "irá", "iré", "aba", "ada", "ida", "ía", "ara",
                "iera", "ad", "ed", "id", "ase", "iese", "aste", "iste", "an", "aban", "ían", "aran",
                "ieran", "asen", "iesen", "aron", "ieron", "ado", "ido", "ando", "iendo", "ió", "ar",
                "er", "ir", "as", "abas", "adas", "idas", "ías", "aras", "ieras", "ases", "ieses", "ís",
                "áis", "abais", "íais", "arais", "ierais", "aseis", "ieseis", "asteis", "isteis",
                "ados", "idos", "amos", "ábamos", "íamos", "imos", "áramos", "iéramos", "iésemos",
                "ásemos"))
            if s and len(w) - len(s) >= rv:
                base = w[:-len(s)]
                if s in ("en", "es", "éis", "emos"):
                    w = base
                    if w.endswith("gu"):
                        w = w[:-1]
                else:
                    w = base
                did = True
            if not did:
                s = _longest(w, ("os", "a", "o", "á", "í", "ó", "e", "é"))
                if s and len(w) - len(s) >= rv:
                    w = w[:-len(s)]
                    if s in ("e", "é") and w.endswith("gu") and len(w) - 1 >= rv:
                        w = w[:-1]
    for a, b in zip("áéíóú", "aeiou"):
        w = w.replace(a, b)
    return w


# ---------------------------------------------------------------- Russian
def russian(word):
    V = "аеиоуыэюя"
    w = word.lower().replace("ё", "е")
    rv = len(w)
    for i, c in enumerate(w):
        if c in V:
            rv = i + 1
            break
    r1 = len(w)
    for i in range(1, len(w)):
        if w[i] not in V and w[i - 1] in V:
            r1 = i + 1
            break
    r2 = len(w)
    for i in range(r1 + 1, len(w)):
        if w[i] not in V and w[i - 1] in V:
            r2 = i + 1
            break

    def match(x, g1, g2=()):
        """longest match of group1 (preceded by а/я) or group2 within RV; returns suffix len or 0"""
        best = 0
        for s in g2:
            if x.endswith(s) and len(x) - len(s) >= rv and len(s) > best:
                best = len(s)
        for s in g1:
            if x.endswith(s) and len(x) - len(s) - 1 >= rv - 0 and len(x) - len(s) >= 1 \
                    and x[-len(s) - 1] in "ая" and len(x) - len(s) - 1 >= rv and len(s) > best:
                best = len(s)
        return best

    PG1 = ("в", "вши", "вшись")
    PG2 = ("ив", "ивши", "ившись", "ыв", "ывши", "ывшись")
    REFL = ("ся", "сь")
    ADJ = ("ее", "ие", "ые", "ое", "ими", "ыми", "ей", "ий", "ый", "ой", "ем", "им", "ым", "ом", "его",
           "ого", "ему", "ому", "их", "ых", "ую", "юю", "ая", "яя", "ою", "ею")
    PART1 = ("ем", "нн", "вш", "ющ", "щ")
    PART2 = ("ивш", "ывш", "ующ")
    VERB1 = ("ла", "на", "ете", "йте", "ли", "й", "л", "ем", "н", "ло", "но", "ет", "ют", "ны", "ть",
             "ешь", "нно")
    VERB2 = ("ила", "ыла", "ена", "ейте", "уйте", "ите", "или", "ыли", "ей", "уй", "ил", "ыл", "им",
             "ым", "ен", "ило", "ыло", "ено", "ят", "ует", "уют", "ит", "ыт", "ены", "ить", "ыть",
             "ишь", "ую", "ю")
    NOUN = ("а", "ев", "ов", "ие", "ье", "е", "иями", "ями", "ами", "еи", "ии", "и", "ией", "ей", "ой",
            "ий", "й", "иям", "ям", "ием", "ем", "ам", "ом", "о", "у", "ах", "иях", "ях", "ы", "ь",
            "ю", "ию", "ью", "я", "ия", "ья")

    def cut(x, n):
        return x[:-n] if n else x

    # step 1
    n = match(w, PG1, PG2)
    if n:
        w = cut(w, n)
    else:
        for s in REFL:
            if w.endswith(s) and len(w) - len(s) >= rv:
                w = w[:-len(s)]
                break
        found = False
        # adjectival
        best = 0
        for s in ADJ:
            if w.endswith(s) and len(w) - len(s) >= rv and len(s) > best:
                best = len(s)
        if best:
            w = w[:-best]
            found = True
            m = match(w, PART1, PART2)
            if m:
                w = cut(w, m)
        if not found:
            m = match(w, VERB1, VERB2)
            if m:
                w = cut(w, m)
                found = True
        if not found:
            best = 0
            for s in NOUN:
                if w.endswith(s) and len(w) - len(s) >= rv and len(s) > best:
                    best = len(s)
            if best:
                w = w[:-best]
    # step 2
    if w.endswith("и") and len(w) - 1 >= rv:
        w = w[:-1]
    # step 3
    if w.endswith("ость") and len(w) - 4 >= r2:
        w = w[:-4]
    elif w.endswith("ост") and len(w) - 3 >= r2:
        w = w[:-3]
    # step 4
    if w.endswith("ейше") and len(w) - 4 >= rv:
        w = w[:-4]
    elif w.endswith("ейш") and len(w) - 3 >= rv:
        w = w[:-3]
    if w.endswith("нн") and len(w) - 1 >= rv:
        w = w[:-1]
    elif w.endswith("ь") and len(w) - 1 >= rv:
        w = w[:-1]
    return w


_FUNCS = {"german": german, "dutch": dutch, "swedish": swedish, "norwegian": norwegian,
          "danish": danish, "spanish": spanish, "russian": russian}


def get(language):
    return _FUNCS.get(language, lambda w: w)
