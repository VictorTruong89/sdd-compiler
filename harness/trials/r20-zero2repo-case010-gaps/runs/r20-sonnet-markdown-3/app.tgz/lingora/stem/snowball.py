"""Snowball stemmers."""
import os

from .. import data
from .porter import PorterStemmer
from .snowball_english import stem_english

SUPPORTED = ("arabic", "danish", "dutch", "english", "finnish", "french", "german", "hungarian",
             "italian", "norwegian", "porter", "portuguese", "romanian", "russian", "spanish",
             "swedish")


def _load_stopwords(language):
    d = data.find("corpora/stopwords/%s" % language)
    with open(d, encoding="utf-8") as f:
        return set(line.strip() for line in f.read().split("\n") if line.strip())


class SnowballStemmer:
    languages = SUPPORTED

    def __init__(self, language, ignore_stopwords=False):
        if language not in SUPPORTED:
            raise ValueError("The language '%s' is not supported." % (language,))
        self.language = language
        self.stopwords = set()
        if ignore_stopwords:
            self.stopwords = _load_stopwords(language)
        if language == "english":
            self._fn = stem_english
        elif language == "porter":
            p = PorterStemmer(PorterStemmer.ORIGINAL_ALGORITHM)
            self._fn = lambda w: p.stem(w)
        else:
            from . import snowball_langs
            self._fn = snowball_langs.get(language)

    def stem(self, word):
        word = word.lower()
        if word in self.stopwords:
            return word
        return self._fn(word)

    def __repr__(self):
        return "<SnowballStemmer(%s)>" % self.language
