"""Stemmers whose results are outside the specified behaviour (best-effort)."""
import re

from .. import data


class WordNetLemmatizer:
    def __init__(self):
        data.find("corpora/wordnet")

    def lemmatize(self, word, pos="n"):
        data.find("corpora/wordnet")
        return word


class _Arabic:
    _diac = re.compile("[ً-ْـ]")

    def stem(self, token):
        return self._diac.sub("", token)


class ARLSTem(_Arabic):
    pass


class ARLSTem2(_Arabic):
    pass


class ISRIStemmer(_Arabic):
    pass


class Cistem:
    def __init__(self, case_insensitive=False):
        self.case_insensitive = case_insensitive

    def stem(self, word):
        return word.lower() if self.case_insensitive else word


class RSLPStemmer:
    def __init__(self):
        data.find("stemmers/rslp")

    def stem(self, word):
        return word
