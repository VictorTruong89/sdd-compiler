"""Porter stemmer (M. F. Porter, 1980) with LINGORA extensions."""


class PorterStemmer:
    ORIGINAL_ALGORITHM = "ORIGINAL_ALGORITHM"
    MARTIN_EXTENSIONS = "MARTIN_EXTENSIONS"
    NLTK_EXTENSIONS = "NLTK_EXTENSIONS"
    LINGORA_EXTENSIONS = NLTK_EXTENSIONS

    def __init__(self, mode="NLTK_EXTENSIONS"):
        if mode not in (self.ORIGINAL_ALGORITHM, self.MARTIN_EXTENSIONS, self.NLTK_EXTENSIONS):
            raise ValueError("Mode must be one of ORIGINAL_ALGORITHM, MARTIN_EXTENSIONS, NLTK_EXTENSIONS")
        self.mode = mode
        self.pool = {}
        if mode == self.NLTK_EXTENSIONS:
            irregular = {
                "skies": "sky", "sky": "sky", "dying": "die", "lying": "lie", "tying": "tie",
                "news": "news", "innings": "inning", "inning": "inning", "outings": "outing",
                "outing": "outing", "cannings": "canning", "canning": "canning", "howe": "howe",
                "proceed": "proceed", "exceed": "exceed", "succeed": "succeed",
            }
            self.pool = irregular

    vowels = frozenset(["a", "e", "i", "o", "u"])

    def _is_consonant(self, word, i):
        if word[i] in self.vowels:
            return False
        if word[i] == "y":
            if i == 0:
                return True
            return not self._is_consonant(word, i - 1)
        return True

    def _measure(self, stem):
        cv = "".join("c" if self._is_consonant(stem, i) else "v" for i in range(len(stem)))
        return cv.count("vc")

    def _has_positive_measure(self, stem):
        return self._measure(stem) > 0

    def _contains_vowel(self, stem):
        return any(not self._is_consonant(stem, i) for i in range(len(stem)))

    def _ends_double_consonant(self, word):
        return len(word) >= 2 and word[-1] == word[-2] and self._is_consonant(word, len(word) - 1)

    def _ends_cvc(self, word):
        return (
            len(word) >= 3
            and self._is_consonant(word, len(word) - 3)
            and not self._is_consonant(word, len(word) - 2)
            and self._is_consonant(word, len(word) - 1)
            and word[-1] not in ("w", "x", "y")
        ) or (
            self.mode == self.NLTK_EXTENSIONS
            and len(word) == 2
            and not self._is_consonant(word, 0)
            and self._is_consonant(word, 1)
        )

    @staticmethod
    def _replace_suffix(word, suffix, replacement):
        assert word.endswith(suffix)
        if suffix == "":
            return word + replacement
        return word[:-len(suffix)] + replacement

    def _apply_rule_list(self, word, rules):
        for suffix, replacement, condition in rules:
            if suffix == "*d" and self._ends_double_consonant(word):
                stem = word[:-2]
                if condition is None or condition(stem):
                    return stem + replacement
                return word
            if word.endswith(suffix):
                stem = self._replace_suffix(word, suffix, "")
                if condition is None or condition(stem):
                    return stem + replacement
                return word
        return word

    def _step1a(self, word):
        if self.mode == self.NLTK_EXTENSIONS:
            if word.endswith("ies") and len(word) == 4:
                return self._replace_suffix(word, "ies", "ie")
        return self._apply_rule_list(word, [("sses", "ss", None), ("ies", "i", None),
                                            ("ss", "ss", None), ("s", "", None)])

    def _step1b(self, word):
        if self.mode == self.NLTK_EXTENSIONS:
            if word.endswith("ied"):
                if len(word) == 4:
                    return self._replace_suffix(word, "ied", "ie")
                return self._replace_suffix(word, "ied", "i")
        if word.endswith("eed"):
            stem = self._replace_suffix(word, "eed", "")
            if self._measure(stem) > 0:
                return stem + "ee"
            return word
        ok = False
        inter = None
        for suffix in ("ed", "ing"):
            if word.endswith(suffix):
                inter = self._replace_suffix(word, suffix, "")
                if self._contains_vowel(inter):
                    ok = True
                    break
        if not ok:
            return word
        return self._apply_rule_list(inter, [
            ("at", "ate", None), ("bl", "ble", None), ("iz", "ize", None),
            ("*d", inter[-1], lambda stem: inter[-1] not in ("l", "s", "z")),
            ("", "e", lambda stem: self._measure(stem) == 1 and self._ends_cvc(stem)),
        ])

    def _step1c(self, word):
        if self.mode == self.NLTK_EXTENSIONS:
            cond = lambda stem: len(stem) > 1 and self._is_consonant(stem, len(stem) - 1)
        else:
            cond = lambda stem: self._contains_vowel(stem)
        return self._apply_rule_list(word, [("y", "i", cond)])

    def _step2(self, word):
        pos = self._has_positive_measure
        if self.mode == self.NLTK_EXTENSIONS:
            if word.endswith("alli") and pos(self._replace_suffix(word, "alli", "")):
                return self._step2(self._replace_suffix(word, "alli", "al"))
        bli = ("bli", "ble", pos)
        abli = ("abli", "able", pos)
        rules = [
            ("ational", "ate", pos), ("tional", "tion", pos), ("enci", "ence", pos),
            ("anci", "ance", pos), ("izer", "ize", pos),
            abli if self.mode == self.ORIGINAL_ALGORITHM else bli,
            ("alli", "al", pos), ("entli", "ent", pos), ("eli", "e", pos), ("ousli", "ous", pos),
            ("ization", "ize", pos), ("ation", "ate", pos), ("ator", "ate", pos),
            ("alism", "al", pos), ("iveness", "ive", pos), ("fulness", "ful", pos),
            ("ousness", "ous", pos), ("aliti", "al", pos), ("iviti", "ive", pos),
            ("biliti", "ble", pos),
        ]
        if self.mode == self.NLTK_EXTENSIONS:
            rules.append(("fulli", "ful", pos))
            rules.append(("logi", "log", lambda stem: pos(word[:-len("ogi")])))
        if self.mode == self.ORIGINAL_ALGORITHM:
            pass
        return self._apply_rule_list(word, rules)

    def _step3(self, word):
        pos = self._has_positive_measure
        return self._apply_rule_list(word, [
            ("icate", "ic", pos), ("ative", "", pos), ("alize", "al", pos), ("iciti", "ic", pos),
            ("ical", "ic", pos), ("ful", "", pos), ("ness", "", pos)])

    def _step4(self, word):
        m1 = lambda stem: self._measure(stem) > 1
        sfx = ["al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent"]
        rules = [(s, "", m1) for s in sfx]
        rules.append(("ion", "", lambda stem: self._measure(stem) > 1 and stem[-1:] in ("s", "t")))
        rules += [(s, "", m1) for s in ["ou", "ism", "ate", "iti", "ous", "ive", "ize"]]
        return self._apply_rule_list(word, rules)

    def _step5a(self, word):
        if word.endswith("e"):
            stem = self._replace_suffix(word, "e", "")
            if self._measure(stem) > 1:
                return stem
            if self._measure(stem) == 1 and not self._ends_cvc(stem):
                return stem
        return word

    def _step5b(self, word):
        return self._apply_rule_list(word, [("ll", "l", lambda stem: self._measure(word[:-1]) > 1)])

    def stem(self, word, to_lowercase=True):
        stem = word.lower() if to_lowercase else word
        if self.mode == self.NLTK_EXTENSIONS and stem in self.pool:
            return self.pool[stem]
        if self.mode != self.ORIGINAL_ALGORITHM and len(stem) <= 2:
            return stem
        stem = self._step1a(stem)
        stem = self._step1b(stem)
        stem = self._step1c(stem)
        stem = self._step2(stem)
        stem = self._step3(stem)
        stem = self._step4(stem)
        stem = self._step5a(stem)
        stem = self._step5b(stem)
        return stem

    def __repr__(self):
        return "<PorterStemmer>"
