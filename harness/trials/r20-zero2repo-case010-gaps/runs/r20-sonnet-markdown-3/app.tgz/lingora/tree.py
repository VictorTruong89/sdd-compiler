"""Constituent trees."""
import re


class Tree(list):
    def __init__(self, label, children):
        if children is None or isinstance(children, (str, bytes)):
            raise TypeError("children should be a list, not %s" % type(children).__name__)
        list.__init__(self, children)
        self._label = label

    def label(self):
        return self._label

    def set_label(self, label):
        self._label = label

    def leaves(self):
        out = []
        for c in self:
            if isinstance(c, Tree):
                out.extend(c.leaves())
            else:
                out.append(c)
        return out

    def __eq__(self, other):
        return (isinstance(other, Tree) and self._label == other._label
                and list.__eq__(self, other))

    def __ne__(self, other):
        return not self == other

    __hash__ = None

    def __repr__(self):
        return "Tree(%r, [%s])" % (self._label, ", ".join(repr(c) for c in self))

    def __str__(self):
        return self.pformat()

    def copy(self):
        return Tree(self._label, [c.copy() if isinstance(c, Tree) else c for c in self])

    def height(self):
        h = 1
        for c in self:
            if isinstance(c, Tree):
                h = max(h, 1 + c.height())
            else:
                h = max(h, 2)
        return h

    def productions(self):
        from .grammar import Nonterminal, Production
        rhs = []
        for c in self:
            rhs.append(Nonterminal(c._label) if isinstance(c, Tree) else c)
        out = [Production(Nonterminal(self._label), rhs)]
        for c in self:
            if isinstance(c, Tree):
                out.extend(c.productions())
        return out

    def subtrees(self):
        yield self
        for c in self:
            if isinstance(c, Tree):
                yield from c.subtrees()

    @staticmethod
    def _leaf_str(c):
        if isinstance(c, tuple) and len(c) == 2:
            return "%s/%s" % c
        return str(c)

    def _flat(self):
        parts = []
        for c in self:
            parts.append(c._flat() if isinstance(c, Tree) else self._leaf_str(c))
        return "(%s%s)" % (self._label, "".join(" " + p for p in parts))

    def pformat(self, margin=70, indent=0):
        s = self._flat()
        if len(s) + indent < margin:
            return s
        out = "(%s" % (self._label,)
        for c in self:
            if isinstance(c, Tree):
                out += "\n" + " " * (indent + 2) + c.pformat(margin, indent + 2)
            else:
                out += "\n" + " " * (indent + 2) + self._leaf_str(c)
        return out + ")"

    def pprint(self, **kw):
        print(self.pformat(**kw))

    @classmethod
    def fromstring(cls, s):
        toks = re.findall(r"\(|\)|[^\s()]+", s)
        if not toks:
            raise ValueError("empty tree text")
        pos = 0

        def parse_node():
            nonlocal pos
            if toks[pos] != "(":
                raise ValueError("expected '(' in %r" % s)
            pos += 1
            label = ""
            if pos < len(toks) and toks[pos] not in "()" or (pos < len(toks) and toks[pos] not in ("(", ")")):
                label = toks[pos]
                pos += 1
            children = []
            while True:
                if pos >= len(toks):
                    raise ValueError("unbalanced parentheses in %r" % s)
                t = toks[pos]
                if t == ")":
                    pos += 1
                    return cls(label, children)
                if t == "(":
                    children.append(parse_node())
                else:
                    children.append(t)
                    pos += 1

        # allow an outer unlabeled wrapper "( (S ...) )"
        t = parse_node()
        if pos != len(toks):
            raise ValueError("extra text after tree in %r" % s)
        if t._label == "" and len(t) == 1 and isinstance(t[0], Tree):
            return t[0]
        return t
