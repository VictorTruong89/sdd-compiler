"""Context-free grammars."""
import re


class Nonterminal:
    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and self._symbol == other._symbol

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return hash(("NT", self._symbol))

    def __str__(self):
        return str(self._symbol)

    def __repr__(self):
        return "%s" % (self._symbol,)

    def __lt__(self, other):
        return str(self) < str(other)


class Production:
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def is_nonlexical(self):
        return all(isinstance(s, Nonterminal) for s in self._rhs)

    def is_lexical(self):
        return not self.is_nonlexical()

    def is_empty(self):
        return len(self._rhs) == 0

    def __eq__(self, other):
        return isinstance(other, Production) and self._lhs == other._lhs and self._rhs == other._rhs

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        parts = [repr(s) if isinstance(s, str) else str(s) for s in self._rhs]
        return "%s -> %s" % (self._lhs, " ".join(parts))

    __repr__ = __str__


_TOKEN = re.compile(r"""'[^']*'|"[^"]*"|\||[^\s|'"]+""")


class CFG:
    def __init__(self, start, productions):
        self._start = start
        self._productions = tuple(productions)
        self._terminals = set()
        for p in self._productions:
            for s in p.rhs():
                if isinstance(s, str):
                    self._terminals.add(s)

    def start(self):
        return self._start

    def productions(self, lhs=None, rhs=None):
        if lhs is not None and not isinstance(lhs, Nonterminal):
            lhs = Nonterminal(lhs)
        out = list(self._productions)
        if lhs is not None:
            out = [p for p in out if p.lhs() == lhs]
        if rhs is not None:
            out = [p for p in out if p.rhs() and p.rhs()[0] == rhs]
        return out

    def terminals(self):
        return set(self._terminals)

    def __str__(self):
        return "Grammar with %d productions (start state = %s)\n" % (
            len(self._productions), self._start) + "\n".join("    " + str(p) for p in self._productions)

    __repr__ = __str__

    @classmethod
    def fromstring(cls, input):
        if isinstance(input, (list, tuple)):
            lines = list(input)
        else:
            lines = input.splitlines()
        prods = []
        start = None
        last_lhs = None
        for raw in lines:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("|"):
                if last_lhs is None:
                    raise ValueError("Unable to parse line: %r" % raw)
                lhs = last_lhs
                rhs_text = line
            else:
                m = re.match(r"^(\S+?)\s*(?:->|→)\s*(.*)$", line)
                if not m:
                    raise ValueError("Unable to parse line: %r" % raw)
                lhs = Nonterminal(m.group(1))
                rhs_text = m.group(2)
            last_lhs = lhs
            if start is None:
                start = lhs
            alts = [[]]
            for tok in _TOKEN.findall(rhs_text):
                if tok == "|":
                    alts.append([])
                elif tok[0] in "'\"" and len(tok) >= 2 and tok[-1] == tok[0]:
                    alts[-1].append(tok[1:-1])
                else:
                    alts[-1].append(Nonterminal(tok))
            if line.startswith("|") is False and rhs_text.strip() == "":
                alts = [[]]
            for a in alts:
                prods.append(Production(lhs, a))
        if start is None:
            raise ValueError("No productions found")
        return cls(start, prods)


def nonterminals(symbols):
    return [Nonterminal(s) for s in symbols.replace(",", " ").split()]
