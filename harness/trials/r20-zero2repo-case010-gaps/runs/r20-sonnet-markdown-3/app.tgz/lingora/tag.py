"""Part-of-speech taggers."""
import json
import os
import re
from collections import Counter, defaultdict

from . import data


class TaggerI:
    def tag(self, tokens):
        raise NotImplementedError

    def tag_sents(self, sents):
        return [self.tag(s) for s in sents]


class SequentialBackoffTagger(TaggerI):
    def __init__(self, backoff=None):
        self._backoff = backoff

    @property
    def backoff(self):
        return self._backoff

    def tag(self, tokens):
        tokens = list(tokens)
        tags = []
        for i in range(len(tokens)):
            tags.append(self.tag_one(tokens, i, tags))
        return list(zip(tokens, tags))

    def tag_one(self, tokens, index, history):
        tag = self.choose_tag(tokens, index, history)
        if tag is None and self._backoff is not None:
            tag = self._backoff.tag_one(tokens, index, history)
        return tag

    def choose_tag(self, tokens, index, history):
        raise NotImplementedError


class DefaultTagger(SequentialBackoffTagger):
    def __init__(self, tag):
        SequentialBackoffTagger.__init__(self, None)
        self._tag = tag

    def choose_tag(self, tokens, index, history):
        return self._tag


class RegexpTagger(SequentialBackoffTagger):
    def __init__(self, regexps, backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        self._regexps = [(re.compile(p), t) for p, t in regexps]

    def choose_tag(self, tokens, index, history):
        for rx, t in self._regexps:
            if rx.match(tokens[index]):
                return t
        return None


class ContextTagger(SequentialBackoffTagger):
    def __init__(self, context_to_tag, backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        self._context_to_tag = context_to_tag if context_to_tag else {}

    def context(self, tokens, index, history):
        raise NotImplementedError

    def choose_tag(self, tokens, index, history):
        c = self.context(tokens, index, history)
        return self._context_to_tag.get(c)


class NgramTagger(ContextTagger):
    _n = 1

    def __init__(self, n=None, train=None, model=None, backoff=None, cutoff=0):
        if n is not None:
            self._n = n
        ContextTagger.__init__(self, model, backoff)
        self._cutoff = cutoff
        if train is not None and model is None:
            self._train(train)

    def context(self, tokens, index, history):
        n = self._n
        if n == 1:
            return tokens[index]
        tag_ctx = tuple(history[max(0, index - n + 1):index])
        return tag_ctx, tokens[index]

    def _train(self, tagged_corpus):
        fd = defaultdict(Counter)
        useful = []
        useful_set = set()
        for sentence in tagged_corpus:
            sentence = list(sentence)
            tokens = [t for t, _ in sentence]
            tags = [g for _, g in sentence]
            for i, (tok, tg) in enumerate(sentence):
                c = self.context(tokens, i, tags[:i])
                if c is None:
                    continue
                fd[c][tg] += 1
                if self._backoff is None or tg != self._backoff.tag_one(tokens, i, tags[:i]):
                    if c not in useful_set:
                        useful_set.add(c)
                        useful.append(c)
        for c in useful:
            best_tag, hits = None, -1
            for tg, n in fd[c].items():
                if n > hits:
                    best_tag, hits = tg, n
            if hits > self._cutoff:
                self._context_to_tag[c] = best_tag


class UnigramTagger(NgramTagger):
    _n = 1

    def __init__(self, train=None, model=None, backoff=None, cutoff=0):
        NgramTagger.__init__(self, 1, train, model, backoff, cutoff)


class BigramTagger(NgramTagger):
    def __init__(self, train=None, model=None, backoff=None, cutoff=0):
        NgramTagger.__init__(self, 2, train, model, backoff, cutoff)


class TrigramTagger(NgramTagger):
    def __init__(self, train=None, model=None, backoff=None, cutoff=0):
        NgramTagger.__init__(self, 3, train, model, backoff, cutoff)


class AffixTagger(ContextTagger):
    def __init__(self, train=None, model=None, affix_length=-3, min_stem_length=2, backoff=None, cutoff=0):
        ContextTagger.__init__(self, model, backoff)
        self._affix_length = affix_length
        self._min_word_length = min_stem_length + abs(affix_length)
        if train is not None and model is None:
            self._train(train, cutoff)

    def context(self, tokens, index, history):
        token = tokens[index]
        if len(token) < self._min_word_length:
            return None
        if self._affix_length > 0:
            return token[:self._affix_length]
        return token[self._affix_length:]

    _train = NgramTagger._train

    def _train(self, corpus, cutoff=0):  # noqa: F811
        self._cutoff = cutoff
        NgramTagger._train(self, corpus)


# ---------------------------------------------------------------- perceptron
_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]


class PerceptronTagger(TaggerI):
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = list(classes)

    @staticmethod
    def _load(lang):
        d = data.find("taggers/averaged_perceptron_tagger_%s" % lang)
        base = os.path.join(d, "averaged_perceptron_tagger_%s" % lang)
        with open(base + ".weights.json", encoding="utf-8") as f:
            w = json.load(f)
        with open(base + ".tagdict.json", encoding="utf-8") as f:
            td = json.load(f)
        with open(base + ".classes.json", encoding="utf-8") as f:
            cl = json.load(f)
        return PerceptronTagger(w, td, cl)

    @staticmethod
    def normalize(word):
        if "-" in word and word[0] != "-":
            return "!HYPHEN"
        if word.isdigit() and len(word) == 4:
            return "!YEAR"
        if word and word[0].isdigit():
            return "!DIGITS"
        return word.lower()

    def _features(self, i, word, context, prev, prev2):
        feats = defaultdict(int)

        def add(name, *args):
            feats[" ".join((name,) + tuple(args))] += 1

        i += len(_START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return feats

    def predict(self, feats):
        scores = defaultdict(float)
        for feat, value in feats.items():
            if feat not in self.weights or value == 0:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda l: (scores[l], l))

    def tag(self, tokens):
        prev, prev2 = _START
        out = []
        context = _START + [self.normalize(w) for w in tokens] + _END
        for i, word in enumerate(tokens):
            t = self.tagdict.get(word)
            if not t:
                t = self.predict(self._features(i, word, context, prev, prev2))
            out.append((word, t))
            prev2 = prev
            prev = t
        return out


_RU_UNIVERSAL = {
    "A": "ADJ", "A-PRO": "PRON", "ADV": "ADV", "ADV-PRO": "PRON", "ANUM": "ADJ",
    "CONJ": "CONJ", "INTJ": "X", "NONLEX": ".", "NUM": "NUM", "PARENTH": "PRT",
    "PART": "PRT", "PR": "ADP", "PRAEDIC": "PRT", "PRAEDIC-PRO": "PRON",
    "S": "NOUN", "S-PRO": "PRON", "V": "VERB", "COM": "X", "NID": "X",
}


def _load_en_universal():
    d = data.find("taggers/universal_tagset")
    path = os.path.join(d, "en-ptb.map")
    m = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.rstrip("\r\n")
            if not line.strip():
                continue
            parts = line.split("\t")
            if len(parts) >= 2:
                m[parts[0]] = parts[1]
    return m


def pos_tag(tokens, tagset=None, lang="eng"):
    if isinstance(tokens, (str, bytes)):
        raise TypeError("tokens must be a list of strings, not a string")
    if lang not in ("eng", "rus"):
        raise NotImplementedError("Currently, only 'eng' and 'rus' are supported, not %r" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("unsupported tagset %r" % (tagset,))
    tokens = list(tokens)
    tagger = PerceptronTagger._load(lang)
    umap = None
    if tagset == "universal" and lang == "eng":
        umap = _load_en_universal()
    tagged = tagger.tag(tokens)
    if tagset == "universal":
        if lang == "eng":
            return [(w, umap.get(t, "X")) for w, t in tagged]
        return [(w, _RU_UNIVERSAL.get(t.split("=")[0], "X") if t is not None else None) for w, t in tagged]
    return tagged
