"""Command line: ``lingora tokenize``."""
import sys


class _Exit(Exception):
    def __init__(self, code):
        self.code = code


class Group:
    def __init__(self):
        self.commands = {}

    def command(self, name):
        def deco(f):
            self.commands[name] = f
            return f
        return deco

    def main(self, args=None, standalone_mode=True, **kw):
        if args is None:
            args = sys.argv[1:]
        args = list(args)
        code = 0
        try:
            if not args or args[0] in ("-h", "--help"):
                print("Usage: lingora [OPTIONS] COMMAND [ARGS]...\n\nCommands:\n  tokenize  Tokenize each line of stdin.")
            elif args[0] not in self.commands:
                raise _UsageError("No such command %r." % args[0])
            else:
                self.commands[args[0]](args[1:])
        except _Exit as e:
            code = e.code
        except _UsageError as e:
            if not standalone_mode:
                raise
            sys.stderr.write("Error: %s\n" % e)
            code = 2
        except Exception as e:  # failure
            if not standalone_mode:
                raise
            sys.stderr.write("Error: %s\n" % (e,))
            code = 1
        if standalone_mode:
            sys.exit(code)
        return None


class _UsageError(Exception):
    pass


cli = Group()


@cli.command("tokenize")
def _tokenize(args):
    from .tokenize import word_tokenize, _load_punkt
    language, delimiter, encoding = "english", " ", "utf-8"
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-l", "--language") and i + 1 < len(args):
            language = args[i + 1]; i += 2
        elif a in ("-d", "--delimiter") and i + 1 < len(args):
            delimiter = args[i + 1]; i += 2
        elif a in ("-e", "--encoding") and i + 1 < len(args):
            encoding = args[i + 1]; i += 2
        elif a.startswith("--language="):
            language = a.split("=", 1)[1]; i += 1
        elif a.startswith("--delimiter="):
            delimiter = a.split("=", 1)[1]; i += 1
        elif a.startswith("--encoding="):
            encoding = a.split("=", 1)[1]; i += 1
        elif a in ("-h", "--help"):
            print("Usage: lingora tokenize [-l LANGUAGE] [-d DELIMITER] [-e ENCODING]")
            return
        else:
            raise _UsageError("Unexpected argument %r." % a)
    _load_punkt(language)  # fail before writing anything when the model is missing
    stream = sys.stdin
    try:
        stream.reconfigure(encoding=encoding)
    except Exception:
        pass
    out = []
    for line in stream:
        line = line.rstrip("\r\n")
        toks = word_tokenize(line, language=language)
        out.append(delimiter.join(toks) + "\n")
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    sys.stdout.write("".join(out))
    sys.stdout.flush()
