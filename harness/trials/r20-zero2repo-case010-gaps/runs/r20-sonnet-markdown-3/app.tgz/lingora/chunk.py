"""Regular-expression chunking."""
import re

from . import data
from .tree import Tree

DEFAULT_ROOT = "S"


def tag_pattern2re_pattern(tag_pattern):
    tag_pattern = re.sub(r"\s", "", tag_pattern)
    out = []
    in_el = False
    i = 0
    while i < len(tag_pattern):
        c = tag_pattern[i]
        if c == "\\" and i + 1 < len(tag_pattern):
            out.append(tag_pattern[i:i + 2])
            i += 2
            continue
        if c == "<" and not in_el:
            out.append("(?:<(?:")
            in_el = True
        elif c == ">" and in_el:
            out.append(")>)")
            in_el = False
        elif c == "." and in_el:
            out.append("[^<>]")
        else:
            out.append(c)
        i += 1
    if in_el:
        raise ValueError("Unbalanced angle brackets in tag pattern")
    res = "".join(out)
    try:
        re.compile(res)
    except re.error as e:
        raise ValueError("Bad tag pattern %r: %s" % (tag_pattern, e))
    return res


class ChunkRule:
    def __init__(self, pattern):
        self.regex = re.compile("(?P<chunk>%s)(?=[^\\{\\}]*(\\{|$))" % tag_pattern2re_pattern(pattern))
        self.repl = r"{\g<chunk>}"


class ChinkRule:
    def __init__(self, pattern):
        self.regex = re.compile("(?P<chink>%s)(?=[^\\{]*\\})" % tag_pattern2re_pattern(pattern))
        self.repl = r"}\g<chink>{"


class ChunkStage:
    def __init__(self, label, rules):
        self.label = label
        self.rules = rules

    def apply(self, children):
        def tag_of(c):
            return c.label() if isinstance(c, Tree) else c[1]
        # string with one <tag> per child
        s = "".join("<%s>" % tag_of(c) for c in children)
        for r in self.rules:
            s = r.regex.sub(r.repl, s)
        # now map back: walk through s, aligning with children
        out = []
        idx = 0
        cur = None
        pos = 0
        for m in re.finditer(r"\{|\}|<[^<>{}]*>", s):
            t = m.group()
            if t == "{":
                cur = []
            elif t == "}":
                if cur:
                    out.append(Tree(self.label, cur))
                cur = None
            else:
                (cur if cur is not None else out).append(children[idx])
                idx += 1
        if idx != len(children):
            raise ValueError("chunk string misaligned (tags may contain brackets)")
        return out


_RULE_SPLIT = re.compile(r"(?P<rule>(\\.|[^#])*)(?P<comment>#.*)?")


def _parse_rule(s):
    m = _RULE_SPLIT.match(s)
    rule = m.group("rule").strip()
    if not rule:
        raise ValueError("Empty chunk pattern")
    if rule[0] == "{" and rule[-1] == "}":
        return ChunkRule(rule[1:-1])
    if rule[0] == "}" and rule[-1] == "{":
        return ChinkRule(rule[1:-1])
    raise ValueError("Illegal chunk pattern: %s" % rule)


def parse_grammar(grammar):
    stages = []
    label, rules = None, []
    for line in grammar.split("\n"):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        m = re.match(r"(?P<nt>(\\.|[^:])*):(?P<rule>.*)", line)
        if m:
            if label is not None:
                stages.append(ChunkStage(label, rules))
            label = m.group("nt").strip()
            rules = []
            line = m.group("rule").strip()
            if not line:
                continue
        if label is None:
            raise ValueError("Grammar must start with a '<LABEL>:' line")
        rules.append(_parse_rule(line))
    if label is not None:
        stages.append(ChunkStage(label, rules))
    return stages


class RegexpParser:
    def __init__(self, grammar, root_label=DEFAULT_ROOT, loop=1):
        if isinstance(grammar, str):
            self._stages = parse_grammar(grammar)
        else:
            self._stages = list(grammar)
        self._root = root_label
        self._loop = loop

    def parse(self, tagged):
        children = [tuple(t) if isinstance(t, list) else t for t in tagged]
        for _ in range(self._loop):
            for st in self._stages:
                children = st.apply(children)
        return Tree(self._root, children)


def ne_chunk(tagged_tokens, binary=False):
    data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    data.find("corpora/words")
    raise NotImplementedError("named-entity chunking is not implemented")
