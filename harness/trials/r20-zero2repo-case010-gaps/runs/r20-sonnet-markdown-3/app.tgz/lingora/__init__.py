"""LINGORA - the Lingora Language Toolkit (pure Python NLP library)."""
from . import data  # noqa: F401

__version__ = "0.1.0"
