"""Tokenizers."""
import os
import re

from . import data

__all__ = ["RegexpTokenizer", "TreebankWordTokenizer", "TweetTokenizer", "WhitespaceTokenizer",
           "WordPunctTokenizer", "BlanklineTokenizer", "NLTKWordTokenizer", "blankline_tokenize",
           "sent_tokenize", "word_tokenize", "wordpunct_tokenize", "PunktSentenceTokenizer"]


class RegexpTokenizer:
    def __init__(self, pattern, gaps=False, discard_empty=True, flags=re.UNICODE | re.MULTILINE | re.DOTALL):
        self._pattern = pattern
        self._gaps = gaps
        self._discard_empty = discard_empty
        self._flags = flags
        self._regexp = re.compile(pattern, flags)

    def tokenize(self, text):
        if self._gaps:
            if self._discard_empty:
                return [t for t in self._regexp.split(text) if t]
            return self._regexp.split(text)
        out = []
        for m in self._regexp.finditer(text):
            # like findall but always the whole match (spec: successive matches)
            out.append(m.group())
        return out

    def span_tokenize(self, text):
        if self._gaps:
            for left, right in self._gap_spans(text):
                if not self._discard_empty or right > left:
                    yield left, right
        else:
            for m in self._regexp.finditer(text):
                yield m.span()

    def _gap_spans(self, text):
        last = 0
        for m in self._regexp.finditer(text):
            yield last, m.start()
            last = m.end()
        yield last, len(text)


class WhitespaceTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s+", gaps=True)


class BlanklineTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s*\n\s*\n\s*", gaps=True)


class WordPunctTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\w+|[^\w\s]+")


def wordpunct_tokenize(text):
    return WordPunctTokenizer().tokenize(text)


def blankline_tokenize(text):
    return BlanklineTokenizer().tokenize(text)


# ------------------------------------------------------------------ Treebank
class TreebankWordTokenizer:
    STARTING_QUOTES = [
        (re.compile(r"^\""), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
    ]
    PUNCTUATION = [
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.\.\."), r" ... "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\']*)\s*$'), r"\1 \2\3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
    ]
    PARENS_BRACKETS = (re.compile(r"[\]\[\(\)\{\}\<\>]"), r" \g<0> ")
    DOUBLE_DASHES = (re.compile(r"--"), r" -- ")
    ENDING_QUOTES = [
        (re.compile(r'"'), " '' "),
        (re.compile(r"(\S)(\'\')"), r"\1 \2 "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    CONTRACTIONS2 = [re.compile(r) for r in (
        r"(?i)\b(can)(?#X)(not)\b", r"(?i)\b(d)(?#X)('ye)\b", r"(?i)\b(gim)(?#X)(me)\b",
        r"(?i)\b(gon)(?#X)(na)\b", r"(?i)\b(got)(?#X)(ta)\b", r"(?i)\b(lem)(?#X)(me)\b",
        r"(?i)\b(more)(?#X)('n)\b", r"(?i)\b(wan)(?#X)(na)(?=\s)")]
    CONTRACTIONS3 = [re.compile(r) for r in (r"(?i) ('t)(?#X)(is)\b", r"(?i) ('t)(?#X)(was)\b")]

    def tokenize(self, text):
        for rx, sub in self.STARTING_QUOTES:
            text = rx.sub(sub, text)
        for rx, sub in self.PUNCTUATION:
            text = rx.sub(sub, text)
        text = self.PARENS_BRACKETS[0].sub(self.PARENS_BRACKETS[1], text)
        text = self.DOUBLE_DASHES[0].sub(self.DOUBLE_DASHES[1], text)
        text = " " + text + " "
        for rx, sub in self.ENDING_QUOTES:
            text = rx.sub(sub, text)
        for rx in self.CONTRACTIONS2:
            text = rx.sub(r" \1 \2 ", text)
        for rx in self.CONTRACTIONS3:
            text = rx.sub(r" \1 \2 ", text)
        return text.split()

    def span_tokenize(self, text):
        # align tokens with the original text
        toks = self.tokenize(text)
        raw = []
        for t in toks:
            raw.append({"``": '"', "''": '"'}.get(t, t))
        pos = 0
        for tok, alt in zip(toks, raw):
            i = text.find(tok, pos)
            use = tok
            if i < 0:
                i = text.find(alt, pos)
                use = alt
            if i < 0:
                raise ValueError("Could not align token %r" % tok)
            yield i, i + len(use)
            pos = i + len(use)


class NLTKWordTokenizer(TreebankWordTokenizer):
    STARTING_QUOTES = [
        (re.compile("([«“‘„]|[`]+)"), r" \1 "),
        (re.compile(r"^\""), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
    ]
    PUNCTUATION = [
        (re.compile(r"([^\.])(\.)([\]\)}>\"\'" "»”’ " r"]*)\s*$"), r"\1 \2\3 "),
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.{2,}"), r" \g<0> "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
        (re.compile(r"[*]"), r" \g<0> "),
        (re.compile("[‒-―]"), r" \g<0> "),
    ]
    ENDING_QUOTES = [
        (re.compile(r"([»”’])"), r" \1 "),
    ] + TreebankWordTokenizer.ENDING_QUOTES


_treebank = TreebankWordTokenizer()
_nltkword = NLTKWordTokenizer()


# -------------------------------------------------------------------- Punkt
_ORTHO_BEG_UC, _ORTHO_MID_UC, _ORTHO_UNK_UC = 2, 4, 8
_ORTHO_UC = 14
_ORTHO_BEG_LC, _ORTHO_MID_LC, _ORTHO_UNK_LC = 16, 32, 64
_ORTHO_LC = 112

_RE_NON_WORD = r"(?:[?!)\";}\]\*:@\'\({\[])"
_RE_MULTI = r"(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"
_RE_WORD_START = r"[^\(\"\`{\[:;&\#\*@\)}\]\-,]"
_WORD_RE = re.compile(
    r"""(
        %(MultiChar)s
        |
        (?=%(WordStart)s)\S+?
        (?=
            \s|
            $|
            %(NonWord)s|%(MultiChar)s|
            ,(?=$|\s|%(NonWord)s|%(MultiChar)s)
        )
        |
        \S
    )""" % {"NonWord": _RE_NON_WORD, "MultiChar": _RE_MULTI, "WordStart": _RE_WORD_START},
    re.UNICODE | re.VERBOSE)
_PERIOD_CONTEXT_RE = re.compile(
    r"""
        \S*
        [.?!]
        (?=(?P<after_tok>
            %(NonWord)s
            |
            \s+(?P<next_tok>\S+)
        ))
    """ % {"NonWord": _RE_NON_WORD}, re.UNICODE | re.VERBOSE)
_REALIGN_RE = re.compile(r"[\"')\]}]+?(?:\s+|(?=--)|$)", re.UNICODE)

_RE_NUMERIC = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_RE_ELLIPSIS = re.compile(r"\.\.+$")
_RE_INITIAL = re.compile(r"[^\W\d]\.$")


class _Tok:
    __slots__ = ("tok", "type", "period_final", "sentbreak", "abbr", "ellipsis", "first_upper",
                 "first_lower", "type_no_period", "type_no_sentperiod", "is_ellipsis", "is_initial")

    def __init__(self, tok):
        self.tok = tok
        self.type = _RE_NUMERIC.sub("##number##", tok.lower())
        self.period_final = tok.endswith(".")
        self.sentbreak = False
        self.abbr = False
        self.ellipsis = False
        self.first_upper = tok[0].isupper()
        self.first_lower = tok[0].islower()
        self.is_ellipsis = bool(_RE_ELLIPSIS.match(tok))
        self.is_initial = bool(_RE_INITIAL.match(tok))
        self.type_no_period = self.type[:-1] if len(self.type) > 1 and self.type[-1] == "." else self.type
        self.type_no_sentperiod = self.type_no_period


class PunktParameters:
    def __init__(self):
        self.abbrev_types = set()
        self.collocations = set()
        self.sent_starters = set()
        self.ortho_context = {}


class PunktSentenceTokenizer:
    def __init__(self, params):
        self._params = params

    @classmethod
    def from_directory(cls, d):
        p = PunktParameters()

        def lines(name):
            with open(os.path.join(d, name), encoding="utf-8") as f:
                for line in f.read().split("\n"):
                    line = line.rstrip("\r")
                    if line != "":
                        yield line
        p.abbrev_types = set(lines("abbrev_types.txt"))
        p.sent_starters = set(lines("sent_starters.txt"))
        for l in lines("collocations.tab"):
            parts = l.split("\t")
            if len(parts) >= 2:
                p.collocations.add((parts[0], parts[1]))
        for l in lines("ortho_context.tab"):
            parts = l.split("\t")
            if len(parts) >= 2:
                p.ortho_context[parts[0]] = int(parts[1])
        return cls(p)

    # --- tokenization into annotated tokens
    def _tokenize_words(self, text):
        for line in text.split("\n"):
            if line.strip():
                for tok in _WORD_RE.findall(line):
                    yield _Tok(tok)

    def _first_pass(self, t):
        tok = t.tok
        if tok in (".", "?", "!"):
            t.sentbreak = True
        elif t.is_ellipsis:
            t.ellipsis = True
        elif t.period_final and not tok.endswith(".."):
            ab = self._params.abbrev_types
            if tok[:-1].lower() in ab or tok[:-1].lower().split("-")[-1] in ab:
                t.abbr = True
            else:
                t.sentbreak = True
        t.type_no_sentperiod = t.type_no_period if not t.sentbreak else t.type
        return t

    def _ortho_heuristic(self, t):
        if t.tok in (";", ":", ",", ".", "!", "?"):
            return False
        oc = self._params.ortho_context.get(t.type_no_sentperiod, 0)
        if t.first_upper and (oc & _ORTHO_LC) and not (oc & _ORTHO_MID_UC):
            return True
        if t.first_lower and ((oc & _ORTHO_UC) or not (oc & _ORTHO_BEG_LC)):
            return False
        return "unknown"

    def _second_pass(self, t1, t2):
        if t2 is None or not t1.period_final:
            return
        typ = t1.type_no_period
        next_typ = t2.type_no_sentperiod
        initial = t1.is_initial
        P = self._params
        if (typ, next_typ) in P.collocations:
            t1.sentbreak = False
            t1.abbr = True
            return
        if (t1.abbr or t1.ellipsis) and not initial:
            if self._ortho_heuristic(t2) is True:
                t1.sentbreak = True
                return
            if t2.first_upper and next_typ in P.sent_starters:
                t1.sentbreak = True
                return
        if initial or typ == "##number##":
            h = self._ortho_heuristic(t2)
            if h is False:
                t1.sentbreak = False
                t1.abbr = True
                return
            if (h == "unknown" and initial and t2.first_upper
                    and not (P.ortho_context.get(next_typ, 0) & _ORTHO_LC)):
                t1.sentbreak = False
                t1.abbr = True

    def _contains_sentbreak(self, text):
        toks = [self._first_pass(t) for t in self._tokenize_words(text)]
        for i, t in enumerate(toks):
            self._second_pass(t, toks[i + 1] if i + 1 < len(toks) else None)
        found = False
        for t in toks:
            if found:
                return True
            if t.sentbreak:
                found = True
        return False

    def _potential_contexts(self, text):
        prev_slice = (0, 0)
        prev_match = None
        for m in _PERIOD_CONTEXT_RE.finditer(text):
            before = text[prev_slice[1]:m.start()]
            idx = 0
            for k in range(len(before) - 1, -1, -1):
                if before[k].isspace():
                    idx = k
                    break
            if idx:
                start = idx + prev_slice[1] + 1
            else:
                start = prev_slice[0]
            cur = (start, m.start())
            if prev_match is not None and prev_slice[1] <= cur[0]:
                yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + prev_match.group("after_tok")
            prev_match = m
            prev_slice = cur
        if prev_match is not None:
            yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + prev_match.group("after_tok")

    def _slices(self, text):
        last = 0
        out = []
        for m, ctx in self._potential_contexts(text):
            if self._contains_sentbreak(ctx):
                out.append((last, m.end()))
                last = m.start("next_tok") if m.group("next_tok") else m.end()
        out.append((last, len(text.rstrip())))
        return out

    def span_tokenize(self, text, realign_boundaries=True):
        slices = self._slices(text)
        if realign_boundaries:
            slices = self._realign(text, slices)
        for s in slices:
            yield s

    def _realign(self, text, slices):
        realign = 0
        out = []
        n = len(slices)
        for i in range(n):
            s1 = (slices[i][0] + realign, slices[i][1])
            s2 = slices[i + 1] if i + 1 < n else None
            if s2 is None:
                if text[s1[0]:s1[1]]:
                    out.append(s1)
                continue
            m = _REALIGN_RE.match(text[s2[0]:s2[1]])
            if m:
                out.append((s1[0], s2[0] + len(m.group(0).rstrip())))
                realign = m.end()
            else:
                realign = 0
                if text[s1[0]:s1[1]]:
                    out.append(s1)
        return out

    def tokenize(self, text, realign_boundaries=True):
        return [text[a:b] for a, b in self.span_tokenize(text, realign_boundaries)]


_cache = {}


def _load_punkt(language):
    d = data.find("tokenizers/punkt_tab/%s" % language)
    files = ("abbrev_types.txt", "sent_starters.txt", "collocations.tab", "ortho_context.tab")
    key = [d]
    for f in files:
        fp = os.path.join(d, f)
        st = os.stat(fp)  # raises if missing
        key.append((st.st_mtime_ns, st.st_size))
    key = tuple(key)
    if key not in _cache:
        if len(_cache) > 8:
            _cache.clear()
        _cache[key] = PunktSentenceTokenizer.from_directory(d)
    return _cache[key]


def sent_tokenize(text, language="english"):
    return _load_punkt(language).tokenize(text)


def word_tokenize(text, language="english", preserve_line=False):
    if preserve_line:
        sentences = [text]
    else:
        sentences = sent_tokenize(text, language)
    out = []
    for s in sentences:
        out.extend(_nltkword.tokenize(s))
    return out


# --------------------------------------------------------------------- Tweet
_EMOTICONS = (r"(?:[<>]?[:;=8][\-o\*\']?[\)\]\(\[dDpP/\:\}\{@\|\\]"
              r"|[\)\]\(\[dDpP/\:\}\{@\|\\][\-o\*\']?[:;=8][<>]?|<3)")
_URLS = (r"(?:https?://|www\.)[^\s<>\"]*[^\s<>\"\.,;:!?\)\]\}'`]"
         r"|(?:https?://|www\.)[^\s<>\"]+")
_PHONE = (r"(?:(?:\+?[01][ *\-.\)]*)?(?:[\(]?\d{3}[ *\-.\)]*)?\d{3}[ *\-.\)]*\d{4})")
_TWEET_REGEXPS = [
    _URLS, _PHONE, _EMOTICONS, r"<[^>\s]+>", r"[\-]+>|<[\-]+", r"(?:@[\w_]+)",
    r"(?:\#+[\w_]+[\w\'_\-]*[\w_]+)",
    r"[\w.+-]+@[\w-]+\.(?:[\w-]\.?)+[\w-]",
    r"(?:[^\W\d_](?:[^\W\d_]|['\-_])+[^\W\d_])",
    r"(?:[+\-]?\d+[,/.:-]\d+[+\-]?)",
    r"(?:[\w_]+)",
    r"(?:\.(?:\s*\.){1,})",
    r"(?:\S)",
]
_WORD_RE_TWEET = re.compile("(%s)" % "|".join(_TWEET_REGEXPS), re.I | re.UNICODE)
_EMOTICON_RE = re.compile("^%s$" % _EMOTICONS, re.UNICODE)
_HANDLES_RE = re.compile(
    r"(?<![A-Za-z0-9_!@#\$%&*])@(([A-Za-z0-9_]){15}(?!@)|([A-Za-z0-9_]){1,14}(?![A-Za-z0-9_]*@))")
_LEN_RE = re.compile(r"(.)\1{2,}", re.DOTALL)
_HANG_RE = re.compile(r"([^a-zA-Z0-9])\1{3,}")


class TweetTokenizer:
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False, match_phone_numbers=True):
        self.preserve_case = preserve_case
        self.reduce_len = reduce_len
        self.strip_handles = strip_handles

    def tokenize(self, text):
        if self.strip_handles:
            text = _HANDLES_RE.sub(" ", text)
        if self.reduce_len:
            text = _LEN_RE.sub(r"\1\1\1", text)
        safe = _HANG_RE.sub(r"\1\1\1", text)
        words = [m[0] if isinstance(m, tuple) else m for m in _WORD_RE_TWEET.findall(safe)]
        if not self.preserve_case:
            words = [w if _EMOTICON_RE.match(w) else w.lower() for w in words]
        return words
