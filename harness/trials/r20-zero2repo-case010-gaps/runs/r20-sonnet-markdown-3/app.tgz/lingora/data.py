"""Locating packaged resources (models, corpora)."""
import os

path = [p for p in (
    os.environ.get("LINGORA_DATA"),
    os.path.expanduser("~/lingora_data"),
    "/usr/share/lingora_data",
    "/usr/local/share/lingora_data",
    "/usr/share/nltk_data",
    "/usr/local/share/nltk_data",
    os.path.expanduser("~/nltk_data"),
) if p]


def find(resource):
    """Return the filesystem path of ``resource`` (relative name) found in
    ``path``; raise LookupError if it is not visible."""
    for d in list(path):
        cand = os.path.join(str(d), *resource.split("/"))
        if os.path.exists(cand):
            return cand
    raise LookupError("Resource %r not found in data.path %r" % (resource, list(path)))
