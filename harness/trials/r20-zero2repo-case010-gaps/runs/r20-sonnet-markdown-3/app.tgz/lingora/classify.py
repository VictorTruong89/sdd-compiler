"""Naive Bayes and decision tree classifiers."""
import math
from collections import Counter, defaultdict


def _max_key(counter):
    best, bc = None, None
    for k, c in counter.items():
        if bc is None or c > bc:
            best, bc = k, c
    return best


class DictionaryProbDist:
    def __init__(self, logprobs):
        m = max(logprobs.values())
        if m == float("-inf"):
            n = len(logprobs)
            self._p = {k: 1.0 / n for k in logprobs}
        else:
            tot = m + math.log(sum(math.exp(v - m) for v in logprobs.values()))
            self._p = {k: math.exp(v - tot) for k, v in logprobs.items()}
            s = sum(self._p.values())
            self._p = {k: v / s for k, v in self._p.items()}

    def prob(self, sample):
        return float(self._p.get(sample, 0.0))

    def logprob(self, sample):
        p = self.prob(sample)
        return math.log(p) if p > 0 else float("-inf")

    def samples(self):
        return list(self._p.keys())

    def max(self):
        return _max_key(self._p)

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._p)


class _ELE:
    def __init__(self, freq, bins):
        self.freq = freq
        self.N = sum(freq.values())
        self.bins = bins

    def logprob(self, sample):
        return math.log((self.freq.get(sample, 0) + 0.5) / (self.N + 0.5 * self.bins))


class NaiveBayesClassifier:
    def __init__(self, label_probdist, feature_probdist):
        self._label_probdist = label_probdist
        self._feature_probdist = feature_probdist
        self._labels = list(label_probdist.freq.keys())

    def labels(self):
        return list(self._labels)

    def classify(self, featureset):
        return self.prob_classify(featureset).max()

    def classify_many(self, featuresets):
        return [self.classify(fs) for fs in featuresets]

    def prob_classify(self, featureset):
        fs = dict(featureset)
        for fname in list(fs):
            if not any((label, fname) in self._feature_probdist for label in self._labels):
                del fs[fname]
        logprob = {}
        for label in self._labels:
            logprob[label] = self._label_probdist.logprob(label)
        for label in self._labels:
            for fname, fval in fs.items():
                pd = self._feature_probdist.get((label, fname))
                if pd is not None:
                    logprob[label] += pd.logprob(fval)
                else:
                    logprob[label] += float("-inf")
        return DictionaryProbDist(logprob)

    @classmethod
    def train(cls, labeled_featuresets):
        label_freq = Counter()
        feature_freq = defaultdict(Counter)
        feature_values = defaultdict(set)
        fnames = set()
        for featureset, label in labeled_featuresets:
            label_freq[label] += 1
            for fname, fval in featureset.items():
                feature_freq[label, fname][fval] += 1
                feature_values[fname].add(fval)
                fnames.add(fname)
        for label in label_freq:
            num = label_freq[label]
            for fname in fnames:
                count = sum(feature_freq[label, fname].values())
                if num - count > 0:
                    feature_freq[label, fname][None] += num - count
                    feature_values[fname].add(None)
        label_pd = _ELE(label_freq, len(label_freq))
        fpd = {}
        for (label, fname), fd in feature_freq.items():
            fpd[label, fname] = _ELE(fd, len(feature_values[fname]))
        return cls(label_pd, fpd)


def _entropy(counter):
    n = sum(counter.values())
    return -sum((c / n) * math.log2(c / n) for c in counter.values() if c)


class DecisionTreeClassifier:
    def __init__(self, label, feature_name=None, decisions=None, default=None):
        self._label = label
        self._fname = feature_name
        self._decisions = decisions
        self._default = default

    def labels(self):
        out = [self._label]
        if self._decisions:
            for d in self._decisions.values():
                for l in d.labels():
                    if l not in out:
                        out.append(l)
        return out

    def classify(self, featureset):
        if self._fname is None:
            return self._label
        fval = featureset.get(self._fname)
        if fval in self._decisions:
            return self._decisions[fval].classify(featureset)
        if self._default is not None:
            return self._default.classify(featureset)
        return self._label

    def classify_many(self, featuresets):
        return [self.classify(fs) for fs in featuresets]

    def error(self, labeled):
        errors = sum(1 for fs, l in labeled if self.classify(fs) != l)
        return errors / len(labeled)

    @staticmethod
    def leaf(labeled):
        return DecisionTreeClassifier(_max_key(Counter(l for _, l in labeled)))

    @staticmethod
    def stump(fname, labeled):
        label = _max_key(Counter(l for _, l in labeled))
        freqs = defaultdict(Counter)
        for fs, l in labeled:
            freqs[fs.get(fname)][l] += 1
        decisions = {v: DecisionTreeClassifier(_max_key(f)) for v, f in freqs.items()}
        return DecisionTreeClassifier(label, fname, decisions)

    @staticmethod
    def best_stump(fnames, labeled):
        best = DecisionTreeClassifier.leaf(labeled)
        best_err = best.error(labeled)
        for fname in sorted(fnames, key=str):
            s = DecisionTreeClassifier.stump(fname, labeled)
            e = s.error(labeled)
            if e < best_err:
                best, best_err = s, e
        return best

    def refine(self, labeled, entropy_cutoff, depth_cutoff, support_cutoff):
        if len(labeled) <= support_cutoff or self._fname is None or depth_cutoff <= 0:
            return
        for fval in list(self._decisions):
            sub = [(fs, l) for fs, l in labeled if fs.get(self._fname) == fval]
            if not sub:
                continue
            if _entropy(Counter(l for _, l in sub)) > entropy_cutoff:
                self._decisions[fval] = DecisionTreeClassifier.train(
                    sub, entropy_cutoff, depth_cutoff, support_cutoff)

    @staticmethod
    def train(labeled_featuresets, entropy_cutoff=0.05, depth_cutoff=100, support_cutoff=10):
        labeled_featuresets = list(labeled_featuresets)
        if not labeled_featuresets:
            raise ValueError("no training data")
        fnames = set()
        for fs, _ in labeled_featuresets:
            fnames.update(fs)
        tree = DecisionTreeClassifier.best_stump(fnames, labeled_featuresets)
        tree.refine(labeled_featuresets, entropy_cutoff, depth_cutoff - 1, support_cutoff)
        return tree

    def pretty_format(self, width=70, prefix="", depth=4):
        if self._fname is None:
            return "%s%s\n" % (prefix, self._label)
        s = ""
        for val, d in self._decisions.items():
            s += "%s%s=%r? " % (prefix, self._fname, val)
            s += d.pretty_format(width, prefix + "  ", depth)
        return s

    def __str__(self):
        return self.pretty_format()


def accuracy(classifier, gold):
    gold = list(gold)
    results = classifier.classify_many([fs for fs, _ in gold])
    correct = [l == r for (_, l), r in zip(gold, results)]
    return sum(correct) / len(correct) if correct else 0.0
