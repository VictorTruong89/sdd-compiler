"""BLEU score."""
import math
import sys
from collections import Counter


def _ngrams(seq, n):
    return [tuple(seq[i:i + n]) for i in range(len(seq) - n + 1)]


def _modified_precision(references, hypothesis, n):
    counts = Counter(_ngrams(hypothesis, n))
    max_counts = {}
    for ref in references:
        rc = Counter(_ngrams(ref, n))
        for ng in counts:
            max_counts[ng] = max(max_counts.get(ng, 0), rc[ng])
    clipped = {ng: min(c, max_counts.get(ng, 0)) for ng, c in counts.items()}
    return sum(clipped.values()), max(1, sum(counts.values()))


class SmoothingFunction:
    def __init__(self, epsilon=0.1, alpha=5, k=5):
        self.epsilon = epsilon
        self.alpha = alpha
        self.k = k

    def method0(self, p_n, references, hypothesis, hyp_len):
        return [(n, d) if n != 0 else (sys.float_info.min, 1) for n, d in p_n]

    def method1(self, p_n, references, hypothesis, hyp_len):
        return [(n, d) if n != 0 else (self.epsilon, d) for n, d in p_n]

    def method2(self, p_n, references, hypothesis, hyp_len):
        return [(n + 1, d + 1) if i != 0 else (n, d) for i, (n, d) in enumerate(p_n)]

    def method3(self, p_n, references, hypothesis, hyp_len):
        incvnt = 1
        out = []
        for n, d in p_n:
            if n == 0:
                incvnt *= 2
                out.append((1.0 / (incvnt * d), 1))
            else:
                out.append((n, d))
        return out


def bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):
    references = [list(r) for r in references]
    hypothesis = list(hypothesis)
    weights = list(weights)
    num_den = []
    for i, _ in enumerate(weights, start=1):
        num_den.append(_modified_precision(references, hypothesis, i))
    if not num_den or num_den[0][0] == 0:
        return 0
    hyp_len = len(hypothesis)
    ref_len = min((len(r) for r in references),
                  key=lambda rl: (abs(rl - hyp_len), rl))
    if hyp_len > ref_len:
        bp = 1
    elif hyp_len == 0:
        bp = 0
    else:
        bp = math.exp(1 - ref_len / hyp_len)
    if smoothing_function is None:
        smoothing_function = SmoothingFunction().method0
    p_n = smoothing_function(num_den, references, hypothesis, hyp_len)
    s = []
    for w, (n, d) in zip(weights, p_n):
        p = n / d
        if p <= 0:
            p = sys.float_info.min
        s.append(w * math.log(p))
    return bp * math.exp(math.fsum(s))


sentence_bleu = bleu
