from .chart import ChartParser


class RecursiveDescentParser(ChartParser):
    """Exhaustive parser (same results as the chart parser)."""
