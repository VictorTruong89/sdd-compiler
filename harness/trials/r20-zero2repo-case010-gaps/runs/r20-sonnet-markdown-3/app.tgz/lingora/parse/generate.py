import sys
import itertools
from ..grammar import Nonterminal


def generate(grammar, start=None, depth=None, n=None):
    if start is None:
        start = grammar.start()
    elif not isinstance(start, Nonterminal):
        start = Nonterminal(start)
    if depth is None:
        depth = sys.maxsize
    it = _generate_all(grammar, [start], depth)
    if n is not None:
        it = itertools.islice(it, n)
    return it


def _generate_all(grammar, items, depth):
    if items:
        try:
            for frag1 in _generate_one(grammar, items[0], depth):
                for frag2 in _generate_all(grammar, items[1:], depth):
                    yield frag1 + frag2
        except RecursionError as error:
            raise RuntimeError("The grammar has rule(s) that generate infinite sentences.") from error
    else:
        yield []


def _generate_one(grammar, lhs, depth):
    if depth > 0:
        if isinstance(lhs, Nonterminal):
            for prod in grammar.productions(lhs):
                yield from _generate_all(grammar, prod.rhs(), depth - 1)
        else:
            yield [lhs]
