from ..grammar import Nonterminal
from ..tree import Tree
from .chart import _check_coverage


class ShiftReduceParser:
    def __init__(self, grammar, trace=0):
        self._grammar = grammar

    def grammar(self):
        return self._grammar

    def parse(self, tokens):
        tokens = list(tokens)
        _check_coverage(self._grammar, tokens)
        return iter(self._parse(tokens))

    def _reduce(self, stack):
        for prod in self._grammar.productions():
            rhs = prod.rhs()
            n = len(rhs)
            if n == 0 or n > len(stack):
                continue
            ok = True
            for sym, item in zip(rhs, stack[-n:]):
                if isinstance(sym, Nonterminal):
                    if not (isinstance(item, Tree) and item.label() == sym.symbol()):
                        ok = False
                        break
                elif isinstance(item, Tree) or item != sym:
                    ok = False
                    break
            if ok:
                stack[-n:] = [Tree(prod.lhs().symbol(), stack[-n:])]
                return True
        return False

    def _parse(self, tokens):
        stack = []
        remaining = list(tokens)
        while remaining:
            stack.append(remaining.pop(0))
            while self._reduce(stack):
                pass
        if len(stack) == 1 and isinstance(stack[0], Tree) \
                and stack[0].label() == self._grammar.start().symbol():
            return [stack[0]]
        return []
