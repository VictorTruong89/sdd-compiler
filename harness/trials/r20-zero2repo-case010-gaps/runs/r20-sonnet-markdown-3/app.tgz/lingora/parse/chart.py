from ..grammar import Nonterminal
from ..tree import Tree


def _check_coverage(grammar, tokens):
    missing = [t for t in tokens if t not in grammar.terminals()]
    if missing:
        raise ValueError("Grammar does not cover some of the input words: %r" % (missing,))


class ChartParser:
    def __init__(self, grammar, **kwargs):
        self._grammar = grammar

    def grammar(self):
        return self._grammar

    def parse(self, tokens, tree_class=Tree):
        tokens = list(tokens)
        _check_coverage(self._grammar, tokens)
        return iter(self._parses(tokens))

    def chart_parse(self, tokens):
        return self.parse(tokens)

    def _parses(self, tokens):
        g = self._grammar
        n = len(tokens)
        memo = {}
        active = set()
        by_lhs = {}
        for p in g.productions():
            by_lhs.setdefault(p.lhs(), []).append(p)

        def sym(s, i, j):
            key = (s, i, j)
            if key in memo:
                return memo[key]
            if key in active:
                return []
            active.add(key)
            res = []
            for p in by_lhs.get(s, ()):
                for kids in seq(p.rhs(), 0, i, j):
                    res.append(Tree(s.symbol(), kids))
            active.discard(key)
            memo[key] = res
            return res

        def seq(rhs, k, i, j):
            if k == len(rhs):
                if i == j:
                    yield []
                return
            s = rhs[k]
            if isinstance(s, Nonterminal):
                for m in range(i, j + 1):
                    for t in sym(s, i, m):
                        for rest in seq(rhs, k + 1, m, j):
                            yield [t] + rest
            else:
                if s == "":
                    yield from seq(rhs, k + 1, i, j)
                elif i < j and tokens[i] == s:
                    for rest in seq(rhs, k + 1, i + 1, j):
                        yield [s] + rest

        return sym(g.start(), 0, n)
