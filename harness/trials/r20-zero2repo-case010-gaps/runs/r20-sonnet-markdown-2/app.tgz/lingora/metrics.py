"""Evaluation metrics."""

__all__ = ["accuracy", "edit_distance", "jaccard_distance", "precision", "recall", "f_measure"]


def accuracy(reference, test):
    if not isinstance(reference, (list, tuple)) or not isinstance(test, (list, tuple)):
        raise TypeError("accuracy expects two lists")
    if len(reference) != len(test):
        raise ValueError("Lists must have the same length.")
    return sum(x == y for x, y in zip(reference, test)) / len(test)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    len1, len2 = len(s1), len(s2)
    lev = [[0] * (len2 + 1) for _ in range(len1 + 1)]
    for i in range(len1 + 1):
        lev[i][0] = i
    for j in range(len2 + 1):
        lev[0][j] = j
    last_left_t = {}
    for i in range(1, len1 + 1):
        last_right_buf = 0
        c1 = s1[i - 1]
        for j in range(1, len2 + 1):
            c2 = s2[j - 1]
            last_left = last_left_t.get(c2, 0)
            last_right = last_right_buf
            if c1 == c2:
                last_right_buf = j
            a = lev[i - 1][j] + 1
            b = lev[i][j - 1] + 1
            c = lev[i - 1][j - 1] + (substitution_cost if c1 != c2 else 0)
            d = c + 1
            if transpositions and last_left > 0 and last_right > 0:
                d = lev[last_left - 1][last_right - 1] + (i - last_left - 1) + (j - last_right - 1) + 1
            lev[i][j] = min(a, b, c, d)
        last_left_t[c1] = i
    return lev[len1][len2]


def jaccard_distance(label1, label2):
    u = len(label1.union(label2))
    return (u - len(label1.intersection(label2))) / u


def _sets(reference, test):
    if not hasattr(reference, "intersection") or not hasattr(test, "intersection"):
        raise TypeError("reference and test should be sets")


def precision(reference, test):
    _sets(reference, test)
    if len(test) == 0:
        return None
    return len(reference.intersection(test)) / len(test)


def recall(reference, test):
    _sets(reference, test)
    if len(reference) == 0:
        return None
    return len(reference.intersection(test)) / len(reference)


def f_measure(reference, test, alpha=0.5):
    p = precision(reference, test)
    r = recall(reference, test)
    if p is None or r is None:
        return None
    if p == 0 or r == 0:
        return 0
    return 1.0 / (alpha / p + (1 - alpha) / r)
