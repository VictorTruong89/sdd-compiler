"""Grammar-based parsers."""
from ..grammar import Nonterminal
from ..tree import Tree


class ChartParser:
    """Exhaustive parser: returns every tree the grammar assigns."""

    def __init__(self, grammar):
        self._grammar = grammar

    def grammar(self):
        return self._grammar

    def parse(self, tokens):
        tokens = list(tokens)
        g = self._grammar
        g.check_coverage(tokens)
        n = len(tokens)
        prods = {}
        for p in g.productions():
            prods.setdefault(p.lhs(), []).append(p)

        # recognition: derivable[(A, i, j)] by fixpoint
        der = set()

        def seq_ends(rhs, k, i):
            """set of end positions for rhs[k:] starting at i"""
            if k == len(rhs):
                return {i}
            s = rhs[k]
            out = set()
            if isinstance(s, Nonterminal):
                for j in range(i, n + 1):
                    if (s, i, j) in der:
                        out |= seq_ends(rhs, k + 1, j)
            elif s == "":
                out |= seq_ends(rhs, k + 1, i)
            elif i < n and tokens[i] == s:
                out |= seq_ends(rhs, k + 1, i + 1)
            return out

        changed = True
        while changed:
            changed = False
            for lhs, ps in prods.items():
                for i in range(n + 1):
                    for p in ps:
                        for j in seq_ends(p.rhs(), 0, i):
                            if (lhs, i, j) not in der:
                                der.add((lhs, i, j))
                                changed = True

        start = g.start()
        if (start, 0, n) not in der:
            return iter([])

        memo = {}
        hit = [False]

        def build(sym, i, j, stack):
            key = (sym, i, j)
            if key in memo:
                return memo[key]
            if key in stack:
                hit[0] = True
                return []
            stack = stack | {key}
            before = hit[0]
            hit[0] = False
            res = []
            for p in prods.get(sym, []):
                for kids in seq(p.rhs(), 0, i, j, stack):
                    res.append(Tree(sym.symbol(), kids))
            if not hit[0]:
                memo[key] = res
            hit[0] = hit[0] or before
            return res

        def seq(rhs, k, i, j, stack):
            if k == len(rhs):
                if i == j:
                    yield []
                return
            s = rhs[k]
            if isinstance(s, Nonterminal):
                for m in range(i, j + 1):
                    if (s, i, m) in der:
                        subs = build(s, i, m, stack)
                        if not subs:
                            continue
                        for rest in seq(rhs, k + 1, m, j, stack):
                            for t in subs:
                                yield [t] + rest
            elif s == "":
                yield from seq(rhs, k + 1, i, j, stack)
            elif i < j and tokens[i] == s:
                for rest in seq(rhs, k + 1, i + 1, j, stack):
                    yield [s] + rest

        return iter(build(start, 0, n, frozenset()))


class ShiftReduceParser:
    """Single left-to-right shift-reduce pass, no backtracking."""

    def __init__(self, grammar):
        self._grammar = grammar

    def grammar(self):
        return self._grammar

    def parse(self, tokens):
        tokens = list(tokens)
        g = self._grammar
        g.check_coverage(tokens)
        prods = [p for p in g.productions() if len(p.rhs()) > 0]
        stack = []
        remaining = tokens[:]

        def matches(rhs):
            if len(rhs) > len(stack):
                return False
            for sym, item in zip(rhs, stack[len(stack) - len(rhs):]):
                if isinstance(sym, Nonterminal):
                    if not (isinstance(item, Tree) and item.label() == sym.symbol()):
                        return False
                else:
                    if not (isinstance(item, str) and item == sym):
                        return False
            return True

        def reduce_():
            for p in prods:
                if matches(p.rhs()):
                    k = len(p.rhs())
                    t = Tree(p.lhs().symbol(), stack[-k:])
                    del stack[-k:]
                    stack.append(t)
                    return True
            return False

        while remaining:
            stack.append(remaining.pop(0))
            while reduce_():
                pass
        if len(stack) == 1 and isinstance(stack[0], Tree) \
                and stack[0].label() == g.start().symbol():
            return iter([stack[0]])
        return iter([])


class RecursiveDescentParser:
    """Backtracking top-down parser (no left recursion)."""

    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):
        tokens = list(tokens)
        g = self._grammar
        g.check_coverage(tokens)
        n = len(tokens)

        def expand(sym, i, depth):
            if depth > 200:
                return
            if isinstance(sym, Nonterminal):
                for p in g.productions(sym):
                    for kids, j in seq(p.rhs(), 0, i, depth + 1):
                        yield Tree(sym.symbol(), kids), j
            elif sym == "":
                yield None, i
            elif i < n and tokens[i] == sym:
                yield sym, i + 1

        def seq(rhs, k, i, depth):
            if k == len(rhs):
                yield [], i
                return
            for t, j in expand(rhs[k], i, depth):
                for rest, e in seq(rhs, k + 1, j, depth):
                    yield ([] if t is None else [t]) + rest, e

        out = []
        for t, j in expand(g.start(), 0, 0):
            if j == n:
                out.append(t)
        return iter(out)
