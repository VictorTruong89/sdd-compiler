"""Command-line group (a small click-compatible shim)."""
import sys

__all__ = ["cli"]


class UsageError(Exception):
    pass


def _tokenize_command(args, out, inp):
    from .tokenize import word_tokenize, _load_punkt
    language = "english"
    delimiter = " "
    encoding = "utf-8"
    i = 0
    while i < len(args):
        a = args[i]
        opt, eq, val = a.partition("=")
        if opt in ("-l", "--language", "-d", "--delimiter", "-e", "--encoding"):
            if not eq:
                i += 1
                if i >= len(args):
                    raise UsageError("Option %s requires an argument" % a)
                val = args[i]
            if opt in ("-l", "--language"):
                language = val
            elif opt in ("-d", "--delimiter"):
                delimiter = val
            else:
                encoding = val
        else:
            raise UsageError("No such option: %s" % a)
        i += 1
    for stream, mode in ((inp, "r"), (out, "w")):
        try:
            stream.reconfigure(encoding=encoding)
        except Exception:
            pass
    _load_punkt(language)  # fail before producing any output
    lines = []
    for line in inp:
        if line.endswith("\n"):
            line = line[:-1]
        if line.endswith("\r"):
            line = line[:-1]
        lines.append(word_tokenize(line, language))
    for toks in lines:
        out.write(delimiter.join(toks) + "\n")
    out.flush()


class Group:
    commands = {"tokenize": _tokenize_command}

    def main(self, args=None, standalone_mode=True, **kw):
        if args is None:
            args = sys.argv[1:]
        args = list(args)
        code = 0
        try:
            if not args or args[0] not in self.commands:
                raise UsageError("Missing or unknown command (available: %s)"
                                 % ", ".join(self.commands))
            self.commands[args[0]](args[1:], sys.stdout, sys.stdin)
        except UsageError as e:
            if not standalone_mode:
                raise
            sys.stderr.write("Error: %s\n" % e)
            code = 2
        except SystemExit:
            raise
        except BaseException as e:
            if not standalone_mode:
                raise
            sys.stderr.write("Error: %s\n" % e)
            code = 1
        if standalone_mode:
            sys.exit(code)
        return None

    __call__ = main


cli = Group()

if __name__ == "__main__":
    cli.main()
