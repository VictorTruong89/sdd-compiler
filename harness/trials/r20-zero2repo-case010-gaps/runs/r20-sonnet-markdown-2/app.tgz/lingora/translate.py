"""BLEU."""
import math
import sys
from collections import Counter

__all__ = ["bleu", "SmoothingFunction"]


class Fraction:
    """Unnormalised fraction (numerator may be 0 with any denominator)."""

    def __init__(self, numerator, denominator, _normalize=False):
        self.numerator = numerator
        self.denominator = denominator

    def __float__(self):
        return self.numerator / self.denominator

    def __repr__(self):
        return "Fraction(%s, %s)" % (self.numerator, self.denominator)


def _ngrams(seq, n):
    return [tuple(seq[i:i + n]) for i in range(len(seq) - n + 1)]


def _modified_precision(references, hypothesis, n):
    counts = Counter(_ngrams(hypothesis, n)) if len(hypothesis) >= n else Counter()
    max_counts = {}
    for ref in references:
        rc = Counter(_ngrams(ref, n)) if len(ref) >= n else Counter()
        for ng in counts:
            max_counts[ng] = max(max_counts.get(ng, 0), rc[ng])
    clipped = {ng: min(c, max_counts.get(ng, 0)) for ng, c in counts.items()}
    return Fraction(sum(clipped.values()), max(1, sum(counts.values())), _normalize=False)


class SmoothingFunction:
    def __init__(self, epsilon=0.1, alpha=5, k=5):
        self.epsilon = epsilon
        self.alpha = alpha
        self.k = k

    def method0(self, p_n, *a, **kw):
        return [p if p.numerator != 0 else sys.float_info.min for p in p_n]

    def method1(self, p_n, *a, **kw):
        return [(p.numerator + self.epsilon) / p.denominator if p.numerator == 0 else p
                for p in p_n]

    def method2(self, p_n, *a, **kw):
        return [Fraction(p.numerator + 1, p.denominator + 1, _normalize=False) if i != 0 else p
                for i, p in enumerate(p_n)]

    def method3(self, p_n, *a, **kw):
        incvnt = 1
        out = []
        for p in p_n:
            if p.numerator == 0:
                out.append(1 / (2 ** incvnt * p.denominator))
                incvnt += 1
            else:
                out.append(p)
        return out


def bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):
    weights = list(weights)
    refs = [list(r) for r in references]
    hypothesis = list(hypothesis)
    if not refs:
        raise ValueError("at least one reference is required")
    n = len(weights)
    p_n = [_modified_precision(refs, hypothesis, i) for i in range(1, n + 1)]
    hyp_len = len(hypothesis)
    ref_len = min((len(r) for r in refs), key=lambda l: (abs(l - hyp_len), l))
    if hyp_len > ref_len:
        bp = 1
    elif hyp_len == 0:
        bp = 0
    else:
        bp = math.exp(1 - ref_len / hyp_len)
    if p_n[0].numerator == 0:
        return 0
    if smoothing_function is None:
        smoothing_function = SmoothingFunction().method0
    p_n = smoothing_function(p_n, references=refs, hypothesis=hypothesis, hyp_len=hyp_len)
    s = (w * math.log(p) for w, p in zip(weights, p_n))
    return bp * math.exp(math.fsum(s))
