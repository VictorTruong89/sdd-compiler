"""Classifiers."""
import math
from collections import defaultdict

from .metrics import accuracy as _list_accuracy  # noqa: F401

__all__ = ["NaiveBayesClassifier", "DecisionTreeClassifier", "accuracy"]


def accuracy(classifier, gold):
    gold = list(gold)
    results = [classifier.classify(fs) for fs, _ in gold]
    correct = sum(r == l for r, (_, l) in zip(results, gold))
    if not gold:
        raise ZeroDivisionError("accuracy of an empty gold list is undefined")
    return correct / len(gold)


class ProbDist:
    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, sample):
        return float(self._probs.get(sample, 0.0))

    def logprob(self, sample):
        p = self.prob(sample)
        return math.log(p) if p > 0 else float("-inf")

    def samples(self):
        return list(self._probs.keys())

    def max(self):
        return max(self._probs, key=lambda k: self._probs[k])

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._probs)


class NaiveBayesClassifier:
    def __init__(self, label_probdist, feature_probdist):
        self._label_probdist = label_probdist
        self._feature_probdist = feature_probdist
        self._labels = list(label_probdist)

    def labels(self):
        return list(self._labels)

    def prob_classify(self, featureset):
        fs = dict(featureset)
        for fname in list(fs):
            if not any((lab, fname) in self._feature_probdist for lab in self._labels):
                del fs[fname]
        logp = {}
        for lab in self._labels:
            lp = math.log(self._label_probdist[lab])
            for fname, fval in fs.items():
                if (lab, fname) in self._feature_probdist:
                    lp += math.log(self._prob_of(self._feature_probdist[lab, fname], fval))
                else:
                    lp = float("-inf")
            logp[lab] = lp
        m = max(logp.values())
        if m == float("-inf"):
            probs = {lab: 1.0 / len(logp) for lab in logp}
        else:
            tot = m + math.log(sum(math.exp(v - m) for v in logp.values()))
            probs = {lab: math.exp(v - tot) for lab, v in logp.items()}
        return ProbDist(probs)

    @staticmethod
    def _prob_of(pd, fval):
        counts, n, bins = pd
        return (counts.get(fval, 0) + 0.5) / (n + 0.5 * bins)

    def classify(self, featureset):
        return self.prob_classify(featureset).max()

    @classmethod
    def train(cls, labeled_featuresets):
        label_freq = {}
        feat_freq = defaultdict(dict)
        feat_values = defaultdict(set)
        fnames = set()
        for fs, label in labeled_featuresets:
            label_freq[label] = label_freq.get(label, 0) + 1
            for fname, fval in fs.items():
                d = feat_freq[label, fname]
                d[fval] = d.get(fval, 0) + 1
                feat_values[fname].add(fval)
                fnames.add(fname)
        if not label_freq:
            raise ValueError("cannot train on an empty training set")
        for label, num in label_freq.items():
            for fname in fnames:
                d = feat_freq[label, fname]
                missing = num - sum(d.values())
                if missing > 0:
                    d[None] = d.get(None, 0) + missing
                    feat_values[fname].add(None)
        total = sum(label_freq.values())
        nl = len(label_freq)
        label_prob = {l: (c + 0.5) / (total + 0.5 * nl) for l, c in label_freq.items()}
        fprob = {}
        for (label, fname), d in feat_freq.items():
            fprob[label, fname] = (dict(d), sum(d.values()), len(feat_values[fname]))
        return cls(label_prob, fprob)


def _max_label(labels):
    counts = {}
    for l in labels:
        counts[l] = counts.get(l, 0) + 1
    best = None
    for l, c in counts.items():
        if best is None or c > counts[best]:
            best = l
    return best


def _entropy(labels):
    counts = {}
    for l in labels:
        counts[l] = counts.get(l, 0) + 1
    n = len(labels)
    return -sum((c / n) * math.log2(c / n) for c in counts.values()) if n else 0.0


class DecisionTreeClassifier:
    def __init__(self, label, feature_name=None, decisions=None, default=None):
        self._label = label
        self._fname = feature_name
        self._decisions = decisions
        self._default = default

    def classify(self, featureset):
        if self._fname is None:
            return self._label
        fval = featureset.get(self._fname)
        if fval in self._decisions:
            return self._decisions[fval].classify(featureset)
        if self._default is not None:
            return self._default.classify(featureset)
        return self._label

    def error(self, labeled):
        errs = sum(1 for fs, l in labeled if self.classify(fs) != l)
        return errs / len(labeled)

    @staticmethod
    def leaf(labeled):
        return DecisionTreeClassifier(_max_label([l for _, l in labeled]))

    @staticmethod
    def stump(fname, labeled):
        label = _max_label([l for _, l in labeled])
        groups = {}
        for fs, l in labeled:
            groups.setdefault(fs.get(fname), []).append(l)
        decisions = {v: DecisionTreeClassifier(_max_label(ls)) for v, ls in groups.items()}
        return DecisionTreeClassifier(label, fname, decisions)

    @staticmethod
    def best_stump(fnames, labeled):
        best = DecisionTreeClassifier.leaf(labeled)
        best_err = best.error(labeled)
        for fname in fnames:
            st = DecisionTreeClassifier.stump(fname, labeled)
            err = st.error(labeled)
            if err < best_err:
                best, best_err = st, err
        return best

    def refine(self, labeled, entropy_cutoff, depth_cutoff, support_cutoff):
        if len(labeled) <= support_cutoff or self._fname is None or depth_cutoff <= 0:
            return
        for fval in list(self._decisions):
            sub = [(fs, l) for fs, l in labeled if fs.get(self._fname) == fval]
            if sub and _entropy([l for _, l in sub]) > entropy_cutoff:
                self._decisions[fval] = DecisionTreeClassifier.train(
                    sub, entropy_cutoff, depth_cutoff, support_cutoff)
        if self._default is not None:
            sub = [(fs, l) for fs, l in labeled if fs.get(self._fname) not in self._decisions]
            if sub and _entropy([l for _, l in sub]) > entropy_cutoff:
                self._default = DecisionTreeClassifier.train(
                    sub, entropy_cutoff, depth_cutoff, support_cutoff)

    @classmethod
    def train(cls, labeled_featuresets, entropy_cutoff=0.05, depth_cutoff=100,
              support_cutoff=10, binary=False, feature_values=None, verbose=False):
        labeled = list(labeled_featuresets)
        if not labeled:
            raise ValueError("cannot train on an empty training set")
        fnames = []
        seen = set()
        for fs, _ in labeled:
            for f in fs:
                if f not in seen:
                    seen.add(f)
                    fnames.append(f)
        tree = cls.best_stump(fnames, labeled)
        tree.refine(labeled, entropy_cutoff, depth_cutoff - 1, support_cutoff)
        return tree
