"""Packaged-resource locator. ``path`` is a mutable list of directories."""
import os

_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

path = []
for _p in (os.environ.get("LINGORA_DATA", "").split(os.pathsep)
           + [os.path.join(_root, "lingora_data"),
              os.path.join(os.path.expanduser("~"), "lingora_data")]):
    if _p:
        path.append(_p)


def find(name, kind=None):
    """Return the first existing location of resource *name* on ``path``.

    Raises LookupError when it is not visible. *kind* may be 'dir' or 'file'.
    """
    rel = name.replace("/", os.sep)
    for d in list(path):
        cand = os.path.join(str(d), rel)
        if kind == "dir" and not os.path.isdir(cand):
            continue
        if kind == "file" and not os.path.isfile(cand):
            continue
        if os.path.exists(cand):
            return cand
    raise LookupError("Resource %r not found on lingora.data.path" % name)


def read_lines(filename):
    """Lines of a UTF-8 text file without line terminators (empty lines kept)."""
    with open(filename, encoding="utf-8", newline="") as f:
        txt = f.read()
    lines = txt.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    return [l[:-1] if l.endswith("\r") else l for l in lines]
