"""Regular-expression chunking and the named-entity chunker."""
import os
import re

from . import data
from .tree import Tree

__all__ = ["RegexpParser", "ne_chunk"]

_ITEM = re.compile(r"[{}]|<[^<>{}]*>")


def tag_pattern2re(tag_pattern):
    p = re.sub(r"\s", "", tag_pattern)
    p = p.replace("<", "(<(").replace(">", ")>)")
    p = re.sub(r"([^\\])\.", r"\1[^\{\}<>]", p)
    return p


class ChunkRule:
    def __init__(self, tag_pattern, label=None, chink=False):
        self.pattern = tag_pattern
        self.chink = chink
        try:
            core = tag_pattern2re(tag_pattern)
            if chink:
                self._re = re.compile("(?P<chink>" + core + r")(?=[^\{\}]*\})")
                self._repl = r"}\g<chink>{"
            else:
                self._re = re.compile("(?P<chunk>" + core + r")(?=[^\{\}]*(\{|$))")
                self._repl = r"{\g<chunk>}"
        except re.error as e:
            raise ValueError("Illegal tag pattern %r: %s" % (tag_pattern, e))

    def apply(self, s):
        s = self._re.sub(self._repl, s)
        return s.replace("{}", "")


class ChunkStage:
    def __init__(self, label, rules):
        self.label = label
        self.rules = rules

    def apply(self, items):
        """items: list of leaves (token, tag) or Trees; returns new item list."""
        def tag_of(it):
            return it._label if isinstance(it, Tree) else it[1]
        s = "".join("<%s>" % tag_of(it) for it in items)
        for r in self.rules:
            s = r.apply(s)
        out = []
        cur = None
        idx = 0
        for m in _ITEM.finditer(s):
            t = m.group(0)
            if t == "{":
                cur = []
            elif t == "}":
                out.append(Tree(self.label, cur or []))
                cur = None
            else:
                it = items[idx]
                idx += 1
                (cur if cur is not None else out).append(it)
        if cur is not None:
            out.append(Tree(self.label, cur))
        return out


def _parse_grammar(text):
    stages = []
    label = None
    pats = []

    def flush():
        if label is not None:
            stages.append(ChunkStage(label, list(pats)))

    for raw in text.split("\n"):
        line = raw.split("#")[0].strip() if "#" in raw and not raw.strip().startswith(("{", "}")) else raw.strip()
        if not line:
            continue
        rest = None
        if line[0] in "{}":
            rest = line
        else:
            m = re.match(r"^([^:{}]+?)\s*:\s*(.*)$", line)
            if not m:
                raise ValueError("Illegal chunk grammar line: %r" % raw)
            flush()
            label = m.group(1).strip()
            pats = []
            rest = m.group(2).strip()
        if rest:
            if label is None:
                raise ValueError("Pattern before first clause label: %r" % raw)
            if rest.startswith("{") and rest.endswith("}"):
                pats.append(ChunkRule(rest[1:-1]))
            elif rest.startswith("}") and rest.endswith("{"):
                pats.append(ChunkRule(rest[1:-1], chink=True))
            else:
                raise ValueError("Illegal chunk pattern: %r" % rest)
    flush()
    if not stages:
        raise ValueError("Chunk grammar has no clauses")
    return stages


class RegexpParser:
    def __init__(self, grammar, root_label="S"):
        self._root = root_label
        if isinstance(grammar, str):
            self._stages = _parse_grammar(grammar)
        else:
            self._stages = list(grammar)

    def parse(self, tagged):
        if isinstance(tagged, (str, bytes)):
            raise TypeError("expected a list of (token, tag) pairs")
        items = [tuple(t) for t in tagged]
        for st in self._stages:
            items = st.apply(items)
        return Tree(self._root, items)

    def __repr__(self):
        return "<RegexpParser with %d stages>" % len(self._stages)


def ne_chunk(tagged_tokens, binary=False):
    data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass", "dir")
    data.find("corpora/words")
    # The packaged model format is not interpreted; no entities are marked.
    return Tree("S", [tuple(t) for t in tagged_tokens])
