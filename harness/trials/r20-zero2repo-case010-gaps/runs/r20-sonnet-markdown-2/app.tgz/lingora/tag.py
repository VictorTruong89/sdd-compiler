"""Part-of-speech taggers."""
import json
import os
import re
from collections import defaultdict

from . import data

__all__ = ["DefaultTagger", "RegexpTagger", "UnigramTagger", "BigramTagger",
           "TrigramTagger", "AffixTagger", "pos_tag"]


def _check_tokens(tokens):
    if isinstance(tokens, (str, bytes)) or not hasattr(tokens, "__iter__"):
        raise TypeError("tokens must be a list of str, not %s" % type(tokens).__name__)
    return list(tokens)


class SequentialTagger:
    def __init__(self, backoff=None):
        self._backoff = backoff

    def choose_tag(self, tokens, index, history):
        raise NotImplementedError

    def tag(self, tokens):
        tokens = _check_tokens(tokens)
        history = []
        out = []
        for i, tok in enumerate(tokens):
            tag = self.tag_one(tokens, i, history)
            out.append((tok, tag))
            history.append(tag)
        return out

    def tag_one(self, tokens, index, history):
        tag = self.choose_tag(tokens, index, history)
        if tag is None and self._backoff is not None:
            tag = self._backoff.tag_one(tokens, index, history)
        return tag

    def tag_sents(self, sents):
        return [self.tag(s) for s in sents]


class DefaultTagger(SequentialTagger):
    def __init__(self, tag):
        SequentialTagger.__init__(self, None)
        self._tag = tag

    def choose_tag(self, tokens, index, history):
        return self._tag


class RegexpTagger(SequentialTagger):
    def __init__(self, regexps, backoff=None):
        SequentialTagger.__init__(self, backoff)
        self._regexps = [(re.compile(p), t) for p, t in regexps]

    def choose_tag(self, tokens, index, history):
        for regexp, tag in self._regexps:
            if regexp.match(tokens[index]):
                return tag
        return None


class _ContextTagger(SequentialTagger):
    N = 1

    def __init__(self, train=None, backoff=None, cutoff=0):
        SequentialTagger.__init__(self, backoff)
        self._table = {}
        if train:
            self._train(train, cutoff)

    def context(self, tokens, index, history):
        raise NotImplementedError

    def _train(self, sents, cutoff):
        counts = {}
        for sent in sents:
            toks = [w for w, _ in sent]
            hist = []
            for i, (w, t) in enumerate(sent):
                ctx = self.context(toks, i, hist)
                if ctx is not None:
                    counts.setdefault(ctx, {})
                    counts[ctx][t] = counts[ctx].get(t, 0) + 1
                hist.append(t)
        for ctx, d in counts.items():
            best = max(d, key=lambda k: d[k])  # first-seen wins ties
            if d[best] > cutoff:
                self._table[ctx] = best

    def choose_tag(self, tokens, index, history):
        ctx = self.context(tokens, index, history)
        if ctx is None:
            return None
        return self._table.get(ctx)


class UnigramTagger(_ContextTagger):
    def context(self, tokens, index, history):
        return tokens[index]


class BigramTagger(_ContextTagger):
    def context(self, tokens, index, history):
        if index == 0:
            return (None, tokens[index])
        return (history[index - 1], tokens[index])


class TrigramTagger(_ContextTagger):
    def context(self, tokens, index, history):
        p2 = history[index - 2] if index >= 2 else None
        p1 = history[index - 1] if index >= 1 else None
        return (p2, p1, tokens[index])


class AffixTagger(_ContextTagger):
    def __init__(self, train=None, backoff=None, affix_length=-3, min_stem_length=2, cutoff=0):
        self._affix_length = affix_length
        self._min_stem_length = min_stem_length
        _ContextTagger.__init__(self, train, backoff, cutoff)

    def context(self, tokens, index, history):
        tok = tokens[index]
        if len(tok) < self._min_stem_length:
            return None
        return tok[self._affix_length:] if self._affix_length < 0 else tok[:self._affix_length]


# ------------------------------------------------------- averaged perceptron
_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]


class PerceptronTagger:
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = classes

    @classmethod
    def load(cls, lang):
        d = data.find("taggers/averaged_perceptron_tagger_" + lang, "dir")
        base = os.path.join(d, "averaged_perceptron_tagger_" + lang)
        out = []
        for ext in ("weights", "tagdict", "classes"):
            p = base + "." + ext + ".json"
            if not os.path.isfile(p):
                raise LookupError("tagger model file missing: %s" % p)
            with open(p, encoding="utf-8") as f:
                out.append(json.load(f))
        return cls(*out)

    @staticmethod
    def normalize(word):
        if "-" in word and word[0] != "-":
            return "!HYPHEN"
        if word.isdigit() and len(word) == 4:
            return "!YEAR"
        if word and word[0].isdigit():
            return "!DIGITS"
        return word.lower()

    def _features(self, i, word, context, prev, prev2):
        feats = defaultdict(int)

        def add(name, *args):
            feats[" ".join((name,) + tuple(args))] += 1
        i += len(_START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[:1])
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return feats

    def predict(self, feats):
        scores = defaultdict(float)
        for feat, value in feats.items():
            if feat not in self.weights or value == 0:
                continue
            for label, w in self.weights[feat].items():
                scores[label] += value * w
        return max(self.classes, key=lambda label: (scores[label], label))

    def tag(self, tokens):
        prev, prev2 = _START
        context = _START + [self.normalize(w) for w in tokens] + _END
        out = []
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                tag = self.predict(self._features(i, word, context, prev, prev2))
            out.append((word, tag))
            prev2 = prev
            prev = tag
        return out


_RU_MAP = {
    "A": "ADJ", "A-PRO": "PRON", "ADV": "ADV", "ADV-PRO": "PRON", "ANUM": "ADJ",
    "CONJ": "CONJ", "INTJ": "X", "NONLEX": ".", "NUM": "NUM", "PARENTH": "PRT",
    "PART": "PRT", "PR": "ADP", "S": "NOUN", "S-PRO": "PRON", "V": "VERB", "COM": "X",
}


def pos_tag(tokens, tagset=None, lang="eng"):
    tokens = _check_tokens(tokens)
    if lang not in ("eng", "rus"):
        raise NotImplementedError("Currently, only 'eng' and 'rus' are supported.")
    if tagset not in (None, "universal"):
        raise ValueError("unsupported tagset %r" % (tagset,))
    tagger = PerceptronTagger.load(lang)
    table = None
    if tagset == "universal" and lang == "eng":
        d = data.find("taggers/universal_tagset", "dir")
        p = os.path.join(d, "en-ptb.map")
        if not os.path.isfile(p):
            raise LookupError("universal tagset table en-ptb.map missing")
        table = {}
        for l in data.read_lines(p):
            parts = l.split("\t")
            if len(parts) >= 2:
                table[parts[0]] = parts[1]
    tagged = tagger.tag(tokens)
    if tagset == "universal":
        if lang == "eng":
            return [(w, table.get(t, "X")) for w, t in tagged]
        return [(w, _RU_MAP.get(t.partition("=")[0], "X") if t is not None else None)
                for w, t in tagged]
    return tagged
