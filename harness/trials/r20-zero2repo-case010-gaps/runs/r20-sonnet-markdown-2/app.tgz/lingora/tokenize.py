"""Tokenizers."""
import os
import re

from . import data

__all__ = ["RegexpTokenizer", "TreebankWordTokenizer", "TweetTokenizer",
           "WhitespaceTokenizer", "WordPunctTokenizer", "blankline_tokenize",
           "sent_tokenize", "word_tokenize", "wordpunct_tokenize"]


def _check(text):
    if not isinstance(text, str):
        raise TypeError("expected str, got %s" % type(text).__name__)


class RegexpTokenizer:
    def __init__(self, pattern, gaps=False, discard_empty=True, flags=re.UNICODE | re.MULTILINE | re.DOTALL):
        self._pattern = pattern
        self._gaps = gaps
        self._discard_empty = discard_empty
        self._regexp = re.compile(pattern, flags)

    def span_tokenize(self, text):
        _check(text)
        if self._gaps:
            pos = 0
            spans = []
            for m in self._regexp.finditer(text):
                spans.append((pos, m.start()))
                pos = m.end()
            spans.append((pos, len(text)))
            for s in spans:
                if self._discard_empty and s[0] == s[1]:
                    continue
                yield s
        else:
            for m in self._regexp.finditer(text):
                if self._discard_empty and m.start() == m.end():
                    continue
                yield (m.start(), m.end())

    def tokenize(self, text):
        _check(text)
        return [text[a:b] for a, b in self.span_tokenize(text)]


class WhitespaceTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s+", gaps=True)


class WordPunctTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\w+|[^\w\s]+")


_blankline = RegexpTokenizer(r"\s*\n\s*\n\s*", gaps=True)


def blankline_tokenize(text):
    return _blankline.tokenize(text)


_wordpunct = WordPunctTokenizer()


def wordpunct_tokenize(text):
    return _wordpunct.tokenize(text)


# ---------------------------------------------------------------- Treebank
class TreebankWordTokenizer:
    STARTING_QUOTES = [
        (re.compile(r'^"'), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
    ]
    PUNCTUATION = [
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.\.\."), r" ... "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\']*)\s*$'), r"\1 \2\3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
    ]
    PARENS_BRACKETS = (re.compile(r"[\]\[\(\)\{\}\<\>]"), r" \g<0> ")
    DOUBLE_DASHES = (re.compile(r"--"), r" -- ")
    ENDING_QUOTES = [
        (re.compile(r'"'), " '' "),
        (re.compile(r"(\S)(\'\')"), r"\1 \2 "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    CONTRACTIONS2 = [re.compile(p) for p in (
        r"(?i)\b(can)(?#X)(not)\b", r"(?i)\b(d)(?#X)('ye)\b",
        r"(?i)\b(gim)(?#X)(me)\b", r"(?i)\b(gon)(?#X)(na)\b",
        r"(?i)\b(got)(?#X)(ta)\b", r"(?i)\b(lem)(?#X)(me)\b",
        r"(?i)\b(more)(?#X)('n)\b", r"(?i)\b(wan)(?#X)(na)(?=\s)")]
    CONTRACTIONS3 = [re.compile(p) for p in (
        r"(?i) ('t)(?#X)(is)\b", r"(?i) ('t)(?#X)(was)\b")]

    def tokenize(self, text):
        _check(text)
        for regexp, sub in self.STARTING_QUOTES:
            text = regexp.sub(sub, text)
        for regexp, sub in self.PUNCTUATION:
            text = regexp.sub(sub, text)
        regexp, sub = self.PARENS_BRACKETS
        text = regexp.sub(sub, text)
        regexp, sub = self.DOUBLE_DASHES
        text = regexp.sub(sub, text)
        text = " " + text + " "
        for regexp, sub in self.ENDING_QUOTES:
            text = regexp.sub(sub, text)
        for regexp in self.CONTRACTIONS2:
            text = regexp.sub(r" \1 \2 ", text)
        for regexp in self.CONTRACTIONS3:
            text = regexp.sub(r" \1 \2 ", text)
        return text.split()


class _ImprovedTokenizer(TreebankWordTokenizer):
    STARTING_QUOTES = [
        (re.compile("([«“‘„]|[`]+)"), r" \1 "),
        (re.compile(r'^"'), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
        (re.compile(r"(?i)(\')(?!re|ve|ll|m|t|s|d|n)(\w)\b"), r"\1 \2"),
    ]
    PUNCTUATION = [
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.{2,}"), r" \g<0> "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\']*)\s*$'), r"\1 \2\3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
        (re.compile(r"[*]"), r" \g<0> "),
        (re.compile("([‒–—―])"), r" \1 "),
    ]
    ENDING_QUOTES = [
        (re.compile("([»”’])"), r" \1 "),
        (re.compile(r"''"), " '' "),
        (re.compile(r'"'), " '' "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]


_improved = _ImprovedTokenizer()


# ---------------------------------------------------------------- Punkt
_ORTHO_BEG_UC, _ORTHO_MID_UC, _ORTHO_UNK_UC = 2, 4, 8
_ORTHO_UC = 14
_ORTHO_BEG_LC, _ORTHO_MID_LC, _ORTHO_UNK_LC = 16, 32, 64
_ORTHO_LC = 112

_NW = r"[?!)\";}\]\*:@\'\({\[]"
_MULTI = r"(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"
_WORD_START = r"[^\(\"\`{\[:;&\#\*@\)}\]\-,]"
_word_re = re.compile(
    r"(?:" + _MULTI + r"|(?=" + _WORD_START + r")\S+?(?=\s|$|" + _NW + "|" + _MULTI
    + r"|,(?=$|\s|" + _NW + "|" + _MULTI + r"))|\S)", re.UNICODE)
_period_re = re.compile(
    r"\S*[.?!](?=(?P<after_tok>" + _NW + r"|\s+(?P<next_tok>\S+)))", re.UNICODE)
_realign_re = re.compile(r"[\"\')\]}]+?(?:\s+|(?=--)|$)")
_RE_NUMERIC = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_RE_ELLIPSIS = re.compile(r"\.\.+$")
_RE_INITIAL = re.compile(r"[^\W\d]\.$")
_RE_ALPHA = re.compile(r"[^\W\d]+$")


class _Tok:
    __slots__ = ("tok", "type", "period_final", "abbr", "ellipsis", "sentbreak")

    def __init__(self, tok):
        self.tok = tok
        self.type = _RE_NUMERIC.sub("##number##", tok.lower())
        self.period_final = tok.endswith(".")
        self.abbr = self.ellipsis = self.sentbreak = False

    @property
    def type_no_period(self):
        if len(self.type) > 1 and self.type.endswith("."):
            return self.type[:-1]
        return self.type

    @property
    def type_no_sentperiod(self):
        return self.type_no_period if self.sentbreak else self.type

    @property
    def first_upper(self):
        return self.tok[0].isupper()

    @property
    def first_lower(self):
        return self.tok[0].islower()

    @property
    def is_ellipsis(self):
        return bool(_RE_ELLIPSIS.match(self.tok))

    @property
    def is_initial(self):
        return bool(_RE_INITIAL.match(self.tok))


class PunktSentenceTokenizer:
    def __init__(self, abbrev_types=(), collocations=(), sent_starters=(), ortho_context=None):
        self.abbrev_types = set(abbrev_types)
        self.collocations = set(collocations)
        self.sent_starters = set(sent_starters)
        self.ortho_context = ortho_context or {}

    @classmethod
    def from_dir(cls, d):
        def lines(name):
            p = os.path.join(d, name)
            if not os.path.isfile(p):
                raise LookupError("Punkt model file missing: %s" % p)
            return data.read_lines(p)
        abbrev = [l for l in lines("abbrev_types.txt") if l != ""]
        starters = [l for l in lines("sent_starters.txt") if l != ""]
        colls = []
        for l in lines("collocations.tab"):
            if l == "":
                continue
            parts = l.split("\t")
            if len(parts) >= 2:
                colls.append((parts[0], parts[1]))
        ortho = {}
        for l in lines("ortho_context.tab"):
            if l == "":
                continue
            parts = l.split("\t")
            if len(parts) >= 2:
                ortho[parts[0]] = int(parts[1])
        return cls(abbrev, colls, starters, ortho)

    # -- annotation
    def _first_pass(self, tok):
        t = tok.tok
        if t in (".", "?", "!"):
            tok.sentbreak = True
        elif tok.is_ellipsis:
            tok.ellipsis = True
        elif tok.period_final and not t.endswith(".."):
            if (t[:-1].lower() in self.abbrev_types
                    or t[:-1].lower().split("-")[-1] in self.abbrev_types):
                tok.abbr = True
            else:
                tok.sentbreak = True

    def _ortho(self, tok):
        if tok.tok in (";", ":", ",", ".", "!", "?"):
            return False
        ctx = self.ortho_context.get(tok.type_no_sentperiod, 0)
        if tok.first_upper and (ctx & _ORTHO_LC) and not (ctx & _ORTHO_MID_UC):
            return True
        if tok.first_lower and ((ctx & _ORTHO_UC) or not (ctx & _ORTHO_BEG_LC)):
            return False
        return "unknown"

    def _second_pass(self, t1, t2):
        if t2 is None or not t1.period_final:
            return
        typ = t1.type_no_period
        next_typ = t2.type_no_sentperiod
        initial = t1.is_initial
        if (typ, next_typ) in self.collocations:
            t1.sentbreak = False
            t1.abbr = True
            return
        if (t1.abbr or t1.ellipsis) and not initial:
            if self._ortho(t2) is True:
                t1.sentbreak = True
                return
            if t2.first_upper and next_typ in self.sent_starters:
                t1.sentbreak = True
                return
        if initial or typ == "##number##":
            r = self._ortho(t2)
            if r is False:
                t1.sentbreak = False
                t1.abbr = True
                return
            if (r == "unknown" and initial and t2.first_upper
                    and not (self.ortho_context.get(next_typ, 0) & _ORTHO_LC)):
                t1.sentbreak = False
                t1.abbr = True
                return

    def _contains_sentbreak(self, text):
        toks = []
        for line in text.split("\n"):
            if line.strip():
                for w in _word_re.findall(line):
                    toks.append(_Tok(w))
        for t in toks:
            self._first_pass(t)
        for i, t in enumerate(toks):
            self._second_pass(t, toks[i + 1] if i + 1 < len(toks) else None)
        found = False
        for t in toks:
            if found:
                return True
            if t.sentbreak:
                found = True
        return False

    def _contexts(self, text):
        prev_slice = (0, 0)
        prev_match = None
        for m in _period_re.finditer(text):
            before = text[prev_slice[1]:m.start()]
            idx = None
            for k in range(len(before) - 1, -1, -1):
                if before[k].isspace():
                    idx = k
                    break
            if idx:
                idx += prev_slice[1] + 1
            else:
                idx = prev_slice[0]
            cur = (idx, m.start())
            if prev_match and prev_slice[1] <= cur[0]:
                yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + prev_match.group("after_tok")
            prev_match = m
            prev_slice = cur
        if prev_match:
            yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + prev_match.group("after_tok")

    def _slices(self, text):
        last = 0
        out = []
        for m, ctx in self._contexts(text):
            if self._contains_sentbreak(ctx):
                out.append((last, m.end()))
                if m.group("next_tok"):
                    last = m.start("next_tok")
                else:
                    last = m.end()
        out.append((last, len(text.rstrip())))
        return out

    def _realign(self, text, slices):
        realign = 0
        res = []
        for k, s1 in enumerate(slices):
            s1 = (s1[0] + realign, s1[1])
            if k + 1 >= len(slices):
                if text[s1[0]:s1[1]]:
                    res.append(s1)
                continue
            s2 = slices[k + 1]
            m = _realign_re.match(text[s2[0]:s2[1]])
            if m:
                res.append((s1[0], s2[0] + len(m.group(0).rstrip())))
                realign = m.end()
            else:
                realign = 0
                if text[s1[0]:s1[1]]:
                    res.append(s1)
        return res

    def span_tokenize(self, text):
        _check(text)
        return self._realign(text, self._slices(text))

    def tokenize(self, text):
        return [text[a:b] for a, b in self.span_tokenize(text)]


_punkt_cache = {}


def _load_punkt(language):
    if not isinstance(language, str) or not language:
        raise ValueError("invalid language %r" % (language,))
    d = data.find("tokenizers/punkt_tab/" + language, "dir")
    key = os.path.abspath(d)
    if key not in _punkt_cache:
        _punkt_cache[key] = PunktSentenceTokenizer.from_dir(d)
    return _punkt_cache[key]


def sent_tokenize(text, language="english"):
    _check(text)
    return _load_punkt(language).tokenize(text)


def word_tokenize(text, language="english", preserve_line=False):
    _check(text)
    sents = [text] if preserve_line else sent_tokenize(text, language)
    return [t for s in sents for t in _improved.tokenize(s)]


# ---------------------------------------------------------------- Tweets
_EMOTICONS = r"""(?:[<>]?[:;=8][\-o\*\']?[\)\]\(\[dDpP/\:\}\{@\|\\]|[\)\]\(\[dDpP/\:\}\{@\|\\][\-o\*\']?[:;=8][<>]?|<3)"""
_URLS = r"""(?:https?://|www\.)[^\s<>"]*[^\s<>".,;:!?)\]}'"]"""
_PHONE = r"""(?:(?:\+?[01][ *\-.\)]*)?(?:[\(]?\d{3}[ *\-.\)]*)?\d{3}[ *\-.\)]*\d{4})"""
_TWEET_RE = re.compile("|".join([
    _PHONE, _URLS, _EMOTICONS, r"<[^>\s]+>", r"[\-]+>|<[\-]+",
    r"(?:@[\w_]+)", r"(?:\#+[\w_]+[\w\'_\-]*[\w_]+)",
    r"[\w.+-]+@[\w-]+\.(?:[\w-]\.?)+[\w-]",
    r"(?:[^\W\d_](?:[^\W\d_]|['\-_])+[^\W\d_])",
    r"(?:[+\-]?\d+[,/.:-]\d+[+\-]?)", r"(?:[\w_]+)", r"(?:\.(?:\s*\.){1,})", r"(?:\S)"]),
    re.VERBOSE | re.I | re.UNICODE)
_EMOT_RE = re.compile("^" + _EMOTICONS + "$")
_HANG_RE = re.compile(r"([^a-zA-Z0-9])\1{3,}")
_LEN_RE = re.compile(r"(.)\1{2,}", re.DOTALL)
_HANDLE_RE = re.compile(
    r"(?<![A-Za-z0-9_!@#\$%&*])@(([A-Za-z0-9_]){15}(?!@)|([A-Za-z0-9_]){1,14}(?![A-Za-z0-9_]*@))")


class TweetTokenizer:
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self.preserve_case = preserve_case
        self.reduce_len = reduce_len
        self.strip_handles = strip_handles

    def tokenize(self, text):
        _check(text)
        if self.strip_handles:
            text = _HANDLE_RE.sub(" ", text)
        if self.reduce_len:
            text = _LEN_RE.sub(r"\1\1\1", text)
        words = [m.group(0) for m in _TWEET_RE.finditer(text)]
        if not self.preserve_case:
            words = [w if _EMOT_RE.match(w) else w.lower() for w in words]
        return words
