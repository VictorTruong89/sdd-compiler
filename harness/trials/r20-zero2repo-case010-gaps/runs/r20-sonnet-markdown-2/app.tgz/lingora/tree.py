"""Constituent trees."""
import re


class Tree(list):
    def __init__(self, label, children):
        if children is None or isinstance(children, (str, bytes)):
            raise TypeError("Tree children must be a list of children, not %r" % (children,))
        list.__init__(self, children)
        self._label = label

    def label(self):
        return self._label

    def set_label(self, label):
        self._label = label

    def __eq__(self, other):
        return (isinstance(other, Tree) and self._label == other._label
                and list.__eq__(self, other))

    def __ne__(self, other):
        return not self == other

    __hash__ = None

    def __lt__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return (str(self._label), list(self)) < (str(other._label), list(other))

    def leaves(self):
        out = []
        for c in self:
            if isinstance(c, Tree):
                out.extend(c.leaves())
            else:
                out.append(c)
        return out

    def pos(self):
        out = []
        for c in self:
            if isinstance(c, Tree):
                out.extend(c.pos())
            elif isinstance(c, tuple):
                out.append(c)
        return out

    def subtrees(self, filter=None):
        if filter is None or filter(self):
            yield self
        for c in self:
            if isinstance(c, Tree):
                yield from c.subtrees(filter)

    def height(self):
        h = 0
        for c in self:
            h = max(h, c.height() if isinstance(c, Tree) else 1)
        return h + 1

    def copy(self, deep=False):
        if not deep:
            return type(self)(self._label, self)
        return type(self)(self._label, [c.copy(True) if isinstance(c, Tree) else c for c in self])

    def productions(self):
        from .grammar import Production, Nonterminal
        rhs = [Nonterminal(str(c._label)) if isinstance(c, Tree) else c for c in self]
        out = [Production(Nonterminal(str(self._label)), rhs)]
        for c in self:
            if isinstance(c, Tree):
                out.extend(c.productions())
        return out

    @classmethod
    def fromstring(cls, s):
        toks = re.findall(r"\(|\)|[^\s()]+", s)
        if not toks:
            raise ValueError("empty tree text")
        pos = 0

        def node():
            nonlocal pos
            if toks[pos] != "(":
                raise ValueError("expected '(' in tree text")
            pos += 1
            if pos >= len(toks):
                raise ValueError("unbalanced tree text")
            if toks[pos] in "()":
                label = ""
            else:
                label = toks[pos]
                pos += 1
            kids = []
            while True:
                if pos >= len(toks):
                    raise ValueError("unbalanced tree text")
                t = toks[pos]
                if t == ")":
                    pos += 1
                    return cls(label, kids)
                if t == "(":
                    kids.append(node())
                else:
                    kids.append(t)
                    pos += 1

        t = node()
        if pos != len(toks):
            raise ValueError("unexpected text after tree")
        if t._label == "" and len(t) == 1 and isinstance(t[0], Tree):
            t = t[0]
        return t

    @staticmethod
    def _leafstr(c):
        if isinstance(c, tuple):
            return "/".join(str(x) for x in c)
        return str(c)

    def _flat(self):
        parts = [c._flat() if isinstance(c, Tree) else self._leafstr(c) for c in self]
        return "(%s %s)" % (self._label, " ".join(parts))

    def pformat(self, margin=70, indent=0):
        s = self._flat()
        if len(s) + indent < margin:
            return s
        s = "(%s" % (self._label,)
        for c in self:
            if isinstance(c, Tree):
                s += "\n" + " " * (indent + 2) + c.pformat(margin, indent + 2)
            else:
                s += "\n" + " " * (indent + 2) + self._leafstr(c)
        return s + ")"

    def pprint(self, **kw):
        print(self.pformat(**kw))

    def __str__(self):
        return self.pformat()

    def __repr__(self):
        return "Tree(%r, %s)" % (self._label, list.__repr__(self))
