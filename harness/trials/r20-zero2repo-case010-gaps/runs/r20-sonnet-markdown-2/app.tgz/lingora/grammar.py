"""Context-free grammars."""
import re


class Nonterminal:
    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and self._symbol == other._symbol

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return hash(("NT", self._symbol))

    def __str__(self):
        return str(self._symbol)

    def __repr__(self):
        return "%s" % (self._symbol,)


class Production:
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def is_lexical(self):
        return all(not isinstance(s, Nonterminal) for s in self._rhs)

    def __eq__(self, other):
        return isinstance(other, Production) and self._lhs == other._lhs and self._rhs == other._rhs

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        return "%s -> %s" % (self._lhs, " ".join(
            repr(s) if isinstance(s, str) else str(s) for s in self._rhs))

    __repr__ = __str__


_TOKEN = re.compile(r"""\s*(?:("[^"]*")|('[^']*')|(\|)|([^\s|'"]+))""")


def _split_rhs(text, line):
    toks = []
    pos = 0
    text = text.rstrip()
    while pos < len(text):
        m = _TOKEN.match(text, pos)
        if not m:
            raise ValueError("Unable to parse production: %r" % line)
        pos = m.end()
        if m.group(1) is not None:
            toks.append(("t", m.group(1)[1:-1]))
        elif m.group(2) is not None:
            toks.append(("t", m.group(2)[1:-1]))
        elif m.group(3) is not None:
            toks.append(("|", "|"))
        else:
            toks.append(("n", m.group(4)))
    return toks


class CFG:
    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)
        self._by_lhs = {}
        for p in self._productions:
            self._by_lhs.setdefault(p.lhs(), []).append(p)

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            raise TypeError("grammar text must be a str")
        prods = []
        start = None
        lhs = None
        for raw in input.splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("|"):
                if lhs is None:
                    raise ValueError("Unable to parse line: %r" % raw)
                rest = line[1:]
                cur_lhs = lhs
                body = "|" + rest
            else:
                m = re.match(r"^(\S+?)\s*(?:->|=>|→)(.*)$", line)
                if not m:
                    raise ValueError("Unable to parse line: %r" % raw)
                cur_lhs = Nonterminal(m.group(1))
                lhs = cur_lhs
                if start is None:
                    start = cur_lhs
                body = m.group(2)
            toks = _split_rhs(body, raw)
            alts = [[]]
            for kind, val in toks:
                if kind == "|":
                    alts.append([])
                elif kind == "t":
                    alts[-1].append(val)
                else:
                    alts[-1].append(Nonterminal(val))
            if line.startswith("|") and alts and alts[0] == [] and len(alts) > 1:
                alts = alts[1:]
            for a in alts:
                prods.append(Production(cur_lhs, a))
        if start is None:
            raise ValueError("No productions found in grammar text")
        return cls(start, prods)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        if isinstance(lhs, str):
            lhs = Nonterminal(lhs)
        return list(self._by_lhs.get(lhs, []))

    def terminals(self):
        out = set()
        for p in self._productions:
            for s in p.rhs():
                if isinstance(s, str):
                    out.add(s)
        return out

    def check_coverage(self, tokens):
        terms = self.terminals()
        missing = [t for t in tokens if t not in terms]
        if missing:
            raise ValueError("Grammar does not cover some of the input words: %r."
                             % ", ".join(repr(m) for m in missing))

    def __str__(self):
        return "Grammar with %d productions (start state = %s)\n" % (
            len(self._productions), self._start) + "\n".join(
            "    %s" % p for p in self._productions)

    __repr__ = __str__
