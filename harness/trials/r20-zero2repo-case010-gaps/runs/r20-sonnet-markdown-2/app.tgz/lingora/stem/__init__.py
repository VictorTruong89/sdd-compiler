"""Stemmers."""
import re

from .porter import PorterStemmer
from .lancaster import LancasterStemmer
from .snowball import SnowballStemmer
from .arabic import ARLSTem, ARLSTem2
from .wordnet import WordNetLemmatizer

__all__ = ["ARLSTem", "ARLSTem2", "LancasterStemmer", "PorterStemmer", "RegexpStemmer",
           "SnowballStemmer", "WordNetLemmatizer"]


class RegexpStemmer:
    def __init__(self, regexp, min=0):
        if not hasattr(regexp, "pattern"):
            regexp = re.compile(regexp)
        self._regexp = regexp
        self._min = min

    def stem(self, word):
        if len(word) < self._min:
            return word
        return self._regexp.sub("", word)

    def __repr__(self):
        return "<RegexpStemmer: %r>" % self._regexp.pattern
