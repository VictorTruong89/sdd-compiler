"""WordNet lemmatizer (reads corpora/wordnet)."""
import os

from .. import data

_SUBS = {
    "n": [("s", ""), ("ses", "s"), ("ves", "f"), ("xes", "x"), ("zes", "z"),
          ("ches", "ch"), ("shes", "sh"), ("men", "man"), ("ies", "y")],
    "v": [("s", ""), ("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"), ("ed", ""),
          ("ing", "e"), ("ing", "")],
    "a": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
    "r": [],
}
_FILES = {"n": "noun", "v": "verb", "a": "adj", "r": "adv"}


class WordNetLemmatizer:
    def __init__(self):
        self._dir = data.find("corpora/wordnet", "dir")
        self._lemmas = {}
        self._exc = {}

    def _load(self, pos):
        if pos in self._lemmas:
            return
        names = set()
        p = os.path.join(self._dir, "index." + _FILES[pos])
        if os.path.isfile(p):
            for l in data.read_lines(p):
                if l and not l.startswith(" "):
                    names.add(l.split(" ")[0])
        exc = {}
        p = os.path.join(self._dir, _FILES[pos] + ".exc")
        if os.path.isfile(p):
            for l in data.read_lines(p):
                parts = l.split()
                if len(parts) >= 2:
                    exc.setdefault(parts[0], []).extend(parts[1:])
        self._lemmas[pos] = names
        self._exc[pos] = exc

    def _morphy(self, form, pos):
        self._load(pos)
        names, exc, subs = self._lemmas[pos], self._exc[pos], _SUBS[pos]

        def flt(forms):
            res, seen = [], set()
            for f in forms:
                if f in names and f not in seen:
                    res.append(f)
                    seen.add(f)
            return res

        def apply(forms):
            return [f[:-len(o)] + n for f in forms for o, n in subs if f.endswith(o)]

        if form in exc:
            return flt([form] + exc[form])
        forms = apply([form])
        res = flt([form] + forms)
        if res:
            return res
        while forms:
            forms = apply(forms)
            res = flt(forms)
            if res:
                return res
        return []

    def lemmatize(self, word, pos="n"):
        if pos == "s":
            pos = "a"
        if pos not in _FILES:
            raise ValueError("unknown part of speech %r" % (pos,))
        lemmas = self._morphy(word, pos)
        return min(lemmas, key=len) if lemmas else word

    def __repr__(self):
        return "<WordNetLemmatizer>"
