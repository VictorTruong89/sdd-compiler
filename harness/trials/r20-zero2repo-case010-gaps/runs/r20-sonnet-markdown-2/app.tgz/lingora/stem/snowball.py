"""Snowball stemmer front end."""
import importlib

from .porter import PorterStemmer as _Porter
from .snowball_base import LanguageStemmer

LANGUAGES = ("arabic", "danish", "dutch", "english", "finnish", "french", "german",
             "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
             "russian", "spanish", "swedish")


class _PorterLang(LanguageStemmer):
    language = "porter"

    def __init__(self, ignore_stopwords=False):
        LanguageStemmer.__init__(self, ignore_stopwords)
        self._p = _Porter()

    def stem(self, word):
        if word in self.stopwords or word.lower() in self.stopwords:
            return word.lower() if word.lower() in self.stopwords else word
        return self._p.stem(word)


class SnowballStemmer:
    languages = LANGUAGES

    def __init__(self, language, ignore_stopwords=False):
        if not isinstance(language, str) or language not in LANGUAGES:
            raise ValueError("The language %r is not supported." % (language,))
        if language == "porter":
            self.stemmer = _PorterLang(ignore_stopwords)
        else:
            if language == "english":
                from .snowball_english import EnglishStemmer as cls
            else:
                from . import snowball_other as mod
                cls = getattr(mod, language.capitalize() + "Stemmer")
            self.stemmer = cls(ignore_stopwords)
        self.stem = self.stemmer.stem

    def stem(self, word):  # replaced per-instance in __init__
        return self.stemmer.stem(word)
