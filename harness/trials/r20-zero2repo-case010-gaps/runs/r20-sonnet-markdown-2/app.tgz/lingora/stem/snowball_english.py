"""Porter2 (Snowball english) stemmer."""
from .snowball_base import LanguageStemmer, r1r2_standard

V = "aeiouy"
_SPECIAL = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli",
    "singly": "singl", "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas",
    "cosmos": "cosmos", "bias": "bias", "andes": "andes",
}
_EXC1A = ("inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed")
_STEP2 = {
    "tional": "tion", "enci": "ence", "anci": "ance", "abli": "able", "entli": "ent",
    "izer": "ize", "ization": "ize", "ational": "ate", "ation": "ate", "ator": "ate",
    "alism": "al", "aliti": "al", "alli": "al", "fulness": "ful", "ousli": "ous",
    "ousness": "ous", "iveness": "ive", "iviti": "ive", "biliti": "ble", "bli": "ble",
    "fulli": "ful", "lessli": "less", "ogi": "og", "li": "",
}
_STEP3 = {
    "tional": "tion", "ational": "ate", "alize": "al", "icate": "ic", "iciti": "ic",
    "ical": "ic", "ful": "", "ness": "", "ative": "",
}
_STEP4 = ("al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent",
          "ism", "ate", "iti", "ous", "ive", "ize", "ion")


def _short_syllable(w):
    n = len(w)
    if n == 2:
        return w[0] in V and w[1] not in V
    if n >= 3:
        return w[-2] in V and w[-1] not in V and w[-1] not in "wxY" and w[-3] not in V
    return False


def _longest(word, keys):
    best = None
    for s in keys:
        if word.endswith(s) and (best is None or len(s) > len(best)):
            best = s
    return best


class EnglishStemmer(LanguageStemmer):
    language = "english"

    def _stem(self, word):
        if len(word) <= 2:
            return word
        if word in _SPECIAL:
            return _SPECIAL[word]
        if word.startswith("y"):
            word = "Y" + word[1:]
        for i in range(1, len(word)):
            if word[i - 1] in V and word[i] == "y":
                word = word[:i] + "Y" + word[i + 1:]
        n = len(word)
        if word.startswith(("gener", "arsen")):
            p1 = 5
        elif word.startswith("commun"):
            p1 = 6
        else:
            p1, _ = r1r2_standard(word, V)
        p2 = n
        for i in range(p1 + 1, n):
            if word[i] not in V and word[i - 1] in V:
                p2 = i + 1
                break

        def clamp():
            nonlocal p1, p2
            p1 = min(p1, len(word))
            p2 = min(p2, len(word))

        # step 0
        for suf in ("'s'", "'s", "'"):
            if word.endswith(suf):
                word = word[:-len(suf)]
                break
        clamp()
        # step 1a
        for suf in ("sses", "ied", "ies", "us", "ss", "s"):
            if word.endswith(suf):
                if suf == "sses":
                    word = word[:-2]
                elif suf in ("ied", "ies"):
                    if len(word) - len(suf) > 1:
                        word = word[:-2]
                    else:
                        word = word[:-1]
                elif suf == "s":
                    if any(c in V for c in word[:-2]):
                        word = word[:-1]
                break
        clamp()
        if word in _EXC1A:
            return word
        # step 1b
        for suf in ("eedly", "ingly", "edly", "eed", "ing", "ed"):
            if word.endswith(suf):
                if suf in ("eed", "eedly"):
                    if len(word) - len(suf) >= p1:
                        word = word[:-len(suf)] + "ee"
                else:
                    if any(c in V for c in word[:-len(suf)]):
                        word = word[:-len(suf)]
                        clamp()
                        if word.endswith(("at", "bl", "iz")):
                            word += "e"
                        elif word.endswith(("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")):
                            word = word[:-1]
                        elif p1 >= len(word) and _short_syllable(word):
                            word += "e"
                break
        clamp()
        # step 1c
        if len(word) > 2 and word[-1] in "yY" and word[-2] not in V:
            word = word[:-1] + "i"
        # step 2
        suf = _longest(word, _STEP2)
        if suf and len(word) - len(suf) >= p1:
            rep = _STEP2[suf]
            if suf == "ogi":
                if word[:-3].endswith("l"):
                    word = word[:-3] + "og"
            elif suf == "li":
                if len(word) > 2 and word[-3] in "cdeghkmnrt":
                    word = word[:-2]
            else:
                word = word[:-len(suf)] + rep
        clamp()
        # step 3
        suf = _longest(word, _STEP3)
        if suf:
            start = p2 if suf == "ative" else p1
            if len(word) - len(suf) >= start:
                word = word[:-len(suf)] + _STEP3[suf]
        clamp()
        # step 4
        suf = _longest(word, _STEP4)
        if suf and len(word) - len(suf) >= p2:
            if suf == "ion":
                if word[:-3].endswith(("s", "t")):
                    word = word[:-3]
            else:
                word = word[:-len(suf)]
        clamp()
        # step 5
        if word.endswith("e"):
            pos = len(word) - 1
            if pos >= p2 or (pos >= p1 and not _short_syllable(word[:-1])):
                word = word[:-1]
        elif word.endswith("l"):
            if len(word) - 1 >= p2 and word[:-1].endswith("l"):
                word = word[:-1]
        return word.replace("Y", "y")
