"""Shared helpers for Snowball stemmers."""
from .. import data


class LanguageStemmer:
    language = None

    def __init__(self, ignore_stopwords=False):
        self.stopwords = set()
        if ignore_stopwords:
            f = data.find("corpora/stopwords/" + self.language, "file")
            self.stopwords = {l.strip() for l in data.read_lines(f) if l.strip()}

    def stem(self, word):
        word = word.lower()
        if word in self.stopwords:
            return word
        return self._stem(word)

    def _stem(self, word):
        raise NotImplementedError


def r1r2_standard(word, vowels):
    """Return (p1, p2) positions: start of R1 / R2 (len(word) if empty)."""
    n = len(word)
    p1 = n
    for i in range(1, n):
        if word[i] not in vowels and word[i - 1] in vowels:
            p1 = i + 1
            break
    p2 = n
    for i in range(p1 + 1, n):
        if word[i] not in vowels and word[i - 1] in vowels:
            p2 = i + 1
            break
    return p1, p2


def rv_standard(word, vowels):
    """Romance RV region start (len(word) if empty)."""
    n = len(word)
    if n < 2:
        return n
    if word[1] not in vowels:
        for i in range(2, n):
            if word[i] in vowels:
                return i + 1
    elif word[0] in vowels and word[1] in vowels:
        for i in range(2, n):
            if word[i] not in vowels:
                return i + 1
    else:
        return 3 if n >= 3 else n
    return n


def longest_suffix(word, suffixes, start=0):
    """Longest suffix from *suffixes* that ends *word* and lies at index >= start."""
    best = None
    for s in suffixes:
        if word.endswith(s) and len(word) - len(s) >= start:
            if best is None or len(s) > len(best):
                best = s
    return best


def longest_any(word, suffixes):
    """Longest matching suffix regardless of region (None if no match)."""
    best = None
    for s in suffixes:
        if word.endswith(s) and (best is None or len(s) > len(best)):
            best = s
    return best
