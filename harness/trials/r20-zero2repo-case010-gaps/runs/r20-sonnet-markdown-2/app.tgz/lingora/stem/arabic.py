"""Light Arabic stemmers (ARLSTem family)."""
import re

_DIAC = re.compile("[ً-ْـ]")
_PREFIXES = ["وال", "فبال", "كال", "بال",
             "لل", "ال", "و", "ف", "ب", "ك", "ل"]
_SUFFIXES = ["هما", "كما", "تما", "هم", "هن",
             "كم", "كن", "نا", "ها", "ات", "ون",
             "ين", "ان", "ية", "ة", "ه", "ي", "ك", "ت"]


class ARLSTem:
    def norm(self, word):
        word = _DIAC.sub("", word)
        return re.sub("[أإآ]", "ا", word)

    def stem(self, word):
        w = self.norm(word)
        if len(w) <= 3:
            return w
        for p in _PREFIXES:
            if w.startswith(p) and len(w) - len(p) >= 3:
                w = w[len(p):]
                break
        for s in _SUFFIXES:
            if w.endswith(s) and len(w) - len(s) >= 3:
                w = w[:-len(s)]
                break
        return w


class ARLSTem2(ARLSTem):
    pass
