"""Snowball stemmers for German, Dutch, Scandinavian languages, Spanish, Russian,
plus light fallbacks for the languages without a full implementation."""
import re

from .snowball_base import LanguageStemmer, r1r2_standard, rv_standard, longest_any


def _longest_in(word, suffixes, start):
    """Longest suffix of *word* that begins at index >= start, else None."""
    best = None
    for s in suffixes:
        if word.endswith(s) and len(word) - len(s) >= start:
            if best is None or len(s) > len(best):
                best = s
    return best


# ---------------------------------------------------------------- German
class GermanStemmer(LanguageStemmer):
    language = "german"
    V = "aeiouyäöü"
    S_END = "bdfghklmnrt"
    ST_END = "bdfghklmnt"

    def _stem(self, word):
        V = self.V
        word = word.replace("ß", "ss")
        chars = list(word)
        for i in range(1, len(word) - 1):
            if word[i - 1] in V and word[i + 1] in V:
                if word[i] == "u":
                    chars[i] = "U"
                elif word[i] == "y":
                    chars[i] = "Y"
        word = "".join(chars)
        p1, p2 = r1r2_standard(word, V)
        p1 = min(max(p1, 3), len(word))
        p2 = max(p2, p1)

        # step 1
        suf = longest_any(word, ("em", "ern", "er", "e", "en", "es", "s"))
        if suf and len(word) - len(suf) >= p1:
            if suf in ("em", "ern", "er"):
                word = word[:-len(suf)]
            elif suf in ("e", "en", "es"):
                word = word[:-len(suf)]
                if word.endswith("niss"):
                    word = word[:-1]
            elif suf == "s" and len(word) >= 2 and word[-2] in self.S_END:
                word = word[:-1]
        # step 2
        suf = longest_any(word, ("en", "er", "est", "st"))
        if suf and len(word) - len(suf) >= p1:
            if suf == "st":
                if len(word) >= 6 and word[-3] in self.ST_END:
                    word = word[:-2]
            else:
                word = word[:-len(suf)]
        # step 3
        suf = longest_any(word, ("end", "ung", "ig", "ik", "isch", "lich", "heit", "keit"))
        if suf and len(word) - len(suf) >= p2:
            if suf in ("end", "ung"):
                word = word[:-len(suf)]
                if word.endswith("ig") and len(word) - 2 >= p2 and not word[:-2].endswith("e"):
                    word = word[:-2]
            elif suf in ("ig", "ik", "isch"):
                if not word[:-len(suf)].endswith("e"):
                    word = word[:-len(suf)]
            elif suf in ("lich", "heit"):
                word = word[:-len(suf)]
                for s2 in ("er", "en"):
                    if word.endswith(s2) and len(word) - 2 >= p1:
                        word = word[:-2]
                        break
            elif suf == "keit":
                word = word[:-4]
                for s2 in ("lich", "ig"):
                    if word.endswith(s2) and len(word) - len(s2) >= p2:
                        word = word[:-len(s2)]
                        break
        word = word.replace("U", "u").replace("Y", "y")
        return word.translate(str.maketrans("äöü", "aou"))


# ---------------------------------------------------------------- Dutch
class DutchStemmer(LanguageStemmer):
    language = "dutch"
    V = "aeiouyè"

    @staticmethod
    def _undouble(w):
        if w.endswith(("kk", "dd", "tt")):
            return w[:-1]
        return w

    def _stem(self, word):
        V = self.V
        word = word.translate(str.maketrans("äëïöüáéíóú", "aeiouaeiou"))
        chars = list(word)
        if chars and chars[0] == "y":
            chars[0] = "Y"
        for i in range(1, len(chars)):
            if chars[i - 1] in V and chars[i] == "y":
                chars[i] = "Y"
        for i in range(1, len(chars) - 1):
            if chars[i - 1] in V and chars[i] == "i" and chars[i + 1] in V:
                chars[i] = "I"
        word = "".join(chars)
        p1, p2 = r1r2_standard(word, V)
        p1 = min(max(p1, 3), len(word))
        p2 = max(p2, p1)

        def en_ok(w, suf):
            return (len(w) - len(suf) >= p1 and len(w) > len(suf)
                    and w[-len(suf) - 1] not in V and w[-len(suf) - 3:-len(suf)] != "gem")

        # step 1
        suf = longest_any(word, ("heden", "en", "ene", "s", "se"))
        if suf and len(word) - len(suf) >= p1:
            if suf == "heden":
                word = word[:-5] + "heid"
            elif suf in ("en", "ene"):
                if en_ok(word, suf):
                    word = self._undouble(word[:-len(suf)])
            else:
                if len(word) > len(suf) and word[-len(suf) - 1] not in V and word[-len(suf) - 1] != "j":
                    word = word[:-len(suf)]
        # step 2
        e_found = False
        if word.endswith("e") and len(word) - 1 >= p1 and len(word) > 1 and word[-2] not in V:
            word = self._undouble(word[:-1])
            e_found = True
        # step 3a
        if word.endswith("heid") and len(word) - 4 >= p2 and not word[:-4].endswith("c"):
            word = word[:-4]
            if word.endswith("en") and en_ok(word, "en"):
                word = self._undouble(word[:-2])
        # step 3b
        suf = longest_any(word, ("end", "ing", "ig", "lijk", "baar", "bar"))
        if suf and len(word) - len(suf) >= p2:
            if suf in ("end", "ing"):
                word = word[:-3]
                if word.endswith("ig") and len(word) - 2 >= p2 and not word[:-2].endswith("e"):
                    word = word[:-2]
                else:
                    word = self._undouble(word)
            elif suf == "ig":
                if not word[:-2].endswith("e"):
                    word = word[:-2]
            elif suf == "lijk":
                word = word[:-4]
                if word.endswith("e") and len(word) - 1 >= p1 and len(word) > 1 and word[-2] not in V:
                    word = self._undouble(word[:-1])
            elif suf == "baar":
                word = word[:-4]
            elif suf == "bar" and e_found:
                word = word[:-3]
        # step 4
        if len(word) >= 4 and word[-1] not in V and word[-1] != "I":
            if word[-3:-1] in ("aa", "ee", "oo", "uu") and word[-4] not in V:
                word = word[:-3] + word[-2] + word[-1]
        return word.replace("I", "i").replace("Y", "y")


# ---------------------------------------------------------- Scandinavian
class _Scandinavian(LanguageStemmer):
    V = "aeiouyäåö"

    def _regions(self, word):
        p1, _ = r1r2_standard(word, self.V)
        return min(max(p1, 3), len(word))


class SwedishStemmer(_Scandinavian):
    language = "swedish"
    V = "aeiouyäåö"
    S_END = "bcdfghjklmnoprtvy"
    STEP1 = ("a", "arna", "erna", "heterna", "orna", "ad", "e", "ade", "ande", "arne", "are",
             "aste", "en", "anden", "aren", "heten", "ern", "ar", "er", "heter", "or", "as",
             "arnas", "ernas", "ornas", "es", "ades", "andes", "ens", "arens", "hetens",
             "erns", "at", "andet", "het", "ast")

    def _stem(self, word):
        p1 = self._regions(word)
        suf = _longest_in(word, self.STEP1 + ("s",), p1)
        if suf:
            if suf != "s":
                word = word[:-len(suf)]
            elif len(word) >= 2 and word[-2] in self.S_END:
                word = word[:-1]
        if any(word.endswith(s) and len(word) - 2 >= p1 for s in ("dd", "gd", "nn", "dt", "gt", "kt", "tt")):
            word = word[:-1]
        suf = _longest_in(word, ("lig", "ig", "els", "löst", "fullt"), p1)
        if suf:
            if suf == "löst":
                word = word[:-1]
            elif suf == "fullt":
                word = word[:-1]
            else:
                word = word[:-len(suf)]
        return word


class NorwegianStemmer(_Scandinavian):
    language = "norwegian"
    V = "aeiouyæåø"
    S_END = "bcdfghjlmnoprtvyz"
    STEP1 = ("a", "e", "ede", "ande", "ende", "ane", "ene", "hetene", "en", "heten", "ar",
             "er", "heter", "as", "es", "edes", "endes", "enes", "hetenes", "ens", "hetens",
             "ers", "ets", "et", "het", "ast")

    def _stem(self, word):
        p1 = self._regions(word)
        suf = _longest_in(word, self.STEP1 + ("s", "erte", "ert"), p1)
        if suf:
            if suf in ("erte", "ert"):
                word = word[:-len(suf)] + "er"
            elif suf == "s":
                if len(word) >= 2 and (word[-2] in self.S_END
                                       or (word[-2] == "k" and len(word) >= 3 and word[-3] not in self.V)):
                    word = word[:-1]
            else:
                word = word[:-len(suf)]
        if any(word.endswith(s) and len(word) - 2 >= p1 for s in ("dt", "vt")):
            word = word[:-1]
        suf = _longest_in(word, ("leg", "eleg", "ig", "eig", "lig", "elig", "els", "lov",
                                 "elov", "slov", "hetslov"), p1)
        if suf:
            word = word[:-len(suf)]
        return word


class DanishStemmer(_Scandinavian):
    language = "danish"
    V = "aeiouyæåø"
    S_END = "abcdfghjklmnoprtvyzå"
    STEP1 = ("hed", "ethed", "ered", "e", "erede", "ende", "erende", "ene", "erne", "ere",
             "en", "heden", "eren", "er", "heder", "erer", "heds", "es", "endes", "erendes",
             "enes", "ernes", "eres", "ens", "hedens", "erens", "ers", "ets", "erets", "et",
             "eret")

    def _pair(self, word, p1):
        if any(word.endswith(s) and len(word) - 2 >= p1 for s in ("gd", "dt", "gt", "kt")):
            return word[:-1]
        return word

    def _stem(self, word):
        p1 = self._regions(word)
        suf = _longest_in(word, self.STEP1 + ("s",), p1)
        if suf:
            if suf == "s":
                if len(word) >= 2 and word[-2] in self.S_END:
                    word = word[:-1]
            else:
                word = word[:-len(suf)]
        word = self._pair(word, p1)
        if word.endswith("igst") and len(word) - 4 >= p1:
            word = word[:-2]
        suf = _longest_in(word, ("ig", "lig", "elig", "els", "løst"), p1)
        if suf:
            if suf == "løst":
                word = word[:-1]
            else:
                word = word[:-len(suf)]
                word = self._pair(word, p1)
        if len(word) - 1 >= p1 and len(word) >= 2 and word[-1] == word[-2] and word[-1] not in self.V:
            word = word[:-1]
        return word


# ---------------------------------------------------------------- Spanish
class SpanishStemmer(LanguageStemmer):
    language = "spanish"
    V = "aeiouáéíóúü"

    def _stem(self, word):
        V = self.V
        p1, p2 = r1r2_standard(word, V)
        rv = rv_standard(word, V)
        orig = word

        # step 0
        pron = longest_any(word, ("me", "se", "sela", "selo", "selas", "selos", "la", "le",
                                  "lo", "las", "les", "los", "nos"))
        if pron and len(word) - len(pron) >= rv:
            base = word[:-len(pron)]
            for s in ("iéndo", "ándo", "ár", "ér", "ír"):
                if base.endswith(s) and len(base) - len(s) >= rv:
                    word = base.replace("á", "a").replace("é", "e").replace("í", "i")
                    break
            else:
                for s in ("ando", "iendo", "ar", "er", "ir"):
                    if base.endswith(s) and len(base) - len(s) >= rv:
                        word = base
                        break
                else:
                    if base.endswith("uyendo") and len(base) - 5 >= rv:
                        word = base
        # step 1
        changed = False
        word_before = word

        def in_(w, s, p):
            return w.endswith(s) and len(w) - len(s) >= p
        groups = [
            (("anza", "anzas", "ico", "ica", "icos", "icas", "ismo", "ismos", "able", "ables",
              "ible", "ibles", "ista", "istas", "oso", "osa", "osos", "osas", "amiento",
              "amientos", "imiento", "imientos"), "d2"),
            (("adora", "ador", "ación", "adoras", "adores", "aciones", "ante", "antes",
              "ancia", "ancias"), "dic"),
            (("logía", "logías"), "log"),
            (("ución", "uciones"), "u"),
            (("encia", "encias"), "ente"),
            (("amente",), "amente"),
            (("mente",), "mente"),
            (("idad", "idades"), "idad"),
            (("iva", "ivo", "ivos", "ivas"), "iv"),
        ]
        allsufs = [(s, kind) for ss, kind in groups for s in ss]
        best = None
        for s, kind in allsufs:
            if word.endswith(s) and (best is None or len(s) > len(best[0])):
                best = (s, kind)
        if best:
            s, kind = best
            if kind == "d2" and in_(word, s, p2):
                word = word[:-len(s)]
                changed = True
            elif kind == "dic" and in_(word, s, p2):
                word = word[:-len(s)]
                if in_(word, "ic", p2):
                    word = word[:-2]
                changed = True
            elif kind == "log" and in_(word, s, p2):
                word = word[:-len(s)] + "log"
                changed = True
            elif kind == "u" and in_(word, s, p2):
                word = word[:-len(s)] + "u"
                changed = True
            elif kind == "ente" and in_(word, s, p2):
                word = word[:-len(s)] + "ente"
                changed = True
            elif kind == "amente" and in_(word, s, p1):
                word = word[:-6]
                changed = True
                if in_(word, "iv", p2):
                    word = word[:-2]
                    if in_(word, "at", p2):
                        word = word[:-2]
                else:
                    for x in ("os", "ic", "ad"):
                        if in_(word, x, p2):
                            word = word[:-2]
                            break
            elif kind == "mente" and in_(word, s, p2):
                word = word[:-5]
                changed = True
                for x in ("ante", "able", "ible"):
                    if in_(word, x, p2):
                        word = word[:-4]
                        break
            elif kind == "idad" and in_(word, s, p2):
                word = word[:-len(s)]
                changed = True
                for x in ("abil", "ic", "iv"):
                    if in_(word, x, p2):
                        word = word[:-len(x)]
                        break
            elif kind == "iv" and in_(word, s, p2):
                word = word[:-len(s)]
                changed = True
                if in_(word, "at", p2):
                    word = word[:-2]
        if not changed:
            # step 2a
            ys = ("ya", "ye", "yan", "yen", "yeron", "yendo", "yo", "yó", "yas", "yes", "yamos")
            s = longest_any(word, ys)
            done = False
            if s and len(word) - len(s) >= rv and word[:-len(s)].endswith("u"):
                word = word[:-len(s)]
                done = True
            if not done:
                # step 2b
                s = longest_any(word, _SPANISH_2B)
                if s and len(word) - len(s) >= rv:
                    if s in ("en", "es", "éis", "emos"):
                        word = word[:-len(s)]
                        if word.endswith("gu") and len(word) - 1 >= rv:
                            word = word[:-1]
                    else:
                        word = word[:-len(s)]
                    done = True
        if word == word_before and not changed:
            pass
        # step 3 (always)
        s = longest_any(word, ("os", "a", "o", "á", "í", "ó", "e", "é"))
        if s and len(word) - len(s) >= rv:
            word = word[:-len(s)]
            if s in ("e", "é") and word.endswith("gu") and len(word) - 1 >= rv:
                word = word[:-1]
        return word.translate(str.maketrans("áéíóú", "aeiou"))


_SPANISH_2B = (
    "en", "es", "éis", "emos",
    "arían", "arías", "arán", "arás", "aríais", "aría", "aréis", "aríamos", "aremos", "ará",
    "aré", "erían", "erías", "erán", "erás", "eríais", "ería", "eréis", "eríamos", "eremos",
    "erá", "eré", "irían", "irías", "irán", "irás", "iríais", "iría", "iréis", "iríamos",
    "iremos", "irá", "iré", "aba", "ada", "ida", "ía", "ara", "iera", "ad", "ed", "id",
    "ase", "iese", "aste", "iste", "an", "aban", "ían", "aran", "ieran", "asen", "iesen",
    "aron", "ieron", "ado", "ido", "ando", "iendo", "ió", "ar", "er", "ir", "as", "abas",
    "adas", "idas", "ías", "aras", "ieras", "ases", "ieses", "ís", "áis", "abais", "íais",
    "arais", "ierais", "aseis", "ieseis", "asteis", "isteis", "ados", "idos", "amos",
    "ábamos", "íamos", "imos", "áramos", "iéramos", "iésemos", "ásemos")


# ---------------------------------------------------------------- Russian
class RussianStemmer(LanguageStemmer):
    language = "russian"
    V = "аеиоуыэюя"
    PG1 = ("вшись", "вши", "в")
    PG2 = ("ившись", "ывшись", "ивши", "ывши", "ив", "ыв")
    REFL = ("ся", "сь")
    ADJ = ("ими", "ыми", "его", "ого", "ему", "ому", "ее", "ие", "ые", "ое", "ей", "ий",
           "ый", "ой", "ем", "им", "ым", "ом", "их", "ых", "ую", "юю", "ая", "яя", "ою", "ею")
    PART1 = ("ем", "нн", "вш", "ющ", "щ")
    PART2 = ("ивш", "ывш", "ующ")
    V1 = ("ете", "йте", "нно", "ешь", "ла", "на", "ли", "ем", "ло", "но", "ет", "ют",
          "ны", "ть", "й", "л", "н")
    V2 = ("ейте", "уйте", "ила", "ыла", "ена", "ите", "или", "ыли", "ило", "ыло", "ено",
          "ует", "уют", "ены", "ить", "ыть", "ишь", "ей", "уй", "ил", "ыл", "им", "ым",
          "ен", "ят", "ит", "ыт", "ую", "ю")
    NOUN = ("иями", "ями", "ами", "ией", "иям", "ием", "иях", "ев", "ов", "ие", "ье",
            "еи", "ии", "ей", "ой", "ий", "ям", "ем", "ам", "ом", "ах", "ях", "ию", "ью",
            "ия", "ья", "а", "е", "и", "й", "о", "у", "ы", "ь", "ю", "я")

    def _rv(self, w):
        for i, c in enumerate(w):
            if c in self.V:
                return i + 1
        return len(w)

    def _strip(self, w, group1, group2, rv):
        """Remove longest ending among group1 (needs a/я before) and group2."""
        best = None
        for s in group1:
            if w.endswith(s) and len(w) - len(s) >= rv and len(w) - len(s) >= 1 \
                    and w[-len(s) - 1] in "ая":
                if best is None or len(s) > len(best):
                    best = s
        for s in group2:
            if w.endswith(s) and len(w) - len(s) >= rv:
                if best is None or len(s) > len(best):
                    best = s
        return best

    def _stem(self, word):
        word = word.replace("ё", "е")
        rv = self._rv(word)
        _, p2 = r1r2_standard(word, self.V)
        # step 1
        s = self._strip(word, self.PG1, self.PG2, rv)
        if s:
            word = word[:-len(s)]
        else:
            r = longest_any(word, self.REFL)
            if r and len(word) - len(r) >= rv:
                word = word[:-len(r)]
            adj = None
            for a in self.ADJ:
                if word.endswith(a) and len(word) - len(a) >= rv:
                    if adj is None or len(a) > len(adj):
                        adj = a
            if adj:
                word = word[:-len(adj)]
                p = self._strip(word, self.PART1, self.PART2, rv)
                if p:
                    word = word[:-len(p)]
            else:
                v = self._strip(word, self.V1, self.V2, rv)
                if v:
                    word = word[:-len(v)]
                else:
                    n = longest_any(word, self.NOUN)
                    if n and len(word) - len(n) >= rv:
                        word = word[:-len(n)]
        # step 2
        if word.endswith("и") and len(word) - 1 >= rv:
            word = word[:-1]
        # step 3
        for s in ("ость", "ост"):
            if word.endswith(s) and len(word) - len(s) >= p2:
                word = word[:-len(s)]
                break
        # step 4
        for s in ("ейше", "ейш"):
            if word.endswith(s) and len(word) - len(s) >= rv:
                word = word[:-len(s)]
                break
        if word.endswith("нн"):
            word = word[:-1]
        elif word.endswith("ь") and len(word) - 1 >= rv:
            word = word[:-1]
        return word


# ---------------------------------------------------------------- fallbacks
class _LightStemmer(LanguageStemmer):
    """Generic longest-suffix stripper used where no full Snowball port is bundled."""
    SUFFIXES = ()
    MIN_STEM = 3

    def _stem(self, word):
        for s in sorted(self.SUFFIXES, key=len, reverse=True):
            if word.endswith(s) and len(word) - len(s) >= self.MIN_STEM:
                return word[:-len(s)]
        return word


class FrenchStemmer(_LightStemmer):
    language = "french"
    SUFFIXES = ("ements", "ement", "ations", "ation", "ités", "ité", "euses", "euse",
                "ments", "ment", "ives", "ive", "ifs", "if", "ances", "ance", "ences",
                "ence", "ables", "able", "istes", "iste", "es", "s", "e", "x")


class ItalianStemmer(_LightStemmer):
    language = "italian"
    SUFFIXES = ("amente", "azione", "azioni", "mente", "ità", "oso", "osa", "osi", "ose",
                "ico", "ici", "ica", "iche", "are", "ere", "ire", "i", "e", "a", "o")


class PortugueseStemmer(_LightStemmer):
    language = "portuguese"
    SUFFIXES = ("amente", "mente", "ações", "ação", "idades", "idade", "osos", "osas",
                "oso", "osa", "ismo", "ista", "es", "s", "a", "o", "e")


class FinnishStemmer(_LightStemmer):
    language = "finnish"
    SUFFIXES = ("ssa", "ssä", "sta", "stä", "lla", "llä", "lta", "ltä", "lle", "ksi",
                "ine", "en", "n", "t", "a", "ä", "i")


class HungarianStemmer(_LightStemmer):
    language = "hungarian"
    SUFFIXES = ("ban", "ben", "val", "vel", "nak", "nek", "hoz", "hez", "höz", "ból",
                "ből", "ra", "re", "ok", "ek", "ök", "k", "t")


class RomanianStemmer(_LightStemmer):
    language = "romanian"
    SUFFIXES = ("ilor", "ului", "elor", "ile", "ele", "ul", "le", "lor", "a", "e", "i")


class ArabicStemmer(LanguageStemmer):
    language = "arabic"

    def __init__(self, ignore_stopwords=False):
        LanguageStemmer.__init__(self, ignore_stopwords)
        from .arabic import ARLSTem
        self._s = ARLSTem()

    def _stem(self, word):
        return self._s.stem(word)
