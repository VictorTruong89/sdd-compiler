"""LINGORA: a pure-Python natural-language processing library.

Importing the package downloads nothing and reads no resources.
"""

from lingora import data  # noqa: F401  (spec: N-000353)

__version__ = "0.1.0"
