"""Evaluation metrics (``lingora.metrics``). FP-07.

Undefined results: ``accuracy`` and ``jaccard_distance`` of two empty collections
(accuracy raises ``ValueError``; jaccard returns 0.0); ``precision``, ``recall``
and ``f_measure`` return ``None`` where the PRD says no number results.
"""


def accuracy(reference, test):  # spec: N-000464 N-000465 N-000310 N-000312
    if not isinstance(reference, list) or not isinstance(test, list):
        raise TypeError("accuracy takes two lists")
    if len(reference) != len(test):
        raise ValueError("accuracy needs lists of equal length")
    if not reference:
        raise ValueError("accuracy is undefined for empty lists")
    return sum(1 for r, t in zip(reference, test) if r == t) / len(reference)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):  # spec: N-000466 N-000467 N-000468 N-000292 N-000293 N-000294 N-000295 N-000296 N-000297 N-000298 N-000299 N-000315
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("edit_distance takes two str")
    if isinstance(substitution_cost, bool) or not isinstance(substitution_cost, (int, float)):
        raise TypeError("substitution_cost must be a number")
    if not isinstance(transpositions, bool):
        raise TypeError("transpositions must be bool")
    if transpositions:
        return _damerau(s1, s2, substitution_cost)
    prev = list(range(len(s2) + 1))
    for i, c1 in enumerate(s1, start=1):
        cur = [i]
        for j, c2 in enumerate(s2, start=1):
            sub = 0 if c1 == c2 else substitution_cost
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + sub))
        prev = cur
    return prev[-1]


def _damerau(s1, s2, sub_cost):
    """Unrestricted Damerau-Levenshtein distance (Lowrance and Wagner, 1975)."""
    inf = len(s1) + len(s2)
    last_row = {}
    d = [[inf] * (len(s2) + 2) for _ in range(len(s1) + 2)]
    d[0][0] = inf
    for i in range(len(s1) + 1):
        d[i + 1][1] = i
        d[i + 1][0] = inf
    for j in range(len(s2) + 1):
        d[1][j + 1] = j
        d[0][j + 1] = inf
    for c in set(s1) | set(s2):
        last_row[c] = 0
    for i in range(1, len(s1) + 1):
        last_match_col = 0
        for j in range(1, len(s2) + 1):
            i1 = last_row.get(s2[j - 1], 0)
            j1 = last_match_col
            if s1[i - 1] == s2[j - 1]:
                cost = 0
                last_match_col = j
            else:
                cost = sub_cost
            d[i + 1][j + 1] = min(
                d[i][j] + cost,
                d[i + 1][j] + 1,
                d[i][j + 1] + 1,
                d[i1][j1] + (i - i1 - 1) + 1 + (j - j1 - 1),
            )
        last_row[s1[i - 1]] = i
    return d[len(s1) + 1][len(s2) + 1]


def jaccard_distance(label1, label2):  # spec: N-000469
    if not isinstance(label1, (set, frozenset)) or not isinstance(label2, (set, frozenset)):
        raise TypeError("jaccard_distance takes two sets")
    union = label1 | label2
    if not union:
        return 0.0
    return (len(union) - len(label1 & label2)) / len(union)


def _check_sets(reference, test):
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        raise TypeError("reference and test must be sets")  # spec: N-000470 N-000471


def precision(reference, test):  # spec: N-000300 N-000301 N-000311 N-000312 N-000313 N-000314
    _check_sets(reference, test)
    if not test:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):  # spec: N-000300 N-000301 N-000313 N-000314
    _check_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):  # spec: N-000300 N-000301 N-000313 N-000314
    _check_sets(reference, test)
    if isinstance(alpha, bool) or not isinstance(alpha, (int, float)):
        raise TypeError("alpha must be a number")
    p = precision(reference, test)
    r = recall(reference, test)
    if p is None or r is None:
        return None
    if p == 0 or r == 0:
        return 0.0
    return 1 / (alpha / p + (1 - alpha) / r)
