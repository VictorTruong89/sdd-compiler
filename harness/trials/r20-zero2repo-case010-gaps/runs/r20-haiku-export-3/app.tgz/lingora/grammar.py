"""Context-free grammars (``lingora.grammar``). FP-05.

Text format: one production per line, ``LHS -> RHS``; ``|`` separates alternatives;
unquoted identifiers are nonterminals, single- or double-quoted text is a terminal.
Blank lines are ignored; lines starting with ``#`` are treated as comments (NOTES.md).
"""

import re as _re


class Nonterminal:
    """A nonterminal symbol; ``str()`` is its name. Not a ``str`` subclass."""  # spec: N-000429 N-000431

    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = str(name)

    def __str__(self):
        return self._name

    def __repr__(self):
        return f"Nonterminal({self._name!r})"

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and other._name == self._name

    def __hash__(self):
        return hash(("Nonterminal", self._name))


class Production:
    """``lhs -> rhs``; ``rhs()`` is a tuple of ``Nonterminal`` or terminal ``str``."""  # spec: N-000432 N-000433

    __slots__ = ("_lhs", "_rhs")

    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __str__(self):
        parts = [f'"{s}"' if isinstance(s, str) else str(s) for s in self._rhs]
        return f"{self._lhs} -> " + (" ".join(parts) if parts else "")

    def __repr__(self):
        return f"Production({self._lhs!r}, {self._rhs!r})"

    def __eq__(self, other):
        return isinstance(other, Production) and (self._lhs, self._rhs) == (other._lhs, other._rhs)

    def __hash__(self):
        return hash((self._lhs, self._rhs))


_TOKEN_RE = _re.compile(r"""'[^']*'|"[^"]*"|\||[^\s|'"]+""")
_IDENT_RE = _re.compile(r"[^\s|'\"]+")


class CFG:
    """A context-free grammar. # spec: N-000424 N-000425 N-000426 N-000427 N-000428 N-000434"""

    def __init__(self, start, productions):
        if not productions:
            raise ValueError("a grammar needs at least one production")
        self._start = start
        self._productions = list(productions)

    @classmethod
    def fromstring(cls, input):  # spec: N-000427 N-000428 N-000240 N-000241
        if not isinstance(input, str):
            raise TypeError("grammar text must be a str")
        productions = []
        start = None
        for lineno, raw in enumerate(input.splitlines(), start=1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "->" not in line:
                raise ValueError(f"grammar line {lineno}: expected 'LHS -> RHS'")
            lhs_text, rhs_text = line.split("->", 1)
            lhs_text = lhs_text.strip()
            if not _IDENT_RE.fullmatch(lhs_text):
                raise ValueError(f"grammar line {lineno}: bad left-hand side {lhs_text!r}")
            lhs = Nonterminal(lhs_text)
            if start is None:
                start = lhs
            alternatives = [[]]
            for tok in _TOKEN_RE.findall(rhs_text):
                if tok == "|":
                    alternatives.append([])
                elif tok[0] in "'\"":
                    alternatives[-1].append(tok[1:-1])
                else:
                    alternatives[-1].append(Nonterminal(tok))
            for alt in alternatives:  # one production per alternative
                productions.append(Production(lhs, alt))
        if not productions:
            raise ValueError("grammar has no productions")
        return cls(start, productions)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        name = str(lhs)
        return [p for p in self._productions if str(p.lhs()) == name]

    def terminals(self):
        return {s for p in self._productions for s in p.rhs() if isinstance(s, str) and s != ""}

    def __repr__(self):
        return f"<CFG with {len(self._productions)} productions>"
