"""Sentence generator from a context-free grammar. # spec: N-000251 N-000252 N-000253 N-000254 N-000255 N-000440 N-000441 N-000442 N-000443

``generate(grammar, start=None, depth=None, n=None)`` yields sentences (lists of str tokens),
expanding nonterminals in their written production order. ``depth`` bounds the derivation
depth (nonterminals beyond it are not expanded); ``n`` caps the number of sentences.
"""

import itertools as _itertools
import sys as _sys

from lingora.grammar import CFG, Nonterminal


def _generate_all(grammar, items, depth):
    if not items:
        yield []
        return
    for frag1 in _generate_one(grammar, items[0], depth):
        for frag2 in _generate_all(grammar, items[1:], depth):
            yield frag1 + frag2


def _generate_one(grammar, item, depth):
    if isinstance(item, Nonterminal):
        if depth > 0:
            for prod in grammar.productions(lhs=item):
                yield from _generate_all(grammar, prod.rhs(), depth - 1)
        return
    yield [item]  # a terminal; the empty string is an empty-string token


def generate(grammar, start=None, depth=None, n=None):
    if not isinstance(grammar, CFG):
        raise TypeError("grammar must be a CFG")
    if start is None:
        start = grammar.start()
    elif not isinstance(start, Nonterminal):
        start = Nonterminal(start)
    if depth is None:
        depth = _sys.maxsize
    if n is not None and (not isinstance(n, int) or isinstance(n, bool) or n < 0):
        raise ValueError("n must be a non-negative int or None")
    sentences = _generate_all(grammar, [start], depth)
    if n is not None:
        sentences = _itertools.islice(sentences, n)
    return (list(s) for s in sentences)
