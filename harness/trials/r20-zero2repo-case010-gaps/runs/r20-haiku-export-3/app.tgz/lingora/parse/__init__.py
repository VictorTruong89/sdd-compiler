"""Parsers (``lingora.parse``). FP-05.

``ChartParser`` (exhaustive) and ``ShiftReduceParser`` (single pass, no backtracking).
A recursive-descent parser exists in LINGORA but is outside this specification.
"""

from lingora.grammar import CFG, Nonterminal  # noqa: F401
from lingora.tree import Tree


def _check_tokens(grammar, tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")
    if not all(isinstance(t, str) for t in tokens):
        raise TypeError("tokens must be a list of str")
    known = grammar.terminals()
    for t in tokens:
        if t not in known:  # spec: N-000438 N-000439 N-000266 N-000438
            raise ValueError(f"token {t!r} is not produced by any production of the grammar")


class _ChartContext:
    def __init__(self, grammar, tokens):
        self.tokens = list(tokens)
        self.prods = {}
        for p in grammar.productions():
            self.prods.setdefault(str(p.lhs()), []).append(p)
        self.memo = {}
        self.active = set()


def _span_trees(ctx, name, i, j):
    key = (name, i, j)
    if key in ctx.memo:
        return ctx.memo[key]
    if key in ctx.active:  # cyclic (unit or epsilon) derivation: not expanded again
        return []
    ctx.active.add(key)
    results = []
    for prod in ctx.prods.get(name, []):
        for children in _match_rhs(ctx, prod.rhs(), 0, i, j):
            results.append(Tree(name, children))
    ctx.active.discard(key)
    ctx.memo[key] = results
    return results


def _match_rhs(ctx, rhs, idx, pos, end):
    if idx == len(rhs):
        if pos == end:
            yield []
        return
    sym = rhs[idx]
    if isinstance(sym, str):
        if sym == "":
            yield from _match_rhs(ctx, rhs, idx + 1, pos, end)
            return
        if pos < end and ctx.tokens[pos] == sym:
            for rest in _match_rhs(ctx, rhs, idx + 1, pos + 1, end):
                yield [sym] + rest
        return
    for k in range(pos, end + 1):
        for sub in _span_trees(ctx, str(sym), pos, k):
            for rest in _match_rhs(ctx, rhs, idx + 1, k, end):
                yield [sub] + rest


class ChartParser:
    """Exhaustive chart parser: every parse tree of the token list. # spec: N-000242 N-000243 N-000244 N-000245 N-000246"""

    def __init__(self, grammar):
        if not isinstance(grammar, CFG):
            raise TypeError("grammar must be a CFG")
        self._grammar = grammar

    def parse(self, tokens):  # spec: N-000436 N-000437 N-000438 N-000439
        _check_tokens(self._grammar, tokens)  # raises at the call for uncovered tokens
        ctx = _ChartContext(self._grammar, tokens)
        start = str(self._grammar.start())
        return iter(_span_trees(ctx, start, 0, len(ctx.tokens)))


class ShiftReduceParser:
    """Single left-to-right shift-reduce pass, no backtracking. # spec: N-000247 N-000248 N-000249 N-000250"""

    def __init__(self, grammar):
        if not isinstance(grammar, CFG):
            raise TypeError("grammar must be a CFG")
        self._grammar = grammar

    def parse(self, tokens):  # spec: N-000436 N-000438 N-000439
        _check_tokens(self._grammar, tokens)
        productions = [p for p in self._grammar.productions() if p.rhs()]
        start = str(self._grammar.start())
        stack = []  # items: (symbol_name_or_terminal, tree_or_token)
        pos = 0
        toks = list(tokens)
        while True:
            reduced = True
            while reduced:  # reduce whenever the top of the stack matches a production's rhs
                reduced = False
                for prod in productions:
                    rhs = prod.rhs()
                    if len(rhs) > len(stack):
                        continue
                    top = stack[len(stack) - len(rhs):]
                    if all(_matches(sym, item) for sym, item in zip(rhs, top)):
                        children = [item for _, item in top]
                        del stack[len(stack) - len(rhs):]
                        stack.append((str(prod.lhs()), Tree(str(prod.lhs()), children)))
                        reduced = True
                        break
            if pos >= len(toks):
                break
            stack.append(("token", toks[pos]))
            pos += 1
        if len(stack) == 1 and stack[0][0] == start and isinstance(stack[0][1], Tree):
            return iter([stack[0][1]])
        return iter([])


def _matches(sym, item):
    kind, value = item
    if isinstance(sym, str):
        return kind == "token" and value == sym
    return kind == str(sym) and isinstance(value, Tree)
