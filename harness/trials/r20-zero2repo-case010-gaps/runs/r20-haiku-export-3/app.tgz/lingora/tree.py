"""Constituent trees (``lingora.tree``).

# spec: N-000444 N-000445 N-000446 N-000447 N-000448 N-000449 N-000450 N-000451 N-000452 N-000453 N-000454
"""

import re as _re


class Tree:
    """A labelled tree. Children are leaves (token strings, or other leaf
    objects such as ``(token, tag)`` pairs in chunk structures) or ``Tree``s."""

    def __init__(self, label, children):
        if isinstance(children, (str, bytes)):  # spec: N-000449
            raise TypeError("Tree children must be a list, not a string")
        if not isinstance(children, list):  # spec: N-000450, N-000451
            raise TypeError("Tree children must be a list")
        self._label = label
        self._children = list(children)

    @classmethod
    def fromstring(cls, s):
        """Parse bracketed tree text ``(label child ...)``. # spec: N-000452"""
        tokens = _re.findall(r"\(|\)|[^\s()]+", s)
        pos = 0

        def parse():
            nonlocal pos
            if pos >= len(tokens) or tokens[pos] != "(":
                raise ValueError("expected '(' in bracketed tree text")
            pos += 1
            if pos >= len(tokens) or tokens[pos] in ("(", ")"):
                raise ValueError("node has no label")
            label = tokens[pos]
            pos += 1
            children = []
            while pos < len(tokens) and tokens[pos] != ")":
                if tokens[pos] == "(":
                    children.append(parse())
                else:
                    children.append(tokens[pos])
                    pos += 1
            if pos >= len(tokens):
                raise ValueError("unbalanced brackets in tree text")
            pos += 1  # consume ')'
            return cls(label, children)

        tree = parse()
        if pos != len(tokens):
            raise ValueError("trailing text after tree")
        return tree

    def label(self):
        return self._label

    def leaves(self):
        out = []
        for child in self._children:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def pformat(self):
        """Pre-order, one-line bracketed rendering. # spec: N-000453 N-000454 N-000261"""
        parts = []
        for child in self._children:
            if isinstance(child, Tree):
                parts.append(child.pformat())
            elif isinstance(child, tuple) and len(child) == 2:
                parts.append(f"{child[0]}/{child[1]}")
            else:
                parts.append(str(child))
        if not parts:
            return f"({self._label})"
        return f"({self._label} " + " ".join(parts) + ")"

    def __str__(self):
        return self.pformat()

    def __repr__(self):
        return f"Tree({self._label!r}, {self._children!r})"

    def __iter__(self):  # spec: N-000446
        return iter(self._children)

    def __len__(self):  # spec: N-000446
        return len(self._children)

    def __getitem__(self, index):  # spec: N-000446, N-000258
        return self._children[index]

    def __eq__(self, other):  # spec: N-000448
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __ne__(self, other):
        result = self.__eq__(other)
        return result if result is NotImplemented else not result

    def __hash__(self):
        return hash((self._label, tuple(self._children)))
