"""Part-of-speech taggers (``lingora.tag``). Feature point FP-03.

Trainable sequential taggers: ``DefaultTagger``, ``UnigramTagger``, ``RegexpTagger``
(bigram, trigram and affix taggers are not implemented; see NOTES.md).
Recommended tagger: ``pos_tag`` (averaged perceptron, packaged English or Russian resource).
"""

import json as _json
import re as _re
from collections import Counter as _Counter, defaultdict as _defaultdict
import os as _os

from lingora import data as _data


def _check_tokens(tokens):
    if isinstance(tokens, str):
        raise TypeError("tokens must be a list of str, not a str")
    if not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")
    for t in tokens:
        if not isinstance(t, str):
            raise TypeError("every token must be a str")


class _SequentialTagger:
    backoff = None

    def _choose(self, tokens):
        raise NotImplementedError

    def tag(self, tokens):  # spec: N-000185 N-000186 N-000408 N-000409
        _check_tokens(tokens)
        tags = list(self._choose(tokens))
        if self.backoff is not None:  # spec: N-000194 N-000195
            # the backoff is consulted only for tokens the primary tagger left untagged
            missing = [i for i, t in enumerate(tags) if t is None]
            if missing:
                fallback = self.backoff.tag(list(tokens))
                for i in missing:
                    tags[i] = fallback[i][1]
        return list(zip(tokens, tags))


class DefaultTagger(_SequentialTagger):
    """Assigns one configured tag to every token. # spec: N-000187"""

    def __init__(self, tag, backoff=None):
        self._tag = tag
        self.backoff = backoff

    def _choose(self, tokens):
        return [self._tag] * len(tokens)


class UnigramTagger(_SequentialTagger):
    """Most frequent training tag per word. # spec: N-000188 N-000189 N-000190 N-000032 N-000177"""

    def __init__(self, train=None, backoff=None):
        self.backoff = backoff
        self._model = {}
        if train is not None:
            counts = _defaultdict(_Counter)
            for sentence in train:
                for pair in sentence:
                    if not (isinstance(pair, (tuple, list)) and len(pair) == 2):
                        raise TypeError("training sentences must hold (token, tag) pairs")
                    token, tag = pair
                    counts[token][tag] += 1
            for token, c in counts.items():
                # ties broken deterministically: first-seen tag wins among equal counts
                self._model[token] = max(c.items(), key=lambda kv: kv[1])[0]

    def _choose(self, tokens):
        return [self._model.get(t) for t in tokens]


class RegexpTagger(_SequentialTagger):
    """First rule whose pattern matches at the token's start gives the tag. # spec: N-000191 N-000192 N-000193"""

    def __init__(self, regexps, backoff=None):
        self.backoff = backoff
        self._rules = []
        for pattern, tag in regexps:
            if not isinstance(pattern, str) or not isinstance(tag, str):
                raise TypeError("regexps must be (pattern, tag) pairs of str")
            self._rules.append((_re.compile(pattern), tag))

    def _choose(self, tokens):
        out = []
        for token in tokens:
            tag = None
            for rx, t in self._rules:
                if rx.match(token):
                    tag = t
                    break
            out.append(tag)
        return out


# ------------------------------------------------------------- universal tagset
_RUSSIAN_TO_UNIVERSAL = {  # implementer's table for Russian National Corpus categories (spec: N-000207)
    "S": "NOUN", "V": "VERB", "A": "ADJ", "ANUM": "ADJ", "NUM": "NUM", "ADV": "ADV",
    "PR": "ADP", "CONJ": "CONJ", "PART": "PRT", "SPRO": "PRON", "APRO": "DET",
    "INTJ": "X", "NONLEX": "X", "UNKN": "X", "PRAEDIC": "ADV", "PRAEDIC_PRO": "ADV",
}

_universal_cache = {}


def _english_universal_map():
    if "eng" in _universal_cache:
        return _universal_cache["eng"]
    directory = _data.require_dir(_os.path.join("taggers", "universal_tagset"), "universal tagset tables")
    table = {}
    for line in _data.read_lines(_os.path.join(directory, "en-ptb.map")):
        parts = line.split("\t")
        if len(parts) == 2:
            table[parts[0].strip()] = parts[1].strip()
    _universal_cache["eng"] = table
    return table


class _Perceptron:
    START = ["-START-", "-START2-"]
    END = ["-END-", "-END2-"]

    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = classes

    @staticmethod
    def normalize(word):
        if "-" in word and word[0] != "-":
            return "!HYPHEN"
        if word.isdigit() and len(word) == 4:
            return "!YEAR"
        if word[:1].isdigit():
            return "!DIGITS"
        return word.lower()

    def _predict(self, features):
        scores = _defaultdict(float)
        for feat, value in features.items():
            if feat not in self.weights or value == 0:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        labels = self.classes or list(scores)
        if not labels:
            return None
        return max(labels, key=lambda label: (scores[label], label))

    @staticmethod
    def _features(i, word, context, prev, prev2):
        features = _defaultdict(int)

        def add(name, *args):
            features[" ".join((name,) + tuple(args))] += 1

        i += len(_Perceptron.START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return features

    def tag(self, tokens):
        prev, prev2 = self.START
        context = self.START + [self.normalize(w) for w in tokens] + self.END
        out = []
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                features = self._features(i, word, context, prev, prev2)
                tag = self._predict(features)
            out.append((word, tag))
            prev2 = prev
            prev = tag
        return out


_perceptron_cache = {}


def _load_perceptron(lang):
    if lang in _perceptron_cache:
        return _perceptron_cache[lang]
    directory = _data.require_dir(
        _os.path.join("taggers", f"averaged_perceptron_tagger_{lang}"),
        f"averaged perceptron tagger ({lang})",
    )
    base = _os.path.join(directory, f"averaged_perceptron_tagger_{lang}")

    def load(suffix):
        path = base + suffix
        if not _os.path.isfile(path):
            raise LookupError(f"averaged perceptron tagger file missing: {path}")
        with open(path, encoding="utf-8") as fh:
            return _json.load(fh)

    model = _Perceptron(load(".weights.json"), load(".tagdict.json"), load(".classes.json"))
    _perceptron_cache[lang] = model
    return model


def pos_tag(tokens, tagset=None, lang="eng"):  # spec: N-000397 N-000398 N-000404 N-000405 N-000406 N-000407 N-000183 N-000215 N-000216
    """Tag a token list with LINGORA's recommended averaged perceptron tagger.

    ``lang`` is ``'eng'`` (Penn Treebank tags) or ``'rus'`` (Russian National Corpus tags).
    ``tagset`` is ``None`` (native tags) or ``'universal'``. Raises ``TypeError`` for a str
    ``tokens``, ``ValueError`` for an unknown ``lang``/``tagset``, and ``LookupError`` when the
    required model is not visible.
    """
    _check_tokens(tokens)
    if lang not in ("eng", "rus"):
        raise ValueError(f"unsupported language for pos_tag: {lang!r}")
    if tagset not in (None, "universal"):
        raise ValueError(f"unsupported tagset: {tagset!r}")
    model = _load_perceptron(lang)
    tagged = model.tag(list(tokens))
    if tagset == "universal":
        if lang == "eng":
            table = _english_universal_map()
            tagged = [(w, table.get(t, t)) for w, t in tagged]
        else:
            tagged = [(w, _russian_universal(t)) for w, t in tagged]
    return tagged


def _russian_universal(tag):
    if tag is None:
        return None
    head = tag.split("=", 1)[0]
    return _RUSSIAN_TO_UNIVERSAL.get(head, "X")


__all__ = ["DefaultTagger", "UnigramTagger", "RegexpTagger", "pos_tag"]
