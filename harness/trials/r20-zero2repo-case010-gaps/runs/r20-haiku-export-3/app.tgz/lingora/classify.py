"""Classifiers (``lingora.classify``). FP-06.

``NaiveBayesClassifier`` (ELE-smoothed, label priors, per-feature value counts) and
``DecisionTreeClassifier`` (multi-way splits on feature values by information gain).
"""

import math as _math
from collections import Counter as _Counter, defaultdict as _defaultdict

_ABSENT = object()  # a feature missing from a featureset counts as having no value


def _check_labeled(labeled):
    if isinstance(labeled, (str, bytes)) or not isinstance(labeled, (list, tuple)):
        raise TypeError("labeled featuresets must be a list of (featureset, label) pairs")
    out = []
    for pair in labeled:
        if not (isinstance(pair, (tuple, list)) and len(pair) == 2 and isinstance(pair[0], dict)):
            raise TypeError("each item must be a (featureset dict, label) pair")
        out.append((dict(pair[0]), pair[1]))
    return out


class ProbDist:
    """Probability distribution over labels. # spec: N-000459 N-000460 N-000280 N-000281"""

    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def samples(self):
        return list(self._probs)

    def __repr__(self):
        return f"<ProbDist with {len(self._probs)} labels>"


class NaiveBayesClassifier:
    """Naive Bayes. # spec: N-000455 N-000456 N-000277 N-000278 N-000279 N-000280 N-000281 N-000282"""

    def __init__(self):
        self._labels = []
        self._prior = {}
        self._counts = {}
        self._totals = {}
        self._bins = {}

    @classmethod
    def train(cls, labeled_featuresets):
        data = _check_labeled(labeled_featuresets)
        if not data:
            raise ValueError("cannot train on an empty list")
        self = cls()
        label_counts = _Counter()
        values = _defaultdict(set)
        counts = _defaultdict(_Counter)
        for fs, label in data:
            label_counts[label] += 1
            for fname, fval in fs.items():
                counts[(label, fname)][fval] += 1
                values[fname].add(fval)
        total = len(data)
        self._labels = list(label_counts)
        self._prior = {label: c / total for label, c in label_counts.items()}
        self._counts = dict(counts)
        self._totals = {key: sum(c.values()) for key, c in counts.items()}
        self._bins = {fname: len(vals) for fname, vals in values.items()}
        return self

    def labels(self):  # spec: N-000282
        return list(self._labels)

    def _log_joint(self, featureset):
        fs = dict(featureset)
        logs = {}
        for label in self._labels:
            lp = _math.log(self._prior[label])
            for fname, fval in fs.items():
                key = (label, fname)
                count = self._counts.get(key, _Counter()).get(fval, 0)
                total = self._totals.get(key, 0)
                bins = self._bins.get(fname, 1)
                # expected-likelihood estimate: (count + 0.5) / (total + 0.5 * bins)
                lp += _math.log((count + 0.5) / (total + 0.5 * bins))
            logs[label] = lp
        return logs

    def prob_classify(self, featureset):  # spec: N-000280 N-000281
        if not isinstance(featureset, dict):
            raise TypeError("featureset must be a dict")
        logs = self._log_joint(featureset)
        m = max(logs.values())
        exps = {label: _math.exp(v - m) for label, v in logs.items()}
        z = sum(exps.values())
        return ProbDist({label: e / z for label, e in exps.items()})

    def classify(self, featureset):  # spec: N-000279
        dist = self.prob_classify(featureset)
        return max(self._labels, key=lambda label: dist.prob(label))


class _Node:
    __slots__ = ("feature", "branches", "label")

    def __init__(self, feature=None, branches=None, label=None):
        self.feature = feature
        self.branches = branches or {}
        self.label = label


def _entropy(labels):
    n = len(labels)
    if n == 0:
        return 0.0
    h = 0.0
    for c in _Counter(labels).values():
        p = c / n
        h -= p * _math.log2(p)
    return h


def _majority(labels):
    counts = _Counter(labels)
    best = max(counts.values())
    for label in labels:  # ties: first label seen
        if counts[label] == best:
            return label


class DecisionTreeClassifier:
    """Decision tree over feature tests. # spec: N-000283 N-000284 N-000285 N-000286 N-000287"""

    def __init__(self, root):
        self._root = root

    @classmethod
    def train(cls, labeled_featuresets):
        data = _check_labeled(labeled_featuresets)
        if not data:
            raise ValueError("cannot train on an empty list")
        features = set()
        for fs, _ in data:
            features.update(fs)
        return cls(cls._build(data, sorted(features, key=str)))

    @staticmethod
    def _build(items, features):
        labels = [label for _, label in items]
        majority = _majority(labels)
        if len(set(labels)) == 1 or not features:
            return _Node(label=majority)
        base = _entropy(labels)
        best = None
        for f in features:
            groups = _defaultdict(list)
            for fs, label in items:
                groups[fs.get(f, _ABSENT)].append((fs, label))
            if len(groups) < 2:
                continue
            n = len(items)
            remainder = sum(len(g) / n * _entropy([l for _, l in g]) for g in groups.values())
            gain = base - remainder
            if best is None or gain > best[0] + 1e-12:
                best = (gain, f, groups)
        if best is None or best[0] <= 1e-12:
            return _Node(label=majority)
        _, f, groups = best
        rest = [g for g in features if g != f]
        branches = {value: DecisionTreeClassifier._build(group, rest) for value, group in groups.items()}
        return _Node(feature=f, branches=branches, label=majority)

    def classify(self, featureset):  # spec: N-000285 N-000286
        if not isinstance(featureset, dict):
            raise TypeError("featureset must be a dict")
        node = self._root
        while node.feature is not None:
            value = featureset.get(node.feature, _ABSENT)
            child = node.branches.get(value)
            if child is None:
                return node.label
            node = child
        return node.label


def accuracy(classifier, gold):  # spec: N-000287 N-000288 N-000310
    """Fraction of gold (featureset, label) pairs the classifier labels correctly."""
    data = _check_labeled(gold)
    if not data:
        raise ValueError("accuracy is undefined for an empty gold list")
    correct = sum(1 for fs, label in data if classifier.classify(fs) == label)
    return correct / len(data)
