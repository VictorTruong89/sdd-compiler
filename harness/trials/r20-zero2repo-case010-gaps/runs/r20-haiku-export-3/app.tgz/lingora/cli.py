"""Command line (``lingora.cli``). # spec: N-000382 N-000383 N-000384 N-000385 N-000386 N-000387 N-000388

``from lingora.cli import cli``; ``cli.main(args=['tokenize'], standalone_mode=True)``.

``tokenize`` reads UTF-8 text line by line from standard input and writes, for every input
line, the recommended word tokenizer's tokens (with sentence splitting) joined by the delimiter
(a single space by default), followed by a newline. Options (implementer's choice):
``--language/-l`` (default ``english``), ``--delimiter/-d`` (default one space),
``--encoding/-e`` (default ``utf-8``).

Failure (e.g. the Punkt models for the language are not visible): nothing is written for the
failed line, a message goes to standard error, and the exit status is 1. Usage errors exit 2.
"""

import sys as _sys

from lingora.tokenize import word_tokenize

_USAGE = "usage: lingora tokenize [--language LANG] [--delimiter DELIM] [--encoding ENC]"


class _Command:
    name = "tokenize"


class _CLI:
    """A command group with one command, ``tokenize``."""

    def main(self, args=None, standalone_mode=True):
        argv = list(_sys.argv[1:] if args is None else args)
        code = self._run(argv)
        if standalone_mode:
            _sys.exit(code)
        return code

    def _run(self, argv):
        if not argv or argv[0] in ("-h", "--help"):
            _sys.stdout.write(_USAGE + "\n")
            return 0 if argv else 2
        command, rest = argv[0], argv[1:]
        if command != "tokenize":
            _sys.stderr.write(f"lingora: no such command {command!r}\n{_USAGE}\n")
            return 2
        language, delimiter, encoding = "english", " ", "utf-8"
        i = 0
        while i < len(rest):
            opt = rest[i]
            if opt in ("-h", "--help"):
                _sys.stdout.write(_USAGE + "\n")
                return 0
            name, value = opt, None
            if "=" in opt and opt.startswith("--"):
                name, value = opt.split("=", 1)
            elif name in ("--language", "-l", "--delimiter", "-d", "--encoding", "-e"):
                i += 1
                if i >= len(rest):
                    _sys.stderr.write(f"lingora: option {name} needs a value\n{_USAGE}\n")
                    return 2
                value = rest[i]
            else:
                _sys.stderr.write(f"lingora: unknown option {opt!r}\n{_USAGE}\n")
                return 2
            if name in ("--language", "-l"):
                language = value
            elif name in ("--delimiter", "-d"):
                delimiter = value
            elif name in ("--encoding", "-e"):
                encoding = value
            else:
                _sys.stderr.write(f"lingora: unknown option {name!r}\n{_USAGE}\n")
                return 2
            i += 1
        return self._tokenize(language, delimiter, encoding)

    @staticmethod
    def _tokenize(language, delimiter, encoding):
        stdin = _sys.stdin
        try:
            if hasattr(stdin, "buffer"):
                text = stdin.buffer.read().decode(encoding)
            else:
                text = stdin.read()
        except UnicodeDecodeError as exc:
            _sys.stderr.write(f"lingora: input is not valid {encoding}: {exc}\n")
            return 1
        lines = text.split("\n")
        if lines and lines[-1] == "":  # the newline that ends the last line
            lines.pop()
        out = _sys.stdout
        for line in lines:
            line = line[:-1] if line.endswith("\r") else line
            try:
                tokens = word_tokenize(line, language=language)
            except Exception as exc:  # this line produces no token line
                out.flush()
                _sys.stderr.write(f"lingora: tokenize failed: {exc}\n")
                return 1
            out.write(delimiter.join(tokens) + "\n")
        out.flush()
        return 0


cli = _CLI()
