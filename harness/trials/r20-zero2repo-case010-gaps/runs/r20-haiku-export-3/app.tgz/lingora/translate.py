"""Translation-quality scores (``lingora.translate``). FP-07: BLEU.

``bleu(references, hypothesis, weights=(0.25,0.25,0.25,0.25), smoothing_function=None)``.
``smoothing_function`` (implementer's choice of form, NOTES.md) is a callable taking the list
of ``(clipped_count, total_count)`` pairs per order and returning a list of precisions;
``epsilon_smoothing`` is provided as a ready-made one.
"""

import math as _math
from collections import Counter as _Counter


def _ngrams(tokens, n):
    return _Counter(tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1))


def epsilon_smoothing(pairs):
    """Replace a zero clipped count with 0.1 (a common sentence-BLEU smoothing)."""
    out = []
    for clipped, total in pairs:
        if total == 0:
            out.append(0.0)
        elif clipped == 0:
            out.append(0.1 / total)
        else:
            out.append(clipped / total)
    return out


def _check_tokens(tokens):
    if not isinstance(tokens, list) or not all(isinstance(t, str) for t in tokens):
        raise TypeError("token lists must be lists of str")


def bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):  # spec: N-000473 N-000474 N-000475 N-000476 N-000477 N-000302 N-000303 N-000304 N-000305 N-000306 N-000307 N-000308 N-000309 N-000289
    if not isinstance(references, list) or not references:
        raise TypeError("references must be a non-empty list of token lists")
    for ref in references:
        _check_tokens(ref)
    _check_tokens(hypothesis)
    weights = tuple(weights)
    if not weights or not all(isinstance(w, (int, float)) and not isinstance(w, bool) for w in weights):
        raise TypeError("weights must be a non-empty sequence of numbers")
    hyp_len = len(hypothesis)
    if hyp_len == 0:
        return 0.0
    ref_lens = [len(r) for r in references]
    closest = min(ref_lens, key=lambda r: (abs(r - hyp_len), r))  # ties: the shorter one
    if hyp_len > closest:
        bp = 1.0
    else:
        bp = _math.exp(1 - closest / hyp_len)

    pairs = []
    for order in range(1, len(weights) + 1):
        hyp_counts = _ngrams(hypothesis, order)
        max_ref = _Counter()
        for ref in references:
            for gram, c in _ngrams(ref, order).items():
                if c > max_ref[gram]:
                    max_ref[gram] = c
        clipped = sum(min(c, max_ref[g]) for g, c in hyp_counts.items())
        total = sum(hyp_counts.values())
        pairs.append((clipped, total))

    if smoothing_function is None:
        precisions = []
        for clipped, total in pairs:
            if total == 0 or clipped == 0:
                return 0.0
            precisions.append(clipped / total)
    else:
        precisions = list(smoothing_function(pairs))
        if any(p <= 0 for p, w in zip(precisions, weights) if w):
            return 0.0

    score = sum(w * _math.log(p) for w, p in zip(weights, precisions) if w)
    return bp * _math.exp(score)
