"""Packaged-resource finder (``lingora.data``).

# spec: N-000353 N-000354 N-000355 N-000356 N-000365 N-000366 N-000367 N-000368 N-000369 N-000370
# spec: N-000357 N-000358 N-000359 N-000360 N-000361 N-000362 N-000363 N-000364

``path`` is a mutable list of directories searched, in order, for packaged
resources. It is read at every lookup, so a caller may replace its contents
in place at any time. Initial contents (implementer's choice, see NOTES.md):
the entries of the ``LINGORA_DATA`` environment variable (``os.pathsep``
separated), then ``<project root>/lingora_data`` and ``~/lingora_data``.
Only directories that exist are ever read.
"""

import os as _os

_PROJECT_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))

path = [p for p in _os.environ.get("LINGORA_DATA", "").split(_os.pathsep) if p]
path.append(_os.path.join(_PROJECT_ROOT, "lingora_data"))
path.append(_os.path.join(_os.path.expanduser("~"), "lingora_data"))


def find(relative):
    """Return the first existing ``os.path.join(dir, relative)`` on ``path``, or ``None``."""
    for directory in list(path):
        if not directory:
            continue
        candidate = _os.path.join(directory, relative)
        if _os.path.exists(candidate):
            return candidate
    return None


def find_dir(relative):
    """Like :func:`find` but only accepts existing directories."""
    for directory in list(path):
        if not directory:
            continue
        candidate = _os.path.join(directory, relative)
        if _os.path.isdir(candidate):
            return candidate
    return None


def require_dir(relative, what):
    """Return the directory for a packaged resource or raise ``LookupError``."""
    found = find_dir(relative)
    if found is None:
        raise LookupError(f"packaged resource not visible: {what} ({relative})")
    return found


def read_lines(filepath):
    """Read a UTF-8 text file; each line without its terminator is one entry."""
    with open(filepath, encoding="utf-8") as fh:
        return [line.rstrip("\r\n") for line in fh]
