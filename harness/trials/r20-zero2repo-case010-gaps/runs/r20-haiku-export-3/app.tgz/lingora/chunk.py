"""Chunking (``lingora.chunk``). Feature point FP-04.

``RegexpParser(grammar)`` reads a chunk grammar; ``parse(tagged)`` returns a ``Tree``.
Grammar: clauses ``LABEL: pattern`` with further patterns on indented lines.
``{...}`` is a chunk rule, ``}...{`` a chink rule; tag patterns are ``<regex>`` elements
with optional ``?``, ``*``, ``+``, ``{m}``, ``{m,n}``, ``{m,}`` quantifiers.
"""

import re as _re

from lingora.tree import Tree

ROOT_LABEL = "S"  # default sentence label (implementer's choice, spec: N-000420)
_INF = float("inf")
_QUANT_RE = _re.compile(r"\{(\d+)(?:(,)(\d*))?\}")
_CLAUSE_RE = _re.compile(r"^([^\s:]+):(.*)$")


class _Element:
    __slots__ = ("regex", "lo", "hi")

    def __init__(self, regex, lo, hi):
        self.regex = regex
        self.lo = lo
        self.hi = hi


class _Rule:
    __slots__ = ("kind", "elements")

    def __init__(self, kind, elements):
        self.kind = kind  # "chunk" or "chink"
        self.elements = elements


def _parse_pattern_text(text, label, lineno):
    """Parse a sequence of ``{...}`` / ``}...{`` rules from one pattern line."""
    rules = []
    i = 0
    n = len(text)
    while i < n:
        ch = text[i]
        if ch.isspace():
            i += 1
            continue
        if ch == "{":
            kind, closer = "chunk", "}"
        elif ch == "}":
            kind, closer = "chink", "{"
        else:
            raise ValueError(f"grammar line {lineno}: unexpected {ch!r} in pattern of {label!r}")
        i += 1
        elements = []
        while True:
            if i >= n:
                raise ValueError(f"grammar line {lineno}: unterminated {kind} rule in {label!r}")
            c = text[i]
            if c == closer:
                i += 1
                break
            if c.isspace():
                i += 1
                continue
            if c == "<":
                end = text.find(">", i + 1)
                if end < 0:
                    raise ValueError(f"grammar line {lineno}: unterminated '<' in {label!r}")
                content = text[i + 1:end]
                try:
                    regex = _re.compile(content)
                except _re.error as exc:
                    raise ValueError(f"grammar line {lineno}: bad tag pattern {content!r}: {exc}")
                elements.append(_Element(regex, 1, 1))
                i = end + 1
                continue
            if c in "?*+" and elements:
                last = elements[-1]
                last.lo, last.hi = {"?": (0, 1), "*": (0, _INF), "+": (1, _INF)}[c]
                i += 1
                continue
            if c == "{" and elements:
                m = _QUANT_RE.match(text, i)
                if m:
                    lo = int(m.group(1))
                    if m.group(2):
                        hi = int(m.group(3)) if m.group(3) else _INF
                    else:
                        hi = lo
                    elements[-1].lo, elements[-1].hi = lo, hi
                    i = m.end()
                    continue
            raise ValueError(f"grammar line {lineno}: unexpected {c!r} in {kind} rule of {label!r}")
        rules.append(_Rule(kind, elements))
    return rules


def _parse_grammar(grammar):
    if not isinstance(grammar, str):
        raise TypeError("grammar must be a str")
    clauses = []  # list of (label, [rules])
    for lineno, raw in enumerate(grammar.splitlines(), start=1):
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        if raw[:1].isspace():
            if not clauses:
                raise ValueError(f"grammar line {lineno}: pattern before any clause label")
            clauses[-1][1].extend(_parse_pattern_text(raw, clauses[-1][0], lineno))
            continue
        m = _CLAUSE_RE.match(raw.strip())
        if not m:
            raise ValueError(f"grammar line {lineno}: expected 'LABEL: pattern'")
        label = m.group(1)
        clauses.append((label, _parse_pattern_text(m.group(2), label, lineno)))
    if not clauses:
        raise ValueError("chunk grammar has no clauses")
    return clauses


def _unit_tag(unit):
    kind, payload = unit[0], unit[1]
    if kind == "leaf":
        return payload[1] if isinstance(payload, tuple) and len(payload) == 2 else None
    return payload.label()


def _match_at(elements, units, start, end):
    """Longest end index of a tag-pattern match beginning at ``start`` within ``units[start:end]``."""
    reach = {start}
    for el in elements:
        nxt = set()
        for p in reach:
            cur = p
            k = 0
            if el.lo <= 0:
                nxt.add(cur)
            while k < el.hi and cur < end:
                tag = _unit_tag(units[cur])
                if tag is None or not el.regex.fullmatch(tag):
                    break
                cur += 1
                k += 1
                if k >= el.lo:
                    nxt.add(cur)
        reach = nxt
        if not reach:
            return None
    ends = [e for e in reach if e > start]
    return max(ends) if ends else None


def _leaf_unit(pair):
    return ("leaf", pair)


class RegexpParser:
    """Chunk parser built from a chunk grammar. # spec: N-000410 N-000411 N-000413 N-000416 N-000417"""

    def __init__(self, grammar):
        if isinstance(grammar, (list, tuple)):
            # a list of stages: each stage is a grammar string, applied in order
            self._stages = [_parse_grammar(g) for g in grammar]
        else:
            self._stages = [_parse_grammar(grammar)]

    def parse(self, tagged):  # spec: N-000418 N-000419 N-000421 N-000422 N-000423 N-000234 N-000235
        if isinstance(tagged, str) or not isinstance(tagged, (list, tuple)):
            raise TypeError("tagged must be a list of (token, tag) pairs")
        pairs = []
        for pair in tagged:
            if not (isinstance(pair, (tuple, list)) and len(pair) == 2):
                raise TypeError("tagged must be a list of (token, tag) pairs")
            pairs.append((pair[0], pair[1]))
        entries = [["leaf", p, False] for p in pairs]  # [kind, payload, own_chunk]
        for stage in self._stages:
            for label, rules in stage:
                entries = self._apply_clause(label, rules, entries)
                for e in entries:
                    e[2] = False
        return Tree(ROOT_LABEL, [e[1] for e in entries])

    @staticmethod
    def _apply_clause(label, rules, entries):
        for rule in rules:
            if rule.kind == "chunk":
                entries = _apply_chunk(label, rule.elements, entries)
            else:
                entries = _apply_chink(rule.elements, entries)
        return entries


def _apply_chunk(label, elements, entries):
    units = [(e[0], e[1]) for e in entries]  # (kind, payload) as used by _match_at
    n = len(units)
    out = []
    i = 0
    while i < n:
        if entries[i][2]:  # chunk built earlier in this clause: opaque to chunk rules
            out.append(entries[i])
            i += 1
            continue
        run_end = i
        while run_end < n and not entries[run_end][2]:
            run_end += 1
        j = i
        while j < run_end:
            e = _match_at(elements, units, j, run_end)
            if e is None:
                out.append(entries[j])
                j += 1
            else:
                children = [entries[k][1] for k in range(j, e)]
                out.append(["tree", Tree(label, children), True])
                j = e
        i = run_end
    return out


def _apply_chink(elements, entries):
    out = []
    for entry in entries:
        if not entry[2]:
            out.append(entry)
            continue
        tree = entry[1]
        units = [("leaf", c) if not isinstance(c, Tree) else ("tree", c) for c in tree]
        pieces = []  # list of ("keep", [units]) / ("chink", unit)
        pos = 0
        n = len(units)
        keep = []
        while pos < n:
            e = _match_at(elements, units, pos, n)
            if e is None:
                keep.append(units[pos])
                pos += 1
            else:
                if keep:
                    pieces.append(("keep", keep))
                    keep = []
                for k in range(pos, e):
                    pieces.append(("chink", units[k]))
                pos = e
        if keep:
            pieces.append(("keep", keep))
        for kind, value in pieces:
            if kind == "keep":
                out.append(["tree", Tree(tree.label(), [u[1] for u in value]), True])
            else:
                out.append([value[0], value[1], False])  # a leaf pair, or an earlier-clause Tree
    return out


def ne_chunk(tagged_tokens):
    """Named-entity chunker. Requires the packaged NE model and English wordlist.
    Raises ``LookupError`` if either is not visible; otherwise raises ``NotImplementedError``
    (the model's results are outside this specification; see NOTES.md)."""  # spec: N-000415
    if not isinstance(tagged_tokens, (list, tuple)):
        raise TypeError("tagged_tokens must be a list of (token, tag) pairs")
    from lingora import data as _data

    if _data.find_dir("chunkers/maxent_ne_chunker_tab/english_ace_multiclass") is None:
        raise LookupError("named-entity chunker model not visible")
    if _data.find("corpora/words") is None:
        raise LookupError("English wordlist not visible")
    raise NotImplementedError("named-entity chunking is not implemented")
