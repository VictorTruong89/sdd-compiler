"""Tokenizers (``lingora.tokenize``).

Feature point FP-01. Public entries: ``wordpunct_tokenize``, ``WordPunctTokenizer``,
``TreebankWordTokenizer``, ``word_tokenize``, ``sent_tokenize``, ``WhitespaceTokenizer``,
``blankline_tokenize``, ``RegexpTokenizer``, ``TweetTokenizer``.
"""

import re as _re

from lingora import _punkt

# ---------------------------------------------------------------- word/punct
# spec: N-000085 N-000086 N-000087 N-000371 N-000372 N-000379 N-000380 N-000385
_WORDPUNCT_RE = _re.compile(r"\w+|[^\w\s]+")


def _check_text(text):
    if not isinstance(text, str):
        raise TypeError("text must be a str")


class WordPunctTokenizer:
    """Maximal runs of word characters, and maximal runs of other non-space characters.

    # spec: N-000085 N-000086 N-000087
    """

    def tokenize(self, text):
        _check_text(text)
        return _WORDPUNCT_RE.findall(text)

    def span_tokenize(self, text):
        _check_text(text)
        for m in _WORDPUNCT_RE.finditer(text):  # spec: N-000119 N-000120 N-000121
            yield (m.start(), m.end())


def wordpunct_tokenize(text):
    return WordPunctTokenizer().tokenize(text)


# ------------------------------------------------------------- Treebank rules
# spec: N-000088 N-000089 N-000090 N-000091 N-000092 N-000093 N-000094 N-000095
# spec: N-000096 N-000097 N-000098
# Note: commas and colons are split as in the Treebank convention (not listed in
# the spec's enumerated list); see NOTES.md.
_TB_STARTING_DQ = _re.compile(r'([ (\[{<])"')
_TB_CLITICS_1 = _re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') ")
_TB_CLITICS_2 = _re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) ")
_TB_SEMI = _re.compile(r"([;@#$%&])")
_TB_QMARK = _re.compile(r"([?!])")
_TB_BRACKETS = _re.compile(r"([\]\[(){}<>])")
_TB_ELLIPSIS = _re.compile(r"\.\.\.")
_TB_COMMA_COLON = _re.compile(r"([:,])([^\d])")
_TB_COMMA_COLON_END = _re.compile(r"([:,])$")
_TB_FINAL_POINT = _re.compile(r"([^\.])(\.)([\]\)}>\"']*)\s*$")
_TB_CONTRACTIONS2 = [
    _re.compile(r"(?i)\b(can)(not)\b"),
    _re.compile(r"(?i)\b(d)('ye)\b"),
    _re.compile(r"(?i)\b(gim)(me)\b"),
    _re.compile(r"(?i)\b(gon)(na)\b"),
    _re.compile(r"(?i)\b(got)(ta)\b"),
    _re.compile(r"(?i)\b(lem)(me)\b"),
    _re.compile(r"(?i)\b(more)('n)\b"),
    _re.compile(r"(?i)\b(wan)(na)(?=\s)"),
]
_TB_CONTRACTIONS3 = [
    _re.compile(r"(?i) ('t)(is)\b"),
    _re.compile(r"(?i) ('t)(was)\b"),
]

# Recommended-tokenizer additions (FP-01).
_REC_TYPO_DQ = _re.compile(r"([“”„‟])")
_REC_TYPO_SQ = _re.compile(r"(?<!\w)([‘’])|([‘’])(?!\w)")
_REC_DASHES = _re.compile(r"([‒–—―])")
_REC_ASTERISK = _re.compile(r"(\*)")
_REC_POINTS = _re.compile(r"(\.{2,})")
_REC_DOUBLE_HYPHEN = _re.compile(r"(--)")


def _treebank_pipeline(text, recommended):
    s = " " + text + " "
    if recommended:
        s = _REC_TYPO_DQ.sub(r" \1 ", s)
        s = _REC_TYPO_SQ.sub(lambda m: " " + (m.group(1) or m.group(2)) + " ", s)
        s = _REC_DASHES.sub(r" \1 ", s)
        s = _REC_ASTERISK.sub(r" \1 ", s)
        s = _REC_POINTS.sub(r" \1 ", s)
        s = _REC_DOUBLE_HYPHEN.sub(r" \1 ", s)
    s = _TB_STARTING_DQ.sub(r"\1 `` ", s)
    s = s.replace('"', " '' ")
    s = _TB_SEMI.sub(r" \1 ", s)
    s = _TB_QMARK.sub(r" \1 ", s)
    s = _TB_BRACKETS.sub(r" \1 ", s)
    s = _TB_ELLIPSIS.sub(" ... ", s)
    s = _TB_COMMA_COLON.sub(r" \1 \2", s)
    s = _TB_COMMA_COLON_END.sub(r" \1 ", s)
    s = _TB_FINAL_POINT.sub(r"\1 \2\3 ", s)
    s = _TB_CLITICS_1.sub(r"\1 \2 ", s)
    s = _TB_CLITICS_2.sub(r"\1 \2 ", s)
    for pat in _TB_CONTRACTIONS2:
        s = pat.sub(r"\1 \2", s)
    for pat in _TB_CONTRACTIONS3:
        s = pat.sub(r" \1 \2", s)  # the match includes the preceding space
    return s.split()


class TreebankWordTokenizer:
    """Penn Treebank word tokenizer. # spec: N-000088 N-000089 N-000090 N-000091 N-000092"""

    def tokenize(self, text):
        _check_text(text)
        return _treebank_pipeline(text, recommended=False)


# ------------------------------------------------------------- recommended
def _recommended_one_line(text):
    # spec: N-000099 N-000100 N-000101 N-000102 N-000103
    return _treebank_pipeline(text, recommended=True)


def word_tokenize(text, language="english", preserve_line=False):
    """LINGORA's recommended word tokenizer. # spec: N-000099 N-000104 N-000105 N-000377 N-000378

    ``preserve_line=True`` treats ``text`` as one already-delimited line.
    ``preserve_line=False`` (default) first splits sentences with :func:`sent_tokenize`,
    which needs the Punkt models for ``language``.
    """
    _check_text(text)
    if preserve_line:
        sentences = [text]
    else:
        sentences = sent_tokenize(text, language)
    tokens = []
    for sentence in sentences:
        tokens.extend(_recommended_one_line(sentence))
    return tokens


def sent_tokenize(text, language="english"):
    """Punkt sentence tokenizer. # spec: N-000122 N-000123 N-000124 N-000125 N-000126 N-000130 N-000131
    Raises ``LookupError`` when the Punkt models for ``language`` are not visible."""
    _check_text(text)
    return _punkt.sentences(text, language)


# ----------------------------------------------------------- whitespace/blank
class WhitespaceTokenizer:
    """Maximal runs of non-whitespace characters. # spec: N-000106 N-000087"""

    _re = _re.compile(r"\S+")

    def tokenize(self, text):
        _check_text(text)
        return self._re.findall(text)

    def span_tokenize(self, text):
        _check_text(text)
        for m in self._re.finditer(text):
            yield (m.start(), m.end())


_BLANKLINE_RE = _re.compile(r"\s*\n\s*\n\s*")  # spec: N-000107 N-000108


def blankline_tokenize(text):
    """Segments separated by a blank line. # spec: N-000107 N-000108 N-000379 N-000381"""
    _check_text(text)
    pieces = _BLANKLINE_RE.split(text)
    return [p.strip() for p in pieces if p.strip()]


# ----------------------------------------------------------------- regexp
# spec: N-000109 N-000110 N-000111 N-000373 N-000374 N-000375 N-000376
class RegexpTokenizer:
    def __init__(self, pattern, gaps=False, discard_empty=True):
        if not isinstance(pattern, str):
            raise TypeError("pattern must be a str")
        if not isinstance(gaps, bool) or not isinstance(discard_empty, bool):
            raise TypeError("gaps and discard_empty must be bool")
        self.pattern = pattern
        self._re = _re.compile(pattern)
        self.gaps = gaps
        self.discard_empty = discard_empty

    def tokenize(self, text):
        _check_text(text)
        if self.gaps:
            pieces = []
            last = 0
            for m in self._re.finditer(text):
                pieces.append(text[last:m.start()])
                last = m.end()
            pieces.append(text[last:])
        else:
            pieces = [m.group(0) for m in self._re.finditer(text)]
        if self.discard_empty:
            pieces = [p for p in pieces if p]
        return pieces

    def span_tokenize(self, text):
        _check_text(text)
        if self.gaps:
            last = 0
            for m in self._re.finditer(text):
                if not self.discard_empty or m.start() > last:
                    yield (last, m.start())
                last = m.end()
            if not self.discard_empty or last < len(text):
                yield (last, len(text))
        else:
            for m in self._re.finditer(text):
                if not self.discard_empty or m.end() > m.start():
                    yield (m.start(), m.end())


# ------------------------------------------------------------------ tweets
# spec: N-000112 N-000113 N-000114 N-000115 N-000116 N-000117 N-000118
_EMOTICON = (
    r"(?:[<>]?[:;=8][\-o\*']?[\)\]\(\[dDpP/:\}\{@\|\\]"
    r"|[\)\]\(\[dDpP/:\}\{@\|\\][\-o\*']?[:;=8][<>]?"
    r"|<3)"
)
_HANDLE = r"(?<!\w)@[A-Za-z0-9_]{1,15}(?![A-Za-z0-9_])"
_TWEET_RE = _re.compile(
    r"|".join(
        [
            r"(?:https?://|www\.)\S+",
            _HANDLE,
            r"#\w+",
            _EMOTICON,
            r"\d+(?:[.,]\d+)+",
            r"\w+(?:['’]\w+)*",
            r"\.{2,}",
            r"[^\w\s]",
        ]
    )
)
_TWEET_EMOTICON_RE = _re.compile(_EMOTICON)
_HANDLE_RE = _re.compile(_HANDLE)


class TweetTokenizer:
    """Tweet-style tokenizer. # spec: N-000112 N-000114 N-000116 N-000117 N-000118"""

    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        for name, value in (
            ("preserve_case", preserve_case),
            ("reduce_len", reduce_len),
            ("strip_handles", strip_handles),
        ):
            if not isinstance(value, bool):
                raise TypeError(f"{name} must be bool")
        self.preserve_case = preserve_case
        self.reduce_len = reduce_len
        self.strip_handles = strip_handles

    def tokenize(self, text):
        _check_text(text)
        if self.strip_handles:
            text = _HANDLE_RE.sub(" ", text)
        if self.reduce_len:
            text = _re.sub(r"(.)\1{2,}", r"\1\1\1", text, flags=_re.DOTALL)
        tokens = _TWEET_RE.findall(text)
        if not self.preserve_case:
            tokens = [t if _TWEET_EMOTICON_RE.fullmatch(t) else t.lower() for t in tokens]
        return tokens
