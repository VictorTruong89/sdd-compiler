"""Punkt unsupervised sentence-boundary detection (Kiss and Strunk, 2006).

# spec: N-000122 N-000123 N-000124 N-000125 N-000126 N-000130 N-000131 N-000082 N-000025

Parameters are read from the packaged resource ``tokenizers/punkt_tab/<language>/``:
``abbrev_types.txt``, ``sent_starters.txt``, ``collocations.tab`` and ``ortho_context.tab``
(format in spec pack 06). The decision procedure is this module's own implementation of
the Punkt heuristics; see NOTES.md for the exact rules used.
"""

import os as _os
import re as _re
import threading as _threading

from lingora import data as _data

# Orthographic bit flags (spec pack 06).
ORTHO_UC_SENT_START = 2
ORTHO_UC_INSIDE = 4
ORTHO_UC_UNKNOWN = 8
ORTHO_LC_SENT_START = 16
ORTHO_LC_INSIDE = 32
ORTHO_LC_UNKNOWN = 64

_NUMBER_RE = _re.compile(r"-?[.,]?\d[\d,.\-]*")
_LEADING_OPEN = "\"'(`[{<“‘„«"
_TRAILING_CLOSE = "\"')]}>”’»"
_SENT_END = ".?!"

_cache = {}
_cache_lock = _threading.Lock()


class PunktParams:
    def __init__(self, abbrev_types, sent_starters, collocations, ortho_context):
        self.abbrev_types = abbrev_types
        self.sent_starters = sent_starters
        self.collocations = collocations
        self.ortho_context = ortho_context


def _read_optional(path):
    if not _os.path.isfile(path):
        return []
    return _data.read_lines(path)


def load_params(language):
    """Load (and cache per directory) the Punkt parameters for ``language``."""
    if not isinstance(language, str) or not _re.fullmatch(r"[A-Za-z][A-Za-z_\-]*", language):
        raise ValueError(f"invalid Punkt language name: {language!r}")
    directory = _data.require_dir(
        _os.path.join("tokenizers", "punkt_tab", language),
        f"Punkt sentence model for {language!r}",
    )
    key = _os.path.abspath(directory)
    with _cache_lock:
        cached = _cache.get(key)
    if cached is not None:
        return cached

    abbrev = {line.strip().lower() for line in _read_optional(_os.path.join(directory, "abbrev_types.txt")) if line.strip()}
    starters = {line.strip().lower() for line in _read_optional(_os.path.join(directory, "sent_starters.txt")) if line.strip()}
    colloc = set()
    for line in _read_optional(_os.path.join(directory, "collocations.tab")):
        parts = line.split("\t")
        if len(parts) == 2:
            colloc.add((parts[0].strip().lower(), parts[1].strip().lower()))
    ortho = {}
    for line in _read_optional(_os.path.join(directory, "ortho_context.tab")):
        parts = line.split("\t")
        if len(parts) == 2 and parts[1].strip().lstrip("-").isdigit():
            ortho[parts[0].strip().lower()] = int(parts[1].strip())

    params = PunktParams(abbrev, starters, colloc, ortho)
    with _cache_lock:
        _cache[key] = params
    return params


class _Tok:
    __slots__ = ("start", "end", "core", "first", "ends_sent", "typ")

    def __init__(self, start, end, raw):
        self.start = start
        self.end = end
        core = raw.rstrip(_TRAILING_CLOSE)
        self.core = core
        stripped = core.lstrip(_LEADING_OPEN)
        self.first = stripped[:1]
        self.ends_sent = core[-1:] if core[-1:] in _SENT_END else ""
        body = stripped[:-1] if self.ends_sent else stripped
        self.typ = body.lower()


def _ortho_start(params, word_lower, first_upper):
    """True / False / None: whether a capitalised word looks like a sentence start."""
    ctx = params.ortho_context.get(word_lower, 0)
    if first_upper:
        if ctx & ORTHO_UC_INSIDE:
            return False  # capitalised inside sentences too: a proper-noun-like word
        if ctx & ORTHO_LC_INSIDE:
            return True  # normally lower-case mid-sentence: capital here marks a start
    return None


def _breaks(params, tokens):
    """Decide, for each token, whether a sentence ends right after it."""
    n = len(tokens)
    breaks = [False] * n
    for i, tok in enumerate(tokens):
        if not tok.ends_sent:
            continue
        nxt = tokens[i + 1] if i + 1 < n else None
        if nxt is None:
            breaks[i] = True
            continue
        if tok.ends_sent in "?!":
            breaks[i] = True
            continue
        # a period-final token
        typ = tok.typ
        if _NUMBER_RE.fullmatch(typ):
            typ = "##number##"
        nxt_word = nxt.typ
        if (tok.typ, nxt_word) in params.collocations or (typ, nxt_word) in params.collocations:
            breaks[i] = False
            continue
        ellipsis = tok.core.endswith("...")
        is_initial = _re.fullmatch(r"[^\W\d_]", typ) is not None
        is_abbrev = typ in params.abbrev_types
        if is_abbrev or is_initial or ellipsis:
            # Abbreviations and initials only end a sentence on strong evidence.
            if nxt.first.isupper():
                starter = nxt_word in params.sent_starters
                ortho = _ortho_start(params, nxt_word, True)
                breaks[i] = bool(starter or ortho is True)
            else:
                breaks[i] = False
            continue
        # an ordinary sentence-final period
        if nxt.first.islower():
            breaks[i] = False
        else:
            breaks[i] = True
    return breaks


def sentences(text, language="english"):
    """Return the sentences of ``text`` as original substrings, in order."""
    params = load_params(language)
    spans = [(m.start(), m.end()) for m in _re.finditer(r"\S+", text)]
    if not spans:
        return []
    tokens = [_Tok(s, e, text[s:e]) for s, e in spans]
    breaks = _breaks(params, tokens)
    out = []
    first = 0
    for i, brk in enumerate(breaks):
        if brk:
            out.append(text[tokens[first].start:tokens[i].end])
            first = i + 1
    if first < len(tokens):
        out.append(text[tokens[first].start:tokens[-1].end])
    return out
