"""Stemmers (``lingora.stem``). Feature point FP-02.

Implemented: ``PorterStemmer`` (LINGORA default mode), ``LancasterStemmer``,
``SnowballStemmer`` for ``english`` (Porter2) and ``porter``, ``RegexpStemmer``.
Named in the interface but not implemented (their results are outside the spec):
``ARLSTem``, ``ARLSTem2`` (raise ``NotImplementedError`` on use), and
``SnowballStemmer`` for the other Snowball languages (raises ``NotImplementedError``
at construction). ``WordNetLemmatizer`` raises ``LookupError`` when WordNet is not visible,
otherwise ``NotImplementedError``. See NOTES.md.
"""

import re as _re

from lingora import data as _data

SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german", "hungarian",
    "italian", "norwegian", "porter", "portuguese", "romanian", "russian", "spanish", "swedish",
)  # spec: N-000393 N-000140

_VOWELS = "aeiou"


def _check_word(word):
    if not isinstance(word, str):
        raise TypeError("word must be a str")


# ==================================================================== Porter
_PORTER_IRREGULAR = {  # small built-in table (entries are the implementer's choice)
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli",
    "singly": "singl", "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas",
    "cosmos": "cosmos", "bias": "bias", "andes": "andes",
}


def _p_cons(word, i):
    ch = word[i]
    if ch in _VOWELS:
        return False
    if ch == "y":
        return i == 0 or not _p_cons(word, i - 1)
    return True


def _p_measure(stem):
    n = len(stem)
    m = 0
    i = 0
    while i < n and _p_cons(stem, i):
        i += 1
    while i < n:
        while i < n and not _p_cons(stem, i):
            i += 1
        if i >= n:
            break
        m += 1
        while i < n and _p_cons(stem, i):
            i += 1
    return m


def _p_has_vowel(stem):
    return any(not _p_cons(stem, i) for i in range(len(stem)))


def _p_double_cons(word):
    return len(word) >= 2 and word[-1] == word[-2] and _p_cons(word, len(word) - 1)


def _p_cvc(stem):
    """*o: stem ends consonant-vowel-consonant (final not w, x, y).
    Extension: a two-letter stem of vowel followed by consonant also counts."""
    if len(stem) == 2:
        return (not _p_cons(stem, 0)) and _p_cons(stem, 1) and stem[1] not in "wxy"
    if len(stem) < 3:
        return False
    return (_p_cons(stem, -3) and not _p_cons(stem, -2) and _p_cons(stem, -1)
            and stem[-1] not in "wxy")


def _p_longest(word, table):
    for suffix in sorted(table, key=len, reverse=True):
        if word.endswith(suffix):
            return suffix
    return None


_P2_TABLE = {
    "ational": "ate", "tional": "tion", "enci": "ence", "anci": "ance", "izer": "ize",
    "bli": "ble", "entli": "ent", "eli": "e", "ousli": "ous", "ization": "ize",
    "ation": "ate", "ator": "ate", "alism": "al", "iveness": "ive", "fulness": "ful",
    "ousness": "ous", "aliti": "al", "iviti": "ive", "biliti": "ble", "logi": "log",
    "fulli": "ful",
}
_P3_TABLE = {"icate": "ic", "ative": "", "alize": "al", "iciti": "ic", "ical": "ic", "ful": "", "ness": ""}
_P4_SUFFIXES = ("al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment",
                "ent", "ion", "ou", "ism", "ate", "iti", "ous", "ive", "ize")


def _p_step1a(w):
    if w.endswith("sses"):
        return w[:-2]
    if w.endswith("ies"):
        return w[:-1] if len(w) == 4 else w[:-2]  # extension: four-letter -ies -> -ie
    if w.endswith("ss"):
        return w
    if w.endswith("s"):
        return w[:-1]
    return w


def _p_step1b(w):
    # extension: at the start of step 1b, -ied -> -ie (four letters) or -i; rest skipped
    if w.endswith("ied"):
        return w[:-1] if len(w) == 4 else w[:-2]
    if w.endswith("eed"):
        stem = w[:-3]
        return stem + "ee" if _p_measure(stem) > 0 else w
    for suffix in ("ed", "ing"):
        if w.endswith(suffix):
            stem = w[: -len(suffix)]
            if not _p_has_vowel(stem):
                return w
            if stem.endswith(("at", "bl", "iz")):
                return stem + "e"
            if _p_double_cons(stem) and stem[-1] not in "lsz":
                return stem[:-1]
            if _p_measure(stem) == 1 and _p_cvc(stem):
                return stem + "e"
            return stem
    return w


def _p_step1c(w):
    # extension: final y -> i only after a consonant that is not the stem's first letter
    if w.endswith("y") and len(w) >= 3 and _p_cons(w, len(w) - 2):
        return w[:-1] + "i"
    return w


def _p_apply_table(w, table, min_measure):
    suffix = _p_longest(w, table)
    if suffix is None:
        return w
    stem = w[: -len(suffix)]
    if _p_measure(stem) > min_measure:
        return stem + table[suffix]
    return w


def _p_step2(w):
    # extension: -alli -> -al tried first (positive measure), then step 2 again
    if w.endswith("alli") and _p_measure(w[:-4]) > 0:
        return _p_step2(w[:-4] + "al")
    suffix = _p_longest(w, _P2_TABLE)
    if suffix == "logi":
        # extension: -logi -> -log when the part before -ogi has positive measure
        if _p_measure(w[:-3]) > 0:
            return w[:-4] + "log"
        return w
    return _p_apply_table(w, _P2_TABLE, 0)


def _p_step3(w):
    return _p_apply_table(w, _P3_TABLE, 0)


def _p_step4(w):
    suffix = None
    for s in sorted(_P4_SUFFIXES, key=len, reverse=True):
        if w.endswith(s):
            suffix = s
            break
    if suffix is None:
        return w
    stem = w[: -len(suffix)]
    if _p_measure(stem) > 1:
        if suffix == "ion" and not stem.endswith(("s", "t")):
            return w
        return stem
    return w


def _p_step5(w):
    if w.endswith("e"):
        stem = w[:-1]
        m = _p_measure(stem)
        if m > 1 or (m == 1 and not _p_cvc(stem)):
            return stem
        return w
    if w.endswith("ll") and _p_measure(w) > 1:
        return w[:-1]
    return w


_PORTER_LINGORA_STEPS = (_p_step1a, _p_step1b, _p_step1c, _p_step2, _p_step3, _p_step4, _p_step5)


class PorterStemmer:
    """Porter stemmer in its default (LINGORA extensions) mode. # spec: N-000145 N-000146 N-000147 N-000148 N-000149 N-000150

    ``stem(word, to_lowercase=True)``.
    """

    def stem(self, word, to_lowercase=True):
        _check_word(word)
        if not isinstance(to_lowercase, bool):
            raise TypeError("to_lowercase must be bool")
        w = word.lower() if to_lowercase else word
        if w in _PORTER_IRREGULAR:  # spec: N-000147
            return _PORTER_IRREGULAR[w]
        if len(w) <= 2:  # spec: N-000148 N-000149
            return w
        for step in _PORTER_LINGORA_STEPS:
            w = step(w)
        return w


# ================================================================= Lancaster
# Paice/Husk rule table (reconstructed; see NOTES.md). Rule format:
# reversed suffix letters, optional '*' (intact-only), remove-count digit,
# replacement letters, then '.' (terminal) or '>' (continue).
_LANCASTER_RULES = [
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>.", "cn1t.", "dd1.", "dei3y>.", "deec2ss.",
    "dee1.", "de2>.", "dooh4>.", "e1>.", "feil1v.", "fi2>.", "gni3>.", "gai3y.", "ga2>.",
    "gg1.", "ht*2.", "hsiug5ct.", "hsi3>.", "i*1.", "i1y>.", "j1d.", "juf1s.", "lbaifi6.",
    "ld1.", "nois4j>.", "noix4ct.", "pp1.", "rr1.", "ss0.",
]
_LANCASTER_PARSED = []
for _r in _LANCASTER_RULES:
    _m = _re.fullmatch(r"([a-z]+)(\*?)(\d)([a-z]*)(>?)\.", _r)
    # kind is "." (terminal) when no '>' flag is present, ">" (continue) otherwise
    _LANCASTER_PARSED.append((_m.group(1)[::-1], bool(_m.group(2)), int(_m.group(3)), _m.group(4), ">" if _m.group(5) else "."))


class LancasterStemmer:
    """Paice/Husk (Lancaster) stemmer. # spec: N-000161 N-000162"""

    def stem(self, word):
        _check_word(word)
        w = word.lower()
        intact = True
        while True:
            applied = False
            for suffix, needs_intact, remove, repl, kind in _LANCASTER_PARSED:
                if needs_intact and not intact:
                    continue
                if not w.endswith(suffix):
                    continue
                stem = w[:-remove] if remove else w
                # acceptability: remaining stem has at least two letters and a vowel (aeiouy)
                if len(stem) < 2 or not any(c in "aeiouy" for c in stem):
                    continue
                w = stem + repl
                intact = False
                applied = True
                if kind == ".":
                    return w
                break
            if not applied:
                return w


# ================================================================== Snowball
# Porter2 (Snowball "english"). # spec: N-000164 N-000165 N-000166
_VOW = "aeiouy"
_E2_EXC1 = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli",
    "singly": "singl", "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas",
    "cosmos": "cosmos", "bias": "bias", "andes": "andes",
}
_E2_EXC2 = {"inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed"}


def _e2_r1(w):
    for prefix in ("gener", "commun", "arsen"):
        if w.startswith(prefix):
            return len(prefix)
    for i in range(1, len(w)):
        if w[i] not in _VOW and w[i - 1] in _VOW:
            return i + 1
    return len(w)


def _e2_short_end(w):
    if len(w) >= 3 and w[-3] not in _VOW and w[-2] in _VOW and w[-1] not in _VOW and w[-1] not in "wxY":
        return True
    if len(w) == 2 and w[0] in _VOW and w[1] not in _VOW:
        return True
    return False


def _e2_ends_in(w, suffixes, region_start):
    for s in sorted(suffixes, key=len, reverse=True):
        if w.endswith(s):
            return s if len(w) - len(s) >= region_start else None
    return None


def porter2_stem(word):
    w = word.lower()
    if len(w) <= 2:
        return w
    if w in _E2_EXC1:
        return _E2_EXC1[w]
    # Mark consonantal y's as Y.
    chars = list(w)
    if chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in _VOW:
            chars[i] = "Y"
    w = "".join(chars)
    r1 = _e2_r1(w)
    r2 = r1 + _e2_r1(w[r1:]) if r1 < len(w) else len(w)
    # Step 0
    for s in ("'s'", "'s", "'"):
        if w.endswith(s):
            w = w[: -len(s)]
            break
    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith(("ied", "ies")):
        w = w[:-3] + ("i" if len(w) > 4 else "ie")
    elif w.endswith("s") and not w.endswith(("us", "ss")):
        if any(c in _VOW for c in w[:-2]):
            w = w[:-1]
    if w in _E2_EXC2:
        return w.replace("Y", "y")
    # Step 1b
    if w.endswith(("eed", "eedly")):
        s = "eedly" if w.endswith("eedly") else "eed"
        if len(w) - len(s) >= r1:
            w = w[: -len(s)] + "ee"
    else:
        s = next((x for x in ("ingly", "edly", "ing", "ed") if w.endswith(x)), None)
        if s is not None and any(c in _VOW for c in w[: -len(s)]):
            w = w[: -len(s)]
            if w.endswith(("at", "bl", "iz")):
                w += "e"
            elif w[-2:] in ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt"):
                w = w[:-1]
            elif r1 >= len(w) and _e2_short_end(w):  # R1 is null and the word is short
                w += "e"
    # Step 1c
    if len(w) > 2 and w[-1] in "yY" and w[-2] not in _VOW:
        w = w[:-1] + "i"
    # Step 2
    s = _e2_ends_in(w, ("tional", "enci", "anci", "abli", "entli", "izer", "ization", "ational",
                        "ation", "ator", "alism", "aliti", "alli", "fulness", "ousli", "ousness",
                        "iveness", "iviti", "biliti", "bli", "ogi", "fulli", "lessli", "li"), r1)
    if s is not None:
        if s == "li":
            if len(w) >= 3 and w[-3] in "cdeghkmnrt":
                w = w[:-2]
        elif s == "ogi":
            if len(w) >= 4 and w[-4] == "l":
                w = w[:-1]
        else:
            rep = {"tional": "tion", "enci": "ence", "anci": "ance", "abli": "able", "entli": "ent",
                   "izer": "ize", "ization": "ize", "ational": "ate", "ation": "ate", "ator": "ate",
                   "alism": "al", "aliti": "al", "alli": "al", "fulness": "ful", "ousli": "ous",
                   "ousness": "ous", "iveness": "ive", "iviti": "ive", "biliti": "ble", "bli": "ble",
                   "fulli": "ful", "lessli": "less"}[s]
            w = w[: -len(s)] + rep
    # Step 3
    s = _e2_ends_in(w, ("tional", "ational", "alize", "icate", "iciti", "ical", "ful", "ness", "ative"), r1)
    if s is not None:
        if s == "ative":
            if len(w) - len(s) >= r2:
                w = w[: -len(s)]
        else:
            rep = {"tional": "tion", "ational": "ate", "alize": "al", "icate": "ic", "iciti": "ic",
                   "ical": "ic", "ful": "", "ness": ""}[s]
            w = w[: -len(s)] + rep
    # Step 4
    s = _e2_ends_in(w, ("al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment",
                        "ent", "ism", "ate", "iti", "ous", "ive", "ize", "ion"), r2)
    if s is not None:
        if s == "ion":
            if len(w) >= 4 and w[-4] in "st":
                w = w[:-3]
        else:
            w = w[: -len(s)]
    # Step 5
    if w.endswith("e"):
        if len(w) - 1 >= r2 or (len(w) - 1 >= r1 and not _e2_short_end(w[:-1])):
            w = w[:-1]
    elif w.endswith("l") and len(w) - 1 >= r2 and w.endswith("ll"):
        w = w[:-1]
    return w.replace("Y", "y")


class _PorterOriginalSnowball:
    """Snowball 'porter' (original Porter algorithm) = the Porter stemmer above."""

    def stem(self, word):
        return PorterStemmer().stem(word)


class SnowballStemmer:
    """Snowball stemmer. # spec: N-000163 N-000164 N-000165 N-000166 N-000167 N-000171 N-000172 N-000173

    ``SnowballStemmer(language, ignore_stopwords=False)``. Implemented: ``english``, ``porter``.
    """

    def __init__(self, language, ignore_stopwords=False):
        if not isinstance(language, str) or language not in SNOWBALL_LANGUAGES:
            raise ValueError(f"unsupported Snowball language: {language!r}")  # spec: N-000171
        if not isinstance(ignore_stopwords, bool):
            raise TypeError("ignore_stopwords must be bool")
        self.language = language
        self.ignore_stopwords = ignore_stopwords
        self._stopwords = frozenset()
        if ignore_stopwords:
            found = _data.find(f"corpora/stopwords/{language}")  # spec: N-000172 N-000173
            if found is None:
                raise LookupError(f"stopwords list not visible for {language!r}")
            self._stopwords = frozenset(
                line.strip().lower() for line in _data.read_lines(found) if line.strip()
            )
        if language not in ("english", "porter"):
            raise NotImplementedError(f"Snowball algorithm for {language!r} is not implemented")

    def stem(self, word):
        _check_word(word)
        w = word.lower()
        if self.ignore_stopwords and w in self._stopwords:  # spec: N-000167
            return w
        if self.language == "porter":
            return _PorterOriginalSnowball().stem(w)
        return porter2_stem(w)


# ================================================================= Regexp
class RegexpStemmer:
    """Removes every match of ``regexp`` from the word. # spec: N-000168 N-000169 N-000170 N-000390 N-000392"""

    def __init__(self, regexp):
        if not isinstance(regexp, str):
            raise TypeError("regexp must be a str")
        self._re = _re.compile(regexp)

    def stem(self, word):
        _check_word(word)
        return self._re.sub("", word)


# ============================================================ outside spec
class ARLSTem:
    """Named in the interface; its stemming results are outside this specification."""

    def stem(self, word):  # spec: N-000136 N-000137
        raise NotImplementedError("ARLSTem is not implemented")


class ARLSTem2(ARLSTem):
    """Named in the interface; its stemming results are outside this specification."""


class WordNetLemmatizer:
    """Requires packaged WordNet. # spec: N-000174 N-000175 N-000135 N-000396

    Raises ``LookupError`` at construction when WordNet is not visible. The lemma
    lookup itself is not implemented (see NOTES.md)."""

    def __init__(self):
        if _data.find_dir("corpora/wordnet") is None and _data.find("corpora/wordnet") is None:
            raise LookupError("WordNet is not visible")

    def lemmatize(self, word):
        _check_word(word)
        raise NotImplementedError("WordNet lemmatization is not implemented")
