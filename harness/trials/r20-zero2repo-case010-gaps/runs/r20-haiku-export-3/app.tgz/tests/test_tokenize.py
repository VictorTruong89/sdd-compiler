import io
import sys

import pytest

from lingora import tokenize as T
from lingora.cli import cli


# spec: N-000085 N-000086 N-000087
def test_N_000085_wordpunct_runs(no_resources):
    assert T.wordpunct_tokenize("Hi, there!  It's 3.5") == ["Hi", ",", "there", "!", "It", "'", "s", "3", ".", "5"]


def test_N_000087_whitespace_never_in_token(no_resources):
    assert T.WordPunctTokenizer().tokenize("  \t\n ") == []


def test_N_000119_span_tokenize(no_resources):
    text = "a, bc"
    spans = list(T.WordPunctTokenizer().span_tokenize(text))
    assert [text[s:e] for s, e in spans] == ["a", ",", "bc"]
    assert all(spans[i][1] <= spans[i + 1][0] for i in range(len(spans) - 1))


# spec: N-000088 N-000089 N-000090 N-000091 N-000092 N-000093 N-000094 N-000096 N-000097
def test_N_000090_treebank_quotes_and_clitics(no_resources):
    tb = T.TreebankWordTokenizer().tokenize
    assert tb('"Hello," she said.') == ["``", "Hello", ",", "''", "she", "said", "."]
    assert tb('He said "hi"') == ["He", "said", "``", "hi", "''"]
    assert tb("They can't go") == ["They", "ca", "n't", "go"]
    assert tb("I'm here") == ["I", "'m", "here"]
    assert tb("We cannot") == ["We", "can", "not"]
    assert tb("gonna") == ["gon", "na"]


# spec: N-000093 N-000095
def test_N_000095_final_point_only(no_resources):
    assert T.TreebankWordTokenizer().tokenize("end of text.") == ["end", "of", "text", "."]
    assert T.TreebankWordTokenizer().tokenize("a. b") == ["a.", "b"]


# spec: N-000099 N-000100 N-000101 N-000102 N-000103 N-000105
def test_N_000100_recommended_extras(no_resources):
    tok = lambda s: T.word_tokenize(s, preserve_line=True)
    assert tok("“quoted”") == ["“", "quoted", "”"]
    assert tok("a--b c*d wait... x") == ["a", "--", "b", "c", "*", "d", "wait", "...", "x"]


# spec: N-000107 N-000108
def test_N_000107_blankline(no_resources):
    assert T.blankline_tokenize("one\ntwo\n\n  \nthree\n\n\nfour") == ["one\ntwo", "three", "four"]
    assert T.blankline_tokenize("   ") == []


# spec: N-000109 N-000110 N-000111
def test_N_000109_regexp_modes(no_resources):
    assert T.RegexpTokenizer(r"\w+").tokenize("a-b c") == ["a", "b", "c"]
    assert T.RegexpTokenizer(r"\s+", gaps=True).tokenize(" a  b ") == ["a", "b"]
    assert T.RegexpTokenizer(r"\s+", gaps=True, discard_empty=False).tokenize(" a") == ["", "a"]


# spec: N-000112 N-000113 N-000114 N-000116 N-000117 N-000118
def test_N_000114_tweet(no_resources):
    tt = T.TweetTokenizer
    assert tt().tokenize("Don't stop :) #fun @bob http://x.io/a") == ["Don't", "stop", ":)", "#fun", "@bob", "http://x.io/a"]
    assert tt(preserve_case=False).tokenize("HELLO :D") == ["hello", ":D"]
    assert tt(strip_handles=True).tokenize("hi @bob there") == ["hi", "there"]
    assert tt(strip_handles=True).tokenize("hi@bob x") == ["hi", "@", "bob", "x"]
    assert tt(reduce_len=True).tokenize("woooooow") == ["wooow"]
    assert tt().tokenize("café naïve") == ["café", "naïve"]


# spec: N-000129
def test_N_000129_empty_inputs_no_model(no_resources):
    assert T.wordpunct_tokenize("") == []
    assert T.wordpunct_tokenize("   ") == []
    assert T.WhitespaceTokenizer().tokenize("   ") == []
    assert T.TreebankWordTokenizer().tokenize("") == []


# spec: N-000122 N-000123 N-000124 N-000125 N-000126 N-000130 N-000131
def test_N_000122_sentences(resources):
    assert T.sent_tokenize("Hello world. This is a test.") == ["Hello world.", "This is a test."]
    assert T.sent_tokenize("Dr. Smith went home. He was tired.") == ["Dr. Smith went home.", "He was tired."]
    assert T.sent_tokenize("I met Mr. Jones today. The meeting went well.") == [
        "I met Mr. Jones today.", "The meeting went well."]
    assert T.sent_tokenize("Is it done? Yes. Really?") == ["Is it done?", "Yes.", "Really?"]
    assert T.sent_tokenize("  ") == []
    assert T.sent_tokenize("One sentence only") == ["One sentence only"]


def test_N_000130_sentences_need_model(no_resources):
    with pytest.raises(LookupError):
        T.sent_tokenize("A. B.")
    with pytest.raises(LookupError):
        T.word_tokenize("A. B.")
    assert T.word_tokenize("A b.", preserve_line=True) == ["A", "b", "."]


# spec: N-000099 N-000104 N-000105
def test_N_000104_word_tokenize_splits_sentences(resources):
    assert T.word_tokenize("Good muffins cost $3.88 in New York. Thanks.") == [
        "Good", "muffins", "cost", "$", "3.88", "in", "New", "York", ".", "Thanks", "."]


# spec: N-000382 N-000383 N-000384 N-000385 N-000386
def test_N_000382_cli_tokenize(resources, monkeypatch, capsys):
    monkeypatch.setattr(sys, "stdin", io.StringIO("Hello world. Bye.\n\nSecond line\n"))
    assert cli.main(args=["tokenize"], standalone_mode=False) == 0
    assert capsys.readouterr().out == "Hello world . Bye .\n\nSecond line\n"


def test_N_000386_cli_failure_writes_no_line(no_resources, monkeypatch, capsys):
    monkeypatch.setattr(sys, "stdin", io.StringIO("A. B.\n"))
    assert cli.main(args=["tokenize"], standalone_mode=False) != 0
    assert capsys.readouterr().out == ""


def test_N_000388_cli_delimiter(resources, monkeypatch, capsys):
    monkeypatch.setattr(sys, "stdin", io.StringIO("a b\n"))
    assert cli.main(args=["tokenize", "--delimiter", "|"], standalone_mode=False) == 0
    assert capsys.readouterr().out == "a|b\n"


# spec: N-000097
def test_N_000097_fused_forms_split(no_resources):
    assert T.TreebankWordTokenizer().tokenize("'tis the 'twas") == ["'t", "is", "the", "'t", "was"]
    assert T.TreebankWordTokenizer().tokenize("d'ye gimme") == ["d", "'ye", "gim", "me"]
