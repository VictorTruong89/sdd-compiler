import pytest

from lingora.chunk import RegexpParser
from lingora.tag import DefaultTagger, RegexpTagger, UnigramTagger, pos_tag


# spec: N-000187 N-000185 N-000186
def test_N_000187_default_tagger():
    assert DefaultTagger("NN").tag(["a", "b"]) == [("a", "NN"), ("b", "NN")]
    assert DefaultTagger("NN").tag([]) == []


# spec: N-000188 N-000190
def test_N_000188_unigram_most_frequent_and_unseen():
    train = [[("the", "DT"), ("run", "NN")], [("run", "VB"), ("run", "VB")]]
    t = UnigramTagger(train)
    assert t.tag(["the", "run", "zzz"]) == [("the", "DT"), ("run", "VB"), ("zzz", None)]


# spec: N-000194 N-000195
def test_N_000194_backoff_only_for_untagged():
    t = UnigramTagger([[("dog", "NN")]], backoff=DefaultTagger("X"))
    assert t.tag(["dog", "cat"]) == [("dog", "NN"), ("cat", "X")]


# spec: N-000191 N-000192 N-000193
def test_N_000191_regexp_tagger_first_match_at_start():
    t = RegexpTagger([(r".*ing$", "VBG"), (r"\d+", "CD"), (r".*", "NN")])
    assert t.tag(["running", "42", "cat"]) == [("running", "VBG"), ("42", "CD"), ("cat", "NN")]
    assert RegexpTagger([(r"\d", "CD")]).tag(["x1"]) == [("x1", None)]


# spec: N-000406 N-000407 N-000409
def test_N_000406_pos_tag_argument_errors(resources):
    with pytest.raises(TypeError):
        pos_tag("a sentence")
    with pytest.raises(ValueError):
        pos_tag(["a"], lang="fra")


def test_N_000407_pos_tag_missing_model(no_resources):
    with pytest.raises(LookupError):
        pos_tag(["a"])


def test_N_000196_pos_tag_perceptron(resources):
    out = pos_tag(["the", "dog", "barks"])
    assert out[0] == ("the", "DT") and out[1] == ("dog", "NN")
    assert len(out) == 3 and all(isinstance(t, str) for _, t in out)


def test_N_000215_universal_tagset(resources):
    assert pos_tag(["the", "dog"], tagset="universal") == [("the", "DET"), ("dog", "NOUN")]


def test_N_000215_universal_tables_missing(monkeypatch, tmp_path):
    from lingora import data
    monkeypatch.setattr(data, "path", [str(tmp_path)])
    from lingora import tag as T
    T._universal_cache.clear()
    T._perceptron_cache.clear()
    with pytest.raises(LookupError):
        pos_tag(["x"], tagset="universal")


# spec: N-000415 N-000416 N-000417 N-000418 N-000419 N-000421 N-000422 N-000423
def test_N_000418_chunk_np_and_cascade():
    grammar = "NP: {<DT>?<JJ>*<NN.*>+}\n  {<PRP>}\nVP: {<VB.*><NP|PRP>*}"
    tagged = [("the", "DT"), ("big", "JJ"), ("dog", "NN"), ("chased", "VBD"), ("it", "PRP"), (".", ".")]
    tree = RegexpParser(grammar).parse(tagged)
    assert tree.label() == "S"
    assert [c.label() for c in tree if hasattr(c, "label")] == ["NP", "VP", ]
    assert tree.leaves() == tagged


def test_N_000422_chink_splits_chunk():
    tree = RegexpParser("NP: {<.*>+}\n  }<VBD>{").parse(
        [("the", "DT"), ("dog", "NN"), ("chased", "VBD"), ("cat", "NN")])
    labels = [c.label() if hasattr(c, "label") else c for c in tree]
    assert labels[0] == "NP" and labels[2] == "NP"
    assert tree[1] == ("chased", "VBD")


def test_N_000226_tokens_keep_order_and_tags():
    tagged = [("a", "DT"), ("b", "NN")]
    assert RegexpParser("NP: {<NN>}").parse(tagged).leaves() == tagged


def test_N_000416_grammar_errors():
    with pytest.raises(ValueError):
        RegexpParser("")
    with pytest.raises(ValueError):
        RegexpParser("not a clause")
