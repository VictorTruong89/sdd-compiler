import pytest

from lingora import classify as C
from lingora import metrics as M
from lingora.translate import bleu


DATA = [({"a": 1, "b": "x"}, "pos"), ({"a": 0, "b": "y"}, "neg"),
        ({"a": 1, "b": "y"}, "pos"), ({"a": 0, "b": "x"}, "neg")]


# spec: N-000277 N-000279 N-000280 N-000281 N-000282 N-000455 N-000456
def test_N_000277_naive_bayes():
    nb = C.NaiveBayesClassifier.train(DATA)
    assert nb.classify({"a": 1, "b": "x"}) == "pos"
    assert nb.classify({"a": 0, "b": "y"}) == "neg"
    dist = nb.prob_classify({"a": 1})
    assert abs(sum(dist.prob(l) for l in dist.samples()) - 1.0) < 1e-9
    assert sorted(nb.labels()) == ["neg", "pos"]
    assert isinstance(dist.prob("pos"), float)


# spec: N-000283 N-000285 N-000286 N-000287
def test_N_000283_decision_tree_separates():
    data = [({"a": 1}, "p"), ({"a": 0}, "n"), ({"a": 1, "b": 2}, "p")]
    dt = C.DecisionTreeClassifier.train(data)
    assert [dt.classify(fs) for fs, _ in data] == ["p", "n", "p"]


def test_N_000283_decision_tree_absent_feature_is_no_value():
    dt = C.DecisionTreeClassifier.train([({"a": 1}, "p"), ({"a": 0}, "n")])
    assert dt.classify({}) in ("p", "n")


# spec: N-000287 N-000288
def test_N_000287_accuracy_helper():
    nb = C.NaiveBayesClassifier.train(DATA)
    assert C.accuracy(nb, DATA) == 1.0


# spec: N-000464 N-000465 N-000466 N-000292 N-000293 N-000294 N-000298 N-000299 N-000315
def test_N_000292_edit_distance():
    assert M.edit_distance("kitten", "sitting") == 3
    assert M.edit_distance("abc", "abc") == 0
    assert M.edit_distance("ab", "ba") == 2
    assert M.edit_distance("", "") == 0
    assert M.edit_distance("abc", "xyz", substitution_cost=2) == 6
    assert M.edit_distance("ab", "abx") == M.edit_distance("abx", "ab")
    with pytest.raises(ValueError):
        M.accuracy([1], [1, 2])


# spec: N-000295 N-000296 N-000297
def test_N_000295_damerau_transpositions():
    assert M.edit_distance("ab", "ba", transpositions=True) == 1
    assert M.edit_distance("ca", "abc", transpositions=True) == 2
    assert M.edit_distance("ca", "abc") == 3


# spec: N-000300 N-000301 N-000311 N-000312 N-000313 N-000314 N-000469
def test_N_000300_sets_metrics():
    assert M.precision({1, 2}, {2, 3}) == 0.5
    assert M.recall({1, 2}, {2, 3}) == 0.5
    assert M.f_measure({1, 2}, {2, 3}) == 0.5
    assert M.precision({1}, set()) is None
    assert M.recall(set(), {1}) is None
    assert M.f_measure({1}, set()) is None
    assert M.f_measure({1}, {2}) == 0.0
    with pytest.raises(TypeError):
        M.precision([1], {1})
    assert M.jaccard_distance({1, 2}, {2, 3}) == pytest.approx(2 / 3)


def test_N_000464_accuracy_metric():
    assert M.accuracy(["a", "b"], ["a", "c"]) == 0.5


# spec: N-000302 N-000303 N-000304 N-000306 N-000307 N-000308 N-000473 N-000474
def test_N_000302_bleu():
    ref = [["the", "cat", "is", "on", "the", "mat"]]
    assert bleu(ref, ["the", "cat", "is", "on", "the", "mat"]) == pytest.approx(1.0)
    assert bleu(ref, ["a"]) == 0.0
    short = bleu(ref, ["the", "cat", "is", "on", "the"])
    assert 0 < short < 1
    assert bleu(ref, ["the", "cat", "sat", "on", "the", "mat"]) == 0.0
    # unigram-only: precision 2/2, brevity penalty exp(1 - 6/2) = exp(-2)
    import math
    assert bleu(ref, ["the", "cat"], weights=(1,)) == pytest.approx(math.exp(1 - 6 / 2))
    with pytest.raises(TypeError):
        bleu(ref, "the cat")
