"""Shared fixtures: synthetic packaged-resource directories in the layout the spec names.

These are small invented models for testing the code paths; they are not LINGORA's
published data (which is not in this repository)."""

import json
import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from lingora import data  # noqa: E402


def _write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)


@pytest.fixture
def resources(tmp_path, monkeypatch):
    """Point ``lingora.data.path`` at a fixture directory holding every packaged resource used."""
    root = str(tmp_path / "lingora_data")
    punkt = os.path.join(root, "tokenizers", "punkt_tab", "english")
    _write(os.path.join(punkt, "abbrev_types.txt"), "dr\nmr\nmrs\netc\ne.g\nvs\n")
    _write(os.path.join(punkt, "sent_starters.txt"), "the\nhe\nshe\nit\nthis\nthey\n")
    _write(os.path.join(punkt, "collocations.tab"), "st.\tjohn\n")
    _write(os.path.join(punkt, "ortho_context.tab"),
           "he\t16\nsmith\t4\nthe\t16\nwent\t32\nwas\t32\nhome\t32\n")
    _write(os.path.join(root, "taggers", "universal_tagset", "en-ptb.map"),
           "NN\tNOUN\nVBD\tVERB\nDT\tDET\nJJ\tADJ\n.\t.\n")
    eng = os.path.join(root, "taggers", "averaged_perceptron_tagger_eng")
    _write(os.path.join(eng, "averaged_perceptron_tagger_eng.weights.json"),
           json.dumps({"bias": {"DT": 1.0}, "i word=the": {"DT": 2.0}}))
    _write(os.path.join(eng, "averaged_perceptron_tagger_eng.tagdict.json"),
           json.dumps({"the": "DT", "dog": "NN"}))
    _write(os.path.join(eng, "averaged_perceptron_tagger_eng.classes.json"),
           json.dumps(["DT", "NN", "VBD", "JJ", "."]))
    _write(os.path.join(root, "corpora", "stopwords", "english"), "the\na\nof\n")
    monkeypatch.setattr(data, "path", [root])
    return root


@pytest.fixture
def no_resources(monkeypatch):
    monkeypatch.setattr(data, "path", [])
