import pytest

from lingora import data
from lingora.tree import Tree


# spec: N-000444 N-000446 N-000447 N-000448 N-000449 N-000450 N-000451
def test_N_000444_tree_basics():
    t = Tree("S", [Tree("NP", ["the", "dog"]), "barks"])
    assert t.label() == "S"
    assert len(t) == 2
    assert t[1] == "barks"
    assert t.leaves() == ["the", "dog", "barks"]
    assert t == Tree("S", [Tree("NP", ["the", "dog"]), "barks"])
    assert t != Tree("S", ["barks"])


def test_N_000449_children_must_be_list():
    with pytest.raises(TypeError):
        Tree("S", "abc")
    with pytest.raises(TypeError):
        Tree("S")
    assert Tree("S", []).leaves() == []
    assert len(Tree("S", [])) == 0


# spec: N-000452 N-000260
def test_N_000452_fromstring_round_trip():
    t = Tree.fromstring("(S (NP the dog) (VP barks))")
    assert t == Tree("S", [Tree("NP", ["the", "dog"]), Tree("VP", ["barks"])])
    assert t.leaves() == ["the", "dog", "barks"]
    assert Tree.fromstring(t.pformat()) == t


# spec: N-000261 N-000453
def test_N_000453_pformat_preorder():
    assert Tree.fromstring("(S (A x) (B y))").pformat().startswith("(S")
    assert Tree.fromstring("(S (A x) (B y))").pformat().index("x") < Tree.fromstring("(S (A x) (B y))").pformat().index("y")


# spec: N-000353 N-000354 N-000356
def test_N_000353_data_path_mutable(resources, no_resources):
    assert isinstance(data.path, list)
    assert data.find("corpora/words") is None
    data.path[:] = [resources]
    assert data.find("corpora/stopwords/english") is not None
    data.path[:] = []
    assert data.find("corpora/stopwords/english") is None


# spec: N-000338 N-000344 (importing downloads nothing)
def test_import_downloads_nothing(no_resources):
    import importlib
    import lingora
    importlib.reload(lingora)
    assert lingora.data is data
