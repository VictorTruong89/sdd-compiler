import pytest

from lingora.stem import LancasterStemmer, PorterStemmer, RegexpStemmer, SnowballStemmer, WordNetLemmatizer


# spec: N-000145 N-000146 N-000148 N-000149 N-000150 N-000151
def test_N_000145_porter_default_mode():
    p = PorterStemmer()
    assert p.stem("caresses") == "caress"
    assert p.stem("ponies") == "poni"
    assert p.stem("ties") == "tie"
    assert p.stem("relational") == "relat"
    assert p.stem("running") == "run"
    assert p.stem("generously") == "gener"
    assert p.stem("CATS") == "cat"
    # with lowercasing off the rules see upper-case letters and do not match
    assert p.stem("CATS", to_lowercase=False) == "CATS"


# spec: N-000148 N-000149
def test_N_000148_short_words_untouched():
    assert PorterStemmer().stem("as") == "as"
    assert PorterStemmer().stem("I") == "i"


# spec: N-000147
def test_N_000147_irregular_table():
    assert PorterStemmer().stem("dying") == "die"


# spec: N-000161 N-000162
def test_N_000161_lancaster_lowercases_and_stems():
    s = LancasterStemmer()
    assert s.stem("Saying") == "say"
    assert s.stem("Crying") == "cry"
    assert s.stem("owed") == "ow"


# spec: N-000164 N-000165 N-000166
def test_N_000165_snowball_english():
    s = SnowballStemmer("english")
    assert s.stem("running") == "run"
    assert s.stem("generously") == "generous"
    assert s.stem("communism") == "communism"
    assert s.stem("skies") == "sky"
    assert s.stem("Hopping") == "hop"


# spec: N-000167 N-000172 N-000173
def test_N_000172_stopword_list_required(no_resources):
    with pytest.raises(LookupError):
        SnowballStemmer("english", ignore_stopwords=True)


def test_N_000167_stopword_skip_with_list(resources):
    assert SnowballStemmer("english", ignore_stopwords=True).stem("The") == "the"
    assert SnowballStemmer("english", ignore_stopwords=True).stem("running") == "run"


# spec: N-000171 N-000393 N-000394
def test_N_000171_unsupported_language():
    with pytest.raises(ValueError):
        SnowballStemmer("klingon")


# spec: N-000168 N-000169 N-000170
def test_N_000168_regexp_stemmer():
    assert RegexpStemmer(r"ing$").stem("running") == "runn"
    assert RegexpStemmer(r"s$").stem("cat") == "cat"


# spec: N-000174 N-000175 N-000396
def test_N_000174_wordnet_needs_resource(no_resources):
    with pytest.raises(LookupError):
        WordNetLemmatizer()
