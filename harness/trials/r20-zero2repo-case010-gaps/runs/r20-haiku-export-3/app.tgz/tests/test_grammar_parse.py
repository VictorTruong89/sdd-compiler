import pytest

from lingora.grammar import CFG, Nonterminal
from lingora.parse import ChartParser, ShiftReduceParser
from lingora.parse.generate import generate

GRAMMAR = """
S -> NP VP
NP -> Det N | 'John'
VP -> V NP
Det -> 'the' | 'a'
N -> 'man' | 'dog'
V -> 'saw'
"""


# spec: N-000427 N-000428 N-000429 N-000430 N-000432 N-000433 N-000434
def test_N_000427_cfg_reader():
    g = CFG.fromstring(GRAMMAR)
    assert str(g.start()) == "S"
    assert len(g.productions()) == 9
    np_prod = g.productions(lhs=Nonterminal("NP"))[0]
    assert isinstance(np_prod.rhs()[0], Nonterminal) and str(np_prod.rhs()[0]) == "Det"
    assert g.productions(lhs="NP")[1].rhs() == ("John",)


def test_N_000440_empty_production():
    g = CFG.fromstring("S -> A\nA -> 'x' |")
    assert [p.rhs() for p in g.productions(lhs="A")] == [("x",), ()]


# spec: N-000242 N-000243 N-000244 N-000245 N-000436
def test_N_000242_chart_parser_trees_and_empty():
    g = CFG.fromstring(GRAMMAR)
    trees = list(ChartParser(g).parse("John saw the man".split()))
    assert len(trees) == 1
    assert trees[0].label() == "S" and trees[0].leaves() == "John saw the man".split()
    assert list(ChartParser(g).parse("saw John".split())) == []


def test_N_000242_chart_parser_ambiguous():
    g = CFG.fromstring("S -> A | B\nA -> 'x'\nB -> 'x'")
    assert len(list(ChartParser(g).parse(["x"]))) == 2


# spec: N-000266 N-000438 N-000439
def test_N_000266_uncovered_token_raises():
    g = CFG.fromstring(GRAMMAR)
    with pytest.raises(ValueError):
        ChartParser(g).parse(["zebra"])


# spec: N-000247 N-000248 N-000249 N-000250
def test_N_000247_shift_reduce_matches_chart_on_unambiguous():
    g = CFG.fromstring(GRAMMAR)
    toks = "John saw a dog".split()
    sr = list(ShiftReduceParser(g).parse(toks))
    ch = list(ChartParser(g).parse(toks))
    assert len(sr) == 1 and sr[0] == ch[0]
    assert list(ShiftReduceParser(g).parse(["John", "John"])) == []


# spec: N-000251 N-000252 N-000253 N-000254 N-000440 N-000441
def test_N_000251_generator_bounds():
    g = CFG.fromstring(GRAMMAR)
    sentences = list(generate(g, depth=6, n=3))
    assert len(sentences) == 3
    assert all(isinstance(t, str) for s in sentences for t in s)
    assert ["John", "saw", "John"] in list(generate(g, depth=3))
    assert list(generate(g, depth=2)) == []
