"""Tests named after spec node ids that the main suite covers only indirectly."""

import ast
import collections
import glob
import os
import sys
import types
import unittest
from decimal import Decimal

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

import pathsel  # noqa: E402
from pathsel import (  # noqa: E402
    EmptyExpressionError,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    PathSelSyntaxError,
    PathSelTokenSyntaxError,
    UnknownFunctionError,
    ZeroSliceStepError,
    compile as pathsel_compile,
    search,
)
from pathsel.functions import Functions, signature  # noqa: E402

PKG = os.path.join(ROOT, "pathsel")


def _package_sources():
    return {path: open(path, encoding="utf-8").read() for path in glob.glob(os.path.join(PKG, "*.py"))}


class TestEntriesAndDocuments(unittest.TestCase):
    def test_N_000004_N_000005_search_and_compile_entries(self):
        self.assertEqual(search("a.b", {"a": {"b": 2}}), 2)
        self.assertEqual(pathsel_compile("a.b").search({"a": {"b": 2}}), 2)

    def test_N_000007_both_paths_same_value(self):
        doc = {"xs": [1, 2, 3]}
        self.assertEqual(search("xs[*]", doc), pathsel_compile("xs[*]").search(doc))

    def test_N_000008_N_000009_options_are_optional_and_control_output(self):
        opts = types.SimpleNamespace(dict_cls=collections.OrderedDict, custom_functions=None)
        self.assertIsInstance(search("{a: `1`}", {}, opts), collections.OrderedDict)
        self.assertIs(type(search("{a: `1`}", {})), dict)

    def test_N_000014_expression_is_unicode_text(self):
        self.assertEqual(search("'é'", {}), "é")
        self.assertEqual(search('"é"', {"é": 1}), 1)

    def test_N_000015_document_may_nest_any_combination_of_types(self):
        doc = {"a": [1, "s", True, None, {"b": [2.5]}], "d": Decimal("1.5")}
        self.assertEqual(search("a[4].b[0]", doc), 2.5)
        self.assertEqual(search("d", doc), Decimal("1.5"))

    def test_N_000016_N_000017_N_000018_entries_and_parsed_reuse(self):
        parsed = pathsel_compile("x")
        self.assertEqual(parsed.search({"x": 1}), 1)
        self.assertEqual(parsed.search({"x": 2}), 2)
        self.assertEqual(search("x", {"x": 3}), 3)

    def test_N_000021_null_for_missing(self):
        self.assertIsNone(search("nope", {}))

    def test_N_000024_decimal_numbers_participate_in_comparisons(self):
        self.assertTrue(search("d >= `1`", {"d": Decimal("1.5")}))
        self.assertTrue(search("d < `2`", {"d": Decimal("1.5")}))

    def test_N_000025_boolean_is_not_a_number(self):
        self.assertIsNone(search("flag < `2`", {"flag": True}))
        self.assertFalse(search("flag == `1`", {"flag": True}))

    def test_N_000027_zero_not_equal_false(self):
        self.assertFalse(search("zero == `false`", {"zero": 0}))

    def test_N_000029_zero_is_a_true_value(self):
        self.assertEqual(search("zero && 'x'", {"zero": 0}), "x")
        self.assertEqual(search("zero || 'x'", {"zero": 0}), 0)

    def test_N_000339_N_000340_builtin_names_keep_builtin_behaviour(self):
        class Shadow(Functions):
            @signature({"types": ["number"]})
            def _func_abs(self, value):
                return "shadowed"

        opts = types.SimpleNamespace(dict_cls=None, custom_functions=Shadow())
        self.assertEqual(search("abs(`-4`)", {}, opts), 4)

    def test_N_000032_options_add_mapping_and_functions(self):
        class P(Functions):
            @signature({"types": ["string"]})
            def _func_twice(self, text):
                return text * 2

        opts = types.SimpleNamespace(dict_cls=None, custom_functions=P())
        self.assertEqual(search("twice('ab')", {}, opts), "abab")

    def test_N_000039_N_000067_N_000366_no_command_line_surface(self):
        self.assertFalse(os.path.exists(os.path.join(PKG, "__main__.py")))
        self.assertFalse(hasattr(pathsel, "main"))

    def test_N_000040_N_000041_missing_paths_null_in_both_entries(self):
        self.assertIsNone(search("a.b.c", {}))
        self.assertIsNone(pathsel_compile("a.b.c").search({}))

    def test_N_000042_ill_formed_text_does_not_succeed(self):
        for text in ["a..", "a b", "(a"]:
            with self.assertRaises(ValueError):
                search(text, {})

    def test_N_000043_N_000044_N_000045_N_000046_N_000047_N_000048_surface(self):
        doc = {"a": {"b": 1}, "xs": [1, 2], "ys": [{"v": 1}, {"v": None}]}
        self.assertEqual(search("a.b", doc), 1)
        self.assertEqual(search("xs[-1]", doc), 2)
        self.assertEqual(search("ys[*].v", doc), [1])
        self.assertEqual(search("{k: a.b}.k", doc), 1)
        self.assertTrue(search("a.b == `1` && xs", doc))
        self.assertEqual(search("length(xs)", doc), 2)

    def test_N_000049_options_surface(self):
        opts = types.SimpleNamespace(dict_cls=collections.OrderedDict, custom_functions=None)
        self.assertIsInstance(search("{x: `1`}", {}, opts), collections.OrderedDict)

    def test_N_000068_not_a_json_decoder(self):
        self.assertEqual(search("@", '{"a": 1}'), '{"a": 1}')


class TestFailureSurface(unittest.TestCase):
    def test_N_000052_python39_syntax(self):
        for path, source in _package_sources().items():
            ast.parse(source, filename=path, feature_version=(3, 9))

    def test_N_000054_cpu_only_no_accelerator_imports(self):
        for path, source in _package_sources().items():
            for banned in ("torch", "numpy", "cupy", "ctypes", "cffi"):
                self.assertNotIn("import " + banned, source, path)

    def test_N_000062_refusals_are_failures_not_null(self):
        with self.assertRaises(ValueError):
            search("a b", {})

    def test_N_000063_N_000064_each_failure_is_its_kind(self):
        self.assertIsInstance(_raised("", ""), EmptyExpressionError)
        self.assertIsInstance(_raised("a |", ""), IncompleteExpressionError)
        self.assertIsInstance(_raised("a b", ""), PathSelSyntaxError)
        self.assertIsInstance(_raised("a-b", ""), PathSelTokenSyntaxError)
        self.assertIsInstance(_raised("arr[::0]", ""), ZeroSliceStepError)
        self.assertIsInstance(_raised("nope(`1`)", ""), UnknownFunctionError)
        self.assertIsInstance(_raised("abs()", ""), InvalidArityError)
        self.assertIsInstance(_raised("abs(`'x'`)", ""), InvalidTypeError)

    def test_N_000065_position_for_syntax_and_incomplete(self):
        self.assertEqual(_raised("a b", "").lex_position, 2)
        self.assertEqual(_raised("a |", "").lex_position, 3)

    def test_N_000103_two_offsets_report_two_positions(self):
        self.assertNotEqual(_raised("a b", "").lex_position, _raised("a  c d", "").lex_position)

    def test_N_000406_kind_is_type_of_exception(self):
        kinds = {type(_raised(text, "")) for text in ["", "a |", "a b", "a-b", "arr[::0]"]}
        self.assertEqual(len(kinds), 5)

    def test_N_000420_no_other_kind_is_function_kind(self):
        for text in ["", "a |", "a b", "a-b", "arr[::0]"]:
            error = _raised(text, "")
            self.assertNotIsInstance(error, (UnknownFunctionError, InvalidArityError, InvalidTypeError))

    def test_N_000368_no_config_or_file_io_in_package(self):
        for path, source in _package_sources().items():
            self.assertNotIn("open(", source, path)


class TestProjectionsAndSpecifics(unittest.TestCase):
    def test_N_000164_object_wildcard_iteration_order(self):
        self.assertEqual(search("*", {"z": 1, "a": 2, "m": 3}), [1, 2, 3])

    def test_N_000175_N_000176_N_000177_N_000178_predicate_forms(self):
        doc = {"xs": [{"v": 1, "t": True}, {"v": 2, "t": False}, {"v": 0}]}
        self.assertEqual(search("xs[?t].v", doc), [1])
        self.assertEqual(search("xs[?`1` == v].v", doc), [1])
        self.assertEqual(search("xs[?v > `0` && t].v", doc), [1])
        self.assertEqual(search("xs[?v == `0` || t].v", doc), [1, 0])

    def test_N_000182_projection_reach(self):
        doc = {"xs": [{"ys": [1, 2]}, {"ys": [3]}]}
        self.assertEqual(search("xs[*].ys[0]", doc), [1, 3])

    def test_N_000191_later_step_not_tighter_applies_to_array(self):
        self.assertIsNone(search("a.*.b.c", {"a": {"x": {"b": {"c": 1}}}}))

    def test_N_000196_comparison_ends_projection(self):
        self.assertFalse(search("xs[*].v == `2`", {"xs": [{"v": 1}, {"v": 2}]}))

    def test_N_000203_filter_with_missing_predicate_does_not_succeed(self):
        with self.assertRaises(ValueError):
            search("xs[?]", {})

    def test_N_000202_N_000204_filter_on_non_array_is_null(self):
        self.assertIsNone(search("xs[?v]", {"xs": {"v": 1}}))

    def test_N_000084_identifier_on_non_object_is_null(self):
        self.assertIsNone(search("s.x", {"s": "text"}))
        self.assertIsNone(search("xs.x", {"xs": [{"x": 1}]}))

    def test_N_000077_dotted_path_returns_field_value(self):
        self.assertEqual(search("a.b", {"a": {"b": {"c": 1}}}), {"c": 1})

    def test_N_000079_reuse_against_many_documents(self):
        parsed = pathsel_compile("v")
        self.assertEqual([parsed.search({"v": i}) for i in range(3)], [0, 1, 2])

    def test_N_000109_whitespace_between_all_tokens(self):
        self.assertEqual(search(" a . b ", {"a": {"b": 1}}), 1)

    def test_N_000223_N_000225_N_000226_literal_then_subexpression(self):
        self.assertEqual(search("`{\"k\": [1, 2]}`.k[1]", {}), 2)

    def test_N_000324_N_000325_N_000326_constructed_hash_is_object(self):
        opts = types.SimpleNamespace(dict_cls=collections.OrderedDict, custom_functions=None)
        self.assertEqual(search("{a: `1`}.a", {}, opts), 1)
        self.assertEqual(search("keys({a: `1`, b: `2`})", {}, opts), ["a", "b"])

    def test_N_000346_N_000347_N_000348_custom_function_refusals(self):
        class P(Functions):
            @signature({"types": ["number"]})
            def _func_one(self, value):
                return value

        opts = types.SimpleNamespace(dict_cls=None, custom_functions=P())
        with self.assertRaises(InvalidTypeError):
            search("one(`'x'`)", {}, opts)
        with self.assertRaises(InvalidArityError):
            search("one()", {}, opts)
        with self.assertRaises(UnknownFunctionError):
            search("two(`1`)", {}, opts)

    def test_N_000423_bare_reference_is_non_null(self):
        self.assertIsNotNone(search("&a", {"a": 1}))


class TestHardwareAndLayout(unittest.TestCase):
    def test_N_000351_N_000352_no_compiled_or_runtime_deps(self):
        text = open(os.path.join(ROOT, "pyproject.toml"), encoding="utf-8").read()
        self.assertIn("dependencies = []", text)
        self.assertNotIn("ext_modules", text)

    def test_N_000353_N_000360_python_floor(self):
        text = open(os.path.join(ROOT, "pyproject.toml"), encoding="utf-8").read()
        self.assertIn('requires-python = ">=3.9"', text)

    def test_N_000355_N_000357_N_000358_N_000359_profile_import_from_tree(self):
        self.assertEqual(os.path.dirname(os.path.abspath(pathsel.__file__)), PKG)

    def test_N_000362_N_000363_N_000364_flat_layout_no_native_build(self):
        text = open(os.path.join(ROOT, "pyproject.toml"), encoding="utf-8").read()
        self.assertIn('packages = ["pathsel"]', text)
        self.assertTrue(os.path.isdir(PKG))
        self.assertFalse(glob.glob(os.path.join(PKG, "*.so")))

    def test_N_000370_package_is_top_level_directory(self):
        self.assertTrue(os.path.isfile(os.path.join(PKG, "__init__.py")))

    def test_N_000371_import_does_not_open_files(self):
        for path, source in _package_sources().items():
            self.assertNotIn("open(", source, path)


class TestTermsAndSurface(unittest.TestCase):
    def test_N_000030_projection_collects_non_null(self):
        self.assertEqual(search("xs[*].v", {"xs": [{"v": 1}, {"w": 2}, {"v": 3}]}), [1, 3])

    def test_N_000034_N_000035_N_000036_failure_kinds_are_exclusive(self):
        kinds = [
            EmptyExpressionError, IncompleteExpressionError, PathSelSyntaxError,
            ZeroSliceStepError, UnknownFunctionError, InvalidArityError, InvalidTypeError,
        ]
        for text, expected in [("", EmptyExpressionError), ("a |", IncompleteExpressionError),
                               ("a b", PathSelSyntaxError), ("arr[::0]", ZeroSliceStepError)]:
            error = _raised(text, {"arr": []})
            self.assertIsInstance(error, expected)
            self.assertEqual(sum(isinstance(error, k) for k in kinds), 1)

    def test_N_000073_N_000074_N_000075_N_000076_entries(self):
        self.assertEqual(search("a", {"a": 1}), 1)
        self.assertEqual(pathsel_compile("a").search({"a": 2}), 2)

    def test_N_000361_zero_runtime_dependencies(self):
        text = open(os.path.join(ROOT, "pyproject.toml"), encoding="utf-8").read()
        self.assertIn("dependencies = []", text)

    def test_N_000367_outcomes_are_returned_or_raised(self):
        self.assertEqual(search("a", {"a": 1}), 1)
        with self.assertRaises(ValueError):
            search("", {})



def _raised(expression, data):
    try:
        search(expression, data)
    except ValueError as error:
        return error
    raise AssertionError("expected a refusal for %r" % (expression,))


if __name__ == "__main__":
    unittest.main()
