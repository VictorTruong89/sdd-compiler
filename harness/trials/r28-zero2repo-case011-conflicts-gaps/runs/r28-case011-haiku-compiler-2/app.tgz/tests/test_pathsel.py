"""Tests for pathsel. Test names carry the spec node ids they exercise (see NOTES.md)."""

import collections
import json
import os
import sys
import types
import unittest
from decimal import Decimal

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

import pathsel  # noqa: E402
from pathsel import (  # noqa: E402
    EmptyExpressionError,
    Functions,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    PathSelSyntaxError,
    PathSelTokenSyntaxError,
    UnknownFunctionError,
    ZeroSliceStepError,
    compile as pathsel_compile,
    search,
)
from pathsel.functions import signature  # noqa: E402

DOC = {
    "a": {"b": {"c": 5}},
    "people": [
        {"name": "x", "age": 31, "tags": [1, 2]},
        {"name": "y", "age": 20, "tags": [3]},
        {"name": None, "age": 40},
    ],
    "arr": [1, [2, 3], [4, [5]]],
    "s": "héllo",
    "flag": True,
    "zero": 0,
    "empty": "",
    "key with space": 1,
    "a.b": "dotted",
    "1": "digit",
}


class Base(unittest.TestCase):
    def assertSearch(self, expression, expected, data=DOC, options=None):
        self.assertEqual(search(expression, data, options), expected, expression)


# --- FP-01: entries, missing paths, compile reuse --------------------------

class TestEntries(Base):
    def test_N_000001_library_is_importable(self):
        self.assertTrue(callable(pathsel.search))
        self.assertTrue(callable(pathsel.compile))

    def test_N_000002_dotted_path_returns_nested_value(self):
        self.assertSearch("a.b.c", 5)
        self.assertSearch("a.b", {"c": 5})

    def test_N_000003_missing_path_yields_null(self):
        self.assertSearch("a.x.y", None)

    def test_N_000006_N_000078_parsed_expression_reused(self):
        parsed = pathsel_compile("people[*].age")
        self.assertEqual(parsed.search(DOC), [31, 20, 40])
        self.assertEqual(parsed.search({"people": [{"age": 1}]}), [1])
        self.assertEqual(parsed.search({}), None)

    def test_N_000080_N_000081_one_shot_equals_compiled(self):
        expr = "people[?age > `25`].name"
        self.assertEqual(search(expr, DOC), pathsel_compile(expr).search(DOC))

    def test_N_000082_same_failure_kinds_both_entries(self):
        with self.assertRaises(EmptyExpressionError):
            search("", DOC)
        with self.assertRaises(EmptyExpressionError):
            pathsel_compile("")

    def test_N_000083_missing_field_at_depth_is_null(self):
        self.assertSearch("a.b.missing.deeper", None)

    def test_N_000085_identifier_on_array_is_null(self):
        self.assertSearch("arr.x", None)

    def test_N_000086_compile_succeeds_when_search_null(self):
        parsed = pathsel_compile("nothing.here")
        self.assertIsNone(parsed.search({}))

    def test_N_000087_N_000089_empty_expression_kind(self):
        with self.assertRaises(EmptyExpressionError) as ctx:
            search("", DOC)
        self.assertIsInstance(ctx.exception, ValueError)

    def test_N_000090_N_000093_whitespace_only_is_incomplete(self):
        for text in ["   ", "\t", "\n", "\r\n "]:
            with self.assertRaises(IncompleteExpressionError, msg=repr(text)) as ctx:
                search(text, DOC)
            self.assertEqual(ctx.exception.lex_position, len(text))

    def test_N_000090_incomplete_pipe_and_brackets(self):
        for text in ["a |", "foo[", "foo[0", "(a", "a ==", "a &&", "a ||", "f(", "{a:", "[1:"]:
            with self.assertRaises(IncompleteExpressionError, msg=text):
                search(text, DOC)

    def test_N_000094_N_000095_syntax_kind(self):
        for text in ["a.1", "a..b", "a b", "foo[*]bar", "foo*", "*foo", "[a,]", "{}", "x)", "a ?"]:
            with self.assertRaises(PathSelSyntaxError, msg=text):
                search(text, DOC)

    def test_N_000096_N_000101_token_level_is_subclass_of_syntax(self):
        for text in ["`abc", "'abc", '"abc', "a = b", "a-b", "a#b"]:
            with self.assertRaises(PathSelTokenSyntaxError, msg=text) as ctx:
                search(text, DOC)
            self.assertIsInstance(ctx.exception, PathSelSyntaxError)
            self.assertNotIsInstance(ctx.exception, (EmptyExpressionError, IncompleteExpressionError))

    def test_N_000102_N_000104_position_reported(self):
        with self.assertRaises(PathSelSyntaxError) as ctx:
            search("a b", DOC)
        self.assertEqual(ctx.exception.lex_position, 2)
        with self.assertRaises(PathSelTokenSyntaxError) as ctx:
            search("a-b", DOC)
        self.assertEqual(ctx.exception.lex_position, 1)
        with self.assertRaises(IncompleteExpressionError) as ctx:
            search("foo |", DOC)
        self.assertEqual(ctx.exception.lex_position, 5)

    def test_N_000105_N_000106_refusals_are_value_errors_not_null(self):
        with self.assertRaises(ValueError):
            search("a b", DOC)

    def test_N_000119_hyphen_is_token_error_and_quoted_key_works(self):
        with self.assertRaises(PathSelTokenSyntaxError):
            search("foo-bar", DOC)
        self.assertEqual(search('"key with space"', DOC), 1)


# --- FP-02: identifiers and subexpressions ---------------------------------

class TestIdentifiers(Base):
    def test_N_000107_unquoted_identifier(self):
        self.assertSearch("a", DOC["a"])
        self.assertSearch("_x1", None)

    def test_N_000109_whitespace_between_tokens(self):
        self.assertSearch(" a \t.\n b . c ", 5)

    def test_N_000110_N_000114_quoted_identifier_decoded(self):
        self.assertSearch('"a.b"', "dotted")
        self.assertSearch('"1"', "digit")
        self.assertSearch('"key with space"', 1)
        self.assertSearch('"\\u0061"', DOC["a"])  # escape decodes to the key "a"
        self.assertSearch('"a"', DOC["a"])

    def test_N_000112_quoted_identifier_chains(self):
        self.assertSearch('"a".b.c', 5)

    def test_N_000116_identifier_on_array_does_not_project(self):
        self.assertSearch("people.name", None)

    def test_N_000117_number_cannot_be_identifier(self):
        with self.assertRaises(PathSelSyntaxError):
            search("a.1", DOC)
        with self.assertRaises(PathSelSyntaxError):
            search("a.-1", DOC)

    def test_N_000120_N_000122_hyphenated_key_needs_quotes(self):
        data = {"my-key": 3}
        self.assertEqual(search('"my-key"', data), 3)
        with self.assertRaises(PathSelTokenSyntaxError):
            search("my-key", data)

    def test_N_000123_dot_at_start_end_or_doubled(self):
        for text in [".a", "a.", "a..b"]:
            with self.assertRaises(PathSelSyntaxError, msg=text):
                search(text, DOC)

    def test_N_000124_bad_quoted_identifier(self):
        for text in ['"abc', '"a\\qb"']:
            with self.assertRaises(PathSelTokenSyntaxError, msg=text):
                search(text, DOC)


# --- FP-03: index, slice, flatten ------------------------------------------

class TestIndexSliceFlatten(Base):
    def test_N_000126_N_000128_index_and_negative(self):
        self.assertSearch("arr[0]", 1)
        self.assertSearch("arr[-1][0]", 4)
        self.assertSearch("arr[9]", None)
        self.assertSearch("arr[-9]", None)

    def test_N_000129_index_on_non_array_is_null(self):
        self.assertSearch("a[0]", None)
        self.assertSearch("s[0]", None)

    def test_N_000131_N_000133_step_defaults_and_zero(self):
        self.assertSearch("arr[0:3]", [1, [2, 3], [4, [5]]])
        with self.assertRaises(ZeroSliceStepError):
            search("arr[0:3:0]", DOC)
        with self.assertRaises(ZeroSliceStepError):
            pathsel_compile("arr[::0]")

    def test_N_000134_negative_bounds(self):
        self.assertSearch("arr[-2:]", [[2, 3], [4, [5]]])

    def test_N_000135_N_000137_positive_step_clamp(self):
        self.assertSearch("arr[:10]", [1, [2, 3], [4, [5]]])
        self.assertSearch("arr[::2]", [1, [4, [5]]])
        self.assertSearch("arr[5:]", [])

    def test_N_000138_N_000140_negative_step(self):
        self.assertSearch("arr[::-1]", [[4, [5]], [2, 3], 1])
        self.assertSearch("arr[-1::-2]", [[4, [5]], 1])

    def test_N_000141_slice_selecting_nothing_is_empty_array(self):
        self.assertSearch("arr[2:1]", [])

    def test_N_000142_slice_on_non_array_is_null(self):
        self.assertSearch("a[0:1]", None)

    def test_N_000145_N_000147_flatten_one_level(self):
        self.assertSearch("arr[]", [1, 2, 3, 4, [5]])
        self.assertSearch("a[]", None)

    def test_N_000148_N_000150_flatten_projection(self):
        self.assertSearch("people[].tags", [[1, 2], [3]])
        self.assertSearch("people[].name", ["x", "y"])

    def test_N_000151_index_slice_flatten_on_document(self):
        self.assertSearch("[0]", 9, data=[9, 8])
        self.assertSearch("[0:1]", [9], data=[9, 8])
        self.assertSearch("[]", [1, 2], data=[[1], [2]])

    def test_N_000155_slice_with_bad_part_is_syntax(self):
        for text in ["arr[1:2:3:4]", "arr[1:x]", "arr[1 2]"]:
            with self.assertRaises(PathSelSyntaxError, msg=text):
                search(text, DOC)

    def test_N_000156_N_000157_out_of_range_no_failure(self):
        self.assertSearch("arr[100:200]", [])


# --- FP-04: projections ----------------------------------------------------

class TestProjections(Base):
    def test_N_000159_N_000162_list_wildcard(self):
        self.assertSearch("people[*].age", [31, 20, 40])
        self.assertSearch("people[*]", [{"name": "x", "age": 31, "tags": [1, 2]}, {"name": "y", "age": 20, "tags": [3]}, {"name": None, "age": 40}])
        self.assertSearch("a[*]", None)

    def test_N_000163_N_000165_object_wildcard(self):
        self.assertSearch("a.*", [{"c": 5}])
        self.assertSearch("people[0].*", ["x", 31, [1, 2]])
        self.assertSearch("s.*", None)

    def test_N_000165_object_wildcard_not_object_null(self):
        self.assertSearch("arr.*", None)

    def test_N_000166_N_000167_nested_projection(self):
        data = {"x": [{"y": [{"z": 1}, {"z": 2}]}, {"y": [{"z": 3}]}]}
        self.assertEqual(search("x[*].y[*].z", data), [[1, 2], [3]])
        self.assertEqual(search("x[*].y[*].q", data), [[], []])
        self.assertEqual(search("x[*].nope[*].z", data), [])

    def test_N_000168_N_000173_filter(self):
        self.assertSearch("people[?age > `25`].name", ["x"])
        self.assertSearch("people[?age > `100`]", [])
        self.assertSearch("a[?x]", None)

    def test_N_000174_N_000179_predicate_forms(self):
        self.assertSearch("people[?tags]", [{"name": "x", "age": 31, "tags": [1, 2]}, {"name": "y", "age": 20, "tags": [3]}])
        self.assertSearch("people[?!tags].age", [40])
        self.assertSearch("people[?age >= `31` || age == `20`].age", [31, 20, 40])
        self.assertSearch("people[?name == 'x'].age", [31])

    def test_N_000180_N_000181_equality_not_truthiness(self):
        self.assertSearch("[?@ == `0`]", [0], data=[0, False, 1])
        self.assertSearch("[?@ == `1`]", [1], data=[0, True, 1])

    def test_N_000185_N_000190_projection_reach(self):
        # a dot after a list wildcard joins the right-hand side
        self.assertSearch("people[*].tags[0]", [1, 3])
        # a dot after an object wildcard does not join (rank 4)
        self.assertSearch("a.*.b.c", None)

    def test_N_000195_N_000197_comparison_ends_projection(self):
        self.assertSearch("people[*].age == `20`", False)

    def test_N_000200_N_000201_wildcard_followed_by_identifier_syntax(self):
        for text in ["[*]foo", "*5", "x.*y"]:
            with self.assertRaises(PathSelSyntaxError, msg=text):
                search(text, DOC)

    def test_N_000202_filter_on_non_array_is_null(self):
        self.assertSearch("a[?x]", None)

    def test_N_000204_N_000205_nulls_dropped(self):
        self.assertSearch("people[*].name", ["x", "y"])


# --- FP-05: constructors, pipe, current value, literals -----------------

class TestConstructorsAndLiterals(Base):
    def test_N_000206_N_000210_multiselect_hash(self):
        self.assertSearch("{n: people[0].name, z: nope}", {"n": "x", "z": None})
        self.assertSearch('{"a b": `1`}', {"a b": 1})

    def test_N_000211_N_000212_multiselect_list(self):
        self.assertSearch("[a.b.c, nope, s]", [5, None, "héllo"])

    def test_N_000213_N_000218_multiselect_placement(self):
        self.assertSearch("people[*].[name, age]", [["x", 31], ["y", 20], [None, 40]])
        self.assertSearch("people[*].{n: name}", [{"n": "x"}, {"n": "y"}, {"n": None}])
        self.assertSearch("nope.[a, b]", None)
        with self.assertRaises(PathSelSyntaxError):
            search("arr[0][a, b]", DOC)
        with self.assertRaises(PathSelSyntaxError):
            search("a{x: b}", DOC)

    def test_N_000219_N_000222_pipe(self):
        self.assertSearch("people[*].age | max(@)", 40)
        self.assertSearch("a|b", None, data={"a": {"b": None}})
        self.assertSearch("people[*].age|length(@)", 3)

    def test_N_000222_pipe_stops_projection(self):
        self.assertSearch("people[*].age | sum(@)", 91)

    def test_N_000019_N_000020_current_value(self):
        self.assertSearch("@", 3, data=3)
        self.assertSearch("people[*].age | [0]", 31)

    def test_N_000223_N_000226_json_literal(self):
        self.assertSearch("`[1, 2]`", [1, 2])
        self.assertSearch("`\"x\"`", "x")
        self.assertSearch("` {\"k\": 1} `.k", 1)
        self.assertSearch("`hello`", "hello")
        self.assertSearch("`  hello`", "hello")
        self.assertSearch("`1`", 1)

    def test_N_000227_N_000230_raw_string(self):
        self.assertSearch("'hello world'", "hello world")
        self.assertSearch("'it\\'s'", "it's")
        self.assertSearch("'123'", "123")
        self.assertSearch("'a\\nb'", "a\\nb")

    def test_N_000231_N_000236_expression_reference_alone(self):
        value = search("&a.b", DOC)
        self.assertIsNotNone(value)
        self.assertIsNot(value, DOC)

    def test_N_000237_unclosed_literal_token_error(self):
        with self.assertRaises(PathSelTokenSyntaxError):
            search("`[1,", DOC)
        with self.assertRaises(PathSelTokenSyntaxError):
            search("'abc", DOC)

    def test_N_000238_literal_after_dot_is_syntax(self):
        with self.assertRaises(PathSelSyntaxError):
            search("a.`1`", DOC)
        with self.assertRaises(PathSelSyntaxError):
            search("a.'x'", DOC)

    def test_N_000239_uXXXX_in_raw_string(self):
        self.assertSearch("'\\u0041'", "A")

    def test_N_000240_N_000241_incomplete_constructors_and_pipe(self):
        for text in ["[a, b", "{a: b", "a |"]:
            with self.assertRaises(IncompleteExpressionError, msg=text):
                search(text, DOC)
        for text in ["{a: b,}", "[a, b,]"]:
            with self.assertRaises(PathSelSyntaxError, msg=text):
                search(text, DOC)


# --- FP-06: comparisons and logic ----------------------------------------

class TestLogic(Base):
    def test_N_000242_N_000244_equality(self):
        self.assertSearch("`0` == `false`", False)
        self.assertSearch("`1` == `true`", False)
        self.assertSearch("`[1,{\"a\":2}]` == `[1,{\"a\":2}]`", True)
        self.assertSearch("`1` != `1.0`", False)
        self.assertSearch("`0` != `false`", True)

    def test_N_000245_N_000246_ordering(self):
        self.assertSearch("`2` < `10`", True)
        self.assertSearch("'a' < 'b'", True)
        self.assertSearch("'b' <= 'a'", False)
        self.assertSearch("`1` >= `1`", True)

    def test_N_000247_N_000250_and_or_return_operands(self):
        self.assertSearch("nope || 'x'", "x")
        self.assertSearch("'a' || 'b'", "a")
        self.assertSearch("'' && 'b'", "")
        self.assertSearch("'a' && 'b'", "b")

    def test_N_000251_N_000252_not(self):
        self.assertSearch("!`0`", False)
        self.assertSearch("!`0.0`", False)
        self.assertSearch("!''", True)
        self.assertSearch("!nope", True)

    def test_N_000253_N_000257_precedence(self):
        self.assertSearch("`1` == `1` && `2` == `2`", True)
        self.assertSearch("nope || `0` && `5`", 5)
        self.assertSearch("!`0` == `true`", False)
        self.assertSearch("!(`0` == `true`)", True)

    def test_N_000258_N_000259_filter_uses_operators(self):
        self.assertSearch("people[?age > `20` && age < `40`].age", [31])

    def test_N_000260_lone_equals_is_token_error(self):
        with self.assertRaises(PathSelTokenSyntaxError):
            search("a = b", DOC)

    def test_N_000261_lone_ampersand(self):
        with self.assertRaises(ValueError):
            search("a & b", DOC)
        with self.assertRaises(ValueError):
            search("a || ", DOC)


# --- FP-07: built-in functions ---------------------------------------------

class TestBuiltins(Base):
    def test_N_000033_N_000262_N_000263_names_are_exact(self):
        names = {n[len("_func_"):] for n in dir(Functions) if n.startswith("_func_")}
        self.assertEqual(
            names,
            {"abs", "avg", "ceil", "contains", "ends_with", "floor", "join", "keys", "length", "map", "max", "max_by", "merge", "min", "min_by", "not_null", "reverse", "sort", "sort_by", "starts_with", "sum", "to_array", "to_number", "to_string", "type", "values"},
        )

    def test_N_000264_N_000266_unknown_function(self):
        with self.assertRaises(UnknownFunctionError) as ctx:
            search("nosuch(`1`)", DOC)
        self.assertIsInstance(ctx.exception, ValueError)

    def test_N_000267_arity_checked_at_search_not_compile(self):
        parsed = pathsel_compile("abs()")
        with self.assertRaises(InvalidArityError):
            parsed.search(DOC)

    def test_N_000268_join_empty_array(self):
        self.assertSearch("join(',', `[]`)", "")

    def test_N_000269_abs(self):
        self.assertSearch("abs(`-3`)", 3)
        self.assertSearch("abs(`-2.5`)", 2.5)

    def test_N_000270_N_000271_avg(self):
        self.assertSearch("avg(`[1, 2, 3]`)", 2)
        self.assertSearch("avg(`[]`)", None)

    def test_N_000272_ceil_floor(self):
        self.assertSearch("ceil(`1.2`)", 2)
        self.assertSearch("floor(`1.8`)", 1)
        self.assertIsInstance(search("ceil(`1.2`)", DOC), int)

    def test_N_000274_N_000275_contains(self):
        self.assertSearch("contains(`[1, 2]`, `2`)", True)
        self.assertSearch("contains('hello', 'ell')", True)
        self.assertSearch("contains(`[\"a\"]`, `\"b\"`)", False)
        with self.assertRaises(InvalidTypeError):
            search("contains('hello', `1`)", DOC)

    def test_N_000276_starts_ends_with(self):
        self.assertSearch("starts_with('hello', 'he')", True)
        self.assertSearch("ends_with('hello', 'lo')", True)

    def test_N_000277_length(self):
        self.assertSearch("length(s)", 5)
        self.assertSearch("length(people)", 3)
        self.assertSearch("length(a)", 1)

    def test_N_000278_reverse(self):
        self.assertSearch("reverse(`[1,2,3]`)", [3, 2, 1])
        self.assertSearch("reverse('abc')", "cba")

    def test_N_000279_N_000280_join(self):
        self.assertSearch("join(', ', `[\"a\", \"b\"]`)", "a, b")

    def test_N_000281_keys_values(self):
        self.assertSearch("keys(a)", ["b"])
        self.assertSearch("values(a)", [{"c": 5}])

    def test_N_000282_type(self):
        self.assertSearch("type(s)", "string")
        self.assertSearch("type(zero)", "number")
        self.assertSearch("type(flag)", "boolean")
        self.assertSearch("type(arr)", "array")
        self.assertSearch("type(a)", "object")
        self.assertSearch("type(nope)", "null")

    def test_N_000283_to_array(self):
        self.assertSearch("to_array(`1`)", [1])
        self.assertSearch("to_array(arr)", DOC["arr"])

    def test_N_000284_N_000285_to_string(self):
        self.assertSearch("to_string(`1`)", "1")
        self.assertSearch("to_string(`[1,\"a\"]`)", '[1,"a"]')
        self.assertSearch("to_string(`\"h\\u00e9\"`)", "hé")
        self.assertSearch("to_string(a)", '{"b":{"c":5}}')
        self.assertSearch("to_string(`\"é\"`)", "é")
        self.assertSearch("to_string(nope)", "null")

    def test_N_000286_N_000289_to_number(self):
        self.assertSearch("to_number('12')", 12)
        self.assertIsInstance(search("to_number('12')", DOC), int)
        self.assertEqual(search("to_number('1.5')", DOC), 1.5)
        self.assertEqual(search("to_number('1e2')", DOC), 100.0)
        self.assertIsNone(search("to_number('x')", DOC))
        self.assertIsNone(search("to_number(`true`)", DOC))
        self.assertIsNone(search("to_number(`null`)", DOC))

    def test_N_000290_N_000292_max_min(self):
        self.assertSearch("max(`[1, 3, 2]`)", 3)
        self.assertSearch("min(`[\"b\", \"a\"]`)", "a")
        self.assertSearch("max(`[]`)", None)
        with self.assertRaises(InvalidTypeError):
            search("max(`[1, \"a\"]`)", DOC)

    def test_N_000293_sort(self):
        self.assertSearch("sort(`[3, 1, 2]`)", [1, 2, 3])
        self.assertSearch("sort(`[\"b\", \"a\"]`)", ["a", "b"])

    def test_N_000294_sum(self):
        self.assertSearch("sum(`[1, 2, 3.5]`)", 6.5)

    def test_N_000295_N_000297_merge(self):
        self.assertSearch("merge(`{\"a\": 1}`, `{\"a\": 2, \"b\": 3}`)", {"a": 2, "b": 3})
        self.assertSearch("merge(a)", {"b": {"c": 5}})

    def test_N_000298_N_000300_not_null(self):
        self.assertSearch("not_null(nope, a.b.c, `9`)", 5)
        self.assertSearch("not_null(nope, nope2)", None)
        self.assertSearch("not_null(empty, nope)", "")
        self.assertSearch("not_null(`[]`, `1`)", [])

    def test_N_000301_N_000302_map_keeps_nulls(self):
        self.assertSearch("map(&age, people)", [31, 20, 40])
        self.assertSearch("map(&name, people)", ["x", "y", None])

    def test_N_000303_N_000305_sort_by_stable(self):
        data = {"xs": [{"k": 2, "id": "a"}, {"k": 1, "id": "b"}, {"k": 2, "id": "c"}]}
        self.assertEqual([x["id"] for x in search("sort_by(xs, &k)", data)], ["b", "a", "c"])

    def test_N_000306_N_000308_max_by_min_by(self):
        data = {"xs": [{"k": 2, "id": "a"}, {"k": 5, "id": "b"}, {"k": 5, "id": "c"}, {"k": 1, "id": "d"}]}
        self.assertEqual(search("max_by(xs, &k).id", data), "b")
        self.assertEqual(search("min_by(xs, &k).id", data), "d")
        self.assertIsNone(search("max_by(`[]`, &k)", data))

    def test_N_000309_N_000310_projection_with_function(self):
        self.assertSearch("people[*].type(@)", ["object", "object", "object"])
        self.assertSearch("people[*].age | length(@)", 3)

    def test_N_000311_N_000313_arity(self):
        with self.assertRaises(InvalidArityError):
            search("abs(`1`, `2`)", DOC)
        with self.assertRaises(InvalidArityError):
            search("not_null()", DOC)
        with self.assertRaises(InvalidArityError):
            search("merge()", DOC)

    def test_N_000314_N_000320_invalid_type(self):
        cases = [
            "abs(flag)",
            "avg(`[1, \"a\"]`)",
            "map(a, people)",
            "sort_by(people, age)",
            "length(zero)",
            "sort_by(people, nope)",
        ]
        for text in cases:
            with self.assertRaises(InvalidTypeError, msg=text):
                search(text, DOC)

    def test_N_000321_N_000322_quoted_function_name_is_syntax(self):
        with self.assertRaises(PathSelSyntaxError):
            search('"abs"(`1`)', DOC)

    def test_N_000317_reference_required(self):
        with self.assertRaises(InvalidTypeError):
            search("map(people, people)", DOC)


# --- FP-08 / Interface: evaluation options, providers ---------------------

class Provider(Functions):
    @signature({"types": ["number"]}, {"types": ["number"]})
    def _func_add(self, left, right):
        return left + right

    @signature({"types": ["string"]})
    def _func_shout(self, text):
        return text.upper() + "!"

    @signature({"types": ["null"]})
    def _func_nothing(self, value):
        return 0


class TestOptionsAndProviders(Base):
    def test_N_000323_N_000327_no_options_plain_dict(self):
        value = search("{a: a.b.c}", DOC)
        self.assertIs(type(value), dict)

    def test_N_000328_N_000334_dict_cls(self):
        opts = types.SimpleNamespace(dict_cls=collections.OrderedDict, custom_functions=None)
        value = search("{a: a.b.c}", DOC, opts)
        self.assertIsInstance(value, collections.OrderedDict)
        self.assertEqual(search("{a: a.b.c}.a", DOC, opts), 5)
        self.assertEqual(search("merge({x: `1`})", DOC, opts), {"x": 1})

    def test_N_000335_N_000338_custom_function(self):
        opts = types.SimpleNamespace(dict_cls=None, custom_functions=Provider())
        self.assertEqual(search("add(`1`, `2`)", DOC, opts), 3)
        self.assertEqual(search("shout('hi')", DOC, opts), "HI!")
        self.assertEqual(search("nothing(nope)", DOC, opts), 0)

    def test_N_000339_N_000340_builtins_available_with_provider(self):
        opts = types.SimpleNamespace(dict_cls=None, custom_functions=Provider())
        self.assertEqual(search("length(s)", DOC, opts), 5)
        self.assertEqual(search("abs(`-1`)", DOC, opts), 1)

    def test_N_000341_options_both_apply(self):
        opts = types.SimpleNamespace(dict_cls=collections.OrderedDict, custom_functions=Provider())
        value = search("{s: shout('x')}", DOC, opts)
        self.assertIsInstance(value, collections.OrderedDict)
        self.assertEqual(value, {"s": "X!"})

    def test_N_000342_N_000343_options_same_result_and_compile_without_provider(self):
        opts = types.SimpleNamespace(dict_cls=None, custom_functions=Provider())
        expr = "add(`2`, `3`)"
        self.assertEqual(search(expr, DOC, opts), pathsel_compile(expr).search(DOC, opts))
        pathsel_compile("add(`1`, `2`)")  # compiles without a provider
        with self.assertRaises(UnknownFunctionError):
            search("add(`1`, `2`)", DOC)

    def test_N_000344_custom_name_without_provider_unknown(self):
        opts = types.SimpleNamespace(dict_cls=None, custom_functions=Functions())
        with self.assertRaises(UnknownFunctionError):
            search("add(`1`, `2`)", DOC, opts)

    def test_N_000345_N_000349_custom_arity_and_type(self):
        opts = types.SimpleNamespace(dict_cls=None, custom_functions=Provider())
        with self.assertRaises(InvalidArityError):
            search("add(`1`)", DOC, opts)
        with self.assertRaises(InvalidTypeError):
            search("add(`1`, `\"x\"`)", DOC, opts)
        with self.assertRaises(InvalidTypeError):
            search("add(`1`, flag)", DOC, opts)

    def test_N_000350_custom_failure_kinds_are_builtin_kinds(self):
        opts = types.SimpleNamespace(dict_cls=None, custom_functions=Provider())
        with self.assertRaises(InvalidTypeError):
            search("add(`1`, `\"x\"`)", DOC, opts)

    def test_N_000389_N_000392_options_attributes_are_read(self):
        class Plain:
            dict_cls = None
            custom_functions = None

        self.assertEqual(search("a.b.c", DOC, Plain()), 5)


# --- Failure carriers -----------------------------------------------------

class TestFailureCarriers(Base):
    def test_N_000405_all_refusals_are_value_errors(self):
        for text in ["", " ", "a b", "a-b", "a.", "nope()", "abs()", "abs(`\"x\"`)", "arr[1:2:0]"]:  # noqa
            with self.assertRaises(ValueError, msg=text):
                search(text, DOC)

    def test_N_000409_N_000410_distinct_kinds(self):
        self.assertFalse(issubclass(PathSelSyntaxError, (EmptyExpressionError, IncompleteExpressionError)))
        self.assertFalse(issubclass(ZeroSliceStepError, PathSelSyntaxError))
        self.assertFalse(issubclass(InvalidTypeError, (UnknownFunctionError, InvalidArityError)))

    def test_N_000415_zero_step_not_syntax(self):
        with self.assertRaises(ZeroSliceStepError) as ctx:
            search("arr[::0]", DOC)
        self.assertNotIsInstance(ctx.exception, PathSelSyntaxError)

    def test_N_000421_N_000422_position_is_int(self):
        with self.assertRaises(PathSelSyntaxError) as ctx:
            search("a b", DOC)
        self.assertIsInstance(ctx.exception.lex_position, int)
        self.assertTrue(0 <= ctx.exception.lex_position <= len("a b"))


# --- Non-functional and layout constraints --------------------------------

class TestConstraints(Base):
    def test_N_000050_N_000051_no_runtime_dependencies(self):
        with open(os.path.join(ROOT, "pyproject.toml"), encoding="utf-8") as handle:
            text = handle.read()
        self.assertIn("dependencies = []", text)

    def test_N_000055_N_000369_flat_layout_import(self):
        self.assertEqual(os.path.basename(os.path.dirname(pathsel.__file__)), "pathsel")

    def test_N_000371_import_is_quiet(self):
        import pathsel.functions as functions

        self.assertTrue(hasattr(functions, "Functions"))

    def test_N_000056_decimal_numbers_compare(self):
        data = {"d": Decimal("2.5")}
        self.assertEqual(search("d > `2`", data), True)
        self.assertEqual(search("d == `2.5`", data), True)

    def test_N_000059_N_000060_missing_is_success(self):
        self.assertIsNone(search("missing", {}))

    def test_N_000066_results_come_from_document(self):
        self.assertEqual(search("people[0].name", DOC), "x")

    def test_N_000069_N_000070_document_not_mutated(self):
        before = json.dumps(DOC, sort_keys=True, default=str)
        search("sort(people[*].age)", DOC)
        search("merge(a)", DOC)
        search("{x: a}", DOC)
        self.assertEqual(json.dumps(DOC, sort_keys=True, default=str), before)

    def test_N_000403_signature_wraps_without_calling(self):
        calls = []

        @signature({"types": ["number"]})
        def impl(self, value):
            calls.append(value)
            return value

        self.assertEqual(calls, [])
        self.assertTrue(callable(impl))


if __name__ == "__main__":
    unittest.main()
