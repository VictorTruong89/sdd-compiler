"""Parser for PathSel expressions (a Pratt parser).

Binding powers, loosest to tightest (spec: N-000253):
  pipe 1 < `||` 2 < `&&` 3 < comparators 5 < `!` operand 45 (see below)
  flatten `[]` 9 (projection rank 1)
  list wildcard `[*]`, slice, object wildcard starting an operand 20 (rank 2)
  filter `[?...]` 21 (rank 3)
  dot step and object wildcard after a dot 40 (rank 4)
  index, slice, list-wildcard or filter bracket written as a step 55 (rank 5)

A projection's right-hand side is parsed with the binding power of its own
form; a later step joins it only when it binds tighter (spec: N-000191..N-000194).
The first step after a projection form always begins its right-hand side when
it is a dot step, a bracket step (index, slice, list wildcard, multiselect list)
or a filter (spec: N-000183, N-000184).
"""

from . import nodes as N
from .errors import (
    EmptyExpressionError,
    IncompleteExpressionError,
    PathSelSyntaxError,
    ZeroSliceStepError,
)
from .lexer import Lexer

BP_PIPE = 1
BP_OR = 2
BP_AND = 3
BP_COMPARE = 5
BP_NOT_OPERAND = 45
BP_FLATTEN = 9
BP_PROJECTION = 20  # rhs of `[*]`, slices, and `*` at the start of an operand
BP_FILTER = 21
BP_DOT = 40
BP_STEP = 55

_COMPARATORS = frozenset(["eq", "ne", "lt", "lte", "gt", "gte"])
_BINARY_BP = {"pipe": BP_PIPE, "or": BP_OR, "and": BP_AND, "dot": BP_DOT}
_BINARY_BP.update({name: BP_COMPARE for name in _COMPARATORS})


def parse(text):
    """Parse expression text into an AST root. Raises a PathSelError subclass on refusal."""
    return Parser(text).parse()


class Parser:
    def __init__(self, text):
        self.text = text
        self.length = len(text)
        self._lexer = Lexer(text)
        self._tokens = []
        self._pos = 0

    # --- token access -------------------------------------------------

    def _ensure(self, offset):
        needed = self._pos + offset
        while len(self._tokens) <= needed:
            if self._tokens and self._tokens[-1].kind == "eof":
                break
            self._tokens.append(self._lexer.next_token())

    def peek(self, offset=0):
        self._ensure(offset)
        index = self._pos + offset
        if index < len(self._tokens):
            return self._tokens[index]
        return self._tokens[-1]

    def advance(self):
        token = self.peek()
        if token.kind != "eof":
            self._pos += 1
        return token

    # --- errors -------------------------------------------------------

    def _unexpected(self, token):
        """End of text where something is still required is incomplete; else syntax."""
        if token.kind == "eof":
            return IncompleteExpressionError("expression is incomplete", self.length)
        return PathSelSyntaxError("unexpected token %r" % (token.value,), token.pos)

    def _syntax(self, token):
        return PathSelSyntaxError("syntax error at offset %d" % token.pos, token.pos)

    def _expect(self, kind):
        token = self.peek()
        if token.kind != kind:
            raise self._unexpected(token)
        return self.advance()

    # --- entry point ----------------------------------------------------

    # spec: N-000087, N-000090, N-000093, N-000094
    def parse(self):
        if self.length == 0:
            raise EmptyExpressionError("expression is empty")  # spec: N-000087..N-000089
        node = self.parse_expression(0)
        token = self.peek()
        if token.kind != "eof":
            raise self._syntax(token)  # spec: N-000094 (leftover token)
        return node

    def parse_expression(self, rbp):
        left = self.nud()
        return self.led_loop(rbp, left)

    def led_loop(self, rbp, left):
        while True:
            token = self.peek()
            if self._binding_power(token) <= rbp:
                return left
            left = self._led(token, left)

    # --- binding ----------------------------------------------------------

    def _bracket_form(self, offset=0):
        """Classify the bracket that starts at `offset` from the current token."""
        after = self.peek(offset + 1)
        if after.kind == "rbracket":
            return "flatten"  # spec: N-000145
        if after.kind == "star" and self.peek(offset + 2).kind == "rbracket":
            return "list"  # spec: N-000158
        if after.kind == "question":
            return "filter"  # spec: N-000168
        if after.kind in ("number", "colon"):
            return "index"  # spec: N-000126, N-000130
        if after.kind == "eof":
            return "eof"
        return "multi"  # spec: N-000213

    def _binding_power(self, token):
        if token.kind == "lbracket":
            form = self._bracket_form()
            if form == "flatten":
                return BP_FLATTEN
            if form == "filter":
                return BP_FILTER
            if form == "multi":
                return 0  # a multiselect list after an operand is not a step
            return BP_STEP  # index, slice, list wildcard, and an unclosed bracket
        return _BINARY_BP.get(token.kind, 0)

    # --- led (binary and postfix forms) -------------------------------------

    def _led(self, token, left):
        kind = token.kind
        if kind == "pipe":  # spec: N-000219..N-000222
            self.advance()
            return N.Sub(left, self.parse_expression(BP_PIPE))
        if kind == "or":  # spec: N-000247, N-000248
            self.advance()
            return N.Or(left, self.parse_expression(BP_OR))
        if kind == "and":  # spec: N-000249, N-000250
            self.advance()
            return N.And(left, self.parse_expression(BP_AND))
        if kind in _COMPARATORS:  # spec: N-000242..N-000245
            self.advance()
            return N.Compare(kind, left, self.parse_expression(BP_COMPARE))
        if kind == "dot":  # spec: N-000108, N-000123
            self.advance()
            return self._chain(left, self._dot_operand())
        if kind == "lbracket":
            return self._chain(left, self._bracket_node(allow_multi=False))
        raise self._syntax(token)

    @staticmethod
    def _chain(left, node):
        if isinstance(left, N.Current):
            return node
        return N.Sub(left, node)

    # spec: N-000108, N-000117, N-000118, N-000123, N-000183, N-000206, N-000213
    def _dot_operand(self):
        token = self.peek()
        if token.kind == "ident":
            if self.peek(1).kind == "lparen":
                return self._function_call()  # spec: N-000309 (a call after a dot)
            self.advance()
            return N.Field(token.value)
        if token.kind == "qident":  # spec: N-000110..N-000114
            self.advance()
            return N.Field(token.value)
        if token.kind == "star":  # spec: N-000163, N-000185..N-000190
            self.advance()
            return N.ObjectProjection(self._projection_rhs(BP_DOT))
        if token.kind == "lbracket":
            form = self._bracket_form()
            if form == "eof":
                raise self._unexpected(self.peek(1))
            if form != "multi":
                raise self._syntax(token)  # a dot before an index, slice, or wildcard
            return self._multilist()  # spec: N-000213, N-000216
        if token.kind == "lbrace":
            return self._multihash()  # spec: N-000206
        raise self._syntax(token)  # spec: N-000123, N-000238

    # spec: N-000183, N-000184, N-000192..N-000194, N-000198, N-000199
    def _projection_rhs(self, rbp):
        token = self.peek()
        if token.kind == "dot":
            self.advance()
            return self.led_loop(rbp, self._dot_operand())
        if token.kind == "lbracket":
            form = self._bracket_form()
            if form == "flatten":
                return N.Current()  # `[]` never begins a right-hand side
            if form == "eof":
                raise self._unexpected(self.peek(1))
            node = self._bracket_node(allow_multi=True)
            return self.led_loop(rbp, node)
        return N.Current()

    # --- brackets -----------------------------------------------------------

    def _bracket_node(self, allow_multi):
        """Parse a bracket construct starting at the current `[`."""
        opener = self.peek()
        form = self._bracket_form()
        if form == "eof":
            raise self._unexpected(self.peek(1))
        if form == "flatten":  # spec: N-000145..N-000150
            self.advance()
            self.advance()
            return N.Flatten(self._projection_rhs(BP_FLATTEN))
        if form == "list":  # spec: N-000159..N-000162
            self.advance()
            self.advance()
            self.advance()
            return N.ListProjection(self._projection_rhs(BP_PROJECTION))
        if form == "filter":  # spec: N-000168..N-000173
            self.advance()
            self.advance()
            predicate = self.parse_expression(0)
            self._expect("rbracket")
            return N.FilterProjection(predicate, self._projection_rhs(BP_FILTER))
        if form == "index":  # spec: N-000126..N-000157
            return self._index_or_slice()
        if not allow_multi:  # spec: N-000213 (a multiselect after an operand)
            raise self._syntax(opener)
        return self._multilist()

    def _index_or_slice(self):
        self.advance()  # '['
        parts = [None]
        colons = 0
        while True:
            token = self.peek()
            if token.kind == "number":
                if parts[-1] is not None:
                    raise self._syntax(token)
                parts[-1] = token.value
                self.advance()
            elif token.kind == "colon":
                colons += 1
                if colons > 2:  # spec: N-000155 (more than three parts)
                    raise self._syntax(token)
                parts.append(None)
                self.advance()
            elif token.kind == "rbracket":
                self.advance()
                break
            else:
                raise self._unexpected(token)  # spec: N-000155 (non-integer part)
        if colons == 0:
            return N.Index(parts[0])  # spec: N-000126..N-000129
        start, stop, step = parts + [None] * (3 - len(parts))
        step = 1 if step is None else step
        if step == 0:
            # spec: N-000152..N-000154 (refused on every entry, so raised at parse time)
            raise ZeroSliceStepError("slice step is zero")
        return N.SliceProjection(start, stop, step, self._projection_rhs(BP_PROJECTION))

    # spec: N-000213..N-000218, N-000240
    def _multilist(self):
        self.advance()  # '['
        items = []
        while True:
            items.append(self.parse_expression(0))
            token = self.peek()
            if token.kind == "comma":
                self.advance()
                continue
            if token.kind == "rbracket":
                self.advance()
                break
            raise self._unexpected(token)
        return N.MultiList(items)

    # spec: N-000206..N-000210, N-000240
    def _multihash(self):
        self.advance()  # '{'
        pairs = []
        while True:
            token = self.peek()
            if token.kind not in ("ident", "qident"):
                raise self._unexpected(token)
            self.advance()
            colon = self.peek()
            if colon.kind != "colon":
                raise self._unexpected(colon)
            self.advance()
            pairs.append((token.value, self.parse_expression(0)))
            token = self.peek()
            if token.kind == "comma":
                self.advance()
                continue
            if token.kind == "rbrace":
                self.advance()
                break
            raise self._unexpected(token)
        return N.MultiHash(pairs)

    # --- function calls ---------------------------------------------------

    # spec: N-000262, N-000264, N-000321
    def _function_call(self):
        name = self.advance().value
        self.advance()  # '('
        args = []
        if self.peek().kind == "rparen":
            self.advance()
            return N.Call(name, args)
        while True:
            args.append(self.parse_expression(0))
            token = self.peek()
            if token.kind == "comma":
                self.advance()
                continue
            if token.kind == "rparen":
                self.advance()
                break
            raise self._unexpected(token)
        return N.Call(name, args)

    # --- nud (prefix forms) -----------------------------------------------

    def nud(self):
        token = self.peek()
        kind = token.kind
        if kind == "ident":  # spec: N-000107, N-000262
            if self.peek(1).kind == "lparen":
                return self._function_call()
            self.advance()
            return N.Field(token.value)
        if kind == "qident":  # spec: N-000110..N-000114, N-000321, N-000322
            self.advance()
            following = self.peek()
            if following.kind == "lparen":
                raise self._syntax(following)
            return N.Field(token.value)
        if kind == "at":  # spec: N-000213 (the current value)
            self.advance()
            return N.Current()
        if kind == "star":  # spec: N-000163, N-000200, N-000201
            self.advance()
            return N.ObjectProjection(self._projection_rhs(BP_PROJECTION))
        if kind == "amp":  # spec: N-000231..N-000236
            self.advance()
            return N.ExpressionRefNode(self.parse_expression(0))
        if kind == "not":  # spec: N-000253..N-000257
            self.advance()
            return N.Not(self.parse_expression(BP_NOT_OPERAND))
        if kind == "lparen":
            self.advance()
            node = self.parse_expression(0)
            self._expect("rparen")
            return node
        if kind == "lbracket":  # spec: N-000126, N-000145, N-000158, N-000213
            return self._bracket_node(allow_multi=True)
        if kind == "lbrace":  # spec: N-000206
            return self._multihash()
        if kind in ("raw", "literal"):  # spec: N-000223, N-000227
            self.advance()
            return N.Literal(token.value)
        raise self._unexpected(token)
