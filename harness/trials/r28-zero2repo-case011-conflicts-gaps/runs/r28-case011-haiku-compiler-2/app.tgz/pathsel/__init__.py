"""pathsel: evaluate PathSel expressions against ordinary Python data.

Public names: `search`, `compile`, the failure types, and the provider API
(in `pathsel.functions`). Importing performs no I/O (spec: N-000371).
"""

from .errors import (
    EmptyExpressionError,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    PathSelError,
    PathSelSyntaxError,
    PathSelTokenSyntaxError,
    UnknownFunctionError,
    ZeroSliceStepError,
)
from .evaluator import Parsed
from .functions import Functions, signature
from .parser import parse as _parse
from .values import ExpressionReference

__all__ = [
    "search",
    "compile",
    "Parsed",
    "Functions",
    "signature",
    "ExpressionReference",
    "PathSelError",
    "EmptyExpressionError",
    "IncompleteExpressionError",
    "PathSelSyntaxError",
    "PathSelTokenSyntaxError",
    "ZeroSliceStepError",
    "UnknownFunctionError",
    "InvalidArityError",
    "InvalidTypeError",
]


# spec: N-000372, N-000375..N-000382
def search(expression, data, options=None):
    """Evaluate `expression` against `data` in one shot and return the selected value."""
    return compile(expression).search(data, options)


# spec: N-000373, N-000383..N-000385
def compile(expression):  # noqa: A001 - the published name (spec: N-000373)
    """Parse `expression` once and return a Parsed object that can be searched repeatedly."""
    if not isinstance(expression, str):
        raise TypeError("expression must be a str")
    return Parsed(_parse(expression), expression)
