"""Failure kinds for PathSel.

Every refusal is a ValueError (spec: N-000405). The kind is carried by the
type of the raised exception (spec: N-000406..N-000420).
"""


class PathSelError(ValueError):
    """Base of every refusal. Never raised directly."""


# spec: N-000087, N-000089, N-000409, N-000413
class EmptyExpressionError(PathSelError):
    """The zero-length expression text does not succeed."""


# spec: N-000090..N-000093, N-000410, N-000421, N-000422
class IncompleteExpressionError(PathSelError):
    """The text ends where an operand or a closing token is still required."""

    def __init__(self, message, lex_position):
        super().__init__(message)
        self.lex_position = int(lex_position)


# spec: N-000094, N-000095, N-000411, N-000421, N-000422
class PathSelSyntaxError(PathSelError):
    """A grammar-level syntax failure (also the base of token-level failures)."""

    def __init__(self, message, lex_position):
        super().__init__(message)
        self.lex_position = int(lex_position)


# spec: N-000096..N-000101, N-000412, N-000413, N-000414
class PathSelTokenSyntaxError(PathSelSyntaxError):
    """A token-level syntax failure: a more specific form of the syntax kind."""


# spec: N-000152..N-000154, N-000415
class ZeroSliceStepError(PathSelError):
    """A slice whose step is 0."""


# spec: N-000264, N-000344, N-000416, N-000418
class UnknownFunctionError(PathSelError):
    """A function name that is neither built in nor supplied by the provider."""


# spec: N-000265, N-000311..N-000313, N-000417, N-000419
class InvalidArityError(PathSelError):
    """A function called with the wrong number of arguments."""


# spec: N-000266, N-000314..N-000320, N-000418, N-000419
class InvalidTypeError(PathSelError):
    """A function argument outside its accepted types."""
