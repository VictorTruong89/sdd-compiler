"""Evaluation context and the parsed-expression object."""

from .errors import UnknownFunctionError
from .functions import find_function


class Context:
    """Per-search settings taken from the evaluation options (spec: N-000328..N-000343).

    `dict_cls` is the mapping type for constructed hashes (None means the host
    dict). `provider` is an object whose `_func_<name>` methods extend the
    built-in set (None means built-ins only).
    """

    __slots__ = ("dict_cls", "provider")

    def __init__(self, dict_cls=None, provider=None):
        self.dict_cls = dict_cls
        self.provider = provider

    # spec: N-000389..N-000392
    @classmethod
    def from_options(cls, options):
        if options is None:
            return cls()
        return cls(
            getattr(options, "dict_cls", None),
            getattr(options, "custom_functions", None),
        )

    # spec: N-000328..N-000334
    def new_mapping(self):
        if self.dict_cls is None:
            return {}
        return self.dict_cls()

    # spec: N-000262, N-000344
    def resolve_function(self, name):
        found = find_function(self.provider, name)
        if found is None:
            raise UnknownFunctionError("unknown function %r" % (name,))
        return found


class Parsed:
    """A compiled expression. Search it any number of times (spec: N-000078, N-000079)."""

    __slots__ = ("_root", "expression")

    def __init__(self, root, expression):
        self._root = root
        self.expression = expression

    # spec: N-000386..N-000388
    def search(self, value, options=None):
        return self._root.eval(value, Context.from_options(options))

    def __repr__(self):
        return "<pathsel.Parsed %r>" % (self.expression,)
