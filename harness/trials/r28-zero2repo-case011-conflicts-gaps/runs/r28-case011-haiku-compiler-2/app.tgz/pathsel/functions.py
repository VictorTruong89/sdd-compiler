"""Built-in functions and the provider API (pathsel.functions).

`Functions` implements the built-in set. A caller extends it by subclassing and
adding `_func_<name>` methods decorated with `signature(...)`. Importing this
module performs no I/O (spec: N-000371).
"""

import functools
import json
import math
import re
from collections.abc import Mapping
from decimal import Decimal

from .errors import InvalidArityError, InvalidTypeError
from .values import (
    ExpressionReference,
    is_array,
    is_number,
    is_object,
    json_equal,
    known_type_name,
    matches_type,
    object_keys,
    object_values,
)


class Signature:
    """Declared arity and argument types of one function."""

    __slots__ = ("params", "variadic")

    def __init__(self, params, variadic):
        self.params = tuple(params)
        self.variadic = variadic

    # spec: N-000311..N-000313, N-000417, N-000419
    def check_arity(self, count):
        expected = len(self.params)
        ok = count >= expected if self.variadic else count == expected
        if not ok:
            raise InvalidArityError(
                "wrong number of arguments: got %d, expected %s%d"
                % (count, "at least " if self.variadic else "", expected)
            )

    # spec: N-000314..N-000320, N-000418, N-000419
    def check_types(self, values):
        last = len(self.params) - 1
        for index, value in enumerate(values):
            if self.variadic and index > last:
                types = self.params[last]
            else:
                types = self.params[index]
            if not any(matches_type(name, value) for name in types):
                raise InvalidTypeError(
                    "argument %d has the wrong type (expected %s)"
                    % (index + 1, " or ".join(types))
                )


# spec: N-000401, N-000402, N-000403, N-000404
def signature(*arguments):
    """Declare argument types for a `_func_<name>` implementation.

    Each argument is a mapping {"types": [type-name, ...]}. Type names are
    "number", "string", "array", "object" and "null" for custom functions;
    the other known names exist for the built-ins. Returns a decorator that
    wraps the implementation without calling it.
    """
    params = []
    variadic = False
    for argument in arguments:
        if not isinstance(argument, Mapping) or "types" not in argument:
            raise TypeError("each signature argument must be a mapping with 'types'")
        types = tuple(argument["types"])
        if not types:
            raise ValueError("a signature argument needs at least one type")
        for name in types:
            if not known_type_name(name):
                raise ValueError("unknown type name %r" % (name,))
        if argument.get("variadic"):
            variadic = True
        params.append(types)
    if variadic and not params:
        raise ValueError("a variadic signature needs at least one argument")
    declared = Signature(params, variadic)

    def decorate(implementation):
        @functools.wraps(implementation)
        def wrapper(self, *args):
            return implementation(self, *args)

        wrapper._pathsel_signature = declared
        return wrapper

    return decorate


# spec: N-000262, N-000393..N-000400
class Functions:
    """The provider of built-in functions. Subclass to add custom functions."""

    # spec: N-000269
    @signature({"types": ["number"]})
    def _func_abs(self, value):
        return abs(value)

    # spec: N-000270, N-000271
    @signature({"types": ["array_of_numbers"]})
    def _func_avg(self, values):
        if not values:
            return None
        return sum(values) / len(values)

    # spec: N-000272
    @signature({"types": ["number"]})
    def _func_ceil(self, value):
        return math.ceil(value)

    # spec: N-000273
    @signature({"types": ["number"]})
    def _func_floor(self, value):
        return math.floor(value)

    # spec: N-000274, N-000275
    @signature({"types": ["array", "string"]}, {"types": ["any"]})
    def _func_contains(self, haystack, needle):
        if isinstance(haystack, str):
            if not isinstance(needle, str):
                raise InvalidTypeError("contains on a string needs a string")
            return needle in haystack
        return any(json_equal(item, needle) for item in haystack)

    # spec: N-000276
    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_ends_with(self, text, suffix):
        return text.endswith(suffix)

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_starts_with(self, text, prefix):
        return text.startswith(prefix)

    # spec: N-000277 (CF-000035 resolved as code points; see NOTES.md)
    @signature({"types": ["string", "array", "object"]})
    def _func_length(self, value):
        if isinstance(value, str):
            return len(value)
        if is_array(value):
            return len(value)
        return len(object_keys(value))

    # spec: N-000278
    @signature({"types": ["array", "string"]})
    def _func_reverse(self, value):
        if isinstance(value, str):
            return value[::-1]
        return list(reversed(value))

    # spec: N-000279, N-000280
    @signature({"types": ["string"]}, {"types": ["array_of_strings"]})
    def _func_join(self, separator, parts):
        return separator.join(parts)

    # spec: N-000281
    @signature({"types": ["object"]})
    def _func_keys(self, value):
        return object_keys(value)

    @signature({"types": ["object"]})
    def _func_values(self, value):
        return object_values(value)

    # spec: N-000282
    @signature({"types": ["any"]})
    def _func_type(self, value):
        if value is None:
            return "null"
        if isinstance(value, bool):
            return "boolean"
        if is_number(value):
            return "number"
        if isinstance(value, str):
            return "string"
        if is_array(value):
            return "array"
        if is_object(value):
            return "object"
        return None

    # spec: N-000283
    @signature({"types": ["any"]})
    def _func_to_array(self, value):
        if isinstance(value, list):
            return value
        if isinstance(value, tuple):
            return list(value)
        return [value]

    # spec: N-000284, N-000285
    @signature({"types": ["any"]})
    def _func_to_string(self, value):
        if isinstance(value, str):
            return value
        return json.dumps(_plain_json(value), separators=(",", ":"))

    # spec: N-000286..N-000289
    @signature({"types": ["any"]})
    def _func_to_number(self, value):
        if is_number(value):
            return value
        if isinstance(value, str):
            if _INTEGER_NUMERAL.match(value):
                return int(value)
            if _DECIMAL_NUMERAL.match(value):
                return float(value)
        return None

    # spec: N-000290..N-000292
    @signature({"types": ["array_of_numbers_or_strings"]})
    def _func_max(self, values):
        if not values:
            return None
        return max(values)

    @signature({"types": ["array_of_numbers_or_strings"]})
    def _func_min(self, values):
        if not values:
            return None
        return min(values)

    # spec: N-000293
    @signature({"types": ["array_of_numbers_or_strings"]})
    def _func_sort(self, values):
        return sorted(values)

    # spec: N-000294
    @signature({"types": ["array_of_numbers"]})
    def _func_sum(self, values):
        return sum(values)

    # spec: N-000295..N-000297
    @signature({"types": ["object"], "variadic": True})
    def _func_merge(self, *objects):
        merged = {}
        for source in objects:
            for key in object_keys(source):
                merged[key] = source[key]
        return merged

    # spec: N-000298..N-000300
    @signature({"types": ["any"], "variadic": True})
    def _func_not_null(self, *values):
        for value in values:
            if value is not None:
                return value
        return None

    # spec: N-000301, N-000302
    @signature({"types": ["ref"]}, {"types": ["array"]})
    def _func_map(self, reference, values):
        return [reference.evaluate(item) for item in values]

    # spec: N-000303..N-000305
    @signature({"types": ["array"]}, {"types": ["ref"]})
    def _func_sort_by(self, values, reference):
        keys = [reference.evaluate(item) for item in values]
        _key_kind(keys)
        order = sorted(range(len(values)), key=lambda index: keys[index])
        return [values[index] for index in order]

    # spec: N-000306..N-000308
    @signature({"types": ["array"]}, {"types": ["ref"]})
    def _func_max_by(self, values, reference):
        return _extreme_by(values, reference, greater=True)

    @signature({"types": ["array"]}, {"types": ["ref"]})
    def _func_min_by(self, values, reference):
        return _extreme_by(values, reference, greater=False)


_INTEGER_NUMERAL = re.compile(r"[+-]?[0-9]+\Z")
_DECIMAL_NUMERAL = re.compile(r"[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?\Z")


# spec: N-000303..N-000308, N-000318
def _key_kind(keys):
    """Every sort key must be a number, or every key a string (spec: N-000319/N-000320)."""
    if all(is_number(key) for key in keys):
        return "number"
    if all(isinstance(key, str) for key in keys):
        return "string"
    raise InvalidTypeError("sort key must be all numbers or all strings")


def _extreme_by(values, reference, greater):
    if not values:
        return None
    keys = [reference.evaluate(item) for item in values]
    _key_kind(keys)
    best = 0
    for index in range(1, len(values)):
        if (keys[index] > keys[best]) if greater else (keys[index] < keys[best]):
            best = index
    return values[best]


def _plain_json(value):
    """Convert a value to plain JSON-compatible Python data for serialization."""
    if value is None or isinstance(value, (bool, str)):
        return value
    if is_number(value):
        return value
    if isinstance(value, Decimal):
        return float(value)
    if is_array(value):
        return [_plain_json(item) for item in value]
    if is_object(value):
        return {key: _plain_json(value[key]) for key in object_keys(value)}
    return str(value)


DEFAULT_PROVIDER = Functions()


# spec: N-000262, N-000336, N-000337
def find_function(provider, name):
    """Return (bound implementation, Signature) for a function name, or None.

    The built-in provider is consulted first, so every built-in name keeps its
    built-in behaviour on every search (spec: N-000339, N-000340). Names that
    are not built in come from the attached provider.
    """
    for candidate in (DEFAULT_PROVIDER, provider):
        if candidate is None:
            continue
        implementation = getattr(candidate, "_func_" + name, None)
        declared = getattr(implementation, "_pathsel_signature", None)
        if declared is not None:
            return implementation, declared
    return None


__all__ = ["Functions", "signature", "ExpressionReference"]
