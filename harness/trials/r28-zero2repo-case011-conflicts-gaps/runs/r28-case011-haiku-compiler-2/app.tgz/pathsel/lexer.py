"""Tokenizer for PathSel expressions.

Tokens are produced on demand by the parser, so a token-level failure is
raised only when the parser reaches the text that cannot be read. This keeps
the reported position the first place where the expression goes wrong
(spec: N-000102..N-000104).
"""

import json
import string

from .errors import PathSelTokenSyntaxError

_WHITESPACE = " \t\r\n"  # spec: N-000109
_IDENT_START = frozenset(string.ascii_letters + "_")  # spec: N-000107
_IDENT_BODY = _IDENT_START | frozenset(string.digits)
_DIGITS = frozenset(string.digits)
_HEX = frozenset(string.hexdigits)

_SINGLE = {
    ".": "dot",
    "*": "star",
    ",": "comma",
    ":": "colon",
    "?": "question",
    "[": "lbracket",
    "]": "rbracket",
    "(": "lparen",
    ")": "rparen",
    "{": "lbrace",
    "}": "rbrace",
    "@": "at",
}


class Token:
    """A lexical token. `pos` is the zero-based character offset where it begins."""

    __slots__ = ("kind", "value", "pos")

    def __init__(self, kind, value, pos):
        self.kind = kind
        self.value = value
        self.pos = pos

    def __repr__(self):
        return "Token(%s, %r, %d)" % (self.kind, self.value, self.pos)


class Lexer:
    def __init__(self, text):
        self.text = text
        self.length = len(text)
        self.index = 0

    def _token_error(self, pos, message):
        return PathSelTokenSyntaxError(message, pos)

    def next_token(self):
        text = self.text
        length = self.length
        while self.index < length and text[self.index] in _WHITESPACE:
            self.index += 1
        if self.index >= length:
            return Token("eof", None, length)
        start = self.index
        char = text[start]
        following = text[start + 1] if start + 1 < length else ""

        if char in _IDENT_START:  # spec: N-000107
            end = start + 1
            while end < length and text[end] in _IDENT_BODY:
                end += 1
            self.index = end
            return Token("ident", text[start:end], start)

        # spec: N-000119, N-000120, N-000121 (a hyphen begins a number only before a digit)
        if char in _DIGITS or (char == "-" and following in _DIGITS):
            end = start + 1
            while end < length and text[end] in _DIGITS:
                end += 1
            self.index = end
            return Token("number", int(text[start:end]), start)

        if char == "-":
            raise self._token_error(start, "a lone hyphen begins no token")

        if char == '"':  # spec: N-000110..N-000114, N-000124
            value, end = self._scan_quoted_identifier(start)
            self.index = end
            return Token("qident", value, start)

        if char == "'":  # spec: N-000227..N-000230
            value, end = self._scan_raw_string(start)
            self.index = end
            return Token("raw", value, start)

        if char == "`":  # spec: N-000223..N-000226, N-000237
            value, end = self._scan_json_literal(start)
            self.index = end
            return Token("literal", value, start)

        if char == "=":  # spec: N-000260
            if following == "=":
                self.index = start + 2
                return Token("eq", "==", start)
            raise self._token_error(start, "a lone '=' begins no token; use '=='")
        if char == "!":  # spec: N-000251
            if following == "=":
                self.index = start + 2
                return Token("ne", "!=", start)
            self.index = start + 1
            return Token("not", "!", start)
        if char == "<":  # spec: N-000245
            if following == "=":
                self.index = start + 2
                return Token("lte", "<=", start)
            self.index = start + 1
            return Token("lt", "<", start)
        if char == ">":
            if following == "=":
                self.index = start + 2
                return Token("gte", ">=", start)
            self.index = start + 1
            return Token("gt", ">", start)
        if char == "|":  # spec: N-000219
            if following == "|":
                self.index = start + 2
                return Token("or", "||", start)
            self.index = start + 1
            return Token("pipe", "|", start)
        if char == "&":  # spec: N-000231, N-000247
            if following == "&":
                self.index = start + 2
                return Token("and", "&&", start)
            self.index = start + 1
            return Token("amp", "&", start)
        if char in _SINGLE:
            self.index = start + 1
            return Token(_SINGLE[char], char, start)
        raise self._token_error(start, "character %r begins no token" % char)

    # spec: N-000110..N-000114, N-000124
    def _scan_quoted_identifier(self, start):
        text = self.text
        end = start + 1
        while end < self.length:
            char = text[end]
            if char == "\\":
                end += 2
                continue
            if char == '"':
                try:
                    value = json.loads(text[start : end + 1])
                except ValueError:
                    raise self._token_error(
                        start, "quoted identifier is not a legal JSON string"
                    )
                return value, end + 1
            end += 1
        raise self._token_error(start, "unterminated quoted identifier")

    # spec: N-000227..N-000230, N-000239 (CF-000049: \uXXXX decoded, other backslashes literal)
    def _scan_raw_string(self, start):
        text = self.text
        length = self.length
        parts = []
        end = start + 1
        while end < length:
            char = text[end]
            if char == "\\" and end + 1 < length:
                nxt = text[end + 1]
                if nxt == "'":
                    parts.append("'")
                    end += 2
                    continue
                if nxt == "u" and end + 6 <= length and all(c in _HEX for c in text[end + 2 : end + 6]):
                    parts.append(chr(int(text[end + 2 : end + 6], 16)))
                    end += 6
                    continue
                parts.append("\\")
                end += 1
                continue
            if char == "'":
                return "".join(parts), end + 1
            parts.append(char)
            end += 1
        raise self._token_error(start, "unterminated raw string literal")

    # spec: N-000223..N-000226, N-000237
    def _scan_json_literal(self, start):
        close = self.text.find("`", start + 1)
        if close < 0:
            raise self._token_error(start, "unterminated JSON literal")
        body = self.text[start + 1 : close]
        try:
            return json.loads(body), close + 1
        except ValueError:
            pass
        try:
            return json.loads('"' + body.lstrip(_WHITESPACE) + '"'), close + 1
        except ValueError:
            raise self._token_error(start, "JSON literal is neither JSON nor string content")
