"""Value model: type predicates, truthiness, JSON equality and references.

Arrays are Python lists/tuples, objects are mappings, strings are str,
numbers are int/float (not bool), booleans are bool, null is None.
Host decimals count as numbers in comparisons (spec: N-000056, N-000246).
"""

from collections.abc import Mapping
from decimal import Decimal


# spec: N-000026, N-000056, N-000057, N-000058
def is_number(value):
    """A JSON number: int or float, never bool."""
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def is_orderable_number(value):
    """Numbers for comparison purposes: JSON numbers plus host decimals (N-000056)."""
    return is_number(value) or isinstance(value, Decimal)


def is_array(value):
    return isinstance(value, (list, tuple))


# spec: N-000023, N-000038
def is_object(value):
    """A mapping. Constructed hashes of any supplied mapping type count (N-000330)."""
    if isinstance(value, Mapping):
        return True
    if isinstance(value, (str, bytes, list, tuple)):
        return False
    return hasattr(value, "keys") and hasattr(value, "__getitem__")


def object_keys(value):
    return list(value.keys())


def object_values(value):
    return [value[key] for key in value.keys()]


# spec: N-000251, N-000252, N-000254..N-000257
def truthy(value):
    """Truthiness: false values are false, null, "", [], {} (N-000251/N-000252)."""
    if value is None or value is False:
        return False
    if isinstance(value, str) or is_array(value):
        return len(value) > 0
    if is_object(value):
        return len(value.keys()) > 0
    return True


# spec: N-000242, N-000243, N-000244
def json_equal(left, right):
    """JSON value equality: deep for arrays/objects; a number is never a boolean."""
    if isinstance(left, bool) or isinstance(right, bool):
        return isinstance(left, bool) and isinstance(right, bool) and left == right
    if left is None or right is None:
        return left is None and right is None
    if is_orderable_number(left) and is_orderable_number(right):
        return left == right
    if isinstance(left, str) and isinstance(right, str):
        return left == right
    if is_array(left) and is_array(right):
        if len(left) != len(right):
            return False
        return all(json_equal(a, b) for a, b in zip(left, right))
    if is_object(left) and is_object(right):
        left_keys = set(left.keys())
        if left_keys != set(right.keys()):
            return False
        return all(json_equal(left[k], right[k]) for k in left_keys)
    return False


class ExpressionReference:
    """A deferred subexpression (spec: N-000231..N-000236, N-000423).

    Built-in functions that take a reference apply it to each element with
    `evaluate`. Searching a bare reference returns one of these objects.
    """

    __slots__ = ("node", "context")

    def __init__(self, node, context):
        self.node = node
        self.context = context

    def evaluate(self, value):
        return self.node.eval(value, self.context)

    def __repr__(self):
        return "<ExpressionReference>"


# spec: N-000338, N-000402, N-000401, N-000318..N-000320
_TYPE_NAMES = frozenset(
    [
        "any",
        "number",
        "string",
        "boolean",
        "null",
        "array",
        "object",
        "ref",
        "array_of_numbers",
        "array_of_strings",
        "array_of_numbers_or_strings",
        "array_or_string",
        "array_or_object",
    ]
)


def known_type_name(name):
    return name in _TYPE_NAMES


def matches_type(name, value):
    """Whether a value satisfies one declared type name (spec: N-000314..N-000320)."""
    if name == "any":
        return True
    if name == "number":
        return is_number(value)
    if name == "string":
        return isinstance(value, str)
    if name == "boolean":
        return isinstance(value, bool)
    if name == "null":
        return value is None
    if name == "array":
        return is_array(value)
    if name == "object":
        return is_object(value)
    if name == "ref":
        return isinstance(value, ExpressionReference)
    if name == "array_of_numbers":
        return is_array(value) and all(is_number(v) for v in value)
    if name == "array_of_strings":
        return is_array(value) and all(isinstance(v, str) for v in value)
    if name == "array_of_numbers_or_strings":
        return is_array(value) and (
            all(is_number(v) for v in value) or all(isinstance(v, str) for v in value)
        )
    if name == "array_or_string":
        return is_array(value) or isinstance(value, str)
    if name == "array_or_object":
        return is_array(value) or is_object(value)
    return False
