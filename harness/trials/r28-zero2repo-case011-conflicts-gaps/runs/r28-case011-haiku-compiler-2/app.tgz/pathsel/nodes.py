"""AST nodes. Every node evaluates against a current value and a context.

Operands of a binary operator are evaluated against the same current value.
Subexpressions (`a.b`, pipes) evaluate the right side against the left result
(see `Sub`). Projections apply their right-hand side to each element and drop
null results (spec: N-000159..N-000205).
"""

import copy

from .values import (
    ExpressionReference,
    is_array,
    is_object,
    is_orderable_number,
    json_equal,
    object_values,
    truthy,
)


def _project(items, rhs, context):
    """Apply rhs to each item and collect the non-null results (spec: N-000160, N-000204)."""
    out = []
    for item in items:
        result = rhs.eval(item, context)
        if result is not None:
            out.append(result)
    return out


# spec: N-000225..N-000227, N-000258..N-000259 (Current is the `@` token)
class Current:
    def eval(self, value, context):
        return value


class Field:
    """An identifier or quoted identifier applied to the current value (spec: N-000107..N-000116)."""

    __slots__ = ("name",)

    def __init__(self, name):
        self.name = name

    # spec: N-000083, N-000115, N-000116, N-000125
    def eval(self, value, context):
        if not is_object(value):
            return None
        try:
            return value[self.name]
        except KeyError:
            return None


class Index:
    """A single integer index; negative counts from the end (spec: N-000126..N-000129)."""

    __slots__ = ("index",)

    def __init__(self, index):
        self.index = index

    def eval(self, value, context):
        if not is_array(value):
            return None
        try:
            return value[self.index]
        except IndexError:
            return None


class Sub:
    """Evaluate `right` against the result of `left` (dot chains, pipes)."""

    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, value, context):
        return self.right.eval(self.left.eval(value, context), context)


class Or:
    # spec: N-000247, N-000248
    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, value, context):
        result = self.left.eval(value, context)
        if truthy(result):
            return result
        return self.right.eval(value, context)


class And:
    # spec: N-000249, N-000250
    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, value, context):
        result = self.left.eval(value, context)
        if not truthy(result):
            return result
        return self.right.eval(value, context)


class Not:
    # spec: N-000251, N-000252
    def __init__(self, operand):
        self.operand = operand

    def eval(self, value, context):
        return not truthy(self.operand.eval(value, context))


class Compare:
    """Comparators. Two numbers or two strings order; mismatched types give null."""

    __slots__ = ("op", "left", "right")

    def __init__(self, op, left, right):
        self.op = op
        self.left = left
        self.right = right

    def eval(self, value, context):
        left = self.left.eval(value, context)
        right = self.right.eval(value, context)
        if self.op == "eq":
            return json_equal(left, right)  # spec: N-000242
        if self.op == "ne":
            return not json_equal(left, right)  # spec: N-000243
        orderable = (is_orderable_number(left) and is_orderable_number(right)) or (
            isinstance(left, str) and isinstance(right, str)
        )
        if not orderable:
            return None  # spec: N-000245, N-000246 (mismatched types: null, chosen)
        if self.op == "lt":
            return left < right
        if self.op == "lte":
            return left <= right
        if self.op == "gt":
            return left > right
        return left >= right


class Literal:
    """A JSON literal, a raw string, or any fixed value (spec: N-000223, N-000227)."""

    __slots__ = ("value",)

    def __init__(self, value):
        self.value = value

    def eval(self, value, context):
        if isinstance(self.value, (dict, list)):
            return copy.deepcopy(self.value)
        return self.value


class ExpressionRefNode:
    """`&expr`: yields a reference that builtins apply later (spec: N-000231..N-000236)."""

    __slots__ = ("node",)

    def __init__(self, node):
        self.node = node

    def eval(self, value, context):
        return ExpressionReference(self.node, context)


class MultiList:
    """`[e1, e2]` (spec: N-000211, N-000212, N-000218, N-000213..N-000217)."""

    __slots__ = ("items",)

    def __init__(self, items):
        self.items = items

    def eval(self, value, context):
        if value is None:
            return None  # spec: N-000218 (CF-000011 resolved as null, see NOTES.md)
        return [item.eval(value, context) for item in self.items]


class MultiHash:
    """`{k: e}` (spec: N-000206..N-000210)."""

    __slots__ = ("pairs",)

    def __init__(self, pairs):
        self.pairs = pairs

    def eval(self, value, context):
        if value is None:
            return None
        built = context.new_mapping()
        for key, node in self.pairs:
            built[key] = node.eval(value, context)  # a null result is stored
        return built


class ListProjection:
    """`[*]`: projects over an array (spec: N-000159..N-000162)."""

    __slots__ = ("rhs",)

    def __init__(self, rhs):
        self.rhs = rhs

    def eval(self, value, context):
        if not is_array(value):
            return None
        return _project(value, self.rhs, context)


class ObjectProjection:
    """`*` or `<expr>.*`: projects over an object's values (spec: N-000163..N-000165)."""

    __slots__ = ("rhs",)

    def __init__(self, rhs):
        self.rhs = rhs

    def eval(self, value, context):
        if not is_object(value):
            return None  # spec: N-000165 (CF-000027 resolved as null, see NOTES.md)
        return _project(object_values(value), self.rhs, context)


class Flatten:
    """`[]`: splices one level of nested arrays, then projects (spec: N-000145..N-000150)."""

    __slots__ = ("rhs",)

    def __init__(self, rhs):
        self.rhs = rhs

    def eval(self, value, context):
        if not is_array(value):
            return None
        flat = []
        for item in value:
            if is_array(item):
                flat.extend(item)
            else:
                flat.append(item)
        return _project(flat, self.rhs, context)


class FilterProjection:
    """`[?predicate]` (spec: N-000168..N-000179)."""

    __slots__ = ("predicate", "rhs")

    def __init__(self, predicate, rhs):
        self.predicate = predicate
        self.rhs = rhs

    def eval(self, value, context):
        if not is_array(value):
            return None  # spec: N-000202 (CF-000005 resolved as null, see NOTES.md)
        kept = [item for item in value if truthy(self.predicate.eval(item, context))]
        return _project(kept, self.rhs, context)


def slice_indices(length, start, stop, step):
    """Indices selected by a slice (spec: N-000130..N-000141)."""
    if step > 0:
        low = 0 if start is None else start
        high = length if stop is None else stop
        if low < 0:
            low += length
        if high < 0:
            high += length
        low = min(max(low, 0), length)
        high = min(max(high, 0), length)
    else:
        # Omitted bounds are the array ends; they are not shifted by the length.
        low = length - 1 if start is None else start
        high = -1 if stop is None else stop
        if start is not None and low < 0:
            low += length
        if stop is not None and high < 0:
            high += length
        low = min(max(low, -1), length - 1)
        high = min(max(high, -1), length - 1)
    return range(low, high, step)


class SliceProjection:
    """`[start:stop:step]` (spec: N-000130..N-000144)."""

    __slots__ = ("start", "stop", "step", "rhs")

    def __init__(self, start, stop, step, rhs):
        self.start = start
        self.stop = stop
        self.step = step
        self.rhs = rhs

    def eval(self, value, context):
        if not is_array(value):
            return None  # spec: N-000142 (CF-000007 resolved as null, see NOTES.md)
        selected = [value[i] for i in slice_indices(len(value), self.start, self.stop, self.step)]
        return _project(selected, self.rhs, context)


class Call:
    """A built-in or custom function call (spec: N-000262..N-000310)."""

    __slots__ = ("name", "args")

    def __init__(self, name, args):
        self.name = name
        self.args = args

    def eval(self, value, context):
        found = context.resolve_function(self.name)  # UnknownFunctionError
        implementation, declared = found
        declared.check_arity(len(self.args))  # InvalidArityError
        arguments = [arg.eval(value, context) for arg in self.args]
        declared.check_types(arguments)  # InvalidTypeError
        return implementation(*arguments)
