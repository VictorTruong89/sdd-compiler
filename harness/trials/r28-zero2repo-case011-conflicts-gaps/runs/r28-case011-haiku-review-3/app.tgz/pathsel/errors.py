"""Refusal types for pathsel.

Every refusal is a ``ValueError``. The kind of a refusal is carried by the
type of the raised exception (see spec/Interface_Contract.md, "Failure carriers").
"""


class PathSelError(ValueError):
    """Base class of every refusal."""


class EmptyExpressionError(PathSelError):
    """The expression text has zero length."""


class _PositionedError(PathSelError):
    """A refusal that reports the offset at which it was detected."""

    def __init__(self, message, lex_position):
        super().__init__(message)
        self.lex_position = int(lex_position)


class IncompleteExpressionError(_PositionedError):
    """Text ended where an operand or a closing delimiter was still required."""


class PathSelSyntaxError(_PositionedError):
    """Grammar-level syntax failure."""


class TokenSyntaxError(PathSelSyntaxError):
    """Token-level syntax failure: a more specific form of the syntax kind."""


class ZeroSliceStepError(PathSelError):
    """A slice whose step is 0."""


class UnknownFunctionError(PathSelError):
    """A function name that is neither built-in nor supplied by the provider."""


class InvalidArityError(PathSelError):
    """A function call with the wrong number of arguments."""


class InvalidTypeError(PathSelError):
    """A function argument outside its accepted types."""
