"""Parser for PathSel expressions and the compile entry.

Structure:

* Binary levels, loosest first: pipe, ``||``, ``&&``, comparators.
* A unit is an optional ``!`` followed by a primary and a run of steps.
* Steps form a flat sequence that is then nested into projections using the
  ranks of spec FP-04 ("Reach of a projection"):

  - A projection's right-hand side starts with the step written directly after
    its form (if that step is a dot step, an index/slice/list-wildcard bracket,
    a multiselect list or a filter). Later steps join it only when their join
    rank is tighter than the projection's own rank.
  - Join ranks of steps: flatten 1, filter 3, dot step 4, bracket step 5.
  - Projection ranks: flatten 1, filter 3, list wildcard / slice / object
    wildcard at the start of an operand or of a right-hand side 2, object
    wildcard written after a dot 4 (2 when it starts a right-hand side).
  - A list wildcard or slice written as a later step is a projection with
    rank 2 but joins an enclosing projection with join rank 5.
"""

from . import nodes as N
from .errors import (
    EmptyExpressionError,
    IncompleteExpressionError,
    PathSelSyntaxError,
    ZeroSliceStepError,
)
from .lexer import (
    AMP,
    AND,
    AT,
    COLON,
    COMMA,
    DOT,
    EOF,
    EQ,
    GE,
    GT,
    IDENT,
    LBRACE,
    LBRACKET,
    LE,
    LITERAL,
    LPAREN,
    LT,
    NE,
    NOT,
    NUMBER,
    OR,
    PIPE,
    QIDENT,
    QMARK,
    RAW,
    RBRACE,
    RBRACKET,
    RPAREN,
    STAR,
    tokenize,
)
from .values import Context

_CMP_KINDS = (EQ, NE, LT, LE, GT, GE)
_NO_RHS = ()


class _Parser:
    def __init__(self, text, tokens):
        self.text = text
        self.tokens = tokens
        self.pos = 0

    # -- token helpers -------------------------------------------------------

    def _tok(self):
        return self.tokens[self.pos]

    def _kind(self):
        return self.tokens[self.pos].kind

    def _advance(self):
        t = self.tokens[self.pos]
        if t.kind != EOF:
            self.pos += 1
        return t

    def _error_at(self, t):
        if t.kind == EOF:
            return IncompleteExpressionError("expression is incomplete", t.pos)
        return PathSelSyntaxError("unexpected token at offset %d" % t.pos, t.pos)

    def _expect(self, kind):
        t = self._tok()
        if t.kind != kind:
            raise self._error_at(t)
        return self._advance()

    # -- binary levels -------------------------------------------------------

    def parse_expr(self):
        left = self._parse_or()
        while self._kind() == PIPE:
            self._advance()
            left = N.Pipe(left, self._parse_or())
        return left

    def _parse_or(self):
        left = self._parse_and()
        while self._kind() == OR:
            self._advance()
            left = N.Or(left, self._parse_and())
        return left

    def _parse_and(self):
        left = self._parse_cmp()
        while self._kind() == AND:
            self._advance()
            left = N.And(left, self._parse_cmp())
        return left

    def _parse_cmp(self):
        left = self._parse_unit()
        while self._kind() in _CMP_KINDS:
            op = self._advance().kind
            left = N.Compare(op, left, self._parse_unit())
        return left

    # -- units ---------------------------------------------------------------

    def _parse_unit(self, restricted=False):
        t = self._tok()
        kind = t.kind
        if kind == NOT:
            self._advance()
            inner = self._parse_unit(restricted=True)
            ops = [N.NotOp(inner)]
            ops.extend(self._parse_items(None, None, restricted))
            return N.Chain(ops)
        if kind == EOF:
            raise self._error_at(t)
        if kind == LBRACKET or kind == STAR:
            return N.Chain(self._parse_items(None, "primary", restricted))
        if kind == IDENT:
            self._advance()
            if self._kind() == LPAREN:
                op = self._parse_call(t.value)
            else:
                op = N.Field(t.value)
        elif kind == QIDENT:
            self._advance()
            op = N.Field(t.value)
        elif kind == LPAREN:
            self._advance()
            expr = self.parse_expr()
            self._expect(RPAREN)
            op = N.Sub(expr)
        elif kind == AT:
            self._advance()
            op = N.Identity()
        elif kind == AMP:
            self._advance()
            op = N.RefOp(self.parse_expr())
        elif kind == LITERAL or kind == RAW:
            self._advance()
            op = N.Literal(t.value)
        elif kind == LBRACE:
            op = self._parse_multi()
        else:
            raise self._error_at(t)
        ops = [op]
        ops.extend(self._parse_items(None, None, restricted))
        return N.Chain(ops)

    def _parse_call(self, name):
        self._advance()  # '('
        args = []
        if self._kind() == RPAREN:
            self._advance()
            return N.Call(name, args)
        args.append(self.parse_expr())
        while self._kind() == COMMA:
            self._advance()
            args.append(self.parse_expr())
        self._expect(RPAREN)
        return N.Call(name, args)

    def _parse_multi(self):
        t = self._tok()
        if t.kind == LBRACKET:
            self._advance()
            exprs = [self.parse_expr()]
            while self._kind() == COMMA:
                self._advance()
                exprs.append(self.parse_expr())
            self._expect(RBRACKET)
            return N.MultiList(exprs)
        # LBRACE: multiselect hash
        self._advance()
        pairs = []
        while True:
            key_tok = self._tok()
            if key_tok.kind not in (IDENT, QIDENT):
                raise self._error_at(key_tok)
            self._advance()
            self._expect(COLON)
            pairs.append((key_tok.value, self.parse_expr()))
            if self._kind() == COMMA:
                self._advance()
                continue
            self._expect(RBRACE)
            return N.MultiHash(pairs)

    # -- steps ---------------------------------------------------------------

    def _parse_items(self, threshold, first, restricted):
        """Parse steps; ``first`` is None, 'primary' or 'rhs' for the first step.

        ``threshold`` is the rank of the enclosing projection (None at the top
        level). ``restricted`` (inside ``!``) allows only index, slice and list
        wildcard brackets.
        """
        ops = []
        while True:
            form = self._classify(first)
            if form is None:
                break
            name, join_rank = form
            if first is None:
                if threshold is not None and join_rank <= threshold:
                    break
                if restricted and name not in ("idxslice", "listwild"):
                    break
            ops.append(self._consume(name, first))
            first = None
        return ops

    def _classify(self, first):
        """Identify the step at the current token: (form, join_rank) or None."""
        t = self._tok()
        kind = t.kind
        if kind == DOT:
            nxt = self.tokens[self.pos + 1]
            if nxt.kind in (IDENT, QIDENT):
                return ("dotfield", 4)
            if nxt.kind == STAR:
                return ("dotobj", 4)
            if nxt.kind in (LBRACKET, LBRACE):
                return ("dotmulti", 4)
            raise PathSelSyntaxError("dot must be followed by a name, a wildcard or a multiselect", nxt.pos)
        if kind == LBRACKET:
            nxt = self.tokens[self.pos + 1]
            if nxt.kind == RBRACKET:
                return None if first == "rhs" else ("flatten", 1)
            if nxt.kind == STAR:
                return ("listwild", 5)
            if nxt.kind == QMARK:
                return ("filter", 3)
            if nxt.kind in (NUMBER, COLON):
                return ("idxslice", 5)
            if nxt.kind == EOF:
                raise IncompleteExpressionError("bracket is not closed", nxt.pos)
            if first is None:
                raise PathSelSyntaxError("bracket content is not allowed after an operand", t.pos)
            return ("multi", 5)
        if kind == STAR and first == "primary":
            return ("objprim", 2)
        return None

    def _consume(self, name, first):
        if name == "dotfield":
            self._advance()
            return N.Field(self._advance().value)
        if name == "dotmulti":
            self._advance()
            return self._parse_multi()
        if name == "multi":
            return self._parse_multi()
        if name == "dotobj":
            self._advance()
            self._advance()
            threshold = 2 if first == "rhs" else 4
            return N.Projection("obj", self._parse_items(threshold, "rhs", False))
        if name == "objprim":
            self._advance()
            return N.Projection("obj", self._parse_items(2, "rhs", False))
        if name == "listwild":
            self._advance()
            self._advance()
            self._expect(RBRACKET)
            return N.Projection("list", self._parse_items(2, "rhs", False))
        if name == "flatten":
            self._advance()
            self._advance()
            return N.Projection("flatten", self._parse_items(1, "rhs", False))
        if name == "filter":
            self._advance()
            self._advance()
            pred = self.parse_expr()
            self._expect(RBRACKET)
            return N.Projection("filter", self._parse_items(3, "rhs", False), pred=pred)
        if name == "idxslice":
            return self._consume_index_or_slice()
        raise AssertionError(name)

    def _consume_index_or_slice(self):
        self._advance()  # '['
        parts = [None]
        while True:
            t = self._tok()
            if t.kind == NUMBER and parts[-1] is None:
                parts[-1] = t.value
                self._advance()
            elif t.kind == COLON:
                if len(parts) >= 3:
                    raise PathSelSyntaxError("slice has more than three parts", t.pos)
                parts.append(None)
                self._advance()
            elif t.kind == RBRACKET:
                self._advance()
                break
            else:
                raise self._error_at(t)
        if len(parts) == 1:
            if parts[0] is None:
                raise PathSelSyntaxError("empty bracket", self.pos)
            return N.Index(parts[0])
        start, stop, step = (parts + [None, None, None])[:3]
        if step == 0:
            raise ZeroSliceStepError("slice step must not be 0")
        return N.Projection("slice", self._parse_items(2, "rhs", False),
                            start=start, stop=stop, step=step)


class CompiledExpression:
    """A parsed expression that can be searched against many documents."""

    __slots__ = ("expression", "_root")

    def __init__(self, expression, root):
        self.expression = expression
        self._root = root

    def search(self, value, options=None):
        return self._root.ev(value, Context.from_options(options))

    def __repr__(self):
        return "<pathsel.CompiledExpression %r>" % (self.expression,)


def compile(expression):
    """Parse an expression once; returns a CompiledExpression or raises a refusal."""
    if not isinstance(expression, str):
        raise TypeError("expression must be a str")
    if expression == "":
        raise EmptyExpressionError("empty expression")
    parser = _Parser(expression, tokenize(expression))
    root = parser.parse_expr()
    t = parser._tok()
    if t.kind != EOF:
        raise PathSelSyntaxError("unexpected token at offset %d" % t.pos, t.pos)
    return CompiledExpression(expression, root)


def search(expression, data, options=None):
    """Evaluate an expression against a document in one call."""
    return compile(expression).search(data, options)
