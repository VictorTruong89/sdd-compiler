"""Built-in language functions and the custom-function provider interface.

``Functions`` implements the built-in set as ``_func_<name>`` methods. A caller
extends the language by subclassing it and decorating ``_func_<name>`` methods
with :func:`signature`. Nothing here performs I/O.
"""

import json
import math
import re
from collections.abc import Mapping
from decimal import Decimal

from .errors import InvalidTypeError, UnknownFunctionError
from .values import ExpressionReference, is_array, is_number, json_equal, json_kind

# name -> (minimum argument count, maximum argument count or None for unbounded)
_BUILTIN_ARITY = {
    "abs": (1, 1),
    "avg": (1, 1),
    "ceil": (1, 1),
    "contains": (2, 2),
    "ends_with": (2, 2),
    "floor": (1, 1),
    "join": (2, 2),
    "keys": (1, 1),
    "length": (1, 1),
    "map": (2, 2),
    "max": (1, 1),
    "max_by": (2, 2),
    "merge": (1, None),
    "min": (1, 1),
    "min_by": (2, 2),
    "not_null": (1, None),
    "reverse": (1, 1),
    "sort": (1, 1),
    "sort_by": (2, 2),
    "starts_with": (2, 2),
    "sum": (1, 1),
    "to_array": (1, 1),
    "to_number": (1, 1),
    "to_string": (1, 1),
    "type": (1, 1),
    "values": (1, 1),
}

_TYPE_NAMES = frozenset(("number", "string", "array", "object", "null", "boolean", "any"))

_INT_NUMERAL = re.compile(r"[+-]?[0-9]+")
_DECIMAL_NUMERAL = re.compile(r"[+-]?(?:[0-9]+\.?[0-9]*|\.[0-9]+)(?:[eE][+-]?[0-9]+)?")


def _need_number(value):
    if not is_number(value):
        raise InvalidTypeError("expected a number")


def _need_string(value):
    if not isinstance(value, str):
        raise InvalidTypeError("expected a string")


def _need_array(value):
    if not is_array(value):
        raise InvalidTypeError("expected an array")


def _need_object(value):
    if not isinstance(value, Mapping):
        raise InvalidTypeError("expected an object")


def _need_ref(value):
    if not isinstance(value, ExpressionReference):
        raise InvalidTypeError("expected an expression reference")


def _homogeneous(values):
    """Every value is a number, or every value is a string (vacuously true when empty)."""
    if all(is_number(v) for v in values) or all(isinstance(v, str) for v in values):
        return
    raise InvalidTypeError("expected all numbers or all strings")


def _sum(values):
    try:
        return sum(values)
    except TypeError:
        return float(sum(float(v) for v in values))


def _compact_json(value):
    """Compact JSON text: no spaces, non-ASCII escaped, host-style numbers."""
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, int):
        return str(int(value))
    if isinstance(value, float):
        return json.dumps(value)
    if isinstance(value, str):
        return json.dumps(value)
    if is_array(value):
        return "[" + ",".join(_compact_json(v) for v in value) + "]"
    if isinstance(value, Mapping):
        return "{" + ",".join(
            json.dumps(str(k)) + ":" + _compact_json(v) for k, v in value.items()
        ) + "}"
    raise InvalidTypeError("value has no JSON form")


def signature(*arguments):
    """Declare the argument types of a custom function.

    Each argument is ``{"types": [<type-name>, ...]}``. The decorator marks the
    implementation and returns it unchanged.
    """
    specs = []
    for argument in arguments:
        if not isinstance(argument, Mapping) or "types" not in argument:
            raise ValueError('each signature argument must be {"types": [...]}')
        types = tuple(argument["types"])
        for type_name in types:
            if type_name not in _TYPE_NAMES:
                raise ValueError("unknown type name: %r" % (type_name,))
        specs.append(types)
    specs = tuple(specs)

    def decorator(implementation):
        implementation._pathsel_sig = specs
        return implementation

    return decorator


def _matches(value, types):
    if "any" in types:
        return True
    kind = json_kind(value)
    return kind is not None and kind in types


class Functions:
    """The built-in function set; subclass it to add custom functions."""

    def _func_abs(self, x):
        _need_number(x)
        return abs(x)

    def _func_avg(self, xs):
        _need_array(xs)
        for x in xs:
            _need_number(x)
        if not xs:
            return None
        return _sum(xs) / len(xs)

    def _func_ceil(self, x):
        _need_number(x)
        return math.ceil(x)

    def _func_floor(self, x):
        _need_number(x)
        return math.floor(x)

    def _func_contains(self, haystack, needle):
        if is_array(haystack):
            return any(json_equal(item, needle) for item in haystack)
        if isinstance(haystack, str):
            _need_string(needle)
            return needle in haystack
        raise InvalidTypeError("expected an array or a string")

    def _func_ends_with(self, s, suffix):
        _need_string(s)
        _need_string(suffix)
        return s.endswith(suffix)

    def _func_starts_with(self, s, prefix):
        _need_string(s)
        _need_string(prefix)
        return s.startswith(prefix)

    def _func_join(self, separator, xs):
        _need_string(separator)
        _need_array(xs)
        for x in xs:
            _need_string(x)
        if not xs:
            return None
        return separator.join(xs)

    def _func_keys(self, obj):
        _need_object(obj)
        return list(obj.keys())

    def _func_values(self, obj):
        _need_object(obj)
        return list(obj.values())

    def _func_length(self, x):
        if isinstance(x, str) or is_array(x) or isinstance(x, Mapping):
            return len(x)
        raise InvalidTypeError("expected a string, an array or an object")

    def _func_map(self, ref, xs):
        _need_ref(ref)
        _need_array(xs)
        return [ref.apply(item) for item in xs]

    def _func_max(self, xs):
        _need_array(xs)
        _homogeneous(xs)
        if not xs:
            return None
        return max(xs)

    def _func_min(self, xs):
        _need_array(xs)
        _homogeneous(xs)
        if not xs:
            return None
        return min(xs)

    def _func_max_by(self, xs, ref):
        return self._by_extreme(xs, ref, greatest=True)

    def _func_min_by(self, xs, ref):
        return self._by_extreme(xs, ref, greatest=False)

    def _by_extreme(self, xs, ref, greatest):
        _need_array(xs)
        _need_ref(ref)
        keys = [ref.apply(item) for item in xs]
        _homogeneous(keys)
        if not xs:
            return None
        best = 0
        for i in range(1, len(xs)):
            if (keys[i] > keys[best]) if greatest else (keys[i] < keys[best]):
                best = i
        return xs[best]

    def _func_merge(self, *objs):
        out = {}
        for obj in objs:
            _need_object(obj)
            for key, value in obj.items():
                out[key] = value
        return out

    def _func_not_null(self, *values):
        for value in values:
            if value is not None:
                return value
        return None

    def _func_reverse(self, x):
        if isinstance(x, str):
            return x[::-1]
        if is_array(x):
            return list(reversed(x))
        raise InvalidTypeError("expected an array or a string")

    def _func_sort(self, xs):
        _need_array(xs)
        _homogeneous(xs)
        return sorted(xs)

    def _func_sort_by(self, xs, ref):
        _need_array(xs)
        _need_ref(ref)
        keys = [ref.apply(item) for item in xs]
        if not xs:
            return []
        _homogeneous(keys)
        order = sorted(range(len(xs)), key=lambda i: keys[i])
        return [xs[i] for i in order]

    def _func_sum(self, xs):
        _need_array(xs)
        for x in xs:
            _need_number(x)
        return _sum(xs)

    def _func_to_array(self, x):
        if is_array(x):
            return x
        return [x]

    def _func_to_number(self, x):
        if is_number(x):
            return x
        if isinstance(x, str):
            if _INT_NUMERAL.fullmatch(x):
                return int(x)
            if _DECIMAL_NUMERAL.fullmatch(x):
                return float(x)
        return None

    def _func_to_string(self, x):
        if isinstance(x, str):
            return x
        return _compact_json(x)

    def _func_type(self, x):
        kind = json_kind(x)
        if kind is None:
            raise InvalidTypeError("value is not a JSON type")
        return kind


_BASE = Functions()


def lookup(name, provider):
    """Resolve a function name at call time.

    Returns ``(kind, lo, hi, func, sig)``. For a built-in, ``kind`` is
    ``"builtin"``, ``lo``/``hi`` bound the argument count and ``sig`` is None.
    For a custom function, ``kind`` is ``"custom"``, ``lo`` is the declared
    argument count, ``hi`` is None and ``sig`` holds the declared types.
    Built-in names always resolve to the built-in, even when a provider
    declares the same name. Raises UnknownFunctionError otherwise.
    """
    if name in _BUILTIN_ARITY:
        lo, hi = _BUILTIN_ARITY[name]
        return ("builtin", lo, hi, getattr(_BASE, "_func_" + name), None)
    if provider is not None:
        attribute = getattr(provider, "_func_" + name, None)
        sig = getattr(attribute, "_pathsel_sig", None) if attribute is not None else None
        if sig is not None:
            return ("custom", len(sig), None, attribute, sig)
    raise UnknownFunctionError("unknown function: %s" % name)


def matches_declared_type(value, types):
    """Whether a value satisfies one declared argument type list."""
    return _matches(value, types)
