"""Tokenizer for PathSel expressions.

The whole text is split up front, so a token-level failure is reported before
any grammar-level failure. Whitespace (space, tab, line feed, carriage return)
is skipped between any two tokens.
"""

import json
import string

from .errors import TokenSyntaxError

IDENT = "IDENT"
QIDENT = "QIDENT"        # quoted identifier; value is the decoded key
NUMBER = "NUMBER"        # integer; value is int
LITERAL = "LITERAL"      # JSON literal between backticks; value is the JSON value
RAW = "RAW"              # raw string between single quotes; value is str
DOT = "DOT"
LBRACKET = "LBRACKET"
RBRACKET = "RBRACKET"
LBRACE = "LBRACE"
RBRACE = "RBRACE"
LPAREN = "LPAREN"
RPAREN = "RPAREN"
COMMA = "COMMA"
COLON = "COLON"
STAR = "STAR"
AT = "AT"
QMARK = "QMARK"
PIPE = "PIPE"
OR = "OR"
AMP = "AMP"
AND = "AND"
NOT = "NOT"
EQ = "EQ"
NE = "NE"
LT = "LT"
LE = "LE"
GT = "GT"
GE = "GE"
EOF = "EOF"


class Token:
    __slots__ = ("kind", "value", "pos")

    def __init__(self, kind, value, pos):
        self.kind = kind
        self.value = value
        self.pos = pos

    def __repr__(self):
        return "Token(%s, %r, %d)" % (self.kind, self.value, self.pos)


_IDENT_START = frozenset(string.ascii_letters + "_")
_IDENT_BODY = _IDENT_START | frozenset(string.digits)
_DIGITS = frozenset(string.digits)
_HEX = frozenset(string.hexdigits)
_WHITESPACE = frozenset(" \t\n\r")

_SINGLE = {
    ".": DOT,
    "[": LBRACKET,
    "]": RBRACKET,
    "{": LBRACE,
    "}": RBRACE,
    "(": LPAREN,
    ")": RPAREN,
    ",": COMMA,
    ":": COLON,
    "*": STAR,
    "@": AT,
    "?": QMARK,
    "|": PIPE,
    "&": AMP,
    "!": NOT,
    "<": LT,
    ">": GT,
}

_DOUBLE = {
    "||": OR,
    "&&": AND,
    "==": EQ,
    "!=": NE,
    "<=": LE,
    ">=": GE,
}

_LITERAL_FAILED = object()


def _parse_json_literal(body):
    """Read the text of a backtick literal; returns _LITERAL_FAILED if unreadable."""
    try:
        return json.loads(body)
    except ValueError:
        pass
    try:
        return json.loads('"' + body.lstrip(" \t\n\r") + '"')
    except ValueError:
        return _LITERAL_FAILED


def _read_quoted_identifier(text, start):
    n = len(text)
    j = start + 1
    closed = -1
    while j < n:
        ch = text[j]
        if ch == "\\":
            j += 2
            continue
        if ch == '"':
            closed = j
            break
        j += 1
    if closed < 0:
        raise TokenSyntaxError("unterminated quoted identifier", start)
    try:
        value = json.loads(text[start:closed + 1])
    except ValueError:
        raise TokenSyntaxError("quoted identifier is not a legal JSON string", start)
    if not isinstance(value, str):
        raise TokenSyntaxError("quoted identifier is not a string", start)
    return value, closed + 1


def _read_raw_string(text, start):
    n = len(text)
    buf = []
    j = start + 1
    while j < n:
        ch = text[j]
        nxt = text[j + 1] if j + 1 < n else ""
        if ch == "\\" and nxt == "'":
            buf.append("'")
            j += 2
            continue
        if ch == "\\" and nxt == "u" and j + 6 <= n and all(h in _HEX for h in text[j + 2:j + 6]):
            code = int(text[j + 2:j + 6], 16)
            j += 6
            if 0xD800 <= code <= 0xDBFF and text[j:j + 2] == "\\u" and j + 6 <= n:
                low_digits = text[j + 2:j + 6]
                if all(h in _HEX for h in low_digits):
                    low = int(low_digits, 16)
                    if 0xDC00 <= low <= 0xDFFF:
                        code = 0x10000 + ((code - 0xD800) << 10) + (low - 0xDC00)
                        j += 6
            buf.append(chr(code))
            continue
        if ch == "'":
            return "".join(buf), j + 1
        buf.append(ch)
        j += 1
    raise TokenSyntaxError("unterminated raw string literal", start)


def tokenize(text):
    """Split expression text into tokens; the last token is EOF at offset len(text)."""
    tokens = []
    i = 0
    n = len(text)
    while i < n:
        c = text[i]
        if c in _WHITESPACE:
            i += 1
            continue
        if c in _IDENT_START:
            j = i + 1
            while j < n and text[j] in _IDENT_BODY:
                j += 1
            tokens.append(Token(IDENT, text[i:j], i))
            i = j
            continue
        if c in _DIGITS or (c == "-" and i + 1 < n and text[i + 1] in _DIGITS):
            j = i + 1
            while j < n and text[j] in _DIGITS:
                j += 1
            tokens.append(Token(NUMBER, int(text[i:j]), i))
            i = j
            continue
        if c == '"':
            value, end = _read_quoted_identifier(text, i)
            tokens.append(Token(QIDENT, value, i))
            i = end
            continue
        if c == "`":
            close = text.find("`", i + 1)
            if close < 0:
                raise TokenSyntaxError("unterminated JSON literal", i)
            value = _parse_json_literal(text[i + 1:close])
            if value is _LITERAL_FAILED:
                raise TokenSyntaxError("JSON literal is neither JSON nor a JSON string body", i)
            tokens.append(Token(LITERAL, value, i))
            i = close + 1
            continue
        if c == "'":
            value, end = _read_raw_string(text, i)
            tokens.append(Token(RAW, value, i))
            i = end
            continue
        two = text[i:i + 2]
        if two in _DOUBLE:
            tokens.append(Token(_DOUBLE[two], two, i))
            i += 2
            continue
        if c in _SINGLE:
            tokens.append(Token(_SINGLE[c], c, i))
            i += 1
            continue
        if c == "=":
            raise TokenSyntaxError('lone "=" is not an operator; equality is "=="', i)
        raise TokenSyntaxError("character begins no token: %r" % c, i)
    tokens.append(Token(EOF, None, n))
    return tokens
