"""pathsel: evaluate PathSel expressions against ordinary Python data.

Public entries:
    search(expression, data, options=None)  -- one-shot evaluation
    compile(expression)                     -- parse once; .search(data, options)
"""

from .errors import (
    EmptyExpressionError,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    PathSelError,
    PathSelSyntaxError,
    TokenSyntaxError,
    UnknownFunctionError,
    ZeroSliceStepError,
)
from .functions import Functions, signature
from .parser import CompiledExpression, compile, search

__all__ = [
    "search",
    "compile",
    "CompiledExpression",
    "Functions",
    "signature",
    "PathSelError",
    "EmptyExpressionError",
    "IncompleteExpressionError",
    "PathSelSyntaxError",
    "TokenSyntaxError",
    "ZeroSliceStepError",
    "UnknownFunctionError",
    "InvalidArityError",
    "InvalidTypeError",
]
