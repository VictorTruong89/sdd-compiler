"""Value model helpers shared by the evaluator and the built-in functions."""

from collections.abc import Mapping
from decimal import Decimal


def is_number(value):
    """Integers, floats and host decimals; never booleans."""
    return isinstance(value, (int, float, Decimal)) and not isinstance(value, bool)


def is_array(value):
    """Host sequences that act as JSON arrays (lists and tuples)."""
    return isinstance(value, (list, tuple))


def is_object(value):
    """Host mappings that act as JSON objects."""
    return isinstance(value, Mapping)


def json_kind(value):
    """Name of the JSON type of ``value``, or None for a non-JSON host value."""
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if is_number(value):
        return "number"
    if isinstance(value, str):
        return "string"
    if is_array(value):
        return "array"
    if is_object(value):
        return "object"
    return None


def truthy(value):
    """Truthiness of the language: false values are null, false, "", [] and {}."""
    if value is None or value is False:
        return False
    if isinstance(value, (str, list, tuple, Mapping)):
        return len(value) > 0
    return True


def json_equal(a, b):
    """Deep JSON equality; a number is never equal to a boolean."""
    if a is None or b is None:
        return a is None and b is None
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if is_number(a) and is_number(b):
        return a == b
    if isinstance(a, str) or isinstance(b, str):
        return isinstance(a, str) and isinstance(b, str) and a == b
    if is_array(a) and is_array(b):
        return len(a) == len(b) and all(json_equal(x, y) for x, y in zip(a, b))
    if is_object(a) and is_object(b):
        if len(a) != len(b):
            return False
        for key in a:
            if key not in b or not json_equal(a[key], b[key]):
                return False
        return True
    if is_array(a) or is_array(b) or is_object(a) or is_object(b):
        return False
    try:
        return bool(a == b)
    except Exception:
        return False


class ExpressionReference:
    """A deferred subexpression produced by ``&expr``.

    Built-in functions apply it to elements with :meth:`apply`. It keeps the
    evaluation context it was created in, so custom functions used inside it
    resolve against the same provider.
    """

    __slots__ = ("expr", "ctx")

    def __init__(self, expr, ctx):
        self.expr = expr
        self.ctx = ctx

    def apply(self, value):
        return self.expr.ev(value, self.ctx)

    def __repr__(self):
        return "<ExpressionReference>"


class Context:
    """Evaluation options after they have been read: a mapping type and a provider."""

    __slots__ = ("dict_cls", "provider")

    def __init__(self, dict_cls=None, provider=None):
        self.dict_cls = dict_cls
        self.provider = provider

    @classmethod
    def from_options(cls, options):
        if options is None:
            return cls()
        return cls(
            getattr(options, "dict_cls", None),
            getattr(options, "custom_functions", None),
        )
