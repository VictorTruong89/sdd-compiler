"""Parsed-expression nodes and their evaluation.

Two kinds of node:

* Expression nodes (``ev(value, ctx)``): Chain, Pipe, Or, And, Compare.
* Operation nodes (``apply(value, ctx)``) that make up a chain: Field, Index,
  Projection, MultiList, MultiHash, Sub, Literal, Identity, RefOp, NotOp, Call.

``value`` is the current value; ``ctx`` is a values.Context.
"""

import copy
from collections.abc import Mapping

from . import functions as _functions
from .errors import InvalidArityError, InvalidTypeError
from .values import (
    ExpressionReference,
    is_array,
    is_number,
    json_equal,
    truthy,
)


def _is_obj(value, ctx):
    if isinstance(value, Mapping):
        return True
    return ctx.dict_cls is not None and isinstance(value, ctx.dict_cls)


def _slice_indices(n, start, stop, step):
    if step is None:
        step = 1

    def clamp(v, lo, hi):
        return lo if v < lo else hi if v > hi else v

    if step > 0:
        s = 0 if start is None else clamp(start + n if start < 0 else start, 0, n)
        e = n if stop is None else clamp(stop + n if stop < 0 else stop, 0, n)
    else:
        s = n - 1 if start is None else clamp(start + n if start < 0 else start, -1, n - 1)
        e = -1 if stop is None else clamp(stop + n if stop < 0 else stop, -1, n - 1)
    return range(s, e, step)


def run_ops(ops, value, ctx):
    for op in ops:
        value = op.apply(value, ctx)
    return value


class Chain:
    __slots__ = ("ops",)

    def __init__(self, ops):
        self.ops = list(ops)

    def ev(self, value, ctx):
        return run_ops(self.ops, value, ctx)


class Pipe:
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def ev(self, value, ctx):
        return self.right.ev(self.left.ev(value, ctx), ctx)


class Or:
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def ev(self, value, ctx):
        a = self.left.ev(value, ctx)
        if truthy(a):
            return a
        return self.right.ev(value, ctx)


class And:
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def ev(self, value, ctx):
        a = self.left.ev(value, ctx)
        if not truthy(a):
            return a
        return self.right.ev(value, ctx)


class Compare:
    __slots__ = ("op", "left", "right")

    def __init__(self, op, left, right):
        self.op = op
        self.left = left
        self.right = right

    def ev(self, value, ctx):
        a = self.left.ev(value, ctx)
        b = self.right.ev(value, ctx)
        if self.op == "EQ":
            return json_equal(a, b)
        if self.op == "NE":
            return not json_equal(a, b)
        comparable = (is_number(a) and is_number(b)) or (
            isinstance(a, str) and isinstance(b, str)
        )
        if not comparable:
            return None
        if self.op == "LT":
            return a < b
        if self.op == "LE":
            return a <= b
        if self.op == "GT":
            return a > b
        return a >= b


# ---------------------------------------------------------------- operations


class Field:
    __slots__ = ("name",)

    def __init__(self, name):
        self.name = name

    def apply(self, value, ctx):
        if not _is_obj(value, ctx):
            return None
        try:
            return value[self.name]
        except KeyError:
            return None


class Index:
    __slots__ = ("index",)

    def __init__(self, index):
        self.index = index

    def apply(self, value, ctx):
        if not is_array(value):
            return None
        n = len(value)
        i = self.index + n if self.index < 0 else self.index
        if 0 <= i < n:
            return value[i]
        return None


class Projection:
    """A projection; ``kind`` is list, slice, flatten, filter or obj.

    The collected results (non-null only) form an array. ``rhs`` is the list of
    operations applied to each element; empty means the element itself.
    """

    __slots__ = ("kind", "start", "stop", "step", "pred", "rhs")

    def __init__(self, kind, rhs, start=None, stop=None, step=None, pred=None):
        self.kind = kind
        self.rhs = rhs
        self.start = start
        self.stop = stop
        self.step = step
        self.pred = pred

    def apply(self, value, ctx):
        kind = self.kind
        if kind == "obj":
            if not _is_obj(value, ctx):
                return None
            elems = list(value.values())
        else:
            if not is_array(value):
                return None
            if kind == "list":
                elems = value
            elif kind == "slice":
                elems = [value[i] for i in _slice_indices(len(value), self.start, self.stop, self.step)]
            elif kind == "flatten":
                elems = []
                for item in value:
                    if is_array(item):
                        elems.extend(item)
                    else:
                        elems.append(item)
            else:  # filter
                elems = [item for item in value if truthy(self.pred.ev(item, ctx))]
        out = []
        rhs = self.rhs
        for item in elems:
            result = run_ops(rhs, item, ctx) if rhs else item
            if result is not None:
                out.append(result)
        return out


class MultiList:
    __slots__ = ("exprs",)

    def __init__(self, exprs):
        self.exprs = exprs

    def apply(self, value, ctx):
        if value is None:
            return None
        return [e.ev(value, ctx) for e in self.exprs]


class MultiHash:
    __slots__ = ("pairs",)

    def __init__(self, pairs):
        self.pairs = pairs

    def apply(self, value, ctx):
        if value is None:
            return None
        out = ctx.dict_cls() if ctx.dict_cls is not None else {}
        for key, expr in self.pairs:
            out[key] = expr.ev(value, ctx)
        return out


class Sub:
    """A parenthesized expression or ``@``-free subexpression evaluated on the current value."""

    __slots__ = ("expr",)

    def __init__(self, expr):
        self.expr = expr

    def apply(self, value, ctx):
        return self.expr.ev(value, ctx)


class Literal:
    __slots__ = ("value",)

    def __init__(self, value):
        self.value = value

    def apply(self, value, ctx):
        return copy.deepcopy(self.value)


class Identity:
    __slots__ = ()

    def apply(self, value, ctx):
        return value


class RefOp:
    """``&expr``: yields a reference that built-in functions apply later."""

    __slots__ = ("expr",)

    def __init__(self, expr):
        self.expr = expr

    def apply(self, value, ctx):
        return ExpressionReference(self.expr, ctx)


class NotOp:
    __slots__ = ("expr",)

    def __init__(self, expr):
        self.expr = expr

    def apply(self, value, ctx):
        return not truthy(self.expr.ev(value, ctx))


class Call:
    __slots__ = ("name", "args")

    def __init__(self, name, args):
        self.name = name
        self.args = args

    def apply(self, value, ctx):
        kind, lo, hi, func, sig = _functions.lookup(self.name, ctx.provider)
        n = len(self.args)
        if kind == "builtin":
            if n < lo or (hi is not None and n > hi):
                raise InvalidArityError("%s() called with %d argument(s)" % (self.name, n))
            args = [a.ev(value, ctx) for a in self.args]
            return func(*args)
        if n != lo:
            raise InvalidArityError("%s() takes %d argument(s), got %d" % (self.name, lo, n))
        args = [a.ev(value, ctx) for a in self.args]
        for arg, types in zip(args, sig):
            if not _functions.matches_declared_type(arg, types):
                raise InvalidTypeError("argument of %s() has the wrong type" % self.name)
        return func(*args)
