"""Behavioral tests for pathsel, derived from spec/Full_PRD.md and spec/Interface_Contract.md.

Run from the project root:  python -m pytest tests
"""

from collections import OrderedDict
from types import SimpleNamespace

import pytest

import pathsel
from pathsel import (
    EmptyExpressionError,
    Functions,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    PathSelSyntaxError,
    TokenSyntaxError,
    UnknownFunctionError,
    ZeroSliceStepError,
    compile as pcompile,
    search,
    signature,
)


def ev(expr, data=None, options=None):
    return search(expr, data if data is not None else {}, options)


# --- FP-01: entries, null, failure kinds ---------------------------------

def test_dotted_path_returns_nested_value():
    assert ev("foo.bar", {"foo": {"bar": 1}}) == 1


def test_missing_path_is_null_at_any_depth():
    assert ev("a.b.c", {"a": {}}) is None
    assert ev("a.b", {"a": 5}) is None


def test_identifier_on_array_is_null():
    assert ev("a.b", {"a": [{"b": 1}]}) is None


def test_compile_then_search_matches_one_shot():
    doc = {"a": [{"b": 2}, {"b": 3}]}
    expr = "a[*].b"
    assert pcompile(expr).search(doc) == ev(expr, doc)
    assert pcompile(expr).search({"x": 1}) is None
    compiled = pcompile("a")
    assert compiled.search({"a": 1}) == 1
    assert compiled.search({"a": 2}) == 2


def test_empty_expression_kind():
    with pytest.raises(EmptyExpressionError):
        ev("")


def test_whitespace_only_is_incomplete_not_empty():
    with pytest.raises(IncompleteExpressionError) as info:
        ev(" \t\n")
    assert info.value.lex_position == 3


def test_failure_kinds_are_distinct_and_value_errors():
    with pytest.raises(ValueError):
        ev("a.")
    with pytest.raises(PathSelSyntaxError) as info:
        ev("a.")
    assert not isinstance(info.value, IncompleteExpressionError)
    assert info.value.lex_position == 2


def test_token_syntax_is_subclass_of_syntax_but_not_syntax_itself():
    with pytest.raises(TokenSyntaxError) as info:
        ev("a-b")
    assert isinstance(info.value, PathSelSyntaxError)
    assert type(info.value) is not PathSelSyntaxError
    assert info.value.lex_position == 1


def test_lone_equals_is_token_syntax():
    with pytest.raises(TokenSyntaxError):
        ev("a = b")


def test_incomplete_position_is_text_length():
    with pytest.raises(IncompleteExpressionError) as info:
        ev("a ==")
    assert info.value.lex_position == 4


def test_trailing_dot_is_syntax_not_incomplete():
    with pytest.raises(PathSelSyntaxError) as info:
        ev("a.")
    assert type(info.value) is PathSelSyntaxError


def test_compile_accepts_then_search_refuses_for_unknown_function():
    compiled = pcompile("nosuch(@)")
    with pytest.raises(UnknownFunctionError):
        compiled.search({})


def test_zero_slice_step_refused_on_both_entries():
    with pytest.raises(ZeroSliceStepError):
        ev("a[0:1:0]", {"a": [1]})
    with pytest.raises(ZeroSliceStepError):
        pcompile("a[::0]")


# --- FP-02: identifiers ---------------------------------------------------

def test_quoted_identifier_names_any_key():
    doc = {"a.b": {"c d": 1, "x-y": 2}}
    assert ev('"a.b"."c d"', doc) == 1
    assert ev('"a.b"."x-y"', doc) == 2
    assert ev('"a.b".c', doc) is None


def test_quoted_identifier_escapes_decoded():
    assert ev('"\\u00e9"', {"é": 7}) == 7


def test_hyphen_and_number_after_dot_are_syntax_errors():
    with pytest.raises(TokenSyntaxError):
        ev("foo-bar")
    with pytest.raises(PathSelSyntaxError):
        ev("a.1")


def test_whitespace_between_tokens():
    assert ev(" a \n . \t b ", {"a": {"b": 3}}) == 3


# --- FP-03: index, slice, flatten ------------------------------------------

def test_index_and_negative_index():
    assert ev("a[0]", {"a": [1, 2]}) == 1
    assert ev("a[-1]", {"a": [1, 2]}) == 2
    assert ev("a[5]", {"a": [1, 2]}) is None
    assert ev("a[0]", {"a": "xy"}) is None


@pytest.mark.parametrize(
    "expr,expected",
    [
        ("a[1:3]", [1, 2]),
        ("a[::2]", [0, 2, 4]),
        ("a[::-1]", [5, 4, 3, 2, 1, 0]),
        ("a[-2:]", [4, 5]),
        ("a[5:1]", []),
        ("a[10:]", []),
        ("a[:-10]", []),
        ("a[::-2]", [5, 3, 1]),
    ],
)
def test_slices(expr, expected):
    assert ev(expr, {"a": [0, 1, 2, 3, 4, 5]}) == expected


def test_slice_of_non_array_is_null():
    assert ev("a[0:2]", {"a": {"x": 1}}) is None


def test_flatten_one_level():
    assert ev("a[]", {"a": [[1, [2]], 3]}) == [1, [2], 3]
    assert ev("[]", [[1], 2]) == [1, 2]
    assert ev("a[]", {"a": 1}) is None


def test_flatten_then_field_projects():
    assert ev("a[].b", {"a": [[{"b": 1}], {"b": 2}]}) == [1, 2]


# --- FP-04: projections ----------------------------------------------------

def test_list_wildcard_drops_nulls_and_projects_rhs():
    doc = {"a": [{"b": 1}, {"b": None}, {"c": 3}, {"b": 4}]}
    assert ev("a[*].b", doc) == [1, 4]
    assert ev("a[*]", {"a": [1, None, 2]}) == [1, 2]
    assert ev("a[*].b", {"a": 1}) is None


def test_projection_nesting_and_join_ranks():
    doc = {"a": [{"b": [1, 2]}, {"b": [3]}]}
    assert ev("a[*].b[0]", doc) == [1, 3]
    assert ev("a[*].b[*]", doc) == [[1, 2], [3]]
    # flatten (rank 1) does not join the list-wildcard right-hand side (rank 2)
    assert ev("a[*].b[]", doc) == [1, 2, 3]
    assert ev("a[*][0]", {"a": [[1, 2], [3]]}) == [1, 3]


def test_flatten_projects_when_followed_by_dot():
    assert ev("a[].b", {"a": [[{"b": 1}], {"b": 2}]}) == [1, 2]


def test_object_wildcard_projects_values():
    doc = {"x": {"v": 1}, "y": {"v": 2}}
    assert ev("*.v", doc) == [1, 2]
    assert ev("x.*", {"x": {"p": 1, "q": 2}}) == [1, 2]
    assert ev("a.*", {"a": 5}) is None


def test_object_wildcard_dot_rhs_begins_with_next_dot_step():
    assert ev("a.*.b", {"a": {"k": {"b": 9}}}) == [9]


def test_filter_projection():
    doc = {"people": [{"n": "a", "age": 30}, {"n": "b", "age": 10}, {"n": "c", "age": 40}]}
    assert ev("people[?age > `20`].n", doc) == ["a", "c"]
    assert ev("people[?age > `100`].n", doc) == []
    assert ev("x[?a]", {"x": {"a": 1}}) is None


def test_filter_truthiness_zero_is_true_and_null_is_false():
    doc = {"a": [{"v": 0}, {"v": None}, {"x": 1}, {"v": False}]}
    assert ev("a[?v]", doc) == [{"v": 0}]


def test_filter_equality_does_not_coerce_zero_and_false():
    doc = [{"v": 0}, {"v": False}, {"v": 1}, {"v": True}]
    assert ev("@[?v == `0`]", doc) == [{"v": 0}]
    assert ev("@[?v == `false`]", doc) == [{"v": False}]
    assert ev("@[?v == `1`]", doc) == [{"v": 1}]


def test_comparison_after_list_wildcard_compares_whole_array():
    assert ev("a[*].b == `[1]`", {"a": [{"b": 1}]}) is True


def test_pipe_stops_projection():
    assert ev("a[*].b | @[0]", {"a": [{"b": 1}, {"b": 2}]}) == 1


# --- FP-05: constructors, pipe, literals --------------------------------

def test_multiselect_list_and_hash():
    doc = {"a": 1, "b": {"c": 2}}
    assert ev("[a, b.c]", doc) == [1, 2]
    assert ev("{x: a, y: b.c, z: missing}", doc) == {"x": 1, "y": 2, "z": None}


def test_multiselect_on_null_current_value_is_null():
    assert ev("a.[x, y]", {"a": None}) is None


def test_multiselect_after_operand_without_dot_is_syntax():
    with pytest.raises(PathSelSyntaxError):
        ev("a[b, c]")
    assert ev("a[*][b, c]", {"a": [{"b": 1, "c": 2}]}) == [[1, 2]]


def test_json_literal_and_fallback_string():
    assert ev("`{\"a\": 1}`.a") == 1
    assert ev("`hello`") == "hello"
    assert ev("` 12 `") == 12


def test_unclosed_literal_is_token_error():
    with pytest.raises(TokenSyntaxError):
        ev("`abc")


def test_raw_string_keeps_backslashes_and_decodes_unicode():
    assert ev("'a\\b'") == "a\\b"
    assert ev("'it\\'s'") == "it's"
    assert ev("'\\u00e9'") == "é"
    assert ev("'123'") == "123"


def test_identity_and_pipe():
    assert ev("a | b", {"a": {"b": 2}}) == 2
    assert ev("@", 5) == 5


def test_expression_reference_bare_is_non_null():
    assert ev("&a", {"a": 1}) is not None


# --- FP-06: comparison and logic ----------------------------------------

def test_equality_is_json_equality():
    assert ev("`1` == `1.0`") is True
    assert ev("`0` == `false`") is False
    assert ev("`1` == `true`") is False
    assert ev("`[1, {\"a\": 2}]` == `[1, {\"a\": 2}]`") is True


def test_ordering_on_numbers_and_strings():
    assert ev("`2` > `1`") is True
    assert ev("'b' > 'a'") is True
    assert ev("'b' < `1`") is None


def test_or_and_return_operands():
    assert ev("a || b", {"a": 0, "b": 2}) == 0
    assert ev("a || b", {"a": None, "b": 2}) == 2
    assert ev("a && b", {"a": None, "b": 2}) is None
    assert ev("a && b", {"a": 1, "b": 2}) == 2


def test_not_binds_to_operand_and_index():
    assert ev("!a[0]", {"a": [0]}) is False
    assert ev("!a", {"a": []}) is True
    assert ev("!a.b", {"a": {"b": 1}}) is None  # dot applies to the boolean result


def test_missing_right_operand_is_refused():
    with pytest.raises(IncompleteExpressionError):
        ev("a && ")
    with pytest.raises(PathSelSyntaxError):
        ev("&& a")


# --- FP-07: built-in functions ------------------------------------------

@pytest.mark.parametrize(
    "expr,data,expected",
    [
        ("abs(a)", {"a": -3}, 3),
        ("avg(a)", {"a": [1, 2, 3, 4]}, 2.5),
        ("avg(a)", {"a": []}, None),
        ("ceil(a)", {"a": 1.2}, 2),
        ("floor(a)", {"a": 1.8}, 1),
        ("contains(a, `2`)", {"a": [1, 2]}, True),
        ("contains(a, 'bc')", {"a": "abcd"}, True),
        ("ends_with(a, 'cd')", {"a": "abcd"}, True),
        ("starts_with(a, 'ab')", {"a": "abcd"}, True),
        ("length(a)", {"a": "héllo"}, 5),
        ("length(a)", {"a": [1, 2]}, 2),
        ("length(a)", {"a": {"x": 1}}, 1),
        ("reverse(a)", {"a": "abc"}, "cba"),
        ("reverse(a)", {"a": [1, 2]}, [2, 1]),
        ("join(', ', a)", {"a": ["x", "y"]}, "x, y"),
        ("join(',', a)", {"a": []}, None),
        ("keys(a)", {"a": {"x": 1, "y": 2}}, ["x", "y"]),
        ("values(a)", {"a": {"x": 1, "y": 2}}, [1, 2]),
        ("max(a)", {"a": [1, 5, 2]}, 5),
        ("min(a)", {"a": ["b", "a"]}, "a"),
        ("max(a)", {"a": []}, None),
        ("sort(a)", {"a": [3, 1, 2]}, [1, 2, 3]),
        ("sum(a)", {"a": [1, 2, 3]}, 6),
        ("merge(a, b)", {"a": {"x": 1}, "b": {"x": 2, "y": 3}}, {"x": 2, "y": 3}),
        ("not_null(a, b)", {"a": None, "b": ""}, ""),
        ("not_null(a, b)", {"a": None, "b": None}, None),
        ("to_array(a)", {"a": 1}, [1]),
        ("to_array(a)", {"a": [1]}, [1]),
        ("to_number(a)", {"a": "5"}, 5),
        ("to_number(a)", {"a": "5.5"}, 5.5),
        ("to_number(a)", {"a": "1e3"}, 1000.0),
        ("to_number(a)", {"a": "x"}, None),
        ("to_number(a)", {"a": True}, None),
        ("to_string(a)", {"a": "s"}, "s"),
        ("to_string(a)", {"a": {"k": [1, "é"]}}, '{"k":[1,"\\u00e9"]}'),
        ("to_string(a)", {"a": True}, "true"),
        ("type(a)", {"a": None}, "null"),
        ("type(a)", {"a": 1.5}, "number"),
        ("type(a)", {"a": {}}, "object"),
        ("type(a)", {"a": []}, "array"),
        ("type(a)", {"a": False}, "boolean"),
    ],
)
def test_builtins(expr, data, expected):
    assert ev(expr, data) == expected


def test_map_includes_nulls_and_sort_by_is_stable():
    assert ev("map(&x, a)", {"a": [{"x": 1}, {}]}) == [1, None]
    doc = {"a": [{"k": 3, "n": "c"}, {"k": 1, "n": "a"}, {"k": 3, "n": "d"}]}
    assert [i["n"] for i in ev("sort_by(a, &k)", doc)] == ["a", "c", "d"]
    assert ev("max_by(a, &k)", doc) == {"k": 3, "n": "c"}
    assert ev("min_by(a, &k)", doc) == {"k": 1, "n": "a"}
    assert ev("max_by(`[]`, &k)") is None


def test_join_of_empty_array_yields_null_by_paragraph_rule():
    assert ev("join(',', `[]`)") is None


def test_projection_as_function_argument():
    assert ev("length(a[*].b)", {"a": [{"b": 1}, {"b": 2}]}) == 2


def test_function_arity_and_type_errors():
    with pytest.raises(InvalidArityError):
        ev("abs(`1`, `2`)", {})
    with pytest.raises(InvalidArityError):
        ev("not_null()", {})
    with pytest.raises(InvalidTypeError):
        ev("abs(a)", {"a": True})
    with pytest.raises(InvalidTypeError):
        ev("max(a)", {"a": [1, "x"]})
    with pytest.raises(InvalidTypeError):
        ev("map(a, b)", {"a": 1, "b": []})
    with pytest.raises(InvalidTypeError):
        ev("sort_by(a, &k)", {"a": [{"k": 1}, {"k": "x"}]})


def test_function_check_happens_at_search_not_compile():
    compiled = pcompile("abs(a, b)")
    with pytest.raises(InvalidArityError):
        compiled.search({})


def test_quoted_function_name_is_syntax():
    with pytest.raises(PathSelSyntaxError):
        ev('"abs"(a)', {"a": 1})


def test_length_takes_exactly_one_argument():
    assert ev("length('abc')") == 3


# --- FP-08: options --------------------------------------------------------

class Provider(Functions):
    @signature({"types": ["number"]}, {"types": ["number"]})
    def _func_add(self, a, b):
        return a + b

    @signature({"types": ["object"]})
    def _func_zero(self, obj):
        return 0

    @signature({"types": ["array"]})
    def _func_pick(self, xs):
        return xs[0] if xs else None


def test_custom_function_and_builtins_still_work():
    opts = SimpleNamespace(dict_cls=None, custom_functions=Provider())
    assert ev("add(`1`, `2`)", {}, opts) == 3
    assert ev("zero(@)", {}, opts) == 0
    assert ev("abs(`-2`)", {}, opts) == 2
    assert ev("pick(a)", {"a": [7]}, opts) == 7


def test_custom_function_refused_without_provider_at_search():
    compiled = pcompile("add(`1`, `2`)")
    with pytest.raises(UnknownFunctionError):
        compiled.search({})
    assert compiled.search({}, SimpleNamespace(dict_cls=None, custom_functions=Provider())) == 3


def test_custom_arity_and_type_checks():
    opts = SimpleNamespace(dict_cls=None, custom_functions=Provider())
    with pytest.raises(InvalidArityError):
        ev("add(`1`)", {}, opts)
    with pytest.raises(InvalidTypeError):
        ev("add(`1`, `true`)", {}, opts)
    with pytest.raises(InvalidTypeError):
        ev("zero(a)", {"a": object()}, opts)


def test_custom_function_inside_expression_reference():
    opts = SimpleNamespace(dict_cls=None, custom_functions=Provider())
    assert ev("map(&add(@, `10`), a)", {"a": [1, 2]}, opts) == [11, 12]


def test_dict_cls_builds_hashes_of_that_type():
    opts = SimpleNamespace(dict_cls=OrderedDict, custom_functions=None)
    result = ev("{x: a, y: b}", {"a": 1, "b": 2}, opts)
    assert isinstance(result, OrderedDict)
    assert ev("{x: a}.x", {"a": 1}, opts) == 1
    assert ev("merge({x: a}, {y: b})", {"a": 1, "b": 2}, opts) == {"x": 1, "y": 2}


def test_package_exports():
    assert callable(pathsel.search)
    assert callable(pathsel.compile)
