"""Behavioural tests for pathsel, one group per feature point of the PRD."""

import collections
import os
import sys

import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import pathsel  # noqa: E402
from pathsel import (  # noqa: E402
    EmptyExpressionError,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    Options,
    PathSelSyntaxError,
    TokenSyntaxError,
    UnknownFunctionError,
    ZeroSliceStepError,
)
from pathsel.functions import Functions, signature  # noqa: E402

DOC = {
    "foo": {"bar": {"baz": 1}},
    "people": [
        {"name": "a", "age": 30},
        {"name": "b", "age": 10},
        {"name": "c"},
    ],
    "arr": [1, [2, 3], [[4]], 5],
    "n": {"x": 1, "y": 2},
    "key with space": {"a.b": 7},
    "zero": 0,
    "empty": "",
    "t": True,
}


def s(expr, data=DOC, options=None):
    return pathsel.search(expr, data, options)


# FP-01 -------------------------------------------------------------------

def test_dotted_path_returns_nested_value():
    assert s("foo.bar.baz") == 1
    assert s("foo.bar") == {"baz": 1}


def test_missing_path_is_null_at_any_depth():
    assert s("nope") is None
    assert s("foo.nope.deeper") is None


def test_compiled_and_one_shot_agree_and_reuse():
    expr = pathsel.compile("people[*].name")
    assert expr.search(DOC) == s("people[*].name") == ["a", "b", "c"]
    assert expr.search({"people": []}) == []
    assert expr.search({}) is None


def test_empty_expression_refused():
    with pytest.raises(EmptyExpressionError):
        s("")
    with pytest.raises(EmptyExpressionError):
        pathsel.compile("")


@pytest.mark.parametrize("text", ["   ", "\t\n\r ", "foo.bar &&", "foo |", "foo[0", "(", "{", "foo[?"])
def test_incomplete_expression(text):
    with pytest.raises(IncompleteExpressionError) as info:
        s(text)
    # The end of the text counts as a token whose offset is the text's length.
    assert info.value.lex_position == len(text)


@pytest.mark.parametrize("text", ["foo.", ".foo", "foo bar", "foo..bar", "foo.1", "foo.'x'", "1", "foo]", "foo.*bar", "*foo", "foo*", "foo[1:2:3:4]", "foo[a:b]", "[a,]", "foo.@"])
def test_grammar_syntax_refusals(text):
    with pytest.raises(PathSelSyntaxError) as info:
        s(text)
    assert type(info.value) is PathSelSyntaxError
    assert isinstance(info.value.lex_position, int)


@pytest.mark.parametrize("text", ["foo=bar", "foo-bar", "#", '"unterminated', "`abc", "'raw", '"bad\\q"'])
def test_token_level_refusals(text):
    with pytest.raises(TokenSyntaxError) as info:
        s(text)
    assert isinstance(info.value, PathSelSyntaxError)
    assert type(info.value) is not PathSelSyntaxError
    assert isinstance(info.value.lex_position, int)


def test_syntax_position_is_offset_of_offending_token():
    with pytest.raises(PathSelSyntaxError) as info:
        s("foo bar")
    assert info.value.lex_position == 4
    with pytest.raises(PathSelSyntaxError) as info:
        s("foo.")
    assert info.value.lex_position == 4


def test_refusal_kinds_are_distinct_value_errors():
    kinds = [EmptyExpressionError, IncompleteExpressionError, PathSelSyntaxError,
             ZeroSliceStepError, UnknownFunctionError, InvalidArityError, InvalidTypeError]
    for cls in kinds:
        assert issubclass(cls, ValueError)
    with pytest.raises(IncompleteExpressionError) as info:
        s("foo |")
    assert not isinstance(info.value, EmptyExpressionError)
    with pytest.raises(TokenSyntaxError) as info:
        s("a=b")
    assert not isinstance(info.value, IncompleteExpressionError)
    assert not isinstance(info.value, EmptyExpressionError)


def test_compile_succeeds_on_wrong_call_but_search_refuses():
    expr = pathsel.compile("nofunc(`1`)")
    with pytest.raises(UnknownFunctionError):
        expr.search(DOC)
    expr = pathsel.compile("length(`1`)")
    with pytest.raises(InvalidTypeError):
        expr.search(DOC)
    expr = pathsel.compile("abs()")
    with pytest.raises(InvalidArityError):
        expr.search(DOC)


# FP-02 -------------------------------------------------------------------

def test_quoted_identifier_names_any_key():
    assert s('"key with space"."a.b"') == 7
    assert s('"key with space".missing') is None
    assert s('"foo.bar"') is None
    assert s('"\\u0066oo".bar.baz') == 1


def test_identifier_on_array_is_null():
    assert s("arr.foo") is None
    assert s("people.name") is None


def test_whitespace_between_tokens():
    assert s(" foo \t. \n bar . baz ") == 1


def test_quoted_identifier_cannot_be_function():
    with pytest.raises(PathSelSyntaxError):
        s('"length"(people)')


# FP-03 -------------------------------------------------------------------

def test_index_and_negative_index_and_out_of_range():
    assert s("arr[0]") == 1
    assert s("arr[-1]") == 5
    assert s("arr[10]") is None
    assert s("arr[-10]") is None
    assert s("foo[0]") is None


def test_slices():
    assert s("arr[1:3]") == [[2, 3], [[4]]]
    assert s("arr[::-1]") == [5, [[4]], [2, 3], 1]
    assert s("arr[::2]") == [1, [[4]]]
    assert s("arr[-2:]") == [[[4]], 5]
    assert s("arr[10:20]") == []
    assert s("arr[:-10]") == []
    assert s("arr[5:0:-2]") == [5, [2, 3]]
    assert s("arr[3:0:-1]") == [5, [[4]], [2, 3]]
    assert s("arr[-1:-10:-1]") == [5, [[4]], [2, 3], 1]


def test_slice_on_non_array_is_null():
    assert s("foo[0:2]") is None


def test_zero_slice_step_refused():
    with pytest.raises(ZeroSliceStepError):
        pathsel.compile("arr[::0]")
    with pytest.raises(ZeroSliceStepError):
        s("arr[0:2:0]")


def test_flatten_one_level():
    assert s("arr[]") == [1, 2, 3, [4], 5]
    assert s("foo[]") is None
    assert s("arr[][]") == [1, 2, 3, 4, 5]


# FP-04 -------------------------------------------------------------------

def test_list_wildcard_and_projection():
    assert s("people[*].name") == ["a", "b", "c"]
    assert s("people[*].age") == [30, 10]
    assert s("people[*]") == DOC["people"]
    assert s("foo[*].x") is None


def test_object_wildcard_projects_values():
    assert s("n.*") == [1, 2]
    assert s("n.*.x") == []
    assert s("foo.*.baz") == [1]
    assert s("arr.*") is None


def test_nested_projection_and_reach():
    data = {"foo": [{"a": [{"b": 1}, {"b": 2}]}, {"a": [{"b": 3}]}]}
    assert s("foo[*].a[*].b", data) == [[1, 2], [3]]
    assert s("foo[*].a[].b", data) == [1, 2, 3]
    assert s("foo[*].a[0].b", data) == [1, 3]


def test_flatten_after_projection_applies_to_collected_array():
    data = {"foo": [{"b": [1, 2]}, {"b": [3]}]}
    assert s("foo[*].b[]", data) == [1, 2, 3]


def test_comparison_after_list_wildcard_compares_whole_array():
    assert s("people[*].age == `[30, 10]`") is True
    assert s("people[*].name == `[\"a\", \"b\", \"c\"]`") is True


def test_filter_projection():
    assert s("people[?age > `20`].name") == ["a"]
    assert s("people[?age].name") == ["a", "b"]
    assert s("people[?!age].name") == ["c"]
    assert s("foo[?a]") is None
    assert s("people[?@.name == 'b'] | [0].age") == 10


def test_filter_predicate_zero_is_true():
    assert s("arr[?@ == `0`]") == []
    data = {"xs": [{"v": 0}, {"v": 1}, {"v": False}]}
    assert s("xs[?v].v", data) == [0, 1]


def test_wildcard_followed_by_identifier_is_syntax_error():
    with pytest.raises(PathSelSyntaxError):
        s("people[*]name")


# FP-05 -------------------------------------------------------------------

def test_multiselect_list_and_hash():
    assert s("[foo.bar.baz, nope]") == [1, None]
    assert s("{a: foo.bar.baz, b: nope}") == {"a": 1, "b": None}
    assert s("people[*].[name, age]") == [["a", 30], ["b", 10], ["c", None]]
    assert s("foo.{x: bar}") == {"x": {"baz": 1}}
    assert s("nope.[a, b]") == [None, None]
    assert s("nope.{a: b}") is None


def test_multiselect_only_first_step_of_projection():
    assert s("arr[*][0]") == [2, [4]]
    with pytest.raises(PathSelSyntaxError):
        s("foo[0][a, b]")


def test_pipe_stops_projection():
    assert s("people[*].age | length(@)") == 2
    assert s("foo | bar | baz") == 1
    assert s("people[*].name | [0]") == "a"


def test_current_value_and_literals():
    assert s("@") == DOC
    assert s("`[1, 2]`[1]") == 2
    assert s("`\"hello\"`") == "hello"
    assert s("`hello world`") == "hello world"
    assert s("`  bare text`") == "bare text"
    assert s("`null`") is None
    assert s("`{\"a\": {\"b\": 3}}`.a.b") == 3


def test_raw_string_literals():
    assert s("'123'") == "123"
    assert s("'it\\'s'") == "it's"
    assert s("'a\\nb'") == "a\\nb"
    assert s("'\\u0041'") == "A"
    assert s("'  spaced  '") == "  spaced  "


def test_literal_after_dot_is_syntax_error():
    with pytest.raises(PathSelSyntaxError):
        s("foo.`1`")


def test_expression_reference_on_its_own_is_non_null():
    assert s("&foo") is not None


# FP-06 -------------------------------------------------------------------

def test_equality_never_equates_numbers_and_booleans():
    assert s("zero == `false`") is False
    assert s("t == `1`") is False
    assert s("t == `true`") is True
    assert s("zero != `false`") is True
    assert s("foo.bar == foo.bar") is True
    assert s("n == `{\"x\": 1, \"y\": 2}`") is True


def test_truthiness_false_set():
    assert s("!zero") is False
    assert s("!empty") is True
    assert s("!nope") is True
    assert s("!`[]`") is True
    assert s("!`{}`") is True


def test_or_and_return_operands():
    assert s("nope || zero") == 0
    assert s("foo || nope") == {"bar": {"baz": 1}}
    assert s("nope && foo") is None
    assert s("foo && zero") == 0
    assert s("empty || `\"x\"`") == "x"


def test_comparators_numbers_and_strings():
    assert s("people[0].age > `20`") is True
    assert s("'abc' < 'abd'") is True
    assert s("'b' >= 'a'") is True
    assert s("'10' < `9`") is None


def test_precedence_and_parentheses():
    assert s("!(nope || empty)") is True
    assert s("!(zero || nope)") is False
    assert s("!zero || t") is True
    assert s("(nope || `1`) == `1`") is True


def test_lone_equals_and_ampersand_refused():
    with pytest.raises(TokenSyntaxError):
        s("a = b")
    with pytest.raises(PathSelSyntaxError):
        s("a & b")
    with pytest.raises(IncompleteExpressionError):
        s("a ||")


# FP-07 -------------------------------------------------------------------

def test_numeric_and_string_functions():
    assert s("abs(`-3`)") == 3
    assert s("ceil(`1.2`)") == 2 and isinstance(s("ceil(`1.2`)"), int)
    assert s("floor(`-1.5`)") == -2
    assert s("avg(`[1, 2, 3, 4]`)") == 2.5
    assert s("avg(`[]`)") is None
    assert s("sum(`[1, 2.5]`)") == 3.5
    assert s("sum(`[]`)") == 0
    assert s("max(`[3, 9, 1]`)") == 9
    assert s('min(`["b", "a"]`)') == "a"
    assert s("max(`[]`)") is None
    assert s("sort(`[3, 1, 2]`)") == [1, 2, 3]
    assert s("ends_with('hello', 'llo')") is True
    assert s("starts_with('hello', 'he')") is True
    assert s("length('héllo')") == 5
    assert s("length(`{\"a\": 1}`)") == 1
    assert s("reverse('abc')") == "cba"
    assert s("reverse(`[1, 2]`)") == [2, 1]
    assert s("join(', ', `[\"a\", \"b\"]`)") == "a, b"
    assert s("join(', ', `[]`)") == ""
    assert s("contains(`[1, true]`, `true`)") is True
    assert s("contains(`[1, true]`, `1`)") is True


def test_contains_is_json_equality():
    assert s("contains(`[1]`, `true`)") is False
    assert s("contains('haystack', 'st')") is True


def test_keys_values_type_conversions():
    assert s("keys(n)") == ["x", "y"]
    assert s("values(n)") == [1, 2]
    assert s("type(n)") == "object"
    assert s("type(`1.5`)") == "number"
    assert s("type(t)") == "boolean"
    assert s("type(nope)") == "null"
    assert s("type(arr)") == "array"
    assert s("type('x')") == "string"
    assert s("to_array(`1`)") == [1]
    assert s("to_array(`[1]`)") == [1]
    assert s("to_string(`1`)") == "1"
    assert s("to_string(`\"x\"`)") == "x"
    assert s("to_string(`{\"a\": [1, 2]}`)") == '{"a":[1,2]}'
    assert s("to_number('12')") == 12 and isinstance(s("to_number('12')"), int)
    assert s("to_number('1.5')") == 1.5
    assert s("to_number('abc')") is None
    assert s("to_number(t)") is None


def test_merge_and_not_null():
    assert s("merge(n, `{\"z\": 3, \"x\": 9}`)") == {"x": 9, "y": 2, "z": 3}
    assert s("not_null(nope, zero, 'x')") == 0
    assert s("not_null(nope, nope)") is None
    assert s("not_null(empty, 'x')") == ""


def test_map_includes_nulls():
    assert s("map(&name, people)") == ["a", "b", "c"]
    assert s("map(&age, people)") == [30, 10, None]


def test_sort_by_stable_and_max_min_by_ties():
    data = {"xs": [{"k": 2, "id": 1}, {"k": 1, "id": 2}, {"k": 2, "id": 3}, {"k": 1, "id": 4}]}
    assert [x["id"] for x in s("sort_by(xs, &k)", data)] == [2, 4, 1, 3]
    assert s("max_by(xs, &k)", data) == {"k": 2, "id": 1}
    assert s("min_by(xs, &k)", data) == {"k": 1, "id": 2}
    assert s("max_by(`[]`, &k)") is None
    assert s("sort_by(`[]`, &k)") == []


def test_function_type_errors():
    with pytest.raises(InvalidTypeError):
        s("abs(t)")
    with pytest.raises(InvalidTypeError):
        s("avg(`[1, 'a']`)")
    with pytest.raises(InvalidTypeError):
        s("max(`[1, 'a']`)")
    with pytest.raises(InvalidTypeError):
        s("sort_by(people, name)")
    with pytest.raises(InvalidTypeError):
        s("sort_by(people, &nope)")
    with pytest.raises(InvalidTypeError):
        s("join(',', `[1]`)")
    with pytest.raises(InvalidTypeError):
        s("ends_with(nope, 'x')")
    with pytest.raises(InvalidTypeError):
        s("map(name, people)")
    with pytest.raises(InvalidTypeError):
        s("length(nope)")
    with pytest.raises(InvalidTypeError):
        s("keys('x')")


def test_function_arity_errors():
    with pytest.raises(InvalidArityError):
        s("abs(`1`, `2`)")
    with pytest.raises(InvalidArityError):
        s("not_null()")
    with pytest.raises(InvalidArityError):
        s("merge()")
    assert s("merge(n)") == {"x": 1, "y": 2}


def test_unknown_function():
    with pytest.raises(UnknownFunctionError):
        s("frobnicate(`1`)")


def test_function_in_projection_and_as_argument():
    assert s("people[*].name | join(',', @)") == "a,b,c"
    assert s("people[*].age | max(@)") == 30
    assert s("people[].age | length(@)") == 2


# FP-08 -------------------------------------------------------------------

class _Ordered(collections.OrderedDict):
    pass


def test_dict_cls_for_constructed_hashes():
    opts = Options(dict_cls=collections.OrderedDict)
    result = s("{a: foo.bar.baz, b: zero}", options=opts)
    assert isinstance(result, collections.OrderedDict)
    assert list(result.items()) == [("a", 1), ("b", 0)]
    assert s("{a: `1`}.a", options=opts) == 1
    assert s("keys({a: `1`, b: `2`})", options=opts) == ["a", "b"]
    assert s("length({a: `1`, b: `2`})", options=opts) == 2
    assert isinstance(s("merge({a: `1`})", options=opts), dict)


def test_custom_functions_and_builtins_still_available():
    class Mine(Functions):
        @signature({"types": ["number"]}, {"types": ["number"]})
        def _func_add(self, a, b):
            return a + b

        @signature({"types": ["string", "null"]})
        def _func_shout(self, x):
            return "HI" if x is None else x.upper()

        @signature()
        def _func_zero(self):
            return 0

    opts = Options(custom_functions=Mine())
    assert s("add(`1`, `2`)", options=opts) == 3
    assert s("shout(nope)", options=opts) == "HI"
    assert s("zero()", options=opts) == 0
    assert s("abs(`-2`)", options=opts) == 2
    assert pathsel.compile("add(`1`, `2`)").search(DOC, opts) == 3
    with pytest.raises(UnknownFunctionError):
        s("add(`1`, `2`)")
    with pytest.raises(InvalidArityError):
        s("add(`1`)", options=opts)
    with pytest.raises(InvalidTypeError):
        s("add(`1`, t)", options=opts)
    with pytest.raises(InvalidTypeError):
        s("shout(`[]`)", options=opts)


def test_custom_function_on_another_provider_is_unknown():
    class A(Functions):
        @signature()
        def _func_only_a(self):
            return 1

    class B(Functions):
        pass

    with pytest.raises(UnknownFunctionError):
        s("only_a()", options=Options(custom_functions=B()))


def test_custom_function_return_value_is_used_even_when_falsy():
    class P(Functions):
        @signature()
        def _func_nothing(self):
            return []

    assert s("nothing()", options=Options(custom_functions=P())) == []


def test_option_objects_are_duck_typed():
    class Ns:
        dict_cls = None
        custom_functions = None

    assert s("{a: `1`}", options=Ns()) == {"a": 1}
