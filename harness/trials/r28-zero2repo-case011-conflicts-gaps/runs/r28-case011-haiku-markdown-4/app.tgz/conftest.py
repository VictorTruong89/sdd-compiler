# Empty marker: pytest inserts this project root on sys.path, so `import pathsel`
# resolves to the flat-layout package at /app/pathsel.
