"""Value model helpers shared by the evaluator and the built-in functions."""

import operator
from collections.abc import Mapping
from decimal import Decimal


class ExpressionReference:
    """A deferred subexpression (``&expr``), bound to the context it was evaluated in."""

    __slots__ = ("node", "ctx")

    def __init__(self, node, ctx):
        self.node = node
        self.ctx = ctx

    def apply(self, value):
        """Evaluate the referenced expression against ``value``."""
        return self.node.eval(value, self.ctx)

    def __repr__(self):
        return "<pathsel expression reference>"


def is_json_number(x):
    """An int or float that is not a boolean."""
    return isinstance(x, (int, float)) and not isinstance(x, bool)


def is_number(x):
    """A JSON number, or a host decimal (which takes part in comparisons)."""
    return is_json_number(x) or isinstance(x, Decimal)


def is_array(x):
    return isinstance(x, (list, tuple))


def is_object(x, dict_cls=None):
    """A mapping, or an instance of the caller's constructed-hash type."""
    if isinstance(x, Mapping):
        return True
    return dict_cls is not None and isinstance(x, dict_cls)


def obj_keys(x):
    return list(x.keys())


def obj_get(x, key):
    """The value under ``key`` in an object, or None when absent."""
    try:
        return x[key]
    except KeyError:
        return None


def truthy(x, dict_cls=None):
    """True unless ``x`` is one of: false, null, "", [], {}."""
    if x is None:
        return False
    if isinstance(x, bool):
        return x
    if isinstance(x, str) or is_array(x):
        return len(x) > 0
    if is_object(x, dict_cls):
        return len(obj_keys(x)) > 0
    return True


def json_equal(a, b, dict_cls=None):
    """JSON value equality: booleans never equal numbers; containers compare deeply."""
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if is_number(a) and is_number(b):
        return a == b
    if a is None or b is None:
        return a is None and b is None
    if isinstance(a, str) or isinstance(b, str):
        return isinstance(a, str) and isinstance(b, str) and a == b
    if is_array(a) or is_array(b):
        if not (is_array(a) and is_array(b)) or len(a) != len(b):
            return False
        return all(json_equal(x, y, dict_cls) for x, y in zip(a, b))
    if is_object(a, dict_cls) and is_object(b, dict_cls):
        ka = obj_keys(a)
        kb = obj_keys(b)
        if len(ka) != len(kb):
            return False
        kb_set = set(kb)
        for k in ka:
            if k not in kb_set:
                return False
            if not json_equal(obj_get(a, k), obj_get(b, k), dict_cls):
                return False
        return True
    return a == b


_ORDERING = {
    "lt": operator.lt,
    "lte": operator.le,
    "gt": operator.gt,
    "gte": operator.ge,
}


def compare_values(op_name, a, b):
    """Ordering comparison of two numbers or two strings; null for other operands."""
    if (is_number(a) and is_number(b)) or (isinstance(a, str) and isinstance(b, str)):
        return _ORDERING[op_name](a, b)
    return None
