"""Built-in language functions and the provider/signature API.

``Functions`` is a provider. Its ``_func_<name>`` methods, each decorated with
``signature``, are the built-in functions. Subclass it to add custom functions:

    class Mine(Functions):
        @signature({"types": ["number"]})
        def _func_double(self, x):
            return x * 2
"""

import json
import math
import re
from collections.abc import Mapping
from decimal import Decimal

from .errors import InvalidTypeError
from .values import (
    ExpressionReference,
    is_array,
    is_json_number,
    is_number,
    is_object,
    json_equal,
    obj_get,
    obj_keys,
)

_TYPE_NAMES = frozenset({"number", "string", "array", "object", "null", "any", "expref"})

_INT_NUMERAL = re.compile(r"-?[0-9]+")
_FLOAT_NUMERAL = re.compile(r"-?(?:[0-9]+\.[0-9]*|\.[0-9]+|[0-9]+)(?:[eE][+-]?[0-9]+)?")


def signature(*arguments):
    """Declare the accepted types of each argument of a function implementation.

    Each positional argument is ``{"types": [<type-name>, ...]}``; the argument
    is accepted when its value matches any listed type. The decorator attaches
    the declaration and returns the same function without calling it.
    """
    specs = []
    for argument in arguments:
        types = argument["types"]
        if not types:
            raise ValueError("signature argument needs at least one type")
        for name in types:
            if name not in _TYPE_NAMES:
                raise ValueError(f"unknown type name {name!r}")
        specs.append(tuple(types))
    specs = tuple(specs)

    def decorate(fn):
        fn._pathsel_sig = specs
        fn._pathsel_variadic = False
        fn._pathsel_min = len(specs)
        return fn

    return decorate


def _variadic(min_args):
    """Mark a signature as repeating its single argument spec, with ``min_args`` minimum."""

    def decorate(fn):
        if len(fn._pathsel_sig) != 1:
            raise ValueError("a variadic signature has exactly one argument spec")
        fn._pathsel_variadic = True
        fn._pathsel_min = min_args
        return fn

    return decorate


def matches_type(value, type_name, dict_cls=None):
    """Whether ``value`` belongs to the named type."""
    if type_name == "any":
        return True
    if type_name == "number":
        return is_json_number(value)
    if type_name == "string":
        return isinstance(value, str)
    if type_name == "array":
        return is_array(value)
    if type_name == "object":
        return is_object(value, dict_cls)
    if type_name == "null":
        return value is None
    if type_name == "expref":
        return isinstance(value, ExpressionReference)
    return False


def function_signature(fn):
    """Return ``(specs, variadic, minimum_argument_count)`` for a declared function."""
    specs = fn._pathsel_sig
    variadic = getattr(fn, "_pathsel_variadic", False)
    minimum = fn._pathsel_min if variadic else len(specs)
    return specs, variadic, minimum


def find_function(name, provider):
    """Locate a function by name.

    Returns a bound callable (its ``_pathsel_*`` declaration is readable from it),
    or None. Built-ins take precedence over the provider, so a provider cannot
    change built-in behaviour.
    """
    attr = "_func_" + name
    builtin = getattr(_BUILTIN, attr, None)
    if builtin is not None and hasattr(builtin, "_pathsel_sig"):
        return builtin
    if provider is not None:
        custom = getattr(provider, attr, None)
        if custom is not None and hasattr(custom, "_pathsel_sig"):
            return custom
    return None


def _require_all(items, predicate, message):
    for item in items:
        if not predicate(item):
            raise InvalidTypeError(message)


def _require_numbers_or_strings(items, message):
    """Every element a JSON number, or every element a string (an empty array passes)."""
    if not items:
        return
    if all(is_json_number(x) for x in items):
        return
    if all(isinstance(x, str) for x in items):
        return
    raise InvalidTypeError(message)


def _keyed(items, ref):
    """Pair each element with its key from the expression reference, checking key types."""
    keys = [ref.apply(item) for item in items]
    _require_numbers_or_strings(keys, "sort key must be all numbers or all strings")
    return list(zip(keys, items))


def _jsonable(x):
    if x is None or isinstance(x, (bool, str, int, float)):
        return x
    if isinstance(x, Decimal):
        return float(x)
    if is_array(x):
        return [_jsonable(v) for v in x]
    if isinstance(x, Mapping) or hasattr(x, "keys"):
        return {str(k): _jsonable(x[k]) for k in x.keys()}
    return str(x)


def _type_name(x):
    if x is None:
        return "null"
    if isinstance(x, bool):
        return "boolean"
    if is_number(x):
        return "number"
    if isinstance(x, str):
        return "string"
    if is_array(x):
        return "array"
    if isinstance(x, Mapping) or hasattr(x, "keys"):
        return "object"
    return "null"


class Functions:
    """Provider of the built-in functions. Subclass it to add custom functions."""

    @signature({"types": ["number"]})
    def _func_abs(self, x):
        return abs(x)

    @signature({"types": ["array"]})
    def _func_avg(self, xs):
        _require_all(xs, is_json_number, "avg needs an array of numbers")
        if not xs:
            return None
        return sum(xs) / len(xs)

    @signature({"types": ["number"]})
    def _func_ceil(self, x):
        return math.ceil(x)

    @signature({"types": ["number"]})
    def _func_floor(self, x):
        return math.floor(x)

    @signature({"types": ["array", "string"]}, {"types": ["any"]})
    def _func_contains(self, haystack, needle):
        if is_array(haystack):
            return any(json_equal(item, needle) for item in haystack)
        if not isinstance(needle, str):
            raise InvalidTypeError("contains on a string needs a string second argument")
        return needle in haystack

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_ends_with(self, text, suffix):
        return text.endswith(suffix)

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_starts_with(self, text, prefix):
        return text.startswith(prefix)

    @signature({"types": ["string", "array", "object"]})
    def _func_length(self, x):
        if isinstance(x, str) or is_array(x):
            return len(x)
        return len(obj_keys(x))

    @signature({"types": ["array", "string"]})
    def _func_reverse(self, x):
        if isinstance(x, str):
            return x[::-1]
        return list(reversed(x))

    @signature({"types": ["string"]}, {"types": ["array"]})
    def _func_join(self, separator, parts):
        _require_all(parts, lambda p: isinstance(p, str), "join needs an array of strings")
        if not parts:
            return ""
        return separator.join(parts)

    @signature({"types": ["object"]})
    def _func_keys(self, obj):
        return obj_keys(obj)

    @signature({"types": ["object"]})
    def _func_values(self, obj):
        return [obj_get(obj, k) for k in obj_keys(obj)]

    @signature({"types": ["any"]})
    def _func_type(self, x):
        return _type_name(x)

    @signature({"types": ["any"]})
    def _func_to_array(self, x):
        if isinstance(x, list):
            return x
        if is_array(x):
            return list(x)
        return [x]

    @signature({"types": ["any"]})
    def _func_to_string(self, x):
        if isinstance(x, str):
            return x
        return json.dumps(_jsonable(x), separators=(",", ":"), ensure_ascii=True)

    @signature({"types": ["any"]})
    def _func_to_number(self, x):
        if is_number(x):
            return x
        if isinstance(x, str):
            if _INT_NUMERAL.fullmatch(x):
                return int(x)
            if _FLOAT_NUMERAL.fullmatch(x):
                return float(x)
        return None

    @signature({"types": ["array"]})
    def _func_max(self, xs):
        if not xs:
            return None
        _require_numbers_or_strings(xs, "max needs an array of numbers or of strings")
        return max(xs)

    @signature({"types": ["array"]})
    def _func_min(self, xs):
        if not xs:
            return None
        _require_numbers_or_strings(xs, "min needs an array of numbers or of strings")
        return min(xs)

    @signature({"types": ["array"]})
    def _func_sort(self, xs):
        _require_numbers_or_strings(xs, "sort needs an array of numbers or of strings")
        return sorted(xs)

    @signature({"types": ["array"]})
    def _func_sum(self, xs):
        _require_all(xs, is_json_number, "sum needs an array of numbers")
        return sum(xs)

    @_variadic(1)
    @signature({"types": ["object"]})
    def _func_merge(self, *objs):
        out = {}
        for obj in objs:
            for k in obj_keys(obj):
                out[k] = obj_get(obj, k)
        return out

    @_variadic(1)
    @signature({"types": ["any"]})
    def _func_not_null(self, *args):
        for arg in args:
            if arg is not None:
                return arg
        return None

    @signature({"types": ["expref"]}, {"types": ["array"]})
    def _func_map(self, ref, xs):
        return [ref.apply(item) for item in xs]

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_sort_by(self, xs, ref):
        pairs = _keyed(xs, ref)
        pairs.sort(key=lambda pair: pair[0])
        return [item for _, item in pairs]

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_max_by(self, xs, ref):
        pairs = _keyed(xs, ref)
        if not pairs:
            return None
        best_key, best = pairs[0]
        for key, item in pairs[1:]:
            if key > best_key:
                best_key, best = key, item
        return best

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_min_by(self, xs, ref):
        pairs = _keyed(xs, ref)
        if not pairs:
            return None
        best_key, best = pairs[0]
        for key, item in pairs[1:]:
            if key < best_key:
                best_key, best = key, item
        return best


_BUILTIN = Functions()
