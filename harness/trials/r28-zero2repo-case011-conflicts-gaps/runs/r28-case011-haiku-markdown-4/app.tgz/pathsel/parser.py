"""Tokenizer and parser for the PathSel language.

The parser is a Pratt parser. Binding powers follow the PRD's ranking:

* flatten ``[]`` 9, filter ``[?`` 21, dot 40, index/slice/list-wildcard/multiselect
  bracket 55; a projection's right-hand side takes the steps that bind tighter
  than its threshold (20 for ``[*]``, slices and ``*``; 9 for flatten; 21 for filter).
* binary operators: pipe 1, ``||`` 2, ``&&`` 3, comparators 5; ``!`` takes its operand
  at binding power 45.
"""

import json
import string

from .errors import (
    EmptyExpressionError,
    IncompleteExpressionError,
    PathSelSyntaxError,
    TokenSyntaxError,
    ZeroSliceStepError,
)
from .nodes import (
    Compare,
    Call,
    Field,
    Flatten,
    FilterProjection,
    Identity,
    Index,
    ListProjection,
    Literal,
    MultiHash,
    MultiList,
    ObjectProjection,
    Not,
    Or,
    And,
    Pipe,
    Reference,
    Slice,
    Sub,
    VirtualStart,
)

_IDENT_START = frozenset(string.ascii_letters + "_")
_IDENT_CHARS = frozenset(string.ascii_letters + string.digits + "_")
_DIGITS = frozenset(string.digits)
_HEX = frozenset(string.hexdigits)
_WHITESPACE = frozenset(" \t\n\r")
_SINGLE = {
    ".": "dot",
    "*": "star",
    "@": "at",
    "[": "lbracket",
    "]": "rbracket",
    "{": "lbrace",
    "}": "rbrace",
    "(": "lparen",
    ")": "rparen",
    ",": "comma",
    ":": "colon",
    "?": "question",
}


class Token:
    __slots__ = ("kind", "value", "pos")

    def __init__(self, kind, value, pos):
        self.kind = kind
        self.value = value
        self.pos = pos

    def __repr__(self):
        return f"Token({self.kind!r}, {self.value!r}, {self.pos})"


def _scan_delimited(text, start, delimiter):
    """Find the closing delimiter, skipping backslash-escaped characters.

    Returns ``(raw_content, index_after_closing_delimiter)``.
    """
    n = len(text)
    j = start + 1
    while True:
        if j >= n:
            raise TokenSyntaxError("unterminated literal", lex_position=start)
        ch = text[j]
        if ch == "\\":
            j += 2
            continue
        if ch == delimiter:
            return text[start + 1 : j], j + 1
        j += 1


def _scan_raw_string(text, start):
    """Scan a single-quoted raw string. Only ``\\'`` and ``\\uXXXX`` are processed."""
    n = len(text)
    j = start + 1
    out = []
    while True:
        if j >= n:
            raise TokenSyntaxError("unterminated raw string", lex_position=start)
        ch = text[j]
        if ch == "\\" and text[j + 1 : j + 2] == "'":
            out.append("'")
            j += 2
            continue
        if ch == "\\" and text[j + 1 : j + 2] == "u":
            digits = text[j + 2 : j + 6]
            if len(digits) == 4 and all(d in _HEX for d in digits):
                out.append(chr(int(digits, 16)))
                j += 6
                continue
        if ch == "'":
            return "".join(out), j + 1
        out.append(ch)
        j += 1


def _read_json_literal(content, start):
    text = content.replace("\\`", "`")
    try:
        return json.loads(text, strict=False)
    except ValueError:
        pass
    try:
        return json.loads('"' + text.lstrip(" \t\n\r") + '"', strict=False)
    except ValueError:
        raise TokenSyntaxError("literal is neither JSON nor JSON string content", lex_position=start)


def tokenize(text):
    """Split the text into tokens. Any token-level failure raises immediately."""
    tokens = []
    n = len(text)
    i = 0
    while i < n:
        c = text[i]
        if c in _WHITESPACE:
            i += 1
            continue
        if c in _IDENT_START:
            j = i + 1
            while j < n and text[j] in _IDENT_CHARS:
                j += 1
            tokens.append(Token("ident", text[i:j], i))
            i = j
            continue
        if c in _DIGITS or (c == "-" and i + 1 < n and text[i + 1] in _DIGITS):
            j = i + 1
            while j < n and text[j] in _DIGITS:
                j += 1
            tokens.append(Token("number", int(text[i:j]), i))
            i = j
            continue
        if c == "-":
            raise TokenSyntaxError("a hyphen begins no token", lex_position=i)
        if c == '"':
            content, j = _scan_delimited(text, i, '"')
            try:
                value = json.loads('"' + content + '"', strict=False)
            except ValueError:
                raise TokenSyntaxError("invalid quoted identifier", lex_position=i)
            tokens.append(Token("qident", value, i))
            i = j
            continue
        if c == "`":
            content, j = _scan_delimited(text, i, "`")
            tokens.append(Token("literal", _read_json_literal(content, i), i))
            i = j
            continue
        if c == "'":
            value, j = _scan_raw_string(text, i)
            tokens.append(Token("literal", value, i))
            i = j
            continue
        if c == "|":
            if text[i + 1 : i + 2] == "|":
                tokens.append(Token("or", "||", i))
                i += 2
            else:
                tokens.append(Token("pipe", "|", i))
                i += 1
            continue
        if c == "&":
            if text[i + 1 : i + 2] == "&":
                tokens.append(Token("and", "&&", i))
                i += 2
            else:
                tokens.append(Token("expref", "&", i))
                i += 1
            continue
        if c == "!":
            if text[i + 1 : i + 2] == "=":
                tokens.append(Token("ne", "!=", i))
                i += 2
            else:
                tokens.append(Token("not", "!", i))
                i += 1
            continue
        if c == "=":
            if text[i + 1 : i + 2] == "=":
                tokens.append(Token("eq", "==", i))
                i += 2
                continue
            raise TokenSyntaxError("a lone '=' begins no token", lex_position=i)
        if c in ("<", ">"):
            if text[i + 1 : i + 2] == "=":
                kind = "lte" if c == "<" else "gte"
                tokens.append(Token(kind, c + "=", i))
                i += 2
            else:
                kind = "lt" if c == "<" else "gt"
                tokens.append(Token(kind, c, i))
                i += 1
            continue
        if c in _SINGLE:
            tokens.append(Token(_SINGLE[c], c, i))
            i += 1
            continue
        raise TokenSyntaxError(f"character {c!r} begins no token", lex_position=i)
    tokens.append(Token("eof", None, n))
    return tokens


_COMPARATORS = {"eq", "ne", "lt", "lte", "gt", "gte"}
_BINARY_LBP = {"pipe": 1, "or": 2, "and": 3, "dot": 40}
for _kind in _COMPARATORS:
    _BINARY_LBP[_kind] = 5


def _chain(left, step):
    """Attach ``step`` after ``left``; a bare identity start needs no wrapper."""
    if isinstance(left, Identity):
        return step
    return Sub(left, step)


class _Parser:
    def __init__(self, text):
        self.text = text
        self.tokens = tokenize(text)
        self.pos = 0
        self.zero_step = False

    # token helpers -----------------------------------------------------

    def peek(self, offset=0):
        index = min(self.pos + offset, len(self.tokens) - 1)
        return self.tokens[index]

    def advance(self):
        tok = self.tokens[self.pos]
        if tok.kind != "eof":
            self.pos += 1
        return tok

    def fail(self, tok):
        """The error for an unexpected token: incomplete at the end, otherwise syntax."""
        if tok.kind == "eof":
            return IncompleteExpressionError(
                "expression is incomplete", lex_position=tok.pos
            )
        return PathSelSyntaxError(
            f"unexpected token {tok.kind} at position {tok.pos}", lex_position=tok.pos
        )

    def expect(self, kind):
        tok = self.peek()
        if tok.kind != kind:
            raise self.fail(tok)
        return self.advance()

    def is_multiselect(self):
        """The current '[' opens a multiselect list (not a flatten, filter, index, slice or wildcard)."""
        nxt = self.peek(1).kind
        if nxt in ("rbracket", "question", "number", "colon"):
            return False
        if nxt == "star" and self.peek(2).kind == "rbracket":
            return False
        return True

    def lbp(self):
        tok = self.peek()
        if tok.kind == "lbracket":
            nxt = self.peek(1).kind
            if nxt == "rbracket":
                return 9
            if nxt == "question":
                return 21
            return 55
        return _BINARY_LBP.get(tok.kind, 0)

    # Pratt core --------------------------------------------------------

    def expr(self, rbp=0):
        node = self.nud()
        while self.lbp() > rbp:
            node = self.led(node)
        return node

    def rhs(self, threshold):
        """The right-hand side of a projection: the following steps that bind tighter."""
        node = VirtualStart()
        while self.lbp() > threshold:
            node = self.led(node)
        return node

    def nud(self):
        tok = self.peek()
        kind = tok.kind
        if kind == "ident":
            self.advance()
            if self.peek().kind == "lparen":
                return self.call(tok.value)
            return Field(tok.value)
        if kind == "qident":
            self.advance()
            return Field(tok.value)
        if kind == "literal":
            self.advance()
            return Literal(tok.value)
        if kind == "at":
            self.advance()
            return Identity()
        if kind == "star":
            self.advance()
            return ObjectProjection(self.rhs(20))
        if kind == "lbrace":
            return self.multihash()
        if kind == "lbracket":
            if self.is_multiselect():
                return self.multilist()
            return self.led_bracket(Identity())
        if kind == "lparen":
            self.advance()
            node = self.expr(0)
            self.expect("rparen")
            return node
        if kind == "not":
            self.advance()
            return Not(self.expr(45))
        if kind == "expref":
            self.advance()
            return Reference(self.expr(0))
        raise self.fail(tok)

    def led(self, left):
        tok = self.peek()
        kind = tok.kind
        if kind == "pipe":
            self.advance()
            return Pipe(left, self.expr(1))
        if kind == "or":
            self.advance()
            return Or(left, self.expr(2))
        if kind == "and":
            self.advance()
            return And(left, self.expr(3))
        if kind in _COMPARATORS:
            self.advance()
            return Compare(kind, left, self.expr(5))
        if kind == "dot":
            self.advance()
            right = self.dot_operand()
            while self.lbp() > 40:
                right = self.led(right)
            return _chain(left, right)
        if kind == "lbracket":
            return self.led_bracket(left)
        raise self.fail(tok)

    # steps -------------------------------------------------------------

    def call(self, name):
        self.expect("lparen")
        args = []
        if self.peek().kind == "rparen":
            self.advance()
            return Call(name, args)
        while True:
            args.append(self.expr(0))
            if self.peek().kind == "comma":
                self.advance()
                continue
            break
        self.expect("rparen")
        return Call(name, args)

    def dot_operand(self):
        tok = self.peek()
        kind = tok.kind
        if kind == "ident":
            self.advance()
            if self.peek().kind == "lparen":
                return self.call(tok.value)
            return Field(tok.value)
        if kind == "qident":
            self.advance()
            return Field(tok.value)
        if kind == "star":
            self.advance()
            return ObjectProjection(self.rhs(20))
        if kind == "lbrace":
            return self.multihash()
        if kind == "lbracket" and self.is_multiselect():
            return self.multilist()
        # After a dot, anything else (including the end of the text) is a syntax failure.
        raise PathSelSyntaxError(
            f"a dot must be followed by an identifier, '*', or a multiselect at position {tok.pos}",
            lex_position=tok.pos,
        )

    def led_bracket(self, left):
        open_tok = self.peek()
        if self.is_multiselect():
            if not isinstance(left, VirtualStart):
                if self.peek(1).kind == "eof":
                    raise self.fail(self.peek(1))
                raise PathSelSyntaxError(
                    f"a multiselect list may only start a projection at position {open_tok.pos}",
                    lex_position=open_tok.pos,
                )
            return self.multilist()
        self.advance()  # '['
        tok = self.peek()
        if tok.kind == "rbracket":
            self.advance()
            return _chain(left, Flatten(self.rhs(9)))
        if tok.kind == "star":
            self.advance()
            self.expect("rbracket")
            return _chain(left, ListProjection(self.rhs(20)))
        if tok.kind == "question":
            self.advance()
            predicate = self.expr(0)
            self.expect("rbracket")
            return _chain(left, FilterProjection(predicate, self.rhs(21)))
        return self.index_or_slice(left)

    def index_or_slice(self, left):
        parts = [self.number_or_none()]
        while self.peek().kind == "colon":
            if len(parts) == 3:
                raise self.fail(self.peek())
            self.advance()
            parts.append(self.number_or_none())
        self.expect("rbracket")
        if len(parts) == 1:
            return _chain(left, Index(parts[0]))
        start, stop, step = (parts + [None, None, None])[:3]
        if step == 0:
            self.zero_step = True
        return _chain(left, Slice(start, stop, step, self.rhs(20)))

    def number_or_none(self):
        if self.peek().kind == "number":
            return self.advance().value
        return None

    def multilist(self):
        """A multiselect list; the current token is its '['."""
        self.expect("lbracket")
        items = []
        while True:
            items.append(self.expr(0))
            if self.peek().kind == "comma":
                self.advance()
                continue
            break
        self.expect("rbracket")
        return MultiList(items)

    def multihash(self):
        self.expect("lbrace")
        pairs = []
        while True:
            tok = self.peek()
            if tok.kind not in ("ident", "qident"):
                raise self.fail(tok)
            self.advance()
            self.expect("colon")
            pairs.append((tok.value, self.expr(0)))
            if self.peek().kind == "comma":
                self.advance()
                continue
            break
        self.expect("rbrace")
        return MultiHash(pairs)


def parse(text):
    """Parse expression text into a tree. Raises the PRD's refusal kinds."""
    if text == "":
        raise EmptyExpressionError("empty expression")
    parser = _Parser(text)
    node = parser.expr(0)
    tok = parser.peek()
    if tok.kind != "eof":
        raise parser.fail(tok)
    if parser.zero_step:
        raise ZeroSliceStepError("slice step of 0")
    return node
