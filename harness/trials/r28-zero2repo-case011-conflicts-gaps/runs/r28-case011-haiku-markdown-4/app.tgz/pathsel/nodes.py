"""Expression tree and evaluation.

Every node implements ``eval(cur, ctx)``, where ``cur`` is the current value and
``ctx`` is a ``Context`` built from the caller's evaluation options.
"""

import copy

from .errors import InvalidArityError, InvalidTypeError, UnknownFunctionError
from .functions import find_function, function_signature, matches_type
from .values import (
    ExpressionReference,
    compare_values,
    is_array,
    is_object,
    json_equal,
    obj_get,
    obj_keys,
    truthy,
)


class Context:
    """Evaluation options as the evaluator reads them."""

    __slots__ = ("dict_cls", "provider")

    def __init__(self, options=None):
        self.dict_cls = getattr(options, "dict_cls", None)
        self.provider = getattr(options, "custom_functions", None)

    def new_mapping(self):
        return self.dict_cls() if self.dict_cls is not None else {}


class Node:
    __slots__ = ()

    def eval(self, cur, ctx):
        raise NotImplementedError


class Identity(Node):
    """The current value (``@``, or the implicit start of an expression)."""

    __slots__ = ()

    def eval(self, cur, ctx):
        return cur


class VirtualStart(Identity):
    """Marks the implicit start of a projection's right-hand side.

    Only the parser distinguishes it; at evaluation it is the current value.
    """

    __slots__ = ()


class Literal(Node):
    __slots__ = ("value",)

    def __init__(self, value):
        self.value = value

    def eval(self, cur, ctx):
        return copy.deepcopy(self.value)


class Field(Node):
    __slots__ = ("name",)

    def __init__(self, name):
        self.name = name

    def eval(self, cur, ctx):
        if is_object(cur, ctx.dict_cls):
            return obj_get(cur, self.name)
        return None


class Sub(Node):
    """Apply ``right`` to the result of ``left``."""

    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, cur, ctx):
        return self.right.eval(self.left.eval(cur, ctx), ctx)


class Index(Node):
    __slots__ = ("n",)

    def __init__(self, n):
        self.n = n

    def eval(self, cur, ctx):
        if not is_array(cur):
            return None
        length = len(cur)
        i = self.n + length if self.n < 0 else self.n
        if 0 <= i < length:
            return cur[i]
        return None


def slice_positions(length, start, stop, step):
    """Indices selected by a slice, following the PRD's clamping rules."""
    if step > 0:
        s = 0 if start is None else start
        if start is not None and s < 0:
            s += length
        s = min(max(s, 0), length)
        e = length if stop is None else stop
        if stop is not None and e < 0:
            e += length
        e = min(max(e, 0), length)
    else:
        s = length - 1 if start is None else start
        if start is not None and s < 0:
            s += length
        s = min(max(s, -1), length - 1)
        e = -1 if stop is None else stop
        if stop is not None and e < 0:
            e += length
        e = min(max(e, -1), length - 1)
    return range(s, e, step)


def collect(items, rhs, ctx):
    """Apply a projection's right-hand side to each item, dropping null results."""
    if isinstance(rhs, Identity):
        return [item for item in items if item is not None]
    out = []
    for item in items:
        value = rhs.eval(item, ctx)
        if value is not None:
            out.append(value)
    return out


class Slice(Node):
    __slots__ = ("start", "stop", "step", "rhs")

    def __init__(self, start, stop, step, rhs):
        self.start = start
        self.stop = stop
        self.step = 1 if step is None else step
        self.rhs = rhs

    def eval(self, cur, ctx):
        if not is_array(cur):
            return None
        positions = slice_positions(len(cur), self.start, self.stop, self.step)
        return collect([cur[i] for i in positions], self.rhs, ctx)


class ListProjection(Node):
    """``[*]``: project over the elements of an array."""

    __slots__ = ("rhs",)

    def __init__(self, rhs):
        self.rhs = rhs

    def eval(self, cur, ctx):
        if not is_array(cur):
            return None
        return collect(cur, self.rhs, ctx)


class ObjectProjection(Node):
    """``*``: project over the values of an object."""

    __slots__ = ("rhs",)

    def __init__(self, rhs):
        self.rhs = rhs

    def eval(self, cur, ctx):
        if not is_object(cur, ctx.dict_cls):
            return None
        values = [obj_get(cur, k) for k in obj_keys(cur)]
        return collect(values, self.rhs, ctx)


class Flatten(Node):
    """``[]``: splice each array element in one level, then project."""

    __slots__ = ("rhs",)

    def __init__(self, rhs):
        self.rhs = rhs

    def eval(self, cur, ctx):
        if not is_array(cur):
            return None
        flat = []
        for item in cur:
            if is_array(item):
                flat.extend(item)
            else:
                flat.append(item)
        return collect(flat, self.rhs, ctx)


class FilterProjection(Node):
    """``[?predicate]``: keep the elements whose predicate is a true value, then project."""

    __slots__ = ("predicate", "rhs")

    def __init__(self, predicate, rhs):
        self.predicate = predicate
        self.rhs = rhs

    def eval(self, cur, ctx):
        if not is_array(cur):
            return None
        kept = [
            item
            for item in cur
            if truthy(self.predicate.eval(item, ctx), ctx.dict_cls)
        ]
        return collect(kept, self.rhs, ctx)


class MultiList(Node):
    """``[e1, e2, ...]``: build an array, one element per expression (nulls stored)."""

    __slots__ = ("items",)

    def __init__(self, items):
        self.items = items

    def eval(self, cur, ctx):
        return [item.eval(cur, ctx) for item in self.items]


class MultiHash(Node):
    """``{k: e, ...}``: build an object. A null current value yields null."""

    __slots__ = ("pairs",)

    def __init__(self, pairs):
        self.pairs = pairs

    def eval(self, cur, ctx):
        if cur is None:
            return None
        out = ctx.new_mapping()
        for key, expr in self.pairs:
            out[key] = expr.eval(cur, ctx)
        return out


class Pipe(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, cur, ctx):
        return self.right.eval(self.left.eval(cur, ctx), ctx)


class Or(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, cur, ctx):
        value = self.left.eval(cur, ctx)
        if truthy(value, ctx.dict_cls):
            return value
        return self.right.eval(cur, ctx)


class And(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, cur, ctx):
        value = self.left.eval(cur, ctx)
        if not truthy(value, ctx.dict_cls):
            return value
        return self.right.eval(cur, ctx)


class Not(Node):
    __slots__ = ("operand",)

    def __init__(self, operand):
        self.operand = operand

    def eval(self, cur, ctx):
        return not truthy(self.operand.eval(cur, ctx), ctx.dict_cls)


class Compare(Node):
    __slots__ = ("op", "left", "right")

    def __init__(self, op, left, right):
        self.op = op
        self.left = left
        self.right = right

    def eval(self, cur, ctx):
        a = self.left.eval(cur, ctx)
        b = self.right.eval(cur, ctx)
        if self.op == "eq":
            return json_equal(a, b, ctx.dict_cls)
        if self.op == "ne":
            return not json_equal(a, b, ctx.dict_cls)
        return compare_values(self.op, a, b)


class Reference(Node):
    """``&expr``: a deferred expression, evaluated later by a function."""

    __slots__ = ("node",)

    def __init__(self, node):
        self.node = node

    def eval(self, cur, ctx):
        return ExpressionReference(self.node, ctx)


class Call(Node):
    __slots__ = ("name", "args")

    def __init__(self, name, args):
        self.name = name
        self.args = args

    def eval(self, cur, ctx):
        fn = find_function(self.name, ctx.provider)
        if fn is None:
            raise UnknownFunctionError(f"unknown function {self.name!r}")
        specs, variadic, minimum = function_signature(fn)
        count = len(self.args)
        if count < minimum or (not variadic and count != len(specs)):
            raise InvalidArityError(
                f"{self.name} called with {count} argument(s)"
            )
        values = [arg.eval(cur, ctx) for arg in self.args]
        for index, value in enumerate(values):
            allowed = specs[min(index, len(specs) - 1)]
            if not any(matches_type(value, t, ctx.dict_cls) for t in allowed):
                raise InvalidTypeError(
                    f"argument {index + 1} of {self.name} has the wrong type"
                )
        return fn(*values)
