"""pathsel: evaluate PathSel expressions against ordinary Python data.

    import pathsel
    pathsel.search("a.b", {"a": {"b": 1}})          # -> 1
    expr = pathsel.compile("people[*].name")
    expr.search(document)                             # -> list of names
"""

from .errors import (
    EmptyExpressionError,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    PathSelError,
    PathSelSyntaxError,
    TokenSyntaxError,
    UnknownFunctionError,
    ZeroSliceStepError,
)
from .functions import Functions, signature
from .nodes import Context
from .parser import parse


class Options:
    """Optional evaluation options: a constructed-hash type and a function provider."""

    def __init__(self, dict_cls=None, custom_functions=None):
        self.dict_cls = dict_cls
        self.custom_functions = custom_functions


class ParsedExpression:
    """A compiled expression that can be searched against many documents."""

    __slots__ = ("expression", "_node")

    def __init__(self, expression, node):
        self.expression = expression
        self._node = node

    def search(self, value, options=None):
        return self._node.eval(value, Context(options))

    def __repr__(self):
        return f"ParsedExpression({self.expression!r})"


def compile(expression):
    """Parse an expression once. Raises a ``PathSelError`` subclass on refusal."""
    return ParsedExpression(expression, parse(expression))


def search(expression, data, options=None):
    """Parse ``expression`` and evaluate it against ``data``."""
    return compile(expression).search(data, options)


__all__ = [
    "search",
    "compile",
    "Options",
    "ParsedExpression",
    "Functions",
    "signature",
    "PathSelError",
    "EmptyExpressionError",
    "IncompleteExpressionError",
    "PathSelSyntaxError",
    "TokenSyntaxError",
    "ZeroSliceStepError",
    "UnknownFunctionError",
    "InvalidArityError",
    "InvalidTypeError",
]
