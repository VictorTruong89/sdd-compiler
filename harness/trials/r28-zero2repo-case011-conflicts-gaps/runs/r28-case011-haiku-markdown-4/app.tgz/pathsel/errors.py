"""Refusal types raised by pathsel.

Every refusal is a ``ValueError`` (through ``PathSelError``). The kind of a
refusal is the type of the raised exception. Syntax and incomplete-expression
refusals also carry an ``int`` attribute ``lex_position``.
"""


class PathSelError(ValueError):
    """Base class of every pathsel refusal."""

    lex_position = None

    def __init__(self, message, lex_position=None):
        super().__init__(message)
        if lex_position is not None:
            self.lex_position = lex_position


class EmptyExpressionError(PathSelError):
    """The expression text has zero length."""


class IncompleteExpressionError(PathSelError):
    """The text ends where an operand or a closing token is still required."""


class PathSelSyntaxError(PathSelError):
    """Grammar-level syntax failure."""


class TokenSyntaxError(PathSelSyntaxError):
    """Token-level syntax failure: a more specific form of the syntax kind."""


class ZeroSliceStepError(PathSelError):
    """A slice whose step is 0."""


class UnknownFunctionError(PathSelError):
    """A function name that is neither built-in nor declared on the provider."""


class InvalidArityError(PathSelError):
    """A function called with the wrong number of arguments."""


class InvalidTypeError(PathSelError):
    """A function argument outside its accepted types."""
