"""Failure kinds. Every refusal is a ValueError."""


class PathSelError(ValueError):
    """Base of all refusals."""


class EmptyExpressionError(PathSelError):
    def __init__(self):
        PathSelError.__init__(self, "Invalid empty expression")


class _Positioned(PathSelError):
    def __init__(self, lex_position, token_value, message):
        PathSelError.__init__(self, "%s (position %s, token %r)" % (message, lex_position, token_value))
        self.lex_position = int(lex_position)
        self.token_value = token_value


class ParseError(_Positioned):
    """Grammar-level syntax failure."""


class LexerError(ParseError):
    """Token-level syntax failure (subclass of the syntax kind)."""


class IncompleteExpressionError(_Positioned):
    """Expression ended where more was required."""


class ZeroSliceStepError(PathSelError):
    def __init__(self):
        PathSelError.__init__(self, "slice step cannot be zero")


class UnknownFunctionError(PathSelError):
    pass


class InvalidArityError(PathSelError):
    pass


class InvalidTypeError(PathSelError):
    pass
