from .errors import (EmptyExpressionError, IncompleteExpressionError,
                     ParseError)
from .lexer import tokenize

BP = {
    'eof': 0, 'unquoted_identifier': 0, 'quoted_identifier': 0, 'literal': 0,
    'rbracket': 0, 'rparen': 0, 'comma': 0, 'rbrace': 0, 'number': 0,
    'current': 0, 'expref': 0, 'colon': 0, 'unknown': 0,
    'pipe': 1, 'or': 2, 'and': 3,
    'eq': 5, 'gt': 5, 'lt': 5, 'gte': 5, 'lte': 5, 'ne': 5,
    'flatten': 9, 'star': 20, 'filter': 21, 'dot': 40, 'not': 45,
    'lbrace': 50, 'lbracket': 55, 'lparen': 60,
}
_STOP = 10
_COMPARATORS = ('eq', 'gt', 'lt', 'gte', 'lte', 'ne')


class Parser(object):
    def __init__(self, expression):
        self.expression = expression
        self.tokens = tokenize(expression)
        self.pos = 0

    # token helpers
    def _cur(self):
        return self.tokens[self.pos]['type']

    def _look(self, k):
        p = self.pos + k
        if p >= len(self.tokens):
            return 'eof'
        return self.tokens[p]['type']

    def _advance(self):
        self.pos += 1

    def _match(self, t):
        if self._cur() == t:
            self._advance()
        else:
            self._error(self.tokens[self.pos])

    def _error(self, token, msg=None):
        if token['type'] == 'eof':
            raise IncompleteExpressionError(token['start'], token['value'],
                                            "Invalid expression: unexpected end of expression")
        raise ParseError(token['start'], token['value'],
                         msg or "Unexpected token %r" % (token['value'],))

    def parse(self):
        if self.expression == '':
            raise EmptyExpressionError()
        node = self._expression(0)
        if self._cur() != 'eof':
            self._error(self.tokens[self.pos])
        return node

    def _expression(self, bp=0):
        tok = self.tokens[self.pos]
        nud = getattr(self, '_nud_' + tok['type'], None)
        if nud is None:
            self._error(tok)
        self._advance()
        left = nud(tok)
        while bp < BP[self._cur()]:
            t = self._cur()
            led = getattr(self, '_led_' + t, None)
            if led is None:
                self._error(self.tokens[self.pos])
            self._advance()
            left = led(left)
        return left

    # nud
    def _nud_literal(self, tok):
        return {'type': 'literal', 'value': tok['value']}

    def _nud_unquoted_identifier(self, tok):
        return {'type': 'field', 'name': tok['value']}

    def _nud_quoted_identifier(self, tok):
        if self._cur() == 'lparen':
            raise ParseError(tok['start'], tok['value'],
                             "Quoted identifier not allowed for function names.")
        return {'type': 'field', 'name': tok['value']}

    def _nud_star(self, tok):
        left = {'type': 'identity'}
        if self._cur() == 'rbracket':
            right = {'type': 'identity'}
        else:
            right = self._proj_rhs(BP['star'])
        return {'type': 'value_projection', 'left': left, 'right': right}

    def _nud_filter(self, tok):
        return self._led_filter({'type': 'identity'})

    def _nud_lbrace(self, tok):
        return self._multi_hash()

    def _nud_flatten(self, tok):
        return self._led_flatten({'type': 'identity'})

    def _nud_current(self, tok):
        return {'type': 'identity'}

    def _nud_expref(self, tok):
        return {'type': 'expref', 'child': self._expression(BP['expref'])}

    def _nud_not(self, tok):
        return {'type': 'not', 'child': self._expression(BP['not'])}

    def _nud_lparen(self, tok):
        e = self._expression(0)
        self._match('rparen')
        return e

    def _nud_lbracket(self, tok):
        if self._cur() in ('number', 'colon'):
            right = self._index_expr()
            return self._project_if_slice({'type': 'identity'}, right)
        if self._cur() == 'star' and self._look(1) == 'rbracket':
            self._advance()
            self._advance()
            right = self._proj_rhs(BP['star'])
            return {'type': 'projection', 'left': {'type': 'identity'}, 'right': right}
        return self._multi_list()

    # led
    def _led_lparen(self, left):
        if left['type'] != 'field':
            tok = self.tokens[self.pos - 1]
            raise ParseError(tok['start'], tok['value'], "Invalid function name")
        args = []
        while self._cur() != 'rparen':
            args.append(self._expression(0))
            if self._cur() == 'comma':
                self._match('comma')
        self._match('rparen')
        return {'type': 'function', 'name': left['name'], 'args': args}

    def _led_dot(self, left):
        if self._cur() != 'star':
            right = self._dot_rhs(BP['dot'])
            return {'type': 'subexpression', 'left': left, 'right': right}
        self._advance()
        right = self._proj_rhs(BP['dot'])
        return {'type': 'value_projection', 'left': left, 'right': right}

    def _led_pipe(self, left):
        return {'type': 'pipe', 'left': left, 'right': self._expression(BP['pipe'])}

    def _led_or(self, left):
        return {'type': 'or', 'left': left, 'right': self._expression(BP['or'])}

    def _led_and(self, left):
        return {'type': 'and', 'left': left, 'right': self._expression(BP['and'])}

    def _led_flatten(self, left):
        node = {'type': 'flatten', 'child': left}
        right = self._proj_rhs(BP['flatten'])
        return {'type': 'projection', 'left': node, 'right': right}

    def _led_filter(self, left):
        cond = self._expression(0)
        self._match('rbracket')
        if self._cur() == 'flatten':
            right = {'type': 'identity'}
        else:
            right = self._proj_rhs(BP['filter'])
        return {'type': 'filter_projection', 'left': left, 'right': right, 'condition': cond}

    def _led_lbracket(self, left):
        if self._cur() in ('number', 'colon'):
            right = self._index_expr()
            return self._project_if_slice(left, right)
        self._match('star')
        self._match('rbracket')
        right = self._proj_rhs(BP['star'])
        return {'type': 'projection', 'left': left, 'right': right}

    def _make_cmp(op):
        def led(self, left):
            return {'type': 'comparator', 'op': op, 'left': left,
                    'right': self._expression(BP[op])}
        return led

    _led_eq = _make_cmp('eq')
    _led_ne = _make_cmp('ne')
    _led_gt = _make_cmp('gt')
    _led_gte = _make_cmp('gte')
    _led_lt = _make_cmp('lt')
    _led_lte = _make_cmp('lte')
    del _make_cmp

    # helpers
    def _project_if_slice(self, left, right):
        node = {'type': 'index_expression', 'left': left, 'right': right}
        if right['type'] == 'slice':
            return {'type': 'projection', 'left': node,
                    'right': self._proj_rhs(BP['star'])}
        return node

    def _index_expr(self):
        if self._look(0) == 'colon' or self._look(1) == 'colon':
            return self._slice()
        node = {'type': 'index', 'value': self.tokens[self.pos]['value']}
        self._advance()
        self._match('rbracket')
        return node

    def _slice(self):
        parts = [None, None, None]
        index = 0
        cur = self._cur()
        while cur != 'rbracket' and index < 3:
            if cur == 'colon':
                index += 1
                if index == 3:
                    self._error(self.tokens[self.pos])
                self._advance()
            elif cur == 'number':
                parts[index] = self.tokens[self.pos]['value']
                self._advance()
                if self._cur() not in ('colon', 'rbracket'):
                    self._error(self.tokens[self.pos])
            else:
                self._error(self.tokens[self.pos])
            cur = self._cur()
        self._match('rbracket')
        return {'type': 'slice', 'start': parts[0], 'stop': parts[1], 'step': parts[2]}

    def _proj_rhs(self, bp):
        cur = self._cur()
        if BP[cur] < _STOP:
            return {'type': 'identity'}
        if cur == 'lbracket':
            return self._expression(bp)
        if cur == 'filter':
            return self._expression(bp)
        if cur == 'dot':
            self._match('dot')
            return self._dot_rhs(bp)
        self._error(self.tokens[self.pos])

    def _dot_rhs(self, bp):
        cur = self._cur()
        if cur in ('quoted_identifier', 'unquoted_identifier', 'star'):
            return self._expression(bp)
        if cur == 'lbracket':
            self._match('lbracket')
            return self._multi_list()
        if cur == 'lbrace':
            self._match('lbrace')
            return self._multi_hash()
        self._error(self.tokens[self.pos])

    def _multi_list(self):
        exprs = []
        while True:
            exprs.append(self._expression(0))
            if self._cur() == 'rbracket':
                break
            self._match('comma')
        self._match('rbracket')
        return {'type': 'multi_list', 'children': exprs}

    def _multi_hash(self):
        pairs = []
        while True:
            key = self.tokens[self.pos]
            if key['type'] in ('quoted_identifier', 'unquoted_identifier'):
                self._advance()
            else:
                self._error(key)
            self._match('colon')
            value = self._expression(0)
            pairs.append((key['value'], value))
            if self._cur() == 'comma':
                self._match('comma')
            elif self._cur() == 'rbrace':
                self._match('rbrace')
                break
            else:
                self._error(self.tokens[self.pos])
        return {'type': 'multi_hash', 'pairs': pairs}


def parse(expression):
    return Parser(expression).parse()
