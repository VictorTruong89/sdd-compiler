import json
import math
import re
from collections.abc import Mapping
from decimal import Decimal

from .errors import UnknownFunctionError, InvalidArityError, InvalidTypeError
from .interpreter import Expref, deep_equal, is_number, is_object


def signature(*arguments):
    def _record(func):
        func.signature = arguments
        return func
    return _record


def type_name(x):
    if x is None:
        return 'null'
    if isinstance(x, bool):
        return 'boolean'
    if isinstance(x, str):
        return 'string'
    if is_number(x):
        return 'number'
    if isinstance(x, list):
        return 'array'
    if is_object(x):
        return 'object'
    if isinstance(x, Expref):
        return 'expref'
    return 'unknown'


def _matches(arg, t):
    if t == 'any':
        return True
    if t == 'array-number':
        return isinstance(arg, list) and all(is_number(e) for e in arg)
    if t == 'array-string':
        return isinstance(arg, list) and all(isinstance(e, str) for e in arg)
    return type_name(arg) == t


_INT = re.compile(r'^[+-]?[0-9]+$')
_FLT = re.compile(r'^[+-]?([0-9]+\.?[0-9]*|\.[0-9]+)([eE][+-]?[0-9]+)?$')


class Functions(object):
    @signature({'types': ['number']})
    def _func_abs(self, arg):
        return abs(arg)

    @signature({'types': ['array-number']})
    def _func_avg(self, arg):
        if not arg:
            return None
        return sum(arg) / float(len(arg))

    @signature({'types': ['number']})
    def _func_ceil(self, arg):
        return math.ceil(arg)

    @signature({'types': ['number']})
    def _func_floor(self, arg):
        return math.floor(arg)

    @signature({'types': ['string', 'array']}, {'types': []})
    def _func_contains(self, subject, search):
        if isinstance(subject, str):
            return isinstance(search, str) and search in subject
        return any(deep_equal(e, search) for e in subject)

    @signature({'types': ['string']}, {'types': ['string']})
    def _func_ends_with(self, s, suffix):
        return s.endswith(suffix)

    @signature({'types': ['string']}, {'types': ['string']})
    def _func_starts_with(self, s, prefix):
        return s.startswith(prefix)

    @signature({'types': ['string', 'array', 'object']})
    def _func_length(self, arg):
        return len(arg)

    @signature({'types': ['array', 'string']})
    def _func_reverse(self, arg):
        if isinstance(arg, str):
            return arg[::-1]
        return list(reversed(arg))

    @signature({'types': ['string']}, {'types': ['array-string']})
    def _func_join(self, glue, arr):
        return glue.join(arr)

    @signature({'types': ['object']})
    def _func_keys(self, arg):
        return list(arg.keys())

    @signature({'types': ['object']})
    def _func_values(self, arg):
        return list(arg.values())

    @signature({'types': []})
    def _func_type(self, arg):
        n = type_name(arg)
        return 'object' if n == 'unknown' else n

    @signature({'types': []})
    def _func_to_array(self, arg):
        if isinstance(arg, list):
            return arg
        return [arg]

    @signature({'types': []})
    def _func_to_string(self, arg):
        if isinstance(arg, str):
            return arg

        def default(o):
            if isinstance(o, Decimal):
                return float(o)
            return str(o)
        return json.dumps(arg, separators=(',', ':'), default=default)

    @signature({'types': []})
    def _func_to_number(self, arg):
        if is_number(arg):
            return arg
        if isinstance(arg, str):
            s = arg.strip()
            if _INT.match(s):
                return int(s)
            if _FLT.match(s):
                try:
                    return float(s)
                except ValueError:
                    return None
        return None

    @signature({'types': ['array-number', 'array-string']})
    def _func_max(self, arg):
        return max(arg) if arg else None

    @signature({'types': ['array-number', 'array-string']})
    def _func_min(self, arg):
        return min(arg) if arg else None

    @signature({'types': ['array-number', 'array-string']})
    def _func_sort(self, arg):
        return sorted(arg)

    @signature({'types': ['array-number']})
    def _func_sum(self, arg):
        return sum(arg)

    @signature({'types': ['object'], 'variadic': True})
    def _func_merge(self, *args):
        merged = {}
        for a in args:
            merged.update(a)
        return merged

    @signature({'types': [], 'variadic': True})
    def _func_not_null(self, *args):
        for a in args:
            if a is not None:
                return a
        return None

    @signature({'types': ['expref']}, {'types': ['array']})
    def _func_map(self, expref, arr):
        return [expref.visit(e) for e in arr]

    def _keys(self, arr, expref):
        keys = [expref.visit(e) for e in arr]
        if not keys:
            return keys
        required = type_name(keys[0])
        if required not in ('number', 'string'):
            raise InvalidTypeError("sort key must be number or string")
        for k in keys:
            if type_name(k) != required:
                raise InvalidTypeError("sort keys must all have the same type")
        return keys

    @signature({'types': ['array']}, {'types': ['expref']})
    def _func_sort_by(self, arr, expref):
        keys = self._keys(arr, expref)
        order = sorted(range(len(arr)), key=lambda i: keys[i])
        return [arr[i] for i in order]

    @signature({'types': ['array']}, {'types': ['expref']})
    def _func_max_by(self, arr, expref):
        keys = self._keys(arr, expref)
        if not arr:
            return None
        best = 0
        for i in range(1, len(arr)):
            if keys[i] > keys[best]:
                best = i
        return arr[best]

    @signature({'types': ['array']}, {'types': ['expref']})
    def _func_min_by(self, arr, expref):
        keys = self._keys(arr, expref)
        if not arr:
            return None
        best = 0
        for i in range(1, len(arr)):
            if keys[i] < keys[best]:
                best = i
        return arr[best]


_DEFAULT = Functions()


def default_provider():
    return _DEFAULT


def _lookup(provider, name):
    func = getattr(provider, '_func_' + name, None)
    if func is None or getattr(func, 'signature', None) is None:
        func = getattr(_DEFAULT, '_func_' + name, None)
        if func is None or getattr(func, 'signature', None) is None:
            return None
        return func
    return func


def call_function(interp, node, value):
    name = node['name']
    func = _lookup(interp.provider, name)
    if func is None:
        raise UnknownFunctionError("Unknown function: %s()" % name)
    sig = list(func.signature)
    nargs = len(node['args'])
    variadic = bool(sig) and bool(sig[-1].get('variadic'))
    if variadic:
        if nargs < len(sig):
            raise InvalidArityError("%s() expects at least %d arguments, got %d" % (name, len(sig), nargs))
    elif nargs != len(sig):
        raise InvalidArityError("%s() expects %d arguments, got %d" % (name, len(sig), nargs))
    args = [interp.visit(a, value) for a in node['args']]
    for i, a in enumerate(args):
        spec = sig[i] if i < len(sig) else sig[-1]
        types = spec.get('types') or []
        if not types:
            continue
        if not any(_matches(a, t) for t in types):
            raise InvalidTypeError("invalid type for argument %d of %s(): got %s, expected %s"
                                   % (i + 1, name, type_name(a), types))
    return func(*args)
