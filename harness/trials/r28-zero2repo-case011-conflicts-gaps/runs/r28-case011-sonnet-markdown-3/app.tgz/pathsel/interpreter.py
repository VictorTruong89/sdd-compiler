import copy
from collections.abc import Mapping
from decimal import Decimal

from .errors import ZeroSliceStepError, UnknownFunctionError, InvalidArityError, InvalidTypeError  # noqa


def is_number(x):
    return isinstance(x, (int, float, Decimal)) and not isinstance(x, bool)


def is_object(x):
    return isinstance(x, Mapping)


def is_false(v):
    if v is None or v is False:
        return True
    if isinstance(v, (str, list)) or is_object(v):
        return len(v) == 0
    return False


def deep_equal(a, b):
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if is_number(a) and is_number(b):
        return a == b
    if isinstance(a, list):
        return (isinstance(b, list) and len(a) == len(b)
                and all(deep_equal(x, y) for x, y in zip(a, b)))
    if is_object(a):
        if not is_object(b) or len(a) != len(b):
            return False
        for k in a:
            if k not in b or not deep_equal(a[k], b[k]):
                return False
        return True
    if isinstance(a, str) or isinstance(b, str):
        return isinstance(a, str) and isinstance(b, str) and a == b
    if a is None or b is None:
        return a is None and b is None
    try:
        return bool(a == b)
    except Exception:
        return False


class Expref(object):
    def __init__(self, node, interpreter):
        self.node = node
        self.interpreter = interpreter

    def visit(self, value):
        return self.interpreter.visit(self.node, value)


class Interpreter(object):
    def __init__(self, options=None):
        self.dict_cls = None
        self.provider = None
        if options is not None:
            self.dict_cls = getattr(options, 'dict_cls', None)
            self.provider = getattr(options, 'custom_functions', None)
        if self.dict_cls is None:
            self.dict_cls = dict
        if self.provider is None:
            from .functions import default_provider
            self.provider = default_provider()

    def visit(self, node, value):
        return getattr(self, 'v_' + node['type'])(node, value)

    def v_field(self, node, value):
        if not is_object(value):
            return None
        try:
            return value[node['name']]
        except KeyError:
            return None

    def v_subexpression(self, node, value):
        r = self.visit(node['left'], value)
        if r is None:
            return None
        return self.visit(node['right'], r)

    v_index_expression = v_subexpression

    def v_pipe(self, node, value):
        return self.visit(node['right'], self.visit(node['left'], value))

    def v_index(self, node, value):
        if not isinstance(value, list):
            return None
        try:
            return value[node['value']]
        except IndexError:
            return None

    def v_slice(self, node, value):
        if not isinstance(value, list):
            return None
        if node['step'] == 0:
            raise ZeroSliceStepError()
        return value[slice(node['start'], node['stop'], node['step'])]

    def v_identity(self, node, value):
        return value

    def v_literal(self, node, value):
        v = node['value']
        if isinstance(v, (list, dict)):
            return copy.deepcopy(v)
        return v

    def v_expref(self, node, value):
        return Expref(node['child'], self)

    def v_flatten(self, node, value):
        base = self.visit(node['child'], value)
        if not isinstance(base, list):
            return None
        out = []
        for el in base:
            if isinstance(el, list):
                out.extend(el)
            else:
                out.append(el)
        return out

    def v_projection(self, node, value):
        base = self.visit(node['left'], value)
        if not isinstance(base, list):
            return None
        out = []
        for el in base:
            r = self.visit(node['right'], el)
            if r is not None:
                out.append(r)
        return out

    def v_value_projection(self, node, value):
        base = self.visit(node['left'], value)
        if not is_object(base):
            return None
        out = []
        for el in list(base.values()):
            r = self.visit(node['right'], el)
            if r is not None:
                out.append(r)
        return out

    def v_filter_projection(self, node, value):
        base = self.visit(node['left'], value)
        if not isinstance(base, list):
            return None
        out = []
        for el in base:
            if not is_false(self.visit(node['condition'], el)):
                r = self.visit(node['right'], el)
                if r is not None:
                    out.append(r)
        return out

    def v_comparator(self, node, value):
        a = self.visit(node['left'], value)
        b = self.visit(node['right'], value)
        op = node['op']
        if op == 'eq':
            return deep_equal(a, b)
        if op == 'ne':
            return not deep_equal(a, b)
        if (is_number(a) and is_number(b)) or (isinstance(a, str) and isinstance(b, str)):
            if op == 'lt':
                return a < b
            if op == 'lte':
                return a <= b
            if op == 'gt':
                return a > b
            return a >= b
        return None

    def v_or(self, node, value):
        a = self.visit(node['left'], value)
        if is_false(a):
            return self.visit(node['right'], value)
        return a

    def v_and(self, node, value):
        a = self.visit(node['left'], value)
        if is_false(a):
            return a
        return self.visit(node['right'], value)

    def v_not(self, node, value):
        return is_false(self.visit(node['child'], value))

    def v_multi_list(self, node, value):
        if value is None:
            return None
        return [self.visit(c, value) for c in node['children']]

    def v_multi_hash(self, node, value):
        if value is None:
            return None
        out = self.dict_cls()
        for k, c in node['pairs']:
            out[k] = self.visit(c, value)
        return out

    def v_function(self, node, value):
        from .functions import call_function
        return call_function(self, node, value)
