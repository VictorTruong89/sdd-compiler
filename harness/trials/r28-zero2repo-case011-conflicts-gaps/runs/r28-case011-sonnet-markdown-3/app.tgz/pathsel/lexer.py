import json
import re

from .errors import LexerError

_IDSTART = frozenset("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_")
_IDCHARS = _IDSTART | frozenset("0123456789")
_DIGITS = frozenset("0123456789")
_WS = frozenset(" \t\n\r")
_SIMPLE = {
    '.': 'dot', '*': 'star', ',': 'comma', ':': 'colon', '@': 'current',
    ']': 'rbracket', '(': 'lparen', ')': 'rparen', '{': 'lbrace', '}': 'rbrace',
}

_PAIR = re.compile(r'\\u([dD][89abAB][0-9a-fA-F]{2})\\u([dD][c-fC-F][0-9a-fA-F]{2})')
_SINGLE = re.compile(r'\\u([0-9a-fA-F]{4})')


def _decode_u(text):
    def pair(m):
        hi, lo = int(m.group(1), 16), int(m.group(2), 16)
        return chr(0x10000 + ((hi - 0xD800) << 10) + (lo - 0xDC00))
    text = _PAIR.sub(pair, text)
    return _SINGLE.sub(lambda m: chr(int(m.group(1), 16)), text)


def tokenize(expr):
    n = len(expr)
    tokens = []
    i = 0

    def tok(t, v, s):
        tokens.append({'type': t, 'value': v, 'start': s})

    def until(delim, start):
        # i points just after the opening delimiter; returns (content, next index)
        j = start + 1
        buf = []
        while j < n:
            c = expr[j]
            if c == '\\' and j + 1 < n:
                buf.append(c + expr[j + 1])
                j += 2
                continue
            if c == delim:
                return ''.join(buf), j + 1
            buf.append(c)
            j += 1
        raise LexerError(start, expr[start:], "Unclosed %s delimiter" % delim)

    while i < n:
        c = expr[i]
        if c in _WS:
            i += 1
        elif c in _SIMPLE:
            tok(_SIMPLE[c], c, i)
            i += 1
        elif c in _IDSTART:
            j = i + 1
            while j < n and expr[j] in _IDCHARS:
                j += 1
            tok('unquoted_identifier', expr[i:j], i)
            i = j
        elif c in _DIGITS or c == '-':
            j = i + 1
            while j < n and expr[j] in _DIGITS:
                j += 1
            if j - i == 1 and c == '-':
                raise LexerError(i, c, "Unknown token '-'")
            tok('number', int(expr[i:j]), i)
            i = j
        elif c == '[':
            if i + 1 < n and expr[i + 1] == ']':
                tok('flatten', '[]', i)
                i += 2
            elif i + 1 < n and expr[i + 1] == '?':
                tok('filter', '[?', i)
                i += 2
            else:
                tok('lbracket', '[', i)
                i += 1
        elif c == '"':
            content, j = until('"', i)
            try:
                value = json.loads('"%s"' % content)
            except ValueError:
                raise LexerError(i, expr[i:j], "Invalid quoted identifier")
            tok('quoted_identifier', value, i)
            i = j
        elif c == "'":
            content, j = until("'", i)
            content = content.replace("\\'", "'")
            tok('literal', _decode_u(content), i)
            i = j
        elif c == '`':
            content, j = until('`', i)
            content = content.replace('\\`', '`')
            try:
                value = json.loads(content)
            except ValueError:
                try:
                    value = json.loads('"%s"' % content.lstrip())
                except ValueError:
                    raise LexerError(i, expr[i:j], "Bad JSON literal")
            tok('literal', value, i)
            i = j
        elif c == '|':
            if i + 1 < n and expr[i + 1] == '|':
                tok('or', '||', i); i += 2
            else:
                tok('pipe', '|', i); i += 1
        elif c == '&':
            if i + 1 < n and expr[i + 1] == '&':
                tok('and', '&&', i); i += 2
            else:
                tok('expref', '&', i); i += 1
        elif c == '<':
            if i + 1 < n and expr[i + 1] == '=':
                tok('lte', '<=', i); i += 2
            else:
                tok('lt', '<', i); i += 1
        elif c == '>':
            if i + 1 < n and expr[i + 1] == '=':
                tok('gte', '>=', i); i += 2
            else:
                tok('gt', '>', i); i += 1
        elif c == '!':
            if i + 1 < n and expr[i + 1] == '=':
                tok('ne', '!=', i); i += 2
            else:
                tok('not', '!', i); i += 1
        elif c == '=':
            if i + 1 < n and expr[i + 1] == '=':
                tok('eq', '==', i); i += 2
            else:
                tok('unknown', '=', i); i += 1
        else:
            raise LexerError(i, c, "Unknown token %r" % c)
    tok('eof', '', n)
    return tokens
