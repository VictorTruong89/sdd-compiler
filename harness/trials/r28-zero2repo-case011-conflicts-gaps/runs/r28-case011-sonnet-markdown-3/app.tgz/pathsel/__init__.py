"""PathSel: declarative extraction of values from JSON-like data."""
from . import errors
from .errors import (PathSelError, EmptyExpressionError, ParseError, LexerError,
                     IncompleteExpressionError, ZeroSliceStepError,
                     UnknownFunctionError, InvalidArityError, InvalidTypeError)
from .parser import parse as _parse
from .interpreter import Interpreter as _Interpreter

__all__ = ['search', 'compile', 'ParsedExpression', 'Options']


class Options(object):
    def __init__(self, dict_cls=None, custom_functions=None):
        self.dict_cls = dict_cls
        self.custom_functions = custom_functions


class ParsedExpression(object):
    def __init__(self, expression):
        self.expression = expression
        self.parsed = _parse(expression)

    def search(self, value, options=None):
        return _Interpreter(options).visit(self.parsed, value)


def compile(expression):
    return ParsedExpression(expression)


def search(expression, data, options=None):
    return compile(expression).search(data, options)
