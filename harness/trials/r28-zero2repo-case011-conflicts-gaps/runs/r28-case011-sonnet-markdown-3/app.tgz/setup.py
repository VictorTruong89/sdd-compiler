from setuptools import setup
setup(name="pathsel", version="1.0", packages=["pathsel"])
