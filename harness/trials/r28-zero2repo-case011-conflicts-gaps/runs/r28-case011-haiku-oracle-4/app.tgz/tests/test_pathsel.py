"""Tests for pathsel. Test names carry the checklist ids they verify (test_N_<id>_...)."""

import collections
import os
import sys
from decimal import Decimal

import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import pathsel  # noqa: E402
from pathsel import (  # noqa: E402
    EmptyExpressionError,
    EvaluationOptions,
    Functions,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    SyntaxFailureError,
    TokenSyntaxError,
    UnknownFunctionError,
    ZeroSliceStepError,
    signature,
)

DOC = {
    "a": {"b": {"c": 5}},
    "people": [
        {"name": "x", "age": 3},
        {"name": "y", "age": 1},
        {"name": None, "age": 2},
    ],
    "n": [1, [2, 3], 4],
    "s": "hello",
    "zero": 0,
    "f": False,
    "empty": "",
}


def s(expr, data=DOC, options=None):
    return pathsel.search(expr, data, options)


def both(expr, data=DOC, options=None):
    """Search and compile-then-search must agree (# spec: N-000080)."""
    one = s(expr, data, options)
    two = pathsel.compile(expr).search(data, options)
    assert one == two
    return one


# -- FP-01 entries, null rules, failure kinds ----------------------------------


def test_N_000001_evaluates_against_python_data():  # spec: N-000001
    assert both("a.b.c") == 5


def test_N_000002_dotted_path_returns_nested_value():  # spec: N-000002, N-000077
    assert both("a.b") == {"c": 5}


def test_N_000003_missing_path_yields_null():  # spec: N-000003, N-000059, N-000060, N-000083, N-000084
    assert both("a.missing.deep") is None


def test_N_000016_search_entry_takes_expression_and_document():  # spec: N-000016, N-000375, N-000376, N-000378
    assert pathsel.search("a.b.c", {"a": {"b": {"c": 1}}}) == 1


def test_N_000017_compile_entry_returns_reusable_parsed_expression():  # spec: N-000017, N-000078, N-000079, N-000383, N-000384, N-000388
    parsed = pathsel.compile("a.b")
    assert parsed.search({"a": {"b": 1}}) == 1
    assert parsed.search({"a": {"b": 2}}) == 2
    assert parsed.search({"x": 1}) is None


def test_N_000086_compiling_well_formed_expression_succeeds_even_if_search_is_null():  # spec: N-000086
    parsed = pathsel.compile("missing[*].x")
    assert parsed.search({}) is None


def test_N_000087_empty_text_is_empty_expression_refusal():  # spec: N-000087, N-000088, N-000089, N-000409
    with pytest.raises(EmptyExpressionError) as info:
        pathsel.search("", DOC)
    assert isinstance(info.value, ValueError)
    with pytest.raises(EmptyExpressionError):
        pathsel.compile("")


def test_N_000090_incomplete_expressions_refuse():  # spec: N-000090, N-000092, N-000093, N-000410
    for text in ["a |", "a ==", "a &&", "foo(", "a[", "a[0", "a.[", "{a:", "!"]:
        with pytest.raises(IncompleteExpressionError) as info:
            pathsel.search(text, DOC)
        assert info.value.lex_position == len(text)


def test_N_000091_whitespace_only_is_incomplete_not_empty():  # spec: N-000091, N-000093
    for text in [" ", "\t", "\n", "\r", "  \t\n"]:
        with pytest.raises(IncompleteExpressionError):
            pathsel.search(text, DOC)


def test_N_000094_syntax_failures_refuse():  # spec: N-000094, N-000095, N-000411
    for text in ["a..b", "a.", ".a", "a b", "a)", "1", "a[*]b", "a[1:2:3:4]", "a[b]", "a.1"]:
        with pytest.raises(SyntaxFailureError) as info:
            pathsel.search(text, DOC)
        assert not isinstance(info.value, IncompleteExpressionError)


def test_N_000096_token_level_failures_are_specific_syntax_kind():  # spec: N-000096, N-000097, N-000098, N-000099, N-000100, N-000101, N-000412, N-000413, N-000414
    for text in ['"abc', "'abc", "`abc", "a = b", "a-b", "#"]:
        with pytest.raises(TokenSyntaxError) as info:
            pathsel.search(text, DOC)
        assert isinstance(info.value, SyntaxFailureError)
        assert not isinstance(info.value, (EmptyExpressionError, IncompleteExpressionError))


def test_N_000102_position_reports_offset_of_failing_token():  # spec: N-000102, N-000103, N-000104, N-000421, N-000422
    with pytest.raises(SyntaxFailureError) as info:
        pathsel.search("a b", DOC)
    assert info.value.lex_position == 2
    with pytest.raises(SyntaxFailureError) as info:
        pathsel.search("a..b", DOC)
    assert info.value.lex_position == 2
    with pytest.raises(TokenSyntaxError) as info:
        pathsel.search("a = b", DOC)
    assert info.value.lex_position == 2


def test_N_000105_refusals_are_value_errors_not_null():  # spec: N-000105, N-000106, N-000405, N-000063
    with pytest.raises(ValueError):
        pathsel.search("a b", DOC)


def test_N_000107_unquoted_identifier_selects_key():  # spec: N-000107, N-000108
    assert both("a.b") == {"c": 5}
    assert both("a . b . c") == 5  # whitespace between tokens does not change meaning (N-000109)


def test_N_000110_quoted_identifier_names_any_key():  # spec: N-000110, N-000111, N-000112, N-000113, N-000114
    data = {"a.b": 1, "x y": 2, "1st": 3, 'q"uote': 4, "é": 5, "a": {"b": 6}}
    assert s('"a.b"', data) == 1
    assert s('"x y"', data) == 2
    assert s('"1st"', data) == 3
    assert s('"q\\"uote"', data) == 4
    assert s('"\\u00e9"', data) == 5
    assert s('"a"."b"', data) == 6


def test_N_000115_identifier_on_non_object_is_null():  # spec: N-000115, N-000116, N-000125
    assert s("n.a") is None
    assert s("s.a") is None
    assert s("people.name") is None


def test_N_000117_number_cannot_be_identifier():  # spec: N-000117, N-000118
    with pytest.raises(SyntaxFailureError):
        pathsel.search("a.1", DOC)
    with pytest.raises(SyntaxFailureError):
        pathsel.search("a.-1", DOC)
    assert s('"1"', {"1": "one"}) == "one"


def test_N_000119_hyphen_is_token_error():  # spec: N-000119, N-000120, N-000121, N-000122
    with pytest.raises(TokenSyntaxError):
        pathsel.search("a-b", DOC)
    assert s('"a-b"', {"a-b": 7}) == 7


def test_N_000123_dot_at_start_end_or_doubled_refuses():  # spec: N-000123
    for text in [".a", "a.", "a..b"]:
        with pytest.raises(SyntaxFailureError):
            pathsel.search(text, DOC)


def test_N_000124_unterminated_or_illegal_quoted_identifier_refuses():  # spec: N-000124
    with pytest.raises(TokenSyntaxError):
        pathsel.search('"abc', DOC)
    with pytest.raises(TokenSyntaxError):
        pathsel.search('"a\\qb"', DOC)


# -- FP-03 indexes, slices, flatten -----------------------------------------


def test_N_000126_index_is_zero_based_and_negative_from_end():  # spec: N-000126, N-000127, N-000128, N-000129
    assert s("[0]", [10, 20, 30]) == 10
    assert s("[-1]", [10, 20, 30]) == 30
    assert s("[3]", [10, 20, 30]) is None
    assert s("[-4]", [10, 20, 30]) is None
    assert s("[0]", "abc") is None
    assert s("[0]", {"0": 1}) is None


def test_N_000130_slice_selects_new_array_with_default_step():  # spec: N-000130, N-000131, N-000135, N-000136, N-000137
    assert s("[1:3]", [0, 1, 2, 3]) == [1, 2]
    assert s("[:2]", [0, 1, 2, 3]) == [0, 1]
    assert s("[2:]", [0, 1, 2, 3]) == [2, 3]
    assert s("[::2]", [0, 1, 2, 3]) == [0, 2]
    assert s("[10:20]", [0, 1]) == []


def test_N_000132_step_may_be_negative_and_selects_from_end():  # spec: N-000132, N-000138, N-000139, N-000140
    assert s("[::-1]", [0, 1, 2]) == [2, 1, 0]
    assert s("[::-2]", [0, 1, 2, 3]) == [3, 1]
    assert s("[-1::-1]", [0, 1, 2]) == [2, 1, 0]
    assert s("[:-3:-1]", [0, 1, 2, 3]) == [3, 2]


def test_N_000133_negative_start_and_stop_add_length():  # spec: N-000133, N-000134
    assert s("[-2:]", [0, 1, 2, 3]) == [2, 3]
    assert s("[:-1]", [0, 1, 2, 3]) == [0, 1, 2]


def test_N_000141_slice_selecting_nothing_is_empty_array():  # spec: N-000141, N-000157
    assert s("[2:1]", [0, 1, 2]) == []
    assert s("[0:0]", []) == []


def test_N_000142_slice_on_non_array_is_null():  # spec: N-000142
    assert s("[0:1]", "abc") is None
    assert s("a[0:1]") is None


def test_N_000143_slice_is_projection_dropping_nulls():  # spec: N-000143, N-000144, N-000204
    assert s("[0:3].a", [{"a": 1}, {"b": 2}, {"a": 3}]) == [1, 3]


def test_N_000145_flatten_splices_one_level():  # spec: N-000145, N-000146, N-000147
    assert s("n[]") == [1, 2, 3, 4]
    assert s("[][]", [[[1], [2]], [3]]) == [1, 2, 3]
    assert s("[]", "abc") is None


def test_N_000148_flatten_is_projection_over_flattened_array():  # spec: N-000148, N-000149, N-000150
    assert s("people[].name") == ["x", "y"]
    assert s("[].a", [[{"a": 1}], [{"a": 2}]]) == [1, 2]


def test_N_000151_index_slice_flatten_can_start_expression():  # spec: N-000151
    assert s("[1]", [5, 6]) == 6


def test_N_000152_zero_slice_step_refuses():  # spec: N-000152, N-000153, N-000154, N-000415
    with pytest.raises(ZeroSliceStepError) as info:
        pathsel.search("[::0]", [1])
    assert not isinstance(info.value, SyntaxFailureError)
    with pytest.raises(ZeroSliceStepError):
        pathsel.compile("[0:1:0]")


def test_N_000155_slice_with_too_many_parts_is_syntax_failure():  # spec: N-000155
    with pytest.raises(SyntaxFailureError):
        pathsel.search("[1:2:3:4]", [1])
    with pytest.raises(SyntaxFailureError):
        pathsel.search("[a:2]", [1])


# -- FP-04 wildcards and filters --------------------------------------------


def test_N_000159_list_wildcard_projects_and_drops_nulls():  # spec: N-000159, N-000160, N-000161, N-000162, N-000204
    assert s("people[*].name") == ["x", "y"]
    assert s("[*]", [1, None, 2]) == [1, 2]


def test_N_000161_list_wildcard_on_non_array_is_null():  # spec: N-000161, N-000162
    assert s("a[*]") is None
    assert s("missing[*].x") is None


def test_N_000163_object_wildcard_projects_values_in_order():  # spec: N-000163, N-000164
    assert s("*", {"a": 1, "b": 2}) == [1, 2]
    assert s("*.x", {"a": {"x": 1}, "b": {"x": 2}}) == [1, 2]
    assert s("a.*", {"a": {"p": 3, "q": 4}}) == [3, 4]


def test_N_000165_object_wildcard_on_non_object_is_null():  # spec: N-000165
    assert s("*", [1, 2]) is None
    assert s("s.*") is None


def test_N_000166_nested_projection_yields_inner_arrays():  # spec: N-000166, N-000167
    data = {"groups": [{"items": [{"v": 1}, {"v": 2}]}, {"items": [{"v": 3}]}]}
    assert s("groups[*].items[*].v", data) == [[1, 2], [3]]


def test_N_000168_filter_keeps_true_elements_in_order():  # spec: N-000168, N-000169, N-000170, N-000171, N-000172, N-000173
    data = [{"v": 1}, {"v": 0}, {"v": None}, {"v": 3}]
    assert s("[?v]", data) == [{"v": 1}, {"v": 0}, {"v": 3}]
    assert s("[?v > `1`].v", data) == [3]


def test_N_000174_predicate_truthiness_and_zero():  # spec: N-000174, N-000175, N-000176, N-000177, N-000178, N-000179
    data = [{"v": 0}, {"v": ""}, {"v": []}, {"v": "x"}]
    assert s("[?v].v", data) == [0, "x"]


def test_N_000180_equality_in_predicate_is_json_equality():  # spec: N-000180, N-000181
    data = [{"v": 0}, {"v": False}, {"v": 1}, {"v": True}]
    assert s("[?v == `0`].v", data) == [0]
    assert s("[?v == `false`].v", data) == [False]
    assert s("[?v == `1`].v", data) == [1]


def test_N_000182_projection_reach_comparison_compares_whole_array():  # spec: N-000182, N-000183, N-000184, N-000185, N-000186, N-000187, N-000188, N-000189, N-000190, N-000191, N-000192, N-000195, N-000196, N-000197
    # The comparison ends the projection, so it compares the whole projected array.
    assert s("people[*].age == `[3, 1, 2]`") is True
    # A dot after a list wildcard joins its right-hand side (rank 4 is tighter than rank 2).
    assert s("people[*].a.b") == []  # every projected .a is null, so nothing is kept
    # An operand-initial object wildcard is rank 2, so a later dot step joins its right-hand side.
    assert s("*.b.c", {"a": {"b": {"c": 1}}}) == [1]
    # A dot-form object wildcard is rank 4, so the later dot step applies to the collected array.
    data = {"a": {"x": {"b": {"c": 1}}}}
    assert s("a.*.b", data) == [{"c": 1}]
    assert s("a.*.b.c", data) is None


def test_N_000193_nested_projection_right_hand_side_rule():  # spec: N-000193, N-000194
    data = {"xs": [{"ys": [{"z": 1}, {"z": 2}]}]}
    assert s("xs[*].ys[*].z", data) == [[1, 2]]
    assert s("xs[].ys[].z", data) == [1, 2]


def test_N_000198_projection_placement_choices_are_documented():  # spec: N-000198, N-000199
    # Slices always project; see NOTES.md for the choice.
    assert s("[0:2][0]", [[1, 2], [3]]) == [1, 3]


def test_N_000200_wildcard_followed_by_identifier_refuses():  # spec: N-000200, N-000201
    with pytest.raises(SyntaxFailureError):
        pathsel.search("*a", DOC)
    with pytest.raises(SyntaxFailureError):
        pathsel.search("a[*]b", DOC)
    with pytest.raises(SyntaxFailureError):
        pathsel.search("a*", DOC)


def test_N_000202_filter_on_non_array_is_null():  # spec: N-000202, N-000203
    assert s("a[?x]") is None
    with pytest.raises(SyntaxFailureError):
        pathsel.search("[?]", [1])


# -- FP-05 constructs, pipe, literals ----------------------------------------


def test_N_000206_multiselect_hash_builds_object_and_stores_nulls():  # spec: N-000206, N-000207, N-000208, N-000209, N-000210
    assert s("{x: a.b.c, y: missing}") == {"x": 5, "y": None}
    assert s('{"a b": s}') == {"a b": "hello"}


def test_N_000211_multiselect_list_builds_array_in_order():  # spec: N-000211, N-000212
    assert s("[a.b.c, s, missing]") == [5, "hello", None]


def test_N_000213_multiselect_placement_and_null_current_value():  # spec: N-000213, N-000214, N-000215, N-000216, N-000217, N-000218
    assert s("people[*].[name, age]") == [["x", 3], ["y", 1], [None, 2]]
    assert s("a.[b]") == [{"c": 5}]
    assert s("missing.{x: a}") is None
    # A multiselect directly after an operand, without a dot, is a grammar-level failure.
    with pytest.raises(SyntaxFailureError):
        pathsel.search("missing[a, b]", DOC)
    with pytest.raises(SyntaxFailureError):
        pathsel.search("a[b, c]", DOC)


def test_N_000219_pipe_passes_whole_result_and_binds_loosest():  # spec: N-000219, N-000220, N-000221, N-000222
    assert s("people[*].name | [0]") == "x"
    assert s("a|b.c", {"a": {"b": {"c": 2}}}) == 2
    assert s("people[*].age | length(@)") == 3


def test_N_000223_json_literal_is_value_regardless_of_document():  # spec: N-000223, N-000224, N-000225, N-000226
    assert s("`[1, 2]`") == [1, 2]
    assert s("`{\"x\": 9}`.x") == 9
    assert s("` hello`") == "hello"  # not valid JSON: read as string content
    assert s("`true`") is True


def test_N_000227_raw_string_is_string_without_json_escapes():  # spec: N-000227, N-000228, N-000229, N-000230
    assert s("'42'") == "42"
    assert s("'it\\'s'") == "it's"
    assert s("'a\\nb'") == "a\\nb"
    assert s("' keep '") == " keep "


def test_N_000231_expression_reference_is_non_null_value():  # spec: N-000231, N-000232, N-000233, N-000234, N-000235, N-000236, N-000423
    assert s("&a.b") is not None


def test_N_000237_bad_literal_or_raw_string_refuses():  # spec: N-000237
    # Neither JSON nor JSON string content: an unescaped quote inside.
    with pytest.raises(TokenSyntaxError):
        pathsel.search('`a"b`', DOC)
    # Valid JSON string content, so it is read as a string rather than refused.
    assert pathsel.search("`{bad`", DOC) == "{bad"
    with pytest.raises(TokenSyntaxError):
        pathsel.search("'unterminated", DOC)


def test_N_000238_literal_after_dot_refuses():  # spec: N-000238, N-000239
    with pytest.raises(SyntaxFailureError):
        pathsel.search("a.`1`", DOC)


def test_N_000240_multiselect_missing_closer_or_trailing_comma_refuses():  # spec: N-000240, N-000241
    for text in ["[a, b", "{x: a", "[a,]", "{x: a,}", "{x a}", "a |"]:
        with pytest.raises((SyntaxFailureError, IncompleteExpressionError)):
            pathsel.search(text, DOC)
    with pytest.raises(SyntaxFailureError):
        pathsel.search("| a", DOC)


# -- FP-06 comparisons and logic ----------------------------------------------


def test_N_000242_equality_is_deep_json_equality():  # spec: N-000242, N-000243, N-000244
    assert s("`[1, {\"a\": 2}]` == `[1, {\"a\": 2}]`") is True
    assert s("`0` == `false`") is False
    assert s("`1` == `1.0`") is True
    assert s("`1` != `2`") is True


def test_N_000245_ordering_numbers_and_strings():  # spec: N-000245, N-000246
    assert s("`1` < `2`") is True
    assert s("'a' < 'b'") is True
    assert s("'b' >= 'b'") is True
    assert s("`2` <= `1`") is False


def test_N_000247_or_and_return_operands():  # spec: N-000247, N-000248, N-000249, N-000250
    assert s("a || s") == {"b": {"c": 5}}  # a is an object, a true value
    assert s("missing || s") == "hello"
    assert s("missing && s") is None
    assert s("s && a.b.c") == 5
    assert s("zero || 'x'") == 0


def test_N_000251_not_returns_boolean_and_zero_is_true():  # spec: N-000251, N-000252
    assert s("!zero") is False
    assert s("!missing") is True
    assert s("!empty") is True


def test_N_000253_binding_order_and_grouping():  # spec: N-000253, N-000254, N-000255, N-000256, N-000257
    assert s("!a.b.c == `5`") is False  # (!a.b.c) == 5 : !5 is false
    assert s("!(a.b.c == `5`)") is False
    assert s("a.b.c == `5` && s") == "hello"
    assert s("missing || zero || s") == 0


def test_N_000258_filter_uses_same_operators():  # spec: N-000258, N-000259
    assert s("people[?age > `1` && name]") == [{"name": "x", "age": 3}]


def test_N_000260_lone_equals_refuses():  # spec: N-000260
    with pytest.raises(TokenSyntaxError):
        pathsel.search("a = 1", DOC)


def test_N_000261_lone_ampersand_or_missing_side_refuses():  # spec: N-000261
    with pytest.raises(SyntaxFailureError):
        pathsel.search("a & b", DOC)
    with pytest.raises(IncompleteExpressionError):
        pathsel.search("a &&", DOC)


# -- FP-07 functions ----------------------------------------------------------


def test_N_000262_function_calls_by_name():  # spec: N-000262, N-000263, N-000264, N-000269
    assert s("abs(`-3`)") == 3
    assert s("abs(a.b.c)") == 5


def test_N_000264_unknown_function_refuses_on_evaluation():  # spec: N-000264, N-000265, N-000266, N-000267, N-000268, N-000416
    with pytest.raises(UnknownFunctionError):
        pathsel.search("nosuch(a)", DOC)
    parsed = pathsel.compile("nosuch(a)")  # compile succeeds
    with pytest.raises(UnknownFunctionError):
        parsed.search(DOC)


def test_N_000269_abs_number():  # spec: N-000269
    assert s("abs(`-2.5`)") == 2.5


def test_N_000270_avg_of_numbers_and_empty_is_null():  # spec: N-000270, N-000271
    assert s("avg(`[1, 2, 3, 4]`)") == 2.5
    assert s("avg(`[]`)") is None


def test_N_000272_ceil_and_floor_are_integers():  # spec: N-000272, N-000273
    assert s("ceil(`1.2`)") == 2 and isinstance(s("ceil(`1.2`)"), int)
    assert s("floor(`1.8`)") == 1 and isinstance(s("floor(`1.8`)"), int)


def test_N_000274_contains_array_and_string():  # spec: N-000274, N-000275
    assert s("contains(`[1, 2]`, `2`)") is True
    assert s("contains(`[1, 2]`, `3`)") is False
    assert s("contains('abc', 'b')") is True


def test_N_000276_starts_and_ends_with():  # spec: N-000276
    assert s("starts_with(s, 'he')") is True
    assert s("ends_with(s, 'lo')") is True
    assert s("ends_with(s, 'he')") is False


def test_N_000277_length_counts_code_points():  # spec: N-000277
    assert s("length(s)") == 5
    assert s("length('é😀')") == 2
    assert s("length(`[1,2,3]`)") == 3
    assert s("length(`{\"a\":1}`)") == 1


def test_N_000278_reverse_array_and_string():  # spec: N-000278
    assert s("reverse(`[1, 2, 3]`)") == [3, 2, 1]
    assert s("reverse(s)") == "olleh"


def test_N_000279_join_strings_and_empty_array():  # spec: N-000279, N-000280
    assert s("join(', ', `[\"a\", \"b\"]`)") == "a, b"
    assert s("join(',', `[]`)") == ""


def test_N_000281_keys_and_values_in_iteration_order():  # spec: N-000281
    assert s("keys(a)") == ["b"]
    assert s("values(a.b)") == [5]


def test_N_000282_type_names():  # spec: N-000282
    assert s("type(s)") == "string"
    assert s("type(`1`)") == "number"
    assert s("type(`true`)") == "boolean"
    assert s("type(`[]`)") == "array"
    assert s("type(a)") == "object"
    assert s("type(missing)") == "null"


def test_N_000283_to_array_wraps_non_arrays():  # spec: N-000283
    assert s("to_array(s)") == ["hello"]
    assert s("to_array(`[1]`)") == [1]


def test_N_000284_to_string_compact_json_and_unicode_escapes():  # spec: N-000284, N-000285
    assert s("to_string(`{\"a\": [1, 2]}`)") == '{"a":[1,2]}'
    assert s("to_string(`\"é\"`)") == "é"
    assert s("to_string(`[\"é\"]`)") == '["\\u00e9"]'
    assert s("to_string(`null`)") == "null"


def test_N_000286_to_number_conversions():  # spec: N-000286, N-000287, N-000288, N-000289
    assert s("to_number('42')") == 42 and isinstance(s("to_number('42')"), int)
    assert s("to_number('4.5')") == 4.5
    assert s("to_number('1e3')") == 1000.0
    assert s("to_number('abc')") is None
    assert s("to_number(`true`)") is None
    assert s("to_number(`[1]`)") is None
    assert s("to_number(`7`)") == 7


def test_N_000290_max_min_of_numbers_or_strings():  # spec: N-000290, N-000291, N-000292
    assert s("max(`[1, 5, 3]`)") == 5
    assert s("min(`[1, 5, 3]`)") == 1
    assert s("max(`[\"a\", \"c\", \"b\"]`)") == "c"
    assert s("max(`[]`)") is None


def test_N_000293_sort_numbers_or_strings():  # spec: N-000293
    assert s("sort(`[3, 1, 2]`)") == [1, 2, 3]
    assert s("sort(`[\"b\", \"a\"]`)") == ["a", "b"]


def test_N_000294_sum_of_numbers():  # spec: N-000294
    assert s("sum(`[1, 2, 3.5]`)") == 6.5
    assert s("sum(`[]`)") == 0


def test_N_000295_merge_objects_later_wins():  # spec: N-000295, N-000296, N-000297
    assert s("merge(`{\"a\": 1, \"b\": 1}`, `{\"b\": 2}`)") == {"a": 1, "b": 2}
    assert s("merge(a)") == {"b": {"c": 5}}


def test_N_000298_not_null_first_non_null_and_empty_is_not_null():  # spec: N-000298, N-000299, N-000300
    assert s("not_null(missing, s, zero)") == "hello"
    assert s("not_null(missing, missing)") is None
    assert s("not_null(missing, empty)") == ""
    assert s("not_null(`[]`, missing)") == []


def test_N_000301_map_includes_nulls():  # spec: N-000301, N-000302
    assert s("map(&name, people)") == ["x", "y", None]


def test_N_000303_sort_by_stable_ascending():  # spec: N-000303, N-000304, N-000305
    data = {"xs": [{"k": 2, "id": "a"}, {"k": 1, "id": "b"}, {"k": 2, "id": "c"}, {"k": 1, "id": "d"}]}
    assert s("sort_by(xs, &k)[*].id", data) == ["b", "d", "a", "c"]


def test_N_000306_max_by_min_by_first_on_ties():  # spec: N-000306, N-000307, N-000308
    data = {"xs": [{"k": 2, "id": "a"}, {"k": 5, "id": "b"}, {"k": 5, "id": "c"}, {"k": 1, "id": "d"}]}
    assert s("max_by(xs, &k).id", data) == "b"
    assert s("min_by(xs, &k).id", data) == "d"
    assert s("max_by(`[]`, &k)") is None


def test_N_000309_function_can_be_projection_rhs():  # spec: N-000309, N-000310
    assert s("people[*].type(@)") == ["object", "object", "object"]
    assert s("people[*].to_string(@)")[0] == '{"name":"x","age":3}'


def test_N_000311_arity_refusals():  # spec: N-000311, N-000312, N-000313, N-000345
    with pytest.raises(InvalidArityError):
        pathsel.search("abs(s, s)", DOC)
    with pytest.raises(InvalidArityError):
        pathsel.search("not_null()", DOC)
    with pytest.raises(InvalidArityError):
        pathsel.search("merge()", DOC)


def test_N_000314_type_refusals():  # spec: N-000314, N-000315, N-000316, N-000317, N-000318, N-000319, N-000320
    with pytest.raises(InvalidTypeError):
        pathsel.search("abs(s)", DOC)
    with pytest.raises(InvalidTypeError):
        pathsel.search("abs(`true`)", DOC)
    with pytest.raises(InvalidTypeError):
        pathsel.search("sum(`[1, \"a\"]`)", DOC)
    with pytest.raises(InvalidTypeError):
        pathsel.search("join(',', `[1]`)", DOC)
    with pytest.raises(InvalidTypeError):
        pathsel.search("map(a, people)", DOC)
    with pytest.raises(InvalidTypeError):
        pathsel.search("sort_by(people, &name)", {"people": [{"name": "x"}, {"name": 1}]})
    with pytest.raises(InvalidTypeError):
        pathsel.search("abs(missing)", DOC)


def test_N_000321_quoted_identifier_cannot_name_function():  # spec: N-000321, N-000322
    with pytest.raises(SyntaxFailureError):
        pathsel.search('"abs"(`1`)', DOC)


# -- FP-08 evaluation options and providers -----------------------------------


class _Provider(Functions):
    @signature({"types": ["number"], "repeat": False}, {"types": ["number"]})
    def _func_add(self, a, b):
        return a + b

    @signature({"types": ["string"]})
    def _func_zero(self, _text):
        return 0


def test_N_000323_options_mapping_type_for_constructed_hashes():  # spec: N-000323, N-000324, N-000328, N-000329, N-000330, N-000331
    opts = EvaluationOptions(dict_cls=collections.OrderedDict)
    result = pathsel.search("{x: a.b.c}", DOC, opts)
    assert isinstance(result, collections.OrderedDict)
    assert result == {"x": 5}
    assert pathsel.search("{x: a.b.c}.x", DOC, opts) == 5
    assert pathsel.search("keys({x: a.b.c})", DOC, opts) == ["x"]


def test_N_000335_custom_function_provider():  # spec: N-000335, N-000336, N-000337, N-000338, N-000339, N-000340, N-000397, N-000398, N-000399, N-000400
    opts = EvaluationOptions(custom_functions=_Provider())
    assert pathsel.search("add(`2`, `3`)", DOC, opts) == 5
    assert pathsel.search("abs(`-1`)", DOC, opts) == 1  # built-ins remain
    assert pathsel.search("zero(s)", DOC, opts) == 0  # a falsy-looking return value is kept


def test_N_000341_options_carry_mapping_and_provider_together():  # spec: N-000341
    opts = EvaluationOptions(dict_cls=dict, custom_functions=_Provider())
    assert pathsel.search("add(`1`, `1`)", DOC, opts) == 2
    assert pathsel.search("{x: `1`}", DOC, opts) == {"x": 1}


def test_N_000342_one_shot_and_compiled_options_agree():  # spec: N-000342, N-000343
    opts = EvaluationOptions(custom_functions=_Provider())
    parsed = pathsel.compile("add(`1`, `2`)")  # compiling without a provider succeeds
    assert parsed.search(DOC, opts) == 3
    with pytest.raises(UnknownFunctionError):
        parsed.search(DOC)


def test_N_000344_name_declared_on_other_provider_is_unknown():  # spec: N-000344
    with pytest.raises(UnknownFunctionError):
        pathsel.search("add(`1`, `2`)", DOC, EvaluationOptions(custom_functions=Functions()))


def test_N_000345_custom_function_arity_and_type_refusals():  # spec: N-000345, N-000346, N-000347, N-000348, N-000349, N-000350
    opts = EvaluationOptions(custom_functions=_Provider())
    with pytest.raises(InvalidArityError):
        pathsel.search("add(`1`)", DOC, opts)
    with pytest.raises(InvalidTypeError):
        pathsel.search("add(s, `1`)", DOC, opts)
    with pytest.raises(InvalidTypeError):
        pathsel.search("add(`true`, `1`)", DOC, opts)


def test_N_000393_provider_signature_declaration_and_return_value_kept():  # spec: N-000393, N-000394, N-000395, N-000396, N-000401, N-000402, N-000403, N-000404
    class Declared(Functions):
        @signature()
        def _func_answer(self):
            return None

    assert pathsel.search("answer()", DOC, EvaluationOptions(custom_functions=Declared())) is None


def test_N_000401_signature_returns_decorator_that_does_not_call():  # spec: N-000401, N-000403, N-000404
    calls = []

    def impl(provider, x):
        calls.append(x)
        return x

    wrapped = signature({"types": ["number"]})(impl)
    assert calls == []
    assert wrapped(None, 3) == 3


# -- Interface and layout ----------------------------------------------------


def test_N_000372_root_names_search_and_compile():  # spec: N-000372, N-000373, N-000374
    assert callable(pathsel.search)
    assert callable(pathsel.compile)


def test_N_000371_import_has_no_side_effects():  # spec: N-000371
    import importlib

    module = importlib.import_module("pathsel.functions")
    assert hasattr(module, "Functions")


def test_N_000422_failure_carries_position_for_incomplete():  # spec: N-000422, N-000090
    with pytest.raises(IncompleteExpressionError) as info:
        pathsel.search("a.b[", DOC)
    assert isinstance(info.value.lex_position, int)
    assert 0 <= info.value.lex_position <= len("a.b[")


def test_N_000024_decimal_values_participate_in_comparisons():  # spec: N-000024, N-000056, N-000245
    assert pathsel.search("v > `1`", {"v": Decimal("2.5")}) is True
    assert pathsel.search("v == `2.5`", {"v": Decimal("2.5")}) is True
    assert pathsel.search("v", {"v": Decimal("2.5")}) == Decimal("2.5")


def test_N_000069_evaluation_does_not_mutate_input():  # spec: N-000069, N-000070
    import copy

    data = {"people": [{"name": "x"}, {"name": None}], "n": [[1], [2]]}
    before = copy.deepcopy(data)
    pathsel.search("people[*].name", data)
    pathsel.search("n[]", data)
    pathsel.search("people[?name]", data)
    assert data == before


def test_N_000067_no_json_decoding_of_document_text():  # spec: N-000067, N-000068
    assert pathsel.search("a", {"a": "{}"}) == "{}"


def test_N_000050_pure_python_package_has_no_runtime_dependencies():  # spec: N-000050, N-000051, N-000052, N-000053, N-000054, N-000055, N-000351, N-000352, N-000353, N-000354, N-000355, N-000356, N-000357, N-000358, N-000359, N-000360, N-000361, N-000362, N-000363, N-000364, N-000365, N-000369, N-000370
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    assert os.path.isfile(os.path.join(root, "pathsel", "__init__.py"))
    assert os.path.isfile(os.path.join(root, "pyproject.toml"))
    with open(os.path.join(root, "pyproject.toml")) as handle:
        text = handle.read()
    assert "dependencies = []" in text
    assert 'name = "pathsel"' in text
