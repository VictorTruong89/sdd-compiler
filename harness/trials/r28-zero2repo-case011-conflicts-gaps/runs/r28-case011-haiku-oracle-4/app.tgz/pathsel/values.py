"""Value model helpers: the six JSON types, host numbers, truthiness and equality.

Decisions recorded in NOTES.md: arrays are list and tuple; objects are any
collections.abc.Mapping; a host decimal is a number for comparison and for
type(), but is not a JSON number for function arguments.
"""

import numbers
import operator
from collections.abc import Mapping
from decimal import Decimal


class RefValue:
    """An expression reference value (# spec: N-000231, N-000234, N-000423).

    ``node`` is the referenced AST; ``apply(element)`` evaluates it with the
    element as the current value. Built-ins such as map() call apply().
    """

    __slots__ = ("node", "_apply")

    def __init__(self, node, apply):
        self.node = node
        self._apply = apply

    def apply(self, element):
        return self._apply(element)

    def __repr__(self):
        return "<PathSel expression reference>"


def is_bool(value):
    return isinstance(value, bool)


def is_json_number(value):
    """An int or float that is not a boolean (# spec: N-000025, N-000027)."""
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def is_host_number(value):
    """Numbers for comparison: JSON numbers plus host decimals and other reals (# spec: N-000024, N-000056)."""
    if isinstance(value, bool):
        return False
    return isinstance(value, (int, float, Decimal, numbers.Real))


def is_array(value):
    return isinstance(value, (list, tuple))


def is_object(value):
    return isinstance(value, Mapping)


def is_false(value):
    """The false-value set: false, null, empty string, empty array, empty object (# spec: N-000029)."""
    if value is None:
        return True
    if isinstance(value, bool):
        return value is False
    if isinstance(value, str):
        return len(value) == 0
    if is_array(value):
        return len(value) == 0
    if is_object(value):
        return len(value) == 0
    return False


def is_true(value):
    return not is_false(value)


def json_equal(a, b):
    """JSON value equality: deep for arrays and objects; a number is never equal to a boolean (# spec: N-000242, N-000243, N-000244, N-000027, N-000180, N-000181)."""
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if is_host_number(a) or is_host_number(b):
        return is_host_number(a) and is_host_number(b) and a == b
    if a is None or b is None:
        return a is None and b is None
    if isinstance(a, str) or isinstance(b, str):
        return isinstance(a, str) and isinstance(b, str) and a == b
    if is_object(a) or is_object(b):
        if not (is_object(a) and is_object(b)) or len(a) != len(b):
            return False
        for key in a:
            if key not in b or not json_equal(a[key], b[key]):
                return False
        return True
    if is_array(a) or is_array(b):
        if not (is_array(a) and is_array(b)) or len(a) != len(b):
            return False
        return all(json_equal(x, y) for x, y in zip(a, b))
    try:
        return bool(a is b or a == b)
    except Exception:  # pragma: no cover - exotic host objects
        return False


_ORDER_OPS = {
    "lt": operator.lt,
    "lte": operator.le,
    "gt": operator.gt,
    "gte": operator.ge,
}


def compare(op, a, b):
    """Ordering comparison: numbers numerically, strings by code point (# spec: N-000245, N-000246).

    Any other pair yields null (decision; see NOTES.md).
    """
    if (is_host_number(a) and is_host_number(b)) or (isinstance(a, str) and isinstance(b, str)):
        return bool(_ORDER_OPS[op](a, b))
    return None
