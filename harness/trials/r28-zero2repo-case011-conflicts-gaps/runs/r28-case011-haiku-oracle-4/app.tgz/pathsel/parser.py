"""Parser for PathSel: a Pratt parser that builds nodes from nodes.py.

Binding powers follow the spec's ranking of projection steps (# spec: N-000185 to N-000190):
flatten 9 < list wildcard, slice, object wildcard that begins an operand (20)
< filter (21) < dot step and other object wildcard (40) < index bracket (55).
Logical and comparison operators: pipe 1, or 2, and 3, comparators 5, not 45.

A projection's right-hand side takes the steps that bind tighter than the
projection (# spec: N-000191 to N-000194). Comparisons, and/or, pipes, commas
and closing tokens end every open projection (# spec: N-000195 to N-000197).
"""

from . import nodes as N
from .errors import (
    EmptyExpressionError,
    IncompleteExpressionError,
    SyntaxFailureError,
    ZeroSliceStepError,
)
from .lexer import Lexer

BP_PIPE = 1
BP_OR = 2
BP_AND = 3
BP_CMP = 5
BP_FLATTEN = 9
PROJ_STOP = 10  # right-hand sides start only at binding powers of at least 10
BP_STAR = 20  # list wildcard, slice, operand-initial object wildcard
BP_FILTER = 21
BP_DOT = 40
BP_NOT = 45
BP_BRACKET = 55

_LBP = {
    "pipe": BP_PIPE,
    "or": BP_OR,
    "and": BP_AND,
    "eq": BP_CMP,
    "ne": BP_CMP,
    "lt": BP_CMP,
    "lte": BP_CMP,
    "gt": BP_CMP,
    "gte": BP_CMP,
    "dot": BP_DOT,
}
_CMP_KINDS = frozenset(["eq", "ne", "lt", "lte", "gt", "gte"])


class _Parser:
    def __init__(self, text):
        self._n = len(text)
        self._lexer = Lexer(text)
        self._buf = []

    # -- token access -----------------------------------------------------

    def _peek(self, k=0):
        while len(self._buf) <= k:
            self._buf.append(self._lexer.next_token())
        return self._buf[k]

    def _advance(self):
        tok = self._peek()
        del self._buf[0]
        return tok

    def _fail(self, tok):
        # End of text where something was still required: incomplete (# spec: N-000090, N-000092).
        if tok.kind == "eof":
            raise IncompleteExpressionError("expression is incomplete", tok.pos)
        # Any other unexpected token: syntax (# spec: N-000094, N-000065).
        raise SyntaxFailureError("syntax error", tok.pos)

    def _lbp(self):
        tok = self._peek()
        if tok.kind == "lbracket":
            # '[]' is the flatten operator, binding looser than projections (# spec: N-000145, N-000185).
            return BP_FLATTEN if self._peek(1).kind == "rbracket" else BP_BRACKET
        return _LBP.get(tok.kind, 0)

    # -- Pratt core -------------------------------------------------------

    def _expr(self, rbp):
        tok = self._advance()
        return self._loop(self._nud(tok), rbp)

    def _loop(self, left, rbp):
        while rbp < self._lbp():
            tok = self._advance()
            left = self._led(tok, left)
        return left

    def _nud(self, tok):
        kind = tok.kind
        if kind == "ident":
            if self._peek().kind == "lparen":
                return self._funccall(tok.value)  # spec: N-000262, N-000264
            return N.Field(tok.value)  # spec: N-000107
        if kind == "qident":
            nxt = self._peek()
            if nxt.kind == "lparen":
                # A quoted identifier cannot name a function (# spec: N-000321, N-000322).
                self._fail(nxt)
            return N.Field(tok.value)  # spec: N-000110
        if kind == "string" or kind == "literal":
            return N.Literal(tok.value)  # spec: N-000223, N-000227
        if kind == "at":
            return N.Current()  # spec: N-000019
        if kind == "star":
            # Operand-initial object wildcard (# spec: N-000163, N-000164).
            return N.Proj("object", None, self._projection_rhs(BP_STAR))
        if kind == "lbracket":
            return self._nud_bracket()
        if kind == "lbrace":
            return self._multi_hash()  # spec: N-000206
        if kind == "lparen":
            inner = self._expr(0)
            close = self._peek()
            if close.kind != "rparen":
                self._fail(close)
            self._advance()
            return inner
        if kind == "not":
            return N.Not(self._expr(BP_NOT))  # spec: N-000251, N-000253
        if kind == "amp":
            # An expression reference extends to the end of the enclosing argument (# spec: N-000231, N-000232).
            return N.Ref(self._expr(0))
        self._fail(tok)

    def _led(self, tok, left):
        kind = tok.kind
        if kind == "pipe":
            return N.Chain(left, self._expr(BP_PIPE))  # spec: N-000219, N-000222
        if kind == "or":
            return N.Or(left, self._expr(BP_OR))  # spec: N-000247, N-000249
        if kind == "and":
            return N.And(left, self._expr(BP_AND))  # spec: N-000248, N-000250
        if kind in _CMP_KINDS:
            return N.Cmp(kind, left, self._expr(BP_CMP))  # spec: N-000242, N-000245
        if kind == "dot":
            return self._led_dot(left)  # spec: N-000108
        if kind == "lbracket":
            return self._led_bracket(left)
        self._fail(tok)

    # -- dot steps --------------------------------------------------------

    def _dot_operand(self):
        """The step after a dot. Only identifiers, quoted identifiers, wildcards and multiselect constructs may follow (# spec: N-000123, N-000238)."""
        tok = self._peek()
        kind = tok.kind
        if kind == "eof":
            # A dot at the end of the text is a syntax failure, not incomplete (# spec: N-000094, N-000123).
            raise SyntaxFailureError("dot is not followed by a step", self._n)
        if kind == "ident":
            self._advance()
            if self._peek().kind == "lparen":
                return self._funccall(tok.value)
            return N.Field(tok.value)
        if kind == "qident":
            self._advance()
            nxt = self._peek()
            if nxt.kind == "lparen":
                self._fail(nxt)
            return N.Field(tok.value)
        if kind == "lbracket":
            after = self._peek(1).kind
            if after in ("star", "rbracket", "question", "number", "colon"):
                # Only a multiselect list may follow a dot in brackets (# spec: N-000215).
                self._fail(self._peek(1))
            self._advance()
            return self._multi_list()
        if kind == "lbrace":
            self._advance()
            return self._multi_hash()
        if kind == "star":
            # Object wildcard in field position ranks as a dot step (# spec: N-000163, N-000187).
            self._advance()
            return N.Proj("object", None, self._projection_rhs(BP_DOT))
        self._fail(tok)

    def _led_dot(self, left):
        operand = self._dot_operand()
        operand = self._loop(operand, BP_DOT)
        return N.Chain(left, operand)

    # -- projections ------------------------------------------------------

    def _projection_rhs(self, bp):
        """The right-hand side of a projection, or None for the identity.

        The first step after the form begins the rhs; later steps join it while they bind tighter than ``bp``
        (# spec: N-000183, N-000184, N-000191, N-000192).
        """
        tok = self._peek()
        if tok.kind == "dot":
            self._advance()
            return self._loop(self._dot_operand(), bp)
        if tok.kind == "lbracket" and self._lbp() >= PROJ_STOP:
            self._advance()
            return self._loop(self._nud_bracket(), bp)
        # Anything else ends the projection; a token that cannot follow it is reported as a leftover (# spec: N-000200, N-000201).
        return None

    # -- brackets ---------------------------------------------------------

    def _nud_bracket(self):
        """A bracket at the start of an operand or of a projection right-hand side (after '[')."""
        tok = self._peek()
        kind = tok.kind
        if kind == "number" or kind == "colon":
            return self._body_node(self._index_or_slice())  # spec: N-000126, N-000130
        if kind == "star" and self._peek(1).kind == "rbracket":
            self._advance()
            self._advance()
            return N.Proj("list", None, self._projection_rhs(BP_STAR))  # spec: N-000159, N-000160
        if kind == "rbracket":
            self._advance()
            return N.Proj("flatten", None, self._projection_rhs(BP_FLATTEN))  # spec: N-000145, N-000148
        if kind == "question":
            self._advance()
            return self._filter_tail()  # spec: N-000168
        # A multiselect list is allowed here as the first step of a right-hand side (# spec: N-000211, N-000213).
        return self._multi_list()

    def _led_bracket(self, left):
        """A bracket that directly follows an operand (after '['). Only index, slice, wildcard, filter and flatten forms are allowed (# spec: N-000218)."""
        tok = self._peek()
        kind = tok.kind
        if kind == "number" or kind == "colon":
            return N.Chain(left, self._body_node(self._index_or_slice()))  # spec: N-000126, N-000130
        if kind == "star":
            nxt = self._peek(1)
            if nxt.kind == "rbracket":
                self._advance()
                self._advance()
                return N.Chain(left, N.Proj("list", None, self._projection_rhs(BP_STAR)))  # spec: N-000159
            self._fail(nxt if nxt.kind == "eof" else tok)
        if kind == "rbracket":
            self._advance()
            return N.Chain(left, N.Proj("flatten", None, self._projection_rhs(BP_FLATTEN)))  # spec: N-000145, N-000148
        if kind == "question":
            self._advance()
            return N.Chain(left, self._filter_tail())  # spec: N-000168
        self._fail(tok)

    def _filter_tail(self):
        """The predicate and closing bracket of a filter (after '[?')."""
        pred = self._expr(0)
        self._expect_rbracket()
        return N.Proj("filter", pred, self._projection_rhs(BP_FILTER))  # spec: N-000168, N-000173

    def _expect_rbracket(self):
        tok = self._peek()
        if tok.kind != "rbracket":
            self._fail(tok)
        self._advance()

    def _body_node(self, body):
        if body[0] == "index":
            return N.Index(body[1])
        _, start, stop, step = body
        return N.Proj("slice", (start, stop, step), self._projection_rhs(BP_STAR))  # spec: N-000143

    def _index_or_slice(self):
        """Parse the inside of an index or slice bracket, after '['. Returns ('index', n) or ('slice', start, stop, step)."""
        parts = [None, None, None]
        idx = 0
        sliced = False
        while True:
            tok = self._peek()
            if tok.kind == "number":
                parts[idx] = tok.value
                self._advance()
                tok = self._peek()
            if tok.kind == "colon":
                sliced = True
                idx += 1
                if idx > 2:
                    # More than three colon-separated parts (# spec: N-000155).
                    self._fail(tok)
                self._advance()
                continue
            break
        if tok.kind != "rbracket":
            self._fail(tok)
        self._advance()
        if not sliced:
            return ("index", parts[0])
        start, stop, step = parts
        if step == 0:
            raise ZeroSliceStepError("slice step is zero")  # spec: N-000152, N-000154
        return ("slice", start, stop, step)

    # -- multiselect and calls --------------------------------------------

    def _multi_list(self):
        """A multiselect list (after '[')."""
        items = []
        while True:
            items.append(self._expr(0))
            tok = self._peek()
            if tok.kind == "comma":
                self._advance()
                continue
            if tok.kind == "rbracket":
                self._advance()
                return N.MultiList(items)  # spec: N-000211, N-000212, N-000240
            self._fail(tok)

    def _multi_hash(self):
        """A multiselect hash (after '{')."""
        pairs = []
        while True:
            key_tok = self._peek()
            if key_tok.kind not in ("ident", "qident"):
                self._fail(key_tok)
            self._advance()
            colon = self._peek()
            if colon.kind != "colon":
                self._fail(colon)
            self._advance()
            pairs.append((key_tok.value, self._expr(0)))  # spec: N-000206, N-000207, N-000208
            tok = self._peek()
            if tok.kind == "comma":
                self._advance()
                continue
            if tok.kind == "rbrace":
                self._advance()
                return N.MultiHash(pairs)
            self._fail(tok)

    def _funccall(self, name):
        """A function call; the current token is '('. Arguments are full expressions (# spec: N-000262, N-000309)."""
        self._advance()
        args = []
        if self._peek().kind == "rparen":
            self._advance()
            return N.Func(name, args)
        while True:
            args.append(self._expr(0))
            tok = self._peek()
            if tok.kind == "comma":
                self._advance()
                continue
            if tok.kind == "rparen":
                self._advance()
                return N.Func(name, args)
            self._fail(tok)


def parse(text):
    """Parse expression text into an AST, or raise a refusal (# spec: N-000014, N-000042, N-000073, N-000086, N-000090, N-000094).

    Ill-formed text never succeeds (# spec: N-000042); the refusal kind is
    chosen by the first failure from left to right.
    """
    if not isinstance(text, str):
        raise TypeError("a PathSel expression must be a str")
    if text == "":
        # The zero-length text is the empty-expression kind (# spec: N-000087, N-000088).
        raise EmptyExpressionError("expression is empty")
    parser = _Parser(text)
    node = parser._expr(0)
    leftover = parser._peek()
    if leftover.kind != "eof":
        # A token left over after a complete expression (# spec: N-000094, N-000095).
        raise SyntaxFailureError("unexpected token after expression", leftover.pos)
    return node
