"""AST node types for PathSel.

Every node is evaluated against a current value. A projection always applies
to the current value and is attached with Chain, so ``a[*].b`` is
Chain(Field(a), Proj('list', rhs=Field(b))).
"""


class Node:
    __slots__ = ()


class Current(Node):
    """The current-value token ``@`` (# spec: N-000019, N-000020)."""

    __slots__ = ()


class Field(Node):
    """An identifier, quoted identifier, or dotted field step (# spec: N-000107, N-000110)."""

    __slots__ = ("name",)

    def __init__(self, name):
        self.name = name


class Literal(Node):
    """A JSON literal, raw string literal, or number-free constant (# spec: N-000223, N-000227)."""

    __slots__ = ("value",)

    def __init__(self, value):
        self.value = value


class Index(Node):
    """An integer index applied to the current value (# spec: N-000126)."""

    __slots__ = ("index",)

    def __init__(self, index):
        self.index = index


class Chain(Node):
    """Evaluate ``right`` with the value of ``left`` as current (dot step or pipe)."""

    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right


class Proj(Node):
    """A projection over the elements selected from the current value.

    ``kind`` is one of 'list', 'object', 'flatten', 'slice', 'filter'.
    ``arg`` is the slice triple or the filter predicate node. ``rhs`` is the
    right-hand side applied per element, or None for the identity.
    """

    __slots__ = ("kind", "arg", "rhs")

    def __init__(self, kind, arg, rhs):
        self.kind = kind
        self.arg = arg
        self.rhs = rhs


class MultiList(Node):
    """A multiselect list (# spec: N-000211)."""

    __slots__ = ("items",)

    def __init__(self, items):
        self.items = items


class MultiHash(Node):
    """A multiselect hash as (key, expression) pairs (# spec: N-000206)."""

    __slots__ = ("pairs",)

    def __init__(self, pairs):
        self.pairs = pairs


class Not(Node):
    """Logical not (# spec: N-000251)."""

    __slots__ = ("operand",)

    def __init__(self, operand):
        self.operand = operand


class Or(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right


class And(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right


class Cmp(Node):
    """A comparator: eq, ne, lt, lte, gt, gte (# spec: N-000242, N-000245)."""

    __slots__ = ("op", "left", "right")

    def __init__(self, op, left, right):
        self.op = op
        self.left = left
        self.right = right


class Func(Node):
    """A function call (# spec: N-000262)."""

    __slots__ = ("name", "args")

    def __init__(self, name, args):
        self.name = name
        self.args = args


class Ref(Node):
    """An expression reference ``&expr`` (# spec: N-000231)."""

    __slots__ = ("expr",)

    def __init__(self, expr):
        self.expr = expr
