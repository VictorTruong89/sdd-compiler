"""Evaluation of PathSel ASTs against ordinary Python data.

Evaluation never writes to the input document (# spec: N-000069, N-000070).
Projections drop null results (# spec: N-000204, N-000205).
"""

import copy

from . import nodes as N
from .errors import InvalidArityError, InvalidTypeError, ZeroSliceStepError
from .functions import matches, resolve
from .values import RefValue, compare, is_array, is_false, is_true, is_object, json_equal


class Context:
    """Per-search settings taken from the evaluation options (# spec: N-000328, N-000335, N-000341)."""

    __slots__ = ("dict_cls", "provider")

    def __init__(self, dict_cls=None, provider=None):
        self.dict_cls = dict_cls
        self.provider = provider


def evaluate(node, cur, ctx):
    """Evaluate ``node`` with ``cur`` as the current value.

    The result is a selected or constructed value taken from the supplied
    document (# spec: N-000015, N-000066). Null is the language's missing
    result (# spec: N-000021).
    """
    kind = type(node)
    if kind is N.Current:
        return cur
    if kind is N.Field:
        # A missing key or a field of a non-object (including an array) is null (# spec: N-000041, N-000059, N-000083, N-000084, N-000085, N-000115, N-000116, N-000125).
        if is_object(cur):
            return cur.get(node.name)
        return None
    if kind is N.Literal:
        value = node.value
        return copy.deepcopy(value) if isinstance(value, (list, dict)) else value  # spec: N-000223
    if kind is N.Index:
        if not is_array(cur):
            return None  # spec: N-000129
        i = node.index
        n = len(cur)
        if i < 0:
            i += n
        # Out-of-range indices yield null, not a failure (# spec: N-000126, N-000127, N-000128, N-000156).
        return cur[i] if 0 <= i < n else None
    if kind is N.Chain:
        return evaluate(node.right, evaluate(node.left, cur, ctx), ctx)  # spec: N-000108, N-000219
    if kind is N.Proj:
        return _projection(node, cur, ctx)
    if kind is N.MultiList:
        if cur is None:
            return None  # decision: a null current value yields null (see NOTES.md)
        return [evaluate(item, cur, ctx) for item in node.items]  # spec: N-000211, N-000212, N-000218
    if kind is N.MultiHash:
        if cur is None:
            return None
        # The constructed object uses the supplied mapping type, or a plain dict (# spec: N-000328, N-000329, N-000332, N-000333, N-000334).
        built = ctx.dict_cls() if ctx.dict_cls is not None else {}
        for key, expr in node.pairs:
            built[key] = evaluate(expr, cur, ctx)  # spec: N-000206, N-000207, N-000208
        return built
    if kind is N.Not:
        return not is_true(evaluate(node.operand, cur, ctx))  # spec: N-000251, N-000252
    if kind is N.Or:
        left = evaluate(node.left, cur, ctx)
        return left if is_true(left) else evaluate(node.right, cur, ctx)  # spec: N-000247, N-000249
    if kind is N.And:
        left = evaluate(node.left, cur, ctx)
        return left if is_false(left) else evaluate(node.right, cur, ctx)  # spec: N-000248, N-000250
    if kind is N.Cmp:
        return _comparison(node, cur, ctx)
    if kind is N.Func:
        return _call(node, cur, ctx)  # spec: N-000262, N-000264
    if kind is N.Ref:
        expr = node.expr
        return RefValue(expr, lambda element: evaluate(expr, element, ctx))  # spec: N-000231, N-000234
    raise TypeError("unknown node %r" % (node,))  # pragma: no cover


def _comparison(node, cur, ctx):
    left = evaluate(node.left, cur, ctx)
    right = evaluate(node.right, cur, ctx)
    op = node.op
    if op == "eq":
        return json_equal(left, right)  # spec: N-000242
    if op == "ne":
        return not json_equal(left, right)  # spec: N-000242
    return compare(op, left, right)  # spec: N-000245, N-000246


def _projection(node, cur, ctx):
    """A projection: select elements, apply the right-hand side, drop nulls (# spec: N-000030, N-000158, N-000159, N-000166, N-000167)."""
    kind = node.kind
    if kind == "list":
        if not is_array(cur):
            return None  # spec: N-000161, N-000162
        elements = cur
    elif kind == "object":
        if not is_object(cur):
            return None  # spec: N-000165 (decision; see NOTES.md)
        elements = list(cur.values())  # spec: N-000164
    elif kind == "flatten":
        if not is_array(cur):
            return None  # spec: N-000147
        elements = []
        for item in cur:
            if is_array(item):
                elements.extend(item)  # one level only (# spec: N-000146)
            else:
                elements.append(item)
    elif kind == "slice":
        if not is_array(cur):
            return None  # spec: N-000142 (decision; see NOTES.md)
        elements = _slice(cur, *node.arg)  # spec: N-000130 to N-000141
    elif kind == "filter":
        if not is_array(cur):
            return None  # spec: N-000202 (decision; see NOTES.md)
        elements = [item for item in cur if is_true(evaluate(node.arg, item, ctx))]  # spec: N-000168, N-000172
    else:  # pragma: no cover
        raise TypeError("unknown projection kind %r" % (kind,))

    out = []
    if node.rhs is None:
        for item in elements:
            if item is not None:
                out.append(item)  # spec: N-000204
        return out
    for item in elements:
        value = evaluate(node.rhs, item, ctx)
        if value is not None:
            out.append(value)  # spec: N-000143, N-000144, N-000204
    return out


def _slice(values, start, stop, step):
    """Python-free slice semantics from the spec (# spec: N-000131 to N-000141)."""
    n = len(values)
    if step is None:
        step = 1  # spec: N-000131
    if step == 0:
        raise ZeroSliceStepError("slice step is zero")  # spec: N-000152
    if step > 0:
        s = 0 if start is None else (start + n if start < 0 else start)  # spec: N-000134, N-000135
        e = n if stop is None else (stop + n if stop < 0 else stop)
        s = min(max(s, 0), n)  # spec: N-000136
        e = min(max(e, 0), n)
        out = []
        i = s
        while i < e:  # spec: N-000137
            out.append(values[i])
            i += step
        return out
    s = n - 1 if start is None else (start + n if start < 0 else start)  # spec: N-000138
    e = -1 if stop is None else (stop + n if stop < 0 else stop)  # spec: N-000139
    s = min(max(s, -1), n - 1)  # spec: N-000140
    e = min(max(e, -1), n - 1)
    out = []
    i = s
    while i > e:
        out.append(values[i])
        i += step
    return out


def _call(node, cur, ctx):
    implementation, owner, params = resolve(node.name, ctx.provider)  # spec: N-000264, N-000344
    nargs = len(node.args)
    repeats = bool(params) and params[-1]["repeat"]
    if repeats:
        if nargs < len(params):
            raise InvalidArityError("function %r needs at least %d argument(s)" % (node.name, len(params)))  # spec: N-000313, N-000345
    elif nargs != len(params):
        raise InvalidArityError("function %r takes %d argument(s)" % (node.name, len(params)))  # spec: N-000311, N-000312, N-000345
    values = [evaluate(arg, cur, ctx) for arg in node.args]
    for index, value in enumerate(values):
        if repeats and index >= len(params) - 1:
            allowed = params[-1]["types"]
        else:
            allowed = params[index]["types"]
        if not any(matches(value, type_name) for type_name in allowed):
            raise InvalidTypeError("argument %d of %r has the wrong type" % (index + 1, node.name))  # spec: N-000314 to N-000320, N-000346 to N-000350
    return implementation(owner, *values)
