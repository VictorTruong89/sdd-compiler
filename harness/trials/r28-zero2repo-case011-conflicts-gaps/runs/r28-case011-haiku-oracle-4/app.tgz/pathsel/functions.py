"""Language functions: the built-in set (FP-07) and the provider mechanism (FP-08, Interface Contract).

A provider is an instance of ``Functions`` or of a subclass. Each attribute named
``_func_<name>`` that was decorated with ``signature`` defines the language
function ``<name>``. The implementation receives the provider instance first,
then one already-evaluated argument per declared parameter.

Decisions recorded in NOTES.md: built-in names take precedence over provider
names, so the FP-07 functions keep their behavior; type() of a value that is
not one of the six JSON types is an invalid-type refusal.
"""

import json
import math
import re
from collections.abc import Mapping
from decimal import Decimal

from .errors import InvalidTypeError, UnknownFunctionError
from .values import RefValue, is_array, is_host_number, is_json_number, is_object, json_equal

_TYPE_NAMES = frozenset(["number", "string", "array", "object", "null", "boolean", "any", "ref"])  # spec: N-000402
_INTEGER_NUMERAL = re.compile(r"-?[0-9]+")  # spec: N-000288
_FLOAT_NUMERAL = re.compile(r"-?(?:[0-9]+\.[0-9]*|\.[0-9]+|[0-9]+)(?:[eE][+-]?[0-9]+)?")  # spec: N-000289


def signature(*arguments):
    """Declare the parameter types of a language function (# spec: N-000401, N-000402, N-000403, N-000404).

    Each argument is a mapping ``{"types": [...]}``, one per parameter, in call
    order. A parameter accepts a value if the value matches any listed type.
    The decorator stores the declaration and returns the implementation unchanged.
    """
    params = []
    for arg in arguments:
        if not isinstance(arg, Mapping):
            raise TypeError("each signature argument must be a mapping with a 'types' list")
        types = arg.get("types")
        if not isinstance(types, (list, tuple)) or not types:
            raise TypeError("'types' must be a non-empty list")
        for name in types:
            if name not in _TYPE_NAMES:
                raise TypeError("unknown parameter type %r" % (name,))
        params.append({"types": tuple(types), "repeat": bool(arg.get("repeat", False))})
    for param in params[:-1]:
        if param["repeat"]:
            raise TypeError("only the last parameter may repeat")
    frozen = tuple(params)

    def decorator(implementation):
        implementation._pathsel_params = frozen
        return implementation

    return decorator


def matches(value, type_name):
    """Whether a value satisfies one declared parameter type (# spec: N-000057, N-000058, N-000314, N-000350).

    Host values that are not JSON types fail every type except 'any' (# spec: N-000058).
    """
    if type_name == "any":
        return True
    if type_name == "number":
        return is_json_number(value)
    if type_name == "string":
        return isinstance(value, str)
    if type_name == "array":
        return is_array(value)
    if type_name == "object":
        return is_object(value)
    if type_name == "null":
        return value is None
    if type_name == "boolean":
        return isinstance(value, bool)
    if type_name == "ref":
        return isinstance(value, RefValue)
    return False


def _require_numbers(values):
    for value in values:
        if not is_json_number(value):
            raise InvalidTypeError("array elements must be numbers")  # spec: N-000316


def _key_kind(values):
    """Return 'number' or 'string' if all values share one of those types, else refuse (# spec: N-000289, N-000305, N-000316)."""
    if all(is_json_number(v) for v in values):
        return "number"
    if all(isinstance(v, str) for v in values):
        return "string"
    raise InvalidTypeError("values must all be numbers or all be strings")


def _plain(value):
    """Convert a value to plain JSON containers for serialization."""
    if is_object(value):
        return {k: _plain(v) for k, v in value.items()}
    if is_array(value):
        return [_plain(v) for v in value]
    return value


def _host_default(value):
    if isinstance(value, Decimal):
        return float(value)
    return str(value)


class Functions:
    """The provider of the built-in language functions (# spec: N-000033, N-000263, N-000393, N-000395, N-000396).

    A caller extends it by subclassing and decorating ``_func_<name>`` methods
    with ``signature`` (# spec: N-000394, N-000397).
    """

    # -- numeric --------------------------------------------------------

    @signature({"types": ["number"]})
    def _func_abs(self, n):  # spec: N-000269
        return abs(n)

    @signature({"types": ["array"]})
    def _func_avg(self, values):  # spec: N-000270, N-000271
        _require_numbers(values)
        if not values:
            return None
        return sum(values) / len(values)

    @signature({"types": ["number"]})
    def _func_ceil(self, n):  # spec: N-000272
        try:
            return math.ceil(n)
        except (OverflowError, ValueError):
            return n

    @signature({"types": ["number"]})
    def _func_floor(self, n):  # spec: N-000273
        try:
            return math.floor(n)
        except (OverflowError, ValueError):
            return n

    @signature({"types": ["array"]})
    def _func_max(self, values):  # spec: N-000290, N-000292
        if not values:
            return None
        _key_kind(values)
        return max(values)

    @signature({"types": ["array"]})
    def _func_min(self, values):  # spec: N-000290, N-000292
        if not values:
            return None
        _key_kind(values)
        return min(values)

    @signature({"types": ["array"]})
    def _func_sum(self, values):  # spec: N-000294
        _require_numbers(values)
        return sum(values)

    # -- strings and arrays ---------------------------------------------

    @signature({"types": ["array", "string"]}, {"types": ["any"]})
    def _func_contains(self, subject, value):  # spec: N-000274, N-000275
        if is_array(subject):
            return any(json_equal(item, value) for item in subject)
        if isinstance(value, str):
            return value in subject
        return False

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_ends_with(self, text, suffix):  # spec: N-000276
        return text.endswith(suffix)

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_starts_with(self, text, prefix):  # spec: N-000276
        return text.startswith(prefix)

    @signature({"types": ["string", "array", "object"]})
    def _func_length(self, value):  # spec: N-000277
        # Strings count Unicode code points, not UTF-8 bytes (decision; see NOTES.md).
        return len(value)

    @signature({"types": ["array", "string"]})
    def _func_reverse(self, value):  # spec: N-000278
        if isinstance(value, str):
            return value[::-1]
        return list(reversed(value))

    @signature({"types": ["string"]}, {"types": ["array"]})
    def _func_join(self, separator, parts):  # spec: N-000279, N-000280
        for part in parts:
            if not isinstance(part, str):
                raise InvalidTypeError("join requires an array of strings")  # spec: N-000317
        return separator.join(parts)

    @signature({"types": ["object"]})
    def _func_keys(self, obj):  # spec: N-000281
        return list(obj.keys())

    @signature({"types": ["object"]})
    def _func_values(self, obj):  # spec: N-000281
        return list(obj.values())

    @signature({"types": ["array"]})
    def _func_sort(self, values):  # spec: N-000293
        _key_kind(values)
        return sorted(values)

    # -- conversions and type ---------------------------------------------

    @signature({"types": ["any"]})
    def _func_type(self, value):  # spec: N-000282, N-000314
        if value is None:
            return "null"
        if isinstance(value, bool):
            return "boolean"
        if is_host_number(value):
            return "number"
        if isinstance(value, str):
            return "string"
        if is_array(value):
            return "array"
        if is_object(value):
            return "object"
        raise InvalidTypeError("type() requires a JSON value")

    @signature({"types": ["any"]})
    def _func_to_array(self, value):  # spec: N-000283
        if isinstance(value, list):
            return value
        if isinstance(value, tuple):
            return list(value)
        return [value]

    @signature({"types": ["any"]})
    def _func_to_string(self, value):  # spec: N-000284, N-000285
        if isinstance(value, str):
            return value
        return json.dumps(_plain(value), separators=(",", ":"), ensure_ascii=True, default=_host_default)

    @signature({"types": ["any"]})
    def _func_to_number(self, value):  # spec: N-000286, N-000287, N-000288, N-000289
        if is_host_number(value):
            return value
        if isinstance(value, str):
            text = value.strip(" \t\n\r")
            if _INTEGER_NUMERAL.fullmatch(text):
                return int(text)
            if _FLOAT_NUMERAL.fullmatch(text):
                return float(text)
        return None

    # -- objects and logic ------------------------------------------------

    @signature({"types": ["object"], "repeat": True})
    def _func_merge(self, *objects):  # spec: N-000295, N-000296, N-000297
        result = {}
        for obj in objects:
            result.update(obj)
        return result

    @signature({"types": ["any"], "repeat": True})
    def _func_not_null(self, *values):  # spec: N-000022, N-000298, N-000299, N-000300
        # An empty array or empty string is not null (decision; see NOTES.md).
        for value in values:
            if value is not None:
                return value
        return None

    # -- expression-reference functions -----------------------------------

    @signature({"types": ["ref"]}, {"types": ["array"]})
    def _func_map(self, ref, values):  # spec: N-000301, N-000302
        return [ref.apply(item) for item in values]

    @signature({"types": ["array"]}, {"types": ["ref"]})
    def _func_sort_by(self, values, ref):  # spec: N-000303, N-000304, N-000305
        if not values:
            return []
        keys = [ref.apply(item) for item in values]
        _key_kind(keys)
        order = sorted(range(len(values)), key=lambda i: keys[i])  # stable
        return [values[i] for i in order]

    @signature({"types": ["array"]}, {"types": ["ref"]})
    def _func_max_by(self, values, ref):  # spec: N-000306, N-000308
        if not values:
            return None
        keys = [ref.apply(item) for item in values]
        _key_kind(keys)
        best = 0
        for i in range(1, len(values)):
            if keys[i] > keys[best]:
                best = i
        return values[best]

    @signature({"types": ["array"]}, {"types": ["ref"]})
    def _func_min_by(self, values, ref):  # spec: N-000306, N-000308
        if not values:
            return None
        keys = [ref.apply(item) for item in values]
        _key_kind(keys)
        best = 0
        for i in range(1, len(values)):
            if keys[i] < keys[best]:
                best = i
        return values[best]


_BUILTIN_PROVIDER = Functions()
_BUILTINS = {}
for _attr, _value in vars(Functions).items():
    if _attr.startswith("_func_") and hasattr(_value, "_pathsel_params"):
        _BUILTINS[_attr[len("_func_"):]] = (_value, _value._pathsel_params)


def resolve(name, provider):
    """Return (implementation, owner, parameters) for a function name, or raise unknown-function.

    Built-ins are looked up first. A provider's ``_func_<name>`` that carries a
    signature defines a custom function; it receives the provider instance
    first (# spec: N-000264, N-000344, N-000397, N-000398, N-000399, N-000400).
    """
    entry = _BUILTINS.get(name)
    if entry is not None:
        return entry[0], _BUILTIN_PROVIDER, entry[1]
    if provider is not None:
        implementation = getattr(type(provider), "_func_" + name, None)
        params = getattr(implementation, "_pathsel_params", None)
        if params is not None:
            return implementation, provider, params
    raise UnknownFunctionError("unknown function %r" % (name,))
