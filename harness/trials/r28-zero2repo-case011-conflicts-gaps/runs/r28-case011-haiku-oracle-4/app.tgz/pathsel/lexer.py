"""Tokenizer for PathSel.

Tokens are produced on demand, so the first failure in left-to-right order is
the one that is reported. Token-level failures raise TokenSyntaxError with the
offset where the unreadable token begins (# spec: N-000096, N-000102, N-000103).
"""

import json
import re

from .errors import TokenSyntaxError

_WHITESPACE = " \t\n\r"  # spec: N-000109
_IDENT_START = frozenset("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_")  # spec: N-000107
_IDENT_CHARS = _IDENT_START | frozenset("0123456789")
_DIGITS = frozenset("0123456789")
_NUMBER_RE = re.compile(r"-?[0-9]+")  # spec: N-000117, N-000155

_PUNCTUATION = {
    ".": "dot",
    "*": "star",
    "[": "lbracket",
    "]": "rbracket",
    "{": "lbrace",
    "}": "rbrace",
    "(": "lparen",
    ")": "rparen",
    ",": "comma",
    ":": "colon",
    "@": "at",
    "?": "question",
}


class Token:
    __slots__ = ("kind", "value", "pos")

    def __init__(self, kind, value, pos):
        self.kind = kind
        self.value = value
        self.pos = pos

    def __repr__(self):
        return "Token(%r, %r, %d)" % (self.kind, self.value, self.pos)


class Lexer:
    def __init__(self, text):
        self._text = text
        self._n = len(text)
        self._i = 0

    def next_token(self):
        text = self._text
        n = self._n
        i = self._i
        while i < n and text[i] in _WHITESPACE:
            i += 1
        if i >= n:
            self._i = n
            return Token("eof", None, n)
        start = i
        c = text[i]
        if c in _IDENT_START:
            j = i + 1
            while j < n and text[j] in _IDENT_CHARS:
                j += 1
            self._i = j
            return Token("ident", text[i:j], start)
        if c in _DIGITS or (c == "-" and i + 1 < n and text[i + 1] in _DIGITS):
            match = _NUMBER_RE.match(text, i)
            self._i = match.end()
            return Token("number", int(match.group(0)), start)
        if c == "-":
            # A lone hyphen begins no token (# spec: N-000119, N-000121, N-000122).
            raise TokenSyntaxError("hyphen begins no token", start)
        if c == '"':
            return self._quoted_identifier(start)
        if c == "'":
            return self._raw_string(start)
        if c == "`":
            return self._json_literal(start)
        if c in _PUNCTUATION:
            self._i = i + 1
            return Token(_PUNCTUATION[c], None, start)
        nxt = text[i + 1] if i + 1 < n else ""
        if c == "|":
            if nxt == "|":
                self._i = i + 2
                return Token("or", None, start)
            self._i = i + 1
            return Token("pipe", None, start)
        if c == "&":
            if nxt == "&":
                self._i = i + 2
                return Token("and", None, start)
            self._i = i + 1
            return Token("amp", None, start)
        if c == "!":
            if nxt == "=":
                self._i = i + 2
                return Token("ne", None, start)
            self._i = i + 1
            return Token("not", None, start)
        if c == "=":
            if nxt == "=":
                self._i = i + 2
                return Token("eq", None, start)
            # A lone '=' is a token-level failure (# spec: N-000260).
            raise TokenSyntaxError("lone '=' begins no token", start)
        if c == "<":
            if nxt == "=":
                self._i = i + 2
                return Token("lte", None, start)
            self._i = i + 1
            return Token("lt", None, start)
        if c == ">":
            if nxt == "=":
                self._i = i + 2
                return Token("gte", None, start)
            self._i = i + 1
            return Token("gt", None, start)
        raise TokenSyntaxError("character %r begins no token" % c, start)

    def _quoted_identifier(self, start):
        # A JSON string literal in double quotes (# spec: N-000110 to N-000114, N-000124).
        text = self._text
        n = self._n
        j = start + 1
        while True:
            if j >= n:
                raise TokenSyntaxError("unterminated quoted identifier", start)
            ch = text[j]
            if ch == "\\":
                j += 2
                continue
            if ch == '"':
                break
            j += 1
        try:
            value = json.loads(text[start:j + 1])
        except ValueError:
            raise TokenSyntaxError("quoted identifier is not a legal JSON string", start)
        self._i = j + 1
        return Token("qident", value, start)

    def _raw_string(self, start):
        # Raw string: no JSON escapes except backslash-quote (# spec: N-000227 to N-000230).
        text = self._text
        n = self._n
        j = start + 1
        buf = []
        while True:
            if j >= n:
                raise TokenSyntaxError("unterminated raw string literal", start)
            ch = text[j]
            if ch == "\\" and j + 1 < n and text[j + 1] == "'":
                buf.append("'")
                j += 2
                continue
            if ch == "'":
                break
            buf.append(ch)
            j += 1
        self._i = j + 1
        return Token("string", "".join(buf), start)

    def _json_literal(self, start):
        # JSON literal between backticks; falls back to JSON string content (# spec: N-000223 to N-000226, N-000237).
        text = self._text
        n = self._n
        j = start + 1
        while True:
            if j >= n:
                raise TokenSyntaxError("unterminated JSON literal", start)
            ch = text[j]
            if ch == "\\":
                j += 2
                continue
            if ch == "`":
                break
            j += 1
        content = text[start + 1:j]
        try:
            value = json.loads(content)
        except ValueError:
            stripped = content.lstrip(_WHITESPACE)
            try:
                value = json.loads('"' + stripped + '"')
            except ValueError:
                raise TokenSyntaxError("JSON literal is neither JSON nor JSON string content", start)
        self._i = j + 1
        return Token("literal", value, start)
