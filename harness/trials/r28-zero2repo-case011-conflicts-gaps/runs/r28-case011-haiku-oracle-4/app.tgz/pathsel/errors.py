"""Refusal kinds for PathSel.

Every refusal is a ValueError (# spec: N-000405). The kind of a refusal is the
type of the raised exception (# spec: N-000406, N-000407, N-000408). Type names
are this implementation's choice; the required relations between them are:

* EmptyExpressionError, IncompleteExpressionError and SyntaxFailureError are
  three different types (# spec: N-000413, N-000414).
* TokenSyntaxError is a subclass of SyntaxFailureError but not the same type
  (# spec: N-000412).
* ZeroSliceStepError is not a syntax failure (# spec: N-000415).
* UnknownFunctionError, InvalidArityError and InvalidTypeError each have their
  own type and are not instances of one another (# spec: N-000416 to N-000420).
"""


class PathSelError(ValueError):
    """Base class of every refusal (# spec: N-000034, N-000035, N-000036, N-000064, N-000105, N-000405).

    Every refusal belongs to exactly one kind, and every kind is a value error.
    Failure messages are informational (# spec: N-000037, N-000061, N-000062, N-000408).
    """


class EmptyExpressionError(PathSelError):
    """The zero-length expression text (# spec: N-000409, N-000087)."""


class _PositionedError(PathSelError):
    """A refusal that carries the position of the failing token (# spec: N-000421, N-000422)."""

    def __init__(self, message, lex_position):
        super().__init__(message)
        self.lex_position = lex_position


class IncompleteExpressionError(_PositionedError):
    """Text ended where an operand or a closing token was still required (# spec: N-000410)."""


class SyntaxFailureError(_PositionedError):
    """Grammar-level syntax failure (# spec: N-000411)."""


class TokenSyntaxError(SyntaxFailureError):
    """Token-level syntax failure: a more specific form of the syntax kind (# spec: N-000412, N-000096)."""


class ZeroSliceStepError(PathSelError):
    """A slice whose step is zero (# spec: N-000415, N-000152)."""


class UnknownFunctionError(PathSelError):
    """A function name that is neither built in nor supplied by the provider (# spec: N-000416, N-000344)."""


class InvalidArityError(PathSelError):
    """A function called with the wrong number of arguments (# spec: N-000417, N-000311, N-000345)."""


class InvalidTypeError(PathSelError):
    """A function argument outside its accepted types (# spec: N-000418, N-000314, N-000346, N-000419)."""
