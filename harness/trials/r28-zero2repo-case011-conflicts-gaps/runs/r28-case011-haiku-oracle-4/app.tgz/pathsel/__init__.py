"""pathsel: evaluate PathSel expressions against ordinary Python data.

Public names: ``search``, ``compile`` (# spec: N-000372, N-000373). Other names
are this implementation's choice (# spec: N-000374).

Outcomes are returned or raised; library calls never exit the process
(# spec: N-000366 to N-000368, N-000371).

Surface (# spec: N-000038, N-000040, N-000043 to N-000049, N-000010, N-000011):
search and compile (FP-01, N-000040); field selection (FP-02, N-000043);
index, slice and flatten (FP-03, N-000044); wildcards and filters (FP-04,
N-000045); constructs, pipe and literals (FP-05, N-000046); comparisons and
logic (FP-06, N-000047); built-in functions (FP-07, N-000048); evaluation
options and providers (FP-08, N-000049). Every feature point FP-01 to FP-08 is
implemented (# spec: N-000012). There is no command-line program
(# spec: N-000039). Product form: an importable library, no network service
and no configuration file (# spec: N-000367).
"""

from .errors import (
    EmptyExpressionError,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    PathSelError,
    SyntaxFailureError,
    TokenSyntaxError,
    UnknownFunctionError,
    ZeroSliceStepError,
)
from .functions import Functions, signature
from .interpreter import Context, evaluate
from .options import EvaluationOptions
from .parser import parse
from .values import RefValue

__all__ = [
    "search",
    "compile",
    "Parsed",
    "EvaluationOptions",
    "Functions",
    "signature",
    "PathSelError",
    "EmptyExpressionError",
    "IncompleteExpressionError",
    "SyntaxFailureError",
    "TokenSyntaxError",
    "ZeroSliceStepError",
    "UnknownFunctionError",
    "InvalidArityError",
    "InvalidTypeError",
    "RefValue",
]


def _context(options):
    # Options are read as attributes; None means no options. Options add a mapping type and an extra function set (# spec: N-000325, N-000326, N-000327, N-000377, N-000386, N-000387).
    if options is None:
        return Context()
    return Context(
        dict_cls=getattr(options, "dict_cls", None),
        provider=getattr(options, "custom_functions", None),
    )


class Parsed:
    """A compiled expression that can be searched many times (# spec: N-000005, N-000018, N-000078, N-000384, N-000385).

    The parsed object's type is this implementation's choice (# spec: N-000385).
    """

    __slots__ = ("_ast",)

    def __init__(self, ast):
        self._ast = ast

    def search(self, value, options=None):
        """Evaluate against ``value``; returns the selected value or raises a refusal.

        Returns the selected or constructed value; on refusal it raises and
        returns nothing (# spec: N-000008, N-000009, N-000379, N-000380, N-000381, N-000388, N-000079, N-000342).
        """
        return evaluate(self._ast, value, _context(options))


def compile(expression):  # spec: N-000005, N-000006, N-000017, N-000074, N-000075, N-000076, N-000383, N-000086
    """Parse an expression once. Returns a Parsed object, or raises a refusal."""
    return Parsed(parse(expression))


def search(expression, data, options=None):  # spec: N-000004, N-000007, N-000016, N-000073, N-000074, N-000075, N-000076, N-000375 to N-000382, N-000082
    """Evaluate an expression against data in one shot.

    The one-shot search and compile-then-search share one parser and one
    evaluator, so they return equal values and refuse the same texts
    (# spec: N-000007, N-000080, N-000081, N-000082).
    """
    return compile(expression).search(data, options)
