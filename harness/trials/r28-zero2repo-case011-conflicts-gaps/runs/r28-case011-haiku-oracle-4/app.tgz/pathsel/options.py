"""Evaluation options (# spec: N-000032, N-000389, N-000390, N-000391, N-000392).

Any object with ``dict_cls`` and ``custom_functions`` attributes is accepted.
This class is an optional convenience holder.
"""


class EvaluationOptions:
    """Holds the two evaluation-option attributes read by the library."""

    def __init__(self, dict_cls=None, custom_functions=None):
        self.dict_cls = dict_cls  # a mapping type, or None (# spec: N-000390)
        self.custom_functions = custom_functions  # a Functions provider instance, or None (# spec: N-000391)
