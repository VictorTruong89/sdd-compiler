from .exceptions import (EmptyExpressionError, IncompleteExpressionError,
                         ParseError, ZeroSliceStepError)
from .lexer import tokenize

BP = {
    "eof": 0, "unquoted_identifier": 0, "quoted_identifier": 0, "literal": 0,
    "rbracket": 0, "rparen": 0, "comma": 0, "rbrace": 0, "number": 0,
    "current": 0, "expref": 0, "colon": 0, "pipe": 1, "or": 2, "and": 3,
    "eq": 5, "gt": 5, "lt": 5, "gte": 5, "lte": 5, "ne": 5,
    "flatten": 9, "star": 20, "filter": 21, "dot": 40, "not": 45,
    "lbrace": 50, "lbracket": 55, "lparen": 60,
}
COMPARATORS = ("eq", "gt", "lt", "gte", "lte", "ne")
IDENTITY = ("identity",)


class Parser(object):
    def __init__(self, expr):
        self.expr = expr
        self.tokens = tokenize(expr)
        self.pos = 0

    # helpers
    def cur(self):
        return self.tokens[self.pos]

    def ctype(self):
        return self.tokens[self.pos][0]

    def ltype(self, n):
        i = self.pos + n
        return self.tokens[i][0] if i < len(self.tokens) else "eof"

    def advance(self):
        self.pos += 1

    def err(self, token=None, force_syntax=False):
        if token is None:
            token = self.cur()
        t, v, s = token
        if t == "eof" and not force_syntax:
            raise IncompleteExpressionError("Unexpected end of expression", s)
        if t == "eof":
            raise ParseError("Unexpected end of expression", s)
        raise ParseError("Unexpected token %r" % (v,), s)

    def match(self, typ):
        if self.ctype() == typ:
            self.advance()
        else:
            self.err()

    def parse(self):
        if self.expr == "":
            raise EmptyExpressionError("Empty expression")
        node = self.expression(0)
        if self.ctype() != "eof":
            self.err()
        return node

    def expression(self, bp=0):
        tok = self.cur()
        self.advance()
        left = self.nud(tok)
        while bp < BP[self.ctype()]:
            tok = self.cur()
            self.advance()
            left = self.led(tok, left)
        return left

    # null denotations
    def nud(self, tok):
        t, v, s = tok
        if t == "literal":
            return ("literal", v)
        if t == "unquoted_identifier":
            return ("field", v)
        if t == "quoted_identifier":
            if self.ctype() == "lparen":
                raise ParseError("Quoted identifier cannot be a function name", self.cur()[2])
            return ("field", v)
        if t == "star":
            right = self.proj_rhs(BP["star"])
            return ("value_projection", IDENTITY, right)
        if t == "filter":
            return self.led_filter(IDENTITY)
        if t == "lbrace":
            return self.multiselect_hash()
        if t == "flatten":
            right = self.proj_rhs(BP["flatten"])
            return ("projection", ("flatten", IDENTITY), right)
        if t == "not":
            return ("not", self.expression(BP["not"]))
        if t == "lparen":
            e = self.expression(0)
            self.match("rparen")
            return e
        if t == "current":
            return IDENTITY
        if t == "expref":
            return ("expref", self.expression(0))
        if t == "lbracket":
            if self.ctype() in ("number", "colon"):
                right = self.index_expression()
                return self.project_if_slice(IDENTITY, right)
            if self.ctype() == "star" and self.ltype(1) == "rbracket":
                self.advance()
                self.advance()
                right = self.proj_rhs(BP["star"])
                return ("projection", IDENTITY, right)
            return self.multiselect_list()
        self.err(tok)

    # left denotations
    def led(self, tok, left):
        t, v, s = tok
        if t == "dot":
            if self.ctype() != "star":
                right = self.parse_dot(BP["dot"])
                return ("subexpr", left, right)
            self.advance()
            right = self.proj_rhs(BP["star"])
            return ("value_projection", left, right)
        if t == "pipe":
            return ("pipe", left, self.expression(BP["pipe"]))
        if t == "or":
            return ("or", left, self.expression(BP["or"]))
        if t == "and":
            return ("and", left, self.expression(BP["and"]))
        if t in COMPARATORS:
            return ("comparator", t, left, self.expression(BP[t]))
        if t == "flatten":
            right = self.proj_rhs(BP["flatten"])
            return ("projection", ("flatten", left), right)
        if t == "filter":
            return self.led_filter(left)
        if t == "lparen":
            if left[0] != "field" or left[0] == "literal":
                raise ParseError("Invalid function call", s)
            args = []
            while self.ctype() != "rparen":
                args.append(self.expression(0))
                if self.ctype() == "comma":
                    self.advance()
                    if self.ctype() == "rparen":
                        self.err()
            self.match("rparen")
            return ("function", left[1], args)
        if t == "lbracket":
            if self.ctype() in ("number", "colon"):
                right = self.index_expression()
                return self.project_if_slice(left, right)
            self.match("star")
            self.match("rbracket")
            right = self.proj_rhs(BP["star"])
            return ("projection", left, right)
        self.err(tok)

    def led_filter(self, left):
        cond = self.expression(0)
        self.match("rbracket")
        right = self.proj_rhs(BP["filter"])
        return ("filter_projection", left, right, cond)

    def project_if_slice(self, left, right):
        node = ("subexpr", left, right)
        if right[0] == "slice":
            return ("projection", node, self.proj_rhs(BP["star"]))
        return node

    def index_expression(self):
        if self.ctype() == "colon" or self.ltype(1) == "colon":
            parts = [None, None, None]
            idx = 0
            while self.ctype() != "rbracket":
                t = self.ctype()
                if t == "colon":
                    idx += 1
                    if idx == 3:
                        self.err(force_syntax=True)
                    self.advance()
                elif t == "number":
                    parts[idx] = self.cur()[1]
                    self.advance()
                else:
                    self.err()
            self.match("rbracket")
            if parts[2] == 0:
                raise ZeroSliceStepError("Slice step cannot be zero")
            return ("slice",) + tuple(parts)
        node = ("index", self.cur()[1])
        self.advance()
        self.match("rbracket")
        return node

    def proj_rhs(self, bp):
        t = self.ctype()
        if BP[t] < 10:
            return IDENTITY
        if t == "lbracket" or t == "filter":
            return self.expression(bp)
        if t == "dot":
            self.advance()
            return self.parse_dot(bp)
        self.err()

    def parse_dot(self, bp):
        t = self.ctype()
        if t in ("unquoted_identifier", "quoted_identifier", "star"):
            return self.expression(bp)
        if t == "lbracket":
            self.advance()
            return self.multiselect_list()
        if t == "lbrace":
            self.advance()
            return self.multiselect_hash()
        self.err(force_syntax=True)

    def multiselect_list(self):
        exprs = []
        while True:
            exprs.append(self.expression(0))
            if self.ctype() == "comma":
                self.advance()
                if self.ctype() == "rbracket":
                    self.err()
            else:
                self.match("rbracket")
                break
        return ("multi_list", exprs)

    def multiselect_hash(self):
        pairs = []
        while True:
            t = self.ctype()
            if t not in ("unquoted_identifier", "quoted_identifier"):
                self.err()
            key = self.cur()[1]
            self.advance()
            self.match("colon")
            pairs.append((key, self.expression(0)))
            if self.ctype() == "comma":
                self.advance()
            elif self.ctype() == "rbrace":
                self.advance()
                break
            else:
                self.err()
        return ("multi_hash", pairs)


def parse(expr):
    return Parser(expr).parse()
