"""PathSel: JSON path-expression evaluation."""
from . import exceptions
from .exceptions import (ArityError, EmptyExpressionError,
                         IncompleteExpressionError, InvalidTypeError,
                         LexerError, ParseError, PathSelError,
                         UnknownFunctionError, ZeroSliceStepError)
from .interpreter import Interpreter
from .parser import parse as _parse


class ParsedExpression(object):
    def __init__(self, expression, ast):
        self.expression = expression
        self._ast = ast

    def search(self, value, options=None):
        return Interpreter(options).visit(self._ast, value)


def compile(expression):
    return ParsedExpression(expression, _parse(expression))


def search(expression, data, options=None):
    return compile(expression).search(data, options)


__all__ = ["search", "compile"]
