"""Failure kinds. Every one is a ValueError."""


class PathSelError(ValueError):
    pass


class EmptyExpressionError(PathSelError):
    pass


class IncompleteExpressionError(PathSelError):
    def __init__(self, message, lex_position=0):
        PathSelError.__init__(self, "%s (position %d)" % (message, lex_position))
        self.lex_position = lex_position


class ParseError(PathSelError):
    """Grammar-level syntax failure."""

    def __init__(self, message, lex_position=0):
        PathSelError.__init__(self, "%s (position %d)" % (message, lex_position))
        self.lex_position = lex_position


class LexerError(ParseError):
    """Token-level syntax failure."""


class ZeroSliceStepError(PathSelError):
    pass


class UnknownFunctionError(PathSelError):
    pass


class ArityError(PathSelError):
    pass


class InvalidTypeError(PathSelError):
    pass
