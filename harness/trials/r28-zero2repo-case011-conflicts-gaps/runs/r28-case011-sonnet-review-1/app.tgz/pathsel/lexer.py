import json
import re

from .exceptions import LexerError

_IDENT_START = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_")
_IDENT = _IDENT_START | set("0123456789")
_DIGITS = set("0123456789")
_WS = " \t\n\r"
_SIMPLE = {
    "]": "rbracket", "{": "lbrace", "}": "rbrace", "(": "lparen",
    ")": "rparen", ",": "comma", ":": "colon", "*": "star", ".": "dot",
    "@": "current",
}
_RAW = re.compile(r"\\'|\\u([0-9a-fA-F]{4})")


def _raw_sub(m):
    if m.group(1) is None:
        return "'"
    return chr(int(m.group(1), 16))


def tokenize(expr):
    """Return list of (type, value, start). Last token is eof."""
    tokens = []
    i, n = 0, len(expr)
    while i < n:
        c = expr[i]
        if c in _WS:
            i += 1
        elif c in _IDENT_START:
            j = i + 1
            while j < n and expr[j] in _IDENT:
                j += 1
            tokens.append(("unquoted_identifier", expr[i:j], i))
            i = j
        elif c in _SIMPLE:
            tokens.append((_SIMPLE[c], c, i))
            i += 1
        elif c == "[":
            nxt = expr[i + 1] if i + 1 < n else ""
            if nxt == "?":
                tokens.append(("filter", "[?", i)); i += 2
            elif nxt == "]":
                tokens.append(("flatten", "[]", i)); i += 2
            else:
                tokens.append(("lbracket", "[", i)); i += 1
        elif c == "|":
            if expr[i + 1:i + 2] == "|":
                tokens.append(("or", "||", i)); i += 2
            else:
                tokens.append(("pipe", "|", i)); i += 1
        elif c == "&":
            if expr[i + 1:i + 2] == "&":
                tokens.append(("and", "&&", i)); i += 2
            else:
                tokens.append(("expref", "&", i)); i += 1
        elif c == "!":
            if expr[i + 1:i + 2] == "=":
                tokens.append(("ne", "!=", i)); i += 2
            else:
                tokens.append(("not", "!", i)); i += 1
        elif c == "<":
            if expr[i + 1:i + 2] == "=":
                tokens.append(("lte", "<=", i)); i += 2
            else:
                tokens.append(("lt", "<", i)); i += 1
        elif c == ">":
            if expr[i + 1:i + 2] == "=":
                tokens.append(("gte", ">=", i)); i += 2
            else:
                tokens.append(("gt", ">", i)); i += 1
        elif c == "=":
            if expr[i + 1:i + 2] == "=":
                tokens.append(("eq", "==", i)); i += 2
            else:
                raise LexerError("Unknown token '='", i)
        elif c == '"':
            j = i + 1
            while j < n and expr[j] != '"':
                j += 2 if expr[j] == "\\" else 1
            if j >= n:
                raise LexerError("Unterminated quoted identifier", i)
            try:
                val = json.loads(expr[i:j + 1])
            except ValueError:
                raise LexerError("Invalid quoted identifier", i)
            if not isinstance(val, str):
                raise LexerError("Invalid quoted identifier", i)
            tokens.append(("quoted_identifier", val, i))
            i = j + 1
        elif c == "'":
            j = i + 1
            while j < n and expr[j] != "'":
                j += 2 if expr[j] == "\\" and j + 1 < n and expr[j + 1] == "'" else 1
            if j >= n:
                raise LexerError("Unterminated raw string", i)
            val = _RAW.sub(_raw_sub, expr[i + 1:j])
            try:
                val = val.encode("utf-16", "surrogatepass").decode("utf-16")
            except UnicodeError:
                pass
            tokens.append(("literal", val, i))
            i = j + 1
        elif c == "`":
            j = i + 1
            while j < n and expr[j] != "`":
                j += 2 if expr[j] == "\\" and j + 1 < n and expr[j + 1] == "`" else 1
            if j >= n:
                raise LexerError("Unterminated JSON literal", i)
            text = expr[i + 1:j].replace("\\`", "`")
            try:
                val = json.loads(text)
            except ValueError:
                try:
                    val = json.loads('"%s"' % text.lstrip())
                except ValueError:
                    raise LexerError("Bad JSON literal", i)
            tokens.append(("literal", val, i))
            i = j + 1
        elif c == "-" or c in _DIGITS:
            j = i + 1 if c == "-" else i
            k = j
            while k < n and expr[k] in _DIGITS:
                k += 1
            if k == j:
                raise LexerError("Unknown token '-'", i)
            tokens.append(("number", int(expr[i:k]), i))
            i = k
        else:
            raise LexerError("Unknown token %r" % c, i)
    tokens.append(("eof", "", n))
    return tokens
