import collections.abc
import json
import re
from decimal import Decimal
import math

from ._values import deep_eq, is_array, is_number
from .exceptions import InvalidTypeError


def signature(*arguments):
    def decorator(func):
        func.signature = list(arguments)
        return func
    return decorator


def _s(*types, **kw):
    d = {"types": list(types)}
    d.update(kw)
    return d


_INT = re.compile(r"^[+-]?[0-9]+$")
_FLT = re.compile(r"^[+-]?([0-9]+\.?[0-9]*|\.[0-9]+)([eE][+-]?[0-9]+)?$")


def _json_default(o):
    if isinstance(o, collections.abc.Mapping):
        return dict(o)
    if isinstance(o, Decimal):
        return float(o)
    raise InvalidTypeError("value is not a JSON type")


def _type_name(v):
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "boolean"
    if isinstance(v, str):
        return "string"
    if is_number(v):
        return "number"
    if is_array(v):
        return "array"
    if isinstance(v, collections.abc.Mapping):
        return "object"
    raise InvalidTypeError("value is not a JSON type")


class Functions(object):
    @signature(_s("number"))
    def _func_abs(self, v):
        return abs(v)

    @signature(_s("array-number"))
    def _func_avg(self, v):
        return sum(v) / len(v) if v else None

    @signature(_s("number"))
    def _func_ceil(self, v):
        return math.ceil(v)

    @signature(_s("number"))
    def _func_floor(self, v):
        return math.floor(v)

    @signature(_s("array", "string"), _s("any"))
    def _func_contains(self, subject, search):
        if isinstance(subject, str):
            return isinstance(search, str) and search in subject
        return any(deep_eq(x, search) for x in subject)

    @signature(_s("string"), _s("string"))
    def _func_ends_with(self, s, suffix):
        return s.endswith(suffix)

    @signature(_s("string"), _s("string"))
    def _func_starts_with(self, s, prefix):
        return s.startswith(prefix)

    @signature(_s("string", "array", "object"))
    def _func_length(self, v):
        return len(v)

    @signature(_s("array", "string"))
    def _func_reverse(self, v):
        if isinstance(v, str):
            return v[::-1]
        return list(reversed(v))

    @signature(_s("string"), _s("array-string"))
    def _func_join(self, sep, arr):
        return sep.join(arr)

    @signature(_s("object"))
    def _func_keys(self, v):
        return list(v.keys())

    @signature(_s("object"))
    def _func_values(self, v):
        return list(v.values())

    @signature(_s("any"))
    def _func_type(self, v):
        return _type_name(v)

    @signature(_s("any"))
    def _func_to_array(self, v):
        return list(v) if isinstance(v, (list, tuple)) else [v]

    @signature(_s("any"))
    def _func_to_string(self, v):
        if isinstance(v, str):
            return v
        try:
            return json.dumps(v, separators=(",", ":"), ensure_ascii=True,
                              default=_json_default)
        except (TypeError, ValueError):
            raise InvalidTypeError("value is not a JSON type")

    @signature(_s("any"))
    def _func_to_number(self, v):
        if is_number(v):
            return v
        if isinstance(v, str):
            if _INT.match(v):
                return int(v)
            if _FLT.match(v):
                return float(v)
        return None

    @signature(_s("array-number", "array-string"))
    def _func_max(self, v):
        return max(v) if v else None

    @signature(_s("array-number", "array-string"))
    def _func_min(self, v):
        return min(v) if v else None

    @signature(_s("array-number", "array-string"))
    def _func_sort(self, v):
        return sorted(v)

    @signature(_s("array-number"))
    def _func_sum(self, v):
        return sum(v)

    @signature(_s("object"), _s("object", variadic=True))
    def _func_merge(self, *objs):
        out = {}
        for o in objs:
            for k in o.keys():
                out[k] = o[k]
        return out

    @signature(_s("any"), _s("any", variadic=True))
    def _func_not_null(self, *args):
        for a in args:
            if a is not None:
                return a
        return None

    @signature(_s("expref"), _s("array"))
    def _func_map(self, ref, arr):
        return [ref.eval(x) for x in arr]

    @staticmethod
    def _keys(ref, arr):
        keys = [ref.eval(x) for x in arr]
        if keys:
            if all(is_number(k) for k in keys):
                pass
            elif all(isinstance(k, str) for k in keys):
                pass
            else:
                raise InvalidTypeError("sort key must be all numbers or all strings")
        return keys

    @signature(_s("array"), _s("expref"))
    def _func_sort_by(self, arr, ref):
        keys = self._keys(ref, arr)
        order = sorted(range(len(arr)), key=lambda i: keys[i])
        return [arr[i] for i in order]

    @signature(_s("array"), _s("expref"))
    def _func_max_by(self, arr, ref):
        keys = self._keys(ref, arr)
        best = None
        for i in range(len(arr)):
            if best is None or keys[i] > keys[best]:
                best = i
        return None if best is None else arr[best]

    @signature(_s("array"), _s("expref"))
    def _func_min_by(self, arr, ref):
        keys = self._keys(ref, arr)
        best = None
        for i in range(len(arr)):
            if best is None or keys[i] < keys[best]:
                best = i
        return None if best is None else arr[best]
