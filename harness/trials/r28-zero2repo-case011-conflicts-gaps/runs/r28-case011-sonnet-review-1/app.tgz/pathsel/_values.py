import collections.abc
from decimal import Decimal


class ExprRef(object):
    def __init__(self, node, interpreter):
        self.node = node
        self.interpreter = interpreter

    def eval(self, value):
        return self.interpreter.visit(self.node, value)


def is_number(v):
    return isinstance(v, (int, float, Decimal)) and not isinstance(v, bool)


def is_array(v):
    return isinstance(v, (list, tuple))


def is_object(v, dict_cls=None):
    if isinstance(v, collections.abc.Mapping):
        return True
    return dict_cls is not None and isinstance(v, dict_cls)


def is_false(v, dict_cls=None):
    if v is None or v is False:
        return True
    if isinstance(v, (str, list, tuple)) or is_object(v, dict_cls):
        try:
            return len(v) == 0
        except TypeError:
            return False
    return False


def deep_eq(a, b, dict_cls=None):
    ab, bb = isinstance(a, bool), isinstance(b, bool)
    if ab or bb:
        return ab and bb and a == b
    if is_number(a) or is_number(b):
        return is_number(a) and is_number(b) and a == b
    if isinstance(a, str) or isinstance(b, str):
        return isinstance(a, str) and isinstance(b, str) and a == b
    if is_array(a) or is_array(b):
        if not (is_array(a) and is_array(b)) or len(a) != len(b):
            return False
        return all(deep_eq(x, y, dict_cls) for x, y in zip(a, b))
    if is_object(a, dict_cls) or is_object(b, dict_cls):
        if not (is_object(a, dict_cls) and is_object(b, dict_cls)):
            return False
        if len(a) != len(b):
            return False
        for k in a.keys():
            if k not in b or not deep_eq(a[k], b[k], dict_cls):
                return False
        return True
    try:
        return bool(a == b)
    except Exception:
        return False
