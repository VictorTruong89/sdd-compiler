from ._values import (ExprRef, deep_eq, is_array, is_false, is_number,
                      is_object)
from .exceptions import (ArityError, InvalidTypeError, UnknownFunctionError)
from .functions import Functions

_DEFAULT = Functions()


def _check_type(v, t, dict_cls):
    if t == "any":
        return True
    if t == "number":
        return is_number(v)
    if t == "string":
        return isinstance(v, str)
    if t == "array":
        return is_array(v)
    if t == "object":
        return is_object(v, dict_cls)
    if t == "null":
        return v is None
    if t == "boolean":
        return isinstance(v, bool)
    if t == "expref":
        return isinstance(v, ExprRef)
    if t == "array-number":
        return is_array(v) and all(is_number(x) for x in v)
    if t == "array-string":
        return is_array(v) and all(isinstance(x, str) for x in v)
    return False


def _compare(op, a, b):
    if op == "eq":
        return deep_eq(a, b)
    if op == "ne":
        return not deep_eq(a, b)
    if (is_number(a) and is_number(b)) or (isinstance(a, str) and isinstance(b, str)):
        if op == "lt":
            return a < b
        if op == "lte":
            return a <= b
        if op == "gt":
            return a > b
        return a >= b
    return None


class Interpreter(object):
    def __init__(self, options=None):
        self.dict_cls = getattr(options, "dict_cls", None)
        self.provider = getattr(options, "custom_functions", None)

    def isobj(self, v):
        return is_object(v, self.dict_cls)

    def visit(self, node, v):
        k = node[0]
        if k == "field":
            if self.isobj(v):
                try:
                    return v.get(node[1])
                except AttributeError:
                    try:
                        return v[node[1]]
                    except KeyError:
                        return None
            return None
        if k == "identity":
            return v
        if k == "literal":
            return node[1]
        if k == "subexpr" or k == "pipe":
            return self.visit(node[2], self.visit(node[1], v))
        if k == "index":
            base = v
            if is_array(base):
                try:
                    return base[node[1]]
                except IndexError:
                    return None
            return None
        if k == "slice":
            if not is_array(v):
                return None
            return list(v)[slice(node[1], node[2], node[3])]
        if k == "projection":
            base = self.visit(node[1], v)
            if not is_array(base):
                return None
            return self._collect(node[2], base)
        if k == "value_projection":
            base = self.visit(node[1], v)
            if not self.isobj(base):
                return None
            return self._collect(node[2], list(base.values()))
        if k == "filter_projection":
            base = self.visit(node[1], v)
            if not is_array(base):
                return None
            kept = [x for x in base if not is_false(self.visit(node[3], x), self.dict_cls)]
            return self._collect(node[2], kept)
        if k == "flatten":
            base = self.visit(node[1], v)
            if not is_array(base):
                return None
            out = []
            for x in base:
                if is_array(x):
                    out.extend(x)
                else:
                    out.append(x)
            return out
        if k == "or":
            l = self.visit(node[1], v)
            return self.visit(node[2], v) if is_false(l, self.dict_cls) else l
        if k == "and":
            l = self.visit(node[1], v)
            return l if is_false(l, self.dict_cls) else self.visit(node[2], v)
        if k == "not":
            return is_false(self.visit(node[1], v), self.dict_cls)
        if k == "comparator":
            return _compare(node[1], self.visit(node[2], v), self.visit(node[3], v))
        if k == "multi_list":
            if v is None:
                return None
            return [self.visit(e, v) for e in node[1]]
        if k == "multi_hash":
            if v is None:
                return None
            out = self.dict_cls() if self.dict_cls is not None else {}
            for key, e in node[1]:
                out[key] = self.visit(e, v)
            return out
        if k == "expref":
            return ExprRef(node[1], self)
        if k == "function":
            return self.call(node[1], node[2], v)
        raise AssertionError(k)

    def _collect(self, right, items):
        out = []
        for x in items:
            r = self.visit(right, x)
            if r is not None:
                out.append(r)
        return out

    def call(self, name, arg_nodes, v):
        func = None
        for prov in (self.provider, _DEFAULT):
            if prov is None:
                continue
            f = getattr(prov, "_func_" + name, None)
            if f is not None and hasattr(f, "signature"):
                func = f
                break
        if func is None:
            raise UnknownFunctionError("Unknown function: %s" % name)
        sig = list(func.signature)
        variadic = bool(sig) and bool(sig[-1].get("variadic"))
        n = len(arg_nodes)
        if variadic:
            if n < len(sig):
                raise ArityError("%s() takes at least %d arguments" % (name, len(sig)))
        elif n != len(sig):
            raise ArityError("%s() takes %d arguments, got %d" % (name, len(sig), n))
        args = [self.visit(a, v) for a in arg_nodes]
        for i, a in enumerate(args):
            spec = sig[min(i, len(sig) - 1)]
            if not any(_check_type(a, t, self.dict_cls) for t in spec.get("types", [])):
                raise InvalidTypeError("Invalid argument %d type for %s()" % (i + 1, name))
        return func(*args)
