"""Built-in language functions, the ``signature`` decorator and the ``Functions`` provider.

``Functions`` implements the built-in set. Callers extend it by subclassing and
decorating ``_func_<name>`` methods with ``signature``. Built-in names always
resolve to the built-in implementation, so a provider can add names but cannot
change the meaning of the built-in set.
"""

import json
import math
import re
from collections.abc import Mapping
from decimal import Decimal

from .errors import InvalidTypeError
from .values import ExpressionReference, is_array, is_number, json_equal

__all__ = ["Functions", "signature"]


_TYPE_CHECKS = {
    "number": is_number,
    "string": lambda v: isinstance(v, str),
    "boolean": lambda v: isinstance(v, bool),
    "array": is_array,
    "object": lambda v: isinstance(v, Mapping),
    "null": lambda v: v is None,
    "any": lambda v: True,
    "ref": lambda v: isinstance(v, ExpressionReference),
}


def matches_types(types, value):
    """True when ``value`` satisfies one of the type names. An empty tuple accepts anything."""
    if not types:
        return True
    for name in types:
        if _TYPE_CHECKS[name](value):
            return True
    return False


def signature(*arguments):
    """Declare the argument types of a custom function.

    Each positional argument is a mapping ``{"types": [...]}`` with type names
    ``number``, ``string``, ``array``, ``object`` or ``null`` (``boolean`` and
    ``any`` are also accepted). The decorator returns the function unchanged apart
    from a ``__pathsel_signature__`` attribute.
    """
    specs = []
    for argument in arguments:
        if not isinstance(argument, Mapping) or "types" not in argument:
            raise TypeError("each signature argument must be a mapping with a 'types' entry")
        types = argument["types"]
        if isinstance(types, str):
            types = [types]
        types = tuple(types)
        for name in types:
            if name not in _TYPE_CHECKS or name == "ref":
                raise ValueError("unknown type name %r in signature" % (name,))
        specs.append(types)
    specs = tuple(specs)

    def decorate(function):
        function.__pathsel_signature__ = specs
        return function

    return decorate


# name -> (minimum args, maximum args or None for variadic, per-position type tuples).
# For variadic functions the last type tuple applies to every further argument.
BUILTIN_SPECS = {
    "abs": (1, 1, [("number",)]),
    "avg": (1, 1, [("array",)]),
    "ceil": (1, 1, [("number",)]),
    "contains": (2, 2, [("array", "string"), ("any",)]),
    "ends_with": (2, 2, [("string",), ("string",)]),
    "floor": (1, 1, [("number",)]),
    "join": (2, 2, [("string",), ("array",)]),
    "keys": (1, 1, [("object",)]),
    "length": (1, 1, [("string", "array", "object")]),
    "map": (2, 2, [("ref",), ("array",)]),
    "max": (1, 1, [("array",)]),
    "max_by": (2, 2, [("array",), ("ref",)]),
    "merge": (1, None, [("object",)]),
    "min": (1, 1, [("array",)]),
    "min_by": (2, 2, [("array",), ("ref",)]),
    "not_null": (1, None, [("any",)]),
    "reverse": (1, 1, [("array", "string")]),
    "sort": (1, 1, [("array",)]),
    "sort_by": (2, 2, [("array",), ("ref",)]),
    "starts_with": (2, 2, [("string",), ("string",)]),
    "sum": (1, 1, [("array",)]),
    "to_array": (1, 1, [("any",)]),
    "to_number": (1, 1, [("any",)]),
    "to_string": (1, 1, [("any",)]),
    "type": (1, 1, [("any",)]),
    "values": (1, 1, [("object",)]),
}

_INT_NUMERAL = re.compile(r"-?[0-9]+\Z")
_FLOAT_NUMERAL = re.compile(r"-?(?:[0-9]+\.[0-9]*|\.[0-9]+|[0-9]+)(?:[eE][+-]?[0-9]+)?\Z")


def _is_string(value):
    return isinstance(value, str)


def _require_all(items, check, what):
    for item in items:
        if not check(item):
            raise InvalidTypeError("%s requires elements of the required type" % what)


def _require_numbers_or_strings(items, what):
    """Every element a number, or every element a string (an empty list passes)."""
    if all(is_number(item) for item in items) or all(_is_string(item) for item in items):
        return
    raise InvalidTypeError("%s requires all numbers or all strings" % what)


class Functions:
    """Provider of the built-in functions. Subclass it to add custom functions."""

    def _func_abs(self, value):
        return abs(value)

    def _func_avg(self, items):
        _require_all(items, is_number, "avg")
        if not items:
            return None
        return sum(items) / len(items)

    def _func_ceil(self, value):
        return math.ceil(value)

    def _func_floor(self, value):
        return math.floor(value)

    def _func_contains(self, haystack, needle):
        if isinstance(haystack, str):
            if not isinstance(needle, str):
                raise InvalidTypeError("contains on a string requires a string")
            return needle in haystack
        return any(json_equal(item, needle) for item in haystack)

    def _func_ends_with(self, text, suffix):
        return text.endswith(suffix)

    def _func_starts_with(self, text, prefix):
        return text.startswith(prefix)

    def _func_length(self, value):
        return len(value)

    def _func_reverse(self, value):
        if isinstance(value, str):
            return value[::-1]
        return list(reversed(value))

    def _func_join(self, separator, items):
        _require_all(items, _is_string, "join")
        if not items:
            return None
        return separator.join(items)

    def _func_keys(self, mapping):
        return list(mapping.keys())

    def _func_values(self, mapping):
        return list(mapping.values())

    def _func_type(self, value):
        if value is None:
            return "null"
        if isinstance(value, bool):
            return "boolean"
        if is_number(value) or isinstance(value, Decimal):
            return "number"
        if isinstance(value, str):
            return "string"
        if is_array(value):
            return "array"
        if isinstance(value, Mapping):
            return "object"
        return "null"

    def _func_to_array(self, value):
        if is_array(value):
            return list(value)
        return [value]

    def _func_to_string(self, value):
        if isinstance(value, str):
            return value
        if isinstance(value, Decimal):
            return str(value)
        return json.dumps(value, separators=(",", ":"), default=str)

    def _func_to_number(self, value):
        if is_number(value):
            return value
        if isinstance(value, str):
            if _INT_NUMERAL.match(value):
                return int(value)
            if _FLOAT_NUMERAL.match(value):
                return float(value)
        return None

    def _func_max(self, items):
        _require_numbers_or_strings(items, "max")
        if not items:
            return None
        return max(items)

    def _func_min(self, items):
        _require_numbers_or_strings(items, "min")
        if not items:
            return None
        return min(items)

    def _func_sort(self, items):
        _require_numbers_or_strings(items, "sort")
        return sorted(items)

    def _func_sum(self, items):
        _require_all(items, is_number, "sum")
        return sum(items)

    def _func_merge(self, *mappings):
        result = {}
        for mapping in mappings:
            result.update(mapping)
        return result

    def _func_not_null(self, *values):
        for value in values:
            if value is not None:
                return value
        return None

    def _func_map(self, reference, items):
        return [reference.apply(item) for item in items]

    def _keyed(self, items, reference, what):
        keys = [reference.apply(item) for item in items]
        _require_numbers_or_strings(keys, what)
        return keys

    def _func_sort_by(self, items, reference):
        keys = self._keyed(items, reference, "sort_by")
        order = sorted(range(len(items)), key=lambda index: keys[index])
        return [items[index] for index in order]

    def _func_max_by(self, items, reference):
        if not items:
            return None
        keys = self._keyed(items, reference, "max_by")
        best = 0
        for index in range(1, len(items)):
            if keys[index] > keys[best]:
                best = index
        return items[best]

    def _func_min_by(self, items, reference):
        if not items:
            return None
        keys = self._keyed(items, reference, "min_by")
        best = 0
        for index in range(1, len(items)):
            if keys[index] < keys[best]:
                best = index
        return items[best]


BUILTIN_PROVIDER = Functions()
