"""Split expression text into tokens.

The whole text is tokenized before parsing. Any character that begins no token,
and any unreadable quoted identifier, raw string or JSON literal, is a token-level
syntax failure reported at the offset where the token begins.
"""

import json

from .errors import TokenSyntaxError

_WHITESPACE = " \t\n\r"
_HEX = frozenset("0123456789abcdefABCDEF")
_DIGITS = frozenset("0123456789")
_IDENT_START = frozenset("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_")
_IDENT_BODY = _IDENT_START | _DIGITS

_SINGLE = {
    ".": "dot",
    "*": "star",
    "]": "rbracket",
    "{": "lbrace",
    "}": "rbrace",
    "(": "lparen",
    ")": "rparen",
    ",": "comma",
    ":": "colon",
    "@": "at",
    "?": "question",
}


class Token:
    __slots__ = ("type", "value", "pos")

    def __init__(self, type_, value, pos):
        self.type = type_
        self.value = value
        self.pos = pos

    def __repr__(self):
        return "Token(%r, %r, %d)" % (self.type, self.value, self.pos)


def _parse_literal(content, pos):
    """JSON text first; otherwise the content as the body of a JSON string."""
    try:
        return json.loads(content)
    except ValueError:
        pass
    try:
        return json.loads('"' + content.lstrip(_WHITESPACE) + '"')
    except ValueError:
        raise TokenSyntaxError("literal is neither JSON nor JSON string content", pos)


def tokenize(text):
    """Return the token list for ``text``, ending with an ``eof`` token at ``len(text)``."""
    tokens = []
    n = len(text)
    i = 0
    while i < n:
        c = text[i]
        if c in _WHITESPACE:
            i += 1
            continue
        start = i
        nxt = text[i + 1] if i + 1 < n else ""

        if c == "[":
            if nxt == "]":
                tokens.append(Token("flatten", None, start))
                i += 2
            else:
                tokens.append(Token("lbracket", None, start))
                i += 1
        elif c in _SINGLE:
            tokens.append(Token(_SINGLE[c], None, start))
            i += 1
        elif c == "|":
            if nxt == "|":
                tokens.append(Token("or", None, start))
                i += 2
            else:
                tokens.append(Token("pipe", None, start))
                i += 1
        elif c == "&":
            if nxt == "&":
                tokens.append(Token("and", None, start))
                i += 2
            else:
                tokens.append(Token("amp", None, start))
                i += 1
        elif c == "=":
            if nxt != "=":
                raise TokenSyntaxError("lone '=' is not an operator; use '=='", start)
            tokens.append(Token("eq", None, start))
            i += 2
        elif c == "!":
            if nxt == "=":
                tokens.append(Token("ne", None, start))
                i += 2
            else:
                tokens.append(Token("not", None, start))
                i += 1
        elif c == "<":
            if nxt == "=":
                tokens.append(Token("lte", None, start))
                i += 2
            else:
                tokens.append(Token("lt", None, start))
                i += 1
        elif c == ">":
            if nxt == "=":
                tokens.append(Token("gte", None, start))
                i += 2
            else:
                tokens.append(Token("gt", None, start))
                i += 1
        elif c == "-" or c in _DIGITS:
            j = i + 1 if c == "-" else i
            if c == "-" and not (nxt and nxt in _DIGITS):
                raise TokenSyntaxError("lone '-' begins no token", start)
            while j < n and text[j] in _DIGITS:
                j += 1
            tokens.append(Token("number", int(text[i:j]), start))
            i = j
        elif c in _IDENT_START:
            j = i + 1
            while j < n and text[j] in _IDENT_BODY:
                j += 1
            tokens.append(Token("unquoted", text[i:j], start))
            i = j
        elif c == '"':
            j = i + 1
            while j < n and text[j] != '"':
                j += 2 if text[j] == "\\" else 1
            if j >= n:
                raise TokenSyntaxError("unterminated quoted identifier", start)
            try:
                value = json.loads(text[i:j + 1])
            except ValueError:
                raise TokenSyntaxError("quoted identifier is not a legal JSON string", start)
            tokens.append(Token("quoted", value, start))
            i = j + 1
        elif c == "'":
            j = i + 1
            buf = []
            while True:
                if j >= n:
                    raise TokenSyntaxError("unterminated raw string literal", start)
                ch = text[j]
                if ch == "'":
                    break
                if ch == "\\" and j + 1 < n:
                    after = text[j + 1]
                    if after == "'":
                        buf.append("'")
                        j += 2
                        continue
                    if after == "u" and j + 6 <= n and all(h in _HEX for h in text[j + 2:j + 6]):
                        buf.append(chr(int(text[j + 2:j + 6], 16)))
                        j += 6
                        continue
                buf.append(ch)
                j += 1
            tokens.append(Token("raw", "".join(buf), start))
            i = j + 1
        elif c == "`":
            j = i + 1
            buf = []
            while True:
                if j >= n:
                    raise TokenSyntaxError("unterminated JSON literal", start)
                ch = text[j]
                if ch == "`":
                    break
                if ch == "\\" and j + 1 < n and text[j + 1] == "`":
                    buf.append("`")
                    j += 2
                    continue
                buf.append(ch)
                j += 1
            tokens.append(Token("literal", _parse_literal("".join(buf), start), start))
            i = j + 1
        else:
            raise TokenSyntaxError("character %r begins no token" % (c,), start)

    tokens.append(Token("eof", None, n))
    return tokens
