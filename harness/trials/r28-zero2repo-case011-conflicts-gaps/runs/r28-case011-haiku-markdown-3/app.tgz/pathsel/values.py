"""Value predicates, equality, ordering and the expression-reference value."""

from collections.abc import Mapping
from decimal import Decimal


def is_number(value):
    """A JSON number: an int or float, never a boolean."""
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def is_cmp_number(value):
    """A number for comparison purposes: JSON numbers plus host decimals."""
    return isinstance(value, (int, float, Decimal)) and not isinstance(value, bool)


def is_array(value):
    """A JSON array: a list or tuple (strings are not arrays)."""
    return isinstance(value, (list, tuple))


def is_false(value):
    """The language's false-value set: false, null, "", [], {}."""
    if value is None or value is False:
        return True
    if isinstance(value, (str, list, tuple, Mapping)):
        return len(value) == 0
    return False


def json_equal(a, b):
    """JSON value equality: deep for arrays and objects, booleans never equal numbers."""
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if a is None or b is None:
        return a is None and b is None
    if is_cmp_number(a) and is_cmp_number(b):
        return a == b
    if isinstance(a, str) and isinstance(b, str):
        return a == b
    if is_array(a) and is_array(b):
        return len(a) == len(b) and all(json_equal(x, y) for x, y in zip(a, b))
    if isinstance(a, Mapping) and isinstance(b, Mapping):
        if len(a) != len(b):
            return False
        for key in a:
            if key not in b or not json_equal(a[key], b[key]):
                return False
        return True
    if is_array(a) or is_array(b) or isinstance(a, Mapping) or isinstance(b, Mapping):
        return False
    return a == b


def ordering(a, b):
    """Return -1, 0 or 1 for two numbers or two strings; None when not comparable."""
    if (is_cmp_number(a) and is_cmp_number(b)) or (isinstance(a, str) and isinstance(b, str)):
        return (a > b) - (a < b)
    return None


class ExpressionReference:
    """A deferred subexpression: the value of ``&expr``.

    Built-in functions such as ``map`` and ``sort_by`` apply it to elements.
    ``apply`` evaluates the referenced node with the evaluation context that
    created the reference, so options (mapping type, custom functions) carry over.
    """

    __slots__ = ("_node", "_context")

    def __init__(self, node, context):
        self._node = node
        self._context = context

    def apply(self, value):
        return self._node.evaluate(value, self._context)

    def __repr__(self):
        return "<pathsel expression reference>"
