"""Refusal kinds raised by pathsel.

Every refusal is a ``ValueError``. The kind is carried by the exception type:

* ``EmptyExpressionError``       - the expression text has zero length.
* ``IncompleteExpressionError``  - the text ends where more input is required.
* ``ExpressionSyntaxError``      - grammar-level syntax failure.
* ``TokenSyntaxError``           - token-level syntax failure (a subclass of
                                   ``ExpressionSyntaxError``, never the same type).
* ``ZeroSliceStepError``         - a slice written with step 0.
* ``UnknownFunctionError``       - a function name that no provider declares.
* ``InvalidArityError``          - a function called with the wrong argument count.
* ``InvalidTypeError``           - a function argument outside its accepted types.

Syntax and incomplete-expression refusals carry ``lex_position``: the zero-based
character offset at which the offending token begins (the end of the text for
end-of-text failures).
"""


class PathSelError(ValueError):
    """Base class of every pathsel refusal."""


class EmptyExpressionError(PathSelError):
    """The expression text is zero-length."""


class IncompleteExpressionError(PathSelError):
    """The text ends where an operand or a closing token is still required."""

    def __init__(self, message, lex_position):
        super().__init__(message)
        self.lex_position = lex_position


class ExpressionSyntaxError(PathSelError):
    """Grammar-level syntax failure."""

    def __init__(self, message, lex_position):
        super().__init__(message)
        self.lex_position = lex_position


class TokenSyntaxError(ExpressionSyntaxError):
    """Token-level syntax failure: a more specific form of the syntax kind."""


class ZeroSliceStepError(PathSelError):
    """A slice whose step is zero."""


class UnknownFunctionError(PathSelError):
    """A function name that is neither built-in nor declared by the provider."""


class InvalidArityError(PathSelError):
    """A function called with a wrong number of arguments."""


class InvalidTypeError(PathSelError):
    """A function argument outside its accepted types."""
