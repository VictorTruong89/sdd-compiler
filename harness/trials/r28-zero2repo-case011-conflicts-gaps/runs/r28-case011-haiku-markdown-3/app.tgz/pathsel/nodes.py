"""Expression tree nodes and their evaluation.

Every node has ``evaluate(value, context)``. ``value`` is the current value and
``context`` is a :class:`Context` built from the caller's evaluation options.
"""

import copy
from collections.abc import Mapping

from .errors import InvalidArityError, InvalidTypeError, UnknownFunctionError
from .functions import BUILTIN_PROVIDER, BUILTIN_SPECS, matches_types
from .values import ExpressionReference, is_array, is_false, json_equal, ordering


class Context:
    """Per-search evaluation options: the constructed-mapping type and the custom provider."""

    __slots__ = ("dict_cls", "provider")

    def __init__(self, dict_cls=None, provider=None):
        self.dict_cls = dict_cls
        self.provider = provider

    @classmethod
    def from_options(cls, options):
        if options is None:
            return cls()
        return cls(getattr(options, "dict_cls", None), getattr(options, "custom_functions", None))

    def new_mapping(self):
        if self.dict_cls is None:
            return {}
        return self.dict_cls()


class Node:
    __slots__ = ()

    def evaluate(self, value, context):  # pragma: no cover - abstract
        raise NotImplementedError


class Current(Node):
    __slots__ = ()

    def evaluate(self, value, context):
        return value


class Literal(Node):
    __slots__ = ("value",)

    def __init__(self, value):
        self.value = value

    def evaluate(self, value, context):
        if isinstance(self.value, (list, dict)):
            return copy.deepcopy(self.value)
        return self.value


class Field(Node):
    __slots__ = ("name",)

    def __init__(self, name):
        self.name = name

    def evaluate(self, value, context):
        if isinstance(value, Mapping):
            return value.get(self.name)
        return None


class Index(Node):
    __slots__ = ("source", "index")

    def __init__(self, source, index):
        self.source = source
        self.index = index

    def evaluate(self, value, context):
        base = self.source.evaluate(value, context)
        if not is_array(base):
            return None
        try:
            return base[self.index]
        except IndexError:
            return None


class Slice(Node):
    """Selects a new array; a projection's source. Step zero is refused at parse time."""

    __slots__ = ("source", "start", "stop", "step")

    def __init__(self, source, start, stop, step):
        self.source = source
        self.start = start
        self.stop = stop
        self.step = step

    def evaluate(self, value, context):
        base = self.source.evaluate(value, context)
        if not is_array(base):
            return None
        return list(base[slice(self.start, self.stop, self.step)])


class Flatten(Node):
    __slots__ = ("source",)

    def __init__(self, source):
        self.source = source

    def evaluate(self, value, context):
        base = self.source.evaluate(value, context)
        if not is_array(base):
            return None
        out = []
        for item in base:
            if is_array(item):
                out.extend(item)
            else:
                out.append(item)
        return out


class Filter(Node):
    __slots__ = ("source", "predicate")

    def __init__(self, source, predicate):
        self.source = source
        self.predicate = predicate

    def evaluate(self, value, context):
        base = self.source.evaluate(value, context)
        if not is_array(base):
            return None
        return [item for item in base if not is_false(self.predicate.evaluate(item, context))]


class ListProjection(Node):
    """Applies ``rhs`` to each element of an array and collects the non-null results."""

    __slots__ = ("source", "rhs")

    def __init__(self, source, rhs):
        self.source = source
        self.rhs = rhs

    def evaluate(self, value, context):
        base = self.source.evaluate(value, context)
        if not is_array(base):
            return None
        out = []
        for item in base:
            result = self.rhs.evaluate(item, context)
            if result is not None:
                out.append(result)
        return out


class ObjectProjection(Node):
    """Applies ``rhs`` to each value of an object and collects the non-null results."""

    __slots__ = ("source", "rhs")

    def __init__(self, source, rhs):
        self.source = source
        self.rhs = rhs

    def evaluate(self, value, context):
        base = self.source.evaluate(value, context)
        if not isinstance(base, Mapping):
            return None
        out = []
        for item in base.values():
            result = self.rhs.evaluate(item, context)
            if result is not None:
                out.append(result)
        return out


class Subexpression(Node):
    """Evaluates ``right`` with the result of ``left`` as the current value (also used for pipe)."""

    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, context):
        return self.right.evaluate(self.left.evaluate(value, context), context)


class Or(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, context):
        result = self.left.evaluate(value, context)
        if not is_false(result):
            return result
        return self.right.evaluate(value, context)


class And(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, context):
        result = self.left.evaluate(value, context)
        if is_false(result):
            return result
        return self.right.evaluate(value, context)


class Not(Node):
    __slots__ = ("operand",)

    def __init__(self, operand):
        self.operand = operand

    def evaluate(self, value, context):
        return is_false(self.operand.evaluate(value, context))


_ORDER_TESTS = {
    "lt": lambda c: c < 0,
    "lte": lambda c: c <= 0,
    "gt": lambda c: c > 0,
    "gte": lambda c: c >= 0,
}


class Comparison(Node):
    """``==``, ``!=`` and the ordering comparators. Non-comparable ordering yields null."""

    __slots__ = ("op", "left", "right")

    def __init__(self, op, left, right):
        self.op = op
        self.left = left
        self.right = right

    def evaluate(self, value, context):
        a = self.left.evaluate(value, context)
        b = self.right.evaluate(value, context)
        if self.op == "eq":
            return json_equal(a, b)
        if self.op == "ne":
            return not json_equal(a, b)
        order = ordering(a, b)
        if order is None:
            return None
        return _ORDER_TESTS[self.op](order)


class MultiList(Node):
    __slots__ = ("items",)

    def __init__(self, items):
        self.items = items

    def evaluate(self, value, context):
        if value is None:
            return None
        return [item.evaluate(value, context) for item in self.items]


class MultiHash(Node):
    __slots__ = ("pairs",)

    def __init__(self, pairs):
        self.pairs = pairs

    def evaluate(self, value, context):
        if value is None:
            return None
        result = context.new_mapping()
        for key, node in self.pairs:
            result[key] = node.evaluate(value, context)
        return result


class ExpressionRef(Node):
    """``&expr``: a deferred reference, not evaluated until a function applies it."""

    __slots__ = ("node",)

    def __init__(self, node):
        self.node = node

    def evaluate(self, value, context):
        return ExpressionReference(self.node, context)


class FunctionCall(Node):
    __slots__ = ("name", "args")

    def __init__(self, name, args):
        self.name = name
        self.args = args

    def evaluate(self, value, context):
        spec = BUILTIN_SPECS.get(self.name)
        if spec is not None:
            return self._call_builtin(spec, value, context)
        return self._call_custom(value, context)

    def _call_builtin(self, spec, value, context):
        low, high, type_specs = spec
        count = len(self.args)
        if count < low or (high is not None and count > high):
            raise InvalidArityError("%s takes a different number of arguments" % self.name)
        args = [arg.evaluate(value, context) for arg in self.args]
        for index, arg in enumerate(args):
            types = type_specs[min(index, len(type_specs) - 1)]
            if not matches_types(types, arg):
                raise InvalidTypeError("argument %d of %s has an invalid type" % (index + 1, self.name))
        return getattr(BUILTIN_PROVIDER, "_func_" + self.name)(*args)

    def _call_custom(self, value, context):
        function = None
        if context.provider is not None:
            function = getattr(context.provider, "_func_" + self.name, None)
        declared = getattr(function, "__pathsel_signature__", None)
        if declared is None:
            raise UnknownFunctionError("unknown function %s" % self.name)
        if len(self.args) != len(declared):
            raise InvalidArityError("%s takes %d arguments" % (self.name, len(declared)))
        args = [arg.evaluate(value, context) for arg in self.args]
        for index, (types, arg) in enumerate(zip(declared, args)):
            if not matches_types(types, arg):
                raise InvalidTypeError("argument %d of %s has an invalid type" % (index + 1, self.name))
        return function(*args)
