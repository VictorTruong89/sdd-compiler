"""Pratt parser for PathSel expressions.

Binding powers, loosest to tightest: pipe (1), ``||`` (2), ``&&`` (3), comparators (5),
flatten (9), list wildcard / slice / object wildcard / filter (20/21), dot (40),
``!`` (45), bracket steps (55).

A projection's right-hand side (see ``_projection_rhs``) takes the following steps
that rank tighter than the projection, as described in FP-04.
"""

from .errors import (
    ExpressionSyntaxError,
    IncompleteExpressionError,
    ZeroSliceStepError,
)
from .lexer import tokenize
from .nodes import (
    And,
    Comparison,
    Current,
    ExpressionRef,
    Field,
    Filter,
    Flatten,
    FunctionCall,
    Index,
    ListProjection,
    Literal,
    MultiHash,
    MultiList,
    Not,
    ObjectProjection,
    Or,
    Slice,
    Subexpression,
)

_BINDING = {
    "pipe": 1,
    "or": 2,
    "and": 3,
    "eq": 5,
    "ne": 5,
    "lt": 5,
    "lte": 5,
    "gt": 5,
    "gte": 5,
    "flatten": 9,
    "dot": 40,
    "lbracket": 55,
}

_COMPARATORS = frozenset(["eq", "ne", "lt", "lte", "gt", "gte"])
_LIST_RHS_BP = 20   # list wildcard, slice, object wildcard
_FILTER_RHS_BP = 21
_FLATTEN_RHS_BP = 9
_DOT_RHS_BP = 40
_NOT_BP = 45


class Parser:
    def __init__(self, tokens):
        self._tokens = tokens
        self._index = 0

    # -- token access -------------------------------------------------------

    def _cur(self):
        return self._tokens[self._index]

    def _peek(self, offset=1):
        return self._tokens[min(self._index + offset, len(self._tokens) - 1)]

    def _advance(self):
        tok = self._tokens[self._index]
        if tok.type != "eof":
            self._index += 1
        return tok

    def _unexpected(self, tok):
        if tok.type == "eof":
            raise IncompleteExpressionError("expression ends before it is complete", tok.pos)
        raise ExpressionSyntaxError("unexpected token %s" % tok.type, tok.pos)

    def _expect(self, kind):
        tok = self._cur()
        if tok.type != kind:
            self._unexpected(tok)
        return self._advance()

    # -- entry --------------------------------------------------------------

    def parse(self):
        node = self._expression(0)
        tok = self._cur()
        if tok.type != "eof":
            raise ExpressionSyntaxError("token %s left over after a complete expression" % tok.type, tok.pos)
        return node

    def _expression(self, rbp):
        node = self._nud()
        while rbp < _BINDING.get(self._cur().type, 0):
            node = self._led(node)
        return node

    # -- prefix positions ---------------------------------------------------

    def _nud(self):
        tok = self._cur()
        kind = tok.type
        if kind == "unquoted":
            self._advance()
            if self._cur().type == "lparen":
                return self._function_call(tok.value)
            return Field(tok.value)
        if kind == "quoted":
            self._advance()
            if self._cur().type == "lparen":
                raise ExpressionSyntaxError("a quoted identifier cannot name a function", self._cur().pos)
            return Field(tok.value)
        if kind == "at":
            self._advance()
            return Current()
        if kind == "star":
            self._advance()
            return ObjectProjection(Current(), self._projection_rhs(_LIST_RHS_BP))
        if kind == "flatten":
            self._advance()
            return ListProjection(Flatten(Current()), self._projection_rhs(_FLATTEN_RHS_BP))
        if kind == "lbracket":
            return self._bracket_step(Current(), multi_allowed=True)
        if kind == "lbrace":
            return self._multi_hash()
        if kind == "lparen":
            self._advance()
            node = self._expression(0)
            self._expect("rparen")
            return node
        if kind == "not":
            self._advance()
            return Not(self._expression(_NOT_BP))
        if kind == "amp":
            self._advance()
            return ExpressionRef(self._expression(0))
        if kind in ("raw", "literal"):
            self._advance()
            return Literal(tok.value)
        self._unexpected(tok)

    # -- infix / postfix positions -----------------------------------------

    def _led(self, left):
        tok = self._cur()
        kind = tok.type
        if kind == "pipe":
            self._advance()
            return Subexpression(left, self._expression(1))
        if kind == "or":
            self._advance()
            return Or(left, self._expression(2))
        if kind == "and":
            self._advance()
            return And(left, self._expression(3))
        if kind in _COMPARATORS:
            self._advance()
            return Comparison(kind, left, self._expression(5))
        if kind == "flatten":
            self._advance()
            return ListProjection(Flatten(left), self._projection_rhs(_FLATTEN_RHS_BP))
        if kind == "dot":
            return self._dot_step(left)
        if kind == "lbracket":
            return self._bracket_step(left, multi_allowed=False)
        self._unexpected(tok)

    def _dot_step(self, left):
        self._expect("dot")
        tok = self._cur()
        if tok.type == "eof":
            raise ExpressionSyntaxError("a dot must be followed by a step", tok.pos)
        if tok.type == "star":
            self._advance()
            return ObjectProjection(left, self._projection_rhs(_DOT_RHS_BP))
        if tok.type == "lbrace":
            return Subexpression(left, self._multi_hash())
        if tok.type == "lbracket":
            after = self._peek()
            starts_index_like = after.type in ("number", "colon", "question", "rbracket") or (
                after.type == "star" and self._peek(2).type == "rbracket"
            )
            if starts_index_like:
                raise ExpressionSyntaxError("a dot may only be followed by a multiselect list", tok.pos)
            return Subexpression(left, self._multi_list())
        if tok.type in ("unquoted", "quoted"):
            return Subexpression(left, self._expression(_DOT_RHS_BP))
        raise ExpressionSyntaxError("a dot must be followed by an identifier, wildcard or multiselect", tok.pos)

    def _bracket_step(self, left, multi_allowed):
        """A bracket after an operand (index, slice, list wildcard, filter) or at the start (multiselect allowed)."""
        nxt = self._peek()
        if nxt.type in ("number", "colon"):
            self._advance()
            return self._index_or_slice(left)
        if nxt.type == "star":
            self._advance()
            self._advance()
            self._expect("rbracket")
            return ListProjection(left, self._projection_rhs(_LIST_RHS_BP))
        if nxt.type == "question":
            self._advance()
            self._advance()
            return self._filter(left)
        if multi_allowed:
            return self._multi_list()
        self._unexpected(nxt)

    def _index_or_slice(self, left):
        """Parse after the opening bracket: ``n`` or ``start:stop:step`` with optional parts."""
        parts = [None]
        colons = 0
        if self._cur().type == "number":
            parts[0] = self._advance().value
        while self._cur().type == "colon":
            if colons == 2:
                raise ExpressionSyntaxError("a slice has more than three parts", self._cur().pos)
            colons += 1
            self._advance()
            parts.append(None)
            if self._cur().type == "number":
                parts[-1] = self._advance().value
        self._expect("rbracket")
        if colons == 0:
            return Index(left, parts[0])
        start, stop, step = parts + [None] * (3 - len(parts))
        if step == 0:
            raise ZeroSliceStepError("a slice step of zero is refused")
        return ListProjection(Slice(left, start, stop, step), self._projection_rhs(_LIST_RHS_BP))

    def _filter(self, left):
        """After ``[?``: a predicate, the closing bracket, and the projection's right-hand side."""
        predicate = self._expression(0)
        self._expect("rbracket")
        return ListProjection(Filter(left, predicate), self._projection_rhs(_FILTER_RHS_BP))

    def _function_call(self, name):
        self._expect("lparen")
        args = []
        if self._cur().type == "rparen":
            self._advance()
            return FunctionCall(name, args)
        args.append(self._expression(0))
        while self._cur().type == "comma":
            self._advance()
            args.append(self._expression(0))
        self._expect("rparen")
        return FunctionCall(name, args)

    def _multi_list(self):
        self._expect("lbracket")
        items = [self._expression(0)]
        while self._cur().type == "comma":
            self._advance()
            items.append(self._expression(0))
        self._expect("rbracket")
        return MultiList(items)

    def _multi_hash(self):
        self._expect("lbrace")
        pairs = []
        while True:
            tok = self._cur()
            if tok.type not in ("unquoted", "quoted"):
                self._unexpected(tok)
            self._advance()
            self._expect("colon")
            pairs.append((tok.value, self._expression(0)))
            if self._cur().type != "comma":
                break
            self._advance()
        self._expect("rbrace")
        return MultiHash(pairs)

    def _projection_rhs(self, bp):
        """The right-hand side of a projection, per FP-04's reach rules.

        Only a dot, or a bracket step, begins the right-hand side; anything else leaves it
        empty (identity). Later steps join only while they bind tighter than ``bp``.
        """
        kind = self._cur().type
        if kind == "dot":
            node = self._dot_step(Current())
        elif kind == "lbracket":
            node = self._expression(bp)
        else:
            return Current()
        while bp < _BINDING.get(self._cur().type, 0):
            node = self._led(node)
        return node


def parse(text):
    """Parse expression text into a tree. The caller has already rejected empty text."""
    return Parser(tokenize(text)).parse()
