"""pathsel: evaluate PathSel expressions against ordinary Python data.

Public entries:

* ``search(expression, data, options=None)`` - one-shot evaluation.
* ``compile(expression)`` - parse once; the returned object's ``search(data, options=None)``
  evaluates the parsed expression against any number of documents.

Refusals are ``ValueError`` subclasses; see ``pathsel.errors``.
"""

from .errors import (
    EmptyExpressionError,
    ExpressionSyntaxError,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    PathSelError,
    TokenSyntaxError,
    UnknownFunctionError,
    ZeroSliceStepError,
)
from .nodes import Context
from .parser import parse

__all__ = [
    "search",
    "compile",
    "ParsedExpression",
    "PathSelError",
    "EmptyExpressionError",
    "IncompleteExpressionError",
    "ExpressionSyntaxError",
    "TokenSyntaxError",
    "ZeroSliceStepError",
    "UnknownFunctionError",
    "InvalidArityError",
    "InvalidTypeError",
]


class ParsedExpression:
    """A compiled expression. Searching it never re-parses the text."""

    __slots__ = ("_root", "_text")

    def __init__(self, root, text):
        self._root = root
        self._text = text

    def search(self, value, options=None):
        return self._root.evaluate(value, Context.from_options(options))

    def __repr__(self):
        return "ParsedExpression(%r)" % (self._text,)


def compile(expression):
    """Parse ``expression`` (a str) and return a :class:`ParsedExpression`, or raise a refusal."""
    if not isinstance(expression, str):
        raise TypeError("expression must be a str")
    if expression == "":
        raise EmptyExpressionError("expression is empty")
    return ParsedExpression(parse(expression), expression)


def search(expression, data, options=None):
    """Evaluate ``expression`` against ``data``; missing paths yield ``None``."""
    return compile(expression).search(data, options)
