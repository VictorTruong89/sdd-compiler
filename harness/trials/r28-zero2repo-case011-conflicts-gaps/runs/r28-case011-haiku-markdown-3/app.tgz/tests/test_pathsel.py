"""Regression tests for pathsel, following the PRD feature points."""

from collections import OrderedDict
from types import SimpleNamespace

import pytest

import pathsel
from pathsel import compile, search
from pathsel.errors import (
    EmptyExpressionError,
    ExpressionSyntaxError,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    TokenSyntaxError,
    UnknownFunctionError,
    ZeroSliceStepError,
)
from pathsel.functions import Functions, signature

DOC = {
    "a": {"b": {"c": 42}},
    "people": [{"first": "J", "age": 3}, {"first": "K", "age": 1}],
    "xs": [3, 1, 2],
    "n": [[1, 2], [3], 4],
    "s": "héllo",
    "o": {"a": 1, "b": None, "c": {"x": 2}},
    "z": 0,
}


@pytest.mark.parametrize(
    "expr, expected",
    [
        ("a.b.c", 42),
        ("a.x.y", None),
        ("people[*].first", ["J", "K"]),
        ("people[0].first", "J"),
        ("people[-1].first", "K"),
        ("people[9]", None),
        ("xs[::-1]", [2, 1, 3]),
        ("xs[1:]", [1, 2]),
        ("xs[:-1]", [3, 1]),
        ("n[]", [1, 2, 3, 4]),
        ("people[?age > `1`].first", ["J"]),
        ("people[*].age | [0]", 3),
        ("!a.b", None),
        ("a.b.c == `42`", True),
        ("`0` || `9`", 0),
        ("z && `5`", 5),
        ("`true` == `1`", False),
        ("'raw\\'s'", "raw's"),
        ('"a".b', {"c": 42}),
        ('"a".b.c', 42),
        ("`{\"x\": 1}`.x", 1),
        ("{x: a.b.c, y: missing}", {"x": 42, "y": None}),
        ("[a.b.c, people[0].age]", [42, 3]),
        ("people[*].*", [["J", 3], ["K", 1]]),
        ("o.*", [1, {"x": 2}]),
        ("o[*]", None),
        ("s[0:2]", None),
        ("people[?age > `1`][0]", []),
        ("people[*].age[0]", []),
        ("people[].first", ["J", "K"]),
    ],
)
def test_selection_and_projection(expr, expected):
    assert search(expr, DOC) == expected


def test_one_shot_and_compiled_agree():
    parsed = compile("people[*].first")
    assert parsed.search(DOC) == search("people[*].first", DOC)
    assert parsed.search({"people": []}) == []
    assert parsed.search({}) is None


@pytest.mark.parametrize(
    "expr, expected",
    [
        ("abs(`-3`)", 3),
        ("avg(xs)", 2.0),
        ("avg(`[]`)", None),
        ("ceil(`1.2`)", 2),
        ("floor(`-1.5`)", -2),
        ("contains(xs, `2`)", True),
        ("contains(s, `\"l\"`)", True),
        ("ends_with(s, `\"lo\"`)", True),
        ("length(s)", 5),
        ("reverse(s)", "olléh"),
        ("join(`\"-\"`, `[\"a\",\"b\"]`)", "a-b"),
        ("join(`\"-\"`, `[]`)", None),
        ("keys(o)", ["a", "b", "c"]),
        ("type(z)", "number"),
        ("type(`null`)", "null"),
        ("to_array(z)", [0]),
        ("to_string(`{\"a\": [1, \"é\"]}`)", '{"a":[1,"\\u00e9"]}'),
        ("to_number(`\"12\"`)", 12),
        ("to_number(`\"1e3\"`)", 1000.0),
        ("to_number(`\"abc\"`)", None),
        ("max(xs)", 3),
        ("min(xs)", 1),
        ("sort(xs)", [1, 2, 3]),
        ("sum(`[]`)", 0),
        ("merge(o, `{\"z\": 9}`).z", 9),
        ("not_null(`null`, `\"\"`)", ""),
        ("sort_by(people, &age)[0].first", "K"),
        ("max_by(people, &age).first", "J"),
        ("min_by(people, &age).first", "K"),
        ("map(&first, people)", ["J", "K"]),
        ("map(&age, people)", [3, 1]),
        ("length(people[*].first)", 2),
    ],
)
def test_builtin_functions(expr, expected):
    assert search(expr, DOC) == expected


def test_function_refusals():
    with pytest.raises(UnknownFunctionError):
        search("nosuch(@)", DOC)
    with pytest.raises(InvalidArityError):
        search("length()", DOC)
    with pytest.raises(InvalidTypeError):
        search("abs(`true`)", DOC)
    with pytest.raises(InvalidTypeError):
        search("ceil(xs)", DOC)


def test_compile_defers_function_refusal_to_search():
    parsed = compile("nosuch(@)")
    with pytest.raises(UnknownFunctionError):
        parsed.search(DOC)


@pytest.mark.parametrize(
    "expr, exc",
    [
        ("", EmptyExpressionError),
        (" ", IncompleteExpressionError),
        ("\t\n", IncompleteExpressionError),
        ("a[0", IncompleteExpressionError),
        ("a |", IncompleteExpressionError),
        ("a.", ExpressionSyntaxError),
        (".a", ExpressionSyntaxError),
        ("a..b", ExpressionSyntaxError),
        ("a.1", ExpressionSyntaxError),
        ("a[1:2:3:4]", ExpressionSyntaxError),
        ("a[x]", ExpressionSyntaxError),
        ("a[0, 1]", ExpressionSyntaxError),
        ("a)", ExpressionSyntaxError),
        ("people[*]x", ExpressionSyntaxError),
        ("a-b", TokenSyntaxError),
        ("a = b", TokenSyntaxError),
        ('"abc', TokenSyntaxError),
        ("'abc", TokenSyntaxError),
        ("`abc", TokenSyntaxError),
        ("a$", TokenSyntaxError),
        ("a[::0]", ZeroSliceStepError),
    ],
)
def test_refusal_kinds(expr, exc):
    with pytest.raises(exc):
        compile(expr)


def test_token_syntax_is_a_subclass_of_syntax_but_not_syntax_itself():
    assert issubclass(TokenSyntaxError, ExpressionSyntaxError)
    assert TokenSyntaxError is not ExpressionSyntaxError
    assert not issubclass(EmptyExpressionError, ExpressionSyntaxError)
    assert not issubclass(IncompleteExpressionError, ExpressionSyntaxError)


def test_refusals_are_value_errors_with_positions():
    try:
        compile("a[1:2:3:4]")
    except ValueError as exc:
        assert exc.lex_position == 7
    else:
        raise AssertionError("expected a refusal")
    try:
        compile("a[0")
    except IncompleteExpressionError as exc:
        assert exc.lex_position == 3


def test_empty_is_not_a_successful_null():
    with pytest.raises(ValueError):
        search("", DOC)


def test_custom_provider_and_options():
    class Provider(Functions):
        @signature({"types": ["number"]}, {"types": ["string", "null"]})
        def _func_double(self, n, s):
            return (n * 2, s)

        @signature({"types": ["array"]})
        def _func_zero(self, items):
            return 0

    options = SimpleNamespace(dict_cls=None, custom_functions=Provider())
    assert search("double(`2`, `null`)", DOC, options) == (4, None)
    assert search("zero(xs)", DOC, options) == 0
    assert search("abs(`-2`)", DOC, options) == 2
    with pytest.raises(InvalidArityError):
        search("double(`2`)", DOC, options)
    with pytest.raises(InvalidTypeError):
        search("double(`true`, `null`)", DOC, options)
    with pytest.raises(UnknownFunctionError):
        search("double(`2`, `null`)", DOC)

    parsed = compile("double(`3`, `null`)")
    with pytest.raises(UnknownFunctionError):
        parsed.search(DOC)
    assert parsed.search(DOC, options) == (6, None)


def test_mapping_type_option():
    options = SimpleNamespace(dict_cls=OrderedDict, custom_functions=None)
    result = search("{a: `1`, b: `2`}", DOC, options)
    assert isinstance(result, OrderedDict)
    assert search("a", result, options) == 1
    assert search("length(@)", result, options) == 2


def test_expression_reference_is_non_null_and_bare():
    assert search("&a.b", DOC) is not None


def test_input_is_not_mutated():
    doc = {"l": [1, 2]}
    search("l[]", doc)
    search("l[*]", doc)
    assert doc == {"l": [1, 2]}


def test_package_exports():
    assert callable(pathsel.search)
    assert callable(pathsel.compile)
