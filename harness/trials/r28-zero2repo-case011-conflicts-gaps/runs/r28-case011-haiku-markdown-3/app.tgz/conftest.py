# Present so pytest puts the project root on sys.path (flat layout: the
# importable package `pathsel` lives directly under this directory).
