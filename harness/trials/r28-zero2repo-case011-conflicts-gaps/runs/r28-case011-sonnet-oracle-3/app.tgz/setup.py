from setuptools import setup
setup(name="pathsel", version="0.1.0", packages=["pathsel"])
