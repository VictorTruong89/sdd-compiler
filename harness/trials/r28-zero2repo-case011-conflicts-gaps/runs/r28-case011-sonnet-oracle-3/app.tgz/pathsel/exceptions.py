"""Failure kinds. Every refusal is a ValueError; the kind is the exception type."""


class PathSelError(ValueError):
    pass


class EmptyExpressionError(PathSelError):
    def __init__(self):
        PathSelError.__init__(self, "Invalid empty expression")


class IncompleteExpressionError(PathSelError):
    def __init__(self, lex_position, message="Invalid expression: incomplete"):
        PathSelError.__init__(self, "%s (position %d)" % (message, lex_position))
        self.lex_position = lex_position


class ParseError(PathSelError):
    """Grammar-level syntax failure."""

    def __init__(self, lex_position, message="syntax error"):
        PathSelError.__init__(self, "%s (position %d)" % (message, lex_position))
        self.lex_position = lex_position


class LexerError(ParseError):
    """Token-level syntax failure (a more specific form of ParseError)."""


class SliceStepZeroError(PathSelError):
    def __init__(self, message="slice step cannot be 0"):
        PathSelError.__init__(self, message)


class UnknownFunctionError(PathSelError):
    pass


class InvalidArityError(PathSelError):
    pass


class InvalidTypeError(PathSelError):
    pass
