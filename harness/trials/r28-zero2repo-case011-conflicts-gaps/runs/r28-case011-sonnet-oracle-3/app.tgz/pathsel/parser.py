"""Lexer and Pratt parser for PathSel expressions."""
import json

from .exceptions import (EmptyExpressionError, IncompleteExpressionError,
                         ParseError, LexerError, SliceStepZeroError)

WS = " \t\n\r"
IDSTART = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_")
IDCONT = IDSTART | set("0123456789")
DIGITS = set("0123456789")
SINGLE = {".": "dot", "*": "star", "]": "rbracket", ",": "comma", ":": "colon",
          "@": "current", "(": "lparen", ")": "rparen", "{": "lbrace",
          "}": "rbrace"}

BP = {
    "eof": 0, "unquoted_identifier": 0, "quoted_identifier": 0, "literal": 0,
    "rbracket": 0, "rparen": 0, "comma": 0, "rbrace": 0, "number": 0,
    "current": 0, "expref": 0, "colon": 0, "pipe": 1, "or": 2, "and": 3,
    "eq": 5, "gt": 5, "lt": 5, "gte": 5, "lte": 5, "ne": 5, "flatten": 9,
    "star": 20, "filter": 21, "dot": 40, "not": 45, "lbrace": 50,
    "lbracket": 55, "lparen": 60,
}
PROJECTION_STOP = 10
COMPARATORS = ("eq", "ne", "lt", "lte", "gt", "gte")


def _consume_until(text, i, delim, start):
    """text[i] is just after the opening delimiter. Returns (content, next_i)."""
    n = len(text)
    j = i
    while j < n:
        c = text[j]
        if c == "\\" and j + 1 < n:
            j += 2
            continue
        if c == delim:
            return text[i:j], j + 1
        j += 1
    raise LexerError(start, "unterminated %s" % delim)


def tokenize(text):
    """Returns list of (type, value, start). A trailing ('error', exc, pos) may
    replace eof when a token-level failure occurs."""
    toks = []
    i = 0
    n = len(text)
    try:
        while i < n:
            c = text[i]
            if c in WS:
                i += 1
            elif c in SINGLE:
                toks.append((SINGLE[c], c, i))
                i += 1
            elif c in IDSTART:
                j = i + 1
                while j < n and text[j] in IDCONT:
                    j += 1
                toks.append(("unquoted_identifier", text[i:j], i))
                i = j
            elif c in DIGITS or (c == "-" and i + 1 < n and text[i + 1] in DIGITS):
                j = i + 1
                while j < n and text[j] in DIGITS:
                    j += 1
                toks.append(("number", int(text[i:j]), i))
                i = j
            elif c == "-":
                raise LexerError(i, "unknown token '-'")
            elif c == "[":
                if i + 1 < n and text[i + 1] == "?":
                    toks.append(("filter", "[?", i))
                    i += 2
                elif i + 1 < n and text[i + 1] == "]":
                    toks.append(("flatten", "[]", i))
                    i += 2
                else:
                    toks.append(("lbracket", "[", i))
                    i += 1
            elif c == "|":
                if i + 1 < n and text[i + 1] == "|":
                    toks.append(("or", "||", i))
                    i += 2
                else:
                    toks.append(("pipe", "|", i))
                    i += 1
            elif c == "&":
                if i + 1 < n and text[i + 1] == "&":
                    toks.append(("and", "&&", i))
                    i += 2
                else:
                    toks.append(("expref", "&", i))
                    i += 1
            elif c == "<":
                if i + 1 < n and text[i + 1] == "=":
                    toks.append(("lte", "<=", i))
                    i += 2
                else:
                    toks.append(("lt", "<", i))
                    i += 1
            elif c == ">":
                if i + 1 < n and text[i + 1] == "=":
                    toks.append(("gte", ">=", i))
                    i += 2
                else:
                    toks.append(("gt", ">", i))
                    i += 1
            elif c == "!":
                if i + 1 < n and text[i + 1] == "=":
                    toks.append(("ne", "!=", i))
                    i += 2
                else:
                    toks.append(("not", "!", i))
                    i += 1
            elif c == "=":
                if i + 1 < n and text[i + 1] == "=":
                    toks.append(("eq", "==", i))
                    i += 2
                else:
                    raise LexerError(i, "unknown token '='")
            elif c == '"':
                content, j = _consume_until(text, i + 1, '"', i)
                try:
                    val = json.loads('"%s"' % content)
                except ValueError:
                    raise LexerError(i, "invalid quoted identifier")
                toks.append(("quoted_identifier", val, i))
                i = j
            elif c == "'":
                content, j = _consume_until(text, i + 1, "'", i)
                toks.append(("literal", content.replace("\\'", "'"), i))
                i = j
            elif c == "`":
                content, j = _consume_until(text, i + 1, "`", i)
                content = content.replace("\\`", "`")
                try:
                    val = json.loads(content)
                except ValueError:
                    try:
                        val = json.loads('"%s"' % content.lstrip())
                    except ValueError:
                        raise LexerError(i, "invalid JSON literal")
                toks.append(("literal", val, i))
                i = j
            else:
                raise LexerError(i, "unknown token %r" % c)
    except LexerError as e:
        toks.append(("error", e, e.lex_position))
        return toks
    toks.append(("eof", "", n))
    return toks


class Parser(object):
    def __init__(self, text):
        self.text = text
        self.tokens = tokenize(text)
        self.pos = 0

    # token helpers
    def peek(self, n=0):
        i = self.pos + n
        if i >= len(self.tokens):
            return self.tokens[-1] if n else self.tokens[-1]
        tok = self.tokens[i]
        if tok[0] == "error" and n == 0:
            raise tok[1]
        return tok

    def ctype(self, n=0):
        t = self.peek(n)
        return t[0]

    def advance(self):
        self.pos += 1

    def fail(self, tok, msg="syntax error"):
        if tok[0] == "eof":
            raise IncompleteExpressionError(tok[2])
        raise ParseError(tok[2], "%s: unexpected token %r" % (msg, tok[1]))

    def match(self, ttype):
        tok = self.peek()
        if tok[0] == ttype:
            self.advance()
            return tok
        self.fail(tok, "expected %s" % ttype)

    # entry
    def parse(self):
        if self.text == "":
            raise EmptyExpressionError()
        node = self.expression(0)
        tok = self.peek()
        if tok[0] != "eof":
            raise ParseError(tok[2], "unexpected token %r" % (tok[1],))
        return node

    def expression(self, bp=0):
        tok = self.peek()
        self.advance()
        left = self.nud(tok)
        while bp < BP.get(self.ctype(), 0):
            tok = self.peek()
            self.advance()
            left = self.led(tok, left)
        return left

    def nud(self, tok):
        t = tok[0]
        if t == "literal":
            return ("literal", tok[1])
        if t in ("unquoted_identifier", "quoted_identifier"):
            return ("field", tok[1], t == "quoted_identifier")
        if t == "star":
            rhs = self.projection_rhs(BP["star"])
            return ("value_projection", ("identity",), rhs)
        if t == "filter":
            return self.led_filter(("identity",))
        if t == "lbrace":
            return self.multiselect_hash()
        if t == "flatten":
            return self.led_flatten(("identity",))
        if t == "lbracket":
            nt = self.ctype()
            if nt in ("number", "colon"):
                right = self.index_expression()
                return self.project_if_slice(("identity",), right)
            if nt == "star" and self.ctype(1) == "rbracket":
                self.advance()
                self.advance()
                rhs = self.projection_rhs(BP["star"])
                return ("projection", ("identity",), rhs)
            return self.multiselect_list()
        if t == "current":
            return ("identity",)
        if t == "expref":
            return ("expref", self.expression(BP["expref"]))
        if t == "not":
            return ("not", self.expression(BP["not"]))
        if t == "lparen":
            e = self.expression(0)
            self.match("rparen")
            return e
        self.fail(tok)

    def led(self, tok, left):
        t = tok[0]
        if t == "dot":
            if self.ctype() != "star":
                right = self.dot_rhs(BP["dot"])
                return ("subexpression", left, right)
            self.advance()
            right = self.projection_rhs(BP["dot"])
            return ("value_projection", left, right)
        if t == "pipe":
            return ("pipe", left, self.expression(BP["pipe"]))
        if t == "or":
            return ("or", left, self.expression(BP["or"]))
        if t == "and":
            return ("and", left, self.expression(BP["and"]))
        if t == "lparen":
            if left[0] != "field" or left[2]:
                raise ParseError(tok[2], "invalid function name")
            args = []
            if self.ctype() != "rparen":
                while True:
                    args.append(self.expression(0))
                    if self.ctype() == "comma":
                        self.advance()
                        continue
                    break
            self.match("rparen")
            return ("function", left[1], args)
        if t == "filter":
            return self.led_filter(left)
        if t == "flatten":
            return self.led_flatten(left)
        if t in COMPARATORS:
            return ("comparator", t, left, self.expression(BP[t]))
        if t == "lbracket":
            nt = self.ctype()
            if nt in ("number", "colon"):
                right = self.index_expression()
                return self.project_if_slice(left, right)
            self.match("star")
            self.match("rbracket")
            rhs = self.projection_rhs(BP["star"])
            return ("projection", left, rhs)
        raise ParseError(tok[2], "unexpected token %r" % (tok[1],))

    def led_filter(self, left):
        cond = self.expression(0)
        self.match("rbracket")
        rhs = self.projection_rhs(BP["filter"])
        return ("filter_projection", left, cond, rhs)

    def led_flatten(self, left):
        rhs = self.projection_rhs(BP["flatten"])
        return ("projection", ("flatten", left), rhs)

    def project_if_slice(self, left, right):
        node = ("index_expression", left, right)
        if right[0] == "slice":
            rhs = self.projection_rhs(BP["star"])
            return ("projection", node, rhs)
        return node

    def projection_rhs(self, bp):
        t = self.ctype()
        if BP.get(t, 0) < PROJECTION_STOP:
            return ("identity",)
        if t in ("lbracket", "filter"):
            return self.expression(bp)
        if t == "dot":
            self.advance()
            return self.dot_rhs(bp)
        self.fail(self.peek())

    def dot_rhs(self, bp):
        t = self.ctype()
        if t in ("quoted_identifier", "unquoted_identifier", "star"):
            return self.expression(bp)
        if t == "lbracket":
            self.advance()
            return self.multiselect_list()
        if t == "lbrace":
            self.advance()
            return self.multiselect_hash()
        tok = self.peek()
        raise ParseError(tok[2], "expected identifier, wildcard or multiselect")

    def index_expression(self):
        if self.ctype() == "colon" or self.ctype(1) == "colon":
            return self.slice_expression()
        tok = self.peek()
        self.advance()
        node = ("index", tok[1])
        self.match("rbracket")
        return node

    def slice_expression(self):
        parts = [None, None, None]
        index = 0
        tok = self.peek()
        while tok[0] != "rbracket" and index < 3:
            if tok[0] == "colon":
                index += 1
                if index == 3:
                    raise ParseError(tok[2], "too many slice parts")
                self.advance()
            elif tok[0] == "number":
                parts[index] = tok[1]
                self.advance()
            else:
                self.fail(tok, "invalid slice")
            tok = self.peek()
        self.match("rbracket")
        if parts[2] == 0:
            raise SliceStepZeroError()
        return ("slice", parts[0], parts[1], parts[2])

    def multiselect_list(self):
        exprs = []
        while True:
            exprs.append(self.expression(0))
            if self.ctype() == "comma":
                self.advance()
                continue
            self.match("rbracket")
            break
        return ("multi_list", exprs)

    def multiselect_hash(self):
        pairs = []
        while True:
            tok = self.peek()
            if tok[0] not in ("unquoted_identifier", "quoted_identifier"):
                self.fail(tok, "expected key")
            self.advance()
            self.match("colon")
            pairs.append((tok[1], self.expression(0)))
            if self.ctype() == "comma":
                self.advance()
                continue
            self.match("rbrace")
            break
        return ("multi_hash", pairs)


def parse(text):
    return Parser(text).parse()
