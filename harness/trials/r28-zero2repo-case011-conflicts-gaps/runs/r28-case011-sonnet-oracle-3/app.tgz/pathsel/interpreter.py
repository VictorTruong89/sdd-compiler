"""Tree interpreter for parsed PathSel expressions."""
import copy
from collections.abc import Mapping
from decimal import Decimal

from .exceptions import InvalidArityError, InvalidTypeError


def is_obj(v):
    if isinstance(v, Mapping):
        return True
    if isinstance(v, (str, bytes, list, tuple)) or v is None:
        return False
    return hasattr(v, "keys") and hasattr(v, "__getitem__") and callable(v.keys)


def is_array(v):
    return isinstance(v, (list, tuple))


def is_number(v):
    return isinstance(v, (int, float, Decimal)) and not isinstance(v, bool)


def obj_keys(v):
    return list(v.keys())


def is_false(v):
    if v is None or v is False:
        return True
    if isinstance(v, (str, list, tuple)):
        return len(v) == 0
    if is_obj(v):
        return len(obj_keys(v)) == 0
    return False


def equals(a, b):
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if is_array(a):
        if not is_array(b) or len(a) != len(b):
            return False
        return all(equals(x, y) for x, y in zip(a, b))
    if is_obj(a):
        if not is_obj(b):
            return False
        ka = obj_keys(a)
        kb = obj_keys(b)
        if len(ka) != len(kb):
            return False
        for k in ka:
            if k not in kb or not equals(a[k], b[k]):
                return False
        return True
    if is_array(b) or is_obj(b):
        return False
    try:
        return bool(a == b)
    except Exception:
        return False


class Expref(object):
    def __init__(self, node, interp):
        self.node = node
        self.interp = interp

    def eval(self, value):
        return self.interp.visit(self.node, value)


class Interpreter(object):
    def __init__(self, options=None):
        from .functions import Functions
        self.dict_cls = getattr(options, "dict_cls", None)
        provider = getattr(options, "custom_functions", None)
        self.functions = provider if provider is not None else _default_provider()

    def new_object(self):
        if self.dict_cls is not None:
            return self.dict_cls()
        return {}

    def visit(self, node, value):
        return getattr(self, "v_" + node[0])(node, value)

    def v_identity(self, node, value):
        return value

    def v_field(self, node, value):
        if is_obj(value):
            try:
                return value[node[1]]
            except (KeyError, IndexError, TypeError):
                return None
        return None

    def v_literal(self, node, value):
        v = node[1]
        if isinstance(v, (list, dict)):
            return copy.deepcopy(v)
        return v

    def v_subexpression(self, node, value):
        return self.visit(node[2], self.visit(node[1], value))

    v_pipe = v_subexpression

    def v_index_expression(self, node, value):
        return self.visit(node[2], self.visit(node[1], value))

    def v_index(self, node, value):
        if not is_array(value):
            return None
        try:
            return value[node[1]]
        except IndexError:
            return None

    def v_slice(self, node, value):
        if not is_array(value):
            return None
        return list(value)[slice(node[1], node[2], node[3])]

    def v_flatten(self, node, value):
        base = self.visit(node[1], value)
        if not is_array(base):
            return None
        out = []
        for el in base:
            if is_array(el):
                out.extend(el)
            else:
                out.append(el)
        return out

    def v_projection(self, node, value):
        base = self.visit(node[1], value)
        if not is_array(base):
            return None
        out = []
        for el in base:
            r = self.visit(node[2], el)
            if r is not None:
                out.append(r)
        return out

    def v_value_projection(self, node, value):
        base = self.visit(node[1], value)
        if not is_obj(base):
            return None
        out = []
        for k in obj_keys(base):
            r = self.visit(node[2], base[k])
            if r is not None:
                out.append(r)
        return out

    def v_filter_projection(self, node, value):
        base = self.visit(node[1], value)
        if not is_array(base):
            return None
        out = []
        for el in base:
            if not is_false(self.visit(node[2], el)):
                r = self.visit(node[3], el)
                if r is not None:
                    out.append(r)
        return out

    def v_comparator(self, node, value):
        op = node[1]
        a = self.visit(node[2], value)
        b = self.visit(node[3], value)
        if op == "eq":
            return equals(a, b)
        if op == "ne":
            return not equals(a, b)
        if (is_number(a) and is_number(b)) or (isinstance(a, str) and isinstance(b, str)):
            if op == "lt":
                return a < b
            if op == "lte":
                return a <= b
            if op == "gt":
                return a > b
            return a >= b
        return None

    def v_or(self, node, value):
        a = self.visit(node[1], value)
        if not is_false(a):
            return a
        return self.visit(node[2], value)

    def v_and(self, node, value):
        a = self.visit(node[1], value)
        if is_false(a):
            return a
        return self.visit(node[2], value)

    def v_not(self, node, value):
        return is_false(self.visit(node[1], value))

    def v_multi_list(self, node, value):
        if value is None:
            return None
        return [self.visit(e, value) for e in node[1]]

    def v_multi_hash(self, node, value):
        if value is None:
            return None
        out = self.new_object()
        for k, e in node[1]:
            out[k] = self.visit(e, value)
        return out

    def v_expref(self, node, value):
        return Expref(node[1], self)

    def v_function(self, node, value):
        name = node[1]
        from .functions import Functions
        fn, specs = Functions._lookup(self.functions, name)
        args = node[2]
        variadic = bool(specs) and bool(specs[-1].get("variadic"))
        if variadic:
            if len(args) < len(specs):
                raise InvalidArityError("%s() expects at least %d argument(s)" % (name, len(specs)))
        elif len(args) != len(specs):
            raise InvalidArityError("%s() expects %d argument(s), got %d" % (name, len(specs), len(args)))
        vals = [self.visit(a, value) for a in args]
        for i, v in enumerate(vals):
            spec = specs[i] if i < len(specs) else specs[-1]
            if not any(type_matches(v, t) for t in spec.get("types", [])):
                raise InvalidTypeError("%s(): argument %d has an invalid type" % (name, i + 1))
        return fn(*vals)


def type_matches(v, t):
    if t == "any":
        return not isinstance(v, Expref)
    if t == "expref":
        return isinstance(v, Expref)
    if t == "number":
        return is_number(v)
    if t == "string":
        return isinstance(v, str)
    if t == "boolean":
        return isinstance(v, bool)
    if t == "array":
        return is_array(v)
    if t == "object":
        return is_obj(v)
    if t == "null":
        return v is None
    if t == "array-number":
        return is_array(v) and all(is_number(x) for x in v)
    if t == "array-string":
        return is_array(v) and all(isinstance(x, str) for x in v)
    return False


_DEFAULT = []


def _default_provider():
    if not _DEFAULT:
        from .functions import Functions
        _DEFAULT.append(Functions())
    return _DEFAULT[0]
