"""pathsel: declarative extraction of values from JSON-like Python data."""
from .exceptions import (PathSelError, EmptyExpressionError,
                         IncompleteExpressionError, ParseError, LexerError,
                         SliceStepZeroError, UnknownFunctionError,
                         InvalidArityError, InvalidTypeError)
from .parser import parse as _parse
from .interpreter import Interpreter as _Interpreter


class ParsedExpression(object):
    def __init__(self, expression, ast):
        self.expression = expression
        self._ast = ast

    def search(self, value, options=None):
        return _Interpreter(options).visit(self._ast, value)

    def __repr__(self):
        return "ParsedExpression(%r)" % (self.expression,)


def compile(expression):
    return ParsedExpression(expression, _parse(expression))


def search(expression, data, options=None):
    return compile(expression).search(data, options)


__all__ = ["search", "compile", "ParsedExpression", "PathSelError",
           "EmptyExpressionError", "IncompleteExpressionError", "ParseError",
           "LexerError", "SliceStepZeroError", "UnknownFunctionError",
           "InvalidArityError", "InvalidTypeError"]
