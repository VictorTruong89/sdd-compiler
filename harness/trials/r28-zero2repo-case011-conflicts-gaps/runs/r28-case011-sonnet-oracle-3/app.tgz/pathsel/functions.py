"""Built-in functions and the provider extension point."""
import json
import math
import re
from decimal import Decimal

from .exceptions import UnknownFunctionError, InvalidTypeError
from .interpreter import (is_obj, is_array, is_number, obj_keys, equals,
                          Expref)


def signature(*arguments):
    def decorator(func):
        func.signature = list(arguments)
        return func
    return decorator


def _t(*types, **kw):
    d = {"types": list(types)}
    d.update(kw)
    return d


_INT_RE = re.compile(r"^[+-]?[0-9]+$")
_FLOAT_RE = re.compile(r"^[+-]?([0-9]+\.?[0-9]*|\.[0-9]+)([eE][+-]?[0-9]+)?$")


def _dump(v):
    if v is None:
        return "null"
    if v is True:
        return "true"
    if v is False:
        return "false"
    if isinstance(v, str):
        return json.dumps(v)
    if isinstance(v, Decimal):
        return str(v)
    if isinstance(v, (int, float)):
        return json.dumps(v)
    if is_array(v):
        return "[" + ",".join(_dump(x) for x in v) + "]"
    if is_obj(v):
        return "{" + ",".join(json.dumps(str(k)) + ":" + _dump(v[k]) for k in obj_keys(v)) + "}"
    return json.dumps(str(v))


def _keys_of(fn_name, ref, arr):
    keys = [ref.eval(el) for el in arr]
    if all(is_number(k) for k in keys) or all(isinstance(k, str) for k in keys):
        return keys
    raise InvalidTypeError("%s(): keys must be all numbers or all strings" % fn_name)


class Functions(object):
    """Provider of the built-in language functions. Subclass and add
    ``_func_<name>`` methods decorated with ``signature``."""

    def _lookup(self, name):
        fn = getattr(self, "_func_" + name, None)
        sig = getattr(fn, "signature", None) if fn is not None else None
        if fn is None or sig is None:
            raise UnknownFunctionError("unknown function: %s()" % name)
        return fn, sig

    @signature(_t("number"))
    def _func_abs(self, a):
        return abs(a)

    @signature(_t("array-number"))
    def _func_avg(self, a):
        if not a:
            return None
        return sum(a) / len(a)

    @signature(_t("number"))
    def _func_ceil(self, a):
        return math.ceil(a)

    @signature(_t("number"))
    def _func_floor(self, a):
        return math.floor(a)

    @signature(_t("array", "string"), _t("any"))
    def _func_contains(self, subject, search):
        if isinstance(subject, str):
            return isinstance(search, str) and search in subject
        return any(equals(x, search) for x in subject)

    @signature(_t("string"), _t("string"))
    def _func_ends_with(self, s, suffix):
        return s.endswith(suffix)

    @signature(_t("string"), _t("string"))
    def _func_starts_with(self, s, prefix):
        return s.startswith(prefix)

    @signature(_t("string", "array", "object"))
    def _func_length(self, a):
        if is_obj(a):
            return len(obj_keys(a))
        return len(a)

    @signature(_t("array", "string"))
    def _func_reverse(self, a):
        if isinstance(a, str):
            return a[::-1]
        return list(a)[::-1]

    @signature(_t("string"), _t("array-string"))
    def _func_join(self, glue, arr):
        return glue.join(arr)

    @signature(_t("object"))
    def _func_keys(self, o):
        return obj_keys(o)

    @signature(_t("object"))
    def _func_values(self, o):
        return [o[k] for k in obj_keys(o)]

    @signature(_t("any"))
    def _func_type(self, v):
        if v is None:
            return "null"
        if isinstance(v, bool):
            return "boolean"
        if isinstance(v, str):
            return "string"
        if is_number(v):
            return "number"
        if is_array(v):
            return "array"
        if is_obj(v):
            return "object"
        return "null"

    @signature(_t("any"))
    def _func_to_array(self, v):
        if is_array(v):
            return v
        return [v]

    @signature(_t("any"))
    def _func_to_string(self, v):
        if isinstance(v, str):
            return v
        return _dump(v)

    @signature(_t("any"))
    def _func_to_number(self, v):
        if is_number(v):
            return v
        if isinstance(v, str):
            if _INT_RE.match(v):
                return int(v)
            if _FLOAT_RE.match(v):
                return float(v)
        return None

    @signature(_t("array-number", "array-string"))
    def _func_max(self, a):
        return max(a) if a else None

    @signature(_t("array-number", "array-string"))
    def _func_min(self, a):
        return min(a) if a else None

    @signature(_t("array-number", "array-string"))
    def _func_sort(self, a):
        return sorted(a)

    @signature(_t("array-number"))
    def _func_sum(self, a):
        return sum(a)

    @signature(_t("object", variadic=True))
    def _func_merge(self, *objs):
        out = {}
        for o in objs:
            for k in obj_keys(o):
                out[k] = o[k]
        return out

    @signature(_t("any", variadic=True))
    def _func_not_null(self, *args):
        for a in args:
            if a is not None:
                return a
        return None

    @signature(_t("expref"), _t("array"))
    def _func_map(self, ref, arr):
        return [ref.eval(el) for el in arr]

    @signature(_t("array"), _t("expref"))
    def _func_sort_by(self, arr, ref):
        arr = list(arr)
        keys = _keys_of("sort_by", ref, arr)
        order = sorted(range(len(arr)), key=lambda i: keys[i])
        return [arr[i] for i in order]

    @signature(_t("array"), _t("expref"))
    def _func_max_by(self, arr, ref):
        arr = list(arr)
        if not arr:
            return None
        keys = _keys_of("max_by", ref, arr)
        best = 0
        for i in range(1, len(arr)):
            if keys[i] > keys[best]:
                best = i
        return arr[best]

    @signature(_t("array"), _t("expref"))
    def _func_min_by(self, arr, ref):
        arr = list(arr)
        if not arr:
            return None
        keys = _keys_of("min_by", ref, arr)
        best = 0
        for i in range(1, len(arr)):
            if keys[i] < keys[best]:
                best = i
        return arr[best]
