"""Tests for pathsel. Each test names the spec node ids it covers (``# spec:`` comments)."""

import decimal
from collections import OrderedDict
from types import SimpleNamespace

import pytest

import pathsel
from pathsel import Functions, signature
from pathsel.errors import (
    ArityError,
    EmptyExpressionError,
    IncompleteExpressionError,
    InvalidTypeError,
    SyntaxFailure,
    TokenSyntaxFailure,
    UnknownFunctionError,
    ZeroSliceStepError,
)

DOC = {
    "a": {"b": {"c": 42}},
    "arr": [1, [2, 3], None, {"x": 1}, 4],
    "people": [
        {"name": "a", "age": 10, "tags": ["x", "y"]},
        {"name": "b", "age": 30, "tags": []},
        {"name": "c", "age": 20, "tags": ["z"]},
    ],
    "n": [[1, 2], [3], []],
    "s": "héllo",
    "t": True,
    "z": 0,
    "nul": None,
}


def s(expr, data=DOC, options=None):
    return pathsel.search(expr, data, options)


def opts(dict_cls=None, custom_functions=None):
    return SimpleNamespace(dict_cls=dict_cls, custom_functions=custom_functions)


# -- FP-01: search, compile, missing paths, failures -------------------------

# spec: N-000001, N-000002, N-000003, N-000077
def test_N_000077_dotted_path_selects_nested_value():
    assert s("a.b.c") == 42
    assert s("a.b") == {"c": 42}


# spec: N-000003, N-000041, N-000059, N-000060, N-000083
def test_N_000083_missing_path_is_null_not_failure():
    assert s("a.x.y") is None
    assert s("nope") is None


# spec: N-000004, N-000005, N-000006, N-000073, N-000074, N-000075, N-000076
def test_N_000073_compile_entry_and_search_entry_exist():
    parsed = pathsel.compile("a.b.c")
    assert parsed.search(DOC) == 42
    assert pathsel.search("a.b.c", DOC) == 42


# spec: N-000078, N-000079, N-000018
def test_N_000078_parsed_expression_reused_across_documents():
    parsed = pathsel.compile("k")
    assert parsed.search({"k": 1}) == 1
    assert parsed.search({"k": 2}) == 2
    assert parsed.search({}) is None


# spec: N-000080, N-000081, N-000082, N-000342
def test_N_000080_one_shot_and_compiled_agree():
    for expr in ["a.b", "people[*].name", "arr[?@ == `1`]", "n[][]"]:
        assert s(expr) == pathsel.compile(expr).search(DOC)


# spec: N-000084
def test_N_000084_identifier_on_array_is_null():
    assert s("arr.x") is None
    assert s("people.name") is None


# spec: N-000086
def test_N_000086_compile_succeeds_even_when_search_is_null():
    parsed = pathsel.compile("missing.deep.path")
    assert parsed.search(DOC) is None


# spec: N-000087, N-000088, N-000089
def test_N_000087_empty_expression_refused_on_both_entries():
    with pytest.raises(EmptyExpressionError):
        pathsel.compile("")
    with pytest.raises(EmptyExpressionError):
        pathsel.search("", DOC)


# spec: N-000090, N-000091, N-000092, N-000093, N-000410
@pytest.mark.parametrize("expr", [" ", "\t\n\r ", "a[", "a[0", "(a", "a |", "a ||", "!", "&", "foo(", "{x:"])
def test_N_000090_incomplete_expression(expr):
    with pytest.raises(IncompleteExpressionError) as info:
        pathsel.compile(expr)
    assert isinstance(info.value.lex_position, int)


# spec: N-000094, N-000095, N-000097, N-000411
@pytest.mark.parametrize("expr", ["a.", "a.1", "a.-1", ".a", "a..b", "a b", "a)", "a[1:2:3:4]", "a[1:x]", "*foo", "a[*]*"])
def test_N_000094_grammar_level_syntax(expr):
    with pytest.raises(SyntaxFailure) as info:
        pathsel.compile(expr)
    assert not isinstance(info.value, TokenSyntaxFailure)
    assert isinstance(info.value.lex_position, int)


# spec: N-000096, N-000098, N-000099, N-000100, N-000101, N-000412, N-000413, N-000414
@pytest.mark.parametrize("expr", ["foo-bar", "=", "a = b", "`abc", "'abc", '"abc', '"a\\q"', "#", "a &&& é"])
def test_N_000096_token_level_syntax_is_subclass(expr):
    with pytest.raises(TokenSyntaxFailure) as info:
        pathsel.compile(expr)
    assert isinstance(info.value, SyntaxFailure)
    assert not isinstance(info.value, (EmptyExpressionError, IncompleteExpressionError))


# spec: N-000102, N-000103, N-000104, N-000421, N-000422
def test_N_000102_positions_reported():
    with pytest.raises(SyntaxFailure) as info:
        pathsel.compile("a b")
    assert info.value.lex_position == 2
    with pytest.raises(IncompleteExpressionError) as info:
        pathsel.compile("a |")
    assert info.value.lex_position == 3
    with pytest.raises(TokenSyntaxFailure) as info:
        pathsel.compile("foo-bar")
    assert info.value.lex_position == 3
    with pytest.raises(SyntaxFailure) as info:
        pathsel.compile("a.")
    assert info.value.lex_position == 2


# spec: N-000105, N-000106, N-000063, N-000064, N-000065, N-000405
def test_N_000105_every_refusal_is_value_error_and_not_null():
    for expr in ["", " ", "a.", "foo()", "length()", "arr[::0]"]:
        with pytest.raises(ValueError):
            s(expr)


# -- FP-02: identifiers ------------------------------------------------------

# spec: N-000107, N-000108, N-000109
def test_N_000107_identifiers_chain_with_spaces():
    assert s("a . b\n.c") == 42
    assert s(" a\t.\tb ") == {"c": 42}
    assert s("_u.x") is None


# spec: N-000110, N-000111, N-000112, N-000113, N-000114
def test_N_000110_quoted_identifier_names_any_key():
    data = {"a b": 1, "x.y": 2, "q\"t": 3, "1st": 4, "é": 5, "h-k": 6, "a\nb": 7}
    assert s('"a b"', data) == 1
    assert s('"x.y"', data) == 2
    assert s('"q\\"t"', data) == 3
    assert s('"1st"', data) == 4
    assert s('"\\u00e9"', data) == 5
    assert s('"h-k"', data) == 6
    assert s('"a\\nb"', data) == 7
    assert s('"x.y"', {"x": {"y": 9}}) is None  # one key, not two levels


# spec: N-000115, N-000116
def test_N_000115_field_on_array_is_null_and_does_not_project():
    assert s("people.name") is None
    assert s("n.length") is None


# spec: N-000117, N-000118
def test_N_000117_number_after_dot_refused_quoted_key_works():
    with pytest.raises(SyntaxFailure):
        pathsel.compile("a.0")
    assert s('"0"', {"0": "zero"}) == "zero"


# spec: N-000119, N-000120, N-000121, N-000122
def test_N_000119_hyphen_is_not_identifier_character():
    with pytest.raises(TokenSyntaxFailure):
        pathsel.compile("ab-cd")
    with pytest.raises(TokenSyntaxFailure):
        pathsel.compile("a.-")


# spec: N-000123, N-000124, N-000125
def test_N_000124_unterminated_quoted_identifier_refused():
    with pytest.raises(TokenSyntaxFailure):
        pathsel.compile('"abc')
    with pytest.raises(TokenSyntaxFailure):
        pathsel.compile('"a\\qb"')
    assert s("a.zz.yy") is None


# -- FP-03: index, slice, flatten --------------------------------------------

# spec: N-000126, N-000127, N-000128, N-000129
def test_N_000126_index_including_negative_and_out_of_range():
    assert s("arr[0]") == 1
    assert s("arr[-1]") == 4
    assert s("arr[99]") is None
    assert s("arr[-99]") is None
    assert s("a[0]") is None
    assert s("s[0]") is None


# spec: N-000130, N-000131, N-000132, N-000133, N-000134, N-000135, N-000136, N-000137
def test_N_000130_positive_slices():
    data = [0, 1, 2, 3, 4]
    assert s("[1:3]", data) == [1, 2]
    assert s("[:2]", data) == [0, 1]
    assert s("[2:]", data) == [2, 3, 4]
    assert s("[::2]", data) == [0, 2, 4]
    assert s("[-2:]", data) == [3, 4]
    assert s("[:-4]", data) == [0]
    assert s("[10:20]", data) == []


# spec: N-000138, N-000139, N-000140
def test_N_000138_negative_step_slices():
    data = [0, 1, 2, 3, 4]
    assert s("[::-1]", data) == [4, 3, 2, 1, 0]
    assert s("[::-2]", data) == [4, 2, 0]
    assert s("[3:0:-1]", data) == [3, 2, 1]
    assert s("[:-10:-1]", data) == [4, 3, 2, 1, 0]


# spec: N-000141, N-000142, N-000156, N-000157
def test_N_000141_empty_slice_and_non_array_slice():
    assert s("[1:0]", [0, 1]) == []
    assert s("s[0:2]") is None
    assert s("a[0:1]") is None


# spec: N-000143, N-000144
def test_N_000143_slice_is_projection_dropping_nulls():
    assert s("arr[0:3].x") == []
    assert s("people[0:2].name") == ["a", "b"]


# spec: N-000145, N-000146, N-000147, N-000148, N-000149, N-000150, N-000151
def test_N_000145_flatten_one_level_and_projection():
    assert s("n[]") == [1, 2, 3]
    assert s("n[][]") == [1, 2, 3]
    assert s("people[].name") == ["a", "b", "c"]
    assert s("a[]") is None
    assert s("[]", [[1], 2]) == [1, 2]
    assert s("people[*].tags[]") == ["x", "y", "z"]


# spec: N-000152, N-000153, N-000154
def test_N_000152_zero_slice_step_refused():
    for expr in ["arr[::0]", "arr[1:2:0]"]:
        with pytest.raises(ZeroSliceStepError):
            s(expr)
        with pytest.raises(ZeroSliceStepError):
            pathsel.compile(expr).search(DOC)
        assert not isinstance(ZeroSliceStepError(), SyntaxFailure)
    pathsel.compile("arr[::0]")  # compiles; the search refuses


# -- FP-04: wildcards and filters --------------------------------------------

# spec: N-000158, N-000159, N-000160, N-000161, N-000162, N-000204, N-000205
def test_N_000159_list_wildcard_projects_and_drops_nulls():
    assert s("people[*].name") == ["a", "b", "c"]
    assert s("arr[*]") == [1, [2, 3], {"x": 1}, 4]
    assert s("a[*]") is None
    assert s("nul[*]") is None


# spec: N-000163, N-000164, N-000165
def test_N_000163_object_wildcard_projects_values():
    data = {"x": {"v": 1}, "y": {"v": 2}, "z": 3}
    assert s("*.v", data) == [1, 2]
    assert s("*", {"k": 1, "j": None, "m": 2}) == [1, 2]
    assert s("*", [1, 2]) is None
    assert s("a.*", DOC) == [{"c": 42}]


# spec: N-000166, N-000167
def test_N_000166_nested_projection_drops_null_inner():
    assert s("people[*].tags[*]") == [["x", "y"], [], ["z"]]
    assert s("n[*][0]") == [1, 3]


# spec: N-000168, N-000169, N-000170, N-000171, N-000172, N-000173
def test_N_000168_filter_keeps_true_values_then_projects():
    assert s("people[?age > `15`].name") == ["b", "c"]
    assert s("people[?age > `100`]") == []
    assert s("a[?x]") is None
    assert s("arr[?@ != `null`]") == [1, [2, 3], {"x": 1}, 4]


# spec: N-000174, N-000175, N-000176, N-000177, N-000178, N-000179
def test_N_000174_predicate_forms():
    data = [{"a": 0, "b": "", "ok": True}, {"a": None, "ok": False}, {"a": "x", "ok": True}]
    assert s("[?ok].a", data) == [0, "x"]  # 0 is a true value, null is a false value
    assert s("[?a == 'x']", data) == [{"a": "x", "ok": True}]
    assert s("[?ok && a]", data) == [{"a": 0, "b": "", "ok": True}, {"a": "x", "ok": True}]
    assert s("[?!ok]", data) == [{"a": None, "ok": False}]


# spec: N-000180, N-000181
def test_N_000180_filter_equality_is_json_equality():
    data = [{"v": 0}, {"v": False}, {"v": 1}, {"v": True}, {"v": 0.0}]
    assert s("[?v == `0`]", data) == [{"v": 0}, {"v": 0.0}]
    assert s("[?v == `1`]", data) == [{"v": 1}]
    assert s("[?v == `false`]", data) == [{"v": False}]


# spec: N-000182, N-000183, N-000184, N-000185, N-000186, N-000187, N-000188, N-000189, N-000190, N-000191, N-000192, N-000193, N-000194
def test_N_000182_projection_reach_rules():
    data = {"a": [{"b": [1, 2]}, {"b": [3]}]}
    assert s("a[*].b[0]", data) == [1, 3]
    assert s("a[*].b[*]", data) == [[1, 2], [3]]
    assert s("a[*].b | [0]", data) == [1, 2]
    assert s("a[*].b[0] | [0]", data) == 1
    assert s("a[*].b[*][0]", data) == [[], []]  # index applies to each element; non-arrays drop


# spec: N-000195, N-000196, N-000197
def test_N_000195_comparison_compares_whole_projected_array():
    assert s("people[*].age > `5`") is None
    assert s("people[*].age == `10`") is False


# spec: N-000198, N-000199
def test_N_000198_placement_decisions_documented():
    # Slice after an index starts a projection; a later step after a dot-multiselect joins it.
    assert s("n[0][0:1]") == [1]
    assert s("people[*].{v: age}.v") == [10, 30, 20]


# spec: N-000200, N-000201, N-000203
def test_N_000200_wildcard_and_filter_refusals():
    for expr in ["*foo", "[*]5", "people[*]*", "[?]", "[?a"]:
        with pytest.raises((SyntaxFailure, IncompleteExpressionError)):
            pathsel.compile(expr)


# spec: N-000202
def test_N_000202_filter_on_non_array_is_null():
    assert s("a[?x]") is None
    assert s("s[?@]") is None


# -- FP-05: construct, pipe, current value, literals ---------------------------

# spec: N-000206, N-000207, N-000208, N-000209, N-000210
def test_N_000206_multiselect_hash_builds_object():
    assert s("people[0].{n: name, miss: nothing}") == {"n": "a", "miss": None}
    assert s("{q: a.b.c, w: `2`}") == {"q": 42, "w": 2}
    assert s('{"a b": a.b.c}') == {"a b": 42}


# spec: N-000211, N-000212, N-000213, N-000214, N-000215, N-000216, N-000217, N-000218
def test_N_000211_multiselect_list_builds_array_with_nulls():
    assert s("[a.b.c, missing, s]") == [42, None, "héllo"]
    assert s("people[*].[name, age]") == [["a", 10], ["b", 30], ["c", 20]]
    assert s("nul.[a, b]") is None
    assert s("nul.{a: b}") is None


# spec: N-000219, N-000220, N-000221, N-000222
def test_N_000219_pipe_passes_whole_result_and_binds_loosest():
    assert s("people[*].name | [0]") == "a"
    assert s("a.b | c") == 42
    assert s("people[*].age | length(@)") == 3
    assert s("a || b | c") is None  # pipe is loosest: (a || b) | c, and a has no c
    assert s("a || missing | b") == {"c": 42}


# spec: N-000223, N-000224, N-000225, N-000226
def test_N_000223_json_literal_regardless_of_document():
    assert s("`[1,2]`[1]") == 2
    assert s("`{\"k\": \"v\"}`.k") == "v"
    assert s("`  42 `") == 42
    assert s("`bare text`") == "bare text"
    assert s("`null`") is None


# spec: N-000227, N-000228, N-000229, N-000230, N-000238, N-000239, N-000049
def test_N_000227_raw_string_literal():
    assert s("'hello world'") == "hello world"
    assert s("'123'") == "123"
    assert s("'it\\'s'") == "it's"
    assert s("'\\u0041\\u00e9'") == "Aé"
    assert s("'a\\nb'") == "a\\nb"  # no JSON escapes except the ones stated
    with pytest.raises(TokenSyntaxFailure):
        pathsel.compile("'unterminated")
    with pytest.raises(SyntaxFailure):
        pathsel.compile("a.'lit'")


# spec: N-000231, N-000232, N-000233, N-000234, N-000235, N-000236, N-000423
def test_N_000231_expression_reference_is_not_evaluated_on_its_own():
    ref = s("&a.b")
    assert ref is not None
    assert ref is not DOC
    assert isinstance(ref, pathsel.ExpressionReference)


# spec: N-000237
def test_N_000237_unclosed_backtick_and_bad_json_refused():
    with pytest.raises(TokenSyntaxFailure):
        pathsel.compile("`abc")
    with pytest.raises(TokenSyntaxFailure):
        pathsel.compile('`"abc`')


# -- FP-06: comparators and logic ----------------------------------------------

# spec: N-000242, N-000243, N-000244
def test_N_000242_equality_is_json_equality():
    assert s("a.b.c == `42`") is True
    assert s("arr == `[1]`") is False
    assert s("`[1,[2]]` == `[1,[2.0]]`") is True
    assert s("`{\"a\":1}` == `{\"a\":1.0}`") is True
    assert s("`0` == `false`") is False
    assert s("`1` == `true`") is False
    assert s("a.b.c != `42`") is False


# spec: N-000245, N-000246
def test_N_000245_ordering_numbers_and_strings():
    assert s("a.b.c > `10`") is True
    assert s("a.b.c <= `42`") is True
    assert s("'b' > 'a'") is True
    assert s("'B' < 'a'") is True  # code point order
    assert s("a.b.c < 'x'") is None


# spec: N-000247, N-000248, N-000249, N-000250
def test_N_000247_or_and_return_operands():
    assert s("missing || 'fallback'") == "fallback"
    assert s("z || 'fallback'") == 0
    assert s("missing && 'x'") is None
    assert s("z && 'x'") == "x"


# spec: N-000251, N-000252
def test_N_000251_not_operator():
    assert s("!missing") is True
    assert s("!z") is False
    assert s("!`0.0`") is False


# spec: N-000253, N-000254, N-000255, N-000256, N-000257
def test_N_000253_binding_order():
    assert s("!a.b.c") is None  # a dot step after ! applies to the result of !
    assert s("(!a).b") is None
    assert s("!arr[0]") is False  # brackets directly after the operand bind to it
    assert s("!(a.b.c == `42`)") is False
    assert s("missing || z && 'x'") == "x"


# spec: N-000258
def test_N_000258_same_operators_in_predicates():
    data = [{"v": 1}, {"v": 0}]
    assert s("[?v == `1` || v == `0`]", data) == data


# spec: N-000259
def test_N_000259_filter_non_array_null_choice_documented():
    assert s("a[?b]") is None


# spec: N-000260, N-000261
def test_N_000260_lone_equals_and_ampersand_refused():
    with pytest.raises(TokenSyntaxFailure):
        pathsel.compile("a = b")
    with pytest.raises(IncompleteExpressionError):
        pathsel.compile("a &&")
    with pytest.raises(SyntaxFailure):
        pathsel.compile("a & b")


# -- FP-07: built-in functions -------------------------------------------------

# spec: N-000262, N-000263, N-000264, N-000265, N-000266, N-000267, N-000268
def test_N_000263_builtin_names_all_resolve():
    names = {
        "abs": "abs(`-1`)", "avg": "avg(`[1]`)", "ceil": "ceil(`1.5`)", "contains": "contains(`[1]`, `1`)",
        "ends_with": "ends_with('ab', 'b')", "floor": "floor(`1.5`)", "join": "join(',', `[\"a\"]`)",
        "keys": "keys(a)", "length": "length(s)", "map": "map(&x, `[{\"x\":1}]`)",
        "max": "max(`[1,2]`)", "max_by": "max_by(`[{\"x\":1}]`, &x)", "merge": "merge(a)",
        "min": "min(`[1,2]`)", "min_by": "min_by(`[{\"x\":1}]`, &x)", "not_null": "not_null(nul)",
        "reverse": "reverse(`[1]`)", "sort": "sort(`[2,1]`)", "sort_by": "sort_by(`[{\"x\":1}]`, &x)",
        "starts_with": "starts_with('ab', 'a')", "sum": "sum(`[1]`)", "to_array": "to_array(z)",
        "to_number": "to_number('1')", "to_string": "to_string(z)", "type": "type(z)", "values": "values(a)",
    }
    assert len(names) == 26
    for expr in names.values():
        assert s(expr) is not None or expr.startswith(("keys", "not_null"))


# spec: N-000264, N-000265, N-000266, N-000344, N-000416, N-000417, N-000418, N-000420
def test_N_000264_check_order_name_then_count_then_type():
    with pytest.raises(UnknownFunctionError):
        s("nope()")
    with pytest.raises(ArityError):
        s("abs()")
    with pytest.raises(InvalidTypeError):
        s("abs('x')")
    # Compiling a wrong call succeeds; the search refuses.
    parsed = pathsel.compile("abs()")
    with pytest.raises(ArityError):
        parsed.search(DOC)
    with pytest.raises(ValueError):
        s("abs()")


# spec: N-000269
def test_N_000269_abs():
    assert s("abs(`-3.5`)") == 3.5


# spec: N-000270, N-000271
def test_N_000270_avg_and_empty():
    assert s("avg(`[1,2,3]`)") == 2
    assert s("avg(`[]`)") is None
    with pytest.raises(InvalidTypeError):
        s("avg(`[1,'x']`)")


# spec: N-000272, N-000273
def test_N_000272_ceil_floor_return_integers():
    assert s("ceil(`1.2`)") == 2 and isinstance(s("ceil(`1.2`)"), int)
    assert s("floor(`-1.2`)") == -2 and isinstance(s("floor(`-1.2`)"), int)


# spec: N-000274, N-000275
def test_N_000274_contains_array_and_string():
    assert s("contains(`[1,2]`, `2`)") is True
    assert s("contains(`[1,2]`, `3`)") is False
    assert s("contains('hello', 'ell')") is True
    with pytest.raises(InvalidTypeError):
        s("contains('hello', `1`)")


# spec: N-000276
def test_N_000276_starts_and_ends_with():
    assert s("ends_with('hello', 'lo')") is True
    assert s("starts_with('hello', 'he')") is True
    assert s("starts_with('hello', 'lo')") is False


# spec: N-000277, N-000035
def test_N_000277_length_counts_characters_not_bytes():
    assert s("length(s)") == 5
    assert s("length('éé')") == 2
    assert s("length(`[1,2,3]`)") == 3
    assert s("length(a)") == 1


# spec: N-000278
def test_N_000278_reverse():
    assert s("reverse(`[1,2,3]`)") == [3, 2, 1]
    assert s("reverse('abc')") == "cba"


# spec: N-000279, N-000280
def test_N_000279_join():
    assert s("join(', ', `[\"a\",\"b\"]`)") == "a, b"
    assert s("join('-', `[]`)") == ""


# spec: N-000281
def test_N_000281_keys_and_values_in_iteration_order():
    data = {"b": 1, "a": 2}
    assert s("keys(@)", data) == ["b", "a"]
    assert s("values(@)", data) == [1, 2]


# spec: N-000282
def test_N_000282_type_names():
    assert s("type(z)") == "number"
    assert s("type(s)") == "string"
    assert s("type(t)") == "boolean"
    assert s("type(arr)") == "array"
    assert s("type(a)") == "object"
    assert s("type(nul)") == "null"


# spec: N-000283
def test_N_000283_to_array():
    assert s("to_array(`[1]`)") == [1]
    assert s("to_array(z)") == [0]
    assert s("to_array(nul)") == [None]


# spec: N-000284, N-000285
def test_N_000284_to_string_compact_json():
    assert s("to_string(`{\"a\":[1,2]}`)") == '{"a":[1,2]}'
    assert s("to_string(`[\"é\"]`)") == '["\\u00e9"]'
    assert s("to_string(`\"é\"`)") == "é"  # a string is returned unchanged
    assert s("to_string(z)") == "0"
    assert s("to_string(t)") == "true"
    assert s("to_string(nul)") == "null"
    assert s("to_string('x')") == "x"


# spec: N-000286, N-000287, N-000288, N-000289
def test_N_000286_to_number_forms():
    assert s("to_number('12')") == 12 and isinstance(s("to_number('12')"), int)
    assert s("to_number('1.5')") == 1.5
    assert s("to_number('1e3')") == 1000.0 and isinstance(s("to_number('1e3')"), float)
    assert s("to_number('abc')") is None
    assert s("to_number(t)") is None
    assert s("to_number(`[1]`)") is None
    assert s("to_number(z)") == 0


# spec: N-000290, N-000291, N-000292
def test_N_000290_max_min():
    assert s("max(`[1,3,2]`)") == 3
    assert s("min(`[1,3,2]`)") == 1
    assert s("max(`[\"a\",\"c\",\"b\"]`)") == "c"
    assert s("max(`[]`)") is None
    with pytest.raises(InvalidTypeError):
        s("max(`[1,\"a\"]`)")


# spec: N-000293
def test_N_000293_sort():
    assert s("sort(`[3,1,2]`)") == [1, 2, 3]
    assert s("sort(`[\"b\",\"a\"]`)") == ["a", "b"]
    with pytest.raises(InvalidTypeError):
        s("sort(`[1,\"a\"]`)")


# spec: N-000294
def test_N_000294_sum():
    assert s("sum(`[1,2,3.5]`)") == 6.5
    with pytest.raises(InvalidTypeError):
        s("sum(`[true]`)")


# spec: N-000295, N-000296, N-000297
def test_N_000295_merge_later_wins():
    assert s("merge(`{\"a\":1}`, `{\"a\":2,\"b\":3}`)") == {"a": 2, "b": 3}
    with pytest.raises(InvalidTypeError):
        s("merge(`[1]`)")


# spec: N-000298, N-000299, N-000300, N-000015
def test_N_000298_not_null_first_non_null():
    assert s("not_null(missing, nul, z, s)") == 0
    assert s("not_null(missing, nul)") is None
    assert s("not_null(missing, '')") == ""
    assert s("not_null(missing, `[]`)") == []


# spec: N-000301, N-000302
def test_N_000301_map_keeps_nulls():
    assert s("map(&x, `[{\"x\":1},{}]`)") == [1, None]


# spec: N-000303, N-000304, N-000305
def test_N_000303_sort_by_stable():
    data = [{"k": 2, "n": "a"}, {"k": 1, "n": "b"}, {"k": 2, "n": "c"}, {"k": 1, "n": "d"}]
    assert [x["n"] for x in s("sort_by(@, &k)", data)] == ["b", "d", "a", "c"]
    assert s("sort_by(`[]`, &k)") == []
    with pytest.raises(InvalidTypeError):
        s("sort_by(`[{\"k\":1},{\"k\":\"a\"}]`, &k)")


# spec: N-000306, N-000307, N-000308
def test_N_000306_max_by_min_by_first_on_ties():
    data = [{"k": 2, "n": "a"}, {"k": 1, "n": "b"}, {"k": 2, "n": "c"}]
    assert s("max_by(@, &k).n", data) == "a"
    assert s("min_by(@, &k).n", data) == "b"
    assert s("max_by(`[]`, &k)") is None
    assert s("min_by(`[]`, &k)") is None


# spec: N-000309, N-000310
def test_N_000309_function_as_projection_rhs_and_projection_as_argument():
    assert s("length(people[*].name)") == 3
    assert s("sum(people[*].age)") == 60


# spec: N-000311, N-000312, N-000313
def test_N_000311_argument_counts():
    with pytest.raises(ArityError):
        s("abs(`1`, `2`)")
    with pytest.raises(ArityError):
        s("not_null()")
    with pytest.raises(ArityError):
        s("merge()")
    assert s("not_null(`1`, `2`, `3`)") == 1


# spec: N-000314, N-000315, N-000316, N-000317, N-000318, N-000319, N-000320
def test_N_000314_argument_types():
    with pytest.raises(InvalidTypeError):
        s("abs(t)")  # a boolean is not a number
    with pytest.raises(InvalidTypeError):
        s("sum(arr)")  # mixed element types
    with pytest.raises(InvalidTypeError):
        s("length(z)")
    with pytest.raises(InvalidTypeError):
        s("map(x, arr)")  # not a reference
    with pytest.raises(InvalidTypeError):
        s("sort_by(people, name)")  # second argument is not a reference
    with pytest.raises(InvalidTypeError):
        s("max_by(`[{\"k\":1},{\"k\":\"a\"}]`, &k)")  # key types differ
    with pytest.raises(InvalidTypeError):
        s("max_by(`[{\"k\":null}]`, &k)")


# spec: N-000321, N-000322
def test_N_000321_quoted_name_cannot_call():
    with pytest.raises(SyntaxFailure):
        pathsel.compile('"abs"(1)')


# -- FP-08: options and custom functions ----------------------------------------

# spec: N-000323, N-000324, N-000325, N-000326, N-000327, N-000328
def test_N_000323_options_dict_cls_for_constructed_hash():
    built = s("{x: `1`}", DOC, opts(dict_cls=OrderedDict))
    assert isinstance(built, OrderedDict)
    assert built == {"x": 1}
    assert type(s("{x: `1`}")) is dict


# spec: N-000329, N-000330, N-000331, N-000332, N-000334
def test_N_000329_constructed_hash_is_object_for_selection_and_functions():
    o = opts(dict_cls=OrderedDict)
    assert s("{x: `1`}.x", DOC, o) == 1
    assert s("keys({x: `1`, y: `2`})", DOC, o) == ["x", "y"]
    assert s("merge({x: `1`})", DOC, o) == {"x": 1}
    assert s("type({x: `1`})", DOC, o) == "object"


# spec: N-000333
def test_N_000333_other_mapping_types_for_function_args_implementers_choice():
    class Plain(dict):
        pass

    assert s("length({x: `1`})", DOC, opts(dict_cls=Plain)) == 1


# spec: N-000335, N-000336, N-000337, N-000338, N-000339, N-000340, N-000341
def test_N_000335_custom_functions_extend_builtins():
    class Provider(Functions):
        @signature({"types": ["number"]}, {"types": ["string", "null"]})
        def _func_pad(self, n, text):
            return (text or "") + str(n)

        @signature()
        def _func_zero(self):
            return 0

        @signature({"types": ["array"]})
        def _func_empty(self, items):
            return []

    o = opts(dict_cls=OrderedDict, custom_functions=Provider())
    assert s("pad(`3`, 'x')", DOC, o) == "x3"
    assert s("pad(`3`, nul)", DOC, o) == "3"
    assert s("zero()", DOC, o) == 0  # returns 0: still a value
    assert s("empty(`[1]`)", DOC, o) == []
    assert s("abs(`-2`)", DOC, o) == 2  # built-ins still available
    assert s("{x: `1`}", DOC, o).__class__ is OrderedDict


# spec: N-000342, N-000343, N-000344
def test_N_000342_custom_name_compiles_without_provider_and_is_unknown_without_it():
    pathsel.compile("pad(`1`, 'x')")
    with pytest.raises(UnknownFunctionError):
        s("pad(`1`, 'x')")
    provider = Functions()
    with pytest.raises(UnknownFunctionError):
        s("pad(`1`, 'x')", DOC, opts(custom_functions=provider))


# spec: N-000345, N-000346, N-000347, N-000348, N-000349, N-000350
def test_N_000345_custom_arity_and_type_refusals():
    class Provider(Functions):
        @signature({"types": ["number"]})
        def _func_one(self, n):
            return n

    o = opts(custom_functions=Provider())
    with pytest.raises(ArityError):
        s("one(`1`, `2`)", DOC, o)
    with pytest.raises(InvalidTypeError):
        s("one(t)", DOC, o)  # a boolean is not a number
    with pytest.raises(InvalidTypeError):
        s("one(&x)", DOC, o)  # a reference is not a number


# spec: N-000351, N-000352, N-000353, N-000354, N-000355, N-000356, N-000357, N-000358, N-000359, N-000360, N-000361, N-000362, N-000363, N-000364, N-000365, N-000366, N-000367, N-000368, N-000369, N-000370, N-000371, N-000372, N-000373, N-000374, N-000375, N-000376, N-000377, N-000378, N-000379, N-000380, N-000381, N-000382
def test_N_000351_package_surface_and_layout():
    import importlib
    import sys

    assert callable(pathsel.search) and callable(pathsel.compile)
    assert importlib.import_module("pathsel.functions") is not None
    assert sys.version_info >= (3, 9)
    assert pathsel.search("a.b.c", DOC) == 42
    assert pathsel.compile("a.b.c").search(DOC) == 42
    assert pathsel.search("a", DOC, None) == {"b": {"c": 42}}


# spec: N-000383, N-000384, N-000385, N-000386, N-000387, N-000388, N-000389, N-000390, N-000391, N-000392, N-000393, N-000394, N-000395, N-000396, N-000397, N-000398, N-000399, N-000400, N-000401, N-000402, N-000403, N-000404
def test_N_000383_functions_and_parsed_expression_api():
    parsed = pathsel.compile("a.b.c")
    assert parsed is not None
    assert parsed.search(DOC, None) == 42
    assert opts(dict_cls=dict).dict_cls is dict
    assert Functions() is not None
    with pytest.raises(TypeError):
        signature("not a mapping")(lambda self: None)


# -- Non-functional constraints, failure carriers, and scope -------------------

# spec: N-000050, N-000051, N-000052, N-000053, N-000054, N-000055
def test_N_000050_pure_python_no_native_dependencies():
    import pathlib

    root = pathlib.Path(pathsel.__file__).parent
    for py in root.glob("*.py"):
        text = py.read_text()
        assert "import numpy" not in text and "ctypes" not in text


# spec: N-000056, N-000057, N-000058
def test_N_000056_host_values_are_selected_and_returned():
    class Thing:
        pass

    thing = Thing()
    assert s("a", {"a": thing}) is thing
    assert s("a.b", {"a": thing}) is None
    assert s("dec", {"dec": decimal.Decimal("1.5")}) == decimal.Decimal("1.5")
    assert s("dec > `1`", {"dec": decimal.Decimal("1.5")}) is True


# spec: N-000059, N-000060, N-000061, N-000062
def test_N_000059_missing_is_success_with_null_and_message_informational():
    assert s("missing") is None
    try:
        pathsel.compile("a b")
    except ValueError as exc:
        assert str(exc)


# spec: N-000063, N-000064, N-000065, N-000066
def test_N_000063_failures_are_value_errors_with_positions():
    with pytest.raises(ValueError) as info:
        pathsel.compile("a.")
    assert info.value.lex_position == 2


# spec: N-000067, N-000068, N-000069, N-000070, N-000071, N-000072
def test_N_000067_input_document_not_mutated_and_no_json_decoding():
    import copy

    data = {"a": [1, {"b": 2}]}
    snapshot = copy.deepcopy(data)
    s("a[*].b", data)
    s("{x: a[0]}", data)
    s("merge(a[1])", data)
    assert data == snapshot
    assert s("`{\"k\": 1}`.k") == 1  # JSON text in literals is read by the expression language, not the document


# spec: N-000405, N-000406, N-000407, N-000408, N-000409, N-000410, N-000411, N-000412, N-000413, N-000414, N-000415, N-000416, N-000417, N-000418, N-000419, N-000420, N-000421, N-000422
def test_N_000405_failure_carrier_types_are_distinct():
    assert issubclass(EmptyExpressionError, ValueError)
    assert issubclass(TokenSyntaxFailure, SyntaxFailure)
    assert not issubclass(TokenSyntaxFailure, (EmptyExpressionError, IncompleteExpressionError))
    assert not issubclass(SyntaxFailure, (EmptyExpressionError, IncompleteExpressionError))
    assert not issubclass(ZeroSliceStepError, SyntaxFailure)
    assert not issubclass(UnknownFunctionError, (ArityError, InvalidTypeError))
    assert not issubclass(ArityError, (UnknownFunctionError, InvalidTypeError))
    assert not issubclass(InvalidTypeError, (UnknownFunctionError, ArityError))
    for kind in (UnknownFunctionError, ArityError, InvalidTypeError, ZeroSliceStepError):
        assert issubclass(kind, ValueError)
    assert not isinstance(ArityError(), SyntaxFailure)


# spec: N-000423
def test_N_000423_bare_expression_reference_is_non_null():
    assert s("&a") is not None


# -- Terminology, public surface, and remaining rules --------------------------

# spec: N-000007, N-000008, N-000009, N-000038, N-000039, N-000040, N-000042, N-000043, N-000044, N-000045, N-000046, N-000047, N-000048
def test_N_000007_public_surface_and_both_paths_agree():
    # Search and compile give the same result for the same expression and document (N-000007),
    # and the public surface covers selection, indexes, projections, constructs, logic, and functions (N-000043-N-000048).
    assert s("people[?age > `15`].name") == pathsel.compile("people[?age > `15`].name").search(DOC)
    assert s("people[*].{n: name}") == [{"n": "a"}, {"n": "b"}, {"n": "c"}]
    assert s("arr[1]") == [2, 3]
    assert s("[].x", [[{"x": 1}], {"x": 2}]) == [1, 2]
    assert s("a.b.c == `42` && people[0].name == 'a'") is True
    assert s("max(n[][])") == 3


# spec: N-000008, N-000009, N-000049, N-000323
def test_N_000008_options_are_optional_and_add_mapping_type_and_functions():
    assert s("a.b.c", DOC, None) == 42
    assert s("{x: `1`}", DOC, opts(dict_cls=OrderedDict)).__class__ is OrderedDict


# spec: N-000010, N-000011, N-000012, N-000013
def test_N_000010_scope_statements_have_no_code_path():
    # These are statements about the specification document itself; nothing is built for them.
    assert pathsel.__doc__ is not None


# spec: N-000014, N-000015, N-000016, N-000017, N-000018, N-000019, N-000020, N-000021, N-000022, N-000023, N-000024, N-000025, N-000026, N-000027, N-000028, N-000029, N-000030, N-000031, N-000032, N-000033, N-000034, N-000036, N-000037
def test_N_000014_terminology_definitions_hold():
    # Null is the missing result; a missing field, a bad index, and a selector on the wrong kind all yield null.
    assert s("missing") is None and s("arr[99]") is None and s("s.x") is None
    # Object: a mapping. Array: a sequence. Boolean is not a number.
    assert s("type(a)") == "object" and s("type(arr)") == "array" and s("type(t)") == "boolean"
    assert s("to_number(t)") is None
    # Number: integer or float; a number made by to_number from a string is floating-point if not an integer numeral.
    assert isinstance(s("to_number('1.0')"), float)
    # Host decimals are numbers in comparisons.
    assert s("dec == `1.5`", {"dec": decimal.Decimal("1.5")}) is True
    # String length is in characters (not bytes).
    assert s("length(s)") == 5
    # False values: false, null, empty string, empty array, empty object; 0 and 0.0 are true values.
    assert s("!`0`") is False and s("!`0.0`") is False
    assert s("!''") is True and s("!`[]`") is True and s("!`{}`") is True
    # Expression reference outside a function argument is non-null (see NOTES.md).
    assert s("&a") is not None
    # Projection drops null results; an object wildcard collects non-null values.
    assert s("people[*].name") == ["a", "b", "c"]
    # Function, failure kind, and evaluation options: each has its own test above.
    assert s("abs(`-1`)") == 1


# spec: N-000034, N-000035, N-000036
def test_N_000034_failure_kinds_are_value_errors_and_token_syntax_is_a_syntax_kind():
    with pytest.raises(ValueError):
        pathsel.compile("a = b")
    assert issubclass(TokenSyntaxFailure, SyntaxFailure)


# spec: N-000085
def test_N_000085_identifier_on_non_object_never_projects():
    assert s("arr.x") is None
    assert s("people.name") is None
    assert s("s.length") is None


# spec: N-000155
def test_N_000155_slice_with_extra_parts_or_non_integer_is_grammar_syntax():
    for expr in ["arr[1:2:3:4]", "arr[1:x]", "arr[a:b]"]:
        with pytest.raises(SyntaxFailure) as info:
            pathsel.compile(expr)
        assert not isinstance(info.value, TokenSyntaxFailure)


# spec: N-000240, N-000241
def test_N_000240_multiselect_and_pipe_refusals():
    for expr in ["{a: b", "[a, b", "{a: b,}", "[a,]", "{a}", "a |"]:
        with pytest.raises((SyntaxFailure, IncompleteExpressionError)):
            pathsel.compile(expr)
