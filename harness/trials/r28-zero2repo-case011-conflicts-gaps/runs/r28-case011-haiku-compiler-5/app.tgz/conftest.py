"""pytest root marker: puts the repository root on sys.path so `import pathsel` works from any cwd."""
