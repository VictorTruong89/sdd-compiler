"""Failure kinds for pathsel.

Every refusal is a ValueError. The kind is carried by the exception type:

* EmptyExpressionError        -- empty-expression kind            # spec: N-000087, N-000409
* IncompleteExpressionError   -- incomplete-expression kind       # spec: N-000090, N-000410
* SyntaxFailure               -- syntax kind, grammar-level       # spec: N-000094, N-000411
* TokenSyntaxFailure          -- token-level form of the syntax   # spec: N-000096, N-000412
                                 kind (a subclass of SyntaxFailure)
* ZeroSliceStepError          -- zero-slice-step kind             # spec: N-000152, N-000415
* UnknownFunctionError        -- unknown-function kind            # spec: N-000264, N-000416
* ArityError                  -- invalid-arity kind               # spec: N-000265, N-000417
* InvalidTypeError            -- invalid-type kind                # spec: N-000266, N-000418

Syntax and incomplete refusals carry an int ``lex_position`` attribute.   # spec: N-000421, N-000422

Failure kinds are value errors and each belongs to exactly one kind. A
successful null is never a refusal.  # spec: N-000063, N-000064, N-000065, N-000105, N-000106, N-000405, N-000406, N-000407, N-000408, N-000034, N-000036, N-000037, N-000061, N-000101
"""


class PathSelError(ValueError):
    """Common base for every refusal. Not itself one of the kinds."""

    lex_position = None


class EmptyExpressionError(PathSelError):
    """The zero-length expression text.  # spec: N-000087, N-000088, N-000089, N-000409, N-000413"""

    def __init__(self, message="empty expression", lex_position=0):
        super().__init__(message)
        self.lex_position = lex_position


class IncompleteExpressionError(PathSelError):
    """Text ends where an operand or a closing token is still required.  # spec: N-000090, N-000091, N-000092, N-000093, N-000410, N-000413, N-000414"""

    def __init__(self, message="incomplete expression", lex_position=0):
        super().__init__(message)
        self.lex_position = lex_position


class SyntaxFailure(PathSelError):
    """Grammar-level syntax failure.  # spec: N-000094, N-000095, N-000097, N-000411, N-000413, N-000414"""

    def __init__(self, message="syntax error", lex_position=0):
        super().__init__(message)
        self.lex_position = lex_position


class TokenSyntaxFailure(SyntaxFailure):
    """Token-level syntax failure: a more specific form of SyntaxFailure.  # spec: N-000098, N-000099, N-000100, N-000412"""


class ZeroSliceStepError(PathSelError):
    """A slice whose step is 0.  # spec: N-000152, N-000153, N-000154, N-000415"""

    def __init__(self, message="slice step is zero", lex_position=None):
        super().__init__(message)
        self.lex_position = lex_position


class UnknownFunctionError(PathSelError):
    """A call names neither a built-in nor a provider function.  # spec: N-000263, N-000344, N-000416, N-000420"""


class ArityError(PathSelError):
    """A call has the wrong number of arguments.  # spec: N-000311, N-000312, N-000313, N-000345, N-000417, N-000420"""


class InvalidTypeError(PathSelError):
    """An argument is outside its accepted types.  # spec: N-000314, N-000315, N-000316, N-000317, N-000318, N-000319, N-000320, N-000347, N-000350, N-000418, N-000419, N-000420"""
