"""Built-in functions, the provider class, and the call checks.

A function call is checked in this order: name, argument count, then each
argument's type. Arguments are evaluated after the count check and before the
type check. Built-in names always resolve to the built-in implementation, so a
provider cannot change their behavior.  # spec: N-000264, N-000265, N-000266, N-000267, N-000339, N-000340, N-000398
"""

import decimal
import json
import math
import re
from collections.abc import Mapping

from .errors import ArityError, InvalidTypeError, UnknownFunctionError
from .values import (
    ExpressionReference,
    is_array,
    is_number,
    is_object,
    is_string,
    json_equal,
    json_type_name,
    obj_items,
)


class _Sig:
    """Internal argument specification: one predicate per parameter; the last one repeats if variadic."""

    __slots__ = ("checks", "min_args", "max_args")

    def __init__(self, checks, min_args, max_args):
        self.checks = checks
        self.min_args = min_args
        self.max_args = max_args


# Argument predicates. # spec: N-000314, N-000315, N-000316, N-000317, N-000318, N-000319, N-000320

def _any(v):
    return True


def _number(v):
    return is_number(v)


def _string(v):
    return is_string(v)


def _array(v):
    return is_array(v)


def _object(v):
    return is_object(v)


def _ref(v):
    return isinstance(v, ExpressionReference)


def _array_or_string(v):
    return is_array(v) or is_string(v)


def _array_or_string_or_object(v):
    return is_array(v) or is_string(v) or is_object(v)


def _array_of_numbers(v):
    return is_array(v) and all(is_number(x) for x in v)


def _array_of_strings(v):
    return is_array(v) and all(is_string(x) for x in v)


def _array_of_numbers_or_strings(v):
    # Every element a number, or every element a string.  # spec: N-000290, N-000291, N-000292, N-000293, N-000319
    return is_array(v) and (all(is_number(x) for x in v) or all(is_string(x) for x in v))


def _union(predicates):
    def check(v):
        return any(p(v) for p in predicates)
    return check


# Type names accepted by `signature`.  # spec: N-000402
_TYPE_NAMES = {
    "number": _number,
    "string": _string,
    "array": _array,
    "object": _object,
    "null": lambda v: v is None,
}


def _builtin(checks, variadic_min=None):
    """Mark a built-in implementation with its argument specification."""

    def decorate(func):
        if variadic_min is None:
            sig = _Sig(list(checks), len(checks), len(checks))
        else:
            sig = _Sig(list(checks), variadic_min, None)
        func.__pathsel_sig__ = sig
        return func

    return decorate


def signature(*arguments):
    """Decorator for a custom function ``_func_<name>`` on a Functions subclass.  # spec: N-000335, N-000336, N-000337, N-000394, N-000401, N-000402, N-000403, N-000404"""
    checks = []
    for arg in arguments:
        if not isinstance(arg, Mapping) or "types" not in arg:
            raise TypeError('each signature argument must be a mapping {"types": [...]}')
        names = arg["types"]
        if not isinstance(names, (list, tuple)) or not names:
            raise ValueError("a signature argument needs a non-empty list of type names")
        predicates = []
        for name in names:
            if name not in _TYPE_NAMES:
                raise ValueError("unknown type name %r; use one of %s" % (name, ", ".join(_TYPE_NAMES)))
            predicates.append(_TYPE_NAMES[name])
        checks.append(_union(predicates))

    def decorate(func):
        n = len(checks)
        func.__pathsel_sig__ = _Sig(list(checks), n, n)
        return func

    return decorate


# Numeral forms for to_number.  # spec: N-000286, N-000287, N-000288, N-000289
_INT_RE = re.compile(r"-?[0-9]+\Z")
_DEC_RE = re.compile(r"(?:-?(?:[0-9]+\.[0-9]*|\.[0-9]+)(?:[eE][+-]?[0-9]+)?|-?[0-9]+[eE][+-]?[0-9]+)\Z")


def _dumps(v):
    """Compact JSON text: no spaces, non-ASCII as \\uXXXX, numbers as the host writes them.  # spec: N-000284, N-000285"""
    if v is None:
        return "null"
    if v is True:
        return "true"
    if v is False:
        return "false"
    if isinstance(v, int):
        return str(int(v))
    if isinstance(v, float):
        return json.dumps(v)
    if isinstance(v, decimal.Decimal):
        return str(v)
    if isinstance(v, str):
        return json.dumps(v)
    if is_array(v):
        return "[" + ",".join(_dumps(x) for x in v) + "]"
    if isinstance(v, Mapping):
        return "{" + ",".join(json.dumps(str(k)) + ":" + _dumps(x) for k, x in v.items()) + "}"
    return json.dumps(str(v))


def _ordered_keys(items, ref):
    """Keys of each element from a reference. All numbers or all strings, else invalid-type.  # spec: N-000303, N-000304, N-000305, N-000306, N-000307, N-000308, N-000319, N-000320"""
    keys = [ref.apply(x) for x in items]
    if keys and not (all(is_number(k) for k in keys) or all(is_string(k) for k in keys)):
        raise InvalidTypeError("sort key must be all numbers or all strings")
    return keys


class Functions:
    """Provider of the built-in functions. Subclass it to add custom functions.  # spec: N-000393, N-000395, N-000396, N-000397"""

    @_builtin([_number])
    def _func_abs(self, n):  # spec: N-000269
        return abs(n)

    @_builtin([_array_of_numbers])
    def _func_avg(self, values):  # spec: N-000270, N-000271
        if not values:
            return None
        return sum(values) / len(values)

    @_builtin([_number])
    def _func_ceil(self, n):  # spec: N-000272
        return math.ceil(n)

    @_builtin([_number])
    def _func_floor(self, n):  # spec: N-000273
        return math.floor(n)

    @_builtin([_array_or_string, _any])
    def _func_contains(self, haystack, needle):  # spec: N-000274, N-000275
        if is_array(haystack):
            return any(json_equal(x, needle) for x in haystack)
        if not is_string(needle):
            raise InvalidTypeError("contains on a string needs a string")
        return needle in haystack

    @_builtin([_string, _string])
    def _func_ends_with(self, text, suffix):  # spec: N-000276
        return text.endswith(suffix)

    @_builtin([_string, _string])
    def _func_starts_with(self, text, prefix):  # spec: N-000276
        return text.startswith(prefix)

    @_builtin([_array_or_string_or_object])
    def _func_length(self, value):  # spec: N-000277
        # Number of Unicode characters of a string, not bytes.  # spec: N-000277, N-000035
        return len(value)

    @_builtin([_array_or_string])
    def _func_reverse(self, value):  # spec: N-000278
        if is_string(value):
            return value[::-1]
        return list(reversed(value))

    @_builtin([_string, _array_of_strings])
    def _func_join(self, sep, values):  # spec: N-000279, N-000280
        # The empty array yields the empty string (see NOTES.md; N-000268 says null).
        return sep.join(values)

    @_builtin([_object])
    def _func_keys(self, obj):  # spec: N-000281
        return [k for k, _ in obj_items(obj)]

    @_builtin([_object])
    def _func_values(self, obj):  # spec: N-000281
        return [v for _, v in obj_items(obj)]

    @_builtin([_any])
    def _func_type(self, value):  # spec: N-000282
        return json_type_name(value)

    @_builtin([_any])
    def _func_to_array(self, value):  # spec: N-000283
        if is_array(value):
            return value
        return [value]

    @_builtin([_any])
    def _func_to_string(self, value):  # spec: N-000284, N-000285
        if is_string(value):
            return value
        return _dumps(value)

    @_builtin([_any])
    def _func_to_number(self, value):  # spec: N-000286, N-000287, N-000288, N-000289
        if is_number(value):
            return value
        if is_string(value):
            if _INT_RE.match(value):
                return int(value)
            if _DEC_RE.match(value):
                return float(value)
        return None

    @_builtin([_array_of_numbers_or_strings])
    def _func_max(self, values):  # spec: N-000290, N-000292
        return max(values) if values else None

    @_builtin([_array_of_numbers_or_strings])
    def _func_min(self, values):  # spec: N-000291, N-000292
        return min(values) if values else None

    @_builtin([_array_of_numbers_or_strings])
    def _func_sort(self, values):  # spec: N-000293
        return sorted(values)

    @_builtin([_array_of_numbers])
    def _func_sum(self, values):  # spec: N-000294
        return sum(values)

    @_builtin([_object], variadic_min=1)
    def _func_merge(self, *objects):  # spec: N-000295, N-000296, N-000297
        merged = {}
        for obj in objects:
            for k, v in obj_items(obj):
                merged[k] = v
        return merged

    @_builtin([_any], variadic_min=1)
    def _func_not_null(self, *values):  # spec: N-000298, N-000299, N-000300
        # An empty string or empty array is not null.  # spec: N-000300, N-000015
        for v in values:
            if v is not None:
                return v
        return None

    @_builtin([_ref, _array])
    def _func_map(self, ref, values):  # spec: N-000301, N-000302
        return [ref.apply(x) for x in values]

    @_builtin([_array, _ref])
    def _func_sort_by(self, values, ref):  # spec: N-000303, N-000304, N-000305
        if not values:
            return []
        keys = _ordered_keys(values, ref)
        order = sorted(range(len(values)), key=lambda i: keys[i])  # stable
        return [values[i] for i in order]

    @_builtin([_array, _ref])
    def _func_max_by(self, values, ref):  # spec: N-000306, N-000308
        if not values:
            return None
        keys = _ordered_keys(values, ref)
        best = 0
        for i in range(1, len(values)):
            if keys[i] > keys[best]:
                best = i
        return values[best]

    @_builtin([_array, _ref])
    def _func_min_by(self, values, ref):  # spec: N-000307, N-000308
        if not values:
            return None
        keys = _ordered_keys(values, ref)
        best = 0
        for i in range(1, len(values)):
            if keys[i] < keys[best]:
                best = i
        return values[best]


# Built-in names and implementations, taken from the class above.
_BUILTINS = {}
for _attr, _value in list(vars(Functions).items()):
    if _attr.startswith("_func_") and hasattr(_value, "__pathsel_sig__"):
        _BUILTINS[_attr[len("_func_"):]] = _value
del _attr, _value

_DEFAULT_PROVIDER = Functions()  # spec: N-000400, N-000395


def resolve(name, provider):
    """Find a function by name: returns (signature, implementation, self-argument).  # spec: N-000263, N-000344, N-000343"""
    if name in _BUILTINS:
        impl = _BUILTINS[name]
        return impl.__pathsel_sig__, impl, provider if provider is not None else _DEFAULT_PROVIDER
    if provider is None:
        raise UnknownFunctionError("unknown function %r" % name)
    impl = getattr(type(provider), "_func_" + name, None)
    if impl is None or not hasattr(impl, "__pathsel_sig__"):
        raise UnknownFunctionError("unknown function %r" % name)
    return impl.__pathsel_sig__, impl, provider


def invoke(ctx, name, arg_nodes, value):
    """Call a function from the current value; checks name, count, then types.  # spec: N-000264, N-000265, N-000266, N-000336, N-000337, N-000338, N-000345, N-000346, N-000347, N-000348, N-000349, N-000350, N-000399, N-000397, N-000398"""
    sig, impl, owner = resolve(name, ctx.provider)
    n = len(arg_nodes)
    if n < sig.min_args or (sig.max_args is not None and n > sig.max_args):
        raise ArityError("function %r takes a different number of arguments" % name)
    args = [node.evaluate(value, ctx) for node in arg_nodes]
    for idx, arg in enumerate(args):
        check = sig.checks[min(idx, len(sig.checks) - 1)]
        if not check(arg):
            raise InvalidTypeError("argument %d of %r has an invalid type" % (idx + 1, name))
    return impl(owner, *args)
