"""pathsel: evaluate PathSel expressions against ordinary Python data.

Public names on the package root: ``search``, ``compile``, and the failure
types in ``pathsel.errors``. ``compile`` is the published name even though it
shadows the host builtin of the same spelling inside this module.
# spec: N-000372, N-000373, N-000374, N-000367, N-000369, N-000370, N-000371
"""

from .errors import (
    ArityError,
    EmptyExpressionError,
    IncompleteExpressionError,
    InvalidTypeError,
    PathSelError,
    SyntaxFailure,
    TokenSyntaxFailure,
    UnknownFunctionError,
    ZeroSliceStepError,
)
from .functions import Functions, signature
from .parser import parse as _parse
from .values import Context, ExpressionReference

# Package-level scope and surface.  # spec: N-000010, N-000011, N-000012, N-000013, N-000038, N-000039, N-000043, N-000044, N-000045, N-000046, N-000047, N-000048, N-000049
# Not implemented, by scope: a JSON decoder/encoder and a command-line program (N-000067, N-000068, N-000071, N-000072, N-000366, N-000368 are met by their absence).

__all__ = [
    "search",
    "compile",
    "ParsedExpression",
    "Functions",
    "signature",
    "ExpressionReference",
    "PathSelError",
    "EmptyExpressionError",
    "IncompleteExpressionError",
    "SyntaxFailure",
    "TokenSyntaxFailure",
    "ZeroSliceStepError",
    "UnknownFunctionError",
    "ArityError",
    "InvalidTypeError",
]


def _context(options):
    """Build the per-search context from an options object (any object with the two attributes).

    Options add a mapping type and a provider; both are optional. A bare options object is read by attribute and
    no options class is published.  # spec: N-000008, N-000009, N-000323, N-000324, N-000325, N-000326, N-000327, N-000332, N-000333, N-000341, N-000392, N-000389, N-000390, N-000391
    """
    if options is None:
        return Context(None, None)
    dict_cls = getattr(options, "dict_cls", None)
    provider = getattr(options, "custom_functions", None)
    return Context(dict_cls, provider)


class ParsedExpression:
    """A parsed expression; search it against any number of documents.  # spec: N-000078, N-000079, N-000384, N-000385, N-000386, N-000387, N-000388"""

    __slots__ = ("_tree", "_text")

    def __init__(self, tree, text):
        self._tree = tree
        self._text = text

    def search(self, value, options=None):  # spec: N-000066, N-000342, N-000387, N-000388
        return self._tree.evaluate(value, _context(options))

    def __repr__(self):
        return "ParsedExpression(%r)" % (self._text,)


def compile(expression):  # noqa: A001 - published name  # spec: N-000073, N-000075, N-000076, N-000086, N-000343, N-000383
    """Parse an expression once. Raises a PathSel refusal on failure."""
    return ParsedExpression(_parse(expression), expression)


def search(expression, data, options=None):  # spec: N-000073, N-000074, N-000080, N-000081, N-000082, N-000375, N-000376, N-000377, N-000378, N-000379, N-000380, N-000381, N-000382
    """Evaluate an expression against data in one shot.  # spec: N-000001, N-000002, N-000003, N-000004, N-000005, N-000006, N-000007, N-000040, N-000041, N-000042, N-000049, N-000066"""
    return compile(expression).search(data, options)
