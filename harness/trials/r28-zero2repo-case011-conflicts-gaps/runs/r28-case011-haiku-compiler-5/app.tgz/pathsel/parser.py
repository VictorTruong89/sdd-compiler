"""Pratt parser for PathSel expressions.

Binding powers (loosest to tightest): pipe 1, || 2, && 3, comparators 5,
flatten 9, list/object wildcard 20, filter 21, dot 40, ! 45, { 50, [ 55, ( 60.
Projection right-hand sides stop at tokens whose binding power is below 10.
This reproduces the reach rules of FP-04 and the operator binding of FP-06.
# spec: N-000185, N-000186, N-000187, N-000188, N-000189, N-000190, N-000191, N-000192, N-000193, N-000194, N-000195, N-000196, N-000197, N-000253, N-000254, N-000255, N-000256, N-000257
"""

from . import lexer as L
from .errors import (
    EmptyExpressionError,
    IncompleteExpressionError,
    SyntaxFailure,
)
from .nodes import (
    And,
    Compare,
    ExpRefNode,
    Field,
    Flatten,
    Function,
    FilterNode,
    Identity,
    Index,
    Literal,
    MultiHash,
    MultiList,
    Not,
    Or,
    Pipe,
    Projection,
    Slice,
    Subexpression,
    ValueProjection,
)

# Binding power of each token type.  # spec: N-000253, N-000254, N-000255, N-000256
_LBP = {
    L.EOF: 0, L.ERROR: 0, L.IDENT: 0, L.QIDENT: 0, L.NUMBER: 0, L.LITERAL: 0,
    L.CURRENT: 0, L.EXPREF: 0, L.RBRACKET: 0, L.RPAREN: 0, L.RBRACE: 0,
    L.COMMA: 0, L.COLON: 0,
    L.PIPE: 1, L.OR: 2, L.AND: 3,
    L.EQ: 5, L.NE: 5, L.LT: 5, L.LTE: 5, L.GT: 5, L.GTE: 5,
    L.FLATTEN: 9, L.STAR: 20, L.FILTER: 21, L.DOT: 40, L.NOT: 45,
    L.LBRACE: 50, L.LBRACKET: 55, L.LPAREN: 60,
}

_PROJECTION_STOP = 10
_STAR_BP = 20
_FLATTEN_BP = 9
_FILTER_BP = 21
_DOT_BP = 40
_NOT_BP = 45


class _Parser:
    def __init__(self, text):
        self._text_len = len(text)
        self._toks = L.tokenize(text)
        self._i = 0

    # -- token access -------------------------------------------------------

    @property
    def cur(self):
        tok = self._toks[self._i]
        if tok.type == L.ERROR:
            raise tok.error
        return tok

    def _peek(self):
        idx = min(self._i + 1, len(self._toks) - 1)
        tok = self._toks[idx]
        if tok.type == L.ERROR:
            raise tok.error
        return tok

    def advance(self):
        if self._toks[self._i].type != L.EOF:
            self._i += 1

    # -- failures -------------------------------------------------------------

    def _unexpected(self, tok):
        """A token that does not fit here. End of text means the expression is incomplete.  # spec: N-000090, N-000091, N-000092, N-000093, N-000102, N-000103, N-000104, N-000240, N-000241"""
        if tok.type == L.EOF:
            return IncompleteExpressionError("expression is incomplete", lex_position=tok.pos)
        return SyntaxFailure("unexpected token at offset %d" % tok.pos, lex_position=tok.pos)

    def _syntax(self, tok):
        return SyntaxFailure("syntax error at offset %d" % tok.pos, lex_position=tok.pos)

    def _expect(self, token_type):
        tok = self.cur
        if tok.type != token_type:
            raise self._unexpected(tok)
        self.advance()
        return tok

    # -- Pratt core -----------------------------------------------------------

    def expression(self, rbp=0):
        left = self._nud()
        while rbp < _LBP[self.cur.type]:
            left = self._led(left)
        return left

    def _nud(self):
        tok = self.cur
        t = tok.type
        if t == L.EOF:
            raise self._unexpected(tok)
        if t == L.IDENT:
            self.advance()
            if self.cur.type == L.LPAREN:
                self.advance()
                return Function(tok.value, self._function_args())
            return Field(tok.value)
        if t == L.QIDENT:
            self.advance()
            return Field(tok.value)
        if t == L.LITERAL:
            self.advance()
            return Literal(tok.value)
        if t == L.CURRENT:
            self.advance()
            return Identity()
        if t == L.EXPREF:
            self.advance()
            return ExpRefNode(self.expression(0))
        if t == L.NOT:
            self.advance()
            return Not(self.expression(_NOT_BP))
        if t == L.STAR:
            self.advance()
            return ValueProjection(Identity(), self._projection_rhs(_STAR_BP))
        if t == L.FLATTEN:
            self.advance()
            return Projection(Flatten(Identity()), self._projection_rhs(_FLATTEN_BP))
        if t == L.FILTER:
            self.advance()
            predicate = self.expression(0)
            self._expect(L.RBRACKET)
            return Projection(FilterNode(Identity(), predicate), self._projection_rhs(_FILTER_BP))
        if t == L.LBRACKET:
            self.advance()
            return self._bracket_nud()
        if t == L.LBRACE:
            self.advance()
            return self._multi_hash()
        if t == L.LPAREN:
            self.advance()
            inner = self.expression(0)
            self._expect(L.RPAREN)
            return inner
        # Numbers, closing tokens, dots, binary operators: no operand can begin here.
        raise self._syntax(tok)

    def _led(self, left):
        tok = self.cur
        t = tok.type
        if t == L.DOT:
            self.advance()
            return Subexpression(left, self._dot_rhs(_DOT_BP))
        if t == L.LBRACKET:  # spec: N-000198, N-000155
            self.advance()
            inner = self.cur
            if inner.type in (L.NUMBER, L.COLON):
                return self._index_or_slice(left)
            if inner.type == L.STAR:
                self.advance()
                self._expect(L.RBRACKET)
                return Projection(left, self._projection_rhs(_STAR_BP))
            raise self._unexpected(inner)
        if t == L.FLATTEN:
            self.advance()
            return Projection(Flatten(left), self._projection_rhs(_FLATTEN_BP))
        if t == L.FILTER:
            self.advance()
            predicate = self.expression(0)
            self._expect(L.RBRACKET)
            return Projection(FilterNode(left, predicate), self._projection_rhs(_FILTER_BP))
        if t == L.STAR:
            self.advance()
            return ValueProjection(left, self._projection_rhs(_STAR_BP))
        if t == L.PIPE:  # spec: N-000219, N-000220, N-000221, N-000222, N-000241
            self.advance()
            return Pipe(left, self.expression(1))
        if t == L.OR:
            self.advance()
            return Or(left, self.expression(2))
        if t == L.AND:  # spec: N-000261, N-000248, N-000250
            self.advance()
            return And(left, self.expression(3))
        if t in L.COMPARATORS:
            self.advance()
            return Compare(L.COMPARATORS[t], left, self.expression(5))
        raise self._syntax(tok)

    # -- brackets ---------------------------------------------------------------

    def _bracket_nud(self):
        """After a leading '[': index, slice, list wildcard, or multiselect list."""
        inner = self.cur
        if inner.type in (L.NUMBER, L.COLON):
            return self._index_or_slice(Identity())
        if inner.type == L.STAR:
            self.advance()
            self._expect(L.RBRACKET)
            return Projection(Identity(), self._projection_rhs(_STAR_BP))
        return self._multi_list()

    def _index_or_slice(self, left):
        """Parse the body of an index or slice after '[' and the first token, through ']'.

        A slice is a projection over the selected elements.  # spec: N-000126, N-000130, N-000155, N-000156
        """
        parts = [None, None, None]
        k = 0
        is_slice = False
        tok = self.cur
        if tok.type == L.NUMBER:
            parts[0] = tok.value
            self.advance()
            tok = self.cur
        while tok.type == L.COLON:
            is_slice = True
            k += 1
            if k > 2:
                raise self._syntax(tok)
            self.advance()
            tok = self.cur
            if tok.type == L.NUMBER:
                parts[k] = tok.value
                self.advance()
                tok = self.cur
        if tok.type != L.RBRACKET:
            raise self._unexpected(tok)
        self.advance()
        if not is_slice:
            return Index(left, parts[0])
        return Projection(Slice(left, parts[0], parts[1], parts[2]), self._projection_rhs(_STAR_BP))

    def _multi_list(self):
        """After '[': comma-separated expressions through ']'.  # spec: N-000211, N-000212, N-000240"""
        items = []
        while True:
            items.append(self.expression(0))
            tok = self.cur
            if tok.type == L.COMMA:
                self.advance()
                continue
            if tok.type == L.RBRACKET:  # spec: N-000213, N-000214, N-000218, N-000240
                self.advance()
                return MultiList(items)
            raise self._unexpected(tok)

    def _multi_hash(self):
        """After '{': key: expression pairs through '}'.  # spec: N-000206, N-000207, N-000208, N-000240"""
        pairs = []
        while True:
            tok = self.cur
            if tok.type not in (L.IDENT, L.QIDENT):
                raise self._unexpected(tok)
            self.advance()
            self._expect(L.COLON)
            pairs.append((tok.value, self.expression(0)))
            tok = self.cur
            if tok.type == L.COMMA:
                self.advance()
                continue
            if tok.type == L.RBRACE:
                self.advance()
                return MultiHash(pairs)
            raise self._unexpected(tok)

    def _function_args(self):
        """After '(': comma-separated arguments through ')'.  # spec: N-000262"""
        args = []
        if self.cur.type == L.RPAREN:
            self.advance()
            return args
        while True:
            args.append(self.expression(0))
            tok = self.cur
            if tok.type == L.COMMA:
                self.advance()
                continue
            if tok.type == L.RPAREN:
                self.advance()
                return args
            raise self._unexpected(tok)

    # -- projection right-hand sides ---------------------------------------------

    def _projection_rhs(self, bp):
        """Right-hand side of a projection. An empty right-hand side is the identity.  # spec: N-000182, N-000183, N-000184, N-000191, N-000192, N-000193, N-000194, N-000200, N-000201, N-000203"""
        tok = self.cur
        if _LBP[tok.type] < _PROJECTION_STOP:
            return Identity()
        if tok.type in (L.LBRACKET, L.FILTER):
            return self.expression(bp)
        if tok.type == L.DOT:
            self.advance()
            return self._dot_rhs(bp)
        raise self._syntax(tok)

    def _continue_after_multi(self, node, bp):
        """A multiselect after a dot keeps taking later steps that rank tighter than bp (N-000199: chosen, joins)."""
        while bp < _LBP[self.cur.type]:
            node = self._led(node)
        return node

    def _dot_rhs(self, bp):
        """Right-hand side of a dot. Later steps join it when they rank tighter (N-000199: multiselect after a dot may take later steps).  # spec: N-000123, N-000199, N-000213, N-000214, N-000215, N-000216, N-000217"""
        tok = self.cur
        if tok.type in (L.IDENT, L.QIDENT, L.STAR):
            return self.expression(bp)
        if tok.type == L.LBRACKET:
            self.advance()
            return self._continue_after_multi(self._multi_list(), bp)
        if tok.type == L.LBRACE:
            self.advance()
            return self._continue_after_multi(self._multi_hash(), bp)
        # A dot must be followed by a selector; end of text here is a syntax failure.  # spec: N-000118, N-000123, N-000183
        raise self._syntax(tok)


def parse(text):
    """Parse expression text into an expression tree. Raises a PathSel refusal on failure."""
    if len(text) == 0:
        raise EmptyExpressionError("empty expression", lex_position=0)
    parser = _Parser(text)
    tree = parser.expression(0)
    tok = parser.cur
    if tok.type != L.EOF:
        raise parser._syntax(tok)
    return tree
