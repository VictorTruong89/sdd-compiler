"""Value model helpers shared by the evaluator and the built-in functions."""

import decimal
from collections.abc import Mapping

# Host decimal values count as numbers.  # spec: N-000024, N-000056, N-000058
_NUMBER_TYPES = (int, float, decimal.Decimal)

# Terminology and value model (the definitions in spec pack 02 are realised here, in the evaluator and the built-ins).
# spec: N-000014, N-000015, N-000016, N-000017, N-000018, N-000019, N-000020, N-000021, N-000022, N-000023, N-000025, N-000026, N-000027, N-000028, N-000029, N-000030, N-000031, N-000032, N-000033, N-000034, N-000035, N-000036, N-000037, N-000056, N-000057, N-000058, N-000059, N-000060, N-000061, N-000062


def is_bool(v):
    return isinstance(v, bool)


def is_number(v):
    # A boolean is not a number.  # spec: N-000026
    return isinstance(v, _NUMBER_TYPES) and not isinstance(v, bool)


def is_string(v):
    return isinstance(v, str)


def is_array(v):
    return isinstance(v, (list, tuple))


def is_object(v, dict_cls=None):
    # Constructed hashes (multiselect hash) are objects whatever the supplied type.
    # # spec: N-000330, N-000331, N-000334
    if isinstance(v, Mapping):
        return True
    return dict_cls is not None and type(v) is dict_cls


def obj_get(obj, key):
    """Field lookup on an object; a missing key is null.  # spec: N-000083, N-000084, N-000125, N-000059, N-000060"""
    if isinstance(obj, Mapping):
        return obj.get(key)
    try:
        return obj[key]
    except KeyError:
        return None


def obj_values(obj):
    return list(obj.values())


def obj_items(obj):
    return list(obj.items())


def is_false(v, dict_cls=None):
    """The false-value set: false, null, empty string, empty array, empty object.  # spec: N-000022, N-000251, N-000252, N-000179"""
    if v is None or v is False:
        return True
    if isinstance(v, str):
        return len(v) == 0
    if is_array(v) or is_object(v, dict_cls):
        try:
            return len(v) == 0
        except TypeError:
            return False
    return False


def json_equal(a, b):
    """JSON value equality: deep for arrays and objects; a number is never equal to a boolean.  # spec: N-000242, N-000243, N-000244"""
    if is_bool(a) or is_bool(b):
        return is_bool(a) and is_bool(b) and a == b
    if is_number(a) and is_number(b):
        return a == b
    if a is None or b is None:
        return a is None and b is None
    if isinstance(a, str) or isinstance(b, str):
        return isinstance(a, str) and isinstance(b, str) and a == b
    if is_array(a) and is_array(b):
        return len(a) == len(b) and all(json_equal(x, y) for x, y in zip(a, b))
    if isinstance(a, Mapping) and isinstance(b, Mapping):
        if set(a.keys()) != set(b.keys()):
            return False
        return all(json_equal(a[k], b[k]) for k in a.keys())
    try:
        return bool(a == b)
    except Exception:  # pragma: no cover - host values with odd __eq__
        return False


def json_type_name(v, dict_cls=None):
    """Result of type(): one of string, number, boolean, array, object, null.  # spec: N-000282"""
    if v is None:
        return "null"
    if is_bool(v):
        return "boolean"
    if is_number(v):
        return "number"
    if isinstance(v, str):
        return "string"
    if is_array(v):
        return "array"
    if is_object(v, dict_cls):
        return "object"
    # Not stated for host values outside the JSON types; chosen: "null".
    return "null"


class ExpressionReference:
    """A deferred subexpression (``&expr``). Functions apply it to elements.  # spec: N-000231, N-000232, N-000233, N-000234, N-000235, N-000236, N-000423"""

    __slots__ = ("_node", "_ctx")

    def __init__(self, node, ctx):
        self._node = node
        self._ctx = ctx

    def apply(self, value):
        return self._node.evaluate(value, self._ctx)

    def __repr__(self):
        return "<pathsel.ExpressionReference>"


class Context:
    """Per-search settings taken from the evaluation options.  # spec: N-000389, N-000390, N-000391"""

    __slots__ = ("dict_cls", "provider")

    def __init__(self, dict_cls, provider):
        self.dict_cls = dict_cls
        self.provider = provider

    def make_hash(self):
        return self.dict_cls() if self.dict_cls is not None else {}
