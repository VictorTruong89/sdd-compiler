"""Expression tree and its evaluation.  # spec: N-000069, N-000070

Each node evaluates against a current value and a Context (evaluation options).
Projections are built from a base node, a right-hand node applied to each
element, and a rule that drops null results.  # spec: N-000143, N-000144, N-000158, N-000204, N-000205
"""

import copy

from .errors import ZeroSliceStepError
from .values import (
    ExpressionReference,
    is_array,
    is_false,
    is_number,
    is_object,
    json_equal,
    obj_get,
    obj_values,
)


class Node:
    __slots__ = ()

    def evaluate(self, value, ctx):  # pragma: no cover - interface
        raise NotImplementedError


class Identity(Node):
    """The current value, written ``@`` or implied at the start of an expression.  # spec: N-000222, N-000151"""

    __slots__ = ()

    def evaluate(self, value, ctx):
        return value


class Literal(Node):
    """A JSON literal or raw string literal: the same value whatever the document.  # spec: N-000223, N-000227, N-000228"""

    __slots__ = ("value",)

    def __init__(self, value):
        self.value = value

    def evaluate(self, value, ctx):
        if isinstance(self.value, (list, dict)):
            return copy.deepcopy(self.value)
        return self.value


class Field(Node):
    """An identifier: the field of the current object; anything else is null.  # spec: N-000057, N-000077, N-000083, N-000084, N-000085, N-000107, N-000110, N-000115, N-000116, N-000125"""

    __slots__ = ("name",)

    def __init__(self, name):
        self.name = name

    def evaluate(self, value, ctx):
        if is_object(value, ctx.dict_cls):
            return obj_get(value, self.name)
        return None


class Subexpression(Node):
    """``left.right``: the right side is evaluated against the value of the left side.  # spec: N-000108, N-000226"""

    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, ctx):
        return self.right.evaluate(self.left.evaluate(value, ctx), ctx)


class Index(Node):
    """``left[n]``; negative counts from the end; out of range or not an array is null.  # spec: N-000126, N-000127, N-000128, N-000129"""

    __slots__ = ("left", "index")

    def __init__(self, left, index):
        self.left = left
        self.index = index

    def evaluate(self, value, ctx):
        base = self.left.evaluate(value, ctx)
        if not is_array(base):
            return None
        n = len(base)
        i = self.index + n if self.index < 0 else self.index
        if 0 <= i < n:
            return base[i]
        return None


def slice_indices(n, start, stop, step):
    """Index sequence chosen by a slice over an array of length n.  # spec: N-000130, N-000131, N-000134, N-000135, N-000136, N-000137, N-000138, N-000139, N-000140, N-000141"""
    if step > 0:
        s = 0 if start is None else (start + n if start < 0 else start)
        e = n if stop is None else (stop + n if stop < 0 else stop)
        s = min(max(s, 0), n)
        e = min(max(e, 0), n)
    else:
        s = n - 1 if start is None else (start + n if start < 0 else start)
        e = -1 if stop is None else (stop + n if stop < 0 else stop)
        s = min(max(s, -1), n - 1)
        e = min(max(e, -1), n - 1)
    return range(s, e, step)


class Slice(Node):
    """``left[start:stop:step]``: a new array; a non-array is null; step 0 is refused.  # spec: N-000130, N-000131, N-000132, N-000133, N-000141, N-000142, N-000152, N-000153, N-000154, N-000156, N-000157"""

    __slots__ = ("left", "start", "stop", "step")

    def __init__(self, left, start, stop, step):
        self.left = left
        self.start = start
        self.stop = stop
        self.step = 1 if step is None else step

    def evaluate(self, value, ctx):
        if self.step == 0:
            raise ZeroSliceStepError("slice step is zero")
        base = self.left.evaluate(value, ctx)
        if not is_array(base):
            return None
        return [base[i] for i in slice_indices(len(base), self.start, self.stop, self.step)]


class Flatten(Node):
    """``left[]``: splice one level of nested arrays; a non-array is null.  # spec: N-000145, N-000146, N-000147, N-000148, N-000149, N-000150"""

    __slots__ = ("left",)

    def __init__(self, left):
        self.left = left

    def evaluate(self, value, ctx):
        base = self.left.evaluate(value, ctx)
        if not is_array(base):
            return None
        out = []
        for item in base:
            if is_array(item):
                out.extend(item)
            else:
                out.append(item)
        return out


class FilterNode(Node):
    """``left[?predicate]``: keep elements whose predicate is a true value; a non-array is null.  # spec: N-000168, N-000169, N-000170, N-000171, N-000172, N-000173, N-000174, N-000175, N-000176, N-000177, N-000178, N-000179, N-000180, N-000181, N-000202, N-000258, N-000259"""

    __slots__ = ("left", "predicate")

    def __init__(self, left, predicate):
        self.left = left
        self.predicate = predicate

    def evaluate(self, value, ctx):
        base = self.left.evaluate(value, ctx)
        if not is_array(base):
            return None
        return [x for x in base if not is_false(self.predicate.evaluate(x, ctx), ctx.dict_cls)]


class Projection(Node):
    """Applies the right side to each element of the left array and collects non-null results.  # spec: N-000143, N-000144, N-000159, N-000160, N-000161, N-000162, N-000166, N-000167, N-000204, N-000205"""

    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, ctx):
        base = self.left.evaluate(value, ctx)
        if not is_array(base):
            return None
        out = []
        for item in base:
            result = self.right.evaluate(item, ctx)
            if result is not None:
                out.append(result)
        return out


class ValueProjection(Node):
    """``left.*`` or ``*``: applies the right side to each value of an object.  # spec: N-000163, N-000164, N-000165, N-000204, N-000205"""

    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, ctx):
        base = self.left.evaluate(value, ctx)
        if not is_object(base, ctx.dict_cls):
            return None
        out = []
        for item in obj_values(base):
            result = self.right.evaluate(item, ctx)
            if result is not None:
                out.append(result)
        return out


class MultiList(Node):
    """``[a, b]``: a new array, one element per expression, nulls stored.  # spec: N-000211, N-000212, N-000213, N-000214, N-000215, N-000216, N-000217, N-000218"""

    __slots__ = ("items",)

    def __init__(self, items):
        self.items = items

    def evaluate(self, value, ctx):
        if value is None:
            return None
        return [item.evaluate(value, ctx) for item in self.items]


class MultiHash(Node):
    """``{k: a}``: a new object, one entry per pair, nulls stored.  # spec: N-000206, N-000207, N-000208, N-000209, N-000210, N-000218, N-000328, N-000329"""

    __slots__ = ("pairs",)

    def __init__(self, pairs):
        self.pairs = pairs

    def evaluate(self, value, ctx):
        if value is None:
            return None
        built = ctx.make_hash()
        for key, expr in self.pairs:
            built[key] = expr.evaluate(value, ctx)
        return built


class Pipe(Node):
    """``left | right``: the right side sees the whole left result.  # spec: N-000219, N-000220, N-000221, N-000222"""

    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, ctx):
        return self.right.evaluate(self.left.evaluate(value, ctx), ctx)


class Or(Node):
    """``a || b``: the left operand if true, otherwise the right operand.  # spec: N-000247, N-000249"""

    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, ctx):
        result = self.left.evaluate(value, ctx)
        if not is_false(result, ctx.dict_cls):
            return result
        return self.right.evaluate(value, ctx)


class And(Node):
    """``a && b``: the left operand if false, otherwise the right operand.  # spec: N-000248, N-000250"""

    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def evaluate(self, value, ctx):
        result = self.left.evaluate(value, ctx)
        if is_false(result, ctx.dict_cls):
            return result
        return self.right.evaluate(value, ctx)


class Not(Node):
    """``!a``: true for a false value, false otherwise.  # spec: N-000251, N-000252"""

    __slots__ = ("operand",)

    def __init__(self, operand):
        self.operand = operand

    def evaluate(self, value, ctx):
        return is_false(self.operand.evaluate(value, ctx), ctx.dict_cls)


class Compare(Node):
    """Comparators. Ordering compares two numbers or two strings; otherwise null.  # spec: N-000242, N-000243, N-000244, N-000245, N-000246, N-000260"""

    __slots__ = ("op", "left", "right")

    def __init__(self, op, left, right):
        self.op = op
        self.left = left
        self.right = right

    def evaluate(self, value, ctx):
        a = self.left.evaluate(value, ctx)
        b = self.right.evaluate(value, ctx)
        if self.op == "==":
            return json_equal(a, b)
        if self.op == "!=":
            return not json_equal(a, b)
        both_numbers = is_number(a) and is_number(b)
        both_strings = isinstance(a, str) and isinstance(b, str)
        if not (both_numbers or both_strings):
            # Mismatched kinds do not order; chosen: null.  See NOTES.md.
            return None
        if self.op == "<":
            return a < b
        if self.op == "<=":
            return a <= b
        if self.op == ">":
            return a > b
        return a >= b


class ExpRefNode(Node):
    """``&expr``: a reference that built-in functions apply later.  # spec: N-000231, N-000232, N-000233, N-000234, N-000235, N-000236, N-000423"""

    __slots__ = ("node",)

    def __init__(self, node):
        self.node = node

    def evaluate(self, value, ctx):
        return ExpressionReference(self.node, ctx)


class Function(Node):
    """A function call. Name, then count, then types are checked when it is evaluated.  # spec: N-000262, N-000264, N-000265, N-000266, N-000267, N-000268, N-000309, N-000310, N-000321, N-000322"""

    __slots__ = ("name", "args")

    def __init__(self, name, args):
        self.name = name
        self.args = args

    def evaluate(self, value, ctx):
        # Imported here: functions depends on values, not on nodes.
        from .functions import invoke

        return invoke(ctx, self.name, self.args, value)
