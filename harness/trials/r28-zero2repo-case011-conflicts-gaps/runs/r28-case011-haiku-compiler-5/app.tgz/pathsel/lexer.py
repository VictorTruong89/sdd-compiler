"""Tokenizer for the PathSel language.

Token-level failures do not raise here. The lexer stores them as an ERROR token
at the point they occur, so the parser reports whichever failure comes first
in the text.  # spec: N-000096, N-000097, N-000098, N-000099, N-000100, N-000101, N-000237, N-000260
"""

import json
import re
import string

from .errors import TokenSyntaxFailure

# Spaces, tabs, line feeds and carriage returns.  # spec: N-000109, N-000109
WHITESPACE = " \t\r\n"

IDENT_START = frozenset(string.ascii_letters + "_")
IDENT_CHARS = frozenset(string.ascii_letters + string.digits + "_")
DIGITS = frozenset(string.digits)
HEX = frozenset(string.hexdigits)

# Token types.
EOF = "eof"
ERROR = "error"
IDENT = "identifier"             # unquoted identifier  # spec: N-000107
QIDENT = "quoted_identifier"     # quoted identifier    # spec: N-000110
NUMBER = "number"                # integer only          # spec: N-000117
LITERAL = "literal"              # JSON literal or raw string  # spec: N-000223, N-000227
CURRENT = "current"              # @                     # spec: N-000222
EXPREF = "expref"                # &                     # spec: N-000231
AND = "and"                      # &&                    # spec: N-000247
OR = "or"                        # ||                    # spec: N-000248
PIPE = "pipe"                    # |                     # spec: N-000219
NOT = "not"                      # !                     # spec: N-000251
EQ = "eq"                        # ==                    # spec: N-000242
NE = "ne"                        # !=                    # spec: N-000242
LT = "lt"
LTE = "lte"
GT = "gt"
GTE = "gte"
DOT = "dot"
STAR = "star"
LBRACKET = "lbracket"
RBRACKET = "rbracket"
FLATTEN = "flatten"             # []  # spec: N-000145
FILTER = "filter"               # [?  # spec: N-000168
LBRACE = "lbrace"
RBRACE = "rbrace"
LPAREN = "lparen"
RPAREN = "rparen"
COMMA = "comma"
COLON = "colon"

COMPARATORS = {EQ: "==", NE: "!=", LT: "<", LTE: "<=", GT: ">", GTE: ">="}

_SINGLE = {
    ".": DOT,
    "*": STAR,
    "]": RBRACKET,
    "{": LBRACE,
    "}": RBRACE,
    "(": LPAREN,
    ")": RPAREN,
    ",": COMMA,
    ":": COLON,
    "@": CURRENT,
}


class Token:
    __slots__ = ("type", "value", "pos", "error")

    def __init__(self, type_, value, pos, error=None):
        self.type = type_
        self.value = value
        self.pos = pos
        self.error = error

    def __repr__(self):
        return "Token(%s, %r, %d)" % (self.type, self.value, self.pos)


def _token_error(message, pos):
    return TokenSyntaxFailure(message, lex_position=pos)


def _decode_raw(text, i, n):
    """Scan a raw string body starting after the opening quote.  # spec: N-000049

    Returns (value, index_after_closing_quote) or None when unterminated.
    ``\\'`` is a single quote; ``\\uXXXX`` decodes to its character.  # spec: N-000227, N-000228, N-000229, N-000230, N-000238, N-000239, N-000049
    """
    out = []
    j = i
    while j < n:
        ch = text[j]
        if ch == "'":
            return "".join(out), j + 1
        if ch == "\\" and j + 1 < n and text[j + 1] == "'":
            out.append("'")
            j += 2
            continue
        if ch == "\\" and j + 1 < n and text[j + 1] == "u" and j + 6 <= n \
                and all(c in HEX for c in text[j + 2:j + 6]):
            code = int(text[j + 2:j + 6], 16)
            j += 6
            # Combine a UTF-16 surrogate pair written as two escapes.
            if 0xD800 <= code <= 0xDBFF and j + 6 <= n and text[j] == "\\" \
                    and text[j + 1] == "u" and all(c in HEX for c in text[j + 2:j + 6]):
                low = int(text[j + 2:j + 6], 16)
                if 0xDC00 <= low <= 0xDFFF:
                    code = 0x10000 + ((code - 0xD800) << 10) + (low - 0xDC00)
                    j += 6
            out.append(chr(code))
            continue
        out.append(ch)
        j += 1
    return None


def _json_literal(body):
    """Value of a backtick literal: JSON, else the content of a JSON string.

    Returns (True, value) or (False, None) when neither reading works.  # spec: N-000223, N-000224, N-000225, N-000226, N-000237
    """
    try:
        return True, json.loads(body)
    except ValueError:
        pass
    try:
        return True, json.loads('"' + body.lstrip(WHITESPACE) + '"')
    except ValueError:
        return False, None


def tokenize(text):
    tokens = []
    n = len(text)
    i = 0
    while True:
        while i < n and text[i] in WHITESPACE:
            i += 1
        if i >= n:
            tokens.append(Token(EOF, None, n))
            return tokens
        c = text[i]
        start = i

        if c in IDENT_START:
            j = i + 1
            while j < n and text[j] in IDENT_CHARS:
                j += 1
            tokens.append(Token(IDENT, text[i:j], start))
            i = j
            continue

        if c in DIGITS or (c == "-" and i + 1 < n and text[i + 1] in DIGITS):
            j = i + 1
            while j < n and text[j] in DIGITS:
                j += 1
            tokens.append(Token(NUMBER, int(text[i:j]), start))
            i = j
            continue

        if c == "-":
            # A lone hyphen begins no token.  # spec: N-000119, N-000120, N-000121, N-000122
            err = _token_error("hyphen begins no token", start)
            tokens.append(Token(ERROR, None, start, err))
            return tokens

        if c in _SINGLE:
            tokens.append(Token(_SINGLE[c], c, start))
            i += 1
            continue

        if c == "[":
            # [] is flatten and [? is a filter, with optional whitespace between tokens.  # spec: N-000145, N-000168, N-000109
            j = i + 1
            while j < n and text[j] in WHITESPACE:
                j += 1
            if j < n and text[j] == "]":
                tokens.append(Token(FLATTEN, "[]", start))
                i = j + 1
            elif j < n and text[j] == "?":
                tokens.append(Token(FILTER, "[?", start))
                i = j + 1
            else:
                tokens.append(Token(LBRACKET, "[", start))
                i += 1
            continue

        if c == "&":
            if i + 1 < n and text[i + 1] == "&":
                tokens.append(Token(AND, "&&", start))
                i += 2
            else:
                tokens.append(Token(EXPREF, "&", start))
                i += 1
            continue

        if c == "|":
            if i + 1 < n and text[i + 1] == "|":
                tokens.append(Token(OR, "||", start))
                i += 2
            else:
                tokens.append(Token(PIPE, "|", start))
                i += 1
            continue

        if c == "=":
            if i + 1 < n and text[i + 1] == "=":
                tokens.append(Token(EQ, "==", start))
                i += 2
                continue
            err = _token_error("lone '=' is not an operator", start)
            tokens.append(Token(ERROR, None, start, err))
            return tokens

        if c == "!":
            if i + 1 < n and text[i + 1] == "=":
                tokens.append(Token(NE, "!=", start))
                i += 2
            else:
                tokens.append(Token(NOT, "!", start))
                i += 1
            continue

        if c in "<>":
            if i + 1 < n and text[i + 1] == "=":
                tokens.append(Token(LTE if c == "<" else GTE, c + "=", start))
                i += 2
            else:
                tokens.append(Token(LT if c == "<" else GT, c, start))
                i += 1
            continue

        if c == '"':  # spec: N-000110, N-000111, N-000112, N-000113, N-000114, N-000124
            j = i + 1
            while j < n and text[j] != '"':
                j += 2 if text[j] == "\\" else 1
            if j >= n:
                err = _token_error("unterminated quoted identifier", start)
                tokens.append(Token(ERROR, None, start, err))
                return tokens
            try:
                value = json.loads(text[i:j + 1])
            except ValueError:
                value = None
            if not isinstance(value, str):
                err = _token_error("quoted identifier is not a legal JSON string", start)
                tokens.append(Token(ERROR, None, start, err))
                return tokens
            tokens.append(Token(QIDENT, value, start))
            i = j + 1
            continue

        if c == "'":
            scanned = _decode_raw(text, i + 1, n)
            if scanned is None:
                err = _token_error("unterminated raw string literal", start)
                tokens.append(Token(ERROR, None, start, err))
                return tokens
            value, i = scanned
            tokens.append(Token(LITERAL, value, start))
            continue

        if c == "`":
            j = text.find("`", i + 1)
            if j < 0:
                err = _token_error("unterminated JSON literal", start)
                tokens.append(Token(ERROR, None, start, err))
                return tokens
            ok, value = _json_literal(text[i + 1:j])
            if not ok:
                err = _token_error("JSON literal is not valid JSON", start)
                tokens.append(Token(ERROR, None, start, err))
                return tokens
            tokens.append(Token(LITERAL, value, start))
            i = j + 1
            continue

        err = _token_error("character %r begins no token" % c, start)
        tokens.append(Token(ERROR, None, start, err))
        return tokens
