"""Refusal types for PathSel.

Every refusal is a ``ValueError``. The kind of a refusal is carried by the
type of the raised exception:

* ``EmptyExpression``      - empty-expression kind
* ``IncompleteExpression`` - incomplete-expression kind (has ``lex_position``)
* ``SyntaxFailure``        - grammar-level syntax kind (has ``lex_position``)
* ``TokenSyntaxFailure``   - token-level syntax kind; a subclass of ``SyntaxFailure``
* ``ZeroSliceStep``        - zero-slice-step kind
* ``UnknownFunction``      - unknown-function kind
* ``InvalidArity``         - invalid-arity kind
* ``InvalidType``          - invalid-type kind
"""


class PathSelError(ValueError):
    """Common base of every refusal. Not raised directly."""

    lex_position = None


class EmptyExpression(PathSelError):
    """The expression text has zero length."""


class IncompleteExpression(PathSelError):
    """The text ends where an operand or a closing token is still required."""

    def __init__(self, message, lex_position):
        super().__init__(message)
        self.lex_position = lex_position


class SyntaxFailure(PathSelError):
    """A grammar-level syntax failure."""

    def __init__(self, message, lex_position):
        super().__init__(message)
        self.lex_position = lex_position


class TokenSyntaxFailure(SyntaxFailure):
    """A syntax failure detected while splitting the text into tokens."""


class ZeroSliceStep(PathSelError):
    """A slice was written with a step of 0."""


class UnknownFunction(PathSelError):
    """The called name is neither built in nor declared on the provider."""


class InvalidArity(PathSelError):
    """A function was called with the wrong number of arguments."""


class InvalidType(PathSelError):
    """A function argument is outside its accepted types."""
