"""Value model helpers: truthiness, equality, ordering, type tests."""

import json
from collections.abc import Mapping
from decimal import Decimal


class Ref:
    """An expression reference value: a deferred subexpression plus its context."""

    __slots__ = ("node", "ctx")

    def __init__(self, node, ctx):
        self.node = node
        self.ctx = ctx

    def __call__(self, value):
        return self.node.eval(value, self.ctx)

    def __repr__(self):
        return "<expression reference>"


def is_number(v):
    return isinstance(v, (int, float, Decimal)) and not isinstance(v, bool)


def is_array(v):
    return isinstance(v, (list, tuple))


def is_object(v):
    return isinstance(v, Mapping)


def is_false(v):
    """The false-value set: false, null, empty string, empty array, empty object."""
    if v is None:
        return True
    if isinstance(v, bool):
        return not v
    if isinstance(v, str):
        return len(v) == 0
    if is_array(v) or is_object(v):
        return len(v) == 0
    return False


def json_equal(a, b):
    """JSON value equality: booleans never equal numbers."""
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if a is None or b is None:
        return a is None and b is None
    if is_number(a) and is_number(b):
        return a == b
    if isinstance(a, str) or isinstance(b, str):
        return isinstance(a, str) and isinstance(b, str) and a == b
    if is_array(a) and is_array(b):
        return len(a) == len(b) and all(json_equal(x, y) for x, y in zip(a, b))
    if is_object(a) and is_object(b):
        if len(a) != len(b):
            return False
        for k in a:
            if k not in b or not json_equal(a[k], b[k]):
                return False
        return True
    if is_array(a) or is_array(b) or is_object(a) or is_object(b):
        return False
    try:
        return bool(a == b)
    except Exception:
        return False


def order_compare(op, a, b):
    """Ordering for two numbers or two strings; anything else yields None (null)."""
    if (is_number(a) and is_number(b)) or (isinstance(a, str) and isinstance(b, str)):
        if op == "lt":
            return a < b
        if op == "lte":
            return a <= b
        if op == "gt":
            return a > b
        return a >= b
    return None


def _plain(v):
    """Copy of v with host decimals as floats and mappings/tuples as dicts/lists."""
    if isinstance(v, Decimal):
        return float(v)
    if is_array(v):
        return [_plain(x) for x in v]
    if is_object(v):
        return {k: _plain(x) for k, x in v.items()}
    return v


def to_json_text(v):
    """Compact JSON text: no spaces, non-ASCII escaped."""
    return json.dumps(_plain(v), separators=(",", ":"), ensure_ascii=True, default=str)


def num_sum(values):
    """Sum numbers; mixed host decimals and floats are summed as floats."""
    try:
        return sum(values)
    except TypeError:
        return sum(float(x) for x in values)


def type_name(v):
    """The language name of a value's type."""
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "boolean"
    if is_number(v):
        return "number"
    if isinstance(v, str):
        return "string"
    if is_array(v):
        return "array"
    if is_object(v):
        return "object"
    # Host values outside the six JSON types are reported as objects.
    return "object"
