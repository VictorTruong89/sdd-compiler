"""Expression tree and evaluation."""

import copy

from .errors import InvalidArity, InvalidType, ZeroSliceStep
from .functions import resolve_function
from .values import (
    Ref,
    is_array,
    is_false,
    is_object,
    json_equal,
    order_compare,
)


class Context:
    """Per-search evaluation state built from the optional options object."""

    __slots__ = ("dict_cls", "provider")

    def __init__(self, dict_cls=None, provider=None):
        self.dict_cls = dict_cls
        self.provider = provider

    @classmethod
    def from_options(cls, options):
        if options is None:
            return cls()
        return cls(getattr(options, "dict_cls", None), getattr(options, "custom_functions", None))

    def new_mapping(self):
        if self.dict_cls is None:
            return {}
        return self.dict_cls()


def project(rhs, items, ctx):
    """Apply rhs to each item and collect the non-null results in order."""
    out = []
    for item in items:
        r = rhs.eval(item, ctx)
        if r is not None:
            out.append(r)
    return out


def slice_list(arr, start, stop, step):
    """Python-like slice with the PathSel rules for negative steps and clamping."""
    n = len(arr)
    if step == 0:
        raise ZeroSliceStep("slice step must not be zero")
    if step > 0:
        s = 0 if start is None else (start + n if start < 0 else start)
        e = n if stop is None else (stop + n if stop < 0 else stop)
        s = min(max(s, 0), n)
        e = min(max(e, 0), n)
    else:
        s = n - 1 if start is None else (start + n if start < 0 else start)
        e = -1 if stop is None else (stop + n if stop < 0 else stop)
        s = min(max(s, -1), n - 1)
        e = min(max(e, -1), n - 1)
    return [arr[i] for i in range(s, e, step)]


class Node:
    __slots__ = ()

    def eval(self, value, ctx):  # pragma: no cover - abstract
        raise NotImplementedError


class Identity(Node):
    __slots__ = ()

    def eval(self, value, ctx):
        return value


IDENTITY = Identity()


class Literal(Node):
    __slots__ = ("value",)

    def __init__(self, value):
        self.value = value

    def eval(self, value, ctx):
        return copy.deepcopy(self.value)


class Field(Node):
    __slots__ = ("name",)

    def __init__(self, name):
        self.name = name

    def eval(self, value, ctx):
        if is_object(value):
            return value.get(self.name)
        return None


class Subexpr(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, value, ctx):
        base = self.left.eval(value, ctx)
        if base is None:
            return None
        return self.right.eval(base, ctx)


class Index(Node):
    __slots__ = ("left", "index")

    def __init__(self, left, index):
        self.left = left
        self.index = index

    def eval(self, value, ctx):
        base = self.left.eval(value, ctx)
        if not is_array(base):
            return None
        n = len(base)
        if -n <= self.index < n:
            return base[self.index]
        return None


class Slice(Node):
    __slots__ = ("left", "start", "stop", "step", "rhs")

    def __init__(self, left, start, stop, step, rhs):
        self.left = left
        self.start = start
        self.stop = stop
        self.step = 1 if step is None else step
        self.rhs = rhs

    def eval(self, value, ctx):
        base = self.left.eval(value, ctx)
        if not is_array(base):
            return None
        selected = slice_list(base, self.start, self.stop, self.step)
        return project(self.rhs, selected, ctx)


class ListProj(Node):
    __slots__ = ("left", "rhs")

    def __init__(self, left, rhs):
        self.left = left
        self.rhs = rhs

    def eval(self, value, ctx):
        base = self.left.eval(value, ctx)
        if not is_array(base):
            return None
        return project(self.rhs, base, ctx)


class ObjProj(Node):
    __slots__ = ("left", "rhs")

    def __init__(self, left, rhs):
        self.left = left
        self.rhs = rhs

    def eval(self, value, ctx):
        base = self.left.eval(value, ctx)
        if not is_object(base):
            return None
        return project(self.rhs, list(base.values()), ctx)


class Flatten(Node):
    __slots__ = ("left", "rhs")

    def __init__(self, left, rhs):
        self.left = left
        self.rhs = rhs

    def eval(self, value, ctx):
        base = self.left.eval(value, ctx)
        if not is_array(base):
            return None
        flat = []
        for item in base:
            if is_array(item):
                flat.extend(item)
            else:
                flat.append(item)
        return project(self.rhs, flat, ctx)


class Filter(Node):
    __slots__ = ("left", "predicate", "rhs")

    def __init__(self, left, predicate, rhs):
        self.left = left
        self.predicate = predicate
        self.rhs = rhs

    def eval(self, value, ctx):
        base = self.left.eval(value, ctx)
        if not is_array(base):
            return None
        kept = [item for item in base if not is_false(self.predicate.eval(item, ctx))]
        return project(self.rhs, kept, ctx)


class MultiList(Node):
    __slots__ = ("items",)

    def __init__(self, items):
        self.items = items

    def eval(self, value, ctx):
        if value is None:
            return None
        return [item.eval(value, ctx) for item in self.items]


class MultiHash(Node):
    __slots__ = ("pairs",)

    def __init__(self, pairs):
        self.pairs = pairs

    def eval(self, value, ctx):
        if value is None:
            return None
        result = ctx.new_mapping()
        for key, node in self.pairs:
            result[key] = node.eval(value, ctx)
        return result


class Pipe(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, value, ctx):
        return self.right.eval(self.left.eval(value, ctx), ctx)


class ExprRef(Node):
    __slots__ = ("inner",)

    def __init__(self, inner):
        self.inner = inner

    def eval(self, value, ctx):
        return Ref(self.inner, ctx)


class Not(Node):
    __slots__ = ("operand",)

    def __init__(self, operand):
        self.operand = operand

    def eval(self, value, ctx):
        return is_false(self.operand.eval(value, ctx))


class Or(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, value, ctx):
        first = self.left.eval(value, ctx)
        if not is_false(first):
            return first
        return self.right.eval(value, ctx)


class And(Node):
    __slots__ = ("left", "right")

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self, value, ctx):
        first = self.left.eval(value, ctx)
        if is_false(first):
            return first
        return self.right.eval(value, ctx)


class Compare(Node):
    __slots__ = ("op", "left", "right")

    def __init__(self, op, left, right):
        self.op = op
        self.left = left
        self.right = right

    def eval(self, value, ctx):
        a = self.left.eval(value, ctx)
        b = self.right.eval(value, ctx)
        if self.op == "eq":
            return json_equal(a, b)
        if self.op == "ne":
            return not json_equal(a, b)
        return order_compare(self.op, a, b)


class Function(Node):
    __slots__ = ("name", "args")

    def __init__(self, name, args):
        self.name = name
        self.args = args

    def eval(self, value, ctx):
        target = resolve_function(self.name, ctx.provider)  # UnknownFunction
        n = len(self.args)
        if target.variadic:
            if n < len(target.params):
                raise InvalidArity("%s() takes at least %d argument(s)" % (self.name, len(target.params)))
        elif n != len(target.params):
            raise InvalidArity("%s() takes %d argument(s), got %d" % (self.name, len(target.params), n))
        values = [arg.eval(value, ctx) for arg in self.args]
        for i, v in enumerate(values):
            allowed = target.params[min(i, len(target.params) - 1)]
            if not target.accepts(v, allowed):
                raise InvalidType("argument %d of %s() has an invalid type" % (i + 1, self.name))
        return target.call(values)
