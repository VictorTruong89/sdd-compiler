"""Parser: tokens to expression tree.

Binding powers (loosest to tightest): pipe 1, or 2, and 3, comparators 5,
flatten 9, list/slice/object wildcard projection 20, filter 21, dot 40,
bracket steps (index, slice, list wildcard) 55.

A projection's right-hand side (see ``Parser.projection_rhs``) always begins
with the step written directly after the projection form. Later steps join
it only when they bind tighter than the projection.
"""

from . import nodes as N
from .errors import EmptyExpression, IncompleteExpression, SyntaxFailure, ZeroSliceStep
from .lexer import tokenize

_CMP_OPS = {"eq": "eq", "ne": "ne", "lt": "lt", "lte": "lte", "gt": "gt", "gte": "gte"}

_BP_PROJ_LIST = 20
_BP_PROJ_FLATTEN = 9
_BP_PROJ_FILTER = 21
_BP_DOT = 40
_BP_BRACKET = 55
_BP_NOT = 45


class Parser:
    def __init__(self, text):
        self.text = text
        self.toks = tokenize(text)
        self.i = 0

    # -- token access -------------------------------------------------------

    def cur(self):
        return self.toks[self.i]

    def peek_kind(self, k=1):
        j = min(self.i + k, len(self.toks) - 1)
        return self.toks[j].kind

    def advance(self):
        tok = self.toks[self.i]
        if tok.kind != "eof":
            self.i += 1
        return tok

    def fail(self, tok):
        """Refuse at tok: incomplete at end of text, otherwise a syntax failure."""
        if tok.kind == "eof":
            raise IncompleteExpression("expression is incomplete", tok.pos)
        raise SyntaxFailure("unexpected token %r at offset %d" % (tok.value, tok.pos), tok.pos)

    def expect(self, kind):
        tok = self.cur()
        if tok.kind != kind:
            self.fail(tok)
        return self.advance()

    # -- binding power ------------------------------------------------------

    def lbp(self):
        kind = self.cur().kind
        if kind == "pipe":
            return 1
        if kind == "or":
            return 2
        if kind == "and":
            return 3
        if kind in _CMP_OPS:
            return 5
        if kind == "dot":
            return _BP_DOT
        if kind == "lbracket":
            nxt = self.peek_kind()
            if nxt == "rbracket":
                return _BP_PROJ_FLATTEN
            if nxt == "question":
                return _BP_PROJ_FILTER
            return _BP_BRACKET
        return 0

    # -- entry --------------------------------------------------------------

    def parse(self):
        if self.text == "":
            raise EmptyExpression("empty expression")
        node = self.expr(0)
        tok = self.cur()
        if tok.kind != "eof":
            raise SyntaxFailure("unexpected token %r at offset %d" % (tok.value, tok.pos), tok.pos)
        return node

    def expr(self, rbp):
        left = self.nud()
        return self.loop(left, rbp)

    def loop(self, left, rbp):
        while self.lbp() > rbp:
            left = self.led(left)
        return left

    # -- prefix position ----------------------------------------------------

    def nud(self):
        tok = self.cur()
        kind = tok.kind
        if kind == "ident":
            self.advance()
            if self.cur().kind == "lparen":
                return self.function_call(tok.value)
            return N.Field(tok.value)
        if kind == "qident":
            self.advance()
            if self.cur().kind == "lparen":
                self.fail(self.cur())
            return N.Field(tok.value)
        if kind in ("raw", "literal"):
            self.advance()
            return N.Literal(tok.value)
        if kind == "current":
            self.advance()
            return N.IDENTITY
        if kind == "expref":
            self.advance()
            return N.ExprRef(self.expr(0))
        if kind == "star":
            self.advance()
            return N.ObjProj(N.IDENTITY, self.projection_rhs(_BP_PROJ_LIST))
        if kind == "lbracket":
            return self.bracket(N.IDENTITY, leading=True)
        if kind == "lbrace":
            return self.multi_hash()
        if kind == "lparen":
            self.advance()
            inner = self.expr(0)
            self.expect("rparen")
            return inner
        if kind == "not":
            self.advance()
            return N.Not(self.expr(_BP_NOT))
        self.fail(tok)

    def function_call(self, name):
        self.expect("lparen")
        args = []
        if self.cur().kind == "rparen":
            self.advance()
            return N.Function(name, args)
        while True:
            args.append(self.expr(0))
            if self.cur().kind == "comma":
                self.advance()
                continue
            break
        self.expect("rparen")
        return N.Function(name, args)

    def multi_hash(self):
        self.expect("lbrace")
        pairs = []
        while True:
            key = self.cur()
            if key.kind not in ("ident", "qident"):
                self.fail(key)
            self.advance()
            self.expect("colon")
            pairs.append((key.value, self.expr(0)))
            if self.cur().kind == "comma":
                self.advance()
                continue
            break
        self.expect("rbrace")
        return N.MultiHash(pairs)

    def is_multi_start(self):
        """At '[': true when the bracket holds a multiselect list (not a step)."""
        return self.peek_kind() not in ("rbracket", "star", "question", "number", "colon")

    # -- infix position -----------------------------------------------------

    def led(self, left):
        tok = self.cur()
        kind = tok.kind
        if kind == "dot":
            self.advance()
            nt = self.cur()
            if nt.kind == "eof":
                raise SyntaxFailure("dot at end of expression", nt.pos)
            if nt.kind == "lbracket":
                if not self.is_multi_start():
                    raise SyntaxFailure("dot before bracket step", nt.pos)
            elif nt.kind not in ("ident", "qident", "star", "lbrace"):
                raise SyntaxFailure("unexpected token after dot at offset %d" % nt.pos, nt.pos)
            rhs = self.nud()
            return N.Subexpr(left, self.loop(rhs, _BP_DOT))
        if kind == "lbracket":
            return self.bracket(left, leading=False)
        if kind == "pipe":
            self.advance()
            return N.Pipe(left, self.expr(1))
        if kind == "or":
            self.advance()
            return N.Or(left, self.expr(2))
        if kind == "and":
            self.advance()
            return N.And(left, self.expr(3))
        if kind in _CMP_OPS:
            self.advance()
            return N.Compare(_CMP_OPS[kind], left, self.expr(5))
        self.fail(tok)

    def bracket(self, left, leading):
        """Parse a bracket form. ``leading`` is true at the start of an operand."""
        self.expect("lbracket")
        tok = self.cur()
        kind = tok.kind
        if kind == "rbracket":
            self.advance()
            return N.Flatten(left, self.projection_rhs(_BP_PROJ_FLATTEN))
        if kind == "star":
            self.advance()
            self.expect("rbracket")
            return N.ListProj(left, self.projection_rhs(_BP_PROJ_LIST))
        if kind == "question":
            self.advance()
            predicate = self.expr(0)
            self.expect("rbracket")
            return N.Filter(left, predicate, self.projection_rhs(_BP_PROJ_FILTER))
        if kind in ("number", "colon"):
            return self.index_or_slice(left)
        if leading:
            items = [self.expr(0)]
            while self.cur().kind == "comma":
                self.advance()
                items.append(self.expr(0))
            self.expect("rbracket")
            return N.MultiList(items)
        self.fail(tok)

    def index_or_slice(self, left):
        parts = []
        while True:
            val = None
            if self.cur().kind == "number":
                val = self.advance().value
            parts.append(val)
            tok = self.cur()
            if tok.kind == "colon":
                if len(parts) == 3:
                    raise SyntaxFailure("slice has more than three parts", tok.pos)
                self.advance()
                continue
            break
        self.expect("rbracket")
        if len(parts) == 1:
            if parts[0] is None:
                raise SyntaxFailure("empty bracket", self.toks[self.i - 1].pos)
            return N.Index(left, parts[0])
        start, stop, step = (parts + [None, None, None])[:3]
        if step == 0:
            raise ZeroSliceStep("slice step must not be zero")
        return N.Slice(left, start, stop, step, self.projection_rhs(_BP_PROJ_LIST))

    # -- projection right-hand sides ----------------------------------------

    def projection_rhs(self, bp):
        """Parse the right-hand side of a projection that binds at ``bp``."""
        tok = self.cur()
        if tok.kind == "lbracket" and self.is_multi_start():
            left = self.nud()
        elif self.is_first_step(tok) or self.lbp() > bp:
            left = self.led(N.IDENTITY)
        else:
            return N.IDENTITY
        return self.loop(left, bp)

    def is_first_step(self, tok):
        if tok.kind == "dot":
            return True
        if tok.kind == "lbracket":
            return self.peek_kind() in ("question", "number", "colon", "star")
        return False


def parse(text):
    """Parse expression text into an expression tree (raises refusals)."""
    return Parser(text).parse()
