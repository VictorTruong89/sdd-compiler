"""Tokenizer for the PathSel language."""

import json
from collections import namedtuple

from .errors import TokenSyntaxFailure

Token = namedtuple("Token", "kind value pos")

_WS = " \t\n\r"
_DIGITS = "0123456789"
_HEX = "0123456789abcdefABCDEF"
_IDENT_START = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_"
_IDENT_CHARS = _IDENT_START + _DIGITS

_SINGLE = {
    ".": "dot",
    "*": "star",
    "[": "lbracket",
    "]": "rbracket",
    "{": "lbrace",
    "}": "rbrace",
    "(": "lparen",
    ")": "rparen",
    ",": "comma",
    ":": "colon",
    "?": "question",
    "@": "current",
    "|": "pipe",
    "&": "expref",
    "!": "not",
    "<": "lt",
    ">": "gt",
}


def _token_error(message, pos):
    return TokenSyntaxFailure(message, pos)


def _hex4(text, i):
    """Return the code point of four hex digits at text[i:i+4], or None."""
    chunk = text[i:i + 4]
    if len(chunk) == 4 and all(c in _HEX for c in chunk):
        return int(chunk, 16)
    return None


def tokenize(text):
    """Split text into tokens. The list always ends with an ``eof`` token."""
    tokens = []
    n = len(text)
    i = 0
    while i < n:
        c = text[i]
        if c in _WS:
            i += 1
            continue
        start = i

        if c in _IDENT_START:
            j = i + 1
            while j < n and text[j] in _IDENT_CHARS:
                j += 1
            tokens.append(Token("ident", text[i:j], start))
            i = j
            continue

        if c in _DIGITS or (c == "-" and i + 1 < n and text[i + 1] in _DIGITS):
            j = i + 1 if c != "-" else i + 2
            while j < n and text[j] in _DIGITS:
                j += 1
            tokens.append(Token("number", int(text[i:j]), start))
            i = j
            continue

        if c == '"':
            j = i + 1
            while True:
                if j >= n:
                    raise _token_error("unterminated quoted identifier", start)
                if text[j] == "\\":
                    j += 2
                    continue
                if text[j] == '"':
                    break
                j += 1
            raw = text[i:j + 1]
            try:
                value = json.loads(raw)
            except ValueError:
                raise _token_error("invalid quoted identifier", start)
            tokens.append(Token("qident", value, start))
            i = j + 1
            continue

        if c == "'":
            j = i + 1
            buf = []
            while True:
                if j >= n:
                    raise _token_error("unterminated raw string literal", start)
                ch = text[j]
                if ch == "\\" and text[j + 1:j + 2] == "'":
                    buf.append("'")
                    j += 2
                elif ch == "'":
                    break
                elif ch == "\\" and text[j + 1:j + 2] == "u" and _hex4(text, j + 2) is not None:
                    code = _hex4(text, j + 2)
                    j += 6
                    if (0xD800 <= code <= 0xDBFF and text[j:j + 2] == "\\u"
                            and _hex4(text, j + 2) is not None
                            and 0xDC00 <= _hex4(text, j + 2) <= 0xDFFF):
                        low = _hex4(text, j + 2)
                        code = 0x10000 + ((code - 0xD800) << 10) + (low - 0xDC00)
                        j += 6
                    buf.append(chr(code))
                else:
                    buf.append(ch)
                    j += 1
            tokens.append(Token("raw", "".join(buf), start))
            i = j + 1
            continue

        if c == "`":
            j = i + 1
            buf = []
            while True:
                if j >= n:
                    raise _token_error("unterminated JSON literal", start)
                ch = text[j]
                if ch == "\\" and text[j + 1:j + 2] == "`":
                    buf.append("`")
                    j += 2
                elif ch == "`":
                    break
                else:
                    buf.append(ch)
                    j += 1
            body = "".join(buf)
            try:
                value = json.loads(body)
            except ValueError:
                stripped = body.lstrip(_WS)
                try:
                    value = json.loads('"' + stripped + '"')
                except ValueError:
                    raise _token_error("invalid JSON literal", start)
            tokens.append(Token("literal", value, start))
            i = j + 1
            continue

        if c == "&" and text[i + 1:i + 2] == "&":
            tokens.append(Token("and", "&&", start))
            i += 2
            continue
        if c == "|" and text[i + 1:i + 2] == "|":
            tokens.append(Token("or", "||", start))
            i += 2
            continue
        if c == "=":
            if text[i + 1:i + 2] == "=":
                tokens.append(Token("eq", "==", start))
                i += 2
                continue
            raise _token_error("lone '=' is not a token", start)
        if c == "!" and text[i + 1:i + 2] == "=":
            tokens.append(Token("ne", "!=", start))
            i += 2
            continue
        if c in "<>" and text[i + 1:i + 2] == "=":
            tokens.append(Token("lte" if c == "<" else "gte", c + "=", start))
            i += 2
            continue

        if c in _SINGLE:
            tokens.append(Token(_SINGLE[c], c, start))
            i += 1
            continue

        if c == "-":
            raise _token_error("lone '-' is not a token", start)
        raise _token_error("unexpected character %r" % c, start)

    tokens.append(Token("eof", "", n))
    return tokens
