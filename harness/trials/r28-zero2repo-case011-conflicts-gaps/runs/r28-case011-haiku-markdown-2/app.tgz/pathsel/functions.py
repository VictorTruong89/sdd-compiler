"""Built-in language functions, the provider class, and the ``signature`` decorator."""

import math
import re

from .errors import InvalidType, UnknownFunction
from .values import (
    Ref,
    is_array,
    is_number,
    is_object,
    json_equal,
    num_sum,
    to_json_text,
    type_name,
)

_CUSTOM_TYPES = frozenset(["number", "string", "array", "object", "null", "boolean", "any"])
_ATTR_PARAMS = "_pathsel_params"
_ATTR_VARIADIC = "_pathsel_variadic"
_FUNC_PREFIX = "_func_"

_INT_NUMERAL = re.compile(r"[+-]?[0-9]+")
_FLOAT_NUMERAL = re.compile(r"[+-]?(?:[0-9]+\.?[0-9]*|\.[0-9]+)(?:[eE][+-]?[0-9]+)?")


def _matches(v, type_key):
    """Whether value v satisfies one type key (a name from the spec)."""
    if type_key == "any":
        return True
    if type_key == "number":
        return is_number(v)
    if type_key == "string":
        return isinstance(v, str)
    if type_key == "boolean":
        return isinstance(v, bool)
    if type_key == "array":
        return is_array(v)
    if type_key == "object":
        return is_object(v)
    if type_key == "null":
        return v is None
    if type_key == "ref":
        return isinstance(v, Ref)
    if type_key == "array_of_numbers":
        return is_array(v) and all(is_number(x) for x in v)
    if type_key == "array_of_strings":
        return is_array(v) and all(isinstance(x, str) for x in v)
    if type_key == "array_of_numbers_or_strings":
        return is_array(v) and (all(is_number(x) for x in v) or all(isinstance(x, str) for x in v))
    raise AssertionError("unknown type key %r" % (type_key,))


def _params_from_spec(arguments):
    params = []
    for arg in arguments:
        types = arg["types"]
        if isinstance(types, str):
            types = [types]
        for t in types:
            if t not in _CUSTOM_TYPES:
                raise ValueError("unknown argument type %r" % (t,))
        params.append(tuple(types))
    return tuple(params)


def signature(*arguments):
    """Declare argument types for a provider function.

    Each argument is ``{"types": [...]}``. Returns a decorator that marks the
    implementation and returns it unchanged.
    """
    params = _params_from_spec(arguments)

    def decorate(func):
        setattr(func, _ATTR_PARAMS, params)
        setattr(func, _ATTR_VARIADIC, False)
        return func

    return decorate


def _builtin(*type_keys, variadic=False):
    """Internal decorator for built-in functions (type keys include the internal ones)."""
    params = tuple((k,) if isinstance(k, str) else tuple(k) for k in type_keys)

    def decorate(func):
        setattr(func, _ATTR_PARAMS, params)
        setattr(func, _ATTR_VARIADIC, variadic)
        return func

    return decorate


class Functions:
    """Provider implementing the built-in function set.

    Subclass it and add ``_func_<name>`` methods decorated with ``signature``
    to define custom functions.
    """

    @_builtin("number")
    def _func_abs(self, n):
        return abs(n)

    @_builtin("array_of_numbers")
    def _func_avg(self, arr):
        if not arr:
            return None
        return num_sum(arr) / len(arr)

    @_builtin("number")
    def _func_ceil(self, n):
        return math.ceil(n)

    @_builtin("number")
    def _func_floor(self, n):
        return math.floor(n)

    @_builtin(("array", "string"), "any")
    def _func_contains(self, seq, x):
        if is_array(seq):
            return any(json_equal(e, x) for e in seq)
        if not isinstance(x, str):
            raise InvalidType("contains() on a string needs a string argument")
        return x in seq

    @_builtin("string", "string")
    def _func_ends_with(self, s, suffix):
        return s.endswith(suffix)

    @_builtin("string", "string")
    def _func_starts_with(self, s, prefix):
        return s.startswith(prefix)

    @_builtin(("string", "array", "object"))
    def _func_length(self, v):
        return len(v)

    @_builtin(("array", "string"))
    def _func_reverse(self, v):
        if is_array(v):
            return list(reversed(v))
        return v[::-1]

    @_builtin("string", "array_of_strings")
    def _func_join(self, sep, arr):
        if not arr:
            return None
        return sep.join(arr)

    @_builtin("object")
    def _func_keys(self, obj):
        return list(obj.keys())

    @_builtin("object")
    def _func_values(self, obj):
        return list(obj.values())

    @_builtin("any")
    def _func_type(self, v):
        return type_name(v)

    @_builtin("any")
    def _func_to_array(self, v):
        if is_array(v):
            return v
        return [v]

    @_builtin("any")
    def _func_to_string(self, v):
        if isinstance(v, str):
            return v
        return to_json_text(v)

    @_builtin("any")
    def _func_to_number(self, v):
        if is_number(v):
            return v
        if isinstance(v, str):
            if _INT_NUMERAL.fullmatch(v):
                return int(v)
            if _FLOAT_NUMERAL.fullmatch(v):
                return float(v)
        return None

    @_builtin("array_of_numbers_or_strings")
    def _func_max(self, arr):
        if not arr:
            return None
        return max(arr)

    @_builtin("array_of_numbers_or_strings")
    def _func_min(self, arr):
        if not arr:
            return None
        return min(arr)

    @_builtin("array_of_numbers_or_strings")
    def _func_sort(self, arr):
        return sorted(arr)

    @_builtin("array_of_numbers")
    def _func_sum(self, arr):
        return num_sum(arr)

    @_builtin("object", variadic=True)
    def _func_merge(self, *objs):
        result = {}
        for obj in objs:
            result.update(obj)
        return result

    @_builtin("any", variadic=True)
    def _func_not_null(self, *args):
        for a in args:
            if a is not None:
                return a
        return None

    @_builtin("ref", "array")
    def _func_map(self, ref, arr):
        return [ref(e) for e in arr]

    @_builtin("array", "ref")
    def _func_sort_by(self, arr, ref):
        keys = [ref(e) for e in arr]
        _check_keys(keys)
        order = sorted(range(len(arr)), key=lambda i: keys[i])
        return [arr[i] for i in order]

    @_builtin("array", "ref")
    def _func_max_by(self, arr, ref):
        if not arr:
            return None
        keys = [ref(e) for e in arr]
        _check_keys(keys)
        best = 0
        for i in range(1, len(arr)):
            if keys[i] > keys[best]:
                best = i
        return arr[best]

    @_builtin("array", "ref")
    def _func_min_by(self, arr, ref):
        if not arr:
            return None
        keys = [ref(e) for e in arr]
        _check_keys(keys)
        best = 0
        for i in range(1, len(arr)):
            if keys[i] < keys[best]:
                best = i
        return arr[best]


def _check_keys(keys):
    """Keys must all be numbers, or all strings."""
    if not keys:
        return
    if all(is_number(k) for k in keys):
        return
    if all(isinstance(k, str) for k in keys):
        return
    raise InvalidType("sort key must be a number for every element, or a string for every element")


class _Target:
    """A resolved function: how to check its arguments and how to call it."""

    __slots__ = ("func", "instance", "params", "variadic")

    def __init__(self, func, instance, params, variadic):
        self.func = func
        self.instance = instance
        self.params = params
        self.variadic = variadic

    def accepts(self, v, allowed):
        return any(_matches(v, t) for t in allowed)

    def call(self, args):
        if self.instance is None:
            return self.func(*args)
        return self.func(self.instance, *args)


_DEFAULT_PROVIDER = Functions()

_BUILTINS = {}
for _attr, _val in list(vars(Functions).items()):
    if _attr.startswith(_FUNC_PREFIX) and hasattr(_val, _ATTR_PARAMS):
        _BUILTINS[_attr[len(_FUNC_PREFIX):]] = _Target(
            _val, _DEFAULT_PROVIDER, getattr(_val, _ATTR_PARAMS), getattr(_val, _ATTR_VARIADIC)
        )


def resolve_function(name, provider):
    """Find a function by name: built-ins first, then the attached provider."""
    target = _BUILTINS.get(name)
    if target is not None:
        return target
    if provider is not None:
        bound = getattr(provider, _FUNC_PREFIX + name, None)
        if callable(bound) and hasattr(bound, _ATTR_PARAMS):
            return _Target(bound, None, getattr(bound, _ATTR_PARAMS), getattr(bound, _ATTR_VARIADIC))
    raise UnknownFunction("unknown function %s()" % (name,))
