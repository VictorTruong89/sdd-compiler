"""PathSel: a declarative expression language for extracting values from JSON-like data.

Public entries:

* ``search(expression, data, options=None)`` - one-shot evaluation.
* ``compile(expression)`` - parse once; the result's ``search(value, options=None)``
  evaluates the parsed expression against any number of documents.
"""

from .errors import (
    EmptyExpression,
    IncompleteExpression,
    InvalidArity,
    InvalidType,
    PathSelError,
    SyntaxFailure,
    TokenSyntaxFailure,
    UnknownFunction,
    ZeroSliceStep,
)
from .nodes import Context
from .parser import parse as _parse

__all__ = [
    "search",
    "compile",
    "ParsedExpression",
    "PathSelError",
    "EmptyExpression",
    "IncompleteExpression",
    "SyntaxFailure",
    "TokenSyntaxFailure",
    "ZeroSliceStep",
    "UnknownFunction",
    "InvalidArity",
    "InvalidType",
]


class ParsedExpression:
    """A parsed PathSel expression, reusable across documents and option sets."""

    __slots__ = ("text", "_node")

    def __init__(self, text, node):
        self.text = text
        self._node = node

    def search(self, value, options=None):
        """Evaluate against ``value``. Refusals raise a ``ValueError`` subclass."""
        return self._node.eval(value, Context.from_options(options))

    def __repr__(self):
        return "ParsedExpression(%r)" % (self.text,)


def compile(expression):
    """Parse ``expression`` and return a ``ParsedExpression``."""
    return ParsedExpression(expression, _parse(expression))


def search(expression, data, options=None):
    """Evaluate ``expression`` against ``data`` in one step."""
    return compile(expression).search(data, options)
