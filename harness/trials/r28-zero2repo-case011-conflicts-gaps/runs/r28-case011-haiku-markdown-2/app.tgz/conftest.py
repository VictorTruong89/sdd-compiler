"""Pytest root configuration.

Its presence at the project root makes pytest put this directory on sys.path,
so the flat-layout ``pathsel`` package imports without an install step.
"""
