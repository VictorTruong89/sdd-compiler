"""Behavioral tests for the pathsel library (run from the project root with pytest)."""

from collections import OrderedDict
from types import SimpleNamespace

import pytest

import pathsel
from pathsel import compile as pc
from pathsel import search
from pathsel.functions import Functions, signature

DOC = {
    "foo": {"bar": {"baz": 1}},
    "arr": [1, [2, 3], 4],
    "people": [
        {"name": "a", "age": 3},
        {"name": "b", "age": 1},
        {"name": "c", "age": 5},
    ],
}


@pytest.mark.parametrize(
    "expr, expected",
    [
        ("foo.bar.baz", 1),
        ("foo.missing.deep", None),
        ("arr[-1]", 4),
        ("arr[9]", None),
        ("arr[1:]", [[2, 3], 4]),
        ("arr[::-1]", [4, [2, 3], 1]),
        ("arr[]", [1, 2, 3, 4]),
        ("people[*].name", ["a", "b", "c"]),
        ("people[?age > `2`].name", ["a", "c"]),
        ("max_by(people, &age).name", "c"),
        ("sort_by(people, &age)[0].name", "b"),
        ("people[*].[name, age]", [["a", 3], ["b", 1], ["c", 5]]),
        ("{n: foo.bar.baz, x: `\"y\"`}", {"n": 1, "x": "y"}),
        ("[foo.bar.baz, missing]", [1, None]),
        ("`\"abc\"`", "abc"),
        ("`abc`", "abc"),
        ("'raw\\'s'", "raw's"),
        ("\"a.b\"", None),
        ("!`0`", False),
        ("`0` == `false`", False),
        ("not_null(missing, `0`, `\"x\"`)", 0),
        ("to_string(`{\"a\": 1}`)", '{"a":1}'),
        ("join(`\"-\"`, `[\"a\", \"b\"]`)", "a-b"),
        ("map(&age, people)", [3, 1, 5]),
        ("to_number(`\"12\"`)", 12),
        ("to_number(`\"x\"`)", None),
        ("length(`\"日本\"`)", 2),
        ("type(people)", "array"),
    ],
)
def test_search_results(expr, expected):
    assert search(expr, DOC) == expected


def test_projection_reach_and_pipe_stop():
    data = {"a": [{"b": [{"c": 1}, {"c": 2}]}, {"b": [{"c": 3}]}]}
    assert search("a[*].b[*].c", data) == [[1, 2], [3]]
    assert search("a[*].b | length(@)", data) == 2
    assert search("a[*].b == `1`", {"a": [{"b": 1}]}) is False


def test_compile_then_search_matches_one_shot():
    expr = "people[?age >= `3`].name"
    parsed = pc(expr)
    for doc in (DOC, {"people": []}, {}):
        assert parsed.search(doc) == search(expr, doc)


def test_missing_and_non_object_are_null():
    assert search("a.b", {"a": [1]}) is None
    assert search("a[0]", {"a": "xyz"}) is None
    assert search("a.*", {"a": 3}) is None
    assert search("a[?b]", {"a": 5}) is None


def test_empty_and_incomplete_are_distinct_kinds():
    with pytest.raises(pathsel.EmptyExpression):
        search("", {})
    with pytest.raises(pathsel.IncompleteExpression):
        search("   ", {})
    with pytest.raises(pathsel.IncompleteExpression):
        search("a.b[", {})


def test_token_error_is_subclass_of_syntax():
    with pytest.raises(pathsel.TokenSyntaxFailure) as tok:
        search("a = b", {})
    with pytest.raises(pathsel.SyntaxFailure) as grammar:
        search("a b", {})
    assert issubclass(type(tok.value), type(grammar.value))
    assert type(tok.value) is not type(grammar.value)
    assert tok.value.lex_position == 2
    assert grammar.value.lex_position == 2
    assert isinstance(tok.value, ValueError)


@pytest.mark.parametrize("expr", ["a.", ".a", "a..b", "a.5", "a*", "a[1:2:3:4]", "a[b]", "a)"])
def test_grammar_syntax_failures(expr):
    with pytest.raises(pathsel.SyntaxFailure):
        search(expr, {})


def test_zero_step_refuses_on_both_entries():
    with pytest.raises(pathsel.ZeroSliceStep):
        pc("a[::0]")
    with pytest.raises(pathsel.ZeroSliceStep):
        search("a[::0]", {"a": [1]})


def test_function_failure_kinds_are_separate_and_deferred():
    parsed = pc("nosuch(@)")  # compiling succeeds
    with pytest.raises(pathsel.UnknownFunction):
        parsed.search(1)
    with pytest.raises(pathsel.InvalidArity):
        search("abs()", {})
    with pytest.raises(pathsel.InvalidType):
        search("abs(`true`)", {})
    assert not issubclass(pathsel.InvalidType, pathsel.SyntaxFailure)


class Provider(Functions):
    @signature({"types": ["number"]}, {"types": ["number", "string"]})
    def _func_double(self, n, s):
        return [n * 2, s]

    @signature({"types": ["array"]})
    def _func_zero(self, arr):
        return 0


def test_custom_functions_and_options():
    opts = SimpleNamespace(dict_cls=OrderedDict, custom_functions=Provider())
    assert search("double(`2`, `\"x\"`)", {}, opts) == [4, "x"]
    assert search("zero(@) == `0`", [], opts) is True
    assert search("abs(`-3`)", {}, opts) == 3
    assert isinstance(search("{a: `1`}", {}, opts), OrderedDict)
    with pytest.raises(pathsel.UnknownFunction):
        search("double(`2`, `\"x\"`)", {})
    with pytest.raises(pathsel.InvalidArity):
        search("double(`2`)", {}, opts)
    with pytest.raises(pathsel.InvalidType):
        search("double(`true`, `1`)", {}, opts)
    assert pc("double(`2`, `\"x\"`)").search({}, opts) == [4, "x"]


def test_input_is_not_mutated():
    doc = {"a": [{"b": 1}, [2]]}
    search("a[].b", doc)
    search("a[*]", doc)
    assert doc == {"a": [{"b": 1}, [2]]}
