"""pathsel: a JMESPath-style JSON query library."""
from .errors import (ArityError, EmptyExpressionError, FunctionTypeError,
                     IncompleteExpressionError, LexerError, ParseError,
                     PathSelError, SliceStepError, UnknownFunctionError)
from .interpreter import Interpreter
from .parser import parse

__all__ = ["search", "compile", "ParsedExpression", "Options"]


class Options:
    def __init__(self, dict_cls=None, custom_functions=None):
        self.dict_cls = dict_cls
        self.custom_functions = custom_functions


class ParsedExpression:
    def __init__(self, expression, ast):
        self.expression = expression
        self._ast = ast

    def search(self, value, options=None):
        return Interpreter(options).visit(self._ast, value)

    def __repr__(self):
        return "ParsedExpression(%r)" % (self.expression,)


def compile(expression):
    if not isinstance(expression, str):
        raise TypeError("expression must be a str")
    return ParsedExpression(expression, parse(expression))


def search(expression, data, options=None):
    return compile(expression).search(data, options)
