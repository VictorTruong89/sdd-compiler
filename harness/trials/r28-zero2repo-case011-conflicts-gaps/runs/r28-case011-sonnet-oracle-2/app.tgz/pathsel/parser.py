from .errors import (EmptyExpressionError, IncompleteExpressionError,
                     ParseError, SliceStepError)
from .lexer import tokenize

BP = {
    "eof": 0, "unquoted": 0, "quoted": 0, "literal": 0, "rbracket": 0,
    "rparen": 0, "comma": 0, "rbrace": 0, "number": 0, "current": 0,
    "expref": 0, "colon": 0, "pipe": 1, "or": 2, "and": 3, "eq": 5, "gt": 5,
    "lt": 5, "gte": 5, "lte": 5, "ne": 5, "flatten": 9, "star": 20,
    "filter": 21, "dot": 40, "not": 45, "lbrace": 50, "lbracket": 55,
    "lparen": 60,
}
STOP = 10
COMPARATORS = ("eq", "gt", "lt", "gte", "lte", "ne")
IDENT = ("unquoted", "quoted")

IDENTITY = ("current",)


class Parser:
    def __init__(self, expr):
        self.expr = expr
        self.toks = tokenize(expr)
        self.i = 0

    def tok(self, k=0):
        j = self.i + k
        if j >= len(self.toks):
            j = len(self.toks) - 1
        return self.toks[j]

    def kind(self, k=0):
        return self.tok(k)[0]

    def advance(self):
        self.i += 1

    def err(self, t=None, force_syntax=False):
        t = t or self.tok()
        if t[0] == "eof" and not force_syntax:
            return IncompleteExpressionError(t[2])
        return ParseError(t[2], "unexpected token %r" % (t[1],))

    def match(self, kind):
        if self.kind() == kind:
            self.advance()
        else:
            raise self.err()

    def parse(self):
        if self.expr == "":
            raise EmptyExpressionError()
        node = self.expression(0)
        if self.kind() != "eof":
            raise self.err()
        return node

    def expression(self, bp=0):
        t = self.tok()
        self.advance()
        left = self.nud(t)
        while bp < BP[self.kind()]:
            t = self.tok()
            self.advance()
            left = self.led(t, left)
        return left

    # ---- prefix
    def nud(self, t):
        k = t[0]
        if k == "literal":
            return ("literal", t[1])
        if k in IDENT:
            if self.kind() == "lparen" and k == "quoted":
                raise ParseError(self.tok()[2], "quoted identifier is not a function name")
            return ("field", t[1], k)
        if k == "star":
            if self.kind() == "rbracket":
                right = IDENTITY
            else:
                right = self.proj_rhs(BP["star"])
            return ("vproj", IDENTITY, right)
        if k == "filter":
            return self.led_filter(IDENTITY)
        if k == "lbrace":
            return self.multi_hash()
        if k == "flatten":
            right = self.proj_rhs(BP["flatten"])
            return ("proj", ("flatten", IDENTITY), right)
        if k == "lbracket":
            if self.kind() in ("number", "colon"):
                right = self.index_expr()
                return self.project_if_slice(IDENTITY, right)
            if self.kind() == "star" and self.kind(1) == "rbracket":
                self.advance(); self.advance()
                return ("proj", IDENTITY, self.proj_rhs(BP["star"]))
            return self.multi_list()
        if k == "current":
            return IDENTITY
        if k == "expref":
            return ("expref", self.expression(BP["expref"]))
        if k == "not":
            return ("not", self.expression(BP["not"]))
        if k == "lparen":
            e = self.expression(0)
            self.match("rparen")
            return e
        raise self.err(t)

    # ---- infix
    def led(self, t, left):
        k = t[0]
        if k == "dot":
            if self.kind() != "star":
                return ("sub", left, self.dot_rhs(BP["dot"]))
            self.advance()
            return ("vproj", left, self.proj_rhs(BP["star"]))
        if k == "pipe":
            return ("sub", left, self.expression(BP["pipe"]))
        if k in ("or", "and"):
            return (k, left, self.expression(BP[k]))
        if k == "lparen":
            if left[0] != "field" or left[2] != "unquoted":
                raise ParseError(t[2], "invalid function name")
            args = []
            if self.kind() != "rparen":
                while True:
                    args.append(self.expression(0))
                    if self.kind() == "comma":
                        self.advance()
                    else:
                        break
            self.match("rparen")
            return ("call", left[1], args)
        if k == "filter":
            return self.led_filter(left)
        if k in COMPARATORS:
            return ("cmp", k, left, self.expression(BP[k]))
        if k == "flatten":
            return ("proj", ("flatten", left), self.proj_rhs(BP["flatten"]))
        if k == "lbracket":
            if self.kind() in ("number", "colon"):
                right = self.index_expr()
                return self.project_if_slice(left, right)
            self.match("star")
            self.match("rbracket")
            return ("proj", left, self.proj_rhs(BP["star"]))
        raise self.err(t, force_syntax=True)

    def led_filter(self, left):
        cond = self.expression(0)
        self.match("rbracket")
        right = self.proj_rhs(BP["filter"])
        return ("fproj", left, right, cond)

    def project_if_slice(self, left, right):
        node = ("sub", left, right)
        if right[0] == "slice":
            return ("proj", node, self.proj_rhs(BP["star"]))
        return node

    def index_expr(self):
        if self.kind() == "colon" or self.kind(1) == "colon":
            return self.slice()
        t = self.tok()
        self.match("number")
        self.match("rbracket")
        return ("index", t[1])

    def slice(self):
        parts = [None, None, None]
        idx = 0
        while self.kind() != "rbracket":
            k = self.kind()
            if k == "colon":
                idx += 1
                if idx == 3:
                    raise self.err()
                self.advance()
            elif k == "number":
                parts[idx] = self.tok()[1]
                self.advance()
            else:
                raise self.err()
        self.match("rbracket")
        if parts[2] == 0:
            raise SliceStepError("slice step cannot be zero")
        return ("slice",) + tuple(parts)

    def proj_rhs(self, bp):
        k = self.kind()
        if BP[k] < STOP:
            return IDENTITY
        if k == "lbracket":
            return self.expression(bp)
        if k == "filter":
            return self.expression(bp)
        if k == "dot":
            self.advance()
            return self.dot_rhs(bp)
        raise self.err(force_syntax=True)

    def dot_rhs(self, bp):
        k = self.kind()
        if k in IDENT or k == "star":
            return self.expression(bp)
        if k == "lbracket":
            self.advance()
            return self.multi_list()
        if k == "lbrace":
            self.advance()
            return self.multi_hash()
        raise self.err(force_syntax=True)

    def multi_list(self):
        exprs = []
        while True:
            exprs.append(self.expression(0))
            if self.kind() == "rbracket":
                break
            self.match("comma")
        self.match("rbracket")
        return ("mlist", exprs)

    def multi_hash(self):
        pairs = []
        while True:
            t = self.tok()
            if t[0] not in IDENT:
                raise self.err()
            self.advance()
            self.match("colon")
            pairs.append((t[1], self.expression(0)))
            if self.kind() == "comma":
                self.advance()
            elif self.kind() == "rbrace":
                break
            else:
                raise self.err()
        self.match("rbrace")
        return ("mhash", pairs)


def parse(expr):
    return Parser(expr).parse()
