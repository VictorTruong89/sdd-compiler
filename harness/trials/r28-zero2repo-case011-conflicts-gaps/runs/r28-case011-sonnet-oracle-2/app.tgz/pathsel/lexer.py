import json
import re

from .errors import LexerError

_WS = " \t\n\r"
_IDSTART = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_")
_IDCHARS = _IDSTART | set("0123456789")
_DIGITS = set("0123456789")
_SIMPLE = {".": "dot", "*": "star", ",": "comma", ":": "colon", "@": "current",
           "(": "lparen", ")": "rparen", "{": "lbrace", "}": "rbrace",
           "]": "rbracket"}
_UESC = re.compile(r"\\u([0-9a-fA-F]{4})")


def _decode_u(s):
    # spec: N-000239 \uXXXX inside a raw string is decoded
    def rep(m):
        return chr(int(m.group(1), 16))
    out = _UESC.sub(rep, s)
    try:  # join surrogate pairs
        out = out.encode("utf-16", "surrogatepass").decode("utf-16")
    except UnicodeError:
        pass
    return out


def tokenize(expr):
    """Return list of (type, value, start). Last token is eof at len(expr)."""
    toks = []
    i = 0
    n = len(expr)
    while i < n:
        c = expr[i]
        if c in _WS:
            i += 1
        elif c in _IDSTART:
            j = i + 1
            while j < n and expr[j] in _IDCHARS:
                j += 1
            toks.append(("unquoted", expr[i:j], i))
            i = j
        elif c in _SIMPLE:
            toks.append((_SIMPLE[c], c, i))
            i += 1
        elif c == "[":
            nxt = expr[i + 1] if i + 1 < n else ""
            if nxt == "?":
                toks.append(("filter", "[?", i)); i += 2
            elif nxt == "]":
                toks.append(("flatten", "[]", i)); i += 2
            else:
                toks.append(("lbracket", "[", i)); i += 1
        elif c == "|":
            if expr[i + 1:i + 2] == "|":
                toks.append(("or", "||", i)); i += 2
            else:
                toks.append(("pipe", "|", i)); i += 1
        elif c == "&":
            if expr[i + 1:i + 2] == "&":
                toks.append(("and", "&&", i)); i += 2
            else:
                toks.append(("expref", "&", i)); i += 1
        elif c == "!":
            if expr[i + 1:i + 2] == "=":
                toks.append(("ne", "!=", i)); i += 2
            else:
                toks.append(("not", "!", i)); i += 1
        elif c == "=":
            if expr[i + 1:i + 2] == "=":
                toks.append(("eq", "==", i)); i += 2
            else:
                raise LexerError(i, "unknown token '='")
        elif c == "<":
            if expr[i + 1:i + 2] == "=":
                toks.append(("lte", "<=", i)); i += 2
            else:
                toks.append(("lt", "<", i)); i += 1
        elif c == ">":
            if expr[i + 1:i + 2] == "=":
                toks.append(("gte", ">=", i)); i += 2
            else:
                toks.append(("gt", ">", i)); i += 1
        elif c in _DIGITS or (c == "-" and i + 1 < n and expr[i + 1] in _DIGITS):
            j = i + 1
            while j < n and expr[j] in _DIGITS:
                j += 1
            toks.append(("number", int(expr[i:j]), i))
            i = j
        elif c == '"':
            j = i + 1
            while j < n and expr[j] != '"':
                j += 2 if expr[j] == "\\" else 1
            if j >= n:
                raise LexerError(i, "unterminated quoted identifier")
            try:
                val = json.loads(expr[i:j + 1])
            except ValueError:
                raise LexerError(i, "invalid quoted identifier")
            toks.append(("quoted", val, i))
            i = j + 1
        elif c == "'":
            j = i + 1
            while j < n and expr[j] != "'":
                j += 2 if expr[j] == "\\" else 1
            if j >= n:
                raise LexerError(i, "unterminated raw string")
            raw = expr[i + 1:j].replace("\\'", "'")
            toks.append(("literal", _decode_u(raw), i))
            i = j + 1
        elif c == "`":
            j = i + 1
            while j < n and expr[j] != "`":
                j += 2 if expr[j] == "\\" else 1
            if j >= n:
                raise LexerError(i, "unterminated literal")
            lex = expr[i + 1:j].replace("\\`", "`")
            try:
                val = json.loads(lex)
            except ValueError:
                try:
                    val = json.loads('"%s"' % lex.lstrip())
                except ValueError:
                    raise LexerError(i, "invalid literal")
            toks.append(("literal", val, i))
            i = j + 1
        else:
            raise LexerError(i, "unknown character %r" % c)
    toks.append(("eof", "", n))
    return toks
