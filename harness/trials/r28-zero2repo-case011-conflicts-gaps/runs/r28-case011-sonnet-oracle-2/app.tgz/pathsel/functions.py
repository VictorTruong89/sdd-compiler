import functools
import json
import math
import re
from collections.abc import Mapping
from decimal import Decimal

from .errors import ArityError, FunctionTypeError, UnknownFunctionError


class ExpRef:
    """Expression reference value."""

    def __init__(self, node, visit):
        self.node = node
        self._visit = visit

    def apply(self, value):
        return self._visit(self.node, value)

    def __repr__(self):
        return "<expression reference>"


def _is_num(v):
    return isinstance(v, (int, float, Decimal)) and not isinstance(v, bool)


def _is_arr(v):
    return isinstance(v, (list, tuple))


def _is_obj(v, dict_cls=None):
    return isinstance(v, Mapping) or (dict_cls is not None and isinstance(v, dict_cls))


def _matches(name, v, dict_cls):
    if name == "any":
        return True
    if name == "number":
        return _is_num(v)
    if name == "string":
        return isinstance(v, str)
    if name == "array":
        return _is_arr(v)
    if name == "object":
        return _is_obj(v, dict_cls)
    if name == "null":
        return v is None
    if name == "boolean":
        return isinstance(v, bool)
    if name == "expref":
        return isinstance(v, ExpRef)
    if name == "array-number":
        return _is_arr(v) and all(_is_num(x) for x in v)
    if name == "array-string":
        return _is_arr(v) and all(isinstance(x, str) for x in v)
    return False


def signature(*arguments):
    # spec: N-000401..N-000404
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*a, **kw):
            return func(*a, **kw)
        wrapper.signature = list(arguments)
        return wrapper
    return decorator


def json_eq(a, b):
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if _is_num(a) and _is_num(b):
        return a == b
    if _is_arr(a) and _is_arr(b):
        return len(a) == len(b) and all(json_eq(x, y) for x, y in zip(a, b))
    if _is_obj(a) and _is_obj(b):
        if len(a) != len(b):
            return False
        for k in a:
            if k not in b or not json_eq(a[k], b[k]):
                return False
        return True
    if _is_arr(a) or _is_arr(b) or _is_obj(a) or _is_obj(b):
        return False
    try:
        return bool(a == b)
    except Exception:
        return False


def _to_json_default(o):
    if isinstance(o, Decimal):
        return float(o)
    if isinstance(o, Mapping):
        return dict(o)
    return str(o)


_INT_RE = re.compile(r"-?[0-9]+\Z")
_FLOAT_RE = re.compile(r"-?[0-9]+(\.[0-9]+)?([eE][+-]?[0-9]+)?\Z")


def _key_check(keys):
    if all(_is_num(k) for k in keys) or all(isinstance(k, str) for k in keys):
        return
    raise FunctionTypeError("sort key must be all numbers or all strings")


class Functions:
    @signature({"types": ["number"]})
    def _func_abs(self, a):
        return abs(a)

    @signature({"types": ["array-number"]})
    def _func_avg(self, a):
        if not a:
            return None
        return sum(a) / len(a)

    @signature({"types": ["number"]})
    def _func_ceil(self, a):
        return math.ceil(a)

    @signature({"types": ["number"]})
    def _func_floor(self, a):
        return math.floor(a)

    @signature({"types": ["array", "string"]}, {"types": ["any"]})
    def _func_contains(self, subject, search):
        if isinstance(subject, str):
            return isinstance(search, str) and search in subject
        return any(json_eq(x, search) for x in subject)

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_ends_with(self, s, suffix):
        return s.endswith(suffix)

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_starts_with(self, s, prefix):
        return s.startswith(prefix)

    @signature({"types": ["string", "array", "object"]})
    def _func_length(self, a):
        return len(a)

    @signature({"types": ["array", "string"]})
    def _func_reverse(self, a):
        if isinstance(a, str):
            return a[::-1]
        return list(reversed(a))

    @signature({"types": ["string"]}, {"types": ["array-string"]})
    def _func_join(self, glue, items):
        return glue.join(items)

    @signature({"types": ["object"]})
    def _func_keys(self, o):
        return list(o.keys())

    @signature({"types": ["object"]})
    def _func_values(self, o):
        return list(o.values())

    @signature({"types": ["any"]})
    def _func_type(self, v):
        if v is None:
            return "null"
        if isinstance(v, bool):
            return "boolean"
        if isinstance(v, str):
            return "string"
        if _is_num(v):
            return "number"
        if _is_arr(v):
            return "array"
        if isinstance(v, Mapping):
            return "object"
        return "object" if hasattr(v, "keys") and hasattr(v, "__getitem__") else "null"

    @signature({"types": ["any"]})
    def _func_to_array(self, v):
        return list(v) if _is_arr(v) else [v]

    @signature({"types": ["any"]})
    def _func_to_string(self, v):
        if isinstance(v, str):
            return v
        return json.dumps(v, separators=(",", ":"), default=_to_json_default)

    @signature({"types": ["any"]})
    def _func_to_number(self, v):
        if _is_num(v):
            return v
        if isinstance(v, str):
            # spec: N-000287 integer numeral -> int (conflict CF-000057, see NOTES.md)
            if _INT_RE.match(v):
                return int(v)
            if _FLOAT_RE.match(v):
                return float(v)
        return None

    @signature({"types": ["array-number", "array-string"]})
    def _func_max(self, a):
        return max(a) if a else None

    @signature({"types": ["array-number", "array-string"]})
    def _func_min(self, a):
        return min(a) if a else None

    @signature({"types": ["array-number", "array-string"]})
    def _func_sort(self, a):
        return sorted(a)

    @signature({"types": ["array-number"]})
    def _func_sum(self, a):
        return sum(a)

    @signature({"types": ["object"], "variadic": True})
    def _func_merge(self, *objs):
        out = {}
        for o in objs:
            for k in o:
                out[k] = o[k]
        return out

    @signature({"types": ["any"], "variadic": True})
    def _func_not_null(self, *args):
        for a in args:
            if a is not None:
                return a
        return None

    @signature({"types": ["expref"]}, {"types": ["array"]})
    def _func_map(self, ref, arr):
        return [ref.apply(x) for x in arr]

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_sort_by(self, arr, ref):
        arr = list(arr)
        if not arr:
            return []
        keys = [ref.apply(x) for x in arr]
        _key_check(keys)
        order = sorted(range(len(arr)), key=lambda i: keys[i])
        return [arr[i] for i in order]

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_max_by(self, arr, ref):
        if not arr:
            return None
        keys = [ref.apply(x) for x in arr]
        _key_check(keys)
        best = 0
        for i in range(1, len(arr)):
            if keys[i] > keys[best]:
                best = i
        return arr[best]

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_min_by(self, arr, ref):
        if not arr:
            return None
        keys = [ref.apply(x) for x in arr]
        _key_check(keys)
        best = 0
        for i in range(1, len(arr)):
            if keys[i] < keys[best]:
                best = i
        return arr[best]


def lookup(provider, name):
    func = getattr(provider, "_func_" + name, None) if provider is not None else None
    if func is None or not hasattr(func, "signature"):
        raise UnknownFunctionError("unknown function: %s" % name)
    return func


def _sig_of(func):
    return func.signature


def check_arity(func, name, n):
    sig = _sig_of(func)
    if sig and sig[-1].get("variadic"):
        ok = n >= len(sig)
    else:
        ok = n == len(sig)
    if not ok:
        raise ArityError("invalid arity calling %s: got %d" % (name, n))


def check_types(func, name, args, dict_cls):
    sig = _sig_of(func)
    for i, a in enumerate(args):
        spec = sig[min(i, len(sig) - 1)]
        types = spec.get("types") or ["any"]
        if not any(_matches(t, a, dict_cls) for t in types):
            raise FunctionTypeError("invalid type for argument %d of %s" % (i + 1, name))
