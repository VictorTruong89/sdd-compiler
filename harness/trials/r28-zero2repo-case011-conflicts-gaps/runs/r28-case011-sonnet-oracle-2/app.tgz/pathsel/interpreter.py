from collections.abc import Mapping

from .functions import (ExpRef, Functions, _is_arr, _is_num, _is_obj,
                        check_arity, check_types, json_eq, lookup)

_DEFAULT = Functions()


class Interpreter:
    def __init__(self, options=None):
        self.dict_cls = getattr(options, "dict_cls", None) if options is not None else None
        prov = getattr(options, "custom_functions", None) if options is not None else None
        self.provider = prov if prov is not None else _DEFAULT

    def obj(self, v):
        return _is_obj(v, self.dict_cls)

    @staticmethod
    def falsy(v):
        if v is None or v is False or v == "" and isinstance(v, str):
            return True
        if _is_arr(v) or isinstance(v, Mapping):
            return len(v) == 0
        return False

    def falsy2(self, v):
        if self.falsy(v):
            return True
        if self.obj(v):
            try:
                return len(v) == 0
            except TypeError:
                return False
        return False

    def visit(self, n, v):
        return getattr(self, "v_" + n[0])(n, v)

    def v_current(self, n, v):
        return v

    def v_literal(self, n, v):
        return n[1]

    def v_field(self, n, v):
        if self.obj(v):
            try:
                return v.get(n[1]) if hasattr(v, "get") else v[n[1]]
            except (KeyError, TypeError):
                return None
        return None

    def v_sub(self, n, v):
        return self.visit(n[2], self.visit(n[1], v))

    def v_index(self, n, v):
        if not _is_arr(v):
            return None
        try:
            return v[n[1]]
        except IndexError:
            return None

    def v_slice(self, n, v):
        if not _is_arr(v):
            return None
        return list(v)[slice(n[1], n[2], n[3])]

    def v_flatten(self, n, v):
        base = self.visit(n[1], v)
        if not _is_arr(base):
            return None
        out = []
        for x in base:
            if _is_arr(x):
                out.extend(x)
            else:
                out.append(x)
        return out

    def v_proj(self, n, v):
        base = self.visit(n[1], v)
        if not _is_arr(base):
            return None
        out = []
        for x in base:
            r = self.visit(n[2], x)
            if r is not None:
                out.append(r)
        return out

    def v_vproj(self, n, v):
        base = self.visit(n[1], v)
        if not self.obj(base):
            return None
        out = []
        for x in list(base.values()):
            r = self.visit(n[2], x)
            if r is not None:
                out.append(r)
        return out

    def v_fproj(self, n, v):
        base = self.visit(n[1], v)
        if not _is_arr(base):
            return None
        out = []
        for x in base:
            if not self.falsy2(self.visit(n[3], x)):
                r = self.visit(n[2], x)
                if r is not None:
                    out.append(r)
        return out

    def v_mlist(self, n, v):
        if v is None:  # CF-000011 resolved: null current value yields null
            return None
        return [self.visit(e, v) for e in n[1]]

    def v_mhash(self, n, v):
        if v is None:
            return None
        out = self.dict_cls() if self.dict_cls is not None else {}
        for k, e in n[1]:
            out[k] = self.visit(e, v)
        return out

    def v_or(self, n, v):
        l = self.visit(n[1], v)
        if not self.falsy2(l):
            return l
        return self.visit(n[2], v)

    def v_and(self, n, v):
        l = self.visit(n[1], v)
        if self.falsy2(l):
            return l
        return self.visit(n[2], v)

    def v_not(self, n, v):
        return self.falsy2(self.visit(n[1], v))

    def v_cmp(self, n, v):
        op = n[1]
        l = self.visit(n[2], v)
        r = self.visit(n[3], v)
        if op == "eq":
            return json_eq(l, r)
        if op == "ne":
            return not json_eq(l, r)
        if (_is_num(l) and _is_num(r)) or (isinstance(l, str) and isinstance(r, str)):
            if op == "lt":
                return l < r
            if op == "lte":
                return l <= r
            if op == "gt":
                return l > r
            return l >= r
        return None

    def v_expref(self, n, v):
        return ExpRef(n[1], self.visit)

    def v_call(self, n, v):
        name = n[1]
        func = lookup(self.provider, name)
        check_arity(func, name, len(n[2]))
        args = [self.visit(a, v) for a in n[2]]
        check_types(func, name, args, self.dict_cls)
        return func(*args)
