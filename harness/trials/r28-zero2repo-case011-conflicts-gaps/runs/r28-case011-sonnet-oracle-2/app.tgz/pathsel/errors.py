"""Failure carriers. Every refusal is a ValueError."""


class PathSelError(ValueError):
    pass


class EmptyExpressionError(PathSelError):
    def __init__(self, msg="empty expression"):
        super().__init__(msg)


class IncompleteExpressionError(PathSelError):
    def __init__(self, lex_position, msg="incomplete expression"):
        super().__init__("%s at position %d" % (msg, lex_position))
        self.lex_position = lex_position


class ParseError(PathSelError):
    """Grammar-level syntax failure."""

    def __init__(self, lex_position, msg="syntax error"):
        super().__init__("%s at position %d" % (msg, lex_position))
        self.lex_position = lex_position


class LexerError(ParseError):
    """Token-level syntax failure."""


class SliceStepError(PathSelError):
    pass


class UnknownFunctionError(PathSelError):
    pass


class ArityError(PathSelError):
    pass


class FunctionTypeError(PathSelError):
    pass
