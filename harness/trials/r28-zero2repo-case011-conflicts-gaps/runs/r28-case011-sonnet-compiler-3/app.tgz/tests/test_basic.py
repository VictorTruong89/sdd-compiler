import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import pathsel
from pathsel import search
from pathsel.functions import Functions, signature
import pytest

D = {"a": {"b": [1, 2, 3, {"c": 4}]}, "xs": [{"n": 1, "k": "a"}, {"n": 0}, {"n": 3, "k": "b"}],
     "o": {"p": 1, "q": 2}}

CASES = [
    ("a.b[0]", 1), ("a.b[-1].c", 4), ("a.zz.y", None), ("a.b[1:3]", [2, 3]),
    ("a.b[::-1][0]", []), ("xs[*].n", [1, 0, 3]), ("xs[?n > `0`].k", ["a", "b"]),
    ("o.*", [1, 2]), ("xs[].k", ["a", "b"]), ("[a.b[0], o.p]", [1, 1]),
    ("{x: o.p, y: a.zz}", {"x": 1, "y": None}), ("xs[*].n | [0]", 1),
    ("length('héé')", 3), ("to_string(`{\"a\": \"é\"}`)", '{"a":"\\u00e9"}'),
    ("not_null(`\"\"`, `1`)", ""), ("sort_by(xs, &n)[0].n", 0),
    ("max_by(xs, &n).k", "b"), ("map(&n, xs)", [1, 0, 3]), ("!(xs[0].zz)", True),
    ("`0` == `false`", False), ("xs[?n].k", ["a", "b"]), ("'a\\'b'", "a'b"),
    ("a.b[::2]", [1, 3]), ("[1:2]", None), ("to_number('1.5')", 1.5),
    ("join(',', `[]`)", ""), ("@", D),
]


@pytest.mark.parametrize("expr,exp", CASES)
def test_cases(expr, exp):
    assert search(expr, D) == exp
    assert pathsel.compile(expr).search(D) == exp


def test_errors():
    with pytest.raises(pathsel.EmptyExpressionError): search("", D)
    with pytest.raises(pathsel.IncompleteExpressionError): search("  ", D)
    with pytest.raises(pathsel.IncompleteExpressionError): search("a.b[", D)
    with pytest.raises(pathsel.ParseError) as e: search("a.", D)
    assert e.value.lex_position == 2 and type(e.value) is pathsel.ParseError
    with pytest.raises(pathsel.LexerError): search("a = b", D)
    with pytest.raises(pathsel.LexerError): search("a-b", D)
    with pytest.raises(pathsel.SliceStepError): search("a[::0]", D)
    with pytest.raises(pathsel.UnknownFunctionError): search("nope(@)", D)
    with pytest.raises(pathsel.ArityError): search("abs()", D)
    with pytest.raises(pathsel.PathselTypeError): search("abs('x')", D)
    with pytest.raises(pathsel.ParseError): search("a.`1`", D)
    with pytest.raises(pathsel.ParseError): search("'x'.\"f\"(1)", D)


def test_custom():
    class F(Functions):
        @signature({"types": ["number"]})
        def _func_dbl(self, x): return x * 2
    class O: dict_cls = None; custom_functions = F()
    assert search("dbl(@)", 4, O) == 8
    assert search("abs(@)", -4, O) == 4
    with pytest.raises(pathsel.UnknownFunctionError): search("dbl(@)", 4)
    from collections import OrderedDict
    class O2: dict_cls = OrderedDict; custom_functions = None
    r = search("{a: @}", 1, O2)
    assert type(r) is OrderedDict and search("keys({a: @})", 1, O2) == ["a"]
