"""pathsel: declarative extraction of values from JSON-like Python data."""
from .exceptions import (ArityError, EmptyExpressionError,
                         IncompleteExpressionError, LexerError, ParseError,
                         PathselError, PathselTypeError, SliceStepError,
                         UnknownFunctionError)
from .interpreter import Interpreter
from .parser import parse as _parse


class ParsedExpression:
    def __init__(self, expression, ast):
        self.expression = expression
        self._ast = ast

    def search(self, value, options=None):
        return Interpreter(options).visit(self._ast, value)

    def __repr__(self):
        return "ParsedExpression(%r)" % (self.expression,)


def compile(expression):
    return ParsedExpression(expression, _parse(expression))


def search(expression, data, options=None):
    return compile(expression).search(data, options)


__all__ = ["search", "compile", "ParsedExpression", "PathselError",
           "EmptyExpressionError", "IncompleteExpressionError", "ParseError",
           "LexerError", "SliceStepError", "UnknownFunctionError",
           "ArityError", "PathselTypeError"]
