import json
import math
from collections.abc import Mapping
from decimal import Decimal

from .exceptions import PathselTypeError


def is_object(v):
    if isinstance(v, Mapping):
        return True
    return (not isinstance(v, (list, str, bytes, tuple, set))
            and hasattr(v, "keys") and hasattr(v, "__getitem__"))


def is_number(v):
    return isinstance(v, (int, float, Decimal)) and not isinstance(v, bool)


def obj_keys(v):
    return list(v.keys())


def obj_get(v, k):
    try:
        return v[k]
    except (KeyError, IndexError, TypeError):
        return None


def json_equal(a, b):
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if is_number(a) and is_number(b):
        return a == b
    if isinstance(a, list) and isinstance(b, list):
        return len(a) == len(b) and all(json_equal(x, y) for x, y in zip(a, b))
    if is_object(a) and is_object(b):
        ka, kb = obj_keys(a), obj_keys(b)
        if len(ka) != len(kb) or set(ka) != set(kb):
            return False
        return all(json_equal(obj_get(a, k), obj_get(b, k)) for k in ka)
    if is_object(a) or is_object(b) or isinstance(a, list) or isinstance(b, list):
        return False
    try:
        return bool(a == b)
    except Exception:
        return False


def json_type(v):
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "boolean"
    if isinstance(v, str):
        return "string"
    if is_number(v):
        return "number"
    if isinstance(v, list):
        return "array"
    if is_object(v):
        return "object"
    return "other"


def _matches(v, t):
    if t == "any":
        return True
    if t == "number":
        return is_number(v)
    if t == "string":
        return isinstance(v, str)
    if t == "boolean":
        return isinstance(v, bool)
    if t == "array":
        return isinstance(v, list)
    if t == "object":
        return is_object(v)
    if t == "null":
        return v is None
    if t == "expref":
        return type(v).__name__ == "Expref"
    if t == "array-number":
        return isinstance(v, list) and all(is_number(x) for x in v)
    if t == "array-string":
        return isinstance(v, list) and all(isinstance(x, str) for x in v)
    return False


def signature(*arguments):
    """Decorator declaring argument specs: {"types": [...]} (optional "variadic")."""
    def decorator(func):
        func.signature = arguments
        return func
    return decorator


def _nums(values):
    if any(isinstance(x, Decimal) for x in values) and not all(
            isinstance(x, Decimal) or (isinstance(x, int) and not isinstance(x, bool))
            for x in values):
        return [float(x) if isinstance(x, Decimal) else x for x in values]
    return list(values)


class Functions:
    """Provider of the built-in functions; subclass to add more."""

    @signature({"types": ["number"]})
    def _func_abs(self, arg):
        return abs(arg)

    @signature({"types": ["array-number"]})
    def _func_avg(self, arg):
        if not arg:
            return None
        arg = _nums(arg)
        return sum(arg) / float(len(arg))

    @signature({"types": ["number"]})
    def _func_ceil(self, arg):
        return math.ceil(arg)

    @signature({"types": ["number"]})
    def _func_floor(self, arg):
        return math.floor(arg)

    @signature({"types": ["array", "string"]}, {"types": ["any"]})
    def _func_contains(self, subject, search):
        if isinstance(subject, str):
            return isinstance(search, str) and search in subject
        return any(json_equal(x, search) for x in subject)

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_ends_with(self, s, suffix):
        return s.endswith(suffix)

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_starts_with(self, s, prefix):
        return s.startswith(prefix)

    @signature({"types": ["string", "array", "object"]})
    def _func_length(self, arg):
        return len(arg)  # characters, not bytes (CF-000035)

    @signature({"types": ["array", "string"]})
    def _func_reverse(self, arg):
        return arg[::-1] if isinstance(arg, str) else list(reversed(arg))

    @signature({"types": ["string"]}, {"types": ["array-string"]})
    def _func_join(self, sep, arr):
        return sep.join(arr)

    @signature({"types": ["object"]})
    def _func_keys(self, arg):
        return obj_keys(arg)

    @signature({"types": ["object"]})
    def _func_values(self, arg):
        return [obj_get(arg, k) for k in obj_keys(arg)]

    @signature({"types": ["any"]})
    def _func_type(self, arg):
        t = json_type(arg)
        return "object" if t == "other" else t

    @signature({"types": ["any"]})
    def _func_to_array(self, arg):
        return arg if isinstance(arg, list) else [arg]

    @signature({"types": ["any"]})
    def _func_to_string(self, arg):
        if isinstance(arg, str):
            return arg
        return json.dumps(arg, separators=(",", ":"), default=_dump_default)

    @signature({"types": ["any"]})
    def _func_to_number(self, arg):
        import re
        if is_number(arg):
            return arg
        if isinstance(arg, str):
            if re.fullmatch(r"[+-]?[0-9]+", arg):
                return int(arg)
            if re.fullmatch(r"[+-]?([0-9]+\.?[0-9]*|\.[0-9]+)([eE][+-]?[0-9]+)?", arg):
                try:
                    return float(arg)
                except ValueError:
                    return None
        return None

    @signature({"types": ["array-number", "array-string"]})
    def _func_max(self, arg):
        if not arg:
            return None
        arg = _nums(arg)
        return max(arg)

    @signature({"types": ["array-number", "array-string"]})
    def _func_min(self, arg):
        if not arg:
            return None
        arg = _nums(arg)
        return min(arg)

    @signature({"types": ["array-number", "array-string"]})
    def _func_sort(self, arg):
        return sorted(_nums(arg))

    @signature({"types": ["array-number"]})
    def _func_sum(self, arg):
        return sum(_nums(arg))

    @signature({"types": ["object"], "variadic": True})
    def _func_merge(self, *args):
        out = {}
        for a in args:
            for k in obj_keys(a):
                out[k] = obj_get(a, k)
        return out

    @signature({"types": ["any"], "variadic": True})
    def _func_not_null(self, *args):
        for a in args:
            if a is not None:
                return a
        return None

    @signature({"types": ["expref"]}, {"types": ["array"]})
    def _func_map(self, ref, arr):
        return [ref.eval(x) for x in arr]

    def _keys_for(self, ref, arr):
        keys = [ref.eval(x) for x in arr]
        if keys:
            t = json_type(keys[0])
            if t not in ("number", "string") or any(json_type(k) != t for k in keys):
                raise PathselTypeError("key must be all numbers or all strings")
        return _nums(keys) if keys and json_type(keys[0]) == "number" else keys

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_sort_by(self, arr, ref):
        keys = self._keys_for(ref, arr)
        order = sorted(range(len(arr)), key=lambda i: keys[i])
        return [arr[i] for i in order]

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_max_by(self, arr, ref):
        keys = self._keys_for(ref, arr)
        best = None
        for i in range(len(arr)):
            if best is None or keys[i] > keys[best]:
                best = i
        return None if best is None else arr[best]

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_min_by(self, arr, ref):
        keys = self._keys_for(ref, arr)
        best = None
        for i in range(len(arr)):
            if best is None or keys[i] < keys[best]:
                best = i
        return None if best is None else arr[best]


def _dump_default(o):
    if isinstance(o, Decimal):
        return float(o)
    if is_object(o):
        return {k: obj_get(o, k) for k in obj_keys(o)}
    return str(o)
