import copy

from .exceptions import (ArityError, PathselTypeError, UnknownFunctionError)
from .functions import (Functions, _matches, is_number, is_object, json_equal,
                        json_type, obj_get, obj_keys)


class Expref:
    """Value of an expression reference."""

    def __init__(self, node, interp):
        self.node = node
        self.interp = interp

    def eval(self, value):
        return self.interp.visit(self.node, value)

    def __repr__(self):
        return "<expref>"


def is_false(v):
    if v is None or v is False or v == "" and isinstance(v, str):
        return True
    if isinstance(v, list):
        return len(v) == 0
    if is_object(v):
        return len(obj_keys(v)) == 0
    return False


def _slice(arr, start, stop, step):
    n = len(arr)
    if step is None:
        step = 1
    if step > 0:
        s = 0 if start is None else start
        e = n if stop is None else stop
        if s < 0:
            s += n
        if e < 0:
            e += n
        s = min(max(s, 0), n)
        e = min(max(e, 0), n)
        return [arr[i] for i in range(s, e, step)]
    s = n - 1 if start is None else start
    e = -1 if stop is None else stop
    if start is not None and s < 0:
        s += n
    if stop is not None and e < 0:
        e += n
    s = min(max(s, -1), n - 1)
    e = min(max(e, -1), n - 1)
    return [arr[i] for i in range(s, e, step)]


_builtin = Functions()


class Interpreter:
    def __init__(self, options=None):
        self.dict_cls = getattr(options, "dict_cls", None) or dict
        self.provider = getattr(options, "custom_functions", None)

    def visit(self, node, value):
        return getattr(self, "_v_" + node[0])(node, value)

    def _v_identity(self, node, value):
        return value

    _v_current = _v_identity

    def _v_field(self, node, value):
        if is_object(value):
            return obj_get(value, node[1])
        return None

    def _v_subexpression(self, node, value):
        return self.visit(node[2], self.visit(node[1], value))

    def _v_pipe(self, node, value):
        return self.visit(node[2], self.visit(node[1], value))

    def _v_literal(self, node, value):
        return copy.deepcopy(node[1])

    def _v_index(self, node, value):
        if not isinstance(value, list):
            return None
        try:
            return value[node[1]]
        except IndexError:
            return None

    def _v_slice(self, node, value):
        if not isinstance(value, list):
            return None
        return _slice(value, node[1], node[2], node[3])

    def _v_flatten(self, node, value):
        base = self.visit(node[1], value)
        if not isinstance(base, list):
            return None
        out = []
        for el in base:
            if isinstance(el, list):
                out.extend(el)
            else:
                out.append(el)
        return out

    def _v_projection(self, node, value):
        base = self.visit(node[1], value)
        if not isinstance(base, list):
            return None
        out = []
        for el in base:
            r = self.visit(node[2], el)
            if r is not None:
                out.append(r)
        return out

    def _v_value_projection(self, node, value):
        base = self.visit(node[1], value)
        if not is_object(base):
            return None
        out = []
        for k in obj_keys(base):
            r = self.visit(node[2], obj_get(base, k))
            if r is not None:
                out.append(r)
        return out

    def _v_filter_projection(self, node, value):
        base = self.visit(node[1], value)
        if not isinstance(base, list):
            return None
        out = []
        for el in base:
            if not is_false(self.visit(node[3], el)):
                r = self.visit(node[2], el)
                if r is not None:
                    out.append(r)
        return out

    def _v_or(self, node, value):
        left = self.visit(node[1], value)
        if not is_false(left):
            return left
        return self.visit(node[2], value)

    def _v_and(self, node, value):
        left = self.visit(node[1], value)
        if is_false(left):
            return left
        return self.visit(node[2], value)

    def _v_not(self, node, value):
        return is_false(self.visit(node[1], value))

    def _v_comparator(self, node, value):
        op = node[1]
        a = self.visit(node[2], value)
        b = self.visit(node[3], value)
        if op == "eq":
            return json_equal(a, b)
        if op == "ne":
            return not json_equal(a, b)
        if (is_number(a) and is_number(b)) or (
                isinstance(a, str) and isinstance(b, str)):
            if op == "lt":
                return a < b
            if op == "lte":
                return a <= b
            if op == "gt":
                return a > b
            return a >= b
        return None

    def _v_multi_list(self, node, value):
        if value is None:
            return None  # CF-000011 resolved: null current value yields null
        return [self.visit(n, value) for n in node[1]]

    def _v_multi_hash(self, node, value):
        if value is None:
            return None
        out = self.dict_cls()
        for k, n in node[1]:
            out[k] = self.visit(n, value)
        return out

    def _v_expref(self, node, value):
        return Expref(node[1], self)

    def _lookup(self, name):
        for prov in (self.provider, _builtin):
            if prov is None:
                continue
            fn = getattr(prov, "_func_" + name, None)
            if fn is not None and hasattr(fn, "signature"):
                return fn
        return None

    def _v_function(self, node, value):
        name, argnodes = node[1], node[2]
        fn = self._lookup(name)
        if fn is None:
            raise UnknownFunctionError("Unknown function: %s()" % name)
        sig = fn.signature
        variadic = bool(sig) and bool(sig[-1].get("variadic"))
        n = len(argnodes)
        if variadic:
            if n < len(sig):
                raise ArityError("%s() expects at least %d arguments" % (name, len(sig)))
        elif n != len(sig):
            raise ArityError("%s() expects %d arguments, got %d" % (name, len(sig), n))
        args = [self.visit(a, value) for a in argnodes]
        for i, a in enumerate(args):
            spec = sig[min(i, len(sig) - 1)]
            if not any(_matches(a, t) for t in spec["types"]):
                raise PathselTypeError(
                    "%s(): invalid type for argument %d (got %s)" % (name, i + 1, json_type(a)))
        return fn(*args)
