import json
import re

from .exceptions import LexerError

_START = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_")
_ID = _START | set("0123456789")
_DIGITS = set("0123456789")
_WS = set(" \t\n\r")
_SIMPLE = {
    ".": "dot", "*": "star", ",": "comma", ":": "colon", "{": "lbrace",
    "}": "rbrace", "]": "rbracket", "(": "lparen", ")": "rparen",
    "@": "current",
}
_U = re.compile(r"\\u([0-9a-fA-F]{4})")


def _decode_u(text):
    def pair(m):
        hi = int(m.group(1), 16)
        return chr(hi)
    # combine surrogate pairs first
    text = re.sub(
        r"\\u([dD][89abAB][0-9a-fA-F]{2})\\u([dD][c-fC-F][0-9a-fA-F]{2})",
        lambda m: chr(0x10000 + ((int(m.group(1), 16) - 0xD800) << 10)
                      + (int(m.group(2), 16) - 0xDC00)),
        text)
    return _U.sub(pair, text)


def tokenize(expr):
    """Return a list of (type, value, start) ending with an eof token."""
    tokens = []
    n = len(expr)
    i = 0

    def consume_until(start, delim):
        # start is index of opening delimiter; returns (lexeme, next_index)
        j = start + 1
        buf = []
        while j < n and expr[j] != delim:
            if expr[j] == "\\":
                buf.append(expr[j])
                j += 1
            if j < n:
                buf.append(expr[j])
                j += 1
        if j >= n:
            raise LexerError(start, "Unterminated %s delimiter" % delim)
        return "".join(buf), j + 1

    while i < n:
        c = expr[i]
        if c in _WS:
            i += 1
        elif c in _SIMPLE:
            tokens.append((_SIMPLE[c], c, i))
            i += 1
        elif c in _START:
            j = i + 1
            while j < n and expr[j] in _ID:
                j += 1
            tokens.append(("unquoted_identifier", expr[i:j], i))
            i = j
        elif c in _DIGITS or c == "-":
            j = i + 1
            if c == "-" and not (j < n and expr[j] in _DIGITS):
                raise LexerError(i, "Unknown token '-'")
            while j < n and expr[j] in _DIGITS:
                j += 1
            tokens.append(("number", int(expr[i:j]), i))
            i = j
        elif c == "[":
            if i + 1 < n and expr[i + 1] == "?":
                tokens.append(("filter", "[?", i))
                i += 2
            elif i + 1 < n and expr[i + 1] == "]":
                tokens.append(("flatten", "[]", i))
                i += 2
            else:
                tokens.append(("lbracket", "[", i))
                i += 1
        elif c == "|":
            if i + 1 < n and expr[i + 1] == "|":
                tokens.append(("or", "||", i))
                i += 2
            else:
                tokens.append(("pipe", "|", i))
                i += 1
        elif c == "&":
            if i + 1 < n and expr[i + 1] == "&":
                tokens.append(("and", "&&", i))
                i += 2
            else:
                tokens.append(("expref", "&", i))
                i += 1
        elif c in "<>!=":
            two = expr[i:i + 2]
            if two == "<=":
                tokens.append(("lte", two, i)); i += 2
            elif two == ">=":
                tokens.append(("gte", two, i)); i += 2
            elif two == "!=":
                tokens.append(("ne", two, i)); i += 2
            elif two == "==":
                tokens.append(("eq", two, i)); i += 2
            elif c == "<":
                tokens.append(("lt", c, i)); i += 1
            elif c == ">":
                tokens.append(("gt", c, i)); i += 1
            elif c == "!":
                tokens.append(("not", c, i)); i += 1
            else:
                raise LexerError(i, "Unknown token '='")
        elif c == '"':
            lexeme, j = consume_until(i, '"')
            try:
                value = json.loads('"%s"' % lexeme)
            except ValueError:
                raise LexerError(i, "Invalid quoted identifier")
            tokens.append(("quoted_identifier", value, i))
            i = j
        elif c == "`":
            lexeme, j = consume_until(i, "`")
            lexeme = lexeme.replace("\\`", "`")
            try:
                value = json.loads(lexeme)
            except ValueError:
                try:
                    value = json.loads('"%s"' % lexeme.lstrip())
                except ValueError:
                    raise LexerError(i, "Bad JSON literal")
            tokens.append(("literal", value, i))
            i = j
        elif c == "'":
            lexeme, j = consume_until(i, "'")
            lexeme = lexeme.replace("\\'", "'")
            tokens.append(("literal", _decode_u(lexeme), i))
            i = j
        else:
            raise LexerError(i, "Unknown token %r" % c)
    tokens.append(("eof", "", n))
    return tokens
