"""Failure carriers.  Every refusal is a ValueError; the kind is the exception type."""


class PathselError(ValueError):
    """Base of every refusal."""


class EmptyExpressionError(PathselError):
    """Zero-length expression text."""  # spec: N-000090


class _Positioned(PathselError):
    def __init__(self, lex_position, message=""):
        self.lex_position = lex_position
        self.message = message
        super().__init__("%s (at position %s)" % (message, lex_position))


class IncompleteExpressionError(_Positioned):
    """Text ended where more was required."""


class ParseError(_Positioned):
    """Grammar-level syntax failure."""


class LexerError(ParseError):
    """Token-level syntax failure (a more specific form of ParseError)."""


class SliceStepError(PathselError):
    """A slice with step 0."""


class UnknownFunctionError(PathselError):
    pass


class ArityError(PathselError):
    pass


class PathselTypeError(PathselError):
    """Invalid argument type."""
