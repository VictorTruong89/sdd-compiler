from .exceptions import (EmptyExpressionError, IncompleteExpressionError,
                         ParseError, SliceStepError)
from .lexer import tokenize

BP = {
    "eof": 0, "unquoted_identifier": 0, "quoted_identifier": 0, "literal": 0,
    "rbracket": 0, "rparen": 0, "comma": 0, "rbrace": 0, "number": 0,
    "current": 0, "expref": 0, "colon": 0, "pipe": 1, "or": 2, "and": 3,
    "eq": 5, "gt": 5, "lt": 5, "gte": 5, "lte": 5, "ne": 5, "flatten": 9,
    "star": 20, "filter": 21, "dot": 40, "not": 45, "lbrace": 50,
    "lbracket": 55, "lparen": 60,
}
_IDENT = ("quoted_identifier", "unquoted_identifier")
IDENTITY = ("identity",)


class Parser:
    def __init__(self):
        self.tokens = []
        self.pos = 0

    def parse(self, expression):
        if expression == "":
            raise EmptyExpressionError("Empty expression")
        self.tokens = tokenize(expression)
        self.pos = 0
        node = self._expression(0)
        if self._cur() != "eof":
            self._raise(self.tokens[self.pos])
        return node

    # token helpers
    def _cur(self):
        return self.tokens[self.pos][0]

    def _look(self, n):
        i = self.pos + n
        if i >= len(self.tokens):
            return "eof"
        return self.tokens[i][0]

    def _advance(self):
        self.pos += 1

    def _raise(self, token, msg=None):
        typ, val, start = token
        if typ == "eof":
            raise IncompleteExpressionError(start, msg or "Invalid end of expression")
        raise ParseError(start, msg or "Unexpected token: %s" % (val,))

    def _match(self, typ):
        if self._cur() == typ:
            self._advance()
        else:
            self._raise(self.tokens[self.pos])

    # core
    def _expression(self, bp=0):
        tok = self.tokens[self.pos]
        self._advance()
        nud = getattr(self, "_nud_" + tok[0], None)
        if nud is None:
            self._raise(tok)
        left = nud(tok)
        while bp < BP[self._cur()]:
            ltok = self.tokens[self.pos]
            led = getattr(self, "_led_" + ltok[0], None)
            if led is None:
                self._raise(ltok)
            self._advance()
            left = led(left, ltok)
        return left

    # nud
    def _nud_literal(self, tok):
        return ("literal", tok[1])

    def _nud_unquoted_identifier(self, tok):
        return ("field", tok[1])

    def _nud_quoted_identifier(self, tok):
        if self._cur() == "lparen":
            self._raise(self.tokens[self.pos],
                        "Quoted identifier not allowed for function names.")
        return ("field", tok[1])

    def _nud_star(self, tok):
        if self._cur() == "rbracket":
            right = IDENTITY
        else:
            right = self._proj_rhs(BP["star"])
        return ("value_projection", IDENTITY, right)

    def _nud_filter(self, tok):
        return self._led_filter(IDENTITY, tok)

    def _nud_lbrace(self, tok):
        return self._multiselect_hash()

    def _nud_flatten(self, tok):
        return ("projection", ("flatten", IDENTITY),
                self._proj_rhs(BP["flatten"]))

    def _nud_not(self, tok):
        return ("not", self._expression(BP["not"]))

    def _nud_lparen(self, tok):
        e = self._expression(0)
        self._match("rparen")
        return e

    def _nud_lbracket(self, tok):
        la = self._look(0)
        if la in ("number", "colon"):
            right = self._index_expression()
            return self._project_if_slice(IDENTITY, right)
        if la == "star" and self._look(1) == "rbracket":
            self._advance()
            self._advance()
            return ("projection", IDENTITY, self._proj_rhs(BP["star"]))
        return self._multiselect_list()

    def _nud_current(self, tok):
        return ("current",)

    def _nud_expref(self, tok):
        return ("expref", self._expression(BP["expref"]))

    # led
    def _led_dot(self, left, tok):
        if self._cur() != "star":
            right = self._dot_rhs(BP["dot"])
            return ("subexpression", left, right)
        self._advance()
        right = self._proj_rhs(BP["dot"])
        return ("value_projection", left, right)

    def _led_pipe(self, left, tok):
        return ("pipe", left, self._expression(BP["pipe"]))

    def _led_or(self, left, tok):
        return ("or", left, self._expression(BP["or"]))

    def _led_and(self, left, tok):
        return ("and", left, self._expression(BP["and"]))

    def _comparator(self, left, tok):
        return ("comparator", tok[0], left, self._expression(BP[tok[0]]))

    _led_eq = _led_ne = _led_lt = _led_gt = _led_lte = _led_gte = _comparator

    def _led_lparen(self, left, tok):
        if left[0] != "field":
            self._raise(tok)
        args = []
        while self._cur() != "rparen":
            args.append(self._expression(0))
            if self._cur() == "comma":
                self._match("comma")
        self._match("rparen")
        return ("function", left[1], args, tok[2])

    def _led_filter(self, left, tok):
        cond = self._expression(0)
        self._match("rbracket")
        right = self._proj_rhs(BP["filter"])
        return ("filter_projection", left, right, cond)

    def _led_flatten(self, left, tok):
        return ("projection", ("flatten", left), self._proj_rhs(BP["flatten"]))

    def _led_lbracket(self, left, tok):
        if self._cur() in ("number", "colon"):
            right = self._index_expression()
            return self._project_if_slice(left, right)
        self._match("star")
        self._match("rbracket")
        return ("projection", left, self._proj_rhs(BP["star"]))

    # helpers
    def _project_if_slice(self, left, right):
        idx = ("subexpression", left, right)
        if right[0] == "slice":
            return ("projection", idx, self._proj_rhs(BP["star"]))
        return idx

    def _index_expression(self):
        if self._look(0) == "colon" or self._look(1) == "colon":
            return self._slice()
        node = ("index", self.tokens[self.pos][1])
        self._advance()
        self._match("rbracket")
        return node

    def _slice(self):
        parts = [None, None, None]
        index = 0
        while self._cur() != "rbracket" and index < 3:
            tok = self.tokens[self.pos]
            if tok[0] == "colon":
                index += 1
                if index == 3:
                    self._raise(tok)
                self._advance()
            elif tok[0] == "number":
                parts[index] = tok[1]
                self._advance()
            else:
                self._raise(tok)
        self._match("rbracket")
        if parts[2] == 0:
            # spec: N-000153 zero-slice-step kind
            raise SliceStepError("slice step cannot be 0")
        return ("slice", parts[0], parts[1], parts[2])

    def _proj_rhs(self, bp):
        cur = self._cur()
        if BP[cur] < 10:
            return IDENTITY
        if cur in ("lbracket", "filter"):
            return self._expression(bp)
        if cur == "dot":
            self._advance()
            return self._dot_rhs(bp)
        self._raise(self.tokens[self.pos])

    def _dot_rhs(self, bp):
        la = self._look(0)
        if la in _IDENT or la == "star":
            return self._expression(bp)
        if la == "lbracket":
            self._advance()
            return self._multiselect_list()
        if la == "lbrace":
            self._advance()
            return self._multiselect_hash()
        tok = self.tokens[self.pos]
        # a dot followed by the end of text is a syntax failure, not incomplete
        raise ParseError(tok[2], "Expecting identifier, wildcard or multiselect after '.'")

    def _multiselect_list(self):
        exprs = []
        while True:
            exprs.append(self._expression(0))
            if self._cur() == "comma":
                self._advance()
                if self._cur() == "rbracket":
                    self._raise(self.tokens[self.pos])
            elif self._cur() == "rbracket":
                self._advance()
                break
            else:
                self._raise(self.tokens[self.pos])
        return ("multi_list", exprs)

    def _multiselect_hash(self):
        pairs = []
        while True:
            tok = self.tokens[self.pos]
            if tok[0] not in _IDENT:
                self._raise(tok)
            self._advance()
            self._match("colon")
            pairs.append((tok[1], self._expression(0)))
            if self._cur() == "comma":
                self._advance()
            elif self._cur() == "rbrace":
                self._advance()
                break
            else:
                self._raise(self.tokens[self.pos])
        return ("multi_hash", pairs)


def parse(expression):
    return Parser().parse(expression)
