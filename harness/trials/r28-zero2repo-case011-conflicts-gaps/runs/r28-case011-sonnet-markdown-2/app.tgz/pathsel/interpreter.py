import copy
from collections.abc import Mapping

from .functions import (Expref, Functions, is_array, is_number, is_object,
                        json_eq)

_DEFAULT_FUNCS = Functions()


def is_false(v):
    if v is None or v is False:
        return True
    if isinstance(v, (str, list, tuple)) or isinstance(v, Mapping):
        return len(v) == 0
    return False


def _slice(arr, start, stop, step):
    if step is None:
        step = 1
    if step == 0:
        return []
    n = len(arr)
    if step > 0:
        s = 0 if start is None else (start + n if start < 0 else start)
        e = n if stop is None else (stop + n if stop < 0 else stop)
        s = max(0, min(n, s))
        e = max(0, min(n, e))
        return [arr[i] for i in range(s, e, step)]
    s = n - 1 if start is None else (start + n if start < 0 else start)
    e = -1 if stop is None else (stop + n if stop < 0 else stop)
    s = max(-1, min(n - 1, s))
    e = max(-1, min(n - 1, e))
    return [arr[i] for i in range(s, e, step)]


def _order(a, b, op):
    if is_number(a) and is_number(b) or isinstance(a, str) and isinstance(b, str):
        if op == "lt":
            return a < b
        if op == "le":
            return a <= b
        if op == "gt":
            return a > b
        return a >= b
    return None


class Interpreter:
    def __init__(self, options=None):
        self.dict_cls = getattr(options, "dict_cls", None) or dict
        funcs = getattr(options, "custom_functions", None)
        self.funcs = funcs if funcs is not None else _DEFAULT_FUNCS

    def visit(self, node, value):
        return getattr(self, "v_" + node[0])(node, value)

    def v_identity(self, node, value):
        return value

    def v_field(self, node, value):
        if is_object(value):
            return value.get(node[1])
        return None

    def v_index(self, node, value):
        if is_array(value):
            try:
                return value[node[1]]
            except IndexError:
                return None
        return None

    def v_slice(self, node, value):
        if not is_array(value):
            return None
        return _slice(value, node[1], node[2], node[3])

    def v_sub(self, node, value):
        return self.visit(node[2], self.visit(node[1], value))

    v_pipe = v_sub

    def _collect(self, items, rhs):
        out = []
        for x in items:
            r = self.visit(rhs, x)
            if r is not None:
                out.append(r)
        return out

    def v_projection(self, node, value):
        base = self.visit(node[1], value)
        if not is_array(base):
            return None
        return self._collect(base, node[2])

    def v_value_projection(self, node, value):
        base = self.visit(node[1], value)
        if not is_object(base):
            return None
        return self._collect(list(base.values()), node[2])

    def v_filter_projection(self, node, value):
        base = self.visit(node[1], value)
        if not is_array(base):
            return None
        kept = [x for x in base if not is_false(self.visit(node[3], x))]
        return self._collect(kept, node[2])

    def v_flatten(self, node, value):
        base = self.visit(node[1], value)
        if not is_array(base):
            return None
        out = []
        for x in base:
            if is_array(x):
                out.extend(x)
            else:
                out.append(x)
        return out

    def v_or(self, node, value):
        left = self.visit(node[1], value)
        if not is_false(left):
            return left
        return self.visit(node[2], value)

    def v_and(self, node, value):
        left = self.visit(node[1], value)
        if is_false(left):
            return left
        return self.visit(node[2], value)

    def v_not(self, node, value):
        return is_false(self.visit(node[1], value))

    def v_compare(self, node, value):
        op = node[1]
        a = self.visit(node[2], value)
        b = self.visit(node[3], value)
        if op == "eq":
            return json_eq(a, b)
        if op == "ne":
            return not json_eq(a, b)
        return _order(a, b, op)

    def v_literal(self, node, value):
        v = node[1]
        if isinstance(v, (list, dict)):
            return copy.deepcopy(v)
        return v

    def v_multilist(self, node, value):
        if value is None:
            return None
        return [self.visit(e, value) for e in node[1]]

    def v_multihash(self, node, value):
        if value is None:
            return None
        out = self.dict_cls()
        for k, e in node[1]:
            out[k] = self.visit(e, value)
        return out

    def v_expref(self, node, value):
        return Expref(node[1])

    def v_function(self, node, value):
        args = [self.visit(a, value) for a in node[2]]
        funcs = self.funcs
        # give function implementations access to the interpreter
        try:
            funcs._interp = self
        except Exception:
            pass
        if hasattr(funcs, "call"):
            return funcs.call(node[1], args, self)
        return Functions.call(funcs, node[1], args, self)
