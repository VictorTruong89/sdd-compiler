import json
import math
import re
from collections.abc import Mapping
from decimal import Decimal
from numbers import Real

from .exceptions import ArityError, InvalidTypeError, UnknownFunctionError


class Expref:
    """Deferred expression reference."""

    def __init__(self, node):
        self.node = node

    def __repr__(self):
        return "<expref>"


def is_number(v):
    return isinstance(v, (Real, Decimal)) and not isinstance(v, bool)


def is_array(v):
    return isinstance(v, (list, tuple))


def is_object(v):
    return isinstance(v, Mapping)


def type_name(v):
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "boolean"
    if isinstance(v, str):
        return "string"
    if is_number(v):
        return "number"
    if is_array(v):
        return "array"
    if is_object(v):
        return "object"
    if isinstance(v, Expref):
        return "expref"
    return None


def json_eq(a, b):
    ab, bb = isinstance(a, bool), isinstance(b, bool)
    if ab or bb:
        return ab and bb and a == b
    if a is None or b is None:
        return a is None and b is None
    if is_number(a) and is_number(b):
        return a == b
    if isinstance(a, str) and isinstance(b, str):
        return a == b
    if is_array(a) and is_array(b):
        return len(a) == len(b) and all(json_eq(x, y) for x, y in zip(a, b))
    if is_object(a) and is_object(b):
        if len(a) != len(b):
            return False
        for k in a:
            if k not in b or not json_eq(a[k], b[k]):
                return False
        return True
    if is_number(a) or is_number(b) or isinstance(a, str) or isinstance(b, str) \
            or is_array(a) or is_array(b) or is_object(a) or is_object(b):
        return False
    try:
        return bool(a == b)
    except Exception:
        return False


def _check(spec, value):
    types = spec["types"]
    t = type_name(value)
    if t == "expref":
        return "expref" in types
    if "any" in types:
        return True
    if t is None:
        return False
    for ty in types:
        if ty == t:
            return True
        if ty == "array-number" and t == "array" and all(is_number(x) for x in value):
            return True
        if ty == "array-string" and t == "array" and all(isinstance(x, str) for x in value):
            return True
    return False


def signature(*arguments):
    def decorator(func):
        func._pathsel_signature = list(arguments)
        return func
    return decorator


def _num_sum(vals):
    try:
        return sum(vals)
    except TypeError:
        return sum(float(v) if isinstance(v, Decimal) else v for v in vals)


_INT_RE = re.compile(r"^[+-]?[0-9]+$")
_FLOAT_RE = re.compile(r"^[+-]?([0-9]+\.?[0-9]*|\.[0-9]+)([eE][+-]?[0-9]+)?$")


def _jdefault(o):
    if isinstance(o, Decimal):
        return float(o)
    if isinstance(o, (tuple, set, frozenset)):
        return list(o)
    if isinstance(o, Mapping):
        return dict(o)
    return str(o)


def _sig(*types):
    return {"types": list(types)}


class Functions:
    def call(self, name, args, interpreter):
        func = getattr(self, "_func_" + name, None) if name.isidentifier() else None
        sig = getattr(func, "_pathsel_signature", None)
        if func is None or sig is None:
            raise UnknownFunctionError("unknown function: %s" % name)
        self._check_arity(name, sig, len(args))
        self._check_types(name, sig, args)
        return func(*args)

    @staticmethod
    def _check_arity(name, sig, n):
        variadic = bool(sig) and sig[-1].get("variadic")
        if variadic:
            ok = n >= len(sig)
        else:
            ok = n == len(sig)
        if not ok:
            raise ArityError("invalid arity for %s: got %d" % (name, n))

    @staticmethod
    def _check_types(name, sig, args):
        for i, a in enumerate(args):
            spec = sig[min(i, len(sig) - 1)]
            if not _check(spec, a):
                raise InvalidTypeError("invalid type for argument %d of %s" % (i + 1, name))

    # ---- builtins
    @signature(_sig("number"))
    def _func_abs(self, v):
        return abs(v)

    @signature(_sig("array-number"))
    def _func_avg(self, v):
        if not v:
            return None
        return _num_sum(v) / len(v)

    @signature(_sig("number"))
    def _func_ceil(self, v):
        return math.ceil(v)

    @signature(_sig("number"))
    def _func_floor(self, v):
        return math.floor(v)

    @signature(_sig("array", "string"), _sig("any"))
    def _func_contains(self, subject, search):
        if isinstance(subject, str):
            return isinstance(search, str) and search in subject
        return any(json_eq(x, search) for x in subject)

    @signature(_sig("string"), _sig("string"))
    def _func_ends_with(self, s, suffix):
        return s.endswith(suffix)

    @signature(_sig("string"), _sig("string"))
    def _func_starts_with(self, s, prefix):
        return s.startswith(prefix)

    @signature(_sig("string", "array", "object"))
    def _func_length(self, v):
        return len(v)

    @signature(_sig("array", "string"))
    def _func_reverse(self, v):
        if isinstance(v, str):
            return v[::-1]
        return list(reversed(v))

    @signature(_sig("string"), _sig("array-string"))
    def _func_join(self, glue, items):
        return glue.join(items)

    @signature(_sig("object"))
    def _func_keys(self, o):
        return list(o.keys())

    @signature(_sig("object"))
    def _func_values(self, o):
        return list(o.values())

    @signature(_sig("any"))
    def _func_type(self, v):
        return type_name(v) or "object"

    @signature(_sig("any"))
    def _func_to_array(self, v):
        return list(v) if is_array(v) else [v]

    @signature(_sig("any"))
    def _func_to_string(self, v):
        if isinstance(v, str):
            return v
        return json.dumps(v, separators=(",", ":"), ensure_ascii=True, default=_jdefault)

    @signature(_sig("any"))
    def _func_to_number(self, v):
        if is_number(v):
            return v
        if isinstance(v, str):
            if _INT_RE.match(v):
                return int(v)
            if _FLOAT_RE.match(v):
                try:
                    return float(v)
                except ValueError:
                    return None
        return None

    @signature(_sig("array-number", "array-string"))
    def _func_max(self, v):
        return max(v) if v else None

    @signature(_sig("array-number", "array-string"))
    def _func_min(self, v):
        return min(v) if v else None

    @signature(_sig("array-number", "array-string"))
    def _func_sort(self, v):
        return sorted(v)

    @signature(_sig("array-number"))
    def _func_sum(self, v):
        return _num_sum(v)

    @signature({"types": ["object"], "variadic": True})
    def _func_merge(self, *objs):
        out = {}
        for o in objs:
            out.update(o)
        return out

    @signature({"types": ["any"], "variadic": True})
    def _func_not_null(self, *args):
        for a in args:
            if a is not None:
                return a
        return None

    # functions needing the interpreter are handled in call overrides below
    @signature(_sig("expref"), _sig("array"))
    def _func_map(self, ref, arr):
        return [self._interp.visit(ref.node, x) for x in arr]

    @signature(_sig("array"), _sig("expref"))
    def _func_sort_by(self, arr, ref):
        keyed = self._keys(arr, ref)
        order = sorted(range(len(arr)), key=lambda i: keyed[i])
        return [arr[i] for i in order]

    @signature(_sig("array"), _sig("expref"))
    def _func_max_by(self, arr, ref):
        if not arr:
            return None
        keyed = self._keys(arr, ref)
        best = 0
        for i in range(1, len(arr)):
            if keyed[i] > keyed[best]:
                best = i
        return arr[best]

    @signature(_sig("array"), _sig("expref"))
    def _func_min_by(self, arr, ref):
        if not arr:
            return None
        keyed = self._keys(arr, ref)
        best = 0
        for i in range(1, len(arr)):
            if keyed[i] < keyed[best]:
                best = i
        return arr[best]

    def _keys(self, arr, ref):
        keys = [self._interp.visit(ref.node, x) for x in arr]
        if all(is_number(k) for k in keys) or all(isinstance(k, str) for k in keys):
            return keys
        raise InvalidTypeError("sort key must be all numbers or all strings")
