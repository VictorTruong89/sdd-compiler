from .exceptions import (EmptyExpressionError, IncompleteExpressionError,
                         PathSelSyntaxError, SliceStepZeroError)
from .lexer import tokenize

BP = {
    "eof": 0, "unquoted": 0, "quoted": 0, "literal": 0, "rbracket": 0,
    "rparen": 0, "comma": 0, "rbrace": 0, "number": 0, "current": 0,
    "expref": 0, "colon": 0, "pipe": 1, "or": 2, "and": 3,
    "eq": 5, "gt": 5, "lt": 5, "ge": 5, "le": 5, "ne": 5,
    "flatten": 9, "star": 20, "filter": 21, "dot": 40, "not": 45,
    "lbrace": 50, "lbracket": 55, "lparen": 60,
}
PROJECTION_STOP = 10
IDENTITY = ("identity",)
COMPARATORS = ("eq", "ne", "lt", "le", "gt", "ge")


class Parser:
    def __init__(self, expr):
        self.expr = expr
        self.tokens = tokenize(expr)
        self.pos = 0
        self.zero_step = False

    @property
    def cur(self):
        return self.tokens[self.pos]

    def peek(self, k=1):
        return self.tokens[min(self.pos + k, len(self.tokens) - 1)]

    def advance(self):
        self.pos += 1

    def unexpected(self, tok=None):
        tok = tok or self.cur
        if tok[0] == "eof":
            raise IncompleteExpressionError(tok[2])
        raise PathSelSyntaxError(tok[2])

    def expect(self, ttype):
        if self.cur[0] != ttype:
            self.unexpected()
        self.advance()

    def parse(self):
        if self.expr == "":
            raise EmptyExpressionError("empty expression")
        node = self.expression(0)
        if self.cur[0] != "eof":
            raise PathSelSyntaxError(self.cur[2])
        if self.zero_step:
            raise SliceStepZeroError("slice step cannot be zero")
        return node

    def expression(self, rbp):
        left = self.nud()
        while rbp < BP[self.cur[0]]:
            left = self.led(left)
        return left

    # ---- prefix
    def nud(self):
        t = self.cur
        tt = t[0]
        if tt == "literal":
            self.advance()
            return ("literal", t[1])
        if tt == "unquoted":
            self.advance()
            if self.cur[0] == "lparen":
                self.advance()
                args = []
                if self.cur[0] != "rparen":
                    while True:
                        args.append(self.expression(0))
                        if self.cur[0] == "comma":
                            self.advance()
                        else:
                            break
                self.expect("rparen")
                return ("function", t[1], args, t[2])
            return ("field", t[1])
        if tt == "quoted":
            self.advance()
            if self.cur[0] == "lparen":
                raise PathSelSyntaxError(self.cur[2])
            return ("field", t[1])
        if tt == "star":
            self.advance()
            rhs = self.projection_rhs(BP["star"])
            return ("value_projection", IDENTITY, rhs)
        if tt == "filter":
            return self.led_filter(IDENTITY)
        if tt == "lbrace":
            self.advance()
            return self.multihash()
        if tt == "flatten":
            self.advance()
            rhs = self.projection_rhs(BP["flatten"])
            return ("projection", ("flatten", IDENTITY), rhs)
        if tt == "not":
            self.advance()
            return ("not", self.expression(BP["not"]))
        if tt == "lparen":
            self.advance()
            e = self.expression(0)
            self.expect("rparen")
            return e
        if tt == "current":
            self.advance()
            return IDENTITY
        if tt == "expref":
            self.advance()
            return ("expref", self.expression(0))
        if tt == "lbracket":
            self.advance()
            c = self.cur[0]
            if c in ("number", "colon"):
                right = self.bracket_index()
                return self.project_if_slice(IDENTITY, right)
            if c == "star" and self.peek()[0] == "rbracket":
                self.advance()
                self.advance()
                return ("projection", IDENTITY, self.projection_rhs(BP["star"]))
            return self.multilist()
        self.unexpected(t)

    # ---- infix
    def led(self, left):
        t = self.cur
        tt = t[0]
        if tt == "dot":
            self.advance()
            return ("sub", left, self.dot_rhs(BP["dot"]))
        if tt == "pipe":
            self.advance()
            return ("pipe", left, self.expression(BP["pipe"]))
        if tt == "or":
            self.advance()
            return ("or", left, self.expression(BP["or"]))
        if tt == "and":
            self.advance()
            return ("and", left, self.expression(BP["and"]))
        if tt in COMPARATORS:
            self.advance()
            return ("compare", tt, left, self.expression(BP[tt]))
        if tt == "flatten":
            self.advance()
            rhs = self.projection_rhs(BP["flatten"])
            return ("projection", ("flatten", left), rhs)
        if tt == "filter":
            return self.led_filter(left)
        if tt == "lbracket":
            self.advance()
            c = self.cur[0]
            if c in ("number", "colon"):
                right = self.bracket_index()
                return self.project_if_slice(left, right)
            if c == "star" and self.peek()[0] == "rbracket":
                self.advance()
                self.advance()
                return ("projection", left, self.projection_rhs(BP["star"]))
            raise PathSelSyntaxError(self.cur[2]) if c != "eof" else IncompleteExpressionError(self.cur[2])
        raise PathSelSyntaxError(t[2])

    def led_filter(self, left):
        self.advance()
        cond = self.expression(0)
        self.expect("rbracket")
        rhs = self.projection_rhs(BP["filter"])
        return ("filter_projection", left, rhs, cond)

    def project_if_slice(self, left, right):
        if right[0] == "slice":
            return ("projection", ("sub", left, right), self.projection_rhs(BP["star"]))
        return ("sub", left, right)

    def bracket_index(self):
        # current token is first token after '['
        if self.cur[0] == "number" and self.peek()[0] == "rbracket":
            v = self.cur[1]
            self.advance()
            self.advance()
            return ("index", v)
        parts = [None, None, None]
        idx = 0
        seen_colon = False
        while self.cur[0] != "rbracket":
            tt = self.cur[0]
            if tt == "colon":
                idx += 1
                seen_colon = True
                if idx == 3:
                    raise PathSelSyntaxError(self.cur[2])
                self.advance()
            elif tt == "number" and parts[idx] is None:
                parts[idx] = self.cur[1]
                self.advance()
            else:
                self.unexpected()
        if not seen_colon:
            raise PathSelSyntaxError(self.cur[2])
        self.advance()
        if parts[2] == 0:
            self.zero_step = True
        return ("slice", parts[0], parts[1], parts[2])

    def projection_rhs(self, bp):
        tt = self.cur[0]
        if BP[tt] < PROJECTION_STOP:
            return IDENTITY
        if tt in ("lbracket", "filter"):
            return self.expression(bp)
        if tt == "dot":
            self.advance()
            return self.dot_rhs(bp)
        raise PathSelSyntaxError(self.cur[2])

    def dot_rhs(self, bp):
        tt = self.cur[0]
        if tt in ("unquoted", "quoted", "star"):
            return self.expression(bp)
        if tt == "lbracket":
            self.advance()
            return self.multilist()
        if tt == "lbrace":
            self.advance()
            return self.multihash()
        raise PathSelSyntaxError(self.cur[2])

    def multilist(self):
        items = []
        while True:
            items.append(self.expression(0))
            if self.cur[0] == "comma":
                self.advance()
                if self.cur[0] == "rbracket":
                    raise PathSelSyntaxError(self.cur[2])
            else:
                break
        self.expect("rbracket")
        return ("multilist", items)

    def multihash(self):
        pairs = []
        while True:
            t = self.cur
            if t[0] not in ("unquoted", "quoted"):
                self.unexpected()
            self.advance()
            self.expect("colon")
            pairs.append((t[1], self.expression(0)))
            if self.cur[0] == "comma":
                self.advance()
            else:
                break
        self.expect("rbrace")
        return ("multihash", pairs)


def parse(expr):
    return Parser(expr).parse()
