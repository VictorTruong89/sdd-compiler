"""Failure kinds. All are ValueError subclasses."""


class PathSelError(ValueError):
    pass


class EmptyExpressionError(PathSelError):
    pass


class IncompleteExpressionError(PathSelError):
    def __init__(self, lex_position, message=None):
        self.lex_position = lex_position
        super().__init__(message or "incomplete expression at position %d" % lex_position)


class PathSelSyntaxError(PathSelError):
    def __init__(self, lex_position, message=None):
        self.lex_position = lex_position
        super().__init__(message or "syntax error at position %d" % lex_position)


class LexerError(PathSelSyntaxError):
    """Token-level syntax failure."""


class SliceStepZeroError(PathSelError):
    pass


class UnknownFunctionError(PathSelError):
    pass


class ArityError(PathSelError):
    pass


class InvalidTypeError(PathSelError):
    pass
