import json
import re

from .exceptions import LexerError

_IDENT_START = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_")
_IDENT = _IDENT_START | set("0123456789")
_DIGITS = set("0123456789")
_WS = set(" \t\n\r")
_U_RE = re.compile(r"\\u([0-9a-fA-F]{4})")


def _bad_const(name):
    raise ValueError(name)


def _raw_unicode(text):
    def rep(m):
        return chr(int(m.group(1), 16))
    out = _U_RE.sub(rep, text)
    # combine surrogate pairs
    if any(0xD800 <= ord(c) <= 0xDFFF for c in out):
        try:
            out = out.encode("utf-16", "surrogatepass").decode("utf-16")
        except UnicodeError:
            pass
    return out


def tokenize(expr):
    tokens = []
    i = 0
    n = len(expr)
    simple = {
        ".": "dot", "*": "star", "]": "rbracket", "{": "lbrace", "}": "rbrace",
        "(": "lparen", ")": "rparen", ",": "comma", ":": "colon", "@": "current",
    }
    while i < n:
        c = expr[i]
        if c in _WS:
            i += 1
        elif c in _IDENT_START:
            j = i + 1
            while j < n and expr[j] in _IDENT:
                j += 1
            tokens.append(("unquoted", expr[i:j], i))
            i = j
        elif c in _DIGITS or c == "-":
            j = i + 1 if c == "-" else i
            if j >= n or expr[j] not in _DIGITS:
                raise LexerError(i, "unexpected character '-'")
            while j < n and expr[j] in _DIGITS:
                j += 1
            tokens.append(("number", int(expr[i:j]), i))
            i = j
        elif c in simple:
            tokens.append((simple[c], c, i))
            i += 1
        elif c == "[":
            nxt = expr[i + 1] if i + 1 < n else ""
            if nxt == "?":
                tokens.append(("filter", "[?", i)); i += 2
            elif nxt == "]":
                tokens.append(("flatten", "[]", i)); i += 2
            else:
                tokens.append(("lbracket", "[", i)); i += 1
        elif c == "|":
            if expr[i + 1:i + 2] == "|":
                tokens.append(("or", "||", i)); i += 2
            else:
                tokens.append(("pipe", "|", i)); i += 1
        elif c == "&":
            if expr[i + 1:i + 2] == "&":
                tokens.append(("and", "&&", i)); i += 2
            else:
                tokens.append(("expref", "&", i)); i += 1
        elif c == "!":
            if expr[i + 1:i + 2] == "=":
                tokens.append(("ne", "!=", i)); i += 2
            else:
                tokens.append(("not", "!", i)); i += 1
        elif c == "=":
            if expr[i + 1:i + 2] == "=":
                tokens.append(("eq", "==", i)); i += 2
            else:
                raise LexerError(i, "unexpected '='")
        elif c == "<":
            if expr[i + 1:i + 2] == "=":
                tokens.append(("le", "<=", i)); i += 2
            else:
                tokens.append(("lt", "<", i)); i += 1
        elif c == ">":
            if expr[i + 1:i + 2] == "=":
                tokens.append(("ge", ">=", i)); i += 2
            else:
                tokens.append(("gt", ">", i)); i += 1
        elif c == '"':
            j = i + 1
            while j < n and expr[j] != '"':
                j += 2 if expr[j] == "\\" else 1
            if j >= n:
                raise LexerError(i, "unterminated quoted identifier")
            try:
                val = json.loads(expr[i:j + 1])
            except ValueError:
                raise LexerError(i, "invalid quoted identifier")
            tokens.append(("quoted", val, i))
            i = j + 1
        elif c == "`":
            j = i + 1
            while j < n and expr[j] != "`":
                j += 2 if (expr[j] == "\\" and expr[j + 1:j + 2] == "`") else 1
            if j >= n:
                raise LexerError(i, "unterminated literal")
            content = expr[i + 1:j].replace("\\`", "`")
            try:
                val = json.loads(content, parse_constant=_bad_const)
            except ValueError:
                try:
                    val = json.loads('"%s"' % content.lstrip())
                except ValueError:
                    raise LexerError(i, "invalid literal")
            tokens.append(("literal", val, i))
            i = j + 1
        elif c == "'":
            j = i + 1
            while j < n and expr[j] != "'":
                j += 2 if (expr[j] == "\\" and expr[j + 1:j + 2] == "'") else 1
            if j >= n:
                raise LexerError(i, "unterminated raw string")
            content = expr[i + 1:j].replace("\\'", "'")
            tokens.append(("literal", _raw_unicode(content), i))
            i = j + 1
        else:
            raise LexerError(i, "unexpected character %r" % c)
    tokens.append(("eof", "", n))
    return tokens
