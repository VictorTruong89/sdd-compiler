"""PathSel: declarative JSON path expressions."""
from .exceptions import (ArityError, EmptyExpressionError,
                         IncompleteExpressionError, InvalidTypeError,
                         LexerError, PathSelError, PathSelSyntaxError,
                         UnknownFunctionError, ZeroSliceStepError)
from .interpreter import Interpreter
from .parser import parse as _parse

__all__ = ["search", "compile", "ParsedExpression"]


class ParsedExpression:
    def __init__(self, expression, ast):
        self.expression = expression
        self._ast = ast

    def search(self, value, options=None):
        return Interpreter(options).visit(self._ast, value)


def compile(expression):
    return ParsedExpression(expression, _parse(expression))


def search(expression, data, options=None):
    return compile(expression).search(data, options)
