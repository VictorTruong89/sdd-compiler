"""Failure kinds. Every kind is a ValueError."""


class PathSelError(ValueError):
    pass


class EmptyExpressionError(PathSelError):
    pass


class _Positioned(PathSelError):
    def __init__(self, message="", lex_position=0):
        super().__init__(message)
        self.lex_position = int(lex_position)


class IncompleteExpressionError(_Positioned):
    pass


class PathSelSyntaxError(_Positioned):
    pass


class LexerError(PathSelSyntaxError):
    """Token-level syntax failure."""


class ZeroSliceStepError(PathSelError):
    pass


class UnknownFunctionError(PathSelError):
    pass


class ArityError(PathSelError):
    pass


class InvalidTypeError(PathSelError):
    pass
